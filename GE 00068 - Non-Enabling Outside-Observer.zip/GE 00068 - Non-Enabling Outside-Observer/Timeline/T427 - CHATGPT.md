## Engineering assessment

This is another **reconstruction-parent interface defect**, not a contract, schema, or negative-case defect.

The prior repair succeeded:

- The ordinal-4 list-versus-object checker defect was reproduced exactly.
- The schema correctly rejected the malformed `outcome`.
- The repaired checker passed its 20-case regression.
- The independent checker validator passed.
- The repaired source compiled, passed static review, and was frozen.
- Failure finalization worked correctly: all supplied roots closed equal, no process or descriptor survived, and the failed root is non-resumable.

The new failure occurred before reconstruction because the frozen parent expected a field named `literal_names_unique`, while the authenticated 946-case registry contains `names_unique: true`. This exposes a broader process gap: **the parent was frozen before every acceptance-bearing external record interface had been crosswalked against the actual authenticated bytes it would consume.**

The next attempt should not be another one-field patch. It should:

1. Repair this exact registry binding.
2. Enumerate every external JSON/source interface the reconstruction parent reads.
3. Freeze exact schemas, pointers, types, and derived invariants for those inputs.
4. Prohibit silent aliases and fallback defaults on acceptance-bearing fields.
5. Derive counts and uniqueness from rows, treating summary fields such as `names_unique` as corroboration.
6. Complete an independent interface-preflight matrix before source freeze.
7. Execute the frozen reconstruction parent exactly once in a new root.

Multiple pre-freeze source corrections may be retained in the fresh repair root, but after freeze there must be exactly one parent execution and no same-root retry.

```text
FRESH REPAIR OF THE SCHEMA-SUBJECT RECONSTRUCTION PARENT,
COMPLETE EXTERNAL-INTERFACE PREFLIGHT, AND ONE-SHOT RECONSTRUCTION

This task repairs the fresh-subject reconstruction parent after its second
failed one-shot execution.

The exact new defect is:

- the frozen v2 parent required an external negative-case-registry field named:
  literal_names_unique;
- the authenticated retained 946-case registry instead contains:
  names_unique: true;
- the parent failed at:
  fresh_subject_reconstruction_parent_v2.py line 1889;
- reconstruction stopped before contract copying, schema copying, or semantic
  package generation;
- failure finalization completed successfully;
- no supplied root was mutated.

This task must not be a one-field-only patch.

Before freezing or executing the repaired parent, it must establish a complete,
identity-bound interface contract for every external source, registry,
specification, and validation record consumed by the reconstruction pipeline.

This is forward reconstruction engineering, not another historical
provenance-reconciliation task.

It does not:

- alter the normative construction-parent contract;
- alter any of the fifteen current schemas;
- change the 946 negative-case names, mutations, expectations, or mechanisms;
- change the 137 contradiction-regression cases or expectations;
- reuse or patch the historical blocked construction-parent implementation;
- execute process-self-test;
- execute construct mode;
- construct a target-audit harness;
- run a target audit;
- rerun runtime validation;
- modify a repository;
- qualify the product;
- authorize A6.

Do not modify, resume, clean, finish, or retry either failed reconstruction
root.

Do not promote any result from either failed root as a current package result.

Do not create subagents or direct auditors.
Do not run Git.
Do not use the network.
Do not invoke product or live-service behavior.
Do not deploy, publish, externally commit, or start A6.

Use one fresh package root.

Before source freeze, bounded source edits and preflight attempts are permitted
inside the fresh root and must be retained as superseded evidence.

After source freeze:

- exactly one reconstruction-parent execution is permitted;
- no source edit is permitted;
- no replacement parent is permitted;
- no administrative continuation is permitted;
- no same-root retry is permitted.

Return the complete operative result inline.

Return exactly one primary verdict:

CONSTRUCTION_PARENT_SCHEMA_FRESH_SUBJECT_RECONSTRUCTED_READY_FOR_FRESH_HARNESS

CONSTRUCTION_PARENT_SCHEMA_FRESH_SUBJECT_RECONSTRUCTION_BLOCKED

PACKAGE_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. LATEST FAILED RECONSTRUCTION ROOT
──────────────────────────────────────────────────────────────────────────────

FAILED_RETRY_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-fresh-subject-retry-9w9u27us

Expected identity:

- device:
  16777234
- inode:
  180679599
- mode:
  0700
- retained verdict:
  CONSTRUCTION_PARENT_SCHEMA_FRESH_SUBJECT_RECONSTRUCTION_BLOCKED

Expected frozen v2 parent:

provenance/fresh_subject_reconstruction_parent_v2.py

- inode:
  180680467
- mode:
  0600
- size:
  202053
- SHA-256:
  3f48bc75330b1c5718b964428c760e62bfab15e00d0f640b5f259b9c52b7da47

Expected failure record:

closing/reconstruction-failure-v1.json

- inode:
  180685688
- mode:
  0600
- size:
  6196
- SHA-256:
  0968d1bb3b38d4b8bf4dbafc9f92faaf534d7df1e01224a85b1f0e9f6ef3e922

Expected exact blocker:

- source:
  fresh_subject_reconstruction_parent_v2.py
- line:
  1889
- expected field:
  literal_names_unique
- actual authenticated field:
  names_unique
- actual value:
  true
- parent exit:
  1
- child count:
  0
- supplied-root closing equality:
  passed for eight roots
- process survivors:
  0
- descriptor survivors:
  0
- cache survivors:
  0
- same-root retry:
  forbidden

Authenticate through the failed root’s retained:

- bootstrap record;
- source freeze;
- invocation/process records;
- source delta;
- checker regressions;
- independent checker validator;
- artifact plan;
- failure record;
- partial inventory;
- cleanup result;
- supplied-root equality.

Classify the root as:

historical_failed_fresh_reconstruction_v2

It is noncurrent, nonauthoritative, nonresumable, and immutable.

Require complete opening/closing equality if opened.

──────────────────────────────────────────────────────────────────────────────
2. FIRST FAILED RECONSTRUCTION ROOT
──────────────────────────────────────────────────────────────────────────────

FIRST_FAILED_RECONSTRUCTION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-fresh-subject-86y_r9l9

Expected identity:

- device/inode:
  16777234 / 180657503
- mode:
  0700
- retained verdict:
  CONSTRUCTION_PARENT_SCHEMA_FRESH_SUBJECT_RECONSTRUCTION_BLOCKED

Expected v1 parent:

provenance/fresh_subject_reconstruction_parent_v1.py

- inode:
  180659051
- size:
  167068
- SHA-256:
  5ddc657cccb6e19c810b9a535cbd2d05e62ead31a6990c8ed753904e5fd956a8

Use only for:

- v1 → v2 → v3 source lineage;
- original ordinal-4 checker causal;
- proof that the schema correctly rejected the mutation;
- proof that v2 preserved case semantics.

Do not use any result from this root as current package evidence.

Require opening/closing equality if opened.

──────────────────────────────────────────────────────────────────────────────
3. TERMINAL HISTORICAL DECISION
──────────────────────────────────────────────────────────────────────────────

FINAL_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-final-subject-p06-p18-reconciliation-v4j7a04y

Expected identity:

- device/inode:
  16777234 / 180632969
- mode:
  0700
- verdict:
  FINAL_SUBJECT_SCHEMA_P06_P18_RECONCILIATION_STOP_AND_RECONSTRUCT
- mandatory progression:
  FRESH_SUBJECT_RECONSTRUCTION_AND_FRESH_HARNESS_EVALUATION
- historical reconciliation terminal:
  true
- further historical reconciliation authorized:
  false

Expected final diagnostic inventory:

closeout/final-diagnostic-inventory-v1.json

- inode:
  180633002
- size:
  14272
- SHA-256:
  a80260149b05ca1f173426165ae41559696029b2a972149bdcc2c373644fe304

Authenticate this decision.

Do not begin another historical reconciliation.

──────────────────────────────────────────────────────────────────────────────
4. AUTHORITATIVE CONTRACT AND SCHEMA INPUTS
──────────────────────────────────────────────────────────────────────────────

AUTHORITATIVE_CONTRACT_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-2y6tkl0n

Expected identity:

- device/inode:
  16777234 / 180472094
- mode:
  0700

Authoritative normative contract:

contract/package-construction-parent-v1.json

- size:
  32038
- SHA-256:
  874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19

SCHEMA_SOURCE_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-repair-pw27ydqf

Expected identity:

- device/inode:
  16777234 / 180513083
- mode:
  0700

SCHEMA_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-construction-parent-schema-reconciliation-5e2lsx8t

Expected identity:

- device/inode:
  16777234 / 180480821
- mode:
  0700

Use these roots as authority for:

- normative-contract bytes;
- exact fifteen current schemas;
- schema-role identities;
- schema-repair authority;
- historical contradiction definitions.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
5. HISTORICAL VALIDATION-SPECIFICATION INPUT
──────────────────────────────────────────────────────────────────────────────

VALIDATION_SPEC_SOURCE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-evidence-repair-lj_8xygs

Expected identity:

- device/inode:
  16777234 / 180576497
- mode:
  0700

Use this root only for authenticated, root-independent validation
specifications and validator source material.

Do not copy its:

- temporal inventory;
- manifests;
- package status;
- package authority;
- reports;
- explicit confirmations;
- root-bound validator results;
- closing-equality records;
- historical P06/P18 conclusions.

Require opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
6. FRESH PACKAGE ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask `077`, prefix:

ES-repair10i-v3-package-construction-parent-schema-fresh-subject-v3-

Immediately emit:

PACKAGE_ROOT=<absolute-path>

Retain before supplied-root inspection:

opening/bootstrap-start.json

Bind:

- fresh-root identity;
- allocation method and umask;
- both failed reconstruction identities;
- exact v2 source identity;
- exact current blocker;
- terminal historical decision;
- authoritative contract identity;
- schema authority identities;
- validation-specification source identity;
- reconstruction-parent-interface-repair authority;
- contract change authorized:
  false;
- schema change authorized:
  false;
- case-registry change authorized:
  false;
- validator semantic change authorized:
  false;
- implementation creation authorized:
  false;
- process-self-test authorized:
  false;
- construct mode authorized:
  false;
- target audit authorized:
  false;
- runtime validation rerun:
  false;
- same-root retry authorized:
  false.

Create directories lazily.

Do not retain an empty directory except the reserved premanifest `manifest/`
directory at the terminal stage.

──────────────────────────────────────────────────────────────────────────────
7. EXACT CURRENT BLOCKER REPRODUCTION
──────────────────────────────────────────────────────────────────────────────

Before editing source, reproduce the exact v2 blocker from authenticated bytes.

Retain:

analysis/negative-registry-interface-failure-reproduction-v1.json

Authenticate the exact 946-case registry used by v2.

Expected retained identity from the failed report:

- case count:
  946
- size:
  414840
- SHA-256:
  823c1b0bd6a1b4f0bf3217f294d2c5b815e782c2e3dbbc0b84739bef1acdcda3
- retained uniqueness field:
  names_unique
- retained uniqueness value:
  true

Resolve the exact path and schema through authenticated source and package
records.

Retain:

- exact registry path;
- exact schema;
- exact top-level field set;
- exact case-list pointer;
- exact case-name pointer;
- actual count field or fields;
- actual uniqueness field;
- actual uniqueness type and value;
- case-name list or derivation;
- case-name digest field, when present;
- historical field requested by v2:
  literal_names_unique;
- exact source range;
- expected value;
- observed absence;
- fallback behavior;
- first blocker;
- package semantic effect:
  none;
- schema semantic effect:
  none;
- case semantic effect:
  none;
- repair owner:
  reconstruction-parent external-interface binding.

Independently derive:

- case count from actual case rows;
- complete case-name list;
- uniqueness;
- duplicates;
- case-name digest under the registry’s declared encoding, when any.

The derived values are authoritative.

Retained summary fields are corroborative and must equal the derived values.

Do not make `names_unique` alone the uniqueness oracle.

If the actual registry identity or grammar cannot be authenticated, return:

CONSTRUCTION_PARENT_SCHEMA_FRESH_SUBJECT_RECONSTRUCTION_BLOCKED

Do not infer an alias.

──────────────────────────────────────────────────────────────────────────────
8. COMPLETE EXTERNAL-INPUT ACCESS CROSSWALK
──────────────────────────────────────────────────────────────────────────────

Before repairing or freezing the parent, statically enumerate every external
file read and every acceptance-bearing external pointer used by the v2
reconstruction parent.

Retain:

analysis/reconstruction-parent-external-input-crosswalk-v1.json

The crosswalk must cover every supplied-root or copied-specification input
consumed by the full pipeline, including at minimum:

- terminal historical decision;
- normative contract;
- schema source registry;
- schema-reconciliation records;
- exact fifteen schema files;
- validation-source disposition inputs;
- 946-case negative registry;
- 137-case contradiction-regression registry;
- contract-witness specification;
- schema-witness specification;
- field-map specification;
- documentary-validator role specification;
- confirmation-evidence semantics;
- independent-validator source/CLI contract;
- package manifest grammar;
- temporal-inventory grammar;
- historical-lineage inputs.

For every external read bind:

- consumer function;
- exact source range;
- role;
- source root;
- exact path derivation;
- exact expected identity or authority record;
- strict JSON schema or source type;
- exact required top-level fields;
- exact JSON pointers;
- expected types;
- optional fields;
- derived invariants;
- corroborative summary fields;
- whether fallback is permitted;
- exact failure disposition;
- whether the interface is required before source freeze.

No acceptance-bearing input may remain uncrosswalked.

Any unknown or ambiguous indispensable interface blocks reconstruction before
source freeze.

──────────────────────────────────────────────────────────────────────────────
9. EXTERNAL-INTERFACE CONTRACT
──────────────────────────────────────────────────────────────────────────────

Generate:

contract/fresh-subject-reconstruction-external-interface-v1.json

For each external input freeze:

- interface role;
- source authority;
- exact path;
- exact identity when fixed;
- schema or source grammar;
- exact required fields;
- exact pointers;
- exact types;
- row key;
- count derivation;
- uniqueness derivation;
- digest derivation;
- local pass derivation;
- consumer;
- failure reason.

Rules:

1. Acceptance-bearing fields use exact names and pointers.

2. No silent aliases.

3. No fallback from one acceptance-bearing pointer name to another.

4. Missing required fields fail closed.

5. Wrong types fail closed.

6. Counts are derived from rows.

7. Uniqueness is derived from row keys.

8. Digests are independently recomputed.

9. Summary fields are corroboration only and must match the derived values.

10. An absent summary field is not interpreted as false, zero, empty, or pass.

11. Generic recursive list selection is forbidden.

12. Longest-list, same-length-list, first-match, filename, and content scoring
    are forbidden.

13. No external historical result is promoted as a fresh result.

Retain one explicit interface row for the 946-case registry proving that the
current accepted field is:

names_unique

and that:

literal_names_unique

is neither required nor accepted as a substitute unless it actually exists in
the authenticated grammar.

──────────────────────────────────────────────────────────────────────────────
10. WHOLE-PIPELINE INTERFACE PREFLIGHT
──────────────────────────────────────────────────────────────────────────────

Before source freeze, run a read-only preflight against every actual external
input in section 8.

Retain:

validation/reconstruction-external-interface-preflight-v1.json

For every interface retain:

- exact file identity;
- strict parse or source authentication;
- actual field set;
- pointer resolution;
- observed types;
- derived counts;
- derived uniqueness;
- derived digests;
- summary-field agreement;
- pass/failure;
- first blocker.

Require:

- every indispensable interface evaluated;
- every required pointer resolved;
- every required type correct;
- every derived invariant true;
- zero fallback;
- zero unknown interface;
- zero ambiguity;
- pass:
  true.

The parent source must not be frozen until this preflight passes against the
actual supplied inputs.

Prefreeze source corrections needed solely to satisfy the frozen interfaces
are permitted inside this fresh root and must be retained as numbered,
superseded source attempts.

They must not change:

- contract semantics;
- schema semantics;
- case names;
- expected acceptances;
- expected rejection mechanisms;
- validation authority.

──────────────────────────────────────────────────────────────────────────────
11. EXTERNAL-INTERFACE MUTATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Create:

validation/reconstruction-external-interface-matrix-v1.json

Cover at minimum:

Negative registry:

1. Exact authenticated registry.
2. `names_unique=true`.
3. Missing `names_unique`.
4. `names_unique=false` with unique rows.
5. `names_unique=true` with duplicate rows.
6. Mistyped `names_unique`.
7. Nonexistent `literal_names_unique` requested.
8. `literal_names_unique` present as an unknown extra field.
9. Wrong case-list pointer.
10. Missing case list.
11. Case list mistyped.
12. Wrong case-name pointer.
13. Duplicate case names.
14. Count summary mismatches derived count.
15. Digest summary mismatches recomputed digest.
16. Empty case registry.
17. 946 rows with exact unique names.
18. 945 rows.
19. 947 rows.

Generic external interfaces:

20. Required pointer absent.
21. Required pointer renamed.
22. Required pointer wrong type.
23. Optional pointer absent.
24. Corroborative summary absent.
25. Corroborative summary contradicts rows.
26. Generic recursive-list fallback attempted.
27. Same-length-list selection attempted.
28. Historical result presented as current source.
29. Fixed identity mismatch.
30. Strict duplicate-key failure.
31. Nonfinite-value failure.
32. Unknown indispensable interface.

Require:

- thirty-two unique literal names;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip.

──────────────────────────────────────────────────────────────────────────────
12. INDEPENDENT EXTERNAL-INTERFACE VALIDATOR
──────────────────────────────────────────────────────────────────────────────

Implement an independently written validator that imports neither:

- reconstruction-parent helpers;
- the producer interface-preflight helper;
- producer mutation fixtures;
- producer expected-result maps.

It must independently inspect:

- v2 source’s external reads;
- the external-input crosswalk;
- the frozen interface contract;
- actual supplied input bytes;
- the 946-case registry grammar;
- derived case count and uniqueness;
- the thirty-two-case matrix;
- absence of fallback aliases;
- complete coverage of acceptance-bearing external inputs.

Retain:

validation/independent-reconstruction-interface-validator-v1.json

Require zero errors.

──────────────────────────────────────────────────────────────────────────────
13. BOUNDED V2 → V3 SOURCE REPAIR
──────────────────────────────────────────────────────────────────────────────

Copy the authenticated v2 source to:

provenance/fresh_subject_reconstruction_parent_v3.py

Use:

- no-follow stable read;
- exclusive mode-0600 write;
- fsync;
- close;
- no-follow reopen;
- exact byte comparison before authorized edits.

Repair ownership:

fresh-subject-external-interface-preflight-and-registry-binding

Authorized changes are exactly:

A. Negative-registry binding

- replace `literal_names_unique` access with the exact authenticated interface;
- derive names and uniqueness from case rows;
- require the retained `names_unique` field, when contractually required, to
  equal the derived result;
- derive count from rows;
- independently recompute any required case-name digest;
- retain the exact registry schema and pointer identities;
- reject unknown aliases and fallback behavior.

B. Complete external-interface enforcement

- use the frozen external-interface contract for every acceptance-bearing
  external read;
- require exact pointer/type checks;
- prohibit generic list extraction;
- prohibit silent defaults;
- preserve optional-field semantics explicitly;
- retain the exact first interface blocker.

C. Prefreeze attempt lineage

- retain every source attempt and why it was superseded;
- no superseded attempt contributes the frozen identity.

D. Failure finalization

Preserve the v2 complete failure closeout:

- first blocker;
- parent/source/process identities;
- partial inventory;
- child ledger;
- cleanup;
- supplied-root closing equality;
- same-root retry false;
- package authority false;
- terminal closure false.

E. Fresh-root and fresh-output bindings

Regenerate only fresh-root-bound paths and identities.

Unauthorized changes:

- normative-contract interpretation;
- any schema byte;
- fifteen-role set;
- fourteen-family set;
- family normative pointers;
- witness semantics;
- 946 case names;
- 946 expected acceptances;
- 946 expected mechanisms;
- 137 regression semantics;
- field-map rules;
- documentary-validator semantics;
- package manifest grammar;
- terminal authority semantics;
- implementation authority.

Retain:

analysis/reconstruction-parent-v2-v3-source-delta.json

For every changed hunk bind:

- v2 source range;
- v3 source range;
- exact interface defect;
- behavior before;
- behavior after;
- contract effect:
  none;
- schema effect:
  none;
- validation semantic effect:
  none.

Require all unrelated functions AST-identical.

──────────────────────────────────────────────────────────────────────────────
14. NEGATIVE-CHECKER REGRESSION PRESERVATION
──────────────────────────────────────────────────────────────────────────────

Rerun the v2 twenty-case negative-checker repair regression against v3.

Require exact semantic equality with the passing v2 regression:

- 20/20;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero checker exception;
- historical ordinal-4 case passes as correctly rejected.

Retain:

validation/negative-matrix-checker-repair-regression-v2.json

Rerun an independent checker validator against v3 and require zero errors.

──────────────────────────────────────────────────────────────────────────────
15. STATIC PREFLIGHT
──────────────────────────────────────────────────────────────────────────────

Before freeze:

1. Compile v3 with pinned Python:

   /Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
   -I
   -S
   -B

2. Require exit `0` and empty stdout/stderr.

3. Run AST/call-graph/dataflow review.

4. Run bytecode/exception-table review where applicable.

Require:

- finite parent;
- no stdin read;
- no persistent loop;
- no network;
- no Git;
- no shell;
- no repository/product/target operation;
- all child launches through one recorder;
- no uncrosswalked external input;
- no acceptance-bearing `.get(..., default)` fallback;
- exact interface helper use;
- negative checker remains type-safe;
- failure closeout reachable for every preterminal exception;
- success terminal protocol unchanged.

──────────────────────────────────────────────────────────────────────────────
16. SOURCE FREEZE
──────────────────────────────────────────────────────────────────────────────

Freeze v3 only after all of the following pass:

- exact blocker reproduction;
- external-input crosswalk;
- external-interface contract;
- whole-pipeline live interface preflight;
- thirty-two-case interface matrix;
- independent interface validator;
- twenty-case negative-checker regression;
- independent checker validator;
- compile;
- both static analyses.

Retain:

opening/fresh-subject-reconstruction-parent-v3-freeze-v1.json

Bind:

- final source identity;
- all prefreeze source attempts;
- v2 → v3 delta;
- interface contract;
- live preflight;
- matrices;
- independent validators;
- supplied input identities;
- later source modification permitted:
  false;
- same-root retry permitted:
  false.

Reopen v3 no-follow and verify identity.

Do not modify it afterward.

──────────────────────────────────────────────────────────────────────────────
17. ONE-SHOT V3 RECONSTRUCTION
──────────────────────────────────────────────────────────────────────────────

Execute the exact frozen v3 parent once using pinned Python with:

-I
-S
-B

Use the exact direct argv, cwd, explicit environment, timeout, and DEVNULL stdin
retained by the reconstruction process contract.

Do not:

- retry;
- launch a replacement parent;
- perform an administrative continuation;
- edit source after launch;
- resume after failure;
- run an external package validator after a failed execution.

The parent must reconstruct the package from the beginning.

No prior passing output may substitute for a fresh output.

──────────────────────────────────────────────────────────────────────────────
18. COMPLETE RECONSTRUCTION PIPELINE
──────────────────────────────────────────────────────────────────────────────

The v3 parent must execute all stages:

1. Authenticate terminal historical decision.
2. Authenticate authoritative contract package.
3. Authenticate schema source and schema reconciliation.
4. Authenticate historical lineage inputs.
5. Validate every frozen external interface.
6. Retain complete artifact plan.
7. Copy normative contract exactly.
8. Copy all fifteen schemas exactly.
9. Generate exact fifteen-role schema registry.
10. Generate exact fourteen-family authority.
11. Generate schema-role/family mapping.
12. Validate all schemas against Draft 2020-12.
13. Freshly reconstruct fourteen families.
14. Generate fresh contract witnesses.
15. Generate fresh schema witnesses.
16. Execute all 946 negative cases.
17. Execute all 137 contradiction-regression cases.
18. Generate the 766/333 field map.
19. Generate all ten documentary-validator results.
20. Generate the exact ten-role validator registry.
21. Generate the documentary-validator evidence DAG.
22. Run the fresh independent schema validator.
23. Generate confirmation evidence and validator result.
24. Generate evidence-derived explicit confirmations.
25. Generate current-role occupancy.
26. Generate package status and authority.
27. Generate historical lineage.
28. Perform supplied-root closing equality.
29. Perform fixture/cache cleanup.
30. Finalize all nonmanifest outputs.
31. Generate and verify temporal inventory.
32. Generate and verify terminal manifests.
33. Independently reproject the final package.
34. Seal exactly once.
35. Perform no filesystem activity after seal.

──────────────────────────────────────────────────────────────────────────────
19. COMPLETE 946-CASE RESULT
──────────────────────────────────────────────────────────────────────────────

The fresh matrix result must retain:

- registry path and identity;
- registry schema;
- case count:
  946;
- unique case count:
  946;
- exact names and digest;
- derived names uniqueness:
  true;
- retained `names_unique`:
  true;
- retained/derived agreement:
  true;
- complete expected-name closure;
- observed and expected acceptance for every case;
- observed and expected mechanism;
- mutated value type;
- instance path;
- schema path;
- per-case pass;
- checker exception:
  absent.

Require:

- false acceptances:
  0;
- false rejections:
  0;
- reason mismatches:
  0;
- skips:
  0;
- checker exceptions:
  0;
- pass:
  true.

The historical ordinal-4 case must pass as a correctly rejected mutation.

──────────────────────────────────────────────────────────────────────────────
20. FAILURE CLOSEOUT
──────────────────────────────────────────────────────────────────────────────

On either success or failure, retain:

- parent/source identity;
- complete child ledger;
- first blocker when any;
- partial-artifact inventory when any;
- fixture/cache cleanup;
- process/descriptor survivor results;
- complete supplied-root opening/closing equality;
- same-root retry forbidden.

On failure:

- package authority:
  false;
- terminal closure:
  false;
- no success manifests;
- nonzero exit;
- retained root left immutable.

Failure to complete cleanup or supplied-root equality requires:

PACKAGE_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
21. PACKAGE SEMANTIC REQUIREMENTS
──────────────────────────────────────────────────────────────────────────────

The fresh package must establish:

- normative contract exact;
- fifteen current schemas exact;
- exactly fifteen current schema roles;
- exactly fourteen generated-record families;
- normative-construction-parent as the sole schema role without a generated
  family;
- fourteen one-to-one family mappings;
- all fifteen schemas metaschema-valid;
- fourteen contract witnesses schema-valid;
- fourteen schema witnesses contract-valid;
- zero jointly unsatisfiable families;
- zero under-enforced baseline families;
- 946-case matrix pass;
- 137-case regression pass;
- 766/333 field-map closure;
- exactly ten documentary-validator roles;
- all ten current results fresh and passing;
- confirmation validator current and passing;
- current-role occupancy complete;
- implementation present false;
- implementation authority false;
- independent acceptance false before a later fresh audit.

──────────────────────────────────────────────────────────────────────────────
22. SUPPLIED-ROOT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete lstat/no-follow inventories for every supplied root opened,
including:

- both failed reconstruction roots;
- terminal historical reconciliation;
- authoritative contract package;
- schema source package;
- schema reconciliation root;
- validation-specification source;
- any historical lineage root actually opened.

Require exact opening/closing equality.

Do not modify or clean supplied roots.

For every reconstruction-owned fixture/cache root:

- retain complete pre-removal inventory;
- remove exact root;
- observe ENOENT twice;
- require zero process and descriptor survivors.

──────────────────────────────────────────────────────────────────────────────
23. TERMINAL PACKAGE CLOSURE
──────────────────────────────────────────────────────────────────────────────

Use the fresh-subject manifest grammar selected by the terminal historical
decision:

- root row `"."` present exactly once;
- directory fields:
  device, gid, inode, kind, mode, path, uid;
- regular fields additionally:
  nlink, size, sha256;
- exact A/B exclusions;
- no mtime, ctime, directory size, or directory link count.

Use two independent reprojectors.

Use the stabilized final-namespace protocol:

1. Finalize every nonmanifest artifact.
2. Generate and verify temporal inventory.
3. Ensure reserved manifest directory exists.
4. Exclusively create zero-length A and B before either projection.
5. Retain both descriptors.
6. Fsync both empty files and the manifest directory.
7. Generate A and B independently with both paths excluded.
8. Require generated bytes identical.
9. Write through retained descriptors.
10. Fsync and close both.
11. Fsync manifest directory.
12. Reopen no-follow.
13. Reverify path/inode/type/mode/link/size/hash.
14. Require A equals B.
15. Independently reproject final root.
16. Require root row present exactly once.
17. Require no empty descendant.
18. Require no symlink, special object, or multi-link regular file.
19. Require modes `0700/0600`.
20. Require no cache or bytecode.
21. Seal exactly once.
22. After seal, allow only guarded terminal stream output and immediate
    nonreturning exit.
23. Perform no filesystem read or write after seal.

──────────────────────────────────────────────────────────────────────────────
24. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

CONSTRUCTION_PARENT_SCHEMA_FRESH_SUBJECT_RECONSTRUCTED_READY_FOR_FRESH_HARNESS

only when:

- external-interface preflight passes;
- independent interface validator passes;
- v3 source freezes and remains unchanged;
- v3 parent executes exactly once;
- complete reconstruction pipeline passes;
- 946-case matrix passes;
- 137-case regression passes;
- field map closes;
- ten-role validation closes;
- independent schema validator passes;
- confirmation evidence closes;
- occupancy closes;
- implementation remains absent;
- supplied roots close equal;
- cleanup closes;
- temporal inventory verifies;
- manifests verify;
- final reprojection passes;
- no write follows closure.

Return:

CONSTRUCTION_PARENT_SCHEMA_FRESH_SUBJECT_RECONSTRUCTION_BLOCKED

when:

- an external input interface is semantically ambiguous;
- the bounded interface repair cannot be isolated;
- a fresh validation lane fails;
- package authority remains ambiguous;
- the package cannot close without changing contract or schema semantics.

Return:

PACKAGE_PROVENANCE_MISMATCH

for:

- supplied-root mutation;
- source drift after freeze;
- fixed contract/schema identity mismatch;
- unaccounted process or filesystem effect;
- missing failure closeout;
- cleanup inequality;
- supplied-root opening/closing inequality;
- terminal package closure failure;
- filesystem activity after seal.

──────────────────────────────────────────────────────────────────────────────
25. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh package-root identity
3. Latest failed reconstruction identity and disposition
4. First failed reconstruction identity and disposition
5. Terminal historical decision authentication
6. Contract/schema/validation-specification source identities
7. Exact v2 parent identity
8. Exact `literal_names_unique` blocker reproduction
9. Exact 946-case registry identity and grammar
10. Derived case count, name set, uniqueness, and digest
11. Complete external-input access crosswalk
12. Frozen external-interface contract
13. Whole-pipeline live interface preflight
14. External-interface mutation matrix
15. Independent interface validator
16. V3 parent identity
17. Exact v2 → v3 source delta
18. Negative-checker regression V2
19. Independent negative-checker validator
20. Compilation and static analyses
21. V3 source freeze
22. One-shot invocation and process custody
23. Complete child-process ledger
24. Artifact-plan result
25. Normative contract preservation
26. Exact fifteen schemas
27. Exact fifteen-role registry
28. Exact fourteen generated families
29. Governing contract pointers
30. Schema/family mapping
31. Metaschema result
32. Fresh family reconstruction
33. Contract-witness result
34. Schema-witness result
35. Complete 946-case result
36. Historical ordinal-4 case result
37. Complete 137-case regression
38. Field-map result
39. Exact ten-role documentary-validator registry
40. All ten fresh validator results
41. Documentary-validator evidence DAG
42. Fresh independent schema-validator result
43. Confirmation evidence and validator
44. Evidence-derived explicit confirmations
45. Current-role occupancy
46. Package status and authority
47. Historical lineage
48. Supplied-root closing equality
49. Fixture/cache cleanup
50. Failure-finalization result, whether used or not
51. Temporal-inventory identity
52. Manifest A identity
53. Manifest B identity
54. Independent terminal reprojection
55. Terminal membership and modes
56. Root-row presence
57. No-write-after-closure
58. Remaining uncertainty and nonclaims
59. Explicit confirmation registry

Required confirmations:

LATEST_FAILED_RECONSTRUCTION_ROOT_MUTATION_NOT_PERFORMED
LATEST_FAILED_RECONSTRUCTION_ROOT_NOT_RESUMED
LATEST_FAILED_RECONSTRUCTION_ROOT_NOT_CLEANED
FIRST_FAILED_RECONSTRUCTION_ROOT_MUTATION_NOT_PERFORMED
TERMINAL_HISTORICAL_DECISION_AUTHENTICATED
AUTHORITATIVE_CONTRACT_PACKAGE_MUTATION_NOT_PERFORMED
SCHEMA_SOURCE_PACKAGE_MUTATION_NOT_PERFORMED
SCHEMA_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
VALIDATION_SPEC_SOURCE_MUTATION_NOT_PERFORMED
EXACT_V2_PARENT_SOURCE_AUTHENTICATED
EXACT_LITERAL_NAMES_UNIQUE_BLOCKER_REPRODUCED
EXACT_946_CASE_REGISTRY_AUTHENTICATED
NEGATIVE_CASE_COUNT_DERIVED_FROM_ROWS
NEGATIVE_CASE_NAMES_DERIVED_FROM_ROWS
NEGATIVE_CASE_UNIQUENESS_DERIVED_FROM_ROWS
RETAINED_NAMES_UNIQUE_MATCHES_DERIVED_VALUE
NEGATIVE_CASE_DIGEST_INDEPENDENTLY_RECOMPUTED
NO_LITERAL_NAMES_UNIQUE_ALIAS_USED
COMPLETE_EXTERNAL_INPUT_CROSSWALK_PRODUCED
ALL_ACCEPTANCE_BEARING_EXTERNAL_INPUTS_REGISTERED
EXTERNAL_INTERFACE_CONTRACT_FROZEN
WHOLE_PIPELINE_INTERFACE_PREFLIGHT_PASSED
NO_ACCEPTANCE_BEARING_FALLBACK_USED
EXTERNAL_INTERFACE_MUTATION_MATRIX_PASSED
INDEPENDENT_EXTERNAL_INTERFACE_VALIDATOR_PASSED
V3_REPAIR_BOUNDED_TO_EXTERNAL_INTERFACE_BINDING
CONTRACT_SEMANTICS_UNCHANGED
ALL_FIFTEEN_SCHEMA_BYTES_UNCHANGED
NEGATIVE_CASE_REGISTRY_UNCHANGED
NEGATIVE_CASE_EXPECTATIONS_UNCHANGED
NEGATIVE_CHECKER_REGRESSION_V2_PASSED
INDEPENDENT_NEGATIVE_CHECKER_VALIDATOR_PASSED
V3_PARENT_SOURCE_COMPILED
V3_PARENT_STATIC_ANALYSES_PASSED
V3_PARENT_SOURCE_FROZEN
V3_PARENT_SOURCE_NOT_MODIFIED_AFTER_FREEZE
V3_PARENT_EXECUTED_EXACTLY_ONCE
REPLACEMENT_PARENT_NOT_LAUNCHED
ADMINISTRATIVE_CONTINUATION_NOT_USED
PARENT_STDIN_NOT_READ
ALL_CHILDREN_ROUTED_THROUGH_RECORDER
CHILD_ORDINALS_COMPLETE_AND_CONTIGUOUS
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
NORMATIVE_CONTRACT_BYTES_UNCHANGED
EXACTLY_FIFTEEN_CURRENT_SCHEMA_ROLES
EXACTLY_FOURTEEN_GENERATED_RECORD_FAMILIES
NORMATIVE_CONSTRUCTION_PARENT_NOT_COUNTED_AS_GENERATED_FAMILY
EVERY_GENERATED_FAMILY_HAS_NORMATIVE_AUTHORITY
SCHEMA_ROLE_TO_FAMILY_MAPPING_COMPLETE
ALL_FIFTEEN_SCHEMAS_METASCHEMA_VALID
FRESH_FOURTEEN_FAMILY_RECONSTRUCTION_PASSED
FOURTEEN_CONTRACT_WITNESSES_SCHEMA_VALID
FOURTEEN_SCHEMA_WITNESSES_CONTRACT_VALID
ZERO_JOINTLY_UNSATISFIABLE_RECORD_FAMILY
ZERO_UNDER_ENFORCED_BASELINE_RECORD_FAMILY
GENERATED_RECORD_NEGATIVE_MATRIX_946_PASSED
HISTORICAL_BLOCKING_CASE_PASSED_AS_REJECTED_MUTATION
CONTRADICTION_REGRESSION_137_PASSED
CONTRACT_SCHEMA_FIELD_MAP_CLOSED
EXACTLY_TEN_CURRENT_DOCUMENTARY_VALIDATOR_ROLES
ALL_TEN_DOCUMENTARY_VALIDATOR_RESULTS_FRESH
ALL_TEN_DOCUMENTARY_VALIDATOR_RESULTS_PASSED
DOCUMENTARY_VALIDATOR_EVIDENCE_GRAPH_ACYCLIC
INDEPENDENT_SCHEMA_VALIDATOR_PASSED
CONFIRMATION_EVIDENCE_MAP_PASSED
EXPLICIT_CONFIRMATIONS_EVIDENCE_DERIVED
CURRENT_ROLE_OCCUPANCY_COMPLETE
NO_HISTORICAL_CLOSURE_OUTPUT_CURRENT
NO_FAILED_ARTIFACT_CURRENT
IMPLEMENTATION_PRESENT_FALSE
IMPLEMENTATION_AUTHORITY_FALSE
PROCESS_SELF_TEST_NOT_EXECUTED
CONSTRUCT_MODE_NOT_EXECUTED
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
FAILURE_CLOSEOUT_CAPABLE
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
FRESH_SUBJECT_TEMPORAL_INVENTORY_CREATED
FRESH_SUBJECT_TEMPORAL_INVENTORY_VERIFIED
FRESH_SUBJECT_MANIFEST_A_CREATED
FRESH_SUBJECT_MANIFEST_B_CREATED
FRESH_SUBJECT_MANIFESTS_BYTE_IDENTICAL
FRESH_SUBJECT_TERMINAL_REPROJECTION_PASSED
FRESH_SUBJECT_ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_WRITE_AFTER_TERMINAL_CLOSURE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

After:

CONSTRUCTION_PARENT_SCHEMA_FRESH_SUBJECT_RECONSTRUCTED_READY_FOR_FRESH_HARNESS

the next tranche is to construct and qualify a fresh independent-audit harness
bound to the new subject identity, with explicit:

- fifteen-schema-role validation;
- fourteen-generated-family validation;
- P18 zero-root cleanup semantics;
- one fresh full acceptance audit.

Do not begin construction-parent implementation before that fresh audit
accepts the reconstructed subject.
```

**Source:** Codex’s `CONSTRUCTION_PARENT_SCHEMA_FRESH_SUBJECT_RECONSTRUCTION_BLOCKED` report in this turn.  
**Confidence:** 0.995 that the failure is reconstruction-parent interface drift rather than a package semantic defect; 0.99 that comprehensive prefreeze interface validation is needed before another one-shot execution; 0.98 that one fresh v3 repair-and-reconstruction attempt is the correct next progression.
