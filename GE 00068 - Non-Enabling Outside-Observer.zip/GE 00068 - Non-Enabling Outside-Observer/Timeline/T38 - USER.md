Here is Codex's response:

Repair 10I-A4 is sealed and passed complete read-only post-seal verification.

- Source T: `fca111f0c8b91af4b1f60f5afbb74a0bdbe818ac`
- Inventory: `7c2fd63c2eeb02412d2e1a625f88887e045def7b69974a5b604bd391ecdf6c06`
- Exact delta: `FORMAT.md`, `envelope/semantic.go`, `envelope/envelope_test.go`
- Binaries:
  - runner: `9df605f44e2a5fa10cd8bbc9360a7709a739f209fa4bf386353c8a790ef45961`
  - compare: `e53c6878acddb2e601376486ee8994d73bf30f176606ca7f42dea8434ddc6f0f`
  - semantic: `ef378cfe85c26f1e45eb6f4a0895d58c53647c1b74a685d1636bccbb81a52a66`
  - fixture: `d058ebdeb01b960868e4784abafbaaef9d57e8e71b12bdaa71f55aca9786c2f4`
- Vulnerable A3 result: `blocked-uncertain / mutant-delta-policy-mismatch`, zero unknowns.
- Repaired final↔mutant: `qualified-different`, exact provenance, accepted false, zero unknowns, exit 2.
- Final↔fresh: `qualified-equal`, lifecycle/diagnostics/canonical semantics equal, accepted true, zero unknowns, exit 0.
- Mutant↔fresh: `qualified-different`, exact inverse delta, zero unknowns, exit 2.
- [Manifest](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a4-successor-closure-4dd211207800/evidence-manifest-v1.txt): `772cd3d85de7505dad6d9ae4ee38f808b8668f9056c0df784fd81d34814957bf`, 540 payloads.
- [Implementation report](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a4-successor-closure-4dd211207800/closeout/implementation-report-v1.md)

Repository source and immutable lineage remain unchanged. B4 remains absent; its restart point is a fresh turn rerunning all five controls from the beginning with sealed A4.

REPAIR10I\_A4\_MUTANT\_COMPARISON\_PATCH\_SEALED\_READY\_FOR\_10I\_B4\_RESTART
