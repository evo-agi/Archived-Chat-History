## Assessment

The stop is correct. This is a **successor security-posture probe defect**, not evidence against the repository candidate:

- No acceptance-bearing command launched.
- The repository and every sealed predecessor remained exact.
- The failure occurred while constructing the read policy for the exact device literal `/dev/null`.
- Cleanup completed without forced action or residue.

The tempting repair—treat every `EINVAL` from `getattrlist` as “ACL unsupported”—would be unsafe. Darwin documents `EINVAL` for several materially different conditions: a malformed attribute request, an invalid attribute, and an attribute unsupported for the particular filesystem object. `ATTR_CMN_EXTENDED_SECURITY` specifically represents ACL data. 

The correct target is likely a typed posture such as:

```text
ACL observation:
  supported-no-acl
  supported-acl-present
  unsupported-for-exact-object
  probe-error
```

For an exact character-device literal, `unsupported-for-exact-object` may be acceptable when the request is independently proven valid and all stable device identity fields remain exact. It must not become a global `EINVAL` exception, and it must not weaken ACL checks for directories, regular files, executables, source trees, or evidence roots.

Because A6R’s active contract explicitly says ACL/xattr posture is fail-closed, this needs a bounded contract check before implementation. The remaining uncertainty is whether the existing `effective-read-policy.v2` contract already intended a typed unsupported-object state and merely omitted `EINVAL`, or whether accepting that state changes the contract and therefore requires `effective-read-policy.v3` plus a new outer generation.

Generated validation machinery remains bounded proof scaffolding rather than product architecture or authority.  Any eventual successor byte change must be validated separately and followed later by a fresh independent audit. 

## Codex prompt: A6D device-security-posture reconnaissance

```text
Objective

Perform a parent-only, source-read-only Repair 10I-A6D reconnaissance of the
fresh A6 prelaunch blocker involving Darwin ACL/security-posture observation
on `/dev/null`.

Determine the smallest safe successor correction and freeze:

1. the exact object-type-specific ACL/xattr posture model;
2. the exact treatment of `EINVAL`;
3. whether this is an implementation defect within the existing
   `effective-read-policy.v2` contract or a contract change requiring new
   schema generations;
4. the exact successor touched-file set;
5. the complete causal, security-mutant, implementation, and fresh-A6 restart
   plan.

Do not implement the correction in this turn.

Do not modify repository source.
Do not modify the sealed A6R successor.
Do not modify any sealed predecessor.
Do not modify, resume, overwrite, or seal either failed A6 child.
Do not launch another A6 source control.
Do not run a repository test suite or build.
Do not implement the historical comparator.
Do not start B6.
Do not run product A/B.
Do not create a snapshot, ZIP, handoff, or capture child.
Do not stage, commit, push, install, invoke a live route, contact a remote
host, or execute Linux binaries.

No subagents. You are the sole operator.

Candidate repository

CANDIDATE_R=/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Forbidden primary checkout as repository cwd or source root

PRIMARY_R=/Users/ds/Repositories/Execution Substrate

Sealed A5T4 repository lineage

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5t4-harness-closure-ab646e5a0e66

Sealed A6O overlay successor lineage

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6o-overlay-successor-closure-8de797304ea9

Sealed A6R reconnaissance

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6r-read-policy-recon-8de797304ea9

Sealed A6R mutable-tree successor

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6r-read-policy-successor-closure-8de797304ea9

Earlier failed A6 child, immutable and unsealed

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a6o-8de797304ea9

Current failed A6 child, immutable and unsealed

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a6r-8de797304ea9

Required new reconnaissance child, absent at opening

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-recon-8de797304ea9

## 1. Absolute repository-root lock

Before any substantive observation:

1. Component-walk and `lstat` CANDIDATE_R.
2. Require physical path exactly:
   `/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1`
3. Require:
   - type: directory
   - device: `16777234`
   - inode: `122118502`
   - mode: `0755`
   - UID/GID: `501/20`
4. Require physical `pwd -P` to equal CANDIDATE_R.
5. Require PRIMARY_R to remain a distinct sibling:
   - device/inode: `16777234/47685738`
   - no alias
   - no equality
   - no nesting
   - no same inode.

Inspect CANDIDATE_R/.git and require:

- regular pointer file;
- no final symlink;
- mode `0644`;
- size `123`;
- device/inode `16777234/122118504`;
- link count `1`;
- SHA-256:
  `79247c70d443aba211d972b5316847bb38cac45d7caf03c766b9ae5d2e2d0419`;
- exact target:
  `/Users/ds/Repositories/Execution Substrate/.git/worktrees/Execution-Substrate---external-tls-status-observation-v1`;
- common Git directory:
  `/Users/ds/Repositories/Execution Substrate/.git`.

Set:

GIT_OPTIONAL_LOCKS=0
LC_ALL=C
LANG=C

Every Git command must use:

git -C "$CANDIDATE_R" ...

or an explicitly configured subprocess cwd equal to physical CANDIDATE_R.

No command may use PRIMARY_R as cwd, Git `-C` target, source root, or inventory
root.

For inline Python:

- use `PYTHONDONTWRITEBYTECODE=1`;
- verify `os.getcwd()` before repository-relative access;
- import no executable module from evidence children;
- create no `__pycache__` or `.pyc`.

Stop on any mismatch:

REPAIR10I_A6D_WORKTREE_MISMATCH

## 2. Mandatory opening gate

Using candidate-rooted observations only, require:

- branch:
  `codex/remote-alpha-external-tls-status-observation-v1`
- HEAD:
  `567bceced5df95ecfe787cc66038d463a854e12c`
- sole parent:
  `05dde14d185b6e022dcc169ef1a658a97961850f`
- HEAD tree:
  `b7cab23732572c2aaea9d5f2f1593338e2e75338`
- upstream:
  absent
- index SHA-256:
  `012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31`
- repository T:
  `8de797304ea944b6a155924e0d1e9e8bbe79534e`
- repository inventory:
  `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`
- inventory size:
  `54314`
- membership:
  `389 / 375 / 14`
- tracked modifications:
  `22`
- staged/deleted/renamed/unmerged:
  `0/0/0/0`.

Require every governed member to be a regular nonsymlink under the established
inventory contract.

Require exact sealed A5T4:

- manifest SHA-256:
  `7cc55f3399d8c5eac48470a4eb82e8087753ddbb17e8d0eb6de7d03ad7937888`
- manifest size:
  `202930`
- payloads:
  `1000`
- directories:
  `188`
- repository T/inventory:
  `8de797304ea944b6a155924e0d1e9e8bbe79534e` /
  `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`.

Require exact sealed A6R reconnaissance:

- manifest SHA-256:
  `12ec94fff28d4a861b92ec069abd90ddd1e39f9b026777799b585db755cfcb6c`
- payloads:
  `19`
- directories:
  `8`.

Require exact sealed A6R successor:

- manifest SHA-256:
  `fe8954e4401005e85059fc0d44684b89bce38c7019d239ebcd5dfa000030f983`
- manifest size:
  `26785`
- payloads:
  `193`
- directories:
  `28`
- source T:
  `50f08cc78fe8634488063853e43904a633261f51`
- source inventory:
  `56f20b54e4992c860598c6603563b4eea589421dff886c5d4002adcc9846c84f`
- members:
  `12`.

A6R binaries:

repair10-runner:
`84afddf2657480661215557059de3eecbf74db8e9ec5f43f19ad883b7ddc1199`

repair10-compare:
`c9af21bd8841a55979c7a907a77195a03345eac6c83001651f11a09a0e7d2781`

repair10-semantic:
`fb438eaf872bc86310fd79b1820a2163aa8a2c9fc2fd5515cc22ad0f5fee2d9a`

repair10-fixture:
`d058ebdeb01b960868e4784abafbaaef9d57e8e71b12bdaa71f55aca9786c2f4`

Require:

- complete A6R post-seal verification;
- exact A6R 24-schema dialect;
- all 32 A6R causals;
- all 58 overlay causals;
- all seven A5C tests;
- A5P2 PTY and execution-policy nonregression.

Require the current failed A6 child to remain:

- present;
- unsealed;
- without manifest or detached digest;
- byte-exact from opening through closing.

Reverify:

- `findings/fresh-validation-block-v1.json`
- `closeout/validation-blocked-closeout-v1.json`
- `closeout/command-root-audit-v1.json`
- suite specification;
- all seven command intents/results;
- read policies;
- rendered profiles;
- raw streams;
- terminal records;
- cleanup and absence records.

Bind exactly:

- failure occurred during pristine-final prelaunch read-policy construction;
- acceptance-bearing commands launched:
  `0`;
- all seven commands:
  `not-launched`;
- syscall/API:
  `getattrlist`;
- requested security attribute:
  `ATTR_CMN_EXTENDED_SECURITY`;
- option:
  `FSOPT_NOFOLLOW`;
- object:
  `/dev/null`;
- returned errno:
  `EINVAL`;
- current A6R classification:
  not accepted as unsupported ACL operation;
- remaining four controls, comparisons, analysis, and policy freeze:
  not started;
- cleanup:
  complete, eleven private roots removed, two absence epochs;
- failed child:
  unrecoverable for continued execution and intentionally unsealed.

Require the earlier failed A6 child and all other predecessor lineage to remain
exact.

Require the A6D target to be absent.

Stop on any mismatch:

REPAIR10I_A6D_RECONNAISSANCE_BASELINE_MISMATCH

## 3. Reconnaissance child

After the opening gate, create A6D exclusively under umask 077 with exactly:

opening/
source/
probes/
schemas/
tests/
findings/
closeout/

All directories mode `0700`.

All files regular, single-link, nonsymlink, mode `0600` or `0700`.

No hardlinks.

Do not import executable modules from predecessor evidence.

The child may contain only:

- safe bounded source excerpts and inventories;
- ACL/xattr producer/consumer analysis;
- private local probes;
- frozen schema and implementation contract;
- causal and restart plans;
- closeout evidence.

No repository test or build is authorized.

## 4. Recover the exact A6R security-posture model

Inspect exact sealed A6R source:

- `FORMAT.md`
- `envelope/runner.go`
- `envelope/semantic.go`
- `envelope/envelope_test.go`
- `envelope/source.go` only to confirm whether it consumes relevant fields;
- CLI mains only where schema dispatch is material.

Recover:

1. Every ACL-related structure, field, enum, and status.
2. Every xattr-related structure, field, enum, and status.
3. Every grant kind to which ACL/xattr observation applies.
4. Every accepted unsupported-operation errno.
5. Every rejected capability or observation errno.
6. Exact `getattrlist` attribute masks.
7. Exact options.
8. Buffer structure and validation.
9. Whether `ATTR_CMN_RETURNED_ATTRS` is requested.
10. Whether `FSOPT_PACK_INVAL_ATTRS` is used.
11. Whether calls are path-based or descriptor-based.
12. Whether the request is shared across files, directories, executables, and
    device literals.
13. Every producer, fingerprint, peer-verification, qualification, and
    comparison consumer.
14. Exact meaning of the frozen
    `ACL/xattr capability error` causal.
15. Exact normative statements concerning:
    - unsupported object;
    - unsupported volume;
    - absent ACL;
    - ACL present;
    - malformed response;
    - probe failure.

Determine whether the FORMAT contract already admits a typed
unsupported-for-object outcome that the implementation failed to recognize.

State where inspection stops.

## 5. Recover the exact `/dev/null` grant

From the failed A6 records recover:

- grant kind;
- grant role;
- requested path;
- physical path;
- no-follow component observations;
- file type;
- device/inode;
- UID/GID;
- mode;
- link count;
- `rdev`;
- filesystem/mount identity if recorded;
- flags;
- existing xattr posture;
- opening and closing observations;
- logical-fingerprint fields;
- command(s) requiring the grant;
- whether any command writes `/dev/null`;
- whether the grant is read-only, write-only, or read/write;
- whether the producer and peer both use the same security-posture probe.

Determine whether `/dev/null` is represented as:

- exact device literal;
- generic file literal;
- tree descendant;
- executable;
- another kind.

Identify every other admitted exact device literal, including where present:

- `/dev/zero`
- `/dev/random`
- `/dev/urandom`
- exact `/dev/fd/N` controls
- PTY device paths.

Do not inspect the operator terminal.

## 6. Darwin errno and API ambiguity

Treat `EINVAL` as ambiguous until causally resolved.

Distinguish:

- invalid `bitmapcount`;
- invalid attribute mask;
- unsupported attribute for the filesystem object;
- incompatible attribute combinations;
- invalid options;
- malformed buffer/request;
- another object-specific failure.

Determine whether the current request can be independently proven valid by:

- exact source construction;
- private regular-file success;
- private directory success;
- a returned-attributes bitmap;
- another safe positive control.

Do not accept `EINVAL` globally.

Do not equate `EINVAL` with “no ACL.”

## 7. Controlled private probes

Use one exclusive private probe root.

Do not touch repository files.
Do not access credentials or unrelated user state.
Do not inspect the operator terminal.
Do not retain sensitive metadata.

Use the exact A6R request implementation where possible.

Required probes:

### 7.1 Known-valid request

Apply the exact attribute request to:

- a private regular file;
- a private directory.

Record:

- return;
- errno;
- returned attribute bitmap where available;
- ACL posture;
- xattr posture;
- stable object identity.

This must establish whether the request itself is structurally valid.

### 7.2 Exact device literals

Probe safely:

- `/dev/null`;
- every other device literal already admitted by the A6R policy and required by
  its commands.

Record:

- exact type and `rdev`;
- return and errno;
- whether results are stable over repeated observations;
- whether producer and peer can observe the same typed posture.

Do not add a new device merely for testing.

### 7.3 Malformed-request controls

In private code, deliberately create:

- wrong bitmap count;
- invalid attribute bit;
- incompatible attribute combination;
- invalid option where safe.

Require these to produce a rejected result, even when errno is `EINVAL`.

The repaired model must distinguish these from an exact known-valid request on
an unsupported object.

### 7.4 Returned-attributes model

Probe whether:

- `ATTR_CMN_RETURNED_ATTRS`;
- `FSOPT_PACK_INVAL_ATTRS`;
- descriptor-based `fgetattrlist`;

can provide a safer explicit unsupported-attribute result for exact device
literals.

Do not adopt a mechanism merely because it avoids `EINVAL`; assess its complete
buffer and identity semantics.

### 7.5 Replacement and symlink controls

Using private objects only:

- symlink to a private device-like or regular target;
- path replacement;
- type substitution;
- same-path new inode.

Require the stable identity layer to reject these independently of ACL posture.

### 7.6 Xattr controls

Determine whether xattr observation on exact device literals is:

- supported and empty;
- supported and populated;
- unsupported-for-object;
- another probe failure.

Do not treat ACL and xattr support as necessarily identical.

## 8. Candidate-model adjudication

Evaluate all models.

### Model A — globally classify EINVAL as unsupported

Reject unless impossible source evidence proves it safe.

Expected disposition: reject because `EINVAL` also represents malformed or
invalid requests.

### Model B — exact device-literal unsupported-object posture

Candidate target:

For an exact declared character-device literal only, an exact known-valid
security-posture request may record:

`unsupported-for-object`

when all are true:

- grant kind and role are exact;
- path and physical path are exact;
- no-follow component identity passes;
- type is exact character device;
- device/inode and `rdev` are exact;
- owner/mode/flags and governed xattr posture are exact;
- request validity is independently established;
- errno is one of the explicitly frozen object-unsupported outcomes;
- producer and peer independently observe the same posture.

This is not “ACL absent.”

Assess whether this is the preferred correction.

### Model C — skip ACL/xattr checks for device literals

Evaluate and likely reject because it removes factual security-posture evidence.

### Model D — use returned-attribute packing

Assess whether this produces a more explicit, deterministic posture without
weakening validation.

### Model E — alternate ACL API

Assess whether another existing Darwin API gives an exact object-support
answer without a new dependency or broad code path.

Do not select it solely for convenience.

### Model F — require every admitted device literal to support ACL queries

Assess whether this would unnecessarily reject stable exact device objects
whose security is governed by type, `rdev`, owner, mode, flags, and exact path.

### Model G — path-specific `/dev/null` exception

Evaluate whether a path-only exception is too narrow or brittle compared with a
typed exact-device-literal contract.

## 9. Required posture state machine

Freeze a closed state model separately for ACL and xattr posture.

At minimum adjudicate:

- observed-absent;
- observed-present;
- unsupported-for-object;
- unsupported-for-volume, if materially distinct;
- malformed-response;
- probe-error;
- capability-unavailable.

Define:

- which states may qualify by grant kind;
- which are report-only;
- which are always blocking;
- which errno/API evidence produces each state;
- which stable identity fields must accompany an unsupported state;
- how producer and peer equality is established.

Do not conflate:

- unsupported;
- absent;
- inaccessible;
- malformed;
- permission denied;
- internal request error.

## 10. Schema/version analysis

Inspect the active A6R dialect:

- `effective-read-policy.v2`;
- eight outer v5 records;
- v3 command records;
- v2 PTY records;
- existing v1 records.

Determine whether the frozen v2 contract already contains the selected typed
posture.

### If the contract already admits it

Freeze this as an implementation correction within:

- `effective-read-policy.v2`;
- outer v5 chain unchanged.

Require proof that:

- FORMAT already specifies the state;
- fields already encode it unambiguously;
- strict decoders already support it;
- only errno/API classification code and missing causals are incomplete.

### If acceptance meaning changes

Freeze new schema generations:

- likely `effective-read-policy.v3`;
- likely complete outer v6 chain;

but derive the exact set from producer/consumer inspection.

Do not reuse v2/v5 identifiers with changed acceptance semantics.

Determine whether command, PTY, overlay, semantic-extraction, byte-comparison,
or provenance schemas remain unchanged.

Freeze complete old/new dialects and strict mixed-generation rejection.

## 11. Logical fingerprint contract

Determine whether the logical fingerprint must bind:

- posture state;
- device grant kind;
- role;
- exact path;
- exact device type and `rdev`;
- support-versus-absence distinction.

Volatile errno text must not become authority when a typed state is sufficient.

Independently changing an acceptance-bearing posture field must change the
fingerprint or fail strict validation.

## 12. Peer qualification contract

Freeze independent peer behavior.

The peer must:

1. reconstruct the exact grant kind and role;
2. independently prove path/type/device/inode/`rdev`/owner/mode/flags;
3. use the exact security-posture request;
4. independently establish request validity;
5. classify ACL and xattr posture separately;
6. compare typed posture, not producer captions;
7. reject malformed requests and unsupported states not admitted for the grant;
8. retain exact errno/API observations factually;
9. reject stable identity or file-byte changes regardless of posture;
10. preserve late-close/resource failure behavior.

## 13. Self-attestation and authority assessment

Confirm the proposed correction:

- grants no new path;
- grants no new syscall authority to controlled commands;
- does not make `/dev` broadly readable;
- does not grant PTY or terminal access;
- does not change repository/product behavior;
- changes only external validation interpretation of an exact observed object;
- does not let producer captions qualify themselves.

## 14. Exact successor touched-file freeze

Inspect whether correction requires:

- `FORMAT.md`
- `envelope/runner.go`
- `envelope/semantic.go`
- `envelope/envelope_test.go`
- `envelope/source.go`
- any command main
- golden files
- `go.mod`.

Freeze the smallest complete set.

No repository file may change.
No new dependency.
No thirteenth member.
No general Darwin metadata framework.

## 15. Future causal matrix

Freeze tests covering at least:

1. Exact `/dev/null` vulnerable A6R behavior reproduced.
2. Exact known-valid request on private regular file.
3. Exact known-valid request on private directory.
4. Exact device literal returns selected unsupported posture and qualifies.
5. Producer and peer independently derive the same posture.
6. Unsupported posture is not represented as ACL absent.
7. Malformed bitmap-count EINVAL rejects.
8. Invalid-attribute EINVAL rejects.
9. Incompatible-attribute EINVAL rejects.
10. EINVAL on regular file rejects.
11. EINVAL on directory/tree rejects.
12. EINVAL on executable rejects.
13. EINVAL on an undeclared path rejects.
14. Wrong device type rejects.
15. Wrong `rdev` rejects.
16. Same path with replacement inode rejects.
17. Symlink substitution rejects.
18. Owner/mode/flags/security-posture mutation rejects.
19. Xattr unsupported and ACL unsupported are classified independently.
20. ACL present remains visible and governed.
21. ACL malformed response rejects.
22. Permission-denied probe rejects.
23. Unexpected errno rejects.
24. Producer-caption pass with peer failure rejects.
25. Late close/resource fault rejects.
26. Literal regular-file and executable size/digest checks remain exact.
27. Mutable-tree A6R causals remain unchanged.
28. Overlay, A5C, and PTY causals remain unchanged.
29. No grant widening to generic `/dev`.
30. No operator-terminal access.
31. Old/new policy schemas reject when mixed, if versioning changes.
32. The retained failed-A6 prelaunch condition becomes a bounded positive
    successor-tool causal only.

## 16. Future implementation and A6 restart

Freeze:

1. Create a new successor implementation child from sealed A6R.
2. Implement only the frozen device-security-posture correction.
3. Run two disjoint test/race/build controls.
4. Reproduce the current prelaunch failure under A6R as expected-negative.
5. Run bounded exact `/dev/null` and malformed-request causals.
6. Reverify mutable-tree, overlay, observability, and PTY nonregression.
7. Seal the successor amendment.
8. Create a new A6 evidence child.
9. Restart all five controls from the beginning.
10. Do not resume the current failed A6 child.
11. Run all five comparisons and structural historical-policy analysis.

A bounded `/dev/null` causal never substitutes for the fresh five-control A6
refresh.

## 17. Future stop conditions

Freeze stop conditions including:

- baseline or lineage mismatch;
- exact request structure cannot be recovered;
- `EINVAL` remains causally ambiguous;
- malformed and unsupported-object EINVAL cannot be distinguished;
- selected model weakens regular-file, directory, executable, or tree checks;
- grant scope widens;
- operator terminal or generic `/dev` access is required;
- ACL and xattr posture cannot be kept distinct;
- peer cannot independently recompute posture;
- schema impact cannot be closed;
- source scope cannot be frozen;
- repository edit, dependency, or thirteenth member required.

## 18. Verdict

Return exactly one.

### Contract ready

REPAIR10I_A6D_RECONNAISSANCE_READY

Use only when:

- the exact `/dev/null` failure is fully explained;
- malformed request and unsupported object are causally distinguishable;
- closed ACL/xattr posture states are frozen;
- qualifying states are frozen by grant kind;
- schema dialect is complete;
- peer qualification is independent;
- touched-file scope and causal matrix are complete;
- no authority widening is required.

### Contract blocked

REPAIR10I_A6D_RECONNAISSANCE_BLOCKED

Use when:

- `EINVAL` cannot be disambiguated safely;
- exact device posture cannot be independently proved;
- regular-file/tree checks would need weakening;
- schema or scope remains unresolved;
- a repository or public-contract change is required.

## 19. Required report

Include:

1. Opening and closing identities.
2. Exact failed-A6 prelaunch identity.
3. Exact `getattrlist` request and call path.
4. Exact `/dev/null` grant identity.
5. Complete ACL/xattr current-state model.
6. Private probe outcomes.
7. `EINVAL` ambiguity adjudication.
8. Candidate-model adjudication.
9. Frozen ACL and xattr posture states.
10. Qualifying states by grant kind.
11. Schema/version decision.
12. Logical-fingerprint contract.
13. Peer-qualification contract.
14. Security and authority assessment.
15. Exact touched-file set.
16. Complete causal matrix.
17. Future implementation and fresh-A6 restart sequence.
18. Stop conditions.
19. Inspection limits and unresolved uncertainty.
20. Manifest SHA-256 and payload count if sealed.
21. Confirmation no repository, successor, predecessor, failed-A6, cache,
    bytecode, test, or build artifact was modified.

No implementation.
No successor amendment.
No additional A6 control.
No comparisons or historical analysis.
No B6.
No product A/B.
No snapshot.
No ZIP, handoff, or capture child.
No independent audit.
No staging, commit, push, installation, live route, remote contact, or Linux
execution.
```

A6’s current unsealed child should remain exactly what it is: evidence that the source control never launched because of an unresolved validation-policy precondition. It must not be repaired in place or represented as a qualifying run.

### Sources

- Codex’s `REPAIR10I_A6_VALIDATION_BLOCKED` report supplied in this turn.
- Apple/Darwin `getattrlist(2)` documentation: `EINVAL` can mean either an invalid request or an attribute unsupported for the particular filesystem object; `ATTR_CMN_EXTENDED_SECURITY` represents ACL data. 
- Milestone 0 proof-scaffolding and non-authority boundary. 
- Governed Execution implementation, repair, and independent-audit separation. 
- Provenance establishes exact bytes, not correctness or a sound security boundary. 

**Confidence**

- Correctness of the A6 stop: **0.999**
- Classification as a successor security-posture probe defect: **0.98**
- Confidence that broad `EINVAL` acceptance would be unsafe: **0.995**
- Confidence that a typed exact-device `unsupported-for-object` posture is the likely repair: **0.89**
- Confidence that schema impact must be inspected before implementation: **0.99**
