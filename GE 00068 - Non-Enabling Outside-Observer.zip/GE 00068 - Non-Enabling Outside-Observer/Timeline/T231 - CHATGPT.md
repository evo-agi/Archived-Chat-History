This closeout is sufficient. The failed attempt should be **discarded permanently**.

The mismatch is entirely an audit-process failure: the first post-epoch process used the primary checkout as its working directory, did not use the controlled environment or umask, did not allocate the audit root, and did not create the mandatory bootstrap record. It read only the prompt attachment; it never inspected the candidate, supplied roots, or target correctness. Therefore:

- **No implementation repair is indicated.**
- **No target identity needs reconciliation.**
- **No negative inference about the repository or correction capsule is warranted.**
- The no-mutation confirmations are credible as process facts because only `sed` and `cat` ran, but they are **not a closing equality proof**.
- The next action is a wholly fresh audit in a **new Codex conversation**.

This fresh audit is still necessary because the earlier retained machine evidence confirms the intended candidate path family and exact seven repository paths, but it does not retain the four auditor reports, auditor command ledger, or proof that the fourth auditor completed its assigned scope.  

The repeated startup failures point to a flaw in the audit choreography: prompt intake must be explicitly **pre-epoch**, and the first **audit-epoch** process must be one controlled bootstrap operation.

## Send this to a fresh Codex chat

```text
FRESH INDEPENDENT AUDIT —
REPAIR 10I A6 SUCCESSOR-GOVERNANCE MODE-PROVENANCE CORRECTION

This is a wholly new read-only audit. Do not resume, continue, reuse, repair,
or reinterpret any earlier audit attempt. In particular, do not reuse any
prior audit root.

OBJECTIVE

Independently audit the exact candidate repository and the exact
mode-provenance correction capsule described below.

The audit must determine whether the correction:

1. accurately reproduces the predecessor logical-mode provenance defect;
2. reconstructs the exact corrected three-record binary delta from
   authenticated repository-mode and payload evidence;
3. has two materially independent builders;
4. rejects the complete required mutation matrix;
5. narrowly and correctly supersedes only the defective provenance artifacts;
6. remains correctly rebound to the repository governance bytes and prior
   validation;
7. has complete, private, deterministic evidence closure;
8. introduces no product, runtime, lifecycle, readiness, publication,
   orchestration, or other authority widening.

Return exactly one primary verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

Do not repair any finding.

----------------------------------------------------------------------
A. PRE-EPOCH PROMPT INTAKE
----------------------------------------------------------------------

Read this entire request through EOF before beginning the audit epoch.

If the client presents this request as an attachment:

- perform exactly one administrative full-file read;
- use the attachment directory itself, or `/Users/ds/Downloads`, as cwd;
- use the attachment’s absolute path;
- read the complete file through EOF, not a fixed line range;
- do not use any repository checkout as cwd;
- do not inspect any repository or supplied-root content;
- do not treat this administrative read as audit evidence.

Only after the entire request has been read may the audit epoch begin.

Do not run `pwd`, `git`, `ls`, `find`, `rg`, `stat`, Python inspection, or any
other process against a repository or supplied root before the controlled
bootstrap in section B.

----------------------------------------------------------------------
B. FIRST AUDIT-EPOCH PROCESS — MANDATORY BOOTSTRAP
----------------------------------------------------------------------

The first process after the audit epoch begins must:

- have cwd exactly:

  `/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1`

- explicitly receive:

  PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
  GIT_OPTIONAL_LOCKS=0
  GIT_CONFIG_NOSYSTEM=1
  LC_ALL=C
  LANG=C
  PYTHONDONTWRITEBYTECODE=1

- set umask `077`;
- use pinned Python where Python is needed;
- atomically allocate a fresh unpredictable audit root beneath
  `/Users/ds/Downloads` with `tempfile.mkdtemp`;
- use a prefix such as:

  `ES-repair10i-a6-governance-mode-provenance-independent-reaudit-`

- immediately and exclusively create a mode-0600 bootstrap record beneath
  that root before inspecting candidate or supplied-root content;
- record:
  - complete argv;
  - cwd;
  - explicit environment;
  - effective umask;
  - allocated audit-root path;
  - process start disposition;
  - process exit and captured-stream identities.

No audit root may be preselected by a fixed complete pathname.

If this first-process contract is violated, stop immediately and return
AUDIT_PROVENANCE_MISMATCH. Do not continue correctness inspection.

----------------------------------------------------------------------
C. PROCESS AND WORKING-DIRECTORY BOUNDARY
----------------------------------------------------------------------

Primary working-tree content beneath:

`/Users/ds/Repositories/Execution Substrate`

is forbidden.

The candidate linked worktree named below is permitted.

Every repository Git invocation must use:

`git -C "$CANDIDATE_R" ...`

with cwd exactly `$CANDIDATE_R` and the controlled environment above.

No unrooted Git command is permitted.

Narrow Git-administration identities and marker/lock paths may be derived only
through rooted Git commands. Do not broadly traverse primary-checkout Git
administration or primary-working-tree content.

Every non-Git operand must be absolute. No substantive process may rely on an
inherited primary-checkout cwd.

Parent processes may use only:

- `$CANDIDATE_R`;
- the fresh audit root;
- or an explicitly assigned supplied root

as cwd.

Any post-epoch process targeting the primary working tree, or any unrecorded
cwd/operand ambiguity, is an immediate AUDIT_PROVENANCE_MISMATCH.

----------------------------------------------------------------------
D. COMPLETE PROCESS RECORDING
----------------------------------------------------------------------

Create an audit-owned command wrapper before correctness inspection.

Every parent command and every auditor command must use that wrapper. The
wrapper must:

- create a mode-0600 exclusive start record before execution;
- record full argv, cwd, explicit environment, umask, assigned auditor, and
  allowed operand roots;
- capture complete stdout and stderr;
- retain exit or signal, byte counts, and SHA-256 values;
- create a separate immutable outcome record;
- never overwrite or reuse a process-record path.

Do not reconstruct a missing record later.

If any process was invoked without its required contemporaneous record, stop
with AUDIT_PROVENANCE_MISMATCH.

----------------------------------------------------------------------
E. EXACT TARGETS
----------------------------------------------------------------------

CANDIDATE_R:

`/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1`

Expected candidate identity:

- device/inode: `16777234 / 122118502`
- branch: `codex/remote-alpha-external-tls-status-observation-v1`
- HEAD: `567bceced5df95ecfe787cc66038d463a854e12c`
- HEAD tree: `b7cab23732572c2aaea9d5f2f1593338e2e75338`
- sole parent: `05dde14d185b6e022dcc169ef1a658a97961850f`
- upstream: absent
- governed/tracked/untracked/directories: `389 / 375 / 14 / 93`
- source T: `f276536fea579d0842cda43b0290656b200b7f27`
- inventory SHA-256:
  `2c152fd6a6d558bff3a56d906f0bd0b8c7f346fcb647d40fe386cfd02163d738`
- staged/deleted/renamed/unmerged: `0 / 0 / 0 / 0`

Exact seven governed path identities:

1. `PLANS.md`
   - mode `100644`
   - bytes `288739`
   - SHA-256
     `f9ba77d11df271e951d29cdf4aa0f21fdc2faa13b698343d2c20e0bbaa19fe8f`

2. `.docs/system_overview/configuration.md`
   - mode `100644`
   - bytes `129589`
   - SHA-256
     `f83f9469014cd89fdbea8fdf5c38eb5a580c25c4937b066e27d665d073fe14b3`

3. `.docs/system_overview/boundaries.md`
   - mode `100644`
   - bytes `96086`
   - SHA-256
     `0bac404d0f4c56cfcc9e7f5f91594c1017a471ed1e9b5be2d4c2347eba03a7dd`

4. `.docs/system_overview/artifact_hygiene.md`
   - mode `100644`
   - bytes `38322`
   - SHA-256
     `2f262b42385d6963c2c6ab4677204361e7f8ecc217192f915b3f056bf9f69910`

5. `.docs/system_overview/capability_probing.md`
   - mode `100644`
   - bytes `42668`
   - SHA-256
     `f177f939932e21e8d53fe521aad9386253e330527b6a85eeb73c0888b1acdeb2`

6. `.docs/system_overview/remote_alpha_external_tls_status_deployment_v1.md`
   - mode `100644`
   - bytes `99195`
   - SHA-256
     `18cfad593028ea25575d5e9593d95533cbda6400bba52897bba8a9ae4f17f32d`

7. `docs_contract_test.go`
   - mode `100644`
   - bytes `794256`
   - SHA-256
     `e43d41791758e6e8ebf2e7fe585e7469f342d9eb3013171cc76bece662f02684`

Do not substitute any similarly named path. In particular, do not replace:

- `boundaries.md` with `service_boundaries.md`;
- the deployment document with a path under `.docs/execution_lifecycle/`;
- root `docs_contract_test.go` with a path beneath `internal/`.

CORRECTION_ROOT:

`/Users/ds/Downloads/ES-repair10i-a6-governance-mode-provenance-repair-fsgu2x8c`

Expected:

- device/inode: `16777234 / 177842688`
- 7 directories including root
- 43 regular files
- directories mode `0700`
- files regular, single-link, mode `0600`
- no empty directory, symlink, or special object
- canonical manifests A and B:
  - 8,590 bytes each
  - byte-identical
  - SHA-256:
    `d7a0c0f376c1a52c2b9b6cdc2b64d43ce9cd2235602b71a2e15552746f6f7cde`
- corrected delta copies:
  - 2,474,094 bytes each
  - byte-identical
  - SHA-256:
    `0ea21358c208771a5dfd1d79d5d298e28cd68d8cd76e5b4c1a1576863df73ec1`

PREDECESSOR_ROOT:

`/Users/ds/Downloads/ES-repair10i-a6-governance-audit-repair-vv8mi2cl`

Expected:

- device/inode: `16777234 / 177742499`
- 10 directories and 98 files
- 108 objects total
- inventory SHA-256:
  `0036cb2e461a66c94fd29f9cde71fc9c51d2ceceddca0d2f6da421396d4ac2ac`
- canonical manifests:
  `1c07db3979d02afcf7852c6c4819630046950712426a267a4117a6774c28b751`

BLOCKING_AUDIT_ROOT:

`/Users/ds/Downloads/repair10i-a6-governance-independent-audit-5n5vkzxr`

Expected:

- device/inode: `16777234 / 177779617`
- 4 directories and 86 files
- 90 objects total
- inventory SHA-256:
  `f64183e7bc5bc731afd291d2e773e2f0062796942a5eeff58918863fb3b37cac`

The prior process-defective audit that ended in AUDIT_PROVENANCE_MISMATCH is not
an audit input and must not be resumed or treated as substantive evidence.

----------------------------------------------------------------------
F. OPENING GATE
----------------------------------------------------------------------

Before correctness inspection:

1. Verify the exact candidate identity and governed inventory.
2. Verify all seven path identities above.
3. Verify exact correction-root closure and both manifests.
4. Verify predecessor and blocking-audit root identities.
5. Verify no repository operation marker or lock.
6. Verify no audit root collision.
7. Verify every opening process record.
8. Preserve an exact opening inventory for every supplied root.
9. Verify no process has targeted primary-working-tree content.
10. Verify no auditor has started.

Stop with AUDIT_PROVENANCE_MISMATCH on any mismatch.

----------------------------------------------------------------------
G. FOUR DIRECT AUDITORS
----------------------------------------------------------------------

After the opening gate passes, start exactly three distinct direct auditors
concurrently:

1. `delta_semantics`
2. `builder_independence`
3. `supersession_rebinding`

After `delta_semantics` completes and its report is retained, start exactly one
new fourth direct auditor:

4. `capsule_security`

No retries unless an auditor fails to start; at most one start retry is
permitted. Do not create nested subagents.

Each auditor must:

- use cwd exactly `$CANDIDATE_R` or its assigned audit-root directory;
- use only absolute operands;
- use the mandatory command wrapper for every process;
- run no Git;
- mutate nothing;
- identify all files and roots inspected;
- distinguish evidence, inference, and uncertainty;
- state uninspected scope;
- state mutation performed: no;
- state nested subagents created: no.

The parent must retain, under the audit root:

- the exact prompt supplied to each auditor;
- an immutable start event;
- a complete report;
- a completion event;
- its command/process ledger;
- exact cwd and complete operand list.

If any required report or ledger is missing, return AUDIT_PROVENANCE_MISMATCH.

----------------------------------------------------------------------
H. REQUIRED CORRECTNESS WORK
----------------------------------------------------------------------

1. Reproduce the predecessor defect.

   Confirm that the predecessor delta has exactly these three incorrect logical
   before modes:

   - `.docs/system_overview/capability_probing.md`
   - `.docs/system_overview/remote_alpha_external_tls_status_deployment_v1.md`
   - `docs_contract_test.go`

   Expected relationship:

   opening logical mode = `100644`
   predecessor delta before mode = `100600`
   predecessor delta after mode = `100644`

   Confirm that payload bytes, sizes, hashes, paths, ordering, after modes,
   delimiters, and terminal framing are otherwise authentic.

2. Independently reconstruct the corrected delta.

   Do not import either producer builder or validator.

   Derive logical before modes from the authenticated repair-opening inventory.
   Derive final identities from the authenticated final inventory and live
   candidate bytes.

   Require exactly three records and exactly the authorized path order.

   The reconstruction must equal both corrected delta copies byte for byte and
   yield:

   size = `2474094`
   SHA-256 =
   `0ea21358c208771a5dfd1d79d5d298e28cd68d8cd76e5b4c1a1576863df73ec1`

3. Prove the exact predecessor-versus-corrected byte difference.

   Require equal total length and exactly six changed bytes corresponding only
   to three `100600 -> 100644` mode corrections.

   Expected zero-based changed offsets:

   `156, 157, 114209, 114210, 376748, 376749`

   Expected field starts:

   `152, 114205, 376744`

4. Audit builder independence.

   Determine whether:

   - builder A and builder B independently parse authenticated inventories;
   - neither derives repository logical modes from evidence-custody permissions;
   - neither consumes the predecessor delta to generate its output;
   - neither embeds the expected corrected digest to force output;
   - no shared local helper supplies the central parsing or mode decision;
   - the language/runtime difference is substantive rather than cosmetic.

5. Run an independently authored thirteen-case mutation matrix.

   It must reject:

   - before mode `100600`;
   - before mode `100755`;
   - wrong after mode;
   - wrong before hash;
   - wrong after hash;
   - record reordering;
   - unauthorized added path;
   - missing authorized path;
   - changed before payload byte;
   - changed after payload byte;
   - custody-mode substitution on all paths;
   - trailing byte;
   - truncated terminal byte.

   Retain fixtures only under the audit root and remove them during cleanup.

6. Audit supersession lineage.

   Verify exact predecessor-to-successor mapping for:

   - corrected delta A;
   - corrected delta B;
   - corrected delta identity;
   - corrected final report.

   Confirm supersession is limited to logical-mode provenance claims and does
   not rewrite or reclassify repository bytes, governance, tests, validation,
   or unrelated evidence.

7. Audit repository rebinding and authority.

   Verify:

   - the exact seven path identities;
   - the exact three repair paths;
   - sole writer:
     `.docs/system_overview/remote_alpha_external_tls_status_deployment_v1.md`;
   - exact five non-overriding consumers;
   - `docs_contract_test.go` as the documentary test;
   - current target remains selected-not-implemented;
   - no product/public/runtime/readiness/commit/publication authority widening.

8. Audit capsule closure.

   Verify exact path membership, types, modes, links, sizes, hashes,
   self-exclusions, no empty directory, no special object, no unexplained
   member, and no mutable or hidden evidence authority.

9. Perform bounded sensitive-material and artifact inspection without printing
   secrets or payload contents.

----------------------------------------------------------------------
I. VALIDATION POSTURE
----------------------------------------------------------------------

Repository bytes are unchanged by the correction capsule.

Do not rerun product tests merely to create activity. Inspect and bind the prior
validation evidence to the exact repository bytes.

Audit-owned parsers, reconstruction, mutation fixtures, and security checks are
permitted only beneath the audit root.

No repository formatting, cleanup, chmod, staging, commit, reset, amend, push,
PR, merge, A6 execution, product path, live service, or network contact is
authorized.

----------------------------------------------------------------------
J. CLOSEOUT
----------------------------------------------------------------------

After all four auditors complete:

1. Preserve disagreements.
2. Reconcile auditor findings with parent-owned reproduction.
3. Remove only audit-created temporary fixtures and private caches.
4. Do not chmod supplied roots.
5. Make two fresh observations that removed private state is absent.
6. Verify no process or descriptor survivor.
7. Re-run complete read-only identities for candidate and every supplied root.
8. Require opening/closing equality.
9. Verify every process record and every auditor report/ledger.
10. Retain a complete audit-root inventory with all directories and files.
11. Return one verdict.

If process evidence is missing, the correct verdict is
AUDIT_PROVENANCE_MISMATCH, not an inferred correctness result.

----------------------------------------------------------------------
K. REQUIRED REPORT
----------------------------------------------------------------------

Return a complete inline report containing:

1. Primary verdict.
2. Administrative pre-epoch disclosure.
3. Audit-root identity and bootstrap record.
4. Exact candidate and supplied-root identities.
5. Opening-gate result.
6. Complete process-record integrity result.
7. Four auditor identities, schedules, cwd values, operands, command-record
   ranges, reports, completion state, retries, and disagreements.
8. Predecessor-defect reproduction.
9. Independent corrected reconstruction.
10. Exact six-byte difference proof.
11. Builder-independence adjudication.
12. Thirteen-case mutation matrix.
13. Supersession and lineage.
14. Repository rebinding and prior-validation treatment.
15. Capsule and manifest closure.
16. Authority/security/artifact adjudication.
17. Severity-ranked findings.
18. Minority findings and parent resolution.
19. Remaining uncertainty and explicit nonclaims.
20. Audit-created paths and cleanup.
21. Closing equality.
22. Explicit action confirmations.

Do not claim ACCEPT unless all required process and correctness evidence is
retained.
```

The operating protocol requires exact provenance before correctness inspection and a stop on any mismatch; it also requires all audit perspectives to be bound to the same target and retained through closeout.  A provenance mismatch is explicitly a stop-before-judgment condition, not an implementation finding. 

### Sources

- The retained reconciliation identifies the intended candidate paths and hashes, and separately records the missing auditor/process evidence that prevents reliance on the prior audit.  
- The project audit protocol requires provenance reproduction before correctness inspection and prohibits reconstructing missing audit coverage through inference. 
- The provenance guidance treats a mismatch as a stop condition and distinguishes exact-byte evidence from implementation correctness. 

**Confidence:** 0.995 that the failed attempt should be discarded without implementation action; 0.96 that the startup and retained-evidence controls above address the failure mode that invalidated both the latest attempt and the earlier nonqualifying audit.
