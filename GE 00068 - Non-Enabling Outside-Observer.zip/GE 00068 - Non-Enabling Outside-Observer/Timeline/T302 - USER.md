Here is Codex's response:

AUDIT\_PROVENANCE\_MISMATCH
The bootstrap carrier failed before process-package materialization. Failed fresh audit root:
`/Users/ds/Downloads/ES-validation-custody-v3-audit-repair-independent-audit-ik29rus5`
No V3 target or supplied target root was inspected or modified. The failed root was not resumed, repaired, or cleaned.
