## Assessment

`GENERIC_PHASE_WRAPPER_READY` closes the remaining process-capability prerequisite. The probe established the exact behavior we needed:

- A phase-start record was written before payload compilation.
- A deterministic `SyntaxError` produced a complete phase outcome rather than a carrier-record gap.
- A later valid phase succeeded with the same wrapper bytes.
- Four consecutive carriers produced complete start/outcome pairs.

I accept the probe **narrowly as phase-wrapper capability evidence**. I would not reuse its cleanup or final-inventory claims as target-audit provenance:

- The reported ENOENT observations named never-created sentinels rather than the removed `private/` path.
- Carrier 0004’s outcome necessarily appeared after its payload generated the closeout inventory.

The full audit prompt below fixes both points. It requires two observations of the exact removed `private/` path and gives the final inventory an explicit, bounded temporal self-exclusion for its own file and the final wrapper outcome.

All prerequisites are now complete:

- Strategic B opening gate: accepted.
- Generic pre-compilation phase wrapper: ready.
- V3 target: unchanged.
- Runtime validation replay: still prohibited.

No further probe or producer repair should precede the full V3 audit.

---

```text
FRESH FULL INDEPENDENT AUDIT —
REPAIR 10I T2A-P VALIDATION-CUSTODY V3 RECORD COMPLETION

Perform a wholly fresh, independent, read-only audit of the combined target:

1. the accepted Strategic B opening gate;
2. the immutable Strategic B snapshot;
3. the immutable blocked V1 validation-custody capsule;
4. the immutable V2 validation-custody capsule;
5. the immutable V2 independent audit; and
6. the immutable V3 record-completion capsule.

Do not repair anything.
Do not mutate any supplied input.
Do not replay runtime validation.
Do not run product code or repository tests.
Do not make network contact.
Do not stage or commit.
Do not start A6.
Do not create nested subagents.

Return exactly one primary verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

OBJECTIVE

Determine whether Validation-Custody V3:

- completely and unambiguously freezes the supported-local validation-custody
  contract;
- preserves every executable and acceptance-bearing Plan V3 semantic in
  Plan V4;
- closes the exact source dependency chain for the 86-byte Unix-socket path
  derivation;
- states all required nonauthority boundaries explicitly;
- composes the bounded V2 technical evidence without promoting the V2 audit’s
  BLOCK verdict;
- rejects independent contradictory mutations;
- preserves one normative writer;
- has complete capsule, artifact, process, and opening/closing provenance.

An ACCEPT qualifies the exact record-complete validation-custody contract and
Plan V4 bytes. It grants no publication, commit, product, runtime, deployment,
readiness, semantic-successor, orchestrator, or A6 authority.

──────────────────────────────────────────────────────────────────────────────
1. ACCEPTED PREREQUISITES
──────────────────────────────────────────────────────────────────────────────

A. STRATEGIC B OPENING GATE

Accepted gate root:

/Users/ds/Downloads/ES-strategic-b-gate-requalification-uTwKU7hS

Accepted gate record:

closeout/accepted-strategic-b-opening-gate-v1.json

- size:
  4173
- SHA-256:
  555041298ee49db603a7c3ff64e022cdf8bf79cd7d7edc6007dcd32e35998212

Gate manifests:

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

- size:
  10066 bytes each
- SHA-256:
  d58de35fdf630829b1fb7efe80a04f0616a66c98039fdf27a2b49a622c49bd05
- required:
  byte-identical

The gate record contains `full_v3_audit_authorized: false` because it is not
allowed to self-authorize a later audit. This user instruction supplies the
authority to perform the present audit. Do not treat that field as a blocker.

B. GENERIC PHASE-WRAPPER CAPABILITY

Capability-probe root:

/Users/ds/Downloads/ES-repair10i-generic-phase-wrapper-probe-sj1gm5ns

Accepted wrapper source:

provenance/phase_runner.py

- SHA-256:
  6e911ca17dedc6c5838b8b880548761b9009bb18fc26f1e7b6934d274f040f56

The probe qualified only this generic behavior:

- start record before payload read or compilation;
- complete SyntaxError outcome;
- valid phase after SyntaxError;
- contiguous phase records across multiple carriers.

Do not use the probe root as V3 qualification evidence.
Do not inherit its cleanup or final-inventory conclusions.
Leave the probe root immutable.

──────────────────────────────────────────────────────────────────────────────
2. ADMINISTRATIVE INTAKE AND AUDIT EPOCH
──────────────────────────────────────────────────────────────────────────────

Read this complete prompt before invoking any tool or process.

Administrative prompt intake before the audit epoch is excluded from evidence.

Do not inspect the candidate, Strategic B, V1, V2, the V2 audit, V3, or the
accepted gate during administrative intake.

After reading the complete prompt, state exactly:

AUDIT_EPOCH_START

The first post-epoch carrier is the one permitted bootstrap exception described
in §3. Every later target-facing carrier must use the exact retained generic
phase wrapper.

──────────────────────────────────────────────────────────────────────────────
3. PROCESS-AUTHORITY SPLIT
──────────────────────────────────────────────────────────────────────────────

Use this exact authority split.

The Codex platform transcript is the authority for:

- top-level carrier ordering;
- exact submitted top-level command;
- submitted cwd;
- submitted explicit environment;
- platform-reported carrier result;
- direct-auditor creation, scheduling, identity, and completion.

The audit root is the authority for:

- bootstrap identity;
- phase inputs and outcomes;
- child-process records;
- target and supplied-root observations;
- retained artifacts;
- opening and closing filesystem equality;
- audit-owned cleanup.

The audit root does not self-attest creation of its own top-level carrier.
Dependence on the Codex platform transcript for carrier launch facts is an
explicit supported property, not an audit defect.

No persistent supervisor is required or permitted.

──────────────────────────────────────────────────────────────────────────────
4. EXACT INPUTS
──────────────────────────────────────────────────────────────────────────────

CANDIDATE_R:

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Expected candidate identity:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- upstream:
  absent
- governed/tracked/untracked:
  389 / 375 / 14
- tracked modifications:
  22
- staged/deleted/renamed/unmerged:
  0 / 0 / 0 / 0
- current F source T:
  f276536fea579d0842cda43b0290656b200b7f27
- current F inventory:
  54314 bytes
  SHA-256:
  2c152fd6a6d558bff3a56d906f0bd0b8c7f346fcb647d40fe386cfd02163d738

STRATEGIC_B_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-snapshot-tx56oir2

Accepted Strategic B stable identities:

- corrected final report:
  closeout/final-report.md
  151150 bytes
  SHA-256:
  2a853c551635c223eec38eb229535285541a653dfa5f1ce59855fd5b2082b2fe

- manifest pair:
  139328 bytes each
  SHA-256:
  df5933f201437dc9ac55f22f72aac4bdde8477a203b7ca22358ab11e77f5c9fc
  required byte-identical

- final evidence inventory:
  130182 bytes
  SHA-256:
  fb30338e1a0fc39359b3517d6f70303ea086689330074b9f1f35854a431a73bb

- stable canonical whole-root projection:
  schema:
  execution-substrate.strategic-b-canonical-inventory.v1
  size:
  96657
  SHA-256:
  4c5556d5c74a5c9a8669e4ba9f2ec061d97fa6fa6e6276459439d9d376370360

- B source inventory:
  54314 bytes
  SHA-256:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2

- governed B source files:
  389

- B source T / Git tree:
  8de797304ea944b6a155924e0d1e9e8bbe79534e

- H→B:
  22 modified
  14 added
  0 deleted
  0 renamed

- synthetic evidence commit:
  e42aac659299e023df07a842df17e9fc84a135c1
  evidence only, not publication authority

Legacy Strategic B inventory hashes:

- 797aad807f76e93a92642b7b3ef798ebab856ecea242325daa623ec08866c201
- ee1ddad6e334149656cb3b310fc6a94a0d4c630c309889296c1aae8e1afecfdc

These are historical ordering-dependent projections only. They must not appear
as acceptance-bearing opening gates.

BLOCKED_V1_REPAIR_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-validation-custody-repair-ivliq7wf

Expected:

- device/inode/mode:
  16777234 / 178515489 / 0700
- complete-tree inventory:
  20758 bytes
  SHA-256:
  7e202a82f642124f952c288ae5ba6f4056150e8163df60101f6d7d630257d3b0
- final inventory SHA-256:
  42d0bd7607af442a4dd943c88175f7e2ef8baff739f72d7b01cccb637e73d3e0
- both manifests:
  73bafd4bf6eeaa7a2511af1a7ac01106ed0d32ab4d719c0dcbab1674985eb498
- disposition:
  immutable historical non-effective sibling-root design

VALIDATION_CUSTODY_V2_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-validation-custody-v2-8r8lyfra

Expected:

- device/inode/mode:
  16777234 / 178558083 / 0700
- complete-tree inventory:
  29434 bytes
  SHA-256:
  33a659bc82d8fe67778e9806674c8a5f5b0477ea7a36a67af9cb902c3c186b76
- contract:
  execution-substrate.repair10i-t2ap.strategic-b-validation-custody.v2
- Plan V3:
  28590 bytes
  SHA-256:
  fee24453d7c4c951f5ce27c55589f169737c97def516a7ad13df3cbe2eee1eee
- final inventory:
  22990 bytes
  SHA-256:
  c17800c69c02565864f8f82a2d70cd5654b729c775c6503627c9742abac6d658
- final report:
  1355 bytes
  SHA-256:
  9e7fd3f059c2cd6e2e3fe306a28a47449b478c63203c82e73f717e1941ad25cd
- both manifests:
  24408 bytes
  SHA-256:
  2bcff6abee571388a37d30d956abb9012630796911f4aa57380806a67bc90628

V2_INDEPENDENT_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v2-independent-audit-znleuyfy

Expected:

- device/inode/mode:
  16777234 / 178646858 / 0700
- complete-tree inventory:
  64018 bytes
  SHA-256:
  e8824a5f0b36b5d4c3b93e71a92b443257e3c1c1f4e97bfba9d4509d8a63ba5e
- verdict:
  BLOCK
- audit report:
  92491 bytes
  SHA-256:
  e977c8ed3394f5e890a1cc1d6b0bf0067b7c430de9b264b5bd9d8028eb6c1e05
- audit inventory:
  69706 bytes
  SHA-256:
  9d29fb1b53f56768fc03762fb152562368f5f3903a02dc4aa0c10d14c2292caf

VALIDATION_CUSTODY_V3_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-record-repair-emh5kxis

Expected root:

- device/inode/mode:
  16777234 / 178799785 / 0700

Expected fixed identities:

- `contract/strategic-b-validation-custody-v3.json`
  4878 bytes
  SHA-256:
  16bfae705924cc67ce21dc8b4a2aada0d181b930a395fc03616f2d05aa017d55

- `contract/validation-plan-v4.json`
  26001 bytes
  SHA-256:
  af1a4349ce6abfc4eadba43297b634c27b8069e2407c4c980737760599098dea

- `contract/plan-v3-v4-semantic-equivalence-v1.json`
  3937 bytes
  SHA-256:
  4855cbd41a4c16a4d0ff52aa2dec75bdd66b1f272d1e1323d7a3b8759efe2f5b

- `validation/producer-documentary-validator-result-v1.json`
  18211 bytes
  SHA-256:
  796c295ae899fe386e268939e6a8c1bdad53559ac8d5cb9ffd066ec9454a0f04

- `validation/independent-documentary-validator-result-v1.json`
  19104 bytes
  SHA-256:
  5411a9a2c3b36d4d8af0c724319d6c1e0451576d9c0f8bb90adb403b48d9f19d

- `validation/mutation-matrix-v1.json`
  22410 bytes
  SHA-256:
  77c844a8261f55110c8900b42cef0d3d47ec39205209f089467c8c0c4cb9fe60

- `closeout/final-implementation-report-v1.md`
  21171 bytes
  SHA-256:
  4cec72ec50ddf41658b9fbf6a48c843ce5a2377bfaf17424bdefada7f1f0d3e6

- `closeout/final-evidence-inventory-v1.json`
  18305 bytes
  SHA-256:
  f7f602952c1a44d442982e883fe6be44c48dca0a908701126463e943964b25c9

- both manifests:
  19881 bytes
  SHA-256:
  94ae9bf8eea0c96b37dfc0aac9134e0acd727510a936621606d7923febced359
  required byte-identical

Expected closure:

- 12 directories including root
- 88 physical files including manifests
- 86 nonmanifest files
- 98 represented entries
- exactly two self-excluded manifests
- no empty directory
- all directories mode 0700
- all files regular, single-link, mode 0600
- no symlink or special object

PINNED GO TOOLCHAIN:

/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go

Expected SHA-256:

3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19

PINNED SOURCE CLOSURE:

- B `internal/testsupport/controlroot.go`
  8695 bytes
  SHA-256:
  3242abc3bfd62400834b99d1386f88974f463ca5287be7faf4182161f8ec57f3

- B `internal/testsupport/controlroot_test.go`
  1359 bytes
  SHA-256:
  de224a8fe61becb88237fca683c1bd91406d8952d1f776819f3f069ef5509e6f

- B `es/runtimehelper/helper_test.go`
  5017 bytes
  SHA-256:
  715b6e1ada4f24a51457b31f28782966804479b18d0ba7b90c73609d17d0a1e0

- Go `src/os/tempfile.go`
  4002 bytes
  SHA-256:
  a337c2a6dc2e4368b2dc0015ea7c0b935b68b14885a0771a6cbe27e588c2cd16

- Go `src/internal/strconv/itoa.go`
  6171 bytes
  SHA-256:
  cfda0d39152dc8ad8e2eb0407682c399ea0a321796211e015096fa57b17a35d5

──────────────────────────────────────────────────────────────────────────────
5. CANDIDATE GIT ENVIRONMENT
──────────────────────────────────────────────────────────────────────────────

Every candidate Git read must use:

git -C "/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1"

with cwd exactly equal to CANDIDATE_R and explicit:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

No Git command may target a supplied evidence root or the primary checkout.

──────────────────────────────────────────────────────────────────────────────
6. FRESH AUDIT ROOT AND BOOTSTRAP
──────────────────────────────────────────────────────────────────────────────

The first post-epoch carrier is the sole bootstrap exception.

It must:

- use CANDIDATE_R as its submitted cwd;
- set umask 077;
- allocate a fresh retained root beneath `/Users/ds/Downloads` using
  `tempfile.mkdtemp` with prefix:

  ES-repair10i-t2ap-validation-custody-v3-independent-audit-

- create:

  opening/
  auditors/
  contract/
  validation/
  provenance/
  closeout/
  manifest/
  private/

- exclusively write `opening/bootstrap.json`;
- verify the accepted wrapper source at the capability-probe root;
- copy its exact bytes to:

  provenance/phase_runner.py

- retain the copied wrapper as regular, single-link mode 0600;
- verify its SHA-256 remains:

  6e911ca17dedc6c5838b8b880548761b9009bb18fc26f1e7b6934d274f040f56

- record the wrapper source identity, audit-root identity, explicit
  environment, cwd, umask, and bootstrap disposition;
- inspect no target or supplied evidence content.

The platform transcript is authoritative for this bootstrap carrier’s launch.

After bootstrap, every target-facing carrier must invoke the exact copied
generic wrapper.

No unwrapped target-facing diagnostic carrier is permitted.

──────────────────────────────────────────────────────────────────────────────
7. GENERIC WRAPPED PHASES
──────────────────────────────────────────────────────────────────────────────

For each target-facing carrier:

- invoke `provenance/phase_runner.py`;
- supply a unique contiguous carrier ordinal;
- supply a retained audit-owned payload;
- supply the payload’s expected path, size, and SHA-256;
- supply the phase name;
- supply exact authorized operands;
- supply expected output records.

The wrapper must create and fsync:

provenance/carrier-NNNN.phase-start.json

before reading or compiling the payload.

The wrapper must always create and fsync:

provenance/carrier-NNNN.phase-outcome.json

after payload completion or failure.

SyntaxError, ImportError, FileNotFoundError, PermissionError, OSError,
SystemExit, and ordinary payload exceptions must produce complete outcomes.

Failed wrapped phases may be retained and superseded when their failure does
not invalidate target provenance. Do not overwrite them.

Do not use `rg`, `fd`, or another optional discovery binary. Use Python
standard-library traversal and exact matching.

──────────────────────────────────────────────────────────────────────────────
8. CHILD-PROCESS RECORDER
──────────────────────────────────────────────────────────────────────────────

The first wrapped phase must create and retain:

provenance/child_runner.py

Before target inspection, independently validate the child recorder using:

Child 0001:

- attempt an absent executable under `private/`;
- require a start record before spawn;
- require FileNotFoundError / ENOENT;
- require complete empty streams and outcome.

Child 0002:

- execute `/usr/bin/true`;
- require exit 0;
- require empty streams;
- require reaping and descriptor closure.

For every later external child process, retain exactly:

provenance/child-NNNN.start.json
provenance/child-NNNN.stdout
provenance/child-NNNN.stderr
provenance/child-NNNN.outcome.json

The start record and stream files must exist and be fsynced before spawn.

No child-process launch may bypass this recorder.

If the child-recorder self-causal fails, stop with
AUDIT_PROVENANCE_MISMATCH before target inspection.

──────────────────────────────────────────────────────────────────────────────
9. OPENING PROVENANCE GATE
──────────────────────────────────────────────────────────────────────────────

Before correctness inspection:

1. Read candidate `AGENTS.md` and applicable nested guidance.
2. Verify the complete candidate identity.
3. Verify the accepted Strategic B gate record and its manifests.
4. Verify the corrected Strategic B report identity.
5. Re-run both accepted Strategic B canonical generators.
6. Require byte-identical output:
   96657 /
   4c5556d5c74a5c9a8669e4ba9f2ec061d97fa6fa6e6276459439d9d376370360
7. Verify the Strategic B source inventory and tree.
8. Verify complete BLOCKED_V1_REPAIR_ROOT closure.
9. Verify complete VALIDATION_CUSTODY_V2_ROOT closure.
10. Verify complete V2_INDEPENDENT_AUDIT_ROOT closure.
11. Verify complete VALIDATION_CUSTODY_V3_ROOT closure.
12. Verify every fixed V3 identity.
13. Verify the pinned Go executable and five exact source files.
14. Retain complete opening inventories for every supplied root.
15. Verify candidate locks and operation markers are absent.
16. Verify carrier and child-process recording continuity through this phase.

Do not use either legacy 164,555-byte Strategic B digest as an opening gate.

Stop with AUDIT_PROVENANCE_MISMATCH on any input mismatch.

Do not begin V3 semantic inspection before this gate passes.

──────────────────────────────────────────────────────────────────────────────
10. FOUR DIRECT READ-ONLY AUDITORS
──────────────────────────────────────────────────────────────────────────────

After opening provenance passes, start exactly three distinct direct auditors
concurrently. After the first completes, start a fourth distinct auditor.

The Codex platform transcript is authoritative for start order and completion.

Auditor 1 — contract and authority

Inspect:

- complete V3 contract;
- Plan V4;
- supersession record;
- complete V3 report;
- failed-attempt classification.

Adjudicate:

- one sole normative validation-custody writer;
- complete allocator contract;
- complete explicit nonauthority;
- no B-source authority;
- no verdict promotion;
- no competing authority in failed attempts.

Auditor 2 — plan equivalence and source closure

Inspect:

- complete Plan V3;
- complete Plan V4;
- exact five source files;
- producer equivalence record only as supplemental evidence.

Independently derive:

- field-level normalized Plan V3→V4 equality;
- exact eight-command preservation;
- complete source-dependency chain;
- decimal maximum 10;
- generated component maximum 12;
- worst-case socket path 86;
- admitted limit 100.

Auditor 3 — V2 evidence adoption and lineage

Inspect:

- V2 audit report and inventory;
- each adopted V2 record;
- adoption record;
- supersession lineage;
- failed and superseded attempts.

Adjudicate:

- each adopted observation is supported;
- V2 verdict remains BLOCK;
- no dynamic evidence is invented;
- V3 claims only bounded composition.

Auditor 4 — provenance, artifacts, and security

Inspect every V3 capsule object, including:

- manifests;
- final inventory;
- failed-attempt directory;
- validator sources;
- mutation fixtures;
- report and closeout.

Adjudicate:

- complete membership;
- modes, links, types, and self-exclusions;
- no unexplained object or empty directory;
- no competing normative record;
- bounded sensitive-material posture;
- no supplied-root mutation.

Auditors must:

- use exact absolute operands;
- run no Git;
- run no tests or product code;
- write no files;
- make no network contact;
- create no nested auditor.

Retain via a later wrapped carrier:

- exact prompts;
- authorized operands;
- reported identities;
- start/completion order;
- complete reports;
- uncertainty and uninspected scope;
- disclosed deviation.

Return BLOCK if four distinct auditors cannot complete.

──────────────────────────────────────────────────────────────────────────────
11. INDEPENDENT V3 CONTRACT RECONSTRUCTION
──────────────────────────────────────────────────────────────────────────────

Do not import producer validator code.

Parse the V3 contract independently with:

- duplicate-key rejection;
- nonfinite-value rejection;
- canonical one-line JSON enforcement;
- exact top-level and nested key sets;
- exact types;
- exact values;
- exact ordered lists where semantic.

Require at least these exact facts.

Status:

- `proposed-effective-pending-independent-audit`

Scope:

- `supported-local-source-external-validation`

Eight authority booleans must be false:

- source authority
- product authority
- runtime authority
- deployment authority
- publication authority
- commit authority
- readiness authority
- A6 authority

Normativity:

- V3 is sole normative validation-custody writer
- projections and evidence may not redefine, override, narrow, or widen
- Strategic B remains sole B source/provenance package

Child and environment layout:

- children exactly:
  c, h, m, r, s, u
- no persistent `t`
- control and TMP lexical equality required
- control and TMP physical identity equality required
- exact parameterized environment values preserved

Allocation:

- parent `/Users/ds/Downloads`
- basename `r10b-<32-lowercase-hex>`
- 16 OS-CSPRNG bytes
- fresh material every attempt
- component-by-component no-follow traversal
- held parent descriptor and physical identity
- descriptor-relative exclusive creation
- retry only on EEXIST
- fresh collision material
- no collision-material reuse
- attempt limit 128
- non-EEXIST terminal, no retry and no fallback
- direct-parent, UID, expected GID, stable device/inode, mode-0700 identity
- forbidden adoption, rename, symlink alias, bind-mount alias, mount alias,
  pathname alias
- no counter, Git hash, latest scan, PID, prefix scan, or timestamp authority

Path budget:

- short root 57
- shared root 59
- generated prefix 2
- uint32 decimal maximum 10
- generated component maximum 12
- separators 2
- leaf `identity.sock`
- leaf bytes 13
- worst case 86
- limit 100
- admitted true

Exact source closure must contain all five exact pinned sources.

All six unsupported-host or alias-support values must be false.

Return BLOCK on an incomplete, ambiguous, inferred-only, or contradictory
field map.

──────────────────────────────────────────────────────────────────────────────
12. INDEPENDENT PLAN V3→V4 EQUIVALENCE
──────────────────────────────────────────────────────────────────────────────

Do not use the producer semantic-equivalence checker as the oracle.

Parse complete Plan V3 and Plan V4.

Normalization may remove only:

- schema/version captions;
- V2→V3 contract-reference update;
- exact source-closure references;
- explicit nonauthority references;
- lineage/status metadata;
- V3-generated record identities.

Normalization must not remove:

- command definitions;
- command order;
- argv;
- cwd semantics;
- environment parameter names or values;
- pinned tools;
- expected exits;
- pass/fail/skip identity policies;
- governing reasons;
- B source, tree, inventory, and synthetic-commit identities;
- shared `r` custody;
- authority boundaries.

Require:

- exactly eight commands;
- identical order;
- exact normalized equality;
- complete field-level difference record;
- no executable or acceptance-bearing semantic change.

The retained normalized digest

bd9802aeb6eb316a30d8582e6911e7fb38233aca24c3519cf15217eed818959f

is corroborating only.

Return BLOCK on any semantic difference. Do not replay runtime validation.

──────────────────────────────────────────────────────────────────────────────
13. INDEPENDENT SOURCE-CLOSURE AND PATH DERIVATION
──────────────────────────────────────────────────────────────────────────────

Read all five exact source files.

Trace the actual chain through:

- control-root containment;
- runtime-helper socket construction;
- Go temporary-name generation;
- unsigned uint32 decimal conversion.

Derive independently:

- shared root 59 bytes;
- separator 1;
- generated prefix 2;
- maximum decimal digits 10;
- generated component 12;
- separator 1;
- `identity.sock` 13;
- total 86;
- limit 100;
- 86 <= 100.

Establish that `src/internal/strconv/itoa.go` is an actual dependency in the
formatting chain.

Return BLOCK if another acceptance-bearing source is required but absent from
the frozen closure.

──────────────────────────────────────────────────────────────────────────────
14. V2 TECHNICAL-EVIDENCE ADOPTION
──────────────────────────────────────────────────────────────────────────────

V2 audit report:

- 92491 bytes
- SHA-256:
  e977c8ed3394f5e890a1cc1d6b0bf0067b7c430de9b264b5bd9d8028eb6c1e05

V2 audit inventory:

- 69706 bytes
- SHA-256:
  9d29fb1b53f56768fc03762fb152562368f5f3903a02dc4aa0c10d14c2292caf

Required adopted records:

- `allocation/allocator-causals.json`
  960 bytes
  SHA-256:
  6ecbd4ef58cfcc2bbdfb92625dcbaa372db1791618eba1a7197fac036143ba70

- `path-budget/independent-proof.json`
  3558 bytes
  SHA-256:
  fc46134e4d7e95ff404a2f81dace6dfed7584e3e6094d510717ef7a7fc30ee7f

- `causals/four-causal-matrix.json`
  2175630 bytes
  SHA-256:
  fd45ce5b818b465f878aa68d3894c0ee1bd8b94135b7294ae68e225bb520e035

- `materialization/exact-B.json`
  152755 bytes
  SHA-256:
  b698eab37368faac9d5bb084ed01e092c3e99aeca43e9cdf8820677ae827decc

- `validation/eight-command-summary.json`
  100416 bytes
  SHA-256:
  ab110d950c4f38df378e8ca6fc68e2f50cbbc1f17c7214c923d8406fae720fe6

- `cleanup/short-root-cleanup.json`
  2940 bytes
  SHA-256:
  e0bd40d46758c9a852ef50a692e537c344bda3c29c1bfe3d54eea1514a04ffd7

- `closing/closing-gate.json`
  106759 bytes
  SHA-256:
  29265b45e2560d26bb9202024817e8bce47ca0f3a45f93d6a0f6d1aa8dc5c44b

- `opening/manifest-closure.json`
  5833 bytes
  SHA-256:
  10e4342fe2c6fda7b0d0e95b85cca7cf354e0f897057310061698d0b260bf2b0

For each:

1. Verify exact path, size, SHA-256, schema, and relevant fields.
2. Verify the adopted V3 claim is directly supported.
3. Verify V3 does not strengthen or broaden the observation.
4. Verify no dynamic output was copied into V3 as competing authority.
5. Verify the V2 verdict remains BLOCK everywhere.
6. Verify V3 claims no new runtime execution.

Inspect raw records whenever a summary is insufficient.

Return BLOCK for an unsupported or promoted claim.

──────────────────────────────────────────────────────────────────────────────
15. FAILED ATTEMPT AND SOLE WRITER
──────────────────────────────────────────────────────────────────────────────

Inspect:

validation/failed-attempts/build-attempt-1/

Require:

- explicitly indexed and superseded;
- outside the normative namespace;
- no current record references it as authority;
- no authority claim;
- contract and plan copies clearly incomplete historical attempt bytes;
- final V3 contract remains the sole normative writer.

Return BLOCK for competing authority.

──────────────────────────────────────────────────────────────────────────────
16. INDEPENDENT MUTATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Do not import either producer validator.
Do not use producer mutation fixtures to generate cases.

Create independent in-memory baselines and at least these 50 mutations.

Allocator:
1. disable fresh CSPRNG material
2. change suffix source
3. weaken exclusive descriptor-relative creation
4. remove component no-follow traversal
5. widen retry beyond EEXIST
6. reuse collision material
7. change attempt limit
8. admit non-EEXIST fallback
9. admit latest or prefix scanning
10. admit adoption
11. admit rename into eligibility
12. admit PID authority
13. admit counter authority
14. admit timestamp authority
15. admit Git-hash authority

Nonauthority:
16–21. set each unsupported-host or alias field to true

Source closure and path budget:
22. omit `itoa.go`
23. change `itoa.go` hash
24. change `tempfile.go` hash
25. change decimal maximum
26. change component maximum
27. change worst-case path
28. change socket limit

Plan:
29. remove command
30. reorder command
31. change argv
32. remove expected identity
33. reclassify expected failure
34. reclassify expected skip
35. change B source/tree identity
36. change shared-`r` custody

Lineage and authority:
37. promote V2 BLOCK to ACCEPT
38. describe Plan V3 as previously effective
39. describe Plan V4 as current without audit
40. grant V3 source authority
41. grant publication, commit, readiness, or A6 authority

Strict parsing and provenance:
42. duplicate JSON key
43. unknown contract key
44. missing mandatory key
45. wrong field type
46. introduce a second normative V3 contract outside `contract/`
47. reference failed-attempt contract as authority
48. change an adopted V2 path or digest
49. strengthen a V2 observation
50. permit normalization to remove an acceptance-bearing Plan field

Require specific mechanism-appropriate rejection for every mutation.

Retain independent validator source and result matrix.

──────────────────────────────────────────────────────────────────────────────
17. NO RUNTIME REPLAY
──────────────────────────────────────────────────────────────────────────────

Do not execute:

- Plan V3 or Plan V4 commands;
- Go repository tests;
- product code;
- V2 allocator;
- V2 causal harnesses;
- live services.

Allowed executable work is limited to audit-owned:

- parsers;
- hashers;
- inventory builders;
- plan comparators;
- source-dependency analyzers;
- mutation validators;
- capsule and security scanners.

If Plan V4 differs semantically, return BLOCK. Do not respond by replaying
runtime validation.

──────────────────────────────────────────────────────────────────────────────
18. CAPSULE CLOSURE AND SECURITY
──────────────────────────────────────────────────────────────────────────────

Independently enumerate V3_ROOT and require:

- 12 directories including root;
- 88 physical files including manifests;
- 86 nonmanifest files;
- 98 represented entries;
- exactly two self-excluded manifests;
- no missing, extra, duplicate, empty, symlink, or special object;
- directories mode 0700;
- files regular, single-link, mode 0600.

Generate two independent manifest projections and require both to equal the
supplied manifests exactly:

- 19881 bytes
- SHA-256:
  94ae9bf8eea0c96b37dfc0aac9134e0acd727510a936621606d7923febced359

Verify the fixed final report and inventory identities.

Perform bounded sensitive-material scanning without emitting matching payload
content. Distinguish fixtures, redaction patterns, hashes, and placeholders
from plausible live secrets.

──────────────────────────────────────────────────────────────────────────────
19. AUTHORITY ADJUDICATION
──────────────────────────────────────────────────────────────────────────────

Require this split.

Strategic B owns:

- B source bytes;
- logical modes;
- byte origins;
- inventory;
- source T / Git tree;
- H→B classification;
- synthetic commit as evidence only.

V2 evidence owns only its retained dynamic observations.

V3 owns only:

- complete validation-custody contract;
- record-complete Plan V4;
- exact source closure;
- explicit nonauthority;
- semantic equivalence with V2 behavior;
- bounded V2 technical-evidence references.

Neither V2 nor V3 owns:

- publication;
- commit;
- current repository truth for B;
- product/runtime/deployment readiness;
- A6 readiness;
- semantic-successor implementation;
- orchestrator implementation;
- hostile/shared-host support;
- symlink, bind-mount, mount, or pathname-alias support.

Return BLOCK on authority drift.

──────────────────────────────────────────────────────────────────────────────
20. CLOSING AND CLEANUP
──────────────────────────────────────────────────────────────────────────────

After all correctness work and all four auditors complete, use wrapped carriers
to:

1. Recompute candidate opening/closing equality.
2. Recompute accepted Strategic B gate-root equality.
3. Recompute STRATEGIC_B_ROOT equality.
4. Recompute BLOCKED_V1_REPAIR_ROOT equality.
5. Recompute VALIDATION_CUSTODY_V2_ROOT equality.
6. Recompute V2_INDEPENDENT_AUDIT_ROOT equality.
7. Recompute VALIDATION_CUSTODY_V3_ROOT equality.
8. Reverify the five pinned source files.
9. Reconcile platform auditor interactions with retained prompts and reports.
10. Validate carrier phase-record continuity.
11. Validate child-process quartet continuity.
12. Reap all audit-owned child processes.
13. Verify no process or descriptor survivor.
14. Remove the exact audit-owned `private/` directory.
15. Make two distinct fresh `lstat` calls on that exact `private/` path.
16. Require both to return ENOENT.
17. Write the final report, platform-carrier index, process audit, cleanup
    record, and closing-equality records.

The two required ENOENT observations must target the removed `private/`
directory itself. Observations of never-created sentinel paths do not qualify.

──────────────────────────────────────────────────────────────────────────────
21. FINAL INVENTORY TEMPORAL CLOSURE
──────────────────────────────────────────────────────────────────────────────

Use one final wrapped inventory carrier after the ordinary closeout carrier.

Before returning, its payload must:

- verify every prior carrier start and outcome;
- verify every child quartet;
- verify all expected retained artifacts;
- create:

  closeout/final-audit-root-inventory.json

- retain no new temporary directory.

Because the wrapper creates the final carrier’s phase outcome only after its
payload returns, the final inventory must use exactly these two declared
temporal self-exclusions:

1. `closeout/final-audit-root-inventory.json`
2. the final inventory carrier’s own
   `provenance/carrier-NNNN.phase-outcome.json`

No other file or directory may be excluded.

The final inventory must include the final carrier’s phase-start record and
every earlier carrier outcome.

After the payload returns:

- the exact generic wrapper creates the final carrier outcome;
- no further filesystem-writing carrier is permitted;
- the platform transcript is authoritative for the final carrier’s reported
  result;
- the inline report must state that the final outcome is a transparent temporal
  self-exclusion and is not hashed by the inventory.

Do not claim that the inventory covers the final outcome bytes.

──────────────────────────────────────────────────────────────────────────────
22. PLATFORM-CARRIER INDEX
──────────────────────────────────────────────────────────────────────────────

Retain:

closeout/platform-carrier-index.json

For the bootstrap and every wrapped carrier, list:

- contiguous ordinal;
- phase;
- submitted command;
- submitted cwd;
- explicit environment;
- platform-reported result where available;
- bootstrap or phase-start record;
- phase-outcome record;
- child ordinal range;
- artifacts;
- discrepancy status.

State literally:

`carrier_launch_authority = "codex-platform-tool-transcript"`

and:

`audit_root_does_not_self_attest_parent_process_creation = true`

Do not invent platform IDs or hashes unavailable from the transcript.

Return AUDIT_PROVENANCE_MISMATCH for:

- an unindexed visible carrier;
- a target-facing carrier without a phase-start record;
- a phase-start record without a visible carrier;
- ambiguous carrier ordering;
- submitted cwd or command conflicting with its record;
- an unrecorded target-facing tool call.

The bootstrap carrier is represented by `opening/bootstrap.json`; all later
target-facing carriers require complete phase records.

──────────────────────────────────────────────────────────────────────────────
23. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return ACCEPT only when:

- opening and closing provenance qualify;
- accepted Strategic B gate passes;
- generic wrapper identity remains exact;
- carrier records are complete under the explicit temporal self-exclusion;
- child records are complete and contiguous;
- four distinct auditors complete;
- V3 contract is complete and unambiguous;
- Plan V4 is independently semantically identical to Plan V3;
- exact path-source closure is complete;
- explicit nonauthority is complete;
- V2 technical-evidence adoption is exact and bounded;
- failed attempts create no competing authority;
- independent mutation matrix passes;
- capsule closure and security pass;
- no acceptance-affecting residual finding remains.

Return BLOCK for a repairable target-level contract, plan, closure, lineage,
adoption, authority, contradiction-resistance, artifact, or security defect.

Return REJECT only for fundamental unsoundness not repairable within the
record-completion scope.

Return AUDIT_PROVENANCE_MISMATCH for:

- input drift;
- supplied-root mutation;
- missing exact input;
- failed opening or closing equality;
- unrecorded target-facing carrier;
- missing phase record;
- missing child quartet;
- unknown mutation;
- unprovable process or artifact continuity.

Do not repair anything.

──────────────────────────────────────────────────────────────────────────────
24. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return the complete audit report inline:

1. Primary verdict
2. Audit-root and bootstrap identity
3. Process-authority split
4. Generic wrapper identity
5. Child-recorder self-causals
6. Candidate and supplied-root opening identities
7. Accepted Strategic B gate adjudication
8. Four auditor identities, schedule, operands, reports, and limits
9. V3 capsule closure
10. Independently parsed V3 field map
11. Plan V3→V4 field-level equivalence
12. Exact source-dependency and 86-byte derivation
13. Explicit nonauthority adjudication
14. V2 technical-evidence adoption adjudication
15. Failed-attempt and sole-writer adjudication
16. Independent 50-case-or-greater mutation matrix
17. Confirmation no runtime replay occurred
18. Authority and nonauthority
19. Artifact and sensitive-material findings
20. Severity-ranked residual findings
21. Minority findings and parent resolution
22. Cleanup and exact-private-path ENOENT observations
23. Candidate and supplied-root closing equality
24. Complete carrier index
25. Complete child-process audit
26. Final inventory and temporal self-exclusions
27. Audit-created paths and retained membership
28. Remaining uncertainty and explicit nonclaims
29. Explicit confirmations

Required confirmations:

CANDIDATE_REPOSITORY_MUTATION_NOT_PERFORMED
CANDIDATE_INDEX_MUTATION_NOT_PERFORMED
STRATEGIC_B_GATE_ROOT_MUTATION_NOT_PERFORMED
STRATEGIC_B_SNAPSHOT_MUTATION_NOT_PERFORMED
BLOCKED_V1_REPAIR_MUTATION_NOT_PERFORMED
VALIDATION_CUSTODY_V2_CAPSULE_MUTATION_NOT_PERFORMED
V2_INDEPENDENT_AUDIT_MUTATION_NOT_PERFORMED
VALIDATION_CUSTODY_V3_CAPSULE_MUTATION_NOT_PERFORMED
OTHER_SUPPLIED_EVIDENCE_NOT_MUTATED
B_SOURCE_BYTES_NOT_MODIFIED
B_LOGICAL_MODES_NOT_MODIFIED
B_SOURCE_T_NOT_MODIFIED
B_GIT_TREE_NOT_MODIFIED
LEGACY_STRATEGIC_B_INVENTORIES_NOT_USED_AS_GATES
ACCEPTED_STRATEGIC_B_CANONICAL_GATE_USED
VALIDATION_COMMAND_SET_NOT_REDUCED
VALIDATION_COMMAND_SEMANTICS_NOT_CHANGED
PATH_SOURCE_CLOSURE_INCLUDES_PINNED_ITOA_GO
HOSTILE_SHARED_HOST_SUPPORT_EXPLICITLY_FALSE
SYMLINK_MOUNT_ALIAS_SUPPORT_EXPLICITLY_FALSE
V2_BLOCK_VERDICT_NOT_PROMOTED
RUNTIME_VALIDATION_NOT_RERUN
PERSISTENT_SUPERVISOR_NOT_USED
GENERIC_WRAPPER_RETAINED_AND_HASH_BOUND
TOP_LEVEL_CARRIERS_COMPLETELY_INDEXED
TOP_LEVEL_PHASE_RECORDS_COMPLETE_AND_CONTIGUOUS
CHILD_PROCESS_RECORDS_COMPLETE_AND_CONTIGUOUS
NO_TARGET_FACING_TOOL_CALL_BYPASSED_PHASE_RECORDING
NO_CHILD_PROCESS_BYPASSED_CHILD_RECORDER
FOUR_AUDITOR_INTERACTIONS_RECONCILED
PRIVATE_SUBTREE_REMOVED
TWO_EXACT_PRIVATE_PATH_ABSENCE_OBSERVATIONS_COMPLETED
FINAL_INVENTORY_TEMPORAL_SELF_EXCLUSIONS_EXACT
PRODUCT_OR_LIVE_SERVICE_NOT_INVOKED
NETWORK_CONTACT_NOT_PERFORMED
A6_NOT_STARTED
SEMANTIC_SUCCESSOR_NOT_IMPLEMENTED
ORCHESTRATOR_NOT_IMPLEMENTED
STAGING_NOT_PERFORMED_IN_CANDIDATE
COMMIT_NOT_PERFORMED_IN_CANDIDATE
NESTED_SUBAGENTS_CREATED: 0
```

After an `ACCEPT`, proceed to the real H→B commit gate. That later gate should:

- stage the exact accepted 36-path H→B scope;
- validate the exact staged tree using the accepted V3 custody contract;
- create exactly one commit with subject:

  `implement Remote Alpha external TLS T2A-P source`

- perform no push, upstream creation, PR, merge, installation, deployment, or
  A6 work.

Only after B is committed should the already-audited B→F governance commit be
gated.

**Sources:** Codex’s generic phase-wrapper capability report and accepted Strategic B gate-requalification report, both supplied above.

**Confidence:** 0.997 that the process prerequisites are now sufficient for the full V3 audit; 0.995 that no V3 target change is warranted; 0.98 that the explicit final-carrier temporal self-exclusion prevents the remaining closeout recursion from becoming another provenance blocker.
