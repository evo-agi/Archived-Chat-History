## Engineering assessment

This is a **fixed-input path-authority defect in the implementation prompt**, not a defect in the governing documentary package.

The documentary root’s identity and physical closure matched exactly: 50 entries, 9 directories, 41 regular files, correct topology, and correct modes. The three supplied inodes, sizes, and hashes also matched—but they belong to these actual sealed paths:

- `manifest/documentary-temporal-inventory-v2.json`
- `manifest/documentary-manifest-a-v2.json`
- `manifest/documentary-manifest-b-v2.json`

The prompt incorrectly assigned those same identities to three nonexistent generic paths:

- `closeout/temporal-final-inventory-v1.json`
- `manifest/canonical-manifest-a-v1.json`
- `manifest/canonical-manifest-b-v1.json`

Codex correctly refused to substitute paths implicitly. :chatgpt-content-reference{index="0"}

Nothing from the harness source budget was consumed:

- no harness source was created;
- no source registry closed;
- compilation never began;
- source attempts remain `0/3`;
- no matrices, synthetic lanes, compatibility replay, rehearsals, PYZ build, or requalification ran. :chatgpt-content-reference{index="1"} :chatgpt-content-reference{index="2"}

The implementation-tranche report and safety-confirmation registries were kept separate from the runtime registries, so the governing domain separation was not regressed. Their pre-source gate merely remained unqualified because the documentary package had not yet authenticated. :chatgpt-content-reference{index="3"}

The failure was cleanly handled: the build root was removed with double-ENOENT evidence, all three supplied inputs closed equal, no implementation verdict was issued, and no real audit or implementation source execution occurred. :chatgpt-content-reference{index="4"} :chatgpt-content-reference{index="5"}

### Progression decision

Proceed directly with the clean harness implementation in a fresh root, with one explicit externally authorized path correction.

Do **not** reseal or modify the governing documentary package. Its bytes and semantics are already valid. Do **not** start another documentary-contract tranche.

The replacement task must:

1. reject the three nonexistent generic paths;
2. authenticate the three exact `v2` documentary paths and identities;
3. retain an explicit path-correction record before consuming the documentary package as authority;
4. authenticate the package under its own manifest grammar;
5. preserve the full `0/3` clean-source-attempt budget;
6. embed the exact governing documentary artifacts in the final PYZ, so the later real audit does not depend on the mutable documentary package directory.

---

```text
IMPLEMENT, QUALIFY, FREEZE, AND PACKAGE A NEW CLEAN
SOURCE-EXTERNAL INDEPENDENT-AUDIT HARNESS FOR THE GENERATION-2
SCHEMA-SUBJECT RECONSTRUCTION-PARENT IMPLEMENTATION

CORRECTED GOVERNING-DOCUMENTARY-PACKAGE CLOSURE PATHS

Objective

Implement a new clean-room source-external independent-audit harness using
only these fixed authorities:

1. the exact current-authority content snapshot ZIP;
2. the exact authority JSON binding that ZIP;
3. the exact sealed governing documentary-contract package, authenticated
   through its actual v2 closure paths designated in this task.

The harness must be:

- clean-room implemented;
- fully qualified;
- source-frozen;
- requalified from frozen bytes;
- packaged as a deterministic executable Python ZIP application;
- bound by an external authority JSON;
- ready for exactly one later fresh independent audit.

Do not execute the real full independent audit in this task.

Do not adjudicate the Generation-2 implementation package.

Do not execute implementation production source.

Do not construct the authoritative current schema subject.

Do not modify any fixed input.

Do not reopen any original contaminated package directory.

Do not open any historical audit-harness, verifier, builder, repair, or audit
root.

Do not copy, patch, translate, import, execute, or use as an AST, bytecode, or
source origin any historical harness, verifier, or documentary-package tooling
source.

Do not perform another historical findings reconciliation.

Do not change the governing documentary contract’s semantics.

Do not add, remove, rename, or reinterpret its:

- five documentary domains;
- 66 runtime report rows;
- 81 runtime confirmation names;
- 15 runtime matrices;
- 595 runtime matrix cases;
- aggregate-owner classes;
- aggregate owner/consumer rules.

Do not create subagents or direct auditors.
Do not use Git or another VCS.
Do not read `.git` metadata.
Do not use the network.
Do not install dependencies.
Do not invoke product or live-service behavior.
Do not publish, deploy, externally commit, or start A6.

Use one finite parent-owned clean implementation and qualification process in
one fresh private build root.

At most three complete clean-source attempts are permitted.

The immediately preceding run stopped before source creation, source-registry
closure, or compilation. It consumed zero source attempts.

The complete 0/3 clean-source-attempt budget remains available.

Return the complete operative report inline. Artifact paths may supplement but
must not replace material identities, source provenance, contract resolution,
interface definitions, matrix results, process custody, rehearsal results,
package identities, and disposition.

Return exactly one primary verdict:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_PYZ_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_FRESH_AUDIT

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_IMPLEMENTATION_BLOCKED

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. FIXED INPUT A — CURRENT-AUTHORITY CONTENT SNAPSHOT
──────────────────────────────────────────────────────────────────────────────

CURRENT_AUTHORITY_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected identity:

- device:
  16777234
- inode:
  181651092
- mode:
  0400
- link count:
  1
- size:
  13598758
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671

CURRENT_AUTHORITY_JSON:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected identity:

- device:
  16777234
- inode:
  181651098
- mode:
  0400
- link count:
  1
- size:
  19737
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563

The containing directory is nonauthoritative.

Do not depend on:

- containing-directory inode;
- containing-directory member set;
- containing-directory mode;
- timestamps;
- `.DS_Store` posture;
- any other file in that directory.

The input authority boundary is exactly:

- authority-JSON bytes;
- bundle-ZIP bytes.

Authenticate authority JSON first.

Require:

- strict UTF-8 JSON;
- duplicate-key rejection;
- exact schema;
- exact archive path and identity;
- role count:
  8;
- content-snapshot role count:
  7;
- bounded failure-evidence role count:
  1;
- archive member count:
  479;
- `.DS_Store` archive-member count:
  0;
- deterministic Build-A/Build-B equality:
  true;
- independent bundle validation:
  passed;
- supplied-root mutation:
  false;
- implementation verdict:
  not issued;
- package verdict:
  not issued.

Authenticate the ZIP independently:

- exact size and SHA-256;
- ZIP_STORED only;
- no duplicate member;
- no absolute or traversal member;
- no directory member;
- no symlink or special member;
- no `.DS_Store`;
- raw UTF-8 byte-sorted names;
- fixed timestamp;
- fixed create-system value;
- fixed member-mode semantics;
- no archive comment;
- no member comment;
- no uncontrolled extra field.

Authenticate:

bundle/index.json
bundle/build-provenance.json
bundle/contamination-ledger.json
bundle/directory-divergence-ledger.json
bundle/role-registry.json

Index model:

- archive members:
  479;
- ordinary indexed member rows:
  478;
- the index declares its own member path;
- the authority JSON externally binds the exact index-member identity;
- no archive self-hash is required inside the archive.

Require exact index/member-set closure.

Retain:

opening/current-authority-bundle-authentication-v1.json

Any mismatch is:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
2. FIXED INPUT B — GOVERNING DOCUMENTARY CONTRACT
──────────────────────────────────────────────────────────────────────────────

DOCUMENTARY_CONTRACT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-clean-audit-harness-governing-documentary-contract-v2-pakmtp5u

Expected root identity:

- device:
  16777234
- inode:
  181874306
- mode:
  0700
- verdict:
  GEN2_CLEAN_AUDIT_HARNESS_GOVERNING_DOCUMENTARY_CONTRACT_FROZEN_READY_FOR_IMPLEMENTATION

Expected physical closure:

- total entries including root:
  50;
- directories:
  9;
- regular files:
  41;
- root row:
  exactly one;
- empty directories:
  0;
- symlinks/special objects:
  0;
- multiply linked files:
  0;
- directory/file modes:
  0700 / 0600;
- cache/bytecode:
  absent.

The following previously requested generic paths are invalid and must be
observed absent:

closeout/temporal-final-inventory-v1.json
manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

The externally designated exact current closure paths are:

manifest/documentary-temporal-inventory-v2.json
manifest/documentary-manifest-a-v2.json
manifest/documentary-manifest-b-v2.json

Corrected temporal inventory:

manifest/documentary-temporal-inventory-v2.json

Expected identity:

- device:
  16777234
- inode:
  181887815
- mode:
  0600
- link count:
  1
- size:
  13133
- SHA-256:
  31b54fd909201b993d36dbd5b0696e4efc8f99bfa3e8d7599e9152d16f0a3028

Corrected manifest A:

manifest/documentary-manifest-a-v2.json

Expected identity:

- device:
  16777234
- inode:
  181887816
- mode:
  0600
- link count:
  1
- size:
  13478
- SHA-256:
  6c61ac791a24b0453466c7e560453420047db9d4b0de21e0fac698fb4633913d

Corrected manifest B:

manifest/documentary-manifest-b-v2.json

Expected identity:

- device:
  16777234
- inode:
  181887817
- mode:
  0600
- link count:
  1
- size:
  13478
- SHA-256:
  6c61ac791a24b0453466c7e560453420047db9d4b0de21e0fac698fb4633913d

Before consuming any documentary artifact as implementation authority, retain:

opening/documentary-package-closure-path-correction-v1.json

The correction record must establish:

- all three invalid generic paths are absent;
- all three exact corrected paths exist;
- each corrected path is a single-link regular file;
- each corrected path has mode 0600;
- stable no-follow reads match the exact expected size and SHA-256;
- corrected manifest A and B are byte-identical;
- strict duplicate-key-rejecting parsing succeeds;
- the package’s exact closure grammar is recovered from the corrected records;
- the corrected records independently reproject the 50-entry final root under
  their owned grammar;
- root-row count is exactly one;
- terminal topology and modes pass;
- the terminal marker and no-write-after-seal evidence authenticate through
  current manifest membership and package records;
- no path is selected by basename, scan, first match, recency, prefix, score,
  or fallback;
- no supplied byte is changed.

Correction classification:

EXTERNALLY_AUTHORIZED_FIXED_PATH_CORRECTION

Correction effects:

- contract semantic effect:
  none;
- documentary-domain effect:
  none;
- registry effect:
  none;
- acceptance-predicate effect:
  none;
- supplied-root effect:
  none;
- source-attempt effect:
  none.

If any corrected identity or closure predicate fails, return:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_PROVENANCE_MISMATCH

Do not infer any alternative path.

Resolve current documentary roles only through:

contract/current-governing-documentary-role-registry-v2.json

Required governing roles include:

contract/documentary-domain-separation-v2.json
contract/aggregate-owner-classification-v1.json
contract/harness-runtime-report-section-registry-v1.json
contract/harness-runtime-confirmation-name-registry-v1.json
contract/harness-runtime-matrix-registry-v1.json
analysis/historical-matrix-total-645-disposition-v2.json
contract/aggregate-owner-consumer-registry-v2.json
validation/documentary-domain-and-aggregate-matrix-v2.json
validation/independent-governing-documentary-contract-validator-v2.json
analysis/documentary-contract-perspective-reconciliation-v2.json
analysis/governing-documentary-contract-status-v2.json
closeout/explicit-documentary-confirmations-v2.json

Require the status:

gen2-clean-audit-harness-governing-documentary-contract-frozen-pending-new-clean-implementation-generation

Treat bounded documentary producer/validator Python files as package tooling
only.

They are not future harness source.

They may not be copied, patched, imported, executed, translated, or used as an
AST/bytecode/source origin for the harness.

Require complete opening/closing equality for the documentary package.

Any mismatch is:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
3. PRIOR PRE-SOURCE FAILURE DISPOSITION
──────────────────────────────────────────────────────────────────────────────

The immediately preceding implementation run established:

- fixed input A authenticated;
- fixed input B root identity and physical closure matched;
- three generic closure paths were absent;
- the exact expected bytes existed at the corrected v2 paths designated above;
- source files created:
  0;
- source registries closed:
  0;
- compilation begun:
  false;
- source attempts consumed:
  0 / 3;
- matrices run:
  0;
- rehearsals run:
  0;
- provisional PYZ count:
  0;
- implementation verdict issued:
  false;
- real audit executed:
  false;
- build root removed with double ENOENT evidence;
- supplied inputs closed equal.

Retain:

opening/prior-pre-source-failure-disposition-v1.json

Classify the prior run as:

historical_pre_source_documentary_closure_path_mismatch

It is:

- noncurrent;
- nonauthoritative;
- nonresumable;
- not a source attempt;
- not a source base;
- no reduction to the 0/3 clean-source-attempt budget.

Do not open or depend on the prior failure output root unless separately
authorized by an exact fixed-input registry.

──────────────────────────────────────────────────────────────────────────────
4. GOVERNING DOCUMENTARY SEMANTICS
──────────────────────────────────────────────────────────────────────────────

Resolve, preserve, and implement exactly the five documentary domains:

1. HARNESS_RUNTIME_REPORT
2. HARNESS_RUNTIME_CONFIRMATIONS
3. HARNESS_RUNTIME_MATRICES
4. IMPLEMENTATION_TRANCHE_OPERATIVE_REPORT
5. IMPLEMENTATION_TRANCHE_SAFETY_CONFIRMATIONS

Rules:

- runtime matrices remain a distinct first-class domain;
- task-level reports do not satisfy runtime-report authority;
- task-level confirmations do not satisfy runtime-confirmation authority;
- unknown domain fails closed;
- counts derive from exact owner rows;
- no copied prose or summary count is authoritative.

Resolve and preserve the exact owner classes:

- DOCUMENTARY_REGISTRY;
- FUTURE_IMPLEMENTATION_REGISTRY;
- AUTHENTICATED_INPUT.

Only DOCUMENTARY_REGISTRY may carry `documentary_domain`.

Future source, interface, role, and PYZ-member counts use
FUTURE_IMPLEMENTATION_REGISTRY.

Current bundle role/member counts use AUTHENTICATED_INPUT.

──────────────────────────────────────────────────────────────────────────────
5. EXACT RUNTIME REGISTRIES
──────────────────────────────────────────────────────────────────────────────

Resolve these exact governing registries from the authenticated documentary
package.

A. Runtime report registry

Owner:

contract/harness-runtime-report-section-registry-v1.json

Required:

- exact ordered rows:
  R01 through R66;
- exact unique row count:
  66;
- no missing, extra, duplicate, renamed, or reordered row.

Do not restate or independently rewrite the registry in source.

Implement directly from the authenticated registry.

B. Runtime confirmation registry

Owner:

contract/harness-runtime-confirmation-name-registry-v1.json

Required:

- exact unique names:
  81;
- verdict excluded;
- no task-level confirmation appended;
- no missing or duplicate name.

Do not restate or independently rewrite the set in source.

Implement directly from the authenticated registry.

C. Runtime matrix registry

Owner:

contract/harness-runtime-matrix-registry-v1.json

Required:

- exact matrix IDs:
  B00 and D01 through D14;
- exact unique row count:
  15;
- exact derived case total:
  595;
- stale total:
  645 rejected;
- no independent matrix-total writer.

Every acceptance-bearing consumer must independently recompute the exact row
count and case total, or consume one immutable validated aggregate result tied
to all exact row identities.

The unavailable historical writer of 645 is report-only uncertainty and must
not block implementation.

──────────────────────────────────────────────────────────────────────────────
6. FRESH BUILD AND OUTPUT ROOTS
──────────────────────────────────────────────────────────────────────────────

Allocate a fresh private build root beneath `/private/tmp` using:

- tempfile.mkdtemp;
- umask:
  077;
- prefix:

ES-repair10i-v3-gen2-clean-independent-audit-harness-corrected-input-

Immediately emit:

HARNESS_BUILD_ROOT=<absolute-path>

Allocate a separate fresh output directory beneath `/Users/ds/Downloads` using:

- tempfile.mkdtemp;
- umask:
  077;
- prefix:

ES-repair10i-v3-gen2-clean-independent-audit-harness-corrected-input-output-

Immediately emit:

HARNESS_OUTPUT_ROOT=<absolute-path>

The build root is temporary and must be removed after evidence retention.

The output directory is nonauthoritative.

Successful authority-bearing outputs:

gen2-clean-source-external-independent-audit-harness-v1.pyz

gen2-clean-source-external-independent-audit-harness-v1.authority.json

Before source creation retain:

opening/bootstrap-start.json
opening/new-clean-generation-authority-v1.json
opening/fixed-input-file-registry-v1.json
opening/documentary-package-closure-path-correction-v1.json
opening/governing-documentary-contract-resolution-v1.json
opening/clean-room-source-authority-v1.json
opening/process-execution-policy-v1.json

Bind:

- implementation generation:
  new clean generation;
- previous pre-source run:
  historical, noncurrent, zero source attempts;
- source-attempt maximum:
  3;
- source attempts consumed:
  0;
- clean source initially absent:
  true;
- implementation-package adjudication:
  forbidden in this task;
- real full audit:
  forbidden in this task;
- implementation production execution:
  forbidden;
- current-subject construction:
  forbidden;
- product/runtime/target/repository/publication/deployment/A6:
  forbidden;
- same-root retry:
  false.

──────────────────────────────────────────────────────────────────────────────
7. CLEAN-ROOM SOURCE AUTHORITY
──────────────────────────────────────────────────────────────────────────────

Permitted implementation inputs:

- current-authority bundle bytes;
- current-authority JSON bytes;
- authenticated governing documentary contracts and registries;
- normative contract and current schemas inside the bundle;
- current validation specifications inside the bundle;
- terminal reconciliation findings inside the bundle;
- this task’s frozen pre-source contracts.

Forbidden source inputs:

- any prior harness source;
- any prior verifier source;
- documentary-package tooling source;
- implementation-subject source as harness source;
- transcript-reconstructed source;
- hash-reconstructed source;
- disassembly-reconstructed source;
- generated source derived from subject source.

Implementation-subject source may be:

- authenticated;
- parsed read-only;
- statically inspected during bounded qualification and later audit.

It may not be:

- imported;
- executed;
- copied into harness source;
- used as an AST/bytecode template.

Retain:

opening/clean-room-source-authority-v1.json

Require no source-text-similarity or source-recovery mechanism.

──────────────────────────────────────────────────────────────────────────────
8. HARNESS AUTHORITY AND NONAUTHORITY
──────────────────────────────────────────────────────────────────────────────

Before source creation retain:

contract/clean-independent-audit-harness-authority-v1.json
contract/clean-independent-audit-harness-operating-model-v1.json

Future `run-full-audit` authority:

- authenticate exact input ZIP and authority JSON;
- resolve all eight current roles;
- read implementation/evidence members;
- create one fresh audit root;
- perform source-external static and bounded behavioral qualification;
- retain complete process custody;
- classify direct package findings, audit findings, derivative findings, mixed
  findings, and unresolved evidence;
- issue exactly one implementation-package verdict:
  ACCEPT,
  BLOCK,
  or AUDIT_PROVENANCE_MISMATCH;
- retain a dependency graph;
- clean audit-owned fixtures;
- terminally close the audit capsule.

Nonauthority:

- implementation repair;
- contract/schema repair;
- source-package mutation;
- current-subject construction;
- product/runtime invocation;
- repository mutation;
- publication/deployment;
- A6.

Process model:

- one finite parent;
- one child recorder;
- no stdin;
- no persistent supervisor;
- no administrative continuation;
- complete stdout/stderr;
- exact exit/signal;
- reaping;
- descriptor closure;
- fixed/dynamic effect attribution;
- evidence before cleanup;
- exact cleanup-set equality;
- same-root retry forbidden.

──────────────────────────────────────────────────────────────────────────────
9. HARNESS MODES AND FUTURE INVOCATION
──────────────────────────────────────────────────────────────────────────────

Final PYZ must support exactly:

--mode qualify-harness

--mode run-full-audit

No default mode.

`qualify-harness` is permitted in this task.

`run-full-audit` is forbidden in this task.

Freeze the exact future invocation:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
-I
-S
-B
<FINAL_HARNESS_PYZ>
--mode
run-full-audit
--bundle
/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip
--bundle-authority
/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Explicit environment only:

PATH=/usr/bin:/bin
LANG=C
LC_ALL=C
PYTHONDONTWRITEBYTECODE=1
PYTHONHASHSEED=0

stdin:
DEVNULL

shell:
false

Future stdout contract:

- exactly one root locator:
  `AUDIT_ROOT=<absolute-path>\n`;
- exactly one terminal JSON/report frame;
- no progress chatter.

Future stderr:

- empty for handled terminal results.

The future `run-full-audit` invocation must not require the external
documentary-contract directory.

The final PYZ must embed exact byte-identical copies of all current governing
documentary artifacts required at runtime and self-authenticate them.

Retain:

contract/future-full-audit-invocation-v1.json

──────────────────────────────────────────────────────────────────────────────
10. DEFECT-PREVENTION REGISTRY
──────────────────────────────────────────────────────────────────────────────

Before source creation retain:

contract/clean-harness-defect-prevention-registry-v1.json

Freeze these exact surfaces:

B00 — bundle authority and member closure

D01 — attempt/status semantics

D02 — transitive freeze binding

D03 — role-layout/source-registry join

D04 — path-sensitive G01 analysis

D05 — confirmation and terminal-marker semantics

D06 — lane-specific validation adapters

D07 — typed 766/333 field-map model

D08 — constructed-subject domain and grammar

D09 — typed physical normalization

D10 — causal findings and report projection

D11 — canonical cleanup-result semantics

D12 — interface metadata-policy separation

D13 — runtime report-registry enforcement

D14 — runtime confirmation-registry enforcement

Every surface binds:

- governing bundle or documentary member;
- typed contract;
- production owner;
- qualification owner;
- independent-validator owner;
- direct tests;
- historical regression data.

D11:

- `cleanup_rows` owns cleanup evidence;
- cleanup-root sets are deterministic projections;
- no `cleanup_roots` alias.

D12 separates:

- field_alias_policy;
- path_rendering_policy;
- normalization_policy.

A path-rendering policy is not a semantic alias.

D13 derives count and order exclusively from the exact 66-row runtime registry.

D14 derives names and count exclusively from the exact 81-name runtime
registry.

──────────────────────────────────────────────────────────────────────────────
11. FULL-AUDIT PHASE PLAN
──────────────────────────────────────────────────────────────────────────────

Before source creation freeze one explicit future phase plan.

At minimum:

P00 — runtime and frozen-source self-authentication
P01 — bundle and authority authentication
P02 — role/index/member closure
P03 — governing contract/schema/validation authentication
P04 — implementation registry, attempt, freeze, and source closure
P05 — production authority and static security
P06 — E00/G00–G29 implementation crosswalk
P07 — documentary lifecycle and writer ownership
P08 — matrix registries and producer results
P09 — 946-case negative evidence
P10 — 137-case contradiction evidence
P11 — 766/333 field-map evidence
P12 — producer rehearsal A/B evidence
P13 — Attempt-2 bounded failure evidence
P14 — implementation confirmation evidence
P15 — constructed-subject evidence domain
P16 — process/failure custody
P17 — fresh audit-owned behavioral causals
P18 — fresh source-external validation
P19 — security and authority closure
P20 — findings, dependencies, and verdict
P21 — cleanup
P22 — input-file closing equality
P23 — preseal
P24 — terminal capsule closure

Every phase freezes:

- prerequisites;
- operands;
- outputs;
- authority contribution;
- pass rule;
- failure rule;
- continuation policy;
- cleanup obligations.

“Terminal” never means “passed.”

Retain:

contract/full-independent-audit-phase-plan-v1.json

──────────────────────────────────────────────────────────────────────────────
12. IMPLEMENTATION-TRANCHE DOMAIN SEPARATION
──────────────────────────────────────────────────────────────────────────────

Before source creation retain task-local registries:

contract/implementation-tranche-operative-report-registry-v1.json
contract/implementation-tranche-safety-confirmation-registry-v1.json

These belong respectively to:

- IMPLEMENTATION_TRANCHE_OPERATIVE_REPORT;
- IMPLEMENTATION_TRANCHE_SAFETY_CONFIRMATIONS.

Rules:

- their row/name counts derive from their exact task-local registries;
- their counts are not compared with runtime 66 or runtime 81;
- they may report runtime-registry compliance;
- they may not satisfy runtime report or runtime confirmation consumers;
- they are not current runtime registries;
- they are packaged, if at all, only as historical implementation evidence.

Run a pre-source domain-consistency validator.

No source creation until it passes.

──────────────────────────────────────────────────────────────────────────────
13. SOURCE ARCHITECTURE
──────────────────────────────────────────────────────────────────────────────

Define clean modular roles for:

- executable ZIP entrypoint;
- finite audit parent;
- child recorder;
- strict JSON parser;
- total JSON observer;
- ZIP authority reader;
- bundle-index resolver;
- current-role resolver;
- safe member reader/materializer;
- embedded-documentary-authority reader;
- grammar registry;
- attempt/status adapter;
- freeze validator;
- role/source joiner;
- path-sensitive phase analyzer;
- qualification-independence analyzer;
- confirmation adjudicator;
- lane adapters;
- field-map adjudicator;
- constructed-subject validator;
- physical normalizer;
- cleanup-result owner;
- process/failure custody;
- security and authority analyzer;
- causal findings reconciler;
- dependency-graph builder;
- runtime report projector;
- runtime confirmation projector;
- audit-capsule lifecycle;
- failure closeout;
- platform-capture adapter;
- qualification-only fixture drivers;
- independent validators.

Every component role maps exactly once to one clean source path.

Production audit logic must not import qualification fixtures.

Independent validators must not import:

- production modules;
- qualification modules;
- expected-result maps;
- mutation generators;
- production observers;
- production normalizers;
- production report/confirmation projectors.

Retain planned and final:

contract/production-source-registry-v1.json
contract/qualification-source-registry-v1.json
contract/independent-source-registry-v1.json

All source and role counts derive from exact registry rows using
FUTURE_IMPLEMENTATION_REGISTRY owner class.

──────────────────────────────────────────────────────────────────────────────
14. CROSS-MODULE INTERFACE REGISTRY
──────────────────────────────────────────────────────────────────────────────

Before compilation derive:

analysis/derived-cross-module-interface-set-v1.json
contract/cross-module-interface-registry-v1.json

Derive interfaces from:

- AST imports;
- direct calls;
- statically resolved attribute calls;
- constructors;
- return sites;
- serialized-record producers/readers;
- statically resolved bytecode targets.

Every interface row binds:

- interface ID;
- provider role;
- consumer role;
- source call sites;
- provider shape;
- consumer shape;
- fields/pointers;
- types;
- nullability;
- exception contract;
- authority;
- verdict applicability;
- field_alias_policy;
- path_rendering_policy;
- normalization_policy;
- direct integration test;
- independent test.

Require exact equality:

derived interface IDs
=
registered interface IDs
=
directly tested interface IDs
=
independently tested interface IDs

The interface count derives exclusively from exact registry rows.

No fixed interface count is supplied by prompt prose.

No dynamically unresolved acceptance-bearing edge is allowed.

──────────────────────────────────────────────────────────────────────────────
15. SOURCE-ATTEMPT LIMIT
──────────────────────────────────────────────────────────────────────────────

At most three complete clean-source attempts.

An attempt begins only when:

- final production registry closes;
- final qualification registry closes;
- final independent registry closes;
- compilation begins.

Any source modification after compilation begins creates a new attempt.

For every attempt retain:

- exact source identities;
- clean-room provenance;
- compilation;
- static/interface gates;
- runtime matrices reached;
- synthetic lanes reached;
- rehearsal posture;
- first blocker;
- supersession.

If Attempt 3 fails, stop.

Do not create Attempt 4.

──────────────────────────────────────────────────────────────────────────────
16. PRECOMPILATION GATES
──────────────────────────────────────────────────────────────────────────────

Before source registries close require:

- input bundle authenticated;
- documentary package authenticated through corrected v2 paths;
- exact path-correction record passed;
- exact five-domain taxonomy resolved;
- exact 66-row runtime report registry resolved;
- exact 81-name runtime confirmation registry resolved;
- exact 15/595 runtime matrix registry resolved;
- task-level report/confirmation domains separated;
- aggregate owner classes resolved;
- source architecture complete;
- all roles occupied;
- cross-module interface registry closed;
- report projector bound to runtime report owner;
- confirmation projector bound to runtime confirmation owner;
- matrix runner bound to runtime matrix owner;
- source/interface/PYZ counts use FUTURE_IMPLEMENTATION_REGISTRY;
- bundle counts use AUTHENTICATED_INPUT;
- no independent aggregate literal writer;
- no historical source origin;
- no documentary-tooling source origin;
- no Git/VCS mechanism.

Failure before registry closure consumes zero source attempts.

──────────────────────────────────────────────────────────────────────────────
17. COMPILATION AND STATIC SOURCE GATES
──────────────────────────────────────────────────────────────────────────────

Compile all sources using pinned Python:

-I -S -B

Require:

- exit zero;
- empty stderr.

Run source-external:

- AST;
- call graph;
- dataflow;
- bytecode;
- exception table;
- CFG;
- bundle-member-access crosswalk;
- embedded-documentary-member crosswalk;
- provider/consumer shape analysis;
- documentary-domain crosswalk;
- aggregate-owner/consumer crosswalk;
- report-section analysis;
- confirmation-name analysis;
- matrix-registry analysis;
- process-launch crosswalk;
- filesystem-operation crosswalk;
- terminal-operation crosswalk;
- forbidden executable/library/path analysis.

Require:

- finite flow;
- no stdin;
- no persistent supervisor;
- every child through one recorder;
- no network;
- no Git/VCS;
- no shell;
- no PATH executable lookup;
- no broad filesystem scan;
- no original-root access in future runtime;
- no unsafe ZIP extraction;
- no unregistered interface;
- no domain conflation;
- no report-count literal;
- no confirmation-count literal;
- no matrix-total literal;
- no stale 645 acceptance;
- no copied aggregate without independent validation;
- no postseal operation;
- success/failure closeout reachable.

──────────────────────────────────────────────────────────────────────────────
18. B00 AND D01–D14 RUNTIME MATRICES
──────────────────────────────────────────────────────────────────────────────

Implement exactly the runtime matrix registry from the documentary package.

Resolve exact matrix IDs and case counts from:

contract/harness-runtime-matrix-registry-v1.json

Do not restate or independently rewrite them in source.

Require:

- exact 15 matrix IDs;
- exact per-row case counts;
- exact derived total:
  595;
- one serialized result per matrix row;
- unique case names within each matrix;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

Required surfaces:

B00 — bundle authority/member closure

D01 — attempt/status semantics

D02 — freeze binding

D03 — role/source join

D04 — G01 path-sensitive reachability

D05 — confirmation/terminal-marker semantics

D06 — lane-specific adapters

D07 — 766/333 field-map semantics

D08 — constructed-subject domain

D09 — physical normalization

D10 — causal findings ownership

D11 — canonical cleanup result

D12 — interface policy separation

D13 — exact runtime report registry

D14 — exact runtime confirmation registry

D13 must reject:

- missing row;
- extra row;
- duplicate ID;
- reorder;
- rename;
- task-report substitution;
- copied count inconsistent with rows.

D14 must reject:

- missing name;
- extra name;
- duplicate name;
- appended verdict;
- task-confirmation substitution;
- copied count inconsistent with names.

Every matrix-suite consumer independently derives:

- matrix count:
  15;
- matrix case total:
  595.

645 may appear only in historical regression fixtures and documentary
disposition records.

It must never be accepted as a current aggregate.

──────────────────────────────────────────────────────────────────────────────
19. PROCESS-CUSTODY QUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Exercise:

- nonexistent executable;
- zero/empty streams;
- nonzero/both streams;
- timeout/kill/reap;
- one child;
- multiple children;
- empty ledger;
- lost stdout;
- lost stderr;
- unregistered dynamic effect;
- zero/one/multiple-root cleanup;
- evidence before cleanup;
- separate stdout/stderr/exit/signal platform capture.

Require:

- complete prelaunch;
- exact argv/cwd/environment;
- complete streams;
- exit or signal;
- reaping;
- descriptor closure;
- effect attribution;
- cleanup equality;
- double ENOENT;
- zero survivors.

──────────────────────────────────────────────────────────────────────────────
20. SYNTHETIC END-TO-END AUDIT LANES
──────────────────────────────────────────────────────────────────────────────

Create source-independent synthetic authority bundles.

Run:

A. exact implementation ACCEPT
B. substantive implementation BLOCK
C. audit provenance mismatch
D. two physically distinct semantically equal constructed subjects
E. wrong-registry and same-length alternative matrix corpora
F. incomplete bounded failure-evidence subset
G. report, confirmation, aggregate, and terminal-marker mutations

Require exact:

- verdict;
- findings;
- finding ownership;
- dependency graph;
- phase results;
- process custody;
- cleanup;
- runtime report sections;
- runtime confirmation name set;
- runtime matrix result set;
- audit-capsule terminal closure;
- no postseal operation.

──────────────────────────────────────────────────────────────────────────────
21. BOUNDED REAL-BUNDLE COMPATIBILITY REPLAY
──────────────────────────────────────────────────────────────────────────────

Against the exact current bundle, without executing implementation source and
without issuing a package verdict:

- authenticate bundle and authority;
- resolve all eight roles;
- resolve implementation Attempts 1–3;
- validate source freeze and frozen requalification;
- resolve current production and qualification component roles where evidence
  establishes them;
- path-sensitively adjudicate G01;
- audit the 125 implementation confirmations;
- parse all current matrix lanes;
- parse 946 negative cases;
- parse 137 contradiction cases;
- parse the 766/333 field map;
- parse producer rehearsal A/B under subject grammar;
- normalize producer rehearsals to zero unexplained differences;
- authenticate Attempt-2 bounded failure evidence;
- derive the exact future full-audit invocation;
- emit no package or implementation verdict.

Retain:

validation/current-bundle-bounded-compatibility-replay-v1.json

──────────────────────────────────────────────────────────────────────────────
22. TWO COMPLETE HARNESS REHEARSALS
──────────────────────────────────────────────────────────────────────────────

Build provisional executable PYZ files from identical candidate source bytes.

Run two physically distinct complete rehearsals against independent synthetic
authority bundles.

Each rehearsal must complete:

- B00 and D01–D14;
- process custody;
- synthetic ACCEPT;
- synthetic BLOCK;
- synthetic provenance failure;
- synthetic subject pair;
- bounded real-bundle compatibility replay;
- exact runtime report generation;
- exact runtime confirmation generation;
- exact runtime matrix evidence;
- audit-capsule terminal closure;
- cleanup.

Retain before cleanup:

- provisional PYZ identity;
- synthetic input identities;
- process records and streams;
- audit-root identity;
- complete audit-capsule inventory;
- result identities;
- terminal identities;
- cleanup records.

Require both rehearsals to use byte-identical provisional PYZs.

Normalize only explicit physical values.

Require zero unexplained semantic difference.

Remove rehearsal fixtures and capsules only after evidence retention and
independent validation, with two ENOENT observations.

──────────────────────────────────────────────────────────────────────────────
23. INDEPENDENT HARNESS VALIDATORS
──────────────────────────────────────────────────────────────────────────────

Independent validators may not import:

- candidate production modules;
- candidate qualification modules;
- fixture generators;
- expected-result maps;
- production observers;
- production normalizers;
- runtime report projector;
- runtime confirmation projector.

They independently verify:

- clean-room provenance;
- input bundle and authority;
- corrected documentary-package closure paths;
- documentary package and role resolution;
- five-domain separation;
- aggregate owner classes;
- exact 66 runtime report rows;
- exact 81 runtime confirmation names;
- exact 15/595 runtime matrix evidence;
- source registries;
- phase plan;
- B00 and D01–D14;
- process custody;
- synthetic lanes;
- compatibility replay;
- both rehearsals;
- normalized comparison;
- evidence retention;
- cleanup;
- source-freeze linkage;
- final PYZ member closure;
- final authority JSON.

Summary Booleans alone are insufficient.

Require zero errors.

──────────────────────────────────────────────────────────────────────────────
24. SOURCE FREEZE
──────────────────────────────────────────────────────────────────────────────

Freeze source only after:

- pre-source contracts pass;
- compilation/static gates pass;
- B00 and D01–D14 pass;
- process custody passes;
- synthetic lanes pass;
- compatibility replay passes;
- both rehearsals pass;
- normalized comparison passes;
- independent validators pass;
- evidence retention/cleanup passes;
- input bundle, authority JSON, and documentary package remain unchanged.

Retain:

opening/clean-independent-audit-harness-source-freeze-v1.json

Bind:

- final production registry;
- final qualification registry;
- final independent registry;
- exact source identities;
- exact documentary-package root and corrected closure-file identities;
- five-domain contract identity;
- report/confirmation/matrix registry identities;
- aggregate owner/consumer registry identity;
- exact 15 matrix-result identities;
- exact derived total 595;
- process custody;
- synthetic lanes;
- compatibility replay;
- rehearsal identities;
- cleanup;
- future invocation;
- input identities;
- full real audit not executed;
- later source modification:
  forbidden.

No independently written aggregate total is permitted.

Reopen every source no-follow.

Do not modify source afterward.

──────────────────────────────────────────────────────────────────────────────
25. DETERMINISTIC EXECUTABLE PYZ
──────────────────────────────────────────────────────────────────────────────

Create a deterministic executable Python ZIP application.

Final name:

gen2-clean-source-external-independent-audit-harness-v1.pyz

Required members include:

- `__main__.py`;
- frozen production modules;
- frozen runtime contracts;
- exact runtime report registry;
- exact runtime confirmation registry;
- exact runtime matrix registry;
- aggregate owner/consumer registry;
- embedded exact current governing documentary artifacts;
- bundle/input contract;
- phase plan;
- source registries;
- source-freeze record;
- qualification evidence required for future self-authentication;
- package status;
- operative report.

Do not include:

- documentary-package tooling Python;
- disposable fixture bytes;
- synthetic payloads;
- caches;
- bytecode;
- `.DS_Store`;
- absolute filesystem objects;
- ZIP directory members;
- superseded source attempts except bounded lineage records expressly required
  by authority.

ZIP requirements:

- ZIP_STORED;
- raw UTF-8 sorted member names;
- fixed timestamp:
  1980-01-01T00:00:00;
- create_system:
  3;
- fixed member permissions:
  0600;
- no duplicate name;
- no comment;
- no uncontrolled extra field;
- no unsafe name;
- no symlink or special attribute.

Build independently twice:

- PYZ Build A;
- PYZ Build B.

Require exact byte equality.

The final member count derives only from the exact member registry using
FUTURE_IMPLEMENTATION_REGISTRY owner class.

──────────────────────────────────────────────────────────────────────────────
26. FINAL HARNESS AUTHORITY JSON
──────────────────────────────────────────────────────────────────────────────

Create:

gen2-clean-source-external-independent-audit-harness-v1.authority.json

Bind:

- harness ID/version;
- exact PYZ path and identity;
- PYZ member count derived from member registry;
- `__main__.py` identity;
- original documentary-package root identity;
- corrected documentary temporal/A/B identities;
- embedded governing-document member identities;
- five-domain contract identity;
- runtime report/confirmation/matrix registry identities;
- aggregate owner/consumer registry;
- source registries;
- source-freeze identity;
- qualification results;
- rehearsal identities;
- future invocation;
- current input bundle path and identity;
- current input authority path and identity;
- modes:
  qualify-harness,
  run-full-audit;
- full real audit executed:
  false;
- implementation verdict:
  not issued;
- current subject constructed:
  false.

Every aggregate in the authority JSON must be recomputed from its governing
owner.

Set both final files to mode `0400` after successful final validation.

The containing output directory is nonauthoritative.

──────────────────────────────────────────────────────────────────────────────
27. FROZEN-PYZ REQUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Run exact final PYZ:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
-I
-S
-B
<FINAL_HARNESS_PYZ>
--mode
qualify-harness
--bundle
/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip
--bundle-authority
/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json
--documentary-contract-root
/Users/ds/Downloads/ES-repair10i-v3-clean-audit-harness-governing-documentary-contract-v2-pakmtp5u

Require:

- exit zero;
- empty stderr;
- exact guarded qualification record;
- PYZ self-authentication;
- bundle authentication;
- documentary package authentication through corrected v2 paths;
- exact five-domain contract;
- exact runtime registries;
- exact derived values:
  - report rows 66;
  - confirmation names 81;
  - matrix rows 15;
  - matrix cases 595;
- embedded documentary-byte equality;
- source-freeze linkage;
- B00/D01–D14 identity linkage;
- process-custody linkage;
- synthetic-lane linkage;
- compatibility-replay linkage;
- rehearsal-source linkage;
- independent-validator linkage;
- final member closure;
- authority-JSON coherence;
- no `run-full-audit` execution;
- no implementation verdict.

Identity linkage alone is insufficient.

The requalification independently recomputes all governed aggregates.

Retain:

validation/frozen-pyz-requalification-v1.json

The future real `run-full-audit` invocation must not require
`--documentary-contract-root`; it uses the embedded authenticated governing
documentary artifacts.

──────────────────────────────────────────────────────────────────────────────
28. FINAL CROSS-DOCUMENT RECONCILIATION
──────────────────────────────────────────────────────────────────────────────

Before success independently verify across:

- documentary package;
- embedded documentary artifacts;
- source freeze;
- qualification result;
- independent-validator result;
- runtime report;
- runtime confirmations;
- runtime matrix results;
- PYZ member registry;
- final authority JSON;
- frozen-PYZ requalification.

Require:

- documentary-domain count:
  5;
- runtime report rows:
  66;
- runtime confirmations:
  81;
- runtime matrix rows:
  15;
- runtime matrix cases:
  595;
- stale 645 accepted:
  false;
- task-report rows compared with runtime rows:
  false;
- task confirmations compared with runtime confirmations:
  false;
- source counts match source registries;
- interface count matches interface registry;
- member count matches member registry;
- bundle role/member counts match authenticated input;
- corrected documentary closure paths match original fixed input;
- embedded governing-document bytes match original package members.

Retain:

validation/final-cross-document-governance-reconciliation-v1.json

Require zero errors.

──────────────────────────────────────────────────────────────────────────────
29. INPUT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat exact no-follow identity checks for:

- current authority bundle;
- current authority JSON.

Repeat complete no-follow inventory for the documentary-contract root.

Require exact opening/closing equality.

Do not open original contaminated package roots.

──────────────────────────────────────────────────────────────────────────────
30. BUILD AND REHEARSAL CLEANUP
──────────────────────────────────────────────────────────────────────────────

Before removing any build, fixture, or rehearsal root retain:

- root identity;
- complete inventory;
- process streams;
- validation results;
- failure outcome when applicable.

Revalidate identity, remove the exact root, and observe ENOENT twice.

Require:

created roots
=
inventoried roots
=
evidence-retained roots
=
cleanup rows
=
twice-absent roots

Do not remove successful final output files.

──────────────────────────────────────────────────────────────────────────────
31. FAILURE CLOSEOUT
──────────────────────────────────────────────────────────────────────────────

On failure retain:

- source attempt or pre-attempt posture;
- first blocker;
- structured exception;
- process ledger and streams;
- partial build inventory;
- indispensable evidence;
- cleanup;
- input closing equality;
- source-freeze posture;
- package posture;
- same-root retry false.

Do not create authoritative final outputs on failure.

If provisional final files exist:

- retain identities;
- classify nonauthoritative;
- remove after evidence retention;
- observe ENOENT twice.

Return provenance mismatch for:

- fixed-input mismatch;
- corrected-path identity mismatch;
- documentary-package closure mismatch;
- source-provenance violation;
- historical or documentary-tooling source use;
- Git/VCS use;
- unregistered effect;
- evidence loss;
- cleanup inequality;
- input closing inequality;
- source drift after freeze;
- final PYZ/authority mismatch;
- post-finalization mutation.

──────────────────────────────────────────────────────────────────────────────
32. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_PYZ_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_FRESH_AUDIT

only when:

- current bundle and authority authenticate;
- documentary root identity and physical closure authenticate;
- invalid generic documentary paths are rejected;
- exact corrected v2 closure paths authenticate;
- documentary terminal closure authenticates;
- exact five-domain semantics resolve;
- exact runtime registries resolve;
- clean-room source authority passes;
- source qualifies within three attempts;
- compilation/static gates pass;
- exact B00/D01–D14 suite passes at 15/595;
- process custody passes;
- synthetic lanes pass;
- compatibility replay passes without verdict;
- both rehearsals pass;
- rehearsal comparison passes;
- independent validators pass;
- evidence retention and cleanup pass;
- source freezes;
- deterministic PYZ A/B match;
- authority JSON binds the PYZ;
- frozen-PYZ requalification passes;
- final cross-document reconciliation passes;
- all fixed inputs close equal;
- final files are mode 0400;
- real full audit remains unexecuted;
- no implementation verdict is issued.

Return:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_IMPLEMENTATION_BLOCKED

when:

- source cannot qualify within three attempts;
- a governed semantic remains unresolved;
- a matrix, synthetic lane, rehearsal, validator, or requalification fails
  without a provenance failure;
- implementation would require changing the governing documentary contract or
  current-authority bundle.

Return:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_PROVENANCE_MISMATCH

for the provenance failures defined in Section 31.

──────────────────────────────────────────────────────────────────────────────
33. REQUIRED INLINE OPERATIVE REPORT
──────────────────────────────────────────────────────────────────────────────

Create a task-local implementation-tranche operative-report registry from these
exact ordered rows.

This registry belongs to:

IMPLEMENTATION_TRANCHE_OPERATIVE_REPORT

Its count derives only from these rows.

It is not compared with runtime report count 66.

Required sections:

1. Primary verdict
2. Fresh build-root identity
3. Fresh output-root identity
4. Input-bundle identity
5. Input-authority identity
6. Documentary-package root identity
7. Invalid generic documentary paths
8. Corrected documentary closure-path authentication
9. Documentary terminal-closure authentication
10. Input authentication
11. Documentary-role resolution
12. Five-domain resolution
13. Runtime-report registry resolution
14. Runtime-confirmation registry resolution
15. Runtime-matrix registry resolution
16. Aggregate-owner resolution
17. Prior pre-source failure disposition
18. Clean-room source authority
19. Harness authority and nonauthority
20. Mode and future-invocation contract
21. Defect-prevention registry
22. Full-audit phase plan
23. Implementation-tranche domain separation
24. Source architecture
25. Source-attempt ledger
26. Final production-source registry
27. Final qualification-source registry
28. Final independent-source registry
29. Cross-module interface registry
30. Precompilation gate
31. Compilation/static gates
32. B00 result
33. D01 result
34. D02 result
35. D03 result
36. D04 result
37. D05 result
38. D06 result
39. D07 result
40. D08 result
41. D09 result
42. D10 result
43. D11 result
44. D12 result
45. D13 result
46. D14 result
47. Exact matrix aggregate result
48. Process-custody qualification
49. Synthetic ACCEPT lane
50. Synthetic BLOCK lane
51. Synthetic provenance-failure lane
52. Synthetic subject-pair lane
53. Bounded compatibility replay
54. Harness rehearsal A
55. Harness rehearsal B
56. Rehearsal PYZ equality
57. Rehearsal semantic comparison
58. Independent validators
59. Evidence retention
60. Cleanup
61. Source freeze
62. PYZ Build A
63. PYZ Build B
64. PYZ equality
65. PYZ member closure
66. Final authority-JSON identity
67. Frozen-PYZ requalification
68. Final cross-document governance reconciliation
69. Confirmation full audit not executed
70. Confirmation implementation verdict not issued
71. Harness-package status
72. Input closing equality
73. Failure-closeout capability and use
74. Final PYZ path and identity
75. Final authority path and identity
76. Remaining uncertainty and nonclaims
77. Task-level safety-confirmation registry

Derive the task report count from these exact rows.

Do not compare it with runtime report count 66.

──────────────────────────────────────────────────────────────────────────────
34. TASK-LEVEL SAFETY CONFIRMATIONS
──────────────────────────────────────────────────────────────────────────────

Freeze an exact task-local confirmation-name registry belonging to:

IMPLEMENTATION_TRANCHE_SAFETY_CONFIRMATIONS

Its count derives from its exact unique names.

Do not compare it with runtime confirmation count 81.

Required exact names:

CURRENT_AUTHORITY_BUNDLE_IDENTITY_MATCHED
CURRENT_AUTHORITY_JSON_IDENTITY_MATCHED
GOVERNING_DOCUMENTARY_ROOT_IDENTITY_MATCHED
INVALID_DOCUMENTARY_GENERIC_PATHS_REJECTED
CORRECTED_DOCUMENTARY_TEMPORAL_PATH_AUTHENTICATED
CORRECTED_DOCUMENTARY_MANIFEST_A_PATH_AUTHENTICATED
CORRECTED_DOCUMENTARY_MANIFEST_B_PATH_AUTHENTICATED
CORRECTED_DOCUMENTARY_MANIFESTS_BYTE_IDENTICAL
DOCUMENTARY_CLOSURE_PATH_CORRECTION_SCOPE_BOUNDED
GOVERNING_DOCUMENTARY_PACKAGE_AUTHENTICATED
FIVE_DOCUMENTARY_DOMAINS_RESOLVED
RUNTIME_REPORT_REGISTRY_RESOLVED
RUNTIME_CONFIRMATION_REGISTRY_RESOLVED
RUNTIME_MATRIX_REGISTRY_RESOLVED
RUNTIME_REPORT_ROW_COUNT_66_DERIVED
RUNTIME_CONFIRMATION_NAME_COUNT_81_DERIVED
RUNTIME_MATRIX_COUNT_15_DERIVED
RUNTIME_MATRIX_CASE_TOTAL_595_DERIVED
STALE_MATRIX_TOTAL_645_REJECTED
PRIOR_PRE_SOURCE_FAILURE_CONSUMED_ZERO_SOURCE_ATTEMPTS
FULL_THREE_ATTEMPT_BUDGET_PRESERVED
CLEAN_ROOM_SOURCE_AUTHORITY_ESTABLISHED
SOURCE_ATTEMPT_LIMIT_RESPECTED
FINAL_SOURCE_REGISTRIES_COMPLETE
ALL_SOURCES_COMPILED
STATIC_SOURCE_GATES_PASSED
BUNDLE_AUTHORITY_MATRIX_PASSED
D01_D14_MATRICES_PASSED
PROCESS_CUSTODY_QUALIFICATION_PASSED
SYNTHETIC_ACCEPTED_PACKAGE_AUDIT_PASSED
SYNTHETIC_BLOCK_PACKAGE_AUDIT_PASSED
SYNTHETIC_PROVENANCE_FAILURE_AUDIT_PASSED
SYNTHETIC_CONSTRUCTED_SUBJECT_PAIR_PASSED
BOUNDED_COMPATIBILITY_REPLAY_PASSED
BOUNDED_COMPATIBILITY_REPLAY_EMITTED_NO_PACKAGE_VERDICT
COMPLETE_HARNESS_REHEARSAL_A_PASSED
COMPLETE_HARNESS_REHEARSAL_B_PASSED
TWO_HARNESS_REHEARSAL_PYZS_BYTE_IDENTICAL
TWO_HARNESS_REHEARSALS_NORMALIZED_EQUAL
INDEPENDENT_HARNESS_VALIDATORS_PASSED
EVIDENCE_RETAINED_BEFORE_CLEANUP
HARNESS_OWNED_CLEANUP_SET_EQUALITY_PASSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
HARNESS_SOURCE_FROZEN
HARNESS_SOURCE_NOT_MODIFIED_AFTER_FREEZE
PYZ_BUILD_A_B_BYTES_IDENTICAL
FINAL_PYZ_MEMBER_SET_CLOSED
FINAL_AUTHORITY_JSON_BINDS_PYZ
FROZEN_PYZ_REQUALIFICATION_PASSED
FINAL_CROSS_DOCUMENT_GOVERNANCE_RECONCILIATION_PASSED
FULL_INDEPENDENT_AUDIT_NOT_EXECUTED
IMPLEMENTATION_PACKAGE_NOT_READJUDICATED
IMPLEMENTATION_PRODUCTION_SOURCE_NOT_EXECUTED
CURRENT_SCHEMA_SUBJECT_NOT_CONSTRUCTED
INPUT_BUNDLE_CLOSING_EQUALITY_PASSED
INPUT_AUTHORITY_JSON_CLOSING_EQUALITY_PASSED
DOCUMENTARY_PACKAGE_CLOSING_EQUALITY_PASSED
FINAL_PYZ_CREATED
FINAL_PYZ_MODE_0400
FINAL_PYZ_IDENTITY_VERIFIED
FINAL_AUTHORITY_JSON_CREATED
FINAL_AUTHORITY_JSON_MODE_0400
FINAL_AUTHORITY_JSON_IDENTITY_VERIFIED
CONTAINING_DIRECTORY_NOT_USED_AS_AUTHORITY
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

After:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_PYZ_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_FRESH_AUDIT

the next tranche is exactly one fresh independent audit of the unchanged
Generation-2 implementation evidence contained in the current-authority bundle,
using:

- the exact final harness PYZ;
- the exact final harness authority JSON;
- the exact current-authority bundle;
- the exact current-authority bundle authority JSON.

The future audit must not depend on the external documentary-contract root.
It must consume the exact governing documentary artifacts embedded in the
frozen PYZ.

Do not combine that audit with this harness-implementation task.

Do not construct the authoritative current schema subject until the later
fresh audit accepts the implementation package.
```

### Sources

The documentary root and physical closure matched, but the previous prompt attached the correct identities to three nonexistent paths; the exact bytes instead reside at the three documentary `v2` paths identified above. :chatgpt-content-reference{index="6"}

No harness source was created, no registry closed, compilation never began, and the full three-attempt source budget remains available. :chatgpt-content-reference{index="7"}

The task-level report and safety domains remained separate, all indispensable evidence was retained, the build root was removed with double-ENOENT evidence, and all fixed inputs closed equal. :chatgpt-content-reference{index="8"} :chatgpt-content-reference{index="9"} :chatgpt-content-reference{index="10"}

**Confidence:** 0.999 that no harness source attempt or implementation-package adjudication occurred; 0.999 that the sole blocker was the three incorrect documentary closure paths; 0.995 that no documentary reseal is required; 0.98 that embedding the governing documentary artifacts in the final PYZ removes the remaining runtime dependency on the mutable documentary directory.

The current attachment was readable. Some earlier project uploads have expired; re-upload them only if a later task needs their original bytes rather than the retained identities and reports.
