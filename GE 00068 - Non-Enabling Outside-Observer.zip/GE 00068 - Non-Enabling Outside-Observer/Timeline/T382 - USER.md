Here is Codex's response:

PREFLIGHT\_PROVENANCE\_MISMATCH

The corrected digest authenticated successfully, but this retry is invalid for two process-provenance reasons:

- I used tooling from the prior failed retry root beyond the permitted lineage-only observation.
- One diagnostic used an unpinned Python invocation without the required `-I -S -B` flags.

The fresh qualification also stopped because its aggregate incorrectly treated the factual value `payload_imported: false` as a failed check. I did not overwrite or remove those nonterminal records.

### Inline report

1. **Verdict:** The verdict above.
2. **Fresh root:** `/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-package-metadata-repair-u3ey9kca`; device/inode `16777234/180345674`, mode `0700`. Unsealed and nonauthoritative.
3. **Predecessor:** Root identity, 74-entry closure, temporal inventory, matching manifests, and independent reprojection authenticated.
4. **Historical roots:** All opened roots passed closing equality.
5. **Predecessor exports:** Seven supplied identities authenticated during predecessor preflight.
6. **Successor exports:** Six byte-identical files and a root-rebound plan were constructed, but never frozen or promoted.
7. **Plan delta:** Only `/payload/frozen_source_identity/package_path` changed.
8. **Generated metadata:** Root contract V2 and export registry V2 exist; qualification result V2 and freeze V3 were not created.
9. **Consumer registry:** Not finalized.
10. **Four-pointer resolution:** Not run.
11. **Dependency graph V2:** Not generated.
12. **Root contract V2:** Generated but nonterminal.
13. **Export registry V2:** Generated but nonterminal.
14. **Qualification result V2:** Not generated.
15. **Metadata mutation matrix:** Not run.
16. **Independent metadata validator:** Not run.
17. **Root-rebinding matrix V2:** Generated and passed locally.
18. **Two-root determinism:** Generated and passed locally.
19. **Support qualification:** Passed locally.
20. **Finalizer qualification:** Failed at aggregation.
21. **Carrier materializations:** Generated locally; not promoted.
22. **Finalizer causals:** Individual process outcomes matched expectations, but the aggregate record failed.
23. **Freeze V3:** Not generated.
24. **Metadata coherence:** Not evaluated.
25. **Frozen requalification:** Not run.
26. **Historical lineage:** Not finalized.
27. **Immobility:** No package authority established.
28. **Cache posture:** Temporary qualification and diagnostic caches were removed; no matching temporary roots remain.
29. **Closing equality:** Passed for predecessor, failed package, blocked attempt, reconciliation, target, V2 audit, pinned Python, and prior retry root.
30. **Temporal inventory:** Not generated.
31. **Manifest A:** Not generated.
32. **Manifest B:** Not generated.
33. **Terminal reprojection:** Not run.
34. **Terminal membership/modes:** Not established.
35. **No-write-after-closure:** Not applicable; no closure occurred.
36. **Real target audit:** Not executed.
37. **Nonclaims:** No package authority, target verdict, runtime validation, deployment, publication, or A6 claim.
38. **Explicit confirmations:** Only the confirmations below are asserted.

### Correction provenance

- Malformed historical digest: `f1e0882854891c2bb8f851309bf8d6f5eb97c13e482809009b75e7aeb31d3e`
- Corrected digest: `f1e0882854891c2bb8f851309bf9e8d6f5eb97c13e482809009b75e7aeb31d3e`
- Size: `8350`
- Manifest A, manifest B, and independent no-follow observation agreed exactly.
- Correction record: [supplied-identity-correction-v1.json](/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-package-metadata-repair-u3ey9kca/opening/supplied-identity-correction-v1.json), size `2319`, SHA-256 `a23df902902d9efca2443da3e3175b1e0b697546d45d06c8020915fca21bb093`.
- Only the malformed fixed identity was corrected; the correction caused no semantic-export or acceptance-rule change.

Confirmed:
```
MALFORMED_HISTORICAL_DIGEST_REJECTED
CORRECTED_DIGEST_EXACTLY_64_LOWERCASE_HEX
CORRECTED_DIGEST_AUTHENTICATED_BY_MANIFEST_A
CORRECTED_DIGEST_AUTHENTICATED_BY_MANIFEST_B
CORRECTED_DIGEST_INDEPENDENTLY_RECOMPUTED
CORRECTION_SCOPE_ONE_FIXED_IDENTITY_ONLY
PRIOR_FAILED_RETRY_ROOT_MUTATION_NOT_PERFORMED
NO_SEMANTIC_CHANGE_FROM_IDENTITY_CORRECTION
SEALED_PREDECESSOR_ROOT_MUTATION_NOT_PERFORMED
FAILED_UNSEALED_PACKAGE_ROOT_MUTATION_NOT_PERFORMED
BLOCKED_CLOSURE_ATTEMPT_ROOT_MUTATION_NOT_PERFORMED
RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
REAL_TARGET_AUDIT_NOT_EXECUTED
NO_GIT_INVOCATION
NO_NETWORK_CONTACT
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

`PRIOR_FAILED_RETRY_ROOT_NOT_RESUMED` cannot be confirmed. No readiness or terminal-closure confirmation is claimed.
