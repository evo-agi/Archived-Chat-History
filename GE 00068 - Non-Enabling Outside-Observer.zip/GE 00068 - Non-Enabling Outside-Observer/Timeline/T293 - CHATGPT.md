## Assessment

The qualification root is correctly **nonqualifying**, but `WRAPPED_CARRIER_LAUNCHER_UNAVAILABLE` is broader than the evidence supports.

Carrier 0002 established several important facts:

- The launcher supplied the previously omitted `--expected-wrapper-sha256`.
- Launcher-side CLI conformance passed.
- The launcher reached the exact accepted wrapper.
- The wrapper parsed the invocation, created complete phase records, loaded the payload, and executed it.
- The payload—not the wrapper parser or process launch—reported failure.

That proves the interpreter → launcher → same-process wrapper → payload path is at least operational through payload execution. What remains unknown is **which payload assertion failed and whether that assertion reflects**:

- an actual launcher defect;
- an incomplete launch contract;
- an incorrect self-check oracle;
- or insufficient retained evidence for something such as same-PID execution.

The response does not identify the failed predicate. Changing the launcher or rerunning another complete qualification now would be guesswork.

The critical path is a small, read-only root-cause reconciliation of the immutable qualification root. Do not retry the full V3 audit or implement another launcher yet.

## Codex prompt

```text
READ-ONLY ROOT-CAUSE RECONCILIATION —
WRAPPED-CARRIER LAUNCHER CARRIER 0002 PAYLOAD FAILURE

This is a bounded, parent-only, read-only failure reconciliation.

Do not repair anything.
Do not mutate any supplied root.
Do not modify the launcher, wrapper, contracts, request, payload, or records.
Do not retry Carrier 0002.
Do not execute the launcher or wrapper.
Do not run the full launcher qualification.
Do not run the full V3 audit.
Do not inspect any repository, candidate, Strategic B root, V1/V2/V3 capsule,
or unrelated evidence root.
Do not run Git, repository tests, product code, or network operations.
Do not create subagents.

Return exactly one primary verdict:

LAUNCHER_FAILURE_RECONCILED_PAYLOAD_ORACLE_DEFECT
LAUNCHER_FAILURE_RECONCILED_LAUNCHER_DEFECT
LAUNCHER_FAILURE_RECONCILED_CONTRACT_DEFECT
LAUNCHER_FAILURE_RECONCILED_EVIDENCE_INSUFFICIENT
RECONCILIATION_PROVENANCE_MISMATCH

OBJECTIVE

Determine the exact assertion or predicate that caused Carrier 0002’s valid
qualification payload to report failure after the corrected launcher had
successfully reached the accepted wrapper and the wrapper had executed the
payload.

Distinguish rigorously among:

1. payload-oracle defect:
   the payload expected something not required by the qualification contract,
   computed a required fact incorrectly, or tested it before sufficient
   evidence existed;

2. launcher defect:
   the launcher failed a behavior actually required by the qualification
   brief;

3. contract defect:
   the launch contract, request contract, or reconstructed wrapper CLI omitted,
   contradicted, or ambiguously specified a required behavior;

4. evidence insufficiency:
   the retained artifacts cannot establish whether a required behavior passed
   or failed.

Do not infer availability or unavailability from the root’s primary verdict.
Adjudicate from the retained bytes.

──────────────────────────────────────────────────────────────────────────────
1. EXACT INPUTS
──────────────────────────────────────────────────────────────────────────────

QUALIFICATION_ROOT:

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualification-kb6zyh_o

Treat it as immutable, incomplete, and nonqualifying.

ACCEPTED_GENERIC_WRAPPER_ROOT:

/Users/ds/Downloads/ES-repair10i-generic-phase-wrapper-probe-sj1gm5ns

Inspect only the exact accepted wrapper and the bounded successful carrier
records needed to establish its real CLI and phase behavior.

Accepted wrapper:

provenance/phase_runner.py

Required identity:

- size:
  15300 bytes
- SHA-256:
  6e911ca17dedc6c5838b8b880548761b9009bb18fc26f1e7b6934d274f040f56
- mode:
  0600
- regular:
  true
- links:
  1

FAILED_PRIOR_LAUNCHER_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-audit-repair-independent-audit-bcrlhn99

Inspect only the bounded launch-contract, launcher-source, request, and failure
records needed to establish the predecessor omitted-argument defect.

Do not mutate, clean, resume, or adopt any supplied root.

──────────────────────────────────────────────────────────────────────────────
2. FRESH RECONCILIATION ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask 077, prefix:

ES-repair10i-wrapped-carrier-launcher-failure-reconciliation-

Retain:

opening/
analysis/
closeout/
provenance/

All retained directories must be mode 0700.
All retained files must be regular, single-link mode 0600.
No symlink, special object, or empty retained directory is permitted.

──────────────────────────────────────────────────────────────────────────────
3. OPENING PROVENANCE
──────────────────────────────────────────────────────────────────────────────

Before interpreting the failure:

1. Enumerate the complete qualification root using lstat/no-follow semantics.
2. Retain an opening inventory with paths, types, modes, links, sizes, and
   regular-file SHA-256 values.
3. Verify the accepted wrapper identity.
4. Verify the qualification-root wrapper copy equals the accepted wrapper.
5. Verify the supplied contracts, launcher source, Carrier 0002 request,
   constructed-launch record, payload source, payload result, phase-start,
   phase-outcome, and available static-validator artifacts.
6. Record every expected artifact that is absent.
7. Record the exact qualification-root primary verdict as historical report
   text only.

Stop with RECONCILIATION_PROVENANCE_MISMATCH on:

- supplied-root drift during this task;
- missing Carrier 0002 result or outcome;
- wrapper identity mismatch;
- ambiguous or contradictory artifact identities preventing analysis.

Do not treat the root’s incompleteness by itself as a provenance mismatch.

──────────────────────────────────────────────────────────────────────────────
4. COMPLETE ARTIFACT DISCOVERY
──────────────────────────────────────────────────────────────────────────────

Inspect at minimum:

contract/phase-runner-cli-contract-v1.json
contract/wrapped-carrier-launch-contract-v1.json
contract/carrier-request-contract-v1.json
source/wrapped_carrier_launcher.py
provenance/carrier-0002.constructed-launch.json
provenance/carrier-0002.phase-start.json
provenance/carrier-0002.phase-outcome.json
provenance/carrier-0002.request.json
payloads/carrier-0002-valid-result.json
validation/independent-launch-validator-a-result.json

Locate and inspect the exact Carrier 0002 payload source, even if its retained
name differs from the expected pattern.

Locate all files that the payload read or referenced.

Retain a machine-readable artifact ledger containing:

- relative path;
- role;
- size;
- SHA-256;
- producer;
- consumer;
- whether it existed before payload execution;
- whether it was created by the payload;
- whether it is acceptance-bearing for the failed assertion.

──────────────────────────────────────────────────────────────────────────────
5. WRAPPER CLI ADJUDICATION
──────────────────────────────────────────────────────────────────────────────

Independently reconstruct the wrapper CLI from the exact wrapper source.

Require this required-option set:

--carrier-ordinal
--phase
--payload
--payload-entry
--audit-root
--payload-sha256
--payload-size
--expected-wrapper-sha256

Optional repeatable options:

--authorized-operand
--expected-output

Compare the complete Carrier 0002 constructed argv with the wrapper parser.

Record:

- every option;
- occurrence count;
- value;
- source:
  launch contract or request;
- required/optional status;
- whether the wrapper admitted it.

Specifically verify:

- `--expected-wrapper-sha256` occurs exactly once;
- its value equals:
  `6e911ca17dedc6c5838b8b880548761b9009bb18fc26f1e7b6934d274f040f56`;
- no required option is missing;
- no unknown option is present;
- no duplicate single-value option is present.

Because the wrapper reached payload execution, distinguish parser admission from
later payload assertions.

──────────────────────────────────────────────────────────────────────────────
6. EXACT PAYLOAD FAILURE
──────────────────────────────────────────────────────────────────────────────

Read the complete Carrier 0002 payload source.

Enumerate every assertion, guard, failure branch, and returned status.

Parse:

- `carrier-0002-valid-result.json`;
- `carrier-0002.phase-outcome.json`;
- any payload-created validator or diagnostic record.

Identify exactly:

- the first failed predicate;
- every additional failed predicate;
- the exact expected value;
- the exact observed value;
- the source file and source location implementing the predicate;
- the evidence artifact used by the predicate;
- the canonical failure message or code;
- why the payload returned failure.

Do not summarize this as merely “payload-reported-failure.”

Retain:

analysis/payload-assertion-ledger.json

For every payload assertion include:

- assertion ID;
- requirement source;
- source location;
- expected value;
- observed value;
- evidence path;
- result:
  pass, fail, not-reached, or indeterminate;
- whether required by the qualification brief;
- whether the implementation tested it correctly;
- causal classification.

──────────────────────────────────────────────────────────────────────────────
7. SAME-PID ADJUDICATION
──────────────────────────────────────────────────────────────────────────────

Determine exactly how the payload attempted to establish same-PID execution.

Inspect:

- launcher source;
- constructed-launch record;
- phase-start;
- phase-outcome;
- payload source;
- payload result;
- any environment or metadata channel carrying a launcher PID.

Answer separately:

1. Did the launcher call `os.execve`?
2. Is there a retained pre-exec launcher PID?
3. Is there a retained wrapper PID?
4. Is there a retained payload PID?
5. Are any of those facts derived from the same process’s self-observation?
6. Does retained evidence prove equality?
7. Did the payload demand evidence that the launcher never promised to retain?
8. Did it compare the wrong PID pair or a missing field?
9. Is same-PID behavior statically established but dynamically unrecorded?
10. Is the qualification requirement satisfiable without changing the
    launcher?

Classify same-PID as:

- passed;
- failed;
- payload-oracle defect;
- evidence insufficient;
- not the failing predicate.

Do not infer PID continuity solely from the report’s prose.

──────────────────────────────────────────────────────────────────────────────
8. FIXED-ENVIRONMENT ADJUDICATION
──────────────────────────────────────────────────────────────────────────────

Compare:

- launch-contract fixed environment;
- constructed-launch environment;
- wrapper phase-start environment or environment identity;
- payload-observed environment;
- payload expectation.

Require exact treatment of:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

and the qualification-root private HOME and TMPDIR values.

Determine whether:

- the launcher replaced inherited PATH;
- the wrapper received the fixed values;
- the payload read the same values;
- the payload expected fields that were deliberately redacted or represented
  by digest;
- environment qualification actually failed;
- environment evidence was merely not yet adjudicated.

──────────────────────────────────────────────────────────────────────────────
9. STATIC-MATRIX ADJUDICATION
──────────────────────────────────────────────────────────────────────────────

Inspect every retained static-validator source and result.

Determine:

- how many independent validators were required;
- how many were created;
- how many ran;
- exact case count;
- exact failed cases;
- whether Carrier 0002 was supposed to require both validators;
- whether the payload failed because only validator A existed;
- whether any validator result itself reports failure;
- whether the matrix ran before or during Carrier 0002;
- whether matrix incompleteness was expected at that phase.

Do not treat a missing later-phase validator as a Carrier 0002 launcher defect
unless the qualification brief explicitly required it before Carrier 0002
success.

──────────────────────────────────────────────────────────────────────────────
10. REQUIREMENT TRACEABILITY
──────────────────────────────────────────────────────────────────────────────

For each failed payload predicate, trace it to one of:

A. An explicit launcher-qualification requirement.
B. An explicit Carrier 0002 requirement.
C. A later-carrier requirement incorrectly pulled into Carrier 0002.
D. A producer-invented requirement.
E. A correct requirement implemented incorrectly.
F. A correct requirement with insufficient retained evidence.

Retain:

analysis/requirement-traceability.json

Quote only short bounded source fragments needed to identify the requirement;
otherwise use exact paraphrase and source location.

──────────────────────────────────────────────────────────────────────────────
11. ROOT-CAUSE VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

LAUNCHER_FAILURE_RECONCILED_PAYLOAD_ORACLE_DEFECT

only if the launcher and contracts satisfy all Carrier 0002 requirements and
the payload failed due to an incorrect, premature, invented, or miscomputed
assertion.

Return:

LAUNCHER_FAILURE_RECONCILED_LAUNCHER_DEFECT

only if retained evidence establishes that the launcher violated an explicit
Carrier 0002 or launcher-package requirement.

Return:

LAUNCHER_FAILURE_RECONCILED_CONTRACT_DEFECT

only if the launch contract, request contract, or CLI contract omitted,
contradicted, or ambiguously assigned a required invariant and that caused the
payload failure.

Return:

LAUNCHER_FAILURE_RECONCILED_EVIDENCE_INSUFFICIENT

only if the exact failed predicate is identifiable but retained evidence cannot
establish whether the required behavior passed or failed.

Return:

RECONCILIATION_PROVENANCE_MISMATCH

only for input drift, supplied-root mutation, missing indispensable failure
artifact, or closing inequality.

Do not implement the repair.

──────────────────────────────────────────────────────────────────────────────
12. REQUIRED RECOMMENDATION
──────────────────────────────────────────────────────────────────────────────

Based on the verdict, specify exactly one next tranche:

For payload-oracle defect:

- preserve the launcher and contract bytes;
- create a new qualification package with a corrected payload;
- identify the exact payload lines or predicate to replace;
- state the correct assertion and evidence source.

For launcher defect:

- identify the minimal launcher behavior change;
- state whether launch/request contracts remain valid;
- list the exact new causals needed.

For contract defect:

- identify the exact contract fields to add or revise;
- state whether launcher source must change;
- state whether the wrapper CLI contract changes.

For evidence insufficiency:

- define one minimal audit-owned causal that produces the missing evidence
  without inspecting target content;
- do not prescribe a full qualification rerun before that causal passes.

Do not recommend the full V3 audit until a complete launcher package has
qualified.

──────────────────────────────────────────────────────────────────────────────
13. CLOSING
──────────────────────────────────────────────────────────────────────────────

Re-enumerate:

- qualification root;
- accepted generic-wrapper root;
- bounded failed prior-launcher root.

Require exact opening/closing equality.

Remove only the reconciliation root’s private temporary state.

Retain:

- opening inventories;
- complete artifact ledger;
- CLI adjudication;
- payload assertion ledger;
- same-PID adjudication;
- environment adjudication;
- static-matrix adjudication;
- requirement traceability;
- root-cause record;
- final report;
- final inventory.

Use two independent manifest generators and require byte-identical closure.

──────────────────────────────────────────────────────────────────────────────
14. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Reconciliation-root identity
3. Supplied-root opening identities
4. Complete relevant artifact ledger
5. Wrapper CLI adjudication
6. Carrier 0002 constructed argv
7. Exact payload source identity
8. Exact first failed predicate
9. Complete payload assertion ledger
10. Same-PID adjudication
11. Fixed-environment adjudication
12. Static-matrix adjudication
13. Requirement traceability
14. Root-cause classification
15. Exact recommended next tranche
16. Supplied-root closing equality
17. Reconciliation capsule closure
18. Remaining uncertainty and nonclaims
19. Explicit confirmations

Required confirmations:

QUALIFICATION_ROOT_MUTATION_NOT_PERFORMED
GENERIC_WRAPPER_ROOT_MUTATION_NOT_PERFORMED
FAILED_PRIOR_LAUNCHER_ROOT_MUTATION_NOT_PERFORMED
LAUNCHER_OR_WRAPPER_NOT_EXECUTED
CARRIER_0002_NOT_RETRIED
EXACT_FAILED_PREDICATE_IDENTIFIED
WRAPPER_CLI_ADJUDICATED
SAME_PID_REQUIREMENT_ADJUDICATED
FIXED_ENVIRONMENT_ADJUDICATED
STATIC_MATRIX_REQUIREMENTS_ADJUDICATED
NO_TARGET_CONTENT_INSPECTED
CANDIDATE_GIT_NOT_INVOKED
PRODUCT_OR_LIVE_SERVICE_NOT_INVOKED
NETWORK_CONTACT_NOT_PERFORMED
FULL_V3_AUDIT_NOT_STARTED
SUBAGENTS_CREATED: 0
```

The next action after this reconciliation should be determined by the exact failed predicate—not by the qualification root’s broad `UNAVAILABLE` label.

**Source:** Codex’s `WRAPPED_CARRIER_LAUNCHER_UNAVAILABLE` report immediately above.

**Confidence:** 0.995 that the launch path itself reached payload execution successfully; 0.98 that the current report is insufficient to classify the failure as a launcher limitation; 0.97 that a read-only artifact reconciliation is the lowest-risk next step.
