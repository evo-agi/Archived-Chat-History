The stop is correct. **A5T’s repository repair is provisionally successful but not seal-ready**:

- The two-file patch passed 45/45 targeted executions across three independent controls.
- Actual socket paths dropped from 105–115 bytes to 75–76 bytes.
- The old `EINVAL` setup failure disappeared.
- All five tests reached their intended assertions outside the A5S sandbox.
- Source-line compatibility and the 387 protected repository tuples remained intact.

The new blocker belongs to the **validation execution boundary**, not to the socket repair itself: A5S allows device writes only to `/dev/null`, while the four root tests reach `os.openpty()`. The full suite therefore cannot qualify under the existing sandbox.

Two bad responses should be avoided:

1. Do not seal A5T from targeted results alone.
2. Do not grant broad access to `/dev`, `/dev/ttys*`, or arbitrary terminal devices merely to make the suite pass.

The decision now is finite: either macOS exposes a narrowly enforceable pseudo-terminal capability suitable for one explicit validation lane, or the test harness must stop requiring a PTY. My provisional preference is the harness redesign unless a dedicated PTY capability or pre-opened-FD design can prove that unrelated operator terminals remain inaccessible.

Keep the current A5T source bytes unchanged while this is investigated. The failed A5T evidence child remains unsealed and nonqualifying.

## Next gate: bounded PTY-capability reconnaissance

Pass this to Codex:

```text
Objective

Perform a parent-only, source-read-only Repair 10I-A5P reconnaissance to
determine the smallest safe correction for the A5T validation blocker:

- exact A5T repository test bytes pass their intended assertions outside the
  A5S sandbox;
- the same four remote-operator tests fail inside A5S because `os.openpty()`
  receives EPERM;
- A5S presently grants device writes only to `/dev/null`.

Determine whether the next repair should be:

A. a narrowly typed successor pseudo-terminal capability;
B. a bounded repository test-harness redesign that removes PTY dependence; or
C. blocked because neither can preserve the required security and validation
   contracts.

Do not implement either option in this turn.

Do not modify repository source.
Do not modify A5S.
Do not resume, overwrite, or seal the failed A5T child.
Do not implement A5C.
Do not restart the A6 policy-evidence refresh.
Do not start A6 or B6.
Do not create a ZIP, handoff, capture child, or snapshot.
Do not stage, commit, push, install, invoke a live route, contact a remote
host, or execute Linux binaries.

No subagents. You are the sole operator.

Repository

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Sealed A5 product predecessor

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5-product-closure-4dd211207800

Sealed A5S successor

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5s-successor-closure-e260e1bb5ac4

Failed and unsealed A5T child

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5t-test-fixture-closure-e260e1bb5ac4

Failed and unsealed A6 policy-evidence refresh

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a5s-e260e1bb5ac4

Required reconnaissance child, absent at opening

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5p-pty-recon-ab646e5a0e66

## 1. Mandatory opening gate

Require exact repository identity:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- upstream:
  absent
- index SHA-256:
  012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31
- current repository T:
  ab646e5a0e66a30c00ca405ab43fbf6903224043
- current repository inventory:
  c06fda4cd2f706ea9f739fc1050434126cc04dd64d5a93de546345081617f0d3
- membership:
  389 total / 375 tracked / 14 nonignored untracked
- staged/deleted/renamed/unmerged:
  0/0/0/0

Require the current repository delta relative to the A5 opening bytes to be
exactly:

1.
remote_alpha_operator_test.go

2.
es/runtimehelper/supervisor_test.go

No addition, deletion, rename, or mode change.

Require the opening A5 file identities to remain recoverable:

remote_alpha_operator_test.go:
  ec3ff21ffabee06711fb85d1794758f01b14e59b61b901263ee17db14bcb67c5

es/runtimehelper/supervisor_test.go:
  1d798d53b5aacf7ba18ecfb7d1a988f922e5a33bdb7a0003c2078644fab2d841

Capture and report the current SHA-256, size, and mode of both changed files.
Do not infer or guess them.

Require exact A5:

- manifest:
  29702284ed6e5a5d44758e27a7211cf83e20dbe13dbd8a9964b87f3f1724b1fc
- payloads:
  341
- directories:
  84
- T:
  e260e1bb5ac44ee4ba732265eddd4a27aa1d3e0c
- inventory:
  9fb9765a4b0b41ae40da758d9a0315739b615a4c4c2027cd1bc1c83c3c92589b

Require exact A5S:

- manifest:
  57a3b060633348f125933b1b577972ae2759256e776745d3ab95cf3a6829ee4f
- payloads:
  271
- source T:
  983943e612dd4d48ca4f0fabbc48ad51909c2e11
- source inventory:
  799bf5e9bac3849e338adf16901d2f2debeb53d07dabb5108547e6c29ed01c8a
- members:
  12

A5S binaries:

repair10-runner:
  ce6a44a99d4f53eaa6c8feeadc407e063deb7e6303e68f154fbe1cf0d573e68b

repair10-compare:
  e31887e0d45026d6bad6a6f2e5a4a30dd1f0f7c5bd55847991a9120ef6351e06

repair10-semantic:
  2f28bf8996b4a42d318cb16604804ad90cdb41b17517d30b4c0db85d5fbd0c2e

repair10-fixture:
  d058ebdeb01b960868e4784abafbaaef9d57e8e71b12bdaa71f55aca9786c2f4

Require the A5T child to remain:

- present;
- unsealed;
- without manifest or detached digest;
- unchanged during this turn.

Reverify its retained evidence that:

- three independent private controls produced 45/45 passes;
- required skips were zero;
- actual socket paths were 75–76 bytes;
- the old socket EINVAL diagnostics disappeared;
- the five named tests reached their intended assertions outside A5S;
- source-line compatibility passed;
- the A5S full-suite attempt failed specifically at PTY allocation with EPERM.

Require the failed policy-evidence child and all predecessor lineage to remain
unchanged.

Require the A5P reconnaissance child to be absent.

Stop on any mismatch:

REPAIR10I_A5P_RECONNAISSANCE_BLOCKED

## 2. Evidence-child posture

Create the A5P reconnaissance child exclusively under umask 077 with exactly:

opening/
source/
profiles/
probes/
findings/
closeout/

All directories mode 0700.

All files regular, single-link, non-symlink, with intended mode 0600 or 0700.

No hardlinks.

This child may contain only:

- source excerpts or inventories required for this decision;
- exact sandbox profiles;
- minimal probe source;
- probe intents, streams, exits, and results;
- the final reconnaissance report;
- cleanup and seal records.

Do not copy private repository logs or unrelated user data.

If reconnaissance completes, install a detached digest and then a manifest as
the final mutation. Otherwise leave the child unsealed.

## 3. Recover the exact PTY call chain

Inspect the exact current source and recover:

1. Every active `openpty`, `pty.Open`, `/dev/ptmx`, `/dev/ttys*`, `isatty`,
   terminal-mode, controlling-terminal, and window-size operation reachable
   from the four remote tests.
2. Exact helper and caller paths and lines.
3. Exact process that executes the PTY allocation:
   - Go test process;
   - Python child;
   - shell helper;
   - another executable.
4. Exact executable, argv, cwd, environment, and inherited descriptors.
5. Whether the PTY is used for:
   - terminal detection only;
   - line discipline;
   - controlling-terminal semantics;
   - signal/job-control behavior;
   - merged stdout/stderr;
   - sudo or remote-shell emulation;
   - readiness;
   - another purpose.
6. Whether the four named assertions genuinely depend on PTY semantics.
7. Whether pipe, socketpair, ordinary files, or an existing test helper can
   preserve those assertions without weakening them.

Inspect every other active caller of the same PTY helper. A local redesign may
not silently alter unrelated tests.

## 4. Recover the exact A5S sandbox denial

Inspect and bind:

- the exact suite specification;
- exact rendered A5S profile;
- profile-source identity;
- command result;
- raw stdout/stderr;
- terminal reconciliation;
- resource ledger;
- process observations;
- EPERM diagnostic;
- failed syscall or path where observable.

Report:

- which sandbox operation was denied;
- whether denial occurred at `/dev/ptmx`, a slave path, an ioctl, or another
  resource;
- whether the child created any master or slave FD before failure;
- whether cleanup and terminal reconciliation remained complete.

Do not infer the denied object solely from the high-level Python or Go error.

## 5. Read-only local policy inspection

Read-only inspect locally available Apple sandbox profiles, manuals, binaries,
or strings for a dedicated pseudo-terminal operation or narrowly typed rule.

Search specifically for safe evidence of:

- `pseudo-tty`;
- `pty`;
- `/dev/ptmx`;
- `/dev/ttys`;
- terminal-device classes;
- sandbox extensions for terminal allocation.

Do not search the network.

Do not copy protected system files into the evidence bundle. Record only safe
path/line/string references and hashes where appropriate.

Do not infer support from an undocumented token merely appearing as a string.
Behavior probes remain required.

## 6. Minimal controlled PTY probes

Create one minimal standard-library probe that:

- calls the same PTY primitive used by the tests;
- reports only success/failure, errno, FD disposition, and safe device-role
  metadata;
- writes no terminal payload;
- closes every acquired FD exactly once;
- retains no terminal device after exit.

Run only against parent-owned private PTY controls. Never open or write the
operator’s current terminal.

Required controls:

### A. Unsandboxed positive

Require successful PTY allocation and complete cleanup.

### B. Exact current A5S profile negative

Require reproduction of the current EPERM failure.

### C. Dedicated PTY-operation candidate

Only if local policy inspection identifies a finite dedicated PTY operation:

- add that one operation to a private probe profile;
- retain every other A5S denial;
- require successful private PTY allocation;
- prove an unrelated parent-created PTY remains inaccessible unless explicitly
  inherited or granted.

### D. Literal `/dev/ptmx` candidate

Test an exact literal grant to `/dev/ptmx` only.

Determine whether that is:

- sufficient;
- insufficient because a slave path or another operation is required;
- rejected by the profile compiler;
- unsafe for another reason.

Do not add a wildcard `/dev` or `/dev/ttys*` rule.

### E. Pre-opened-FD candidate

The parent creates a private PTY pair and passes only explicitly selected FDs
to the sandboxed child.

Determine whether:

- the child can use the inherited descriptors without any new terminal-device
  file grant;
- the child can be prevented from allocating another PTY;
- the existing tests could consume such FDs without production changes;
- descriptor custody, close, process-group, and cleanup evidence can remain
  complete.

Use two parent-owned private PTYs where useful:

- one granted;
- one ungranted negative.

Never probe unrelated system or user terminals.

### Forbidden probe

Do not run a profile granting:

- all of `/dev`;
- a regex or prefix covering every `/dev/ttys*`;
- the operator’s current terminal;
- unrestricted device read/write.

Static analysis may classify such a rule as broad, but it must not be executed.

## 7. Security adjudication

For every candidate mechanism determine whether it permits:

- allocating arbitrary new PTYs;
- opening existing unrelated TTYs;
- reading or writing another user or operator terminal;
- becoming a controlling terminal;
- terminal injection;
- bypassing command stream custody;
- escaping raw stdout/stderr accounting;
- changing signal or process-group semantics;
- retaining descriptors after child exit;
- broadening non-PTY commands.

A successor capability is acceptable only if:

- it is explicit in the suite/command policy;
- it changes the logical fingerprint;
- it is denied by default;
- it is confined to a named validation lane;
- unrelated commands do not receive it;
- external requalification recomputes it;
- resource ledgers account for all inherited or allocated descriptors;
- no unrelated terminal becomes accessible;
- cleanup and two fresh zero-observation epochs remain provable.

Broad `/dev`, `/dev/ttys*`, or operator-terminal access is automatically
unacceptable.

## 8. Test-harness alternative

Independently determine whether PTY use can be removed from the four tests
without changing their named assertions.

For each feasible alternative report:

- exact helper and call sites;
- semantic behavior currently supplied by the PTY;
- replacement primitive;
- why the replacement preserves the assertion;
- exact touched files;
- impact on other PTY callers;
- required positive and inverse-mutant tests;
- source-line compatibility with A5S;
- whether the current two-file A5T scope is sufficient.

Do not recommend replacing PTY with pipes merely because the tests pass under
one control. The replacement must preserve every intended terminal, signal,
remote-shell, sudo, ordering, and stream property actually asserted.

If PTY behavior is not material to these tests, prefer removing incidental PTY
dependence over widening the sandbox.

## 9. Successor-capability alternative

If a narrow successor solution exists, freeze:

- exact capability name;
- exact profile rule;
- exact suite/command-spec field;
- default value;
- permitted source classes and command lanes;
- logical-fingerprint treatment;
- strict schema impact;
- external qualification recomputation;
- resource-ledger treatment;
- process/descriptor custody;
- exact successor touched files;
- positive and negative causal tests;
- A/B build and self-test requirements.

Determine explicitly whether a private schema version change is required.

Do not hide the capability behind:

- command-name inference;
- test-name inference;
- implicit full-suite behavior;
- a profile-string special case;
- a caller-supplied arbitrary device path.

## 10. Validation consequences

Freeze the required sequence after the selected repair:

1. Seal the successor capability amendment or repository harness redesign.
2. Preserve the current failed A5T child as negative evidence.
3. Create a new A5T validation/closure child; do not resume the current child.
4. Re-run from the beginning:
   - targeted controls;
   - count-three;
   - race;
   - boundary and negative controls;
   - broader affected packages;
   - complete private full suite under the corrected successor.
5. Require the repaired five tests to pass inside the qualified sandbox.
6. Require no new unknown diagnostics or source-line incompatibility.
7. Seal A5T only after the complete gate passes.
8. Implement and seal the separate A5C observability-duration amendment.
9. Restart the complete two-control A6 policy-evidence refresh from fresh
   materializations.

The current 45/45 passes remain useful implementation evidence but do not
substitute for the new full validation.

## 11. Required verdict

Return exactly one:

### Narrow successor capability is feasible and preferred

REPAIR10I_A5P_SUCCESSOR_CAPABILITY_RECONNAISSANCE_READY

Use only when:

- a finite PTY capability is behavior-proven;
- unrelated terminals remain inaccessible;
- no broad device rule is needed;
- the exact successor scope, schema treatment, and causal matrix are frozen;
- this is safer and smaller than a repository harness redesign.

### Repository test-harness redesign is required or preferred

REPAIR10I_A5T_TEST_HARNESS_REDESIGN_REQUIRED

Use when:

- PTY semantics are unnecessary or can be replaced without weakening the
  assertions; or
- every successor grant would be broad, implicit, or unable to exclude
  unrelated terminals.

State the exact repository scope and why the redesign preserves the tests.

### Evidence is insufficient

REPAIR10I_A5P_RECONNAISSANCE_BLOCKED

Use when:

- the denied operation cannot be identified;
- probe behavior is ambiguous;
- no safe capability or faithful harness alternative can be frozen;
- containment or cleanup fails.

## 12. Required report

Include:

1. Opening and closing identities.
2. Exact current two-file repository delta.
3. Exact A5T retained validation results.
4. Complete PTY call graph.
5. Exact sandbox denial.
6. Local sandbox-policy findings.
7. Controlled probe matrix and outcomes.
8. Security analysis.
9. Test-harness alternative analysis.
10. Successor-capability alternative analysis.
11. Recommended path and rejected path.
12. Exact touched-file set.
13. Exact causal and validation matrix.
14. Restart and evidence-carry-forward rules.
15. Inspection limits and uncertainty.
16. Manifest identity and payload count if the reconnaissance child is sealed.
17. Confirmation that no repository or predecessor bytes changed.

No implementation.
No A5T seal.
No A5C.
No A6 or B6.
No product A/B.
No snapshot.
No ZIP or handoff.
No capture child.
No independent audit.
No staging, commit, push, installation, live route, remote contact, or Linux
execution.
```

This is a genuine scope-expansion gate, but it does not invalidate the two-file repair. It establishes that the validation substrate currently cannot exercise those repaired tests under its own declared least-privilege profile.

After any successor or repository byte change, the affected validation and later audit must be redone; a prior audit is not binding after bytes change.  Exact manifests can prove which bytes were exercised, but they cannot prove that granting terminal capability—or replacing the terminal harness—is correct or safe.  The sealed A2 precedent also expressly distinguishes a bounded tool causal from the fresh downstream source control still required afterward. 

### Sources

- Codex’s `REPAIR10I_A5T_SCOPE_EXPANSION_REQUIRED` report supplied in this turn.
- Governed Execution repair and re-audit protocol. 
- Governed Execution Provenance Guidance. 
- Sealed Repair 10I-A2 non-substitution boundary. 

**Confidence:** 0.999 that A5T correctly stopped; 0.98 that the two-file socket repair itself remains valid but unqualified; 0.90 that a broad terminal-device grant would be unacceptable; 0.75 that the eventual preferred result will be a test-harness redesign rather than a full-suite PTY grant; 0.99 that the complete A5T validation must restart after whichever repair is selected.
