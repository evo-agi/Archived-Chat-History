Here is Codex's response:

AUDIT_PROVENANCE_MISMATCH

The one authorized substantive parent ran once, sealed the audit capsule, and exited nonreturningly. No retry, subject change, authority change, repository change, target audit, runtime execution, A6 activity, network access, Git operation, or subagent occurred.

The sealed artifacts are the [terminal record](/private/tmp/ES-repair10i-v3-replacement-schema-subject-independent-audit-qz6fkiej/terminal/terminal-result.json) and [52-item generated report](/private/tmp/ES-repair10i-v3-replacement-schema-subject-independent-audit-qz6fkiej/report/final-operative-report-v1.json).

## Operative report

1. **Exact primary verdict:** The verdict is the line above. No subject acceptance or subject block disposition was established.

2. **Fresh audit-root identity:** `/private/tmp/ES-repair10i-v3-replacement-schema-subject-independent-audit-qz6fkiej`; device `16777234`, inode `182663988`, mode `0700`, UID `501`, GID `0`.

3. **Replacement subject identity:** `/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-z1o1vs54`; device `16777234`, inode `182649818`, mode `0700`, UID `501`, GID `20`; matched.

4. **Construction-wrapper identity:** Device `16777234`, inode `182648782`, mode `0700`, UID `501`, GID `0`; authenticated.

5. **Accepted implementation authority chain:** Passed. Accepted audit inode `182593190`; accepted wrapper inode `182593189`; accepted disposition, source freeze, lineage, requalification, exact parent argv, one-shot authorization, process custody, raw streams, terminal seal, and no-postseal records authenticated.

6. **Content identities:** Bundle size `13,598,758`, SHA-256 `b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671`; authority size `19,737`, SHA-256 `276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563`. Authentication passed: 479 members, eight roles, seven content roles, one bounded failure-evidence role, deterministic equality, no `.DS_Store`.

7. **Audit source/toolchain:** Five fresh files were used:

   - Parent: `fb90501ee12b3c2d746c5a0f3ad462115c0d3d53c9cf1c904c99b9ce299731d9`
   - Primary oracle: `8e6da1ec47278cd27b050d102d741881e1b202a2029f16333bdc3493d6b2f233`
   - Secondary oracle: `edb2ef40969f9007be11c58b38239c5dace17bb6728935d0e6b77f6f9d92191b`
   - Qualification runner: `c03b0be019e9af9720ee592dd516f360f8b09286ce7874927de8c0b174687e3d`
   - Static qualifier: `f9e2ff26ed8aea513c73966ffb61702db4bccda9baaa5b28e116c4b9e8b0fe90`

   Pinned Python `3.13.4`; authenticated `jsonschema 4.24.0`; `Draft202012Validator`.

8. **Audit source freeze:** Five sources frozen before substantive execution; later modification forbidden. Registry SHA-256 `955357fae51cf126780f1622374c77da2c039d7f63de92b246898c5ae984f1e8`.

9. **Historical-regression requirements:** Retained as requirements only in [historical-audit-regression-requirements-v1.json](/private/tmp/ES-repair10i-v3-replacement-schema-subject-independent-audit-qz6fkiej/opening/historical-audit-regression-requirements-v1.json).

10. **Audit-logic qualification matrix:** 38/38 synthetic cases passed; zero false acceptance, false rejection, reason mismatch, skip, unexpected exception, or oracle disagreement. The substantive failures show this matrix was insufficient to qualify the production paths.

11. **Dual-oracle contract and identities:** `fresh-primary-recursive-v1` and `fresh-secondary-model-v1`; contract frozen in [dual-oracle-audit-contract-v1.json](/private/tmp/ES-repair10i-v3-replacement-schema-subject-independent-audit-qz6fkiej/contract/dual-oracle-audit-contract-v1.json).

12. **Subject terminal closure:** Passed independently. Root identity, counts, topology, modes, temporal inventory, manifests, exclusions, and no-postseal record matched.

13. **Subject temporal/manifests:** Temporal size `16,051`, SHA-256 `905a21d0ec24be5caf8b29ac0e29419833dc19b7b309f60afdb2ad215a1866b4`; each manifest size `16,620`, SHA-256 `5f22e7e1405afd0378ff2e054f7b436d4b00172a300a97a5676880a9d7196758`.

14. **Independent physical reprojection:** Passed: 73 entries, 12 directories, 61 regular files, one root row, no empty descendants, symlinks, special objects, multiply linked files, cache, or bytecode.

15. **Normative contract:** Size `32,038`, SHA-256 `874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19`; strict JSON, sole-writer posture, and false implementation-present/authority postures passed.

16. **Fifteen current schema roles:** `child-process-record`, `cleanup-result`, `current-export-registry`, `executable-origin-registry`, `failure-outcome`, `metadata-coherence`, `normative-construction-parent`, `package-freeze`, `package-root-rebinding`, `phase-record`, `plan-identity-consumer-registry`, `pointer-resolution-result`, `qualification-result`, `temporal-inventory`, `terminal-manifest-metadata`. All role, path, `$id`, identity, current-status, and physical-set checks passed.

17. **Fourteen generated families:** `child-process`, `cleanup-result`, `current-export-registry`, `executable-origin-registry`, `failure-outcome`, `metadata-coherence`, `package-freeze`, `package-root-rebinding`, `phase-record`, `plan-identity-consumer-registry`, `pointer-resolution-result`, `qualification-result`, `temporal-inventory`, `terminal-manifest-metadata`.

18. **Role/family mapping:** Complete; `child-process-record → child-process`; the other thirteen roles map by corresponding family name. `normative-construction-parent` is the sole intentionally unmapped role.

19. **Draft 2020-12:** 15 evaluated, 15 valid, zero errors, zero unresolved references, zero empty `prefixItems`.

20. **Contract-derived witness rows:** All 14 were schema-valid and contract-valid.

21. **Schema-derived witness rows:** All 14 were contract-valid and schema-valid. For both witness kinds, the family identities were:

   | Family | SHA-256 | Size |
   |---|---|---:|
   | child-process | `6a6a90fe4a12b2063324e21c9b9a226e0f69a7f9d733e58cf5e8a5de70a7c0db` | 684 |
   | cleanup-result | `0e407e34d4d21b9dee5f4774276e7ed53851d596b3375a9bc37fb803da782ba0` | 442 |
   | current-export-registry | `c4394d3ada7ef4a9d8d79e86c6bfeb36ea1e141211e8b9f69e0f1f8567534a41` | 1,060 |
   | executable-origin-registry | `871fd273780550569070cfa37bed7d7d825e7dc02b7c2f32a0503c478701879a` | 342 |
   | failure-outcome | `8e06c9d373b093a95f20f68b303158a5fe1adab5fad2a3397f420093e2be07e9` | 388 |
   | metadata-coherence | `99d09a9cef27acc1e3e2ae0212f7b6037fd15fecc60a7845a4e814b1cdadb237` | 348 |
   | package-freeze | `aa6a713e789cb761ff8895e02ae7099b71b90a89fbb246ef886707d56dc7fed6` | 1,197 |
   | package-root-rebinding | `7ff1dad6013c35806c40d62d72982444475fee1d8a6cee1712c969467a5de6f3` | 442 |
   | phase-record | `2cd21ccb1d0972e37cd137f3d56b81de99e20197976c1b8e4dd5f7d95312e001` | 632 |
   | plan-identity-consumer-registry | `04268e68056e8a3bdf9eed331bd115e55f9cc108b489bdf07679a7035d4a286e` | 655 |
   | pointer-resolution-result | `773ede18c6e3ededf8792a6f220a7caef29763d44c31e8301836afa2210aaafb` | 1,870 |
   | qualification-result | `e82cfc5b583869e119fc6ca4123712006f22866f4d276ebd2c46f0066520f0a7` | 406 |
   | temporal-inventory | `94db36972f8dd3908579e371b9727f011f3d832f5204fc28681dc803623d6ddb` | 828 |
   | terminal-manifest-metadata | `b15fa1e8cc41edcc02f69b3228c2e8ab02db84a64bd3b89627ce932d9c5cc3a1` | 683 |

22. **Witness aggregate:** Both oracles: 14 contract witnesses, 14 schema witnesses, 28 passing rows, zero joint unsatisfiability, zero baseline under-enforcement, zero failed rows.

23. **946-case aggregate:** Execution completed, but the results are nonoperative:

   - Primary: 946 rows; 720 passed; 226 nonpassing; 0 false acceptances; 7 false rejections; 226 reason mismatches; 6 exceptions.
   - Secondary: 946 rows; 718 passed; 228 nonpassing; 0 false acceptances; 9 false rejections; 219 reason mismatches; 8 exceptions.

24. **Exact emitted nonpassing 946 rows:** These identify every retained nonpassing row.

   - Primary ordinals: `8,10,16,20-22,26,36,46,50,52,56,64,78,80,82,84,86,88,90,92,96,98,100,102,104,106,108,110,126,128,188,202,204,208,218,224,226,236,244,250,268,270,288,290,292,294,296,363,373,375,400,416-457,459,461,464-487,489,491-494,512,514,516,518,520,522,532,534,544,546,548,550,560,562,572,574,576,578,588,590,600,602,604,606,616,618,628,630,632,676-679,681,695,701,703,715,717,720-733,737,739,741,743,745,747,749,751,753,755,759,761,763,781,783,785,787,795,815,817,820-833,837,839,841,843,845,847,849,851,853,855,873,875,881,898`.
   - Secondary ordinals: the same set plus `203` and `900`.
   - Common exceptions: `80,98,102,110,204,518`, all caused by documentary checking iterating a deliberately mistyped `null`.
   - Exact rows are retained in [primary-negative-946-v1.json](/private/tmp/ES-repair10i-v3-replacement-schema-subject-independent-audit-qz6fkiej/validation/primary-negative-946-v1.json) and [secondary-negative-946-v1.json](/private/tmp/ES-repair10i-v3-replacement-schema-subject-independent-audit-qz6fkiej/validation/secondary-negative-946-v1.json).

25. **137-case aggregate:** Each oracle evaluated 137 rows; only ordinal 1 passed; ordinals 2–137 failed; zero skips or exceptions.

26. **Exact emitted nonpassing 137 rows:** Ordinals `2–137` for both oracles. The evaluator incorrectly projected nearly every successful semantic predicate to `ACCEPT_ALL_14`, ignoring each row’s governed outcome vocabulary such as `REJECT_EMPTY_EXPORTS`, `ACCEPT_TARGET_AUDIT_PLAN`, `REJECT_SCHEMA`, `ABSENT`, or `DETECTED`. Exact rows are in [primary-contradiction-137-v1.json](/private/tmp/ES-repair10i-v3-replacement-schema-subject-independent-audit-qz6fkiej/validation/primary-contradiction-137-v1.json) and [secondary-contradiction-137-v1.json](/private/tmp/ES-repair10i-v3-replacement-schema-subject-independent-audit-qz6fkiej/validation/secondary-contradiction-137-v1.json).

27. **Dual-oracle crosswalk:** 1,177 rows; two disagreements:

   - Ordinal 203, `required-remove:executable-origin-registry:/entries`: primary correctly observed `REJECT_SCHEMA`; secondary raised `KeyError('entries')`.
   - Ordinal 900, `under-enforcement:cleanup-pass-with-set-mismatch`: primary observed `REJECT_DOCUMENTARY`; secondary raised `KeyError(...)`.

   See [dual-oracle-crosswalk-v1.json](/private/tmp/ES-repair10i-v3-replacement-schema-subject-independent-audit-qz6fkiej/validation/dual-oracle-crosswalk-v1.json).

28. **766/333 field map:** Passed: 766 unique normative leaves, 333 unique enforcement rows, exact expected set, zero unresolved or duplicate rows, identities and family mappings closed.

29. **Documentary validators:** Exact ten-role registry, unique paths, exact identities, and all ten retained producer results reported passing. Independent closure failed only for `schema-negative-matrix-validator`, derivatively from the invalid 946 audit.

30. **Confirmation evidence:** 66 rows evaluated; 51 passed and 15 were derivative failures; zero hard-coded-success flags within the oracle rows, zero absence-as-success, stale evidence, circularity, or independent blockers.

31. **Derivative-confirmation ledger:** Fifteen derivative failures, not counted as independent package blockers:

   `ALL_TEN_SEMANTIC_CONTRADICTION_SITES_REPAIRED`, `ALL_THIRTY_NINE_REQUIRED_FIELDS_ADMITTED`, `CHILD_PRELAUNCH_FIELDS_ADMITTED_AND_ENFORCED`, `CHILD_OUTCOME_FIELDS_ADMITTED_AND_ENFORCED`, `SEVEN_EXPORT_ROLES_ADMITTED_AND_ENFORCED`, `SUCCESSOR_PLAN_IDENTITY_ADMITTED_AND_ENFORCED`, `PHASE_REQUIRED_ACTIONS_ADMITTED_AND_ENFORCED`, `PAYLOAD_IMPORTED_RAW_POSTURE_ADMITTED_AND_ENFORCED`, `PAYLOAD_IMPORTED_POSITIVE_ASSERTION_ADMITTED_AND_ENFORCED`, `QUALIFICATION_PLAN_IDENTITY_ADMITTED_AND_ENFORCED`, `PACKAGE_FREEZE_PLAN_IDENTITY_ADMITTED_AND_ENFORCED`, `PACKAGE_FREEZE_EXPORT_IDENTITIES_ADMITTED_AND_ENFORCED`, `GENERATED_RECORD_NEGATIVE_MATRIX_PASSED`, `CONTRADICTION_REGRESSION_MATRIX_PASSED`, `DOCUMENTARY_VALIDATORS_REGENERATED`.

32. **Current-role occupancy:** The independent check failed because it generated `validator:<role>` identifiers while the authenticated registry uses `documentary-validator:<role>`. This is an audit label-normalization defect, not established subject drift.

33. **Lineage/supersession:** Fifteen explicit schema supersession edges retained; lineage record passed; `historical_source_used=false`.

34. **Producer package status:** Construction passed; producer qualification passed; subject terminal closure passed; `implementation_present=false`; `implementation_authority=false`; independent acceptance not preclaimed; target audit not executed; runtime validation not rerun; no self-promotion.

35. **Findings registry:** Five supposed subject blockers were emitted: `NEGATIVE-946`, `CONTRADICTION-137`, `DOCUMENTARY-VALIDATORS`, `CONFIRMATION-EVIDENCE`, and `OCCUPANCY-LINEAGE-STATUS`. They are nonoperative because their causal failures are audit-oracle and projection defects.

36. **Repair-owner registry:** The sealed registry assigned subject-side owners, but those assignments are not adopted. The demonstrated repair owners are `INDEPENDENT_AUDIT_ORACLE` and `INDEPENDENT_AUDIT_EVIDENCE_PROJECTION`.

37. **Finding ownership/dependency graph:** Five findings, five direct-blocker labels, zero dependency edges, non-null evidence structurally retained. Ownership is substantively invalid because audit defects were misclassified as subject-package defects.

38. **A00–A15 phases:** `A00–A06 passed`; `A07 failed`; `A08 failed`; `A09 passed`; `A10–A13 failed`; `A14 passed`; `A15 recorded passed`. All 16 records are terminal. A15’s status conflicts with the terminal `closure_pass=false`.

39. **Child ledger/custody:** Zero children; empty contiguous ordinal set; no streams missing; all children vacuously reaped; all descriptors closed. Parent used the pinned interpreter, isolated mode, bytecode disabled, `DEVNULL` stdin, exact audit-root cwd, no shell/network/Git, and one authorized launch.

40. **Audit cleanup:** Passed. Two preparation fixture roots were inventoried, evidence-retained, removed, and verified absent twice; exact cleanup-set equality held; zero process, descriptor, cache, or bytecode survivors.

41. **Supplied-root equality:** Passed for all six supplied inputs. Entry counts remained subject `73`, construction wrapper `49`, accepted audit `78`, accepted wrapper `12`; content-file identities remained byte-identical.

42. **Audit temporal identity:** Size `17,503`; SHA-256 `9376e443e1a20cc631d0bb02fad5b25384d350164371cb81c7413a31ce7642b1`; independently generated bytes equal; immediate reprojection passed.

43. **Audit manifests:** Each size `18,167`; SHA-256 `cd486b110b11d8ff8d793d945efeb290af8a037b1f63ec14a293ca7f9e357c27`.

44. **Audit A/B equality:** Passed byte-for-byte.

45. **Final reprojection:** Passed; root row count exactly one; descriptor/path inode equality passed.

46. **Audit topology/modes:** Directory modes `0700`, file modes `0600`, zero symlinks, special objects, multiply linked files, cache, or bytecode. Terminal topology nevertheless recorded `manifest` and `terminal` as empty descendants because their reserved files were excluded from the projection.

47. **Audit seal/no-postseal:** One seal transition; terminal descriptor reserved and inode-bound; terminal frame prepared before seal; only the precomputed frame and nonreturning exit followed. Terminal record size `6,197`, SHA-256 `bc10e2fe29be0b91e77ff127e00e90019d30376caf9da4eb87de1149dda5206a`. Capsule `closure_pass=false` because of the empty-descendant result above.

48. **Subject mutation:** Not performed. Subject cleanup, chmod, repair, relocation, or reseal was not performed.

49. **Authority promotion:** No promotion or rebinding occurred.

50. **Product/runtime/target/A6:** No product or live-service invocation, target audit, runtime-validation rerun, publication, deployment, or A6 activity occurred.

51. **Remaining uncertainty/nonclaims:** The exact subject’s independent acceptability remains unadjudicated. The emitted 946/137 nonpasses and five supposed subject findings cannot support subject repair or reconstruction. No authority or readiness claim follows.

52. **Explicit audit confirmations:** The capsule projected all 83 values as `true`, but that projection conflicts with retained evidence and was hard-coded. Evidence-adjudicated status:

```text
✓ REPLACEMENT_SUBJECT_ROOT_IDENTITY_MATCHED
✓ REPLACEMENT_CONSTRUCTION_WRAPPER_AUTHENTICATED
✓ ACCEPTED_IMPLEMENTATION_AUDIT_CHAIN_AUTHENTICATED
✓ CURRENT_CONTENT_BUNDLE_IDENTITY_MATCHED
✓ CURRENT_CONTENT_AUTHORITY_IDENTITY_MATCHED
✓ INDEPENDENT_AUDIT_SOURCE_CREATED
✓ INDEPENDENT_AUDIT_SOURCE_IMPORTS_NO_PRODUCER_OR_HISTORICAL_AUDIT_HELPERS
✓ INDEPENDENT_AUDIT_SOURCE_FROZEN
✓ HISTORICAL_AUDIT_REGRESSION_REQUIREMENTS_RETAINED
✓ DUAL_ORACLE_AUDIT_CONTRACT_FROZEN
✓ AUDIT_LOGIC_QUALIFICATION_MATRIX_PASSED
✓ SUBJECT_TEMPORAL_INVENTORY_IDENTITY_MATCHED
✓ SUBJECT_MANIFEST_A_IDENTITY_MATCHED
✓ SUBJECT_MANIFEST_B_IDENTITY_MATCHED
✓ SUBJECT_MANIFESTS_BYTE_IDENTICAL
✓ SUBJECT_TERMINAL_REPROJECTION_PASSED
✓ SUBJECT_ROOT_ROW_PRESENT_EXACTLY_ONCE
✓ SUBJECT_PHYSICAL_CLOSURE_MATCHED_MANIFESTS
✓ NORMATIVE_CONTRACT_BYTES_UNCHANGED
✓ EXACTLY_FIFTEEN_CURRENT_SCHEMA_ROLES
✓ EXACTLY_FOURTEEN_GENERATED_RECORD_FAMILIES
✓ NORMATIVE_CONSTRUCTION_PARENT_NOT_COUNTED_AS_GENERATED_FAMILY
✓ SCHEMA_ROLE_TO_FAMILY_MAPPING_COMPLETE
✓ ALL_FIFTEEN_SCHEMAS_METASCHEMA_VALID
✓ FOURTEEN_CONTRACT_WITNESSES_SCHEMA_VALID
✓ FOURTEEN_SCHEMA_WITNESSES_CONTRACT_VALID
✓ WITNESS_AGGREGATE_HAS_NON_NULL_DIRECT_EVIDENCE
✓ ZERO_JOINTLY_UNSATISFIABLE_RECORD_FAMILY
✓ ZERO_UNDER_ENFORCED_BASELINE_RECORD_FAMILY
△ GENERATED_RECORD_NEGATIVE_MATRIX_946_COMPLETED — rows emitted, result nonoperative
✓ EVERY_NONPASSING_946_ROW_RETAINED
△ CONTRADICTION_REGRESSION_137_COMPLETED — rows emitted, result nonoperative
✓ EVERY_NONPASSING_137_ROW_RETAINED
✗ DUAL_ORACLE_RESULTS_AGREE
✓ CONTRACT_SCHEMA_FIELD_MAP_766_333_CLOSED
✓ EXACT_CURRENT_DOCUMENTARY_VALIDATOR_ROLE_SET
✓ ALL_CURRENT_DOCUMENTARY_VALIDATOR_RESULTS_PRESENT
△ ALL_CURRENT_DOCUMENTARY_VALIDATOR_RESULTS_PASSED — retained results pass; independent closure invalid
△ CONFIRMATION_EVIDENCE_MAP_COMPLETED — evaluated, aggregate failed derivatively
✓ DERIVATIVE_CONFIRMATIONS_NOT_COUNTED_AS_INDEPENDENT_BLOCKERS
✗ EXPLICIT_CONFIRMATIONS_EVIDENCE_DERIVED
✗ CURRENT_ROLE_OCCUPANCY_COMPLETE
✓ NO_HISTORICAL_CLOSURE_OUTPUT_CURRENT
✓ NO_FAILED_ARTIFACT_CURRENT
✓ IMPLEMENTATION_PRESENT_FALSE
✓ IMPLEMENTATION_AUTHORITY_FALSE
✓ PRODUCER_PACKAGE_NOT_SELF_PROMOTED
✓ INDEPENDENT_SUBJECT_ACCEPTANCE_NOT_PRECLAIMED
✓ EVERY_DIRECT_BLOCKER_HAS_NON_NULL_DIRECT_EVIDENCE
✓ EVERY_DIRECT_BLOCKER_HAS_PRIMARY_REPAIR_OWNER
✗ FINDING_OWNERSHIP_COMPLETE
✓ EVERY_REQUIRED_AUDIT_PHASE_TERMINAL
✓ CHILD_ORDINALS_COMPLETE_AND_CONTIGUOUS
✓ ALL_CREATED_CHILDREN_REAPED
✓ ALL_CHILD_DESCRIPTORS_CLOSED
✓ AUDIT_CLEANUP_SET_EQUALITY_PASSED
✓ SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
✓ AUDIT_TEMPORAL_INVENTORY_CREATED
✓ AUDIT_TEMPORAL_INVENTORY_VERIFIED
✓ AUDIT_MANIFEST_A_CREATED
✓ AUDIT_MANIFEST_B_CREATED
✓ AUDIT_MANIFESTS_BYTE_IDENTICAL
✓ AUDIT_TERMINAL_REPROJECTION_PASSED
✓ AUDIT_ROOT_ROW_PRESENT_EXACTLY_ONCE
✗ NO_EMPTY_DESCENDANT_AT_AUDIT_TERMINAL_CLOSURE
✓ NO_SYMLINK_OR_SPECIAL_OBJECT
✓ NO_MULTIPLY_LINKED_FILE
✓ ALL_AUDIT_DIRECTORY_MODES_0700
✓ ALL_AUDIT_FILE_MODES_0600
✓ NO_AUDIT_CACHE_OR_BYTECODE_RETAINED
✓ SINGLE_AUDIT_SEAL_TRANSITION
✓ NO_WRITE_AFTER_AUDIT_TERMINAL_SEAL
✓ REPLACEMENT_SUBJECT_MUTATION_NOT_PERFORMED
✓ REPLACEMENT_SUBJECT_CLEANUP_NOT_PERFORMED
✓ CURRENT_AUTHORITY_PROMOTION_NOT_PERFORMED
✓ CURRENT_AUTHORITY_REBINDING_NOT_PERFORMED
✓ NO_NETWORK_CONTACT
✓ NO_GIT_INVOCATION
✓ NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
✓ NO_TARGET_AUDIT_EXECUTED
✓ NO_RUNTIME_VALIDATION_RERUN
✓ NO_A6_ACTIVITY
✓ NO_SUBAGENTS_CREATED
```
