A3 is a clean success and the correct continuation point is now **a wholly fresh Repair 10I-B3**, not another successor amendment and not a resumption of either failed B child.

The report closes the precise B2 defect in the right way:

- It changed only the three authorized successor files.
- It preserved source lines and offsets as material fields instead of adding source-version-specific line-number branches.
- It reduced the governed-final panic unknowns from 24 to zero while preserving lifecycle and terminal identities.
- It left historical HEAD and Repair 9 semantics byte-identical and at zero unknowns.
- It rebuilt the four successor binaries independently on A and B with byte equality and inode separation.
- It sealed A3 and left the repository, A/A2, Phase H, and the failed B/B2 children unchanged.

The fact that the runner and comparator binaries changed even though their source files did not is expected: both link the modified `envelope` package. There is no scope anomaly in that alone.

A3 remains implementation evidence, not independent acceptance. The next task must freshly execute all five controls using A3. Nothing from B2 should be promoted as a completed source control. The earlier A2 lineage explicitly required a fresh B restart rather than continuation from partial results.  

Pass this to Codex:

```text
Objective

Execute Repair 10I-B3 from the beginning using the sealed Repair 10I-A3
successor.

Freshly run and independently qualify all five source controls, perform the five
required semantic comparisons, run two independent product A/B preparations and
direct byte comparisons, seal the complete Repair 10I-B3 evidence child, and
only then create and verify a new Option-B integrated source ZIP, audit handoff,
and capture child.

Do not repair source or successor code during this turn.

If any repository or successor defect is discovered, stop with the applicable
blocking verdict. Do not patch it inside B3.

Repository

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Required new evidence child, absent at opening

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-b3-closure-4dd211207800

Required new public targets, absent at opening

/Users/ds/Downloads/ES-T2AP-repair10-integrated-4dd211207800-i10b3.zip

/Users/ds/Downloads/ES-T2AP-repair10-integrated-4dd211207800-i10b3-audit-handoff.md

Required new capture child, absent at opening

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/snapshot-4dd211207800-i10b3

No subagents. You are the sole operator.

No repository or successor source mutation is authorized.

## 1. Immutable inputs

Repair 10I-A:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a-closure-00280085500a

Expected manifest:
dcfc3fbb0db26ba4fda8a899c839781a6a86abdf32a45a39e3b29c1b4b20b2a7

Expected payload count:
334

Repair 10I-A2:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a2-successor-closure-4dd211207800

Expected manifest:
f3e78a4286751248444243591dba49ab222ebba396952877e225d3f5ab1c4cf7

Expected payload count:
210

Repair 10I-A3:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a3-successor-closure-4dd211207800

Expected successor:
- T:
  6d4d9bd209dc67ebef2ae6f33451841766b74bf7
- inventory:
  d28c0e10247c805c2e50e9e894e361ea2d6fee93431a6ecd36e5c0df9670505f
- members:
  12

Expected A3 manifest:
a13558be3a3cae274a9654496633041cb5b47a83af3d94b73655d7fccbda252b

Expected payload count:
292

Expected detached-digest file SHA-256:
f7040f7f66ee30b40084ef2818d7d5cdcf9d77ac10d9fc0c0cf4b16d427c911c

Expected A3 binaries:

repair10-runner
- size: 5,587,714
- SHA-256:
  aba83c2a19664ae3adfc16633bf3dfe1ae10db1ee2201b96d253d249e147377f

repair10-compare
- size: 4,597,410
- SHA-256:
  f5ace5d0ade46af4b444756f4da549fc8aff14a5fdd141ae73623c7daf2fde1d

repair10-semantic
- size: 4,129,186
- SHA-256:
  5a71e78080fa9fdd06147a95044cdf6135251e4ad16eca49dd148c86fcfb3dc6

repair10-fixture
- size: 7,709,426
- SHA-256:
  d058ebdeb01b960868e4784abafbaaef9d57e8e71b12bdaa71f55aca9786c2f4

Phase H:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-h-closure-503d27bfe70d

Expected manifest:
fdfc710eca48306813f505766f70da35f23e34e32f177f714ab178ee4eee1abb

Expected payload count:
6,191

Failed B and B2 children are immutable, nonqualifying historical evidence:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-b-closure-4dd211207800

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-b2-closure-4dd211207800

Do not resume, seal, rename, clean, or overwrite either failed child.

## 2. Mandatory opening gate

Before creating B3, verify:

Repository:
- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- upstream:
  absent
- index SHA-256:
  012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31
- source T:
  4dd2112078004c3d82d24a5167f16a6f25fe33ed
- source inventory:
  2e77086590f3456474c2fdd8b64e9d2ea490dac9a04c45c2b091da2fcba210b0
- membership:
  389 total / 375 tracked / 14 nonignored untracked
- staged/deleted/renamed/unmerged:
  0/0/0/0
- protected package.go SHA-256:
  168c5dbbc3954fd25a0daad9757e09b398638aac2fdf25426b5555cb5c3fbcd6
- package_test.go SHA-256:
  046db5a2e55f81fb754303606780eb352bc5732b49fc999f91db6ce54d010f3f

Reverify every immutable manifest completely, not only its aggregate hash.

Require all B3 and capture targets listed above to be absent.

Stop before creating B3 on any mismatch:

REPAIR10I_B3_BASELINE_MISMATCH

## 3. Posture and authority

This is Repair 10I-B validation, evidence, and capture only.

Authorized:
- create the exclusive B3 evidence child;
- create private, no-hardlink controls;
- run repository tests and private product preparation;
- copy exact immutable successor binaries into controls;
- generate private evidence;
- seal B3;
- after B3 sealing, create one Option-B snapshot/capture from absent targets.

Not authorized:
- repository source edits;
- successor source edits;
- mutation of A, A2, A3, H, B, or B2;
- staging, commit, push, PR, merge;
- installation or live route execution;
- remote contact;
- Linux binary execution;
- T2A-I or T2B work;
- self-declared independent audit.

Repair 10I-A3 is the sole active successor authority.

A/A2/H/B/B2 are historical or predecessor evidence only.

## 4. B3 evidence layout

Create B3 exclusively under umask 077 with exactly these top-level directories:

opening/
tool/
commands/
validation/
baselines/
comparisons/
preparation/
builds/
findings/
closeout/

Files must be regular, single-link, non-symlink entries with intended evidence
mode 0600 or 0700. Directories must be 0700. No hardlinked evidence.

Retain all failed and superseded attempts. Never overwrite them.

## 5. Successor opening hard gate

Before any source control executes:

1. Reverify all 12 A3 successor source members.
2. Reverify both retained A/B binary sets and the four expected binary identities.
3. Reverify A3’s vulnerable-precondition result:
   - A2 final semantics unknown count 24;
   - A3 final semantics unknown count 0;
   - exactly 24 diagnostic records changed;
   - 564 unchanged;
   - lifecycle count 6,252 unchanged;
   - terminal count 2,926 unchanged;
   - source lines 1269 and 1252 preserved;
   - offsets +0x6c and +0x7c preserved.
4. Reverify historical HEAD and Repair 9 A3 semantic outputs:
   - unknown count zero;
   - exact reported SHA-256 values;
   - no lifecycle or terminal drift.
5. Require A3 source and binary A/B inode separation.
6. Copy, rather than hardlink, the exact A3 binaries into B3’s private tool roots.
7. Verify copy-to-origin byte equality and distinct inodes.

Do not rebuild or amend A3 unless a mismatch is found. A mismatch stops B3.

## 6. Source controls

Materialize five completely independent no-hardlink source controls:

1. historical HEAD
2. exact Repair 9
3. pristine final Repair 10I
4. intentional final-only mutant
5. fresh independent pristine final Repair 10I

Every control receives distinct physical:

- source
- Git administration and object store
- HOME
- XDG_CONFIG_HOME
- XDG_CACHE_HOME
- GOPATH
- GOMODCACHE
- GOCACHE
- GOTMPDIR
- TMPDIR
- runtime root
- PackageFloor
- evidence root
- socket/listener state
- process group/session state

No control may share mutable state with another.

Source identities:

Historical HEAD:
- commit:
  567bceced5df95ecfe787cc66038d463a854e12c
- tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338

Repair 9:
- T:
  0ea3b661f09e73e1126bae0f6e993e22bbf21198
- inventory:
  7b8cfa43f5338a15b632a3ce8fc20f8df56a192702d951b4d5967deba494199e
- members:
  382

Final:
- T:
  4dd2112078004c3d82d24a5167f16a6f25fe33ed
- inventory:
  2e77086590f3456474c2fdd8b64e9d2ea490dac9a04c45c2b091da2fcba210b0
- members:
  389

Fresh final:
- same logical T/inventory/membership as final;
- physically independent source, Git, cache, runtime, process, socket, and
  evidence state.

Use `source_class: pristine-final` for both final and fresh-final controls.
Control identity, physical roots, and provenance distinguish them. Do not invent
another source class.

Each control executes literally:

go test -json -count=1 -p=1 -parallel=1 ./...

Expected process exit membership is {0,1}. Qualification depends on raw semantic
integrity, not exit code alone.

For every control retain:

- source inventory and pure T;
- suite specification;
- command intent;
- exact argv/cwd/environment;
- effective read policy;
- raw stdout/stderr through EOF;
- exit and Wait disposition;
- command result;
- terminal reconciliation;
- resource ledger;
- two fresh post-clean observations;
- producer semantic extraction;
- opposite-side independent raw re-extraction;
- producer and peer qualification;
- source/tool/spec/result lineage.

Any unknown diagnostic, malformed stream, duplicate or missing terminal,
unqualified resource disposition, forced cleanup, survivor, EOF failure, or
opposite-side re-extraction mismatch blocks the control.

## 7. Intentional mutant

Construct the mutant before execution from exact final source.

Retain and seal its provenance before launching its suite.

The sole changed path remains:

es/externaltls/internal/statusobservation/remoteobserver/observe_test.go

Insert exactly:

t.Fatal("intentional Repair 10I mutant")

at the governed insertion site used by the Repair 10I plan.

Retain:

- base path/mode/size/SHA-256;
- resulting path/mode/size/SHA-256;
- exact insertion offset and context digest;
- sole changed-path set;
- base T/inventory;
- effective mutant T/inventory;
- immutable pre-execution source inventory;
- provenance payload SHA-256.

Require no second changed path, mode change, or mutation after suite launch.

The intended semantic delta must be exactly:

- the declared test pass→fail transition;
- its necessary enclosing package terminal transition;
- the exact declared diagnostic tuple;
- no other lifecycle, diagnostic, unknown, panic, race, warning, skip, package
  abort, malformed-stream, or resource change.

## 8. External requalification

Use the opposite A3 successor side for every control.

Qualification must:

- reopen and identity-bracket raw streams;
- re-extract semantics from raw bytes;
- reject stored producer captions as proof;
- require canonical semantic bytes to match independently derived bytes;
- bind source class, source T/inventory, suite spec, command result, terminal
  reconciliation, raw stream, extractor identity, and mapping identity;
- require zero unknowns;
- require complete resource and cleanup disposition.

All five controls must independently qualify before any comparison starts.

If any source or tool defect is found, stop:

REPAIR10I_B3_SOURCE_OR_TOOL_REPAIR_REQUIRED

Do not edit source.

## 9. Five semantic comparisons

Create and retain five exact comparison specifications.

Required results:

1. final ↔ fresh
   - both independently qualified;
   - lifecycle equal;
   - diagnostics equal;
   - canonical semantics equal;
   - unknown count zero;
   - AcceptedEqual=true;
   - Outcome=qualified-equal;
   - exit 0.

2. final ↔ mutant
   - both independently qualified;
   - exactly the declared mutant delta;
   - unknown count zero;
   - AcceptedEqual=false;
   - Outcome=qualified-different;
   - exit 2.

3. mutant ↔ fresh
   - both independently qualified;
   - exactly the declared mutant delta in the opposite direction;
   - unknown count zero;
   - Outcome=qualified-different;
   - exit 2.

4. HEAD ↔ final
   - both independently qualified;
   - qualified-different;
   - no undeclared final-only:
     - fail;
     - skip;
     - disappearance;
     - package abort;
     - panic;
     - race;
     - warning;
     - malformed stream;
     - unknown diagnostic;
   - exit 2.

5. Repair 9 ↔ final
   - same independent no-regression requirement;
   - exit 2.

Compare HEAD→final and Repair9→final separately. Never union the baselines.

A declared new passing identity is permitted only when explicitly represented in
the comparison specification. Every hazardous new or disappeared identity
blocks.

Factual raw-byte difference may remain visible. It must not prevent final/fresh
canonical accepted equality when all typed semantics are equal and qualified.

Any late custody, close, terminal, resource, or qualification fault forces exit
1 and AcceptedEqual=false even when factual semantic bytes match.

## 10. Product A/B preparation

Only after all five comparisons pass, create two fully independent final-source
product controls A and B.

Each side must have independent:

- source;
- private Git repository/common object store/refs/index;
- HOME/XDG;
- GOPATH/GOMODCACHE/GOCACHE/GOTMPDIR/TMPDIR;
- runtime root and slots;
- PackageFloor and generation hierarchy;
- process/session state;
- sockets/listeners;
- evidence and retained-output roots.

Construct the same deterministic synthetic commit C over exact final T.

Run the required exact-candidate compiler-input and deterministic preparation
tests with:

ES_T2AP_PRIVATE_REPOSITORY
ES_T2AP_PRIVATE_COMMIT
ES_T2AP_PRIVATE_TREE

No required test may skip.

Require both sides to independently produce identical:

- C
- T
- artifact digest D
- evidence digest E
- compiler-input closure
- module closure
- GOROOT closure
- tool identities
- source inventory

While origins are live:

- open both artifact files and compare through EOF;
- open both `build-evidence.v2.json` files and compare through EOF;
- retain independent mode-0600, single-link copies;
- compare origin→retained copies through EOF;
- verify no inode aliases or hardlinks;
- parse evidence and independently recompute its C/T/D and source/compiler/module/
  GOROOT/tool bindings.

Then:

- close every comparison descriptor;
- remove both mutable controls;
- perform two fresh post-clean absence epochs;
- retain only authorized B3 evidence and the four retained payload copies.

Any C/T/D/E or byte mismatch blocks B3.

## 11. Carry-forward Repair 10I-A evidence

Reverify, but do not mutate or falsely reproduce:

- Repair 10I-A repository validation;
- module verification;
- vet;
- four cross-build records;
- protected package.go identity;
- exact repository source T/inventory.

Because repository bytes are unchanged after I-A, these sealed results may be
carried into the B3 implementation report as predecessor validation evidence.

Clearly label them:
- sealed Repair 10I-A validation;
- not freshly rerun by B3.

B3’s five full-suite controls and product A/B are fresh validation against the
same source bytes.

## 12. B3 closeout and seal

Before sealing:

- recompute repository T/inventory/membership;
- verify branch/HEAD/parent/HEAD tree/upstream/index;
- verify staged/deleted/renamed/unmerged remain zero;
- verify protected package.go and every non-I-A source member;
- reverify A, A2, A3, H, B, and B2;
- prove no Git operation marker or lock;
- prove no private process, group, descriptor, socket, listener, cache, source,
  Git store, runtime root, fixed slot, PackageFloor, generation, build, mutant,
  or temporary report remains;
- perform two absence epochs.

Retain:

- all opening and closing identities;
- all five source-control inputs and results;
- mutant provenance;
- all producer and peer qualifications;
- all five comparison specs/results/custody records;
- product A/B source and ownership topology;
- C/T/D/E and byte-comparison transcripts;
- retained A/B payloads;
- failed and superseded attempts;
- complete command index;
- literal assertion mapping;
- provenance recipe and payload inventories;
- cleanup and absence records;
- implementation report;
- B3 closeout adjudication.

Install the detached digest first.
Install `evidence-manifest-v1.txt` as the final B3 mutation.
Write nothing into B3 afterward.
Perform complete read-only post-seal verification.

B3 readiness must be false unless:

- all five source controls qualified;
- final/fresh is accepted equal with exit 0 and zero unknowns;
- the mutant comparisons show exactly the intended delta;
- both historical comparisons independently show no undeclared regression;
- product A/B C/T/D/E and actual bytes are equal;
- cleanup and sealing are complete.

## 13. Option-B integrated capture

Begin capture only after B3 is sealed and reverified.

Use an outer capture recorder from before the first capture command. It owns:

- exact caller argv;
- cwd;
- bounded environment;
- raw stdout/stderr through EOF;
- process birth/session/group identity;
- exit;
- Wait/reap disposition;
- failure/recovery records.

Do not infer or synthesize a failed caller record later.

Required public targets and capture child must still be absent.

Option-B acceptance identity binds:

- exact ZIP bytes, size, and SHA-256;
- safe unique member paths;
- allowed member types and logical modes;
- raw ZIP headers;
- CRCs;
- complete membership;
- source inventory and T;
- two independent inode-disjoint extractions;
- archive regular-file type;
- mode 0600;
- single link;
- captured effective owner UID/GID;
- atomic same-filesystem no-clobber publication;
- completed write, fsync, close, directory sync, and publication record;
- forward and reverse handoff bindings;
- sealed capture manifest.

Container ctime, birth time, device/inode transport identity, host flags, and
host-managed xattr names/value digests are supplementary report-only metadata.

Do not claim historical equality for those values without an opening baseline.
Do not intentionally mutate xattrs.

On any failure:

- retain original caller records and all completed evidence;
- do not overwrite or reuse the target;
- do not retroactively qualify a partial capture;
- stop with the capture-blocked verdict.

Seal the capture child after publication, verification, handoff construction,
cleanup, and closing equality.

No independent audit occurs in this turn.

## 14. Stop verdicts

Opening mismatch:

REPAIR10I_B3_BASELINE_MISMATCH

Source or successor defect:

REPAIR10I_B3_SOURCE_OR_TOOL_REPAIR_REQUIRED

Validation, comparison, product A/B, cleanup, or B3 sealing failure:

REPAIR10I_B3_VALIDATION_BLOCKED

Capture failure after B3 sealing:

REPAIR10I_B3_CAPTURE_BLOCKED

Complete success:

REPAIR10I_B3_SEALED_INTEGRATED_SNAPSHOT_CREATED_READY_FOR_FRESH_AUDIT

The success report must include:

- repository T/inventory/membership;
- A3 source and binary identities;
- five control raw/semantic/qualification identities;
- all five comparison outcomes and reason codes;
- exact mutant provenance;
- product A/B C/T/D/E and compared byte counts;
- B3 manifest identity and payload count;
- ZIP identity, member count, extraction identities, and T;
- handoff identity;
- capture-child manifest identity and payload count;
- opening/closing repository and Git equality;
- cleanup and absence results;
- failed/superseded attempts;
- explicit nonclaims.

Do not create subagents.
Do not edit repository or successor source.
Do not stage, commit, push, install, invoke a live route, contact a remote host,
execute Linux binaries, or perform an independent audit.
```

The gate after a successful B3 remains a **fresh read-only independent audit**. Implementation validation and independent audit must stay separate; the project protocol explicitly assigns audit to a later fresh conversation against exact bytes.  Provenance at B3 and capture closeout proves byte identity, not correctness or authority, so the later audit must independently inspect source, tests, evidence, and comparison semantics. 

### Sources

- Codex’s Repair 10I-A3 report in the current conversation.
- Sealed A2 predecessor report and its required fresh-B restart point.  
- Governed Execution implementation/audit separation protocol. 
- Governed Execution provenance and audit guidance. 

**Confidence:** 0.99 that A3 closes the exact B2 semantic-grammar blocker; 0.98 that no additional successor amendment is justified before B3; 0.96 that B3 must restart all five controls and not reuse B2’s partial execution as qualification.
