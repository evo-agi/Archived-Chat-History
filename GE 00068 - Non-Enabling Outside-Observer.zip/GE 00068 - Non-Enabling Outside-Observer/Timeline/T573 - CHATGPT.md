## Engineering assessment

The 946-case outcome-projection repair is complete, qualified, frozen, and ready for exactly one successor real audit.

The repair addresses the demonstrated defect rather than suppressing the historical result:

- all 946 subject rows were passing;
- the predecessor harness had incorrectly projected ordinals 1–907 as blockers by comparing descriptive prose with governed reason-class tokens;
- every projected row still had `pass:true`;
- the projected findings lacked the mandatory actionable fields. :chatgpt-content-reference{index="0"}

The successor now separates:

- governed expected acceptance, outcome token, and semantic reason class;
- independently observed acceptance, outcome, reason class, validator keyword, and documentary result;
- report-only prose, which cannot participate in semantic comparison. :chatgpt-content-reference{index="1"}

Direct findings are now gated correctly. A 946 row can create a blocker only after two independent projections agree on an exact structured mismatch and the finding contains non-null evidence, a governing pointer, repair owner, repair surface, byte-change posture, reconstruction posture, and re-audit posture. A passing row or prose-only difference cannot create a finding. Zero valid findings cannot produce `BLOCK`. :chatgpt-content-reference{index="2"}

### Qualification result

The repair passed all material gates:

- 984 projection-matrix cases passed;
- the historical 907-row false-blocker corpus now produces zero findings and zero audit errors;
- all 946 current replacement-subject rows were evaluated by both successor oracles with zero semantic mismatches, disagreements, or exceptions;
- all nine prior qualification matrices retained their exact names and expected results. :chatgpt-content-reference{index="3"}

The packaged rehearsals also cover the required terminal outcomes:

- valid ACCEPT;
- one complete direct 946 BLOCK;
- ambiguous reason → provenance mismatch;
- historical 907-row regression → zero findings;
- incomplete finding schema → provenance mismatch rather than false BLOCK. :chatgpt-content-reference{index="4"}

The source then froze, deterministic packaging succeeded, post-package qualification passed, certificate validation passed, and frozen-package requalification passed. :chatgpt-content-reference{index="5"}

### Current authority-bearing artifacts

```text
/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-outcome-projection-output-bjm8ily7/gen2-replacement-schema-subject-independent-audit-v3.pyz
```

- inode: `182836502`
- mode: `0400`
- size: `14,537,525`
- SHA-256: `60b62e1e41a79c7b154f50aad34a451c26f819eb7eecf127999026791ced25db`

```text
/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-outcome-projection-output-bjm8ily7/gen2-replacement-schema-subject-independent-audit.authority-v3.json
```

- inode: `182836506`
- mode: `0400`
- size: `28,318`
- SHA-256: `f4adc99efe033cbdbfdd28a2970d215f6bd0c7e9f0bbbe21d3fcf219cc79ae26`

```text
/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-outcome-projection-output-bjm8ily7/gen2-replacement-schema-subject-independent-audit.launch-profile-v5.json
```

- inode: `182836514`
- mode: `0400`
- size: `14,417`
- SHA-256: `ab682c027344ea98fcd78d3494d1a4f503a3ef6d337db5dc56bbd5750937ffa3`

```text
/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-outcome-projection-output-bjm8ily7/gen2-replacement-schema-subject-independent-audit.launch-certificate-v6.json
```

- inode: `182836518`
- mode: `0400`
- size: `18,164`
- SHA-256: `063c5c3bd57840bdeec550ff17e19c7134961f6df4126a1383853526d77b4894` :chatgpt-content-reference{index="6"}

Exactly one successor real-audit authorization is active and unconsumed. The predecessor authorization is consumed and historical. No real audit ran in this repair task, and no subject verdict was issued. :chatgpt-content-reference{index="7"}

## Progression decision

Execute exactly **one real independent audit** now.

No additional harness repair, packaging, launch-authority, construction, or reconciliation work is justified beforehand.

The external wrapper should use only the current successor chain:

1. PYZ v3;
2. runtime authority v3;
3. launch profile v5;
4. launch certificate v6;
5. the unchanged replacement subject;
6. its construction wrapper;
7. current content bundle and authority;
8. accepted implementation authority roots.

The audit wrapper must enforce the repaired finding coherence independently:

```text
valid direct finding count
=
exact independently nonpassing row count
```

A passing 946 row must never create a finding. A raw `BLOCK` with zero valid direct findings must be demoted to `AUDIT_PROVENANCE_MISMATCH`.

---

## Complete replacement Codex prompt

```text
EXECUTE EXACTLY ONE REAL INDEPENDENT AUDIT OF THE UNCHANGED
REPLACEMENT GENERATION-2 SCHEMA SUBJECT

USING SUCCESSOR AUDIT PYZ V3, RUNTIME AUTHORITY V3,
LAUNCH PROFILE V5, AND LAUNCH CERTIFICATE V6

Objective

Execute exactly one real independent audit of:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-z1o1vs54

Use only these current audit artifacts:

1. successor audit PYZ v3;
2. successor runtime authority v3;
3. successor split-root launch profile v5;
4. successor launch certificate v6;
5. unchanged replacement subject;
6. replacement construction wrapper;
7. current content bundle and authority;
8. accepted implementation authority chain.

The predecessor PYZ v2, runtime authority v2, profile v4, and certificate v5
are historical. Certificate-v5’s authorization was consumed by the prior real
audit and must not be reused.

Certificate v6 contains the sole active, unconsumed real-audit authorization.

Authenticate every current authority artifact before allocating a wrapper root,
workspace, or creating a process.

Use the exact split-root lifecycle governed by profile v5:

- allocate an existing wrapper-owned workspace;
- submit that workspace as cwd;
- derive its exact absent capsule child;
- pass that absent child as `--output-root`;
- do not precreate the child;
- require the frozen runtime to create it;
- require the terminal frame and capsule records to bind the child rather than
  the workspace.

Execute the current platform preflight exactly once.

Then execute the real audit parent exactly once.

Capture process creation and completion exactly.

After completion:

- retain raw stdout and stderr before parsing;
- parse only under the current framing contract;
- authenticate the exact capsule root;
- inspect the capsule read-only;
- authenticate the substantive audit evidence and terminal closure;
- retain the raw harness disposition;
- derive the wrapper verdict;
- stop.

Do not modify, repair, resume, clean, remove, or rerun the capsule.

Do not execute qualification, rehearsal, or synthetic mode.

Do not launch a replacement, recovery, continuation, post-failure validator, or
second audit parent.

Do not run another direct subject auditor outside the frozen harness.

Do not execute subject source.

Do not rerun subject construction.

Do not promote or rebind current schema authority.

Do not combine audit and authority promotion.

Do not modify a repository.

Do not use Git or another VCS.

Do not read `.git`.

Do not use the network.

Do not install dependencies.

Do not invoke product or live-service behavior.

Do not run target audit.

Do not rerun product runtime validation.

Do not publish, deploy, externally commit, or begin A6.

Do not create subagents or direct auditors.

Return the complete operative report inline.

Return exactly one wrapper verdict:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_ACCEPT

GEN2_REPLACEMENT_SCHEMA_SUBJECT_BLOCK

AUDIT_PROVENANCE_MISMATCH

Retain the exact raw harness disposition separately.

Map only exact current governed tokens:

SUBJECT_AUDIT_ACCEPT
→ GEN2_REPLACEMENT_SCHEMA_SUBJECT_ACCEPT

SUBJECT_AUDIT_BLOCK
→ GEN2_REPLACEMENT_SCHEMA_SUBJECT_BLOCK

SUBJECT_AUDIT_PROVENANCE_MISMATCH
→ AUDIT_PROVENANCE_MISMATCH

Do not normalize an unknown token.

A raw SUBJECT_AUDIT_BLOCK may be promoted only when every direct blocker
satisfies the evidence rules below.

If any prelaunch gate fails before audit-parent process creation, return:

AUDIT_PROVENANCE_MISMATCH

and explicitly state:

REAL_REPLACEMENT_SUBJECT_AUDIT_NOT_EXECUTED
SUCCESSOR_REAL_AUDIT_AUTHORIZATION_NOT_CONSUMED

──────────────────────────────────────────────────────────────────────────────
1. SUCCESSOR AUDIT PYZ V3
──────────────────────────────────────────────────────────────────────────────

SUCCESSOR_AUDIT_PYZ_V3:

/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-outcome-projection-output-bjm8ily7/gen2-replacement-schema-subject-independent-audit-v3.pyz

Expected identity:

- inode:
  182836502
- mode:
  0400
- link count:
  1
- size:
  14537525
- SHA-256:
  60b62e1e41a79c7b154f50aad34a451c26f819eb7eecf127999026791ced25db

Observe and retain device.

Require a device predicate only when governed by current authority.

──────────────────────────────────────────────────────────────────────────────
2. SUCCESSOR RUNTIME AUTHORITY V3
──────────────────────────────────────────────────────────────────────────────

SUCCESSOR_RUNTIME_AUTHORITY_V3:

/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-outcome-projection-output-bjm8ily7/gen2-replacement-schema-subject-independent-audit.authority-v3.json

Expected identity:

- inode:
  182836506
- mode:
  0400
- link count:
  1
- size:
  28318
- SHA-256:
  f4adc99efe033cbdbfdd28a2970d215f6bd0c7e9f0bbbe21d3fcf219cc79ae26

──────────────────────────────────────────────────────────────────────────────
3. CURRENT LAUNCH PROFILE V5
──────────────────────────────────────────────────────────────────────────────

CURRENT_LAUNCH_PROFILE_V5:

/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-outcome-projection-output-bjm8ily7/gen2-replacement-schema-subject-independent-audit.launch-profile-v5.json

Expected identity:

- inode:
  182836514
- mode:
  0400
- link count:
  1
- size:
  14417
- SHA-256:
  ab682c027344ea98fcd78d3494d1a4f503a3ef6d337db5dc56bbd5750937ffa3

──────────────────────────────────────────────────────────────────────────────
4. CURRENT LAUNCH CERTIFICATE V6
──────────────────────────────────────────────────────────────────────────────

CURRENT_LAUNCH_CERTIFICATE_V6:

/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-outcome-projection-output-bjm8ily7/gen2-replacement-schema-subject-independent-audit.launch-certificate-v6.json

Expected identity:

- inode:
  182836518
- mode:
  0400
- link count:
  1
- size:
  18164
- SHA-256:
  063c5c3bd57840bdeec550ff17e19c7134961f6df4126a1383853526d77b4894

──────────────────────────────────────────────── LIMITED TO LINEAGE
────────────────────────────────────────────────

5. HISTORICAL CONSUMED PREDECESSORS

Historical audit PYZ v2:

/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-input-role-repair-output-v2aqmvn8/gen2-replacement-schema-subject-independent-audit-v2.pyz

Historical runtime authority v2:

/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-input-role-repair-output-v2aqmvn8/gen2-replacement-schema-subject-independent-audit.authority-v2.json

Historical profile v4:

/Users/ds/Downloads/ES-repair10i-v3-audit-launch-profile-binding-correction-output-bxpo6kwq/gen2-replacement-schema-subject-independent-audit.launch-profile-v4.json

Historical certificate v5:

/Users/ds/Downloads/ES-repair10i-v3-audit-launch-profile-binding-correction-output-bxpo6kwq/gen2-replacement-schema-subject-independent-audit.launch-certificate-v5.json

Open them only when certificate-v6 lineage validation requires external bytes.

Require:

- predecessor roles current:
  false;
- certificate-v5 authorization consumed:
  true;
- predecessor active future authorization count:
  zero;
- predecessor execution controls not used;
- predecessor mutation:
  forbidden.

Do not add unnecessary predecessor artifacts to the wrapper fixed-input set when
certificate v6 closes lineage internally.

──────────────────────────────────────────────────────────────────────────────
6. REPLACEMENT SUBJECT
──────────────────────────────────────────────── LIMITED TO AUDIT TARGET
────────────────────────────────────────────────

REPLACEMENT_SUBJECT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-z1o1vs54

Expected identity:

- device:
  16777234
- inode:
  182649818
- mode:
  0700
- UID/GID:
  501/20

Expected canonical inventory SHA-256:

eb46c6784c361962fa007c2c8638676ca8e5a810cfb91512437e008cd64beea3

Expected physical closure:

- 73 entries including root;
- 12 directories;
- 61 regular files.

Authenticate through:

- certificate v6;
- authority v3;
- subject temporal inventory and manifests;
- two stable no-follow live inventory projections.

Require all identities and canonical inventory bindings to agree.

Open only this exact root.

Do not scan for another subject.

──────────────────────────────────────────────── LIMITING CONSTRUCTION PROVENANCE
────────────────────────────────────────────────

7. REPLACEMENT CONSTRUCTION WRAPPER

REPLACEMENT_CONSTRUCTION_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-replacement-schema-subject-construction-wrapper-v3-ewh59_5a

Expected identity:

- device:
  16777234
- inode:
  182648782
- mode:
  0700
- UID/GID:
  501/0

Expected canonical inventory SHA-256:

9c6736d69b81fc0f0d06bbee8dde0a930bab284064f40c01b9ec65cf9ea5b60e

Authenticate only:

- replacement-subject allocation;
- accepted implementation use;
- construction authorization and consumption;
- production-parent custody;
- subject terminal closure;
- no second construction;
- pending-independent-audit posture.

Require certificate-v6, authority-v3, and two live projections to agree.

Require opening/closing equality.

──────────────────────────────────────────────── LIMITING ACCEPTED IMPLEMENTATION
────────────────────────────────────────────────

8. ACCEPTED IMPLEMENTATION AUTHORITY

ACCEPTED_IMPLEMENTATION_AUDIT_ROOT:

/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-mp6hex04

Expected identity:

- device:
  16777234
- inode:
  182593190
- mode:
  0700

Expected canonical inventory SHA-256:

3e88e9c4df565bf29e181eb6f9ba10f64faf07342cf0e642a7154d15f6be222d

ACCEPTED_IMPLEMENTATION_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-wrapper-se4f_xxg

Expected identity:

- device:
  16777234
- inode:
  182593189
- mode:
  0700

Expected canonical inventory SHA-256:

6d1d2176d356634176ee8717a5dce46cfb2718ba42237872b32e9d44de5ac108

Expected disposition:

GEN2_IMPLEMENTATION_PACKAGE_ACCEPT

Authenticate only:

- accepted reconstruction-parent implementation;
- accepted production source and freeze;
- accepted construction contract;
- unsuperseded implementation package;
- replacement construction used the accepted parent.

Require certificate-v6, authority-v3, and two live projections to agree.

Do not re-audit the implementation package.

Require opening/closing equality.

────────────────────────────────────────────────

9. CURRENT CONTENT INPUTS

CURRENT_CONTENT_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected identity:

- inode:
  181651092
- mode:
  0400
- link count:
  1
- size:
  13598758
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671

CURRENT_CONTENT_AUTHORITY:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected identity:

- inode:
  181651098
- mode:
  0400
- link count:
  1
- size:
  19737
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563

Authenticate content authority before interpreting the ZIP.

Require:

- exact bundle identity;
- 479 members;
- eight current roles;
- deterministic member closure;
- no `.DS_Store`.

──────────────────────────────────────────────── LIMITING CURRENT AUTHORITY
────────────────────────────────────────────────

10. STABLE PRELAUNCH AUTHENTICATION

Before allocating wrapper/workspace roots, authenticate:

- successor PYZ v3;
- runtime authority v3;
- profile v5;
- certificate v6;
- replacement subject;
- construction wrapper;
- accepted implementation roots;
- content bundle;
- content authority.

Open predecessor artifacts only when required by certificate-v6 external
lineage validation.

For every file:

- no-follow open;
- regular-file check;
- governed mode and link count;
- device/inode/size/SHA-256;
- two stable byte and metadata reads.

For every root:

- exact identity;
- two complete canonical no-follow inventory projections;
- equality of both projections;
- equality with current certificate/authority bindings.

Strict-parse all authority JSON using:

- UTF-8;
- duplicate-key rejection;
- nonfinite-number rejection.

If any prelaunch predicate fails:

- do not allocate wrapper/workspace roots;
- do not execute platform preflight;
- do not create the audit parent;
- return:
  AUDIT_PROVENANCE_MISMATCH;
- state:
  REAL_REPLACEMENT_SUBJECT_AUDIT_NOT_EXECUTED;
- state:
  SUCCESSOR_REAL_AUDIT_AUTHORIZATION_NOT_CONSUMED.

────────────────────────────────────────────────

11. CURRENT SUCCESSOR AUTHORITY CLOSURE

Validate authority v3, profile v5, and certificate v6 under their exact schemas.

Require exact agreement among:

- successor PYZ v3;
- authority v3;
- profile v5;
- certificate v6;
- replacement subject;
- construction wrapper;
- accepted implementation roots;
- content inputs;
- successor source freeze;
- successor member registry;
- structured 946 result-semantics contract;
- dual reason-projection contract;
- direct-finding eligibility contract;
- disposition-from-valid-findings contract;
- ten-role subject-input registry;
- compatibility result;
- qualification and rehearsal evidence;
- split-root policy;
- framing contract.

Require:

- successor PYZ current:
  true;
- authority v3 current:
  true;
- profile v5 current:
  true;
- certificate v6 current:
  true;
- all predecessor roles current:
  false;
- all predecessor active future authorizations:
  zero;
- certificate-v6 active authorization:
  one;
- total active future authorization:
  one;
- real audit already executed:
  false;
- subject verdict:
  not issued;
- authority promotion:
  false.

Any discrepancy:

- do not launch;
- return provenance mismatch;
- authorization remains unconsumed.

────────────────────────────────────────────────

12. SUCCESSOR PYZ MEMBER CLOSURE

Parse successor PYZ v3 directly.

Require exact correspondence with:

- authority v3;
- profile v5;
- certificate v6;
- embedded member registry.

Require:

- exactly 84 members;
- exact non-self registry closure;
- raw UTF-8 sorted names;
- ZIP_STORED;
- fixed timestamp;
- `create_system=3`;
- member mode 0600;
- no duplicate;
- no unsafe path;
- no directory member;
- no symlink/special member;
- no comment or uncontrolled extra;
- no cache or bytecode;
- no historical source.

Authenticate current embedded roles for:

- entrypoint;
- successor source freeze;
- source registries;
- structured 946 semantics;
- primary and secondary reason projectors;
- finding eligibility;
- disposition derivation;
- subject input dependency registry;
- semantic input resolver;
- compatibility result;
- 15/14 model;
- 946 and 137 vocabularies;
- total documentary checking;
- witness logic;
- field-map logic;
- documentary-validator logic;
- confirmation logic;
- occupancy vocabulary;
- capsule lifecycle;
- no-VCS contract;
- projection matrix;
- historical 907-row regression;
- packaged rehearsals;
- independent validation;
- post-package qualification;
- frozen-package requalification;
- future invocation contract.

Any discrepancy:

- do not launch;
- return provenance mismatch.

────────────────────────────────────────────────

13. WRAPPER EVIDENCE ROOT AND SPLIT-ROOT WORKSPACE

After Sections 10–12 pass, allocate:

A. WRAPPER_EVIDENCE_ROOT

Use the exact profile-v5 wrapper-evidence policy.

B. FRESH_PRIVATE_AUDIT_WORKSPACE

Use the exact profile-v5 split-root policy.

Immediately retain:

- absolute path;
- device;
- inode;
- mode;
- UID/GID;
- empty inventory.

Derive the exact absent capsule child from profile v5.

Require:

- workspace exists;
- workspace empty;
- capsule child absent;
- wrapper did not create the child;
- no alternate root;
- no scan or fallback.

Use:

- workspace as submitted cwd;
- absent child as `--output-root`.

On prelaunch failure:

- retain evidence;
- remove only wrapper-owned empty roots after revalidation;
- observe ENOENT twice;
- authorization remains unconsumed.

After audit-parent creation:

- authorization is consumed;
- preserve workspace and capsule regardless of outcome.

────────────────────────────────────────────────

14. PLATFORM-CAPTURE PREFLIGHT

Execute exactly once under profile v5.

Do not reconstruct the preflight from a predecessor profile or prompt.

Retain:

- requested and resolved interpreter identities;
- exact argv;
- cwd;
- submitted environment;
- process posture;
- PID;
- timing;
- raw streams;
- sizes and SHA-256;
- exit/signal;
- reaping;
- descriptor closure.

Require the exact profile-v5 preflight result.

Require afterward:

- workspace remains empty;
- capsule child remains absent.

If preflight fails:

- do not create the audit parent;
- authorization remains unconsumed;
- return provenance mismatch;
- do not retry.

────────────────────────────────────────────────

15. EXACT REAL-AUDIT INVOCATION

Derive exact argv exclusively from:

- profile v5;
- certificate v6;
- authority v3;
- successor embedded invocation contract.

Require current bindings for:

- successor PYZ v3;
- authority v3;
- replacement subject;
- construction wrapper;
- content inputs;
- accepted implementation roots;
- workspace cwd;
- absent capsule-child output root;
- current environment;
- current process posture.

Do not pass profile v5 or certificate v6 to the harness unless the exact current
CLI explicitly requires it.

Immediately before process creation:

- reauthenticate every fixed input;
- reauthenticate workspace;
- require workspace empty;
- require capsule child absent.

Launch exactly once and synchronously.

The certificate-v6 authorization is consumed only on successful process
creation.

After process creation, consumption is final.

Do not launch:

- qualification;
- rehearsal;
- synthetic mode;
- replacement or recovery parent;
- continuation;
- post-failure validator;
- second audit.

────────────────────────────────────────────────

16. TOP-LEVEL PROCESS CUSTODY

Retain before parsing:

- custody ID;
- process-creation result;
- PID;
- start/completion;
- duration;
- exact argv;
- cwd;
- environment;
- stdin/shell/TTY/detachment;
- raw stdout;
- raw stderr;
- stream sizes and SHA-256;
- exit;
- signal;
- process error;
- reaping;
- descriptor closure;
- fixed-input identities at launch;
- workspace identity;
- capsule-child absence at launch.

The wrapper owns top-level process custody.

If completion custody is missing:

- authorization remains consumed;
- do not scan;
- do not retry;
- return provenance mismatch.

────────────────────────────────────────────────

17. STREAM AND TERMINAL-FRAME PARSING

Retain raw streams before parsing.

Parse only under the authority-v3/profile-v5/certificate-v6 framing contract.

Require:

- governed stdout/stderr posture;
- exactly one terminal frame;
- no trailing bytes;
- strict UTF-8;
- duplicate-key rejection;
- nonfinite-number rejection;
- exact current frame schema;
- exact raw harness disposition;
- exact capsule-root binding;
- exact closure fields.

Require:

terminal-frame capsule root
=
profile-v5-derived capsule child.

If the process exits under an unhandled-failure posture:

- return provenance mismatch;
- do not scan;
- preserve workspace and capsule;
- do not retry.

────────────────────────────────────────────────

18. CAPSULE-ROOT AUTHENTICATION

Authenticate only the profile-v5-derived capsule child.

Require:

- absent before launch;
- created only after process creation;
- exact governed relationship to workspace;
- directory;
- no symlink;
- mode 0700;
- terminal-frame equality;
- capsule records bind the same root;
- workspace is not the capsule.

Do not scan or select another path.

Failure forces provenance mismatch.

────────────────────────────────────────────────

19. READ-ONLY CAPSULE INSPECTION

Inspect only the authenticated capsule root.

Do not modify, clean, chmod, resume, execute capsule source, execute subject
source, launch another validator, or regenerate evidence.

Resolve authoritative records only through:

- terminal frame;
- capsule path/role registry;
- indexes;
- manifests;
- exact evidence pointers.

Authenticate:

- successor source identities and freeze;
- no-VCS posture;
- ten-role subject-input resolution;
- no acceptance-bearing direct subject path;
- exact 15/14 model;
- complete 946 and 137 vocabularies;
- structured 946 semantics;
- independent primary/secondary reason projections;
- subject terminal closure;
- normative contract;
- schema roles and families;
- Draft 2020-12 results;
- witness rows;
- all 946 exact rows;
- all 137 exact rows;
- dual-oracle crosswalk;
- 766/333 field map;
- documentary validators;
- confirmation derivation;
- occupancy, lineage, and producer status;
- findings and repair owners;
- A00–A15;
- child custody;
- cleanup;
- supplied-input equality;
- temporal inventory;
- manifests;
- final reprojection;
- physical topology;
- A15/closure agreement;
- seal/no-postseal result.

────────────────────────────────────────────────

20. 946 ROW/FINDING/DISPOSITION COHERENCE

Independently require:

valid direct 946 finding count
=
exact independently nonpassing 946-row count

For each 946 row, distinguish:

- governed expected outcome;
- independently observed structured outcome;
- governed expected semantic reason class;
- independently observed semantic reason class;
- report-only prose.

Report-only prose must not participate in semantic comparison.

A row with `pass:true` may create a direct finding only if the two independent
oracles establish an exact structured mismatch and retain the mismatched
dimensions.

Require:

- both projectors completed;
- both projectors agree;
- no projector exception;
- no ambiguous semantic reason;
- every finding references an exact nonpassing row;
- every nonpassing row has at most one primary direct finding unless explicitly
  governed otherwise;
- every direct finding satisfies its complete schema;
- no aggregate finding without exact member rows.

If:

- 946 nonpassing-row count is zero,

then require:

- direct 946 finding count is zero.

If direct findings exist while all cited rows remain passing:

- return `AUDIT_PROVENANCE_MISMATCH`;
- do not promote BLOCK.

────────────────────────────────────────────────

21. DIRECT BLOCKER STANDARD

A raw terminal:

SUBJECT_AUDIT_BLOCK

may be promoted only when every direct blocker contains:

- exact failed witness or case row;
- non-null direct evidence;
- governing contract/schema/specification pointer;
- primary repair owner;
- exact repair surface;
- subject-byte-change posture;
- reconstruction posture;
- unchanged-subject re-audit posture.

For 946 or 137 blockers, require exact failed per-case rows.

Derivative confirmations are not independent blockers.

A required semantic subject-input role may be a direct blocker only when its
requirement, absence, and package ownership are authenticated without resolver
ambiguity.

Any:

- unhandled exception;
- resolver ambiguity;
- unauthenticated role;
- oracle disagreement;
- ambiguous semantic reason;
- invalid outcome projection;
- incomplete direct evidence;
- finding-count/nonpassing-row-count mismatch;
- hard-coded confirmation;
- occupancy-role defect;
- capsule-closure defect;

forces:

AUDIT_PROVENANCE_MISMATCH

rather than subject BLOCK.

────────────────────────────────────────────────

22. CAPSULE TERMINAL CLOSURE

Authenticate:

- temporal inventory;
- manifest A;
- manifest B;
- A/B byte equality;
- independent final reprojection;
- root row once;
- no physical empty descendant;
- no symlink/special object;
- no multiply linked regular file;
- directory/file modes 0700/0600;
- no cache or bytecode;
- A15 status equals final closure;
- one seal transition;
- no filesystem/process/validation operation after seal.

A terminal frame is insufficient without this closure.

Failure forces provenance mismatch.

────────────────────────────────────────────────

23. WRAPPER FIXED-INPUT CLOSING EQUALITY

After completion, repeat opening/closing authentication for every fixed input
actually opened:

- successor PYZ v3;
- authority v3;
- profile v5;
- certificate v6;
- predecessor artifacts only if externally opened for lineage;
- replacement subject;
- construction wrapper;
- accepted implementation roots;
- content bundle;
- content authority.

Require exact role-set closure and every row passed.

Do not mutate supplied inputs.

Failure forces provenance mismatch.

────────────────────────────────────────────────

24. FINAL VERDICT RULES

Report:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_ACCEPT

only when:

- all fixed inputs authenticate;
- successor authority closes;
- preflight passes;
- process custody completes;
- terminal framing passes;
- capsule provenance passes;
- ten-role input resolution closes;
- subject terminal closure passes;
- exact 15/14 model passes;
- all schemas pass Draft 2020-12;
- all witnesses pass;
- all 946 rows pass;
- all 137 rows pass;
- dual projectors and oracles agree;
- 766/333 closes;
- documentary-validator authority closes;
- confirmation evidence closes;
- occupancy/lineage/status close;
- valid direct finding count is zero;
- audit cleanup and equality pass;
- capsule closure passes;
- wrapper closing equality passes.

Report:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_BLOCK

only when:

- audit provenance passes;
- one or more exact independently nonpassing subject rows or another valid
  direct subject defect exists;
- valid direct finding count equals governed nonpassing evidence;
- every blocker satisfies Section 21;
- findings and dependencies are complete;
- cleanup/equality/capsule closure pass.

Report:

AUDIT_PROVENANCE_MISMATCH

for:

- fixed-input or authority mismatch;
- preflight failure;
- process-custody loss;
- framing/root failure;
- subject drift;
- source/toolchain/freeze failure;
- resolver ambiguity or unauthenticated role;
- unhandled exception;
- oracle/projector disagreement;
- ambiguous semantic reason;
- invalid outcome projection;
- finding count mismatch;
- incomplete finding schema;
- hard-coded confirmation;
- occupancy-role defect;
- cleanup inequality;
- supplied-root inequality;
- capsule-closure failure;
- A15/closure contradiction;
- postseal activity;
- wrapper equality failure.

Do not retry.

────────────────────────────────────────────────

25. NO FOLLOW-ON EXECUTION

After reporting:

- stop;
- preserve all audit and launch artifacts;
- preserve workspace and capsule;
- preserve replacement subject unchanged;
- preserve construction wrapper;
- preserve accepted implementation roots;
- preserve content inputs;
- do not promote or rebind current schema authority;
- do not construct another subject;
- do not execute product/live-service modes;
- do not run target audit;
- do not rerun runtime validation;
- do not modify a repository;
- do not publish or deploy;
- do not begin A6;
- do not launch another agent.

────────────────────────────────────────────────

26. REQUIRED INLINE OPERATIVE REPORT

Return:

1. Exact wrapper verdict
2. Exact raw harness disposition
3. Successor PYZ-v3 identity
4. Authority-v3 identity
5. Profile-v5 identity
6. Certificate-v6 identity
7. Predecessor consumed-lineage posture
8. Replacement-subject identity
9. Construction-wrapper authentication
10. Accepted implementation chain
11. Content identities
12. Stable prelaunch authentication
13. Successor authority closure
14. Successor member closure
15. Wrapper-root identity
16. Workspace identity
17. Capsule-child absence proof
18. Platform preflight
19. Exact audit argv/cwd/environment
20. Top-level process custody
21. Raw streams
22. Exit/signal
23. Terminal frame
24. Capsule-root authentication
25. Successor source/freeze/no-VCS posture
26. Ten-role subject-input resolution
27. Subject terminal closure
28. Normative contract
29. Fifteen schema roles
30. Fourteen generated families
31. Role/family mapping
32. Draft 2020-12
33. Contract-witness rows
34. Schema-witness rows
35. Witness aggregate
36. Complete 946 result
37. Exact independently nonpassing 946 rows
38. Complete 137 result
39. Exact independently nonpassing 137 rows
40. Primary 946 reason projection
41. Secondary 946 reason projection
42. Dual-projection crosswalk
43. 946 nonpassing-row count
44. Valid direct 946-finding count
45. 946 row/finding count equality
46. 766/333 field map
47. Documentary-validator closure
48. Confirmation derivation
49. Derivative-confirmation ledger
50. Occupancy, lineage, and producer status
51. Findings
52. Repair-owner registry
53. Dependency graph
54. A00–A15
55. Child custody
56. Audit cleanup
57. Capsule supplied-root equality
58. Wrapper fixed-input equality
59. Audit temporal identity
60. Audit manifest identities
61. A/B equality
62. Final reprojection
63. Physical topology/modes
64. A15/closure agreement
65. Seal/no-postseal result
66. Confirmation subject unchanged
67. Confirmation no authority promotion
68. Confirmation no product/runtime/target/A6 activity
69. Remaining uncertainty/nonclaims
70. Explicit wrapper confirmations

Required confirmations:

SUCCESSOR_AUDIT_PYZ_V3_IDENTITY_MATCHED
SUCCESSOR_RUNTIME_AUTHORITY_V3_IDENTITY_MATCHED
CURRENT_PROFILE_V5_IDENTITY_MATCHED
CURRENT_CERTIFICATE_V6_IDENTITY_MATCHED
PREDECESSOR_REAL_AUDIT_AUTHORIZATION_CONSUMED
EXACTLY_ONE_ACTIVE_SUCCESSOR_AUDIT_AUTHORIZATION
REPLACEMENT_SUBJECT_ROOT_IDENTITY_MATCHED
REPLACEMENT_CONSTRUCTION_WRAPPER_AUTHENTICATED
ACCEPTED_IMPLEMENTATION_AUDIT_CHAIN_AUTHENTICATED
CURRENT_CONTENT_BUNDLE_IDENTITY_MATCHED
CURRENT_CONTENT_AUTHORITY_IDENTITY_MATCHED
SUCCESSOR_AUTHORITY_CURRENT_AND_COHERENT
SUCCESSOR_PYZ_MEMBER_SET_84_CLOSED
WRAPPER_WORKSPACE_ALLOCATED
WRAPPER_WORKSPACE_EMPTY_BEFORE_LAUNCH
CAPSULE_CHILD_ABSENT_BEFORE_LAUNCH
WRAPPER_DID_NOT_PRECREATE_CAPSULE_ROOT
PLATFORM_CAPTURE_PREFLIGHT_PASSED
PREFLIGHT_WORKSPACE_REMAINED_EMPTY
PREFLIGHT_CAPSULE_CHILD_REMAINED_ABSENT
REAL_SUBJECT_AUDIT_EXECUTED_EXACTLY_ONCE
SUCCESSOR_AUDIT_AUTHORIZATION_CONSUMED
QUALIFICATION_MODE_NOT_EXECUTED
REHEARSAL_MODE_NOT_EXECUTED
SYNTHETIC_MODE_NOT_EXECUTED
REPLACEMENT_AUDIT_PARENT_NOT_LAUNCHED
ADMINISTRATIVE_CONTINUATION_NOT_USED
NO_DIRECT_AUDITOR_USED_OUTSIDE_HARNESS
RAW_STDOUT_RETAINED
RAW_STDERR_RETAINED
PLATFORM_EXIT_AND_SIGNAL_RETAINED
AUDIT_ROOT_SCAN_NOT_PERFORMED
TERMINAL_FRAME_STRICTLY_PARSED
TERMINAL_FRAME_ROOT_EQUALS_PROFILE_DERIVED_CAPSULE_CHILD
SUCCESSOR_CLEAN_SOURCE_FREEZE_AUTHENTICATED
NO_GIT_OR_VCS_INVOCATION
SUBJECT_INPUT_ACCESS_SET_10_COMPLETE
SUBJECT_INPUT_ACCESS_EQUAL_DEPENDENCY_REGISTRY
NO_ACCEPTANCE_BEARING_DIRECT_SUBJECT_PATH_LITERAL
NO_UNHANDLED_ENOENT
SUBJECT_TERMINAL_REPROJECTION_PASSED
NORMATIVE_CONTRACT_BYTES_UNCHANGED
EXACTLY_FIFTEEN_CURRENT_SCHEMA_ROLES
EXACTLY_FOURTEEN_GENERATED_RECORD_FAMILIES
NORMATIVE_CONSTRUCTION_PARENT_NOT_COUNTED_AS_GENERATED_FAMILY
SCHEMA_ROLE_TO_FAMILY_MAPPING_COMPLETE
ALL_FIFTEEN_SCHEMAS_METASCHEMA_VALID
FOURTEEN_CONTRACT_WITNESSES_SCHEMA_VALID
FOURTEEN_SCHEMA_WITNESSES_CONTRACT_VALID
WITNESS_AGGREGATE_HAS_EXACT_ROW_EVIDENCE
GENERATED_RECORD_NEGATIVE_MATRIX_946_COMPLETED
EVERY_NONPASSING_946_ROW_RETAINED
CONTRADICTION_REGRESSION_137_COMPLETED
EVERY_NONPASSING_137_ROW_RETAINED
PRIMARY_REASON_CLASS_PROJECTION_COMPLETED
SECONDARY_REASON_CLASS_PROJECTION_COMPLETED
DUAL_REASON_CLASS_PROJECTIONS_AGREE
NO_REASON_CLASS_PROJECTION_EXCEPTION
NO_PROSE_TO_REASON_CLASS_COMPARISON
EXACT_GOVERNED_OUTCOME_VOCABULARY_USED
DIRECT_FINDING_COUNT_EQUALS_NONPASSING_ROW_COUNT
PASSING_946_ROW_DID_NOT_CREATE_FINDING
EVERY_DIRECT_BLOCKER_HAS_NON_NULL_DIRECT_EVIDENCE
EVERY_DIRECT_BLOCKER_HAS_GOVERNING_POINTER
EVERY_DIRECT_BLOCKER_HAS_PRIMARY_REPAIR_OWNER
EVERY_DIRECT_BLOCKER_HAS_REPAIR_SURFACE
BLOCK_DISPOSITION_DERIVED_FROM_VALID_FINDINGS
CONTRACT_SCHEMA_FIELD_MAP_766_333_CLOSED
EXACT_CURRENT_DOCUMENTARY_VALIDATOR_ROLE_SET
ALL_CURRENT_DOCUMENTARY_VALIDATOR_RESULTS_PRESENT
ALL_CURRENT_DOCUMENTARY_VALIDATOR_RESULTS_PASSED
CONFIRMATION_EVIDENCE_MAP_COMPLETED
DERIVATIVE_CONFIRMATIONS_NOT_COUNTED_AS_DIRECT_BLOCKERS
NO_HARDCODED_CONFIRMATION_SUCCESS
CURRENT_ROLE_OCCUPANCY_COMPLETE
GOVERNED_DOCUMENTARY_VALIDATOR_PREFIX_USED
NO_HISTORICAL_CLOSURE_OUTPUT_CURRENT
NO_FAILED_ARTIFACT_CURRENT
IMPLEMENTATION_PRESENT_FALSE
IMPLEMENTATION_AUTHORITY_FALSE
PRODUCER_PACKAGE_NOT_SELF_PROMOTED
INDEPENDENT_ACCEPTANCE_NOT_PRECLAIMED
FINDING_OWNERSHIP_COMPLETE
EVERY_REQUIRED_AUDIT_PHASE_TERMINAL
A15_STATUS_EQUALS_FINAL_CLOSURE_PASS
CHILD_ORDINALS_COMPLETE_AND_CONTIGUOUS
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
AUDIT_CLEANUP_SET_EQUALITY_PASSED
CAPSULE_SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
WRAPPER_FIXED_INPUT_CLOSING_EQUALITY_PASSED
AUDIT_TEMPORAL_INVENTORY_CREATED
AUDIT_TEMPORAL_INVENTORY_VERIFIED
AUDIT_MANIFEST_A_CREATED
AUDIT_MANIFEST_B_CREATED
AUDIT_MANIFESTS_BYTE_IDENTICAL
AUDIT_TERMINAL_REPROJECTION_PASSED
AUDIT_ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_AUDIT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_AUDIT_DIRECTORY_MODES_0700
ALL_AUDIT_FILE_MODES_0600
NO_AUDIT_CACHE_OR_BYTECODE_RETAINED
SINGLE_AUDIT_SEAL_TRANSITION
NO_WRITE_AFTER_AUDIT_TERMINAL_SEAL
REPLACEMENT_SUBJECT_MUTATION_NOT_PERFORMED
REPLACEMENT_SUBJECT_CLEANUP_NOT_PERFORMED
CURRENT_AUTHORITY_PROMOTION_NOT_PERFORMED
CURRENT_AUTHORITY_REBINDING_NOT_PERFORMED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

## Sources and confidence

The attached report establishes the exact predecessor defect, bounded source repair, independent reason projection, valid-finding gating, and historical 907-row closure. :chatgpt-content-reference{index="8"}

It establishes packaged ACCEPT/BLOCK/provenance regressions, source freeze, deterministic successor artifacts, post-package qualification, certificate validation, frozen-package requalification, and one active unconsumed successor authorization. :chatgpt-content-reference{index="9"}

**Provenance confidence:** 0.999  
**Projection-repair confidence:** 0.999  
**One-audit readiness confidence:** 0.999  
**Replacement-subject acceptance confidence before audit:** 0.00

Some older project uploads have expired. Re-upload any specific older artifact if you need its original bytes re-read rather than relying on retained identities and reports.
