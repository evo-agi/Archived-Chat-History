Here is Codex's response:

CONTRACT\_PROVENANCE\_MISMATCH

The canonical supplied-root registry is internally inconsistent:

- Required `accepted_bootstrap_audit` path: `/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-independent-audit-sbv__euv`
- Result: path absent.
- Expected device/inode `16777234/180047263` instead resolves at `/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-a-c-h-i-independent-audit-sbv__euv`—without `-v1-`.
- The predecessor and reconciliation both bind to that latter path with 197 entries and digest `ed2fa43c432f9350b2429fa744778b7004cad5e1162c986b87849af4bdc65825`.

Because the canonical key is exactly `(role_id, absolute_path)`, substituting the observed path would violate the supplied authority.

Fresh stopped root:

- Root: `/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-ibf2v5bk`
- Identity: device `16777234`, inode `180454877`, mode `0700`
- Retained only: [opening/bootstrap-start.json](/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-ibf2v5bk/opening/bootstrap-start.json)
- Bootstrap SHA-256: `05bf489df20afc2610062c2cd33e4b06c06c63d3759aecfa0411e347c094d472`
- No normative artifacts were copied and no seal or manifests were created.

The predecessor’s 51-entry manifest projection and reconciliation’s 23-entry self-excluding inventory both reproduced exactly. No supplied root was modified; no implementation, package construction, target audit, runtime validation, Git, network, product, A6, or subagent activity occurred.
