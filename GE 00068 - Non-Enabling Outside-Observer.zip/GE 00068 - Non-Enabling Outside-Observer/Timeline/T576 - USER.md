Here is Codex's response:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_CURRENT_AUTHORITY_PROMOTION_PROVENANCE_MISMATCH

1. Exactly one promotion parent ran. It exited `1` without retry.
2. Partial output root: [ES-repair10i-v3-current-schema-subject-authority-promotion-0v_b4n_m](/Users/ds/Downloads/ES-repair10i-v3-current-schema-subject-authority-promotion-0v_b4n_m), created privately with mode `0700`.
3. Accepted subject remains device/inode `16777234/182649818`, 73 entries, inventory SHA-256 `eb46c6784c361962fa007c2c8638676ca8e5a810cfb91512437e008cd64beea3`.
4. Audit wrapper remains device/inode `16777234/182855547`; capsule remains `16777234/182860759`, 33 entries, inventory SHA-256 `0f23428965bed3096ee4ce6821a6e126e22a6e8432e43edbc8e92b06f84d6c2b`.
5. Existing evidence still records `SUBJECT_AUDIT_ACCEPT` and `GEN2_REPLACEMENT_SCHEMA_SUBJECT_ACCEPT`.
6. Construction provenance remains `16777234/182648782`, 49 entries, inventory SHA-256 `9c6736d69b81fc0f0d06bbee8dde0a930bab284064f40c01b9ec65cf9ea5b60e`.
7. Accepted implementation roots retain inventory hashes `3e88e9c…222d` and `6d1d2176…c108`.
8. Current content bundle and authority retain SHA-256 identities `b494b918…3671` and `276fde7d…1563`.
9. Prelaunch analysis uniquely resolved `CONTENT_SNAPSHOT_AUTHORITY_OWNER`, but the parent did not retain that resolution as successor authority.
10. Owning records were the final content-snapshot authority, `bundle-index-v1`, and `bundle-role-registry-v1`.
11. Dedicated authority, reconstruction-parent, containing-directory, and current-schema-package-as-competing-writer candidates were rejected.
12. No promotion contract was completed.
13. The predecessor `current-schema-package` role was identified, but no transition occurred.
14. No successor current-schema-subject role was created.
15. No successor current/historical registry was created.
16. Exactly-one-current-subject was not established.
17. Successor-snapshot output form was selected but not materialized.
18. Deterministic Build A/B did not run.
19. The independent validator did not run.
20. The promotion matrix did not run.
21. Parent-owned closing equality was not reached. A subsequent read-only check confirmed all supplied canonical identities remain unchanged.
22. The reserved temporal file remains zero bytes.
23. Both reserved manifest files remain zero bytes.
24. Final reprojection did not run.
25. Terminal topology was not established; the partial root contains empty reserved directories.
26. No seal transition occurred.
27. Subject bytes are unchanged.
28. Audit wrapper and capsule bytes are unchanged.
29. No repository mutation occurred.
30. No product, runtime, target-audit, publication/deployment, or A6 authority was widened.
31. No successor ZIP or authority JSON exists.
32. Failure cause: the builder treated the subject manifest’s exclusion objects as hashable strings, raising `TypeError: unhashable type: 'dict'`. This is a builder provenance failure, not supplied-input drift.
33. The partial root and both source files were preserved unchanged; no cleanup or retry was performed.

Confirmations established:

- `SUBJECT_BYTES_NOT_MODIFIED`
- `AUDIT_CAPSULE_BYTES_NOT_MODIFIED`
- `NO_PRODUCT_AUTHORITY_WIDENING`
- `NO_RUNTIME_AUTHORITY_WIDENING`
- `NO_TARGET_AUDIT_AUTHORITY_WIDENING`
- `NO_PUBLICATION_OR_DEPLOYMENT_AUTHORITY_WIDENING`
- `NO_A6_AUTHORITY_WIDENING`
- `NO_REPOSITORY_MUTATION`
- `NO_GIT_INVOCATION`
- `NO_NETWORK_CONTACT`
- `NO_SUBAGENTS_CREATED`

All promotion, deterministic-build, independent-validation, terminal-closure, seal, and current-role confirmations are not established.
