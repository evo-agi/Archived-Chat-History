## Assessment

Codex’s diagnosis is complete and internally consistent. The bootstrap successfully:

- allocated and retained the fresh root;
- verified pinned Python;
- reproduced the qualified launcher manifests using the correct `directory`/`regular` grammar;
- verified the launcher package’s closure and fixed identities;
- verified the reconciliation capsule’s manifests;
- opened and parsed the import-interface records.

It then failed on an **invented verdict-discovery predicate**:

```python
"LAUNCHER_IMPORT_RECONCILED_BOOTSTRAP_VERIFIER_DEFECT" in all_rec_strings
```

The bootstrap searched ten unrelated records but omitted the authoritative record:

```text
closeout/verdict.json
```

That record contained the exact verdict at `/verdict`. The package interface was already unambiguous; the bootstrap ignored its exact-path authority and fell back to a recursive string search. This is plainly a bootstrap implementation defect, not an input, launcher-package, import-interface, platform, or V3 defect.

Codex’s recommendation to qualify an immutable bootstrap importer is now justified. We have crossed the point where another handwritten bootstrap inside the full audit is strategically defensible. The importer should be the **last process-infrastructure package**:

1. implement it once;
2. validate its complete import and materialization behavior;
3. independently audit it;
4. consume its exact accepted bytes in the full V3 audit.

It must remain narrow. It owns only fresh-root allocation, immutable input verification, process-package import, root rebinding, bootstrap records, and Carrier 0002 materialization. It must not inspect V3 targets or own audit correctness.

## Prompt for Codex

```text
IMPLEMENT THE IMMUTABLE VALIDATION-CUSTODY V3
BOOTSTRAP-IMPORTER PACKAGE

This is a source-external audit-process infrastructure tranche.

Do not inspect or modify any candidate repository, Strategic B source,
Validation-Custody target, V1/V2/V3 capsule other than the exact immutable
process-package inputs named below, product source, live service, or unrelated
evidence root.

Do not run Git.
Do not run repository tests.
Do not run product code.
Do not rerun runtime validation.
Do not use the network.
Do not stage, commit, push, install, deploy, or start A6.
Do not create subagents.

Return exactly one primary implementation verdict:

VALIDATION_CUSTODY_V3_BOOTSTRAP_IMPORTER_IMPLEMENTED_READY_FOR_FRESH_AUDIT
VALIDATION_CUSTODY_V3_BOOTSTRAP_IMPORTER_IMPLEMENTATION_BLOCKED
IMPLEMENTATION_PROVENANCE_MISMATCH

OBJECTIVE

Implement and producer-validate one immutable source-external bootstrap-importer
package that a later full Validation-Custody V3 independent audit can invoke as
its sole unwrapped bootstrap process.

The importer must:

1. allocate and immediately retain/emit a fresh audit root;
2. verify the immutable qualified-launcher package under its exact manifest
   grammar;
3. verify the immutable launcher-import reconciliation capsule;
4. read the reconciliation verdict from its exact manifest-covered canonical
   path, never through recursive string discovery;
5. enforce the closed consumer import interface;
6. copy exactly five process artifacts byte-for-byte;
7. regenerate exactly the root-bound auxiliary records;
8. generate the fresh root-bound launch-contract instance;
9. prove normalized root rebinding over the exact twelve direct pointers;
10. create the audit-owned Carrier 0002 self-check payload and request;
11. terminate without inspecting any V3 target or supplied target root;
12. leave a complete bootstrap-start, bootstrap-outcome, result, and provenance
    package even on failure.

This package must replace future handwritten bootstrap logic. It does not own
V3 correctness, target provenance, audit findings, or the final audit verdict.

──────────────────────────────────────────────────────────────────────────────
1. EXACT IMMUTABLE INPUTS
──────────────────────────────────────────────────────────────────────────────

QUALIFIED_LAUNCHER_ROOT:

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38

Expected root identity:

- device/inode:
  16777234 / 179032804
- mode:
  0700
- expected primary verdict:
  WRAPPED_CARRIER_LAUNCHER_READY

Required package identities:

Accepted wrapper:

- relative path:
  source/phase_runner.py
- size:
  15300
- SHA-256:
  6e911ca17dedc6c5838b8b880548761b9009bb18fc26f1e7b6934d274f040f56
- mode:
  0600
- regular:
  true
- links:
  1

Qualified launcher:

- relative path:
  source/wrapped_carrier_launcher.py
- size:
  16603
- SHA-256:
  12e4c0bd37581c7c9634133fd5cb0c30f9db4871f13f8f6825a1efed1f51fd9e

Phase-runner CLI contract:

- relative path:
  contract/phase-runner-cli-contract-v1.json
- size:
  6937
- SHA-256:
  be46e39be6b72c2a49ca510807d6aa346a477fe13dad0911bc1965c389f1695f

Carrier-request contract:

- relative path:
  contract/carrier-request-contract-v1.json
- size:
  1606
- SHA-256:
  bdd167b775281418364b362270dbba366a2f4f4c6dc8257ce1a3e829834a3790

Environment-observation policy:

- relative path:
  contract/environment-observation-policy-v1.json
- authenticate through the supplied manifest pair and package role ledger

Qualification-root launch-contract instance:

- size:
  2260
- SHA-256:
  b9ac95c264d88d0a0cd76f17c7089b65229bed9c4eb65ea949ef4f745c5e57d1

Qualified-package manifests:

manifest/qualification-manifest-a-v1.json
manifest/qualification-manifest-b-v1.json

- size:
  12404 each
- SHA-256:
  a81be4da4d3c767e0e1c1b98db8e7ccf4403977e2b1ef66d21263adbcd1acebb
- byte-identical:
  required

Expected package projection:

- 73 represented entries;
- 9 directories including root;
- 64 represented nonmanifest regular files;
- exactly two self-exclusions:
  the two manifest files;
- 66 physical regular files including manifests;
- no retained empty directory;
- no symlink;
- no special object;
- no multiply linked regular file;
- directories mode 0700;
- files regular, single-link mode 0600.

IMPORT_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-launcher-package-import-reconciliation-xqrjt92s

Expected primary verdict:

LAUNCHER_IMPORT_RECONCILED_BOOTSTRAP_VERIFIER_DEFECT

Required reconciliation identities and records include:

closeout/verdict.json

- size:
  414
- SHA-256:
  5361158b8d8f57181bae449f2f7bf5994b3eeede681a4dd64187155e64ad6a63
- required `/verdict`:
  LAUNCHER_IMPORT_RECONCILED_BOOTSTRAP_VERIFIER_DEFECT

Also consume and independently verify:

manifest/qualified-package-manifest-contract-v1.json
manifest/supplied-manifest-byte-comparison.json
interface/complete-package-role-ledger.json
interface/qualified-launcher-consumer-import-contract-v1.json
analysis/auxiliary-identity-record-adjudication.json
interface/root-rebinding-field-map-v1.json
interface/bootstrap-materialization-order-v1.json
analysis/corrected-bootstrap-algorithm.json
closeout/supplied-root-closing-equality.json
closeout/final-inventory.json
closeout/verdict.json

Reconciliation-capsule fixed closeout identities:

- final inventory:
  5597 bytes
  SHA-256:
  c95a08a254d28196bfc77467ff9bc7c156823fde1ecc982fd1cf94dff470bd5b

- covering manifests:
  5728 bytes each
  SHA-256:
  448d7b3ab37654336d35f36088986a01ec67a69a3479540cf9ded3bc46d0c648
  required byte-identical

FAILED_BOOTSTRAP_ROOT:

/Users/ds/Downloads/ES-validation-custody-v3-audit-repair-independent-audit-ik29rus5

Use this root only as immutable historical defect evidence.

Inspect only:

opening/bootstrap-start.json
opening/bootstrap-outcome.json

and the bounded transcript-derived implementation causal supplied by the
latest reconciliation report.

Do not resume, clean, repair, or adopt this root.

PINNED PYTHON:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Closed acceptance identity:

- version:
  Python 3.13.4
- regular:
  true
- links:
  1
- size:
  119424
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b

Interpreter permission bits and other filesystem metadata are report-only.

Do not reject mode 0775.
Do not chmod or normalize the interpreter.

──────────────────────────────────────────────────────────────────────────────
2. FRESH IMPLEMENTATION PACKAGE
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh package root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask 077, prefix:

ES-repair10i-v3-bootstrap-importer-v1-

Recommended retained structure:

source/
contract/
schemas/
tests/
tests/fixtures/
validation/
provenance/
closeout/
manifest/
private/

No retained empty directory is permitted.

All retained directories must be mode 0700.
All retained files must be regular, single-link mode 0600.
No symlink, special object, or multiply linked file is permitted.

──────────────────────────────────────────────────────────────────────────────
3. PACKAGE CLASSIFICATION AND AUTHORITY
──────────────────────────────────────────────────────────────────────────────

Classification:

- source-external audit-process infrastructure;
- evidence/provenance and process-materialization authority only;
- no repository authority;
- no product authority;
- no runtime authority;
- no deployment authority;
- no publication or commit authority;
- no V3 target-correctness authority;
- no audit-verdict authority;
- no A6 authority.

The package may:

- allocate one fresh audit root;
- verify its two immutable process-package inputs;
- copy the five approved process artifacts;
- generate fresh root-bound bootstrap artifacts;
- produce Carrier 0002 materialization inputs;
- report bootstrap success or failure.

It may not:

- inspect the candidate;
- inspect Strategic B;
- inspect V1/V2/V3 target roots;
- start direct auditors;
- execute the launcher or wrapper;
- execute Carrier 0002;
- advance audit progression beyond bootstrap materialization;
- issue ACCEPT/BLOCK/REJECT for the V3 target.

──────────────────────────────────────────────────────────────────────────────
4. IMPLEMENTATION ROOT STRUCTURE
──────────────────────────────────────────────────────────────────────────────

Create at minimum:

source/
  bootstrap_importer_v1.py

contract/
  bootstrap-importer-contract-v1.json
  qualified-launcher-input-contract-v1.json
  launcher-import-reconciliation-input-contract-v1.json
  fresh-audit-root-layout-v1.json
  bootstrap-result-contract-v1.json
  bootstrap-failure-contract-v1.json
  carrier-0002-self-check-template-contract-v1.json

schemas/
  bootstrap-importer-contract-v1.schema.json
  bootstrap-result-v1.schema.json
  bootstrap-failure-v1.schema.json

tests/
  test_bootstrap_importer_v1.py
  independent_bootstrap_validator_v1.py
  fixtures/

validation/
  producer-test-result-v1.json
  independent-validator-result-v1.json
  causal-matrix-v1.json
  deterministic-materialization-v1.json
  failure-atomicity-v1.json
  source-identity-v1.json

provenance/
  source-inventory-v1.txt
  attempt-index-v1.json
  implementation-delta-v1.patch
  package-build-v1.json

closeout/
  final-implementation-report-v1.md
  final-evidence-inventory-v1.json
  cleanup-v1.json

manifest/
  canonical-manifest-a-v1.json
  canonical-manifest-b-v1.json

Generated schema files are projections. The executable importer source and its
closed contract remain the semantics owners.

──────────────────────────────────────────────────────────────────────────────
5. IMPORTER CLI
──────────────────────────────────────────────────────────────────────────────

Freeze one exact CLI.

Recommended shape:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13 \
  -I -S -B \
  bootstrap_importer_v1.py \
  --qualified-launcher-root ABSOLUTE_ROOT \
  --import-reconciliation-root ABSOLUTE_ROOT \
  --audit-parent /Users/ds/Downloads \
  --audit-prefix EXACT_PREFIX

Derive and freeze the final exact option names, types, required status, and
canonical order.

The importer must use no shell and no PATH lookup.

Stdout contract:

Immediately after fresh-root allocation, start-record retention, and fsync,
emit exactly one line:

AUDIT_ROOT=<absolute-path>\n

No earlier stdout is permitted.

After that line, stdout must remain empty.

Stderr must remain empty for handled bootstrap success or handled bootstrap
failure.

Process exit:

- `0`:
  bootstrap materialization completed successfully;
- nonzero:
  bootstrap failed after writing a canonical failure outcome.

Freeze exact nonzero exit classes in the contract.

──────────────────────────────────────────────────────────────────────────────
6. FRESH AUDIT-ROOT LAYOUT
──────────────────────────────────────────────────────────────────────────────

The importer must create the exact initial audit-root directory set required by
the complete V3 audit.

Derive it from the prior full-audit brief and the failed-root membership.

At minimum adjudicate:

analysis
auditors
child
closeout
contract
evidence
interaction
opening
payload
phase
private
private/home
private/tmp
request
result
source

Freeze:

- exact required directories;
- exact modes;
- whether later directories may be added;
- which directories must be nonempty at importer completion;
- which may remain empty only temporarily;
- which are owned by later audit phases.

Avoid creating retained empty directories that would make importer completion
nonqualifying. When a directory is needed only later, either:

- omit it until the owning later phase; or
- place an explicit canonical placeholder/ownership record if the complete
  V3 audit contract requires early creation.

Do not invent placeholder files solely to evade an empty-directory rule unless
the contract explicitly classifies them.

──────────────────────────────────────────────────────────────────────────────
7. QUALIFIED-LAUNCHER MANIFEST VERIFICATION
──────────────────────────────────────────────────────────────────────────────

Implement the exact manifest grammar:

- canonical UTF-8 JSON;
- sorted keys;
- compact separators;
- ASCII escaping as implemented by the supplied generators;
- no nonfinite values;
- one terminal LF;
- path order:
  ascending `os.fsencode(relative_path)` bytes;
- root:
  `.`;
- type labels:
  `directory`
  `regular`;
- directory fields:
  `mode`
  `path`
  `type`;
- regular-file fields:
  `links`
  `mode`
  `path`
  `sha256`
  `size`
  `type`;
- exactly two manifest exclusions;
- symlinks:
  reject;
- special objects:
  reject;
- multiply linked regular files:
  reject;
- unsupported path encoding:
  fail closed;
- empty directories:
  represented by the grammar.

The immutable qualified package is separately required to have zero retained
empty directories.

Never use `file` as a synonym for `regular`.

The importer must independently reproject the package and compare canonical
bytes directly with both supplied manifests.

Require:

- both supplied manifests byte-identical;
- fresh projection equal to both;
- exact entry count;
- exact membership;
- exact fields;
- exact modes and links;
- no omitted object.

──────────────────────────────────────────────────────────────────────────────
8. IMPORT-RECONCILIATION VERIFICATION
──────────────────────────────────────────────────────────────────────────────

Verify the reconciliation capsule through its own covering manifests and fixed
closeout identities.

Do not use recursive string discovery for verdicts or roles.

Verdict verification must:

1. Resolve exactly:
   `closeout/verdict.json`
2. Verify the path is represented by the reconciliation covering manifests.
3. Verify regular-file type, mode, links, size, and SHA-256.
4. Strictly parse canonical JSON with duplicate-key and nonfinite rejection.
5. Require the exact schema present in the retained verdict record:
   inspect and freeze the actual field map; do not guess it.
6. Read `/verdict` directly.
7. Require:
   `LAUNCHER_IMPORT_RECONCILED_BOOTSTRAP_VERIFIER_DEFECT`
8. Require the exact associated fields establishing:
   - package import information is unambiguous;
   - no interface addendum is required;
   - no package repair is required.

Inspect and freeze the exact JSON pointers and expected values from the
retained record.

Forbidden:

- flattening arbitrary string values;
- substring searching;
- accepting the verdict from a prose report;
- accepting only a path reference to the verdict file;
- scanning filenames to assign artifact roles.

──────────────────────────────────────────────────────────────────────────────
9. CLOSED COPY BOUNDARY
──────────────────────────────────────────────────────────────────────────────

Copy exactly five artifacts byte-for-byte:

1. qualified wrapper source;
2. qualified launcher source;
3. phase-runner CLI contract;
4. carrier-request contract;
5. environment-observation policy.

The output relative paths must be frozen.

For every copy:

- open source no-follow;
- require expected type/mode/link/size/hash;
- create destination exclusively at 0600;
- write complete bytes;
- fsync;
- close;
- reopen no-follow;
- verify exact bytes and identity.

No qualification payload, result, phase record, carrier index, closeout
payload, final inventory, manifest, or failed-attempt record may be copied as
fresh audit truth.

──────────────────────────────────────────────────────────────────────────────
10. GENERATED AUXILIARY RECORDS
──────────────────────────────────────────────────────────────────────────────

Generate from final copied bytes:

opening/qualified-launcher-source-identity.json
opening/fixed-environment-observation.json

Resolve their roles solely through the qualification launch contract’s bound
pointers:

- `/launcher_identity_record`
- `/fixed_environment_record`

Do not search filenames for `record`.

Freeze exact schemas and field maps from the qualification exemplars and import
contract.

The launcher identity record must describe the copied fresh-audit-root
launcher, not the qualification-root source file.

The fixed-environment record must describe the fresh root’s exact environment:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
HOME=<FRESH_ROOT>/private/home
TMPDIR=<FRESH_ROOT>/private/tmp

Do not copy the qualification exemplars.

──────────────────────────────────────────────────────────────────────────────
11. FRESH ROOT-BOUND LAUNCH CONTRACT
──────────────────────────────────────────────────────────────────────────────

Create one fresh launch-contract instance from the qualification-root launch
contract.

The exact direct changed-pointer set is:

- `/qualification_root`
- `/wrapper/path`
- `/phase_runner_cli_contract/path`
- `/carrier_request_contract/path`
- `/fixed_environment/HOME`
- `/fixed_environment/TMPDIR`
- `/fixed_environment_record/path`
- `/fixed_environment_record/size`
- `/fixed_environment_record/sha256`
- `/launcher_identity_record/path`
- `/launcher_identity_record/size`
- `/launcher_identity_record/sha256`

No direct pointer may be added or removed.

For every change retain:

- source value;
- destination value;
- classification:
  `physical-audit-root-rebinding-only`;
- semantic effect:
  none.

Normalize both launch contracts by replacing qualification-root and fresh-root
physical values with `${AUDIT_ROOT}`.

Require byte-identical normalized projections.

Any non-root-bound difference is a bootstrap failure.

──────────────────────────────────────────────────────────────────────────────
12. CARRIER 0002 MATERIALIZATION
──────────────────────────────────────────────────────────────────────────────

Create one fresh audit-owned Carrier 0002 self-check payload and request.

The payload must implement the qualified environment policy:

- constructed fixed environment equals launch-contract fixed environment;
- every contract-owned observed key has the exact value;
- additional post-exec key names are diagnostics only;
- additional values are not retained;
- same launcher and payload PID required;
- complete wrapper CLI conformance required;
- expected wrapper SHA exactly once;
- no child process;
- no target inspection;
- result retained at mode 0600.

The importer must:

- create payload source exclusively;
- retain size and SHA-256;
- create the Carrier 0002 request;
- bind launch-contract path, size, and SHA-256;
- bind payload path, size, and SHA-256;
- bind exact expected outputs;
- reject invariant launch fields in the request.

The importer must not execute Carrier 0002.

──────────────────────────────────────────────────────────────────────────────
13. BOOTSTRAP START, OUTCOME, AND RESULT
──────────────────────────────────────────────────────────────────────────────

Immediately after allocating the fresh root, retain and fsync:

opening/bootstrap-start.json

It must bind:

- schema;
- exact root;
- root identity;
- audit parent;
- prefix;
- allocation mechanism;
- umask;
- importer source identity;
- importer package identity;
- candidate/target inspection:
  false;
- status:
  bootstrap-started.

On success, retain:

opening/bootstrap-outcome.json
opening/bootstrap-import-result.json

The result must bind:

- success;
- fresh root;
- every copied artifact identity;
- generated auxiliary record identities;
- fresh launch-contract identity;
- rebinding-proof identity;
- Carrier 0002 payload and request identities;
- package and reconciliation input identities;
- `target_content_inspected:false`;
- exact next authorized action:
  launch Carrier 0002 through the copied qualified launcher.

On handled failure, retain:

opening/bootstrap-outcome.json
opening/bootstrap-failure.json

Bind:

- exact failed operation;
- exception type/message;
- completed step ordinal;
- partial artifacts;
- target inspection false;
- fresh root;
- no authorization for Carrier 0002.

Never leave the root locator unknown.

──────────────────────────────────────────────────────────────────────────────
14. FAILURE ATOMICITY
──────────────────────────────────────────────────────────────────────────────

The importer must fail closed.

On any failure:

- do not delete the fresh root;
- do not overwrite an existing artifact;
- do not continue to later materialization stages;
- do not emit a success result;
- do not inspect target content;
- retain the exact root and failure evidence.

Use exclusive creation for every retained artifact.

No retry inside a failed fresh root.

──────────────────────────────────────────────────────────────────────────────
15. PRODUCER TEST MATRIX
──────────────────────────────────────────────────────────────────────────────

Implement a complete producer test suite.

At minimum cover:

A. Happy path

1. exact inputs produce successful bootstrap materialization;
2. stdout emits exactly one correct `AUDIT_ROOT=` line;
3. five copied artifacts match byte-for-byte;
4. generated records describe copied bytes;
5. fresh launch contract normalizes equal;
6. Carrier 0002 payload and request are complete;
7. target inspection remains false.

B. Reconciliation verdict

8. verdict present at exact canonical path:
   pass;
9. verdict omitted:
   reject;
10. wrong verdict:
    reject;
11. malformed verdict JSON:
    reject;
12. duplicate verdict key:
    reject;
13. nonfinite verdict value:
    reject;
14. verdict file not covered by reconciliation manifest:
    reject;
15. path reference present elsewhere but verdict file missing:
    reject;
16. expected verdict text present in unrelated record only:
    reject;
17. recursive string search would find a value but canonical verdict is wrong:
    reject.

C. Manifest grammar

18. regular file labeled `file`:
    reject;
19. regular file labeled `regular`:
    pass;
20. wrong row order:
    reject;
21. root row missing:
    reject;
22. extra row:
    reject;
23. missing row:
    reject;
24. wrong directory mode:
    reject;
25. wrong regular-file mode:
    reject;
26. wrong link count:
    reject;
27. wrong size:
    reject;
28. wrong hash:
    reject;
29. symlink:
    reject;
30. special object:
    reject;
31. hardlink:
    reject;
32. manifest pair differs:
    reject.

D. Import interface

33. missing one of five exports:
    reject;
34. extra copied qualification result:
    reject;
35. stale qualification launcher identity copied as fresh:
    reject;
36. stale fixed-environment exemplar copied as fresh:
    reject;
37. role discovery by filename substring:
    reject in static/source audit;
38. wrong auxiliary bound path:
    reject;
39. materialization order violation:
    reject;
40. identity record referenced before finalization:
    reject.

E. Root rebinding

41. one required pointer omitted:
    reject;
42. one extra pointer changed:
    reject;
43. non-root field changed:
    reject;
44. normalized contracts differ:
    reject;
45. stale qualification-root path remains:
    reject.

F. Carrier 0002 materialization

46. invariant override in request:
    reject;
47. expected-wrapper SHA repeated in request:
    reject;
48. payload hash wrong:
    reject;
49. expected output missing:
    reject;
50. environment oracle uses whole-map equality:
    reject through source/static policy check.

G. Failure behavior

51. failure before root emission:
    prohibited by design;
52. failure after root emission retains canonical outcome;
53. partial copy failure stops progression;
54. success result absent on failure;
55. fresh root is retained;
56. target-inspection flag remains false.

Pin exact case names and expected reasons independently from the generated
cases.

──────────────────────────────────────────────────────────────────────────────
16. INDEPENDENT VALIDATOR
──────────────────────────────────────────────────────────────────────────────

Implement a second independent validator.

It must:

- import no producer test helper;
- generate its own literal case set;
- strictly parse contracts and records;
- independently verify manifest grammar;
- independently verify exact-path verdict lookup;
- independently verify copy/regenerate classification;
- independently verify root-rebinding pointers;
- independently verify materialization order;
- independently verify Carrier 0002 request;
- require the same expected outcomes and reasons.

Require:

- exact case-name closure;
- exact count;
- uniqueness;
- zero false acceptance;
- mechanism-specific reasons;
- no producer fixture used as the case generator.

──────────────────────────────────────────────────────────────────────────────
17. DETERMINISM AND TWO FRESH SUCCESS RUNS
──────────────────────────────────────────────────────────────────────────────

Run the importer successfully twice into two separately allocated fresh audit
roots.

Require:

- both use distinct physical roots;
- both emit one correct root line;
- copied process artifacts byte-identical;
- normalized generated records byte-identical where root normalization applies;
- normalized launch contracts byte-identical;
- Carrier 0002 payload source byte-identical;
- normalized Carrier 0002 requests byte-identical;
- no supplied-root mutation;
- no target inspection.

Remove both test audit roots only if they are implementation-owned fixtures and
the test contract permits removal.

Retain complete before/after fixture records and two absence observations for
each removed fixture root.

The final importer package itself must not depend on either random fixture
path.

──────────────────────────────────────────────────────────────────────────────
18. STATIC SECURITY AND PROCESS REVIEW
──────────────────────────────────────────────────────────────────────────────

Inspect importer source for:

- network APIs;
- subprocess calls;
- shell use;
- Git;
- repository path access;
- target-root access;
- broad Downloads scanning;
- latest/prefix selection;
- adoption of existing audit roots;
- path traversal;
- symlink following;
- nonexclusive writes;
- secret emission;
- raw inherited environment capture.

Expected:

- no network;
- no Git;
- no target access;
- no subprocess required for bootstrap materialization;
- no shell;
- no broad root scanning;
- no adoption;
- no overwrite;
- no secret-bearing output.

The importer may read only the two supplied process roots, pinned Python, and
its own package/fixture paths.

──────────────────────────────────────────────────────────────────────────────
19. PROVENANCE AND ATTEMPT TREATMENT
──────────────────────────────────────────────────────────────────────────────

Retain:

- opening input inventories;
- source identities;
- exact implementation source;
- contracts and schemas;
- every test command;
- every stdout/stderr/result;
- failed and superseded attempts;
- two successful deterministic runs;
- fixture cleanup;
- final package inventory;
- covering manifests.

No failed attempt may contribute a final passing identity or count.

Do not overwrite failed evidence.

──────────────────────────────────────────────────────────────────────────────
20. CAPSULE CLOSURE
──────────────────────────────────────────────────────────────────────────────

Use two independently implemented lstat/no-follow manifest generators.

Require:

- root represented;
- every directory represented;
- every nonmanifest file represented;
- exactly two manifest self-exclusions;
- no unexplained or empty retained directory;
- no symlink;
- no special object;
- no multiply linked regular file;
- directories mode 0700;
- files regular, single-link mode 0600;
- independent manifests byte-identical.

Finalize:

- implementation report;
- source inventory;
- contracts and schemas;
- producer test source/results;
- independent validator source/results;
- causal matrix;
- deterministic-run records;
- security review;
- attempt index;
- cleanup;
- final inventory;
- manifest pair.

──────────────────────────────────────────────────────────────────────────────
21. STOP CONDITIONS
──────────────────────────────────────────────────────────────────────────────

Stop and return
`VALIDATION_CUSTODY_V3_BOOTSTRAP_IMPORTER_IMPLEMENTATION_BLOCKED` on:

- input identity drift;
- ambiguous import-interface field;
- missing exported artifact;
- inability to reproduce package or reconciliation manifests;
- verdict record ambiguity;
- circular generated-record dependency;
- root-rebinding ambiguity;
- source change required in the qualified launcher or wrapper;
- inability to materialize Carrier 0002 without executing target content;
- false acceptance in either validator;
- nondeterministic normalized output;
- supplied-root mutation;
- unexpected network or target access.

Return `IMPLEMENTATION_PROVENANCE_MISMATCH` for:

- opening/closing supplied-root inequality;
- incomplete process or attempt records;
- missing final artifact;
- manifest closure failure;
- mutation of an immutable supplied input.

Do not repair supplied inputs.

──────────────────────────────────────────────────────────────────────────────
22. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Implementation-package root identity
3. Immutable input identities
4. Reproduced prior bootstrap defect
5. Importer authority and nonauthority
6. Exact importer CLI
7. Fresh audit-root layout
8. Qualified-package manifest verifier
9. Reconciliation exact-path verdict verifier
10. Closed five-artifact copy boundary
11. Generated auxiliary-record field maps
12. Root-bound launch-contract algorithm
13. Exact twelve-pointer rebinding proof
14. Carrier 0002 payload and request generation
15. Bootstrap start/outcome/result/failure schemas
16. Failure atomicity
17. Producer causal matrix
18. Independent validator result
19. Two deterministic success runs
20. Security/process review
21. Failed and superseded attempts
22. Supplied-root opening/closing equality
23. Fixture cleanup and absence observations
24. Package inventory and manifest identities
25. Severity-ranked residual findings
26. Remaining uncertainty and nonclaims
27. Explicit confirmations

Required confirmations:

QUALIFIED_LAUNCHER_PACKAGE_MUTATION_NOT_PERFORMED
IMPORT_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
FAILED_BOOTSTRAP_ROOT_MUTATION_NOT_PERFORMED
CANDIDATE_REPOSITORY_NOT_INSPECTED
STRATEGIC_B_NOT_INSPECTED
V1_V2_V3_TARGETS_NOT_INSPECTED
PACKAGE_MANIFEST_TYPE_REGULAR_USED
PACKAGE_MANIFEST_TYPE_FILE_NOT_USED
RECONCILIATION_VERDICT_READ_FROM_EXACT_PATH
RECURSIVE_STRING_VERDICT_DISCOVERY_NOT_USED
EXACT_FIVE_PROCESS_ARTIFACTS_COPIED
QUALIFICATION_RESULTS_NOT_COPIED_AS_FRESH_TRUTH
FRESH_LAUNCHER_IDENTITY_RECORD_GENERATED
FRESH_FIXED_ENVIRONMENT_RECORD_GENERATED
ROOT_BOUND_LAUNCH_CONTRACT_GENERATED
ROOT_REBINDING_POINTER_SET_EXACT
CARRIER_0002_PAYLOAD_AND_REQUEST_GENERATED
IMPORTER_DOES_NOT_EXECUTE_CARRIER_0002
TARGET_CONTENT_INSPECTED_FALSE
TWO_FRESH_SUCCESSFUL_MATERIALIZATIONS_COMPLETED
PRODUCER_CAUSAL_MATRIX_PASSED
INDEPENDENT_VALIDATOR_PASSED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_SUBAGENTS
INDEPENDENT_AUDIT_NOT_PERFORMED
```

After—and only after—this package reports
`VALIDATION_CUSTODY_V3_BOOTSTRAP_IMPORTER_IMPLEMENTED_READY_FOR_FRESH_AUDIT`,
perform a fresh independent audit of the importer package. Do not return
directly to the full V3 audit.

**Source:** Codex’s `BOOTSTRAP_FAILURE_RECONCILED_IMPLEMENTATION_DEFECT` report above.

**Confidence:** 0.999 that the latest bootstrap failure was the omitted exact-path verdict record; 0.998 that the qualified launcher package and import interface remain sound; 0.98 that an independently qualified immutable bootstrap importer is now the correct final process-infrastructure boundary.
