## Assessment

The process mechanism itself passed. The failure was entirely in the audit-owned Carrier 0002 oracle:

```python
"target_content_inspected": False
...
passed = all(checks.values())
```

The required state was correctly `false`, but the payload inserted that raw state into a map of positive success predicates. That single polarity error caused the aggregate `success:false`, wrapper disposition `payload-reported-failure`, and exit `30`.

Two additional Carrier 0001 defects must be closed before another audit:

- The fixed-environment record added an unauthorized top-level `policy` field. The accepted schema permits only `authority`, `environment`, and `schema`.
- The rebinding proof did not implement the reconciled proof contract. It omitted four real direct pointers, substituted transitive or nonexistent pointers, and omitted the normalized predecessor/successor projections and zero-non-root-difference result.

The failed payload also omitted several checks required by the intended process contract—same PID, constructed-environment equality, wrapper-SHA value and cardinality, and CLI conformance—and included a vacuous duplicate payload-identity check. These should be corrected together rather than waiting for another audit failure.

Codex’s conclusion is now right: freeze Carrier 0001 plus the Carrier 0002 self-check as one immutable, independently qualified **full-audit bootstrap package**. This should be the final process-infrastructure implementation tranche. It must stop after a successful process self-check and inspect no V3 target.

## Prompt for Codex

```text
IMPLEMENT THE IMMUTABLE VALIDATION-CUSTODY V3
FULL-AUDIT BOOTSTRAP PACKAGE V1

This is a source-external audit-process infrastructure tranche.

Do not modify any supplied root.
Do not resume, repair, or clean a failed audit root.
Do not inspect the candidate repository, Strategic B, blocked V1,
Validation-Custody V2, the V2 audit, V3 predecessor, V3 audit-repair target,
product source, or unrelated evidence.
Do not run Git.
Do not run repository tests or product code.
Do not execute Plan V3 or Plan V4.
Do not use the network.
Do not stage, commit, push, install, deploy, or start A6.
Do not create subagents.

Return exactly one primary implementation verdict:

VALIDATION_CUSTODY_V3_FULL_AUDIT_BOOTSTRAP_IMPLEMENTED_READY_FOR_FRESH_AUDIT
VALIDATION_CUSTODY_V3_FULL_AUDIT_BOOTSTRAP_IMPLEMENTATION_BLOCKED
IMPLEMENTATION_PROVENANCE_MISMATCH

OBJECTIVE

Implement and producer-validate one immutable source-external process package
containing the complete, corrected full-audit bootstrap boundary:

1. exact literal-path Carrier 0001 bootstrap materialization;
2. exact qualified-launcher package import;
3. fresh auxiliary records;
4. exact root-bound launch contract;
5. exact twelve-pointer rebinding proof;
6. corrected Carrier 0002 process-self-check payload;
7. exact Carrier 0002 request;
8. process-only qualification proving Carrier 0002 passes;
9. no target inspection.

The package must replace future handwritten Carrier 0001 and Carrier 0002
bootstrap logic.

It owns only audit-process initialization and qualification. It owns no V3
target correctness, repository, product, runtime, publication, commit,
deployment, readiness, audit-verdict, or A6 authority.

The production bootstrap source may materialize Carrier 0002 but must not
itself execute target-facing work. Package qualification may execute the
bounded no-target Carrier 0002 self-check against implementation-owned fixture
roots.

──────────────────────────────────────────────────────────────────────────────
1. EXACT IMMUTABLE INPUTS
──────────────────────────────────────────────────────────────────────────────

FAILED_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-bootstrap-importer-audit-repair-independent-audit-3_22cefi

Treat it as immutable process-failure evidence.

Expected failed-root facts include:

Carrier 0001 source:

- relative path:
  opening/carrier-0001-source.py
- size:
  87292
- SHA-256:
  d8c341721670cb4ace79d44f5e662260b040f9a430d2b4ef890785b51977e5d5

Failed Carrier 0002 payload:

- relative path:
  payloads/audit_supervisor.py
- size:
  64431
- SHA-256:
  f3a0ca539d2f7f4498a5612f17d242a1e2e2b67c4c4e5b7779304fe376e24408

Carrier 0002 request:

- relative path:
  provenance/carrier-0002.request.json
- size:
  2366
- SHA-256:
  2b6aacff6d0f75abe8dd2df2fa701cc0123d8bf693f64642d2b77157b5ad84e2

Constructed launch:

- relative path:
  provenance/carrier-0002.constructed-launch.json
- size:
  6382
- SHA-256:
  5f8b909e3c473690e9050195b417b61b78c9be10e79ffa87e713156af1574f26

Phase start:

- relative path:
  provenance/carrier-0002.phase-start.json
- size:
  5244
- SHA-256:
  c3cd6a568df387ed2276446a338542d48a5c64198e92bc4db537bc7b17ea54f1

Phase outcome:

- relative path:
  provenance/carrier-0002.phase-outcome.json
- size:
  3010
- SHA-256:
  d1c610efa6972e393c6e1743958fd3fe16a730e29aa2fce1f76ba287782210c3

Failed self-check result:

- relative path:
  opening/process-self-check-payload-result.json
- size:
  1723
- SHA-256:
  4ea6997cb82258c1efe1b8204581cb8a15ab57eb023ea2473571430bc279d967

Fresh launch contract:

- relative path:
  contract/wrapped-carrier-launch-contract-v1.json
- size:
  2404
- SHA-256:
  7734827d75104e54d38916b2a3661ce9db913113a494298a31a6da69ee49cdd7

Malformed rebinding proof:

- relative path:
  opening/launch-contract-root-rebinding-v1.json
- size:
  869
- SHA-256:
  df8374bcc4bc4549361b4cb0a06d7cf9ad32d537a54241fe5a6094b8c30d8dc3

Fixed-environment record with extra top-level field:

- relative path:
  opening/fixed-environment-observation.json
- size:
  849
- SHA-256:
  1b900a6b4f56826dc36780355a30b81b6a52437a46cac0b3a72bccb17cde18cd

Do not mutate, resume, or clean the failed root.

QUALIFIED_LAUNCHER_ROOT:

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38

Expected root identity:

- device/inode:
  16777234 / 179032804
- mode:
  0700
- expected verdict:
  WRAPPED_CARRIER_LAUNCHER_READY

Exact wrapper:

source/phase_runner.py

- size:
  15300
- SHA-256:
  6e911ca17dedc6c5838b8b880548761b9009bb18fc26f1e7b6934d274f040f56

Exact launcher:

source/wrapped_carrier_launcher.py

- size:
  16603
- SHA-256:
  12e4c0bd37581c7c9634133fd5cb0c30f9db4871f13f8f6825a1efed1f51fd9e

Phase-runner CLI contract:

contract/phase-runner-cli-contract-v1.json

- size:
  6937
- SHA-256:
  be46e39be6b72c2a49ca510807d6aa346a477fe13dad0911bc1965c389f1695f

Carrier-request contract:

contract/carrier-request-contract-v1.json

- size:
  1606
- SHA-256:
  bdd167b775281418364b362270dbba366a2f4f4c6dc8257ce1a3e829834a3790

Environment-observation policy:

contract/environment-observation-policy-v1.json

- size:
  530
- SHA-256:
  7004617e0b15cf563fdac60f7144d0066384a44debd77b2174c55819816cf82f

Qualification-root launch contract:

- size:
  2260
- SHA-256:
  b9ac95c264d88d0a0cd76f17c7089b65229bed9c4eb65ea949ef4f745c5e57d1

Qualification manifest pair:

- size:
  12404 each
- SHA-256:
  a81be4da4d3c767e0e1c1b98db8e7ccf4403977e2b1ef66d21263adbcd1acebb
- required:
  byte-identical

IMPORT_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-launcher-package-import-reconciliation-xqrjt92s

Expected verdict:

LAUNCHER_IMPORT_RECONCILED_BOOTSTRAP_VERIFIER_DEFECT

Use as normative process-import inputs:

manifest/qualified-package-manifest-contract-v1.json
interface/qualified-launcher-consumer-import-contract-v1.json
analysis/auxiliary-identity-record-adjudication.json
interface/root-rebinding-field-map-v1.json
interface/bootstrap-materialization-order-v1.json
analysis/corrected-bootstrap-algorithm.json
closeout/verdict.json

Canonical verdict record:

- size:
  414
- SHA-256:
  5361158b8d8f57181bae449f2f7bf5994b3eeede681a4dd64187155e64ad6a63
- required `/verdict`:
  LAUNCHER_IMPORT_RECONCILED_BOOTSTRAP_VERIFIER_DEFECT

REPAIRED_IMPORTER_REFERENCE_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-bootstrap-importer-v1-audit-repair-h585ymcr

Use only as bounded reference evidence for the producer-retained successful
Carrier 0002 self-check semantics.

Expected source:

source/bootstrap_importer_v1.py

- size:
  84255
- SHA-256:
  1a7032d6ade79c3c5046f922fccbf870c716ede8100abc1969da5fad580b27bd

Do not adopt the producer result as the oracle.
Do not inspect any V3 target.

PINNED PYTHON:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Closed identity:

- version:
  Python 3.13.4
- regular:
  true
- links:
  1
- size:
  119424
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b

Permission bits and other host metadata are report-only.
Do not reject mode 0775.
Do not chmod or normalize the interpreter.

──────────────────────────────────────────────────────────────────────────────
2. FRESH PACKAGE
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh package root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask 077, prefix:

ES-repair10i-v3-full-audit-bootstrap-v1-

Recommended structure:

source/
contract/
schemas/
tests/
tests/fixtures/
validation/
lineage/
provenance/
closeout/
manifest/
private/

No retained empty directory is permitted.

All retained directories must be mode 0700.
All retained files must be regular, single-link mode 0600.
No symlink, special object, or multiply linked file is permitted.

──────────────────────────────────────────────────────────────────────────────
3. PACKAGE AUTHORITY
──────────────────────────────────────────────────────────────────────────────

Positive authority is limited to:

- exact process-input verification;
- fresh audit-root allocation;
- bootstrap provenance;
- exact five-artifact process materialization;
- fresh auxiliary-record generation;
- root-bound launch-contract generation;
- root-rebinding proof generation;
- Carrier 0002 payload/request generation;
- process-self-check qualification.

Explicit nonauthority must include:

- candidate-repository;
- source;
- product;
- runtime;
- deployment;
- publication;
- commit;
- V3 target correctness;
- V3 audit verdict;
- readiness;
- A6.

The package must not inspect a V3 target.

The package’s process-only qualification stops after successful Carrier 0002
and local cleanup.

──────────────────────────────────────────────────────────────────────────────
4. PACKAGE STRUCTURE
──────────────────────────────────────────────────────────────────────────────

Create at minimum:

source/
  full_audit_bootstrap_v1.py
  process_self_check_payload_v1.py
  qualification_harness_v1.py

contract/
  full-audit-bootstrap-contract-v1.json
  process-self-check-contract-v1.json
  fixed-environment-record-contract-v1.json
  launcher-identity-record-contract-v1.json
  root-rebinding-proof-contract-v1.json
  qualification-result-contract-v1.json

schemas/
  full-audit-bootstrap-contract-v1.schema.json
  process-self-check-result-v1.schema.json
  fixed-environment-record-v1.schema.json
  launcher-identity-record-v1.schema.json
  root-rebinding-proof-v1.schema.json

tests/
  test_full_audit_bootstrap_v1.py
  independent_bootstrap_validator_v1.py
  fixtures/

validation/
  producer-test-result-v1.json
  independent-validator-result-v1.json
  process-self-check-causal-matrix-v1.json
  deterministic-materialization-v1.json
  carrier-0002-handoff-v1.json
  failure-atomicity-v1.json
  source-identity-v1.json

lineage/
  failed-audit-binding-v1.json
  launcher-package-binding-v1.json
  import-reconciliation-binding-v1.json
  repaired-importer-reference-binding-v1.json
  proposed-supersession-v1.json

provenance/
  source-inventory-v1.txt
  attempt-index-v1.json
  package-build-v1.json

closeout/
  final-implementation-report-v1.md
  final-evidence-inventory-v1.json
  cleanup-v1.json

manifest/
  canonical-manifest-a-v1.json
  canonical-manifest-b-v1.json

Generated schemas remain projections. The executable bootstrap source and
closed contract own semantics.

──────────────────────────────────────────────────────────────────────────────
5. BOOTSTRAP CLI
──────────────────────────────────────────────────────────────────────────────

Freeze one exact CLI.

Recommended shape:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13 \
  -I -S -B \
  source/full_audit_bootstrap_v1.py \
  --qualified-launcher-root ABSOLUTE_ROOT \
  --import-reconciliation-root ABSOLUTE_ROOT \
  --audit-parent /Users/ds/Downloads \
  --audit-prefix EXACT_PREFIX

Derive and freeze the final exact option names, required status, types, and
canonical order.

No shell.
No PATH lookup.
No fallback input.
No target-root argument.

Stdout:

- exactly one:
  `AUDIT_ROOT=<absolute-path>\n`
- emitted only after root allocation and durable bootstrap-start retention;
- no earlier stdout.

Handled bootstrap success/failure stderr must be empty.

──────────────────────────────────────────────────────────────────────────────
6. CARRIER 0001 SEMANTICS
──────────────────────────────────────────────────────────────────────────────

Carrier 0001 must use literal exact paths and identities only.

No:

- glob;
- recursive discovery;
- scoring;
- first viable selection;
- fallback;
- candidate enumeration;
- PATH lookup;
- latest/prefix scanning;
- adoption of an existing root.

Carrier 0001 must:

1. Allocate a fresh audit root.
2. Retain and fsync bootstrap-start.
3. Emit the exact root locator.
4. Verify pinned Python.
5. Verify both qualified-package manifests under their exact
   `directory`/`regular` grammar.
6. Resolve exact manifest rows for the exact five process artifacts.
7. Verify the import-reconciliation manifests and exact verdict path.
8. Copy exactly the five process artifacts:
   - wrapper;
   - launcher;
   - CLI contract;
   - request contract;
   - environment policy.
9. Reopen and verify each copy.
10. Generate the fresh launcher identity record.
11. Generate the fresh fixed-environment record.
12. Generate the root-bound launch contract.
13. Generate the exact rebinding proof.
14. Generate the corrected Carrier 0002 payload and request.
15. Retain bootstrap outcome.

Carrier 0001 must not:

- inspect the V3 target;
- execute a target process;
- run Git;
- use network;
- invoke shell;
- copy qualification results as fresh truth.

──────────────────────────────────────────────────────────────────────────────
7. FIXED-ENVIRONMENT RECORD REPAIR
──────────────────────────────────────────────────────────────────────────────

Generate:

opening/fixed-environment-observation.json

The exact permitted top-level fields are:

- `authority`
- `environment`
- `schema`

No fourth top-level field is permitted.

Do not include:

- `policy`
- a path to the policy;
- a copied policy body;
- a redundant policy caption.

The separate copied environment-observation-policy contract remains the policy
authority.

The environment map must be exactly:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
HOME=<FRESH_ROOT>/private/home
TMPDIR=<FRESH_ROOT>/private/tmp

Generate the record from final fresh-root values.
Finalize it before launch-contract creation.
Bind its exact path, size, and SHA-256 in the launch contract.

Reject:

- missing field;
- unknown top-level field;
- stale qualification-root path;
- mismatched size/hash;
- generation after launch-contract finalization.

──────────────────────────────────────────────────────────────────────────────
8. EXACT ROOT-REBINDING PROOF
──────────────────────────────────────────────────────────────────────────────

Generate the proof required by the reconciled consumer import contract.

Use the exact twelve direct launch-contract pointers:

- `/qualification_root`
- `/wrapper/path`
- `/phase_runner_cli_contract/path`
- `/carrier_request_contract/path`
- `/fixed_environment/HOME`
- `/fixed_environment/TMPDIR`
- `/fixed_environment_record/path`
- `/fixed_environment_record/size`
- `/fixed_environment_record/sha256`
- `/launcher_identity_record/path`
- `/launcher_identity_record/size`
- `/launcher_identity_record/sha256`

Do not substitute:

- transitive fields;
- nonexistent launch-contract pointers;
- nested fields from the auxiliary records;
- report-only paths.

The proof must include the exact reconciled schema and top-level field map,
including at minimum:

- predecessor launch-contract identity;
- successor launch-contract identity;
- exact changed-field count:
  12;
- twelve changed-field objects;
- pointer;
- predecessor value;
- successor value;
- classification:
  `physical-audit-root-rebinding-only`;
- semantic effect:
  none;
- normalized predecessor projection;
- normalized successor projection;
- normalized predecessor identity;
- normalized successor identity;
- normalized equality:
  true;
- non-root difference count:
  0;
- success:
  true.

Derive the exact field map from the reconciliation records. Do not invent a
parallel proof schema.

Finalize the launcher identity and fixed-environment records first.
Finalize the launch contract next.
Finalize normalized projections and proof afterward.

──────────────────────────────────────────────────────────────────────────────
9. CORRECTED CARRIER 0002 SELF-CHECK
──────────────────────────────────────────────────────────────────────────────

Carrier 0002 must be an audit-process self-check only.

It must inspect no V3 target.

Freeze the positive assertion map with unambiguous names and polarity.

At minimum require:

1. `carrier_ordinal_is_2`
2. `audit_root_equals_context_root`
3. `constructed_environment_equals_launch_contract`
4. `observed_contract_environment_values_exact`
5. `same_pid`
6. `wrapper_sha256_exact`
7. `wrapper_sha256_occurrence_count_is_1`
8. `cli_conformance_is_pass`
9. `no_child_process_created`
10. `target_content_inspected_is_false`
11. `expected_outputs_complete`
12. `request_contains_no_invariant_override`

Raw posture fields must be retained separately:

- `child_process_created: false`
- `target_content_inspected: false`
- additional post-exec environment key names;
- no additional environment values.

Correct aggregation:

```
passed = all(assertions.values())
```

Every assertion value must mean success when true.

Never insert raw negative state into the positive assertion map.

In particular, do not use:

```
"target_content_inspected": False
```

as a positive assertion.

Use:

```
"target_content_inspected_is_false":
    target_content_inspected is False
```

Do not use the vacuous self-comparison:

```
context.payload_identity or self_sha == self_sha
```

Payload identity is already verified authoritatively by the wrapper.

Either:

- omit a duplicate payload-identity assertion; or
- verify it from wrapper-provided authenticated context whose absence fails
  closed.

No fallback-to-self value is permitted.

──────────────────────────────────────────────────────────────────────────────
10. SAME-PID EVIDENCE
──────────────────────────────────────────────────────────────────────────────

Carrier 0002 must explicitly verify same-PID continuity.

Retain:

- launcher PID immediately before terminal `execve`;
- payload PID from `os.getpid()` after wrapper entry;
- equality result.

The launcher already records its pre-exec PID in its constructed-launch
record. Use that exact field.

The payload must compare:

- retained launcher pre-exec PID;
- its own payload PID.

Require equality.

Do not demand a separate wrapper PID unless the qualified launcher contract
requires one.

Reject:

- missing launcher PID;
- missing payload PID;
- mismatched PID;
- comparison of the wrong two fields;
- a static-source-only claim substituted for retained dynamic equality.

──────────────────────────────────────────────────────────────────────────────
11. ENVIRONMENT ASSERTIONS
──────────────────────────────────────────────────────────────────────────────

Keep these distinct:

A. Constructed environment:

The constructed launch record’s environment must exactly equal the
launch-contract fixed environment.

B. Observed owned environment:

For every contract-owned key, the payload-observed value must remain exact.

C. Additional environment:

Additional post-exec key names are diagnostic only.
Additional values are not retained.
Additional keys do not fail the self-check.

Do not use whole observed-map equality.

Retain:

- constructed map identity;
- required-key comparison;
- missing required keys;
- changed required values;
- additional key names;
- constructed-map equality;
- observed-owned-values equality.

──────────────────────────────────────────────────────────────────────────────
12. CLI AND WRAPPER-SHA ASSERTIONS
──────────────────────────────────────────────────────────────────────────────

Carrier 0002 must verify from the constructed-launch record:

- conformance result is exactly `pass`;
- missing required options empty;
- unknown options empty;
- duplicate singleton options empty;
- malformed values empty;
- canonical option order true;
- expected-wrapper SHA occurs exactly once;
- expected-wrapper SHA value equals:
  6e911ca17dedc6c5838b8b880548761b9009bb18fc26f1e7b6934d274f040f56
- payload path/size/SHA exact;
- audit-root exact;
- carrier ordinal exact;
- phase exact;
- entry exact;
- expected outputs exact;
- authorized operands exact.

Do not infer these merely from phase-start existence.

──────────────────────────────────────────────────────────────────────────────
13. REQUEST AND OUTPUT POSTURE
──────────────────────────────────────────────────────────────────────────────

Carrier 0002 request must bind:

- root-bound launch-contract path, size, SHA-256;
- payload path, size, SHA-256;
- submitted cwd;
- exact expected outputs;
- exact authorized operands;
- no invariant override.

The self-check must require every declared expected output to exist at success
and to have its declared role, mode, link count, type, and identity where
defined.

The payload may create only the process-self-check result and any explicitly
contracted future request templates.

If future request templates are retained, classify them as nonexecuted,
nonauthoritative process inputs. Their presence must not imply later audit
progression.

──────────────────────────────────────────────────────────────────────────────
14. PRODUCER PROCESS-SELF-CHECK MATRIX
──────────────────────────────────────────────────────────────────────────────

Implement a complete matrix covering at least:

1. Correct target-inspection false posture passes.
2. Target-inspection true fails.
3. Raw false inserted into positive assertion map is rejected by static policy
   validation.
4. Child-process false posture passes.
5. Child-process true fails.
6. Constructed environment exact passes.
7. Constructed environment missing key fails.
8. Constructed environment changed value fails.
9. Constructed environment extra key fails.
10. Observed owned values exact with additional diagnostic key passes.
11. Observed required key missing fails.
12. Observed required value changed fails.
13. Additional key value is not retained.
14. Same PID passes.
15. PID mismatch fails.
16. Missing launcher PID fails.
17. Missing payload PID fails.
18. Wrapper SHA exact passes.
19. Wrapper SHA wrong fails.
20. Wrapper SHA missing fails.
21. Wrapper SHA duplicate fails.
22. CLI conformance pass succeeds.
23. Missing option fails.
24. Unknown option fails.
25. Duplicate singleton fails.
26. Malformed option fails.
27. Canonical order false fails.
28. Wrong payload identity fails through wrapper.
29. Vacuous payload self-comparison is rejected statically.
30. Wrong audit root fails.
31. Merely absolute but wrong audit root fails.
32. Request invariant override fails.
33. Missing expected output fails.
34. Unexpected output fails when the contract forbids it.
35. Fixed-environment record exact three-field shape passes.
36. Extra `policy` field fails.
37. Missing authority field fails.
38. Missing environment field fails.
39. Missing schema field fails.
40. Rebinding proof exact passes.
41. Missing one actual direct pointer fails.
42. Added transitive pointer fails.
43. Added nonexistent pointer fails.
44. Changed-field count other than 12 fails.
45. Normalized mismatch fails.
46. Non-root difference count nonzero fails.
47. Missing normalized projection fails.
48. `success:false` proof fails.
49. Stale qualification-root path fails.
50. Aggregate success passes only when every positive assertion is true.

Pin exact names and expected reasons independently of generated fixtures.

Require zero false acceptance.

──────────────────────────────────────────────────────────────────────────────
15. INDEPENDENT VALIDATOR
──────────────────────────────────────────────────────────────────────────────

Implement a second validator that imports no producer helper and does not use
producer fixtures as its case generator.

It must independently:

- parse and verify the fixed-environment schema;
- parse and verify the rebinding-proof schema;
- inspect self-check payload source for polarity;
- reject raw negative-state fields in the positive assertion map;
- reject vacuous payload-identity fallback;
- reconstruct expected assertions;
- generate its own mutation cases;
- verify same-PID evidence;
- verify environment semantics;
- verify CLI and wrapper-SHA semantics;
- verify no target access;
- verify no child process;
- verify successful aggregation.

Require exact case-name and reason closure.
Require zero false acceptance.

──────────────────────────────────────────────────────────────────────────────
16. TWO FRESH BOOTSTRAP MATERIALIZATIONS
──────────────────────────────────────────────────────────────────────────────

Run Carrier 0001 into two distinct implementation-owned roots.

Require:

- distinct physical roots;
- one exact root-locator line;
- exact five copied artifacts;
- valid launcher identity;
- exact three-field fixed-environment record;
- valid root-bound launch contract;
- valid exact twelve-pointer proof;
- normalized contracts byte-identical;
- normalized auxiliary records equal;
- corrected self-check payload source byte-identical;
- normalized Carrier 0002 requests equal;
- no target inspection;
- Carrier 0002 not yet executed at materialization time.

Retain complete inventories before cleanup.

──────────────────────────────────────────────────────────────────────────────
17. TWO SUCCESSFUL CARRIER 0002 HANDOFFS
──────────────────────────────────────────────────────────────────────────────

Execute Carrier 0002 successfully in both fresh roots through the exact
qualified launcher and wrapper.

For each require:

- request admission;
- constructed launch;
- wrapper parser admission;
- phase start/outcome;
- compilation and execution;
- exact owned environment;
- diagnostic-only extra key names;
- same PID;
- wrapper SHA exact and once;
- CLI conformance pass;
- no child;
- no target inspection;
- every expected output present;
- payload `success:true`;
- wrapper exit 0.

The two normalized self-check results must be byte-identical after permitted
root/PID normalization.

The package’s qualification stops after those two self-checks.

No target process may run.

──────────────────────────────────────────────────────────────────────────────
18. FAILURE ATOMICITY
──────────────────────────────────────────────────────────────────────────────

Inject safe failures at minimum during:

- exact input verification;
- process-artifact copy;
- launcher identity retention;
- fixed-environment retention;
- launch-contract retention;
- normalized projection retention;
- rebinding-proof retention;
- self-check payload retention;
- Carrier 0002 request retention;
- Carrier 0002 self-check failure.

For each require:

- root locator retained;
- bootstrap-start retained;
- canonical failure/outcome;
- no success result;
- partial artifacts exact;
- no overwrite;
- no retry in the failed root;
- no target inspection;
- no later progression.

──────────────────────────────────────────────────────────────────────────────
19. STATIC SOURCE AND SECURITY REVIEW
──────────────────────────────────────────────────────────────────────────────

Inspect all package source for:

- network;
- Git;
- shell;
- target paths;
- broad Downloads scan;
- latest/prefix selection;
- existing-root adoption;
- symlink traversal;
- overwrite;
- unsafe modes;
- secret-bearing output;
- raw additional environment values;
- implicit authority widening.

The bootstrap may spawn only the exact Carrier 0002 process during package
qualification. The production bootstrap source itself may materialize but must
not automatically advance into target audit work.

No candidate or V3 target path literal is permitted in executable source.

──────────────────────────────────────────────────────────────────────────────
20. LINEAGE AND NONAUTHORITY
──────────────────────────────────────────────────────────────────────────────

Retain exact bindings to:

- failed audit root and its causal records;
- qualified launcher root;
- import-reconciliation root;
- repaired-importer producer handoff reference.

The package must state explicitly:

- failed audit remains nonqualifying;
- malformed rebinding proof is superseded only as process evidence;
- extra fixed-environment field is superseded only as process evidence;
- failed self-check result remains historical;
- qualified launcher and wrapper remain unchanged;
- no V3 target conclusion is inherited.

Nonauthority must explicitly cover:

- repository;
- source;
- product;
- runtime;
- deployment;
- publication;
- commit;
- V3 correctness;
- audit verdict;
- readiness;
- A6.

──────────────────────────────────────────────────────────────────────────────
21. PROCESS EVIDENCE
──────────────────────────────────────────────────────────────────────────────

Retain complete contemporaneous records for every validation subprocess:

- start before spawn;
- argv;
- cwd;
- explicit environment;
- stdout;
- stderr;
- exit/signal;
- reaping;
- descriptor closure.

Do not claim visibility into opaque platform carrier internals.

No failed attempt may contribute a passing identity, count, or verdict.

──────────────────────────────────────────────────────────────────────────────
22. CLOSING EQUALITY AND CLEANUP
──────────────────────────────────────────────────────────────────────────────

Repeat complete inventories for every supplied root opened.

Require exact opening/closing equality.

Retain complete inventories of implementation-owned fixture roots before
removing them.

For each removed root, require two fresh ENOENT observations.

Verify no process or descriptor survivor.

──────────────────────────────────────────────────────────────────────────────
23. PACKAGE CLOSURE
──────────────────────────────────────────────────────────────────────────────

Use two independent lstat/no-follow manifest generators.

Require:

- root represented;
- every directory represented;
- every nonmanifest regular file represented;
- exactly two manifest self-exclusions;
- no empty retained directory;
- no symlink;
- no special object;
- no multiply linked file;
- directories mode 0700;
- files regular, single-link mode 0600;
- byte-identical manifests.

Finalize:

- source;
- contracts and schemas;
- payload template;
- producer matrix;
- independent validator;
- two materializations;
- two self-check handoffs;
- failure causals;
- lineage;
- process records;
- security review;
- attempts;
- cleanup;
- final report;
- final inventory;
- manifest pair.

──────────────────────────────────────────────────────────────────────────────
24. STOP CONDITIONS
──────────────────────────────────────────────────────────────────────────────

Return
`VALIDATION_CUSTODY_V3_FULL_AUDIT_BOOTSTRAP_IMPLEMENTATION_BLOCKED`
on:

- supplied-input drift;
- need to modify the qualified launcher or wrapper;
- ambiguity in the reconciled import interface;
- inability to generate the exact auxiliary schemas;
- inability to implement the exact twelve-pointer proof;
- false acceptance in either validator;
- self-check regression;
- target access;
- unrelated process behavior change;
- nondeterministic normalized result.

Return `IMPLEMENTATION_PROVENANCE_MISMATCH` on:

- supplied-root mutation;
- incomplete process evidence;
- missing final artifact;
- opening/closing inequality;
- manifest closure failure.

Do not repair supplied inputs.

──────────────────────────────────────────────────────────────────────────────
25. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh package identity
3. Immutable input identities
4. Reproduced failed self-check causal
5. Exact authority and nonauthority
6. Exact touched/created semantic files
7. Bootstrap CLI
8. Carrier 0001 algorithm
9. Fixed-environment record schema
10. Root-bound launch contract
11. Exact twelve-pointer proof
12. Corrected Carrier 0002 assertion map
13. Target-inspection polarity treatment
14. Payload-identity treatment
15. Same-PID treatment
16. Environment treatment
17. CLI and wrapper-SHA treatment
18. Producer matrix result
19. Independent validator result
20. Two fresh materializations
21. Two successful Carrier 0002 handoffs
22. Failure-atomicity results
23. Security findings
24. Failed/superseded attempts
25. Supplied-root closing equality
26. Fixture cleanup
27. Package inventory and manifests
28. Severity-ranked residual findings
29. Remaining uncertainty and nonclaims
30. Explicit confirmations

Required confirmations:

FAILED_AUDIT_ROOT_MUTATION_NOT_PERFORMED
QUALIFIED_LAUNCHER_PACKAGE_MUTATION_NOT_PERFORMED
IMPORT_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
REPAIRED_IMPORTER_REFERENCE_MUTATION_NOT_PERFORMED
CANDIDATE_REPOSITORY_NOT_INSPECTED
STRATEGIC_B_NOT_INSPECTED
V1_V2_V3_TARGETS_NOT_INSPECTED
TARGET_INSPECTION_POLARITY_CORRECT
RAW_FALSE_TARGET_STATE_NOT_USED_AS_POSITIVE_ASSERTION
VACUOUS_PAYLOAD_IDENTITY_ASSERTION_REMOVED
FIXED_ENVIRONMENT_RECORD_EXACT_THREE_FIELD_SHAPE
REBINDING_PROOF_EXACT_SCHEMA
REBINDING_PROOF_EXACT_TWELVE_POINTERS
NORMALIZED_LAUNCH_CONTRACTS_EQUAL
NON_ROOT_DIFFERENCE_COUNT_ZERO
CONSTRUCTED_ENVIRONMENT_ASSERTED
OBSERVED_OWNED_ENVIRONMENT_ASSERTED
ADDITIONAL_ENVIRONMENT_KEYS_DIAGNOSTIC_ONLY
SAME_PID_ASSERTED
WRAPPER_SHA_VALUE_ASSERTED
WRAPPER_SHA_CARDINALITY_ASSERTED
CLI_CONFORMANCE_ASSERTED
NO_CHILD_PROCESS_ASSERTED
TARGET_CONTENT_NOT_INSPECTED_ASSERTED
TWO_FRESH_MATERIALIZATIONS_PASSED
TWO_CARRIER_0002_HANDOFFS_PASSED
PRODUCER_MATRIX_PASSED
INDEPENDENT_VALIDATOR_PASSED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
FULL_V3_AUDIT_NOT_STARTED
A6_NOT_STARTED
INDEPENDENT_AUDIT_NOT_PERFORMED
SUBAGENTS_CREATED: 0
```

After this package reports
`VALIDATION_CUSTODY_V3_FULL_AUDIT_BOOTSTRAP_IMPLEMENTED_READY_FOR_FRESH_AUDIT`,
perform a fresh independent audit of the package. Do not return directly to the repaired-importer audit.

**Source:** Codex’s `PROCESS_SELF_CHECK_RECONCILED_AUDIT_PAYLOAD_ORACLE_DEFECT` report above.

**Confidence:** 0.999 that the immediate exit-30 cause was the target-inspection polarity error; 0.995 that the launcher, wrapper, request, launch contract, and fixed owned environment were operationally correct; 0.98 that packaging the complete Carrier 0001/0002 boundary is now the correct final process-infrastructure step.
