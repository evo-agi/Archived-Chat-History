## Assessment

This fifth **BLOCK** is credible, but SEC-02 is qualitatively different from the previous verifier bugs.

The verifier cannot conclusively determine, after Python has begun executing the script, which filesystem object the interpreter originally loaded. The audit demonstrated exactly that gap: Python loaded target-contained code through an external symlink; the path was then replaced with the legitimate external verifier before `open_source_binding()` ran; all later path, descriptor, identity, and closing checks observed only the replacement.

Another local amendment to `open_source_binding()` would therefore be the wrong next step. This is now an **interpreter launch-custody decision**, not merely a pathname-validation repair.

The most promising bounded replacement is an **argv-bound source launch**:

1. The external producer or auditor opens and hashes the exact committed `verify_v1.py` under no-follow custody.
2. It supplies those exact UTF-8 source bytes as Python’s `-c` argument rather than asking Python to load the script from a mutable pathname.
3. The verifier recovers the executed code string from `sys.orig_argv`, requires exact equality with the package’s externally pinned `verify_v1.py`, and binds the package/registry/layout roots physically.
4. The target can no longer select which code Python loads by racing a script pathname.
5. External provenance remains the source of trust; the verifier still does not certify its own correctness or authority.

That model needs behavioral confirmation before implementation. A descriptor-backed launch capsule is the fallback. Merely documenting an “immutable launch path” precondition would be weaker and should not be adopted unless the project deliberately excludes concurrent control of the launcher path from the threat model.

The project’s frozen architecture requires exact source to be supplied to a fresh audit without making the verifier self-verifying.  The operating protocol also calls for read-only reconnaissance before implementation when an authority or architectural decision remains unresolved. 

## Codex prompt: executable-source launch-custody reconnaissance

```text
MANDATORY RESPONSE-FORMAT REQUIREMENT

Your final response must embed the complete reconnaissance report inline in
Markdown.

Do not respond with only:

- a verdict;
- a short summary;
- a link to a local report;
- “full report available at …”;
- or an attachment reference.

You may create and link source-external evidence as supplemental material, but
the complete required report must also appear in the response body.

This requirement applies to every outcome:

- READY;
- PARTIAL;
- BLOCKED;
- BASELINE_MISMATCH;
- SUBAGENT_UNAVAILABLE.

Do not silently truncate the inline report.

Objective

Perform a read-only architecture and feasibility reconnaissance for the
Evidence Verification v1 executable-source load-custody boundary exposed by
the fifth independent audit’s SEC-02 finding.

Do not implement or edit anything.

The fifth audit demonstrated that post-load source-path binding is
insufficient:

1. Python began loading script bytes through an external symlink whose target
   was source physically beneath the evidence target.
2. The loaded source executed a synchronization prelude.
3. An external actor atomically replaced the symlink with a direct regular
   external file containing the exact current verifier bytes.
4. `open_source_binding()` and all closing checks observed only the
   replacement.
5. The target-contained loaded code then returned canonical `pass`.

The current patch’s stationary SEC-01 checks remain useful, but no further
post-load pathname check can by itself prove which object Python originally
loaded.

Freeze one safe, finite launch-custody design before authorizing any source
mutation.

No repository mutation.
No documentation edit.
No formatting.
No staging, commit, push, PR, merge, installation, deployment, A6 restart,
product execution, product A/B, live-service invocation, network contact, or
Linux binary execution.

No writer subagents.
No nested subagents.

## 1. Inputs

Implementation worktree:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Expected branch:

codex/evidence-verification-v1

Expected HEAD:

567bceced5df95ecfe787cc66038d463a854e12c

Expected HEAD tree:

b7cab23732572c2aaea9d5f2f1593338e2e75338

Expected sole parent:

05dde14d185b6e022dcc169ef1a658a97961850f

Expected upstream:

absent

Exact current canonical patch manifest:

EXPECTED_MANIFEST=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v3/provenance/manifest-run-1.json

Expected manifest SHA-256:

f900d6abb37f74fbcd628f622354e8e7898fb341a074071e464288e978e5b9d8

Expected tracked binary-diff SHA-256:

8aea2e7529c49a2bcda866ad60dbab43b31bb594f705a320ada92576a99507ac

Expected verifier SHA-256:

1379fd38799e12a44979812532f6100dc16e2af1a386b3297c5e85b450ab405f

Expected test SHA-256:

cf2f786435787bdf0c19d133f3ea15ffab52083de4163d30db6d0eaa56077132

Exact provenance recipe:

RECIPE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/capture-final-provenance-v1.py

Expected recipe SHA-256:

bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333

Repair-v3 report:

REPAIR_V3_REPORT=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v3/closeout/implementation-report-v3.md

Fifth audit root:

AUDIT_V5=/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5

Fifth audit report:

AUDIT_V5_REPORT=/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5/closeout/report.md

SEC-02 causal record:

SEC02_RECORD=/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5/perspectives/security-artifact/source-load-race-result.json

Original sealed A6D child:

A6D=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

Sealed A6D amendment:

A6D_AMEND=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

Pinned interpreter:

PYTHON=/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Expected interpreter:

- version `3.13.4`;
- size `119424`;
- SHA-256:
  `f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b`.

Required initially absent reconnaissance root:

RECON_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-load-custody-recon-f900d6abb37f

Forbidden primary checkout:

PRIMARY_R=/Users/ds/Repositories/Execution Substrate

## 2. Strict posture and Git boundary

Set:

GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

Only the parent may execute Git.

Every Git command must be exactly:

git -C "$IMPL_R" ...

with both Git environment bindings above.

No subagent may execute Git.

Do not execute Git in:

- PRIMARY_R;
- A6D;
- A6D_AMEND;
- any implementation-evidence root;
- any audit root;
- RECON_ROOT.

No implicit-cwd Git commands.

Record all parent Git argv, cwd, and relevant environment.

## 3. Opening gate

Require IMPL_R:

- physical root equals lexical path;
- branch:
  `codex/evidence-verification-v1`;
- HEAD:
  `567bceced5df95ecfe787cc66038d463a854e12c`;
- tree:
  `b7cab23732572c2aaea9d5f2f1593338e2e75338`;
- sole parent:
  `05dde14d185b6e022dcc169ef1a658a97961850f`;
- upstream:
  absent;
- exactly 13 changed or untracked paths;
- exactly four modified tracked and nine untracked;
- every path regular, single-link, working mode `0644`, logical mode `100644`;
- zero staged, deleted, renamed, or unmerged;
- no extra path;
- no Git operation marker or lock.

Require:

- EXPECTED_MANIFEST exact and stable;
- manifest SHA-256 exact;
- live 13-path bytes equal the manifest;
- tracked binary diff exact;
- verifier and test SHA-256 exact;
- RECIPE source exact;
- AUDIT_V5_REPORT and SEC02_RECORD present and stable.

Stop on any mismatch:

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_RECON_BASELINE_MISMATCH

## 4. Reconnaissance evidence root

After the opening gate, require RECON_ROOT absent.

Create it under umask `077` with:

opening/
perspectives/
probes/
findings/
closeout/

All outputs remain beneath RECON_ROOT.

Probe-created temporary roots must be beneath:

RECON_ROOT/probes/tmp/

Remove only probe-owned temporary roots.

Do not write into IMPL_R or supplied evidence.

## 5. Read-only explorer workflow

Spawn exactly four bounded read-only explorers in parallel.

No nested subagents.

No explorer Git commands.

### Explorer 1 — Python load and invocation semantics

Determine, under pinned Python 3.13.4:

- what Python opens and closes for ordinary script execution;
- what source identity remains observable after module execution begins;
- exact contents of `sys.argv`, `sys.orig_argv`, `__file__`, `__spec__`,
  `__loader__`, and the module code object under:
  - direct script execution;
  - final symlink execution;
  - `python -c`;
  - `python -`;
  - `/dev/fd/N`;
- whether `sys.orig_argv` retains the exact `-c` source string, including:
  - embedded newlines;
  - terminal LF;
  - UTF-8 round trip;
  - current verifier’s approximately 37 KiB source;
- command-size bounds on this host;
- whether the actual module code object can be compared deterministically to
  separately compiled source and what that proves or does not prove;
- whether Python exposes the originally loaded script inode through any
  supported API;
- FD inheritance, `pass_fds`, `/dev/fd`, and descriptor lifetime behavior;
- whether macOS `F_GETPATH` or another supported descriptor operation can
  recover useful physical source location and its limits.

Return evidence, inference, uncertainty, and a feasibility table.

### Explorer 2 — Authority and contract analysis

Inspect:

- current architecture-reset decision;
- `PLANS.md`;
- evidence-verification documentation;
- artifact hygiene;
- capability probing;
- provenance guidance;
- SEC-02 report and minority view.

Determine:

- which owner must establish source-byte trust;
- which owner may establish launch custody;
- whether source location is an invariant or merely one current mechanism;
- whether exact executed-byte identity can replace physical source-location
  identity without weakening the non-self-verification model;
- whether an externally enforced stable-launch-path precondition is sufficient
  under the current threat model;
- whether the invocation contract change requires:
  - no version change;
  - a launch-protocol version only;
  - tool v2;
  - output/schema changes;
- which governing docs must change for each viable model.

Do not silently reinterpret the existing categorical source-external rule.

### Explorer 3 — Security and threat-model analysis

Analyze at least:

- attacker controls target only;
- attacker controls external launch pathname concurrently;
- attacker has same-UID rename/write capability;
- attacker can create symlinks or hardlinks;
- attacker can replace package files but not interpreter argv;
- attacker can alter environment but not pinned argv;
- privileged filesystem identity forgery;
- source bytes are exact but physically target-contained;
- loaded source bytes differ but compile to equivalent code objects;
- code-object comparison versus exact-byte comparison;
- source package and registry/spec substitution;
- bootstrap recursion and the root of trust.

Evaluate the security guarantees of every candidate model below.

Identify which guarantees are actually required by current repository contracts
and which would be new strategic hardening.

### Explorer 4 — Migration, validation, and bounded implementation map

For every viable model:

- identify exact repository files that would change;
- identify any new file;
- classify a new file as source, inert source text, launcher, fixture, or spec;
- identify invocation migration for:
  - unit tests;
  - real A6D verification;
  - amendment verification;
  - synthetic A6;
  - later producer and auditor use;
- define causal tests;
- define provenance and fresh-audit inputs;
- decide whether registry/layout bytes remain unchanged;
- decide whether historical fixtures remain inert;
- identify exact stop conditions;
- estimate whether the model fits one finite implementation tranche.

Preserve disagreements among explorers.

## 6. Candidate models that must be adjudicated

Do not assume the current post-load model is salvageable.

### Model A — Post-load pathname binding

Current model, including further `open_source_binding()` strengthening.

Expected disposition unless contradicted by evidence:

- insufficient for the load-to-binding interval.

Explain precisely why.

### Model B — Externally trusted immutable launch-path precondition

The verifier remains a normal script. Producer/auditor asserts that the direct
source pathname cannot change from before interpreter load through process
completion.

Evaluate:

- how that precondition would be proved;
- whether ordinary ownership and mode bits are sufficient against same-UID
  mutation;
- whether this is honest under current contracts;
- whether it merely moves an unproved premise outside the verifier.

Do not select this model merely because canonical audit invocations happened
to use stable paths.

### Model C — Source-by-value `python -c` launch

Primary candidate.

The external producer/auditor:

1. no-follow opens the exact committed `verify_v1.py`;
2. reads and hashes the exact bytes;
3. requires equality with externally supplied provenance;
4. decodes the admitted canonical UTF-8 source;
5. passes those exact source characters as the interpreter’s `-c` argument;
6. passes an explicit physical package-root argument;
7. launches the pinned interpreter directly, without a script pathname.

The verifier:

- requires `-c` launch;
- recovers the executed source string from `sys.orig_argv`;
- enforces an exact, unambiguous `-c` argv shape;
- encodes the recovered string canonically;
- binds it byte-for-byte to the no-follow-opened package
  `tools/evidence_verify/verify_v1.py`;
- derives registry and layouts from a physically checked package root;
- retains existing target/candidate/package disjointness;
- rejects ordinary script launch, symlink launch, stdin launch, or ambiguous
  argv;
- does not treat its comparison as proof of trust;
- emits no source hash or source path;
- relies on external provenance for trust in the supplied bytes.

Behaviorally determine:

- whether exact source bytes round-trip through argv;
- whether current source size is safely beneath host limits;
- whether terminal LF and UTF-8 are stable;
- whether `sys.orig_argv` is sufficient and immutable for the process;
- whether package-file swaps are caught;
- whether this closes SEC-02 without recursive launcher trust;
- what external caller code is needed to construct argv safely.

### Model D — FD-bound source and package launch capsule

The external producer/auditor:

- opens source and package parent no-follow;
- hashes the held source FD against external provenance;
- passes source and package FDs to the child;
- invokes Python through a descriptor-backed path or a minimal `-c` bootstrap.

The verifier:

- requires inherited source/package FDs;
- verifies source and package identities and ancestry;
- ensures Python executed bytes from that exact held source object;
- rechecks custody at close.

Determine:

- whether `/dev/fd/N` gives a reliable same-object load;
- whether Python closes or duplicates relevant FDs;
- whether the verifier can prove the loaded object was the inherited FD;
- whether a bootstrap is still required;
- whether the bootstrap introduces another source-of-trust recursion;
- schema/evidence needed for the launch capsule.

### Model E — Canonical `-c` bootstrap that compiles held-FD source

The external caller passes one exact, independently audited bootstrap program
as the `-c` argument.

The bootstrap:

- opens source/package no-follow;
- verifies source bytes against external expected provenance;
- retains source and package FDs;
- compiles and executes exact bytes from the held source FD;
- injects a closed launch-custody object into the verifier;
- leaves required FDs available for closing revalidation.

Determine:

- where exact bootstrap source lives;
- how producer/auditor obtains it without another mutable-script launch;
- whether it is prompt-carried, repository-retained inert text, or a new
  committed contract;
- whether that creates a second verifier or new authority owner;
- whether it is necessary if Model C works.

### Model F — Native or compiled launcher

Evaluate only as a fallback:

- correctness value;
- dependency/build/artifact cost;
- cross-platform implications;
- new source and binary provenance;
- whether it is disproportionate for the current bounded tranche.

### Model G — Contract relaxation to executed-byte equivalence

The physical source may originate beneath the target if the code actually
executed is proven byte- or code-equivalent to externally pinned source.

Evaluate separately:

- exact-byte equivalence;
- Python code-object equivalence;
- comments/encoding/compiler flags;
- whether this preserves or abandons the no-self-verification architecture;
- whether it would require an explicit strategic change.

Do not select this silently as an implementation convenience.

## 7. Required parent probes

After all explorers return, the parent may run bounded, source-external probes
under RECON_ROOT only.

Use pinned Python and no network.

At minimum probe:

1. `sys.orig_argv` under `-c` with exact current verifier source.
2. Exact round trip:
   - source file bytes;
   - decoded source string;
   - `sys.orig_argv` source string;
   - re-encoded bytes.
3. Terminal-LF preservation.
4. Source-size and argv-size margin.
5. Direct script versus final symlink versus `-c` observable state.
6. Source-by-value execution with a physically target-contained source path
   present but never loaded.
7. Package-root binding and package source comparison.
8. Package source replaced after `-c` argv construction.
9. `/dev/fd/N` source execution with inherited FD.
10. Source FD and package FD survival.
11. Module-code-object versus recompiled-source comparison.
12. Any claimed macOS descriptor-path mechanism.

Do not probe with repository files as mutable targets. Use byte-exact private
copies.

Retain:

- exact probe source;
- argv;
- environment;
- stdout/stderr;
- exit;
- file identities;
- cleanup.

## 8. Selection criteria

The selected model must:

1. Bind the object or exact bytes Python executes before target-controlled code
   can run.
2. Preserve external provenance as the trust source.
3. Avoid verifier self-certification.
4. Avoid recursive amendment or launcher trust.
5. Fail closed on unsupported capability or ambiguous invocation.
6. Preserve no-write, no-child-process-by-verifier, and no-network behavior.
7. Keep output free of source/package/target paths and readiness claims.
8. Remain compatible with independent real A6D, amendment, and synthetic A6
   verification.
9. Admit deterministic producer and auditor invocation.
10. Fit one finite, auditable implementation tranche.
11. State the exact threat model and residual assumptions.
12. Avoid depending on a mere same-UID-writable pathname remaining stable.

If no model satisfies all twelve criteria, return BLOCKED rather than forcing
a design.

## 9. Parent synthesis requirements

The parent must:

- wait for all four explorers;
- preserve every disagreement;
- distinguish source evidence, platform/API evidence, inference, and strategic
  choice;
- reconcile current contracts with the selected target;
- decide one primary model and at most one fallback;
- decide whether SEC-02 is:
  - implementation-only;
  - invocation-contract;
  - tool-version;
  - architecture-boundary;
- freeze exact touched-file scope;
- freeze exact invocation;
- freeze exact external-launcher responsibilities;
- freeze exact verifier responsibilities;
- freeze tests and independent-audit requirements;
- define migration from current audit inputs;
- define stop conditions;
- close every explorer;
- reverify repository and supplied evidence unchanged.

Do not implement.

## 10. Required verdicts

Return exactly one:

### Ready

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_RECONNAISSANCE_READY

Use only when one complete, finite launch model is frozen with no material
authority or feasibility gap.

### Partial

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_RECONNAISSANCE_PARTIAL

Use when a preferred direction exists but a bounded runtime or ownership
question remains.

### Blocked

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_RECONNAISSANCE_BLOCKED

Use when no candidate safely closes SEC-02 under the current constraints.

### Baseline mismatch

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_RECON_BASELINE_MISMATCH

Use on repository, recipe, manifest, audit, or supplied-evidence drift.

### Required explorer unavailable

SUBAGENT_UNAVAILABLE

Use when required perspective coverage remains missing after one retry.

## 11. Required complete inline report

Your final response must embed the complete report inline.

Include:

1. Verdict.
2. Response-format confirmation.
3. Opening and closing repository/provenance identity.
4. Fifth-audit SEC-02 statement and exact causal mechanism.
5. Why post-load path binding cannot by itself prove the loaded object.
6. Four explorer scopes and completion status.
7. Preserved disagreements.
8. Probe environment and exact probes run.
9. Probe results.
10. Model A adjudication.
11. Model B adjudication.
12. Model C adjudication.
13. Model D adjudication.
14. Model E adjudication.
15. Model F adjudication.
16. Model G adjudication.
17. Selected primary model.
18. Selected fallback, if any.
19. Explicitly rejected models and why.
20. Exact threat model.
21. Residual trust assumptions.
22. Exact future invocation contract.
23. Exact external producer/auditor responsibilities.
24. Exact verifier responsibilities.
25. Whether direct script invocation remains supported.
26. Tool and launch-protocol version disposition.
27. Output/schema disposition.
28. Registry/layout disposition.
29. Exact intended touched-file set.
30. Any new file and its classification.
31. Complete causal and validation matrix.
32. Real A6D/amendment migration.
33. Synthetic A6 migration.
34. Provenance and fifth-successor-audit sequence.
35. Mandatory stop conditions.
36. Inspection limits and unresolved uncertainty.
37. Audit-created probe artifacts and cleanup.
38. Explicit confirmations:
    - repository mutation not performed;
    - documentation mutation not performed;
    - implementation not performed;
    - tests of repository source not run;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 not restarted;
    - product paths/live services not invoked;
    - network contact not performed;
    - nested subagents not created.

Do not replace any section with a link.

Links may appear only as supplemental references after the complete inline
report.

No implementation.
No staging.
No commit.
No push.
No A6 restart.
```

## Likely direction

The **source-by-value `python -c` model** is the leading candidate because the bytes Python executes are placed directly in the immutable process argv rather than selected through a raceable script pathname. `sys.orig_argv` can potentially let the verifier bind those executed characters to the externally pinned package source without granting itself source-trust authority. The reconnaissance must prove that exact round trip and invocation shape before it is frozen.

If that model is not exact or portable enough, the fallback is an FD-backed `-c` bootstrap—not another post-load path check.

### Sources

- Fifth independent audit supplied in this turn: SEC-02 and the load-to-binding race.
- The verifier architecture explicitly selects exact externally supplied source and rejects self-verification. 
- The architecture’s current direct-script invocation and source-package boundary are explicit, so changing launch semantics requires a named decision rather than an incidental patch. 
- Read-only reconnaissance must precede implementation when the authority or architecture decision remains unresolved. 
- Implementation, audit, repair, and commit are separate engagement types; changed bytes require new provenance and another audit. 
- Exact source bytes must remain externally available; source hash alone is insufficient. 
- Provenance binds everyone to the same bytes but does not establish correctness or authority. 
- Proof scaffolding and generated evidence must remain non-authoritative. 

**Confidence**

- Fifth-audit BLOCK verdict: **0.997**
- SEC-02 as a real load-custody gap: **0.995**
- Another post-load pathname repair being insufficient: **0.99**
- Source-by-value `-c` launch as the leading bounded model: **0.88**
- Need for read-only design reconnaissance before further edits: **0.998**
