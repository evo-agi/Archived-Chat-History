## Engineering assessment

This is the decisive authority migration we needed.

The bundle succeeded on the right boundary:

- The seven current package roles were recovered as **manifest-authenticated content snapshots**.
- Attempt 2 was retained only as a **bounded failure-evidence subset**, without silently promoting unbound files.
- Every manifest-covered regular file was authenticated by exact bytes.
- Historical temporal inventories and canonical manifests were preserved unchanged.
- Volatile directory metadata and `.DS_Store` contamination were recorded separately rather than rewritten into package truth.
- The deterministic archive excluded `.DS_Store`, directory entries, symlinks, special objects, and unsafe member names.
- Build A and Build B were byte-identical.
- Two independent bundle rehearsals produced byte-identical archives.
- The builder source froze and requalified.
- All authoritative members of the supplied roots closed equal.
- The final archive and authority JSON are read-only, exact-file authorities. No implementation or package verdict was issued.

The new current authority boundary is now exactly:

```text
/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip
```

- device/inode: `16777234 / 181651092`
- mode/link count: `0400 / 1`
- size: `13,598,758`
- SHA-256: `b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671`

and:

```text
/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json
```

- device/inode: `16777234 / 181651098`
- mode/link count: `0400 / 1`
- size: `19,737`
- SHA-256: `276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563`

The containing directory is explicitly nonauthoritative. Later work must not reopen the contaminated roots.

### Two cautions to preserve

First, the bundle is a **content authority**, not a reconstructed directory image. Consumers must resolve roles and original paths through `bundle/index.json` and the role records. They must not assume that original directories exist as ZIP members.

Second, `bundle/index.json` has 478 ordinary member rows plus its declared self member, while the archive contains 479 members. Its exact index-member identity is externally bound by the authority JSON to avoid cryptographic self-reference. The new harness must implement that model exactly rather than treating the index as incomplete.

### Progression decision

Proceed directly to a new clean source-external independent-audit harness.

A separate closure-verifier tranche is no longer needed. The bundle’s authority JSON, index, role registry, original closure records, and copied bytes are sufficient for a clean harness to implement its own narrow fixed-input authentication lane.

The harness itself should also use a file-level authority boundary to avoid repeating the `.DS_Store` problem. The recommended final outputs are:

```text
gen2-clean-source-external-independent-audit-harness-v1.pyz
gen2-clean-source-external-independent-audit-harness-v1.authority.json
```

The `.pyz` should be a deterministic executable ZIP application, run through pinned Python with `-I -S -B`. The authority JSON should bind its exact bytes, internal members, source freeze, qualification evidence, future invocation, and input bundle identities.

This task should implement and qualify the harness but **must not run the real full audit**. After success, the next tranche is exactly one fresh independent audit of the unchanged implementation evidence contained in the snapshot bundle.

---

```text
IMPLEMENT, QUALIFY, FREEZE, AND PACKAGE A NEW CLEAN
SOURCE-EXTERNAL INDEPENDENT-AUDIT HARNESS FOR THE SEALED
GENERATION-2 RECONSTRUCTION-PARENT IMPLEMENTATION

FILE-LEVEL CURRENT AUTHORITY ONLY

Objective

Implement a clean-room source-external independent-audit harness using only:

1. the exact current-authority content snapshot ZIP;
2. the exact authority JSON that binds that ZIP;
3. new source authored in this task from the governing contracts, schemas,
   validation specifications, and reconciliation evidence inside that bundle.

The harness must be implemented, qualified, frozen, requalified, and packaged
as a deterministic executable Python ZIP application.

Do not reopen any original current package directory.

Do not reopen any contaminated live authority root.

Do not open any historical audit-harness, verifier, builder, repair, or audit
root.

Do not copy, patch, translate, import, execute, or use as an AST/bytecode/source
origin any historical audit-harness or verifier source.

Do not use implementation production source as harness source. It may be read
from the bundle only as the future audit subject and during bounded
compatibility qualification. It must not be executed.

Do not execute the real full independent audit in this task.

Do not construct the authoritative current schema subject.

Do not issue an implementation ACCEPT or BLOCK verdict in this task.

Do not perform another historical findings reconciliation.

Do not create subagents or direct auditors.
Do not use Git or another VCS.
Do not read `.git` metadata.
Do not use the network.
Do not install dependencies.
Do not invoke product or live-service behavior.
Do not publish, deploy, externally commit, or start A6.

Use one finite parent-owned implementation and qualification process in one
fresh private working root.

At most three complete clean-source attempts are permitted.

Return the complete operative report inline. Artifact paths may supplement but
must not replace source identities, authority findings, interface contracts,
matrix results, process custody, rehearsal results, package identities, and
disposition.

Return exactly one primary verdict:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_PYZ_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_FRESH_AUDIT

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_IMPLEMENTATION_BLOCKED

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. EXACT CURRENT INPUT FILES
──────────────────────────────────────────────────────────────────────────────

CURRENT_AUTHORITY_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected identity:

- device:
  16777234
- inode:
  181651092
- mode:
  0400
- link count:
  1
- size:
  13598758
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671

CURRENT_AUTHORITY_JSON:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected identity:

- device:
  16777234
- inode:
  181651098
- mode:
  0400
- link count:
  1
- size:
  19737
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563

The containing output directory is not authority-bearing.

Do not depend on:

- its inode;
- its member set;
- its mode;
- its modification time;
- absence or presence of `.DS_Store`;
- any other file in that directory.

The authority boundary is exactly:

authority-JSON bytes
+
bundle-ZIP bytes

Open no other supplied root.

──────────────────────────────────────────────────────────────────────────────
2. FRESH IMPLEMENTATION AND OUTPUT ROOTS
──────────────────────────────────────────────────────────────────────────────

Allocate a private implementation/qualification root beneath `/private/tmp`
using:

- tempfile.mkdtemp;
- umask 077;
- prefix:

ES-repair10i-v3-gen2-clean-independent-audit-harness-build-

Immediately emit:

HARNESS_BUILD_ROOT=<absolute-path>

Allocate a separate private output directory beneath `/Users/ds/Downloads`
using:

- tempfile.mkdtemp;
- umask 077;
- prefix:

ES-repair10i-v3-gen2-clean-independent-audit-harness-output-

Immediately emit:

HARNESS_OUTPUT_ROOT=<absolute-path>

The build root is temporary and must be removed after evidence retention.

The output directory is nonauthoritative.

The only successful final authority-bearing files are:

gen2-clean-source-external-independent-audit-harness-v1.pyz

gen2-clean-source-external-independent-audit-harness-v1.authority.json

Before opening the bundle retain:

opening/bootstrap-start.json
opening/clean-harness-source-authority-v1.json
opening/fixed-input-file-registry-v1.json
opening/process-execution-policy-v1.json
opening/historical-source-prohibition-v1.json

Bind:

- exact input identities;
- clean source initially absent:
  true;
- source-attempt maximum:
  3;
- implementation package mutation:
  impossible from this task;
- implementation production execution:
  forbidden;
- real full audit:
  forbidden in this task;
- current-subject construction:
  forbidden;
- product/runtime/target/repository/publication/deployment/A6:
  forbidden;
- same-root retry:
  false.

──────────────────────────────────────────────────────────────────────────────
3. FIXED-INPUT AUTHENTICATION
──────────────────────────────────────────────────────────────────────────────

Authenticate authority JSON first.

Require:

- strict UTF-8 JSON;
- duplicate-key rejection;
- exact schema;
- exact archive absolute path;
- exact archive device/inode/mode/link/size/SHA-256;
- role count:
  8;
- content-snapshot role count:
  7;
- bounded failure-evidence role count:
  1;
- archive member count:
  479;
- `.DS_Store` archive-member count:
  0;
- deterministic Build-A and Build-B equality:
  true;
- independent validation:
  passed;
- supplied-root mutation:
  false;
- implementation verdict:
  not issued;
- package verdict:
  not issued.

Authenticate the ZIP:

- exact size and SHA-256;
- `ZIP_STORED` only;
- no duplicate member;
- no unsafe member name;
- no absolute member;
- no `..`;
- no directory member;
- no symlink or special member;
- no `.DS_Store`;
- raw UTF-8 byte-sorted member names;
- fixed 1980 timestamp;
- fixed create system;
- fixed mode semantics;
- no archive comment;
- no member comment;
- no uncontrolled extra fields.

Authenticate:

bundle/index.json
bundle/build-provenance.json
bundle/contamination-ledger.json
bundle/directory-divergence-ledger.json
bundle/role-registry.json

Index model:

- archive member count:
  479;
- ordinary indexed rows:
  478;
- index declares its own member path;
- exact index-member size and SHA-256 are externally bound by the authority
  JSON;
- no self-hash is required inside the index;
- no member outside the declared index/self model is permitted.

Require exact index/member-set closure.

Retain:

opening/current-authority-bundle-authentication-v1.json

Any mismatch is:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
4. CURRENT ROLE RESOLUTION
──────────────────────────────────────────────────────────────────────────────

Resolve exactly eight roles through:

bundle/role-registry.json
bundle/index.json

Required roles:

1. terminal-findings-reconciliation
2. gen2-implementation-package
3. gen2-successor-contract-package
4. normative-contract-package
5. current-schema-package
6. schema-reconciliation-capsule
7. current-validation-specification-package
8. attempt-2-failure-evidence

Required classes:

- seven:
  MANIFEST_AUTHENTICATED_CONTENT_SNAPSHOT
- one:
  BOUNDED_FAILURE_EVIDENCE_SUBSET

For every role require:

- unique role ID;
- exact root-authority member;
- exact closure-evidence members where applicable;
- exact copied-file member registry;
- no unknown role;
- no duplicate role;
- no missing role;
- no directory-member dependency;
- no live-root dependency.

Resolve original files only through:

role
+
original relative path
+
index row

Do not select archive members by:

- basename;
- first match;
- suffix;
- recursive search;
- same-size list;
- score;
- recency;
- inferred path.

Retain:

opening/current-authority-role-resolution-v1.json

──────────────────────────────────────────────────────────────────────────────
5. CLEAN-ROOM SOURCE AUTHORITY
──────────────────────────────────────────────────────────────────────────────

Before source creation retain:

opening/clean-room-harness-source-authority-v1.json

Permitted source inputs:

- normative construction-parent contract member;
- current schema members;
- schema-reconciliation documentary records;
- current validation-specification documentary records;
- terminal findings-reconciliation findings and mandatory treatment;
- bundle authority model and role records;
- this task’s frozen pre-source contracts.

Historical source prohibition:

No Python or executable source member from the bundle may be copied, patched,
translated, transformed, imported, executed, or used as a source template or
AST/bytecode origin for the harness.

Implementation source members may be:

- byte-authenticated;
- parsed read-only during compatibility qualification;
- inspected in the later full audit.

They may not supply harness implementation source.

No historical harness/verifier source exists as a permitted fixed input.

Require:

- authored-from-contract source only;
- no source-text similarity mechanism;
- no copy/paste from bundle source;
- no dynamic code generation from subject source;
- no source member executed.

──────────────────────────────────────────────────────────────────────────────
6. HARNESS AUTHORITY AND NONAUTHORITY
──────────────────────────────────────────────────────────────────────────────

Before source creation retain:

contract/clean-independent-audit-harness-authority-v1.json
contract/clean-independent-audit-harness-operating-model-v1.json

Authority in future `run-full-audit` mode:

- authenticate the exact bundle and authority JSON;
- resolve current roles;
- read implementation and evidence members;
- create one fresh audit root;
- run audit-owned static and behavioral qualification;
- retain complete process custody;
- issue one implementation-package verdict:
  ACCEPT, BLOCK, or AUDIT_PROVENANCE_MISMATCH;
- retain findings and dependencies;
- clean audit-owned fixtures;
- terminally close the audit capsule.

Nonauthority:

- implementation repair;
- contract repair;
- schema repair;
- source-package mutation;
- current-subject construction;
- product/runtime invocation;
- repository mutation;
- publication/deployment;
- A6.

Process model:

- finite one-shot parent;
- no stdin;
- no persistent supervisor;
- no administrative continuation;
- one recorder;
- complete streams;
- exact exit/signal;
- reaping;
- descriptor closure;
- fixed and dynamic effect attribution;
- evidence before cleanup;
- exact cleanup-set equality;
- same-root retry forbidden.

──────────────────────────────────────────────────────────────────────────────
7. HARNESS MODES AND FUTURE INVOCATION
──────────────────────────────────────────────────────────────────────────────

The final executable `.pyz` must support exactly:

--mode qualify-harness

--mode run-full-audit

No default mode.

`qualify-harness` is permitted in this task.

`run-full-audit` is forbidden in this task.

Freeze the exact future invocation:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
-I
-S
-B
<FINAL_HARNESS_PYZ>
--mode
run-full-audit
--bundle
/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip
--bundle-authority
/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Future execution environment:

PATH=/usr/bin:/bin
LANG=C
LC_ALL=C
PYTHONDONTWRITEBYTECODE=1
PYTHONHASHSEED=0

No inherited environment.
stdin = DEVNULL.
shell = false.

Future stdout contract:

- exactly one audit-root locator:
  `AUDIT_ROOT=<absolute-path>\n`
- exactly one terminal JSON record or explicitly defined terminal report
  framing;
- no progress chatter.

Future stderr:

- empty for a handled terminal result.

Freeze:

contract/future-full-audit-invocation-v1.json

──────────────────────────────────────────────────────────────────────────────
8. DEFECT-PREVENTION REGISTRY
──────────────────────────────────────────────────────────────────────────────

Before source creation retain:

contract/clean-harness-defect-prevention-registry-v1.json

Freeze these surfaces.

B00 — Bundle authority and member closure

- authority JSON;
- ZIP grammar;
- index self-member model;
- role resolution;
- member safety;
- exact source-member identity;
- no live-root access.

D01 — Attempt/status semantics

Use exact fields and governing pointers.
No status-text scoring or recursive arbitrary selection.

D02 — Transitive freeze binding

Validate:

freeze
→ source registry
→ source identities
→ producer rehearsal bindings
→ frozen requalification

Do not invent redundant direct-copy requirements.

D03 — Role-layout/source-registry join

Support multiple roles per source file.
Do not compare role-row count with source-file-row count.

D04 — Path-sensitive G01 adjudication

Distinguish:

- helper presence;
- success-path reachability;
- phase ownership;
- create versus verify;
- success versus failure path.

D05 — Confirmation and terminal-marker semantics

Support:

- 125-domain implementation confirmations;
- 66-domain constructed-subject confirmations;
- preterminal rows;
- terminal resolution;
- hard-coded success;
- absence-as-success;
- nullable blocker;
- verdict separate from confirmations.

D06 — Lane-specific validation adapters

One explicit adapter per lane.
No same-length or recursive list discovery.

D07 — Typed 766/333 field-map model

Normative facts and generated enforcement rows are distinct.

D08 — Constructed-subject domain

Use the 66-confirmation subject domain and subject-owned manifest grammar.

D09 — Physical normalization

Normalize through typed dependency propagation, not filename heuristics.

D10 — Causal findings

Only direct implementation observations may become package defects.
Audit defects and derivative failures remain separate.

D11 — Canonical cleanup-result semantics

One typed cleanup result.
`cleanup_rows` owns cleanup evidence.
Root sets are deterministic projections.
No `cleanup_roots` alias.

D12 — Interface metadata policy separation

Separate:

- field_alias_policy;
- path_rendering_policy;
- normalization_policy.

A path-rendering policy is not a field alias.

D13 — Report-section registry

Ordered exact section registry.
Count derived only from `len(section_registry)`.
No independent section-count literal.

D14 — Confirmation-name registry

Exact name set.
Count derived from the set.
No appended verdict token.
Primary verdict in a separate record.

Each surface must bind:

- governing bundle member;
- typed contract;
- production owner;
- qualification owner;
- independent-validator owner;
- direct tests;
- historical regression data.

──────────────────────────────────────────────────────────────────────────────
9. FULL-AUDIT PHASE PLAN
──────────────────────────────────────────────────────────────────────────────

Before source creation freeze one explicit phase plan.

At minimum:

P00 — runtime and frozen-source self-authentication
P01 — bundle and authority authentication
P02 — role/index/member closure
P03 — governing contract/schema/validation authentication
P04 — implementation registry, attempt, freeze, and source closure
P05 — production authority and static security
P06 — E00/G00–G29 implementation crosswalk
P07 — documentary lifecycle and writer ownership
P08 — matrix registries and producer results
P09 — 946-case negative evidence
P10 — 137-case contradiction evidence
P11 — 766/333 field-map evidence
P12 — producer rehearsal A/B evidence
P13 — Attempt-2 failure specimen
P14 — implementation confirmation evidence
P15 — constructed-subject evidence domain
P16 — process/failure custody
P17 — fresh audit-owned behavioral causals
P18 — fresh source-external validation
P19 — security and authority closure
P20 — findings, dependency graph, and verdict
P21 — cleanup
P22 — bundle closing equality
P23 — preseal
P24 — terminal capsule closure

Every phase must freeze:

- prerequisites;
- operands;
- outputs;
- authority contribution;
- pass rule;
- failure rule;
- whether evidence collection may continue;
- cleanup obligations.

No phase may treat “terminal” as “passed.”

Retain:

contract/full-independent-audit-phase-plan-v1.json

──────────────────────────────────────────────────────────────────────────────
10. REPORT AND CONFIRMATION CONTRACTS
──────────────────────────────────────────────────────────────────────────────

Before source creation retain:

contract/full-audit-report-section-registry-v1.json
contract/full-audit-confirmation-name-registry-v1.json
contract/full-audit-report-contract-v1.json
contract/full-audit-confirmation-contract-v1.json

Report requirements:

- ordered unique section IDs;
- exact applicability by verdict;
- section count derived from the registry;
- package findings;
- audit findings;
- derivative failures;
- mixed findings;
- unresolved findings;
- evidence/provenance findings;
- no prose as authority.

Confirmation requirements:

- exact unique name set;
- count derived from names;
- evidence pointer per confirmation;
- no hard-coded success;
- no absence-as-success;
- terminal confirmations resolved only from terminal evidence;
- primary verdict not included as a confirmation.

Run an independent pre-source documentary validator.

No source creation until it passes.

──────────────────────────────────────────────────────────────────────────────
11. SOURCE ARCHITECTURE
──────────────────────────────────────────────────────────────────────────────

Define clean modular roles for:

- executable ZIP entrypoint;
- finite audit parent;
- child recorder;
- strict JSON parser;
- total JSON observer;
- ZIP authority reader;
- bundle index resolver;
- role resolver;
- safe member reader/materializer;
- grammar registry;
- attempt/status adapter;
- freeze validator;
- role/source joiner;
- path-sensitive phase analyzer;
- qualification-independence analyzer;
- confirmation adjudicator;
- lane adapters;
- field-map adjudicator;
- subject-domain validator;
- physical normalizer;
- cleanup-result owner;
- process/failure custody;
- security and authority analysis;
- causal findings reconciliation;
- dependency-graph builder;
- report projector;
- audit-capsule lifecycle;
- failure closeout;
- platform-capture adapter;
- qualification-only fixture drivers;
- independent validators.

Production audit logic may not import qualification fixtures.

Independent validators may not import production or qualification modules,
expected maps, mutation generators, production observers, normalizers, or
projectors.

Retain planned and final source registries.

──────────────────────────────────────────────────────────────────────────────
12. SOURCE-ATTEMPT LIMIT
──────────────────────────────────────────────────────────────────────────────

At most three complete clean-source attempts.

An attempt begins only when:

- final production registry closes;
- final qualification registry closes;
- final independent registry closes;
- compilation begins.

Any source modification after compilation begins creates a new attempt.

For every attempt retain:

- source identities;
- clean-room provenance;
- compilation;
- static/interface gates;
- matrices reached;
- synthetic lanes;
- rehearsals reached;
- first blocker;
- supersession.

If Attempt 3 fails, stop.

Do not create Attempt 4.

──────────────────────────────────────────────────────────────────────────────
13. PRECOMPILATION AND STATIC SOURCE GATES
──────────────────────────────────────────────────────────────────────────────

Before compilation require:

- every source parses;
- every architecture role is occupied;
- every cross-module interface is registered;
- provider/consumer shapes conform;
- report implementation matches report registry;
- confirmation implementation matches confirmation registry;
- no historical source origin;
- no Git/VCS mechanism;
- no implementation production execution.

Then compile every source under pinned Python `-I -S -B`.

Require exit zero and empty stderr.

Run source-external:

- AST;
- call graph;
- dataflow;
- bytecode;
- exception tables;
- CFG;
- bundle-member-access crosswalk;
- provider/consumer shape analysis;
- report-section analysis;
- confirmation-name analysis;
- process-launch crosswalk;
- filesystem-operation crosswalk;
- terminal-operation crosswalk;
- forbidden executable/library/path analysis.

Require:

- finite flow;
- no stdin;
- no persistent supervisor;
- all children through one recorder;
- no network;
- no Git/VCS;
- no shell or PATH lookup;
- no broad filesystem scan;
- no original-root access;
- no unsafe ZIP extraction;
- no unregistered interface;
- no field-alias/path-policy conflation;
- no report-count drift;
- no extra confirmation;
- no postseal operation;
- success and failure closeout reachable.

──────────────────────────────────────────────────────────────────────────────
14. B00 AND D01–D14 MATRICES
──────────────────────────────────────────────────────────────────────────────

Run uniquely named, closed matrices.

Minimum counts:

- B00 bundle authority/member closure:
  70;
- D01 attempt/status:
  30;
- D02 freeze binding:
  25;
- D03 role/source join:
  30;
- D04 G01 reachability:
  30;
- D05 confirmation semantics:
  35;
- D06 lane adapters:
  at least 100;
- D07 field map:
  30;
- D08 constructed-subject domain:
  40;
- D09 physical normalization:
  40;
- D10 causal findings:
  30;
- D11 cleanup result:
  50;
- D12 interface metadata:
  35;
- D13 report registry:
  25;
- D14 confirmation registry:
  25.

B00 must cover:

- authority JSON exact baseline;
- wrong archive path;
- wrong size/hash;
- wrong member count;
- wrong role count;
- ZIP compression;
- duplicate member;
- unsafe member name;
- missing index;
- index/member mismatch;
- index self-member mismatch;
- wrong self-member identity;
- missing role;
- duplicate role;
- unknown role;
- `.DS_Store` member;
- directory member;
- symlink/special member;
- wrong member bytes;
- wrong member role ownership;
- bounded failure subset falsely treated as complete.

D11 must reject `cleanup_roots` aliasing.

D12 must distinguish field alias, path rendering, and normalization.

D13 must reject section-count drift.

D14 must reject an appended verdict confirmation.

Require across every matrix:

- unique names;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

──────────────────────────────────────────────────────────────────────────────
15. PROCESS-CUSTODY QUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Exercise:

- nonexistent executable;
- zero/empty streams;
- nonzero/both streams;
- timeout/kill/reap;
- one child;
- multiple children;
- empty ledger;
- lost stdout;
- lost stderr;
- unregistered dynamic effect;
- zero/one/multiple-root cleanup;
- evidence before cleanup;
- platform separate-stream/exit capture.

Require complete custody, effect attribution, cleanup equality, double ENOENT,
and zero survivors.

──────────────────────────────────────────────────────────────────────────────
16. SYNTHETIC END-TO-END AUDIT LANES
──────────────────────────────────────────────────────────────────────────────

Create source-independent synthetic authority bundles.

Run:

A. exact implementation ACCEPT;
B. substantive implementation BLOCK;
C. audit provenance mismatch;
D. two physically distinct semantically equal constructed subjects;
E. wrong registry and same-length alternative matrix corpora;
F. incomplete bounded failure-evidence subset;
G. terminal marker and confirmation mutation cases.

Require exact:

- verdict;
- findings;
- finding ownership;
- dependency graph;
- phase results;
- process custody;
- cleanup;
- report sections;
- confirmation set;
- audit-capsule terminal closure;
- no postseal operation.

──────────────────────────────────────────────────────────────────────────────
17. BOUNDED REAL-BUNDLE COMPATIBILITY REPLAY
──────────────────────────────────────────────────────────────────────────────

Against the exact current bundle, without executing implementation source and
without issuing a package verdict:

- authenticate bundle and authority;
- resolve all eight roles;
- resolve implementation Attempts 1–3;
- validate source freeze and frozen requalification;
- resolve 24 production and nine qualification roles;
- path-sensitively adjudicate G01;
- audit the 125 implementation confirmations;
- parse all ten matrix lanes;
- parse 946 negative cases;
- parse 137 contradiction cases;
- parse the 766/333 field map;
- parse producer rehearsal A/B under the subject grammar;
- normalize producer rehearsals to zero unexplained differences;
- authenticate Attempt-2 bounded failure evidence;
- derive the exact future full-audit invocation;
- emit no implementation/package verdict.

Retain:

validation/current-bundle-bounded-compatibility-replay-v1.json

──────────────────────────────────────────────────────────────────────────────
18. TWO COMPLETE HARNESS REHEARSALS
──────────────────────────────────────────────────────────────────────────────

Build provisional executable `.pyz` artifacts from identical candidate source
bytes.

Run two physically distinct complete harness rehearsals against independent
synthetic authority bundles.

Each rehearsal must complete:

- B00;
- D01–D14;
- process custody;
- synthetic ACCEPT;
- synthetic BLOCK;
- synthetic provenance failure;
- synthetic subject comparison;
- bounded real-bundle compatibility replay;
- report generation;
- confirmation generation;
- audit-capsule closure;
- cleanup.

Retain before cleanup:

- exact provisional `.pyz` identity;
- synthetic input-bundle identities;
- process records and streams;
- audit-root identity;
- complete audit-capsule inventory;
- all result identities;
- terminal identities;
- cleanup records.

Require both rehearsals to use byte-identical provisional `.pyz` files.

Normalize only explicit physical values in output capsules.

Require zero unexplained semantic difference.

Remove rehearsal fixtures and capsules only after evidence retention and
observe ENOENT twice.

──────────────────────────────────────────────────────────────────────────────
19. INDEPENDENT HARNESS VALIDATORS
──────────────────────────────────────────────────────────────────────────────

Independent validators may not import candidate production or qualification
modules, generators, expected maps, observers, normalizers, or report
projectors.

They must independently verify:

- clean-room provenance;
- bundle/authority authentication;
- role resolution;
- phase plan;
- B00 and D01–D14 matrices;
- cross-module interfaces;
- report registry/count;
- confirmation registry/count/verdict separation;
- process custody;
- synthetic verdict lanes;
- compatibility replay;
- both rehearsals;
- normalized comparison;
- evidence retention;
- cleanup;
- source freeze linkage;
- final `.pyz` member closure;
- final authority JSON.

Require zero errors.

──────────────────────────────────────────────────────────────────────────────
20. SOURCE FREEZE
──────────────────────────────────────────────────────────────────────────────

Freeze source only after:

- pre-source contracts pass;
- compilation/static gates pass;
- B00 and D01–D14 pass;
- process custody passes;
- synthetic lanes pass;
- compatibility replay passes;
- both rehearsals pass;
- normalized comparison passes;
- independent validators pass;
- evidence retention and cleanup pass;
- input files remain unchanged.

Retain:

opening/clean-independent-audit-harness-source-freeze-v1.json

Bind:

- final production registry;
- final qualification registry;
- final independent registry;
- exact source identities;
- all contracts;
- all matrices;
- rehearsals;
- compatibility replay;
- cleanup;
- future invocation;
- input bundle identities;
- full real audit not executed;
- later source modification:
  forbidden.

Reopen all source no-follow.

Do not modify source afterward.

──────────────────────────────────────────────────────────────────────────────
21. DETERMINISTIC EXECUTABLE PYZ PACKAGE
──────────────────────────────────────────────────────────────────────────────

Create a deterministic executable ZIP application.

Final name:

gen2-clean-source-external-independent-audit-harness-v1.pyz

Required members include:

- `__main__.py`;
- frozen production modules;
- frozen runtime contracts;
- frozen report/confirmation registries;
- bundle/input contract;
- phase plan;
- source registries;
- source-freeze record;
- qualification evidence required for future authentication;
- operative report;
- package status.

Do not include:

- source-attempt failures not required for lineage;
- disposable fixture bytes;
- synthetic package payloads;
- caches or bytecode;
- absolute filesystem objects;
- `.DS_Store`;
- directory ZIP members.

ZIP requirements:

- `ZIP_STORED`;
- member names sorted by raw UTF-8 bytes;
- fixed timestamp:
  1980-01-01T00:00:00;
- `create_system = 3`;
- fixed member permissions:
  `0600`;
- no duplicate names;
- no comments;
- no uncontrolled extra fields;
- no unsafe member names;
- no symlink/special attributes.

Build final PYZ independently twice:

- PYZ Build A;
- PYZ Build B.

Require exact byte equality.

──────────────────────────────────────────────────────────────────────────────
22. FINAL HARNESS AUTHORITY JSON
──────────────────────────────────────────────────────────────────────────────

Final name:

gen2-clean-source-external-independent-audit-harness-v1.authority.json

It must bind:

- harness ID and version;
- exact `.pyz` absolute path;
- `.pyz` device/inode/mode/link/size/SHA-256;
- `.pyz` member count;
- `__main__.py` identity;
- final source registries;
- source-freeze identity;
- frozen-requalification identity;
- qualification result identities;
- rehearsal identities;
- future invocation;
- current input bundle path and identity;
- current input authority-JSON path and identity;
- modes:
  qualify-harness and run-full-audit;
- full real audit executed:
  false;
- implementation verdict:
  not issued;
- current subject constructed:
  false.

Set both final files to mode `0400` after final validation.

The containing output directory is nonauthoritative.

──────────────────────────────────────────────────────────────────────────────
23. FROZEN-PYZ REQUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Using exact final PYZ Build-A/B bytes after equality:

Run:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
-I
-S
-B
<FINAL_PYZ>
--mode
qualify-harness
--bundle
<CURRENT_AUTHORITY_BUNDLE>
--bundle-authority
<CURRENT_AUTHORITY_JSON>

Require:

- exit zero;
- empty stderr;
- exact guarded qualification result;
- bundle authentication;
- source/member self-authentication;
- compilation/static equivalence;
- B00 and D01–D14 result identity linkage;
- process-custody linkage;
- synthetic-lane linkage;
- compatibility-replay linkage;
- rehearsal-source linkage;
- independent-validator linkage;
- final member closure;
- no `run-full-audit` execution;
- no implementation verdict.

Do not rerun complete rehearsals.

Retain:

validation/frozen-pyz-requalification-v1.json

──────────────────────────────────────────────────────────────────────────────
24. INPUT-FILE CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat exact no-follow identity checks for:

- current authority bundle;
- current authority JSON.

Require exact device/inode/mode/link/size/SHA-256 equality with opening.

Do not open the original contaminated roots.

──────────────────────────────────────────────────────────────────────────────
25. BUILD AND FIXTURE CLEANUP
──────────────────────────────────────────────────────────────────────────────

Before removing any build or rehearsal root retain:

- identity;
- complete inventory;
- process streams;
- validation results;
- failure outcome where applicable.

Then revalidate identity, remove the exact root, and observe ENOENT twice.

Require:

created
=
inventoried
=
evidence-retained
=
cleanup rows
=
twice absent

Do not remove the final output directory or final `.pyz`/authority files on
success.

──────────────────────────────────────────────────────────────────────────────
26. FAILURE CLOSEOUT
──────────────────────────────────────────────────────────────────────────────

On failure retain:

- source attempt or pre-attempt posture;
- first blocker;
- structured exception;
- process ledger and streams;
- partial build inventory;
- indispensable evidence;
- cleanup;
- input-file closing equality;
- source-freeze posture;
- final-package posture;
- same-root retry false.

Do not create authoritative final outputs on failure.

If provisional `.pyz` or authority files exist:

- retain identities;
- classify nonauthoritative;
- remove after evidence retention;
- observe ENOENT twice.

Return provenance mismatch for:

- input bundle/authority mismatch;
- unsafe or inconsistent archive;
- source-provenance violation;
- historical source use;
- Git/VCS use;
- unregistered process/filesystem effect;
- indispensable evidence loss;
- cleanup inequality;
- input-file closing inequality;
- source drift after freeze;
- final `.pyz`/authority mismatch;
- post-finalization mutation.

──────────────────────────────────────────────────────────────────────────────
27. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_PYZ_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_FRESH_AUDIT

only when:

- input bundle and authority authenticate;
- role/index/member closure passes;
- clean-room source authority passes;
- pre-source contracts pass;
- phase plan closes;
- source qualifies within three attempts;
- compilation/static gates pass;
- B00 and D01–D14 pass;
- process custody passes;
- synthetic audit lanes pass;
- compatibility replay passes without a verdict;
- both complete rehearsals pass;
- rehearsal comparison passes;
- independent validators pass;
- evidence retention and cleanup pass;
- source freezes;
- deterministic PYZ Build A/B match;
- final authority JSON binds the PYZ;
- frozen-PYZ requalification passes;
- input files close equal;
- final files are mode `0400`;
- full real audit remains unexecuted;
- no implementation verdict is issued.

Return:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_IMPLEMENTATION_BLOCKED

when:

- governing semantics remain unresolved;
- source cannot qualify within three attempts;
- a matrix, synthetic lane, rehearsal, validator, or requalification fails
  without a provenance failure;
- implementation would require modifying the current bundle or its governing
  semantics.

Return:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_PROVENANCE_MISMATCH

for the provenance failures defined in Section 26.

──────────────────────────────────────────────────────────────────────────────
28. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return the exact ordered report-section registry frozen before source.

At minimum include:

1. Primary verdict
2. Fresh build-root identity
3. Fresh output-root identity
4. Exact input-bundle identity
5. Exact input-authority identity
6. Bundle/authority authentication
7. Bundle index/member closure
8. Current role resolution
9. Clean-room source authority
10. Harness authority and nonauthority
11. Mode and future-invocation contract
12. Defect-prevention registry
13. Full-audit phase plan
14. Report contract
15. Confirmation contract
16. Source architecture
17. Source-attempt ledger
18. Final production-source registry
19. Final qualification-source registry
20. Final independent-source registry
21. Cross-module interface registry
22. Precompilation gate
23. Compilation/static gates
24. B00 bundle matrix
25–38. D01–D14 matrix results
39. Process-custody qualification
40. Synthetic ACCEPT lane
41. Synthetic BLOCK lane
42. Synthetic provenance-failure lane
43. Synthetic subject-pair lane
44. Bounded real-bundle compatibility replay
45. Harness rehearsal A
46. Harness rehearsal B
47. Rehearsal normalized comparison
48. Independent validators
49. Evidence retention
50. Build/rehearsal cleanup
51. Source freeze
52. PYZ Build A
53. PYZ Build B
54. PYZ Build-A/B equality
55. Final PYZ member closure
56. Final authority-JSON identity
57. Frozen-PYZ requalification
58. Confirmation full real audit was not executed
59. Confirmation implementation verdict was not issued
60. Harness-package status
61. Input-file closing equality
62. Failure-closeout capability and use
63. Final PYZ path and identity
64. Final authority-JSON path and identity
65. Remaining uncertainty and nonclaims
66. Explicit confirmation registry

The actual section count must be derived from the frozen registry.

Freeze the exact confirmation-name set before source.

The confirmation artifact must contain exactly that set and no verdict token.

Required confirmations include:

CURRENT_AUTHORITY_BUNDLE_IDENTITY_MATCHED
CURRENT_AUTHORITY_JSON_IDENTITY_MATCHED
BUNDLE_AUTHORITY_JSON_STRICTLY_VALIDATED
BUNDLE_ZIP_GRAMMAR_VALIDATED
BUNDLE_INDEX_MEMBER_MODEL_VALIDATED
BUNDLE_MEMBER_SET_CLOSED
EXACTLY_EIGHT_CURRENT_ROLES_RESOLVED
SEVEN_CONTENT_SNAPSHOT_ROLES_RESOLVED
ONE_BOUNDED_FAILURE_EVIDENCE_ROLE_RESOLVED
NO_LIVE_ROOT_ACCESSED
NO_HISTORICAL_HARNESS_SOURCE_USED
NO_IMPLEMENTATION_SOURCE_USED_AS_HARNESS_SOURCE
CLEAN_ROOM_SOURCE_AUTHORITY_ESTABLISHED
HARNESS_AUTHORITY_SCOPE_CLOSED
HARNESS_NONAUTHORITY_SCOPE_CLOSED
QUALIFY_HARNESS_MODE_IMPLEMENTED
RUN_FULL_AUDIT_MODE_IMPLEMENTED
RUN_FULL_AUDIT_MODE_NOT_EXECUTED
FUTURE_FULL_AUDIT_INVOCATION_FROZEN
DEFECT_PREVENTION_REGISTRY_COMPLETE
FULL_AUDIT_PHASE_PLAN_COMPLETE
REPORT_SECTION_REGISTRY_FROZEN
REPORT_SECTION_COUNT_DERIVED
CONFIRMATION_NAME_REGISTRY_FROZEN
CONFIRMATION_COUNT_DERIVED
PRIMARY_VERDICT_SEPARATE_FROM_CONFIRMATIONS
SOURCE_ARCHITECTURE_COMPLETE
SOURCE_ATTEMPT_LIMIT_RESPECTED
FINAL_SOURCE_REGISTRIES_COMPLETE
INDEPENDENT_VALIDATORS_IMPORT_NO_PRODUCTION_HELPERS
ALL_SOURCES_COMPILED
STATIC_SOURCE_GATES_PASSED
BUNDLE_AUTHORITY_MATRIX_PASSED
D01_D14_MATRICES_PASSED
PROCESS_CUSTODY_QUALIFICATION_PASSED
SYNTHETIC_ACCEPTED_PACKAGE_AUDIT_PASSED
SYNTHETIC_BLOCK_PACKAGE_AUDIT_PASSED
SYNTHETIC_PROVENANCE_FAILURE_AUDIT_PASSED
SYNTHETIC_CONSTRUCTED_SUBJECT_PAIR_PASSED
BOUNDED_COMPATIBILITY_REPLAY_PASSED
BOUNDED_COMPATIBILITY_REPLAY_EMITTED_NO_PACKAGE_VERDICT
COMPLETE_HARNESS_REHEARSAL_A_PASSED
COMPLETE_HARNESS_REHEARSAL_B_PASSED
TWO_HARNESS_REHEARSALS_NORMALIZED_EQUAL
INDEPENDENT_HARNESS_VALIDATORS_PASSED
EVIDENCE_RETAINED_BEFORE_CLEANUP
HARNESS_OWNED_CLEANUP_SET_EQUALITY_PASSED
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
HARNESS_SOURCE_FROZEN
HARNESS_SOURCE_NOT_MODIFIED_AFTER_FREEZE
PYZ_DETERMINISTIC_FORMAT_FROZEN
PYZ_BUILD_A_CREATED
PYZ_BUILD_B_CREATED
PYZ_BUILD_A_B_BYTES_IDENTICAL
FINAL_PYZ_MEMBER_SET_CLOSED
FINAL_AUTHORITY_JSON_BINDS_PYZ
FROZEN_PYZ_REQUALIFICATION_PASSED
FULL_INDEPENDENT_AUDIT_NOT_EXECUTED
IMPLEMENTATION_PACKAGE_NOT_READJUDICATED
IMPLEMENTATION_PRODUCTION_SOURCE_NOT_EXECUTED
CURRENT_SCHEMA_SUBJECT_NOT_CONSTRUCTED
INPUT_BUNDLE_CLOSING_EQUALITY_PASSED
INPUT_AUTHORITY_JSON_CLOSING_EQUALITY_PASSED
FINAL_PYZ_CREATED
FINAL_PYZ_MODE_0400
FINAL_PYZ_IDENTITY_VERIFIED
FINAL_AUTHORITY_JSON_CREATED
FINAL_AUTHORITY_JSON_MODE_0400
FINAL_AUTHORITY_JSON_IDENTITY_VERIFIED
CONTAINING_DIRECTORY_NOT_USED_AS_AUTHORITY
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

After:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_PYZ_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_FRESH_AUDIT

the next tranche is exactly one fresh independent audit of the unchanged
Generation-2 implementation evidence contained in the current-authority bundle,
using:

- the exact final harness PYZ;
- the exact harness authority JSON;
- the exact current-authority bundle ZIP;
- the exact bundle authority JSON.

Do not combine that audit with this harness-implementation task.

Do not construct the authoritative current schema subject until that later
fresh audit accepts the implementation package.
```

### Sources

The Codex report in your message establishes the final bundle and authority-file identities, deterministic build equality, two byte-identical rehearsal archives, independent archive validation, source freeze and requalification, eight-role closure, zero `.DS_Store` archive members, and supplied-root authoritative-member closing equality.

It also explicitly limits the artifact to manifest-authenticated regular-file content, preserves historical directory and closure records, retains Attempt 2 only as a bounded evidence subset, and issues no implementation or package verdict.

**Confidence:** 0.999 that the current-authority snapshot bundle is the correct fixed-input boundary; 0.995 that the live contaminated roots should now be retired from the critical path; 0.98 that a deterministic executable `.pyz` plus authority JSON is the right harness authority format; 0.97 that the next successful tranche should be followed immediately by one fresh audit rather than another authority-reconciliation track.
