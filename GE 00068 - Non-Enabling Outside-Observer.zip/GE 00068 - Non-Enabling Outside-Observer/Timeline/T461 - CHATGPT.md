## Engineering assessment

This is an **ordinary clean-harness implementation blocker**, not a provenance mismatch and not an implementation-package finding.

The corrected reconciliation member authenticated, the terminal findings decision remained intact, the implementation and every governing root closed unchanged, and the clean operating model was frozen before source creation. :chatgpt-content-reference{index="0"}

The clean implementation made substantial progress:

- All three source attempts were used as required.
- Attempt 3 compiled all 21 sources and passed its static gates.
- All ten D01–D10 matrices passed, totaling 390 cases.
- Process custody passed.
- Synthetic ACCEPT, substantive BLOCK, provenance-failure, and constructed-subject-pair lanes passed.
- The bounded compatibility replay passed without issuing a package verdict.
- Both complete harness rehearsals passed and normalized with zero unexplained differences.
- Initial independent validators passed. :chatgpt-content-reference{index="1"}

The sole terminal blocker was a concrete cross-module interface mismatch:

- the rehearsal-cleanup provider returned `cleanup_rows`;
- `combine_cleanup` required `cleanup_roots`;
- the pre-source interface registry omitted this edge;
- source freeze, frozen requalification, and package closure consequently did not occur. :chatgpt-content-reference{index="2"} :chatgpt-content-reference{index="3"}

That is a defect in the new clean harness implementation’s **qualification integration**, not a reason to discard the clean architecture or modify the implementation package. But the prior three-attempt budget is exhausted, so the failed root cannot be resumed or patched.

### Progression decision

Start one fresh **bounded successor-repair tranche** using the exact Attempt-3 clean-room source set as a nonauthoritative repair base.

The repair must do more than rename one field. It must freeze a canonical cleanup-result interface, derive every cleanup set from one typed record, enumerate every acceptance-bearing cross-module edge from the actual call graph, and directly test all provider/consumer paths before compilation can qualify.

Allow at most two repaired-source attempts. If another unregistered acceptance-bearing interface appears, or Attempt 2 fails, retire this clean candidate and return to a new clean implementation generation. Do not issue another localized patch.

```text
FINAL BOUNDED REPAIR OF THE CLEAN SOURCE-EXTERNAL GENERATION-2
INDEPENDENT-AUDIT HARNESS — CLEANUP RESULT AND COMPLETE
CROSS-MODULE INTERFACE CLOSURE

Objective

Create a fresh successor to the blocked clean source-external audit-harness
implementation by repairing the exact cleanup-result provider/consumer mismatch
and closing every acceptance-bearing cross-module interface.

Use the exact clean-room Attempt-3 source set as a bounded,
nonauthoritative repair base.

Do not resume or modify the failed implementation root.

Do not use source from Attempts 1 or 2.

Do not use any source from the retired incremental audit-harness lineage.

Do not execute the fresh full independent audit in this task.

Do not execute the sealed implementation package’s production reconstruction
parent.

Do not construct the authoritative current schema subject.

Do not modify or adjudicate the sealed implementation package.

Do not change:

- the normative construction-parent contract;
- current schemas;
- Generation-2 authority;
- package verdict rules;
- package acceptance thresholds;
- validation case names or expected semantics;
- the 41 current Generation-2 roles;
- the 15 schema roles;
- the 14 generated-record families;
- the 946-case or 137-case registries;
- the 766/333 field-map semantics.

Do not create subagents or direct auditors.
Do not run Git.
Do not use the network.
Do not install dependencies.
Do not invoke product or live-service behavior.
Do not deploy, publish, externally commit, or start A6.

Use one finite parent-owned repair and qualification process in one fresh
private root.

At most two complete repaired-source attempts are permitted.

Return the complete operative report inline. Artifact paths may supplement but
must not replace material identities, causal findings, source deltas,
interfaces, process custody, validation results, and disposition.

Return exactly one primary verdict:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_CLEAN_AUDIT_HARNESS_INTERFACE_REPAIRED_QUALIFIED_FROZEN_READY_FOR_FRESH_AUDIT

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_CLEAN_AUDIT_HARNESS_INTERFACE_REPAIR_BLOCKED

CLEAN_AUDIT_HARNESS_REPAIR_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. BLOCKED CLEAN-HARNESS ROOT
──────────────────────────────────────────────────────────────────────────────

BLOCKED_CLEAN_HARNESS_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-source-external-independent-audit-harness-5cmvznq8

Expected identity:

- device:
  16777234
- inode:
  181151302
- mode:
  0700
- verdict:
  SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_CLEAN_SOURCE_EXTERNAL_AUDIT_HARNESS_IMPLEMENTATION_BLOCKED
- harness authority:
  false
- source freeze:
  false
- terminal seal:
  false
- same-root retry:
  false

Expected failure-closeout identity:

- inode:
  181185194
- mode:
  0600
- size:
  6142
- SHA-256:
  73d52a8857ccc850f3e8c652bb6daf94e8c28a7f6dba9f27471aeebc8376d7a8

Expected failure partial inventory:

- inode:
  181185193
- size:
  139730
- SHA-256:
  1db4c461ec922812661fdf112dc52b6515e8b2669307b91941a2c1c56df7fa6d
- projection SHA-256:
  bdf206d68f9b07f05055bda1565c0dc8760db623cb4b4b9faeaebcea47267c5e
- represented entries:
  420

Expected supplied-root equality record:

- inode:
  181184890
- size:
  6245
- SHA-256:
  c17016c485a38bc15814b73ea426d6da17824bc3fe865c15fe3beed389f1f5f3

Authenticate through retained records:

- corrected reconciliation-member authentication;
- terminal reconciliation authentication;
- clean-room source authority;
- pre-source operating-model freeze;
- D01–D10 registry;
- external-interface registry;
- total JSON-observation contract;
- source architecture;
- source-attempt ledger;
- Attempt-3 source registries;
- static results;
- all D01–D10 matrices;
- process-custody result;
- four synthetic audit lanes;
- bounded compatibility replay;
- rehearsal A;
- rehearsal B;
- normalized rehearsal comparison;
- initial independent validators;
- cleanup;
- supplied-root equality;
- failure closeout.

Classify this root as:

historical_blocked_clean_harness_implementation

It is immutable, noncurrent, nonauthoritative, nonresumable, and not cleanable
in this task.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
2. EXACT ATTEMPT-3 REPAIR-BASE AUTHORITY
──────────────────────────────────────────────────────────────────────────────

Resolve the exact Attempt-3 source paths only through the failed root’s
Attempt-3 artifact and source registries.

Expected production registry:

- inode:
  181183049
- mode:
  0600
- size:
  3275
- SHA-256:
  99577b16994ebc42ace893610863c1ffa7c38d54b831d32bb37153d3617fc30d

Expected qualification registry:

- inode:
  181183050
- mode:
  0600
- size:
  1825
- SHA-256:
  207ea576fa5e3aec1cdf3e5e0314bca34d3da00e39608df1592cc94e5e339232

Expected independent registry:

- inode:
  181183051
- mode:
  0600
- size:
  1074
- SHA-256:
  e76bd6eb21ea47bd4a6d6884faae1c523e9ddb1e51fac3dfcb441b01bd6e9cb3

Expected complete Attempt-3 candidate source-set SHA-256:

d5a03fbefd9717724bc426d300303a090418d1452479d7f511af4a5db1f59fbd

Expected role counts:

- production:
  12 source files;
- qualification:
  6 source files;
- independent:
  3 source files;
- total:
  21 source files;
- architecture roles:
  34.

Authenticate every source path, role, type, mode, link count, size, and
SHA-256 through these registries.

Do not select source by basename, uniqueness, directory convention, recency,
or content.

Do not use Attempt-1 or Attempt-2 source.

Retain:

opening/attempt-3-clean-source-repair-base-v1.json

Classify the Attempt-3 source set as:

clean_room_attempt_3_bounded_repair_base

It is:

- clean-room;
- exact-byte authenticated;
- noncurrent;
- nonauthoritative;
- unfrozen;
- eligible only for the bounded interface repair defined here.

No intermediate Attempt-3 pass result becomes final authority.

──────────────────────────────────────────────────────────────────────────────
3. GOVERNING AUTHORITIES
──────────────────────────────────────────────────────────────────────────────

FINAL_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-gen2-implementation-audit-block-findings-reconciliation-1cinwqpj

Expected identity:

- device/inode:
  16777234 / 181119472
- mode:
  0700
- governing treatment:
  CLEAN_SOURCE_EXTERNAL_AUDIT_HARNESS_REIMPLEMENTATION_THEN_FRESH_AUDIT

AUTHORITATIVE_CONTRACT_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-2y6tkl0n

Expected identity:

- device/inode:
  16777234 / 180472094
- mode:
  0700

Normative contract:

- size:
  32038
- SHA-256:
  874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19

GEN2_SUCCESSOR_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-bootstrap-order-repair-t9kydqve

Expected identity:

- device/inode:
  16777234 / 180871216
- mode:
  0700

SCHEMA_SOURCE_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-repair-pw27ydqf

Expected identity:

- device/inode:
  16777234 / 180513083
- mode:
  0700

SCHEMA_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-construction-parent-schema-reconciliation-5e2lsx8t

Expected identity:

- device/inode:
  16777234 / 180480821
- mode:
  0700

VALIDATION_SPEC_SOURCE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-evidence-repair-lj_8xygs

Expected identity:

- device/inode:
  16777234 / 180576497
- mode:
  0700

IMPLEMENTATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634

Expected identity:

- device/inode:
  16777234 / 180884963
- mode:
  0700

ATTEMPT_2_FAILED_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-hqsolb0v

Expected identity:

- device/inode:
  16777234 / 180892391
- mode:
  0700

Use these roots read-only.

Do not execute the implementation production source.

Require complete opening/closing equality for every supplied root opened.

──────────────────────────────────────────────────────────────────────────────
4. FRESH SUCCESSOR REPAIR ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root under `/Users/ds/Downloads` using:

- tempfile.mkdtemp;
- umask 077;
- prefix:

ES-repair10i-v3-gen2-clean-audit-harness-interface-repair-

Immediately emit:

HARNESS_ROOT=<absolute-path>

Retain before supplied-root inspection:

opening/bootstrap-start.json
opening/clean-harness-interface-repair-authority-v1.json

Bind:

- fresh-root identity;
- allocation method and umask;
- failed clean-harness root identity;
- exact Attempt-3 source authority;
- terminal reconciliation identity;
- bounded repair seam:
  CLEAN_HARNESS_IMPLEMENTATION_INTERFACE_REPAIR;
- implementation package mutation:
  unauthorized;
- full independent audit:
  unauthorized in this task;
- real implementation rehearsals:
  unauthorized;
- current-subject construction:
  unauthorized;
- product/runtime/repository/publication/deployment/A6:
  unauthorized;
- source attempts:
  maximum 2;
- same-root retry:
  false.

Create directories lazily.

No empty directory may remain at successful terminal closure.

──────────────────────────────────────────────────────────────────────────────
5. EXACT BLOCKER REPRODUCTION
──────────────────────────────────────────────────────────────────────────────

Before copying or modifying source, reproduce the exact Attempt-3 blocker.

Required causal chain:

1. The rehearsal-cleanup provider returns or stores:
   `cleanup_rows`.
2. `qualification_parent.py`, at the authenticated call site near prior line
   731, passes that result to `combine_cleanup`.
3. `combine_cleanup`, near prior line 610, requires:
   `cleanup_roots`.
4. The consumer raises:
   `KeyError("cleanup_roots")`.
5. Rehearsal A and B had already passed.
6. Normalized rehearsal comparison had passed.
7. The exception prevents:
   - final independent-validator closure;
   - source freeze;
   - frozen requalification;
   - package terminal closure.

Retain:

analysis/cleanup-interface-mismatch-reproduction-v1.json

Bind:

- provider source/function/range;
- consumer source/function/range;
- call path;
- exact provider object;
- exact consumer expectation;
- exact exception;
- first failed operation;
- source identity;
- rehearsal posture before failure;
- authority effect;
- qualification effect;
- terminal effect.

Required classification:

CLEAN_HARNESS_CROSS_MODULE_CLEANUP_INTERFACE_DEFECT

unless governing contract evidence proves a different owner.

──────────────────────────────────────────────────────────────────────────────
6. CLEANUP-RESULT AUTHORITY ADJUDICATION
──────────────────────────────────────────────────────────────────────────────

Before source modification, retain:

analysis/cleanup-result-authority-adjudication-v1.json

Crosswalk:

- the normative cleanup obligations;
- operating-model cleanup contract;
- process-custody requirements;
- evidence-before-cleanup requirements;
- cleanup-set equality;
- fixture cleanup records;
- rehearsal cleanup records;
- provider output;
- consumer input;
- synthetic cleanup fixtures;
- independent-validator expectations.

Determine one authoritative cleanup-result representation.

The canonical result must represent, with exact types:

- created roots;
- inventoried roots;
- evidence-retained roots;
- cleanup rows;
- twice-absent roots;
- process survivor count;
- descriptor survivor count;
- cache/bytecode survivor count;
- set-equality result;
- overall pass;
- first blocker or null.

One authoritative field must own each fact.

Do not preserve conflicting aliases merely for compatibility.

Do not support both `cleanup_rows` and `cleanup_roots` as independent
acceptance-bearing facts.

When root sets are derived from cleanup rows, identify the rows as evidence and
the derived set as a deterministic projection.

When the governing contract does not establish a field spelling, freeze the
spelling here before source repair and use it everywhere.

Unknown, missing, wrong-type, contradictory, or duplicated cleanup facts fail
closed.

──────────────────────────────────────────────────────────────────────────────
7. CLOSED CLEANUP INTERFACE CONTRACT
──────────────────────────────────────────────────────────────────────────────

Generate:

contract/clean-harness-cleanup-result-interface-v1.json

Bind:

- provider functions;
- aggregator:
  `combine_cleanup`;
- all consumers;
- exact schema;
- exact fields;
- types;
- ordering;
- nullability;
- empty-set semantics;
- one-root semantics;
- multiple-root semantics;
- evidence-before-cleanup semantics;
- double-ENOENT requirement;
- process/descriptor/cache requirements;
- failure behavior;
- authority;
- derived fields;
- unknown-field rule;
- alias rule:
  forbidden;
- fallback rule:
  forbidden.

Require:

- equal empty sets pass;
- integer zero survivor counts pass;
- no generic truthiness;
- no missing-as-empty;
- no field-name fallback;
- no recursive search;
- no source-order dependence;
- no second writer;
- no overwrite or result adoption.

──────────────────────────────────────────────────────────────────────────────
8. COMPLETE CROSS-MODULE INTERFACE INVENTORY
──────────────────────────────────────────────────────────────────────────────

The prior registry declared 30 edges and omitted the cleanup edge.

Generate a new registry from the exact Attempt-3 source set:

contract/clean-harness-cross-module-interface-registry-v2.json

Derive the candidate interface set independently using:

- AST imports;
- direct calls;
- attribute calls with resolved module ownership;
- function return sites;
- constructor calls;
- serialized-record producers and consumers;
- bytecode call targets where static resolution is possible.

For every cross-module interface retain:

- interface ID;
- provider module/function;
- consumer module/function;
- call sites;
- provider return shape;
- consumer-required shape;
- field and pointer vocabulary;
- type and nullability;
- exception contract;
- authority;
- applicable execution lanes;
- direct integration test;
- independent-validator test.

Require exact set equality between:

- derived cross-module interfaces;
- registered interfaces;
- directly tested interfaces;
- independently tested interfaces.

No unregistered acceptance-bearing interface is permitted.

A dynamically unresolved acceptance-bearing interface blocks qualification.

Do not classify interfaces solely by role count or source-file count.

──────────────────────────────────────────────────────────────────────────────
9. PRE-COMPILATION INTERFACE CONFORMANCE
──────────────────────────────────────────────────────────────────────────────

Before a source attempt may begin compilation, run source-external interface
conformance against the candidate registries.

Require:

- every provider return path compatible with each consumer;
- every serialized record compatible with every direct reader;
- no consumer-required field absent from provider shape;
- no conflicting duplicate field;
- no wrong-type path;
- no alias/fallback dependency;
- no interface known only through rehearsal execution.

Retain:

validation/precompilation-cross-module-interface-conformance-v1.json

Compilation is forbidden when this gate fails.

This gate does not consume a source attempt until the repaired source
registries close and compilation begins.

──────────────────────────────────────────────────────────────────────────────
10. BOUNDED SOURCE-REPAIR SURFACE
──────────────────────────────────────────────────────────────────────────────

Retain:

analysis/cleanup-interface-repair-surface-v1.json

Permitted production or qualification changes are limited to:

- the cleanup-result provider;
- `combine_cleanup`;
- their exact callers;
- typed cleanup-result accessors;
- cleanup interface declarations;
- direct cleanup integration tests;
- cross-module interface registry and validators;
- failure reporting required to retain typed cleanup mismatches.

Protected:

- normative package audit semantics;
- D01–D10 semantic adapters;
- package verdict rules;
- case registries and expectations;
- implementation compatibility parsers;
- manifest and temporal grammar semantics;
- root normalizer semantics;
- synthetic verdict semantics;
- process recorder;
- source attempt and freeze semantics;
- terminal lifecycle except as needed to consume the canonical cleanup result.

Every unrelated common function must remain AST-identical.

Any required change outside the frozen surface blocks the task unless it is
pure qualification evidence with no acceptance-semantic effect.

──────────────────────────────────────────────────────────────────────────────
11. SOURCE ATTEMPT LIMIT
──────────────────────────────────────────────────────────────────────────────

At most two complete repaired-source attempts are permitted.

A complete attempt begins when:

- production registry closes;
- qualification registry closes;
- independent registry closes;
- compilation begins.

For each attempt retain:

- predecessor source identities;
- repaired source identities;
- exact textual and AST delta;
- changed functions;
- protected-function identities;
- compilation;
- precompilation interface result;
- static gates;
- matrices reached;
- rehearsal posture;
- first blocker;
- supersession disposition.

Any modification after compilation begins creates a new attempt.

If Attempt 2 fails:

- stop;
- return the blocked verdict;
- retain:
  repair_candidate_retired=true;
  further_localized_repair_authorized=false;
  new_clean_implementation_generation_required=true;
- do not create Attempt 3.

──────────────────────────────────────────────────────────────────────────────
12. CLEANUP INTERFACE MATRIX
──────────────────────────────────────────────────────────────────────────────

Run at least 45 unique cases.

Cover:

- exact zero-root baseline;
- exact one-root baseline;
- exact multiple-root baseline;
- provider uses canonical field;
- historical provider uses `cleanup_rows`;
- historical consumer requires `cleanup_roots`;
- missing canonical field;
- wrong field name;
- both names equal;
- both names conflicting;
- rows wrong type;
- row missing root;
- duplicate root row;
- created/inventoried mismatch;
- inventoried/evidence mismatch;
- evidence/cleanup mismatch;
- cleanup/twice-absent mismatch;
- one ENOENT only;
- process survivor;
- descriptor survivor;
- cache survivor;
- integer zero counts;
- Boolean substituted for integer;
- null blocker on success;
- nonnull blocker on success;
- failure blocker absent;
- unknown acceptance-bearing field;
- missing-as-empty attempt;
- alias attempt;
- fallback attempt;
- recursive-discovery attempt;
- source-order variation;
- deterministic root-set derivation from rows.

Require:

- unique names;
- exact name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

Retain:

validation/cleanup-result-interface-matrix-v1.json

──────────────────────────────────────────────────────────────────────────────
13. CROSS-MODULE INTERFACE MATRIX
──────────────────────────────────────────────────────────────────────────────

For every registered cross-module interface run:

- exact baseline;
- missing required field;
- wrong required type;
- unknown acceptance-bearing field;
- forbidden null;
- provider exception;
- consumer exception;
- stale producer identity;
- wrong consumer identity;
- shape mismatch;
- applicable empty and zero values.

Require direct real-function integration per interface.

Retain:

validation/complete-cross-module-interface-matrix-v1.json

Require:

- every derived interface tested;
- every registered interface tested;
- every interface independently tested;
- zero untested edges;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

──────────────────────────────────────────────────────────────────────────────
14. PRIOR QUALIFICATION REGRESSION
──────────────────────────────────────────────────────────────────────────────

Against the repaired candidate rerun every prior lane:

- D01 attempt/status:
  exact 30 cases;
- D02 freeze binding:
  exact 25 cases;
- D03 role/source join:
  exact 30 cases;
- D04 G01 reachability:
  exact 30 cases;
- D05 confirmation semantics:
  exact 35 cases;
- D06 lane adapters:
  exact 100 cases;
- D07 field map:
  exact 30 cases;
- D08 constructed-subject domain:
  exact 40 cases;
- D09 root normalization:
  exact 40 cases;
- D10 causal report:
  exact 30 cases;
- process custody:
  exact prior 17 cases;
- synthetic acceptance;
- synthetic BLOCK;
- synthetic provenance failure;
- synthetic constructed-subject pair;
- bounded compatibility replay.

Require exact prior case-name and expectation equality.

Across the 390 D01–D10 cases and every retained nonmatrix lane require zero
regression.

Intermediate Attempt-3 results are comparison evidence only.

──────────────────────────────────────────────────────────────────────────────
15. CLEANUP INTEGRATION CAUSALS
──────────────────────────────────────────────────────────────────────────────

Run source-external integration causals using the real repaired functions:

1. rehearsal cleanup with zero roots;
2. rehearsal cleanup with one root;
3. rehearsal cleanup with A and B roots;
4. synthetic fixture cleanup;
5. nonzero child that created a root;
6. timeout child that created a root;
7. root removed before evidence retention;
8. one missing ENOENT;
9. duplicate cleanup row;
10. exact historical Attempt-3 cleanup payload.

For every causal retain:

- provider output;
- consumer input;
- combined result;
- set projections;
- cleanup rows;
- inventory identities;
- process custody;
- double ENOENT;
- result identity.

No hand-built consumer fixture may substitute for the real call chain.

──────────────────────────────────────────────────────────────────────────────
16. TWO COMPLETE QUALIFICATION REHEARSALS
──────────────────────────────────────────────────────────────────────────────

Run two physically distinct complete harness rehearsals using the exact same
repaired source bytes.

Each rehearsal must complete:

- all D01–D10 matrices;
- process custody;
- synthetic accepted package;
- synthetic BLOCK package;
- synthetic provenance failure;
- synthetic constructed-subject comparison;
- bounded compatibility replay;
- cleanup combination;
- report generation;
- capsule terminal closure.

Retain before removal:

- complete root identities;
- process records and streams;
- all result identities;
- complete inventories;
- cleanup provider and consumer records;
- combined cleanup result;
- terminal identities and topology.

Run source-external independent rehearsal validation.

Normalize only explicit physical facts.

Require zero unexplained difference.

Remove exact roots only after evidence retention and observe ENOENT twice.

──────────────────────────────────────────────────────────────────────────────
17. INDEPENDENT INTERFACE VALIDATOR
──────────────────────────────────────────────────────────────────────────────

Implement a source-external validator that imports neither:

- repaired production modules;
- repaired qualification helpers;
- provider/consumer test helpers;
- matrix generators;
- expected-result maps.

It must independently:

- derive the cross-module call-edge set;
- compare it with the interface registry;
- inspect provider and consumer shapes;
- validate the cleanup contract;
- validate every interface matrix result;
- validate prior-lane regressions;
- inspect both rehearsal cleanup paths;
- verify normalized rehearsal equality;
- verify evidence retention and cleanup;
- verify terminal capsule closure.

Require zero errors and no exception.

Retain:

validation/independent-clean-harness-interface-validator-v1.json

A validator that checks only result-summary Booleans is insufficient.

──────────────────────────────────────────────────────────────────────────────
18. STATIC SOURCE QUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Compile every source under pinned Python `-I -S -B`.

Require exit 0 and empty stderr.

Run source-external:

- AST;
- call graph;
- dataflow;
- bytecode;
- exception table;
- CFG;
- provider-return-shape analysis;
- consumer-required-shape analysis;
- serialized-record producer/reader analysis;
- process-launch crosswalk;
- filesystem-operation crosswalk;
- terminal-operation crosswalk.

Require:

- finite control flow;
- no stdin read;
- no persistent supervisor;
- all children through one recorder;
- no network;
- no Git;
- no shell;
- no PATH executable lookup;
- no broad root traversal;
- no historical harness source import;
- no implementation-source execution;
- no unregistered cross-module edge;
- no generic cleanup-field fallback;
- no postseal filesystem operation;
- success and failure closeout reachable.

Static pass is false if interface set equality is false.

──────────────────────────────────────────────────────────────────────────────
19. SOURCE FREEZE
──────────────────────────────────────────────────────────────────────────────

Freeze only after:

- exact blocker reproduction;
- cleanup authority adjudication;
- cleanup contract closure;
- complete interface registry;
- precompilation conformance;
- cleanup matrix;
- interface matrix;
- all prior regressions;
- cleanup integration causals;
- both rehearsals;
- normalized comparison;
- independent validator;
- static gates;
- supplied-root equality;
- evidence retention and cleanup.

Retain:

opening/clean-harness-interface-repair-source-freeze-v1.json

Bind:

- final source registries;
- Attempt-3 predecessor identities;
- exact source delta;
- protected functions;
- cleanup contract;
- interface registry;
- matrices;
- causals;
- rehearsals;
- normalized comparison;
- cleanup;
- full audit not executed;
- later modification permitted:
  false.

Reopen every source no-follow and verify identity.

Do not modify source afterward.

──────────────────────────────────────────────────────────────────────────────
20. FROZEN-SOURCE REQUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Against exact frozen bytes rerun:

- compilation;
- static and interface gates;
- cleanup matrix;
- complete interface matrix;
- all prior D01–D10 regressions;
- process-custody qualification;
- synthetic audit lanes;
- bounded compatibility replay;
- cleanup integration causals;
- independent interface validator;
- source/result identity linkage;
- supplied-root closing equality.

Do not rerun the two complete rehearsals.

Require proof that both passing rehearsals used the exact bytes later frozen.

Retain:

validation/frozen-clean-harness-interface-requalification-v1.json

Any mismatch blocks the task.

──────────────────────────────────────────────────────────────────────────────
21. HARNESS PACKAGE STATUS
──────────────────────────────────────────────────────────────────────────────

Generate preterminal status:

- status:
  clean-source-external-gen2-independent-audit-harness-interface-repaired-qualified-frozen-pending-fresh-audit;
- failed clean implementation:
  historical noncurrent after successor closure;
- Attempt-3 repair base:
  superseded after successor closure;
- implementation package mutated:
  false;
- implementation package adjudicated:
  false;
- full audit executed:
  false;
- harness qualification:
  passed;
- source frozen:
  true;
- fresh full audit required:
  true;
- current-subject construction:
  unauthorized;
- product/runtime/target/repository/publication/deployment/A6:
  not performed or authorized.

Do not claim implementation acceptance or rejection.

──────────────────────────────────────────────────────────────────────────────
22. SUPPLIED-ROOT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete no-follow inventories for every supplied root opened:

- blocked clean-harness root;
- final reconciliation root;
- implementation package;
- successor Generation-2 package;
- authoritative contract;
- schema source;
- schema reconciliation;
- validation specification;
- Attempt-2 failed root;
- any additional supplied root actually opened.

Require exact opening/closing equality.

Do not modify or clean supplied roots.

For every repair-owned fixture root:

- retain complete inventory;
- retain indispensable evidence;
- remove exact root;
- observe ENOENT twice;
- require zero process and descriptor survivors.

──────────────────────────────────────────────────────────────────────────────
23. SUCCESSOR PACKAGE TERMINAL CLOSURE
──────────────────────────────────────────────────────────────────────────────

Before temporal projection:

- finalize all nonclosure output;
- create only final directories actually used;
- ensure `closeout/` and `manifest/` exist;
- retain no empty descendant;
- reserve zero-length A/B;
- retain descriptors;
- freeze directory set;
- prohibit later directory creation.

Then:

1. generate temporal inventory excluding itself and A/B;
2. write into preexisting `closeout/`;
3. independently reproject immediately;
4. require equality;
5. independently generate A/B excluding A/B;
6. require identical bytes;
7. write through retained descriptors;
8. fsync, close, fsync manifest directory;
9. reopen no-follow;
10. verify path/inode/type/mode/link/size/hash;
11. independently reproject final root;
12. require root row exactly once;
13. require no empty descendant;
14. require no symlink or special object;
15. require no multiply linked regular file;
16. require modes 0700/0600;
17. require no cache or bytecode;
18. transition seal once;
19. build report through typed closed interfaces;
20. emit only guarded marker and verdict;
21. exit nonreturningly;
22. perform no filesystem read or write after seal.

──────────────────────────────────────────────────────────────────────────────
24. FAILURE CLOSEOUT
──────────────────────────────────────────────────────────────────────────────

On failure retain:

- exact source attempt;
- first blocker;
- structured exception;
- complete process ledger and streams;
- complete partial inventory;
- indispensable evidence before cleanup;
- fixture cleanup;
- supplied-root equality;
- authority false;
- freeze posture;
- terminal seal false;
- same-root retry false;
- candidate-retirement disposition when attempt budget is exhausted.

Do not create success manifests for a failed package.

Failure to retain indispensable evidence, clean roots, or close supplied roots
equally is:

CLEAN_AUDIT_HARNESS_REPAIR_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
25. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_CLEAN_AUDIT_HARNESS_INTERFACE_REPAIRED_QUALIFIED_FROZEN_READY_FOR_FRESH_AUDIT

only when:

- failed clean root authenticates;
- Attempt-3 source authority closes;
- exact blocker reproduces;
- one canonical cleanup-result contract closes;
- complete cross-module interface set closes;
- repair remains bounded;
- cleanup matrix passes;
- interface matrix passes;
- every prior qualification lane regresses exactly;
- cleanup integration causals pass;
- two complete rehearsals pass;
- normalized comparison passes;
- independent validator passes;
- static gates pass;
- source freezes;
- frozen requalification passes;
- implementation remains unchanged and unadjudicated;
- full audit remains unexecuted;
- supplied roots close equal;
- successor package terminally closes;
- no write follows seal.

Return:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_CLEAN_AUDIT_HARNESS_INTERFACE_REPAIR_BLOCKED

when:

- cleanup authority remains ambiguous;
- another acceptance-bearing interface is missing;
- repair exceeds the frozen surface;
- a matrix, causal, rehearsal, validator, or static gate fails;
- Attempt 2 fails.

When this blocked verdict follows Attempt-2 failure, retain:

- repair_candidate_retired:
  true;
- further_localized_repair_authorized:
  false;
- new_clean_implementation_generation_required:
  true.

Return:

CLEAN_AUDIT_HARNESS_REPAIR_PROVENANCE_MISMATCH

for:

- fixed-input mismatch;
- supplied-root mutation;
- indispensable evidence loss;
- unaccounted process/filesystem effect;
- cleanup inequality;
- supplied-root closing inequality;
- source drift after freeze;
- package closure failure;
- postseal filesystem activity.

──────────────────────────────────────────────────────────────────────────────
26. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh repair-root identity
3. Blocked clean-harness identity and closure
4. Exact Attempt-3 source authority
5. Governing-root identities and closing equality
6. Blocker reproduction
7. Cleanup-result authority adjudication
8. Canonical cleanup-result schema
9. Confirmation no conflicting cleanup alias exists
10. Complete derived cross-module interface set
11. Complete registered cross-module interface set
12. Derived/registered/tested interface set equality
13. Repair authority and touched source surface
14. Source-attempt ledger
15. Final production-source registry
16. Final qualification-source registry
17. Final independent-source registry
18. Exact source delta
19. Protected-function equality
20. Precompilation interface conformance
21. Cleanup-result matrix
22. Cross-module interface matrix
23. Prior D01–D10 regression
24. Process-custody regression
25. Synthetic accepted-package regression
26. Synthetic BLOCK-package regression
27. Synthetic provenance-failure regression
28. Synthetic subject-pair regression
29. Bounded compatibility replay
30. Cleanup integration causals
31. Rehearsal A
32. Rehearsal B
33. Normalized rehearsal comparison
34. Independent interface validator
35. Compilation and static qualification
36. Source freeze
37. Frozen-source requalification
38. Confirmation implementation production source was not executed
39. Confirmation full independent audit was not executed
40. Harness-package status
41. Supplied-root closing equality
42. Evidence retention and fixture cleanup
43. Failure-closeout capability and use
44. Temporal-inventory identity
45. Manifest A identity
46. Manifest B identity
47. Independent terminal reprojection
48. Terminal membership and modes
49. No-write-after-closure
50. Candidate terminality disposition
51. Remaining uncertainty and nonclaims
52. Explicit confirmation registry

Required confirmations:

BLOCKED_CLEAN_HARNESS_ROOT_MUTATION_NOT_PERFORMED
BLOCKED_CLEAN_HARNESS_ROOT_NOT_RESUMED
EXACT_ATTEMPT_3_SOURCE_AUTHORITY_ESTABLISHED
ATTEMPT_1_SOURCE_NOT_USED
ATTEMPT_2_SOURCE_NOT_USED
FINAL_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
IMPLEMENTATION_PACKAGE_MUTATION_NOT_PERFORMED
IMPLEMENTATION_PACKAGE_NOT_READJUDICATED
SUCCESSOR_GEN2_ROOT_MUTATION_NOT_PERFORMED
AUTHORITATIVE_CONTRACT_ROOT_MUTATION_NOT_PERFORMED
SCHEMA_SOURCE_ROOT_MUTATION_NOT_PERFORMED
SCHEMA_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
VALIDATION_SPEC_ROOT_MUTATION_NOT_PERFORMED
ATTEMPT_2_FAILED_ROOT_MUTATION_NOT_PERFORMED
CLEANUP_INTERFACE_MISMATCH_REPRODUCED
CLEANUP_RESULT_AUTHORITY_ADJUDICATED
CANONICAL_CLEANUP_RESULT_SCHEMA_FROZEN
NO_CONFLICTING_CLEANUP_ALIAS
NO_CLEANUP_FIELD_FALLBACK
EQUAL_EMPTY_CLEANUP_SETS_ACCEPTED
CLEANUP_INTEGER_ZERO_COUNTS_ACCEPTED
CLEANUP_SET_EQUALITY_ENFORCED
COMPLETE_CROSS_MODULE_INTERFACE_SET_DERIVED
COMPLETE_CROSS_MODULE_INTERFACE_REGISTRY_PRODUCED
DERIVED_REGISTERED_INTERFACE_SET_EQUAL
EVERY_REGISTERED_INTERFACE_DIRECTLY_TESTED
EVERY_REGISTERED_INTERFACE_INDEPENDENTLY_TESTED
NO_UNREGISTERED_ACCEPTANCE_BEARING_INTERFACE
REPAIR_BOUNDED_TO_CLEANUP_AND_INTERFACE_CLOSURE
PACKAGE_ACCEPTANCE_RULES_UNCHANGED
PACKAGE_VERDICT_RULES_UNCHANGED
UNRELATED_FUNCTIONS_AST_IDENTICAL
SOURCE_ATTEMPT_LIMIT_RESPECTED
PRECOMPILATION_INTERFACE_CONFORMANCE_PASSED
CLEANUP_RESULT_MATRIX_PASSED
CROSS_MODULE_INTERFACE_MATRIX_PASSED
D01_D10_REGRESSION_PASSED
PROCESS_CUSTODY_REGRESSION_PASSED
SYNTHETIC_ACCEPTED_PACKAGE_REGRESSION_PASSED
SYNTHETIC_BLOCK_PACKAGE_REGRESSION_PASSED
SYNTHETIC_PROVENANCE_FAILURE_REGRESSION_PASSED
SYNTHETIC_SUBJECT_PAIR_REGRESSION_PASSED
BOUNDED_COMPATIBILITY_REPLAY_PASSED
BOUNDED_COMPATIBILITY_REPLAY_EMITTED_NO_PACKAGE_VERDICT
CLEANUP_INTEGRATION_CAUSALS_PASSED
COMPLETE_REHEARSAL_A_PASSED
COMPLETE_REHEARSAL_B_PASSED
TWO_REHEARSALS_NORMALIZED_EQUAL
INDEPENDENT_INTERFACE_VALIDATOR_PASSED
ALL_SOURCES_COMPILED
STATIC_SOURCE_GATES_PASSED
FINAL_SOURCE_REGISTRIES_FROZEN
FINAL_SOURCES_NOT_MODIFIED_AFTER_FREEZE
FROZEN_SOURCE_REQUALIFICATION_PASSED
IMPLEMENTATION_PRODUCTION_SOURCE_NOT_EXECUTED
FULL_INDEPENDENT_AUDIT_NOT_EXECUTED
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
EVIDENCE_RETAINED_BEFORE_CLEANUP
AUDIT_OWNED_CLEANUP_SET_EQUALITY_PASSED
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
SUCCESSOR_TEMPORAL_INVENTORY_CREATED
SUCCESSOR_TEMPORAL_INVENTORY_VERIFIED
SUCCESSOR_MANIFEST_A_CREATED
SUCCESSOR_MANIFEST_B_CREATED
SUCCESSOR_MANIFESTS_BYTE_IDENTICAL
SUCCESSOR_TERMINAL_REPROJECTION_PASSED
SUCCESSOR_ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_WRITE_AFTER_TERMINAL_CLOSURE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

After:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_CLEAN_AUDIT_HARNESS_INTERFACE_REPAIRED_QUALIFIED_FROZEN_READY_FOR_FRESH_AUDIT

the next tranche is exactly one fresh independent audit of the unchanged sealed
implementation package.

Do not combine that audit with this repair.

If Attempt 2 fails, retire this clean candidate and return to a new clean
implementation generation. Do not issue another localized repair.
```

**Sources:** The report records all three attempt blockers, identifies the final cleanup shape mismatch, and confirms that the third candidate had not reached source freeze or terminal closure. :chatgpt-content-reference{index="4"} It also shows that all D01–D10 matrices, process custody, synthetic verdict lanes, bounded replay, both rehearsals, and normalized comparison passed before that blocker. :chatgpt-content-reference{index="5"} Supplied-root equality, cleanup, and failure closeout passed, while final registries, freeze, requalification, temporal inventory, and manifests remained unestablished. :chatgpt-content-reference{index="6"}

**Confidence:** 0.995 that no implementation-package defect was established; 0.98 that the clean architecture is reusable; 0.97 that one bounded interface-repair tranche is proportionate; 0.95 that another uncovered acceptance-bearing interface should terminate this candidate rather than trigger a further localized patch.
