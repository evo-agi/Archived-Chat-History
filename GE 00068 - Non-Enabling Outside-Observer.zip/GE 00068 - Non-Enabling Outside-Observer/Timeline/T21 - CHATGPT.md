Codex stopped at the correct gate. This is **not a substantive Repair 10I-A source failure yet**. It is a validation-construction failure: the required regression command was run without the governed private candidate repository, commit, and tree inputs that four tests intentionally require. An exit code of zero does not cure those skips, so sealing would have been wrong.

The important facts are:

- The authorized repository and successor edits are already present.
- The frozen-H vulnerabilities were reproduced and the repaired successor passed its full, focused, race, and deterministic-build controls.
- Repository formatting, documentation-contract, and privacy controls passed.
- The failed regression did not reveal a test assertion failure; it revealed missing validation inputs.
- Module verification, vet, builds, closeout, and sealing remain genuinely unperformed.
- Repair 10I-B remains correctly untouched.

So the right move is **a narrow continuation of the same Repair 10I-A implementation turn**. Do not revert, create a new repair tranche, perform new reconnaissance, weaken the skip gates, or start 10I-B. Supply the missing governed private candidate environment, rerun a fresh repository-validation control, finish closeout, and seal the existing Phase I-A child additively. Engineering validation and repair of validation failures belong to the implementation turn; independent audit remains later and separate. 

Pass this to the same Codex conversation:

```text
Permission remains workspace-write.

Continue the existing Repair 10I-A implementation turn. This is a bounded
validation continuation, not new reconnaissance and not Repair 10I-B.

Do not create subagents. You remain the sole writer.

Return exactly one:

REPAIR10I_A_IMPLEMENTED_TOOL_GATE_SEALED_READY_FOR_10I_B
REPAIR10I_A_VALIDATION_BLOCKED
REPAIR10I_A_BASELINE_MISMATCH
REPAIR10I_A_SCOPE_EXPANSION_REQUIRED

## 1. Current adjudication

The prior stop was correct.

The external-TLS regression command exited zero but emitted four test-level
skips because the governed private candidate repository, commit, and tree
environment was absent.

Treat this as a validation-construction defect, not as evidence that the
Repair 10I-A source implementation is wrong.

Do not edit or weaken the tests to eliminate the skips. Supply the exact
governed private inputs those tests require.

Do not start Repair 10I-B.

## 2. Required baseline

Repository:

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Require:

branch:
codex/remote-alpha-external-tls-status-observation-v1

HEAD:
567bceced5df95ecfe787cc66038d463a854e12c

sole parent:
05dde14d185b6e022dcc169ef1a658a97961850f

HEAD tree:
b7cab23732572c2aaea9d5f2f1593338e2e75338

upstream:
absent

index SHA-256:
012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31

current Repair 10I-A repository T:
bdf87ac3eb5527b4779ef40094094548ce7699fb

current repaired-successor tree:
8f60b33980c436422ccb55b3f5d6e938c03c4a22

Use the complete current repository inventory digest and complete successor
inventory digest already retained in the Phase I-A records; do not rely on the
abbreviated report renderings. Report their full values.

Require the same authorized eight repository files and seven successor files.
Require every nonallowlisted path to remain byte- and mode-identical.

Stop with REPAIR10I_A_BASELINE_MISMATCH before further work on any drift.

## 3. Existing Phase I-A evidence

Continue additively in:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a-closure-00280085500a

Requirements:

- The directory must exist.
- It must remain unsealed: no qualifying final manifest or detached digest may
  already be installed.
- Preserve every existing failed-attempt record and raw stream.
- Do not delete, overwrite, rename, or repurpose the failed repository-control
  records.
- Use new versioned command/control paths for this continuation.
- The previous failure must remain classified as nonqualifying validation
  construction evidence.
- The evidence manifest must still be the final mutation if the tranche
  ultimately qualifies.

Reverify the immutable Phase H input and its exact manifest:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-h-closure-503d27bfe70d

fdfc710eca48306813f505766f70da35f23e34e32f177f714ab178ee4eee1abb

## 4. First inspect the skip contract

Before launching the corrected regression:

1. Inspect package_test.go around the reported line 3890 and the complete helper
   chain governing those four skips.
2. Record:
   - exact test identities;
   - exact required environment variable names;
   - exact repository/commit/tree validation rules;
   - whether ES_T2AP_REAL_VALIDATION or another gate is required;
   - every input those tests consume;
   - why the skip occurred in the prior command.
3. Bind this inspection to the current Repair 10I-A source bytes.
4. Do not change source merely because the prior command omitted its required
   environment.

At minimum, reconcile the previously governed variables:

ES_T2AP_PRIVATE_REPOSITORY
ES_T2AP_PRIVATE_COMMIT
ES_T2AP_PRIVATE_TREE

Use any additional variable only when the exact current test source requires
it. Do not guess or introduce a new test mode.

## 5. Construct the governed private candidate inputs

Create one new exclusive private validation control beneath a mode-0700 root,
under umask 077.

It must be outside the repository and inside the Phase I-A validation scratch
boundary.

Materialize a complete, no-hardlink copy of the exact current Repair 10I-A
source.

Requirements:

- Reconstruct current T exactly as
  bdf87ac3eb5527b4779ef40094094548ce7699fb.
- Create a private Git repository/admin topology accepted by the current tests.
- Create one deterministic synthetic validation-only commit C over that exact T.
- Record C and T before test execution.
- Preserve realistic required config/ref topology when the tests require it.
- Use a private object store, index, refs, HOME, XDG, GOPATH, GOMODCACHE,
  GOCACHE, GOTMPDIR, and TMPDIR.
- Use no Git alternate or live repository administration unless the current
  validated constructor explicitly requires a read-only input and the contract
  permits it.
- Do not expose the real worktree, real Git administration, PackageFloor, fixed
  runtime slots, installed target, ignored .out state, or private operator state
  to the test process.
- Keep execution offline.
- Record complete source inventory, T, synthetic C, Git topology identity, argv,
  cwd, environment, and cleanup disposition.

Prefer the already governed exact-candidate construction mechanism retained in
Phase H or the current Phase I-A validation tooling. Do not invent an
incompatible ad hoc fixture.

This is a repository-validation input only. It is not Repair 10I-B product A/B,
one of the five final semantic controls, artifact acceptance, or a snapshot.

## 6. Corrected external-TLS regression gate

First rerun the exact required regression command in a fresh command record,
with the governed private repository/commit/tree environment supplied:

go test -json -count=1 -p=1 -parallel=1 ./es/externaltls/... \
  -skip '^TestProductionLifetimeLockFD9CLOEXECPreventsChildInheritanceV2$'

Use the pinned Go 1.26.5 binary and the already frozen offline/private
environment.

Require:

- command exit 0;
- complete, valid JSONL through EOF;
- no panic, race, build/setup failure, malformed stream, missing terminal, or
  duplicate terminal;
- every one of the four previously skipped exact-candidate tests is now
  actually selected, runs, and passes;
- zero unexpected test-level skips;
- any effect of the explicit -skip expression is separately classified rather
  than conflated with environment-gated skips;
- no live repository, PackageFloor, fixed-slot, installed-route, network, or
  remote effect;
- no survivor, open descriptor, socket, listener, or residue;
- two fresh absence observations after cleanup.

If any previously skipped test still skips, stop with
REPAIR10I_A_VALIDATION_BLOCKED. Do not alter the tests to force execution.

If a test executes and fails, determine whether the failure is:

- a Repair 10I-A source defect repairable within the frozen eight/seven files;
- a private candidate-construction error;
- an environmental limitation;
- or a scope-expansion requirement.

Repair only a demonstrated Repair 10I-A defect within the frozen scope. Any
other necessary source widening returns
REPAIR10I_A_SCOPE_EXPANSION_REQUIRED.

## 7. Fresh qualifying repository-validation control

After the corrected regression qualifies, run one complete fresh repository
validation control against the same exact Repair 10I-A bytes. Preserve the
earlier successful records, but do not use a collection of partial attempts as
a substitute for this final qualifying control.

Run:

### No-write formatting

gofmt -d docs_contract_test.go \
  es/externaltls/internal/statusobservation/remoteobserver/observe_test.go

Require empty output.

### Documentation contract

go test -json -count=1 -p=1 -parallel=1 . \
  -run '^TestRemoteAlphaExternalTLST2APRepair10Contract$'

### Privacy

go test -json -count=3 -p=1 -parallel=1 \
  ./es/externaltls/internal/statusobservation/remoteobserver \
  -run '^(TestObserveV1WitnessCustodyClassificationAndContextV1|TestObserverClosingWitnessPrivacyV1|TestRepair10IStructuralPrivacyProjectionCausalControlsV1)$'

### External-TLS regression with governed private candidate environment

go test -json -count=1 -p=1 -parallel=1 ./es/externaltls/... \
  -skip '^TestProductionLifetimeLockFD9CLOEXECPreventsChildInheritanceV2$'

Again require all four exact-candidate tests to run and pass with zero
unexpected skips.

### Module verification

go mod verify

Require:

all modules verified

Use a complete private offline cache. Do not fetch.

### Vet

go vet ./...

Require exit zero and empty diagnostics.

### Private builds

GOOS=darwin GOARCH=arm64 CGO_ENABLED=0 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <PRIVATE>/es-external-tls-status-package \
  ./es/externaltls/cmd/es-external-tls-status-package

GOOS=darwin GOARCH=arm64 CGO_ENABLED=0 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <PRIVATE>/es-external-tls-status \
  ./es/externaltls/cmd/es-external-tls-status

GOOS=linux GOARCH=amd64 CGO_ENABLED=0 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <PRIVATE>/es-external-tls-observer-linux-amd64 \
  ./es/externaltls/cmd/es-external-tls-observer

GOOS=linux GOARCH=arm64 CGO_ENABLED=0 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <PRIVATE>/es-external-tls-observer-linux-arm64 \
  ./es/externaltls/cmd/es-external-tls-observer

Inspect and hash all four. Do not execute the Linux binaries. Remove all four
after their records are complete.

## 8. Successor evidence recheck

No successor source change is expected during this continuation.

Reverify, read-only:

- final successor inventory and tree;
- exact seven-file changed set;
- exact five-file frozen set;
- two disjoint source-copy identities;
- byte-identical and inode-distinct A/B runner, comparator, semantic, and
  fixture binaries;
- completed full/focused count-three tests;
- completed race tests;
- frozen-H vulnerable versus repaired-I causal pairs;
- exhaustive CommandSpec fingerprint table;
- F/G/H schema rejection;
- independent raw-semantic re-extraction;
- late-fault invalidation.

If the current successor bytes differ from the already validated successor
identity, stop with REPAIR10I_A_BASELINE_MISMATCH.

Do not rerun expensive successor controls solely for ceremony when their sealed
raw evidence remains complete and bound to unchanged successor bytes. Rerun a
control only if its retained evidence is incomplete, inconsistent, or not
safely sealable.

## 9. Closeout and sealing

After all gates qualify:

1. Recompute complete repository inventory and T.
2. Require T to remain the exact current Repair 10I-A T unless an in-scope,
   recorded repair was necessary. If bytes changed, rerun every affected
   validation against the new exact bytes.
3. Verify the exact eight-file repository scope.
4. Verify the exact seven-file successor scope.
5. Verify every nonallowlisted repository and successor path is byte- and
   mode-identical.
6. Reverify Phase H completely.
7. Verify:
   - branch, HEAD, parent, HEAD tree, absent upstream;
   - index bytes;
   - membership;
   - zero staged/deleted/renamed/unmerged;
   - no Git operation marker or lock;
   - no fixed runtime slot;
   - no PackageFloor/package/generation root;
   - no installed target;
   - no validation process, socket, listener, descriptor, cache, binary, or
     private repository residue.
8. Retain the prior failed validation attempt as failed/superseded evidence.
9. Add the successful continuation records without overwriting anything.
10. Produce the implementation report and Repair 10I-A finding ledger.
11. Install detached digest, then evidence-manifest-v1.txt as the final Phase
    I-A mutation.
12. Perform complete read-only post-seal verification.
13. Write nothing afterward.

The final report must include complete, non-abbreviated repository and successor
inventory hashes.

## 10. Repair 10I-B boundary

Even after success:

- do not construct the real deliberate mutant;
- do not execute final/fresh/mutant/HEAD/Repair-9 full-suite controls;
- do not externally qualify those five controls;
- do not run the five semantic comparisons;
- do not run product A/B C/T/D/E preparation;
- do not create an integrated ZIP, handoff, capture child, or recovery lineage;
- do not perform or claim independent audit;
- do not stage, commit, push, install, invoke a live route, or contact a remote
  host.

The private candidate repository created here exists solely to satisfy the
Repair 10I-A repository test contract. It must be deleted at closeout.

## 11. Final report

Report:

1. Verdict.
2. Why the prior skip occurred.
3. Exact private candidate environment and synthetic C/T.
4. Exact identities of the four formerly skipped tests and proof they ran.
5. Opening and final repository T and inventory.
6. Opening and final successor tree and inventory.
7. Exact repository and successor touched sets.
8. Every validation command, result, skips, and raw evidence reference.
9. Module/vet/build results.
10. Failed/superseded attempt treatment.
11. Cleanup and absence evidence.
12. Phase I-A manifest path, size, SHA-256, payload count, and detached digest.
13. Remaining exact Repair 10I-B work.
14. Assumptions and limitations.

Required footer:

REPAIR10I_B_NOT_STARTED
INTEGRATED_SNAPSHOT_NOT_CREATED
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
INSTALLATION_NOT_PERFORMED
LIVE_ROUTE_NOT_INVOKED
REMOTE_CONTACT_NOT_PERFORMED
SUBAGENTS_CREATED: 0
```

The key restraint is: **provide the missing governed validation inputs; do not “fix” the skip by weakening the test contract.**

### Sources

- Codex’s Repair 10I-A report in this turn.
- The project operating protocol separates parent-only implementation validation from a later fresh independent audit, and permits implementation closeout to repair failures caused by the patch while preserving exact scope.  
- Exact provenance confirms common bytes but does not establish correctness or validation sufficiency; the remaining gates still must run and bind to the final bytes. 

**Confidence:** 0.98 that Codex stopped correctly; 0.96 that no new reconnaissance is needed; 0.95 that this can be resolved as an additive 10I-A validation continuation without repository source changes; 0.88 that the existing governed exact-candidate constructor will satisfy all four skipped tests without scope expansion.
