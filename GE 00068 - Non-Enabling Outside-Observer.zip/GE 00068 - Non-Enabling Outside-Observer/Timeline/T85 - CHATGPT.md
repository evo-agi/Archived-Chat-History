This is the correct stop. The blocker is **not a Repair 9 defect, an A5C semantic defect, or failed historical evidence**. It is a successor source-modeling defect:

- A5C can represent an exact source or an intentional mutant.
- It cannot represent an exact historical source plus a deterministic, validation-only harness transformation.
- Reusing `intentional-mutant` would misclassify the purpose and policy of the transformation.
- Silently patching Repair 9 would destroy the distinction between its historical source identity and its effective validation materialization.

The durable model should keep these as separate dimensions:

```text
source_class = historical-repair9

base source:
  T = 0ea3b661…
  inventory = 7b8cfa43…

validation_harness_overlay:
  exact one-file deterministic transformation
  purpose = remove sandbox-incompatible test-private process substitution
  authority = validation scaffolding only

effective validation source:
  T = 4bd05d4f…
  inventory = e17a7732…
```

`validation-harness-overlay` should **not replace the source class**. It should be an optional, tightly governed provenance layer over an otherwise exact source class. This preserves the historical Repair 9 identity while honestly identifying the bytes that are executed.

The next tranche should be a read-only contract freeze before implementation. The required schema versions, qualification behavior, overlay restrictions, and touched files are not yet fully established. The failed A6 child should remain unsealed negative evidence and must not be resumed.

## Codex prompt: Repair 10I-A6O historical-overlay reconnaissance

```text
Objective

Perform a parent-only, source-read-only Repair 10I-A6O reconnaissance to
freeze the exact successor contract required to represent and independently
qualify one bounded historical validation-harness overlay.

The current sealed A5C successor cannot represent the required Repair 9
control honestly:

- source class `historical-repair9` requires exact base identity;
- Repair 9 needs one deterministic test-private validation overlay to remove
  sandbox-incompatible Bash process substitution;
- A5C requires non-mutants to have equal base/effective source identities and
  empty mutation provenance;
- A5C accepts provenance only for `intentional-mutant`;
- explicit overlay fields are rejected as unknown.

Freeze the smallest safe successor amendment that represents:

1. exact historical source identity;
2. an optional, closed, validation-only overlay;
3. exact effective execution identity;
4. independent materialization and qualification of both;
5. explicit non-authority and non-product treatment.

Do not implement the amendment in this turn.

Do not modify repository source.
Do not modify A5C.
Do not modify A5T4.
Do not modify, resume, overwrite, or seal the failed A6 child.
Do not run any historical full suite.
Do not run product A/B.
Do not create a snapshot, ZIP, handoff, or capture child.
Do not stage, commit, push, install, invoke a live route, contact a remote
host, or execute Linux binaries.

No subagents. You are the sole operator.

Repository

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Sealed A5T4 repository-validation lineage

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5t4-harness-closure-ab646e5a0e66

Sealed A5C successor

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5c-successor-closure-8de797304ea9

Sealed A5FD harness analysis

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5fd-devfd-recon-ab646e5a0e66

Failed and unsealed A6 attempt

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a5c-8de797304ea9

Required new reconnaissance child, absent at opening

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6o-historical-overlay-recon-8de797304ea9

## 1. Mandatory opening and closing gates

Require exact repository identity:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- upstream:
  absent
- index SHA-256:
  012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31
- repository T:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- repository inventory:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2
- membership:
  389 total / 375 tracked / 14 nonignored untracked
- staged/deleted/renamed/unmerged:
  0/0/0/0

Require the repository delta from sealed A5 to remain exactly the three
existing A5T4 test files recorded by the sealed A5T4 inventory.

Require exact sealed A5T4:

- manifest SHA-256:
  7cc55f3399d8c5eac48470a4eb82e8087753ddbb17e8d0eb6de7d03ad7937888
- manifest size:
  202930
- payloads:
  1000
- directories:
  188
- repository T:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- inventory:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2

Require exact sealed A5C:

- manifest SHA-256:
  05ff0c0f63babccf1f6f11be262202c5792a1ce93f497b0231eb49e532e38489
- manifest size:
  31421
- payloads:
  216
- directories:
  71
- source T:
  2c2d0b36f52d5949d023a36400f0e0748149875a
- source inventory:
  810f9d2934d56fba840f3c44938ee7a7784face2c8fa2458873fc5df8722f6f9
- members:
  12

Recover and verify all A5C A/B binary identities from the sealed report and
manifest.

Require:

- A/B byte equality;
- inode-distinct copies;
- complete post-seal verification;
- all seven A5C tests;
- A5P2 PTY nonregression;
- active v3/v2/v1 dialect;
- active observability rule:
  observability-inbound-request-complete-v2.

Require exact sealed A5FD:

- manifest SHA-256:
  f4bfa2b8479a8679d4a2af4173f2bc9d76bc6f4085cdda3bb4c60d06c0b9b768
- size:
  4951
- payloads:
  37
- directories:
  6

Require the failed A6 child to remain:

- present;
- unsealed;
- without evidence manifest or detached digest;
- byte-exact from opening through closing.

At opening, create and retain a complete safe snapshot of its path set, modes,
sizes, hashes, links, and directory modes.

Reverify:

- closeout/final-report-v1.md
- findings/historical-control-construction-required-v1.json
- sources/historical-repair9-validation-harness-overlay-provenance-v1.json
- both independent bounded A5C rejection probes;
- the superseded A5C test invocation and corrected invocation;
- cleanup and two absence epochs.

Bind these exact facts:

Repair 9 base identity:

- T:
  0ea3b661f09e73e1126bae0f6e993e22bbf21198
- inventory:
  7b8cfa43f5338a15b632a3ce8fc20f8df56a192702d951b4d5967deba494199e

Repair 9 overlay-effective identity:

- T:
  recover the complete value beginning `4bd05d4f` from the retained provenance
- inventory:
  recover the complete value beginning `e17a7732` from the retained provenance

Historical HEAD:

- T:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- inventory:
  291d9e9b2cf2f3875f5c06378415fb49e0b17703adc846874a0026af843f399a
- overlay:
  not required

Require all other sealed and unsealed lineage to remain exact.

Require the A6O reconnaissance target to be absent.

Repeat all repository, A5C, A5T4, A5FD, failed-A6, and lineage checks at
closeout.

Stop on any mismatch:

REPAIR10I_A6O_RECONNAISSANCE_BASELINE_MISMATCH

## 2. Reconnaissance evidence child

After the opening gate, create A6O exclusively under umask 077 with exactly:

opening/
source/
schemas/
tests/
findings/
closeout/

All directories mode 0700.

All files regular, single-link, non-symlink, mode 0600 or 0700 as intended.

No hardlinks.

Do not copy repository contents or sensitive raw streams unnecessarily.

Do not import executable Python modules from predecessor evidence children.

The child may contain only:

- safe source excerpts/inventories;
- schema and producer/consumer maps;
- overlay provenance analysis;
- the frozen implementation contract;
- causal and validation plans;
- closeout evidence.

No tests or builds are authorized.

## 3. Recover the exact current A5C source model

Inspect the exact sealed A5C source and document:

1. Every active `source_class`.
2. Every base/effective source identity field.
3. Every mutation-provenance field.
4. Every condition requiring base identity to equal effective identity.
5. Every condition requiring empty provenance for non-mutants.
6. Every intentional-mutant-only provenance decoder.
7. Every producer and consumer of:
   - suite specification;
   - command intent;
   - command result;
   - suite result;
   - binding recomputation;
   - control qualification;
   - semantic comparison specification;
   - semantic comparison result;
   - semantic comparison custody.
8. Every logical-fingerprint field involving source class, T, inventory, or
   provenance.
9. Every external qualification path that reopens or recomputes source
   identity.
10. Every historical-schema rejection gate.

Inspect:

- `FORMAT.md`
- `envelope/runner.go`
- `envelope/source.go`
- `envelope/semantic.go`
- `envelope/envelope_test.go`
- relevant CLI mains where they dispatch schema-specific logic.

State where inspection stops.

## 4. Recover the exact Repair 9 overlay

From sealed A5T4, A5FD, and failed A6 evidence, recover:

- exact source path;
- opening logical mode;
- opening size and SHA-256;
- effective size and SHA-256;
- exact base T/inventory;
- exact effective T/inventory;
- exact match count;
- match byte offsets;
- exact before bytes;
- exact replacement bytes;
- line-count behavior;
- loop-body equality;
- nonmatched-byte equality;
- complete transformation recipe;
- recipe source identity;
- reversibility evidence;
- shell-equivalence evidence;
- active test declarations before and after;
- production-wrapper identity before and after;
- exact reason Repair 9 requires the overlay;
- exact reason historical HEAD does not.

The overlay must remain exactly the A5T4 validation-harness transformation.

Do not design a general source transformation framework.

## 5. Strategic data-model decision

Evaluate and adjudicate these models.

### Model A — replace the source class

Example:

source_class = validation-harness-overlay

Reject unless repository evidence proves that the underlying historical class
can still be independently and unambiguously recovered.

The expected disposition is rejection because it conflates historical source
identity with validation adaptation.

### Model B — misuse intentional-mutant provenance

Reject unless repository evidence proves identical semantics and policy.

The expected disposition is rejection because:

- intentional mutant is an expected semantic difference;
- validation overlay is intended to preserve source-test meaning while making
  the historical harness executable under current containment;
- their acceptance and comparison rules differ.

### Model C — silent materialization patch

Reject.

It destroys auditable base/effective identity and prevents independent
qualification.

### Model D — separate source class and validation overlay

Preferred target unless exact source inspection disproves it:

```text
source_class = historical-repair9

base:
  T
  inventory
  membership

validation_harness_overlay:
  closed, optional, source-external provenance record

effective:
  T
  inventory
  membership
```

Historical HEAD remains:

```text
source_class = historical-head
validation_harness_overlay = absent
base == effective
```

Final, fresh final, and intentional mutant remain overlay-free.

Freeze the selected model and the rejected alternatives.

## 6. Overlay authority and classification

Freeze the overlay as:

- validation scaffolding only;
- source-external evidence/projection;
- non-authoritative;
- not product source;
- not historical product behavior;
- not an intentional mutation;
- not a public schema;
- not a general migration mechanism;
- not reusable for arbitrary historical sources.

The overlay may be permitted only when all of the following are exact:

- source class:
  historical-repair9
- base T:
  0ea3b661f09e73e1126bae0f6e993e22bbf21198
- base inventory:
  7b8cfa43f5338a15b632a3ce8fc20f8df56a192702d951b4d5967deba494199e
- overlay ID:
  freeze one exact identifier
- overlay path:
  exact one recovered test file
- transformation:
  exact recovered A5T4 derivative
- changed path count:
  1
- no addition, removal, rename, or mode change
- test declaration universe:
  unchanged
- production path set:
  unchanged
- production bytes:
  unchanged
- line count:
  unchanged
- transformation:
  unique and reversible
- effective T/inventory:
  exact retained values.

Any other source class, base identity, path, recipe, or effective identity must
be rejected.

Do not authorize caller-supplied arbitrary overlay recipes.

## 7. Overlay provenance record

Freeze one exact private schema, provisionally:

execution-substrate.repair10i.validation-harness-overlay-provenance.v1

Adjudicate the final name after inspecting the existing schema namespace.

The record must be closed and contain at least:

- schema;
- overlay ID;
- classification;
- purpose;
- allowed source class;
- base T;
- base inventory;
- base membership;
- effective T;
- effective inventory;
- effective membership;
- changed-path count;
- path;
- logical mode before/after;
- size before/after;
- SHA-256 before/after;
- exact recipe ID;
- exact recipe-source SHA-256;
- exact recipe-source reference within the evidence lineage;
- match count;
- match byte offset;
- before-block SHA-256;
- after-block SHA-256;
- line count before/after;
- loop-body SHA-256 before/after;
- nonmatched-byte equality;
- reversible;
- shell-equivalence evidence reference and SHA-256;
- test-declaration-universe equality;
- production-byte equality;
- creation sequence;
- frozen-before-execution;
- final outcome;
- ordered errors.

Do not retain arbitrary source content in the record when hashes and bounded
safe excerpts are sufficient.

## 8. Materialization and qualification contract

Freeze this sequence for a valid overlaid historical control:

1. Materialize the exact base source with no hardlinks.
2. Verify base source class, T, inventory, membership, modes, and path set.
3. Verify the exact overlay provenance record.
4. Apply the exact built-in overlay recipe.
5. Require exactly one match.
6. Recompute the effective source inventory and T.
7. Require exact expected effective identity.
8. Freeze the effective source before command execution.
9. Run the suite without later source mutation.
10. Retain base and effective identities independently.
11. Opposite-side qualification independently:
    - rematerializes or safely reconstructs the base identity;
    - revalidates the overlay recipe and provenance;
    - recomputes the expected effective identity;
    - verifies the executed source;
    - verifies suite, command, raw, semantics, terminal, resource, and cleanup
      bindings.
12. Comparison records retain both base and effective source identities.
13. Historical policy results are explicitly labeled:
    historical source under validation-harness overlay.

Producer captions are not authority.

The control must not qualify if only the effective identity is available and
the base identity cannot be proven.

## 9. Comparison semantics

Freeze how overlaid historical evidence participates in comparison.

The factual semantic comparison uses the independently qualified effective
execution output.

The result must also retain:

- historical base identity;
- overlay ID;
- effective identity;
- overlay qualification outcome;
- explicit nonclaim that the overlay bytes are historical product source.

The historical policy may reason over the qualified terminal and diagnostic
evidence only after overlay qualification succeeds.

The overlay itself must not:

- create or remove test declarations;
- change production behavior;
- be counted as a final product improvement;
- authorize an otherwise blocked transition;
- hide unknown diagnostics;
- alter the candidate structural historical-policy lattice.

Any semantic difference caused by the overlay outside its exact intended
validation-environment correction blocks qualification.

## 10. Active schema-version freeze

Inspect the complete current A5C v3/v2/v1 dialect.

Identify every acceptance-bearing record whose meaning changes when a
validation overlay may be present.

At minimum inspect whether changes are required to:

- suite spec;
- AB suite spec;
- command intent;
- command result;
- terminal reconciliation;
- suite result;
- binding recomputation;
- control qualification;
- semantic comparison spec;
- semantic comparison result;
- semantic comparison custody;
- effective read policy;
- source inventory or mutable inventory;
- byte-capture and byte-comparison records.

Do not version records whose meaning is genuinely unchanged.

Do not reuse a current schema identifier if its acceptance meaning changes.

Freeze:

- complete active successor dialect after the amendment;
- historical parse-only dialects;
- exact producer/consumer map;
- strict decoding behavior;
- rejection of mixed old/new acceptance records.

The likely direction is a new outer generation for source-binding records plus
the new overlay-provenance schema, but do not freeze version numbers by
assumption. Derive them from the complete producer/consumer inspection.

## 11. Exact successor touched-file freeze

Recover:

- all 12 A5C source members;
- exact source paths implementing source class, materialization, provenance,
  qualification, comparison, and schema dispatch.

Freeze the smallest complete successor touched-file set.

Inspect explicitly whether changes are required to:

- `FORMAT.md`
- `envelope/runner.go`
- `envelope/source.go`
- `envelope/semantic.go`
- `envelope/envelope_test.go`
- `cmd/repair10-runner/main.go`
- `cmd/repair10-semantic/main.go`
- `cmd/repair10-compare/main.go`
- `cmd/repair10-fixture/main.go`
- golden files
- `go.mod`

Repository source must remain unchanged.

No thirteenth successor source member.
No new dependency.
No general overlay framework.

If exact scope cannot be frozen, return blocked.

## 12. Mandatory causal-test matrix

Freeze active successor tests covering:

### Current vulnerable condition

- exact Repair 9 base source;
- honest base/effective identities;
- exact overlay provenance;
- current A5C rejects before control creation.

### Valid Repair 9 overlay

- exact base source accepted;
- exact one-file overlay accepted;
- effective identity exact;
- suite/control source class remains historical-repair9;
- overlay classification retained;
- external qualification independently recomputes base, recipe, effective
  identity, and execution binding.

### Overlay absence

- historical HEAD qualifies without an overlay;
- final and fresh qualify without overlays;
- intentional mutant qualifies only through intentional-mutant provenance.

### Wrong source class

Reject overlay on:

- historical HEAD;
- final;
- fresh final;
- intentional mutant;
- test fixture;
- any unknown source class.

### Wrong base identity

Reject:

- one-nibble base T mutation;
- one-nibble inventory mutation;
- wrong membership;
- wrong path set;
- wrong logical mode.

### Wrong overlay

Reject:

- unknown overlay ID;
- wrong path;
- more than one changed path;
- addition/removal/rename;
- mode change;
- zero matches;
- multiple matches;
- changed loop body;
- changed nonmatched bytes;
- changed line count;
- nonreversible transformation;
- recipe-source mismatch;
- shell-equivalence evidence mismatch;
- test declaration added/removed;
- production byte changed;
- unexpected effective T/inventory.

### Provenance custody

Reject:

- missing provenance;
- provenance created after suite execution;
- mutable provenance;
- producer-only caption;
- missing recipe bytes;
- recipe hash without recoverable recipe source;
- path or record inode alias;
- late close or resource fault.

### Semantic containment

Reject when the overlay:

- changes a terminal outside the exact validation-environment correction;
- adds or removes diagnostics outside its bounded purpose;
- changes the test universe;
- masks an unknown diagnostic;
- changes product-source claims.

### Mixed classes

Reject:

- intentional-mutant provenance plus validation overlay in the same current
  control;
- old schema with new overlay record;
- new schema with old source-binding semantics.

## 13. Validation and restart plan

Freeze this implementation sequence:

1. Create a new successor implementation child from sealed A5C.
2. Implement only the frozen overlay/source-binding contract.
3. Run two disjoint source/test/race/build controls.
4. Reproduce the current A5C rejection as expected-negative evidence.
5. Run one bounded, freshly materialized Repair 9 overlay construction and
   opposite-side qualification.
6. Run one historical-HEAD no-overlay qualification.
7. Reverify final/fresh/mutant paths remain unchanged.
8. Seal the successor amendment.
9. Create a new A6 evidence-refresh child.
10. Restart all five controls from the beginning.
11. Do not resume the current failed A6 child.
12. Run all five comparisons and structural historical analysis.
13. Freeze or block the future historical-comparator policy based on fresh
    evidence.

A bounded overlay causal does not replace the fresh A6 controls.

## 14. Stop conditions for future implementation

Freeze stop conditions including:

- baseline or lineage mismatch;
- overlay recipe unavailable or ambiguous;
- need for repository change;
- need for arbitrary caller-supplied overlay;
- general source-transformation framework required;
- effective identity cannot be reproduced from exact base plus recipe;
- external qualification cannot independently recompute the overlay;
- old schema can qualify new overlay semantics;
- intentional-mutant and overlay semantics cannot be kept separate;
- overlay changes test declarations or production bytes;
- overlay changes semantics outside its exact validation purpose;
- source scope exceeds the frozen successor files;
- new dependency or thirteenth member required.

## 15. Required verdict

Return exactly one:

### Contract ready

REPAIR10I_A6O_RECONNAISSANCE_READY

Use only when:

- source class and overlay are separate;
- exact Repair 9 overlay is frozen;
- base/effective identity contract is complete;
- qualification and comparison behavior are complete;
- schema dialect is complete;
- touched-file scope is complete;
- causal and validation matrices are complete;
- no repository change or general overlay framework is required.

### Contract blocked

REPAIR10I_A6O_RECONNAISSANCE_BLOCKED

Use when:

- overlay purpose or bytes are ambiguous;
- current lineage cannot prove exact base/effective identities;
- schema/version effects cannot be closed;
- source scope is unresolved;
- external qualification cannot be made independent;
- a repository or public-contract change is required.

## 16. Required report

Include:

1. Opening and closing identities.
2. Exact current A5C rejection mechanism.
3. Exact Repair 9 base identity.
4. Exact overlay recipe and one-file delta.
5. Exact effective identity.
6. Why HEAD needs no overlay.
7. Selected source-class/overlay model.
8. Rejected alternative models.
9. Overlay authority and nonclaims.
10. Complete provenance-record contract.
11. Materialization and external-qualification sequence.
12. Comparison and reporting semantics.
13. Complete schema dialect and producer/consumer map.
14. Exact successor touched-file set.
15. Exact causal-test matrix.
16. Future implementation and A6 restart sequence.
17. Stop conditions.
18. Inspection limits and uncertainty.
19. Manifest identity and payload count if the reconnaissance child is sealed.
20. Confirmation no repository, successor, predecessor, failed-A6, cache,
    bytecode, test, or build artifact was modified.

No implementation.
No successor amendment.
No historical full suite.
No A6 restart.
No B6.
No product A/B.
No snapshot.
No ZIP or handoff.
No capture child.
No independent audit.
No staging, commit, push, installation, live route, remote contact, or Linux
execution.
```

The critical design judgment is that the overlay is **an independently qualified transformation of a historical control**, not a new historical source class and not an intentional mutant. That separation prevents validation scaffolding from becoming product or historical truth by drift. The project’s MVP freeze explicitly says proof harnesses do not define ES contracts and generated evidence is not authoritative. 

The current failed A6 child is still useful as a precise negative causal. It cannot substitute for the fresh controls required after the successor amendment; the earlier sealed A2 closeout states that distinction explicitly. 

Any successor amendment changes the tested bytes and therefore requires new validation, provenance, and a later fresh independent audit.   Provenance will establish the exact overlay and successor bytes, but not that the model is correct or that the eventual historical policy is sound. 

### Sources

- Codex’s `REPAIR10I_A6_HISTORICAL_CONTROL_CONSTRUCTION_REQUIRED` report supplied in this turn.
- Milestone 0 proof-harness and evidence-authority boundary. 
- Sealed Repair 10I-A2 downstream-control non-substitution boundary. 
- Governed Execution repair and re-audit protocol.  
- Governed Execution provenance limitations. 

**Confidence:** 0.999 that A6 correctly stopped; 0.98 that the missing capability is a separately modeled validation overlay rather than another source class; 0.96 that the Repair 9 overlay can remain one exact test-only transformation; 0.90 that a bounded successor amendment can fit within the existing 12-member tool source; 0.995 that the complete A6 refresh must restart after the amendment seals.
