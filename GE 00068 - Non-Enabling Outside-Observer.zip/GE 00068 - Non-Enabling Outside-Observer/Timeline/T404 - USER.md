Here is Codex's response:

`AUDIT_PROVENANCE_MISMATCH`

1. Primary verdict: `AUDIT_PROVENANCE_MISMATCH`.
2. Fresh audit root: [audit capsule](/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-independent-audit-_0v5svyw) — device `16777234`, inode `180525271`, mode `0700`.
3. Subject package: expected identity matched. Manifest bytes, hashes, represented 65-entry membership, and physical membership matched. The audit’s empty-directory calculation incorrectly counted the root itself, so its terminal-closure gate was not established.
4. Authoritative contract package: expected identity matched; manifests were byte-identical at 17,596 bytes with SHA-256 `a5886…ec7a2`. Its 75 represented entries matched physically. The audit reprojection added a nonexistent `path` member to this package’s `root_identity`, causing a tooling-only canonical comparison failure.
5. Reconciliation root: expected identity matched; manifests were byte-identical at 8,309 bytes with SHA-256 `adf5f5…1c82`; 35 represented entries matched physically. It encountered the same root-empty calculation defect.
6. Normative contract: byte-identical to the authoritative baseline; strict parsing passed; sole semantic writer remained true; status remained `frozen-pending-implementation`.
7. Current schema registry: exactly 15 roles, with unique role, path, and $id; every current identity authenticated.
8. Historical supersession: all 15 historical schemas were defective/noncurrent and correctly linked to current successors.
9. Metaschema validation: 15/15 passed Draft 2020-12 using `python-jsonschema` 4.24.0; zero errors.
10. Family reconstruction: 14/14 generated-record families independently reconstructed without unresolved differences.
11. Fresh contract witnesses: 14/14 schema-valid and contract-valid.
12. Fresh schema witnesses: 14/14 schema-valid and contract-valid; zero jointly unsatisfiable families.
13. Historical regressions: all 10 contradiction sites, 39 excluded members, and 21 Draft violations were absent.
14. Generated-record negative audit: all 946 uniquely named cases freshly passed; zero false outcomes or skips.
15. Contradiction regression: all 137 cases passed, including the exact historical 33-case prefix.
16. Per-schema adjudication: all 14 generated-record schemas passed positive, contract-semantic, and unknown-field checks.
17. Field map V2: independently closed at 766 normative leaves and 333 enforcement rows; zero unresolved pointers.
18. Documentary validators: substantive defect found. The current registry declares nine roles and omits `confirmation-evidence-map-validator`, despite declaring ten minimum roles elsewhere. The retained executable validator also writes directly to the supplied root and could not be rerun under the read-only constraint. See [documentary validator audit](/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-independent-audit-_0v5svyw/validation/current-documentary-validator-audit-v1.json).
19. Fresh independent validator: passed its schema, witness, negative, historical, supersession, and contract-preservation lanes.
20. Prior blind spots: all seven specified lanes were independently exercised and passed.
21. Preterminal correction: substantive evidence defect found. It omits the exact failed operation, files created before failure, files superseded, and superseding result identities. See [correction audit](/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-independent-audit-_0v5svyw/analysis/preterminal-correction-audit-v1.json).
22. Authority chain: verified; the normative contract remained the sole semantic writer and terminal closure remained necessary for package authority.
23. Implementation: absent; implementation authority false; historical candidate not executed or used as an oracle.
24. Security and hygiene: no network, Git, repository/product, target-audit, implementation, live-service, or A6 activity.
25. Failed attempts: the producer correction and three audit-tool attempts were retained and classified as noncurrent/noncontributing.
26. Supplied-root equality: exact opening/closing equality passed for all four supplied roots.
27. Fixture cleanup: bootstrap fixture removed exactly; ENOENT observed twice; zero process or descriptor survivors.
28. Audit temporal inventory: 67 premanifest entries; SHA-256 `c39ed5a3ee001e2e00306c318a41cea494d329d1bf724b7fa1a2b0ead3a6750b`.
29. Audit manifest A: 16,085 bytes; SHA-256 `22cce40cb2c543ab1b4295bdefdb8bb782c21a1b19e1eb9c40cb5feeeaa8deac`.
30. Audit manifest B: identical size, bytes, and SHA-256.
31. Audit-capsule reprojection: failed because the retained manifest recorded `no_empty_directory:false`; this triggers the required provenance-mismatch verdict.
32. Terminal physical tree: 12 directories and 58 files; no actual empty directories, symlinks, special objects, multiply linked files, cache, bytecode, or mode violations.
33. No-write-after-closure: no post-manifest writes were performed, but this confirmation is not established because terminal closure itself failed.
34. Nonclaims: no implementation readiness, runtime readiness, repository authority, deployment, publication, target-audit verdict, orchestration authority, or A6 authority is claimed.
35. Explicit confirmations: every requested confirmation was observed true except:
    - `SUBJECT_SCHEMA_PACKAGE_TERMINAL_CLOSURE_VERIFIED` — not established by the capsule.
    - `CURRENT_DOCUMENTARY_VALIDATORS_BIND_CURRENT_IDENTITIES` — false.
    - `CURRENT_DOCUMENTARY_VALIDATORS_PASSED` — false.
    - `PRETERMINAL_CORRECTION_BOUNDED_AND_NONCONTRIBUTING` — false due incomplete evidence.
    - `AUDIT_CAPSULE_TERMINAL_REPROJECTION_PASSED` — false.
    - `NO_WRITE_AFTER_TERMINAL_CLOSURE` — not established because closure failed.

The complete retained evidence is in the [audit root](/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-independent-audit-_0v5svyw).
