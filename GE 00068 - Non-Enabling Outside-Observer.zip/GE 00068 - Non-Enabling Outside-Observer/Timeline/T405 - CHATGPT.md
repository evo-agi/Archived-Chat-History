## Assessment

The audit did **not** qualify, but it separated two different classes of issue:

| Class | Reported issue | Current status |
|---|---|---|
| Audit-capsule defect | Empty-directory logic incorrectly counted the root | Clearly audit-side |
| Audit-capsule defect | Contract-package reprojection injected a nonexistent `path` into `root_identity` | Clearly audit-side |
| Audit-capsule defect | Manifest faithfully retained `no_empty_directory:false`, preventing terminal audit closure | Consequence of the first defect |
| Possible subject-package defect | Documentary-validator registry contains nine roles while another governing record requires ten, omitting `confirmation-evidence-map-validator` | Plausible, but nonauthoritative until reconciled |
| Possible subject-package defect | A current executable validator writes into the supplied package, preventing a read-only independent replay | Plausible, but its actual CLI and role must be adjudicated |
| Possible subject-package defect | The preterminal correction record omits the failed operation, created files, superseded files, and superseding identities | Plausible evidence-lineage gap; acceptance effect not yet established |

The positive schema findings—15/15 metaschema validation, 14/14 witnesses in both directions, all 946 negative cases, all 137 regression cases, and field-map closure—are strong evidence, but they are still **report-only observations from a nonqualifying audit**.

We should neither repair the schema package nor rerun the full audit immediately. First perform one narrow, read-only reconciliation that:

1. proves the two audit-harness defects;
2. independently adjudicates the three claimed package defects;
3. determines the exact repair split;
4. freezes the corrected full-audit method.

If the validator-registry and correction-lineage findings are confirmed, the result will be a mixed repair: bounded package-evidence repair plus audit-harness repair, followed by a fresh full audit. If they are disproved, only the audit harness needs repair.

Forward this prompt to Codex:

```text
READ-ONLY RECONCILIATION OF THE NONQUALIFYING
CONSTRUCTION-PARENT SCHEMA-PACKAGE INDEPENDENT AUDIT —
AUDIT-CAPSULE DEFECTS VERSUS CLAIMED SUBJECT-PACKAGE DEFECTS

This task reconciles a nonqualifying independent audit.

It must separate:

A. defects in the independent-audit implementation or audit capsule; from

B. genuine defects in the supplied repaired schema package.

It does not:

- repair the schema package;
- repair or rerun the full independent audit;
- amend the normative contract;
- amend a schema;
- create or patch implementation source;
- execute process-self-test;
- execute construct mode;
- build a target-audit harness package;
- run a target audit;
- rerun runtime validation;
- modify a repository.

Do not modify, resume, clean, finish, or reseal any supplied root.
Do not promote any finding merely because it appears in the failed audit report.
Do not reinterpret the failed audit as ACCEPT or BLOCK.
Do not create subagents or direct auditors.
Do not run Git.
Do not use the network.
Do not invoke product or live-service behavior.
Do not deploy, publish, externally commit, or start A6.

Use one finite parent-owned diagnostic process. Retained files are
supplemental; return the complete substantive report inline.

Return exactly one primary verdict:

CONSTRUCTION_PARENT_SCHEMA_AUDIT_RECONCILED_AUDIT_DEFECT_ONLY
CONSTRUCTION_PARENT_SCHEMA_AUDIT_RECONCILED_MIXED_REPAIR_REQUIRED
CONSTRUCTION_PARENT_SCHEMA_AUDIT_RECONCILIATION_BLOCKED
RECONCILIATION_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. SUBJECT SCHEMA PACKAGE
──────────────────────────────────────────────────────────────────────────────

SUBJECT_SCHEMA_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-repair-pw27ydqf

Expected identity:

- device/inode:
  16777234 / 180513083
- mode:
  0700
- producer verdict:
  TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_SCHEMA_PACKAGE_REPAIRED

Expected normative contract:

contract/package-construction-parent-v1.json

- size:
  32038
- SHA-256:
  874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19

Expected temporal inventory:

closeout/temporal-final-inventory-v1.json

- size:
  15221
- SHA-256:
  e056edb02cfff4b8cfc5bf1cdded805fcc7386de68d6328c6d264b9365db5180

Expected terminal manifests:

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

- size:
  15314 each
- SHA-256:
  71a95eafce77a9cf41c2839e7020c0dead925e0cd1732a99692bdd0137810968
- byte-identical:
  required

Expected physical closure:

- total entries:
  65
- directories:
  10
- regular files:
  55
- empty directories:
  0
- symlinks:
  0
- special objects:
  0
- multiply linked regular files:
  0
- directory mode:
  0700
- regular-file mode:
  0600

Authenticate and independently reproduce the complete package closure.

The package remains nonaccepted pending a qualifying independent audit.

──────────────────────────────────────────────────────────────────────────────
2. FAILED INDEPENDENT AUDIT
──────────────────────────────────────────────────────────────────────────────

FAILED_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-independent-audit-_0v5svyw

Expected identity:

- device/inode:
  16777234 / 180525271
- mode:
  0700
- retained verdict:
  AUDIT_PROVENANCE_MISMATCH

Expected temporal inventory:

- represented entries:
  67
- SHA-256:
  c39ed5a3ee001e2e00306c318a41cea494d329d1bf724b7fa1a2b0ead3a6750b

Expected terminal manifests:

- size:
  16085 each
- SHA-256:
  22cce40cb2c543ab1b4295bdefdb8bb782c21a1b19e1eb9c40cb5feeeaa8deac
- byte-identical:
  required

Expected current physical tree:

- directories:
  12
- regular files:
  58
- actual empty directories:
  0
- symlinks:
  0
- special objects:
  0
- multiply linked files:
  0
- cache/bytecode:
  absent

Authenticate and independently reproduce the failed audit capsule.

The retained verdict remains:

AUDIT_PROVENANCE_MISMATCH

Do not reinterpret it.

──────────────────────────────────────────────────────────────────────────────
3. SUPPORTING CONTRACT AND RECONCILIATION ROOTS
──────────────────────────────────────────────────────────────────────────────

AUTHORITATIVE_CONTRACT_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-2y6tkl0n

Expected identity:

- device/inode:
  16777234 / 180472094
- mode:
  0700

SCHEMA_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-construction-parent-schema-reconciliation-5e2lsx8t

Expected identity:

- device/inode:
  16777234 / 180480821
- mode:
  0700

Open these only as needed to authenticate:

- normative-contract authority;
- schema-repair authority;
- expected validator roles;
- preterminal-attempt requirements.

Require complete opening/closing equality for every supplied root opened.

──────────────────────────────────────────────────────────────────────────────
4. FRESH DIAGNOSTIC ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask `077`, prefix:

ES-repair10i-v3-schema-audit-findings-reconciliation-

Immediately emit:

RECONCILIATION_ROOT=<absolute-path>

Retain before substantive inspection:

opening/bootstrap-start.json

Bind:

- fresh-root identity;
- supplied-root identities;
- read-only reconciliation authority;
- schema repair authorized:
  false;
- audit-harness repair authorized:
  false;
- implementation work authorized:
  false;
- target audit authorized:
  false;
- runtime validation rerun:
  false.

Create directories lazily.
Do not retain an empty directory.

──────────────────────────────────────────────────────────────────────────────
5. FAILED-AUDIT SOURCE AUTHORITY
──────────────────────────────────────────────────────────────────────────────

Identify every audit-owned source that generated or consumed:

- subject-package opening closure;
- authoritative-contract-package closure;
- empty-directory results;
- `root_identity` canonical comparison;
- terminal audit manifests;
- documentary-validator audit;
- preterminal-correction audit.

Identify source only through explicit provenance, process, result, temporal
inventory, manifest, or source-identity bindings.

Do not select source by:

- basename;
- sole-candidate status;
- content scoring;
- recency;
- first viable file;
- fallback.

Retain:

opening/failed-audit-source-registry-v1.json

For every source bind:

- role;
- path;
- size;
- SHA-256;
- mode/link count;
- producer;
- consumers;
- whether executed;
- current diagnostic eligibility.

If an indispensable source cannot be identified, return:

CONSTRUCTION_PARENT_SCHEMA_AUDIT_RECONCILIATION_BLOCKED

Do not invent the algorithm.

──────────────────────────────────────────────────────────────────────────────
6. AUDIT DEFECT A — EMPTY-DIRECTORY CALCULATION
──────────────────────────────────────────────────────────────────────────────

Reconstruct the exact empty-directory algorithm used for:

- the subject package;
- the reconciliation root;
- the audit capsule itself.

Retain:

analysis/empty-directory-audit-algorithm-v1.json

Crosswalk:

- physical traversal;
- root representation;
- descendant-directory representation;
- child counting;
- empty-directory classification;
- manifest metadata generation;
- terminal reprojection;
- confirmation generation.

Identify the exact source range and first incorrect predicate.

Independently calculate the actual empty-directory set for:

- subject schema package;
- authoritative contract package;
- schema reconciliation root;
- failed audit root.

Required test matrix includes:

1. Root with regular-file children.
2. Root with directory children.
3. Empty nonroot directory.
4. Nonempty nonroot directory.
5. Manifest root row represented.
6. Manifest root row omitted by grammar.
7. Root incorrectly treated as an ordinary candidate empty directory.
8. Reserved premanifest directory.
9. Terminal manifest directory containing A and B.
10. Empty directory after terminal manifest creation.

For every case retain expected and observed classification.

Determine whether:

- the root was included in the candidate empty-directory set;
- the root was assigned zero children incorrectly;
- `"."` was confused with an ordinary descendant;
- the manifest grammar and physical grammar were mixed;
- or another exact mechanism occurred.

Classify this separately from package quality.

──────────────────────────────────────────────────────────────────────────────
7. AUDIT DEFECT B — ROOT-IDENTITY CANONICALIZATION
──────────────────────────────────────────────────────────────────────────────

Reconstruct the authoritative-contract-package reprojection that reportedly
added a nonexistent `path` member to `root_identity`.

Retain:

analysis/root-identity-canonicalization-defect-v1.json

Authenticate:

- the authoritative package’s manifest grammar;
- the actual `root_identity` field set;
- the audit-generated comparison object;
- the injected `path` field;
- comparison result.

Determine:

- which function added `path`;
- whether it was schema-driven or hard-coded;
- whether the subject package used a different grammar;
- whether any supplied package actually contained that field;
- whether the failure was audit-tool-only.

Required mutations:

- exact valid root identity;
- valid identity plus unknown `path`;
- missing required root field;
- changed device/inode/mode;
- root path represented elsewhere;
- schema whose root identity legitimately includes path;
- schema whose root identity excludes path.

Do not change a supplied package to make the audit comparator pass.

──────────────────────────────────────────────────────────────────────────────
8. AUDIT-CAPSULE TERMINAL FAILURE
──────────────────────────────────────────────────────────────────────────────

Crosswalk:

- empty-directory result;
- audit manifest metadata;
- temporal inventory;
- manifest A/B;
- terminal reprojection;
- no-write-after-closure confirmation;
- primary verdict.

Retain:

analysis/audit-capsule-terminal-failure-v1.json

Answer:

1. Did the audit manifests faithfully seal the incorrect
   `no_empty_directory:false` result?
2. Did the physical audit root actually contain an empty directory?
3. Were A and B otherwise byte-identical and physically accurate?
4. Was the no-write-after-closure failure merely derivative of failed terminal
   closure?
5. Are any other terminal-audit-capsule defects present?
6. What exact audit-harness changes are required before a new full audit?

Do not reseal the failed audit.

──────────────────────────────────────────────────────────────────────────────
9. CLAIMED PACKAGE DEFECT A — DOCUMENTARY-VALIDATOR ROLE REGISTRY
──────────────────────────────────────────────────────────────────────────────

Locate and authenticate the exact current documentary-validator role registry.

Do not infer its path.

Retain:

analysis/documentary-validator-role-registry-adjudication-v1.json

Report:

- registry path;
- schema;
- size/SHA-256;
- exact declared roles;
- declared role count;
- minimum or exact required count;
- source of the required count;
- whether `confirmation-evidence-map-validator` is absent;
- whether another role or record performs that validation;
- whether the omission affects current package acceptance;
- whether the producer report incorrectly claimed ten roles;
- whether the registry itself claims completeness.

Identify the exact authority for requiring the role:

- normative contract;
- schema package task contract;
- generated-record family freeze;
- confirmation evidence map;
- validator registry schema;
- producer report only;
- or another exact source.

Distinguish:

- contract/schema semantic defect;
- package acceptance-evidence defect;
- report-only count mismatch;
- audit parser defect.

Do not treat the reconciliation prompt alone as hidden package truth; identify
the retained package or governing-task record that makes the requirement
acceptance-bearing.

──────────────────────────────────────────────────────────────────────────────
10. CLAIMED PACKAGE DEFECT B — EXECUTABLE VALIDATOR WRITE BEHAVIOR
──────────────────────────────────────────────────────────────────────────────

Identify the exact retained executable validator that the failed audit says
writes directly to the supplied package.

Retain:

analysis/documentary-validator-write-behavior-v1.json

Authenticate:

- source path and identity;
- declared validator role;
- CLI;
- cwd assumptions;
- input paths;
- output paths;
- default output behavior;
- hard-coded paths;
- whether an output path is a required CLI operand;
- whether it reads or writes the supplied package;
- whether it can be executed against a read-only subject while writing results
  exclusively into an audit-owned path;
- whether it imports or executes implementation or product code;
- whether replay is required for package acceptance.

Use source inspection first.

Do not execute it against the supplied package when it may write there.

When safe and necessary, copy the exact source into an audit-owned fixture and
run it only against audit-owned copies or with an audit-owned result path.

Classify as exactly one:

- package validator design defect;
- package evidence/replay defect;
- independent-audit invocation defect;
- documentation-only limitation;
- evidence insufficient.

Answer whether the validator’s retained historical result remains
byte-authenticated even if fresh read-only replay is impossible.

──────────────────────────────────────────────────────────────────────────────
11. CLAIMED PACKAGE DEFECT C — PRETERMINAL CORRECTION RECORD
──────────────────────────────────────────────────────────────────────────────

Authenticate:

validation/preterminal-finalizer-correction-v1.json

and every record it cites.

Retain:

analysis/preterminal-correction-lineage-adjudication-v1.json

Crosswalk:

- exact failed attempt;
- exact failed operation;
- exception or category error;
- files created before failure;
- files partially written;
- current-role paths occupied;
- files removed;
- files superseded;
- superseding result paths;
- superseding result identities;
- effect on contract bytes;
- effect on schema bytes;
- effect on validator counts;
- effect on package verdict;
- effect on terminal inventory and manifests.

Determine whether the four fields reported absent by the failed audit are:

1. normatively required;
2. schema-required;
3. task acceptance requirements;
4. indispensable to prove no stale authority;
5. reconstructable from other authenticated package evidence;
6. merely desirable hardening.

Search only the supplied package and explicitly bound historical inputs.

Do not use filename or chronology alone as authority.

Classify as exactly one:

- acceptance-affecting package provenance defect;
- bounded package evidence gap;
- report-only incompleteness;
- audit overreach;
- evidence insufficient.

If reconstructable, retain the exact authoritative reconstruction, but do not
repair the package.

──────────────────────────────────────────────────────────────────────────────
12. PACKAGE CURRENT-ROLE OCCUPANCY
──────────────────────────────────────────────────────────────────────────────

Independently enumerate every current authoritative or acceptance-bearing role
in the subject package.

Retain:

analysis/current-role-occupancy-v1.json

For every role bind:

- role ID;
- current path;
- identity;
- producer;
- governing record;
- current status;
- historical competing paths;
- duplicate or ambiguity count.

Specifically determine whether any failed or preterminal artifact remains at a
current role path or contributes to:

- current schema identity;
- current validator result;
- current pass count;
- current confirmation;
- current package verdict;
- terminal inventory;
- manifest membership.

This adjudication is required before deciding whether the incomplete
correction record is acceptance-affecting.

──────────────────────────────────────────────────────────────────────────────
13. DEPENDENCY AND PROPAGATION GRAPH
──────────────────────────────────────────────────────────────────────────────

Create:

analysis/audit-and-package-finding-dependency-graph-v1.json

Include nodes for:

- root-empty audit defect;
- root-identity audit defect;
- audit terminal-closure failure;
- documentary-validator registry claim;
- validator-write claim;
- preterminal-correction claim;
- producer report statements;
- subject package authority;
- failed audit verdict.

Classify edges as:

- causes;
- propagates;
- duplicates;
- shared evidence;
- independent;
- derivative.

Separate:

- primary audit defects;
- primary package defects, if any;
- derivative audit failures;
- report-only discrepancies.

──────────────────────────────────────────────────────────────────────────────
14. COUNTERFACTUAL AND MUTATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Retain:

validation/schema-audit-findings-reconciliation-matrix-v1.json

Cover at minimum:

Audit closure:

1. Root excluded from empty-descendant calculation.
2. Root included as an ordinary directory.
3. Actual empty descendant.
4. Root identity exact.
5. Unknown `path` added to root identity.
6. No-empty result true with no empty descendant.
7. No-empty result false with no empty descendant.
8. Manifest faithfully sealing a false audit result.
9. Confirmation derived from terminal closure.
10. Confirmation asserted despite terminal failure.

Validator registry:

11. Exact ten-role registry.
12. Nine-role registry missing confirmation validator.
13. Missing role supplied by another current role.
14. Duplicate validator role.
15. Declared count inconsistent with rows.
16. Report says ten while registry has nine.
17. Confirmation map exists but has no current validator owner.

Validator replay:

18. Validator writes hard-coded supplied-root output.
19. Validator accepts audit-owned `--result`.
20. Validator default writes subject but explicit result redirects safely.
21. Validator mutates input beyond result output.
22. Historical result valid but fresh replay impossible.
23. Read-only replay not contractually required.

Preterminal correction:

24. Complete correction lineage.
25. Missing failed operation.
26. Missing created-path list.
27. Missing superseded-path list.
28. Missing superseding identities.
29. Missing fields reconstructed unambiguously elsewhere.
30. Stale failed artifact at current role.
31. No stale artifact and all current identities independently bound.
32. Failed result included in current pass count.
33. Failed result excluded from current pass count.

Require:

- exact unique names;
- complete expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip.

──────────────────────────────────────────────────────────────────────────────
15. ROOT-CAUSE AND REPAIR CLASSIFICATION
──────────────────────────────────────────────────────────────────────────────

For each finding classify:

AUDIT_HARNESS_DEFECT
PACKAGE_CONTRACT_OR_SCHEMA_DEFECT
PACKAGE_ACCEPTANCE_EVIDENCE_DEFECT
PACKAGE_REPORT_ONLY_DEFECT
INDEPENDENT_AUDIT_INVOCATION_DEFECT
DERIVATIVE_FAILURE
EVIDENCE_INSUFFICIENT

Then classify the overall reconciliation:

A. `AUDIT_DEFECT_ONLY`

Use only when all claimed package defects are disproved or non-acceptance
hardening.

B. `MIXED_REPAIR_REQUIRED`

Use when at least one acceptance-affecting package defect is confirmed in
addition to the audit defects.

C. `RECONCILIATION_BLOCKED`

Use when indispensable evidence is missing or authority remains ambiguous.

Do not classify the subject package as accepted.

──────────────────────────────────────────────────────────────────────────────
16. MINIMAL NEXT TRANCHE
──────────────────────────────────────────────────────────────────────────────

Do not implement it.

If `AUDIT_DEFECT_ONLY`, specify an exact audit-harness repair that:

- excludes the physical root from descendant-empty checks;
- uses each manifest grammar’s exact root-identity shape;
- independently tests root and empty-directory handling;
- reruns the full schema-package audit in a fresh root;
- preserves the subject package unchanged.

If `MIXED_REPAIR_REQUIRED`, specify two separate bounded repairs:

1. Subject schema-package evidence repair:
   - exact affected files only;
   - normative contract unchanged unless independently proven necessary;
   - schemas unchanged unless independently proven necessary;
   - no implementation;
   - fresh terminal package root.

2. Independent-audit harness repair:
   - exact audit algorithms and tests;
   - fresh frozen audit source;
   - fresh full audit only after the package repair closes.

State integration order explicitly.

Do not combine package repair and audit-harness repair into one authority
surface.

──────────────────────────────────────────────────────────────────────────────
17. NO REPAIR OR RETRY
──────────────────────────────────────────────────────────────────────────────

Do not:

- repair the subject package;
- repair the failed audit;
- rerun the full audit;
- write a replacement validator registry;
- rewrite the preterminal correction record;
- patch a validator;
- create implementation source;
- run process-self-test;
- run construct mode;
- build a harness package;
- run a target audit.

This task ends with causal and authority adjudication.

──────────────────────────────────────────────────────────────────────────────
18. SUPPLIED-ROOT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete lstat/no-follow inventories for every supplied root opened.

Require exact opening/closing equality.

Do not modify or clean supplied roots.

For every audit-owned fixture or cache root:

- retain complete pre-removal inventory;
- remove exact root;
- observe ENOENT twice;
- require zero process and descriptor survivors.

──────────────────────────────────────────────────────────────────────────────
19. DIAGNOSTIC CAPSULE CLOSURE
──────────────────────────────────────────────────────────────────────────────

Retain:

- bootstrap start;
- source registry;
- fixed-input authentication;
- audit-defect analyses;
- package-finding analyses;
- role occupancy;
- dependency graph;
- mutation matrix;
- supplied-root equality;
- final inline-equivalent report;
- explicit confirmations;
- final diagnostic inventory.

Terminal manifests are optional.

If terminal manifests are created:

- they must faithfully represent the diagnostic capsule;
- root handling must use the corrected algorithm;
- no false success caption may be written;
- no write may occur after closure.

──────────────────────────────────────────────────────────────────────────────
20. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

CONSTRUCTION_PARENT_SCHEMA_AUDIT_RECONCILED_AUDIT_DEFECT_ONLY

only when:

- both audit-harness defects are independently proved;
- no actual empty directory exists in the subject or audit root;
- root-identity comparison failure is tool-only;
- documentary-validator registry is contractually sufficient or its mismatch
  is non-acceptance report-only;
- validator replay limitation is an audit invocation issue or nonrequired
  hardening;
- preterminal correction evidence is sufficient under the actual package
  authority model;
- no acceptance-affecting package defect is confirmed.

Return:

CONSTRUCTION_PARENT_SCHEMA_AUDIT_RECONCILED_MIXED_REPAIR_REQUIRED

when:

- the audit-harness defects are proved; and
- one or more acceptance-affecting package evidence or validator defects are
  independently confirmed.

Return:

CONSTRUCTION_PARENT_SCHEMA_AUDIT_RECONCILIATION_BLOCKED

when indispensable source, contract, lineage, or role evidence is unavailable.

Return:

RECONCILIATION_PROVENANCE_MISMATCH

for:

- supplied-root mutation;
- opening/closing inequality;
- fixed identity mismatch;
- unaccounted diagnostic process effect;
- cleanup-set inequality;
- diagnostic-capsule closure failure when terminal closure is attempted.

──────────────────────────────────────────────────────────────────────────────
21. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh diagnostic-root identity
3. Subject package identity and closure
4. Failed audit identity and closure
5. Supporting root identities
6. Failed-audit source registry
7. Empty-directory audit algorithm
8. Exact root-empty first failure
9. Correct physical empty-directory results
10. Root-identity canonicalization algorithm
11. Exact injected-root-field failure
12. Audit-capsule terminal-failure dependency
13. Documentary-validator registry identity
14. Exact validator role list and count
15. Authority for required validator count
16. Confirmation-evidence-map-validator disposition
17. Executable validator source identity
18. Executable validator CLI and write behavior
19. Validator replay classification
20. Preterminal correction-record identity
21. Exact missing correction fields
22. Reconstructed failed-attempt lineage
23. Current-role occupancy
24. Preterminal correction classification
25. Dependency graph
26. Mutation matrix
27. Per-finding classifications
28. Overall repair classification
29. Exact minimal next tranche
30. Supplied-root closing equality
31. Fixture/cache cleanup
32. Remaining uncertainty and nonclaims
33. Explicit confirmations

Required confirmations:

SUBJECT_SCHEMA_PACKAGE_MUTATION_NOT_PERFORMED
FAILED_SCHEMA_AUDIT_ROOT_MUTATION_NOT_PERFORMED
AUTHORITATIVE_CONTRACT_PACKAGE_MUTATION_NOT_PERFORMED
SCHEMA_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
SUBJECT_PACKAGE_PHYSICAL_CLOSURE_REPROJECTED
FAILED_AUDIT_PHYSICAL_CLOSURE_REPROJECTED
FAILED_AUDIT_SOURCE_REGISTRY_COMPLETE
ROOT_EMPTY_DIRECTORY_DEFECT_CROSSWALKED
ROOT_NOT_ACTUALLY_EMPTY
NO_ACTUAL_EMPTY_DIRECTORY_IN_SUBJECT_PACKAGE
NO_ACTUAL_EMPTY_DIRECTORY_IN_FAILED_AUDIT_ROOT
ROOT_IDENTITY_CANONICALIZATION_DEFECT_CROSSWALKED
NONEXISTENT_ROOT_IDENTITY_PATH_FIELD_IDENTIFIED
AUDIT_CAPSULE_TERMINAL_FAILURE_CROSSWALKED
DOCUMENTARY_VALIDATOR_REGISTRY_AUTHENTICATED
DOCUMENTARY_VALIDATOR_ROLE_COUNT_ADJUDICATED
CONFIRMATION_EVIDENCE_MAP_VALIDATOR_ADJUDICATED
EXECUTABLE_VALIDATOR_WRITE_BEHAVIOR_ADJUDICATED
VALIDATOR_REPLAY_REQUIREMENT_ADJUDICATED
PRETERMINAL_CORRECTION_RECORD_AUTHENTICATED
PRETERMINAL_CORRECTION_LINEAGE_ADJUDICATED
CURRENT_ROLE_OCCUPANCY_COMPLETE
NO_FAILED_ARTIFACT_SILENTLY_PROMOTED
AUDIT_AND_PACKAGE_FINDINGS_SEPARATED
DEPENDENCY_GRAPH_COMPLETED
RECONCILIATION_MUTATION_MATRIX_PASSED
NO_PACKAGE_REPAIR_PERFORMED
NO_AUDIT_RETRY_PERFORMED
NO_IMPLEMENTATION_CREATED
PROCESS_SELF_TEST_NOT_EXECUTED
CONSTRUCT_MODE_NOT_EXECUTED
NO_HARNESS_PACKAGE_CONSTRUCTED
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

Do not authorize implementation until the package defects, if any, are repaired
and a fresh corrected independent audit accepts the resulting schema package.
```

## Decision

Run the focused reconciliation above. Do not repair the package or rerun the full audit yet.

**Source:** Codex’s `AUDIT_PROVENANCE_MISMATCH` report in the current turn.  
**Confidence:** 1.00 that the independent audit is nonqualifying; 0.99 that its terminal failure is audit-side; 0.78 that at least one of the validator-registry or correction-lineage findings will prove acceptance-affecting.
