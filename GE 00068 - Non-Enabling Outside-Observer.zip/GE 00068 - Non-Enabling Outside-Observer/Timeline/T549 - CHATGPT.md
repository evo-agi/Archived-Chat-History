## Engineering assessment

The sealed verdict is correctly `AUDIT_PROVENANCE_MISMATCH`. It does **not** establish a defect in the replacement subject.

The replacement subject itself passed every independently completed structural and semantic lane before the audit logic failed:

- terminal physical closure and manifest reprojection;
- normative-contract identity and posture;
- 15 current schema roles and 14 generated families;
- exact role/family mapping;
- Draft 2020-12 validation for all 15 schemas;
- both sets of 14 witnesses;
- the 766/333 field map;
- documentary-validator role and identity closure;
- lineage, supersession, and producer nonauthority posture. :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"}

The failed 946- and 137-case results are demonstrably **audit-oracle defects**:

- The 946 evaluators produced 226 and 228 nonpassing rows, raised exceptions while iterating deliberately mistyped `null` values, and disagreed on ordinals 203 and 900. These are failures of total case evaluation and documentary-check handling, not qualified subject findings. :chatgpt-content-reference{index="2"}
- The 137 evaluator projected almost every successful semantic predicate to the single result `ACCEPT_ALL_14`, ignoring the governed outcome vocabulary such as `REJECT_EMPTY_EXPORTS`, `REJECT_SCHEMA`, `ABSENT`, and `DETECTED`. :chatgpt-content-reference{index="3"}
- The occupancy check invented `validator:<role>` identifiers while the current registry uses `documentary-validator:<role>`. :chatgpt-content-reference{index="4"}
- The 15 false confirmations were derivative from the invalid 946/137 results, not independent blockers. :chatgpt-content-reference{index="5"}
- The capsule’s explicit-confirmation projection was hard-coded to all true despite its own retained evidence. :chatgpt-content-reference{index="6"}

The audit capsule also failed terminal authority for a separate audit-lifecycle reason. Its physical-empty-directory check treated `manifest/` and `terminal/` as empty because reserved files were excluded from the manifest projection. This made `closure_pass=false`, even though A15 was recorded as passed. That is a namespace/projection and phase-status defect in the audit capsule, not subject drift. :chatgpt-content-reference{index="7"}

### Current classification

- **Replacement subject:** unchanged, producer-qualified, terminally closed, pending independent audit.
- **Subject-package defects:** none established.
- **Independent audit generation:** nonqualifying and retired.
- **Required repair owner:** `INDEPENDENT_AUDIT_ORACLE` and `INDEPENDENT_AUDIT_EVIDENCE_PROJECTION`.
- **Subject reconstruction:** not required.
- **Subject reuse:** required; audit the unchanged replacement subject.
- **Another findings reconciliation:** not required and should not be started.

The report itself reaches the same substantive conclusion: the five supposed subject blockers are nonoperative because their causes are audit-oracle and projection defects, and the exact subject’s acceptability remains unadjudicated. :chatgpt-content-reference{index="8"}

## Progression decision

Build and run one **new clean independent-audit generation** against the unchanged replacement subject.

Do not patch or reuse the failed audit source. Preserve its capsule only as a regression corpus. The next audit must qualify its actual production oracles against the exact failures exposed here before it receives authority to inspect the real subject.

---

## Complete replacement Codex prompt

```text
IMPLEMENT AND EXECUTE ONE NEW CLEAN SOURCE-EXTERNAL INDEPENDENT AUDIT
OF THE UNCHANGED REPLACEMENT GENERATION-2 SCHEMA SUBJECT

RETIRE THE NONQUALIFYING AUDIT ORACLES AND TERMINAL-CAPSULE PROJECTION

Objective

Independently audit the unchanged replacement schema subject:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-z1o1vs54

The immediately preceding independent audit returned:

AUDIT_PROVENANCE_MISMATCH

It did not establish a subject-package blocker.

Its exact demonstrated audit defects were:

1. the 946-case oracles were not total over deliberately invalid JSON shapes;
2. documentary checks iterated deliberately mistyped null values;
3. the two 946 oracles disagreed on exact cases;
4. the 137 evaluator collapsed governed outcome vocabularies into
   `ACCEPT_ALL_14`;
5. current-role occupancy used `validator:<role>` while the authenticated
   registry uses `documentary-validator:<role>`;
6. derivative confirmation failures were projected from invalid audit results;
7. explicit confirmations were hard-coded to true;
8. supposed subject findings were assigned subject ownership despite audit
   causals;
9. physical directory emptiness was derived from a self-excluding manifest
   projection, falsely classifying reserved `manifest/` and `terminal/`
   directories as empty;
10. phase A15 reported passed while terminal `closure_pass` was false.

Implement a new clean independent-audit generation.

Do not patch, copy, import, translate, execute, decompile, disassemble into
source, or use as an AST, bytecode, fixture, expected-result, normalization, or
projection origin:

- the failed independent-audit source;
- its primary oracle;
- its secondary oracle;
- its qualification runner;
- its static qualifier;
- the historical blocked-subject audit source;
- the historical findings-reconciliation source;
- the reconstruction-parent source;
- producer validator helpers;
- producer fixture generators;
- producer expected-result maps;
- producer report or confirmation projectors.

The failed audit capsule may be opened read-only only as an authenticated
regression corpus.

Do not mutate, repair, clean, relocate, chmod, or reseal the replacement subject.

Do not rerun construction.

Do not promote or rebind current schema authority.

Do not combine audit with authority promotion.

Do not execute product or live-service behavior.

Do not run target audit.

Do not rerun product runtime validation.

Do not modify a repository.

Do not use Git or another VCS.

Do not read `.git`.

Do not use the network.

Do not install dependencies.

Do not publish, deploy, externally commit, or begin A6.

Do not create subagents or direct auditors.

Use one finite qualification and audit parent in one fresh private root.

Return the complete operative report inline.

Return exactly one primary verdict:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_ACCEPT

GEN2_REPLACEMENT_SCHEMA_SUBJECT_BLOCK

AUDIT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. REPLACEMENT SUBJECT
──────────────────────────────────────────────────────────────────────────────

REPLACEMENT_SUBJECT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-z1o1vs54

Expected root identity:

- device:
  16777234
- inode:
  182649818
- mode:
  0700
- UID:
  501
- GID:
  20

Expected physical closure:

- total entries including root:
  73;
- directories:
  12;
- regular files:
  61;
- root row:
  exactly one;
- empty descendants:
  0;
- symlinks:
  0;
- special objects:
  0;
- multiply linked regular files:
  0;
- directory mode:
  0700;
- file mode:
  0600;
- cache/bytecode:
  absent.

Expected temporal record:

closeout/temporal-final-inventory-v1.json

- size:
  16051
- SHA-256:
  905a21d0ec24be5caf8b29ac0e29419833dc19b7b309f60afdb2ad215a1866b4

Expected manifest A:

manifest/canonical-manifest-a-v1.json

- size:
  16620
- SHA-256:
  5f22e7e1405afd0378ff2e054f7b436d4b00172a300a97a5676880a9d7196758

Expected manifest B:

manifest/canonical-manifest-b-v1.json

- size:
  16620
- SHA-256:
  5f22e7e1405afd0378ff2e054f7b436d4b00172a300a97a5676880a9d7196758

Open only this exact root.

Do not scan for another subject.

Do not select by prefix, recency, basename, hash search, inode search, score,
similarity, or first match.

──────────────────────────────────────────────────────────────────────────────
2. REPLACEMENT CONSTRUCTION WRAPPER
──────────────────────────────────────────────── LIMITED TO PROVENANCE
────────────────────────────────────────────────

REPLACEMENT_CONSTRUCTION_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-replacement-schema-subject-construction-wrapper-v3-ewh59_5a

Expected root identity:

- device:
  16777234
- inode:
  182648782
- mode:
  0700
- UID:
  501
- GID:
  0

Expected operative report:

report/final-operative-report-v1.json

Resolve its exact identity through the wrapper’s terminal result and retained
registry.

Authenticate:

- forward-treatment directive;
- historical-subject preservation;
- historical-audit preservation;
- failed-reconciliation exclusion;
- accepted source-freeze semantic resolution;
- accepted implementation authority;
- one-shot construction authorization and consumption;
- exact production-parent invocation;
- platform and process custody;
- exact subject-root locator;
- fresh allocation and nonadoption;
- wrapper input closing equality;
- no second construction;
- no independent audit during construction.

Do not use wrapper prose as subject-semantic authority.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
3. ACCEPTED IMPLEMENTATION AUTHORITY
──────────────────────────────────────────────── LIMITED TO CHAIN AUTHENTICATION
────────────────────────────────────────────────

ACCEPTED_IMPLEMENTATION_AUDIT_ROOT:

/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-mp6hex04

Expected identity:

- device:
  16777234
- inode:
  182593190
- mode:
  0700

ACCEPTED_IMPLEMENTATION_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-wrapper-se4f_xxg

Expected identity:

- device:
  16777234
- inode:
  182593189
- mode:
  0700

Expected accepted disposition:

GEN2_IMPLEMENTATION_PACKAGE_ACCEPT

Authenticate only the current chain needed to establish:

- accepted reconstruction-parent implementation;
- accepted production source;
- accepted semantic source-freeze role;
- accepted construction contract;
- implementation package remained unsuperseded;
- the replacement wrapper used the accepted parent.

Do not re-audit the implementation package.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
4. CURRENT CONTENT AUTHORITY
────────────────────────────────────────────────

CURRENT_CONTENT_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected identity:

- device:
  16777234
- inode:
  181651092
- mode:
  0400
- link count:
  1
- size:
  13598758
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671

CURRENT_CONTENT_AUTHORITY:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected identity:

- device:
  16777234
- inode:
  181651098
- mode:
  0400
- link count:
  1
- size:
  19737
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563

Authenticate the content authority before the ZIP.

Require:

- 479 members;
- eight current roles;
- seven content roles;
- one bounded failure-evidence role;
- deterministic archive equality;
- independent archive validation;
- no `.DS_Store`.

Use exact current roles to resolve:

- normative contract;
- current schemas;
- schema-role registry;
- family authority;
- 946-case specification;
- 137-case specification;
- 766/333 field-map authority;
- documentary-validator specifications;
- confirmation-evidence specifications.

The containing directory is nonauthoritative.

──────────────────────────────────────────────────────────────────────────────
5. NONQUALIFYING AUDIT REGRESSION CAPSULE
──────────────────────────────────────────────── LIMITED TO TEST REQUIREMENTS
────────────────────────────────────────────────

FAILED_AUDIT_ROOT:

/private/tmp/ES-repair10i-v3-replacement-schema-subject-independent-audit-qz6fkiej

Expected root identity:

- device:
  16777234
- inode:
  182663988
- mode:
  0700
- UID:
  501
- GID:
  0

Expected historical verdict:

AUDIT_PROVENANCE_MISMATCH

Authenticate read-only:

- root identity;
- retained temporal and manifest identities;
- terminal result;
- one seal transition;
- no postseal operation;
- historical nonqualifying disposition.

Resolve exact retained regression artifacts:

validation/primary-negative-946-v1.json
validation/secondary-negative-946-v1.json
validation/primary-contradiction-137-v1.json
validation/secondary-contradiction-137-v1.json
validation/dual-oracle-crosswalk-v1.json
opening/historical-audit-regression-requirements-v1.json
terminal/terminal-result.json

Use them only to define regression tests.

Do not execute or copy any source under the failed audit root.

Do not adopt any finding ownership or subject-blocker classification from this
capsule.

Classify:

HISTORICAL_NONQUALIFYING_AUDIT_ORACLE_AND_TERMINAL_PROJECTION_FAILURE

Require opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
6. FRESH AUDIT ROOT
────────────────────────────────────────────────

Allocate one fresh private root beneath `/private/tmp` using:

- tempfile.mkdtemp;
- umask:
  077;
- prefix:

ES-repair10i-v3-replacement-schema-subject-independent-audit-v2-

Immediately emit:

SUBJECT_AUDIT_ROOT=<absolute-path>

Before source creation retain:

opening/bootstrap-start.json
opening/audit-authority-v2.json
opening/fixed-input-registry-v1.json
opening/subject-opening-inventory-v1.json
opening/process-execution-policy-v1.json
opening/audit-source-authority-v2.json
opening/nonqualifying-audit-regression-registry-v1.json

Audit authority is limited to:

- fixed-input authentication;
- read-only subject inspection;
- independent semantic validation;
- exact finding ownership;
- audit-owned fixture cleanup;
- supplied-input closing equality;
- audit-capsule terminal closure.

Nonauthority includes:

- subject mutation or repair;
- subject reconstruction;
- authority promotion or rebinding;
- product/runtime/target/repository activity;
- publication/deployment/A6.

──────────────────────────────────────────────────────────────────────────────
7. CLEAN AUDIT-SOURCE AUTHORITY
────────────────────────────────────────────────

Create entirely new audit source inside the fresh audit root.

Forbidden source origins:

- failed audit source;
- failed primary oracle;
- failed secondary oracle;
- failed qualification runner;
- failed static qualifier;
- historical subject-audit source;
- historical reconciliation source;
- producer reconstruction source;
- producer validators;
- producer fixtures;
- producer expected maps;
- producer or historical projectors/normalizers;
- transcript-reconstructed source;
- decompiled/disassembled source;
- similarity-derived source.

The new source may use:

- governing contract and specification bytes;
- replacement subject bytes;
- current content authority;
- authenticated historical failure rows solely as regression fixtures;
- this task’s contracts.

Retain:

opening/clean-audit-source-authority-v1.json
opening/clean-audit-source-layout-v1.json

Require every source role mapped exactly once.

At minimum define clean roles for:

- finite audit parent;
- strict JSON;
- no-follow inventory;
- manifest reprojector;
- Draft 2020-12 adapter;
- contract witness constructor;
- schema witness constructor;
- primary 946 evaluator;
- secondary 946 evaluator;
- primary 137 evaluator;
- secondary 137 evaluator;
- governed-outcome vocabulary resolver;
- documentary semantic checker;
- field-map resolver;
- documentary-validator adjudicator;
- confirmation derivation;
- occupancy/lineage adjudicator;
- finding owner;
- cleanup owner;
- input-equality owner;
- terminal capsule owner;
- independent qualification validators.

──────────────────────────────────────────────────────────────────────────────
8. GOVERNED OUTCOME VOCABULARY
────────────────────────────────────────────────

Before implementing evaluators retain:

contract/governed-case-outcome-vocabulary-v1.json

Derive the exact outcome vocabulary from the current 946 and 137 case
specifications.

For every governed case type retain:

- case family;
- expected acceptance posture;
- exact expected outcome token;
- exact reason class;
- controlling pointer;
- controlling schema keyword where applicable;
- documentary checks required;
- absent/null/wrong-type behavior.

Do not collapse outcomes into:

- ACCEPT_ALL_14;
- generic ACCEPT;
- generic REJECT;
- Python truthiness;
- exception presence.

Every evaluator must return one exact governed outcome or an explicit audit
execution error.

An audit execution error forces `AUDIT_PROVENANCE_MISMATCH`; it is not a subject
case failure.

──────────────────────────────────────────────────────────────────────────────
9. TOTAL DOCUMENTARY CHECKING
────────────────────────────────────────────────

Retain:

contract/total-documentary-checking-v1.json

Every documentary check must be total over:

- missing value;
- explicit null;
- Boolean;
- integer;
- string;
- array;
- object;
- malformed object members.

No acceptance-bearing checker may:

- iterate without type validation;
- index without shape validation;
- use `.get` on an unverified object;
- treat an exception as governed rejection;
- treat absence as success;
- conflate Boolean false with missing;
- conflate integer zero with false.

Required exact regressions include:

- historical 946 exception ordinals:
  80,
  98,
  102,
  110,
  204,
  518;

- ordinal 203:
  `required-remove:executable-origin-registry:/entries`;

- ordinal 900:
  `under-enforcement:cleanup-pass-with-set-mismatch`.

For every regression require:

- no uncaught exception;
- exact governed outcome;
- exact reason;
- exact direct evidence.

──────────────────────────────────────────────────────────────────────────────
10. DUAL-ORACLE INDEPENDENCE
────────────────────────────────────────────────

Retain:

contract/dual-oracle-audit-contract-v2.json

Primary and secondary oracles may share only:

- immutable input bytes;
- authenticated `jsonschema` library;
- frozen outcome-vocabulary contract.

They must not share:

- mutation application code;
- case-shape interpretation;
- documentary-check helpers;
- reason classifiers;
- error normalizers;
- result aggregators;
- expected-result maps;
- fixture constructors.

Require independent source registries.

For every case, crosswalk:

- expected outcome;
- primary outcome/reason;
- secondary outcome/reason;
- exact error evidence;
- agreement.

Any unexplained disagreement forces:

AUDIT_PROVENANCE_MISMATCH

It must not become a subject blocker.

──────────────────────────────────────────────────────────────────────────────
11. OCCUPANCY AND ROLE-ID NORMALIZATION
────────────────────────────────────────────────

Retain:

contract/current-role-occupancy-vocabulary-v1.json

Use exact role IDs from the authenticated current registries.

For documentary validators, preserve the governed role form:

documentary-validator:<role>

Do not invent:

validator:<role>

Do not normalize semantic prefixes unless the governing registry explicitly
defines the normalization.

Occupancy closure is exact set equality among authenticated current role rows.

Unknown, missing, duplicate, or differently prefixed roles must have exact
evidence and classification.

──────────────────────────────────────────────────────────────────────────────
12. EVIDENCE-DERIVED CONFIRMATIONS
────────────────────────────────────────────────

Retain:

contract/evidence-derived-confirmation-v1.json

Every confirmation row contains:

- name;
- evidence path;
- JSON pointer;
- expected value;
- observed value;
- pass;
- direct/derivative classification;
- dependencies.

No confirmation value may be hard-coded.

No absence-as-success.

No global all-true projection.

A false confirmation caused solely by another direct failed domain is:

DERIVATIVE_CONFIRMATION_FAILURE

It is not an additional direct subject blocker.

The final confirmation registry is generated from exact derived rows.

──────────────────────────────────────────────────────────────────────────────
13. PHYSICAL EMPTY-DIRECTORY AND CLOSURE MODEL
────────────────────────────────────────────────

Retain:

contract/audit-capsule-physical-closure-v1.json

Physical directory emptiness must be computed from the complete physical
terminal namespace.

It must not be computed from:

- self-excluding temporal projection;
- self-excluding manifest projection;
- a projection that omits reserved terminal files.

Before temporal or manifest projection:

- create every final directory;
- reserve temporal, both manifest, and terminal-result files;
- retain descriptors;
- freeze namespace.

Reserved files count as physical children even when excluded from a projection.

Require separately:

- physical no-empty-descendant result;
- temporal projection result;
- manifest projection result;
- final whole-root reprojection.

`manifest/` and `terminal/` must not be considered empty when their physical
reserved files exist.

A15 status must derive from the final `closure_pass` value.

A15 cannot be passed when `closure_pass=false`.

──────────────────────────────────────────────── LIMITED TO REGRESSIONS
────────────────────────────────────────────────

14. AUDIT-LOGIC QUALIFICATION

Before the real audit, run audit-owned fixtures covering at minimum:

A. 946 regressions

- all historical nonpassing ordinals;
- all six historical null-iteration exceptions;
- ordinals 203 and 900;
- wrong-type, absent, null, Boolean, integer, string, array, and object inputs;
- outcome-versus-reason mismatch;
- exact current valid baseline.

B. 137 regressions

- all 137 governed outcome tokens;
- exact baseline;
- every historical ordinal 2–137;
- explicit rejection of `ACCEPT_ALL_14` collapse;
- exact outcome-token equality.

C. Occupancy regressions

- exact `documentary-validator:<role>` baseline;
- invented `validator:<role>`;
- missing prefix;
- duplicate role;
- historical role current;
- failed role current.

D. Confirmation regressions

- exact evidence-derived baseline;
- hard-coded all true;
- absence-as-success;
- derivative false row;
- independent direct false row;
- stale evidence;
- circular dependency.

E. Terminal-closure regressions

- physical reserved manifest and terminal files;
- projection-excluded reserved files;
- genuinely empty directory;
- missing reserved file;
- A15 passed with closure false;
- closure true baseline;
- operation after seal.

Require:

- uniquely named cases;
- expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception;
- zero oracle disagreement.

Retain:

validation/clean-audit-logic-qualification-v1.json

Remove fixtures only after evidence retention.

Require double ENOENT and exact cleanup-set equality.

──────────────────────────────────────────────── LIMITED TO SOURCE
────────────────────────────────────────────────

15. SOURCE COMPILATION, STATIC GATES, AND FREEZE

Compile all source with pinned Python:

-I -S -B

Retain complete process custody.

Run source-external:

- AST;
- call graph;
- dataflow;
- import-origin;
- exception paths;
- process effects;
- filesystem effects;
- input-boundary analysis;
- oracle independence;
- confirmation derivation;
- occupancy vocabulary use;
- physical-closure logic;
- terminal-operation analysis.

Require:

- no forbidden source origin;
- no producer/historical audit imports;
- total documentary checking;
- no exception-as-outcome;
- exact governed vocabulary use;
- no hard-coded confirmation success;
- exact occupancy role IDs;
- physical emptiness independent of projections;
- A15 derived from closure pass;
- no network;
- no Git;
- no shell;
- no broad scan;
- no postseal operation.

Retain:

validation/clean-audit-static-qualification-v1.json

Freeze every source after all qualification gates pass.

Retain:

opening/clean-audit-source-freeze-v1.json

Reopen no-follow and require identity equality.

Do not modify afterward.

──────────────────────────────────────────────── LIMITED TO REAL SUBJECT
────────────────────────────────────────────────

16. SUBJECT TERMINAL-CLOSURE AUTHENTICATION

Authenticate:

- root identity;
- temporal record;
- manifest A;
- manifest B;
- A/B equality;
- manifest grammar;
- exclusions;
- represented path set;
- physical path set;
- every represented file’s bytes;
- governed metadata;
- no-follow whole-root reprojection;
- root row once;
- topology/modes;
- cache/bytecode absence.

Require current physical closure equal both manifests.

Any subject drift forces:

AUDIT_PROVENANCE_MISMATCH

Do not reinterpret drift as semantic BLOCK.

────────────────────────────────────────────────

17. NORMATIVE CONTRACT, SCHEMAS, AND FAMILIES

Authenticate the normative contract:

- size:
  32038;
- SHA-256:
  874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19.

Require:

- strict JSON;
- duplicate-key rejection;
- nonfinite rejection;
- sole normative-writer posture;
- implementation-present/authority posture.

Independently reconstruct:

- exactly 15 current schema roles;
- unique paths and `$id` values;
- current/nonhistorical rows;
- exactly 14 generated families;
- normative authority pointers;
- exact role/family mapping;
- normative parent solely unmapped;
- no fifteenth family.

Do not rely on producer aggregates without row reconstruction.

────────────────────────────────────────────────

18. DRAFT 2020-12 VALIDATION

Authenticate `jsonschema` distribution, version, module path, source identities,
and `Draft202012Validator`.

Validate all 15 current schemas.

Require:

- 15 evaluated;
- 15 valid;
- zero errors;
- no empty `prefixItems`;
- no unresolved references;
- no partial or substituted validator behavior.

────────────────────────────────────────────────

19. FRESH WITNESSES

Independently create:

- 14 contract-derived witnesses;
- 14 schema-derived witnesses.

Do not reuse producer witness bytes.

For every row retain:

- witness ID;
- family;
- instance;
- construction authority;
- schema role/path/identity;
- normative pointers;
- schema result;
- contract result;
- primary and secondary result;
- direct evidence.

Require:

- 28 passing rows;
- zero joint unsatisfiability;
- zero baseline under-enforcement;
- dual-oracle agreement.

Aggregate derives only from the rows.

A blocker requires exact failed rows and non-null direct evidence.

────────────────────────────────────────────────

20. COMPLETE 946-CASE AUDIT

Authenticate the current 946-case registry.

Require:

- 946 exact rows;
- 946 unique literal names;
- expected-name closure;
- governed expectations.

Run all cases through both clean oracles.

Every result row contains:

- ordinal;
- literal name;
- family;
- schema role/path/identity;
- base-instance identity;
- mutation operator;
- mutation pointer;
- original and mutated values;
- expected outcome and reason;
- primary observed outcome/reason;
- secondary observed outcome/reason;
- validator keyword;
- instance path;
- schema path;
- normalized errors;
- governing specification pointer;
- agreement;
- classification.

Require:

- no exception;
- zero oracle disagreement;
- no skip;
- exact governed outcome vocabulary.

A subject blocker requires exact failed rows.

If any evaluator exception or oracle disagreement occurs:

AUDIT_PROVENANCE_MISMATCH

────────────────────────────────────────────────

21. COMPLETE 137-CASE AUDIT

Authenticate the current 137-case registry.

Require:

- 137 exact rows;
- unique literal names;
- expected-name closure;
- exact governed outcome tokens;
- historical-prefix semantics.

Run all cases through both clean oracles.

Retain all fields required in Section 20 plus:

- contradiction family;
- contradiction site;
- historical-prefix membership;
- governed atomic-member count.

Explicitly forbid an `ACCEPT_ALL_14` aggregate from replacing row-specific
outcomes.

Any evaluator exception or disagreement forces provenance mismatch.

────────────────────────────────────────────────

22. FIELD MAP, DOCUMENTARY VALIDATORS, AND CONFIRMATIONS

A. Field map

Independently resolve:

- 766 normative leaves;
- 333 enforcement rows;
- all JSON pointers;
- identities and family mappings.

Require zero unresolved, duplicate, wrong, or unclassified row.

B. Documentary validators

Derive exact current roles using the governed identifiers.

Require:

- exact ten-role set;
- `documentary-validator:<role>` identity vocabulary where governed;
- one current result per role;
- no duplicate role/path;
- source/result identities;
- every retained result passing;
- acyclic evidence graph.

Independent closure of a retained validator must use the corrected clean audit
logic.

C. Confirmations

Derive all 66 rows from evidence.

Require:

- no hard-coded value;
- no absence-as-success;
- no stale evidence;
- no circularity;
- direct versus derivative classification;
- derivative failures not counted as direct blockers.

────────────────────────────────────────────────

23. OCCUPANCY, LINEAGE, AND STATUS

Independently require:

- one current artifact per schema role;
- one current artifact per documentary-validator role;
- exact role IDs;
- no failed artifact current;
- no historical closure output current;
- explicit supersession edges;
- exact lineage;
- implementation_present false;
- implementation_authority false;
- producer construction passed;
- producer qualification passed;
- subject terminal closure passed;
- independent acceptance false before this audit;
- target audit not executed;
- runtime validation not rerun;
- no self-promotion.

────────────────────────────────────────────────

24. FINDINGS AND REPAIR OWNERSHIP

Retain:

analysis/findings-and-dependency-graph.json
analysis/repair-owner-registry.json

Only direct subject-package findings may force BLOCK.

Every direct blocker must contain:

- exact failed witness or case rows;
- non-null direct evidence;
- governing contract/schema/spec pointer;
- primary repair owner;
- exact repair surface;
- whether subject bytes must change;
- whether reconstruction is required;
- whether unchanged-subject re-audit is allowed;
- dependencies and verdict effect.

Allowed primary owners:

- NORMATIVE_CONTRACT_AUTHORITY
- CURRENT_SCHEMA_AUTHORITY
- VALIDATION_SPECIFICATION_AUTHORITY
- SUBJECT_RECONSTRUCTION_PARENT
- SUBJECT_EVIDENCE_GENERATION
- PRODUCER_VALIDATOR_LOGIC
- INDEPENDENT_AUDIT_ORACLE
- INDEPENDENT_AUDIT_EVIDENCE_PROJECTION
- CONFIRMATION_EVIDENCE_MAP
- MIXED_OWNER
- UNRESOLVED_OWNER

Audit-oracle, oracle-disagreement, evidence-projection, occupancy-label,
confirmation-projection, custody, cleanup, or capsule-closure defects force
`AUDIT_PROVENANCE_MISMATCH`.

They are not subject blockers.

────────────────────────────────────────────────

25. AUDIT PHASES AND PROCESS CUSTODY

Retain terminal phases:

A00 fixed inputs
A01 construction chain
A02 subject terminal closure
A03 normative contract and schema roles
A04 generated families and mappings
A05 Draft 2020-12
A06 witnesses
A07 946 cases
A08 137 cases
A09 766/333 field map
A10 documentary-validator authority
A11 confirmations
A12 occupancy, lineage, status
A13 findings and disposition
A14 cleanup and supplied-root equality
A15 audit-capsule terminal closure

Every phase contains:

- explicit status;
- terminal true;
- direct phase-specific evidence;
- findings;
- first blocker or null;
- continuation;
- cleanup obligations;
- authority contribution.

A15 status must equal final closure pass.

Retain a complete child ledger.

Explicit zero-child evidence passes.

────────────────────────────────────────────────

26. AUDIT CLEANUP AND SUPPLIED-ROOT EQUALITY

Retain:

cleanup/cleanup-result.json
closing/supplied-root-closing-equality.json

Require exact cleanup-set equality.

Equal empty sets pass.

Require zero process, descriptor, cache, and bytecode survivors.

Repeat complete opening/closing equality for:

- replacement subject;
- construction wrapper;
- accepted implementation audit root;
- accepted implementation wrapper root;
- content bundle;
- content authority;
- failed audit root when opened as regression input;
- every additional fixed input.

Do not mutate or clean supplied roots.

────────────────────────────────────────────────

27. AUDIT-CAPSULE TERMINAL CLOSURE

Before projection:

- finalize all nonclosure records;
- create only used final directories;
- reserve temporal, manifest A, manifest B, and terminal result;
- retain descriptors;
- freeze physical namespace.

Physical empty-directory adjudication uses the complete physical namespace,
including reserved files.

Create:

closeout/temporal-final-inventory.json
manifest/canonical-manifest-a.json
manifest/canonical-manifest-b.json
terminal/terminal-result.json

Require:

- independently generated temporal bytes equal;
- immediate temporal reprojection;
- independent A/B generation;
- A/B byte equality;
- descriptor/path inode equality;
- final whole-root reprojection;
- root row once;
- no physical empty descendant;
- clean topology and modes;
- no cache/bytecode;
- one seal transition;
- A15 status equals closure result;
- no postseal operation.

Prepare terminal frame before seal.

After seal:

- emit only terminal frame;
- exit nonreturningly.

────────────────────────────────────────────────

28. VERDICT RULES

Return:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_ACCEPT

only when:

- provenance and chain pass;
- subject terminal closure passes;
- 15/14 model passes;
- schemas pass Draft 2020-12;
- witnesses pass with oracle agreement;
- all 946 cases pass with exact outcomes;
- all 137 cases pass with exact outcomes;
- 766/333 closes;
- documentary-validator authority closes;
- confirmation evidence closes;
- occupancy/lineage/status close;
- no direct package blocker remains;
- cleanup/equality/capsule closure pass.

Return:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_BLOCK

only when:

- audit provenance passes;
- at least one direct current subject-package blocker exists;
- every blocker has exact non-null evidence;
- every nonpassing witness/case row is retained;
- repair ownership is retained;
- findings/dependencies are complete;
- cleanup/equality/capsule closure pass.

Return:

AUDIT_PROVENANCE_MISMATCH

for:

- fixed-input mismatch;
- subject drift;
- audit toolchain failure;
- evaluator exception;
- oracle disagreement;
- invalid outcome-vocabulary projection;
- incomplete direct evidence;
- aggregate blocker without exact rows;
- hard-coded confirmations;
- occupancy label mismatch;
- audit cleanup inequality;
- supplied-root inequality;
- audit-capsule closure failure;
- A15/closure contradiction;
- postseal activity.

Do not retry in this task.

────────────────────────────────────────────────

29. NO FOLLOW-ON EXECUTION

After reporting:

- stop;
- preserve replacement subject unchanged;
- preserve construction wrapper;
- preserve accepted implementation roots;
- preserve content inputs;
- preserve failed historical audit;
- preserve new audit capsule;
- do not promote or rebind authority;
- do not construct another subject;
- do not execute product/live-service modes;
- do not run target audit;
- do not rerun runtime validation;
- do not modify a repository;
- do not publish or deploy;
- do not begin A6;
- do not launch another agent.

────────────────────────────────────────────────

30. REQUIRED INLINE OPERATIVE REPORT

Return:

1. Exact primary verdict
2. Fresh audit-root identity
3. Replacement subject identity
4. Construction-wrapper identity
5. Accepted implementation authority
6. Content identities
7. Failed-audit regression-capsule identity
8. Clean source authority and source registries
9. Audit source freeze
10. Governed outcome vocabulary
11. Total documentary-checking contract
12. Dual-oracle independence
13. Occupancy role vocabulary
14. Evidence-derived confirmation contract
15. Physical closure model
16. Audit-logic qualification
17. Static qualification
18. Subject terminal-closure authentication
19. Normative contract
20. Fifteen schema roles
21. Fourteen generated families
22. Role/family mapping
23. Draft 2020-12
24. Contract-witness rows
25. Schema-witness rows
26. Witness aggregate
27. Complete 946 aggregate
28. Exact failed 946 rows, if any
29. Complete 137 aggregate
30. Exact failed 137 rows, if any
31. Dual-oracle crosswalk
32. 766/333 field map
33. Documentary-validator closure
34. Confirmation-evidence result
35. Derivative-confirmation ledger
36. Current-role occupancy
37. Lineage/supersession
38. Producer status
39. Findings
40. Repair owners
41. Dependency graph
42. A00–A15
43. Child custody
44. Audit cleanup
45. Supplied-root equality
46. Audit temporal identity
47. Audit manifest identities
48. A/B equality
49. Final reprojection
50. Physical topology/modes
51. Seal/A15/no-postseal
52. Confirmation subject unchanged
53. Confirmation no authority promotion
54. Confirmation no product/runtime/target/A6 activity
55. Remaining uncertainty/nonclaims
56. Explicit confirmations

Required confirmations:

REPLACEMENT_SUBJECT_ROOT_IDENTITY_MATCHED
REPLACEMENT_CONSTRUCTION_WRAPPER_AUTHENTICATED
ACCEPTED_IMPLEMENTATION_AUDIT_CHAIN_AUTHENTICATED
CURRENT_CONTENT_BUNDLE_IDENTITY_MATCHED
CURRENT_CONTENT_AUTHORITY_IDENTITY_MATCHED
FAILED_AUDIT_CAPSULE_AUTHENTICATED_AS_NONQUALIFYING
FAILED_AUDIT_SOURCE_NOT_REUSED
CLEAN_INDEPENDENT_AUDIT_SOURCE_CREATED
CLEAN_AUDIT_SOURCE_IMPORTS_NO_FORBIDDEN_HELPERS
CLEAN_AUDIT_SOURCE_FROZEN
GOVERNED_OUTCOME_VOCABULARY_FROZEN
TOTAL_DOCUMENTARY_CHECKING_IMPLEMENTED
DUAL_ORACLE_INDEPENDENCE_ENFORCED
OCCUPANCY_ROLE_VOCABULARY_GOVERNED
CONFIRMATIONS_EVIDENCE_DERIVED
PHYSICAL_EMPTY_DIRECTORY_CHECK_USES_FULL_NAMESPACE
AUDIT_LOGIC_QUALIFICATION_PASSED
AUDIT_STATIC_QUALIFICATION_PASSED
SUBJECT_TEMPORAL_IDENTITY_MATCHED
SUBJECT_MANIFEST_A_IDENTITY_MATCHED
SUBJECT_MANIFEST_B_IDENTITY_MATCHED
SUBJECT_MANIFESTS_BYTE_IDENTICAL
SUBJECT_TERMINAL_REPROJECTION_PASSED
SUBJECT_ROOT_ROW_PRESENT_EXACTLY_ONCE
SUBJECT_PHYSICAL_CLOSURE_MATCHED_MANIFESTS
NORMATIVE_CONTRACT_BYTES_UNCHANGED
EXACTLY_FIFTEEN_CURRENT_SCHEMA_ROLES
EXACTLY_FOURTEEN_GENERATED_RECORD_FAMILIES
NORMATIVE_CONSTRUCTION_PARENT_NOT_COUNTED_AS_GENERATED_FAMILY
SCHEMA_ROLE_TO_FAMILY_MAPPING_COMPLETE
ALL_FIFTEEN_SCHEMAS_METASCHEMA_VALID
FOURTEEN_CONTRACT_WITNESSES_SCHEMA_VALID
FOURTEEN_SCHEMA_WITNESSES_CONTRACT_VALID
WITNESS_AGGREGATE_HAS_EXACT_ROW_EVIDENCE
ZERO_JOINTLY_UNSATISFIABLE_RECORD_FAMILY
ZERO_UNDER_ENFORCED_BASELINE_RECORD_FAMILY
GENERATED_RECORD_NEGATIVE_MATRIX_946_COMPLETED
EVERY_NONPASSING_946_ROW_RETAINED
CONTRADICTION_REGRESSION_137_COMPLETED
EVERY_NONPASSING_137_ROW_RETAINED
DUAL_ORACLE_RESULTS_AGREE
NO_ORACLE_EXCEPTION
EXACT_GOVERNED_OUTCOME_VOCABULARY_USED
CONTRACT_SCHEMA_FIELD_MAP_766_333_CLOSED
EXACT_CURRENT_DOCUMENTARY_VALIDATOR_ROLE_SET
ALL_CURRENT_DOCUMENTARY_VALIDATOR_RESULTS_PRESENT
ALL_CURRENT_DOCUMENTARY_VALIDATOR_RESULTS_PASSED
CONFIRMATION_EVIDENCE_MAP_COMPLETED
DERIVATIVE_CONFIRMATIONS_NOT_COUNTED_AS_DIRECT_BLOCKERS
NO_HARDCODED_CONFIRMATION_SUCCESS
CURRENT_ROLE_OCCUPANCY_COMPLETE
GOVERNED_DOCUMENTARY_VALIDATOR_PREFIX_USED
NO_HISTORICAL_CLOSURE_OUTPUT_CURRENT
NO_FAILED_ARTIFACT_CURRENT
IMPLEMENTATION_PRESENT_FALSE
IMPLEMENTATION_AUTHORITY_FALSE
PRODUCER_PACKAGE_NOT_SELF_PROMOTED
INDEPENDENT_ACCEPTANCE_NOT_PRECLAIMED
EVERY_DIRECT_BLOCKER_HAS_NON_NULL_DIRECT_EVIDENCE
EVERY_DIRECT_BLOCKER_HAS_PRIMARY_REPAIR_OWNER
FINDING_OWNERSHIP_COMPLETE
EVERY_REQUIRED_AUDIT_PHASE_TERMINAL
A15_STATUS_EQUALS_FINAL_CLOSURE_PASS
CHILD_ORDINALS_COMPLETE_AND_CONTIGUOUS
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
AUDIT_CLEANUP_SET_EQUALITY_PASSED
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
AUDIT_TEMPORAL_INVENTORY_CREATED
AUDIT_TEMPORAL_INVENTORY_VERIFIED
AUDIT_MANIFEST_A_CREATED
AUDIT_MANIFEST_B_CREATED
AUDIT_MANIFESTS_BYTE_IDENTICAL
AUDIT_TERMINAL_REPROJECTION_PASSED
AUDIT_ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_AUDIT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_AUDIT_DIRECTORY_MODES_0700
ALL_AUDIT_FILE_MODES_0600
NO_AUDIT_CACHE_OR_BYTECODE_RETAINED
SINGLE_AUDIT_SEAL_TRANSITION
NO_WRITE_AFTER_AUDIT_TERMINAL_SEAL
REPLACEMENT_SUBJECT_MUTATION_NOT_PERFORMED
REPLACEMENT_SUBJECT_CLEANUP_NOT_PERFORMED
CURRENT_AUTHORITY_PROMOTION_NOT_PERFORMED
CURRENT_AUTHORITY_REBINDING_NOT_PERFORMED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

### Sources and confidence

The latest report establishes that subject closure, the 15/14 model, metaschema validation, witnesses, field map, lineage, and producer posture all passed. :chatgpt-content-reference{index="9"} :chatgpt-content-reference{index="10"}

It directly establishes the 946/137 oracle failures, the two oracle disagreements, the occupancy-label defect, derivative confirmation failures, invalid subject finding ownership, and hard-coded confirmation projection. :chatgpt-content-reference{index="11"} :chatgpt-content-reference{index="12"}

It also establishes the capsule’s physical-empty-directory projection defect and the A15/closure contradiction. :chatgpt-content-reference{index="13"}

**Provenance confidence:** 0.995  
**Audit-only defect classification confidence:** 0.999  
**Unchanged-subject audit readiness:** 0.98  
**Current subject acceptance confidence:** 0.00—the failed audit did not adjudicate it.

The current attachment was fully readable. Some older uploaded artifacts have expired; re-upload one only if a future review requires its original bytes rather than the retained identities and reports.
