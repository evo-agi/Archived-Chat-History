## Assessment

The sealed package is **mechanically sound but authority-invalid**. Its exports, root binding, qualification causals, terminal inventory, manifests, and no-write-after-closure posture all passed. The failure is narrower:

- The dependency graph declared two JSON pointers that do not exist.
- The package qualification result copied that unresolved ledger and overstated success.
- Frozen requalification compared the same flawed ledger rather than resolving each pointer against the actual documents.
- The terminal manifests faithfully sealed those contradictions, so the root must remain immutable and noncurrent.

The two exact pointer errors are:

- Declared  
  `contract/package-root-rebinding-v1.json#/successor_plan_identity`  
  Actual  
  `contract/package-root-rebinding-v1.json#/successor_plan_predicted_identity`

- Declared  
  `opening/current-export-registry-v1.json#/exports/target-audit-plan`  
  Actual  
  `opening/current-export-registry-v1.json#/exports/target-audit plan`

No target, bootstrap, executable-source, plan-semantic, finalizer, or acceptance-rule repair is authorized.

A new root is still necessary because the plan is physically bound to the sealed package path. The new tranche should:

1. Rebind the plan once to the new final root.
2. Keep the other six semantic exports byte-identical.
3. Replace the flawed generated metadata with clean versioned records using deliberately fixed field names.
4. Validate each acceptance-bearing JSON pointer by actual RFC 6901 resolution—not by copied-ledger equality.
5. Freshly rerun qualification because the plan identity changes again.
6. Seal the package only after all pointer-resolution evidence is final.

Acyclic metadata construction is essential. The semantic qualification result may report that qualification passed, but it must explicitly remain **nonterminal and nonauthoritative** until the later pointer-resolution record and terminal capsule closure pass.

Forward this prompt:

```text
BOUNDED TRANSITIVE-IDENTITY METADATA REPAIR,
PHYSICAL-ROOT REBINDING, FRESH QUALIFICATION, AND TERMINAL CLOSURE —
VALIDATION-CUSTODY V3 TARGET-AUDIT HARNESS PACKAGE

This task creates one fresh, immutable target-audit harness package from an
exact mechanically sealed predecessor whose generated metadata contains two
invalid transitive JSON pointers.

It repairs:

- one unavoidable physical package-root binding in the target-audit plan;
- generated package metadata that binds the resulting plan identity;
- qualification logic that failed to resolve those pointers.

It does not repair or redesign:

- the target-audit executable source;
- target-audit algorithms;
- target-audit acceptance criteria;
- support-root binding semantics;
- finalizer lifecycle semantics;
- process-custody semantics;
- the Validation-Custody V3 target;
- the accepted bootstrap package.

Do not modify, resume, clean, finish, or reseal any historical root.

Do not silently rebind a path.
Do not introduce package portability, runtime root discovery, latest selection,
prefix scanning, score selection, fallback, symlink indirection, or movable-root
semantics.
Do not execute the real target audit.
Do not execute Plan V3 or Plan V4.
Do not run repository tests or product code.
Do not run Git.
Do not use the network.
Do not install, deploy, publish, externally commit, or start A6.
Do not create subagents or direct auditors.

Return exactly one primary verdict:

TARGET_AUDIT_HARNESS_PACKAGE_METADATA_REPAIR_READY
TARGET_AUDIT_HARNESS_PACKAGE_METADATA_REPAIR_BLOCKED
PREFLIGHT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. EXACT SEALED PREDECESSOR PACKAGE
──────────────────────────────────────────────────────────────────────────────

SEALED_PREDECESSOR_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-package-rebound-voptrogn

Expected identity:

- device/inode:
  16777234 / 180248929
- mode:
  0700
- retained task verdict:
  PREFLIGHT_PROVENANCE_MISMATCH
- physical entries:
  74
- directories:
  14
- regular files:
  60

Expected temporal inventory:

closeout/temporal-final-inventory-v2.json

- size:
  16600
- SHA-256:
  8f32a844819a333fd88588ea048455576147886f0a8b512a19278b5df6affca7

Expected terminal manifests:

manifest/canonical-manifest-a-v2.json
manifest/canonical-manifest-b-v2.json

- size:
  16431 each
- SHA-256:
  240259f8e850293f1d8b8bec8c349eb8d21bc931ea191ff34373cfa963a9eee7
- byte-identical:
  required

Authenticate the complete package closure independently before using any
predecessor byte.

This sealed package is immutable historical evidence. It is not current
package authority.

Do not alter any predecessor byte.

──────────────────────────────────────────────────────────────────────────────
2. GOVERNING PREDECESSOR RECORDS
──────────────────────────────────────────────────────────────────────────────

Authenticate at minimum:

analysis/export-dependency-graph-v1.json

- size:
  14792
- SHA-256:
  b2650e42030a1afc1f679f8e669c45fb762b37c1030af55baed46acba81250e5

contract/package-root-rebinding-v1.json

- size:
  3541
- SHA-256:
  12f1ef745cb193227a138122cfa2f04a6c5b9ed98c4da419a1e8b90a24c9cb8a

validation/package-root-rebinding-matrix-v1.json

- SHA-256:
  689188076a6b8315dd0c25372433e3f4e7a6af1d16e0c5080e47195b4b1b2291

validation/two-root-rebinding-determinism-v1.json

- SHA-256:
  f1e0882854891c2bb8f851309bf8d6f5eb97c13e482809009b75e7aeb31d3e

validation/current-qualification-result-v1.json

- size:
  8000
- SHA-256:
  a9b9c3903339166588b8eca0ec69a475b232b6bd741cf7e3b6b7d79a5fa832b2

opening/target-audit-harness-package-freeze-v2.json

- size:
  12130
- SHA-256:
  009e11de818e487126d03cf09d3d3bb3a6542d7c7f4f4df3550cce4e2c2060fc

validation/frozen-package-requalification-v2.json

- size:
  31209
- SHA-256:
  70d1e81853b5a4de8c9152e994682eec3df74bbc0959390c0c13ddf34ab8d934

closeout/explicit-confirmations-v2.json

- SHA-256:
  2d01bfbd7ba45e9a7d4bbbc1328447449c347e19ab3f0b9fad24be677049dda7

The governing defects are exactly:

A. In `contract/package-root-rebinding-v1.json`:

Declared pointer:
  /successor_plan_identity

Actual field:
  /successor_plan_predicted_identity

B. In `opening/current-export-registry-v1.json`:

Declared pointer:
  /exports/target-audit-plan

Actual field:
  /exports/target-audit plan

C. `validation/current-qualification-result-v1.json` copied the unresolved
   ledger and claimed success.

D. `validation/frozen-package-requalification-v2.json` checked copied-ledger
   equality rather than actual pointer existence and resolution.

Do not infer any additional semantic defect from these records.

──────────────────────────────────────────────────────────────────────────────
3. HISTORICAL LINEAGE ROOTS
──────────────────────────────────────────────────────────────────────────────

Open read-only only when needed for lineage and fixed-input authentication:

FAILED_UNSEALED_PACKAGE_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-repair-odqwbxli

BLOCKED_CLOSURE_ATTEMPT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-package-qko804d4

RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-target-audit-provenance-reconciliation-wtfwwjks

TARGET_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-audit-repair-0mwnrf5b

V2_INDEPENDENT_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v2-independent-audit-znleuyfy

ACCEPTED_BOOTSTRAP_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t

ACCEPTED_BOOTSTRAP_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-a-c-h-i-independent-audit-sbv__euv

QUALIFIED_LAUNCHER_ROOT:

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38

IMPORT_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-launcher-package-import-reconciliation-xqrjt92s

PINNED_PYTHON:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Every opened root requires complete lstat/no-follow opening and closing
equality.

──────────────────────────────────────────────────────────────────────────────
4. EXACT PREDECESSOR SEMANTIC EXPORTS
──────────────────────────────────────────────────────────────────────────────

The predecessor’s seven semantic exports are:

source/target_audit_payload_v2.py

- size:
  203704
- SHA-256:
  3528fc8b06665c4a1ec18a12b6ae0e0bbd0c1496767420139627d8064af7ee42

contract/target-audit-plan-v2.json

- size:
  8553
- SHA-256:
  2dfa051b5c6258cb2b84f8704f6cc3259b75f6d37197737e800b69e9e63d92cc

contract/support-root-binding-policy-v1.json

- size:
  4051
- SHA-256:
  0cc44dc948227c32c1a34d9cf6518ae07caa1b3eaa46a69482cca6e00921a87d

contract/finalizer-lifecycle-v1.json

- size:
  2261
- SHA-256:
  73f30bed23431cc4b49234433ebebdaf9042faa2af26015ff1fd830936f5fef8

contract/finalizer-process-custody-v1.json

- size:
  1068
- SHA-256:
  b9e3ccd4754faf956c42eaa6fd8199feda76ee8a5f3d4794acd7c1949a037bd7

templates/carrier-0003-request-template-v2.json

- size:
  2941
- SHA-256:
  89bb7eb2a3b54f0583a91056349ebf3c97ebafc9535239f4386a6a003f5e20e7

templates/finalizer-invocation-contract-template-v1.json

- size:
  3557
- SHA-256:
  569509be03ecf3e7380bba0be63df5ccd80ccb44a223675c540525d3b1690dab

The current predecessor plan is bound to:

/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-package-rebound-voptrogn/source/target_audit_payload_v2.py

The new final plan must bind the new final package root.

──────────────────────────────────────────────────────────────────────────────
5. FRESH FINAL PACKAGE ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one final package root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask `077`, prefix:

ES-repair10i-v3-target-audit-harness-package-metadata-repair-

Immediately emit:

PACKAGE_ROOT=<absolute-path>

This exact physical path is the final immutable package root.

Do not later move, rename, copy, or adopt another root.

Before writing exports retain:

opening/bootstrap-start.json

including:

- final root identity;
- allocation method and umask;
- predecessor package identity;
- exact predecessor seven-export identities;
- repair authority:
  physical-root-rebinding-and-generated-metadata-repair-only;
- semantic source changes authorized:
  false;
- executable control-flow changes authorized:
  false;
- acceptance-rule changes authorized:
  false;
- real target audit executed:
  false.

Create directories lazily.

Do not retain an empty directory.

──────────────────────────────────────────────────────────────────────────────
6. SEMANTIC EXPORT CONSTRUCTION
──────────────────────────────────────────────────────────────────────────────

Copy byte-for-byte these six exports:

source/target_audit_payload_v2.py
contract/support-root-binding-policy-v1.json
contract/finalizer-lifecycle-v1.json
contract/finalizer-process-custody-v1.json
templates/carrier-0003-request-template-v2.json
templates/finalizer-invocation-contract-template-v1.json

Use no-follow reads, exclusive mode-0600 writes, fsync, no-follow reopen, and
exact byte comparison.

Generate the new:

contract/target-audit-plan-v2.json

by changing exactly one value:

JSON pointer:

/payload/frozen_source_identity/package_path

Old value:

/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-package-rebound-voptrogn/source/target_audit_payload_v2.py

New value:

${EXACT_FINAL_PACKAGE_ROOT}/source/target_audit_payload_v2.py

where `${EXACT_FINAL_PACKAGE_ROOT}` is replaced by the literal emitted path.

No placeholder remains in the final plan.

Require:

- exactly one changed JSON pointer;
- unchanged schema;
- unchanged field map;
- unchanged command, operand, authority, nonauthority, and verdict semantics;
- unchanged payload size and SHA-256 fields;
- exact payload resolution under the final root.

Retain original and successor plan bytes and their exact diff.

──────────────────────────────────────────────────────────────────────────────
7. CLEAN VERSIONED GENERATED METADATA
──────────────────────────────────────────────────────────────────────────────

Do not copy these flawed predecessor metadata records as current:

analysis/export-dependency-graph-v1.json
contract/package-root-rebinding-v1.json
opening/current-export-registry-v1.json
validation/current-qualification-result-v1.json
opening/target-audit-harness-package-freeze-v2.json
validation/frozen-package-requalification-v2.json
closeout/explicit-confirmations-v2.json

Bind their identities only in historical lineage.

Generate new versioned metadata records with closed field names.

A. Root-rebinding contract:

contract/package-root-rebinding-v2.json

Required plan-identity field:

/successor_plan_identity

B. Current export registry:

opening/current-export-registry-v2.json

Required exact plan role key and pointer:

/exports/target-audit-plan

Do not use a key containing a space.

C. Current qualification result:

validation/current-qualification-result-v2.json

Required plan-identity field:

/plan_identity

D. Freeze record:

opening/target-audit-harness-package-freeze-v3.json

Required plan-identity field:

/plan_identity

Every plan-identity object must have exactly:

{
  "path": "<package-relative-plan-path>",
  "sha256": "<64-lowercase-hex>",
  "size": <integer>
}

Use the exact package-relative path:

contract/target-audit-plan-v2.json

No alternate field name, alias, duplicate, or compatibility synonym is
permitted.

──────────────────────────────────────────────────────────────────────────────
8. ACCEPTANCE-BEARING PLAN-IDENTITY CONSUMER REGISTRY
──────────────────────────────────────────────────────────────────────────────

After the four generated metadata records exist, retain:

contract/acceptance-bearing-plan-identity-consumers-v1.json

It must declare exactly four acceptance-bearing consumers:

1.
document:
  contract/package-root-rebinding-v2.json
pointer:
  /successor_plan_identity
role:
  package-root-rebinding

2.
document:
  opening/current-export-registry-v2.json
pointer:
  /exports/target-audit-plan
role:
  current-export-registry

3.
document:
  validation/current-qualification-result-v2.json
pointer:
  /plan_identity
role:
  current-qualification-result

4.
document:
  opening/target-audit-harness-package-freeze-v3.json
pointer:
  /plan_identity
role:
  frozen-package-identity

For every row bind:

- document path;
- document size;
- document SHA-256;
- exact RFC 6901 pointer;
- field role;
- expected plan-identity object;
- acceptance-bearing:
  true.

Do not include reports, lineage, diagnostic ledgers, or validation records that
merely mention the plan identity.

Retain a separate nonauthoritative occurrence scan for all other plan-identity
mentions.

──────────────────────────────────────────────────────────────────────────────
9. ACTUAL JSON-POINTER RESOLUTION
──────────────────────────────────────────────────────────────────────────────

Implement strict RFC 6901 pointer resolution.

Do not validate pointer strings through copied-ledger equality.

Do not validate merely that a document contains the expected plan digest.

Retain:

validation/transitive-plan-identity-resolution-v1.json

For every one of the four consumer rows:

1. Reopen the document no-follow.
2. Verify its bound size and SHA-256.
3. Strict-parse JSON:
   - reject duplicate keys;
   - reject nonfinite values.
4. Resolve the exact pointer token by token.
5. Require that resolution succeeds exactly once.
6. Require the resolved value to be an object.
7. Require its exact field set:
   `path`, `sha256`, `size`.
8. Require exact canonical equality with the current plan identity.
9. Retain:
   - pointer;
   - decoded tokens;
   - resolved value;
   - expected value;
   - success;
   - first blocker.

Require all four rows to pass.

No package qualification or freeze claim may become terminal authority before
this resolution record passes.

──────────────────────────────────────────────────────────────────────────────
10. COMPLETE DEPENDENCY GRAPH
──────────────────────────────────────────────────────────────────────────────

Retain:

analysis/export-dependency-graph-v2.json

It must distinguish:

A. Direct semantic export dependency:

contract/target-audit-plan-v2.json
#/payload/frozen_source_identity/package_path

B. Acceptance-bearing generated-metadata consumers:

the exact four records in section 8.

C. Nonauthoritative evidence mentions:

reports, lineage, diagnostics, matrices, occurrence scans.

For every occurrence record:

- file;
- JSON pointer or source line;
- role;
- direct or transitive;
- acceptance-bearing or evidence-only;
- old value;
- new value;
- required action.

The graph may claim `complete:true` only when:

- all seven semantic exports were scanned;
- all current generated metadata was scanned;
- all four consumer pointers were actually resolved;
- no unregistered acceptance-bearing consumer exists;
- all other occurrences are explicitly classified as evidence-only.

Retain the complete occurrence scan used to establish closure.

──────────────────────────────────────────────────────────────────────────────
11. ROOT-REBINDING CONTRACT V2
──────────────────────────────────────────────────────────────────────────────

The new:

contract/package-root-rebinding-v2.json

must bind:

- predecessor sealed package identity;
- predecessor plan identity;
- predecessor package-root pointer and value;
- final package root identity;
- successor plan identity;
- successor package-root pointer and value;
- exact direct changed pointer set:
  one pointer;
- exact semantic-export changed set:
  plan only;
- exact unchanged semantic-export set:
  six exports;
- exact generated metadata consumer registry;
- semantic effect:
  none;
- executable control-flow effect:
  none;
- acceptance-rule effect:
  none;
- package immobility:
  required;
- later rebinding:
  forbidden without a new package and fresh qualification.

It must not claim transitive-pointer completeness until the actual resolution
record exists.

Use a field such as:

transitive_pointer_resolution_required: true

Do not embed a premature success claim.

──────────────────────────────────────────────────────────────────────────────
12. CURRENT EXPORT REGISTRY V2
──────────────────────────────────────────────────────────────────────────────

Generate:

opening/current-export-registry-v2.json

Require exactly seven export roles and exactly one current plan.

Use exact keys:

target-audit-payload
target-audit-plan
support-root-binding-policy
finalizer-lifecycle
finalizer-process-custody
carrier-0003-request-template
finalizer-invocation-contract-template

Do not use spaces in role keys.

For each bind:

- relative path;
- size;
- SHA-256;
- mode;
- link count;
- schema or source role;
- producer;
- consumers;
- current:
  true.

The plan entry must occur exactly at:

/exports/target-audit-plan

──────────────────────────────────────────────────────────────────────────────
13. FRESH QUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Because the root-bound plan identity changes again, generate fresh current
qualification evidence.

Do not promote predecessor qualification results to current authority.

Freshly run:

- package-root rebinding matrix;
- support-root binding mutation matrix;
- support-root live replay;
- finalizer mutation matrix;
- independent finalizer validator;
- successful synthetic finalization causal;
- required failure finalization causals;
- direct-finalizer process-custody qualification;
- two synthetic Carrier 0003 materializations;
- retained failed-audit replay;
- payload compile-only check;
- static source/call-graph checks;
- AST postseal analysis;
- bytecode/exception-table postseal analysis.

Do not run the real target audit.

Do not execute Plan V3 or Plan V4.

Do not import the target-audit payload.

Every Python process must use:

-I -S -B
PYTHONDONTWRITEBYTECODE=1

and an external private audit-owned:

PYTHONPYCACHEPREFIX

that is inventoried and removed before package closure.

No package-root bytecode or cache path is permitted.

──────────────────────────────────────────────────────────────────────────────
14. CURRENT QUALIFICATION RESULT V2
──────────────────────────────────────────────────────────────────────────────

Generate:

validation/current-qualification-result-v2.json

It must bind:

- exact seven current export identities;
- exact current plan identity;
- root-rebinding contract V2;
- export registry V2;
- rebinding matrix;
- support-binding qualification;
- finalizer qualification;
- independent validator;
- synthetic materializations;
- finalization causals;
- process custody;
- compilation/static/postseal results;
- cache posture;
- target audit executed:
  false;
- semantic change:
  physical-root-rebinding-only;
- qualification_success:
  true on success;
- package_authority_established:
  false;
- terminal_closure_established:
  false;
- transitive_pointer_resolution_required:
  true;
- first_blocker:
  null on qualification success.

Its `success` or `qualification_success` field qualifies the dynamic and static
qualification surfaces only.

It must not claim current package authority.

The exact plan identity must occur at:

/plan_identity

──────────────────────────────────────────────────────────────────────────────
15. METADATA-POINTER MUTATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Create a literal matrix covering at minimum:

1. Exact four-consumer baseline.
2. Missing consumer.
3. Extra acceptance-bearing consumer.
4. Duplicate consumer document/pointer pair.
5. Nonexistent pointer.
6. Wrong pointer:
   `/successor_plan_predicted_identity`.
7. Wrong registry pointer with space:
   `/exports/target-audit plan`.
8. Pointer resolves to scalar.
9. Pointer resolves to null.
10. Pointer resolves to wrong object field set.
11. Correct path, stale SHA-256.
12. Correct SHA-256, stale size.
13. Correct identity, wrong plan path.
14. Predecessor plan identity.
15. Wrong document identity.
16. Duplicate JSON key in consumer document.
17. Nonfinite value.
18. Malformed RFC 6901 escape.
19. Evidence-only mention marked acceptance-bearing.
20. Acceptance-bearing consumer omitted from dependency graph.
21. Dependency graph claims complete before pointer resolution.
22. Qualification result claims package authority before resolution.
23. Freeze record claims terminal closure.
24. Copied-ledger equality without pointer resolution.
25. Pointer resolution result omits decoded tokens.
26. Unknown role.
27. Consumer document missing.
28. Plan missing.
29. Plan root path stale.
30. All exact pointers resolve and match.

Require:

- exact literal names;
- uniqueness;
- two-way closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip.

Retain:

validation/metadata-pointer-mutation-matrix-v1.json

──────────────────────────────────────────────────────────────────────────────
16. INDEPENDENT METADATA VALIDATOR
──────────────────────────────────────────────────────────────────────────────

Implement a second validator that imports neither:

- package construction helpers;
- first pointer resolver;
- first mutation-matrix helper;
- producer mutation fixtures.

It must independently:

- strict-parse the four consumer documents;
- implement RFC 6901 resolution;
- verify exact pointer existence;
- verify exact resolved field set and values;
- verify complete consumer registry;
- verify no unregistered acceptance-bearing consumer;
- verify dependency-graph completeness;
- verify qualification nonauthority before closure;
- verify freeze-record semantics;
- run its own literal mutation registry.

Retain:

validation/independent-metadata-pointer-validator-v1.json

Require zero errors.

──────────────────────────────────────────────────────────────────────────────
17. ROOT-REBINDING MATRIX V2
──────────────────────────────────────────────────────────────────────────────

Rerun and extend the root-rebinding matrix.

In addition to the existing 30 cases, require cases for:

- each of the two predecessor incorrect pointers;
- all four correct pointers;
- pointer existence;
- pointer resolution;
- exact resolved identity;
- dependency-graph completeness;
- qualification nonauthority before closure;
- stale freeze-record identity;
- unregistered current-plan consumer.

Retain:

validation/package-root-rebinding-matrix-v2.json

Do not reuse the predecessor matrix result as current authority.

──────────────────────────────────────────────────────────────────────────────
18. TWO-ROOT DETERMINISM
──────────────────────────────────────────────────────────────────────────────

Use two audit-owned temporary candidate roots.

For each:

- copy six unchanged semantic exports;
- generate a root-bound plan;
- generate the clean V2 metadata structures;
- normalize only:
  - candidate root;
  - directly root-derived path strings;
  - plan size/SHA-256;
  - document size/SHA-256 fields transitively changed by those identities.

Require:

- normalized semantic exports byte-identical;
- normalized generated metadata byte-identical;
- exact four consumer pointers identical;
- pointer resolution passes in both roots;
- source bytes identical;
- schemas and acceptance rules identical;
- no stale predecessor path.

Retain:

validation/two-root-metadata-determinism-v1.json

Inventory and remove both roots with two fresh ENOENT observations each.

──────────────────────────────────────────────────────────────────────────────
19. FREEZE RECORD V3
──────────────────────────────────────────────────────────────────────────────

After fresh qualification passes, generate:

opening/target-audit-harness-package-freeze-v3.json

It must bind:

- final root device/inode/mode;
- exact seven export identities;
- exact plan identity at:
  /plan_identity
- root-rebinding contract V2;
- export registry V2;
- current qualification result V2;
- qualification evidence identities;
- semantic changed set:
  plan only;
- semantic unchanged set:
  six exports;
- package-root rebinding:
  explicit;
- executable control-flow change:
  false;
- acceptance-rule change:
  false;
- later export modification permitted:
  false;
- target audit executed:
  false;
- package_authority_established:
  false;
- terminal_closure_established:
  false;
- transitive_pointer_resolution_required:
  true.

Reopen every semantic export and verify exact identity.

No export may change after this freeze.

──────────────────────────────────────────────────────────────────────────────
20. TRANSITIVE POINTER RESOLUTION AFTER FREEZE
──────────────────────────────────────────────────────────────────────────────

After the freeze record exists:

1. Finalize the four-consumer registry with current document identities.
2. Run strict pointer resolution over all four consumers.
3. Run the metadata-pointer mutation matrix.
4. Run the independent metadata validator.
5. Regenerate the complete dependency graph V2.
6. Require `complete:true`.
7. Require no unresolved or unregistered acceptance-bearing consumer.

Retain:

validation/package-metadata-coherence-v1.json

This record may claim:

- metadata_coherence:
  true;
- transitive_pointer_resolution:
  true;
- qualification_result_bound:
  true;
- freeze_record_bound:
  true.

It must still claim:

- terminal_closure_established:
  false;
- package_authority_established:
  false.

Terminal package authority arises only after final capsule closure.

──────────────────────────────────────────────────────────────────────────────
21. FROZEN EXPORT REQUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Against the exact frozen seven exports and finalized metadata:

1. Verify all export identities.
2. Verify exact direct plan-pointer delta.
3. Verify root-rebinding matrix V2.
4. Verify support-binding qualification.
5. Verify finalizer qualification.
6. Verify synthetic materializations.
7. Verify synthetic finalizer causals.
8. Verify metadata-pointer matrix.
9. Verify independent metadata validator.
10. Verify actual four-pointer resolution.
11. Verify dependency-graph completeness.
12. Verify no stale predecessor package path.
13. Verify package immobility.
14. Verify cache/bytecode absence.

Retain:

validation/frozen-package-requalification-v3.json

It may claim requalification success but not terminal package authority.

Any mismatch requires:

PREFLIGHT_PROVENANCE_MISMATCH

Do not edit frozen exports or finalized metadata afterward.

──────────────────────────────────────────────────────────────────────────────
22. HISTORICAL LINEAGE
──────────────────────────────────────────────────────────────────────────────

Retain:

lineage/package-metadata-repair-lineage-v1.json

Bind:

- failed unsealed package;
- blocked closure attempt;
- sealed metadata-inconsistent predecessor;
- predecessor manifests and plan identity;
- exact two pointer defects;
- predecessor invalid qualification and requalification claims;
- new final package root;
- new plan identity;
- exact semantic changed set;
- exact generated-metadata replacement set;
- historical roots:
  noncurrent,
  nonauthoritative,
  ineligible for runtime or acceptance use.

Do not copy historical current-verdict, qualification, freeze, or confirmation
records into current paths.

──────────────────────────────────────────────────────────────────────────────
23. PACKAGE IMMOBILITY
──────────────────────────────────────────────────────────────────────────────

Retain:

analysis/package-immobility-and-root-authority-v2.json

Require:

- package is bound to this exact physical root;
- moving or copying invalidates the plan binding;
- relocation requires a new package, explicit rebind, fresh qualification, and
  fresh closure;
- no runtime root discovery;
- no fallback to any historical package;
- no latest/prefix/score authority;
- exactly one current plan;
- exactly one current payload path writer.

Do not claim root independence or portability.

──────────────────────────────────────────────────────────────────────────────
24. CACHE AND BYTECODE DISCIPLINE
──────────────────────────────────────────────────────────────────────────────

Retain:

analysis/cache-and-bytecode-posture-v2.json

Require:

- no `__pycache__`;
- no `.pyc`;
- no `.pyo`;
- no package-local bytecode cache;
- all qualification caches external;
- all external caches inventoried and removed;
- all Python processes used `-B`;
- `PYTHONDONTWRITEBYTECODE=1`;
- package payload not imported;
- compile-only checks produced no package-local cache.

A cache artifact in the package is terminal.

──────────────────────────────────────────────────────────────────────────────
25. NO REAL TARGET AUDIT
──────────────────────────────────────────────────────────────────────────────

Do not:

- execute Carrier 0003 against the real target;
- invoke the real direct finalizer;
- adjudicate target semantics;
- execute Plan commands;
- run repository tests;
- invoke product code;
- produce a target ACCEPT/BLOCK/REJECT verdict.

This task ends after fresh package qualification, metadata coherence,
freeze/requalification, and terminal package closure.

──────────────────────────────────────────────────────────────────────────────
26. SUPPLIED-ROOT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete lstat/no-follow inventories for every supplied root opened.

Require exact opening/closing equality.

Do not modify or clean supplied roots.

For every audit-owned fixture root:

- retain a complete pre-removal inventory;
- remove only that exact root;
- perform two fresh ENOENT observations;
- require zero process and descriptor survivors.

──────────────────────────────────────────────────────────────────────────────
27. PRETERMINAL REPORTING
──────────────────────────────────────────────────────────────────────────────

Before temporal inventory generation, finalize:

closeout/final-package-report-v3.md
closeout/explicit-confirmations-v3.json

The retained report must state:

- qualification passed;
- metadata coherence passed;
- exports frozen;
- package authority not yet terminal;
- terminal inventory and manifests pending.

Do not claim package current authority before closure.

Return the complete final report inline after read-only observation of the sealed
package.

Do not write another verdict file after terminal closure.

──────────────────────────────────────────────────────────────────────────────
28. TEMPORAL FINAL INVENTORY
──────────────────────────────────────────────────────────────────────────────

After every nonmanifest artifact is final, generate:

closeout/temporal-final-inventory-v3.json

Require:

- root represented;
- every current directory represented;
- every current nonmanifest regular file represented;
- exact exclusions:
  - temporal inventory itself;
  - future manifest A;
  - future manifest B;
- reserved future `manifest/` directory explicitly declared;
- stable grammar;
- no symlink;
- no special object;
- no multiply linked regular file;
- all directories mode 0700;
- all files mode 0600;
- no empty retained directory except reserved `manifest/` before manifests;
- no cache or bytecode.

Reopen and verify the inventory before manifest generation.

──────────────────────────────────────────────────────────────────────────────
29. TERMINAL MANIFEST CLOSURE
──────────────────────────────────────────────────────────────────────────────

After temporal-inventory verification:

1. Ensure the reserved `manifest/` directory exists at mode 0700.
2. Independently generate manifest A.
3. Independently generate manifest B.
4. Require generated bytes to be byte-identical.
5. Exclusively create:
   manifest/canonical-manifest-a-v3.json
6. Write/fsync/close A.
7. Exclusively create:
   manifest/canonical-manifest-b-v3.json
8. Write/fsync/close B.
9. Fsync the manifest directory.
10. Reopen both no-follow.
11. Verify size and SHA-256.
12. Require each equals its generated bytes.
13. Require A equals B.
14. Independently reproject the complete root.
15. Require reprojection equals A and B.
16. Require no retained empty directory.
17. Require no cache or bytecode.
18. Require no symlink, special object, or multiply linked file.
19. Require all modes 0700/0600.

After terminal manifest closure, perform no filesystem write.

The inline response may inspect the sealed root read-only and report terminal
identities.

──────────────────────────────────────────────────────────────────────────────
30. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

TARGET_AUDIT_HARNESS_PACKAGE_METADATA_REPAIR_READY

only when:

- every supplied root authenticates and closes;
- seven semantic exports authenticate;
- direct plan root binding is exact;
- six semantic exports remain byte-identical;
- clean V2/V3 generated metadata exists;
- exactly four acceptance-bearing plan-identity consumers exist;
- all four exact pointers resolve;
- all four resolved values equal the current plan identity;
- no unregistered acceptance-bearing consumer exists;
- dependency graph is complete;
- pointer matrix passes;
- independent metadata validator passes;
- fresh dynamic qualification passes;
- qualification result remains nonterminal before closure;
- freeze record remains nonterminal before closure;
- metadata-coherence record passes;
- frozen package requalification passes;
- no stale predecessor path remains;
- no cache or bytecode remains;
- temporal inventory verifies;
- terminal manifests exist and match;
- terminal reprojection passes;
- no write follows terminal closure;
- no real target audit ran.

Return:

TARGET_AUDIT_HARNESS_PACKAGE_METADATA_REPAIR_BLOCKED

when:

- another semantic export must change;
- an executable or acceptance-rule change is needed;
- more or fewer than four current acceptance-bearing plan consumers exist;
- pointer resolution remains ambiguous;
- qualification fails;
- metadata coherence fails;
- package closure cannot complete.

Return:

PREFLIGHT_PROVENANCE_MISMATCH

for:

- supplied-root mutation;
- closing inequality;
- source-authority mismatch;
- unauthorized semantic drift;
- frozen export mismatch;
- terminal closure failure;
- write after terminal closure.

──────────────────────────────────────────────────────────────────────────────
31. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Final package-root identity
3. Sealed predecessor identity and closure
4. Historical lineage roots
5. Exact predecessor export identities
6. Exact successor export identities
7. Direct plan-root pointer delta
8. Clean generated-metadata versions
9. Exact four-consumer registry
10. Actual four-pointer resolution
11. Complete dependency graph
12. Root-rebinding contract V2
13. Export registry V2
14. Fresh qualification result V2
15. Metadata-pointer mutation matrix
16. Independent metadata validator
17. Root-rebinding matrix V2
18. Two-root metadata determinism
19. Fresh support-binding qualification
20. Fresh finalizer qualification
21. Synthetic Carrier 0003 materializations
22. Synthetic finalizer causals
23. Freeze record V3
24. Metadata-coherence result
25. Frozen-package requalification V3
26. Historical lineage
27. Package immobility result
28. Cache and bytecode posture
29. Supplied-root closing equality
30. Temporal inventory identity
31. Manifest A identity
32. Manifest B identity
33. Independent terminal reprojection
34. Terminal membership and modes
35. No-write-after-closure result
36. Confirmation real target audit did not run
37. Remaining uncertainty and nonclaims
38. Explicit confirmations

Required confirmations:

SEALED_PREDECESSOR_ROOT_MUTATION_NOT_PERFORMED
FAILED_UNSEALED_PACKAGE_ROOT_MUTATION_NOT_PERFORMED
BLOCKED_CLOSURE_ATTEMPT_ROOT_MUTATION_NOT_PERFORMED
RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
EXACT_SEVEN_PREDECESSOR_EXPORT_IDENTITIES_AUTHENTICATED
SIX_SUCCESSOR_EXPORTS_BYTE_IDENTICAL
DIRECT_PLAN_ROOT_POINTER_REBOUND_EXPLICITLY
PLAN_SEMANTIC_FIELD_MAP_UNCHANGED
EXECUTABLE_SOURCE_CONTROL_FLOW_UNCHANGED
TARGET_AUDIT_ACCEPTANCE_RULES_UNCHANGED
CLEAN_VERSIONED_METADATA_GENERATED
EXACTLY_FOUR_ACCEPTANCE_BEARING_PLAN_IDENTITY_CONSUMERS
ROOT_REBINDING_CONSUMER_POINTER_RESOLVED
EXPORT_REGISTRY_CONSUMER_POINTER_RESOLVED
QUALIFICATION_RESULT_CONSUMER_POINTER_RESOLVED
FREEZE_RECORD_CONSUMER_POINTER_RESOLVED
ALL_RESOLVED_PLAN_IDENTITIES_EQUAL
NO_UNREGISTERED_ACCEPTANCE_BEARING_PLAN_CONSUMER
COMPLETE_EXPORT_DEPENDENCY_GRAPH_PRODUCED
METADATA_POINTER_MUTATION_MATRIX_PASSED
INDEPENDENT_METADATA_POINTER_VALIDATOR_PASSED
PACKAGE_ROOT_REBINDING_MATRIX_V2_PASSED
TWO_ROOT_METADATA_DETERMINISM_PASSED
FRESH_SUPPORT_BINDING_QUALIFICATION_PASSED
FRESH_FINALIZER_QUALIFICATION_PASSED
TWO_SYNTHETIC_CARRIER_0003_MATERIALIZATIONS_PASSED
SYNTHETIC_FINALIZER_CAUSALS_PASSED
CURRENT_QUALIFICATION_RESULT_NONTERMINAL_BEFORE_CLOSURE
FREEZE_RECORD_NONTERMINAL_BEFORE_CLOSURE
PACKAGE_METADATA_COHERENCE_PASSED
FROZEN_PACKAGE_REQUALIFICATION_V3_PASSED
HISTORICAL_PACKAGES_NONCURRENT
PACKAGE_PHYSICALLY_ROOT_BOUND
PACKAGE_RELOCATION_UNSUPPORTED
NO_RUNTIME_ROOT_DISCOVERY
NO_ROOT_FALLBACK
NO_LATEST_OR_SCORE_SELECTION
NO_BYTECODE_CACHE_RETAINED
NO_PYC_RETAINED
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
TEMPORAL_FINAL_INVENTORY_CREATED
TEMPORAL_FINAL_INVENTORY_VERIFIED
TERMINAL_MANIFEST_A_CREATED
TERMINAL_MANIFEST_B_CREATED
TERMINAL_MANIFESTS_BYTE_IDENTICAL
INDEPENDENT_TERMINAL_REPROJECTION_PASSED
NO_EMPTY_DIRECTORY_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_WRITE_AFTER_TERMINAL_CLOSURE
REAL_TARGET_AUDIT_NOT_EXECUTED
RUNTIME_VALIDATION_NOT_RERUN
NO_GIT_INVOCATION
NO_NETWORK_CONTACT
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

After `TARGET_AUDIT_HARNESS_PACKAGE_METADATA_REPAIR_READY`, execute one fresh
target audit using the accepted bootstrap and this exact sealed package. Do not
copy, move, edit, or regenerate the package.
```

The current sealed root must remain unchanged and must not be used for the target audit.

**Source:** Codex’s `PREFLIGHT_PROVENANCE_MISMATCH` report in the current turn.

**Confidence:** 1.00 that the current sealed root is nonauthoritative; 0.995 that the remaining defects are generated-metadata pointer defects; 0.97 that a clean versioned-metadata successor with fresh qualification is the narrowest sound repair.
