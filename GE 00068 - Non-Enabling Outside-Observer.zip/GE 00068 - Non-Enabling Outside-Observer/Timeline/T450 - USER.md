Here is Codex's response:

# `HARNESS_REPAIR_PROVENANCE_MISMATCH`

### 1. Primary verdict

The fixed predecessor cannot be authenticated against the supplied blocked-status identity. The repair stopped before source copying, compilation, or any source attempt.

### 2. Fresh successor repair-root identity

Operative root:

[`/Users/ds/Downloads/ES-repair10i-v3-gen2-independent-audit-harness-terminal-adapter-repair-h3yhmdqh`](/Users/ds/Downloads/ES-repair10i-v3-gen2-independent-audit-harness-terminal-adapter-repair-h3yhmdqh)

- Device: `16777234`
- Inode: `181097643`
- Mode: `0700`
- Allocation: `tempfile.mkdtemp`
- Umask: `077`

### 3. Predecessor blocked repair-root identity and closure

Predecessor:

[`/Users/ds/Downloads/ES-repair10i-v3-gen2-independent-audit-harness-repair-y0atdjv6`](/Users/ds/Downloads/ES-repair10i-v3-gen2-independent-audit-harness-repair-y0atdjv6)

- Device: `16777234`
- Inode: `181082379`
- Mode: `0700`
- Classification: `historical_blocked_terminal_adapter_repair_predecessor`

Authenticated closure evidence:

- Temporal inventory: inode `181094949`, size `32055`, SHA-256 `c6a3532ff28528f95b61d66ab4c7667f605996db5a65b3ff2abefad13eaad4ab`
- Manifest A: inode `181094947`, size `33301`, SHA-256 `0a012d51d1bd2608c4a9208e0986f1291602e8dc7586cbb4f9784f62c2572ebf`
- Manifest B: inode `181094948`, size `33301`, same SHA-256
- Manifest pair byte-identical: yes
- Temporal and both manifest reprojections: passed
- Root row: exactly once
- Physical topology: 115 objects, 23 directories, 92 regular files
- Failure closeout SHA-256: `e2c6fffee7a36a4c9389a318abf6161fe255b47456465bb0273baba7bff4c8c1`

The fixed blocked-status identity failed:

- Supplied expected value: `fad5526228906c0845ddc409c13838e666df92aba6dc0556`
- Supplied length: `48` hexadecimal characters
- Required SHA-256 length: `64`
- Actual file SHA-256: `fad5526228906c0845f9b34d6e3d0a1845ddc409c13838e666df92aba6dc0556`

Evidence: [predecessor authentication](/Users/ds/Downloads/ES-repair10i-v3-gen2-independent-audit-harness-terminal-adapter-repair-h3yhmdqh/opening/predecessor-repair-root-authentication-v1.json) and [provenance mismatch](/Users/ds/Downloads/ES-repair10i-v3-gen2-independent-audit-harness-terminal-adapter-repair-h3yhmdqh/analysis/fixed-predecessor-provenance-mismatch-v1.json).

### 4. Exact Attempt-2 source authority

The current registry authenticated before the stop:

- Registry: six sources, fourteen roles
- Registry SHA-256: `910eb1a344f73bc1d9679b32c9af1ca038a5f6219454fdb0322fbb0f9a1fc6bb`
- Audit parent: size `239303`, SHA-256 `1caa2554c923ce2f1e9bc684301860654bfd18b1a18e614613e7115eafce7d6c`
- Repair core: size `46559`, SHA-256 `adaecf6cf565748a95e2afe2059ea811638fbbae60188d8133adb3b69ccb65d5`
- Qualification driver: size `59954`, SHA-256 `c55912bd92be12f844761e3f2a04f4ee878c528d3b665b36bde535fd00ed3e48`
- Independent validator: size `18809`, SHA-256 `2345012ade8e63c3a5e96a19c57b42be2428c8a284238cbe69bdc81479bdca21`
- Recorder: size `6209`, SHA-256 `ec724c7dd00feb63d918cc8497336b01d681b542b0aa7e76f5b7dc0fec40119a`
- Platform capture: size `3344`, SHA-256 `1a53f3d74297c42e0e7d9002fed551dca685caed280357a657910c40e2d85670`

No Attempt-1 source was promoted. No source was copied into a successor attempt.

Authority record: [attempt-2-source-authority-v1.json](/Users/ds/Downloads/ES-repair10i-v3-gen2-independent-audit-harness-terminal-adapter-repair-h3yhmdqh/opening/attempt-2-source-authority-v1.json).

### 5. Original failed-audit identity and disposition

The original failed-audit root remained read-only and unadjudicated. Its opening and closing inventories were equal.

Inventory digest:

`de3a62f894eafdea54d0af85914d41c614804ea83c1b66add27da08e73c7f3bd`

### 6. Implementation-package identity and closing equality

Implementation root:

`/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634`

- Device: `16777234`
- Inode: `180884963`
- Mode: `0700`
- Inventory digest: `d272be8e9ea33eab1cd5f78c8840b4d5d073df6704d916d41981110b9c952b4e`
- Opening/closing equality: passed
- Mutated: no
- Readjudicated: no
- Production source executed: no

### 7. Successor Generation-2 identity and closing equality

Successor root:

`/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-bootstrap-order-repair-t9kydqve`

- Device: `16777234`
- Inode: `180871216`
- Mode: `0700`
- Inventory digest: `8f8f383aae4bf5ebf96ea6c5ca053f6fe6e69f8bb318ee0272c68d7701fac0f6`
- Opening/closing equality: passed
- Mutated: no

### 8. External-root identities and closing equality

All remained read-only and closed equal:

- Authoritative contract: inode `180472094`, digest `0cb2062afdd960a56792f90420e4f491b65f836886584dca586f0ed161831d36`
- Schema source: inode `180513083`, digest `89b95b973e4e8158668c10dabf04fa66bb3a205ad048579c271e4f3f57fa450a`
- Schema reconciliation: inode `180480821`, digest `86ed69482adb4e20cdcdb47aab002178560229a702f91505be137478c0e2c889`
- Validation specification: inode `180576497`, digest `712600a53799b082cce3e015f497772d96230b9e0a27d8c28e422af450eae019`

### 9. Attempt-2 failed-root identity and closing equality

Root:

`/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-hqsolb0v`

- Device: `16777234`
- Inode: `180892391`
- Mode: `0700`
- Inventory digest: `778d0c6e41b3d80ce8a9f326782a0c868af2b5dad8332a24b1c65af04e6297f1`
- Opening/closing equality: passed
- Mutated: no

### 10. Exact terminal-adapter blocker reproduction

The source-level defect chain was authenticated:

1. `repair_core.close_capsule()` returns root identity at `/inventory/root_identity`.
2. It does not return `/audit_root_identity`.
3. `repair_core.seal_audit()` forwards the result unchanged.
4. `Audit.build_inline_report()` indexes `terminal["audit_root_identity"]`.
5. The path raises `KeyError("audit_root_identity")`.
6. Marker and verdict preparation cannot complete.

Relevant predecessor ranges:

- `Audit.build_inline_report`: lines 4041–4199
- `Audit.seal_terminal_capsule`: lines 4201–4349
- `repair_core.close_capsule`: lines 891–1025
- `repair_core.seal_audit`: lines 1028–1048

The prior matrices stopped at `close_capsule`; the prior validator did not exercise the real `seal_audit()` → `build_inline_report()` integration.

### 11. Terminal-adapter authority adjudication

Existing evidence indicates `/inventory/root_identity` is the sole authoritative value and no governing lifecycle contract requires a top-level alias.

Because fixed-predecessor authentication failed first, this finding was not frozen as a successor authority adjudication.

### 12. Canonical terminal-result schema

Not generated. Provenance failure stopped work before successor contracts or source were created.

### 13. Canonical audit-root-identity pointer

The predecessor evidence supports `/inventory/root_identity`, but no successor contract froze it.

### 14. Duplicate root-identity alias

No alias was introduced because no repaired source candidate was produced.

### 15. Complete cross-module interface registry

Not generated. No acceptance-bearing interface registry may be claimed from an unauthenticated fixed predecessor.

### 16. Repair authority and source surface

Authority stopped at fixed-input authentication. No production or qualification source was modified.

### 17. Source-attempt ledger

- Authorized attempts: `2`
- Complete attempts begun: `0`
- Compilation begun: no
- Candidate registry closed: no
- Attempt 3 created: no

Ledger: [source-attempt-ledger-v1.json](/Users/ds/Downloads/ES-repair10i-v3-gen2-independent-audit-harness-terminal-adapter-repair-h3yhmdqh/closing/source-attempt-ledger-v1.json).

### 18. Final repaired source registry

Not generated. The authenticated predecessor registry remains historical evidence only.

### 19. Exact source delta

No repaired-source delta exists. No source bytes were copied or changed after the provenance failure.

### 20. Protected-function equality

Not adjudicated against a successor candidate because no candidate existed.

### 21. Terminal-adapter integration matrix

Not run.

### 22. Cross-module interface matrix

Not run.

### 23. Static and bytecode interface gates

Not run.

### 24. Prior 209-case qualification regression

Not run. Prior results were inspected only as historical predecessor evidence.

### 25. Synthetic success terminal path

Not run.

### 26. Synthetic BLOCK terminal path

Not run.

### 27. Synthetic zero-root failure path

Not run.

### 28. Synthetic one-root failure path

Not run.

### 29. Synthetic temporal failure path

Not run.

### 30. Synthetic manifest-B failure path

Not run.

### 31. Bounded read-only live replay

Not run.

### 32. Independent terminal-adapter validator

Not implemented or run.

### 33. Source freeze

No repaired source existed to freeze.

### 34. Frozen-source requalification

Not run.

### 35. Implementation production source execution

Confirmed absent.

### 36. Full independent audit execution

Confirmed absent.

### 37. Harness-package status

- Status: `terminal-adapter-repair-provenance-mismatch`
- Harness authority: false
- Source attempts begun: `0`
- Repaired source frozen: false
- Terminal success seal: false
- Implementation mutated: false
- Implementation adjudicated: false
- Target audit executed: false
- Runtime validation rerun: false
- A6 started: false

Status identity:

- Size: `482`
- SHA-256: `e77dd2def31baf6918cbb26fd1727b9b051a62ae477f5b3e7329085d0c087def`

### 38. Supplied-root closing equality

All nine opened supplied roots closed exactly equal.

[Closing-equality record](/Users/ds/Downloads/ES-repair10i-v3-gen2-independent-audit-harness-terminal-adapter-repair-h3yhmdqh/closing/supplied-root-closing-equality-final-v1.json):

- Inode: `181102861`
- Mode: `0600`
- Size: `275366`
- SHA-256: `ab46434bcb726e4bbce47b6b3bae88a138a2c6e4306a57be078d9128bbf1cc78`

### 39. Fixture cleanup

No qualification fixture root was created. Process survivors and open child descriptors were both zero.

An initial empty allocation candidate created by a bootstrap-command typo was inspected as containing only an empty `opening/` directory and removed before allocating the operative root.

### 40. Failure-closeout capability and use

Failure closeout retained the fixed mismatch, opening authority, process custody, complete supplied-root equality, confirmation registry, status, report, and preclose inventory.

No success manifests were created.

[Failure closeout](/Users/ds/Downloads/ES-repair10i-v3-gen2-independent-audit-harness-terminal-adapter-repair-h3yhmdqh/closeout/failure-closeout-v1.json):

- Size: `2869`
- SHA-256: `99e202ebf68fe60ff248cb12dc0823144574a459560c08474184ece91adf722c`

### 41. Temporal-inventory identity

No successor success temporal inventory was created.

### 42. Manifest A identity

Not created.

### 43. Manifest B identity

Not created.

### 44. Independent terminal reprojection

Not applicable because no terminal success closure occurred.

### 45. Terminal membership and modes

Final failure-package topology:

- Objects including root: `24`
- Directories including root: `7`
- Regular files: `17`
- Empty descendants: `0`
- Symlinks: `0`
- Special objects: `0`
- Multiply linked regular files: `0`
- Cache or bytecode artifacts: `0`
- Directory modes: all `0700`
- File modes: all `0600`

This is clean failure evidence, not a success-sealed harness capsule.

### 46. No-write-after-closure

No filesystem operation was performed after the final failure-closeout observation. The required terminal-success confirmation remains unestablished because no terminal success seal occurred.

### 47. Incremental-lineage terminality disposition

No source attempt began, so attempt-budget exhaustion and lineage retirement were not adjudicated.

Further localized repair was not authorized or recommended in this result. A valid fixed-predecessor authority would be required before any repair work could begin.

### 48. Remaining uncertainty and nonclaims

This result makes no claim of:

- Terminal-adapter repair
- Closed cross-module interfaces
- Harness qualification or readiness
- Repaired-source freeze
- Implementation acceptance or rejection
- Product/runtime behavior
- Target-audit execution
- Runtime validation
- Deployment, publication, or A6 activity

Report artifacts:

- [Operative report](/Users/ds/Downloads/ES-repair10i-v3-gen2-independent-audit-harness-terminal-adapter-repair-h3yhmdqh/report/final-operative-report-v1.md) — SHA-256 `7c6d07acc6528bf33e1abbc3d1ab02c701956f215119b46eefe862e8ea9812da`
- [Report data](/Users/ds/Downloads/ES-repair10i-v3-gen2-independent-audit-harness-terminal-adapter-repair-h3yhmdqh/report/final-operative-report-data-v1.json) — SHA-256 `85a8a6b676ac23284625b4a8098ddba73f2a85e81fac0c8dd686480419f63346`

### 49. Explicit confirmation registry

There are 83 confirmations: 38 confirmed and 45 not confirmed.

```text
01  PREDECESSOR_REPAIR_ROOT_MUTATION_NOT_PERFORMED                 CONFIRMED
02  PREDECESSOR_REPAIR_ROOT_NOT_RESUMED                            CONFIRMED
03  EXACT_ATTEMPT_2_SOURCE_AUTHORITY_ESTABLISHED                   CONFIRMED
04  ATTEMPT_1_SOURCE_NOT_PROMOTED                                  CONFIRMED
05  ORIGINAL_FAILED_AUDIT_ROOT_MUTATION_NOT_PERFORMED              CONFIRMED
06  IMPLEMENTATION_PACKAGE_MUTATION_NOT_PERFORMED                  CONFIRMED
07  IMPLEMENTATION_PACKAGE_NOT_READJUDICATED                       CONFIRMED
08  SUCCESSOR_GEN2_PACKAGE_MUTATION_NOT_PERFORMED                  CONFIRMED
09  AUTHORITATIVE_CONTRACT_PACKAGE_MUTATION_NOT_PERFORMED          CONFIRMED
10  SCHEMA_SOURCE_PACKAGE_MUTATION_NOT_PERFORMED                   CONFIRMED
11  SCHEMA_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED              CONFIRMED
12  VALIDATION_SPEC_SOURCE_MUTATION_NOT_PERFORMED                  CONFIRMED
13  ATTEMPT_2_FAILED_ROOT_MUTATION_NOT_PERFORMED                   CONFIRMED
14  TERMINAL_ADAPTER_MISMATCH_REPRODUCED                           CONFIRMED
15  PROVIDER_RETURN_SHAPE_AUTHENTICATED                            CONFIRMED
16  CONSUMER_REQUIRED_SHAPE_AUTHENTICATED                          CONFIRMED
17  CANONICAL_ROOT_IDENTITY_POINTER_FROZEN                         NOT_CONFIRMED
18  CANONICAL_ROOT_IDENTITY_POINTER_IS_INVENTORY_ROOT_IDENTITY     NOT_CONFIRMED
19  TOP_LEVEL_ROOT_IDENTITY_ALIAS_NOT_INTRODUCED                   CONFIRMED
20  TERMINAL_ADAPTER_CONTRACT_CLOSED                               NOT_CONFIRMED
21  TERMINAL_ADAPTER_TOTAL_ACCESSOR_IMPLEMENTED                    NOT_CONFIRMED
22  NO_TERMINAL_ADAPTER_POINTER_FALLBACK                           NOT_CONFIRMED
23  COMPLETE_CROSS_MODULE_INTERFACE_REGISTRY_PRODUCED              NOT_CONFIRMED
24  EVERY_ACCEPTANCE_BEARING_CROSS_MODULE_INTERFACE_REGISTERED     NOT_CONFIRMED
25  EVERY_REGISTERED_INTERFACE_DIRECTLY_TESTED                     NOT_CONFIRMED
26  REPAIR_BOUNDED_TO_TERMINAL_ADAPTER_AND_INTERFACE_COVERAGE      CONFIRMED
27  PACKAGE_ACCEPTANCE_RULES_UNCHANGED                             CONFIRMED
28  PACKAGE_VERDICT_CONSTANTS_UNCHANGED                            CONFIRMED
29  UNRELATED_AUDIT_FUNCTIONS_AST_IDENTICAL                        NOT_CONFIRMED
30  SOURCE_ATTEMPT_LIMIT_RESPECTED                                 CONFIRMED
31  TERMINAL_ADAPTER_SUCCESS_PATH_PASSED                           NOT_CONFIRMED
32  TERMINAL_ADAPTER_BLOCK_PATH_PASSED                             NOT_CONFIRMED
33  TERMINAL_ADAPTER_AUDIT_FAILURE_PATH_PASSED                     NOT_CONFIRMED
34  OLD_KEYERROR_PATH_REJECTED_BY_REGRESSION                       NOT_CONFIRMED
35  MISSING_INVENTORY_REJECTED                                    NOT_CONFIRMED
36  WRONG_INVENTORY_TYPE_REJECTED                                 NOT_CONFIRMED
37  MISSING_ROOT_IDENTITY_REJECTED                                 NOT_CONFIRMED
38  TOP_LEVEL_ALIAS_ONLY_REJECTED                                  NOT_CONFIRMED
39  CONFLICTING_ROOT_IDENTITY_ALIAS_REJECTED                       NOT_CONFIRMED
40  NO_FILESYSTEM_OPERATION_IN_POSTSEAL_ADAPTER_PATH               NOT_CONFIRMED
41  TERMINAL_ADAPTER_MATRIX_PASSED                                 NOT_CONFIRMED
42  CROSS_MODULE_INTERFACE_MATRIX_PASSED                           NOT_CONFIRMED
43  STATIC_INTERFACE_GATES_PASSED                                  NOT_CONFIRMED
44  BYTECODE_INTERFACE_GATES_PASSED                                NOT_CONFIRMED
45  PRIOR_209_CASE_REGRESSION_PASSED                               NOT_CONFIRMED
46  SYNTHETIC_SUCCESS_CAPSULE_PASSED                               NOT_CONFIRMED
47  SYNTHETIC_BLOCK_CAPSULE_PASSED                                 NOT_CONFIRMED
48  SYNTHETIC_ZERO_ROOT_FAILURE_CAPSULE_PASSED                     NOT_CONFIRMED
49  SYNTHETIC_ONE_ROOT_FAILURE_CAPSULE_PASSED                      NOT_CONFIRMED
50  SYNTHETIC_TEMPORAL_FAILURE_CAUSAL_PASSED                       NOT_CONFIRMED
51  SYNTHETIC_MANIFEST_B_FAILURE_CAUSAL_PASSED                     NOT_CONFIRMED
52  BOUNDED_LIVE_REPLAY_PASSED                                     NOT_CONFIRMED
53  INDEPENDENT_TERMINAL_ADAPTER_VALIDATOR_PASSED                  NOT_CONFIRMED
54  INDEPENDENT_VALIDATOR_EXERCISED_REAL_SEAL_TO_REPORT_PATH       NOT_CONFIRMED
55  REPAIRED_HARNESS_SOURCE_FROZEN                                 NOT_CONFIRMED
56  REPAIRED_HARNESS_SOURCE_NOT_MODIFIED_AFTER_FREEZE              NOT_CONFIRMED
57  FROZEN_HARNESS_REQUALIFICATION_PASSED                          NOT_CONFIRMED
58  IMPLEMENTATION_PRODUCTION_SOURCE_NOT_EXECUTED                  CONFIRMED
59  FULL_INDEPENDENT_AUDIT_NOT_EXECUTED                            CONFIRMED
60  SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED                          CONFIRMED
61  NO_PROCESS_SURVIVOR                                            CONFIRMED
62  NO_DESCRIPTOR_SURVIVOR                                         CONFIRMED
63  NO_CACHE_OR_BYTECODE_RETAINED                                  CONFIRMED
64  SUCCESSOR_HARNESS_TEMPORAL_INVENTORY_CREATED                   NOT_CONFIRMED
65  SUCCESSOR_HARNESS_TEMPORAL_INVENTORY_VERIFIED                  NOT_CONFIRMED
66  SUCCESSOR_HARNESS_MANIFEST_A_CREATED                           NOT_CONFIRMED
67  SUCCESSOR_HARNESS_MANIFEST_B_CREATED                           NOT_CONFIRMED
68  SUCCESSOR_HARNESS_MANIFESTS_BYTE_IDENTICAL                     NOT_CONFIRMED
69  SUCCESSOR_HARNESS_TERMINAL_REPROJECTION_PASSED                 NOT_CONFIRMED
70  SUCCESSOR_HARNESS_ROOT_ROW_PRESENT_EXACTLY_ONCE                NOT_CONFIRMED
71  NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE                        NOT_CONFIRMED
72  NO_SYMLINK_OR_SPECIAL_OBJECT                                   CONFIRMED
73  NO_MULTIPLY_LINKED_FILE                                        CONFIRMED
74  ALL_DIRECTORY_MODES_0700                                       CONFIRMED
75  ALL_FILE_MODES_0600                                            CONFIRMED
76  NO_WRITE_AFTER_TERMINAL_CLOSURE                                NOT_CONFIRMED
77  NO_NETWORK_CONTACT                                             CONFIRMED
78  NO_GIT_INVOCATION                                              CONFIRMED
79  NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION                          CONFIRMED
80  NO_TARGET_AUDIT_EXECUTED                                       CONFIRMED
81  NO_RUNTIME_VALIDATION_RERUN                                    CONFIRMED
82  NO_A6_ACTIVITY                                                 CONFIRMED
83  NO_SUBAGENTS_CREATED                                           CONFIRMED
```

Registry artifact: [explicit-confirmations-v1.json](/Users/ds/Downloads/ES-repair10i-v3-gen2-independent-audit-harness-terminal-adapter-repair-h3yhmdqh/report/explicit-confirmations-v1.json), SHA-256 `674e3075bf43cadc59dac2f8f83178bae3ad221d303afda502c0e855ab6dba7f`.
