## Engineering assessment

This candidate is now **terminally retired**, exactly as the preceding repair contract required. Both actual repaired-source attempts were consumed, Attempt 2 failed, and the retained disposition is:

- `repair_candidate_retired=true`
- `further_localized_repair_authorized=false`
- `new_clean_implementation_generation_required=true` :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"}

The result still establishes important facts:

- The original `cleanup_rows`/`cleanup_roots` defect was successfully repaired.
- A canonical typed cleanup-result contract was established.
- The complete cross-module set was derived as 31 interfaces, with exact derived/registered/directly-tested/independently-tested ID-set equality.
- Precompilation conformance, compilation, static gates, the 57-case cleanup matrix, the 372-case interface matrix, all 390 D01–D10 cases, process custody, synthetic verdict lanes, compatibility replay, cleanup causals, both rehearsals, and normalized rehearsal equality all passed. :chatgpt-content-reference{index="2"} :chatgpt-content-reference{index="3"} :chatgpt-content-reference{index="4"}

The final blocker was a **qualification-policy modeling defect**, not a newly demonstrated implementation-package defect:

- Interface `I08` had valid provider and consumer candidates and valid call sites.
- Its registry metadata described “absolute/relative path rendering only.”
- The independent validator incorrectly required every interface row’s `alias` field to equal `forbidden`.
- That conflated semantic field aliasing with governed path-rendering equivalence. :chatgpt-content-reference{index="5"}

Two additional contract-model defects were already visible:

- interface `I30` described a 59-section report while the task required 58;
- the confirmation artifact contained 96 entries by appending a verdict token to the 95 requested confirmations. :chatgpt-content-reference{index="6"}

The candidate cannot be promoted despite its extensive positive evidence. It never reached source freeze, frozen requalification, or terminal package closure. The implementation package remains unchanged, unexecuted, and unadjudicated; all supplied roots closed equal and cleanup completed. :chatgpt-content-reference{index="7"}

### Progression decision

Begin a **new clean audit-harness implementation generation**.

Do not copy, patch, import, transform, or use as an AST/source origin any source from:

- the retired incremental harness;
- the blocked clean implementation;
- the Git-disqualified repair;
- the final interface-repair candidate.

Their reports, contracts, registries, and defect records may be used only as historical requirements and negative evidence.

The new generation must freeze—before source creation—fourteen defect-prevention surfaces:

1. the previous D01–D10 surfaces;
2. canonical cleanup-result semantics;
3. typed interface metadata separating field aliasing from path-rendering policy;
4. report-section registry semantics;
5. exact confirmation registry and separate verdict authority.

```text
NEW CLEAN IMPLEMENTATION GENERATION OF THE SOURCE-EXTERNAL
INDEPENDENT AUDIT HARNESS FOR THE SEALED GENERATION-2
SCHEMA-SUBJECT RECONSTRUCTION-PARENT IMPLEMENTATION

Objective

Implement a new clean-room generation of the source-external independent audit
harness from current governing contracts, schemas, validation specifications,
and the terminal audit-defect reconciliation.

The new generation must incorporate the complete historical defect catalogue,
including the terminal cleanup-interface repair failure, without copying,
patching, importing, executing, transforming, or using as an AST/bytecode
origin any historical audit-harness source.

Qualify, freeze, requalify, and terminally close the new harness package.

Do not execute the fresh full implementation-package audit in this task.

Do not modify or adjudicate the sealed implementation package.

Do not execute the implementation reconstruction parent.

Do not construct the authoritative current schema subject.

Do not perform another historical findings reconciliation.

Do not perform another localized repair of either retired harness lineage.

Do not create subagents or direct auditors.
Do not use Git or another VCS.
Do not use the network.
Do not install dependencies.
Do not invoke product or live-service behavior.
Do not deploy, publish, externally commit, or start A6.

Use one finite parent-owned clean implementation and qualification process in
one fresh private root.

At most three complete source attempts are permitted.

Return the complete operative report inline. Artifact paths may supplement but
must not replace material identities, source authority, interfaces, matrices,
process custody, qualification results, and disposition.

Return exactly one primary verdict:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_NEW_CLEAN_AUDIT_HARNESS_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_FRESH_AUDIT

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_NEW_CLEAN_AUDIT_HARNESS_IMPLEMENTATION_BLOCKED

NEW_CLEAN_AUDIT_HARNESS_IMPLEMENTATION_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. TERMINAL HISTORICAL AUTHORITIES
──────────────────────────────────────────────────────────────────────────────

FINAL_FINDINGS_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-gen2-implementation-audit-block-findings-reconciliation-1cinwqpj

Expected identity:

- device/inode:
  16777234 / 181119472
- mode:
  0700
- verdict:
  GEN2_IMPLEMENTATION_AUDIT_BLOCK_RECONCILED_AUDIT_HARNESS_REIMPLEMENTATION_REQUIRED
- mandatory treatment:
  CLEAN_SOURCE_EXTERNAL_AUDIT_HARNESS_REIMPLEMENTATION_THEN_FRESH_AUDIT

Authenticate:

- complete 29-finding ledger;
- audit-source predicate crosswalk;
- validation-lane adjudication;
- rehearsal adjudication;
- dependency graph;
- mandatory next engineering treatment;
- supplied-root equality;
- terminal inventory and manifests.

Treat this root as the semantic authority for:

- zero verified implementation-package defects;
- 23 primary audit defects;
- six derivative failures;
- ten deduplicated defect surfaces;
- retirement of the incremental harness lineage;
- requirement for clean source-external harness implementation.

Do not reinterpret F01–F29.

Do not run another findings reconciliation.

──────────────────────────────────────────────────────────────────────────────
2. RETIRED AND BLOCKED HARNESS LINEAGES
──────────────────────────────────────────────────────────────────────────────

RETIRED_INCREMENTAL_HARNESS_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-gen2-independent-audit-harness-terminal-adapter-repair-5u3oi458

BLOCKED_CLEAN_IMPLEMENTATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-source-external-independent-audit-harness-5cmvznq8

Expected blocked-clean identity:

- device/inode:
  16777234 / 181151302
- mode:
  0700
- entries:
  423
- projection:
  a3659edc8aff7ff3980a662be072b15ac67b1c44ba3ccb44a4b03f792a9a5ee0

GIT_DISQUALIFIED_REPAIR_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-audit-harness-interface-repair-4xuh1lon

Expected identity:

- device/inode:
  16777234 / 181212642
- mode:
  0700
- disposition:
  historical process-policy violation before source attempt
- complete source attempts:
  0

FINAL_INTERFACE_REPAIR_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-audit-harness-interface-repair-clean-shv_7p0b

Expected identity:

- device/inode:
  16777234 / 181400197
- mode:
  0700
- verdict:
  SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_CLEAN_AUDIT_HARNESS_INTERFACE_REPAIR_BLOCKED
- source attempts consumed:
  2 / 2
- candidate retired:
  true
- further localized repair:
  false
- new clean implementation generation:
  required

Authenticate in the final interface-repair root:

Final source-attempt ledger:

- inode:
  181415014
- size:
  695
- SHA-256:
  89bc657e7a6ddfc120bcb05fa032e35a608d171ea6046f3ace60af5aa4de1445

Attempt-2 production registry:

- inode:
  181411725
- size:
  5998
- SHA-256:
  1b6861d9107debe981551160d143060169dc9f6fc87916797e4212a181cc07c0

Attempt-2 qualification registry:

- inode:
  181411726
- size:
  3357
- SHA-256:
  86c6248187b3ef5ef8b47cd49bb4b5086a21f3a8c07f4328d80bedaca014400d

Attempt-2 independent registry:

- inode:
  181411727
- size:
  1892
- SHA-256:
  43c3b04f3589a919ca3ad6edb2cde79692d4a77a8b5786c3f107726605bde20b

Complete interface registry:

- path:
  contract/clean-harness-cross-module-interface-registry-attempt-2-v3.json
- inode:
  181411723
- size:
  41840
- SHA-256:
  04c1d9c7b33c70b42f41b8c6925ef085ea702ffbaa37b935db8163e9191cbb43

Independent-interface failure:

- inode:
  181415009
- size:
  2909
- SHA-256:
  9173e28a2e2c08e1318c47fff8811161922d261ed3e6b82a2c16eb3101a1e56c

Supplied-root equality:

- inode:
  181415011
- size:
  4537
- SHA-256:
  d8cf1dad3d4c5f18114db1d6873c3357c4a5dd3d69f437c3181183005640e3fa

Failure closeout:

- inode:
  181415015
- size:
  14843
- SHA-256:
  704ea0c472a0f926c37777048f5383a8957b7c46e1eec1d44edebae85f1322e3

Classify every historical harness root as:

- immutable;
- noncurrent;
- nonauthoritative;
- not a source base;
- not resumable;
- not cleanable in this task;
- usable only for fixed identity, defect evidence, and supplied-root equality.

HISTORICAL SOURCE PROHIBITION

No historical harness source may be:

- copied;
- patched;
- imported;
- executed;
- transformed;
- mechanically translated;
- used as a template;
- used as an AST origin;
- used as a bytecode origin;
- used as a source-snippet origin.

Source bytes may be hashed and identity-authenticated, but not read as
implementation input.

Historical reports, contracts, registries, and failure records may be read as
requirements and defect evidence.

Require complete opening/closing equality for every historical root opened.

──────────────────────────────────────────────────────────────────────────────
3. SEALED IMPLEMENTATION PACKAGE — FUTURE AUDIT SUBJECT
──────────────────────────────────────────────────────────────────────────────

IMPLEMENTATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634

Expected identity:

- device/inode:
  16777234 / 180884963
- mode:
  0700
- producer verdict:
  SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_INDEPENDENT_AUDIT

Expected physical closure:

- entries:
  112
- directories:
  17
- regular files:
  95
- temporal represented rows:
  109
- manifest represented rows:
  110

Expected production registry:

- inode:
  180895418
- size:
  704
- SHA-256:
  1ded4df7836c16a153b6aab587d7d41903f1d8e907903a0000ae0efb518962c4

Expected production source:

- size:
  65305
- SHA-256:
  8edb8790e140560de891830919571e616852df8b7878d9d4e403fb0dde70bc6e

Expected qualification registry:

- inode:
  180895419
- size:
  4391
- SHA-256:
  57c22b15bab5667d32f9949867f198eddd41b0d345ad1d30111370c6c1548a8c

Expected source freeze:

- size:
  4057
- SHA-256:
  678f4fb76c4bab0d686e106911e28eb34328e0abdc280cee38cca6a8265e135b

Expected frozen requalification:

- size:
  31819
- SHA-256:
  5e48332bec6610032ea14067eeecda20f653a14af03d0d27f9edc09db862e21f

Use this root only for bounded read-only compatibility qualification.

Do not:

- execute the production reconstruction parent;
- mutate, resume, repair, or reseal the package;
- issue an implementation verdict in this task.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
4. CURRENT GOVERNING ROOTS
──────────────────────────────────────────────────────────────────────────────

GEN2_SUCCESSOR_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-bootstrap-order-repair-t9kydqve

Expected identity:

- device/inode:
  16777234 / 180871216
- mode:
  0700

Current role registry:

contract/current-gen2-contract-role-registry-v2.json

- inode:
  180880498
- size:
  37791
- SHA-256:
  6fb98f6558b18c22c161b9869ca3cf4752c0867307fa17b5e255d9dc21e2963f

AUTHORITATIVE_CONTRACT_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-2y6tkl0n

Expected identity:

- device/inode:
  16777234 / 180472094
- mode:
  0700

Normative contract:

- size:
  32038
- SHA-256:
  874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19

SCHEMA_SOURCE_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-repair-pw27ydqf

Expected identity:

- device/inode:
  16777234 / 180513083
- mode:
  0700

SCHEMA_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-construction-parent-schema-reconciliation-5e2lsx8t

Expected identity:

- device/inode:
  16777234 / 180480821
- mode:
  0700

VALIDATION_SPEC_SOURCE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-evidence-repair-lj_8xygs

Expected identity:

- device/inode:
  16777234 / 180576497
- mode:
  0700

ATTEMPT_2_FAILED_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-hqsolb0v

Expected identity:

- device/inode:
  16777234 / 180892391
- mode:
  0700

Use only current roles resolved through the successor registry.

Use the normative contract as sole semantic authority.

Use current schemas and current validation specifications only.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
5. FRESH NEW-GENERATION HARNESS ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root under `/Users/ds/Downloads` using:

- tempfile.mkdtemp;
- umask 077;
- prefix:

ES-repair10i-v3-gen2-new-clean-source-external-audit-harness-

Immediately emit:

HARNESS_ROOT=<absolute-path>

Retain before supplied-root inspection:

opening/bootstrap-start.json
opening/new-clean-generation-source-authority-v1.json
opening/task-process-execution-policy-v1.json

Bind:

- fresh-root identity;
- allocation method and umask;
- terminal reconciliation identity;
- historical harness roots and retirement status;
- all historical source use prohibited;
- clean source initially absent;
- implementation package mutation:
  unauthorized;
- implementation adjudication:
  unauthorized in this task;
- full audit:
  unauthorized in this task;
- real implementation rehearsals:
  unauthorized;
- current-subject construction:
  unauthorized;
- target audit/runtime/product/repository/publication/deployment/A6:
  unauthorized;
- source-attempt maximum:
  3;
- same-root retry:
  false.

Create directories lazily.

No empty directory may remain at successful terminal closure.

──────────────────────────────────────────────────────────────────────────────
6. PROCESS-EXECUTION POLICY — PRE-SOURCE
──────────────────────────────────────────────────────────────────────────────

Freeze before any child process:

contract/new-clean-harness-process-execution-policy-v1.json

Permit only exact registered executables and argv shapes for:

- pinned Python compilation;
- source-external validators;
- bounded causals;
- synthetic fixture parents;
- harness qualification rehearsals;
- platform-capture preflight.

Require one recorder for every child.

Prelaunch record:

- ordinal;
- exact executable;
- argv;
- cwd;
- explicit environment;
- stdin;
- timeout;
- fixed effects;
- dynamic-root contract;
- purpose;
- phase.

Outcome record:

- exit or signal;
- stdout bytes;
- stderr bytes;
- timeout;
- reaping;
- descriptor closure;
- fixed effects;
- dynamic effects.

Explicitly forbid:

- Git;
- every other VCS executable;
- GitPython;
- dulwich;
- pygit2;
- libgit2;
- JGit;
- `.git` metadata;
- repository-root discovery;
- VCS status/diff;
- a shell;
- PATH-based executable lookup.

Use direct no-follow lstat, stable reads, hashes, inventories, byte comparison,
and AST comparison.

An actual Git/VCS process, library use, or metadata read is:

NEW_CLEAN_AUDIT_HARNESS_IMPLEMENTATION_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
7. PRE-SOURCE OPERATING MODEL AND AUTHORITY
──────────────────────────────────────────────────────────────────────────────

Before source creation retain:

contract/new-clean-audit-harness-operating-model-v1.json
contract/new-clean-audit-harness-authority-v1.json
analysis/new-clean-audit-harness-source-architecture-v1.json

Authority:

- authenticate supplied roots;
- inspect implementation source/evidence read-only in later full-audit mode;
- run audit-owned matrices and causals;
- create disposable audit-owned rehearsals;
- retain evidence;
- clean audit-owned roots after retention;
- issue package verdicts in later full-audit mode;
- close audit capsules.

Nonauthority:

- implementation repair;
- contract or schema repair;
- current-subject construction;
- product/runtime invocation;
- repository mutation;
- publication/deployment;
- A6.

Process model:

- one finite parent;
- one recorder;
- no stdin;
- no persistent supervisor;
- no administrative continuation;
- complete streams;
- exact exit/signal;
- reaping;
- descriptor closure;
- effect attribution before cleanup;
- no shell/PATH lookup/network/Git/broad scan/latest selection/adoption.

No source may be created before this freeze passes.

──────────────────────────────────────────────────────────────────────────────
8. FOURTEEN DEFECT-PREVENTION SURFACES
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/new-clean-audit-harness-defect-prevention-registry-v1.json

Each surface must have:

- governing evidence;
- typed interface;
- production owner;
- qualification owner;
- independent-validator owner;
- direct tests;
- historical regression cases.

D01 — Attempt/status semantics

Use exact authoritative fields such as `final_source_contributor`.
No status-text scoring or arbitrary recursive selection.

D02 — Transitive freeze binding

Validate:

freeze
→ source registry
→ source identity
→ rehearsal binding
→ frozen requalification

Do not invent redundant direct-copy requirements.

D03 — Role-layout/source-registry join

Support multiple roles per source file.
Do not compare role-row count to source-registry-row count.

D04 — Path-sensitive G01 analysis

Distinguish helper presence, call reachability, phase ownership, create versus
verify, and success versus failure path.

D05 — Confirmation and terminal-marker semantics

Support:

- implementation-package 125-domain;
- constructed-subject 66-domain;
- preterminal rows;
- externally resolved terminal rows;
- hard-coded success;
- absence-as-success;
- null blocker.

D06 — Lane-specific validation adapters

One explicit adapter per lane.
No recursive or same-length-list discovery.

D07 — Typed 766/333 field-map model

Normative facts and generated enforcement rows are distinct layers.

D08 — Constructed-subject domain and grammar

Use the constructed subject’s 66-confirmation domain and
`canonical-manifest.v1` grammar.

D09 — Contract-wide physical normalization

Normalize physical facts through typed dependency propagation, not filename
tokens.

D10 — Causal findings and report projection

Only direct package observations may become package defects.
Audit defects and derivative failures remain separate.

D11 — Canonical cleanup-result semantics

One typed cleanup-result shape.
`cleanup_rows` is evidence; root sets are deterministic projections.
No `cleanup_roots` compatibility alias.

D12 — Interface metadata semantics

Separate these concepts in the interface registry:

- `field_alias_policy`;
- `path_rendering_policy`;
- `normalization_policy`.

Required fields:

`field_alias_policy`:

- enum:
  `forbidden`
- means no alternate acceptance-bearing field or pointer spelling.

`path_rendering_policy`:

- typed enum, for example:
  `exact-absolute`,
  `root-relative-normalized`,
  `absolute-or-root-relative-normalized`
- controls only path representation.

`normalization_policy`:

- exact allowed physical normalization or `none`.

A non-`none` path-rendering policy is not a field alias.

Independent validators must validate each policy by its own field and enum.

Historical I08 regression:

- valid provider/consumer;
- valid call sites;
- `field_alias_policy=forbidden`;
- governed absolute/root-relative path rendering in
  `path_rendering_policy`;
- must pass.

D13 — Report-section registry

Freeze an ordered machine-readable report-section registry before source.

Requirements:

- every section has unique ID;
- exact order;
- exact title;
- exact required/optional status;
- applicable verdict classes;
- evidence source.

The report-section count is always derived as:

`len(section_registry)`

No independent numeric literal may claim “58,” “59,” or another count.

Final report must contain exactly the registered section IDs, no missing or
extra section.

D14 — Confirmation registry and verdict separation

Freeze the exact requested confirmation-name set before source.

Requirements:

- unique confirmation names;
- count derived as `len(confirmation_names)`;
- no extra verdict token;
- no primary-verdict token inside the confirmation registry;
- primary verdict stored in a separate record;
- preterminal and terminal confirmation classes explicit;
- confirmation artifact contains exactly the frozen name set;
- report may project but may not add confirmations.

Historical regression:

- 95 requested names plus one appended verdict token must be rejected;
- exact 95-name registry plus separate verdict must pass.

──────────────────────────────────────────────────────────────────────────────
9. EXTERNAL-INTERFACE REGISTRY
──────────────────────────────────────────────────────────────────────────────

Before source, generate:

contract/new-clean-audit-harness-external-interface-registry-v1.json

Enumerate every acceptance-bearing supplied interface required for a future
audit, including:

- 41-role successor registry;
- implementation production/qualification registries;
- attempt ledger;
- source freeze;
- frozen requalification;
- producer rehearsals;
- component-role layout;
- confirmation registry and evidence map;
- ten matrix families;
- 946 cases;
- 137 cases;
- 766/333 field map;
- constructed-subject phase/results;
- constructed-subject confirmations;
- subject temporal and manifest grammars;
- Attempt-2 failure evidence;
- process and cleanup records;
- terminal capsule records.

For every interface bind:

- role ID;
- authoritative document;
- exact schema/grammar;
- exact pointer;
- row-key field;
- types;
- counts;
- uniqueness;
- digest;
- nullability;
- authority;
- applicability;
- field alias policy;
- path rendering policy;
- normalization policy;
- fallback forbidden;
- consumer;
- direct test;
- independent test.

Unknown or ambiguous interfaces fail closed.

──────────────────────────────────────────────────────────────────────────────
10. TOTAL JSON OBSERVATION MODEL
──────────────────────────────────────────────────────────────────────────────

Freeze exact statuses:

- present;
- absent;
- wrong-container-type;
- invalid-pointer-token;
- invalid-array-index;
- duplicate-key-source-invalid;
- wrong-top-level-type.

No object operation without object observation.

No array operation without array observation and bounds.

No chained `.get()` on untrusted/mutated JSON.

No missing value becomes zero, false, null, empty object/array, or success.

No generic truthiness for acceptance-bearing values.

Retain:

contract/new-clean-audit-harness-total-json-observation-v1.json

──────────────────────────────────────────────────────────────────────────────
11. REPORT AND CONFIRMATION CONTRACTS
──────────────────────────────────────────────────────────────────────────────

Before source, retain:

contract/new-clean-audit-harness-report-contract-v1.json
contract/new-clean-audit-harness-confirmation-contract-v1.json

Report contract:

- ordered section registry;
- derived section count;
- exact applicability by verdict;
- one primary-verdict field;
- one terminal-status field;
- findings grouped as package, audit, derivative, mixed, or unresolved;
- no section-count literal outside the registry;
- no report prose used as authority.

Confirmation contract:

- exact frozen confirmation-name registry;
- count derived from names;
- no extra entries;
- no verdict entry;
- one evidence pointer per confirmation;
- no hard-coded success;
- no absence-as-success;
- terminal confirmations resolved only by the terminal marker or governing
  terminal evidence.

Run an independent pre-source documentary validator that rejects:

- 59-versus-58 style count drift;
- missing section;
- extra section;
- duplicate section;
- appended verdict confirmation;
- confirmation count not equal to the name set.

No source may be created before this validator passes.

──────────────────────────────────────────────────────────────────────────────
12. SOURCE ARCHITECTURE AND REGISTRIES
──────────────────────────────────────────────────────────────────────────────

Define clean modular roles before source creation, including:

- finite parent;
- recorder;
- strict JSON parser;
- total observer;
- no-follow inventory;
- role resolver;
- grammar registry;
- attempt/status adapter;
- freeze validator;
- role/source joiner;
- path-sensitive analyzer;
- qualification-independence analyzer;
- confirmation adjudicator;
- lane adapters;
- field-map adjudicator;
- constructed-subject validator;
- root normalizer;
- cleanup-result owner;
- evidence retention/cleanup;
- process/failure custody;
- security/authority;
- causal reconciliation;
- report projector;
- capsule terminal lifecycle;
- failure closeout;
- platform capture;
- independent validators.

Every role maps exactly once to one clean source path.

Production logic may not import qualification fixtures.

Independent validators may not import production or qualification modules,
generators, expected-result maps, production observers, normalizers, or
projectors.

Retain planned and final:

contract/new-clean-harness-production-source-registry-v1.json
contract/new-clean-harness-qualification-source-registry-v1.json
contract/new-clean-harness-independent-source-registry-v1.json

──────────────────────────────────────────────────────────────────────────────
13. CROSS-MODULE INTERFACE REGISTRY
──────────────────────────────────────────────────────────────────────────────

Before compilation derive and retain:

analysis/derived-cross-module-interface-set-v1.json
contract/new-clean-harness-cross-module-interface-registry-v1.json

Derive interfaces from:

- AST imports;
- direct calls;
- resolved attribute calls;
- return sites;
- constructors;
- serialized-record producers/readers;
- statically resolved bytecode targets.

For every interface bind:

- ID;
- provider;
- consumer;
- call sites;
- provider shape;
- consumer shape;
- fields/pointers;
- types;
- nullability;
- exception contract;
- authority;
- verdict applicability;
- field alias policy;
- path rendering policy;
- normalization policy;
- direct integration test;
- independent test.

Require exact equality:

derived
=
registered
=
directly tested
=
independently tested

No dynamically unresolved acceptance-bearing edge.

The historical cleanup edge and historical I08 semantics must be represented
normally, not as post hoc exceptions.

──────────────────────────────────────────────────────────────────────────────
14. PRECOMPILATION CONTRACT AND INTERFACE VALIDATION
──────────────────────────────────────────────────────────────────────────────

Before source registries close, run independent source-external validation of:

- operating model;
- authority;
- D01–D14 registry;
- external-interface registry;
- JSON-observation model;
- report contract;
- confirmation contract;
- source architecture;
- cross-module interface schema and policy enums.

After candidate source exists but before compilation, require:

- all files parse as AST;
- every role is occupied;
- every interface set closes;
- every provider path conforms to consumers;
- report-section implementation matches the section registry;
- confirmation implementation matches the exact name registry;
- no field-alias/path-rendering conflation;
- no unresolved interface;
- no Git/VCS mechanism.

If this gate fails:

- source registries must not close;
- compilation must not begin;
- no source attempt is consumed.

──────────────────────────────────────────────────────────────────────────────
15. SOURCE-ATTEMPT LIMIT
──────────────────────────────────────────────────────────────────────────────

At most three complete clean-source attempts are permitted.

An attempt begins only when:

- production registry closes;
- qualification registry closes;
- independent registry closes;
- compilation begins.

For each attempt retain:

- exact source identities;
- clean-room provenance;
- textual and AST delta from no predecessor:
  newly authored;
- compilation;
- static/interface gates;
- matrices reached;
- synthetic lanes;
- rehearsal posture;
- first blocker;
- supersession.

Any modification after compilation starts creates a new attempt.

If Attempt 3 fails, stop. Do not create Attempt 4.

──────────────────────────────────────────────────────────────────────────────
16. STATIC SOURCE GATES
──────────────────────────────────────────────────────────────────────────────

Compile every source with pinned Python `-I -S -B`.

Require exit 0 and empty stderr.

Run source-external:

- AST;
- call graph;
- dataflow;
- bytecode;
- exception table;
- CFG;
- provider/consumer shape analysis;
- report-section analysis;
- confirmation-name analysis;
- process-launch crosswalk;
- filesystem-operation crosswalk;
- terminal-operation crosswalk;
- forbidden executable/library/path analysis.

Require:

- finite flow;
- no stdin;
- no persistent supervisor;
- every child through recorder;
- no network/Git/VCS/shell/PATH lookup;
- no broad Downloads scan;
- no historical harness import;
- no implementation-source execution;
- no unregistered interface;
- no alias/path-policy conflation;
- no report-count literal drift;
- no extra confirmation;
- no postseal filesystem operation;
- success/failure closeout reachable.

──────────────────────────────────────────────────────────────────────────────
17. DEFECT-PREVENTION MATRICES
──────────────────────────────────────────────────────────────────────────────

Run unique, closed matrices for D01–D14.

Minimum counts:

- D01 attempt/status:
  30;
- D02 freeze binding:
  25;
- D03 role/source join:
  30;
- D04 G01 reachability:
  30;
- D05 confirmation semantics:
  35;
- D06 lane adapters:
  at least 100;
- D07 field map:
  30;
- D08 constructed-subject domain:
  40;
- D09 root normalization:
  40;
- D10 causal report:
  30;
- D11 cleanup result:
  50;
- D12 interface metadata:
  35;
- D13 report registry:
  25;
- D14 confirmation registry:
  25.

D12 must include:

- field alias forbidden and path rendering exact absolute;
- field alias forbidden and governed root-relative normalization;
- semantic field alias attempt;
- conflicting pointer alias;
- path rendering mistaken for alias;
- normalization mistaken for alias;
- missing policy field;
- wrong policy enum;
- stale absolute path;
- wrong root-relative path;
- historical I08 valid baseline;
- historical universal-alias predicate, which must be rejected.

D13 must include:

- exact registry-derived count;
- 58 versus 59 mismatch;
- extra section;
- missing section;
- duplicate section;
- reordered required section;
- hard-coded independent count.

D14 must include:

- exact name set;
- extra verdict token;
- missing confirmation;
- duplicate confirmation;
- wrong count;
- verdict separate from confirmations;
- preterminal and terminal classification;
- terminal marker resolution.

Require zero false acceptance, false rejection, reason mismatch, skip, or
unexpected exception.

──────────────────────────────────────────────────────────────────────────────
18. PROCESS-CUSTODY QUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Exercise:

- nonexistent executable;
- zero/empty streams;
- nonzero with both streams;
- timeout/kill/reap;
- dynamic root zero/nonzero;
- missing result;
- empty ledger;
- multiple children;
- lost stdout/stderr;
- unregistered effect;
- evidence before cleanup;
- zero/one/multiple-root cleanup.

Require complete custody, effect attribution, cleanup equality, and zero
survivors.

──────────────────────────────────────────────────────────────────────────────
19. SYNTHETIC END-TO-END AUDIT LANES
──────────────────────────────────────────────────────────────────────────────

Create source-independent synthetic fixtures from governing contracts.

Run:

A. accepted implementation package;
B. substantive BLOCK package;
C. audit provenance failure;
D. physically distinct semantically equal constructed subjects;
E. matrix-corpus wrong-registry and same-length alternatives.

Require exact verdicts, complete findings, process custody, report contract,
confirmation contract, temporal/manifests, terminal adapter, cleanup, and no
postseal operation.

──────────────────────────────────────────────────────────────────────────────
20. BOUNDED READ-ONLY COMPATIBILITY REPLAY
──────────────────────────────────────────────────────────────────────────────

Against unchanged real supplied roots, without executing implementation source
or full-audit mode, require the candidate to:

- authenticate implementation closure;
- resolve 41 roles;
- resolve Attempts 1–3;
- validate freeze binding;
- resolve 24 production and nine qualification roles;
- path-sensitively adjudicate G01;
- audit 125 implementation confirmations;
- parse all current matrix lanes;
- parse 946 and 137 cases;
- parse 766/333 field map;
- parse producer rehearsals under subject-domain grammar;
- normalize rehearsals to zero unexplained differences;
- authenticate Attempt-2 failure evidence;
- derive one exact future full-audit invocation;
- emit no package verdict.

Retain:

validation/new-clean-harness-bounded-compatibility-replay-v1.json

──────────────────────────────────────────────────────────────────────────────
21. TWO COMPLETE HARNESS REHEARSALS
──────────────────────────────────────────────────────────────────────────────

Run two physically distinct complete rehearsals on audit-owned synthetic
fixture sets using the same candidate bytes.

Each rehearsal must complete:

- D01–D14 matrices;
- process custody;
- synthetic ACCEPT/BLOCK/provenance lanes;
- subject-pair comparison;
- compatibility replay;
- report generation;
- exact confirmation registry;
- terminal capsule closure;
- cleanup.

Retain complete roots until independent validation, normalized comparison, and
evidence retention pass.

Require zero unexplained difference after governed physical normalization.

──────────────────────────────────────────────────────────────────────────────
22. INDEPENDENT VALIDATORS
──────────────────────────────────────────────────────────────────────────────

Independent validators may not import candidate production or qualification
modules, generators, expected maps, observers, normalizers, or projectors.

They must independently verify:

- clean-room provenance;
- contracts and registries;
- D01–D14 matrices;
- cross-module interfaces;
- D12 policy-field separation;
- report-section registry/count;
- confirmation name set/count/verdict separation;
- process custody;
- synthetic verdict lanes;
- compatibility replay;
- both rehearsals;
- normalization;
- cleanup;
- capsule closure.

Require zero errors.

Independent validators must validate each typed interface-metadata policy by
its own field. They may not apply a universal “all alias fields must be
forbidden” predicate to path-rendering or normalization policies.

──────────────────────────────────────────────────────────────────────────────
23. FAILURE EVIDENCE AND CLEANUP
──────────────────────────────────────────────────────────────────────────────

Before removing any owned root retain:

- root identity;
- complete inventory;
- all process records and streams;
- all indispensable results;
- failure outcome;
- terminal posture.

Then verify identity, remove exact root, and observe ENOENT twice.

Require:

created
=
inventoried
=
evidence-retained
=
cleanup rows
=
twice absent

Empty equal sets pass.

──────────────────────────────────────────────────────────────────────────────
24. SOURCE FREEZE
──────────────────────────────────────────────────────────────────────────────

Freeze only after:

- static gates;
- all D01–D14 matrices;
- process custody;
- synthetic lanes;
- compatibility replay;
- both rehearsals;
- normalized equality;
- independent validators;
- cleanup;
- supplied-root equality.

Retain:

opening/new-clean-audit-harness-source-freeze-v1.json

Bind exact production, qualification, and independent registries; clean-room
provenance; governing identities; all results; rehearsals; cleanup; and full
audit not executed.

Reopen all source no-follow.

Do not modify source afterward.

──────────────────────────────────────────────────────────────────────────────
25. FROZEN-SOURCE REQUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Against exact frozen bytes rerun:

- compilation;
- static and interface gates;
- D01–D14 matrices;
- process custody;
- synthetic lanes;
- compatibility replay;
- independent validators;
- source/result linkage;
- supplied-root equality.

Do not rerun full rehearsals.

Prove both passing rehearsals used the exact bytes frozen later.

Retain:

validation/new-clean-audit-harness-frozen-source-requalification-v1.json

──────────────────────────────────────────────────────────────────────────────
26. PACKAGE STATUS
──────────────────────────────────────────────────────────────────────────────

Generate preterminal status:

- status:
  new-clean-source-external-gen2-implementation-audit-harness-implemented-qualified-frozen-pending-fresh-audit;
- prior harness lineages:
  retired;
- implementation package:
  unchanged and unadjudicated;
- full audit:
  not executed;
- source:
  frozen;
- qualification:
  passed;
- fresh audit:
  required;
- current-subject construction:
  unauthorized;
- product/runtime/target/repository/publication/deployment/A6:
  not performed or authorized.

──────────────────────────────────────────────────────────────────────────────
27. SUPPLIED-ROOT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete no-follow inventories for every supplied root opened.

Require exact equality.

Do not mutate or clean supplied roots.

For each harness-owned fixture, retain evidence, remove exact root, observe
ENOENT twice, and require zero process/descriptor/cache survivors.

──────────────────────────────────────────────────────────────────────────────
28. TERMINAL PACKAGE CLOSURE
──────────────────────────────────────────────────────────────────────────────

Before temporal projection:

- finalize nonclosure outputs;
- create only used directories;
- ensure preexisting `closeout/` and `manifest/`;
- no empty descendant;
- reserve A/B;
- retain descriptors;
- freeze directory set.

Then:

1. temporal projection excluding self and A/B;
2. immediate independent reprojection;
3. independent identical A/B generation;
4. writes through retained descriptors;
5. fsync/close/directory fsync;
6. no-follow reopen and identity checks;
7. final independent reprojection;
8. root row once;
9. clean topology/modes/links/cache posture;
10. one seal transition;
11. typed report projection from exact section registry;
12. exact confirmation registry without verdict token;
13. guarded verdict and marker;
14. nonreturning exit;
15. no postseal operation.

──────────────────────────────────────────────────────────────────────────────
29. FAILURE CLOSEOUT
──────────────────────────────────────────────────────────────────────────────

On failure retain source attempt, first blocker, exception, process ledger and
streams, partial inventory, indispensable evidence, cleanup, supplied-root
equality, freeze posture, terminal posture, and same-root retry false.

Do not create success manifests for failed packages.

Evidence loss, cleanup inequality, supplied-root inequality, source drift,
closure failure, or postseal operation is:

NEW_CLEAN_AUDIT_HARNESS_IMPLEMENTATION_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
30. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_NEW_CLEAN_AUDIT_HARNESS_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_FRESH_AUDIT

only when all authority, source, interface, matrix, process, synthetic,
compatibility, rehearsal, independent-validation, cleanup, freeze,
requalification, supplied-root, and terminal-closure gates pass.

Return:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_NEW_CLEAN_AUDIT_HARNESS_IMPLEMENTATION_BLOCKED

when the new clean implementation cannot qualify within three attempts or
would require changing governing package semantics.

Return:

NEW_CLEAN_AUDIT_HARNESS_IMPLEMENTATION_PROVENANCE_MISMATCH

for fixed-input mismatch, source-provenance violation, Git/VCS use,
unregistered effects, evidence loss, cleanup inequality, supplied-root
inequality, source drift after freeze, package-closure failure, or postseal
operation.

──────────────────────────────────────────────────────────────────────────────
31. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return the exact ordered section registry established pre-source. It must
include, at minimum:

1. Primary verdict
2. Fresh root identity
3. Terminal reconciliation authentication
4. Historical harness-lineage retirement
5. Implementation-package preservation
6. Governing-root preservation
7. Clean-room source authority
8. Process-execution policy
9. Operating-model freeze
10. D01–D14 registry
11. External-interface registry
12. Total JSON-observation contract
13. Report contract
14. Confirmation contract
15. Source architecture
16. Source-attempt ledger
17. Production registry
18. Qualification registry
19. Independent registry
20. Cross-module interface registry
21. Static gates
22–35. D01–D14 matrix results
36. Process-custody qualification
37. Synthetic ACCEPT lane
38. Synthetic BLOCK lane
39. Synthetic provenance-failure lane
40. Synthetic subject-pair lane
41. Compatibility replay
42. Harness rehearsal A
43. Harness rehearsal B
44. Normalized rehearsal comparison
45. Independent validators
46. Evidence retention
47. Fixture/rehearsal cleanup
48. Source freeze
49. Frozen-source requalification
50. Confirmation full audit not executed
51. Package status
52. Supplied-root closing equality
53. Failure-closeout capability/use
54. Temporal-inventory identity
55. Manifest A identity
56. Manifest B identity
57. Terminal reprojection
58. Terminal membership and modes
59. No-write-after-closure
60. Remaining uncertainty and nonclaims
61. Explicit confirmation registry

The actual count must be derived from the frozen ordered registry. No separate
hard-coded section count is permitted.

Freeze an exact confirmation-name registry pre-source. The confirmation
artifact must contain exactly those names and no primary-verdict token.

Required confirmations must include:

FINAL_RECONCILIATION_AUTHENTICATED
INCREMENTAL_HARNESS_LINEAGE_RETIRED
BLOCKED_CLEAN_HARNESS_ROOT_MUTATION_NOT_PERFORMED
GIT_DISQUALIFIED_ROOT_MUTATION_NOT_PERFORMED
FINAL_INTERFACE_REPAIR_ROOT_MUTATION_NOT_PERFORMED
NO_HISTORICAL_HARNESS_SOURCE_COPIED
NO_HISTORICAL_HARNESS_SOURCE_PATCHED
NO_HISTORICAL_HARNESS_SOURCE_IMPORTED
NO_HISTORICAL_HARNESS_SOURCE_USED_AS_AST_ORIGIN
IMPLEMENTATION_PACKAGE_MUTATION_NOT_PERFORMED
IMPLEMENTATION_PACKAGE_NOT_READJUDICATED
GOVERNING_ROOTS_MUTATION_NOT_PERFORMED
CLEAN_ROOM_SOURCE_AUTHORITY_ESTABLISHED
PROCESS_EXECUTION_POLICY_FROZEN
NO_GIT_EXECUTABLE_INVOKED
NO_GIT_LIBRARY_USED
NO_DOT_GIT_PATH_ACCESSED
OPERATING_MODEL_FROZEN_BEFORE_SOURCE
D01_D14_REGISTRY_COMPLETE
INTERFACE_METADATA_POLICIES_SEPARATED
REPORT_SECTION_REGISTRY_FROZEN
REPORT_SECTION_COUNT_DERIVED
CONFIRMATION_NAME_REGISTRY_FROZEN
CONFIRMATION_COUNT_DERIVED
PRIMARY_VERDICT_SEPARATE_FROM_CONFIRMATIONS
EXTERNAL_INTERFACE_REGISTRY_COMPLETE
TOTAL_JSON_OBSERVATION_IMPLEMENTED
SOURCE_ARCHITECTURE_COMPLETE
SOURCE_ATTEMPT_LIMIT_RESPECTED
FINAL_SOURCE_REGISTRIES_COMPLETE
INDEPENDENT_VALIDATORS_IMPORT_NO_PRODUCTION_HELPERS
ALL_SOURCES_COMPILED
STATIC_SOURCE_GATES_PASSED
D01_D14_MATRICES_PASSED
PROCESS_CUSTODY_QUALIFICATION_PASSED
SYNTHETIC_ACCEPTED_PACKAGE_AUDIT_PASSED
SYNTHETIC_BLOCK_PACKAGE_AUDIT_PASSED
SYNTHETIC_PROVENANCE_FAILURE_AUDIT_PASSED
SYNTHETIC_CONSTRUCTED_SUBJECT_PAIR_PASSED
BOUNDED_COMPATIBILITY_REPLAY_PASSED
BOUNDED_COMPATIBILITY_REPLAY_EMITTED_NO_PACKAGE_VERDICT
COMPLETE_HARNESS_REHEARSAL_A_PASSED
COMPLETE_HARNESS_REHEARSAL_B_PASSED
TWO_HARNESS_REHEARSALS_NORMALIZED_EQUAL
INDEPENDENT_HARNESS_VALIDATORS_PASSED
EVIDENCE_RETAINED_BEFORE_CLEANUP
AUDIT_OWNED_CLEANUP_SET_EQUALITY_PASSED
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
NEW_CLEAN_HARNESS_SOURCE_FROZEN
NEW_CLEAN_HARNESS_SOURCE_NOT_MODIFIED_AFTER_FREEZE
FROZEN_SOURCE_REQUALIFICATION_PASSED
FULL_INDEPENDENT_AUDIT_NOT_EXECUTED
CURRENT_SCHEMA_SUBJECT_NOT_CONSTRUCTED
PROCESS_SELF_TEST_NOT_EXECUTED
PRODUCT_CONSTRUCT_MODE_NOT_EXECUTED
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
HARNESS_TEMPORAL_INVENTORY_CREATED
HARNESS_TEMPORAL_INVENTORY_VERIFIED
HARNESS_MANIFEST_A_CREATED
HARNESS_MANIFEST_B_CREATED
HARNESS_MANIFESTS_BYTE_IDENTICAL
HARNESS_TERMINAL_REPROJECTION_PASSED
HARNESS_ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_WRITE_AFTER_TERMINAL_CLOSURE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

After:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_NEW_CLEAN_AUDIT_HARNESS_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_FRESH_AUDIT

the next tranche is exactly one fresh independent audit of the unchanged
sealed implementation package.

Do not combine that audit with this implementation task.

Do not construct the authoritative current schema subject until that later
fresh audit accepts the implementation package.
```

### Sources

The attached report records the controlling Attempt-2 independent-validator failure, its exact `I08` policy mismatch, and exhaustion of the two-attempt budget. :chatgpt-content-reference{index="8"} :chatgpt-content-reference{index="9"} :chatgpt-content-reference{index="10"}

It also establishes that all direct interface tests, D01–D10 regressions, process custody, synthetic verdict lanes, bounded replay, cleanup causals, both rehearsals, and normalized comparison passed before the independent-validator failure. :chatgpt-content-reference{index="11"}

The candidate never froze or terminally closed, all supplied roots remained unchanged, cleanup completed, and the implementation package remained unexecuted and unadjudicated. :chatgpt-content-reference{index="12"}

**Confidence:** 0.999 that no implementation-package repair is authorized; 0.999 that the localized clean-harness candidate is terminally retired; 0.98 that a new clean implementation generation with pre-source separation of alias, path-rendering, report, and confirmation semantics is the correct next tranche.
