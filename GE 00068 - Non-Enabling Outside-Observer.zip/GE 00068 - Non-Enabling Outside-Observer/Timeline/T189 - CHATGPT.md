## Assessment

This is a **contract-reconciliation stop, not an implementation failure**.

Codex correctly refused to satisfy the literal condition that every prepublication failure must leave the final pathname absent. In the concurrent-collision case, another writer created that pathname. The caller has only two safe options:

- preserve the foreign object and reject; or
- delete or replace another writer’s object.

The second option would violate the exclusive, no-overwrite publication contract. The implemented behavior—preserve the foreign file, fail the caller, and publish no caller-owned accepted record—is the correct behavior.

### Freeze the corrected criterion

The acceptance rule should now be:

> Before publication, the caller must not create or publish an accepted final JSON record. When no external writer has occupied the final pathname, a precommit failure leaves that pathname absent. When another writer wins a concurrent exclusive-publication race, the foreign pathname may remain present, but its identity and bytes must remain unchanged; the caller’s staged object must not become the final object; the caller invocation must be nonaccepted; and no successful shared-output projection may attribute the foreign record to that invocation.

Consequently:

- **Final-path absence is required only when no foreign collision occurred.**
- **No caller-published accepted final record** is the universal invariant.
- The caller must never delete, replace, relabel, or take custody of the foreign occupant.
- A record pathname existing by itself is not proof that the failed caller invocation accepted it. Acceptance requires the successful caller outcome plus the exclusively committed record.
- Any caller-created sidecars or staging file remain failed-attempt evidence and must block ambiguous same-basename reuse, as already implemented.

This does not change protocol v2, schema v3, the 25 fields, or the source bytes. It resolves an impossible conjunction in the previous acceptance matrix.

## Disposition

Do **not** return this to implementation. The source already appears to implement the corrected semantics:

- caller-evidence containment is repaired;
- accepted JSON is staged and exclusively published at the commit point;
- `renameatx_np(..., RENAME_EXCL)` preserves a foreign destination;
- the caller rejects on the collision;
- it does not publish its staged record as accepted;
- the remaining blocker is expressly the wording of our criterion.

The next action is a **fresh independent audit of the exact current bytes**, using the corrected collision contract below. This follows the project’s required separation between implementation and independent audit, and the audit must begin from exact provenance rather than trusting the producer report.  

## Codex prompt — fresh independent audit

```text
MANDATORY RESPONSE FORMAT

Embed the complete audit report inline in Markdown. Local evidence links may be
supplemental, but must not replace any part of the report.

Return exactly one:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH
PROCESS_BOUNDARY_BLOCK
SUBAGENT_UNAVAILABLE

FRESH READ-ONLY CONVERSATION

This must be a completely fresh Codex conversation.

Do not resume:

- the caller-evidence/atomic-publication implementation conversation;
- either caller reusability/depth audit;
- any earlier caller-snapshot audit;
- any repository implementation or repository audit conversation.

Objective

Independently audit the exact source-external Evidence Verification v1 caller
successor that repairs:

1. record-destination containment relative to caller_evidence_root; and
2. publication of an accepted JSON record before acceptance was irrevocable.

The producer returned SCOPE_EXPANSION_REQUIRED because one supplied acceptance
criterion was internally inconsistent in the concurrent foreign-final
collision case. The corrected criterion is frozen in section 2 below. The
producer verdict itself does not disqualify the exact source bytes.

Do not repair or modify the caller, repository, or any supplied evidence.

No formatting, cleanup of supplied roots, staging, commit, push, PR, merge,
installation, deployment, A6 restart, product execution, live-service
invocation, network contact, or Linux binary execution.

No nested subagents.

## 1. Exact frozen inputs

Frozen repository, read-only:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Expected repository identity:

- branch:
  codex/evidence-verification-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- upstream:
  absent
- canonical manifest SHA-256:
  4a3a42441632725c12dedbb13d6ab619f2b42677dde12a80c6efcc3025518537
- full-index tracked binary-diff SHA-256:
  b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb
- restored governed inventory:
  477 exact objects

Current implementation root:

REPAIR_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-repair-c24d79991539-v1

Exact successor:

SUCCESSOR=$REPAIR_ROOT/source/launch_v3_trusted_host_reusable_depth12_atomic_publish.py

Expected successor identity:

- size:
  45678
- SHA-256:
  3c06a1c8dae17ba1a8f21fa50fde8b9dea9b4a5c274c740b761774c60bedc631

Exact base caller copy:

BASE_COPY=$REPAIR_ROOT/source/base_caller_exact.py

Expected base identity:

- size:
  33758
- SHA-256:
  c24d79991539a1aa638480c45e7b3af86d8ea5f04134b7222da76f0e1bb91d24

Source delta:

SOURCE_DELTA=$REPAIR_ROOT/provenance/source-delta.diff

Expected source-delta SHA-256:

a9f1f7d3ec09317126b575ade443fe89e7b9a7d31db7a0466d63c452e0bd3bd2

Semantic crosswalk:

$REPAIR_ROOT/provenance/semantic-crosswalk.json

Implementation report:

$REPAIR_ROOT/closeout/implementation-report.md

Attempt index:

$REPAIR_ROOT/provenance/attempt-index-final.json

Atomic-publication capability record:

$REPAIR_ROOT/provenance/atomic-publication-capability.json

Implementation manifests:

MANIFEST_1=$REPAIR_ROOT/provenance/repair-manifest-run-1.json
MANIFEST_2=$REPAIR_ROOT/provenance/repair-manifest-run-2.json

Expected SHA-256 for each:

58b1f0fe386be8fafd3d073a80b99bd9ae3191f0547f40ce8967ccf18669fc00

Expected implementation-root closure:

- 183 regular files total;
- 10 directories including the root;
- 181 SHA-bearing rows covering every nonmanifest regular file exactly once;
- only the two manifest paths self-excluded;
- every regular file single-link and mode 0600;
- every directory mode 0700;
- private tmp directory empty.

Frozen base-repair root:

BASE_REPAIR_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-caller-reusability-depth-repair-c030f2baf200-v1

Expected base-repair closure:

- 108 regular files;
- 10 directories;
- manifest SHA-256:
  70e2a46949f2bc0eb25a799e60af2c44e73112a408bd119fc8e297a6203eec15

Prior blocking audit, read-only:

BLOCKING_AUDIT=/Users/ds/Downloads/ES-evidence-verification-v1-caller-reusability-depth-independent-audit-70e2a46949f2-v2

Read and bind at minimum:

- causals/caller-evidence-ancestor.json
- causals/late-json-full-main-corrected.json
- causals/destination-negatives.json
- causals/output-races-and-retry.json
- causals/sealed-compatibility.json
- causals/caller-negatives-independent.json
- closeout/final-addendum.json

Unchanged verifier:

VERIFY=$IMPL_R/tools/evidence_verify/verify_v1.py

Expected verifier identity:

- size:
  40121
- SHA-256:
  bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c

Original sealed A6D:

A6D=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

Expected A6D manifest SHA-256:

dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9

Sealed amendment:

A6D_AMEND=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

Expected amendment manifest SHA-256:

a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e

Pinned Python:

PYTHON=/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Expected interpreter:

- Python 3.13.4;
- regular and single-link;
- size:
  119424
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b

Fresh audit root, required absent at opening:

AUDIT_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-independent-audit-58b1f0fe386b-v1

## 2. Corrected concurrent-collision contract

The following decision supersedes only the internally inconsistent literal
criterion in the producer prompt. It does not change source bytes, protocol,
schema, authority, or any other acceptance rule.

### Universal invariant

For every precommit failure:

- the caller must not publish its staged JSON object as the final accepted
  record;
- the caller invocation must be nonaccepted;
- shared output must not report a successful accepted invocation;
- no caller-created final JSON may state `outcome="accepted"`;
- no pre-existing or concurrently created foreign final object may be deleted,
  replaced, relabelled, or taken into caller custody.

### No external collision

When no external writer creates the final JSON pathname, any precommit failure
must leave that final pathname absent.

### Concurrent foreign-final collision

When another writer creates the final pathname after the caller’s initial
absence check and before exclusive publication:

- the final pathname may remain present;
- that object is foreign, not caller-published;
- its device/inode, type, mode, link count, size, and bytes must remain
  unchanged by the caller;
- the caller’s verified staged inode must not become the final inode;
- exclusive publication must fail;
- the invocation must return nonaccepted;
- no successful shared-output projection may attribute the foreign object to
  this invocation;
- any caller-created sidecars or stage are failed-attempt evidence only and
  must make same-basename retry fail closed;
- the caller must not delete the foreign object merely to make the pathname
  absent.

Path presence alone does not prove that this invocation accepted a record.
Acceptance requires both:

1. successful exclusive publication by this invocation; and
2. the successful caller process outcome associated with that publication.

Audit the exact source against this corrected contract. Do not retain the
superseded demand that a foreign writer’s object be deleted.

## 3. Authority and scope

Classification:

- source-external validation-evidence caller;
- repository verifier remains an ES-owned Bounded slice rule;
- caller and records remain evidence/projection;
- no product, runtime, admission, orchestration, readiness, durable-state,
  commit, publication, or deployment authority.

Audit scope:

- caller-evidence containment;
- staged JSON and atomic publication state machine;
- Darwin exclusive-publication capability;
- concurrent foreign-final semantics under section 2;
- partial-output and retry behavior;
- hook containment;
- depth/snapshot nonregression;
- exact protocol/schema preservation;
- exact-successor compatibility;
- implementation-root provenance and closure.

Out of scope:

- repository test 89 and authority-family work;
- product behavior;
- fresh Repair 10I A6 construction;
- commit or publication.

## 4. Audit-evidence posture

Before correctness inspection:

1. Require AUDIT_ROOT absent.
2. Set umask 077.
3. Create retained audit directories directly at 0700.
4. Create each retained audit file exclusively at 0600.
5. Never overwrite, truncate, rewrite, or chmod-correct a retained record.
6. Capture child output in memory before retaining it.
7. The parent writes all retained auditor reports.
8. Keep private audit tmp empty at closeout.

Return PROCESS_BOUNDARY_BLOCK on any evidence-posture failure. Do not repair the
same audit attempt.

Do not inspect primary-working-tree content.

Repository Git reads must use only:

git -C "$IMPL_R" ...

with cwd exactly IMPL_R and explicit:

GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

Auditors must run no Git.

Any imported caller source must be an audit-owned exact byte copy, under
bytecode-disabled execution.

## 5. Opening provenance

Before source correctness inspection, independently require:

### Repository

- exact branch, HEAD, tree, parent, and absent upstream;
- exact canonical manifest and tracked diff;
- exact 477-object inventory;
- no repository cache, bytecode, test cache, ignored extra, or generated
  artifact;
- zero staged, deleted, renamed, or unmerged paths.

### Implementation root

Independently inventory REPAIR_ROOT by relative path.

Require:

- exact successor, base copy, source delta, crosswalk, capability record,
  causals, tests, validation, sidecars, report, and attempt index;
- exactly 183 regular files and 10 directories;
- all files mode 0600 and single-link;
- all directories mode 0700;
- tmp empty;
- both manifests canonical and byte-identical;
- exactly 181 SHA-bearing file rows;
- every nonmanifest file covered exactly once;
- exactly the two manifest paths self-excluded;
- all directories covered exactly once;
- no unexplained exclusion or later mutation.

Also verify BASE_REPAIR_ROOT, BLOCKING_AUDIT, A6D, and A6D_AMEND remain
unchanged at opening and closeout.

Return AUDIT_PROVENANCE_MISMATCH on any mismatch and stop before correctness
inspection.

## 6. Four distinct auditors

After provenance matches, start three distinct read-only auditors concurrently:

1. Contract, protocol, schema, source-delta, and state-machine auditor.
2. Filesystem, descriptor-output, atomic-publication, and collision auditor.
3. Snapshot/depth, tests, resource limits, and provenance auditor.

After one completes and closes, start a fourth distinct auditor:

4. Security, hook reachability, disclosure, compatibility, and artifact auditor.

Retry a failed start once. If a required distinct auditor cannot start, return
SUBAGENT_UNAVAILABLE.

No nested delegation. No auditor mutation, Git, network, supplied-root write,
repository import, or artifact-producing repository execution.

Each auditor must report exact operands, cwd, evidence, inference, uncertainty,
uninspected scope, disagreements, mutation `no`, and nested subagents `no`.

## 7. Exact source delta

Independently compare BASE_COPY and SUCCESSOR and regenerate the unified diff.

Require the delta to be confined to:

- caller_evidence_root destination disjointness;
- staged JSON naming and collision checks;
- behavior-probed `renameatx_np(..., RENAME_EXCL)` capability and publication;
- output state-machine changes required to make publication the commit point;
- deterministic private hooks and normal-main guards;
- bounded comments/constants for that contract.

Require the reported snapshot/depth block to be byte-identical to base at:

- size:
  7831
- SHA-256:
  287302fb8e96d79898e1ae30f632f346a45a6aa76ea1bc030e26e7267b9fe7ff

Confirm unchanged:

- CLI names, order, required/optional status, and defaults;
- launch protocol v2;
- record schema v3;
- exact 25 fields and meanings;
- source-by-value launch;
- interpreter/source/registry/layout/result checks;
- snapshot semantics and limits;
- trusted-host nonclaims;
- every unrelated acceptance gate;
- no fourth public output;
- no product/runtime/readiness authority.

BLOCK on unexplained semantic widening.

## 8. Caller-evidence containment

Independently verify and causally test that the record parent rejects, before
child launch or output preparation:

- equality with caller_evidence_root;
- descendant of caller_evidence_root;
- ancestor containing caller_evidence_root;
- physical inode alias;
- supported case alias;
- symlink-mediated equivalent.

Require disjointness in both physical ancestry directions using descriptor-bound
identity, not lexical prefixes or commonpath.

For every rejected case require:

- no record, sidecar, or stage created;
- no child launch;
- caller_evidence bytes and inventory unchanged;
- exact compatible nonaccepting classification.

Verify accepted external destinations preserve equal opening and closing
caller_evidence snapshots.

## 9. Atomic publication algorithm

Inspect and independently test:

### Capability

- exact Darwin `RENAME_EXCL` value and API use;
- descriptor-relative, same-directory publication;
- behavioral capability probe before public output creation;
- occupied destination yields EEXIST and changes neither source nor destination;
- unoccupied destination receives the exact staged inode;
- stage name disappears;
- no overwrite rename, copy/delete fallback, or persistent hard-link fallback;
- capability uncertainty fails before accepted publication.

### Precommit state

Require initially absent:

- stdout sidecar;
- stderr sidecar;
- final JSON;
- deterministic stage path.

Require exclusive descriptor-relative 0600 creation, complete write, fsync,
close, and reobservation for both sidecars and stage.

Require all acceptance-bearing provenance, snapshot, relationship, parent, and
output checks to complete before publication.

### Commit point

The exclusive stage-to-final publication is the sole accepted-record commit
point.

After successful publication:

- final JSON exists once;
- stage is absent;
- final inode equals verified stage inode;
- final link count is one;
- record is canonical v3, accepted, and has empty errors;
- sidecar identities and hashes agree;
- process result is successful;
- no subsequent acceptance-bearing check can fail;
- cleanup or shared-output failure cannot contradict the committed result.

## 10. Publication-failure and collision matrix

Deterministically reproduce all producer cases and independently add any missing
edge cases:

- before stdout;
- partial stdout write;
- stdout fsync;
- between stdout and stderr;
- partial stderr;
- stderr fsync;
- after sidecars;
- partial stage;
- stage fsync;
- stage close/reobservation;
- parent rebinding;
- capability unavailable;
- destination created concurrently;
- exclusive publication failure;
- successful publication;
- attempted postcommit error;
- shared-output failure;
- same-basename retry after each failed phase;
- retry after success.

For ordinary precommit failures with no foreign collision require:

- final JSON absent;
- no caller-created accepted final record;
- invocation nonaccepted;
- partial artifacts clearly nonaccepted;
- retry fails closed without overwrite.

### Mandatory foreign-final collision causal

Create a deterministic foreign final object after the initial absence check and
before `RENAME_EXCL`.

Test at least:

1. arbitrary non-JSON foreign bytes;
2. a schema-valid JSON object containing `"outcome":"accepted"`.

For each require:

- `RENAME_EXCL` fails;
- invocation is nonaccepted;
- no successful shared output attributes the record to the caller;
- foreign final object’s device/inode, type, mode, link count, size, and bytes
  are unchanged;
- staged inode does not become final inode;
- caller does not delete or replace the foreign object;
- sidecars/stage are classified only as failed-attempt evidence;
- same-basename retry fails closed;
- the final path’s presence is not represented as this invocation’s accepted
  publication.

Do not fail the audit merely because the foreign pathname remains present.
Fail it if the caller owns, changes, publishes, accepts, or falsely attributes
that object.

Reproduce the prior `late-json-full-main-corrected` mechanism and prove that a
corresponding precommit failure leaves no caller-created accepted final JSON.

## 11. Hooks and normal execution

Prove:

- all private hooks default to null;
- normal `main()` rejects a non-null hook before output or child launch;
- no CLI, environment, target, package, verifier result, registry/layout,
  record field, or path can set a hook;
- hooks are unavailable in normal source-by-value execution;
- no exception path retains one;
- audit tests use only exact audit-owned source copies;
- hooks cannot bypass or reorder acceptance checks in normal execution.

Any normal-input hook route is BLOCK.

## 12. Snapshot/depth regression

Independently confirm:

- root depth 0;
- files/directories through depth 12 accepted;
- files/directories at depth 13 rejected before observation;
- depth and path-byte errors remain distinct;
- stable canonical repetition;
- symlink, special file, hardlink, replacement, mutation, disappearance,
  type/mode/link and resource-limit behavior;
- capability and runtime listing failure;
- no watched-root write.

Verify limits are applied before unbounded allocation or read work.

## 13. Record schema and disclosure

Inspect producer and audit-owned records.

Require:

- exact launch protocol v2;
- exact schema v3;
- exact 25 fields;
- unchanged meanings;
- mandatory trusted-host nonclaims;
- no source text, payload, credential, private endpoint, absolute watched-root,
  caller-evidence, output, foreign-final, or staging path;
- no staging name in final record or shared output;
- `outcome="accepted"` only after the caller’s own successful exclusive commit;
- a foreign collision never yields a caller-accepted record.

Acceptance must be understood as successful invocation plus exclusive
publication, not mere path existence.

## 14. Fresh exact-successor compatibility

Every acceptance-bearing run must execute exact SUCCESSOR bytes. No patched
copy, changed constant, or reconstructed caller may qualify.

Use fresh safe external record directories.

### A6D

Run sealed twice.

Require:

- caller accepted;
- verifier exit 0;
- empty verifier stderr;
- canonical stdout SHA-256:
  3bbbc3d2ba257007e2d5b55991ce043d1cb7c5cb841e70e86f6421752e38d606;
- deterministic nonsnapshot fields;
- equal target/package/TMPDIR/caller-evidence snapshots;
- exactly three final 0600 outputs and no stage;
- committed record identity and retry semantics correct;
- unchanged A6D manifest;
- mandatory nonclaims.

### Amendment

Run sealed twice with canonical stdout SHA-256:

be83077cf61b3250eb39239e0e60bdadcec42d6ae4c2e8d6a9542ccd1caffabc

Require the same conditions.

### Synthetic A6

Create only an audit-owned fixture.

Run pre-seal twice, seal only that fixture, then run sealed twice.

Require exact successor bytes, accepted results, deterministic outputs by stage,
empty verifier stderr, equal snapshots, correct publication semantics, and only
the expected seal transition.

### SEC-02

Require source-by-value launch, target script never loaded, marker absent, and
direct-script predecessor form nonqualifying.

Do not claim atomic interpreter custody.

### Caller negatives

Freshly exercise:

- interpreter hash and size;
- source mismatch;
- registry/layout result mismatch;
- package-target containment;
- snapshot uncertainty/replacement/capability;
- file depth 13;
- invalid destination;
- caller-evidence containment;
- parent replacement;
- ordinary partial-output failures;
- foreign-final collision.

## 15. Closing provenance

Remove only audit-owned temporary fixtures.

Require:

- unchanged repository manifest, diff, and 477-object inventory;
- unchanged BASE_REPAIR_ROOT;
- unchanged BLOCKING_AUDIT;
- unchanged REPAIR_ROOT with exact 183-file/10-directory closure;
- unchanged producer manifests;
- unchanged A6D and amendment manifests;
- no process, child, descriptor, fixture, or temporary survivor;
- empty audit tmp;
- every retained audit file regular, single-link 0600;
- every retained audit directory 0700.

## 16. Verdict rules

ACCEPT only if:

- provenance matches;
- the source delta is bounded;
- caller-evidence containment is complete;
- staged publication has one irreversible commit point;
- no ordinary failure leaves a caller-created accepted final JSON;
- foreign collisions preserve the foreign object and remain nonaccepted;
- path presence alone is never treated as caller acceptance;
- hooks are unreachable normally;
- depth/snapshot behavior does not regress;
- exact-successor compatibility passes;
- schema, protocol, authority, and nonclaims remain unchanged;
- no process or artifact blocker remains.

BLOCK for any repairable source, test, publication, collision-attribution,
provenance-format, disclosure, resource, or validation defect.

REJECT only for a fundamental architecture or authority defect.

AUDIT_PROVENANCE_MISMATCH for any opening or closing identity mismatch.

PROCESS_BOUNDARY_BLOCK for an audit-process or retained-evidence-posture
failure.

SUBAGENT_UNAVAILABLE if a required auditor cannot start after one retry.

## 17. Required inline report

Include:

1. Verdict.
2. Exact repository and implementation-root identities.
3. Audit-evidence posture.
4. Opening and closing provenance.
5. Four auditor identities, schedule, operands, and status.
6. Exact source delta.
7. Corrected collision-contract adjudication.
8. Caller-evidence containment.
9. Atomic-publication capability.
10. Output state machine and commit point.
11. Ordinary precommit failure behavior.
12. Foreign-final collision behavior.
13. Partial artifacts and retry semantics.
14. Hook reachability.
15. Depth and snapshot regression.
16. Protocol/schema/field preservation.
17. Record disclosure and attribution.
18. A6D results.
19. Amendment results.
20. Synthetic A6 results.
21. SEC-02 result.
22. Caller negatives.
23. No-write and deterministic-output evidence.
24. Authority and security adjudication.
25. Severity-ranked residual findings.
26. Minority findings and parent resolution.
27. Remaining uncertainty and nonclaims.
28. Audit-created paths and cleanup.
29. Explicit confirmations:
    - repository mutation not performed;
    - supplied-evidence mutation not performed;
    - repair not performed;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 restart not performed;
    - product/live services not invoked;
    - network contact not performed;
    - nested subagents not created.

Do not stage, commit, push, or restart A6.
```

## Sources

The project operating protocol requires implementation and independent audit to remain separate, with any changed implementation receiving a fresh read-only audit.  The provenance protocol requires exact-byte reproduction before correctness inspection and makes clear that matching hashes do not themselves prove correctness. 

The broader MVP claim also classifies generated reports and proof artifacts as evidence or projection rather than execution or orchestration authority, which remains important for the foreign-collision distinction. 

**Confidence**

- The remaining issue is an inconsistent acceptance criterion, not a source defect: **0.995**
- Preserving a concurrently created foreign final object is the correct safety behavior: **0.999**
- Current source bytes should proceed directly to fresh independent audit: **0.98**
- No additional producer implementation pass is warranted before that audit: **0.97**
