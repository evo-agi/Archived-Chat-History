## Engineering assessment

This report clears the repaired audit harness for its intended use. It does not accept the implementation package, but it now provides a sealed, qualified, frozen audit executor for exactly one fresh independent audit.

The material result is stronger than another documentary repair:

- The canonical terminal root identity remains `/inventory/root_identity`; no duplicate top-level alias or fallback was introduced.
- The provider and forwarding functions remained unchanged. Only `build_inline_report` and new typed adapter helpers changed.
- The repaired source registry closes over eight files and 21 roles.
- Both authorized source attempts were consumed, with Attempt 2 succeeding. The production repair did not change between the attempts; Attempt 2 corrected only qualification-result polarity.
- Twenty terminal-adapter cases, 70 direct cross-module cases, and all 209 inherited cases passed.
- Success, substantive `BLOCK`, and four failure lanes passed through the real adapter.
- Bounded live replay reached actual adapter report and marker generation without adjudicating the implementation.
- The independent validator directly exercised the real seal-to-report path.
- Source freeze, frozen requalification, supplied-root equality, and terminal package closure all passed. :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"} :chatgpt-content-reference{index="2"}

The repaired package is rooted at `/Users/ds/Downloads/ES-repair10i-v3-gen2-independent-audit-harness-terminal-adapter-repair-5u3oi458`, identity `16777234/181106957/0700`. Its temporal inventory and matching manifests sealed a clean 101-entry physical package with no empty files, invalid objects, mode defects, or post-seal filesystem operation. :chatgpt-content-reference{index="3"} :chatgpt-content-reference{index="4"}

### Progression decision

Execute **one fresh source-external independent audit** of the unchanged implementation package using this exact sealed harness.

Do not combine any repair with that audit. The three possible outcomes now have distinct continuations:

- **Accepted:** authorize one exact use of the audited frozen reconstruction parent to build the authoritative current schema subject.
- **Implementation blocked:** repair or replace the implementation package under the audit’s exact bounded findings, then independently audit its successor.
- **Audit provenance mismatch:** do not localize another repair in this harness lineage. Preserve the attempt and move to a clean source-external audit-harness implementation.

```text
EXECUTE ONE FRESH INDEPENDENT AUDIT OF THE SEALED GENERATION-2
SCHEMA-SUBJECT RECONSTRUCTION-PARENT IMPLEMENTATION

Objective

Use the exact sealed and qualified independent-audit harness to perform one
fresh source-external audit of the unchanged sealed Generation-2
reconstruction-parent implementation package.

This task executes the audit. It does not repair the harness, repair the
implementation, construct the authoritative current schema subject, or perform
product/runtime work.

Do not modify any supplied root.

Do not create replacement audit source.

Do not requalify or patch the sealed harness.

Do not resume or adopt any historical audit root.

Do not retry the full audit.

Do not create subagents or direct auditors.
Do not run Git.
Do not use the network.
Do not install dependencies.
Do not invoke product or live-service behavior.
Do not deploy, publish, externally commit, or start A6.

Use the sealed harness’s exact current source registry, frozen invocation
contract, process-custody contract, full-audit phase plan, verdict rules,
terminal adapter, and capsule lifecycle.

Return the complete operative report inline. Private artifact paths may
supplement but may not replace causal findings, material values, process
custody, validation results, and disposition.

Return exactly one primary verdict:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_IMPLEMENTATION_INDEPENDENT_AUDIT_ACCEPTED_READY_FOR_ONE_SHOT_SUBJECT_CONSTRUCTION

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_IMPLEMENTATION_INDEPENDENT_AUDIT_BLOCKED

AUDIT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. SEALED AUDIT-HARNESS PACKAGE
──────────────────────────────────────────────────────────────────────────────

AUDIT_HARNESS_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-gen2-independent-audit-harness-terminal-adapter-repair-5u3oi458

Expected identity:

- device:
  16777234
- inode:
  181106957
- mode:
  0700
- retained verdict:
  SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_INDEPENDENT_AUDIT_HARNESS_TERMINAL_ADAPTER_REPAIRED_READY_FOR_FRESH_AUDIT

Expected current source registry:

contract/repaired-audit-harness-source-registry-v2.json

- inode:
  181111335
- size:
  7045
- SHA-256:
  06c7612cb850e5e139710899b030e92fa5fc0f1cd69194b3957539eddb46f3e7

Expected current source identities:

Repaired audit parent:

- inode:
  181108257
- size:
  248859
- SHA-256:
  8940bcb9171e5627d6b48446d55db85898fba402ec2661b49b11c9ebfb63eb97

Audit recorder:

- inode:
  181108258
- size:
  6209
- SHA-256:
  ec724c7dd00feb63d918cc8497336b01d681b542b0aa7e76f5b7dc0fec40119a

Predecessor independent validator:

- inode:
  181108259
- size:
  18809
- SHA-256:
  2345012ade8e63c3a5e96a19c57b42be2428c8a284238cbe69bdc81479bdca21

Platform-capture helper:

- inode:
  181108260
- size:
  3344
- SHA-256:
  1a53f3d74297c42e0e7d9002fed551dca685caed280357a657910c40e2d85670

Predecessor qualification driver:

- inode:
  181108261
- size:
  59954
- SHA-256:
  c55912bd92be12f844761e3f2a04f4ee878c528d3b665b36bde535fd00ed3e48

Repair core:

- inode:
  181108262
- size:
  46559
- SHA-256:
  adaecf6cf565748a95e2afe2059ea811638fbbae60188d8133adb3b69ccb65d5

Independent terminal validator:

- inode:
  181108263
- size:
  13434
- SHA-256:
  204f5eb7f8ecd76e4a66f06b23917de329568efbf92e5d175b06c70c647d8c0c

Terminal qualification:

- inode:
  181108264
- size:
  35563
- SHA-256:
  68de4d3c1a9b9f92fb8178524445e817872cae23912259c372ef43e1305ad2f1

Expected source-freeze record:

opening/final-terminal-adapter-repair-source-freeze-v2.json

- inode:
  181111340
- size:
  5392
- SHA-256:
  97bce1a778e28cb6998e866b7dedb68339bd69b22f5f2627a1cf2283cb502196

Expected frozen requalification:

- inode:
  181111443
- size:
  3828
- SHA-256:
  6bea7fa38c4d9401b4f5ab0c6b1d291426f2ec772b12c1a763add277b5b4fb7b

Expected independent-validator result:

- inode:
  181111440
- size:
  4315
- SHA-256:
  4ad999765b70f21f1d3e113c4d9c6ea6df972052475717c0347cbf0a8cda2222

Expected package status:

analysis/harness-package-status-v2.json

- inode:
  181111444
- size:
  648
- SHA-256:
  499629d5f0e8df164482fb1cabe9aec736b15a5fe256d60b87eb0bd92aca81d9

Expected operative status:

- repaired harness qualified and frozen;
- fresh audit pending;
- implementation adjudication absent;
- full audit not run.

Expected supplied-root equality:

closing/supplied-root-closing-equality-final-v2.json

- inode:
  181111442
- size:
  285300
- SHA-256:
  8a0d53a2373cc14c31ccd0b54eabab5e1d4389ef61977bd89476357d221f0b90

Expected harness temporal inventory:

closeout/temporal-final-inventory-v2.json

- device:
  16777234
- inode:
  181111454
- mode:
  0600
- link count:
  1
- size:
  28284
- SHA-256:
  0840ce855995c08e9b6671b8664c6a87cb282bef2cb84d3cdbe5b61a18c4f4fa

Expected manifest A:

- inode:
  181111452
- mode:
  0600
- link count:
  1
- size:
  33400
- SHA-256:
  84a369d0682c12a865d966268f1e1f11888139533704c531134bf05b466c1fa0

Expected manifest B:

- inode:
  181111453
- mode:
  0600
- link count:
  1
- size:
  33400
- SHA-256:
  84a369d0682c12a865d966268f1e1f11888139533704c531134bf05b466c1fa0

Expected closure:

- 101 physical entries including root;
- 20 directories;
- 81 regular files;
- 98 temporal represented entries;
- 99 manifest represented entries;
- one root row;
- no empty file or descendant;
- no symlink or special object;
- no multiply linked regular file;
- no cache or bytecode;
- modes 0700/0600;
- no post-seal filesystem operation.

Authenticate the complete harness package before launch.

Do not select a different source or role by basename, first match, recency,
fallback, or report prose.

Any harness identity, source-freeze, frozen-requalification, status, manifest,
or closure mismatch is:

AUDIT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
2. IMPLEMENTATION PACKAGE UNDER AUDIT
──────────────────────────────────────────────────────────────────────────────

IMPLEMENTATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634

Expected identity:

- device:
  16777234
- inode:
  180884963
- mode:
  0700
- producer verdict:
  SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_INDEPENDENT_AUDIT

Expected producer posture:

- physical entries:
  112
- directories including root:
  17
- regular files:
  95
- terminal-manifest represented entries:
  110
- temporal represented entries:
  109
- current subject constructed:
  false
- implementation status:
  frozen pending independent audit
- one-shot current-subject use:
  unauthorized

Expected fixed identities:

Final production-source registry:

- size:
  704
- SHA-256:
  1ded4df7836c16a153b6aab587d7d41903f1d8e907903a0000ae0efb518962c4

Final production source:

- size:
  65305
- SHA-256:
  8edb8790e140560de891830919571e616852df8b7878d9d4e403fb0dde70bc6e

Final qualification-source registry:

- size:
  4391
- SHA-256:
  57c22b15bab5667d32f9949867f198eddd41b0d345ad1d30111370c6c1548a8c

Source freeze:

- size:
  4057
- SHA-256:
  678f4fb76c4bab0d686e106911e28eb34328e0abdc280cee38cca6a8265e135b

Frozen-source requalification:

- size:
  31819
- SHA-256:
  5e48332bec6610032ea14067eeecda20f653a14af03d0d27f9edc09db862e21f

Complete retained child ledger:

- SHA-256:
  68417ca2a1adf28f6a23eb4441ade07c53ff59ad41f4c064a72e7ef21b76537c

Producer supplied-root equality:

- SHA-256:
  bb1e3da048d3da927173096a167dcfbbc93a62dd8e9e65fbff11215cc7062331

Treat every package result as supplied producer evidence, not audit authority.

Do not modify, reseal, repair, or resume this root.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
3. GOVERNING GENERATION-2 AND EXTERNAL ROOTS
──────────────────────────────────────────────────────────────────────────────

GEN2_SUCCESSOR_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-bootstrap-order-repair-t9kydqve

Expected identity:

- device/inode:
  16777234 / 180871216
- mode:
  0700

Expected current role registry:

contract/current-gen2-contract-role-registry-v2.json

- size:
  37791
- SHA-256:
  6fb98f6558b18c22c161b9869ca3cf4752c0867307fa17b5e255d9dc21e2963f

AUTHORITATIVE_CONTRACT_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-2y6tkl0n

Expected identity:

- device/inode:
  16777234 / 180472094
- mode:
  0700

Normative contract:

contract/package-construction-parent-v1.json

- size:
  32038
- SHA-256:
  874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19

SCHEMA_SOURCE_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-repair-pw27ydqf

Expected identity:

- device/inode:
  16777234 / 180513083
- mode:
  0700

SCHEMA_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-construction-parent-schema-reconciliation-5e2lsx8t

Expected identity:

- device/inode:
  16777234 / 180480821
- mode:
  0700

VALIDATION_SPEC_SOURCE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-evidence-repair-lj_8xygs

Expected identity:

- device/inode:
  16777234 / 180576497
- mode:
  0700

ATTEMPT_2_FAILED_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-hqsolb0v

Expected identity:

- device/inode:
  16777234 / 180892391
- mode:
  0700

Expected failure outcome:

- inode:
  180892410
- size:
  3352
- SHA-256:
  2168ff6dcba31613d7071cdd2d86ee7895e4331dd1c9ab4d4d94ea6e779eecf0

Use only current roles from the successor registry.

Require complete opening/closing equality for every supplied root opened.

Do not modify or clean any supplied root.

──────────────────────────────────────────────────────────────────────────────
4. PLATFORM-CAPTURE PREFLIGHT
──────────────────────────────────────────────────────────────────────────────

Before launching the full audit, use the exact sealed platform-capture helper.

Run one bounded preflight that:

- emits one known stdout line;
- emits a different known stderr line;
- exits with one known nonzero code;
- reads no stdin;
- touches no supplied root;
- allocates no audit capsule.

Retain exact:

- helper identity;
- argv;
- cwd;
- environment;
- PID;
- start and completion;
- stdout bytes, size, SHA-256;
- stderr bytes, size, SHA-256;
- exit code;
- signal;
- reaping;
- descriptor closure.

The full audit may launch only when separate-stream and completion capture pass.

A platform-capture failure is:

AUDIT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
5. EXACT FULL-AUDIT INVOCATION
──────────────────────────────────────────────────────────────────────────────

Derive the invocation solely from the sealed harness package’s:

- current source registry;
- source freeze;
- frozen requalification;
- bounded live replay;
- current full-audit interface contract.

Do not manually reconstruct an invocation from prose.

Do not infer a source path from filename conventions.

Do not use a predecessor source.

Require one unique invocation binding:

- exact pinned interpreter;
- exact `-I -S -B`;
- exact repaired audit-parent source;
- exact full-audit mode;
- exact implementation root;
- exact successor Generation-2 root;
- exact authoritative contract root;
- exact schema source;
- exact schema reconciliation root;
- exact validation-specification root;
- exact Attempt-2 failure root when the current contract supplies it;
- exact cwd;
- exact environment;
- DEVNULL stdin;
- finite timeout;
- locator grammar;
- expected exit classes;
- stdout/stderr posture.

Retain:

opening/exact-fresh-full-audit-invocation-v1.json

If no single exact invocation derives, return:

AUDIT_PROVENANCE_MISMATCH

Do not patch or replace the harness.

──────────────────────────────────────────────────────────────────────────────
6. SINGLE PARENT EXECUTION
──────────────────────────────────────────────────────────────────────────────

Execute the exact frozen repaired audit parent exactly once.

Do not:

- launch a replacement parent;
- resume the parent;
- send it commands through stdin;
- run an administrative continuation;
- launch a separate package auditor;
- use a subagent;
- recover by polling for a guessed root.

Capture:

- platform custody ID;
- PID;
- exact argv;
- cwd;
- explicit environment;
- start;
- completion;
- duration;
- exit code;
- signal;
- raw stdout bytes, size, SHA-256;
- raw stderr bytes, size, SHA-256.

Require stdout to contain exactly one valid audit-root locator and the governing
terminal output allowed by the frozen contract.

Select the fresh audit root only from the exact parent locator.

Do not scan `/Users/ds/Downloads`.

Do not select by prefix, recency, inode search, basename, or score.

If the locator is absent, ambiguous, malformed, or not captured, return:

AUDIT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
7. AUDIT AUTHORITY
──────────────────────────────────────────────────────────────────────────────

The fresh audit may:

- authenticate supplied roots;
- inspect source and evidence read-only;
- run audit-owned matrices and causals;
- execute two disposable reconstruction rehearsals using the exact frozen
  implementation source;
- retain and compare rehearsal evidence;
- remove only audit-owned rehearsal and fixture roots after evidence retention;
- issue the implementation-package verdict;
- close its own capsule.

The fresh audit may not:

- modify the implementation package;
- modify governing contracts or schemas;
- repair implementation source;
- repair the audit harness;
- construct the authoritative current schema subject;
- invoke product or live-service behavior;
- mutate repositories;
- deploy or publish;
- start A6.

──────────────────────────────────────────────────────────────────────────────
8. REQUIRED IMPLEMENTATION-PACKAGE AUDIT COVERAGE
──────────────────────────────────────────────────────────────────────────────

The frozen audit parent must independently complete every current audit phase
and retain terminal records for all required lanes.

At minimum require:

A. Fixed identities and closure

- implementation package physical closure;
- temporal-inventory reprojection;
- manifest A/B reprojection;
- root-row and exclusions;
- modes, types, links, topology, cache, and bytecode;
- successor package closure;
- all 41 current roles;
- all authoritative external inputs.

B. Source and attempt lineage

- current production registry;
- current qualification registry;
- all current source identities;
- Attempts 1–3;
- first blocker and disposition of failed attempts;
- only Attempt 3 current;
- no stale result bound to superseded source;
- source freeze;
- frozen requalification;
- producer rehearsal-to-frozen-source linkage.

C. Production authority and state machine

- all 24 production roles;
- all nine qualification roles;
- one writer per mutable fact;
- E00;
- G00;
- G01;
- G02;
- G03;
- G04;
- G05–G29;
- exact phase order;
- no authority before its owning phase;
- no directory creation after G01;
- terminal seal and no postseal operation.

D. Qualification-source independence

- independent validators import no production or producer helper;
- package matrices bind current source;
- no hidden shared expected-result oracle;
- no stale identity.

E. Writer and documentary evidence

- exact 73-path subject namespace;
- one writer per path;
- no overwrite or adoption;
- confirmation validator single writer;
- final ten-role registry after all results;
- regeneration derived from final registry;
- evidence-derived confirmations;
- no circular validation.

F. Process and failure custody

- one production recorder;
- complete child ledger;
- streams;
- exit/signal;
- reaping and descriptor closure;
- fixed/dynamic effects;
- exact locator handling;
- cleanup-set equality;
- evidence before cleanup;
- Attempt-2 G06 failure specimen;
- no same-root retry.

G. Confirmation registry

- all 125 names;
- unique name set;
- exact evidence binding;
- no hard-coded success;
- no absence-as-success;
- correct preterminal/terminal treatment;
- no stale source binding.

H. Security and authority

- no production network;
- no Git;
- no shell;
- no PATH executable lookup;
- no broad root discovery;
- no latest/prefix/score selection;
- no existing-root adoption;
- no production-reachable qualification hook;
- no repository/product/target invocation;
- no authority widening.

──────────────────────────────────────────────────────────────────────────────
9. FRESH INDEPENDENT VALIDATION LANES
──────────────────────────────────────────────────────────────────────────────

Freshly execute every current audit-owned validation lane required by the
sealed harness.

At minimum retain fresh results for:

- bootstrap-order matrix;
- external-interface matrix;
- JSON-observation matrix;
- schema/family matrix;
- process-custody/locator matrix;
- cleanup/failure-evidence matrix;
- writer/lifecycle matrix;
- namespace/temporal matrix;
- manifest/terminal matrix;
- negative-checker robustness matrix;
- complete 946-case negative audit;
- complete 137-case contradiction regression;
- 766/333 field-map closure.

For every lane require:

- exact authenticated case-name registry;
- unique names;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

Producer results are comparison evidence only.

──────────────────────────────────────────────────────────────────────────────
10. E00 NEGATIVE CAUSALS
──────────────────────────────────────────────────────────────────────────────

Execute the current bounded E00 causal set against the exact frozen
implementation production source, including:

- missing `-I`;
- missing `-S`;
- missing `-B`;
- missing all three;
- option tokens only after the script operand;
- wrong interpreter where the current audit contract permits an exact
  unambiguous invocation.

Require for every case:

- rejection before package authority;
- no subject-root allocation;
- no locator;
- exact streams and exit;
- complete process custody;
- no supplied-root mutation;
- no unregistered filesystem effect.

──────────────────────────────────────────────────────────────────────────────
11. FRESH REHEARSAL A
──────────────────────────────────────────────────────────────────────────────

Derive the exact implementation-parent invocation through the repaired
harness’s authenticated invocation model.

Execute the exact frozen implementation source once.

Require:

- exact process custody;
- exact `SUBJECT_ROOT` locator;
- one fresh root;
- full E00 and G00–G29 completion;
- exact current 73-path namespace;
- exact contract bytes;
- fifteen current schemas;
- 15-role and 14-family closure;
- witnesses;
- all 946 and 137 cases;
- 766/333 field map;
- ten documentary validators;
- confirmation evidence;
- occupancy/status/lineage;
- supplied-root equality;
- cleanup;
- temporal inventory;
- manifest pair;
- terminal reprojection;
- clean topology and modes;
- no postseal operation.

Retain a complete no-follow inventory and every process/result identity.

Do not remove the root yet.

──────────────────────────────────────────────────────────────────────────────
12. FRESH REHEARSAL B
──────────────────────────────────────────────────────────────────────────────

Execute the same exact frozen source and invocation shape a second time.

Require a physically distinct root by path and device/inode.

Retain the same complete custody and evidence.

Do not remove the root yet.

──────────────────────────────────────────────────────────────────────────────
13. SOURCE-EXTERNAL REHEARSAL VALIDATION
──────────────────────────────────────────────────────────────────────────────

Independently adjudicate each rehearsal using the sealed audit harness’s
source-external validators.

Require independent verification of:

- phase sequence and authority;
- namespace;
- contract and schemas;
- 15/14 closure;
- witnesses;
- 946 and 137 result sets;
- field map;
- documentary lifecycle;
- validator result closure;
- confirmation evidence;
- process custody;
- cleanup;
- temporal inventory;
- manifests;
- terminal topology and seal.

Retain:

validation/fresh-rehearsal-a-independent-result-v1.json
validation/fresh-rehearsal-b-independent-result-v1.json

Require zero errors.

──────────────────────────────────────────────────────────────────────────────
14. NORMALIZED REHEARSAL COMPARISON
──────────────────────────────────────────────────────────────────────────────

Normalize only explicitly physical bindings:

- root paths;
- device/inode;
- PIDs;
- root-bound identities;
- nonacceptance-bearing timestamps;
- fields explicitly classified as physical.

Compare all semantic artifacts, including:

- contract bytes;
- schema identities;
- role and family rows;
- mapping;
- witnesses;
- all 946 results;
- all 137 results;
- field-map rows;
- validator registry and results;
- documentary DAG;
- confirmation semantics;
- occupancy/status/lineage;
- temporal semantics;
- normalized manifest bytes;
- final topology.

Require zero unexplained difference.

Retain:

validation/two-fresh-independent-rehearsals-v1.json

──────────────────────────────────────────────────────────────────────────────
15. QUALIFICATION-EVIDENCE RECONCILIATION
──────────────────────────────────────────────────────────────────────────────

Crosswalk the fresh independent results against the sealed implementation
package’s producer evidence.

Classify every difference as:

- expected physical difference;
- producer formatting difference;
- producer validation defect;
- implementation defect;
- audit defect;
- unresolved.

No unresolved acceptance-bearing difference is permitted for acceptance.

Retain:

analysis/package-qualification-evidence-reconciliation-v1.json

──────────────────────────────────────────────────────────────────────────────
16. REHEARSAL EVIDENCE RETENTION AND CLEANUP
──────────────────────────────────────────────────────────────────────────────

Before cleanup retain inside the fresh audit capsule:

- exact A/B root identities;
- complete inventories;
- parent process records;
- stdout/stderr;
- all phase/result identities;
- independent validation;
- normalized comparison;
- qualification reconciliation;
- terminal identities and topology.

Require a passing evidence-retention record.

Then:

1. re-lstat A and verify identity;
2. remove exact A;
3. observe ENOENT twice;
4. re-lstat B and verify identity;
5. remove exact B;
6. observe ENOENT twice;
7. remove all audit-owned causal and fixture roots after evidence retention;
8. observe ENOENT twice per root;
9. require every child reaped;
10. require every descriptor closed;
11. require zero process survivor;
12. require zero cache or bytecode survivor.

Require exact equality:

created audit-owned roots
=
inventoried roots
=
evidence-retained roots
=
cleanup rows
=
twice-absent roots

The equal-empty-set case remains valid for any phase that created no roots.

──────────────────────────────────────────────────────────────────────────────
17. SUPPLIED-ROOT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete no-follow inventories for every supplied root opened:

- sealed repaired audit harness;
- sealed implementation package;
- successor Generation-2 package;
- authoritative contract package;
- schema source;
- schema reconciliation;
- validation specification;
- Attempt-2 failed root;
- any additional supplied root actually opened.

Require exact opening/closing equality.

Do not modify or clean supplied roots.

Any inequality is:

AUDIT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
18. PRESEAL VERDICT
──────────────────────────────────────────────────────────────────────────────

Before terminal audit-capsule closure, retain:

closeout/preseal-independent-audit-result-v1.json

It must bind:

- fixed-input authentication;
- implementation closure;
- 41-role resolution;
- source/attempt/freeze adjudication;
- production and qualification source audit;
- writer and documentary lifecycle;
- process/failure custody;
- 125-confirmation audit;
- fresh matrices;
- E00 causals;
- fresh rehearsal A/B;
- normalized comparison;
- qualification reconciliation;
- security and authority;
- cleanup;
- supplied-root equality;
- complete severity-ranked findings;
- proposed primary verdict.

The preseal record is nonauthoritative until the audit capsule terminally
closes.

──────────────────────────────────────────────────────────────────────────────
19. FRESH AUDIT-CAPSULE TERMINAL CLOSURE
──────────────────────────────────────────────────────────────────────────────

Use the sealed repaired harness’s current capsule lifecycle and terminal
adapter.

Before temporal projection:

- finalize all nonclosure artifacts;
- create only used final directories;
- ensure `closeout/` and `manifest/` exist;
- retain no empty descendant;
- reserve manifest A/B before projection;
- freeze the directory set;
- prohibit later directory creation.

Then require:

- temporal inventory created and immediately reprojected;
- manifest A/B independently generated and byte-identical;
- descriptor/path/inode/type/mode/link/size/hash custody;
- final independent reprojection;
- root row exactly once;
- no empty descendant;
- no symlink or special object;
- no multiply linked regular file;
- modes 0700/0600;
- no cache or bytecode;
- one seal transition;
- terminal report built through the repaired typed adapter;
- canonical root identity taken from `/inventory/root_identity`;
- no top-level compatibility alias;
- exact verdict and marker;
- nonreturning exit;
- no postseal filesystem or tool operation.

──────────────────────────────────────────────────────────────────────────────
20. VERDICT RULES AND TERMINAL PROGRESSION
──────────────────────────────────────────────────────────────────────────────

Return:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_IMPLEMENTATION_INDEPENDENT_AUDIT_ACCEPTED_READY_FOR_ONE_SHOT_SUBJECT_CONSTRUCTION

only when all substantive and provenance gates pass and the fresh audit capsule
terminally closes.

Do not construct the current schema subject in this task.

The next tranche after acceptance is one exact use of the audited frozen
implementation source to construct one authoritative current schema-subject
root, followed by its own required independent acceptance path.

Return:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_IMPLEMENTATION_INDEPENDENT_AUDIT_BLOCKED

when the audit independently establishes an implementation-package defect.

Do not repair the implementation in this task.

Retain exact bounded package-repair ownership and validation requirements.

Return:

AUDIT_PROVENANCE_MISMATCH

for an audit-process failure, including:

- harness identity or freeze mismatch;
- platform-capture failure;
- missing or ambiguous locator;
- lost child stream or process record;
- unaccounted audit-owned effect;
- indispensable evidence lost before cleanup;
- cleanup inequality;
- supplied-root mutation or inequality;
- audit-capsule closure failure;
- postseal operation.

If this fresh execution returns `AUDIT_PROVENANCE_MISMATCH` because of another
audit-harness source or interface defect:

- preserve the failed audit unchanged;
- do not issue another localized repair of this incremental harness lineage;
- set:
  retire_incremental_harness_lineage=true
- set:
  clean_source_external_audit_harness_implementation_required=true
- set:
  further_localized_repair_authorized=false

Do not reinterpret an audit provenance mismatch as an implementation defect.

──────────────────────────────────────────────────────────────────────────────
21. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Sealed harness identity and closure
3. Harness source registry, freeze, and requalification
4. Platform-capture preflight
5. Exact full-audit invocation
6. Parent platform custody and raw streams
7. Fresh audit-root locator and identity
8. Implementation-package identity and closure
9. Implementation temporal-inventory identity and reprojection
10. Implementation manifest A identity and reprojection
11. Implementation manifest B identity and reprojection
12. Successor Generation-2 authentication
13. Current 41-role resolution
14. External-root authentication
15. Attempt-2 failed-root authentication
16. Current production-source registry
17. Current qualification-source registry
18. Attempt 1–3 lineage
19. Source freeze and frozen-requalification adjudication
20. Production component-role audit
21. Qualification-source independence audit
22. E00 audit
23. G00 audit
24. G01 audit
25. G02 audit
26. G03 audit
27. G04 audit
28. G05–G29 audit
29. Writer-registry audit
30. Documentary-lifecycle audit
31. Process/failure-custody audit
32. Complete 125-confirmation audit
33. Fresh bootstrap-order matrix
34. Fresh external-interface matrix
35. Fresh JSON-observation matrix
36. Fresh schema/family matrix
37. Fresh process-custody/locator matrix
38. Fresh cleanup/failure-evidence matrix
39. Fresh writer/lifecycle matrix
40. Fresh namespace/temporal matrix
41. Fresh manifest/terminal matrix
42. Fresh negative-checker robustness matrix
43. Fresh 946-case result
44. Fresh 137-case result
45. Fresh 766/333 field-map result
46. E00 negative causals
47. Fresh rehearsal A
48. Fresh rehearsal B
49. Independent rehearsal A adjudication
50. Independent rehearsal B adjudication
51. Normalized rehearsal comparison
52. Package qualification-evidence reconciliation
53. Security and authority findings
54. Severity-ranked findings
55. Rehearsal evidence-retention result
56. Rehearsal and fixture cleanup
57. Complete audit child-process ledger
58. Supplied-root closing equality
59. Preseal substantive verdict
60. Audit temporal-inventory identity
61. Audit manifest A identity
62. Audit manifest B identity
63. Independent audit-capsule reprojection
64. Terminal membership and modes
65. Terminal adapter/report/marker result
66. No-write-after-seal
67. Progression disposition
68. Remaining uncertainty and nonclaims
69. Explicit confirmation registry

Resolve every confirmation required by the sealed repaired harness’s current
full-audit contract.

At minimum require confirmations for:

- harness identity, source freeze, and requalification;
- platform capture;
- exact single parent execution;
- exact audit-root locator;
- implementation package immutability;
- all current-role and source bindings;
- fresh matrix closure;
- E00 causals;
- two fresh rehearsals;
- normalized equality;
- independent validation;
- evidence-before-cleanup;
- cleanup-set equality;
- child reaping and descriptor closure;
- supplied-root equality;
- audit-capsule temporal and manifest closure;
- root row;
- clean topology and modes;
- canonical terminal-adapter path;
- no postseal operation;
- no Git, network, product/live service, target audit, runtime rerun, A6, or
  subagents.
```

**Sources:** The attached report states that the repaired harness is qualified and frozen for a fresh audit, preserves `/inventory/root_identity` as the sole canonical value, changes only the report consumer and typed helpers, and passes its source-delta protections. :chatgpt-content-reference{index="5"} :chatgpt-content-reference{index="6"} It also records two bounded attempts ending in a current successful Attempt 2, direct terminal-adapter and cross-module coverage, inherited regression closure, synthetic terminal lanes, bounded live replay, independent validation, source freeze, and frozen requalification. :chatgpt-content-reference{index="7"} :chatgpt-content-reference{index="8"} Its final package has matching terminal manifests, clean topology, passing terminal reprojection, zero post-seal operations, and an explicit nonclaim over implementation acceptance because the full audit was not run. :chatgpt-content-reference{index="9"}

**Confidence:** 0.997 that one fresh audit is now the correct and only immediate tranche; 0.995 that implementation acceptance and current-subject construction remain unauthorized; 0.98 that any further harness provenance failure should terminate this incremental harness lineage rather than trigger another localized repair.
