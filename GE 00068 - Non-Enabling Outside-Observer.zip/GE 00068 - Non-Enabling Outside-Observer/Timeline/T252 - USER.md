Here is Codex's response:

# Fresh independent exact-source audit — Repair 10I T2A-P strategic B snapshot

## 1. Primary verdict

**BLOCK**

Opening and closing provenance, all 389 source origins, H→B reconstruction, the B tree, and the synthetic evidence commit qualify. The acceptance boundary does not: two required fresh-validation identities fail because the mandated audit-private path cannot satisfy B’s 100-byte Unix-socket planning limit.

This is repairable within the strategic snapshot/validation boundary, so it is BLOCK rather than REJECT. It is not AUDIT\_PROVENANCE\_MISMATCH because every supplied identity remained equal across opening and closing.

## 2. Audit-root identity

Fresh root: `/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-independent-audit-qtbsxpc9`

- Device: `16777234`
- Inode: `178361381`
- Mode: `0700`
- Allocated under umask 077 with the required `tempfile.mkdtemp` prefix
- Parent-only audit; nested subagents: `0`

## 3. Candidate and supplied-root opening identities

Candidate device/inode/mode: `16777234/122118502/0755`

- Branch: `codex/remote-alpha-external-tls-status-observation-v1`
- HEAD: `567bceced5df95ecfe787cc66038d463a854e12c`
- HEAD tree: `b7cab23732572c2aaea9d5f2f1593338e2e75338`
- Sole parent: `05dde14d185b6e022dcc169ef1a658a97961850f`
- Upstream: absent
- Tracked/untracked/governed: `375/14/389`
- Modified: `22`
- Staged/deleted/renamed/unmerged: `0/0/0/0`
- F source T: `f276536fea579d0842cda43b0290656b200b7f27`
- F inventory: `54314` bytes / `2c152fd6a6d558bff3a56d906f0bd0b8c7f346fcb647d40fe386cfd02163d738`
- Index device/inode/mode/size: `16777234/177958951/0600/44490`
- Index SHA-256: `b2856028ec627e9f5f07d508a08b840545750419e98ce32a869d8d7197a20d91`
- No lock or operation marker

| Supplied rootDevice/inodeDirs/filesLogical bytesCanonical aggregate SHA-256 |                      |                |               |                                                                    |
| --------------------------------------------------------------------------- | -------------------- | -------------- | ------------- | ------------------------------------------------------------------ |
| `accepted_governance_mode_provenance_audit`                                 | `16777234/177899858` | `4/5`          | `716651`      | `a69a86c1506ff7e39b5f75175c08a4140ec8851af6164228625578470c30fd9b` |
| `commit_scope_reconciliation`                                               | `16777234/177969035` | `31/234`       | `2210939`     | `5c2da60ab476492aa6f960e9ddb0b890eca244bbedc81f62bca709f87396486f` |
| `failed_staged_tree_gate`                                                   | `16777234/177938057` | `6/66`         | `1424535`     | `ce4cc73b2f5688daf79e41d2aa627f78a9b080f00233c8dc9801cacf8ddbd1b1` |
| `governance_audit_repair`                                                   | `16777234/177742499` | `10/98`        | `6610704`     | `6d359f034b1366a29a5455b6205499724a2e7037e38b5012946216569e3441fb` |
| `governance_freeze_implementation`                                          | `16777234/177683220` | `14/60`        | `3365062`     | `c6fc33db8905462008f34ed7ccb060837d9291c8003604c7a2fee3d2b71bdb4d` |
| `predecessor_topology_reconciliation`                                       | `16777234/178071975` | `16/75`        | `3604378`     | `97fdb291e918dd50a271f042c350c6025ef3aa93d75dbb9053bcd22e6a4c3da2` |
| `repair10_lineage`                                                          | `16777234/149648711` | `21693/129296` | `12556899768` | `eb3fd5f3836eb32879596fa0f66735301652230fb18b21528fe304e9d11860a6` |

All seven expected aggregate identities matched.

## 4. Strategic snapshot closure

Root device/inode/mode: `16777234/178255587/0700`

- Full filesystem: `107` directories and `462` regular files, including both manifests
- Symlinks/special files: `0/0`
- Aggregate: `e03b61fa6ac228d327dbf7d9dc88d4d4a8b3bcb5262e1a9a83b7aed39581eab3`
- Canonical projection: `567` entries
- `107` directories plus `460` nonmanifest files
- Exactly two manifest self-exclusions
- No empty directory
- All directories mode 0700
- All files regular, single-link, mode 0600

## 5. Complete B source-origin adjudication

All `389` unique rows passed exact path, classification, logical mode, physical custody, size, SHA-256, source-root/path identity, retained identity, H blob where present, F identity, and B→F adjudication.

- `C`, candidate-current-F unchanged byte: `382`
- `G`, governance-freeze pre-governance byte: `7`
- Ambiguous origins: `0`
- Inode aliases: `0`

The seven B→F paths sourced from authenticated pre-governance bytes are:

- `.docs/system_overview/artifact_hygiene.md`
- `.docs/system_overview/boundaries.md`
- `.docs/system_overview/capability_probing.md`
- `.docs/system_overview/configuration.md`
- `.docs/system_overview/remote_alpha_external_tls_status_deployment_v1.md`
- `PLANS.md`
- `docs_contract_test.go`

## 6. Logical-mode versus custody-mode adjudication

Repository modes came from authenticated source records, not physical custody:

- `328` paths at `100644`
- `61` paths at `100755`

Snapshot custody held all 389 files as regular, single-link mode 0600 beneath `94` mode-0700 source directories. No symlink, special object, hardlink alias, or candidate/supplied inode alias was found.

## 7. Independent B source T and inventory reconstruction

- Source T: `8de797304ea944b6a155924e0d1e9e8bbe79534e`
- Inventory size: `54314`
- Inventory SHA-256: `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`
- Governed files: `389`

Closing reconstruction independently repeated the same identities.

## 8. Independent H→B 36-path classification

Exactly 22 modified, 14 added, 0 deleted, and 0 renamed:

- `MODIFIED 100644` `.docs/system_overview/artifact_hygiene.md`
- `MODIFIED 100644` `.docs/system_overview/boundaries.md`
- `MODIFIED 100644` `.docs/system_overview/capability_probing.md`
- `MODIFIED 100644` `.docs/system_overview/configuration.md`
- `MODIFIED 100644` `.docs/system_overview/remote_alpha_external_tls_lifecycle.md`
- `MODIFIED 100644` `.docs/system_overview/remote_alpha_external_tls_policy_core_v1.md`
- `ADDED 100644` `.docs/system_overview/remote_alpha_external_tls_status_deployment_v1.md`
- `MODIFIED 100644` `.docs/system_overview/remote_alpha_external_tls_status_observation_v1.md`
- `MODIFIED 100644` `.docs/system_overview/remote_supported_host_alpha.md`
- `MODIFIED 100644` `PLANS.md`
- `MODIFIED 100644` `docs_contract_test.go`
- `MODIFIED 100644` `es/admission/internal/reliablesubmit/sqlite_physical_test.go`
- `MODIFIED 100644` `es/admission/service_direct_test.go`
- `MODIFIED 100644` `es/app/submit_integration_test.go`
- `ADDED 100644` `es/externaltls/cmd/es-external-tls-status-package/main.go`
- `MODIFIED 100644` `es/externaltls/internal/statusobservation/remoteobserver/observe_test.go`
- `ADDED 100644` `es/externaltls/internal/statuspackage/package.go`
- `ADDED 100644` `es/externaltls/internal/statuspackage/package_test.go`
- `ADDED 100644` `es/externaltls/internal/statuspackage/schema.go`
- `MODIFIED 100644` `es/runtimehelper/helper_test.go`
- `MODIFIED 100644` `es/runtimehelper/supervisor_test.go`
- `ADDED 100644` `internal/testsupport/controlroot.go`
- `ADDED 100644` `internal/testsupport/controlroot_test.go`
- `ADDED 100644` `internal/testsupport/process.go`
- `ADDED 100644` `internal/testsupport/process_test.go`
- `MODIFIED 100644` `remote_alpha_migrate_es_service_user_test.go`
- `MODIFIED 100644` `remote_alpha_normal_shell_runtime_image_check_test.go`
- `MODIFIED 100644` `remote_alpha_operator_test.go`
- `ADDED 100644` `remote_alpha_prepare_external_tls_status_test.go`
- `MODIFIED 100644` `remote_alpha_runtime_security_boundary_check_test.go`
- `MODIFIED 100644` `remote_alpha_vault_workload_auth_check_test.go`
- `MODIFIED 100755` `scripts/remote_alpha_operator.sh`
- `ADDED 100755` `scripts/remote_alpha_prepare_external_tls_status.sh`
- `ADDED 100644` `testdata/remote_alpha_external_tls_status/repair10_git_session_v1.json`
- `ADDED 100644` `testdata/remote_alpha_external_tls_status/repair10_tree_corpus_v1.json`
- `ADDED 100644` `validation_isolation_test.go`

The independent semantic manifest equals the supplied H-B manifest.

## 9. B Git tree identity

Pure Git-object reconstruction and a separate private index/write-tree both produced:

`8de797304ea944b6a155924e0d1e9e8bbe79534e`

It equals B source T and the required tree identity.

## 10. Synthetic commit reproduction

Private reconstruction produced:

`e42aac659299e023df07a842df17e9fc84a135c1`

Using:

- Tree: `8de797304ea944b6a155924e0d1e9e8bbe79534e`
- Parent: `567bceced5df95ecfe787cc66038d463a854e12c`
- Subject: `implement Remote Alpha external TLS T2A-P source`
- Author/committer: `Repair 10I Strategic Snapshot <repair10i-strategic-snapshot.invalid>`
- Timestamp: `2001-01-01T00:00:00Z`

The raw object is `331` bytes / SHA-256 `ed28443d2af9808ee2d5867356bc7061fccbab903f9b6210ac170549a98bcebb`. No undeclared metadata was present. This identity remains evidence only.

## 11. Non-36 H-path equality

H contained `375` paths. All `353` H paths outside the 36-path delta retained exact blob OID and logical mode. B contains no addition beyond the exact 14 listed above.

## 12. Validation-plan authority adjudication

The recovered plan contains eight commands with exact IDs, argv, rationale, expected exit semantics, identity policies, and governing records.

- B-era documentary set: exactly 105
- F-only later identity: `TestRepair10IA6SuccessorGovernanceContract`
- External-TLS exception set: independently supported
- Nonroot helper-fixture skip: independently supported
- Shell syntax and private `git diff --check`: required supplemental checks

The plan is complete and recovered, not a producer-selected subset.

However, the producer-recorded control/TMP root was the shorter mutable snapshot root. That environment cannot be replayed read-only under the mandated independent-audit root.

## 13. Exact 105 documentary identities and results

Fresh exit `0`; exact top-level closure `105`; all passed; no fail, skip, error, or panic identity.
```
PASS TestDocsRemoteAlphaOperatorFacadeBoundaries
PASS TestDocsRemoteAlphaOperatorP0cFirstDelegationBoundary
PASS TestGo1265ToolchainBaselineDocsAndBuildContract
PASS TestGoldenProducerProofPathIsDocumented
PASS TestHybridIntegrationArchitectureADRDocsContract
PASS TestHybridIntegrationBridgeCodexRowPinsEvidenceBoundary
PASS TestMilestone1BoundaryPostureMatrixIsDocumented
PASS TestMilestone1LeastPrivilegeBoundaryCloseoutIsDocumented
PASS TestPrimaryMilestoneRealignmentPreservesESOwnership
PASS TestProducerFailurePathDistinctionsAreDocumented
PASS TestReliableSubmitContractAdapterFoundationDocsAndSourceContract
PASS TestReliableSubmitPersistenceAndConcurrencyADRDocsContract
PASS TestReliableSubmitPublicOptInAndVersioningDocsContract
PASS TestReliableSubmitPureModelDocsAndSourceContract
PASS TestRemoteAlphaExternalTLSIncidentCompatibilityAndMigration
PASS TestRemoteAlphaExternalTLSLifecycleCurrentAndTargetContract
PASS TestRemoteAlphaExternalTLSLifecycleHasExactPolicyCoreConsumer
PASS TestRemoteAlphaExternalTLSLifecyclePlanningAndBoundaryAlignment
PASS TestRemoteAlphaExternalTLSLifecycleRejectsTargetWidening
PASS TestRemoteAlphaExternalTLSLifecycleSecurityAndOwnership
PASS TestRemoteAlphaExternalTLSPolicyCoreDocumentationContract
PASS TestRemoteAlphaExternalTLSRestorationAndChat00054Boundary
PASS TestRemoteAlphaExternalTLSStatusObservationV1Contract
PASS TestRemoteAlphaExternalTLSStatusT2APackageAndFacadeContract
PASS TestRemoteAlphaExternalTLST2APCurrentTargetMatrixV1
PASS TestRemoteAlphaExternalTLST2APRepair10Contract
PASS TestRemoteAlphaExternalTLST2APRepair5LifecycleOrderV1
PASS TestRemoteAlphaExternalTLST2APRepair7Contract
PASS TestRemoteAlphaExternalTLST2APRepair8Contract
PASS TestRemoteAlphaExternalTLST2APRepair9Contract
PASS TestRemoteAlphaMaintenanceMonitorBoundaryAndRouteMatrix
PASS TestRemoteAlphaOperatorDocsInvolvementAndP0dEvidenceBoundaries
PASS TestRemoteAlphaOperatorHealthcheckTLSCompanionDocsCurrentAndTargetSeparation
PASS TestRemoteAlphaOperatorP0dDocsFirstDelegationBoundary
PASS TestRemoteAlphaOperatorP0fDocsReadinessSessionBoundary
PASS TestRemoteAlphaOperatorP0gDocsRecoverySessionBoundary
PASS TestRemoteAlphaOperatorP0hDocsSchemaAwareRecoveryEvidenceBoundary
PASS TestRemoteAlphaOperatorP0iDocsHostLocalUnsealBoundary
PASS TestRemoteAlphaOperatorP0jDocsMacSideUnsealBoundary
PASS TestRemoteAlphaOperatorP0kDocsMacSideResetDryRunBoundary
PASS TestRemoteAlphaOperatorP0lDocsMacSideResetExecuteContractPrep
PASS TestRemoteAlphaOperatorP0mDocsMacSideResetExecuteImplementationBoundary
PASS TestRemoteAlphaOperatorP0nDocsVaultWorkloadAuthCheckBoundary
PASS TestRemoteAlphaOperatorP0oDocsVaultWorkloadAuthBootstrapPlanningBoundary
PASS TestRemoteAlphaOperatorP0pDocsVaultWorkloadAuthBootstrapExecutionContractPrep
PASS TestRemoteAlphaOperatorP0qDocsVaultWorkloadAuthBootstrapExecutionRoute
PASS TestRemoteAlphaOperatorP0rDocsRuntimeIdentitySummaryRoute
PASS TestRemoteAlphaOperatorP0sDocsESServiceTLSRenewRoute
PASS TestRemoteAlphaOperatorP0tDocsESGovernanceTLSRenewRoute
PASS TestRemoteAlphaOperatorP0uDocsOperatorHealthcheckTLSRenewRoute
PASS TestRemoteAlphaOperatorP0vCompanionDocsCurrentStatusAlignment
PASS TestRemoteAlphaOperatorP0vDocsOperatorHealthcheckTLSNoninteractiveStatusDesign
PASS TestRemoteSupportedHostAlphaAGSServiceHardeningSliceIsDocumented
PASS TestRemoteSupportedHostAlphaARSServiceHardeningSliceIsDocumented
PASS TestRemoteSupportedHostAlphaDirectBoundaryIsDocumented
PASS TestRemoteSupportedHostAlphaDoctorVocabularyIsDocumented
PASS TestRemoteSupportedHostAlphaEGSServiceHardeningSliceIsDocumented
PASS TestRemoteSupportedHostAlphaESBinaryDeploymentOperatorFlowIsDocumented
PASS TestRemoteSupportedHostAlphaESConfigTLSPrepOperatorStagingFlowIsDocumented
PASS TestRemoteSupportedHostAlphaESConfigTLSPrepSliceIsDocumented
PASS TestRemoteSupportedHostAlphaESServiceUserMigrationOperatorFlowIsDocumented
PASS TestRemoteSupportedHostAlphaESServiceUserRollbackRehearsalIsDocumented
PASS TestRemoteSupportedHostAlphaESWritableStateOwnershipOperatorFlowIsDocumented
PASS TestRemoteSupportedHostAlphaESWritableStateReadinessOperatorFlowIsDocumented
PASS TestRemoteSupportedHostAlphaNormalShellRuntimeImageSummarySchemaIsDocumented
PASS TestRemoteSupportedHostAlphaRuntimeSecurityBoundaryCheckerIsDocumented
PASS TestRemoteSupportedHostAlphaSupportBundleSummarySectionsAreDocumented
PASS TestRemoteSupportedHostAlphaVaultServiceUserMigrationSurfaceIsDocumented
PASS TestRemoteSupportedHostAlphaVaultWorkloadAuthSummarySchemaIsDocumented
PASS TestSubmitIdempotencyCorrelationAndRecoveryDocsContract
PASS TestSupportedLocalCPConsumerRunbookPreservesControlPlaneBoundaries
PASS TestSystemOverviewAuthorityHeadersFollowRepoHierarchy
PASS TestWorkstreamASharedKernelDecisionIsDocumented
PASS TestWorkstreamB0ArtifactBoundaryGateIsDocumented
PASS TestWorkstreamB1ArtifactBoundaryGuardrailPostureIsDocumented
PASS TestWorkstreamBArtifactCompatibilityEdgesStayConsistent
PASS TestWorkstreamBArtifactPublicationStorageDecisionIsDocumented
PASS TestWorkstreamC0BoundarySurfaceAssertionsAreDocumented
PASS TestWorkstreamC0ExecutionOwnershipGateIsDocumented
PASS TestWorkstreamC0ExternalAuthorityAndEvidenceNonOwnershipIsDocumented
PASS TestWorkstreamC1PrepareAdmissionGuardrailPostureIsDocumented
PASS TestWorkstreamC2SubmitLifecycleProjectionGuardrailPostureIsDocumented
PASS TestWorkstreamC3RetainedResultAuthorityHandoffGuardrailPostureIsDocumented
PASS TestWorkstreamC4RuntimeIdentityVaultHandoffGuardrailPostureIsDocumented
PASS TestWorkstreamC5StatusLogsResultCancelCompatibilityGuardrailPostureIsDocumented
PASS TestWorkstreamC6AdmissionPolicyLayerV0ContractIsDocumented
PASS TestWorkstreamC6AdmissionPolicyNonClaimsAreDocumented
PASS TestWorkstreamC6ConfigurableAdmissionPolicyInputsAreDocumented
PASS TestWorkstreamC7CheckpointDocsContract
PASS TestWorkstreamCESExecutionAdmissionModelDecisionIsDocumented
PASS TestWorkstreamCLifecycleProjectionAuthorityLabelsAreDocumented
PASS TestWorkstreamCProducerContractPrepareBoundaryTestsAreDocumented
PASS TestWorkstreamCResultSurfaceClassificationStaysConsistent
PASS TestWorkstreamCRetainedResultBundleClarificationIsDocumented
PASS TestWorkstreamCRuntimeProfileBoundaryStaysNarrow
PASS TestWorkstreamCRuntimeProfileCompatibilityMatrixIsDocumented
PASS TestWorkstreamD1bCGSV2AuthorizeContractDesignIsDocumented
PASS TestWorkstreamD1cEGSVersionedRuntimeTrustWrapperDesignIsDocumented
PASS TestWorkstreamD1dIDConfCompatibilityDowngradeIsDocumented
PASS TestWorkstreamDPolicyAuthorizationBoundaryClarificationIsDocumented
PASS TestWorkstreamDVersioningGuardrailBeforeSemanticExpansionIsDocumented
PASS TestWorkstreamERuntimeConfigOwnershipDecisionIsDocumented
PASS TestWorkstreamERuntimeConfigOwnershipKeepsESCGSOutOfESInternal
PASS TestWorkstreamFRuntimeIdentityHandoffOwnershipDecisionIsDocumented
PASS TestWorkstreamFRuntimeIdentityKeepsESCGSOutOfESInternal
```

Stdout: `171315` bytes / `2a04748093c63774e71f0b5ca807f8e40d2985622d9934ac668f110ff5ad382b`; stderr empty.

## 14. Exact external-TLS fail/skip identities and policy

Fresh raw exit `1` is accepted at identity level.

Exactly one failure:

- `execution-substrate/es/externaltls/internal/statuspackage::TestProductionLifetimeLockFD9CLOEXECPreventsChildInheritanceV2` — production FD 9 validation reports `lifetime_lock_identity_invalid`.

Exactly four skips:

- `execution-substrate/es/externaltls/internal/statuspackage::TestPrivateExactCandidateCompilerInputOracleAndOmissionsV2` — governed final-candidate oracle is enabled by the validation runner.
- `execution-substrate/es/externaltls/internal/statuspackage::TestPrivateExactCandidateDeterministicPreparationAndReuseV2` — governed final-candidate package preparation is enabled by the validation runner.
- `execution-substrate/es/externaltls/internal/statuspackage::TestRepair10ECombinedErrorExactCloseCardinalityV2` — governed final-candidate package preparation is enabled by the validation runner.
- `execution-substrate/es/externaltls/internal/statuspackage::TestRepair10PublishedStageCombinedErrorRealPreparationV2` — governed final-candidate package preparation is enabled by the validation runner.

No additional fail, skip, malformed JSON, error, or panic identity occurred.

Stdout: `1481599` bytes / `9775a1bb0ecaaf34d50498464365de2835bf7969d57bd479fc621becaefd84a5`; stderr empty.

## 15. Exact nonroot-product pass/skip identities and policy

Fresh raw exit `1` is not acceptable.

- `PASS` `execution-substrate/es/app::TestExecutionWorkspaceTempDirUsesControlRoot`
- `PASS` `execution-substrate/es/runtimehelper::TestMaterializeHelperPrivateSPIRESocketCreatesStableAliasForMountedSourceDir`
- `SKIP` `execution-substrate/es/app::TestNomadHarnessProcessCustodianFixtureV1` — `private custodian fixture only`; accepted because its passing parent exercises the fixture under the required environment.
- `PASS` `execution-substrate/es/app::TestNomadHarnessProcessCustodianWithoutServiceV1`
- `PASS` `execution-substrate/es/admission/internal/reliablesubmit::TestSQLiteClaimStoreTwoHandlesBusyTimeoutAndHelperProcessContention`
- `PASS` `execution-substrate/es/admission::TestValidateExecutionRuntimeInputsAcceptsRegularBinaryWithoutLiveSPIRESocketAccess`
- `PASS` `execution-substrate/es/admission::TestValidateExecutionRuntimeInputsRejectsNonAbsoluteSPIRESocketPath`
- `PASS` `execution-substrate/es/admission::TestValidateExecutionRuntimeInputsRejectsNonRegularBinary`
- `FAIL` `execution-substrate/es/runtimehelper::TestWaitForHelperReadinessReturnsWhenEndpointServesJWT` — unexpected; the 105-byte audit-owned Unix-socket path was rejected by `bind` as an invalid argument.

Expected eight passes plus one governed skip; observed seven passes, one governed skip, and one unexpected failure.

Stdout: `10849` bytes / `9146c1fee55a7ad673ac34f98e30a3756bb331cbb5f90417eb635e411b4b2bce`; stderr empty.

## 16. Remaining validation commands and results

- `go-version`: exit `0`, PASS. Observed `go version go1.26.5 darwin/arm64`; binary 14,500,160 bytes, mode 0555, SHA-256 `3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19`.
- `testsupport-acceptance`: exit `1`, FAIL.
  - `FAIL` `TestRepair10ControlRootPolicyV1` — `AllocateShortDir` rejected the complete socket path as exceeding 100 bytes.
  - `PASS` `TestRepair10OwnedProcessLifecycleV1`
  - `PASS` `TestRepair10SignalBirthMismatchNeverSignalsV1`
- `repair10-current-affected-pass`: exit `0`; all exact 20 identities passed:
  - `TestRemoteAlphaPrepareExternalTLSStatusDirectExecEnvironmentForwardingAndFailuresV3`
  - `TestRemoteAlphaPrepareExternalTLSStatusFreshBootstrapClosureV2`
  - `TestRemoteAlphaPrepareExternalTLSStatusParseSafeDirectStartupBoundary`
  - `TestRemoteAlphaPrepareExternalTLSStatusPreGoResiduePreservationAndNoShellCleanupV3`
  - `TestRemoteAlphaPrepareExternalTLSStatusWrapperExactGrammar`
  - `TestRemoteAlphaT2APRepair10CClosingConfigAndSourceSessionActualFlowV9`
  - `TestRemoteAlphaT2APRepair10ExactBlobSizeAndLongListingCausalV8`
  - `TestRemoteAlphaT2APRepair10ShellBoundedGitRunnerCausalV7`
  - `TestRemoteAlphaT2APRepair10ShellConfigLeafBracketCausalV7`
  - `TestRemoteAlphaT2APRepair10ShellPrivateReaderCausalV7`
  - `TestRemoteAlphaT2APRepair9SequentialSixCallerPrivateSlotNamespacesV6`
  - `TestRemoteAlphaT2APRepair9ShellObjectBoundaryTimestampDigestV6`
  - `TestRemoteAlphaT2APRepair9ShellPackedLooseDirectoryPrefixCaseFoldV6`
  - `TestRemoteAlphaT2APShellGitTopologyResolutionAndZeroObjectSentinelV5`
  - `TestRemoteAlphaT2APShellLexicalDirectoryGateV4`
  - `TestRemoteAlphaT2APShellRawRefGrammarConformanceV5`
  - `TestRemoteAlphaT2APShellSingleAlternateColonDecoyV5`
  - `TestRepair10IDualSetpgidRaceReconciliationV1`
  - `TestRepair10ISetpgidFailureRequiresExactGroupProofV1`
  - `TestRepair10ISetpgidInverseMutantsV1`
- `bash-syntax`: exit `0`, PASS.
- `private-git-diff-check`: exit `0`, PASS.

Only the 80 already-present module-cache objects across 20 modules were copied, with physical inode separation. Offline settings included `GOPROXY=off`, `GOSUMDB=off`, `GOTOOLCHAIN=local`, and `GOWORK=off`.

Every command left exact B tree/inventory and private Git cleanliness unchanged. Overall fresh validation is false because commands 3 and 6 violated their identity policies.

## 17. Capsule manifests and final-inventory closure

Two independent traversals produced byte-identical `139328`-byte manifests with SHA-256:

`df5933f201437dc9ac55f22f72aac4bdde8477a203b7ca22358ab11e77f5c9fc`

Each equals both supplied manifests.

The pre-seal final inventory has exact closure over `566` represented entries. Its only declared post-seal directory changes are:

- `closeout`: links `14→15`, size `448→480`
- `manifest`: links `2→4`, size `64→128`

Fixed closeout identities pass:

- Final evidence inventory: `130182` bytes / `fb30338e1a0fc39359b3517d6f70303ea086689330074b9f1f35854a431a73bb`
- Final report: `151150` bytes / `2a853c551635c223eec38eb229535285541a653dfa5f1ce59855fd5b2082b2fe`

## 18. Archive, artifact, and sensitive-material findings

- `.examples/control_plane_normal_shell_runtime/dist/control_plane_normal_shell_runtime.tar.gz`: governed source fixture; sole `entrypoint` member, regular mode 0755, safe relative path.
- `.examples/execution_loop/artifacts/static-script-success.tar.gz`: governed source fixture; sole `entrypoint` member, regular mode 0755, safe relative path.
- `.examples/runtime_identity_reference/dist/runtime_identity_reference.tar.gz`: governed source fixture; sole `entrypoint` member, regular mode 0755, safe relative path.
- `.out/Dockerfile`: authenticated governed source path, `1251` bytes / `db6ad1f03a2cc1bb7d52eaca5bb1e28a6dbfb8b008311dcfb418c5c7a17a74fe`.

No member was absolute, parent-traversing, symlinked, or special.

Bounded scanning found no sensitive filename and no plausible live secret. Ten file/pattern pairs are explicit fake/redaction/sanitization fixtures: PEM/RSA markers in governed tests and sanitizer logic, plus `sk-…`-shaped negative/redaction fixtures in five test files.

## 19. Snapshot authority and nonauthority

The snapshot correctly claims only:

- Exact source bytes and logical modes
- H→B classification
- B source T, inventory, and Git-tree candidate
- Observed validation
- Byte provenance

It explicitly disclaims publication, current-repository truth, future commit identity, product/runtime/deployment readiness, A6 readiness, semantic-successor implementation, and orchestrator implementation.

Classification:

- T1: Current invariant
- T2A-P: unaccepted Bounded slice rule
- Legacy operator: Temporary compatibility edge
- T2A-I and T2B: absent
- Repair 10I uses no Reopened redesign seam

## 20. Severity-ranked residual findings

1. **P1 — required independent validation is not reproducible inside the mandated audit custody root.** The shortest allowed physical control/TMP path is the 76-byte audit root itself. With the observed direct-child temporary name and `identity.sock`, the path is at least 103 bytes—105 bytes under the transient root used here—above B’s 100-byte fail-closed limit. Two required identities therefore fail exactly and reproducibly.
2. **P1 — validation-plan environment/custody mismatch.** The producer pass used the shorter supplied snapshot root itself as both `ES_REPAIR10_CONTROL_ROOT` and `TMPDIR`. Replaying that choice would create and remove directories in supplied evidence, which is forbidden in this independent read-only audit. The plan lacks a conformant audit-owned short-path strategy.
3. **P3 — no acceptance effect: historical lineage modes.** The lineage contains authenticated historical 0700 executable evidence files and two 0644 leaves. Its exact expected aggregate binds those modes; the strategic snapshot and this audit’s retained evidence satisfy their separate 0600 rule.

## 21. Minority/alternative interpretations and parent resolution

A temporary audit-root rename, second short root, symlink/mount alias, or supplied-snapshot TMPDIR could shorten the socket path. Each changes the physical custody premise or mutates supplied evidence, so those workarounds were rejected.

A stricter reading might require every historical provenance file to be 0600. That conflicts with the named roots’ exact authenticated aggregates and the specific 0600 requirement for snapshot/audit-retained files. The aggregate-bound historical modes therefore control.

Neither interpretation changes the BLOCK.

## 22. Cleanup and two absence observations

Removed only audit-owned transient:

`/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-independent-audit-qtbsxpc9/t`

Identity: `16777234/178361878/0700`.

- Precleanup process scan: no referencing process
- `/usr/sbin/lsof +D`: no descriptor
- Absence observation 1: fresh `lstat` returned ENOENT
- Filesystem sync
- Absence observation 2: fresh `lstat` returned ENOENT
- Postcleanup process scan: no survivor

## 23. Candidate and supplied-root closing equality

- Candidate opening/closing equality, including branch, HEAD, tree, status, F inventory, and index identity: `true`
- Strategic snapshot complete fingerprint equality: `true`
- All seven named supplied-root inventory equalities: `true`
- Closing retained B source: pass
- Closing manifest reconstruction: pass
- Fixed closeout identities: pass
- Final-evidence-inventory closure: pass

`PROVENANCE_EQUAL=true`

## 24. Audit-created paths and final inventory

Final retained shape:

- `6` directories
- `79` regular files
- No empty directory
- All directories mode 0700
- All files regular, single-link, mode 0600
- Transient `t/` absent

Retained report: [final-audit-report.md](/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-independent-audit-qtbsxpc9/retained/final-audit-report.md)

- Size: `34460`
- SHA-256: `b7e959a5785af954c6be556da594b39fc3c2da37e8d1b09dd775ddcae623ea65`

Final audit-root inventory: [final-audit-root-inventory.json](/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-independent-audit-qtbsxpc9/retained/final-audit-root-inventory.json)

- Entries: `85`
- Directories/files: `6/79`
- Size: `25624`
- SHA-256: `d514e99ce2833bdf6bb36dc5e3b9ced3b9eb52651425f9d6057c13e5fb4a8475`
- The inventory represents itself using an explicit content self-exclusion and hashes every other file.

## 25. Remaining uncertainty and explicit nonclaims

No source, provenance, tree, or synthetic-commit uncertainty remains.

The unresolved acceptance fact is whether a revised and explicitly authorized short audit-owned physical-root design would make the two failing identities pass. That experiment was not permitted and is not claimed.

This audit does not claim publication, current repository truth for B, future commit identity, installation, deployment, runtime readiness, live-service behavior, A6 readiness, T2A-I/T2B implementation, semantic-successor implementation, or orchestrator implementation.

## 26. Explicit confirmations

CANDIDATE\_REPOSITORY\_MUTATION\_NOT\_PERFORMED\
CANDIDATE\_INDEX\_MUTATION\_NOT\_PERFORMED\
STRATEGIC\_B\_SNAPSHOT\_MUTATION\_NOT\_PERFORMED\
OTHER\_SUPPLIED\_EVIDENCE\_NOT\_MUTATED\
EXACT\_B\_SOURCE\_INDEPENDENTLY\_RECONSTRUCTED\
EXACT\_H\_B\_SCOPE\_INDEPENDENTLY\_RECONSTRUCTED\
B\_GIT\_TREE\_INDEPENDENTLY\_REPRODUCED\
SYNTHETIC\_COMMIT\_INDEPENDENTLY\_REPRODUCED\
VALIDATION\_PLAN\_INDEPENDENTLY\_ADJUDICATED\
PRODUCT\_OR\_LIVE\_SERVICE\_NOT\_INVOKED\
NETWORK\_CONTACT\_NOT\_PERFORMED\
A6\_NOT\_STARTED\
SEMANTIC\_SUCCESSOR\_NOT\_IMPLEMENTED\
ORCHESTRATOR\_NOT\_IMPLEMENTED\
STAGING\_NOT\_PERFORMED\_IN\_CANDIDATE\
COMMIT\_NOT\_PERFORMED\_IN\_CANDIDATE\
NESTED\_SUBAGENTS\_CREATED: 0
