## Assessment

The historical `BLOCK` remains authoritative, but this reconciliation did not qualify because it failed to authenticate the subject package’s manifest entries. It therefore cannot authoritatively classify P06, even though the evidence strongly points to an audit defect.

What is already clear:

- **P18 is a concrete audit pass-predicate defect.** All cleanup sets were empty and equal; root, process, descriptor, and cache survivor counts were zero; preseal recorded `cleanup_complete=true`. The phase failed because integer `0` was evaluated as false rather than compared with zero.
- **P06 is strongly indicative of an audit parser/oracle defect.** Its source evaluated:
  ```python
  len(role_registry.get("roles", role_registry.get("schemas", []))) == 15
  ```
  and consumed the fallback empty list, producing count `0`. That does not test the intended fourteen generated-record families and apparently did not even bind the exact fifteen-role schema registry.
- The reconciliation then compounded this by using generic extraction: it found a 25-entry combined role list and a 19-entry `required_fields` list, neither of which establishes the intended P06 domain.
- The unresolved issue is now narrower: **why the subject’s 83 manifest entries failed exact reprojection despite matching counts**. Until the exact differing path and field are identified, neither package provenance nor P06 can be authoritatively resolved.

Do not repair the package or harness yet. The next pass should do only two things:

1. Identify every exact subject-manifest row difference under the subject’s own manifest grammar.
2. Bind P06 to the exact schema-role registry and generated-record-family registry, without recursive list selection or fallback.

P18 should be reauthenticated in that same qualifying reconciliation but does not need another broad investigation.

## Prompt for Codex

```text
READ-ONLY RECONCILIATION OF THE SUBJECT SCHEMA PACKAGE’S
MANIFEST PROVENANCE AND THE FULL AUDIT’S P06 COUNT DOMAIN

This task resolves the provenance failure that prevented authoritative
adjudication of P06 in the historical schema-package BLOCK audit.

It must:

1. identify every exact difference between the subject package’s terminal
   manifest projection and its current physical root under the subject’s own
   manifest grammar; and

2. adjudicate P06 using the exact authoritative schema-role registry and exact
   generated-record-family registry.

It also reauthenticates the already isolated P18 zero-root cleanup defect.

It does not:

- repair the subject package;
- repair the audit harness;
- rerun the full audit;
- reinterpret or replace the historical BLOCK;
- modify the normative contract;
- modify any schema;
- execute any package validator;
- create or patch implementation source;
- execute process-self-test;
- execute construct mode;
- construct a target-audit harness package;
- run a target audit;
- rerun runtime validation;
- modify a repository.

Do not modify, resume, clean, finish, or reseal any supplied root.
Do not use recursive same-length-list selection.
Do not select a record because it has a field named `roles`, `schemas`,
`families`, or `required_fields`.
Do not use basename, recency, scoring, newest/latest, first-match, or fallback
selection.
Do not create subagents or direct auditors.
Do not run Git.
Do not use the network.
Do not invoke product or live-service behavior.
Do not deploy, publish, externally commit, or start A6.

Use one finite parent-owned read-only reconciliation process.

Return the complete substantive report inline.

Return exactly one primary verdict:

SUBJECT_SCHEMA_PROVENANCE_AND_P06_RECONCILED_AUDIT_DEFECT_ONLY
SUBJECT_SCHEMA_PROVENANCE_AND_P06_RECONCILED_PACKAGE_DEFECT_CONFIRMED
SUBJECT_SCHEMA_PROVENANCE_AND_P06_RECONCILED_MIXED_REPAIR_REQUIRED
SUBJECT_SCHEMA_PROVENANCE_AND_P06_RECONCILIATION_BLOCKED
RECONCILIATION_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. SUBJECT SCHEMA-EVIDENCE PACKAGE
──────────────────────────────────────────────────────────────────────────────

SUBJECT_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-evidence-repair-lj_8xygs

Expected identity:

- device:
  16777234
- inode:
  180576497
- mode:
  0700
- producer verdict:
  TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_SCHEMA_EVIDENCE_PACKAGE_REPAIRED

Expected normative contract:

contract/package-construction-parent-v1.json

- size:
  32038
- SHA-256:
  874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19

Expected temporal inventory:

closeout/temporal-final-inventory-v1.json

- size:
  19782
- SHA-256:
  a0b9cea7066be343416abb38e510e3f10f1cb0984d07ed193269ea3d81780b44

Expected terminal manifests:

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

- size:
  19875 each
- SHA-256:
  e3dd1d878e97b5f49c4cd6091f77d1606cccfb83a26b0a16e3404f0dcd2c076b
- byte-identical:
  required

Expected physical closure reported by the producer:

- total physical paths:
  85
- directories:
  10
- regular files:
  75
- manifest-represented paths:
  83
- exact manifest self-exclusions:
  manifest A and manifest B
- empty descendants:
  0
- symlinks:
  0
- special objects:
  0
- multiply linked files:
  0
- directory/file modes:
  0700 / 0600

The immediately preceding reconciliation observed:

- expected manifest-entry count:
  83;
- observed manifest-entry count:
  83;
- exact entry equality:
  false;
- individual divergent entry:
  not retained.

Authenticate this root before interpreting P06.

Do not assume either that the subject package is valid or that the prior
reprojector was defective.

──────────────────────────────────────────────────────────────────────────────
2. AUTHORITATIVE HISTORICAL FULL AUDIT
──────────────────────────────────────────────────────────────────────────────

FULL_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-fresh-schema-package-independent-audit-2o4jt9xo

Expected identity:

- device:
  16777234
- inode:
  180621226
- mode:
  0700
- retained verdict:
  TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_SCHEMA_PACKAGE_BLOCKED
- terminal marker:
  FULL_AUDIT_TERMINAL_SEAL="passed"
- platform exit:
  0

Expected temporal inventory:

- inode:
  180621253
- size:
  6192
- SHA-256:
  07a1a345b1f0705aded67872727884e6b55977ebebd9b59f6eb38810db916451

Expected manifest A:

- inode:
  180621254
- size:
  6346
- SHA-256:
  8f9fec052ebc641d2e2aa7815eba6638bf7d1b01cd7f1a3c339c2af7b5d030d2

Expected manifest B:

- inode:
  180621255
- size:
  6346
- SHA-256:
  8f9fec052ebc641d2e2aa7815eba6638bf7d1b01cd7f1a3c339c2af7b5d030d2

Authenticate through manifest membership and live no-follow observation:

phases/P06.json

- inode:
  180621235
- size:
  559
- SHA-256:
  57213476c84ddcdfe1f68d4c53d60a54df7aada3bdb6a81e5686b3e58d09469e

phases/P18.json

- inode:
  180621247
- size:
  400
- SHA-256:
  a2f95eb5606b857a7ec76ad2fe78adaa55743fb6a843a3896eff0ce0ab03af47

Also authenticate:

- phase-terminal results;
- preseal substantive result;
- primary verdict;
- supplied-root closing equality;
- cleanup-set result;
- complete child ledger.

The historical BLOCK remains authoritative and must not be rewritten.

──────────────────────────────────────────────────────────────────────────────
3. NONQUALIFYING P06/P18 RECONCILIATION
──────────────────────────────────────────────────────────────────────────────

FAILED_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-audit-block-reconciliation-ppg2rkd9

Expected identity:

- device/inode:
  16777234 / 180625230
- mode:
  0700
- verdict:
  RECONCILIATION_PROVENANCE_MISMATCH

Authenticate and inspect at minimum:

opening/fixed-input-authentication-v1.json
analysis/audit-record-resolution-v1.json
analysis/p06-p18-source-crosswalk-v1.json
analysis/p06-count-domain-adjudication-v1.json
analysis/p18-cleanup-semantics-adjudication-v1.json
analysis/p06-p18-verdict-dependency-v1.json
analysis/subject-package-p06-p18-crosscheck-v1.json
analysis/finding-classifications-v1.json
validation/p06-family-count-reconciliation-matrix-v1.json
validation/p18-cleanup-reconciliation-matrix-v1.json
closing/supplied-root-closing-equality-v1.json
closeout/final-reconciliation-report-v1.json
closeout/final-diagnostic-inventory-v1.json

Use this root only as:

- authenticated source-crosswalk evidence;
- failed subject-authentication evidence;
- P18 causal evidence;
- historical nonqualifying reconciliation evidence.

Do not promote its aggregate verdict or unresolved package findings.

──────────────────────────────────────────────────────────────────────────────
4. FROZEN AUDIT-HARNESS SOURCE
──────────────────────────────────────────────────────────────────────────────

HARNESS_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-package-audit-harness-closure-repair-um86iu8y

Expected identity:

- device/inode:
  16777234 / 180607196
- mode:
  0700

Expected parent source:

source/audit_harness.py

- device:
  16777234
- inode:
  180607327
- mode:
  0600
- link count:
  1
- size:
  143624
- SHA-256:
  df73ad9f1ffe7c721abdb0e7ca9532b2955153341d29752b01369256244c45c6

Expected phase plan:

- inode:
  180610120
- size:
  15461
- SHA-256:
  596637bfc9ba88439d359eb2bf6ec2a8b6a6ec5f81475c7d6216d3f77ded674e

Authenticate the exact source and phase plan.

Use them to reconstruct P06 and P18. Do not infer those predicates from report
prose alone.

──────────────────────────────────────────────────────────────────────────────
5. FRESH DIAGNOSTIC ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask `077`, prefix:

ES-repair10i-v3-subject-provenance-p06-reconciliation-

Immediately emit:

RECONCILIATION_ROOT=<absolute-path>

Retain before supplied-root inspection:

opening/bootstrap-start.json

Bind:

- fresh-root identity;
- subject identity;
- full-audit identity;
- failed reconciliation identity;
- harness identity;
- read-only reconciliation authority;
- subject repair authorized:
  false;
- harness repair authorized:
  false;
- full-audit retry authorized:
  false;
- implementation work authorized:
  false;
- runtime validation rerun:
  false.

Create directories lazily.
Do not retain an empty directory.

──────────────────────────────────────────────────────────────────────────────
6. EXACT SUBJECT MANIFEST GRAMMAR
──────────────────────────────────────────────────────────────────────────────

Determine the subject manifest grammar from authenticated subject records.

Do not reuse a generic grammar from another package.

Retain:

analysis/subject-manifest-grammar-v1.json

Bind:

- manifest schema;
- top-level fields;
- entry-array pointer;
- path field;
- root represented:
  true/false;
- root-identity location and exact field set;
- exclusion location;
- exact A/B self-exclusions;
- type vocabulary;
- mode representation;
- directory fields;
- regular-file fields;
- link-count semantics;
- size semantics;
- hash semantics;
- ordering;
- canonical serialization;
- terminal metadata fields.

Unknown or ambiguous grammar must fail closed.

Do not add a `path` field to a root identity unless this exact grammar owns it.
Do not remove one when required.

──────────────────────────────────────────────────────────────────────────────
7. EXACT SUBJECT ROW-BY-ROW REPROJECTION
──────────────────────────────────────────────────────────────────────────────

Independently reproduce the subject manifest using two audit-owned
implementations:

A. no-follow `scandir` recursion;
B. an independently written `os.walk` or equivalent traversal.

Neither may import the subject’s generator.

Both must use the exact grammar from section 6.

Compare:

- supplied manifest A;
- supplied manifest B;
- fresh projection A;
- fresh projection B.

Retain:

validation/subject-manifest-row-reprojection-v1.json

Required outputs:

- supplied A/B byte equality;
- fresh A/B byte equality;
- expected entry count;
- observed entry count;
- expected path set;
- observed path set;
- missing paths;
- extra paths;
- duplicate paths;
- exact row differences.

For every differing path and field retain:

- relative path;
- object type;
- expected row;
- observed row;
- differing JSON pointer;
- expected value;
- observed value;
- whether the field is grammar-owned;
- whether the field is stable;
- source of observed value;
- first differing canonical byte offset, when bytes differ.

Do not stop at the first difference.

Classify the exact failure as one of:

SUBJECT_PACKAGE_TERMINAL_MANIFEST_DRIFT
SUBJECT_PACKAGE_POSTSEAL_MUTATION
SUBJECT_PACKAGE_UNSTABLE_MANIFEST_FIELD
DIAGNOSTIC_REPROJECTOR_GRAMMAR_DEFECT
DIAGNOSTIC_REPROJECTOR_IMPLEMENTATION_DEFECT
MIXED_PROVENANCE_DEFECT
NO_DIFFERENCE_REPRODUCED
EVIDENCE_INSUFFICIENT

If no difference is reproduced, identify the exact defect in the previous
reconciliation’s reprojector.

──────────────────────────────────────────────────────────────────────────────
8. SUBJECT PACKAGE CHRONOLOGY AND CURRENT CLOSURE
──────────────────────────────────────────────────────────────────────────────

Crosswalk:

- temporal inventory;
- terminal manifests;
- producer/finalizer record;
- manifest mtimes and identities;
- current physical tree;
- any current file not represented due to self-exclusion;
- no-write-after-closure claim.

Retain:

analysis/subject-package-closure-chronology-v1.json

Determine:

- whether every current nonmanifest path is represented;
- whether A/B are the only physical self-exclusions;
- whether any path or field changed after seal;
- whether any current package record postdates terminal closure;
- whether the observed row difference proves actual package drift;
- whether the difference is purely diagnostic-tool-generated.

Do not infer an intermediate history that is not retained.

──────────────────────────────────────────────────────────────────────────────
9. EXACT CURRENT SCHEMA-ROLE REGISTRY
──────────────────────────────────────────────────────────────────────────────

Authenticate the exact current schema-role registry through the subject
manifest and its governing role registry.

Expected package path from prior package reports:

contract/generated-record-schema-role-registry-v1.json

Do not assume this path if the manifest/governing records bind another path.

Retain:

analysis/exact-current-schema-role-registry-v1.json

Require:

- exact registry path;
- schema;
- size/SHA-256;
- exact top-level field names;
- exact pointer containing schema-role rows;
- exactly fifteen schema roles;
- unique role IDs;
- unique current paths;
- unique `$id` values;
- one current schema per role;
- no documentary-validator roles mixed into this registry.

The expected schema-role set is:

1. child-process-record
2. cleanup-result
3. current-export-registry
4. executable-origin-registry
5. failure-outcome
6. metadata-coherence
7. normative-construction-parent
8. package-freeze
9. package-root-rebinding
10. phase-record
11. plan-identity-consumer-registry
12. pointer-resolution-result
13. qualification-result
14. temporal-inventory
15. terminal-manifest-metadata

Do not silently rename roles. Report exact retained role strings and their
mapping to the expected semantic set.

──────────────────────────────────────────────────────────────────────────────
10. EXACT GENERATED-RECORD-FAMILY REGISTRY
──────────────────────────────────────────────────────────────────────────────

Authenticate the exact generated-record-family authority through:

- the normative contract; and
- the package’s generated-record family field freeze.

Expected package path from prior reports:

analysis/generated-record-family-field-freeze-v1.json

Do not assume this path when another path is explicitly bound.

Retain:

analysis/exact-generated-record-family-registry-v1.json

Require:

- exact record path;
- schema;
- size/SHA-256;
- exact top-level field names;
- exact pointer containing family rows;
- exactly fourteen families;
- unique family IDs;
- no generic extraction from `required_fields`;
- no documentary-validator roles;
- no normative-contract schema counted as a generated record family.

The expected semantic family set is:

1. child process
2. cleanup result
3. current export registry
4. executable-origin registry
5. failure outcome
6. metadata coherence
7. package freeze
8. package-root rebinding
9. phase record
10. plan-identity consumer registry
11. pointer-resolution result
12. qualification result
13. temporal inventory
14. terminal-manifest metadata

Report exact retained family IDs and their mapping to this semantic set.

──────────────────────────────────────────────────────────────────────────────
11. SCHEMA-ROLE TO FAMILY MAPPING
──────────────────────────────────────────────────────────────────────────────

Retain:

analysis/schema-role-to-family-mapping-v1.json

For every one of the fifteen schema roles record:

- schema role;
- current schema path;
- generated-record family, when any;
- family source pointer;
- mapping status.

Require:

- fourteen one-to-one generated-family mappings;
- exactly one schema role with no generated-record family:
  normative-construction-parent;
- zero duplicate family mapping;
- zero unmapped generated family;
- zero unauthorized fifteenth generated family.

If another mapping is supported by the normative contract, retain the exact
authority and do not force the expected result.

──────────────────────────────────────────────────────────────────────────────
12. EXACT P06 INPUT BINDING
──────────────────────────────────────────────────────────────────────────────

Using the frozen audit source and retained P06 phase record, determine exactly
what object was assigned to the source variable historically named
`role_registry`.

Retain:

analysis/p06-input-binding-v1.json

Bind:

- loader function;
- source expression;
- exact input path;
- exact input identity;
- exact schema;
- exact pointer expected by the source;
- exact top-level keys actually present;
- value returned by:
  `role_registry.get("roles")`;
- value returned by:
  `role_registry.get("schemas")`;
- fallback value;
- resulting operand type and count.

Answer:

1. Was the correct schema-role registry file loaded?
2. Was the correct file loaded but the wrong pointer vocabulary used?
3. Was a combined current-role occupancy record loaded?
4. Was a generated-family record loaded?
5. Was another record loaded?
6. Why did the historical expression consume `[]`?
7. Why did the failed reconciliation later observe a 25-entry combined list?
8. Are those observations from different records?
9. Which record, if any, is authoritative for P06?

Do not use the variable name as authority.

──────────────────────────────────────────────────────────────────────────────
13. P06 PHASE SEMANTICS
──────────────────────────────────────────────────────────────────────────────

Authenticate the frozen P06 phase-plan entry.

Retain:

analysis/p06-phase-semantics-v1.json

Bind:

- phase ID;
- phase title;
- prerequisites;
- operands;
- required outputs;
- pass rule;
- failure rule;
- authority contribution;
- cleanup obligations.

Determine whether P06 is normatively intended to verify:

- exactly fourteen generated-record families;
- exactly fifteen current schema roles;
- both as separate predicates;
- registry-local `pass`;
- or another exact requirement.

Do not infer intent solely from:

- `fifteen_current_families`;
- the phase title;
- a report description.

Use the frozen phase plan and normative contract.

──────────────────────────────────────────────────────────────────────────────
14. FRESH P06 BASELINE EVALUATION
──────────────────────────────────────────────────────────────────────────────

Evaluate the exact subject package under the correct authoritative records.

Retain:

validation/fresh-p06-baseline-evaluation-v1.json

At minimum compute separately:

- current schema-role count;
- schema-role uniqueness;
- current schema-role closure;
- generated-record-family count;
- family uniqueness;
- family closure;
- family-to-schema mapping;
- package family-registry local pass;
- package schema-role-registry local pass.

Then evaluate:

A. Historical source predicate unchanged.

B. Correct phase-plan predicate.

C. Independent audit-owned predicate.

Retain exact expected and observed values.

Do not write to the subject package.

──────────────────────────────────────────────────────────────────────────────
15. P06 MUTATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Retain:

validation/p06-authoritative-domain-matrix-v1.json

Cover at minimum:

1. Exact fifteen schema roles and fourteen families.
2. Schema-role registry absent.
3. Family registry absent.
4. Wrong record loaded as schema registry.
5. Wrong record loaded as family registry.
6. Correct record with unexpected top-level key.
7. Fallback empty list.
8. Combined 25-role occupancy list used as schema roles.
9. `required_fields` list used as families.
10. Fourteen families with normative schema excluded.
11. Fifteen families with normative schema incorrectly included.
12. One family missing.
13. One family duplicated.
14. One schema role missing.
15. One schema role duplicated.
16. Local registry pass false.
17. Local pass true but row closure false.
18. Count value Boolean.
19. Count value string.
20. Exact subject baseline under historical source.
21. Exact subject baseline under corrected domain.
22. Subject manifest provenance valid.
23. Subject manifest provenance invalid.

Require:

- unique literal names;
- complete expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip.

──────────────────────────────────────────────────────────────────────────────
16. P18 REAUTHENTICATION
──────────────────────────────────────────────────────────────────────────────

Reauthenticate, without broad reanalysis:

- `owned_transient_root_count=0`;
- created root set empty;
- inventoried root set empty;
- cleanup-row set empty;
- twice-absent root set empty;
- set equality true;
- process survivors zero;
- descriptor survivors zero;
- cache survivors zero;
- preseal cleanup complete true.

Retain:

analysis/p18-reauthentication-v1.json

Crosswalk the exact frozen source expression that converted integer `0` into
phase failure.

Require a small literal matrix covering:

- successful zero-root cleanup;
- one correctly cleaned root;
- omitted root;
- root survivor;
- process survivor;
- descriptor survivor;
- zero used as Boolean;
- zero checked as `== 0`.

This task may classify P18 independently of the subject manifest result.

──────────────────────────────────────────────────────────────────────────────
17. FINDING AND AUTHORITY CLASSIFICATION
──────────────────────────────────────────────────────────────────────────────

Classify the subject-manifest issue and P06 separately.

Subject manifest:

PACKAGE_PROVENANCE_DEFECT
DIAGNOSTIC_REPROJECTOR_DEFECT
MIXED_PROVENANCE_DEFECT
NO_DEFECT_REPRODUCED
EVIDENCE_INSUFFICIENT

P06:

PACKAGE_CONTRACT_OR_SCHEMA_DEFECT
PACKAGE_ACCEPTANCE_EVIDENCE_DEFECT
AUDIT_INPUT_BINDING_DEFECT
AUDIT_POINTER_VOCABULARY_DEFECT
AUDIT_COUNT_DOMAIN_DEFECT
AUDIT_ORACLE_DEFECT
MIXED_DEFECT
EVIDENCE_INSUFFICIENT

P18:

AUDIT_PASS_PREDICATE_DEFECT
AUDIT_RECORD_NORMALIZATION_DEFECT
PACKAGE_CLEANUP_DEFECT
MIXED_DEFECT
EVIDENCE_INSUFFICIENT

Retain:

analysis/final-finding-classifications-v1.json

For every finding bind:

- exact source;
- exact operands;
- expected semantics;
- observed semantics;
- package effect;
- audit effect;
- acceptance effect;
- repair owner.

──────────────────────────────────────────────────────────────────────────────
18. HISTORICAL BLOCK DEPENDENCY
──────────────────────────────────────────────────────────────────────────────

Retain:

analysis/historical-block-dependency-v2.json

Trace:

- subject provenance state;
- P06;
- P18;
- substantive issue rows;
- phase aggregation;
- P19;
- historical BLOCK;
- P20 terminal closure.

Determine counterfactually:

- verdict if P06 passes and P18 remains historically false;
- verdict if P18 passes and P06 remains historically false;
- verdict if both pass and no other issue exists;
- whether the authoritative historical BLOCK changes:
  it must not.

Do not produce a replacement verdict.

──────────────────────────────────────────────────────────────────────────────
19. REPAIR-SURFACE PROJECTION
──────────────────────────────────────────────────────────────────────────────

Do not implement repairs.

Retain:

analysis/minimal-next-tranche-v2.json

If the subject manifest is valid and P06/P18 are audit defects, define a
harness-only repair covering:

- exact P06 record path and pointer binding;
- separate schema-role and family-domain predicates;
- exact fourteen-family expectation;
- exact fifteen-schema-role expectation, when required;
- P18 zero-root cleanup predicate;
- P18 record/preseal consistency;
- focused matrices;
- fresh source freeze;
- fresh qualification;
- one fresh full audit against the unchanged subject package.

If a subject package provenance defect is confirmed, define:

1. a separate package-repair root and exact affected package files; then
2. a separate harness repair; then
3. a fresh full audit.

Do not combine package and harness authority.

Do not authorize construction-parent implementation.

──────────────────────────────────────────────────────────────────────────────
20. NO REPAIR OR RETRY
──────────────────────────────────────────────────────────────────────────────

Do not:

- repair the subject package;
- repair the audit harness;
- rerun the full audit;
- rewrite P06 or P18;
- normalize the historical BLOCK;
- execute subject package validators;
- execute `qualify-harness`;
- execute `run-full-audit`;
- create implementation source;
- execute process-self-test;
- execute construct mode;
- build a target-audit harness package;
- run a target audit.

This task ends with exact provenance and count-domain adjudication.

──────────────────────────────────────────────────────────────────────────────
21. SUPPLIED-ROOT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete lstat/no-follow inventories for every supplied root opened:

- subject package;
- full-audit capsule;
- failed reconciliation root;
- harness package.

Any other opened root also requires exact equality.

Do not modify or clean supplied roots.

For every diagnostic-owned fixture or cache root:

- retain complete pre-removal inventory;
- remove exact root;
- observe ENOENT twice;
- require zero process and descriptor survivors.

──────────────────────────────────────────────────────────────────────────────
22. DIAGNOSTIC CAPSULE CLOSURE
──────────────────────────────────────────────────────────────────────────────

Retain:

- bootstrap start;
- fixed-input authentication;
- subject manifest grammar;
- dual row reprojection;
- subject closure chronology;
- exact schema-role registry;
- exact family registry;
- schema/family mapping;
- P06 input binding;
- P06 phase semantics;
- P06 baseline evaluation;
- P06 matrix;
- P18 reauthentication;
- finding classifications;
- historical BLOCK dependency;
- repair-surface projection;
- supplied-root closing equality;
- final report;
- explicit confirmations;
- final diagnostic inventory.

Terminal manifests are optional.

If terminal manifests are created:

- use a stable, explicitly documented diagnostic grammar;
- use the final-namespace protocol;
- preserve exact fields;
- perform no write after closure.

──────────────────────────────────────────────────────────────────────────────
23. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

SUBJECT_SCHEMA_PROVENANCE_AND_P06_RECONCILED_AUDIT_DEFECT_ONLY

only when:

- the subject package manifests reproduce exactly under their own grammar, or
  the prior mismatch is proved to be diagnostic-tool-only;
- exact fifteen-schema-role closure passes;
- exact fourteen-family closure passes;
- P06 failed because of wrong record binding, wrong pointer vocabulary, wrong
  count domain, or fallback behavior;
- P18 is independently confirmed as an audit defect;
- no subject-package defect remains.

Return:

SUBJECT_SCHEMA_PROVENANCE_AND_P06_RECONCILED_PACKAGE_DEFECT_CONFIRMED

only when:

- the subject terminal manifests or physical closure are genuinely stale or
  invalid; or
- P06 correctly identifies a package omission or ambiguity without an audit
  defect explaining it.

Return:

SUBJECT_SCHEMA_PROVENANCE_AND_P06_RECONCILED_MIXED_REPAIR_REQUIRED

when subject-package and audit defects independently exist.

Return:

SUBJECT_SCHEMA_PROVENANCE_AND_P06_RECONCILIATION_BLOCKED

when exact manifest grammar, row divergence, schema-role authority, or family
authority cannot be established.

Return:

RECONCILIATION_PROVENANCE_MISMATCH

for:

- supplied-root mutation;
- opening/closing inequality;
- fixed source or manifest identity mismatch;
- unaccounted process or filesystem effect;
- cleanup inequality;
- diagnostic-capsule closure failure when terminal closure is attempted.

──────────────────────────────────────────────────────────────────────────────
24. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh diagnostic-root identity
3. Subject-package identity and closure
4. Historical full-audit identity and closure
5. Failed reconciliation identity and closure
6. Frozen harness identity and closure
7. Exact subject-manifest grammar
8. Supplied A/B identities and byte equality
9. Fresh independent projection A identity
10. Fresh independent projection B identity
11. Expected/observed path sets
12. Complete row-difference ledger
13. First differing path and field
14. Subject closure chronology
15. Subject-manifest issue classification
16. Exact schema-role-registry identity
17. Exact fifteen schema-role set
18. Exact family-registry identity
19. Exact fourteen generated-record-family set
20. Schema-role-to-family mapping
21. P06 exact input binding
22. P06 source predicate
23. P06 frozen phase semantics
24. Historical P06 operand and result
25. Correct baseline P06 operands and result
26. P06 authoritative-domain matrix
27. P06 classification
28. P18 reauthentication
29. P18 source predicate
30. P18 classification
31. Historical BLOCK dependency
32. Overall repair classification
33. Exact minimal next tranche
34. Supplied-root closing equality
35. Fixture/cache cleanup
36. Remaining uncertainty and nonclaims
37. Explicit confirmations

Required confirmations:

SUBJECT_SCHEMA_PACKAGE_MUTATION_NOT_PERFORMED
AUTHORITATIVE_FULL_AUDIT_ROOT_MUTATION_NOT_PERFORMED
FAILED_P06_P18_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
FROZEN_HARNESS_PACKAGE_MUTATION_NOT_PERFORMED
SUBJECT_MANIFEST_GRAMMAR_AUTHENTICATED
SUBJECT_MANIFEST_A_AUTHENTICATED
SUBJECT_MANIFEST_B_AUTHENTICATED
SUBJECT_MANIFESTS_BYTE_IDENTICAL
SUBJECT_MANIFEST_REPROJECTOR_A_COMPLETED
SUBJECT_MANIFEST_REPROJECTOR_B_COMPLETED
SUBJECT_MANIFEST_ROW_DIFFERENCES_EXHAUSTIVE
SUBJECT_MANIFEST_PROVENANCE_ADJUDICATED
EXACT_SCHEMA_ROLE_REGISTRY_AUTHENTICATED
EXACT_FIFTEEN_SCHEMA_ROLES_RETAINED
EXACT_GENERATED_FAMILY_REGISTRY_AUTHENTICATED
EXACT_FOURTEEN_GENERATED_RECORD_FAMILIES_RETAINED
SCHEMA_ROLE_TO_FAMILY_MAPPING_COMPLETE
NORMATIVE_CONSTRUCTION_PARENT_NOT_COUNTED_AS_GENERATED_FAMILY
P06_INPUT_RECORD_IDENTIFIED
P06_INPUT_POINTER_IDENTIFIED
P06_FALLBACK_CAUSE_IDENTIFIED
P06_PHASE_SEMANTICS_ADJUDICATED
P06_BASELINE_FRESHLY_EVALUATED
P06_AUTHORITATIVE_DOMAIN_MATRIX_PASSED
P06_CLASSIFICATION_COMPLETE
P18_ZERO_ROOT_STATE_REAUTHENTICATED
P18_SOURCE_PREDICATE_REAUTHENTICATED
P18_CLASSIFICATION_COMPLETE
HISTORICAL_BLOCK_VERDICT_PRESERVED
HISTORICAL_BLOCK_DEPENDENCY_CROSSWALKED
PACKAGE_AND_AUDIT_FINDINGS_SEPARATED
NO_PACKAGE_REPAIR_PERFORMED
NO_HARNESS_REPAIR_PERFORMED
NO_FULL_AUDIT_RETRY_PERFORMED
NO_IMPLEMENTATION_CREATED
PROCESS_SELF_TEST_NOT_EXECUTED
CONSTRUCT_MODE_NOT_EXECUTED
NO_HARNESS_PACKAGE_CONSTRUCTED
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

Do not begin construction-parent implementation after this reconciliation.

If the verdict is:

SUBJECT_SCHEMA_PROVENANCE_AND_P06_RECONCILED_AUDIT_DEFECT_ONLY

the next tranche may repair only the P06 and P18 harness predicates in a fresh
harness root, requalify and freeze the harness, and then run one new full audit
against the unchanged subject package.
```

## Decision

The latest reconciliation is nonqualifying, but it materially strengthens the audit-defect hypothesis:

- P18 is effectively proven audit-side.
- P06 used an empty fallback rather than an authenticated family or schema-role domain.
- The remaining blocker is the unexplained equal-count subject-manifest row mismatch.

Resolve that exact row mismatch and bind the authoritative P06 records before authorizing any repair.

**Source:** Codex’s latest `RECONCILIATION_PROVENANCE_MISMATCH` report, the terminally sealed historical `BLOCK` audit, and the frozen harness report supplied in this conversation.  
**Confidence:** 0.995 that P18 is an audit pass-predicate defect; 0.95 that P06 is an audit input-binding or count-domain defect; 0.65 that the subject-manifest mismatch is another diagnostic reprojector defect rather than actual package drift.
