Do **not** treat this as an implementation finding, and do not launch another audit yet.

`AUDIT_PROVENANCE_MISMATCH` means the attempt failed before it could issue a correctness judgment. That is the correct stop behavior, but the one-line response is not enough to determine whether the cause was:

- a genuine target/input identity mismatch;
- another startup or working-directory violation;
- a pre-existing audit-root collision;
- missing process records;
- or some other audit-evidence failure.

The prior retained reconciliation already showed why this distinction matters: the intended candidate paths and hashes were internally consistent, but missing auditor reports, command ledgers, and fourth-auditor completion evidence made process compliance unprovable.  The audit protocol requires provenance to be reproduced before correctness inspection and requires an immediate stop on any mismatch. 

Send this **in the same Codex chat**:

```text
Provide the complete closeout for the AUDIT_PROVENANCE_MISMATCH you just
returned.

Do not continue the audit, rerun the opening gate, inspect correctness, start
auditors, repair anything, or create a replacement attempt. Use only the
retained evidence from this failed attempt and the conversation/tool transcript.
Do not reconstruct missing process evidence. When a value is unavailable, write
UNRECOVERABLE FROM RETAINED EVIDENCE.

Return a complete inline report with these sections:

1. Verdict

   AUDIT_PROVENANCE_MISMATCH

2. Exact first failing gate

   State:
   - the gate name;
   - whether the failure is a process-boundary, repository-identity,
     supplied-input, audit-root, recipe, manifest, inventory, or retained-record
     mismatch;
   - the first operation at which the mismatch became determinative;
   - whether any earlier gate had qualified.

3. Exact expected versus observed values

   For the first mismatch, report:
   - expected path/value;
   - observed path/value;
   - type;
   - device/inode where retained;
   - mode;
   - link count;
   - size;
   - SHA-256 where applicable;
   - cwd;
   - explicit environment;
   - umask;
   - whether the value was contemporaneously recorded or merely reported by
     the tool transcript.

4. Causal explanation

   Explain why this is AUDIT_PROVENANCE_MISMATCH rather than BLOCK or REJECT.

   Do not infer a target defect merely from an audit-process failure.

5. Complete process account

   Enumerate every process invocation made from the beginning of the audit
   attempt through the stop, including administrative reads after the stop.

   For each process report:
   - ordinal;
   - complete argv, or UNRECOVERABLE;
   - cwd;
   - explicit environment, or UNRECOVERABLE;
   - effective umask, or UNRECOVERABLE;
   - exit or signal;
   - stdout byte count and SHA-256, or UNRECOVERABLE;
   - stderr byte count and SHA-256, or UNRECOVERABLE;
   - paths read;
   - paths written;
   - whether a contemporaneous start record exists;
   - whether a contemporaneous outcome record exists;
   - whether it is audit evidence, administrative prompt intake, or post-stop
     closeout activity.

6. Prompt-intake and first-process adjudication

   State:
   - whether the entire prompt was read through EOF before audit epoch;
   - how that was established;
   - the first post-epoch process;
   - its exact cwd;
   - whether the required controlled environment and umask were explicitly
     applied;
   - whether the fresh audit root and bootstrap record existed before any
     target inspection.

7. Audit-created paths

   Enumerate every path created by the attempt, including partial audit roots,
   bootstrap records, temporary files, stream captures, ledgers, or reports.

   For each, report:
   - type;
   - mode;
   - link count;
   - size;
   - SHA-256 when regular;
   - whether retained, removed, or absent;
   - whether it is complete, partial, or invalid evidence.

8. Mutation and contamination adjudication

   State separately whether the attempt performed or may have performed:
   - repository-content mutation;
   - Git-index or Git-administration mutation;
   - supplied-evidence mutation;
   - audit-root mutation;
   - cache, bytecode, or temporary-artifact creation;
   - cleanup;
   - chmod or normalization.

   If unchanged closing equality was not independently observed, say so.
   Do not convert “no mutation command was intended” into certified equality.

9. Audit progression at stop

   State:
   - whether correctness inspection began;
   - whether any auditor was started;
   - auditor identities and statuses, if any;
   - whether any causal, test, compatibility run, or supplied-root inspection
     occurred;
   - whether closing provenance occurred.

10. Salvageability

   Return exactly one:

   COMPLETE_MISMATCH_EVIDENCE_RETAINED
   PARTIAL_MISMATCH_EVIDENCE_RETAINED
   MISMATCH_EVIDENCE_NOT_RETAINED

   Explain what can and cannot be proven from retained evidence.

11. Required next action

   Choose one and justify it:

   - discard attempt and run a wholly fresh audit;
   - reconcile a named target/input identity before another audit;
   - restore a named audit-created artifact before another audit;
   - obtain a missing exact audit input before another audit.

   Do not recommend an implementation repair unless the retained mismatch
   actually establishes a target defect.

12. Explicit confirmations

   Include truthful values for:

   REPOSITORY_MUTATION_NOT_PERFORMED
   SUPPLIED_EVIDENCE_MUTATION_NOT_PERFORMED
   CORRECTION_CAPSULE_MUTATION_NOT_PERFORMED
   BLOCKING_AUDIT_MUTATION_NOT_PERFORMED
   CORRECTNESS_INSPECTION_NOT_PERFORMED
   AUDITORS_NOT_STARTED
   TESTS_NOT_RUN
   FORMATTING_NOT_PERFORMED
   REPAIR_NOT_PERFORMED
   STAGING_NOT_PERFORMED
   COMMIT_NOT_PERFORMED
   PUSH_NOT_PERFORMED
   A6_NOT_STARTED
   NETWORK_CONTACT_NOT_PERFORMED
   NESTED_SUBAGENTS_CREATED

Do not perform additional substantive target inspection to complete this
report. Preserve unknowns rather than reconstructing them.
```

The next decision depends entirely on that closeout. A wrong initial cwd or missing bootstrap record means discard-and-restart; an actual candidate, correction-capsule, or manifest mismatch must instead be reconciled before another audit. The protocol explicitly classifies provenance mismatch as a stop-before-judgment condition. 

**Sources:** retained audit reconciliation and project audit protocol.  
**Confidence:** 0.99 that the current one-line verdict is insufficient for triage; 0.97 that requesting a non-mutating closeout in the same Codex chat is the correct immediate action.
