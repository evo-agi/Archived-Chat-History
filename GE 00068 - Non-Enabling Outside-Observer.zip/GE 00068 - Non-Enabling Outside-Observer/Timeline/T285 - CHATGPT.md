## Assessment

`AUDIT_PROVENANCE_MISMATCH` is the correct verdict. The failure occurred before any target or supplied evidence was inspected, so it says nothing about the V3 audit-repair capsule.

The cause is narrow and mechanical:

- `phase_runner.py` is deliberately retained as mode `0600`.
- A mode-`0600` Python source file is readable by its owner but is **not directly executable**.
- The carrier attempted to execute the wrapper path as the program, producing `EACCES`.
- The wrapper therefore never ran and could not create its phase-start or phase-outcome records.

This is not a defect in the wrapper capability already proved, nor a reason to alter the wrapper’s mode. The wrapper must remain `0600` and be launched through the pinned Python interpreter.

No V3 capsule repair, process-capability probe, runtime replay, or repository change is needed. Discard this audit attempt and perform a wholly fresh audit using interpreter-mediated wrapper invocation.

Send the following as a continuation in the same Codex chat that received the full audit brief. When starting a new Codex chat, prepend the complete full-audit prompt from the prior turn.

```text
FRESH RETRY — PROCESS-LAUNCH CORRECTION FOR THE
VALIDATION-CUSTODY V3 AUDIT-REPAIR INDEPENDENT AUDIT

Repeat the immediately preceding full independent-audit brief from the
beginning, using a new audit root.

The target, supplied inputs, acceptance criteria, four-auditor assignments,
static correctness requirements, mutation matrix, manifest causals, closing
requirements, verdict rules, and required inline report remain unchanged.

The only authorized change is the exact wrapper-launch contract below.

Do not reuse, resume, clean, or mutate the failed audit root:

/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-audit-repair-independent-audit-k10ilirb

Treat that root as immutable historical process-failure evidence.

Return exactly one primary verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. ROOT CAUSE AND REQUIRED TREATMENT
──────────────────────────────────────────────────────────────────────────────

The accepted generic wrapper is a private Python source artifact, not an
executable program.

Accepted wrapper source:

/Users/ds/Downloads/ES-repair10i-generic-phase-wrapper-probe-sj1gm5ns/provenance/phase_runner.py

Expected identity:

- size:
  15300 bytes
- SHA-256:
  6e911ca17dedc6c5838b8b880548761b9009bb18fc26f1e7b6934d274f040f56
- retained mode:
  0600
- regular:
  true
- single-link:
  true

Mode 0600 must be preserved.

Forbidden:

- executing `phase_runner.py` directly;
- using its path as the executable in argv[0];
- chmodding it executable;
- relying on a shebang;
- sourcing it in a shell;
- copying it to an executable-mode path;
- using a loader that attempts direct exec of the wrapper;
- changing its bytes or mode.

Every post-bootstrap wrapped carrier must invoke the wrapper through the pinned
Python interpreter.

──────────────────────────────────────────────────────────────────────────────
2. PINNED INTERPRETER
──────────────────────────────────────────────────────────────────────────────

Use exactly:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Expected identity:

- version:
  Python 3.13.4
- regular:
  true
- single-link:
  true
- size:
  119424 bytes
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b

Before the first wrapped carrier, the bootstrap must verify and retain this
interpreter identity.

Every wrapper invocation must use the exact interpreter-option prefix:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13 \
  -I -S -B \
  "$AUDIT_ROOT/provenance/phase_runner.py"

followed by the exact wrapper CLI arguments required by the accepted wrapper
source.

Use the exact argument names, ordering requirements, and encoding defined by
the retained wrapper and exercised by the successful generic-wrapper probe.
Do not invent a replacement CLI.

The submitted command may use the platform shell only to supply the explicit
environment and invoke this interpreter command. The wrapper itself must be
the Python script operand, never the executable operand.

──────────────────────────────────────────────────────────────────────────────
3. EXPLICIT WRAPPER ENVIRONMENT
──────────────────────────────────────────────────────────────────────────────

Every wrapped carrier must explicitly receive at least:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

Use audit-owned private values for any required:

HOME
TMPDIR

The carrier start record must bind the exact environment record and its
SHA-256.

The wrapper invocation must not depend on:

PYTHONPATH
user site packages
system site packages
the submitted cwd for imports
repository Python modules
an executable shebang

The `-I -S -B` invocation is mandatory.

──────────────────────────────────────────────────────────────────────────────
4. BOOTSTRAP RECORDS
──────────────────────────────────────────────────────────────────────────────

The bootstrap remains the sole permitted unwrapped local-process carrier.

It must:

1. allocate a wholly fresh audit root;
2. create the required private directory structure;
3. copy the accepted wrapper bytes to:

   provenance/phase_runner.py

4. preserve mode 0600;
5. verify the copied wrapper size and SHA-256;
6. verify the pinned interpreter;
7. retain:

   opening/bootstrap.json
   opening/python-interpreter-identity.json
   opening/phase-wrapper-identity.json
   opening/phase-wrapper-invocation-contract.json

The invocation-contract record must state:

- wrapper is Python source, not executable;
- direct execution is forbidden;
- mode 0600 is required;
- interpreter path and identity;
- exact interpreter flags `-I -S -B`;
- accepted wrapper CLI field map;
- submitted cwd policy;
- explicit environment-record policy.

The bootstrap must inspect no target or supplied evidence content.

──────────────────────────────────────────────────────────────────────────────
5. FIRST WRAPPED CARRIER — LAUNCH SELF-CHECK
──────────────────────────────────────────────────────────────────────────────

Carrier 0002 must be an audit-owned wrapper-launch self-check before any target
or supplied-root inspection.

Create one retained audit-owned no-op payload, mode 0600, that:

- imports only the Python standard library;
- writes one private mode-0600 result beneath the fresh audit root;
- reads no target or supplied root;
- creates no child process;
- returns success.

Invoke Carrier 0002 using the pinned interpreter-mediated wrapper command.

Require:

- wrapper phase-start record created and fsynced before payload read or
  compilation;
- wrapper phase-outcome record created and fsynced after success;
- wrapper source identity exact;
- interpreter identity exact;
- payload identity exact;
- payload compiled and executed;
- expected result created;
- no direct wrapper execution;
- no permission error;
- no bytecode;
- complete carrier index entry.

Stop immediately with AUDIT_PROVENANCE_MISMATCH if this self-check does not
qualify.

Do not attempt a second launch shape inside the same audit.

──────────────────────────────────────────────────────────────────────────────
6. CHILD-RECORDER SELF-CAUSALS
──────────────────────────────────────────────────────────────────────────────

After Carrier 0002 qualifies, the next wrapped carrier must create the child
recorder and execute the two child-recorder self-causals required by the
original full-audit brief:

- missing executable / ENOENT;
- `/usr/bin/true` / exit 0.

Every subsequent external child process must use that recorder.

Do not begin target inspection until both wrapper and child-recorder
self-causals pass.

──────────────────────────────────────────────────────────────────────────────
7. ALL LATER WRAPPED CARRIERS
──────────────────────────────────────────────────────────────────────────────

Every later local-process carrier must use the same:

- copied wrapper bytes;
- pinned interpreter;
- `-I -S -B` options;
- interpreter-mediated launch shape;
- explicit environment-record treatment.

No post-bootstrap local process may:

- execute the wrapper directly;
- invoke a payload directly;
- use an unwrapped diagnostic command;
- use a different wrapper copy;
- change the wrapper’s mode;
- change the wrapper’s bytes.

Direct auditor interactions remain separately indexed and are not local-process
carriers.

──────────────────────────────────────────────────────────────────────────────
8. CARRIER-INDEX ADDITIONS
──────────────────────────────────────────────────────────────────────────────

In addition to the stable carrier-index fields from the original audit brief,
each wrapped carrier entry must bind:

- interpreter path;
- interpreter size;
- interpreter SHA-256;
- interpreter flags:
  `["-I", "-S", "-B"]`;
- wrapper mode:
  `0600`;
- wrapper invocation disposition:
  `interpreter-mediated-python-source`;
- direct wrapper execution:
  false.

The platform transcript remains authoritative for top-level launch and
ordering.

Do not require unavailable opaque tool-internal command expansion.

──────────────────────────────────────────────────────────────────────────────
9. VERDICT TREATMENT
──────────────────────────────────────────────────────────────────────────────

The failed audit root and its permission-denied result are historical
process-failure evidence only.

They are not:

- V3 target evidence;
- a target blocker;
- a supplied-input mismatch;
- a reason to alter the wrapper;
- a reason to alter wrapper mode;
- a reason to alter V3 or Plan V4.

The fresh audit must independently perform the complete opening gate,
four-auditor review, correctness inspection, causals, closing equality, process
audit, cleanup, and final inventory required by the preceding full-audit brief.

Use the original verdict rules after the corrected wrapper self-check passes.

──────────────────────────────────────────────────────────────────────────────
10. REQUIRED ADDITIONAL INLINE REPORT ITEMS
──────────────────────────────────────────────────────────────────────────────

In the complete audit report, explicitly include:

- pinned interpreter identity;
- copied wrapper identity and mode;
- exact interpreter-mediated launch shape;
- Carrier 0002 wrapper-launch self-check;
- confirmation that no direct wrapper execution occurred;
- confirmation that no chmod or executable copy occurred;
- confirmation that every later carrier used the same invocation contract.

Add these required confirmations:

PINNED_PYTHON_IDENTITY_VERIFIED
WRAPPER_RETAINED_MODE_0600
WRAPPER_NOT_EXECUTED_DIRECTLY
WRAPPER_NOT_CHMODDED
WRAPPER_NOT_COPIED_AS_EXECUTABLE
WRAPPER_INVOKED_THROUGH_PINNED_PYTHON
WRAPPER_INVOKED_WITH_ISOLATION_FLAGS
WRAPPER_LAUNCH_SELF_CHECK_PASSED
ALL_WRAPPED_CARRIERS_USED_SAME_INTERPRETER_CONTRACT

Retain every confirmation and requirement from the preceding full-audit brief.

Do not otherwise narrow, simplify, or alter that brief.
```

This retry should go directly back to the full independent audit. No new V3 implementation or generic-wrapper repair is justified.

Some earlier uploaded project files have expired from this session. They were not needed to assess this process failure because the complete Codex report was inline. Re-upload them for any later byte-level inspection of those artifacts.

**Source:** Codex’s `AUDIT_PROVENANCE_MISMATCH` report immediately above.

**Confidence:** 0.999 that the failure is solely direct execution of a mode-`0600` Python source file; 0.998 that interpreter-mediated launch is the correct repair; 0.99 that no target or wrapper-byte change is warranted.
