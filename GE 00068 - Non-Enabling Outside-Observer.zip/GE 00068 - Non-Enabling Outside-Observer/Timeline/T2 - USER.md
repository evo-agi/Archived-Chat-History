Here is Codex's response:

The Repair 10G design is coherently frozen, and all four bounded explorers completed without nesting. No implementation, product tests, evidence mutation, snapshot, network access, or target-repository writes occurred. One explorer did, however, accidentally create an external `/tmp` scratch file; that protocol breach determines the final verdict.

### 1. Current contracts and invariants

Repair 10G is a refinement of the unaccepted T2A-P `Bounded slice rule`, correcting unintended Repair 10F drift. It is not a `Reopened redesign seam`.

- T1 remains a `Current invariant`.
- Legacy operator behavior remains a `Temporary compatibility edge`.
- T2A-I and T2B remain absent future work.
- Evidence remains non-authoritative.
- Public `prepare`/`check` grammar, result schema, blocker vocabulary, fixed paths, and package contents remain unchanged.
- `check` remains non-mutating; only `prepare` may mutate managed package state.
- The floor lock remains held through closing barriers and release.
- Published package bytes cannot be unlinked or replaced by late cleanup.
- Actual causes remain private; the first public blocker is stable; uncertainty suppresses hashes and finite success.

Final read-only verification matched:

- Branch: `codex/remote-alpha-external-tls-status-observation-v1`
- HEAD: `567bceced5df95ecfe787cc66038d463a854e12c`
- Sole parent: `05dde14d185b6e022dcc169ef1a658a97961850f`
- HEAD tree: `b7cab23732572c2aaea9d5f2f1593338e2e75338`
- Upstream: absent
- Candidate T: `624ece774f7cdc01a9abace85785c0418f66cdda`
- Inventory SHA-256: `65280783ea3149589912cf589caf6d52ba7a1eb45a324c1141544da526ab1763`
- Membership: 389 = 375 tracked + 14 nonignored untracked
- Staged/deleted/renamed/unmerged: `0/0/0/0`
- Expected tracked modifications: 21
- Index equals HEAD; index SHA-256: `012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31`
- Final porcelain-v2 status SHA-256: `5f88ce7f3b86f9af1b36fcd3e9c2611529bf29b6b28be9d259b7d6c8816424f1`
- All 389 modes, sizes, and SHA-256 values matched; logical bytes: 9,933,221.

### 2. Strategic decisions

| FindingsUnderlying causeFrozen correction |                                                                        |                                                                                           |
| ----------------------------------------- | ---------------------------------------------------------------------- | ----------------------------------------------------------------------------------------- |
| P2-001–P2-004, P2-007                     | Descriptor ownership is advisory and recoverable by raw FD             | One invocation-wide, structurally mandatory `OwnedDescriptor`/`OwnerToken` abstraction    |
| P2-005–P2-007                             | Closing paths short-circuit and construct errors opportunistically     | Total owner visitation plus one canonical causal accumulator and one final adjudication   |
| P3-001–P3-006                             | Qualification trusts producer captions and incomplete retained state   | Fresh raw observations, independently rederived qualification, recursive A/B disjointness |
| P4-001–P4-002                             | Audit host mutates its own Git namespace and allowed streams to escape | Detached venue where possible; otherwise a narrow self-recording-aware provenance gate    |

Repair 10G must not be implemented as thirteen local patches or another validation framework.

### 3. Exact custody API and state machine

The abstraction stays unexported in [package.go (line 1150)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/es/externaltls/internal/statuspackage/package.go:1150>):
```
type descriptorOwnerIDV5 uint8
type descriptorGenerationV5 uint64

type ownerTokenV5 struct {
    registryID uint64
    owner      descriptorOwnerIDV5
    generation descriptorGenerationV5
}

type ownedDescriptorV5 struct {
    registry *descriptorCustodyRegistryV5
    token    ownerTokenV5
}

type descriptorDispositionV5 struct {
    Token          ownerTokenV5
    Kind           descriptorTerminalKindV5
    CloseAttempted bool
    Cause          error
}
```

State transitions are:
```
reserved
  ├─ opener failure ───────────────────────────────> terminal/open-failed
  └─ successful enrollment ─> live-unidentified
                                  └─ attach identity ─> live-identified
                                         ├─ stale/reuse ─> terminal/stale-reuse
                                         └─ dispose ─> disposing
                                                        ├─ nil ─> terminal/closed
                                                        └─ error, including EINTR
                                                             ─> terminal/close-uncertain
```

Required operations:

- `Open`, `OpenAt`, `OpenFile`, and `Pipe` reserve a generation and enroll every successful descriptor before it escapes.
- `AttachOpeningIdentity` attaches stable `(device, inode, file type)` identity without changing owner or generation. Mutable size/mode checks remain owner-specific validations.
- `WithFD` or an equivalent revocable borrow supplies an FD only for nonclosing operations.
- `Transfer` moves ownership and invalidates the source alias.
- Adoption by `os.File` changes the registry-owned close driver without changing the token.
- `Dispose` accepts only the owned handle/token. It invalidates aliases and removes the active-FD mapping before the sole close.
- Repeated or concurrent disposition waits for and returns the same stored terminal disposition and exact cause; it never invokes close again.
- `EINTR` is terminal uncertainty and is never retried.
- A stale token or FD reuse records `stale-reuse`, performs no close, and cannot touch the newer generation.
- `Finalize` freezes acquisition, disposes omitted live owners in generation order while recording omission uncertainty, verifies every acquisition and alias, and caches its result.

`activeByFD` is only a collision guard, never an ownership lookup. Retrofit enrollment, raw-FD reverse lookup, caller-supplied close thunks, arbitrary owner strings, and per-helper production registries are removed.

Universal coverage includes:

- Current runtime, coordinate, hierarchy, census/recovery, stage, slot, leaf, evidence-writer, directory-view, and recursive-cleanup owners.
- Currently unregistered child-pipe ends; lexical-directory descriptors; Go-distribution ancestry; regular readers; Git readers/writers/directories; build-validation roots/leaves/directories; configuration parent/writer; and generic private writers.
- The current `exact-generation-directory` is role metadata on its original token, not a fabricated acquisition.
- Inherited FD 9 remains an explicitly borrowed, nondisposable lifetime authority.

A source/AST contract permits raw acquisition and close only inside the custody primitive and explicit test cleanup. It supplements, but never substitutes for, production-path causal tests.

### 4. Exact barrier/error model and ordering

A fixed invocation record replaces defer-order-dependent joins:
```
operational
hierarchies[] { barrier, namespaceCleanup, closes }
coordinate    { barrier, nonFloorCloses, unlock, floorClose }
stage
runtime
custody
emission
```

The canonical private order is:

1. Earlier operational causes.
2. Each hierarchy bracket in lifecycle order:
   - identity and durability observations root-to-leaf;
   - dependency-required namespace-cleanup causes in stable path order;
   - descriptor dispositions leaf-to-root.
3. Coordinate bracket:
   - identity start-to-floor;
   - for `prepare`, directory then parent sync for each suffix start-to-floor;
   - non-floor closes in reverse order;
   - floor unlock;
   - floor close.
4. Stage: `build-evidence.v2.json`, executable, then stage directory—identity followed by close for each.
5. Runtime cleanup in lexical DFS order, then runtime-root close, then runtime-parent close.
6. Final custody/accounting uncertainty in acquisition-generation order.
7. Result-emission failure last.

Each syscall cause is retained adjacent to its private coarse classification as `errors.Join(coarse, actual)`. The complete chain is joined once; map iteration and defer chronology cannot determine order.

After an operational failure, no new owner or unsafe namespace mutation begins. Safe observations, selected syncs on independently proven held owners, and disposition of every acquired owner continue.

For every `prepare`, existing-generation recovery uses `synchronize=true` after success, failure, partial acquisition, or validation failure. `check` remains identity-only and non-mutating. An owner whose identity cannot be proven is not synchronized by pathname; explicit sync uncertainty is recorded while other proven owners continue.

Public adjudication occurs exactly once:

- Preserve an operational blocker if present.
- Otherwise select the first coarse blocker in canonical order.
- Cleanup never replaces it.
- Any private uncertainty yields `blocked`, exit 2, and empty hashes.
- After publication, late failure may change only the result to blocked; it cannot mutate published identity or bytes.

The documented causal order wins over current physical defer order. Dependency-required cleanup may execute earlier physically, but its causes must be buffered into the canonical bucket.

### 5. Exact successor qualification model

The successor treats every `Qualified`, `ResourceDisposition`, binding digest, recomputation boolean, and equality caption as an untrusted claim.

- `suite-result` becomes a non-adjudicative index of immutable raw records.
- Raw records retain actual launch results; nullable observed process epochs; observer executable/argv/env/output/exit; descriptor acquisition, identity, transfer, close and post-close observations; stream EOF/write/sync/close results; worker joins; listener/rebind observations; cleanup syscalls; and parent-relative absence observations.
- Missing, defaulted, fabricated, duplicate, unparsable, or failed observations mean uncertainty—not absence.
- PID identity is `(PID, kernel birth identity, PPID, PGID, SID, observation epoch)`. A non-launched command has no PID fields.
- `DeriveControlQualification` reopens and identity-brackets raw records, then independently recomputes:
  - C and its object bytes;
  - C→T and T;
  - D and E through held reads to EOF;
  - logical source inventory and pure tree;
  - all 12 successor members;
  - executed compiler and `go version`;
  - GOROOT identity;
  - module inputs, offline module listing, cache inventory, and output build info;
  - preparation-tool identity;
  - actual command executable, argv, environment, cwd, streams, and terminal state.
- Expected spec values are policy inputs, never proof.
- After both controls are cleaned, perform two genuinely new post-clean observation epochs for roots, process epochs, sockets/listeners, and endpoint rebindability.
- `BytesEqual` is a factual byte result. `AcceptedEqual` additionally requires both freshly derived qualifications, recursive disjointness, bindings, cleanup, terminal state, and all late close/output/publication checks.
- Equal but nonqualifying controls therefore produce `BytesEqual=true`, `AcceptedEqual=false`.
- `qualified-equal` is assigned only after every late check succeeds. On any error, no accepted final record may remain published.

Physical-to-logical materialization is explicit: verify sealed regular single-link 0400/0600 input against its logical inventory row; create an exclusive 0600 destination under umask 077; copy through held descriptors; `fchmod` to logical 0644/0755; sync, close, reopen no-follow, and reverify. Sealed evidence is never chmodded or built directly.

### 6. Exact A/B physical-disjointness model

Both mutable controls coexist through live inventory, recomputation, direct origin comparison, immutable capture, closing inventory, and pre-clean process/socket census.

Each side’s mutable-root union includes:

- Build/control parents and logical source.
- Git worktree metadata, gitdir, commondir, objects, alternates, and Git object environment.
- HOME/XDG, GOPATH, GOMODCACHE, GOCACHE, GOTMPDIR, TMPDIR, and tool caches.
- Runtime, command, profile, and reconciliation roots.
- PackageFloor, coordinate, generation, platform, and slot state.
- Origin artifacts, evidence, captures, and retained-output roots.

No-follow recursive inventory records physical paths, type, mode, device/inode, link count, size, and identity epoch. Acceptance requires:

- No physical equality or containment in either direction across opposite roots.
- No cross-control `(device,inode)` collision across any descendants.
- No same-side duplicate regular inode and regular `nlink == 1`.
- No symlink, special file, unreadable/raced subtree, Git alternate, cache, runtime, PackageFloor, artifact, or evidence alias.
- No common process epoch, ancestry/ownership crossover, survivor, shared socket inode/endpoint, undeclared listener, or rebind ambiguity.

Pinned sealed inputs, GOROOT, SDK, and executables may be shared only as declared immutable byte/identity-bound dependencies; they are not claimed to be disjoint mutable roots.

After immutable captures are closed and reverified, mutable controls are deleted. Only raw records, inventories, transcripts, mode mappings, captures, observations, derived qualifications, comparison records, and rebuilt binaries remain. Phase F remains historical/preliminary; every fresh audit must rerun A/B.

### 7. Exact audit-venue policy

Preferred venue: a detached/projectless Codex task over a no-hardlink extraction of the sealed ZIP, with no attachment to the shared project Git directory and every output under one exclusive source-external audit root.

Fallback acceptance requires both:

- `hard_capsule_equal`: exact opening/closing equality of source inventory/T, branch/HEAD/parent/tree/upstream/status, `.git` pointer, linked HEAD/commondir/gitdir, index bytes and decoded tree, config, packed refs, candidate ref, every nonvolatile ref, object-selection markers, and complete candidate/nonvolatile object closure.
- `volatile_delta_adjudicated`: every self-recording delta is enumerated and belongs only to:
  - exact `refs/codex/turn-diffs/**`;
  - matching reflogs;
  - objects reachable exclusively from that opening/closing ref delta, correctly framed to their OID, unpacked, and unreachable from candidate/index/nonvolatile refs;
  - Codex conversation metadata outside repository Git and source.

Never exclude all `refs/codex/**`, `.git/objects`, packs, `.git/cursor/**`, other worktrees, or generic project metadata.

Timestamps are report-only only when path, type, mode, owner, device/inode, links, size, and bytes remain exact.

Every child’s stdout, stderr, command intent, terminal record, temporary file, A/B root, and closeout stream must be rooted under the exclusive audit root from process launch. Any `/tmp` fallback or escaping stream stops the audit.

### 8. Exact repository touched-file set

Exactly ten existing repository files may change:

1. [PLANS.md (line 3751)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/PLANS.md:3751>)
2. [remote\_alpha\_external\_tls\_status\_deployment\_v1.md (line 1205)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/.docs/system_overview/remote_alpha_external_tls_status_deployment_v1.md:1205>)
3. [boundaries.md (line 1260)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/.docs/system_overview/boundaries.md:1260>)
4. [capability\_probing.md (line 581)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/.docs/system_overview/capability_probing.md:581>)
5. [artifact\_hygiene.md (line 507)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/.docs/system_overview/artifact_hygiene.md:507>)
6. [configuration.md (line 2043)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/.docs/system_overview/configuration.md:2043>)
7. [docs\_contract\_test.go (line 12278)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/docs_contract_test.go:12278>)
8. [package.go (line 1150)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/es/externaltls/internal/statuspackage/package.go:1150>)
9. [package\_test.go (line 8811)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/es/externaltls/internal/statuspackage/package_test.go:8811>)
10. [remote\_alpha\_prepare\_external\_tls\_status\_test.go (line 4161)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/remote_alpha_prepare_external_tls_status_test.go:4161>)

One explorer proposed nine files, omitting the root test. The freeze includes it because its current lifecycle/token guards bless the incomplete model. Any need for an eleventh repository file is a stop-and-re-freeze event.

### 9. Exact successor/evidence touched-file set

No existing evidence file is modified. During a separately authorized implementation, copy all 12 Phase F successor members without hardlinks into one new Phase G child, then modify only:

- `tool/source/FORMAT.md`
- `tool/source/cmd/repair10-compare/main.go`
- `tool/source/cmd/repair10-runner/main.go`
- `tool/source/cmd/repair10-semantic/main.go`
- `tool/source/envelope/envelope_test.go`
- `tool/source/envelope/runner.go`
- `tool/source/envelope/semantic.go`
- `tool/source/envelope/source.go`

Keep byte-identical:

- `tool/source/cmd/repair10-fixture/main.go`
- Both golden files under `tool/source/envelope/testdata/`
- `tool/source/go.mod`

Private validation records use new `execution-substrate.repair10g.<family>.v1` identifiers for:

`suite-spec`, `ab-suite-spec`, `command-intent`, `command-result`, `terminal-reconciliation`, `suite-result`, `control-observation`, `mutable-inventory`, `binding-recomputation`, `control-qualification`, `go-test-semantics`, `semantic-comparison-result`, `byte-capture`, `byte-comparison-spec`, and `byte-comparison-result`.

Source-inventory v1, evidence-manifest v1, and the unchanged effective-read-policy contract retain their existing IDs. Repair 10F qualification/comparison records cannot qualify as Repair 10G inputs.

This versions only source-external private evidence schemas. No product/public schema changes.

### 10. Exact docs-first implementation order

1. Reverify baseline and immutable lineage.
2. Allocate one exclusive Phase G evidence child and copy the 12 successor members without hardlinks.
3. Update `PLANS.md`.
4. Update the five authoritative `.docs/system_overview/` pages.
5. Update `docs_contract_test.go` and the root structural/source guard.
6. Add the production-path causal tests in `package_test.go`.
7. Update successor `FORMAT.md` and add successor causal/mutant tests.
8. Implement `package.go`.
9. Implement the remaining seven successor source changes.
10. Run focused validation, then count-three/race/full validation, then fresh A/B.
11. Generate the Phase G manifest as the child’s final mutation and verify it read-only.

Tests must express the intended contract before either product or successor implementation is considered complete.

### 11. Exact validation commands and required evidence

Every `go` invocation uses:

`/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go`

under an empty environment with `LANG=C`, `LC_ALL=C`, `GOENV=off`, `GOFLAGS=-mod=readonly -buildvcs=false`, `GOPROXY=off`, `GOSUMDB=off`, `GOVCS=*:off`, `GOTOOLCHAIN=local`, `GOWORK=off`, `GOTELEMETRY=off`, and exclusive HOME/XDG/GOPATH/GOMODCACHE/GOCACHE/GOTMPDIR/TMPDIR roots.

The product suite records these exact argv families:
```
go test -json -count=1 -p=1 -parallel=1 . \
  -run '^(TestRemoteAlphaExternalTLST2APRepair10Contract|TestRemoteAlphaT2APLifecycleOrderingTraceAndMutants)$'

go test -json -count=1 -p=1 -parallel=1 \
  ./es/externaltls/internal/statuspackage \
  -run '^(TestRepair10GProductionAcquisitionInventoryV5|TestRepair10GTerminalDispositionReplayEINTRAndFDReuseV5|TestRepair10GFinalAccountingAndTransferAliasesV5|TestRepair10GExistingGenerationRecoveryRunsTotalClosingSyncBarrierV5|TestRepair10GTotalHierarchyCoordinateAndSlotBarriersV5|TestRepair10GCombinedOperationalAndCleanupCausalityV5|TestRepair10GCustodyOmissionAndCanonicalOwnerOrderV5|TestRepair10GPostPublicationLateFailurePreservesIdentityV5)$'

go test -json -count=3 -p=1 -parallel=1 \
  ./es/externaltls/internal/statuspackage -run '^TestRepair10G'

go test -race -json -count=1 -p=1 -parallel=1 \
  ./es/externaltls/internal/statuspackage -run '^TestRepair10G'

go test -json -count=1 -p=1 -parallel=1 ./...
go test -race -json -count=1 -p=1 -parallel=1 ./...
go vet ./...
go mod verify
go build -trimpath -buildvcs=false ./...
```

Each restored successor A/B source runs:
```
go test -json -count=3 -p=1 -parallel=1 ./...

CGO_ENABLED=1 \
CC=/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang \
SDKROOT=/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX26.5.sdk \
go test -race -json -count=1 -p=1 -parallel=1 ./...

CGO_ENABLED=0 go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <side>/bin/repair10-runner ./cmd/repair10-runner
CGO_ENABLED=0 go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <side>/bin/repair10-compare ./cmd/repair10-compare
CGO_ENABLED=0 go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <side>/bin/repair10-semantic ./cmd/repair10-semantic
CGO_ENABLED=0 go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <side>/bin/repair10-fixture ./cmd/repair10-fixture
```

All four A/B binaries must be byte-equal. Each side’s runner executes its own Repair 10G suite, peer binaries rederive the other side’s retained transaction, and the closed A/B coordinator performs live observation, capture, cleanup, post-clean observation, derivation, comparison, and final publication.

Required evidence includes raw command intents/streams/terminal records; acquisition/disposition ledgers; ordered private-cause records; public blocker/hash results; publication identity; logical-mode restoration records; successor source/toolchain/module bindings; recursive A/B inventories; process/socket epochs; fresh cleanup observations; factual and accepted equality results; all mutants; rebuilt-binary digests; and the final manifest. Environment-dependent skips do not qualify.

### 12. Exact provenance, snapshot, and audit sequence

Immutable lineage anchors:

- Phase F manifest: `cf38650361ab8def4deea41726893ee0c8017406d4ef0d3ebcbd7473de6e9726`
- Phase F successor inventory/tree: `46d8be01642b2d94b4e4ab83c8843a692dfdb1a87bca2b26fa19d37b967de87a` / `5896a0693bdb9d669d5064fb18aabbb2b6140aa9`
- Recovery manifest: `d63f41db3435ef250da00f4ed6d398674e15d658ba5ec41de3b13e28e9834b0a`
- Recovered ZIP: `b6f3a3a207a997539050d11e89a26ff8bfeccce09d7b1d5df732088ea51e5fa0`
- Recovered handoff: `2b89ff15ba1322523f6a5e1c14770dba7d1c2dde23e903d3d1ff7604059fb824`
- Candidate inventory/T: `65280783ea3149589912cf589caf6d52ba7a1eb45a324c1141544da526ab1763` / `624ece774f7cdc01a9abace85785c0418f66cdda`

Future sequence:

1. Verify lineage and baseline.
2. Create one Phase G child.
3. Implement docs/tests/code under the frozen sets.
4. Rebuild and self-qualify twice.
5. Run bounded validation and fresh A/B.
6. Install the Phase G manifest last and verify read-only.
7. Create exactly one strategic ZIP/snapshot/handoff after sealing.
8. Run one independent audit in the preferred venue, always rerunning A/B.
9. Exact-byte commit only after audit success.

No development-time or audit-time snapshots. Phase F and recovery capture remain immutable.

### 13. Explicit non-goals

- No T1 change.
- No T2A-I or T2B work.
- No operator-production, installation, deployment, acceptance, restoration, or handback.
- No public API, CLI, product schema, configuration, path, blocker vocabulary, or module-graph change.
- No new Go source file, module, dependency, shared kernel, or general validation framework.
- No promotion of Phase F captions.
- No attempt to make evidence or the audit successor authoritative.
- No ES product workaround for Codex-managed refs.

### 14. Mandatory stop conditions

Stop and re-freeze on any:

- Baseline, lineage, hard-provenance, source membership, index, candidate ref, or object-closure drift.
- Unclassifiable Git/host delta or output outside the exclusive evidence/audit root.
- Raw descriptor acquisition/close outside custody; retrofit enrollment; FD-based ownership lookup; omitted acquisition; surviving alias; duplicate syscall; retried EINTR; or stale token touching a new owner.
- Dropped/reordered actual cause, skipped acquired owner, public blocker replacement, retained hashes under uncertainty, or post-publication mutation.
- Existing-generation `prepare` path that omits its selected sync barrier.
- Synthetic/post-hoc causal test, environment skip, or mutation that bypasses the production path.
- Missing/fabricated raw successor observation or use of a Repair 10F caption as proof.
- Recursive A/B alias, hardlink, Git alternate, cache/runtime/PackageFloor/process/socket collision, race, or incomplete inventory.
- Origin deletion before live comparison/capture; fewer than two fresh post-clean epochs; survivor or listener ambiguity.
- Equal bytes accepted with a nonqualifying control, or accepted output surviving a late fault.
- Unequal successor builds or failed self-host/cross-derivation.
- Mutation of Phase F/recovery evidence.
- Need for an eleventh repository file, ninth successor source file, fixture change, new dependency/framework, public schema change, or reopened seam.

### 15. Inspection limits and unresolved uncertainty

- All four explorers completed and are closed; none nested.
- This was static reconnaissance. No compile, test, dynamic trace, EINTR induction, capability probe, fresh A/B, or detached-venue availability check was performed.
- `/usr/sbin/lsof` is present, but its usable behavior and permissions must be behavior-probed. Failure blocks; there is no OS-name fallback.
- Identical A/B binaries are reproducibility evidence, not correctness proof.
- The eight-file successor set remains subject to compile-time confirmation. Any extra member is a stop, not silent widening.
- The brief’s “no schemas” scope line conflicts with its request to identify schemas requiring versioning and its objective of no *public* schema changes. The freeze interprets the prohibition as product/public schemas; changed private evidence meanings receive new Repair 10G IDs. If private versioning was also intended to be forbidden, implementation is blocked.
- The barrier review omitted the root integration test; the custody and contract reviews showed it blesses the incomplete model. The frozen ten-file set includes it.
- Current physical cleanup order differs from documented causal precedence. The freeze preserves documented precedence and buffers physically earlier dependency cleanup.
- One explorer accidentally created `/tmp/r10g-e2-rg.txt` outside the repository: 77,902 bytes, SHA-256 `a777ef684345b642904eb0ed135503dce436dffa28326a9295964978849deac0`. It was not deleted because deletion was prohibited. The candidate repository, Phase F, and recovery evidence remained exact, but this prevents certification of a completely compliant reconnaissance run.

REPAIR10G\_RECONNAISSANCE\_PARTIAL
