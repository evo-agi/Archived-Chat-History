## Assessment

The launcher tranche has reached the right stopping point. Codex reports `WRAPPED_CARRIER_LAUNCHER_READY` for a fresh immutable package at `/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38`. The accepted wrapper, pinned interpreter, and supplied historical roots all retained their expected identities. 

The report supports the intended narrow repair:

- The predecessor failure was reproduced as the single overstrong whole-environment equality predicate.
- The launcher, CLI contract, and request-contract semantics remained unchanged.
- The launch contract changed only through explicit physical-root rebinding.
- Carrier 0002 passed with the corrected environment oracle.
- Carrier 0003 retained a complete qualifying `SyntaxError`.
- Carrier 0004 recovered successfully.
- Both independent 30-case validators passed with no false acceptance.  

Process continuity is now established: same-PID execution passed, every carrier used the same fixed environment and complete wrapper argv, and Carriers 0001–0005 have contiguous requests, constructed-launch records, starts, and outcomes.  The qualification capsule also closed with byte-identical independent manifests, private modes, and no empty, linked, symlink, or special artifact. 

No further launcher implementation or launcher capability probe is warranted. The next step is the **fresh full V3 independent audit**, consuming this launcher package as an immutable process input. The audit must not regenerate the launcher or import the qualification payloads as target evidence.

Send the following as a continuation in the Codex chat that already has the complete V3 audit brief.

---

```text
FRESH FULL INDEPENDENT AUDIT —
VALIDATION-CUSTODY V3 AUDIT-REPAIR CAPSULE,
USING THE QUALIFIED WRAPPED-CARRIER LAUNCHER PACKAGE

Repeat the immediately preceding complete Validation-Custody V3 audit-repair
independent-audit brief from the beginning with a wholly fresh audit root.

All target roots, fixed target identities, four-auditor assignments,
correctness requirements, mutation requirements, manifest causals, closing
requirements, verdict rules, and required report items from that brief remain
in force unless explicitly replaced below.

The process mechanism is now frozen by the qualified launcher package. Do not
rebuild, redesign, patch, or requalify the launcher inside this audit.

Return exactly one primary verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. NEW IMMUTABLE PROCESS INPUT
──────────────────────────────────────────────────────────────────────────────

QUALIFIED_LAUNCHER_ROOT:

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38

Expected root identity:

- device/inode:
  16777234 / 179032804
- mode:
  0700
- disposition:
  immutable qualified source-external process package

Expected primary verdict:

WRAPPED_CARRIER_LAUNCHER_READY

Fixed launcher-package identities:

Accepted wrapper:

- size:
  15300
- SHA-256:
  6e911ca17dedc6c5838b8b880548761b9009bb18fc26f1e7b6934d274f040f56
- mode:
  0600
- regular:
  true
- links:
  1

Qualified launcher:

- size:
  16603
- SHA-256:
  12e4c0bd37581c7c9634133fd5cb0c30f9db4871f13f8f6825a1efed1f51fd9e

Phase-runner CLI contract:

- size:
  6937
- SHA-256:
  be46e39be6b72c2a49ca510807d6aa346a477fe13dad0911bc1965c389f1695f

Carrier-request contract:

- size:
  1606
- SHA-256:
  bdd167b775281418364b362270dbba366a2f4f4c6dc8257ce1a3e829834a3790

Qualification-root launch-contract instance:

- size:
  2260
- SHA-256:
  b9ac95c264d88d0a0cd76f17c7089b65229bed9c4eb65ea949ef4f745c5e57d1

Qualification manifest pair:

manifest/qualification-manifest-a-v1.json
manifest/qualification-manifest-b-v1.json

- size:
  12404 each
- SHA-256:
  a81be4da4d3c767e0e1c1b98db8e7ccf4403977e2b1ef66d21263adbcd1acebb
- required byte-identical

Expected manifest closure:

- 73 represented entries;
- root plus 8 retained subdirectories;
- 64 represented nonmanifest files;
- exactly two manifest self-exclusions;
- no empty directory;
- no symlink;
- no special object;
- no multiply linked file;
- directories mode 0700;
- files regular, single-link mode 0600.

The opening gate must independently enumerate and close this complete package.

Stop with AUDIT_PROVENANCE_MISMATCH on any launcher-package identity,
membership, mode, link, type, or manifest mismatch.

The launcher package is a process-capability input only. It has no authority
over V3 correctness, supplied-root identity, target findings, or the audit
verdict.

──────────────────────────────────────────────────────────────────────────────
2. PRIOR FAILED AUDITS
──────────────────────────────────────────────────────────────────────────────

All earlier failed launcher and full-audit roots remain immutable,
nonqualifying historical process evidence.

Do not:

- resume them;
- repair them;
- clean them;
- adopt their auditor reports;
- use partial correctness work from them;
- search for an earlier unreported root;
- use their launcher or payload bytes in preference to the qualified package.

The qualified launcher root above is the sole launcher-package input.

──────────────────────────────────────────────────────────────────────────────
3. FRESH AUDIT ROOT AND BOOTSTRAP
──────────────────────────────────────────────────────────────────────────────

Read this complete prompt before invoking a tool.

Then state exactly:

AUDIT_EPOCH_START

The first post-epoch local-process carrier is the sole bootstrap exception.

Allocate one fresh audit root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask 077, with the prefix required by the preceding full
V3 audit brief.

Before discretionary checks:

1. retain `opening/bootstrap-start.json`;
2. emit the exact audit-root path;
3. create the required audit directories;
4. verify the qualified launcher package;
5. verify pinned Python;
6. copy the fixed process-package artifacts into the audit root;
7. retain `opening/bootstrap-outcome.json`.

The bootstrap must inspect no V3 target or supplied target root until the
process package and bootstrap records qualify.

──────────────────────────────────────────────────────────────────────────────
4. PINNED INTERPRETER
──────────────────────────────────────────────────────────────────────────────

Use exactly:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Closed acceptance identity:

- version:
  Python 3.13.4
- regular:
  true
- links:
  1
- size:
  119424
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b

Interpreter flags:

["-I", "-S", "-B"]

Permission bits, uid/gid, device/inode, timestamps, flags, xattrs, and ancestor
posture remain report-only.

Do not reject mode 0775.
Do not chmod or normalize the interpreter.

──────────────────────────────────────────────────────────────────────────────
5. PROCESS-PACKAGE MATERIALIZATION
──────────────────────────────────────────────────────────────────────────────

Copy from the qualified launcher package into the fresh audit root:

- exact accepted wrapper source;
- exact qualified launcher source;
- exact phase-runner CLI contract;
- exact carrier-request contract;
- exact environment-observation policy;
- exact source-identity records required by the launcher.

Preserve every copied source byte exactly.
Preserve mode 0600.
Do not copy qualification payloads as audit payloads.
Do not copy qualification results as current audit results.
Do not copy the qualification closeout payload as an audit closeout payload.

The fresh audit owns its own phase payloads and results.

Verify every copied byte against the qualification package and its covering
manifests.

──────────────────────────────────────────────────────────────────────────────
6. FRESH ROOT-BOUND LAUNCH-CONTRACT INSTANCE
──────────────────────────────────────────────────────────────────────────────

The qualification-root launch contract contains physical paths and cannot be
used unchanged.

Create one fresh audit-root-bound launch-contract instance by changing only the
root-derived fields proven by the qualification package.

The only authorized changed pointer families are:

- `/qualification_root`
- `/wrapper/path`
- `/phase_runner_cli_contract/path`
- `/carrier_request_contract/path`
- `/fixed_environment/HOME`
- `/fixed_environment/TMPDIR`
- `/fixed_environment_record/path`
- `/fixed_environment_record/size`
- `/fixed_environment_record/sha256`
- `/launcher_identity_record/path`
- `/launcher_identity_record/size`
- `/launcher_identity_record/sha256`

Retain:

opening/launch-contract-root-rebinding-v1.json

For each changed pointer, record:

- predecessor value;
- successor value;
- classification:
  `physical-audit-root-rebinding-only`;
- semantic effect:
  none.

Normalize qualification-root and audit-root values to `${AUDIT_ROOT}` and
require normalized predecessor and successor launch contracts to be
byte-identical.

Any non-root-bound difference requires AUDIT_PROVENANCE_MISMATCH.

Do not alter:

- launcher semantics;
- CLI contract semantics;
- request-contract semantics;
- fixed PATH;
- interpreter flags;
- accepted wrapper digest;
- direct-execution prohibition;
- shell prohibition;
- fallback prohibition;
- same-PID requirement;
- environment-observation policy.

──────────────────────────────────────────────────────────────────────────────
7. FIXED WRAPPED-CARRIER INVOCATION
──────────────────────────────────────────────────────────────────────────────

Every post-bootstrap local-process carrier must invoke:

pinned Python
→ exact qualified launcher
→ same-PID execve
→ pinned Python
→ exact mode-0600 phase runner
→ audit-owned retained payload

Use no shell fallback.
Use no direct wrapper execution.
Use no direct payload execution.
Use no PATH lookup for interpreter or wrapper.
Use no alternate launcher source.
Use no changed launcher source.
Use no chmod.

Fixed environment must come only from the fresh launch-contract instance:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
HOME=<AUDIT_ROOT>/private/home
TMPDIR=<AUDIT_ROOT>/private/tmp

Additional post-exec environment keys are name-only diagnostics and do not
fail qualification when every contract-owned value remains exact.

Every constructed wrapper argv must include every required wrapper option,
including exactly one:

--expected-wrapper-sha256
6e911ca17dedc6c5838b8b880548761b9009bb18fc26f1e7b6934d274f040f56

Per-carrier requests must not repeat or override invariant launch fields.

──────────────────────────────────────────────────────────────────────────────
8. INITIAL PROCESS SELF-CHECK
──────────────────────────────────────────────────────────────────────────────

Carrier 0002 must be one audit-owned no-target self-check before supplied-root
inspection.

Use an audit-owned payload implementing the qualified environment-observation
policy:

- constructed environment must exactly equal launch-contract fixed
  environment;
- every contract-owned observed key must have the exact value;
- additional observed key names are diagnostics only;
- additional values are not retained;
- same-PID equality required;
- expected-wrapper SHA exactly once;
- complete CLI conformance required;
- no target inspection;
- no child process;
- result mode 0600.

Require complete request, constructed-launch, phase-start, phase-outcome, and
result records.

Do not rerun the complete launcher qualification.
Do not run the package’s SyntaxError or recovery payloads.
This self-check verifies only that the root-rebound process instance is usable.

Stop with AUDIT_PROVENANCE_MISMATCH on self-check failure.

──────────────────────────────────────────────────────────────────────────────
9. CHILD-RECORDER CAUSALS
──────────────────────────────────────────────────────────────────────────────

After Carrier 0002 passes, create the child recorder through a wrapped phase.

Before target inspection, require:

- missing executable / ENOENT causal;
- `/usr/bin/true` / exit-0 causal;
- complete stream records;
- process reaping;
- descriptor closure;
- contiguous child ordinals.

Every subsequent external child process must use the same recorder.

──────────────────────────────────────────────────────────────────────────────
10. CARRIER AND REQUEST AUTHORITY
──────────────────────────────────────────────────────────────────────────────

The qualified launcher package owns invariant launch semantics.

Each audit-owned request may contain only phase-varying fields allowed by the
qualified carrier-request contract.

Reject requests containing or overriding:

- interpreter path or identity;
- interpreter flags;
- wrapper path, size, digest, or mode;
- fixed environment;
- PATH;
- HOME;
- TMPDIR;
- shell or fallback disposition;
- same-PID disposition.

Every request must bind:

- the fresh launch-contract path, size, and SHA-256;
- payload path, size, and SHA-256;
- submitted cwd;
- exact expected outputs;
- authorized operands.

Every carrier must retain its constructed-launch record before exec.

──────────────────────────────────────────────────────────────────────────────
11. OPENING PROVENANCE GATE
──────────────────────────────────────────────────────────────────────────────

After process self-checks pass, perform the complete opening provenance gate
from the preceding full V3 audit brief.

It must independently verify at minimum:

- candidate repository;
- accepted Strategic B gate;
- Strategic B snapshot;
- blocked V1;
- Validation-Custody V2;
- V2 independent audit and verdict BLOCK;
- V3 predecessor;
- previous blocking V3 audit;
- failed V3 audit-repair attempt;
- exact V3 audit-repair capsule;
- qualified launcher package;
- five pinned source files;
- candidate locks and operation markers;
- complete process continuity.

Use the accepted Strategic B canonical projection:

- size:
  96657
- SHA-256:
  4c5556d5c74a5c9a8669e4ba9f2ec061d97fa6fa6e6276459439d9d376370360

Do not use either legacy ordering-dependent Strategic B inventory as an
acceptance gate.

Stop with AUDIT_PROVENANCE_MISMATCH on any opening mismatch.

──────────────────────────────────────────────────────────────────────────────
12. FOUR DIRECT AUDITORS
──────────────────────────────────────────────────────────────────────────────

After opening provenance passes:

- start Auditors 1–3 concurrently;
- start Auditor 4 only after the first of 1–3 completes;
- no retries unless the original full audit brief explicitly allows one;
- no nested agents.

Auditor 1 — normative authority and supersession

Audit:

- exact current V3 contract;
- exact current Plan V4;
- failed-attempt index;
- authoritative supersession;
- whole-root authority claims;
- predecessor historical references.

Auditor 2 — V2 adoption and correction lineage

Audit:

- all nine adoption rows;
- every raw V2 source;
- correction record;
- complete observation-lineage ledger;
- V2 report and verdict.

Auditor 3 — static semantics and contradiction resistance

Audit:

- V3 field map;
- Plan V3→V4 equivalence;
- five-source closure;
- 86-byte derivation;
- producer and independent validators;
- retained results.

Auditor 4 — provenance, manifests, inventory, scan, and security

Audit every V3 audit-repair capsule object and applicable supplied-root
boundary.

Auditors run no Git, tests, product code, runtime validation, network, writes,
or nested agents.

Retain exact prompts, operands, reports, start/completion ordering, and stated
limits.

──────────────────────────────────────────────────────────────────────────────
13. TARGET CORRECTNESS AUDIT
──────────────────────────────────────────────────────────────────────────────

Execute every target-correctness requirement from the preceding complete V3
audit brief unchanged, including:

A. Normative authority

Require exactly:

- one current standalone V3 normative contract;
- one current standalone Plan V4;
- one sole-writer claim;
- no copied historical failed-attempt contract or Plan;
- no other current normative writer;
- no historical artifact eligible for runtime or acceptance use.

B. Failed-attempt lineage

Authenticate every predecessor failed-attempt reference, identity, reason,
superseding record, and false authority flag.

C. V2 adoption

Independently adjudicate all nine rows.

For OBS-05:

- preserve raw `pass:false`;
- preserve raw `all_accepted:false`;
- authenticate the correction record;
- verify exact supporting correction fields;
- reject any raw-only pass claim.

For OBS-06:

- verify each isolation subrecord independently;
- preserve the false aggregate;
- limit adoption to isolation only.

For OBS-07:

- preserve raw cleanup `pass:false`;
- authenticate correction;
- verify bounded false-positive explanation;
- verify two ENOENT observations;
- verify empty post-run PID query;
- reject any broader cleanup claim.

Require V2 verdict `BLOCK` and `verdict_promoted:false`.

D. V3 semantics

Independently verify:

- complete typed field map;
- all false authority flags;
- all false unsupported-host and alias flags;
- allocator contract;
- child/environment layout;
- path budget;
- source authority separation.

E. Plan equivalence

Independently normalize and compare Plan V3 and Plan V4.

Require:

- exact eight-command set and order;
- exact argv;
- environment;
- expected identity policy;
- expected failure/skip policy;
- Strategic B identity;
- shared-r custody;
- zero semantic difference outside authorized metadata/reference changes.

F. Exact source closure

Verify all five pinned source identities and exact derivation:

59 + 1 + (2 + 10) + 1 + 13 = 86 <= 100

G. Independent mutation matrix

Construct a fresh audit-owned matrix without importing producer validator code
or producer fixtures as the case generator.

Exercise at least the complete required case set from the preceding full audit
brief, including authority, adoption, correction-lineage, parsing, plan,
source, manifest, inventory, scan, and historical-use cases.

Require:

- exact names;
- uniqueness;
- mechanism-specific reasons;
- zero false acceptance.

H. Manifest generators

Inspect both producer generators completely.

Run audit-owned causals for:

- stable tree;
- directory symlink;
- file symlink;
- special object;
- multiply linked file;
- empty directory;
- unsupported path encoding where safely constructible;
- stable output despite excluded volatile directory metadata.

Require both generators to reject every prohibited fixture and agree on the
stable fixture.

I. Real capsule closure

Independently enumerate the V3 audit-repair capsule and require exact equality
with both supplied manifests.

J. Final inventory chronology

Verify the exact three exclusions and absence of unstable directory metadata.
Verify the manifests cover the final inventory.

K. Terminal sensitive-material audit

Independently scan the complete terminal capsule, including final report,
inventory, scan record, manifests, validators, lineage, and adoption records.

Do not emit matched payload content.
Any plausible live secret blocks acceptance.

──────────────────────────────────────────────────────────────────────────────
14. NO RUNTIME REPLAY
──────────────────────────────────────────────────────────────────────────────

Do not execute:

- Plan V3;
- Plan V4;
- repository tests;
- product code;
- V2 allocator;
- V2 causal harness;
- live service;
- live route.

Allowed executable work remains limited to audit-owned:

- parsers;
- hashers;
- inventory builders;
- static analyzers;
- plan comparators;
- mutation validators;
- manifest-fixture causals;
- scanners;
- cleanup tools;
- candidate Git reads.

──────────────────────────────────────────────────────────────────────────────
15. PLATFORM-CARRIER INDEX
──────────────────────────────────────────────────────────────────────────────

Index every local-process carrier using only stable, available facts:

- ordinal;
- phase;
- launcher identity;
- qualification-package identity;
- launch-contract identity;
- request identity;
- payload identity;
- interpreter identity and flags;
- wrapper identity and mode;
- fixed-environment identity;
- submitted cwd;
- platform-reported outcome class;
- phase-start identity;
- phase-outcome identity;
- child ordinal range;
- artifacts;
- discrepancy status.

State:

`carrier_launch_authority = "codex-platform-tool-transcript"`

and:

`audit_root_does_not_self_attest_parent_process_creation = true`

Do not require unavailable opaque tool-internal command serialization.

Direct auditor interactions belong in a separate interaction index.

Return AUDIT_PROVENANCE_MISMATCH on an actual missing or conflicting carrier,
request, phase record, child quartet, cwd, environment, ordering, or supplied
root—not on unavailable internal formatting.

──────────────────────────────────────────────────────────────────────────────
16. CLOSING EQUALITY AND CLEANUP
──────────────────────────────────────────────────────────────────────────────

After all auditors and parent correctness work:

- repeat candidate Git identity and status;
- repeat complete inventories for all supplied roots;
- include the qualified launcher package in opening/closing equality;
- verify the five pinned source files unchanged;
- verify all carriers and child records complete;
- verify no child, process, or descriptor survivor;
- remove only the audit-owned `private/` path;
- make two fresh `lstat` observations on that exact path;
- require ENOENT twice.

Do not mutate or clean the launcher qualification package.

──────────────────────────────────────────────────────────────────────────────
17. FINAL AUDIT INVENTORY
──────────────────────────────────────────────────────────────────────────────

Use one final wrapped carrier.

Before return, its payload must verify:

- all earlier carrier records;
- all child quartets;
- all direct-auditor records;
- all expected audit artifacts;
- supplied-root closing equality;
- cleanup;
- process/descriptor absence.

It must create:

closeout/final-audit-root-inventory.json

Exactly two temporal self-exclusions are permitted:

1. itself;
2. its wrapper-created phase-outcome record.

After the payload returns, the wrapper writes the final outcome.

No later filesystem-writing carrier is permitted.

The inline report must bind the final outcome’s terminal size and SHA-256.

Do not use a background thread or copied qualification closeout mechanism to
change this temporal model.

──────────────────────────────────────────────────────────────────────────────
18. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return ACCEPT only if:

- process package and root rebinding qualify;
- opening and closing provenance qualify;
- every fixed target identity matches;
- exactly one current contract and Plan exist;
- failed-attempt authority is fully demoted;
- every V2 adopted fact is supported;
- V2 remains BLOCK;
- V3 and Plan semantics remain unchanged;
- source and path derivations pass;
- independent mutation matrix passes;
- manifest-generator source review and causals pass;
- real capsule closure passes;
- inventory chronology is truthful;
- terminal sensitive-material scan passes;
- four auditors complete;
- process and artifact continuity pass;
- no acceptance-affecting residual finding remains.

Return BLOCK for a repairable target-level authority, adoption, contract,
lineage, manifest, inventory, scan, validation, or artifact defect.

Return REJECT only for fundamental unsoundness outside the bounded repair
scope.

Return AUDIT_PROVENANCE_MISMATCH for process-record failure, input drift,
supplied-root mutation, missing fixed input, or failed opening/closing
equality.

Do not repair anything.

──────────────────────────────────────────────────────────────────────────────
19. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return the complete report required by the preceding full V3 audit brief, plus:

1. Qualified launcher-package root identity and closure.
2. Copied launcher/wrapper/CLI/request identities.
3. Fresh launch-contract root-rebinding record.
4. Process self-check result.
5. Confirmation additional post-exec environment keys remained diagnostic.
6. Confirmation every local-process carrier used the exact qualified launcher.
7. Confirmation the launcher package was not rebuilt or modified.
8. Qualified package opening/closing equality.

Add these required confirmations:

QUALIFIED_LAUNCHER_PACKAGE_VERIFIED
QUALIFIED_LAUNCHER_PACKAGE_NOT_MUTATED
QUALIFIED_LAUNCHER_SOURCE_COPIED_BYTE_EXACT
QUALIFIED_WRAPPER_SOURCE_COPIED_BYTE_EXACT
CLI_CONTRACT_COPIED_BYTE_EXACT
REQUEST_CONTRACT_COPIED_BYTE_EXACT
FRESH_LAUNCH_CONTRACT_ONLY_ROOT_REBOUND
LAUNCHER_SEMANTICS_NOT_CHANGED
ENVIRONMENT_OBSERVATION_POLICY_NOT_CHANGED
PROCESS_SELF_CHECK_PASSED
ADDITIONAL_POST_EXEC_ENVIRONMENT_KEYS_DIAGNOSTIC_ONLY
ALL_LOCAL_CARRIERS_USED_QUALIFIED_LAUNCHER
NO_LOCAL_PROCESS_BYPASSED_PHASE_RECORDING
NO_CHILD_PROCESS_BYPASSED_CHILD_RECORDER

Retain every confirmation required by the preceding complete V3 audit brief.
Do not otherwise narrow or simplify that brief.
```

After an `ACCEPT`, stop V3 work and move to the real H→B parent-only commit gate. Do not add another launcher or validation-custody implementation tranche.

**Source:** Codex’s wrapped-carrier qualification report.   

**Confidence:** 0.995 that the launcher package is ready as immutable audit-process input; 0.99 that no additional launcher tranche is justified; 0.97 that the next valid step is the fresh full V3 audit.

Some older project attachments are no longer available in this session. The current attached report was sufficient for this assessment; re-upload older artifacts only when direct byte-level inspection of them is needed.
