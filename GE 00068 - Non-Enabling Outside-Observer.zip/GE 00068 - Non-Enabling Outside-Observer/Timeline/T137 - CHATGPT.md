## Assessment

The reconciliation is complete and removes the last known audit-input ambiguity. The exact fifth-audit inputs are now explicit:

- **Recipe source:** `/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/capture-final-provenance-v1.py`
- **Recipe SHA-256:** `bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333`
- **Expected canonical manifest:** `/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v3/provenance/manifest-run-1.json`
- **Manifest SHA-256:** `f900d6abb37f74fbcd628f622354e8e7898fb341a074071e464288e978e5b9d8`
- **Tracked binary-diff SHA-256:** `8aea2e7529c49a2bcda866ad60dbab43b31bb594f705a320ada92576a99507ac`
- **Verifier SHA-256:** `1379fd38799e12a44979812532f6100dc16e2af1a386b3297c5e85b450ab405f`
- **Test SHA-256:** `cf2f786435787bdf0c19d133f3ea15ffab52083de4163d30db6d0eaa56077132`

The manifest was selected through an indexed final recipe run rather than filename inference; all 13 rows match the live worktree, and the tracked diff was independently reproduced. The duplicate manifest and recipe copies are corroborating copies with an adequately explained selection rule, not unresolved provenance ambiguity.

No implementation repair, validation rerun, or report amendment is needed. The next step is the fifth independent audit. The selected architecture explicitly requires exact source to be supplied to a fresh audit before the first commit and does not ask the verifier to certify itself.  The audit must reproduce exact provenance before correctness inspection and stop on any mismatch. 

## Codex prompt: fifth fresh independent audit

```text
MANDATORY RESPONSE-FORMAT REQUIREMENT

Your final response must embed the complete audit report inline in Markdown.

Do not respond with only:

- a verdict;
- a summary;
- a link to a local report;
- “full report available at …”;
- or an attachment reference.

You may write and link a source-external report as supplemental evidence, but
the complete report required below must also appear in the response body.

This requirement applies to every outcome, including:

- ACCEPT;
- BLOCK;
- REJECT;
- AUDIT_PROVENANCE_MISMATCH;
- audit-process block;
- subagent-coverage block.

Do not silently truncate the inline report. When output pressure exists,
prioritize the complete inline report over local-file links.

Objective

Perform a fifth, fresh, read-only independent audit of the repaired Evidence
Verification v1 implementation.

Do not repair or modify the patch.

The fourth independent audit returned BLOCK for one high-severity executable-
source boundary defect, SEC-01. Repair-v3 reports that the verifier now binds
its actual executable source physically, rejects symlink or multi-link source
launches, and preserves the external-provenance/non-self-verification model.

A subsequent read-only input reconciliation recovered the exact recipe source,
canonical manifest, tracked binary diff, execution contract, and live-patch
binding for this fifth audit.

Return exactly one verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

This is a new audit of new bytes. No prior audit qualifies or rejects this
repair-v3 target.

No repository mutation.
No formatting.
No repair.
No repository cleanup.
No staging, commit, push, PR, merge, installation, deployment, A6 restart,
product test, product A/B, live-service invocation, network contact, or Linux
binary execution.

No nested subagents.

## 1. Exact audit inputs

Implementation worktree:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Expected branch:

codex/evidence-verification-v1

Expected HEAD:

567bceced5df95ecfe787cc66038d463a854e12c

Expected HEAD tree:

b7cab23732572c2aaea9d5f2f1593338e2e75338

Expected sole parent:

05dde14d185b6e022dcc169ef1a658a97961850f

Expected upstream:

absent

Implementation evidence root:

EVIDENCE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df

Repair-v3 evidence root:

REPAIR_V3=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v3

Repair-v3 implementation report:

IMPLEMENTATION_REPORT=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v3/closeout/implementation-report-v3.md

Exact provenance recipe source:

RECIPE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/capture-final-provenance-v1.py

Expected recipe object:

- regular file;
- mode `0600`;
- size `5143`;
- device/inode `16777234/176824598`;
- link count `1`;
- SHA-256:
  `bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333`.

Expected recipe ID:

execution-substrate.evidence-verification-v1.final-patch-provenance.v1

Exact retained canonical manifest:

EXPECTED_MANIFEST=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v3/provenance/manifest-run-1.json

Expected manifest object:

- regular file;
- mode `0600`;
- size `3192`;
- device/inode `16777234/176911418`;
- link count `1`;
- SHA-256:
  `f900d6abb37f74fbcd628f622354e8e7898fb341a074071e464288e978e5b9d8`.

Expected tracked binary-diff SHA-256:

8aea2e7529c49a2bcda866ad60dbab43b31bb594f705a320ada92576a99507ac

Expected current verifier SHA-256:

1379fd38799e12a44979812532f6100dc16e2af1a386b3297c5e85b450ab405f

Expected current test SHA-256:

cf2f786435787bdf0c19d133f3ea15ffab52083de4163d30db6d0eaa56077132

Expected unchanged registry SHA-256:

e35306141f58ab7b2908b3c62a74d173af17c6e7124acc92bd5737ec7004d880

Expected unchanged layout SHA-256 values:

A6D successor:
267053d083ecac7a7bcf8533e14d207c1438c032e66eaa95ba240d8b683eb0dc

A6D amendment:
3f6e47873c3760e2c2de6560aa9031d5657efff8d42ce9b5fda26fe396f56be4

A6 policy:
b98258468ad7815fe924c25aa7f9959db12570b952e2713c2bd8ee3083ce07e8

Exact Python interpreter:

PYTHON=/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Expected interpreter object:

- version `3.13.4`;
- regular, single-link file;
- mode `0775`;
- size `119424`;
- device/inode `16777234/2301718`;
- SHA-256:
  `f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b`.

Fourth audit, read-only:

AUDIT_V4=/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v4

Fourth-audit report:

AUDIT_V4_REPORT=/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v4/closeout/report.md

Fourth-audit SEC-01 reproduction:

AUDIT_V4_REPRO=/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v4/validation/source-symlink-repro.json

Expected fourth-audit report SHA-256:

8402ef713e8ec41edd09ee8462fd2961f59253345206f683c2a956e76e9df479

Expected fourth-audit reproduction SHA-256:

ebfab10a586a1e626132eddf0a74ac93edd7445571bb56e99f0ff021c88cd1f8

Earlier audits, read-only:

AUDIT_V1=/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-567bceced5df-v1

AUDIT_V2=/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v2

Nonqualifying audit v3, read-only:

AUDIT_V3=/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v3

Original sealed A6D child:

A6D=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

Expected A6D manifest SHA-256:

dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9

Sealed A6D amendment:

A6D_AMEND=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

Expected amendment manifest SHA-256:

a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e

Required fresh audit root, absent at opening:

AUDIT_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5

Forbidden primary checkout:

PRIMARY_R=/Users/ds/Repositories/Execution Substrate

## 2. Strict Git and process boundary

Use the exact sanitized base environment:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
TMPDIR=/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5/tmp

Launch audit commands from an explicitly constructed environment containing
only those variables, except when a required operating-system variable is
proven necessary and separately disclosed.

Only the audit parent may execute Git.

Every direct audit Git invocation must be exactly rooted as:

git -C "$IMPL_R" ...

and inherit:

GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1

The exact supplied provenance recipe may execute Git internally only after its
source bytes and semantics are verified. Its internal Git calls must all use:

git -C <root>

with cwd equal to that root.

No audit perspective or subagent may execute Git.

Do not execute Git in:

- PRIMARY_R;
- a Repair 10I candidate;
- A6D;
- A6D_AMEND;
- EVIDENCE;
- AUDIT_V1;
- AUDIT_V2;
- AUDIT_V3;
- AUDIT_V4;
- AUDIT_ROOT.

Do not use implicit-current-directory Git invocations.

Record every parent Git argv, cwd, and relevant environment.

Any nonconforming Git operation is an audit-process blocker. Disclose it
immediately and do not silently continue.

## 3. Audit root and provenance replay roots

Require AUDIT_ROOT absent.

Create it directly under umask `077`, without symlink components, with:

opening/
provenance/
perspectives/
validation/
findings/
closeout/
tmp/

Create direct, physical opening provenance directories:

OPENING_CONTINUATION=$AUDIT_ROOT/opening/provenance-replay-v1

OPENING_PROVENANCE=$OPENING_CONTINUATION/provenance

Create:

- `$OPENING_CONTINUATION`
- `$OPENING_PROVENANCE`

under umask `077`.

Require these absent before creation:

- `$OPENING_PROVENANCE/manifest-run-1.json`
- `$OPENING_PROVENANCE/manifest-run-2.json`
- every opening stdout/stderr capture path.

Do not create the closing continuation until closeout.

All audit output remains beneath AUDIT_ROOT.

Remove only audit-owned temporary fixture roots. Do not remove, chmod,
normalize, rewrite, or restore metadata on a repository or supplied-evidence
object.

## 4. Opening repository gate

Require IMPL_R:

- physical root equals lexical path;
- root is a real directory and not a symlink;
- branch:
  `codex/evidence-verification-v1`;
- HEAD:
  `567bceced5df95ecfe787cc66038d463a854e12c`;
- HEAD tree:
  `b7cab23732572c2aaea9d5f2f1593338e2e75338`;
- sole parent:
  `05dde14d185b6e022dcc169ef1a658a97961850f`;
- upstream:
  absent;
- exactly 13 changed or untracked paths;
- exactly four modified tracked paths;
- exactly nine untracked paths;
- every patch path regular and single-link;
- every working-tree mode `0644`;
- every logical mode `100644`;
- zero staged;
- zero deleted;
- zero renamed;
- zero unmerged;
- no Git operation marker or lock;
- no path outside the expected set.

Expected paths:

1. `PLANS.md`
2. `.docs/system_overview/boundaries.md`
3. `.docs/system_overview/artifact_hygiene.md`
4. `.docs/system_overview/capability_probing.md`
5. `.docs/system_overview/evidence_verification.md`
6. `tools/evidence_verify/verify_v1.py`
7. `tools/evidence_verify/registry_v1.json`
8. `tools/evidence_verify/layouts/a6d_successor_v1.json`
9. `tools/evidence_verify/layouts/a6d_amendment_v1.json`
10. `tools/evidence_verify/layouts/a6_policy_v1.json`
11. `tools/evidence_verify/test_verify_v1.py`
12. `tools/evidence_verify/fixtures/historical_a6d_verify_postseal_v1.py.txt`
13. `tools/evidence_verify/fixtures/historical_a6d_verify_closing_v1.py.txt`

Stop before correctness inspection on mismatch:

AUDIT_PROVENANCE_MISMATCH

## 5. Exact input identity and recipe-semantic gate

Open RECIPE and EXPECTED_MANIFEST through no-follow descriptors with stable
before/read/after identity checks.

Require RECIPE to match every object identity and digest in section 1.

Require EXPECTED_MANIFEST to match every object identity and digest in
section 1.

Inspect RECIPE source and require:

- recipe ID:
  `execution-substrate.evidence-verification-v1.final-patch-provenance.v1`;
- exactly required `--root`, `--continuation`, and `--output`;
- root and continuation must be absolute physical paths;
- output must be directly under `<continuation>/provenance/`;
- output basename only `manifest-run-1.json` or `manifest-run-2.json`;
- exclusive `xb` output creation;
- output mode `0600`;
- canonical bytes also written identically to stdout;
- every Git operation uses `git -C <root>`;
- Git cwd equals root;
- branch, HEAD, tree, absent upstream, exact tracked/untracked scope checked;
- UTF-8-byte path sorting;
- exact deterministic tracked diff command:
  `git diff --binary --no-ext-diff --no-textconv --no-color --full-index HEAD --`;
- compact sorted-key ASCII JSON plus one LF;
- no timestamp, randomness, hostname, username, or machine-specific absolute
  path in canonical output.

Parse EXPECTED_MANIFEST and require:

- expected recipe ID;
- expected branch and HEAD;
- null/absent upstream according to frozen schema;
- exactly 13 file identities;
- exactly four `tracked_modified`;
- exactly nine `untracked`;
- exact expected path set;
- regular type throughout;
- logical mode `100644`;
- complete size and SHA-256;
- tracked binary-diff:
  `8aea2e7529c49a2bcda866ad60dbab43b31bb594f705a320ada92576a99507ac`;
- verifier SHA-256:
  `1379fd38799e12a44979812532f6100dc16e2af1a386b3297c5e85b450ab405f`;
- test SHA-256:
  `cf2f786435787bdf0c19d133f3ea15ffab52083de4163d30db6d0eaa56077132`;
- registry and layout hashes as specified in section 1.

Stop on any mismatch:

AUDIT_PROVENANCE_MISMATCH

## 6. Opening provenance reproduction

Run from cwd:

`/Users/ds/Repositories/Execution Substrate - evidence-verification-v1`

with the exact sanitized environment from section 2.

Opening run 1 argv:

[
  "/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13",
  "-I",
  "-B",
  "/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/capture-final-provenance-v1.py",
  "--root",
  "/Users/ds/Repositories/Execution Substrate - evidence-verification-v1",
  "--continuation",
  "/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5/opening/provenance-replay-v1",
  "--output",
  "/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5/opening/provenance-replay-v1/provenance/manifest-run-1.json"
]

Opening run 2 uses the identical argv except the output ends with:

`manifest-run-2.json`

Capture stdout and stderr separately beneath:

`$AUDIT_ROOT/opening/`

without altering the recipe argv.

Require:

- both exits `0`;
- stderr empty;
- both output files byte-identical;
- both stdout streams byte-identical;
- each stdout stream byte-identical to its output file;
- all four byte streams byte-identical to EXPECTED_MANIFEST;
- SHA-256:
  `f900d6abb37f74fbcd628f622354e8e7898fb341a074071e464288e978e5b9d8`;
- tracked binary-diff:
  `8aea2e7529c49a2bcda866ad60dbab43b31bb594f705a320ada92576a99507ac`;
- exact 13-path set;
- exact four/nine classifications;
- every live file identity matches the manifest;
- no repository or supplied-evidence mutation.

Stop before correctness inspection on any difference:

AUDIT_PROVENANCE_MISMATCH

## 7. Audit lineage disposition

Inspect AUDIT_V4_REPORT and AUDIT_V4_REPRO read-only and require their expected
SHA-256 values.

Require the audit to record:

- audit v4 returned BLOCK;
- SEC-01 was its only blocking residual finding;
- v4 evaluated predecessor bytes;
- v4 does not qualify repair-v3 bytes;
- the parser perspective’s narrow minority containment view is preserved;
- repair-v3 claims SEC-01 repaired;
- this audit must independently determine whether that repair is correct.

Record audit v3 separately as permanently nonqualifying due to its provenance-
input failure and primary-checkout Git-process violation. Do not inherit any
correctness conclusion from v3.

## 8. Audit perspectives

Only after exact opening provenance succeeds, create exactly four bounded,
read-only audit perspectives.

Subagents may inspect source and audit-owned copies but execute no Git and
perform no repository write.

No nested subagents.

Roles:

1. Contract and authority auditor.
2. Verifier correctness and executable-source/state-semantics auditor.
3. Test and validation adequacy auditor.
4. Security, filesystem, capability, and artifact auditor.

Each perspective receives:

- the same reproduced canonical patch identity;
- exact verifier, test, registry, and layout identities;
- repair-v3 implementation report;
- audit-v4 report and SEC-01 reproduction;
- prior EV/F closure ledger;
- architecture target and non-goals;
- audit-v3 nonqualification.

Retry a failed perspective once.

Do not replace missing required perspective coverage with silent parent
inference.

Preserve minority findings.

## 9. Authority and whole-patch audit

Audit the entire 13-path patch.

Require:

- verifier remains an ES-owned `Bounded slice rule`;
- verifier output remains evidence/projection only;
- no readiness, product, runtime, admission, orchestration, durable-state, or
  execution authority;
- layouts remain structure-only;
- closeout and later independent audit retain readiness adjudication;
- no self-verification;
- no target-contained source trust;
- no evidence-child-local verifier authority;
- no runtime caller-supplied layout;
- no verifier-amendment chain;
- no product API, public schema, route, module, service, or runtime-contract
  change;
- repair-v3 does not give the verifier source-hash or provenance authority;
- source-byte trust remains external to the verifier.

The selected architecture is an ES-owned committed external verifier whose
exact source is independently audited before first commit. It does not verify
itself or a new evidence child. 

Proof harnesses and generated evidence must remain non-authoritative. 

## 10. Full verifier correctness audit

Inspect the complete current `verify_v1.py`, not only repair-v3 changes.

### 10.1 Executable-source binding

Independently inspect and determine:

- how `__file__` and `sys.argv[0]` are related;
- what spelling becomes the invocation-source authority;
- whether that spelling must be absolute;
- how every source-path component is observed no-follow;
- whether any source-path component symlink can escape detection;
- how the final source is opened;
- required file type;
- required link count;
- opening `lstat`, descriptor `fstat`, and path re-observation;
- source descriptor lifetime;
- source parent identity;
- physical package ancestry derivation;
- source-package/target equality and containment;
- target/source-package reverse containment;
- case-alias behavior;
- closing source identity and ancestry checks;
- disappearance, substitution, inode reuse, and race handling;
- unsupported-operation behavior;
- output minimization.

Reject reliance on:

- lexical `Path(__file__).absolute().parent`;
- `resolve()` alone;
- `realpath()` string equality;
- `commonpath()` string equality;
- case folding or lowercase comparison;

as the deciding physical boundary.

Confirm that external provenance remains the source-byte authority and that the
verifier does not claim to authenticate its own bytes.

### 10.2 Independent SEC-01 adversarial matrix

Using only audit-owned fixture roots and copies of the exact current verifier,
independently run at minimum:

1. Direct, absolute, regular, single-link external source with disjoint target:
   - pre-seal pass;
   - sealed pass.

2. Direct source physically beneath target:
   - pre-seal `TARGET_BOUNDARY`/2;
   - sealed `TARGET_BOUNDARY`/2.

3. External final-component symlink to target-contained source:
   - both stages `TARGET_BOUNDARY`/2.

4. External parent-directory symlink leading to target-contained source:
   - both stages `TARGET_BOUNDARY`/2.

5. External hardlink to target-contained source:
   - source link count greater than one;
   - both stages `TARGET_BOUNDARY`/2.

6. Source package beneath target:
   - reject.

7. Target beneath source package:
   - reject.

8. Source package equal to target:
   - reject.

9. Case-variant spelling of a prohibited physical relationship:
   - reject identically on this host.

10. Source identity changes before closing adjudication:
    - `IO_OR_RACE`/7;
    - no pass.

11. Source disappears before closing adjudication:
    - `IO_OR_RACE`/7;
    - no pass.

12. Unsupported source no-follow or parent traversal:
    - `IO_OR_RACE`/7;
    - no pathname fallback.

13. Same source bytes, distinct single-link inode, physically disjoint:
    - both stages pass.

14. External source whose parent component is a symlink:
    - `TARGET_BOUNDARY`/2.

15. Relative source invocation:
    - `TARGET_BOUNDARY`/2.

16. Final source symlink to a physically external source:
    - `TARGET_BOUNDARY`/2 under the direct-source-only rule.

For every negative require:

- exact outcome;
- exact error class;
- exact exit;
- exactly one canonical stdout line;
- empty stderr;
- no traceback;
- no leaked source or target path.

First reproduce the SEC-01 mechanism against an audit-owned copy of the exact
predecessor verifier when safely recoverable from retained repair-v3 evidence.
Require the predecessor to pass and the repaired source to reject. If exact
predecessor bytes are unavailable, report that limitation and rely on the
retained audit-v4 reproduction without approximating the source.

### 10.3 Closing race review

Inspect whether the closing source and package checks can be defeated by:

- replacing the source path after opening;
- replacing a source parent directory;
- renaming the source package;
- reusing an inode;
- changing link count;
- changing mode or size;
- removing and recreating source;
- swapping a case alias.

Use small, bounded, audit-owned injected races where safe.

Do not claim resistance to privileged kernel-level identity forgery.

### 10.4 Previous correctness mechanisms

Independently re-audit prior repaired mechanisms:

- target/package/candidate physical ancestry;
- case aliases;
- candidate symlink and hardlink handling;
- literal-LF manifest grammar;
- bounded package JSON;
- bounded manifest streaming;
- seal-file and aggregate read accounting;
- complete decimal parsing and error classification;
- spec-path validation before target opening;
- capability preflight and post-preflight uncertainty;
- exact file/directory/mode/path closure;
- deterministic canonical output;
- zero-write behavior.

## 11. Test and validation audit

Inspect the complete current `test_verify_v1.py`.

Discover the exact test identities independently.

Expected:

- 75 tests;
- four producer runs:
  - twice under umask `077`;
  - twice under umask `022`;
- zero failure;
- zero error;
- zero skip.

Independently run the complete suite:

1. twice under umask `077`;
2. twice under umask `022`.

Require:

- identical discovered test set;
- exactly 75 passes every run;
- zero skip;
- no repository artifact;
- deterministic relevant outputs.

Audit whether tests 60–75 independently and causally exercise their stated
mechanism.

Check specifically that:

- test 62 cannot pass merely because generic package/target containment
  already rejects;
- test 63 genuinely traverses a symlinked parent component;
- test 64 proves multi-link source rejection;
- tests 69–70 actually reach closing source re-observation;
- test 71 exercises both no-follow and parent-traversal uncertainty without
  pathname fallback;
- test 72 proves byte equality alone is not containment;
- tests 74–75 distinguish relative spelling and final-source symlink.

Check for circular tests in which the same implementation helper generates the
expected result without an independent oracle.

Require prior tests 01–59 to remain present and effective.

## 12. Fresh compatibility validation

Use exact PYTHON and sanitized environment from sections 1–2.

Run independently:

1. AST parse of all current Python source.
2. Parse both historical `.py.txt` files without executing them.
3. Strict registry and three-layout parsing.
4. Complete 75-test suite four times under the two umasks.
5. Every independent SEC-01/source-boundary causal.
6. Sealed A6D verification twice.
7. Sealed amendment verification twice.
8. Synthetic A6 pre-seal verification twice.
9. Test-owned synthetic sealing.
10. Synthetic A6 sealed verification twice.
11. Repeated canonical-output comparison.
12. Before/after target, manifest candidate where applicable, verifier package,
    and TMPDIR snapshots.
13. Parent-only explicitly rooted:
    `git -C "$IMPL_R" diff --check`
    with both required Git environment bindings.

Require:

- all repeated outputs byte-identical;
- all stderr empty on successful invocations;
- no real sealed child mutation;
- no verifier-package mutation;
- no repository artifact.

Expected real-child output hashes reported by implementation:

- A6D stdout:
  `3bbbc3d2ba257007e2d5b55991ce043d1cb7c5cb841e70e86f6421752e38d606`
- amendment stdout:
  `be83077cf61b3250eb39239e0e60bdadcec42d6ae4c2e8d6a9542ccd1caffabc`.

Treat these as reported expectations to verify, not as proof.

## 13. Registry, layout, and repair-scope confirmation

Require live hashes:

- registry:
  `e35306141f58ab7b2908b3c62a74d173af17c6e7124acc92bd5737ec7004d880`
- A6D successor layout:
  `267053d083ecac7a7bcf8533e14d207c1438c032e66eaa95ba240d8b683eb0dc`
- A6D amendment layout:
  `3f6e47873c3760e2c2de6560aa9031d5657efff8d42ce9b5fda26fe396f56be4`
- A6 policy layout:
  `b98258468ad7815fe924c25aa7f9959db12570b952e2713c2bd8ee3083ce07e8`.

Require repair-v3 to have changed, relative to its opening target, only:

- `tools/evidence_verify/verify_v1.py`
- `tools/evidence_verify/test_verify_v1.py`
- `.docs/system_overview/evidence_verification.md`
- `.docs/system_overview/artifact_hygiene.md`.

Audit the entire current 13-path patch, not only those four repair-v3 files.

## 14. Security and artifact audit

Inspect:

- source descriptor flags and lifetime;
- no-follow source-path component traversal;
- source identity tuple;
- package descriptor lifetime;
- ancestor traversal termination;
- target and candidate identities;
- concurrent replacement behavior;
- bounded file and manifest reads;
- exception handling;
- output minimization;
- no writes;
- no child process;
- no network;
- no target-code import;
- no runtime layout injection;
- no source-hash self-authority.

Inspect IMPL_R for:

- `__pycache__`;
- `.pyc` and `.pyo`;
- `.pytest_cache`;
- generated manifests;
- databases;
- journals;
- locks;
- fixture roots;
- temporary output;
- unexpected executable modes;
- unsupported file types.

Historical fixtures must remain inert and never be imported or executed as
repository code.

## 15. Repair-v3 evidence audit

Inspect:

- repair-v3 SEC-01 disposition;
- minority-view disposition;
- vulnerable predecessor reproduction;
- tests 60–75 individual causals;
- four full 75-test runs;
- exact test list;
- real-child checks;
- synthetic checks;
- no-write snapshots;
- failed/superseded index;
- cleanup;
- implementation report;
- final provenance.

Require:

- SEC-01 explicitly closed with source and test evidence;
- minority view preserved rather than erased;
- no earlier audit represented as qualifying changed bytes;
- final validation bound to final source bytes;
- no failed or superseded attempt silently omitted;
- registry/layout unchanged claim supported;
- no authority or security widening;
- source-external report copy and inline producer report materially agree.

## 16. Parent adjudication

After all four perspectives complete:

1. Preserve every material finding and disagreement.
2. Distinguish:
   - provenance mismatch;
   - residual patch defect;
   - repaired patch defect;
   - pre-existing issue;
   - audit-process issue;
   - future hardening seam.
3. Reconcile SEC-01 and every earlier EV/F finding against current source and
   fresh causals.
4. Audit the entire 13-path patch.
5. Do not accept solely because tests pass.
6. Do not reject because the verifier is ES-local rather than a general
   cross-repository framework.
7. Do not repair.

## 17. Closing provenance replay

Remove only audit-created temporary fixture roots.

Require a fresh, absent closing continuation:

CLOSING_CONTINUATION=$AUDIT_ROOT/closeout/provenance-replay-v1

CLOSING_PROVENANCE=$CLOSING_CONTINUATION/provenance

Create both as direct directories under umask `077`.

Require closing manifest and stdout/stderr capture targets absent.

Use the same cwd, PYTHON, sanitized environment, RECIPE, and IMPL_R.

Closing run 1 argv is the opening run-1 argv with:

- `--continuation` set to:
  `/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5/closeout/provenance-replay-v1`
- `--output` set to:
  `/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5/closeout/provenance-replay-v1/provenance/manifest-run-1.json`

Closing run 2 uses the same closing continuation and output basename
`manifest-run-2.json`.

Require:

- both exits `0`;
- stderr empty;
- both output files byte-identical;
- both stdout streams byte-identical;
- all four byte streams byte-identical to EXPECTED_MANIFEST;
- SHA-256:
  `f900d6abb37f74fbcd628f622354e8e7898fb341a074071e464288e978e5b9d8`;
- tracked binary-diff:
  `8aea2e7529c49a2bcda866ad60dbab43b31bb594f705a320ada92576a99507ac`;
- repository identity unchanged;
- exact 13-path identities unchanged;
- zero staged/deleted/renamed/unmerged;
- no audit-created repository object;
- A6D and A6D_AMEND unchanged;
- EVIDENCE, AUDIT_V1, AUDIT_V2, AUDIT_V3, and AUDIT_V4 unchanged.

On any difference:

AUDIT_PROVENANCE_MISMATCH

## 18. Finding format

For every material finding use:

AUDIT FINDING

ID:
Type:
Severity: critical | high | medium | low | observation
Classification:
Current contract or strategic target:
Path and line:
Evidence:
Reachable mechanism:
Impact:
Required correction:
Containment/nonclaim:
Uncertainty:
Patch defect, pre-existing issue, or audit-process issue:
Blocking: yes | no

## 19. Verdict rules

### AUDIT_PROVENANCE_MISMATCH

Use when:

- repository identity differs;
- recipe source differs or is unavailable;
- expected manifest differs;
- path set, classification, mode, size, or file digest differs;
- repeated provenance is unstable;
- tracked diff differs;
- closing provenance differs.

Stop before correctness inspection on opening mismatch.

### REJECT

Use only for a fundamental authority or decomposition defect that cannot be
repaired inside the bounded 13-path tranche.

### BLOCK

Use when any repairable correctness, security, source-boundary, resource,
validation, test, artifact, or evidence defect remains.

### ACCEPT

Use only when:

- opening and closing provenance match;
- exact recipe and manifest paths were used directly;
- SEC-01 is independently and causally closed;
- every earlier blocking EV/F finding remains closed;
- authority and non-self-verification boundaries remain sound;
- executable source is physically source-external under all tested aliases;
- source identity and closing checks are fail-closed;
- tests are mechanism-specific and umask-independent;
- real and synthetic compatibility checks pass;
- no artifact, evidence, or report blocker remains;
- every audit Git command was parent-only and explicitly rooted.

## 20. Required complete inline final report

Your final response must contain the complete report inline.

Do not replace any section with a link. Supplemental links may follow the
complete inline report.

Include:

1. Verdict.
2. Response-format confirmation.
3. Exact recipe-source and canonical-manifest paths used.
4. Opening and closing provenance.
5. Canonical manifest and tracked-diff SHA-256 values.
6. Repository identity and exact 13-path scope.
7. All four audit perspectives and completion status.
8. Audit-v3 and audit-v4 lineage disposition.
9. Complete SEC-01 adjudication.
10. Preserved minority view.
11. Closure table for SEC-01 and every prior EV/F finding.
12. Authority and non-self-verification adjudication.
13. Full executable-source binding review.
14. Every independent source-boundary causal and result.
15. Source closing-race adjudication.
16. Whole-verifier correctness adjudication.
17. Test and validation adjudication.
18. Exact discovered test count and identities or a complete safe reference
    plus inline count and coverage summary.
19. Both umask-077 results.
20. Both umask-022 results.
21. Real A6D checks.
22. Real amendment checks.
23. Synthetic pre-seal and sealed checks.
24. Security, filesystem, capability, resource, and artifact adjudication.
25. Repair-v3 evidence adjudication.
26. Severity-ranked residual findings.
27. Minority findings and parent resolution.
28. Uninspected areas and uncertainty.
29. Audit-created paths and cleanup.
30. Exact Git-process-boundary confirmation.
31. Explicit confirmations:
    - repository mutation not performed;
    - formatting not performed;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 not restarted;
    - product tests/live services not invoked;
    - network contact not performed;
    - nested subagents not created.

No repair.
No commit.
No push.
No A6 restart.
No product A/B.
No snapshot or deployment.
```

An `ACCEPT` result moves to a separate exact-byte commit gate. That gate may stage only the accepted 13 paths, compare staged blobs, modes, and sizes to the accepted manifest, run byte-preserving validation, commit once, and compare committed blobs again. No implementation repair is allowed during the commit gate. 

### Sources

- Fifth-audit input reconciliation supplied in this turn.
- Exact prior input-selection pattern and requirement that manifest rows match live bytes. 
- Selected external-verifier architecture and non-self-verifying bootstrap. 
- Proof tooling and generated evidence remain non-authoritative. 
- Independent audit must reproduce exact provenance before correctness inspection. 
- Exact recipe source, not only its hash, must remain available. 

**Confidence**

- Input reconciliation correctness: **0.999**
- Evidence of current implementation drift: **none found**
- Readiness for fifth fresh audit: **0.999**
- Confidence that the prompt closes the prior audit-input failure: **0.998**
- Need for any further implementation work before audit: **low, approximately 0.01**
- Correct next gate after audit `ACCEPT`: exact-byte commit gate, **0.999**
