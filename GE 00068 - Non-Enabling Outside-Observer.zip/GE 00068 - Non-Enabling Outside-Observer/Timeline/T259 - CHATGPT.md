## Assessment

This is a favorable `BLOCK`. The independent audit qualified every execution-bearing part of the design:

- opening and closing provenance;
- independent short-root allocation;
- exact-B materialization and Git-tree identity;
- the 86-byte worst-case pathname derivation;
- all four custody causals;
- all eight validation commands;
- exact identity-level pass/fail/skip adjudication;
- cross-command generated-state isolation;
- short-root cleanup and two absence observations;
- V2 capsule structural closure.

The remaining blockers are **record-completeness defects**, not implementation defects:

1. **The authoritative contract records do not explicitly freeze all allocator semantics.** The allocator implementation behaved correctly, but executable behavior cannot substitute for the declared contract.
2. **Two nonauthority statements are missing:** hostile/shared-host support and symlink/mount-alias support.
3. **The path-budget source closure omitted `src/internal/strconv/itoa.go`,** even though the 10-decimal-digit bound depends on `FormatUint`.

No repository change, B-source change, allocator change, test change, or validation rerun is needed. Repeating the full eight-command replay in the producer repair would add process risk without resolving a behavioral uncertainty—the independent audit already replayed it successfully.

The clean path is a **versioned record-completion successor**:

- preserve validation-custody V2 and plan V3 as immutable, technically successful but nonqualifying predecessor evidence;
- create `validation-custody.v3`;
- create `validation-plan.v4`, byte-semantically identical in its eight commands and outcomes, but bound to V3;
- add the missing allocator fields, explicit nonauthorities, and complete path-source closure;
- bind the V2 independent audit’s observed technical results without promoting its `BLOCK` verdict;
- run a fresh, narrow independent audit of the record-completion capsule and its bindings.

Only after that audit returns `ACCEPT` should the real H→B commit gate begin.

## Prompt for Codex

```text
REPAIR 10I T2A-P VALIDATION-CUSTODY V3 RECORD-COMPLETION REPAIR

Create a source-external, versioned record-completion successor for the
Repair 10I T2A-P strategic B validation-custody contract.

Do not create subagents.

This task does not modify or rerun:

- the candidate repository;
- the strategic B snapshot;
- the blocked V1 custody capsule;
- the V2 custody capsule;
- the V2 independent audit;
- B source bytes, logical modes, source T, inventory, Git tree, synthetic
  commit, tests, or H→B classification;
- the eight-command validation execution.

It does not stage, commit, publish, install, deploy, contact a network, or
begin A6.

Return exactly one primary verdict:

REPAIR10I_T2AP_VALIDATION_CUSTODY_V3_RECORD_COMPLETION_READY_FOR_FRESH_AUDIT
REPAIR10I_T2AP_VALIDATION_CUSTODY_V3_RECORD_COMPLETION_BLOCKED
VALIDATION_CUSTODY_V3_PROVENANCE_MISMATCH

OBJECTIVE

Repair exactly three independently audited record defects:

1. Freeze all acceptance-bearing allocator semantics in the sole authoritative
   structured contract.
2. Add explicit nonauthority for hostile/shared-host support and symlink,
   bind-mount, mount, and pathname-alias support.
3. Complete the exact-source closure of the socket path-budget proof by binding
   pinned Go `src/internal/strconv/itoa.go`.

Do not change executable behavior or validation outcomes.

──────────────────────────────────────────────────────────────────────────────
1. IMMUTABLE INPUTS
──────────────────────────────────────────────────────────────────────────────

CANDIDATE_R:

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Expected candidate identity:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- HEAD tree:
  b7cab23732572e5cbbdf41f5e68244ae15895
  NOTE: do not use this malformed line as an identity.
- authoritative HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- upstream:
  absent
- governed files:
  389
- tracked/untracked:
  375 / 14
- tracked modifications:
  22
- staged/deleted/renamed/unmerged:
  0 / 0 / 0 / 0
- current F source T:
  f276536fea579d0842cda43b0290656b200b7f27
- current F inventory SHA-256:
  2c152fd6a6d558bff3a56d906f0bd0b8c7f346fcb647d40fe386cfd02163d738

STRATEGIC_B_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-snapshot-tx56oir2

Required B identities:

- B source T / Git tree:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- B inventory SHA-256:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2
- B inventory size:
  54314
- governed files:
  389
- H→B:
  22 modified, 14 added, 0 deleted, 0 renamed
- synthetic commit:
  e42aac659299e023df07a842df17e9fc84a135c1

Required strategic-snapshot closeout identities:

- closeout/final-evidence-inventory.json
  size:
  130182
  SHA-256:
  fb30338e1a0fc39359b3517d6f70303ea086689330074b9f1f35854a431a73bb

- closeout/final-report.md
  size:
  151150
  SHA-256:
  2a853c551635c223eec38eb229535285541a653dfa5f1ce59855fd5b2082b2fe

- manifest/canonical-manifest-a-v1.json
- manifest/canonical-manifest-b-v1.json
  size:
  139328 each
  SHA-256:
  df5933f201437dc9ac55f22f72aac4bdde8477a203b7ca22358ab11e77f5c9fc

BLOCKED_V1_REPAIR_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-validation-custody-repair-ivliq7wf

Required historical disposition:

- sibling-root design;
- immutable and non-effective;
- final inventory SHA-256:
  42d0bd7607af442a4dd943c88175f7e2ef8baff739f72d7b01cccb637e73d3e0
- manifest SHA-256:
  73bafd4bf6eeaa7a2511af1a7ac01106ed0d32ab4d719c0dcbab1674985eb498

VALIDATION_CUSTODY_V2_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-validation-custody-v2-8r8lyfra

Required identities:

- device/inode/mode:
  16777234 / 178558083 / 0700
- producer verdict:
  REPAIR10I_T2AP_STRATEGIC_B_VALIDATION_CUSTODY_V2_READY_FOR_FRESH_AUDIT
- contract ID:
  execution-substrate.repair10i-t2ap.strategic-b-validation-custody.v2
- plan V3:
  size 28590
  SHA-256:
  fee24453d7c4c951f5ce27c55589f169737c97def516a7ad13df3cbe2eee1eee
- final evidence inventory:
  size 22990
  SHA-256:
  c17800c69c02565864f8f82a2d70cd5654b729c775c6503627c9742abac6d658
- final report:
  size 1355
  SHA-256:
  9e7fd3f059c2cd6e2e3fe306a28a47449b478c63203c82e73f717e1941ad25cd
- canonical manifests:
  size 24408 each
  SHA-256:
  2bcff6abee571388a37d30d956abb9012630796911f4aa57380806a67bc90628
  required:
  byte-identical

V2_INDEPENDENT_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v2-independent-audit-znleuyfy

Required identities:

- verdict:
  BLOCK
- closeout/final-audit-report.md
  size:
  92491
  SHA-256:
  e977c8ed3394f5e890a1cc1d6b0bf0067b7c430de9b264b5bd9d8028eb6c1e05
- closeout/final-audit-root-inventory.json
  size:
  69706
  SHA-256:
  9d29fb1b53f56768fc03762fb152562368f5f3903a02dc4aa0c10d14c2292caf

The audit’s dynamic observations are bounded evidence. Its BLOCK verdict is not
promoted or relabeled.

Required audited technical facts:

- independent short-root allocation passed;
- all four causals passed;
- exact B materialization passed;
- all eight validation commands passed their identity policies;
- cross-command isolation passed;
- cleanup and two ENOENT observations passed;
- V2 capsule closure passed;
- candidate and all supplied-root opening/closing equalities passed.

Required audited blockers:

- CONTRACT_FREEZE_INCOMPLETE;
- NONAUTHORITY_INCOMPLETE;
- PATH_SOURCE_CLOSURE_INCOMPLETE.

PINNED GO SOURCE

Go executable:

/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go

Expected SHA-256:

3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19

Required exact path sources include:

- B `internal/testsupport/controlroot.go`
  expected SHA-256:
  3242abc3bfd62400834b99d1386f88974f463ca5287be7faf4182161f8ec57f3

- B `internal/testsupport/controlroot_test.go`
  expected SHA-256:
  de224a8fe61becb88237fca683c1bd91406d8952d1f776819f3f069ef5509e6f

- B `es/runtimehelper/helper_test.go`
  expected SHA-256:
  715b6e1ada4f24a51457b31f28782966804479b18d0ba7b90c73609d17d0a1e0

- pinned Go `src/os/tempfile.go`
  expected SHA-256:
  a337c2a6dc2e4368b2dc0015ea7c0b935b68b14885a0771a6cbe27e588c2cd16

- pinned Go `src/internal/strconv/itoa.go`
  expected size:
  6171
  expected SHA-256:
  cfda0d39152dc8ad8e2eb0407682c399ea0a321796211e015096fa57b17a35d5

Use other inputs only through exact paths referenced by these named roots. Do
not broadly scan unrelated Downloads content or sibling repositories.

──────────────────────────────────────────────────────────────────────────────
2. EFFECT BOUNDARY
──────────────────────────────────────────────────────────────────────────────

Authorized:

- read the candidate and named immutable roots;
- allocate one fresh retained V3 repair root beneath /Users/ds/Downloads;
- create canonical documentary/provenance records, validators, reports, and
  manifests beneath that root;
- run bounded documentary and provenance validation;
- create audit-owned mutation fixtures beneath private V3-root state;
- remove only V3-root private transient state.

Forbidden:

- candidate repository or index mutation;
- mutation of any supplied root;
- B-source materialization for runtime validation;
- rerunning the complete eight-command validation plan;
- rerunning product or documentary repository tests;
- changing allocator executable behavior;
- changing command argv, order, expected identities, or expected results;
- staging or committing;
- product/live-service invocation;
- installation or deployment;
- network contact;
- A6 work;
- subagents.

Every Git read against the candidate must use:

git -C "/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1"

with cwd exactly equal to that repository and explicit:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

──────────────────────────────────────────────────────────────────────────────
3. FRESH V3 RECORD-REPAIR ROOT
──────────────────────────────────────────────────────────────────────────────

Under umask 077, allocate one unpredictable retained root beneath
/Users/ds/Downloads using tempfile.mkdtemp with prefix:

ES-repair10i-t2ap-validation-custody-v3-record-repair-

Retained directories must be physical mode 0700.

Retained files must be regular, single-link, mode 0600.

Recommended structure:

opening/
contract/
validation/
provenance/
manifest/
closeout/

Do not retain an unexplained empty directory.

All supplied roots remain immutable.

──────────────────────────────────────────────────────────────────────────────
4. SOLE AUTHORITATIVE V3 CONTRACT
──────────────────────────────────────────────────────────────────────────────

Create one canonical structured contract:

contract/strategic-b-validation-custody-v3.json

Contract ID:

execution-substrate.repair10i-t2ap.strategic-b-validation-custody.v3

This is the sole normative writer for validation custody. Projection and
evidence records must reference it and must not redefine, override, narrow, or
widen it.

The contract must freeze at least these exact typed facts.

A. Scope and status

```json
{
  "scope": "supported-local-source-external-validation",
  "status": "proposed-effective-pending-independent-audit",
  "source_authority": false,
  "publication_authority": false,
  "commit_authority": false,
  "product_authority": false,
  "runtime_authority": false,
  "deployment_authority": false,
  "readiness_authority": false,
  "a6_authority": false
}
```

B. Short-root allocation

```text
parent:
  /Users/ds/Downloads

basename_template:
  r10b-<32-lowercase-hex>

suffix_bytes:
  16

suffix_encoding:
  lowercase-hex

suffix_source:
  operating-system-csprng

fresh_suffix_per_attempt:
  true

attempt_limit:
  128

parent_traversal:
  component-by-component-no-follow

parent_descriptor_and_identity:
  held-from-parent-admission-through-exclusive-child-creation-and-child-verification

creation:
  descriptor-relative-exclusive-directory-creation

child_mode:
  0700

retry_condition:
  EEXIST-only

collision_material:
  fresh-csprng-material-per-attempt

collision_material_reuse_allowed:
  false

non_eexist_failure:
  terminal-no-retry-no-fallback

required_child_identity:
  direct-parentage-invoking-uid-expected-parent-gid-stable-device-inode-mode-0700

forbidden_authority_sources:
  counter
  git-hash
  latest-scan
  pid
  prefix-scan
  timestamp

forbidden_allocation_actions:
  adopt-existing
  rename-into-eligibility
  symlink-alias
  bind-mount-alias
  mount-alias
  pathname-alias
```

C. Child and environment layout

```text
children:
  c
  h
  m
  r
  s
  u

persistent_t_child:
  false

ES_REPAIR10_SOURCE_ROOT:
  ${SHORT_ROOT}/s

ES_REPAIR10_CONTROL_ROOT:
  ${SHORT_ROOT}/r

TMPDIR:
  ${SHORT_ROOT}/r

HOME:
  ${SHORT_ROOT}/h

GOTMPDIR:
  ${SHORT_ROOT}/u

GOCACHE:
  ${SHORT_ROOT}/c

GOMODCACHE:
  ${SHORT_ROOT}/m

control_tmp_lexical_equality_required:
  true

control_tmp_physical_identity_equality_required:
  true
```

D. Path-budget contract

```text
socket_path_limit_bytes:
  100

short_root_bytes:
  57

shared_control_tmp_root_bytes:
  59

generated_component_prefix_bytes:
  2

generated_uint32_decimal_max_digits:
  10

generated_component_max_bytes:
  12

separator_bytes:
  2

socket_leaf:
  identity.sock

socket_leaf_bytes:
  13

worst_case_socket_path_bytes:
  86

worst_case_admitted:
  true
```

E. Required exact source closure

The contract must bind path, size, and SHA-256 for every source needed to derive
the path budget, including:

- B `internal/testsupport/controlroot.go`
- B `internal/testsupport/controlroot_test.go`
- B `es/runtimehelper/helper_test.go`
- pinned Go `src/os/tempfile.go`
- pinned Go `src/internal/strconv/itoa.go`

Do not rely on a function name or prose summary where exact source bytes are
required.

F. Explicit nonauthority

The contract must state literally:

```text
shared_or_adversarial_host_supported:
  false

hostile_or_remotely_administered_host_supported:
  false

symlink_alias_supported:
  false

bind_mount_alias_supported:
  false

mount_alias_supported:
  false

pathname_alias_supported:
  false
```

These are nonauthority statements, not behavioral claims that V3 resists those
environments.

──────────────────────────────────────────────────────────────────────────────
5. VALIDATION PLAN V4
──────────────────────────────────────────────────────────────────────────────

Create:

contract/validation-plan-v4.json

It must preserve the V3 plan’s complete executable semantics:

- all eight command IDs;
- exact command order;
- normalized argv arrays;
- pinned tools;
- expected exits;
- exact pass/fail/skip identity policies;
- governing reasons;
- B source T, inventory, Git tree, synthetic commit, and H→B scope;
- shared `${SHORT_ROOT}/r` custody;
- all environment parameter names.

Permitted differences from plan V3:

- schema/version;
- contract reference from V2 to V3;
- exact source-closure reference;
- explicit nonauthority reference;
- lineage/status metadata;
- record identities generated by this repair.

No runtime command, argument, identity expectation, or result policy may change.

Produce a canonical semantic-equivalence record proving, after normalization,
that all eight executable command definitions and identity policies are
identical between plan V3 and plan V4.

──────────────────────────────────────────────────────────────────────────────
6. SUPERSESSION LINEAGE
──────────────────────────────────────────────────────────────────────────────

Create:

contract/validation-plan-supersession-v3.json

Freeze this exact lineage:

1. Base strategic-snapshot validation plan:
   historical source plan.

2. Blocked sibling-root plan V2:
   historical and non-effective because TMPDIR and control root were siblings.

3. Validation plan V3 under custody contract V2:
   executable behavior independently qualified, but non-effective because:
   - allocator contract freeze incomplete;
   - nonauthority incomplete;
   - path exact-source closure incomplete.

4. Validation plan V4 under custody contract V3:
   proposed effective pending fresh independent audit.

State explicitly that V3→V4 changes no:

- B source byte;
- logical mode;
- byte origin;
- inventory;
- source T;
- Git tree;
- synthetic commit;
- H→B path classification;
- validation command;
- command order;
- expected pass/fail/skip identity;
- observed V2 audit result.

The prior V2 audit remains `BLOCK`; its technical records are bounded inputs,
not a promoted verdict.

──────────────────────────────────────────────────────────────────────────────
7. TECHNICAL-EVIDENCE ADOPTION RECORD
──────────────────────────────────────────────────────────────────────────────

Create:

validation/v2-independent-technical-evidence-adoption-v1.json

Bind the complete V2 audit report and audit inventory.

List every technical observation being carried forward:

- allocator causals passed;
- 86-byte derivation independently reproduced;
- four validation-custody causals passed;
- exact B materialization passed;
- all eight commands passed their identity-level policies;
- cross-command isolation passed;
- cleanup passed;
- candidate and supplied-root closing equality passed;
- V2 capsule closure passed.

For each observation bind the exact source record path, size, and SHA-256 inside
the V2 audit root.

State:

- the V2 verdict remains BLOCK;
- V3 does not claim a new runtime execution;
- the adoption record is evidence composition, not verdict inheritance;
- a fresh V3 audit must independently decide whether the unchanged dynamic
  results apply to the record-complete V3 contract.

Do not copy the dynamic outputs into a competing evidence lineage unless needed
for exact manifest closure. Prefer references with exact identities.

──────────────────────────────────────────────────────────────────────────────
8. DOCUMENTARY VALIDATOR AND MUTATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Create one producer validator and one independently implemented validator.

Neither may import the other.

Both must:

- parse the V3 contract strictly;
- reject duplicate JSON keys;
- reject nonfinite values;
- require canonical one-line JSON where prescribed;
- require the exact complete typed field map;
- validate plan V4;
- validate supersession lineage;
- validate plan V3/V4 semantic equivalence;
- validate source-closure identities;
- validate explicit nonauthority;
- validate the V2 audit evidence-adoption bindings.

Run at least these mutation cases:

ALLOCATOR CONTRACT

1. fresh CSPRNG material disabled
2. suffix source changed from OS CSPRNG
3. descriptor-relative exclusive creation weakened
4. component no-follow traversal removed
5. retry condition widened beyond EEXIST
6. collision material reused
7. attempt limit changed from 128
8. non-EEXIST fallback admitted
9. latest/prefix scanning admitted
10. adoption admitted
11. rename into eligibility admitted
12. PID authority admitted
13. counter authority admitted
14. timestamp authority admitted
15. Git-hash authority admitted

NONAUTHORITY

16. shared/adversarial host support true
17. hostile/remote administration support true
18. symlink alias support true
19. bind-mount alias support true
20. mount alias support true
21. pathname alias support true

SOURCE CLOSURE

22. `itoa.go` omitted
23. `itoa.go` hash changed
24. `tempfile.go` hash changed
25. generated decimal maximum changed from 10
26. generated component maximum changed from 12
27. worst-case path changed from 86
28. limit changed from 100

PLAN PRESERVATION

29. command removed
30. command reordered
31. argv changed
32. expected identity removed
33. expected failure reclassified
34. expected skip reclassified
35. B source/tree identity changed
36. shared `r` custody changed

LINEAGE AND AUTHORITY

37. V2 BLOCK promoted to ACCEPT
38. V3 plan described as previously effective
39. V4 described as current without independent audit
40. V3 contract granted source authority
41. V3 contract granted publication/commit/readiness/A6 authority

Require every mutation to reject for its intended specific reason.

Retain exact validator source, inputs, results, and failed/superseded attempts.

──────────────────────────────────────────────────────────────────────────────
9. VALIDATION REQUIREMENTS
──────────────────────────────────────────────────────────────────────────────

Do not rerun the eight runtime commands.

Run only bounded record/provenance validation:

- exact supplied-input identity verification;
- V3 canonical-contract validation;
- plan V3/V4 semantic-equivalence validation;
- supersession validation;
- exact source-closure verification;
- technical-evidence adoption verification;
- producer mutation matrix;
- independent mutation matrix;
- bounded sensitive-material scan;
- capsule membership and mode checks.

The absence of a fresh runtime replay is intentional and must be stated
explicitly. Runtime behavior was independently observed in the V2 audit and is
unchanged by this record-only successor.

Return BLOCK if any V3 field changes executable semantics and would therefore
require replay.

──────────────────────────────────────────────────────────────────────────────
10. CAPSULE CONTENT
──────────────────────────────────────────────────────────────────────────────

Retain at minimum:

opening/
  candidate-identity.json
  strategic-b-binding.json
  blocked-v1-binding.json
  v2-capsule-binding.json
  v2-audit-binding.json

contract/
  strategic-b-validation-custody-v3.json
  validation-plan-v4.json
  validation-plan-supersession-v3.json
  plan-v3-v4-semantic-equivalence-v1.json
  path-source-closure-v3.json

validation/
  v2-independent-technical-evidence-adoption-v1.json
  producer-documentary-validator-result-v1.json
  independent-documentary-validator-result-v1.json
  mutation-matrix-v1.json
  failed-and-superseded-attempt-index-v1.json

provenance/
  producer validator source
  independent validator source
  source-closure checker
  semantic-equivalence checker
  closeout builder
  manifest builders

closeout/
  closing-equality-v1.json
  final-implementation-report-v1.md
  final-evidence-inventory-v1.json

manifest/
  canonical-manifest-a-v1.json
  canonical-manifest-b-v1.json

Do not copy the 389 B files or the full V2 runtime evidence into this capsule.

──────────────────────────────────────────────────────────────────────────────
11. AUTHORITY AND NONAUTHORITY
──────────────────────────────────────────────────────────────────────────────

The V3 capsule may claim only:

- a complete validation-custody contract;
- a record-complete validation plan;
- exact path-source closure;
- explicit nonauthority;
- semantic equivalence with the dynamically audited V2 behavior;
- bounded composition of retained technical evidence.

It may not claim:

- new B source, mode, origin, inventory, tree, or synthetic-commit authority;
- a new runtime validation run;
- inheritance of the V2 `BLOCK` verdict as acceptance;
- publication or commit authority;
- current repository truth for B;
- product/runtime/deployment readiness;
- A6 readiness;
- semantic-successor or orchestrator implementation;
- hostile/shared-host support;
- symlink or mount-alias support.

STRATEGIC_B_ROOT remains the sole B source/provenance package.

──────────────────────────────────────────────────────────────────────────────
12. CLOSING AND COMPLETE EVIDENCE CLOSURE
──────────────────────────────────────────────────────────────────────────────

After validation:

1. Remove only V3-root private transient fixtures.
2. Make two fresh absence observations.
3. Verify no process or descriptor survivor.
4. Reverify candidate identity unchanged.
5. Reverify STRATEGIC_B_ROOT unchanged.
6. Reverify BLOCKED_V1_REPAIR_ROOT unchanged.
7. Reverify VALIDATION_CUSTODY_V2_ROOT unchanged.
8. Reverify V2_INDEPENDENT_AUDIT_ROOT unchanged.
9. Verify no supplied-root mutation.
10. Generate two canonical manifests independently.
11. Require:
    - byte-identical manifests;
    - every retained directory represented;
    - every retained nonmanifest file represented exactly once;
    - only the two manifests self-excluded;
    - no empty, unexplained, symlink, special, or multiply linked object;
    - all directories mode 0700;
    - all files regular, single-link, mode 0600.
12. Retain a complete inline report and final inventory.

Return VALIDATION_CUSTODY_V3_PROVENANCE_MISMATCH on any opening/closing drift.

──────────────────────────────────────────────────────────────────────────────
13. STOP CONDITIONS
──────────────────────────────────────────────────────────────────────────────

Stop immediately on:

- candidate or supplied-root drift;
- missing exact source bytes;
- contract or plan ambiguity;
- any executable-semantic difference between plan V3 and V4;
- command-set, order, argv, or expected-result drift;
- inability to bind `itoa.go`;
- missing explicit nonauthority;
- mutation-matrix false acceptance;
- promotion of the V2 BLOCK verdict;
- new B-source authority;
- incomplete capsule closure;
- repository, supplied-root, network, product, live-service, or A6 activity.

──────────────────────────────────────────────────────────────────────────────
14. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return the complete report inline, including:

1. Primary verdict
2. Opening candidate and supplied-root identities
3. V3 repair-root identity
4. Exact three audit findings consumed
5. Contract V3 complete typed field map
6. Plan V3/V4 semantic-equivalence result
7. Supersession lineage
8. Exact path-source closure, including `itoa.go`
9. Explicit nonauthority disposition
10. V2 technical-evidence adoption
11. Producer validator design and result
12. Independent validator design and result
13. Complete mutation matrix
14. Confirmation no runtime replay occurred
15. Capsule authority and nonauthority
16. Artifact and sensitive-material findings
17. Cleanup and absence observations
18. Candidate and supplied-root closing equality
19. Complete retained membership and manifest identities
20. Remaining uncertainty
21. Explicit confirmations

Required confirmations:

CANDIDATE_REPOSITORY_MUTATION_NOT_PERFORMED
CANDIDATE_INDEX_MUTATION_NOT_PERFORMED
STRATEGIC_B_SNAPSHOT_MUTATION_NOT_PERFORMED
BLOCKED_V1_REPAIR_MUTATION_NOT_PERFORMED
VALIDATION_CUSTODY_V2_CAPSULE_MUTATION_NOT_PERFORMED
V2_INDEPENDENT_AUDIT_MUTATION_NOT_PERFORMED
OTHER_SUPPLIED_EVIDENCE_NOT_MUTATED
B_SOURCE_BYTES_NOT_MODIFIED
B_LOGICAL_MODES_NOT_MODIFIED
B_SOURCE_T_NOT_MODIFIED
B_GIT_TREE_NOT_MODIFIED
VALIDATION_COMMAND_SET_NOT_REDUCED
VALIDATION_COMMAND_SEMANTICS_NOT_CHANGED
PATH_SOURCE_CLOSURE_INCLUDES_PINNED_ITOA_GO
HOSTILE_SHARED_HOST_SUPPORT_EXPLICITLY_FALSE
SYMLINK_MOUNT_ALIAS_SUPPORT_EXPLICITLY_FALSE
RUNTIME_VALIDATION_NOT_RERUN
PRODUCT_OR_LIVE_SERVICE_NOT_INVOKED
NETWORK_CONTACT_NOT_PERFORMED
A6_NOT_STARTED
SEMANTIC_SUCCESSOR_NOT_IMPLEMENTED
ORCHESTRATOR_NOT_IMPLEMENTED
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED_IN_CANDIDATE
COMMIT_NOT_PERFORMED_IN_CANDIDATE
SUBAGENTS_CREATED: 0
```

After a successful producer pass, run a fresh narrow independent audit of the
combined target:

- immutable strategic B snapshot;
- immutable V2 dynamic-validation capsule and audit evidence; and
- V3 record-completion capsule.

Only an `ACCEPT` should unlock the real H→B commit gate.

### Source

:chatgpt-content-reference{index="0"}, especially §§1, 5–8, 14–21.

**Confidence:** 0.998 that no executable or repository repair is needed; 0.995 that the three blockers are completely addressable through a versioned record-completion capsule; 0.97 that the V2 runtime replay should not be repeated unless the V3 audit finds an executable-semantic difference.
