## Assessment

This attempt failed for **three execution-harness defects**, not for a package, target, or metadata-design defect:

1. **Historical tooling contamination.** A tool from the prior failed retry root was used beyond lineage-only inspection. That invalidates the new attempt’s process provenance even if its outputs were technically correct.
2. **Unpinned Python execution.** One diagnostic used Python without the exact pinned interpreter and required `-I -S -B` flags.
3. **Qualification-polarity error.** The aggregate treated the correct raw posture `payload_imported: false` as a failed positive check. The raw fact should remain false, while the assertion should be `payload_imported_is_false: true`.

The corrected 64-character digest is now fully authenticated. No further digest reconciliation is needed. The constructed exports and locally passing evidence in `...-u3ey9kca` remain nonauthoritative and must not be reused.

The narrow next step is a **wholly fresh retry of the same metadata-repair package task**, with a process-provenance gate before construction. All executable tooling must be newly retained in the fresh root or be an exact system executable; all Python invocations must use the pinned interpreter with `-I -S -B`; and raw posture values must be separated from positive assertions.

Forward this prompt to Codex:

```text
FRESH PROCESS-CLEAN RETRY —
TARGET-AUDIT HARNESS TRANSITIVE-METADATA REPAIR,
PHYSICAL-ROOT REBINDING, QUALIFICATION, AND TERMINAL CLOSURE

The immediately preceding attempt stopped correctly with:

PREFLIGHT_PROVENANCE_MISMATCH

The corrected governing digest authenticated successfully. The attempt is
nonqualifying solely because:

1. tooling from a prior failed retry root was used beyond lineage-only
   observation;
2. one Python diagnostic did not use the pinned interpreter with `-I -S -B`;
3. qualification aggregation incorrectly treated the correct raw fact
   `payload_imported:false` as a failed positive assertion.

This prompt authorizes a wholly fresh retry of the preceding bounded
transitive-metadata repair task with those three audit-process defects fixed.

All substantive objectives, semantic boundaries, fixed input identities,
metadata requirements, mutation requirements, qualification requirements,
freeze requirements, terminal closure requirements, stop conditions, verdict
rules, report requirements, and confirmations from the immediately preceding
metadata-repair prompt remain governing unless explicitly superseded below.

Do not reuse or promote any output from either failed retry.

Return exactly one primary verdict:

TARGET_AUDIT_HARNESS_PACKAGE_METADATA_REPAIR_READY
TARGET_AUDIT_HARNESS_PACKAGE_METADATA_REPAIR_BLOCKED
PREFLIGHT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. AUTHORITATIVE SEALED PREDECESSOR
──────────────────────────────────────────────────────────────────────────────

SEALED_PREDECESSOR_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-package-rebound-voptrogn

Expected identity:

- device/inode:
  16777234 / 180248929
- mode:
  0700
- physical entries:
  74
- directories:
  14
- regular files:
  60

Expected temporal inventory:

closeout/temporal-final-inventory-v2.json

- size:
  16600
- SHA-256:
  8f32a844819a333fd88588ea048455576147886f0a8b512a19278b5df6affca7

Expected terminal manifests:

manifest/canonical-manifest-a-v2.json
manifest/canonical-manifest-b-v2.json

- size:
  16431 each
- SHA-256:
  240259f8e850293f1d8b8bec8c349eb8d21bc931ea191ff34373cfa963a9eee7
- byte-identical:
  required

Authenticate the complete predecessor closure independently.

This sealed predecessor is the sole semantic and qualification input for the
new retry.

Do not adopt semantic exports, qualification outputs, generated metadata,
helpers, validators, builders, or tools from either failed retry root.

──────────────────────────────────────────────────────────────────────────────
2. CORRECTED GOVERNING IDENTITY
──────────────────────────────────────────────────────────────────────────────

Subject:

/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-package-rebound-voptrogn/validation/two-root-rebinding-determinism-v1.json

Expected:

- size:
  8350
- SHA-256:
  f1e0882854891c2bb8f851309bf9e8d6f5eb97c13e482809009b75e7aeb31d3e

Malformed historical value:

f1e0882854891c2bb8f851309bf8d6f5eb97c13e482809009b75e7aeb31d3e

- length:
  62
- current authority:
  false
- permitted use:
  historical error record only

Before construction require exact agreement among:

- predecessor manifest A row;
- predecessor manifest B row;
- independent no-follow file observation.

Retain a fresh correction record in the new root. Do not copy the prior
retry’s correction record as current authority.

──────────────────────────────────────────────────────────────────────────────
3. IMMUTABLE FAILED RETRY ROOTS
──────────────────────────────────────────────────────────────────────────────

PRIOR_FAILED_RETRY_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-package-metadata-repair-h5f09wc4

LATEST_FAILED_RETRY_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-package-metadata-repair-u3ey9kca

Expected latest-root identity:

- device/inode:
  16777234 / 180345674
- mode:
  0700
- verdict:
  PREFLIGHT_PROVENANCE_MISMATCH

Both roots are immutable, nonauthoritative process-failure evidence.

They may be opened read-only solely to bind:

- root identity;
- failure verdict;
- failure report;
- correction-provenance identity;
- process-provenance failure reason;
- qualification-polarity failure reason.

Forbidden uses include:

- importing a module;
- executing a script;
- compiling a script for reuse;
- copying a helper, validator, builder, fixture, matrix, generated export, or
  qualification result;
- using a record as the current qualification oracle;
- adopting partially constructed exports;
- resuming package construction.

If either root is opened, require complete opening/closing equality.

Required confirmations:

PRIOR_FAILED_RETRY_ROOT_MUTATION_NOT_PERFORMED
LATEST_FAILED_RETRY_ROOT_MUTATION_NOT_PERFORMED
PRIOR_FAILED_RETRY_ROOT_NOT_RESUMED
LATEST_FAILED_RETRY_ROOT_NOT_RESUMED
NO_HISTORICAL_RETRY_TOOLING_EXECUTED
NO_HISTORICAL_RETRY_TOOLING_IMPORTED
NO_HISTORICAL_RETRY_OUTPUT_PROMOTED

──────────────────────────────────────────────────────────────────────────────
4. FRESH FINAL PACKAGE ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one wholly fresh final root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask `077`, prefix:

ES-repair10i-v3-target-audit-harness-package-metadata-repair-

Immediately emit:

PACKAGE_ROOT=<absolute-path>

This exact root is the final immutable package root.

Do not construct an intermediate current package and move or rename it later.

Before any package construction retain:

opening/bootstrap-start.json

including:

- fresh-root identity;
- allocation method;
- umask;
- sealed-predecessor identity;
- exact seven predecessor export identities;
- corrected governing identity;
- immutable failed-retry roots;
- process-provenance contract;
- repair authority:
  physical-root-rebinding-and-generated-metadata-repair-only;
- semantic source changes authorized:
  false;
- executable control-flow changes authorized:
  false;
- acceptance-rule changes authorized:
  false;
- real target audit executed:
  false.

Create directories lazily. Do not retain an empty directory.

──────────────────────────────────────────────────────────────────────────────
5. PROCESS-PROVENANCE GATE BEFORE CONSTRUCTION
──────────────────────────────────────────────────────────────────────────────

No semantic export may be written until this gate passes.

Retain:

opening/executable-origin-registry-v1.json
opening/python-invocation-contract-v1.json
opening/process-provenance-gate-v1.json

Every executable, script, validator, builder, diagnostic, fixture driver, and
qualification tool that may run must be registered before first execution.

Allowed executable origins are exactly:

A. Pinned Python:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

B. Exact absolute-path operating-system executables explicitly recorded in the
registry.

C. Fresh audit-owned source created in the new root, retained and hash-bound
before first execution.

D. Frozen successor semantic exports after they have been created in the new
root, and only for the qualification operations authorized by the governing
metadata-repair task.

Forbidden executable origins:

- either failed retry root;
- the blocked closure-attempt root;
- the failed unsealed package root;
- the sealed predecessor root, except that its semantic exports may be read as
  data inputs before fresh successor construction;
- unretained here-doc Python;
- unretained temporary scripts;
- code selected by basename, prefix, recency, scoring, or fallback;
- a script resolved through PATH.

For every fresh audit-owned executable source retain:

- path;
- role;
- size;
- SHA-256;
- mode/link count;
- producer;
- consumers;
- first permitted execution ordinal;
- historical-source dependency:
  none.

The process-provenance gate must verify:

- no registered executable source lies under a failed or historical root;
- every fresh helper exists in the new root;
- every helper identity is fixed before execution;
- every Python invocation contract is pinned;
- no semantic export has yet been written;
- no package construction has begun.

Any violation requires:

PREFLIGHT_PROVENANCE_MISMATCH

Do not continue.

──────────────────────────────────────────────────────────────────────────────
6. EXACT PINNED PYTHON CONTRACT
──────────────────────────────────────────────────────────────────────────────

Every Python process launched by this task, including:

- construction;
- parsing;
- diagnostics;
- hashing helpers;
- mutation matrices;
- independent validators;
- synthetic materializations;
- finalizer causals;
- compilation;
- static checks;
- freeze qualification;
- terminal inventory and manifest generators;

must begin with exactly:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
-I
-S
-B

Forbidden:

- `python`;
- `python3`;
- `/usr/bin/python3`;
- `/usr/bin/env python`;
- shebang-direct Python execution;
- Python resolved through PATH;
- missing `-I`;
- missing `-S`;
- missing `-B`;
- combined or reordered forms unless the process contract explicitly permits
  them. For this task, use the exact separate order `-I -S -B`.

Every Python process must use explicit stable environment values including:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

Use fresh audit-owned HOME, TMPDIR, and PYTHONPYCACHEPREFIX roots when the child
requires them.

No Python cache root may survive final cleanup.

Retain:

provenance/complete-python-process-ledger-v1.json

For each process record:

- ordinal;
- executable identity;
- argv;
- cwd;
- explicit environment;
- source path and identity;
- source-origin classification;
- start;
- stdout/stderr;
- exit/signal;
- reaping;
- descriptor closure;
- paths written;
- cache root;
- cleanup disposition.

Before preseal require:

- every Python process uses the exact pinned interpreter;
- every Python process uses exact `-I -S -B`;
- every source origin is permitted;
- every cache root is removed and twice absent;
- no package-local bytecode exists.

One violation requires:

PREFLIGHT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
7. FRESH FINITE CONSTRUCTION TOOLING
──────────────────────────────────────────────────────────────────────────────

Do not use construction tooling from an earlier root.

Create fresh construction and validation sources inside the new root under:

provenance/
validation/

Retain and hash-bind each source before execution.

Prefer one finite package-construction parent whose subprocess creation routes
through one retained recorder.

The parent must be:

- finite;
- noninteractive;
- stdin-independent;
- free of a persistent input loop;
- incapable of resuming an earlier root;
- unable to select tooling outside the executable-origin registry;
- unable to write outside the fresh package root and explicitly registered
  external qualification fixture/cache roots.

All subprocesses must route through its process recorder.

Do not use another hidden helper process.

Retain:

provenance/package-construction-parent-source.py
provenance/package-construction-process-ledger-v1.json

The construction parent is package evidence, not a consumer-facing export.

──────────────────────────────────────────────────────────────────────────────
8. QUALIFICATION RAW-POSTURE AND ASSERTION MODEL
──────────────────────────────────────────────────────────────────────────────

The failed retry incorrectly included:

payload_imported: false

inside a map whose values were aggregated with `all(...)`.

Repair the qualification evidence model.

Raw factual posture and positive assertions must be separate.

Required shape:

{
  "raw_posture": {
    "payload_imported": false
  },
  "assertions": {
    "payload_imported_is_false": true
  },
  "success": true
}

The raw field remains factual and false.

The assertion must be computed as:

type(payload_imported) is bool and payload_imported is False

Qualification success must be computed only from the positive assertion map.

Required aggregate rule:

- every assertion value must have exact type `bool`;
- every assertion value must be `true`;
- raw posture values must never be passed directly to `all(...)`;
- absence of the raw field must reject;
- integer `0` must reject as mistyped;
- string `"false"` must reject;
- raw `true` must reject;
- a source mutation that aggregates raw posture directly must reject.

Retain:

contract/qualification-posture-and-assertion-policy-v1.json
validation/qualification-polarity-matrix-v1.json

Required literal cases:

1. `payload_imported=false` → positive assertion true → pass.
2. `payload_imported=true` → assertion false → reject.
3. Missing raw field → reject.
4. Raw value integer `0` → reject.
5. Raw value string `"false"` → reject.
6. Raw false inserted directly into assertion map → reject.
7. Raw false included directly in `all(raw.values())` → reject.
8. Assertion missing → reject.
9. Assertion name wrong → reject.
10. Correct raw/assertion separation → pass.

Require:

- unique names;
- two-way closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip.

This is audit qualification logic only.

Do not edit the target-audit payload to change `payload_imported:false`.

──────────────────────────────────────────────────────────────────────────────
9. CORRECTED-DIGEST PROVENANCE
──────────────────────────────────────────────────────────────────────────────

Reauthenticate the corrected two-root-determinism identity directly from the
sealed predecessor and its terminal manifests.

Retain:

opening/supplied-identity-correction-v2.json

Require:

- subject path;
- size 8350;
- malformed 62-character value;
- corrected 64-character value;
- predecessor manifest A row;
- predecessor manifest B row;
- independent no-follow observation;
- exact three-way equality;
- current authority:
  corrected value;
- malformed value current authority:
  false;
- correction scope:
  one-fixed-preflight-identity-only;
- semantic effect:
  none.

Do not copy the correction record from a failed retry.

──────────────────────────────────────────────────────────────────────────────
10. COMPLETE FIXED-IDENTITY FORMAT PREFLIGHT
──────────────────────────────────────────────────────────────────────────────

Before constructing semantic exports, enumerate every fixed digest literal used
by this fresh task.

Require each SHA-256 literal to be:

- exactly 64 characters;
- lowercase hexadecimal.

Retain:

opening/fixed-identity-format-preflight-v1.json

If any malformed literal remains:

- retain a complete malformed-identity ledger;
- return `PREFLIGHT_PROVENANCE_MISMATCH`;
- do not begin package construction.

The corrected two-root-determinism digest must pass.

──────────────────────────────────────────────────────────────────────────────
11. RESTART THE METADATA-REPAIR TASK FROM THE SEALED PREDECESSOR
──────────────────────────────────────────────────────────────────────────────

After sections 5–10 pass, execute the complete preceding metadata-repair task
from its beginning against the sealed predecessor.

Do not adopt any partially constructed export or metadata file from a failed
retry.

Required work remains:

1. Allocate and preserve the exact final physical package root.
2. Copy the six byte-identical semantic exports.
3. Generate the root-bound plan by changing exactly:
   `/payload/frozen_source_identity/package_path`.
4. Generate clean versioned metadata:
   - `contract/package-root-rebinding-v2.json`
   - `opening/current-export-registry-v2.json`
   - `validation/current-qualification-result-v2.json`
   - `opening/target-audit-harness-package-freeze-v3.json`
5. Generate exactly four acceptance-bearing plan-identity consumers.
6. Resolve all four exact RFC 6901 pointers.
7. Generate a complete dependency graph.
8. Run the metadata-pointer mutation matrix.
9. Run the independent metadata-pointer validator.
10. Run root-rebinding matrix V2.
11. Run two-root metadata determinism.
12. Run fresh support-binding qualification.
13. Run fresh finalizer qualification.
14. Run two synthetic Carrier 0003 materializations.
15. Run synthetic finalizer causals.
16. Generate the current qualification result.
17. Freeze the seven exports.
18. Run post-freeze pointer resolution and metadata coherence.
19. Run frozen-package requalification V3.
20. Retain historical lineage.
21. Verify package immobility.
22. Verify cache and bytecode posture.
23. Repeat supplied-root closing equality.
24. Create temporal final inventory.
25. Generate terminal manifest A and B.
26. Independently reproject terminal closure.
27. Perform no write after closure.

All exact mutation registries, schemas, field maps, consumer pointers,
normalization rules, report requirements, and confirmations from the preceding
metadata-repair prompt remain required.

──────────────────────────────────────────────────────────────────────────────
12. FRESH QUALIFICATION — NO FAILED-RETRY RESULT PROMOTION
──────────────────────────────────────────────────────────────────────────────

Freshly produce every current qualification result.

Do not copy or promote:

- root-rebinding matrices;
- determinism results;
- support-binding results;
- finalizer results;
- synthetic materializations;
- synthetic causals;
- pointer matrices;
- independent validators;
- qualification results;
- freeze records;
- metadata-coherence records;
- requalification records;

from either failed retry.

Historical records may be read only for lineage comparison.

Current qualification must bind only:

- current final package root;
- current plan identity;
- current export identities;
- current metadata identities;
- current process ledger;
- current polarity policy and result;
- current fixture and cleanup evidence.

──────────────────────────────────────────────────────────────────────────────
13. CURRENT QUALIFICATION AGGREGATE
──────────────────────────────────────────────────────────────────────────────

Generate:

validation/current-qualification-result-v2.json

The result must separate:

- raw factual posture;
- positive assertions;
- counts and identities;
- qualification success;
- package authority;
- terminal closure.

Required:

- raw `payload_imported`:
  false;
- positive assertion `payload_imported_is_false`:
  true;
- no raw posture value in the assertion map;
- qualification success derived only from positive assertions and exact
  required matrices/results;
- `package_authority_established`:
  false before terminal closure;
- `terminal_closure_established`:
  false before terminal closure;
- `first_blocker`:
  null only when current qualification passes.

Retain exact source line or JSON pointer for every assertion producer.

──────────────────────────────────────────────────────────────────────────────
14. PROCESS-PROVENANCE PRESEAL GATE
──────────────────────────────────────────────────────────────────────────────

Before freeze and again before temporal inventory, require:

- complete executable-origin registry;
- complete Python process ledger;
- no executable helper from a historical or failed root;
- no unpinned Python;
- no Python invocation missing `-I -S -B`;
- no unregistered process;
- no unreaped child;
- no open process descriptor;
- no surviving cache root;
- no package-local bytecode;
- exact cleanup-set equality.

Retain:

validation/process-provenance-preseal-gate-v1.json

Any failure requires:

PREFLIGHT_PROVENANCE_MISMATCH

Do not seal a package with a failed process-provenance gate.

──────────────────────────────────────────────────────────────────────────────
15. FROZEN-PACKAGE REQUALIFICATION
──────────────────────────────────────────────────────────────────────────────

The frozen-package requalification must independently rerun:

- fixed export identity checks;
- exact direct plan-root delta;
- root-rebinding matrix V2;
- two-root metadata determinism;
- support-binding qualification;
- finalizer qualification;
- synthetic materializations;
- synthetic finalizer causals;
- qualification polarity matrix;
- metadata-pointer matrix;
- independent metadata validator;
- actual four-pointer resolution;
- dependency-graph completeness;
- process-provenance gate;
- cache/bytecode absence;
- package immobility.

Do not merely compare copied ledgers.

Every claimed pointer must be resolved against actual current documents.

Every executed qualification process must appear in the current process ledger.

──────────────────────────────────────────────────────────────────────────────
16. TERMINAL PACKAGE CLOSURE
──────────────────────────────────────────────────────────────────────────────

After all nonmanifest artifacts are final:

1. Generate and verify the temporal final inventory.
2. Ensure only the reserved `manifest/` directory may be empty premanifest.
3. Independently generate A and B.
4. Require generated bytes equal.
5. Exclusively create A and B.
6. Write/fsync/close both.
7. Fsync the manifest directory.
8. Reopen both no-follow.
9. Verify identities.
10. Require on-disk A and B equal their generated bytes.
11. Independently reproject complete terminal closure.
12. Require reprojection equals A and B.
13. Require no empty directory.
14. Require no cache or bytecode.
15. Require all modes, links, and types exact.
16. Perform no filesystem write after closure.

The final inline response may inspect the sealed root read-only.

No verdict or confirmation file may be written after terminal closure.

──────────────────────────────────────────────────────────────────────────────
17. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

TARGET_AUDIT_HARNESS_PACKAGE_METADATA_REPAIR_READY

only when every requirement from the preceding metadata-repair task passes,
plus:

- process-provenance gate passes;
- no prior retry tool was used;
- all Python invocations are pinned and isolated;
- qualification-polarity matrix passes;
- `payload_imported:false` is correctly converted into the positive assertion
  `payload_imported_is_false:true`;
- current qualification aggregate passes;
- all current process records are complete.

Return:

TARGET_AUDIT_HARNESS_PACKAGE_METADATA_REPAIR_BLOCKED

when:

- a semantic export or acceptance rule must change;
- current qualification fails for a genuine package reason;
- metadata coherence cannot close;
- the repair requires wider authority.

Return:

PREFLIGHT_PROVENANCE_MISMATCH

for:

- any historical tooling reuse;
- any unpinned Python process;
- any Python process missing exact `-I -S -B`;
- incomplete process ledger;
- supplied-root mutation;
- closing inequality;
- source-authority mismatch;
- unauthorized semantic drift;
- frozen-export mismatch;
- terminal closure failure;
- write after terminal closure.

──────────────────────────────────────────────────────────────────────────────
18. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return the complete inline report required by the preceding metadata-repair
task.

Add these sections near the beginning:

A. Historical failed-retry disposition

- both failed retry roots;
- exact roots opened;
- files inspected;
- confirmation no tool was executed, imported, compiled, or copied.

B. Process-provenance gate

- executable-origin registry identity;
- every permitted executable origin;
- every forbidden origin;
- process-provenance result.

C. Python invocation ledger

- complete ordinal list;
- exact executable;
- flags;
- source;
- cwd;
- environment;
- exit;
- cache posture;
- cleanup.

D. Qualification polarity

- raw `payload_imported` value;
- positive assertion value;
- aggregation rule;
- ten-case polarity matrix;
- first blocker or success.

E. Corrected identity provenance

- malformed historical digest;
- corrected digest;
- manifest A row;
- manifest B row;
- independent observation;
- correction-record identity.

Required additional confirmations:

PRIOR_FAILED_RETRY_ROOT_MUTATION_NOT_PERFORMED
LATEST_FAILED_RETRY_ROOT_MUTATION_NOT_PERFORMED
PRIOR_FAILED_RETRY_ROOT_NOT_RESUMED
LATEST_FAILED_RETRY_ROOT_NOT_RESUMED
NO_HISTORICAL_RETRY_TOOLING_EXECUTED
NO_HISTORICAL_RETRY_TOOLING_IMPORTED
NO_HISTORICAL_RETRY_OUTPUT_PROMOTED
FRESH_CONSTRUCTION_TOOLING_RETAINED_AND_HASH_BOUND
EXECUTABLE_ORIGIN_REGISTRY_COMPLETE
COMPLETE_PYTHON_PROCESS_LEDGER_RETAINED
ALL_PYTHON_INVOCATIONS_USED_PINNED_INTERPRETER
ALL_PYTHON_INVOCATIONS_USED_LITERAL_I_S_B
NO_UNREGISTERED_PYTHON_PROCESS
NO_PACKAGE_LOCAL_PYTHON_CACHE
QUALIFICATION_RAW_POSTURE_SEPARATE_FROM_ASSERTIONS
PAYLOAD_IMPORTED_RAW_FALSE_PRESERVED
PAYLOAD_IMPORTED_IS_FALSE_ASSERTION_TRUE
RAW_FALSE_NOT_AGGREGATED_AS_FAILED_CHECK
QUALIFICATION_POLARITY_MATRIX_PASSED
PROCESS_PROVENANCE_PRESEAL_GATE_PASSED
CORRECTED_DIGEST_AUTHENTICATED_FRESHLY
```

Do not create another reconciliation tranche before this fresh retry unless the
new process-provenance gate finds an additional concrete fixed-input conflict.

## Decision

Retry the metadata-repair package task from the sealed predecessor in a new root. Do not use any code or partial output from `...-h5f09wc4` or `...-u3ey9kca`.

**Source:** Codex’s latest `PREFLIGHT_PROVENANCE_MISMATCH` report.  
**Confidence:** 1.00 that the attempt is nonqualifying; 0.995 that no package or target semantic repair is authorized; 0.98 that a process-clean retry with corrected qualification polarity is the narrowest valid next step.
