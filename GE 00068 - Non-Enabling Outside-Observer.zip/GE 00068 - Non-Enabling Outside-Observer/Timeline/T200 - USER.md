Here is Codex's response:

# Record custody reconnaissance

## 1. Verdict

**RECORD_CUSTODY_RECONNAISSANCE_READY**

Select **Model C, atomic bundle-parent publication**, with **Model E, trusted stable destination ancestry, as an explicit supported-local precondition**. This is a design decision for a future implementation, not approval of the blocked v3 caller. If output ancestry can be renamed by an in-scope concurrent actor, this verdict no longer applies and implementation must block.

## 2. Pre-epoch disclosure

I read the request attachment with cwd explicitly set to `/Users/ds/Downloads` before opening provenance. An initial administrative checker failed while parsing its own output; a corrected read-only checker passed before the reconnaissance root was allocated. Neither attempt changed a supplied root.

## 3. Opening and closing identities

Opening and [closing provenance](/Users/ds/Downloads/ES-evidence-verification-v1-record-custody-reconnaissance-fg101qmu/closing_provenance.json) matched:

| Input | Frozen identity confirmed |
| --- | --- |
| Repository | Branch `codex/evidence-verification-v1`; HEAD `567bceced5df95ecfe787cc66038d463a854e12c`; tree `b7cab23732572c2aaea9d5f2f1593338e2e75338`; sole parent `05dde14d185b6e022dcc169ef1a658a97961850f`; no upstream |
| Governed repository objects | 477 exact rows; canonical manifest SHA-256 `4a3a42441632725c12dedbb13d6ab619f2b42677dde12a80c6efcc3025518537`; tracked `git diff --binary --full-index HEAD` SHA-256 `b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb`; status unchanged |
| Repair root | 183 files and 10 directories; inventory SHA-256 `6435c3e446ee9a7249de0ff6a6e640b4d1613208d5b67f6198b92b4020bdde7c`; both canonical manifest hashes `58b1f0fe386be8fafd3d073a80b99bd9ae3191f0547f40ce8967ccf18669fc00` |
| Current successor, base, delta | SHA-256 respectively `3c06a1c8dae17ba1a8f21fa50fde8b9dea9b4a5c274c740b761774c60bedc631`, `c24d79991539a1aa638480c45e7b3af86d8ea5f04134b7222da76f0e1bb91d24`, `a9f1f7d3ec09317126b575ade443fe89e7b9a7d31db7a0466d63c452e0bd3bd2` |
| Blocking audit | Its `final_inventory.json` SHA-256 `267d6df463bc09e65babd312faab1441d2516227e10241b24b38f710d6778296`; all 108 self-excluded inventory rows matched |
| Verifier | 40,121 bytes; SHA-256 `bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c` |
| Pinned Python | Python 3.13.4; 119,424 bytes; SHA-256 `f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b` |

The closing checker compared the governed repository rows, repair manifest rows, audit inventory rows, Git identity and status, and pinned bytes. All checks passed. Git calls used `git -C` with the required explicit environment and repository cwd.

## 4. Fresh reconnaissance-root identity

The atomically allocated, source-external root is [record-custody-reconnaissance-fg101qmu](/Users/ds/Downloads/ES-evidence-verification-v1-record-custody-reconnaissance-fg101qmu/final_inventory.json). Its direct root is owned by the current user, mode `0700`, device `16777234`, inode `177425789`. Its final self-excluded inventory records **15 files and 7 directories**, all private; the inventory SHA-256 is `70fe43eb8432eaac6aa6c8d0630bb9a97d404d2098235fdbb091bc950eb19c15`. `tmp/` and all probe fixture directories are empty.

## 5. Four auditor identities, schedule, operands, and status

Three read-only perspectives started concurrently after opening provenance: `/root/darwin_vfs_auditor`, `/root/contract_version_auditor`, and `/root/threat_custody_auditor`. `/root/migration_evidence_auditor` started after the Darwin auditor completed. All four completed; none delegated further. Their operands and conclusions are retained in [auditors_summary.md](/Users/ds/Downloads/ES-evidence-verification-v1-record-custody-reconnaissance-fg101qmu/auditors_summary.md).

They inspected the frozen caller, qualifying audit causals, and relevant `PLANS.md` and `.docs/` pages. The migration auditor inspected the named compatibility and validation records. The Darwin auditor also read the request attachment as an administrative, read-only operand. The shared conclusion was that C publishes the three files together, while **C alone cannot promise continuing lexical-path custody**.

## 6. Frozen audit finding

The qualifying audit remains **BLOCK**. Its [displacement causal](/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-independent-audit-58b1f0fe386b-mib0s7im/displacement_causal.json) moved held directory inode `177420060`, installed replacement inode `177420067`, and left accepted JSON and sidecars, including record inode `177420066`, in the moved original. The declared `--record` pathname was absent. Nevertheless, `main()` returned `0`, shared stdout reported acceptance, and the verifier exited `0`.

## 7. Why finite file-level rechecks fail

A check establishes a pathname relationship only when it runs. A rename can follow the last check and precede a descriptor-relative file commit. Checking after commit cannot undo the interval in which accepted bytes were visible; unlink or rollback can also target a changed name. Repetition narrows a window but never closes it.

## 8. Model A — More checks

**Rejected.** Precommit rebinds leave a final gap. A postcommit rebind can fail after publication, so making its result an acceptance gate would contradict already visible evidence. The [postcommit probe](/Users/ds/Downloads/ES-evidence-verification-v1-record-custody-reconnaissance-fg101qmu/rename_models_probe.json) reproduced that ordering.

## 9. Model B — Root-relative final-file rename

**Rejected for this contract.** A root-relative destination can put JSON at the declared pathname while sidecars written through a held directory remain in its moved original. The probe observed exactly that split. Three separate file renames would have three commit points.

## 10. Model C — Atomic bundle-parent publication

**Selected as the primary mechanism.** Interpret the immediate parent of `--record` as one invocation bundle directory. It must be absent initially. Prepare a private, mode `0700` sibling stage directory in an admitted existing grandparent, containing exactly the JSON, stdout, and stderr files at mode `0600`. Validate and sync the complete stage before one exclusive directory rename. Resolve both stage and destination from a root descriptor using full root-relative paths at commit.

The future caller must behaviorally prove the required directory-rename capability on the actual output filesystem before building accepted evidence. A successful rename publishes one directory object and its three children together. It does **not**, by itself, defend a lexical path against an actor moving an ancestor during or after lookup.

## 11. Model D — Directory-object custody

**Rejected.** It would make `--record` an opening locator rather than a continuing JSON pathname. Once descriptors close, inode identity alone gives a consumer no durable locator. Current shared stdout supplies only a `record_role` basename, and v3 fields cannot honestly express moved-directory custody. Selecting D would weaken the requested record-path contract.

## 12. Model E — Trusted stable destination ancestry

**Adopted explicitly as C’s precondition, not as another publication operation.** The current [trusted-host contract](/Users/ds/Repositories/Execution%20Substrate%20-%20evidence-verification-v1/.docs/system_overview/evidence_verification.md) covers interpreter installation ancestry, but not output ancestry. Future governing documentation must expand that bounded supported-local premise to the selected output namespace and every principal able to rename its components.

The operator must place the output root in a physical, source-external, operator-owned namespace; admit an existing mode `0700` grandparent; reject symlinks, uncertain ownership or modes, and containment with target, package, candidate, TMPDIR, or caller-source custody. Every actor able to rename the stage, bundle, grandparent, or mutable ancestors must be trusted and must leave them stable from preflight through consumer opening. A shared, adversarial, remotely administered, or uncertain host is unsupported. This is a material documented trust decision. It must not be described as a race-proof kernel mechanism or as satisfying an in-scope concurrent ancestry-mover test.

## 13. Model F — Dedicated writer or native helper

**Not selected.** It would add a new source/binary owner, build and launch provenance, and potentially host privilege. It cannot itself prevent a privileged principal from later renaming an ancestor. C with the explicit supported-local placement premise is proportionate to this evidence-only slice; a wider hostile-writer requirement would require a separate governance decision.

## 14. Exact probes and results

The pinned Python ran audit-owned [rename probe source](/Users/ds/Downloads/ES-evidence-verification-v1-record-custody-reconnaissance-fg101qmu/rename_models_probe.py) and [results](/Users/ds/Downloads/ES-evidence-verification-v1-record-custody-reconnaissance-fg101qmu/rename_models_probe.json). Each result retains argv, environment, object identities, and cleanup.

| Required case | Observation |
| --- | --- |
| 1. Held descriptor after parent move | Exclusive rename succeeded into the moved original; declared final path absent. |
| 2. Held source, root-relative final file | JSON reached the replacement path; both sidecars remained in the moved original. |
| 3. Both names root-relative after move | Rename failed `ENOENT`; stage remained in the moved original. |
| 4. Complete three-file directory | One exclusive rename succeeded; stage/final directory inode matched, stage name disappeared, three mode `0600` children appeared together under mode `0700` final directory. |
| 5. Grandparent moved and replaced before commit | Rename failed `ENOENT`; declared final absent. |
| 6. Move synchronized during commit | Thread and fork races produced successful renames followed by moved ancestry. None identifies the exact order of ancestor rename and kernel rename linearization. |
| 7. Arbitrary foreign final bundle | `EEXIST`; foreign bytes and identity unchanged; stage retained. |
| 8. Accepted-looking foreign bundle | `EEXIST` with the same preservation; its JSON was not attributable to this caller. |
| 9. Same-basename retry after success | `EEXIST`; first final bundle unchanged; second stage retained. |
| 10. Partial stage and retry | Precommit `BUNDLE_INCOMPLETE`; a deterministic reused stage name gave `STAGE_EXISTS`. Future attempts therefore need distinct private stage names and explicit failed-stage treatment. |
| 11. Declared path at commit observation | With stable ancestry, successful atomic rename makes the bundle available at the declared JSON path; the probe directly observed that path and matching inode at return. The kernel linearization instant was inferred from rename semantics, not directly sampled. |
| 12. Postcommit check | Accepted bytes were visible before an ancestor move made the declared path absent. A subsequent check could fail but could not revoke that visibility. |

Additional bounded race sources and results are retained for [thread, 500 trials](/Users/ds/Downloads/ES-evidence-verification-v1-record-custody-reconnaissance-fg101qmu/grandparent_race_probe.json), [fork, 300 trials](/Users/ds/Downloads/ES-evidence-verification-v1-record-custody-reconnaissance-fg101qmu/grandparent_fork_race_probe.json), [deep-path fork, 300 trials](/Users/ds/Downloads/ES-evidence-verification-v1-record-custody-reconnaissance-fg101qmu/grandparent_fork_race_deep_probe.json), and [parent-delay fork, 700 trials](/Users/ds/Downloads/ES-evidence-verification-v1-record-custody-reconnaissance-fg101qmu/grandparent_fork_race_parentdelay_probe.json). Each reported `success/moved` after joining the mover. Call-interval timestamps do not prove whether the move preceded the rename’s kernel linearization. The selected design does not depend on that unproved interleaving because it excludes concurrent output-ancestry movers through its explicit trust precondition.

## 15. Threat model

Target content, pre-seal candidate content, target-controlled script paths, unproven package inputs, and out-of-contract arguments remain untrusted. Their changes must fail existing validation gates. A foreign final bundle may already exist or race to occupy the final name; exclusive rename must fail without attributing it to this caller.

The foreground process, pinned interpreter installation and its writers, kernel/process substrate, output namespace and every actor able to rename its stage, bundle, or ancestors are trusted supported-local preconditions. No untrusted actor may mutate the stage or move output ancestry during the custody interval. Same-UID or privileged actors with such rename authority are inside that trusted boundary; if they are adversarial or uncoordinated, the host is unsupported. Trusted mutation after the bounded custody interval, privileged compromise, and kernel/process compromise are outside the guarantee. No indefinite pathname stability or crash durability is claimed.

## 16. Selected primary model

**Model C**, conditional on the separately stated **Model E** host and placement premise. The contract is a `Bounded slice rule` for source-external evidence/projection. It changes no ES product, runtime, public, admission, orchestration, or readiness authority. This is the smallest design that gives the three outputs one publication event while retaining `--record` as a JSON pathname.

## 17. Automatic fallback

There is **no automatic fallback** to file-level publication, inode custody, another path, a copied record, `/dev/fd`, a native launcher, or a privileged helper. Failure to prove placement, capability, or stable-host posture blocks the attempt.

## 18. Exact commit point

The sole accepted-record commit point is a successful `renameatx_np(RENAME_EXCL)` of the **complete stage directory** to the initially absent bundle-parent name, using full root-relative source and destination paths. All potentially rejecting checks, file writes, file and stage-directory fsyncs, descriptor closes that could change the outcome, content verification, containment checks, and capability validation occur before it. Afterward, only non-gating cleanup, best-effort shared-stdout projection, and the already determined return remain. A postcommit fsync is not made an acceptance gate; power-loss durability is outside this online custody claim.

## 19. Exact pathname and object guarantee

Let `--record=$OUTPUT_ROOT/records/$BUNDLE_ID/$NAME.json`. `$OUTPUT_ROOT/records` exists and is admitted; `$BUNDLE_ID` does not exist at preflight. Under stable ancestry, successful commit makes that exact JSON pathname resolve within the renamed stage directory object, alongside `$NAME.stdout` and `$NAME.stderr`. The directory and its three children keep their staged inode identities. No other public output file is part of this invocation bundle.

A consumer opens the **declared absolute JSON path**, verifies the complete bundle, modes, file identities and sidecar sizes/hashes, canonical v4 schema, and independent source/launch/provenance evidence. An accepted-looking stage or foreign final bundle is insufficient. Trusted mutation after consumer opening ends the bounded pathname guarantee.

## 20. Version and schema decision

The caller-record schema becomes **`execution-substrate.evidence-closure-launch-record.v4`**. `--record` remains the JSON pathname, but its immediate parent is now an initially absent bundle directory. The three filenames remain `$NAME.json`, `$NAME.stdout`, and `$NAME.stderr`. Shared stdout retains exactly `errors`, `exit`, `outcome`, and `record_role`, where `record_role` is the JSON basename; it remains a projection.

Launch protocol **`execution-substrate.evidence-closure-launch/v2`** stays because verifier source-by-value transport and `-I -S -B -c` argv semantics do not change. The verifier tool, result schema, and bytes remain v1 and byte-identical. The private normative trusted-host contract should be revised from v1 to **`execution-substrate.evidence-verification.trusted-host-contract.v2`** to name output ancestry and its writers.

The v4 JSON retains these **exact 25 top-level fields**: `argv_shape`, `argv_shape_sha256`, `atomic_loaded_object_binding`, `candidate`, `environment`, `errors`, `exit`, `interpreter`, `interpreter_trust_model`, `launch_protocol`, `layout_expected_sha256`, `outcome`, `package_root`, `registry_expected_sha256`, `schema`, `shared_or_adversarial_host_supported`, `snapshots`, `source`, `stderr_sha256`, `stderr_size`, `stdout_sha256`, `stdout_size`, `target`, `transient_trusted_principal_replacement_covered`, and `verifier_child_launched`. `schema` changes literal value; `outcome=accepted` gains the explicit bundle-publication and custody meaning. The interpreter-specific trust-model field retains its existing meaning.

## 21. Compatibility and migration

Existing v3 caller records, A6D records, and amendment records remain immutable historical compatibility evidence. They do not acquire v4 pathname-custody status. The blocked successor is a superseded negative regression fixture and no qualifying fallback. Label it a `Temporary compatibility edge` only if an active legacy execution route is deliberately retained, with its scope and removal condition documented; mere retention as an inert fixture does not create that active edge.

## 22. Exact future touched-file set

No file was changed for implementation in this turn. The proposed future repository edits are limited to existing [PLANS.md](/Users/ds/Repositories/Execution%20Substrate%20-%20evidence-verification-v1/PLANS.md), [.docs/system_overview/evidence_verification.md](/Users/ds/Repositories/Execution%20Substrate%20-%20evidence-verification-v1/.docs/system_overview/evidence_verification.md), [.docs/system_overview/capability_probing.md](/Users/ds/Repositories/Execution%20Substrate%20-%20evidence-verification-v1/.docs/system_overview/capability_probing.md), and [.docs/system_overview/artifact_hygiene.md](/Users/ds/Repositories/Execution%20Substrate%20-%20evidence-verification-v1/.docs/system_overview/artifact_hygiene.md). They respectively own redesign sequencing; normative custody/trust/version semantics; behavioral directory-rename capability; and private source-external evidence handling. No repository verifier, registry, layout, product, lifecycle, or new repository file is required by this design.

Atomically allocate a **new** repair root under Downloads for `source/base_v3_exact.py`, `source/launch_v4_trusted_host_atomic_bundle.py`, `provenance/source-delta.diff`, causal and compatibility test sources under `tests/`, results under `causals/` and `validation/`, and canonical provenance manifests and closeout records. Allocate a separate sibling mode `0700` output root with an existing mode `0700` `records/` grandparent. Invocation bundle parents under it begin absent. The two roots stay physically disjoint to preserve caller-evidence containment. Exact old and new bytes, test sources, failed/superseded attempt index, inventories, and two reproducible manifest runs must be sealed; a fresh independent audit gets both roots and the exact source delta. Failed stages remain explicitly nonqualifying and must not be silently reused.

## 23. Complete future causal matrix

For every failure below: require **no caller-attributed final bundle, no accepted shared projection, and an explicit failure or indeterminate record outside the claimed final path**. For every success: require a v4 accepted bundle at the declared path, three matching sidecars/files, independent provenance, and no extra public output.

| Case | Required outcome and acceptance evidence |
| --- | --- |
| Valid commit | One exclusive directory rename; stage/final inode identity; exact three files, `0700`/`0600`; declared JSON path resolves. |
| Target, package, candidate, TMPDIR, caller-evidence, interpreter, output containment | Each overlap or alias blocks before commit; no final bundle attributed to caller. |
| Held parent displaced before final validation | Block; no accepted projection. |
| Grandparent displaced before syscall | Root-relative source lookup fails or validation blocks; no final bundle. |
| Ancestor displaced during syscall | Treat as unsupported-host violation; causal must show whether a success can lose the lexical path and must never be claimed as in-scope success. |
| Ancestor displaced after commit | Demonstrate bounded trust limit; no rollback or postcommit downgrade claim. |
| Arbitrary and canonical accepted-looking foreign bundle | `EEXIST`, unchanged foreign inode/bytes; no attribution to this invocation. |
| Output count and co-location | Exactly JSON, stdout, stderr in the one bundle; no split outputs. |
| Short/partial writes and precommit fsync faults | Block before rename; retained or cleaned stage explicitly indexed; no final bundle. |
| Partial bundle construction | Reject before rename; a fresh stage permits same-basename retry. |
| Capability failure | Fail fast at validation boundary; no OS-label branch or fallback. |
| Retry after every failure | Fresh private stage; existing foreign final untouched; accepted result only on a later successful exclusive rename. |
| Retry after success | `EEXIST`; first accepted bundle unchanged. |
| Normal execution hooks | Internal race/snapshot hooks unreachable from normal caller invocation. |
| Depth and snapshot regression | Existing bounds and repeated-observation decisions unchanged. |
| Schema and redaction | Exact v4 keys, canonical encoding and hashes; no secret/source-text leak in shared projection. |
| A6D and amendment | Two read-only runs each; v3 remains compatibility evidence only. |
| Synthetic A6 | Two pre-seal and two sealed runs; verifier behavior and hashes unchanged. |
| SEC-02 | Source-by-value v2 launch and hostile script-path negatives remain enforced. |
| Supplied-root integrity | Opening and closing identities, inventories, status, source and verifier hashes match. |
| Process and descriptor cleanup | No child/process survivor; all owned descriptors closed; only indexed failed evidence remains. |
| Independent audit | Fresh auditor independently checks source, docs, causals, provenance, and final output custody before any readiness claim. |

## 24. Future implementation and audit sequence

First record the scope and private trusted-host v2 decision in `PLANS.md` and authoritative `.docs/`. Then write the v4 causal and compatibility tests, implement the external successor, run capability and full matrix validation on fresh roots, produce exact old/new source and inventory provenance, and obtain a fresh independent audit. Do not resume or reinterpret the existing BLOCK audit. Repository Git or later A6 work follows only a separate closeout decision.

## 25. Mandatory stop conditions

The future attempt must block if stable output ancestry and all renamers cannot be established; placement or ownership is uncertain; the actual filesystem lacks proved exclusive directory rename; a stage or final name is ambiguous; three files cannot be committed as one directory; any postcommit operation can downgrade acceptance; the v4 or trusted-host v2 change is omitted; verifier or product authority must change; or tests admit an in-scope ancestor mover that can make an accepted declared path disappear. C alone does not pass these conditions.

## 26. Inspection limits and uncertainty

The race probes demonstrate the hazard but do not timestamp kernel linearization relative to ancestor movement. The selected contract relies on **explicitly stable ancestry**, not an unproved claim about that interleaving. The directory probe established observed rename, collision, identity, and co-location behavior on this host; the future caller must re-probe its actual output filesystem. No future implementation, complete validation run, independent v4 audit, crash recovery, or indefinite path custody is claimed here.

## 27. Reconnaissance-created paths and cleanup

Only the [fresh reconnaissance root](/Users/ds/Downloads/ES-evidence-verification-v1-record-custody-reconnaissance-fg101qmu/final_inventory.json) was created. It contains five probe `.py` sources and five matching `.json` results, [auditor summary](/Users/ds/Downloads/ES-evidence-verification-v1-record-custody-reconnaissance-fg101qmu/auditors_summary.md), [decision record](/Users/ds/Downloads/ES-evidence-verification-v1-record-custody-reconnaissance-fg101qmu/design_decision.json), [closing checker](/Users/ds/Downloads/ES-evidence-verification-v1-record-custody-reconnaissance-fg101qmu/closing_check.py), closing provenance, and final inventory. Probe fixture directories and `tmp/` are empty. No probe-process survivor was observed. The evidence files are retained for review; no supplied-root cleanup occurred.

## 28. Explicit confirmations

- Repository mutation: **not performed**.
- Supplied-evidence mutation: **not performed**.
- Implementation: **not performed**.
- Git staging: **not performed**.
- Commit: **not performed**.
- Push: **not performed**.
- A6 restart: **not performed**.
- Product or live-service invocation: **not performed**.
- Network contact: **not performed**.
- Nested subagents: **not created**.
