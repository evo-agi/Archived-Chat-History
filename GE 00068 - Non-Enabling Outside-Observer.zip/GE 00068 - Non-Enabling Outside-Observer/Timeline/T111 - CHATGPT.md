## Verdict

This is the hard stop we intentionally installed. **Do not create another verifier amendment. Do not retry A6.**

A6V establishes that the current target-specific verifier architecture cannot bootstrap a new target safely:

- The smallest code change would be one closed A6 target kind.
- The already sealed verifier can verify the first amendment only at that amendment’s exact path.
- Its fixture mode is confined inside the immutable amendment.
- A separate extension cannot be sealed by an already trusted verifier.
- Continuing would require another verifier layer, violating the one-layer limit.

This is no longer a local Repair 10I defect. It is an **evidence-verification architecture failure**.

The project explicitly says proof harnesses must not become architecture or authority, and generated evidence remains non-authoritative.  Milestone 0 exists specifically to prevent the MVP from becoming “whatever the current proof harness happens to do.”  That is now the material risk.

## Strategic correction

Retire the target-specific, self-sealing verifier chain for future work. Replace it with a non-recursive model:

```text
versioned verifier source outside the evidence child
        +
closed, versioned layout specification
        +
evidence manifest and detached digest
        ↓
producer runs verifier twice
        ↓
fresh auditor receives the exact verifier source and reruns it independently
```

The evidence child must not contain the only verifier capable of qualifying itself. The verifier must not require its own evidence container to be verified first.

This is already the project’s normal provenance model: preserve the exact recipe source, run it deterministically, then have the independent audit rerun the exact source against the same bytes.  The guidance also warns against letting provenance ceremony obscure the actual architectural risk. 

The responsibilities should separate cleanly:

| Concern | Owner |
|---|---|
| Manifest byte closure, modes, hashes, links, no extras | External versioned verifier |
| Expected target layout | Closed versioned layout specification |
| Validation success and comparison policy | Closeout adjudicator and later independent audit |
| Tool identity | Exact source bytes plus Git/provenance or a separately audited tool package |
| Runtime/product authority | Never the verifier or evidence child |

A verifier may prove that an evidence package is byte-exact. It must not decide whether Repair 10I is correct, ready, or authoritative.

## Current artifact disposition

- **A6D original child:** sealed historical implementation/validation evidence.
- **A6D verifier amendment:** sealed historical evidence that repaired A6D’s packaged-verifier defect.
- **A6V:** unsealed read-only reconnaissance; sufficient to establish the architectural blocker.
- **All failed A6 children:** remain immutable and unsealed.
- **Repository candidate:** unchanged.
- **A6D successor source and binaries:** not rejected by A6V; they remain candidate inputs, but no fresh A6 may start until the replacement verifier architecture is frozen, implemented, validated, and independently audited.

No existing artifact should be modified or retroactively promoted.

## Next tranche

Start a separate read-only evidence-architecture reset. This should not be framed as Repair 10I-A6V2 or another verifier patch.

### Codex prompt: non-recursive evidence verification architecture reset

```text
Objective

Perform a parent-only, read-only architecture reset for Governed Execution
evidence verification.

The current Repair 10I target-specific verifier chain has reached its hard
anti-recursion stop:

- original A6D evidence child was sealed with a defective packaged verifier;
- one separately sealed amendment corrected A6D verification;
- the corrected verifier admits only closed target kinds;
- a new A6 evidence child needs a new closed target kind;
- the already sealed verifier cannot verify a separate target-extension child;
- another verifier-amendment layer is prohibited;
- A6V returned REPAIR10I_A6V_RECONNAISSANCE_BLOCKED.

Freeze a durable, non-recursive replacement that can serve Repair 10I and
future sensitive Governed Execution evidence without allowing proof tooling to
become product, orchestration, runtime, or readiness authority.

Do not implement anything in this turn.

Do not modify any repository.
Do not modify, resume, seal, or delete any evidence child.
Do not run product tests, source controls, comparisons, builds, or A/B.
Do not start or resume A6.
Do not stage, commit, push, install, invoke live services, contact networks, or
execute Linux binaries.

No subagents. You are the sole operator.

## Inputs

Candidate repository, read-only:

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Project guidance:

- Governed Execution Provenance Guidance
- Governed Execution Codex Subagent Operating Protocol
- Milestone 0 MVP Claim Freeze

Original A6D implementation child:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

Original A6D manifest:

dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9

A6D verifier amendment:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

Amendment manifest:

a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e

Blocked A6V reconnaissance:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6v-evidence-target-recon-8de797304ea9

Current failed A6 child:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a6d-8de797304ea9

## 1. Baseline and no-mutation gate

Require exact candidate identity:

- physical root:
  /Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1
- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- upstream:
  absent
- index SHA-256:
  012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31
- source T:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- inventory:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2
- membership:
  389 / 375 / 14
- staged/deleted/renamed/unmerged:
  0/0/0/0.

Use explicitly rooted Git commands only.

Require A6D and the amendment to reproduce their exact manifests and remain
unchanged.

Require A6V and every failed A6 child to remain unsealed and byte-exact.

Create no evidence child for this reconnaissance. Return findings in stdout
only.

## 2. Recover the current verifier architecture

Inspect:

- original A6D packaged verifier;
- corrected amendment verifier;
- closing/layout helper;
- fixture and target-kind tests;
- A6V report and six-rejection matrix;
- original and amendment manifests;
- joint-qualification record.

Map precisely:

1. Generic manifest/path/type/mode/size/hash/link verification.
2. Target-kind dispatch.
3. Target-layout assertions.
4. Pre-seal versus sealed checks.
5. Readiness or closeout assertions.
6. Tool-bootstrap and path-binding assumptions.
7. Which parts are reusable.
8. Which parts caused recursive amendments.
9. Which claims belong to verification versus validation/adjudication.

## 3. Freeze the authority split

The replacement must enforce:

### External verifier owns only byte closure

It may verify:

- manifest syntax and canonical form;
- detached digest;
- exact path set;
- type;
- mode;
- size;
- SHA-256;
- link count;
- directory modes;
- symlink/special-file prohibition;
- no unexpected governed payload;
- no post-manifest mutation;
- exact versioned layout specification identity.

It must not decide:

- whether tests passed;
- whether a comparison is acceptable;
- whether a repair is correct;
- whether a historical policy is safe;
- whether the evidence is product or runtime authority;
- whether a tranche is ready to commit.

### Layout specification owns structure only

It may define:

- target-kind identifier;
- required top-level directories;
- required fixed records;
- permitted bounded optional locations;
- pre-seal and sealed posture;
- mode and type rules.

It must not be caller-controlled at runtime.

A target layout is admitted only by an exact versioned spec identity already
known to the verifier package or separately exact-bound by owning source.

### Closeout adjudication owns readiness claims

It consumes validation and comparison evidence, but its output is evidence
only and is independently recomputed by a later audit.

## 4. Select the non-recursive bootstrap model

Evaluate:

### Model A — committed verifier source

One versioned verifier and its closed layout specifications live in a durable
repository path and are bound by Git/provenance.

Evidence children reference:

- verifier version;
- verifier source SHA-256;
- layout-spec ID and SHA-256.

The verifier does not verify its own repository or evidence container.

### Model B — exact source supplied to each tranche and audit

The exact verifier source is carried as an audit input, run twice by the
producer and independently rerun by the auditor.

It remains outside the evidence child.

### Model C — separately audited standalone tool package

The verifier and layout specifications are implemented and independently
audited once, then referenced by exact package/source identity.

### Model D — verifier embedded in each evidence child

Reject.

### Model E — target-specific amendment chain

Reject.

### Model F — caller-supplied arbitrary layout

Reject.

Select one primary model and, where useful, one bounded bootstrap model before
the verifier is committed.

The selected design must require no self-verification and no future amendment
layer merely to admit another closed target layout.

## 5. Determine durable placement

Evaluate exact placement options:

1. ES-local durable tooling, such as:
   tools/evidence_verify/
2. project-level cross-repository provenance tooling;
3. source-external exact tool source carried with prompts.

Classify:

- current owner;
- authority;
- consumers;
- versioning;
- migration cost;
- cross-repo implications.

Do not create a cross-repository framework merely because the problem is
generic. Prefer the narrowest durable owner that can meet current needs.

Freeze the exact intended placement or return blocked.

## 6. Freeze verifier and layout-spec contracts

Define:

- verifier tool ID;
- verifier source layout;
- layout-spec schema;
- canonical encoding;
- admitted target-kind registration;
- pre-seal invocation;
- sealed invocation;
- canonical output;
- exit codes;
- no-write requirement;
- deterministic environment;
- exact error classes;
- strict unknown-target rejection.

The verifier must accept a new closed layout version without requiring a new
verifier binary when the layout schema semantics are unchanged.

Adding a layout specification must itself go through ordinary source
implementation, validation, provenance, and independent audit—not a
self-sealing amendment.

## 7. Current Repair 10I migration

Freeze the disposition of:

- original A6D child;
- A6D amendment;
- A6V report;
- failed A6 children;
- A6D successor source and binaries.

Determine whether future A6 may:

1. use the existing exact A6D successor source/binaries;
2. verify A6D and the future A6 child using the replacement external verifier;
3. treat the original target-specific verifiers as historical regression
   fixtures only.

Do not require a successor rebuild unless exact source/binary evidence is
insufficient.

The new A6 child must be fresh. No failed A6 child may be resumed.

## 8. Required causal matrix

Freeze tests for:

1. valid generic pre-seal closure;
2. valid generic sealed closure;
3. missing manifest;
4. missing sidecar;
5. wrong sidecar;
6. missing payload;
7. unexpected payload;
8. wrong mode;
9. wrong size;
10. wrong hash;
11. wrong link count;
12. directory-mode mismatch;
13. symlink;
14. special file;
15. post-manifest mutation;
16. unknown layout spec;
17. wrong layout-spec hash;
18. missing required layout entry;
19. unexpected layout entry;
20. pre-seal/sealed stage confusion;
21. caller-supplied arbitrary layout rejected;
22. readiness content is not interpreted;
23. verifier performs zero writes;
24. repeated canonical output is byte-identical;
25. verifier source does not reside under or depend on the target evidence
    child;
26. verifier does not verify its own container;
27. producer and fresh auditor independently reproduce the same result;
28. original target-specific verifier defects remain regression fixtures;
29. no recursive amendment is required to add a new closed layout spec;
30. exact source and layout identities are retained in the evidence closeout.

## 9. Implementation and audit sequence

Freeze:

1. read-only architecture decision;
2. one bounded verifier implementation tranche;
3. exact unit/fixture/determinism validation;
4. exact provenance;
5. fresh independent audit of verifier source and layout-spec semantics;
6. only after audit acceptance, fresh A6 restart;
7. fresh A6 uses the audited verifier and exact A6 layout spec;
8. future A6 evidence receives its own later independent audit.

The verifier implementation audit must not audit Repair 10I product behavior.

## 10. Stop conditions

Return blocked if:

- the verifier must verify its own evidence container;
- another amendment layer is required;
- verifier and readiness adjudication cannot be separated;
- caller-controlled layouts are required;
- durable placement cannot be assigned;
- source or schema scope remains open;
- adding a target kind still requires verifier-code modification without a
  semantic reason;
- repository or public product contracts would need to change;
- a cross-repository framework is required before a narrow ES-owned tool can
  work.

## 11. Verdicts

Return exactly one:

EVIDENCE_VERIFICATION_ARCHITECTURE_RESET_READY

Use only when the authority split, non-recursive bootstrap, durable placement,
tool/spec contracts, migration, touched surfaces, tests, implementation
sequence, and audit sequence are completely frozen.

EVIDENCE_VERIFICATION_ARCHITECTURE_RESET_BLOCKED

Use when any of those remain unresolved.

## 12. Required report

Include:

1. Opening and closing identity.
2. Current verifier-chain mechanism and failure.
3. Authority classification.
4. Selected bootstrap model.
5. Selected durable placement.
6. Verifier contract.
7. Layout-spec contract.
8. Readiness/adjudication separation.
9. Current Repair 10I migration.
10. Exact future touched-file set.
11. Complete causal matrix.
12. Implementation sequence.
13. Independent-audit sequence.
14. Stop conditions.
15. Inspection limits and uncertainty.
16. Confirmation no repository or evidence mutation occurred.

No implementation.
No A6 restart.
No verifier amendment.
No B6.
No product A/B.
No snapshot.
No commit or publication.
```

## Critical path after the reset

1. Freeze the non-recursive model.
2. Implement the verifier as an ordinary bounded source tranche.
3. Independently audit that verifier.
4. Restart A6 once, from fresh controls.
5. Resume the Repair 10I path only after A6 completes.

No target-specific verifier patch should occur before that.

### Sources

- Codex’s `REPAIR10I_A6V_RECONNAISSANCE_BLOCKED` report supplied in this turn.
- The MVP claim freeze says proof harnesses do not define architecture and generated evidence is not authoritative. 
- Milestone 0 explicitly exists to prevent the MVP becoming whatever the proof harness happens to do. 
- The provenance lifecycle expects exact verifier/recipe source to be rerun independently rather than self-verified by its output container. 
- Project guidance warns against letting provenance ceremony obscure the architectural risk. 
- Implementation, repair, and independent audit remain separate engagements. 

**Confidence**

- Correctness of the A6V stop: **0.999**
- Classification as an evidence-architecture failure rather than a Repair 10I source defect: **0.995**
- Confidence that another verifier amendment would be the wrong next move: **0.999**
- Confidence in a non-recursive external-verifier model: **0.97**
- Confidence that existing A6D successor source/binaries can probably be retained through the reset: **0.91**
- Confidence that Repair 10I should remain paused until the verifier is separately implemented and audited: **0.999**
