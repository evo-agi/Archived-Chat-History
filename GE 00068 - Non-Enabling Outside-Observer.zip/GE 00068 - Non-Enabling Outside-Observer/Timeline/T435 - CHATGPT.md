## Engineering assessment

The latest result does **not** establish whether Candidate 2’s production parent is correct or defective.

What it establishes conclusively is narrower:

- The documentary-evidence single-writer repair worked.
- The one-writer and failure-custody specifications and matrices passed.
- All static, ownership, and component-regression lanes passed.
- Both rehearsal parents apparently completed.
- The independent rehearsal validator exited `1`.
- The qualification harness then destroyed indispensable evidence before retaining:
  - the validator’s stdout and exact error list;
  - its complete process ledger;
  - rehearsal B’s exact identity and inventory;
  - rehearsal B’s double-`ENOENT` cleanup proof.

That leaves two live possibilities:

1. **The production candidate or rehearsal outputs are actually defective**, and the independent validator correctly found errors.
2. **The independent validator or its invocation is defective**, while the rehearsals are sound.

Neither can be inferred from the retained capsule. A source repair now would be speculative.

The next tranche should therefore be a **source-external qualification replay of the exact Attempt 2 bytes, with no source edits**. It is not another source attempt, historical reconciliation, or subject reconstruction. Its only job is to recover the missing qualification truth under a minimal audit-owned supervisor that keeps both rehearsal roots intact until every process record, stream, result, inventory, and validation finding has been retained.

This replay must be terminal for Candidate 2:

- If both rehearsals and the independent validator pass, Candidate 2’s production source remains viable; the only confirmed defect is the historical qualification-harness custody path. The next task may repair that harness only.
- If the rehearsals contain independently confirmed defects, retire Candidate 2 and build a new clean parent from the frozen operating model and specifications.
- If the independent validator is the defect, repair only that validator and its qualification custody.
- If the replay itself again loses indispensable evidence, retire the entire Candidate 2 qualification lineage rather than attempting another recovery pass.

No current subject should be constructed, and no source should be patched, frozen, or promoted in this tranche.

```text
TERMINAL SOURCE-EXTERNAL QUALIFICATION REPLAY OF THE EXACT
CLEAN SCHEMA-SUBJECT RECONSTRUCTION-PARENT CANDIDATE

This task determines whether the exact second-attempt clean reconstruction
candidate is semantically sound, whether its independent rehearsal validator
is defective, or whether both are defective.

It performs no source repair.

It performs no current schema-subject construction.

It is not another historical provenance reconciliation.

The exact historical failure was:

- both rehearsal parents completed;
- the independent rehearsal validator exited `1`;
- validator stdout and exact errors were not retained;
- its complete process ledger was not retained;
- rehearsal B’s exact identity and inventory were not retained;
- rehearsal B’s exact double-ENOENT cleanup evidence was not retained;
- indispensable evidence was destroyed before qualification could be
  adjudicated;
- the result was `IMPLEMENTATION_PROVENANCE_MISMATCH`.

This replay must retain all indispensable evidence before any rehearsal root
is removed.

Do not:

- modify any supplied root;
- modify any production or qualification source;
- patch Candidate 2;
- create a third source attempt;
- change the normative contract;
- change any schema;
- change the 15-role or 14-family model;
- change any of the 946 or 137 cases or expected outcomes;
- construct the current schema subject;
- execute product process-self-test;
- execute product construct mode;
- construct a target-audit harness;
- run a target audit;
- rerun runtime validation;
- modify a repository;
- run Git;
- use the network;
- invoke product or live-service behavior;
- deploy, publish, externally commit, or start A6;
- create subagents or direct auditors.

Use one finite, source-external replay supervisor in one fresh replay-capsule
root.

The supervisor may construct exactly two disposable rehearsal subjects. It
must keep both roots intact until:

- both parent processes have complete custody;
- both roots have complete inventories;
- the independent validator has finished;
- its stdout, stderr, result, exit, signal, and process record are retained;
- an audit-owned adjudication has completed;
- every indispensable artifact has been copied or regenerated into the replay
  capsule.

Return the complete operative report inline.

Return exactly one primary verdict:

CLEAN_RECONSTRUCTION_PARENT_EXACT_REPLAY_PASSED_HARNESS_CUSTODY_DEFECT_ONLY

CLEAN_RECONSTRUCTION_PARENT_EXACT_REPLAY_BLOCKED_PRODUCTION_SOURCE_DEFECT

CLEAN_RECONSTRUCTION_PARENT_EXACT_REPLAY_BLOCKED_INDEPENDENT_VALIDATOR_DEFECT

CLEAN_RECONSTRUCTION_PARENT_EXACT_REPLAY_BLOCKED_MIXED_DEFECT

QUALIFICATION_REPLAY_PROVENANCE_MISMATCH

Also return exactly one mandatory next treatment:

BOUNDED_QUALIFICATION_HARNESS_CUSTODY_REPAIR

RETIRE_CANDIDATE_AND_BUILD_NEW_CLEAN_PARENT

BOUNDED_INDEPENDENT_VALIDATOR_REPAIR_AND_REQUALIFICATION

RETIRE_CANDIDATE_AND_REBUILD_PARENT_AND_VALIDATOR

RETIRE_CANDIDATE_QUALIFICATION_LINEAGE

──────────────────────────────────────────────────────────────────────────────
1. FAILED REPAIR PACKAGE — FIXED INVESTIGATIVE INPUT
──────────────────────────────────────────────────────────────────────────────

FAILED_REPAIR_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-clean-parent-evidence-ownership-repair-no81sk4_

Expected identity:

- device:
  16777234
- inode:
  180805755
- mode:
  0700
- retained verdict:
  IMPLEMENTATION_PROVENANCE_MISMATCH

Expected final report:

report/final-repair-failure-report-v1.json

- size:
  resolve and authenticate from the supplied root;
- SHA-256:
  4dc3f1098b5796c2a3707c49dfb39192294142fdcb1dee21ccc7b2b10e71bb61

Authenticate at minimum:

- bootstrap start;
- repair-input authentication;
- exact Attempt 2 source registries;
- source-attempt ledger;
- source delta;
- documentary-evidence lifecycle;
- writer registry;
- one-writer matrix;
- failure-custody contract and matrix;
- static and ownership results;
- component-regression results;
- documentary-lifecycle integration result;
- rehearsal A retained records;
- independent-validator invocation records that remain;
- supplied-root closing equality;
- cleanup;
- final failure report.

Classify this root as:

historical_nonqualifying_candidate_2_qualification_attempt

It is:

- immutable;
- noncurrent;
- nonauthoritative;
- not resumable;
- not cleanable in this task;
- eligible to supply only exact Candidate 2 source bytes and authenticated
  qualification specifications.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
2. EXACT CANDIDATE 2 PRODUCTION SOURCE REGISTRY
──────────────────────────────────────────────────────────────────────────────

Authenticate these exact production-source files from the failed repair root.

All expected mode `0600`, link count `1`.

1. source/reconstruction_parent_v1.py
   - size:
     28564
   - SHA-256:
     75efcbb46ef7230e717880710ffad6f134a3b194f675d93c7871120b256f611b

2. source/process_recorder_v1.py
   - size:
     2814
   - SHA-256:
     791567d839755e0cd8eac2773cdd5e2b5734a9782600171978b1a7c30ebc3dd7

3. source/strict_json_v1.py
   - size:
     5628
   - SHA-256:
     b99a2e30100ea1d6af54c7d9a796a4cabf36faefd77e6674eb96741967d246aa

4. source/json_observation_v1.py
   - size:
     3454
   - SHA-256:
     3e4127193ff92e2dbad82a35dfc5f74019478d5993eba80538e0824df043ff2d

5. source/supplied_root_inventory_v1.py
   - size:
     2915
   - SHA-256:
     bfb29efb83b0b093cedbab6c607f6e45f10ed16d211ee6758a31e2316e643067

6. source/manifest_projection_a_v1.py
   - size:
     3588
   - SHA-256:
     72673406941b036b0063bc8d616b500bc957c9085f431b4448ec9f20a4fa1071

7. source/manifest_projection_b_v1.py
   - size:
     3853
   - SHA-256:
     0cb66ced7e8181d0157a41c775399319e099097b110a3f094e6918c026a9ea6e

8. source/schema_engine_v1.py
   - size:
     17784
   - SHA-256:
     a921404efd8b789566c081e083b18795aaa66a5ed6691ce7bea9424693963aff

9. source/subject_model_v1.py
   - size:
     21985
   - SHA-256:
     3711dd7f13bbe9986cb88938b820e5f2a2fe9a1000769f99c2a3e6cc31e2b4be

Authenticate the final Attempt 2 production registry record itself and require
that it contains exactly these nine current paths and identities.

Do not infer a source from basename or uniqueness.

──────────────────────────────────────────────────────────────────────────────
3. EXACT CANDIDATE 2 QUALIFICATION SOURCE REGISTRY
──────────────────────────────────────────────────────────────────────────────

Authenticate these exact qualification-source files.

All expected mode `0600`, link count `1`.

1. validation/qualification_harness_v1.py
   - size:
     157586
   - SHA-256:
     a4f206e41432ceefd445dd0e1c70925af4e70e84022b94c807c0242fcb57c626

2. validation/independent_external_interface_validator_v1.py
   - size:
     5123
   - SHA-256:
     1c0a44777233fc22876b045c29be786881eefbf5df51b80b394822f5944bc35b

3. validation/independent_negative_matrix_validator_v1.py
   - size:
     8773
   - SHA-256:
     8e24d764878add303d4b2531b4fd9cc60f28a6dadf1d5ec68bc71b80adac3828

4. validation/independent_schema_subject_validator_v1.py
   - size:
     13453
   - SHA-256:
     9087c0109db5bc77366e312b610622f7f948ba4be72e91eface5c5ac67d47606

5. validation/independent_process_custody_validator_v1.py
   - size:
     3129
   - SHA-256:
     b7a351b0517f54a8a76e26c16fe82768e8529c01ffebf536d968b409d7e3e99f

6. validation/independent_rehearsal_validator_v1.py
   - size:
     23445
   - SHA-256:
     b810003b879ce3f2c26d25565509a86762d6ed0626eaec18aedda3e1bf567677

7. validation/terminal_manifest_reprojector_v1.py
   - size:
     4185
   - SHA-256:
     8a0ae1f57ba987df816827e583b99d57bc5ecca31cdb7a50e440ab10958d0c2f

Authenticate the final Attempt 2 qualification registry and require exactly
these seven paths and identities.

No source may be modified in this task.

──────────────────────────────────────────────────────────────────────────────
4. AUTHORITATIVE CONTRACT, SCHEMA, AND VALIDATION INPUTS
──────────────────────────────────────────────────────────────────────────────

AUTHORITATIVE_CONTRACT_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-2y6tkl0n

Expected identity:

- device/inode:
  16777234 / 180472094
- mode:
  0700

Authoritative contract:

contract/package-construction-parent-v1.json

- size:
  32038
- SHA-256:
  874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19

SCHEMA_SOURCE_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-repair-pw27ydqf

Expected identity:

- device/inode:
  16777234 / 180513083
- mode:
  0700

SCHEMA_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-construction-parent-schema-reconciliation-5e2lsx8t

Expected identity:

- device/inode:
  16777234 / 180480821
- mode:
  0700

VALIDATION_SPEC_SOURCE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-evidence-repair-lj_8xygs

Expected identity:

- device/inode:
  16777234 / 180576497
- mode:
  0700

Use these roots as the exact supplied inputs to both rehearsals.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
5. FRESH REPLAY CAPSULE
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask `077`, prefix:

ES-repair10i-v3-clean-parent-exact-qualification-replay-

Immediately emit:

REPLAY_ROOT=<absolute-path>

Retain before supplied-root inspection:

opening/bootstrap-start.json

Bind:

- fresh-root identity;
- allocation method and umask;
- failed repair-root identity;
- exact Candidate 2 production registry;
- exact Candidate 2 qualification registry;
- historical provenance-mismatch reason;
- authoritative supplied-input identities;
- replay-only authority;
- source modification authorized:
  false;
- source repair authorized:
  false;
- source freeze authorized:
  false;
- current subject construction authorized:
  false;
- product implementation authorized:
  false;
- target audit authorized:
  false;
- runtime validation authorized:
  false;
- same-root retry authorized:
  false;
- further Candidate 2 qualification replay after this task:
  false.

Create directories lazily.
Do not retain an empty directory except a reserved premanifest directory if the
replay capsule itself is terminally sealed.

──────────────────────────────────────────────────────────────────────────────
6. BYTE-EXACT REPLAY SOURCE COPY
──────────────────────────────────────────────────────────────────────────────

Copy all nine production and seven qualification source files into the replay
capsule using:

- no-follow stable source reads;
- exclusive mode-0600 writes;
- complete write;
- fsync;
- close;
- no-follow reopen;
- exact size and SHA-256 comparison.

Retain:

opening/exact-candidate-source-copy-v1.json

Require:

- sixteen source files;
- zero missing;
- zero extra;
- zero mismatched;
- no transformation;
- no normalization;
- no edit;
- no generated source.

The copied sources remain investigative Candidate 2 bytes, not current
authority.

──────────────────────────────────────────────────────────────────────────────
7. SOURCE-EXTERNAL REPLAY SUPERVISOR
──────────────────────────────────────────────────────────────────────────────

Implement a new audit-owned finite supervisor under:

tooling/source_external_replay_supervisor_v1.py

The supervisor may not import:

- Candidate 2 production modules;
- Candidate 2 qualification helpers;
- historical qualification-harness helpers;
- historical process recorders;
- producer expected-result maps.

It may execute Candidate 2 sources only as child processes.

Supervisor authority is limited to:

- exact source/input authentication;
- child process custody;
- rehearsal-root custody;
- stream/result retention;
- complete physical inventories;
- independent adjudication;
- cleanup;
- replay-capsule closure.

It has no authority to:

- modify Candidate 2;
- repair a rehearsal;
- alter a result;
- promote a rehearsal as current;
- construct the current subject.

All child launches must route through one supervisor-owned recorder.

──────────────────────────────────────────────────────────────────────────────
8. SUPERVISOR PROCESS-CUSTODY PREFLIGHT
──────────────────────────────────────────────────────────────────────────────

Before either rehearsal, qualify the supervisor’s custody path.

Retain:

validation/replay-supervisor-custody-preflight-v1.json

Required causals:

1. nonexistent executable:
   - spawn failure retained;
   - no process claimed;
   - streams represented exactly.

2. child exits zero with empty streams.

3. child exits nonzero with nonempty stdout and stderr:
   - exact bytes, sizes, and hashes retained.

4. child creates one dynamic root and exits zero:
   - exact locator retained;
   - root identity and inventory retained.

5. child creates one dynamic root and exits nonzero:
   - exact locator retained despite nonzero exit;
   - root identity and inventory retained.

6. child result missing:
   - failure retained;
   - root not cleaned before inventory.

7. child timeout:
   - process termination and reaping retained;
   - streams retained;
   - root effects retained.

8. cleanup:
   - evidence retained before removal;
   - exact root removed;
   - ENOENT observed twice.

Require:

- contiguous ordinals;
- every launched child reaped;
- every descriptor closed;
- stdout/stderr retained before cleanup;
- process ledger retained before cleanup;
- dynamic-root identity retained before cleanup;
- complete root inventory retained before cleanup;
- no unaccounted effect;
- zero survivor.

If this preflight fails, return:

QUALIFICATION_REPLAY_PROVENANCE_MISMATCH

Do not run the rehearsals.

──────────────────────────────────────────────────────────────────────────────
9. EXACT REHEARSAL INVOCATION CONTRACT
──────────────────────────────────────────────────────────────────────────────

Derive the exact rehearsal-parent invocation from:

- Candidate 2 source;
- Candidate 2 operating model;
- Candidate 2 artifact plan;
- Candidate 2 historical rehearsal records;
- authoritative supplied-input identities.

Retain:

contract/exact-candidate-rehearsal-invocation-v1.json

Bind:

- exact executable;
- exact `-I -S -B` options;
- exact script path;
- exact mode;
- exact supplied-root operands;
- exact output-root or output-parent operands;
- cwd;
- explicit environment;
- stdin;
- timeout;
- expected stdout grammar;
- expected stderr posture;
- expected exit semantics;
- exact dynamic-root or fixed-root attribution;
- exact result paths;
- cleanup ownership.

Do not infer an invocation from filename conventions.

Do not use the Candidate 2 qualification harness as the parent process for
rehearsal custody.

Invoke the Candidate 2 production reconstruction parent directly.

If the exact invocation cannot be established, return:

QUALIFICATION_REPLAY_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
10. REHEARSAL A
──────────────────────────────────────────────────────────────────────────────

Allocate or bind the rehearsal A root exactly as required by the invocation
contract.

Use prefix when supervisor allocation is authoritative:

ES-repair10i-v3-clean-parent-replay-rehearsal-a-

Execute the exact Candidate 2 production parent once.

Retain before any cleanup:

- exact rehearsal path;
- device/inode/mode;
- parent prelaunch;
- parent PID;
- argv;
- cwd;
- environment;
- stdout;
- stderr;
- exit/signal;
- timeout posture;
- reaping;
- descriptor closure;
- complete process ledger;
- complete no-follow physical inventory;
- every result identity;
- temporal inventory identity;
- manifest A identity;
- manifest B identity;
- terminal marker;
- terminal membership;
- no-write posture;
- package-status result;
- complete failure evidence when exit is nonzero.

Do not remove rehearsal A.

──────────────────────────────────────────────────────────────────────────────
11. REHEARSAL B
──────────────────────────────────────────────────────────────────────────────

Allocate or bind a physically distinct rehearsal B root.

Use prefix when supervisor allocation is authoritative:

ES-repair10i-v3-clean-parent-replay-rehearsal-b-

Execute the same exact Candidate 2 production source bytes, argv shape,
environment, and supplied inputs.

Retain the same complete custody fields as rehearsal A.

Require A and B distinct by:

- absolute path;
- device/inode pair.

Do not remove rehearsal B.

──────────────────────────────────────────────────────────────────────────────
12. REHEARSAL RAW-RESULT ADJUDICATION
──────────────────────────────────────────────────────────────────────────────

Before invoking the independent rehearsal validator, independently inspect
both rehearsal roots without importing Candidate 2 helpers.

Retain:

analysis/rehearsal-raw-result-adjudication-v1.json

For each rehearsal bind:

- parent exit;
- terminal marker;
- package status;
- planned membership;
- actual membership;
- contract identity;
- fifteen schema identities;
- fifteen-role registry;
- fourteen-family registry;
- schema/family mapping;
- 946-case result identity and counts;
- 137-case result identity and counts;
- field-map identity and counts;
- ten-role validator registry;
- ten result identities;
- evidence DAG;
- confirmation evidence;
- current-role occupancy;
- supplied-root equality;
- cleanup result;
- temporal inventory;
- manifest pair;
- independent physical reprojection;
- terminal topology;
- modes;
- cache/bytecode;
- postseal activity.

Do not decide final implementation validity solely from this preliminary
inspection.

──────────────────────────────────────────────────────────────────────────────
13. EXACT INDEPENDENT REHEARSAL-VALIDATOR INVOCATION
──────────────────────────────────────────────────────────────────────────────

Derive and retain:

contract/exact-independent-rehearsal-validator-invocation-v1.json

Bind:

- exact Candidate 2 validator source identity;
- pinned Python and flags;
- exact rehearsal A and B operands;
- exact result path in the replay capsule;
- exact argv;
- cwd;
- environment;
- stdin;
- timeout;
- expected result schema;
- exit semantics;
- stdout semantics;
- stderr semantics.

The result path must be absent before launch and exclusively created.

The replay supervisor must capture:

- prelaunch;
- PID;
- stdout bytes;
- stderr bytes;
- exit/signal;
- result bytes;
- reaping;
- descriptor closure;
- filesystem effects.

Do not let the validator clean either rehearsal root.

──────────────────────────────────────────────────────────────────────────────
14. INDEPENDENT VALIDATOR EXECUTION
──────────────────────────────────────────────────────────────────────────────

Execute the exact independent rehearsal validator once.

Retain:

- complete child process record;
- raw stdout file;
- raw stderr file;
- exact result file when produced;
- parsed error list;
- exception/traceback when any;
- every referenced rehearsal path;
- every referenced result pointer;
- first failure;
- all failures.

If exit is `1`, do not collapse the finding to “validator failed.”

Retain every exact error before any cleanup.

If the validator crashes:

- retain exception type;
- exception message;
- traceback;
- source line;
- operation;
- input pointer and value type where applicable.

──────────────────────────────────────────────────────────────────────────────
15. SOURCE-EXTERNAL FAILURE CLASSIFICATION
──────────────────────────────────────────────────────────────────────────────

For every independent-validator error, classify it through fresh direct
observation of the rehearsal roots.

Retain:

analysis/independent-validator-error-adjudication-v1.json

Each error row must contain:

- validator error ID;
- validator source range;
- claimed path/pointer;
- expected value;
- validator-observed value;
- fresh audit-observed value;
- rehearsal A value;
- rehearsal B value;
- whether the validator parsed the correct record;
- whether the validator used the correct grammar;
- whether the underlying rehearsal artifact is actually defective;
- immediate cause;
- repair owner.

Allowed per-error classifications:

PRODUCTION_RECONSTRUCTION_DEFECT
PRODUCTION_OUTPUT_EVIDENCE_DEFECT
INDEPENDENT_VALIDATOR_ORACLE_DEFECT
INDEPENDENT_VALIDATOR_PARSER_DEFECT
INDEPENDENT_VALIDATOR_INVOCATION_DEFECT
QUALIFICATION_PROCESS_CUSTODY_DEFECT
MIXED_DEFECT
EVIDENCE_INSUFFICIENT

Do not infer a production defect merely from validator exit `1`.

Do not exonerate production merely because the parent exited `0`.

──────────────────────────────────────────────────────────────────────────────
16. NORMALIZED REHEARSAL COMPARISON
──────────────────────────────────────────────────────────────────────────────

Retain:

validation/source-external-two-rehearsal-comparison-v1.json

Normalize only explicitly physical values:

- rehearsal-root absolute path;
- root device/inode;
- root-bound generated identities;
- child PIDs;
- nonacceptance-bearing timestamps;
- explicitly enumerated physical bindings.

Compare semantically:

- contract bytes;
- fifteen schema identities;
- fifteen-role registry;
- fourteen-family registry;
- schema/family mapping;
- witness semantics;
- all 946 case names and results;
- all 137 case names and results;
- 766/333 field-map rows;
- ten-role validator registry;
- all ten validator results;
- evidence DAG;
- confirmation semantics;
- current-role occupancy;
- package status;
- temporal inventories;
- terminal manifests after normalization;
- final topology.

Retain every unexplained difference.

──────────────────────────────────────────────────────────────────────────────
17. TERMINAL CANDIDATE CLASSIFICATION
──────────────────────────────────────────────────────────────────────────────

Retain:

analysis/candidate-2-terminal-classification-v1.json

Classify Candidate 2 exactly as one:

PRODUCTION_CANDIDATE_SEMANTICALLY_SOUND_QUALIFICATION_HARNESS_CUSTODY_DEFECT

PRODUCTION_CANDIDATE_DEFECT_CONFIRMED

INDEPENDENT_VALIDATOR_DEFECT_CONFIRMED

MIXED_PRODUCTION_AND_VALIDATOR_DEFECT

CANDIDATE_QUALIFICATION_NONQUALIFYING

Rules:

A. Production candidate sound / harness custody defect only

Require:

- both rehearsal parents exit successfully;
- both roots terminally close;
- raw audit adjudication passes;
- normalized rehearsals agree;
- independent validator passes, or every validator failure is independently
  proved validator-side with no underlying rehearsal defect;
- all evidence is retained.

B. Production defect

Require at least one independently observed rehearsal defect attributable to
production source or generated output.

C. Validator defect

Require rehearsal outputs independently pass while the validator misparses,
misbinds, crashes, invokes incorrectly, or applies an invalid oracle.

D. Mixed

Require independent production and validator defects.

E. Nonqualifying

Use only when replay evidence is complete but classification remains
indispensably ambiguous.

No additional Candidate 2 replay is authorized after this task.

──────────────────────────────────────────────────────────────────────────────
18. MANDATORY NEXT TREATMENT
──────────────────────────────────────────────────────────────────────────────

Retain:

analysis/mandatory-next-treatment-v1.json

Select exactly one:

A. When production is sound and historical defect is harness custody only:

BOUNDED_QUALIFICATION_HARNESS_CUSTODY_REPAIR

The next task may:

- repair only qualification-harness process/evidence custody;
- preserve all nine production source bytes;
- preserve validator semantics when independently sound;
- complete two rehearsals;
- freeze the repaired implementation package;
- submit it to a fresh independent audit.

B. When only the independent validator is defective:

BOUNDED_INDEPENDENT_VALIDATOR_REPAIR_AND_REQUALIFICATION

The next task must preserve production source bytes and repair only the
validator/invocation lane.

C. When production candidate is defective:

RETIRE_CANDIDATE_AND_BUILD_NEW_CLEAN_PARENT

Candidate 2 must not be patched further.

D. When mixed:

RETIRE_CANDIDATE_AND_REBUILD_PARENT_AND_VALIDATOR

E. When replay provenance fails or classification remains nonqualifying:

RETIRE_CANDIDATE_QUALIFICATION_LINEAGE

Do not recommend another replay.

──────────────────────────────────────────────────────────────────────────────
19. EVIDENCE RETENTION BEFORE CLEANUP
──────────────────────────────────────────────────────────────────────────────

Before removing rehearsal A or B, retain inside the replay capsule:

- exact root identities;
- complete physical inventories;
- temporal and manifest identities;
- all parent process records;
- all child ledgers;
- all stdout/stderr files;
- all validator inputs;
- validator process record;
- validator stdout/stderr;
- validator result;
- raw adjudication;
- error adjudication;
- normalized comparison;
- terminal classification;
- mandatory treatment.

Generate:

closing/rehearsal-evidence-retention-v1.json

Require:

- rehearsal A evidence complete;
- rehearsal B evidence complete;
- validator evidence complete;
- no indispensable path exists only in a rehearsal root;
- all copied/regenerated evidence identities verified.

Do not proceed to cleanup unless this record passes.

──────────────────────────────────────────────────────────────────────────────
20. REHEARSAL CLEANUP
──────────────────────────────────────────────────────────────────────────────

After evidence retention passes:

1. re-lstat rehearsal A and require original identity;
2. remove exact rehearsal A;
3. observe ENOENT twice;
4. re-lstat rehearsal B and require original identity;
5. remove exact rehearsal B;
6. observe ENOENT twice;
7. require every child reaped;
8. require every descriptor closed;
9. require zero process survivor;
10. require zero cache/bytecode survivor.

Retain:

closing/rehearsal-cleanup-v1.json

Require exact set equality:

created rehearsal roots
=
inventoried rehearsal roots
=
retained-evidence roots
=
cleanup rows
=
twice-absent roots

──────────────────────────────────────────────────────────────────────────────
21. SUPPLIED-ROOT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete lstat/no-follow inventories for every supplied root opened:

- failed repair root;
- authoritative contract package;
- schema source package;
- schema reconciliation root;
- validation-specification source;
- any historical authority root actually opened.

Require exact opening/closing equality.

Do not modify or clean supplied roots.

──────────────────────────────────────────────────────────────────────────────
22. REPLAY CAPSULE CLOSURE
──────────────────────────────────────────────────────────────────────────────

After every nonmanifest replay artifact is final:

1. generate and verify a temporal inventory;
2. create terminal manifest A and B using a stable final-namespace protocol;
3. use two independently authored projections;
4. require A/B byte equality;
5. independently reproject the final capsule;
6. require root row present exactly once;
7. require no empty descendant;
8. require no symlink, special object, or multiply linked file;
9. require modes `0700/0600`;
10. require no cache/bytecode;
11. seal once;
12. perform no filesystem read or write after seal.

On failure before seal:

- retain explicit failure outcome;
- retain complete evidence;
- do not produce a success seal;
- exit nonzero.

──────────────────────────────────────────────────────────────────────────────
23. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

CLEAN_RECONSTRUCTION_PARENT_EXACT_REPLAY_PASSED_HARNESS_CUSTODY_DEFECT_ONLY

only when:

- complete source/input authentication passes;
- supervisor custody preflight passes;
- both rehearsals complete;
- every rehearsal artifact independently passes;
- normalized comparison passes;
- independent validator passes or is conclusively shown validator-side only;
- Candidate 2 production source has no confirmed defect;
- all evidence is retained before cleanup;
- cleanup closes;
- supplied roots close equal;
- replay capsule terminally closes.

Mandatory next treatment:

BOUNDED_QUALIFICATION_HARNESS_CUSTODY_REPAIR

Return:

CLEAN_RECONSTRUCTION_PARENT_EXACT_REPLAY_BLOCKED_PRODUCTION_SOURCE_DEFECT

when an independently observed production or output defect exists and no
independent validator defect affects that classification.

Mandatory next treatment:

RETIRE_CANDIDATE_AND_BUILD_NEW_CLEAN_PARENT

Return:

CLEAN_RECONSTRUCTION_PARENT_EXACT_REPLAY_BLOCKED_INDEPENDENT_VALIDATOR_DEFECT

when both rehearsals independently pass and the validator or its invocation is
the sole defect.

Mandatory next treatment:

BOUNDED_INDEPENDENT_VALIDATOR_REPAIR_AND_REQUALIFICATION

Return:

CLEAN_RECONSTRUCTION_PARENT_EXACT_REPLAY_BLOCKED_MIXED_DEFECT

when independent production and validator defects exist.

Mandatory next treatment:

RETIRE_CANDIDATE_AND_REBUILD_PARENT_AND_VALIDATOR

Return:

QUALIFICATION_REPLAY_PROVENANCE_MISMATCH

for:

- supplied-root mutation;
- source identity mismatch;
- supervisor custody failure;
- lost stdout/stderr;
- lost process ledger;
- rehearsal root removed before evidence retention;
- missing A or B identity/inventory;
- incomplete error retention;
- cleanup inequality;
- supplied-root closing inequality;
- replay-capsule closure failure;
- postseal filesystem activity.

Mandatory next treatment:

RETIRE_CANDIDATE_QUALIFICATION_LINEAGE

No further replay is authorized.

──────────────────────────────────────────────────────────────────────────────
24. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Mandatory next treatment
3. Fresh replay-root identity
4. Failed repair-root identity and closure
5. Exact production-source registry
6. Exact qualification-source registry
7. Authoritative supplied-input identities
8. Exact source-copy result
9. Replay-supervisor source identity
10. Supervisor custody preflight
11. Exact rehearsal invocation contract
12. Rehearsal A identity
13. Rehearsal A parent process custody
14. Rehearsal A complete inventory and terminal result
15. Rehearsal B identity
16. Rehearsal B parent process custody
17. Rehearsal B complete inventory and terminal result
18. Raw rehearsal-result adjudication
19. Independent-validator invocation contract
20. Independent-validator process custody
21. Validator stdout identity and complete text or structured contents
22. Validator stderr identity and complete text or structured contents
23. Validator result identity and complete findings
24. Complete validator-error adjudication
25. Normalized rehearsal comparison
26. Candidate 2 terminal classification
27. Mandatory next-treatment rationale
28. Evidence-retention result
29. Rehearsal cleanup and double-ENOENT result
30. Complete child-process ledger
31. Supplied-root closing equality
32. Replay temporal-inventory identity
33. Replay manifest A identity
34. Replay manifest B identity
35. Independent replay-capsule reprojection
36. Terminal membership and modes
37. No-write-after-closure
38. Remaining uncertainty and nonclaims
39. Explicit confirmation registry

Required confirmations:

FAILED_REPAIR_ROOT_MUTATION_NOT_PERFORMED
EXACT_CANDIDATE_2_PRODUCTION_SOURCE_REGISTRY_AUTHENTICATED
EXACT_CANDIDATE_2_QUALIFICATION_SOURCE_REGISTRY_AUTHENTICATED
CANDIDATE_2_SOURCE_BYTES_NOT_MODIFIED
CANDIDATE_2_SOURCE_REPAIR_NOT_PERFORMED
AUTHORITATIVE_CONTRACT_PACKAGE_MUTATION_NOT_PERFORMED
SCHEMA_SOURCE_PACKAGE_MUTATION_NOT_PERFORMED
SCHEMA_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
VALIDATION_SPEC_SOURCE_MUTATION_NOT_PERFORMED
SOURCE_EXTERNAL_SUPERVISOR_USED
SUPERVISOR_IMPORTS_NO_CANDIDATE_HELPERS
SUPERVISOR_CUSTODY_PREFLIGHT_PASSED
EXACT_REHEARSAL_INVOCATION_FROZEN
REHEARSAL_A_EXECUTED_EXACTLY_ONCE
REHEARSAL_B_EXECUTED_EXACTLY_ONCE
REHEARSAL_ROOTS_PHYSICALLY_DISTINCT
REHEARSAL_A_PROCESS_CUSTODY_COMPLETE
REHEARSAL_B_PROCESS_CUSTODY_COMPLETE
REHEARSAL_A_COMPLETE_INVENTORY_RETAINED
REHEARSAL_B_COMPLETE_INVENTORY_RETAINED
REHEARSAL_A_STREAMS_RETAINED
REHEARSAL_B_STREAMS_RETAINED
REHEARSAL_A_TERMINAL_POSTURE_ADJUDICATED
REHEARSAL_B_TERMINAL_POSTURE_ADJUDICATED
INDEPENDENT_VALIDATOR_EXECUTED_EXACTLY_ONCE
INDEPENDENT_VALIDATOR_PROCESS_CUSTODY_COMPLETE
INDEPENDENT_VALIDATOR_STDOUT_RETAINED
INDEPENDENT_VALIDATOR_STDERR_RETAINED
INDEPENDENT_VALIDATOR_RESULT_RETAINED
EVERY_VALIDATOR_ERROR_RETAINED
EVERY_VALIDATOR_ERROR_INDEPENDENTLY_ADJUDICATED
TWO_REHEARSALS_NORMALIZED_COMPARISON_COMPLETED
CANDIDATE_2_TERMINAL_CLASSIFICATION_COMPLETE
MANDATORY_NEXT_TREATMENT_SELECTED
REHEARSAL_EVIDENCE_RETAINED_BEFORE_CLEANUP
REHEARSAL_A_DOUBLE_ENOENT_RETAINED
REHEARSAL_B_DOUBLE_ENOENT_RETAINED
REHEARSAL_CLEANUP_SET_EQUALITY_PASSED
CHILD_ORDINALS_COMPLETE_AND_CONTIGUOUS
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
CURRENT_SCHEMA_SUBJECT_NOT_CONSTRUCTED
PROCESS_SELF_TEST_NOT_EXECUTED
CONSTRUCT_MODE_NOT_EXECUTED
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
REPLAY_CAPSULE_TEMPORAL_INVENTORY_CREATED
REPLAY_CAPSULE_MANIFEST_A_CREATED
REPLAY_CAPSULE_MANIFEST_B_CREATED
REPLAY_CAPSULE_MANIFESTS_BYTE_IDENTICAL
REPLAY_CAPSULE_TERMINAL_REPROJECTION_PASSED
NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_WRITE_AFTER_TERMINAL_CLOSURE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

This replay is terminal for Candidate 2.

Do not issue another Candidate 2 replay after its result.
```

**Source:** Codex’s `IMPLEMENTATION_PROVENANCE_MISMATCH` report in this turn.  
**Confidence:** 0.99 that the current evidence is insufficient to classify Candidate 2; 0.98 that a no-edit source-external replay is the narrowest trustworthy next step; 0.97 that any further loss of replay evidence should retire the candidate rather than trigger another recovery attempt.
