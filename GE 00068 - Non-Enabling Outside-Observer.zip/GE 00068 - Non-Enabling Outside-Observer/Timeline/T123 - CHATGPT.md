## Assessment

This is the correct repair disposition. The patch is ready for a **new, full independent re-audit**, not for commit yet.

The important points are now clean:

- EV-01 through EV-08 were repaired within the authorized six-file subset and without changing the 13-path tranche boundary.
- EV-09 was correctly left as an audit-process issue rather than “fixed” in source.
- Validation was rebuilt from the repaired bytes rather than inherited from the blocked audit target.
- The test suite passed 52 tests in four independent runs across umasks `077` and `022`.
- Real A6D and amendment closure, synthetic pre-seal/sealed closure, deterministic output, and no-write behavior passed.
- The final canonical patch manifest is now `7d114a1479d62ea613957ee7e80f7cf0c37c46a4279d1c26e2ce3474d56a26f5`.
- The repaired verifier is `ee8809b8b67b18751d29893bff7d624fc85edee10e84b9eb0e72bf33c7437a68`.
- The previous audit does not qualify these bytes.

The architecture remains the intended non-recursive design: an ES-owned committed verifier with versioned layout specifications, independently audited before its first commit; it does not verify itself or obtain readiness authority.  Proof tooling and generated evidence must remain non-authoritative rather than becoming ES architecture by inertia. 

The fresh re-audit should correct the prior audit-process defect structurally: **only the audit parent may execute Git, every Git invocation must use `git -C "$IMPL_R"` and `GIT_OPTIONAL_LOCKS=0`, and audit subagents must execute no Git command at all.**

## Codex prompt: fresh independent re-audit

```text
Objective

Perform a fresh, read-only independent re-audit of the repaired Evidence
Verification v1 implementation.

Do not repair or modify the patch.

The previous audit returned BLOCK and identified EV-01 through EV-08 as patch
or test defects and EV-09 as an audit-process defect. The implementation
parent reports that EV-01 through EV-08 are repaired, freshly validated, and
re-provenanced. EV-09 must be avoided through strict audit procedure; it does
not authorize a repository change.

Return exactly one verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

This is a new audit of new bytes. The prior audit verdict does not qualify or
reject this repaired target.

No repository mutation.
No formatting.
No cleanup that changes repository or supplied evidence bytes.
No staging, commit, push, PR, merge, installation, deployment, A6 restart,
product test, live-service invocation, network contact, or Linux execution.

No nested subagents.

## 1. Inputs

Implementation worktree:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Expected branch:

codex/evidence-verification-v1

Expected HEAD:

567bceced5df95ecfe787cc66038d463a854e12c

Expected HEAD tree:

b7cab23732572c2aaea9d5f2f1593338e2e75338

Expected sole parent:

05dde14d185b6e022dcc169ef1a658a97961850f

Expected upstream:

absent

Implementation evidence root:

EVIDENCE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df

Repair implementation report:

EVIDENCE/audit-repair-v1/closeout/implementation-report-v1.json

Expected repaired canonical patch manifest:

EVIDENCE/audit-repair-v1/closeout/provenance/manifest-run-1.json

Expected canonical patch-manifest SHA-256:

7d114a1479d62ea613957ee7e80f7cf0c37c46a4279d1c26e2ce3474d56a26f5

Expected verifier SHA-256:

ee8809b8b67b18751d29893bff7d624fc85edee10e84b9eb0e72bf33c7437a68

Expected unchanged registry SHA-256:

e35306141f58ab7b2908b3c62a74d173af17c6e7124acc92bd5737ec7004d880

Expected unchanged layout SHA-256 values:

A6D successor:
267053d083ecac7a7bcf8533e14d207c1438c032e66eaa95ba240d8b683eb0dc

A6D amendment:
3f6e47873c3760e2c2de6560aa9031d5657efff8d42ce9b5fda26fe396f56be4

A6 policy:
b98258468ad7815fe924c25aa7f9959db12570b952e2713c2bd8ee3083ce07e8

Expected final provenance recipe source SHA-256:

bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333

Recover the expected repaired tracked binary-diff SHA-256, complete canonical
manifest bytes, exact recipe source, validation commands, and test identities
from the repair implementation report and retained repair evidence.

If any required exact source or expected digest is unavailable, return:

AUDIT_PROVENANCE_MISMATCH

Do not reconstruct or approximate it.

Previous completed audit, read-only:

PRIOR_AUDIT=/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-567bceced5df-v1

Original sealed A6D child:

A6D=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

Sealed A6D amendment:

A6D_AMEND=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

Required new audit root, absent at opening:

AUDIT_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v2

## 2. Strict Git and process boundary

Set:

GIT_OPTIONAL_LOCKS=0
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

Only the audit parent may execute Git.

Every Git invocation must be exactly rooted through:

git -C "$IMPL_R" ...

and inherit:

GIT_OPTIONAL_LOCKS=0

No audit subagent may execute Git.

Do not execute any Git command in:

- the primary ES checkout;
- the Repair 10I candidate;
- A6D;
- A6D_AMEND;
- EVIDENCE;
- PRIOR_AUDIT;
- AUDIT_ROOT.

Do not use an implicit current-directory Git invocation.

Record every parent Git argv, cwd, and environment.

Any nonconforming Git command is an audit-process blocker and must be
disclosed. Do not continue silently.

## 3. Audit root

Require AUDIT_ROOT absent.

Create it under umask `077`.

All audit outputs remain beneath AUDIT_ROOT.

Use exactly:

opening/
provenance/
perspectives/
validation/
findings/
closeout/

Do not place audit files in the repository or supplied evidence roots.

Remove only audit-owned temporary fixture roots. Do not remove or normalize a
repository or supplied-evidence artifact.

## 4. Opening repository gate

Require IMPL_R:

- physical root equals lexical path;
- final root is a real directory;
- branch:
  `codex/evidence-verification-v1`;
- HEAD:
  `567bceced5df95ecfe787cc66038d463a854e12c`;
- HEAD tree:
  `b7cab23732572c2aaea9d5f2f1593338e2e75338`;
- sole parent:
  `05dde14d185b6e022dcc169ef1a658a97961850f`;
- upstream:
  absent;
- exactly 13 changed or untracked paths;
- exactly four modified tracked paths;
- exactly nine untracked paths;
- every path regular;
- every working-tree mode `0644`;
- every logical mode `100644`;
- zero staged;
- zero deleted;
- zero renamed;
- zero unmerged;
- no Git operation marker or lock;
- no path outside the expected set.

Expected 13 paths:

1. `PLANS.md`
2. `.docs/system_overview/boundaries.md`
3. `.docs/system_overview/artifact_hygiene.md`
4. `.docs/system_overview/capability_probing.md`
5. `.docs/system_overview/evidence_verification.md`
6. `tools/evidence_verify/verify_v1.py`
7. `tools/evidence_verify/registry_v1.json`
8. `tools/evidence_verify/layouts/a6d_successor_v1.json`
9. `tools/evidence_verify/layouts/a6d_amendment_v1.json`
10. `tools/evidence_verify/layouts/a6_policy_v1.json`
11. `tools/evidence_verify/test_verify_v1.py`
12. `tools/evidence_verify/fixtures/historical_a6d_verify_postseal_v1.py.txt`
13. `tools/evidence_verify/fixtures/historical_a6d_verify_closing_v1.py.txt`

Stop before correctness inspection on mismatch:

AUDIT_PROVENANCE_MISMATCH

## 5. Exact provenance gate

### 5.1 Recipe source

Resolve the exact final provenance recipe source from the repair implementation
report and retained repair evidence.

Require:

- exact recipe ID;
- source SHA-256:
  `bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333`;
- complete source bytes available;
- explicitly rooted Git commands;
- deterministic locale;
- tracked modifications and untracked additions included;
- path classification included;
- regular-file type, logical mode, size, and SHA-256 included;
- deterministic tracked binary diff included;
- deterministic raw-byte path sorting;
- canonical JSON;
- no timestamp, random value, hostname, username, or machine-specific
  absolute path in canonical output;
- output written outside IMPL_R.

### 5.2 Reproduce twice

Run the exact recipe twice against IMPL_R.

Require:

- both successful;
- byte-identical outputs;
- equality with the retained repaired canonical manifest;
- canonical manifest SHA-256:
  `7d114a1479d62ea613957ee7e80f7cf0c37c46a4279d1c26e2ce3474d56a26f5`;
- tracked binary-diff SHA-256 equal to the exact repaired value from the
  implementation report;
- exact 13-path set;
- four `tracked_modified`;
- nine `untracked`;
- exact per-file type, mode, size, and SHA-256;
- no additional path.

Stop before source inspection on any difference:

AUDIT_PROVENANCE_MISMATCH

### 5.3 Previous audit disposition

Require the repair evidence to state truthfully:

- the prior audit qualified only predecessor bytes;
- EV-01 through EV-08 were repaired;
- EV-09 remained an audit-process issue;
- the prior audit does not qualify the repaired bytes;
- new validation and new provenance were generated;
- no commit or A6 restart occurred.

## 6. Audit perspectives

After exact provenance succeeds, create exactly four bounded read-only audit
perspectives.

They may inspect files and audit-owned copies but must execute no Git command
and perform no repository write.

No nested subagents.

Roles:

1. Contract and authority auditor.
2. Verifier correctness and state-semantics auditor.
3. Test and validation adequacy auditor.
4. Security, filesystem, capability, and artifact auditor.

Each receives:

- the exact canonical patch manifest;
- repaired verifier hash;
- unchanged registry and layout hashes;
- prior EV-01 through EV-09 finding ledger;
- repair implementation report;
- current architecture target;
- non-goals.

Retry a failed perspective once.

Do not silently replace required missing coverage with parent inference.

Preserve minority findings.

## 7. Authority and contract re-audit

Inspect all five governing documents and the architecture-reset decision.

Require:

- ES-local ownership remains bounded;
- verifier output remains evidence/projection only;
- no runtime, admission, orchestration, readiness, product, durable-state, or
  execution authority;
- layout specs remain structural declarations only;
- closeout and later audit own readiness interpretation;
- no evidence-child self-verification;
- no amendment-chain model;
- no runtime caller-supplied layout;
- no public API, product schema, route, module, service, or runtime-contract
  change;
- EV-01 through EV-08 repairs do not widen the verifier’s authority;
- EV-09 is documented only as prior audit-process history.

Check docs and source for contradictions.

The canonical MVP planning freeze explicitly says proof scaffolding must not
be promoted into architecture or make evidence authoritative. Preserve that
boundary. 

## 8. Full verifier audit

Inspect the complete repaired `verify_v1.py`, not only changed hunks.

### 8.1 EV-01 physical boundary

Audit:

- descriptor-bound root opening;
- stable `(device,inode,type)` identity;
- physical ancestor-chain derivation;
- package/target equality and containment;
- target/package reverse containment;
- pre-seal candidate identity;
- candidate parent ancestry;
- candidate symlink and hardlink handling;
- case-alias resistance;
- opening/closing identity stability;
- fail-closed behavior when ancestry cannot be proven.

Reject reliance on case folding, lowercasing, `realpath()` string equality, or
`commonpath()` as physical authority.

Independently reproduce, in audit-owned copies:

- canonical nested target rejection;
- different-case spelling of the same nested target rejection;
- package beneath target;
- target/package alias;
- candidate beneath package;
- candidate beneath target;
- case-variant candidate containment;
- candidate symlink;
- candidate hardlink where supported;
- truly disjoint target and candidate pass.

### 8.2 EV-02 literal-LF grammar

Audit raw-byte parsing.

Require literal `0x0a` as the only line separator.

Independently test pre-seal and sealed rejection of:

- vertical tab;
- form feed;
- NEL;
- CRLF;
- missing final LF;
- extra blank line;
- Unicode line or paragraph separator where encodable.

Require canonical `MANIFEST_CANONICAL` output and no traceback.

### 8.3 EV-03 bounded JSON

Audit:

- raw-source byte-size bound;
- nonrecursive lexical nesting preflight;
- string and escape handling;
- depth semantics at below-bound, exact-bound, and over-bound cases;
- duplicate-key and float rejection;
- invalid UTF-8;
- malformed escapes;
- `RecursionError` and expected parse exceptions;
- deterministic one-line failure output;
- no traceback.

Independently rerun the prior deeply nested-registry mechanism.

### 8.4 EV-04 resource limits

Audit that limits are enforced before unbounded work:

- manifest file count;
- declared per-file size;
- declared aggregate size;
- incremental target file count;
- incremental directory count;
- actual size before open/hash;
- aggregate size before hashing the overflow-causing file;
- both stability traversals bounded;
- no unbounded `listdir()` or equivalent materialization;
- no excessive read before rejection.

Use small audit-owned budget fixtures and instrumented read/count observations.
Do not create a large tree.

### 8.5 EV-05 capabilities

Audit behavioral capability preflight for every required descriptor-relative
operation.

Require:

- capability absence maps to canonical `indeterminate`;
- error class `IO_OR_RACE`;
- exit `7`;
- no traceback;
- no pathname fallback;
- failures arising after preflight are also canonicalized.

Inject `NotImplementedError` and supported “operation unavailable” `OSError`
variants at each boundary.

### 8.6 EV-08 decimal parser

Audit the bounded decimal parser.

Independently test:

- digit string beyond Python’s conversion limit;
- leading zero;
- sign;
- non-ASCII digit;
- empty input;
- exact maximum;
- maximum plus one.

Require lexical malformed values to map to `MANIFEST_CANONICAL`, while
canonical values above resource limits map to the declared resource/closure
class.

## 9. Test and validation audit

Inspect all test source and discover the complete current test set.

Expected implementation report:

- 52 tests;
- four complete passing runs:
  - twice under umask `077`;
  - twice under umask `022`;
- zero failure;
- zero error;
- zero skip.

Independently run the complete suite:

1. twice under umask `077`;
2. twice under umask `022`.

Require:

- identical discovered test set;
- 52 passes every run;
- zero skip;
- deterministic relevant outputs;
- no repository artifact.

Inspect whether tests explicitly set every fixture file and directory mode.

Audit EV-07 isolated tests:

- self-consistent missing required root;
- required-path symlink replacement;
- required-path FIFO/special-file replacement;
- extra-path symlink remains separately tested;
- extra-path special file remains separately tested;
- exact expected failure class asserted.

Ensure no test passes solely because of an unrelated stale manifest row or
unexpected extra path.

Check for circular tests that use the implementation itself as the only
expected-value oracle.

## 10. Real and synthetic compatibility reruns

Use exact interpreter:

`/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13`

Require:

- version `3.13.4`;
- size `119424`;
- SHA-256:
  `f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b`.

Use:

- `-I`;
- `-B`;
- `PYTHONDONTWRITEBYTECODE=1`;
- `LC_ALL=C`;
- `LANG=C`;
- private AUDIT_ROOT-owned `TMPDIR`;
- no network.

Run independently:

1. AST parse of all Python source.
2. Strict registry/spec parsing.
3. Sealed A6D verification twice.
4. Sealed amendment verification twice.
5. Synthetic A6 pre-seal verification twice.
6. Test-owned sealing.
7. Synthetic A6 sealed verification twice.
8. Repeated canonical-output comparisons.
9. Before/after target and verifier-package snapshots.
10. `git -C "$IMPL_R" diff --check` by the parent only.

Require real sealed children unchanged.

Require all repeated outputs byte-identical.

## 11. Security and artifact audit

Inspect:

- open flags;
- no-follow handling;
- directory descriptor lifetime;
- ancestor traversal termination;
- candidate-file read stability;
- traversal race handling;
- bounded hashing;
- incremental enumeration;
- exception handling;
- malformed and oversized source behavior;
- output minimization;
- no writes;
- no child process;
- no network;
- no target code import;
- no generic caller layout.

Inspect IMPL_R for:

- `__pycache__`;
- `.pyc`;
- `.pytest_cache`;
- generated manifests;
- databases or journals;
- locks;
- fixture roots;
- temporary outputs;
- unexpected executable modes;
- unsupported objects.

Historical fixture files must remain inert and must never be imported or
executed as repository code.

## 12. Repair-evidence audit

Inspect:

- repair finding disposition;
- exact predecessor manifest;
- vulnerable/repaired causal records;
- four complete fresh test runs;
- complete test list;
- real-child checks;
- synthetic checks;
- no-write snapshots;
- failed/superseded attempt index;
- cleanup;
- final repair implementation report;
- final provenance.

Require:

- every EV-01 through EV-08 finding explicitly closed with source and test
  evidence;
- EV-09 explicitly left as audit-process-only;
- no predecessor validation represented as final repair proof;
- all final evidence binds final bytes;
- registry/layout bytes truly remained unchanged;
- no missing or overwritten failed attempt;
- no authority/security widening claim unsupported by source.

## 13. Parent adjudication

The audit parent must:

1. Preserve all material findings and disagreements.
2. Distinguish:
   - provenance mismatch;
   - repaired patch defect;
   - residual patch defect;
   - pre-existing issue;
   - audit-process issue;
   - future hardening seam.
3. Reconcile each prior EV finding against current source and fresh causals.
4. Audit the entire 13-path patch, not only the repairs.
5. Avoid accepting solely because tests pass.
6. Avoid rejecting because the verifier is ES-local rather than a general
   cross-repository framework.
7. Perform no repair.

## 14. Closing provenance and no-mutation gate

Remove only audit-created temporary fixtures.

Rerun the exact final provenance recipe twice.

Require:

- both outputs byte-identical;
- equality with opening repaired manifest;
- SHA-256:
  `7d114a1479d62ea613957ee7e80f7cf0c37c46a4279d1c26e2ce3474d56a26f5`;
- tracked binary-diff equal to the repaired expected value;
- repository identity unchanged;
- exact path set and per-file identities unchanged;
- staged/deleted/renamed/unmerged remain zero;
- no audit-created repository file;
- A6D and A6D_AMEND unchanged.

If closing provenance differs:

AUDIT_PROVENANCE_MISMATCH

## 15. Finding format

For each material finding:

AUDIT FINDING

ID:
Type:
Severity: critical | high | medium | low | observation
Classification:
Current contract or strategic target:
Path and line:
Evidence:
Reachable mechanism:
Impact:
Required correction:
Containment/nonclaim:
Uncertainty:
Patch defect, pre-existing issue, or audit-process issue:
Blocking: yes | no

## 16. Verdict rules

### AUDIT_PROVENANCE_MISMATCH

Use when:

- repository identity differs;
- recipe source unavailable or wrong;
- repaired manifest differs;
- repeated provenance unstable;
- closing provenance differs.

Stop before correctness inspection on opening mismatch.

### REJECT

Use only for a fundamental decomposition or authority failure that cannot be
repaired within the bounded tranche.

### BLOCK

Use when any repairable correctness, security, validation, documentation,
artifact, or evidence defect remains.

### ACCEPT

Use only when:

- opening and closing provenance match;
- EV-01 through EV-08 are causally closed;
- EV-09 is not repeated;
- authority split remains sound;
- verifier remains fail-closed;
- physical boundaries resist aliases and case variants;
- manifest grammar is canonical;
- parsing and resources are bounded;
- capability failures are canonical;
- tests are umask-independent and mechanism-specific;
- real and synthetic closure reruns pass;
- no artifact or report blocker remains.

## 17. Required final report

Include:

1. Verdict.
2. Opening and closing provenance.
3. Repaired canonical manifest and tracked diff digests.
4. Repository identity.
5. All four audit perspectives and completion status.
6. EV-01 through EV-09 closure table.
7. Authority/contract adjudication.
8. Full verifier correctness adjudication.
9. Test/validation adjudication.
10. Security/filesystem/capability adjudication.
11. Fresh validation commands and outcomes.
12. Results under umask `077` and `022`.
13. Real A6D/amendment checks.
14. Synthetic pre-seal/sealed checks.
15. Severity-ranked residual findings.
16. Minority findings.
17. Uninspected areas and uncertainty.
18. Audit-created artifacts and cleanup.
19. Confirmation:
    - repository mutation not performed;
    - formatting not performed;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 not restarted;
    - product tests/live services not invoked;
    - every Git command was parent-only and explicitly rooted;
    - nested subagents not created.

No repair.
No commit.
No push.
No A6 restart.
No product A/B.
No snapshot or deployment.
```

After `ACCEPT`, the next step is a separate exact-byte commit gate. No implementation repair is permitted during that gate: regenerate the accepted manifest, stage exactly the 13 audited paths, compare staged blobs/modes/sizes with the manifest, run byte-preserving final validation, commit once, and compare committed blobs again. Any byte change returns the tranche to implementation and another audit. 

The fresh audit must again reproduce exact provenance before source inspection. 

### Sources

- Codex’s `EVIDENCE_VERIFICATION_V1_AUDIT_REPAIR_IMPLEMENTED_READY_FOR_FRESH_REAUDIT` report supplied in this turn.
- Non-recursive ES-owned verifier architecture. 
- Frozen verifier and non-authority contracts. 
- MVP proof scaffolding remains non-authoritative. 
- Repair requires new provenance and a fresh independent audit. 
- Commit is permitted only after audit acceptance. 
- Provenance-before-correctness audit sequence. 

**Confidence**

- Repair provenance readiness: **0.997**
- Correct next gate: fresh independent re-audit, **0.999**
- Likelihood that EV-01 through EV-08 are closed, before re-audit: **0.90**
- Confidence that EV-09 must be handled procedurally rather than in source: **0.999**
- Confidence that no commit or A6 restart should occur before `ACCEPT`: **0.999**
