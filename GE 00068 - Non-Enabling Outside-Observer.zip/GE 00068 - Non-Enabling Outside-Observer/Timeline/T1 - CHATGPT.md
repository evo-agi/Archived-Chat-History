This is a **real BLOCK**, but the report is less fragmented than the count of 13 findings suggests. It exposes **five root problems**, not thirteen unrelated failures.

Do not create another snapshot, rerun the commit gate, or add more validation evidence yet.

## What the audit actually established

| Root problem | Findings | Disposition |
|---|---|---|
| The custody registry is not the sole descriptor authority | `P2-001`, `P2-002`, `P2-003`, part of `P2-007` | Product repair required |
| Closing barriers and private error accumulation are incomplete | `P2-004`, `P2-005`, `P2-006`, part of `P2-007` | Product repair required |
| The successor tool accepts assertions about qualification instead of deriving facts | `P3-001`, `P3-002`, `P3-004`, `P3-005` | Successor redesign required |
| A/B disjointness checks cover roots, not the complete mutable state graph | `P3-003` | Successor redesign required |
| Codex’s project infrastructure mutates its own turn-diff Git namespace during the audit | `P4-001` | Audit-environment correction, **not a product repair** |

`P3-006` and `P4-002` are reporting/packaging observations and should be corrected without widening the product tranche.

### The product findings are material

`P2-001` and `P2-003` are the decisive product defects:

- A descriptor can apparently be disposed without first becoming a registry-owned object.
- Some cleanup paths discard the generation and later resolve ownership by the raw integer FD.
- A stale owner can therefore act on a newly reused FD.

That means the registry is presently an **optional bookkeeping layer**, not the exclusive custody boundary claimed by the contract. This should not be repaired with more conditional checks around the existing helper. The API must make the bypass structurally unavailable.

The barrier findings are similarly coherent: early returns and coarse blocker substitution prevent the implementation from completing all acquired-owner barriers and retaining every private cause. A blocked public result is not enough; the contract explicitly claims complete private custody and ordered uncertainty.

### The successor problem is architectural

The successor is still allowing a producer to say, in effect:

> “I am cleaned up, independent, and qualified.”

and then comparing those claims.

That is the wrong trust direction. Qualification must be derived from raw observations, immutable records, fresh post-cleanup inspection, and independently recomputed bindings. Evidence remains evidence; it does not become authoritative merely because a helper labels it `Qualified`. The project already states that generated evidence must not become authoritative, and that planning/documentation slices do not widen ES contracts.  Provenance likewise binds participants to the same bytes but does not establish correctness, sufficient tests, or sound authority boundaries. 

### `P4-001` must not enter Repair 10G source scope

The mutation occurred under Codex-managed `refs/codex/turn-diffs/**`, while candidate source, branch, HEAD, index, and critical Git identity remained exact. That is an audit-venue problem.

Trying to “repair” ES around host-managed turn-capture refs would be category error and would perpetuate the loop. The next independent audit must either:

1. run outside the project-backed Codex environment; or
2. explicitly classify that host-owned namespace as volatile/report-only while holding candidate-authoritative refs, index, source, config, and object content to exact equality.

The first path is cleaner.

## Recommended next move

Do **one read-only Repair 10G reconnaissance turn** before authorizing mutation. It should freeze:

1. a type-level descriptor-custody redesign;
2. a total, non-short-circuiting barrier/error model;
3. a successor model that derives qualification rather than trusting captions;
4. complete A/B mutable-state disjointness;
5. a detached audit venue that cannot be invalidated by Codex’s own turn-capture machinery.

This follows the project protocol: reconnaissance and implementation should be separate turns, the parent should be the sole writer, and changed bytes must later receive a new fresh independent audit. 

Pass the following to a fresh **read-only Codex conversation**.

```text
REPAIR 10G — READ-ONLY RECONNAISSANCE AND DESIGN FREEZE

Objective

Freeze one coherent Repair 10G implementation plan that closes the exact
Repair 10F audit findings without widening T2A-P, changing public schemas,
changing T1, or continuing the audit-framework expansion by inertia.

This is reconnaissance only. Do not edit, create, delete, format, stage,
commit, push, install, run product tests, create another snapshot, mutate
evidence, or contact any network or live service.

Repository

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Expected repository baseline

branch:
codex/remote-alpha-external-tls-status-observation-v1

HEAD:
567bceced5df95ecfe787cc66038d463a854e12c

sole parent:
05dde14d185b6e022dcc169ef1a658a97961850f

HEAD tree:
b7cab23732572c2aaea9d5f2f1593338e2e75338

upstream:
absent

Expected Repair 10F source identity

T:
624ece774f7cdc01a9abace85785c0418f66cdda

inventory SHA-256:
65280783ea3149589912cf589caf6d52ba7a1eb45a324c1141544da526ab1763

membership:
389 total
375 tracked
14 nonignored untracked

Expected staged/deleted/renamed/unmerged:
0/0/0/0

Qualifying source and evidence

Recovered source ZIP:
/Users/ds/Downloads/ES-T2AP-repair10-integrated-624ece774f7c-q4n8vz-r1.zip

Recovered handoff:
/Users/ds/Downloads/ES-T2AP-repair10-integrated-624ece774f7c-q4n8vz-r1-audit-handoff.md

Sealed Phase F:
/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-f-closure-q4n8vz

Sealed recovery capture:
/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/snapshot-624ece774f7c-q4n8vz-r1

Current classification

- T1 is a Current invariant.
- Repair 10G and T2A-P are an unaccepted Bounded slice rule.
- Legacy operator behavior is a Temporary compatibility edge.
- T2A-I and T2B remain absent future work.
- No Reopened redesign seam is being implemented.
- Evidence remains non-authoritative.
- P4-001 is an audit-environment finding and is not permission to modify ES
  source around Codex-managed refs.

Mandatory finding ledger

Product/source:
- P2-001 — registry enrollment can be bypassed.
- P2-002 — repeated disposition returns a new error instead of stored state.
- P2-003 — generation is discarded and lookup later uses the raw integer FD.
- P2-004 — actual close causes are replaced by coarse blockers.
- P2-005 — existing-generation recovery suppresses the closing sync barrier.
- P2-006 — hierarchy/coordinate barriers return early and drop later causes.
- P2-007 — active tests bless synthetic or incomplete custody semantics.

Successor/evidence:
- P3-001 — post-cleanup qualification trusts retained/fabricated captions.
- P3-002 — comparator trusts producer-supplied bindings and booleans.
- P3-003 — A/B disjointness is root-only and omits descendant/process/socket/
  slot state.
- P3-004 — persisted outcome remains qualified-equal after a late fault.
- P3-005 — retained Phase F A/B evidence cannot be independently reobserved
  after origins are deleted.
- P3-006 — sealed physical modes versus logical source modes need an explicit
  materialization rule.

Audit process:
- P4-001 — project-managed refs/codex/turn-diffs changed during audit.
  Treat this as an audit-venue defect, not an ES product defect.
- P4-002 — closeout streams temporarily escaped the original audit root.

Required reconnaissance workflow

After confirming the exact baseline, create exactly four bounded read-only
explorers. No nested subagents. Give every explorer this complete context and
the same exact candidate identity.

Explorer 1 — universal descriptor custody

Inspect all descriptor acquisition, registration, transfer, lookup, close,
barrier, final-verification, and cleanup paths in:

- es/externaltls/internal/statuspackage/package.go
- es/externaltls/internal/statuspackage/package_test.go
- governing T2A-P documentation and PLANS.md

Produce:

1. A complete inventory of every governed descriptor owner and acquisition
   site.
2. Every route that can currently close or dispose a raw FD without a
   generation-bound registry token.
3. Every route that indexes ownership by the integer FD.
4. Every repeated-disposition route and its current returned state/cause.
5. A type-level design in which:
   - registration is mandatory at acquisition;
   - no ordinary production helper accepts a bare FD for disposition;
   - owner token includes immutable owner ID and generation;
   - opening identity may be attached after acquisition without changing the
     owner generation;
   - aliases are invalidated before the sole Close;
   - repeated disposition returns the stored terminal disposition and cause;
   - EINTR is never retried;
   - stale generation or FD reuse blocks without touching the newer owner;
   - final verification accounts for every acquisition.
6. Whether a single unexported OwnedDescriptor/OwnerToken abstraction can
   close the defect without public API/schema changes.
7. Exact intended touched files and causal tests.

Do not accept “static scan says no raw Close” as sufficient. The design must
make ordinary bypass structurally unavailable.

Explorer 2 — total barriers and ordered private causality

Inspect:

- existing-generation recovery;
- hierarchy closing barriers;
- coordinate/floor barriers;
- stage and runtime cleanup;
- blocker mapping;
- errors.Join ordering;
- all early returns and coarse error replacements.

Produce:

1. The exact required private error order.
2. Every current short-circuit point.
3. Every current cause-replacement point.
4. A total barrier algorithm that:
   - visits every acquired owner despite earlier failure;
   - records identity, sync, close, and cleanup uncertainty;
   - returns one ordered joined private chain;
   - selects the public blocker exactly once;
   - never lets a cleanup blocker replace an established operational blocker;
   - clears hashes and suppresses finite success when required.
5. An explicit decision for existing-generation synchronization.
6. Production-path causal tests for:
   - first barrier failure plus later barrier causes;
   - operational failure plus hierarchy, coordinate, stage, runtime-root, and
     runtime-parent causes;
   - public blocker stability;
   - omitted owner;
   - duplicate close;
   - EINTR;
   - stale generation/FD reuse;
   - owner reordering;
   - post-publication immutability.
7. Exact touched docs/tests/source.

Explorer 3 — successor qualification and A/B evidence

Inspect the complete retained 12-member Phase F successor source.

Treat all `Qualified`, `ResourceDisposition`, `IndependentControlsVerified`,
binding digests, and equality captions as untrusted claims until recomputed.

Produce a bounded redesign that:

1. Derives qualification from fresh raw observations after cleanup.
2. Never fabricates PID, birth-time, session, resource, or cleanup facts.
3. Recomputes C/T/D/E, source inventory, compiler, module, GOROOT, tool, and
   command bindings from underlying retained records or live controls.
4. Finalizes `qualified-equal` only after all descriptor, output, close,
   cleanup, resource, and terminal checks complete.
5. Keeps factual BytesEqual separate from AcceptedEqual.
6. Recursively inventories all A/B mutable roots and checks:
   - physical path equality and containment both directions;
   - every cross-control device/inode pair;
   - hardlinks;
   - mutable Git stores and alternates;
   - caches;
   - runtime roots;
   - PackageFloor/generation/slot state;
   - artifacts and evidence;
   - process epochs;
   - sockets/listeners.
7. Rejects equal but nonqualifying controls.
8. Defines exactly what must remain live until comparison and what can be
   retained as immutable evidence.
9. Determines whether Phase F historical A/B should remain preliminary only
   and the fresh audit must always rerun A/B.
10. Makes logical source-mode restoration explicit before inventory/build.
11. Minimizes the successor rather than adding another general framework
    layer.

Return exact successor files to modify, schemas to version, tests/mutants,
self-host/rebuild commands, and stop conditions.

Explorer 4 — contracts, audit venue, provenance, and scope cap

Inspect:

- AGENTS.md;
- PLANS.md;
- T2A-P deployment/boundary/configuration/capability/artifact docs;
- docs_contract_test.go;
- Phase F and recovery-capture contracts;
- provenance and audit guidance.

Produce:

1. Docs that must change with the product and successor corrections.
2. A strict distinction between:
   - candidate-authoritative Git state;
   - Codex/project-managed volatile refs and associated host metadata;
   - report-only timestamps;
   - immutable candidate source/index/config/ref facts.
3. The preferred next audit venue:
   - detached/non-project Codex execution if available;
   - otherwise an explicit volatile-namespace exclusion that cannot hide
     candidate branch/ref/index/object-content changes.
4. A provenance gate that does not continually fail because the audit host
   records its own conversation.
5. The exact future audit requirement for fresh A/B rather than reliance on
   Phase F captions.
6. A finite scope cap:
   - no new general-purpose validation framework;
   - no new public product surface;
   - no changes to T1, T2A-I, T2B, operator production, schemas, or module
     graph;
   - no attempt to make the audit tool authoritative.
7. Exact touched files, evidence lineage, snapshot cadence, and stop
   conditions.

Parent synthesis requirements

Wait for all four explorers and preserve disagreements.

Reduce the thirteen audit findings to their underlying design causes rather
than planning thirteen independent patches.

Return:

1. Current contracts and invariants.
2. Strategic decisions.
3. Exact custody API and state machine.
4. Exact barrier/error model and ordering.
5. Exact successor qualification model.
6. Exact A/B physical-disjointness model.
7. Exact audit-venue policy.
8. Exact repository touched-file set.
9. Exact successor/evidence touched-file set.
10. Exact docs-first implementation order.
11. Exact validation commands and required evidence.
12. Exact provenance/snapshot/audit sequence.
13. Explicit non-goals.
14. Mandatory stop conditions.
15. Inspection limits and unresolved uncertainty.

Do not implement.

Do not create the next Phase evidence child yet.

Do not rerun the expensive validation matrix.

Do not create a snapshot.

Do not modify Phase F or recovery-capture evidence.

Before finishing, close all explorers and verify branch, HEAD, index, worktree
membership, candidate T, and status remain unchanged.

Final verdict must be exactly one of:

REPAIR10G_RECONNAISSANCE_READY
REPAIR10G_RECONNAISSANCE_PARTIAL
REPAIR10G_RECONNAISSANCE_BLOCKED
SUBAGENT_UNAVAILABLE
```

The critical architectural recommendation is this: **Repair 10G should make the registry and verifier the only paths through which custody and qualification can occur.** Continuing to preserve fallback paths while adding more tests around them will produce another audit cycle without closing the underlying contract.

The fresh audit must remain a separate read-only conversation; the operating protocol explicitly requires that separation and prohibits audit-time repair. 

### Sources

- Codex independent-audit report supplied in the current message.
- Governed Execution Codex Subagent Operating Protocol: implementation, independent audit, repair, and re-audit are distinct engagements. 
- Governed Execution Provenance Guidance: exact provenance binds bytes but does not establish correctness or sufficient validation. 

**Confidence:** 0.97 that another repair is required; 0.95 that the product findings collapse into two source-design causes; 0.94 that the successor findings collapse into qualification derivation plus complete disjointness; 0.99 that `P4-001` belongs in the audit venue rather than Repair 10G product scope.
