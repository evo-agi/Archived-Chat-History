## Assessment

A6D is implementation-ready. The contract is appropriately narrow and addresses the real ambiguity rather than weakening the validator globally:

- `EINVAL` is **not** accepted generically.
- The exception is limited to the exact `/dev/null` device-literal grant and exact `static-runtime` role.
- ACL and xattr posture remain separate observations.
- `unsupported-for-volume` is not conflated with “absent.”
- The unsupported state qualifies only when the exact request is independently known-valid, the live object identity is exact, and the relevant volume capability bit is valid and clear.
- Malformed requests, capability uncertainty, unexpected errno, path or type substitution, wrong `rdev`, ownership/mode changes, and producer/peer disagreement remain blocking.
- Regular files, executables, directories, and trees retain their current security-posture requirements.
- No controlled-command authority or read scope widens.

The schema decision is also correct. `effective-read-policy.v2` only admitted `ENOTSUP`/`EOPNOTSUPP`; accepting the newly proven `/dev/null` posture changes acceptance semantics. It therefore requires `effective-read-policy.v3` and the complete outer v6 chain rather than silently repurposing v2/v5.

The next tranche should implement and seal this successor-only amendment, then stop. The five-control A6 refresh must restart afterward in a new child; the current failed A6 child remains unsealed negative evidence. A bounded tool causal cannot substitute for that fresh downstream validation. 

## Codex prompt: implement the A6D device-security-posture amendment

```text
Permission is workspace-write for one new source-external successor/evidence
child only.

Objective

Implement, validate, close out, and seal the Repair 10I-A6D exact-device
security-posture amendment frozen by the sealed A6D reconnaissance.

The current sealed A6R successor fails before command launch while constructing
the pristine-final read policy:

- exact object:
  /dev/null
- current grant kind:
  file
- current role:
  static-runtime
- exact ACL request:
  path-based getattrlist
  bitmapcount = 5
  commonattr = ATTR_CMN_EXTENDED_SECURITY = 0x00400000
  volattr = 0
  dirattr = 0
  fileattr = 0
  forkattr = 0
  buffer size = 65536
  options = FSOPT_NOFOLLOW = 1
- observed result:
  EINVAL
- current A6R interpretation:
  probe failure
- acceptance-bearing commands launched:
  0

The sealed A6D reconnaissance proves:

1. The exact ACL request succeeds on private regular-file and directory
   controls, establishing that the request itself is structurally valid.
2. The exact request repeatedly returns EINVAL on exact `/dev/null`.
3. Malformed requests can also return EINVAL; errno alone is never enough.
4. A separate volume-capability request returns the ACL capability bit
   `0x400` as valid and clear for the volume containing `/dev/null`.
5. The `/dev/null` xattr-list probe repeatedly returns EPERM.
6. A separate volume-capability request returns the native-xattr capability bit
   `0x4000` as valid and clear.
7. ACL and xattr unsupported states must remain separate.
8. Neither unsupported state means “ACL absent” or “xattrs absent.”
9. This is a validation-contract change requiring:
   - effective-read-policy.v3;
   - the complete eight-record outer v6 chain.
10. The correction is limited to an exact `/dev/null` device-literal grant and
    does not authorize a generic character-device, `/dev`, ACL, xattr, or
    EINVAL exception.

Implement only this frozen contract.

This is a parent-only implementation turn.

Do not modify repository source.
Do not modify sealed A6R.
Do not modify sealed A6D.
Do not modify any predecessor.
Do not resume, modify, overwrite, or seal either failed A6 child.
Do not restart the five-control A6 refresh in this turn.
Do not implement the historical directional-comparator policy.
Do not start B6.
Do not run product A/B preparation.
Do not create an integrated snapshot, ZIP, handoff, or capture child.
Do not stage, commit, push, install, invoke a live route, contact a remote
host, or execute Linux binaries.
Do not perform or claim an independent audit.

No subagents. You are the sole writer.

Candidate repository, read-only throughout

CANDIDATE_R=/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Forbidden primary checkout as repository cwd or source root

PRIMARY_R=/Users/ds/Repositories/Execution Substrate

Sealed A5T4 repository lineage

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5t4-harness-closure-ab646e5a0e66

Sealed A6O overlay successor lineage

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6o-overlay-successor-closure-8de797304ea9

Sealed A6R reconnaissance

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6r-read-policy-recon-8de797304ea9

Sealed A6R mutable-tree successor baseline

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6r-read-policy-successor-closure-8de797304ea9

Sealed A6D device-security reconnaissance

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-recon-8de797304ea9

Earlier failed A6 child, immutable and unsealed

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a6o-8de797304ea9

Current failed A6 child, immutable and unsealed

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a6r-8de797304ea9

Required new successor child, absent at opening

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

## 1. Absolute physical-root lock

Before any substantive observation:

1. Component-walk and `lstat` CANDIDATE_R.
2. Require physical path exactly:
   `/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1`
3. Require:
   - type: directory
   - device: `16777234`
   - inode: `122118502`
   - mode: `0755`
   - UID/GID: `501/20`
4. Enter the candidate through an explicitly configured cwd.
5. Require physical `pwd -P` to equal CANDIDATE_R.
6. Require PRIMARY_R to remain a distinct sibling:
   - device/inode: `16777234/47685738`
   - no alias
   - no equality
   - no nesting
   - no same inode.

Inspect CANDIDATE_R/.git and require:

- regular pointer file;
- no final symlink;
- mode `0644`;
- size `123`;
- device/inode `16777234/122118504`;
- link count `1`;
- SHA-256:
  `79247c70d443aba211d972b5316847bb38cac45d7caf03c766b9ae5d2e2d0419`;
- exact target:
  `/Users/ds/Repositories/Execution Substrate/.git/worktrees/Execution-Substrate---external-tls-status-observation-v1`;
- common Git directory:
  `/Users/ds/Repositories/Execution Substrate/.git`.

Set:

GIT_OPTIONAL_LOCKS=0
LC_ALL=C
LANG=C

Every Git command must use:

git -C "$CANDIDATE_R" ...

or an explicitly configured subprocess cwd equal to physical CANDIDATE_R.

No command may use PRIMARY_R as:

- cwd;
- Git `-C` target;
- source root;
- inventory root.

For inline Python:

- use `PYTHONDONTWRITEBYTECODE=1`;
- verify `os.getcwd()` before repository-relative access;
- import no executable module from evidence children;
- create no `__pycache__` or `.pyc`.

Stop on any mismatch:

REPAIR10I_A6D_IMPLEMENTATION_WORKTREE_MISMATCH

## 2. Mandatory opening gate

Using candidate-rooted observations only, require:

- branch:
  `codex/remote-alpha-external-tls-status-observation-v1`
- HEAD:
  `567bceced5df95ecfe787cc66038d463a854e12c`
- sole parent:
  `05dde14d185b6e022dcc169ef1a658a97961850f`
- HEAD tree:
  `b7cab23732572c2aaea9d5f2f1593338e2e75338`
- upstream:
  absent
- index SHA-256:
  `012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31`
- repository T:
  `8de797304ea944b6a155924e0d1e9e8bbe79534e`
- repository inventory:
  `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`
- inventory size:
  `54314`
- membership:
  `389 total / 375 tracked / 14 nonignored untracked`
- tracked modifications:
  `22`
- staged/deleted/renamed/unmerged:
  `0/0/0/0`.

Require every governed source member to be a regular nonsymlink member under
the established inventory contract.

Require the exact three-file A5T4 repository delta and every other repository
tuple to match sealed A5T4.

Require exact sealed A5T4:

- manifest SHA-256:
  `7cc55f3399d8c5eac48470a4eb82e8087753ddbb17e8d0eb6de7d03ad7937888`
- manifest size:
  `202930`
- payloads:
  `1000`
- directories:
  `188`
- repository T:
  `8de797304ea944b6a155924e0d1e9e8bbe79534e`
- inventory:
  `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`.

Require exact sealed A6R reconnaissance:

- manifest SHA-256:
  `12ec94fff28d4a861b92ec069abd90ddd1e39f9b026777799b585db755cfcb6c`
- payloads:
  `19`
- directories:
  `8`.

Require exact sealed A6R successor:

- manifest SHA-256:
  `fe8954e4401005e85059fc0d44684b89bce38c7019d239ebcd5dfa000030f983`
- manifest size:
  `26785`
- payloads:
  `193`
- directories:
  `28`
- source T:
  `50f08cc78fe8634488063853e43904a633261f51`
- source inventory:
  `56f20b54e4992c860598c6603563b4eea589421dff886c5d4002adcc9846c84f`
- members:
  `12`.

A6R binaries:

repair10-runner:
`84afddf2657480661215557059de3eecbf74db8e9ec5f43f19ad883b7ddc1199`

repair10-compare:
`c9af21bd8841a55979c7a907a77195a03345eac6c83001651f11a09a0e7d2781`

repair10-semantic:
`fb438eaf872bc86310fd79b1820a2163aa8a2c9fc2fd5515cc22ad0f5fee2d9a`

repair10-fixture:
`d058ebdeb01b960868e4784abafbaaef9d57e8e71b12bdaa71f55aca9786c2f4`

Recover and verify their exact sizes from the sealed report and manifest.

Require:

- A/B byte equality;
- inode-distinct copies;
- complete A6R post-seal verification;
- exact A6R 24-schema dialect;
- all 32 A6R causals;
- all 58 overlay causals;
- all seven A5C tests;
- A5P2 PTY and execution-policy nonregression.

Require exact sealed A6D:

- manifest SHA-256:
  `006d5c51f54fc350f857423014296ea0559996604a723997e56b7f0ac0713da1`
- manifest size:
  `2357`
- payloads:
  `18`
- directories:
  `8` including root.

Reverify completely:

- `closeout/final-report-v1.md`
- `probes/private-darwin-probe-results-v1.json`
- `probes/volume-capability-stability-v1.json`
- `schemas/frozen-device-security-contract-v1.md`
- `schemas/schema-transition-v1.json`
- `tests/future-causal-matrix-v1.json`
- exact source/touched-file freeze;
- implementation/restart sequence;
- stop conditions.

Require the current failed A6 child to remain:

- present;
- unsealed;
- without manifest or detached digest;
- exact opening/closing byte snapshot:
  `a3c1f0f5a1cba0ec2b194afdeac7ff58ff3648ec7238c54834d11e247a2094f6`.

Reverify:

- `findings/fresh-validation-block-v1.json`
- `closeout/validation-blocked-closeout-v1.json`
- `closeout/command-root-audit-v1.json`
- all seven command intent/result records;
- read-policy construction evidence;
- cleanup and two absence epochs.

Bind exactly:

- pristine-final prelaunch only;
- acceptance-bearing commands launched:
  `0`;
- all seven commands:
  `not-launched`;
- object:
  `/dev/null`;
- current grant role:
  `static-runtime`;
- current grant kind:
  `file`;
- `getattrlist` bitmapcount:
  `5`;
- common mask:
  `ATTR_CMN_EXTENDED_SECURITY = 0x00400000`;
- other masks:
  zero;
- buffer size:
  `65536`;
- option:
  `FSOPT_NOFOLLOW = 1`;
- return:
  `EINVAL`;
- xattr probe:
  not reached in the failed run;
- other controls/comparisons:
  not started;
- cleanup:
  eleven private roots removed and two absence epochs.

Require all other sealed and unsealed predecessor lineage to remain exact.

Require the new successor child to be absent.

Stop on any mismatch:

REPAIR10I_A6D_IMPLEMENTATION_BASELINE_MISMATCH

## 3. Evidence-child creation

After the opening gate, create the successor child exclusively under umask 077.

Use exactly:

opening/
tool/
controls/
commands/
validation/
findings/
closeout/

All directories mode `0700`.

All files regular, single-link, nonsymlink, with intended mode `0600` or
`0700`.

No hardlinks.

Do not import executable modules from predecessor evidence children.

Copy all 12 A6R successor source members independently into:

tool/source/

Require:

- no hardlinks;
- opening bytes and logical modes equal A6R;
- complete source inventory and pure T;
- every unchanged source member reverified at closeout.

## 4. Exact authorized successor scope

Modify exactly these four copied A6R source files:

1. `tool/source/FORMAT.md`
2. `tool/source/envelope/runner.go`
3. `tool/source/envelope/semantic.go`
4. `tool/source/envelope/envelope_test.go`

The other eight source members remain byte- and logical-mode-identical to A6R:

- `tool/source/envelope/source.go`
- `tool/source/cmd/repair10-runner/main.go`
- `tool/source/cmd/repair10-semantic/main.go`
- `tool/source/cmd/repair10-compare/main.go`
- `tool/source/cmd/repair10-fixture/main.go`
- both golden files
- `tool/source/go.mod`

No thirteenth source member.
No new dependency.
No golden edit.
No CLI edit.
No repository edit.

Stop if another source file is required:

REPAIR10I_A6D_SCOPE_EXPANSION_REQUIRED

## 5. Exact `/dev/null` device-literal grant

Replace the current generic `file` representation for this one admitted object
with the exact A6D-frozen device-literal representation.

Compile-time admitted path:

`/dev/null`

Exact role:

`static-runtime`

Required live observation:

- lexical path exactly `/dev/null`;
- physical path exactly `/dev/null`;
- no symlink in the final component;
- exact character-device type;
- stable live device/inode;
- stable live `rdev`;
- UID/GID;
- mode;
- link count;
- flags;
- no-follow component identity;
- exact grant kind and role.

The current observed identity used by the vulnerable causal is:

- st_dev:
  `1020514618`
- inode:
  `336`
- rdev:
  `50331650`
- UID/GID:
  `0/0`
- mode:
  `0666`
- links:
  `1`
- flags:
  `0`.

Do not hard-code volatile inode identity as a cross-boot global constant unless
the sealed A6D contract explicitly requires that. Bind the live opening
identity and require peer equality for the same control.

Do not generalize this admission to:

- another character device;
- another `/dev` path;
- a caller-provided path;
- another grant role;
- `/dev/zero`;
- `/dev/random`;
- `/dev/urandom`;
- a PTY;
- `/dev/fd/*`.

Every other admitted device retains its existing contract unless explicitly
covered by the sealed A6D contract.

## 6. Separate ACL and xattr posture states

Implement the exact closed ACL and xattr state machines frozen in:

`schemas/frozen-device-security-contract-v1.md`

Do not reconstruct or abbreviate them from this prompt.

At minimum preserve distinct states for:

- observed absent;
- observed present;
- unsupported for object;
- unsupported for volume;
- malformed response;
- probe error;
- capability unavailable.

Use the exact A6D names and field shapes.

Do not conflate:

- unsupported;
- absent;
- inaccessible;
- permission denied;
- malformed request;
- malformed response;
- capability uncertainty.

ACL and xattr posture must be represented and verified independently.

## 7. Exact ACL unsupported-for-volume qualification

ACL `unsupported-for-volume` may qualify only for the exact `/dev/null`
device-literal grant when every condition frozen in A6D is satisfied.

At minimum require:

1. Exact device-literal grant kind.
2. Exact role `static-runtime`.
3. Exact path `/dev/null`.
4. Exact live character-device identity and `rdev`.
5. Exact no-follow component observations.
6. Exact known-valid ACL request:
   - bitmapcount `5`;
   - common mask `ATTR_CMN_EXTENDED_SECURITY`;
   - all other masks zero;
   - buffer size `65536`;
   - `FSOPT_NOFOLLOW`.
7. Independent proof that this request succeeds on the frozen private
   regular-file and directory positive controls.
8. Exact object request returns `EINVAL`.
9. Independent volume-capability request is structurally valid.
10. The ACL capability bit `0x400` is:
    - marked valid;
    - clear.
11. Producer and peer independently derive the same typed state.
12. All stable object/security fields remain exact.

`EINVAL` without this entire proof remains blocking.

`EINVAL` on:

- a regular file;
- a directory;
- a tree;
- an executable;
- an undeclared path;
- another device literal;
- a malformed request

must remain blocking.

The resulting state is not `ACL absent`.

## 8. Exact xattr unsupported-for-volume qualification

Xattr `unsupported-for-volume` may qualify only for the same exact
`/dev/null` device-literal grant when every condition frozen in A6D is
satisfied.

At minimum require:

1. Exact device-literal grant kind, role, path, type, identity, and `rdev`.
2. Exact xattr-list request.
3. Exact observed result:
   `EPERM`.
4. Independent volume-capability request is structurally valid.
5. The native-xattr capability bit `0x4000` is:
   - marked valid;
   - clear.
6. Producer and peer independently derive the same typed state.
7. ACL and xattr observations remain separate.
8. Stable object/security fields remain exact.

`EPERM` without this entire capability proof remains blocking.

The resulting state is not `xattrs absent`.

Do not infer xattr support from ACL support or vice versa.

## 9. Malformed and capability-error handling

Preserve the complete malformed-request and capability-error distinctions
frozen by A6D.

Reject at least:

- wrong bitmap count;
- invalid attribute bit;
- incompatible attribute combination;
- invalid option;
- malformed returned-attributes buffer;
- capability bitmap not marked valid;
- capability bit unexpectedly set;
- capability request failure;
- repeated capability observations disagree;
- producer/peer capability disagreement;
- unexpected errno;
- permission denial without the exact valid-clear volume proof.

A malformed request returning `EINVAL` must never reach
`unsupported-for-volume`.

## 10. Schema dialect

Implement exactly the 24-schema transition sealed in:

`schemas/schema-transition-v1.json`

Before editing, retain the exact A6R active dialect.

After editing, require exactly:

### Outer v6

- `execution-substrate.repair10i.suite-spec.v6`
- `execution-substrate.repair10i.ab-suite-spec.v6`
- `execution-substrate.repair10i.suite-result.v6`
- `execution-substrate.repair10i.binding-recomputation.v6`
- `execution-substrate.repair10i.control-qualification.v6`
- `execution-substrate.repair10i.semantic-comparison-spec.v6`
- `execution-substrate.repair10i.semantic-comparison-result.v6`
- `execution-substrate.repair10i.semantic-comparison-custody.v6`

### Command v3

- `execution-substrate.repair10i.command-intent.v3`
- `execution-substrate.repair10i.command-result.v3`
- `execution-substrate.repair10i.terminal-reconciliation.v3`

### Private PTY v2

- `execution-substrate.repair10i.private-pty-command.v2`
- `execution-substrate.repair10i.private-pty-broker-journal.v2`
- `execution-substrate.repair10i.private-pty-allocation.v2`
- `execution-substrate.repair10i.private-pty-reconciliation.v2`

### Read policy v3

- `execution-substrate.repair10i.effective-read-policy.v3`

### Unchanged v1

- `execution-substrate.repair10i.control-observation.v1`
- `execution-substrate.repair10i.mutable-inventory.v1`
- `execution-substrate.repair10i.intentional-mutant-provenance.v1`
- `execution-substrate.repair10i.validation-harness-overlay-provenance.v1`
- `execution-substrate.repair10i.go-test-semantics.v1`
- `execution-substrate.repair10i.byte-capture.v1`
- `execution-substrate.repair10i.byte-comparison-spec.v1`
- `execution-substrate.repair10i.byte-comparison-result.v1`

Use the exact A6D producer/consumer map.

Require:

- every producer emits the intended generation;
- every consumer requires the intended generation;
- strict decoding;
- v2/v5 acceptance records remain parse-only historical records;
- v2/v5 cannot qualify v3/v6 semantics;
- v3/v6 cannot qualify through v2/v5 verifier logic;
- mixed old/new acceptance chains fail.

Do not change command, PTY, overlay, semantics, byte, or mutant schema meanings.

## 11. Logical fingerprint

Implement the exact A6D fingerprint contract.

The logical fingerprint must bind all material fields frozen by A6D,
including:

- effective-read-policy schema generation;
- grant kind;
- role;
- exact path;
- exact object type;
- exact device `rdev`;
- ACL typed posture;
- ACL capability-evidence identity;
- xattr typed posture;
- xattr capability-evidence identity.

Do not make raw errno text the authority when the typed state and retained
factual observation are available.

Changing an acceptance-bearing posture or capability field must change the
fingerprint or fail strict validation.

Report-only observation differences must not make otherwise equivalent
controls logically different.

## 12. Independent peer qualification

Implement the exact A6D peer contract.

The peer must independently:

1. Reconstruct the exact grant kind and role.
2. Reobserve path, physical path, components, type, device/inode, `rdev`,
   ownership, mode, links, and flags.
3. Reissue the exact ACL request.
4. Independently establish request validity.
5. Reissue the exact xattr request.
6. Reissue the exact volume-capability request.
7. Derive ACL and xattr typed posture separately.
8. Compare typed posture and all acceptance-bearing evidence.
9. Retain raw errno and capability observations factually.
10. Reject producer-caption-only success.
11. Reject stable identity changes regardless of posture.
12. Preserve late-close and resource-failure behavior.

Producer `read_policy_verified=true` is never authority.

## 13. Vulnerable A6R causal

Using exact sealed A6R source, reproduce the frozen predecessor behavior:

- exact `/dev/null` grant;
- exact ACL request;
- `EINVAL`;
- A6R cannot classify it as supported or accepted unsupported state;
- read-policy construction blocks;
- no command launches.

Retain this as expected-negative evidence.

Do not modify or resume the failed A6 child.

## 14. Mandatory 46-case matrix

Implement and execute every case in the sealed:

`tests/future-causal-matrix-v1.json`

No omission, merging, approximation, or substitute.

The matrix includes the exact frozen cases for:

- exact `/dev/null` vulnerable behavior;
- valid private regular-file request;
- valid private directory request;
- exact device unsupported-for-volume qualification;
- producer/peer agreement;
- unsupported not equal to absent;
- malformed bitmap-count EINVAL;
- invalid-attribute EINVAL;
- incompatible-attribute EINVAL;
- EINVAL on regular file;
- EINVAL on directory/tree;
- EINVAL on executable;
- EINVAL on undeclared path;
- wrong device type;
- wrong `rdev`;
- same-path replacement inode;
- symlink substitution;
- owner/mode/flags/security-posture mutation;
- ACL and xattr independent classification;
- ACL present;
- malformed ACL response;
- permission-denied probe;
- unexpected errno;
- producer-pass/peer-fail;
- late-close/resource fault;
- literal-file and executable exactness;
- mutable-tree A6R nonregression;
- overlay nonregression;
- A5C nonregression;
- PTY nonregression;
- no generic `/dev` grant;
- no operator-terminal access;
- old/new schema rejection;
- bounded failed-A6 positive successor-tool causal.

Use the exact test identities and expected outcomes frozen in A6D.

## 15. Private Darwin probe causals

Use only exclusive private roots and the exact request implementation.

Require causals for:

- known-valid request on private regular file;
- known-valid request on private directory;
- exact `/dev/null` ACL result;
- exact `/dev/null` xattr result;
- volume-capability valid-clear ACL bit;
- volume-capability valid-clear native-xattr bit;
- repeated observation stability;
- malformed request EINVAL;
- identity substitution;
- symlink substitution;
- wrong object type;
- wrong `rdev`.

Do not access the operator terminal.
Do not enumerate unrelated `/dev` objects.
Do not add another device grant.

## 16. Failed-A6 bounded causal

Run only the bounded causal frozen by A6D.

The failed A6 child remains immutable and unsealed.

Use its retained records and/or the exact private reconstruction authorized by
the A6D contract.

Require the bounded causal to prove:

- the exact prelaunch failure is reproduced under A6R;
- the exact request is known-valid;
- exact `/dev/null` identity is stable;
- ACL capability bit is valid-clear;
- xattr capability bit is valid-clear;
- repaired ACL posture is `unsupported-for-volume`;
- repaired xattr posture is independently `unsupported-for-volume`;
- the grant qualifies only under the exact device-literal contract;
- malformed or identity-mutated variants reject.

Label this exactly:

bounded successor-tool causal only

It is not:

- a live requalification of the deleted failed control;
- a pristine-final source control;
- a substitute for the future five-control A6 refresh.

## 17. Two disjoint successor controls

Use pinned Go 1.26.5 under umask 077.

Each side independently owns:

- source;
- HOME;
- XDG_CONFIG_HOME;
- XDG_CACHE_HOME;
- GOPATH;
- GOMODCACHE;
- GOCACHE;
- GOTMPDIR;
- TMPDIR;
- build root;
- command output;
- report root;
- private ACL/xattr probe roots.

No writable state may be shared.

Require:

- no-hardlink source copies;
- disjoint source inode sets;
- disjoint caches and build roots;
- no shared mutable store.

On both sides run:

gofmt -d over all Go source members

Require empty output.

go test -json -count=3 -p=1 -parallel=1 ./...

go test -json -count=3 -p=1 -parallel=1 ./envelope \
  -run '^TestRepair10I'

go test -json -count=3 -p=1 -parallel=1 ./envelope \
  -run '^TestRepair10I.*DeviceSecurity'

go test -json -count=3 -p=1 -parallel=1 ./envelope \
  -run '^TestRepair10I.*ReadPolicy'

go test -race -json -count=1 -p=1 -parallel=1 ./...

go test -race -json -count=1 -p=1 -parallel=1 ./envelope \
  -run '^TestRepair10I'

go test -race -json -count=1 -p=1 -parallel=1 ./envelope \
  -run '^TestRepair10I.*DeviceSecurity'

go test -race -json -count=1 -p=1 -parallel=1 ./envelope \
  -run '^TestRepair10I.*ReadPolicy'

Also execute every exact selector frozen in the 46-case matrix.

Require:

- every frozen causal executes;
- zero required skips;
- zero failures;
- zero races;
- zero malformed streams;
- zero missing or duplicate terminals;
- no survivor;
- no forced cleanup;
- complete terminal and resource disposition.

## 18. Deterministic builds

Build independently on both sides:

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-runner ./cmd/repair10-runner

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-compare ./cmd/repair10-compare

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-semantic ./cmd/repair10-semantic

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-fixture ./cmd/repair10-fixture

Require every A/B pair:

- byte-identical through EOF;
- inode-distinct;
- single-link;
- expected mode;
- built from exact amended source;
- no unexpected absolute build path.

## 19. A6R, A6O, A5C, A5P2, and overlay nonregression

Re-run or independently reverify:

- all 32 mutable-tree read-policy causals;
- stable/report-only metadata treatment;
- literal-file and executable byte/digest enforcement;
- all 58 historical-overlay causals;
- valid Repair 9 overlay qualification;
- historical HEAD no-overlay qualification;
- final/fresh/mutant overlay-free source binding;
- all seven A5C observability tests;
- observability duration-position semantics;
- A5P2 `LOCAL_PEERPID`;
- acknowledged openpty/forkpty handoffs;
- parent-alias close ordering;
- EOF/hangup evidence;
- direct `/dev/ptmx` denial;
- unrelated-terminal denial;
- PTY late-fault rejection;
- byte-comparison behavior;
- source/suite/command fingerprints.

No canonicalization, overlay, PTY, comparison, mutable-tree, or execution-policy
change is authorized beyond the exact device-security posture contract.

## 20. Security and authority controls

Require:

- repository remains read-only and byte-exact;
- no new controlled-command permission;
- no new path grant;
- no broad `/dev` grant;
- no generic character-device grant;
- no operator-terminal access;
- no public/product schema change;
- no product execution-authority change;
- no `.out` traversal or write;
- no PackageFloor or fixed-runtime access;
- no credential, keychain, TLS, SPIFFE, Vault, endpoint, or unrelated-user
  exposure;
- no raw PTY payload retained;
- producer captions remain non-authoritative;
- all generated records remain evidence/projection only.

## 21. Evidence requirements

Retain:

- complete physical-root and candidate capsule;
- command-root audit;
- exact A6R source copy and inventory;
- exact four-file source delta;
- old and new 24-schema dialects;
- exact ACL/xattr posture contract;
- exact `/dev/null` grant contract;
- vulnerable A6R causal;
- all 46 causals;
- private Darwin probe records;
- volume-capability records;
- failed-A6 bounded causal;
- A/B test, race, and build records;
- binary identities;
- A6R/A6O/A5C/A5P2/overlay nonregression;
- failed and superseded attempts;
- closing repository and predecessor verification;
- cleanup and two absence epochs;
- implementation report;
- exact path/mode/size/hash inventory.

Do not claim a fresh A6 source-control result.
Do not claim historical-policy readiness.
Do not retain sensitive contents.

## 22. Closeout and sealing

Require:

- exactly the four authorized successor source files changed;
- the other eight A6R source members byte- and mode-identical;
- repository remains:
  - T `8de797304ea944b6a155924e0d1e9e8bbe79534e`
  - inventory
    `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`
  - membership `389/375/14`
  - staged/deleted/renamed/unmerged `0/0/0/0`;
- branch/HEAD/parent/tree/upstream/index unchanged;
- candidate root and `.git` binding unchanged;
- A6R, A6D, A5T4, A6O, A5C, both failed A6 children, and every predecessor
  unchanged;
- no predecessor cache or bytecode;
- no private source, probe, cache, build, process, descriptor, socket, report,
  or temporary root remains;
- two fresh absence epochs pass;
- command-root audit proves no command used PRIMARY_R as cwd or source root.

Install the detached digest before the manifest.

Install `evidence-manifest-v1.txt` as the final mutation.

Write nothing afterward.

Perform complete read-only post-seal verification of:

- membership;
- path set;
- file types;
- modes;
- sizes;
- hashes;
- links;
- directory modes;
- final source T/inventory;
- binary identities;
- repository/predecessor identities;
- absence state;
- command-root audit.

## 23. Mandatory stop conditions

Stop on:

- physical-root mismatch;
- baseline or lineage mismatch;
- need for a fifth successor file;
- repository mutation;
- exact request or capability proof mismatch;
- generic EINVAL acceptance;
- ACL/xattr state conflation;
- unsupported represented as absent;
- malformed-request EINVAL accepted;
- permission error accepted without exact capability proof;
- another device/path/role receives the exception;
- stable identity, `rdev`, owner, mode, flags, or security checks weaken;
- regular-file/tree/executable checks weaken;
- grant scope widens;
- old schema qualifies new semantics;
- peer cannot independently recompute posture;
- any required causal survives;
- A/B test, race, or binary mismatch;
- predecessor regression;
- survivor, forced cleanup, or sealing failure.

## 24. Verdicts

Physical-root mismatch:

REPAIR10I_A6D_IMPLEMENTATION_WORKTREE_MISMATCH

Opening or lineage mismatch:

REPAIR10I_A6D_IMPLEMENTATION_BASELINE_MISMATCH

Scope expansion required:

REPAIR10I_A6D_SCOPE_EXPANSION_REQUIRED

Contract or schema transition incomplete:

REPAIR10I_A6D_CONTRACT_INCOMPLETE

Implementation, validation, cleanup, or sealing failure:

REPAIR10I_A6D_SOURCE_OR_TOOL_REPAIR_REQUIRED

Complete success:

REPAIR10I_A6D_DEVICE_SECURITY_POSTURE_PATCH_SEALED_READY_FOR_FRESH_A6_RESTART

The success report must include:

1. Repository opening/closing identity and physical-root lock.
2. A6R and amended successor T/inventory.
3. Exact four-file delta.
4. Exact old and new 24-schema dialects.
5. `effective-read-policy.v3` contract.
6. Complete eight-record outer v6 chain.
7. Exact `/dev/null` device-literal grant contract.
8. ACL and xattr posture states.
9. Exact ACL and xattr volume-capability evidence.
10. Vulnerable A6R causal.
11. Repaired exact-device causal.
12. All 46 causal outcomes.
13. Malformed-request rejection.
14. Regular-file/tree/executable nonregression.
15. Failed-A6 bounded causal and explicit non-substitution label.
16. A6R/A6O/A5C/A5P2/overlay nonregression.
17. A/B test/race/build results and binary identities.
18. Security and no-authority-widening result.
19. Repository no-mutation and command-root audit.
20. Manifest SHA-256, size, and payload count.
21. Cleanup and two absence epochs.
22. Explicit statement that fresh A6 was not restarted, the historical
    comparator was not implemented, product A/B was not run, and no snapshot
    or audit occurred.

No fresh A6 restart.
No historical-comparator implementation.
No B6.
No product A/B.
No snapshot.
No integrated ZIP.
No handoff.
No capture child.
No independent audit.
No staging, commit, push, installation, live route, remote contact, or Linux
execution.
```

## After A6D implementation

Once this amendment seals, create another entirely new A6 evidence child and rerun all five source controls from the beginning. Do not resume either failed A6 child.

The implementation and later independent audit remain separate engagements. Any changed successor bytes require new validation and a new audit before publication.  

The validator, volume-capability records, and typed posture remain proof scaffolding and evidence—not ES product architecture, execution authority, or runtime truth.  Provenance can establish the exact successor and evidence bytes, but cannot itself prove that the security-state model is sound or complete. 

### Sources

- Codex’s sealed `REPAIR10I_A6D_RECONNAISSANCE_READY` report supplied in this turn.
- Milestone 0 MVP claim and proof-scaffolding freeze. 
- Governed Execution implementation, repair, and independent-audit lifecycle.  
- Provenance limitations. 

**Confidence**

- A6D reconnaissance provenance: **0.998**
- Contract-readiness confidence: **0.975**
- Confidence that generic `EINVAL` acceptance is correctly rejected: **0.999**
- Confidence that the exact `/dev/null` typed posture is the correct bounded repair: **0.94**
- Confidence that v3/v6 versioning is required: **0.99**
- Confidence that the full five-control A6 refresh must restart after sealing: **0.999**
