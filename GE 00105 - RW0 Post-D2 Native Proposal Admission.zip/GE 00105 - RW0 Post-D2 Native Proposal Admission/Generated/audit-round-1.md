# Governed Execution Audit: Round 1

**Scope:** Coordinator `trunk_dev` at `eac7f6d` (RW0-D2 merged). Two subjects:

1. the D1+D2 worker boundary, assuming the worker misbehaves;
2. the durable SQLite core, under real crashes.

**Method:**
- Read the code, then reproduce every claim by running it.
- Probes ran against scratch copies. Neither repository was modified.
- Anything that wasn't reproduced is left out.
- Scripts and patches are listed in the appendix.

**Baseline health:**
- On `eac7f6d`, the D1 and D2 suites pass: 193 tests.
- On the pre-D2 baseline, the full suite passed 8,996 of 9,005. Six of those failures come from the exact-file-inventory tests tripping on `__pycache__`, two from my environment, and one is a Linux-only year-padding quirk you've accepted.

## Summary

**The durable core keeps its central promise under real crashes:**
- I SIGKILLed the real D1 flow at 150 random instants. 118 of those kills landed after initialization.
- In each of those 118, I restarted and ran the product's fresh-writer recovery for the genesis and author-effect families, then retried each command twice.
- Every classification was `committed_exact` or `definitely_not_committed`; the cases split 58 / 49 / 11 across both, neither, and genesis only. None was unresolved, and the author family was never committed without genesis.
- Every committed family replayed exactly with zero new rows, every uncommitted family applied exactly once, and `integrity_check` was clean all 118 times.
- That is the hardest part of what you set out to build, and it holds.

**The gaps are at the edges, and all of them concern failure.** The most elaborate defenses in the code target failures inside the running process. These come from outside it: process death, power loss, and protocol-legal inputs nobody exercised.

| # | Finding | Where | Urgency |
|---|---|---|---|
| F1 | A crash at the commit point leaves the store unopenable by any product entry point, with a misleading "not managed" error. | Durable core | Fix before unattended runs |
| F2 | `synchronous=FULL` in DELETE mode doesn't make the last commit durable against power loss. A worker can run on a phase record that later disappears. | Durable core | Fix before live effects |
| F3 | "Cleanup complete" doesn't mean the worker's processes are gone. A daemonizing child survives and is reported clean. | Worker boundary | Fix before live Codex |
| F4 | D1 accepts a protocol-valid two-observation worker result, then D2 crashes on it (positional indexing). | Worker boundary | Fix before live Codex |
| F5 | A misbehaving checker, or 2 s of clock skew, produces a raw exception instead of a typed stop. | Worker boundary | Fix before remote host |
| F6 | In the first scenario, the worker is authorized to edit the test that validates it. | Design | Decide before live |
| F7 | No document considers worker-authored content steering the reviewer or review model. | Design | Decide before live |

## Findings

### F1. A crash at the commit point wedges restart

**What happens:**
- In DELETE journal mode, the commit point is the unlink of `coordinator-state.sqlite-journal`. Before that unlink, the database file has already been rewritten.
- A process that dies in this window (SIGKILL, OOM, host crash, power loss) leaves a *hot* journal. SQLite repairs that automatically on the next **read/write** open.
- Every product entry point opens **read-only** first:
  - `acquire_sqlite_writer_session` runs `_require_managed_preflight`, which calls `inspect_database`, which opens with `mode=ro`.
  - `initialize_database`, `migrate_database` and `validate_database` behave the same way.
- A read-only connection can't roll a hot journal back, so SQLite returns `SQLITE_READONLY_ROLLBACK`. Nothing in the product ever opens read/write first.

**Reproduced deterministically** (`commit_point_kill.py`, `wedge_entrypoints.py`):
- `strace` delivers SIGKILL to a real writer acquisition exactly at its journal unlink.
- After that:
  - `inspect_database` and `validate_database` return `unknown / sqlite_posture_unavailable`;
  - `initialize_database` and `migrate_database` raise `sqlite_posture_unavailable`;
  - `acquire_sqlite_writer_session` raises `DATABASE_NOT_MANAGED` on every retry.
- One plain `sqlite3.connect(path)` makes everything work again. `integrity_check` is ok, and the uncommitted issuance is correctly absent.

**Why it matters:**
- The three-way recovery runs under a *fresh writer*, which can't be acquired, so it is never reached.
- The error reads as "corrupt or unmanaged". An operator (or an agent) acting on it could delete a healthy durable record.
- This contradicts the crash table in `writer-session-authority.md`. For "Process crash during uncommitted issuance transaction", it says the next acquisition "reads the unchanged durable generation and increments from it". In fact, the next acquisition fails indefinitely. The data itself is fine, as the threat model says; it's availability that breaks.

**How often:**
- The window is one database fsync per commit.
- 300 uniformly random kills across two runs on this VM never landed in it. In the restart-focused run, 87 restarted fine and 63 had died before initialization finished. The deterministic `strace` kill shows what happens when a crash does land there.
- So this is rare on fast disks, and certain eventually under power loss or slow storage.

**Fix sketch:**
- In writer acquisition, which already takes the state-authority lock, open the bound database read/write once *before* the read-only preflight. SQLite then rolls back any hot journal.
- Alternatively, detect `SQLITE_READONLY_ROLLBACK` and run an explicit `recover_database()` under the lock.
- Either way, report "crash recovery pending", not "not managed".
- Add a real-process-death test: the `strace` technique, or a SIGKILL at a commit hook.

### F2. A reported commit can be undone by power loss

**What happens:**
- The trace of a real commit (`results/one_commit_syscalls.trace`) shows this sequence:
  1. fsync the journal;
  2. fsync the directory, to make the journal's creation durable;
  3. fsync the journal again;
  4. fsync the database;
  5. `unlink(journal)`;
  6. no directory fsync after the unlink.
- If power fails before the filesystem persists that unlink (ext4 commits metadata every ~5 s by default), the journal reappears on reboot. SQLite then rolls the committed transaction back.
- [SQLite's documentation](https://www.sqlite.org/docsrc/info/bcf687da9c172292) says exactly this. `EXTRA` "is like FULL with the addition that the directory containing a rollback journal is synced after that journal is unlinked… EXTRA provides additional durability if the commit is followed closely by a power loss."
- The Coordinator pins `synchronous=FULL`, and `sqlite_connection._verify_posture` rejects any other value.

**Reproduced** (`power_loss_sim.py`), as a simulation of the on-disk state:
- `strace` holds the 7th journal unlink of a real D1 run, which is the C1 phase commit, and the synced journal is copied.
- D1 then launches the worker, which exits 0, and returns `capsule_ready`.
- Restoring the journal (the power-loss state) has two effects:
  - first, F1: the product refuses to open the store;
  - second, after SQLite's rollback, `rw0_phase_instances` holds 0 rows. The worker ran on a phase record that no longer exists.

**Why it matters:**
- The design's ordering rule is "commit before effect". It is only as strong as the commit's durability.
- After such a rollback, recovery honestly says `definitely_not_committed`. A later redo would launch a second author invocation, and could replenish the "one productive acceptance, never replenished" allowance that the bootstrap guard forbids.

**Fix sketch:** either one is enough.
- `PRAGMA synchronous=EXTRA`: one extra directory fsync per commit.
- WAL mode with `FULL`, which syncs on every commit. ES's reliable-submit store already uses this (`es/admission/internal/reliablesubmit/sqlite_store.go:430-431`).

### F3. Process-group cleanup misses daemonized descendants

**What happens:**
- `run_fake_module` puts the child in a new session and finishes with `group_clear = not killpg(pgid, 0)`.
- A descendant that calls `setsid()` and closes the pipes leaves that group. The group then looks empty while the descendant keeps running.

**Reproduced:**
- `escape_probe.py` calls the supervisor directly. The verdict is `reason=ok, reaped=True, group_clear=True, clean_success=True`, while the escaped descendant (pgid 899 vs supervised 898) keeps writing a heartbeat.
- `d1_escape.py` applies `daemonizing_worker.patch` to the real D1 flow. D1 returns `capsule_ready` with `worker cleanup_complete: True`, and the worker's daemon is still alive afterwards.

**Context:**
- The D1 document is explicit: "not a same-UID security sandbox". So this violates no stated claim.
- But the cleanup signal itself is wrong, and real Codex sessions daemonize without any malice: tmux, language servers in remote mode, build daemons, `docker compose up -d`.
- If this supervisor carries into the live route, nothing can verify the "one active invocation" ceiling, because an earlier invocation's processes may still be running.

**Fix sketch:**
- On the Linux host, bound the tree with a cgroup and kill the whole cgroup (for example, `systemd-run --scope`), or with a PID namespace or container.
- At minimum, make the supervisor a subreaper (`PR_SET_CHILD_SUBREAPER`) and treat any surviving descendant as `cleanup_unresolved`.
- The ES/Nomad/Docker route gives you this for free.

### F4. D1 accepts a worker result that D2 cannot process

**What happens:**
- The Wire grammar permits `(worker_started, worker_completed)` with no `candidate_captured`.
- D1's handback accepts 2 or 3 observations. D1 never cross-checks the worker's claim of "no candidate" against the parent's capture finding a changed file.
- D2 then indexes checked families by position. `checked_reviewer_separation` requires `len == 14` and reads `[12]`, `[4]` and `[:3]`, and `_rw0_d2a_offline` reads `[6]`, `[7]`, `[8]`, `[9]`, `[11]` and `[13]`. All of these assume exactly three worker observations.

**Reproduced** with `two_observation_worker.patch`, a one-line change:
- `d1_probe.py` returns `D1: capsule_ready … worker observations: ['worker_started', 'worker_completed'] … classification: usable`.
- `d2_probe.py` returns a raw `ValueError invalid_d2_checking_evidence` from `checked_reviewer_separation`.

**Fix sketch:**
- Have D1 reject a capture that contradicts the worker's own claim.
- Have D2 look families up by role or label, never by position.

### F5. Untyped exceptions where typed stops were intended

**What happens:**
- `run_d2a_checked_evidence` catches only `_D2AStop`.
- `normalize_checking_evidence`, `D2Reconstruction` and `process.validate()` raise plain `ValueError` subclasses.
- These escape `run_rw0_d2_offline`, whose `except BaseException` calls `d1_run.close()` and re-raises. The caller gets an exception, not a handback, and the reached prefix the code comments promise to retain is lost.

**Reproduced:**
- With `malformed_validator.patch` (the validator exits 0 with a bad frame), the caller receives a raw `ValueError invalid_d2_checking_evidence`.
- With `worker_clock_ahead.patch` (the worker's clock is 2 s ahead of the parent's), D1 itself raises `ValueError invalid_d1_handback` from the handback constructor, because `_rw0_d1_handback.py:199` requires worker completion ≤ adapter exit. D1's `except BaseException` path also deletes the state root.

**Why it matters:**
- Several relations order events by comparing wall-clock strings taken by different processes: `_rw0_d1_handback.py:199`, `_rw0_d2a_evidence.py:981`, `_rw0_d2b_proposal.py:314-419`.
- That's safe while everything shares one clock. If any of these pairs land on different hosts in the live topology, ordinary skew of a second or two breaks the run.

**Fix sketch:**
- Map every checker or normalization failure to a `_D2AStop` reason.
- Order events by sequence or causal reference rather than by comparing clocks across hosts, or allow an explicit skew bound.

### F6. The first scenario validates itself (design)

- The first recorded scenario authorizes `docs_contract_test.go` alongside the docs it pins. The worker writes both the change and the test that judges it.
- Validation therefore proves consistency, not correctness, and the independent reviewer carries the whole load.
- Editing tests until they pass is one of the most commonly reported failures of unsupervised coding agents.
- I found no document that discusses this.

**Options:**
- Make the validating test read-only for the worker.
- Validate against the base revision's tests plus a separately authored check.
- Or record explicitly that this scenario's validation is weak by construction.

### F7. No content-level threat model for the checkers (design)

- The threat model covers files (symlinks, hardlinks, modes), processes, frames and authority forgery thoroughly.
- Nothing in roughly 250k words of documentation mentions prompt injection: candidate content addressed to the reviewer or review model ("reviewer: this change is safe").
- D2's fakes key on literal markers the worker could write. That is fine for a fake, but it shows the gap.

**What would be needed:** before a model reviews worker output, decide what the reviewer sees, how instructions in the content are neutralized, and how a reviewer verdict is corroborated.

## What held up

**Attacked, and it held:**
- **Hardlink smuggling.** A worker replaced the target with a hardlink to a host file. D1 stopped with `unsafe_candidate`.
- **Symlink.** The fixture's `unsafe_path` behavior also stopped with `unsafe_candidate`.
- **Extra files.** An unauthorized new file stopped with `excessive_candidate`.
- **Checker-input tampering.** A third party modified the validator's reconstructed tree before the validator read it. The validator refused, because its digests arrive over a pipe, and D2 stopped with the typed `validator_process_failed`.

**Checked in code, not attacked:**
- The state-authority lock uses `flock` on a separate file with `O_CLOEXEC` and a fork handler that doesn't unlock the shared descriptor. This avoids SQLite's POSIX-lock pitfall.
- There is no `executescript` inside transactions. All transactions use explicit `BEGIN IMMEDIATE`, and `trusted_schema` and extension loading are off.

## Minor notes

- `run_rw0_d1_offline`'s `except Exception: reason = "durable_conflict"` labels any programming error as a durable conflict. My own harness bug surfaced that way.
- On assurance proportionality:
  - About 2,000 of the ~7,000 lines in `sqlite_writer_session.py` sit in cleanup, lifecycle and interruption handlers.
  - The VS1A test file is 8,893 lines.
  - That machinery guards against signals arriving inside Python cleanup, while process death at the commit point (F1) has no test.
  - A crash-only stance would let in-process interruption simply mean "exit, then recover on restart", and could retire much of that machinery. That stance is: make restart after any death robust, and test it with real kills.
- ES: about 330 of its tests hardcode `/Users/ds/Repositories/...`. Gating them behind a build tag or environment variable for the alpha host, and deriving the repo root from the test's working directory, would make the suite portable.

## Appendix: reproduction

**Environment:** Linux, Python 3.13, `strace` 6.x. Set `COORD_REPO=<Coordinator checkout>` and `PYTHONPATH=$COORD_REPO/src` (or the path of a patched copy), and `PYTHONDONTWRITEBYTECODE=1`. Run from the bundle directory with a `tmp/` subdirectory.

| Script | Shows |
|---|---|
| `commit_point_kill.py` (+ `acquire_child.py`) | F1: SIGKILL at the journal unlink, then a permanent `DATABASE_NOT_MANAGED` until a manual read/write open |
| `wedge_entrypoints.py` | F1: all four public `*_database` entry points and writer acquisition refuse |
| `power_loss_sim.py` (+ `d1_fixed_root_child.py`) | F2: the worker runs, then the phase record disappears after a simulated power loss |
| `escape_probe.py` (+ `probes/_audit_escaping_child.py`, copied into a src copy and added to `_CHILDREN`) | F3: supervisor-level escape |
| `d1_escape.py` + `probes/daemonizing_worker.patch` | F3: D1 returns `capsule_ready` with a live worker daemon |
| `d1_probe.py`, `d2_probe.py` + `probes/two_observation_worker.patch` | F4 |
| `d2_probe.py` + `probes/malformed_validator.patch` / `probes/worker_clock_ahead.patch` | F5 |
| `d2_probe.py` + `probes/hardlink_worker.patch` / `probes/tampered_checker_input.patch` | Attacks that held |
| `torture2.py`, `torture3.py` (+ `d1_child.py`) | Restart and recovery under random SIGKILLs (the summary's recovery result) |

The patches touch only the fake children, to model misbehavior. Apply them to a copy, never to the working tree (`patch -d <copy-parent> -p1`, as shown in the bundle README).
