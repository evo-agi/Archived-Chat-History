# Coordinator F1 blocked-package review and engineering decision

## Routing, status, and effect ceiling

This is the data-only source/evidence review requested in the current ChatGPT conversation. It is not a Codex assignment, an independent whole-candidate audit, or authority to edit, execute, recover a database, stage, commit, retry an audit, or publish. The implementation writer remains idle. The separately commissioned Opus reviewer receives no assignment.

**Decision:** preserve the blocked result and refusal-only partial source. Select a narrowly corrected F1 recovery contract based on the *files the recovery operation can use*, rather than a retrospective proof that an interrupted connection never attached another database. Do not re-enable the attempted code as-is. The supplied counterexample does not justify selecting a custom VFS or a new containment subsystem. Recovery availability, error compatibility, provenance, and validation still need a newly identified successor.

This expressly changes the prior F1 mandate's interpretation of its one-database/external-path condition. It is not a retroactive PASS for an implementation stopped under that condition.

## 1. Authenticated subjects

The uploaded F1 ZIP is 4,030,365 bytes, SHA-256 `ab6bb4d1625d63440aaf6aecbec79a55b7aedcbcaca43870a87ce5f70565c43f`. It contains 416 uniquely named safe regular members, 22,353,628 uncompressed bytes, and 415 package-manifest-covered members plus the manifest itself. All covered sizes, SHA-256 values, and archived OS modes match. The report is 10,131 bytes, SHA-256 `3d9b3c53f86e94a43672b5c16008bfbd379f8dee321c30650d2a4cdf087ea132`.

The original ReviewPackage.zip was independently rehashed: 14,481,457 bytes, SHA-256 `d9b4d61e212893b48ba1952c3b5370c09874ca2e70798decc36bc4fdbd893d9b`.

| Subject | Independently reconstructed tree | Raw source and delta |
|---|---|---|
| Original native-proposal candidate | `17ee7db2925ed03ebc1614880fba5ec83d102d8c` | 298 original endpoints; preserved and unaccepted. |
| Attempted writable F1 source | `ce18ef08e935e69980c7c5adf3486c39685df4c9` | 299 endpoints: 12 modifications plus one creation against the original. |
| Refusal-only partial source | `b2e958c6a5d894fdf0d14dd5c821582c1d067489` | 299 endpoints: 11 modifications plus one creation against the original. |

All source sizes, SHA-256s and Git blobs match their respective source manifests. Both F1-only unified deltas were independently reconstructed against original raw endpoints with a data-only hunk reader; all 13 attempted and 12 refusal-only endpoint results match. No Git or patch program was run. All five migration SQL resources and the historical schema SQL remain byte-identical. The known OS-0600 test remains represented as Git mode 100644. `sqlite_security.py` and the original filesystem-binding regression module are byte-exact originals in the refusal-only subject.

**Archive layout correction:** `source/` is the refusal-only subject. Its manifest and delta are `evidence/blocked-source-manifest.json` and `evidence/blocked-f1-only.diff`. The attempted subject is reconstructed from the original candidate plus `attempted/changed-source/`; its manifest is `attempted/final-source-manifest.json`. The report's `final-source/` and `blocked-source/` names describe former local execution directories, not literal source roots in this delivery. No source is selected from a directory name alone.

The nested EarlyF1Checkpoint.zip matches its 31,715-byte identity and `9c2751992ca0fba882bbb4e477503b07df9f993996af36675063abd09010ae79` SHA-256. All eleven of its covered members authenticate. No SQLite database, journal, raw Git index, cache, or credential payload is included in the delivered archive.

## 2. The decisive probe: supported conclusions and limits

Source: `attempted/probe_attached_outside_decisive.py:7–29`; retained output: `attempted/probe-attached-outside-decisive.log:1–6`.

The script initializes a synthetic main database. A task-owned child uses a direct SQLite connection, attaches an outside-root sibling, creates its marker table, begins a transaction, fills a new main table sufficiently to spill, inserts one auxiliary row, and calls `os._exit(0)` **without issuing COMMIT**. This is a real interrupted transaction fixture, not a product-command execution or the original unlink-window experiment.

The retained output records:

```text
inspect DatabaseClassification.UNKNOWN recovery_needed
UNSAFE ADMISSION 1
after main journal False
after external journal True
```

The label `UNSAFE ADMISSION` is the probe author's interpretation. The observable facts are successful session generation 1, removal of the main journal, and existence of the sibling journal afterward. The script/log do not record the sibling's header, engine recovery classification, before/after bytes, or an I/O trace. Therefore they do not establish that the sibling journal was hot, that recovery opened/modified it, or that either database suffered corruption. They also do not prove absence of outside-root I/O.

The direct probe lacks its own retained argv/environment/source-hash receipt. Its association with the attempted tree is supplied by the package/report and the surrounding retained source/validation records, not by a self-contained invocation receipt. This limits exact runtime attribution; it does not erase the script, observed outcome, or the source-supported inability of the selected predicate to discover a hidden prior attachment.

Earlier same-root attachment evidence is different: `attempted/probe_attached.py:5–24` and its log show `recovery_unsafe` when a sibling journal is visible in the main root. The attempted helper's local directory scan explains that refusal; it is not a general attachment detector.

The original hot-journal defect now has additional inspected implementation evidence: `evidence/checkpoint-original.log` records real numeric 776 and original `database_not_managed`; `checkpoint-successor.log` records generation 2 after previously committed generation 1; `checkpoint-unsafe.log` records a 0644-journal refusal. These are retained executions, not experiments rerun by ChatGPT. The original Opus reproduction materials remain separate.

## 3. Contract decision: recovery dependencies, not unknowable history

The preexisting owner contract provides an owner-private local filesystem model, fixed database naming, no arbitrary SQL, and limited same-account malicious-process resistance. See original candidate `.docs/sqlite-operations-and-recovery.md:239–273` (same unchanged passage at refusal-only `source/.docs/sqlite-operations-and-recovery.md:265–297`) and `source/.docs/sqlite-threat-model.md:288–312`. It does not establish authenticated provenance for every raw SQLite connection that might have previously accessed the file.

The previous F1 mandate §4D–E prohibited implicit attached/super-journal recovery and required an enforceable external-path boundary. The attempted implementation construed that as proving the absence of all prior external attachment. The source probe demonstrates why the selected local checks cannot establish that history. **Do not turn that extra historical claim into a permanent product requirement by inertia.**

Select the following successor target:

- Recover only the bound configured main database and its fixed adjacent DELETE rollback journal, under the existing authority lock and existing owner-private threat model.
- Require precise engine recovery-needed classification plus independent filesystem/journal eligibility; neither a filename nor code 776 alone proves managed schema or grants a writer.
- Refuse super-journal/path-bearing recovery dependencies, unsupported auxiliary objects, incompatible posture, unsafe links/modes, and observed binding changes before the relevant write-capable recovery access. Do not follow journal-supplied paths or recover a sibling database.
- Do not claim to prove the prior connection's complete attachment set. A disconnected sibling journal somewhere else is not itself an observable recovery dependency and does not alone establish unsafe recovery of the main file.
- Preserve post-recovery schema/catalog/durable-writer validation before issuing a writer. Recovery is a storage effect; refusal afterward means no writer issued, not necessarily no storage changed.
- Keep same-account race limits explicit. Pre/post descriptor checks are not a race-free custom VFS. The implementation must justify the exact supported engine/VFS and all relevant access paths; it cannot enable an unrestricted fallback on uncertainty.

This replaces the retrospective no-attachment requirement with a concrete operational boundary. The old counterexample and its blocked disposition remain intact. A future regression for that fixture must assess main recovery correctness and external noninterference, not merely demand refusal because the fixture author knows an attachment occurred. Byte equality alone cannot prove no external reads; the validation claim must distinguish effects it actually observes.

### External technical corroboration, distinct from package evidence

SQLite's official rollback locking description explains separate per-database journals, cache spill before COMMIT, and later super-journal creation. The version-3.49.1 pager source reads a super-journal name from the journal tail and conditionally consults it during playback/cleanup (`readSuperJournal`, `pager_playback`, `pager_delsuper`). This supports separating current recovery dependencies from earlier attachment history. It does not authenticate the installed build/VFS or reproduce this fixture.

References: SQLite `lockingv3.html`, §§4–5; official SQLite repository tag `version-3.49.1`, `src/pager.c`, especially lines 1240–1260, 2683–2689 and 2814–2833 (web display uses zero-based line labels). These are additional primary-source checks, not replacements for the supplied owning contract.

The attempted helper at `attempted/changed-source/src/ge_nwp_coordinator/sqlite_security.py:220–284` performs fixed-name, private-file, identity, header-size and journal-tail checks. Its footer exclusion is relevant to *dependencies*, but passing that check does not establish all-history provenance. Reusing this code is not approved by this review: source/runtime guards and compatibility tests remain to be completed under the selected narrower target.

## 4. Four FULL failures are an attributable compatibility regression

All four named failures are the `database`, `root`, `lock`, and `hardlink` parameters of `test_writer_acquisition_rechecks_filesystem_binding_before_publication` in `tests/test_b3c1b_rollback_only_writer_fencing.py:1033–1118`.

Each enters the expected SQLiteWriterAcquisitionError branch, then fails at line 1095: observed `WRITER_ACQUISITION_FAILED`, expected `DATABASE_NOT_MANAGED`. This is not an observed leaked writer session or a successful recovery bypass. It is a real contract/test regression on the healthy acquisition route, not a reason to dismiss the tests.

The attempted code's cause is source-visible: COMMIT sets `committed=True` at `sqlite_writer_session.py:7252–7253`; publication rechecks the binding at :7261–7262; the newly added catch at :7290–7303 maps binding failure after commit to `WRITER_ACQUISITION_FAILED`. The original catch returned `DATABASE_NOT_MANAGED`.

The existing test itself expects the next issuance to be generation 2 at :1114–1116. Consequently its original reason never promised that no issuance row had committed. Keep the original healthy-path vocabulary and behavior unless a distinct owner-level contract change is deliberately selected; do not change the assertions just to green this patch. Recovery-specific states can remain separate.

The four failed nodes stop at the reason assertion, so their later privacy/registry/reacquisition assertions receive no execution credit on that run. The later 93-test run passes them on the different refusal-only subject, whose original exception mapping is restored.

## 5. Validation reconciliation and source-credit correction

| Evidence | Reconciled result | Subject/limit |
|---|---|---|
| `attempted/final-collect.txt` | 9,215 distinct IDs | Manifest-bound attempted final source. |
| `attempted/final-run.txt`, `final-junit.xml` | 1,525 passes; four failures; exit 130 | Interrupted, not FULL success. XML contains 1,529 named cases plus one unnamed empty unfinished element; no extra pass is credited to it. |
| `validation/focused-3.xml` | 291 passes, zero failed/error/skipped cases | Earlier writable-development source; **not** exact final attempted bytes. |
| `validation/target-7.xml` | 24 passes | Another earlier source identity; not exact final attempted bytes. |
| `validation/blocked-target.xml` | 8 passes | Refusal-only subject, source binding recorded by blocked command manifest. |
| `validation/blocked-focused.xml` | 277 passes | Same refusal-only subject; contains all 8 target cases. |
| `validation/blocked-binding.xml` | 93 passes | Same refusal-only subject; disjoint from those 277 IDs. |

**Additional receipt limit:** comparing `validation/focused-source-3-manifest.json` with `attempted/final-source-manifest.json` finds four different endpoints: operations/recovery documentation, writer-session documentation, `sqlite_writer_session.py`, and the new test module. The writer-source sizes are 308,922 versus 308,920 bytes. Therefore the report's 291-pass result cannot certify the later attempted tree. `target-source-7-manifest.json` also differs in operations documentation and writer source. The raw earlier writer contents are not supplied as a complete earlier source tree; no causal explanation for those byte differences is invented.

The refusal-only executions total 378 occurrences but 370 distinct test IDs. They establish neither writable recovery nor final selector-free validation. The source-binding and command records were inspected as records, not independently rerun. Historical 9,191 implementation passes and all original audit noncoverage remain separate.

## 6. Raw-index issue: retained limit, not a repair conclusion

Opening and attempted-prefull records carry 32,314 bytes and SHA-256 `7bd47e04c4dd62d43b33d2e01fa39df585b9df04f6cf809789e35dab36429a20`. The refusal-only manifest and terminal observations carry the same size but SHA-256 `7e27326ab9b242d5bb56e41286d561be4dffed43dc3d377b5bffc75c8ffd5b07`.

No before/after raw index payloads are retained. Thus the exact changed fields, extension data, stat-cache content, actor and cause cannot be independently recovered from this package. Do not describe the change as harmless refresh, stage mutation, or tool action without evidence. No reset or attempted reconstruction of the old index is selected.

There is narrower semantic evidence. The unchanged collector's code compares the complete stage-zero map with the baseline tree at `evidence/provenance_collector.py:105–108` before its hardcoded creation-count failure at :109–111. Both retained final collector attempts reach that latter failure, supporting the earlier semantic comparison at those executions. The terminal helper checks empty staged-diff stdout but does not retain that command's exit code or full stage-zero listing (`terminal_observation.py:13–17`); it is not a lossless terminal semantic-index record.

The old exact-byte preservation gate remains failed. **Recommended later continuation treatment, not performed here:** authenticate the known refusal-only source and named protected Git state, read and retain the actual complete semantic index and current raw index without reset/refresh, require the semantic map to equal the unchanged baseline, and establish an explicitly prospective preservation interval. Missing historical raw bytes need not freeze source design forever, but cannot be replaced by a claim that the prior interval was preserved. Any new semantic/source/protected-state mismatch blocks mutation.

The complete retained ref inventories do support the selected scoped distinction. H1 and H2 raw serializations reproduce their 53/54-record hashes. Canonically sorted F1 opening, pre-FULL and terminal inventories match at 56 records; the opening raw ordering differs, not the records. No actor attribution or retroactive resolution of the original H1/H2 intervals follows.

## 7. Collector correction is independent

The historical collector is byte-exact, SHA-256 `b61b4a4e949e564e206e6d195791f56585c437d4130c86731e5b4be713c5da7a`. It hardcodes twelve creations. This task authorized a new thirteenth test, making that unchanged final gate incompatible with the allowed work. Both failure logs preserve the exact failing line.

A later handoff must explicitly version only the successor's expected path inventory and source identity treatment, retain the original collector/results, and enumerate all thirteen creations rather than relax to an arbitrary count. Do not delete the required regression or normalize away raw-index drift. No new general provenance framework is needed.

## 8. Immediate continuation and preserved holds

The package supplies enough evidence to choose the narrower F1 design now. No new package, Opus response, replay of the historical crash campaign, or full reconnaissance is a prerequisite for that decision.

The next executable assignment should be a separately issued F1 continuation against the exact refusal-only source. It must begin with the prospective provenance reconciliation above, explicitly version the collector inventory, revise the owning recovery contract/tests together, preserve the healthy acquisition reason, and finish source-bound synthetic validation including the independently discriminating recovery-boundary cases and a final selector-free collection/FULL execution. No part of that work is executed or authorized by this review document.

Do not simply restore the attempted tree, accept the refusal-only state as recovery completion, or start Unit 2 on an implicitly accepted checkpoint. All migration/schema bytes, DELETE/FULL posture, domain transactions, and D2/native-admission semantics remain out of this F1 redesign. F2 is not solved by recovery availability.

The original native-proposal candidate remains unaccepted. F4, malformed-input F5, NPA-WITNESS-01, and the earlier qualified live-boundary concerns remain. Provider audit access remains unresolved; no retry is selected. Both historical provenance-mismatch records and their limits remain. Candidate-specific A01–A12, connected proof, discriminating controls, and independent collection/FULL obligations remain undischarged; these implementation records are not substitute audit coverage.

## Inspection limits and confidence

Inspected: archive metadata/manifests; original and both F1 source identities/deltas; governing guidance and relevant recovery/connection/filesystem contracts; complete F1 production changes; decisive fixture and logs; changed/new tests and four failed assertions; JUnit/collection/source-binding records; collector and retained index/ref/config observation code and outputs. Not a semantic audit of every line of all 299 files.

No repository command, candidate import, uploaded program, database open, test, crash probe, migration, live-checkout access or mutation occurred. Data-only SHA calculations, source/diff parsing, XML/JSON inspection, and independent Git-object hash construction ran in this conversation's artifact workspace. Public primary SQLite documentation/source was read separately for the specific engine mechanism; no target host was contacted.

Confidence: artifact/source provenance 0.99; interpretation of the inspected probe and four failure assertions 0.97; narrower engineering contract direction 0.94. Runtime correctness of any future recovery implementation remains unestablished. Historical raw-index cause and exact installed SQLite/VFS conformance remain unresolved.
