# Native proposal/admission candidate: source comparison and bounded repair scope

**Audience and status:** engineering decision record for this ChatGPT conversation. This is **not a Codex assignment, a new-chat handoff, an Opus assignment, or an independent-audit verdict**. It authorizes no repository change, execution, test, crash experiment, migration, audit retry, commit, or publication.

## 1. Result and exact subject

The previously missing source dependency is now resolved. The uploaded `ReviewPackage.zip` is the preserved native post-execution proposal/admission candidate:

- Archive: **14,481,457 bytes**, SHA-256 `d9b4d61e212893b48ba1952c3b5370c09874ca2e70798decc36bc4fdbd893d9b`.
- Independently reconstructed candidate tree: **`17ee7db2925ed03ebc1614880fba5ec83d102d8c`**.
- Baseline commit recorded by the package: `eac7f6df5f281138dd0640c5cd47b9924c8390f8`.
- Independently reconstructed baseline tree: `061c43c41228310134a30f3b79291bba3e44f3f2`.
- Candidate: **298 files, 57 modifications, 12 creations, 229 unchanged baseline paths**; 17,630,664 raw source bytes.
- The 545-member outer ZIP has 544 manifest-covered members; all covered sizes, SHA-256 values, and archived permission modes matched. The self-excluded manifest is protected by the outer ZIP identity.
- All 298 source endpoints matched the canonical manifest's byte length, SHA-256, Git blob identity, and archived mode. All 286 embedded baseline endpoints and all 57 raw before payloads matched their corresponding baseline bytes.
- The embedded baseline ZIP matches the previously supplied checkpoint. All 319 manifest-covered baseline members matched. Both Git tree IDs were reconstructed directly from path/mode/blob data, without Git or repository commands.
- All three retained canonical-manifest passes are equal: 108,510 bytes, SHA-256 `b66a42d5f4b4e87b06ec0fcf1fbf184cbbb957d7223a3e50f32c976dbd63ceed`.
- The tracked diff is 148,261 bytes, SHA-256 `22165ebc894ae732fb17a0d1c0cbc034d985a7dfedab224a4968c08a9489216e`. Its bytes authenticated; this pass did not execute a patch replay.

These are **artifact observations**, not fresh observations of the local repository, index, configuration, refs, or platform execution. The source tree is an uncommitted candidate identity, not a new commit.

This record supplements the earlier `Coordinator_Bounded_Repair_Specification_and_Candidate_Impact_Map.md`: its “candidate source unavailable” limitation no longer applies to the source paths inspected below. It does not replace the original candidate or promote the earlier design to implementation.

## 2. Engineering disposition

The source comparison confirms that the mechanisms underlying **F1, F4, and malformed-input F5 remain in this exact candidate**. This is now direct candidate-source evidence, not merely an inference from its implementation report.

One additional candidate-specific source finding arose while inspecting the required safe-witness dependency: **NPA-WITNESS-01**, a missing final write-time association between the supplied child-outcome witness and the original run. It is separate from Opus's merged-baseline findings and was not dynamically reproduced here.

The selected sequence remains:

1. **Unit 1: governed recovery entry (F1)**, with the narrow filesystem/error-classification contract described below.
2. **Unit 2: legal D2 layouts and typed malformed-input stops (F4/F5)**, with the explicitly added native safe-witness association correction.

Keep the two units' deltas and validation attributable separately. Do not reset, discard, or alter the preserved candidate merely to obtain a clean starting point. A later authorized repaired successor needs a new identity and an exact delta from this candidate.

The original candidate remains **unchanged, unaccepted, and on correctness hold**, and its implementation writer remains idle. No additional Opus response is a prerequisite for these source-based decisions.

## 3. F1: the candidate did not change the recovery-blocking functions

The candidate adds four native-proposal methods to `sqlite_writer_session.py`, but its complete `acquire_sqlite_writer_session`, `_require_managed_preflight`, and `_raise_writer_state_malformed_if_present` functions are byte-identical to the merged baseline.

| Function | Baseline lines | Candidate lines |
|---|---:|---:|
| `acquire_sqlite_writer_session` | 7073–7188 | 7184–7299 |
| `_require_managed_preflight` | 7191–7199 | 7302–7310 |
| `_raise_writer_state_malformed_if_present` | 7202–7216 | 7313–7327 |
| `sqlite_migration._assess_location_database` | 1001–1038 | 1021–1058 |
| `sqlite_migration._assess_location_database_history_only` | 1041–1078 | 1061–1098 |
| `sqlite_migration._classify_existing_file_header` | 982–998 | 1002–1018 |

The function comparisons used complete raw source spans, not line-number similarity. The candidate's migration changes add the 0005 catalog/schema inventory and zero-seed check; they do not fix these assessment paths.

Acquisition still requires observational managed preflight before acquiring the authority lock and again before the bound writable open (`sqlite_writer_session.py:7184–7199`). The assessment opens read-only and collapses connection failures into its existing assessment/error path (`sqlite_migration.py:1021–1058`). The unchanged connection adapter turns SQLite operational errors into a generic posture failure (`sqlite_connection.py:408–434`). The owning acquisition ordering and crash-next-acquisition promise are also unchanged (`.docs/writer-session-authority.md:561–585,671–678`).

**Conclusion:** the candidate inherits the source-level recovery-entry conflict. This does not independently reproduce Opus's interruption timing, returned error sequence, filesystem behavior, or manually repaired database.

### The auxiliary-file boundary is not already implemented

The existing binding contains three identities: state root, authority-lock file, and database file (`sqlite_security.py:69–104,162–201`). Existing root and regular-file checks provide ownership, mode, regular-file, and single-link constraints (`:335–340,417–432,446–449`). The bound connection validates those objects before and after opening the existing database (`sqlite_connection.py:322–365`).

There is **no corresponding rollback-journal identity in that binding**. A source search and inspection of the three relevant owners—`sqlite_security.py`, `sqlite_connection.py`, and `state_authority_lock.py`—does not reveal a recovery-specific auxiliary-file admission mechanism. That is a limited source observation, not an assertion about every VFS operation.

Therefore the repair cannot simply reorder the current calls and claim its existing binding already covers recovery.

### Selected Unit 1 scope

The direct production edit scope is:

| File under `src/ge_nwp_coordinator/` | Required change |
|---|---|
| `sqlite_connection.py` | Preserve a closed, machine-derived recovery-required condition through the private error boundary; add the recovery operation only within the existing connection owner. No exception-text recognition or generic writable gateway. |
| `sqlite_migration.py` | Carry that distinct observational condition without classifying it as established schema corruption. Observation and validation remain nonrecovering; ordinary operations must not auto-migrate. |
| `sqlite_errors.py` | Add only the safe recovery-required/unresolved diagnostics needed to avoid reporting known recovery need as generic unmanaged state. No raw exception, path, SQL, journal content, or credential payload. |
| `sqlite_security.py` | Define and enforce the supported auxiliary-file eligibility checks using the existing root/lock/database binding. Do not claim journal provenance merely from a filename or header. |
| `sqlite_writer_session.py` | Add the narrowly admitted recovery branch under the existing authority lock, then preserve post-recovery validation, issuance fencing, generation rules, cleanup, and final session publication. |

`state_authority_lock.py` is a **reuse and validation dependency**, not a selected redesign. Its existing resource API can capture and validate the database binding while holding the lock (`:172–179,287–308`). Shared transaction/controller, Section 41/C1 mutation semantics, and public `StateStore` are not selected edit surfaces for Unit 1.

The recovery branch is limited to the configured existing private state location and supported single-database rollback-journal arrangement. Before a write-capable recovery open it must establish the root/lock/database binding and the permitted auxiliary-file posture, including private owner/mode, regular-file/single-link/no-follow checks where applicable. Unsupported WAL/SHM or multi-database recovery arrangements must not be adopted implicitly. No application-level journal restoration, deletion, rewriting, or generic repair is selected.

SQLite's supported recovery behavior owns rollback; the application owns eligibility, custody, validation, and truthful outcomes. If the connection/VFS cannot support the selected auxiliary-file constraints, the implementation must report that specific unresolved design boundary rather than weakening it. This pass has not verified VFS behavior or selected a custom VFS.

After eligible recovery, revalidate bound identity, current managed schema/catalog, invariants, and writer state before the existing issuance transaction can return a writer. Keep the lock held through the transition; a pre-lock recovery observation is not a capability to operate on a different later file.

**Intentional contract change:** engine recovery may change database/journal bytes before managed-schema status is known. If later schema validation rejects the store, report no writer issuance—not “the store was untouched.” Obvious absent/empty/invalid inputs retain their existing noncreating refusal behavior. An older exact catalog still requires explicit administrative migration. Recovery neither reconstructs a dead credential nor authorizes another domain effect or first-live incarnation.

Unit 1 leaves the current journal/synchronous policy unchanged. That is scope isolation, **not** resolution of F2.

### Governing documents and test dependencies

Update the affected current contracts in `.docs/writer-session-authority.md`, `.docs/sqlite-bootstrap-and-migrations.md`, `.docs/sqlite-operations-and-recovery.md`, and `.docs/sqlite-threat-model.md`. Do not rewrite historical tranche records into current guarantees.

Primary regression surfaces are `tests/test_sqlite_b2c_writer_session.py`, `test_sqlite_b1_connection_posture.py`, `test_sqlite_b1_filesystem_security.py`, `test_sqlite_b1_migrations.py`, `test_sqlite_c2b1_migration_framework.py`, and `test_state_authority_lock.py`. Existing authority/boundary consumers include `test_b2a_writer_session_contract.py`, `test_b3c1_prerequisite_contract.py`, and the shared pre-I/O cleanup tests. Dependency-only assertion changes require an identified changed contract; they do not permit blanket hash refreshes.

Later acceptance must include a genuine engine-recognized recovery-required fixture, not only a mocked error; observational no-write checks; healthy and rejected acquisition; lock/identity/auxiliary-file refusals; post-recovery schema rejection; issuance-before/after-commit distinctions; and preservation of existing fencing/cleanup behavior. The fixture method and execution remain separately authorized future work.

## 4. F4/F5: inherited D2 plus new native consumers

The complete bytes of these relevant baseline modules are unchanged in the candidate:

- `_rw0_d2_offline.py`
- `_rw0_d2a_offline.py`
- `_rw0_d2a_evidence.py`
- `_rw0_d2a_handback.py`
- `_rw0_d2_handback.py`
- `_rw0_d2b_model_input.py`
- `_rw0_d2b_proposal.py`

The candidate's new outer function calls `run_rw0_d2_offline(...)` **before** entering its continuation `try/finally` (`_rw0_d2_post_execution_continuation.py:542–554`). Thus the new continuation is not an independent fix for upstream D2 failures. D2 retains its own disposal responsibility for failures before returning a run.

### Two legal complete layouts, not an arbitrary length range

D2 admits the actual worker observations (`_rw0_d2a_offline.py:392–425`) and later assumes fixed positions (`:542–592`). The checkpoint, final handback/reason checks, A-to-B association, and model-input assembler independently retain the same assumption:

- `_rw0_d2a_evidence.py:401–416`
- `_rw0_d2a_handback.py:122–207`
- `_rw0_d2_handback.py:44–154,158–171,378–429`
- `_rw0_d2b_model_input.py:224–299`

For a revalidated original Wire result with `n` equal to two or three observations, select exactly `n + 11` complete checked C1 families:

| Worker observations | Complete members | Exact rank sequence |
|---:|---:|---|
| 2 | 13 | `12,12,12,13,14,1,1,5,6,12,6,12,1` |
| 3 | 14 | `12,12,12,12,13,14,1,1,5,6,12,6,12,1` |

This table is a proposed contract successor derived from the current producer ordering. It is not behavior the candidate already implements.

Use one finite role/layout resolver for the D2 consumers, not scattered offset adjustments or a permissive `(13,14)` length test. Derive the selected layout from the checked original worker result; validate canonical order, exact types, phase, membership/receipt identities, and actual dependency relationships. Repeated rank 12 does not identify a unique role. The optional observation must not be invented, and its absence is not an authoritative “no candidate” assertion.

### New durable-witness dependency

The native safe-basis validator explicitly requires fourteen members and their literal rank vector (`_section41_post_execution_proposal_mutation_contracts.py:152–178`). The assembler iterates actual `checked_admissions` (`_rw0_d2_post_execution_continuation.py:95–101`). Historical checked readback invokes the same basis validator, then validates each persisted C1 member/receipt (`_sqlite_section41_post_execution_proposal.py:240–260,277–318`).

Consequently the repair must span producer, final D2 consumer, fresh native write, and historical native readback. Merely fixing D2's first failing index leaves a second refusal in the new safe-basis grammar.

Select explicit compatibility for the existing valid fourteen-member encodings: keep their canonical bytes/digests stable for equal inputs; add only the exact thirteen-member form. Preserve closed keys, bounds, exact builtins, privacy allowlist, and the two-effect/three-child structure. Historical readback must derive/check the selected worker layout from actual persisted member relationships rather than infer semantics solely from rank counts. Old child attestations do not gain fresh source-authentication credit by being readable.

### Typed malformed-input stops

The process-frame decoder already exposes `D2CheckingFrameError`, a content-free `ValueError` subtype (`_rw0_d2a_process_frames.py:39–44,135–151`). The normalizer catches broad exceptions and collapses that distinction to its generic error (`_rw0_d2a_evidence.py:964–1009`). `_run_checker` retains a valid process outcome and then calls that normalizer; `run_d2a_checked_evidence` retains its prefix only for `_D2AStop` (`_rw0_d2a_offline.py:310–327,615–629`).

Select narrow declared child-input rejection handling, with stage-specific invalid-evidence reasons, instead of relabeling an exit-zero process as failed. Preserve internal invariant/programming errors and process-control propagation. The existing process-failed reasons and complete-checkpoint evidence-mismatch reason do not truthfully describe this earlier clean-process/bad-evidence state.

For both layouts, the expected checked prefix at an invalid validator response is `n + 7` members and one clean child; at an invalid reviewer response it is `n + 9` members and two clean children. These counts follow the producer's actual order (`_rw0_d2a_offline.py:460–526`). They must accompany exact relationship checks, not replace them. Retain both committed bound effects, admit no invalid observation, and launch no downstream model.

The D2 stopped handback retains the actual reached prefix while its run remains owned/open. The borrowed native continuation can return its existing nonadmitting `stopped` result; the outer wrapper still owns disposal. Do not silently add a promise that all prefix state survives deletion of the process-owned temporary root. Cross-host clock semantics remain outside this repair.

## 5. Additional source finding: NPA-WITNESS-01

**Type:** candidate-specific evidence-origin / contract gap.  
**Severity:** high for the selected fresh-write provenance invariant; not a demonstrated C2-acceptance or live-execution bypass.  
**Evidence:** static call/dataflow inspection; no executable counterexample or database observation.

The contract states that the original run's checked admissions and three child outcomes are revalidated at the final consuming boundary (`.docs/section41-post-execution-proposal-family.md:9–16,51–59`).

The producer computes `safe_outcome_digest` from each actual process outcome (`_rw0_d2_post_execution_continuation.py:54–64,112–138`). However:

1. The writer ingress checks the supplied basis shape and original-run type/ownership separately (`sqlite_writer_session.py:6826–6865`).
2. The fresh writer verifies canonical basis bytes, their supplied digest, the run's handback, and proposal/evidence relations. It does not reconstruct the complete basis from that run and compare them (`_sqlite_section41_post_execution_proposal.py:472–552`).
3. The basis validator checks child role, digest syntax, and two literal true flags—not equality to actual child outcomes (`_section41_post_execution_proposal_mutation_contracts.py:186–192`).
4. Historical `_check_witness` checks C1 memberships and bound-effect receipts, not child digest association (`_sqlite_section41_post_execution_proposal.py:240–274`).

**Static distinguishing case:** a well-formed replacement child-outcome digest, with dependent basis/command identities consistently recomputed, is not rejected by any inspected predicate specifically for disagreement with the original run's child outcome. The healthy original handback and nine proposal roles need not change. This is a source-based missing-check argument; no claim is made that such an input was executed or committed in this pass.

**Correction selected for Unit 2:** before the first fresh A insert, independently derive the exact safe basis from the revalidated original run and compare the full canonical bytes and command association. A producer-side check alone is insufficient. Share only a private non-I/O assembly function below the caller and writer where necessary; do not import orchestration into the SQL owner, add a generic gateway, or re-run a child/model. A small helper extraction is permissible in the future edit plan only to avoid cycles and duplicated canonicalization.

Preserve receipt-first historical replay: an exact already-recorded family is checked as historical evidence, without requiring new currentness or executing processes. The stronger fresh gate does not retroactively authenticate old process attestations.

Later regression evidence must reach the writer with the original valid run plus a structurally valid mismatched witness, demonstrate refusal before target rows/receipt, and preserve valid own-run recording/replay. It must not take credit for an earlier malformed-JSON or stale-digest rejection.

## 6. Finalized production impact and explicit no-change boundaries

### Unit 2 direct source surfaces

| File under `src/ge_nwp_coordinator/` | Required treatment |
|---|---|
| `_rw0_d2a_evidence.py` | Complete-layout role resolution for separation; preserve declared child-input error distinction. |
| `_rw0_d2a_offline.py` | Replace offset-dependent consumers; truthful stage-specific invalid-evidence stops. |
| `_rw0_d2a_handback.py` | Exact two-layout checkpoint and role associations. |
| `_rw0_d2_handback.py` | Layout-dependent prefixes, reasons, final revalidation, and A-to-B binding. |
| `_rw0_d2b_model_input.py` | Obtain worker/authority/other roles from checked role resolution, not fixed offsets. |
| `_section41_post_execution_proposal_mutation_contracts.py` | Closed safe-basis compatibility for the two layouts; preserve canonical/privacy rules. |
| `_rw0_d2_post_execution_continuation.py` | Keep original-run construction aligned with the shared basis definition and two layouts; preserve custody and automatic A/B sequencing. |
| `_sqlite_section41_post_execution_proposal.py` | Fresh full-basis/original-run equality for NPA-WITNESS-01; historical verification of actual layout relationships. |

A private pure helper extraction may be justified for role resolution or basis assembly, but its imports, callers, source inventory, and tests must be named in the eventual patch. This is not authorization for general joins or a new evidence framework.

`_rw0_d2a_process_frames.py` already supplies a narrow frame error type; no grammar relaxation is selected. `_rw0_d2_offline.py` remains a final-consumer/cleanup regression dependency; source edits are not presumed necessary once the inner stop is typed correctly. `_section41_post_execution_proposal_row_values.py` consumes `checked_safe_basis_bytes` and therefore needs compatibility tests, not a new row algebra.

### Migration and ownership remain stable

Migration 0005 contains a bounded BLOB plus fixed row identities/FKs/immutability guards, **not** a fourteen-member witness constraint (`0005_section41_post_execution_proposal_family.sql:1–18,20–63`). The existing common families, generic C1 0-or-9 rules, and unchanged pure V22 do not need redesign for this correction.

**Selected no-change boundary:** preserve all five production migration resources, current migration checksum/catalog/tip, table/trigger/index counts, and the pure V22 source. No migration 0006, row-schema version replacement, rank-15 semantic redesign, or mega-transaction is selected. The basis grammar change is an explicit private contract successor, not a physical schema migration.

If later implementation demonstrates an actual conflicting physical invariant, report that specific invariant before changing this decision; do not use the repair as permission to widen schemas.

### Assurance consumers

Update the owning D2 and native Section 41 documents with the revised layout, stop-reason, and fresh basis-binding contracts. Preserve D1/Wire grammar, C1 ownership, and all previously accepted authority boundaries.

Primary Unit 2 regression surfaces are:
`test_rw0_d2_offline_integration.py`,
`test_rw0_d2_model_handback.py`,
`test_rw0_d2_evidence_children.py`,
`test_rw0_d2_process_frames.py`,
`test_rw0_d2_c1_checked_readback.py`,
`test_rw0_d2_post_execution_admission_integration.py`,
`test_section41_post_execution_proposal_contracts.py`,
`test_section41_private_atomic_post_execution_proposal.py`, and
`test_section41_post_execution_proposal_recovery.py`.

The existing basis positive explicitly pins fourteen entries (`test_section41_post_execution_proposal_contracts.py:33–57`). Its successor must test both exact shapes, not simply lower the assertion. Preserve invalid-type, privacy, same-capsule/donor, missing-role, strict expiry, and commit/recovery controls.

Guard dependencies include P11 current bytes plus both predecessor reconstructions and its independent companion; P09 where its protected source actually changes; the pure-owner import/caller inventories in `test_post_execution_pure_owner_boundaries.py` and `test_post_execution_pure_owner_vectors.py`; C10 at `test_rw0_c2_durable_progression_decision_semantic_contract.py:6265–6294`; and relevant SQLite source/import boundaries. A named-file reference alone is not permission to edit a test. Change only the expectation made obsolete by a selected contract, retain independent negative controls, and record the preserved property.

## 7. Future acceptance and current noncoverage

Future repair validation must establish both legal D1→D2→A→B→V22 positives with parent-captured bytes; both stage-specific malformed-input stops under both layouts; exact fresh witness equality; valid fourteen-member historical compatibility; donor/role/prefix refusal at the intended final consumer; no later effects after invalid evidence; and preserved cleanup/recovery/currentness behavior.

Unit 1 needs its own recovery-entry evidence. A mocked marker or successful error classification is not a substitute for a real supported recovery-required store. The F2 host-specific trace and simulation remain uninspected; no power-loss-safety or second-acceptance conclusion is established here.

The original writer's 9,191-pass receipt and logs are authenticated package contents. I read the receipt and selected test bodies for this impact review; I did not reproduce the run or fully reconcile every retained execution artifact. Its count is historical evidence for this original candidate, not a required count or pass for a future successor.

Both provenance-stop reports remain unchanged. The scoped protected-state versus diagnostic-ref treatment remains the selected audit policy, not a successful live qualification established in this pass. The consolidated audit mandate was rejected before the separate Opus report; no retry is selected and no partial execution is inferred.

The complete outstanding **A01–A12**, connected-proof, discriminating-control, retained-evidence reconciliation, and independent selector-free collection/FULL obligations survive. The exact fixed-fourteen assumption must be explicitly succeeded by the two legal closed layouts; that is a coverage clarification/expansion, not deletion of the association duties. NPA-WITNESS-01 adds a precise fresh-origin check to the relevant existing provenance/association obligations. This source review is engineering evidence, not discharge of the required independent engagement.

There is no completed candidate-specific correctness audit to transfer to repaired bytes. Preserve all useful original provenance and source findings, identify the successor's deltas, and require fresh validation of changed behavior and affected integration. Provider inability to perform required coverage leaves the audit incomplete; it is neither a candidate defect nor acceptance.

## 8. Next bounded action and inspection limits

**Next action selected for later authorization: implement Unit 1's F1 recovery-entry correction against the preserved candidate as a separately identified successor.** Keep Unit 2's exact scope, including NPA-WITNESS-01, queued as a distinct repair unit; F1 alone cannot lift the whole correctness hold. No additional package or reviewer response is needed merely to establish the source applicability now recorded.

This document is not an operative prompt. There is nothing in this response to send to Codex or to a new ChatGPT conversation. The implementation writer remains idle until an explicit implementation handoff authorizes the change and its validation.

This pass used only supplied artifacts. It authenticated package data, reconstructed Git object identities in memory, compared source spans, parsed source as text/AST, and inspected the selected docs/tests/schema paths. It did not import candidate modules, execute uploaded collectors/helpers, invoke Git, open SQLite state, run tests or crash probes, inspect a live checkout, contact services, or make repository/ref/publication changes.

The semantic review is intentionally bounded. It is not a full audit of the 298 files, all nine new/changed production modules, every cleanup state, or every stored relationship. The no-change recommendations for V22/0005 express this repair's scope, not new whole-component correctness acceptance.

Source coordinates below refer to the exact candidate's `source/` tree. Baseline coordinates are used only when explicitly labeled. Existing Opus reproduction materials remain uninspected. The separately commissioned reviewer is not assigned work by this document.

**Confidence:** archive/source identity 0.99; candidate applicability of inherited F1/F4/malformed-F5 mechanisms 0.98; NPA-WITNESS-01 static missing-association diagnosis 0.95. Runtime manifestations and any repaired successor remain unvalidated.

Data-only authentication details: [inspection record](sandbox:/mnt/data/Coordinator_Candidate_Source_Inspection_Record.json).

## Appendix: exact candidate-source excerpts

The excerpts are source evidence for this targeted decision, not executed programs. Omitted surrounding sections remain in the authenticated original archive.

### F1: unchanged acquisition/preflight

`src/ge_nwp_coordinator/sqlite_writer_session.py:7184–7199`

```text
7184: def acquire_sqlite_writer_session(location: CoordinatorStateLocation) -> WriterSession:
7185:     """Acquire an internal SQLite-backed writer session for a managed database."""
7186: 
7187:     _require_managed_preflight(location)
7188:     authority_lock = acquire_state_authority_lock(location)
7189:     connection: sqlite3.Connection | None = None
7190:     credential: _PrivateWriterCredential | None = None
7191:     database_binding: _StateDatabaseAuthorityBinding | None = None
7192:     committed = False
7193:     try:
7194:         _require_managed_preflight(location)
7195:         database_binding = authority_lock._capture_state_database_authority_binding(location)
7196:         connection = _open_bound_existing_sqlite_connection(database_binding, read_only=False)
7197:         connection.execute("BEGIN IMMEDIATE")
7198:         try:
7199:             _validate_current_managed_connection(connection)
```

### F1: classification still collapses

`src/ge_nwp_coordinator/sqlite_writer_session.py:7302–7327`

```text
7302: def _require_managed_preflight(location: CoordinatorStateLocation) -> None:
7303:     inspection = inspect_database(location)
7304:     if (
7305:         inspection.classification is not DatabaseClassification.MANAGED
7306:         or inspection.current_sequence != inspection.latest_sequence
7307:     ):
7308:         if inspection.classification is DatabaseClassification.UNKNOWN:
7309:             _raise_writer_state_malformed_if_present(location)
7310:         raise SQLiteWriterAcquisitionError(SQLiteWriterAcquisitionFailureReason.DATABASE_NOT_MANAGED)
7311: 
7312: 
7313: def _raise_writer_state_malformed_if_present(location: CoordinatorStateLocation) -> None:
7314:     connection: sqlite3.Connection | None = None
7315:     try:
7316:         connection = open_existing_sqlite_connection(location, read_only=True)
7317:         _read_durable_writer_issuance(connection)
7318:     except SQLiteWriterAcquisitionError as exc:
7319:         if exc.reason is SQLiteWriterAcquisitionFailureReason.WRITER_STATE_MALFORMED:
7320:             raise
7321:     except SQLiteStateError:
7322:         return
7323:     except sqlite3.Error:
7324:         return
7325:     finally:
7326:         if connection is not None:
7327:             connection.close()
```

### F1: read-only assessment

`src/ge_nwp_coordinator/sqlite_migration.py:1021–1054`

```text
1021: def _assess_location_database(
1022:     location: CoordinatorStateLocation,
1023:     catalog: MigrationCatalog,
1024:     *,
1025:     current_app_schema: int,
1026:     verify_managed_invariants: bool,
1027: ) -> _MigrationDatabaseAssessment:
1028:     database_path = existing_state_database_path(location)
1029:     if database_path is None:
1030:         return _MigrationDatabaseAssessment(_MigrationDatabaseDisposition.ABSENT)
1031:     file_state = _classify_existing_file_header(database_path)
1032:     if file_state is not None:
1033:         if file_state[0] is DatabaseClassification.EMPTY:
1034:             return _MigrationDatabaseAssessment(_MigrationDatabaseDisposition.EMPTY)
1035:         reason = SQLiteStateErrorCode(file_state[1] or SQLiteStateErrorCode.SQLITE_POSTURE_UNAVAILABLE)
1036:         return _MigrationDatabaseAssessment(
1037:             _MigrationDatabaseDisposition.CORRUPT_HISTORY,
1038:             reason=reason,
1039:         )
1040:     try:
1041:         connection = open_existing_sqlite_connection(location, read_only=True)
1042:     except SQLiteStateError as exc:
1043:         return _MigrationDatabaseAssessment(
1044:             _MigrationDatabaseDisposition.CORRUPT_HISTORY,
1045:             reason=SQLiteStateErrorCode(exc.error_class),
1046:         )
1047:     try:
1048:         return _assess_open_database(
1049:             connection,
1050:             catalog,
1051:             current_app_schema=current_app_schema,
1052:             verify_managed_invariants=verify_managed_invariants,
1053:         )
1054:     finally:
```

### F1: operational error loses the specific origin

`src/ge_nwp_coordinator/sqlite_connection.py:408–434`

```text
408: def apply_observational_connection_posture(
409:     connection: sqlite3.Connection,
410:     *,
411:     busy_timeout_ms: int = DEFAULT_BUSY_TIMEOUT_MS,
412: ) -> SQLiteConnectionPosture:
413:     _require_bounded_busy_timeout(busy_timeout_ms)
414:     try:
415:         _disable_extension_loading(connection)
416:         connection.execute("PRAGMA foreign_keys = ON")
417:         _set_busy_timeout(connection, busy_timeout_ms)
418:         trusted_schema_supported, trusted_schema = _disable_trusted_schema(connection)
419:         posture = SQLiteConnectionPosture(
420:             foreign_keys=_pragma_bool(connection.execute("PRAGMA foreign_keys").fetchone()),
421:             journal_mode=str(_single_pragma_value(connection.execute("PRAGMA journal_mode").fetchone())).lower(),
422:             synchronous=_normalize_synchronous(connection.execute("PRAGMA synchronous").fetchone()[0]),
423:             locking_mode=str(_single_pragma_value(connection.execute("PRAGMA locking_mode").fetchone())).lower(),
424:             trusted_schema_supported=trusted_schema_supported,
425:             trusted_schema=trusted_schema,
426:             busy_timeout_ms=int(_single_pragma_value(connection.execute("PRAGMA busy_timeout").fetchone())),
427:             extension_loading_disabled=True,
428:             explicit_transaction_control=connection.isolation_level is None,
429:         )
430:     except sqlite3.Error:
431:         raise _SQLiteOperationalPostureError(SQLiteStateErrorCode.SQLITE_POSTURE_UNAVAILABLE) from None
432:     except (TypeError, ValueError):
433:         raise SQLiteStateError(SQLiteStateErrorCode.SQLITE_POSTURE_UNAVAILABLE) from None
434:     _verify_nonpersistent_posture(posture, busy_timeout_ms)
```

### F1: existing binding fields

`src/ge_nwp_coordinator/sqlite_security.py:69–104`

```text
69: @dataclass(frozen=True, slots=True, repr=False, eq=False)
70: class _StateDatabaseAuthorityBinding:
71:     """Hidden root/lock/database identity binding for one state location."""
72: 
73:     _location: CoordinatorStateLocation
74:     _state_root_identity: _FilesystemObjectIdentity
75:     _authority_lock_file_identity: _FilesystemObjectIdentity
76:     _database_file_identity: _FilesystemObjectIdentity
77: 
78:     def __post_init__(self) -> None:
79:         if type(self._location) is not CoordinatorStateLocation:
80:             raise ValueError("invalid state database binding")
81:         for identity in (
82:             self._state_root_identity,
83:             self._authority_lock_file_identity,
84:             self._database_file_identity,
85:         ):
86:             if type(identity) is not _FilesystemObjectIdentity:
87:                 raise ValueError("invalid state database binding")
88: 
89:     def __repr__(self) -> str:
90:         return "<_StateDatabaseAuthorityBinding>"
91: 
92:     __hash__ = None  # type: ignore[assignment]
93: 
94:     def __reduce__(self) -> object:
95:         raise TypeError("invalid state database binding")
96: 
97:     def _same_authority_as(self, other: "_StateDatabaseAuthorityBinding") -> bool:
98:         return (
99:             type(other) is _StateDatabaseAuthorityBinding
100:             and self._location is other._location
101:             and self._state_root_identity._same_identity_as(other._state_root_identity)
102:             and self._authority_lock_file_identity._same_identity_as(other._authority_lock_file_identity)
103:             and self._database_file_identity._same_identity_as(other._database_file_identity)
104:         )
```

### F4: legal observations enter dynamically

`src/ge_nwp_coordinator/_rw0_d2a_offline.py:392–425`

```text
392:     checked = progress.checked_families
393:     author_observations = handback.wire_result.observations
394:     for ordinal, observation in enumerate(author_observations):
395:         checked.append(_admit(
396:             location=location, handback=handback, preimages=preimages,
397:             label=f"author-observation.{ordinal}", rank=12,
398:             value=observation, owners=author_observation_owners,
399:         ))
400:     author_obs_families = tuple(checked)
401:     checked.append(_admit(
402:         location=location, handback=handback, preimages=preimages,
403:         label="adapter-exit", rank=12, value=handback.adapter_exit,
404:         owners=author_observation_owners,
405:     ))
406:     adapter_family = checked[-1]
407:     basis = handback.phase_basis
408:     lineage = basis.c2b3d_lineage
409:     observation_locators = tuple(
410:         _member(f"worker_observation:{ordinal:03d}", family.admission_result)
411:         for ordinal, family in enumerate(author_obs_families)
412:     )
413:     worker_binding = RW0C1WireWorkerResultBindingV1(
414:         "worker-result.d2", basis.basis_ref, basis.basis_digest,
415:         lineage.program_ref, lineage.semantic_attempt_ref, lineage.candidate_ref,
416:         lineage.effect_intent_ref, lineage.author_command_ref,
417:         lineage.attempt_fence_ref, lineage.effect_fence_ref,
418:         lineage.delivery_attempt_ref, observation_locators,
419:     )
420:     checked.append(_admit(
421:         location=location, handback=handback, preimages=preimages,
422:         label="worker-result", rank=13, value=worker_binding,
423:         owners=result_owners, dependencies=observation_locators,
424:     ))
425:     worker_result_family = checked[-1]
```

### F4: fixed consumers

`src/ge_nwp_coordinator/_rw0_d2a_offline.py:542–569`

```text
542:     checked_families = tuple(checked)
543:     separation, separation_support = checked_reviewer_separation(
544:         checked_families=checked_families,
545:         capsule_manifest=handback.capsule_manifest,
546:     )
547:     validation_result_set = checking_result_set(
548:         evidence=validation_evidence,
549:         qualification=checked_families[9].evidence_value,
550:         expires_at=author.attempt_fence.expires_at,
551:     )
552:     review_result_set = checking_result_set(
553:         evidence=review_evidence,
554:         qualification=checked_families[11].evidence_value,
555:         expires_at=author.attempt_fence.expires_at,
556:     )
557:     attempt_digest = author_plan.semantic_attempt.semantic_attempt_digest
558:     validation_disposition, validation_support = checking_disposition(
559:         evidence=validation_evidence, result_set=validation_result_set,
560:         qualification=checked_families[9].evidence_value,
561:         semantic_attempt_digest=attempt_digest, attempt_number=1,
562:         reviewer_separation=None,
563:     )
564:     review_disposition, review_support = checking_disposition(
565:         evidence=review_evidence, result_set=review_result_set,
566:         qualification=checked_families[11].evidence_value,
567:         semantic_attempt_digest=attempt_digest, attempt_number=1,
568:         reviewer_separation=separation,
569:     )
```

### F5: child outcome versus normalization

`src/ge_nwp_coordinator/_rw0_d2a_offline.py:310–327`

```text
310:         process = run_fake_module(
311:             "ge_nwp_coordinator._rw0_d2a_fake_" + role,
312:             request, cwd=reconstruction.root,
313:             output_limit=64 * 1024 + 8, cancelled=cancelled,
314:         )
315:         process.validate()
316:         progress.child_outcomes.append(process)
317:         if not process.cleanup_complete:
318:             raise _D2AStop("process_cleanup_unresolved")
319:         if not process.clean_success:
320:             raise _D2AStop(role + "_process_failed")
321:         evidence = normalize_checking_evidence(
322:             role=role, process=process, command=command,
323:             author_command=handback.author_command,
324:             adapter_exit=handback.adapter_exit,
325:         )
326:         reconstruction.verify()
327:         return evidence, root_identity
```

### F5: retained-prefix handler

`src/ge_nwp_coordinator/_rw0_d2a_offline.py:615–629`

```text
615: def run_d2a_checked_evidence(
616:     d1_run: RW0D1OfflineRun, work_spec: WorkSpecV1,
617:     fixture: D1ArtificialFixture, *, cancelled: object = None,
618: ) -> _RW0D2AAdmittedBundle:
619:     """Borrow D1 and retain the actual dependency-closed reached prefix on stop."""
620:     progress = _D2AProgress()
621:     try:
622:         return _run_d2a_checked_evidence_impl(
623:             d1_run, work_spec, fixture, cancelled=cancelled, progress=progress,
624:         )
625:     except _D2AStop as stop:
626:         stop.bound_effects = tuple(progress.bound_effects)
627:         stop.checked_families = tuple(progress.checked_families)
628:         stop.child_outcomes = tuple(progress.child_outcomes)
629:         raise
```

### F5: new outer caller cannot catch a prior D2 failure

`src/ge_nwp_coordinator/_rw0_d2_post_execution_continuation.py:542–554`

```text
542: def run_rw0_d2_post_execution_continuation(
543:     work_spec: WorkSpecV1, fixture: D1ArtificialFixture,
544: ) -> PostD2ContinuationResultV1:
545:     """Run D2 exactly once, then own its creator-process disposal in finally."""
546:     run = run_rw0_d2_offline(work_spec, fixture)
547:     result: PostD2ContinuationResultV1 | None = None
548:     primary: BaseException | None = None
549:     try:
550:         result = continue_open_rw0_d2_run(run)
551:     except BaseException as error:
552:         primary = error
553:         raise
554:     finally:
```

### Witness: exact current count and child grammar

`src/ge_nwp_coordinator/_section41_post_execution_proposal_mutation_contracts.py:152–192`

```text
152:         witness = basis["d2_checkpoint_witness"]
153:         if type(witness) is not dict or frozenset(witness) != _WITNESS_KEYS:
154:             _invalid()
155:         members = witness["checked_memberships"]
156:         effects = witness["bound_effects"]
157:         children = witness["child_attestations"]
158:         if (type(members) is not list or len(members) != 14
159:                 or type(effects) is not list or len(effects) != 2
160:                 or type(children) is not list or len(children) != 3):
161:             _invalid()
162:         if tuple(member.get("kind_rank") if type(member) is dict else None
163:                  for member in members) != (
164:                      12, 12, 12, 12, 13, 14, 1, 1, 5, 6, 12, 6, 12, 1,
165:                  ):
166:             _invalid()
167:         for member in members:
168:             if type(member) is not dict or frozenset(member) != frozenset((
169:                 "kind_rank", "membership_ref", "membership_digest",
170:                 "mutation_ref", "admission_graph_digest",
171:             )):
172:                 _invalid()
173:             if type(member["kind_rank"]) is not int or not 1 <= member["kind_rank"] <= 15:
174:                 _invalid()
175:             for name in ("membership_ref", "mutation_ref"):
176:                 _safe_ref(member[name])
177:             for name in ("membership_digest", "admission_graph_digest"):
178:                 _sha(member[name])
179:         for effect, expected in zip(effects, ("validate_candidate", "review_candidate"), strict=True):
180:             if (type(effect) is not dict or frozenset(effect) != frozenset((
181:                 "effect_class", "mutation_ref", "receipt_graph_digest",
182:             )) or effect["effect_class"] != expected):
183:                 _invalid()
184:             _safe_ref(effect["mutation_ref"])
185:             _sha(effect["receipt_graph_digest"])
186:         for child, expected in zip(children, ("validator", "reviewer", "model"), strict=True):
187:             if (type(child) is not dict or frozenset(child) != frozenset((
188:                 "role", "safe_outcome_digest", "clean_success", "cleanup_complete",
189:             )) or child["role"] != expected or child["clean_success"] is not True
190:                     or child["cleanup_complete"] is not True):
191:                 _invalid()
192:             _sha(child["safe_outcome_digest"])
```

### Witness: original assembly

`src/ge_nwp_coordinator/_rw0_d2_post_execution_continuation.py:95–138`

```text
95:     membership_witness = [{
96:         "kind_rank": family.admission_result.kind_rank,
97:         "membership_ref": family.admission_result.membership_ref,
98:         "membership_digest": family.admission_result.membership_digest,
99:         "mutation_ref": family.admission_result.mutation_ref,
100:         "admission_graph_digest": family.admission_result.admission_graph_digest,
101:     } for family in handback.checked_admissions]
102:     effect_witness = []
103:     for proof in handback.committed_bound_effects:
104:         plan = _development_bound_effect_establishment_write_plan(
105:             proof.command, proof.confirmed_result.transaction_timestamp,
106:         )
107:         effect_witness.append({
108:             "effect_class": proof.command.effect_class,
109:             "mutation_ref": proof.command.mutation_ref,
110:             "receipt_graph_digest": plan.mutation_receipt.mutation_graph_digest,
111:         })
112:     child_witness = [{
113:         "role": role,
114:         "safe_outcome_digest": _safe_child_digest(role, outcome),
115:         "clean_success": outcome.clean_success,
116:         "cleanup_complete": outcome.cleanup_complete,
117:     } for role, outcome in zip(
118:         ("validator", "reviewer", "model"), handback.child_outcomes, strict=True,
119:     )]
120:     safe_basis = {
121:         "lineage_v01": lineage.to_mapping(),
122:         "context_v02": handback.input_context.to_mapping(),
123:         "capsule_safe_projection_v04": capsule_safe.to_mapping(),
124:         "model_safe_projection_v05": (
125:             handback.evidence_supply.model_input_safe_projection.to_mapping()
126:         ),
127:         "private_input_manifest_v07": (
128:             handback.evidence_supply.private_input_manifest.to_mapping()
129:         ),
130:         "model_input_binding_v09": handback.model_input_binding.to_mapping(),
131:         "artifact_safe_projection": handback.safe_projection.to_mapping(),
132:         "d2_checkpoint_witness": {
133:             "checked_memberships": membership_witness,
134:             "bound_effects": effect_witness,
135:             "child_attestations": child_witness,
136:         },
137:     }
138:     encoded = checked_safe_basis_bytes(safe_basis)
```

### Witness: fresh consuming boundary

`src/ge_nwp_coordinator/_sqlite_section41_post_execution_proposal.py:472–489`

```text
472: def write_fresh_after_fencing(
473:     *, capability: object, connection: sqlite3.Connection,
474:     command: RecordPostExecutionProposalCommandV1, run: RW0D2OfflineRun,
475:     safe_basis_bytes: bytes, transaction_timestamp: str,
476: ) -> RecordPostExecutionProposalResultV1 | PostExecutionProposalConflictV1:
477:     if (type(connection) is not sqlite3.Connection
478:             or type(command) is not RecordPostExecutionProposalCommandV1
479:             or type(run) is not RW0D2OfflineRun
480:             or checked_safe_basis_bytes(safe_basis_bytes) != safe_basis_bytes
481:             or safe_basis_digest(safe_basis_bytes) != command.safe_basis_digest):
482:         raise _integrity() from None
483:     run._require_open_owner()
484:     handback = run.handback
485:     handback.validate()
486:     if handback.status != "preadmission_ready":
487:         raise _integrity() from None
488:     checkpoint = handback.evidence_checkpoint
489:     basis = checkpoint.d1_handback.phase_basis
```

### Witness: persisted witness checks

`src/ge_nwp_coordinator/_sqlite_section41_post_execution_proposal.py:240–274`

```text
240: def _check_witness(capability: object, basis: dict[str, object]) -> None:
241:     witness = basis["d2_checkpoint_witness"]
242:     phase_ref = basis["context_v02"]["phase_basis_ref"]
243:     phase_digest = basis["context_v02"]["phase_basis_digest"]
244:     for member in witness["checked_memberships"]:
245:         family = _read_membership_family(
246:             capability, phase_basis_ref=phase_ref,
247:             membership_ref=member["membership_ref"],
248:         )
249:         receipt = _read_receipt(capability, member["mutation_ref"])
250:         if family is None or receipt is None:
251:             raise _integrity() from None
252:         _verify_evidence_family_rows(family, receipt, capability=capability)
253:         actual = family.membership
254:         if (actual.value("phase_basis_ref") != phase_ref
255:                 or actual.value("phase_basis_digest") != phase_digest
256:                 or actual.value("kind_rank") != member["kind_rank"]
257:                 or actual.value("membership_digest") != member["membership_digest"]
258:                 or actual.value("admitted_by_mutation_ref") != member["mutation_ref"]
259:                 or actual.value("admission_graph_digest") != member["admission_graph_digest"]):
260:             raise _integrity() from None
261:     for effect in witness["bound_effects"]:
262:         raw = _one(
263:             capability, "development_mutation_receipts",
264:             _decision_rows._DEVELOPMENT_MUTATION_RECEIPT_COLUMNS,
265:             "mutation_ref = ?", (effect["mutation_ref"],),
266:         )
267:         if raw is None:
268:             raise _integrity() from None
269:         try:
270:             row = _decision_rows.development_mutation_receipt_row_value_from_row_tuple(raw)
271:         except Exception:
272:             raise _integrity() from None
273:         if row.mutation_graph_digest != effect["receipt_graph_digest"]:
274:             raise _integrity() from None
```

### No SQL witness count

`src/ge_nwp_coordinator/sqlite_migrations/0005_section41_post_execution_proposal_family.sql:1–18`

```text
1: CREATE TABLE development_post_execution_proposal_contexts (
2:   "schema_id" ANY NOT NULL CHECK (typeof("schema_id")='text' AND "schema_id"='governed-execution.nwp-section41-post-execution-proposal-context-row.v1'),
3:   "proposal_phase" ANY NOT NULL CHECK (typeof("proposal_phase")='text' AND "proposal_phase"='post_execution_semantic_review'),
4:   "context_ref" ANY NOT NULL CHECK (typeof("context_ref")='text' AND length(CAST("context_ref" AS BLOB)) BETWEEN 1 AND 96 AND "context_ref" NOT GLOB '*[^0-9A-Za-z.-]*' AND substr("context_ref",1,1) GLOB '[0-9A-Za-z]'),
5:   "context_digest" ANY NOT NULL CHECK (typeof("context_digest")='text' AND length(CAST("context_digest" AS BLOB))=64 AND "context_digest" NOT GLOB '*[^0-9a-f]*'),
6:   "proposal_ref" ANY NOT NULL CHECK (typeof("proposal_ref")='text' AND length(CAST("proposal_ref" AS BLOB)) BETWEEN 1 AND 96 AND "proposal_ref" NOT GLOB '*[^0-9A-Za-z.-]*' AND substr("proposal_ref",1,1) GLOB '[0-9A-Za-z]'),
7:   "proposal_digest" ANY NOT NULL CHECK (typeof("proposal_digest")='text' AND length(CAST("proposal_digest" AS BLOB))=64 AND "proposal_digest" NOT GLOB '*[^0-9a-f]*'),
8:   "phase_basis_ref" ANY NOT NULL CHECK (typeof("phase_basis_ref")='text' AND length(CAST("phase_basis_ref" AS BLOB)) BETWEEN 1 AND 96 AND "phase_basis_ref" NOT GLOB '*[^0-9A-Za-z.-]*' AND substr("phase_basis_ref",1,1) GLOB '[0-9A-Za-z]'),
9:   "phase_basis_digest" ANY NOT NULL CHECK (typeof("phase_basis_digest")='text' AND length(CAST("phase_basis_digest" AS BLOB))=64 AND "phase_basis_digest" NOT GLOB '*[^0-9a-f]*'),
10:   "safe_basis_bytes" ANY NOT NULL CHECK (typeof("safe_basis_bytes")='blob' AND length("safe_basis_bytes") BETWEEN 1 AND 131072),
11:   "safe_basis_digest" ANY NOT NULL CHECK (typeof("safe_basis_digest")='text' AND length(CAST("safe_basis_digest" AS BLOB))=64 AND "safe_basis_digest" NOT GLOB '*[^0-9a-f]*'),
12:   "context_row_digest" ANY NOT NULL CHECK (typeof("context_row_digest")='text' AND length(CAST("context_row_digest" AS BLOB))=64 AND "context_row_digest" NOT GLOB '*[^0-9a-f]*'),
13:   PRIMARY KEY (context_ref),
14:   UNIQUE (proposal_phase,context_ref,context_digest),
15:   UNIQUE (proposal_phase,proposal_ref),
16:   FOREIGN KEY (proposal_phase,proposal_ref) REFERENCES development_model_proposals(proposal_phase,proposal_ref) ON UPDATE RESTRICT ON DELETE RESTRICT NOT DEFERRABLE INITIALLY IMMEDIATE,
17:   FOREIGN KEY (phase_basis_ref,phase_basis_digest) REFERENCES rw0_phase_instances(phase_basis_ref,phase_basis_digest) ON UPDATE RESTRICT ON DELETE RESTRICT NOT DEFERRABLE INITIALLY IMMEDIATE
18: ) STRICT;
```
