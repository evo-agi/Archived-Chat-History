# Coordinator Unit 2 typed child-value repair — static package review

## Disposition

`POST_D2_UNIT2_TYPED_CHILD_VALUE_REPAIR_READY_FOR_INDEPENDENT_AUDIT_ACCESS_PENDING`

No new blocking defect was found in the exact three-file successor delta. This is a static engineering review of supplied artifacts and source, not independent runtime acceptance and not permission to stage, commit, publish, or widen product authority.

## Exact subject

- Review ZIP: `PostD2Unit2TypedChildRepairReviewPackage.zip`
- Size: `5,912,014` bytes
- SHA-256: `a019b8afca2f71efb1400c7b83d9710b5379a74975f3748981d2e31059e248cd`
- Package members: `438`; `437` covered by the complete package manifest
- Source endpoints: `299`
- Independently reconstructed source tree: `8633f700647bcdd19451a6840295a527940e7a3b`
- Predecessor tree: `a0b52ca6f396638ee5615ad75523a394dba637a0`
- Exact predecessor delta: three modified existing files, no additions or deletions:
  - `.docs/rw0-d2-offline-evidence-and-review.md`
  - `src/ge_nwp_coordinator/_rw0_d2a_evidence.py`
  - `tests/test_rw0_d2_offline_integration.py`

The standalone implementation report is `10,127` bytes, SHA-256 `bffe86f1cf983bc06263668c83275e82de3274a7919b674f7d0a2036b708d4fa`, and equals the embedded report byte-for-byte.

## Source judgment

### Repair closes the identified typed-value escape

`_rw0_d2a_evidence.py` now validates two child-owned semantic classes immediately after closed-frame decoding and before `WorkerObservationV1.create`:

1. `observed_at` must parse as an actual calendar timestamp and round-trip under the existing fixed UTC grammar.
2. `(outcome, reason_code)` must belong to the finite validator or reviewer vocabulary.

Those checks convert only the declared child-input failures to `_D2CheckingInputInvalid`. Existing command, fence, delivery, capsule, source, evidence, invocation, file-digest, and adapter-order checks remain in the same private boundary. There is no catch-all around `WorkerObservationV1.create`, result-set construction, the checker path, programming faults, or process-control exceptions.

This closes the previously identified cases in which a canonical, digest-valid child frame could escape as a raw `WorkerExecutionValueError` or fail later after additional checker work.

### Tests exercise the actual semantic boundary

The new parameterized regression constructs canonical, digest-valid altered response frames and covers:

- validator and reviewer roles;
- legal two- and three-observation D1 layouts;
- impossible calendar timestamps;
- forbidden reason codes;
- the other role's reason code;
- a permitted reason paired with the wrong outcome.

It checks exact retained prefixes, exact child counts, no later checker/model launch, no Section 41 post-execution proposal row, no C1 rank-15 row, valid stopped-handback reconstruction, and creator-owned close. Existing malformed-frame, process-failure, cleanup-unresolved, programming-fault, connected-positive, donor-refusal, and historical 13/14 replay controls remain in the packaged register.

### Deliberate remaining limit

The repair does not change valid future-clock or cross-host temporal ordering. A syntactically and calendar-valid child timestamp that is ahead of the parent clock remains part of the separately open clock/causality portion of F5. The malformed-input portion is repaired; the broader clock issue is not closed by this candidate and must not be reported as closed.

No new migration, schema, V22, Wire/C2A grammar, public API, or F1 source change appears in this successor. All fourteen frozen F1 paths match the F1 input by byte and mode.

## Retained validation evidence

The package records exact collected, executed, and JUnit-ID set equality for every gate:

| Gate | Collected | Executed | JUnit | Failures | Errors | Skips |
|---|---:|---:|---:|---:|---:|---:|
| Direct | 80 | 80 | 80 | 0 | 0 | 0 |
| Focused | 3,330 | 3,330 | 3,330 | 0 | 0 | 0 |
| Connected | 6 | 6 | 6 | 0 | 0 | 0 |
| FULL | 9,291 | 9,291 | 9,291 | 0 | 0 | 0 |

The source-bound first checkpoint contains 23 collected/executed/JUnit cases and exit status zero. Its nested manifest authenticates all twelve covered members. The validation ID recorder is an external observational pytest plugin; its source records node IDs and reports and does not select, skip, or modify tests.

These are authenticated implementation records. No test was independently rerun in this review.

## Provenance and cleanup

The final-a, final-b, and post-cleanup canonical manifests are byte-identical:

- bytes: `116,404`
- SHA-256: `90e4c2e0e2db99f139b26b759d578445fbddfec39ccefe88604118ccca6ab51a`

Their tracked binary diffs are also byte-identical:

- bytes: `276,579`
- SHA-256: `9b3e07523e7fe24331c00346d331378249b133a093c38b5b08453ad445f1c350`

The prospective interval retains the fixed raw index, configuration, and 32 authoritative refs. Historical raw-index and diagnostic-ref gaps remain unresolved and are not backdated by this result.

## Current disposition and next gate

Tree `8633f700647bcdd19451a6840295a527940e7a3b` is the current cumulative uncommitted review subject. Earlier original-candidate, F1, and Unit 2 identities remain historical subjects with their original dispositions.

The source-supported F1 repair, legal 13/14 layouts, malformed-input typed stops, and original-run witness association are now represented in this cumulative subject. F2, qualified F3/F6/F7, cross-host clock ordering, live custody, C2 decision/acceptance, and product execution remain outside it.

The next required gate is a fresh independent audit of the cumulative 299-file source, including independent source review, connected/discriminating controls, and selector-free collection/FULL execution. The prior provider-access interruption remains unresolved. No automatic mandate rewrite or resubmission is selected here.

Until a qualified independent review is available:

- keep the implementation writer idle;
- preserve this exact package and tree;
- do not stage, commit, push, open a PR, merge, or begin another mutation tranche on top of an implicitly accepted base.

## Inspection limits

This review authenticated and inspected archive members, source bytes, Git-object-compatible identities, the exact delta, tests, documentation, retained JUnit/ID evidence, checkpoint package, and provenance captures as data. It did not access the live checkout, run Git commands, import repository modules, execute tests or helpers, open SQLite databases, launch child processes, or contact a network or live target.
