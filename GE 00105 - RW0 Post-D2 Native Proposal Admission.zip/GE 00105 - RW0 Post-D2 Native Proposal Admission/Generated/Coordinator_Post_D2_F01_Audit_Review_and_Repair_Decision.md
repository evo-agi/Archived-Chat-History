# Post-D2 cumulative audit review and repair decision

## Disposition

`POST_D2_CUMULATIVE_CANDIDATE_REPAIR_REQUIRED_F01`

The artifact-only audit correctly blocks acceptance of sealed source tree
`8633f700647bcdd19451a6840295a527940e7a3b`. Its F01 finding is a real
source-level error-classification defect. F02 is an evidence-availability
limit in that audit, not a source defect, and is independently resolved by the
attached F1 package comparison below. F03 remains a nonblocking structural
observation.

## F01 — accepted blocking defect

In `src/ge_nwp_coordinator/_sqlite_section41_post_execution_proposal.py`, the
fresh path wraps the fenced owner read, semantic currentness comparison, and
historical-time comparisons in one broad `except Exception`. Consequently,
`SQLiteMutationStoreError(database_integrity_failure)` from the actual owner
reader is converted into `PostExecutionProposalConflictV1("currentness_conflict")`.
The mutation fails closed, but the result falsely reports ordinary stale state
instead of an operational/integrity failure.

The repair must separate these cases:

- a failed/malformed owner read or unexpected internal validation failure is a
  safe mutation-store error and must not become a conflict result;
- the finite stale/currentness conditions represented by
  `RW0D2BInputConflict`, changed retained stop coordinates, or invalid temporal
  ordering remain `currentness_conflict`;
- process-control exceptions remain unsuppressed;
- no route probe, insert, receipt, or commit occurs after an owner-read failure.

The smallest expected repository delta is:

- `src/ge_nwp_coordinator/_sqlite_section41_post_execution_proposal.py`
- `tests/test_section41_private_atomic_post_execution_proposal.py`

No schema, migration, error vocabulary, public API, D2 layout, F1 code, V22,
or documentation change is required unless implementation exposes a direct
contract ambiguity.

## F02 — evidence obligation now independently resolvable

The audit package proved the final tree equal to immediate predecessor
`a0b52ca6f396638ee5615ad75523a394dba637a0`, but did not contain the F1
per-path source needed to prove linkage to tree
`93afef8750e062d80626a5a37adfa27766305b7c`.

The supplied `F1ClassificationRepairReviewFinal.zip` authenticates that F1
source tree. Direct data-only comparison against the current candidate shows
all fourteen frozen paths byte- and mode-identical. The exact path inventory is
in `Post_D2_F1_Linkage_Verification.json`.

This closes the engineering uncertainty. A later independent auditor must
receive and authenticate the exact F1 package (or equivalent exact historical
payloads) alongside the repaired successor; the prior audit cannot be
retroactively relabeled accepted.

## F03 — retained observation

The transient result constructor's 20-character timestamp check is weaker than
canonical UTC validation, but the persisted receipt and production result path
validate the value before effectful use. No effect-authorizing path from an
invalid direct construction was established. Do not broaden the F01 repair to
this observation.

## Validation and audit consequences

The auditor independently completed the structural A01–A12 review and exact
9,291-node collection, but stopped the full execution after F01. Its partial
run is not a full-suite pass. Changed bytes require a new source identity,
implementation validation, and a fresh independent audit. The repaired writer
must carry explicit F1-linkage evidence, run the affected causal controls and
one selector-free full collection/execution, and return a sealed review
package. No staging or publication is authorized.

## Inspection limits

This review authenticated the supplied candidate, F1, and audit packages as
data; inspected the exact F01 source and relevant currentness tests; and
compared the fourteen historical F1 paths. It did not execute repository code,
tests, SQLite, packaged helpers, or the live checkout.
