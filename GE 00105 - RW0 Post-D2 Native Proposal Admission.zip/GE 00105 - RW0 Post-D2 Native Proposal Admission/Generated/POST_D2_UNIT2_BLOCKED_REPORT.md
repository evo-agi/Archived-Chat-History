# POST_D2_UNIT2_BLOCKED

## Opening and retained source identities

- Authenticated Input A: 7,406,558 bytes, SHA-256 `9cb40710e2a6d2c4d13fb79196885d12d5f52ea1e7f5f7f50ebf1b48f24085b3`; 299-file source tree `93afef8750e062d80626a5a37adfa27766305b7c`.
- Authenticated Input B: 14,481,457 bytes, SHA-256 `d9b4d61e212893b48ba1952c3b5370c09874ca2e70798decc36bc4fdbd893d9b`; source tree `17ee7db2925ed03ebc1614880fba5ec83d102d8c` (historical comparison only).
- Opening frozen v3 canonical manifest SHA-256: `69b34f2a5e3da6c710a3746e94e6971f63c7541babdfd12b18d7e09422e6b122`.
- The incomplete eight-file implementation attempt was retained externally as `blocked-partial-source/`, 299-file tree `2df9487936436ed1b11ae73dd75d909645f0ef5a`; its v3 canonical manifest SHA-256 was `92f520d4858b93afefceb7017b4419a2f90a9c2a085da63ef9271a6385d822f3`.
- The live repository was restored to Input A's exact 299 source file bytes and modes. The initial raw index was separately retained as `opening-index.raw` (32,314 bytes, SHA-256 `7e27326ab9b242d5bb56e41286d561be4dffed43dc3d377b5bffc75c8ffd5b07`).
- All fourteen frozen F1 paths are byte- and mode-identical to Input A in the restored live source. No repository change from this Unit 2 attempt remains.

The external partial attempt touched only these authorized production files:

| File | Attempted purpose |
| --- | --- |
| `src/ge_nwp_coordinator/_rw0_d2a_evidence.py` | One finite checked-layout resolver and narrow child-input exception. |
| `src/ge_nwp_coordinator/_rw0_d2a_offline.py` | Dynamic A family roles and typed invalid-evidence stop. |
| `src/ge_nwp_coordinator/_rw0_d2a_handback.py` | Dynamic checkpoint roles. |
| `src/ge_nwp_coordinator/_rw0_d2_handback.py` | Dynamic reached-prefix and child-count rules. |
| `src/ge_nwp_coordinator/_rw0_d2b_model_input.py` | Dynamic direct C1 role selection. |
| `src/ge_nwp_coordinator/_section41_post_execution_proposal_mutation_contracts.py` | Exact 13/14 safe-basis grammar and shared command/basis derivation. |
| `src/ge_nwp_coordinator/_rw0_d2_post_execution_continuation.py` | Use the shared derivation and dynamic role selection. |
| `src/ge_nwp_coordinator/_sqlite_section41_post_execution_proposal.py` | Fresh-write original-run equality gate. |

## Compatibility capture before editing

The authenticated Input A source was executed in an external copy with a fixed UTC clock and a test-only adapter reference derived from the child's exact stdout instead of the nondeterministic OS PID. The two independent captures were byte-identical. `pre-edit-vector.json` retains the complete command mapping/digest, base64-encoded exact canonical safe-basis bytes, size/digest, 14 checked membership selectors in order, and persisted row/receipt identities. Vector file SHA-256: `38a8a2f1aab88fb94c836358a7caa9a2b6a50f6157311ec1fa7dd307c07b8acb`; command digest `42e9c63493d6f5b1ce277b9001bcd3cbcf5737f57f8f11b42998af783e41a929`; safe basis 31,855 bytes, digest `df99c744d4028959c3b44818aa7eb76c5c09fa62756526732a30b41589a9f5a7`.

## Exact scope conflict

The current C2A contract says `worker_completed` has **no** conditional fields; only `candidate_captured` carries `candidate_ref` (`.docs/c2a-first-slice-semantic-protocol-contract.md`, source/observation-kind matrix and conditional-field rule). The legal Wire result can therefore contain only `worker_started, worker_completed` while the parent still captures and capsules the candidate.

On the incomplete Unit 2 attempt, `two_observation_blocker_probe.py` used the real D1 worker and parent capture, then re-encoded its actual Wire result with the legal two observations. D1 returned `capsule_ready`, and `worker_completed` had no `candidate_ref`. D2 reached `evaluate_post_execution_reviewer_separation()` in `src/ge_nwp_coordinator/_post_execution_evidence_values.py`. That pure owner chooses the final worker observation as `captured` for count two and requires its `candidate_ref` to equal the parent capsule candidate. It raised `_PostExecutionContractViolation: source_owner_mismatch` before D2 B, Section 41 A, C1 B, or V22. See `two-observation-blocker.log`.

The necessary correction belongs to `src/ge_nwp_coordinator/_post_execution_evidence_values.py` and its pure-owner controls. The mandate's authorized production list excludes that file and explicitly forbids changes to other production files. Synthesizing a candidate reference in `worker_completed`, or bypassing the pure relationship check, would violate the C2A schema and governance boundary. No authorized eight-file-only implementation can meet the required two-observation connected positive.

One existing three-observation connected positive passed on the incomplete external source. This does not validate the partial attempt. The first substantive checkpoint, remaining causal controls, final focused selector, selector-free FULL run, final v3 triple capture, docs/status successor, and implemented review package were not performed because the required two-observation predicate is blocked. The partial source is evidence of the attempted path, not a candidate.

The amendment needed to proceed is narrow: authorize correction of the two-observation reviewer-separation relation in `_post_execution_evidence_values.py` and its directly affected pure-owner tests, while retaining the C2A conditional-field rule and parent-owned capture semantics. Any new run should start from the authenticated F1 source tree and recapture its own final source identity.

## Effect records

INDEPENDENT_AUDIT_NOT_PERFORMED  
STAGING_NOT_PERFORMED  
COMMIT_NOT_PERFORMED  
PUSH_NOT_PERFORMED  
PR_NOT_CREATED  
MERGE_NOT_PERFORMED  
PUBLICATION_NOT_PERFORMED
