# F1 post-recovery classification repair — static package review

**Engineering disposition:** `POST_D2_F1_CLASSIFICATION_REPAIR_STATIC_REVIEW_CLEAR_AS_UNIT2_BASE`

This is a ChatGPT engineering review of the supplied implementation package. It is **not** an independent audit, commit authorization, publication authorization, or acceptance of the complete native proposal/admission candidate.

## 1. Exact subject and package authentication

The supplied `F1ClassificationRepairReviewFinal.zip` is the exact review package reported by the implementation writer:

- size: **7,406,558 bytes**
- SHA-256: **`9cb40710e2a6d2c4d13fb79196885d12d5f52ea1e7f5f7f50ebf1b48f24085b3`**
- unique safe members: **381**
- package-manifest-covered members: **380**, all matching their recorded size and SHA-256
- standalone `IMPLEMENTATION_REPORT.md`: **7,230 bytes**, SHA-256 **`948e0cd190846cd26c1c43804ee808d1f719ce60274817ed463051cb7fde60a5`**; byte-identical to the report inside the ZIP

All **299** source endpoints in `source/` matched the final source manifest by path, size, raw SHA-256, Git blob identity, and Git mode. Their independently reconstructed Git tree is:

```text
93afef8750e062d80626a5a37adfa27766305b7c
```

The exact predecessor is the authenticated F1 tree:

```text
b4d2d4236b8c09d95aca8a671d02fe769370ed02
```

The predecessor delta changes only:

```text
src/ge_nwp_coordinator/sqlite_writer_session.py
tests/test_sqlite_writer_hot_journal_recovery.py
```

No source path was created or deleted and both modes are unchanged.

## 2. Source judgment

The implementation makes the intended narrow distinction:

- after admitted engine rollback, a post-recovery managed inspection classified as `UNKNOWN/sqlite_posture_unavailable` is converted to `recovery_unresolved`;
- a deterministically older catalog/schema/invariant posture, including the exact recovered 0004 prefix, remains `database_not_managed`;
- pre-recovery observation, journal eligibility, binding, locking, create-disabled recovery opening, cleanup, issuance, publication, migration policy, and no-hidden-retry behavior remain on their prior paths.

The new branch is reached only by the post-recovery preflight call. Other `_require_managed_preflight()` call sites retain their prior behavior. The surrounding acquisition error path releases the authority lock and does not publish a writer.

The new regression uses the existing genuine hot-journal fixture, permits real SQLite rollback, makes only the third writer inspection operationally unavailable, then verifies:

- `recovery_unresolved` rather than `database_not_managed`;
- no writer issuance and no hidden retry;
- the journal was consumed and the fixture spill was rolled back;
- generation 1 remains unchanged;
- the authority lock is released;
- after removing the injected failure, the same recovered store issues generation 2.

The exact-0004 counterpart remains separately covered and continues to require explicit migration.

**Static conclusion:** I found no new F1 blocker in the two-file delta. The correction directly addresses `F1-POSTREC-01` without widening schema, public APIs, transaction ownership, or recovery eligibility.

## 3. Retained validation reconciliation

The package retains source-bound records for the exact final tree:

| Run | Retained result |
|---|---:|
| Targeted checkpoint | 6 passed |
| Complete hot-journal module | 41 passed |
| Eight-module focused selection | 403 passed; 3 existing fork warnings |
| D1/D2 → Section 41 A → C1 B → V22 connected positive | 1 passed |
| Selector-free collection | 9,232 unique IDs |
| Selector-free FULL | 9,232 passed; 0 failures/errors/skips; 3 existing fork warnings |

The collected-ID and executed-JUnit inventories contain the same **9,232** unique IDs. The JUnit records zero failures, errors, and skips. The retained final source manifest is equal before and after the runs.

These are authenticated implementation records, not tests independently rerun by ChatGPT.

## 4. Provenance and limits

The package retains three byte-identical final/post-cleanup v3 manifests at SHA-256:

```text
69b34f2a5e3da6c710a3746e94e6971f63c7541babdfd12b18d7e09422e6b122
```

They bind the 299 source endpoints, cumulative HEAD-relative diff, thirteen created paths, semantic and raw index, configuration, and the frozen 32-record authoritative ref map. The measured prospective raw index, configuration, and authoritative-ref identities remain stable. Diagnostic turn-diff refs are retained separately under the existing name-based policy.

Historical raw-index and diagnostic-ref intervals remain unresolved. This prospective package does not backdate preservation or erase the two earlier `AUDIT_PROVENANCE_MISMATCH` records.

This review did not:

- access the live checkout;
- execute repository code, tests, databases, or uploaded helpers;
- reproduce the runtime behavior independently;
- perform the unfinished A01–A12 candidate audit;
- grant staging, commit, push, PR, merge, deployment, or product-effect authority.

## 5. Engineering consequence

Tree `93afef8750e062d80626a5a37adfa27766305b7c` is a suitable **implementation checkpoint** for the separately identified Unit 2 repairs. It is not an accepted release candidate.

The F1 delta and its evidence must remain independently attributable and byte-frozen while Unit 2 addresses:

1. both legal two- and three-observation D2 layouts;
2. typed stops for clean checking processes that return invalid evidence;
3. exact fresh-write association of the native Section 41 command/safe basis with the original open D2 run (`NPA-WITNESS-01`).

F2 and qualified F3/F6/F7 remain outside Unit 2. The provider-access interruption and unfinished independent audit remain separate. A future combined successor requires a new source identity, complete validation on its own bytes, and governed review when an available review path exists.
