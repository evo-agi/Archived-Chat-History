# Coordinator bounded repair specification and candidate-impact map

**Status: engineering design only.** This document specifies two separate corrective units. It authorizes no repository edits, execution, tests, crash experiments, audit retry, staging, commit, or publication. It is not a prompt for the independent reviewer.

## 1. Subjects, evidence, and disposition

The merged baseline is commit `eac7f6df5f281138dd0640c5cd47b9924c8390f8`, tree `061c43c41228310134a30f3b79291bba3e44f3f2`. The supplied `RW0_D2_PR15_Source_Checkpoint.zip` is 3,227,944 bytes, SHA-256 `af5ee227cb9d42e15d0043423852712ef0e058dcd2538ebc117610db61fc6878`. Its source is directly inspectable here.

The separate native proposal/admission candidate is the uncommitted tree `17ee7db2925ed03ebc1614880fba5ec83d102d8c`, on `codex/post-d2-native-proposal-admission-v1`, based on that merge. Its fixed review package is:

`/Users/ds/Downloads/Coordinator_PostD2_Final_ftssNh/ReviewPackage.zip`

14,481,457 bytes; SHA-256 `d9b4d61e212893b48ba1952c3b5370c09874ca2e70798decc36bc4fdbd893d9b`.

That candidate ZIP is not available in this conversation's working files. Candidate impact below is explicitly report-derived until its payloads are inspected. Its implementation report is 19,394 bytes, SHA-256 `3099b026881bab6a7bfc05fa2c6230cf9e9d331d8f72b608e3aa52c94d41e4a6`; the retained provenance audits report authentication of all 298 endpoints, 57 modifications and 12 creations, but stopped before correctness review and independent execution.

Three matters remain separate:

* **Access:** the consolidated `Coordinator_Post_D2_Operative_Independent_Audit_Mandate.txt` was also rejected, before the Opus report. No automatic resubmission is selected. Refusal establishes neither completed coverage nor zero tool activity.
* **Acceptance:** the candidate remains unchanged, unaccepted, and on correctness hold; its implementation writer remains idle. Both historical provenance-mismatch dispositions and their unresolved intervals survive. The candidate-specific protected-state/diagnostic-ref distinction is retained, not claimed to have been exercised successfully.
* **Correctness evidence:** the completed triage stands. Baseline source supports F1, F4, and the malformed-checker-input part of F5. Opus's original executable reproductions remain uninspected. F2's host-specific trace and restored-journal simulation are reported evidence, not an authenticated power-loss experiment or a demonstrated second acceptance.

The Opus addendum assignment is withdrawn. The reviewer remains separately commissioned by the user. This design depends on no new reviewer response.

This conversation continues 00077 from an archived history transfer, not dependable cross-chat memory.

## 2. Selected sequence and limits

**First repair unit: F1 recovery entry. Second repair unit: F4 plus malformed-checker-input F5.** The first addresses shared writer acquisition; the second addresses the legal D1/D2 evidence shapes and truthful stopped handbacks. Keep their changes and acceptance evidence separately attributable even if a later authorized candidate ultimately contains both.

Prepare repairs against the exact native-proposal candidate once its payloads are available. Do not roll back, reset, overwrite, commit, or discard the original candidate to obtain a clean baseline. A later implementation must have a distinct identity and an explicit delta from the preserved candidate.

The immediate work completed by this document is the repair specification and baseline/report-level impact map. The remaining source dependency is a narrow comparison with the already-existing candidate ZIP, not a new full reconnaissance or historical-package reconstruction.

No F2 journal-mode/synchronous change, escaped-descendant containment redesign, cross-host clock redesign, live model-input redesign, C2 writer, provider route, ES/Bridge change, or autonomous recovery loop belongs to these two units. F2 continues to limit power-loss durability claims. The selected first-live continuity/custody gate is not relaxed by a general SQLite recovery correction.

## 3. Unit 1 — reachable, governed recovery before writer issuance

### 3.1 Current conflict and chosen contract successor

Baseline `sqlite_writer_session.py:7073–7088` requires managed read-only preflight both before lock acquisition and before the bound writable open. `_require_managed_preflight` collapses unsuccessful classification into `DATABASE_NOT_MANAGED` (`:7191–7213`). The read-only assessment is at `sqlite_migration.py:1001–1033`; connection posture handling drops the specific SQLite error origin at `sqlite_connection.py:408–434`.

The contract explicitly orders managed preflight ahead of the lock and writable connection (`.docs/writer-session-authority.md:561–585`), but promises next-acquisition recovery after interrupted issuance (`:671–678`). Fix the conflict in governing documentation and corresponding tests, not by silently bypassing that preflight.

**Selected target:** ordinary writer acquisition has a narrowly admitted backend-recovery branch, distinct from normal managed acquisition. Inspection and validation remain observational. There is no new public recovery service, caller-supplied SQL, generic writable gateway, or alternative connection owner.

### 3.2 Required order and authority boundary

1. **Observational classification.** Preserve ordinary absent, empty, known-invalid, wrong-posture, incompatible, and healthy outcomes. A closed, machine-derived rollback-required condition must remain distinguishable from corruption or unknown schema. Preserve the relevant SQLite error identity through the private adapter; never select recovery by matching exception text, journal filename presence alone, or generic `SQLITE_POSTURE_UNAVAILABLE`.

2. **Eligibility before engine mutation.** The recovery branch is confined to the configured local Coordinator state location and its supported rollback-journal arrangement. Establish existing-file/root identity, safe ownership/modes, no unsafe links or aliases, and the applicable auxiliary-file boundary. Refuse unsupported journal arrangements and unprovable custody. A well-formed SQLite header is not evidence that the schema is managed.

3. **Acquire and retain the existing state-authority lock.** Recheck the observations and capture the root/lock/database binding under that lock. If another legitimate operation resolved the condition before acquisition, reclassify rather than replaying an obsolete recovery decision. Do not manufacture a live writer credential from lock possession.

4. **Use the existing connection owner for engine recovery only.** Open create-disabled against the bound existing file with the established connection-local safety posture. Let SQLite perform required rollback through its supported recovery behavior; do not manually delete, restore, rewrite, or replay journals. No persistent mode conversion, migration, initialization, application-row repair, or semantic command replay is allowed in this stage.

5. **Validate after recovery and before issuance.** Revalidate the filesystem binding, managed schema/catalog, invariants and writer state before issuing a generation or returning a writer. The healthy path's transactional managed validation remains mandatory. An exact older schema still requires explicit migration; recovery does not grant migration permission.

6. **Publish only proved outcomes.** Return a writer only after normal issuance commitment and successful custody/cleanup obligations. Failure must preserve the distinction between recovery unavailable/unresolved, storage recovered but schema rejected, issuance not attempted, and issuance commitment uncertain. Existing safe-error and process-control conventions apply. No diagnostic is permission to delete/reinitialize a recoverable store.

**Important scope change:** engine recovery can alter database/journal bytes before logical managed-schema status is established. That is an intentional, narrow exception at this governed mutation entry, not an observational no-write claim. A recovered database that subsequently fails schema validation must receive no writer, but its bytes cannot truthfully be described as untouched. The proposed docs/tests must state this explicitly.

The existing binding protects root/lock/database identity; it must not be presumed to authenticate every journal or auxiliary-file operation. The exact auxiliary-file admission and cleanup treatment is an implementation-entry item to settle from the candidate source. If safe bounded recovery cannot be established, fail unresolved; do not weaken the boundary to make acquisition succeed.

### 3.3 Preserved behavior and non-goals

`inspect_database()` and `validate_database()` stay read-only, including for a recovery-required store. They may report a precise safe reason without doing the recovery. Bootstrap/migration may need the same reason classification, but this unit does not make either operation silently recover, initialize, or adopt unknown state. The normal writer path is the selected automatic recovery entry.

Maintain the existing no-lock/no-create behavior for obvious absent, empty, and invalid non-SQLite stores and no application writes to known schema drift. The baseline tests at `tests/test_sqlite_b2c_writer_session.py:338–391` protect these distinctions.

Recovery restores storage accessibility; it does not reconstruct a dead private credential, renew policy, authorize another child invocation, or restore first-live custody. Native Section 41/C1 family recovery stays a separate read-only semantic operation under an acquired writer; storage-level rollback must not be relabeled as domain replay.

No F2 power-loss sufficiency claim follows. Retaining the current connection posture for this unit is scope isolation, not acceptance of that posture for all live durability guarantees.

### 3.4 Future acceptance evidence — not executed or authorized here

The minimum later validation must demonstrate:

* A supported isolated store with an actual engine-recognized recovery requirement reaches normal governed acquisition without an arbitrary external writable open. An injected exception alone does not prove journal recovery.
* Interrupted uncommitted issuance versus committed issuance with a lost return have distinct, correct generation/readback outcomes; recovery does not duplicate a domain effect or reuse an already committed generation.
* Observation APIs leave the database and sidecars unchanged while reporting recovery-required/unavailable truthfully.
* Busy lock, unsafe identity/link replacement, unsupported journal posture, failed recovery, and failed post-recovery schema validation return the specified refusal/uncertainty without publishing a writer or losing resource custody.
* Healthy acquisition, fencing, explicit migration, close/fork/process-control behavior and existing semantic recovery remain valid.

A controlled process-interruption fixture may eventually be justified in a disposable external copy. Its method and authorization are future work. Neither random-kill success nor a mock marker alone substitutes for the recovery-required positive. No specific Opus harness is prerequisite.

## 4. Unit 2 — legal evidence cardinality and typed malformed-input stops

### 4.1 Closed role layout, not arbitrary joins

The Wire owner permits exactly `(worker_started, worker_completed)` or `(worker_started, candidate_captured, worker_completed)`, with protocol order defined by tuple position (`.docs/rw0-b2-wire-protocol.md:49–57`; `tests/test_rw0_b2_wire_values.py:298–307`). Missing `candidate_captured` is not an explicit negative capture claim. Parent-owned capture and independent validation remain required.

D2 currently admits the actual worker sequence (`_rw0_d2a_offline.py:392–400`) and then assumes fourteen checked families in construction, separation, checkpoint validation, final handback and model-input consumers. Therefore replacing one array index is insufficient.

**Selected target:** one finite, non-I/O D2 role-resolution routine, reused at construction and independently revalidated at the final consuming boundaries. It recognizes only the two permitted layouts and their dependency-closed prefixes. It validates each actual checked family's type, rank, phase, value/ref/digest, membership/receipt, source and relationship to the original run. Kind rank or a caller-supplied role label alone is not a selector.

Let `n` be the number of observations in the revalidated original worker result, necessarily 2 or 3. The complete canonical layout is:

| Canonical role sequence | Rank | Complete count contribution |
|---|---:|---:|
| Actual ordered worker observations | 12 each | n |
| Adapter exit | 12 | 1 |
| Worker-result binding | 13 | 1 |
| Process-result classification | 14 | 1 |
| Validation authority, then review authority | 1 each | 2 |
| Readiness | 5 | 1 |
| Validation qualification, validator observation | 6, 12 | 2 |
| Review qualification, reviewer observation | 6, 12 | 2 |
| Author authority | 1 | 1 |

The complete length is `n + 11`: **13 or 14**, not arbitrary variable cardinality. Preserve canonical order. Do not sort a wrong-order input into validity, infer missing members, pad with fabricated observations, choose the first matching rank, or accept duplicates/extras. Counts validate the selected layout; they do not establish it.

The original three-observation sequence remains valid. All exact A-to-B associations, same-capsule donor refusals, reviewer separation, authority-role joins and nested revalidation remain mandatory. Nine model evidence roles, nine persisted evidence bindings, twelve common owner rows and rank-15 ownership do not change merely because the upstream C1 witness contains thirteen rather than fourteen members.

### 4.2 Complete consumer change, including stop semantics

Update the producer, reviewer-separation derivation, checkpoint validation, model-input construction and final handback checks together. Baseline anchors:

* `_rw0_d2a_offline.py:78–96,392–441,543–606`;
* `_rw0_d2a_evidence.py:401–426`;
* `_rw0_d2a_handback.py:122–145,182–207,213–260`;
* `_rw0_d2b_model_input.py:224–240,295–296,595`;
* `_rw0_d2_handback.py:44,55–155,170–171,378–427`.

Retain the ordered families as evidence; a role resolver is not a new owner of admission. Derive stop prefixes from the selected legal layout and actual reached stage, not a count guessed from the final tuple. For example, before a validator result is admitted the checked prefix has `n+7` members; before a reviewer result is admitted it has `n+9`. Existing fixed thresholds 10/12 and 14 must not reject the shorter valid path or admit an impossible longer one.

The candidate's new safe witness reportedly fixes fourteen members. Its assembler, command validation, historical reader, retained basis and final consumer must be inspected and updated consistently in a later successor. Preserve original witness bytes and meanings as historical inputs. Any change to a serialized/digested grammar needs an explicit named compatibility/version treatment; do not silently reinterpret an existing witness or regenerate historical hashes. No new SQL table or migration is presumed necessary until actual candidate DDL and parsers are inspected.

### 4.3 Malformed checker input is not failed process execution

An exit-zero checker can have a valid clean process outcome but invalid returned evidence. Baseline `_run_checker` validates and records the process before normalization (`_rw0_d2a_offline.py:315–326`). Only `_D2AStop` acquires the retained progress prefix (`:615–629`); an escaped exception instead reaches the outer dispose-and-rethrow path (`_rw0_d2_offline.py:155–157`).

**Selected target:** introduce origin-specific, closed rejection handling at the checker frame/normalization boundary. Only expected external-input decoding/validation failures become typed stopped handbacks. Preserve the validated process outcome, committed bound effects and actually checked C1 prefix. The failed checker observation must not be admitted; no downstream reviewer/model/proposal step may run past that rejection.

Use distinct stage-specific reasons for invalid validator evidence and invalid reviewer evidence. Do not call these `validator_process_failed`/`reviewer_process_failed`: those existing reasons require a non-successful process. Nor can the existing complete-checkpoint `evidence_mismatch` reason simply be reused: it currently requires fourteen checked members and two clean children (`_rw0_d2_handback.py:111–124`).

The new reasons must be checked against the exact stage, selected layout and clean retained child outcome at both construction and explicit final validation. A valid stopped run retains custody until its creator closes it. Cleanup failure remains distinguishable and must not be hidden by a protocol-invalid label.

Do not catch arbitrary `ValueError` across the entire orchestration. Separate declared child-input rejection from internal reconstruction/relationship defects, programming errors and process-control exceptions. Preserve sanitized diagnostics; do not retain raw malformed frames in public handbacks or exception graphs. This unit does not promise a typed stop for every possible internal bug.

### 4.4 Future acceptance evidence — not executed or authorized here

Require both legal worker-result shapes through actual D1→D2 composition and, on the later repaired candidate, the actual Section 41 A→C1 B→V22 continuation. The positive uses parent-captured candidate bytes; it must not directly seed target rows or manufacture a missing observation.

For both shapes, independently reject wrong ordering, duplicate/missing/foreign roles, wrong authority assignments, and same-capsule/noncapsule donors at the relevant final consumer. Demonstrate those refusals without claiming that a wrong earlier failure proves a later predicate.

For validator and reviewer separately, require an exit-zero malformed frame to return the new typed stop, exact reached prefix and truthful clean process outcome, with no admission of the malformed observation and no later dependent process. Also retain nonzero-exit, cleanup-unresolved, process-control propagation and internal-error controls so the repair does not erase the distinction it was intended to restore.

The two-second clock-skew scenario and cross-host chronology rules remain outside this repair unit. Their prior qualification is preserved.

## 5. Candidate impact map and assurance dependencies

`S/` below means `src/ge_nwp_coordinator/`. “Reported” means the supplied candidate implementation report, not direct payload inspection.

| Surface | Baseline finding / proposed role | Candidate impact and confidence limit |
|---|---|---|
| `S/sqlite_writer_session.py`, `S/sqlite_migration.py` | Acquisition/preflight/classification and current-schema validation; direct F1 repair surfaces. | Both modified by the candidate. Compare complete affected functions and callers, not line offsets or baseline patch application. Raw successor control flow remains uninspected. |
| `S/sqlite_connection.py`, `S/sqlite_security.py`, `S/sqlite_errors.py`, `S/state_authority_lock.py` | Preserve origin-specific failure and existing bound connection/lock owner; establish auxiliary-file admission without generic SQL access. | Not listed among candidate modifications. Reported inheritance supports relevance, but exact candidate bytes have not been inspected here. Edit only if the actual narrow recovery design needs it. |
| Existing D2 producer/evidence/checkpoint/model-input/handback files named in §4.2 | Fixed layout and reason-prefix consumers; complete F4/F5 repair set. | Not listed as changed by native admission. Report strongly supports inherited dependency; candidate-specific byte confirmation is still outstanding. |
| `S/_rw0_d2_post_execution_continuation.py`, `S/_section41_post_execution_proposal_mutation_contracts.py`, `S/_section41_post_execution_proposal_row_values.py`, `S/_sqlite_section41_post_execution_proposal.py` | Original-run witness, safe basis, persisted readback and continuation depend on D2 evidence. | New candidate source, not present in the baseline. The reported fourteen-member witness and progress handling require targeted inspection. Do not infer precise functions or edits from filenames alone. |
| `S/_sqlite_rw0_c1.py`, `S/sqlite_transition_transaction.py` | Shared admission/readback and operation control; preserve existing transaction ownership and fences. | Both candidate-modified. No redesign is selected; assess integration and any additional affected guarantees. |
| Migration `0005_section41_post_execution_proposal_family.sql`; pure V22; migrations 0001–0004 | Do not change schema, projection ownership or historical migration bytes merely to address cardinality. | Inspect 0005's actual constraints and safe-basis validators before deciding whether any schema treatment is necessary. The original candidate's bytes remain fixed even if a future successor differs. |

**Owning documentation:** `.docs/writer-session-authority.md`, `.docs/sqlite-bootstrap-and-migrations.md`, `.docs/sqlite-operations-and-recovery.md`, `.docs/sqlite-threat-model.md`, `.docs/rw0-d2-offline-evidence-and-review.md`, and the candidate's `.docs/section41-post-execution-proposal-family.md`. Read the D1/Wire/C1 owners as compatibility constraints. Update overarching guidance only where current claims genuinely change; no standalone status-normalization tranche is selected.

**Primary existing test surfaces:** `tests/test_sqlite_b2c_writer_session.py`, `test_sqlite_b1_connection_posture.py`, `test_sqlite_b1_filesystem_security.py`, `test_sqlite_b1_migrations.py`, `test_sqlite_c2b1_migration_framework.py`, `test_state_authority_lock.py`; and `tests/test_rw0_d2_offline_integration.py`, `test_rw0_d2_evidence_children.py`, `test_rw0_d2_model_handback.py`, `test_rw0_d2_process_frames.py`, `test_rw0_d2_c1_checked_readback.py`, with the candidate's `test_rw0_d2_post_execution_admission_integration.py` and Section 41 recovery/persistence tests.

Protect P11's actual current-file checks and historical reconstructions, the independent companion, P09, controller identities, SQL/import/caller inventories and nonimplementation boundaries. Map actual dependent assertions before freezing the edit set. Changed tests need a preserved-property explanation; do not update hashes wholesale, remove hostile cases, or treat every historical literal as a current constraint.

This table is a bounded impact map, not an authorized touched-file allowlist or an exhaustive candidate-source review.

## 6. Acceptance continuity and remaining input

The original candidate has no completed candidate-specific correctness audit to carry forward. Artifact identity checks remain useful; they do not discharge A01–A12 or execution.

For a later repair successor:

* **A01:** explicitly succeed the fixed-fourteen layout requirement with both legal closed layouts. Preserve actual original-run origin and all final associations; this is a disclosed contract change, not reduced coverage.
* **A02/A03/A08:** re-evaluate changed safe-witness schema, digest vectors and actual checked-reader/owner associations. Unchanged pure V22 is not proof of its changed inputs.
* **A05/A10/A11:** validate recovery entry, shared writer/controller interactions, semantic commit uncertainty, retained known facts and custody against the successor bytes.
* **A04/A06/A07/A09/A12:** remain mandatory; catalog compatibility, currentness, complete families, separate B transaction and assurance preservation are not waived by the narrower repairs.

All A01–A12 obligations, the connected positive, relevant discriminating controls and independent selector-free collection/FULL execution remain required for eventual acceptance. The original 9,191-pass writer run is historical evidence for its original bytes, not an expected count or a pass on a successor. Record exactly which prior observations still apply and which must be regenerated. Platform inability to perform a required part yields incomplete coverage, never acceptance or a candidate defect inferred from refusal.

**Next missing input:** the existing fixed `ReviewPackage.zip` named in §1. It is needed to finalize the candidate-specific function/schema/assurance impact and precise edit scope—not to repeat baseline triage. Missing Opus originals prevent authentication of particular historical reproductions and environment-specific conclusions, but do not prevent this source-based design or require another response from that reviewer.

No live repository or GitHub state was read for this document. The baseline archive was inspected as data and all manifest-covered members and source blob identities were checked. No uploaded program or repository code was imported/executed; no tests, migrations, database opens, fault experiments or audit retries occurred. The exact candidate payloads and Opus reproduction materials remain uninspected.

## Source coordinates and confidence

Baseline source coordinates throughout refer to the `source/` tree in the fixed D2 checkpoint. Additional constraints: `AGENTS.md:634–644` requires governing docs, tests and source to change together; `pyproject.toml:6,9–11` defines the Python minimum and pytest test root. Candidate evidence is `IMPLEMENTATION_REPORT.md:11–13,44–52,99–119,125–127`. Audit noncoverage is retained in the first provenance-stop report's §§“Scope actually reached” and “Preservation, ownership and limitations”, and the subsequent re-entry report's §§“Scope and limits”.

The original candidate audit register is §5 (A01–A12) of `Coordinator_Post_D2_Native_Proposal_Admission_Independent_Audit_Prompt.txt`; this document neither reissues that mandate nor requests execution of it. Provider refusals and withdrawal of the Opus assignment are user-reported status updates preserved above.

**Confidence:** baseline artifact identity high; baseline source mechanisms and selected repair requirements high; candidate-impact mapping provisional and report-backed; exact F1 recovery-admission implementation, successor applicability, and repair runtime correctness unvalidated.
