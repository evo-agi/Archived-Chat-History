# Coordinator F1 final package — static source and evidence review

## Disposition

`POST_D2_F1_RECOVERY_ENTRY_REPAIR_BLOCKED_BY_POST_RECOVERY_CLASSIFICATION`

The supplied package is internally authenticated and its retained implementation validation is coherent, but the exact final source has one source-supported recovery-result defect. The candidate should receive one narrow repair before independent audit.

This is a data-only review. No repository command, module import, test, database, journal, helper, or packaged program was executed.

## Authenticated subject

- Review ZIP: 46,613,017 bytes; SHA-256 `612d1256f3f00d23e39830d144a9ccb8717ae340e2d1259ce8bfcd8e8d9d9143`.
- Standalone implementation report: 8,445 bytes; SHA-256 `c6b3f4842ff0db177256b6e1c9e1d910b01aa0fefb70d7c128d59eb7b25252c2`.
- Package manifest: 4,387 covered regular members; no missing, extra, duplicate, unsafe, or mismatched member.
- Final source: 299 regular endpoints; all source-manifest sizes, modes, SHA-256 values, and Git blob IDs reproduced.
- Independently reconstructed final Git tree: `b4d2d4236b8c09d95aca8a671d02fe769370ed02`.
- Starting refusal-only tree: `b2e958c6a5d894fdf0d14dd5c821582c1d067489`.
- Incremental F1 continuation: 11 changed paths; total F1 delta from the original native candidate: 14 paths.

## Retained validation reconciliation

The final collection and execution records bind to source tree `b4d2d4236b8c09d95aca8a671d02fe769370ed02`.

- Collected IDs: 9,231, all unique.
- Executed JUnit IDs: 9,231, all unique.
- Collected and executed ID serializations are byte-identical, SHA-256 `85865c330d1f54c9f8f6785cacf8e7d09eeea7bd143a5a66338e11b8ea7a8007`.
- JUnit: 9,231 tests; zero failures, errors, or skips.
- Final output: `9231 passed, 3 warnings`; the warnings are the retained Python 3.13 fork deprecations.
- The final source comparison reports no post-run source change.

These are inspected implementation records, not an independently rerun suite.

## Finding F1-POSTREC-01

**Type:** durable-state/recovery result classification and contract drift  
**Severity:** high  
**Affected source:** `src/ge_nwp_coordinator/sqlite_writer_session.py`  
**Affected contract:** `.docs/writer-session-authority.md`; `.docs/sqlite-operations-and-recovery.md`

### Source path

`acquire_sqlite_writer_session()` performs:

1. successful `_recover_locked_hot_journal(database_binding)`;
2. binding validation;
3. a new `_require_managed_preflight(location)`;
4. only then the ordinary writer-opening and issuance path.

Relevant final-source coordinates:

- `sqlite_writer_session.py:7200-7213` — post-recovery validation and preflight;
- `sqlite_writer_session.py:7328-7345` — `_require_managed_preflight()`;
- `sqlite_writer_session.py:7287-7293` — `SQLiteWriterAcquisitionError` is rethrown unchanged.

If the post-recovery observational inspection is operationally unavailable—for example, it returns `UNKNOWN/sqlite_posture_unavailable`—`_require_managed_preflight()` raises `SQLiteWriterAcquisitionError(DATABASE_NOT_MANAGED)`. The surrounding post-recovery block converts only authority-binding mismatch/unavailability to `RECOVERY_UNRESOLVED`; it does not convert this acquisition error. The outer handler preserves the incorrect `DATABASE_NOT_MANAGED` result.

### Contract conflict

The final owner documents state:

- an operational error after recovery access or unproved cleanup reports `recovery_unresolved`;
- access/cleanup uncertainty after the engine may have changed the journal reports `recovery_unresolved`;
- an exact older or otherwise deterministically ineligible recovered store remains `database_not_managed`, with no writer and no implicit migration.

The current source does not preserve this distinction for an operational failure in the post-recovery managed preflight.

### Impact

The path fails closed and does not itself demonstrate unsafe writer issuance. However, it can report a store as `database_not_managed` after SQLite rollback has already changed storage and the product could not complete post-recovery verification. That is a materially misleading durable-state result and recreates the ambiguity F1 was intended to remove.

### Test gap

`tests/test_sqlite_writer_hot_journal_recovery.py:527-563` covers failure while opening the recovery connection or applying posture on that recovery connection. It does not cover the later post-recovery `_require_managed_preflight()`.

`tests/test_sqlite_writer_hot_journal_recovery.py:625-646` covers post-recovery authority-binding failure and correctly expects `recovery_unresolved`.

`tests/test_sqlite_writer_hot_journal_recovery.py:181-199` correctly preserves `database_not_managed` for an exact recovered older migration prefix.

No retained test exercises an operationally unavailable post-recovery managed preflight after genuine rollback.

## Required correction

Keep the repair narrow:

1. After successful engine recovery, distinguish operational inability to establish the managed posture/invariants from deterministic schema/catalog ineligibility.
2. Map the former to `RECOVERY_UNRESOLVED`.
3. Preserve `DATABASE_NOT_MANAGED` for the exact older prefix and other deterministically ineligible/unmanaged states.
4. Preserve all journal admission, binding, lock, create-disabled opening, cleanup, no-retry, no-auto-migration, and healthy publication behavior.
5. Add one causal test using a genuine hot-journal fixture: permit the real rollback, force only the subsequent managed inspection to become operationally unavailable, require `RECOVERY_UNRESOLVED`, no issuance, released lock, and a later successful acquisition after the injected failure is removed.
6. Preserve the existing exact-older-prefix test as the discriminating counterpart.

## Acceptance consequences

- Do not send tree `b4d2d4236b8c09d95aca8a671d02fe769370ed02` to an independent audit as the intended accepted F1 successor.
- Produce a new source identity and new implementation-validation/provenance package after the narrow repair.
- The original native candidate remains unaccepted.
- F4, malformed-input F5, `NPA-WITNESS-01`, F2, qualified F3/F6/F7, the historical provenance mismatches, and the unfinished candidate-specific independent audit remain separate and open.
