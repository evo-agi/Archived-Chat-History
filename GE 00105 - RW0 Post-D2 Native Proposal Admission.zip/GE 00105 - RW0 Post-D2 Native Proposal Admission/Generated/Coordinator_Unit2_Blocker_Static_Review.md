# Coordinator Unit 2 blocker static review

## Disposition

`POST_D2_UNIT2_SCOPE_AMENDMENT_SUPPORTED`

The blocked package authenticates and supports a narrow continuation. The blocker is not a contradiction in the legal Wire/C2A grammar; it is one pure-owner relation that incorrectly aliases `worker_completed` as the capture observation when the legal two-observation form is used.

## Authenticated inputs

- Blocked ZIP: 3,467,435 bytes, SHA-256 `b36c1d1e535dbcd8b792576cccb2593d0a5dc235e7c7f523b4c7b62da2175ba2`.
- Package manifest: 321 covered members, zero missing or mismatched members; `manifest.json` self-excluded.
- F1 base ZIP: 7,406,558 bytes, SHA-256 `9cb40710e2a6d2c4d13fb79196885d12d5f52ea1e7f5f7f50ebf1b48f24085b3`; all 380 manifest-covered members authenticate.
- F1 source: 299 files, reconstructed tree `93afef8750e062d80626a5a37adfa27766305b7c`.
- Blocked partial: the same 299 paths with exactly eight changed production endpoints, reconstructed tree `2df9487936436ed1b11ae73dd75d909645f0ef5a`.
- Live checkout was reported restored to the F1 base; no Unit 2 repository changes remain.

## Source finding

The C2A matrix requires no conditional fields on `worker_completed` and requires `candidate_ref` only on `candidate_captured`. The legal Wire sequence may omit `candidate_captured` while D1's parent still captures and capsules the candidate.

`evaluate_post_execution_reviewer_separation()` already accepts two or three observation memberships and the V40 schema already permits two or three ordered locators. It also independently checks:

- parent capsule candidate/capsule/digest;
- rank-13 worker-result binding candidate and lineage;
- review observation candidate/capsule/digest;
- exact C1 memberships and relations;
- author source/effect/delivery identities.

The blocking defect is the local alias:

```python
captured = author_observations[1] if count == 3 else author_observations[-1]
```

followed by an unconditional `captured.candidate_ref` comparison. For count two, the final observation is `worker_completed`, where `candidate_ref` is forbidden.

## Selected correction

Retain the existing Wire and WorkerObservation contracts. For count three, continue checking the ordinal-1 `candidate_captured` observation against the parent capsule. For count two, do not read or synthesize a capture field; bind candidate identity through the parent capsule, the rank-13 worker-result binding, and the review observation. Preserve V40 schema/profile/digest grammar and the three-observation behavior.

## Scope consequence

Add `src/ge_nwp_coordinator/_post_execution_evidence_values.py` and its direct existing pure-owner tests to the Unit 2 editable scope. No migration, physical schema, V22, D1 Wire, WorkerObservation, new file, or F1 change is justified.

The eight-file partial remains noncandidate evidence. It may be inspected and selectively reused after authentication, but implementation must restart from exact F1 tree `93af...` and produce a new identity.

## Validation consequence

The final focused selector must include direct pure-owner relation tests and unchanged C2A/WorkerObservation/Wire grammar controls, in addition to the original Unit 2 connected checkpoint and selector-free FULL gate.

## Limits

This review authenticated and inspected artifacts as data. It did not execute repository code, tests, migrations, processes, or uploaded helpers; it does not accept the partial implementation or discharge the independent audit.
