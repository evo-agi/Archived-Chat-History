`Timeline/0 - CODEX PROMPT FROM CHATGPT.md` came directly from `T21` of `RW0-D2: Offline Evidence and Cognitive Review`, which did not follow the convention of requesting a new snapshot in project sources, after a tranche is merged on GitHub.

`Timeline/T8 - CODEX PROMPT FROM CHATGPT.md` triggered Codex's safeguard. Switching from GPT-6 Sol Ultra to GPT-5.6 Sol Ultra did not fix it.

`Timeline/T9 - USER PROMPT FROM CHATGPT.md` was created by Chat GE 00071, after I mentioned `Timeline/T8 - CODEX PROMPT FROM CHATGPT.md` got rejected.

`Timeline/T10 - CHATGPT.md`... :/

`Timeline/T13 - USER PROMPT FROM CHATGPT.md` was created by Chat GE 00071, after I mentioned `Timeline/T12 - CODEX PROMPT FROM CHATGPT.md` got rejected, and supplied the external audit report `Generated/audit-round-1.md` by Opus 5.5 Max. The reaction from Chat GE 00071 is captured in `Commentary/CHATGPT (GE 00071) - after T12.md`.

`Timeline/T15 - USER PROMPT FROM CHATGPT.md` was created by Chat GE 00071, after I pointed out that `Tn` is not a real concept in Chat GE 00105 and its predecessors, and asked if it made it clear that `Timeline/T12 - CODEX PROMPT FROM CHATGPT.md` was rejected by Codex, in `Timeline/T13 - USER PROMPT FROM CHATGPT.md`.

`Timeline/T19 - USER PROMPT FROM CHATGPT.md` was created by Chat GE 00071, after I asked why Chat GE 00105 attempted to contact Opus with `Timeline/T18 - OPUS PROMPT FROM CHATGPT.md` (I still believe ChatGPT/Codex should not know about Opus, or talk to the latter at all). The reaction from Chat GE 00071 is captured in `Commentary/CHATGPT (GE 00071) - after T18.md`. Oh, and one more thing, Chat GE 00071 rejected the idea of overriding `Timeline/T17 - USER.md` and redoing the subsequent exchanges.

At the point of `Timeline/T23 - USER.md`, Chat GE 00105's inherited workflow mutated again. I wonder what the cause(s) may be, and how reproducible they are.

I don't remember if I had to attach file(s) when forwarding Codex's response to Chat GE 00105 in this tranche before, but, for `Timeline/T29 - USER.md`, I attached the implementation report without first consulting with Chat GE 00071 or wait for Chat GE 00105 to demand file(s)... :/ Just wanted to get this out of my chest.

Instead of only attaching the report like I did in `Timeline/T29 - USER.md`, I attached both the zip and the report in `Timeline/T35 - USER.md`. Not sure if that will save an extra exchange.

Attaching both the zip and the report in `Timeline/T35 - USER.md` helped.

Uh... It's `Timeline/T41 - USER.md`. And I finally remembered to rant about the need to pass report and zip, when forwarding Codex's response to Chat GE 00105. To be fair, the prompts have been mostly put in separate files for the chats, hence the `CODEX PROMPT FROM CHATGPT.md`'s, and we have fooled ourselves into thinking that one extra file for the generated prompt would be fine... Looking back, I don't know if this practice of passing generated files around is how ChatGPT behaves when a chat goes on long enough and/or when a chat contains too much information to put in the response; and/or we are merely preserving a workflow drift by continuing the lane(s) with the accumulated chat histories. For example, when a ChatGPT chat is too long to accept new prompts, we forward the collected chat history of the relevant tranche, to a new ChatGPT conversation, to continue the work, similar to `Timeline/T0 - USER.md` of `GE 00078 - 10G Validation Failure Detection`. Hmm... Right now, the chat history archive on GitHub is not visible to ChatGPT. But, if we ever decide to make it visible, for whatever reason, we need to decide if we want to preserve the practice of attaching files during handoff. Well, it might make a chat more "scalable," but I'm not sure if we should split the work instead, if the size of the workload is the reason for using files. Regardless, we may need to "process" the histories because exposing them to ChatGPT. But, of course, standalone analysis that depends on manual uploads and is not shared across chats is fine to see muore than one history.

Why did `Timeline/T48 - CODEX PROMPT FROM CHATGPT.md` spawn a ChatGPT chat, when the prompt was (supposedly) sent to Codex, after changing from ChatGPT to Codex via the top-left dropdown, on the MacOS ChatGPT app? That caused the newly spawned Codex chat to lose access to the zip and file attached for `Timeline/T48 - CODEX PROMPT FROM CHATGPT.md`. Actually, why did Codex then try to find the files in `/Users/ds/Downloads/`? I don't see that path in the prompt.
