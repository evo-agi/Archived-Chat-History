**Send one prompt:**

:chatgpt-content-reference{index="0"}[**Coordinator_Post_D2_Operative_Independent_Audit_Mandate.txt**](sandbox:/mnt/data/Coordinator_Post_D2_Operative_Independent_Audit_Mandate.txt)

Paste its complete contents into **the same independent Codex audit conversation that produced the two provenance-mismatch reports**. Keep the implementation writer idle.

The other two files are **reference documents, not additional prompts to execute**. The original `Native_Proposal_Admission_Independent_Audit_Prompt.txt` supplies the detailed sections explicitly incorporated by the replacement. The `Scoped_Provenance_and_Substantive_Audit_Prompt.txt` is the superseded T8 mandate.

**Do not concatenate the three files or submit them sequentially.** The operative mandate tells the auditor which retained materials to retrieve, authenticate, and follow. My previous response should have distinguished the single handoff from its source links more clearly.

**Confidence: high.**
