**Send this one prompt to the same implementation Codex conversation that produced the blocked F1 closeout, with write permission—not the independent auditor, Opus, or a new ChatGPT conversation.**

:chatgpt-content-reference{index="8"}[**Download the F1 recovery-dependency continuation prompt**](sandbox:/mnt/data/Coordinator_F1_Recovery_Dependency_Continuation_Prompt.txt)

No other prompt files need to accompany it. It identifies the existing local packages and supplies the complete operative instructions.

## What this continuation authorizes

The writer resumes from the exact **refusal-only partial source**:

```text
b2e958c6a5d894fdf0d14dd5c821582c1d067489
```

It must authenticate that source and the live checkout before editing. It must not restore the failed writable attempt wholesale or treat the current refusal-only behavior as completed recovery. IMPLEMENTATION_REPORT

The substantive contract change is explicit: **constrain the files and dependencies recovery may use, rather than prove that the interrupted connection never attached another database.** Super-journal/path-bearing dependencies and unsafe arrangements remain refusal conditions. The existing owner-private threat model and its race limitations remain visible. The earlier blocked experiment stays a valid record under its original requirement; it is not relabeled a pass. IMPLEMENTATION_REPORT

The handoff also addresses the three concrete implementation/provenance issues:

- **Prospective index preservation:** retain the actual current raw index and complete semantic inventory, authenticate them before proceeding, and preserve the new interval. The unexplained historical change remains unresolved—not reset or attributed to harmless housekeeping. IMPLEMENTATION_REPORT
- **Exact thirteen-creation collector:** explicitly version the external recipe’s identifier and creation inventory, preserving the original collector and failed outputs. No general provenance redesign or additional repository file is authorized. IMPLEMENTATION_REPORT
- **Healthy-path compatibility:** preserve the four original filesystem-binding error expectations and their later cleanup assertions, rather than changing tests to accept the attempted implementation’s regression.

## Required return

Codex must produce a newly identified F1 successor, an early source-bound recovery checkpoint, the finite recovery/refusal/cleanup controls, and **one final selector-free collection and FULL execution** on the final bytes. The corrected cross-file control must assess main recovery and external noninterference without inventing an I/O trace or claiming that unchanged bytes prove no external reads.

Earlier focused results cannot certify the successor. The previous interrupted FULL and missing refusal-only FULL remain incomplete evidence. IMPLEMENTATION_REPORT

**No staging, commit, publication, audit retry, or Unit 2 implementation is authorized.** F4, malformed-input F5, `NPA-WITNESS-01`, the other qualified concerns, and the unfinished candidate-specific independent audit remain open. F1 completion alone will not lift the whole correctness hold. IMPLEMENTATION_REPORT

I saved and reopened the prompt, checked its input identities and selected paths, and reverified the package’s **415 covered members and 299-file starting tree**. Those were artifact checks only; no repository code, database, test, or uploaded helper was executed.

**Sources:** The authenticated blocked package and closeout cited above; SQLite’s official rollback documentation and pinned pager source support the recovery-dependency distinction, not acceptance of the proposed implementation. [SQLite](https://www.sqlite.org/lockingv3.html)

**Confidence:** starting-artifact identity **0.99**; continuation scope **0.95**. Live provenance and repaired runtime correctness remain to be established.
