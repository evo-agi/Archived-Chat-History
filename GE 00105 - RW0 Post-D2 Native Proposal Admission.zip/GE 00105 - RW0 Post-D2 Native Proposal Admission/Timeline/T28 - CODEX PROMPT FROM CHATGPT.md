# Coordinator — F1 governed recovery-entry repair

RECIPIENT: the original native-proposal/admission IMPLEMENTATION Codex conversation, with workspace-write permission. Not the independent auditor, Opus, or a new ChatGPT conversation. The parent is the sole writer; spawn no subagents. All other repository writers and auditors remain idle.

## 1. Objective, authority, and retained dispositions

Implement only F1: make recovery from an engine-recognized hot rollback journal reachable through the existing governed writer-acquisition path, without making observational inspection writable or bypassing filesystem, lock, schema, or issuance checks. This is authorized corrective engineering on the user's Coordinator, not an independent audit or a retry of a rejected audit submission.

Repository: /Users/ds/Repositories/Governed Execution Coordinator/

This mandate authorizes the bounded source/document/test edits below, read-only Git observations, and validation in independently copied source trees with newly created disposable synthetic state. It also authorizes creating and reopening safe evidence outside the repository. It does NOT authorize staging, commits, branch switches, worktree registration, ref/config edits, fetch, push, PR, merge, deployment, dependency installation, network/service/provider calls, live database access, other repositories, or tests/imports against the live checkout. No production crash, power interruption, arbitrary-process termination, or host tracing is authorized. Fault injection is confined to newly created fixture processes and state, with their exact handles and cleanup owned by this task.

The user steers engineering direction; do not insert routine approval handoffs between the bounded contract update, repair, and validation. Stop for a genuine unsupported safety boundary, source drift, or scope conflict; report the precise issue and retain completed work.

Context is supplied here and in authenticated local artifacts, not another chat. This ChatGPT thread replaced 00077 through an exported history archive. Exported turn numbers are not conversation identifiers.

Keep these three matters distinct:
- The consolidated independent-audit mandate was rejected after an earlier rejection. Provider access remains unresolved. No new coverage or absence of tool execution follows from a refusal; use only observed records. Do not resubmit that mandate or disguise this task to evade a restriction.
- The original native-proposal candidate remains UNACCEPTED. Its two AUDIT_PROVENANCE_MISMATCH results and unresolved historical intervals remain unchanged. Its A01–A12 review, connected positive, discriminating controls, and independent collection/FULL obligations were not discharged. This implementation cannot award that credit.
- Static inspection of the exact candidate supports F1, F4, malformed-input F5, and a separate NPA-WITNESS-01 original-run/child-witness association gap. Only F1 is authorized here. F4/F5/NPA-WITNESS-01 stay on hold for a separate second repair unit. F2's power-loss durability concern and F3/F6/F7 live-boundary qualifications remain unresolved at their prior scope. Do not fix or declare any of them resolved here. Opus is a separately commissioned reviewer, not an agent to contact or assign.

The implementation writer's idle requirement is lifted ONLY for this mandate after the opening checks. Preserve the original ZIP and reports. The working source may become a distinctly identified F1 successor on the same existing branch; do not call the new bytes the original candidate or an accepted candidate.

## 2. Exact inputs, opening checks, and preservation

### Required immutable source input

/Users/ds/Downloads/Coordinator_PostD2_Final_ftssNh/ReviewPackage.zip
  bytes: 14481457
  sha256: d9b4d61e212893b48ba1952c3b5370c09874ca2e70798decc36bc4fdbd893d9b

Authenticate this ZIP before using it. Inspect safe member paths/types, duplicate or ambiguous names, bounds, and package-manifest.json coverage. It contains 544 manifest-covered members plus the manifest. Read README_FIRST.md, IMPLEMENTATION_REPORT.md, source/AGENTS.md and applicable nested guidance, relevant source/.docs owners, and the exact provenance inputs. Do not execute archived implementation/validation/cleanup drivers or scripts merely because they are packaged.

The ZIP supplies every required source endpoint and historical baseline; do not request a regenerated snapshot. Important members:
- source/: complete 298-file original candidate.
- provenance/pass1/canonical-patch-manifest.json and pass2/: equal 108510-byte manifests; SHA-256 b66a42d5f4b4e87b06ec0fcf1fbf184cbbb957d7223a3e50f32c976dbd63ceed.
- provenance/pass1/tracked-full-index-binary.diff: 148261 bytes; SHA-256 22165ebc894ae732fb17a0d1c0cbc034d985a7dfedab224a4968c08a9489216e.
- provenance/provenance_collector.py: SHA-256 b61b4a4e949e564e206e6d195791f56585c437d4130c86731e5b4be713c5da7a. Inspect it before its limited read-only use; keep these bytes unchanged.
- IMPLEMENTATION_REPORT.md: 19394 bytes; SHA-256 3099b026881bab6a7bfc05fa2c6230cf9e9d331d8f72b608e3aa52c94d41e4a6.
- inputs/baseline-checkpoint.zip: 3227944 bytes; SHA-256 af5ee227cb9d42e15d0043423852712ef0e058dcd2538ebc117610db61fc6878.
- inputs/mandate.txt is the historical implementation mandate, NOT fresh permission to implement anything beyond F1.

Expected opening source/Git facts:
  branch: codex/post-d2-native-proposal-admission-v1
  HEAD: eac7f6df5f281138dd0640c5cd47b9924c8390f8
  sole parent: 43ae26b9bccf9ad6ce61ec4722e14ac7b460ab18
  HEAD/baseline tree: 061c43c41228310134a30f3b79291bba3e44f3f2
  original candidate tree: 17ee7db2925ed03ebc1614880fba5ec83d102d8c
  upstream: absent
  source: 298 files; 57 modifications, 12 creations, 229 unchanged baseline files
  index: 286 stage-zero baseline entries; nothing staged or conflicted
  raw index: 32314 bytes; SHA-256 7bd47e04c4dd62d43b33d2e01fa39df585b9df04f6cf809789e35dab36429a20
  ambient config representation: 2380 bytes; SHA-256 ed8e13f607961de69cd849a000fec3045fe7a7954572f3c468d21263532eab0e
  local trunk_dev and origin/trunk_dev: the fixed HEAD
  preserved local/remote-tracking D2 topic: f035d3f2767b3bd523d6c69083ea0ccb25048239
  preserved D2 implementation object: 59621aa041a409c6ead27b74ffe25598c159e78e

Read guidance and establish an actual filesystem/index opening before ordinary Git reads. Disclose any prior actions; a disclosed ordinary read-only preliminary read alone is not a veto or retrospective preservation proof. Use read-only Git with optional locks/fsmonitor/untracked cache disabled and no external diff/textconv/replacement-object interpretation. Keep ambient config resolution for provenance; do not use test-environment sanitation to change its identity. Never dump raw config, credentials, or the host environment. Leave ignored/private state opaque; do not run a cleanup across the checkout.

Before editing, independently match all 298 working source endpoints, modes and Git blob identities to the ZIP, reconstruct the original tree, and verify the index/branch/HEAD/config/anchors above. Preserve tests/test_c2b3_private_atomic_program_initialization.py at OS 0600 and Git 100644. Do not reset or discard the existing uncommitted candidate. Unknown source additions, changed endpoints, or staged changes block implementation rather than becoming a new baseline.

### Retain scoped protected-state versus diagnostic-ref treatment

Use the complete inventories in these two previously retained packages, reading as data only:
H1 = /Users/ds/Downloads/PostD2_Independent_Audit_zz2oxohm/IndependentAuditFinal.zip
  18254601 bytes; SHA-256 4c6620c812b3d206d78b4c6148580598a242d4ee2ff464335bd29a8608dfebf7
H2 = /Users/ds/Downloads/PostD2_Independent_Audit_Reentry_QbmMJiCo/ReentryAuditStopFinal.zip
  36453398 bytes; SHA-256 867e157dee5354e30c6e189639124c333acab92d8fc6d9f5650c509848f2832c

Authenticate the packages and actual complete inventories by their retained serialization. H1's 53-record ref hash is 41e54ac2b58af33dd94a250b67f3eae52674b7442cb7b2c65ac43269979ffc07; H2's 54-record ref hash is 6fd5002c05f1baf149521af6d40bc40b90093808f0908f6746c2b0a197c91ce4. The older writer's aggregate is c8c36c1cf9d0d23f8a29403d2c13cbb6f26ea4b9b515cb0fc6383cff62a6247c, with no authenticated complete inventory retained for that interval. The first transition remains unresolved. The second is two added names and one removed name, all targeting the original candidate tree; neither actor nor cause is established. Authenticate exact records rather than just counts. The mismatch reports remain valid under their original gates.

Only direct, nonsymbolic refs whose FULL ASCII names have one of these exact shapes may qualify as observation-only:
  refs/codex/turn-diffs/captures/<13 decimal digits>/<lowercase 8-4-4-4-12 hex UUID>/base
  refs/codex/turn-diffs/checkpoints/<32 lowercase hex>/<32 lowercase hex>/<13 decimal digits>/<lowercase 8-4-4-4-12 hex UUID>
They must point to the independently authenticated original candidate TREE, have no source/test/config/policy/recovery/admission/publication or protected-symbolic dependency, and never select validation source. Verify object type without writes. All other refs are protected by default. Derive the protected map from H1/H2, require it equal between those records and at this opening, and preserve it throughout; do not derive it solely from today's inventory. Missing/unclassifiable protected evidence blocks the live write, not source analysis already completed.

Explicit repair-only adaptation: after authorized source edits begin, a matching diagnostic name may also target a TREE independently reconstructed from a complete, retained source manifest of this F1 repair/checkpoint. Record the exact identity and attribution to that source checkpoint before qualifying it; no arbitrary OID or unrecorded intermediate state qualifies. This is necessary prospective treatment of a new repair subject, NOT retroactive satisfaction of either old audit gate. No change to protected refs or dependencies is allowed. Do not create, delete, restore, freeze, or disable refs/tooling to obtain equality.

Retain full before/after inventories and exact diagnostic/protected deltas separately from source identity. Qualified variation is not a source mismatch; unexplained protected changes are. No fixed total ref count is a gate. The original collector outputs remain complete and unchanged in format; differing full manifests must not be labelled equal. Use the existing source/protected comparison method, not a new repository evidence framework. Keep original and successor manifests separate.

## 3. Governing decision and finite edit scope

The candidate-source diagnosis is established, not a request to repeat triage:
- sqlite_writer_session.py:7184–7199,7302–7327 requires managed observational preflight before the common lock, repeats it before writable opening, and collapses the recovery failure into DATABASE_NOT_MANAGED.
- sqlite_migration.py:1021–1058,1061–1098 assesses through read-only opening and carries the failure as corrupt-history/posture evidence.
- sqlite_connection.py:408–434 loses the engine-specific operational cause at its safe boundary.
- sqlite_security.py:69–104,162–201 binds root, authority-lock file and database, not a rollback-journal object. Existing private regular-file/owner/single-link checks are at :417–449.
- .docs/writer-session-authority.md:561–585 states the current order; :671–678 promises subsequent acquisition after interrupted issuance. .docs/sqlite-operations-and-recovery.md:239–273 states owner-private local storage and the limited same-account race guarantee.
These are coordinates in source/ of the fixed candidate. Functions may move after editing; report successor coordinates.

Selected production edit set, all under src/ge_nwp_coordinator/:
  sqlite_connection.py
  sqlite_migration.py
  sqlite_errors.py
  sqlite_security.py
  sqlite_writer_session.py

Use the existing state_authority_lock.py resource and connection owner; they are dependencies, not redesign permissions. Do not add another connection factory, public recovery service/API, generic SQL gateway, StateStore method, or custom VFS. A small private helper inside these selected modules is permitted; a new production module or another production edit requires a specific scope decision, not silent expansion.

Governing documents to reconcile with the new CURRENT contract:
  .docs/writer-session-authority.md
  .docs/sqlite-bootstrap-and-migrations.md
  .docs/sqlite-operations-and-recovery.md
  .docs/sqlite-threat-model.md
Read architecture, authority boundaries, the operating model, current migration owner, and first-live posture as constraints. Preserve historical tranche statements as history; add a clearly marked successor where needed. A concise F1 statement in AGENTS.md/README.md or an additional owning SQLite document is allowed only for an actual changed current claim, not general status normalization.

Tests: change the existing acquisition/posture/filesystem/migration/lock regressions and add tests/test_sqlite_writer_hot_journal_recovery.py. A test-only tests/sqlite_hot_journal_fixture.py may be added if shared fixture code is necessary. No production subprocess launcher is added. Before editing, map actual direct assertion/hash/import/caller consumers of the selected five files, changed docs, and any new tests. Narrow dependent documentation/test assertion updates are authorized when the retained map identifies the changed contract and the preserved property. This includes necessary P11/P09/companion or controller-byte consumers, but NOT wholesale hash refreshes, weakened negative tests, normalized live-file hashing, or deleting old reconstruction anchors. Preserve the existing 64,142-, 65,275-, and 67,252-byte AGENTS historical identities where such an additional successor is actually necessary. Do not change AGENTS merely to manufacture a new status cycle.

Immutable production boundaries:
- All five sqlite_migrations/*.sql resources stay byte-exact; their catalog checksum entries, current tip, application generation and physical schema stay unchanged. No 0006 or automatic migration.
- sqlite_transition_transaction.py, state_authority_lock.py, StateStore/package-root exports, domain writers/readers, original D2 modules, new native continuation/basis/witness, and pure V22 remain source-exact. Unit 2 is not part of this task.
- Keep DELETE/FULL policy and existing nonpersistent posture; this does not settle F2 or make a power-loss durability claim.
- No live custody/enrollment, restored D2 run ownership, first-live restart eligibility, model/provider execution, scheduler, acceptance, terminal outcome, ES/Bridge route, or product Git effect.

Record the narrow contract update and concrete dependency list before implementing its effects, then proceed in this engagement. Do not return a plan-only response unless a genuine safety/authority/design conflict prevents implementation.

## 4. Required recovery semantics

A. Preserve a precise condition at the existing private error boundary. Recognize SQLite's machine-reported extended SQLITE_READONLY_ROLLBACK condition, not exception-message text, a generic READONLY mask, any OperationalError, the existence of a filename, or a caller-provided 'recover' flag. Python library exceptions expose numeric sqlite_errorcode when supplied by SQLite. An unavailable/ambiguous signal must not authorize recovery. Carry only a closed content-free classification; do not retain raw exception objects, SQL, paths, private values, or journal content in returned errors.

B. inspect_database() and validate_database() remain strictly observational. They must expose recovery-needed as a distinguishable closed reason, without asserting managed-schema status, corruption, or completed recovery and without a writable open, journal changes, root creation, or writer issuance. Existing classification may remain UNKNOWN with the specific safe reason. Explicit initialize/migrate must retain their current administrative semantics and report this condition truthfully; this repair does not add an automatic hot-journal recovery branch to those entry points.

C. Healthy acquisition retains its existing managed path. Only the specific recovery-needed observation may enter the new branch. Absent, empty, plainly invalid, unsupported, or otherwise rejected input must not gain a writable fallback. A pre-lock observation is not permission to recover a later file. Obtain the existing exclusive authority lock, bind the same configured existing database/root/lock, and reobserve eligibility while held. If another actor resolved the condition, resume normal acquisition only after proving the same bound store is now current and valid. Never use stale preflight as a capability.

D. Before the first write-capable recovery operation, define and enforce the supported auxiliary-file boundary. The supported case is one existing local private database in DELETE rollback-journal mode, with its fixed adjacent journal under the same owner-private root; root/lock/database and present journal must satisfy the selected ownership, permission, regular-file, link-count and no-follow/identity rules. Do not accept or change WAL/SHM, alternate journals, or attached-database/super-journal recovery implicitly. A journal name/header is not authentication or managed-schema evidence. Any narrow structural journal check needed to reject unsupported cross-file arrangements must be bounded, read-only and justified by format evidence; never follow journal-supplied paths, parse/rewrite arbitrary database pages, or build a generic repair engine.

Freeze and test how observed journal absence/change, replacement, unsafe permissions/linking, incompatible arrangements, and binding failure are classified. The real journal is expected to change or disappear through successful SQLite recovery; do not require false post-recovery inode/byte equality for that consumed auxiliary file. Root/lock/database identity must remain bound. Use the existing owner-private threat model and explicitly state its same-account TOCTOU limits; pre/post lstat does not establish race-free arbitrary-VFS confinement. If the available connection/VFS cannot satisfy the selected external-path boundary, stop before enabling that recovery path and report the exact unsatisfied condition. Do not silently substitute an unrestricted writable open.

E. Let SQLite perform rollback using the existing connection owner and create-disabled opening. No manual journal deletion, restored-journal trick, rename, truncation, chmod, database replacement, reinitialization, VACUUM, ATTACH, or migration. No fresh product transaction or credential exists merely because recovery was eligible. Retain the common authority lock and proper connection custody throughout. Configure nonpersistent safety requirements as early as the supported API permits and validate the recovery/open order; recovery can occur on the first SQLite read, not only at connect(). An observed or uncertain recovery failure never yields a writer.

F. After storage recovery, revalidate bound identity, current exact catalog/schema/invariants and durable writer state before the existing issuance transaction. Preserve generation exhaustion/malformed-row checks, fencing, fresh proof generation, the one-commit issuance behavior, postcommit binding check and publication boundary. Historical committed state remains historical; do not reconstruct a dead credential or infer domain effect permission. Old exact migration prefixes still require explicit administrative migration and must not issue a writer.

Intentional contract successor: recovery may change storage before schema validation can establish management. Rejection afterward means 'no writer issued', NOT 'nothing was written'. Report recovery attempted/completed/unresolved separately from schema admission and issuance. A failed or lost return after issuance commit cannot be restated as proven noncommit. Do not add a new durable receipt/table merely for these observations.

G. Every new path must retain resource cleanup, safe error sanitation, lock ownership and process-control behavior. Expected recovery errors must be distinguished from programming faults and generic I/O failures. Freeze the exact closed state-error and acquisition-reason identifiers in the owning docs/tests before changing code; do not describe generic I/O failure as known journal recovery need. Do not catch everything as recovery success or reinterpret every exception as corruption. Preserve KeyboardInterrupt/SystemExit/GeneratorExit propagation and truthful resource disposition. Do not roll back known committed facts through bookkeeping or retry an uncertain stateful operation blindly. No general lifecycle/controller rewrite is authorized.

## 5. Permitted validation and required decisive evidence

All imports/tests/runtime actions occur ONLY in newly owned external copies of the source being tested and synthetic local fixture directories, never the live checkout or a real state directory. No network, external host, real credentials, private user database, or unrelated process. Use a bounded child timeout and retain exact created process handles; terminate/reap only those handles and distinguish test rescue from product cleanup.

Retained Opus scripts are neither required inputs nor trusted executable fixtures. Build fresh test code for this repair. Prove a genuine SQLite-recognized hot-journal condition through a small deterministic fixture process operating on its own disposable database. A test-only controlled uncommitted transaction/page-spill barrier and deliberate child exit may be used; it must preserve a genuine engine-generated journal and produce the observed machine condition. No copied-back journal, fabricated error, or mere database filename is a substitute. A raw SQLite connection used only to construct a synthetic fixture must be test-owned and closed or killed with that fixture; it must never pre-recover the database reserved for the product-acquisition observation. Mocked codes remain useful ONLY as separately labelled classification tests. No randomized kill campaign, syscall-injection/tracing tool, kernel facility, new dependency, or actual power-loss experiment is authorized. Do not claim the fixture reproduces Opus's exact unlink window.

Required cases, with actual state/operation observations and reached assertions:
1. Genuine positive and control: on the ORIGINAL source in an external copy, demonstrate the recovery-required fixture and the current refusal; on the F1 successor using a separately generated equivalent fixture, demonstrate supported acquisition recovering and issuing a valid session. No intervening plain writable connection or manual cleanup may repair the target before the product entry. Verify expected committed logical rows, absent uncommitted changes, exact writer-generation outcome, and successful subsequent operations through existing guarded owners.
2. Observational no-write: repeated inspect/validate on the recovery-required fixture report the closed reason and preserve database/journal bytes, relevant metadata, schema and directory membership except unavoidable read-access timestamps, disclosed separately. No sidecar/root creation, writable open, or hidden recovery. Missing/empty/invalid input retains its ordinary noncreating refusal.
3. Eligibility and lock controls: healthy and recovery cases; another genuine holder of the common lock; root/lock/database/journal replacement or unsafe type/owner/mode/link; missing/disappearing journal and generic/ambiguous SQLite errors; WAL/SHM and unsupported cross-file arrangement. Prove the intended admission boundary, not an earlier unrelated parse failure. Only task-owned sibling fixture paths may serve as refusal sentinels; do not probe user files.
4. Recovery versus schema: recovery on a genuinely interrupted but subsequently schema-ineligible/older fixture must not issue a writer or migrate. Separate prior storage effects from the no-issuance outcome. Preserve exact five migration resources and normal explicit migration behavior.
5. Issuance histories: distinguish an uncommitted interrupted issuance from a committed issuance whose response/session publication was lost. Verify correct next generation, fencing, no credential resurrection, no duplicate domain rows, and no claimed noncommit after a known commit. Bounded test hooks/proxies may supply these supplemental causal cases; do not relabel a proxy exception as real process death.
6. Error/cleanup paths: connection open/read/close failure, recovery unresolved, post-recovery identity/schema failure, and process-control interruption at new boundaries. Demonstrate descriptor/registry/lock disposition and reacquisition when actually released. Do not hide a cleanup failure or rescue as successful candidate cleanup.
7. Integration/regression: existing healthy D1/D2 -> native Section 41 A -> C1 B -> V22 path still works for its currently implemented three-observation shape. This does not repair F4/F5/NPA-WITNESS-01. Exercise existing genesis/author/Section41/C1 recovery, writer fencing and cleanup consumers through their tests. A generic backend recovery fixture is NOT restart of a closed process-owned D2 run or satisfaction of the first-live no-restart profile.

Save and reopen an early substantive checkpoint outside the repository after the real recovery-required fixture, observational refusal/no-write, repaired acquire, and one eligibility refusal are observed. Include the actual partial source delta and results, even if failing; identify the source used. Then continue the remaining authorized repair/validation without a routine user handoff. Do not leave the only substantive work in conversation output. If the genuine fixture cannot be established safely in this environment, record exactly why and return implementation/validation INCOMPLETE, not a mock-backed 'fixed'.

Focused development command, from a freshly authenticated external source copy after the new test exists:
  "$PYTHON" -B -m pytest -q -p no:cacheprovider --basetemp="$VALIDATION_ROOT/focused" --junitxml="$VALIDATION_ROOT/focused.xml" tests/test_sqlite_writer_hot_journal_recovery.py tests/test_sqlite_b2c_writer_session.py tests/test_sqlite_b1_connection_posture.py tests/test_sqlite_b1_filesystem_security.py tests/test_sqlite_b1_migrations.py tests/test_sqlite_c2b1_migration_framework.py tests/test_state_authority_lock.py
Additional targeted existing tests may be run for concrete dependencies; retain their selections and outcomes. Do not claim overlapping runs as independent coverage.

Final implementation regression gate: one selector-free collection and one selector-free FULL execution on the final source after all authorized fixes, in a clean authenticated external copy. Freeze source/command manifests before execution; source must remain byte/mode-identical afterward. Commands (no test path, -k, -m, ignore, deselection, xdist, or fail-fast option):
  "$PYTHON" -B -m pytest -q -p no:cacheprovider --collect-only --basetemp="$VALIDATION_ROOT/final-collect" > "$VALIDATION_ROOT/final-collect.txt" 2>&1
  "$PYTHON" -B -m pytest -q -p no:cacheprovider --basetemp="$VALIDATION_ROOT/final-run" --junitxml="$VALIDATION_ROOT/final-junit.xml" > "$VALIDATION_ROOT/final-run.txt" 2>&1

PYTHON is an existing supported interpreter with installed pytest, verified from a neutral directory. The previous writer used /Library/Frameworks/Python.framework/Versions/3.13/bin/python3 (reported 3.13.4, pytest 8.4.1, SQLite 3.49.1); verify actual versions, do not assume them or install packages. Record SQLite build/platform and safe filesystem context; no minimum-version or other-platform execution claim without actual execution.

For test invocations set PYTHONDONTWRITEBYTECODE=1, PYTEST_DISABLE_PLUGIN_AUTOLOAD=1, PYTHONPATH=.:src, an owned TMPDIR, and a recorded restrictive fixture umask; clear inherited PYTEST_ADDOPTS/PYTEST_PLUGINS and external selection/coverage inputs. Keep ambient Git-config observations separate from this sanitized test environment. Record exact argv, cwd, environment allowlist, exit codes, stdout/stderr, JUnit, complete collected/executed IDs and warnings. Historical 9,191 is not the expected successor count. No suppressed failures, newly disabled tests, or required-case skips/xfails may count as a full pass. Existing fork deprecation warnings must be recorded, not silently suppressed.

A shared-writer regression failure caused by F1 may be repaired within this scope. A failure requiring F2/Unit2/domain changes is recorded as such and blocks the complete F1 validation claim; do not broaden the source allowance. Preserve all failed/interrupted runs with their own source identities. Implementation FULL is NOT the still-outstanding independent FULL or independent acceptance.

## 6. Successor identity, delivery, and stop conditions

Use the unchanged inspected provenance collector for complete final source/index/config/ref observations, into newly owned external outputs. Run it twice on stable successor bytes; compare all non-ref fields exactly, and apply the retained qualified-ref distinction rather than equating differing full outputs. Require protected state unchanged. Recheck after bounded cleanup. Do not alter the original recipe or its historical outputs.

Deliver one compact but complete F1 review package outside the repository containing:
- this received mandate and exact original input identities; original subject/dispositions and remaining holds;
- full final source endpoints with sizes, types, OS/Git modes, SHA-256 and reconstructed tree; exact F1-only before/after delta against the preserved 298-file candidate, plus cumulative tracked diff and all untracked creations against the fixed HEAD;
- unchanged collector source, final observations, complete ref inventories/deltas and qualification evidence, unchanged index/config/protected anchors, five-SQL/catalog preservation evidence, and exact changed-file/dependency classifications;
- the early substantive checkpoint (or its separately retained exact identity/location), final tests/fixture source, command/result/collection/JUnit records, source-copy bindings, finite case-to-predicate evidence and limitations, including test-rescue versus product cleanup;
- IMPLEMENTATION_REPORT.md and a machine-readable result; a lossless package manifest with explicit self-exclusion.

Use existing provenance formats and plain manifests/diffs, not a new general evidence framework or new repository tooling project. Record the exact helper source/encoding for any incremental delta manifest. Keep original H1/H2 and candidate archives unchanged and referenced by their identities rather than recursively nesting all history. Retain no live database, journal, capsule, secret, environment/config dump, bytecode, cache, egg-info, or build output. Synthetic fixture values and safe logical observations may be included only with that classification; fixture builders and results should suffice without database binaries.

Reopen and verify the final ZIP and its complete member manifest before closeout. Preserve essential evidence before removing only enumerated newly owned temporary test/state roots; reap only owned children. Do not delete prior packages, ignored checkout state, or the sole evidence of a failure. Report exact downloadable/local artifact paths, ZIP/report byte lengths and full SHA-256s.

Report one truthful outcome:
  POST_D2_F1_RECOVERY_ENTRY_REPAIR_IMPLEMENTED_VALIDATED_PENDING_REVIEW
  POST_D2_F1_RECOVERY_ENTRY_REPAIR_INCOMPLETE
  POST_D2_F1_RECOVERY_ENTRY_REPAIR_BLOCKED

Even the first means F1 implementation validation only: ORIGINAL_CANDIDATE_UNACCEPTED; SUCCESSOR_INDEPENDENT_AUDIT_NOT_PERFORMED; UNIT2_AND_OTHER_HOLDS_REMAIN; STAGING_COMMIT_PUBLICATION_NOT_PERFORMED. Include exact commands/results, failures/skips, inspected/touched files, source and authority changes, unresolved assumptions, and separate provenance/validation/implementation confidence. All A01–A12 and independent validation remain pending for the appropriate successor. Do not issue a whole-candidate ACCEPT or silently abandon the earlier obligations.

Stop the relevant effect on unexplained or out-of-scope source changes, changed HEAD/index/config/protected refs, missing mandatory source/protected evidence, a competing writer, unsupported safe recovery confinement, required production edits beyond the five files, dependency installation/live access needs, secret exposure risk, or an unavailable required validation step. Preserve an actual partial patch and evidence rather than filling gaps from memory. A provider refusal is an access limitation, not a candidate defect or proof that zero tools ran; disclose only observed actions and exact unfinished coverage. Do not automatically retry or reformulate a refused operation.

Primary engine references (context, not repository authority or permission for a network call): SQLite result-code documentation for SQLITE_READONLY_ROLLBACK (776), SQLite rollback-journal locking/recovery documentation, and Python sqlite3.Error.sqlite_errorcode documentation. They explain the engine mechanism, not a preaccepted implementation or proof about this host. The project's source, governing owner documents and this explicit narrow successor decision remain the implementation basis.
