Objective

Repair one source-supported classification defect in the current F1 successor:
after SQLite has performed admitted hot-journal rollback, an operational failure
of the subsequent managed preflight must report `recovery_unresolved`, while an
exact older or otherwise deterministically ineligible recovered database must
remain `database_not_managed`.

Recipient and repository

Use the same workspace-write Codex implementation conversation that produced
`POST_D2_F1_RECOVERY_ENTRY_REPAIR_IMPLEMENTED_VALIDATED_PENDING_REVIEW`.
Repository:
`/Users/ds/Repositories/Governed Execution Coordinator/`

This is a narrow repair continuation. Do not start another reconnaissance,
independent audit, Unit 2 implementation, or publication gate. You are the sole
writer. Spawn no subagents while mutation is permitted.

Fixed input and opening identity

Authenticate before editing:

- review package:
  `/Users/ds/Downloads/Coordinator_F1_Dependency_4_lsuogh/F1RecoveryDependencyReviewFinal.zip`
- exact size: `46613017`
- SHA-256:
  `612d1256f3f00d23e39830d144a9ccb8717ae340e2d1259ce8bfcd8e8d9d9143`
- expected current 299-file source tree:
  `b4d2d4236b8c09d95aca8a671d02fe769370ed02`
- expected branch:
  `codex/post-d2-native-proposal-admission-v1`
- expected HEAD:
  `eac7f6df5f281138dd0640c5cd47b9924c8390f8`
- expected HEAD tree:
  `061c43c41228310134a30f3b79291bba3e44f3f2`
- expected upstream: absent
- authoritative-ref map: the exact 32-record map and canonical hash
  `eaee93514b861f8dcf1d949c426acd164debfd01f9f6b1317b432a20b9b8b09e`
  retained in the package
- diagnostic-ref treatment: retain the exact capture/checkpoint name policy and
  lossless sidecars from the v3 collector; do not classify by source-tree target
- prospective raw-index opening: retain the current raw bytes and semantic entry
  map before ordinary Git operations; do not reset or rewrite the index

Read repository guidance first. Authenticate the package manifest, final source
manifest, final v3 collector source/freeze, opening anchors, and live source.
Stop without editing on a source, semantic-index, configuration, authoritative-
ref, branch, HEAD, upstream, mode, or protected-file mismatch. Qualified
capture/checkpoint diagnostic variation remains observable but is not a source
identity mismatch under the existing v3 policy. Preserve all historical index
and ref gaps as unresolved history; do not claim retroactive preservation.

Defect to repair

In the fixed final source:

- `src/ge_nwp_coordinator/sqlite_writer_session.py:7200-7213` performs engine
  recovery and then calls `_require_managed_preflight(location)`;
- `_require_managed_preflight` at `:7328-7345` maps an operationally unavailable
  inspection such as `UNKNOWN/sqlite_posture_unavailable` to
  `database_not_managed`;
- the post-recovery block converts binding mismatch/unavailability, but not this
  `SQLiteWriterAcquisitionError`, to `recovery_unresolved`;
- the outer acquisition handler rethrows that reason unchanged.

This conflicts with the current F1 owner contract: after write-capable recovery
access, operational inability to establish the post-recovery state is
`recovery_unresolved`; an exact older or otherwise deterministically ineligible
recovered store remains `database_not_managed` and receives no writer or
implicit migration.

Implementation requirements

1. Make the smallest explicit source change that preserves that distinction.
   Do not blanket-map every post-recovery refusal to `recovery_unresolved`.
2. Preserve `database_not_managed` for the exact recovered migration-0004 prefix
   and other deterministic catalog/schema/invariant ineligibility.
3. Preserve `recovery_unresolved` for operational inability to complete the
   post-recovery managed assessment after SQLite may have changed storage.
4. Preserve all existing behavior for:
   - exact numeric 776 detection;
   - observational inspect/validate no-write behavior;
   - initialize/migrate refusal;
   - common authority lock and root/lock/database binding;
   - fixed adjacent DELETE-journal admission and super-journal refusal;
   - create-disabled bound recovery open;
   - process-control exceptions;
   - binding-change and cleanup uncertainty;
   - healthy acquisition and publication-binding error reasons;
   - no automatic retry, migration, reinitialization, or journal deletion;
   - all five migrations, migration/catalog identities, application generation,
     schemas, transactions, D2/native continuation, and public/package surfaces.
5. Do not add a new error vocabulary unless an existing closed reason cannot
   express the required distinction. The current owner documents already state
   the intended result; change documentation only if needed to remove a real
   inconsistency, not to describe development history.

Required causal regression

Add the regression to the existing
`tests/test_sqlite_writer_hot_journal_recovery.py`; do not create another test
file or change the v3 thirteen-creation inventory.

The test must:

- create a genuine engine-recognized hot DELETE journal using the existing
  synthetic fixture;
- allow the admitted engine rollback to occur and establish that the main
  journal was consumed or the equivalent retained recovery effect occurred;
- inject failure only into the subsequent post-recovery managed inspection,
  not the recovery connection's initial open/posture step;
- require `SQLiteWriterAcquisitionFailureReason.RECOVERY_UNRESOLVED`;
- establish that no writer issuance was added, the authority lock was released,
  and no hidden retry occurred;
- remove the injection and prove the same recovered current store can then
  acquire the next expected writer generation;
- retain the existing exact-older-prefix case as a discriminating positive for
  `DATABASE_NOT_MANAGED` and explicit migration-only upgrade;
- retain all existing post-recovery binding and recovery-open/posture controls.

Do not satisfy the test solely through a mocked top-level exception. The fixture
must perform real SQLite rollback; the narrow injection may control the later
assessment result or its underlying observational open.

Touched-file ceiling

Expected direct changes:

- `src/ge_nwp_coordinator/sqlite_writer_session.py`
- `tests/test_sqlite_writer_hot_journal_recovery.py`

A directly owning document may change only if source inspection proves the
current text cannot accurately express the repaired behavior. Stop and report
before editing any migration, SQL resource, schema owner, transaction owner,
D1/D2/native-admission module, package export, public API, or unrelated test.

Validation

Use authenticated external source copies only. Do not import or test the live
checkout.

First save and reopen a source-bound targeted checkpoint containing:

- the new causal post-recovery operational-failure regression;
- the existing exact-older-prefix discriminator;
- the existing recovery-open/posture-unresolved case;
- the existing post-recovery binding-failure case;
- one ordinary successful hot-journal recovery and next-generation issuance.

Then run and retain:

1. the complete `tests/test_sqlite_writer_hot_journal_recovery.py`;
2. the same eight-module focused selection used by the final F1 package:
   - `tests/test_sqlite_writer_hot_journal_recovery.py`
   - `tests/test_sqlite_b2c_writer_session.py`
   - `tests/test_sqlite_b1_connection_posture.py`
   - `tests/test_sqlite_b1_filesystem_security.py`
   - `tests/test_sqlite_b1_migrations.py`
   - `tests/test_sqlite_c2b1_migration_framework.py`
   - `tests/test_state_authority_lock.py`
   - `tests/test_b3c1b_rollback_only_writer_fencing.py`
3. the current-shape D1/D2 -> Section 41 A -> C1 B -> V22 positive used in the
   prior F1 closeout;
4. one final selector-free collection and one selector-free FULL execution on
   the exact final bytes, with collection/executed/JUnit ID reconciliation;
5. source/mode equality after every retained run and `git diff --check`.

Use the existing installed interpreter and isolated-environment posture from the
accepted F1 implementation evidence unless the authenticated repository contract
requires otherwise. Do not install dependencies, contact networks or live
services, or use a user database.

Provenance and delivery

- Preserve the original candidate, refusal-only, failed-attempt, blocked-opening,
  and current F1 package identities as history.
- Use the already frozen external v3 provenance collector and exact thirteen-
  creation inventory. Do not edit the historical collector or invent another
  provenance framework.
- Run final provenance twice and after cleanup; require identical canonical
  bytes for source, diff, semantic index, raw-index prospective interval,
  configuration, authoritative refs, and the defined diagnostic policy.
- Retain complete diagnostic ref inventories/deltas as sidecars.
- Package the complete final 299-file source, exact delta against tree
  `b4d2d4236b8c09d95aca8a671d02fe769370ed02`, targeted and final validation,
  provenance, cleanup, assumptions, and nonclaims.
- Save, reopen, and verify the review package before reporting it.

Return

Return one disposition and one downloadable/reopenable review package. Report:

- new final source tree and exact changed paths;
- the implemented classification rule;
- targeted, focused, connected-positive, collection, FULL, warning/skip results;
- exact provenance identities and any diagnostic ref variation;
- failed/interrupted validation and its source identity;
- remaining holds and all unperformed work.

Stop conditions

Stop without claiming completion if the live source does not match the fixed
starting subject, the correction requires widening recovery authority or schema,
the older-prefix distinction cannot be preserved, a required causal test cannot
be constructed safely, final FULL does not pass, final provenance is unstable,
or platform policy prevents required work. Preserve partial findings and exact
unperformed coverage.

Effects not authorized

No staging, commit, push, PR, merge, branch deletion, publication, deployment,
network/provider/ES/Bridge access, live database recovery, host crash or power-
loss experiment, custom VFS, Unit 2/F4/F5/NPA repair, independent audit, or
acceptance claim is authorized.

The original native candidate and this F1 successor remain unaccepted until the
new bytes receive their separately governed review. F4, malformed-input F5,
`NPA-WITNESS-01`, F2, qualified F3/F6/F7, historical provenance limits, and the
unfinished candidate-specific independent audit remain open.
