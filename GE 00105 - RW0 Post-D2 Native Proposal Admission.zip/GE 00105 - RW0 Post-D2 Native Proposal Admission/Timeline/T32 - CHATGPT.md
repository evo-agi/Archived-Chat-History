**The package authenticates. My recommendation is a narrowly corrected F1 recovery contract—not a custom VFS or a broader containment project. The attempted implementation must remain disabled until a newly identified successor satisfies that corrected contract and its validation.**

The important correction is to distinguish **which files recovery may access** from **whether the interrupted transaction ever involved another database**. The supplied experiment demonstrates a limitation of the latter requirement; it does not demonstrate an escape from the former.

:chatgpt-content-reference{index="11"}[**Package review and engineering decision**](sandbox:/mnt/data/Coordinator_F1_Blocked_Package_Review_and_Decision.md)

This is the review record for this conversation, **not a prompt to send to Codex**.

## What the package establishes

I verified the ZIP’s advertised **4,030,365-byte size and SHA-256**, all **415 manifest-covered members**, and both F1 source variants. Independently reconstructed Git trees match all three recorded subjects: the original 298-file candidate, the attempted writable repair, and the current 299-file refusal-only partial patch. Both F1-only diffs reproduce their respective raw endpoints.

The current partial source is indeed refusal-only. It recognizes `recovery_needed`, but still refuses writable recovery before issuing a writer. The attempted recovery helper is absent, and `sqlite_security.py` is restored to the original candidate’s bytes. All five migrations remain unchanged. This corroborates the reported source disposition, **not fresh live-checkout preservation or runtime acceptance**. IMPLEMENTATION_REPORT

## 1. The counterexample is narrower than its “unsafe admission” label

The retained script performs `ATTACH` through a direct synthetic SQLite connection, starts a transaction, spills main-database pages, inserts an auxiliary row, and exits **without attempting COMMIT**. Its output records successful writer generation 1 afterward, removal of the main journal, and continued existence of the external journal.

The script does **not** record the external journal’s header or engine classification, before/after contents, or an I/O trace. Therefore:

**It establishes an undetected cross-file transaction origin. It does not establish that the external journal was hot, that recovery accessed or modified it, or that either database became corrupt.** Conversely, it also does not prove absence of external access.

Those distinctions come directly from `attempted/probe_attached_outside_decisive.py:7–29` and its six-line log. The closeout report already distinguishes this from a claim that the external database was recovered. IMPLEMENTATION_REPORT

There is also an attribution limit: the probe lacks its own retained invocation receipt binding argv, environment, and source hash. Its association with the attempted source comes from the package/report and surrounding records. That is useful evidence, but not the same as an independently rerun, completely source-bound experiment.

## 2. Select recovery-dependency confinement, not historical attachment proof

**My previous F1 mandate allowed its “one-database” condition to become an unnecessarily strong historical claim.** Codex correctly stopped under that interpretation. I would now change the prospective requirement explicitly, without relabeling that stopped attempt as successful.

The existing storage contract selects owner-private local storage and acknowledges limited same-account race resistance; it does not authenticate the history of every raw SQLite connection that previously accessed the database. See `.docs/sqlite-operations-and-recovery.md:265–297` and `.docs/sqlite-threat-model.md:288–312` in the refusal-only source.

SQLite’s documented ordering explains why that matters: pages can spill before COMMIT, while the super-journal is introduced later in the multi-database commit sequence. Thus, a main journal without a super-journal reference is not proof that no other database participated earlier. [SQLite](https://www.sqlite.org/lockingv3.html)

**The selected successor requirement should be: recover only the bound main database and its fixed adjacent journal, without following external recovery dependencies.** That retains the important safety conditions:

- Reject super-journal/path-bearing recovery dependencies, unsupported sidecars, unsafe links or permissions, and observed binding changes before the relevant write-capable access.
- Retain the existing authority lock, connection owner, create-disabled opening, and post-recovery schema and writer-state validation.
- Do not claim complete attachment-history provenance or race-free confinement beyond the existing owner-private threat model.

This is a deliberate scope correction—not permission for an unrestricted writable fallback. SQLite’s version-3.49.1 pager source makes super-journal processing conditional on a name read from the journal tail, supporting this distinction between *recovery dependencies* and *earlier transaction history*. That source inspection does not certify the installed binary/VFS or the attempted helper. [GitHub](https://raw.githubusercontent.com/sqlite/sqlite/version-3.49.1/src/pager.c)

Under this corrected contract, **an unrelated surviving journal outside the root is not, by itself, a failure**. A future test must instead establish correct main-database recovery and the claimed external noninterference. Merely checking that outside bytes stayed equal would not prove there were no outside reads.

A stronger confinement mechanism remains an option **only if the actual recovery-access boundary cannot be met within the explicitly supported threat model**. This probe does not establish that necessity.

## 3. The four FULL failures have a concrete, separate cause

All four failures are parameters of:

```text
tests/test_b3c1b_rollback_only_writer_fencing.py
test_writer_acquisition_rechecks_filesystem_binding_before_publication
```

They inject database, root, lock, or hardlink drift at the postcommit publication check. Each receives the expected acquisition exception, then fails because its reason is **`writer_acquisition_failed` instead of `database_not_managed`**.

The attempted code introduced that change in `sqlite_writer_session.py:7290–7303`: its new binding-error handler branches on `committed`. The existing regression expects the original reason at test line 1095.

**These are real compatibility failures, not observed successful writer publication.** They also cannot establish all later cleanup assertions, because execution stops at the reason assertion. The existing test already expects the next successful issuance to reach generation 2, so its original `database_not_managed` result did **not** imply that no issuance row had committed.

The bounded correction is to preserve the healthy acquisition path’s existing classification, while handling recovery-specific outcomes separately—not refresh the assertions merely to make the suite pass. The later 93-test result applies to the different refusal-only source, where the original mapping was restored. IMPLEMENTATION_REPORT

## 4. One validation claim needs tighter source attribution

**The 291-pass focused run did not execute the exact final attempted tree.**

Its retained source manifest differs from `attempted/final-source-manifest.json` at four endpoints: two documents, `sqlite_writer_session.py`, and the new recovery test. Consequently, those 291 passes belong to an earlier development version; they cannot certify tree `ce18ef08e935e69980c7c5adf3486c39685df4c9`.

The final attempted-source collection contains **9,215 distinct IDs**. Its interrupted execution records **1,525 passes and four failures**, not a passing FULL run. I reconciled the XML’s extra unnamed unfinished element without crediting it as another passed test.

For the refusal-only source, the retained records support **370 distinct passing tests**, not 378: all eight target cases are included in the 277-test focused selection, while the 93 binding cases are separate. These are inspected implementation records, not tests I reran. There remains **no final selector-free collection/FULL result for that source**. IMPLEMENTATION_REPORT

## 5. The index issue cannot be explained from the retained bytes

The package contains the opening and closing index hashes, but **neither raw index payload**. We therefore cannot determine which fields changed, identify the actor, or classify the difference as harmless cache refresh. The historical exact-byte preservation failure stands. IMPLEMENTATION_REPORT

There is narrower supporting evidence: both failed collector executions reached the thirteen-versus-twelve creation-count check **after** the collector had compared the complete stage-zero index with the baseline tree. That supports semantic equality at those observations; it does not explain the raw change or reconstruct the missing historical interval.

For a later continuation, I recommend a **prospective opening**, explicitly recording the unresolved interval: retain the actual current raw index and complete semantic entry map, require the latter to equal the unchanged baseline, and authenticate the source and protected Git state before allowing edits. Do not reset the index or pretend the old hash was preserved.

The collector’s hardcoded twelve-creation requirement is independently confirmed. Its successor must explicitly account for the authorized thirteenth test while preserving the original recipe and failed outputs. **No new general provenance framework is needed.** IMPLEMENTATION_REPORT

## Recommended next action

**The next Codex assignment should be a bounded F1 continuation against the exact refusal-only source:**

```text
b2e958c6a5d894fdf0d14dd5c821582c1d067489
```

It should combine the prospective provenance opening, the explicit recovery-contract correction, preservation of healthy-path error behavior, and source-bound synthetic validation followed by final collection/FULL execution. It must produce a new successor identity—not restore the attempted tree or declare refusal-only behavior to be completed recovery.

**No further package, Opus response, historical crash reconstruction, or full reconnaissance is needed to select that direction.** This review does not issue that assignment; keep the writer idle for now.

The original candidate remains unaccepted. F4, malformed-input F5, `NPA-WITNESS-01`, and the other qualified concerns remain open. Provider audit access is still unresolved, and neither this review nor the implementation tests discharge the outstanding candidate-specific independent audit. Both historical provenance mismatches remain recorded. IMPLEMENTATION_REPORT IMPLEMENTATION_REPORT

**Sources and limits:** Authenticated package source, scripts, manifests, logs, and XML; exact coordinates and reconciliation details are in the linked review. Official SQLite documentation/source was checked separately for the engine mechanism. No repository commands, uploaded programs, candidate imports, databases, tests, crash probes, or live-checkout operations were executed.

**Confidence:** artifact/source identity **0.99**; interpretation of the probe and four failures **0.97**; corrected engineering direction **0.94**. Future recovery correctness and historical index-change cause remain unestablished.
