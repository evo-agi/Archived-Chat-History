# Coordinator post-D2 cumulative candidate — artifact-only independent audit

## Objective

Independently audit the exact cumulative post-D2 candidate contained in the sealed review archive below. This is a defensive local software-correctness, durable-state, and validation review. Do not repair the candidate.

Use a **fresh independent Codex conversation**. The implementation writer must remain idle.

## Fixed inputs

The user will attach both files to this conversation:

1. `PostD2Unit2TypedChildRepairReviewPackage.zip`
   - size: `5,912,014` bytes
   - SHA-256: `a019b8afca2f71efb1400c7b83d9710b5379a74975f3748981d2e31059e248cd`
2. `IMPLEMENTATION_REPORT.md`
   - size: `10,127` bytes
   - SHA-256: `bffe86f1cf983bc06263668c83275e82de3274a7919b674f7d0a2036b708d4fa`

The sole candidate source is the archive's `source/` tree:

- 299 files
- Git-compatible tree: `8633f700647bcdd19451a6840295a527940e7a3b`
- immediate predecessor tree: `a0b52ca6f396638ee5615ad75523a394dba637a0`
- frozen F1 base tree: `93afef8750e062d80626a5a37adfa27766305b7c`

Useful package anchors:

- `package-manifest.json`: 72,319 bytes; SHA-256 `90bac7fb81b0f79ec06141648d6892d45a7e8d834c7159d262d744721454871c`
- `evidence/source-final-manifest.json`: 76,923 bytes; SHA-256 `78b18c8647538401ab75d62fbb895fa68ab654d5a527a8b5a96743b36590301a`
- `evidence/exact-delta.json`: 2,969 bytes; SHA-256 `b3f7a4cdf2f61a280b9979dd27f094022ce6b6ec17316190a2bf6498b1b3b5c7`
- `evidence/delta-from-a0b52ca6.patch`: 9,086 bytes; SHA-256 `9aa0ac14c536e790613279a16f95ec750e2e3aba5556183f98cb20c62666c4ea`
- `evidence/causal-control-register.json`: 18,529 bytes; SHA-256 `3e42efe1f87423c1863450be499eddd93fa99f296cc0ef16c501788d956862d3`
- final provenance manifest: `evidence/provenance/final-a/canonical-patch-manifest.json`, 116,404 bytes; SHA-256 `90e4c2e0e2db99f139b26b759d578445fbddfec39ccefe88604118ccca6ab51a`

The packaged and standalone implementation reports must be byte-identical.

## Effect ceiling

This audit is **artifact-only** with isolated local validation.

Allowed:

- read the attached files;
- extract the ZIP into newly created task-owned directories;
- inspect source, docs, tests, SQL, manifests, logs, JUnit, and inert helper source;
- execute repository tests only from a fresh copy of the authenticated `source/` tree, using new synthetic temporary state;
- create audit artifacts outside the extracted source tree.

Forbidden:

- access or inspect the live repository checkout, `.git`, refs, index, config, caches, ignored files, user databases, credentials, or unrelated host state;
- network access, package installation, live services, provider calls, ES/Bridge calls, or live targets;
- source repair, formatting, staging, commit, push, PR, merge, publication, migration of a real database, or any product effect;
- execution of archived helper programs without first inspecting their exact source and deciding that execution is necessary and within this ceiling.

Historical live-ref/index provenance mismatches remain unresolved records. They are not silently cured, but they are not part of this artifact-only correctness gate. A later commit gate must independently prove that the live checkout matches any accepted package bytes exactly.

If the platform refuses or cannot perform a required action, preserve completed findings and return `...AUDIT_INCOMPLETE` with the exact unperformed coverage. A platform refusal is neither a candidate defect nor acceptance.

## 1. Authentication and scoped provenance

Before semantic review or test execution:

1. Verify both fixed file identities.
2. Inspect the ZIP centrally before extraction: normalized unique relative names, regular files/directories only, no traversal, links, special files, ambiguous duplicates, or unsafe expansion.
3. Verify every member covered by `package-manifest.json`; confirm its explicit self-exclusion.
4. Verify `evidence/source-final-manifest.json`, every `source/` byte and mode, and independently reconstruct tree `8633f700647bcdd19451a6840295a527940e7a3b`.
5. Verify the exact three-path successor delta from `a0b52ca6...`; confirm all other 296 paths are byte- and mode-identical to that predecessor as recorded by the package.
6. Verify all fourteen frozen F1 paths are unchanged from tree `93afef...` using the supplied evidence.
7. Verify the packaged report equals the standalone report and reconcile the final validation/provenance identities.

On any package/member/source mismatch, stop with:

`AUDIT_PROVENANCE_MISMATCH`

Do not substitute live repository state or regenerate a new target.

## 2. Substantive correctness review and permitted local validation

Read `source/AGENTS.md`, `source/README.md`, the owning documents, all changed source/tests, migration 0005 and its catalog consumers, the complete affected shared functions, and the retained evidence listed below. State the exact inspection boundary.

Maintain an A01–A12 register. For every row record governing and candidate path:line, inspected dataflow, normal and discriminating evidence, causal/structural/report-only credit, masking or unfinished coverage, and disposition.

### A01 — Original-run origin and final association

Trace one original open D2 run through Section 41 transaction A, checked A readback, separate C1 rank-15 transaction B, checked A/B readback, and unchanged V22. Verify the legal two- and three-observation D1 forms map to exact 13- and 14-member layouts without synthesized fields or positional ambiguity. Check final A-to-B role/source/policy/risk/authority/capsule relationships and original process custody.

### A02 — Closed schemas, safe basis, and privacy

Verify command, result, recovery, context, receipt, and exact eight-field safe-basis schemas; canonical duplicate-key-free UTF-8; bounds, types, cardinalities, bool-as-int rejection, and recursive retention limits. Confirm V07/V08 metadata is distinct from V10/V11 supplied private values. No raw capsule, prompt, artifact narrative/response, paths, runtime handles, PID/cwd/environment/stdout, credentials, or private evidence may become durable safe output.

### A03 — Digest graph and command identity

Derive the complete digest order independently. Confirm no self-reference; committed projection excludes its own digest, dependent receipt digest, and fresh/replay presentation status. Verify stable preassigned C1 identities, changed-command conflict under an occupied mutation ref, and independent row/receipt/value validation.

### A04 — DDL, migration, and compatibility

Inspect migration `0005_section41_post_execution_proposal_family.sql`, row definitions, catalog/framework changes, and actual schema inventory. Verify two new STRICT tables, four immutability triggers, no unintended seed/index, exact FK/unique routes, and preservation of migrations 0001–0004. Check fresh initialization, supported-prefix explicit migration, rollback on failed migration, partial/unknown state refusal, old-binary/new-schema refusal, and no automatic migration during ordinary validation/acquisition. Distinguish tested SQLite 3.49.1 behavior from the minimum-version contract.

### A05 — Shared controller/session safety and F1 recovery

Audit the complete operation path through the existing guard/lease/slot, authority lock, fencing, transaction controller, one commit attempt, capability invalidation, cleanup, and error sanitization. Verify the bounded hot-journal recovery dependency: observational inspection remains no-write; only the supported bound main database/fixed adjacent DELETE journal can be admitted; unsafe/super-journal/changed evidence refuses before write-capable access; post-recovery operational uncertainty is `recovery_unresolved`; deterministic ineligibility remains `database_not_managed`; no hidden retry, implicit migration, raw connection escape, or writer across child launches.

### A06 — Fresh currentness versus historical replay

Verify transaction-A currentness is resampled under the writer fence and is not the earlier D2 B-time observation. Check independent controlling expiries/head/stop/fence predicates, equality rejection for fresh recording, and exact replay/readback after expiry or head movement without retiming historical evidence.

### A07 — Complete family, occupancy, and same-transaction gates

Check all global source/artifact/proposal/context/receipt routes, all nine evidence keys, evidence-set reuse, complete bounded SELECT gates, exact roles/ranks/order/required flags/digests, receipt-last ordering, rollback/no-fragment behavior, no upsert/adoption/alternate IDs, and no repair of foreign or partial rows.

### A08 — Checked SQL readback and unchanged V22

Trace actual SELECT tuples through typed construction. Verify the Section 41 reader returns the twelve real common owner rows, context, safe basis, and receipt; the C1 reader returns the real rank-15 family; and unchanged V22 consumes those actual values rather than caller-authored expected values. Confirm both 13/14 historical readbacks require no child/model rerun.

### A09 — Separate B transaction and stable identities

Verify B is built only after checked A, uses the preassigned stable C1 identities and original CAS preimages, and does not combine ownership with A. A committed proposal without C1 admission is a legitimate distinct state. A B refusal or proven noncommit must not fabricate admission or a C2 block.

### A10 — Commit uncertainty and recovery

Inspect before/after underlying-commit exceptions for A and B, at-most-one attempt, cleanup/readback failures, complete-absence proof, foreign/partial-route handling, receipt-first read-only recovery, and truthful `committed_exact` / `definitely_not_committed` / `unresolved` classification. Do not infer noncommit from a missing return or missing receipt alone.

### A11 — Reached facts, typed checker stops, custody, and disposal

Verify exact prefixes for legal 2/3 layouts. Canonical digest-valid child frames with invalid dates or invalid role-specific outcome/reason pairs must produce `validator_evidence_invalid` or `reviewer_evidence_invalid`, preserve the reached prefix, and prevent later checker/model/native effects. Process failure, cleanup-unresolved, programming faults, and process-control exceptions remain distinct. Verify original-process run ownership and truthful outer disposal outcomes.

### A12 — Assurance successors and documentation

Review P09/P11/raw-file historical reconstruction, caller/import guards, source inventories, migration/catalog assertions, frozen F1 paths, current status text, and all changed assurance consumers. Ensure no guard was merely refreshed or weakened to obtain passing tests, and no documentation claims C2 decision/acceptance, live custody, product execution, or publication.

### Required evidence review

Inspect as data, at minimum:

- `evidence/IMPLEMENTATION_REPORT.md`
- `evidence/exact-delta.json` and `evidence/delta-from-a0b52ca6.patch`
- `evidence/FirstSubstantiveCheckpoint.zip` and checkpoint reconciliation
- `evidence/causal-control-register.json`
- every `evidence/validation/{direct,focused,connected,full}/` receipt, ID inventory, logs, JUnit, warnings, and source-before/after record
- `evidence/provenance/opening-v3/`, `final-a/`, `final-b/`, and `post-cleanup/`
- cleanup and precleanup evidence manifests

The writer's 80, 3,330, 6, and 9,291 passing results are retained implementation evidence, not independent validation.

### Independent execution

Only after source review finds no material blocker, create a new isolated copy of the authenticated `source/` tree and run exactly one selector-free collection and one selector-free FULL execution.

From the isolated source root, using an already installed interpreter only:

```text
PYTHONDONTWRITEBYTECODE=1
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTHONPATH=.:src
python3 -B -m pytest -q -p no:cacheprovider --collect-only --basetemp=<new-owned-collect>
python3 -B -m pytest -q -p no:cacheprovider --basetemp=<new-owned-run> --junitxml=<new-owned-junit>
```

Requirements:

- no path, `-k`, `-m`, ignore/deselect, xdist, skip/xfail injection, warning suppression, or install;
- record exact interpreter path/version, pytest version, SQLite version, argv, cwd, nonsecret environment, exits, complete collected IDs, JUnit IDs, warnings, failures/errors/skips, and source before/after identities;
- reconcile actual results with the packaged 9,291 inventory without forcing that number;
- preserve failed helper attempts and do not repeat an uncertain stateful action without inspecting its effects;
- use only newly created synthetic state and task-owned temporary paths;
- verify all 299 source bytes/modes unchanged after execution.

A material source finding may stop broader execution. Record exactly which A-rows and validation obligations remain unperformed.

## 3. Final findings and acceptance limitations

Return one disposition:

- `POST_D2_CUMULATIVE_CANDIDATE_ACCEPTED_READY_FOR_COMMIT_GATE`
- `POST_D2_CUMULATIVE_CANDIDATE_AUDIT_BLOCKED`
- `POST_D2_CUMULATIVE_CANDIDATE_AUDIT_INCOMPLETE`
- `AUDIT_PROVENANCE_MISMATCH`

Acceptance requires:

- exact package/source authentication;
- complete A01–A12 review;
- no unresolved material correctness/authority/security finding within scope;
- decisive connected, recovery, legal-layout, typed-stop, and witness-association evidence;
- reconciled retained evidence;
- successful independent selector-free collection and FULL execution on unchanged extracted bytes.

Matching hashes or a green suite alone is insufficient. Unsupported or unperformed required work precludes acceptance.

Report separately:

1. artifact/source provenance confidence;
2. independent validation confidence;
3. implementation confidence;
4. historical live-provenance limits that remain unresolved but were outside this artifact-only gate;
5. exact performed work, findings, masking/coverage limits, and unperformed obligations.

Acceptance applies only to the sealed package bytes and permits consideration of a **separate** live reauthentication, stage, validation, commit, and publication gate. It authorizes no repository mutation or product effect.

Retain one safe audit report and, where supported, one manifest-covered evidence ZIP outside the extracted source. Do not nest the original archive. Remove only enumerated audit-created temporary copies after essential evidence is retained and reopened.
