# Post-D2 native post-execution proposal admission — parent-only implementation

## 0. Objective, decision, and effect ceiling

Implement one connected artificial offline continuation:

actual original open D2 run
  -> native Section 41 post-execution family recording (transaction A)
  -> independently checked committed-family readback
  -> existing C1 rank-15 single-member admission (transaction B)
  -> checked C1 + Section 41 readback
  -> existing pure Section 41 projection (V22)
  -> stop without a C2 decision, acceptance, terminal outcome, or executable permission.

This is a new post-D2 tranche, not a repair, reopening, or reinterpretation of the accepted D2 v1 proof. The engineering decision adopts the two-transaction recommendation, with the explicit corrections and scope additions below. Do not repeat reconnaissance or ask for approval at each internal checkpoint. Freeze the bounded owning contract and its test obligations before the new runtime implementation, then complete the connected result in this same engagement. A genuinely unresolved authority or incompatible migration decision still stops its dependent implementation.

Repository: /Users/ds/Repositories/Governed Execution Coordinator/

Use the SAME Codex conversation that produced RECOMMENDATION.md, now with repository write permission. The parent is the only writer. All prior explorers must be finished/closed; spawn no subagents or independent auditors in this turn.

Authorized: inspect the fixed source and safe local metadata; create and switch to the exact new local branch specified below; edit the bounded docs/source/tests/schema surfaces; create owned external validation copies and synthetic test databases; run the specified local validation there; correct in-scope implementation/test failures; retain a complete safe review package outside the repository.

Not authorized: staging, commit/amend, push, PR, merge, fetch, reset/clean, remote/network/service/provider calls, dependency installation, changes to any other repository, access or migration of real operator state, live grants or supplier work, product Git effects, deployment, or independent acceptance. Do not execute uploaded checkpoint/reviewer helpers. Newly authored or modified repository code runs only in an authenticated external validation copy, never in the live checkout. Synthetic fake planner/worker/checker/model processes under existing test contracts are allowed there; real Codex/provider/ES/Bridge execution is not.

The architecture target remains autonomous development under standing policy without a user in routine progression. This tranche removes one internal handoff in an offline proof; it does not claim to deliver that complete target.

## 1. Fixed inputs and prospective opening

Integrated baseline commit: eac7f6df5f281138dd0640c5cd47b9924c8390f8
Sole parent: 43ae26b9bccf9ad6ce61ec4722e14ac7b460ab18
Accepted tree: 061c43c41228310134a30f3b79291bba3e44f3f2
Preserved source implementation: 59621aa041a409c6ead27b74ffe25598c159e78e
Preserved status/P11 tip: f035d3f2767b3bd523d6c69083ea0ccb25048239
Expected starting checkout: codex/rw0-d2-offline-evidence-cognitive-review-v1 at f035d3f2767b3bd523d6c69083ea0ccb25048239
Expected upstream: origin/codex/rw0-d2-offline-evidence-cognitive-review-v1 at that same topic tip
Expected local trunk_dev and local origin/trunk_dev: eac7f6df5f281138dd0640c5cd47b9924c8390f8
Expected source/index: 286 entries, clean, accepted tree. Same tree does not mean same history.

Fixed checkpoint:
/Users/ds/Downloads/RW0_D2_PR15_Squash_Integration_q_bbr1om/RW0_D2_PR15_Source_Checkpoint.zip
Bytes: 3227944
SHA-256: af5ee227cb9d42e15d0043423852712ef0e058dcd2538ebc117610db61fc6878

Reconnaissance report:
/Users/ds/Downloads/Coordinator_PostD2_Recon_vzYHK2/RECOMMENDATION.md
Bytes: 46961
SHA-256: 50a059f55fcd4c494ef0c6fea1e0c5b9863ec1b99a76fd02d0e1a624c4465699

Read AGENTS.md and applicable nested guidance before repository commands. Authenticate both inputs, inspect them as data, and verify the complete source_manifest/package_manifest. The checkpoint's 319 covered members, 286 source entries, 17421866 source bytes, and accepted Git tree were independently checked by ChatGPT; verify the live equality yourself. Do not run evidence/*.py from the archive. A file-location adjustment is acceptable only after finding the exact same already-created bytes in the named task's known Downloads locations; do not regenerate a baseline or search unrelated private trees.

Record a prospective opening for source bytes/modes, stage-zero index and raw index identity, branch/upstream, refs, and configuration identity. Preserve the known ignored cache opaquely; no cleanup or enumeration of unrelated sensitive material. The existing tests/test_c2b3_private_atomic_program_initialization.py has OS mode 0600 while its Git mode is 100644: preserve, do not chmod it. Do not print config values, credentials, real database content, or ignored private paths.

Use GIT_OPTIONAL_LOCKS=0, --no-optional-locks, core.fsmonitor=false and core.untrackedCache=false for observations; disable external diff/textconv on diff commands. A fully disclosed ordinary preliminary read-only command is not an automatic terminal blocker solely because it preceded guidance. Start preservation at the actual opening and retain the earlier gap. Unknown/mutating actions or unexplained source/ref drift are not excused; never reset a successful opening to conceal drift.

After the clean expected baseline is authenticated, this one local branch operation is authorized:
  git --no-optional-locks -c core.fsmonitor=false switch --no-track -c codex/post-d2-native-proposal-admission-v1 eac7f6df5f281138dd0640c5cd47b9924c8390f8

First require that the new branch does not exist and inspect applicable checkout hook/filter posture without executing unreviewed code. Do not force, reuse a preexisting branch, overwrite work, invoke an unreviewed hook, or change persistent configuration. The new branch starts at the integrated squash with no upstream. Preserve the original local/remote-tracking topic and both trunk refs. Record the authorized HEAD/new-ref transition separately from preservation of unrelated state; ordinary checkout index bookkeeping is not source drift, but it must be identified. No branch operation is to be repeated after uncertain success without readback. If the actual starting branch differs, report safe identity drift rather than silently absorbing it.

## 2. Governing decisions and corrections to reconnaissance

The two transactions are selected, not merely alternatives for further exploration:
- Section 41 records and owns its native proposal/context/receipt family.
- C1 separately admits exactly the persisted twelve common owner rows. It neither authors Section 41 rows nor absorbs the new Section 41 receipt/context into its frozen graph.
- The existing resource-bound transaction controller and guarded writer session remain the only connection/transaction owners. No second connection factory, generic SQL gateway, mutable status store, or public API is introduced.
- V22 remains pure and unchanged. Expected output is an assertion, never substitute input authority.
- The model's five recommendations remain evidence. None is a Coordinator acceptance, durable block, terminal decision, or permission.

Adopt these source-verified corrections explicitly in the contract and report:

A. Checked-readback gap. _sqlite_rw0_c1.py:5039-5057 has a D2-specific checked-value union and :5124-5126 excludes rank 15. The internal wrapper machinery already supports rank 15. Extend only the private rank selector/type or a precisely bounded equivalent; ALSO supply a separate Section 41 checked reader returning actual twelve owner row values and exact SELECT tuples. Adding 15 to a set alone is insufficient for _section41_post_execution_proposal_family_projection.py:627-703.

B. V-number/privacy correction. The recommendation sometimes calls full evidence supply "V08". In the accepted source:
  V07 = PostExecutionPrivateInputManifestV2 (safe metadata manifest);
  V08 = PostExecutionPrivateInputManifestEntryV2 (metadata entry within V07);
  V10 = PostExecutionEvidenceSupplyV2;
  V11 = PostExecutionRoleSupplyV2 (includes typed_canonical_value and support data).
Source: _post_execution_evidence_values.py:2173-2285,2609-2643,2711-2779. Freeze retention by exact schema IDs, types and field names, not shorthand V numbers. The metadata entry is permitted only through the explicitly allowlisted V07 schema; full V10/V11 supplied values and raw private payloads are not persisted wholesale.

C. Migration/test dependency completion. The recommendation's 49-module selector (43 existing + 6 proposed) omits tests/test_sqlite_c2b2_migration_0002.py. It independently pins the current catalog at 0004 (:58-61), cumulative counts (:130-134), and current documentation/catalog behavior (:4370 onward). Include its narrowly scoped current-suffix successor while preserving the literal 0002 oracle. Also update the actual migration owners .docs/sqlite-bootstrap-and-migrations.md, .docs/sqlite-operations-and-recovery.md, .docs/sqlite-schema-v1.md, and .docs/sqlite-state-backend-adr.md. Do not let an omitted indirect consumer create another artificial scope-stop loop.

D. Digest construction. Freeze an acyclic dependency order for command, safe basis, context/common row digests, mutation graph, committed result projection, receipt, and returned presentation result. The committed result projection MUST NOT include its own digest, the receipt digest that depends on it, or fresh-versus-replay presentation status. The final result may include the receipt identity after it is computed. Existing C1 distinguishes these layers at _rw0_c1_semantic_values.py:1183-1253; preserve that design principle without changing the C1 v1 grammar.

E. D2 compatibility and custody. Implement an adjacent private outer continuation entry in _rw0_d2_post_execution_continuation.py that calls run_rw0_d2_offline once and owns its lifetime. Leave the existing D2 function, original handback meaning, fake-model identities, and original pure owners unchanged. A lower-level continuation may borrow the exact original open run for tests/foreground composition; borrowing is not disposal ownership. The outer owner must close the run in finally and disclose unresolved cleanup instead of fabricating clean success. No new public CLI, StateStore/WriterSession protocol, package-root export, scheduler, or callback-based authority interface.

F. Validation choice. Because this patch changes the common migration tip and shared writer/controller, the operative final regression is ONE selector-free full collection and ONE full execution of the completed candidate. This includes the report's 49 modules and shared persistence/transaction/session tests, rather than treating that incomplete selector as a sufficient final gate. Do not also run the entire 49-module union as another ceremonial final gate. Targeted development/connected-checkpoint tests are allowed; failed/intermediate attempts remain reported. Historical 9098/1013 counts are not expected counts for this new source.

## 3. Governing files, current contracts, and deferred seams

Read the current controlling sections and explicit supersessions in:
- AGENTS.md; README.md; .docs/autonomous-software-development-operating-model.md (composition owner; no root PLANS.md exists in this checkpoint).
- .docs/c2b-durable-development-state.md, repaired Section 41 and current implementation/status treatment; Section 42 is not an alternative semantic owner.
- .docs/rw0-d1-offline-process-and-capsule-spine.md; .docs/rw0-d2-offline-evidence-and-review.md; .docs/rw0-c1-durable-evidence.md.
- .docs/architecture.md; .docs/authority-boundaries.md; the four migration owners listed above.
- .docs/rw0-c2-durable-progression-decision-semantic-contract.md; .docs/rw0-c2-private-value-versioning.md; .docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md; .docs/rw0-c2-scope-admission-provisioning-contract.md; .docs/rw0-c2-first-live-proof-posture.md.
- The existing session/controller/nominal-read/commit-close/recovery rules and affected tests, not merely the new family code.

Classifications:
Current invariants: single existing writer/controller, exact fencing before protected reads, nominal capability lifetime, private sanitized errors, one commit attempt, receipt-first historical replay, owner-specific recovery, existing C1 semantics, preserved pre-execution v1 contracts.
Bounded proof: one artificial D2 invocation, fake processes/sources, original process-owned temporary state, no real custody/supplier.
Selected new contract: native Section 41 post-execution write/receipt/readback and connected C1 rank-15 continuation.
Compatibility: generic common Section 41/C1 0-or-9 representation stays intact; this producer and V22 require nine. D2 v1 still ends at preadmission_ready.
Reopened assertion: the current catalog ends at 0004 / there is no 0005. Replace only as an explicit Section 41 additive successor; do not preserve a tranche-status assertion as a permanent architecture invariant.
Deferred: physical C2 decision/guard/admission provisioning/acceptance/terminal storage; multi-run D2 identity allocation; restart-safe custody; real supplier conformance; live model/worker/provider/ES/Bridge; product Git and autonomy loop.

The offline permission follows .docs/rw0-c2-first-live-proof-posture.md:200-218 and the explicit real-custody qualifier in .docs/rw0-c2-scope-admission-provisioning-contract.md:305-315. It is not a waiver of live gate B. Artificial local process witnesses, SQLite rows and writer locks do not satisfy external custody/enrollment/fencing requirements. Do not generalize this proof's one-run/process lifetime into the production architecture or a promise that the first live service is complete.

## 4. Internal contract freeze, migration, and privacy basis

Before runtime implementation, write the narrow Section 41 successor and its contract-test obligations. Prefer one subordinate .docs/section41-post-execution-proposal-family.md explicitly incorporated by the existing Section 41 owner, not a second competing source of truth. Record exact command/result/recovery schemas, graph and digest order, safe-basis field allowlist, fresh/replay/currentness cases, bounded queries, collisions, A/B state transitions, disposal ownership, SQL DDL/column order/FKs/triggers, catalog checksum and compatibility treatment. This is an internal dependency in the authorized implementation, not a user approval checkpoint or a separate contract-only delivered tranche.

Selected migration: 0005_section41_post_execution_proposal_family.sql, exactly two new immutable STRICT tables:
1. development_post_execution_proposal_contexts: post phase, context identity, proposal identity, phase-basis identity, bounded canonical safe_basis_bytes + digest, context-row digest and exact uniqueness/FK routes.
2. development_post_execution_proposal_receipts: mutation/command/schema identity, the exact phase/context/proposal/source/artifact/evidence-set identities, safe-basis identity, preassigned C1 mutation/membership refs, mutation-graph and committed-result digests, committed outcome/time and receipt digest.

Use immediate restricted FKs and explicit unique composite parent keys. Bind the phase-qualified common proposal and existing C1 phase without editing old tables. Every repeated digest/coordinate not mechanically enforced by an existing FK must be enforced by typed construction and complete writer/readback verification; do not describe a ref-only FK as a digest equality check. Preserve the exact same-transaction Section 41 evidence gate. Add UPDATE and DELETE guards for each new table, zero seed rows, and only necessary inline-key indexes. Derive the full catalog/schema manifest, explicit-index distinction and column/FK/trigger counts from the selected DDL, not a report total. Starting cumulative counts are 62 tables/110 triggers/5 explicit indexes; two tables/four immutability triggers imply 64/114 if no other justified objects are selected. Do not silently add another durable owner or table.

Preserve these literal production migration bytes:
- 0001_initial.sql: 17940 bytes; SHA-256 1a3af0f4dc3a9df8fe0a745a68a98590e56dd6f9dc7aeeced3aa975839543148
- 0002_development_program_and_effect_state.sql: 154434 bytes; SHA-256 5859f49994b1467db71911fb60db4f1cfc562af7517dc6e4d81b5b29ca44d56c
- 0003_cognitive_proposal_and_selection_state.sql: 161472 bytes; SHA-256 b5c7cac8e074b77ab369579f1f8015f547f1a2776b4b09d612e56280f16c1579
- 0004_rw0_c1_durable_evidence.sql: 289058 bytes; SHA-256 967b9c2deb43da625f9ce82d43c9538bfd2fa27c02f3abdfcb12eb3a2aef8cec

Keep generation 2 only with explicit additive-framework/SQLite-minimum compatibility proof. Existing 0004 states require explicit administrative migrate_database() before normal writer admission; initialize applies all five; validation/acquisition/product mutation never auto-migrate. Exercise migration only on newly owned synthetic external fixtures, including a populated valid supported prefix and failure/rollback cases. Old-binary/new-schema refusal remains. Do not touch an operator's actual database. If generation 2 cannot correctly express the required compatibility, stop that implementation with the exact conflict rather than silently bumping generation.

Current C2 documents' prospective 0005 references need a bounded successor to a later additive suffix, currently expected 0006. This does NOT freeze a C2 physical schema or create 0006. Historical 0004/0005 assertions must be explicitly scoped, not globally replaced across archives and older contracts.

Safe basis: at most 131072 bytes of canonical duplicate-key-free UTF-8 JSON in a BLOB, exact closed top-level fields:
  lineage_v01
  context_v02
  capsule_safe_projection_v04
  model_safe_projection_v05
  private_input_manifest_v07
  model_input_binding_v09
  artifact_safe_projection
  d2_checkpoint_witness

Define the exact recursively allowed schemas/fields/array cardinalities/byte ceilings and domain-separated digest. The witness holds the ordered 14 C1 membership selectors with necessary exact identities, two bound-effect receipt selectors, and three child-role safe outcome digests/clean-separation attestations. Bind them to the actual original run and persisted owners at writing. Reuse exact existing typed constructors and relation validators, not just shape/self-hash checks. Restrict V07/V08 to ref/schema/digest/length/classification metadata. Reject unknown fields, non-exact builtins, bool-as-int, noncanonical input, excessive nesting/size and invalid repeated relations.

Do not persist V10/V11 wholesale, prompts, artifact narrative/raw response, capsule/file blobs, raw WorkSpec, PID/cwd/environment/stdout, run objects, handles, paths, or credentials. A canonical JSON container is not permission to store arbitrary payloads. At the 131072 bound and one byte beyond, test explicit acceptance/refusal as applicable; do not truncate or silently enlarge the ceiling. Prove real positive fixtures fit.

A historical process witness is a checker attestation bound to consumed evidence, NOT independent replay of the children or external source authentication. Readback reconstructs the actual retained safe values and persistent owners; it cannot recover deliberately unretained private bytes. State that limitation rather than calling all transient facts independently revalidated after custody disappears.

## 5. Native transaction A: recording and checked readback

Introduce a closed private RecordPostExecutionProposalCommandV1 and safe result/recovery types, with family-local names/version domains. The command binds the preassigned mutation ref, phase/V02 context, source/artifact/proposal/evidence-set refs/digests, exact ordered nine evidence roles/ranks/ordinals/schema/ref/digest identities, canonical safe-basis digest, and preassigned C1 route. It contains no caller-authored SQL row set, receipt, authority Boolean, connection, mutable head, path, or run owner. Derive bounded safe C1 mutation/membership references once from stable preassigned identities (not a self-referential command digest), and store them in the A receipt.

Fresh recording additionally requires the exact original open run through a separate nonserialized bounded in-process operand. Close its dependency/import boundary explicitly; it is not a general callback or self-attesting safe dictionary. Preserve D1/D2 typed revalidation, exact A-to-B association, capsule, checking effects, ordered C1 members, source profiles/supports, policy/risk/authority roles and process separation at the FINAL consuming boundary. Reject a detached donor with internally valid values, a same-capsule/different-policy transplant, and forged nested wrappers. Basic custody/type validation is not expiry validation: never make receipt-first historical replay contingent on a fresh model/source/current-head check.

Use the existing _SQLiteWriterSession private guarded operation and sqlite_transition_transaction.py resource-owned operation lease, slot, BEGIN IMMEDIATE, fencing, nominal capabilities and close-proof discipline. Extend through a family-local operation only. Do not reuse the pre-execution receipt/disposition/head or insert dummy C2 facts.

Required transaction ordering:
1. Exact local closed-world preflight under normal session precedence; no row/receipt disclosure or raw connection escape.
2. Acquire the existing operation lease/slot and transaction resource; fence before any protected receipt or owner lookup.
3. Receipt lookup by mutation ref. On a hit verify the entire original context/common/evidence/receipt graph, then exact command association. A mismatching command is an identity conflict, not a repaired family or a fresh write. Historical replay does not sample fresh authority/expiry or run a child.
4. On receipt miss, sample the native operation timestamp under the owning transaction contract and re-read actual current phase/program/work/selection/effect/delivery/stop owners. Compare exact frozen original D2 B-time coordinates; never replace them with newer heads. Revalidate all required currentness/expiry premises from the original consumed run. Equality with expiry rejects fresh admission. Historical role observations retain their original times; the transaction check is a distinct new instant. Bind proposal/source chronology to the operation time. Do not claim continuous validity until a later wall-clock COMMIT.
5. Probe ALL relevant global and composite routes, including source/artifact/proposal/context/receipt, evidence-set use in common rows and all nine evidence-binding keys. No upsert, alternate generated route, adoption or fragment completion. D2's literal global refs permit one distinct D2 review per disposable database; exact replay is allowed, a second distinct output colliding on any route is no-write.
6. Insert source, artifact binding, proposal, safe context and exactly nine evidence-binding rows in the contract's immediate-FK order. Reuse existing common row types/phase meanings. Run the exact proposal LIMIT 2 and ordered evidence LIMIT 10 gate after the family writes and before receipt disclosure or COMMIT. Require exact nine roles/ranks/ordinal zero/required flags, complete set digest, same source/proposal/context relations, and no extras. Generic existing 0-or-9 remains supported outside this selected producer.
7. Construct/insert receipt LAST; fully read back and verify the persisted family, safe basis, self/graph/result/receipt digests and all associations in the same transaction. Invalidate capability before the one commit attempt.
8. Return fresh_committed only after commit and the owning close/cleanup publication boundary are proven. Once commit is attempted, later ordinary wrapper/delegate/connection/capability/lease/slot cleanup failures cannot be downgraded to no-write; use existing commit-uncertainty posture. Governing process-control exceptions retain their own sanitization/ownership semantics.

Provide one private bounded fenced reader for the Section 41 family that returns reconstructed V02/safe basis/receipt, actual source/artifact/proposal/nine evidence row values, and their actual explicit-column SELECT tuples in V22's order. Do not manufacture SELECT tuples by reserializing a caller's expected object. Verify historical persistent relations, including referenced immutable phase/C1/effect facts as required by the frozen witness. Read errors, extra rows or unknown structures fail closed. No raw connection or public reader surface.

## 6. Recovery, second transaction, and foreground result

Precompute exact bounded recovery selectors before any A or B commit attempt. Include every key needed to distinguish absence from a partial/foreign family; a missing receipt alone never proves noncommit.

A recovery is read-only through an independently acquired fenced writer:
- committed_exact: exact receipt-first complete historical family and original command identity proved;
- definitely_not_committed: exact necessary prerequisite identities proved and EVERY claimed route absent;
- unresolved: partial, foreign, contradictory, inaccessible or unverifiable state.

No recovery writes, retries, repairs fragments, invents IDs, reruns the model, or grants permission. If definitely_not_committed, a separately initiated exact-command attempt is possible only while the same original run remains valid and all fresh premises hold; the continuation does not automatically perform that retry. Exact historical replay/recovery remains valid after expiry or later head movement and uses persisted semantic time. A fresh session is not a process restart or custody restoration.

After A is proven committed, close its session. In a fresh session build B's existing C1 rank-15 command from CHECKED persisted twelve common owner rows, immutable original phase CAS preimages and the preassigned C1 route. Freeze the exact B command/recovery selector before B's attempt and prove that same-command reconstruction is deterministic; never read later heads into a replacement command. Verify A's receipt/context separately. C1's existing CAS, admission grammar, receipt-first replay and recovery remain owners; do not add A's two new rows to its twelve-row graph or broaden rank 15's generic representation.

If B's fresh CAS rejects after A committed, retain A and report proposal_recorded_not_admitted. It is neither an atomic rollback of A nor a C2 block. If B's commit is uncertain, use only C1's read-only recovery before claiming admission; unresolved remains unresolved. Proven B commitment followed by failed final readback/projection is distinguishable from failure to commit B. Do not label all later failures simply "not admitted" or discard known committed facts. No duplicate A/B operation or new model run on lost response.

Extend C1 checked rank-15 support narrowly. Obtain its actual value, relation, membership, receipt/mutation identity and admission graph along with the Section 41 reader's actual owner data. Invoke unchanged V22. Any expected projection passed to V22 is independently assembled from those checked owners, not an authority shortcut. A successful final proof requires both committed families, exact checked associations and the coherent projection.

The new outer private foreground entry calls D2 once, borrows that original run across A/B/readback/projection, and closes it by its creator process in finally. Factor a borrowed internal continuation so replay/recovery can be exercised while the original run is alive, with no second custody owner. Keep no writer session open across child launches. No callbacks may supply authority, alternate connections or fake successful cleanup. Results are closed, versioned transient progress/evidence values, separating known A state, known B state, projection outcome and cleanup condition. Do not return a path, database handle, run owner or restart token as safe result data.

The temporary SQLite facts survive writer-session closure while the original run owns the state; D1 disposal later removes that root. This is not restart-resumable durable program progression. Explicitly test fresh-session readback before disposal and refusal after run closure/wrong process. Clone/restore, manually reconstructed SQLite, process/supervisor restart and multi-run identity allocation stay unsupported.

## 7. Touched surfaces and assurance succession

Direct new files selected:
- .docs/section41-post-execution-proposal-family.md
- src/ge_nwp_coordinator/sqlite_migrations/0005_section41_post_execution_proposal_family.sql
- src/ge_nwp_coordinator/_section41_post_execution_proposal_mutation_contracts.py
- src/ge_nwp_coordinator/_section41_post_execution_proposal_row_values.py
- src/ge_nwp_coordinator/_sqlite_section41_post_execution_proposal.py
- src/ge_nwp_coordinator/_rw0_d2_post_execution_continuation.py
- the six new test modules named in section 9.

Direct existing implementation scope:
- src/ge_nwp_coordinator/sqlite_migration.py
- src/ge_nwp_coordinator/sqlite_transition_transaction.py
- src/ge_nwp_coordinator/sqlite_writer_session.py
- src/ge_nwp_coordinator/_sqlite_rw0_c1.py
- only if needed for literal bounded query/tuple support: _sqlite_rw0_c1_readers.py and _sqlite_rw0_c1_reader_contracts.py in the same package.

Docs authorized only for the selected successor, status/impact mapping, migration tip and preserved deferred boundaries: AGENTS.md, README.md, .docs/c2b-durable-development-state.md, .docs/rw0-d2-offline-evidence-and-review.md, .docs/rw0-c1-durable-evidence.md, .docs/autonomous-software-development-operating-model.md, .docs/architecture.md, .docs/authority-boundaries.md, the four migration owners, .docs/rw0-b2-capability.md, and the five C2 target docs listed in section 3 where their prospective suffix or source-nonimplementation assertions need exact scoping. Do not perform a global documentation rewrite. Keep D2 v1 historical boundaries true while identifying the new entry and successor.

Existing tests authorized: the 43 listed in the recommendation; tests/test_sqlite_c2b2_migration_0002.py; affected shared session/transaction/delegation tests for exact new guarded operation/closed inventories; and another existing documentation/catalog/AST inventory consumer only when static inspection proves it directly depends on this authorized change. Inventory each such dependency before editing it, state the original protected invariant and exact replacement, and include it in final validation. This bounded assurance-dependency allowance is not permission to change unrelated behavior or broaden all imports. Do not stop merely because another literal current-tip consumer was omitted from the initial report.

Protected semantics/bytes:
- Migrations 0001-0004 remain byte-exact.
- Existing D2 entry, handback/model input/proposal semantics and hardcoded invocation identities remain byte-exact unless a precise unavoidable conflict is returned for a new decision. The adjacent wrapper is selected to avoid changing them.
- _section41_post_execution_proposal_family_projection.py and existing pure evidence/profile/value contracts remain byte-exact; no new grammar, profile or recommendation branch.
- _rw0_c1_semantic_values.py and existing C1 admission/recovery semantics remain unchanged; the reader extension is not a new producer/reducer.
- Existing pre-execution receipt, selection/disposition/head contracts, public StateStore/WriterSession protocol/package exports, B3/B4 lifecycle/cleanup/privacy and source authentication boundaries remain unchanged.
- No changes to pyproject dependencies, runtime/platform minimum, .codex agent policies, or another repository.

P11: AGENTS.md baseline is 65275 bytes, SHA-256 1137167c50bbc8c302f126bea89a7f1032555664b278db66d5aae4feedd79cbc. Preserve its independently checked prior 64142-byte identity ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166. Introduce a NAMED bounded post-D2 successor layer with exact reversible current edits. Existing primary AND independent companion raw checks must continue hashing the complete live current AGENTS bytes against explicit literals. Additional reconstruction proves the exact integrated predecessor, then preserves the earlier two-span D2 historical guarantee. Do not replace raw current checks with normalized/historical content, auto-update expected hashes from the subject, ignore arbitrary regions, or disable hostile controls. New permitted spans need lossless before/after evidence and independent context anchors. Update the assurance note and companion consumer deliberately.

Pure-owner and guarded-call boundaries: independently update primary and companion exact caller inventories only for the new necessary private edges. Preserve forbidden public/state_store imports, old finite hostile vectors, existing D2 guarded-action pairs and absence of C2 physical writers. An extra import pair is not authority to add an open-ended import grammar. Freeze each new pair in the contract before source uses it.

No-0005 guards become exact Section 41-0005/no-C2 guards with positive protection of the new suffix and continued protection of all deferred C2 effects. Preserve literal older migration oracles and make current cumulative assertions explicit successors. The report's index is a starting map, not a complete guarantee; the final full suite must expose missed consumers.

Status wording should describe the exact source/capability and refer to separately recorded audit/commit events. Do not write that this new patch has passed independent review, and do not hardcode a transient "uncommitted/pending" statement as a permanent runtime contract that will demand another status-only hash cycle.

## 8. Acceptance evidence and first substantive checkpoint

Critical path: narrow owner/DDL/assurance freeze -> native A + full checked reader -> narrow C1 reader -> borrowed/owned continuation -> actual connected positive + discriminating controls -> remaining finite faults/regressions -> exact review package. Pure values are supporting work, not a separate deliverable substituting for the connected path.

Save and reopen the FIRST substantive checkpoint outside the repository once it contains the actual connected positive and discriminating failures, before broadening the finite fault suite. It must contain actual source/diff identity, exact commands/results and safe readback evidence, not just a plan, "unestablished" placeholders or component-only tests. Continue internally after saving it; no user relay between A and B and no separate checkpoint approval. If completion becomes blocked, return the saved real checkpoint and exact unsupported boundary.

Required positive: one actual D2 invocation in a new external-copy synthetic fixture; actual separate fake processes produce the proposal; native A writes 12 common rows plus context and receipt; existing C1 B admits rank 15; both are read back in fresh guarded sessions; actual tuples/owner values feed unchanged V22. No direct SQL seeding of either target family or prebuilt admitted wrapper. Observe one model run and no extra model/child run for replay/recovery. Tests may use test-owned SQL only for explicit negative/migration fixtures, never as the positive's target producer.

At least these independent assertions must accompany the connected positive before expanding controls:
- Same-capsule/different-policy or donor-B substitution reaches the final consuming boundary and refuses before target write.
- Missing/wrong/extra evidence member or falsified typed owner relation is refused at the same-transaction family gate; zero target/receipt survivors after rollback.
- A committed, B fresh CAS conflict: A exact and retained, no B admission/projection claim.
- Exact same-command historical replay/readback after expiry/head change: original rows and time unchanged, no model rerun or duplicate.

Complete finite coverage before READY_FOR_INDEPENDENT_AUDIT:
1. Closed command/basis/row/result/receipt grammars, exact types/duplicate keys/size ceiling, acyclic digest vectors and all cross-row identities. Retention allowlist rejects full V10/V11/raw private/payload/path-bearing additions; canary data remains absent from all stored safe basis and outputs.
2. All five actual model recommendations remain proposal evidence. Positive continuation is not silently restricted to accept_candidate and never performs corresponding C2 effects.
3. All nine roles; missing/extra/duplicate/reordered/phase/source/set/digest/ref discrepancies; same-capsule cross-policy and forged nested wrappers. Assert the intended production check was reached; an earlier refusal is not independent credit for a later predicate.
4. Fresh source/fence expiry immediately before/at/after the strict boundary and changed owner heads/stop. Historical replay/readback keeps past meanings. Distinguish the transaction-sampled check from wall-clock commit completion.
5. Global-key collisions, changed-command mutation-ref reuse, second distinct D2 review collisions; no alternate ID/upsert/partial repair. Preserve unrelated/preexisting rows.
6. A and B before-commit failure, commit-call exception before underlying commit, exception after underlying commit, lost return and later cleanup failure. Exactly one commit attempt per owner invocation; no false no-write or false admitted/projection result. Use real owner transactions/fault seams, not a stand-in mock that never reaches commit.
7. Each A-to-B-to-projection gap, including B committed but final verification failed, read-only three-way recovery, complete-route absence versus partial/foreign rows, safe same-command selectors, no blind retry/model rerun.
8. Fresh writer-session historical readback while original run is open; creator-process disposal/wrong-process/closed-run refusal; no restart/clone/custody claim. Cleanup failure remains distinguishable from ordinary stopped work.
9. Fresh full migration and explicit old-prefix migration including populated valid owner data; unchanged four earlier resources, generation compatibility, zero seeds, FK/trigger/catalog/schema checks, failure rollback and refusal of unsupported/unknown/partial state; no auto-migrate on normal acquisition.
10. Existing pre-execution runtime, all C1 kinds including generic 0-or-9, V22 pure contracts and private/public/delegation/exception/cleanup boundaries. P11 and independent companions reject outside-span changes and keep historical assertions.

Keep runtime causal tests, source/AST inventory guards, and retained reports distinct. A large passing count cannot substitute for the connected positive and exact discriminating states. No generalized joins, open-ended fuzzing framework or unrelated mutation campaign is requested.

## 9. Exact validation plan

Every execution is from a fresh task-owned external source copy of the CURRENT CANDIDATE, not the baseline ZIP and not the live checkout. Include every tracked baseline path with its intended replacement and all created source paths; preserve modes including the known 0600 test. No .git, remotes, alternates, hooks, prior caches, real state or credentials. Verify complete source hashes/modes before import and after validation; retain logs/JUnit/inventories before cleaning disposable copies.

Preferred interpreter from recon: /opt/homebrew/bin/python3.12 (reported 3.12.11). Verify its exact version, pytest availability and SQLite version from a neutral owned directory. If that installed interpreter lacks pytest or is unavailable, the already used /Library/Frameworks/Python.framework/Versions/3.13/bin/python3 is an authorized fallback ONLY after its existing environment is verified. No install or environment repair. Freeze one absolute PY path and observed versions before operative tests, use it consistently, and disclose any fallback. SQLite minimum remains the existing contract, not just what happens to be installed. Do not claim execution on SQLite 3.37.0 unless actually tested there.

Required new modules:
  tests/test_section41_post_execution_proposal_contracts.py
  tests/test_sqlite_section41_migration_0005.py
  tests/test_section41_private_atomic_post_execution_proposal.py
  tests/test_section41_post_execution_proposal_recovery.py
  tests/test_section41_post_execution_proposal_delegation.py
  tests/test_rw0_d2_post_execution_admission_integration.py

The recommendation's existing 43 modules are mandatory coverage inside FULL:
  tests/test_rw0_d2_offline_integration.py
  tests/test_rw0_d2_model_handback.py
  tests/test_rw0_d2_c1_checked_readback.py
  tests/test_rw0_d2_bound_effect_contracts.py
  tests/test_rw0_d2_bound_effect_persistence.py
  tests/test_rw0_d2_evidence_children.py
  tests/test_rw0_d2_process_frames.py
  tests/test_rw0_d1_handback_values.py
  tests/test_rw0_d1_offline_integration.py
  tests/test_section41_cognitive_proposal_semantic_values.py
  tests/test_section41_cognitive_proposal_row_values.py
  tests/test_sqlite_section41_migration_0003.py
  tests/test_section41_pre_execution_plan_disposition_contracts.py
  tests/test_section41_private_atomic_pre_execution_plan_disposition.py
  tests/test_section41_pre_execution_plan_disposition_recovery.py
  tests/test_section41_private_pre_execution_plan_disposition_delegation.py
  tests/test_rw0_c1_mutation_contracts.py
  tests/test_rw0_c1_private_atomic_persistence.py
  tests/test_rw0_c1_recovery.py
  tests/test_rw0_c1_private_readers.py
  tests/test_rw0_c1_reader_contracts.py
  tests/test_rw0_c1_row_values.py
  tests/test_rw0_c1_semantic_values.py
  tests/test_rw0_c1_writer_session_delegation.py
  tests/test_post_execution_pure_owner_boundaries.py
  tests/test_post_execution_pure_owner_relations.py
  tests/test_post_execution_pure_owner_values.py
  tests/test_post_execution_pure_owner_vectors.py
  tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
  tests/test_rw0_c2_private_value_versioning_contract.py
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
  tests/test_rw0_c2_scope_admission_provisioning_contract.py
  tests/test_rw0_c2_first_live_proof_posture_contract.py
  tests/test_sqlite_b1_migrations.py
  tests/test_sqlite_c2b1_migration_framework.py
  tests/test_sqlite_rw0_c1_migration_0004.py
  tests/test_autonomous_software_development_operating_model.py
  tests/test_architecture_contracts.py
  tests/test_c2b0_durable_state_contract.py
  tests/test_rw0_b1_boundaries.py
  tests/test_rw0_b2_capability_boundaries.py
  tests/test_c2a_nonimplementation.py
  tests/test_worker_execution_semantic_boundaries.py

FULL must also collect the existing shared tests, including test_sqlite_c2b2_migration_0002.py, test_sqlite_b2c_writer_session.py, test_sqlite_b2b_lock_integration.py, test_sqlite_b1_connection_posture.py, test_b3c4b_private_atomic_transition_persistence.py, test_b3c4c_public_transition_delegation.py, test_b4b_private_atomic_global_stop_persistence.py, test_b4c_public_global_stop_delegation.py, test_c2b3_private_atomic_program_initialization.py, test_c2b3_private_program_initialization_delegation.py, test_c2b3d_private_atomic_author_effect_establishment.py and test_c2b3d_private_author_effect_delegation.py. These are coverage requirements, not additional separately repeated final groups.

Create VALIDATION_COPY, VALIDATION_ROOT and owned temp paths outside repositories and freeze their actual absolute paths in run receipts. Use a sanitized nonsecret environment; unset inherited pytest options/addopts/selection, Python startup overrides and plugin autoload. Preserve legitimate executable access needed by the established fake-process tests. Record safe effective argv/cwd/env keys and relevant nonsecret values. Do not dump the original environment.

From cd "$VALIDATION_COPY", after selecting PY, minimal connected development commands may use:
  NEW_MODULES=(
    tests/test_section41_post_execution_proposal_contracts.py
    tests/test_sqlite_section41_migration_0005.py
    tests/test_section41_private_atomic_post_execution_proposal.py
    tests/test_section41_post_execution_proposal_recovery.py
    tests/test_section41_post_execution_proposal_delegation.py
    tests/test_rw0_d2_post_execution_admission_integration.py
  )
  PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 PYTHONPATH=.:src TMPDIR="$VALIDATION_ROOT/tmp" "$PY" -B -m pytest -q -p no:cacheprovider --collect-only --basetemp="$VALIDATION_ROOT/target-collect" "${NEW_MODULES[@]}" > "$VALIDATION_ROOT/target-collect.txt" 2>&1
  PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 PYTHONPATH=.:src TMPDIR="$VALIDATION_ROOT/tmp" "$PY" -B -m pytest -q -p no:cacheprovider --basetemp="$VALIDATION_ROOT/target-run" --junitxml="$VALIDATION_ROOT/target-junit.xml" "${NEW_MODULES[@]}" > "$VALIDATION_ROOT/target-run.txt" 2>&1

For the first connected checkpoint, a smaller exact named-node selection inside these modules is allowed once the positive and four discriminating cases are authored. Record the exact selection and reached assertions. Missing future tests are not passes. Targeted failure-driven reruns are development evidence, not duplicated final coverage.

After the final source freeze, from the final authenticated copy, operative selector-free commands are:
  PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 PYTHONPATH=.:src TMPDIR="$VALIDATION_ROOT/tmp" "$PY" -B -m pytest -q -p no:cacheprovider --collect-only --basetemp="$VALIDATION_ROOT/full-collect" > "$VALIDATION_ROOT/full-collect.txt" 2>&1
  PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 PYTHONPATH=.:src TMPDIR="$VALIDATION_ROOT/tmp" "$PY" -B -m pytest -q -p no:cacheprovider --basetemp="$VALIDATION_ROOT/full-run" --junitxml="$VALIDATION_ROOT/full-junit.xml" > "$VALIDATION_ROOT/full-run.txt" 2>&1

Capture each real exit code directly (no masking pipeline). No -k/-m/--ignore/deselection, xdist, warning suppression, new skip/xfail, or configuration change to narrow FULL. Retain complete node IDs, not a guessed test count. Record deduplication and module/ID inventory recipes; verify collected IDs equal executed JUnit cases and all required modules/new controls occur. Disclose any legitimate pre-existing warnings/skips by exact nodes and relevance; they are not zero by assertion. New unexpected skips/xfails or unexplained warning/error outcomes do not qualify for ready status.

If final validation fails, repair only within the authorized scope, retain the failed evidence, freeze the new source and rerun affected tests and a new operative FULL. A prior candidate's pass does not certify changed bytes. No blind retry of stateful tests on a contaminated copy. No need to rerun the earlier independent D2 audit mutants or the six historical gate groups as separate campaigns.

## 10. Provenance and retained review package

This is transaction/schema-sensitive work: deliver a complete exact-byte review subject, not just a narrative or a diff hash.

Establish one task-specific deterministic provenance collector OUTSIDE the repository. Recipe ID: governed-execution.post-d2-native-proposal-admission.patch.v1. Freeze and retain its actual source and source SHA-256 before the operative final constructions. The recipe must bind baseline commit/tree, actual branch/HEAD/upstream, complete changed-path set including creations, per-file classification/type/Git mode/OS mode/size/SHA-256 and Git blob identity, and the raw deterministic full-index binary tracked diff. Use sorted compact UTF-8 JSON with terminal LF; exclude volatile timestamps/absolute machine paths from the canonical identity. Record safe observation times/locations separately. Do not execute the uploaded generic legacy recipe or silently claim it is this new recipe.

Run the exact collector twice with fresh reads and require byte-identical canonical output. Include literal source and expected outputs so an independent auditor can reproduce it. Verify HEAD/index/refs/configuration remain at the authorized opening branch state and source outside the changed set remains baseline-exact. No staging. Check the tracked diff with:
  GIT_OPTIONAL_LOCKS=0 git --no-optional-locks -c core.fsmonitor=false -c diff.external= -c diff.trustExitCode=false diff --no-ext-diff --no-textconv --check eac7f6df5f281138dd0640c5cd47b9924c8390f8 --

Retain one safe package under a new owned /Users/ds/Downloads directory containing:
- README_FIRST, implementation report, actual decision/contract freeze and deviations, original recommendation identity, and this mandate.
- Full candidate source tree and its complete raw identity/mode manifest; complete before/after bytes for all touched paths (or exact before entries plus the authenticated baseline source already included), raw full-index tracked diff, creation inventory, canonical patch manifests from both passes, and exact provenance collector source.
- Earlier migration preservation checks; final DDL/catalog/schema/FK/trigger inventory and compatibility proof; allowlisted safe-basis schema and acyclic digest vectors.
- First substantive connected checkpoint identity; actual positive/negative results and a case-to-production-seam register showing reached failures, A/B/receipt/readback/projection outcomes, causal versus structural coverage and masking limits.
- Final candidate validation copy manifest; exact commands/cwd/sanitized environment and interpreter/pytest/SQLite versions; collection IDs, logs, JUnit, exit codes, failed/intermediate attempts, and final before/after source comparisons.
- A/B recovery and cleanup outcomes using only safe synthetic evidence; no real or full SQLite files, journals/WAL/SHM, private artifacts/capsule blobs, secrets, raw environment, or unrelated local state.
- Final preservation/cleanup observations, package manifest covering every other member, and ZIP bytes/SHA-256.

Reopen the final ZIP, verify safe unique regular-file member names/no links or traversal, all member sizes/hashes, every candidate source endpoint, and actual nonempty required evidence. Keep the retained package and its operative logs. Delete only newly owned disposable validation copies/test roots after evidence was copied and reopened. Do not remove the fixed checkpoint, prior reports, sole surviving execution records, or preexisting caches.

Reports/manifests/logs remain evidence. Neither the package, the transient continuation result, nor the model response becomes a second durable progression owner or an independent acceptance certificate.

## 11. Stop conditions, bounded recovery, and closeout

Stop the dependent action for: wrong/dirty baseline or competing writer; source changes outside this authority; need to modify prior migration bytes/generation semantics beyond the selected decision; a third durable table/owner or cross-owner transaction requirement; inability to retain the safe basis without private payload or unsupported proof; changed pre-execution/C1/V22 semantics; need for live custody/supplier or C2 acceptance; exposed secrets; unreconciled source/index/ref drift; incomplete causal/validation evidence.

Do not stop solely for a disclosed harmless preliminary read ordering mistake, a newly identified direct documentary/current-catalog test dependency within section 7, or a corrected external inspection/packaging script bug. Preserve the initial error and its evidence; determine whether any effect already happened before repeating it. Do not reinterpret a repository implementation/test failure as a driver error. Never reset the identity baseline or silently widen scope to make the result pass.

Return one of:
  POST_D2_NATIVE_PROPOSAL_ADMISSION_READY_FOR_INDEPENDENT_AUDIT
  POST_D2_NATIVE_PROPOSAL_ADMISSION_PARTIAL
  POST_D2_NATIVE_PROPOSAL_ADMISSION_BLOCKED

The report must state exact branch/HEAD/tree/parent/upstream; touched files and semantic classes; adopted/rejected recommendation details; contract/schema/private-API and authority changes; connected first checkpoint and final A/B/projection boundary; commands, exact counts/results/warnings, failures and skipped validation; artifact identities; assumptions, residual risk and deferred live/multi-run/custody/C2 seams; and source/index/ref/config/cache preservation limits.

READY means the connected implementation and specified candidate validation are complete enough for a fresh independent audit. It does NOT mean independently accepted, committed, published, live-ready or production-durable. No staging/commit/push/PR/merge is performed. Return actual local deliverable paths and exact ZIP/report hashes; do not claim a nonexistent checkpoint or continuation artifact.
