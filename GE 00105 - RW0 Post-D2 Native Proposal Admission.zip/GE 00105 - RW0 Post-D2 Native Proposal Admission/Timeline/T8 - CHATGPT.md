**Do not change the candidate or rerun implementation. Codex stopped correctly, but my re-entry gate repeated the original mistake: it pinned another complete ref snapshot across turns. Updating the expected count from 53 to 54 would repeat that mistake again.**

The correction is to **separate exact candidate/protected-state identity from narrowly qualified diagnostic-ref observations**, while retaining every record and both failed audit dispositions. No substantive acceptance has occurred.

## What this report adds

The newer transition is no longer an unidentified aggregate difference. The retained comparison identifies **two added refs and one removed ref**, all beneath the turn-diff capture/checkpoint paths and all pointing to the same candidate tree:

```text
17ee7db2925ed03ebc1614880fba5ec83d102d8c
```

There was no OID change on shared ref names. All non-ref manifest fields—including source, index, tracked diff, and configuration—matched. That is substantially more informative than “54 versus 53.” audit_report

**This does not identify the actor or establish harmlessness.** The earlier writer-to-first-auditor transition remains unresolved, and the latest 54-record inventory does not reproduce the writer’s historical 54-record hash. Those are separate facts; neither should be erased. audit_report

The report also confirms that the actual work remains outstanding: **A01–A12, the connected positive, discriminating probes, migration behavior, retained-result reconciliation, and independent FULL execution were not reached.** The author’s 9,191-pass result is still packaged implementation evidence. audit_report

## The replacement rule

I am selecting an **explicitly versioned audit binding**, not another whole-manifest reset.

**Source and protected state remain exact.** The original ZIP, all 298 endpoints, patch, baseline/index, branch, HEAD, parent, upstream, configuration representation, and protected refs must still match. The protected-ref baseline is derived from the two authenticated retained inventories—not from whatever happens to exist at the next opening.

**Only a tightly bounded ref class can vary without blocking the source audit.** Qualification requires the precise observed capture/checkpoint name shapes, the exact candidate-tree OID, and demonstrated absence of source-selection, validation, policy, recovery, publication, or protected-symbolic dependencies. Current qualifying refs must be direct, not symbolic. Everything else remains protected by default.

**All observations remain visible.** The unchanged original collector still produces complete manifests. The auditor retains complete ref inventories and exact additions, removals, and changes—including qualified ones. Those full manifests must not be declared equal when they differ. A separate deterministic binding compares the invariant fields and protected refs.

This is **not a blanket exemption for `refs/codex/**`**, permission to manipulate refs, or attribution of the changes to Codex. A ref with the wrong target, an unknown shape, a protected dependency, or a changed protected identity still blocks. A further qualifying capture/checkpoint record does not require another round trip through you.

That treatment also fits the project’s distinction between source provenance and correctness, and its guidance against volatile canonical inputs and provenance ceremony obscuring architectural risk. The task-specific change is explicit; the old recipe and old results remain unchanged. Governed Execution Provenance G… Governed Execution Provenance G…

## Next Codex handoff

:chatgpt-content-reference{index="5"}[Download the complete scoped-provenance and substantive-audit prompt](sandbox:/mnt/data/Coordinator_Post_D2_Scoped_Provenance_and_Substantive_Audit_Prompt.txt)

Send it to **the same independent audit conversation**, with the implementation writer idle. It replaces both preceding audit mandates in full.

The prompt requires the auditor to authenticate the reported three-record transition, qualify the narrow diagnostic class, establish the new binding, and **continue the substantive audit in the same engagement**. It does not authorize another provenance-only success response.

I preserved **Sections 3–7, the immutable migration anchors, and both appendices byte-for-byte**. The complete 69-path review, A01–A12 register, actual D2 → Section 41 → C1 → V22 positive, transaction/recovery controls, assurance-successor checks, and selector-free independent collection and execution remain required. No coverage has been traded for the procedural correction.

**No source repair, staging, commit, push, PR, merge, or product effect is authorized.** Acceptance would still require the substantive audit and independent validation to succeed. The original two `AUDIT_PROVENANCE_MISMATCH` reports remain valid records of their failed gates; the unresolved historical interval must accompany any later disposition.

## What I checked here

The attached report is exactly **6,511 bytes**, with the advertised SHA-256:

```text
229c020eaf75446893174dc17752d56644def6e9b0d027acb8eccb551b6d347f
```

I inspected the previous mandates, verified that the three exact ref names carry into the replacement, and saved, reopened, and compared the new handoff. Post_D2_Scoped_Provenance_Audit_Handoff_Check.json[Handoff integrity record](sandbox:/mnt/data/Post_D2_Scoped_Provenance_Audit_Handoff_Check.json).

Neither candidate nor stopped-audit ZIP was attached here. I did not inspect the live repository, execute its code or the uploaded collector, or run tests. **The candidate remains unchanged and unaudited on implementation correctness—not rejected as defective.**

**Sources:** Latest audit report, especially its exact delta and noncoverage sections cited above; the preceding audit mandates; project provenance guidance.

**Confidence:** **0.98** in the diagnosis and **0.94** in the bounded replacement policy. Report identity is independently verified; candidate provenance remains auditor-reported here. Independent validation and implementation correctness remain unassessed.
