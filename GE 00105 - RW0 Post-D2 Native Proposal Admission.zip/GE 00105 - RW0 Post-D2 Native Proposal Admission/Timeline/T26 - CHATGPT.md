**The package authenticates, and the candidate-specific comparison is complete. F1, F4, and the malformed-input portion of F5 remain in these exact bytes.** I also found one additional source-level association gap in the new native writer. The candidate remains unchanged and on correctness hold.

:chatgpt-content-reference{index="3"}[**Candidate-specific source review and finalized repair scope**](sandbox:/mnt/data/Coordinator_Candidate_Specific_Repair_Scope.md)

This is the review result **for this conversation**, not a prompt to send to Codex or another reviewer.

## What is now established directly

The ZIP matches its recorded **14,481,457-byte size and SHA-256**. All **544 manifest-covered members** authenticate. Its **298 source files** reconstruct candidate tree:

```text
17ee7db2925ed03ebc1614880fba5ec83d102d8c
```

The source comparison confirms **57 modifications, 12 creations, and 229 unchanged baseline files**. The embedded baseline independently reconstructs the accepted D2 tree. This closes the missing-source limitation; it does not establish fresh live-checkout preservation or reproduce any tests.

### F1: the candidate leaves the recovery-entry mechanism unchanged

Although the candidate modifies `sqlite_writer_session.py`, the **complete acquisition and preflight functions are byte-identical to the merged baseline**. Its migration changes likewise leave the relevant read-only assessment functions unchanged.

The candidate still performs managed preflight before acquiring the authority lock, and again before its bound writable open. The failure-classification path still loses the specific operational cause. These are direct source observations at:

```text
src/ge_nwp_coordinator/sqlite_writer_session.py:7184–7199,7302–7327
src/ge_nwp_coordinator/sqlite_migration.py:1021–1058
src/ge_nwp_coordinator/sqlite_connection.py:408–434
```

**The repair cannot be just a call-order swap.** The existing filesystem binding covers the root, authority-lock file, and database—not a rollback-journal object. The repair therefore needs an explicit auxiliary-file eligibility boundary before permitting engine recovery. That requirement is now confirmed from the candidate’s implementation, rather than left as an inspection question.

The selected F1 production scope is **`sqlite_connection.py`, `sqlite_migration.py`, `sqlite_errors.py`, `sqlite_security.py`, and `sqlite_writer_session.py`**, with their governing documentation and regression consumers. The existing authority-lock owner is reused, not redesigned.

### F4/F5: unchanged D2 fails before the new continuation can help

The relevant D2 producer, checkpoint, model-input, normalization, and final-handback modules are **byte-identical to the baseline**. The new native continuation calls `run_rw0_d2_offline()` before entering its own continuation handler:

```text
src/ge_nwp_coordinator/_rw0_d2_post_execution_continuation.py:542–554
```

Consequently, repairing only the new wrapper would leave the upstream defects intact.

The additional native dependency is also confirmed: **its safe-basis validator explicitly requires fourteen checked members**, and persisted-family readback invokes that same validator:

```text
src/ge_nwp_coordinator/_section41_post_execution_proposal_mutation_contracts.py:152–178
src/ge_nwp_coordinator/_sqlite_section41_post_execution_proposal.py:277–318
```

The repair must therefore cover the complete consuming path: the two legal worker-observation forms, D2’s role resolution and stopped prefixes, native basis construction, and historical readback. The selected complete layouts remain **13 or 14 members, derived from the actual two- or three-observation worker result**—not an arbitrary length allowance.

For malformed checker input, preserve the distinction between **a clean process returning invalid evidence** and a failed process. Introduce narrowly classified invalid-evidence stops that retain the actual reached prefix; do not catch every `ValueError` or weaken the separate clock rules.

## Additional candidate-specific finding: `NPA-WITNESS-01`

**The final fresh writer does not independently bind the supplied child-outcome witness back to the original run.**

The normal producer computes each child-outcome digest from the actual process result. But the consuming path validates the supplied basis and the original handback separately. The basis validator checks that each child digest is well-formed and its flags are true; the persisted-witness checker checks C1 memberships and bound-effect receipts, **not equality with the original child outcomes**.

The relevant source is:

```text
_rw0_d2_post_execution_continuation.py:54–64,112–138
_section41_post_execution_proposal_mutation_contracts.py:186–192
_sqlite_section41_post_execution_proposal.py:240–274,472–552
```

The distinguishing case is a structurally valid replacement child digest with consistently recomputed dependent identities. **The inspected predicates do not reject it specifically for disagreeing with the original run.** This is a static missing-check finding; I did not execute that case or observe a committed false witness.

The bounded correction is to **derive the complete canonical safe basis from the revalidated original run at the fresh write boundary and require exact equality before inserting target rows**. Checking only the producer is insufficient. Historical replay must retain its separate meaning: verify the stored family without rerunning children or pretending to recreate their custody.

I have explicitly added this correction to the second repair unit. It is **not attributed to Opus**, and it does not expand F1 into an unrelated writer redesign.

## What does not need to change

**Migration 0005 does not encode the fourteen-member constraint.** It stores a bounded basis BLOB; the cardinality restriction resides in Python validation. The existing pure V22 source is also unchanged.

Accordingly, the selected repair preserves:

- **All five migration resources**, their checksums, the catalog tip, and physical schema.
- **Pure V22, rank-15 ownership, and the separate Section 41/C1 transactions.**
- The nine model-evidence roles and twelve common proposal-owner rows.

No migration 0006, new C2 schema, or combined transaction is justified by these findings. Valid existing fourteen-member basis encodings should retain their canonical identities; supporting the second legal layout is an explicit private-contract successor, not a physical migration.

## Recommended next step

**The next bounded action is a separately authorized F1 implementation against this preserved candidate, producing a distinctly identified successor.** Keep F4/malformed-F5 plus `NPA-WITNESS-01` as the second attributable repair unit. F1 alone would not lift the whole correctness hold.

No further package or Opus response is needed merely to establish the source applicability. Missing original reproduction records still limit claims about those particular experiments, and F2’s host-specific durability evidence remains unverified.

The provider-access interruption remains separate. **No audit retry is selected.** Both historical provenance mismatches remain recorded, and A01–A12, connected-proof, discriminating-control, and independent collection/FULL obligations remain outstanding. The retained audits explicitly stopped before that work. audit_report

The packaged **9,191-pass** result remains the original writer’s validation evidence, not independent acceptance or a result for a future repair. IMPLEMENTATION_REPORT

**Sources and limits:** Authenticated candidate and embedded baseline; exact source excerpts and the detailed impact map are in the linked review. I performed data-only authentication and targeted static inspection—no candidate imports, repository commands, database opens, tests, crash experiments, network calls, or repository changes. Opus’s original reproduction materials remain separate and uninspected. Chat_00105_Opus_Report_Triage_H…

**Confidence:** source identity **0.99**; inherited-defect applicability **0.98**; the new witness-association finding **0.95**. Runtime manifestations and repair correctness remain unvalidated.
