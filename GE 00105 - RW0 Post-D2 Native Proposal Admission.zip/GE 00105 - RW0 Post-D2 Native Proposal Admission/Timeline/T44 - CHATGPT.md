**The Unit 2 package authenticates, but the exact final source has one narrow blocking defect. Do not send tree `a0b52ca6f396638ee5615ad75523a394dba637a0` to independent audit yet.**

## Disposition

```text
POST_D2_UNIT2_BLOCKED_BY_INCOMPLETE_TYPED_CHILD_VALUE_BOUNDARY
```

I independently verified:

- the 12,469,629-byte ZIP and its advertised SHA-256;
- all 465 safe archive members and all 464 manifest-covered members;
- all 299 source endpoints, modes, SHA-256 values, and Git blob identities;
- reconstructed source tree `a0b52ca6f396638ee5615ad75523a394dba637a0`;
- exactly 25 changed existing paths from F1 tree `93afef8750e062d80626a5a37adfa27766305b7c`;
- preservation of all fourteen frozen F1 paths;
- exact reconciliation of 3,314 focused and 9,275 FULL collected/executed/JUnit IDs, with zero recorded failures, errors, or skips.

The report accurately records the final tree, path count, and uncommitted posture. IMPLEMENTATION_REPORT The retained validation evidence is internally consistent, but I did not execute the source or rerun its tests. IMPLEMENTATION_REPORT

## Blocking finding: `UNIT2-TYPED-01`

The report claims that a clean checker response failing its typed input frame **or value** becomes `validator_evidence_invalid` or `reviewer_evidence_invalid` at the correct prefix. IMPLEMENTATION_REPORT The source implements only part of that boundary.

A checker can return a **canonical, digest-valid frame** that passes the frame decoder but contains a semantically invalid child-owned value:

```text
observed_at = 9999-99-99T99:99:99Z
reason_code = provably_not_accepted
an unsupported role-specific reason
a permitted reason paired with the wrong outcome
```

The current path behaves as follows:

1. `_rw0_d2a_process_frames.py` checks timestamp shape using a regular expression, not calendar validity, and accepts a broad reason-code grammar.
2. `_decode_child_checking_record()` converts frame and command-relation failures to `_D2CheckingInputInvalid`, but does not close those semantic gaps.
3. `WorkerObservationV1.create()` can therefore raise `WorkerExecutionValueError` outside the typed conversion boundary.
4. An unsupported but otherwise valid reason can survive observation construction and fail later in `checking_result_set()` as raw `invalid_d2_checking_evidence`.
5. Result-set construction occurs after both checker observations have been admitted. A semantically invalid validator response can therefore allow the reviewer to run before the raw failure.

The current causal test replaces stdout with bytes that are not a valid frame. It proves frame containment, but not containment of a canonical frame carrying invalid typed values.

This does **not** expose an unsafe Section 41 write—the native continuation is not reached. It does mean that the malformed-input portion of F5 remains incompletely repaired: the selected typed-stop and no-later-checker guarantees are false for part of the declared input surface.

:chatgpt-content-reference{index="4"}[Complete static package review](sandbox:/mnt/data/Coordinator_Unit2_Typed_Value_Static_Review.md)

## Next Codex handoff

Send **only this prompt** to the **same native-proposal/F1/Unit 2 implementation Codex conversation**, with write permission:

:chatgpt-content-reference{index="5"}[**Coordinator Unit 2 typed child-value repair prompt**](sandbox:/mnt/data/Coordinator_Unit2_Typed_Child_Value_Repair_Prompt.txt)

Do not send it to the independent auditor, Opus, or a new ChatGPT conversation. Do not send the static review as a second assignment.

The correction is deliberately small:

- validate actual UTC calendar syntax and the exact role-specific `(outcome, reason_code)` vocabulary inside the dedicated child-input boundary;
- convert only those child-owned failures to `_D2CheckingInputInvalid`;
- preserve raw propagation of internal/programming failures and process-control exceptions;
- add canonical, digest-valid semantic-invalid controls for validator and reviewer across the legal two-/three-observation layouts;
- prove exact prefixes and absence of later checker/model/native effects;
- rerun the focused selector, connected controls, and one selector-free FULL suite.

The expected source delta is limited to:

```text
src/ge_nwp_coordinator/_rw0_d2a_evidence.py
tests/test_rw0_d2_offline_integration.py
```

No new repository path, migration, physical schema, V22, C2A/Wire grammar, F1 change, staging, commit, or publication is authorized. Changed bytes must receive a new tree identity; the existing 9,275-pass result does not transfer automatically.

Targeted static inspection found no additional blocker in the legal 13/14 layout resolution, V40 two-observation association, three-observation compatibility, original-run fresh-writer equality, or historical 13/14 readback. Those observations are not an independent audit verdict.

The original candidate, F1 successor, and Unit 2 tree remain unaccepted. Provider audit access, historical provenance gaps, F2, and qualified F3/F6/F7 remain separate and unresolved. The implementation report itself correctly states that no independent audit, staging, commit, or publication occurred. IMPLEMENTATION_REPORT

:chatgpt-content-reference{index="6"}[Handoff identity record](sandbox:/mnt/data/Coordinator_Unit2_Typed_Value_Handoff_Check.json)

**Sources:** Attached implementation report and authenticated Unit 2 package; exact source and test coordinates are recorded in the static review.

**Confidence:** package/source provenance **0.99**; validation-record reconciliation **0.98**; blocking source finding **0.98**. Runtime repair correctness remains unestablished.
