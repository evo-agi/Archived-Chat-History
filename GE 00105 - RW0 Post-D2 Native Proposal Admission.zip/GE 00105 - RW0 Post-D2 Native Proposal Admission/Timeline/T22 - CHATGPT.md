**The bounded repair specification is drafted. The selected sequence remains F1’s recovery-entry repair first, followed by a separate F4/malformed-input-F5 composition repair.** The exact successor edit set remains pending comparison with the preserved candidate’s source—not another Opus response.

:chatgpt-content-reference{index="7"}[**Repair specification and candidate-impact map**](sandbox:/mnt/data/Coordinator_Bounded_Repair_Specification_and_Candidate_Impact_Map.md)

This is a design document, **not an executable assignment or authorization to change the repository**.

## 1. F1: make recovery reachable without making inspection writable

The specification selects a **narrow recovery branch within the existing writer-acquisition path**, retaining the existing connection owner and state-authority lock. Ordinary `inspect_database()` and `validate_database()` remain observational.

The important contract change is explicit: **storage recovery may alter database or journal bytes before managed-schema validation can succeed.** A repair cannot simultaneously allow that recovery and claim the entire operation was non-mutating. It must separate:

- a precise recovery-required condition from generic corruption, unsupported posture, or unknown schema;
- eligibility for bounded engine recovery from permission to issue a writer;
- successful storage recovery from successful schema validation and writer issuance.

The baseline currently places managed preflight both before lock acquisition and before the bound writable open, while its crash table promises successful subsequent acquisition after interrupted issuance. Those are the specific surfaces to reconcile: `sqlite_writer_session.py:7073–7088,7191–7213` and `.docs/writer-session-authority.md:561–585,671–678` in the supplied checkpoint. The external report describes the same recovery-entry mechanism, but its original execution materials remain uninspected. Chat_00105_Opus_Report_Triage_H…

The proposed branch must preserve create-disabled access, filesystem identity, custody, safe journal handling, post-recovery validation, and the existing issuance transaction. It must not become an unrestricted early writable open, an automatic migration, manual journal repair, or permission to reinitialize the store.

**One implementation detail remains genuinely unresolved:** the exact auxiliary-file admission checks needed before allowing SQLite to recover through the candidate’s existing binding machinery. The specification requires that decision before implementation; it does not assume the current root/lock/database binding already proves every journal operation safe.

F2 remains separate. Restoring access does not establish power-loss durability or authorize repeating an external effect after lost state.

## 2. F4/F5: repair the whole consuming path, not one index or exception handler

The source inspection makes this repair more precise.

### Two legal layouts, with exact roles

The Wire contract permits two or three worker observations. D2 admits that actual sequence, then assumes fourteen checked families across separation, checkpoint validation, model-input construction, and final-handback checks. The fixed-count dependency is therefore broader than the originally reported indexing failure. The report identifies the initiating failure; the specification maps its additional consumers. Chat_00105_Opus_Report_Triage_H…

The selected replacement is **one finite role-resolution routine that recognizes exactly the two legal layouts and their dependency-closed prefixes**. For a revalidated original worker result with \(n \in \{2,3\}\) observations, the complete checked-family sequence contains:

```text
n worker observations + 11 other required families
= 13 or 14 checked families
```

This does **not** permit arbitrary cardinality or unordered joins. The routine must verify canonical order, exact identities, types, ranks, phase, memberships, receipts, and source relationships. Repeated ranks cannot serve as unique selectors. Missing `candidate_captured` must not be converted into a fabricated observation or an authoritative negative claim.

The original three-observation path remains valid. The nine model-evidence roles, nine persisted evidence bindings, twelve common owner rows, and rank-15 ownership are not reduced.

### A clean process can return invalid evidence

The existing handback reasons distinguish process failure from a successful process. Consequently, an exit-zero malformed frame cannot truthfully be relabeled `validator_process_failed` or `reviewer_process_failed`. Nor can it simply reuse the existing complete-checkpoint `evidence_mismatch` reason: that reason requires a later, complete prefix.

The specification therefore selects **stage-specific invalid-evidence stops**, produced only from declared checker-input decoding or normalization failures. They retain the validated process outcome, committed bound effects, and actually checked prefix; they admit no malformed observation and launch no later dependent step.

This addresses the source-supported gap between `_rw0_d2a_offline.py:315–326,615–629` and the outer dispose-and-rethrow path in `_rw0_d2_offline.py:155–157`. It does not turn every internal `ValueError` into an ordinary protocol stop, suppress process-control exceptions, or absorb the separate clock-skew question. The external report’s malformed-frame and timestamp cases remain distinct. Chat_00105_Opus_Report_Triage_H…

## 3. Candidate impact: what is established and what still needs its bytes

| Surface | Available evidence | Consequence |
|---|---|---|
| Writer acquisition and migration assessment | The candidate reports changes to `sqlite_writer_session.py` and `sqlite_migration.py`. | Inspect their actual successor functions before freezing F1 edits; do not apply a baseline patch blindly. |
| Existing D2 layout and handback consumers | They are absent from the candidate’s reported changed-source list. | Reported inheritance strongly supports applicability, but I have not directly checked those candidate payloads here. |
| New native-admission continuation and safe witness | The candidate reports retaining a fourteen-member C1 witness. | Its assembler, validators, stored basis, historical reader, and final consumer need a coordinated compatibility treatment. |
| Migration 0005 and pure V22 | Their responsibilities are separately defined in the candidate report. | No schema change or projection redesign is presumed necessary. Inspect actual constraints before deciding. |

These distinctions follow the candidate’s reported source inventory and implemented witness/readback design—not a new candidate-source audit. IMPLEMENTATION_REPORT IMPLEMENTATION_REPORT

The specification also identifies the assurance dependencies that must move with a legitimate repair: current-file and historical identity checks, independent companion checks, caller inventories, migration assertions, and the final reason/prefix validators. It does not authorize refreshing hashes until tests pass.

## Acceptance and the immediate continuation point

**The original candidate remains unchanged, unaccepted, and on correctness hold, with its writer idle.** The provider interruption remains unresolved; neither the withdrawn Opus assignment nor this specification replaces the unfinished candidate audit.

A repaired successor would need a new identity and an explicit change to the audit’s fixed-fourteen requirement: both legal closed layouts must be covered while preserving all original association obligations. The remaining A01–A12 work, connected proof, discriminating controls, and independent collection/FULL validation remain mandatory. There is no completed candidate-specific correctness coverage to carry forward from the provenance stops. audit_report

**To finalize the candidate-specific edit scope, attach the existing `ReviewPackage.zip`** from:

```text
/Users/ds/Downloads/Coordinator_PostD2_Final_ftssNh/ReviewPackage.zip
```

Its recorded identity is **14,481,457 bytes**, SHA-256 `d9b4d61e212893b48ba1952c3b5370c09874ca2e70798decc36bc4fdbd893d9b`. No new run or regenerated package is needed. audit_report

**Sources and inspection limits:** I inspected the supplied baseline archive as data, checked its manifest-covered members and source blob identities, and used the candidate and audit reports cited above. The specification contains exact source coordinates. No repository code, uploaded helper, test, migration, database, crash experiment, or audit retry was executed.

**Confidence:** high in the baseline mechanisms and repair requirements; candidate-impact mapping remains report-backed; exact recovery implementation and successor correctness remain unvalidated.
