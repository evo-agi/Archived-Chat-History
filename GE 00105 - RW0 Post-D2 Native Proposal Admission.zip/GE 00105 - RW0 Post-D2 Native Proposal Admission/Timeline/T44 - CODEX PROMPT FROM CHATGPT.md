# Post-D2 Unit 2 narrow typed child-value repair

## Recipient and effect ceiling

Use this in the **same write-enabled native-proposal/F1/Unit 2 implementation Codex conversation** that produced `POST_D2_UNIT2_IMPLEMENTED_VALIDATED_PENDING_REVIEW`.

You are the sole repository writer. Do not spawn subagents during mutation. This mandate authorizes only the narrow repair below, validation in authenticated external copies, exact provenance closeout, and a review package.

Do not stage, commit, push, create or update a PR, merge, publish, access a network or live target, run against a user database, retry the independent audit, or implement F2/F3/F6/F7, C2, product effects, or another tranche.

Repository:

```text
/Users/ds/Repositories/Governed Execution Coordinator/
```

## Fixed input

Authenticate before editing:

```text
Review ZIP:
/Users/ds/Downloads/Coordinator_Unit2_Continuation_20261024/PostD2Unit2ReviewPackage.zip

Size:
12469629

SHA-256:
1db1f454574384d6905f60badbf34650cdab2833e6ad1f3e2333694a8c2b931d

Expected source count:
299

Expected source tree:
a0b52ca6f396638ee5615ad75523a394dba637a0

Expected branch:
codex/post-d2-native-proposal-admission-v1

Expected HEAD:
eac7f6df5f281138dd0640c5cd47b9924c8390f8

Expected upstream:
absent
```

The attached report identity is 10,334 bytes / SHA-256 `9a42e20a510a7017b82e467bbe269cc289fd4ec84b6c23242a3c4d27464272c8`.

Authenticate the complete package manifest, all 299 source bytes/modes/Git blobs, exact source tree, live source correspondence, semantic and raw index, configuration, branch/HEAD/upstream, 32 authoritative refs, and the qualified diagnostic-ref policy. Preserve the prior historical raw-index/ref gaps as unresolved history; do not backdate the new interval.

Use the package's frozen external collector v3 unchanged:

```text
collector-v3.py bytes: 16465
collector-v3.py SHA-256:
1c909a808e66991dab682882b5c1c71a0e6f1cdf88c820a792de1a752db5e0af

authoritative-ref map count: 32
authoritative-ref map SHA-256:
eaee93514b861f8dcf1d949c426acd164debfd01f9f6b1317b432a20b9b8b09e
```

Stop before editing on source, protected-state, package, or policy mismatch. Qualified turn-diff diagnostic additions/removals remain observations under the existing exact namespace policy; do not mutate or attribute them.

## Blocking defect to repair

The current Unit 2 conversion boundary handles malformed frames and explicit command/adapter relation mismatches, but not every closed semantic validation failure caused by decoded child-supplied fields.

Current path:

- `_rw0_d2a_process_frames.py` accepts regex-shaped timestamps and broad reason strings;
- `_rw0_d2a_evidence.py::_decode_child_checking_record` does not establish calendar validity or the exact role-specific outcome/reason vocabulary;
- `WorkerObservationV1.create` can therefore raise `WorkerExecutionValueError` from a clean canonical child record outside `_D2CheckingInputInvalid`;
- an unsupported but frame-valid reason can survive normalization and fail later in `checking_result_set`, after later checker work has occurred;
- `_run_checker` converts only `_D2CheckingInputInvalid` to the stage-specific typed stop.

Examples that must be handled as child evidence invalid, not as raw programming failures:

```text
observed_at = 9999-99-99T99:99:99Z
reason_code = provably_not_accepted
an unsupported role reason
an allowed reason paired with the wrong outcome
```

Each specimen must be a canonical, digest-valid response frame and otherwise match the exact command, fence, delivery, capsule, source, evidence, invocation, and file-digest relation.

## Selected repair contract

Repair the declared child-input boundary, not the whole exception surface.

Before admitting the checker observation, establish all child-owned semantics required by the existing result-set contract:

1. `observed_at` is an actual canonical UTC calendar timestamp under the existing timestamp grammar;
2. `(outcome, reason_code)` is one of the exact role-specific pairs already represented by the current validator/reviewer fake children and `checking_result_set` finite vocabulary;
3. the existing closed-frame and command/adapter relation checks still pass.

Convert failures of those child-owned checks to the existing private `_D2CheckingInputInvalid`, so `_run_checker` returns:

```text
validator_evidence_invalid
reviewer_evidence_invalid
```

at the existing exact reached prefixes.

Do **not**:

- catch all `Exception`, all `ValueError`, or all `WorkerExecutionValueError` around the checker path;
- relabel a programming/invariant failure outside the declared child-record field surface;
- suppress `KeyboardInterrupt`, `SystemExit`, or `GeneratorExit`;
- change valid future-clock/cross-host ordering behavior in this unit;
- change process-failure or cleanup-unresolved reasons;
- admit an invalid observation;
- launch a later checker/model or perform native A/B effects after the relevant invalid input;
- change the response-frame schema, WorkerObservation schema, C2A/Wire grammar, migration, physical schema, V22, F1 paths, or public/package API.

Use the smallest source-owner correction. The expected production file is:

```text
src/ge_nwp_coordinator/_rw0_d2a_evidence.py
```

The expected direct regression file is:

```text
tests/test_rw0_d2_offline_integration.py
```

No new repository path is authorized. A directly dependent existing exact-source assertion may move only if you first identify its owning invariant and show why the two-file repair necessarily changes it. Do not refresh unrelated hashes or status text.

## Required causal controls

Add finite controls using canonical, digest-valid child response frames. At minimum establish:

1. validator semantic-invalid value → `validator_evidence_invalid`;
2. reviewer semantic-invalid value after a valid validator → `reviewer_evidence_invalid`;
3. impossible calendar timestamp is contained;
4. unsupported or mismatched role outcome/reason is contained;
5. both legal two- and three-observation D1 layouts retain exact stage prefixes across the finite set;
6. invalid validator evidence launches no reviewer/model and causes no Section 41/C1 rank-15 write;
7. invalid reviewer evidence launches no model and causes no Section 41/C1 rank-15 write;
8. the existing malformed-frame controls still pass;
9. checker nonzero remains `*_process_failed`;
10. cleanup unresolved remains `process_cleanup_unresolved`;
11. the existing injected programming fault still propagates and is not relabelled;
12. the valid two- and three-observation connected positives remain exact;
13. the original-run donor command/safe-basis refusal and historical 13/14 replay/readback controls remain exact;
14. all fourteen frozen F1 paths remain byte/mode identical to the fixed input.

Do not treat a raw exception expectation as evidence for the repaired semantic-invalid cases.

## Checkpoint and validation

Before broad validation, save and reopen one substantive source-bound checkpoint containing:

- a canonical semantic-invalid validator case;
- a canonical semantic-invalid reviewer case;
- one two-observation and one three-observation exact-prefix case;
- the programming-fault discrimination;
- one valid connected D1 → D2 → Section 41 A → C1 B → V22 positive;
- source manifest before/after equality.

Then run, only from authenticated external copies of the final source:

1. the directly changed test module;
2. the Unit 2 focused selector from the fixed package, with any additional existing direct owner module required by the exact repair;
3. the connected positive and original-run witness/replay controls;
4. one selector-free collection;
5. one selector-free FULL execution.

Use the installed interpreter/environment posture already recorded by the Unit 2 package. Do not install dependencies. Reconcile collected IDs, executed IDs, and JUnit IDs exactly. Report every failure, error, skip, xfail, warning, interruption, timeout, or helper correction against the source identity on which it occurred. Earlier 3,314/9,275 results do not validate changed bytes.

After validation, run the unchanged frozen v3 collector twice and once after cleanup. Require byte-identical canonical output for the final source and stable authoritative state. Retain complete diagnostic-ref sidecars. Cleanup only task-owned external copies and temporary state, after durable evidence is reopened and verified.

## Required delivery

Return one reopened review ZIP containing:

- complete final 299-file source;
- exact delta from tree `a0b52ca6f396638ee5615ad75523a394dba637a0`;
- exact final source tree;
- the substantive checkpoint;
- causal-control register;
- focused and FULL collection/execution/JUnit reconciliation;
- final-a/final-b/post-cleanup v3 captures and ref sidecars;
- cleanup record;
- implementation report and this mandate as inert text.

The report must state:

- exact changed paths and why each is necessary;
- the exact child-owned semantic vocabulary enforced;
- how programming/invariant failures remain outside the conversion boundary;
- exact reached prefixes for both legal layouts and both checker stages;
- no-later-effect observations;
- final focused and FULL results;
- all remaining nonclaims and unresolved historical provenance limits.

Return exactly one disposition:

```text
POST_D2_UNIT2_TYPED_CHILD_VALUE_REPAIR_IMPLEMENTED_VALIDATED_PENDING_REVIEW
POST_D2_UNIT2_TYPED_CHILD_VALUE_REPAIR_BLOCKED
```

End with:

```text
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
MERGE_NOT_PERFORMED
PUBLICATION_NOT_PERFORMED
```
