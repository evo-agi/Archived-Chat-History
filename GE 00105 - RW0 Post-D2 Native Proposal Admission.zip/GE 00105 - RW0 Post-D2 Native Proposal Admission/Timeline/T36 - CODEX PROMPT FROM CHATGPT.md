# Coordinator — F1 recovery-dependency continuation after scoped ref-policy correction

RECIPIENT: the same IMPLEMENTATION Codex conversation that returned `POST_D2_F1_RECOVERY_ENTRY_REPAIR_BLOCKED` at the protected-ref opening check, with workspace-write permission. Not the independent auditor, Opus, or another ChatGPT conversation. You are the sole writer; no subagents. Other repository writers and auditors remain idle.

This is the single operative F1 continuation mandate. It supersedes the prior recovery-dependency continuation mandate in full. The prior stop remains a truthful result under its former rule: no source edit or test occurred. This mandate corrects that rule prospectively; it does not relabel the stopped engagement as successful, identify the actor behind ref changes, or claim historical continuity.

## 1. Engineering disposition, objective and authority

The latest package establishes that the 299-file refusal-only source, semantic index, raw index across its measured opening reads, configuration, HEAD/branch/baseline anchors, and all non-turn-diff refs matched their fixed identities. The sole stop arose because the former rule placed nineteen `refs/codex/turn-diffs/checkpoints/**` refs into the protected map merely because their targets were not one of three selected source trees.

That target-dependent classification is withdrawn. It confused platform diagnostic/checkpoint evidence with repository-authoritative refs.

For this candidate and continuation:

- **Authoritative/protected ref state** is every `show-ref --head` record whose name does **not** match either exact diagnostic grammar below. The retained H1, H2, prior F1 closeout and latest blocked opening each contain the same 32 authoritative records. Canonical serialization `OID SP ref LF`, sorted by ref name, is 32 records with SHA-256 `eaee93514b861f8dcf1d949c426acd164debfd01f9f6b1317b432a20b9b8b09e`.
- **Diagnostic ref state** is any direct ref whose name exactly matches one of these shapes:

  ```text
  ^refs/codex/turn-diffs/captures/[0-9]{13}/[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}/base$
  ^refs/codex/turn-diffs/checkpoints/[0-9a-f]{32}/[0-9a-f]{32}/[0-9]{13}/[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$
  ```

- Diagnostic additions and removals are retained as lossless observations but do not select source bytes and do not by themselves block implementation. A surviving diagnostic name must not retarget within a measured interval. Every current diagnostic ref must be direct, nonsymbolic, and resolve to a Git `tree` object. Any name outside the two grammars, any authoritative add/remove/retarget, any diagnostic retarget, any non-tree current diagnostic target, or any demonstrated source/config/worktree/replace-object dependency remains blocking.
- Do not pin a total ref count or a fixed list of diagnostic names. Do not restore or delete refs. Preserve the complete old and new inventories and exact deltas.
- The removed checkpoint ref ending `9c748b04-11b1-43bb-a31b-900372c59bb9`, formerly at `45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4`, remains an unexplained historical diagnostic-ref removal. Its actor, cause, timing and historical object type are not established. Reclassification by exact namespace/role is not a harmlessness claim and does not backdate preservation.

This is a narrow candidate-specific provenance correction, not a general exemption for `refs/codex/**` and not a new repository authority model.

Objective after the corrected opening succeeds: implement F1 from the exact refusal-only source tree `b2e958c6a5d894fdf0d14dd5c821582c1d067489`. Make engine-recognized rollback recovery reachable through existing governed writer acquisition while preserving observational inspection, filesystem binding, common-lock custody, schema validation, issuance, cleanup, and the corrected recovery-dependency contract. Do not restore the failed writable attempt wholesale.

Repository:

```text
/Users/ds/Repositories/Governed Execution Coordinator/
```

Authorized after section 3: the bounded source/docs/test edits in section 5; read-only Git observations; external provenance/artifact tooling; validation in authenticated external source copies using newly created task-owned synthetic state; save/reopen safe evidence outside the repository. Complete the bounded contract update, implementation and validation in this engagement without routine approval handoffs.

Not authorized: repository test/import execution; live or pre-existing user databases; other repositories or hosts; network/provider/service/ES/Bridge access; installation; privileged tracing, kernel instrumentation or host/power-failure experiments; arbitrary-process termination; a custom VFS or storage engine; staging, commit, branch switch, worktree registration, index/ref/config mutation, fetch, push, PR, merge, release or deployment. Raw SQLite fixture construction is allowed only on owned synthetic state, never as a product recovery bypass.

Retain the substantive decisions from the prior mandate:

- Recovery constrains the files and dependencies it may use; it does not prove that an interrupted connection never used `ATTACH`. Support the bound main database and its fixed adjacent DELETE journal within the existing owner-private local-storage threat model. Reject super-journal/path-bearing recovery dependencies and unsafe/unsupported arrangements before relevant write-capable recovery access.
- Begin an explicitly prospective raw-index preservation interval only after exact source, complete semantic index, authoritative refs, config and Git anchors authenticate. Preserve the older unexplained index transition; never reset or refresh the index to make it disappear.
- Preserve healthy-path error semantics, including the four publication-binding regressions' `DATABASE_NOT_MANAGED` expectation. That reason does not prove that no issuance row committed.

Retain separate dispositions: original native candidate `UNACCEPTED`; both historical `AUDIT_PROVENANCE_MISMATCH` records and their limits; unresolved provider rejection of the consolidated independent-audit mandate; outstanding A01–A12, connected proof, discriminating controls and independent collection/FULL. This repair is not an audit retry and awards no independent-audit credit. F4, malformed-input F5, `NPA-WITNESS-01`, F2 and qualified F3/F6/F7 remain outside this task; F1 completion alone cannot lift the whole hold. Opus is independently commissioned by the user and receives no assignment.

## 2. Authenticate the exact inputs and select the source

### Input 1 — latest opening-stop package

```text
/Users/ds/Downloads/Coordinator_F1_Continuation_u0t0780j/F1RecoveryDependencyOpeningBlocked.zip
Bytes: 3,438,841
SHA-256: eeeb1274c73a9f039624deb31a9d3a913cfcb07996b2dd785368ecf5f2265281
```

It has 336 manifest-covered members plus `package-manifest.json`. Its report is 6,325 bytes, SHA-256 `a855d4ad6aec6469bacc93f3530ec1b2e7cd2a93705f7f32f8550eeb41f8d530`.

Read as inert data:

- `README_FIRST.md`, `IMPLEMENTATION_REPORT.md`, `result.json`;
- `source/` — the unchanged 299-file refusal-only subject;
- `evidence/starting-source-manifest.json` — 105,871 bytes, SHA-256 `70d6bbbeac99ba353996b90da7e31bd1dcda9d08a737eece05dfb037c01904c6`;
- `evidence/starting-f1-only.diff` — 27,983 bytes, SHA-256 `1b0494c63c3ff09c94298747ce343276fa492f523591c3386f2da943b7b4af08`;
- `evidence/opening-index.raw`, `opening-index-stage.raw`, `opening-current-refs.raw`, `opening-ref-delta.json`, `historical-ref-history.json`, `opening-git-observation.json`;
- `evidence/h1-53-refs.raw`, `h2-54-refs.raw`, `blocked-final-refs.raw`;
- `evidence/provenance_collector_v1.py` — 7,808 bytes, SHA-256 `b61b4a4e949e564e206e6d195791f56585c437d4130c86731e5b4be713c5da7a`;
- `evidence/provenance_collector_v2.py` — 8,698 bytes, SHA-256 `4556bb1606a14771051b78955edee0f35cfcd164b5947aa11c870fd24594193f`;
- `evidence/collector-v1-v2.diff`, `collector-v2-freeze.json`, `opening-v2/canonical-patch-manifest.json`.

`evidence/opening-protected.json`, `check_opening_git.py`, `check_opening_git_initial.py`, and the embedded prior continuation mandate are historical failed-policy evidence. Do **not** execute or reuse their 51-entry protected-map assertion unchanged.

### Input 2 — prior F1 blocked package

```text
/Users/ds/Downloads/Coordinator_F1_Repair_OPlFDp6b/F1BlockedReviewPackageFinal.zip
Bytes: 4,030,365
SHA-256: ab6bb4d1625d63440aaf6aecbec79a55b7aedcbcaca43870a87ce5f70565c43f
```

Use it for the failed writable attempt, original/current F1 deltas, decisive synthetic fixture and logs, interrupted/full/focused validation records, dependency map, SQL preservation, and the original 299-file refusal-only closeout. Do not treat `attempted/` as current source.

### Input 3 — original native-proposal candidate

```text
/Users/ds/Downloads/Coordinator_PostD2_Final_ftssNh/ReviewPackage.zip
Bytes: 14,481,457
SHA-256: d9b4d61e212893b48ba1952c3b5370c09874ca2e70798decc36bc4fdbd893d9b
```

Use it for the exact original 298-file candidate, baseline, original provenance recipe and native-admission evidence.

For all ZIPs: verify raw identity, unique normalized safe relative member paths, regular/directory types only, bounded sizes, explicit self-exclusion, complete manifest coverage, member sizes/SHA-256/modes, and reopening. Do not execute archived helpers, probes, packaging scripts or cleanup programs automatically. Scripts may be read as source and selectively reauthored outside the repository under this mandate.

Preserve these source identities and dispositions:

```text
original native candidate  17ee7db2925ed03ebc1614880fba5ec83d102d8c  298 files  unaccepted
failed writable attempt    ce18ef08e935e69980c7c5adf3486c39685df4c9  299 files  evidence only
starting refusal-only      b2e958c6a5d894fdf0d14dd5c821582c1d067489  299 files  unaccepted
```

Reconstruct the starting tree from all source bytes, Git modes and blob IDs. Preserve `tests/test_c2b3_private_atomic_program_initialization.py` at OS mode 0600 / Git mode 100644. Authentication is not correctness.

## 3. Corrected prospective opening and provenance recipe v3

Read live `AGENTS.md`, applicable nested guidance and section 5's owning documents. Disclose preliminary read-only activity; it is neither an automatic veto nor retrospective preservation evidence. Establish a fresh filesystem/raw-index opening before ordinary Git observations.

Fixed Git/source anchors:

```text
branch: codex/post-d2-native-proposal-admission-v1
HEAD: eac7f6df5f281138dd0640c5cd47b9924c8390f8
sole parent: 43ae26b9bccf9ad6ce61ec4722e14ac7b460ab18
HEAD tree: 061c43c41228310134a30f3b79291bba3e44f3f2
upstream: absent
local trunk_dev and origin/trunk_dev: fixed HEAD
local and remote-tracking D2 topic: f035d3f2767b3bd523d6c69083ea0ccb25048239
preserved D2 implementation commit: 59621aa041a409c6ead27b74ffe25598c159e78e
semantic index: 286 stage-zero entries exactly equal to HEAD tree; no stage/conflict
ambient exact-prefix config: 2,380 bytes; SHA-256 ed8e13f607961de69cd849a000fec3045fe7a7954572f3c468d21263532eab0e
starting source: exact 299 endpoints and tree b2e958c6a5d894fdf0d14dd5c821582c1d067489
```

Use read-only Git with optional locks, fsmonitor, untracked cache, replacement-object interpretation, external diff and textconv disabled. Do not use `update-index`, `reset`, `read-tree`, `write-tree`, checkout, switch, fetch or any explicit index/ref refresh.

### 3.1 Raw and semantic index

Copy the actual raw index bytes and metadata to a newly owned private external evidence root before ordinary Git reads. Repeat the raw read. Retain the complete stage/mode/blob/path inventory. The latest observed raw index was 32,314 bytes, SHA-256 `7e27326ab9b242d5bb56e41286d561be4dffed43dc3d377b5bffc75c8ffd5b07`; the earlier unexplained value was `7bd47e04c4dd62d43b33d2e01fa39df585b9df04f6cf809789e35dab36429a20`. A new difference is another unobserved interval, not permission to reset. The actual current raw bytes may become the **prospective** anchor only when repeated reads are stable, the semantic index equals HEAD, and all other checks in this section pass. Preserve that anchor thereafter.

### 3.2 Authoritative and diagnostic refs

Construct the expected authoritative map from Input 1's `opening-current-refs.raw` by excluding only names matching the two exact diagnostic regexes in section 1. Require 32 records and canonical SHA-256 `eaee93514b861f8dcf1d949c426acd164debfd01f9f6b1317b432a20b9b8b09e`. Independently confirm the same map in H1, H2 and the prior F1 final inventory.

At each opening/final observation:

1. Read `show-ref --head` losslessly.
2. Partition by exact name grammar, not target identity.
3. Require the authoritative map to equal the fixed 32-record map exactly.
4. For every current diagnostic ref, use `for-each-ref`/`cat-file` read-only observations to require a direct nonsymbolic ref to an existing `tree` object.
5. Require any diagnostic name present in two consecutive observations to retain the same OID. Additions/removals are allowed and recorded; retargets are blocking.
6. Require no source endpoint contains the literal `refs/codex/turn-diffs`, no worktree/HEAD/upstream/anchor selects one, no `refs/replace/**` exists or changes, and no measured configuration/source dependency points to the diagnostic namespace.
7. Preserve complete ref inventories, exact added/removed/retargeted sets and actor/cause uncertainty. Never restore/delete/freeze a diagnostic ref.

No total ref count or diagnostic aggregate is an acceptance target.

### 3.3 Narrow external collector v3

Preserve v1, v2, their hashes, manifests and failed outputs unchanged. Author one external-only v3 successor from the authenticated v2 source. This is a deliberate task-specific re-baseline, not a repository file or general framework.

Allowed v2→v3 changes are only:

- recipe ID becomes `governed-execution.post-d2-f1-recovery-dependency.patch.v3`;
- embed/verify the exact two diagnostic name grammars and the exact 32-record authoritative map (or its losslessly included map plus fixed canonical hash);
- fail on any authoritative mismatch, unqualified name, symbolic diagnostic ref, non-tree current diagnostic target, or surviving-name retarget;
- replace the volatile full-ref `entries/sha256` field in the **canonical source-binding manifest** with a deterministic authoritative-ref record containing the policy ID, exact count 32 and canonical SHA-256 `eaee93514b861f8dcf1d949c426acd164debfd01f9f6b1317b432a20b9b8b09e`, plus a boolean that all current diagnostics qualified;
- write the complete all-ref and diagnostic-ref inventories/object classifications as separate noncanonical sidecar evidence files for each run. Those sidecars may differ only by qualified diagnostic additions/removals and must always be retained and compared.

All other v2 logic—including baseline identity, exact thirteen-created-path inventory, source bytes/modes/blobs, semantic/raw index, config, tracked diff, canonical encoding and external destination behavior—must remain unchanged. Freeze and hash v3 before repository editing. Run it once at opening. The canonical manifest must match the authenticated starting source and current prospective raw-index anchor. Do not require sidecar equality across time.

The prospective preservation interval begins only after sections 3.1–3.3 all succeed. If they succeed, continue directly into section 4 in this same engagement; do not return another opening-only handoff. If they fail for a genuine authoritative/source/index/config mismatch, stop without mutation and retain exact evidence.

## 4. Freeze and implement the corrected recovery contract

The following owner-contract successor is selected, not a request for another broad reconnaissance.

A. Preserve precise classification. Only SQLite-supplied integer 776 (SQLITE_READONLY_ROLLBACK) produces UNKNOWN/recovery_needed at the safe observation boundary. Messages, a generic READONLY mask, any OperationalError, journal presence or caller flags are insufficient. inspect_database()/validate_database() remain observational. Initialize/migrate refuse recovery-needed without implicit recovery/migration. Preserve the WAL-header refusal that avoids a second writer-row diagnostic open/sidecar creation. Safe errors carry no raw SQL, paths, journal data or private values.

B. Govern entry. Healthy managed acquisition retains its existing route and errors. Only the precise recovery-needed condition can enter the recovery branch. Acquire the existing common authority lock, bind the configured EXISTING root/lock/database and reobserve while held. A pre-lock result is not authority over a later file. A concurrently resolved store can use normal acquisition only after the same binding and current schema validate. No absent/empty/unsupported/generic-error writable fallback.

C. Bound recovery dependencies. Before relevant write-capable access, check root/lock/database and fixed adjacent DELETE journal ownership, private modes, regular type, single link, no-follow/identity and compatible posture. A narrow bounded read-only structural journal check may reject super-journal/path-bearing tails or malformed/ambiguous supported-format evidence; it must never follow supplied paths or implement page replay. Refuse super-journal dependencies even inside the root, unsupported WAL/SHM/auxiliary arrangements and observed unsafe substitutions. Define missing/disappearing/truncated/zeroed/changed journal outcomes; do not turn uncertainty into eligibility or exclude ordinary recoverable cases merely to fit one fixture.

A no-super-journal result does NOT prove no prior ATTACH. The historical probe exited before COMMIT and recorded main recovery/issuance with a surviving sibling journal, not that sibling's hotness, corruption or an external I/O trace. Do not demand refusal just because the fixture author knows an attachment happened. Do not search outside the root for attachment history, recover another database, or claim the prior blocked attempt passed.

D. Use the existing engine/owners. SQLite performs rollback through the existing connection owner with create-disabled opening and common-lock custody. Recovery can happen on the first database-relevant read, not just connect(); establish eligibility before that operation and set existing nonpersistent safety controls as early as the API permits. No product ATTACH, manual journal deletion/rename/truncate/chmod, replacement, reinitialization, VACUUM, migration or extra connection factory. SQLite may consume/change the admitted journal; do not require its post-recovery inode/byte equality. Keep root/lock/database binding and cleanup valid.

The existing owner-private local-storage and same-account race limits remain. Holding checked descriptors does not prove the standard VFS exclusively uses those descriptors. Explain the supported engine access path and assumptions; do not promise hostile same-UID race-free or arbitrary-VFS confinement. If actual recovery dependencies cannot be bounded under that supported model, leave recovery disabled and report the precise gap, not the discarded demand for complete attachment history.

E. Separate storage effects from admission. After rollback, revalidate binding, exact current catalog/schema/invariants and durable writer state BEFORE ordinary issuance. Old prefixes still need explicit administrative migration; ineligible recovered state gets no writer. Preserve generation exhaustion/malformed-row checks, fencing, fresh proof, one-commit issuance, postcommit binding and publication. Recovery is not a credential or effect permit. Refusal afterward may mean no writer but changed storage. A lost return after known commit cannot become proven noncommit; no blind retry of an uncertain stateful operation. No new durable receipt/schema is required.

F. Keep compatibility and cleanup. In tests/test_b3c1b_rollback_only_writer_fencing.py::test_writer_acquisition_rechecks_filesystem_binding_before_publication, retain all four database/root/lock/hardlink variants, DATABASE_NOT_MANAGED expectation, and later privacy/registry/reacquisition assertions. The existing next-generation-2 expectation already admits a prior committed issuance. Do not map that healthy path to WRITER_ACQUISITION_FAILED merely because committed=True, or edit the assertions to accept it. Freeze recovery-specific closed reasons separately. Preserve KeyboardInterrupt/SystemExit/GeneratorExit, safe error handling and truthful connection/descriptor/lock disposition. Do not classify programming faults as recovery success or blanket corruption.

Technical context, not installed-binary authentication or network permission: SQLite documents precommit spill separately from later super-journal creation. version-3.49.1 pager.c readSuperJournal/pager_playback/pager_delsuper uses an optional journal-tail name; code 776 identifies rollback blocked by read-only access. References: https://www.sqlite.org/lockingv3.html ; https://www.sqlite.org/rescode.html#readonly_rollback ; https://raw.githubusercontent.com/sqlite/sqlite/version-3.49.1/src/pager.c . These support the dependency/history distinction, not a preaccepted repair or permission to browse.

## 5. Finite edit scope

Production edits only in src/ge_nwp_coordinator/:
  sqlite_connection.py
  sqlite_migration.py
  sqlite_errors.py
  sqlite_security.py
  sqlite_writer_session.py
Reuse state_authority_lock.py unchanged. No new module, public recovery API, StateStore method, generic SQL gateway or lifecycle/controller redesign.

Update the actual CURRENT claims in:
  .docs/writer-session-authority.md
  .docs/sqlite-bootstrap-and-migrations.md
  .docs/sqlite-operations-and-recovery.md
  .docs/sqlite-threat-model.md
Supersede refusal-only current wording explicitly while retaining the previous failure as history. Read architecture, authority boundaries, operating model, migration owner and first-live posture as constraints. No cosmetic AGENTS/README or status-normalization cycle. An additional EXISTING document/assertion consumer may change only where the pre-edit dependency map identifies a directly affected F1 contract and preserved property.

Use existing tests/test_sqlite_writer_hot_journal_recovery.py for fixtures/regressions. Direct existing tests are the eight modules below. Narrow necessary source/hash/import/error/doc assertion successors are permitted with a dependency map; retain historical identity/reconstruction anchors, independent companions and discriminating controls. No blind hash refresh, live-byte normalization, test deletion/weakening or changes to the four healthy-path expectations. Changing universal recovery refusal to supported recovery plus explicit refusals is the intended contract successor.

No new/deleted/renamed repository path: retain 299 source endpoints and exactly thirteen creations. Keep fixture helpers in the existing test module. A genuine need for another path is a scope stop, not permission to silently invalidate the collector.

Keep source-exact: all five SQL resources, their catalog checksums/tip 0005, application generation 2 and physical schema; sqlite_transition_transaction.py, state_authority_lock.py, StateStore and package exports; domain writers/readers, D1/D2, native continuation/basis/witness and pure V22. Preserve DELETE/FULL and nonpersistent posture. F2 and Unit 2 repairs are not included. Freeze the concrete dependency/edit map and owner contract before implementing effects, then continue this engagement.

## 6. Permitted local validation and required evidence

Execute only in newly owned EXTERNAL source copies authenticated before import, with disposable synthetic state, no remotes/private state/cache, and no live checkout on import paths. Inspect fixture sources before use. Keep bounded timeouts and exact child handles; terminate/reap only task-owned children. Test rescue is not product cleanup. No randomized kill campaign, syscall injection, privileged/host-wide tracing, dependency or power-loss experiment.

Historical credit: 291 focused passes belong to an earlier writable development source, not the final ce18ef08... tree. Its final run collected 9215 IDs, then interrupted with 1525 named passes and four failures; an unnamed unfinished XML element is not a pass. Refusal-only selections cover 370 distinct IDs, not 378 distinct tests, without final FULL. Keep those records/limits; they do not validate new bytes.

Required cases (record exact source, inputs, reached check, result and effects):

R1 — Genuine recovery. Use frozen refusal-only source as the direct comparator; original-candidate refusal remains historical evidence, not a new run. Generate separate equivalent genuine hot-journal fixtures for comparator and successor using a bounded task-owned child, uncommitted page spill and deliberate exit. Observe real numeric 776. No raw writable open/manual repair may pre-recover the product test target. Successor acquisition must restore committed logical state, remove uncommitted changes, issue the correct next generation and support a normal guarded operation. Mocked errors/filenames do not satisfy this case; do not call it Opus's unlink-window or power-loss reproduction.

R2 — Observation/admin. Repeated inspect/validate preserve database/journal bytes, directory membership and relevant non-atime metadata, reporting UNKNOWN/recovery_needed with no writable open, hidden recovery, root/sidecar creation or issuance. Initialize/migrate still refuse. Preserve absent/empty/generic-error, old-prefix and WAL-header behavior. Separately test exact numeric classification and generic/string/bool/absent imitations; no replacement of R1 by mocks. Disclose atime limits.

R3 — Eligibility. Exercise a real common-lock holder; unsafe root/lock/database/journal type, owner, mode, link and substitutions; absent/disappearing/changed journal; incompatible WAL/SHM/auxiliary posture; ambiguous header/tail; and a recognizable nonempty super-journal dependency. The dependency control must reach that rejection, not an earlier unrelated parse error. A finite synthetic format fixture is allowed and labelled as structural, not a genuine crash. Confirm no relevant writable recovery open or issuance and actual cleanup; use only owned sentinels, never user files.

R4 — Corrected cross-file-origin control. Rebuild the small pre-COMMIT ATTACH fixture using new task-owned main/sibling databases. Product recovery receives only the main location. For an otherwise supported main journal without a rejected dependency, verify main rollback/issuance and unchanged external sibling database/journal bytes/metadata (disclose atime), without a product sibling recovery/ATTACH. Compare sibling bytes without a SQLite open that would repair them. Establish the no-external-dependency access argument from the actual admitted engine path; distinguish source inference from runtime observations. Byte equality, Python open hooks or sqlite trace_callback alone do not prove absence of C/VFS reads. No new host tracer is required or authorized; if read visibility is absent, disclose it rather than inventing a trace. A defensible supported-engine/dependency argument is required. Mere remaining sibling-journal existence is not a failure under the revised contract.

R5 — Recovery versus admission. Recover a genuine interrupted fixture with old/ineligible recovered schema and prove no writer/migration, while honestly recording rollback effects. Verify the five SQL/catalog identities. Distinguish uncommitted issuance from committed issuance with lost publication; supplemental test proxies/hooks may cover causal boundaries but are not actual process death. Check generation/fencing, no credential resurrection/duplicate domain effects and no false noncommit.

R6 — Cleanup/compatibility. Cover new open/read/close failures, binding changes, unresolved recovery, post-recovery validation failures and process-control interruption. Observe descriptors, registry, lock custody and reacquisition where released. Run the four original publication-drift cases EARLY with unchanged reasons/later assertions and the complete binding module. They are separate from the revised attachment-history condition.

R7 — Connected regression. Exercise the existing actual D1/D2 -> Section 41 A -> C1 B -> V22 positive for its CURRENT three-observation shape. This is shared-backend compatibility, not F4/F5/witness repair or restart of a disposed D2 run. Retain existing genesis/author/Section41/C1 recovery/fencing/cleanup coverage in FULL.

Save/reopen an early substantive checkpoint once R1, observational preservation, one actual eligibility/dependency refusal, R4, and the four healthy-path cases have results. Preserve partial source and actual results even if failing, then continue the remaining work. Do not run a broad suite while the recovery boundary is unsupported or return a plan-only/checkpoint-only result when bounded execution can continue.

Every run needs exact argv, cwd, safe environment allowlist, versions, exit/status, stdout/stderr, IDs/warnings, pre/post source manifest and reconstructible source bytes/delta. A bare manifest cannot recover missing source; retain distinct development/failure/final subjects. No test result is transferred to later source merely because its change is small.

Use an installed supported interpreter with pytest, verified from a neutral directory. Previously: /Library/Frameworks/Python.framework/Versions/3.13/bin/python3, Python 3.13.4, pytest 8.4.1, SQLite 3.49.1. Record actual SQLite/build/platform facts; safe version/compile-option queries may use an owned scratch/in-memory database, not live state. No installation or unexecuted minimum-version/other-platform claim.

Tests: PYTHONDONTWRITEBYTECODE=1, PYTEST_DISABLE_PLUGIN_AUTOLOAD=1, PYTHONPATH=.:src, owned TMPDIR, umask 077; clear inherited PYTEST_ADDOPTS/PYTEST_PLUGINS and selection/coverage inputs. Preserve required child environment explicitly without secret dumps. Keep ambient Git-config measurement separate. Fixture-mode expectations must remain intentional under the restrictive umask.

Focused development, from the authenticated external copy (variables name actual owned paths):
  "$PYTHON" -B -m pytest -q -p no:cacheprovider --basetemp="$VALIDATION_ROOT/focused" --junitxml="$VALIDATION_ROOT/focused.xml" tests/test_sqlite_writer_hot_journal_recovery.py tests/test_sqlite_b2c_writer_session.py tests/test_sqlite_b1_connection_posture.py tests/test_sqlite_b1_filesystem_security.py tests/test_sqlite_b1_migrations.py tests/test_sqlite_c2b1_migration_framework.py tests/test_state_authority_lock.py tests/test_b3c1b_rollback_only_writer_fencing.py
Additional targeted existing tests for concrete dependencies are allowed; retain selections and do not add overlapping counts as independent coverage.

FINAL: after all in-scope fixes, freeze one clean final external source copy and run one selector-free collection and one selector-free FULL:
  "$PYTHON" -B -m pytest -q -p no:cacheprovider --collect-only --basetemp="$VALIDATION_ROOT/final-collect" > "$VALIDATION_ROOT/final-collect.txt" 2>&1
  "$PYTHON" -B -m pytest -q -p no:cacheprovider --basetemp="$VALIDATION_ROOT/final-run" --junitxml="$VALIDATION_ROOT/final-junit.xml" > "$VALIDATION_ROOT/final-run.txt" 2>&1
No path selector, -k, -m, ignore/deselection, xdist, fail-fast or suppression. Retain process exit, exact collected versus executed IDs, JUnit outcomes/warnings/skips and unchanged source bytes/modes. Neither 9191 nor 9215 is an expected successor count. Failed/interrupted attempts remain bound to their own source; repair only in-scope causes and then freeze a new final run. Missing required coverage, skips/xfails or interrupted FULL cannot be called validated success. Record existing fork warnings. Implementation FULL does not replace independent FULL.

## 7. Final provenance, delivery and disposition

After edits stop, run frozen collector v3 twice into fresh external destinations; match live final source to the final validated source and preserve raw/semantic index, config and the exact 32-record authoritative ref map. Require the two v3 canonical manifests to be byte-identical. Retain complete diagnostic-ref sidecars and disclose any qualified add/remove variation separately; do not fold their volatile count or hash into the canonical source binding. Repeat preservation after bounded cleanup. No new anchor may excuse drift.

Return ONE review ZIP under 250 MB, without recursively nesting older packages:
- received mandate/input identities, explicit contract/provenance changes and preserved dispositions;
- source/ with all 299 FINAL endpoints, complete size/type/OS+Git-mode/SHA-256/blob manifest and new reconstructed tree; incremental delta from b2e958c6... AND total F1-only delta from 17ee7db...; cumulative HEAD-relative tracked diff and thirteen creations;
- v1/v2/v3 recipes, exact code diff/hashes, both final manifests, full semantic-index and ref inventories/classifications, prospective raw index copies, safe config measurements, SQL/catalog preservation and dependency/touched-file map;
- early checkpoint or its compact reconstructible delta/receipts; final fixtures/tests, source-bound commands/logs/collection/JUnit, R1–R7 predicate/effect coverage and limitations; failed/interrupted records with correct source identities;
- IMPLEMENTATION_REPORT.md, machine-readable result, complete member manifest with explicit self-exclusion.

source/ must mean the delivered final subject, never the abandoned attempt. Classify the prospective raw index as private noncredential repository-metadata evidence; retain it without printing it. No live database/journal/WAL/SHM, private capsule, credentials, environment/config dump, bytecode/cache/build/egg-info output. Synthetic builders, hashes and safe logical observations suffice without database binaries. Preserve original ZIPs unchanged by identity/path rather than nesting them repeatedly.

Retain evidence before removing only enumerated newly owned temporary source/test/state roots and owned children. No prior package/ignored state or sole failure evidence may be removed. Reopen the ZIP, verify complete manifest coverage and reconstruct its final source tree. Report exact ZIP/report paths, bytes and SHA-256. Archive integrity, live preservation and validation are distinct.

Use one truthful primary disposition:
  POST_D2_F1_RECOVERY_ENTRY_REPAIR_IMPLEMENTED_VALIDATED_PENDING_REVIEW
  POST_D2_F1_RECOVERY_ENTRY_REPAIR_INCOMPLETE
  POST_D2_F1_RECOVERY_ENTRY_REPAIR_BLOCKED
Even the first is only implementation-validated F1 work. Include ORIGINAL_CANDIDATE_UNACCEPTED; SUCCESSOR_INDEPENDENT_AUDIT_NOT_PERFORMED; UNIT2_AND_OTHER_HOLDS_REMAIN; STAGING_COMMIT_PUBLICATION_NOT_PERFORMED. Report commands/results, failed/skipped/unperformed work, authority/security assumption changes, preservation limits and separate provenance/validation/implementation confidence. No whole-candidate ACCEPT.

Stop the relevant effect on missing mandatory source, unexpected live source/Git/protected changes, a competing writer, inability to enforce the selected recovery-dependency boundary, a needed new module/schema/path or stronger threat model, unauthorized live/network/install needs, sensitive-material risk or unavailable required validation. Preserve actual partial source and findings. No unrestricted fallback, automatic old-attempt restoration, provenance reset, Opus assignment or audit retry. A provider refusal remains an access limitation: report only observed actions and exact unfinished coverage, and do not automatically reformulate/resubmit it.
