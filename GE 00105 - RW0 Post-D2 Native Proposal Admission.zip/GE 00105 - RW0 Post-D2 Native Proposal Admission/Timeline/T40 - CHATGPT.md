**The F1 classification repair is suitable as the frozen implementation base for Unit 2.** I found no new blocking defect in the exact two-file delta. This is an engineering disposition—not independent acceptance of F1 or the whole native-proposal candidate.

The package authenticates to:

```text
F1ClassificationRepairReviewFinal.zip
Size:   7,406,558 bytes
SHA-256:
9cb40710e2a6d2c4d13fb79196885d12d5f52ea1e7f5f7f50ebf1b48f24085b3

Final source tree:
93afef8750e062d80626a5a37adfa27766305b7c
```

All 299 source endpoints and the reconstructed tree match the package. The predecessor delta changes only `sqlite_writer_session.py` and `test_sqlite_writer_hot_journal_recovery.py`. The correction now distinguishes post-recovery operational uncertainty as `recovery_unresolved` while preserving `database_not_managed` for deterministic schema or catalog ineligibility. The new regression exercises a genuine hot journal, verifies no issuance or hidden retry, confirms lock release, and then obtains generation 2 after removing the injected inspection failure. IMPLEMENTATION_REPORT

The retained validation evidence is internally consistent: 9,232 collected IDs equal 9,232 executed JUnit IDs, with zero failures, errors, or skips. I did not rerun those tests; this remains authenticated implementation evidence. IMPLEMENTATION_REPORT

## Next Codex handoff

Send **only this prompt** to the **same native-proposal/F1 implementation Codex conversation**, with write permission:

:chatgpt-content-reference{index="3"}[**Coordinator Unit 2 implementation mandate**](sandbox:/mnt/data/Coordinator_Unit2_Legal_Layouts_Typed_Invalid_Evidence_and_Witness_Repair_Prompt.txt)

Do not send the static review, prior F1 prompts, or any audit mandate alongside it. Keep the independent auditor and Opus out of this implementation engagement.

The mandate starts from exact tree `93af…` and freezes all fourteen F1 paths byte-for-byte. It addresses the remaining connected repair unit:

1. **Both legal D2 layouts.** The existing two-observation and three-observation worker forms become exact 13- and 14-member checked layouts throughout D2 A, D2 B, handback validation, native safe-basis persistence, and historical readback. It forbids narrowing the Wire grammar or fabricating `candidate_captured`.

2. **Typed malformed-input stops.** A clean validator or reviewer process returning invalid checking evidence produces `validator_evidence_invalid` or `reviewer_evidence_invalid`, preserving the actual checked prefix and process outcome. The mandate explicitly prohibits a blanket `ValueError` or `Exception` catch.

3. **Original-run witness association.** The fresh Section 41 writer must derive the complete expected command and safe basis from the original open D2 run and compare them exactly before any target write. A donor child-outcome witness with consistently recomputed digests must be rejected before rows or a receipt appear.

The existing three-observation command and safe-basis bytes must remain byte-identical. The new two-observation path uses the same physical schema with an exact 13-member witness; no migration or V22 change is permitted.

The first substantive checkpoint must include an actual two-observation D1 → D2 → Section 41 A → C1 B → V22 positive, the unchanged three-observation positive, both malformed-checker stops, the donor-witness refusal, and historical 13/14-member readback. Final validation requires one focused selection and one selector-free collection/FULL run on authenticated external source copies.

**No new repository files, migration changes, staging, commit, push, PR, merge, audit retry, or publication are authorized.**

:chatgpt-content-reference{index="4"}[Static F1 package review](sandbox:/mnt/data/Coordinator_F1_Classification_Repair_Static_Review.md)  
:chatgpt-content-reference{index="5"}[Handoff integrity record](sandbox:/mnt/data/Coordinator_Unit2_Handoff_Check.json)

The original candidate and the new F1 checkpoint remain unaccepted. Historical provenance gaps, the provider-access interruption, F2, qualified F3/F6/F7, and the unfinished candidate-specific independent audit remain open. IMPLEMENTATION_REPORT

**Sources:** Codex’s F1 classification-repair report and authenticated review package; prior F1 package and original native-proposal package used for exact predecessor and cumulative comparisons.

**Confidence:** package/source provenance **0.99**; F1 static correctness assessment **0.97**; Unit 2 scope and handoff **0.95**. Runtime correctness of the future Unit 2 successor remains unestablished.
