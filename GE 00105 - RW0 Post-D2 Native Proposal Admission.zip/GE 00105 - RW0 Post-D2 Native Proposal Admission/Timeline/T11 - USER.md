Which prompt(s) should I send to Codex? I see three files.
