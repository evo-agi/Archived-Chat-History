# Coordinator Unit 2 implementation mandate
## Legal D2 layouts, typed invalid-evidence stops, and original-run witness association

### Routing and authorization

Use this mandate in the **same write-enabled Coordinator implementation Codex conversation** that produced `F1ClassificationRepairReviewFinal.zip` and tree `93afef8750e062d80626a5a37adfa27766305b7c`.

The foreground parent is the sole repository writer. Do not delegate mutation to subagents. This is an implementation/validation engagement, not an independent audit.

Authorized effects are limited to the source, documentation, tests, external-copy validation, provenance collection, bounded cleanup, and review-package creation defined below. Do **not** stage, commit, push, create or update a PR, merge, fetch, install dependencies, contact a provider or live service, operate on a user database, invoke ES or Bridge, or publish any product effect.

This mandate is complete. Do not require the user to assemble earlier prompt fragments.

---

## 1. Objective

Starting from the exact F1 checkpoint tree

```text
93afef8750e062d80626a5a37adfa27766305b7c
```

implement one bounded Unit 2 successor that corrects three connected source defects while preserving the F1 repair byte-for-byte:

1. **F4 — both legal worker-observation layouts:** carry both Wire-legal worker result forms through D2 A, D2 B, handback validation, native Section 41 safe-basis construction, persistence, and checked readback:
   - `worker_started, worker_completed`;
   - `worker_started, candidate_captured, worker_completed`.

2. **Malformed-input F5 — typed checking stops:** when a validator or reviewer process exits cleanly but returns a declared-invalid checking frame or checking record, return a stage-specific typed D2 stop with the exact reached prefix and clean process outcome. Do not leak a raw normalization exception, mislabel it as process failure, or catch unrelated programming/process-control errors.

3. **`NPA-WITNESS-01` — original-run association:** at the fresh native Section 41 write boundary, independently derive the expected command and complete safe basis from the original open D2 run and require exact equality with the supplied command and safe-basis bytes before any target insert. This must bind the child outcome attestations as well as every other safe-basis field to that run.

The result remains one artificial offline proof. It makes no C2 decision, acceptance, terminal outcome, executable permission, restart-safe custody, live provider claim, ES/Bridge route, Git effect, service, scheduler, or autonomous-loop claim.

---

## 2. Fixed inputs and exact opening subject

Authenticate these local retained inputs before ordinary repository work:

### Input A — current implementation subject

```text
/Users/ds/Downloads/Coordinator_F1_Classification_eSUxoG/F1ClassificationRepairReviewFinal.zip
```

Expected identity:

```text
size:   7,406,558 bytes
SHA256: 9cb40710e2a6d2c4d13fb79196885d12d5f52ea1e7f5f7f50ebf1b48f24085b3
```

Its sole final source subject is `source/`, containing 299 regular source endpoints and reconstructing tree:

```text
93afef8750e062d80626a5a37adfa27766305b7c
```

The included implementation report is 7,230 bytes, SHA-256:

```text
948e0cd190846cd26c1c43804ee808d1f719ce60274817ed463051cb7fde60a5
```

### Input B — original native-proposal candidate

```text
/Users/ds/Downloads/Coordinator_PostD2_Final_ftssNh/ReviewPackage.zip
```

Expected identity:

```text
size:   14,481,457 bytes
SHA256: d9b4d61e212893b48ba1952c3b5370c09874ca2e70798decc36bc4fdbd893d9b
source tree: 17ee7db2925ed03ebc1614880fba5ec83d102d8c
```

Use Input B only for cumulative-delta and historical-identity comparison. Do not restore its bytes over the F1 checkpoint.

### Expected live repository posture

```text
repository: /Users/ds/Repositories/Governed Execution Coordinator
branch:     codex/post-d2-native-proposal-admission-v1
HEAD:       eac7f6df5f281138dd0640c5cd47b9924c8390f8
HEAD tree:  061c43c41228310134a30f3b79291bba3e44f3f2
upstream:   absent
working source tree: 93afef8750e062d80626a5a37adfa27766305b7c
source endpoints: 299
stage-zero index entries: 286, equal to HEAD
created paths relative to HEAD: exactly the existing thirteen
```

The prospective raw-index anchor retained by Input A is:

```text
size:   32,314 bytes
SHA256: 7e27326ab9b242d5bb56e41286d561be4dffed43dc3d377b5bffc75c8ffd5b07
```

The configuration anchor is:

```text
size:   2,380 bytes
SHA256: ed8e13f607961de69cd849a000fec3045fe7a7954572f3c468d21263532eab0e
```

The frozen authoritative-ref map contains 32 direct refs with canonical SHA-256:

```text
eaee93514b861f8dcf1d949c426acd164debfd01f9f6b1317b432a20b9b8b09e
```

Use the exact v3 collector and authoritative/diagnostic-ref policy retained in Input A. Capture/checkpoint refs under the already qualified turn-diff name grammars remain complete sidecar observations rather than canonical source authority. Do not restore, delete, retarget, or attribute them. Any authoritative-ref mismatch, diagnostic retarget, invalid diagnostic name/type/target, source mismatch, index semantic mismatch, raw-index mismatch, configuration mismatch, branch/HEAD/upstream mismatch, staged entry, or unexpected source path blocks mutation.

Opening-block verdict:

```text
POST_D2_UNIT2_OPENING_BLOCKED
```

Do not reset or normalize a mismatch into the new baseline.

---

## 3. Current disposition and historical limits

Tree `93afef8750e062d80626a5a37adfa27766305b7c` is an authenticated implementation checkpoint, **not an accepted candidate**. Its retained validation is implementation evidence, not independent audit credit.

Preserve without reinterpretation:

- the original unaccepted native candidate tree `17ee7db2925ed03ebc1614880fba5ec83d102d8c`;
- the refusal-only, failed-attempt, blocked-opening, and earlier F1 subjects;
- both historical `AUDIT_PROVENANCE_MISMATCH` results and their unresolved intervals;
- the provider-access interruption and unfinished candidate-specific audit;
- the scoped authoritative-state versus diagnostic-ref treatment;
- the still-outstanding A01–A12, connected-proof, discriminating-control, and independent selector-free FULL obligations.

This Unit 2 implementation creates a new successor identity. It does not retroactively accept any predecessor.

---

## 4. Frozen Unit 1/F1 checkpoint

The following fourteen F1 paths must remain **byte- and mode-identical** to Input A throughout Unit 2:

```text
.docs/sqlite-bootstrap-and-migrations.md
.docs/sqlite-operations-and-recovery.md
.docs/sqlite-threat-model.md
.docs/writer-session-authority.md
src/ge_nwp_coordinator/sqlite_connection.py
src/ge_nwp_coordinator/sqlite_errors.py
src/ge_nwp_coordinator/sqlite_migration.py
src/ge_nwp_coordinator/sqlite_security.py
src/ge_nwp_coordinator/sqlite_writer_session.py
tests/test_sqlite_b1_filesystem_security.py
tests/test_sqlite_b1_migrations.py
tests/test_sqlite_backend_b0_contract.py
tests/test_sqlite_c2b1_migration_framework.py
tests/test_sqlite_writer_hot_journal_recovery.py
```

This includes the final F1 classification repair in `sqlite_writer_session.py` and its genuine-hot-journal regression. Do not fold Unit 2 into the SQLite recovery implementation, alter its error vocabulary, or refresh F1 tests/docs merely because Unit 2 changes other source.

If Unit 2 cannot be implemented without changing any frozen F1 path, stop with:

```text
POST_D2_UNIT2_F1_BOUNDARY_CONFLICT
```

and report the exact dependency. Do not edit first and justify later.

---

## 5. Other invariants and non-goals

Preserve exactly unless this mandate explicitly says otherwise:

- migrations `0001` through `0005`, their bytes, catalog checksums, application generation 2, physical tables/triggers/indexes, and explicit-migration-only behavior;
- the Section 41 transaction A / C1 transaction B ownership split;
- C1 rank-15 admission, receipt-first replay, three-way recovery, and frozen twelve-common-owner-row graph;
- the pure V22 projection source and semantics;
- the nine model-evidence roles and twelve common Section 41 owner rows;
- the original `run_rw0_d2_offline()` entry and `preadmission_ready` non-acceptance meaning;
- the legal Wire grammar; do not make `candidate_captured` mandatory and do not modify D1 to invent or infer a missing worker observation;
- parent-owned candidate capture and capsule verification;
- no public/package export, `StateStore` widening, public `WriterSession` widening, new connection owner, general join framework, generalized evidence registry, new migration, or new source/test/document file;
- process-control exceptions (`KeyboardInterrupt`, `SystemExit`, `GeneratorExit`) and cleanup/custody responsibilities;
- model recommendation as evidence only;
- exact historical 14-member persisted-family replay.

F2, escaped-descendant containment/F3, F6, F7, cross-host clock redesign, live custody, first-live supplier work, C2 persistence, and publication are outside Unit 2.

---

## 6. Contract A — two exact legal D2 A layouts

### 6.1 Legal worker observation forms

The existing Wire owner permits exactly these complete worker observation sequences:

```text
2 observations:
  worker_started
  worker_completed

3 observations:
  worker_started
  candidate_captured
  worker_completed
```

Absence of `candidate_captured` is not an authoritative claim that the parent captured no candidate. D1's parent-owned capture/capsule remains the source of actual candidate bytes. Do not narrow the legal two-observation form to preserve current indices.

### 6.2 Exact checked-family order

For `n` legal worker observations, where `n` is exactly 2 or 3, the complete checked-family sequence is:

```text
0 .. n-1   worker observations, in Wire order
n          adapter exit observation
n + 1      worker-result binding
n + 2      process-result classification
n + 3      validation authority
n + 4      review authority
n + 5      readiness
n + 6      validation qualification
n + 7      validator observation
n + 8      review qualification
n + 9      reviewer observation
n + 10     author authority
```

Complete count:

```text
n + 11 = 13 or 14
```

Exact complete rank sequences:

```text
13-member layout:
(12, 12, 12, 13, 14, 1, 1, 5, 6, 12, 6, 12, 1)

14-member layout:
(12, 12, 12, 12, 13, 14, 1, 1, 5, 6, 12, 6, 12, 1)
```

Implement one private, closed layout/role resolver in an existing D2 owner. Every affected consumer must use the same named role resolution or an exact derived value from it. Do not scatter independent `n + k` arithmetic or retain fixed numeric indices in downstream consumers.

The resolver must reject:

- any observation count other than 2 or 3;
- wrong observation order or kinds;
- duplicate, omitted, inserted, or reordered checked roles;
- wrong rank/type/schema/phase/member identity;
- mismatched relation/dependency owners;
- bool-as-int or wrapper substitution;
- a supplied layout detached from the actual D1 Wire result.

Keep relationship checks exact. This is a finite two-layout contract, not an unordered lookup or general join.

### 6.3 Exact dynamic prefix boundaries

For a layout with `n` worker observations:

```text
base through readiness:                n + 6 checked members
through validation qualification:      n + 7
through validator observation:         n + 8
through review qualification:          n + 9
through reviewer observation:          n + 10
complete through author authority:      n + 11
```

The retained stop/prefix rules must derive from the resolved layout:

- no checker child may exist before the validation-qualification prefix;
- validator process cleanup/failure/invalid-evidence stops have `n + 7` checked members and one child outcome;
- reviewer process cleanup/failure/invalid-evidence stops have `n + 9` checked members and two child outcomes;
- `reconstruction_not_independent` has `n + 10` checked members and two clean child outcomes;
- complete A evidence has `n + 11` checked members;
- C1 admission/readback/commit failures retain the actual reached prefix and the child count implied by that prefix:
  - zero children at or below `n + 6`;
  - one child at or below `n + 8` after the first launch;
  - two children thereafter.

Preserve all existing cleanup and reason distinctions. Do not award a deeper reached prefix than was actually admitted.

### 6.4 Complete consumers

Remove fixed-14/fixed-index assumptions from the complete current path, including at least:

```text
src/ge_nwp_coordinator/_rw0_d2a_evidence.py
src/ge_nwp_coordinator/_rw0_d2a_offline.py
src/ge_nwp_coordinator/_rw0_d2a_handback.py
src/ge_nwp_coordinator/_rw0_d2_handback.py
src/ge_nwp_coordinator/_rw0_d2b_model_input.py
src/ge_nwp_coordinator/_section41_post_execution_proposal_mutation_contracts.py
src/ge_nwp_coordinator/_rw0_d2_post_execution_continuation.py
src/ge_nwp_coordinator/_sqlite_section41_post_execution_proposal.py
```

Inspect `src/ge_nwp_coordinator/_rw0_d2_offline.py` as a required dependency. Keep it byte-exact unless the new typed stop reason cannot be carried through its existing `_D2AStop` path without a narrowly justified edit.

The two-observation layout must flow through:

```text
actual D1 run
→ D2 A admissions/checkpoint
→ D2 B nine-role context/supply/model result
→ typed preadmission handback
→ native Section 41 transaction A
→ checked A readback
→ C1 rank-15 transaction B/readback
→ unchanged pure V22
```

There is no manual relay and no direct SQL seeding of A or B target families.

---

## 7. Contract B — typed clean-process invalid-evidence stops

### 7.1 New reasons

Add exactly these stage-specific reasons to the private D2 handback grammar:

```text
validator_evidence_invalid
reviewer_evidence_invalid
```

They mean:

- the respective child process was launched;
- its process outcome is valid, reaped, `cleanup_complete=true`, and `clean_success=true`;
- the returned checking frame/record failed the declared closed checking-input grammar or its relation to the already validated command/adapter inputs;
- no observation from that invalid record was admitted;
- no later checker/model/native A/B effect ran;
- the exact prior checked prefix and child outcome are retained.

They do **not** mean process failure, cleanup failure, internal invariant failure, clock redesign, or C1 failure.

### 7.2 Exception boundary

Do not catch all `Exception` or all `ValueError` at `_run_checker` and call it input invalid.

Introduce a dedicated private exception emitted only by a narrowly bounded child-record decode/normalization helper. Trusted command/author/adapter/process inputs must be validated outside that conversion boundary. Convert only:

- `D2CheckingFrameError` from the closed response frame decoder; and
- explicitly identified closed validation failures caused by fields in the decoded child-supplied record.

Programming/invariant failures outside that declared input surface and process-control exceptions must propagate. Existing process cleanup/failure reasons remain unchanged.

The parent must return a typed stopped handback through the existing `_D2AStop` path, not close the D1 run and rethrow a raw malformed-input exception.

### 7.3 Required discrimination

Tests must establish all of the following:

- validator exit zero + malformed frame → `validator_evidence_invalid`;
- reviewer exit zero + malformed frame → `reviewer_evidence_invalid`;
- process nonzero remains `*_process_failed`;
- cleanup unresolved remains `process_cleanup_unresolved`;
- an injected internal/programming error outside the declared child-input conversion boundary is not relabelled as invalid evidence;
- both legal 13- and 14-member layouts retain their exact stage prefixes;
- no later child/model/Section 41/C1 effect occurs after either invalid-evidence stop.

Do not change the separate wall-clock ordering contract in this unit.

---

## 8. Contract C — exact original-run command and safe-basis association

### 8.1 One canonical derivation

Centralize the derivation of:

```text
RecordPostExecutionProposalCommandV1
canonical safe_basis_bytes
```

from the original open `RW0D2OfflineRun` in one private existing owner, chosen to avoid import cycles. Both the continuation caller and the fresh writer boundary must use that same derivation. Do not maintain two equivalent-looking implementations.

The derivation must validate the original run, handback, complete legal D2 layout, A-to-B associations, bound effects, child role/order/outcomes, safe projections, and all repeated identities before producing the command and bytes.

### 8.2 Fresh writer equality gate

In `write_fresh_after_fencing`, after establishing the exact original open run and before route probing, target insertion, or receipt construction:

1. derive the expected command and canonical safe-basis bytes from that run;
2. require the supplied command to equal the expected command as a complete typed value;
3. require supplied `safe_basis_bytes` to equal the derived canonical bytes exactly;
4. require the safe-basis digest and all dependent command identities to match that derivation.

A structurally valid donor basis with recomputed safe-basis digest, command digest, child attestations, and dependent identities must fail specifically because it does not equal the original run-derived subject. The refusal must occur before any target row or receipt is inserted.

Do not rely only on the continuation producer. The fresh write boundary owns this check.

### 8.3 Historical replay boundary

Do not rerun children or require present process custody for receipt-first historical replay/readback. Existing historical verification continues to prove the persisted immutable family and command identity. Fresh-write original-run association and historical persisted-family verification are distinct responsibilities.

### 8.4 Safe-basis compatibility

The `d2_checkpoint_witness.checked_memberships` parser must accept exactly the two complete legal rank/layout sequences in §6.2 and reject every other count/order/rank sequence.

For the existing three-observation fixture, the repair must preserve the exact pre-Unit-2:

- command mapping and command digest;
- canonical safe-basis bytes and byte count;
- safe-basis digest;
- 14-member witness order;
- persisted row/receipt identities.

Before editing, capture and retain that vector from an authenticated external copy of Input A. After implementation, the same fixture must reproduce it byte-for-byte. This is a compatibility gate, not a new authority source.

The new two-observation path may produce the distinct exact 13-member witness under the same physical schema. No migration or row-schema change is authorized.

---

## 9. Documentation and assurance successors

Update current truth without rewriting history.

### Required owning documents

```text
AGENTS.md
.docs/rw0-d2-offline-evidence-and-review.md
.docs/rw0-c1-durable-evidence.md
.docs/section41-post-execution-proposal-family.md
.docs/c2b-durable-development-state.md
.docs/rw0-b2-capability.md
```

Required treatment:

- state the exact two legal layouts and their 13/14 checked-family forms;
- preserve parent-owned capture semantics and the non-meaning of omitted `candidate_captured`;
- record the two typed invalid-evidence stops and their reached-prefix meaning;
- record fresh-write derivation/equality to the original run and the separate historical replay boundary;
- retain all authority/nonclaim language;
- do not claim independent acceptance, commit, publication, live restart, C2 authority, or product execution.

`AGENTS.md` currently has a complete-file P11 identity chain. Treat this as a named P11 successor:

- preserve the current 67,252-byte identity as the immediate predecessor;
- preserve the earlier 65,275-byte and 64,142-byte historical reconstructions;
- keep complete-current-file raw hashing and the independent companion check;
- add bounded forward/reverse reconstruction only for the exact Unit 2 status/contract spans;
- do not introduce general normalization, dynamic expected values, or a hash refresh without semantic controls.

### Required current identity/status consumers

```text
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
tests/test_c2b0_durable_state_contract.py
```

Inspect `tests/test_architecture_contracts.py` before editing; change it only if an existing exact current-contract assertion directly requires the Unit 2 successor. Preserve all unrelated identities, hostile controls, and historical rows.

---

## 10. Selected touched-file scope

### Production files authorized

```text
src/ge_nwp_coordinator/_rw0_d2a_evidence.py
src/ge_nwp_coordinator/_rw0_d2a_offline.py
src/ge_nwp_coordinator/_rw0_d2a_handback.py
src/ge_nwp_coordinator/_rw0_d2_handback.py
src/ge_nwp_coordinator/_rw0_d2b_model_input.py
src/ge_nwp_coordinator/_section41_post_execution_proposal_mutation_contracts.py
src/ge_nwp_coordinator/_rw0_d2_post_execution_continuation.py
src/ge_nwp_coordinator/_sqlite_section41_post_execution_proposal.py
```

`src/ge_nwp_coordinator/_rw0_d2_offline.py` is inspect-first and may change only for the narrow typed-stop plumbing described in §7. No other production file is authorized.

### Core causal tests authorized

```text
tests/test_rw0_d2_offline_integration.py
tests/test_rw0_d2_model_handback.py
tests/test_rw0_d2_evidence_children.py
tests/test_rw0_d2_process_frames.py
tests/test_rw0_d2_c1_checked_readback.py
tests/test_rw0_d2_post_execution_admission_integration.py
tests/test_section41_post_execution_proposal_contracts.py
tests/test_section41_private_atomic_post_execution_proposal.py
tests/test_section41_post_execution_proposal_recovery.py
```

### Structural/status tests authorized

```text
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
tests/test_c2b0_durable_state_contract.py
tests/test_post_execution_pure_owner_boundaries.py
tests/test_post_execution_pure_owner_vectors.py
tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
```

Change the last three only if the actual import/caller inventory changes. Do not refresh their literals speculatively.

### No new repository files

The current v3 provenance inventory has exactly thirteen created paths. Unit 2 must use existing files and preserve that inventory. If a genuinely necessary source/test/document file is missing, stop before creating it and report:

```text
POST_D2_UNIT2_NEW_PATH_REQUIRED
```

Do not modify the collector to absorb an unapproved path.

---

## 11. Required causal evidence

### 11.1 Pre-edit compatibility capture

From an authenticated external copy of Input A, run the existing three-observation connected fixture only as needed to retain a safe vector containing:

- exact command mapping/digest;
- exact canonical safe-basis bytes, byte count, and digest;
- 14 checked membership selectors/ranks/order;
- relevant persisted context/receipt identities.

Bind the vector to source tree `93afef8750e062d80626a5a37adfa27766305b7c`. Do not use the live checkout for imports or tests.

### 11.2 First substantive repaired checkpoint

Before broad validation, create, save, reopen, and verify one checkpoint containing these exact final-source cases:

1. **Two-observation connected positive:** an actual D1 result with only `worker_started` and `worker_completed` proceeds through D2 A, D2 B, Section 41 A, C1 B, checked readback, and unchanged V22. No target SQL seeding or manual relay.
2. **Three-observation compatibility positive:** the existing path remains valid and reproduces the pre-edit command/safe-basis vector byte-for-byte.
3. **Validator invalid evidence:** clean exit-zero malformed checking input returns `validator_evidence_invalid` with the exact prefix, no reviewer/model/native effect.
4. **Reviewer invalid evidence:** validator succeeds; clean reviewer exit-zero malformed checking input returns `reviewer_evidence_invalid` with the exact prefix, no model/native effect.
5. **Original-run witness association:** a structurally valid donor command/safe basis with recomputed dependent digests reaches the fresh write association gate and is rejected before any target row/receipt; the own-run counterpart commits.
6. **Historical compatibility:** exact 14-member replay/readback remains valid; exact 13-member replay/readback is valid; no child/model rerun occurs.

The checkpoint must carry source identity, exact commands, returned typed reasons/results, row counts, and before/after source manifests. Reopen it before proceeding.

### 11.3 Finite discriminating controls

At minimum, cover:

- both legal layouts through complete and stopped handbacks;
- illegal 1-, 4-, duplicate-, inserted-, omitted-, and reordered observation/member forms;
- rank/order substitutions in both 13- and 14-member safe-basis witnesses;
- fixed-index mutants or equivalent causal controls showing the two-observation path would fail if any required consumer remained fixed at the 14-member offsets;
- process failure versus clean invalid evidence versus cleanup unresolved;
- invalid evidence at both checker stages in both legal layouts;
- internal/programming exception not relabelled as input invalid;
- exact reached-prefix and child-count validation for C1 admission/readback/commit failures across both layouts;
- same-capsule/different-policy and crossed A-to-B donor controls remain rejected;
- original-run safe-basis/command donor substitution with all dependent digests recomputed;
- no target rows on association refusal;
- receipt-first replay and uncertain-commit recovery remain unchanged;
- no raw private supply, paths, handles, PIDs, stdout, or credentials added to SQL.

Do not claim a predicate was exercised when an earlier predicate masked it. Record the reached assertion for every discriminating control.

---

## 12. Validation

All execution must use authenticated, task-owned external source copies assembled from the final bytes. Do not import or test the live checkout. Use the installed Python/pytest environment already used by the F1 package; install nothing.

### 12.1 Focused final selection

Freeze and execute one deduplicated focused selector containing all changed-source causal tests, status/identity tests, native Section 41/C1 integration tests, and the F1 preservation guard:

```text
tests/test_rw0_d2_offline_integration.py
tests/test_rw0_d2_model_handback.py
tests/test_rw0_d2_evidence_children.py
tests/test_rw0_d2_process_frames.py
tests/test_rw0_d2_c1_checked_readback.py
tests/test_rw0_d2_post_execution_admission_integration.py
tests/test_section41_post_execution_proposal_contracts.py
tests/test_section41_private_atomic_post_execution_proposal.py
tests/test_section41_post_execution_proposal_recovery.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
tests/test_c2b0_durable_state_contract.py
tests/test_post_execution_pure_owner_boundaries.py
tests/test_post_execution_pure_owner_vectors.py
tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
tests/test_sqlite_writer_hot_journal_recovery.py
```

Add an existing test module only when a changed production/document path has a demonstrated direct consumer not represented above. Record that dependency before execution. Do not use an unreviewed wildcard for the focused set.

Run collection and execution once each on the final focused source. Retain exact node IDs and JUnit.

### 12.2 Selector-free final gate

After all source and documentation bytes are final:

1. build a fresh authenticated external copy;
2. run one selector-free collection;
3. run one selector-free FULL execution;
4. require exact equality between collected unique IDs and executed JUnit IDs;
5. require zero failures, errors, and skips;
6. classify warnings without suppressing them;
7. verify source bytes/modes unchanged after each run.

The current 9,232-pass result is historical evidence for tree `93af…`; it is not the expected count and does not validate changed bytes.

Any failed, interrupted, rescued, partial, or earlier-source run remains evidence under its own source identity and receives no final credit.

### 12.3 F1 preservation

Before and after final validation, compare all fourteen frozen F1 paths to Input A. The complete hot-journal module must pass in the focused selection or separately on the same final source. Unit 2 must not change the F1 behavior or evidence identity.

---

## 13. Provenance and review package

Use the **unedited frozen v3 collector** retained in Input A. The thirteen-created-path inventory remains exact because this mandate authorizes no new repository file.

At closeout:

1. remove only task-owned generated state after safe evidence retention;
2. run two fresh final v3 captures and require byte-identical canonical outputs;
3. perform one post-cleanup capture and require equality with the final pair;
4. preserve complete diagnostic-ref inventories/deltas as sidecars;
5. require source, semantic/raw index, configuration, authoritative refs, branch, HEAD, upstream, modes, and cumulative diff to match the prospective interval;
6. retain the exact collector source/freeze and commands.

Produce one reopened, manifest-verified review ZIP containing:

- this mandate and opening authentication;
- the complete final 299-file source subject;
- exact final source manifest and reconstructed Git tree;
- exact Unit 2 delta from tree `93afef8750e062d80626a5a37adfa27766305b7c`;
- cumulative delta from original candidate tree `17ee7db2925ed03ebc1614880fba5ec83d102d8c`;
- proof that the fourteen F1 paths equal Input A;
- the pre-edit 14-member compatibility vector and final equality result;
- the saved/reopened first substantive checkpoint;
- finite case/control register with reached assertions;
- focused and FULL commands, environments, logs, JUnit, ID inventories, and source bindings;
- final/post-cleanup provenance records and diagnostic-ref sidecars;
- bounded cleanup record;
- implementation report with explicit nonclaims.

Report the ZIP size and SHA-256 only after full reopen and member verification.

---

## 14. Stop conditions

Stop without staging or publication if any of these occurs:

- opening identity/provenance mismatch;
- need to change a frozen F1 path;
- need for a new repository path;
- need to change a migration, physical schema, application generation, V22, C1 rank-15 ownership, transaction A/B ownership, public/package surface, D1 Wire grammar, or process supervisor;
- inability to preserve the existing three-observation command/safe-basis bytes;
- inability to keep child-input conversion narrower than a blanket exception catch;
- inability to enforce original-run equality at the fresh write boundary before target writes;
- target rows appear after the donor-association refusal;
- a required causal control is masked and no bounded direct control can reach it;
- focused or FULL final validation fails, skips, is interrupted, or lacks exact ID reconciliation;
- final source/provenance differs after validation or cleanup;
- unexplained authoritative ref, raw index, configuration, branch, HEAD, upstream, source, or mode change.

Return an exact blocked disposition, retain all completed evidence under its actual source identity, identify unperformed coverage, and do not weaken the requirement to claim completion.

---

## 15. Required final report

Return one of:

```text
POST_D2_UNIT2_IMPLEMENTED_VALIDATED_PENDING_REVIEW
POST_D2_UNIT2_BLOCKED
```

The report must include:

- opening and final identities;
- exact touched files and why;
- exact 13/14 layout contract and resolver location;
- typed invalid-evidence reason behavior and exception boundary;
- original-run command/safe-basis equality gate and donor control;
- pre-edit versus final 14-member compatibility vector;
- first checkpoint identity and results;
- focused and FULL collection/execution counts, exact ID reconciliation, warnings, failures/skips/interruption status;
- exact F1 preservation result;
- v3 provenance identities and historical-limit disclosure;
- assumptions and uninspected areas;
- remaining F2/F3/F6/F7, independent-audit, and product-boundary holds;
- review ZIP path, size, and SHA-256.

End with these truthful effect records:

```text
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
MERGE_NOT_PERFORMED
PUBLICATION_NOT_PERFORMED
```
