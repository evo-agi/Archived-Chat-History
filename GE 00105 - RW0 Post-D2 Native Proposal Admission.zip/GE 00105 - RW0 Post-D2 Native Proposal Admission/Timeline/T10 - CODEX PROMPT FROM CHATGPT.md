# Post-D2 native proposal admission — operative independent audit mandate

## Assignment, authorization and continuation status

Continue in the SAME independent Codex audit conversation; keep the implementation writer and all other repository writers idle. This is an authorized defensive correctness, privacy and transaction-safety audit of the user's local Governed Execution Coordinator candidate, not an implementation task or a test against live systems.

The ChatGPT planning conversation issuing this mandate replaced Chat 00077 after its length limit; its history was transferred in an archive. Do not depend on access to that chat, cross-chat memory, or an implementation conversation. Use the exact inputs below and observed records in this independent-audit conversation.

The user reports that submission of T8 was rejected with “Some cybersecurity requests are still limited, even when Daybreak is on.” That is platform/submission status, not an audit verdict. Do not credit T8 provenance qualification, source review, connected proof or FULL execution merely because they were requested. Inspect any actual visible tool records, retain authenticated partial work and distinguish completed, attempted, not performed and unknown actions. Do not assume either zero execution or completion. Both earlier AUDIT_PROVENANCE_MISMATCH results remain unchanged.

This mandate replaces the operative instructions of T8 and earlier audit handoffs. Changes are instruction consolidation, exact-reference incorporation and explicit platform-interruption reporting only. T8's candidate-specific protected-state/diagnostic-ref method, existing v2 binding, substantive coverage and acceptance standard are retained; no new evidence framework or candidate version is introduced. The complete sections incorporated below remain mandatory, not optional background. A shorter instruction does not reduce the required evidence.

Repository, inspection only:
  /Users/ds/Repositories/Governed Execution Coordinator/

Authorized: safe source/Git-metadata and named-artifact reads; external audit records and independently authored helpers; authenticated, isolated external candidate copies; new synthetic databases, fake child processes and the existing process/fork tests; bounded defensive fault controls in separately identified disposable variants. The only live-repository operations are read-only inspection/provenance collection. No repository import, test, candidate execution or live writer acquisition.

Prohibited: live-repository mutation (source, index, refs or config), branch switching, candidate repair, staging, commit, fetch, push, PR, merge, installation, network calls, other repositories, live targets/databases/credentials, provider/Codex/ES/Bridge services, custody suppliers or product effects. The accepted archive and clean validation-source bytes also remain unchanged; only separately labelled diagnostic variants may contain the explicitly permitted test mutations. Do not execute retained implementation, validation, checkpoint or cleanup drivers. Inspect the exact provenance collector before its limited read-only use. Do not conceal the audit's purpose, evade a provider restriction, or replace refused work with weaker evidence represented as complete.

## 1. Authentication and scoped provenance

### Exact inputs and incorporation

The following directory aliases are notation for exact local paths, not assumed shell variables:
  C = /Users/ds/Downloads/Coordinator_PostD2_Final_ftssNh
  B = /Users/ds/Downloads/RW0_D2_PR15_Squash_Integration_q_bbr1om
  H1 = /Users/ds/Downloads/PostD2_Independent_Audit_zz2oxohm
  H2 = /Users/ds/Downloads/PostD2_Independent_Audit_Reentry_QbmMJiCo

Authenticate these files by byte length and full SHA-256:

C/ReviewPackage.zip
  14481457; d9b4d61e212893b48ba1952c3b5370c09874ca2e70798decc36bc4fdbd893d9b
C/IMPLEMENTATION_REPORT.md
  19394; 3099b026881bab6a7bfc05fa2c6230cf9e9d331d8f72b608e3aa52c94d41e4a6
B/RW0_D2_PR15_Source_Checkpoint.zip
  3227944; af5ee227cb9d42e15d0043423852712ef0e058dcd2538ebc117610db61fc6878
H1/IndependentAuditFinal.zip
  18254601; 4c6620c812b3d206d78b4c6148580598a242d4ee2ff464335bd29a8608dfebf7
H1/audit_report.md
  8456; eed8630ea6e0a4591d4846fac7d30bc1d86a937622b0a636e81d2000127c6e72
H1/audit_result.json
  666; 67605d033f688ffcb791efa3bc8b03a4c5d649c9dcb055889b826ae98fe85c1f
H2/ReentryAuditStopFinal.zip
  36453398; 867e157dee5354e30c6e189639124c333acab92d8fc6d9f5650c509848f2832c
H2/audit_report.md
  6511; 229c020eaf75446893174dc17752d56644def6e9b0d027acb8eccb551b6d347f
H2/audit_result.json
  884; 0a854de9db9ab9be50b3c7a05cb4b358ba83816c6d5a5f16ea1c91f0d1a35ce4

M = Coordinator_Post_D2_Native_Proposal_Admission_Independent_Audit_Prompt.txt
  51045; 2aeee22cc25d0dd77c7177afb38360d31f46068297e24164b626c39f3d03299e
Read its exact retained attachment in THIS audit conversation, or a byte-identical copy identified through the named packages' manifests/visible attachment locations. Do not assume an unverified local pathname or another chat. Required M sections:
  §1: all original candidate/input identities, including historical checkpoints;
  §§3–4: ownership, permissions within this ceiling, and the frozen contract;
  §5: COMPLETE A01–A12 register;
  §6: connected positive and complete bounded discriminating-control obligations;
  §7: retained-evidence reconciliation and independent collection/FULL requirements;
  §9 and Appendices A–B: immutable migrations, all 69 changed paths, and mandatory FULL modules.
M §§0, 2 and 8 are superseded by this mandate. In incorporated sections, “provenance matches” means the scoped rule below, not equality with an old total-ref manifest. Read those sections in full; do not replace their predicates with the navigation summaries below. Their content is unchanged from T8. The bytes from M's “## 3.” through just before “## 8.” hash to ac2a9bd5f6668fa8bef50da0974152e35c3937f7563a15441cb37840e050443c.

Also authenticate and read the selected implementation contract, retained under C/ReviewPackage.zip inputs/:
  Coordinator_Post_D2_Native_Proposal_Admission_Implementation_Prompt.txt
  52775; d59d9d0fbb71f44ed2e99ef49f27b903e39cad6d52cd134ba07da2404b7c8434
Locate its exact member by manifest and bytes, not a guessed basename. Its implementation permissions are NOT audit permissions. Its corrections govern over the background recommendation (46961 bytes; 50a059f55fcd4c494ef0c6fea1e0c5b9863ec1b99a76fd02d0e1a624c4465699), available under the same authenticated inputs or the exact location in M §1.

Load these materials yourself; the user need not assemble prompt fragments. Identical copies in supplied locations are acceptable; regenerated inputs are not. If a mandatory input is unavailable or fails authentication, retain what is established and report the exact limitation without reconstructing it from memory or scanning unrelated private state.

### Fixed candidate and preservation

Authenticate safe unique ZIP members, bounded decompression and complete manifest coverage before extraction. Preserve all predecessor bytes. Reconcile the 286-file baseline, all 57 modified before/after pairs, 12 creations, 229 unchanged files and complete 298-file candidate by raw size/hash, Git blob/mode and OS mode. Preserve the known OS-0600/Git-100644 test distinction. Reconstruct the trees without repository object/index writes. Prior patch replay may carry forward only after its exact inputs/results authenticate; no correctness credit follows from replay alone.

Fixed source anchors:
  branch: codex/post-d2-native-proposal-admission-v1; upstream: absent
  HEAD: eac7f6df5f281138dd0640c5cd47b9924c8390f8
  sole parent: 43ae26b9bccf9ad6ce61ec4722e14ac7b460ab18
  baseline/HEAD tree: 061c43c41228310134a30f3b79291bba3e44f3f2
  candidate tree: 17ee7db2925ed03ebc1614880fba5ec83d102d8c (not a commit)
  local trunk_dev and origin/trunk_dev: the fixed HEAD
  local/remote-tracking D2 topic: f035d3f2767b3bd523d6c69083ea0ccb25048239
  preserved original implementation commit: 59621aa041a409c6ead27b74ffe25598c159e78e
  index: 286 stage-zero baseline entries; no staged/conflicted entries;
    32314 bytes; 7bd47e04c4dd62d43b33d2e01fa39df585b9df04f6cf809789e35dab36429a20
  tracked diff: 148261 bytes; 22165ebc894ae732fb17a0d1c0cbc034d985a7dfedab224a4968c08a9489216e
  original writer manifests: 108510 bytes each;
    b66a42d5f4b4e87b06ec0fcf1fbf184cbbb957d7223a3e50f32c976dbd63ceed
  unchanged provenance/provenance_collector.py:
    b61b4a4e949e564e206e6d195791f56585c437d4130c86731e5b4be713c5da7a
  ambient config representation: 2380 bytes;
    ed8e13f607961de69cd849a000fec3045fe7a7954572f3c468d21263532eab0e

Read applicable AGENTS.md/nested guidance first. Record a real filesystem/index opening before ordinary Git observations and disclose actual earlier commands and unobserved intervals; an ordinary disclosed read-only preliminary read alone is not a veto. Unknown effects, source drift or competing mutation are not excused. Use safe read-only Git forms with optional locks, fsmonitor, untracked cache, external diff/textconv and replacement-object interpretation disabled as applicable. Preserve protected symbolic and worktree routing, not just resolved OIDs. Do not refresh the index or inspect ignored caches/private state.

Inspect and retain the unchanged v1 collector, then run it twice to new owned external outputs using the actual ambient Git-config resolution, not the test-copy env -i. Do not dump environment/config or manipulate their inputs to obtain a hash. If its inspected CLI cannot safely direct output externally, the previously permitted exact independently authored v1 computation may be used with its derivation retained; no approximation or dropped fields. All fresh manifests must have the original complete field set and match EVERY non-ref value. Repeat source/index/config/anchor/protected checks before candidate execution and after cleanup.

### Candidate-specific ref distinction — retain T8's method

Recover complete R1 and R2 inventories from H1/H2 and authenticate their original serialization against their retained manifests. Verify the exact two additions/one removal in H2/audit_report.md and unchanged shared-name OIDs; retain names and OIDs, not net counts. The writer-to-R1 transition remains unresolved unless an actually retained complete inventory reproduces its original hash. Neither actor nor cause is established. Today's 54-record count does not recreate the writer's 54-record set. No fixed live total-ref count is required.

An observation-only Q record must satisfy ALL of:
  • Full ASCII name exactly matches one of:
    refs/codex/turn-diffs/captures/<13 decimal digits>/<UUID>/base
    refs/codex/turn-diffs/checkpoints/<32 lowercase hex>/<32 lowercase hex>/<13 decimal digits>/<UUID>
    UUID means lowercase hexadecimal 8-4-4-4-12 groups; no extra segments.
  • OID equals candidate TREE 17ee7db2925ed03ebc1614880fba5ec83d102d8c. Verify present object type without replacements/writes. Absent historical storage facts remain unknown.
  • Present records are direct, not symbolic; no protected symbolic/routing/config/source/test/validation/recovery/admission/publication or governing-policy dependency selects through them. Inspect actual candidate/config/launcher dependencies and cite scope; a namespace alone proves nothing.
  • Source/test copies are selected exclusively from the authenticated archive and fixed identities, never Q or copied live Git state.

Everything else is protected by default. Qualify R1/R2 independently, require their protected maps to be equal and derive P0 from them, NOT from the next live opening. Names in P0 cannot later be reclassified to absorb drift. Require every current protected map to equal P0 and protected symbolic/routing facts to remain opening-exact. New qualifying Q names may appear/disappear; changed-to-wrong-OID, symbolic, unknown or source-dependent records do not qualify. Never create, restore, delete or freeze refs or disable tooling to obtain equality.

Retain complete inventories, raw v1 outputs and exact Q/protected deltas at observed times. Pair aggregates with their actual record sets; label unmatched observations rather than inventing contents or spinning for an old hash. A further bounded read may resolve pairing. Full manifests that differ must never be called equal. Qualified Q variation alone is not a blocker; protected/source/index/config mismatch or unresolved qualification is.

Use the EXISTING T8 binding, not a new framework:
  schema_id = governed-execution.post-d2-native-proposal-admission.audit-binding.v2
  diagnostic_policy_id = governed-execution.post-d2-native-proposal-admission.candidate-tree-turn-diffs.v1
The exact other fields are review_zip_sha256, baseline_zip_sha256, writer_manifest_sha256, collector_source_sha256, audit_mandate_sha256 (this received mandate), candidate_tree, invariant_manifest (EVERY original v1 key/value except top-level refs), and protected_ref_records (complete P0 sorted {name,oid} records, including HEAD when present). Reject ambiguous/duplicate names and any additional normalization. Encode sorted-key compact ensure_ascii=False UTF-8 JSON plus one LF; retain exact bytes, size/hash and derivation helper. No times, Q records, random paths, raw config or self-hash inside this binding.

Construct it once from authenticated immutable inputs/P0 and again after independently verifying corresponding fresh observations; require byte equality. Before candidate execution, inspect/freeze the qualification helper and retain the same data-only controls: actual three-record delta preserves P; source/branch/index/config changes, out-of-shape/wrong-tree refs, protected additions/removals/changes, symbolic dependencies and missing protected/unclassified records cannot disappear. Retain the full observation ledger separately. Save/reopen this opening evidence and continue directly to substantive work in the SAME engagement, without another user handoff.

## 2. Substantive correctness review and permitted local validation

The mandatory detail is M §§3–7, §9 and Appendices A–B, incorporated above. Perform the complete source/contract review, not merely the new modules or author tests. Inspect all 69 changed paths and shared affected behavior, migrations, guidance, configuration, examples and evidence. The selected result is the original D2 run → native Section 41 transaction A → checked A → separate C1 rank-15 transaction B → checked A/B → unchanged V22. A recorded-but-not-admitted proposal is legitimate; no combined transaction, C2 decision/acceptance, live custody or restart claim is permitted.

Keep a complete A01–A12 register with governing/candidate path:line, inspected dataflow, normal/discriminating observations, causal versus structural versus report-only credit, masking/unfinished coverage and disposition. Navigation labels only—the full M §5 requirements remain binding:
  A01 original-run origin and final A-to-B association;
  A02 closed schemas, eight-field safe basis and recursive privacy;
  A03 acyclic digests, known-answer vector and command identity;
  A04 additive 0005 DDL, immutable 0001–0004 and migration compatibility;
  A05 shared controller/session fencing, one commit attempt and cleanup;
  A06 fresh strict currentness versus historical replay;
  A07 complete same-transaction family, bounded readers and occupancy;
  A08 genuine checked SQL tuples/owner associations and unchanged V22;
  A09 separately constructed B, original CAS preimages and stable identities;
  A10 A/B commit uncertainty, complete absence proof and read-only recovery;
  A11 reached-facts matrix, original-process custody and truthful disposal;
  A12 all assurance/document successors, including P09/P11 and caller guards.

Inspect execution dependencies before imports. Copies must contain no live .git, remotes, alternates, hooks, caches, credentials or real databases, and must not hardlink live source. Use newly owned external directories, inspected fake children and new synthetic fixtures only. No network or live target is authorized. Optional bounded subagents may inspect authenticated source only under M §3; parent executes probes serially and owns the report. No nested delegation or independent-perspective claim without actual coverage.

Independently exercise the genuine connected positive and save/reopen its substantive checkpoint before expanding controls. Preserve all M §6 controls: donor/same-capsule substitution at the real consumer; withheld ninth actual insert and overcomplete/foreign reader; narrower strict expiry and valid historical replay; actual before/after commit failures for A/B plus cleanup/readback failure; missing receipt with partial/foreign route including reused evidence set; A-committed/B-CAS refusal; and B-committed/final-projection or disposal failure. Include required outside-span/unauthorized-edge assurance controls. Observe real synthetic rows, attempt counts, reached predicates and cleanup—not unrelated exceptions or count-only assertions. Keep all-nine omission/read-fault coverage in FULL and distinguish overlapping/masked checks. Bounded audit-only variants are diagnostic controls, not candidate repairs; preserve their exact diffs and source binding.

Reconcile the writer's retained validation/final/{validation-receipt.json,node-inventory.json,source-manifest.json,full-collect.txt,full-run.txt,full-junit.xml}, case register, schema/migration records, first connected checkpoint and cleanup evidence as data. Earlier failed/interrupted runs and the reported 9191 passes are not independent validation. Do not execute archived drivers.

After substantive review/probes reveal no blocker, perform ONE independent selector-free collection and ONE FULL execution in a fresh, unmodified authenticated copy. Use M §7's exact runner/environment/argv and conditional sequencing, including:
  /Library/Frameworks/Python.framework/Versions/3.13/bin/python3
  -B -m pytest -q -p no:cacheprovider
  collection: --collect-only --basetemp=<new owned collection path>
  execution: --basetemp=<new owned run path> --junitxml=<owned JUnit path>
There is NO path, -k, -m, ignore/deselect or xdist selector. Retain actual argv/cwd, constructed nonsecret environment, versions, exit codes, complete module/node inventory, logs, JUnit and warnings/errors/skips. Verify installed Python 3.13.4/pytest 8.4.1/SQLite 3.49.1 from a neutral directory; unavailable/materially different runtime stops dependent validation, not source findings. No installs, warning suppression, injected skips/xfails or unreported runtime substitution. Do not apply the test-copy sanitized environment to the ambient-config collector.

All Appendix B modules must be present. Independently reconcile collected IDs, duplicates, executed JUnit identities and producer encoding; 9191 is the report to verify, not a literal to force. Check all 298 endpoints/modes after execution. Preserve failed helper attempts; determine whether any stateful action completed before retrying. Never repeat uncertain fixture commits or relabel production failures as driver mistakes. A genuine material finding may stop broader execution with a reproducer and exact remaining coverage.

## 3. Final findings and acceptance limitations

Keep platform/submission status, historical provenance, present protected-state observations, source findings and execution results separate. If a provider cannot support any required part, do not disguise or bypass the restriction. Preserve completed source-bound findings/records, identify the precise unavailable action and affected A-rows/controls/FULL work, and return INCOMPLETE. Unknown tool completion stays unknown; do not rerun an uncertain stateful action without inspecting its observed effects. No platform refusal is a candidate defect, a passing check or acceptance.

Retain and reopen one safe external audit package: input identities; unchanged historical reports; source/copy manifests; original collector outputs; existing v2 binding/helper/data-controls and complete ref ledger; all A01–A12 findings; connected checkpoint and probe/variant sources; actual causal/structural limits; writer-record reconciliation; independent collection/execution receipts; failures, unperformed work and closing preservation. Reference existing archives by exact identity rather than nesting them again. No real database, private capsule, credential, raw host environment/config, cache or build output. Manifest all deliverable members with explicit self-exclusion; report final ZIP/report/result sizes and SHA-256s. Retain essential evidence before deleting only enumerated NEW audit-owned disposable state. Reap children, distinguish audit rescue from candidate cleanup and repeat final source/index/config/protected observations.

Return ONE primary disposition:
  POST_D2_NATIVE_PROPOSAL_ADMISSION_ACCEPTED_READY_FOR_COMMIT_GATE
  POST_D2_NATIVE_PROPOSAL_ADMISSION_AUDIT_BLOCKED
  POST_D2_NATIVE_PROPOSAL_ADMISSION_AUDIT_INCOMPLETE
  AUDIT_PROVENANCE_MISMATCH

ACCEPTED requires exact original candidate authentication; successful scoped opening AND closing; complete A01–A12 review; decisive connected/discriminating/recovery evidence; reconciled retained evidence; and complete successful independent selector-free collection/FULL execution. Neither a green suite nor matching hashes replace other obligations. Unsupported or unperformed required work precludes acceptance. Material source defects block; actual protected-state/source mismatches retain their own classification. A later mismatch does not erase valid source-bound findings, but withholds gate eligibility.

Report separately: (1) immutable artifact/source identity; (2) both historical mismatches and unresolved writer-to-first-auditor gap; (3) current protected-state binding and every qualified ref delta; (4) actual independent review/validation coverage; (5) bounded implementation correctness. Preserve actor/cause uncertainty, unobserved intervals and all masking/coverage limits. Historical mismatch verdicts are not cured; qualified Q changes and the already disclosed historical gap alone are not vetoes under the retained scoped rule.

Acceptance applies only to these exact bytes under the stated evidence criterion and permits consideration of a SEPARATE commit gate. It authorizes no staging, commit, publication, live authority, physical C2 acceptance or product effect. Provide severity/type/path:line findings, exact performed commands/results and omissions, final identities and separate provenance, validation and implementation confidence. Complete the supported audit in this one engagement; do not return another reconnaissance, implementation repair or provenance-only success handoff.
