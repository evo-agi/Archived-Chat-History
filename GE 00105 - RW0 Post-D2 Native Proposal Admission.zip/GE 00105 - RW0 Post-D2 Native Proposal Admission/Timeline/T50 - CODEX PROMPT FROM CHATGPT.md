# Coordinator post-D2 F01 currentness/read-failure classification repair

## Recipient and effect ceiling

Use the same write-enabled Codex implementation conversation that produced the
post-D2/F1/Unit 2 candidate. The independent auditor remains idle.

This engagement authorizes one bounded repair and validation package. Do not
stage, commit, push, create a PR, merge, publish, contact a network/live target,
open a user database, or implement any other finding.

## Fixed subjects and required inputs

Repository:
`/Users/ds/Repositories/Governed Execution Coordinator/`

Expected branch/HEAD posture:
- branch `codex/post-d2-native-proposal-admission-v1`
- HEAD `eac7f6df5f281138dd0640c5cd47b9924c8390f8`
- no upstream

Exact current review subject:
- source tree `8633f700647bcdd19451a6840295a527940e7a3b`
- `/Users/ds/Downloads/Coordinator_Unit2_TypedChildRepair_20261024/PostD2Unit2TypedChildRepairReviewPackage.zip`
- 5,912,014 bytes
- SHA-256 `a019b8afca2f71efb1400c7b83d9710b5379a74975f3748981d2e31059e248cd`

Independent blocked audit:
- `/Users/ds/Downloads/PostD2_IndependentAudit_20261024_a019b8af/AUDIT_REPORT.md`
- `/Users/ds/Downloads/PostD2_IndependentAudit_20261024_a019b8af/AUDIT_EVIDENCE.zip`
- disposition `POST_D2_CUMULATIVE_CANDIDATE_AUDIT_BLOCKED`

Exact F1 historical linkage input:
- `/Users/ds/Downloads/Coordinator_F1_Classification_eSUxoG/F1ClassificationRepairReviewFinal.zip`
- 7,406,558 bytes
- SHA-256 `9cb40710e2a6d2c4d13fb79196885d12d5f52ea1e7f5f7f50ebf1b48f24085b3`
- source tree `93afef8750e062d80626a5a37adfa27766305b7c`

Authenticate all required inputs and the live source before editing. Stop if the
live 299-file source is not exact tree `8633f700647bcdd19451a6840295a527940e7a3b`, if an unrelated source change is
present, or if the fixed packages do not match.

Historical raw-index/ref gaps remain disclosed. Establish a new prospective
interval using the existing frozen-v3 authoritative-ref/diagnostic-ref policy;
do not reset, restore, delete, or silently reclassify historical state.

## Objective

Repair audit finding F01 only:

On a fresh Section 41 proposal receipt miss, a fenced current-owner read or
integrity failure must remain a safe `SQLiteMutationStoreError` (normally
`database_integrity_failure`). It must not be returned as the ordinary
`PostExecutionProposalConflictV1("currentness_conflict")` used for actual stale
heads, stop/currentness mismatch, or expiry/temporal conflict.

The write must continue to fail closed before route probing or target writes.

## Required semantics

In
`src/ge_nwp_coordinator/_sqlite_section41_post_execution_proposal.py`, narrow
the fresh-currentness boundary at `write_fresh_after_fencing`:

1. The actual fenced owner read
   `_read_rw0_d2_current_owner_snapshot_after_fencing(...)` is not inside a
   broad conflict-conversion catch. A `SQLiteMutationStoreError` from that read
   propagates through the existing controller/session safe-error path.
2. `RW0D2BInputConflict` from `require_current_d2_basis(...)` remains the finite
   ordinary `currentness_conflict` result.
3. The retained global-stop timestamp mismatch and the three explicit
   historical-time comparisons remain `currentness_conflict`.
4. Unexpected validation, mapping, or programming failures must not be silently
   demoted to currentness. They must reach the existing safe integrity-failure
   boundary. Do not add a blanket `except Exception` elsewhere.
5. `KeyboardInterrupt`, `SystemExit`, and `GeneratorExit` remain unsuppressed.
6. A failed owner read reaches no route probe, insert, receipt construction, or
   COMMIT attempt and leaves all five A target counts zero.
7. Existing changed-head and strict-expiry behavior remains byte/semantically
   compatible: those cases return `currentness_conflict`, not an exception.

Prefer the existing `RW0D2BInputConflict` vocabulary over a new public error or
result type. Do not change `sqlite_errors.py`, schemas, migration 0005, the
transaction controller, writer session, D2/Unit 2/F1 code, or V22.

## Authorized repository scope

Expected and preferred changed paths:
- `src/ge_nwp_coordinator/_sqlite_section41_post_execution_proposal.py`
- `tests/test_section41_private_atomic_post_execution_proposal.py`

No new repository path is authorized. Do not edit documentation unless a real
source contradiction makes the existing owner contract insufficient; stop and
report that contradiction rather than widening scope automatically.

F03 (the transient result constructor timestamp observation) is explicitly out
of scope.

## Required causal regression

Add a test in the existing Section 41 atomic proposal module that uses a real
D2 run and fresh command/basis, injects a failure at the actual owner-reader
seam (prefer an underlying SELECT/read helper fault that the real owner reader
normalizes), and proves:

- the outward result is `SQLiteMutationStoreError` with
  `database_integrity_failure`, not `PostExecutionProposalConflictV1`;
- the route probe and insert path are not reached;
- no commit attempt occurs;
- target counts are `[0, 0, 0, 0, 0]` and recovery remains a proven noncommit
  where the existing contract permits that classification;
- process-control behavior is unchanged.

Retain and rerun the existing genuine changed-head and expiry controls so the
repair does not convert ordinary currentness conflict into integrity failure.
Do not satisfy the regression by testing only a detached helper or by changing
assertions to accept the old false reason.

## F1 linkage evidence obligation (no source change)

The blocked audit could prove only immediate-predecessor equality because the
F1 payload was not supplied. Using the exact F1 ZIP above:

1. authenticate its package manifest and 299-file F1 source tree
   `93afef8750e062d80626a5a37adfa27766305b7c`;
2. compare the fourteen paths named by the current
   `evidence/f1-frozen-path-preservation.json` against the F1 package's
   `source/` payloads by raw bytes and numeric mode;
3. require all fourteen exact;
4. retain a deterministic `f1-base-linkage.json` containing the two package
   identities, F1 tree, successor tree, all fourteen path/size/hash/mode rows,
   and the comparison method;
5. include that sidecar in the final review package and report that the future
   auditor must also receive the exact F1 package (or exact equivalent
   historical payloads). Do not claim this retroactively changes the blocked
   audit verdict.

## Checkpoint and validation

Before the broad run, save and reopen one source-bound checkpoint containing:
- the new owner-read failure regression;
- genuine changed-head conflict;
- strict expiry before/at/after controls;
- one actual D2 → Section 41 A → C1 B → V22 positive;
- unchanged F1 hot-journal classification coverage;
- exact source before/after identity.

Then run, from authenticated isolated external copies only:

1. direct affected modules, including the Section 41 atomic proposal module;
2. the existing post-D2 focused selector plus the new regression;
3. the connected positive/control selection;
4. one selector-free collection and one selector-free FULL execution.

Do not use the live checkout for imports/tests. Disable plugin autoload,
bytecode and pytest cache writes as in the prior gates. Reconcile collected,
executed and JUnit node-ID sets exactly; report actual counts rather than
assuming 9,291. Preserve unsuppressed warnings and source before/after records.
A stopped or partial FULL is not a pass.

## Provenance and packaging

Use the existing frozen-v3 collector and current authoritative-ref versus
qualified-diagnostic-ref policy without changing its source or recipe ID.
Run the final capture twice and once after bounded cleanup; require byte equality
for the final source/diff/protected-state fields. Preserve complete diagnostic
inventories as sidecars and retain historical gaps as limits.

Return one reopened review package containing:
- complete final 299-file source;
- exact two-file delta from tree `8633f700647bcdd19451a6840295a527940e7a3b`;
- implementation report;
- source-bound checkpoint;
- direct/focused/connected/FULL collection and execution evidence;
- F1 linkage sidecar;
- final provenance captures, cleanup record, and all failed/interrupted attempts.

Report the new Git-compatible source tree. No independent audit is performed by
this engagement.

## Stop conditions

Stop without source mutation if opening authentication fails. After editing,
stop with a blocked/incomplete result if:
- the repair requires a schema, migration, public API, transaction-controller,
  F1, D2 layout, or additional error-vocabulary change;
- a currentness conflict can no longer be distinguished from an owner-read
  failure;
- any target row or commit attempt occurs after the injected read failure;
- F1 linkage does not reproduce all fourteen exact rows;
- final source identity or protected state is unstable;
- selector-free collection or FULL execution cannot complete successfully.

## Required final disposition

Use exactly one:
- `POST_D2_F01_CURRENTNESS_CLASSIFICATION_REPAIR_IMPLEMENTED_VALIDATED_PENDING_REVIEW`
- `POST_D2_F01_CURRENTNESS_CLASSIFICATION_REPAIR_BLOCKED`
- `POST_D2_F01_CURRENTNESS_CLASSIFICATION_REPAIR_INCOMPLETE`

State explicitly:
`INDEPENDENT_AUDIT_NOT_PERFORMED`
`STAGING_NOT_PERFORMED`
`COMMIT_NOT_PERFORMED`
`PUSH_NOT_PERFORMED`
`PR_NOT_CREATED`
`MERGE_NOT_PERFORMED`
`PUBLICATION_NOT_PERFORMED`
