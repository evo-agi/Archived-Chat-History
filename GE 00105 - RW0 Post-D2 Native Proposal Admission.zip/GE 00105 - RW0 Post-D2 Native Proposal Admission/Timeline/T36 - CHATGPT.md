**The continuation stopped correctly under the previous mandate, but the blocking classification was too broad. This is a handoff defect—not candidate drift or an F1 implementation finding.**

The retained inventories show a clean split:

- The same **32 non-turn-diff refs** are byte-for-byte identical across the first provenance stop, the second stop, the prior F1 closeout, and this latest opening.
- All observed churn is under the exact `refs/codex/turn-diffs/captures/**` or `refs/codex/turn-diffs/checkpoints/**` namespaces.
- The missing ref is one of those checkpoint refs. It had been classified as protected only because its target was not one of three selected candidate trees.
- Source, semantic index, configuration, HEAD, branch, baseline anchors, and the 299-file refusal-only tree still authenticated. The raw index was stable across the opening reads and matched the prior F1 terminal value. No source edit or test occurred. IMPLEMENTATION_REPORT

That target-dependent rule was the mistake. Turn-diff refs are platform diagnostic/checkpoint evidence; their target does not become repository authority merely because it is an older tree. An earlier accepted D2 audit already treated the exact capture/checkpoint subtrees as diagnostic after finding no source, guidance, configuration, or executable-selection dependency on them. Pasted text

## Next handoff

Send this **single prompt** to the **same F1 implementation Codex conversation**, with write permission:

:chatgpt-content-reference{index="3"}[**Coordinator_F1_Recovery_Dependency_Continuation_v2_Prompt.txt**](sandbox:/mnt/data/Coordinator_F1_Recovery_Dependency_Continuation_v2_Prompt.txt)

Do not send the prior continuation prompt alongside it.

The replacement makes these explicit changes:

- It freezes the exact **32-record authoritative ref map**, with canonical SHA-256:

  ```text
  eaee93514b861f8dcf1d949c426acd164debfd01f9f6b1317b432a20b9b8b09e
  ```

- It classifies refs by the two exact turn-diff name grammars—not by whether their target happens to equal the candidate, failed attempt, or refusal-only tree.
- Qualified diagnostic additions and removals are retained but do not force another user round trip. Diagnostic retargeting, an invalid name, a symbolic ref, a non-tree current target, or any change outside those namespaces still blocks.
- It does **not** restore or delete the missing ref, identify its actor, call its disappearance harmless, or retroactively validate the earlier interval.
- It introduces a narrowly versioned **external collector v3**. The canonical source binding contains the fixed authoritative-ref map and diagnostic-policy result; complete diagnostic inventories remain separate sidecars. This prevents volatile platform checkpoint counts from repeatedly invalidating otherwise identical source provenance.
- All substantive F1 obligations remain unchanged: the corrected recovery-dependency contract, R1–R7, early checkpoint, healthy-path compatibility, final selector-free collection and FULL execution, exact successor source, and no staging or publication.

The historical opening stop remains a valid record under its former rule. The original candidate and refusal-only source remain unaccepted; F4, malformed-input F5, `NPA-WITNESS-01`, the unfinished independent audit, and the other holds remain open.

**Sources:** latest blocked opening report; prior accepted D2 audit; project provenance guidance that deterministic canonical records should avoid volatile metadata and that provenance must remain separate from correctness. Governed Execution Provenance G…

**Confidence:** **0.99** in the artifact diagnosis and ref-map comparison; **0.96** in the corrected continuation policy. F1 implementation correctness remains unestablished.
