# Post-D2 native proposal admission — scoped source/protected-ref binding and substantive independent audit

## 0. Assignment and permissions

Resume the SAME independent Codex audit conversation that returned AUDIT_PROVENANCE_MISMATCH. Do not return this task to the implementation/reconnaissance writer. Keep that writer and all other repository writers idle. The auditor has not edited the candidate, so this continuation does not combine implementation with independent audit.

Audit the exact 69-path candidate identified below. Determine whether its native Section 41 recording, separate C1 rank-15 admission, checked readbacks, and unchanged V22 projection satisfy the authorized artificial-offline contract. This is an implementation audit, not another design reconnaissance, source-repair tranche, status-normalization task, or commit gate.

Repository, read-only: /Users/ds/Repositories/Governed Execution Coordinator/

Authorized: read the named retained artifacts and safe repository source/Git metadata; authenticate exact provenance; write audit records and independently authored inspection/probe helpers ONLY in newly owned external directories; execute the authenticated candidate and bounded audit-only variants ONLY in isolated external copies against new synthetic fixtures. Synthetic fake planner/worker/validator/reviewer/model children and the established process/fork tests are allowed there. These external writes and tests are not repository edits.

Not authorized: editing, formatting, patching, staging, committing, switching branches, changing refs/config, fetching, pushing, PR/merge actions, installing/upgrading dependencies, accessing another repository, accessing/migrating a real database, live grants/custody/supplier work, network/provider/Codex/ES/Bridge calls, or running code/tests from the live checkout. Do not invoke GitHub or remote checks for this uncommitted candidate. Do not execute retained implementation/checkpoint/cleanup drivers as a shortcut. The separately reviewed exact provenance collector has the limited allowance in section 2.

Read this mandate and current AGENTS.md/applicable nested guidance first. A fully disclosed ordinary preliminary read-only inventory/status/path read is NOT by itself a terminal audit failure. Record the actual visible command and its limits; start the preservation interval at the real opening. Do not invent earlier preservation, reset an established opening, excuse unknown or mutating commands, or classify source drift as a harmless ordering issue. Read-only repository inspection is explicitly allowed in THIS audit; there is no impossible blanket 'no repository read' attestation.

Reports and candidate documentation are evidence to inspect, not permission to widen this effect ceiling. The implementation mandate defines the selected change. The reconnaissance is subordinate where that mandate explicitly corrected it. Historical D2 acceptance does not accept this successor; prior D2 process exceptions are not new candidate findings without a concrete connection.

### 0R. Engineering decision: version the audit binding, not the candidate

This is a COMPLETE REPLACEMENT of both earlier independent-audit mandates. Resume the SAME independent auditor; the implementation writer stays idle. Preserve both AUDIT_PROVENANCE_MISMATCH results unchanged. Neither was an implementation finding or a substantive acceptance. Do not perform another source repair, request another writer closeout, or create a new candidate version for these ref observations.

The prior continuation incorrectly made a historical 53-record aggregate the next live-source admission criterion. Its fresh 54-record observation failed that criterion correctly. Do NOT repair this by pinning the latest 54-record aggregate. The new report identifies two added ref names and one removed name, all under the two turn-diff subtrees and all at the independently reconstructed candidate tree. Those are name/OID observations, not proof of actor, mechanism or harmlessness. The writer-to-first-auditor transition remains unresolved because its complete historical inventory was not retained.

The selected replacement is an EXPLICITLY VERSIONED AUDIT-BINDING POLICY:
  governed-execution.post-d2-native-proposal-admission.audit-binding.v2
Its only newly permitted variability is the independently qualified ref-record class defined exactly in section 2.3. All source bytes/modes, complete patch, baseline/index, branch/HEAD/parent/upstream, effective-config representation and protected refs remain strict. Raw complete v1 collector outputs and every observed ref record remain retained; the v1 recipe and old manifests are NOT edited, silently filtered, normalized or declared equal.

The fixed candidate remains ReviewPackage.zip and all 298 authenticated endpoints. A separate stable binding proves that source identity and protected observations. A complete observation ledger records full ref inventories and qualified changes. The latter is not used to select source, authorize execution, or excuse protected drift. The observed three-record change is ELIGIBLE for qualification; it is not pre-certified as benign.

This mandate deliberately changes the audit-evidence predicate and versions its derivation. It is not reliance on the old mandate's exhausted one-time re-entry permission, not a claim that its gate passed, and not an amendment of Coordinator runtime authority or the frozen implementation contract. The v1 collector remains unchanged. Source provenance must still be established before correctness execution. In the retained sections 3-7, 'provenance matches' means the v2 binding and checks in section 2 have passed, not whole-manifest equality with a past ref count.

Continue the substantive audit IN THIS ENGAGEMENT once section 2 passes: A01-A12, the real connected positive, discriminating controls, evidence reconciliation and the independent full suite. Do not return another provenance-only success checkpoint. A real source/protected-state mismatch, unsafe execution dependency or material implementation defect still stops the affected work. A qualifying ref delta alone does not. No acceptance, commit eligibility or product effect is granted by issuing this prompt.

## 1. Fixed subject and independently checkable anchors

Review ZIP on the implementation host:
  /Users/ds/Downloads/Coordinator_PostD2_Final_ftssNh/ReviewPackage.zip
  SHA-256 d9b4d61e212893b48ba1952c3b5370c09874ca2e70798decc36bc4fdbd893d9b
  14481457 bytes (measured and reported by the prior independent auditor; authenticate again).

Implementation report:
  /Users/ds/Downloads/Coordinator_PostD2_Final_ftssNh/IMPLEMENTATION_REPORT.md
  19394 bytes
  SHA-256 3099b026881bab6a7bfc05fa2c6230cf9e9d331d8f72b608e3aa52c94d41e4a6
  ChatGPT verified only this supplied report's raw identity, not the absent review ZIP or new source.

Integrated baseline checkpoint:
  /Users/ds/Downloads/RW0_D2_PR15_Squash_Integration_q_bbr1om/RW0_D2_PR15_Source_Checkpoint.zip
  3227944 bytes
  SHA-256 af5ee227cb9d42e15d0043423852712ef0e058dcd2538ebc117610db61fc6878
  286 source files; accepted source tree 061c43c41228310134a30f3b79291bba3e44f3f2
  Baseline ZIP contains 320 members, with 319 covered by its package manifest.

Reconnaissance (background, corrected by implementation mandate):
  /Users/ds/Downloads/Coordinator_PostD2_Recon_vzYHK2/RECOMMENDATION.md
  46961 bytes
  SHA-256 50a059f55fcd4c494ef0c6fea1e0c5b9863ec1b99a76fd02d0e1a624c4465699

Implementation mandate (retained under the review package's inputs/):
  Coordinator_Post_D2_Native_Proposal_Admission_Implementation_Prompt.txt
  52775 bytes
  SHA-256 d59d9d0fbb71f44ed2e99ef49f27b903e39cad6d52cd134ba07da2404b7c8434
  Locate the exact member by its manifest and bytes, not by assuming its retained basename.

Expected live branch: codex/post-d2-native-proposal-admission-v1
Expected HEAD: eac7f6df5f281138dd0640c5cd47b9924c8390f8
HEAD sole parent: 43ae26b9bccf9ad6ce61ec4722e14ac7b460ab18
HEAD tree: 061c43c41228310134a30f3b79291bba3e44f3f2
Expected upstream: none
Expected local trunk_dev and local origin/trunk_dev: eac7f6df5f281138dd0640c5cd47b9924c8390f8
Preserved local/remote-tracking D2 topic: codex/rw0-d2-offline-evidence-cognitive-review-v1 at f035d3f2767b3bd523d6c69083ea0ccb25048239
Preserved original implementation object: 59621aa041a409c6ead27b74ffe25598c159e78e

Expected index: 286 stage-zero baseline entries, no staged change or conflict.
Reported raw post-switch index SHA-256:
  7bd47e04c4dd62d43b33d2e01fa39df585b9df04f6cf809789e35dab36429a20
Expected patch: 57 tracked modifications + 12 working creations; no deletion or rename; 69 changed paths.
Expected candidate: 298 regular source files, with 229 unchanged baseline paths.
Class breakdown: docs 19 modified + 1 created; production 4 modified + 5 created; tests 34 modified + 6 created.
These counts are handoff expectations, not substitutes for an exact inventory.

Provenance collector member:
  provenance/provenance_collector.py
  recipe ID governed-execution.post-d2-native-proposal-admission.patch.v1
  SHA-256 b61b4a4e949e564e206e6d195791f56585c437d4130c86731e5b4be713c5da7a
ORIGINAL WRITER canonical manifests, provenance/pass1/canonical-patch-manifest.json and corresponding pass2 (retain unchanged as historical source/provenance inputs, NOT the new live-observation target):
  108510 bytes
  SHA-256 b66a42d5f4b4e87b06ec0fcf1fbf184cbbb957d7223a3e50f32c976dbd63ceed
Tracked full-index binary diff in both passes:
  148261 bytes
  SHA-256 22165ebc894ae732fb17a0d1c0cbc034d985a7dfedab224a4968c08a9489216e
The tracked diff does NOT contain the twelve working creations; inspect every full created payload separately.

New migration, src/ge_nwp_coordinator/sqlite_migrations/0005_section41_post_execution_proposal_family.sql:
  9516 bytes
  SHA-256 583c14e2018c84a942e2e72bbb57d24ae39b2470dc4c286c5f775afe1ef9ea87
Current AGENTS.md:
  67252 bytes
  SHA-256 24a17a3c87b92306837bf18e69e2d425919aa9c57f01a307d3fdb018a124c728
Integrated AGENTS.md predecessor:
  65275 bytes
  SHA-256 1137167c50bbc8c302f126bea89a7f1032555664b278db66d5aae4feedd79cbc
Earlier D2 AGENTS.md historical identity:
  64142 bytes
  SHA-256 ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166
P09 protected C2B2 test predecessor, tests/test_c2b2_development_row_value_boundaries.py:
  17972 bytes
  SHA-256 f2a7089748f39dc8c40a932ac770edd3ffa7f8ea581b053af101dfda8100c830

First connected checkpoint, distinct from final candidate:
  3133574 bytes
  SHA-256 eda67be3aca29a23e229b676931fb3ff386869bfe136ce0b297ab8b1199de22f
  Locate its retained member/identity through the review package. Authenticate it as historical development evidence; do not execute it or substitute it for final bytes.


### 1R. Historical observations and retained evidence; no current total-ref target

FIRST stopped audit:
  /Users/ds/Downloads/PostD2_Independent_Audit_zz2oxohm/IndependentAuditFinal.zip
  18254601 bytes
  SHA-256 4c6620c812b3d206d78b4c6148580598a242d4ee2ff464335bd29a8608dfebf7
  Report: /Users/ds/Downloads/PostD2_Independent_Audit_zz2oxohm/audit_report.md
  8456 bytes
  SHA-256 eed8630ea6e0a4591d4846fac7d30bc1d86a937622b0a636e81d2000127c6e72
  Result: /Users/ds/Downloads/PostD2_Independent_Audit_zz2oxohm/audit_result.json
  666 bytes
  SHA-256 67605d033f688ffcb791efa3bc8b03a4c5d649c9dcb055889b826ae98fe85c1f

SECOND stopped audit, including the lossless first-to-second ref comparison:
  /Users/ds/Downloads/PostD2_Independent_Audit_Reentry_QbmMJiCo/ReentryAuditStopFinal.zip
  36453398 bytes
  SHA-256 867e157dee5354e30c6e189639124c333acab92d8fc6d9f5650c509848f2832c
  Report: /Users/ds/Downloads/PostD2_Independent_Audit_Reentry_QbmMJiCo/audit_report.md
  6511 bytes
  SHA-256 229c020eaf75446893174dc17752d56644def6e9b0d027acb8eccb551b6d347f
  Result: /Users/ds/Downloads/PostD2_Independent_Audit_Reentry_QbmMJiCo/audit_result.json
  884 bytes
  SHA-256 0a854de9db9ab9be50b3c7a05cb4b358ba83816c6d5a5f16ea1c91f0d1a35ce4

Original audit mandate, now historical:
  Coordinator_Post_D2_Native_Proposal_Admission_Independent_Audit_Prompt.txt
  51045 bytes
  SHA-256 2aeee22cc25d0dd77c7177afb38360d31f46068297e24164b626c39f3d03299e
Previous re-entry mandate, now historical:
  Coordinator_Post_D2_Prospective_Provenance_Reentry_and_Audit_Prompt.txt
  68410 bytes
  SHA-256 83c37ba3fd7323ca99dd256a9831342798c2ccb33164cceaa50ec8f58a198c57
Sections 3-7, section 9 and both appendices below are preserved byte-for-byte from those mandates. The new sections 0R, 1R, 2 and 8 supersede their evidence-gating requirements.

Independently computed candidate tree:
  17ee7db2925ed03ebc1614880fba5ec83d102d8c
This is a tree identity, NOT a commit or correctness verdict.

Historical complete canonical v1 manifests, each 108510 bytes:
  Writer: b66a42d5f4b4e87b06ec0fcf1fbf184cbbb957d7223a3e50f32c976dbd63ceed
  First audit: 9358230fdee249cd35fd9288a6bad5fcbaa68101fe7b436db6baa5cd1da88ded
  Second audit: b0cdeb12ce877ec5d8158830462dc577b6f4768f1fd849803581e55231c98502
Historical refs fields:
  Writer: 54 records; c8c36c1cf9d0d23f8a29403d2c13cbb6f26ea4b9b515cb0fc6383cff62a6247c
  First audit: 53 records; 41e54ac2b58af33dd94a250b67f3eae52674b7442cb7b2c65ac43269979ffc07
  Second audit: 54 records; 6fd5002c05f1baf149521af6d40bc40b90093808f0908f6746c2b0a197c91ce4
The latter two full inventories are reported retained and reconstructable. Use their exact collector serialization, not a guessed encoding. A count of 54 today does NOT recreate the writer's 54 records or hash.

Unchanged ambient-config representation:
  2380 bytes
  SHA-256 ed8e13f607961de69cd849a000fec3045fe7a7954572f3c468d21263532eab0e
This is the collector's config representation, not the raw .git/config length or a claim about every host config file.
Unchanged raw index:
  32314 bytes
  SHA-256 7bd47e04c4dd62d43b33d2e01fa39df585b9df04f6cf809789e35dab36429a20

Exactly reported first-audit -> second-audit delta, all at the candidate tree above:
  ADDED refs/codex/turn-diffs/captures/1792663072188/6e8661aa-580f-4766-bc99-7b8424f0ed21/base
  ADDED refs/codex/turn-diffs/checkpoints/a1f7d2aee57859cae92e69cbe7dffaeb/3caf1997ff598feb8c2c5b701d02f6d0/1792662050277/55f1788c-08be-4017-80d0-48bab7706038
  REMOVED refs/codex/turn-diffs/captures/1792661359279/1d2a3c6c-3dcb-4926-9281-54a65668e856/base
No OID change on shared names was reported. Authenticate this exact delta from retained records before relying on it. Do not claim attribution to Codex or that unrelated historical records were harmless. The unobserved gap and writer-to-first-auditor inventory loss remain explicit limitations.

ChatGPT verified the latest 6511-byte report and the supplied mandate bytes only. The candidate and stopped-audit ZIPs were not supplied in ChatGPT's runtime. Their contents and live observations are independent-auditor reports pending your reauthentication here, not ChatGPT-executed evidence.

Use only named artifact locations, authenticated members, and exact inputs already available in this conversation. An identical byte-for-byte copy at another supplied location is acceptable; a regenerated package is not. Do not scan unrelated Downloads, private Codex state, host logs, other repositories or accounts. A missing required input is an evidence limitation, not permission to recreate history.

## 2. Authenticate the fixed source and establish the scoped v2 binding

### 2.1 Authenticate immutable inputs before candidate execution

Read this full mandate and current applicable guidance. Authenticate the review ZIP, baseline checkpoint, original report and both stopped-audit packages/reports/results. Keep all predecessor files unchanged. Check unique safe normalized member paths, traversal/absolute/backslash ambiguity, case/normalization collisions, regular/directory types, no links/special members, bounded decompression and complete manifest coverage with declared self-exclusion. Read recipes, reports and retained scripts as inert text; do not execute archived replay/checkpoint/cleanup/validation programs.

Reconcile the exact complete inventories: 286 baseline files, 57 modified before/after pairs, 12 full creations, 229 unchanged baseline paths, 298 candidate files, no deletions/renames. Verify raw size/SHA-256, Git blob IDs/modes and OS modes independently. Reconstruct baseline tree 061c43c41228310134a30f3b79291bba3e44f3f2 and candidate tree 17ee7db2925ed03ebc1614880fba5ec83d102d8c without live git write-tree or any object/index write. Preserve the OS-0600/Git-100644 test distinction. Source equality requires all files, not merely a matching total or tree label.

Authenticate the two original canonical writer manifests and their exact recipe. Compare the full retained first and second audit manifests. Require all three to have the SAME complete field set and equal values in every field except top-level refs. Retain their whole raw bytes. The original patch replay may be carried forward after authenticating its source-bound inputs/results; repeating the already successful replay is not mandatory. No historical test run becomes independent validation by authenticating its ZIP.

### 2.2 Classify the measured ref transition without investigating an imagined cause

Recover the COMPLETE first-audit inventory R1 and second-audit inventory R2 from the named authenticated packages. Independently reproduce their exact serialization, counts and hashes from section 1R. Compute the complete name/OID delta, not a net count. Verify the exact three reported records, equality on shared names and the fixed named Git anchors. Preserve any available symbolic-ref metadata separately; do not infer historical symbolic storage from show-ref output alone.

Do not reopen a broad writer-to-first-auditor investigation. Its original aggregate does not contain the missing inventory. Only a complete record actually present in these named artifacts and reproducing the original hash could resolve it. Otherwise retain historical_writer_ref_transition=unresolved; actor/cause=not_established. That known absence is not a new blocker under this explicit decision. Concrete evidence of a material protected-anchor or source-selection conflict remains blocking.

### 2.3 Exact candidate-specific diagnostic qualification; protect everything else

This is NOT a blanket refs/codex/** or turn-diffs prefix exemption. A record is eligible for the observation-only class Q only when ALL the following hold:

1. Its full ASCII refname matches one of these TWO closed shapes, with no trailing segment:
   refs/codex/turn-diffs/captures/<13 decimal digits>/<UUID>/base
   refs/codex/turn-diffs/checkpoints/<32 lowercase hex>/<32 lowercase hex>/<13 decimal digits>/<UUID>
   Here UUID is exactly lowercase hex in 8-4-4-4-12 groups; no additional version inference is made. No other namespace, casing, shape or ambiguous name is allowed into Q.
2. Its recorded OID is exactly 17ee7db2925ed03ebc1614880fba5ec83d102d8c, the independently reconstructed unchanged candidate TREE. A branch/base commit, arbitrary tree or merely same-content label does not qualify. For present live records verify target object type/tree without replacements, hooks, object writes or ref mutations. For absent historical records use authenticated retained endpoint evidence and mark any unobserved storage detail as unknown, not as a fabricated live observation.
3. A current eligible record is direct, not symbolic. No protected symbolic ref, HEAD/worktree routing, replace-ref, configuration selector, source/test/validation dependency, recovery/admission/publication selector or applicable governing rule resolves through it. Check actual candidate/config/launcher dependencies, not merely the prefix. A documentation mention is not itself executable selection. Record exact inspected paths/lines and safe config conclusions; do not claim a universal proof about all host applications.
4. Source and validation are selected ONLY from the authenticated archive and fixed explicit object/endpoint identities, never by this ref. Live .git and diagnostic objects/refs are not copied into validation. No live program/test is executed. No diagnostic ref content becomes authority or a substitute for the review source.

Define eligibility from this policy BEFORE observing new deltas. Qualify R1 and R2 independently using their retained facts plus the same bounded dependency checks. For historical observations, Q is a classification of the recorded name/OID endpoints and demonstrated non-selection in this audit, not an assertion about who wrote a ref or its unrecorded prior symbolic representation. Any contrary available evidence disqualifies the record.

Define P(R) as every record in R not qualifying for Q. Require P(R1) == P(R2), with exact record identities, and derive the fixed protected anchor P0 from those authenticated inventories. Do NOT define P0 from whatever the next opening happens to contain. All heads, remotes, tags, HEAD, replace refs, stash/notes, other codex records, unknown shapes, different OIDs and unclassified records are protected by default. A previously protected record cannot be reclassified solely to absorb its movement: a name in P0 must remain protected and exact for this engagement. Source-dependent or symbolic records remain protected even when their spelling and OID otherwise fit.

New eligible Q names may appear or disappear between turns or observations, including beyond the three already named examples. Qualification is rule-based and candidate-specific, not a continually enlarged name allowlist. Every such delta is retained with full old/new records and the exact criterion it passed. Moving an eligible name to another OID or making it symbolic is NOT covered. Unqualified/new protected records, protected deletions or changes, required-anchor loss and unresolved selection dependencies block acceptance. Never create, delete, restore or freeze refs to make an observation pass. Do not disable tooling or alter its configuration.

Before live audit execution, inspect and freeze the external qualification helper and apply a small DATA-ONLY control set: the actual three-record transition must leave P invariant; source/branch/index/config changes must fail; a similarly named out-of-scope ref, wrong tree, protected-ref addition/removal/change, protected symbolic dependency and missing protected/unclassified record must not be erased by the policy. Retain helper source and expected/actual results. This is a bounded test of the new evidence predicate, not a new product or general ref-normalization library.

### 2.4 Establish a real opening and preserve the original collector

Use a newly owned external audit root. Read guidance, then record the actual source/filesystem/index opening before ordinary Git observations. Disclose preliminary reads and the unobserved prior gap; do not backdate preservation. Source must match all 298 candidate payloads/modes. The semantic index must equal the 286 stage-zero baseline entries and the raw index must match section 1R. Require exact patch, branch, HEAD, sole parent, tree, no upstream and all named trunk/D2 topic/original-commit anchors. Inspect for active Git operations, unexpected locks or a concrete competing writer without scanning private account/process state. A qualified ref change by itself does not prove such a writer exists. Record the actual protected symbolic routes and safe worktree-routing facts at opening and require exact equality at all subsequent observations, in addition to the P0 name/OID comparison. Equal resolved OIDs do not prove equal symbolic routes. Compare available historical routing evidence where it exists; do not invent unavailable older symbolic observations.

Use safe read-only Git forms: GIT_OPTIONAL_LOCKS=0, --no-optional-locks, core.fsmonitor=false, core.untrackedCache=false, and disabled external diff/textconv/renames where applicable. Independent object reads must not use replacement objects or ambiguous ref resolution. No index refresh, write-tree, fetch, checkout, reset, branch/ref/config mutation, maintenance/GC, live tests or repository imports. Preexisting ignored caches remain opaque and untouched.

Authenticate and inspect the unchanged provenance/provenance_collector.py before its limited execution. Retain its v1 recipe ID/source bytes/hash. Run it twice with its actual inspected safe CLI and fresh external output paths, using the actual ambient Git-config resolution that reproduced the fixed config representation. Test-copy env -i is NOT its environment. Do not inject/remove HOME/XDG/Git-config inputs or modify the recipe to produce a desired hash. No environment/config dump. If its CLI cannot safely use owned external output, independently implement its EXACT inspected v1 computation as previously permitted, retaining source and derivation; do not approximate or silently omit any v1 field.

Capture complete lossless ref inventories around these observations with the exact serialization used by v1, and a safe supplemental current symbolic/type inventory. No current total count is fixed. Independently reconstruct each available retained refs aggregate from its paired raw records. Where a ref read and a collector pass occur at different instants, keep those observations distinct: never pretend a bracketing inventory is the very read that supplied an unmatched aggregate. A further single read-only capture may resolve a pairing; do not spin until a stale all-ref hash returns. Unpaired aggregate observations must be labeled as such, not given invented per-ref contents. A qualified Q change between paired observations is not source drift or a reason to abandon substantive review; a protected-state conflict or inability to establish the required protected observations is blocking.

Each newly observed complete inventory must give exactly P0 after qualification. Every fresh collector manifest must equal the original writer manifest in ALL non-ref fields, and have the same complete field set. Full v1 manifest hashes may legitimately differ because Q was observed at a different time. Record raw v1 outputs unchanged, exact field-level differences, and every observed full inventory, including Q. Do NOT describe the whole v1 outputs as equal or as reproducing b66a42..., 935823... or b0cdeb12... unless they actually do.

### 2.5 Deterministic v2 binding plus lossless observation ledger

This is an explicit new comparison schema, not a silent edit of v1. Independently construct a stable JSON object B with exactly:
  schema_id = governed-execution.post-d2-native-proposal-admission.audit-binding.v2
  review_zip_sha256 = the fixed original review ZIP SHA-256
  baseline_zip_sha256 = the fixed integrated checkpoint SHA-256
  writer_manifest_sha256 = the fixed ORIGINAL writer manifest SHA-256
  collector_source_sha256 = the unchanged v1 collector SHA-256
  audit_mandate_sha256 = SHA-256 of the actual received complete replacement prompt
  candidate_tree = the fixed independently reconstructed candidate tree
  invariant_manifest = a NEW object containing EVERY key/value of the original v1 manifest except its sole top-level refs key
  protected_ref_records = the complete P0 records, canonically represented as sorted {name, oid} objects
  diagnostic_policy_id = governed-execution.post-d2-native-proposal-admission.candidate-tree-turn-diffs.v1

All included identities are fixed by authenticated input; protected_ref_records is derived from the authenticated historical complete inventories under section 2.3, not from an adjustable opening. Reject duplicate/ambiguous names; include HEAD when present in the original serialization. Do not drop any additional v1 field, normalize path/mode/number/string values, or substitute a current value for a nonmatching old value. The separately retained complete original manifests still include refs. This explicit v2 projection is not a claim that excluded full-ref observations are equal.

Encode B as sorted-key, compact, ensure_ascii=False UTF-8 JSON plus one terminal LF. Do not include measurement times, Q inventory, random paths, raw config or an output's own hash in B. Compute its size/SHA-256, retain its complete bytes and the exact independently authored derivation/qualification helper source. Reconstruct B twice: first from immutable writer inputs plus P0, then by independently verifying every corresponding fresh non-ref field and protected inventory before generating the same object. Require byte equality. Never use the expected B payload as the measured result without verifying its inputs. Freeze B before candidate code execution; helper transcription bugs may be repaired with both attempts retained, but the policy and protected/source anchors cannot be relaxed.

Alongside B retain observation-ledger records with actual timestamps, complete raw v1 outputs, full raw/ref inventories and available symbolic/type details, pairings or their limits, Q/P classification for EVERY record, exact added/removed/changed records, config/index observation identities, the authenticated three-record historical delta and unresolved older transition. Include source endpoint and copy manifests, collector/helper identities, failed measurement attempts and the exact engineering-decision scope. Never reduce this ledger to just counts or an unpaired hash.

The raw all-ref manifest equality requirement is replaced ONLY by this named policy. The auditor is still forbidden to mutate any live ref, including Q. A nonzero observed Q delta means you cannot claim that ALL refs were unchanged or identify a writer from the namespace. You may claim that the candidate and protected observations matched, with the actual qualifying deltas disclosed.

### 2.6 Critical path and closing conditions

Once exact source, non-ref v1 fields, P0, dependency qualification and v2 binding pass, save/reopen the binding/ledger internally and proceed directly to sections 3-7. Do not wait for the full count to settle at 53 or 54, return another opening-only success, ask the user to stop ordinary tooling, or initiate a separate implementation closeout. If a real mismatch blocks this gate, retain the actual observations and the particular failed predicate, not merely a count difference.

All execution remains in independent external copies made from the fixed 298-file archive, never live hardlinks or a checkout selected by a diagnostic ref. Include no live .git, remotes, alternate object store, hooks, caches, credentials or real databases. Inspect test configuration, import paths and child launchers before execution to exclude unintended live-path/network/state access. Preserve the original archive and all prior evidence. Optional source-review agents inspect only authenticated copies.

Repeat exact source/index/config/named-anchor and P0 observations before candidate execution and after final cleanup. Retain all raw inventories and classify every delta under the SAME frozen rule; B must remain identical. Q churn cannot absorb a protected or source change, and it cannot retrospectively explain the writer's missing historical inventory. Observations establish their measured endpoints, not continuous surveillance or an atomic host snapshot. Closeout separately reports unchanged protected state, qualified ref deltas and unobserved intervals.

Preserve substantive work even when a later real closing mismatch is found. The appropriate outcome then distinguishes source-bound findings/test results from failed live preservation and withholds commit-gate eligibility; do not discard valid audit evidence or imply test failure solely from an environmental observation. There is no artifact-only fallback to bypass a known source/protected-state conflict. This engagement authorizes no gate effect.

## 3. Review ownership and parallelism

The parent owns provenance, integration, audit-test execution, report and disposition. Bounded read-only subagents MAY inspect authenticated archive/external-copy source after provenance matches; none may execute tests, edit source, create nested agents, access live state, or widen scope. Useful nonoverlapping perspectives are (a) contract/privacy/schema, (b) writer/controller/replay/recovery, and (c) continuation/assurance/validation. Give each the exact canonical identity, fixed contracts, corrections, effect ceiling and required path:line evidence. Preserve disagreements and verify their decisive claims yourself.

Subagents are optional, not a new mechanical approval prerequisite. If unavailable, the parent must actually perform and label the missing perspective or return partial coverage. Never claim a nonexistent independent perspective. Keep all test/probe execution serial under the parent; stop/close agents before cleanup. No competing writer is permitted.

## 4. Frozen contract to judge, not to redesign

Selected connected result:
  original D2 run (one invocation)
  -> Section 41 transaction A owns source/artifact/proposal/nine evidence rows + safe context + native receipt
  -> fresh fenced checked A readback
  -> separate existing C1 transaction B admits the twelve COMMON Section 41 owner rows at rank 15
  -> fresh checked A/B readbacks
  -> unchanged pure V22 projection
  -> nonaccepting transient result and creator-process disposal.

A may commit without B. That is a legitimate recorded-but-not-admitted state. A and B may not be collapsed into a cross-owner transaction; A context/receipt may not be absorbed into C1's frozen twelve-row graph. C1 is an admission owner, not the author of Section 41 rows. The existing writer-session/resource-bound controller remains the only connection/transaction owner.

D2 v1 entry, handback/model code, fake identities, migrations 0001-0004, existing pure evidence/profile/value owners, _rw0_c1_semantic_values.py, and V22 remain byte-exact where the implementation mandate protected them. Existing C1 admission/recovery semantics, pre-execution receipt/disposition/selection semantics, public interfaces/exports, and shared B3/B4 cleanup/fencing contracts remain unchanged. The intended C1 change is its private checked rank-15 selector/type, not a widened admission grammar.

Safe retention correction: V07 is PostExecutionPrivateInputManifestV2; V08 is its metadata entry. V10/V11 are full evidence/role supplies with supplied canonical values. Retention must be enforced by exact schema IDs and recursively closed fields, not by V-number shorthand. Raw private evidence, artifact narrative/response, capsule blobs, WorkSpec, prompts, runtime handles, PID/cwd/environment/stdout, paths and credentials may not be stored wholesale or exposed in safe results. Child-outcome digests are bounded consumed-evidence attestations, not replay of children or authenticated live-supplier evidence.

Migration 0005 deliberately adds only the selected Section 41 context and receipt. Generic common Section 41/C1 zero-or-nine representation remains; this native D2 producer and V22 require nine. Application generation 2 and explicit administrative migration of complete old-prefix states are selected. Existing acquisition/validation cannot auto-migrate. C2's prospective suffix can be deferred without selecting its physical schema. Artificial offline repetition does not satisfy or waive first-live supplier gate B.

One original process owns temporary run custody. New writer-session readback while it lives is allowed; restart/clone/restore/multi-run identity allocation is not established. All five model recommendations remain evidence, never a C2 decision, durable block, acceptance, terminal outcome or effect grant. No live route, product Git handler, scheduler or autonomous loop is introduced.

Read controlling guidance and explicit supersessions, not only the new contract: AGENTS.md, README.md, .docs/autonomous-software-development-operating-model.md, architecture/authority boundaries, the Section 41 section of c2b-durable-development-state.md and its new incorporated owner, D1/D2 and C1 owners, the five C2 target owners, migration/recovery owners, affected source/test/DDL/configuration/examples and relevant retained artifacts. There is no root PLANS.md in the authenticated baseline; do not invent one. Read all twelve created files, the complete 57-file tracked patch, full new production modules, and all changed/shared functions with their surrounding ownership/exception/resource invariants. Report the exact semantic inspection limit rather than claiming every line of the entire tree was audited.

## 5. Mandatory source and contract audit register

For each A01-A12 retain: governing path:line; candidate path:line; code/dataflow inspected; normal and discriminating evidence; causal versus structural versus report-only status; masking/coverage limits; pass/finding/unresolved. A green full suite is not an answer to this register.

A01 — Native end-to-end origin and final association.
Trace the new outer and borrowed continuation through the ORIGINAL open D2 run to actual native A/B calls. Verify one D2 invocation, no directly seeded target family on the positive, one model run and no replacement donor. The final consuming boundary must bind all retained A-to-B role/source/policy/risk/authority/capsule relationships, original run custody, three D2 child outcomes, two checking effects and all fourteen C1 families. The fixed D2 kind sequence is (12,12,12,12,13,14,1,1,5,6,12,6,12,1), from unchanged _rw0_d2_handback.py:44; it is NOT ranks 1 through 14. Membership order and roles must be checked, not just count, membership presence, self-digests or capsule identity. Reject same-capsule/noncapsule donor replacements at the real consumer. Equivalent canonical values are not automatically foreign custody; distinguish value equality from the original run operand.

A02 — Closed input, safe basis and privacy.
Derive exact command/row/result/recovery schemas and eight-field safe-basis allowlist from the owning contract. Verify canonical duplicate-key-free UTF-8, exact built-in types, bounds/nesting/cardinalities, bool-as-int rejection and field-local strings; no arbitrary mapping/callback becoming authority. The BLOB limit is 131072 bytes: inspect exact boundary and one-byte-over behavior without truncation or relaxing schemas to manufacture a positive. Check V07/V08 metadata versus V10/V11 payloads recursively and adversarial canaries in synthetic fixtures. Fresh write validates retained safe values against the actual run and persisted owners. Historical readback can prove only retained content and owner associations, not deliberately unretained private bytes or external custody.

A03 — Digest graph and command identity.
Independently derive one complete known-answer vector across safe basis, command, common/context rows, mutation graph, committed-result projection, receipt and presentation. Confirm an acyclic definition; the committed projection excludes its own digest, dependent receipt digest and fresh/replay presentation status. Preassigned C1 mutation/membership refs are stable and not generated from a self-referential digest. Changed command under an occupied mutation ref conflicts after receipt-first family verification. Check row/receipt/value digest validation separately from expected-value assertions and hash-only testimonies.

A04 — DDL, additive migration and compatibility.
Read all SQL and row definitions, catalog/framework changes and exact schema introspection. Verify exactly two new STRICT tables, four UPDATE/DELETE immutability triggers, zero new seeds and no new explicit index; distinguish inline-key autoindexes. Verify phase/context/proposal/mutation/receipt unique routes, immediate restricted FKs and every repeated identity not enforced by SQL is enforced in both writer and checked reader. Ref-only FK is not digest equality. Derive actual counts independently: report claims 5 catalog entries, 64 user tables, 114 triggers, 5 explicit indexes, 1518 columns, 197 FK constraints/513 component rows. Any discrepancy is explained from actual DDL, never silently normalized. Authenticate all four older migration resources (section 9). Exercise fresh initialization, populated valid supported-prefix migration, exact 0004 acquisition refusal, explicit migration success, failure rollback, partial/unknown states and old-binary/new-schema refusal. Preserve historical 0001 fixture semantics while checking the B3 fixture's updated physical catalog. Runtime observation on SQLite 3.49.1 is not a run on 3.37.0; inspect minimum-contract compatibility and fault tests and report that distinction. No dependency installation or minimum change.

A05 — Shared controller and writer-session safety.
Audit the COMPLETE new operation path through the existing operation guard/lease/slot, resource-bound transaction, BEGIN IMMEDIATE, fencing, nominal capability invalidation, commit attempt, error sanitization and cleanup/publication rules. Fence before receipt or protected-row disclosure. No raw connection escape, generic gateway, second connection owner, ambient authority callback or broadened public protocol. Check altered exception branches against every existing operation they can affect, not just the new family. At most one commit attempt per operation. A later delegate/connection/capability/lease/slot cleanup failure after a commit attempt cannot become a no-write result. Process-control exceptions retain correct ownership/sanitization. No writer remains open across child launches.

A06 — Fresh currentness and historical meaning.
The original D2 B-time observation is not the new write-time authority observation. Re-read exact program/work/selection/effect/delivery/phase/stop prerequisites under transaction A; preserve frozen original preimages rather than rebasing to newer heads. Test each independently controlling source/fence/attempt expiry with representable before/equal/after times, including a narrower bound where other valid lifetimes would otherwise mask the predicate. Equality rejects fresh recording; legitimate previously committed families replay and read back after expiry/head movement. Chronology must relate proposal/source to transaction time without retiming historical evidence. Do not claim continuous authority until later wall-clock COMMIT. Record any masked predicate honestly.

A07 — Complete family, same-transaction gates and occupancy.
Check global source/artifact/proposal/context/receipt routes, all nine composite evidence keys, and evidence-set reuse across proposals. The report's proposal_ref occupancy probe may replace nine probes ONLY if the actual immutable key/FK structure proves that every claimed evidence key is covered and every foreign/partial fragment is detected; audit that equivalence, not loop count. Require explicit bounded actual SELECTs (including proposal LIMIT 2 and evidence LIMIT 10) after inserts, exact roles/ranks/order/ordinal/required flags/digests, receipt last, and full same-transaction readback. No upsert, fragment adoption, alternate IDs or selective overwrite. Missing/extra/duplicate/wrong-phase/source/set/role/ref entries must not leave a target receipt/family after rollback. No existing rows may be repaired to fit the command.

A08 — Checked readers, evidence provenance and V22.
Trace actual SQL result tuples through typed construction and final projection. Section 41 reader must return all twelve common owner values and twelve genuine SELECT tuples, reconstructed V02/safe basis and verified context/receipt. It may not fabricate SELECT tuples from the caller's object. Recheck referenced immutable C1 membership/receipt and bound-effect owner facts; a digest-only fabricated witness is not admitted evidence. Verify C1 selector/type extension is exactly rank-15 support with fencing and existing wrapper checks. Inspect added decision-row imports/consumers for their actual read-only predecessor purpose; do not assume their name adds or authorizes a physical C2 decision writer. Match actual twelve-row order and exact C1 relation/graph/membership/mutation data to unchanged V22. Its expected-value argument is an assertion, never the supplied owner truth. B readback alone does not prove A's two new rows.

A09 — Separate B command and transaction.
Build B only after A's checked committed proof, from persisted twelve common rows and original phase CAS preimages with stable preassigned C1 identities. Freeze B command and recovery selector before its attempt. No later-head refresh, changed command, A-row ownership transfer or enlargement of C1 graph. B CAS refusal leaves A committed and no new B/projection claim. Preserve generic zero-or-nine C1 representation outside this producer. Inspect command reconstruction/replay for identical identity rather than merely equivalent final fields.

A10 — Commit uncertainty, absence and historical replay.
For A and B independently cover failures before commit, commit-call exception before underlying commit, exception after actual commit, lost return and postcommit cleanup failure. Observe actual commit calls and durable synthetic rows, not mocks that never reach the owner. Selectors must be fixed before attempts. Fresh fenced recovery is read-only, receipt-first, verifies exact full historical family and command, and reports committed_exact / definitely_not_committed / unresolved. Missing receipt alone cannot prove noncommit. Probe every claimed route and prerequisite; partial, foreign, extra or unverifiable rows are unresolved, not adoptable absence. Recovery cannot write, rerun model/children, retry admission or manufacture a new selector. Verify replay with later expired heads while original run remains open. No false no-write after an uncertain attempt.

A11 — Progress state, custody and cleanup.
Derive the finite reached-facts/result matrix from the contract. Distinguish no A record, A committed/B not committed, uncertain A, uncertain B, B committed/final reader or projection failed, coherent projection, borrowed cleanup pending and owner cleanup unresolved. Immutable known commitments cannot be discarded to report a simpler failure. A projection is not acceptance. Borrowed results cannot claim disposal; outer finally closes the original run even when downstream verification raises, and cannot hide cleanup failure behind a success. Test same-process fresh-session readback, wrong-process and closed-run refusal, and no child/FD/state-root leakage from audit fixtures. Do not infer restart/restore or multiple-run support from SQLite persistence.

A12 — Assurance successors, protected behavior and documentation.
Inspect ALL 40 changed tests and 20 documentation files, not just six new modules. For each changed inventory/hash/fixture: record old protected property, exact new allowed edge/change, remaining hostile control and independent consumer. Verify P11 complete-live-byte primary and companion guards, exact integrated predecessor reconstruction and older 64142-byte guarantee. Verify P09's reported 260-byte addition against raw before/after bytes, removal reconstruction of the 17972-byte predecessor, and semantic necessity of the exact new consumer. Audit the B3c4c controller-byte successor against unchanged lifecycle/cleanup semantics, not merely its current hash. Existing caller/SQL-import/guard vectors and no-C2/public/runtime boundaries must not be weakened to clear the predecessor failures. Historical literal migration oracles stay historical, current catalog assertions advance explicitly. Reject self-derived expectations, wildcard imports, ignored regions, shortened hostile vectors, hidden skip/xfail/deselection or replacing actual raw-byte checks with reconstructed text. A justified bounded inventory successor is permitted by the original mandate; its late discovery is not automatically scope drift. Pending-review narrative should not trigger another status-only repair unless it materially misstates authority or current behavior.

## 6. Independent runtime evidence — critical path before broad validation

After provenance/source screening, independently run one actual original D2 -> native A -> checked A -> native C1 B -> checked A/B -> unchanged V22 positive in the authenticated clean audit copy. Existing test fixtures may be used only after you inspect that they genuinely produce this path. Record safe owner identities and cardinalities, fourteen original C1 family roles/order, twelve actual owner tuples, the new rank-15 membership, receipt/result/projection vectors, actual child-launch count and cleanup ownership. Capture the proof while the original run is open; do not preserve a raw database/private capsule in the handoff. Observe no extra model launch on replay/recovery.

Save and reopen this substantive audit checkpoint and its full source identity before expanding fault probes. This is internal progress, not a user approval checkpoint. It must include actual results or an exact counterexample, not an empty procedural checkpoint. An early material defect can stop further execution; save the exact reproducer and unfinished register instead of demanding completion of all tests on a known-bad candidate.

Run a bounded independent discriminating set, with exact selectors and expected observations frozen in the audit register before execution:
- A same-capsule/different-policy or donor-B substitution at the final consuming boundary. Show own-graph positive and observed target-write absence on rejection. Do not count an unrelated constructor/type failure as proof of the final relational check.
- A withheld real evidence insert (at least the ninth), plus an overcomplete/foreign-reader result at the actual same-transaction gate. Retained full-suite coverage of all nine omissions/read faults must also be verified. Show receipt-last behavior and rollback/no surviving target family.
- Fresh strict expiry at its boundary with a distinct valid historical replay after expiry; include the narrower independently controlling lifetime case and changed-head no-write control where applicable. Preserve observation-time versus commit-time distinction.
- A and B actual underlying commit exceptions on both sides of commit, and one postcommit cleanup/readback failure. Inspect attempt counts, recovery classifications and final reached facts, not only exceptions.
- Missing receipt with a present partial/foreign claimed route, including same evidence_set_ref on another proposal; it must not become definitely_not_committed. Preserve exact existing rows and absence of recovery writes/retry.
- A committed/B CAS refusal and B committed/final projection or disposal failure; neither may be reported as complete admitted-clean success or as though the known commit never happened.

Independent small probes may be authored outside candidate source. Fault injection/mutations are allowed only in separately identified disposable audit variants, each retaining the unmodified 298-file baseline, exact changed-file diff/hash, test selection and observed production check. No edits to repository or accepted package. Begin with a valid positive; distinguish natural fault injection from deliberate removal of a production check. Do not broadly rewrite production/tests to make a probe pass. Source-hash/AST refusals are structural evidence, not causal proof of a runtime predicate. If an earlier guard masks a later one, use a bounded direct seam when contract-valid or mark that later predicate unproved; never count the same failure twice as independent proof.

At least source-review and targeted outside-span/unauthorized-edge controls must substantiate P09/P11 and caller-guard preservation. Do not start a generalized mutation/fuzz/join campaign or repeat the old D2 A01-A13/E/X/R/J campaign wholesale. Relevant unchanged D2 regression tests remain in FULL; the new audit concentrates on the added consumer, writer, readers, migration and shared-controller changes.

## 7. Retained implementation evidence and one clean full regression

First reconcile retained evidence as data. Read validation/final/validation-receipt.json, node-inventory.json, source-manifest.json, full-collect.txt, full-run.txt and full-junit.xml. Reconstruct exact collection/JUnit identity equality using the retained mapping/encoding, not counts alone. Check complete candidate source binding, exact argv/cwd/sanitized environment, plugins/selectors, real exit codes, pre/post source equality and warning/outcome inventory. Authenticate evidence/case-register.md, schema inventory, migration preservation, digest/retention vectors, first checkpoint and cleanup records. Validate all declared evidence is nonempty and belongs to its claimed source version.

The report describes extensive intermediate failures and interrupted runs. Preserve their chronology and semantic consequences; they do not certify final bytes. In particular check final repairs for the kind-rank sequence, B3 physical schema fixture, exact caller/SQL-import/document consumers, B3c4c controller pin and P09 consumer successor. The operative writer claim is 9191 collected = 9191 unique executed JUnit cases = 9191 passed, zero failures/errors/skips/xfails, and three pre-existing fork DeprecationWarnings. A larger aggregate pass count does not excuse changed guard meaning. Do not substitute 9180, 9190, the historical D2 9098, or focused 1013 counts for final evidence.

After source review and bounded probes reveal no blocker, run ONE selector-free independent collection and ONE selector-free execution in a fresh clean authenticated candidate copy, not a previously mutated probe copy. Do not also repeat all 49 historical selected modules as a second final campaign. The mandatory modules in appendix B must be present inside FULL, including shared migration/session/controller tests; missing coverage is not cured by an equal total count.

Use the installed interpreter matching the reported final run:
  PY=/Library/Frameworks/Python.framework/Versions/3.13/bin/python3
Reported versions: Python 3.13.4, pytest 8.4.1, SQLite 3.49.1.
Verify actual executable and versions from a neutral owned directory before repository imports. The implementation reports Python 3.12.11 has no pytest; do not install it or repeat environment-repair work. If the selected installed runtime is unavailable or materially different, disclose and stop the dependent validation, retaining source findings; do not silently choose a different oracle/runtime.

Create AUDIT_ROOT, VALIDATION_COPY and VALIDATION_ROOT under a fresh owned external root. Set actual absolute paths, create owned home/tmp directories and record them. Use an explicitly constructed nonsecret environment, not a dump of the ambient environment. Verify the unchanged pyproject configuration and test hooks do not add hidden selectors. A suitable runner is:

  PY=/Library/Frameworks/Python.framework/Versions/3.13/bin/python3
  RUN_ENV=(env -i
    "PATH=/Library/Frameworks/Python.framework/Versions/3.13/bin:/usr/bin:/bin:/usr/sbin:/sbin:/opt/homebrew/bin"
    "HOME=$AUDIT_ROOT/home" "LANG=C" "LC_ALL=C"
    "PYTHONDONTWRITEBYTECODE=1" "PYTEST_DISABLE_PLUGIN_AUTOLOAD=1"
    "PYTHONPATH=.:src" "TMPDIR=$VALIDATION_ROOT/tmp")
  cd "$VALIDATION_COPY"
  "${RUN_ENV[@]}" "$PY" -B -m pytest -q -p no:cacheprovider --collect-only --basetemp="$VALIDATION_ROOT/full-collect" > "$VALIDATION_ROOT/full-collect.txt" 2>&1
  COLLECT_RC=$?
  # Retain COLLECT_RC immediately; do not execute FULL on failed/incomplete collection.
  "${RUN_ENV[@]}" "$PY" -B -m pytest -q -p no:cacheprovider --basetemp="$VALIDATION_ROOT/full-run" --junitxml="$VALIDATION_ROOT/full-junit.xml" > "$VALIDATION_ROOT/full-run.txt" 2>&1
  RUN_RC=$?
  # Retain RUN_RC immediately together with actual argv/cwd/environment and source identity.

Run collection and execution as separately recorded invocations with conditional sequencing, not a blindly pasted block after a failed command. No -k/-m/--ignore/--deselect, xdist, warning suppression, skip injection, dependency installation or configuration mutation. Capture real exit codes without a masking pipe. Freeze and retain complete unique node IDs and module inventory, using the exact producer algorithm for receipt comparison and independently checking its meaning. Compare executed JUnit identities to complete collected identities; distinguish list order and set equality rather than silently sorting away duplicates. The expected reported total is 9191, but independently derive it; any different result requires an explanation, not a new expected literal.

Three reported warning nodes, all in tests/test_sqlite_b2c_writer_session.py:
  test_operation_guard_close_waits_and_retains_authority_until_exit
  test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
  test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock
Retain exact actual warning/error/skip records. Existing warnings may remain with explanation; they are not test failures. New unexplained warnings/skips/xfails, omitted IDs, source drift or incomplete collection cannot count as a complete clean validation.

Check all 298 source endpoints and OS modes again after each clean execution and after probe cleanup. Do not rerun repository tests after an audit source repair: source repair is forbidden. An independently authored external helper bug may be corrected with both attempts retained, after determining whether a stateful action already happened. Do not retry uncertain mutations/commits in a fixture or relabel a real production failure as a helper error. Use new explicitly owned fixtures for repeat diagnostics.

## 8. Findings, retained evidence and disposition under the scoped binding

Classify findings by severity and type: contract/authority drift, correctness/transaction/recovery bug, security/privacy issue, migration/compatibility issue, assurance/coverage weakness, documentation/artifact gap or report-only uncertainty. Give exact candidate path:line, contract, reproducer, expected/observed state, impact, patch-versus-preexisting origin and smallest repair boundary. Do not propose deferred C2/live/restart features as a repair to a bounded nonclaim.

Material code/contract defects or missing required evidence block acceptance. Matching hashes do not prove correctness; a green FULL result does not replace A01-A12. Expected discriminating mutant failures are not candidate failures. Historical ref gaps and corrected external data-helper errors remain disclosed; they are not automatically implementation defects. No source repair is permitted.

Before cleanup retain and reopen one safe audit package outside the repo containing:
- complete report/machine result with exact source, contract and effect boundaries;
- immutable input identities, complete endpoint manifests, original v1 manifest/recipe identities, v2 B bytes/helper/policy identity, and the full observation ledger including ALL ref records and old/new deltas;
- both original mismatch reports unchanged and an exact explanation that neither old gate passed; preserve the first unresolved historical transition and the measured second delta without actor attribution;
- A01-A12 register, source lines, each auditor perspective's actual coverage, and all disagreements;
- the first substantive connected checkpoint, safe observations, exact probe source/variant diffs, reached checks, digest vectors, counterexamples, masking/causal limits and custody/cleanup observations;
- retained-writer-evidence reconciliation, independent final source binding, actual argv/cwd/sanitized environment/runtime, exit codes, collection/node inventory, execution output, JUnit and warning/skip/error records;
- cleanup ownership, failed data/helper attempts, post-cleanup source/index/config/protected readback, qualified Q deltas, open findings and skipped work.

Do not embed copies of entire nested predecessor ZIPs merely to make the new package self-contained; keep those existing files intact, reference their exact paths/size/hash and retain necessary safe evidence members with source identities. No missing evidence may be filled by invented references. Include complete new audit helper/probe source, not only hashes. No real database, full private synthetic capsule/database payload, credential, raw host environment/config, bytecode, cache/build output or unrelated artifact is deliverable. Safe synthetic row/value projections and reproducible probe recipes are permitted within the frozen privacy contract. Manifest all other package members with explicit self-exclusion and hash the final ZIP externally.

After retaining and reopening evidence, remove only enumerated NEW audit-owned disposable copies/test state. Do not clean predecessors or the live repo. Confirm audit children reaped; any audit-only rescue of deliberately faulted resources stays separate from candidate cleanup claims. For any observer failure after a stateful action, inspect the completed effect before a retry; do not repeat an uncertain commit or mutate refs.

Return ONE primary disposition:
  POST_D2_NATIVE_PROPOSAL_ADMISSION_ACCEPTED_READY_FOR_COMMIT_GATE
  POST_D2_NATIVE_PROPOSAL_ADMISSION_AUDIT_BLOCKED
  POST_D2_NATIVE_PROPOSAL_ADMISSION_AUDIT_INCOMPLETE
  AUDIT_PROVENANCE_MISMATCH

ACCEPTED requires ALL of: exact authenticated original candidate; passed scoped v2 opening and closing binding; completed substantive register; decisive real connected/negative/recovery evidence; reconciled retained execution evidence; and complete successful independent selector-free collection and FULL execution from clean authenticated final bytes. No semantic audit or independent test result existed before this continuation. The writer's 9191-pass count is not independent evidence until actually exercised here.

Under this explicitly versioned rule, qualified Q deltas and the unresolved writer-to-first-auditor inventory do not by themselves veto source-audit acceptance. A real protected/source/config/index mismatch or a failed qualification does. State exactly which is present. Never label an old mismatch as cured, all refs as preserved when they changed, or a ref class as actor-authenticated/harmless. The complete old manifests are unequal; the new B comparison is a different disclosed evidence criterion.

Report FIVE separate conclusions:
  (1) immutable source/artifact identity;
  (2) historical ref evidence and unresolved gaps;
  (3) current protected-state binding versus complete qualified ref observations;
  (4) independent runtime/validation coverage;
  (5) implementation correctness within the artificial offline boundary.

Acceptance applies only to the exact original bytes and recorded v2 criterion. It grants NO staging, commit, push, PR, merge, live authority or other product effect. A later separately authorized gate must authenticate live working/staged/committed endpoints, compare the same protected/source binding and record scoped ref deltas rather than reinstate stale total-ref equality. It must explicitly authorize its own index/branch/upstream mutations and carry unresolved historical limits. This prompt does not authorize that gate.

The final response must include actual retained ZIP/report/result paths, sizes and SHA-256s; branch/HEAD/base/candidate-tree/upstream; changed-file counts; report-versus-executed evidence; schema/transaction/reader/recovery/assurance conclusions; failures/skips/masking limits; complete provenance qualification and observed deltas; unfinished work; and separate provenance, validation and implementation confidence. Return substantive findings or the exact specific remaining blocker, not another summary that only total ref counts differ.

## 9. Older immutable migration anchors

All paths are under src/ge_nwp_coordinator/sqlite_migrations/:
  0001_initial.sql
    17940 bytes; 1a3af0f4dc3a9df8fe0a745a68a98590e56dd6f9dc7aeeced3aa975839543148
  0002_development_program_and_effect_state.sql
    154434 bytes; 5859f49994b1467db71911fb60db4f1cfc562af7517dc6e4d81b5b29ca44d56c
  0003_cognitive_proposal_and_selection_state.sql
    161472 bytes; b5c7cac8e074b77ab369579f1f8015f547f1a2776b4b09d612e56280f16c1579
  0004_rw0_c1_durable_evidence.sql
    289058 bytes; 967b9c2deb43da625f9ce82d43c9538bfd2fa27c02f3abdfcb12eb3a2aef8cec

These are old production resource identities, not identities of current cumulative-schema fixture databases. Preserve that distinction when reviewing the B3 fixture and current catalog successors.

## Appendix A. Exact reported 69-path review scope

This inventory is copied from the authenticated implementation report and must equal the independently reconstructed canonical manifest. It is not a grant to edit any path.

- modified: .docs/architecture.md
- modified: .docs/authority-boundaries.md
- modified: .docs/autonomous-software-development-operating-model.md
- modified: .docs/c2b-durable-development-state.md
- modified: .docs/c2b2-migration-0002.md
- modified: .docs/rw0-c1-durable-evidence.md
- modified: .docs/rw0-b2-capability.md
- modified: .docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md
- modified: .docs/rw0-c2-durable-progression-decision-semantic-contract.md
- modified: .docs/rw0-c2-first-live-proof-posture.md
- modified: .docs/rw0-c2-private-value-versioning.md
- modified: .docs/rw0-c2-scope-admission-provisioning-contract.md
- modified: .docs/rw0-d2-offline-evidence-and-review.md
- created: .docs/section41-post-execution-proposal-family.md
- modified: .docs/sqlite-bootstrap-and-migrations.md
- modified: .docs/sqlite-operations-and-recovery.md
- modified: .docs/sqlite-schema-v1.md
- modified: .docs/sqlite-state-backend-adr.md
- modified: AGENTS.md
- modified: README.md
- created: src/ge_nwp_coordinator/_rw0_d2_post_execution_continuation.py
- created: src/ge_nwp_coordinator/_section41_post_execution_proposal_mutation_contracts.py
- created: src/ge_nwp_coordinator/_section41_post_execution_proposal_row_values.py
- modified: src/ge_nwp_coordinator/_sqlite_rw0_c1.py
- created: src/ge_nwp_coordinator/_sqlite_section41_post_execution_proposal.py
- modified: src/ge_nwp_coordinator/sqlite_migration.py
- created: src/ge_nwp_coordinator/sqlite_migrations/0005_section41_post_execution_proposal_family.sql
- modified: src/ge_nwp_coordinator/sqlite_transition_transaction.py
- modified: src/ge_nwp_coordinator/sqlite_writer_session.py
- modified: tests/b3_coherent_transition_fixture.py
- modified: tests/test_autonomous_software_development_operating_model.py
- modified: tests/test_b2a_writer_session_contract.py
- modified: tests/test_b3_coherent_transition_fixture.py
- modified: tests/test_b3a_persistence_contracts.py
- modified: tests/test_b3b1_pure_row_contracts.py
- modified: tests/test_b3b2a_read_scope_and_query_contracts.py
- modified: tests/test_b3b2b_select_readers.py
- modified: tests/test_b3b_reader_prerequisite_contracts.py
- modified: tests/test_b3c0a_transition_authority_contract.py
- modified: tests/test_b3c0b_transition_event_replay_contracts.py
- modified: tests/test_b3c1_prerequisite_contract.py
- modified: tests/test_b3c1b_rollback_only_writer_fencing.py
- modified: tests/test_b3c3_prerequisite_contract.py
- modified: tests/test_b3c4c_prerequisite_contract.py
- modified: tests/test_c2a_nonimplementation.py
- modified: tests/test_c2b0_durable_state_contract.py
- modified: tests/test_c2b2_development_row_value_boundaries.py
- modified: tests/test_post_execution_pure_owner_boundaries.py
- modified: tests/test_post_execution_pure_owner_vectors.py
- modified: tests/test_remote_worker_pre_execution_planning_contract.py
- modified: tests/test_runtime_non_authority.py
- modified: tests/test_rw0_b2_capability_boundaries.py
- modified: tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
- modified: tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
- modified: tests/test_rw0_c2_private_value_versioning_contract.py
- created: tests/test_rw0_d2_post_execution_admission_integration.py
- created: tests/test_section41_post_execution_proposal_contracts.py
- created: tests/test_section41_post_execution_proposal_delegation.py
- created: tests/test_section41_post_execution_proposal_recovery.py
- created: tests/test_section41_private_atomic_post_execution_proposal.py
- modified: tests/test_sqlite_b1_migrations.py
- modified: tests/test_sqlite_b2c_writer_session.py
- modified: tests/test_sqlite_backend_b0_contract.py
- modified: tests/test_sqlite_c2b1_migration_framework.py
- modified: tests/test_sqlite_c2b2_migration_0002.py
- modified: tests/test_sqlite_rw0_c1_migration_0004.py
- modified: tests/test_sqlite_section41_migration_0003.py
- created: tests/test_sqlite_section41_migration_0005.py
- modified: tests/test_worker_execution_semantic_boundaries.py

## Appendix B. Mandatory existing/new modules inside selector-free FULL

These 61 literal test-module paths are the deduplicated explicit requirements in the implementation mandate. They are coverage assertions, not a replacement selector or an additional repeated suite. Also inspect all 40 changed test/support files and collect every other module discovered by unmodified FULL.

- tests/test_architecture_contracts.py
- tests/test_autonomous_software_development_operating_model.py
- tests/test_b3c4b_private_atomic_transition_persistence.py
- tests/test_b3c4c_public_transition_delegation.py
- tests/test_b4b_private_atomic_global_stop_persistence.py
- tests/test_b4c_public_global_stop_delegation.py
- tests/test_c2a_nonimplementation.py
- tests/test_c2b0_durable_state_contract.py
- tests/test_c2b3_private_atomic_program_initialization.py
- tests/test_c2b3_private_program_initialization_delegation.py
- tests/test_c2b3d_private_atomic_author_effect_establishment.py
- tests/test_c2b3d_private_author_effect_delegation.py
- tests/test_post_execution_pure_owner_boundaries.py
- tests/test_post_execution_pure_owner_relations.py
- tests/test_post_execution_pure_owner_values.py
- tests/test_post_execution_pure_owner_vectors.py
- tests/test_rw0_b1_boundaries.py
- tests/test_rw0_b2_capability_boundaries.py
- tests/test_rw0_c1_mutation_contracts.py
- tests/test_rw0_c1_private_atomic_persistence.py
- tests/test_rw0_c1_private_readers.py
- tests/test_rw0_c1_reader_contracts.py
- tests/test_rw0_c1_recovery.py
- tests/test_rw0_c1_row_values.py
- tests/test_rw0_c1_semantic_values.py
- tests/test_rw0_c1_writer_session_delegation.py
- tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
- tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
- tests/test_rw0_c2_first_live_proof_posture_contract.py
- tests/test_rw0_c2_private_value_versioning_contract.py
- tests/test_rw0_c2_scope_admission_provisioning_contract.py
- tests/test_rw0_d1_handback_values.py
- tests/test_rw0_d1_offline_integration.py
- tests/test_rw0_d2_bound_effect_contracts.py
- tests/test_rw0_d2_bound_effect_persistence.py
- tests/test_rw0_d2_c1_checked_readback.py
- tests/test_rw0_d2_evidence_children.py
- tests/test_rw0_d2_model_handback.py
- tests/test_rw0_d2_offline_integration.py
- tests/test_rw0_d2_post_execution_admission_integration.py
- tests/test_rw0_d2_process_frames.py
- tests/test_section41_cognitive_proposal_row_values.py
- tests/test_section41_cognitive_proposal_semantic_values.py
- tests/test_section41_post_execution_proposal_contracts.py
- tests/test_section41_post_execution_proposal_delegation.py
- tests/test_section41_post_execution_proposal_recovery.py
- tests/test_section41_pre_execution_plan_disposition_contracts.py
- tests/test_section41_pre_execution_plan_disposition_recovery.py
- tests/test_section41_private_atomic_post_execution_proposal.py
- tests/test_section41_private_atomic_pre_execution_plan_disposition.py
- tests/test_section41_private_pre_execution_plan_disposition_delegation.py
- tests/test_sqlite_b1_connection_posture.py
- tests/test_sqlite_b1_migrations.py
- tests/test_sqlite_b2b_lock_integration.py
- tests/test_sqlite_b2c_writer_session.py
- tests/test_sqlite_c2b1_migration_framework.py
- tests/test_sqlite_c2b2_migration_0002.py
- tests/test_sqlite_rw0_c1_migration_0004.py
- tests/test_sqlite_section41_migration_0003.py
- tests/test_sqlite_section41_migration_0005.py
- tests/test_worker_execution_semantic_boundaries.py

End of mandate.
