# Coordinator Unit 2 pure-owner scope amendment and implementation continuation

## Routing and effect ceiling

Use this mandate in the **same write-enabled Coordinator implementation Codex conversation** that produced `POST_D2_UNIT2_BLOCKED` and restored the live checkout to F1 tree:

```text
93afef8750e062d80626a5a37adfa27766305b7c
```

The foreground parent is the sole repository writer. Do not use the independent auditor, Opus, a new repository writer, or a mutation subagent.

This is a bounded implementation/validation continuation. Do **not** stage, commit, push, create or update a PR, merge, fetch, install dependencies, contact a provider or live service, invoke ES or Bridge, operate on a user database, or publish any product effect.

This mandate is complete. The user must not assemble prompt fragments.

---

## 1. Authenticate the three exact inputs before repository work

### Input A — current F1 implementation base

```text
/Users/ds/Downloads/Coordinator_F1_Classification_eSUxoG/F1ClassificationRepairReviewFinal.zip
size:   7,406,558 bytes
SHA256: 9cb40710e2a6d2c4d13fb79196885d12d5f52ea1e7f5f7f50ebf1b48f24085b3
source tree: 93afef8750e062d80626a5a37adfa27766305b7c
source endpoints: 299
```

### Input B — original native-proposal candidate, historical comparison only

```text
/Users/ds/Downloads/Coordinator_PostD2_Final_ftssNh/ReviewPackage.zip
size:   14,481,457 bytes
SHA256: d9b4d61e212893b48ba1952c3b5370c09874ca2e70798decc36bc4fdbd893d9b
source tree: 17ee7db2925ed03ebc1614880fba5ec83d102d8c
```

### Input C — blocked Unit 2 evidence and exact prior mandate

```text
/Users/ds/Downloads/Coordinator_Unit2_bBD22u/POST_D2_UNIT2_BlockedEvidence.zip
size:   3,467,435 bytes
SHA256: b36c1d1e535dbcd8b792576cccb2593d0a5dc235e7c7f523b4c7b62da2175ba2
```

Input C must contain and authenticate:

```text
POST_D2_UNIT2_BLOCKED_REPORT.md
  5,679 bytes
  SHA256 d6962f217604601879927aaa64204c84d23b25b9e9ce530c21afb0c7df8271fb

mandate.txt
  32,556 bytes
  SHA256 026cae737760e2781614029f021f126949ac3079f60133d3381dbe52357950cc

pre-edit-vector.json
pre-edit-vector-repeat.json
  each 75,594 bytes
  each SHA256 38a8a2f1aab88fb94c836358a7caa9a2b6a50f6157311ec1fa7dd307c07b8acb

pre-edit-source-manifest.json
  96,426 bytes
  SHA256 30f2043812fc26672182abbb0c31e151dbc99de9c95357cf6a7ce64be7823f6e
  source tree 93afef8750e062d80626a5a37adfa27766305b7c

blocked-partial-v3/canonical-patch-manifest.json
  114,458 bytes
  SHA256 92f520d4858b93afefceb7017b4419a2f90a9c2a085da63ef9271a6385d822f3

blocked-partial-source/
  299 source files
  reconstructed tree 2df9487936436ed1b11ae73dd75d909645f0ef5a

two_observation_blocker_probe.py
  3,127 bytes
  SHA256 4d15cfd2d73d4b5540c91e2ebaaaa9ad41352f0ded97f87b61d761e323077fbf

two-observation-blocker.log
  396 bytes
  SHA256 c5e88cb785ec533a0d312a7cd71721ebbb813218bbc322bb0231ae59039c0020
```

Authenticate Input C's complete 321-member manifest. Treat the blocked partial as nonauthoritative implementation evidence, not a candidate or accepted patch.

### Expected live repository posture

```text
repository: /Users/ds/Repositories/Governed Execution Coordinator
branch:     codex/post-d2-native-proposal-admission-v1
HEAD:       eac7f6df5f281138dd0640c5cd47b9924c8390f8
HEAD tree:  061c43c41228310134a30f3b79291bba3e44f3f2
upstream:   absent
working source tree: 93afef8750e062d80626a5a37adfa27766305b7c
source endpoints: 299
stage-zero index entries: 286, equal to HEAD
created paths relative to HEAD: exactly the existing thirteen
```

Retain the prospective raw-index, configuration, 32-authoritative-ref, and qualified diagnostic-ref policy from Input A and the prior mandate. Any mismatch that the existing opening rules classify as blocking still blocks mutation. Do not reset or normalize a mismatch into a new baseline.

Opening-block verdict:

```text
POST_D2_UNIT2_OPENING_BLOCKED
```

---

## 2. Incorporation of the prior Unit 2 mandate

The exact `mandate.txt` authenticated from Input C is incorporated into this mandate.

The following prior sections remain mandatory without coverage reduction:

- §§1–9;
- §§11–15;
- all F1 frozen-path requirements;
- both legal 13/14 layouts;
- typed validator/reviewer invalid-evidence stops;
- original-run command and complete safe-basis equality at the fresh write boundary;
- pre-edit 14-member vector preservation;
- first substantive checkpoint and all finite discriminating controls;
- focused and selector-free FULL validation;
- v3 provenance, cleanup, package, nonclaim, and effect-record requirements.

This mandate replaces the prior §10 touched-file scope and amends the focused selector as stated below. Where this mandate is more specific, it governs. No other acceptance requirement is weakened.

The prior blocked disposition remains valid under its old scope. It is not reclassified as a source failure or a completed Unit 2 implementation.

---

## 3. Engineering decision: exact pure-owner correction

The current C2A/Wire contract remains unchanged:

```text
worker_started   -> no conditional fields
worker_completed -> no conditional fields
candidate_captured -> candidate_ref required
```

The legal worker-result sequences remain exactly:

```text
worker_started, worker_completed
worker_started, candidate_captured, worker_completed
```

The parent-owned capsule remains the authoritative candidate capture. Omission of `candidate_captured` is not a worker claim that no parent candidate exists.

`PostExecutionReviewerSeparationEvaluationV1` already permits two or three ordered author-observation locators. Do not change its schema ID, profile pair, field grammar, digest domains, minimum/maximum locator cardinality, or output meaning.

Correct only the relation implemented by:

```text
src/ge_nwp_coordinator/_post_execution_evidence_values.py
evaluate_post_execution_reviewer_separation(...)
```

Required semantics:

1. For both legal layouts, require exact ordered observation kinds, exact C1 memberships, exact relation rows, exact rank-13 worker-result locator tuple, common lineage, author source/effect/delivery identities, review capsule identity, support set, and current V40 output assertion.
2. For the **three-observation** layout, continue requiring the ordinal-1 `candidate_captured.candidate_ref` to equal the parent capsule candidate.
3. For the **two-observation** layout, there is no candidate-captured observation. Do not alias `worker_completed` as a capture observation and do not read or synthesize `candidate_ref` on it.
4. For the two-observation layout, bind candidate identity through the independently checked parent capsule, the rank-13 worker-result binding's `candidate_ref`, and the review observation's capsule/candidate identity. All must agree exactly.
5. Retain the exact worker observation grammar. A `worker_completed` carrying candidate/capsule conditional fields must still be rejected by the worker semantic owner; do not loosen that owner.
6. The V40 result continues to carry the parent capsule candidate/capsule/digest and exactly two or three author-observation locators according to the actual legal layout.
7. Do not bypass reviewer separation, remove candidate association, invent a candidate observation, narrow the legal Wire grammar, or make D1 infer worker-authored evidence from parent capture.

This is an alignment of the pure relation with an existing legal protocol form, not a schema or authority redesign.

---

## 4. Replacement touched-file scope

### 4.1 Production files authorized

The prior eight Unit 2 production files remain authorized:

```text
src/ge_nwp_coordinator/_rw0_d2a_evidence.py
src/ge_nwp_coordinator/_rw0_d2a_offline.py
src/ge_nwp_coordinator/_rw0_d2a_handback.py
src/ge_nwp_coordinator/_rw0_d2_handback.py
src/ge_nwp_coordinator/_rw0_d2b_model_input.py
src/ge_nwp_coordinator/_section41_post_execution_proposal_mutation_contracts.py
src/ge_nwp_coordinator/_rw0_d2_post_execution_continuation.py
src/ge_nwp_coordinator/_sqlite_section41_post_execution_proposal.py
```

Add exactly this pure owner:

```text
src/ge_nwp_coordinator/_post_execution_evidence_values.py
```

`src/ge_nwp_coordinator/_rw0_d2_offline.py` retains the prior inspect-first, narrow typed-stop permission.

No other production file is authorized.

### 4.2 Direct pure-owner tests authorized

Add these existing test files to the editable scope:

```text
tests/test_post_execution_pure_owner_relations.py
tests/test_post_execution_pure_owner_vectors.py
```

`tests/test_post_execution_pure_owner_values.py` is inspect-first and may change only if the existing fixed V40 fixture registry cannot express a coherent two-observation owner graph without a localized fixture successor. Do not change the V40 schema or profile to make the test easier.

The prior causal, status, and structural test scope remains authorized. No new repository file is permitted.

### 4.3 Documents

The prior owning-document scope remains authorized. The C2A source/observation-kind matrix is already correct and is inspect-only:

```text
.docs/c2a-first-slice-semantic-protocol-contract.md
```

Do not change it to place `candidate_ref` on `worker_completed` or to require `candidate_captured`.

### 4.4 Partial-attempt use

After authenticating Input C, you may inspect and reuse sound portions of `blocked-partial-source/` as implementation evidence. Do not copy it wholesale over the live source and do not treat tree `2df948...` as a candidate. Reconcile every adopted hunk against the exact F1 base, this amended relation, and the complete prior mandate.

The pre-edit 14-member compatibility vector in Input C may be reused as the fixed predecessor anchor after its source binding and duplicate identity authenticate. Do not rerun it merely to recreate the same anchor. Final three-observation equality remains mandatory.

---

## 5. Required direct pure-owner controls

Before relying on the connected end-to-end positive, add direct causal coverage for the pure relation:

1. **Two-observation positive:** a coherent rank-13 worker-result owner graph with exact `worker_started, worker_completed`, no candidate fields on `worker_completed`, parent capsule candidate equality, review capsule equality, and two V40 locators passes as `separate/governed_review_graph_separate`.
2. **Three-observation compatibility positive:** the existing V40 owner graph remains byte/semantic compatible and continues to require ordinal-1 `candidate_captured` equality.
3. **Two-observation worker-result candidate mismatch:** reseal/reconstruct the rank-13 binding and dependent owner rows so its candidate differs from the parent capsule; reject at `source_owner_mismatch`.
4. **Two-observation review candidate/capsule mismatch:** reject at the relation owner.
5. **Three-observation captured-candidate mismatch:** preserve the existing rejection at the relation owner.
6. **Illegal synthesized field:** demonstrate through the existing WorkerObservation owner/control that `worker_completed` with `candidate_ref` remains invalid; do not add a production workaround.
7. **Locator cardinality/order:** two and three exact ordered locator sequences pass; one, four, duplicate, omitted, inserted, or reordered sequences remain rejected at the appropriate owner.

For every negative, record the reached predicate. Do not award causal credit to a masked downstream check.

These controls supplement rather than replace the prior first substantive checkpoint and finite Unit 2 controls.

---

## 6. First substantive checkpoint and complete Unit 2 behavior

The prior §11 checkpoint remains mandatory. The two-observation connected positive must now demonstrate that the repaired pure reviewer-separation owner succeeds without violating the C2A conditional-field rule, then continues through:

```text
D1 parent capture
→ D2 A with the legal 13-member layout
→ D2 B
→ Section 41 transaction A
→ C1 rank-15 transaction B
→ checked readback
→ unchanged V22 projection
```

Retain all prior requirements for:

- the unchanged three-observation 14-member vector;
- validator/reviewer typed invalid-evidence stops;
- donor command/safe-basis refusal before target writes;
- 13/14 historical readback without child/model rerun;
- exact reached prefixes, cleanup, uncertainty, replay, and privacy limits.

Save, reopen, and verify the checkpoint before broad validation.

---

## 7. Focused validation amendment

The prior focused selector remains mandatory and must add these exact modules:

```text
tests/test_post_execution_pure_owner_relations.py
tests/test_post_execution_pure_owner_values.py
tests/test_c2a_first_slice_semantic_protocol_contract.py
tests/test_worker_execution_semantic_values.py
tests/test_rw0_b2_wire_values.py
```

Retain the already selected:

```text
tests/test_post_execution_pure_owner_boundaries.py
tests/test_post_execution_pure_owner_vectors.py
```

Collect and execute the deduplicated focused union once each on the final authenticated external source. Retain exact node IDs and JUnit.

Then perform the unchanged selector-free collection and FULL execution requirements from the prior mandate. Historical partial, three-observation-only, earlier-source, failed, interrupted, or masked runs receive no final credit.

The exact final test count is discovered, not prescribed. Require exact collected/executed ID equality and zero failures, errors, or skips.

---

## 8. Provenance and final subject

Start from the exact restored F1 tree `93af...`. A completed Unit 2 implementation must produce a new 299-file tree identity.

Retain:

- all fourteen F1 paths byte- and mode-identical to Input A;
- the exact thirteen created-path inventory;
- the unchanged v3 collector and current authoritative/diagnostic-ref policy;
- two byte-identical final captures plus one equal post-cleanup capture;
- the exact Unit 2 delta from `93af...`;
- the cumulative delta from original tree `17ee...`;
- the blocked partial and blocker records as historical evidence, not final source.

The final review package must contain the complete final source, direct pure-owner controls, first checkpoint, final vector comparison, focused/FULL records, provenance, cleanup, and explicit nonclaims.

---

## 9. Stop conditions

All prior stop conditions remain. Also stop if:

- the two-observation path requires changing the C2A conditional-field matrix or WorkerObservation schema;
- the implementation requires synthesizing `candidate_ref` on `worker_completed`;
- the pure owner can pass only by removing the parent-capsule/rank-13/review candidate association;
- V40 schema/profile/digest grammar must change;
- a new production, test, or document path is required;
- a direct pure-owner negative is masked and no bounded existing-file test can reach the intended relation;
- the three-observation V40 behavior or pre-edit command/safe-basis vector changes;
- any frozen F1 path changes;
- final focused or FULL validation is incomplete or fails.

Return:

```text
POST_D2_UNIT2_BLOCKED
```

with exact completed and unperformed coverage. Do not weaken the requirement or create an invalid observation to proceed.

---

## 10. Required final report

Return one of:

```text
POST_D2_UNIT2_IMPLEMENTED_VALIDATED_PENDING_REVIEW
POST_D2_UNIT2_BLOCKED
```

In addition to the prior report requirements, include:

- the exact pure-owner source change and why it preserves the C2A grammar;
- direct two-/three-observation V40 controls and their reached predicates;
- confirmation that `worker_completed` still carries no candidate/capsule conditional fields;
- exact use or rejection of the retained eight-file partial attempt;
- final source tree and complete changed-path inventory;
- focused and FULL collection/execution reconciliation;
- F1 byte preservation and v3 provenance identities.

End with:

```text
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
MERGE_NOT_PERFORMED
PUBLICATION_NOT_PERFORMED
```
