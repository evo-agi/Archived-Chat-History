**The stop was correct under the prior file ceiling, and a narrow scope amendment is sufficient.** No new reconnaissance, schema change, F1 change, or broader contract redesign is needed.

The blocked package authenticates completely. It preserves the exact F1 base tree `93afef8750e062d80626a5a37adfa27766305b7c`, records an eight-production-file partial attempt as evidence only, and confirms that the live checkout was restored with all fourteen F1 paths unchanged. POST_D2_UNIT2_BLOCKED_REPORT

The blocker is exactly where Codex reported it: the C2A contract legally permits `worker_started, worker_completed`, with no `candidate_ref` on `worker_completed`, while the pure reviewer-separation owner treats the last worker observation as the capture observation in the two-observation case. The existing parent capsule and rank-13 worker-result binding already carry the candidate association. Synthesizing a field or bypassing the relation would be wrong. POST_D2_UNIT2_BLOCKED_REPORT

## Next Codex handoff

Send **only this prompt** to the **same Unit 2 implementation Codex conversation**, with write permission:

:chatgpt-content-reference{index="3"}[**Coordinator Unit 2 pure-owner scope amendment and continuation**](sandbox:/mnt/data/Coordinator_Unit2_Pure_Owner_Scope_Amendment_and_Continuation_Prompt.txt)

Do not send the prior Unit 2 prompt alongside it. Do not send it to the independent auditor, Opus, or a new ChatGPT conversation.

The replacement:

- Starts again from the restored F1 tree, not from the incomplete partial source.
- Authenticates the blocked package and incorporates its exact prior `mandate.txt`, so you do not need to assemble prompt fragments.
- Preserves all previous Unit 2 obligations: legal 13/14 layouts, typed invalid-evidence stops, original-run witness association, first substantive checkpoint, finite controls, final focused validation, selector-free FULL, F1 preservation, and v3 provenance.
- Adds exactly one production owner to the authorized scope:

  ```text
  src/ge_nwp_coordinator/_post_execution_evidence_values.py
  ```

- Adds its direct existing pure-owner tests.
- Keeps the C2A observation grammar unchanged. `worker_completed` remains prohibited from carrying candidate fields.
- Requires the two-observation relation to bind candidate identity through the parent capsule, the rank-13 worker-result binding, and the independent-review observation.
- Preserves the existing three-observation `candidate_captured` check and byte-compatible path.
- Permits selective reuse of the eight-file partial attempt only after authentication; it may not be restored wholesale or treated as a candidate.
- Expands the focused selector to include the direct pure-owner relation, C2A, WorkerObservation, and Wire grammar tests before the final FULL run.

No migration, physical schema, V22, D1 Wire, WorkerObservation schema, new repository file, or F1 change is authorized.

:chatgpt-content-reference{index="4"}[Static package review and engineering rationale](sandbox:/mnt/data/Coordinator_Unit2_Blocker_Static_Review.md)

The operative prompt is **15,979 bytes**, SHA-256:

```text
3ad622217e091c5fb2b7e07aea50ff5d266dd32cfad7a9cd9f9c970b21bfc8ac
```

The incomplete partial remains evidence, not implementation credit. Codex performed no surviving repository mutation, final checkpoint, focused gate, FULL run, staging, commit, or publication in the blocked attempt. POST_D2_UNIT2_BLOCKED_REPORT

**Sources:** Attached blocked report and authenticated blocked evidence ZIP; exact source and contract inspection recorded in the linked static review.

**Confidence:** package provenance **0.99**; blocker diagnosis **0.99**; amended scope **0.97**. Unit 2 implementation and runtime correctness remain unestablished.
