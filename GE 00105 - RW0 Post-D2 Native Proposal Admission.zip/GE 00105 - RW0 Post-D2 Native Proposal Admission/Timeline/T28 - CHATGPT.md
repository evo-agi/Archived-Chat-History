**Send this one prompt to the original native-proposal/admission implementation Codex conversation, with write permission—not the independent auditor, Opus, or a new ChatGPT conversation.**

:chatgpt-content-reference{index="3"}[**Download the F1 governed recovery-entry repair prompt**](sandbox:/mnt/data/Coordinator_F1_Governed_Recovery_Entry_Repair_Prompt.txt)

The prompt resumes that writer **only for F1**, after it authenticates the preserved candidate and checks the live checkout. It contains the required instructions and identifies the existing local inputs; no other prompt fragments need to accompany it.

## What this authorizes

Implement the narrow recovery-entry correction across the five selected production files, their owning documentation, and directly dependent tests. The existing authority-lock and connection owners remain in place.

The governing distinction is **storage recovery versus writer issuance**. SQLite’s `SQLITE_READONLY_ROLLBACK` identifies a database requiring rollback that cannot proceed through a read-only connection; it is not itself evidence that the database has a valid managed schema. [SQLite](https://www.sqlite.org/rescode.html) The prompt therefore requires observational inspection to remain non-mutating, recovery eligibility to be checked under the existing lock, and schema, identity, and issuance checks to succeed before returning a writer.

It also makes the auxiliary-file boundary explicit. The implementation must not substitute an unrestricted writable open, manually delete a journal, or report “nothing changed” after recovery altered storage but subsequent schema validation refused issuance.

**All five migrations, the physical schema, DELETE/FULL policy, domain transactions, and D2/native-continuation code remain unchanged.** F2, F4, malformed-input F5, and `NPA-WITNESS-01` are not included in this repair.

## Required evidence and return

The first substantive checkpoint must demonstrate a **genuine engine-recognized recovery-required fixture**, observational no-write behavior, repaired acquisition, and a discriminating refusal. A mocked exception alone cannot establish the repair. The fixture and any controlled child termination are confined to newly created synthetic state and task-owned processes; there is no live-database recovery or production crash experiment.

Codex must then complete the bounded regression controls and **one final selector-free collection and full-suite execution**, entirely in authenticated external source copies. It must return a reopened review package containing the complete successor source, the **F1-only delta against the original candidate**, validation records, and preservation evidence. That is implementation validation—not the outstanding independent audit.

## What remains held

The original candidate remains preserved and unaccepted. The working checkout may become a newly identified F1 successor; it must not retain the original candidate’s identity.

**F1 completion alone will not lift the whole correctness hold.** The second repair unit and the unfinished candidate-specific audit remain outstanding. Both historical provenance mismatches stay recorded, and the scoped protected-state/diagnostic-ref distinction remains explicit rather than reverting to a fixed total-ref count. The retained audit records establish that A01–A12 and independent execution were not reached. audit_report

No staging, commit, publication, audit retry, or reviewer assignment is authorized. A provider refusal or unavailable required validation step must produce a truthful incomplete result, not weaker evidence presented as success.

I saved and reopened the handoff, rechecked the package’s 544 manifest-covered members, and independently reconstructed the original 298-file candidate tree. I did not execute repository code, tests, databases, or uploaded programs.

**Sources:** Authenticated `ReviewPackage.zip`, particularly `sqlite_writer_session.py:7184–7327`, `sqlite_connection.py:408–434`, and `sqlite_security.py:69–104`; SQLite’s recovery documentation cited above; retained audit noncoverage.

**Confidence:** provenance **0.99**; repair scope and handoff **0.96**. Repair correctness and runtime validation remain unestablished.
