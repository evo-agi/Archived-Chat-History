COORDINATOR — TARGETED F1/F2/F4/F5 EXISTING-EVIDENCE ADDENDUM

Recipient: the original Opus reviewer who authored “Governed Execution Audit: Round 1,” in that same review conversation. This is one complete evidence-follow-up assignment, not a Codex prompt or a transfer of the unfinished candidate audit.

1. PURPOSE AND PRESERVED STATE

The project owner authorizes a bounded, defensive review of your existing records for F1, F2, F4 and F5. Supply the evidence needed to verify or qualify the reported reproductions and select a later repair scope. Do not perform another audit, new experiments, implementation, or reconstruction of the entire historical package. Disagree with the engineering triage where original evidence warrants it; this is not a request to confirm predetermined conclusions.

Your report names merged Coordinator trunk_dev at eac7f6d. The recorded comparison baseline is commit eac7f6df5f281138dd0640c5cd47b9924c8390f8, tree 061c43c41228310134a30f3b79291bba3e44f3f2. The supplied audit-round-1.md identity is 16,967 bytes, SHA-256 f9355a10fa9038030296c0f08b1f0d46019e9253a772859f1dab58bff4d7b251. These are comparison anchors, not proof of what your original probes inspected. Do not fill an absent historical source identity from these values.

The separate uncommitted native post-execution proposal/admission candidate remains frozen and unaccepted: candidate tree 17ee7db2925ed03ebc1614880fba5ec83d102d8c, branch codex/post-d2-native-proposal-admission-v1, based on the merged baseline. Its ReviewPackage.zip is 14,481,457 bytes, SHA-256 d9b4d61e212893b48ba1952c3b5370c09874ca2e70798decc36bc4fdbd893d9b. Its implementation writer stays idle. Do not inspect or modify that candidate for this assignment.

The consolidated Coordinator_Post_D2_Operative_Independent_Audit_Mandate.txt was submitted to Codex and rejected before your report arrived. Audit access remains unresolved; no retry is requested. Rejection proves neither completed coverage nor zero tool execution. Both historical provenance-mismatch dispositions and their limits remain recorded. The candidate-specific protected-state/diagnostic-ref distinction remains selected, not proven executed. A01–A12, connected proof, discriminating controls, and independent collection/FULL obligations remain outstanding. Your separately commissioned baseline review and this addendum do not replace them or confer candidate acceptance.

Engineering triage found source support in the merged baseline for F1, F4, and malformed-input F5, while qualifying F2's runtime/power-loss interpretation and the clock concern. Your reproduction materials have not yet been inspected by that triage. The correctness hold is independent of provider access. This follow-up neither lifts it nor assumes each baseline mechanism persists in uninspected successor bytes.

The coordinating ChatGPT conversation continues 00077 through an exported archive, not dependable cross-chat memory. No other chat or numbered export-turn reference is required to understand this assignment.

2. AUTHORIZED OPERATIONS AND LIMITS

Use only your already-retained round-one report, tool transcript, known evidence directory, scripts, patches, traces, logs, environment records, and historical source copies. Read scripts and source as inert text. Limited file reading, hashing, safe copying, excerpting and packaging are authorized, together with writing the addendum outside any repository and without overwriting originals. Any helper used for those data-only tasks must not import or execute repository or probe code.

Do not run tests, imports, fixtures, migrations, SQLite queries/connections, product/probe child processes, crash/signal experiments, journal restoration, patch application, or EXTRA/WAL trials. Do not issue new repository/Git, host-inspection, service, network or provider commands, even to fill an environment gap. No installation, cleanup of old evidence, repository mutation, staging, commit, publication or audit retry is authorized. Do not turn unavailable records into an instruction to rerun them.

Locate materials only through their known retained locations and your original visible records; do not search unrelated repositories, home directories or hosts. Preserve originals. Do not deliver credentials, private operational data, database/journal images or unrelated logs. Supply safe synthetic output excerpts instead. Label every redaction, omission or excerpt and its effect on verification; a derivative's hash is not the original's hash. If safe disclosure is impossible, identify the limitation without exposing the material.

3. ORIGINAL SOURCE AND EXECUTION BINDING

First identify the source actually used for each relevant probe from existing records: full commit/tree or retained source identities when available, intentional scratch-copy changes, exact script/patch versions, original invocation, and its link to the returned output. Distinguish original measurements from hashes computed now on surviving files. A file's current presence does not prove it is the version executed historically. If only an abbreviated commit or narrative survives, say so.

Compare the original report with the supplied identity if the original bytes remain accessible. A differing copy does not invalidate every finding automatically: label the copy and identify which conclusions can still be supported. Do not recreate missing scripts, traces or outputs from memory or present a new reconstruction as an original record. Recollection may be labeled as such but receives no execution-verification credit.

The filenames below are labels from your report, not assertions of absolute paths or present availability. Provide only the relevant existing originals or bounded excerpts, preserving the information needed to understand chronology and contrary results. Missing evidence for one finding must not prevent reporting the others.

4. FINDING-SPECIFIC EVIDENCE

F1 — Hot-journal recovery entry

Inspect commit_point_kill.py, acquire_child.py, wedge_entrypoints.py, and the corresponding retained invocation, trace and returned outputs. Establish exactly where the original interruption occurred relative to journal unlink, including whether the syscall completed, was prevented, or cannot be located from the retained trace. Separate script intent from observed termination.

Show the recorded sequence and results for inspect_database, validate_database, initialize_database, migrate_database and acquire_sqlite_writer_session, including actual error/classification information and any retries already performed. Identify intervening opens or other operations that could have changed recovery state. Separately identify the original manual read/write-open observation and subsequent integrity/issuance observation, if retained. Do not treat that diagnostic operation as an approved repair or claim all entry points were observed when only some have records.

State what is established about recovery being unreachable through supported entry points, what is source reasoning, and what remains unverified. No new database open is permitted.

F2 — Commit durability trace and restored-journal simulation

Inspect power_loss_sim.py, d1_fixed_root_child.py, results/one_commit_syscalls.trace, and their relevant original invocation/output. Supply existing records of the Python/SQLite version and build, VFS selection, filesystem/mount, VM/storage posture and tracing configuration only to the extent recorded. Unknown settings remain unknown; do not assume filesystem defaults or inspect the current host to backfill them.

For the commit trace, retain enough original context to associate relevant file descriptors, sync/unlink calls, return values and process identities. Explain whether the trace's filters and boundaries support the claimed absence of a directory sync after unlink. If they do not, narrow that observation rather than infer a complete syscall history.

For the simulation, identify the original evidence associating the selected unlink with the C1 phase commit; the copied journal and restoration steps as described in existing records; the worker/capsule outcome; and the recorded before/after phase-row observations. Do not supply database/journal images or query them again.

Separate syscall observation, deliberate simulated disk state, and inference about real power loss. No actual power-cut result, second author invocation, renewed allowance or second acceptance may be inferred from the reported missing phase. Any stronger original observation must be cited explicitly. Do not test or select a repair here.

F4 — Legal two-observation worker result

Inspect d1_probe.py, d2_probe.py, probes/two_observation_worker.patch, and their actual retained outputs. Provide the exact patch and source binding, the worker observation sequence, parent-owned candidate capture/classification evidence, and the D1 and D2 outcomes with the relevant failure stack. Distinguish separate probe runs rather than implying they were one execution.

Determine from those records which cardinality/positional consumer failed and what input reached it. Absence of candidate_captured is not itself an explicit negative claim that no candidate exists; identify any actual contrary field or narrow that wording. Include an already-retained ordinary three-observation comparator only if one exists. Do not generate a new comparator or apply the patch again.

F5 — Malformed checker input; separate timestamp case

Inspect the relevant d2_probe.py records and probes/malformed_validator.patch. Provide the exact synthetic bad frame or a safe faithful representation, recorded child exit result, normalization failure/stack, and caller outcome. Distinguish observations of retained-prefix loss or disposal from conclusions drawn solely from exception-handling source. State whether any typed stop actually returned; do not substitute a harness failure for a product-boundary failure.

Separately inspect probes/worker_clock_ahead.patch and its original invocation/output. Identify the actual entry point, which timestamp was altered, the recorded comparison and exception, and how the offset was produced. Distinguish a synthetic timestamp adjustment from measured cross-host clock skew. Include only already-existing cleanup/state observations; do not simulate clocks again or extend this into remote-host validation.

5. ADDENDUM AND DELIVERY

Return one concise addendum organized as: original source/evidence binding; F1; F2; F4; F5; missing records and consequences. For each finding distinguish observed original output, script/source inspection, simulation and inference. Cite actual retained filenames and line/event ranges, including any contradictions. Say whether the available evidence supports, narrows, revises or leaves unverified the reported reproduction. A successful inspection now is not a newly executed probe.

For each unavailable record, name what is missing and the exact claim or decision it prevents. Do not infer that the original execution never occurred, erase independently supported source findings, or mark the whole engagement failed because one attachment is missing. Do not replace missing runtime evidence with general documentation. Conversely, do not certify a reproduction from its report narrative alone.

Deliver ADDENDUM.md and the minimum safe supporting originals/excerpts in one downloadable ZIP where supported. Put a simple file index in the addendum: filename, original locator, evidence purpose, whether original or derivative, and current byte size/SHA-256. No new evidence framework, custom provenance recipe, full source dump or historical-package rebuild is requested. Reopen the deliverable to confirm it contains the stated files; this checks delivery, not historical execution. If attachment/export capability is unavailable, return the completed addendum and precise availability limits without inventing a downloadable artifact.

Conclude with what this existing-record inspection resolved and did not resolve, and a truthful statement of operations performed. Do not issue candidate ACCEPT, claim A01–A12/FULL credit, repair source, or prescribe new experiments as if already authorized. Preserve the original report and earlier positive evidence; there is no request to rerun its random-kill campaign or reopen F3/F6/F7. Engineering will assess any later repair or audit-coverage transition separately.
