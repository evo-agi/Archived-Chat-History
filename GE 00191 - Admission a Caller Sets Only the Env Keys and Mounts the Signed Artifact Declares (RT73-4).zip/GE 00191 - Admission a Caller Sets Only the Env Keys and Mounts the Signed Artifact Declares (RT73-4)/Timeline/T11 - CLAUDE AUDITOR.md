Audit the caller injection fix
