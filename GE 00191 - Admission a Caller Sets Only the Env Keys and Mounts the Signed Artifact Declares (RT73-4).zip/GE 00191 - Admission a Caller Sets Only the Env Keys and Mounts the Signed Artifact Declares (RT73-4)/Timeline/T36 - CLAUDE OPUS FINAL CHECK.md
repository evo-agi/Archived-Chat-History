**Re-check 25 (Opus) on PR #74 at e0b5c89: BLOCK.** One low finding and one docs nit. Every claimed fix holds, and so does the #69 merge resolution.

**What holds**
- **Provenance:** my manifest matches writer report 24's byte for byte, and the closing run matches the opening one.
- **The merge:** comparing each changed line of the PR and of #69, the only difference is the expected one. The PR's three-line edit moved from PLANS.md into the standing rule. A test guards it.
- **The fixes:** `TEXTDOMAINDIR`, `TEXTDOMAIN` and `LANGUAGE` are reserved. The upstream glibc 2.39 and 2.42 source confirms the reason the PR gives for `LANGUAGE`. `GCONV_PATH` is credited. The `INSECURE_SKIP_VERIFY` suffix is in place, and the runbook text is accurate.
- **Tests:** I ran the full suite on the exact bytes of both trees as an unprivileged user. The same 17 tests fail on head and base, all environment-only. The 18 new tests pass.
- **Mutants:** 11 of my 12 mutants are killed. The one that survives is runbook text, which no test reads.
- **Red-team 19's probes:** all 8 pass at the head (102 keys reserved, 5 still admitted when declared).
- **CI on e0b5c89:** Linux and macOS are both green.

**F1 (low):** the contract now describes the Go and gcc keys as whole categories, without the earlier "best-known" hedge. Five keys in those categories are still open, all from the sources the PR itself names:
- `FC`, `PKG_CONFIG` and `GCCGOTOOLDIR` come from `go help environment`. Each names a program the go command runs. I confirmed that `go build` runs `PKG_CONFIG` and `FC`, using only system binaries.
- `LPATH` and `OBJCPLUS_INCLUDE_PATH` come from gcc 13.3.0. I confirmed that `LPATH` adds library directories just as `LIBRARY_PATH` does.

The fix is five entries in the reserved list plus the same five in the test that pins it. I tested that change: the affected tests pass with the contract unchanged. Those two sources have no other keys in these categories, so another round on this wording should find nothing new.

**N1 (nit):** the new `LANG`/`LC_ALL` sentence sits just before "It is a backstop", so "It" now seems to point at the locale keys. Moving the sentence fixes it, with no test change.

The report also has four observations that need no change.

Report: `25-pr74-recheck-opus.md` (SHA-256 `570172882c835a7e9fda3ca036a1fa0813afba68b38e74979da46cd10a31fd44`), with evidence in `25-pr74-recheck-opus-evidence/`. I pushed nothing and posted nothing on GitHub, and I did not read the paired Sonnet report.

STATUS: READY (re-check delivered with verdict BLOCK on F1; nothing running)
