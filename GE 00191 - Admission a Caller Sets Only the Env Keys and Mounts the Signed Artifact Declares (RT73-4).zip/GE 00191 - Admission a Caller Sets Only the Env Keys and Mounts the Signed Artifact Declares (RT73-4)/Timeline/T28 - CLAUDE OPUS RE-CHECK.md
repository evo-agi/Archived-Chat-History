**CI on 9c06790 is green on both Linux and macOS.** The test gate passed (50 packages), all 14 self-skips are listed, the es/app Docker flows ran, and no test outside the list failed. That doesn't change re-check 23: its verdict for 9c06790 stays BLOCK.

The PR head has already moved to `978bccb`, where the writer committed fixes for R1 and R2, and trunk_dev has moved to `0b9278c`. Neither re-check 23 nor this addendum covers that head. It needs a fresh re-check, run in a thread that hasn't audited this PR. Its CI was still running at 11:01 PM Eastern.

Addendum SHA-256 `8da009274e751af25fc90970660adc3c7474c91e30a87917c364aba20d16793e`.

STATUS: READY (this re-check is finished; the new head 978bccb awaits a fresh re-check)
