Network grants are up as [PR 73](https://github.com/evo-agi/Execution-Substrate/pull/73), so its audit and red-team are starting.
