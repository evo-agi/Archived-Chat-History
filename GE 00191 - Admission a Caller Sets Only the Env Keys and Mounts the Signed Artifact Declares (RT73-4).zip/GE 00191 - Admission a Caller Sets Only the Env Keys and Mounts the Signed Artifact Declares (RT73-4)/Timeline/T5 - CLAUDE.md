I'm starting the fix that stops callers injecting their own code into granted runs.
