PR #74 is repaired and pushed. The new head is `9c06790` (base `trunk_dev` at `a5861b7`), ready for the narrow re-check. All four Lows are fixed:

- **RT74-1:** the backup list now blocks whole families (`VAULT_`, `XDG_`, `OPENSSL_`, `NPM_CONFIG_`, `JAVA_`, `RUBY` and others) plus single keys such as `WORKLOAD_VAULT_INSECURE_SKIP_VERIFY` and `GODEBUG`. 87 of the 94 keys the red-team found open are now blocked. The other 7 are locale and Go tuning keys, which load no code.
- **RT74-2:** added the red-team's test for reliable submit's retained-request check.
- **A1:** the docs and comments now credit sudo correctly.
- **A2:** reworded the stale standing-rule line, and the docs test now catches it.

A full test run on the new head shows no new failures. CI is running, and I'm watching it. Details are in report 22, which includes the manifest. `mount_targets` stays as the name.

STATUS: PR #74 at `9c06790` needs the narrow re-check and green CI, then the merge gate.
