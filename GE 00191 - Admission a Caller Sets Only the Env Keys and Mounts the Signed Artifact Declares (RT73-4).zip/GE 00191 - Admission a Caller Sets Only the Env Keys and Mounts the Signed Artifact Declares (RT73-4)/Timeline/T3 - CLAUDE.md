The proper solution is that the owner's config decides network access for each combination of *who runs it* and *what runs*. Nobody else gets a say: not the publisher's request, and not whoever happens to be admitted. Concretely:

1. **Grants match the caller as well as the publisher.** A grant names who may run what with network, so Claude gets network only where a grant names `user/claude`.
2. **AGS stops copying "network access" from the publish request into the signed claims unchecked.** Today any caller can publish its own networked artifact, and ES's grant check becomes the only gate for that.
3. **Callers can't inject code into a granted run.** An artifact with an empty environment list should mean "no caller variables", and mounts should be limited the same way. Otherwise a caller with the right grant could still swap in its own `python3` through `PATH`.

My plan: 1 and 2 go into the network grants work before PR 70 merges, and 3 gets its own PR, also before Claude gets box access. It's slower, but it closes the hole rather than documenting it. Shall I go ahead?

STATUS: NEEDS DAVID (go-ahead on caller-keyed grants plus the two fixes above)
