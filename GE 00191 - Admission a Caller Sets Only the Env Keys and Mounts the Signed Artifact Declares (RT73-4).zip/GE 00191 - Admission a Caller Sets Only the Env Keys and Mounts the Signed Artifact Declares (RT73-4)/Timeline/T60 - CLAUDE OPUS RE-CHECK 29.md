Re-check 29 of PR #74 at 10a3b58: **ACCEPT**, no findings. `VSB_DIR` is now reserved and pinned. The guard holds within the limits it states: all 25 mutants were killed, and the only gaps are the two its comment names. The open-keys paragraph is pinned as a whole. The root and es/admission packages pass on head and on 0e56e23 with 0 failing tests, and also in a tree without .git. CI is green on both jobs, and provenance matches the writer's manifest.

STATUS: READY (report delivered; nothing running)
