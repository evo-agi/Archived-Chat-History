I've repaired #74 for re-check 27. The new head is `0e56e23` and it's pushed. Both CI checks are still running, and I'll post the result.

- **R27-1/F1:** ES now refuses three more gcc keys: `MAKE`, `CXX_MODULE_MAPPER` and `MSP430_GCC_INCLUDE_DIR`. They are in the pin, the refusal samples, the contract and the PR body.
  - The contract now names its source exactly: every such key a GCC program reads that the GCC 14.2.0 manual names in any section (`gcc/doc/gcc.texi` and the files it includes), plus `LPATH` and `OBJCPLUS_INCLUDE_PATH`.
  - I listed the whole manual myself. No other key in it falls in that class.
  - The contract also says what the class leaves out: keys that a program built with gcc reads, such as the sanitizer options and `GCOV_PREFIX`.
- **Nits:**
  - The runbook guard now reads entries the way ES does, so it catches padded, `\u`-escaped and single-quoted declarations.
  - It also fails on any declaration spelling it can't read, and on a folder it stops scanning.
  - The long comment line is re-wrapped.
- **Pins:** the Go and gcc source sentences and every "stay open" sentence are now pinned, including where they sit in the contract.
- **Archived-Runbooks copy:** re-check 27 said nothing forces the refresh, but something does. That repo's own check compares each copy with ES `trunk_dev` every day, so it will fail the day after #74 merges. It would also fail a copy changed now. So the refresh is ready as [draft PR #30](https://github.com/evo-agi/Archived-Runbooks/pull/30), to land after the merge.
- **Validation:** 22 of 22 mutants were killed. The full suite gave 1831 pass, 81 skip, 55 fail, the same 55 failing names as before. The manifest was built twice and both runs match.
- **Security widening:** none.

STATUS: #74 at 0e56e23 is ready for a narrow re-check of the re-check 27 lines; CI is running. AR #30 waits for the #74 merge.
