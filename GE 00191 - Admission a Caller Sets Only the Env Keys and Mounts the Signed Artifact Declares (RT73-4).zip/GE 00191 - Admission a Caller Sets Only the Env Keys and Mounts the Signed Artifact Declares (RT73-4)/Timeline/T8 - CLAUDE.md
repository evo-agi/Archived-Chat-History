Done. Caller-keyed grants and the AGS fix are going into the network grants work, and the injection fix has its own thread. PR 70 waits for both.

And yes, I'll take the security lead. Whenever a decision does reach you, I'll explain it in plain terms: what could go wrong, who could do it, and what each option costs. Most of these I'll just handle, as with today's call to let the user CA sign only `user/` identities. I've saved that as a standing rule.

STATUS: WORKING (network authority fixes, plus audit fixes on PRs 66 to 73)
