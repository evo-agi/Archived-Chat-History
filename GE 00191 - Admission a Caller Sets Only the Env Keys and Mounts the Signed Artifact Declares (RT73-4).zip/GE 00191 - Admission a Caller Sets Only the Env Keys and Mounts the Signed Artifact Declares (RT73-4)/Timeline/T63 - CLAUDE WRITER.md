The new head on #74 is `4d7ed6d`. It's pushed, on top of `trunk_dev` be20ffc (#75).

- **N29-1:** I added Sonnet's two table cases: a single-quoted Python named escape, and a key name escaped with an upper-case hex digit. I also added cases for the two branches Sonnet called harmless (GM22 and GM24). All four mutants are now killed.
- **Merge:** the #75 merge had no conflict. The PR's own diff has the same `git patch-id` on be20ffc as on the old base, so the merge didn't change the change.
- **The delta to check:** `10a3b58..aa2b6a5` is one test file, +7. `aa2b6a5..4d7ed6d` is the merge.
- **Checks:** build, vet and the root package pass. The manifest was built twice on the new base and both runs match.
- **Still running:** the full suite here and CI. I'll add both results to report 30.

STATUS: #74 at 4d7ed6d is ready for your paired check of the delta. The full suite and CI are still running.
