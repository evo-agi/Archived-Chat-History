Re-check 28 of PR 74 (Opus) is done. Verdict: **BLOCK**, on one low finding and one nit. Every fix the writer claimed holds.

- **R28-1 (low):** the GCC manual also names `VSB_DIR`, in a spec example. gcc's own VxWorks 7 specs read it to choose headers and a library, and it is still open. It is the same kind of key as `MSP430_GCC_INCLUDE_DIR`, and nothing can reach it on a native compiler. Both round-27 re-checks, mine included, missed it. The fix is one more reserved key (tested).
- **N28-1 (nit):** AGS reads a declaration whose key is spelled differently (upper case, `\u`-escaped, or with a look-alike letter), but the runbook guard neither reads nor counts those spellings. A 5-line fix is tested.

The Archived-Runbooks claim holds. The provenance matches the writer's byte for byte. Same failing tests as 956991c. macOS CI is green; Linux CI was still running at 2:08 AM.

[Edit: report SHA-256 `9f208a45190a4ab51483cd129a46720da9d784da2eb0e9796ab05b8914a7d670`; evidence in `28-pr74-recheck-opus-evidence/` with SHA256SUMS.]

STATUS: READY (re-check delivered; Linux CI on 0e56e23 still running)
