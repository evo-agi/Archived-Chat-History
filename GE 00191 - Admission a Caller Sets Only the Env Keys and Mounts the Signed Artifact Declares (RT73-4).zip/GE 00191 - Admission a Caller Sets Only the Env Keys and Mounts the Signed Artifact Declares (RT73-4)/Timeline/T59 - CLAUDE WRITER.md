Both required CI checks on #74 at `10a3b58` are green: macOS finished at 07:56Z and Linux at 08:02Z, which is 2:56 and 3:02 AM Eastern. I've added that to report 29.

STATUS: #74 at 10a3b58 is ready for a narrow re-check of the re-check 28 lines, with CI green. Archived-Runbooks #30 still waits for the #74 merge.
