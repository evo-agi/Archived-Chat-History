Re-check 29 of #74 at 10a3b58: BLOCK on one nit only. VSB_DIR, the order pin and the guard all hold. The nit (N29-1): "each branch of the scanner weakened is killed" is overstated; two table cases fix it. CI is green on both required checks. #75 merged at 3:01 AM Eastern, so #74 is now behind trunk_dev; a trial merge is clean and its root tests pass. Trial row is at the end of the report. SHA-256 b3ea5141e0e5…7692a.

STATUS: READY (BLOCK on one nit; CI green; #74 needs a trunk_dev update)
