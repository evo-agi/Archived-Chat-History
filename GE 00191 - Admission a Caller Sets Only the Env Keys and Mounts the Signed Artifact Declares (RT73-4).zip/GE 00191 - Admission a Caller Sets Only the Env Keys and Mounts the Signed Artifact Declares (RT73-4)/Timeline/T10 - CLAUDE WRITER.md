PR #74 is open and ready for its fresh audit and red-team: https://github.com/evo-agi/Execution-Substrate/pull/74. A caller can now set only the settings, and mount only the folders, that the signed package itself lists. Nothing is needed from you unless you'd like a different name for one new field (below).

**The hole, in plain terms.** Whoever asks ES to run a package can pass environment variables and attach folders. Some variables, like `BASH_ENV` or `PYTHONSTARTUP`, make a program run extra code when it starts. A caller could use them, or attach their own files where the program reads code, to slip their own code into a run that had been approved for network access.

**What changed**
- **The package's signed list is now the main lock.** If the list is empty, the caller can set nothing. Mounts work the same way: the package has to name each folder path it accepts. The new list is called `mount_targets`.
- **A backup lock.** ES refuses about 75 known startup-code variables, plus whole families such as anything starting with `LD_` or `PYTHON`, even if a package lists one by mistake. No list like this is ever complete, which is why it's the backup and not the main lock.
- **One extra gap closed.** While fixing this, I found that a name containing `=` could sneak past the old checks, so names are now restricted to letters, digits and underscores.

**Tradeoffs**
- **Command-line arguments are still the caller's choice.** A package that treats its arguments as code can still be steered by them. Limiting arguments is a separate decision, and I'd wait until a package needs it.
- **Old packages keep working.** Their signatures still verify, and none of our scripts, examples or other repos sends anything the new rules refuse.

The full local test run shows no new failures against the base, and Codex found nothing. CI is running, and I'm watching it. I told the network-grants thread about the one small docs conflict with #73. The report is attached.

STATUS: PR #74 is open, CI is running, and the audit and red-team are next. Nothing is needed from you.
