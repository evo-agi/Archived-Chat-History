> Update while you were away: one design decision needs you, everything else is moving.


What is the proper solution here?
