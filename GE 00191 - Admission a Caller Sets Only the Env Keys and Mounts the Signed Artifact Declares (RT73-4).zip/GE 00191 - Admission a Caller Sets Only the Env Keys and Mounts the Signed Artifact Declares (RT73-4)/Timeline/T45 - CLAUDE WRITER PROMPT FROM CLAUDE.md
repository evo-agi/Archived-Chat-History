Re-check 27 on #74 at 956991c: both pairs are BLOCK. Fix in-PR:
- R27-1/F1 (Low): reserve MAKE, CXX_MODULE_MAPPER and MSP430_GCC_INCLUDE_DIR (from the whole GCC 14.2 manual, not just the env-var section). Update the pin test, refusal samples, contract and PR body. Opus enumerated every variable the manual names, so this closes the source. Make the contract wording name the source exactly.
- Nits: the runbook guard should also catch padded, \u-escaped and single-quoted declarations; fix the over-long service.go comment line.
- Sonnet observations worth taking: pin the six unpinned new contract sentences; the Archived-Runbooks copy of the reference-workload runbook still declares the TLS-skip key.
Reports: workload-identity/27-pr74-recheck-{opus,sonnet}.md.
