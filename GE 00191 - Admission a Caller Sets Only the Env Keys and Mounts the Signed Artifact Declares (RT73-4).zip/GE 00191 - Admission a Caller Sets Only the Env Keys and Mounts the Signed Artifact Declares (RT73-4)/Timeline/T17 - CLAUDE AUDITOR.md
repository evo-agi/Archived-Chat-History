**BLOCK on PR 74, but only for two low-severity wording fixes. The code is correct.** I pushed nothing and posted nothing on GitHub.

Report: [21-pr74-audit.md](/mnt/project-files/reports/Execution-Substrate/workload-identity/21-pr74-audit.md), SHA-256 `219c5ecd64d9c6483eab1eebde845071631583c8e7eeffe2107c562614400f9a`. The evidence and its checksums are in `21-pr74-audit-evidence/`.

**What holds** (checked at head f8bc3df):
- If a package lists no environment variables, callers can set none.
- A mount is allowed only at a target path the package signs, matched exactly.
- Packages signed before this change still verify unchanged. An older ES refuses the new field rather than ignoring it, so nothing gets quietly widened.
- No example, script or other repo is affected.

**How I checked:**
- I rebuilt both heads byte for byte from the provenance recipe.
- The full test suite shows no new failures against the base, and all 16 new tests pass.
- I made 20 deliberate breakages to the code: the tests caught 19, and the 20th makes no real difference to behavior.
- CI on Linux and macOS is green. The mount and network tests that only run in CI did run there and pass.

**Findings (both low):**
- **A1:** The contract and two code comments say some blocked variables come from sudo version 1.9.16p2. Seven of them (NODE_OPTIONS, GIT_CONFIG_* and others) were only added in later sudo versions.
- **A2:** One standing-rule doc still says the old "empty allowlist behavior" remains in force. The docs test misses that wording.

**Before merge:**
- Main trunk has moved on (the layout PR merged), so the writer has to merge it in again. I tried that merge myself: it applies cleanly, the change itself is identical, and no tests newly fail.
- You still need to agree to the new field name `mount_targets`.

After the repair, a quick re-check of just the changes is enough.

STATUS: READY (audit delivered; the fixes go to the writer thread)
