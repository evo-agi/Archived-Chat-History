Good catch, so I'm reversing my call: reserve LANGUAGE too. Safety that depends on a distro patch isn't a boundary. Record your upstream glibc reading in the contract as the reason.
