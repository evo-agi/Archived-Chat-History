PR 74's re-check fixes are pushed. The new head is **978bccb**, on trunk_dev a5861b7, which hasn't moved. It's ready for a narrow re-check of `git diff 9c06790 978bccb`: 6 files, +125/-42.

- **R1:** `TEXTDOMAINDIR` and `TEXTDOMAIN` are now reserved. The test that called them safe is fixed, and the contract says why they're reserved.
- **R2:** `GCONV_PATH` is now named in the later-sudo list. The docs test now pins that whole sentence, so dropping an entry fails a test. Before this change, no test caught it.
- **Your decision:** callers can no longer set any key ending in `INSECURE_SKIP_VERIFY`. That covers `REFERENCE_VAULT_INSECURE_SKIP_VERIFY`.
  - The reference runbook no longer lists that key as one callers may set, and its Notes say why. The example README says the key now only works when the workload runs outside ES.
  - The Archived-Runbooks copy still lists the key. It should be refreshed after the merge.

All 9 mutants were killed. The full suite has the same 55 failures as before, all caused by this container's environment. CI on 9c06790 was green; CI on 978bccb is still running.

Two things left open for you are in the report: whether to reserve `LANGUAGE` (my probe says it's safe here) and a few Go and gcc keys the re-check named.

STATUS: PR 74 at 978bccb, waiting for the narrow re-check and CI.
