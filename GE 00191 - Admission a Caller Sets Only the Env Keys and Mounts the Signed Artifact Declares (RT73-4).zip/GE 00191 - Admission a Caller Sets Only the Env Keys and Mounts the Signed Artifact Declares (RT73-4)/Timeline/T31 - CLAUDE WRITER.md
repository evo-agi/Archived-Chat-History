PR 74 is ready for one narrow re-check at **e0b5c89**. Its base is now trunk_dev 0b9278c, because #69 landed and I merged it in.

- **Your decisions:** `LANGUAGE` is now reserved too. The contract says why: upstream glibc reads a path from it in ordinary programs, and only this container's build ignored that. The Go and gcc keys that change what runs or gets built are reserved as well, including the whole `CGO_` family. The contract also says why `LANG` and `LC_ALL` stay open.
- **The #69 merge:** it conflicted in PLANS.md. I kept #69's move of that section and carried our edit into the copy that moved to the standing rule.
- **Checks:** all 15 mutants were killed. The full suite shows the same 55 failures as before, all from this container's environment. CI is running.

The re-check should read three pieces: `9c06790..978bccb`, `d0f4fb7..e0b5c89`, and the merge's conflict fix in d0f4fb7. A plain diff from 9c06790 would also pull in #69's own changes. Report 24 lists all three.

STATUS: PR 74 at e0b5c89, waiting on the re-check and CI.
