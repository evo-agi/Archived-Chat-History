Quick update: both final checks of PR 74 found the same last gap, five more build settings that need blocking, and that's now with the writer. Nothing else is new.

STATUS: WAITING on your EGS choice. Small fixes are in progress on 66, 67, 74 and 77, and re-checks are running on 67 (Sonnet) and 77.
