Nothing needs you. All the fixes for PRs 66, 67 and 70 are in, and fresh checks are running on all three, including a red-team for 70. The revocation runbook is up as a docs PR and being audited. It surfaced a small bug, an upper-case digest that would silently not revoke, which is getting its own fix PR. PR 74 has two more gcc settings to block.

STATUS: WAITING on nothing from you.
