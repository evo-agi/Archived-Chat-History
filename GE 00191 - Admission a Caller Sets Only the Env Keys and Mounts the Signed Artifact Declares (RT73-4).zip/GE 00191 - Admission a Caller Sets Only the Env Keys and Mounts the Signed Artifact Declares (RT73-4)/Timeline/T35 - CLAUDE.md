Nothing new needs you beyond the governance read. The checks on PR 77 found three small gaps in its tests and description, and those are with the writer. Sonnet's check of PR 74 found one more environment setting to block, and I'll route it once the Opus check lands.

STATUS: WAITING on your read of the governance design. Small fixes are in progress on 66, 67 and 77, and checks are still running on 67 (Sonnet) and 74 (Opus).
