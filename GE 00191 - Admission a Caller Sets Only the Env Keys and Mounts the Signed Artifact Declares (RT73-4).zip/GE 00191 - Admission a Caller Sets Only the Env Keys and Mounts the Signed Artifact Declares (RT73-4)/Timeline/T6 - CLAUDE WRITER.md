First I'll map how ES applies caller environment variables and mounts to a run today.
