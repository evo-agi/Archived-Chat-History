PR 74's re-check 25 fixes are pushed at **956991c**. trunk_dev is unchanged at 0b9278c, so there was nothing to merge. The narrow check needs only `git diff e0b5c89 956991c`, which is 4 files.

- **F1:** `FC`, `PKG_CONFIG`, `GCCGOTOOLDIR`, `LPATH` and `OBJCPLUS_INCLUDE_PATH` are now reserved. Two additions go beyond F1:
  - `PKG_CONFIG` is reserved as a whole family, so pkg-config's search keys go with it. Both re-checks noted those keys can point a build at the caller's headers and libraries.
  - gcc's two dependency-file keys are reserved. They let a caller write text it chooses to a path it chooses.
- **Docs nit:** the stay-open sentence now comes after the boundary sentence. It also names the Go and gcc keys left open, and why.
- **Runbook text:** a new test fails if any runbook or example lists a reserved key as one callers may set. The runbook mutant that survived re-check 25 is now killed.

All 12 mutants were killed. The full suite has the same 55 environment-only failures as before. CI on 956991c is running.

STATUS: PR 74 at 956991c, waiting on the narrow check and CI.
