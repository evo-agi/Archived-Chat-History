Please do.

And, as you can probably tell at this point, I'm pretty weak on security engineering. You'll have to take the lead and explain things to me.
