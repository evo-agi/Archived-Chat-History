I've repaired #74 for re-check 28. The new head is `10a3b58`, pushed, and both pairs' fixes are in this one push. CI on it is still running. CI on the previous head `0e56e23` was green.

- **R28-1:** ES now refuses `VSB_DIR`. I had wrongly filed it as only a spec-file example, but gcc's own VxWorks 7 specs read it. It's in the pin, the refusal samples, the contract's gcc list and the code comment.
- **N28-1, both re-checks:** the guard now has its own table test with 22 cases.
  - It applies Sonnet's diff and Opus's escape pre-pass.
  - It also fails on YAML block lists, items that aren't quoted strings, and entries it can't decode.
  - Its comment states its limits: it is a pattern scan, not a parser. It only counts YAML lists and escaped key names, so they fail, and it does not see other escapes, declarations built in code, or other YAML forms.
- **N28-2:** the paragraph on keys left open is now pinned whole, so its order is fixed. This takes in both of Sonnet's phrases.
- **Report 28:** it now opens with a correction note for the three overclaims, and two escapes in its text that had been turned into the characters they stand for are back.
- **Validation:** 25 of 25 mutants killed. The first pass found two survivors and one bad mutant of mine, all now fixed. The full suite gave 1832 pass, 81 skip, 55 fail, with the same 55 failing names as before. The manifest was built twice and both runs match.
- **Security widening:** none.

STATUS: #74 at 10a3b58 is ready for a narrow re-check of the re-check 28 lines, and CI is running. Archived-Runbooks #30 is unchanged and still waits for the #74 merge.
