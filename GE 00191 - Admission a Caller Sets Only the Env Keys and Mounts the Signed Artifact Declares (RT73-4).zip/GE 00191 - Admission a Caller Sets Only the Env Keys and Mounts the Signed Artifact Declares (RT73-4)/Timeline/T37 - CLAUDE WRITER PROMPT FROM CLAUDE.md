The final checks of PR #74 at e0b5c89 are both BLOCK on one Low. Fix it in-PR:
- F1 (Low): reserve FC, PKG_CONFIG, GCCGOTOOLDIR (from go help environment) and LPATH, OBJCPLUS_INCLUDE_PATH (from gcc 13.3.0). Add them to the reserved list, the pin test, the refusal table, the contract and the PR body.
- Also fix the Opus docs nit (runbook text with no test reading it, per the report).
Reports: /mnt/project-files/reports/Execution-Substrate/workload-identity/25-pr74-recheck-{opus,sonnet}.md. Both say this closes the class for those two sources.
