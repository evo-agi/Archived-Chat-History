# Red-team of ES PR #74 (a caller sets only what the signed artifact declares, RT73-4): 19-pr74-redteam

Date: 2026-11-26, about 9:15 PM Eastern (02:15Z on 11-27). Thread: "Red-team the caller injection fix". This thread did not write or audit PR #74. Posture: read-only. Nothing was pushed, nothing was posted on GitHub, no Linux box and no live service were used. Evidence: `19-pr74-redteam-evidence/` (its `README.md` has the commands).

Source labels: "ran" means I ran it in this container on the commit named. "Read" means I read the code and did not run it. "Inference:" and "Guess:" mark the rest.

## Target

| Item | Value |
| --- | --- |
| PR | evo-agi/Execution-Substrate #74, branch `claude/project-thread-ef7st5` |
| Head | `f8bc3df20e1e3c17751edd1751010644733991ab`, tree `7e9fb159ca289962dfec392f384c83696a3ca362` |
| What the head is | A merge of `trunk_dev` at `fbfd100946d2cb8f25232bac182b94fb299c66da` (PR #72) into the writer's one commit `626c3cd7c163948ee7939f2f57ea7f271a79ae6f` |
| `git diff fbfd100 f8bc3df \| sha256sum` | `f3a44704c5c9fb52afe22f9c5d69e8bc2dd4a1fd6a13671553a158f35fc38fc6`, 28 files, +1159 / -71 |
| `git diff 39e19de 626c3cd \| sha256sum` | `523ff52c31a27b9471fc478330a6c0e68f19958b066dfab97efeed8cc14c46e3`, 28 files, +1159 / -71. This is the value in writer report 15. |
| Head checked again before writing | `git ls-remote` at 02:14Z: PR head is still `f8bc3df`, `trunk_dev` is still `fbfd100` |
| CI on the head at 02:14Z (GitHub, read) | "test on macOS" passed. "build, vet and test" was still running. |

**The head moved during this pass.** I began on `626c3cd`. `git diff 626c3cd f8bc3df` touches 13 files, all from PR #72, and none under `es/`, `ags/`, `ars/`, `internal/contracts/`, `.examples/` or `scripts/` (ran: `git diff --stat` on those paths is empty). I ran every probe again on `f8bc3df` and the numbers are the same. The mutant runs of the first half were at `626c3cd`; each file they change is byte-identical at `f8bc3df`. The one mutant a finding rests on (MN) I ran again at `f8bc3df`.

## Outcome

**I found no way to get a caller-chosen environment key, a caller-chosen mount, or through them caller-chosen code into a run unless the signed package declares it.** The signed declaration held as the boundary against 3,000,000 generated key names, 4,000 random requests checked at the Nomad job ES built, 18 spellings of the request body, 11 doctored registry records, and a record signed before the new field existed.

Three items remain. None is a bypass.

| ID | Severity | Type | In one line |
| --- | --- | --- | --- |
| RT74-1 | Low | security risk in the backstop, and one contract sentence that claims more than the code does | The reserved-key list misses most keys in the families the contract says it covers. I asked ES about 107 key names. 13 are reserved. ES put each of the other 94 into the job with the caller's value once a package declared it. One of the 94 is a switch that code in this repository reads to turn off the TLS check of the Vault connection. A publisher has to declare the key first, so the boundary is not affected. |
| RT74-2 | Low | test gap | The rule is applied in two places. The second one (reliable submit judging a retained request again) has no test: with that check deleted, all of `es/admission` still passes. Nothing in the running service calls that path today. |
| RT74-3 | Report only | known, deferred decision | `argv` is not bounded, as the writer said. It reaches only the package's entrypoint and cannot change the options of ES's supervisor. No example package in the repository reads its arguments. |

Per the standing rule that Low items are fixed in the PR: RT74-1 needs a list change, one reworded sentence and a test. RT74-2 needs one test, which is in the evidence folder ready to add.

## RT74-1 (Low): the reserved-key backstop misses the families the contract says it covers

**What.** PR #74 has two layers for environment keys. The boundary: a caller may set only a key the signed package declares. The backstop: a list of reserved keys ES refuses even when a package declares them, so that a publisher's mistake does not hand a caller the run. The contract is honest that the list cannot be complete ("It is a backstop for a publisher's mistake, not the boundary", `.docs/execution_lifecycle/contracts.md` line 524). Four lines above, it also says:

> These keys cover shell startup files and options (`ENV`, `BASH_ENV`, `SHELLOPTS`, `PS4` and others) and the module paths and option keys of Python, Perl, Ruby, Node.js, Java and Git

That sentence is not true of the code. The list is glibc's set-user-ID list and sudo's removal list plus the additions the contract names. Those two lists were written to protect set-user-ID programs and sudo. They do not know the tools the granted image holds.

**Proof (ran, `f8bc3df`).** `TestRedTeam74BackstopCoverageOfTheFamiliesTheContractNames`. For each key name it signs a package that declares that key, sends a request that sets it, and reads the Nomad job ES built. Result: `keys probed=107 reserved=13 admitted when declared=94`. The 13 reserved keys are controls and were refused. The other 94 were in the job's `Env` with the caller's value. Full table: the first test in `outputs/at-f8bc3df-all-probes.txt`.

The probe asks ES for its decision only. It runs no workload. What a program then does with the key is the right-hand column below, and **that column is Inference from each program's public documentation unless marked "read". I ran none of those programs** (see "Coverage this environment could not give").

| Family | Reserved today (refused) | Not reserved (in the job once declared) | What the key does |
| --- | --- | --- | --- |
| A switch this repository's own code reads | `NODE_TLS_REJECT_UNAUTHORIZED`, same purpose | `WORKLOAD_VAULT_INSECURE_SKIP_VERIFY` | Read: when it is `1`, `es/runtimeprofiles/control_plane_normal_shell/proof-codex-shim.py:72`, `.examples/control_plane_normal_shell_runtime/entrypoint:224` and `.examples/runtime_identity_vault_login/entrypoint:92` set `verify_mode = ssl.CERT_NONE` on the connection that carries the workload's Vault login and returns its secret. The shim is installed in the granted image when it is built with `CODEX_REALIZATION=proof`. |
| The Vault client | `VAULT_ADDR`, `VAULT_CACERT`, `VAULT_NAMESPACE` | `VAULT_AGENT_ADDR`, `VAULT_PROXY_ADDR`, `VAULT_HTTP_PROXY`, `VAULT_SKIP_VERIFY`, `VAULT_TLS_SERVER_NAME`, `VAULT_CAPATH`, `VAULT_CLIENT_CERT`, `VAULT_CLIENT_KEY`, `VAULT_TOKEN` | The official Vault client reads these to pick another address or proxy, to skip the TLS check, or to trust another CA. Same effect as the three reserved keys. ES's own helper does not call Vault (read), so this concerns a workload that uses the Vault CLI or library. |
| Per-user configuration | `HOME` | `XDG_CONFIG_HOME`, `XDG_CONFIG_DIRS`, `XDG_DATA_HOME`, `XDG_DATA_DIRS`, `XDG_CACHE_HOME`, `CURL_HOME`, `WGETRC`, `NETRC` | The contract reserves `HOME` because programs read their per-user configuration there. Git, pip and curl are in the granted image (read: its Dockerfile) and take the same files from `XDG_CONFIG_HOME` or `CURL_HOME`. A Git configuration file can name commands for Git to run. A curl configuration file can set a proxy and turn off the TLS check. |
| The agent CLI the granted image installs | none | `CODEX_HOME`, `OPENAI_BASE_URL` | Its configuration directory and the address it sends requests and its credential to. |
| TLS library | `SSL_CERT_FILE`, `SSL_CERT_DIR`, four CA-bundle keys | `OPENSSL_CONF`, `OPENSSL_MODULES`, `OPENSSL_ENGINES`, `AWS_CA_BUNDLE`, `PIP_CERT`, `GRPC_DEFAULT_SSL_ROOTS_FILE_PATH`, `PERL_LWP_SSL_VERIFY_HOSTNAME` | An OpenSSL configuration file can tell the library to load a module from a path. The others replace the trusted CAs for one client. |
| Node.js and npm | `NODE_OPTIONS`, `NODE_PATH` | `NPM_CONFIG_SCRIPT_SHELL`, `npm_config_script_shell`, `NPM_CONFIG_USERCONFIG`, `NODE_REPL_EXTERNAL_MODULE`, `NODE_COMPILE_CACHE` | npm reads every key that starts with `npm_config_` as a setting, in either letter case. |
| Ruby | `RUBYLIB`, `RUBYOPT` | `GEM_PATH`, `GEM_HOME`, `RUBYGEMS_GEMDEPS`, `BUNDLE_GEMFILE` | Where Ruby finds the gems a program loads: a module path under another name. |
| Java | `JAVA_TOOL_OPTIONS`, `_JAVA_OPTIONS`, `JDK_JAVA_OPTIONS`, `CLASSPATH` | `JAVA_HOME`, `OPENJ9_JAVA_OPTIONS`, `IBM_JAVA_OPTIONS`, `MAVEN_OPTS`, `GRADLE_OPTS` | Which Java runs, and the option keys of other Java virtual machines and build tools. |
| Perl | five keys | `PERL_USE_UNSAFE_INC`, `PERL_MM_OPT`, `PERL_MB_OPT` | Module search and installer options. |
| Python tools outside the `PYTHON` prefix | every `PYTHON*` key | `PIP_INDEX_URL`, `PIP_CONFIG_FILE`, `VIRTUAL_ENV`, `PYTEST_ADDOPTS`, `DJANGO_SETTINGS_MODULE` | Where pip downloads from, and module names two common frameworks import at start. |
| Programs Git and ssh start by name | every `GIT_*` key | `SSH_ASKPASS`, `PAGER`, `EDITOR`, `VISUAL` | The value is a program to run. |
| Runtimes the list does not name | none | `DOTNET_STARTUP_HOOKS`, `CORECLR_PROFILER_PATH`, `PHPRC`, `PHP_INI_SCAN_DIR`, `LUA_INIT`, `LUA_PATH`, `LUA_CPATH`, `R_PROFILE_USER`, `TCLLIBPATH` | The same kind of key as `PYTHONSTARTUP` or `RUBYOPT`, for other languages. |
| Build and archive tools | none | `MAKEFLAGS`, `MAKEFILES`, `GNUMAKEFLAGS`, `TAR_OPTIONS`, `LESSOPEN`, `CC`, `RUSTC_WRAPPER`, `GOFLAGS` | Options and helper programs these tools take from the environment. `tar` is in the granted image. |
| Client credential and configuration files | none | `AWS_CONFIG_FILE`, `KUBECONFIG`, `DOCKER_CONFIG`, `GNUPGHOME` | Configuration files that can name a helper program. |
| The scheduler's own variables | none | `NOMAD_TOKEN`, `NOMAD_ADDR`, `NOMAD_SECRETS_DIR`, `NOMAD_TASK_DIR`, `NOMAD_ALLOC_DIR`, `NOMAD_ALLOC_ID`, `NOMAD_META_run_id` | Inference: a key in the job's `Env` replaces the value Nomad sets under the same name, so a workload that trusts `NOMAD_*` would read the caller's value. One job on the Linux box would confirm it. |
| Other proxies | `HTTP_PROXY`, `HTTPS_PROXY`, `ALL_PROXY`, `FTP_PROXY`, `NO_PROXY` | `WS_PROXY`, `WSS_PROXY`, `RSYNC_PROXY`, `GRPC_PROXY` | Proxy keys of single clients. |
| Go runtime | `SSL_CERT_FILE`, `SSL_CERT_DIR` | `GODEBUG`, `GOTRACEBACK`, `GOMEMLIMIT`, `GOGC`, `GOMAXPROCS` | ES's supervisor is a Go program that starts as root in the container with the task's environment (read). These keys tune the Go runtime. I know of no way they load code. Listed so the fact is on record. |
| Locale | `LOCPATH`, `NLSPATH`, `GCONV_PATH`, `PATH_LOCALE` | `LANG`, `LC_ALL`, `LANGUAGE`, `TEXTDOMAINDIR` | With the four path keys reserved I see no harm in these. Listed because the brief named locale. |

**Why it is Low and not more.** A caller cannot use any of this alone. The package's publisher must first declare the key, and the contract tells the publisher what that means ("A publisher that declares a key accepts any value a caller ES admits gives it"). With nothing declared, ES admits no caller key at all (ran: the two empty declared sets in the 3,000,000-key probe admitted nothing, and the PR's own `TestEmptyEnvironmentAllowlistAdmitsNoCallerKey` passes). The repository's normal-shell example declares no key at all.

**Why it is still worth fixing in this PR.** The backstop exists for the case where a publisher declares a key that looks like plain configuration. `XDG_CONFIG_HOME`, `JAVA_HOME`, `GEM_HOME`, `PIP_INDEX_URL`, `EDITOR` or `KUBECONFIG` look like that. Some of these keys take a path, and a declared caller mount gives the caller a path it controls: a mount admits an artifact of any publisher (a documented decision of this PR), and files in a mount keep their execute bit (read: `governedMountExecFileMode = 0o755` in `es/admission/mounts.go`). Others take a program or an address as the value itself. So one wrong declaration by a publisher is enough, which is the mistake the list was added to catch.

**Suggested fix.** Three parts. None changes the design. The wider prefixes (`OPENAI_`, `PIP_`, `XDG_`) also stop a publisher from exposing a harmless key under them, so which of them to take is the writer's and the coordinator's call.

1. Reserve the keys with the most reach in the granted image now. As exact keys: `WORKLOAD_VAULT_INSECURE_SKIP_VERIFY`, `CURL_HOME`, `WGETRC`, `NETRC`, `GEM_HOME`, `GEM_PATH`, `RUBYGEMS_GEMDEPS`, `BUNDLE_GEMFILE`, `NODE_REPL_EXTERNAL_MODULE`, `NODE_COMPILE_CACHE`, `JAVA_HOME`, `OPENJ9_JAVA_OPTIONS`, `IBM_JAVA_OPTIONS`, `PERL_USE_UNSAFE_INC`. As prefixes: `VAULT_`, `XDG_`, `OPENSSL_`, `NPM_CONFIG_`, `NOMAD_`, `CODEX_`, `OPENAI_`, `PIP_`. No example in the repository declares a key these would refuse (ran: the examples declare `APP_MODE`, `WORKLOAD_VAULT_SECRET_PATH` or nothing), and none of the thirteen keys in the PR's `TestOrdinaryEnvironmentKeysAreNotReserved` falls under them. The rest of the table is the writer's call.
2. Reword the sentence on line 520 so that it says where the list comes from and stops saying it covers those languages. For example: "These keys include shell startup files and options (...) and the best-known module-path and option keys of Python, Perl, Ruby, Node.js, Java and Git. They do not include every such key."
3. Update the pinned set in `TestReservedEnvironmentKeySetIsPinned` and add the new keys to the table of `TestReservedEnvironmentKeysAreRefusedEvenWhenTheArtifactDeclaresThem`.

A defence that does not depend on a list would be stronger than a longer list: for example, AGS refusing at publish time to sign a declaration that holds a reserved key, so the publisher learns of the mistake and not the caller, or mounting caller mounts without execute permission. Both change behaviour that this PR documents, so they are design decisions for the coordinator and not part of this repair.

**Regression test.** The probe in `probes/es_admission_zz_redteam74_backstop_probe_test.go` is the starting point: after the repair, each key the repair covers must appear under "refused although declared". Turned into an assertion, that is the table in part 3.

## RT74-2 (Low): the second place that applies the rule has no test

**What.** The contract says ES applies the rules "in the shared admission path, so `:prepare`, `:submit` and every other path that admits a request apply them alike" (line 515). The rule check `validateInvocationAgainstManifest` has two callers (ran: grep at `f8bc3df`):

- `es/admission/service.go:742`, the shared path that `:prepare` and `:submit` use.
- `es/admission/reliable_submit_operational_admission.go:394`, the last line of `operationalEvidenceMatchesOriginal`. Reliable submit keeps a caller's request next to the signed evidence it was admitted under. When it writes that pair to custody and when it reads it back, this function judges the request against the evidence again.

On that second path the line is the only thing that looks at the retained caller environment. `validateOperationalPlan` (`reliable_submit_operational_format.go:68`) requires zero mounts and no network, and compares argv, digests, timeout and resources. It does not look at env (read).

**Proof (ran).** Mutant MN replaces line 394 with `return true`.

- The repository's own tests do not notice. Full `go test ./es/admission/ -count=1` on MN at `f8bc3df`, with no probe file in the tree: `ok execution-substrate/es/admission 288.532s` (`outputs/at-f8bc3df-MN-full-es-admission.txt`). The function is unexported and no other package can reach it.
- My probe notices. `TestRedTeam74RetainedOriginalEnvIsJudgedByTheSignedDeclaration` uses the repository's own fixture (`makeOperationalFixture`, `operationalV2Original`), whose evidence declares `environment_variables=["APP_MODE"]`. It sets one caller key in the retained request and asks `operationalEvidenceMatchesOriginal` and `encodeOperationalOriginal`. On the head all four subtests pass (the request is refused). On MN all four fail: a retained request that sets `LD_PRELOAD`, `BASH_ENV`, `PATH` or `UNDECLARED_KEY` "matched" its evidence and was written to custody (5,434 to 5,444 bytes). Outputs: `outputs/at-f8bc3df-all-probes.txt`, `outputs/at-f8bc3df-MN-retained-probe.txt`.

**Why it is Low.** No code in the running service calls this path today. No `Service` method defined in `es/admission/reliable_submit_*.go` has a caller outside those files and tests (ran: grep at `f8bc3df`), and `reliable_submit_replay_private.go:212` says of its entry point "It has no runtime or effect caller". PR #74 did not change the line (ran: `git diff 39e19de 626c3cd` on that file is empty). What PR #74 changed is what the line means: before, an empty declaration let every key through, so the line could not refuse a caller key under an empty list. Now it is the only guard for env on that path. Inference: reliable submit is the project's top priority, so the path will get a caller. The test should exist before the caller does.

**Suggested fix and regression test.** Add the probe as a permanent test. `regressions/es_admission_retained_request_env_test.go` is the probe under a permanent name, `TestOperationalRetainedRequestEnvIsJudgedByTheSignedDeclaration`. Ran: it passes at `f8bc3df` and fails on MN at `f8bc3df` (`outputs/at-f8bc3df-regression-test.txt`, `outputs/at-f8bc3df-MN-regression-test.txt`). No product code changes.

## RT74-3 (report only): argv

The writer named this as a known, deferred decision, and the contract says it plainly (line 534). What I checked:

- Caller argv cannot change what ES's own supervisor does. ES builds the command as `supervisor --payload-archive ... --timeout-seconds N -- <caller argv>`, and Go's flag parser stops at `--`. Ran: `TestRedTeam74CallerArgvCannotChangeSupervisorOptions` gives `parseSupervisorArgs` 10 caller lists that look like options (`--entrypoint`, `--timeout-seconds`, a second `--`, empty strings and others). The options stay as ES set them and the workload gets the caller's list unchanged. The second stage (`exec-workload`) parses the same way (read, not run).
- In the 4,000-request probe, caller argv was each time exactly the tail of the command after `--` (ran).
- None of the four example entrypoints in `.examples/` reads its arguments (ran: grep for `sys.argv`, `$@` and positional parameters finds nothing). The normal-shell example gives the agent CLI a fixed prompt.

So today's risk is a package that chooses to run its arguments, which is the publisher's decision that the contract describes.

## What held

All ran at `f8bc3df` unless marked.

| Attack | Result |
| --- | --- |
| Undeclared key or mount reaches the job | `TestRedTeam74JobCarriesOnlyWhatTheSignedArtifactDeclares`: 4,000 random requests (seed 74), 1,792 admitted, 2,208 refused. The only caller keys in any job were `APP_MODE`, `LANG`, `Mixed_Case1`, `_`, `app_token`. The only caller mount targets were `/execution/mounts/a/b`, `/execution/mounts/config`, `/execution/mounts/data` and one with a non-ASCII letter. All declared. The package also declared `LD_PRELOAD`, `PATH`, `path`, `http_proxy`, `PYTHONPATH`, `GIT_SSH_COMMAND`, `EXEC_RUN_ID`, `BASH_ENV` and malformed names on purpose: none reached a job. |
| `:prepare` and `:submit` disagree, or a refused request reaches Nomad | Never, in the same 4,000 requests. |
| Key names: letter case, look-alike letters, `=`, NUL, white space, prefixes | `TestRedTeam74FuzzEnvironmentKeysAgainstTheOracle`: 3,000,000 keys (seed 7400) from an alphabet that holds `=`, NUL, tab, newline, `$`, `{`, `%`, the long s (U+017F), the Kelvin sign (U+212A), a full-width letter, a zero-width space and reserved words, against 7 declared sets. The rule check agreed with an independent reading of the rules every time. 15 distinct keys were admitted, all declared, portable and unreserved (for example `PATHX`, `XPATH`, `LDX`, `HOMEX`, `ENVX`: a name that merely contains a reserved word is not reserved, which is right). The look-alike letters cannot fold into a reserved name because the name rule refuses every non-ASCII letter first. |
| A caller key replaces a key ES sets | Not in any of the 4,000 jobs. ES writes its own keys after the caller's, and every key ES writes is reserved (read: `resolvedSemanticRuntimeEnvironment`, `newResolvedRunProjection`). |
| Request body spellings | `TestRedTeam74RequestBodySpellings`: 18 bodies. Two `env` objects (Go merges them), `ENV` next to `env`, `Env` after `env`, `mounts` twice, `mounts` spelled with a long s, `target_path` twice, `Target_Path`, `invocation` twice, JSON escapes that spell a key, an escaped `=`, an escaped NUL, an unknown field. Each body was refused, or the job held only declared input. There is one strict decoder, so what is checked is what is used. |
| Mount targets: `..`, `//`, `/./`, trailing slash, letter case, a longer or shorter name, a sub-path or parent of a declared target, the same letter in another Unicode form, a byte order mark, padding | In the 4,000-request probe, 43 target spellings. Only the four declared targets reached a job. A padded spelling of a declared target is trimmed to the declared target, as the contract says. |
| A mount that shadows ES's own paths or the entrypoint | Targets must be under `/execution/mounts/` and declared. The package declared `/etc`, `/usr/bin`, `/execution/run/work`, `/execution/staged` and `/execution/mounts/../run/work` on purpose: none was ever usable. ES's own mounts sit outside `/execution/mounts/`. |
| Symlinks and path tricks inside a mount archive | Read: mount archive validation refuses symlinks, hard links, special files and traversal. The repository's `TestRuntimeMountArchiveRejectsPathTraversalAndSymlinksBeforeMaterialization` covers it (ran by name: passes). I added no probe here. |
| A registry that serves a wider declaration | `TestRedTeam74SealedDeclarationCannotBeWidenedInTheRegistry`: 7 doctored records (a wider env list, the list twice, a second field that differs in letter case, the `runtime` object twice, `mount_targets` added, added with another letter case, added with a long s). All refused: `403 artifact_evidence_invalid: artifact evidence signature verification failed`. Four more records: one with an unknown extra field is refused outright, and three that decode to the signed value (the wide list first and the signed list last, `mount_targets` null, `mount_targets` empty) admit nothing beyond the signed declaration. |
| A package signed before the field existed | `TestRedTeam74ArtifactSignedBeforeTheFieldAdmitsNothing`: no `mount_targets` field admits no mount, and its empty env list admits no key. The old seal still verifies, because the field is left out of the signed form when empty. |
| The retained-request path of reliable submit | Applies the rule at the head (RT74-2 is about its missing test). |
| Caller argv changes supervisor options | No (RT74-3). |

## How I know the probes can fail, and how well the PR's tests guard the rules

Eleven mutants. Each is one edit to the code under test. Diffs: `mutants/`.

| ID | Edit | My probes | The repository's tests |
| --- | --- | --- | --- |
| MA | An empty declared env list admits every key (the old rule) | fail | Not run by me. Writer report 15: its M1, killed. |
| MB | No check of mount targets against the declaration | fail | Not run by me. Writer report 15: M2, killed. |
| MC | Reserved match is case-sensitive | fail | Not run by me. Writer report 15: M5, killed. |
| MD | No portable-name rule | fail | Not run by me. Writer report 15: M3, killed. |
| MF | A declared mount target matches as a prefix | fail | Killed: `TestCallerMountNeedsATargetTheArtifactDeclares` |
| MG | A declared key skips the reserved check | fail | Killed: `TestReservedEnvironmentKeysAreRefusedEvenWhenTheArtifactDeclaresThem`, `TestCallerCannotPutItsOwnCodeIntoAGrantedNetworkRun` |
| MH | The declared env match ignores letter case | fail | Killed: `TestDeclaredEnvironmentKeyIsTheOnlyCallerKeyAdmitted` |
| MS | The declared mount match ignores letter case | not run | Killed: `TestCallerMountNeedsATargetTheArtifactDeclares` |
| MP | AGS does not sign `mount_targets` | not run | Killed: `TestPublishSignsTheDeclaredMountTargets` |
| MQ | The seal's canonical form drops `mount_targets` | not run | Killed: `TestMountTargetsAreSignedAsATrimmedSortedSet`, `TestPublishSignsTheDeclaredMountTargets` |
| MN | The retained-request path skips the rule check | fail (retained probe) | **Survives** the whole `es/admission` package: RT74-2 |

Every mutant but MN ran at `626c3cd`. MN ran at both commits. For MF, MG, MH, MS, MP and MQ the repository's tests were the targeted set in the evidence README (about 3 minutes each), not the whole suite; a mutant that the targeted set kills is killed.

## Observations, not findings

1. **The caller picks the runtime profile, and with it the image.** `execution_substrate.runtime_profile` is a request annotation (read: `es/admission/runtimeprofile.go`). When ES configuration enables that profile, any signed static-script package with network access can be asked to run under `control-plane-normal-shell/v1`. No caller code enters the run that way: both images come from ES configuration. This is older than PR #74. Read at PR #73 head `de4ade8`: a grant rule names the `runtime_profile`, so a granted run is held to the profile the owner wrote.
2. **The artifact digest does not cover the declaration.** The digest is made from the payload digest, the artifact type and the intent digest. The runtime interface, including the two declared lists, is in the signed evidence but not in the digest, and the registry keeps the first evidence registered for a digest (a second one gets 409; read: `ars/index/fileindex.go`). So the declaration for a digest belongs to whoever registers it first. I found no gain in that: the evidence names its publisher, and PR #73's grant rules name the publisher (read at `de4ade8`), so another publisher's wider declaration brings no grant. It matters only if a later change keys trust on the artifact digest alone.
3. **Caller mounts are executable.** Files keep their execute bit and the bind mount has no `noexec` option (read: `runtimeMountSpecs`). That is how a mount is meant to work if a package runs tools from it. It is also what gives a path-valued key in RT74-1 something to point at.
4. **A publisher gets no error for declaring a key that can never be used.** AGS signs the declared lists as given (read: `ags/publish/service.go`). A package that declares `PATH` is signed, and the first sign of the mistake is the caller's 400.
5. **The `runtime_identity_vault_success` example declares `WORKLOAD_VAULT_SECRET_PATH`.** A caller of that package picks the Vault path the example reads. That is the example's choice, and Vault policy decides what the workload identity can read.
6. **ES's helper ignores `SPIFFE_ENDPOINT_SOCKET`.** It names the socket address in code (read: `workloadapi.WithAddr`), so a declared key of that name cannot point it at another socket.

## Suites

| Run | Commit | Result |
| --- | --- | --- |
| My probes: `go test ./es/admission/ -run TestRedTeam74 -count=1 -v` and the same for `./es/runtimehelper/` | `f8bc3df` | 8 tests, all pass (`outputs/at-f8bc3df-all-probes.txt`) |
| `go test ./es/admission/ ./es/runtimehelper/ ./es/api/ ./internal/contracts/evidence/v1/ ./ags/publish/ -count=1` on a clean tree, no probe files | `f8bc3df` | all five `ok`; `es/admission` took 305.579s (`outputs/at-f8bc3df-clean-tree-packages.txt`) |
| `go test ./es/admission/ -count=1` with my first probe file in the tree | `626c3cd` | `ok execution-substrate/es/admission 363.172s` |
| The PR's nine tests in `es/admission/caller_declaration_test.go`, by name with `-v` | `f8bc3df` | 9 of 9 pass (`outputs/at-f8bc3df-pr-nine-tests.txt`) |

"Tests pass" above means these packages only. I did not run the root package, `es/app`, `scripts`, `es/admission/internal/reliablesubmit` or the other services. Writer report 15 and the audit of this PR cover the whole suite.

## Coverage this environment could not give

- **No container ran.** There is no Docker daemon, Nomad, Vault or SPIRE here. Every probe stops at the job ES builds and at the supervisor's argument parsing. What Nomad and Docker then do with that job is not tested.
- **No demonstration of an unreserved key running caller code in a real program.** I started one. The assistant's safety filter stopped it, I deleted the partial file, and I did not write it again in another form. So the right-hand column of the RT74-1 table comes from documentation, except the row marked "read". If David wants one of those rows proven, it is a box run on his go.
- **Nomad and `NOMAD_*` keys.** Inference only, as marked.
- **What the runtime images hold under `/execution/mounts`.** Unknown. Docker resolves a mount target inside the image, so a symlink there would move a caller mount. The normal-shell Dockerfile creates nothing there (read). The image for `static-script/default` comes from configuration and I did not see it. `docker run --rm <image> ls -la /execution` on the box would settle it.
- **PR #73 and PR #74 together.** I read PR #73's grant rules at `de4ade8` and did not run the two PRs merged.
- **CI.** Read from GitHub, not run by me.

## For the writer, in one list

1. RT74-1: reserve the keys and prefixes in "Suggested fix" part 1, update the pinned set and the refusal table, and reword the sentence on line 520 of `.docs/execution_lifecycle/contracts.md`.
2. RT74-2: add `regressions/es_admission_retained_request_env_test.go` to `es/admission/`.
3. RT74-3: nothing to do in this PR.

For the coordinator: two design options that do not belong in this repair are in RT74-1 (AGS refusing a declaration that holds a reserved key; caller mounts without execute permission), and observation 2 is worth a line in the notes for any later change that keys trust on the artifact digest.

STATUS: READY
