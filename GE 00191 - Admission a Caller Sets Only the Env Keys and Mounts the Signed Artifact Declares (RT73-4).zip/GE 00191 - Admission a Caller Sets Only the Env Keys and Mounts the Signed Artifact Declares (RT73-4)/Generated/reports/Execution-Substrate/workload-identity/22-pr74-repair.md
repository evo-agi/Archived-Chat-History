# Writer report 22: ES PR #74 repair after red-team 19 and audit 21

Date: 2026-11-26, about 10:25 PM Eastern (2026-11-27 03:25Z). Writer: the "Stop callers injecting code into runs" thread, which wrote #74 (report 15).

## Target

| Item | Value |
| --- | --- |
| PR | evo-agi/Execution-Substrate #74, branch `claude/project-thread-ef7st5` |
| Base | `trunk_dev` at `a5861b7c0e2199a77b489d25e6b3fc02e6448c20` (#68) |
| Head | `9c067902afc4edafd250f8ba06b1e64b1666d72f`, tree `727481fed42b3278eef78ba3fea602947200502e` (pushed; `git ls-remote` equal) |
| Commits since the audited head `f8bc3df` | `a0e8158` RT74-1 and RT74-2; `0626d9c` A1 and A2; `9c06790` merge of `trunk_dev` `a5861b7` (#68), no conflict |
| `git diff a5861b7 9c06790` | 29 files, +1420 / -75; `\| sha256sum` = `07626657b39ad18105019ce485546216cdad90265a488dac55d94faf0c72df96` |
| Canonical manifest (O4) | recipe `governed-execution.audit-patch-manifest.v2` (source SHA-256 `c08597e2…a3ca`, `sha256sum -c` OK), fresh clone, branch reset `--mixed` to `a5861b7`, upstream `origin/trunk_dev`; run twice, `cmp` identical. `manifest_sha256` `1f19ff0055926632216fe6aef0f2328acce41e567ea8dd32a3759671fdbfc2f4`, 29 files, `textual_diff_sha256` `95e614e2e0ed1292b0d2b6ae73f88820d57cc86966cc94554b9a677f7e7f161b`. File: `22-pr74-repair-evidence/manifest-v2-9c06790-on-a5861b7.json` |
| Gate | narrow re-check of the delta, then CI on 9c06790 |

The 29th path compared with audit 21's 28 is the new `es/admission/reliable_submit_retained_request_env_test.go`.

## Delta to re-check (`git diff f8bc3df 9c06790`, PR paths only)

Product code, one file: `es/admission/service.go`, the reserved set and its comments. No change to `validateInvocationAgainstManifest` or any other logic.

| Finding | Change |
| --- | --- |
| RT74-1 (red-team 19) | `reservedRuntimeEnvPrefixes` gains whole families: `VAULT_`, `XDG_`, `OPENSSL_`, `NPM_CONFIG_`, `NOMAD_`, `CODEX_`, `OPENAI_`, `PIP_`, `PYTEST_`, `PERL`, `RUBY`, `GEM_`, `BUNDLE_`, `JAVA_`, `MAVEN_`, `GRADLE_`, `DOTNET_`, `CORECLR_`, `COMPLUS_`, `PHP`, `LUA_`, `CARGO_`, `RUSTUP_`, `RUSTC`, `DOCKER_`, `SSH_`, `GRPC_`, `CURL_`. `reservedRuntimeEnvKeys` gains 69 single keys of the same kinds that no prefix covers (block "Keys of the same kinds…"), including `WORKLOAD_VAULT_INSECURE_SKIP_VERIFY`, `GODEBUG`, `GOTRACEBACK`, `SHELL`, `EDITOR`, `CC`, `CFLAGS`, `MAKEFLAGS`, `KUBECONFIG`. Of the red-team's 94 open keys, 87 are now reserved; the 7 left (`LANG`, `LC_ALL`, `LANGUAGE`, `TEXTDOMAINDIR`, `GOMEMLIMIT`, `GOGC`, `GOMAXPROCS`) load no code and change no trust. Contract section 5: the overclaiming sentence now says "the best-known module-path and option keys … They do not include every such key", plus two bullets naming every new prefix and the single-key kinds. |
| RT74-2 (red-team 19) | `es/admission/reliable_submit_retained_request_env_test.go`: the red-team's `TestOperationalRetainedRequestEnvIsJudgedByTheSignedDeclaration`, header comment changed from "Proposed" only. |
| A1 (audit 21) | Contract section 5 and the two `service.go` comments credit sudo 1.9.16p2 only for its own entries and name the entries sudo's development branch adds later: `_JAVA_OPTIONS`, `CLASSPATH`, `PYTHONSTARTUP`, `NODE_OPTIONS`, `NODE_PATH`, `GIT_SSH_COMMAND`, `GIT_CONFIG_*` (diff of the two `initial_badenv_table`s, fetched 2026-11-26; `GCONV_PATH` is also added there and is reserved through glibc's list). The `PYTHON` prefix comment names 1.9.16p2's four `PYTHON*` entries. Test comment in `caller_declaration_test.go` follows. |
| A2 (audit 21) | `.docs/standing_rules/execution_admission_and_custody.md`: "empty allowlist behavior … remain in force" replaced by "Environment and mount admission are those of the shared admission path (`.docs/execution_lifecycle/contracts.md`, section 5); the foundation adds no rule of its own." The precedence clause is a separate sentence, because `TestAuthorityOrderIsStatedOnlyInAgents` refuses "precedence" in a sentence that names a governing file. `caller_declaration_docs_contract_test.go` now refuses "empty allowlist behavior" in the five docs. |

Tests changed: `caller_declaration_test.go` pins the new keys and prefixes; new `TestReservedFamiliesCoverTheKeysTheRedTeamFoundOpen` (the 87 keys); 23 more end-to-end refusal cases in `TestReservedEnvironmentKeysAreRefusedEvenWhenTheArtifactDeclaresThem`, sampling the new families and single keys; `TestOrdinaryEnvironmentKeysAreNotReserved` adds the 6 keys left open (`LANG` was already there). `TestEmptyEnvironmentAllowlistAdmitsNoCallerKey` used `WORKLOAD_VAULT_INSECURE_SKIP_VERIFY` as its ordinary key; that key is now reserved, so the test uses `WORKLOAD_VAULT_SECRET_PATH`. Docs test: three phrases added (two required, one refused).

Not changed: AGS, the evidence contract, the examples, scripts. Coordinator decision recorded: the name `mount_targets` stays (O3 closed).

## Validation (ran, as root in this container)

- `go build ./...`, `go vet` on root, `es/admission`, `es/app`, `ags/...`, `internal/...`: clean. gofmt clean.
- `go test -json -count=1 -timeout 60m ./...` on 9c06790: 1826 pass, 81 skip, 55 fail. The 55 failing names equal the 626c3cd run name for name (3 `reliablesubmit` old-binary probes, 14 `es/app`, 38 `scripts`), all environment-only and failing on base too (report 15). Lists in the evidence folder. Root package passes in full, including #68's `TestServiceLayout` and `TestAuthorityOrderIsStatedOnlyInAgents`. Audit 21 ran unprivileged and saw 14; the difference is root-refusing fixtures, as it says.
- New and changed tests pass: `TestReservedFamiliesCoverTheKeysTheRedTeamFoundOpen`, `TestOperationalRetainedRequestEnvIsJudgedByTheSignedDeclaration`, `TestReservedEnvironmentKeySetIsPinned`, `TestReservedEnvironmentKeysAreRefusedEvenWhenTheArtifactDeclaresThem`, `TestCallerDeclarationRulesAreInTheLifecycleContract`, `TestLifecycleContractNamesOnlyReservedKeysTheCodeReserves`.
- Mutants this round: MN (retained-request check returns true) kills `TestOperationalRetainedRequestEnvIsJudgedByTheSignedDeclaration`. Restoring the old standing-rule sentence kills `TestCallerDeclarationRulesAreInTheLifecycleContract` ("must not contain \"empty allowlist behavior\"").
- CI on the previous head f8bc3df: both required checks green. CI on 9c06790: started by the push; the PR thread watches it.

## Compatibility of the wider backstop

No example, runbook, script or test declares a key under the new families or single keys (declared keys in the repo: `APP_MODE`, `API_URL`, `ALLOWED_ENV`, `WORKLOAD_VAULT_SECRET_PATH`). The cost: a publisher can no longer let callers set a key in these families, for example `JAVA_OPTS` or `CODEX_*`. Inference: none of today's flows needs that; a later need is a deliberate change to the pinned set.

## Open, for the coordinator

- Red-team 19's two design options (AGS refusing to sign a declaration that holds a reserved key; mounting caller mounts without execute permission) and observation 2 (the artifact digest does not cover the declaration) are not in this repair.
- Audit 21 O2 (a retained original stored before this PR would read as integrity failure) is for the reliable-submit wiring brief.
- argv stays unbounded (RT74-3, O5), as the contract says.

## Confidence

Provenance high (manifest twice, identical; pushed head equal). Validation high for everything this container runs; the Docker/Nomad flows rely on CI. Implementation high: the delta is list entries, comments, docs and tests; the admission logic audit 21 checked is unchanged.
