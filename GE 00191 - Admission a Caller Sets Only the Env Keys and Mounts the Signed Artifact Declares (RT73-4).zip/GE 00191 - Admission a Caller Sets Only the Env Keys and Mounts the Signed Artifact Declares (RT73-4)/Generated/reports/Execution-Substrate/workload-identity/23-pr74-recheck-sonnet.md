# Narrow re-check 23 (Sonnet): ES PR #74 repair after audit 21 and red-team 19: BLOCK (one Low doc finding; CI on the head still running)

Date: 2026-11-26, about 10:35 PM Eastern (03:35Z on 11-27). Auditor: thread "Sonnet re-check of caller injection fix". Model: `[model withheld]`. Model-evaluation trial, category R-M (narrow re-check, medium); another model checks the same scope independently and I did not read its output. I have not audited or written any part of #74.

Source labels: "ran" means I ran it in this container on the commit named. "Read" means I read the code or source and did not run it. "Inference:" and "Guess:" mark the rest.

```text
INDEPENDENT AUDIT REPORT (narrow re-check of the repair delta)
Repository / Audit target:
  evo-agi/Execution-Substrate PR #74, branch claude/project-thread-ef7st5
  base trunk_dev a5861b7c0e2199a77b489d25e6b3fc02e6448c20 (#68)
  topic commit 9c067902afc4edafd250f8ba06b1e64b1666d72f, tree 727481fed42b3278eef78ba3fea602947200502e
  recipe governed-execution.audit-patch-manifest.v2, source SHA-256
    c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (verified before each run)
  canonical-manifest SHA-256 1f19ff0055926632216fe6aef0f2328acce41e567ea8dd32a3759671fdbfc2f4, 29 paths,
    textual_diff_sha256 95e614e2e0ed1292b0d2b6ae73f88820d57cc86966cc94554b9a677f7e7f161b
    (writer report 22 gives the same values; my manifest file is byte-identical to its manifest file)
  `git diff a5861b7 9c06790 | sha256sum` = 07626657b39ad18105019ce485546216cdad90265a488dac55d94faf0c72df96
Audit posture: read-only, parent only, no subagents. Nothing pushed, nothing posted on GitHub. Tests, probes and
  mutants ran in separate clones owned by an unprivileged user; the provenance clone ran no tests.
Provenance reproduction: reproduced twice, identical; closing run equals opening; pushed tip and trunk_dev
  re-read at close, unchanged; every committed blob equals its manifest record (29 of 29). No mode-bit differences.
Coverage: the whole repair delta (6 files), the merge, every other copy of the changed sentences in the repo,
  the one non-test caller of the reserved set, the PR body, the upstream sudo table, the red-team 19 probes rerun.
  Not covered: see "Coverage this environment could not give".
Findings: 1 Low (F1, docs and a code comment). 3 observations. No finding against the four fixes' substance.
Validation assessment: whole suite on exact bytes for both trees as an unprivileged user: no new failure, 18 new
  tests pass, nothing newly skipped. 10 mutants, all killed. Red-team 19's eight probes pass on the head.
Sensitive-material handling: no secrets, keys, tokens, env files, SQLite or TLS/SPIFFE/Vault material read.
Remaining uncertainty and stop conditions: CI on 9c06790 had not finished at 03:33Z (both required jobs
  "in_progress"). Verdict is a BLOCK on F1 whatever CI says; a PASS later needs CI green on the new head.
Confidence: provenance high / validation high for what runs here (Docker and Nomad flows run only in CI) /
  implementation high for the four fixes, medium on the unblocked-key judgment (it rests on read sources and two small probes).
Effect status: repair, commit, push, PR, merge not performed.
Report delivery: /mnt/project-files/reports/Execution-Substrate/workload-identity/23-pr74-recheck-sonnet.md
  (SHA-256 in the delivering message), evidence in 23-pr74-recheck-sonnet-evidence/ (SHA256SUMS inside).
Final verdict: BLOCK
```

Why BLOCK with one Low finding: David's standing rule is that Low findings are fixed in the PR, and audit 21 blocked on two. F1 is a few words in two places and changes no behavior. The rest of the repair holds.

## Provenance (ran)

- Recipe bytes: `sha256sum -c` OK. Pushed tip equals `9c06790`, `trunk_dev` equals `a5861b7`, base is an ancestor, clean checkout, `git reset --mixed` to base, upstream pinned to `origin/trunk_dev`, v2 run twice to two absent paths in a `0700` directory outside the repo, `cmp` identical, equal to the writer's manifest file in report 22's evidence folder, closing run equal to opening.
- **The merge is git's own, with no hand edit.** `git merge-tree --write-tree 0626d9c a5861b7` gives tree `727481fe…`, equal to the head's tree. Parents of `9c06790` are `0626d9c` and `a5861b7`.
- **The patch's +/- lines did not change by the merge.** The path set of `git diff fbfd100 0626d9c` (old base, repaired tip before the merge) equals that of `git diff a5861b7 9c06790` (29 paths). The `+`/`-` lines of the two diffs are identical, in total (`c6fefbad…`) and for each of the 29 files. So the merge changed context only, and everything below that reads the repair at `0626d9c` applies to the head.
- **Nothing else changed.** `git diff f8bc3df 0626d9c` touches six files and nothing else: `.docs/execution_lifecycle/contracts.md`, `.docs/standing_rules/execution_admission_and_custody.md`, `caller_declaration_docs_contract_test.go`, `es/admission/caller_declaration_test.go`, `es/admission/service.go` and the new `es/admission/reliable_submit_retained_request_env_test.go`. In `service.go` all three hunks sit inside the `var (…)` block of the reserved set (comments, new keys, new prefixes); `validateInvocationAgainstManifest`, `isReservedRuntimeEnvKey` and every other function are unchanged. No assertion is removed from any test; two lines of existing tests change (a comment, and the ordinary key in `TestEmptyEnvironmentAllowlistAdmitsNoCallerKey`, from a key that is now reserved to `WORKLOAD_VAULT_SECRET_PATH`, which is not). The 23 files outside the delta are unchanged by the repair. The PR has five commits: `626c3cd`, `f8bc3df` (merge), `a0e8158`, `0626d9c`, `9c06790` (merge).

## The four fixes

| ID | Verdict | What I checked |
| --- | --- | --- |
| A1 (audit 21) sudo attribution | Fixed, with one omission (F1) | Contract `contracts.md:520` and `service.go:125-131, 270-279` now credit 1.9.16p2 only for its own entries and name the later ones. I fetched `plugins/sudoers/env.c` from the upstream repository (tag `SUDO_1_9_16p2`, SHA-256 `64d72a55…`; development branch `cc856f0f`, SHA-256 `e5145d71…`, the same two hashes audit 21 recorded) and diffed the two `initial_badenv_table`s. 1.9.16p2 has the four `PYTHON*` entries the comment names (`PYTHONHOME`, `PYTHONPATH`, `PYTHONINSPECT`, `PYTHONUSERBASE`) and none of `_JAVA_OPTIONS`, `CLASSPATH`, `PYTHONSTARTUP`, `NODE_OPTIONS`, `NODE_PATH`, `GIT_SSH_COMMAND`, `GIT_CONFIG_*`. The development branch adds those seven **and an eighth, `GCONV_PATH`** (F1). The PR body now lists the same seven. No other doc, README, PLANS or test carries the old attribution (ran: `git grep` for `1.9.16`, `badenv`, "later sudo"). |
| A2 (audit 21) stale standing-rule sentence | Fixed | `execution_admission_and_custody.md:138-142` now says environment and mount admission "are those of the shared admission path (…, section 5); the foundation adds no rule of its own", and keeps the precedence clause as a separate sentence. No other copy of "empty allowlist behavior" exists at the head (ran: `git grep`; the only hit is the forbidden-phrase list). `caller_declaration_docs_contract_test.go:57` now refuses the phrase in all five docs. Mutant A2 (old sentence restored) is killed by `TestCallerDeclarationRulesAreInTheLifecycleContract`. |
| RT74-1 (red-team 19) backstop misses families | Fixed | See below. |
| RT74-2 (red-team 19) retained-request check untested | Fixed | `reliable_submit_retained_request_env_test.go` is byte-identical to the red-team's `regressions/es_admission_retained_request_env_test.go` except the header comment ("Proposed" removed). Mutant R1 (the retained-request line returns `true`; red-team's MN) is killed by it, and by nothing in the old suite. It passes at the head. |

### RT74-1 in detail

- **Contract sentence.** `contracts.md:520` no longer says the list covers the languages' keys. It says "the best-known module-path and option keys of Python, Perl, Ruby, Node.js, Java and Git. They do not include every such key; the families below add more", and `:526` keeps "no list can name every variable every program reads". The old sentence is a refused phrase in the docs test (`caller_declaration_docs_contract_test.go:43`), the new two are required (`:31-32`).
- **Code.** 28 prefixes added (`service.go:291-334`, 36 prefixes in all) and 69 single keys (`:187-265`). The one non-test caller of the set is `validateInvocationAgainstManifest` (`service.go:1166`), so the new entries judge caller keys only: not the profile env or ES's own keys.
- **The red-team's own measurement, rerun at the head** (ran): `TestRedTeam74BackstopCoverageOfTheFamiliesTheContractNames` reports `keys probed=107 reserved=100 admitted when declared=7`, against 13 and 94 at `f8bc3df`. The 100 = 13 controls + 87 repaired, as report 22 says. The seven admitted keys are exactly `LANG LC_ALL LANGUAGE TEXTDOMAINDIR GOMEMLIMIT GOGC GOMAXPROCS`. Each of the 87 is checked by `TestReservedFamiliesCoverTheKeysTheRedTeamFoundOpen`.
- **Pin and docs agree.** `TestReservedEnvironmentKeySetIsPinned` compares the code's set and prefix list with the test's lists exactly (so a silent addition or removal fails); `TestLifecycleContractNamesOnlyReservedKeysTheCodeReserves` fails if the contract names a key the code does not reserve or leaves a prefix unnamed. Mutants R2 (drop `XDG_`), R3 (drop `WORKLOAD_VAULT_INSECURE_SKIP_VERIFY`), R4 (drop `NOMAD_`), R6 (drop `GODEBUG`), R7 (prefixes matched without the ASCII fold), R8 (contract stops naming `NOMAD_`) and R9 (overclaim sentence restored) are killed; R5 (prefix `PHP` widened to `P`, which would over-reserve) is killed by `TestOrdinaryEnvironmentKeysAreNotReserved` and the pin.
- **No example or script is refused.** The keys declared or sent anywhere in the repo are `APP_MODE`, `WORKLOAD_VAULT_SECRET_PATH`, `REFERENCE_IDENTITY_URL`, `REFERENCE_SECRET_PATH`, `REFERENCE_VAULT_INSECURE_SKIP_VERIFY`, `API_URL`, `ALLOWED_ENV` (read: `.examples/`, both runbook copies, `scripts/60_execute_loop.sh`); none is reserved. `WORKLOAD_VAULT_INSECURE_SKIP_VERIFY` is only read by the three entrypoints the contract names (`.examples/control_plane_normal_shell_runtime/entrypoint:224`, `.examples/runtime_identity_vault_login/entrypoint:92`, `proof-codex-shim.py:72`); nothing in the repo sets it.
- **The boundary did not move.** All eight red-team 19 probes pass at the head (ran): 4,000 random requests, 3,000,000 fuzzed keys, 18 body spellings, doctored registry records, a pre-field artifact, the retained-request path, argv.

## The 7 unblocked keys load no code

Claim in report 22 and in `caller_declaration_test.go:362-364`: they "load no code and change no trust". My result: **no mechanism that loads code from a caller-chosen place**, found by the checks below. One of them lets a caller choose message text (O1).

| Key | What I checked | Result |
| --- | --- | --- |
| `LANG`, `LC_ALL`, `LANGUAGE` | Ran, glibc 2.39: a locale name given as a path (`LC_ALL=/dir/custom`, `LANG=…`, `LC_NUMERIC=…`, a `../` spelling) is refused ("unsupported locale setting"); the control `LOCPATH=/dir LC_ALL=custom` loads the locale and the custom decimal point shows. So the only way to point glibc at a caller's locale directory is `LOCPATH`, which ES reserves. Read, not run: gconv modules come from the system directory or `GCONV_PATH` (reserved). | Locale data from system places only. No code. |
| `TEXTDOMAINDIR` | Ran: with `LANGUAGE=xx LC_ALL=en_US.UTF-8 TEXTDOMAIN=dom`, bash prints `hello` for `echo $"hello"`; adding `TEXTDOMAINDIR=<dir with a dom.mo>` prints the catalog's text instead. | A message catalog is data, but the caller chooses the text a program prints. See O1. |
| `GOMEMLIMIT`, `GOGC`, `GOMAXPROCS` | Read, Go 1.26.5 runtime: `proc.go:922` (`strconv.ParseInt`, a positive integer), `mgcpacer.go:1371` and `:1417` (`readGOGC`: "off" or an integer; `readGOMEMLIMIT`: a size). They tune the garbage collector and the scheduler of any Go program in the run, including ES's own supervisor. | Numbers only. Inference: they can slow or exhaust the caller's own run (`GOGC=off`); none loads code or changes a trust decision. |

Each of these needs a publisher that declared the key; a declared key is the boundary, as the contract says.

## Findings

```text
AUDIT FINDING F1
Type / Severity: test/doc/artifact gap (incomplete list of what sudo's development branch adds) / low
Current contract: .docs/execution_lifecycle/contracts.md section 5, reserved keys
Path and line (9c06790): .docs/execution_lifecycle/contracts.md:520; es/admission/service.go:125-131
  (also the PR body, "Reserved keys are a backstop")
Evidence: The contract says sudo's development branch "adds to that table after 1.9.16p2: `_JAVA_OPTIONS`,
  `CLASSPATH`, `PYTHONSTARTUP`, `NODE_OPTIONS`, `NODE_PATH`, `GIT_SSH_COMMAND` and `GIT_CONFIG_*`", and the code
  comment lists the same seven. The development table I fetched (sudo-project/sudo HEAD cc856f0f, env.c SHA-256
  e5145d71…) adds eight: the same seven and `GCONV_PATH` ("glibc generic char set conversion iface"), placed
  after `GIT_CONFIG_*`. Ran: a diff of the two entry lists, in evidence upstream/sudo-initial_badenv_table-extract.txt.
  Writer report 22 knows it ("`GCONV_PATH` is also added there and is reserved through glibc's list") but neither
  the contract nor the comment says so. Audit 21 also counted seven.
Impact: none on behavior: GCONV_PATH is reserved through the glibc bullet above it and in the pinned set. It is the
  same kind of defect as A1: a reader who compares the sentence with the cited table finds an entry that is missing.
Required correction: add `GCONV_PATH` to the sentence in contracts.md:520 ("… and `GCONV_PATH`, which the glibc
  list above already reserves") and to the comment at service.go:125-131; keep the PR body in step. Optionally name
  commit cc856f0f instead of a date, as audit 21 allowed ("main moves"). No test change is needed.
Patch defect or pre-existing issue: patch defect (the sentence was rewritten in 0626d9c; before it, it also listed
  fewer entries than the table adds).
```

## Observations (no correction required by this re-check)

- **O1. `TEXTDOMAINDIR` is a path key of the class the PR already reserves.** The reserved set holds `LOCPATH`, `NLSPATH` and `PATH_LOCALE` (directories of locale data and message catalogs). `TEXTDOMAINDIR` names the directory bash and gettext(1) read message catalogs from, and with `LANGUAGE` it lets a caller choose the text a program prints (ran above). That is text, not code, and it needs a declared key plus a declared caller mount holding the catalog, so I do not call the "no code" claim false. But "change no trust" is not strictly true of a key that picks what a program says, and reserving it is one entry (pinned set, contract mention). Recommendation for the coordinator: reserve `TEXTDOMAINDIR` in the same round as F1, since the sets are being edited anyway.
- **O2. The "Go toolchain keys" sentence is looser than the code, and other same-class keys remain; neither is a finding.** `contracts.md:525` says the single keys include "Go toolchain keys, including `GODEBUG` and `GOTRACEBACK`". The code reserves 12 Go keys. Ran against the head (`isReservedRuntimeEnvKey`, a probe over 62 candidate names that includes ordinary controls such as `TZ` and `TERM`; evidence `probes/`): `GOROOT`, `GOCACHEPROG`, `GOAUTH`, `GOEXPERIMENT`, `CGO_CFLAGS`, `CGO_LDFLAGS`, `CGO_CPPFLAGS`, `GCC_EXEC_PREFIX` and `COMPILER_PATH` are not reserved; neither are credential-class names such as `GH_TOKEN` and `ANTHROPIC_BASE_URL`. `go help environment` (ran) describes `GOCACHEPROG` as "a command … that implements an external go command build cache" and `GOAUTH` as controlling authentication; by parity with `JAVA_HOME` (reserved through `JAVA_`), `GOROOT` names which toolchain a workload runs. Inference: each matters only if a publisher declares it and the workload runs `go` or `gcc`. The contract states the limit twice (`:520` "do not include every such key", `:526` "no list can name every variable every program reads"), and the project's own lesson is that vocabulary guards cannot be complete, so I do not raise this as a finding. If the coordinator wants the Go sentence to be exact, the cheap fix is "the best-known Go toolchain keys". Also not reserved: `MUSL_LOCPATH` (data only; Inference from musl's documented behavior, not run).
- **O3. Items audit 21 and red-team 19 left open are still open, as report 22 says.** AGS refusing to sign a declaration holding a reserved key, caller mounts without execute permission, the artifact digest not covering the declaration, the retained-original integrity classification (audit 21 O2) and unbounded `argv` (RT74-3, O5). None is in this repair, and none was in this re-check's scope.

## Validation (ran)

All runs as an unprivileged user `ci` (uid 1500, gid 1600), `umask 022`, `env -i`, signals reset to default, Go 1.26.5 (`GOTOOLCHAIN=local`, `GOPROXY=off` after `go mod download`), each tree in its own clone of a bundle (tree hashes checked), `go test -json -count=1 -timeout 60m ./...`, one tree at a time. Host packages acl, iproute2, openssh-client, uuid-runtime and the `en_US.UTF-8` locale installed.

| Tree | Top-level pass / skip / fail | Compared with base |
| --- | --- | --- |
| base `a5861b7` | 1843 / 87 / 14 | |
| head `9c06790` | 1861 / 87 / 14 | same 14 failing names (also the same 45 failing with subtests); 18 tests only at head, all pass (the PR's 16 new tests plus `TestReservedFamiliesCoverTheKeysTheRedTeamFoundOpen` and `TestOperationalRetainedRequestEnvIsJudgedByTheSignedDeclaration`); nothing newly skipped, nothing gone, no status change |

The 14 failures are environment-only, identical to audit 21's list for `a5861b7` (3 old-binary probes in `es/admission/internal/reliablesubmit`, `TestLinuxSetupBootstrapFinishesWithItsSavedSecret` and `TestNomadACLToolRetriesABootstrapThatNeverTookEffect` in `es/app`, 9 Remote Alpha tests in `scripts`; `tests/failing-top-level-*.txt`). 55 `es/app` tests skip here (no Docker or Nomad), including the mount flows and the bridge-network test; CI runs them. `gofmt -l` on the four changed Go files is empty; `go build ./...` passes; `go vet` of the root package, `es/admission`, `es/app`, `ags/...` and `internal/...` passes on Linux and `GOOS=darwin GOARCH=arm64`.

**Mutants** (on a clone of the head, targeted tests; `mutants/`): R1 retained-request check returns true, R2 drop `XDG_`, R3 drop `WORKLOAD_VAULT_INSECURE_SKIP_VERIFY`, R4 drop `NOMAD_`, R5 `PHP` widened to `P`, R6 drop `GODEBUG`, R7 prefixes without the ASCII fold, R8 contract stops naming `NOMAD_`, R9 contract restores the overclaim sentence, A2 old standing-rule sentence restored. **10 of 10 killed**, each by the test named in `mutants-log.txt`.

## CI

At 03:33Z, GitHub (read) shows both required checks on `9c06790` still `in_progress`: "build, vet and test" (job 140285058935, started 02:59:44Z) and "test on macOS" (job 140285058666, started 03:06:34Z). I could not report a result. The previous head's runs were green (audit 21). The mount flows, the bridge-network test and the real-AGS refusal test run only there, so a green CI on this head is part of the gate, and I did not wait for it.

## Coverage this environment could not give

- No Docker, Nomad, Vault or SPIRE: the `es/app` mount and network flows and `TestSubmitRefusesAMountTheSignedArtifactDoesNotDeclare` skip here (CI runs them); no macOS run.
- Programs that read the 7 keys were not run, except glibc locale lookup and bash message catalogs (two small probes). What the runtime images hold is not known; I did not inspect the static-script image.
- The sudo table was read from the upstream repository's `plugins/sudoers/env.c` only; I did not determine which release first shipped the additions.
- PR #73 merged with this PR was not tried (not in scope).

## For the writer, in one list

1. F1: add `GCONV_PATH` to the sudo sentence in `contracts.md:520` and the comment at `service.go:125-131`; update the PR body.
2. Optional, same round: reserve `TEXTDOMAINDIR` (O1); reword the Go sentence (O2).
3. Then merge `trunk_dev` again if it moved; a narrow check that the patch lines are unchanged and CI green on the new head decide the merge gate.

## Evidence

`23-pr74-recheck-sonnet-evidence/`: `provenance/` (opening and closing manifests, the repair delta as a diff, commands and the per-file +/- comparison), `upstream/` (extract of both sudo tables, with source hashes), `tests/` (failing-name lists for both trees, the comparison), `probes/` (red-team 19's probes rerun at the head, the same-class key probe, the locale and catalog probe with its output), `mutants/` (runner, log, results), `scripts/` (test runners), and `SHA256SUMS`.

STATUS: READY
