# Writer report 24: ES PR #74 repair after re-check 23

Date: 2026-11-26, about 11:20 PM Eastern (2026-11-27 04:20Z). Writer: the "Stop callers injecting code into runs" thread, which wrote #74 (reports 15 and 22). This replaces the first draft of this report (head 978bccb): the coordinator then decided two more items and #69 landed, so the head moved again.

## Target

| Item | Value |
| --- | --- |
| PR | evo-agi/Execution-Substrate #74, branch `claude/project-thread-ef7st5` |
| Base | `trunk_dev` at `0b9278ca74404b46b5e9f0e1701874b52687f5e8` (#69). Report 22's base was a5861b7 (#68) |
| Head | `e0b5c89214f11b45d7d88a72cad9b0c5f163c5bd`, tree `cf451cca91dc396bcbb8845213e4c2254e65ce01` (pushed; `git ls-remote` equal) |
| Commits since the re-checked head `9c06790` | `6b8bab2` R1, R2 and the TLS-skip suffix; `978bccb` docs test pins the later-sudo sentence; `d0f4fb7` merge of `trunk_dev` 0b9278c (#69), one conflict, resolved (below); `e0b5c89` `LANGUAGE` and the Go and gcc keys (coordinator decisions after this report's first draft) |
| `git diff 0b9278c e0b5c89` (whole PR on the new base) | 31 files, +1549 / -77; `\| sha256sum` = `4f32f7adbf56ec8663387bbd57528212777de464ed20d5fab7b9a586f91b7412` |
| Delta to re-check | `git diff 9c06790 978bccb` (6 files, +125 / -42, sha256 `2da5ced3e5c931fe0e071d8cda93c7d43d47d9ec8ecebe8b32e2e639118987d4`), `git diff d0f4fb7 e0b5c89` (4 files, +67 / -23, sha256 `d80aff5abbb5130661a961d7be48abb40e3c3d5e059517dcb37f48c955269d7f`), and the merge resolution `git show --remerge-diff d0f4fb7` (2 files). `git diff 9c06790 e0b5c89` also carries #69's own changes, so it is not the right view |
| Canonical manifest (O4) | recipe `governed-execution.audit-patch-manifest.v2` (source SHA-256 `c08597e2…a3ca`, `sha256sum -c` OK), fresh clone of the pushed branch, reset `--mixed` to `origin/trunk_dev` 0b9278c, upstream `origin/trunk_dev`; run twice, `cmp` identical. `manifest_sha256` `6fc6c2927af698d2c28cccb334465d6fd735f86b8ace3c12ae440ed3d44446aa`, 31 files, `textual_diff_sha256` `31f0b9b39939dbbca3285c60a8db376c620ec35a1341bde0d5d235d525a312a4`. File: `24-pr74-repair-evidence/manifest-v2-e0b5c89-on-0b9278c.json` (the 978bccb-on-a5861b7 manifest is kept beside it) |
| Gate | one narrow re-check of the delta above, then CI on e0b5c89 |

The two paths new to the PR compared with report 22's 29 are `.examples/runtime_identity_reference/README.md` and `.runbooks/execution/Governed Execution ES Submit Runtime Identity Reference Workload.md`.

## Delta to re-check

Product code, one file: `es/admission/service.go`. Map entries, one prefix, a new one-element suffix slice with a three-line loop in `isReservedRuntimeEnvKey`, comments. `validateInvocationAgainstManifest` is unchanged.

| Item | Change |
| --- | --- |
| R1 (re-check 23, Opus) | `TEXTDOMAINDIR` and `TEXTDOMAIN` reserved (comment: bash expands a translation of `$"..."` as double-quoted text, so a catalog the caller chooses could run commands). `TEXTDOMAINDIR` is gone from `TestOrdinaryEnvironmentKeysAreNotReserved`, and the false "they load no code and change no trust" is gone from that test and from above `redTeam74FamilyKeys`. Both are pinned and in the end-to-end refusal table; the contract names them in the single-keys bullet. |
| `LANGUAGE` (coordinator, after this report's first draft) | Reserved with the two above. Reason, in the contract and the code comment: upstream glibc's gettext (`intl/dcigettext.c`, read in 2.39 and 2.42) skips a `LANGUAGE` entry that holds a path only in set-user-ID programs, and I found no other filter in `finddomain.c`, `l10nflist.c`, `explodename.c` or `loadmsgcat.c`, so such an entry can name a catalog outside the bound directory. This container's Ubuntu glibc 2.39 ignored every entry holding a `/`, through bash and through `dgettext` directly (probe in `24-pr74-repair-evidence/language-probe/`); Inference: a distribution patch does that. A backstop does not rest on one build. Pinned, refused end to end (`Language`), out of the ordinary list. |
| `LANG`, `LC_ALL` | Stay open. The contract now says why: glibc refuses a locale name that climbs out of the locale directory and looks a name up only under that directory unless `LOCPATH`, which is reserved, is set (`locale/findlocale.c`, `valid_locale_name` and the lookup after it, read in 2.42; re-check 23 probe 7). `GOMEMLIMIT`, `GOGC` and `GOMAXPROCS` stay open as runtime tuning. |
| Go and gcc keys (coordinator; re-check 23 Sonnet O2) | Reserved: the Go keys that choose which toolchain, compiler or helper command runs, where modules, sources and build results come from or go, or how the toolchain builds and fetches (`go help environment`, Go 1.26.5): `GOROOT`, `GOPATH`, `GOBIN`, `GOCACHE`, `GOCACHEPROG`, `GOMODCACHE`, `GOWORK`, `GOAUTH`, `GOVCS`, `GOEXPERIMENT`, `GOTMPDIR`, `GCCGO`, and the family `CGO_` (cgo's flags and their allow and deny lists); gcc's `GCC_EXEC_PREFIX`, `COMPILER_PATH`, `LIBRARY_PATH`, `CPATH`, `C_INCLUDE_PATH`, `CPLUS_INCLUDE_PATH`, `OBJC_INCLUDE_PATH`, `GCC_COMPARE_DEBUG`. Already reserved: `GOFLAGS`, `GOENV`, `GOTOOLCHAIN`, the module proxy and checksum keys, `CC`, `CXX`, `CPP`, `CFLAGS` and the like. Left open: `GOOS` and `GOARCH`, which choose only among code the artifact already holds (pinned as ordinary), the other target-architecture keys, `GO111MODULE` (GOPATH and HOME are reserved) and `GOFIPS140`. The contract's Go sentence names the kinds instead of "the best-known Go toolchain keys". |
| R2 (re-check 23, both) | Contract and the sudo comment name `GCONV_PATH` as the eighth later-sudo entry, "which the glibc list above already holds". The docs test requires the whole later-sudo sentence. |
| TLS-skip switches (coordinator, re-check 23 Opus O1) | New `reservedRuntimeEnvSuffixes = []string{"INSECURE_SKIP_VERIFY"}`, matched on the ASCII-folded key: covers `REFERENCE_VAULT_INSECURE_SKIP_VERIFY`, `WORKLOAD_VAULT_INSECURE_SKIP_VERIFY` (still also listed by name), a bare `INSECURE_SKIP_VERIFY` and any other `*_INSECURE_SKIP_VERIFY`. Contract: a new bullet, and the suffix list named as part of "the exact list". Tests: pin of the suffix list; probes with the suffix and `X1_`+suffix in three cases; refusal cases; near misses (`SKIP_VERIFY`, `INSECURE_SKIP_VERIFY_NOTE`) ordinary. The docs test reads the suffix list from the AST, requires "ends in `<suffix>`" and counts a suffix match as reserved. |
| Runbook and example | The reference-workload runbook's step 4 publish request no longer declares `REFERENCE_VAULT_INSECURE_SKIP_VERIFY` (the submit request never sent it); a Notes bullet says the workload checks Vault's certificate against the bundle ES gives it in `SSL_CERT_FILE` (or the image's store), why a caller must not turn that off, and that ES refuses the key; History entry. The example README says the switch applies only outside ES. Entrypoint and its tracked archive unchanged. |
| Merge of #69 (`d0f4fb7`) | #69 moved PLANS.md's "Workstream C admission and custody rules" section into `.docs/standing_rules/execution_admission_and_custody.md`. PLANS.md conflicted; I took #69's removal. This PR's edit to that text ("change environment or mount admission (which the shared admission path owns, …)" in place of "silently tighten the current empty-environment-allowlist contract") is carried into the moved copy (standing rule, about line 1033), as the PR body foresaw ("whichever lands second carries the edit"). The other PLANS.md edit (current facts, lines 289-290) merged cleanly. The docs test's refusal of the old wording in five docs still passes. |

## Checks behind the claims

- `SSL_CERT_FILE`: ES sets it to the platform bundle when the workload-zone trust carries one (`es/admission/resolved_execution_plan.go:690-692`); the entrypoint uses Python's default TLS context, which takes OpenSSL's default paths, and OpenSSL reads `SSL_CERT_FILE` from the environment. Inference from reading, not run on the box.
- Repo inventory (`git grep`): the only TLS-skip switches read from the environment are `WORKLOAD_VAULT_INSECURE_SKIP_VERIFY` (three entrypoints) and `REFERENCE_VAULT_INSECURE_SKIP_VERIFY` (one). Declared keys left in the repo: `APP_MODE`, `API_URL`, `ALLOWED_ENV`, `WORKLOAD_VAULT_SECRET_PATH`, `REFERENCE_IDENTITY_URL`, `REFERENCE_SECRET_PATH`; none is reserved. (Report 22's inventory missed the reference workload's three.)

## Validation (ran, as root in this container)

- `go build ./...`; `go vet` on root, `es/admission`, `es/app`, `ags/...`, `internal/...`: clean on 6b8bab2; root and `es/admission` vet clean on e0b5c89. `gofmt -l` on the three changed Go files: empty.
- On 6b8bab2: `go test -count=1 ./es/admission/` ok (303 s); full suite `go test -json -count=1 -timeout 60m ./...` 1826 pass, 81 skip, 55 fail, the 55 failing names equal 9c06790's name for name (3 `reliablesubmit` old-binary probes, 14 `es/app`, 38 `scripts`), all environment-only and failing on the base too. List: `24-pr74-repair-evidence/failing-top-level-6b8bab2.txt`.
- On e0b5c89: `go test -count=1 .` (root, including #69's new docs guards and `TestCallerDeclarationRulesAreInTheLifecycleContract`) ok; targeted `es/admission` tests ok. Full suite: 1830 pass, 81 skip, 55 fail. The four extra passes are #69's new tests. The 55 failing names equal 6b8bab2's and 9c06790's name for name (`24-pr74-repair-evidence/failing-top-level-e0b5c89.txt`).
- Mutants on e0b5c89, 15 of 15 killed (`24-pr74-repair-evidence/mutants-log-e0b5c89.txt`): S1–S4 suffix loop removed, suffix list emptied, `TEXTDOMAINDIR` or `TEXTDOMAIN` dropped; S5 contract stops naming the suffix; S6 suffix matched as a prefix; S7 without the ASCII fold; S8 contract drops `GCONV_PATH` (survived on 6b8bab2, killed since 978bccb's sentence pin); S9–S12 `LANGUAGE`, `GOCACHEPROG`, `CGO_`, `GCC_EXEC_PREFIX` dropped; S13 contract stops naming `CGO_`; S14 contract drops the `LANGUAGE` reason; S15 contract names `GOOS` as reserved. Each is killed by `TestReservedEnvironmentKeySetIsPinned`, the refusal test, `TestOrdinaryEnvironmentKeysAreNotReserved` or one of the two docs tests.
- CI on 9c06790: both required checks green ("build, vet and test", "test on macOS"). CI on 978bccb: superseded. CI on e0b5c89: both required checks green ("test on macOS" 04:38Z, "build, vet and test" 04:55Z).

## Security widening

None. Every change refuses more caller keys. The cost: a publisher can no longer let callers set the keys above, including choosing the message language through `LANGUAGE` (`LANG` and `LC_ALL` remain). Inference: no flow in this repo or the project's other repos needs any of them (inventory above).

## Open, for the coordinator

- **Archived-Runbooks copy.** The reference-workload runbook's copy on Archived-Runbooks `main` (8d99aa0, line 168) still declares the switch. Its new Notes text describes behavior that exists only once #74 merges, so the copy should be refreshed from `trunk_dev` after the merge, as AR PR #12 did after #60. Suggest a backlog line tied to the #74 merge.
- Not asked for and left open: `MUSL_LOCPATH` (re-check 23 Opus O2, data only) and clang's own keys such as `CCC_OVERRIDE_OPTIONS`.
- Unchanged from report 22: red-team 19's two design options (AGS refusing to sign a reserved key; caller mounts without execute permission) and its observation 2; audit 21 O2 (retained original before this PR); unbounded argv (RT74-3, O5).

## Confidence

Provenance high (manifest twice, identical; pushed head equal). Validation high for what this container runs; Docker/Nomad flows rely on CI. Implementation high: list entries, one prefix, a one-element suffix list with a three-line loop, comments, docs and tests; the merge resolution is mechanical; the admission logic audit 21 checked is unchanged. The `SSL_CERT_FILE` runbook sentence and the glibc source reading behind `LANGUAGE` are from reading, not a box run.
