# Writer report 28: ES PR #74 repair after re-check 27

Date: 2026-11-27, about 1:40 AM Eastern (06:40Z).

> Corrections (report 29, after re-check 28): `VSB_DIR` is not only a spec example, since gcc's VxWorks 7 specs read it, and it is now reserved. "Pins N1's order" below was not true for the order N1 reported; 10a3b58 pins the paragraph whole. The guard's "a new spelling cannot slip past" overstated it; report 29 states what the scan reads and what it does not see. Writer: the "Stop callers injecting code into runs" thread, which wrote #74 (reports 15, 22, 24 and 26).

## Target

| Item | Value |
| --- | --- |
| PR | evo-agi/Execution-Substrate #74, branch `claude/project-thread-ef7st5` |
| Base | `trunk_dev` at `0b9278ca74404b46b5e9f0e1701874b52687f5e8` (#69), unchanged since report 24 |
| Head | `0e56e23ed9c5ba4742f5967d145373dc157c3a64`, tree `3be25b02a4fc447dce00db61e4ed403aea197378` (pushed; `git ls-remote` equal) |
| Commits since re-checked `956991c` | `0e56e23`: R27-1/F1, N27-1, N27-2, Sonnet O1 and O2. No merge (base unchanged) |
| Delta to re-check | `git diff 956991c 0e56e23`: 4 files, +112 / -32, `\| sha256sum` = `bc55758467ce59798d60698a0154694b5a14b4c458bcc54d5305abf2c3e33e79` |
| `git diff 0b9278c 0e56e23` | 31 files, +1714 / -77, sha256 `8d9fd4453ce0dab950184e25846b31a434d82ea5a527d2094cd7d0e709249938` |
| Canonical manifest (O4) | recipe v2 (source SHA-256 `c08597e2…a3ca`, `sha256sum -c` OK), fresh clone of the pushed branch, reset `--mixed` to `origin/trunk_dev` 0b9278c; run twice, `cmp` identical. File SHA-256 `731646edec2a92fd89d746490ae50671ba984731c172bb4d86d7f3f8dc297fd5`, 31 files, `textual_diff_sha256` `eca96ce341048e2563e1fff05e1eed49077198fa7a5457f2571864d9e5fa7fd7`. File: `24-pr74-repair-evidence/manifest-v2-0e56e23-on-0b9278c.json` |
| Archived-Runbooks | evo-agi/Archived-Runbooks #30 (draft), branch `claude/project-thread-ef7st5`, head `d65e8df`, base `main` `8d99aa0` |

## Delta

Product code: `es/admission/service.go`, three map entries and a comment.

| Item | Change |
| --- | --- |
| R27-1 (Opus) / F1 (Sonnet) | Reserved by name: `MAKE` (lto-wrapper runs it for a parallel LTO link), `CXX_MODULE_MAPPER` (its `\|program` form names a program cc1plus starts) and `MSP430_GCC_INCLUDE_DIR` (the msp430 port's header and linker-script directory; only a cross compiler reads it, reserved so the sentence holds literally, as Opus recommended). Added to the pin, the refusal table (`MAKE`, `make`, `CXX_MODULE_MAPPER`, `MSP430_GCC_INCLUDE_DIR`) and the contract's gcc parentheses; `MAKE_TARGET` added as a near miss to the ordinary-keys test (the key is exact, not a prefix). |
| Source named exactly | The contract's gcc clause now reads "every such key a GCC program reads that the GCC 14.2.0 manual, `gcc/doc/gcc.texi` and the files it includes, names in any section, not only in its section on environment variables, and the two that gcc's driver and preprocessor read and the manual leaves out, `LPATH` and `OBJCPLUS_INCLUDE_PATH`". The code comment says the same. A new sentence after the stay-open sentences says what the class leaves out: "keys the GCC manual names that a program built with gcc reads when it runs, such as the sanitizer runtime's `ASAN_OPTIONS` and the coverage runtime's `GCOV_PREFIX`, are outside that class and are not reserved." |
| My own enumeration of the source | Fetched `gcc/doc/gcc.texi` at `releases/gcc-14.2.0` and every file it includes (frontends, standards, invoke with cppwarnopts, cppopts, cppdiropts, avr-mmcu, cppenv and libiberty's at-file, implement-c, implement-cxx, extend with md, objc, compat, gcov, gcov-tool, gcov-dump, lto-dump, trouble, bugreport, service, contribute, gnu, contrib and the licence texts). Names found: 29 `@env` names, cppenv's `@item` names (`C_INCLUDE_PATH`, `CPLUS_INCLUDE_PATH`, `OBJC_INCLUDE_PATH`, `SUNPRO_DEPENDENCIES`), `@vindex` locale names (`LC_COLLATE`, `LC_MONETARY`, `LC_NUMERIC`, `LC_TIME`), and in plain text `MSP430_GCC_INCLUDE_DIR`, `GCOV_PREFIX`, `GCOV_PREFIX_STRIP`, `GCOV_ERROR_FILE`, `GCOV_EXIT_AT_ERROR`, and the spec examples `TOPDIR` and `VSB_DIR`. Placed: in the class and now all reserved: `GCC_EXEC_PREFIX`, `COMPILER_PATH`, `LIBRARY_PATH`, `CPATH`, `C_INCLUDE_PATH`, `CPLUS_INCLUDE_PATH`, `OBJC_INCLUDE_PATH`, `GCC_COMPARE_DEBUG`, `DEPENDENCIES_OUTPUT`, `SUNPRO_DEPENDENCIES`, `MAKE`, `CXX_MODULE_MAPPER`, `MSP430_GCC_INCLUDE_DIR`, with `PATH` and `TMPDIR` reserved elsewhere. Read by the built program, not gcc: the five sanitizer `*_OPTIONS`, `VTV_LOGS_DIR` and the four `GCOV_*` keys (the gcov ones were not in either re-check's table; they are in the same group as the sanitizer keys). Locale, diagnostics text and layout: `LANG`, `LC_*`, `SOURCE_DATE_EPOCH`, `GCC_EXTRA_DIAGNOSTIC_OUTPUT`, `GCC_COLORS`, `GCC_URLS`, `TERM_URLS`, `COLUMNS`. Not environment reads of gcc: `GCC_INCLUDE_DIR`, `TARGET_SYSTEM_ROOT` (configure-time values), `TOPDIR`, `VSB_DIR` (examples of a spec file's `getenv`). This matches both re-checks' placement. |
| N27-2 / Sonnet N1 | The comment above the single keys is re-wrapped; its longest line is now 75 characters with tabs counted as one, like its neighbours. |
| N27-1 and Sonnet O1 | The runbook guard reads an entry the way a publish request carries it: JSON escapes decoded (`json.Unmarshal`, then Go unquoting), and the shared matcher trims white space and folds only ASCII letters, as `isReservedRuntimeEnvKey` does. It also reads single-quoted (Python) lists. It counts every `environment_variables` followed by `:` or `=` and `[`, quoted or not, escaped quotes included, and fails when that count differs from the lists it parsed, so a new spelling cannot slip past. It needs at least one declaration in each of `.runbooks`, `.examples` and `scripts` (Sonnet's H5), and it checks its own matcher (`" LD_PRELOAD"`, `"ld_preload\t"` and `"Shell"` reserved, `"\u017fhell"` not). |
| Sonnet O2 / Opus O1 | Pinned as required phrases: the whole backstop sentence through "Some keys of these kinds stay open on purpose." (pins N1's order), the full `LANG` and `LC_ALL` sentence, "every such key `go help environment` lists in Go 1.26.5", the whole gcc clause (pins the category "a file it writes with text the caller chooses", every listed key including `LPATH`, `DEPENDENCIES_OUTPUT` and `SUNPRO_DEPENDENCIES`, and the source wording), the `GOOS` sentence, the `SOURCE_DATE_EPOCH` sentence and the new scope sentence. |
| Sonnet O5 (Archived-Runbooks copy) | Archived-Runbooks has a machine-enforced trigger, which re-check 27 did not find: its workflow "ES runbook copies match Execution-Substrate" compares each copy with ES `trunk_dev`, daily at 10:17 UTC, on pull requests and on each push to `main`. Ran its script locally: `main` passes against `trunk_dev` (0 problems) and fails against this PR's branch on exactly this file (1 problem). So changing the copy now would fail that repository's own check, and the day after #74 merges the check fails until the copy is refreshed. I opened the refresh as draft PR #30: the ES file at 0e56e23 copied word for word, with the one relative link made absolute and the note naming 0e56e23. Against this branch the check reports 0 problems; against `trunk_dev` it reports 1, by design. After the merge: point the note at the `trunk_dev` commit and mark it ready. |

## Validation (ran, as root in this container)

- `go vet` on root and `es/admission`: clean. `gofmt -l` on the changed Go files: empty.
- Root package (full) and the targeted `es/admission` tests (`TestReserved|TestOrdinary|TestEmptyEnvironment|TestCaller|TestDeclared|TestEnvironmentRefusal|TestOperationalRetained|TestRedTeam`): ok on 0e56e23.
- Full suite on 7c0e3de, the first cut of 0e56e23 (`go test -count=1 -json ./...`, as root): 1831 pass, 81 skip, 55 fail. The 55 failing names equal bba0248's name for name (`24-pr74-repair-evidence/failing-top-level-7c0e3de.txt`), all environment-only. 0e56e23 differs from 7c0e3de only by the matcher self-check in the root docs test; the root package passes in full on 0e56e23.
- Mutants, 22 of 22 killed on 0e56e23 (`24-pr74-repair-evidence/mutants-log-0e56e23.txt`, runner `mutants-0e56e23.py`):

  | Mutant | Killed by |
  | --- | --- |
  | U1–U3: `MAKE`, `CXX_MODULE_MAPPER` or `MSP430_GCC_INCLUDE_DIR` dropped from the map | the pin, the refusal test and the contract test |
  | U4: example declares `" LD_PRELOAD"` (re-check 27's M12 and G07) | the guard |
  | U5: example declares `"LD_\u0050RELOAD"` (G08) | the guard |
  | U6: a script holds a single-quoted Python list declaring `LD_PRELOAD` (G09) | the guard |
  | U7: a runbook declares an unquoted `environment_variables: [` list | the guard's spelling count |
  | U8: a script declares through escaped quotes `\"environment_variables\": [` | the guard's spelling count |
  | U9: the scan drops the `scripts` root (H5) | the guard's per-root check |
  | U10: the matcher stops trimming, with U4's entry | survived on 7c0e3de, the first cut; killed on 0e56e23 by the matcher self-check |
  | U11: the matcher folds with Unicode case mapping | the matcher self-check |
  | C1–C9: the contract drops the Go source clause, reverts the gcc source wording, drops the "file it writes" category, drops `DEPENDENCIES_OUTPUT` and `SUNPRO_DEPENDENCIES`, drops the `LANG`, `GOOS`, `SOURCE_DATE_EPOCH` or scope sentence, or moves the `LANG` sentence back before the boundary sentence | the required phrases |
  | C10: the contract names `ASAN_OPTIONS` among the reserved gcc keys | the required phrase and the contract test |
- CI on 956991c: both required checks green. CI on 0e56e23: both required checks were running when this report was written (started 06:23Z); both went green (macOS 06:57Z, Linux 07:09Z, per re-check 28 Sonnet).

## Security widening

None. The change refuses three more caller keys, and every other change is a test, a comment or a contract sentence. The cost: a publisher can no longer let callers set `MAKE`, `CXX_MODULE_MAPPER` or `MSP430_GCC_INCLUDE_DIR`. No artifact in the project declares any of them (re-check 27 Sonnet's cross-repo grep, and the guard over this repository).

## Open, for the coordinator

- Archived-Runbooks #30 lands after #74 merges; the daily copy check enforces it.
- Unchanged from report 26: red-team 19's design options (AGS refusing to sign a reserved key; caller mounts without execute permission), audit 21 O2, unbounded argv, `MUSL_LOCPATH` and clang's own keys such as `CCC_OVERRIDE_OPTIONS`.
- New, not asked for: keys the GCC manual names for a program built with gcc, which run code or write files when that program runs: the sanitizer runtimes' `*_OPTIONS` (their options can name a symbolizer program) and `GCOV_PREFIX` (where the coverage runtime writes). The contract now says they are outside the class. Re-check 27 raised the sanitizer group as O4 (Sonnet) and O2 (Opus); `GCOV_*` is the same group. GCC's `COLLECT_*` keys (Opus O2) are also outside the class.
- Re-check 27 Sonnet O3 (name the other open Go keys) and O6 / Opus O3 (`PKG_CONFIGURATION` falls under the prefix) are left as they are: the sentence says "Some keys", and the pin catches any change to the set.

## Confidence

- **Provenance: high.** The manifest was built twice and both runs are identical; the pushed head equals the local one.
- **Validation: high** for everything this container can run. The Docker and Nomad flows rely on CI.
- **Implementation: high.** Three map entries, a comment, contract sentences and tests; admission logic is unchanged since audit 21.
- **Source enumeration: high** for the GCC 14.2.0 manual as fetched from the GCC mirror's `releases/gcc-14.2.0` tag. Not run: `MSP430_GCC_INCLUDE_DIR` (no msp430 cross compiler here); its effect is from the manual. `MAKE` and `CXX_MODULE_MAPPER` were demonstrated by both re-checks, not again by me.
