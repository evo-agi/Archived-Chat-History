# Re-check 29 (Opus): ES PR #74 at 10a3b58: ACCEPT (R28-1, N28-1 and N28-2 fixed; the guard holds within its stated limits; no new finding)

Date: 2026-11-27, about 3:05 AM Eastern (08:05Z). Thread: "Opus re-check 29 of PR 74", fresh and read-only. I did not write #74 and did not audit it before this round. Blind pair in the model-evaluation trial (category R-M, security): I did not read the Sonnet report for this round or its evidence folder, and I messaged no thread. Model: [model withheld]. Inputs read: re-check 28 Opus report, writer report 29, and a project-memory note summarizing re-check 28 Sonnet (that report not opened).

Source labels: "ran" means I ran it in this container on the commit named; "read" means I read the code, document or upstream source and did not run it; "CI" means read from GitHub; "Inference:" marks my reasoning.

```text
INDEPENDENT AUDIT REPORT (narrow re-check of a repair, protocol §14)
Repository / Audit target:
  evo-agi/Execution-Substrate PR #74, branch claude/project-thread-ef7st5
  base 0b9278ca74404b46b5e9f0e1701874b52687f5e8 (trunk_dev, #69)
  topic commit 10a3b587930b622bec25eee532ba3cad3b349518, tree 5cea997d63751be9a7794bc3efbd04a927b3f02a
  recipe governed-execution.audit-patch-manifest.v2, source SHA-256
    c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (sha256sum -c OK before each run)
  canonical-manifest SHA-256 0e198ba98335ad47a17bcfe245c8e203c61e74c6ee00fd5e1189ed5ccf275338, 31 paths,
    textual_diff_sha256 44f533fa988296b6626c9bd77d64c52dfff4c2cee31f808b0119b90f177500c6
  Scope (coordinator): git diff 0e56e23 10a3b58 (4 files, +148 / -58). R28-1 (VSB_DIR reserved),
    N28-1 (the runbook guard as a function with a 22-case table test and its limits stated),
    N28-2 (the open-keys paragraph pinned whole). The guard is judged by its stated limits; no
    hunt for further spellings. Source closed as in re-check 28.
Audit posture: read-only. Parent only, no subagents. Nothing pushed, nothing posted on GitHub, no
  Linux box, no live service. Tests, probes and mutants ran as an unprivileged user (ci, uid 1500,
  umask 022, env -i with no proxy variable) in clones made from a bundle, never in the provenance clone.
Provenance reproduction: equal to writer report 29's manifest file, byte for byte; opening and
  closing runs identical (two runs each).
Findings: none. 3 observations.
Validation assessment: root package and es/admission in full on head and on 0e56e23: both pass,
  0 failing tests on either, no status change; the head adds the new table test and the VSB_DIR and
  vsb_dir refusal subtests. Same packages plus internal/testutil in a git-archive tree without .git:
  all pass. 25 of 25 mutants killed by the check meant to catch them; the 2 spellings the scanner's
  comment says it does not see pass, as stated. Case-folding claim power-checked over every rune.
  CI on 10a3b58: both required checks green (macOS 07:56Z, Linux 08:02Z).
Sensitive-material handling: no secrets, keys, tokens, env files, SQLite or TLS/SPIFFE/Vault
  material read into the report or evidence.
Confidence: provenance high / validation high / implementation high.
Effect status: repair, commit, push, PR, merge not performed.
Report delivery: /mnt/project-files/reports/Execution-Substrate/workload-identity/29-pr74-recheck-opus.md
  (SHA-256 in the delivering message), evidence in 29-pr74-recheck-opus-evidence/ (SHA256SUMS inside).
Final verdict: ACCEPT
```

## In plain words

All three re-check 28 items are fixed, and nothing new turned up in the delta.

1. **R28-1, `VSB_DIR`.** It is now reserved by name, pinned, refused (also as `vsb_dir`) and named in the contract's gcc list and the code comment. Dropping it, or turning it into a prefix, fails the tests.
2. **N28-1, the runbook guard.** The guard is now a function with its own 22-case table test. It reads the declaration key in any letter case, the way AGS's JSON decoder matches it. It counts every spelling it can't read and fails on it. Its comment states what it doesn't see. I checked each claim in that comment, killed every branch by changing it, and confirmed that the two blind spots the comment names really are blind spots, and nothing beyond them.
3. **N28-2, the open-keys paragraph.** It is now one pinned phrase. The exact reorder Sonnet reported and three other edits all fail.

## Provenance (ran)

| Step | Result |
| --- | --- |
| Recipe bytes | `sha256sum -c` OK (`c08597e2…a3ca`) on the shared file and on the copy that ran, before the opening (07:24Z) and closing (07:40Z) runs |
| Pushed tip | `git ls-remote` at 07:22Z and again at 07:40Z: `refs/heads/claude/project-thread-ef7st5` and `refs/pull/74/head` = `10a3b58`, `trunk_dev` = `0b9278c` |
| Base ancestry | `git merge-base --is-ancestor 0b9278c 10a3b58`: yes; `10a3b58`'s parent is `0e56e23`, no merge |
| Opening manifest | fresh clone from GitHub of the branch (`git status` clean at the tip), `git reset --mixed origin/trunk_dev`, upstream `origin/trunk_dev`; two runs, `cmp` identical, SHA-256 `0e198ba9…5338`, equal byte for byte to `24-pr74-repair-evidence/manifest-v2-10a3b58-on-0b9278c.json` |
| Committed blobs | 31 of 31 records equal the blob at `10a3b58` (SHA-256 and size); every mode `0644`; path set equals `git diff -z --name-only 0b9278c 10a3b58` |
| Diffs | `git diff 0e56e23 10a3b58`: 4 files, +148 / -58, `\| sha256sum` `417a6719…4bb8`; `git diff 0b9278c 10a3b58`: 31 files, +1804 / -77, `109f0941…e82d` (both equal to report 29) |
| Closing run | same clone, recipe re-verified: two runs identical and equal to the opening manifest |

## The claimed fixes

| Item | Verdict | Evidence |
| --- | --- | --- |
| R28-1: `VSB_DIR` reserved | Fixed | Read at `10a3b58`: map entry `es/admission/service.go:321`; comment :212-213 ("VSB_DIR, which gcc's VxWorks 7 specs read for header directories and to choose a library (the manual's spec-file example)"); pin `caller_declaration_test.go:231`; refusal table :378 (`VSB_DIR`, `vsb_dir`); contract `.docs/execution_lifecycle/contracts.md:525` gcc parentheses; required phrase `caller_declaration_docs_contract_test.go:48`. `git grep -w VSB_DIR` finds it in exactly those 4 files (7 lines). Ran: subtests `TestReservedEnvironmentKeysAreRefusedEvenWhenTheArtifactDeclaresThem/VSB_DIR` and `/vsb_dir` pass. Mutants V1 (dropped from the map: killed by `TestReservedEnvironmentKeySetIsPinned`, the refusal test and `TestLifecycleContractNamesOnlyReservedKeysTheCodeReserves`), V2 (contract drops it: killed by the pinned gcc clause), V3 (moved to a prefix: killed by the pin). The writer's citation of gcc `config/vxworks.h` lines 89-90 and 145 is exact (read in re-check 28's fetched copy, SHA-256 `4a016616…b015`, `28-pr74-recheck-opus-evidence/upstream/gcc-sources/vxworks.h`). The comment block's longest line is 75 columns with a tab as one; gofmt clean. |
| N28-1: the guard reads or fails on the key spellings AGS accepts | Fixed, within the stated limits | See the next section. |
| N28-2: the open-keys paragraph pinned whole | Fixed | Read: the required phrase at `caller_declaration_docs_contract_test.go:38` runs from "`TestReservedEnvironmentKeySetIsPinned` pins it." through the scope sentence and equals the contract text. The six separate pins it replaces (pin sentence, backstop, `LANG`, `GOOS`, `SOURCE_DATE_EPOCH`, scope) are all inside it, so no pinned text was lost. Mutants: C11 (the backstop sentences moved after the `LANG` sentence, the order N1 reported), C12 (`GOOS` and `SOURCE_DATE_EPOCH` sentences swapped), C13 (scope sentence moved first), C14 (one word dropped): all killed by `TestCallerDeclarationRulesAreInTheLifecycleContract`. |

## The guard, judged by its stated limits

What it claims (read, `caller_declaration_docs_contract_test.go:296-321` and the PR body's "Guards and tests" list): it reads a quoted `environment_variables` key in any letter case (as `encoding/json` matches a field name, U+017F as s included) and entries that hold `]`. It decodes entries as JSON, then as Go strings, and single-quoted ones as Python. It counts every spelling after `\uXXXX` decoding (quoted or not, escaped quotes, an index, `:` or `=`, a list or a YAML block list) and fails when the count differs from what it reads. It fails on a list item that isn't a quoted string and on an entry neither decoder reads. It needs a scanned file in each of the four roots. It states that it doesn't see a key name escaped other than with `\uXXXX`, a declaration built in code, or YAML in other forms.

| Check | Result |
| --- | --- |
| The table test has 22 cases (PR body, report 29) | Counted: 22 (ran). The three cases whose meaning rests on an escape hold the literal backslash sequence in the file, not the character (checked byte by byte; the file is pure ASCII), so a tool rewrite did not weaken them. |
| "(?i) folds as `encoding/json` matches a field name, U+017F as s included" | Power-checked (ran, `probes/fold-*`, Go 1.26.5): for each of the 13 distinct characters of `environment_variables`, over every valid rune, Go `regexp` `(?i)`, `bytes.EqualFold` and an `encoding/json` decode with `DisallowUnknownFields` into a field tagged `environment_variables` accept exactly the same runes. That is the ASCII pair for each letter, plus U+017F for `s`. 0 disagreements. |
| Plants the scanner says it reads | Killed by the read and the reserved-key check: D04 upper-case key in the example, D06 a second upper-case key after the real one, D07 a runbook key ending in raw U+017F, G16 an entry holding `]` before `LD_PRELOAD` in `run.sh`. |
| Plants the scanner says it counts and fails | Killed by "N declarations, but the scan reads M": D05 key with an escaped underscore, D07e key ending in an escaped U+017F, G11 an indexed assignment, G12 a YAML block list. Killed by the item and decode checks: G17 an unquoted list item, D08 a Python named escape. |
| Each branch of the scanner | Killed by the table test: H1 read pattern loses `(?i)`, H2 count pattern loses `(?i)`, H3 count on raw text, H5 unquoted-item check removed, H6 undecodable entry accepted, H7 double-quoted entries not decoded. Killed by the per-root check: H4 walk drops `.docs`. |
| The stated limits are real, and only those | L1 (a runbook key written `'environment\x5fvariables'`, an escape other than `\uXXXX`) and L2 (a YAML block list with a comment after the colon) pass every test. Both are named in the comment. Nothing I planted outside those named classes slipped through. |
| Read and count cannot cancel within one file | Inference from the code: the read pattern's matched prefix (`["']environment_variables["']\s*:\s*\[`) holds no backslash, and the count pattern starts with the literal word, so `\uXXXX` decoding leaves every read declaration intact and counted. "Read" is therefore a subset of "counted", and the per-file comparison fails exactly when some counted declaration is unread. One unread spelling can't be hidden by an extra read elsewhere in the same file. |

## Findings

None.

## Observations (no correction required by this re-check)

- **O1. The comment's limits are honest.** L1 and L2 survive, as the comment says they do. Any further declaration form would need a parser per format, which the comment says plainly. Under the coordinator's scope ("judge by stated limits"), they are not findings.
- **O2. V3 is caught only by the pin.** Moving `VSB_DIR` from the key map to the prefix list still refuses `VSB_DIR` and passes the contract test, so only `TestReservedEnvironmentKeySetIsPinned` fails. That is enough, because the pin exists for exactly this. The refusal table has no `VSB_DIR` near-miss (`MAKE` has `MAKE_TARGET`). That costs nothing while the pin holds. I raise nothing.
- **O3. Writer's open items unchanged.** `TMP`/`TEMP`, `WIND_BASE`, `OFFLOAD_TARGET_*` and `COLLECT_*` are outside the closed source and not judged here, as in re-check 28 (O4).

## Validation

All runs as `ci` (uid 1500), `umask 022`, `env -i` (no proxy variables), Go 1.26.5 (`/opt/go1265`, `GOTOOLCHAIN=local`, `GOPROXY=off`, module cache filled first), launched through `tests/sigreset.py` (SIGHUP and friends reset). One clone per tree from a bundle; trees checked (`5cea997d…`, `3be25b02…`). Command (`tests/run-pkgs.sh`): `go vet . ./es/admission/`, then `go test -count=1 -timeout=30m -json . ./es/admission/`. Head and `0e56e23` ran side by side, 07:25Z to 07:36Z. Scope: only these two packages hold the delta. I did not run the full suite this round; report 28's full runs found the same failing names on both trees before this delta.

| Tree | Top-level pass / skip / fail (both packages) | Compared |
| --- | --- | --- |
| `0e56e23` | 780 / 14 / 0 | |
| `10a3b58` | 781 / 14 / 0 | 0 failing tests on either. No status change. The head adds `TestEnvironmentDeclarationScanReadsEachSpelling` and the `VSB_DIR` and `vsb_dir` refusal subtests. The other name differences are the randomized `TestRedTeamPR12*/round_*` subtests, which differ by design (`tests/summary.txt`). |
| `10a3b58`, git-archive tree without `.git` | 786 / 15 / 0 (root, `es/admission`, `internal/testutil`) | all pass (`tests/nogit-summary.txt`) |

Failing test names: none in any run. `go vet`: clean on both trees and the no-.git tree. `git status --porcelain` after each clone run: empty. gofmt on the three changed Go files: clean.

**Mutants** (ran; runner `mutants/mutants.py`, two fresh clones of the head, reset and `git status` empty before each, umask 022; logs `mutants/log-{a,b}.jsonl`). Sets: `adm` = `go test ./es/admission/ -run 'TestReserved|TestOrdinary|TestEmptyEnvironment|TestCaller|TestDeclared|TestEnvironmentRefusal|TestOperationalRetained|TestRedTeam'`; `root` = `go test . -run 'TestCallerDeclaration|TestLifecycleContract|TestRunbooksAndExamples|TestEnvironmentDeclarationScan'`. Baseline B0: both sets pass.

| ID | Change | Result |
| --- | --- | --- |
| V1, V2, V3 | `VSB_DIR` dropped from the map; dropped from the contract; moved to a prefix | killed (pin, refusal, contract tests; pinned gcc clause; pin) |
| C11-C14 | open-keys paragraph: N1's order; two sentences swapped; scope first; one word dropped | killed (pinned paragraph) |
| D04, D06, D07, G16 | upper-case key; second upper-case key; key ending in U+017F; entry holding `]` | killed (reserved key read) |
| D05, D07e, G11, G12 | escaped underscore in key; escaped U+017F in key; indexed assignment; YAML block list | killed (count) |
| G17, D08 | unquoted list item; Python named escape | killed (item check; decode check) |
| H1-H7 | each scanner branch weakened; walk drops `.docs` | killed (table test; per-root check) |
| L1, L2 | `\x` escape in key; YAML comment after the colon | pass: the comment's stated limits |

Totals: 25 of 25 killed; 2 stated-limit spellings pass as stated.

## CI (CI)

Read through the GitHub connector at 07:22Z-08:03Z; I ran nothing on GitHub. Both check runs are on the PR head, `10a3b58`.

| Check | Run / job | Time (UTC) | Result |
| --- | --- | --- | --- |
| test on macOS | 45957237285 / 140366425109 | 07:24:40 to 07:56:24 | success |
| build, vet and test (Linux) | 45957237250 / 140366424960 | 07:15:44 to 08:02:20 | success |

## Coverage this environment could not give

- No Docker daemon, Nomad, Vault or SPIRE here; CI runs the `es/app` flows (unchanged by this delta).
- No VxWorks cross compiler: `VSB_DIR`'s effect is read from gcc's spec text (re-check 28).
- I did not rerun the writer's 25 mutants or the full suite; my own 27 runs overlap theirs where listed.

## Trial-log row (model evaluation, category R-M, security)

| Date | Category | PR @ head | Scope | Model | Verdict | Findings | Later outcome |
|---|---|---|---|---|---|---|---|
| 2026-11-27 | R-M | ES #74 @ 10a3b58 | narrow re-check (pair) | [model withheld] | ACCEPT | none; R28-1 (VSB_DIR), N28-1 (guard: 22-case table test, (?i) fold power-checked against encoding/json over every rune), N28-2 (paragraph pinned whole) verified; 25/25 mutants killed, 2 stated-limit spellings pass as stated; root + es/admission pass on head and 0e56e23 and in a no-.git tree, 0 failing; 3 obs | paired with the Sonnet row; reports workload-identity/29-pr74-recheck-{opus,sonnet}.md |

## Evidence

`29-pr74-recheck-opus-evidence/`:

- `provenance/`: the four manifests, the recipe hash that ran, the delta diff and digests.
- `tests/`: runner, signal wrapper, summarizer, summaries, vet, exit codes, status, trees, timings, the three `go test -json` logs gzipped.
- `probes/`: the case-fold probe (`fold-main.go.txt`, `fold-go.mod`) and its output.
- `mutants/`: runner, launcher, logs and run outputs.
- `SHA256SUMS`.

STATUS: READY (re-check delivered, verdict ACCEPT; no finding)
