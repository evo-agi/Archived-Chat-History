# Re-check 25 (Opus): ES PR #74 at e0b5c89: BLOCK (one low finding and one docs nit; every claimed fix and the #69 merge resolution hold)

Date: 2026-11-27, about midnight Eastern (05:00Z). Thread: "Opus final check of injection fix". Fresh and read-only: this thread did not write #74, did not audit it before, and did not read or message the paired re-check of the model-evaluation trial (category R-M). Model: [model withheld].

Source labels: "ran" means I ran it in this container on the commit named; "read" means I read the code, document or upstream source and did not run it; "Inference:" and "Guess:" mark the rest.

```text
INDEPENDENT AUDIT REPORT (narrow re-check of a repair, protocol §14)
Repository / Audit target:
  evo-agi/Execution-Substrate PR #74, branch claude/project-thread-ef7st5
  base 0b9278ca74404b46b5e9f0e1701874b52687f5e8 (trunk_dev, #69)
  topic commit e0b5c89214f11b45d7d88a72cad9b0c5f163c5bd, tree cf451cca91dc396bcbb8845213e4c2254e65ce01
  recipe governed-execution.audit-patch-manifest.v2, source SHA-256
    c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (sha256sum -c OK before each run)
  canonical-manifest SHA-256 6fc6c2927af698d2c28cccb334465d6fd735f86b8ace3c12ae440ed3d44446aa, 31 paths,
    textual_diff_sha256 31f0b9b39939dbbca3285c60a8db376c620ec35a1341bde0d5d235d525a312a4
  Scope (writer report 24): git diff 9c06790 978bccb, git diff d0f4fb7 e0b5c89, and the conflict
    resolution in merge d0f4fb7 (#69's PLANS.md move).
Audit posture: read-only. Parent only, no subagents (narrow delta). Nothing pushed, nothing posted on
  GitHub, no Linux box, no live service. Tests, probes and mutants ran as an unprivileged user (ci,
  uid 1500) in clones made from a bundle, never in the provenance clone. Two local branches
  (audit25-head, audit25-base) were created in this container's clone to make the bundle and deleted
  right after; never pushed.
Provenance reproduction: equal to writer report 24's manifest file, byte for byte, twice; closing run
  equal to opening.
Coverage: every line of the two deltas (6 + 4 files); the merge d0f4fb7 (remerge diff, and both sides'
  +/- lines compared with #69 and with the PR on its old base); the reserved-key check and its one
  caller; every caller key declared or sent in this repo; upstream glibc 2.39 and 2.42 intl and locale
  sources, gcc 13.3.0 sources and `go help environment` (Go 1.26.5) against the contract's new
  sentences; red-team 19's probes; the PR body. Uninspected: Docker/Nomad flows (no daemon here; CI is
  the reference), runtime images.
Findings: 1 low (F1, backstop gap against the contract's new Go and gcc sentences), 1 docs nit (N1).
  No medium or higher. 4 observations.
Validation assessment: full suite on head and base as an unprivileged user: same 17 failing names on both, 18 new tests
  all pass, nothing gone or newly skipped. 12 mutants of the
  delta: 11 killed, 1 survives (runbook text, no test asked for). Red-team 19's 8 probes pass at
  e0b5c89; the backstop probe reports reserved=102, admitted when declared=5. The fix proposed for F1
  passes the affected tests. CI on e0b5c89: both required checks green.
Sensitive-material handling: no secrets, keys, tokens, env files, SQLite or TLS/SPIFFE/Vault material
  read into the report or evidence.
Remaining uncertainty and stop conditions: none that blocks the verdict; F1's reach depends on runtime
  images I could not inspect.
Confidence: provenance high / validation high for what runs here / implementation high for the claimed
  fixes and the merge resolution; medium-high for the backstop's completeness (by design it cannot be
  complete; F1 is measured only against the sources the contract itself names).
Effect status: repair, commit, push, PR, merge not performed.
Report delivery: /mnt/project-files/reports/Execution-Substrate/workload-identity/25-pr74-recheck-opus.md
  (SHA-256 in the delivering message), evidence in 25-pr74-recheck-opus-evidence/ (SHA256SUMS inside).
Final verdict: BLOCK
```

Why BLOCK with one low finding: the standing rule is that low findings are fixed in the PR. F1 is five map entries and the same five in the pin (tested below); N1 moves one sentence. Everything the repair claims holds, and the merge resolution is exactly the relocation the writer describes. If the coordinator instead judges F1 as outside the backstop's stated limits, nothing else here blocks; see "Why F1 is in scope" for why I think it is inside them.

## Provenance (ran)

| Step | Result |
| --- | --- |
| Recipe bytes | `sha256sum -c` OK (`c08597e2…a3ca`), on the shared file and on the copy that ran |
| Pushed tip | `git ls-remote` at 04:16Z: `refs/heads/claude/project-thread-ef7st5` and `refs/pull/74/head` = `e0b5c89`, `trunk_dev` = `0b9278c`; again at close (below) |
| Base ancestry | `git merge-base --is-ancestor 0b9278c e0b5c89`: yes |
| Manifest | fresh clone of github.com/evo-agi/Execution-Substrate, branch checked out at the tip, `git status` clean, `git reset --mixed 0b9278c`, upstream `origin/trunk_dev`; two runs, `cmp` identical; file SHA-256 `6fc6c292…46aa`, equal byte for byte to `24-pr74-repair-evidence/manifest-v2-e0b5c89-on-0b9278c.json`; 31 paths |
| Committed blobs | every manifest record equals the blob at `e0b5c89` (SHA-256 and size, 0 differences), every mode `100644`; path set equals `git diff --name-only 0b9278c e0b5c89` |
| Whole-PR diff | `git diff 0b9278c e0b5c89`: 31 files, +1549 / -77, `\| sha256sum` `4f32f7ad…7412` (writer's value) |
| Delta diffs | `git diff 9c06790 978bccb`: 6 files, +125 / -42, `2da5ced3…d4d4`; `git diff d0f4fb7 e0b5c89`: 4 files, +67 / -23, `d80aff5a…7d7f` (both writer's values) |
| Closing run | 04:40Z, same clone, recipe re-verified: two runs identical and equal to the opening manifest; `git ls-remote` unchanged (tip `e0b5c89`, `trunk_dev` `0b9278c`) |

## Nothing changed beyond the stated repair and the stated merge resolution (ran)

Commits since re-check 23's target 9c06790: `6b8bab2`, `978bccb`, merge `d0f4fb7` (parents `978bccb`, `0b9278c`), `e0b5c89`. `0b9278c` is #69 on `a5861b7`.

- **The merge, PR side.** The `+`/`-` lines of `git diff a5861b7 978bccb` (the PR on its old base, just before the merge) and `git diff 0b9278c d0f4fb7` (the PR on its new base, just after) are identical for 29 of the 31 files. The two that differ differ by exactly one moved edit: the PR's three-line edit ("change environment or mount admission (which the shared admission path owns, …, section 5)" in place of "silently tighten the current empty-environment-allowlist contract") left `PLANS.md` and appears in `.docs/standing_rules/execution_admission_and_custody.md`. The PR's other PLANS.md edit (the two current-fact bullets, now at lines 289-290) is unchanged.
- **The merge, trunk side.** The `+`/`-` lines of #69 itself (`git diff a5861b7 0b9278c`) and of `git diff 978bccb d0f4fb7` are identical for 11 of 13 files; the two others differ by the same moved edit, seen from the other side.
- **The remerge diff** (`git show --remerge-diff d0f4fb7`) touches exactly these two files: PLANS.md resolves the conflict by taking #69's removal of the section, and the moved copy (standing rule, line 1033) carries the PR's wording. No other hand edit.
- **The guard holds the resolution.** `caller_declaration_docs_contract_test.go:57-66` refuses "empty-environment-allowlist contract" in five docs, the standing rule among them. Mutant K08 (the moved copy reverted to #69's text) is killed by `TestCallerDeclarationRulesAreInTheLifecycleContract`. A repo-wide `git grep` at `e0b5c89` finds the old wording only in that test's refused list.
- **Therefore** the only changes to the PR's patch since 9c06790 are `git diff 9c06790 978bccb`, `git diff d0f4fb7 e0b5c89` and that one relocation, as writer report 24 says.
- In `es/admission/service.go` the two deltas touch only the reserved-key `var` block (map entries, the `CGO_` prefix, the new `reservedRuntimeEnvSuffixes`), comments, and three lines in `isReservedRuntimeEnvKey` (`service.go:1454-1458`, the suffix loop). `validateInvocationAgainstManifest` is unchanged, and `isReservedRuntimeEnvKey` still has one caller (`service.go:1216`, the caller-key loop), so the wider list judges caller keys only, never the profile's or ES's own keys (read: `git grep` at `e0b5c89`).

## The claimed fixes

| Item | Verdict | Evidence |
| --- | --- | --- |
| R1 (re-check 23 Opus): `TEXTDOMAINDIR`, `TEXTDOMAIN` | Fixed | Both in `reservedRuntimeEnvKeys` (`service.go:301-302`) and in the pin (`caller_declaration_test.go:192-231`). `TEXTDOMAINDIR` is gone from `TestOrdinaryEnvironmentKeysAreNotReserved` (`:381`), and the false "they load no code and change no trust" is gone from that test and from above `redTeam74FamilyKeys`. Both are in the end-to-end refusal table (`TEXTDOMAINDIR`, `textdomain`) and named in the contract's single-keys bullet (`contracts.md:525`) with the reason R1 gave. Mutants K01 (for `LANGUAGE`, same list) and the writer's S3/S4 cover a dropped entry. |
| `LANGUAGE` (coordinator decision) | Fixed, and the reason given is accurate | Reserved (`service.go:303`), pinned, refused end to end (`Language`), out of the ordinary list. The contract sentence (`contracts.md:525`) matches upstream: glibc 2.39 `intl/dcigettext.c:687-691` and 2.42 `:658-662` skip a `LANGUAGE` entry with a `/` only `if (ENABLE_SECURE && IS_PATH_WITH_DIR (single_locale))` (read; 2.42 file SHA-256 equal to re-check 23's copy). The "one Ubuntu build ignored such entries" half also holds for the spellings report 24 did not try: this container's Ubuntu glibc 2.39-0ubuntu8.12 ignored `../../../..<dir>`, `en/../../../..<dir>`, `en_US/../../../..<dir>` and `<dir>` through bash and through `dgettext` alike, while the path the upstream code would build for the second spelling exists (ran, `language-probe/`; Inference: a distribution patch). The docs test pins the reason (mutant K10 killed). |
| `LANG`, `LC_ALL` stay open | Holds | `locale/findlocale.c` (2.42, read): `valid_locale_name` refuses `/../`, a leading `../`, a trailing `/..` and any `/` not at the start, and an absolute name is still joined under the locale directory (`_nl_make_l10nflist` with `_nl_default_locale_path`) unless `LOCPATH` (reserved) is set. With `LANGUAGE` reserved, gettext takes the catalog name from the locale `setlocale` accepted. Pinned in the contract (mutant K06 killed). One readability nit, N1. |
| Go and gcc keys (coordinator decision; re-check 23 Sonnet O2) | The listed keys are reserved as claimed; the new categorical wording is not yet true of its own sources (F1) | Map entries `service.go:281-300`, prefix `CGO_` `:368`, pin and refusal cases match (mutants K03, K04 killed). The contract's Go sentence now says the reserved set holds "the Go toolchain keys that choose which toolchain, compiler or helper command runs, …" and the gcc sentence names "the GNU C compiler's keys that choose the programs it runs, the headers and libraries it builds with, or extra options". Measured against `go help environment` (Go 1.26.5, which report 24 cites) and the gcc 13.3.0 sources, five keys in those categories are open; see F1. `GOOS` and `GOARCH` are pinned as ordinary and the docs test refuses a contract that names them (mutant K07 with `GOFIPS140` killed). |
| R2 (re-check 23, both): `GCONV_PATH` | Fixed | Contract `contracts.md:520` and the comment `service.go:126-133` now name `GCONV_PATH` as the eighth later-sudo entry, "which the glibc list above already holds"; the docs test requires the whole sentence (mutant K09 killed, where re-check 23's R09 survived); the PR body says the same. |
| TLS-skip switches (coordinator; re-check 23 Opus O1) | Fixed | `reservedRuntimeEnvSuffixes = {"INSECURE_SKIP_VERIFY"}` matched on the ASCII-folded, trimmed key (`service.go:376-385`, `:1454-1458`); the key passed the portable-name check first. Probe at the head (ran): `INSECURE_SKIP_VERIFY`, `X_INSECURE_SKIP_VERIFY`, `vault_insecure_skip_verify` reserved; `INSECURE_SKIP_VERIFY_X`, `SKIP_VERIFY` open. Contract bullet `contracts.md:526` and "the exact list" sentence name the suffix list; the docs test reads the suffix list from the AST and requires "ends in `<suffix>`" (mutants K02, K05, K11 killed). |
| Runbook and example | Fixed; text accurate | The reference-workload runbook's step 4 publish request no longer declares `REFERENCE_VAULT_INSECURE_SKIP_VERIFY`; its submit request (`"env"`, runbook line 232-235) sends only `REFERENCE_IDENTITY_URL` and `REFERENCE_SECRET_PATH`, so nothing the runbook does changes. The new Notes bullet is right: the entrypoint builds `urllib.request.build_opener()` with Python's default TLS context unless the switch is `1` (`.examples/runtime_identity_reference/entrypoint:146-153`, read), the default context loads OpenSSL's default paths, which honor `SSL_CERT_FILE`, and ES sets `SSL_CERT_FILE` when the workload-zone trust has a bundle (`es/admission/resolved_execution_plan.go:690-692`, read). The example README says the switch applies only outside ES. Nothing guards the runbook's text (mutant K12 survives; O1). |
| Merge of #69 | Correct | See the section above. |

The PR body (read at 04:30Z) matches the code: it names the suffix, `GCONV_PATH`, `LANGUAGE`, the Go and gcc keys and the #69 resolution.

## Findings

```text
AUDIT FINDING F1
Type / Severity: security risk in the backstop (incomplete against the contract's own new category
  sentences) / low
Current contract: .docs/execution_lifecycle/contracts.md section 5, single-keys bullet (line 525, e0b5c89):
  "the Go toolchain keys that choose which toolchain, compiler or helper command runs, where modules,
  sources and build results come from or go, or how the toolchain builds and fetches (`GOROOT`, …
  and others)" and "the GNU C compiler's keys that choose the programs it runs, the headers and libraries
  it builds with, or extra options (`GCC_EXEC_PREFIX`, `COMPILER_PATH`, `LIBRARY_PATH`, `CPATH`,
  `C_INCLUDE_PATH`, `CPLUS_INCLUDE_PATH`, `OBJC_INCLUDE_PATH`, `GCC_COMPARE_DEBUG`)". Writer report 24:
  "Reserved: the Go keys that choose which toolchain, compiler or helper command runs … (`go help
  environment`, Go 1.26.5)".
Path and line (e0b5c89): es/admission/service.go:84-304 (none of the five keys below in the map, and no
  prefix or suffix covers them); es/admission/caller_declaration_test.go:192-231 (pin)
Evidence (ran unless marked):
  - `go help environment` (Go 1.26.5, upstream/go-help-environment-1.26.5.txt) lists three keys that name
    a program the go command runs and that are open at the head (key probe, key-probes/):
      FC            "The command to use to compile Fortran code."
      PKG_CONFIG    "Path to pkg-config tool."
      GCCGOTOOLDIR  "If set, where to find gccgo tools, such as cgo."
    Their neighbours CC, CXX, AR and GCCGO are reserved. Benign probes with system binaries only:
    `go build` of a cgo package with a `#cgo pkg-config:` directive runs whatever PKG_CONFIG names
    (PKG_CONFIG=/usr/bin/false: "/usr/bin/false: exit status 1"; PKG_CONFIG=/usr/bin/echo:
    "/usr/bin/echo --cflags -- probe-package"), and `go build -x` of a cgo package holding a Fortran file
    runs FC (FC=/usr/bin/false appears as the command). GCCGOTOOLDIR was not run (no gccgo here).
  - gcc 13.3.0 reads two keys in the gcc sentence's categories that are open:
      LPATH  gcc/gcc.cc:4830-4831 (read): "Use LPATH like LIBRARY_PATH (for the CMU build program)",
             applied when not cross-compiling. Ran: `LPATH=<dir> gcc -print-search-dirs` adds <dir> to
             the library search list exactly as LIBRARY_PATH=<dir> does (4 entries each, 0 without).
      OBJCPLUS_INCLUDE_PATH  gcc/incpath.cc:482-484 (read): the Objective-C++ member of the same table as
             C_INCLUDE_PATH, CPLUS_INCLUDE_PATH and OBJC_INCLUDE_PATH. Present in this container's cc1.
    Both are left out of the GCC manual (cppenv.texi:18 comments OBJCPLUS_INCLUDE_PATH out; LPATH is
    not in invoke.texi), so Inference: the writer's list follows the manual, which is complete for what
    it documents. The driver reads no other variable through env.get (gcc.cc: GCC_EXEC_PREFIX,
    COMPILER_PATH, LIBRARY_PATH, LPATH, GCC_COMPARE_DEBUG).
  - Everything else in `go help environment` that the go command reads is reserved or is a build-mode key
    the writer left open on purpose (GOOS, GOARCH, the architecture-level keys GO386…GOWASM, GO111MODULE,
    GOFIPS140, GO_EXTLINK_ENABLED, GOCOVERDIR). So these five are the whole gap within the two sources;
    a further round on these sentences should find nothing new in them.
Impact: a publisher that declares one of these keys (they look like build configuration, the mistake the
  backstop exists for) lets a caller choose a program the go command runs during a cgo build (PKG_CONFIG,
  FC, GCCGOTOOLDIR), or the libraries gcc links and the crt start files it finds there (LPATH), or
  Objective-C++ headers. With a declared caller mount, whose files keep their execute bit (red-team 19
  observation 3), that is the caller's code in the run, the same reach as CC, which the PR reserves.
  Reach today is small: it needs a workload that runs `go build` with cgo, or gcc, and a publisher that
  declares the key; no artifact in the project declares any of them (inventory: the declared keys in this
  repo are APP_MODE, WORKLOAD_VAULT_SECRET_PATH, REFERENCE_IDENTITY_URL, REFERENCE_SECRET_PATH). The
  contract sentence, though, now states the category without "best-known" (978bccb's wording), so a
  reader takes FC and PKG_CONFIG as reserved.
Required correction: reserve FC, PKG_CONFIG, GCCGOTOOLDIR, LPATH and OBJCPLUS_INCLUDE_PATH by name and add
  them to mustBeReservedEnvironmentKeys (and, if wanted, to the refusal table). Tested: that change
  (mutants/fix-check.diff.txt) passes `go test ./es/admission/ -run
  'TestReserved|TestOrdinary|TestEmptyEnvironment|TestCaller|TestDeclared|TestEnvironmentRefusal|TestOperationalRetained'`
  and `go test . -run 'TestCallerDeclaration|TestLifecycleContract'` with the contract unchanged (the
  "and others" parentheses already cover them). The alternative, going back to "the best-known Go
  toolchain keys" and naming the gcc keys as examples, also satisfies the contract, but leaves PKG_CONFIG
  open while CC is closed, which I would not recommend.
Uncertainty: none on the facts above; GCCGOTOOLDIR's effect is from the go help text only.
Patch defect or pre-existing issue: patch defect in e0b5c89 (the categorical wording and the Go and gcc
  lists are new there); the keys themselves were open before the PR too.
```

**Why F1 is in scope.** The project's lesson is that vocabulary guards cannot be complete, so audits should hold them to their stated limits. F1 holds the two sentences only to the sources the change itself names (`go help environment`, which report 24 cites, and the GNU C compiler whose keys the sentence lists), and I enumerated those sources completely so that this is the last item they can yield. Keys outside them (pkg-config's own search keys, clang's keys, `MUSL_LOCPATH`) are observations, not findings.

```text
AUDIT FINDING N1
Type / Severity: test/doc/artifact gap (readability of the contract) / nit
Path and line (e0b5c89): .docs/execution_lifecycle/contracts.md:527
Evidence: the new sentence "`LANG` and `LC_ALL` stay open: … so they select only installed locales." sits
  between "… and `TestReservedEnvironmentKeySetIsPinned` pins it." and "It is a backstop for a publisher's
  mistake, not the boundary", so "It" now follows a sentence about two locale keys instead of the list.
Required correction: move the LANG/LC_ALL sentence after "The boundary is the allowlist in the next rule."
  (no test change: both sentences are pinned as substrings, not by position).
Patch defect or pre-existing issue: patch defect (e0b5c89).
```

## Observations (no correction required by this re-check)

- **O1. Nothing keeps the runbooks from declaring a reserved key.** Mutant K12 (the reference runbook's publish request declares `REFERENCE_VAULT_INSECURE_SKIP_VERIFY` again) survives: no test reads runbook payloads. AGS still signs a declaration that holds a reserved key (red-team 19's open design option), so such a runbook would publish fine and its caller would be refused at submit. Same open item as before; noted so the AGS option is weighed with it. The Archived-Runbooks copy (8d99aa0) still declares the switch; I agree with report 24 that it should be refreshed from `trunk_dev` after the merge.
- **O2. pkg-config's own keys.** `PKG_CONFIG_PATH`, `PKG_CONFIG_LIBDIR` and `PKG_CONFIG_SYSROOT_DIR` choose which `.pc` files supply a cgo build's flags. Go checks pkg-config output against its cgo flag allowlist (`cmd/go/internal/work/exec.go:1807` and `:1823` in Go 1.26.5, read; the probe shows it refusing `--cflags` as a flag), which admits `-I`, `-L` and `-l` with a path (`security.go:48`, `:164-165`), so a caller-chosen `.pc` could point a build at the caller's headers and libraries, as `CPATH` and `LIBRARY_PATH` (reserved) do. They are pkg-config's keys, not in the contract's Go or gcc sentences, so this is the coordinator's call if PKG_CONFIG is reserved.
- **O3. The "how the toolchain builds" clause reads wider than the code.** The Go sentence's last category also describes `GOOS`, `GOARCH`, `GO111MODULE`, `GOFIPS140` and the architecture-level keys, which stay open by design (report 24 gives reasons; `GOOS`/`GOARCH` are pinned as ordinary). The contract now states why `LANG` and `LC_ALL` stay open; a like sentence for these would make the Go sentence exact. Optional.
- **O4. Harness note on the retained-request test.** Run with the default umask 0002 of a new user, `TestOperationalRetainedRequestEnvIsJudgedByTheSignedDeclaration` (and red-team 19's copy) fail with "private replay: unavailable", because ES refuses the group-writable directories the fixture creates; with `umask 022` (the full-suite runs, and CI) both pass. Environment only; recorded so a later auditor does not chase it.

## Validation

All test runs as an unprivileged user `ci` (uid 1500, gid 1600), `umask 022`, `env -i` (no proxy variables), Go 1.26.5 (`GOTOOLCHAIN=local`, `GOPROXY=off` after `go mod download all`, `go.sum` restored to the committed bytes), one clone per tree made from a bundle (trees `cf451cca…` and `b3c61199…` checked). Host packages acl, iproute2, openssh-client, uuid-runtime and the `en_US.UTF-8` locale installed first. Command: `go test -json -count=1 -timeout 60m ./...`, one tree at a time (head 04:21:50Z-04:30:50Z, base 04:30:50Z-04:39:31Z).

| Tree | Top-level pass / skip / fail | Compared |
| --- | --- | --- |
| base `0b9278c` | 1844 / 87 / 17 | |
| head `e0b5c89` | 1862 / 87 / 17 | same 17 failing names (and the same 54 failing names counting subtests); 18 tests only at head, all pass; none only at base; no test changed status |

The 18 tests only at head are the PR's 16 plus `TestReservedFamiliesCoverTheKeysTheRedTeamFoundOpen` and `TestOperationalRetainedRequestEnvIsJudgedByTheSignedDeclaration` (list: `tests/all-top-level-*.txt`); the root package passes in full on the head, including #69's new guards and both caller-declaration docs tests. The 17 failures are environment-only and fail the same way on the base: the 3 `reliablesubmit` old-binary probes, `TestLinuxSetupBootstrapFinishesWithItsSavedSecret` and `TestNomadACLToolRetriesABootstrapThatNeverTookEffect` in `es/app`, and 12 Remote Alpha tests in `scripts` (`tests/failing-top-level-*.txt`). Writer report 24 saw 55 failing as root; Guess: running as root without these host packages fails more fixtures. The names-equal-to-base result is what a delta needs, and it holds.

`gofmt -l` on the three changed Go files: empty. `go vet . ./es/admission/` passes on Linux and with `GOOS=darwin GOARCH=arm64` (ran on the head clone).

**Red-team 19's probes at `e0b5c89`** (ran, `key-probes/probes-at-e0b5c89.txt`): all eight pass, among them the 4,000-request job probe, the 3,000,000-key fuzz and the retained-request probe; the backstop probe reports `keys probed=107 reserved=102 admitted when declared=5`, the five being `LANG LC_ALL GOMEMLIMIT GOGC GOMAXPROCS` (re-check 23 saw 100 and 7 at 9c06790; `LANGUAGE` and `TEXTDOMAINDIR` moved to reserved).

**Mutants of the delta** (ran on a clone of the head, targeted `-run` sets, baseline green first; `mutants/`):

| ID | Change | Result |
| --- | --- | --- |
| K01 | `LANGUAGE` dropped from the map | killed: `TestReservedEnvironmentKeySetIsPinned`, `TestReservedEnvironmentKeysAreRefusedEvenWhenTheArtifactDeclaresThem` |
| K02 | suffix matched as a prefix | killed: `TestOrdinaryEnvironmentKeysAreNotReserved`, the refusal test |
| K03 | prefix `CGO_` dropped | killed: the pin, the refusal test |
| K04 | `GOROOT` dropped (code only) | killed: the pin, the refusal test |
| K05 | extra suffix `SKIP_VERIFY` in code (over-reservation) | killed: `TestOrdinaryEnvironmentKeysAreNotReserved`, the pin |
| K06 | contract drops the `LANG`/`LC_ALL` sentence | killed: `TestCallerDeclarationRulesAreInTheLifecycleContract` |
| K07 | contract names `GOFIPS140` as reserved | killed: `TestLifecycleContractNamesOnlyReservedKeysTheCodeReserves` |
| K08 | standing rule's moved copy reverted to #69's text (merge resolution undone) | killed: `TestCallerDeclarationRulesAreInTheLifecycleContract` |
| K09 | contract drops `GCONV_PATH` from the later-sudo sentence | killed: `TestCallerDeclarationRulesAreInTheLifecycleContract` |
| K10 | contract drops the `LANGUAGE` reason | killed: `TestCallerDeclarationRulesAreInTheLifecycleContract` |
| K11 | contract stops saying "ends in `INSECURE_SKIP_VERIFY`" | killed: both docs tests |
| K12 | runbook publish request declares `REFERENCE_VAULT_INSECURE_SKIP_VERIFY` again | survived: no test reads runbook payloads (O1; not asked for) |

**Fix check for F1** (ran): the five entries in the map and the pin, `gofmt`-clean; the targeted `es/admission` set (including `TestOperationalRetained`) and the root docs tests pass (`mutants/fix-check-output.txt`). Workspace restored to the head afterwards (`git status` empty).

## CI

Read through the GitHub connector at 04:58Z; I ran nothing on GitHub. Both required checks on the audited head are green:

| Check | Run / job | Head SHA | Result |
| --- | --- | --- | --- |
| Linux, "build, vet and test" | run 45938193870, job 140306246226 | `e0b5c89214f11b45d7d88a72cad9b0c5f163c5bd` (run details) | success, 04:08:57Z to 04:55:51Z |
| macOS, "test on macOS" | run 45938193837, job 140306302507 | listed as a check run of the PR's head `e0b5c89` | success, 04:09:08Z to 04:38:47Z |

Linux log lines (quoted): `all 17 listed tests still fail on this host, each in a run of its own and in the run of its package` (04:54:51Z) and `tests as root passed: 9 of execution-substrate/scripts` (04:55:47Z). macOS: `all 26 listed tests still fail on this host, each in a run of its own and in the run of its package` (04:38:38Z). I read the tail of each log only; the job conclusions are the gate's verdict (Inference from the gate's rule that an unlisted failure fails the job, as in re-check 23a).

## Coverage this environment could not give

- No Docker daemon, Nomad, Vault or SPIRE: the es/app Docker/Nomad flows skip here; CI runs them.
- No runtime image was inspected, so whether any granted image runs `go build` with cgo or gcc (F1's reach) is Unknown.
- `GCCGOTOOLDIR` was not exercised (no gccgo); its effect is from `go help environment`.
- Nothing ran on macOS here; CI's macOS job is the reference.

## Evidence

`25-pr74-recheck-opus-evidence/`: `provenance/` (commands, opening and closing manifests), `merge-and-delta-checks.txt` and `pm.py.txt` (the per-file +/- comparison of the merge), `key-probes/` (the key probe test, red-team 19's probes at the head, the gcc LPATH and Go PKG_CONFIG/FC probes with their scripts, and the umask 0002 run of O4), `language-probe/` (script, catalog writer, output), `upstream/` (glibc 2.39 and 2.42, gcc 13.3.0 sources, `go help environment`; `upstream-SHA256.txt`), `mutants/` (runner, definitions, log, fix-check diff and output), `tests/` (runner, summarizer, failing and all-test lists for both trees, timeline), and `SHA256SUMS`.
