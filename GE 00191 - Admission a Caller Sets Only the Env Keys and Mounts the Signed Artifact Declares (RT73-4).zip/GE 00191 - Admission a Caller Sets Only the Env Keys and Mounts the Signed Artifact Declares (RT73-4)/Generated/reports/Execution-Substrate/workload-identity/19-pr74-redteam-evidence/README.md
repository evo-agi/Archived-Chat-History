# Evidence for 19-pr74-redteam

Red-team of evo-agi/Execution-Substrate PR #74 at head `f8bc3df20e1e3c17751edd1751010644733991ab` (first half of the pass at the writer's commit `626c3cd7c163948ee7939f2f57ea7f271a79ae6f`, which the head merges with `trunk_dev` at `fbfd100`). Read-only: nothing here was pushed or posted. Everything ran in a private container with Go 1.26.5 (the toolchain `go.mod` names), no Docker daemon, no Nomad, no Vault, no SPIRE.

## Layout

| Folder | What it holds |
| --- | --- |
| `probes/` | The four probe files, named for where they go in the repository. |
| `regressions/` | The RT74-2 probe under a permanent test name, ready to copy into `es/admission/`. Ran: passes at `f8bc3df`, fails on MN. |
| `mutants/` | One diff per mutant. Each applies with `git apply` at `626c3cd` and at `f8bc3df` (the files they touch are byte-identical at both). |
| `outputs/` | What each run printed. `at-626c3cd-*` and `at-f8bc3df-*` name the commit. Lines with "TLS handshake error" from the test servers were filtered out; nothing else was. |
| `SHA256SUMS` | Checksums of every file in this folder. |

## Repeat the probes on the head

```bash
git fetch origin pull/74/head && git worktree add --detach /tmp/rt74 f8bc3df20e1e3c17751edd1751010644733991ab
cd /tmp/rt74
cp <evidence>/probes/es_admission_zz_redteam74_probe_test.go          es/admission/zz_redteam74_probe_test.go
cp <evidence>/probes/es_admission_zz_redteam74_backstop_probe_test.go es/admission/zz_redteam74_backstop_probe_test.go
cp <evidence>/probes/es_admission_zz_redteam74_retained_probe_test.go es/admission/zz_redteam74_retained_probe_test.go
cp <evidence>/probes/es_runtimehelper_zz_redteam74_argv_probe_test.go es/runtimehelper/zz_redteam74_argv_probe_test.go
go test ./es/admission/ -run 'TestRedTeam74' -count=1 -v      # about 25 seconds; add -short for about 3 seconds
go test ./es/runtimehelper/ -run 'TestRedTeam74' -count=1 -v
```

The backstop probe needs the helpers in `zz_redteam74_probe_test.go`. The retained probe and the argv probe stand alone. All four use only the repository's own test fixtures. None starts a container or opens a connection outside the test process.

| Test | What it asks |
| --- | --- |
| `TestRedTeam74JobCarriesOnlyWhatTheSignedArtifactDeclares` | 4,000 random requests (seed 74). Does anything reach the Nomad job that the signed declaration does not cover? Do `:prepare` and `:submit` agree? Does a refused request ever reach Nomad? Is caller argv exactly the tail after `--`? |
| `TestRedTeam74FuzzEnvironmentKeysAgainstTheOracle` | 3,000,000 keys (seed 7400) from an adversarial alphabet against 7 declared sets. Does the rule check ever admit a key that an independent reading of the rules refuses? |
| `TestRedTeam74RequestBodySpellings` | 18 JSON spellings of the request body (duplicate members, field-name case, look-alike letters, escapes). |
| `TestRedTeam74SealedDeclarationCannotBeWidenedInTheRegistry` | A registry that serves a doctored evidence record: 7 widened records, 1 record with an unknown extra field, and 3 spellings that decode to the signed value. |
| `TestRedTeam74ArtifactSignedBeforeTheFieldAdmitsNothing` | A record with no `mount_targets` field and an empty environment list. |
| `TestRedTeam74BackstopCoverageOfTheFamiliesTheContractNames` | For 107 key names: is the key reserved, and if not, does it reach the job with the caller's value once a package declares it? Logs a table. Runs no workload and carries no payload. (RT74-1) |
| `TestRedTeam74RetainedOriginalEnvIsJudgedByTheSignedDeclaration` | Does the retained-request path of reliable submit refuse a retained request whose env key the retained evidence does not declare? (RT74-2) |
| `TestRedTeam74CallerArgvCannotChangeSupervisorOptions` | 10 caller argv lists that look like supervisor options. |

## Repeat a mutant

```bash
cd /tmp/rt74 && git apply <evidence>/mutants/MN-retained-request-path-skips-the-rules.diff
go test ./es/admission/ -run 'TestRedTeam74RetainedOriginalEnvIsJudgedByTheSignedDeclaration' -count=1 -v   # fails on the mutant
rm es/admission/zz_redteam74_*_test.go && go test ./es/admission/ -count=1 -timeout 25m                     # the repository's own tests, about 6 minutes
git checkout -- .
```

The targeted set used for the PR's own tests on each mutant was:

```bash
go test ./es/admission/ -run 'Environment|Mount|CallerCannot|Declaration|Reserved|Operational|Manifest' -count=1 -timeout 25m
go test ./internal/contracts/evidence/v1/ ./ags/publish/ -count=1
```

## Mutants

| ID | Edit | Killed by my probes | Killed by the repository's tests |
| --- | --- | --- | --- |
| MA | An empty declared env list admits every key (the old rule) | yes | not run by me. Writer report 15 reports the same edit as its M1, killed. |
| MB | No check of mount targets against the declaration | yes | not run by me. Writer report 15: M2, killed. |
| MC | Reserved match is case-sensitive | yes | not run by me. Writer report 15: M5, killed. |
| MD | No portable-name rule | yes | not run by me. Writer report 15: M3, killed. |
| MF | A declared mount target matches as a prefix | yes | yes: `TestCallerMountNeedsATargetTheArtifactDeclares` |
| MG | A declared key skips the reserved check | yes | yes: `TestReservedEnvironmentKeysAreRefusedEvenWhenTheArtifactDeclaresThem`, `TestCallerCannotPutItsOwnCodeIntoAGrantedNetworkRun` |
| MH | The declared env match ignores letter case | yes | yes: `TestDeclaredEnvironmentKeyIsTheOnlyCallerKeyAdmitted` |
| MS | The declared mount match ignores letter case | not run | yes: `TestCallerMountNeedsATargetTheArtifactDeclares` |
| MP | AGS does not sign `mount_targets` | not run | yes: `TestPublishSignsTheDeclaredMountTargets` |
| MQ | The seal's canonical form drops `mount_targets` | not run | yes: `TestMountTargetsAreSignedAsATrimmedSortedSet`, `TestPublishSignsTheDeclaredMountTargets` (the `es/admission` set alone stayed green) |
| MN | The retained-request path returns true in place of running the rule check | yes: the retained probe | **no**: the targeted set and the whole `./es/admission` package pass on it (`outputs/at-f8bc3df-MN-full-es-admission.txt`). This is RT74-2. |

Two mutants carried names from an earlier draft of the list while they ran, and their files were renamed here to say what the edit is: MH (was "declaration-not-trimmed-but-caller-key-trimmed") and MS (was "mount-declaration-untrimmed-entries-match-subtree"). The diffs are the authority for what each mutant changes.

Runs at `626c3cd`: MA, MB, MC, MD, MF, MG, MH, MS, MP, MQ and the targeted set on MN. Runs at `f8bc3df`: every probe, the PR's nine tests by name, the five packages on a clean tree, and MN (retained probe, regression test, whole `./es/admission`).

## What is not here

A demonstration of caller code running inside a real interpreter through an unreserved key. I started one and the assistant's safety filter stopped it. I deleted the partial file and did not write it again in another form. RT74-1 therefore rests on ES's decision per key (ran) and on each program's public documentation (not run).
