# Audit 21: ES PR #74, caller declarations (RT73-4 option c): BLOCK (two low docs findings; the code holds)

Date: 2026-11-26, about 9:50 PM Eastern (02:50Z on 11-27). Auditor: the "Audit the caller injection fix" thread (fresh: this thread has not audited #74 or written any part of it). Correctness audit; a separate red-team runs in parallel.

```text
INDEPENDENT AUDIT REPORT
Repository / Audit target:
  evo-agi/Execution-Substrate PR #74, branch claude/project-thread-ef7st5
  Final target (the verdict covers this): base fbfd100946d2cb8f25232bac182b94fb299c66da (trunk_dev, #72 merged),
    topic commit f8bc3df20e1e3c17751edd1751010644733991ab (merge of 626c3cd and fbfd100),
    tree 7e9fb159ca289962dfec392f384c83696a3ca362
    canonical-manifest SHA-256 47d666410e7085d1062302546af303fa5c6d728dbdbdf5d5e42f225409be68e3 (28 paths)
  Also checked: trunk_dev moved to a5861b7 (#68) at the end of the audit. Trial merge e4b55a4 of f8bc3df into
    a5861b7 (tree c56692963336addfc75724a5a8b6ced1770da9ac) is clean, the patch's +/- lines are identical, and
    the full suite shows no new failure. Not a provenance target: the writer has not pushed that merge yet.
  Writer's reported target (also audited): base 39e19defb0ea6c0bda30a14f88452b24f9bd9cdf, commit
    626c3cd7c163948ee7939f2f57ea7f271a79ae6f, tree 191c7be29464a6624b2fedd34897847c1f3f4616,
    canonical-manifest SHA-256 e8df9de80c9f6ce2c2897663337d6bd88bb17f5f1a282c10837567329d849f8b (28 paths)
  Recipe: governed-execution.audit-patch-manifest.v2, source SHA-256
    c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (verified before each run)
Audit posture: read-only. Parent only, no subagents. Nothing pushed, nothing posted on GitHub. Tests, probes
  and mutants ran in separate clones (an unprivileged user's own checkouts and scratch copies), never in the
  provenance clones.
Provenance reproduction: both targets reproduced twice, byte-identical; opening = closing on both; no
  mode-bit differences. Details under "Provenance".
Coverage: all 28 changed paths read; plus every unchanged caller of the changed functions (prepareAdmission,
  prepareArtifactFromDiscovery, validateRuntimeMounts, the operational handoff checks, the job env merge, the
  evidence seal and decoders), every ES caller in the repo's examples, runbooks and scripts, and the
  Maintenance Agent (d60e0d2), Infrastructure Manager (9623f5c), Coordinator (aa8104f), Bridge-Core (4580426)
  and Archived-Runbooks (6dbe5d0) trees. The cited upstream sources (glibc 2.42 unsecvars.h, sudo 1.9.16p2
  env.c, sudo main env.c) were fetched and compared. Uninspected: live Docker/Nomad behavior (container has
  neither; CI is the reference), the red-team surface.
Findings: 2 low patch defects (both docs or comments), no medium or higher. 5 observations.
Validation assessment: full suite re-run on base, 626c3cd and the merged head as an unprivileged user: no new
  failure, 16 new tests pass, nothing newly skipped; the same on the newer trunk a5861b7 (layout guard
  included). 20 mutants: 19 killed, 1 equivalent. CI on f8bc3df: Linux and macOS green; es/app mount and
  bridge-network tests ran there (no es/app self-skips).
Sensitive-material handling: no secrets, keys, tokens, env files, SQLite or TLS/SPIFFE/Vault material read
  into the report or evidence.
Remaining uncertainty and stop conditions: the Docker/Nomad tests run only in CI, and the native
  installed-source mount test runs only on the box (see "CI"). The branch is behind trunk_dev a5861b7, so the
  writer must merge it again (required up-to-date check) and CI must rerun. The name `mount_targets` still
  needs David's naming agreement (procedures.md, Naming) before merge.
Confidence: provenance high / validation high / implementation high.
Effect status: repair, commit, push, PR, merge not performed.
Report delivery: /mnt/project-files/reports/Execution-Substrate/workload-identity/21-pr74-audit.md
  (SHA-256 in the delivering message), evidence in 21-pr74-audit-evidence/ (SHA256SUMS inside).
Final verdict: BLOCK
```

Why BLOCK with only low findings: David's standing rule is that low findings are fixed in the PR. Both are wording fixes in two docs and two code comments, plus one phrase in a docs test. A narrow delta re-check is enough afterwards; nothing in the admission logic needs to change.

## Provenance

| Step | 626c3cd on 39e19de (writer's target) | f8bc3df on fbfd100 (current head) |
| --- | --- | --- |
| Recipe bytes | `sha256sum -c` OK | `sha256sum -c` OK |
| Pushed tip | equal at 01:19Z; the writer pushed the merge f8bc3df at about 01:25Z | equal at 01:48Z and again at close |
| Tree / diff | tree 191c7be2; `git diff \| sha256sum` 523ff52c... (writer's value) | tree 7e9fb159, equal to my own `git merge-tree` of fbfd100 and 626c3cd; diff f3a44704... |
| Two runs | identical | identical |
| Manifest | e8df9de8..., 28 paths. Every record equals the committed blob of 626c3cd (sha256 and size, 0 differences); path set equals `git diff --name-only` | 47d66641..., the same 28 paths; records differ only for the three files #72 also changed |
| Closing run | equal to opening | equal to opening |

The writer's report 15 gives hashes and a path summary but no canonical manifest (operating protocol §11, provenance §5.2 step 8), so there was nothing to compare byte for byte; the committed blobs bind the bytes instead (observation O4). The `+`/`-` lines of `git diff 39e19de 626c3cd` and `git diff fbfd100 f8bc3df` are identical: the merge changed context only, so every reading of 626c3cd applies to f8bc3df.

## What holds (repo-validated at f8bc3df unless labeled)

- **The signed runtime interface is the only source.** `validateInvocationAgainstManifest` (`es/admission/service.go:1002`) admits a caller env key only if it passes the existing Nomad text check, is a portable name (`isPortableEnvironmentKey`, `:1074`), is not reserved (`:1256`, ASCII fold at `:1275`) and is in the declared list. The old `if len(allowedEnv) > 0` guard is gone, so an empty or absent list admits nothing. Mounts: after the unchanged shape and overlap checks, each `target_path` must be an exact member of the declared `mount_targets` (`:1041`). No prefix or subtree match.
- **Every admitting path runs it.** It sits in `prepareArtifactFromDiscovery` (`:742`), which `prepareAdmission` (`:591`) runs for `:prepare` and `:submit`; the reliable-submit replay builds a request and goes through Submit; the operational handoff calls it directly (`reliable_submit_operational_admission.go:394`). Mount artifacts use `prepareArtifactFromEvidenceRecord` for their own evidence only (`mounts.go:271`), never as the invocation's manifest.
- **Before any effect.** In `prepareAdmission` the check follows evidence verification and runtime trust and precedes the workload-zone Vault read, policy payload read, mount resolution, staging and Nomad. The admission tests assert no payload read, no mount read, empty staging and results roots and no Nomad call; the es/app test removes the mount artifact's evidence blob, so a read would turn the 400 into a 503.
- **No other request field reaches the task environment.** The job env is caller env, then profile env, then ES keys (`resolved_execution_plan.go:675`); annotations select a profile only and do not reach job or task `Meta` (`submit.go:169-225`).
- **The seal covers the new field.** `Verify` hashes the canonical form computed from the parsed struct (`internal/contracts/evidence/v1/record.go:65`), and the canonical runtime now carries `mount_targets` as a trimmed, sorted list (`execution_claims.go:65`). ES trims declared entries the same way (`declaredStringSet`), so what ES enforces is what was signed. Mutant N12 (canonical form drops the field) is killed.
- **Old evidence verifies unchanged.** `omitempty` on both the claim and its canonical form; `normalizeStringSet` returns an empty slice for an empty list, which `omitempty` drops. Probe P1 rebuilt the test record on base 39e19de: its canonical bytes equal the golden constant in `mount_targets_test.go` (976 bytes).
- **No silent widening on rollback or mixed versions.** Every evidence decoder in ES is strict (`decodeJSON`, `service.go:1198`; `decodeOperationalEvidence`, `reliable_submit_operational_admission.go:343`). Probe P2 shows base's strict decoder refuses a record carrying `mount_targets` (`json: unknown field "mount_targets"`), so an older ES refuses such an artifact instead of ignoring the field. An older AGS refuses a publish request with the field (`ags/publish/service.go:439`, strict). ES is the only consumer of the evidence in the repo.
- **Strictly narrower.** No request base refused is admitted now: the old reserved keys stay reserved (`traceparent` now through the fold), whitespace-padded keys that base trimmed before the reserved check now fail the name rule first, and a mount at any target needs a declaration it did not need before.
- **The reserved set matches its cited sources.** It holds every non-`LD_` key of glibc 2.42 `unsecvars.h` exactly, and covers every Linux entry of sudo's `initial_badenv_table` in both 1.9.16p2 and current main (fetched copies and hashes in the evidence). Only the attribution is off (A1).
- **Callers are unaffected.** Nothing in the repo or the other repos sends env to an artifact with an empty list or sends mounts: `.examples/execution_loop/*` (static script declares and sends `APP_MODE`; Vault example declares `WORKLOAD_VAULT_SECRET_PATH`; normal shell declares none and sends none), `.examples/control_plane_static_script/run.sh`, both runbook copies (ES and Archived-Runbooks: the reference workload declares three keys and sends two of them), `scripts/60_execute_loop.sh` and `40_submit.sh` (no mounts; env from the example), the hardening scripts (publish only). MA, IM, Coordinator and Bridge-Core contain no ES invocation.
- **Contract and docs.** Section 5 states every rule the code enforces, including the refusal point, ordering, the trimming rule and that a declared target trusts any governed artifact. Shared-kernel, system-overview, PLANS.md, README, design, implementation and reliable-submit docs follow. Old-wording phrases are kept out by `TestCallerDeclarationRulesAreInTheLifecycleContract`; the contract cannot name a key the code does not reserve (`TestLifecycleContractNamesOnlyReservedKeysTheCodeReserves`, mutant N19 killed). One missed copy: A2.
- **Existing tests were not weakened.** The 7 es/admission and 7 es/app test edits only add declared mount targets; no assertion was removed. `TestSubmitRejectsOverlappingMountTargets` declares both targets, so it still reaches the overlap.

## Findings

```text
AUDIT FINDING A1
Type / Severity: test/doc/artifact gap (wrong source attribution in the contract and code comments) / low
Current contract: .docs/execution_lifecycle/contracts.md section 5
Path and line (f8bc3df): .docs/execution_lifecycle/contracts.md:520; es/admission/service.go:125-128, :187-188, :193-194
Evidence: The contract says sudo 1.9.16p2's initial_badenv_table, "and _JAVA_OPTIONS and CLASSPATH, which later
  sudo adds", and that "Its wildcard entries become the prefixes LD_, _RLD, KRB5_CONFIG and GIT_ (wider than sudo's
  GIT_CONFIG_*...)". The code comment over the block that holds NODE_OPTIONS and NODE_PATH says the same, and the
  prefix comment lists "sudo's wildcard entries LD_*, _RLD*, KRB5_CONFIG* and GIT_CONFIG_*".
  sudo 1.9.16p2's plugins/sudoers/env.c (fetched from the SUDO_1_9_16p2 tag, SHA-256 64d72a55...) has no
  NODE_OPTIONS, NODE_PATH, GIT_SSH_COMMAND, GIT_CONFIG_* or PYTHONSTARTUP entry. Current sudo main (fetched
  2026-11-27 01:5xZ, SHA-256 e5145d71...) adds _JAVA_OPTIONS, CLASSPATH, PYTHONSTARTUP, NODE_OPTIONS, NODE_PATH,
  GIT_SSH_COMMAND and GIT_CONFIG_*. Writer report 15 and the PR body repeat the 1.9.16p2 attribution.
Impact: none on behavior: the reserved set covers every Linux entry of both versions. A reader who checks the
  cited version finds entries that are not there, in the section that is the contract for this boundary.
Required correction: cite the entries later sudo adds as such (all seven, not only _JAVA_OPTIONS and CLASSPATH),
  in contracts.md section 5 and both service.go comments; keep the PR body and report in step. Name a sudo commit
  or release for "later sudo" if one is wanted; main moves.
Uncertainty: which sudo release first shipped the seven additions was not determined (the GitHub API was not
  reachable from here); the fix does not depend on it.
Patch defect or pre-existing issue: patch defect.
```

```text
AUDIT FINDING A2
Type / Severity: test/doc/artifact gap (stale sentence in a standing rule the PR edits) / low
Current contract: .docs/standing_rules/execution_admission_and_custody.md, reliable-submit foundation invariant
Path and line (f8bc3df): .docs/standing_rules/execution_admission_and_custody.md:138-141
Evidence: "Caller, profile and platform environment precedence, empty allowlist behavior, policy-fetched payload
  reuse and both implicit default and explicit control-plane-normal-shell/v1 profile behavior remain in force."
  The PR rewrote the same sentence in contracts.md (:1297-1300, now "Environment and mount admission (section 5)
  and caller/profile/platform precedence are those of the shared admission path; the foundation adds no rule of
  its own") and edited this file ten lines above (:124-129), but left this copy. The docs test's forbidden
  phrases ("empty environment-allowlist behavior", "Empty environment allowlist meaning", ...) all contain
  "environment", so "empty allowlist behavior" passes it; the full root package is green at f8bc3df.
Impact: a standing rule still says the empty-allowlist behavior "remains in force", which reads as the behavior
  this PR removes.
Required correction: reword as contracts.md:1297-1300 does, and add a phrase that matches this wording (for
  example "empty allowlist behavior") to the forbidden list in caller_declaration_docs_contract_test.go.
Patch defect or pre-existing issue: patch defect (a doc the PR's own rule change made stale).
```

## Observations (no correction required by this audit)

- **O1. Reserved list: same-class keys that are missing.** The contract says the list is a backstop and cannot be complete, and this audit judges it as such: each key below matters only if a publisher declares it. Two groups fall in classes the PR already chose, so they are cheap to add in the same repair round:
  - `XDG_CONFIG_HOME` and `XDG_CONFIG_DIRS`, for the reason the contract gives for `HOME`: Git reads `$XDG_CONFIG_HOME/git/config`, whose `core.fsmonitor`, `core.pager` and `core.sshCommand` run commands; many other programs read their config there.
  - `OPENSSL_CONF`, `OPENSSL_MODULES` and `OPENSSL_ENGINES`, the same class as `LD_PRELOAD`: an OpenSSL config can load an engine or provider shared object into any process that initializes OpenSSL, including Python's `ssl` module.
  Outside the named classes, for the record only: `LUA_INIT`, `PHPRC`/`PHP_INI_SCAN_DIR`, `DOTNET_STARTUP_HOOKS`, `GOFLAGS`, `LESSOPEN`, `BUNDLE_GEMFILE`, `npm_config_*`. Inference, not probed: each runs or loads code in the program that reads it.
- **O2. Operational handoff classifies a tightened rule as integrity.** `qualifyOperationalRetained` returns `OperationalIntegrity` when `operationalEvidenceMatchesOriginal` fails (`reliable_submit_operational_admission.go:440`), and that check includes `validateInvocationAgainstManifest` (`:394`); the decoder of a retained handoff refuses the same way (`reliable_submit_operational_format.go:189`). An original stored before this PR that sent env to an empty-list artifact would read as corruption rather than as a refusal under the current rule. Nothing is affected today: the private store is runtime-unwired (PLANS.md:1496-1510). Pre-existing coupling that this PR is the first to exercise. Recommendation for the coordinator: carry it into the reliable-submit wiring brief with a test, since that is when retained originals start to exist.
- **O3. The name `mount_targets` needs David's agreement before merge** (procedures.md, "Naming", David 2026-11-23 21:01Z). The writer flagged it. A rename changes product bytes (three structs, docs, tests) and needs a delta check.
- **O4. Writer report 15 carries no canonical v2 manifest.** Provenance was reproduced independently and bound to the committed blobs, so no verdict depends on it; the replacement report after repair should include the manifest of its final head.
- **O5. `invocation.argv` stays caller-chosen**, as the contract now says plainly (section 5, last request rule). An artifact whose entrypoint runs its arguments still lets any admitted caller choose what runs with the artifact's network access. This is the writer's report-only uncertainty; bounding argv is a separate decision.

## Validation

All runs as an unprivileged user `ci` (uid 1500, gid 1600), `umask 022`, `env -i`, Go 1.26.5 (`GOTOOLCHAIN=local`, `GOPROXY=off` after `go mod download`), HUP/INT/QUIT/TERM reset, each tree in its own checkout cloned from a bundle. Commands: `go test -json -count=1 -timeout 60m ./...` per tree, one tree at a time.

| Tree | Top-level pass / skip / fail | Compared with the previous row |
| --- | --- | --- |
| base 39e19de | 1838 / 87 / 14 | |
| 626c3cd | 1854 / 87 / 14 | same 14 failing names; 16 new tests, all pass; nothing newly skipped or gone |
| f8bc3df tree (local merge commit bd8acd7, tree 7e9fb159) | 1856 / 87 / 14 | same 14 failing names; the 2 extra are #72's tests |
| new trunk a5861b7 (#68) | 1843 / 87 / 14 | same 14 failing names as the first base |
| f8bc3df merged into a5861b7 (trial e4b55a4, tree c5669296) | 1859 / 87 / 14 | same 14 failing names; exactly the 16 new tests added, all pass; nothing newly skipped |

The 14 failures are environment-only and identical on all three trees: 3 old-binary probes in `es/admission/internal/reliablesubmit`, 2 in `es/app` (`TestLinuxSetupBootstrapFinishesWithItsSavedSecret`, `TestNomadACLToolRetriesABootstrapThatNeverTookEffect`), 9 Remote Alpha TLS/recovery/upgrade tests in `scripts`. Lists: `tests/failing-top-level-*.txt`. 55 es/app tests skip in the container on every tree (Docker and Nomad), including the three mount flows the PR edited and `TestSubmitFlowUsesBridgeNetworkWhenNetworkAccessEnabled`; CI runs them.

For the a5861b7 pair, the first run used git worktrees of a root-owned clone, so seven root-package tests that list tracked files (`git ls-files`, including #68's `TestServiceLayout`) failed on both trees with exit 128. I re-ran the root package in `ci`-owned clones: 184/0 on a5861b7, 186/0 on the merge, `TestServiceLayout` passing. The table combines that rerun with the full run of every other package (same tree hashes).

The writer reported 14 es/app and 38 scripts failures; they ran as root, which explains the difference (root-refusing fixtures). Their names-equal-to-base conclusion agrees with mine.

**Probes** (`probes/zz_audit_probe_test.go.txt`, run on a scratch copy of base 39e19de):
- P1 `TestAuditProbeGoldenEqualsBaseCanonical`: base canonical bytes equal the PR's golden constant. PASS.
- P2 `TestAuditProbeBaseRefusesRecordWithMountTargets`: base's strict decoding refuses a record with `mount_targets`. PASS.

**Mutants** (on the merged head; definitions and logs in `mutants/`): staged, the pinning tests with `-failfast` first, the whole package for anything that survives.

| ID | Change | Result |
| --- | --- | --- |
| N01 | declared entries not trimmed | killed: `TestDeclaredEnvironmentKeyIsTheOnlyCallerKeyAdmitted` |
| N02 | env keys checked in map order | killed: `TestEnvironmentRefusalNamesTheFirstKeyInOrder` (first version did not compile; rerun with the import kept) |
| N03 | digit allowed first | killed: `TestCallerEnvironmentKeyMustBeAPortableName/1ABC` |
| N04 | empty key allowed | killed: `TestCallerEnvironmentKeyMustBeAPortableName/#00` |
| N05 | prefixes matched without the fold | killed: `TestReservedEnvironmentKeysAreRefusedEvenWhenTheArtifactDeclaresThem` |
| N06 | mount matched by prefix (subtree) | killed: `TestCallerMountNeedsATargetTheArtifactDeclares/declared_target_only` |
| N07 | mount check only when the list is non-empty | killed: `.../no_declaration_admits_no_mount` |
| N08 | `manifestFromEvidence` drops `MountTargets` | killed: `.../declared_target_only` |
| N09 | only the first mount checked | killed: `.../declared_target_only` |
| N10 | a declared key skips the reserved check | killed: `TestReservedEnvironmentKeysAreRefusedEvenWhenTheArtifactDeclaresThem/LD_PRELOAD` |
| N11 | non-ASCII bytes allowed in names | killed: `TestCallerEnvironmentKeyMustBeAPortableName/ÄPP_MODE` |
| N12 | canonical form drops `mount_targets` (seal would not cover it) | killed: `TestMountTargetsAreSignedAsATrimmedSortedSet` |
| N13 | canonical `mount_targets` without `omitempty` | killed: `TestRecordWithoutMountTargetsKeepsItsCanonicalBytes` |
| N14 | canonical list not normalized | killed: `TestMountTargetsAreSignedAsATrimmedSortedSet` |
| N15 | AGS does not copy `MountTargets` into evidence | killed: `TestPublishSignsTheDeclaredMountTargets` |
| N16 | AGS manifest field without `omitempty` | killed: `TestPublishWithoutMountTargetsWritesTheSameShapeAsBefore` |
| N17 | evidence claim field without `omitempty` | killed: `TestRecordWithoutMountTargetsKeepsItsCanonicalBytes` |
| N18 | ES `Manifest` field without `omitempty` | survived the whole `es/admission` package: equivalent. ES never encodes its `Manifest` (built only by `manifestFromEvidence`, read only in `validateInvocationAgainstManifest` and `resolved_execution_plan.go:453`) |
| N19 | contract names `XDG_CONFIG_HOME` as reserved | killed: `TestLifecycleContractNamesOnlyReservedKeysTheCodeReserves` |
| N20 | `SSLKEYLOGFILE` dropped from the set | killed: `TestReservedEnvironmentKeySetIsPinned` |

The writer's six mutants (M1 to M6) were not rerun; N07/N08 and N05 cover M2 and M5 from other angles.

## CI

Both required checks are green on f8bc3df (fetched through the GitHub connector; summary and the Linux log in `ci/`):

- **Linux, "build, vet and test"**: run 45922496699, job 140256296965, success at 02:21:01Z (9:21 PM Eastern). `go build`, `go vet` (Linux and darwin/arm64), the gate self-test, then the test gate (01:30:09 to 02:02:32Z): "test gate passed: 49 packages ... 14 tests skipped themselves, all of them listed". The 14 self-skips are in `scripts` (9), `reliablesubmit` (2) and `es/admission` (3); `es/app` had none, and its observed run passed with exactly the three listed entries skipped. So the mount flows that run in CI (`TestSubmitFlowMountsGovernedArtifactAndLifecycleStillWorks`, `TestSubmitFlowRemovesRuntimeMountArchiveResidueAfterExtraction`) and `TestSubmitFlowUsesBridgeNetworkWhenNetworkAccessEnabled` ran and passed there. "Listed tests still fail" and "Listed tests pass as root" were green too.
- **macOS, "test on macOS"**: job 140256321770, success at 01:56:00Z.
- The listed `TestSubmitFlowMountsGovernedArtifactAndLifecycleWithInstalledSourceIdentity` (on `.github/ci/environment-only-tests.txt` at base; the PR changes nothing under `.github/`) still fails for its listed reason, "mount witness: source envelope is incomplete" (`mounted_source_identity_test.go:1092`, unchanged). That check reads `ES_MOUNT_WITNESS_*`, which only a native box run sets, and fails before anything is published. So the PR's one-line edit to that test (it now declares `/execution/mounts/config`, the target it mounts at, read and confirmed) runs nowhere until the next native qualification run; its CI sibling `...StillWorks` covers the same admission path. A wrong declaration there would make the box run refuse the mount, not widen it.
- The earlier head 626c3cd's runs (45921004819, 45921004801) were cancelled when f8bc3df was pushed.
- CI has not run on the PR merged with the newer trunk (a5861b7); GitHub reports the branch as behind. See "Interactions" for my local run of that merge.

## Interactions

- **#68** (one layout for the five services) merged into trunk_dev as a5861b7 near the end of this audit, so GitHub shows #74 as behind. Ten files are changed by both, all merge cleanly; the merged patch's +/- lines equal `git diff fbfd100 f8bc3df` exactly; #74 adds no cross-service import and the layout guard passes on the merge (Validation). The writer has to merge trunk_dev again; that head needs CI and a narrow check that its patch lines are unchanged.
- **#72** merged into trunk_dev at 01:18:43Z, after #74 was opened; the writer merged it at f8bc3df without conflict (tree equal to my trial merge). Three shared files, all clean.
- **#73** (network grants, still open): the writer reports one textual conflict in `.docs/system_overview/contracts.md`; not re-checked here against #73's current head. Whichever lands second needs the usual provenance step.
- **Red-team** runs separately on the same PR; this audit did not read its output.

## Evidence

`21-pr74-audit-evidence/`: `provenance/` (both manifests and the commands), `probes/`, `upstream/` (extracted sudo tables and glibc list with source-file hashes), `tests/` (failing-name lists per tree, the comparison, the runners), `mutants/` (definitions, runner, results, logs), `ci/` (summary and the Linux job log), and `SHA256SUMS`.
