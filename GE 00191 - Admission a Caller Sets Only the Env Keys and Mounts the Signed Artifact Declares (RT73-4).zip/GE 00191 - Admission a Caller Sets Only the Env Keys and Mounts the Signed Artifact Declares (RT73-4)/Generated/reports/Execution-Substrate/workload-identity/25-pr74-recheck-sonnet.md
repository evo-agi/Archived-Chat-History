# Narrow re-check 25 (Sonnet): ES PR #74 repair after re-check 23: BLOCK (one Low finding; every other claimed fix holds; CI on the head: macOS green, Linux still running)

Date: 2026-11-26, about 11:40 PM Eastern (04:40Z on 11-27). Auditor: thread "Sonnet final check of injection fix". Model: `[model withheld]`. Model-evaluation trial, category R-M (narrow re-check, medium); another model checks the same scope independently and I did not read its output. I did not write or audit any part of #74 before. I read the two earlier re-checks (23, Opus and Sonnet) and writer report 24 as the brief asked.

Source labels: "ran" means I ran it in this container on the commit named. "Read" means I read the code or source and did not run it. "Inference:" and "Guess:" mark the rest.

```text
INDEPENDENT AUDIT REPORT (narrow re-check of a repair, protocol §14)
Repository / Audit target:
  evo-agi/Execution-Substrate PR #74, branch claude/project-thread-ef7st5
  base trunk_dev 0b9278ca74404b46b5e9f0e1701874b52687f5e8 (#69)
  topic commit e0b5c89214f11b45d7d88a72cad9b0c5f163c5bd, tree cf451cca91dc396bcbb8845213e4c2254e65ce01
  recipe governed-execution.audit-patch-manifest.v2, source SHA-256
    c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (sha256sum -c OK before each run)
  canonical-manifest SHA-256 6fc6c2927af698d2c28cccb334465d6fd735f86b8ace3c12ae440ed3d44446aa, 31 paths,
    textual_diff_sha256 31f0b9b39939dbbca3285c60a8db376c620ec35a1341bde0d5d235d525a312a4
  Scope: git diff 9c06790 978bccb, git diff d0f4fb7 e0b5c89, and the resolution of merge d0f4fb7 (the #69 PLANS move)
Audit posture: read-only, parent only, no subagents. Nothing pushed, nothing posted on GitHub. Tests, probes and
  mutants ran in separate clones owned by an unprivileged user; the provenance clone ran no tests.
Provenance reproduction: reproduced twice, identical; equal to the writer's manifest file byte for byte; closing run
  equals opening; pushed tip, PR ref and trunk_dev re-read at close, unchanged; all 31 committed blobs equal their
  manifest records; path set equals git diff --name-only; no mode-bit differences (new files are 100644).
Coverage: every hunk of the three delta views; the merge's removed block and moved sentence; the PR body; the other
  copies of the changed sentences in the repo; every use of the newly reserved keys in this repo and in the
  project's other repos; the one non-test caller of the reserved check; the upstream glibc and GCC sources the new
  comments cite; the whole `go help environment` list. Not covered: see "Coverage this environment could not give".
Findings: 1 Low (F1). 5 observations. No finding against the substance of the six claimed fixes.
Validation assessment: whole suite on exact bytes for both trees as an unprivileged user: same 35 failing names on
  both, 18 tests only at the head and all pass, nothing gone, no status change. 40 mutants of my own: 39 killed, 1
  survived (O4). Real-function probe of 128 candidate keys. CI on e0b5c89: macOS green at 04:38:47Z, Linux still running at 04:41Z.
Sensitive-material handling: no secrets, keys, tokens, env files, SQLite or TLS/SPIFFE/Vault material read.
Remaining uncertainty and stop conditions: the Linux CI job on the head ("in_progress" since 04:08:57Z). The
  verdict is BLOCK on F1 whatever CI says, and a fix creates a new head that needs its own CI.
Confidence: provenance high / validation high for what runs here (Docker and Nomad flows run only in CI) /
  implementation high for the six claimed fixes, medium-high on the completeness of the Go class (F1 is the gap).
Effect status: repair, commit, push, PR, merge not performed.
Report delivery: /mnt/project-files/reports/Execution-Substrate/workload-identity/25-pr74-recheck-sonnet.md
  (SHA-256 in the delivering message), evidence in 25-pr74-recheck-sonnet-evidence/ (SHA256SUMS inside).
Final verdict: BLOCK
```

Why BLOCK with one Low finding: the standing rule is that Low findings are fixed in the PR. F1 is three list entries, a line in the pin test and the refusal table, and a few words in the contract. The fix closes the class: the table under F1 classifies every key in `go help environment` (Go 1.26.5), so one more round should not be needed for the Go keys.

## Provenance (ran)

| Step | Result |
|---|---|
| Recipe bytes | `sha256sum -c` OK (`c08597e2…a3ca`), before the opening and the closing run |
| Pushed tip | `git ls-remote`: `refs/heads/claude/project-thread-ef7st5` and `refs/pull/74/head` = `e0b5c89`, `trunk_dev` = `0b9278c`, at the start and again at the close |
| Base ancestry | `0b9278c` is an ancestor of `e0b5c89` |
| Manifest | fresh clone of GitHub, branch checked out at the tip (clean), `git reset --mixed 0b9278c`, upstream `origin/trunk_dev`, two runs to two absent paths in a `0700` directory outside the repo, `cmp` identical, file SHA-256 `6fc6c292…44446aa` (full value above), equal to writer report 24's `manifest-v2-e0b5c89-on-0b9278c.json` byte for byte |
| Committed blobs | 31 of 31 records equal the blob at `e0b5c89` (SHA-256 and size); path set equals `git diff --name-only 0b9278c e0b5c89` |
| Closing run | same clone, recipe re-verified, two runs identical and equal to the opening manifest |
| Diff digests | `git diff 9c06790 978bccb`: 6 files, +125/-42, `2da5ced3…8987d4`; `git diff d0f4fb7 e0b5c89`: 4 files, +67/-23, `d80aff5a…269d7f`; `git diff 0b9278c e0b5c89`: 31 files, +1549/-77, `4f32f7ad…b7412`. All three equal report 24's values |
| Commit chain | `9c06790` → `6b8bab2` → `978bccb` → merge `d0f4fb7` (parents `978bccb`, `0b9278c`) → `e0b5c89`. Linear after the merge |

## Nothing else changed, and the merge resolution (ran)

- **The delta is the delta.** `9c06790..978bccb` touches six files (`contracts.md`, the example README, the reference-workload runbook, the docs test, `caller_declaration_test.go`, `service.go`). `d0f4fb7..e0b5c89` touches four (`contracts.md`, the docs test, `caller_declaration_test.go`, `service.go`). `service.go` is byte-identical at `978bccb` and `d0f4fb7`, so the merge did not touch it. Against the earlier manifest (`22-pr74-repair-evidence/manifest-v2-9c06790-on-a5861b7.json`) 21 of 29 file records are identical and 2 paths are new (the example README and the runbook, both named in report 24). Of the 8 whose bytes differ, 4 are in the delta (`contracts.md`, the docs test, `caller_declaration_test.go`, `service.go`; #69 also changed 3 lines of `contracts.md`, merged cleanly) and 4 differ only because #69 changed the same files (`PLANS.md`, `README.md`, `docs_contract_test.go`, the standing-rule doc; below). The patch lines of those four are compared below.
- **The PR's patch lines did not change by the merge, except for one moved edit.** I compared the `+`/`-` lines of `git diff a5861b7 978bccb` (the PR on its old base) with `git diff 0b9278c d0f4fb7` (the PR on the new base, after the merge), file by file: 31 paths on both sides, 29 files with identical lines. The two that differ are `PLANS.md` and `.docs/standing_rules/execution_admission_and_custody.md`, and the difference is exactly three lines (the PR's two-line rewording and the one old line it replaces) that left `PLANS.md` and appear in the standing-rule doc.
- **The one conflict.** `git merge-tree --write-tree 978bccb 0b9278c` (base `a5861b7`) auto-merges `contracts.md` and the standing-rule doc, and conflicts in `PLANS.md` only. The merge commit's tree differs from that result in exactly two files, `PLANS.md` (the conflict, resolved) and the standing-rule doc (the carried edit), matching `git show --remerge-diff d0f4fb7` (2 files, `+2 -192`; saved as `provenance/remerge-diff-d0f4fb7.patch`).
- **The resolution is faithful.** The 188 lines the resolution removes from `PLANS.md` are a contiguous block of the PR side at `978bccb` (line 1332). Dropping its five-line pointer stub, the remaining 180 lines are a contiguous block of the standing-rule doc at `e0b5c89` (line 878), and with the PR's one reworded sentence put back to the old wording they are a contiguous block of the doc at `0b9278c` (line 876). So #69 moved the text unchanged, the resolution loses nothing of the PR side, and the PR's edit lands in the moved copy at line 1033. `PLANS.md` at `e0b5c89` differs from `0b9278c` only by the PR's own two lines at 289-290 (`git diff -U0`). The stub that #69 deleted was also absent on the trunk side of the conflict (the "theirs" part is empty).
- **No test lost an assertion.** The docs test still refuses the old "empty allowlist" wording in all five docs; `TestCallerDeclarationRulesAreInTheLifecycleContract` and #69's own docs guards pass at the head (root package: pass).

## The claimed fixes

| Claim (report 24) | Verdict | What I checked |
|---|---|---|
| R1: `TEXTDOMAINDIR` and `TEXTDOMAIN` reserved; the false "load no code" claim gone | Fixed | Both are keys in `service.go` (`:301-302`), pinned in `mustBeReservedEnvironmentKeys`, in the refusal table (`TEXTDOMAINDIR`, `textdomain`), out of `TestOrdinaryEnvironmentKeysAreNotReserved`, named in the contract's single-keys bullet. The words "they load no code and change no trust" are gone from the test and from above `redTeam74FamilyKeys` (`grep -r`: no hit in the tree). Mutants K_drop_TEXTDOMAINDIR, K_drop_TEXTDOMAIN killed by `TestReservedEnvironmentKeySetIsPinned` and the refusal test |
| `LANGUAGE` reserved, with the reason | Fixed; claim verified at source | Key, pin, refusal case `Language`, out of the ordinary list; contract states why. **Read:** glibc 2.42 `intl/dcigettext.c:660` is `if (ENABLE_SECURE && IS_PATH_WITH_DIR (single_locale)) continue;` and glibc 2.39 has the same test at `:689`, so a path entry in `LANGUAGE` is skipped only in set-user-ID programs (fetched from `bminor/glibc` tags `glibc-2.39` and `glibc-2.42`, SHA-256 in `upstream/`). **Ran:** I reran the writer's benign probe here (Ubuntu glibc 2.39-0ubuntu8.12, bash 5.2.21): an absolute and a `../` path in `LANGUAGE` give the untranslated text, `TEXTDOMAINDIR` and `LANGUAGE=xx` give the catalog's text, the same four lines as `language-probe/output.txt`. Mutants K_drop_LANGUAGE, C_drop_LANGUAGE_reason killed |
| `LANG`, `LC_ALL` stay open, with the reason | Holds | **Read:** glibc 2.42 `locale/findlocale.c` `valid_locale_name` refuses a name with a `..` component and a name that holds a slash but does not start with one; the lookup builds `<locale dir>/<name>` (`intl/l10nflist.c`, `_nl_make_l10nflist`: the directory list, then `/`, then the name; no special case for an absolute name), so a name stays under the directory unless `LOCPATH`, which is reserved, replaces it. The contract sentence matches. Mutant C_drop_LANG_LC_ALL_open killed. `LC_ALL` is pinned ordinary, and an over-reserving mutant (O_overreserve_LC_ALL) is killed |
| R2: `GCONV_PATH` named as the eighth later-sudo entry | Fixed | The contract sentence and the `service.go` comment both name it ("which the glibc list above already holds"); the docs test requires the whole sentence. The PR body carries it too. Mutants C_drop_GCONV_PATH_sentence and C_credit_sudo_dev_only_seven killed. (sudo's own table was checked by both re-checks 23, same hashes; I did not refetch it, and the delta does not change that claim.) |
| TLS-skip switches: any key ending in `INSECURE_SKIP_VERIFY` reserved | Fixed | `reservedRuntimeEnvSuffixes` holds the one entry; `isReservedRuntimeEnvKey` loops over it on the ASCII-folded, trimmed key (`service.go:1441-1460`); the only non-test caller is still the caller-key loop (`:1216`), so ES's own and profile keys are not judged. **Ran:** the real function reserves `REFERENCE_VAULT_INSECURE_SKIP_VERIFY`, `WORKLOAD_VAULT_INSECURE_SKIP_VERIFY`, a bare `INSECURE_SKIP_VERIFY` and `app_tls_insecure_skip_verify`, and leaves `SKIP_VERIFY` and `INSECURE_SKIP_VERIFY_NOTE` ordinary. Mutants S1 (loop removed), S2 (no case fold), S3 (prefix), S4 (list typo), S5 (contains) all killed |
| Runbook and example README | Fixed | Step 4's publish request now declares `REFERENCE_IDENTITY_URL` and `REFERENCE_SECRET_PATH` only; the submit request never sent the switch (`grep -r`: the key appears only in the entrypoint, the README, the Notes and History, the contract, the code comment and the tests). The tracked archive holds only the entrypoint (`tar tzvf`), which did not change. **Ran:** Python's `ssl.get_default_verify_paths()` reports `openssl_cafile_env='SSL_CERT_FILE'`, and `ssl.create_default_context()` verifies by default, which supports the Notes bullet; ES sets `SSL_CERT_FILE` only when the workload TLS bundle is present (`resolved_execution_plan.go:690-692`, `authorityhandoff.go:224`), as the bullet says ("when the workload-zone Vault configuration carries one") |
| Go and gcc keys incl. `CGO_` reserved | Fixed for every key listed; the class is not closed (F1) | All 12 Go keys, `CGO_`, and the 8 gcc keys the report lists are in `service.go` (diff above) and each is killed when dropped (mutants K_drop_*, P_drop_CGO_; 20 keys and 1 prefix, all killed). The previous Sonnet re-check's O2 list (`GOROOT`, `GOCACHEPROG`, `GOAUTH`, `GOEXPERIMENT`, `CGO_*`, `GCC_EXEC_PREFIX`, `COMPILER_PATH`) is now fully reserved (probe). `GOOS`, `GOARCH`, `GOMEMLIMIT`, `GOGC`, `GOMAXPROCS`, `LC_ALL` are pinned ordinary and over-reserving them is killed. The probe shows the real function agrees with my reading of the code |
| "No flow in this repo or the other repos needs any of them" | Holds | `git grep -w` for every newly reserved key at the head: the only hits are `go build` environments in scripts, Dockerfiles and tests (`CGO_ENABLED=0 GOOS=linux …`, `GOTOOLCHAIN=local`, `runtime.GOROOT()`), none an artifact declaration or a caller key; the three INSECURE switches are read by entrypoints and, for the reference workload, no longer declared. The same search at `trunk_dev` of Maintenance Agent `d60e0d2`, Infrastructure Manager `9623f5c`, Coordinator `aa8104f` and bridge-core `4580426` finds nothing. Archived-Runbooks `main` (`6dbe5d0`) still declares `REFERENCE_VAULT_INSECURE_SKIP_VERIFY` (O3) |

## Findings

```text
AUDIT FINDING F1
Type / Severity: security risk in the backstop (incomplete against its own stated class) and a contract
  sentence that overstates it / low
Current contract: .docs/execution_lifecycle/contracts.md section 5, single-keys bullet: "the Go toolchain keys that
  choose which toolchain, compiler or helper command runs, where modules, sources and build results come from or
  go, or how the toolchain builds and fetches (GOROOT, GOPATH, ... and others)"; report 24 gives the source as
  `go help environment`, Go 1.26.5; PR body says the same
Path and line (e0b5c89): es/admission/service.go:281-300 (the Go and gcc entries) and the comment at :195-212;
  .docs/execution_lifecycle/contracts.md:525
Evidence:
  - `go help environment` (ran, Go 1.26.5) lists `CC`, `CXX`, `FC` and `PKG_CONFIG` together under "General-purpose
    environment variables": "FC: The command to use to compile Fortran code." and "PKG_CONFIG: Path to pkg-config
    tool." `CC`, `CXX` and `AR` are reserved (earlier lists); `FC` and `PKG_CONFIG` are not. Ran: the real
    `isReservedRuntimeEnvKey` at e0b5c89 returns false for both (probes/real-function-key-probe-output.txt).
  - The go command takes both from the environment and runs them. Ran: `PKG_CONFIG=/tmp/mypkg go env PKG_CONFIG`
    prints `/tmp/mypkg` and `FC=/tmp/myfc go env FC` prints `/tmp/myfc`. Read, Go 1.26.5 source:
    `cmd/go/internal/work/exec.go:1659` (`envList("PKG_CONFIG", cfg.DefaultPkgConfig)`, the command the go command
    runs for a `#cgo pkg-config:` line) and `:2418-2434` (`gfortranCmd` from `envList("FC", "gfortran")`, the
    compiler for Fortran files in a cgo package).
  - A third key of the same kind, `GCCGOTOOLDIR` ("where to find gccgo tools, such as cgo", `go help
    environment`), sits beside the reserved `GCCGO`. Ran: `go env` ignores `GOTOOLDIR`, `GOMOD`, `GOEXE` and `GOVERSION` set in the environment, and
    `go env GCCGOTOOLDIR` printed nothing under the gc toolchain, so I did not observe an effect. Inference: it
    matters only to a run that uses gccgo, which `GCCGO` already reserves.
Impact: the same as the keys the PR reserves for this class (`GOCACHEPROG`, `GOROOT`, `CC`): a publisher that
  declares `PKG_CONFIG` or `FC` (they look like plain build configuration) lets a caller choose a program that the
  go command runs when a run builds cgo code. Reach (Inference) is small and the same as for the reserved keys: the run's image
  needs the go toolchain and a C toolchain, and the program must come from a caller mount (mounts keep their execute
  bit: re-check 23, citing red-team 19 observation 3). It is a backstop gap, not a hole in the boundary, and the contract says no list is
  complete; but the PR now states a class by its source, and two keys of that class that sit next to three reserved
  ones are missing, in the sentence audit 21's A1 and re-check 23's R2 were about (a stated list that does not match
  its source).
Required correction (closes the Go class; table below): reserve `FC` and `PKG_CONFIG`, and, for completeness with
  `GCCGO`, `GCCGOTOOLDIR`: add them to `reservedRuntimeEnvKeys` and to `mustBeReservedEnvironmentKeys`; add `FC`
  and `PKG_CONFIG` to the refusal table; name them in the contract's Go parenthetical (a docs test already fails if
  the contract names a key the code does not reserve); add one clause to the code comment ("... helper command runs,
  including pkg-config and the Fortran compiler"); keep the PR body in step. No logic change. If the coordinator
  prefers to leave them open instead, the Go sentence must say so ("the Go keys that choose the C, C++ and linker
  commands ...") and the writer's "left open" list must name `FC`, `PKG_CONFIG` and `GCCGOTOOLDIR` with a reason.
Uncertainty: which images a granted run uses, and whether any holds a go toolchain with cgo, is Unknown.
Patch defect or pre-existing issue: patch defect (the class was stated in e0b5c89; `FC` and `PKG_CONFIG` were open
  before the PR too).
```

### The Go class, key by key (`go help environment`, Go 1.26.5; ran, real function)

| Keys | At `e0b5c89` | Why |
|---|---|---|
| `GOROOT` `GOPATH` `GOBIN` `GOCACHE` `GOCACHEPROG` `GOMODCACHE` `GOWORK` `GOAUTH` `GOVCS` `GOEXPERIMENT` `GOTMPDIR` `GCCGO` `GOFLAGS` `GOENV` `GOTOOLCHAIN` `GOPROXY` `GONOPROXY` `GOPRIVATE` `GOINSECURE` `GOSUMDB` `GONOSUMDB` `GODEBUG` `AR` `CC` `CXX`, and `CGO_*` (every name the help lists, by prefix) | reserved | choose a toolchain, compiler or helper command, or where modules, code and results come from or go |
| `FC` `PKG_CONFIG` `GCCGOTOOLDIR` | **open** | in the stated class: F1 |
| `GOOS` `GOARCH` `GOARM` `GOARM64` `GOAMD64` `GO386` `GOMIPS` `GOMIPS64` `GOPPC64` `GORISCV64` `GOWASM` | open | target selection among code the artifact already holds (the writer's decision; agree) |
| `GO111MODULE` `GOFIPS140` `GO_EXTLINK_ENABLED` | open | mode switches; with `GOPATH` and `HOME` reserved they pick no new code or command (the linker's external mode runs `CC`, reserved) |
| `GOCOVERDIR` `GOTELEMETRY` `GOTELEMETRYDIR` | open | where a covered binary or the go command writes data files; data, not code (O1 notes the file-write kind) |
| `GOEXE` `GOGCCFLAGS` `GOHOSTARCH` `GOHOSTOS` `GOMOD` `GOTOOLDIR` `GOVERSION` | open | computed by the go command. Ran for `GOTOOLDIR`, `GOMOD`, `GOEXE`, `GOVERSION`: setting them in the environment changes nothing (`go env`; a `go build` with `GOTOOLDIR=/nonexistent` succeeds). Not run for `GOGCCFLAGS`, `GOHOSTARCH`, `GOHOSTOS` (Inference: same) |
| `GOMEMLIMIT` `GOGC` `GOMAXPROCS` (not in the help text) | open | runtime tuning (report 24's decision; agree). `GODEBUG` and `GOTRACEBACK` are reserved |

The gcc class is closed against the GCC 14.2 manual (`gcc/doc/invoke.texi`, "Environment Variables Affecting GCC", and `cppenv.texi`, fetched from `gcc-mirror/gcc` tag `releases/gcc-14.2.0`): `GCC_EXEC_PREFIX`, `COMPILER_PATH`, `LIBRARY_PATH`, `CPATH`, `C_INCLUDE_PATH`, `CPLUS_INCLUDE_PATH`, `OBJC_INCLUDE_PATH`, `GCC_COMPARE_DEBUG` are reserved, `TMPDIR` and `GCONV_PATH` and `LD_RUN_PATH` were already; the manual's other keys are `LANG` and `LC_*` (open by design), `GCC_EXTRA_DIAGNOSTIC_OUTPUT` (stderr text), `SOURCE_DATE_EPOCH` (a timestamp) and `DEPENDENCIES_OUTPUT` and `SUNPRO_DEPENDENCIES` (O1).

## Observations (no correction required by this re-check)

- **O1. `DEPENDENCIES_OUTPUT` and `SUNPRO_DEPENDENCIES` are the two gcc keys the manual lists that are left open.** `DEPENDENCIES_OUTPUT` is "equivalent to combining the options `-MM` and `-MF`" (`cppenv.texi`), so it makes gcc write Make rules to a path the caller names; the content is dependency text, not code. This is the file-write kind, outside "load code, name a program or a configuration file, or change TLS trust", but inside the writer's phrase "or extra options", so the writer should decide and say which. Not run.
- **O2. pkg-config's own keys are open** (`PKG_CONFIG_PATH`, `PKG_CONFIG_LIBDIR`, `PKG_CONFIG_SYSROOT_DIR`): they choose which `.pc` files, and so which flags and libraries, a cgo build uses, like `CPATH` and `LIBRARY_PATH`. Outside the PR's stated Go class (they are pkg-config's, not the go command's), and once `PKG_CONFIG` itself is reserved they reach libraries and flags, not a program. Clang's keys (`CCC_OVERRIDE_OPTIONS`) and `MUSL_LOCPATH` stay open as report 24 says.
- **O3. The Archived-Runbooks copy** of the reference-workload runbook (`main` `6dbe5d0`, now) still declares `REFERENCE_VAULT_INSECURE_SKIP_VERIFY` in its publish request. It still works (the declaration is not judged at publish, and the submit request never sends the key), but it contradicts the repo copy once #74 merges. Report 24 asks the coordinator for a backlog line; the project rule is that a deferral needs a machine-enforced trigger, and I found none for the cross-repo refresh (a prose backlog line is not one). Decision for the coordinator; not a #74 defect.
- **O4. One mutant of mine survived: the contract may stop naming `TEXTDOMAIN` and no test notices.** `TestLifecycleContractNamesOnlyReservedKeysTheCodeReserves` requires every prefix and suffix to be named and no unreserved key to be named, but not every reserved single key (the contract says the exact list is the code's, and the single keys are a sample). Report 24 says "the contract names them"; that is true at the head and not pinned. By design, not asked for.
- **O5. `PLANS.md:290`** summarizes what ES reserves as "loader, shell-startup, program-lookup, interpreter, proxy and TLS-trust keys". The sentence was written in 626c3cd and predates the families (Vault, XDG, build tools) and this delta's compiler-toolchain and message-catalog keys; it is not exhaustive and says nothing false. Mention only so the coordinator can decide whether a "build and translation" clause is worth a docs line.
- **Items audit 21 and red-team 19 left open are still open, as report 24 says** (AGS refusing to sign a reserved key, caller mounts without execute permission, retained-original integrity classification, unbounded `argv`). None is in this delta.

## Validation (ran)

All runs as an unprivileged user `ci` (uid 1500), `umask 022`, `env -i`, Go 1.26.5 (`GOTOOLCHAIN=local`, `GOPROXY=off` after `go mod download`), each tree in its own clone of a bundle (tree hashes checked: base `b3c61199…`, head `cf451cca…`), `go test -json -count=1 -timeout 60m ./...`, one tree at a time. `go build ./...` passes on both trees. I did not install the host packages (acl, iproute2, openssh-client, uuid-runtime, the `en_US` locale) that re-check 23's Sonnet run added, Guess: that is why my failure count is higher than its 14.

| Tree | Top-level pass / skip / fail | Compared with base |
|---|---|---|
| base `0b9278c` | 1826 / 87 / 35 | |
| head `e0b5c89` | 1844 / 87 / 35 | the same 35 failing names (and the same 262 failing with subtests); 18 tests only at the head, all pass (2 root docs tests, 2 `ags/publish`, 11 `es/admission` including the retained-request test, 1 `es/app` (`TestSubmitRefusesAMountTheSignedArtifactDoesNotDeclare`) and 2 `internal/contracts/evidence/v1`; names in `tests/status-all-head.txt`); none only at base; no status change |

The 35 failures are in three packages and fail the same way on the base: 3 old-binary probes in `es/admission/internal/reliablesubmit`, 3 in `es/app` (`TestLinuxSetupBootstrapFinishesWithItsSavedSecret`, `TestLinuxSetupGoToolchainInstallerHermeticPreflightAndCleanup`, `TestNomadACLToolRetriesABootstrapThatNeverTookEffect`) and 29 Remote Alpha tests in `scripts`. Guess: this container lacks host tools or paths their fixtures need (re-check 23's Sonnet run saw 14 with those packages installed). The root package passes in full on both trees, including #69's heading-link and PLANS guards and the PR's two docs tests. 55 `es/app` tests skip here (no Docker or Nomad), the same set on both trees. Lists: `tests/failing-head.txt`, `failing-base.txt` (identical), `status-all-*.txt`.

Report 24 gives 55 failures as root in its container for both trees; different environment, same conclusion (names equal to base). I did not rerun as root.

**Mutants of my own** (40, on a clone of the head, targeted tests: `./es/admission/ -run 'TestReserved|TestOrdinary|TestEmptyEnvironment|TestCaller|TestDeclared|TestEnvironmentRefusal|TestOperationalRetained|TestLifecycle'` and `. -run 'TestCallerDeclaration|TestLifecycleContract'`; runner `scripts/mutants.py`, log `mutants/mutants-log.txt`): suffix loop removed, no case fold, as a prefix, list typo, as "contains"; each of the 3 translation keys dropped; each of the 20 Go and gcc keys dropped; `CGO_` dropped; `GOOS`, `LC_ALL`, `GOMEMLIMIT` over-reserved; contract drops the `GCONV_PATH` clause, the `LANGUAGE` reason, the `LANG`/`LC_ALL` sentence, the `CGO_` mention, the suffix bullet, credits sudo's development branch with seven entries again, names `GOOS` as reserved. **39 of 40 killed**, each by the test named in the log. The survivor is O4.

**Real-function probe** (`scripts/zz_audit25_probe_test.go` copied into the `es/admission` package of a scratch clone, run, deleted; 128 candidate keys in `scripts/probe-keys.txt`; output `probes/real-function-key-probe-output.txt`): 58 reserved, 70 open. It is the source of the "not reserved" statements above.

## CI

GitHub (read), last look 04:41Z: "test on macOS" (run 45938193837, job 140306302507) **completed with success** at 04:38:47Z; "build, vet and test" (run 45938193870, job 140306246226, started 04:08:57Z) is still `in_progress`. The run's `head_sha` is `e0b5c89`. I did not wait for the Linux job: the verdict is BLOCK either way, and a fix makes a new head that needs its own CI. CI on the previous head `9c06790` was green (report 24). The mount flows, the bridge-network test and the real-AGS refusal test run only in CI.

## Coverage this environment could not give

- No Docker, Nomad, Vault or SPIRE: the `es/app` mount and network flows skip here; no macOS run.
- I did not run a program that reads the newly reserved keys (a cgo build with `PKG_CONFIG` set, `bash` with `LANGUAGE` pointing at a catalog under set-user-ID). The `go env` results and the source lines above show that the go command takes `PKG_CONFIG` and `FC` from the environment and where it runs them; they are not a demonstration of a caller's command running, which I left undone on purpose, as the earlier re-checks did.
- What the runtime images hold (a go toolchain, cgo, bash scripts using `$"..."`, a non-C locale) is Unknown; no image was inspected.
- sudo's `env.c` tables were not refetched (both re-checks 23 did, with the same hashes; the delta does not change that claim). glibc 2.39 and 2.42 `dcigettext.c` and 2.42 `findlocale.c` and `l10nflist.c` were read from the upstream tags named above; the container's own glibc is Ubuntu's 2.39 build.

## For the writer, in one list

1. F1: reserve `FC`, `PKG_CONFIG` and `GCCGOTOOLDIR` (code, pin, refusal table, contract, comment, PR body), as above; or leave them open and say so in the Go sentence and in report 24's "left open" list.
2. Optional, same round: say in the comment or contract whether `DEPENDENCIES_OUTPUT` and `SUNPRO_DEPENDENCIES` stay open (O1).
3. Then take the new manifest, merge `trunk_dev` again if it moved, and let CI on the new head decide the merge gate with a narrow check that only the F1 lines changed. The audit-21 chain, red-team 19 and re-checks 23 and 25 do not need repeating for those lines beyond that check.

## Evidence

`25-pr74-recheck-sonnet-evidence/`: `provenance/` (opening and closing manifests, the three diffs and their digests, the remerge diff, the commit chain), `upstream/` (glibc `dcigettext.c` 2.39 and 2.42, `findlocale.c` and `l10nflist.c` 2.42, the GCC `cppenv.texi`, with SHA-256 of these and of `invoke.texi`), `probes/` (the rerun of the writer's LANGUAGE probe, the real-function probe output), `tests/` (failing-name lists and per-test status for both trees, progress log), `mutants/` (log), `scripts/` (clone, build, full-run, mutant and probe runners), and `SHA256SUMS`.

STATUS: READY (re-check delivered, verdict BLOCK on one Low finding; Linux CI on e0b5c89 still running, macOS green)
