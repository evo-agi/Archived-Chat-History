# Writer report 30: ES PR #74, re-check 29's nit and the merge of #75

Date: 2026-11-27, about 3:30 AM Eastern (08:30Z). Writer: the "Stop callers injecting code into runs" thread, which wrote #74 (reports 15, 22, 24, 26, 28 and 29).

## Target

| Item | Value |
| --- | --- |
| PR | evo-agi/Execution-Substrate #74, branch `claude/project-thread-ef7st5` |
| Base | `trunk_dev` at `be20ffc8a5f82a35c4ce9064594a081f419c1ef5` (#75), new since report 29 |
| Head | `4d7ed6d8897fda4d318baf845c7b6c150e336ef5`, tree `fb6432494605a83a57d0347784c5d60681fb88c6` (pushed; `git ls-remote` equal) |
| Commits since re-checked `10a3b58` | `aa2b6a5`: four table cases (N29-1). `4d7ed6d`: clean merge of `trunk_dev` at be20ffc (#75), no conflict |
| Delta to re-check | `git diff 10a3b58 aa2b6a5`: 1 file (`caller_declaration_docs_contract_test.go`), +7, `| sha256sum` = `40b2e10aac824644f4564691d0a0773d8dfa45b1cf5adc22bd2b45f961caa87b` |
| The merge | #75 and #74 both edit `.docs/system_overview/contracts.md` and `PLANS.md`, in different sections; git merged them without a conflict. `git diff 0b9278c aa2b6a5` and `git diff be20ffc 4d7ed6d` have the same `git patch-id --stable` (`63b7455bc01edd57de3445dfc2183b1b9b727cdd`), so the PR's change is byte for byte the same on the new base. #75 adds no `environment_variables` declaration and does not touch admission. |
| `git diff be20ffc 4d7ed6d` | 31 files, +1811 / -77, sha256 `80f0c38def9fd02e36262f5e239bec41f340caa4b97591d5d764f9ff8a4abb4f` |
| Canonical manifest (O4) | recipe v2 (source SHA-256 `c08597e2…a3ca`, `sha256sum -c` OK), fresh clone of the pushed branch, reset `--mixed` to `origin/trunk_dev` be20ffc; run twice, `cmp` identical. File SHA-256 `89004ac6502a9c9cf87f738126875a51df387250d25c0a9f73793fbc55ae3686`, 31 files, `textual_diff_sha256` `61fad89e36a514e0ccee532077933f0b974891b6cad7015970e17b9392ebe08e`. File: `24-pr74-repair-evidence/manifest-v2-4d7ed6d-on-be20ffc.json` |

## Delta

| Item | Change |
| --- | --- |
| N29-1 (Sonnet), option (a) | Two table cases, as re-check 29 proposed: a single-quoted entry holding the Python named escape `\N{LATIN CAPITAL LETTER L}`, which must be reported (GM14), and a key name escaped with an upper-case hex digit, `environment\u005Fvariables`, which must fail the count (GM26). |
| GM22 and GM24 (Sonnet, "harmless") | Two more cases, so that every branch re-check 29 weakened now has a case that reaches it: a Go escape in a double-quoted entry (`LD_\x50RELOAD` reads as `LD_PRELOAD`) and an escaped quote in a single-quoted entry (`'A\'B'` reads as `A'B`). GM27 (`{3,4}` hex digits) is left: it changes nothing a JSON or Go decoder accepts. |

## Validation (ran, as root in this container)

- `go build ./...`; `go vet` on root, `es/admission` and `ags/...`: clean. `gofmt -l` on the changed file: empty.
- Root package (full): ok on aa2b6a5 and on 4d7ed6d.
- Mutants on aa2b6a5 (`24-pr74-repair-evidence/mutants-log-aa2b6a5.txt`, runner `mutants-aa2b6a5.py`): GM14, GM26, GM22 and GM24 are each killed by `TestEnvironmentDeclarationScanReadsEachSpelling`. That makes 4 of 4 this round, and 29 of 29 over rounds 28 and 29.
- Full suite on 4d7ed6d (`go test -count=1 -json ./...`, as root): 1857 pass, 81 skip, 55 fail. The 25 extra passes over 3e5fc49's 1832 are exactly the 25 top-level tests #75 added (29 new `func Test` lines, 4 of them `TestMain`), and each of them passes. The 55 failing names equal 3e5fc49's and bba0248's name for name (`24-pr74-repair-evidence/failing-top-level-4d7ed6d.txt`, sha256 fc42519d9a532564524166ec46209d50a2143a448225929eb2cdaa16400ee72f), all environment-only (3 reliablesubmit, 14 es/app, 38 scripts). The four new cases are rows of the table in `TestEnvironmentDeclarationScanReadsEachSpelling` (one test, no subtests), and it passes.
- CI on 10a3b58: both required checks green. CI on 4d7ed6d: both required checks green: "build, vet and test" (Linux, job 140387805041, 08:12:22Z to 08:59:29Z) and "test on macOS" (job 140387804966, 08:16:47Z to 08:47:58Z). GitHub reports the PR mergeable (clean) on base be20ffc.

## Security widening

None. The change is four test cases; the merge brings #75, already reviewed and merged on `trunk_dev`.

## Open, for the coordinator

Unchanged from report 29.

## Confidence

- **Provenance: high.** The manifest was built twice and both runs are identical, the pushed head equals the local one, and the patch-id shows the PR's change is unchanged by the merge.
- **Validation: high** for everything this container can run. The Docker and Nomad flows rely on CI.
