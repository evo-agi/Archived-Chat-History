# Narrow re-check 28 (Sonnet): ES PR #74 repair after re-check 27: BLOCK (two nits only; the three keys, the source wording and the guard's named spellings all hold)

Date: 2026-11-27, about 2:10 AM Eastern (07:10Z). Auditor: thread "Sonnet re-check 28 of PR 74". Model: `[model withheld]`. Model-evaluation trial, category R-M security (narrow re-check, medium); another model checks the same scope independently and I did not read its output (`28-pr74-recheck-opus.md` was not opened; it did not exist when I started). This thread has not written, repaired or audited #74 before. As the brief asked, I read re-check 27 (Opus and Sonnet) and writer report 28.

Source labels: "ran" means I ran it in this container on the commit named. "Read" means I read code, a document or upstream source and did not run it. "Inference:" and "Guess:" mark the rest.

```text
INDEPENDENT AUDIT REPORT (narrow re-check of a repair, protocol §14)
Repository / Audit target:
  evo-agi/Execution-Substrate PR #74, branch claude/project-thread-ef7st5
  base trunk_dev 0b9278ca74404b46b5e9f0e1701874b52687f5e8 (#69)
  topic commit 0e56e23ed9c5ba4742f5967d145373dc157c3a64, tree 3be25b02a4fc447dce00db61e4ed403aea197378
  recipe governed-execution.audit-patch-manifest.v2, source SHA-256
    c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (sha256sum -c OK before each pair of runs)
  canonical-manifest SHA-256 731646edec2a92fd89d746490ae50671ba984731c172bb4d86d7f3f8dc297fd5, 31 paths,
    textual_diff_sha256 eca96ce341048e2563e1fff05e1eed49077198fa7a5457f2571864d9e5fa7fd7
  Scope: git diff 956991c 0e56e23 (4 files, +112/-32, sha256 bc557584...e79). R27-1 / F1 (MAKE, CXX_MODULE_MAPPER,
    MSP430_GCC_INCLUDE_DIR; the contract names its source and what the class leaves out), the runbook guard (padded,
    escaped and single-quoted spellings; fails on unreadable ones), the new pins, and the claim that Archived-Runbooks'
    daily check forces the copy refresh (draft Archived-Runbooks #30).
Audit posture: read-only, parent only, no subagents. Nothing pushed, nothing posted on GitHub, no box, no merge.
  Tests, probes and mutants ran in clones owned by an unprivileged user (uid 1500); the provenance clone ran no tests.
Provenance reproduction: reproduced twice, identical; equal to the writer's manifest file byte for byte; closing
  runs equal the opening; pushed tip, PR ref and trunk_dev re-read at start and close, unchanged; delta digests equal
  the writer's.
Coverage: every hunk of the 4-file delta; the PR body; the writer's report; the whole GCC 14.2.0 manual closure
  (45 environment names) and go help environment (54 keys) against the real reserved-key function at the base, at
  956991c and at the head (257-key probe); the AGS request decoder (ran); the guard's every regex and branch; every
  other use of the three new keys in this repository, in the project's other repositories and in the org's code
  search; the Archived-Runbooks check and draft #30 (ran). Not covered: see "Coverage this environment could not give".
Findings: 2 nits (N28-1, N28-2). 7 observations. No finding against the substance of the repair.
Validation assessment: whole suite on exact bytes for head and base as an unprivileged user: the same 45 failing
  names (14 top-level) on both, 163 names only at the head and all pass, no status change in 10321 common tests, and
  the 43 names only at the base are the randomly named rounds of one pass-both test. 70 mutants of my own: 52 killed,
  18 survived (each classified below). A 257-key probe of the real function. 11 more mutants test my proposed fixes.
  CI on 0e56e23: both required checks green (macOS 06:57Z, Linux 07:09Z).
Sensitive-material handling: no secrets, keys, tokens, env files, SQLite or TLS/SPIFFE/Vault material read.
Remaining uncertainty and stop conditions: none that blocks the verdict. The two nits are fixed by a new head, which
  needs its own CI.
Confidence: provenance high / validation high for what runs here (Docker and Nomad flows run only in CI) /
  implementation high for the repair's substance; the nits are measured, not guessed.
Effect status: repair, commit, push, PR, merge not performed.
Report delivery: /mnt/project-files/reports/Execution-Substrate/workload-identity/28-pr74-recheck-sonnet.md
  (SHA-256 in the delivering message), evidence in 28-pr74-recheck-sonnet-evidence/ (SHA256SUMS inside).
Final verdict: BLOCK
```

**Why BLOCK, in plain words.** The repair does what it says. `MAKE`, `CXX_MODULE_MAPPER` and `MSP430_GCC_INCLUDE_DIR` are now reserved in the code, the pin, the refusal table and the contract. I rebuilt the list of every environment name the whole GCC 14.2.0 manual closure gives (45 names, not only the section "Environment Variables Affecting GCC") and ran each through the real function: 16 are reserved, 29 are open and each of those is outside the stated class (locale, diagnostics, spec-file text, or read by a program built with gcc), and none is in the class and open. The contract now names its source exactly and says what the class leaves out, and that sentence is true. The runbook guard reads the padded, JSON-escaped, Go-escaped and single-quoted spellings and fails on unquoted, keyword-argument and escaped-quote spellings; every mutant of those is killed. Archived-Runbooks' daily check does force the copy refresh.

Two statements are stronger than the tests behind them, and both are the kind the PR body lists as killed mutants. First, the guard "fails on a declaration in a spelling it cannot read", but five spellings slip past it: a key name in another letter case, a key name with a JSON escape, `request["environment_variables"] = [...]`, a YAML block list, and a `]` inside an earlier entry. AGS accepts the first two (ran). Nothing in the repository uses any of them today, and the effect would be a runbook whose caller is refused at submit, so this is a nit. Second, the writer's report says the new required phrases "pin N1's order", and one mutant that puts the `LANG` sentence back in front of the backstop sentence passes every test. Both are fixed by narrowing the claim or by about four lines in the docs test; I tested the four-line version. Because the standing rule is that nits are fixed in the PR, the verdict is BLOCK on nits only, as re-check 21 (Opus) did for #73.

**If the coordinator reads the two statements as observations**, nothing else blocks, and the result is ACCEPT (PASS in the brief). Then the sentence in the guard's comment and the PR body should be narrowed to what the guard does, and the report's "pins N1's order" is simply not true and should not be repeated. I think the small fix is better: it keeps the PR body's mutant list literally true.

## Provenance (ran)

| Step | Result |
|---|---|
| Recipe bytes | `sha256sum -c` OK (`c08597e2…a3ca`), before the opening and the closing runs |
| Pushed tip | `git ls-remote` at the start and at the close (06:56Z): `refs/heads/claude/project-thread-ef7st5` and `refs/pull/74/head` = `0e56e23`, `trunk_dev` = `0b9278c`. The PR API shows head `0e56e23`, base `0b9278c`, 12 commits, 31 files, +1714/-77 |
| Base ancestry | `0b9278c` is an ancestor of `0e56e23`; chain `956991c` → `0e56e23`, one commit, no merge (`provenance/commits.txt`) |
| Manifest | fresh clone of GitHub, branch checked out at the tip (clean), `git reset --mixed 0b9278c`, upstream `origin/trunk_dev`, two runs, `cmp` identical, `manifest_sha256` `731646ed…297fd5`; **equal byte for byte** to the writer's `24-pr74-repair-evidence/manifest-v2-0e56e23-on-0b9278c.json`; 31 files; `textual_diff_sha256` `eca96ce3…fd7` equals the writer's |
| Closing run | the clone had the opening state; two runs, identical, and equal to the opening (`manifest-close-{1,2}.json` = `manifest-open-{1,2}.json`) |
| Diff digests | `git diff 956991c 0e56e23`: 4 files, +112/-32, `bc557584…e79`; `git diff 0b9278c 0e56e23`: 31 files, +1714/-77, `8d9fd445…938`; tree `3be25b02…`. All equal the writer's report 28 values |

## The delta, and what it does (read; one data-only code change and tests)

- `es/admission/service.go`: three map entries (`MAKE`, `CXX_MODULE_MAPPER`, `MSP430_GCC_INCLUDE_DIR`, lines 316-318) and the comment above the single keys re-wrapped and re-worded (longest line 75). No logic change: `isReservedRuntimeEnvKey` is untouched and has the one caller, the caller-key loop.
- `es/admission/caller_declaration_test.go`: the three keys in the exact pin (line 231) and four spellings in the refusal table (`MAKE`, `make`, `CXX_MODULE_MAPPER`, `MSP430_GCC_INCLUDE_DIR`, line 378); `MAKE_TARGET` in the ordinary-keys list.
- `.docs/execution_lifecycle/contracts.md` (section 5, the single-keys bullet, line 525): the gcc clause now names the source and the three keys, and one new sentence says what the class leaves out.
- `caller_declaration_docs_contract_test.go`: the shared matcher (`strings.Map` ASCII fold over `strings.TrimSpace`), the guard (two regexes, an entry regex, `declaredEnvironmentEntry` for JSON, Go and Python-quoted entries, a count check, a per-root requirement, a matcher self-check), and the required phrases for the new text.

## The claimed fixes

| Claim (report 28 and the brief) | Verdict | What I checked |
|---|---|---|
| R27-1 / F1: `MAKE`, `CXX_MODULE_MAPPER`, `MSP430_GCC_INCLUDE_DIR` reserved | **Fixed, all three** | Open at the base and at 956991c, reserved at the head in the real function, with every spelling I tried (`make`, `Make`, padded, tab, NBSP, trailing newline; `probes/probe-head.tsv`, groups `fix28` and `manual28`). Each is in the code, the exact pin, the refusal table and the contract. Dropping any of the three, or turning `MAKE` into a prefix, is killed by the pin (mutants `A_*`, 4 of 4). `MAKE_TARGET`, `MAKELEVEL`, `MAKE_COMMAND`, `CMAKE` and the other near misses stay open (probe); `MAKEFLAGS` and `MAKEFILES` were open at the base and are reserved by earlier rounds of this PR. Reasons: `MAKE` and `CXX_MODULE_MAPPER` are the ones re-check 27 ran against gcc (it started the program they name; I did not repeat those probes, they are unchanged); `MSP430_GCC_INCLUDE_DIR`: read, `invoke.texi:29344-29350`, "this directory will also be registered as an include path, and linker library path", so headers and linker scripts, as the contract says; only a cross compiler for msp430 reads it (the writer says so too) |
| The contract names its source exactly | **Holds** | "every such key a GCC program reads that the GCC 14.2.0 manual, `gcc/doc/gcc.texi` and the files it includes, names in any section, not only in its section on environment variables". I fetched `gcc.texi` at `releases/gcc-14.2.0` and every file it includes (hashes in `upstream/gcc-14.2.0-doc-SHA256SUMS`) and extracted every name (`@env`, `@vindex`, cppenv `@item`, plain text) into `upstream/manual-environment-names-at-0e56e23.tsv`: **45 names** (plus `LPATH` and `GLIBCXX_FORCE_NEW`, which the manual does not hold, as controls). At the head: 16 reserved (14 in the class, `PATH` and `TMPDIR` elsewhere), 29 open. The 29 open ones are: eight `LANG`/`LC_*` keys, `SOURCE_DATE_EPOCH`, `GCC_EXTRA_DIAGNOSTIC_OUTPUT`, `GCC_COLORS`, `GCC_URLS`, `TERM_URLS`, `COLUMNS` (locale and diagnostics; `LANG`, `LC_ALL`, `SOURCE_DATE_EPOCH` and `GCC_EXTRA_DIAGNOSTIC_OUTPUT` are named as open on purpose), `GCC_INCLUDE_DIR`, `TARGET_SYSTEM_ROOT`, `TOPDIR`, `VSB_DIR` (names inside spec-file text, read at `invoke.texi:36844`, `:36970`, `:37012`, `:37386`, not environment reads), and eleven read by a program built with gcc (`ASAN_OPTIONS`, `LSAN_OPTIONS`, `TSAN_OPTIONS`, `UBSAN_OPTIONS`, `HWASAN_OPTIONS`, `VTV_LOGS_DIR`, the four `GCOV_*` keys, `GLIBCPP_FORCE_NEW`). **No key is in the class and open.** This agrees with the writer's own enumeration name for name |
| The contract says what the class leaves out | **Holds** | The new sentence: "keys the GCC manual names that a program built with gcc reads when it runs, such as the sanitizer runtime's `ASAN_OPTIONS` and the coverage runtime's `GCOV_PREFIX`, are outside that class and are not reserved." True: all eleven are open (probe, group `manual28`), and the contract test accepts the sentence. The pinned phrase is mutation-tested: dropping it, dropping `GCOV_PREFIX` from it, or turning "not reserved" into "reserved" is killed (`C_drop_scope_sentence`, `C_scope_sentence_drop_GCOV`, `C_scope_sentence_says_reserved`); naming `ASAN_OPTIONS` among the reserved keys is killed (`C_names_ASAN_OPTIONS_reserved`) |
| N27-2: the 108-column comment line | **Fixed** | longest line of the comment is 75 columns (tab counted as one), neighbours 61-75 |
| Guard reads an entry as ES does: JSON escapes, trim, ASCII fold, single quotes | **Fixed, tested** | Planted in a runbook, an example or a script, each killed by the guard: padded entry, JSON `u`-escape (underscore and a no-break space, `G03`, `G04`), single-quoted, single-quoted with a hex escape, single-quoted and padded (`G02`-`G07`); matcher mutants (no trim, Unicode case mapping, case-sensitive) killed (`H01`-`H03`). The self-check cases (`" LD_PRELOAD"`, tab-padded lower case, `Shell` reserved, the long-s `ſhell` not) hold, and the real function agrees with all of them (probe, group `spell28`) |
| Guard counts every spelling and fails on one it cannot read | **Holds for the spellings it counts; not for five others (N28-1)** | Killed: unquoted key with a colon, keyword argument with `=`, escaped quotes inside a shell string (`G08`-`G10`), a second list in a file, a lower-case key in `.docs`, a multi-line list, an example declaring the new key `MAKE`, a script declaring `CXX_MODULE_MAPPER` (`G17`-`G21`). Survived: `G11`-`G16` |
| Guard needs a declaration in each of `.runbooks`, `.examples`, `scripts` | **Holds** | Dropping any of the three roots, or the check, is killed (`H04`-`H06`, `H13`). `.docs` has no such requirement (O2) |
| Required phrases pin the new sentences | **Holds, except one order (N28-2)** | 13 of 14 contract mutants killed, among them the Go source clause, the gcc source wording and the version, the `any section` clause, both new key names, the `MSP430_GCC_INCLUDE_DIR` name, the `LANG` source reference, the `GOOS` and `SOURCE_DATE_EPOCH` sentences, the scope sentence. The survivor is `C_N1_revert_order` |
| Reserved-key set is pinned exactly; ordinary keys stay open | **Holds** | Over-reserving any of 11 keys the contract calls open (`ASAN_OPTIONS`, `GCOV_PREFIX`, `UBSAN_OPTIONS`, `GCOV_PREFIX_STRIP`, `VTV_LOGS_DIR`, `SOURCE_DATE_EPOCH`, `GCC_EXTRA_DIAGNOSTIC_OUTPUT`, `GO111MODULE`, `GOFIPS140`, `LANG`, `LC_ALL`) is killed (`O_*`, 11 of 11) |
| No flow needs the newly reserved keys (PR body) | **Holds** | The guard passes: none of the nine declarations in `.runbooks`, `.examples`, `scripts` names a reserved key. `git grep -w` for the three keys at the head: no hit outside the writer's four files. The earlier grep of six other repositories (`xrepo/other-repos-grep.txt`) records zero hits per repository, but did not save its pattern; I added the org's code search: `CXX_MODULE_MAPPER` and `MSP430_GCC_INCLUDE_DIR` have 0 hits, and the only non-ES files that mention `environment_variables` are three Maintenance Agent Python files and two Archived-Runbooks runbooks (`xrepo/code-search-new-keys.txt`). Search covers default branches only. `MAKE` is the English word in code search and cannot be searched that way |
| Archived-Runbooks' daily check forces the refresh; draft #30 does it | **Holds, with caveats (O1)** | The workflow runs `check_es_runbook_copies.py trunk_dev` daily (cron 10:17Z), on pull requests, on pushes to `main` and by hand. Ran its script against a clone of AR `main` (`8d99aa0`): against `trunk_dev` 0 problems; against the PR branch (`0e56e23`) exactly 1 problem, the reference-workload runbook. Against draft #30 (`d65e8df`): against the PR branch 0 problems; against `trunk_dev` 1 problem (the same file). So #30 is right for the merged content and cannot pass its own check before #74 merges, as the PR body says |
| Test numbers in the PR body | **Writer's environment** | 1831 pass, 81 skip, 55 fail as root, on 7c0e3de. Mine differ (below); names equal the base in both. The statement that 0e56e23 differs from 7c0e3de only by the matcher self-check is the writer's; I did not diff 7c0e3de (not a re-check target) |

## Findings

```text
AUDIT FINDING N28-1
Type / Severity: test/doc/artifact gap (a claim stronger than the test: the guard "fails on a declaration in a spelling
  it cannot read") / nit
Current contract: the comment above the guard (caller_declaration_docs_contract_test.go:219-225): "…and fails on a
  declaration in a spelling it cannot read." The PR body, "Guards and tests worth knowing": "fails on a declaration in a
  spelling it cannot read", and under Mutants: "a runbook, example or script declares a reserved key, padded,
  `\u`-escaped, single-quoted, or in a spelling the scan cannot read". Writer report 28, row N27-1: "so a new spelling
  cannot slip past".
Path and line (0e56e23): caller_declaration_docs_contract_test.go:238 (declaration regex), :240 (anyDeclaration regex),
  :260-263 (the count that is meant to catch unread spellings)
Evidence (ran): one planted declaration of LD_PRELOAD per mutant, in a real file, run through the real guard
  (mutants/mut1.log, mut2.log). Killed, so the guard reads them: padded, JSON-escaped entry, Go-escaped entry,
  no-break space, single-quoted, hex escape in single quotes, unquoted key with a colon, keyword argument with "=",
  escaped quotes in a shell string, a second list, lower case in .docs, a multi-line list. Survived, so the guard does
  not read them and does not fail on them (G11-G16):
    G11  request["environment_variables"] = ["LD_PRELOAD"]   (indexed assignment: after the name comes "]" before "=")
    G12  a YAML block list: environment_variables:\n  - LD_PRELOAD   (no "[")
    G13  "ENVIRONMENT_VARIABLES": [...]   and
    G14  "Environment_Variables": [...]   (the regexes are case-sensitive)
    G15  the key name with its first letter written as a JSON escape (backslash, u, 0065, then "nvironment_variables")
    G16  "environment_variables": ["APP_MODE", "X]", "LD_PRELOAD"]   (the list body stops at the first "]", and the
         count of spellings still equals the count of lists, so nothing fails)
  AGS's request decoder accepts G13, G14 and G15: it uses encoding/json, which matches field names case-insensitively
  and decodes escapes in key names. Ran (probes/decode-output.txt, zz_audit28_decode_test.go): the three spellings
  decode to the same declared list. A trailing space in the name is refused as an unknown field. Inference: a reserved
  key declared in one of these spellings would publish, and its caller would be refused at submit, which is what the
  guard exists to prevent; I ran the decoder, not a publish.
  Exposure today: none. The four roots hold 12 lines that mention "environment_variables": 9 declarations, all read
  (the guard's own count passes), and 3 prose mentions in .docs that no regex matches.
Impact: documentation hygiene only. A future runbook written in one of the five spellings would declare a reserved key
  without the guard noticing; the effect is a caller refused at submit, with no widening of anything ES admits. It is a
  nit because nothing in the repository is affected and the boundary (the signed allowlist and the reserved backstop) is
  not in play. The claim is stated as complete and listed among killed mutants, so a reader will trust it.
Required correction: pick one.
  (a) Narrow the claim in the comment and the PR body to what the scan does: "reads a quoted or unquoted
      environment_variables key followed by ':' or '=' and a '[' list, and fails on one it counts but cannot read; it does
      not read YAML block lists, JSON-escaped key names, or an entry that contains ']'".
  (b) Widen the scan (tested; probes/proposed-fix-N28.diff, two changed regex lines): "(?i)" on both regexes; "\]?" after the
      quote characters in anyDeclaration, so indexed assignment is counted and fails the count; a string-aware list body
      in the declaration regex, so "]" inside an entry is read. With this change the real tree stays green and G11, G13,
      G14 and G16 are killed (mutants FIX2_*, mut3.log). G12 (YAML) and G15 (escaped key name) still slip; say so in
      the comment, since no regex reads them.
  Either way, change the comment on the anyDeclaration line ("Any spelling of a declaration…") to match.
Uncertainty: whether anyone writes these spellings is Unknown. YAML and key-name escapes need a real parser, which I do not
  recommend for a hygiene check.
Patch defect or pre-existing issue: patch defect (the claim is new in 0e56e23; the guard is from bba0248).
```

```text
AUDIT FINDING N28-2
Type / Severity: test/doc/artifact gap (the order that re-check 25's N1 asked for is not pinned, although the repair
  report says it is) / nit
Current contract: writer report 28, row Sonnet O2 / Opus O1: "the whole backstop sentence through 'Some keys of these
  kinds stay open on purpose.' (pins N1's order)". The comment in the docs test (caller_declaration_docs_contract_test.go:
  35-36): "the sentences on keys left open follow the one that calls the list a backstop." The PR body: the docs test pins
  "the sentences on keys left open, including where they sit" and kills a mutant that "moves that sentence".
Path and line (0e56e23): caller_declaration_docs_contract_test.go:34-44 (the required phrases)
Evidence (ran): mutant C_N1_revert_order moves the backstop sentence ("It is a backstop … Some keys of these kinds stay open
  on purpose.") from after "`TestReservedEnvironmentKeySetIsPinned` pins it." to after the `LANG` and `LC_ALL` sentence.
  That is the order re-check 25's N1 reported. Every test passes (mutants/mut1.log). The cause: the required phrases are
  checked one by one for presence; the backstop block and the `LANG` sentence are each present and whole, and nothing
  ties one to the other. The writer's own mutant C8, "moves the LANG sentence back before the boundary sentence"
  (24-pr74-repair-evidence/mutants-0e56e23.py:52, killed in its log), is a different placement: it inserts the `LANG`
  sentence in front of "The boundary is the allowlist in the next rule.", inside the backstop block, which breaks the
  pinned block. It is not the order N1 reported. I read that mutant and its log line; I did not re-run it.
Impact: none on behaviour. The paragraph can drift back to the order that read as if "It is a backstop" described the
  `LANG` sentence, and the test would not say so.
Required correction: pin the order with two more phrases (tested; probes/proposed-fix-N28.diff): "pins it. It is a
  backstop for a publisher's mistake" and "Some keys of these kinds stay open on purpose. `LANG` and `LC_ALL` stay open:".
  The real contract passes; the mutant is killed (FIX2_pin_order, FIX2_pin_order+C_N1_revert_order). Or drop "pins N1's
  order" from the report, "including where they sit" from the PR body and the comment at lines 35-36 from the test.
Patch defect or pre-existing issue: patch defect in a claim (the order was fixed in bba0248; the claim of pinning is
  0e56e23). Re-check 27's O2 listed "reverting N1's order" as unpinned; the repair added phrases but not this tie.
```

## Observations (no correction required by this re-check)

- **O1. Archived-Runbooks: the trigger is real; four things around it are not enforced.** (1) The check ran daily and passed on three scheduled runs I could read (2026-11-24 20:40Z, 11-25 19:57Z, 11-26 19:39Z; `xrepo/ar-scheduled-runs.txt`); GitHub starts them 9-10 hours after the cron hour, so the first failure after #74 merges comes within about a day, not at 10:17Z. (2) The check also runs on pull requests and pushes to `main`, so after #74 merges, any other Archived-Runbooks PR or push goes red until #30 lands, and #30 cannot go green before #74 merges (the commit message says so). The order the PR body gives is the only one that works. (3) The commit message for #30 says to point the note's commit at the `trunk_dev` commit after the merge; that is a manual step, and the check's documented rules (its docstring, read; I did not test a stale commit) ask that the note exist and name the same ES file, not that its commit be on `trunk_dev`. If #74 is squash-merged, `0e56e23` is not on `trunk_dev`. (4) Whether the check is a required status on Archived-Runbooks `main` is Unknown (I cannot read that repository's branch protection).
- **O2. The guard's own branches are exercised only by a planted spelling.** Of the guard's code mutants, 5 survive: dropping the `.docs` root (`H07`, no declaration in `.docs` today and no per-root requirement for it; `G18` shows a planted `.docs` list is caught), removing the count check (`H08`), dropping `=` from the count regex (`H09`), reading single-quoted entries raw (`H11`) and a double-quote-only declaration regex (`H12`). The repository has no single-quoted or odd-spelled list, so no existing file reaches those lines. This is why the writer's U-mutants plant files. It would be cheaper to keep if the scan were a function over a string with a small table test; optional. Two more survivors (`H14`, `H15`) remove cases from the matcher self-check itself; the cases they remove are what kill `H01`-`H03`.
- **O3. gcc also reads `TMP` and `TEMP`; only `TMPDIR` is reserved.** `libiberty/make-temp-file.c:131-133` (`choose_tmpdir`, GCC 14.2.0, read) tries `TMPDIR`, `TMP` and `TEMP` in that order, and gcc's driver uses it for its temp files (Inference; I did not read gcc's use of it). At the head `TMP` and `TEMP` are open (probe, group `extra28`) and `TMPDIR` is reserved ("reserved elsewhere"). The manual names only `TMPDIR` (`invoke.texi:37346`), so the stated source is closed and this is not a finding. Effect (Inference): a caller who sets them chooses the directory for compiler temp files, not a program or a header; the same kind of key as `GOTMPDIR`, which is reserved. For the coordinator, with the sanitizer and `GCOV_*` keys the writer already lists as open.
- **O4. Driver-internal keys are open: `COLLECT_GCC`, `COLLECT_GCC_OPTIONS`, `COLLECT_LTO_WRAPPER`, `COLLECT_AS_OPTIONS`, `COLLECT_NO_DEMANGLE`, `GCC_DEBUG`, `GCC_OPTIONS`** (probe, group `outside28`). The manual does not name them, so they are outside the stated source. Guess: the gcc driver sets the `COLLECT_*` keys itself for its children, so a caller's value is probably overwritten; I did not read or run this. Opus's earlier O2 raised them; the writer lists them as outside the class.
- **O5. `MSP430_GCC_INCLUDE_DIR` is read from the manual only.** I did not read the msp430 port's source. The manual text gives the class the contract states, and only a cross compiler for msp430 reads the key, so reach is smaller than for the other two; the writer says so too.
- **O6. Items the earlier rounds left open are still open, unchanged and outside this delta**: AGS refusing to sign a reserved key, caller mounts without the execute bit, unbounded `argv`, `MUSL_LOCPATH` and clang's own keys (writer report 28, "Open, for the coordinator").
- **O7. The PR body's mutant counts** ("15 of 15, 12 of 12 and 22 of 22") are the writer's; I re-ran independent equivalents of the round-27 group, which is what this scope is, and got the results in the table below. The mismatches are N28-1 (spellings "the scan cannot read") and N28-2.

## Validation (ran)

All runs as an unprivileged user (uid 1500), `umask 022`, `env -i`, Go 1.26.5 (`GOTOOLCHAIN=local`, `GOPROXY=off`), one clone per tree made from a bundle, `go vet . ./es/... ./scripts/... ./internal/...` then `go test -count=1 -timeout 30m -json ./...`, one tree at a time. Scripts in `tests/`.

| Tree | vet | Top-level pass / skip / fail | Compared with base |
|---|---|---|---|
| base `0b9278c` | exit 0 | 1847 / 87 / 14 | |
| head `0e56e23` | exit 0 | 1866 / 87 / 14 | the same 45 failing names (the same 14 top-level, with subtests); 163 names only at the head, all pass (19 top-level: the PR's own tests); 43 only at the base, all the randomly named rounds of `TestRedTeamPR12CombinedSIGKILLAtRandomInstants` (`round_0_after_27ms` and so on), which pass at both; 10321 names in common, no status change |

The 14 top-level failures are in three packages and fail the same way on the base: 3 old-binary probes in `es/admission/internal/reliablesubmit`, 2 in `es/app` (`TestLinuxSetupBootstrapFinishesWithItsSavedSecret`, `TestNomadACLToolRetriesABootstrapThatNeverTookEffect`) and 9 in `scripts`. Guess: this container lacks host tools or paths their fixtures need; it is not the writer's container (55 failures as root). The 19 top-level tests only at the head: 3 root (`TestCallerDeclarationRulesAreInTheLifecycleContract`, `TestLifecycleContractNamesOnlyReservedKeysTheCodeReserves`, `TestRunbooksAndExamplesDeclareNoReservedEnvironmentKey`), 2 `ags/publish`, 11 `es/admission`, 1 `es/app`, 2 `internal/contracts/evidence/v1` (`tests/only-head-top.txt`). Docker, Nomad and Vault flows skip here. `gofmt -l` on the changed Go files is empty. The two targeted sets pass on the head (mutant baselines).

**Mutants of my own (70, plus 11 for the proposed fixes)**, on clones of the head, runner `mutants/mutants28.py`, logs `mutants/mut1.log` and `mut2.log` (round 1) and `mut3.log` (fixes); targeted sets `./es/admission/ -run 'TestReserved|TestOrdinary|TestEmptyEnvironment|TestCaller|TestDeclared|TestEnvironmentRefusal|TestOperationalRetained|TestLifecycle'` and `. -run 'TestCallerDeclaration|TestLifecycleContract|TestRunbooksAndExamples'`; baseline green first, each mutant on a clean checkout. **52 killed, 18 survived.**

| Group | Mutants | Killed | Survived |
|---|---|---|---|
| Code: each of the 3 new keys dropped; `MAKE` turned into a prefix | 4 | 4 | 0 |
| Code: a key the contract calls open reserved (11 keys) | 11 | 11 | 0 |
| Test pins: new keys dropped from the exact pin, from the refusal table, `MAKE_TARGET` from the ordinary list | 3 | 1 | 2: redundant (the exact pin already kills every code mutant above) |
| Contract text | 14 | 13 | 1: N28-2 |
| Planted declarations in runbooks, examples, scripts, docs | 22 | 15 | 7: `G11`-`G16` (N28-1) and `G22`, which plants the ordinary key `MAKE_TARGET`, where green is the wanted result |
| The guard's own code | 15 | 8 | 7: `H07`, `H08`, `H09`, `H11`, `H12` (O2), `H14`, `H15` (mutations of the self-check) |
| Fix check: key-name case only (green wanted) | 1 | | passes |

None of the 18 survivors is a reservation: every mutant that changes which key the code reserves is killed. The two findings are the survivors that say something about a claim.

**Proposed fixes** (`probes/proposed-fix-N28.diff`, two changed regex lines and two added phrases in `caller_declaration_docs_contract_test.go`; 11 mutants): the real tree stays green with the widened regexes and with the two order phrases. With the widened regexes, a planted `G11`, `G13`, `G14`, `G16` and the two earlier planted spellings (`G01`, `G05`) are killed; `G12` and `G15` survive (a YAML block list and an escaped key name need a parser). With the two order phrases, `C_N1_revert_order` is killed.

**Real-function probe** (`probes/zz_audit28_probe_test.go`, copied into the `es/admission` package of a scratch clone, run, deleted; 257 keys in `probes/keys.tsv`: all 54 keys of `go help environment`, all 45 environment names of the GCC 14.2 manual closure plus controls, the three new keys and their spellings, near misses for each, driver-internal keys, padded and re-cased spellings and `TMP`/`TEMP`; run on the base, 956991c and the head, outputs `probes/probe-{base,prev,head}.tsv`). Differential 956991c → head: exactly the three new keys flip from open to reserved, with their spellings (17 probe rows), and **no key flips from reserved to open**. Against the base 130 rows flip, all of them open at the base and reserved at the head (none the other way). **AGS decoder probe** (`probes/zz_audit28_decode_test.go`, run in `ags/publish` of a scratch clone): the field names `environment_variables`, `Environment_Variables`, `ENVIRONMENT_VARIABLES` and one with a JSON u-escape decode to the same list; a trailing space or a missing underscore is refused; a single-quoted name is not JSON.

## CI

GitHub (read via the connector). `0e56e23`: "test on macOS" (run 45951497624, job 140348160640) **completed with success** at 06:57:49Z (started 06:27:04Z). "build, vet and test" (run 45951497649, job 140348160543, started 06:23:05Z) **completed with success** at 07:09:49Z (46 min 44 s). Both runs' `head_sha` is `0e56e23`. I read only the tail of the Linux job log, which is the post-job cleanup, not the test output; the job conclusion is the gate's verdict (Inference from the gate's rule that an unlisted failure fails the job, as in re-check 23a). Both jobs were still running for most of my work; I waited for them. Evidence: `ci/check-runs-0e56e23.txt`.

## Coverage this environment could not give

- No Docker, Nomad, Vault or SPIRE: the `es/app` mount and network flows skip here, so I did not run `:submit` with a caller declaring any of the three keys; the evidence for the keys is the real function and the manual. No macOS run of my own (CI's macOS job is the reference and is green).
- I did not repeat the gcc probes of re-check 27 for `MAKE` and `CXX_MODULE_MAPPER` (unchanged by this delta) and I did not run an msp430 compiler (O5).
- The gcc manual and sources I cite are 14.2.0; this container's gcc is 13.3.0, which I did not need to run.
- I cannot read branch protection or required checks of Archived-Runbooks (O1).
- Org code search covers default branches, so it cannot see this PR's own files.
- What the runtime images hold (g++ with modules, LTO, msp430) is Unknown; no image was inspected.

## For the writer, in one list

1. N28-1: narrow the guard's claim in the comment and the PR body (also its mutant line), or widen the scan with `probes/proposed-fix-N28.diff` (case-insensitive, indexed assignment counted, string-aware list body) and say what still slips (YAML block lists, an escaped key name). Update the "Any spelling of a declaration" comment either way.
2. N28-2: add the two order phrases from the same diff, or drop "pins N1's order" and "including where they sit".
3. Optional, same round: O2 (scan as a function with a table test), O3 (name `TMP` and `TEMP` as open, or reserve them).
4. After #74 merges, #30's note must be pointed at the `trunk_dev` commit by hand (O1).
5. Then take the new manifest, merge `trunk_dev` again if it moved, and let CI on the new head decide the merge gate with a narrow check that only these lines changed. The audit-21 chain, red-team 19 and re-checks 23, 25 and 27 do not need repeating for them.

## Trial log row (for the coordinator to copy)

| Date | Category | PR @ head | Scope | Model | Verdict | Findings | Later outcome |
|---|---|---|---|---|---|---|---|
| 2026-11-27 | R-M security | ES #74 @ 0e56e23 | narrow re-check of 956991c..0e56e23 (real) | [model withheld] | BLOCK (nits only) | N28-1 nit: the runbook guard's "fails on a spelling it cannot read" is overclaimed (5 spellings slip: key case, escaped key name, indexed assignment, YAML block list, "]" in an entry; none in the repo today; fix tested). N28-2 nit: "pins N1's order" is false (mutant moving the LANG sentence back passes; two phrases fix it, tested). 7 observations (AR trigger real with caveats; guard branches only exercised by planted files; TMP and TEMP open; driver keys open; MSP430 read from the manual only; old open items unchanged). The three keys, the source wording and the scope sentence verified: 45 manual names, 16 reserved, 29 open and outside the class; same 45 failing names as base, no status change; 52 of 70 own mutants killed (18 survivors classified); CI green on both required checks | to fill in: pair is the Opus run on the same head and scope, not read |

## Evidence

`28-pr74-recheck-sonnet-evidence/`: `provenance/` (opening and closing manifests, the delta diff and digests, the commit chain, the recipe hash), `tests/` (runner scripts, failing-name lists for both trees, the names only at one tree, vet output, gzipped `go test -json` of both runs), `probes/` (the 257-key list and probe test, outputs for the base, 956991c and the head, the decoder probe and its output, the proposed-fix diff), `mutants/` (runner, name lists, the three logs), `upstream/` (hashes of the GCC 14.2.0 doc files, the manual-names table, the `choose_tmpdir` reads), `xrepo/` (the Archived-Runbooks check outputs for `main` and draft #30 against `trunk_dev` and the PR branch, the scheduled runs, the other-repository grep, the code search), `ci/` (the check runs), `README.md` and `SHA256SUMS`.

STATUS: READY (re-check delivered, verdict BLOCK on two nits; CI on 0e56e23 green on both required checks)
