# Re-check 23a (Opus): CI on ES PR #74 at 9c06790, addendum to 23-pr74-recheck-opus.md

Date: 2026-11-26, about 11:05 PM Eastern (04:05Z on 11-27). Read through the GitHub connector; I ran nothing on GitHub.

## Result: both required checks green on the audited head 9c06790

| Check | Run / job | Head SHA | Result |
| --- | --- | --- | --- |
| Linux, "build, vet and test" | run 45931533404, job 140285058935 | `9c067902afc4edafd250f8ba06b1e64b1666d72f` | success, 02:59:40Z to 03:46:08Z |
| macOS, "test on macOS" | run 45931533282, job 140285058666 | `9c067902afc4edafd250f8ba06b1e64b1666d72f` | success, job 03:06:34Z to 03:41:46Z (test gate, Test and "Listed tests still fail" steps all succeeded) |

Linux log lines (quoted):

- `test gate passed: 50 packages, 3 of them with skipped entries (17 entries); 14 tests skipped themselves, all of them listed` (03:30:53Z)
- Self-skips: `execution-substrate/scripts: 9 tests skipped themselves`, `execution-substrate/es/admission/internal/reliablesubmit: 2 tests skipped themselves`, `execution-substrate/es/admission: 3 tests skipped themselves`.
- `execution-substrate/es/app: the observed run passed; go test skipped exactly the listed tests of this package (3), each once`. So the es/app Docker/Nomad flows that skip in a cloud container, including the PR's mount tests and `TestSubmitRefusesAMountTheSignedArtifactDoesNotDeclare`, ran and passed here. Inference: from the gate's rule that every test not listed must run; I did not find each test name in the log.
- `all 17 listed tests still fail on this host, each in a run of its own and in the run of its package` (03:45:07Z). These include `TestSubmitFlowMountsGovernedArtifactAndLifecycleWithInstalledSourceIdentity`, still failing for its listed reason, `mount witness: source envelope is incomplete` (as audit 21 found), and the 3 reliablesubmit old-binary probes.
- `tests as root passed: 9 of execution-substrate/scripts` (03:46:04Z).

No test failed outside the list. These results match audit 21's CI result for f8bc3df.

## The head has moved since this re-check

At 04:03Z, `refs/pull/74/head` is `978bccb5657db177be8b73f8d767ca2815f38cb0`: `6b8bab2` (03:49Z, "Admission: reserve bash's translation keys and any INSECURE_SKIP_VERIFY switch (re-check 23 R1, R2)") and `978bccb` (03:51Z, "Docs test: pin the later-sudo attribution sentence (re-check 23 R2)"). 6 files, +125 / -42 against 9c06790. `trunk_dev` has also moved to `0b9278ca74404b46b5e9f0e1701874b52687f5e8`. Re-check 23 and this addendum bind only 9c06790. The new head needs its own fresh re-check (protocol §14), and its CI (runs 45936615915 and 45936615923, started 03:51:57Z) was still running at 04:01Z. I did not read or judge those commits.

STATUS: READY (CI on 9c06790 green; verdict of re-check 23 stays BLOCK for 9c06790; new head 978bccb awaits a fresh re-check)
