# Re-check 23 (Opus): ES PR #74 repair since f8bc3df: BLOCK (one low finding and one low docs nit; every claimed fix holds)

Date: 2026-11-26, about 10:35 PM Eastern (03:35Z on 11-27). Thread: "Opus re-check of caller injection fix". Fresh and read-only: this thread did not write #74, did not audit it before, and did not read the paired re-check of the model-evaluation trial (category R-M). Model: [model withheld].

Source labels: "ran" means I ran it in this container on the commit named; "read" means I read the code or document and did not run it; "Inference:" and "Guess:" mark the rest.

```text
INDEPENDENT AUDIT REPORT (narrow re-check of a repair, protocol §14)
Repository / Audit target:
  evo-agi/Execution-Substrate PR #74, branch claude/project-thread-ef7st5
  base a5861b7c0e2199a77b489d25e6b3fc02e6448c20 (trunk_dev, #68)
  topic commit 9c067902afc4edafd250f8ba06b1e64b1666d72f (merge of 0626d9c and a5861b7)
  tree 727481fed42b3278eef78ba3fea602947200502e
  recipe governed-execution.audit-patch-manifest.v2, source SHA-256
    c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (sha256sum -c OK before each run)
  canonical-manifest SHA-256 1f19ff0055926632216fe6aef0f2328acce41e567ea8dd32a3759671fdbfc2f4, 29 paths
  Scope: the delta since audit 21's target f8bc3df (a0e8158, 0626d9c) plus the trunk_dev merge 9c06790.
Audit posture: read-only. Parent only, no subagents (narrow delta). Nothing pushed, nothing posted on
  GitHub, no Linux box, no live service. Tests, probes and mutants ran as an unprivileged user in its own
  clones, never in the provenance clone. Local branches audit-head/audit-base/audit-f8 were created in this
  container's clone to make a bundle and deleted at the end; never pushed.
Provenance reproduction: equal to writer report 22, byte for byte, twice; closing run equal to opening.
Coverage: every line of git diff f8bc3df 0626d9c (6 files); the merge 9c06790 (tree check and patch-line
  check); the reserved-key check and its only caller; every declared and sent caller key in this repo,
  Archived-Runbooks 8d99aa0, MA d60e0d2, IM 9623f5c, Coordinator aa8104f, Bridge-Core 4580426; upstream
  sudo 1.9.16p2 and main env.c and glibc 2.42 sources (fetched again, same SHA-256 as audit 21); glibc 2.42
  intl and locale sources; the bash 5.2.21 manual. Uninspected: Docker/Nomad flows (no daemon here; CI is
  the reference), the static-script runtime image (configured on the host, not in the repo).
Findings: 2 low (R1 security risk in the backstop plus a test that freezes it; R2 docs attribution nit).
  No medium or higher. 3 observations.
Validation assessment: full suite re-run on head and base as an unprivileged user: same failing names on
  both, 18 new tests (16 from 626c3cd, 2 from the repair) all pass, nothing gone or newly skipped; es/app and
  scripts re-run without proxy variables, same result. Red-team 19's eight probes re-run at 9c06790: pass.
  10 mutants of the repair: 9 killed, 1 survives (A1 wording, no test asked for). The proposed fix for R1
  passes the affected tests. CI on 9c06790 was still running at 03:34Z (see "CI").
Sensitive-material handling: no secrets, keys, tokens, env files, SQLite or TLS/SPIFFE/Vault material read
  into the report or evidence.
Remaining uncertainty and stop conditions: CI on 9c06790 had not finished when this report was written; a CI addendum
  follows. R1's reach depends on runtime images I could not inspect.
Confidence: provenance high / validation high / implementation high for the claimed fixes, medium-high
  for the backstop's completeness (by design it cannot be complete).
Effect status: repair, commit, push, PR, merge not performed.
Report delivery: /mnt/project-files/reports/Execution-Substrate/workload-identity/23-pr74-recheck-opus.md
  (SHA-256 in the delivering message), evidence in 23-pr74-recheck-opus-evidence/ (SHA256SUMS inside).
Final verdict: BLOCK
```

Why BLOCK with only low findings: the standing rule is that low findings are fixed in the PR, and the brief asked me to confirm that the seven keys left open load no code. Six of them hold; `TEXTDOMAINDIR` does not, and the repair added a test that pins it open with a comment saying it loads no code. The fix is two list entries, one test edit and one contract phrase (tested below). Everything else the repair claims holds.

## Provenance (ran)

| Step | Result |
| --- | --- |
| Recipe bytes | `sha256sum -c` OK (`c08597e2…a3ca`) |
| Pushed tip | `git ls-remote`: `refs/pull/74/head` and `refs/heads/claude/project-thread-ef7st5` = `9c06790`, `trunk_dev` = `a5861b7`, at 03:02Z and again at 03:33Z |
| Base ancestry | `git merge-base --is-ancestor a5861b7 9c06790`: yes |
| Tree | `9c06790^{tree}` = `727481fe…`, equal to `git merge-tree --write-tree 0626d9c a5861b7`, so the merge is git's own clean merge with no hand edit |
| Manifest | fresh clone, branch checked out at the tip, `git reset --mixed a5861b7`, upstream `origin/trunk_dev`; two runs, `cmp` identical; file SHA-256 `1f19ff00…fbfc2f4`, equal to `22-pr74-repair-evidence/manifest-v2-9c06790-on-a5861b7.json` byte for byte; 29 paths; `textual_diff_sha256` `95e614e2…f161b` |
| Committed blobs | every manifest record equals the blob at `9c06790` (SHA-256 and size, 0 differences); path set equals `git diff --name-only a5861b7 9c06790` |
| `git diff a5861b7 9c06790` | 29 files, +1420 / -75, `\| sha256sum` `07626657…72df96` (writer's value) |
| Closing run | 03:33Z, same clone, recipe re-verified: two runs identical and equal to the opening manifest |

## Nothing changed beyond the stated repair and a clean merge (ran)

- The `+`/`-` lines of `git diff fbfd100 0626d9c` (the PR on its old base, after the repair) and `git diff a5861b7 9c06790` (the PR on its new base) are identical, and the path sets are identical. So the merge changed context only.
- The trunk side of the merge, `git diff 0626d9c 9c06790`, has the same `+`/`-` lines as `git diff fbfd100 a5861b7` (#68 itself).
- Therefore the only change to the PR's patch since audit 21's target is `git diff f8bc3df 0626d9c`: 6 files, +273 / -16: `es/admission/service.go` (list entries and comments only), `.docs/execution_lifecycle/contracts.md` (section 5), `.docs/standing_rules/execution_admission_and_custody.md`, `caller_declaration_docs_contract_test.go`, `es/admission/caller_declaration_test.go` and the new `es/admission/reliable_submit_retained_request_env_test.go`. This matches writer report 22's table.
- In `service.go` the diff touches only the two `var` blocks (`reservedRuntimeEnvKeys`, `reservedRuntimeEnvPrefixes`) and their comments. `isReservedRuntimeEnvKey` (`service.go:1391`) and `validateInvocationAgainstManifest` (`:1137`) are unchanged, and the reserved check has one caller (`:1166`), the caller-key loop. It is not applied to profile or ES keys, so a wider list cannot refuse a runtime profile's own environment (read: grep for every use at `9c06790`).

## The claimed fixes

| Finding | Verdict | Evidence |
| --- | --- | --- |
| A1 (audit 21) | Fixed, one omission (R2) | Contract `.docs/execution_lifecycle/contracts.md:520` and `service.go:125-131`, `:270-271`, `:275-279` now credit 1.9.16p2 only with its own entries. I fetched both sudo files again (same SHA-256 as audit 21) and diffed the tables: every key in the code's sudo block is a 1.9.16p2 Linux entry or one of the later additions it names, the three wildcard prefixes are 1.9.16p2's, and the `PYTHON` comment names exactly 1.9.16p2's four `PYTHON*` entries. sudo main adds eight entries, not seven: the contract, both comments and the PR body leave out `GCONV_PATH` (R2). The PR body is in step otherwise. No test guards the wording (mutant R09 survives), which audit 21 did not ask for. |
| A2 (audit 21) | Fixed | `.docs/standing_rules/execution_admission_and_custody.md:138-142` now reads as `contracts.md:1302` does. "empty allowlist behavior" is in the docs test's refused list for the five docs (`caller_declaration_docs_contract_test.go:57`). Mutant R05 (old sentence back) is killed. A repo-wide search finds no other "empty (environment) allowlist" wording; the two hits for "allowlist" are about caller authentication. |
| RT74-1 (red-team 19) | Fixed as claimed; the claim about the 7 keys left open holds for 6 (R1) | The 87 keys in `redTeam74FamilyKeys` are exactly red-team 19's 94 open keys minus the 7 the writer left open (set comparison against `19-pr74-redteam-evidence/outputs/at-f8bc3df-all-probes.txt`, no key missing or extra). Red-team 19's own probes rerun at `9c06790`: `keys probed=107 reserved=100 admitted when declared=7`, the 7 being `LANG LC_ALL LANGUAGE TEXTDOMAINDIR GOMEMLIMIT GOGC GOMAXPROCS`, and all eight red-team probes pass, including the 4,000-request job probe and the 3,000,000-key fuzz. The overclaiming sentence is gone (`contracts.md:520` now says "best-known … They do not include every such key") and the docs test refuses the old wording (mutant R06 killed). Every new prefix is named in the contract (mutant R07 killed) and the contract cannot name a key the code does not reserve (mutant R08 killed). Dropping a prefix or a key is caught by the pin, the 87-key test and the refusal table (mutants R02, R03, R04 killed). |
| RT74-2 (red-team 19) | Fixed | `reliable_submit_retained_request_env_test.go` equals red-team 19's `regressions/es_admission_retained_request_env_test.go` except its header comment (diff: one line). Mutant R01 (red-team's MN: the retained check returns true) is killed by it. The opposite mistake, refusing every retained caller key (mutant R10), is killed by 42 operational tests, including this test's own control case. |

No other change: AGS, the evidence contract, examples and scripts are untouched by the repair (diff above).

## Findings

```text
AUDIT FINDING R1
Type / Severity: security risk in the backstop, and a test that pins it open / low
Current contract: .docs/execution_lifecycle/contracts.md section 5 (reserved keys are a backstop for a
  publisher's mistake); writer report 22: the 7 keys left open "load no code and change no trust"
Path and line (9c06790): es/admission/caller_declaration_test.go:362-364 (TEXTDOMAINDIR pinned as an
  ordinary key, with the comment "they load no code and change no trust"); :238-239 (same claim);
  es/admission/service.go:83-264 (TEXTDOMAINDIR and TEXTDOMAIN in no list and under no prefix)
Evidence:
  - TEXTDOMAINDIR names the directory bash reads the translations of $"..." strings from. The bash 5.2.21
    reference manual (Ubuntu bash-doc 5.2.21-2ubuntu4, section 3.1.2.5) says: "Since this is a form of
    double quoting, the string remains double-quoted by default, whether or not it is translated and
    replaced. If the noexpand_translation option is enabled ..., translated strings are single-quoted
    instead", and of TEXTDOMAINDIR: "You, or possibly your users, set the TEXTDOMAINDIR variable to the
    name of a directory where the message catalog files are stored."
  - Ran (benign probe, evidence textdomain-probe/): bash 5.2.21 takes TEXTDOMAINDIR from the environment
    and prints the translation from a catalog in that directory (output line 2). A catalog whose
    translation holds "$TEXTDOMAIN" prints the expanded value (line 3), and the literal text once the
    script sets noexpand_translation (line 4). So a translation from a caller-chosen directory goes through
    double-quote expansion.
  - Inference from the same manual (not run, on purpose: a demonstration of caller code running is not
    planned in this project's threads): double-quote expansion includes command substitution, so a catalog
    the caller supplies can run commands in any bash script that uses $"..." under a non-C locale.
  - TEXTDOMAIN, which none of the reports probed, does the same through "../" (ran, line 5): bash and
    glibc open /usr/share/locale/en/LC_MESSAGES/../../../../../<dir>/probe.mo.
  - The caller needs a directory it controls: a declared mount (files keep their execute bit and a mount
    admits any publisher's governed artifact, red-team 19 observation 3) is one.
  - The other six keys hold (ran and read): LANG and LC_ALL only select installed locales, because glibc
    refuses traversal and builds paths under the default locale directory unless LOCPATH (reserved) is
    set (findlocale.c valid_locale_name; probe lines 7-8). LANGUAGE entries with a path were ignored by
    this container's glibc 2.39 (probe line 6; python ctypes dgettext the same), though glibc 2.42's
    dcigettext.c skips them only for set-user-ID programs (read), so other C libraries may differ;
    catalogs it selects are message text, not code, so I do not count LANGUAGE against the claim.
    GOMEMLIMIT, GOGC and GOMAXPROCS tune the Go runtime and load nothing.
Impact: a publisher who declares TEXTDOMAINDIR (it looks like plain configuration, the case the backstop
  exists for) lets a caller run commands in bash scripts that translate strings. Reach today is small:
  it needs a non-C locale in the image (Inference: the repo's only image, node:22-bookworm-slim, has
  none beyond C.UTF-8; the static-script image is configured on the host and Unknown) and a script using
  $"...". But the PR now pins TEXTDOMAINDIR as safe in a test whose comment states the false property,
  which makes the wrong claim harder to undo later.
Required correction: reserve TEXTDOMAINDIR and TEXTDOMAIN (bash's translation directory and domain),
  remove TEXTDOMAINDIR from TestOrdinaryEnvironmentKeysAreNotReserved and add both to the pinned list,
  and name them in the contract's single-keys bullet (for example "where bash reads the translations of
  $"..." strings, which it expands as double-quoted text (TEXTDOMAINDIR, TEXTDOMAIN)"). Tested: the
  proposed code and test change (evidence fix-check/) passes: `go test ./es/admission/ -run 'TestReserved|TestOrdinary|TestEmptyEnvironment|TestCaller|TestDeclared|TestEnvironmentRefusal|TestOperationalRetained'` ok, and `go test . -run 'TestCallerDeclaration|TestLifecycleContract'` ok, with the contract unchanged (the docs test requires only that the contract name no unreserved key and every prefix).
Uncertainty: which C library and locales the static-script image holds (one docker run on the box would
  settle it). Not needed for the fix.
Patch defect or pre-existing issue: patch defect in the repair (the test and its claim are new in
  a0e8158); the key itself was open before the PR too.
```

```text
AUDIT FINDING R2
Type / Severity: test/doc/artifact gap (incomplete source attribution, the subject of A1) / low
Current contract: .docs/execution_lifecycle/contracts.md section 5
Path and line (9c06790): .docs/execution_lifecycle/contracts.md:520; es/admission/service.go:128-131;
  caller_declaration_test.go:201-202; the PR body ("Reserved keys are a backstop")
Evidence: the contract says "the entries sudo's development branch adds to that table after 1.9.16p2
  (read on 2026-11-26): _JAVA_OPTIONS, CLASSPATH, PYTHONSTARTUP, NODE_OPTIONS, NODE_PATH, GIT_SSH_COMMAND
  and GIT_CONFIG_*." The diff of the two initial_badenv_table copies (sudo SUDO_1_9_16p2 env.c SHA-256
  64d72a55…, main e5145d71…, both fetched again here) shows eight additions; the eighth is GCONV_PATH.
  Writer report 22 knows this ("GCONV_PATH is also added there and is reserved through glibc's list") but
  the docs and comments do not say it. Audit 21's own A1 text also listed seven.
Impact: none on behavior (GCONV_PATH is reserved through glibc's list, service.go:104). A reader who
  checks the list against sudo finds one more entry than the contract names, in the sentence A1 was about.
Required correction: add "and GCONV_PATH, which glibc's list above already holds" (or similar) in the
  contract, the service.go comment, and the PR body.
Patch defect or pre-existing issue: patch defect (the enumeration is new in 0626d9c).
```

## Observations (no correction required by this re-check)

- **O1. The repository's own runbook declares a TLS-skip switch of the kind the repair reserves.** The repair reserves `WORKLOAD_VAULT_INSECURE_SKIP_VERIFY` because "the repository's own Vault login code reads" it (contract, single-keys bullet). The reference workload in `.runbooks/execution/Governed Execution ES Submit Runtime Identity Reference Workload.md:161-165` (and its copy on Archived-Runbooks `main` 8d99aa0, line 168) declares `REFERENCE_VAULT_INSECURE_SKIP_VERIFY`, which `.examples/runtime_identity_reference/entrypoint:146-153` reads to set `ssl.CERT_NONE` on its Vault connection; it also declares `REFERENCE_IDENTITY_URL`, where the workload fetches the identity JWT it logs in with. So any admitted caller of that artifact can turn off the TLS check of the workload's Vault login. The runbook sends neither switch, and the declaration is the publisher's deliberate choice, so the backstop is not the right tool by its own definition; red-team 19 did not list it. Pre-existing, outside this delta. Writer report 22's inventory of declared keys ("`APP_MODE`, `API_URL`, `ALLOWED_ENV`, `WORKLOAD_VAULT_SECRET_PATH`") misses these three; none is reserved by the repair, so its compatibility conclusion stands. Recommendation for the coordinator: decide whether the reference workload should declare the switch at all (drop it from both runbook copies, or reserve it too).
- **O2. `TEXTDOMAIN` and the musl locale path.** Outside the seven keys: `TEXTDOMAIN` is covered in R1. `MUSL_LOCPATH` (musl's locale directory, the musl counterpart of `LOCPATH`) is not reserved; Inference: musl reads only libc message translations from it, used as text, so I do not raise it. Noted so a later list change can decide.
- **O3. Writer report 22's time stamp.** It says "about 10:25 PM Eastern (2026-11-27 03:25Z)"; the file was written at 03:00:52Z and the commits are at 02:51Z. Report-only; no target value depends on it.

## Validation

All test runs as an unprivileged user `ci` (uid 1500, gid 1600), `umask 022`, `env -i`, Go 1.26.5 (`GOTOOLCHAIN=local`, `GOPROXY=off` after `go mod download all`, `go.sum` restored), one clone per tree made from a bundle. Command: `go test -json -count=1 -timeout 60m ./...`.

| Run | 9c06790 (head) | a5861b7 (base) | Compared |
| --- | --- | --- | --- |
| Full suite (first run; the container's proxy variables were in the environment) | 1830 pass / 87 skip / 45 fail | 1812 / 87 / 45 | same 45 failing names; 18 new tests, all pass; none gone; no status change |
| `./es/app/ ./scripts/` again with no proxy variable | 580 / 71 / 34 | 579 / 71 / 34 | same 34 failing names; the extra pass is the PR's `TestSubmitRefusesAMountTheSignedArtifactDoesNotDeclare` |

The proxy variables made 8 more curl-based operator-script tests in `es/app` fail on both trees (they reach local `*.internal` test servers through the proxy), so the second run replaces those two packages. Combined, the head has 37 environment-only failures, all failing the same way on the base: 3 old-binary probes in `es/admission/internal/reliablesubmit`, 2 in `es/app` (`TestLinuxSetupBootstrapFinishesWithItsSavedSecret`, `TestNomadACLToolRetriesABootstrapThatNeverTookEffect`, the same two audit 21 saw) and 32 Remote Alpha tests in `scripts`. Audit 21 saw 9 in `scripts`; Guess: this container lacks host tools or paths its fixtures need. The names-equal-to-base conclusion is what matters for a delta, and it holds. The 18 new tests are the 16 audit 21 listed plus `TestReservedFamiliesCoverTheKeysTheRedTeamFoundOpen` and `TestOperationalRetainedRequestEnvIsJudgedByTheSignedDeclaration`. The root package passes in full on the head (including #68's `TestServiceLayout` and `TestAuthorityOrderIsStatedOnlyInAgents`). Lists: `tests/`.

**Red-team 19 probes at `9c06790`** (ran, `outputs/rt19-probes-at-9c06790.txt`): all eight pass; the backstop probe now reports `reserved=100 admitted when declared=7`.

**Mutants of the repair** (ran; targeted `-run` sets; definitions `mutants/mutants.py.txt`, diffs and logs in `mutants/`):

| ID | Change | Result |
| --- | --- | --- |
| R01 | retained-request check returns true (red-team MN) | killed: `TestOperationalRetainedRequestEnvIsJudgedByTheSignedDeclaration` |
| R02 | prefix `XDG_` dropped | killed: `TestReservedFamiliesCoverTheKeysTheRedTeamFoundOpen`, `TestReservedEnvironmentKeySetIsPinned`, `TestReservedEnvironmentKeysAreRefusedEvenWhenTheArtifactDeclaresThem` |
| R03 | key `WORKLOAD_VAULT_INSECURE_SKIP_VERIFY` dropped | killed: the same three |
| R04 | prefix `CURL_` (last in the list) dropped | killed: the same three |
| R05 | old standing-rule sentence restored (A2) | killed: `TestCallerDeclarationRulesAreInTheLifecycleContract` |
| R06 | old "module paths and option keys of …" sentence restored | killed: `TestCallerDeclarationRulesAreInTheLifecycleContract` |
| R07 | contract stops naming the prefix `CURL_` | killed: `TestLifecycleContractNamesOnlyReservedKeysTheCodeReserves` |
| R08 | contract names `GOMEMLIMIT` as reserved | killed: `TestLifecycleContractNamesOnlyReservedKeysTheCodeReserves` |
| R09 | contract credits only `_JAVA_OPTIONS` and `CLASSPATH` to later sudo again (A1) | survived: no test guards the attribution (not asked for) |
| R10 | retained path refuses every caller key (the opposite mistake) | killed: 42 tests of the `Operational` set, among them `TestOperationalRetainedAdmissionEvidenceV2`, `TestOperationalOriginalBindingAndCustody` and the RT74-2 test's control case |

## CI

Checked through the GitHub connector at 03:33Z: both required checks on `9c06790` were still running, "build, vet and test" (run 45931533404, job 140285058935, started 02:59:44Z) and "test on macOS" (run 45931533282, job 140285058666, started 03:06:34Z). Both are listed as check runs of the PR's head commit, and the Linux run's details name head SHA `9c06790`. On the previous head `f8bc3df`, audit 21 found both green. I will add the result as `23a-pr74-recheck-opus-ci.md` when the runs finish; the verdict does not depend on it (BLOCK either way), but the merge gate does.

## Coverage this environment could not give

- No Docker daemon, Nomad, Vault or SPIRE: the es/app mount and network flows skip here; CI runs them.
- No container image was inspected. Whether any granted image has a non-C locale and bash scripts using `$"..."` (R1's reach) is Unknown for the static-script image.
- The command-substitution step of R1 is Inference from the bash manual; I showed only parameter expansion of a translated string.

## Evidence

`23-pr74-recheck-opus-evidence/`: `provenance/` (both manifests, commands), `textdomain-probe/` (`run.sh.txt`, `mkmo.py.txt`, `output.txt`), `upstream/` (fetched sources and their SHA-256), `tests/` (failing-name lists and per-test results for head and base, runner), `outputs/rt19-probes-at-9c06790.txt`, `mutants/`, `fix-check/`, and `SHA256SUMS`.

STATUS: READY (re-check delivered with verdict BLOCK; CI addendum to follow when GitHub finishes)
