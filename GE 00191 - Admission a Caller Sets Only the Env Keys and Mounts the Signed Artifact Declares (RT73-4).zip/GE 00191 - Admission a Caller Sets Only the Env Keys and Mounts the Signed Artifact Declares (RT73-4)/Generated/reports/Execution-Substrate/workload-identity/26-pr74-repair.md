# Writer report 26: ES PR #74 repair after re-check 25

Date: 2026-11-27, about 12:25 AM Eastern (05:25Z). Writer: the "Stop callers injecting code into runs" thread, which wrote #74 (reports 15, 22 and 24).

## Target

| Item | Value |
| --- | --- |
| PR | evo-agi/Execution-Substrate #74, branch `claude/project-thread-ef7st5` |
| Base | `trunk_dev` at `0b9278ca74404b46b5e9f0e1701874b52687f5e8` (#69), unchanged since report 24 |
| Head | `956991c1b78b5a21a072ddf463a6327249077031`, tree `5e03010aec5bd24661f2a5de70d974e137a719fd` (pushed; `git ls-remote` equal) |
| Commits since re-checked `e0b5c89` | `bba0248` F1, N1 and a runbook guard (O1); `956991c` docs test pins the `PKG_CONFIG` family sentence. No merge (base unchanged) |
| Delta to re-check | `git diff e0b5c89 956991c`: 4 files, +121 / -36, `\| sha256sum` = `86c2668caff738f3ee16d0301d291b8ab23accfcca23525af3cec4fb21f362af` |
| `git diff 0b9278c 956991c` | 31 files, +1634 / -77, sha256 `c4fa6aaf1806863b323ea5005e34291bd28340f34e858c588bdfe5c870880d82` |
| Canonical manifest (O4) | recipe v2 (source SHA-256 `c08597e2…a3ca`, `sha256sum -c` OK), fresh clone of the pushed branch, reset `--mixed` to `origin/trunk_dev` 0b9278c; run twice, `cmp` identical. `manifest_sha256` `0e8c5d6256ba7e506c04c0b325218707689f11a252616311f24aa67b5fbf547b`, 31 files, `textual_diff_sha256` `b04f27a9b8f309a1a2a6348d6d30fc68431662932c2f740954a995b76562bfd4`. File: `24-pr74-repair-evidence/manifest-v2-956991c-on-0b9278c.json` |

## Delta

Product code: `es/admission/service.go`, list entries and comments only.

| Item | Change |
| --- | --- |
| F1 (re-check 25, both) | Reserved by name: `FC` and `GCCGOTOOLDIR` (go help environment, beside `CC`, `CXX`, `GCCGO`), and gcc's `LPATH` and `OBJCPLUS_INCLUDE_PATH`. `PKG_CONFIG` is reserved as a family (prefix `PKG_CONFIG`), so pkg-config's search keys `PKG_CONFIG_PATH`, `PKG_CONFIG_LIBDIR`, `PKG_CONFIG_SYSROOT_DIR` go with the program. Both re-checks raised those keys as an observation (Opus O2, Sonnet O2): they choose the `.pc` files that give a cgo build `-I`, `-L` and `-l` paths, which is what `CPATH` and `LIBRARY_PATH` (reserved) do. Pin test, refusal table (`FC`, `PKG_CONFIG`, `pkg_config_path`, `PKG_CONFIG_LIBDIR`, `GCCGOTOOLDIR`, `LPATH`, `OBJCPLUS_INCLUDE_PATH`), contract and code comment updated. The contract's Go sentence now ends "`FC`, `PKG_CONFIG` and others, every such key `go help environment` lists in Go 1.26.5". The gcc sentence ends "every such key the GCC 14.2 manual lists, and the two that gcc's driver and preprocessor read and the manual leaves out, `LPATH` and `OBJCPLUS_INCLUDE_PATH`". Those are the two sources the re-checks enumerated. |
| Sonnet O1 (writer to decide) | Reserved `DEPENDENCIES_OUTPUT` and `SUNPRO_DEPENDENCIES`. Their "file target" form makes the preprocessor write a rule line holding a target string the caller chooses to a path the caller chooses (cppenv.texi). Inference: written into a file that a shell later sources, a target such as `$(…)` would run. The contract's gcc category now includes "a file it writes with text the caller chooses". |
| N1 (re-check 25 Opus) | The `LANG`/`LC_ALL` sentence moved after "The boundary is the allowlist in the next rule.", so "It is a backstop" follows the list again. That sentence now opens "Some keys of these kinds stay open on purpose". It also names `GOOS`, `GOARCH`, the other target keys, `GO111MODULE` and `GOFIPS140` (they choose only among code the artifact or the toolchain already holds; Opus O3), and gcc's `SOURCE_DATE_EPOCH` and `GCC_EXTRA_DIAGNOSTIC_OUTPUT` (a timestamp and diagnostic text). `TestOrdinaryEnvironmentKeysAreNotReserved` pins those six as open. |
| Opus O1, the runbook text no test read | New `TestRunbooksAndExamplesDeclareNoReservedEnvironmentKey` (root package). It reads every `"environment_variables": [...]` list in `.runbooks`, `.examples`, `.docs` and `scripts`. It fails if a list declares a key that `es/admission/service.go` reserves (keys, prefixes and suffixes read from its AST, as the contract test does). It also fails if it cannot find the known declarations of `APP_MODE`, `WORKLOAD_VAULT_SECRET_PATH` and `REFERENCE_IDENTITY_URL`, so a broken scan cannot pass. The matcher is now shared with `TestLifecycleContractNamesOnlyReservedKeysTheCodeReserves`. |
| Docs test | Required phrases added: the `PKG_CONFIG` family sentence. |

## Validation (ran, as root in this container)

- `go vet` on root and `es/admission`: clean. `gofmt -l` on the changed Go files: empty.
- Targeted `es/admission` tests and the root package: ok on 956991c.
- Full suite on bba0248: 1831 pass, 81 skip, 55 fail; the one extra pass is the new guard; the 55 failing names equal e0b5c89's name for name (`24-pr74-repair-evidence/failing-top-level-bba0248.txt`), all environment-only. 956991c changes only the root docs test, which passes.
- Mutants, 12 of 12 killed (`24-pr74-repair-evidence/mutants-log-bba0248.txt`):

  | Mutant | Killed by |
  | --- | --- |
  | T1–T6: `FC`, the `PKG_CONFIG` prefix, `GCCGOTOOLDIR`, `LPATH`, `OBJCPLUS_INCLUDE_PATH` or `DEPENDENCIES_OUTPUT` dropped | the pin and refusal tests (and the contract test where the contract names the key) |
  | T7: the contract stops describing `PKG_CONFIG` as a family | survived on bba0248; killed on 956991c by the new required phrase |
  | T8: the reference runbook declares `REFERENCE_VAULT_INSECURE_SKIP_VERIFY` again (re-check 25's surviving K12) | the new guard |
  | T9: an example declares `LD_PRELOAD` | the new guard |
  | T10: the contract names `GOOS` as reserved | the contract test |
  | T11: the guard's regex is broken so the scan finds nothing | the guard's own self-check |
- CI on e0b5c89: green on both required checks. CI on 956991c: both required checks green ("test on macOS" 05:32Z, "build, vet and test" 05:50Z).

## Security widening

None. Every change refuses more caller keys or adds a test. The cost is that a publisher can no longer let callers set these keys. No artifact in the project declares any of them; the new guard now checks the repository's own declarations.

## Open, for the coordinator

- Unchanged from report 24:
  - The Archived-Runbooks copy should be refreshed after the merge. Re-check 25 Sonnet O3 notes there is no machine-enforced trigger for that; it is the coordinator's call.
  - Red-team 19's design options (AGS refusing to sign a reserved key, which would make the new runbook guard redundant at publish time; caller mounts without execute permission).
  - Audit 21 O2.
  - Unbounded argv.
- Still open and not asked for: `MUSL_LOCPATH`, and clang's own keys such as `CCC_OVERRIDE_OPTIONS`.

## Confidence

- **Provenance: high.** The manifest was built twice and both runs are identical; the pushed head equals the local one.
- **Validation: high** for everything this container can run. The Docker and Nomad flows rely on CI.
- **Implementation: high.** The change is list entries, comments, a docs sentence move and tests; admission logic is unchanged since audit 21.
- **Not run:** the `DEPENDENCIES_OUTPUT` reason is from the GCC manual, and no shell-sourcing demonstration was run, on purpose.
