# Narrow re-check 30 (Sonnet): ES PR #74 at 4d7ed6d, after re-check 29's nit N29-1 and the merge of #75: ACCEPT (the four new cases kill their mutants, the merge leaves the PR's patch unchanged, CI is green on 4d7ed6d)

Date: 2026-11-27, about 4:05 AM Eastern (09:05Z; start 08:14Z). Auditor: thread "Sonnet delta check of PR 74". Model: `[model withheld]`. Model-evaluation trial, category R-S security PR (narrow re-check, small: a 7-line test delta, a clean merge and CI; I first labelled it R-M, and the log row uses R-S, as the pair's does), a real check, with the usual model run blind on the same head and scope. This thread has not written, repaired or audited #74 before.

Disclosure on blindness. I did not open the Opus report or evidence for this scope. A listing of the report folder at the start showed the names `29-pr74-recheck-opus.md`, `29-pr74-recheck-opus-evidence` and the writer's `30-pr74-repair.md`; no `30-pr74-recheck-opus*` name was listed, and I opened none of the Opus files. When I delivered this report, the same folder listing (names only) showed `30-pr74-recheck-opus.md` and `30-pr74-recheck-opus-evidence`; I did not open either, and my verdict was settled before I looked at that listing. Project memory recalled by the session held notes on re-checks 23, 25, 27, 28 and 29 of this PR, including that the Opus re-check 29 of 10a3b58 ended ACCEPT; that is the previous round, not this scope, and no finding below comes from it. I read `model-evaluation/sonnet-trial.md` lines 1-33 and 66 to the end (rules and routing); the second range, begun by a line count that had moved, showed one log row (an Opus run on #67, not this PR). I did not read the log's other rows before finishing. When I appended my row after the report was final, the log's last row, the Opus run on this scope, came into view (its first 260 characters: R-S, ACCEPT, no findings, GM14, GM26, GM22 and GM24 killed); my verdict, findings and evidence were settled before that and I changed none of them. As the brief asked, I read my own re-check 29 (the source of N29-1) and writer report 30.

Source labels: "ran" means I ran it in this container on the commit named. "Read" means I read code or a document and did not run it. "Inference:" and "Guess:" mark the rest.

```text
INDEPENDENT AUDIT REPORT (narrow re-check of a repair, protocol §14)
Repository / Audit target:
  evo-agi/Execution-Substrate PR #74, branch claude/project-thread-ef7st5
  base trunk_dev be20ffc8a5f82a35c4ce9064594a081f419c1ef5 (#75)
  topic commit 4d7ed6d8897fda4d318baf845c7b6c150e336ef5, tree fb6432494605a83a57d0347784c5d60681fb88c6
  recipe governed-execution.audit-patch-manifest.v2, source SHA-256
    c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (sha256sum -c OK before the opening and the closing runs)
  canonical-manifest SHA-256 89004ac6502a9c9cf87f738126875a51df387250d25c0a9f73793fbc55ae3686, 31 paths,
    textual_diff_sha256 61fad89e36a514e0ccee532077933f0b974891b6cad7015970e17b9392ebe08e
  Scope: (1) git diff 10a3b58 aa2b6a5 (1 file, +7); (2) the merge 4d7ed6d (aa2b6a5 + trunk_dev be20ffc, #75);
    (3) CI on 4d7ed6d.
Audit posture: read-only, parent only, no subagents. Nothing pushed, nothing posted on GitHub, no box, no merge.
  Tests and mutants ran in clones owned by an unprivileged user (uid 1500); the provenance clone ran no tests.
Provenance reproduction: reproduced twice, identical; equal to the writer's manifest file byte for byte; closing runs
  equal the opening; pushed tip, PR ref and trunk_dev unchanged at the start, at the close and at 09:03Z.
Findings: none. 3 observations (O1 to O3). No finding against the delta or the merge.
Validation assessment: whole suite on exact bytes for head and base as an unprivileged user: the same 45 failing
  names (14 top-level) on both, no status change in 10453 common names; the PR's 20 own top-level tests pass.
CI on 4d7ed6d: both required checks green ("test on macOS" 08:47:58Z, "build, vet and test" 08:59:29Z; see "CI").
Sensitive-material handling: no secrets, keys, tokens, env files, SQLite or TLS/SPIFFE/Vault material read.
Remaining uncertainty and stop conditions: none that blocks the verdict. I did not re-read the PR's merge state after the checks passed (it read `blocked` while they ran); whether the branch rules need anything beyond the two checks and the gate is Unknown.
Confidence: provenance high / validation high for what runs here (Docker and Nomad flows run only in CI) /
  implementation high for the delta (four test cases, no product code).
Effect status: repair, commit, push, PR, merge not performed.
Report delivery: /mnt/project-files/reports/Execution-Substrate/workload-identity/30-pr74-recheck-sonnet.md
  (SHA-256 in the delivering message), evidence in 30-pr74-recheck-sonnet-evidence/ (SHA256SUMS inside).
Final verdict: ACCEPT
```

**In plain words.** The four new table cases do what the writer says: each one is the only thing that fails when its mutant is planted, and without it the mutant passes every test. The merge of #75 left the PR's own patch byte for byte the same, and the merge commit holds nothing but the clean merge. CI is green on the exact head, so the merge gate can proceed on this check (the coordinator decides; nothing here is a merge).

## Provenance (ran)

| Step | Result |
|---|---|
| Recipe bytes | `sha256sum -c` OK (`c08597e2…a3ca`) on the shared file and on the copy that ran, before the opening and the closing runs (`provenance/recipe-hash.txt`) |
| Pushed tip | `git ls-remote` at the start (08:15Z), at the close (08:38Z) and after CI finished (09:03Z): `refs/heads/claude/project-thread-ef7st5` and `refs/pull/74/head` = `4d7ed6d`, `trunk_dev` = `be20ffc`. The PR API shows head `4d7ed6d`, base `be20ffc`, 15 commits, 31 files, +1811/-77 |
| Base ancestry | `be20ffc` is an ancestor of `4d7ed6d`; chain `10a3b58` → `aa2b6a5` (one commit) → merge `4d7ed6d` (parents `aa2b6a5`, `be20ffc`) (`merge/merge-checks.txt`) |
| Manifest | fresh clone of GitHub, branch checked out at the tip (clean), `git reset --mixed be20ffc`, upstream `origin/trunk_dev`; two runs, `cmp` identical, `manifest_sha256` `89004ac6…3686`; **equal byte for byte** to the writer's `24-pr74-repair-evidence/manifest-v2-4d7ed6d-on-be20ffc.json`; 31 files; `textual_diff_sha256` `61fad89e…be08e` equals the writer's |
| Closing run | the clone had the opening state; two runs identical and equal to the opening (`close-{1,2}.json` = `open-{1,2}.json`) |
| Digests | `git diff 10a3b58 aa2b6a5`: `40b2e10a…a87b` (equals writer report 30). `git diff be20ffc 4d7ed6d`: 31 files, +1811/-77, `80f0c38d…bb4` (equals writer report 30) |

## 1. The delta 10a3b58..aa2b6a5 (read, then ran)

One file, `caller_declaration_docs_contract_test.go`, **7 insertions, 0 deletions**: a 3-line comment and four table cases in `TestEnvironmentDeclarationScanReadsEachSpelling` (`merge/delta-10a3b58-aa2b6a5.diff`). The file is byte-identical at `aa2b6a5` and `4d7ed6d`, so the merge did not touch it. `gofmt -l` on it is empty. The table now has 26 cases (counted), as the PR body says. The blob holds the escapes as backslash text, ASCII only (checked with a byte count: `environment` + backslash-u005F once, `LD_` + backslash-x50 twice, and so on), so nothing was rewritten by a tool.

| Case (name in the table) | Input | Expects | Branch it reaches |
|---|---|---|---|
| C1 `Python named escape, single-quoted` | `{'environment_variables': ['…N{LATIN CAPITAL LETTER L}D_PRELOAD']}` | a problem | `decodeDeclaredEnvironmentEntry`, single-quoted fallback `!strings.Contains(match[2], backslash)` (GM14) |
| C2 `key written with an upper-case escape` | `{"environment…u005Fvariables": ["LD_PRELOAD"]}` | a problem | `jsonUnicodeEscape` `[0-9A-Fa-f]{4}`, upper-case hex in the pre-pass (GM26) |
| C3 `Go escape, double-quoted` | `"environment_variables": ["LD_…x50RELOAD"]` | entries `LD_PRELOAD`, no problem | double-quoted `strconv.Unquote` (GM22) |
| C4 `escaped quote, single-quoted` | `{'environment_variables': ['A…'B']}` | entries `A'B`, no problem | single-quoted `…'` → `'` replacement (GM24) |

**Mutants (ran).** Clone at `4d7ed6d`, targeted set `. -run 'TestCallerDeclaration|TestLifecycleContract|TestRunbooksAndExamples|TestEnvironmentDeclarationScan'`, each mutant on a clean checkout, a build error would be reported as BUILDERR (none occurred). Four configurations per mutant: all four cases; the mutant's own case deleted; all four deleted (this is the table at 10a3b58 plus the same code); only the mutant's own case kept. 27 runs (`mutants/mutants30-table.tsv`, runner `mutants/mutants30.py`):

| Mutant | all four cases | own case deleted | all four deleted | only own case |
|---|---|---|---|---|
| control (no edit) | pass | | pass | |
| GM14 single-quoted fallback always accepts | **killed**, by C1 only | survives | survives | **killed**, by C1 |
| GM26 hex pre-pass lower-case only | **killed**, by C2 only | survives | survives | **killed**, by C2 |
| GM22 double-quoted Go-escape branch off | **killed**, by C3 only | survives | survives | **killed**, by C3 |
| GM24 single-quoted `…'` replacement off | **killed**, by C4 only | survives | survives | **killed**, by C4 |
| Z6 (mine) the replacement deletes the quote instead of unescaping it | **killed**, by C4 only | survives | survives | **killed**, by C4 |
| Z7 (mine) the Go-escape branch returns the raw text | **killed**, by C3 only | survives | survives | **killed**, by C3 |
| GM27 hex pre-pass takes 3 or 4 digits | survives | | | |

So each case is needed (the other three do not cover it), each is enough alone, and each fails for the reason it should: GM14 and GM26 report `problems [], want a problem: true`; GM22 and GM24 report an undecodable entry and no entries (`mutants/mut30-GM*-all.log`). Z6 and Z7 show that the `entries` comparison of C3 and C4 has power of its own, not only the problem check. GM27 survives as in re-check 29 (it takes a three-digit escape no decoder accepts; harmless, not a branch).

**Sweep of the whole earlier scanner set (ran).** Re-check 29's runner, re-run on `4d7ed6d`: 29 runnable mutants, **24 killed, 5 survive** (re-check 29 at 10a3b58: 20 killed, 9 survived). The four that flipped are GM14, GM22, GM24 and GM26. The five survivors are GM27 and the four O1 mutants of re-check 29 (GM17, GM17b, GM20, GM21: the per-root file check, the per-root declaration requirement and the wiring that turns a scanner problem into a failure; they live in the walk, outside `scanEnvironmentDeclarations`), all unchanged from 29 (`mutants/sweep-29-GM-set-at-4d7ed6d.log`; GM30 is the anchor miss that 29 already dropped). The PR body's "every scanner branch that re-checks 28 and 29 weakened" is therefore true of the scanner and its decoder; it does not cover the walk wiring, and it does not claim to.

## 2. The merge 4d7ed6d (ran)

| Check | Result |
|---|---|
| The PR's own patch (`git patch-id --stable`) | `git diff 0b9278c aa2b6a5` (old base) and `git diff be20ffc 4d7ed6d` (new base): both `63b7455bc01edd57de3445dfc2183b1b9b727cdd`. Both are 31 files, +1811/-77; the raw diff digests differ (`39f67afe…` and `80f0c38d…`) because the blob ids on the index lines and the hunk offsets of those two shared files differ, as expected |
| What the merge brought in | `git diff aa2b6a5 4d7ed6d` and `git diff 0b9278c be20ffc` (#75's own change): both `3c24d2c5fb5bd0a9042e9b3cb3a07b9994264bf9`, the same 39 files |
| No hand edit in the merge commit | `git merge-tree --write-tree aa2b6a5 be20ffc` exits 0 and writes tree `fb6432494605a83a57d0347784c5d60681fb88c6`, which is exactly the tree of `4d7ed6d`; `git show --cc 4d7ed6d` is empty |
| Per-file bytes against re-check 29's manifest (10a3b58 on 0b9278c) | of the 31 manifest paths, 28 have the same SHA-256 as at 10a3b58; the three that differ are the delta's test file and the two files #75 also edits (`.docs/system_overview/contracts.md`, `PLANS.md`); no path was added or lost (read: the two manifests) |
| Overlap with #75 | `.docs/system_overview/contracts.md` and `PLANS.md` only; the textual merge is clean. #75 adds no line that mentions `environment_variables` (0 of its added lines) and changes no file under `es/admission` except the new test `service_direct_test.go` (read: `git diff --stat 0b9278c be20ffc`) |
| The guard and the pins on the merged tree | the root package passes in full on `4d7ed6d` (it is not among the three failing packages), so `TestRunbooksAndExamplesDeclareNoReservedEnvironmentKey`, `TestEnvironmentDeclarationScanReadsEachSpelling`, `TestCallerDeclarationRulesAreInTheLifecycleContract` and `TestLifecycleContractNamesOnlyReservedKeysTheCodeReserves` pass; `es/admission` passes too, with `TestReservedEnvironmentKeySetIsPinned` |

## 3. Validation (ran)

All runs as an unprivileged user (uid 1500), `umask 022`, `env -i`, Go 1.26.5 (`GOTOOLCHAIN=local`, `GOPROXY=off`), one clone per tree, `go vet . ./es/... ./scripts/... ./internal/... ./ars/... ./ags/... ./egs/...` then `go test -count=1 -timeout 30m -json ./...`, one tree at a time (`tests/`). `git status --porcelain` before and after each run: empty.

| Tree | vet | Top-level pass / skip / fail | Compared with base |
|---|---|---|---|
| base `be20ffc` | exit 0 | 1871 / 88 / 14 | |
| head `4d7ed6d` | exit 0 | 1891 / 88 / 14 | the same 45 failing names (the same 14 top-level, with subtests, and the same names as re-check 29 listed at 10a3b58); 166 names only at the head, all pass (20 top-level: the PR's own tests); 43 only at the base, all pass (the randomly named rounds of three PR12 SIGKILL tests); 10453 names in common, no status change |

The 14 failing top-level tests are the three old-binary probes in `es/admission/internal/reliablesubmit`, two in `es/app` and nine in `scripts` (`tests/head-fail-top.txt`); they fail the same way on the base. The PR body's count (55 failing, run as root on 3e5fc49) is a different environment and a commit I could not check (not on the remote); the comparison that matters, head against base by name, is equal in both.

## 4. CI on 4d7ed6d (read)

Read through the GitHub connector, polled until both finished. `4d7ed6d`: "test on macOS" (run 45963874991, job 140387804966, started 08:16:47Z) completed 08:47:58Z (31m11s), conclusion success; "build, vet and test" (run 45963874995, job 140387805041, started 08:12:22Z) completed 08:59:29Z (47m07s), conclusion success. The connector lists exactly those two checks, the two the project requires. The PR head read `4d7ed6d` at the start, at the close and after the checks finished (`provenance/ls-remote-final.txt`, 09:03Z). I read the results and did not read the job logs: nothing failed. Record: `ci/check-runs-4d7ed6d.txt`.

## Observations (no correction required)

- **O1. Writer report 30 is unfinished.** Its Validation section still holds the template words `FULLSUITE` and `CISTATUS` where the full-suite result and the CI status on 4d7ed6d go, and the PR body says the full run on 4d7ed6d "is in progress, and writer report 30 will give its result". The facts are in sections 3 and 4 above; the writer should fill them in, or the coordinator can take them from here. A report is projection, not repo.
- **O2. The scope of "every scanner branch".** True for the scanner and its decoder (section 1); the four walk survivors (re-check 29 O1) and GM27 remain, unchanged. Nothing new.
- **O3. Items outside this delta stay as re-check 29 left them:** the open driver-internal keys (`WIND_BASE`, `GCC_OFFLOAD_OMP_REQUIRES_FILE`), AGS signing a reserved key, caller mounts without the execute bit, unbounded `argv`, and Archived-Runbooks #30's note commit after #74 merges.

## Coverage this environment could not give

- No Docker, Nomad, Vault or SPIRE here: the `es/app` flows that need them skip or fail the same on both trees; CI is their reference. No macOS run of my own.
- I did not re-run the Archived-Runbooks check script: neither the delta nor #75 touches the reference-workload runbook (`.runbooks/execution/Governed Execution ES Submit Runtime Identity Reference Workload.md` has the same SHA-256, `f4b27e8a…`, in this manifest as in re-check 29's — read from the two manifests).
- Opus's work on this scope: not read, by design.

## For the writer, in one list

1. Fill the two placeholders in writer report 30 (O1) and refresh the PR body's "in progress" sentence.
2. After merging: Archived-Runbooks #30's note must be pointed at the `trunk_dev` commit by hand (unchanged from re-check 29).

## Trial log row (for the coordinator to copy; also appended to the trial log)

| Date | Category | PR @ head | Scope | Model | Verdict | Findings | Later outcome |
|---|---|---|---|---|---|---|---|
| 2026-11-27 | R-S (security PR, test-only delta + merge) | ES #74 @ 4d7ed6d | narrow re-check of 10a3b58..aa2b6a5 and the merge of #75, CI included (real) | [model withheld] | ACCEPT | none. The four new table cases kill GM14, GM26, GM22 and GM24, each case alone is enough and each is needed (own mutants Z6 and Z7 too). Sweep of re-check 29's scanner mutants on the head: 24 killed, 5 survive (GM27 and the four walk-wiring ones, unchanged). Merge: patch-id of the PR's patch equal on both bases (63b7455b), merge-tree reproduces the merge tree, combined diff empty, manifest equal to the writer's byte for byte. Suite: same 45 failing names as the base (1891/88/14 against 1871/88/14), no status change in 10453 names. CI green on both required checks (08:47:58Z, 08:59:29Z). 3 observations (writer report 30 still holds the template words FULLSUITE and CISTATUS) | not blind to the previous round (project memory showed Opus re-check 29 of 10a3b58 ended ACCEPT); this scope's Opus report not opened (its log row came into view after my verdict was final). Pair: the Opus run on the same head and scope, also ACCEPT. Report workload-identity/30-pr74-recheck-sonnet.md |

## Evidence

`30-pr74-recheck-sonnet-evidence/`: `provenance/` (opening and closing manifests, recipe hash, `ls-remote` at the start, the close and the end), `merge/` (the delta diff, the patch-id, merge-tree and combined-diff checks), `mutants/` (runner, the 27-run table, every log, the sweep of re-check 29's set), `tests/` (runner scripts, failing-name lists, names only at one tree, vet output, status files, gzipped `go test -json` of both runs), `ci/` (check runs), `README.md`, `SHA256SUMS`.

STATUS: READY (re-check delivered: ACCEPT, no findings; CI green on both required checks at 4d7ed6d; the merge gate and the writer's report 30 placeholders remain with the coordinator and the writer)
