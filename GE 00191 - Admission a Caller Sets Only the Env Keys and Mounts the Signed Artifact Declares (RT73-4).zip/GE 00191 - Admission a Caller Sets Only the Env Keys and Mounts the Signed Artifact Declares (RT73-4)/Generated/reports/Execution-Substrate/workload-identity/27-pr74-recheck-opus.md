# Re-check 27 (Opus): ES PR #74 at 956991c: BLOCK (one low finding, two nits; F1, N1 and the runbook guard are fixed, and both extras hold)

Date: 2026-11-27, about 1:10 AM Eastern (06:10Z). Thread: "Re-check caller env injection PR" (it re-checked #73 earlier tonight as report 21; it has not written, audited or re-checked #74 before). Fresh and read-only. Blind pair in the model-evaluation trial (category R-S): I did not read the Sonnet report for this round or its evidence, and I messaged no thread. Model: [model withheld].

Source labels: "ran" means I ran it in this container on the commit named; "read" means I read the code, document or upstream source and did not run it; "CI" means read from GitHub; "Inference:" marks my reasoning.

```text
INDEPENDENT AUDIT REPORT (narrow re-check of a repair, protocol §14)
Repository / Audit target:
  evo-agi/Execution-Substrate PR #74, branch claude/project-thread-ef7st5
  base 0b9278ca74404b46b5e9f0e1701874b52687f5e8 (trunk_dev, #69)
  topic commit 956991c1b78b5a21a072ddf463a6327249077031, tree 5e03010aec5bd24661f2a5de70d974e137a719fd
  recipe governed-execution.audit-patch-manifest.v2, source SHA-256
    c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (sha256sum -c OK before each run)
  canonical-manifest SHA-256 0e8c5d6256ba7e506c04c0b325218707689f11a252616311f24aa67b5fbf547b, 31 paths,
    textual_diff_sha256 b04f27a9b8f309a1a2a6348d6d30fc68431662932c2f740954a995b76562bfd4
  Scope (coordinator): git diff e0b5c89 956991c (4 files): re-check 25's F1 (5 keys), N1 and the
    runbook observation (O1), plus the extras: the PKG_CONFIG family and gcc's dependency-file keys.
    Measured only against the two sources the contract names (go help environment, Go 1.26.5; the
    GCC 14.2 manual, plus the gcc driver and preprocessor the new sentence names).
Audit posture: read-only. Parent only, no subagents. Nothing pushed, nothing posted on GitHub, no
  Linux box, no live service. Tests, probes and mutants ran as an unprivileged user (ci, uid 1500)
  in clones made from a bundle, never in the provenance clone.
Provenance reproduction: equal to writer report 26's manifest file, byte for byte; opening and
  closing runs identical (two runs each).
Findings: 1 low (R27-1), 2 nits (N27-1, N27-2). No medium or higher. 4 observations.
Validation assessment: full suite on head and base as an unprivileged user: the same 14 failing
  tests on both (45 counting subtests), 19 tests only at head, all pass. 18 mutants: 14 killed,
  4 survive (1 is N27-1, 3 are contract wording no test is asked to pin). The fixes proposed for
  R27-1 and N27-1 pass the affected tests. CI on 956991c: both required checks green.
Sensitive-material handling: no secrets, keys, tokens, env files, SQLite or TLS/SPIFFE/Vault
  material read into the report or evidence.
Confidence: provenance high / validation high / implementation high for the claimed fixes;
  high that R27-1 is the last gap within the two named sources (I enumerated both completely).
Effect status: repair, commit, push, PR, merge not performed.
Report delivery: /mnt/project-files/reports/Execution-Substrate/workload-identity/27-pr74-recheck-opus.md
  (SHA-256 in the delivering message), evidence in 27-pr74-recheck-opus-evidence/ (SHA256SUMS inside).
Final verdict: BLOCK
```

## Why BLOCK, and why the finding is inside the stated limits

Everything the repair claims holds. It blocks on one low finding because the new gcc sentence is not yet true of its own named source. The contract (and the PR body) now say the reserved set holds the gcc keys "that choose the programs it runs, … : every such key the GCC 14.2 manual lists". The GCC 14.2 manual documents two more keys that name a program GCC runs, and both are open:

- `MAKE`, in the `-flto` section: "The environment variable `MAKE` may be used to override the program used."
- `CXX_MODULE_MAPPER`, in the C++ modules section: its `|program` form makes the compiler spawn a program.

I ran both: gcc ran the program each one named (R27-1). The two re-checks 25 measured gcc against the manual's "Environment Variables Affecting GCC" section and the driver's own reads; these two keys sit in other sections and in other GCC programs, so neither re-check could have seen them. To end the rounds on this source, I listed every environment variable the whole manual names (29 `@env` names plus one in plain text) and placed each one below. No further key in the manual falls in the sentence's categories. The coordinator's "the class is closed for those two sources" holds for `go help environment` (checked key by key, below) and holds for the manual once R27-1 is fixed.

The fix is three map entries and the same three names in the pin and refusal tables (tested below). The two nits are a one-word guard fix and a comment reflow.

## Provenance (ran)

| Step | Result |
| --- | --- |
| Recipe bytes | `sha256sum -c` OK (`c08597e2…a3ca`) on the shared file and on the copy that ran, before the opening and the closing runs |
| Pushed tip | `git ls-remote` at 05:13Z and again at 06:04Z: `refs/heads/claude/project-thread-ef7st5` and `refs/pull/74/head` = `956991c`, `trunk_dev` = `0b9278c` |
| Base ancestry | `git merge-base --is-ancestor 0b9278c 956991c`: yes; commits since `e0b5c89`: `bba0248` (parent `e0b5c89`) and `956991c` (parent `bba0248`), no merge |
| Opening manifest | fresh clone of github.com/evo-agi/Execution-Substrate at the branch, `git status` clean, `git reset --mixed 0b9278c`, upstream `origin/trunk_dev` = `0b9278c`; two runs, `cmp` identical, SHA-256 `0e8c5d62…547b`, equal byte for byte to `24-pr74-repair-evidence/manifest-v2-956991c-on-0b9278c.json` |
| Committed blobs | every manifest record equals the blob at `956991c` (SHA-256 and size, 0 differences); every mode `0644`; path set equals `git diff -z --name-only 0b9278c 956991c` (31) |
| Diffs | `git diff e0b5c89 956991c`: 4 files, +121 / -36, `\| sha256sum` `86c2668c…62af`; `git diff 0b9278c 956991c`: 31 files, +1634 / -77, `c4fa6aaf…0d82` (both equal to report 26) |
| Closing run | 06:04Z, same clone, recipe re-verified: two runs identical and equal to the opening manifest |

## What the delta changes (read)

- `es/admission/service.go`: only map entries (`GCCGOTOOLDIR`, `FC` at :297-298; `LPATH`, `OBJCPLUS_INCLUDE_PATH`, `DEPENDENCIES_OUTPUT`, `SUNPRO_DEPENDENCIES` at :307-310), the prefix `PKG_CONFIG` (:381) and comments. `isReservedRuntimeEnvKey` (:1454-1473: trim, ASCII fold, exact keys, prefixes, suffixes) and its one caller (:1229, the caller-key loop) are unchanged, so the wider list still judges only caller keys.
- `es/admission/caller_declaration_test.go`: the pin gains the 8 keys and the prefix; the refusal table gains `FC`, `PKG_CONFIG`, `pkg_config_path`, `PKG_CONFIG_LIBDIR`, `GCCGOTOOLDIR`, `LPATH`, `OBJCPLUS_INCLUDE_PATH`, `DEPENDENCIES_OUTPUT`, `SUNPRO_DEPENDENCIES`; the ordinary list gains `GO111MODULE`, `GOFIPS140`, `SOURCE_DATE_EPOCH`, `GCC_EXTRA_DIAGNOSTIC_OUTPUT`.
- `.docs/execution_lifecycle/contracts.md` (:524-527): the family bullet names `PKG_CONFIG`; the Go and gcc sentences gain the keys and the completeness clauses; the `LANG`/`LC_ALL` sentence moves (N1) into a new "stay open on purpose" passage.
- `caller_declaration_docs_contract_test.go`: the matcher moves into `reservedEnvironmentKeyMatcher` (:139), unchanged; a required phrase for the `PKG_CONFIG` family sentence; the new `TestRunbooksAndExamplesDeclareNoReservedEnvironmentKey` (:206).

## The claimed fixes and the extras

| Item | Verdict | Evidence |
| --- | --- | --- |
| F1 (re-check 25, both): `FC`, `PKG_CONFIG`, `GCCGOTOOLDIR`, `LPATH`, `OBJCPLUS_INCLUDE_PATH` | Fixed | All five reserved (key probe, ran), pinned and refused end to end; dropping any one is killed (M01-M05). |
| `go help environment` (Go 1.26.5) is now closed, as the Go sentence says | Holds | I took every key the help text lists as read from the environment (60, `upstream/go-help-environment-1.26.5.txt`) through the real `isReservedRuntimeEnvKey` (ran, `probes/key-probe-at-956991c.txt`): 45 reserved; 15 open, all target or mode keys (`GOOS`, `GOARCH`, `GO386`, `GOAMD64`, `GOARM`, `GOARM64`, `GOMIPS`, `GOMIPS64`, `GOPPC64`, `GORISCV64`, `GOWASM`, `GO111MODULE`, `GOFIPS140`, `GO_EXTLINK_ENABLED`, `GOCOVERDIR`). None of the 15 names a program, a source of code or a build-result location. The 9 keys the help lists as "not read from the environment" (`GOTOOLDIR` among them) are out of scope by the help's own words. |
| gcc driver and preprocessor reads | Holds | GCC 14.2 sources (read): the driver reads only `GCC_EXEC_PREFIX`, `COMPILER_PATH`, `LIBRARY_PATH`, `LPATH`, `GCC_COMPARE_DEBUG` (`gcc.cc:4746-5444`, the `env.get` calls; the spec-file `getenv` function reads only what a spec names, and `gcc -dumpspecs` and `g++ -dumpspecs` here name none, ran), the preprocessor reads the `incpath.cc:483-495` table (with `OBJCPLUS_INCLUDE_PATH`) and `DEPENDENCIES_OUTPUT`/`SUNPRO_DEPENDENCIES` (`c-opts.cc:1409-1414`). All reserved. So "the two that gcc's driver and preprocessor read and the manual leaves out" is exact. |
| The GCC 14.2 manual is closed, as the gcc sentence says | Not yet true | See R27-1. |
| Extra 1: the `PKG_CONFIG` family | Holds; well chosen | The prefix covers Go's `PKG_CONFIG` and every pkg-config key. pkgconf 1.8.1 is the pkg-config in this Ubuntu image. Its binary and library name 19 `PKG_CONFIG_*` keys, all reserved (ran). Among them are `PKG_CONFIG_PATH`, `PKG_CONFIG_LIBDIR` and `PKG_CONFIG_SYSROOT_DIR`, which choose the `.pc` files. `PKG_CONFIG_LOG` writes a log to a path the caller names. The prefix also covers the freedesktop pkg-config's `PKG_CONFIG_$PACKAGE_$VARIABLE` overrides, e.g. `pkg_config_zlib_prefix` (reserved, ran). pkgconf's other environment names are `CPATH`, `CPLUS_INCLUDE_PATH`, `OBJC_INCLUDE_PATH` and `LIBRARY_PATH`, all already reserved. `DESTDIR`, `LIBS`, `CFLAGS` and `POSIXLY_CORRECT` appear in its strings, but setting them did not change `pkg-config --cflags --libs python3` (ran). Near misses: `PKG_CONFIGURATION` is reserved too, the same over-reach the `PERL`, `RUBY` and `PHP` prefixes already accept (O3). `PKGCONFIG`, `PKG_CONFI` and `MY_PKG_CONFIG` stay open. The contract names the family and says why, and the docs test pins that sentence. |
| Extra 2: `DEPENDENCIES_OUTPUT`, `SUNPRO_DEPENDENCIES` | Holds; the stated reason is right | `c-opts.cc:1400-1432` (read): the value is a file name, optionally followed by a space and a target. The target is passed as `-MT` with the comment "Let the caller perform MAKE quoting", so it goes into the file unquoted, and the rules are appended to that file. Benign probe (ran, gcc 13.3 in this image, `probes/gcc-probes.txt`): `DEPENDENCIES_OUTPUT="<dir>/deps.out caller-chosen-target-text" gcc -c a.c` wrote `caller-chosen-target-text: a.c`. `SUNPRO_DEPENDENCIES` did the same and also listed the system header. The contract's "a file it writes with text the caller chooses" is accurate. The writer's further point, that a shell sourcing such a file would run the text, is a reasonable inference; I did not demonstrate it either. |
| N1 (re-check 25 Opus) | Fixed | "It is a backstop …" now follows "… `TestReservedEnvironmentKeySetIsPinned` pins it." (`contracts.md:527`). The new passage's reasons are accurate: `GOFIPS140` selects a FIPS module the toolchain ships; `SOURCE_DATE_EPOCH` and `GCC_EXTRA_DIAGNOSTIC_OUTPUT` change a timestamp and diagnostic text (manual, read). No test holds the order (M15 survives). Re-check 25 asked for no test, so this is not a finding. |
| O1 (re-check 25 Opus): runbook declarations | Fixed, one gap (N27-1) | The new guard catches a reserved key declared in an example (M11 `PKG_CONFIG_PATH`, M13 lowercase `ld_preload`) or in `scripts/` (M14). The writer's T8 covers a runbook. Its self-check needs three known declarations. Every `environment_variables` declaration outside Go in the repo is JSON with double quotes, the form its regex reads (`git grep`, 14 files). It misses a padded entry; see N27-1. |
| Sonnet O1: the dependency-file keys | Done | As in extra 2. |

## Findings

```text
AUDIT FINDING R27-1
Type / Severity: security risk in the backstop (the contract's completeness claim is false in its
  own named source) / low
Current contract: .docs/execution_lifecycle/contracts.md:525 (956991c): "the GNU C compiler's keys
  that choose the programs it runs, the headers and libraries it builds with, extra options, or a
  file it writes with text the caller chooses (… : every such key the GCC 14.2 manual lists, and
  the two that gcc's driver and preprocessor read and the manual leaves out, `LPATH` and
  `OBJCPLUS_INCLUDE_PATH`)". The PR body says the same.
Path and line (956991c): es/admission/service.go:84-314 (reservedRuntimeEnvKeys; neither key there,
  no prefix or suffix covers them; MAKEFLAGS at :253 is a different key)
Evidence:
  - MAKE. Manual (gcc/doc/invoke.texi:14727-14728, releases/gcc-14.2.0, read): "The environment
    variable MAKE may be used to override the program used." Source (gcc/lto-wrapper.cc, read):
    make_exists() runs `$MAKE --version` (:1380-1392) whenever parallel LTRANS is requested, by
    -flto=N, -flto=auto, -flto=jobserver or a detected make jobserver (:1600-1669). The parallel
    step then runs `$MAKE` with its arguments, split by buildargv (:2073-2080). Ran (gcc 13.3 in
    this image, as ci, marker script only): `MAKE=<dir>/marker.sh gcc -flto=2 a.c b.c -o ab` ran
    the marker ("marker ran: …/marker.sh --version"). The marker exits 1, so gcc fell back to a
    serial link and the build still succeeded (exit 0). The control run without MAKE ran no marker.
  - CXX_MODULE_MAPPER. Manual (invoke.texi:3512-3522 and :37733-37756, read): the mapper comes from
    -fmodule-mapper or the CXX_MODULE_MAPPER variable, and its "|program [args]" form is "A program
    to spawn". Source: gcc/cp/module.cc:14345 reads it when no option is given. Ran:
    `CXX_MODULE_MAPPER='|<dir>/marker.sh' g++ -std=c++20 -fmodules-ts -c m.cc` spawned the marker
    (then "cc1plus: error: mapper exit status 1"). An ordinary compile without -fmodules-ts did not
    spawn it.
  - MSP430_GCC_INCLUDE_DIR (invoke.texi:29344-29350, read): a directory the msp430 port searches
    for headers and linker scripts. Only an msp430-elf cross compiler reads it, so it has no reach
    in a native image. It is listed here because the sentence says "every such key the manual
    lists".
  - Complete list of the manual's names (key probe, ran; text, read). Reserved: COMPILER_PATH,
    CPATH, C_INCLUDE_PATH, CPLUS_INCLUDE_PATH, OBJC_INCLUDE_PATH, DEPENDENCIES_OUTPUT,
    SUNPRO_DEPENDENCIES, GCC_COMPARE_DEBUG, GCC_EXEC_PREFIX, LIBRARY_PATH, PATH, TMPDIR. Open by
    design: LANG, LC_ALL, LC_CTYPE, LC_MESSAGES (locale), SOURCE_DATE_EPOCH,
    GCC_EXTRA_DIAGNOSTIC_OUTPUT, GCC_COLORS, GCC_URLS, TERM_URLS and COLUMNS (diagnostic text and
    layout). Not read by gcc: ASAN_, HWASAN_, LSAN_, TSAN_ and UBSAN_OPTIONS and VTV_LOGS_DIR are
    read by the instrumented program's runtime, not the compiler; GCC_INCLUDE_DIR and
    TARGET_SYSTEM_ROOT are configure-time values (the driver's environment reads are listed
    above); TOPDIR is the manual's example of a spec-file getenv. Open and in the sentence's
    categories: MAKE, CXX_MODULE_MAPPER, MSP430_GCC_INCLUDE_DIR. That is the whole gap in this
    source.
Impact: a publisher that declares MAKE lets a caller choose a program that gcc runs at every
  parallel-LTO link, -flto=auto included, silently, with the build still passing. With a declared
  caller mount, whose files keep their execute bit (red-team 19 observation 3), that is the
  caller's code in the run, the same reach as CC, which is reserved. CXX_MODULE_MAPPER reaches
  the same way, only for C++ modules builds. Reach today is small: it needs a workload that builds
  C or C++ with LTO or modules, and a publisher that declares the key. No artifact in the project
  declares either (the declared keys in this repo are APP_MODE, WORKLOAD_VAULT_SECRET_PATH,
  REFERENCE_IDENTITY_URL and REFERENCE_SECRET_PATH). But the contract now says the class is
  complete for this manual, so a reader takes MAKE as reserved.
Required correction: reserve MAKE, CXX_MODULE_MAPPER and MSP430_GCC_INCLUDE_DIR by name, and add
  them to mustBeReservedEnvironmentKeys and to the refusal table. Naming them in the contract's
  gcc parentheses is optional. Tested (mutants/fix-check.diff.txt, 7 lines in 3 files, gofmt-clean):
  the targeted es/admission set (`TestReserved|TestOrdinary|TestEmptyEnvironment|TestCaller|
  TestDeclared|TestEnvironmentRefusal|TestOperationalRetained|TestRedTeam`) and the root docs
  tests pass, with the three names in the contract. If the writer would rather not reserve
  MSP430_GCC_INCLUDE_DIR, the sentence can say "a native compiler" instead. I recommend reserving
  it: one line, and the sentence then holds literally.
Uncertainty: none on the facts. The probes ran gcc 13.3 (the image's); the manual and sources are
  14.2, and the code paths cited are the same in both (Inference from the probe matching the 14.2
  source).
Patch defect or pre-existing issue: patch defect in bba0248 (the "every such key the GCC 14.2 manual
  lists" claim is new there); the keys themselves were open before the PR.
```

```text
AUDIT FINDING N27-1
Type / Severity: test gap (the new guard reads declarations untrimmed; ES trims them) / nit
Path and line (956991c): caller_declaration_docs_contract_test.go:141
  (`upper := strings.ToUpper(key)`), used by TestRunbooksAndExamplesDeclareNoReservedEnvironmentKey
Evidence (ran): mutant M12, an example that declares " LD_PRELOAD", passes every test.
  ES compares declared entries after trimming (contracts.md:528), and isReservedRuntimeEnvKey trims
  too (service.go:1455). Power check (probes/zz_audit27_padded_test.go): an artifact whose signed
  declaration holds " LD_PRELOAD" or "LD_PRELOAD\t" gets its caller's LD_PRELOAD refused before any
  effect. That is the "publishes fine, refused at submit" case the guard exists to catch.
Required correction: `strings.ToUpper(strings.TrimSpace(key))` in reservedEnvironmentKeyMatcher.
  Tested (mutants/n2-fix-check.txt): the root docs tests pass with it, and M12 is then killed. The
  contract test, which shares the matcher, is unaffected.
Patch defect or pre-existing issue: patch defect (bba0248).
```

```text
AUDIT FINDING N27-2
Type / Severity: readability / nit
Path and line (956991c): es/admission/service.go:211
Evidence: the edited comment block wraps at about 80 columns, but line 211 ("// commands in a script
  that translates its messages. Upstream glibc's gettext skips a LANGUAGE entry that") is 108
  characters; the rewrap stopped one line short.
Required correction: reflow that line with the next (comment only; gofmt does not care).
Patch defect or pre-existing issue: patch defect (bba0248).
```

## Observations (no correction required by this re-check)

- **O1. Contract wording no test pins (M15, M16, M17 survive).** The position of the N1 sentence, the clause "every such key `go help environment` lists in Go 1.26.5", and the name `LPATH` in the gcc parentheses can each change without a test failing. This is by design: the docs tests pin the rule sentences, require every named key to be reserved and require every prefix and suffix to be named, not every single key (re-check 25 Sonnet O4 said the same). A removal would only weaken a claim, so I raise nothing.
- **O2. Seen outside the two sources, not judged.** GCC's `collect2` and `lto-wrapper` also read `COLLECT_GCC`, `COLLECT_GCC_OPTIONS`, `COLLECT_LTO_WRAPPER`, `COLLECT_AS_OPTIONS` and `COLLECT_NO_DEMANGLE` (14.2 sources, read; open, probe). Inference: the driver sets the first four for its children, so a caller's value is normally replaced. The manual does not list them, and they are not the driver's or preprocessor's own reads. Sanitizer `*_OPTIONS` (whose runtime can be told to run a symbolizer program) and `VTV_LOGS_DIR` are read by an instrumented program, not by gcc. Both groups are outside the sentence's class. I record them so a later round does not take them for new findings within it.
- **O3. The `PKG_CONFIG` prefix has no underscore,** so it also reserves names such as `PKG_CONFIGURATION`, as `PERL`, `RUBY` and `PHP` already do. It is harmless and consistent; I mention it only so nobody reads it as a mistake.
- **O4. The guard's self-check proves only that `.runbooks` and `.examples` are scanned.** Today `scripts/` holds only empty lists (M14 shows it is scanned) and `.docs` holds none in JSON form, so nothing is lost.

## Validation

All runs as an unprivileged user `ci` (uid 1500, gid 1600), `umask 022`, `env -i` (no proxy variables), Go 1.26.5 (`/opt/go1265`, `GOTOOLCHAIN=local`, `GOPROXY=off`, module cache already complete), one clone per tree from a bundle (trees `5e03010a…` and `b3c61199…` checked). Before the runs I installed acl, iproute2, openssh-client, uuid-runtime and the `en_US.UTF-8` locale, as re-check 25 did. Command: `go vet . ./es/... ./scripts/... ./internal/... ./ars/... ./ags/... ./egs/... ./cgs/...`, then `go test -count=1 -timeout=30m -json ./...`, one tree at a time: head 05:16:15Z-05:23:49Z, base 05:23:49Z-05:31:06Z. Nothing else ran during the two runs except the short key probe and gcc probes during the base run.

| Tree | Top-level pass / skip / fail | Compared |
| --- | --- | --- |
| base `0b9278c` | 1847 / 87 / 14 | |
| head `956991c` | 1866 / 87 / 14 | the same 14 failing names, and the same 45 counting subtests; 19 tests only at head, all pass (`tests/only-head-top.txt`: re-check 25's 18 plus `TestRunbooksAndExamplesDeclareNoReservedEnvironmentKey`); none only at base; no test changed status |

`go vet`: clean on both. `git status --porcelain` after each run: empty. The 14 failures are environment-only and fail the same way on the base. They are the 3 `reliablesubmit` old-binary probes; `TestLinuxSetupBootstrapFinishesWithItsSavedSecret` and `TestNomadACLToolRetriesABootstrapThatNeverTookEffect` in `es/app`; and 9 in `scripts`: 3 TLS-status, 2 operator-recovery, 3 P0t-grammar and `TestRemoteAlphaUpgradeESCheckRefusesWhatItWasNotWrittenFor` (`tests/fail-*-top.txt`). Writer report 26 saw 55 failing as root, and re-check 25 saw 17 as `ci`. Inference: host packages and the user account account for the difference. The names-equal-to-base result is what a delta needs, and it holds.

**Mutants** (ran; fresh clone of the head, `git status` empty before each, targeted sets first, then the whole `es/admission` and root packages for every survivor; `mutants/`):

| ID | Change | Result |
| --- | --- | --- |
| M01-M04 | `FC`, `GCCGOTOOLDIR`, `LPATH`, `OBJCPLUS_INCLUDE_PATH` dropped | killed: the pin and the refusal test (and the contract test where the contract names the key) |
| M05 | prefix `PKG_CONFIG` dropped | killed: the pin, the refusal test, the contract test |
| M06 | `PKG_CONFIG` reserved as one key instead of a family | killed: the pin, the refusal test (`pkg_config_path`, `PKG_CONFIG_LIBDIR`) |
| M07, M08 | `DEPENDENCIES_OUTPUT`, `SUNPRO_DEPENDENCIES` dropped | killed: the pin, the refusal test, the contract test |
| M09, M10 | `SOURCE_DATE_EPOCH`, `GO111MODULE` over-reserved | killed: `TestOrdinaryEnvironmentKeysAreNotReserved`, the pin |
| M11 | example declares `PKG_CONFIG_PATH` | killed: the new guard |
| M12 | example declares `" LD_PRELOAD"` | **survived** (N27-1; power-checked) |
| M13 | example declares `ld_preload` | killed: the new guard |
| M14 | a `scripts/` hardening request declares `MAKEFLAGS` | killed: the new guard |
| M15 | contract: N1 moved back | survived (O1; no test asked for) |
| M16 | contract drops the `go help environment` completeness clause | survived (O1) |
| M17 | contract stops naming `LPATH` | survived (O1) |
| M18 | guard matcher without case folding | killed: the contract test |

**Fix checks** (ran, then the clone was restored, `git status` empty): R27-1's three names in map, pin, refusal table and contract (`mutants/fix-check-output.txt`); N27-1's trim, with and without M12 (`mutants/n2-fix-check.txt`).

## CI (CI)

Read through the GitHub connector at 05:46Z-05:58Z; I ran nothing on GitHub. Both jobs ran on the merge commit `9213692` ("Merge 956991c… into 0b9278c…").

| Check | Run / job | Time (UTC) | Result |
| --- | --- | --- | --- |
| build, vet and test (Linux) | 45943548808 / 140322998203 | 05:04:02 to 05:50:34 | success |
| test on macOS | 45943548863 / 140322998381 | 05:04:02 to 05:32:24 | success |

Linux log (whole log read, 1,404 lines; `ci/excerpts.txt`): `es/app` passed with only its 3 listed tests skipped ("the observed run passed; go test skipped exactly the listed tests of this package (3), each once"). It has no self-skip group, so its Docker and Nomad flows ran there. The other log lines: "test gate passed: 50 packages, 3 of them with skipped entries (17 entries); 14 tests skipped themselves, all of them listed"; "all 17 listed tests still fail on this host …"; "tests as root passed: 9 of execution-substrate/scripts". macOS log (whole log, 3,639 lines): "test gate passed: 2 packages, 1 of them with skipped entries (26 entries); 81 tests skipped themselves, all of them listed" and "all 26 listed tests still fail on this host …".

## Coverage this environment could not give

- No Docker daemon, Nomad, Vault or SPIRE here; CI ran the `es/app` flows.
- `GCCGOTOOLDIR` was not exercised (no gccgo). `MSP430_GCC_INCLUDE_DIR` was not exercised (no msp430 cross compiler). Both effects come from the documentation.
- No runtime image was inspected, so whether a granted image builds with LTO or C++ modules (R27-1's reach) is unknown.

## Trial-log row (model evaluation, category R-S)

| Date | Category | PR @ head | Scope | Model | Verdict | Findings | Later outcome |
|---|---|---|---|---|---|---|---|
| 2026-11-27 | R-S | ES #74 @ 956991c | narrow re-check (pair) | [model withheld] | BLOCK | R27-1 Low (MAKE, CXX_MODULE_MAPPER, MSP430_GCC_INCLUDE_DIR open though the contract says every such key the GCC 14.2 manual lists; MAKE and the mapper demonstrated), N27-1 nit (guard does not trim declarations; M12 survives), N27-2 nit (comment wrap) | paired with the Sonnet row; reports workload-identity/27-pr74-recheck-{opus,sonnet}.md |

## Evidence

`27-pr74-recheck-opus-evidence/`:

- `provenance/`: the four manifests and the recipe copy that ran.
- `tests/`: runner, environment wrapper, summarizer, failing and only-head lists, vet, status, timings, and both `go test -json` logs gzipped.
- `probes/`: the key probe and its output, the padded-declaration power check, and the gcc probe script with its output.
- `upstream/`: the GCC 14.2.0 manual and sources, with `gcc-14.2.0-SHA256.txt`, and `go help environment` from Go 1.26.5.
- `mutants/`: spec, runner, results, log, both fix checks and the fix diff.
- `ci/`: both job logs gzipped, and excerpts.
- `SHA256SUMS`.
