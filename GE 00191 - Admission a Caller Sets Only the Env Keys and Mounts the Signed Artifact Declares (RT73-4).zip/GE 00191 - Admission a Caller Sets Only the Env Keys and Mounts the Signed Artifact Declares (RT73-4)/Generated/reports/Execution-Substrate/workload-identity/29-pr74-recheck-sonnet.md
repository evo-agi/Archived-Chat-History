# Narrow re-check 29 (Sonnet): ES PR #74 repair after re-check 28: BLOCK (one nit only; VSB_DIR, the order pin and the guard's behaviour all hold)

Date: 2026-11-27, about 3:10 AM Eastern (08:10Z; start 07:21Z). Auditor: thread "Sonnet re-check 29 of PR 74". Model: `[model withheld]`. Model-evaluation trial, category R-M security (narrow re-check, medium); the usual model checks the same scope independently. I did not read its report or evidence: a folder named `29-pr74-recheck-opus-evidence` showed in one directory listing (names only), and I did not list or open it. This thread has not written, repaired or audited #74 before. As the brief asked, I read re-check 28 (Opus and Sonnet) and writer report 29.

Disclosure on blindness. The brief said not to read the tail of the shared trial log. I read `model-evaluation/sonnet-trial.md` in full to learn the logging rules (the Read tool returns the whole file), so its log table was shown to me. No row in it names #74 at 10a3b58 or any Opus finding on this scope; the newest #74 rows are for 9c06790, e0b5c89 and 956991c. The session also recalled memory notes on re-checks 23, 25, 27 and 28 of this PR (earlier rounds, which the brief allowed). No finding below came from either.

Source labels: "ran" means I ran it in this container on the commit named. "Read" means I read code, a document or upstream source and did not run it. "Inference:" and "Guess:" mark the rest.

```text
INDEPENDENT AUDIT REPORT (narrow re-check of a repair, protocol §14)
Repository / Audit target:
  evo-agi/Execution-Substrate PR #74, branch claude/project-thread-ef7st5
  base trunk_dev 0b9278ca74404b46b5e9f0e1701874b52687f5e8 (#69)
  topic commit 10a3b587930b622bec25eee532ba3cad3b349518, tree 5cea997d63751be9a7794bc3efbd04a927b3f02a
  recipe governed-execution.audit-patch-manifest.v2, source SHA-256
    c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (sha256sum -c OK before the opening and the closing runs)
  canonical-manifest SHA-256 0e198ba98335ad47a17bcfe245c8e203c61e74c6ee00fd5e1189ed5ccf275338, 31 paths,
    textual_diff_sha256 44f533fa988296b6626c9bd77d64c52dfff4c2cee31f808b0119b90f177500c6
  Scope: git diff 0e56e23 10a3b58 (4 files, +148/-58, sha256 417a6719...4bb8). R28-1 (VSB_DIR reserved), N28-1 (the runbook
    guard as a function with a 22-case table test, its limits stated), N28-2 (the open-keys paragraph pinned whole).
Audit posture: read-only, parent only, no subagents. Nothing pushed, nothing posted on GitHub, no box, no merge.
  Tests, probes and mutants ran in clones owned by an unprivileged user (uid 1500); the provenance clone ran no tests.
Provenance reproduction: reproduced twice, identical; equal to the writer's manifest file byte for byte; closing runs
  equal the opening; pushed tip, PR ref and trunk_dev re-read at the start and the close, unchanged; delta digests
  equal the writer's.
Coverage: every hunk of the 4-file delta; the PR body; writer report 29; the whole GCC 14.2.0 manual closure (45 names)
  against the real reserved-key function at the base, at 0e56e23 and at the head (291-key probe); gcc 14.2.0 source for
  VSB_DIR, TOPDIR and every literal getenv read in gcc/*.cc, libcpp and libiberty; the guard's every regex and branch,
  by 106 mutant runs of my own and by a 60,000-document differential test against AGS's own JSON decoder; the writer's
  25 mutants, re-run; the open-keys paragraph by 14 contract mutants. Not covered: see "Coverage this environment could not give".
Findings: 1 nit (N29-1). 5 observations. No finding against the substance of the repair.
Validation assessment: whole suite on exact bytes for head and base as an unprivileged user: the same 45 failing
  names (14 top-level) on both, 167 names only at the head and all pass, no status change in 10320 common names.
CI on 10a3b58: both required checks green ("build, vet and test" 08:02:20Z, "test on macOS" 07:56:24Z; see "CI").
trunk_dev moved after my closing run: #75 merged at 08:01Z (be20ffc). #74 is now behind; a trial merge is clean and its
  root and es/admission tests pass (see "trunk_dev moved").
Sensitive-material handling: no secrets, keys, tokens, env files, SQLite or TLS/SPIFFE/Vault material read.
Remaining uncertainty and stop conditions: none that blocks the verdict. The nit is fixed by a new head (two table cases)
  or by narrowing a sentence in the PR body (the head stays). #74 is also behind trunk_dev now (#75), so a new head is
  likely anyway (see "trunk_dev moved").
Confidence: provenance high / validation high for what runs here (Docker and Nomad flows run only in CI) /
  implementation high for the repair's substance; the nit is measured, not guessed.
Effect status: repair, commit, push, PR, merge not performed.
Report delivery: /mnt/project-files/reports/Execution-Substrate/workload-identity/29-pr74-recheck-sonnet.md
  (SHA-256 in the delivering message), evidence in 29-pr74-recheck-sonnet-evidence/ (SHA256SUMS inside).
Final verdict: BLOCK
```

**Why BLOCK, in plain words.** All three repairs do what they say.

- **R28-1.** `VSB_DIR` is reserved in the code, the exact pin, the refusal table, the contract's gcc parentheses and the code comment. The gcc source says what the comment says: gcc 14.2.0's VxWorks 7 specs read it for two header directories and to choose a library, through the driver's `getenv` spec function. I ran the whole manual closure through the real function: 45 names, 17 reserved (16 before), 28 open, and none of the 28 is in the class; `TOPDIR` is read by no gcc source, and `GCC_INCLUDE_DIR` and `TARGET_SYSTEM_ROOT` are macros. Between 0e56e23 and the head exactly the `VSB_DIR` spellings flip from open to reserved (8 probe rows); nothing else moves.
- **N28-2.** The open-keys paragraph is one required phrase. I tried 11 reorderings, deletions and edits of it, including the exact reversal re-check 25 reported (the `LANG` sentence before the backstop sentence): all killed. The report's sentence "every other reordering now fails" is true.
- **N28-1.** The guard is a function with a table test, and its stated limits are accurate. A differential test I wrote runs 60,000 random JSON runtime interfaces through AGS's own decoder and through the scanner: every document whose key has no escape is read, with the same entries AGS decodes (30,346 of them, all letter cases and U+017F included), and every document whose key is written with an escape is reported (29,654). The writer's 25 mutants are all killed when I re-run them. The four spellings the comment says it does not see do slip, as stated.

One thing is stronger than its tests. The PR body and writer report 29 say each branch of the scanner, weakened, is killed. Two are not: the entry decoder's single-quoted fallback (a single-quoted entry neither decoder reads) and the upper-case hex digits of a key-name escape. The code is right in both (a planted single-quoted `\N{...}` entry is refused by the real guard; the differential test reads upper-case hex), but no test in the repository pins either. This is a nit, and the project rule is that nits are fixed in the PR, so the verdict is BLOCK on a nit only, as re-checks 21 (Opus, #73) and 28 (Sonnet, this PR) did.

**If the coordinator reads N29-1 as an observation**, nothing else blocks and the result is ACCEPT. Resolving it costs either a new head (two table cases, tested, which means a new CI round of about 46 minutes and a new check) or no new head at all: narrowing "each branch of the scanner weakened" in the PR body to what was killed. The first is the fix the project's own principles prefer (a gap with a cheap, tested fix is fixed, not noted); the second is a description edit and leaves the audited bytes, this audit and CI valid. Since #75 merged into `trunk_dev` after my closing run, #74 needs an update from `trunk_dev` as well (see "trunk_dev moved"), which makes a new head and a new CI round likely whichever way N29-1 goes.

## Provenance (ran)

| Step | Result |
|---|---|
| Recipe bytes | `sha256sum -c` OK (`c08597e2…a3ca`) on the shared file and on the copy that ran, before the opening and the closing runs (`provenance/recipe-hash.txt`) |
| Pushed tip | `git ls-remote` at the start (07:21Z) and at the close (07:48Z): `refs/heads/claude/project-thread-ef7st5` and `refs/pull/74/head` = `10a3b58`, `trunk_dev` = `0b9278c`. The PR API shows head `10a3b58`, base `0b9278c`, 13 commits, 31 files, +1804/-77 (`provenance/ls-remote-close.txt`) |
| Base ancestry | `0b9278c` is an ancestor of `10a3b58`; `0e56e23` → `10a3b58` is one commit with no merge (`provenance/commits.txt`) |
| Manifest | fresh clone of GitHub, branch checked out at the tip (clean), `git reset --mixed 0b9278c`, upstream `origin/trunk_dev`; two runs, `cmp` identical, `manifest_sha256` `0e198ba9…275338`; **equal byte for byte** to the writer's `24-pr74-repair-evidence/manifest-v2-10a3b58-on-0b9278c.json`; 31 files; `textual_diff_sha256` `44f533fa…500c6` equals the writer's |
| Closing run | the clone had the opening state; two runs identical and equal to the opening (`manifest-close-{1,2}.json` = `manifest-open-{1,2}.json`) |
| Diff digests | `git diff 0e56e23 10a3b58`: 4 files, +148/-58, `417a6719…4bb8`; `git diff 0b9278c 10a3b58`: 31 files, +1804/-77, `109f0941…e82d`; tree `5cea997d…`. All equal writer report 29 |

## The delta, and what it does (read)

- `es/admission/service.go`: one map entry (`"VSB_DIR": {}`, line 321) and the comment above the single keys re-wrapped and re-worded (longest line 75 columns). No logic change: `isReservedRuntimeEnvKey` is untouched.
- `es/admission/caller_declaration_test.go`: `VSB_DIR` in the exact pin (line 231) and `VSB_DIR`, `vsb_dir` in the refusal table (line 378).
- `.docs/execution_lifecycle/contracts.md` (section 5, the single-keys bullet, line 525): `VSB_DIR` named in the gcc parentheses, after `MSP430_GCC_INCLUDE_DIR`.
- `caller_declaration_docs_contract_test.go`: the open-keys paragraph folded into one required phrase (line 38); the guard's two patterns, entry pattern and decoder moved into `scanEnvironmentDeclarations` and `decodeDeclaredEnvironmentEntry` (lines 301-366); the per-root file check (line 270); `TestEnvironmentDeclarationScanReadsEachSpelling`, the 22-case table test (line 371).
- Not touched: the runbook, the examples, the scripts. So Archived-Runbooks' copy of the reference-workload runbook compares the same against `10a3b58` as against `0e56e23`.

## The claimed fixes

| Claim (report 29, PR body, brief) | Verdict | What I checked |
|---|---|---|
| R28-1: `VSB_DIR` reserved by name, in the pin, the refusal table, the contract and the comment | **Fixed, all five places** | Real function (ran, `probes/probe-head.tsv`): `VSB_DIR`, `vsb_dir`, `Vsb_Dir`, padded and tab-padded spellings reserved; `VSB_DIR2`, `VSB_DIRS`, `XVSB_DIR`, `VSB`, `VSB_` stay open. Mutants: dropping it from the map is killed by the pin and the refusal test; dropping it from the contract by the pinned gcc clause; dropping it from the pin alone by the pin (V1-V3, killed); reserving it as the prefix `VSB_` by the pin (V5). Dropping it from the refusal table alone survives, because the exact pin already kills every code change (V4, redundant; not a finding) |
| The gcc source says what the comment says | **Holds** | Read, GCC 14.2.0 (commit `04696df0`): `gcc/config/vxworks.h:89-90` (`-idirafter %:getenv(VSB_DIR /h)` and `/share/h`, inside the `TARGET_VXWORKS7` branch) and `:145` (`%:if-exists-then-else(%:getenv(VSB_DIR /usr/h/public/rtnetStackLib.h) rtnet net)`, which library to link); `config.gcc:1146-1147` sets `TARGET_VXWORKS7` for `*-*-vxworks7*`; `gcc/gcc.cc:10307` `value = env.get (varname);` is the `getenv` spec function (`upstream/vsb-dir-and-topdir-grep.txt`). The manual's own example is `invoke.texi:37012` |
| `TOPDIR` stays open: no GCC source reads it | **Holds** | `grep -w TOPDIR` over `gcc/`, `libcpp/`, `libiberty/` and `libgcc/` outside `gcc/doc`: no hit. Its only appearance is the manual's `%:getenv(TOPDIR /include)` example (`invoke.texi:36973`) |
| The contract's source sentence is true: every manual-named key of the class is reserved | **Holds** | I rebuilt the candidate names from the manual closure myself (`upstream/manual-closure-candidates-own-extraction.tsv`: `@env`, `@vindex`, `getenv(`, `$NAME`, tokens near "environment") and checked them against re-check 28 Sonnet's 45-name table: no new name (`DEBUG`, the example program's own read in an ifunc resolver, is not a key a GCC program reads). Real function on all 45 (`upstream/manual-names-at-10a3b58.tsv`): 17 reserved, 28 open. The 28 open ones are the same as at 0e56e23 and are outside the class: eight `LANG`/`LC_*` and `SOURCE_DATE_EPOCH` and five diagnostics keys (`GCC_EXTRA_DIAGNOSTIC_OUTPUT`, `GCC_COLORS`, `GCC_URLS`, `TERM_URLS`, `COLUMNS`), `GCC_INCLUDE_DIR` and `TARGET_SYSTEM_ROOT` (macros in the sources, not environment reads), `TOPDIR` (above), and eleven read by a program built with gcc (the sanitizer `*_OPTIONS`, `VTV_LOGS_DIR`, four `GCOV_*`, `GLIBCPP_FORCE_NEW`). A grep of every literal `getenv`/`env.get` in `gcc/*.cc`, `libcpp` and `libiberty` finds no further name of the class (`upstream/getenv-reads-in-gcc-sources.txt`) |
| Differential 0e56e23 to 10a3b58: only `VSB_DIR` moves | **Holds** | 291 keys on the base, 0e56e23 and the head: 8 rows flip (all `VSB_DIR` spellings), all open to reserved; none flips back; against the base 142 rows flip, all open to reserved, none the other way |
| N28-2: the paragraph is pinned whole, so its order is fixed and every other reordering fails | **Holds** | 14 contract mutants of my own: the exact reversal of N1 (`LANG` sentence before the backstop sentence), the swap of the `GOOS` and `SOURCE_DATE_EPOCH` sentences, the scope sentence moved to two other places, `LANG` moved after `GOOS`, the boundary sentence split off, the backstop sentence before "pins it", and four deletions or edits (one sentence each, "not reserved" turned to "reserved"): **all 13 killed** by `TestCallerDeclarationRulesAreInTheLifecycleContract`. The 14th, a duplicate sentence appended after the paragraph, passes, because the pin is a contains-check; the order of the pinned sentences is unchanged by it, so the claim stands. The gcc clause, the "any section" clause and `MSP430_GCC_INCLUDE_DIR` stay pinned (killed) |
| N28-1: the guard reads each declaration like AGS, fails on what it counts but cannot read | **Holds for JSON; the stated limits are accurate** | See "The guard" below |
| The 22-case table test | **22 cases** | Counted in the file (lines 371-399) |
| 25 of 25 writer mutants killed | **Reproduced** | I ran the writer's own file (`24-pr74-repair-evidence/mutants-10a3b58.py`, path changed to my clone): 25 of 25 killed, tree restored clean (`mutants/writer-run.log`) |
| Writer's full-suite counts on 3e5fc49 (1832 / 81 / 55) | **Not reproducible** | `3e5fc49` is not on the remote, so I could not check it. My counts are below (the same 45 failing names as the base) |
| Archived-Runbooks #30 unchanged | **Holds** | Draft #30 head is still `d65e8df`; the delta does not touch `.runbooks`, so its check results are as in re-check 28 |

### The guard (ran)

1. **Differential test against AGS's decoder** (`probes/zz_audit29_diff_test.go`, copied into a scratch clone of the head, never into the audited tree). It builds 60,000 JSON runtime interfaces with the `environment_variables` key spelled at random as `encoding/json` accepts it: letters in upper case, `s` as U+017F, letters written as `\u` escapes with lower or upper hex, JSON whitespace between all tokens, entries with escapes, brackets, quotes and surrogate halves, a second upper-case declaration, a neighbouring field. AGS's decoder (`httpx.DecodeStrictJSON` into `publish.RuntimeInterface`) refused none. Each document goes to `scanEnvironmentDeclarations` too. Claims checked: (A) a key with no escape is read, no problem, and every entry AGS decoded is read: **30,346 documents, no disagreement**; (B) a key written with an escape is reported: **29,654 documents, all reported**; (C) every entry AGS decoded is read or a problem is reported: **no disagreement**. The test has power: it fails when I weaken the scanner by dropping `(?i)` from either pattern, counting on raw text, removing the count check, ending the list body at the first `]`, decoding no JSON entries, skipping the `\u` pre-pass or reading lower-case hex only (8 of 8 killed; `probes/probe-power.log`; accepting undecodable entries survives it, as it must, since every generated document is valid JSON).
2. **Planted declarations in real files** (36 spellings, each in a runbook, an example, a script or `.docs`, run through the real guard): every declaration the comment says it reads or counts is killed: padded, `\u`-escaped, NBSP, single-quoted with a hex escape, an upper-case, mixed-case and U+017F key, the same key as a `\u` escape, a second list in one file, an entry holding `]` or `[` (double and single quoted), an unquoted key, a keyword argument, an indexed assignment (both quote styles), an attribute assignment, a YAML block list (quoted and unquoted key), an escaped-quote shell string, an unquoted list item, a Python named escape (double and single quoted), a comment inside a multi-line list, and `VSB_DIR` in three spellings. The two ordinary keys (`MAKE_TARGET`, `TOPDIR`) stay green, as wanted.
3. **The stated limits are true.** A key name written with a hex escape in a single-quoted Python key (`environment` + `\x5f` + `variables`), a key built in code (`"environment_" + "variables"` then `request[key] = [...]`), a YAML block list with a comment between the key and the list, and `request["environment_variables"].append("LD_PRELOAD")` all pass the guard (L1-L4, survived), which is exactly what the comment says it does not see. None is in the repository today.
4. **The table's branches** (my 30 scanner mutants, table in the next section): 20 killed, 3 survive only because the checks they remove fire only when a root loses all its files or declarations or when the wiring is the only thing between a problem and a pass (observations), and **one is a gap, N29-1** (GM14), with a related one (GM26).

## Findings

```text
AUDIT FINDING N29-1
Type / Severity: test/doc/artifact gap (a claim stronger than the tests: "each branch of the scanner, weakened, is killed") / nit
Current contract: PR body, "Tests": "Mutants for the last four rounds: ... 25 of 25 killed. Among them: ... each branch of the
  scanner weakened, the walk dropping a root, ..."; writer report 29, Validation table, row H1-H12: "each branch of the scanner
  weakened: ... undecodable entries are accepted; single-quoted entries are read raw; double-quoted entries are not JSON-decoded".
Path and line (10a3b58): caller_declaration_docs_contract_test.go:366 (the single-quoted fallback of decodeDeclaredEnvironmentEntry:
  "return match[2], !strings.Contains(match[2], `\`)"); :306 (jsonUnicodeEscape, "[0-9A-Fa-f]{4}")
Evidence (ran, on clones of the head, mutants/mutants29.py, logs mut1-mut6):
  GM14  the single-quoted fallback always accepts ("!strings.Contains(match[2], `\`)" becomes "true"): every test passes.
        The table has the double-quoted counterpart ("Python named escape", line 398; the writer's H9 kills the double-quoted
        fallback) but no single-quoted one, and no file in the repository holds a single-quoted entry neither decoder reads.
        The code is right: Y2 plants a single-quoted '\N{LATIN CAPITAL LETTER L}D_PRELOAD' entry in a runbook and the real
        guard reports it (killed). So the behaviour the comment states ("an entry neither decoder reads") holds for both
        quote styles; only the double-quoted one is pinned.
  GM26  the escape pre-pass reads lower-case hex only ("[0-9A-Fa-f]" becomes "[0-9a-f]"): every test passes. The table's
        key-escape case uses a lower-case hex digit. The code is right: the differential test generates upper-case hex
        (a key such as environment, backslash-u, 005F, variables) and kills GM26 (probes/probe-power.log).
  Related, harmless: GM22 (the double-quoted Go-escape branch off) and GM24 (the single-quoted "\'" replacement off) survive;
        both make the scan stricter (an extra problem), so they cannot hide a declaration. GM27 ({3,4} hex digits) survives
        and changes nothing real.
Impact: none on behaviour. A later edit to either line could stop the guard seeing a declaration spelled in one of those two
  ways, and no test would say so. The guard is a hygiene check: ES refuses the caller's key at submit whatever the runbook
  declares, so nothing ES admits changes. It is a nit because the claim is stated as exhaustive and listed among killed mutants.
Required correction: pick one.
  (a) Add two table cases (tested, mutants X1, X3, X5): a single-quoted entry holding the Python named escape
      (expected: a problem, no entries), and a key written as a JSON unicode escape with an upper-case hex digit
      (expected: a problem). The real tree stays green (X5 survives = passes); GM14 is killed (X6) and GM26 is killed (X7).
  (b) Narrow the sentence in the PR body (and say so in the next writer report) to the branches that were weakened and killed,
      which are the 12 H-mutants and 13 others in report 29. This needs no new head; the audited bytes and CI stay valid.
  The project's own rule against leaving a known gap with a cheap fix points to (a).
Uncertainty: none on the facts. Whether anyone will ever edit those two lines is Unknown.
Patch defect or pre-existing issue: patch defect in a claim (the scanner and its table test are new in 10a3b58).
```

## Observations (no correction required by this re-check)

- **O1. Checks that fire only on a violation are still unpinned, and one earlier "kill" was a build error.** Survivors, all compile-valid mutants: the per-root file check (GM17; with the `.docs` root also dropped, GM17b), the per-root declaration requirement (GM21), and the wiring that turns a scanner problem into a test failure (GM20; with a planted YAML block list in the same run, Y1, the guard passes). The table test calls the scanner directly, so only a planted file can show the wiring, and the repository has none. The same class as re-checks 28 Opus O2 and Sonnet O2; the writer chose the function-and-table remedy and it covers the scanner but not the loop around it. **Correction to my predecessor, re-check 28 Sonnet:** its table says dropping "the check" is killed by `H13`; its own log (`28-pr74-recheck-sonnet-evidence/mutants/mut1.log`) shows `H13` ended in `[build failed]` (the mutant left the loop variable unused), so it was a compile error, not a test. The compile-valid version (GM21 here) survives, as Opus's `M09` did. My first versions of five guard mutants (GM09, GM17, GM17b, GM19, GM21) had the same flaw; I rewrote them and only the later lines count (`mutants/mutants-final.tsv`). Optional: a small `scanDir`-style helper with its own test would pin the wiring.
- **O2. The comment says "a problem for each declaration it counts but cannot read".** The code reports one problem for the count (`N environment_variables declarations, but the scan reads M`), one per list holding something other than quoted entries, and one per undecodable entry. A file with three unreadable spellings gets one count problem. The guard fails either way. Wording only.
- **O3. Keys read by gcc's drivers outside the stated source are open, as the earlier rounds recorded.** Probe (ran, head): `COLLECT_GCC`, `COLLECT_GCC_OPTIONS`, `COLLECT_AS_OPTIONS`, `COLLECT_LTO_WRAPPER`, `COLLECT_NO_DEMANGLE`, `OFFLOAD_TARGET_NAMES`, `OFFLOAD_TARGET_DEFAULT`, `GCC_OFFLOAD_OMP_REQUIRES_FILE`, `TMP`, `TEMP`, `WIND_BASE`, `PWD`, `TERM`, `COLORTERM` and `POSIXLY_CORRECT` are all open (`probes/probe-head-extra-driver-keys.tsv` and `probe-head.tsv`). The manual names none of them, so the contract's sentence is true. `GCC_OFFLOAD_OMP_REQUIRES_FILE` is new to the lists (read: a gcc and lto-wrapper handshake file name, driver-internal like the `COLLECT_*` keys; I did not read how the driver sets it, so whether a caller's value survives is Unknown). `WIND_BASE` is read by a VxWorks AE spec (`vxworksae.h:27`) and is the same kind as `VSB_DIR` but outside the manual. For the coordinator, with the writer's list (Sonnet O3, Opus O4, Sonnet O4 / Opus O2 of re-check 28).
- **O4. The guard's walk skips `.gz`, `.tgz`, `.tar`, `.png`, `.svg` and `.pdf` and scans four roots only.** Read, unchanged by this delta. A declaration in Go test code, `README.md`, `PLANS.md` or another repository is outside it, as the PR body says ("`.runbooks`, `.examples`, `.docs` or `scripts`").
- **O5. Items outside this delta stay as the earlier rounds left them:** AGS signing a reserved key, caller mounts without the execute bit, unbounded `argv`, `MUSL_LOCPATH`, clang's keys, the sanitizer `*_OPTIONS` and `GCOV_*` keys (the contract says they are outside the class), and Archived-Runbooks' manual note commit after #74 merges.

## Validation (ran)

All runs as an unprivileged user (uid 1500), `umask 022`, `env -i`, Go 1.26.5 (`GOTOOLCHAIN=local`, `GOPROXY=off`), one clone per tree made from a bundle, `go vet . ./es/... ./scripts/... ./internal/... ./ars/... ./ags/... ./egs/...` then `go test -count=1 -timeout 30m -json ./...`, one tree at a time (`tests/`). Installed first: acl, iproute2, openssh-client, uuid-runtime, the `en_US.UTF-8` locale.

| Tree | vet | Top-level pass / skip / fail | Compared with base |
|---|---|---|---|
| base `0b9278c` | exit 0 | 1847 / 87 / 14 | |
| head `10a3b58` | exit 0 | 1867 / 87 / 14 | the same 45 failing names (the same 14 top-level, with subtests); 167 names only at the head, all pass (20 top-level: the PR's own tests, among them `TestEnvironmentDeclarationScanReadsEachSpelling`); 44 only at the base, all pass (the randomly named rounds of the PR12 SIGKILL tests); 10320 names in common, no status change |

The 14 failing top-level tests are the same as in re-check 28 (3 old-binary probes in `es/admission/internal/reliablesubmit`, 2 in `es/app`, 9 in `scripts`): `tests/head-failing-top-level.txt`. They fail the same way on the base. `git status --porcelain` before and after each run: empty. `gofmt -l` on the three changed Go files: empty. The one top-level test more than at 0e56e23 (1867 against 1866 there) is the new table test.

**Mutants of my own: 106 runs, `mutants/mutants-final.tsv` (the latest line per name).** 82 killed, 23 survived, 1 unusable (an anchor miss, `GM30`, dropped). Runner `mutants/mutants29.py`; targeted sets `./es/admission/ -run 'TestReserved|TestOrdinary|TestEmptyEnvironment|TestCaller|TestDeclared|TestEnvironmentRefusal|TestOperationalRetained|TestLifecycle'` and `. -run 'TestCallerDeclaration|TestLifecycleContract|TestRunbooksAndExamples|TestEnvironmentDeclarationScan'`; baseline green first, each mutant on a clean checkout; a build error is reported as `BUILDERR`, not as a kill.

| Group | Runs | Killed | Survived |
|---|---|---|---|
| Control (no-op edit) | 1 | | 1 (green, as wanted) |
| R28-1: `VSB_DIR` dropped or moved in the code, pin, table, contract; `TOPDIR` and `WIND_BASE` over-reserved; contract names `TOPDIR` as reserved | 9 | 7 | 2: dropping it from the refusal table alone (V4) and the `MAKE_TARGET` row (V9), both redundant with the exact pin |
| N28-2 and other contract mutants (reorderings, deletions, edits) | 14 | 13 | 1: a sentence appended after the paragraph (C12), a contains-pin by design |
| Scanner branches (GM) | 29 | 20 | 9: GM14 and GM26 (N29-1), GM22, GM24, GM27 (stricter or harmless), GM17, GM17b, GM20, GM21 (O1) |
| Planted declarations in real files (P) | 36 | 34 | 2: `MAKE_TARGET` and `TOPDIR`, where green is wanted |
| Stated limits (L) | 4 | | 4: survive, as the comment says |
| Matcher (H), table-inversion (T), planted single-quoted named escape (Y2) | 4 | 4 | |
| Proposed fixes: the two table cases alone (X1, X3, X5), each with the mutant it must kill (X2, X4, X6, X7); wiring dropped with a planted list (Y1) | 9 | 4 | 5: X1, X3 and X5 pass on the real tree, as wanted; Y1 (O1) |

**Key probe** (`probes/probe-{head,prev-0e56e23,base}.tsv`, 291 keys: all 54 of `go help environment`, the 45 manual names, the new key and its spellings and near misses, the driver-internal keys of the earlier rounds): described in the table above; run through `isReservedRuntimeEnvKey` itself (`probes/zz_audit29_probe_test.go`, copied in and removed).

## CI

Read through the GitHub connector. `10a3b58`: "test on macOS" (run 45957237285, job 140366425109, started 07:24:40Z) and "build, vet and test" (run 45957237250, job 140366424960, started 07:15:44Z): both completed with conclusion success. "test on macOS" completed 07:56:24Z (31m44s); "build, vet and test" completed 08:02:20Z (46m36s). The connector lists exactly those two checks, the two the project requires. The PR head read 10a3b58 at the same time. Record: `ci/check-runs-10a3b58.txt`. I read the results and did not read the job logs: nothing failed.

## trunk_dev moved (read, and ran on a trial merge)

At my final re-read of the refs (08:02:55Z, `provenance/ls-remote-final.txt`) the branch tip and `refs/pull/74/head` were still 10a3b58, but `trunk_dev` had moved from 0b9278c (my closing run, 07:48:44Z) to be20ffc: "Give each host its own AGS and EGS signing keys (#75)", merged 03:01:25 Eastern (08:01:25Z), 39 files, +2603/-48. The PR object reads `mergeable_state: behind`. Record: `ci/trunk-dev-moved.txt`.

- Overlap with #74's files: `.docs/system_overview/contracts.md` (+98 lines on trunk) and `PLANS.md` (+1). `git merge-tree --write-tree 10a3b58 be20ffc` exits 0 with no conflict (tree a54a10fe).
- I built that tree and ran the root package and `es/admission` on it as the unprivileged user (`ci/trial-merge-run.sh`): build clean, 3855 pass, 16 skip, 0 fail. `TestRunbooksAndExamplesDeclareNoReservedEnvironmentKey`, `TestEnvironmentDeclarationScanReadsEachSpelling`, `TestCallerDeclarationRulesAreInTheLifecycleContract`, `TestLifecycleContractNamesOnlyReservedKeysTheCodeReserves` and `TestReservedEnvironmentKeySetIsPinned` all pass, so #75's new files under `scripts/` and `.docs/` declare no `environment_variables` list the guard refuses and the contract pins still hold. This is a trial merge I built here, not a pushed commit, and I did not run the other packages on it.
- Inference: the branch rule for `trunk_dev` requires an up-to-date branch (project memory, 11-25), so #74 needs an update from `trunk_dev` before it can merge, whatever N29-1 becomes. That is a new head and a new CI round in any case, so the two table cases for N29-1 can ride along at no extra CI cost; the "narrow the PR body" option still saves the writer the edit, but not the new round. The coordinator decides.

## Coverage this environment could not give

- No Docker, Nomad, Vault or SPIRE here: the `es/app` mount and network flows skip, so I did not run `:submit` with a caller declaring `VSB_DIR`; the evidence for the key is the real function, the gcc source and the manual. No macOS run of my own (CI's macOS job is the reference).
- No VxWorks 7 gcc: the effect of `VSB_DIR` is read from `vxworks.h` and the driver's `getenv` spec function, not run (Inference).
- `3e5fc49`, the commit the writer's full-suite numbers belong to, is not on the remote, so those numbers are the writer's.
- Org code search covers default branches, so it cannot see this PR's files; I did not repeat the cross-repository greps of earlier rounds for `VSB_DIR` (re-check 28 Opus found no hit in the org).
- I did not re-run the Archived-Runbooks check script: the delta does not touch the runbook.

## For the writer, in one list

1. N29-1: add two table cases to `TestEnvironmentDeclarationScanReadsEachSpelling` (a single-quoted entry with a Python named escape; a key-name JSON escape with an upper-case hex digit), tested as X1, X3 and X5 in `mutants/mutants29.py` (the file builds the escape text with `chr(92)`; type neither case as a backslash-u sequence through a tool that rewrites it), or narrow "each branch of the scanner" in the PR body to what the mutants killed.
2. Optional, same round: O1 (a helper around the walk so that the wiring has a test), O2 (the comment's "for each").
3. After a new head: take the manifest again, let CI decide, and a narrow check of only those lines is enough; audit 21, red-team 19 and re-checks 23, 25, 27, 28 and this one do not need repeating for them.
4. After #74 merges: Archived-Runbooks #30's note must be pointed at the `trunk_dev` commit by hand.

## Trial log row (for the coordinator to copy)

| Date | Category | PR @ head | Scope | Model | Verdict | Findings | Later outcome |
|---|---|---|---|---|---|---|---|
| 2026-11-27 | R-M (security) | ES #74 @ 10a3b58 | narrow re-check of 0e56e23..10a3b58 (real) | [model withheld] | BLOCK (nit only) | N29-1 nit: "each branch of the scanner weakened is killed" is overstated (GM14, single-quoted undecodable-entry fallback; GM26, upper-case hex in a key escape; both unpinned, code right; two table cases fix it, tested). R28-1 VSB_DIR verified (gcc 14.2.0 vxworks.h and gcc.cc read; 45 manual names, 17 reserved, 28 open and outside the class; only `VSB_DIR` flips). N28-2 verified (13 of 14 contract mutants killed; the survivor is by design). N28-1 verified (60,000-document differential test against AGS's decoder: no disagreement; writer's 25 mutants reproduced; stated limits true). 5 observations incl. a correction to Sonnet re-check 28's "H13 killed" (a build error). Same 45 failing names as the base, no status change; 82 of 106 own mutant runs killed (23 survivors classified) | not blind to the log table (the file was displayed whole; no row for this scope); Opus report not opened. Pair: the Opus run on the same head and scope |

## Evidence

`29-pr74-recheck-sonnet-evidence/`: `provenance/` (opening and closing manifests, the delta diff and digests, the commit chain, `ls-remote` at the close, the recipe hash), `tests/` (runner scripts, failing-name lists for both trees, the names only at one tree, vet output, status files, gzipped `go test -json` of both runs), `probes/` (the 291-key list and probe test, outputs for the base, 0e56e23 and the head, the differential test and its output, the power check, the driver-key probe), `mutants/` (runner, name lists, the six logs, the final table, the writer's runner re-run with its log), `upstream/` (the gcc commit, the `VSB_DIR` and `TOPDIR` greps with the `vxworks.h` and `gcc.cc` lines, every literal getenv read, the manual names with their state at the base, 0e56e23 and the head, my own candidate extraction), `ci/` (the two check runs, the trunk_dev movement, and the trial-merge run with its gzipped `go test -json`), `README.md`, `SHA256SUMS`.

STATUS: READY (re-check delivered: BLOCK on one nit, N29-1; CI on 10a3b58 green on both required checks; trunk_dev moved to #75, so #74 needs an update, trial merge clean)
