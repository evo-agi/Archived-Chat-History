# Re-check 30 (Opus): ES PR #74 at 4d7ed6d: ACCEPT (the N29-1 rows kill the four named mutants; the merge leaves the PR's patch unchanged; CI green)

Date: 2026-11-27, about 4:05 AM Eastern (09:05Z). Thread: "Opus delta check of PR 74", fresh and read-only. I did not write #74 and did not audit this round before. Blind pair in the model-evaluation trial (category R-S, security PR with a test-only delta): I did not read the Sonnet report or evidence for this round, and I messaged no thread. Model: [model withheld]. Inputs read: writer report 30, the lines of re-check 29 Sonnet that a search for "N29-1" returned (its summary lines, the finding block and the paragraph around it; the finding this delta answers), my own re-check 29 for its header form, and the trial log.

Source labels: "ran" means I ran it in this container on the commit named; "read" means I read it and did not run it; "CI" means read from GitHub; "Inference:" marks my reasoning.

```text
INDEPENDENT AUDIT REPORT (narrow re-check of a repair, protocol §14)
Repository / Audit target:
  evo-agi/Execution-Substrate PR #74, branch claude/project-thread-ef7st5
  base be20ffc8a5f82a35c4ce9064594a081f419c1ef5 (trunk_dev, #75)
  topic commit 4d7ed6d8897fda4d318baf845c7b6c150e336ef5, tree fb6432494605a83a57d0347784c5d60681fb88c6
  recipe governed-execution.audit-patch-manifest.v2, source SHA-256
    c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (sha256sum -c OK before each run)
  canonical-manifest SHA-256 89004ac6502a9c9cf87f738126875a51df387250d25c0a9f73793fbc55ae3686, 31 paths,
    textual_diff_sha256 61fad89e36a514e0ccee532077933f0b974891b6cad7015970e17b9392ebe08e
  Scope (coordinator): git diff 10a3b58 aa2b6a5 (1 test file, +7: the N29-1 table cases);
    the merge aa2b6a5..4d7ed6d of trunk_dev be20ffc (#75) must not change the PR's own patch;
    CI on 4d7ed6d. Kept very small on purpose.
Audit posture: read-only. Parent only, no subagents. Nothing pushed, nothing posted on GitHub, no
  Linux box, no live service. Tests and mutants ran as root in detached worktrees, never in the
  provenance clone (see "Limits").
Provenance reproduction: equal to writer report 30's manifest file, byte for byte; opening and
  closing runs identical (two runs each).
Findings: none. 1 observation (GM27 survives; stricter-only, see "In plain words").
Validation assessment: the four named mutants (GM14, GM26, GM22, GM24) are each killed at aa2b6a5
  by exactly the new table case meant for it, and each survives the same test at 10a3b58; no-change
  baseline passes on both. Patch-id of the PR's change is the same before and after the merge, and
  the merge needed no hand resolution. Root package in full on 4d7ed6d: ok. CI on 4d7ed6d: both
  required checks green ("test on macOS" 08:47:58Z, "build, vet and test" 08:59:29Z).
Sensitive-material handling: no secrets, keys, tokens, env files, SQLite or TLS/SPIFFE/Vault
  material read into the report or evidence.
Confidence: provenance high / validation high for the delta / implementation high.
Effect status: repair, commit, push, PR, merge not performed.
Report delivery: /mnt/project-files/reports/Execution-Substrate/workload-identity/30-pr74-recheck-opus.md
  (SHA-256 in the delivering message), evidence in 30-pr74-recheck-opus-evidence/ (SHA256SUMS inside).
Final verdict: ACCEPT
```

## In plain words

The new head does what writer report 30 says, and nothing else.

1. **The four new table rows work.** Each of the four scanner changes that re-check 29 named (GM14, GM26, GM22, GM24) now fails the scanner's table test, and each fails on exactly the row added for it. On the previous head the same test passed with each change, so it is the new rows that catch them.
2. **The merge of #75 did not change the PR.** The PR's own diff has the same patch-id on the new base as on the old one, and git merged without any hand edits. The merge does not touch the test file.
3. **CI is green** on 4d7ed6d on both required jobs, and the root package passes here too.

No finding. One observation: the PR body's "every scanner branch that re-checks 28 and 29 weakened" is killed holds if "weakened" means "made to let more through". Re-check 29's GM27 (`{3,4}` hex digits) still survives, but it can only make the scan stricter: it decodes more escapes, so it only adds to the count of declarations, and the count can only rise above what the scan reads (read is a subset of counted, re-check 29), never cancel a missing one. Writer report 30 says GM27 is left on purpose. The PR body's "26 cases" is right (counted at 4d7ed6d).

## Provenance (ran)

| Step | Result |
|---|---|
| Recipe bytes | `sha256sum -c` OK (`c08597e2…a3ca`) on the shared file and on the copy that ran, before the opening and closing runs (`provenance/recipe-hash*.txt`) |
| Pushed tip | `git ls-remote` at the start (08:14Z) and at the close (09:02Z): `refs/heads/claude/project-thread-ef7st5` and `refs/pull/74/head` = `4d7ed6d`, `trunk_dev` = `be20ffc` (`provenance/ls-remote-*.txt`) |
| Commits | `aa2b6a5` (parent `10a3b58`): the table cases. `4d7ed6d` (parents `aa2b6a5`, `be20ffc`): merge of trunk_dev. `0b9278c` (re-check 29's base) is an ancestor of `be20ffc` |
| Manifest | fresh clone from GitHub of the branch (`git status` clean at the tip), `git reset --mixed origin/trunk_dev` (be20ffc), upstream `origin/trunk_dev`; two runs, `cmp` identical, SHA-256 `89004ac6…3686`, **equal byte for byte** to `24-pr74-repair-evidence/manifest-v2-4d7ed6d-on-be20ffc.json`; 31 files |
| Closing run | same clone, untouched since the opening (no test ran in it); recipe re-verified; two runs identical and equal to the opening manifest |
| Delta digest | `git diff 10a3b58 aa2b6a5`: 1 file, +7, sha256 `40b2e10a…a87b`, equal to writer report 30 |
| Merge | `git diff 0b9278c aa2b6a5` and `git diff be20ffc 4d7ed6d` have the same `git patch-id --stable`: `63b7455bc01edd57de3445dfc2183b1b9b727cdd`. `git show --remerge-diff 4d7ed6d` is empty, so git's automatic merge is the committed result (no hand edits in the merge). Files both sides touch: `.docs/system_overview/contracts.md`, `PLANS.md`. `git diff be20ffc 4d7ed6d`: 31 files, +1811/-77, sha256 `80f0c38d…4abb4f`, equal to writer report 30 |

## The delta (read)

`caller_declaration_docs_contract_test.go`, four rows added to `TestEnvironmentDeclarationScanReadsEachSpelling` after the double-quoted "Python named escape" row, plus a three-line comment naming N29-1:

| Row | Text | Expected | Reaches |
|---|---|---|---|
| Python named escape, single-quoted | a single-quoted entry holding `\N{LATIN CAPITAL LETTER L}D_PRELOAD` | a problem | the single-quoted fallback of `decodeDeclaredEnvironmentEntry` (GM14) |
| key written with an upper-case escape | key `environment`, backslash-u `005F`, `variables` | a problem | the `[0-9A-Fa-f]{4}` class of `jsonUnicodeEscape` (GM26) |
| Go escape, double-quoted | `"LD_\x50RELOAD"` | entry `LD_PRELOAD`, no problem | the `strconv.Unquote` branch for double-quoted entries (GM22) |
| escaped quote, single-quoted | `'A\'B'` | entry `A'B`, no problem | the `\'` replacement for single-quoted entries (GM24) |

No code change; the scanner functions are byte for byte those re-check 29 audited. `gofmt -l` on the file: empty (ran).

## Mutants (ran)

My runner (`mutants/mutants30.py`) makes one exact replacement per mutant (the old text must occur once), runs only `TestEnvironmentDeclarationScanReadsEachSpelling` with `-v`, and restores the file. I wrote the four mutants from the N29-1 block's descriptions; I did not use re-check 29's or the writer's runners.

| Mutant | Change | 10a3b58 (before the delta) | aa2b6a5 (the delta) | Failing row at aa2b6a5 |
|---|---|---|---|---|
| M0 | none (baseline) | pass | pass | none |
| GM14 | single-quoted fallback returns `true` | survives | **killed** | "Python named escape, single-quoted: problems [], want a problem" |
| GM26 | `[0-9A-Fa-f]{4}` becomes `[0-9a-f]{4}` | survives | **killed** | "key written with an upper-case escape: problems [], want a problem" |
| GM22 | double-quoted `strconv.Unquote` branch disabled | survives | **killed** | "Go escape, double-quoted": a "cannot decode" problem and no entry |
| GM24 | `\'` replacement removed | survives | **killed** | "escaped quote, single-quoted": a "cannot decode" problem and no entry |

Each mutant fails exactly one row, the one added for it, so the rows are not redundant with each other or with the earlier table. That GM14 and GM26 survive the whole suite at 10a3b58 is re-check 29 Sonnet's measurement; I re-ran only the table test there, which is enough to show the kill comes from the new rows. Logs: `mutants/log-{10a3b58,aa2b6a5}.txt`.

## CI (CI)

`get_check_runs` on PR #74 at 09:02Z; the PR API shows head `4d7ed6d`, base `be20ffc`, `mergeable_state` clean.

| Check | Status | Started | Completed |
|---|---|---|---|
| test on macOS | success | 08:16:47Z | 08:47:58Z |
| build, vet and test | success | 08:12:22Z | 08:59:29Z |

Both are the required checks on `trunk_dev`. Links: [Linux job](https://github.com/evo-agi/Execution-Substrate/actions/runs/45963874995/job/140387805041), [macOS job](https://github.com/evo-agi/Execution-Substrate/actions/runs/45963874991/job/140387804966).

## Tests on the merged head (ran)

`go test -count=1 .` (root package, which holds the scanner and the docs-contract tests that read both files the merge touched) on 4d7ed6d: `ok` (`tests/root-4d7ed6d.txt`). Go 1.26.5, `GOPROXY=off`, no proxy variable.

## Limits

- Tests ran as root, not as an unprivileged user. The table test is a pure function, so the user does not matter for the mutant results. The full root package as root is a sanity run only; CI's normal-user run is the gate for the merged head.
- I did not re-run `es/admission` or the full suite: the delta is one test file and the merge's effect on the PR's patch is nil by patch-id. CI covers the rest, including #75's own code on this head.
- GM27 (`{3,4}` hex digits), left untested by the writer, is outside this scope; re-check 29 Sonnet rated it as changing nothing a decoder accepts.

## Evidence

`30-pr74-recheck-opus-evidence/` (SHA256SUMS inside):
- `provenance/`: the four manifests, recipe hash checks, `ls-remote` at open and close, `diffs.txt` (digests, patch-ids, remerge-diff size, files both sides touch), the delta diff, the remerge-diff output.
- `mutants/`: runner, logs and summaries for both trees.
- `tests/`: the root-package run on 4d7ed6d.
