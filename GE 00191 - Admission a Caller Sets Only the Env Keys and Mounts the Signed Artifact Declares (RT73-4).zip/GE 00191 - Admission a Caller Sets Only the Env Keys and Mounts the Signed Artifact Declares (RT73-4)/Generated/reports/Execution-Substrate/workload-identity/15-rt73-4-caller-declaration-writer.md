# Writer report 15: ES caller declarations, RT73-4 option (c)

Date: 2026-11-26, about 8:10 PM Eastern (2026-11-27 01:10Z). Writer: the "Stop callers injecting code into runs" thread.

## Target

| Item | Value |
| --- | --- |
| PR | evo-agi/Execution-Substrate #74, base `trunk_dev`, branch `claude/project-thread-ef7st5` |
| Base tip | `39e19defb0ea6c0bda30a14f88452b24f9bd9cdf` (#71 merged) |
| Head | `626c3cd7c163948ee7939f2f57ea7f271a79ae6f`, one commit; then `f8bc3df20e1e3c17751edd1751010644733991ab`, a clean merge of `trunk_dev` at `fbfd100` (#72) with no conflict. After the merge: root, `es/admission`, `es/api`, `es/config`, `internal/callerauth`, `internal/callerallowlist`, `cgs/policy`, `ags/publish` and `internal/contracts/evidence/v1` pass (`go test -count=1`), `go vet` clean |
| Head tree | `191c7be29464a6624b2fedd34897847c1f3f4616` |
| Diff `39e19de..626c3cd` | 28 files, +1159 / -71; `git diff 39e19de 626c3cd \| sha256sum` = `523ff52c31a27b9471fc478330a6c0e68f19958b066dfab97efeed8cc14c46e3` |
| Brief | coordinator relay, RT73-4 option (c), approved by David; red-team report `11-pr73-redteam.md`, section RT73-4 |
| Gate | product admission code plus one shared-kernel field: fresh audit, red-team, merge gate |

## Manifest

Product code:
- `internal/contracts/evidence/v1/execution_claims.go`: `ExecutionRuntime.MountTargets` (`mount_targets,omitempty`), signed as a trimmed, sorted set.
- `ags/publish/types.go`, `ags/publish/service.go`: AGS accepts `admission.runtime.mount_targets` and signs it as given.
- `es/admission/types.go`, `es/admission/service.go`: `RuntimeInterface.MountTargets`; `manifestFromEvidence` copies it; `validateInvocationAgainstManifest` enforces the rules; reserved key set and prefixes widened; `declaredStringSet`, `sortedMapKeys`, `isPortableEnvironmentKey`, `asciiUpper`.

Tests:
- New: `internal/contracts/evidence/v1/mount_targets_test.go`, `ags/publish/mount_targets_test.go`, `es/admission/caller_declaration_test.go`, `caller_declaration_docs_contract_test.go`.
- Changed to declare the mount targets they use: `es/admission/ars_blob_fetch_test.go`, `nomad_request_strings_test.go`, `reliable_submit_binding_test.go`, `resolved_execution_plan_test.go`, `submit_test.go`; `es/app/submit_integration_test.go`, `lifecycle_integration_test.go`, `resolved_plan_custody_hermetic_test.go`.
- New es/app test: `TestSubmitRefusesAMountTheSignedArtifactDoesNotDeclare`.
- `docs_contract_test.go`: three pinned phrases follow the new wording.

Docs: `.docs/execution_lifecycle/contracts.md` (section 5 request invariants, `:prepare` claims sentence, foundation sentence), `design.md`, `implementation.md`, `submit_idempotency_correlation_and_recovery.md`; `.docs/standing_rules/execution_admission_and_custody.md`; `.docs/system_overview/boundaries.md`, `contracts.md`, `shared_kernel.md`; `PLANS.md`; `README.md`.

No scripts, examples or config change.

## Design (repo-validated at 626c3cd unless labeled)

- The signed runtime interface is the only source of what a caller may set or mount. `es/admission/service.go:1002` (`validateInvocationAgainstManifest`).
- Environment, in order per key (keys in byte order): Nomad-evaluated text check (unchanged), portable name `[A-Za-z_][A-Za-z0-9_]*` (`service.go:1074`), reserved check (`service.go:1256`, ASCII fold at `:1275`), then membership in the declared list. An empty or absent list admits none.
- Mounts: the existing shape and overlap checks (`validateRuntimeMounts`, unchanged) run first, then exact membership of `target_path` in the declared `mount_targets` (`service.go:1041`). No prefix or subtree matching.
- Reserved set: `service.go:83` (keys) and `:184` (prefixes). Sources: glibc 2.42 `sysdeps/generic/unsecvars.h`; sudo 1.9.16p2 `plugins/sudoers/env.c` `initial_badenv_table` Linux entries plus `_JAVA_OPTIONS` and `CLASSPATH` from later sudo; ES additions (PATH, HOME, JDK_JAVA_OPTIONS, proxy and TLS-trust keys, prefixes PYTHON, GIT_, BASH_FUNC_, LD_, _RLD, KRB5_CONFIG). The existing ES keys (identity, Vault, SPIFFE, OTEL, `traceparent` now spelled `TRACEPARENT`) stay. Reserved keys are refused even when declared.
- Evidence: `mount_targets` is `omitempty` in both the claim and its canonical form (`execution_claims.go:21`, `:41`, `:65`), so a record signed before the field existed keeps its canonical bytes and seal.
- Name choice: `mount_targets` sits beside `environment_variables` in the same object. Inference: easy to rename before merge (one JSON tag in three structs, the docs, and the tests); it needs David's naming review per project procedure.

## Classified facts

- Contract/invariant: section 5 of the lifecycle contract now states the rules; `TestCallerDeclarationRulesAreInTheLifecycleContract` pins them.
- Compatibility edge: callers that send env to an empty-allowlist artifact, or mount at an undeclared target, are newly refused. Checked callers: ES examples, ES runbooks, `scripts/60_execute_loop.sh`, MA (d60e0d2), IM (9623f5c), Coordinator (aa8104f), the archived runbooks (static script declares and sends only `APP_MODE`; Vault runbook declares its key). Bridge-core has no ES invocation (code search returned nothing for `invocation`, `artifacts:prepare`, `executions:submit`). None is newly refused.
- Bounded proof: the RT73-4 replay (`TestCallerCannotPutItsOwnCodeIntoAGrantedNetworkRun`) runs against the admission harness, not a live box.
- Report-only uncertainty: argv is not bounded. An entrypoint that interprets its arguments as code (for example `sh -c "$@"`) still lets a caller choose what runs. The contract says argv is not bounded by a declaration. Bounding it is a separate decision.

## Validation

Commands run in a separate worktree checked out at 626c3cd (`/home/user/work/wt-run`), Go 1.26.5 toolchain from the repo:

- `go vet ./es/app/` and gofmt on changed files: clean.
- `go test -json -count=1` on every package except root, `es/app`, `es/runtimehelper`, `scripts`: all pass except three old-binary probes in `es/admission/internal/reliablesubmit` (`TestOperationalHandoffSchema4BinaryRefusesSchema5`, `TestSQLiteV3OldBinaryRefusesWithoutMutation`, `TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation`: "authenticated schema-4 opener is required"). The same three fail on 39e19de (re-run there with `go test -count=1 ./es/admission/internal/reliablesubmit/`).
- `go test -json -count=1 -timeout 60m . ./es/app ./es/runtimehelper ./scripts ./cmd/... ./scripts/internal/...`: root and `es/runtimehelper` pass; `es/app` 14 and `scripts` 38 failures, the same names as the 39e19de baseline. The baseline also listed root `TestGo1265ToolchainBaselineDocsAndBuildContract`; it passes now on both commits (re-run on 39e19de), so that baseline entry was this container's module cache at the time, not a code difference. Result files: `/tmp/claude-0/-home-user/879f9a63-04ba-536a-a288-146739885510/scratchpad/r3/` (ephemeral).
- Baseline for comparison: the same commands on 39e19de (`/home/user/work/es`), compared name by name.
- Mutation probes on `service.go`, each killed:
  - M1 empty allowlist admits all: `TestEmptyEnvironmentAllowlistAdmitsNoCallerKey`, `TestEnvironmentRefusalNamesTheFirstKeyInOrder`;
  - M2 no mount declaration check: `TestCallerMountNeedsATargetTheArtifactDeclares`, `TestCallerCannotPutItsOwnCodeIntoAGrantedNetworkRun`;
  - M3 no name rule: `TestCallerEnvironmentKeyMustBeAPortableName`;
  - M4 `PATH` not reserved: `TestReservedEnvironmentKeySetIsPinned`, `TestReservedEnvironmentKeysAreRefusedEvenWhenTheArtifactDeclaresThem`, `TestCallerCannotPutItsOwnCodeIntoAGrantedNetworkRun`;
  - M5 case-sensitive reserved match: `TestReservedEnvironmentKeysAreRefusedEvenWhenTheArtifactDeclaresThem`;
  - M6 mount check disabled, es/app: `TestSubmitRefusesAMountTheSignedArtifactDoesNotDeclare` (503 instead of 400).

- Codex review on 626c3cd: completed with no findings.
- CI (`build, vet and test`, `test on macOS`): running at the time of writing; the PR thread watches it.

## Skipped validation

- Three es/app mount tests need Docker and Nomad and skip in this container: `TestSubmitFlowMountsGovernedArtifactAndLifecycleStillWorks`, `TestSubmitFlowMountsGovernedArtifactAndLifecycleWithInstalledSourceIdentity`, `TestSubmitFlowRemovesRuntimeMountArchiveResidueAfterExtraction`. They now declare `mount_targets`; CI and the box are the reference.
- No live box run. The change is admission-only and refuses before any effect.

## Authority or security widening

- Narrowing, not widening: callers lose the ability to set undeclared env keys and to mount at undeclared targets.
- Shared kernel: `claims.admission.execution.runtime` gains one optional field, `mount_targets`. AGS signs it as given and judges nothing; ES alone decides. `shared_kernel.md` records why.

## Known interactions

- #73: one textual conflict, `.docs/system_overview/contracts.md`, the AGS `admission.access` bullet; whichever lands second keeps both bullets. All other shared files merge cleanly by `git merge-tree`. #73 adds no test that sends caller env or mounts.
- #69 moves the PLANS.md section with the "change environment or mount admission" sentence.

## Confidence

- Provenance: high. One commit, hashes above; the full runs used the same commit.
- Validation: high for admission and AGS units and es/app without Docker; medium for the three Docker/Nomad mount tests until CI runs them.
- Implementation: high that the declaration is now the boundary on env and mounts. Medium that the reserved list is complete for every runtime a publisher might use; it is a backstop by design and the contract says so.
