# Re-check 28 (Opus): ES PR #74 at 0e56e23: BLOCK (one low finding, one nit; R27-1/F1, the three reservations, the pins and the Archived-Runbooks claim hold)

Date: 2026-11-27, about 2:10 AM Eastern (07:10Z). Thread: "Opus re-check 28 of PR 74", fresh and read-only. I did not write #74 and did not audit it before this round. Blind pair in the model-evaluation trial (category R-M, security): I did not read the Sonnet report for this round or its evidence folder, and I messaged no thread. Model: [model withheld]. Inputs read: re-checks 27 (Opus and Sonnet) and writer report 28.

Source labels: "ran" means I ran it in this container on the commit named; "read" means I read the code, document or upstream source and did not run it; "CI" means read from GitHub; "Inference:" marks my reasoning.

```text
INDEPENDENT AUDIT REPORT (narrow re-check of a repair, protocol §14)
Repository / Audit target:
  evo-agi/Execution-Substrate PR #74, branch claude/project-thread-ef7st5
  base 0b9278ca74404b46b5e9f0e1701874b52687f5e8 (trunk_dev, #69)
  topic commit 0e56e23ed9c5ba4742f5967d145373dc157c3a64, tree 3be25b02a4fc447dce00db61e4ed403aea197378
  recipe governed-execution.audit-patch-manifest.v2, source SHA-256
    c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (sha256sum -c OK before each run)
  canonical-manifest SHA-256 731646edec2a92fd89d746490ae50671ba984731c172bb4d86d7f3f8dc297fd5, 31 paths,
    textual_diff_sha256 eca96ce341048e2563e1fff05e1eed49077198fa7a5457f2571864d9e5fa7fd7
  Scope (coordinator): git diff 956991c 0e56e23 (4 files). R27-1/F1 (MAKE, CXX_MODULE_MAPPER,
    MSP430_GCC_INCLUDE_DIR reserved; the contract names its source exactly as the whole GCC 14.2.0
    manual plus LPATH and OBJCPLUS_INCLUDE_PATH, and states what the class leaves out); the runbook
    guard reading declarations like ES (padded, \u-escaped, single-quoted; failing on spellings it
    cannot read); the new pins; the claim that Archived-Runbooks' daily check forces the copy
    refresh (draft AR PR #30). Source closed: measured only against the GCC 14.2.0 manual and the
    two keys the contract adds; no new source opened.
Audit posture: read-only. Parent only, no subagents. Nothing pushed, nothing posted on GitHub, no
  Linux box, no live service. Tests, probes and mutants ran as an unprivileged user (ci, uid 1500)
  in clones made from a bundle, never in the provenance clone.
Provenance reproduction: equal to writer report 28's manifest file, byte for byte; opening and
  closing runs identical (two runs each).
Findings: 1 low (R28-1), 1 nit (N28-1). No medium or higher. 4 observations.
Validation assessment: full suite on head and on 956991c as an unprivileged user: the same 59
  failing names (15 top-level) on both, the same top-level test set, no status change. 31 mutant
  and fix runs: every claimed fix is killed when reverted; 6 declaration spellings and 3 guard
  self-protections survive (N28-1, O1, O2). Both proposed fixes pass the affected tests.
  CI on 0e56e23: "test on macOS" green; "build, vet and test" (Linux) still running at
  07:08Z. The verdict does not depend on it, and a fix makes a new head that needs its own CI.
Sensitive-material handling: no secrets, keys, tokens, env files, SQLite or TLS/SPIFFE/Vault
  material read into the report or evidence.
Confidence: provenance high / validation high / implementation high for the claimed fixes;
  high that R28-1 is the last gap in the manual (every name in all 30 files placed, below).
Effect status: repair, commit, push, PR, merge not performed.
Report delivery: /mnt/project-files/reports/Execution-Substrate/workload-identity/28-pr74-recheck-opus.md
  (SHA-256 in the delivering message), evidence in 28-pr74-recheck-opus-evidence/ (SHA256SUMS inside).
Final verdict: BLOCK
```

## Why BLOCK, in plain words

Everything the repair claims holds: the three keys are reserved, pinned and refused; the contract now names its source as the whole manual; the guard reads padded, `\u`-escaped and single-quoted entries; the pins kill every contract change I tried; and the Archived-Runbooks check behaves exactly as the writer says.

It blocks on two small things, both inside the stated limits:

1. **R28-1 (low).** The manual names one more key that a GCC program reads to choose its headers and libraries: `VSB_DIR`. It appears in the spec-file section's example `%:getenv(VSB_DIR rtnet.h)`, and that example is taken from gcc's own VxWorks 7 specs, which read `VSB_DIR` to add header directories and pick a library. That is the same standing as `MSP430_GCC_INCLUDE_DIR`, which the writer reserved so the sentence holds literally. The writer placed `VSB_DIR` with `TOPDIR` as "examples of a spec file's getenv". That is right for `TOPDIR` (no GCC source reads it) and wrong for `VSB_DIR`. My own re-check 27 missed `VSB_DIR` entirely, and so did Sonnet's. Reach is nil on a native compiler. The fix is one map entry plus the pin, a refusal sample and the contract name (tested).
2. **N28-1 (nit).** The guard says it "fails on a declaration in a spelling it cannot read". AGS decodes the declaration's key with Go's `encoding/json`, which also accepts `ENVIRONMENT_VARIABLES`, `environment\u005fvariables` and `environment_variableſ`, and takes the later of two duplicates. The guard neither reads nor counts those spellings, so a reserved key declared under them passes. This is the same kind of gap as N27-1. A five-line fix (count after decoding `\u` escapes, case folded) is tested, or the comment can say what it reads.

If the coordinator reads the manual's spec examples as outside "names", R28-1 becomes an observation. N28-1 alone would then be a nit, and the result would be BLOCK (nits) under the project's rule that nits are fixed in the PR.

## Provenance (ran)

| Step | Result |
| --- | --- |
| Recipe bytes | `sha256sum -c` OK (`c08597e2…a3ca`) on the shared file and on the copy that ran, before the opening and the closing runs |
| Pushed tip | `git ls-remote` at 06:29Z and again at 07:01Z: `refs/heads/claude/project-thread-ef7st5` and `refs/pull/74/head` = `0e56e23`, `trunk_dev` = `0b9278c` |
| Base ancestry | `git merge-base --is-ancestor 0b9278c 0e56e23`: yes; `0e56e23`'s parent is `956991c`, no merge |
| Opening manifest | fresh clone, branch checked out at the tip (`git status` clean), `git reset --mixed 0b9278c`, upstream `origin/trunk_dev` = `0b9278c`; two runs, `cmp` identical, SHA-256 `731646ed…7fd5`, equal byte for byte to `24-pr74-repair-evidence/manifest-v2-0e56e23-on-0b9278c.json` |
| Committed blobs | 31 of 31 records equal the blob at `0e56e23` (SHA-256 and size); every mode `0644`; path set equals `git diff -z --name-only 0b9278c 0e56e23` |
| Diffs | `git diff 956991c 0e56e23`: 4 files, +112 / -32, `\| sha256sum` `bc557584…3e79`; `git diff 0b9278c 0e56e23`: 31 files, +1714 / -77, `8d9fd445…9938` (both equal to report 28) |
| Closing run | 07:01Z, same clone, recipe re-verified: two runs identical and equal to the opening manifest |

## What the delta changes (read)

- `es/admission/service.go`: three map entries (`MAKE`, `CXX_MODULE_MAPPER`, `MSP430_GCC_INCLUDE_DIR`, :316-318) and the comment above the single keys, re-worded and re-wrapped (longest line 75 columns with tabs counted as one; N27-2 fixed). `isReservedRuntimeEnvKey` (:1462: `strings.TrimSpace`, then `asciiUpper`, exact keys, prefixes, suffixes) and its one caller (:1237, after `isPortableEnvironmentKey`) are unchanged.
- `es/admission/caller_declaration_test.go`: the three keys in the pin and in the refusal table (with `make`), and `MAKE_TARGET` as a near miss.
- `.docs/execution_lifecycle/contracts.md:525,527`: the gcc parentheses name the three keys and the source ("every such key a GCC program reads that the GCC 14.2.0 manual, `gcc/doc/gcc.texi` and the files it includes, names in any section, …"); a new sentence after the stay-open sentences puts the built program's keys (`ASAN_OPTIONS`, `GCOV_PREFIX`) outside the class.
- `caller_declaration_docs_contract_test.go`: seven new or lengthened required phrases; the matcher now trims and folds only ASCII letters; the guard decodes entries, reads single-quoted lists, counts every `environment_variables` followed by `:` or `=` and `[`, requires a declaration in each of `.runbooks`, `.examples` and `scripts`, and checks its own matcher.

## The claimed fixes

| Item | Verdict | Evidence |
| --- | --- | --- |
| R27-1 / F1: `MAKE`, `CXX_MODULE_MAPPER`, `MSP430_GCC_INCLUDE_DIR` reserved | Fixed | Key probe on the real function at `0e56e23` (ran, `probes/key-probe-0e56e23.tsv`): all three reserved, also as `make`, `" MAKE"`, `"make\t"`, `"MAKE "` and `Cxx_Module_Mapper`; `MAKE_TARGET` and `MAKEFLAGS`' neighbours behave as the tests say. Dropping any one is killed by the pin, the refusal test and the contract test (M01-M03); reserving `MAKE` as a prefix is killed by the pin and the `MAKE_TARGET` near miss (M04). Effects of `MAKE` and the mapper were shown by both re-checks 27; I did not rerun them. |
| The contract names its source as the whole manual | Holds as wording; one key missing | The clause names `gcc/doc/gcc.texi` "and the files it includes … in any section". I fetched `gcc.texi` at `releases/gcc-14.2.0` and every file it includes, recursively: 30 files (`upstream/manual/`, hashes inside; only the build-generated `gcc-vers.texi` is not in the tree). Every name placed below. One key in the class is open: R28-1. |
| "the two that gcc's driver and preprocessor read and the manual leaves out, `LPATH` and `OBJCPLUS_INCLUDE_PATH`" | Exact | `LPATH` appears nowhere in the 30 files. `OBJCPLUS_INCLUDE_PATH` appears only as a Texinfo comment, `cppenv.texi:17-18`: "@c Commented out until ObjC++ is part of GCC: @c @itemx OBJCPLUS_INCLUDE_PATH", which the rendered manual omits. The driver reads `LPATH` (`gcc.cc:4918`) and the preprocessor reads the `incpath.cc` table (read). |
| The class leaves out the built program's keys, "such as … `ASAN_OPTIONS` and … `GCOV_PREFIX`", which "are not reserved" | Holds | Key probe: the five sanitizer `*_OPTIONS`, `VTV_LOGS_DIR` and the four `GCOV_*` keys are open. No file under `gcc/` reads any `GCOV_*` key (grep at the tag; libgcov reads them). The sentence sits after "The exact list is …", so the contract test, which judges only the text before it, does not read these names as reserved (read, `caller_declaration_docs_contract_test.go:175-215`). |
| N27-1 / Sonnet O1: the guard reads padded, `\u`-escaped and single-quoted entries | Fixed | D01 (`"\u004cD_PRELOAD"`), D02 (`" LD_PRELOAD"`) and D03 (a single-quoted Python list) are killed by the guard. The matcher trims with `strings.TrimSpace` and folds only `a`-`z`, which is exactly `isReservedRuntimeEnvKey` (service.go:1462-1490); the self-check kills a matcher that stops trimming (M05) or folds with Unicode case (M06). |
| The guard "fails on a declaration in a spelling it cannot read" | Holds for the forms it counts; not for key-name spellings AGS accepts | Killed: an unquoted key `environment_variables: [` (D10) and a Python keyword argument `environment_variables=[` (D11). Survive: N28-1 (D04-D07). |
| Sonnet H5: a declaration needed in each root | Fixed | The check is at `caller_declaration_docs_contract_test.go:279-283`; disabling it survives on the real tree (M09, O2), as expected for a check that only fires when a root is empty. |
| N27-2: comment wrap | Fixed | Longest line in the block 75 columns (service.go:218), gofmt clean. |
| Sonnet O2 / Opus O1: the new pins | Hold | Killed: dropping the `CXX_MODULE_MAPPER` clause (C01), the scope sentence (C02), narrowing the source to one section (C03), dropping `MSP430_GCC_INCLUDE_DIR` from the contract (C04), all by `TestCallerDeclarationRulesAreInTheLifecycleContract`. Naming a key the code does not reserve (`VSB_DIR`, C05) is killed by both docs tests. The writer's C1-C10 cover the rest; I did not rerun them. |
| Sonnet O5: Archived-Runbooks' daily check forces the copy refresh | Holds, with one timing note (O3) | Read: `.github/workflows/es-runbook-copies.yml` runs `check_es_runbook_copies.py trunk_dev` on `schedule` (`17 10 * * *`), on every pull request, on pushes to `main` and by hand. The script fails unless each copy, minus its note and with its trunk_dev links made relative, equals the ES file byte for byte. Ran the script (AR `main` 8d99aa0 and PR #30 head d65e8df, each against ES `trunk_dev` 0b9278c and `0e56e23`): main vs trunk_dev 0 problems; main vs 0e56e23 1 problem (the reference-workload copy); PR #30 vs trunk_dev 1 problem (same file); PR #30 vs 0e56e23 0 problems (`ar/`). So once #74 merges, every scheduled run on `main` and every AR pull request fails until the copy is refreshed. The check reads only that the note names some commit, not which, so PR #30 passes after the merge even before its note is re-pointed. |

## Placement of every name in the GCC 14.2.0 manual (ran: extraction; read: classification)

Extraction: all `@env{}` (29 names), all `@vindex` (including four commented out), the `cppenv.texi` table, every upper-case token within 300 characters of "environment variable", `getenv` or `@env{`, every token with an underscore within 500 characters of "environment", "getenv" or "variable", and every `$NAME` (`upstream/manual/`).

| Group | Names | Placement |
| --- | --- | --- |
| In the class, reserved | `GCC_EXEC_PREFIX`, `COMPILER_PATH`, `LIBRARY_PATH`, `CPATH`, `C_INCLUDE_PATH`, `CPLUS_INCLUDE_PATH`, `OBJC_INCLUDE_PATH`, `GCC_COMPARE_DEBUG`, `DEPENDENCIES_OUTPUT`, `SUNPRO_DEPENDENCIES`, `MAKE`, `CXX_MODULE_MAPPER`, `MSP430_GCC_INCLUDE_DIR`; `PATH`, `TMPDIR` reserved elsewhere | key probe: all reserved |
| **In the class, open** | **`VSB_DIR`** | **R28-1** |
| Locale and diagnostic text or layout, open by design | `LANG`, `LC_ALL`, `LC_CTYPE`, `LC_MESSAGES` (and `LC_COLLATE`, `LC_MONETARY`, `LC_NUMERIC`, `LC_TIME`, which appear only in `@c` comments), `SOURCE_DATE_EPOCH`, `GCC_EXTRA_DIAGNOSTIC_OUTPUT`, `GCC_COLORS`, `GCC_URLS`, `TERM_URLS`, `COLUMNS` | read by `diagnostic.cc`, `diagnostic-color.cc`, `pretty-print.cc`, `intl.cc`; the contract's stay-open sentences cover them in kind |
| Read by the built program, outside the class by the new sentence | `ASAN_OPTIONS`, `HWASAN_OPTIONS`, `LSAN_OPTIONS`, `TSAN_OPTIONS`, `UBSAN_OPTIONS`, `VTV_LOGS_DIR`, `GCOV_PREFIX`, `GCOV_PREFIX_STRIP`, `GCOV_ERROR_FILE`, `GCOV_EXIT_AT_ERROR`, and `DEBUG`, the example program's own `getenv ("DEBUG")` in an ifunc resolver (`extend.texi:3392`) | none read under `gcc/`; `DEBUG` was in no earlier table and changes nothing |
| Not environment reads of a GCC program | `GCC_INCLUDE_DIR`, `TARGET_SYSTEM_ROOT` (configure-time macros; `gcc.cc` reads only the five `env.get` names at :4746-5444 plus spec `getenv`), `TOPDIR` (the `getenv` spec example; no file in `gcc/`, `libcpp/`, `libiberty/` or `libgcc/` names it), `PATH_SEPARATOR` (a macro), `$SYSROOT` (a literal token gcc replaces in `-I` arguments) | read |

## Findings

```text
AUDIT FINDING R28-1
Type / Severity: contract drift (the completeness claim is false in its own named source) / low
Current contract: .docs/execution_lifecycle/contracts.md:525 (0e56e23): the GNU C compiler's keys
  "that choose the programs it runs, the headers and libraries it builds with, …: every such key a
  GCC program reads that the GCC 14.2.0 manual, `gcc/doc/gcc.texi` and the files it includes, names
  in any section". The code comment (service.go:202-214) and writer report 28 say the same.
Path and line (0e56e23): es/admission/service.go:84-321 (reservedRuntimeEnvKeys; no VSB_DIR, and no
  prefix or suffix covers it); key probe: "VSB_DIR" open, "vsb_dir" open.
Evidence (read; GCC tag releases/gcc-14.2.0, commit 04696df0):
  - The manual names it. invoke.texi:37012, in the spec-file section under if-exists-then-else:
    "-l%:if-exists-then-else(%:getenv(VSB_DIR rtnet.h) rtnet net)". invoke.texi:36965-36969: "The
    getenv spec function takes two arguments: an environment variable name and a string."
  - A GCC program reads it. The driver's getenv spec function reads the named variable from the
    environment (gcc.cc:10294-10307, `value = env.get (varname);`). gcc's own VxWorks 7 specs call it:
    gcc/config/vxworks.h:86-93, VXWORKS_ADDITIONAL_CPP_SPEC, "-idirafter %:getenv(VSB_DIR /h)" and
    "-idirafter %:getenv(VSB_DIR /share/h)" (header directories), and :145, VXWORKS_NET_LIBS_RTP,
    "-l%:if-exists-then-else(%:getenv(VSB_DIR /usr/h/public/rtnetStackLib.h) rtnet net)" (which
    library to link). TARGET_VXWORKS7 is set for *-*-vxworks7* (config.gcc:1146-1147). The manual's
    example is this spec, shortened.
  - So VSB_DIR is a key a GCC program reads, the manual names it, and it chooses headers and a
    library: inside the sentence's class, like MSP430_GCC_INCLUDE_DIR (also a cross-compiler-only
    key the manual names in a target section, reserved in this repair "so the sentence holds
    literally").
  - Writer report 28 lists VSB_DIR with TOPDIR as "examples of a spec file's getenv". TOPDIR is
    read by no GCC source (grep of gcc/, libcpp/, libiberty/, libgcc/ at the tag: none). VSB_DIR is.
    Re-check 27 (mine and Sonnet's) did not list VSB_DIR at all: both enumerations took @env and
    prose names and missed a name that appears only inside a spec example.
Impact: none on a native compiler; a VxWorks 7 cross gcc would add a caller-chosen directory to
  the header search (after the system directories) and pick a library by a caller-chosen file's
  existence. No artifact in the project declares it (ran: `git grep VSB_DIR` at 0e56e23 finds nothing;
  GitHub code search `VSB_DIR org:evo-agi`, default branches, 0 results).
  The weight is the contract's categorical claim: a reader takes every manual-named key of these
  kinds as reserved.
Required correction: reserve VSB_DIR by name; add it to mustBeReservedEnvironmentKeys, to the
  refusal table and to the contract's gcc parentheses (and so to the required phrase). Tested
  (mutants/fix-R28-1-VSB_DIR.diff, 5 one-line edits in 4 files, gofmt clean): the targeted
  es/admission set (`TestReserved|TestOrdinary|TestEmptyEnvironment|TestCaller|TestDeclared|
  TestEnvironmentRefusal|TestOperationalRetained|TestRedTeam`) and the root docs tests pass (F1).
  Alternative: say that names appearing only in the manual's spec-language examples are outside
  the source. I recommend reserving: one line, and the sentence then holds as written.
Uncertainty: none on the facts. I did not build a VxWorks cross compiler; the effect is read from
  the spec text and the getenv spec function.
Patch defect or pre-existing issue: patch defect in 0e56e23 (the "names in any section" wording is
  new there); the key itself was open before the PR.
```

```text
AUDIT FINDING N28-1
Type / Severity: test gap (the guard's own claim is wider than what it reads) / nit
Current claim: caller_declaration_docs_contract_test.go:222-226 (0e56e23): the scan "reads an entry
  as a publish request carries it … and fails on a declaration in a spelling it cannot read";
  writer report 28: "so a new spelling cannot slip past".
Path and line (0e56e23): caller_declaration_docs_contract_test.go:239-241 and :262-265 (the
  `declaration` and `anyDeclaration` patterns are case-sensitive and match only the literal text
  `environment_variables`).
Evidence (ran):
  - AGS decodes a publish request with httpx.DecodeStrictJSON (ags/api/server.go:89-90,
    internal/httpx/httpx.go:12-23: encoding/json with DisallowUnknownFields). Probe through that
    function into publish.PublishRequest (probes/ags-decode-probe-0e56e23.tsv): the key spellings
    "ENVIRONMENT_VARIABLES", "environment\u005fvariables", "environment_variable\u017f" (U+017F, both
    escaped and as raw UTF-8) each fill admission.runtime.environment_variables with ["LD_PRELOAD"];
    an object holding "environment_variables":["APP_MODE"] then "ENVIRONMENT_VARIABLES":["LD_PRELOAD"]
    yields ["LD_PRELOAD"] (the later key wins). A padded key name is refused (unknown field).
  - Mutants on the head: an example declaring LD_PRELOAD under "ENVIRONMENT_VARIABLES" (D04), under
    "environment\u005fvariables" (D05), as a second, upper-case key after its real declaration (D06),
    and a runbook key ending in U+017F (D07): all four pass every test.
Impact: none on runs (ES still refuses the caller's key at submit). The guard exists to catch the
  "publishes fine, refused at submit" case in the repository's own publish requests, and these
  spellings bypass both its reading and its count. Same kind as N27-1.
Required correction: either count declarations after decoding \uXXXX escapes and with case folded,
  so any such spelling fails the count and asks for the scan to learn it (tested,
  mutants/fix-N28-1-guard-spellings.diff, 5 lines added: `(?i)` on anyDeclaration plus a \u pre-pass;
  Go's (?i) folds U+017F with s as encoding/json does; the real tree passes, F2; D04-D07 are then
  killed by the count, F2+D04..D07), or narrow the comment to "fails on a lower-case, unescaped
  `environment_variables` it cannot read". I recommend the code change.
Patch defect or pre-existing issue: patch defect (0e56e23 adds the claim).
```

## Observations (no correction required by this re-check)

- **O1. Entries outside the stated decoding are read raw, silently.** A runbook entry using a Python named escape (`"\N{LATIN CAPITAL LETTER L}D_PRELOAD"`, D08) and a `run.sh` list whose first entry holds `]` before a reserved one (`["A]B", "LD_PRELOAD"]`, D09) both survive. The writer's stated decoding is JSON then Go escapes, so D08 is outside it; D09's `A]B` can never match a caller key, since ES admits only ASCII letters, digits and underscores (`isPortableEnvironmentKey`, service.go:1234). If the writer touches the guard for N28-1, failing on an entry neither decoder reads would close D08 too; not required.
- **O2. Three of the guard's own checks have no self-check.** Turning off entry decoding (M07), the spelling count (M08) or the per-root check (M09) passes on the real tree, because the repository holds no escaped entry, no odd spelling and no empty root. That is normal for checks that fire only on a violation. The matcher has a self-check (M05 and M06 are killed); the decoder and the count could get one line each in the same way. I raise nothing.
- **O3. The Archived-Runbooks trigger fires daily, but late.** The three scheduled runs so far started at 2026-11-24 20:40Z, 11-25 19:57Z and 11-26 19:39Z, not 10:17Z (CI, run list of `es-runbook-copies.yml`, all green, actor David's account, which last edited the schedule, so GitHub's failure notices go there). Whether the check is required on AR `main` is Unknown (I did not read branch protection). Neither changes the claim: the check fails on `main` and on every AR pull request from the first run after #74 merges until the copy is refreshed. PR #30 currently shows the expected failure (`mergeable_state` "unstable").
- **O4. Seen outside the closed source, not judged.** `WIND_BASE` (read by `gcc/config/vxworksae.h:27` and the Ada VxWorks link specs) and `OFFLOAD_TARGET_NAMES` / `OFFLOAD_TARGET_DEFAULT` (`lto-wrapper.cc:951,1019`) are read by GCC programs, but the manual does not name them; the `COLLECT_*` keys are as in re-check 27's O2. All open (key probe). I list them only so a later round does not count them as new within the class.

## Validation

All runs as `ci` (uid 1500), `umask 022`, `env -i` (no proxy variables), Go 1.26.5 (`/opt/go1265`, `GOTOOLCHAIN=local`, `GOPROXY=off`, module cache filled first), one clone per tree from a bundle (trees `3be25b02…` and `5e03010a…` checked). Installed first: acl, iproute2, openssh-client, uuid-runtime, the `en_US.UTF-8` locale. Command: `go vet . ./es/... ./scripts/... ./internal/... ./ars/... ./ags/... ./egs/... ./cgs/...`, then `go test -count=1 -timeout=30m -json ./...`, one tree at a time: head 06:39:19Z-06:47:12Z, `956991c` 06:47:12Z-06:55:05Z. Only the short probe run (two packages) overlapped the head run.

| Tree | Top-level pass / skip / fail | Compared |
| --- | --- | --- |
| `956991c` (the re-checked head of round 27) | 1865 / 87 / 15 | |
| `0e56e23` | 1865 / 87 / 15 | the same 59 failing names (with subtests), the same top-level test set (the delta adds subtests only), no status change (`tests/summary.txt`) |

`go vet`: clean on both. `git status --porcelain` after each run: empty. The 15 failing top-level tests are re-check 27's 14 environment-only names plus `TestLinuxSetupGoToolchainInstallerHermeticPreflightAndCleanup` (es/app). That one failed because I launched both runs under `nohup`, which leaves SIGHUP ignored; rerun on the head with HUP, INT, QUIT and TERM reset (`tests/sigreset.py`), it passes. It failed the same way on both trees.

**Mutants and fix checks** (ran; runner `mutants/mutants.py`, two fresh clones of the head, `git status` empty before each, umask 022; log `mutants/log-{a,b}.jsonl`). Sets: `adm` = the targeted es/admission set above, `root` = `go test . -run 'TestCallerDeclaration|TestLifecycleContract|TestRunbooksAndExamples'`. Baseline B0: both sets pass.

| ID | Change | Result |
| --- | --- | --- |
| M01-M03 | `MAKE`, `CXX_MODULE_MAPPER`, `MSP430_GCC_INCLUDE_DIR` dropped | killed: the pin, the refusal test, the contract test |
| M04 | `MAKE` reserved as a prefix | killed: the pin, `MAKE_TARGET` near miss |
| M05, M06 | matcher stops trimming; matcher folds with Unicode case | killed: the matcher self-check |
| M07, M08, M09 | entry decoding off; spelling count off; per-root check off | survived (O2) |
| D01, D02, D03 | entry `"\u004cD_PRELOAD"`; entry `" LD_PRELOAD"`; single-quoted Python list | killed: the guard |
| D10, D11 | unquoted key `environment_variables: [`; Python `environment_variables=[` | killed: the spelling count |
| D04-D07 | key spelled `ENVIRONMENT_VARIABLES`, `environment\u005fvariables`, a second upper-case key, key ending in U+017F | **survived** (N28-1; power-checked through AGS's decoder) |
| D08, D09 | Python named escape in an entry; `]` inside an earlier entry | survived (O1) |
| C01-C04 | contract drops the mapper clause, the scope sentence, the "any section" source, `MSP430_GCC_INCLUDE_DIR` | killed: the required phrases |
| C05 | contract names `VSB_DIR` as reserved before any code change | killed: both docs tests |
| F1 | R28-1 fix | both sets pass |
| F2; F2+D04..D07 | N28-1 fix alone; with each surviving spelling | passes; all four then killed by the count |

A first pass of these runs used `su`'s default umask 0002 and showed false kills in `TestRedTeamRecheck31*` (operational fixtures; they fail on the clean head under that umask too). I discarded it and reran everything with umask 022; the first pass is kept in `mutants/first-run-umask0002/` for the record.

## CI (CI)

Read through the GitHub connector at 06:57Z-07:10Z; I ran nothing on GitHub.

| Check | Run / job | Time (UTC) | Result |
| --- | --- | --- | --- |
| test on macOS | 45951497624 / 140348160640 | 06:27:04 to 06:57:49 | success |
| build, vet and test (Linux) | 45951497649 / 140348160543 | started 06:23:05 | still running at 07:08Z (the round-27 head took 46 minutes) |

## Coverage this environment could not give

- No Docker daemon, Nomad, Vault or SPIRE here; CI runs the `es/app` flows.
- No VxWorks or msp430 cross compiler: `VSB_DIR` and `MSP430_GCC_INCLUDE_DIR` effects are read from GCC's spec and source text.
- I did not read AR's branch protection, so whether its check is required on `main` is Unknown.
- I did not rerun the writer's C1-C10, U1-U11 or the `MAKE` and mapper demonstrations; my own mutants overlap them where listed.

## Trial-log row (model evaluation, category R-M, security)

| Date | Category | PR @ head | Scope | Model | Verdict | Findings | Later outcome |
|---|---|---|---|---|---|---|---|
| 2026-11-27 | R-M | ES #74 @ 0e56e23 | narrow re-check (pair) | [model withheld] | BLOCK | R28-1 Low (VSB_DIR: the manual names it in a spec example, gcc's VxWorks 7 specs read it for headers and a library; open though the contract says every manual-named key of the kinds is reserved; also missed by both re-checks 27), N28-1 nit (guard does not read or count declaration keys AGS's encoding/json accepts: upper case, \u-escaped, U+017F, later duplicate; D04-D07 survive, power-checked), 4 obs. All R27-1/N27-1/N27-2/pin/AR claims verified; same failing names as 956991c; both fixes tested | paired with the Sonnet row; reports workload-identity/28-pr74-recheck-{opus,sonnet}.md |

## Evidence

`28-pr74-recheck-opus-evidence/`:

- `provenance/`: the four manifests, the recipe hash that ran, the delta diff and digests.
- `tests/`: runner, signal wrapper, summarizer, summary, failing lists, vet, status, timings, both `go test -json` logs gzipped.
- `probes/`: the key probe and the AGS decode probe (as `.go.txt`), their runner and outputs.
- `mutants/`: runner, launcher, logs, the discarded umask-0002 pass, both fix diffs and the diff maker.
- `upstream/manual/`: the 30 files of the GCC 14.2.0 manual as fetched, with hashes; `upstream/gcc-sources/`: `vxworks.h`, `vxworksae.h` and an excerpt of every environment read cited, with file hashes and the tag's commit.
- `ar/`: the four copy-check outputs and the workflow file.
- `SHA256SUMS`.

STATUS: READY (re-check delivered, verdict BLOCK on one low and one nit; both fixes tested)
