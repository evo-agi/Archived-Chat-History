# Narrow re-check 27 (Sonnet): ES PR #74 repair after re-check 25: BLOCK (one Low finding, one nit; every claimed fix holds)

Date: 2026-11-27, about 12:40 AM Eastern (05:40Z). Auditor: thread "Sonnet narrow re-check of PR 74 at 956991c". Model: `[model withheld]`. Model-evaluation trial, category R-S (narrow re-check, small); another model checks the same scope independently and I did not read its output (`27-pr74-recheck-opus.md` was not opened). I did not write or audit any part of #74 before. As the brief asked, I read re-checks 25 (Opus and Sonnet) and writer report 26.

Source labels: "ran" means I ran it in this container on the commit named. "Read" means I read code, a document or upstream source and did not run it. "Inference:" and "Guess:" mark the rest.

```text
INDEPENDENT AUDIT REPORT (narrow re-check of a repair, protocol §14)
Repository / Audit target:
  evo-agi/Execution-Substrate PR #74, branch claude/project-thread-ef7st5
  base trunk_dev 0b9278ca74404b46b5e9f0e1701874b52687f5e8 (#69)
  topic commit 956991c1b78b5a21a072ddf463a6327249077031, tree 5e03010aec5bd24661f2a5de70d974e137a719fd
  recipe governed-execution.audit-patch-manifest.v2, source SHA-256
    c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (sha256sum -c OK before each pair of runs)
  canonical-manifest SHA-256 0e8c5d6256ba7e506c04c0b325218707689f11a252616311f24aa67b5fbf547b, 31 paths,
    textual_diff_sha256 b04f27a9b8f309a1a2a6348d6d30fc68431662932c2f740954a995b76562bfd4
  Scope: git diff e0b5c89 956991c (4 files, +121/-36, sha256 86c2668c...62af). Re-check 25's F1 (five keys), its
    docs nit N1 and the runbook finding O1, and the two extras: the PKG_CONFIG family and gcc's dependency-file keys.
Audit posture: read-only, parent only, no subagents. Nothing pushed, nothing posted on GitHub, no box, no merge.
  Tests, probes and mutants ran in separate clones owned by an unprivileged user (uid 1500); the provenance clone ran
  no tests.
Provenance reproduction: reproduced twice, identical; equal to the writer's manifest file byte for byte; closing
  runs equal the opening; pushed tip, PR ref and trunk_dev re-read at start and close, unchanged; all 31 committed
  blobs equal their manifest records; path set equals git diff --name-only; every mode 100644.
Coverage: every hunk of the 4-file delta; the PR body; the only other copy of the changed sentences (none: the
  contract is the one doc); every use of the newly reserved keys in this repo and in the project's other repos; the
  go help environment list (all 54 keys) and the GCC 14.2 manual's environment names (all 29), each against the real
  reserved-key function at base, e0b5c89 and the head; the GCC 14.2 sources that read the two keys in F1.
  Not covered: see "Coverage this environment could not give".
Findings: 1 Low (F1), 1 nit (N1). 7 observations. No finding against the substance of the claimed fixes.
Validation assessment: whole suite on exact bytes for head and base as an unprivileged user: the same 43 failing
  names (13 top-level) on both, 19 tests only at the head and all pass, none only at base, no status change. 44
  mutants of my own: 31 killed, 13 survived (each classified below; F1's cause is not among them, it is a missing
  entry no test can see). A 146-key probe of the real function. The proposed fix for F1 passes the affected tests.
  CI on 956991c: both required checks green.
Sensitive-material handling: no secrets, keys, tokens, env files, SQLite or TLS/SPIFFE/Vault material read.
Remaining uncertainty and stop conditions: none that blocks the verdict. The verdict is BLOCK on F1 whatever CI
  says, and a fix creates a new head that needs its own CI.
Confidence: provenance high / validation high for what runs here (Docker and Nomad flows run only in CI) /
  implementation high for the claimed fixes, medium-high on the completeness of the gcc class (F1 is the gap).
Effect status: repair, commit, push, PR, merge not performed.
Report delivery: /mnt/project-files/reports/Execution-Substrate/workload-identity/27-pr74-recheck-sonnet.md
  (SHA-256 in the delivering message), evidence in 27-pr74-recheck-sonnet-evidence/ (SHA256SUMS inside).
Final verdict: BLOCK
```

**Why BLOCK, in plain words.** Every item re-check 25 asked for is done and tested: the five keys (`FC`, `PKG_CONFIG`, `GCCGOTOOLDIR`, `LPATH`, `OBJCPLUS_INCLUDE_PATH`) are reserved, the contract sentence order is fixed, and a new guard keeps the repository's runbooks and examples free of reserved keys. The extras are sound: the `PKG_CONFIG` family and the two dependency-file keys do what the writer says. But the repair also states a class by its source, "every such key the GCC 14.2 manual lists", and the manual lists two more keys that choose a program gcc runs, `CXX_MODULE_MAPPER` and `MAKE`. Both are still open, and I confirmed with benign probes that gcc starts the program they name. The earlier re-checks and the writer enumerated only the manual's section "Environment Variables Affecting GCC", not the whole manual. This is the same shape as F1 of re-check 25, so the standing rule (Low findings are fixed in the PR) applies. The fix is two map entries, two pin entries, two refusal samples and two words in the contract, and I tested it.

**If the coordinator reads the stated source as only that manual section**, F1 becomes an observation and nothing else here blocks, so the result would be PASS. In that case the three statements (the contract, the code comment and the PR body) should say "the keys of the manual's section 'Environment Variables Affecting GCC'", so that they are true as written. I think reserving the two keys is better: both name programs, which is the category the PR reserves for `CC` and `PKG_CONFIG`.

## Provenance (ran)

| Step | Result |
|---|---|
| Recipe bytes | `sha256sum -c` OK (`c08597e2…a3ca`), before the opening and the closing runs |
| Pushed tip | `git ls-remote` at the start and at the close: `refs/heads/claude/project-thread-ef7st5` and `refs/pull/74/head` = `956991c`, `trunk_dev` = `0b9278c` |
| Base ancestry | `0b9278c` is an ancestor of `956991c`; chain `e0b5c89` → `bba0248` → `956991c`, linear, no merge (`provenance/commits.txt`) |
| Manifest | fresh clone of GitHub, branch checked out at the tip (clean), `git reset --mixed 0b9278c`, upstream `origin/trunk_dev`, two runs, `cmp` identical, `manifest_sha256` `0e8c5d62…bf547b`, equal byte for byte to `24-pr74-repair-evidence/manifest-v2-956991c-on-0b9278c.json`; 31 files; `textual_diff_sha256` `b04f27a9…bfd4` equals the writer's |
| Committed blobs | 31 of 31 records equal the blob at `956991c` (SHA-256 and size); path set equals `git diff --name-only 0b9278c 956991c` |
| Closing run | the clone had been left on a detached head by one read step, so I repeated the same four set-up lines, then two runs: identical, and equal to the opening (`manifest_sha256` the same) |
| Diff digests | `git diff e0b5c89 956991c`: 4 files, +121/-36, `86c2668c…62af`; `git diff 0b9278c 956991c`: 31 files, +1634/-77, `c4fa6aaf…880d82`; tree `5e03010a…`. All equal report 26's values |
| Commits | `bba0248` (F1, N1, runbook guard) changes 4 files, +118/-36; `956991c` (docs test pins the `PKG_CONFIG` family sentence) changes only the root docs test, +3. The PR body's sentence "956991c changes only the root docs test" is right |

## The delta, and what it does (read; the change is list entries, comments, a docs reflow and tests)

- `es/admission/service.go`: map entries `GCCGOTOOLDIR`, `FC`, `LPATH`, `OBJCPLUS_INCLUDE_PATH`, `DEPENDENCIES_OUTPUT`, `SUNPRO_DEPENDENCIES`; prefix `PKG_CONFIG` (after `CGO_`); the long comment above the lists re-worded. No logic change: `isReservedRuntimeEnvKey` is untouched and still has the one caller (`service.go:1229`, the caller-key loop), so ES's own and profile keys are not judged by the wider list.
- `es/admission/caller_declaration_test.go`: the pin lists, the refusal table (`FC`, `PKG_CONFIG`, `pkg_config_path`, `PKG_CONFIG_LIBDIR`, `GCCGOTOOLDIR`, `LPATH`, `OBJCPLUS_INCLUDE_PATH`, `DEPENDENCIES_OUTPUT`, `SUNPRO_DEPENDENCIES`) and the ordinary-keys list (`GO111MODULE`, `GOFIPS140`, `SOURCE_DATE_EPOCH`, `GCC_EXTRA_DIAGNOSTIC_OUTPUT` added).
- `.docs/execution_lifecycle/contracts.md` (one bullet group, section 5): the new family, Go and gcc wording, and the moved "stay open" sentences.
- `caller_declaration_docs_contract_test.go`: a shared matcher (`reservedEnvironmentKeyMatcher`), the new guard `TestRunbooksAndExamplesDeclareNoReservedEnvironmentKey`, and one required phrase (the `PKG_CONFIG` family sentence).

## The claimed fixes

| Claim (report 26) | Verdict | What I checked |
|---|---|---|
| F1, Opus and Sonnet: `FC`, `PKG_CONFIG`, `GCCGOTOOLDIR`, `LPATH`, `OBJCPLUS_INCLUDE_PATH` reserved | **Fixed, all five** | Each is open at base and at `e0b5c89` and reserved at the head in the real function (`probes/probe-*.tsv`). Each is in the code, the pin, the refusal table (`FC`, `PKG_CONFIG` through the family, `GCCGOTOOLDIR`, `LPATH`, `OBJCPLUS_INCLUDE_PATH`), the contract and the comment. Dropping any entry is killed by `TestReservedEnvironmentKeySetIsPinned` and `TestReservedEnvironmentKeysAreRefusedEvenWhenTheArtifactDeclaresThem` (mutants A_drop_*). The reasons hold: `PKG_CONFIG` and `FC` are programs the go command runs (`go help environment`, 1.26.5; re-check 25 ran it); `LPATH` and `OBJCPLUS_INCLUDE_PATH` are read by gcc's driver and preprocessor (`gcc/gcc.cc:4918` for `LPATH`; `gcc/incpath.cc:484`, the table, and `:104`, which reads each name in it, for `OBJCPLUS_INCLUDE_PATH`; GCC 14.2, read) |
| `PKG_CONFIG` reserved as a family (Sonnet O2 of re-check 25) | **Fixed, and sound** | The prefix has no trailing underscore, like `PERL`, `PHP`, `RUBY` and `RUSTC`, so `PKG_CONFIG` itself and every `PKG_CONFIG_*` key are caught, and so is a name such as `PKG_CONFIGURATION` (probe). That over-reach is the same by-design trade as the other families; no key under the prefix is declared anywhere in the project (see below). Ran: `PKG_CONFIG_PATH=<dir> pkg-config --cflags --libs zz` returns the `-I`, `-L` and `-l` flags of the caller's `.pc` file, and without the key the package is not found (`probes/gcc/run2-output.txt`). So the keys do choose the flags and libraries a cgo build gets, as the contract says. Mutants: prefix dropped, changed to `PKG_CONFIG_` (exact key opens), mistyped, or widened to `PKG_CONF`: all killed |
| Dependency-file keys `DEPENDENCIES_OUTPUT`, `SUNPRO_DEPENDENCIES` reserved (Sonnet O1) | **Fixed; the reason is accurate** | Ran (gcc 13.3.0): `DEPENDENCIES_OUTPUT='<path> <target>' gcc -E a.c` writes a rule line whose target is the text the caller gave, to the path the caller gave. A target of `$(echo-run) \`x\`` was written verbatim (`$(echo-run) \`x\`: a.c`); `SUNPRO_DEPENDENCIES` does the same. The contract's category "a file it writes with text the caller chooses" is therefore true. That a shell sourcing the file would run the text is the writer's Inference; I did not test it, and it does not matter for the reservation |
| N1 (Opus): the `LANG`/`LC_ALL` sentence moved so "It is a backstop" follows the list | **Fixed** | The paragraph now reads: "…`TestReservedEnvironmentKeySetIsPinned` pins it. It is a backstop for a publisher's mistake, not the boundary: … The boundary is the allowlist in the next rule. Some keys of these kinds stay open on purpose. `LANG` and `LC_ALL` stay open: …". The order is not pinned by a test (O2) |
| Opus O3: say why `GOOS`, `GOARCH`, `GO111MODULE`, `GOFIPS140` stay open | **Fixed** | The "stay open" sentence names `GOOS`, `GOARCH` "and the other target keys", `GO111MODULE`, `GOFIPS140` ("choose only among code the artifact or the Go toolchain already holds"), and gcc's `SOURCE_DATE_EPOCH` and `GCC_EXTRA_DIAGNOSTIC_OUTPUT` ("a timestamp and the text of its diagnostics"). `TestOrdinaryEnvironmentKeysAreNotReserved` now pins those six as open; reserving any of them is killed (mutants O_overreserve_*, five of five) |
| Runbook finding (Opus O1; the writer's T8): a runbook that declares a reserved key | **Fixed, with limits (O1)** | The new guard parses 9 declaration lists in `.runbooks`, `.examples`, `.docs` and `scripts` (I counted: control-plane `run.sh` 1, three execution-loop examples 3, two runbooks 2, three Remote Alpha scripts 3), with four distinct keys: `APP_MODE`, `REFERENCE_IDENTITY_URL`, `REFERENCE_SECRET_PATH`, `WORKLOAD_VAULT_SECRET_PATH`. None is reserved, and the test passes at the head. It has power: a reserved key added to the reference runbook, an example, the static-script runbook, a Remote Alpha script, a docs block (lower case), or as the second entry of a multi-line list is each killed (mutants G01-G06), as is a broken scan regex (H6) and a broken matcher (H1-H4, killed through the shared contract test). Its limits are in O1 |
| Docs test: required phrase for the `PKG_CONFIG` family | **Fixed** | Mutant C_drop_PKG_CONFIG_family_sentence killed by `TestCallerDeclarationRulesAreInTheLifecycleContract` (it survived at `bba0248`, as report 26 says). The other new sentences are not pinned (O2) |
| "No flow in this repo or the other repos needs any of the newly reserved keys" (PR body, Compatibility) | **Holds** | `git grep -w` for `PKG_CONFIG*`, `GCCGOTOOLDIR`, `LPATH`, `OBJCPLUS_INCLUDE_PATH`, `DEPENDENCIES_OUTPUT`, `SUNPRO_DEPENDENCIES`, `CXX_MODULE_MAPPER` and `FC=`/`"FC"`: in this repo only the writer's own files (`service.go`, the pin, the docs test, the contract) hit; in Maintenance Agent `72cc716`, Infrastructure Manager `a6c23a3`, Coordinator `46a33aa`, bridge-core `60dda23` and Archived-Runbooks `8d99aa0` (main of each, shallow clones, today) there are no hits (`xrepo/other-repos-grep.txt`). The declared keys in this repo are the four above |
| PR body matches the code | **Holds, and repeats F1's sentence** | The body names the families `CGO_` and `PKG_CONFIG`, `FC`, `LPATH`, `OBJCPLUS_INCLUDE_PATH`, `DEPENDENCIES_OUTPUT`, the guard, and "every such key the GCC 14.2 manual lists" (the sentence F1 is about). Its test numbers (bba0248: 1831 pass, 81 skip, 55 fail as root) are the writer's environment; mine differ (below) and the names-equal-to-base conclusion is the same |

## Findings

```text
AUDIT FINDING F1
Type / Severity: security risk in the backstop (incomplete against its own stated source; the contract, the code
  comment and the PR body say the class is closed) / low
Current contract: .docs/execution_lifecycle/contracts.md section 5, single-keys bullet (line 525 at 956991c): "the
  GNU C compiler's keys that choose the programs it runs, the headers and libraries it builds with, extra options,
  or a file it writes with text the caller chooses (`GCC_EXEC_PREFIX`, … `SUNPRO_DEPENDENCIES`: every such key the
  GCC 14.2 manual lists, and the two that gcc's driver and preprocessor read and the manual leaves out, `LPATH` and
  `OBJCPLUS_INCLUDE_PATH`)". The same claim is in the comment at es/admission/service.go:201 and :206 and in the PR body.
Path and line (956991c): es/admission/service.go:296-313 (the map: neither key below is in it, and no prefix or suffix
  covers them); es/admission/caller_declaration_test.go:226-231 (pin) and :371-374 (refusal table); contracts.md:525
Evidence (ran unless marked):
  - The GCC 14.2 manual lists two environment variables that choose a program gcc runs and are not in the section
    "Environment Variables Affecting GCC" (invoke.texi:37288), which re-check 25 and report 26 enumerated:
      CXX_MODULE_MAPPER  indexed as an environment variable (`@vindex CXX_MODULE_MAPPER @r{environment variable}`,
        invoke.texi:3512), "If unspecified the CXX_MODULE_MAPPER environment variable is used" (:3521), and the
        "C++ Module Mapper" node (:37734) gives its forms: `|program args` "A program to spawn, and communicate with
        on its stdin/stdout streams", `host:port`, a socket, or a mapping file. Read, GCC 14.2 source:
        gcc/cp/module.cc:14345 `option = getenv ("CXX_MODULE_MAPPER")`.
      MAKE  invoke.texi:14727, under -flto=n: "The environment variable MAKE may be used to override the program
        used". Read: gcc/lto-wrapper.cc:1382 and :2073 `buildargv (getenv ("MAKE"))`.
  - Ran (gcc 13.3.0, this container's Ubuntu build; benign marker scripts that only append a line to a file in my
    scratch directory, run as the unprivileged user; probes/gcc/run-output.txt):
      `CXX_MODULE_MAPPER='|/opt/audit27/probe-gcc/fakemapper.sh' g++ -std=c++20 -fmodules-ts -c m.cc`: the marker
      shows "mapper-started argv=" (gcc then fails the handshake: "failed mapper handshake communication
      error:Broken pipe"); without the key there is no marker.
      `MAKE=<fakemake.sh> gcc -O2 -flto=2 -flto-partition=max a.c b.c`: the marker shows gcc ran the program with
      `--version` and then `-f /tmp/….mk -j2 all`.
  - Ran, the real function `isReservedRuntimeEnvKey` at 956991c: `CXX_MODULE_MAPPER` and `MAKE` are OPEN, as they
    are at e0b5c89 and at the base (probes/probe-head.tsv; the gcc-manual group).
  - The other 19 environment names the manual lists (29 in all; probes/probe-head.tsv): 8 are reserved (`PATH`,
    `TMPDIR`, `GCC_EXEC_PREFIX`, `COMPILER_PATH`, `LIBRARY_PATH`, `CPATH`, `GCC_COMPARE_DEBUG`,
    `DEPENDENCIES_OUTPUT`); `LANG`, `LC_ALL`, `SOURCE_DATE_EPOCH` and `GCC_EXTRA_DIAGNOSTIC_OUTPUT` are open and
    named as open on purpose; `LC_CTYPE`, `LC_MESSAGES`, `COLUMNS`, `GCC_COLORS`, `GCC_URLS` and `TERM_URLS` change
    only locale, width, colours and links of diagnostics (open, like `LANG`; not named); `TOPDIR`,
    `TARGET_SYSTEM_ROOT` and `GCC_INCLUDE_DIR` are names in spec-file text and build macros, not keys gcc reads from
    its environment (read: invoke.texi:36844, :36970, :37386); `ASAN_OPTIONS`, `LSAN_OPTIONS`, `TSAN_OPTIONS`,
    `UBSAN_OPTIONS`, `HWASAN_OPTIONS` and `VTV_LOGS_DIR` belong to the compiled program's runtime, not to the
    compiler (O4). So `CXX_MODULE_MAPPER` and `MAKE` are the only two keys in the manual that are in the sentence's
    categories and open.
  - The Go sentence ("every such key `go help environment` lists in Go 1.26.5") holds: of the 54 keys the help lists,
    30 are reserved (`go-help` group of the probe) and the 24 open ones are the target keys, `GO111MODULE`,
    `GOFIPS140` (named as open), seven keys the go command computes (`GOEXE`, `GOGCCFLAGS`, `GOHOSTARCH`,
    `GOHOSTOS`, `GOMOD`, `GOTOOLDIR`, `GOVERSION`), and `GOCOVERDIR`, `GO_EXTLINK_ENABLED`, `GOTELEMETRY` and
    `GOTELEMETRYDIR` (data files and a link mode, no program; O3). None names a program the go command runs.
Impact: the same as the keys the PR reserves for this class (`CC`, `PKG_CONFIG`, `LPATH`): a publisher that declares
  `MAKE` (it looks like plain build configuration, and its neighbours `MAKEFLAGS` and `MAKEFILES` are reserved) or
  `CXX_MODULE_MAPPER` lets a caller choose a program gcc starts. Reach (Inference) is small: the run's image needs
  g++ with `-fmodules-ts` (C++ modules; the manual says mapper functionality "is in its infancy and is intended for
  experimentation") or gcc with `-flto=N` on enough code to split, the publisher must declare the key, and the program must come from a caller mount (mounts keep their execute
  bit: red-team 19 observation 3). No artifact in the project declares either key. It is a backstop gap, not a hole
  in the boundary; but the PR states the class by its source, so a reader takes both keys as reserved.
Required correction (closes the manual class): reserve `CXX_MODULE_MAPPER` and `MAKE`: two entries in
  `reservedRuntimeEnvKeys`, the same two in `mustBeReservedEnvironmentKeys`, the two in the refusal table, and the
  two names in the contract's gcc list. Tested: that change (probes/proposed-fix-F1.diff, 5 lines changed in 3 files)
  passes `go test ./es/admission/ -run 'TestReserved|TestOrdinary|TestEmptyEnvironment|TestCaller|TestDeclared|
  TestEnvironmentRefusal|TestOperationalRetained|TestLifecycle'` and `go test . -run 'TestCallerDeclaration|
  TestLifecycleContract|TestRunbooksAndExamples'`, and is gofmt-clean. The contract test already accepts the two
  names once the code reserves them. The alternative is to say, in the contract, the comment and the PR body, that
  the source is the manual's section "Environment Variables Affecting GCC" and to list the two keys as open with a
  reason; I would not recommend it, since both name programs.
Uncertainty: which images a granted run uses, and whether any holds g++ with modules or gcc with LTO, is Unknown. The
  probes ran gcc 13.3.0; the sources I read are GCC 14.2.0, and both read the two keys the same way.
Patch defect or pre-existing issue: patch defect in the claim (the categorical wording is new in bba0248); the keys
  were open before the PR too.
```

```text
AUDIT FINDING N1
Type / Severity: test/doc/artifact gap (comment layout) / nit
Path and line (956991c): es/admission/service.go:211
Evidence: after the comment above the single-keys list was re-worded, one line was left at 108 columns ("commands in
  a script that translates its messages. Upstream glibc's gettext skips a LANGUAGE entry that"), while the lines
  around it are 61-74 columns. gofmt is clean (ran), so no tool notices.
Required correction: re-wrap the last five comment lines. No code or test change.
Patch defect or pre-existing issue: patch defect (bba0248).
```

## Observations (no correction required by this re-check)

- **O1. The runbook guard reads one spelling.** It parses only `"environment_variables": [ … ]` with double quotes and takes the quoted strings as they are. ES judges a declared entry after trimming white space and after JSON decoding, and the guard does neither. Ran, mutants on the head: a padded entry (`" LD_PRELOAD"`, G07), a JSON escape (`"LD_PRELOAD"`, G08) and a single-quoted Python list (G09) each **survive**; the real function reserves the padded spelling (probe, `spelling` group), so ES would refuse that caller at submit and the guard would not have said so. All 9 declarations in the repository use the scanned spelling, and the self-check requires three of them, so nothing is wrong today. Also, dropping the `scripts` root from the scan survives (H5): the self-check finds its three required keys in `.runbooks` and `.examples` only. A declaration outside the four roots (G10, a README) survives by design. Cheap tightenings: trim and upper-case the same way ES does; require each root to hold at least one known declaration; or compare the number of lists parsed with the number of times `environment_variables` appears next to a `[` in those roots.
- **O2. The new contract sentences are not pinned, the same by-design gap as re-check 25's O4.** Of 12 contract mutants, 4 are killed (the family sentence, and three over-claims: naming `GO111MODULE`, `SOURCE_DATE_EPOCH` or `CXX_MODULE_MAPPER` as reserved) and 8 survive: dropping "every such key `go help environment` lists", dropping "every such key the GCC 14.2 manual lists, and the two…", dropping the category "or a file it writes with text the caller chooses", dropping `DEPENDENCIES_OUTPUT` and `SUNPRO_DEPENDENCIES` from the list, dropping the "stay open on purpose" sentences (three mutants), and reverting N1's order. Removing a claim makes the contract weaker, not false, and the test pins the direction that matters (a named key must be reserved). If the coordinator wants them pinned, the same one-line required-phrase addition used for the `PKG_CONFIG` sentence works.
- **O3. The "stay open on purpose" list is not exhaustive for the Go keys, by its own wording ("Some keys…").** Of the 24 open keys in `go help environment`, the sentence names the target keys, `GO111MODULE` and `GOFIPS140`; it does not name `GO_EXTLINK_ENABLED`, `GOCOVERDIR`, `GOTELEMETRY`, `GOTELEMETRYDIR` or the seven computed keys. None names a program; `GOCOVERDIR` and `GOTELEMETRYDIR` choose where data files go (the same kind as `GOTMPDIR`, which is reserved; Inference: because the go command runs what it builds there). Naming them would let a reader verify "every such key" without this table. The pin already catches any code change to them (`TestReservedEnvironmentKeySetIsPinned` is exact).
- **O4. Keys the GCC manual lists that belong to the compiled program, not to gcc, are open.** `ASAN_OPTIONS`, `LSAN_OPTIONS`, `TSAN_OPTIONS`, `UBSAN_OPTIONS`, `HWASAN_OPTIONS` (the sanitizer runtime; its options include a symbolizer program and log and suppression files) and `VTV_LOGS_DIR` (where a vtable-verified program writes logs). The sentence says "the GNU C compiler's keys", so I did not count them in F1. Like clang's keys and `MUSL_LOCPATH` (report 26, "still open and not asked for"), they stay with the coordinator.
- **O5. The Archived-Runbooks copy of the reference-workload runbook still declares `REFERENCE_VAULT_INSECURE_SKIP_VERIFY`** (`8d99aa0`, line 168). It still works, and report 26 lists the refresh as the coordinator's call; the project rule is that a deferral needs a machine-enforced trigger, and I found none. Unchanged from re-check 25's O3; not a #74 defect.
- **O6. The `PKG_CONFIG` prefix reserves names such as `PKG_CONFIGURATION`** (probe). Same trade as `PERL`, `PHP`, `RUBY`, `RUSTC`; no key under it is declared in the project. Mentioned so it is a known edge.
- **O7. Items audit 21 and red-team 19 left open are still open, as report 26 says** (AGS refusing to sign a reserved key, caller mounts without execute permission, unbounded `argv`). None is in this delta.

## Validation (ran)

All runs as an unprivileged user (uid 1500), `umask 022`, `env -i`, Go 1.26.5 (`GOTOOLCHAIN=local`, `GOPROXY=off`), one clone per tree made from a bundle (tree hashes checked: base `b3c61199…`, head `5e03010a…`), `go vet . ./es/... ./scripts/... ./internal/...` then `go test -count=1 -timeout 30m -json ./...`, one tree at a time. Scripts in `tests/`.

| Tree | vet | Top-level pass / skip / fail | Compared with base |
|---|---|---|---|
| base `0b9278c` | exit 0 | 1849 / 86 / 13 | |
| head `956991c` | exit 0 | 1868 / 86 / 13 | the same 43 failing names (the same 13 top-level, with subtests); 19 tests only at the head, all pass; none only at base; no status change |

The 13 top-level failures are in three packages and fail the same way on the base: 3 old-binary probes in `es/admission/internal/reliablesubmit`, 2 in `es/app` (`TestLinuxSetupBootstrapFinishesWithItsSavedSecret`, `TestNomadACLToolRetriesABootstrapThatNeverTookEffect`) and 8 Remote Alpha tests in `scripts`. Guess: this container lacks host tools or paths their fixtures need (it is not the writer's container, which saw 55). The 19 tests only at the head are the PR's own: 3 root (`TestCallerDeclarationRulesAreInTheLifecycleContract`, `TestLifecycleContractNamesOnlyReservedKeysTheCodeReserves`, `TestRunbooksAndExamplesDeclareNoReservedEnvironmentKey`), 2 `ags/publish`, 11 `es/admission`, 1 `es/app` and 2 `internal/contracts/evidence/v1` (`tests/only-head-top.txt`). Docker, Nomad and Vault flows skip here (86 skips on both trees). `gofmt -l` on the three changed Go files is empty; `go vet` on the root and `es/admission` also passes with `GOOS=darwin GOARCH=arm64`.

**Mutants of my own (44, plus the fix check)**, on a clone of the head, runner `mutants/mutants.py`, log `mutants/mutants-log.txt`; targeted sets `./es/admission/ -run 'TestReserved|TestOrdinary|TestEmptyEnvironment|TestCaller|TestDeclared|TestEnvironmentRefusal|TestOperationalRetained|TestLifecycle'` and `. -run 'TestCallerDeclaration|TestLifecycleContract|TestRunbooksAndExamples'`; baseline green first. **31 killed, 13 survived.**

| Group | Mutants | Killed | Survived |
|---|---|---|---|
| Code: each of the 6 new entries dropped; prefix `PKG_CONFIG` dropped, changed to `PKG_CONFIG_`, mistyped, widened to `PKG_CONF` | 10 | 10 (by the pin, and for all but the widened one also by the refusal test) | 0 |
| Code: a key left open on purpose reserved (`GO111MODULE`, `GOFIPS140`, `SOURCE_DATE_EPOCH`, `GCC_EXTRA_DIAGNOSTIC_OUTPUT`, `GOARCH`) | 5 | 5 (by `TestOrdinaryEnvironmentKeysAreNotReserved` and the pin) | 0 |
| Contract text (12) | 12 | 4 | 8: O2 |
| Runbook, example and script declarations (11) | 11 | 7 (G01-G06 and G11, white space before the colon) | 4: G07, G08, G09 (O1), G10 (outside the roots, by design) |
| The guard itself (6): matcher without prefix, suffix, case or exact-key checks; scan regex broken; `scripts` root dropped | 6 | 5 (H1-H4 by the shared contract test, H6 by the guard) | 1: H5 (O1) |
| **Proposed fix for F1** (not a mutant: green is the wanted result) | 1 | | passes both targeted sets |

None of the 13 survivors is a reservation: every mutant that changes which key the code reserves is killed. F1 is a key that is not in the code, which no mutant of the delta can show; I found it by enumerating the stated source.

**Real-function probe** (`probes/zz_audit27_probe_test.go`, copied into the `es/admission` package of a scratch clone, run, deleted; 146 keys in `probes/keys.tsv`: all 54 keys of `go help environment`, all 29 environment names of the GCC 14.2 manual, the five F1 keys, pkg-config's keys and near misses, gcc driver keys, and padded and re-cased spellings; run on the base, `e0b5c89` and the head, outputs `probes/probe-{base,prev,head}.tsv`). Differential `e0b5c89` → head: exactly 36 keys flip from open to reserved (the seven named keys, 16 `PKG_CONFIG*` names and spellings, and 13 re-cased or padded spellings of the named keys), and **no key flips from reserved to open**. At the head, 30 of the 54 Go keys and 8 of the 29 manual names are reserved; the open ones are classified under F1 and O3-O4.

## CI

GitHub (read via the connector). `956991c`: "test on macOS" (run 45943548863, job 140322998381) **completed with success** at 05:32:24Z (started 05:04:02Z). "build, vet and test" (run 45943548808, job 140322998203, started 05:04:02Z) **completed with success** at 05:50:34Z. The workflow run's `head_sha` is `956991c`. Tail of its log (read): "tests as root passed: 9 of execution-substrate/scripts". I read only the tail of the job log; the job conclusion is the gate's verdict (Inference from the gate's rule that an unlisted failure fails the job, as in re-check 23a). Both jobs were still running when I finished the rest of the work; I waited for them. Evidence: `ci/check-runs-956991c.txt`.

## Coverage this environment could not give

- No Docker, Nomad, Vault or SPIRE: the `es/app` mount and network flows skip here, so I did not run `:submit` with a caller declaring `CXX_MODULE_MAPPER` or `MAKE`; the F1 evidence is the real function plus gcc itself. No macOS run (CI's macOS job is the reference).
- I did not run `GCCGOTOOLDIR` (no gccgo here); its effect is from `go help environment` and re-check 25's reading.
- The probes ran gcc 13.3.0 (Ubuntu); the manual and sources I cite are GCC 14.2.0. I did not run gcc 14.2.
- What the runtime images hold (g++ with modules, LTO, cgo, pkg-config) is Unknown; no image was inspected.
- I did not demonstrate a caller's own code running through either key: the probes use marker scripts of mine that only append a line to a file, on purpose, as the earlier re-checks did.

## For the writer, in one list

1. F1: reserve `CXX_MODULE_MAPPER` and `MAKE` (code, pin, refusal table, contract list); `probes/proposed-fix-F1.diff` applies to the head and passes the targeted tests. Or narrow the three statements to the manual's section and name the two as left open with a reason.
2. N1: re-wrap the one 108-column comment line.
3. Optional, same round: O1 (trim and upper-case in the guard; a known declaration per root), O2 (pin the new claim sentences), O3 (name the remaining open Go keys).
4. Then take the new manifest, merge `trunk_dev` again if it moved, and let CI on the new head decide the merge gate with a narrow check that only these lines changed. The audit-21 chain, red-team 19 and re-checks 23 and 25 do not need repeating for them.

## Trial log row (for the coordinator to copy)

| Date | Category | PR @ head | Scope | Model | Verdict | Findings | Later outcome |
|---|---|---|---|---|---|---|---|
| 2026-11-27 | R-S | ES #74 @ 956991c | narrow re-check (real) | [model withheld] | BLOCK | F1 Low: `CXX_MODULE_MAPPER` and `MAKE` open although the contract, comment and PR body say every GCC 14.2 manual key of the kinds is reserved (gcc starts the program they name: ran); fix tested. N1 nit: one 108-column comment line. 7 observations (guard reads one spelling; new contract sentences unpinned; open Go keys not all named; sanitizer keys; AR copy stale). All five re-check 25 keys, N1 and the runbook guard verified; same 43 failing names as base; 31 of 44 own mutants killed (13 survivors classified); CI green on both required checks | to fill in: pair is the Opus run on the same head and scope, not read |

## Evidence

`27-pr74-recheck-sonnet-evidence/`: `provenance/` (opening and closing manifests, the delta diff and digests, the commit chain, the recipe hash, commands), `tests/` (runner scripts, failing-name lists for both trees, the 19 tests only at the head, vet output, summary, gzipped `go test -json` of both runs), `probes/` (the 146-key list and probe test, outputs for the base, `e0b5c89` and the head, the F1 fix patch, and `gcc/` with the marker scripts, test sources and the outputs of the `CXX_MODULE_MAPPER`, `MAKE`, dependency-file and pkg-config probes), `mutants/` (runner, logs), `upstream/` (`go help environment`, the cppenv text, hashes of the GCC 14.2 sources and the lines in them that read the environment), `xrepo/` (the cross-repo search), `ci/` (the check runs), and `SHA256SUMS`.

STATUS: READY (re-check delivered, verdict BLOCK on one Low finding; CI on 956991c green on both required checks)
