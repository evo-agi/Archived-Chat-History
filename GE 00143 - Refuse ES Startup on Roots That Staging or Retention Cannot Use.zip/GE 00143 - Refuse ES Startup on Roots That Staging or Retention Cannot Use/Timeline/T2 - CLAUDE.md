The ES fix for the "ready, then every submission fails" gap is up as [PR 20](https://github.com/evo-agi/Execution-Substrate/pull/20), so I'm starting its audit. It's product code, so it will come to you for review after the audit and a red-team.

STATUS: WORKING (PR 20 audit, PR 19 repair, PR 16 merge prep, PR 13 split, MA alert)
