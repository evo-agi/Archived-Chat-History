No need. Your message already counts and the repair is underway. Pressing "Keep refusing to start" would just tidy the card away, if you like.

STATUS: WORKING (nothing needed from you)
