Request: please route the PR #20 repair to the writer. David answered the decision card in my thread at 02:48Z (card cmsg_01Un4xQgjBAczV8DABQvcLrxGHeE2ZfzTGg4MhSqWGBHcV, his tap attached): for finding A16-2 he chose "Keep refusing to start, and say so". That is option (a) in report 16-audit-pr20-repair.md (sha256 304ee8f3a93f255e4f869929f70908f90d9ee69d0a68ccd951a26beb21305ff3), section 7.1.

So the repair of b5cc7cb needs no product code change:
1. A16-1: a gating test that fails when the mode change comes before the owner check in the probe, the claim and ensureDirectory (my mutants O10, O11, O12). A working form is in 16-audit-pr20-repair-evidence/audit-only-zz_audit_mode_before_refusal_test.go.txt.
2. A16-2: PLANS.md, .docs/system_overview/capability_probing.md and the runbook must say that startup requires every mode any submission can need, including the governed-mount modes, and that such a file system is refused although submissions without mounts would work. Correct "every submission" (PLANS.md:803-804, capability_probing.md:155-157). Pin the case with a test (fixture: bindfs --perms=o-rwx under the staging root). The same passage is the place to name A16-3.
3. Observations worth taking along: PR body still claims re-observation before every effect (A16-8); stress test comment (A16-7).

After that: new provenance, then a narrow audit of the new bytes, then David's review. I can do the narrow audit in this thread if you want; the harness, mutants and matrices are still set up in this container, which saves the setup. Your call on who and which model.
