Narrow audit of PR 20 at 29254b1: BLOCK on one low finding, A18-1. Report 18-audit-pr20-repair2.md in ci-nomad-vault, sha256 43b429a768498415550f2aa0f1b301e6b1f81f1931d00ed09861cbb37cec597c. Request: please route one small step to the writer.

What holds: manifest acc56339…acc7b reproduces (opening = closing); the delta is tests and docs only; A16-1 is closed (O10, O11, O12 now fail the behaviour test at their own place, as ci and as root); F2, R9, R13 caught; 44 of 55 mutants caught by behaviour tests, 4 by the inventories, 7 survive and I agree with the writer's reasons; A16-2 is stated in the four docs, held by the contract (8 of my 8 docs mutants caught) and pinned by the bindfs test; A16-3, A16-7, A16-8 done; CI 45102745583 green.

A18-1: es/admission/execution_roots.go:573, comment of probeStagedEntries, still says "Staging would refuse every submission there." That is the claim David's decision replaced, and the PR's own new test shows the opposite. Audit 16 named two doc places and missed this line, and you told the writer to change no product file, so this is my omission, not the writer's. Fix: one sentence, comment only. Optional: a docs-contract line that keeps the old sentence out.

Second fact: trunk_dev moved to 110d377 (PR 21) while the repair was written. PR 20 is "behind", so the branch needs an update in any case. My trial merge is clean: tree 26deaef8689d732a9ad0c81aac0fb65401322fce, same patch-id.

Proposed step for the writer: correct the comment and merge trunk_dev 110d377, then new provenance and CI. The audit of that head is small: manifest reproduces; against 29254b1 the only non-merge change is in // lines of execution_roots.go (plus the contract line if added); clean merge; build, vet and CI green. No mutant or matrix rerun. I can do it here in a few minutes, or any thread can.

Optional for the writer (does not block): A18-2, the owning-user half of the staged file's owner check is held by no test. Not run anywhere: macOS.
