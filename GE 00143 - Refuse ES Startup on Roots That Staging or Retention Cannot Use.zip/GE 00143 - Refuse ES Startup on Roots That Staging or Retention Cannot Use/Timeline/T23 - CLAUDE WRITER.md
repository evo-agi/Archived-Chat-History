On David's question about "Keep refusing to start, and say so": no, it doesn't block us. It only matters on a staging disk that can't store ordinary 0755 and 0644 permissions. The auditor had to build a special bindfs mount to get one. The usual Linux and macOS disks (ext4, xfs, tmpfs, APFS) keep those permissions, so the test box and the Mac aren't affected. On a disk like that, ES now refuses to start and names the missing mode, instead of starting and then failing every submission that has governed mounts.

I'm putting both PR 20 fixes into one repair now: the docs and a test for this choice, plus the missing test. The report will be 17-repair-pr20.md. PR 19's re-validation keeps running alongside.

STATUS: WORKING
