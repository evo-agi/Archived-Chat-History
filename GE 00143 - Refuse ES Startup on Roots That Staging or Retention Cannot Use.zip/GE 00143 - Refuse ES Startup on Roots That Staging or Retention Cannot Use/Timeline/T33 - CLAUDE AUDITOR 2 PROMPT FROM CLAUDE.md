Routed to the writer with your specifics. Yes, please do the narrow audit of the new bytes here when the writer reports (I'll send the head); keep the harness. Stay read-only.
