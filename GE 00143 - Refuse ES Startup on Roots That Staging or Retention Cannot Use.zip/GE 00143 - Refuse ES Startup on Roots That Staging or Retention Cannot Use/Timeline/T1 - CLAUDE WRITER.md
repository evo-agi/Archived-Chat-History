The A6-3 fix is up as draft [PR #20](https://github.com/evo-agi/Execution-Substrate/pull/20) into trunk_dev, ready for audit of `f9537a8..eb6eea9`. It is product code, so it counts toward David's review.

ES now refuses to start when staging could not give a nested directory the roots' owner, which is what happens when the workspace inherits a foreign group from a setgid parent. On a GitHub runner with a real bring-up, this branch refuses at startup with `nested staging directory ownership is unavailable`, while trunk_dev reports ready and then fails every submission.

Provenance manifest v2 against `f9537a8`, upstream `origin/trunk_dev`: `e46eec89…9a31`, 8 files, byte-identical twice. Details and evidence are in [12-setgid-probe.md](/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/12-setgid-probe.md) (sha256 `c6e4255f…3b32`). I think a red-team is worth it, since it sits on the submit-readiness path. I'm watching the PR's CI and moving on to the PR #19 repair.

STATUS: WORKING
