The Mac run for PR 20 has started on your Mac, in a temporary folder under Playground, following the brief. It should take about 5 to 10 minutes, and I'll post the result when it's in. PR 19's repair carries on meanwhile.

STATUS: WORKING
