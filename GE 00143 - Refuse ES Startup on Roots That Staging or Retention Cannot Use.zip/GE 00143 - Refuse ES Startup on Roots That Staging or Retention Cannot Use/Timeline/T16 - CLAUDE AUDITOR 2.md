Asked the project to choose an option

```json
{"kind":"activity","tool":"ask_decision","text":"Asked the project to choose an option","decision":{"version":1,"question":"Choose what ES does on a staging disk that cannot hold governed-mount permissions","options":[{"label":"Keep refusing to start, and say so","consequence":"ES will not start there, even though submissions without governed mounts would work. The docs and a test state it. No product code change."},{"label":"Start, refuse only mount submissions","consequence":"ES starts there and refuses only submissions that use governed mounts. Needs new product code and a new audit, and adds a second kind of readiness."}],"recommended":0,"reason":"An ES that is ready but fails some submissions is the symptom this PR removes. Keeping the refusal needs only docs and a test."}}
```
