Asked the project to choose an option

Choose what ES does on a staging disk that cannot hold governed-mount permissions

1. Keep refusing to start, and say so (recommended): ES will not start there, even though submissions without governed mounts would work. The docs and a test state it. No product code change.
2. Start, refuse only mount submissions: ES starts there and refuses only submissions that use governed mounts. Needs new product code and a new audit, and adds a second kind of readiness.

Why recommended: An ES that is ready but fails some submissions is the symptom this PR removes. Keeping the refusal needs only docs and a test.
