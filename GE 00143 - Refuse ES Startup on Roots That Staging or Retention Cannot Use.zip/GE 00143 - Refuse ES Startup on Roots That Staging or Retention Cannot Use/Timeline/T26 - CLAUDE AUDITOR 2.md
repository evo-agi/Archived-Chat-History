Chose an option

```json
{"kind":"activity","tool":"decide","text":"Chose an option","decision_id":"cmsg_01Un4xQgjBAczV8DABQvcLrxGHeE2ZfzTGg4MhSqWGBHcV","option_index":0,"chosen_by":"user_[account id withheld]"}
```
