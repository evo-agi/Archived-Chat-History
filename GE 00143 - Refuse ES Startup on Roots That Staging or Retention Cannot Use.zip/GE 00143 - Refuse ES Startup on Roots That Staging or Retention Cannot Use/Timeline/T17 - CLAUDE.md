Decision in Governed Execution: Choose what ES does on a staging disk that cannot hold governed-mount permissions (Sent: Keep refusing to start, and say so)

```json
{"kind":"widget","family":"blocks","widget":"card","input":{"blocks":[{"type":"context","text":"Decision in Governed Execution"},{"type":"section","text":"Choose what ES does on a staging disk that cannot hold governed-mount permissions"},{"type":"context","text":"Sent: Keep refusing to start, and say so"}],"updated_at":"2026-11-23T02:48:11.276205101Z"},"text":"Decision in Governed Execution: Choose what ES does on a staging disk that cannot hold governed-mount permissions (Sent: Keep refusing to start, and say so)","by_channel_session":true,"answers_decision":{"channel":"e0f1a6a9-419d-4a5e-a01a-1ab448a16525","card":"7bcbebb2-c0d7-4797-b572-cd91583fcd6a","thread_root":"38a69019-37be-43c5-95ad-6647727b4e7e"}}
```
