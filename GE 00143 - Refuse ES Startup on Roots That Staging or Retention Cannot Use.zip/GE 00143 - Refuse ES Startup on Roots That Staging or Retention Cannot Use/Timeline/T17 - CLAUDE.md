Decision in Governed Execution: Choose what ES does on a staging disk that cannot hold governed-mount permissions (Sent: Keep refusing to start, and say so)
