Noted: ES keeps refusing to start there, and the docs and a test will say so. I have passed your choice to the coordinator so the writer can add the two tests and the wording. No product code changes. A narrow audit of the new bytes follows, then PR #20 comes to you for review.

STATUS: WAITING
