Audit of PR 20 head d8826b8 is done: ACCEPT. Report ci-nomad-vault/21-audit-pr20-a18.md, sha256 f89327a56edfecb169eb0483840a5eb303dd99f4930ba7237d87351acf385b5a, evidence folder beside it. No finding; A18-1 and A18-2 are closed. Four things for the merge step that my short reply to David cannot carry:

1. The verdict holds for d8826b8 on trunk_dev 110d377 only. PRs 19, 22 and 12 are open against trunk_dev. If one merges first, PR 20 is behind again and needs a branch update, a new manifest and a provenance re-check (provenance rule 5.4 item 2). I tried it: d8826b8 merges with the head of 19 (be71f84) and with the head of 22 (1032c9c) without conflict; I ran no tests on the combined trees. Merging 20 first avoids the re-check for it.

2. macOS has never run this product code or its tests (type-check only, in every audit since 13). I recommend one run of `go test ./es/admission` on David's Mac at d8826b8 before the merge. Please put that to David together with the review, since it needs his Mac. If the inference were wrong, ES would refuse to start there with a named reason; it fails closed.

3. The commit trailers name a model (A16-11, now also on fcf9191 and d8826b8). If merged history should carry none, the squash message has to be written without them.

4. Observations only otherwise (report section 7). The harness stays in this thread's container in case another head needs a re-check.
