No, it doesn't block us. It only affects a staging disk that can't keep normal Unix permissions, such as some network or special mounts. Inference: the test box uses an ordinary local disk, where ES starts as before, and the reliable-submit work doesn't depend on such disks. The audit's run on the box's real setup will confirm that. If we ever need those disks, the second option can be added later as its own change. I'll take your message as the pick and pass it on.

Separately, the flaky-test fix (PR 21) passed its re-audit with nothing to change and now goes through the merge steps.

STATUS: WORKING (PR 20 small repair, PR 21 merge, PR 22 audit, PR 19, PR 13 split, MA alert)
