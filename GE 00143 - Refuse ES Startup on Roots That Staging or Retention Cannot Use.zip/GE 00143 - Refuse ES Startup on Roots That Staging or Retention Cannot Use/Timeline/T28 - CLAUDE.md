Fair point, and thanks. The card came from the audit, but the repair runs in a different place, [Run Nomad and Vault tests in CI](#cmsg_01Un4xQgjBAczV8DABQvcLrx9qA4pvEiFx8Pa7SN4JK3UU), which confirmed at 02:40 UTC that it's making both PR 20 fixes. From now on, when you answer a card in words, I'll say in my reply where the work continues so you don't have to guess.

STATUS: WORKING (nothing needed from you)
