The ES fix that stops "ready, then every submission fails" has its red-team findings repaired and is green on GitHub, so it's getting one more fresh audit before your review.

STATUS: WORKING (PR 20 audit, PR 19 storage check, PR 13 split, PR 21/22, MA alert; nothing needed from you)
