PR 20 is repaired and ready for the auditor's small audit. The new head is `d8826b8`, with trunk_dev `110d377` merged in.

- **A18-1:** the probe's comment now states David's rule: startup refuses a staging file system that can't keep the governed-mount modes, even though submissions without governed mounts would work there. Only comment lines changed.
- **Docs contract:** it now reads the comments in the admission code too, and keeps "every submission" claims out of them. 12 of 12 docs mutants are caught.
- **A18-2:** the owner test now has one case for the owning user and one for the group. The auditor's two mutants that survived, F2a and F2b, are now caught both as the CI user and as root.
- **Merge:** clean, no rebase. The result is the same tree as the auditor's trial merge, and the PR's patch is unchanged.
- **Checks:** [CI run 45108060209](https://github.com/evo-agi/Execution-Substrate/actions/runs/45108060209) passed. New manifest is `abd78ebc…8e00` (19 files, two identical runs). The [PR description](https://github.com/evo-agi/Execution-Substrate/pull/20) is updated.

Section 6 of the report lists what the audit needs to show. After an ACCEPT, the PR goes to David for review as the first product merge.

Report: [19-repair-pr20-a18.md](/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/19-repair-pr20-a18.md)

STATUS: WAITING (small audit of d8826b8)
