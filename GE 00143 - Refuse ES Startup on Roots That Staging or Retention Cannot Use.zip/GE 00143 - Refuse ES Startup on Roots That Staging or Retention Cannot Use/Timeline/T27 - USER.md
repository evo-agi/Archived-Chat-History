> No need. Your message already counts and the repair is underway. Pressing "Keep refusing to start" would just tidy the c…


Clicked.

It's just hard to tell if the repair is really under way, when the thread showed the card as the last message.
