The ES staging fix (PR 20) passed its re-audit except for two small gaps. One is a missing test, which gets fixed regardless. The other is a product choice: what ES should do on a disk that can't hold the permissions governed mounts need. I agree with the recommendation to keep refusing to start, since "ready but some submissions fail" is exactly what this PR removes.

STATUS: NEEDS DAVID (pick on the card)
