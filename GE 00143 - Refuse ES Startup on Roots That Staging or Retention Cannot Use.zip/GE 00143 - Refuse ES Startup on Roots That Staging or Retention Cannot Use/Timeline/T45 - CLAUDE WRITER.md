The Mac run brief for PR 20 at `d8826b8` is ready: [22-mac-brief-pr20.md](/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/22-mac-brief-pr20.md).

It runs the whole of `es/admission` at `d8826b8` and again at trunk_dev `110d377`, so any Mac failure can be told apart from one that already exists without the PR. It also runs the PR's own tests that compile on macOS in full, plus `go vet`, `gofmt` and the docs contract tests. It works in a fresh temporary folder under Playground with Go 1.26.5 from the module cache, downloads nothing, never makes the folder its working directory, and removes it at the end. It should take about 5 to 10 minutes.

David, when you're back, write "go ahead" in this thread and I'll start it on your Mac. The session only accepts a start from your own message here. Nothing gets merged. PR 19's repair continues meanwhile.

STATUS: WAITING (David: "go ahead" here for the Mac run; PR 19 repair in progress)
