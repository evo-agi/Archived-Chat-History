[PR 20](https://github.com/evo-agi/Execution-Substrate/pull/20), the ES fix that stops "ready, then every submission fails", passed its audit with nothing to change. It now gets a red-team, and after that it comes to you for review.

STATUS: WORKING (PR 20 red-team, PR 19 and PR 21 audits, PR 13 split, MA alert, collector fix)
