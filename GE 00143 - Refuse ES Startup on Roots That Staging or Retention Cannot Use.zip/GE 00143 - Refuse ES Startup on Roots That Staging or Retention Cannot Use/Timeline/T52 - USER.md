<!-- reply 1 -->
> I resolved 16 threads whose work is finished or superseded, mostly older audits and red-teams. Seven stay open because w…


Hmm... I still don't understand PR20, but I'll approve it for now.

Pinged thread `Run Nomad and Vault tests in CI`.

About Fable vs Opus for the red-team, we can go with Opus, but we will need to add Fable-backed red-team to the backlog, maybe as a new thread, where we continuously supply new objectives for the red-team to execute post-reset.
