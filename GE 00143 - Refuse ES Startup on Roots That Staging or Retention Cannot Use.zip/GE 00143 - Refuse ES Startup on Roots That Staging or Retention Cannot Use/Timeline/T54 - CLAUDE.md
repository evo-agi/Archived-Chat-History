Thanks. PR 20 merges once your Mac run passes. Since you want to judge it, here it is in plain terms:

- **The problem:** for each job, ES prepares a staging folder whose subfolders must belong to ES's own account with exact permissions. On some machines the disk quietly changes that, for example when the parent folder forces its own group onto new folders. ES then said "ready", but every job with mounted files failed.
- **The fix:** at startup ES now tries it for real. It creates test folders and files, renames one, and checks owner and permissions. If anything comes out wrong, it refuses to start and names the reason.
- **What review added:** the red-team found three ways around the first version, such as never testing files and a swap race. All three are fixed and now pinned by tests.

On the red-team: the PR 12 red-team will run on Opus. I've also set a reminder for Nov 27 to start a Fable red-team that works through a backlog of targets, starting with PR 12 again, and I'll keep adding targets until then.

STATUS: WORKING (Mac run, then PR 20 merge; PR 19, PR 22, PR 13, MA audit)
