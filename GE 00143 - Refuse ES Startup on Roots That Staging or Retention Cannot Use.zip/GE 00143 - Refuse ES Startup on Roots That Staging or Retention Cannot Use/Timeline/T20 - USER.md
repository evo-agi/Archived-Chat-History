<!-- reply 1 -->
> The ES staging fix (PR 20) passed its re-audit except for two small gaps. One is a missing test, which gets fixed regard…


I do like the option of `Keep refusing to start, and say so`. But I have to ask, does that block us?
