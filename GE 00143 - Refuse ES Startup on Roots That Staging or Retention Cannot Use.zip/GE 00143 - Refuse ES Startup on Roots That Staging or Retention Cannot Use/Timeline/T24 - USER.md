<!-- reply 1 -->
> No, it doesn't block us. It only affects a staging disk that can't keep normal Unix permissions, such as some network or…


Oh, do I still need to pick from the card?
