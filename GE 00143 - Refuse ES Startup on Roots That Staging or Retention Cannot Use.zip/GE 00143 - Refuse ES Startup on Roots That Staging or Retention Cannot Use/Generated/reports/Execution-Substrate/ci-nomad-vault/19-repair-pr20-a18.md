# PR #20 audit-18 repair: the probe's comment states the chosen rule, each owner half is held, and trunk_dev is merged (A18-1, A18-2)

Report 19 of the CI Nomad/Vault track. It answers the coordinator's request of 2026-11-23 03:43Z: audit 18 of `29254b1` is BLOCK on A18-1 (`18-audit-pr20-repair2.md`). "(1) fix the comment at es/admission/execution_roots.go:573 … to match David's decision, comment only; (2) add the docs-contract line that keeps the old sentence out of code comments too; (3) also close A18-2 now rather than leave it: a test holding the owning-user half of the staged file's owner check; (4) merge trunk_dev 110d377 (no rebase …); new manifest, CI, short report. The same auditor does the small audit next."

Date: 2026-11-23. Repository: `evo-agi/Execution-Substrate`, draft PR #20. Evidence: `19-repair-pr20-a18-evidence/` next to this file. `README.md` there names every file, and `SHA256SUMS.txt` lists them.

## 1. Outcome

| Item | Result |
| --- | --- |
| A18-1 (a product comment still said staging refuses every submission) | Fixed. Comment lines only: of the 8 changed lines in `es/admission/execution_roots.go`, every one begins with `//` (section 3.1). |
| Docs contract | `TestStartupProbeUseAgreementDocsContract` now also reads the comments of the admission code. It requires the new rule sentence in the comment of `probeStagedEntries` and keeps "refuse every submission" and three variants out of every non-test file in `es/admission`, across line breaks (section 3.2). 12 docs mutants, 12 caught: the 8 of report 17 and 4 new ones on code comments. |
| A18-2 (no test held the owning-user half of the staged file's owner check) | Closed. `TestStartupProbeFileChecksRefuseAnOwnerTheFileSystemIgnores` now has one case per half: "owning user" (as root; through `sudo` when the test is not root) and "group". Each case first shows on a witness file that the mount leaves exactly that half unchanged. The auditor's F2a is now caught as `ci` and as root, and F2b too (section 3.3). |
| Merge of trunk_dev `110d377` (PR #21) | `fcf9191`, a plain merge, no conflict, no rebase. Its tree `26deaef8689d732a9ad0c81aac0fb65401322fce` is the tree of the auditor's trial merge. The pull request's patch has the same patch-id against the new base as against the old, `32cdf1a018d6181b41200a426ebb6253392194fe` (section 2). |
| Product code | Comment lines in `es/admission/execution_roots.go` only. No other non-test file under `es/admission`, and no script or workflow, changed. |
| Mutants | The auditor's 55 audit-16 mutants and 8 audit-18 mutants, rerun on the head as `ci`: 52 of 63 caught by behaviour tests (44 of 55 at `29254b1`, plus all 8 finer ones), 4 more only by the typed inventories, and the same 7 survivors as report 17. The control O9 survives as it should. As root, all 22 owner, file and retained-file mutants are caught, F2a and F2b among them; the control O9 survives (section 4.2). |
| CI | Run [45108060209](https://github.com/evo-agi/Execution-Substrate/actions/runs/45108060209) on `d8826b8`: success. In `es/admission` only the two listed opt-in tests skipped, so both new cases ran as `runner` (section 4.4). |
| Head | `d8826b884571e2ece19bc69f7daecb1c4918802a` on `claude/project-thread-a9tcoa-setgid-probe`, draft [PR #20](https://github.com/evo-agi/Execution-Substrate/pull/20). Tree `b3b240d01dd540390c72243eb1ab7c467907e036`. |
| Manifest | `abd78ebc6e5627d1ba541bf98eabd253e6c27ec02b813c13307d1926f6058e00`, against base `110d377`, upstream `origin/trunk_dev`, 19 files. Taken twice from one fresh clone; the two runs are byte-identical. |

Nothing was merged into trunk_dev.

## 2. Target identity

| | Value |
| --- | --- |
| Branch | `claude/project-thread-a9tcoa-setgid-probe` |
| Head | `d8826b884571e2ece19bc69f7daecb1c4918802a`, tree `b3b240d01dd540390c72243eb1ab7c467907e036` |
| Commits since `29254b1` | `fcf9191` "Merge trunk_dev 110d377 (PR #21) into the startup probe branch" (parents `29254b1`, `110d377`; tree `26deaef8…`), then `d8826b8` "State the chosen mode rule in the probe's comment and hold each owner half (A18-1, A18-2)" |
| Base | `110d377a459471e94aa14cc83877f554ae62f893` (trunk_dev, PR #21); it was `f62d024` for reports 15 and 17 |
| What the merge brought in | One file, `remote_alpha_es_service_tls_status_test.go` (+84/−7), byte-identical to trunk_dev's. The pull request does not touch it. |
| Manifest tool | `governed_execution_audit_patch_manifest_v2.py`, sha256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` |
| Manifest recipe | `mkman.sh` (in the evidence): umask 022; fresh `git clone --branch claude/project-thread-a9tcoa-setgid-probe`; HEAD checked to be `d8826b8`; `git fetch origin trunk_dev`, checked to be `110d377`; `110d377` checked to be an ancestor; clean worktree; `git reset --mixed 110d377`; `git branch --set-upstream-to=origin/trunk_dev`; `python3 -I` the tool twice; `cmp` of the two outputs |
| Manifest | `abd78ebc6e5627d1ba541bf98eabd253e6c27ec02b813c13307d1926f6058e00` (`manifest-v2-pr20-d8826b8.json`), 19 files, textual diff sha256 `a17410db48b97dbe69daddc79c87216d6339ae4a48a5d3fa69342ddfef7490da` |

The manifest has the same 19 paths as report 17's. The merged file is not among them, since it is the same on both sides.

The delta for the audit is `fcf9191..d8826b8` (`fix-fcf9191-d8826b8.diff`), which is byte-identical to `29254b1..d8826b8` with the merged file left out: 3 files, 88 insertions, 16 deletions.

| File | Change |
| --- | --- |
| `es/admission/execution_roots.go` | A18-1: the comment of `probeStagedEntries`, 1 line out and 7 in, all comment lines |
| `docs_contract_test.go` | the comment rule of section 3.2 (+25) |
| `es/admission/execution_roots_probe_refusal_reasons_linux_test.go` | A18-2: two cases and a shared helper with the witness file (+55/−15) |

`merge-and-delta-checks.txt` holds the commands and their output: parents and trees, the merged file against trunk_dev, both patch-ids, the stat of the fix commit, the count of changed non-comment lines in `execution_roots.go` (0), and the list of changed non-test files under `es/admission` (only that file).

## 3. The changes

### 3.1 A18-1: the comment of `probeStagedEntries`

Before (line 573 at `29254b1`):

```go
// cannot keep. Staging would refuse every submission there.
```

After:

```go
// cannot keep. Staging would refuse submissions there: on such an overlay all
// of them, and on a file system that cannot keep a mode, those that need it.
// The governed-mount modes are needed only by submissions with governed
// mounts, so startup also refuses a staging file system that cannot keep
// them, although submissions without governed mounts would work there. That
// is the chosen rule (STARTUP-PROBE-USE-AGREEMENT-01): no submission ES
// accepts fails for want of a mode.
```

The first sentence is the auditor's suggested wording, lightly reordered. The comment names the rule's PLANS.md id, so a reader of the function finds the decision. It also says "no submission ES accepts fails for want of a mode" rather than PLANS.md's "every submission it accepts can be staged", which A18-3 reads as wider than the probe proves (section 5).

### 3.2 The docs contract reads the admission code's comments

`TestStartupProbeUseAgreementDocsContract` gains a helper `commentText(path)`. It trims each line, drops a leading `//`, and collapses whitespace with the contract's existing `compactText`, so a phrase that spans comment lines reads as one. Then:
- `es/admission/execution_roots.go` must contain "so startup also refuses a staging file system that cannot keep them, although submissions without governed mounts would work there";
- every non-test `.go` file in `es/admission` must contain none of "refuse every submission", "refuses every submission", "fail every submission", "fails every submission".

The second check reads whole files, code included. No identifier or string in the package contains those phrases, so it cannot fire on code, and it also holds a claim that might come back in a string. Docs mutants D09 to D12 (section 4.3) restore the old sentence, drop the new one, and put the claim into another admission file, once on one line and once split across two comment lines. All four are caught.

### 3.3 A18-2: one case per owner half

At `29254b1` the bindfs test asked for `54321:54321` as root, and for the caller's own user with a supplementary group otherwise. Either way the group differed, so removing `identity.UID != owner.UID` from `probeStagedFile` (F2a) changed nothing. In a whole probe that half cannot be reached, because the owner rule refuses first.

The test now has two cases, each asking for an owner that differs from the creator in one half only:
- **owning user**: `54321` with root's own group. Only root may give a file to another user; for any other caller the kernel refuses before the file system is asked. So a non-root test reruns this case as root through `rerunTestAsRootThroughSudo` (the helper report 17 already uses, which requires `--- PASS` of the exact case).
- **group**: the caller's own user with `54321` as root, or with a supplementary group of the caller otherwise. Without root and without a supplementary group it skips, as before.

Both go through a new helper, `requireProbeFileChecksRefuseIgnoredOwner`. Before it calls the probes, it creates a witness file in the same directory, gives it the requested owner, and requires that exactly one half of the result differs from the request. That shows the mount ignored the change in the half under test only, so the probe's refusal below can only come from that half's comparison. Then `probeStagedFile` must fail with "staged file ownership is unavailable" and `probeRetainedResultFile` with "retained result file ownership is unavailable", as before.

Where it runs: as `runner` on CI (passwordless sudo, bindfs, supplementary group `docker`) both cases run, and the test gate fails the check if either skips unlisted. As a user without sudo the whole test skips at `requireTestMountPrivilege`, as it did at `29254b1`.

## 4. Validation

### 4.1 Tests

Trees are `git archive` of `d8826b8`. The `ci` and root runs were in private mount namespaces (`unshare --mount --propagation private`), per the lesson that the probe tests refuse when the host mount table changes.

| User | Result |
| --- | --- |
| `ci` 30033:30033, groups 30033 996, passwordless sudo (mirrors `runner`) | `gofmt -l` empty; `go vet` linux and darwin/arm64 clean for `es/admission` and the root package; the four new and changed tests pass, including "owning user" as root through sudo and "group" with group 996; the three docs-contract tests pass; whole `es/admission` ok in 35.5 s with only the two listed opt-in skips (`log-clean-run-uid30033.log`, `log-admission-whole-uid30033.log`) |
| root | the four tests pass, both cases directly; whole `es/admission` ok in 58.4 s, with the same 6 skips as report 17's root run (tests that need a non-root caller, and the two opt-in ones) (`log-root-run-uid0.log`, `log-admission-whole-uid0.log`) |
| `ci3` 31500:31600, no sudo | `gofmt` empty, vet linux and darwin/arm64 clean; whole `es/admission` ok in 38.2 s with 11 skips, the same as report 17; the bindfs test skips at its mount-privilege check (`log-tests-uid31500.log`, `log-admission-whole-uid31500.log`). This run was not in a private mount namespace. |

### 4.2 Mutants

`mut19.py` loads audit 16's `mutants.py` unchanged (the same file `mut17.py` used) and adds audit 18's 8 finer mutants, copied unchanged from `mutants2.py` (R13a, R13b, R9a, R9b, F2a, F2b, A2, A2L). Each mutant edits a fresh copy of the tree and must apply exactly once. Targeted runs use the auditor's TARGETED list plus report 17's three tests; survivors are rerun against the whole package. No run hit mount-table noise.

As `ci` (`log-clean-run-uid30033.log`): the control M00 passes. 52 of the 63 mutants are caught by behaviour tests. Against the whole package, R11, R12, B1 and B2 are caught by `TestAdmissionProductionHasOneResolverAndOneMaterializationPath` (the typed inventory). F6, D1, R1, R2, R5, R6 and R15 survive, the same seven report 17 reviewed in its section 3.2 (no fixture reaches them on Linux without a race or a seam in product code). O9, the order-neutral control, survives.

The audit-18 mutants, against this head:

| Mutant | `ci` (sudo) | root | `ci3` (no sudo) | Caught by |
| --- | --- | --- | --- | --- |
| F2a, staged file, owning-user half removed | caught (survived at `29254b1`) | caught (survived) | survives | `…IgnoredOwner/owning_user` |
| F2b, staged file, group half removed | caught | caught (survived) | survives | `…IgnoredOwner/group` |
| R9a, retained file, owning-user half | caught | caught | caught | the table test and `owning_user` |
| R9b, retained file, group half | caught | caught | caught | the table test and `group` |
| R13a, R13b | caught | caught | caught | the table test |
| A2, A2L | caught | caught | not run | probe and agreement tests |

Without sudo the bindfs test skips, so F2, F2a and F2b survive as `ci3`, as F2 did at `29254b1`. That is why CI must run it as `runner`, and the gate makes a skip there fail the check.

As root (`log-root-run-uid0.log`): all 22 O, F2, R9, R13 and A2 mutants are caught; the control O9 survives.

### 4.3 Docs mutants

`docmut19.py` runs report 17's 8 docs mutants (D01 to D08) and 4 new ones: D09 restores the old sentence in the probe's comment, D10 drops the new rule sentence, D11 adds "fails every submission" in a comment of `staging_custody.go`, and D12 adds "would refuse / every submission" there across two comment lines. 12 of 12 caught, each by the line of the contract that holds it (`log-root-run-uid0.log`, section "docs mutants").

### 4.4 CI

Run [45108060209](https://github.com/evo-agi/Execution-Substrate/actions/runs/45108060209), job 137473797976, on `d8826b8`: success. Build, vet, vet for macOS, "Check the test gate", test, and "Listed tests still fail" all passed. `es/admission`: ok in 59.3 s, "2 tests skipped themselves", the two listed opt-in swap stress tests. So both new cases ran as `runner`. The root package, which holds the docs contract, passed. Gate: "41 packages, 3 of them with skipped entries (15 entries); 41 tests skipped themselves, all of them listed". The log is `ci-pr20-45108060209-job137473797976.log`.

## 5. Other observations

- **A18-3** ("ES starts only where every submission it accepts can be staged" reads wider than the probe proves). No change. The auditor reads it, in its paragraph about modes, as the reason for the rule and not as a false claim. The new comment avoids the wider wording.
- **A18-4** (A16-4, A16-6, A16-9, A16-10, A16-11) carried over unchanged. On A16-11: the trailer is the session's required commit attribution, and `d8826b8` changes product code in comment lines only.
- The merge commit `fcf9191` carries the same trailers, and its message says only what it merges.

## 6. For the next audit

As audit 18 listed, extended by the test that the coordinator asked for:
1. The manifest `abd78ebc…8e00` should reproduce from a fresh clone at `d8826b8` against `110d377`.
2. Against `29254b1`, outside the merged file, only three files change: comment lines in `es/admission/execution_roots.go`, the contract lines in `docs_contract_test.go`, and the A18-2 test.
3. The merge `fcf9191` has no conflict; its tree is the trial merge's `26deaef8…`.
4. Build, vet and CI are green on `d8826b8` (run 45108060209).

The A18-2 test is new test code, so the audit may want to rerun F2a and F2b. `mut19.py` and the run scripts are in the evidence.

After an ACCEPT, PR #20 goes to David for review, as the first product merge into trunk_dev.
