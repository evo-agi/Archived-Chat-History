# ES PR #20 audit of the repair: startup probe agrees with staging and retention

Independent correctness audit, requested by the coordinator on 2026-11-23. Written by the audit thread "Audit the staging check repair", from about 01:45Z to 02:45Z on 2026-11-23 (container clock). I am not the writer. I did not push, comment on, or merge anything.
Evidence: `16-audit-pr20-repair-evidence/` beside this file. Its `README.md` explains every file and `SHA256SUMS.txt` lists them.

**Final verdict for `b5cc7cb`: BLOCK.** Two low findings on the patch need a change before merge. Neither says that the product code does something unsafe today. One is a test that does not guard half of the rule it names. The other is a start that is now refused although submissions without mounts work, which the report and two doc sentences deny; it needs a decision from David. Both repairs are small, and neither needs a change to the repaired checks themselves.

What holds (all checked on the exact pushed bytes):
- **Provenance reproduces.** Manifest `9d277408…1b4a`, 18 files, base `f62d024`, two runs byte-identical, equal to the writer's file, and equal again at the end of the audit.
- **The owner check comes before every owner and mode change, in all three places** (`execution_roots.go:513`, `staging_custody.go:556` and `:637`). Files are created and opened in one step, so they have no such window.
- **The swap race is closed.** 1000 starts as root per target: 0 hits on the head. The same binary harness on the tree before the repair: 21 and 4 hits.
- **Every staged mode is probed and no other mode can be staged.** Every production call passes a listed mode (read from source). Dropping any mode from the probe or from the list, or removing either guard, fails a behaviour test.
- **The no-replace rename is really probed.** Removing the free-name rename, or doing it with a plain rename, fails the bindfs tests.
- **The four red-team tests are adopted byte for byte** (same patch-id as `93a0833`), fail on the tree before the repair, and pass on the head.
- **The red-team matrix, rerun before and after the repair (1,920 cells):** all 638 working cells still work, all 367 gap cells are now refused at startup, no cell is a false refusal. The writer had not rerun it.
- **CI run 45094162628 is green** on `b5cc7cb`. bindfs `1.14.7-1.1build2` was installed, the three bindfs tests ran, and only the two listed stress tests skipped themselves.
- **The merge of `trunk_dev` is clean.** Redoing it gives the same tree as `c50f36a`. The trunk side changed one file that the PR does not touch.
- **55 mutants of my own: 38 caught by behaviour tests, 5 more by the typed source guardrails, 12 survive.** Ten survivors change no start-or-refuse outcome in 3,280 matrix cells or are unreachable on Linux. Two survivors are finding A16-1.

What blocks:
- **A16-1 (low, tests).** The rule is "refuse before any owner or mode change". The gating tests only see an owner change. A mutant that changes the directory's mode first and checks the owner afterwards passes every gating test at two of the three places. With that mutant, the opt-in stress test shows root changing another user's directory from `1777` to `0750` in 14 of 1000 starts. The opt-in test does not run in CI. I wrote a 3-case test that catches all three mutants without a race, to show the gap can be closed with a test alone.
- **A16-2 (low, behaviour and docs; decision for David).** ES now refuses to start on a staging file system that cannot keep the modes that only governed mounts use (`0755` directories, `0644` and `0755` files). Before the repair ES started there, and every submission without governed mounts was staged, retained and read back. It still is on the head, if the probe is ignored: the red-team harness labels all 8 cells I built `FALSE-REFUSAL`. The writer's report says "No setup that works is newly refused", and `PLANS.md` and `capability_probing.md` say such file systems failed "every submission". Refusing may well be the right product choice. It is a tradeoff, so it is David's, and the bytes must say what was chosen.

What the next steps need to know:
- This audit binds `b5cc7cb` only. A repair makes new bytes and needs new provenance and a fresh, narrow audit.
- This is product code and the first product merge of the Claude era. David's review follows an ACCEPT, not this report.
- Not run: macOS and the Remote Alpha host. Section 8 lists what stands in for them and what does not.

## 1. Audit target

| Field | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate`, draft PR #20 into `trunk_dev` |
| Topic branch | `claude/project-thread-a9tcoa-setgid-probe` |
| Head | `b5cc7cb78d3e9f14b015403fcad5451da5957f75`, also `refs/pull/20/head` (`git ls-remote` at the end; PR API at the start) |
| Head tree | `9de2a9338f328704642b14d58a0b73a08385ab3c` |
| Base | `trunk_dev` at `f62d0245e95e2b411be16511fc1bf9e1da727ce5`, an ancestor of the head; unchanged at the end of the audit |
| Scope asked | the repair delta `eb6eea9..b5cc7cb`, and whether the whole PR at `b5cc7cb` against `f62d024` still holds |
| Commits in the delta | `c27c689` (red-team tests), `c50f36a` (merge of `f62d024`), `259480a`, `91a9865`, `b5cc7cb` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified before each run) |
| Canonical manifest | SHA-256 `9d277408770cc0cc07d9082ca8d36f1be981b9191dbd492872fb6faa1e571b4a`, 18 changed paths, `textual_diff_sha256` `148852d4…d2e4` |
| PR state when read | draft, 18 files, +1931/−92, 9 commits, mergeable state "clean" |
| Writer's report | `15-repair-pr20.md`, SHA-256 `4cf7a048eff408ae8678834258c65375eff5ea167453d36b466ad06e7459943c` (verified); its evidence folder's `SHA256SUMS.txt` checks out |
| Earlier reports | `13-audit-pr20.md` (`301a7b1d…d8e5`), `14-red-team-pr20.md` (`8252af65…4b65`), both verified |

Audit posture: read-only. Parent thread only; no subagents. All work ran in this cloud container. Nothing ran on David's Mac or on the Linux box.

## 2. Provenance reproduction

Commands as in provenance §5.3, in a fresh clone (`es-prov`), with the recipe copied and its hash verified first:

```text
git fetch -q origin trunk_dev claude/project-thread-a9tcoa-setgid-probe
origin/<topic> = b5cc7cb78d3e9f14b015403fcad5451da5957f75      (equals the reported tip)
git merge-base --is-ancestor f62d024… b5cc7cb…                 (yes)
git checkout -q -f -B <topic> b5cc7cb… ; git status --porcelain (empty)
git reset -q --mixed f62d024… ; git branch -q --set-upstream-to=origin/trunk_dev
python3 -I v2.py 1.json ; python3 -I v2.py 2.json ; cmp 1.json 2.json   (identical)
```

- Opening manifest: `9d277408…1b4a`, 18 files. `cmp` with the writer's `manifest-v2-pr20-b5cc7cb.json`: identical.
- Mode bits: no difference of any kind. Nothing had to be tolerated.
- Closing manifest, after all work, with the upstream pinned again and `origin/trunk_dev` still `f62d024`: two runs identical, and `cmp` with the opening manifest: identical.
- I never wrote into the provenance clone. Tests ran in separate checkouts and scratch copies.

## 3. Scope of the change

Product code is two files: `es/admission/execution_roots.go` and `es/admission/staging_custody.go`. The rest is tests (nine files), docs (`PLANS.md`, two `.docs` files, one runbook, `docs_contract_test.go`) and CI (`go.yml`, the gate self-test's hash pin, two lines in `environment-only-tests.txt`).

The delta `eb6eea9..b5cc7cb`:
- `c27c689` has the same patch-id as the red-team's `93a0833`, and its two test files are the same blobs. Later commits changed only their header comments.
- `c50f36a` merges `f62d024`. I redid the merge from `c27c689`: same tree (`1d4cd9f2…`). The trunk side changed only `es/admission/internal/reliablesubmit/sqlite_physical_test.go`.
- `259480a`, `91a9865` and `b5cc7cb` are the repair, its test and doc follow-ups, and the workflow comment.

## 4. Coverage

Read in full on the head: both product files; `results.go` and `result_auth.go` for the calls the probe mirrors; all new and changed test files; the docs, runbook and CI diffs; the CI job log; the protocol and provenance rules; reports 13, 14 and 15.
Not inspected: packages outside `es/admission` beyond a search of the whole module for owner and mode changes; the unchanged parts of `docs_contract_test.go`; schemas and migrations (none changed).

## 5. Review

### 5.1 RT-3: no directory opened by name changes its owning user

`requireOpenedDirectoryOwnedByRootsUser` (`staging_custody.go:181`) stats the opened descriptor and refuses unless its owning user is the roots' owning user. It is called at `execution_roots.go:513` (startup probe), `staging_custody.go:556` (claim of a run staging root) and `:637` (directories inside it). In each place it comes before `Fchown` and `Fchmod`.

I searched the module for every owner or mode change. In `es/admission` these three are the only ones on a directory. All others are on files that were created and opened in one call (`O_CREAT|O_EXCL`), so nothing can be put in their place. The check and the change use the same descriptor, so the owner cannot differ between them unless root changes it.

What remains is what the red-team recorded as O-3: a directory that already belongs to the roots' owner, put there by somebody who may rename entries in the roots, gets the roots' group and mode. That needs roots that others can write. The writer documents it. I agree it is outside this repair.

### 5.2 RT-1: every staged mode is probed

`stagedFileModes()` and `stagedDirectoryModes()` (`staging_custody.go:144-159`) list five file modes and two directory modes. The probe stages one entry of each inside its nested directory (`execution_roots.go:574-629`) with staging's own checks: regular file, one link, the staging root's device, the roots' owner, the exact mode. `ensureDirectory` and `writeFileWithHookAndParentMode` refuse any mode outside the lists (`:582`, `:702`).

Every production call passes a listed mode: `executionpackage.go:136, 140, 179, 182, 185, 254` and `mounts.go:219, 228, 662, 667, 670`, where the file mode comes from `normalizedGovernedMountFileMode` (`0644` or `0755`).

The cost of probing every mode is finding A16-2: three of the seven modes are used only when a submission has governed mounts (`mounts.go:212-215` returns before creating anything when there are none).

### 5.3 RT-2: the no-replace rename

`probeRetainedResultFiles` (`execution_roots.go:674-727`) creates a `0600` and a `0640` file inside the natural result directory with retention's checks, then renames the `0600` file with the no-replace rename onto an existing name, which must fail with `EEXIST`, and onto a free name, which must succeed and leave the same object with the same identity. The second rename is the one that asks the file system. Retention's own two renames (`results.go:677`, `result_auth.go:353`) use the same call in the same kind of directory.

### 5.4 Re-observation

Report 15 says the probe re-observes both roots before every effect. On the head the five staged files share one re-observation, and so do the retention files and renames. The total stays 15 per start. The effects in each batch go through descriptors inside directories the probe has just made, and `NewService` re-observes once more at the end, so I see no safety loss. The docs in the PR do not claim per-effect re-observation. The PR body still does. Observation A16-8.

### 5.5 Leftovers

A start now leaves 13 entries (9 under the staging root, 4 under the results root) where the base left 5. They are kept on purpose under the existing rule that ES does not unlink what it cannot prove it owns. `TestExecutionRootCapabilityProbeCoversBothConfiguredRoots` pins the exact set, owners and modes.

## 6. Validation I ran

All on `b5cc7cb` unless said otherwise. Identities: `ci` (30033, passwordless sudo, bindfs installed), `ci3` (31500, no sudo), root.

### 6.1 Static checks and tests

| Check | Result |
| --- | --- |
| `go build ./...`, `gofmt -l` on the changed Go files, `go vet ./es/admission .` | clean |
| `GOOS=darwin GOARCH=arm64` vet and build | clean (type-check only; nothing ran on macOS) |
| whole `es/admission`, `-count=1 -v`, as `ci` | `ok`, 1,110 runs, 2 skips (the two listed stress tests) |
| the same as `ci3` | `ok`; 10 skips, all tests that need sudo or the opt-in variable |
| the same as root | `ok`; 6 skips, all tests that need an unprivileged user or the opt-in variable |
| `go test ./...` as `ci`, head and base | the same 10 tests fail on both, all of them entries of `environment-only-tests.txt`; every other package passes on both |
| the four adopted red-team tests on `c50f36a` (red-team tests, product code before the repair) | all four fail |

### 6.2 Swap stress (`TestExecutionRootProbeDirectorySwapStress`, 1000 rounds per target, as root)

| Binary | probe target | nested target |
| --- | --- | --- |
| head `b5cc7cb` | 0 of 1000 | 0 of 1000 |
| before the repair (`c50f36a`) | 21 of 1000 | 4 of 1000 |
| head with mutant O10 (mode change before the owner check) | 14 of 1000 | 0 of 1000 |

On the head the nested target cannot be reached: a root ES on roots owned by another user is now refused at the first directory, so that half passes without testing anything (observation A16-7). The probe target still has teeth, as the third row shows.

### 6.3 The red-team matrix, before and after the repair

The red-team's harness and case builder, rebuilt in this container: 32 layouts, 4 identities, 16 mounts (ext4, tmpfs, grpid, xfs, three overlays, an idmapped mount, seven bindfs variants and the container's own file system; no btrfs). 1,920 cells per tree. "Before" is `c50f36a`, whose product code equals `eb6eea9`.

| Before | Head | Cells |
| --- | --- | --- |
| works | works | 638 |
| ES ready, every submission fails | refused at startup | 161 |
| ES ready, every retention fails | refused at startup | 206 |
| refused | refused | 869 |
| roots cannot be set up | the same | 46 |

No cell is a false refusal and no gap is left. 38 of the "refused, refused" cells are a root ES on roots owned by another user: refused before at the result directory, now refused at the first staging directory, before any owner change.

### 6.4 A cross matrix of my own

The red-team's matrix puts both roots on one file system. I added pairs: staging on one of 17 mounts, results on another, plain ownership, five identity setups. 1,360 cells per tree.

- 336 working cells still work. 336 gap cells are now refused. 0 gaps left.
- **8 cells that worked are now refused**: a root ES with roots owned by root, staging on a bindfs mount that gives new entries to another user (`--create-for-user`). Before, root created the entries, they appeared as that user, and root gave them back to root. Now the owner check refuses. This is the RT-3 rule doing what it says, and `PLANS.md` states the rule. Observation A16-3.

### 6.5 A staging file system that keeps no permission bits for others

Neither matrix has a file system on which only the governed-mount modes fail, and the red-team harness's real `Submit` has no mounts. So I added one: bindfs with `--perms=o-rwx` under the staging root, results on ext4, tmpfs, xfs and the container's file system, as root and as `ci`. 8 cells per tree.

| Tree | Startup probe | Real `Submit` (no mounts) | Retention and read | Staging with a mount tree | Harness label |
| --- | --- | --- | --- | --- | --- |
| before the repair | passes | works | works | fails | `AGREE-OK+DIRECT-DIFFERS` |
| head | refuses: `staged 0755 directory mode is unavailable` | works | works | fails | `FALSE-REFUSAL+DIRECT-DIFFERS` |

All 8 cells behave the same way. This is finding A16-2.

### 6.6 The PR's own CI

Run 45094162628, job 137430212947, on `b5cc7cb`: success. From the job log:
- `bindfs 1.14.7-1.1build2` and `libfuse2t64 2.9.9-8.1build1` installed from `noble/universe`.
- The gate self-test ran 121 tests, including the one that holds `go.yml` by its SHA-256.
- `ok execution-substrate/es/admission 93.632s`; 2 tests skipped themselves there, both listed.
- "test gate passed: 41 packages, 3 of them with skipped entries (15 entries); 41 tests skipped themselves, all of them listed".
- "all 15 listed tests still fail on this host".

### 6.7 The bindfs pin

The coordinator asked whether the pin is integrity-checked and whether it widens CI trust.

- **Integrity.** The version is fixed (`bindfs=1.14.7-1.1build2`), and `go.yml` is held by its SHA-256 in the gate self-test (`48e87597…8474`, equal to the file on the head), so the version cannot change without the self-test changing in the same commit. The package's bytes are checked by apt against Ubuntu's signed index. Inference: that is apt's default, the step does not disable it, and the log shows no warning; I did not test it by tampering. The repository holds no hash of the package. The dependency `libfuse2t64` is not pinned.
- **Trust.** No new trust root: the package comes from the same Ubuntu archive the runner image is built from. What is new: two more packages from `universe` are installed, and the tests run bindfs as root through sudo. The job's token is read-only, the checkout keeps no credentials, the trigger is `pull_request`, and the job uses no secrets. A bad package could falsify that run's result, as any tool on the runner could.
- The step adds `apt-get update` to every run, so a mirror outage now fails the job. It fails closed.

I record this as observation A16-6, with a hardening option. It does not block.

### 6.8 Mutants

55 mutants on scratch copies, each run against the probe's behaviour tests as `ci`; the owner-check mutants also as root; survivors against the whole package. `mutants.py.txt` has every mutant.

| Group | Mutants | Result |
| --- | --- | --- |
| Owner check removed, moved after the owner change, or comparing with the wrong user, at each of the three places | O1 to O8 | all caught, as `ci` and as root |
| Mode change moved before the owner check | O10, O11, O12 | none caught by a behaviour test. O11 (claim) is caught by a typed order guardrail. **O10 (probe) and O12 (`ensureDirectory`) survive everything.** Finding A16-1 |
| Probe skips one staged mode, or stages no file | P1 to P7 | all caught |
| A mode guard removed; a mode dropped from or added to a list | G1, G2, L1 to L7 | all caught |
| Staged file and directory checks | F1 to F6, D1 to D5 | 8 caught; F2 (owner re-check), F6 (link count), D1 (directory device) survive |
| Free-name rename removed or made a plain rename; evidence file dropped; collision target dropped; device or mode check on retained files removed | R3, R4, R7, R8, R10, R14 | all caught |
| Collision rename accepts any error, or any outcome | R1, R2 | survive |
| Checks after the rename; owner and link-count checks on retained files | R5, R6, R9, R13 | survive |
| No `Fchown` or `Fchmod` on retained files; a batch re-observation removed | R11, R12, B1, B2 | caught only by the typed call inventories |
| Control: owner check moved after the re-observation, still before the owner change | O9 | survives, as it should |

About the survivors other than O10 and O12:
- I built one binary with F2, F6, D1, R2, R5, R6, R9 and R13 applied together and ran both matrices on it: all 3,280 cells have the head's verdict. Binaries with R11 and with R12 alone: the same. A first run of the combined binary differed in 5 cells; all 5 were ES refusing because the mount table changed while my other tests were mounting file systems. The rerun without that noise is the one I count; the noisy logs are kept.
- R1 and R2 are the brief's "accept replace on rename". **No test kills them, and on Linux no test can without a seam:** the kernel answers a no-replace rename onto an existing name with `EEXIST` before it asks the file system. The half of RT-2 that matters, the free-name rename, is pinned (R3, R4). Observation A16-4.

## 7. Findings

Severity is for the product. "Patch" means the repair introduced it; "older" means the base has it too.

### 7.1 On the patch

```text
AUDIT FINDING
ID / Type / Severity: A16-1 / test gap on a security ordering rule / low
Current contract or strategic target: PLANS.md, STARTUP-PROBE-USE-AGREEMENT-01: the
  probe, the claim and ensureDirectory "refuse a directory whose owning user is not
  already the roots' owning user, before any owner or mode change". The new test
  says the same in its comment (execution_roots_owner_check_test.go:59-60).
Path and line: es/admission/execution_roots.go:513-527; staging_custody.go:556-564
  and 637-651 (correct on the head). Tests:
  execution_roots_owner_check_test.go:65-143 (checks the owner and the error text
  only); execution_roots_probe_use_agreement_linux_test.go:198-256 (checks the
  owner only).
Evidence: mutants O10, O11 and O12 move the Fchmod in front of the owner check and
  leave the Fchown behind it. All three pass every behaviour test as ci and as root.
  In the whole package O11 is caught by the typed flow guardrail ("wrong governed
  order at set claimed mode"); O10 and O12 pass everything. With O10 the opt-in
  stress test fails: root changed another user's directory from mode 1777 to 0750
  in 14 of 1000 starts. That test skips itself in CI by design.
Impact: none on the head. A later edit that changes the mode before the check would
  let a root ES alter the mode of somebody else's directory before it refuses, and
  CI would stay green. For the probe that needs a root ES on roots owned by another
  user, which is itself refused; for ensureDirectory it also needs roots that
  others can write.
Required correction: a gating test that fails for O10, O11 and O12. No product
  change. One way that works: run the three cases under a process mask that removes
  the group bits, so a directory ES creates with 0750 has 0700, and require 0700
  after the refusal. My audit-only test does that and catches all three, each at
  its place, without a race (audit-only-zz_audit_mode_before_refusal_test.go.txt,
  log-audit-only-mode-test.log). The writer may choose another form.
Uncertainty: none about the survival. That the mask is the simplest way is a guess.
Patch defect or pre-existing issue: patch (its tests).
```

```text
AUDIT FINDING
ID / Type / Severity: A16-2 / start refused although use works; docs and report say
  otherwise / low
Current contract or strategic target: PLANS.md, STARTUP-PROBE-USE-AGREEMENT-01: "the
  configured-Submit startup probe and use must agree". The adopted test file states
  it "in either direction". PLANS.md:803-804 and capability_probing.md:155-157 say
  the newly refused file systems failed "every submission". Report 15, 3.4: "No
  setup that works is newly refused."
Path and line: es/admission/execution_roots.go:574-596 (the probe stages every
  listed mode); staging_custody.go:144-159 (the lists include governedMountDirMode
  0755, governedMountFileMode 0644, governedMountExecFileMode 0755);
  mounts.go:212-215 (a submission without governed mounts stages none of them).
Evidence: staging on bindfs --perms=o-rwx, results on four ordinary file systems, as
  root and as ci, 8 cells. Before the repair: probe passes, real Submit works,
  retention and read work. Head: probe refuses with "staged 0755 directory mode is
  unavailable"; real Submit, retention and read still work. The harness labels all
  8 FALSE-REFUSAL (log-noother-*.log). Neither earlier matrix could show this: both
  roots were on one file system there, and bindfs fails retention for another
  reason.
Impact: after this change ES does not start on a staging file system that keeps
  owner and group bits but not the bits for others, or that otherwise cannot hold
  0755 and 0644. Deployments that never use governed mounts worked there. It fails
  closed with a clear message. How common such file systems are: unknown. I measured
  only bindfs.
Required correction: a decision, then bytes that match it.
  (a) Keep the refusal. Say in PLANS.md, capability_probing.md and the runbook that
      startup requires every mode any submission can need, including the modes of
      governed mounts, and that such a file system is refused although submissions
      without mounts would work. Correct "every submission". Pin the case with a
      test.
  (b) Do not refuse startup for the modes only governed mounts need; refuse a
      submission with governed mounts there instead, with a named reason.
  I recommend (a): an ES that is ready but fails some submissions is the symptom
  this PR exists to remove, and (b) adds a second kind of readiness. It is a
  tradeoff between starting less often and failing later, so it is David's call.
Uncertainty: whether any real deployment uses such a file system is unknown.
Patch defect or pre-existing issue: patch. At eb6eea9 the probe staged only 0750
  directories.
```

Observations on the patch. None needs a change before merge on its own.

- **A16-3. The owner rule refuses a setup that worked.** A root ES whose staging file system gives new entries to another user than the roots' owner (8 cells, section 6.4). `PLANS.md` states the rule ("Entries ES creates must therefore already belong to the roots' owning user"), and it is the price of RT-3. Report 15's "No setup that works is newly refused" is wrong here as well. If A16-2 is repaired by option (a), the same doc passage is the place to name this case.
- **A16-4. The existing-name half of the rename probe has no test that can reach it on Linux** (mutants R1, R2). The writer disclosed R1 as M24. A seam around the rename call, or a run on macOS, would reach it.
- **A16-5. Report 15, observation 3, gives the wrong cause for one case.** A root ES with staging on a local file system owned by another user and results on a bindfs that forces that owner: before the repair ES started, and retention then failed at the rename (`invalid argument`), not at the natural directory. Inference, not run: on a forced-owner file system that supports the no-replace rename, that setup worked before and is refused now. It is A16-3 seen from the other root.
- **A16-6. The bindfs pin is a version pin** (section 6.7). Hardening option: download the package, compare it with a SHA-256 kept in the workflow, then install it, and pin `libfuse2t64` the same way. The signed index lists `a1a8fb5fabe490193759fd731c7edb95b44a7fcc78f680dfcb9d06fd23c317e8` for `bindfs_1.14.7-1.1build2_amd64.deb`, as seen from this container.
- **A16-7. The stress test's nested target is unreachable on the head** (section 6.2). Its comment still presents both targets as live.
- **A16-8. "Re-observation before every effect"** is no longer true of the probe (section 5.4). Report 15 and the PR body say it; the docs in the PR do not. The PR body should be brought up to date before a squash merge, because the squash message is usually taken from it.
- **A16-9. Retention's modes have no list and guard like staging's.** A new retention file mode would be noticed only by the typed creation inventory.
- **A16-10. Other surviving mutants** (F2, F6, D1, R5, R6, R9, R13, and R11, R12, B1, B2 behind the inventories): no outcome changes in 3,280 cells. They guard against file systems that no fixture here provides.
- **A16-11. For the coordinator, a process fact.** The trailers of `259480a`, `91a9865`, `b5cc7cb` and the merge `c50f36a` name Claude [model withheld]; `c27c689` names Claude [model withheld]. Whether that matches the model rule for writers of sensitive ES product code is the coordinator's to judge. It does not bear on correctness.

### 7.2 Older issues, not caused by the patch

- **Red-team O-3** (section 5.1): a swapped-in directory that already belongs to the roots' owner gets the roots' group and mode. Needs roots others can write. Documented.
- **Red-team O-1**: a re-observation fails when the mount table changes between two reads, with no retry. I hit it 6 times in one run of the two matrices while my own tests were mounting file systems (5 cells changed their label; section 6.8). The probe makes 15 re-observations per start, as it did at `eb6eea9`.

## 8. Validation assessment

Re-run by me: provenance (twice, opening and closing); build, vet, format and two Darwin cross-checks; the whole `es/admission` package as three identities; the whole module on head and base; the adopted tests on the tree before the repair; the swap stress on three binaries; the red-team matrix and a cross matrix on five binaries; the no-other-bits fixture; 55 mutants.

Read, not re-run: the PR's CI (job log fetched and read).

Not run, and what stands in:
- **macOS.** Only type-checked. The stricter `EEXIST` rule and the free-name rename go through `renameatx_np` there and have never executed. Inference: APFS answers both as the probe expects. A run of `go test ./es/admission` on the Mac before merge would settle it.
- **The Remote Alpha host, real NFS, CIFS, CephFS, 9p, btrfs.** bindfs stands in for file systems that bend one rule. The writer's list of file systems without the no-replace rename rests on kernel source, not on runs.
- **The real `es` binary.** The first audit ran it. The delta does not touch where `NewService` calls the probe (diff), and `TestRetainedResultReviewStartupNaturalDirectoryMask` runs `NewService` under three process masks.
- **Submissions with governed mounts through the real `Submit`.** The hermetic fixture has none; direct staging of a mount tree stands in.

Limits: the swap stress is a race, so 0 of 1000 is evidence, not proof; the deterministic tests carry the proof for the owner, and A16-1 is where they stop.

## 9. Sensitive-material handling

No secrets, keys, tokens or env files were read or written. The CI log is GitHub's own, already masked, and the writer's evidence holds the same file. I scanned the evidence folder for addresses, tokens and key material: only test names matched. No personal data is in the evidence.

## 10. Remaining uncertainty and stop conditions

- How common file systems like the one in A16-2 are. Unknown.
- macOS behaviour of the new rename checks. Inference only.
- If the repair changes more than tests, docs and (for option b) the mode handling, the narrow re-audit should widen.
- Stop condition for the merge gate: the PR head must equal an accepted commit. `b5cc7cb` is not accepted.

## 11. Confidence

| Kind | Level | Why |
| --- | --- | --- |
| Provenance | high | recipe verified; two runs identical; equal to the writer's manifest; closing equals opening; remote refs unchanged at the end |
| Validation | high on Linux, none on macOS | three identities, 3,280 cells on two trees, stress with a sensitivity check, 55 mutants; macOS only type-checked |
| Implementation | high that the checks do what they say; the two findings are about what guards them and what they cost | every claim of the writer about the code reproduced, except "no working setup is newly refused" |

## 12. Effect status

Repair: not performed. Commit: none. Push: none. PR: not edited, not commented, not reviewed. Merge: none. GitHub calls: `git fetch`, `git ls-remote`, and reads of PR #20, run 45094162628 and its job log. Scratch trees, mounts and users live in this container and go away with it.

## 13. Report delivery

`/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/16-audit-pr20-repair.md`. Its SHA-256 is in the thread reply and in project memory, because a file cannot hold its own hash. Evidence: `16-audit-pr20-repair-evidence/` with `SHA256SUMS.txt`.

## 14. Final verdict

**BLOCK** for `b5cc7cb78d3e9f14b015403fcad5451da5957f75` (base `f62d024`, tree `9de2a933…`, manifest `9d277408…1b4a`), on A16-1 and A16-2.

Next: David decides A16-2 (keep the refusal and say so, or let ES start and refuse only submissions with mounts). The writer then adds the test for A16-1 and the docs or code for A16-2, takes new provenance, and a fresh audit checks the new bytes. David's review of the product change follows that audit.

STATUS: NEEDS DAVID
