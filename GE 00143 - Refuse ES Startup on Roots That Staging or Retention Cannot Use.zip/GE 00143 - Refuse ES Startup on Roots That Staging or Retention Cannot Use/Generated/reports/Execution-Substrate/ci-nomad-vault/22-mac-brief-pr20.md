# Mac run brief: PR #20 at d8826b8, `go test ./es/admission`

Prepared 2026-11-23 for the first macOS run of PR #20 (product code in `es/admission`: ES's startup probe and staging custody). macOS has only cross-built and vetted this code so far; the Darwin no-replace rename and the probe's staged entries have never run there.

**How it runs:** when David writes "go ahead" in the PR 19/20 writer thread, that thread starts a Remote Control session on his Mac with the text below as its instructions, in the folder `/Users/ds/Repositories/Playground`. Read-only, about 5 to 10 minutes, cleans up after itself. The brief already holds every fallback, because the session cannot take follow-up instructions unless David writes in the thread again.

**What it checks:**
- whole `es/admission` at `d8826b8` (PR head), verbose, with every skip and failure reported;
- the PR's own tests that compile on macOS, in full;
- `go vet`, `gofmt` and the docs contract tests at `d8826b8`;
- whole `es/admission` at trunk_dev `110d377` (without the PR), so any Mac failure can be told apart from one that exists without this PR.

Expected here (from the cloud container, linux; darwin vet): `go vet ./es/admission` and the root package's darwin vet are clean; the docs tests pass. The tests that need passwordless `sudo` skip on a Mac without it; the PR's Linux-only test files (bindfs, mount namespaces, the swap stress test) do not compile on macOS, which is expected.

---

## Instructions for the Mac session (paste as is)

Run a read-only test check of one Execution-Substrate commit on this Mac and report the complete output. This is the first macOS run of pull request 20, which changes product code in es/admission (ES's startup probe and staging). Change nothing outside one new temporary folder.

Rules:
- Create exactly one new folder: T=$(mktemp -d /Users/ds/Repositories/Playground/es-pr20-mac.XXXXXX) and print it. Then create a marker file: touch "$T/start-marker".
- Keep /Users/ds/Repositories/Playground as your working directory for the whole run. Never cd into "$T" or anything below it, not even briefly: run every command with git -C "$T/es" or inside a subshell such as ( cd "$T/es" && … ). (If the temporary folder ever becomes the working directory, removing it at the end is refused.)
- Do not change, stage, commit or delete anything in any existing folder. You may read the origin URL of the existing clone with: git -C "/Users/ds/Repositories/Execution Substrate" remote get-url origin. Run no other command in that folder.
- Do not run sudo yourself. Some tests call "sudo -n true" on their own to decide whether to run root-only cases; without passwordless sudo they skip, which is expected. If any test output contains "the same test as root", say so in the report.
- No git push. No installs and no downloads other than the git clone and fetch. Do not touch any live service (these tests use only local fakes).
- For every go and gofmt command, set these variables, so that nothing can be downloaded and a missing toolchain or module fails loudly, and the build cache stays in the temporary folder:
    export GOTOOLCHAIN=go1.26.5 GOPROXY=off GOFLAGS=-mod=readonly GOCACHE="$T/gocache"
  Outside the clone, go version may print the Mac's go1.26.1; that is expected and not a reason to stop. Inside the clone it must print go1.26.5 (from the module cache). If it does not, stop and report instead of installing anything. For gofmt use "$(go env GOROOT)/bin/gofmt" inside the clone.
- If a go command fails because a module is missing from the module cache, report the exact error and stop. Do not download.
- If a test command fails, do not try to fix any code. Record the output and go on with the next step.
- At the end remove the temporary folder and confirm it is gone. If the removal is refused, do not retry: say so and give David the one-line command. /Users/ds/Repositories/Playground itself must still exist.

Steps:
1. Print: sw_vers, uname -m, whoami, ps -p 1 -o comm=, /bin/bash --version | head -1. Clone:
     git clone "$(git -C "/Users/ds/Repositories/Execution Substrate" remote get-url origin)" "$T/es"
2. git -C "$T/es" fetch origin trunk_dev claude/project-thread-a9tcoa-setgid-probe
   Print git -C "$T/es" rev-parse origin/claude/project-thread-a9tcoa-setgid-probe origin/trunk_dev
   (expected d8826b884571e2ece19bc69f7daecb1c4918802a and 110d377a459471e94aa14cc83877f554ae62f893; if either differs, say so and still test the commits named below).
3. git -C "$T/es" checkout --detach d8826b884571e2ece19bc69f7daecb1c4918802a
   Confirm git -C "$T/es" rev-parse HEAD 'HEAD^{tree}' (expected tree b3b240d01dd540390c72243eb1ab7c467907e036).
   Inside the clone print: go version, and go env GOVERSION GOROOT GOTOOLCHAIN GOPROXY GOCACHE. Stop here if go version is not go1.26.5.
4. At d8826b8, each with its exit status:
   a. ( cd "$T/es" && go test -count=1 -v -timeout 30m ./es/admission ) > "$T/admission-head.log" 2>&1; echo "exit $?"
      From that log report: the exit status; the last 3 lines; the number of lines matching each of '^ *--- PASS', '^ *--- SKIP' and '^ *--- FAIL'; every '--- SKIP' line together with the two lines after it (grep -E -A2 '^ *--- SKIP'); every line containing 'panic:' or 'the same test as root'; and for each failed test its complete output, from its "=== RUN" line through its "--- FAIL" line and the indented lines after it.
   b. R='^(TestExecutionRootProbe.*|TestStagingRefusesModesTheStartupProbeDoesNotProve|TestDirectoriesOpenedByNameNeverChangeOwningUser|TestRetainedResultFileIdentityErrorNamesEachCheck|TestExecutionRootCapabilityProbeCoversBothConfiguredRoots|TestStagingCustodyCapabilityProbeRetainsUnlinkUnprovenObjects)$'
      ( cd "$T/es" && go test -count=1 -v -run "$R" ./es/admission ); echo "exit $?"
      Report the complete output (it is short).
   c. ( cd "$T/es" && go vet ./es/admission ); echo "exit $?"    (expected: no output, exit 0)
   d. ( cd "$T/es" && "$(go env GOROOT)/bin/gofmt" -l es/admission docs_contract_test.go ); echo "exit $?"    (expected: no output)
   e. ( cd "$T/es" && go test -count=1 -run Doc . ); echo "exit $?"    (the docs contract tests; report the complete output)
5. At trunk_dev without this pull request, for comparison:
   git -C "$T/es" checkout --detach 110d377a459471e94aa14cc83877f554ae62f893 and confirm git -C "$T/es" rev-parse HEAD.
   f. ( cd "$T/es" && go test -count=1 -v -timeout 30m ./es/admission ) > "$T/admission-base.log" 2>&1; echo "exit $?"
      Report the same items as in a.
6. Leftovers and cleanup:
   - ps -axo pid,ppid,stat,command | grep -E 'admission\.test' | grep -v grep    (expected: no output)
   - git -C "$T/es" status --porcelain    (expected: empty)
   - find /Users/ds/go/pkg/mod -newer "$T/start-marker" -print | head -5    (expected: no output, meaning nothing was downloaded)
   - rm -rf "$T", then confirm "$T" is gone and /Users/ds/Repositories/Playground still exists.

Report back: the environment lines of step 1, the branch and commit hashes of steps 2 and 3, the go version and go env lines, and for each of a to f the exact command, its exit status and the items asked for above, with the duration of every test in b. Say plainly which commands passed and which failed. Do not summarize a failure away.
