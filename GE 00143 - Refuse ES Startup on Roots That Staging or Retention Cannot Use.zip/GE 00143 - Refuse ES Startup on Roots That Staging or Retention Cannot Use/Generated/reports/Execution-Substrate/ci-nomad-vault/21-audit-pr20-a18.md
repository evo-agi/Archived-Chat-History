# ES PR #20 small audit of the third repair: the probe's comment, the merge of trunk_dev, and the two owner halves

Small, read-only correctness audit of `29254b1..d8826b8`, requested by the coordinator on 2026-11-23 at 04:12Z. Written by the audit thread "Audit the staging check repair", the thread that wrote audits 16 and 18, from about 04:12Z to 04:38Z. I am not the writer. I did not push, comment on, or merge anything.
Evidence: `21-audit-pr20-a18-evidence/` beside this file. Its `README.md` explains every file and `SHA256SUMS.txt` lists them.

**Final verdict for `d8826b8`: ACCEPT.** The one finding that blocked `29254b1` (A18-1) is closed, and the change that closes it touches comment lines only. Observation A18-2 is closed too. Everything the writer claims about this delta reproduces. I found nothing new that needs a change.

What holds (all checked on the exact pushed bytes):
- **Provenance reproduces.** Manifest `abd78ebc…8e00`, 19 files, base `110d377`, two runs byte-identical, equal to the writer's file, and equal again at the end.
- **A18-1 is closed, and the product code does not change.** In `29254b1..d8826b8` one Go file that is not a test changes, `es/admission/execution_roots.go`. Its 8 changed lines all begin with `//`, none is a compiler directive, and the file printed from its syntax tree without comments is byte-identical before and after. So the product code is what audit 16 examined at `b5cc7cb`, statement for statement.
- **The new comment is true.** I compared each of its statements with the code and with the measured cases of audit 16 (section 4.1).
- **The merge of `trunk_dev` is clean.** `fcf9191` merges `110d377` with no conflict. Its tree is `26deaef8…`, the tree of my trial merge in audit 18 and of the merge I redid now from its two parents. It brings in one test file that the pull request does not touch. The pull request's patch has the same patch-id as before the merge.
- **The docs contract now reads the comments of the admission code.** 16 of my 16 docs mutants are caught, 8 of them new ones on code comments, also when the old claim is split over two comment lines. The 4 controls survive, as they should.
- **A18-2 is closed.** With the owning-user half of the staged file's owner check removed, the case "owning user" fails and the case "group" passes. With the group half removed it is the other way round. Both as `ci` and as root.
- **Mutants.** Of my 64, 52 are caught by behaviour tests (51 at `29254b1`), 4 more only by the typed inventories, and 8 survive: the control and the same 7 as before. The writer's numbers are the same.
- **Tests.** Build, vet and format are clean. The whole `es/admission` package passes as three identities. The whole module fails exactly the 10 tests that the new base `110d377` fails here, and nothing else.
- **CI run 45108060209 is green** on `d8826b8`, tested as merged with `110d377`. In `es/admission` only the two listed stress tests skipped themselves. GitHub reports the pull request as mergeable, state "clean".

What blocks: nothing.

What David's review and the merge need to know:
- **The verdict is for exactly this head on exactly this base.** Three other pull requests are open against `trunk_dev` (#19, #22 and #12). If one of them merges first, PR #20 is behind again and needs another branch update, a new manifest and a provenance re-check (section 6).
- **macOS has still never run this code.** It is type-checked only. I recommend one run of `go test ./es/admission` on the Mac at this head before the merge (section 8). If it were wrong there, ES would refuse to start on the Mac, loudly; it would not start and misbehave.
- The product code was audited in full at `b5cc7cb` (audit 16: 3,280 file-system cells, 55 mutants). Since then only tests, docs and these comment lines have changed.

## 1. Audit target

| Field | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate`, draft PR #20 into `trunk_dev` |
| Topic branch | `claude/project-thread-a9tcoa-setgid-probe` |
| Head | `d8826b884571e2ece19bc69f7daecb1c4918802a`, also `refs/pull/20/head` (`git ls-remote` at the start and at the end) |
| Head tree | `b3b240d01dd540390c72243eb1ab7c467907e036` |
| Commits since the last audited head | `fcf9191c15b5ecc3b35c12f12ac1377f405e0e70` (merge of `trunk_dev` `110d377` into `29254b1`), then `d8826b8` (the fix, 3 files, +88 −16) |
| Last audited head | `29254b16dcacab051a9007377083881a2c1e9d7f` (audit 18: BLOCK on A18-1 alone) |
| Base of the manifest | `110d377a459471e94aa14cc83877f554ae62f893`, which is `trunk_dev` now and the merge base |
| Scope asked | the delta `29254b1..d8826b8` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified before each run) |
| Canonical manifest | SHA-256 `abd78ebc6e5627d1ba541bf98eabd253e6c27ec02b813c13307d1926f6058e00`, 19 changed paths, `textual_diff_sha256` `a17410db…90da` |
| PR state when read (04:17Z) | open, draft, 19 files, +2246/−92, 12 commits, mergeable state "clean" |
| Writer's report | `19-repair-pr20-a18.md`, SHA-256 `28e053583eed5d9785310d1d24885bdb123cba5435587c20346a01a9749eb292` (verified); the 22 files of its evidence folder match its `SHA256SUMS.txt` |

Audit posture: read-only. Parent thread only; no subagents. All work ran in this cloud container, with the harness of audits 16 and 18. Nothing ran on David's Mac or on the Linux box.

## 2. Provenance reproduction

In a fresh clone (`es-prov3`), with the recipe's hash verified first:

```text
git fetch -q origin trunk_dev claude/project-thread-a9tcoa-setgid-probe
origin/<topic> = d8826b884571e2ece19bc69f7daecb1c4918802a      (equals the reported tip)
origin/trunk_dev = 110d377a459471e94aa14cc83877f554ae62f893    (an ancestor of the tip)
git checkout -q -f -B <topic> d8826b8… ; git status --porcelain (empty)
git reset -q --mixed 110d377… ; git branch -q --set-upstream-to=origin/trunk_dev
python3 -I v2.py 1.json ; python3 -I v2.py 2.json ; cmp 1.json 2.json   (identical)
```

- Opening manifest: `abd78ebc…8e00`, 19 files. `cmp` with the writer's `manifest-v2-pr20-d8826b8.json`: identical.
- Mode bits: all 19 entries `0644`. Nothing had to be tolerated.
- The 19 paths are the same 19 as at `29254b1`. Three of them have other bytes: `docs_contract_test.go`, `es/admission/execution_roots.go` and `es/admission/execution_roots_probe_refusal_reasons_linux_test.go`.
- Closing manifest, after all other work, upstream pinned again: two runs identical, and `cmp` with the opening manifest and with the writer's: identical. Remote refs at that time (04:30Z, and again at 04:32Z): topic branch and `refs/pull/20/head` `d8826b8`, `trunk_dev` `110d377`.
- The work tree of the provenance clone has the tree id `b3b240d0…`, the head's tree.
- I changed no file, index entry or branch of the provenance clone outside the recipe. One check computed that tree id with a temporary index, which adds objects to the clone's object store and nothing else.

## 3. Scope of the delta

`git diff --name-status 29254b1 d8826b8`:

| File | Comes from | Kind |
| --- | --- | --- |
| `remote_alpha_es_service_tls_status_test.go` | the merge `fcf9191` | test of PR #21; its blob equals `trunk_dev`'s |
| `es/admission/execution_roots.go` | the fix `d8826b8` | comment lines only (A18-1) |
| `docs_contract_test.go` | the fix | docs contract, +25 |
| `es/admission/execution_roots_probe_refusal_reasons_linux_test.go` | the fix | test, +56 −15 (A18-2) |

Nothing under `.github/` or `scripts/` changed, and no file that is not a Go file. My diff of the fix commit has the same SHA-256 as the writer's `fix-fcf9191-d8826b8.diff` (`6ee28cf4…640b`).

This is what audit 18, section 6, and the writer's report, section 6, said the small audit has to show:

| To show | Result |
| --- | --- |
| 1. The new manifest reproduces | yes (section 2) |
| 2. Outside the merge, against `29254b1`: comment lines of `execution_roots.go`, the contract lines, and the A18-2 test, nothing else | yes (this section and 4.1) |
| 3. The merge of `trunk_dev` has no conflict | yes; redone from its parents, same tree `26deaef8…` (4.4) |
| 4. Build, vet and the PR's CI are green on the new head | yes (5.1, 5.2) |
| 5. The new test, and a mutant against it (coordinator, 03:43Z) | yes; F2a and F2b, and all 64 mutants again (5.3) |

Read in full: the fix commit, the helpers the changed test calls, the comment in its place in the file, the pull request description (04:17Z), report 19.

## 4. Review

### 4.1 A18-1: the comment of `probeStagedEntries`

**It is a comment change and nothing else.** Three independent checks:
- `git diff -U0 29254b1 d8826b8 -- es/admission/execution_roots.go`: 8 changed lines, 1 removed and 7 added. Every one begins with `//` followed by a space and prose. None is a `//go:` directive, a `//line` or cgo line, or a build constraint.
- I parsed the file at both commits with `go/parser` without comments and printed the syntax trees with `go/printer`. The two outputs are byte-identical (663 lines, SHA-256 `0cb715b8…f485`). The same tool shows a difference as soon as I change one token of code.
- No other Go file that is not a test differs between `29254b1` and `d8826b8`. The same holds from `b5cc7cb`, the head whose product code audit 16 examined in full: `execution_roots.go` has the same blob at `b5cc7cb` and at `29254b1`, and no workflow, script or other product file has changed since `b5cc7cb`.

**The new text**, each statement against the code and the measured cases:

| Statement | Verdict |
| --- | --- |
| "Staging would refuse submissions there: on such an overlay all of them" | true. On an overlay whose layers are on different file systems every staged file fails staging's device check, and every submission stages files. Audit 16 measured it |
| "and on a file system that cannot keep a mode, those that need it" | true. This is the sentence that was wrong before |
| "The governed-mount modes are needed only by submissions with governed mounts" | true. `0755` directories and `0644` and `0755` files are set only in `mounts.go`. A submission without governed mounts stages `0750` directories and `0600`, `0640` and `0750` files (`executionpackage.go`) |
| "so startup also refuses a staging file system that cannot keep them, although submissions without governed mounts would work there" | true. It is David's decision of 02:48Z. `TestStartupRefusesStagingThatCannotHoldGovernedMountModes` shows both halves on one mount |
| "That is the chosen rule (STARTUP-PROBE-USE-AGREEMENT-01): no submission ES accepts fails for want of a mode" | true as the rule's aim. Startup stages one entry of every mode in the two lists, and staging refuses any mode outside the lists. It rests on what every startup probe rests on: the file system behaves at use as it did at startup. The sentence is narrower than the one in `PLANS.md` that A18-3 is about |

The old sentence, "Staging would refuse every submission there.", is gone. At the head I searched the whole tree for "every submission", "all submissions", "any submission", "each submission" and "no submission". What is left: `PLANS.md:785` (the setgid case, where every submission does fail), `PLANS.md:808` (A18-3), the phrases the docs contract requires or forbids, and the new comment. In `es/admission` and the packages below it, no Go file, test or not, contains "every submission" any more.

### 4.2 The docs contract reads the comments of the admission code

`TestStartupProbeUseAgreementDocsContract` gets a helper, `commentText`, that reads a file, drops a leading `//` from each line and joins the words with single spaces. With it the test now:
- requires the rule sentence in `es/admission/execution_roots.go` ("so startup also refuses a staging file system that cannot keep them, although submissions without governed mounts would work there");
- forbids "refuse every submission", "refuses every submission", "fail every submission" and "fails every submission" in every file `es/admission/*.go` that is not a test.

What I checked, with docs mutants of my own (5.4):
- The old comment put back, alone or beside the new one, fails the test. So does the rule sentence removed or changed by a word.
- The claim put into another admission file fails the test on one line, split over two comment lines, split over two indented comment lines inside a function, and inside an error string. The helper reads whole files, so strings are held as well.
- If the directory were renamed, the check could not pass empty: the required sentence is read from the file by name.

Its limits. They are how this contract works everywhere, and audit 18 left the line to the writer's choice:
- It holds the four phrases word for word. The claim in other words passes (control DM18).
- It reads `es/admission/*.go` only, not the packages below it (control DM19), and not test files (control DM20). The probe, staging custody and their comments are all in `es/admission` itself.

### 4.3 A18-2: one case per owner half

`TestStartupProbeFileChecksRefuseAnOwnerTheFileSystemIgnores` now has two cases on a bindfs mount that ignores owner and group changes. Each asks for an owner that differs from the file's creator in one half only.
- "owning user": owner `54321` with the caller's own group. Only root may give a file away, so a non-root caller reruns the case as root through `sudo`.
- "group": the caller's own user with another group; as non-root a supplementary group, because the kernel passes only such a change on to the file system.
- **The witness.** Before the two probes run, the case creates a file on the mount, asks for the owner change, and fails unless exactly one half of the result differs from what was asked. That shows the mount ignored the change, and that the other half cannot be what the probe refuses on.
- **The rerun as root cannot pass without running.** The parent requires exit status 0 and the line `--- PASS: <name of the case>` in the child's output. If the top-level test skipped as root, that line would be missing.
- **No skip can hide it on CI.** Without sudo the whole test skips, as it did before. The gate fails the check for any skip that is not listed, and this test is not listed.
- Both probes are still held to the exact message of the owner check, which differs from the message of a failing `Fchown`.

Result: each half of each of the two file checks is now held by a case of its own (5.3).

### 4.4 The merge of `trunk_dev`

- `fcf9191` has the parents `29254b1` and `110d377`. Against its first parent it changes one file, `remote_alpha_es_service_tls_status_test.go`, and that file's blob equals `trunk_dev`'s. Against its second parent it changes the pull request's 19 paths.
- No file is changed both by the pull request and by `trunk_dev` since the old base `f62d024`.
- I redid the merge from the two parents in a scratch clone: no conflict, tree `26deaef8689d732a9ad0c81aac0fb65401322fce`. That is the tree of the writer's merge commit and of my trial merge in audit 18. So the merge commit holds nothing but the merge.
- Patch-id of the pull request's patch: `32cdf1a0…94fe` against the old base at `29254b1` and against the new base at `fcf9191`. At `d8826b8` it differs, by the fix commit.
- The merged test file changes results neither on the head nor on the base in this container (5.1).

### 4.5 The pull request description

Read at 04:17Z. Its new section "Audit 18 repair (A18-1, A18-2) and trunk_dev `110d377`" says what the commits do, and its numbers agree with mine: comment lines only, the contract reads the admission code's comments across line breaks, one case per half with a witness file, the merge brings in one file, same patch-id, the manifest, the CI run. "Not run" now says that `d8826b8` changes only comment lines. I found no statement in it that the head contradicts.

## 5. Validation I ran

All on `d8826b8`. Identities as in audits 16 and 18: `ci` (30033, passwordless sudo, bindfs), `ci3` (31500, no sudo), root.

### 5.1 Static checks and tests

| Check | Result |
| --- | --- |
| `go build ./...`, `gofmt -l`, `go vet ./es/admission .` | clean |
| `GOOS=darwin GOARCH=arm64` vet and build | clean (type-check only) |
| whole `es/admission`, `-count=1 -v`, as `ci` | `ok`, 1,122 runs (1,120 at `29254b1`; the 2 new ones are the two cases), 2 skips, both listed |
| the same as root | `ok`, 1,122 runs, 6 skips, the same six tests as at `29254b1` |
| the same as `ci3` | `ok`, 1,111 runs; 11 tests and one subtest skip, the same as at `29254b1`, all for lack of sudo or the opt-in variable |
| `go test ./...` as `ci`, head and base `110d377` | the same 10 tests fail on both, and every package has the same result on both. All 10 are among the 15 tests that CI lists as still failing on its runner |
| the four tests the last two repairs added or changed, 40 times, as `ci` and as root | `ok` both |
| both docs contract tests on the unmutated head | pass |

### 5.2 The PR's own CI

Run 45108060209, job 137473797976, read through the GitHub connector: event `pull_request`, head `d8826b8`, conclusion success, every step success, including "Vet for macOS", "Install bindfs", "Check the test gate", "Test" and "Listed tests still fail". It is the only check run of the head.

- From the job log (1,240 lines; I fetched the last 24 and they equal the writer's copy; the other lines are from that copy): CI tested the merge of `d8826b8` into `110d377`; `bindfs 1.14.7-1.1build2`; `ok execution-substrate 97.272s` (the root package with the docs contract); `ok execution-substrate/es/admission 59.298s`; "execution-substrate/es/admission: 2 tests skipped themselves", the two stress tests; "test gate passed: 41 packages, 3 of them with skipped entries (15 entries); 41 tests skipped themselves, all of them listed"; "all 15 listed tests still fail on this host".
- So both new cases ran on the runner, "owning user" through `sudo`.
- Unlike at `29254b1`, this run is against the current `trunk_dev`.

### 5.3 Mutants

The same 64 as in audit 18: the 55 of audit 16, R15, and the 8 finer ones. Each on a scratch copy inside a private mount namespace. Per mutant: the behaviour tests as `ci`; the owner mutants also as root; survivors against the whole package. Every mutant applied exactly once. The unmutated tree passes as `ci` and as root. No run showed mount-table noise.

| | At `29254b1` | At `d8826b8` |
| --- | --- | --- |
| Caught by behaviour tests, as `ci` | 51 | **52** |
| Caught only by the typed inventories (B1, B2, R11, R12) | 4 | 4 |
| Survive | 9: control O9; F6, D1, R1, R2, R5, R6, R15; **F2a** | 8: control O9; F6, D1, R1, R2, R5, R6, R15 |
| As root, the 20 owner mutants (O1 to O12, F2, F2a, F2b, R9, R9a, R9b, A2, A2L) | 17 caught; O9, F2a, F2b survive | **19 caught**; only the control O9 survives |

The two the new test is for:

| Mutant | As `ci` | As root | Fails | Passes |
| --- | --- | --- | --- | --- |
| F2a, owning-user half of the staged file's owner check removed | caught (survived before) | caught (survived before) | case "owning user": "staged file probe = <nil>, want the owner check after the ignored owner change to refuse" | case "group" |
| F2b, group half removed | caught | caught (survived before) | case "group", the same message | case "owning user" |

The retained file's halves (R9a, R9b) are caught as before by the table test, and each also by its own case of this test. O10, O11 and O12 (A16-1) are still caught, each at its own place, as `ci` and as root. No mutant that was caught at `29254b1` survives now.

The 7 survivors are those of audit 18, section 5.4, where I agreed with the writer's reasons. The product code has not changed since, so that judgement stands: observations A16-4 and A16-10, not blocking.

### 5.4 Docs mutants

20 of my own against `TestStartupProbeUseAgreementDocsContract`; the unmutated tree passes before and after.

| Mutants | Result |
| --- | --- |
| DM1 to DM8, the docs mutants of audit 18 | 8 of 8 caught, as before |
| DM10 the old comment restored; DM11 the old sentence added after the new comment; DM12 the rule sentence dropped; DM13 the rule sentence changed by one word | 4 of 4 caught |
| DM14 the claim in a comment of `staging_custody.go` on one line; DM15 split over two comment lines; DM16 split over two indented comment lines in a function; DM17 in an error string | 4 of 4 caught |
| Controls, expected to survive: DM9 and DM18 (the claim in other words), DM19 (in a package below `es/admission`), DM20 (in a test file) | 4 of 4 survive |

## 6. The base, and the other open pull requests

- `trunk_dev` is `110d377`, and the head contains it. GitHub reports mergeable state "clean". The rule that the branch must be up to date is met as long as `trunk_dev` does not move.
- At 04:32Z three other pull requests are open against `trunk_dev`: #19 and #22 (drafts, both in audit or repair according to project memory) and #12.
- If one of them merges before PR #20, PR #20 is behind again. Provenance rule 5.4, item 2, then applies: the branch update makes new bytes and needs a new manifest; after a clean merge with an unchanged patch the coordinator may accept a provenance-only re-check.
- I tried both in a scratch clone, without checking anything out: `d8826b8` merges with the head of #19 (`be71f84`) and with the head of #22 (`1032c9c`) with no conflict. PR #19 shares `PLANS.md` and the bring-up runbook with PR #20; PR #22 shares `PLANS.md` and `capability_probing.md`. I did not run tests on the combined trees.
- The order is the coordinator's to choose. Merging PR #20 first avoids the re-check for it.

## 7. Findings

### 7.1 On the patch

None.

Closed by this delta:
- **A18-1** (the comment said staging would refuse every submission): closed (4.1), and held by the docs contract (4.2).
- **A18-2** (the owning-user half of the staged file's owner check was held by no test): closed (4.3, 5.3).

Observations. None needs a change before merge.

- **A21-1. What the new contract lines do not reach.** They hold four phrases word for word, in `es/admission/*.go` without the test files. A paraphrase, a package below `es/admission` or a test file is not read (controls DM18, DM19, DM20). I would not widen it: a contract that tried to catch paraphrases would be guessing.
- **A18-3, unchanged.** "ES starts only where every submission it accepts can be staged" in `PLANS.md` reads wider than what the probe proves. In its paragraph, which is about modes, I read it as the reason for the rule. The new comment uses the narrower wording.
- **Carried over from audit 16, unchanged and outside this delta:** A16-4 (no Linux test reaches the existing-name rename), A16-6 (bindfs is pinned by version only), A16-9 (retention's modes have no list and guard), A16-10 (the 7 survivors).
- **A16-11, now on two more commits.** The trailers of `fcf9191` and `d8826b8` name Claude [model withheld], as those of earlier commits do. The writer says this is its session's required attribution. It matters only for the merge: if the merged history is to carry no model name, the squash message has to be written without the trailers. Inference: GitHub's default squash message can carry the commits' messages and co-author lines, depending on the repository's setting.

### 7.2 Older issues

None new. Red-team O-1 and O-3 stand as audit 16 recorded them.

## 8. Validation assessment

Re-run by me: provenance (opening and closing); the merge from its parents; the comment-only proof; build, vet, format and the Darwin cross-checks; whole `es/admission` as three identities; the whole module on head and base; the changed tests 40 times as two identities; 64 code mutants and 20 docs mutants.

Read, not re-run: the PR's CI (run, job and check run through the connector; the log's tail fetched; the rest from the writer's copy), the pull request description, the list of open pull requests.

Not run:
- **The file-system matrices of audit 16.** Not needed: the product code is the code they ran on, apart from comment lines (4.1).
- **macOS.** Only type-checked, here and in CI. This has been so since the first audit of this pull request. The startup probe now stages files of five modes, checks devices and owners, and renames with the no-replace rename, which on macOS goes through `renameatx_np` and has never executed. Inference: APFS answers all of it as the probe expects. Three new test files of this pull request, and its changes to three existing ones, have no build constraint and would run on the Mac; they have not. One run of `go test ./es/admission` on the Mac at `d8826b8` would settle it, and I recommend it before the merge. It needs David's Mac. If the inference were wrong, ES would refuse to start there with a named reason; it fails closed.
- **Real NFS, CephFS, 9p and CIFS.** bindfs fixtures stand in, as before.
- **The combined trees with #19 or #22** (section 6).

## 9. Sensitive-material handling

No secrets, keys, tokens or env files were read or written. I scanned the evidence folder for addresses, tokens and key material: no match. The CI log is cited from the writer's evidence and not copied.

## 10. Remaining uncertainty and stop conditions

- macOS behaviour, as above. Inference only.
- Stop condition for the merge gate: the PR head must equal the accepted commit, `d8826b8`, and `trunk_dev` must still be `110d377`. If either has moved, section 6 applies.
- This audit did not re-examine the product code, because it has not changed. Its correctness rests on audit 16 (`b5cc7cb`), the red-team before it, and audit 18.

## 11. Confidence

| Kind | Level | Why |
| --- | --- | --- |
| Provenance | high | recipe verified; two runs identical; equal to the writer's manifest; closing equals opening; remote refs unchanged between start and end |
| Validation | high on Linux, none on macOS | three identities, 64 code mutants and 20 docs mutants, 40 repeats, head against base, the PR's CI read from the source |
| Implementation | high | the product change is comment lines, shown three ways; the new test and contract lines each fail under the mutant they are for; every claim of the writer about this delta reproduced |

## 12. Effect status

Repair: not performed. Commit: none. Push: none. PR: not edited, not commented, not reviewed. Merge: none. GitHub calls: `git clone`, `git fetch`, `git ls-remote`; reads of PR #20 and its check runs, run 45108060209, its job and the tail of its log, the list of open pull requests, and the file list of PR #22. The merges I tried were aborted or written as loose objects in a scratch clone. Scratch trees, mounts and users live in this container.

## 13. Report delivery

`/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/21-audit-pr20-a18.md`. Its SHA-256 is in the thread reply and in project memory. Evidence: `21-audit-pr20-a18-evidence/` with `SHA256SUMS.txt`.

## 14. Final verdict

**ACCEPT** for `d8826b884571e2ece19bc69f7daecb1c4918802a` (base `110d377`, tree `b3b240d0…`, manifest `abd78ebc…8e00`).

Next: David's review of PR #20, the first product merge into `trunk_dev`. Before the merge: the head and the base as in section 10, and, as I recommend, one run of `go test ./es/admission` on the Mac.

STATUS: READY
