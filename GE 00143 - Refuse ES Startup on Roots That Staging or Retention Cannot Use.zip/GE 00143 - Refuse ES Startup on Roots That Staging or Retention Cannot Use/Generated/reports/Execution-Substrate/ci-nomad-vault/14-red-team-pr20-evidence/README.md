# Evidence for 14-red-team-pr20.md

Red-team of `evo-agi/Execution-Substrate` draft PR #20 at `eb6eea90b0e694ffa2e7ab62f64f6d7d6f0936c3` (base `f9537a8680c24bf2108b95ed20ac3724e8939d3a`). Everything here was produced in the thread's cloud container on 2026-11-22 and 2026-11-23 (UTC). `SHA256SUMS.txt` lists every file except itself.

Nothing here is a secret. The folder was scanned for tokens, private keys, e-mail addresses, phone numbers and personal names: no hit.

## Where things ran

`environment.txt`: kernel, Go and tool versions, the four identities, the two trees, the hashes of the two `es` binaries, every scratch mount with its options, the bindfs command lines, and the pull request's refs at the end.

## Harness (never part of the tree under test)

Source files carry `.txt` so nothing builds them by accident. They were copied into `es/admission/` of a scratch copy of each tree.

| File | What it is |
| --- | --- |
| `harness-zz_rt_matrix_test.go.txt` | `TestRTMatrix`: for each case, runs the startup probe, then the real `Service.Submit`, the real staging functions directly, and the real retention; prints one `CASE` line with a verdict label |
| `harness-zz_rt_race_test.go.txt` | `TestRTDirSwapRace` and its attacker: a second user swaps a directory or a symbolic link in during the probe |
| `harness-zz_rt_misc_test.go.txt` | repeated and concurrent starts, leftovers, changes after startup, the real binary, submissions in a loop, path spellings |
| `harness-mkcases.sh.txt` | builds the 32 layouts |
| `harness-build_all.sh.txt`, `harness-run_matrix.sh.txt`, `harness-as.sh.txt` | build the layouts for four identities per file system; run a test as one identity |
| `harness-pivot.py.txt` | compares two matrix logs cell by cell |
| `harness-fresh.sh.txt`, `harness-churn.sh.txt` | rebuild one identity's cases; mount and unmount in a loop |

Verdict labels are explained in section 3 of the report.

## Matrix logs

Each `### tree=… fs=… ident=…` line starts one run; each `CASE` line is one cell.

| File | Content |
| --- | --- |
| `log-matrix-base.log`, `log-matrix-head.log` | 9 kernel and overlay file systems, 1152 cells each |
| `log-idmap-base.log`, `log-idmap-head.log` | idmapped mount, 128 cells each |
| `log-fuse-base.log`, `log-fuse-head.log` | 7 bindfs variants, 768 cells each |
| `log-pivot-kernel-fs-base-head.txt`, `log-pivot-idmap-base-head.txt`, `log-pivot-fuse-base-head.txt` | base to head, counted per file system. The header line of each pivot says "base>head"; that is the script's fixed wording for "first log > second log" |
| `log-umask-head.log` | head, 9 umasks on two file systems, 2304 cells |
| `log-userns.log` | base and head inside `unshare --map-root-user`, 32 cells each |
| `log-special.log` | bind-mounted roots, staging on its own tmpfs, `nosuid,nodev,noexec`, a space in the path, symlinked root, symlinked parent, read-only staging; base and head |
| `log-pathforms.log` | ten spellings of the root paths; base and head |
| `log-inodes.log` | head, tmpfs with 4 to 60 inodes |
| `log-overlay-devices.txt` | `st_dev` of a directory and of a file on the three overlay mounts |

## Real binary

`log-binary.log`: the `es` binary from each build, 7 layouts, 3 identities, 6 file systems. `STARTS` means it got past the capability check and stopped at the stub trust model (`start app: fetch trust model: unexpected status 404`). `REFUSES` means it exited at `build app: validate execution root capabilities: …`.

## Attacks on the probe

| File | Content |
| --- | --- |
| `log-race-base-probe.log`, `log-race-head-probe.log`, `log-race-head-nested.log` | directory swap, 1000 rounds each |
| `log-race-head-nested-symlink.log` | the same with a symbolic link, 1000 rounds |
| `log-misc.log` | concurrent starts, leftovers per start, one refused probe directory. The line `nested-directories=1380` counts each `nested` twice, because the pattern also matches through the probe's symbolic link |
| `log-poststart.log` | four runs with a change between startup and use |
| `log-churn.log` | 400 starts beside a mount loop, base and head |
| `log-churn-use.log` | 300 submissions beside a mount loop, head |
| `log-strace-rename-noreplace.txt` | the three `renameat2` calls of the RT-2 test: the fixture's witness, the probe's collision check, retention's publish |

## Proposed regression tests

| File | Content |
| --- | --- |
| `proposed-execution_roots_probe_use_agreement_linux_test.go.txt` | four tests for RT-1, RT-2 and RT-3. Byte-identical to `es/admission/execution_roots_probe_use_agreement_linux_test.go` in commit `93a0833cf1d58576889910a90abfd4182e158139` (blob `b62e629912bfa17edae9212a8c5cf58e86ba9e2e`) |
| `proposed-execution_roots_probe_swap_stress_linux_test.go.txt` | the opt-in stress test for RT-3. Byte-identical to the file of that name without the prefix in the same commit (blob `526c309864e93526e74a3f45bc960aaa4fc3e75e`) |
| `log-proposed-tests.log` | the four tests on head, base and prototype, as `ci` and as root |
| `log-proposed-tests-prototype.log` | the pull request's own three tests and the proposed ones on the prototype, as `ci` and as root |
| `log-proposed-stress.log` | the stress test on head and prototype, 1000 rounds per target |
| `log-package-run-with-proposed-tests.txt` | `go test ./es/admission/ ./` on commit `93a0833`, as root: package results and failing top-level tests, and the same list for the root package on a clean `eb6eea9` |

## Prototype repair

`prototype-repair-not-for-merge.patch.txt`: 83 lines added to `es/admission/execution_roots.go` in a scratch copy of the head. It exists to show that the proposed tests can pass and what such a repair costs. It is not a proposed patch, was never committed and never left the container.

`log-matrix-proto.log`, `log-idmap-proto.log`, `log-fuse-proto.log`: the whole matrix on the prototype. `log-pivot-kernel-fs-head-prototype.txt`, `log-pivot-idmap-head-prototype.txt`, `log-pivot-fuse-head-prototype.txt`: the comparison with the head (the header again says "base>head" for "first log > second log").

## Kernel source

`kernel-source-lines.txt`: the lines of Linux v6.12 that the report cites for rename flags and for overlay device numbers, with the SHA-256 of each fetched file. The runs used kernel 6.18.44; the lines are cited only for file systems that could not be run here.

## Re-running

On a Linux machine with root, Go 1.26.5, `bindfs`, `setfacl`, `setpriv`, `capsh` and loop devices: check out the tree, copy the three `harness-zz_rt_*_test.go.txt` files into `es/admission/` without the prefix and the `.txt`, build the test binary with `go test -c`, create the identities and groups named in `environment.txt`, build the cases with `harness-build_all.sh.txt`, and run `harness-run_matrix.sh.txt`. The scripts expect `/opt/rt/<tree>` and `/opt/rt/fs/<mount>`.

The proposed tests need none of that: `go test ./es/admission/ -run 'TestExecutionRootProbe(AgreesWith|HandsNoDirectory)' -v` as a user with passwordless sudo.
