# ES PR #20 red-team: startup refuses when staging cannot own a nested directory

Break-it pass, requested by the coordinator on 2026-11-22. Written by the thread "Red-team the staging ownership check", from 23:25Z on 2026-11-22 to about 00:30Z on 2026-11-23.
Evidence: `14-red-team-pr20-evidence/` beside this file. Its `README.md` explains every file and `SHA256SUMS.txt` lists them.

**Final verdict for `eb6eea9`: HOLDS WITH CAVEATS.**

The claim of the pull request holds. I could not make the new check miss the condition it was written for, and I could not make it refuse a setup that works. The caveats are three older weaknesses of the same startup probe that the pull request does not repair. Two of them still give "ES starts, and then nothing works". The third is a race in which a root ES gives away a directory. None of the three was introduced by this pull request. The third gains one more instance through it.

What holds:
- **The targeted gap is closed everywhere I looked.** Across 2,048 cells (17 file systems and mount variants, 4 identities, 32 layouts) the base has 443 cells where startup passes and the first submission fails. The head closes 282 of them. Every closed cell is a layout with setgid roots. The 161 that stay open have another cause (RT-1).
- **No working setup is refused.** 0 false refusals in 4,403 cells on the head and 2,087 on the base. Every cell that works on the base works on the head: 638 on kernel file systems and the idmapped mount, unchanged.
- **The real `es` binary agrees.** Built from the head it exits with `build app: validate execution root capabilities: nested staging directory ownership is unavailable` in 48 of 119 starts across 6 file systems. Built from the base it gets past the check in all 119.
- **Umask, ACLs, default ACLs, sticky bits, missing roots, bind mounts, a staging root on its own tmpfs, `nosuid,nodev,noexec`, an idmapped mount and a user namespace** change nothing about that. The documented `UMask=0027` works.
- **Symlinks do not get through.** A symbolic link swapped in for `nested` by another user changed nothing in 1000 rounds; in the one round where the link was in place in time, the probe refused it. Symlinked roots and symlinked parents are refused before the probe.
- **Concurrent starts do not disturb each other** (640 probes in one process, 8 processes with 50 each).

What I broke (section 6):
- **RT-1, medium, older.** The staging probe never creates a regular file and tries one mode, a directory at `0750`. On an overlay whose layers are on different file systems (and no `xino`), ES starts and every submission fails with `stage artifact payload failed`: 76 of 76 otherwise working cells, real binary included. This is the symptom this pull request set out to remove, with another cause.
- **RT-2, medium, older.** The results probe tests the no-replace rename only against a name that exists and accepts any error. On a file system whose rename takes no flags, ES starts, submissions are accepted, and no result can ever be retained: 206 cells on four FUSE variants. Linux's own source says NFS, CephFS, 9p and eCryptfs are such file systems. That last step is an inference; I had none of them here.
- **RT-3, low, older pattern with one new instance.** A root ES on roots that belong to another user is refused, but before it refuses it gives directories it opened by name to that user. That user can swap in somebody else's directory: 13 to 18 hits per 1000 starts through the old window, 2 to 6 per 1000 through the new one. This confirms by run what the audit recorded as inference (A13-P1).

Each finding comes with a proposed regression test (section 7). All of them fail on the base and on the head, and all pass on a throwaway repair that costs no working cell in the whole matrix.

What the merge gate needs to know:
- Nothing I found is a reason to hold this pull request back on correctness. It is a strict improvement: 282 cells closed, none lost. Whether RT-3's new instance should be repaired inside this pull request or in the next change is a tradeoff, and it is the coordinator's and David's to make. Section 10 gives both sides.
- This report binds `eb6eea9` only. `trunk_dev` is at `f62d024`, so the branch update that the audit already named still applies.
- Not run: macOS, the Remote Alpha host, real NFS, CephFS, CIFS, 9p or vfat, and the full Nomad, Docker and Vault stack. Section 8 says what stood in for each.

## 1. Target

| Field | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate`, draft PR #20 into `trunk_dev` |
| Head | `eb6eea90b0e694ffa2e7ab62f64f6d7d6f0936c3`, equal to `refs/pull/20/head` at the start and at the end (`git ls-remote`) |
| Head tree | `778e00829e23cb382fa364295b1f6af075b50d7c` |
| Base | `f9537a8680c24bf2108b95ed20ac3724e8939d3a`, tree `88e6d89349b681dc5d469644fe1002850ec3ab75` |
| `trunk_dev` now | `f62d0245e95e2b411be16511fc1bf9e1da727ce5` |
| Change | 8 paths, 377 insertions, 9 deletions. The only product change is `es/admission/execution_roots.go` (+56): `probeNestedStagingDirectory`, lines 568 to 605, called from `probeCapabilities` |
| Audit | `13-audit-pr20.md`, SHA-256 `301a7b1df205654862647cd602cff1bb0bc990765f96a0045f9ad4ee6235d8e5`, checked before use. Verdict ACCEPT |
| Writer report | `12-setgid-probe.md` |
| Real binaries | `es` from the head, SHA-256 `9f5ca7e8d0fff857fa5fb3e7dc9816065c3b302c320b090fc113ef9eb5bf0240`; from the base, `61f6acbbe96d554553156894fd2129cdd0ec834f0011a1cad767bb45ed4ef073` |

## 2. Posture and local stack

Read-only on the pull request: no push to its branch, no comment, no review, no edit, no merge. No subagents. I pushed one commit with the proposed tests to my own branch, `claude/project-thread-suv0zx` (`93a0833`), with no pull request. Nothing ran on the Linux box or against any live service.

Everything ran in this thread's cloud container: Linux 6.18.44, x86_64, Go 1.26.5, root available. `environment.txt` has the details.

The local stack has three layers. I name them because "a local stack" can be read as more than this:
1. **The startup probe itself**, called as startup calls it: `provisionExecutionRoots`, `owner`, `probeCapabilities`.
2. **Real use.** The real `Service.Submit` with the package's own hermetic artifact and Nomad fixtures. The real staging functions called directly, to get the raw error that Submit hides behind a fixed message. The real `retainTerminalResult` and `readRetainedResultBundle`, with a stand-in for the workload that writes two result files.
3. **The real `es` binary**, started with a config that names the roots and a stub for the trust model. A start counts as "passes the check" when it gets to `start app: fetch trust model: unexpected status 404`, which comes after the capability check.

I did not run Nomad, Docker or Vault, and no workload ran. "ES reports ready" rests on reading `es/api/server.go:80`: readiness is `started && TrustModelLoaded && ArtifactRegistryHealthy`, and nothing re-checks the roots after startup.

## 3. Method

One harness test runs a case and names the outcome:

| Label | Startup probe | Submit | Retention | Meaning |
| --- | --- | --- | --- | --- |
| AGREE-OK | passes | works | works | fine |
| AGREE-REFUSE | refuses | fails | | fine |
| REFUSE-RESULT | refuses | works | fails | fine, the results side justifies the refusal |
| GAP-SUBMIT | passes | fails | | ready, and submissions fail |
| GAP-RESULT | passes | works | fails | ready, and results are lost |
| FALSE-REFUSAL | refuses | works | works | a valid setup is refused |
| NO-PROVISION | | | | the roots are refused before the probe |

The matrix has three axes.

**32 layouts** (`harness-mkcases.sh.txt`): 8 ownership cases (plain, another group set directly, setgid with a foreign group, with ES's own group, with a supplementary group, mixed, group-writable), 8 mode and sticky-bit cases (`0700`, `0777`, `1755`, `1777`, `3775`, `3777` with a foreign group, `0500`, `0300`), 13 ACL cases (default ACLs of several shapes, a named user, an empty mask, roots owned by another user and reached through an ACL, combinations with setgid), and 3 cases where the roots do not exist yet under setgid, default-ACL and plain parents.

**4 identities:** `ci` (30033, with one supplementary group), `ci4` (32500, primary group only), root, and root without `CAP_CHOWN`, `CAP_DAC_OVERRIDE`, `CAP_DAC_READ_SEARCH`, `CAP_FOWNER` and `CAP_FSETID`.

**17 file systems and mount variants:**
- kernel: the container's ext4, tmpfs, ext4 on a loop device, ext4 with `grpid` (new entries always take the parent's group, as on macOS and the BSDs), xfs, btrfs;
- overlay: both layers on one file system; layers on two file systems with `xino` off; the same with `xino=on`;
- an idmapped mount (`X-mount.idmap`);
- seven bindfs (FUSE) mounts that bend one rule each: plain, owner changes ignored, owner changes denied, mode changes ignored, modes fixed, entries created for another user, and a mix that looks like a share without POSIX modes.

Beside the matrix: 9 umasks on two file systems, a user namespace, 7 special path and mount cases, 10 spellings of the root paths, repeated and concurrent starts, inode exhaustion, changes after startup, mount churn, and two races by a second user.

## 4. The claim of the pull request

### 4.1 Ready, and then submissions fail

Base to head, per group of file systems (`log-pivot-*-base-head.txt`):

| | Cells | GAP-SUBMIT base | closed on head | GAP-SUBMIT left | AGREE-OK base | AGREE-OK head | FALSE-REFUSAL |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Kernel file systems and overlay (9) | 1152 | 216 | 140 | 76 | 562 | 562 | 0 |
| Idmapped mount | 128 | 20 | 20 | 0 | 76 | 76 | 0 |
| bindfs variants (7) | 768 | 207 | 122 | 85 | 0 | 0 | 0 |
| Sum | 2048 | 443 | 282 | 161 | 638 | 638 | 0 |

Two bindfs variants have 64 cells instead of 128, because not every identity can enter them. That is why 17 mounts give 2,048 cells and not 2,176.

The 161 cells that are left are RT-1: 76 on the split overlay, 46 and 39 on two bindfs variants. None of them is a setgid or group case; the raw cause in all 161 is `staging file has an invalid identity`. The 206 GAP-RESULT cells on bindfs are the same on base and head and are RT-2.

Every one of the 282 closed cells becomes AGREE-REFUSE, and every one is a layout with setgid roots. On the kernel file systems and the idmapped mount (160 cells) they are `c03`, `c05` for an identity outside the group, `c08`, `m06`, `a09`, `a10` and `p01`: roots that pass a group down through the setgid bit to a process that is not a member. On the bindfs variants (122 cells) the same layouts close, and 18 cells more (`c04`, `m05`, `c07`) on mounts that ignore mode or owner changes: there the setgid bit or the group cannot be put right for another reason, staging fails on it, and the new check sees that too. On the `grpid` mount the base has no gap and the head refuses nothing more (106 AGREE-OK on both), which is the case the pull request's own test comment describes.

btrfs roots are refused before the probe on base and head (`descriptor and mountinfo devices disagree`, 128 cells). That is older behaviour and outside this change; I note it because a btrfs host cannot run ES at all today.

### 4.2 Wrong refusals

None. No cell is FALSE-REFUSAL on the base or on the head in any log: 2,087 cells on the base, 4,403 on the head. No cell that is AGREE-OK on the base has another label on the head.

Setgid roots as such are not refused. With ES's own group (`c04`) or a supplementary group (`c05` as `ci`, `c07`) they pass and work.

### 4.3 The real binary

119 starts per build (`log-binary.log`): 7 layouts, 3 identities, on the container's ext4, `grpid`, both overlays, plain bindfs and the share-like bindfs.

| File system | Base: passes the check | Head: passes | Head: refuses |
| --- | --- | --- | --- |
| container ext4 | 21 | 12 | 9 |
| ext4 `grpid` | 21 | 21 | 0 |
| overlay, one file system | 21 | 12 | 9 |
| overlay, two file systems, no xino | 21 | 12 | 9 |
| bindfs plain | 21 | 12 | 9 |
| bindfs share-like | 14 | 2 | 12 |

All 48 refusals carry `nested staging directory ownership is unavailable`, 36 with `: operation not permitted` and 12 without an error number. The 12 are on the share-like bindfs, where mode changes are ignored and the check fails on the mode, not on the owner. The audit already notes this wording (A13-5).

The 12 starts that pass on the split overlay and the 12 on plain bindfs are starts of an ES that cannot work there (RT-1, RT-2).

### 4.4 Umask, user namespace, special paths

- **Umask** (`log-umask-head.log`, head, 2,304 cells). `0000`, `0002`, `0007`, `0022` and `0027` give the same picture: 152 AGREE-OK, 72 AGREE-REFUSE, 26 REFUSE-RESULT, 6 NO-PROVISION each. Under `0037` and `0077`, 100 cells per umask move to REFUSE-RESULT with `natural retained result directory creation is unavailable`, and retention does fail there. `.docs/execution_lifecycle/implementation.md:985` says a restrictive umask fails closed, and the accepted posture is `UMask=0027`. Under `0177` and `0277` the package's Submit fixture cannot run (372 cells marked HARNESS-ABORT); there I compared the probe with direct staging only. The probe passes and staging fails in 0 cells. In 144 cells the probe refuses, again with `natural retained result directory creation is unavailable`, while direct staging works; retention could not be run for them, so that those refusals are justified is an inference from the 96 cells of the same umasks where it could be run and failed.
- **User namespace** (`log-userns.log`, `unshare --map-root-user`, 32 cells per build): identical on base and head. Roots with an unmapped group are refused on both, with a bare `invalid argument`.
- **Special cases** (`log-special.log`, identical on base and head): roots that are bind mounts, a staging root on its own tmpfs, `nosuid,nodev,noexec`, and a path with a space all work. A staging root that is a symbolic link, or whose parent is one, is refused before the probe (`too many levels of symbolic links`). A read-only staging root is refused by the probe and by Submit.
- **Path spellings** (`log-pathforms.log`, identical on base and head): trailing slash, double slash, `.` and `..` components are accepted and work. A relative path, an empty path, the same directory twice, and one root inside the other are refused.

## 5. Attacks on the probe itself

### 5.1 Directory swap by a second user

Setup: ES is root. Both roots belong to an unprivileged user, the attacker. A third user, the victim, owns a world-writable sticky directory inside a directory of the attacker's. The attacker watches the staging root with inotify and renames the victim's directory into place between the probe's `Mkdirat` and its open.

| Target of the swap | Build | Rounds | Victim's directory given to the attacker |
| --- | --- | --- | --- |
| probe directory (`execution_roots.go:465-476`) | base | 1000 | 13 |
| probe directory | head | 1000 | 18, and 17 in a second run |
| `nested` (`execution_roots.go:572-583`, new) | head | 1000 | 6, and 2 in a second run |
| `nested`, symbolic link instead of a directory | head | 1000 | 0 (the probe met the link once and refused it: `too many levels of symbolic links`) |

In a hit the victim's directory goes from `34500:34600` mode `1777` to `33500:33600` mode `0750`. ES ends every round with its normal refusal for this setup (`natural retained result directory creation is unavailable`), so nothing in its output shows the interference. This is RT-3.

I expected the fixed name `nested` to make the new window easier to hit than the old one. The runs say the opposite.

### 5.2 Concurrent starts, leftovers, full file systems

- **Concurrent starts** (`log-misc.log`): 32 probes at once for 20 rounds in one process, and 8 processes with 50 probes each, on base and head. All 640 and all 400 pass. Each start uses its own random token, and `nested` lives inside that start's own directory.
- **Leftovers.** A passing start leaves 2 entries in the staging root and 3 in the results root, and on the head one more directory, `nested`, inside the staging probe directory: 6 inodes per start on the head, 5 on the base. Nothing removes them; that is documented. A refused start on the head leaves the probe directory (`uid:roots' group`) with `nested` inside (`uid:own group`, `0750`) and nothing in the results root. The harness line `nested-directories=1380` counts every `nested` twice because its pattern also matches through the probe's symbolic link; the real count is one per start.
- **Full file system** (`log-inodes.log`, head, tmpfs with 4 to 60 inodes): with up to 5 free inodes the probe refuses with a bare `no space left on device`. With 6 to 25 free inodes the probe passes and a submission, or the retention of its result, then fails for lack of space. A startup check cannot reserve space, so I do not count this as a gap.
- **Error paths.** Every failing step of the new function returns after closing its descriptor (`defer` at line 579; the caller closes the probe directory's descriptor on every path). A refused start exits the process.

### 5.3 Changes after startup

Readiness is never re-evaluated (section 2). `log-poststart.log` has four runs on the head: after a passing start, giving both roots a foreign group with the setgid bit makes every submission fail (`stage artifact payload failed`); a default ACL on the results root makes retention fail (`retained result directory has an invalid identity`); the control without a change works. ES stays "ready" throughout. Submit derives the owner from the roots at each submission and fails closed, so nothing unsafe happens. It is the same "ready, but failing" symptom by another route, and no startup probe can prevent it. Observation O-2.

### 5.4 Mount churn

Each `reobserve` reads `/proc/self/mountinfo` twice and fails when the two reads differ (`execution_roots_linux.go:72`, no retry). The base probe calls it 12 times, the head 15 times. With a loop beside ES that mounts and unmounts a tmpfs, as a container host does when tasks start and stop (`log-churn.log`, 400 starts each):

| One mount and unmount about every | Base: refused starts | Head: refused starts |
| --- | --- | --- |
| no churn | 0 | 0 |
| 50 ms | 6 | 12 |
| 5 ms | 52 | 70 |
| as fast as possible | 133 | 177 |

Submissions are hit too, though less (`log-churn-use.log`, head, 300 each): 0 failures at 50 ms, 6 at 5 ms, 29 at full speed, as `500 claim execution staging root failed`. The message for a refused start is `execution roots could not be proven physically separate: mountinfo changed during acquisition`. Observation O-1.

## 6. Findings

Severity is for the product. "Older" means the base has it too and the pull request's diff does not touch the cause.

```text
RED-TEAM FINDING
ID / Type / Severity: RT-1 / startup check does not cover what staging does / medium
Claim under attack: after this change, ES no longer reports ready while every
  submission fails to stage.
Path and line: es/admission/execution_roots.go:465-507 and 568-605 (the staging probe
  creates two directories at 0750 and one symbolic link, and no regular file);
  es/admission/staging_custody.go:686-694 (every staged file must be a regular file
  with one link, on the staging root's device, with the roots' owner and the exact
  mode); executionpackage.go:140 (payload at 0600); mounts.go:21-23 (0755
  directories, 0644 and 0755 files); ownership.go:10-12.
Evidence, shape a: an overlay whose lower and upper layers are on different file
  systems, without xino. Directories report the overlay's device, regular files
  another one (46 and 47 here, log-overlay-devices.txt; the rule is in
  kernel-source-lines.txt, fs/overlayfs/inode.c).
  76 of 76 cells that work on every other kernel file system are GAP-SUBMIT on base
  and head: probe passes, Submit answers 500 "stage artifact payload failed", raw
  cause "staging file has an invalid identity". The real binary from the head passes
  the check in 12 of 21 starts there. With xino=on the same overlay works (76
  AGREE-OK).
Evidence, shape b: file systems that do not store the mode they are asked for. On a
  bindfs mount that shows every file as 0640 and every directory as 0750: 46 cells
  GAP-SUBMIT on the head (39 more on a second variant, as root and as root without
  capabilities). On a mount that
  ignores mode changes, under a default ACL: the 0755 mount directories cannot be
  made (12 cells, direct staging; the Submit fixture has no mounts).
Impact: ES starts and reports ready; every submission fails with a 500. This is
  the symptom of A6-3 with another cause. It fails closed; no security effect.
Where it bites: shape a needs ES's roots on an overlay with layers on two file
  systems and a kernel without xino (upstream default is off; this container's
  kernel has xino_auto=N). Inference: a container or microVM root file system built
  from a read-only image device and a separate writable device is such a place. An
  overlay with both layers on one file system, as Docker's overlay2 makes, is not
  affected (76 AGREE-OK). Shape b is shown only on bindfs emulations. Guess: a CIFS
  mount with dir_mode=0750 behaves like it; not run.
Patch defect or older issue: older. Base and head are identical here.
Proposed regression tests: TestExecutionRootProbeAgreesWithStagingOnOverlayWithSeparateLayerFileSystems
  (needs sudo only) and TestExecutionRootProbeAgreesWithStagingWhenTheFileSystemFixesModes
  (needs sudo and bindfs).
Repair direction: let the probe stage, inside its nested directory, one regular file
  per file mode staging uses and one 0755 directory, with the same checks staging
  applies. The prototype does this and turns all 161 cells into refusals at no cost.
Confidence: high for both shapes as run. The "where it bites" lines are inference.
```

```text
RED-TEAM FINDING
ID / Type / Severity: RT-2 / startup check accepts a missing primitive / medium
Claim under attack: startup proves the primitives that staging and retention need.
Path and line: es/admission/execution_roots.go:553 (the no-replace rename is tried
  only onto a name that exists, and any error counts as success);
  es/admission/results.go:677 and result_auth.go:353 (retention publishes the bundle
  and its record with a no-replace rename onto a free name);
  staging_custody_linux.go:19-21 (renameat2 with RENAME_NOREPLACE).
Evidence: Linux answers EEXIST for a no-replace rename onto an existing name before
  it asks the file system (fs/namei.c:5125-5126 in v6.12). So the probe cannot tell
  a file system that supports the flag from one that does not. Trace on bindfs
  1.14.7 (log-strace-rename-noreplace.txt): the probe's call returns EEXIST, and
  retention's call onto a free name returns EINVAL. Result: 206 cells GAP-RESULT on
  base and head (plain bindfs 76, owner changes ignored 66, mode changes ignored 60,
  created for another user 4): startup passes, Submit works, and
  retainTerminalResult fails with "invalid argument". The real binary from the head
  passes the check in 12 of 21 starts on plain bindfs.
Impact: ES starts and accepts work, runs execute, and no result is ever retained.
  What the caller then sees for such a run I did not trace; Unknown.
Where it bites: any file system whose rename accepts no flags. Shown here on FUSE
  with a server that lacks the call (fs/fuse/dir.c:1092-1102). Inference from the
  v6.12 source, not run: NFS (fs/nfs/dir.c:2728), CephFS (fs/ceph/dir.c:1461), 9p
  (fs/9p/vfs_inode.c:880) and eCryptfs (fs/ecryptfs/inode.c:598) return EINVAL for
  any flag. Whether such a mount passes the rest of the probe is Unknown; a results
  root on an NFS export would confirm or refute it. CIFS and vfat accept the flag.
Patch defect or older issue: older, and on the results side, which this pull request
  does not touch.
Proposed regression test: TestExecutionRootProbeAgreesWithRetentionWhenRenameRejectsNoReplace
  (needs sudo and bindfs; it checks first that the fixture's rename rejects the flag
  and skips if a newer bindfs supports it).
Repair direction: after the collision check, rename the probe file onto a free name
  with the same call and require success. The prototype does this: all 206 cells
  become refusals.
Confidence: high for FUSE as run. Medium for the named network file systems.
```

```text
RED-TEAM FINDING
ID / Type / Severity: RT-3 / privileged owner change on a directory opened by name / low
Claim under attack: the probe has no TOCTOU weakness (audit 5.4, A13-P1 as inference).
Path and line: es/admission/execution_roots.go:465-476 (probe directory, older) and
  572-583 (nested, new in this pull request): Mkdirat, then an open by name, then
  Fchown to the roots' owner. Nothing ties the opened directory to the created one.
Evidence: section 5.1. Root ES, roots owned by an unprivileged user, a victim's
  directory the attacker may rename. Hits per 1000 starts: 13 (base, probe
  directory), 18 and 17 (head, probe directory), 6 and 2 (head, nested). 0 with a
  symbolic link. The deterministic form: after one refused start as root on roots
  owned by 54321, the probe directory and nested are owned by 54321
  (log-proposed-tests.log).
Preconditions: ES runs as root (Inference, not run: a process with CAP_CHOWN is in
  the same position); its roots belong
  to another, unprivileged user; that user can rename the target directory, which
  means write access to the target and to the directory it is in. ES does not start
  in this setup on an ordinary file system. Each start attempt is one try, so a
  service manager that restarts ES gives the attacker as many as it wants.
Impact: the attacker becomes owner of a directory it could already write to, and
  the directory's mode becomes 0750. For a shared sticky directory that means the
  attacker may now remove other users' entries and shut them out. Not shown and not
  expected: gaining a directory the attacker cannot write to.
Not affected: an ES that does not run as root. It can only change the group of its
  own directories. The documented posture is User=es.
Patch defect or older issue: older pattern; PLANS.md R14-ROOT-CUSTODY-01 names the
  non-atomic mkdir and open as a known limit for the setup helper only. The pull
  request adds a second instance, with a lower measured hit rate than the first. It
  does not change who can attack or what they gain.
Related, not attacked: ES accepts roots that other users may write to (0777 and
  1777 are AGREE-OK for all four identities). With such roots any local user is in
  the attacker's position for the rename, and a root ES would take the swapped-in
  directory for itself. Observation O-3.
Proposed regression tests: TestExecutionRootProbeHandsNoDirectoryToAnotherUser
  (deterministic, needs sudo) and TestExecutionRootProbeDirectorySwapStress (the race
  itself, opt-in, root only).
Repair direction: before any Fchown on a directory opened by name, read its owner
  and refuse when the owning user is not already the roots' owner. ES then never
  changes an owning user. No working cell needs such a change, because retained
  result directories are created without an owner change (execution_roots.go:633).
  The prototype does this: 0 hits in 2000 rounds, and all 88 REFUSE-RESULT cells of
  the kernel matrix stay refusals. The audit names the same pattern in
  staging_custody.go:551-578 (ensureDirectory); I did not attack it.
Confidence: high that the race exists and for the rates on this machine. Rates on
  other hardware will differ.
```

Observations, none of them a defect of this pull request:

- **O-1, mount churn refuses starts and fails submissions (older, slightly worse on the head).** Section 5.4. A start fails when any mount changes anywhere in ES's mount namespace during one of its 15 double reads. The pull request adds 3 of the 15. At one mount cycle every 50 ms that is 6 of 400 starts on the base and 12 of 400 on the head. ES runs beside Nomad and Docker, which mount and unmount on every task start and stop. A bounded retry of the double read would address it. The same mechanism fails live submissions under heavier churn.
- **O-2, readiness does not track the roots (older, by design).** Section 5.3.
- **O-3, roots writable by other users are accepted (older).** `m02` (`0777`) and `m04` (`1777`) are AGREE-OK for all identities. I did not attack run staging through such roots; that is the custody design, not this change.
- **O-4, the refusal names ownership when the mode is at fault.** On file systems that ignore mode changes the nested check fails on the mode and says `nested staging directory ownership is unavailable`. Same point as the audit's A13-5.
- **O-5, btrfs roots are refused outright (older).** `descriptor and mountinfo devices disagree`, base and head.
- **O-6, leftovers grow by 6 inodes per start on the head (5 on the base).** Documented; under a restart loop it adds up.

## 7. Proposed regression tests

Branch `claude/project-thread-suv0zx` of `evo-agi/Execution-Substrate`, one commit, `93a0833cf1d58576889910a90abfd4182e158139`, on top of `eb6eea9`. No pull request. The same two files are in the evidence folder as `proposed-*.go.txt`.

| Test | Finding | Needs | Base | Head | Prototype |
| --- | --- | --- | --- | --- | --- |
| `TestExecutionRootProbeAgreesWithStagingOnOverlayWithSeparateLayerFileSystems` | RT-1 | sudo | fails | fails | passes |
| `TestExecutionRootProbeAgreesWithStagingWhenTheFileSystemFixesModes` (2 subtests) | RT-1 | sudo, bindfs, setfacl | fails | fails | passes |
| `TestExecutionRootProbeAgreesWithRetentionWhenRenameRejectsNoReplace` | RT-2 | sudo, bindfs | fails | fails | passes |
| `TestExecutionRootProbeHandsNoDirectoryToAnotherUser` | RT-3 | sudo | fails | fails | passes |
| `TestExecutionRootProbeDirectorySwapStress` (opt-in) | RT-3 | root, `ES_PROBE_SWAP_STRESS_ROUNDS` | not run (it names a constant the base lacks; the harness race gave 13 of 1000 there) | fails: 17 and 2 of 1000 | passes: 0 and 0 of 1000 |

Run as `ci` (through sudo) and as root; results are the same (`log-proposed-tests.log`, `log-proposed-tests-prototype.log`, `log-proposed-stress.log`).

The first four follow the rule the pull request set for its own test: probe and use must agree, in either direction. So a repair may make the probe refuse the setup or make use work in it.

**The prototype** (`prototype-repair-not-for-merge.patch.txt`, 83 added lines in `execution_roots.go`) is not a proposed patch. I wrote it for two questions only. Can the tests pass at all? Yes. Does a repair of this kind cost any working setup? No: against the head, all 638 AGREE-OK cells stay AGREE-OK, all 161 GAP-SUBMIT cells and all 206 GAP-RESULT cells become refusals, and no other label changes (`log-pivot-*-head-prototype.txt`). The pull request's own three tests pass on it. It never left the container.

Notes for whoever adopts the tests:
- They fail on `trunk_dev` today. They belong in the change that repairs each finding, not before it.
- `.github/ci` fails a run on a skip that is not listed. Two tests skip without bindfs, and the stress test and its helper skip unless asked. The runner needs `bindfs` installed for the first two to gate anything; whether GitHub's `ubuntu-24.04` image has it is Unknown.
- `TestExecutionRootProbeHandsNoDirectoryToAnotherUser` presumes the repair direction of RT-3 (never change an owning user). Its comment says what to do if the repair binds the open to the creation instead.
- Checked on commit `93a0833`: `go vet` for Linux and for `GOOS=darwin` (the files are Linux-only by name), `gofmt`, and the whole `es/admission` package, where only these four tests fail (28.2 s, `log-package-run-with-proposed-tests.txt`). The module's root package fails 34 tests as root in this container, the same 34 as on a clean `eb6eea9`; they are host-dependent tests and have nothing to do with these files.

## 8. Coverage I could not provide

| Not covered | What stood in | What it leaves open |
| --- | --- | --- |
| macOS | ext4 with `grpid` for the group rule (base and head identical, 106 AGREE-OK, no gap, no refusal added); `GOOS=darwin go vet` | APFS, macOS ACL inheritance, and the Darwin variants of the no-follow open and the no-replace rename were not exercised at all |
| Remote Alpha host | nothing; it needs David's Mac and was excluded | its kernel, file system and service posture |
| Real NFS, CephFS, 9p, eCryptfs | bindfs for the rename behaviour; Linux v6.12 source for the rest | RT-2 on them is inference; root squash was not run |
| Real CIFS, vfat | bindfs with fixed modes | RT-1 shape b on them is a guess |
| Nomad, Docker, Vault, a real workload | hermetic Submit and a stand-in workload | what a caller sees after a failed retention; Docker with user-namespace remapping (only a plain user namespace was run) |
| The readiness endpoint over HTTP | code reading of `es/api/server.go:80`; the binary run stops at the trust model fetch | none that I can name |
| SELinux, AppArmor, quotas | nothing | denials and `EDQUOT` in the probe or in staging |
| Staging custody at submission time | only what the matrix exercises | `ensureDirectory` has RT-3's pattern and was not attacked; roots writable by other users (O-3) |
| The base under the 9 umasks, inode exhaustion and churned submissions | the head only | the check behind those results is outside the diff, so "older" is inference there |

## 9. Sensitive-material handling

No secret, key, token, environment file or database was read or copied. The stub config for the real binary used synthetic values. The evidence folder was scanned for tokens, private keys, e-mail addresses, phone numbers and personal names: no hit. Kernel sources were fetched from the public repository with no project data in the request.

## 10. Remaining uncertainty and the open decision

- The verdict binds `eb6eea9` with base `f9537a8`. A later commit on the branch needs a fresh look at least at the diff.
- All rates in 5.1 and 5.4 are from one machine.
- **Open decision, RT-3's new instance.** For merging as it is: the pull request removes 282 failing cells and adds no failure; the new window is in a setup that never starts, has the same precondition and the same attacker as the older window in the same probe, and is hit less often; repairing it properly means repairing both windows and `ensureDirectory`, which is its own change with its own audit. Against: the project's rule is no "accept now, revisit later" without a machine-enforced trigger, and this pull request does add one more privileged owner change on a directory opened by name. A middle way that keeps the rule: merge, and make the repair of RT-1 to RT-3 the next item, with the tests on my branch as its acceptance gate. I recommend the middle way. It is a tradeoff, so it is not mine to settle.

No stop condition was met.

## 11. Confidence

| | Level | Why |
| --- | --- | --- |
| The claim holds | high | 4,403 cells on the head with no false refusal and no gap of the targeted kind; real binary agrees; base and head compared cell by cell |
| RT-1 | high as run | two builds, two layers of use, real binary; reach in the field is inference |
| RT-2 | high on FUSE, medium beyond | traced system calls; network file systems from source reading only |
| RT-3 | high | measured on base and head, deterministic form shown, repair direction tested |
| Coverage | medium | one kernel, one machine, no macOS, no alpha host, no real network file system |

## 12. Effect status

Repair: not performed. Product code: unchanged. Commit: one, test files only, `93a0833`. Push: `claude/project-thread-suv0zx` only. Pull request: none opened; PR #20 not edited, not commented, not reviewed. Merge: none. No live service was contacted and the Linux box was not used. GitHub calls: `git fetch`, `git ls-remote`, one `git push` to my own branch. Scratch mounts and trees live in the container and go away with it.

## 13. Report delivery

This file: `/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/14-red-team-pr20.md`. Its SHA-256 is given in the thread reply that attaches it, because a file cannot contain its own hash.
Evidence: `/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/14-red-team-pr20-evidence/`, 52 files.

## 14. Final verdict

**HOLDS WITH CAVEATS** for `eb6eea90b0e694ffa2e7ab62f64f6d7d6f0936c3` (base `f9537a8`, tree `778e0082…`).

The caveats are RT-1 and RT-2 (medium, older, ES still starts where it cannot work) and RT-3 (low, older pattern, one new instance). Each has a proposed regression test on `claude/project-thread-suv0zx` at `93a0833`.
