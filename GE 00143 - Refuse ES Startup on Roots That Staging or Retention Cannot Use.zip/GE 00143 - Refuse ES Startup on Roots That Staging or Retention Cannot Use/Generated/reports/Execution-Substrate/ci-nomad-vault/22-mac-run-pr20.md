# Mac run result: PR #20 at d8826b8, `go test ./es/admission`

Run on David's Mac on 2026-11-23, 05:13:04Z to 05:17:05Z, from the brief `22-mac-brief-pr20.md`, after David's "Please go ahead for the Mac run when ready." (05:11:59Z). Read-only. Everything ran in one temporary folder, `/Users/ds/Repositories/Playground/es-pr20-mac.9Tym4j`, which was removed at the end. `/Users/ds/Repositories/Playground` still exists.

## 1. Outcome

| Step | Command | Exit | Result |
| --- | --- | --- | --- |
| a | whole `es/admission` at `d8826b8` | 1 | 15 top-level tests fail, **the same 15 with the same output as at trunk_dev `110d377` (f)** |
| b | PR #20's own probe tests | 0 | **pass**; 2 parts skip without passwordless sudo |
| c | `go vet ./es/admission` | 0 | **clean** |
| d | `gofmt -l es/admission docs_contract_test.go` | 0 | **clean** |
| e | `go test -run Doc .` | 1 | 1 failure, `TestRemoteAlphaESServiceTLSStatusReaderDocumentAcceptance`, which **also fails at `110d377`** |
| f | whole `es/admission` at `110d377` (without PR #20) | 1 | the same 15 top-level tests fail |

- **PR #20 adds no failure on macOS.** Comparing the result sets, `d8826b8` has 16 results that `110d377` lacks (14 PASS, 2 SKIP), all of them PR #20's new tests, and `110d377` has none that `d8826b8` lacks. After removing line numbers and durations, the failure output of a and f is identical (`diff` exit 0). None of the failing test files is in PR #20's diff (19 files).
- **The Darwin code that had never run on a Mac now has.** `TestExecutionRootProbeAcceptsSetgidRootsWithTheProcessGroup` and `…WithASupplementaryGroup` call the real startup probe, `probeCapabilities`. It ends with `probeNaturalResultDirectory`, which runs Darwin's `renameatx_np(RENAME_EXCL|RENAME_NOFOLLOW_ANY)` onto an existing name (must fail with `EEXIST`) and onto a free name (must succeed and keep the same file), after the nested staging directory and every staged mode. Both tests pass on the Mac, as do the staging steps they run after the probe.
- No output contains `panic:` or "the same test as root". Nothing was downloaded (no file in the module cache newer than the start marker), no test process was left, and the clone was clean before removal.

## 2. The pre-existing macOS failures (not caused by PR #20)

The 15 `es/admission` failures and the one docs failure exist identically without this PR.

- 9 `TestPrivateReplay*` tests: `reliable submit store: unsupported format`.
- `TestNewServiceRejectsDualMissingExecutionRootsBeforeMutation`, `TestRetainedResultReviewStartupNaturalDirectoryMask` (3 masks) and `TestRetainedResultReviewFreshServiceReopensPersistedResultWithReloadedKey`: `retained result authentication key is unavailable`.
- `TestRetainedResultAuditF1RenderedConfigConstructsConfiguredService`, `TestRetainedResultReviewStartupUsesExactKeyParentWithPaddedRoots` and `TestRetainedResultReviewStartupPreservesSpaceBearingKeyAncestor`: `validate execution.runtime_support_binary: too many levels of symbolic links`.
- Root package: `TestRemoteAlphaESServiceTLSStatusReaderDocumentAcceptance`, `fresh pass refused: exit status 1: Incomplete` (picked up by `-run Doc` because its name contains "Document").

Inference, not run: on macOS, Go's test temporary folders are under `/var/folders/…`, and `/var` is a symbolic link to `/private/var`.
- The replay store refuses a root path that contains a symbolic link: `OpenPrivateReplayCustody` returns `errClaimStoreUnsupported` ("unsupported format") when `rejectSymlinkPath(root)` fails (`es/admission/internal/reliablesubmit/replay_custody_file.go:160-161`).
- Darwin's no-follow open uses `O_NOFOLLOW_ANY`, which refuses a symbolic link anywhere in the path, so the result is "too many levels of symbolic links".
- The TLS status fixture resolves its temporary root (`pathlib.Path(root).resolve()`) but its validation probe uses it unresolved.
- PR #20's own tests use `physicalTestTempDir`, which is why they pass there.
- A rerun with `TMPDIR` set to the resolved `/private/var/…` path would confirm it. Making macOS pass in full is separate work, outside PR #20.

## 3. Environment and identity

```
ProductName: macOS / ProductVersion: 26.6.2 / BuildVersion: 25G83
arm64
ds
/sbin/launchd
GNU bash, version 3.2.57(1)-release (arm64-apple-darwin25)

origin/claude/project-thread-a9tcoa-setgid-probe = d8826b884571e2ece19bc69f7daecb1c4918802a  (as expected)
origin/trunk_dev                                 = 110d377a459471e94aa14cc83877f554ae62f893  (as expected)
HEAD after checkout = d8826b884571e2ece19bc69f7daecb1c4918802a
HEAD^{tree}         = b3b240d01dd540390c72243eb1ab7c467907e036  (as expected)

outside clone: go version go1.26.1 darwin/arm64
inside clone:  go version go1.26.5 darwin/arm64
GOVERSION   go1.26.5
GOROOT      /Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64
GOTOOLCHAIN go1.26.5
GOPROXY     off
GOCACHE     <temporary folder>/gocache
```

The existing clone's origin is `git@github.com:SeritArbores/Execution-Substrate.git`, not the `evo-agi` name. The fetch from it returned the expected hashes for both branches, so the commits under test are the right ones.

## 4. Step details

### a. Whole `es/admission` at `d8826b8`: exit 1

- Ran 05:13:47Z to 05:14:26Z; `FAIL execution-substrate/es/admission 32.461s`.
- Counts: `--- PASS` 1042, `--- SKIP` 2, `--- FAIL` 30 (15 top-level tests and their subtests). Four of the PASS lines are output of the child process that `TestDirectoriesOpenedByNameNeverChangeOwningUser` runs under the mask `0077`.
- Skips, each without passwordless sudo, as the brief expected:
  - `TestExecutionRootProbeRefusesWhenStagingCannotOwnNestedDirectories`: `needs passwordless sudo to give the fixture roots a group this process is not in`.
  - `TestDirectoriesOpenedByNameNeverChangeOwningUser/staging_directory`: `needs root or passwordless sudo`.

Failure output (identical at `110d377` apart from durations):

```
=== RUN   TestPrivateReplaySameDeliveryPB1Verification
    reliable_submit_replay_private_test.go:161: reliable submit store: unsupported format
--- FAIL: TestPrivateReplaySameDeliveryPB1Verification (0.00s)
=== RUN   TestPrivateReplayWinnerOriginalAfterDefaultKeyDrift
    reliable_submit_replay_private_test.go:195: reliable submit store: unsupported format
--- FAIL: TestPrivateReplayWinnerOriginalAfterDefaultKeyDrift (0.00s)
=== RUN   TestPrivateReplayConcurrentWinnerClassification
=== RUN   TestPrivateReplayConcurrentWinnerClassification/same_facts_positive_control
    reliable_submit_replay_private_test.go:235: reliable submit store: unsupported format
=== RUN   TestPrivateReplayConcurrentWinnerClassification/drifted_defaults_image_placement_and_keys
    reliable_submit_replay_private_test.go:341: reliable submit store: unsupported format
--- FAIL: TestPrivateReplayConcurrentWinnerClassification (0.00s)
    --- FAIL: TestPrivateReplayConcurrentWinnerClassification/same_facts_positive_control (0.00s)
    --- FAIL: TestPrivateReplayConcurrentWinnerClassification/drifted_defaults_image_placement_and_keys (0.00s)
=== RUN   TestPrivateReplayCommitUnknownOutcomeKinds
=== RUN   TestPrivateReplayCommitUnknownOutcomeKinds/actual_commit_response_lost
    reliable_submit_replay_private_test.go:470: reliable submit store: unsupported format
=== RUN   TestPrivateReplayCommitUnknownOutcomeKinds/connection_closed_before_commit
    reliable_submit_replay_private_test.go:470: reliable submit store: unsupported format
--- FAIL: TestPrivateReplayCommitUnknownOutcomeKinds (0.00s)
    --- FAIL: TestPrivateReplayCommitUnknownOutcomeKinds/actual_commit_response_lost (0.00s)
    --- FAIL: TestPrivateReplayCommitUnknownOutcomeKinds/connection_closed_before_commit (0.00s)
=== RUN   TestPrivateReplayFreshProcessVerifiedOriginal
    reliable_submit_replay_private_test.go:527: reliable submit store: unsupported format
--- FAIL: TestPrivateReplayFreshProcessVerifiedOriginal (0.00s)
=== RUN   TestPrivateReplayRedactionAndNonwiring
    reliable_submit_replay_private_test.go:587: reliable submit store: unsupported format
--- FAIL: TestPrivateReplayRedactionAndNonwiring (0.00s)
=== RUN   TestPrivateReplayProgressAdmissionReplay
=== RUN   TestPrivateReplayProgressAdmissionReplay/RetainedOriginalAfterRestartAndDrift
    reliable_submit_replay_private_test.go:681: reliable submit store: unsupported format
=== RUN   TestPrivateReplayProgressAdmissionReplay/ScopeOneOccupiesSameKey
    reliable_submit_replay_private_test.go:756: reliable submit store: unsupported format
=== RUN   TestPrivateReplayProgressAdmissionReplay/ConcurrentInitialWinner
    reliable_submit_replay_private_test.go:784: reliable submit store: unsupported format
=== RUN   TestPrivateReplayProgressAdmissionReplay/OccupiedAtCapacityAndValidMissRefusal
    reliable_submit_replay_private_test.go:842: reliable submit store: unsupported format
--- FAIL: TestPrivateReplayProgressAdmissionReplay (0.01s)
    --- FAIL: TestPrivateReplayProgressAdmissionReplay/RetainedOriginalAfterRestartAndDrift (0.00s)
    --- FAIL: TestPrivateReplayProgressAdmissionReplay/ScopeOneOccupiesSameKey (0.00s)
    --- FAIL: TestPrivateReplayProgressAdmissionReplay/ConcurrentInitialWinner (0.00s)
    --- FAIL: TestPrivateReplayProgressAdmissionReplay/OccupiedAtCapacityAndValidMissRefusal (0.00s)
=== RUN   TestPrivateReplayProgressHasNoEffectPaths
    (9 subtests, all PASS)
=== NAME  TestPrivateReplayProgressHasNoEffectPaths
    reliable_submit_replay_private_test.go:902: reliable submit store: unsupported format
--- FAIL: TestPrivateReplayProgressHasNoEffectPaths (4.98s)
=== RUN   TestPrivateReplayProgressOccupiedDisposition
    (DisjointCatalog, EquivalentWinner, ChangedIntent, UnavailableWinner)
    reliable_submit_replay_private_test.go:1025: reliable submit store: unsupported format   (once per subtest)
--- FAIL: TestPrivateReplayProgressOccupiedDisposition (0.01s)
    (4 subtests FAIL)
=== RUN   TestNewServiceRejectsDualMissingExecutionRootsBeforeMutation
    service_direct_test.go:41: unexpected dual-missing startup error: retained result authentication key is unavailable
--- FAIL: TestNewServiceRejectsDualMissingExecutionRootsBeforeMutation (0.00s)
=== RUN   TestRetainedResultAuditF1RenderedConfigConstructsConfiguredService
    service_direct_test.go:227: rendered configuration did not construct authenticated service: service=false err=validate execution.runtime_support_binary: too many levels of symbolic links
--- FAIL: TestRetainedResultAuditF1RenderedConfigConstructsConfiguredService (0.13s)
=== RUN   TestRetainedResultReviewStartupNaturalDirectoryMask
    /0000: service_direct_test.go:321: qualified mask 0000 refused startup: retained result authentication key is unavailable
    /0027: service_direct_test.go:321: qualified mask 0027 refused startup: retained result authentication key is unavailable
    /0077: service_direct_test.go:299: restrictive mask did not refuse startup at natural directory probe: service=false err=retained result authentication key is unavailable
--- FAIL: TestRetainedResultReviewStartupNaturalDirectoryMask (0.03s)
=== RUN   TestRetainedResultReviewStartupUsesExactKeyParentWithPaddedRoots
    service_direct_test.go:370: startup did not load exact key parent: service=false err=validate execution.runtime_support_binary: too many levels of symbolic links
--- FAIL: TestRetainedResultReviewStartupUsesExactKeyParentWithPaddedRoots (0.01s)
=== RUN   TestRetainedResultReviewStartupPreservesSpaceBearingKeyAncestor
    service_direct_test.go:418: startup did not load exact nested key: service=false err=validate execution.runtime_support_binary: too many levels of symbolic links
--- FAIL: TestRetainedResultReviewStartupPreservesSpaceBearingKeyAncestor (0.01s)
=== RUN   TestRetainedResultReviewFreshServiceReopensPersistedResultWithReloadedKey
    service_direct_test.go:449: first service startup: retained result authentication key is unavailable
--- FAIL: TestRetainedResultReviewFreshServiceReopensPersistedResultWithReloadedKey (0.00s)
```

(Two repetitive blocks are shortened in parentheses here; the device report had them in full.)

### b. PR #20's probe tests: exit 0

`go test -count=1 -v -run "$R" ./es/admission` with the brief's regex. `ok execution-substrate/es/admission 0.344s`.

| Test | Result | Time |
| --- | --- | --- |
| `TestExecutionRootProbeRefusesWhenStagingCannotOwnNestedDirectories` | SKIP (no passwordless sudo) | 0.01s |
| `TestExecutionRootProbeAcceptsSetgidRootsWithTheProcessGroup` | PASS | 0.01s |
| `TestExecutionRootProbeAcceptsSetgidRootsWithASupplementaryGroup` | PASS | 0.01s |
| `TestStagingRefusesModesTheStartupProbeDoesNotProve` | PASS | 0.00s |
| `TestDirectoriesOpenedByNameNeverChangeOwningUser` | PASS | 0.03s |
| ↳ `claimed_run_staging_root` (with the child run under mask `0077`, PASS) | PASS | 0.01s |
| ↳ `staging_directory` | SKIP (needs root or passwordless sudo) | 0.01s |
| ↳ `startup_probe_directory` (with the child run under mask `0077`, PASS) | PASS | 0.01s |
| `TestRetainedResultFileIdentityErrorNamesEachCheck` (7 subtests: second link, directory, symbolic link, other device, other owning user, other group, other mode) | PASS | 0.00s each |
| `TestExecutionRootCapabilityProbeCoversBothConfiguredRoots` | PASS | 0.00s |
| `TestStagingCustodyCapabilityProbeRetainsUnlinkUnprovenObjects` | PASS | 0.00s |

### c, d. `go vet` and `gofmt`: exit 0, no output

`gofmt` was the toolchain's own, `/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/gofmt`.

### e. Docs contract tests: exit 1

```
--- FAIL: TestRemoteAlphaESServiceTLSStatusReaderDocumentAcceptance (0.98s)
    remote_alpha_es_service_tls_status_test.go:603: fresh pass refused: exit status 1: Incomplete
FAIL
FAIL	execution-substrate	2.074s
```

The same command at `110d377` (an extra run beyond the brief) failed the same way: exit 1, the same line 603, `Incomplete`, 1.05s. The file is not in PR #20's diff.

### f. Whole `es/admission` at `110d377`: exit 1

- HEAD confirmed `110d377a459471e94aa14cc83877f554ae62f893`. Ran 05:15:54Z to 05:16:12Z; `FAIL execution-substrate/es/admission 17.115s`.
- Counts: `--- PASS` 1024, `--- SKIP` 0, `--- FAIL` 30. No `panic:`, no "the same test as root".
- The same 15 top-level tests and 30 FAIL lines as in a, with identical output after normalizing line numbers and durations.

### Leftovers and cleanup

- No `admission.test` process left; `git status --porcelain` empty.
- `find /Users/ds/go/pkg/mod -newer start-marker`: no output.
- `rm -rf` of the temporary folder: exit 0, the folder is gone, `Playground` exists. Go's own temporary folder under `/var/folders/…/T/` held nothing from this run afterwards.

### Beyond the brief (read-only)

- `go version` once outside the clone without the variables (go1.26.1).
- A one-line note of the folder path in the session's own scratch folder, deleted in the next command.
- Read-only looks inside the clone (test and error sources, `git diff --stat`, `merge-base`, `log`) and the extra docs-test run at `110d377`.
- No sudo, no push, no install, no existing folder touched except the allowed `remote get-url` read. The working directory stayed `Playground`; every command into the clone used a subshell or `git -C`.

## 5. Merge gate

The coordinator's condition was "the Mac run passes". Read against the brief's purpose, which was to tell PR #20's macOS failures apart from failures that exist without it, the run passes. PR #20's tests pass, `vet` and `gofmt` are clean, the Darwin rename and staging probe ran and passed, and every failure is identical at `110d377`. The full macOS suite was already red before PR #20; that is a separate follow-up.
