# ES startup refuses roots whose nested staging directories cannot get the roots' group (A6-3)

Report 12 of the CI Nomad/Vault track (renumbered from 11, because the PR #19 audit took that number). The coordinator's request of 2026-11-22 21:29Z: "A6-3, ES's startup check missing this case, is a real product gap: readiness says ready when submit will fail. Fix it properly in its own draft PR to trunk_dev, with ES failing closed at startup or readiness on that ownership condition and a regression test. Treat it as sensitive runtime/filesystem code: full provenance gate, and stop before writing if the right check point is unclear. That PR is product code, so it counts toward David's review."

Date: 2026-11-22. Repository: `evo-agi/Execution-Substrate`. Evidence: `12-evidence/` beside this file (`SHA256SUMS.txt` lists every file).

## 1. Outcome

| Item | Result |
| --- | --- |
| Product change | Yes, as asked. `es/admission/execution_roots.go`: one new startup probe step, `probeNestedStagingDirectory`, 56 added lines. **Product code: counts toward David's review.** |
| Check point | ES startup, in the existing configured-Submit capability probe (`NewService` → `probeCapabilities`, `es/admission/service.go:231`). ES refuses to start, so it never listens and never reports ready (section 3.2). |
| Change | Branch `claude/project-thread-a9tcoa-setgid-probe`, head `eb6eea9`, based on trunk_dev `f9537a8` (PR #14's merge, which landed during this work). Draft PR: [#20](https://github.com/evo-agi/Execution-Substrate/pull/20) |
| Regression test | `TestExecutionRootProbeRefusesWhenStagingCannotOwnNestedDirectories`: fails on trunk_dev `3a5f257` (the probe passes, staging fails with EPERM), passes on the head |
| Runner | Live red/green with a real bring-up whose workspace sits under a setgid directory of a foreign group: on this tree ES **refuses at startup** with the new error, no submission is staged; on trunk_dev `3a5f257` ES reports ready and the submission fails to stage (run 45078335546). Unit, docs, whole `es/admission` and ordinary bring-ups as two operators pass (run 45076707139). Section 6.4 |
| Manifest | `e46eec89dba2bac0000069d10cf9c3a3850c1a34f73c38ba3a634e3f48de9a31`, base `f9537a8`, upstream `origin/trunk_dev`, 8 files (section 2) |
| Mutants | 9 code mutants: 7 caught as a user with sudo; P05 and P06 survive and are equivalent in practice (section 6.3). 5 docs mutants, all caught. |

Nothing was merged.

## 2. Target identity

| Field | Value |
| --- | --- |
| Base | `trunk_dev` at `f9537a8680c24bf2108b95ed20ac3724e8939d3a` (PR #14's squash merge, on top of PR #18's `3a5f257`) |
| Topic branch and tip | `claude/project-thread-a9tcoa-setgid-probe` at `eb6eea90b0e694ffa2e7ab62f64f6d7d6f0936c3` |
| Commits | `191ef9d` (the fix, tests and docs, on `b8d6bc3`), `11000b2` (merge of trunk_dev `3a5f257`, no conflicts), `d8794de` (PR #18's known-gap sentences replaced, docs contract extended), `eb6eea9` (merge of trunk_dev `f9537a8`, PR #14; `docs_contract_test.go` merged without conflicts) |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked with `sha256sum -c` |
| Base-relative manifest | `e46eec89dba2bac0000069d10cf9c3a3850c1a34f73c38ba3a634e3f48de9a31`. `umask 022`, fresh clone from GitHub after the push, `git reset --mixed f9537a8`, `git branch --set-upstream-to=origin/trunk_dev` immediately before each of the two runs, byte-identical. 8 files (7 `tracked_modified`, 1 `untracked`: the new test file), textual diff `b3f198813dcb18f09dad05923dc6921103e4fe55bee5e1d129dab154630671b6`. Copy: `12-evidence/manifest-v2-setgid-eb6eea9.json`. Seven of the eight blobs are byte-identical to the earlier manifest of `d8794de` against `3a5f257` (`10a5e8ff…9a40`, copy `manifest-v2-setgid-d8794de.json`); only `docs_contract_test.go` differs, by PR #14's own changes to it. |
| Files | `es/admission/execution_roots.go`, `es/admission/execution_roots_inherited_group_test.go` (new), `es/admission/workstream_c_guardrails_test.go`, `docs_contract_test.go`, `PLANS.md`, `.docs/execution_lifecycle/implementation.md`, `.docs/system_overview/capability_probing.md`, `.runbooks/system/v1_bringup.md` |

## 3. The gap and the fix

### 3.1 The gap

Audit 05 addendum (A6-1 and A6-3) observed it on PR #18's bring-up: the bring-up workspace sat under a setgid directory whose group the operator was not in, so both roots inherited that group. Mechanism:

1. Every startup probe creates its entries **directly in the roots**, so they inherit the roots' group, and `Fchown` to the roots' owner changes nothing. All probes pass and ES reports ready.
2. Staging claims a run directory in the staging root, gives it the roots' owner, and sets it to `0750` (`claimStagingCustodyFromQualifiedRoot`, `staging_custody.go:503-506`). That mode carries no setgid bit.
3. The first directory staging creates inside (`ensureDirectory`, `staging_custody.go:578`) therefore gets ES's effective GID. Changing it to the roots' GID needs membership of that group. ES runs with no supplementary groups, so `Fchown` fails with EPERM, and every submission fails with "stage artifact payload failed", reported as a substrate failure.

The kernel rule behind step 3: a process without `CAP_CHOWN` may give a file only its current group or a group it is a member of.

### 3.2 Choice of check point

The coordinator asked me to stop if the right check point was unclear. It was clear, for four reasons:

- PLANS.md (line 220) states that "ES's behavioral startup checks stay the only capability gate". The gap is that gate over-claiming, so the fix belongs inside it, not in a launcher or a readiness endpoint.
- The startup probe already repeats staging's claim step on its own probe directory: `Mkdirat`, `Fchown` to the roots' owner, `Fchmod` to the stable stage mode `0750` (`execution_roots.go:465-487`). The only step it did not repeat is the next one staging takes, `ensureDirectory`'s create, `Fchown`, `Fchmod`, verify inside that `0750` directory. Adding exactly that step inside the probe directory makes the probe test what staging will do.
- It is behavioral, with no platform or label branching (AGENTS.md section 12). Where new entries always take their parent's group, as on macOS, the nested directory gets the roots' group, `Fchown` to it is allowed, staging works, and the probe passes.
- A startup refusal is the strongest fail-closed point: ES exits from `NewService` with "validate execution root capabilities: nested staging directory ownership is unavailable: operation not permitted" and never opens its listener, so neither health nor readiness can say ready.

Rejected alternatives:

- Refuse setgid roots whose group is not the effective GID. That is a static rule standing in for the behavior. It would wrongly refuse roots with a supplementary group that staging can use, and wrongly refuse on platforms where every directory inherits its parent's group.
- A check in the bring-up launcher. It would cover only bring-up, not other deployments of ES, and it would make the launcher a second capability gate.

### 3.3 What the new step does

`probeNestedStagingDirectory(stagingFD, owner)` runs inside `probeCapabilities`, right after the staging probe directory has been set to `0750` and before it is closed:

1. Re-observe the roots, then `Mkdirat(stagingFD, "nested", 0750)` and open it without following symlinks.
2. Re-observe, then `Fchown` it to the roots' UID and GID. On failure: `nested staging directory ownership is unavailable: <errno>`.
3. Re-observe, `Fchmod` to `0750`, `Fstat`, and require a directory on the staging root's device, with the roots' UID and GID and exactly mode `0750` (no setgid). Otherwise: `nested staging directory ownership is unavailable`.

It uses the same re-observation and verification pattern as `probeNaturalResultDirectory`. The `nested` directory stays inside the retained probe directory, like the other probe fixtures (no unlink without proven exact-object ownership).

### 3.4 Behavior

| Roots | Before | After |
| --- | --- | --- |
| Caller's UID and primary group, no setgid (the normal bring-up) | ready, staging works | ready, staging works (runner, section 6.4) |
| Group set directly to a group ES is not in | refused at startup, at the staging probe directory's `Fchown` (`execution_roots.go:476`) | unchanged |
| Setgid, inherited group ES is not in | **ready, every submission fails to stage** | **refused at startup**, "nested staging directory ownership is unavailable: operation not permitted" |
| Setgid, inherited group = ES's effective GID | ready, staging works | ready, staging works (test) |
| Setgid, inherited group = a supplementary group of ES | ready, staging works | ready, staging works (test) |
| ES as root | ready | ready (root may give any group) |
| macOS (every new entry takes the parent's group) | staging works | probe passes by the same reasoning; cross-compiled only, not run on a Mac |

## 4. Tests

New `es/admission/execution_roots_inherited_group_test.go`:

- `TestExecutionRootProbeRefusesWhenStagingCannotOwnNestedDirectories`: gives both roots a group this process is not in (the first free GID from 54321 up) with mode `2755`, via `sudo -n chgrp` and `sudo -n chmod`. It skips as root and without passwordless sudo. It runs the real `provisionExecutionRoots`, `owner` and `probeCapabilities`, then stages a nested directory the way Submit does (`claimStagingCustodyFromQualifiedRoot` for a run ID, then `ensureDirectory("payload", 0750)`). The probe and staging must agree; a staging failure must be EPERM, and a probe failure must carry the new message. This is platform-neutral: where staging works, the probe must pass.
- `TestExecutionRootProbeAcceptsSetgidRootsWithTheProcessGroup` and `…WithASupplementaryGroup`: setgid roots with the process's own group, or with a supplementary group it is in (skips if it has none), must pass the probe. The staging probe directory must hold exactly `nested`, with mode `0750` and the roots' owner, and staging must work. The supplementary-group case pins that the probe changes the group rather than only checking it.

`es/admission/workstream_c_guardrails_test.go`: the typed inventories list the new function's effects (3 re-observations, one `Mkdirat`, `Fchown` and `Fchmod` each) and pin its only caller, `probeCapabilities`.

`docs_contract_test.go`: new `TestNestedStagingOwnerProbeDocsContract` pins the rule in `PLANS.md`, `capability_probing.md`, `implementation.md`, the bring-up runbook and the source, and forbids PR #18's three known-gap sentences from coming back.

## 5. Docs

- `PLANS.md`: new `NESTED-STAGING-OWNER-PROBE-01` (bounded slice rule) after the natural result directory rule.
- `.docs/system_overview/capability_probing.md`: the nested probe after the natural result directory probe; PR #18's "Those checks do not yet catch roots that inherit another group…" is replaced by a sentence saying they now refuse startup.
- `.docs/execution_lifecycle/implementation.md`: the nested probe in the natural-probe bullet, naming `probeNestedStagingDirectory` and `stagingCustody.ensureDirectory`; PR #18's "so ES reports ready but every submission fails to stage" is replaced by "the nested staging probe above refuses them".
- `.runbooks/system/v1_bringup.md`, roots bullet: "ES refuses to start with roots that have another group, whether the group was set directly, for example to a shared project group, or inherited from a setgid parent directory; the inherited case is reported as `nested staging directory ownership is unavailable`. Keep the bring-up workspace out of setgid directories whose group is not your primary group."

## 6. Validation

### 6.1 Container, on `d8794de`

The runs in sections 6.1 to 6.4 used `d8794de`. The final merge `eb6eea9` brought in PR #14 only (CI files and test-only changes elsewhere); on `eb6eea9`, as `ci`, `gofmt` is clean, `go vet ./es/admission .` and `GOOS=darwin GOARCH=arm64 go vet ./es/admission` pass (PR #14 removed the copylocks finding), the new tests, the typed guardrail test and the docs tests pass (`container-eb6eea9-after-merge-uid30033.log`). The PR's own CI (PR #14's gate) runs on `eb6eea9`; that gate also fails if a test skips itself on its runner without a `skips-itself` line, so the sudo-dependent refusal test cannot silently skip there.

Two non-root users: `ci` 30033:30033 (groups 30033 and docker 996, passwordless sudo) and `ci3` 31500:31600 (groups 31600 and 996, no sudo).

| Check | `ci` | `ci3` |
| --- | --- | --- |
| `gofmt -l es/admission docs_contract_test.go` | clean | clean |
| The three new tests and `TestExecutionRootCapabilityProbeCoversBothConfiguredRoots` | pass; the refusal test logs "startup probe: nested staging directory ownership is unavailable: operation not permitted; staging a nested directory: operation not permitted" | pass; the refusal test skips (no sudo) |
| Docs tests `TestNestedStagingOwnerProbeDocsContract`, `TestRetainedResultReviewDocsContract` | pass | pass |
| Whole `es/admission` | ok (49 s) | ok (49 s) |
| Cross-build of `es/admission` and its tests for darwin/arm64, darwin/amd64, linux/arm64 | ok | |
| `go vet ./es/admission` | only the known pre-existing copylocks finding (`result_auth_test.go:395`) | |

Logs: `container-d8794de-uid30033.log`, `container-d8794de-uid31500.log` (script `container-test-script.sh.txt`), `crossbuild-d8794de.log`. The "whole root package" section of the two container logs is not a valid run: the tree there is a `git archive` copy extracted under umask `002`, so tests that need a git checkout or exact file modes fail. The root package ran on the runner instead (section 6.4).

### 6.2 Red on trunk_dev

`3a5f257` plus only the final test file (`red-3a5f257-uid30033.log`, `red-3a5f257-uid31500.log`, script `red-test-script.sh.txt`):

- As `ci`: the refusal test fails, "startup probe: <nil>; staging a nested directory: operation not permitted … startup probe and staging disagree". This is the A6-3 gap, reproduced.
- As both users: the two accept tests fail with "staging probe directory entries = []; want exactly "nested"", because trunk_dev has no nested probe.

### 6.3 Mutants

Code mutants (`mutants_a63.py.txt`; logs `mutants-d8794de-uid30033-gid30033.log`, `mutants-d8794de-uid31500-gid31600.log`), each on a fresh copy of `d8794de`, running the three new tests, `TestExecutionRootCapabilityProbeCoversBothConfiguredRoots` and `TestRetainedResultReviewStartupNaturalDirectoryMask`:

| Mutant | `ci` (sudo) | `ci3` (no sudo) |
| --- | --- | --- |
| P01 no call to the nested probe | caught | caught |
| P02 nested probe error ignored | caught | survives (refusal test skips) |
| P03 no `Fchown` of the nested directory | caught (supplementary-group test) | caught |
| P04 no `Fchmod` of the nested directory | caught (umask `0077` case of the natural directory mask test) | caught |
| P05 no verification after `Fchmod` | survives | survives |
| P06 verification skips UID and GID | survives | survives |
| P07 nested directory created directly in the root | caught | caught |
| P08 raw errno instead of the message | caught | survives (refusal test skips) |
| P09 nested probe before the probe directory's `Fchmod` | caught | survives (refusal test skips) |

P05 and P06 are equivalent in practice. After a successful `Fchown` and `Fchmod` on an open descriptor, POSIX guarantees the owner and mode the verification checks. Only a file system that accepts `chown` without applying it (for example vfat mounted with `quiet`) could make them differ. ES refuses such a file system at startup anyway, because the symlink probe that runs right after the nested probe (`execution_roots.go:499`) fails there. The verification is defensive and mirrors `ensureDirectory`'s. The three mutants that survive only as `ci3` are caught wherever the refusal test runs; the runner has passwordless sudo, so it runs there (section 6.4).

Docs mutants (`docmut.py.txt`, `docmutants-d8794de-uid30033.log`): restoring each of PR #18's three known-gap sentences (D01 to D03), or appending them next to the new text (D04, D05), fails `TestNestedStagingOwnerProbeDocsContract`. 5 of 5 caught.

### 6.4 Runner

GitHub-hosted `ubuntu-24.04` (rootful Docker, passwordless sudo, pinned Nomad 2.1.1, Vault 2.2.2, SPIRE 1.14.4, images by digest), probe branch `claude/project-thread-a9tcoa-bringup-probe`. Each probe commit's tree is `d8794de` plus one probe workflow and nothing else.

**Run [45076707139](https://github.com/evo-agi/Execution-Substrate/actions/runs/45076707139)** on `07e85a0` (workflow `probe-setgid.yml.txt`; log `runner-45076707139-job137375432747.log`):

| Step | Result |
| --- | --- |
| `gofmt`; `go vet ./es/admission` | clean; vet shows only the known copylocks finding |
| Probe tests as `runner` 1001:1001 (passwordless sudo; groups include adm, users, docker) | all pass, **the refusal test runs** (not skipped) and logs "startup probe: nested staging directory ownership is unavailable: operation not permitted; staging a nested directory: operation not permitted"; the supplementary-group test runs |
| Whole `es/admission` as `runner` | ok (82 s) |
| Docs tests | ok, including `TestNestedStagingOwnerProbeDocsContract` |
| Bring-up test as `runner`, ordinary workspace | passed (80 s); the staging probe directory holds exactly `nested`, `1001:1001`, mode `750` |
| Probe tests as `op` 2500:2600 (no sudo) | pass; the refusal test skips |
| Bring-up test as `op`, ordinary workspace | passed (50 s); `nested` is `2500:2600`, mode `750` |
| Whole `es/app` (informational) | only the known three: the two `ExactGoPreflight` subtests and `…InstalledSourceIdentity` |
| Root package with the gate's 11 skips (informational) | only `…WithSudoVisibleInspection`, the known failure that PR #14 fixes |
| The two live setgid steps | did not run their checks: the step shell runs with `-e`, so the expected test failure ended each step at once. My workflow bug; fixed in the next run. |

**Run [45078335546](https://github.com/evo-agi/Execution-Substrate/actions/runs/45078335546)** on `6d23bc2` (workflow `probe-setgid-live.yml.txt`; log `runner-45078335546-job137380512761.log`). Group `proj` (1800) was created, and `runner` is not in it. For each run the checkout's `.out`, where the bring-up test creates its workspace, was made `runner:proj` mode `2755`, so the workspace and both roots inherit group 1800:

| | This tree (`d8794de`) | trunk_dev `3a5f257` (control, a worktree in the same job) |
| --- | --- | --- |
| Workspace and roots | `1001:1800`, setgid | `1001:1800`, setgid |
| Bring-up `up` | **fails**: ES exits at startup with `build app: validate execution root capabilities: nested staging directory ownership is unavailable: operation not permitted` (from ES's log in the kept workspace) | passes, and so does `check`: the test asserts `submit-ready: true` in both outputs (`operator_scripts_integration_test.go`, the assertions before the execute loop) and went on to the execute loop |
| Submission | none: 0 `run-*` directories in the staging root | the execute loop fails with `stage artifact payload failed` (3 files carry it). The staging root holds `run-c156586e168fe211` as `1001:1800 drwxr-x---` (setgid cleared) with `payload` inside as `1001:1001`: the A6-1 mechanism exactly |
| Step verdict | **pass** | marked failed, by a wrong criterion of mine: the step also required the text `submit-ready: true` in the test log or workspace, but the test prints the `up` and `check` output only when it fails there. The test's own assertions establish readiness (it reached the execute loop), and the other three criteria held (test failed, `stage artifact payload failed` present, new refusal absent). I did not re-run it for that. |

So the fix turns "ready, then every submission fails" into a startup refusal that names the cause, on a real ES in a real bring-up.

Probe commit `b73839e` sits between the two runs: a commit of mine that removed the first workflow without adding the second (a failed `cp`), so it triggered no run. Its tree is exactly `d8794de`.

## 7. Not run, limitations

- Not run on macOS. The reasoning in section 3.2 and the cross-build are the only evidence for macOS; the supported-local proof on the Mac (`scripts/73_supported_local_proof.sh`) has not run with this change.
- The refusal test needs passwordless sudo and a non-root user, and the supplementary-group test needs a supplementary group. A developer machine without them skips the tests. On a GitHub-hosted runner both run (section 6.4). PR #14's gate, now on trunk_dev, already fails when a test skips itself on its runner without a `skips-itself` line, so a skip there cannot hide a regression.
- A file system that accepts `chown` silently is not covered by a test (P05, P06 above).

## 8. Effects

- Pushed the new branch `claude/project-thread-a9tcoa-setgid-probe`, head `d8794de`.
- Probe branch `claude/project-thread-a9tcoa-bringup-probe` fast-forwarded from `4667d92` to `07e85a0` (a merge commit whose tree is `d8794de` plus `.github/workflows/probe-setgid.yml`), then to `b73839e` and `6d23bc2` (tree `d8794de` plus `.github/workflows/probe-setgid-live.yml`). No force-push. The probe branch stays in use for the PR #19 repair's runner run; this session cannot delete branches.
- A failed `git worktree add` let a probe commit land on the local setgid branch; it was reset to `d8794de` before any push, so no pushed branch ever held it.
- Draft PR [#20](https://github.com/evo-agi/Execution-Substrate/pull/20) opened into `trunk_dev`, assigned to SeritArbores. No merge.

## 9. Request

Audit of `f9537a8..eb6eea9`. This is ES product code on the startup and staging path, so it counts toward David's review. Red-team and the auditor's model are the coordinator's call; my view is that a red-team is warranted, because the change is small but sits in sensitive filesystem code on the submit-readiness path.
