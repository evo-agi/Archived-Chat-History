# ES PR #20 narrow audit of the second repair: tests and docs for A16-1 and A16-2

Narrow, read-only correctness audit of `b5cc7cb..29254b1`, requested by the coordinator on 2026-11-23 at 03:20Z. Written by the audit thread "Audit the staging check repair", the thread that wrote audit 16, from about 03:21Z to 03:45Z (container clock). I am not the writer. I did not push, comment on, or merge anything.
Evidence: `18-audit-pr20-repair2-evidence/` beside this file. Its `README.md` explains every file and `SHA256SUMS.txt` lists them.

**Final verdict for `29254b1`: BLOCK, on one low finding.** Everything the writer claims about this delta reproduces. A16-1 is closed. A16-2 is closed in the docs, the runbook, the docs contract and a test. What is left is one sentence of the old claim in a comment in the product file, which audit 16 did not name. The fix is one sentence in a comment.

What holds (all checked on the exact pushed bytes):
- **Provenance reproduces.** Manifest `acc56339…acc7b`, 19 files, base `f62d024`, two runs byte-identical, equal to the writer's file, and equal again at the end.
- **The delta is tests and docs only.** 9 files, +257 −14. No product file, script or workflow changed. My diff is byte-identical to the writer's diff file.
- **A16-1 is closed.** With the mode change moved before the owner check, `TestDirectoriesOpenedByNameNeverChangeOwningUser` fails at the matching place, at each of the three places, as `ci` and as root, with "has mode 0750 after the refusal, want 0700". No race is involved.
- **F2, R9 and R13 are now caught**, as the writer says. Of my 55 mutants from audit 16, 44 are caught by behaviour tests (38 before), 4 more only by the typed inventories, and 7 survive, one of them the control.
- **A16-2 is stated and pinned.** `PLANS.md`, `capability_probing.md`, `implementation.md` and the runbook say that ES refuses a staging file system that cannot keep the governed-mount modes although submissions without governed mounts would work there. The new bindfs test fails if the probe stops staging those modes or if they leave the lists. The docs contract caught 8 of my 8 docs mutants.
- **A16-3, A16-7 and A16-8 are done.** I read the pull request description at 03:27Z.
- **CI run 45102745583 is green** on `29254b1`. In `es/admission` only the two listed stress tests skipped themselves.
- **The 7 survivors: I agree with the writer's reasons** (section 5.4).

What blocks:
- **A18-1 (low, a comment in product code).** `es/admission/execution_roots.go:573`, in the comment of `probeStagedEntries`, still says of a file system that does not keep a mode: "Staging would refuse every submission there." That is the claim David's decision replaced. The new test in this same delta shows a run without governed mounts staging on such a file system. Audit 16 cited two doc places and the lines right below this comment, and missed the comment. The writer corrected what was named and was told to change no product file. Neither is the writer's error. The sentence still has to change before the first product merge.

What the next steps need to know:
- **`trunk_dev` moved** to `110d377` (PR #21, one test file) while this repair was written. The pull request is "behind", and the branch rules require it to be up to date. So a new head is needed in any case. The comment can be corrected in the same step.
- A trial merge of `110d377` into `29254b1` has no conflict and leaves the pull request's own patch unchanged (same patch-id).
- The audit of the next head can be small and mechanical. Section 6 says what it has to show.
- Nothing I found touches what the product code does. The product files are byte-identical to `b5cc7cb`.

## 1. Audit target

| Field | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate`, draft PR #20 into `trunk_dev` |
| Topic branch | `claude/project-thread-a9tcoa-setgid-probe` |
| Head | `29254b16dcacab051a9007377083881a2c1e9d7f`, also `refs/pull/20/head` (`git ls-remote` at the start and at the end) |
| Head tree | `63c71fac6d7c289187e10d486ce7e850e3707c94` |
| Parent | `b5cc7cb78d3e9f14b015403fcad5451da5957f75` (audit 16: BLOCK on A16-1, A16-2) |
| Base of the manifest | `f62d0245e95e2b411be16511fc1bf9e1da727ce5`, still the merge base |
| `trunk_dev` now | `110d377a459471e94aa14cc83877f554ae62f893` (PR #21). It moved after the writer's manifest. See section 6 |
| Scope asked | the delta `b5cc7cb..29254b1`: one commit, 9 files |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified before each run) |
| Canonical manifest | SHA-256 `acc563391546918df6ea945aaea4a03a43034cfe4dedcbf49c6e870e405acc7b`, 19 changed paths, `textual_diff_sha256` `2c2c9fe8…5d93` |
| PR state when read | draft, 19 files, +2174/−92, 10 commits, mergeable state "behind" |
| Writer's report | `17-repair-pr20.md`, SHA-256 `b205d40b13181e0ec08601cd015b33ad14955562d16cfe990318876bf1c4e9d1` (verified) |
| Decision this delta carries out | David, 2026-11-23 02:48Z, on the decision card in this thread: "Keep refusing to start, and say so" |

Audit posture: read-only. Parent thread only; no subagents. All work ran in this cloud container, with the harness of audit 16. Nothing ran on David's Mac or on the Linux box.

## 2. Provenance reproduction

In a fresh clone (`es-prov2`), with the recipe's hash verified first:

```text
git fetch -q origin trunk_dev claude/project-thread-a9tcoa-setgid-probe
origin/<topic> = 29254b16dcacab051a9007377083881a2c1e9d7f      (equals the reported tip)
git merge-base --is-ancestor f62d024… 29254b1…                 (yes)
git checkout -q -f -B <topic> 29254b1… ; git status --porcelain (empty)
git reset -q --mixed f62d024… ; git branch -q --set-upstream-to=origin/trunk_dev
python3 -I v2.py 1.json ; python3 -I v2.py 2.json ; cmp 1.json 2.json   (identical)
```

- Opening manifest: `acc56339…acc7b`, 19 files. `cmp` with the writer's `manifest-v2-pr20-29254b1.json`: identical.
- Mode bits: all 19 entries `0644`. Nothing had to be tolerated.
- Closing manifest, after all work, upstream pinned again: two runs identical, and `cmp` with the opening manifest: identical. Remote refs at that time: topic branch and `refs/pull/20/head` `29254b1`, `trunk_dev` `110d377`.
- The manifest records the upstream's name, not its commit, so the moved `trunk_dev` does not change it. The base it is taken against is `f62d024`, as the writer states.
- I never wrote into the provenance clone.

## 3. Scope of the delta

One commit, `29254b1`. `git diff --name-status b5cc7cb 29254b1`:

| File | Kind |
| --- | --- |
| `es/admission/execution_roots_owner_check_test.go` | test (A16-1) |
| `es/admission/execution_roots_probe_file_checks_test.go` | test, new |
| `es/admission/execution_roots_probe_refusal_reasons_linux_test.go` | test (two new bindfs tests) |
| `es/admission/execution_roots_probe_swap_stress_linux_test.go` | comment only (A16-7) |
| `PLANS.md`, `.docs/system_overview/capability_probing.md`, `.docs/execution_lifecycle/implementation.md`, `.runbooks/system/v1_bringup.md` | docs |
| `docs_contract_test.go` | docs contract |

No `.go` file that is not a test changed, and nothing under `.github/`. My diff has the same SHA-256 as the writer's `delta-b5cc7cb-29254b1.diff` (`85531e89…8e1c`). Because the product files are byte-identical to `b5cc7cb`, the matrices of audit 16 (3,280 cells) describe this head as well. I did not rerun them.

Read in full: the delta, the helpers the new tests call, the product functions they exercise, the docs passages around each changed hunk, the pull request description, reports 16 and 17.

## 4. Review

### 4.1 A16-1: the mode half of the owner rule

Each of the three cases now runs its body only in a child process of the test binary whose process mask is `0077` (`rerunTestUnderOwnerOnlyProcessMask`). There ES creates the directory as `0700`, and `requireUntouched` requires `0700` and the creator's owner after the refusal. A mode change before the refusal leaves `0750`.

What I checked:
- **The child cannot pass without running the case.** The parent requires exit status 0 and the line `--- PASS: <subtest name>` in the child's output. A pattern that matches nothing prints no such line.
- **The chain for the root-only case.** As a non-root user the case first reruns itself as root through `sudo`, which drops the environment. The root process then reruns itself under the mask. The baseline log shows both levels.
- **Each case still refuses for its own reason.** The three error texts are still required.
- **Nothing was lost by moving the bodies under the mask.** The owner-check mutants O1 to O8 are still all caught, as `ci` and as root.
- **The mask stays in the child.** The parent process never changes its own mask, so other tests in the package are not affected.
- **No flake in 40 repeats** as `ci` and 40 as root.

The file has no build constraint, so the test also compiles for macOS (`go vet` for darwin is clean). It has not run there.

### 4.2 The two file-check tests

- `TestRetainedResultFileIdentityErrorNamesEachCheck` is a table over `retainedResultFileIdentityError` with crafted identities. I split the two compound checks into halves: link count alone, regular file alone, owning user alone, group alone. All four finer mutants are caught, each by its own row.
- `TestStartupProbeFileChecksRefuseAnOwnerTheFileSystemIgnores` calls `probeStagedFile` and `probeRetainedResultFile` directly on a bindfs mount with `--chown-ignore --chgrp-ignore` and requires the exact text of the check after the owner change. That text differs from the one a failing `Fchown` gives, so the test cannot pass for the wrong reason. It relies on the helper's layout (`backing` beside `mount`), which is what `mountTestBindfs` creates.
- Its limit is observation A18-2: for the staged file, the owning-user half of the check is held by no test.

### 4.3 A16-2: the test

`TestStartupRefusesStagingThatCannotHoldGovernedMountModes` puts staging on `bindfs --perms=o-rwx`, the fixture of audit 16, and results in an ordinary directory. It requires three things: the startup probe refuses with `staged 0755 directory mode is unavailable`; on the same roots a run staged the way a submission without governed mounts is staged works and passes the handoff check; the first governed-mount directory fails.

- The second part calls `stagePayload`, `stageCapturedRuntimeSupportBinary` and `stageWorkloadVaultTrustMaterial`. Those are all the staging calls of a submission without governed mounts (`executionpackage.go:136, 140, 179, 182, 185, 254`); the others are in `mounts.go` and run only with governed mounts.
- Two mutants of mine that undo David's choice are both caught, by this test among others: A2 (the probe stages none of the three governed-mount modes) and A2L (the three modes leave both lists).
- The third part accepts any error. That is enough for what the test states.

### 4.4 A16-2: the docs

I compared each new statement with the code and with the measured cases of audit 16.

| Place | Statement | Verdict |
| --- | --- | --- |
| `PLANS.md` | refuses "instead of reporting ready while submissions or retentions fail"; the staged modes include the governed-mount modes, "so ES also refuses to start on a staging file system that cannot keep those modes although submissions without governed mounts would work there"; "That is deliberate" | true; matches the 8 cells of audit 16 and the new test |
| `capability_probing.md` | "refuses startup instead of failing submissions"; the governed-mount sentence | true |
| `implementation.md` | "startup refuses a staging file system that cannot keep them even when no submission would use governed mounts" | true |
| runbook | "ES refuses such a file system even if your submissions never use governed mounts, because staging a governed mount needs `0755` directories and `0644` and `0755` files" | true for what an operator needs. The "because" fits the mode example, not the overlay and rename examples before it, which fail every submission or every retention anyway |
| `PLANS.md` (A16-3) | "a root ES whose staging file system gives new entries to another user, for example a bindfs mount with `--create-for-user`, is refused although it started before this rule" | true; the 8 cells of audit 16, section 6.4 |
| docs contract | 6 new required phrases; the two old sentences forbidden | holds: 8 of my 8 docs mutants caught |

Two limits, neither a defect of this delta:
- The contract forbids the two old sentences word for word. A paraphrase of the old claim passes (my control mutant DM9). That is how this contract works everywhere.
- The contract does not look at the comment of finding A18-1.

Other uses of "every submission" and the like at the head, checked: `PLANS.md:785` (the setgid case, where every submission does fail), `capability_probing.md:166` (a results file system without the no-replace rename loses every result), `execution_roots.go:673` (the same, for retention). All three are correct. `docs_contract_test.go:13616` is an old sentence that the nested-probe contract keeps out.

### 4.5 A16-3, A16-5, A16-7, A16-8

- A16-3: named in `PLANS.md` and held by the contract (4.4).
- A16-5: report 17 corrects report 15's observation. No bytes in the repository were affected.
- A16-7: the stress test's header now says its nested target is no longer reached. Comment only.
- A16-8: the pull request description, read at 03:27Z, says the probe re-observes both roots once per batch of effects, 15 times per start. It no longer says "before each effect", and it says "while submissions fail there".

## 5. Validation I ran

All on `29254b1`. Identities as in audit 16: `ci` (30033, passwordless sudo, bindfs), `ci3` (31500, no sudo), root.

### 5.1 Static checks and tests

| Check | Result |
| --- | --- |
| `go build ./...`, `gofmt -l`, `go vet ./es/admission .` | clean |
| `GOOS=darwin GOARCH=arm64` vet and build | clean (type-check only) |
| whole `es/admission`, `-count=1 -v`, as `ci` | `ok`, 1,120 runs (1,110 at `b5cc7cb`; the 10 new ones are the table test with its 7 rows and the two bindfs tests), 2 skips, both listed |
| the same as root | `ok`, 6 skips, the same six tests as at `b5cc7cb` |
| the same as `ci3` | `ok`; 11 tests and one subtest skip, all for lack of sudo or the opt-in variable; two of them are the new bindfs tests |
| `go test ./...` as `ci` | the same 10 listed tests fail as at `b5cc7cb`, which audit 16 compared with the base; every package has the same result as at `b5cc7cb` |
| the four new and changed tests, 40 times, as `ci` and as root | `ok` both |

### 5.2 The PR's own CI

Run 45102745583, job 137457076512, read through the GitHub connector: event `pull_request`, head `29254b1`, conclusion success, every step success, including "Install bindfs", "Check the test gate", "Test" and "Listed tests still fail".

- The gate fails when a test skips itself without being listed. At the head `environment-only-tests.txt` lists two skipping tests for `es/admission`, the stress test and its helper. So a green gate means the new and changed tests ran on the runner, with their sudo and bindfs cases.
- From the job log (1,241 lines; I fetched the last 24 and they equal the writer's copy; the other lines are from that copy): CI tested the merge of `29254b1` into `f62d024`; `bindfs 1.14.7-1.1build2`; `ok execution-substrate/es/admission 59.363s`; "test gate passed: 41 packages, 3 of them with skipped entries (15 entries); 41 tests skipped themselves, all of them listed"; "all 15 listed tests still fail on this host".
- CI has not run against `trunk_dev` `110d377`.

### 5.3 Mutants

The 55 mutants of audit 16 and R15, unchanged, plus 8 finer ones, each on a scratch copy inside a private mount namespace. Per mutant: the behaviour tests as `ci`; the owner-check and owner-of-file mutants also as root; survivors against the whole package. The unmutated tree passes both ways. No run showed mount-table noise.

| Group | At `b5cc7cb` | At `29254b1` |
| --- | --- | --- |
| O1 to O8, owner check removed, moved or wrong | caught | caught, as `ci` and as root |
| **O10, O11, O12, mode change before the owner check** | O10 and O12 survived everything; O11 only a typed guardrail | **all three caught by the behaviour test, as `ci` and as root, each at its own place** |
| P1 to P7, G1, G2, L1 to L7 | caught | caught |
| F1 to F6, D1 to D5 | F2, F6, D1 survived | **F2 caught**; F6 and D1 survive |
| R3, R4, R7, R8, R10, R14 | caught | caught |
| R1, R2 | survived | survive |
| R5, R6 (and R15, both together) | survived | survive |
| **R9, R13** | survived | **both caught** |
| R11, R12, B1, B2 | only the typed inventories | the same |
| O9, control | survives | survives, as it should |

Totals for the 55: 44 caught by behaviour tests, 4 more only by `TestAdmissionProductionHasOneResolverAndOneMaterializationPath`, 7 survive (O9, F6, D1, R1, R2, R5, R6). The writer's numbers are the same; the writer counts R15 in place of the control.

The 8 finer mutants: the four halves of the retained-file checks are caught. A2 and A2L are caught. F2b (group half of the staged file's owner check) is caught as `ci` and survives as root. F2a (owning-user half) survives as both. See A18-2.

### 5.4 The survivors, judged

The coordinator asked me to judge the writer's section 3.2.

| Mutant | Writer's reason | My judgement |
| --- | --- | --- |
| F6, link count and regular file of a staged file | a file just created with `O_EXCL` is regular and has one link unless something links it in between | Agree. The file is created at `execution_roots.go:602` with `O_CREAT\|O_EXCL`. No fixture here reports another link count for a new file. The check is inline, so a table test would need a product change |
| D1, device of a staged directory | the directory is opened with `RESOLVE_NO_XDEV` | Agree for Linux: `platformOpenAtNoFollow(…, true)` adds `RESOLVE_NO_XDEV` (`staging_custody_linux.go:10`), so a directory on another device does not open. On macOS the check is the only guard, and nothing has run there |
| R1, R2, collision rename | Linux answers `EEXIST` before the file system is asked, and the free-name rename refuses the same file systems | Agree. For R2 there is one more reason: if a file system replaced the target, the source name is gone and the free-name rename fails |
| R5, R6, R15, checks after the free-name rename | need a file system that changes a file's identity on rename | Agree. None of ext4, tmpfs, xfs, overlay or bindfs does. An object-store file system that renames by copying would |
| R11, R12, B1, B2, behind the inventories | equivalent on every reachable path, or need a race | Agree. Any mask that leaves the result directory at `0750` also leaves `0600` and `0640` files as created, so the `Fchmod` cannot matter where the probe gets that far |

These stay what audit 16 called them: observations A16-4 and A16-10. They guard against file systems no fixture here provides. They do not block.

### 5.5 Docs mutants

9 of my own against `TestStartupProbeUseAgreementDocsContract`: the unmutated tree passes; 8 are caught (each new statement removed, each old claim put back beside the new text); the control, the old claim in other words, survives as expected.

## 6. The base moved

Not a finding on the patch. It decides what the next step has to be.

- `trunk_dev` is `110d377` since PR #21 was merged, after the writer took the manifest. It changes one file, `remote_alpha_es_service_tls_status_test.go`, which the pull request does not touch.
- GitHub reports the pull request as "behind". The rules on `trunk_dev` require an up-to-date branch, so `29254b1` cannot be the head that merges.
- Trial merge in a scratch copy: no conflict; tree `26deaef8689d732a9ad0c81aac0fb65401322fce`; the pull request's patch against the new base has the same patch-id as against the old (`32cdf1a0…94fe`).
- Merge gate, provenance rule 5.4, item 2: a branch update makes new bytes and needs a new manifest; after a clean merge with an unchanged patch the coordinator may accept a provenance-only re-check; otherwise the new bytes are audited.

With the fix for A18-1 in the same step the patch is not unchanged, so the next head needs an audit of that step. It is a small one. It has to show:
1. the new manifest reproduces;
2. against `29254b1`, the only change outside the merge is in comment lines of `es/admission/execution_roots.go` (every changed line begins with `//`), plus a docs-contract line if the writer adds one;
3. the merge of `trunk_dev` has no conflict;
4. build, vet and the PR's CI are green on the new head.

That is a provenance check with one extra diff. It needs no new mutant or matrix run, because no line of code changes.

## 7. Findings

### 7.1 On the patch

```text
AUDIT FINDING
ID / Type / Severity: A18-1 / product-code comment contradicts the decided and
  documented behaviour / low
Current contract or strategic target: David's decision of 2026-11-23 02:48Z on
  A16-2: "Keep refusing to start, and say so". PLANS.md at the head,
  STARTUP-PROBE-USE-AGREEMENT-01: ES refuses a staging file system that cannot
  keep the governed-mount modes "although submissions without governed mounts
  would work there". Audit 16, A16-2, required correction (a): correct "every
  submission".
Path and line: es/admission/execution_roots.go:565-573, the comment of
  probeStagedEntries: "... and a file system that does not keep the modes it is
  asked for fails on the first mode it cannot keep. Staging would refuse every
  submission there."
Evidence: the sentence came with commit 259480a, is in b5cc7cb and is unchanged
  in 29254b1 (the file is byte-identical). For a file system that cannot keep
  only the governed-mount modes it is false: in this delta,
  TestStartupRefusesStagingThatCannotHoldGovernedMountModes stages a run without
  governed mounts on such a mount and passes; in audit 16 the real Submit,
  retention and read worked there in 8 of 8 cells. The docs contract does not
  read this comment.
Impact: none on behaviour. Whoever reads the function that makes the refusal is
  told the opposite of what PLANS.md says and of what David chose. It is the
  first product merge, and the sentence would be in it.
Required correction: change the sentence so that it no longer says every
  submission is refused on a file system that cannot keep a mode. For example:
  "Staging would refuse submissions there: all of them on such an overlay, and
  on a file system that cannot keep a mode, those that need that mode." Comment
  only. The docs contract already reads product files; a line there that keeps
  the old sentence out would hold it, at the writer's choice.
Uncertainty: none about the text or the behaviour.
Patch defect or pre-existing issue: patch (the pull request; not this delta).
  Audit 16 cited PLANS.md:803-804, capability_probing.md:155-157 and
  execution_roots.go:574-596, and missed line 573. The writer corrected what
  was named, under an instruction to change no product file.
```

Observations. None needs a change before merge on its own.

- **A18-2. The owning-user half of the staged file's owner check is held by no test.** My mutant F2a removes `identity.UID != owner.UID` from `probeStagedFile` and survives every test as `ci` and as root. In the new bindfs test the group alone already differs. In a whole probe that half cannot be reached, because the owner rule refuses first. The retained file's two halves are both held by the table test. If the writer wants to close it: as root, one more call that asks for the owner `54321` with root's own group.
- **A18-3. "ES starts only where every submission it accepts can be staged"** (`PLANS.md`, now also a required phrase of the docs contract) reads wider than what the probe proves. The probe proves every mode and kind of entry a submission can need. It cannot prove room on the disk. In its paragraph, which is about modes, I read it as the reason for the rule and not as a false claim.
- **A18-4. Carried over from audit 16, unchanged and outside this delta:** A16-4 (no Linux test reaches the existing-name rename), A16-6 (bindfs is pinned by version only), A16-9 (retention's modes have no list and guard), A16-10 (the survivors of 5.4), A16-11 (the trailer of `29254b1` again names Claude [model withheld]; this commit changes no product code).

### 7.2 Older issues

None new. Red-team O-1 and O-3 stand as audit 16 recorded them.

## 8. Validation assessment

Re-run by me: provenance (opening and closing); build, vet, format and the Darwin cross-checks; whole `es/admission` as three identities; the whole module; the new tests 40 times as two identities; 64 code mutants and 9 docs mutants; a trial merge with the moved base.

Read, not re-run: the PR's CI (run and job through the connector; the log's tail fetched; the rest from the writer's copy), the pull request description.

Not run:
- **The matrices of audit 16.** Not needed: the product files are byte-identical to `b5cc7cb` (`git diff` over all non-test `.go` files is empty).
- **macOS.** Only type-checked. Two test files of this delta have no build constraint and would run on the Mac; they have not. The no-replace rename on macOS has still never executed. A run of `go test ./es/admission` on the Mac before merge would settle both.
- **The merged result with `110d377`.** Only the trial merge. The next head's CI covers it.

## 9. Sensitive-material handling

No secrets, keys, tokens or env files were read or written. I scanned the evidence folder for addresses, tokens and key material: no match. The CI log is cited from the writer's evidence and not copied.

## 10. Remaining uncertainty and stop conditions

- macOS behaviour, as in audit 16. Inference only.
- If the next head changes more than the comment, a docs-contract line and the merge, the small audit of section 6 is not enough.
- Stop condition for the merge gate: the PR head must equal an accepted commit. `29254b1` is not accepted, and it is behind `trunk_dev`.

## 11. Confidence

| Kind | Level | Why |
| --- | --- | --- |
| Provenance | high | recipe verified; two runs identical; equal to the writer's manifest; closing equals opening; remote refs unchanged between start and end |
| Validation | high on Linux, none on macOS | three identities, 64 code mutants and 9 docs mutants, 40 repeats, the PR's CI read from the source |
| Implementation | high | every claim of the writer about this delta reproduced; the one finding is a sentence both audits could have caught earlier |

## 12. Effect status

Repair: not performed. Commit: none. Push: none. PR: not edited, not commented, not reviewed. Merge: none. GitHub calls: `git clone`, `git fetch`, `git ls-remote`, and reads of PR #20, run 45102745583, its job and the tail of its log. The trial merge was aborted in a scratch copy. Scratch trees, mounts and users live in this container.

## 13. Report delivery

`/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/18-audit-pr20-repair2.md`. Its SHA-256 is in the thread reply and in project memory. Evidence: `18-audit-pr20-repair2-evidence/` with `SHA256SUMS.txt`.

## 14. Final verdict

**BLOCK** for `29254b16dcacab051a9007377083881a2c1e9d7f` (base `f62d024`, tree `63c71fac…`, manifest `acc56339…acc7b`), on A18-1 alone.

Next: the writer corrects the comment at `execution_roots.go:573` and merges `trunk_dev` `110d377` into the branch, in one step; new provenance; the small audit of section 6; then David's review of the product change. A16-1 and A16-2 need nothing more.

STATUS: WAITING
