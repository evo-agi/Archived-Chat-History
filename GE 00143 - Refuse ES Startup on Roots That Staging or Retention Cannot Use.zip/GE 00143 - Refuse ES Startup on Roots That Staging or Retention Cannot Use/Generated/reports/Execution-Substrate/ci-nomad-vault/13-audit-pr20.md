# ES PR #20 audit: startup refuses when staging cannot own a nested directory

Independent correctness audit, requested by the coordinator on 2026-11-22. Written by the audit thread "Audit the staging ownership startup check", from about 22:45Z to 23:25Z.
Evidence: `13-audit-pr20-evidence/` beside this file. Its `README.md` explains every file and `SHA256SUMS.txt` lists them.

**Final verdict for `eb6eea9`: ACCEPT.** No blocking finding. I record six observations on the patch and two on older code. None needs a change before merge.

What holds:
- **The fix closes A6-3.** Across 340 ownership cases (17 setups, 5 identities, 4 file systems) the base has 30 cases where startup passes and staging then fails. The head has 0.
- **No working setup is refused.** 42 cells differ between base and head. 30 are the cases above. The other 12 were refused on the base already and now get the new, clearer message. No cell went from working to refused.
- **The probe can only refuse what the first submission would have failed on.** It runs the same system calls, in the same order, with the same checks, as staging does inside a run directory.
- **The check point is right.** The real `es` binary built from the head exits with `build app: validate execution root capabilities: nested staging directory ownership is unavailable: operation not permitted` before it listens or makes any network call.
- **Tests are red on the base and green on the head.** The PR's own CI ran the refusal test on GitHub's runner. It did not skip.
- **A same-user symlink swap during the probe changes nothing outside the roots** (2000 rounds). The same harness does catch a mutant that follows symlinks.
- **33 mutants of my own: 21 caught, 12 survive** as a user with sudo. No survivor changes a start-or-refuse outcome. Section 6.7 gives the reason for each.

What the merge gate needs to know:
- `trunk_dev` moved after the audit base, to `f62d024` (PR #16, one test file, no overlap with this PR). Updating the branch creates new bytes, so provenance §5.4 step 2 applies. This audit binds `eb6eea9` only.
- This is product code. Under the merge policy it counts toward David's review of the first three product merges. Whether it needs a red-team is the coordinator's call.
- Not run on macOS or on the Remote Alpha host. Section 8 says what stands in for them.

## 1. Audit target

| Field | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate`, draft PR #20 into `trunk_dev` |
| Topic branch | `claude/project-thread-a9tcoa-setgid-probe` |
| Head | `eb6eea90b0e694ffa2e7ab62f64f6d7d6f0936c3`, also `refs/pull/20/head` (`git ls-remote` at the start and at the end) |
| Head tree | `778e00829e23cb382fa364295b1f6af075b50d7c` |
| Base | `trunk_dev` at `f9537a8680c24bf2108b95ed20ac3724e8939d3a` (PR #14's merge). It is a parent of the head and the merge base. |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked before each run |
| Canonical manifest | `e46eec89dba2bac0000069d10cf9c3a3850c1a34f73c38ba3a634e3f48de9a31`, upstream `origin/trunk_dev`, 8 paths (7 `tracked_modified`, 1 `untracked`), textual diff `b3f198813dcb18f09dad05923dc6921103e4fe55bee5e1d129dab154630671b6` |
| Writer report | `12-setgid-probe.md`, SHA-256 `c6e4255f9411cd21340615ea6a58be95632cb350ced4e9f8de17b380009f3b32`; `12-evidence/SHA256SUMS.txt` checks OK |

Audit posture: read-only. No repair, commit, push, PR comment, review, edit or merge. No subagents. All mutants and harness files lived in scratch copies outside the audit clone.

## 2. Provenance reproduction

I took the manifest before reading the diff, per provenance §5.3: a clean clone, HEAD reset to `f9537a8`, the tip's bytes in the working tree, upstream `origin/trunk_dev`.

| Run | Time | Result |
| --- | --- | --- |
| Opening, 2 runs | 22:46Z | `e46eec89…9a31`, byte-identical to each other and to the writer's `12-evidence/manifest-v2-setgid-eb6eea9.json` |
| Closing, 2 runs | 23:09Z | byte-identical to the opening |
| Final, 2 runs | 23:15Z | byte-identical to the opening. Taken after the last mutant runs and after `origin/trunk_dev` was refreshed. |

All eight paths have mode `0644`, so no mode-bit tolerance was needed. Each working-tree file hashes to the blob of the same path in `eb6eea9` (`provenance-notes.txt`).

Other identity checks:
- `eb6eea9` is a merge of `d8794de` (the writer's last commit) and `f9537a8`. Its tree equals `git merge-tree d8794de f9537a8`, so the merge added nothing by hand.
- Seven of the eight paths are byte-identical between `d8794de` and `eb6eea9`. Only `docs_contract_test.go` differs, through PR #14. So the writer's runner evidence on `d8794de` covers the product code and the new tests of `eb6eea9`.
- The PR's CI ran on merge commit `efea5ea`, whose tree is `778e0082…`, the head's tree.
- I fetched the writer's two runner job logs again from GitHub. Both are byte-identical to the copies in `12-evidence/`.

## 3. Scope of the change

Eight paths, 377 lines added and 9 removed.

| Path | Change |
| --- | --- |
| `es/admission/execution_roots.go` | +56: constant `nestedStagingProbeName`, one call at line 488, new function `probeNestedStagingDirectory` at lines 568 to 605. The only product change. |
| `es/admission/execution_roots_inherited_group_test.go` | new, 244 lines, three tests and helpers |
| `es/admission/workstream_c_guardrails_test.go` | +10: the new function's allowed system calls and its single caller |
| `docs_contract_test.go` | +30: `TestNestedStagingOwnerProbeDocsContract` |
| `PLANS.md` | +10: rule `NESTED-STAGING-OWNER-PROBE-01` |
| `.docs/execution_lifecycle/implementation.md`, `.docs/system_overview/capability_probing.md`, `.runbooks/system/v1_bringup.md` | the rule, and PR #18's three known-gap sentences replaced |

## 4. Coverage

Read in full: `AGENTS.md`, the parts of `PLANS.md` on execution roots and capability probes, `.docs/system_overview/capability_probing.md`, `.docs/execution_lifecycle/implementation.md` around the roots, `.docs/system_overview/remote_supported_host_alpha.md`, the bring-up runbook section, the whole diff, `execution_roots.go`, the staging code the probe mirrors (`staging_custody.go`: `claimStagingCustodyFromQualifiedRoot`, `ensureDirectory`, `writeFile`), the startup path (`cmd/es/main.go`, `es/app/app.go`, `es/admission/service.go`), the platform open helpers for Linux and Darwin, the new tests, the guardrail and docs contract tests, the CI gate's skip list, the writer's report and evidence, and finding A6-3 in `05-audit-addendum.md`.

Not inspected: schemas and migrations (none touched), the other services, anything in `es/app` beyond the startup path and the tests that count probe fixtures.

## 5. Review

### 5.1 Check point

`NewService` (`service.go:222-231`) provisions the roots, reads their owner and calls `probeCapabilities`. It is the only production caller, and `probeCapabilities` is the only caller of the new function (grep, and pinned by the guardrail test). `app.New` (`app.go:35`) calls `NewService` before `Start`, which fetches the trust model and then listens. `main.go:27` prints `build app: …` and exits. So a refusal happens before ES listens, reports ready, contacts another service or accepts a submission. The new step runs inside the existing staging probe, right after the probe directory is set to `0750` (`execution_roots.go:484-488`).

The check runs once per start. A change to the roots' group or to ES's groups after startup is not probed again. A submission then fails closed at staging, as before. That is older behaviour and outside this PR.

### 5.2 Does the probe match staging?

Yes. Step by step:

| Step | Staging (`staging_custody.go`) | Probe (`execution_roots.go`) |
| --- | --- | --- |
| Parent directory | run root: `Mkdirat`, `Fchown` to the roots' owner, `Fchmod 0750` (479 to 506) | probe directory: the same three calls (465 to 484), unchanged by this PR |
| Create | `Mkdirat(payload, 0750)` (551) | `Mkdirat(nested, 0750)` (572) |
| Open | `platformOpenAtNoFollow` (556) | the same helper (575) |
| Own | `Fchown(owner.UID, owner.GID)` (578) | the same (583) |
| Mode | `Fchmod` (583) | `Fchmod 0750` (589) |
| Verify | directory, same device, UID, GID, exact mode (597 to 601) | the same, plus link count at least 1 (597 to 601) |

The only extra condition in the probe is the link count, which fails only when the directory is removed while the probe holds it open. So in an undisturbed start, the probe refuses exactly when staging's first nested directory would fail. This is the argument that covers platforms I could not run (section 8).

Files are covered by the same condition. `writeFile` also calls `Fchown` to the roots' owner (`staging_custody.go:667`), and the kernel applies one rule to files and directories.

### 5.3 False refusals

None found. The matrix in section 6.4 is the evidence. The setups the brief names:

| Setup | Base | Head |
| --- | --- | --- |
| Roots owned by ES's UID and primary group (c01, c16) | starts | starts |
| Setgid roots with ES's own group (c04, c17) | starts | starts |
| Setgid roots with a group ES is a member of (c05, as `ci`, `ci3`) | starts | starts |
| Root-run ES on `0:0` roots at `0755`, the supported-local profile (c14 as root, with and without capabilities) | starts | starts |
| Roots missing, created by ES under plain or own-group parents (c21, c23) | starts | starts |
| File system where every new entry takes its parent's group, as on macOS (`grpid` mount, all cases) | unchanged | unchanged, including foreign-group roots, which pass because staging works there |

### 5.4 Symlinks and races

- `nested` is opened with the helper that refuses symlinks (Linux `openat2` with `RESOLVE_BENEATH`, `NO_SYMLINKS`, `NO_MAGICLINKS`, `NO_XDEV`; Darwin `O_NOFOLLOW_ANY`). `Fchown`, `Fchmod` and `Fstat` act on that descriptor, never on a path.
- The roots are re-observed before each of the three changes (`Mkdirat`, `Fchown`, `Fchmod`), as the guardrail test requires. Removing any one of the three fails that test (mutants B17a to B17c).
- The probe directory has a random name and mode `0750`, so only ES's own UID, the roots' owner or root can write in it.
- Section 6.6 gives the race I ran. One residual window is recorded as A13-P1. It is an older pattern, not introduced here.

### 5.5 Leftovers

After a successful start the staging root holds the probe directory (`0750`, the roots' owner), `nested` inside it (same owner and mode) and the probe symlink. After the new refusal it holds the probe directory and `nested`, which then carries ES's own group. The results root is untouched. Nothing is removed, by the documented no-uncertain-unlink rule, and the docs say that `nested` is retained. No product code or script looks for these names. The `es/app` tests that count entries in the staging root still see 3, because `nested` sits inside the probe directory.

### 5.6 Error message

`nested staging directory ownership is unavailable: operation not permitted` is accurate for the case it was written for, and the runbook names it. A13-5 notes that the same words without the error number can also report other causes.

### 5.7 Docs

The four documents agree with each other and with what I measured. The runbook's sentence that ES refuses roots with another group, whether set directly or inherited, holds for the launcher's identity (primary group, no other groups): cases c02, c03, c05, c06 and c20 as `ci4`. PR #18's three known-gap sentences are gone and the docs contract test forbids them. A13-6 notes one sentence that is true only for Linux's default group rule.

## 6. Validation I ran

### 6.1 The PR's tests, head and base

Identities are described in the evidence README. Base means `f9537a8` plus only the new test file.

| Identity | Head `eb6eea9` | Base `f9537a8` |
| --- | --- | --- |
| `ci` (sudo, extra group) | 5 of 5 pass. The refusal test logs both errors: probe `nested staging directory ownership is unavailable: operation not permitted`, staging `operation not permitted`. | all 3 new tests fail. Refusal test: `startup probe: <nil>; staging a nested directory: operation not permitted`, "disagree". |
| `ci3` (no sudo, extra group) | refusal test skips, others pass | refusal test skips, both accept tests fail |
| `ci4` (no sudo, no extra group) | refusal and extra-group tests skip, others pass | the remaining accept test fails |
| root | same two skips, others pass | the remaining accept test fails |

### 6.2 Static checks and the whole package

On the head as `ci`: `gofmt` clean; `go vet ./es/admission .` exit 0; `go vet` for darwin/arm64 and darwin/amd64 exit 0; both docs contract tests pass; the guardrail test passes.
Whole `es/admission` on the head: 1089 passed, 0 failed, 0 skipped as `ci` (89.5 s); 1088 passed and 1 skipped as `ci3`. The skip is the refusal test.

### 6.3 The PR's own CI

Run 45079434745, job 137384023403, success, on the merge commit with the head's tree. `test gate passed: 41 packages, 3 of them with skipped entries (15 entries); 39 tests skipped themselves, all of them listed`. The 39 are 37 in `es/app` and 2 in `reliablesubmit`. None is in `es/admission`, so the refusal test and the extra-group test ran there. Neither is in `.github/ci/environment-only-tests.txt`, so the gate would fail if one of them skipped.

### 6.4 Ownership matrix

My harness builds a pair of roots, runs the startup probe, then stages the way Submit does (claim a run root, create `payload`, write a file, create `run/platform` and `mounts/a`). It runs on a scratch copy of the base and of the head.

| | Base | Head |
| --- | --- | --- |
| Cases | 340 | 340 |
| Probe passes, staging fails (the A6-3 gap) | 30 | 0 |
| Probe refuses, staging alone would work | 19 | 19 (the same 19, see below) |

- 42 cells differ: 30 gap to refuse, 12 refuse to refuse with the new message (case c08, where the base refused later with a bare `operation not permitted`).
- The 30 are setgid roots whose group ES is not a member of, on three file systems: group 1800 for every identity but full root (c03, c13), and group 1900 for the two identities outside it, `ci4` and root without capabilities (c05).
- The 19 are older refusals by the results-side check (`natural retained result directory creation is unavailable`), for example roots whose group was set directly to one of ES's other groups. They are identical on base and head.
- On the `grpid` file system base and head agree in every cell, and foreign-group roots pass because staging works there.
- A second run added roots that do not exist yet under separate setgid parents (c20 to c23): ES creates them, they inherit the foreign group, and the head refuses (gap on the base).

### 6.5 Real startup

Same cases, base and head. `NewService` ran on the container file system and on `grpid` as all five identities (210 runs per tree). The real binary, built from `eb6eea9` and from `f9537a8`, ran on the container file system as `ci`, `ci4`, root and root without capabilities (84 runs per tree).

| | Base | Head |
| --- | --- | --- |
| `NewService` returns no error | 135 | 119 |
| `NewService` refuses with the new message | 0 | 20 |
| Binary reaches `start app: fetch trust model: unexpected status 404` (probe passed, first network call) | 47 | 34 |
| Binary exits with `build app: validate execution root capabilities: nested staging directory ownership is unavailable: operation not permitted` | 0 | 16 |

Every start that became a refusal is a gap cell in the matrix of section 6.4 or in its second run (c20, c22). The rest of the new-message runs are c08.

The writer's runner logs, which I verified as authentic, show the same on a real bring-up with Nomad and Vault under a setgid workspace owned `1001:1800`. On the PR tree ES exits with that message and creates no run directory. On `trunk_dev` at `3a5f257` ES starts, the bring-up reaches its first execution, and that fails with `stage artifact payload failed`, leaving a run directory owned `1001:1800` whose `payload` is owned `1001:1001`.

### 6.6 Symlink race

A second thread with ES's own UID watches the staging root with inotify, and as soon as `nested` appears replaces it with a symlink to a directory outside the roots (mode `0700`).

| Tree | Rounds | Probe outcomes | Outside directory |
| --- | --- | --- | --- |
| Head | 2000 | 391 pass, 1565 refuse with the new message, 42 `no such file or directory`, 2 `too many levels of symbolic links` | unchanged, mode `0700` |
| Mutant B16 (plain `openat`) | 2000 | 642 pass, 1310 refuse, 48 not found | changed to `0750`. The harness fails, as it should. |

### 6.7 Mutants

33 mutants of the product change, each on a fresh scratch copy of the head, against the three new tests, the two neighbouring probe tests, the guardrail test and the docs test. `mutants-summary.txt` has one line per mutant.

| Identity | Caught | Survive |
| --- | --- | --- |
| `ci` (sudo) | 21 | 12 |
| `ci3` (no sudo) | 15 | 18 |

Caught as `ci`: no call (A1), error ignored by the caller (A2), wrong position (A3, A4), created in the root itself (A5), no `Fchown` (B1), group or target wrong (B3, B5, B19, B24, B25), no `Fchmod` (B11), other name (B13), other text (B14), symlinks followed (B16), a re-observation removed (B17a to B17c), and the three combinations C1 to C3.

Survivors as `ci`, and why none changes an outcome:

| Mutant | Why it survives | Changes start or refuse? |
| --- | --- | --- |
| B2, B6: `Fchown` error ignored or `EPERM` swallowed | the verification still sees the wrong group | No. B2 run on 126 matrix cases: identical in verdict, and in 16 of them the text loses its error number. B6 by the same reasoning. |
| B7, B8, B8g: verification never refuses, or skips UID and GID, or the GID | the `Fchown` error still refuses | No. B7 run on 126 cases: identical in verdict and text. B8 and B8g are weaker forms of B7. |
| B9, B10: verification skips mode or device | `Fchmod` succeeded on the descriptor; the open cannot cross a mount on Linux | No, by reasoning. |
| A7: nested probe only when the staging root has the setgid bit | without that bit the probe directory's own `Fchown` (line 476) already decides | No. Run on 126 cases: identical in verdict and text. |
| B26: `Fchown` error ignored for root only | the verification refuses | No. Run on 126 cases: identical in verdict, and in 6 of them the text loses its error number. |
| B4: `Fchown` leaves the UID alone | differs only when ES's UID is not the roots' UID, which the results-side check refuses | No, by reasoning. |
| B27: `Fchmod` before `Fchown` | `0750` has no bit that a group change clears | No, by reasoning. |
| B15: error number not wrapped | the text is the same | No. |

The writer reported two survivors (P05, P06). They are my B7 and B8. The extra six survivors as `ci3` (A2, A3, A4, B14, C2, C3) all need the refusal test, which skips without sudo.

## 7. Findings

No critical, high, medium or low finding. All of the following are observations.

### 7.1 On the patch

```text
AUDIT FINDING
ID / Type / Severity: A13-1 / test dependency / observation
Current contract or strategic target: tests fail on the base and pin the refusal.
Path and line: es/admission/execution_roots_inherited_group_test.go:28-33
Evidence: the only test that reaches the refusal needs a non-root user, passwordless
  sudo and Linux's default group rule. Without sudo it skips, and six more mutants
  survive (A2, A3, A4, B14, C2, C3; mutants-ci3.log).
Impact: none on the gate today. The test ran on GitHub's runner for this PR, and
  the CI gate fails on a skip that is not listed.
Required correction: none. If anyone later lists this test as skips-itself in
  .github/ci/environment-only-tests.txt, the refusal loses its only pin.
Uncertainty: project notes from PR #14 say that making this gate a required status
  check on trunk_dev was still open. I did not check the branch protection. Until
  it is required, the pin holds through the merge gate reading the CI result.
Patch defect or pre-existing issue: property of the patch's test, not a defect.
```

```text
AUDIT FINDING
ID / Type / Severity: A13-2 / test gap, masked pair / observation
Current contract or strategic target: the probe gives the directory the roots' owner
  and verifies it.
Path and line: es/admission/execution_roots.go:583-584 and 596-603
Evidence: the Fchown error path and the verification each cover for the other, so
  B2, B6, B7, B8 and B8g survive one at a time. Removing both is caught (C1 to C3).
  The writer disclosed two of these (P05, P06).
Impact: none on behaviour. The double check is deliberate and mirrors staging.
Required correction: none.
Uncertainty: a file system that accepts chown without applying it would tell them
  apart. None was tested.
Patch defect or pre-existing issue: neither; test-strength note.
```

```text
AUDIT FINDING
ID / Type / Severity: A13-3 / test gap / observation
Current contract or strategic target: AGENTS.md section 12 and the writer's report:
  the probe is behavioural, with no branching on platform or labels.
Path and line: es/admission/execution_roots.go:488; es/admission/execution_roots_test.go
  (TestExecutionRootCapabilityProbeCoversBothConfiguredRoots)
Evidence: mutant A7 runs the nested probe only when the staging root carries the
  setgid bit, and survives every test. Both accept tests use setgid roots, and the
  older probe test does not look inside the probe directory.
Impact: none on behaviour. A7 gives the same verdict as the head in 126 cases.
Required correction: none. One assertion in the older probe test that the probe
  directory contains "nested" would pin it.
Uncertainty: none for the cases run.
Patch defect or pre-existing issue: neither; test-strength note.
```

```text
AUDIT FINDING
ID / Type / Severity: A13-4 / test gap / observation
Current contract or strategic target: as A13-2.
Path and line: es/admission/execution_roots.go:583-603
Evidence: B4, B9, B10, B15, B26 and B27 survive. No test runs as root without
  CAP_CHOWN or as a privileged ES on roots owned by another UID.
Impact: none on behaviour (section 6.7).
Required correction: none.
Uncertainty: B4, B9, B10 and B27 are judged by reasoning, not by a matrix run.
Patch defect or pre-existing issue: neither; test-strength note.
```

```text
AUDIT FINDING
ID / Type / Severity: A13-5 / message accuracy / observation
Current contract or strategic target: the refusal names its cause.
Path and line: es/admission/execution_roots.go:596-603
Evidence: the text without an error number, "nested staging directory ownership is
  unavailable" (line 602), is also returned when the directory was removed while open, is on
  another device, or has another mode. In the race run it appeared 1565 times for
  a removed directory, not for ownership.
Impact: an operator could be pointed at ownership when something is interfering
  with the roots. Only reachable under interference or on an unusual file system.
  The normal refusal carries the error number and is accurate.
Required correction: none. The older results-side probe uses one text in the same way.
Uncertainty: none.
Patch defect or pre-existing issue: patch, cosmetic.
```

```text
AUDIT FINDING
ID / Type / Severity: A13-6 / docs precision / observation
Current contract or strategic target: docs describe behaviour that holds on every
  supported platform.
Path and line: PLANS.md:781-782; .docs/execution_lifecycle/implementation.md:995-996;
  es/admission/execution_roots.go:562-564 (comment)
Evidence: "so the new directory gets ES's effective GID" is true under Linux's
  default group rule. Where a new entry always takes its parent's group (macOS,
  the BSDs, Linux mounts with grpid), it gets the roots' group, and the probe and
  staging both pass (grpid rows of the matrix).
Impact: none on behaviour. The refusal rule that follows is stated correctly, and
  capability_probing.md words it without the mechanism.
Required correction: none.
Uncertainty: none.
Patch defect or pre-existing issue: patch, wording.
```

### 7.2 Older issues, not caused by the patch

```text
AUDIT FINDING
ID / Type / Severity: A13-P1 / race window / observation
Current contract or strategic target: no TOCTOU or symlink weakness in the probe.
Path and line: es/admission/execution_roots.go:572-583 (new); the same pattern at
  465-476 (probe directory) and in staging_custody.go:551-578 (ensureDirectory,
  which checks only type and device before the change)
Evidence: between Mkdirat and the open there is nothing that ties the opened
  directory to the one just created. Symlinks are refused, and the race run showed
  no effect. A real directory renamed into place would be opened and changed.
Impact: Inference from the code, not run: this matters only when ES can change
  ownership freely (root) and the roots belong to another, unprivileged user. ES
  refuses to start in that setup, but only at a later step of the same probe.
  That user could get a directory it can already move there re-owned to itself.
  The base has the same window on the probe directory, so the patch adds a second
  instance, not a new class. PLANS.md rule R14-ROOT-CUSTODY-01 requires such a
  binding, but only for the supported-local setup helper.
Required correction: none in this PR.
Uncertainty: the directory-swap variant was not run.
Patch defect or pre-existing issue: pre-existing pattern.
```

```text
AUDIT FINDING
ID / Type / Severity: A13-P2 / message accuracy / observation
Current contract or strategic target: the refusal names its cause.
Path and line: es/admission/execution_roots.go:476
Evidence: roots whose group was set directly to a foreign group are refused with
  "validate execution root capabilities: operation not permitted" and nothing else
  (case c02, for example; this bare text ends 14 NewService runs on the head).
Impact: the sibling of the case this PR fixes still has a bare message. The runbook
  and implementation.md do describe it.
Required correction: none in this PR.
Uncertainty: none.
Patch defect or pre-existing issue: pre-existing.
```

No minority findings: there were no subagents.

## 8. Validation assessment

Re-run by me: the PR's tests on head and base as four identities; static checks including two Darwin cross-vets; the whole `es/admission` package as two identities; the ownership matrix; `NewService` and the real binary; the symlink race with a sensitivity check; 33 mutants as two identities; the matrix on four survivors.

Verified from records, not re-run: the PR's CI for all 41 packages on the merge commit; the writer's two runner logs with Nomad and Vault on `d8794de`, fetched again from GitHub and byte-identical.

Not run, and what stands in:

| Not run | Stand-in | Limit |
| --- | --- | --- |
| macOS, natively | the step-by-step equivalence with staging (5.2), two Darwin cross-vets, and the `grpid` file system for the group rule | No Mac was linked to this thread. The supported-local proof script has not run with this change. |
| The Remote Alpha host | the equivalence, and cases c01 and c16 (roots owned by ES's UID and primary group) | Not the host itself. |
| A full bring-up with Nomad and Vault on `eb6eea9` | the writer's runs on `d8794de`, whose product code and tests are byte-identical | One commit earlier. |
| A complete submission under accepted setgid roots (c04, c05) | staging was run; the results side was not | Unchanged by this PR: the probe passes these on base and head alike. |
| `es/app` and the other packages locally | the PR's CI | |
| The directory-swap race of A13-P1 | code reading | Marked as inference. |

Harness mishaps are listed in the evidence README. None affected a result that is reported here.

## 9. Sensitive-material handling

No secret, key, token, environment file or database was read or copied. The evidence folder was scanned for tokens, private keys, e-mail addresses and phone numbers. The only hit is GitHub's own masked `AUTHORIZATION: basic ***` line in the CI log.

## 10. Remaining uncertainty and stop conditions

- The verdict binds `eb6eea9` with base `f9537a8`. Any later commit on the branch sends the work back to audit (provenance §5.4 step 1).
- `trunk_dev` is now at `f62d0245e95e2b411be16511fc1bf9e1da727ce5` (PR #16, `es/admission/internal/reliablesubmit/sqlite_physical_test.go` only). A trial merge with the head is clean (`git merge-tree`, tree `d833e052…`, no ref written). Step 2 of §5.4 applies: update the branch, take a new manifest, and if `git range-diff` shows the patch unchanged the coordinator may accept a provenance-only re-check.
- macOS and the Remote Alpha host rest on the equivalence argument, not on a run.
- The probe runs at startup only (5.1).

No stop condition was met.

## 11. Confidence

| | Level | Why |
| --- | --- | --- |
| Provenance | very high | six manifest runs identical, equal to the writer's; head equals the PR head at start and end; blob-level equality |
| Validation | high | red and green reproduced under four identities, 340-case matrix, real binary, CI record checked; macOS and the alpha host not run |
| Implementation | high | about 40 lines that replay existing staging code; no outcome-changing mutant survives; one inferred older race window |

## 12. Effect status

Repair: not performed. Commit: none. Push: none. PR: not opened, edited or commented. Merge: not performed. No live service was contacted. The only GitHub calls were reads (PR, checks, job logs, refs).

## 13. Report delivery

This file: `/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/13-audit-pr20.md`. Its SHA-256 is given in the thread reply that attaches it, because a file cannot contain its own hash.
Evidence: `/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/13-audit-pr20-evidence/`, 57 files.

## 14. Final verdict

**ACCEPT** for `eb6eea90b0e694ffa2e7ab62f64f6d7d6f0936c3` (base `f9537a8`, tree `778e0082…`, manifest `e46eec89…9a31`).
