# ES PR #29: narrow audit 10, e548b07 → 06e84e5 (red-team fixes, trunk_dev sync, guard walk)

| | |
|---|---|
| Audited heads | `91dbad69d6111a5bc57b71df5e3331d665d855a2` (tree `d87d39a0…`, first pass). Then `06e84e517964360698052f39ed757b74c83d939a` (tree `7ba2f726acef1ae90fe82f9f44012460f89cd62b`), the head this verdict is for |
| Base | trunk_dev `76c030f` (now holds PR #27) |
| Writer's reports | `09-repair.md` (91dbad6) and `11-repair.md` (06e84e5). The red-team report is `08-redteam.md`, including Addendum A |
| Previous audit | `08-audit.md` (delta check, ACCEPT on `e548b07`) |
| Auditor | independent auditor thread (not the writer), read-only, no repo writes |
| Window | 2026-11-23 20:24Z to 21:16Z |
| Evidence | `10-audit-evidence/` (SHA256SUMS inside) |

## Verdict

**ACCEPT on `06e84e5`. No findings are open.**

- **RT8-1:** the redirect fix is correct and complete for ES's ARS and EGS clients. Every caller accepts only `200` and closes the body, so a returned `3xx` is refused everywhere. The test kills every redirect-policy variant I tried.
- **RT8-2 and RT8-3:** the guard now covers every repository package that `cmd/es` links on darwin/arm64, linux/amd64 and linux/arm64.
- **A10-1 (Low), closed in `06e84e5`.** On `91dbad6` I found that the guard did not list linux/arm64. The red-team's re-check found the same gap independently, as part of RT8-3. I re-ran my mutant for it on `06e84e5`, and it is now killed.
- **No lost coverage:** the trunk_dev merge is clean, and no test that passed before fails now.

## 1. Commits and manifests (`commits/`, `provenance/`)

- **`14572f1`** merges trunk_dev `76c030f` (PR #27). Its tree `721bd01f…` equals `git merge-tree e548b07 76c030f`. PR #27 shares three paths with PR 29: `contracts.md`, `boundaries.md` and `PLANS.md`. PR 29's changed lines in each are identical on both bases.
- **`91dbad6`** changes 5 paths. The `service.go` change is line-for-line the red-team's `both-fixes.diff`.
- **`06e84e5`** changes 1 path, `es/admission/ars_blob_fetch_test.go`. I applied the red-team's `recheck-91dbad6/proposed-fix/guard-walk-hardening.diff` (sha256 `22c5f116…`) to `91dbad6`. The result differs from `06e84e5` only by the writer's 8-line `filepath.EvalSymlinks(esRoot)` addition.
- **Manifests.** Tip bytes were placed on HEAD `76c030f`, and the recipe hash was checked before each run.
  - `91dbad6`: two opening runs and the closing run all give `dab632ae…b19a`, 29 paths.
  - `06e84e5`: two opening runs and the closing run all give `5e3590e2b1d3bec27c8816c8d5cd3b1dd334dbdf7f95f7525179f33b14130043`, 29 paths. The textual diff is `a8d50652…f30c`, unchanged, because the changed file is one the PR adds.
  - Both of my `1.json` files are byte-identical to the writer's.

## 2. RT8-1 review (redirects)

- `newDependencyClient` (`service.go:807-852`, `CheckRedirect` at :847) is the only constructor for ES's ARS and EGS clients (`service.go:191`, `:195`). The only other `http.Client` in `es/`, `internal/` and `cmd/` is the Nomad client in `submit.go:235`. That one is O8-3, which belongs with PR #31.
- All four callers check `StatusCode` against `200` after `defer response.Body.Close()`:
  - the trust model, `service.go:289-297`;
  - the discovery read, `:466-476`;
  - the health check, `:867-874`;
  - the verified blob read, `ars_blob_fetch.go:76-86`.
- The test builds both clients with the production constructor over mTLS. It covers a cross-origin `302` to plain HTTP and a same-origin `307`. It checks that neither target is reached, and it checks the verified read's `302` mapping and the discovery read's refusal.
- The new 5A bullet matches the code, and it is pinned.

## 3. Guard review (RT8-2, RT8-3)

**What the guard does on `06e84e5`:**

- It runs `go list -deps ./cmd/es` with the local toolchain and the hermetic `productionGoListEnvironment` (`CGO_ENABLED=0`, `GOPROXY=off`, `GOENV=off`, no `GIT_*`). It does this for darwin/arm64, linux/amd64 and linux/arm64, the same three targets as `loadTypedProductionPackages`.
- It keeps every non-standard package whose directory is inside the repository. It refuses a main-module package, or a module replaced with a directory, that lies outside the repository.
- It inspects every non-test `.go` file in each kept directory, whatever its build tags, once per resolved path, with the same rules as the `es/` walk.

**Why that covers the earlier gaps:**

- The listing now includes directories under `es/` that the source walk skips (`_x`, `.x`, `testdata`), nested modules replaced in `go.mod`, and linux/arm64-only links.
- It fails closed in four cases: if `go list` fails, if a line is malformed, if fewer than 5 outside packages are found, or if a directory can't be read.
- The new self-test runs the listing on a small module shaped like this repository. It requires each of those cases, and it requires the refusal of an outside replacement.

**The symlink fix.** `go list` reports resolved directories, so the ES root is now resolved too. I checked both heads from a symlinked path, as user ci:

- On `91dbad6` the guard fails closed from a symlinked checkout: every label became `../../tip5/…`.
- On `06e84e5` the guard and the self-test pass from the same kind of path (`tests/symlink-checkout-*.txt`).

So the fix removes a false failure and opens nothing.

**ES's build contract.** It is `CGO_ENABLED=0` with no custom tags. Every production ES build sets this: the generated Dockerfile (`generate_control_plane_dockerfile.sh:48`) and `remote_alpha_deploy_es_binaries.sh:592` and `:1106`. The control-plane image is built for the host architecture (`control_plane.sh:37-55`), which is linux/arm64 on Apple Silicon.

## 4. Finding A10-1 (Low, guard gap): closed in 06e84e5

- **The gap.** On `91dbad6`, `esBinaryModulePackageDirsOutside` (`ars_blob_fetch_test.go:1031`) listed only linux/amd64 and darwin/arm64.
- **Mutant G5.** Put the G1b read in a new `internal/blobcache` package, imported only by an `es/admission` file tagged `//go:build linux && arm64`.
  - The linux/arm64 ES binary builds with it.
  - On `91dbad6`, the whole es/admission package passes, so G5 **survives**.
  - On `06e84e5`, G5 is **killed** by the guard (`mutants/91dbad6/`, `mutants/06e84e5/`).
- My own fix (`proposed-fix/a10-1-guard-targets.diff`, tested on `91dbad6`) is superseded by RT8-3's broader change. It is kept only as a record.
- **What I missed.** RT8-3's other cases were not in my `91dbad6` review: directories under `es/` that the source walk skips, and nested replaced modules. The red-team found them first.

## 5. Results

| Check | `91dbad6` | `06e84e5` |
|---|---|---|
| build, vet, cross-vet | ok (darwin/arm64) | ok (darwin/arm64 and linux/arm64; gofmt clean) |
| es/admission `-v` (user ci) | 1,297 pass, 4 skip. 0 lost against `e548b07` | 1,300 pass, 4 skip. 0 lost against `91dbad6`. New: the self-test (+2 subtests) |
| es/admission `-race` | ok, 0 races | ok, 0 races |
| Root package against trunk_dev `76c030f` | 38 container-only failures, identical names. 0 lost. +3 ARS docs tests | ARS and binding docs tests pass. The change touches no root file |
| es/app, internal/..., ars/... against trunk_dev | 1,075 pass and 84 skip on both, 0 lost | not re-run (the delta is one es/admission test file) |
| Guard from a symlinked checkout | fails closed (false failure) | passes |
| Audit 06's 36 code mutants | 36 of 36 killed | 36 of 36 killed |
| Writer's 09 set (8) | 8 of 8 killed | 8 of 8 killed |
| Writer's 11 set (14, `mutants_10.py`) | not applicable | 14 of 14 killed (C1, G3-G9, M1-M5) |
| Mine: R5 (only EGS refuses redirects), R6 (only ARS refuses) | both killed | both killed |
| Mine: G5 (linux/arm64-only link) | **survives** (A10-1) | killed |
| Mine: G6 (link only under `//go:build cgo`) | survives | survives. This is not a finding: production builds use `CGO_ENABLED=0` (§3) |
| PR 12 line (`4416699`) | Merged with `91dbad6`, it conflicts in `PLANS.md`. trunk_dev `76c030f` alone gives the same conflict, so it comes from PR #27. Merged with `e548b07`, it is clean | same, because the delta does not touch `PLANS.md` |
| CI | run 45258642043: cancelled at 20:45Z by the next push, after its Test step had succeeded | run 45262533615 succeeded at 21:13:16Z. Build, both vets, the test gate and the Test step all succeeded, and the list check reports that all 16 listed tests still fail |

## 6. Non-claims and limits

- **What the guard cannot see.** It stays syntactic, as `09-repair.md` §6 and `11-repair.md` §5 say:
  - reflection, `unsafe`, linkname and assembly;
  - direct `ars/store` reads (that package re-hashes on read);
  - a package linked only under a custom build tag or under cgo. Neither is part of ES's build contract.
- **Not run here.** The red-team's live-stack redirect probe was not re-run by me. No box run.
