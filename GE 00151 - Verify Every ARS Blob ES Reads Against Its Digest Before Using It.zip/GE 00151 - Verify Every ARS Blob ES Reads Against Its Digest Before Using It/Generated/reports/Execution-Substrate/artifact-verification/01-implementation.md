# ES verifies every ARS blob it reads: implementation report

Date: 2026-11-23. Writer thread for David's request of 15:04Z ("please also make ES verify"). Repository `evo-agi/Execution-Substrate`.

| Item | Value |
| --- | --- |
| Draft PR | [#29](https://github.com/evo-agi/Execution-Substrate/pull/29) into `trunk_dev` |
| Topic branch | `claude/project-thread-urwhl2` |
| Base | `trunk_dev` `036d50724b499b020c5149c55ad902cfcb1482c0` (PR #25). Work started on `792f17c`; PR #25 changes no file of this patch |
| Topic commit | `f8c1a73b5a14b99a40e9c54910a76e14d30e5312` (one commit) |
| Tree | `6b72ef78ba077c0f7a396227f69c12d3c9c7d3d8` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (checked before the run) |
| Textual diff SHA-256 | `c900bbff00cf1ac8ce10fa118eef0d918cbc630ccf41a574118f86111a370072` |
| Canonical manifest SHA-256 | `32310cac508a305413825bf6f240d299c411e5ff5425920ec3ff52fb39b5fe7c` |
| Files | 22 (3 new, 19 modified), all mode 0644 |
| CI | run [45211410865](https://github.com/evo-agi/Execution-Substrate/actions/runs/45211410865) "build, vet and test" **green** on `f8c1a73` (15:59Z-16:28Z); PR mergeable (clean) |

Evidence is in `01-evidence/` next to this file. The manifest JSON is `01-evidence/manifest/manifest-1.json` (section 9 lists its paths).

---

## 1. Plain-language summary for David

ES fetches five kinds of file from the artifact registry (ARS) by their fingerprint (SHA-256 digest): the signed evidence, the Vault settings, the program itself (which the safety policy also inspects) and any mounted files. Until now ES trusted ARS to send the right bytes and never checked the fingerprint itself.

Now ES checks every one of those reads. It computes the fingerprint of exactly the bytes it received and uses those bytes only if the fingerprint matches. If it does not match, the request is refused before anything happens: no run, no files written, nothing sent to Nomad.

The new tests, run against today's `trunk_dev`, show what was possible before: ES happily submitted runs with a swapped program, swapped mount files, and even different Vault settings that point the workload at another Vault server. On the new code all of those are refused.

To your question: the Python version was designed to have the bytes checked (by Nomad, not ES), but probably never really did (details in my 15:10Z reply), and the Go rewrite dropped the check entirely in its first submit commit. So this restores, properly, a protection that was intended and lost.

What I need from you: nothing yet. It merges cleanly with the PR 12/13 work and needs no change there (section 7). Next come an independent audit and a red-team; after that it comes to you for review, since it is product code.

---

## 2. Step 1 finding (posted 15:10Z, unchanged)

- **Python POC** (`/mnt/project-files/Execution Substrate POC - Snapshot.zip`, SHA-256 `50836e20b398c36da0b9cbba4cf35424dca3f4f595745fe0cb091d0b44ccd55b`, repo `Monolith` at `cbbac0e68945ca07514d0b23b8822561b8d787d6`, nothing executed): ES never fetched program or mount bytes itself. It gave Nomad an artifact URL and `options={"checksum": <signed digest>}` (`services/execution/intent/NomadJobSpecFactory.py:301-340`, applied at `:190-200`; `ExecutionServer.py:787-795`, `:2059-2081`). **Inference:** the job JSON used `source`/`options` (`NomadJobSpecFactory.py:1676-1685`) while Nomad's JSON API names the fields `GetterSource`/`GetterOptions` (Nomad v1.9.7 `api/tasks.go:860-868`), so the checksum probably never reached Nomad. The Vault blob was never checked (`ExecutionServer.py:2027-2035`); `ArtifactRegistryClient.get_blob_bytes(verify=False)` (`:454-505`) had no ES caller.
- **Go rewrite**: the first Go submit commit `a771825` (2026-04-01) read `/v1/blobs/{digest}:bytes` with no hash (`es/admission/submit.go:181-220` at that commit). At `792f17c`, none of the five reads hashed what it received.

---

## 3. What changed

### 3.1 Code (4 production files)

- **New `es/admission/ars_blob_fetch.go`**: `fetchVerifiedARSBlob(ctx, digest, view, limit)` is ES's only read of `GET /v1/blobs/{digest}{:bytes|:json}`.
  1. Refuses a digest that does not match `^sha256:[0-9a-f]{64}$` before any request. The string requested is the string verified; it is never trimmed.
  2. Answers other than 200 are classified (404, other status) without reading bytes.
  3. Reads the body with the existing `readBoundedResponseBody(response, limit)` into one buffer.
  4. Returns the buffer only when `digestBytes(buffer) == digest`; otherwise drops it.
  It returns a private failure class; each caller maps it onto its own existing public error.
- `submit.go` `fetchPayloadBytesWithin` (primary payload and governed mounts), `policy_payload.go` `fetchAdmissionPolicyPayloadBytes`, `service.go` `fetchArtifactEvidenceBlob` and `fetchWorkloadZoneVaultConfig` now call the helper. JSON reads decode the verified buffer with the same strict `decodeJSON` as before (`decodeBoundedJSONResponse` was exactly bounded read + `decodeJSON`).
- The verified buffer is the copy that is used: Submit still stages the policy read's buffer as the primary payload when the policy fetched it (`resolved_execution_plan.go:479-487`, unchanged), and mount bytes go straight from the helper to archive validation and staging.

### 3.2 Public mapping (status and code unchanged; only the mismatch message is new)

| Read | HTTP / code | Message on digest mismatch |
| --- | --- | --- |
| Evidence | 503 `artifact_evidence_unavailable` | `artifact evidence blob does not match its discovery digest` |
| Vault config | 503 `workload_zone_vault_unavailable` | `artifact registry workload-zone vault blob does not match its configured digest` |
| Policy payload | 403 `admission_policy_input_unavailable` | existing fixed message |
| Primary / mount payload | 503 `payload_unavailable` | `artifact payload bytes do not match the signed payload digest` |

No message carries a digest, a byte count or received bytes. The mount path keeps its size-limit mapping (the bound error is still the acquisition cause on an over-limit read; a mismatch carries `errARSBlobDigestMismatch`, which is not a bound error).

### 3.3 Contract and docs (doc-first rule of AGENTS.md §7)

- `.docs/execution_lifecycle/contracts.md`: new **section 5A, ARS blob byte verification contract** (`Current invariant`): covered reads with digest sources, rules, public mapping, and what is outside (staged files after the freeze point stay under staging custody; runtime-support binary; profile image). Plus one `:prepare` bullet and the Submit bullet.
- `implementation.md` (steps 3, 6, 8, submit step 6, mount bullet), `artifact_publication_storage.md` (new bullet, payload row, 4D step 7), `runtime_config_ownership.md`, and `PLANS.md:940`, which said "ARS remains their integrity authority".

### 3.4 Tests

- **New `es/admission/ars_blob_fetch_test.go`** (14 tests):
  - Helper: exact bytes accepted; flipped bit, extra byte, short, empty and another blob refused, for both views, one request each; the empty blob only under the empty digest; 15 non-canonical digests (empty, short, long, uppercase, other algorithms, spaces, newline, tab, path tricks, non-hex) refused with **zero** requests; 404, 500 and 206 with the right bytes, and an over-limit body, classified without bytes.
  - Public mapping at each of the five call sites, including that no message leaks the digest or the bytes.
  - End to end, each with a positive control on the same fixture: Submit with a substituted or extended primary payload (payload-blind policy, so Submit makes the read); Prepare and Submit with a substituted policy payload; Submit with substituted mount bytes and with re-encoded mount evidence; Prepare and Submit with re-encoded evidence, a different valid Vault config and a re-encoded Vault config. Each refusal checks status, code, message, no Nomad call, empty staging and results roots, and (for the dependency blobs) no payload read. Positive controls check the staged payload or mount file equals the signed bytes, and that the policy read is the only payload read.
  - **Guard** `TestFetchVerifiedARSBlobIsTheOnlyARSBlobReadInES`: parses every non-test Go file under `es/` (all build tags) and requires (a) exactly one string literal containing `blobs`, `"/v1/blobs/"` in `fetchVerifiedARSBlob`, and (b) the `arsClient` field used only in `fetchVerifiedARSBlob`, `fetchArtifactDiscoveryRecord` and `Health`.
  - `TestPrivateReplayClaimRendezvousReportsAWorkerThatReturnsEarly` (helper test, in `reliable_submit_replay_private_test.go`).
- **New root `ars_blob_verification_docs_contract_test.go`** (3 tests): section 5A exists once and sits directly before section 6; its rules and five covered reads are pinned; the mismatch messages are read from `ars_blob_fetch.go` with `go/parser` and must appear in the 5A mapping rows; the statements in the four other docs are pinned and "ARS remains their integrity authority" must be gone.
- **Fixtures made digest-true** (the old fixtures signed made-up digests such as `labeledDigest("11")`, so verification refused them):
  - `artifact_prepare_test.go`: `newPreparedArtifactFixture` now reseals so the discovery record names the digest of the evidence document that `writeJSONResponse` actually serves; new `withPayload(t, payload)` re-derives the identity from the served payload's digest and reseals with the same key.
  - `authorityhandoff_test.go`: `testWorkloadZoneVaultConfigDigest` is now `digestBytes(validWorkloadZoneVaultConfigBlob)` = `sha256:5b095c7783ea05fa76caada31d6d2cb1206319b8e25df18da447e455a98c0ff4` (four golden literals follow).
  - `withPayload` added before the request is built in tests that serve a payload (policy_admission, policy, submit, resolved_execution_plan, workstream_b, workstream_c). Tests that already called `a2BindSignedPayload` are unchanged.
  - The two literal Nomad goldens change only `EXEC_ARTIFACT_DIGEST` and `artifact_digest` (artifact digest now derived from the real payload).
  - Two Vault tests that serve another Vault blob now configure that blob's digest.
  - `reliable_submit_binding_test.go` "A A Q byte mismatch": the resolver itself now refuses the mismatched mount bytes (503 mismatch message, no run material) instead of the later binding.
- **Bounded replay test** (coordinator item 2): `TestPrivateReplayConcurrentWinnerClassification` waited on `<-arrived` twice with no bound, so a worker that failed before the claim hook hung the package until its timeout. A `privateReplayClaimRendezvous` helper now waits for arrival, early return or an 8 s bound (the file's existing bound), always releases the hook, bounds the wait for workers, and lets the caller report each worker's own error first.

---

## 4. Validation

Linux container, Go 1.26.5, root user, `umask 0022`. This container has no Nomad, Vault, SPIRE, ssh, uuidgen or `en_US.UTF-8` locale, so the root package, `es/app` and two `reliablesubmit` probe tests fail for environment reasons on base and branch alike. I compared failing sets instead of expecting green.

| Check | Result |
| --- | --- |
| `go build ./...`, `go vet ./...`, `GOOS=darwin GOARCH=arm64 go vet ./...`, `gofmt -l` on changed files | clean (at `036d507` + patch) |
| `go test ./es/admission/` | ok (36-47 s), several runs, last after the final edit |
| `go test ./...` at `792f17c` + patch vs base `792f17c` | 19 packages ok; 3 packages fail (root, `reliablesubmit`, `es/app`) with **identical** failing sets, 254 entries each (`suite/base-fails.txt`, `suite/branch-fails.txt`) |
| At `036d507`: root package + `es/admission/...` on branch vs root package on base | `es/admission` ok; root failing sets identical (242); `reliablesubmit` fails only its two listed probe tests (`TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation`, `TestSQLiteV3OldBinaryRefusesWithoutMutation`, both in `.github/ci/environment-only-tests.txt`) |
| Race: `go test -race` on every new test plus the binding, replay, policy, workstream B, tranche B, resolved-execution and submit families | ok, 57.7 s, no race report |
| Docs contract tests (root) | 3 of 3 pass |

The CI gate with Nomad/Vault/SPIRE (`es/app` integration, the environment-only list and the gate self-test) ran on GitHub: run 45211410865 is green on `f8c1a73`. Nothing ran on macOS.

### 4.1 The new tests fail on the old code

I ran the four end-to-end tests and the binding test against the **old production code** (`792f17c`; ES production code is identical at `036d507`), with the new fixtures and a test-only shim that defines the three new message constants (`old-code-run/`). Every positive control passed; every substitution case failed:

| Case | Old code |
| --- | --- |
| Substituted / extended primary payload | accepted (expected 503) |
| Substituted policy payload, Prepare and Submit | admitted (policy inspected the substituted bytes) |
| Substituted mount bytes; re-encoded mount evidence | accepted |
| Re-encoded evidence, Submit | **submitted a run** (`run-e25a70acc6548e1f`) |
| Different valid Vault config (address `vault.substituted.invalid`), Submit | **submitted a run** (`run-ac08557c1c319c8f`) |
| Re-encoded Vault config, Submit | **submitted a run** |
| Binding test "A A Q byte mismatch" | resolver accepted the mismatched mount bytes |

13 failing subtests in total; log `old-code-run/oldcode-e2e.log`. The helper unit tests and the guard need the new code to compile, so they are covered by mutants instead.

### 4.2 Mutants: 18 of 18 caught

`mutants/results.txt`; each mutant applied alone, targeted test set, file restored after. M1-M17 ran on the production bytes that were committed (the test file later gained the guard's client-use check, which only adds checks); M18-M19 ran on the final tree.

| ID | Mutation | Caught by |
| --- | --- | --- |
| M1 | drop the digest comparison (old behavior) | helper, mapping, all end-to-end tests, binding test |
| M2 | skip the canonical-digest check | non-canonical test (zero requests) |
| M3 | return the mismatched bytes with the error | helper test |
| M4 / M5 | verify only `:json` / only `:bytes` | helper and end-to-end tests |
| M6 | accept 206 as success | transport-classification test |
| M7 | accept an empty body under any digest | helper and empty-blob tests |
| M8 | hash all but an odd last byte | helper and end-to-end tests |
| M9 / M10 / M11 | evidence / Vault / payload mismatch falls back to the generic message | mapping and end-to-end tests |
| M12 | payload mismatch drops its acquisition cause | mapping test |
| M13 | policy read ignores a mismatch | mapping test (the end-to-end result is the same fixed 403 because the policy then has no bytes) |
| M14 | evidence read bypasses the helper | mapping, end-to-end, guard |
| M15 | Submit re-reads the payload instead of using the verified policy buffer | policy end-to-end test (read count), binding test |
| M17 | rendezvous ignores a worker that returned early | rendezvous helper test |
| M18 | new ARS read built from split literals in a new function | guard (client use) |
| M19 | `"/v1/blobs/"` literal in `es/app` | guard (literal) |

M16 (request a normalized digest) was dropped: it is only reachable together with M2, which is caught.

### 4.3 The replay test now fails bounded

With the fixture made to serve one wrong byte (`bounded-replay-test/`): the old test body **hung until the 30 s package timeout** (`panic: test timed out after 30s`, stuck in `same_facts_positive_control`); the new body **failed in 0.06 s** with the worker's own error, `concurrent admission: private replay: unavailable`.

---

## 5. Provenance

Taken as in `provenance-and-audit-evidence.md` §5.2: HEAD at base `036d507`, topic bytes in the working tree, nothing staged, branch checked out under its name, upstream pinned to `origin/trunk_dev` immediately before. Two runs to absent paths in a fresh 0700 directory: byte-identical. `git add -A`; staged path set equals the manifest path set (22). One commit; `git status --porcelain` empty afterwards. Every committed blob hashes to its manifest entry and is mode 100644 (checked with `git show f8c1a73:<path> | sha256`).

---

## 6. Remaining seams and non-claims

- Staged files are not re-hashed after the freeze point; staging custody protects them (contract 5A, "Outside this contract").
- The discovery record itself is not content-addressed; it is bound through the signed evidence (artifact digest, payload digest, type and intent cross-checks, unchanged).
- The verification is of ARS bytes against digests ES already trusts. It does not change who signs evidence or which signers ES trusts (and ES still reads EGS trust only at startup, the open finding of 2026-11-22).
- The guard is a merge guard against honest new reads, not proof against an adversarial author: a route assembled at runtime from non-literal parts outside `arsClient` would evade it. Review still applies.
- Not run: macOS. CI (Linux, with Nomad/Vault/SPIRE) is green.

---

## 7. Change list for the PR 12 writer (coordinator item 1)

PR #13 merged into PR #12's branch as `6288b63`; the trunk_dev merge is draft PR #28 (`claude/project-thread-ne9cwa-pr12-trunk-dev`, head `2c8bf35`). I trial-merged this patch into that head.

**Result: PR #28 needs no change for this patch.**

| Check | Result |
| --- | --- |
| `git merge --no-ff f8c1a73` into `2c8bf35` | clean, no conflict; merge `627cd0d`, tree `29bae96436063735d69b81fe466a1c9ce2d48cfb` |
| ARS blob reads added by PR 12/13 | **none**. At `e060449`, `8058561` (PR #12 head before #13) and `2c8bf35` the only `/v1/blobs/` reads are the same four call sites that this patch moves onto the helper; PR 12/13's operational admission and handoff code does not use `arsClient`. In the merged tree `"/v1/blobs/"` appears once, in `fetchVerifiedARSBlob`, and the guard passes |
| `go build ./...`, `go vet ./...`, `GOOS=darwin GOARCH=arm64 go vet ./...` on the merge | clean |
| `go test ./internal/testtmpdir/ ./es/admission/... .` on the merge vs on `2c8bf35` alone | `es/admission` ok on both (345 s / 385 s); `admissionstate` ok; `reliablesubmit` fails only its three probe tests on both (`TestOperationalHandoffSchema4BinaryRefusesSchema5` and the two `TestSQLite…` probes, all on PR #28's CI list); root package fails the same environment set. Failing sets are **identical**, 245 entries each (`trial-merges/`) |

So PR 12/13's new tests already pass with digest-true fixtures: they serve payloads through `a2BindSignedPayload` or do not serve payloads. Nothing in PR #28's merge plan (56 paths, the two `docs_contract_test.go` blocks, the follow-up patch) changes.

**What the PR 12 writer should know for later edits** (no action needed now):

1. Whichever of PR #29 and PR #12 lands second merges cleanly as of these heads; re-run `TestFetchVerifiedARSBlobIsTheOnlyARSBlobReadInES` after that merge.
2. A new PR 12 test that serves ARS bytes must serve digest-true bytes: call `fixture = fixture.withPayload(t, payload)` (or `a2BindSignedPayload`) before `fixture.prepareRequest()`; a test that serves another Vault blob must set `service.cfg.RuntimeConfig.WorkloadZoneVaultConfigRef.Digest` and `service.workloadZoneVaultConfigRef` to that blob's digest.
3. A new ES read of an ARS blob must go through `fetchVerifiedARSBlob`; the guard fails otherwise.
4. If PR #29 lands on `trunk_dev` first, PR #12's trunk-relative path count does not change (PR #29's paths are `trunk_dev`'s then), but its manifest must be taken again on the new merge.

---

## 8. Other open branches

| Branch | Base | Touches ES ARS reads or fixtures that serve ARS bytes? | Trial |
| --- | --- | --- | --- |
| PR #26 (`claude/project-thread-ne9cwa`, Workstream A allow rule, head `0aba38e`) | `036d507` | `workstream_a_guardrails_test.go` only | merged cleanly (`909507f`, tree `34837faf…`); `go test ./es/admission/` ok (46 s) |
| `claude/project-thread-i9yve2` (CGS principals) | `792f17c` | no | not needed |
| `claude/project-thread-k69qcw-child-containment` | `110d377` | no | not needed |
| `claude/project-thread-0tw2qq` (CI red-team) | `ae326b0` | no | not needed |
| `claude/project-thread-suv0zx` (red-team regression proposal) | `f9537a8` | edits `workstream_c_guardrails_test.go` | not trial-merged (old base); if it continues, its tests must follow item 2 of section 7 |
| `claude/project-thread-uijb9o` | `ae326b0` | reliable-submit tests (older PR 12 line) | not trial-merged; superseded by PR #28 as far as I can tell (Guess) |

No branch adds an ARS blob read: each has the same four reads (and nine `arsClient` lines) as `trunk_dev`.

---

## 9. Manifest paths

```
path  mode  size  sha256
.docs/execution_lifecycle/contracts.md  0644  134755  9c1d491b2268f8960d4a7551a9a55a330b32d1217d1ef51e8a38effd7bbeb2bf
.docs/execution_lifecycle/implementation.md  0644  94166  6886f7867de5a43b315a7d16b20897ff0670bebb2aefce531a278991601d4357
.docs/system_overview/artifact_publication_storage.md  0644  18937  afe872049e620f489d9e4691da2554b64b74571392b2418a7a3f50f6144099c0
.docs/system_overview/runtime_config_ownership.md  0644  11801  0ebd0b6a788e013ea6657a2ba11b79d4a7b84a27dfeca32c4db10a54f909c746
PLANS.md  0644  314763  a34d0fb2e3913d5b38af520e0597f12108ff1aa63a5fdd33c6c934c30c318639
ars_blob_verification_docs_contract_test.go  0644  8494  eb4ea39aeddb39e3a30352e62969c6b9d0ed5879b310272a33a009a6ad41f08d
es/admission/ars_blob_fetch.go  0644  4009  d4fab4f4e8d4f469114d6ac437450825250aeda9890840f0f855bc84771e960c
es/admission/ars_blob_fetch_test.go  0644  27014  a2e2190ef06c0626a2de9baa4972de11f71809e9350c1766a06b3722ec32630f
es/admission/artifact_prepare_test.go  0644  13683  6a5e47ee8456cf8c6c7b95244136ba96a2de74ac235831eb83113f16f16a64a6
es/admission/authorityhandoff_test.go  0644  6020  dc40e664320b649ead7d7f5d50cd79a2a0c10ddbb978fbe49e75674ae2bcd79a
es/admission/policy_admission_test.go  0644  17352  a79605b391c6c47b8fd482a2a6e02aa0fd131df15da9ce013b3f2c618e6453c9
es/admission/policy_payload.go  0644  5216  682b0fb3322e53340911fa54a883563bffe629676d44ed01d067f1b90380d241
es/admission/policy_test.go  0644  15439  31df4b76ee89797aa677a12e7e2b45b6f0deae4f1cb8b61e317ffd3fbe0348cc
es/admission/reliable_submit_binding_test.go  0644  58939  5529fb6cff6b362a194fff9021ab7efbc4af09461c8d1d74a540c4cc2d311be7
es/admission/reliable_submit_replay_private_test.go  0644  48412  8fcc62a4c8753a027f351f6418cb7e1c9c557ea47314dcf78c9d52cbb2bc96b1
es/admission/resolved_execution_plan_test.go  0644  124369  011a2fdc98c0bde98437f843d9ac59c8313f8909040a6ab2edf20e67d88520b1
es/admission/service.go  0644  33853  e4737a64f452cc843a4f2ab9cda721645cc01e260ee86275493bfe94cfd25b14
es/admission/service_direct_test.go  0644  37823  da10a7216021c3030f48f1f8a7ae6e38a5e38626f8c7243ccbcb40f17fc75d9b
es/admission/submit.go  0644  9560  c6ad3ead85d237192add91f31005da8b10b07a8e9f4f2bed0a9246685f8f9089
es/admission/submit_test.go  0644  33170  675e4125df4387c7392aac94c29af4c300a795b4631d62b92a6fbabd61b959ec
es/admission/workstream_b_guardrails_test.go  0644  5320  ae1a675d693c03c3bacc2099fc785bfcd1af68d156c5ce132ccd70ee8f9de3b9
es/admission/workstream_c_guardrails_test.go  0644  301067  ce1cb434437095f1f15866b8019289bed78372cf1ee829fab20cfdb69bc13de8
```
