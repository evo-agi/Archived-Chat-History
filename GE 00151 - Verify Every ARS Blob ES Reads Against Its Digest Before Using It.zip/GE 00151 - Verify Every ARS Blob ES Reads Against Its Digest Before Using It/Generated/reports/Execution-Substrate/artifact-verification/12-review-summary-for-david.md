# PR #29 review summary (about 5 minutes)

**What it does, in one sentence:** ES now checks the fingerprint of every file it fetches from the artifact registry (ARS) before using it, so a broken or hostile registry can no longer make ES run something other than what was signed.

Code is cited as `path:line` at trunk_dev `76c030f`, unless it is marked "head", meaning the PR head `06e84e5`.

## 1. Your question: does the design let services go straight to ARS?

**Writes: no. AGS stands in front of ARS on the way in.**

- Only AGS can put files into ARS or register an artifact.
- ARS checks this itself. Uploads and registrations require the AGS identity `service/artifact-governance` (`ars/api/server.go:23`, `:69`, `:137`, `:557`).
- AGS is where publication is decided. It checks the caller, builds the evidence record and signs it (`.docs/system_overview/boundaries.md:383`, `:439`).

**Reads: yes, ES reads directly from ARS, and this is the documented design.**

- The boundary doc says so in several places:
  - "ES reads blobs and artifact evidence/records through ARS" (`boundaries.md:384`).
  - "ES does not call AGS on the runtime path" (`boundaries.md:442`).
  - Other readers are allowed only if ARS's configuration lists them (`boundaries.md:387`; `configuration.md:136`).
- The Python POC did the same:
  - Its execution service had its own registry client (`Monolith/services/execution/ExecutionServer.py:218`).
  - Its registry listed `service/execution` as an allowed reader (`Monolith/services/registry/ArtifactRegistryServer.py:62-68`).
  - Its docs say "AGS is the sole writer to ARS" (`Monolith/.docs/integration/ags_ars_integration.md:43`). That is about writing, not reading.

**Who calls ARS today:**

| Caller | What it does with ARS | Where |
| --- | --- | --- |
| AGS | Uploads files, registers artifacts, checks ARS health | `ags/publish/service.go:66`, `:381`, `:401` |
| ES (admission) | Reads the artifact's discovery record, then up to five kinds of file: the evidence, the program, its mounts, the admission-policy input and the Vault settings. Also checks ARS health | `es/admission/service.go:466`, `:514`, `:663`; `policy_payload.go:78`; `submit.go:130`; health `service.go:336` |
| Operator scripts | The bring-up check reads the Vault settings file with the operator certificate | `scripts/internal/bringup.sh:717` |
| Workers and agents | Nothing. ES stages the bytes, and runs never talk to ARS | — |

ARS's example reader list is `service/execution`, `service/artifact-governance` and `operator/local` (`.examples/config/ars.json:18-22`).

**PR #29 adds no new path to ARS.**

- Before the PR, ES read files from ARS in four places in the code. Mounts reuse the program read, which makes five kinds of read.
- After the PR, all five go through one checked function (head `es/admission/ars_blob_fetch.go:76`).
- The discovery read and the health check are unchanged.
- ES also stops following "moved elsewhere" (redirect) answers from ARS and EGS. So ES now reaches fewer places, not more.

## 2. Why direct reads are fine, and what I recommend

AGS's authority travels with the data, not with the connection:

- AGS signs the evidence record.
- The evidence names the fingerprint (digest) of the program.
- ES checks the signature, and with this PR it also checks every fingerprint.

So ES does not need to trust ARS, or anything between ES and ARS, for the contents of a file.

Sending reads through AGS instead would put the service that holds the signing key in the path of every run. That gives it more exposure and more load, and once the bytes are checked it adds no protection.

**Recommendation:** keep direct reads from ES, and keep AGS as the only writer.

## 3. What changes in ES

**Before:**

- ES fetched the five kinds of file and used them exactly as received.
- Tests run against the old code show that a substituted program, substituted mount files, re-encoded evidence or different valid Vault settings were all accepted, and a run was submitted.

**After:**

- ES computes each file's fingerprint itself. It uses the file only if the fingerprint matches the one it expected.
  - For most files, the expected fingerprint comes from AGS's signed evidence.
  - For the Vault settings, it comes from ES's own configuration.
- A mismatch is refused before anything is created: no run, no staged files, no Nomad job.
- Two smaller fixes are included:
  - ARS can no longer substitute a different signed artifact as a mount.
  - ES ignores redirects from ARS and EGS.

**Size:** about 170 lines added and 90 removed in the product code in `es/admission` (`ars_blob_fetch.go` is the heart of it, at 98 lines). The rest is tests and docs. If you look at one file, look at that one.

## 4. The honest limit: one thing ES still trusts ARS for

To find an artifact's signed evidence, ES first asks ARS a question: "which evidence document applies to this artifact?" That answer, the discovery record, is not signed.

- Normally there is exactly one evidence document per artifact, and nothing changes.
- AGS's key could sign two evidence documents for the same artifact with different claims, for example different network access. If that happens, ARS chooses which one ES uses.
- For mounts, this changes no file. For the main program, it decides which claims apply.
- The fix is a design change, not a patch: the run request should name the exact evidence document, and revocation should retire the old ones.

I recommend this as its own design item, alongside the trust/revocation and admission-decision-record work. Section 5A of the contract states the limit.

## 5. Two older drifts noticed while answering (not caused by this PR)

- **The ARS writer check is looser than the docs.**
  - `configuration.md:137` says AGS writes with "the dedicated `service/artifact-governance` writer identity".
  - The code also accepts any identity below that path, such as `service/artifact-governance/x` (`ars/api/server.go:563`, `:571-580`).
  - The POC matched the identity exactly. This belongs in the identity work.
- **ES's Nomad client still follows redirects.** The red-team left that for the Nomad-lock PR #31.

## 6. How it was checked

- Five correctness audits and a red-team, all accepted. Every finding was fixed in the PR.
- The red-team attacked from the side of a hijacked ARS:
  - about 3 million fuzzed answers;
  - 560 concurrent submissions against a registry that alternates good and bad answers;
  - a live local stack of the real services.
- CI is green on the head. The merge checks passed: the head and trunk_dev are unchanged since the audits, and the change manifest was reproduced. GitHub's automated Codex review found nothing.

## 7. What is needed from you

Approve the merge, or ask questions. The main judgement call is whether to accept the discovery-record limit (section 4) as a follow-up design item rather than a blocker for this PR.
