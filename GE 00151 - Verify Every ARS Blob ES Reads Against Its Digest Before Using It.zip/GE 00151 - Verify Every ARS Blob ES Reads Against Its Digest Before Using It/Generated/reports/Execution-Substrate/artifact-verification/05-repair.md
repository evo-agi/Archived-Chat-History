# ES PR #29 repair after audit 04

**Outcome:** repaired, with one product-code change. I reviewed the auditor's tested diff and applied it unchanged. It covers A4-1 (the mount discovery binding), A4-2 (wording) and A4-3 (guard). Beyond that diff I added three things: a guard pin on the callers of the unverified discovery read, a not-found mapping test, and the mount scope of the remaining ARS choice in 5A and the storage doc. Every targeted mutant dies, and the root failing set is unchanged.

| Item | Value |
| --- | --- |
| Repository / branch | `evo-agi/Execution-Substrate`, `claude/project-thread-urwhl2`, draft PR #29 |
| Base | `trunk_dev` `036d50724b499b020c5149c55ad902cfcb1482c0` (unchanged) |
| Previous tip (audited) | `89da53dd7987ce20b9ebd479e9d90b5e2a63c92e` |
| New tip | `bb177ae7640d28b8aff4a7a44b874aa3eea56cd4`, tree `8710e167d409901a31813e70db5d5f4a37d7fd52` (fast-forward push, no force) |
| Delta `89da53d..bb177ae` | 11 paths, +242/-31 |
| Range `036d507..bb177ae` | 28 paths: the 23 before, plus `mounts.go`, `docs_contract_test.go`, `es_execution_admission_model.md`, `submit_idempotency_correlation_and_recovery.md` and `boundaries.md` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (checked before the run) |
| Textual diff SHA-256 | `c1ca2bd1b849a63c4d0b5d76ac2346ed6f3facb73812a153ae0e597025f4b824` |
| Canonical manifest SHA-256 | `026e6ce11a79a08d7bcf6d604c7ee8403646334fd99d7b8720416fc28ce09490`, 28 files |

Evidence is in `05-evidence/` next to this file.

## 1. What changed

| Finding | Change | Where |
| --- | --- | --- |
| A4-1 (Medium) | Auditor's diff. `prepareMountArtifact` refuses a discovery record whose artifact digest is not the requested mount digest, with `409 mount_artifact_invalid` and the message "artifact digest mismatch between mount source and artifact discovery". The check is placed before the evidence is prepared or the payload is read. Tests added: a Submit test for both modes (control stages the requested mount; substitute is refused, the other payload is never read, no run effects); "A B P substitution" now refused by the resolver; and a direct binding test so the binding's own requested-versus-verified check stays covered. The four docs that called this a residual, and the `docs_contract_test.go` pin on it, now say it is closed | `mounts.go:258-263`; `ars_blob_fetch_test.go:663`; `reliable_submit_binding_test.go:527`, `:620` |
| A4-2 (Low) | Auditor's diff. 5A now says the record's digest must equal "the requested one (the invocation's `artifact_digest`, or a governed mount's source `artifact_digest`)". It also says only the primary artifact's evidence must claim `derivation_spec_digest` and `output_id`. Both sentences are pinned | `contracts.md:715-722` |
| A4-3 (Low) | Auditor's diff. The guard also records bare `arsClient` identifiers and pins them to the field declaration plus NewService's local, key and value. It is contained: it kills G1 (second field) and G2 (second local). Reflection and `unsafe` stay out of reach, as the audit says | `ars_blob_fetch_test.go:919` |
| Mine: discovery callers | The guard pins every caller of the unverified discovery read: `prepareArtifact`, `prepareMountArtifact`, and `fetchArtifactDiscovery` for the record read. A new caller fails the guard until it gets the same binding and a test. This is what would have caught A4-1 | `ars_blob_fetch_test.go:944` |
| Mine: O4-2 remainder | `TestARSBlobCallSitesMapNotFound` checks each covered read's own mapping for a 404 | `ars_blob_fetch_test.go:339` |
| Mine: mount scope of the remaining choice | 5A now says which variants pass the checks: for the primary artifact, the same artifact digest, derivation spec digest and output ID; for a mount, the same artifact digest. It also says what the choice affects. For a mount it changes no staged byte, because the artifact digest fixes the payload digest, and the mount path uses only the payload and the identity. For the primary artifact it decides which execution claims apply. The storage doc says the same. Both are pinned, together with the ARS index sentence (O4-1) | `contracts.md:723-732`; `artifact_publication_storage.md:77-85` |

**Review of the auditor's diff before applying it:**

- Only one production line depends on the requested digest. `fetchValidatedMountPayload` trims the mount source digest. The trimmed form is what is sent to ARS and also what the new check compares against, so it compares the exact string requested. The primary path does the same, at `service.go:545`.
- `prepareArtifactFromEvidenceRecord` then requires the evidence identity to equal that same digest. The verified mount identity therefore equals the request.
- An honest ARS never serves another artifact's record (`ars/api/server.go:774`, `:806-830`), so honest deployments see no change. The code was already public: "Invalid or unusable mount artifact" (`contracts.md:1144`).
- I considered moving the check into the shared helper (`fetchArtifactDiscovery`, or a `requested` parameter on `prepareArtifactFromEvidenceRecord`) so that no caller could forget it. I kept the auditor's placement. It matches the primary path's layering, and the primary and mount refusals have different public mappings. The new caller pin guards against a forgotten third caller instead.
- PR 12's head has the same discovery callers and the same four residual sentences, so the change carries over (section 4).

`05-evidence/delta/additions-beyond-auditor-diff-04.diff` shows that seven of the eleven files are byte-identical to `89da53d` plus the auditor's diff. The other four carry only my additions above. They add 80 lines and remove 8; the 8 removed lines are the old storage sentence, two lines of the old 5A sentence, and the old storage pin.

## 2. Validation (tree `8710e167…`)

| Command | Result |
| --- | --- |
| `go build ./...`, `go vet ./...`, `GOOS=darwin GOARCH=arm64 go vet ./...`, `gofmt -l` on changed Go files | clean |
| `go test -count=1 ./es/admission/` (root, this container) | ok: 1,204 pass, 11 skip, 0 fail. That is 12 more passes than `89da53d`: 5 for the mount Submit test, 1 for the binding test, 6 for the not-found test |
| Root package, full, `89da53d` against the repair | the same 242 failing names on both, none only on one side (`05-evidence/root/root-failing-sets.txt`). They fail only in this container (root user, no Nomad or Vault); CI runs them |
| Root `-run 'ARSBlobVerification\|TestReliableSubmitBindingProducerDocsContract'` | pass |
| `-race -count=3` on the new and changed mount, guard and not-found tests | ok |
| Code mutants, one at a time, whole package with `-failfast`. The auditor's FX1, FG1, FG2 and FY3 were used unchanged. Mine: W1, a third caller of the discovery read; W2, W3 and W4, the payload, evidence and Vault 404 split out with another message | **8 of 8 killed** (`05-evidence/mutants/mutant-results.txt`) |
| Docs mutants F1 to F7: the mount binding wording reverted, the derivation/output claim reverted (= E3), the mount/primary set sentence dropped, the staged-byte sentence dropped, the ARS index sentence dropped (= E4), the storage qualifier dropped, and the residual sentence restored in the idempotency doc | **7 of 7 killed** (`docs-mutant-results.txt`) |

## 3. Provenance

This followed `provenance-and-audit-evidence.md` §5.5:

1. Recorded TIP `89da53d`, which equals `origin/claude/project-thread-urwhl2`.
2. Confirmed `origin/trunk_dev` is still `036d507`. Nothing was staged.
3. Ran `git reset --mixed 036d507` and pinned the upstream to `origin/trunk_dev`.
4. Ran v2 twice into a fresh 0700 directory. The two outputs are byte-identical.
5. Ran `git reset --mixed 89da53d`, then `git add -A` (11 delta paths), and committed once. `git status --porcelain` is empty afterwards.

I then checked the commit against the manifest:

- `git diff --name-only 036d507 bb177ae` equals the 28 manifest paths.
- Every committed blob hashes to its manifest entry, and every one is mode 100644.

The fast-forward push succeeded. The manifest files are in `05-evidence/manifest/`.

## 4. Trial merges and CI

The merge commits are local only. Outputs are in `05-evidence/trial-merges/`.

| Merge | Result |
| --- | --- |
| `bb177ae` into PR 12's head `2c8bf35` | clean; merge `8ab4d539`, tree `9091ee1b…`. Build and vet ok. `"/v1/blobs/"` appears only in `ars_blob_fetch.go`. `es/admission` ok (287 s). The root contract tests, including the binding-producer docs pin, are ok |
| `bb177ae` into PR #26's head `a88467f` | clean; merge `a2e2d131`, tree `26ebe4cd…`. Build and vet ok. `es/admission` ok (41 s). The root contract tests are ok |

CI on `bb177ae` was running when I wrote this.

## 5. Short re-audit scope

Range `89da53d..bb177ae`, 11 paths. Provenance covers `036d507..bb177ae`. Points to check:

1. Seven files are identical to `89da53d` plus `proposed-fix-04.diff`. The other four differ only by my additions.
2. The added guard pin on discovery callers, the not-found test, and the 5A and storage wording. The staged-byte claim rests on `resolveRuntimeMounts` using only payload bytes, the verified identity and the payload digest (`mounts.go:166-205`).
3. Re-run `mutants_fix.py`, my `mutants_mine.py.txt`, and the docs mutants.

## 6. Non-claims

- The discovery record is still unverified. ES now binds it to the requested artifact on both paths. Which sealed variant of that artifact applies remains ARS's choice. That is the design item recommended in `03-repair.md` §2.
- The guard is syntactic. It cannot catch reflection or `unsafe`.
- The es/app end-to-end mount tests skip in this container. CI runs them.
