# ES PR #29: narrow re-audit 06 of repair bb177ae (ARS blob byte verification)

| | |
|---|---|
| Repository | evo-agi/Execution-Substrate, draft PR #29 |
| Audited head | `bb177ae7640d28b8aff4a7a44b874aa3eea56cd4`, tree `8710e167d409901a31813e70db5d5f4a37d7fd52` (fast-forward from `89da53d`) |
| Base | trunk_dev `036d507` (PR base). trunk_dev moved to `8ba1edb` (PR #26) at 19:10Z, during this audit; see O6-1 |
| Writer's report | `05-repair.md`, sha256 `3184a0c02600bce0a59e7fa0366fbeef760183a4680751dd61db0a818247d270` |
| Previous audit | `04-audit.md` (REPAIR NEEDED: A4-1 Medium, A4-2 Low, A4-3 Low) |
| Auditor | independent auditor thread (not the writer), read-only, no repo writes |
| Window | 2026-11-23 18:57Z to 19:25Z |
| Evidence | `06-audit-evidence/` (SHA256SUMS inside) |

## 1. Verdict

**ACCEPT.** A4-1, A4-2 and A4-3 are closed. I found no new finding at Low or above.

- The mount path now refuses a discovery record that names another artifact. I probed this on the tip and on the PR 12 merge, and both refused.
- The writer's additions are accurate and tested: the guard pin on the callers of the unverified discovery read, the not-found mapping test, and the 5A and storage wording.
- No test that passed on `89da53d` fails on `bb177ae`.
- 35 of 36 code mutants and 7 of 7 docs mutants are killed.
- CI is green.

There is one nit, N6-1, with a tested one-test diff. It corrects my own earlier "equivalent" label for mutant X12 and has no security effect. There is one merge-order observation, O6-1: trunk_dev now holds PR #26, and the tested merge tree is given below.

The next step is the red-team.

## 2. Provenance gate

- The recipe was checked before each run (`v2.py`, sha256 `c08597e2…a3ca`) and was not edited.
- Tip bytes were placed on HEAD `036d507` under umask 022.
- **Opening** (18:57Z): two runs, both with manifest sha256 `026e6ce11a79a08d7bcf6d604c7ee8403646334fd99d7b8720416fc28ce09490`, 28 files, textual diff `c1ca2bd1…b824`. These equal the writer's values.
- **Closing** (19:17Z): byte-identical to the opening (`cmp`). At close, the tracked files equal `bb177ae`, and the three new files equal its blobs.
- The trunk_dev move does not change the manifest. The recipe records the upstream by name and hashes the working tree against HEAD (`provenance/provenance.txt`).
- Refs re-fetched at 19:15Z:
  - PR 29 head: `bb177ae`
  - PR 12 head: `2c8bf35`
  - PR 26 head: `a88467f`, merged
  - trunk_dev: `8ba1edb`

## 3. Delta 89da53d..bb177ae (11 files, +242/-31)

**Seven files are byte-identical to my tested `proposed-fix-04.diff`:**

- `mounts.go`
- `reliable_submit_binding_test.go`
- `docs_contract_test.go`
- four docs: implementation, es_execution_admission_model, submit_idempotency…, and boundaries

So the A4-1 production change is exactly the six-line check that I proposed and probed.

**The writer's additions, each checked:**

1. **The guard pins the callers of the unverified discovery read.** The pinned callers are `prepareMountArtifact` → `fetchArtifactDiscovery`, `prepareArtifact` → `fetchArtifactDiscovery`, and `fetchArtifactDiscovery` → `fetchArtifactDiscoveryRecord`.
   - These are exactly the three call sites at the tip (grep).
   - Both live callers bind the record to the requested digest: `service.go:545` for the primary path and `mounts.go:261` for the mount path.
   - Writer mutant W1 adds a third caller, and the guard kills it.
2. **`TestARSBlobCallSitesMapNotFound`.** It gives each covered read a 404, requires its own "unavailable" mapping, and expects exactly 5 requests. W2, W3 and W4 split out the 404 with the "read failed" message, and all three are killed. This closes the 404 remainder of O2-3 that I noted in O4-2.
3. **5A wording (A4-2).**
   - Derivation spec and output ID are now claimed for the primary artifact only. This matches the code: only `prepareArtifactFromDiscovery` (`service.go:559-570`) checks them.
   - The new variant sentence and "for a mount this changes no staged byte, because the artifact digest fixes the payload digest" are accurate:
     - `evidencev1` `Package.validate` re-derives `artifact_digest = DeriveArtifactDigest(payload_digest, artifact_type, intent_digest)`.
     - The mount path uses only `prepared.payloadDigest` and `prepared.manifest.ArtifactDigest` (`mounts.go:241-250`).
   - The ARS index sentence matches `ars/index/fileindex.go:81-97`, which is write-once per artifact digest.
4. **Storage bullet.** "(and, for the primary artifact, the same derivation inputs)" is accurate for the same reason.
5. **Docs pins.** The writer's docs mutants F1-F7 were re-run here, and all 7 are killed (`mutants/docs-writer-F1-F7-rerun-results.txt`).

## 4. Findings

### Closed

- **A4-1 (Medium), closed.** Live Submit now refuses a mount discovery record for another artifact with 409 `mount_artifact_invalid`. The other payload is never read and there are no run effects.
  - My probe (`probe/`) on `bb177ae` gives: `SUBMIT submitted=false … err=artifact digest mismatch between mount source and artifact discovery nomad=0`. The PR 12 merge `dd53e8d` gives the same result.
  - On `89da53d`, the same probe staged artifact Y's bytes.
  - FX1 (check removed) is killed by `TestSubmitRefusesAMountDiscoveryRecordForAnotherArtifact`. FY3 (binding requested-vs-verified check removed) is killed by the new direct binding test.
- **A4-2 (Low), closed.** See §3 item 3.
- **A4-3 (Low), closed.** G1, FG1 and FG2 are all killed by the bare-identifier rule.

### N6-1 (nit, test gap): the whole-digest comparison is not pinned. This corrects O2-4/O4-2.

- Mutant X12 changes `ars_blob_fetch.go` to compare only the first 39 characters of the digest (128 bits). It survives the whole package.
- In audits 02 and 04 I called it "equivalent". That was imprecise:
  - It is not exploitable. A compromised ARS would need bytes whose SHA-256 matches 128 bits of a digest it does not choose, which is a second preimage.
  - It is testable, though, because a test chooses the requested digest.
- `proposed-test/whole-digest-test.diff` (sha256 `6a2fe5269e87c34cd9e6227291d664c907ba1ca0f3198f86e77e2909882fc7b9`, test only, +32 lines) adds `TestFetchVerifiedARSBlobComparesTheWholeDigest`. The test requests a digest that differs from the served bytes' digest only in its last hex digit, for both views.
  - On the tip, es/admission is ok, vet is ok and gofmt is clean.
  - With X12, the whole package with `-failfast` fails in the new test.
  - It applies cleanly to the PR 12 and trunk_dev trial merges.
- The coordinator's standing rule is to fix low nits in the PR. This one is optional for correctness.

### Observations

- **O6-1 (merge order).** PR #26 merged into trunk_dev as `8ba1edb` (19:10Z). Its tree `45b41a40…` equals `a88467f`'s tree.
  - The trunk_dev ruleset requires up-to-date branches, so PR 29 needs trunk_dev merged in before it can land.
  - `git merge-tree origin/trunk_dev bb177ae` gives tree `26ebe4cd0bb767629179d43ca4c0e12450a9264c`. That is the tree of my trial merge `m26c`, already built and tested: es/admission ok, root docs pins ok.
  - A merge commit with that tree needs only a tree-equality check plus CI, unless N6-1's test is added first. In that case, re-run the merge-tree and the es/admission package.
  - The PR 12 trial merge (tree `9091ee1b…`) also stays valid. The rule in project memory still applies: whichever of #29 and #12 lands second re-runs the blob-read guard.
- **O6-2 (coverage scope, unchanged).** No end-to-end es/app mount submit exercises the new refusal:
  - CI's `TestSubmitFlowMountsGovernedArtifactAndLifecycleWithInstalledSourceIdentity` is on the environment-only list. It has been listed since PR #24, is unchanged here, and fails before any submit.
  - Its siblings skip in this container.
  - The refusal is covered in-package by a Submit test through the live resolver, and by the probe.
  - *Inference:* CI's es/app run showed only the 3 listed failures, so the honest mount end-to-end tests still pass there. I could not read per-test lines, because the run-log zip download was refused by the proxy.

## 5. Results

| Check | Result |
|---|---|
| Manifest (open ×2, close) | `026e6ce1…9490`, 28 files, all identical, equal to the writer's |
| `go test -count=1 -v ./es/admission/` (user ci) | 1,222 pass, 4 skip, 0 fail. Passed on `89da53d` but not here: 0. Skips identical. New tests: `TestARSBlobCallSitesMapNotFound`, `TestSubmitRefusesAMountDiscoveryRecordForAnotherArtifact`, `TestReliableSubmitBindingRefusesAMountWhoseVerifiedArtifactIsNotTheRequestedOne` (+9 subtests) |
| `-race ./es/admission/` | ok, 104.6 s, 0 race reports |
| build, vet, vet for darwin | ok |
| Root package | 38 container-only failures, same name set as `89da53d` (sorted-name sha256 `408eecb52f0074b5`); all docs contract tests pass |
| `go test -run Mount ./es/app/` | same PASS/SKIP sets as `89da53d` (3 end-to-end submits skip here) |
| Code mutants, whole package, `-failfast` (`mutants/results-bb177ae.txt`) | **35 of 36 killed**. Audit-04 lists unchanged (28 + FX1, FG1, FG2, FY3) plus writer W1-W4, all copied byte-for-byte (`mutants/provenance.txt`). X12 survives (N6-1, killed by the proposed test). Tree clean after the run |
| Docs mutants F1-F7 (writer's, re-run) | 7 of 7 killed |
| Mount substitution probe | refused on `bb177ae` and on the PR 12 merge `dd53e8d` |
| Trial merge into PR 12 `2c8bf35` | clean, tree `9091ee1b…` (= writer's). Build ok, es/admission ok (267 s), `/v1/blobs/` only at `ars_blob_fetch.go:76`, root docs pins ok |
| Trial merge into PR 26 `a88467f` = trunk_dev `8ba1edb` | clean, tree `26ebe4cd…` (= writer's). Build ok, es/admission ok, root docs pins ok |
| CI run 45242563111 | success (19:18:16Z). Test step success; the list check reports all 16 listed tests still fail. `environment-only-tests.txt` is not touched by the PR |

## 6. Not run, and limits

- No es/app end-to-end mount submit was run here (no Nomad or Docker; see O6-2).
- No box run. The change has no box-facing surface beyond Submit refusals.
- The red-team is not part of this audit. Suggested focus:
  - the remaining ARS choice among valid sealed variants for the primary artifact (documented in 5A, design item);
  - discovery-record handling for revoked signers;
  - paths to the discovery read that the guard cannot see. The guard already records every selector named `fetchArtifactDiscovery` or `fetchArtifactDiscoveryRecord`, so calls, method values and method expressions all count (`ars_blob_fetch_test.go:866`). Both are unexported methods of `*Service`, so only code in package `admission` can reach them, and the guard walks all of that package's non-test files. I see no gap there.

**Confidence: high** for the closed findings and the absence of lost coverage. The evidence comes from direct probes, mutants against the whole package, and set comparisons.
