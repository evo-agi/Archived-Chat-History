# ES PR #29 repair after red-team re-check (RT8-3)

**Outcome:** done. The new head is `06e84e517964360698052f39ed757b74c83d939a`, a fast-forward from `91dbad6`. The change is test-only, in one file. It contains the red-team's `guard-walk-hardening.diff`, applied unchanged, plus one fix of mine. The fix stops the guard from failing falsely in a checkout reached through a symbolic link. All 14 mutants are killed.

The auditor's `10-audit.md` on `91dbad6` had not arrived when I pushed (20:43Z), so it is not folded in here. If it reports findings, they go into the next round. I numbered this report 11 so that it does not collide with the audit.

| Item | Value |
| --- | --- |
| Repository / branch | `evo-agi/Execution-Substrate`, `claude/project-thread-urwhl2`, draft PR #29 |
| Previous head | `91dbad69d6111a5bc57b71df5e3331d665d855a2` (09-repair) |
| New head | `06e84e5`, tree `7ba2f726acef1ae90fe82f9f44012460f89cd62b`. The delta `91dbad6..06e84e5` is 1 path, +170/-22: `es/admission/ars_blob_fetch_test.go` |
| Base | trunk_dev `76c030fa7872dd22dda731591878ef284c01bd9b` (unchanged) |
| Recipe | v2, source SHA-256 `c08597e2…a3ca` (checked before the run) |
| Textual diff SHA-256 | `a8d506524740be25531df90621ac01929c8ef1462ea61fadcba50d08418ef30c`. This is unchanged from 09, because the changed file is a file the PR adds, and the textual diff covers only files that trunk_dev already tracks |
| Canonical manifest SHA-256 | `5e3590e2b1d3bec27c8816c8d5cd3b1dd334dbdf7f95f7525179f33b14130043`, 29 files, `76c030f..06e84e5` |

The evidence is in `11-evidence/` next to this file. `SHA256SUMS.txt` lists every file.

## 1. What changed

The red-team's diff (SHA-256 `22c5f116…6a12`) is applied unchanged. It changes the guard in four ways:

- It inspects every directory that `cmd/es` links from inside the repository, including those under `es/`. This covers `es/_x`, `es/.x` and `testdata`, which the source walk skips. Each file is inspected once.
- It keeps any non-standard package whose directory is inside the repository. That covers nested and replaced modules, not only the main module.
- It refuses a linked module that is replaced with a directory outside the repository.
- It lists darwin/arm64, linux/amd64 and linux/arm64, the same set as `loadTypedProductionPackages`.

The diff also adds a self-test, `TestESBinaryRepositoryPackageDirsSeesEveryLinkedRepositoryPackage`.

**My addition: resolve the ES root.** `go list` reports package directories with symbolic links resolved. The guard took its ES root from `filepath.Abs("..")`, which keeps the logical path. In a checkout reached through a symbolic link, file labels from the two sources therefore differed. `ars/api/server.go`, for example, was labelled `../../../../../../../../home/user/Execution-Substrate/ars/api/server.go`. The expected sites then did not match, and the guard failed even though nothing was wrong. A temporary directory on macOS (`/var` → `/private/var`) is enough to cause this.

This only made the guard fail closed, never open, and the problem already existed on `91dbad6`. The fix resolves `esRoot` with `filepath.EvalSymlinks` before walking. Both runs are in `11-evidence/suite/symlink-checkout-*.txt`:

- Without the fix, the guard fails when run from a symbolic-link path to this checkout.
- With the fix, the guard and the self-test pass from that path and from the real path.

`11-evidence/delta/additions-beyond-guard-walk-hardening.diff` shows the only lines beyond the red-team's diff: 8 lines of comment and code.

**Review of the red-team diff:**

- **Duplicate inspection.** Inspecting each file once, keyed by its resolved path, means the source walk and the dependency walk never record a site twice. The `files < 50` check still counts only the source walk.
- **The `go list` template.** It prints 4 tab-separated fields per non-standard package, ending in `end`, and any other line is an error. Packages from the module cache are outside the repository and are neither main-module nor directory-replaced, so they are skipped. Third-party code cannot name ES's config types.
- **Build settings.** ES's build contract is `CGO_ENABLED=0` with no custom build tags (checked across workflows, scripts and docs). So listing with GOOS and GOARCH, at `CGO_ENABLED=0`, covers every production build.
- **The self-test.** It runs `go list` on a synthetic module with the same hermetic environment (`GOPROXY=off`, a directory replacement, so no `go.sum` is needed). It resolves temporary directory paths on both sides.

## 2. Validation (tree `7ba2f726…`)

| Command | Result |
| --- | --- |
| `go build ./...`, `go vet ./es/...`, `go vet ./es/admission/` for darwin/arm64 and linux/arm64, `gofmt -l` | clean |
| `go test -count=1 ./es/admission/` (root, this container) | ok: 1,282 pass, 11 skip, 0 fail. That is 3 more than `91dbad6`: the self-test and its two subtests |
| Root package `-run 'ARSBlobVerification\|TestReliableSubmitBindingProducerDocsContract'` | pass |
| `-race -count=3` on the guard and the self-test | ok |
| Mutants. A guard mutant must build `cmd/es` and be linked on its platform (checked with `go build` and `go list -deps`). A self-test mutant must pass vet | **14 of 14 killed** (`11-evidence/mutants/mutant-results.txt`) |

| Mutant | Where the unverified read lives, or what is weakened | Killed by |
| --- | --- | --- |
| C1 | `internal/blobcache` (control) | guard |
| G5 | `es/_blobcache` | guard |
| G6 | `es/admission/testdata/blobcache` | guard |
| G6b | `es/.blobcache` | guard |
| G7 | nested module `internal/blobmod`, replaced in `go.mod` | guard |
| G8 | `internal/blobcache`, imported only by a `linux && arm64` file | guard (linux/arm64 listing) |
| G9 | a module replaced with a directory outside the repository | guard refuses: "outside the repository, which this guard cannot inspect" |
| G3 | `internal/callerauth` (from PR #27) | guard |
| G4 | `internal/blobcache`, imported only by a `darwin` file | guard (darwin/arm64 listing) |
| M1 to M4 (red-team) | the dependency walk skips directories under es/ again; keeps main-module packages only; drops linux/arm64; accepts outside replacements | self-test |
| M5 (mine) | the dependency walk drops darwin/arm64 | self-test |

I did not re-run the whole module this round. The change is one test file in es/admission, and the whole-module comparison in 09 covered everything else on the same base.

## 3. Provenance

This followed §5.5:

1. Recorded TIP `91dbad6`, which equals the remote branch.
2. Confirmed trunk_dev is still `76c030f`. Nothing was staged.
3. Ran `git reset --mixed 76c030f` and pinned the upstream to `origin/trunk_dev`.
4. Ran v2 twice into a fresh 0700 directory. The two outputs are byte-identical.
5. Ran `git reset --mixed 91dbad6`, then `git add -A` (1 path), and committed once.

I then checked the commit against the manifest:

- `git diff --name-only 76c030f 06e84e5` equals the 29 manifest paths.
- Every committed blob matches its manifest entry, and every one is mode 100644.

The push was a fast-forward.

## 4. Scope for the next checks

The delta is `91dbad6..06e84e5`, one test file. It is the red-team diff plus the 8-line root resolution. Points to check:

1. Re-run the red-team's `run-mutant.sh` set, or `11-evidence/mutants/mutants_10.py.txt`, which takes the worktree, an outside directory and an output path.
2. The symbolic-link case.

## 5. Non-claims

The guard is still syntactic. It cannot see reflection, `unsafe` or linkname, and it cannot see a direct read of ARS's storage through `ars/store`, which re-hashes on read. A package linked only under a custom build tag is not listed, because ES's build contract has none.
