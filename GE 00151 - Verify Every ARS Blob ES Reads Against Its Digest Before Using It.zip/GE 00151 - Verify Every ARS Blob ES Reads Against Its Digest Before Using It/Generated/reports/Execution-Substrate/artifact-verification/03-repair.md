# ES PR #29 repair after audit 02

**Outcome:** repaired. A2-1 to A2-4 are fixed with the auditor's tested diff, applied unchanged. For A2-5, I checked whether the discovery record could be properly signed or pinned in this PR. It can't. Signing doesn't give the missing property, and pinning needs a request-grammar change that collides with PR 12. So section 5A is reworded to say exactly what is and isn't verified, and the gap is reported below with a recommendation. I also fixed O2-1 and O2-2. Every targeted mutant dies.

| Item | Value |
| --- | --- |
| Repository / branch | `evo-agi/Execution-Substrate`, `claude/project-thread-urwhl2`, draft PR #29 |
| Base | `trunk_dev` `036d50724b499b020c5149c55ad902cfcb1482c0` (unchanged since the first commit) |
| Previous tip (audited) | `f8c1a73b5a14b99a40e9c54910a76e14d30e5312` |
| New tip | `89da53dd7987ce20b9ebd479e9d90b5e2a63c92e`, tree `86c432266ffc481de0084255b4091c8e12799935` (fast-forward push, no force) |
| Delta `f8c1a73..89da53d` | 9 paths, +295/-43 |
| Range `036d507..89da53d` | 23 paths (the 22 before plus `.docs/execution_lifecycle/design.md`) |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (checked before the run) |
| Textual diff SHA-256 | `45ff314f33aacb65d371ae3ab2906a27f6f8bb0d3b816f1973edbb3203d2a77d` |
| Canonical manifest SHA-256 | `3521d5c3904c25495c81f447f895704f2034fab079c6cd0d680155922a6415dc`, 23 files |

Evidence is in `03-evidence/` next to this file.

## 1. Findings and what changed

| Finding | Fix | Where |
| --- | --- | --- |
| A2-1 evidence decode coverage lost | Auditor's diff: the three evidence failure cases (truncated, unknown field, trailing document) are digest-true, so the strict decoder refuses them; they pin "artifact evidence payload was invalid" | `artifact_prepare_test.go` |
| A2-2 binding-layer mount check unexercised | Auditor's diff: `TestReliableSubmitBindingRefusesMountBytesThatDoNotHashToTheMountPayloadDigest` (control builds, mismatch refuses) | `reliable_submit_binding_test.go:608` |
| A2-3 read limits unpinned | Auditor's diff: `TestARSBlobReadsKeepTheirOwnReadLimits` (one byte over each read's limit, no Content-Length) | `ars_blob_fetch_test.go:798` |
| A2-4 guard evasions | Auditor's diff: the guard records the method called on each `arsClient` use, records any use that isn't a direct call, and allows `Dependencies.ArtifactRegistry` only in `NewService` and `Config.Validate` | `ars_blob_fetch_test.go:676` |
| A2-5 5A over-claims | Reworded (section 2). The root docs test pins the new wording and refuses the old | contracts.md 5A, storage, runtime-config and design docs |
| O2-1 call-site normalization unpinned | New `TestARSBlobCallSitesRequestTheDigestExactlyAsGiven`. It passes each of the five call sites an uppercase, space-padded or newline-terminated spelling of the digest of the bytes ARS serves. Each must refuse with its "unavailable" mapping and send no request | `ars_blob_fetch_test.go:281` |
| O2-2 rendezvous arrival bound unpinned | The arrival bound is now a field (default 8 s; the return bound stays the 8 s constant). New `TestPrivateReplayClaimRendezvousBoundsTheWaitForArrival` holds one worker short of the hook until release, with a 50 ms bound and its own 5 s guard | `reliable_submit_replay_private_test.go:333` |
| O2-3 Vault strict decode untested | Covered by the auditor's diff (`TestWorkloadZoneVaultBlobIsDecodedStrictlyFromVerifiedBytes`) | `ars_blob_fetch_test.go:338` |

The auditor's diff is applied byte-for-byte. `artifact_prepare_test.go` and `reliable_submit_binding_test.go` are identical to `f8c1a73` plus that diff. `ars_blob_fetch_test.go` differs from it only by the added O2-1 test, which is 61 added lines and none removed (`03-evidence/delta/additions-beyond-auditor-diff.diff`). No production code changed in this repair.

## 2. A2-5: can the discovery record be verified properly in this PR?

**Answer: no, not without a request-grammar change that belongs in its own design.** Signing it would not close the gap, and pinning it has no trusted source inside ES today.

### What the discovery record decides today

ES reads `GET /v1/artifacts/{artifact_digest}/discovery` (`service.go:465`) without byte verification. Here is how each field ES takes from it is bound:

| Field | Binding |
| --- | --- |
| `artifact.artifact_digest` | must equal the request's (`service.go:545`) |
| `payload.digest`, `artifact.artifact_type`, `artifact.intent_digest` | must equal the signature-verified evidence claims (`service.go:600-620`). What ES uses afterwards is the signed value |
| `evidence.digest` | used only to choose which evidence blob to read; that blob is then hash-verified against it |

The evidence it points at must carry a valid seal from an allowed signer. It must also claim the requested `artifact_digest`, `derivation_spec_digest` and `output_id`. Nothing checks that it is the only such document.

`artifact_digest` is derived from `payload_digest`, `artifact_type` and `intent_digest` only. It is "not derived from admission/runtime claim material" (`artifact_publication_storage.md:146`). So the provenance key can seal several evidence documents with the same artifact digest, derivation spec digest and output ID. They can differ in `network_access`, `target_platform`, the runtime env allowlist, required capabilities, and the publication facts.

That situation is reachable on the normal path. AGS uploads the evidence blob before it registers (`ags/publish/service.go:178-192`). ARS refuses a second registration with different digests (`ars/index/fileindex.go:97`), but by then the second sealed blob is already in the store. An ARS that follows its own contract always names the first registered document. A compromised ARS can name any of them.

**Demonstration** (`03-evidence/a25-discovery/`): this is a scratch test, not committed. It builds two evidence documents sealed by the same key, for the same artifact digest, derivation spec digest and output ID, differing only in `network_access`. ES prepares whichever one the discovery record names, with `networkAccess=false` and `true` respectively.

This applies to every artifact ES resolves through discovery, governed mounts included.

### Why signing doesn't fix it

The evidence is already sealed by AGS. If AGS also signed the discovery record, it would sign one record per publish. Two publishes would give two validly signed records, and ARS would still pick between them. What's missing is **uniqueness or recency**, not authenticity.

### Why pinning doesn't fit here

ES has no trusted per-artifact source for the evidence digest. Its startup config pins only the Vault blob. The only party that could name the evidence digest per request is the caller, through a new invocation field (and one per mount source). That means:

- a change to the public `:prepare`/`:submit` request grammar;
- a change to reliable submit's replay intent, which binds the invocation fields (`reliable_submit_replay_intent.go:214`), and to PR 12's request binding, which is in flight;
- changes to the Coordinator and other clients, and to the shared-kernel docs.

Pinning alone also only moves the choice from ARS to the caller. A caller can still pick the most permissive sealed variant. Retiring a variant needs revocation, which is gap 2.

### Recommendation

Track this as its own named design item. Decide it with gap 2 (trust and revocation) and gap 3 (admission decision record), after PR 12 lands. My recommended design:

1. **The invocation names the evidence digest** for the primary artifact and for each mount. ES fetches that evidence by digest through `fetchVerifiedARSBlob` and drops the discovery read from the admission path. ARS becomes storage only, which is the principle this PR already applies to blobs. The choice becomes explicit and is bound into the request.
2. **Retiring a sealed variant goes through gap 2's revocation design.** Until a variant is revoked, every variant AGS sealed for that artifact and derivation stays admissible. That is a policy statement, not a hidden ARS choice.
3. **Gap 3's decision record names the admitted evidence digest.** Every admission then shows which signed claims it ran under.

Until then, the gap is stated precisely and held in place two ways:

- Contract 5A says it (`contracts.md:655`, `:713-727`). The root docs test pins that text, and it fails if the old "the bytes it reads" claim comes back.
- The blob-read guard keeps `fetchArtifactDiscoveryRecord` as the only ARS read that skips verification.

### The rewording

- **contracts.md 5A opening** (`:655`): the claim now covers "the integrity of the blobs it reads by digest". It adds: "ES still trusts ARS for one choice: which sealed evidence document applies to an artifact, through the discovery record".
- **5A table**: the evidence row now says the discovery record is not verified.
- **5A "Outside this contract"** (`:713`): new paragraph. It states that the discovery record is not read by digest and has no trusted digest, what binds each field ES uses, that uniqueness is not checked and why, that ARS chooses when there is more than one, and what an honest ARS does.
- **contracts.md `:prepare` bullet** (`:521`): "every ARS blob it reads by digest", plus a sentence that the discovery record is unverified.
- **artifact_publication_storage.md:77**: scoped the same way, plus the discovery limit.
- **runtime_config_ownership.md**: "for this blob" instead of "for the bytes it reads".
- **design.md:165**: this said ARS is authoritative for blob reads, which predates this PR. It now adds that ES verifies every blob read by digest and doesn't verify the discovery record. It is also pinned.

## 3. Validation (tree `86c43226…`)

| Command | Result |
| --- | --- |
| `go build ./...`, `go vet ./...`, `GOOS=darwin GOARCH=arm64 go vet ./...`, `gofmt -l` on changed Go files | clean |
| `go test -count=1 ./es/admission/` (root, this container) | ok, 58.4 s: 1,192 pass, 11 skip, 0 fail (`03-evidence/suite/`). The extra skips compared with the auditor's 4 are root-only skips in this container |
| Root docs tests `-run ARSBlobVerification` | 3 of 3 pass |
| `-race` on every new and changed test | ok, no race report |
| `-race -count=100` on the rendezvous tests and the call-site test | ok |
| Code mutants: the 11 the auditor's fix targets (X1a, X1b, X1c, X4, X4c, X5, X6, X7, X19, X20, Y1), plus X17, X18 (O2-1) and X22 (O2-2). The auditor's definitions were used unchanged, one at a time, on the whole package with `-failfast` | **14 of 14 killed** (`03-evidence/mutants/mutant-results.txt`) |
| Docs mutants on the new pins (D3 to D10: old opening restored, uniqueness or chooser sentence dropped, discovery sentence dropped, storage, runtime-config, `:prepare` and design sentences reverted) | **8 of 8 killed** (`docs-mutant-results.txt`) |
| Root package, other packages | Unchanged by this repair except the docs test. One unrelated root test (`TestRemoteAlphaVaultServiceUserMigrationApplyRepresentsPostApplyContractFailureHonestly`) fails in this container on `f8c1a73` too, because it runs as root. CI runs it as a normal user |

## 4. Provenance

This followed `provenance-and-audit-evidence.md` §5.5:

1. Recorded TIP `f8c1a73`.
2. Checked that `origin/trunk_dev` is still `036d507`.
3. Nothing was staged. Ran `git reset --mixed 036d507` and pinned the upstream to `origin/trunk_dev`.
4. Ran v2 twice, to absent paths in a fresh 0700 directory. The outputs are byte-identical.
5. Ran `git reset --mixed f8c1a73`, then `git add -A` (9 delta paths), and committed once.
6. `git status --porcelain` is empty afterwards.

Then checked the new commit against the manifest:

- `git diff --name-only 036d507 89da53d` equals the 23 manifest paths.
- Every committed blob hashes to its manifest entry, and every one is mode 100644.

The fast-forward push succeeded. Files: `03-evidence/manifest/` (`1.json`, `2.json`, `run-1.out`, `run-2.out`, `staged-delta.txt`, `base-range-paths.txt`).

## 5. Trial merges and CI

The merge commits are local only and were not pushed. Outputs are in `03-evidence/trial-merges/`.

| Merge | Result |
| --- | --- |
| `89da53d` into PR 12's head `2c8bf35` (PR #12's branch and PR #28's head) | clean; merge `f617f735`, tree `8069c879…`. `"/v1/blobs/"` still appears once in ES production code (the helper). Build and vet ok. `es/admission` ok (301 s). The root contract tests show only the container-only failure from section 3 |
| `89da53d` into PR #26's head `06ec54b` | clean; merge `6b80dd97`, tree `29e1fae6…`. Build and vet ok. `es/admission` ok (54 s). The root contract tests show only the same container-only failure |

CI on `89da53d` (run 45230111785) was still running when I handed this over. The thread reply gives the result.

## 6. Narrow re-audit scope

Range: `f8c1a73..89da53d`, 9 paths. Provenance covers the full `036d507..89da53d` range. Points to check:

1. The two test files are identical to `f8c1a73` plus the proposed diff. The third differs only by the O2-1 test.
2. The A2-5 wording is accurate against the code: discovery bindings `service.go:545-620`, AGS upload order, ARS write-once index.
3. The new pins and the O2-1 and O2-2 tests catch what they claim to catch (X17, X18, X22, D3 to D10).
4. Whether the A2-5 recommendation should become a tracked item. That is the coordinator's call.

## 7. Non-claims

- The discovery record remains unverified. This repair states that limit. It doesn't remove it.
- No production code changed. The verification behaviour is exactly as audited at `f8c1a73`.
- Whether AGS has in fact sealed more than one evidence document for any real artifact was not checked. The demonstration shows ES would accept either one.
