# ES PR #29: whole-digest test (N6-1) and trunk_dev sync

**Outcome:** done. The new head is `e548b0726e9e1c4c2f0c964f1465019197b57b6a` (tree `1c68dd98cf8efbb7af696d79b009f40957af5efe`), a fast-forward from the accepted `bb177ae`. The only product code in it is what audit 06 accepted.

| Item | Value |
| --- | --- |
| Accepted head (audit 06) | `bb177ae7640d28b8aff4a7a44b874aa3eea56cd4` |
| Commit 1 | `2e5e9f15ccfd61407b66cb58f787f5d84830e69b`: merge of trunk_dev `8ba1edb` (PR #26), no conflicts. Its tree, `26ebe4cd0bb767629179d43ca4c0e12450a9264c`, is the trial-merge tree that both the writer and the auditor tested |
| Commit 2 | `e548b07`: the auditor's `06-audit-evidence/proposed-test/whole-digest-test.diff` (sha256 `6a2fe526…`), applied unchanged. Test only: `TestFetchVerifiedARSBlobComparesTheWholeDigest` in `es/admission/ars_blob_fetch_test.go` |
| New base | trunk_dev `8ba1edb8af52214ec1bfbb5b93e5a4dc4e51b1ce` |
| Recipe | v2, source sha256 `c08597e2…a3ca` (checked before the run) |
| Textual diff SHA-256 | `7b9e05b26ec692d4e73665b2a4dd29b15f0126eddacf57e3658246331b32a352` |
| Canonical manifest SHA-256 | `6e91a985c446c4d24ce7f0a38dd06d70da1b4dd6d3501fe3f11fe5745d4d9a35`, 28 files, `8ba1edb..e548b07` |

## Validation

| Check | Result |
| --- | --- |
| `go build ./...`, `go vet ./...`, macOS vet, gofmt | clean |
| `go test -count=1 ./es/admission/` (root, this container) | ok: 1,276 pass, 11 skip, 0 fail. This includes PR #26's tests and the new test with its two views |
| Root package, `8ba1edb` against the new tip | the same 242 failing names, all specific to this container. No test that passes on trunk_dev fails on the tip (`07-evidence/root/`) |
| Mutant X12 (compare only the first 39 characters) | killed by the new test (both views) |
| Provenance | Per §5.5 with the new base: HEAD reset `--mixed` to `8ba1edb`, upstream pinned, two byte-identical runs, reset to the merge commit, one commit. Then `git diff --name-only 8ba1edb e548b07` equals the 28 manifest paths, every committed blob matches its manifest hash, and all are mode 100644. The push was a fast-forward |

## Delta for the narrow check

`bb177ae..e548b07` is the trunk_dev merge (PR #26's four test and doc files, which merged with no conflicts) plus one test-only file. The PR's own path set against the new base is still 28 paths. Against `036d507` it was 28 too; PR #26's files are trunk_dev's now.

## Merge note for PR 12

PR 12's head `2c8bf35` still merges cleanly with `bb177ae`, giving tree `9091ee1b…`. It does **not** merge cleanly with trunk_dev `8ba1edb` alone: `git merge-tree` reports a conflict in `es/admission/workstream_a_guardrails_test.go` between PR 12 and PR #26. PR #29 adds no conflict of its own. PR 12 resolves that conflict when it takes up trunk_dev.
