# ES PR #29: delta check 08, bb177ae → e548b07

| | |
|---|---|
| Audited head | `e548b0726e9e1c4c2f0c964f1465019197b57b6a`, tree `1c68dd98cf8efbb7af696d79b009f40957af5efe` |
| Base | trunk_dev `8ba1edb` (holds PR #26) |
| Previous audit | `06-audit.md`, ACCEPT on `bb177ae` with nit N6-1 and observation O6-1 |
| Auditor | independent auditor thread (not the writer), read-only, no repo writes |
| Window | 2026-11-23 19:32Z to 20:02Z |
| Writer's report | `07-sync.md`, sha256 `5a665022…5f10` (the writer used number 07, so this note is 08) |
| Evidence | `08-audit-evidence/` (SHA256SUMS inside) |

## Verdict

**ACCEPT.** The delta is exactly what the writer reported in `07-sync.md`: the trunk_dev merge that I tested in audit 06, plus my N6-1 test, unchanged. Nothing else changed. There are no findings. N6-1 and O6-1 are closed.

## Checks

1. **Commits** (`commits/commits.txt`):
   - `2e5e9f1` merges `bb177ae` with trunk_dev `8ba1edb`. Its tree is `26ebe4cd…`, which equals `git merge-tree 8ba1edb bb177ae` and the trial merge I built and tested in audit 06.
   - `e548b07` adds only `es/admission/ars_blob_fetch_test.go` (+32 lines). `git diff 2e5e9f1 e548b07` is byte-identical to `06-audit-evidence/proposed-test/whole-digest-test.diff` (sha256 `6a2fe526…`).
2. **Manifest** (`provenance/`). The recipe hash was checked and the recipe was not edited. The tip bytes were placed on HEAD `8ba1edb`.
   - Both opening runs and the closing run give `6e91a985c446c4d24ce7f0a38dd06d70da1b4dd6d3501fe3f11fe5745d4d9a35`: 28 paths (25 modified, 3 added), textual diff `7b9e05b2…a352`. These equal the writer's claim.
   - Against audit 06's manifest (base `036d507`), the path set is the same. Three hashes differ:
     - the N6-1 test file;
     - `workstream_b_guardrails_test.go` and `workstream_c_guardrails_test.go`, which PR #26 also changed. PR #29's own changed lines in these two files are identical on both bases.
3. **Tests** (`tests/summary.txt`), run as user ci:
   - Build, vet and darwin vet are ok.
   - es/admission: 1,294 pass, 4 skip, 0 fail. Nothing that passed on `bb177ae` fails here, and the skips are identical. The new tests are the N6-1 test plus PR #26's four Workstream A tests.
   - The blob-read guard passes, and `/v1/blobs/` appears only at `ars_blob_fetch.go:76`.
   - Race: ok, 102 s.
   - Root package: the same 38 container-only failing names as on `bb177ae`. No docs or contract test is among them.
4. **The N6-1 test kills X12 on this head** (`mutants/`). With the whole package and `-failfast`, it fails in `TestFetchVerifiedARSBlobComparesTheWholeDigest/:bytes`. The tree was clean afterwards.
5. **CI** (`ci/`): run 45249694858 on `e548b07` succeeded at 19:59:07Z. Build, vet, darwin vet, the test gate and the Test step all succeeded, and the list check reports that all 16 listed tests still fail.

The writer's counts in `07-sync.md` (1,276 pass and 11 skip in es/admission, 242 root failures) differ from mine because the writer runs as root in its own container. Both of us found no test that passes on the base and fails on the tip.

## Observation for the coordinator (not a PR #29 finding)

- **O8-1.** The writer's `07-sync.md` reports this too. PR 12's head `2c8bf35` now conflicts with trunk_dev in `es/admission/workstream_a_guardrails_test.go`.
  - The conflict comes from PR #26: `2c8bf35` against `a88467f` already conflicts, and so does `2c8bf35` against `8ba1edb`.
  - PR #29 does not add it: `2c8bf35` against `bb177ae` is clean.
  - So PR 12 needs that conflict resolved whichever PR lands first. The PR 29 trial tree `9091ee1b…` from audit 06 applies only until then.
  - The rule from project memory still applies: whichever of #29 and #12 lands second re-runs the blob-read guard.

The red-team runs in parallel on this same head.
