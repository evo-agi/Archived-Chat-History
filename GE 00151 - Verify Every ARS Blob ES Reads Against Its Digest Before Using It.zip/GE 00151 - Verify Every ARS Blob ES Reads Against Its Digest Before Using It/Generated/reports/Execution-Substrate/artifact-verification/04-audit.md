# ES PR #29 narrow re-audit of the repair (audit 04)

**Verdict: REPAIR NEEDED. One Medium finding blocks acceptance, and two Low findings can be fixed in the same pass.**

The repair closes A2-1 to A2-4, O2-1 and O2-2, and I re-verified each one. A2-5 is only partly closed. The new section 5A text is accurate for the primary artifact, and its claims about AGS and ARS hold. For governed mounts it is wrong. Live Submit does not check that a mount's discovery record names the requested mount artifact. A compromised ARS can therefore make ES stage the bytes of any other validly sealed artifact as the mount, and I demonstrated this on 89da53d and on the PR 12 merge.

This gap predates PR #29. Four existing docs record it as a known residual of the PB1 binding slice. The new 5A paragraph contradicts them, and the gap defeats PR #29's mount protection against the very attacker the PR is about. I wrote and tested a fix, `04-audit-evidence/proposed-fix/proposed-fix-04.diff`. It adds a 6-line production check, tests, a guard rule and docs updates, and it kills every targeted mutant.

| Item | Value |
| --- | --- |
| Repository / PR | `evo-agi/Execution-Substrate`, draft PR #29, branch `claude/project-thread-urwhl2` |
| Audited head | `89da53dd7987ce20b9ebd479e9d90b5e2a63c92e`, tree `86c432266ffc481de0084255b4091c8e12799935`. It fast-forwards from `f8c1a73` (`git merge-base --is-ancestor`), with one commit. |
| Base | `trunk_dev` `036d50724b499b020c5149c55ad902cfcb1482c0`, unchanged at the start (17:47Z) and at the close (18:32Z) |
| Writer's report | `03-repair.md`, SHA-256 `b3b3a72027a03c8454b2c2cc8c6569d709409e708e20fc4fac2ea2a3c428dd72`. All 20 entries in its `03-evidence/SHA256SUMS.txt` are OK. |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`. I checked it before each run, and it is byte-equal to `claude-conversion/tools/` |
| Manifest | `3521d5c3904c25495c81f447f895704f2034fab079c6cd0d680155922a6415dc`, 23 files, textual diff `45ff314f33aacb65d371ae3ab2906a27f6f8bb0d3b816f1973edbb3203d2a77d`. Two opening runs were byte-identical, and both equal the writer's `03-evidence/manifest/1.json`. The closing run (18:32Z) is byte-identical to the opening. |
| CI | Run 45230111785 on `89da53d`: **success** (18:08:19Z). The list check reports "all 16 listed tests still fail on this host". |
| Repo writes | None. Everything was done in local clones: merges, fix commits and probes. |

## 1. Findings

| ID | Severity | Type | Summary | Status |
| --- | --- | --- | --- | --- |
| A4-1 | **Medium** | Contract accuracy over a pre-existing security gap | 5A says the discovery record's "artifact digest must equal the request's". The mount path never checks this, so ARS can substitute any sealed artifact as a mount on live Submit | Open; fixed in proposed diff |
| A4-2 | Low | Docs | 5A says the evidence must "claim the requested `artifact_digest`, `derivation_spec_digest` and `output_id`". That holds for the primary artifact only, since a mount request carries no derivation spec or output ID | Open; fixed in proposed diff |
| A4-3 | Low | Guard completeness | The blob-read guard can still be bypassed by giving `Service` a second field initialised from NewService's `arsClient` local (mutant G1 survives) | Open; fixed in proposed diff |

### A4-1 (Medium): mount discovery is not bound to the requested mount

**Where.** `es/admission/mounts.go:253-264` (`prepareMountArtifact`). This file is unchanged by PR #29 and identical on base. The function reads `/v1/artifacts/{requested}/discovery` and passes the record and its evidence straight to `prepareArtifactFromEvidenceRecord` (`service.go:583`). That function checks the evidence against the record's *own* artifact digest, not against the requested one. Only the primary path compares the record with the request, at `service.go:545`, plus the derivation and output checks at `:552-570`. The requested digest and the verified digest are carried side by side (`resolvedMountPlan.artifactDigest` and `.verifiedArtifactDigest`). They are compared only in the reliable-submit binding (`reliable_submit_binding.go:360`), which the public `POST /v1/executions:submit` handler (`es/api/server.go:66,135` → `Service.Submit`) does not call.

**Demonstration.** See `probe/` and the probe test `zz_audit_mount_discovery_probe_test.go.txt`, which is not for commit. A mount requests source X. ARS answers X's discovery read with the record of a different artifact Y that is validly sealed, and every blob then served hashes to its digest. On `89da53d`, Submit returns `submitted=true` with one Nomad registration and stages Y's `config.txt` under mounts/00. The same happens on the PR 12 trial merge `31995d6`. (`:prepare` does not resolve mounts, so the probe's Prepare line says nothing either way.)

**Why it matters for this PR.**

- **It contradicts the PR's own promise.** PR #29's mount test (`TestSubmitRefusesMountBytesAndEvidenceThatDoNotHashToTheirDigests`) shows substituted mount bytes being refused. A compromised ARS gets the same substitution through the discovery record, as long as the substitute is any artifact the provenance key ever sealed: an older config, or one built for another workload.
- **The new text contradicts four existing docs.** The new 5A paragraph says the binding exists. These docs say it does not:
  - `implementation.md:54-55`: "it does not add requested-versus-returned mount artifact refusal to live `Submit`"
  - `submit_idempotency_correlation_and_recovery.md:535-539`: "A signed request-A/discovery-B/payload-P combination may therefore reach legacy staging … residual current-path limitation"
  - `es_execution_admission_model.md:113`
  - `boundaries.md:236-238`
- **It is pinned as legacy behaviour.** The existing test `TestReliableSubmitBindingRejectsMismatchedSignedMountArtifact` "A B P substitution" pins the resolver's acceptance as "current legacy resolver rejection changed".

**Fix (proposed diff).** In `prepareMountArtifact`, the discovery record's artifact digest must equal the requested mount digest. The comparison is exact, which is the same rule as the primary path. Otherwise ES refuses with `409 mount_artifact_invalid`, "artifact digest mismatch between mount source and artifact discovery". That code already exists in the public table as "Invalid or unusable mount artifact" (contracts.md:1144), so there is no new public grammar.

An honest ARS never serves another artifact's record. `validateArtifactDiscovery` (`ars/api/server.go:806-830`) refuses a record for another artifact both at registration and on every read (`:774`). The check therefore changes nothing for an honest deployment.

The PB1 slice deliberately left legacy rejection unchanged, but that reason does not apply here. PR #29 is a runtime hardening of ES's trust in ARS, and it already changes what live Submit refuses. **I recommend fixing the gap in this PR rather than documenting it in 5A.** Writing it down would accept a known ARS road that PR #29 sets out to close. Whether to do it here is the coordinator's call.

### A4-2 (Low): derivation and output claims are primary-only

The 5A paragraph says the evidence must "claim the requested `artifact_digest`, `derivation_spec_digest` and `output_id`". A mount request carries only an artifact digest, and `prepareMountArtifact` checks no derivation spec or output ID. The proposed wording is: "claim the requested `artifact_digest`; for the primary artifact it must also claim the requested `derivation_spec_digest` and `output_id`". This finding stands even with A4-1 fixed. Docs mutant E3, which drops the evidence sentence, survives on 89da53d. The proposed diff pins the corrected sentence.

### A4-3 (Low): the guard can still be bypassed by aliasing in NewService

My audit-02 guard records `arsClient` selector uses and pins `Dependencies.ArtifactRegistry`. It does not see the bare identifier in NewService (`service.go:191,255`). Mutant G1 adds a `Service` field `arsSide`, sets it from the same local in the struct literal, and reads `/v1/artifacts/{d}/evidence` unverified through it. G1 survives. The proposed guard rule also records bare `arsClient` identifiers and pins them to the field declaration plus NewService's three uses: local, key and value. G1 and a variant G2 (`side := arsClient`) are killed.

The guard is still syntactic. A deliberate bypass through reflection or `unsafe` is out of its reach and is left to review and the red-team.

### Observations

- **O4-1. One 5A sentence is not pinned.** The sentence "ARS's index accepts one discovery record per artifact digest, so an ARS that follows its own registration contract always names the first registered document" is unpinned (docs mutant E4 survives). It is descriptive and true (`ars/index/fileindex.go:82-97`), so this is a nit.
- **O4-2. X15 and X12.** X15 (payload default branch message) is now killed, but incidentally: the O2-1 test pins the non-canonical refusal, which shares the `default:` branch with 404. A mutant that splits out only 404 would still survive. That is the remainder of O2-3 and is not security-relevant. X12 (39-character prefix compare, meaning 128 bits of the digest) still survives and is equivalent in practice.
- **O4-3. The A2-5 recommendation.** The writer's recommendation (the invocation names the evidence digest; revocation retires variants; the decision record names the admitted evidence) is sound, and I agree it is its own design item. Once A4-1 is fixed, the residual ARS choice is narrower: it covers only sealed variants of the *same* artifact digest, which is what 5A then says. Whether to track it is the coordinator's call.
- **O4-4. The new rendezvous test.** `TestPrivateReplayClaimRendezvousBoundsTheWaitForArrival` calls `releaseAndWait` from a goroutine. That function can call `t.Fatalf`, but only when workers have not returned 8 s after release, which this test cannot reach. With its 50 ms bound it never failed in 4,500 runs under 3× CPU oversubscription (plain, `-race`, `GOMAXPROCS=1`).

## 2. The delta `f8c1a73..89da53d` (9 paths, +295/-43)

- **No production code changed.** The manifest SHA-256s of `ars_blob_fetch.go` (`d4fab4f4…`), `service.go` (`e4737a64…`), `submit.go` (`c6ad3ead…`) and `policy_payload.go` (`682b0fb3…`) equal the audit-02 values.
- **My audit-02 diff is applied byte for byte.** I applied `02-audit-evidence/proposed-fix/proposed-test-fix.diff` to a clean `f8c1a73`:
  - `artifact_prepare_test.go` comes out as blob `c646ebb1…` and `reliable_submit_binding_test.go` as blob `e7ce8231…`. Both are identical to `89da53d`.
  - `ars_blob_fetch_test.go` differs only by 61 added lines, the O2-1 test. That hunk is identical to the writer's `03-evidence/delta/additions-beyond-auditor-diff.diff`.
- **The O2-1 test** (`TestARSBlobCallSitesRequestTheDigestExactlyAsGiven`) covers all five call sites with uppercase, space-padded and newline-terminated digests of the served bytes. It requires each call site's own "unavailable" mapping and zero ARS requests. It kills X17, X18 and my new N2 (Vault call site trims) and N3 (policy call site lowercases).
- **The O2-2 change** turns the arrival bound into a field, defaulting to the 8 s constant; the return bound is unchanged. The new test kills X22 and my new N1, where the timer ignores the field.
- **The docs and the root docs test** pin the new 5A, `:prepare`, storage, runtime-config and design sentences, and refuse the old over-claims. The writer's D3-D10 re-ran 8 of 8 killed, and my E1-E2 (old sentence re-added beside the new) were killed. E3 and E4 survive, as noted under A4-2 and O4-1.

## 3. Is the A2-5 wording accurate? (the writer's question)

| Claim in 5A / 03-repair §2 | Checked against | Result |
| --- | --- | --- |
| Discovery is read by artifact digest, unverified | `service.go:465-510` (`arsClient.get` → `decodeBoundedJSONResponse`) | True |
| "its artifact digest must equal the request's" | `service.go:545` primary; `mounts.go:253-264` mount | **Primary only (A4-1)** |
| Payload digest, type and intent must equal the signed evidence; the used value is the signed value | `service.go:600-620`; `:634` uses `TrimSpace(discovery.Payload.Digest)`, which equals the evidence value after the check | True |
| Evidence digest only selects the blob | The only production use of `discovery.Evidence.Digest` is `service.go:455` | True |
| Evidence must claim the requested `artifact_digest`, `derivation_spec_digest`, `output_id` | `service.go:552-570` primary only | **Primary only (A4-2)** |
| `artifact_digest` not derived from admission claims | `evidencev1.DeriveArtifactDigest` (payload, type, intent); AGS takes intent from the request (`ags/publish/service.go:97-101`) and admission fields from `req.Admission` (`:111-116`, `:240-248`) | True |
| AGS uploads evidence before registering | `ags/publish/service.go:178-192` (payload, evidence, manifest, discovery, descriptor; then `registerArtifact`) | True |
| ARS index is write-once per artifact digest; an honest ARS names the first | `ars/index/fileindex.go:82-97` (same tuple is idempotent, otherwise `ConflictError`); reads use `Lookup` by the requested digest and re-validate the record against it (`ars/api/server.go:335-360`, `:774`) | True |
| The demonstration: ES prepares whichever sealed variant discovery names | I re-ran the writer's scratch test on `89da53d` (`probe/probe-89da53d.txt`): `networkAccess=false` and `true` | True |

## 4. Validation on `89da53d` (user `ci`, umask 022, default signal dispositions, Go 1.26.5)

| Check | Result |
| --- | --- |
| `go test -count=1 -v ./es/admission/` | ok, 53.6 s: 1,210 pass, 4 skip, 0 fail. Against f8c1a73's 1,181 pass, no test is lost; there are 5 new top-level tests and 24 new subtests, and the same 4 skips (`tests/tip-vs-f8c1a73-es-admission-summary.txt`) |
| `-race ./es/admission/` | ok, 101 s, 0 race reports |
| Root `-run ARSBlobVerification` | 3 of 3 pass |
| `go vet ./es/... .` | clean |
| Rendezvous stress | 0 failures in 3,000 plain runs, 1,000 `-race` runs and 500 `GOMAXPROCS=1` runs, all under 12 busy loops on 4 CPUs |
| Code mutants (`mutants/results-89da53d.txt`), whole package, `-failfast` | **26 of 28 killed.** All 14 targeted (R-X1a, X1b, X1c, X4, X4c, X5, X6, X7, X19, X20, Y1, X17, X18, X22) were killed. New N1, N2 and N3 were killed. Sanity re-checks X2, X3, X8, X10, X11, X13, X14, Y2 and X15 were killed. **G1 survived (A4-3)**, and X12 survived (equivalent). The tree was clean after the run. |
| Docs mutants | Writer's D3-D10: 8 of 8 killed. Mine: E1 and E2 killed; E3 and E4 survived |

## 5. The proposed fix (`proposed-fix/proposed-fix-04.diff`, 10 files, +163/-25)

The diff contains:

- `mounts.go` +6: the A4-1 check.
- `ars_blob_fetch_test.go`:
  - new `TestSubmitRefusesAMountDiscoveryRecordForAnotherArtifact`, covering modes `""` and `async`. A control case submits and stages the requested mount. The substitute case is refused with 409, the other artifact's payload is never read, and there are no run effects.
  - the A4-3 guard rule.
- `reliable_submit_binding_test.go`:
  - "A B P substitution" is now refused by the resolver, before the mount payload read.
  - new `TestReliableSubmitBindingRefusesAMountWhoseVerifiedArtifactIsNotTheRequestedOne` keeps the binding's own requested-versus-verified check under test. This follows the audit-02 lesson on coverage that gets lost when an earlier check is added.
- Docs:
  - 5A wording for A4-1 and A4-2, pinned in the root docs test.
  - the four docs that described the residual.
  - `docs_contract_test.go`: the pin on "residual current-path limitation" is replaced by the new sentence.

Validation of the diff on `89da53d`:

- es/admission ok: 1,227 pass, 0 fail.
- vet is clean.
- Fix mutants: 4 of 4 killed:
  - FX1, the check removed;
  - FG1 (= G1) and FG2, against the guard;
  - FY3, the binding stops comparing requested with verified.
- Root package: the same 38 container-only failing names as `89da53d` (`proposed-fix/root-package-failing-sets.txt`). My first run surfaced the `docs_contract_test.go` pin, which the final diff updates.
- `-run Mount ./es/app/`: identical PASS/SKIP sets. The 3 end-to-end mount tests skip in this container.

The diff applies cleanly to the PR 12 merge, where es/admission is ok in 249 s and the root failing set is unchanged. It also applies to both PR 26 merges (`git apply --check`). The wording is a suggestion; the writer owns it.

## 6. Trial merges

All merges are local and clean (`trial-merges/merges.txt`):

- **PR 12 head `2c8bf35`** + `89da53d` gives tree `8069c879…`, which is the writer's.
  - Build and vet are ok, es/admission is ok in 258 s, and root docs pass 3 of 3.
  - The A4-1 probe reproduces on this merge.
- **PR 26 head `06ec54b`** + `89da53d` gives tree `29e1fae6…`, which is the writer's. es/admission is ok.
- **PR 26 moved during the audit** to `a88467f` (one commit, 1 file). Merged with `89da53d`, it gives tree `9fccba5b…`. Build, vet, es/admission and root docs are all ok.

## 7. What I did not run, and what I do not claim

- Container-dependent tests. I did not run the es/app end-to-end mount submits (they need Nomad and Docker; CI runs them) or the root-package TLS-witness tests, which fail in this container on `89da53d` too. CI was green on `89da53d`. The fix itself has no CI run, because nothing was pushed.
- Mutation coverage beyond the listed mutants. I did not re-run the audit-02 instrumented per-test probe, because the delta changes no production code.
- Whether AGS has really sealed more than one evidence document for any real artifact, or whether any real deployment has a mount whose discovery an ARS has substituted.
- A guard against reflection or `unsafe` access to `arsClient`.
- This is an audit, not the red-team, which is still due on the final head.

## 8. Confidence

| Area | Confidence |
| --- | --- |
| Provenance | 0.99 (manifest reproduced byte-identically by me, the writer and the closing run; heads re-fetched at the close) |
| Delta verification | 0.95 |
| A4-1 | 0.95 (demonstrated on the head and the PR 12 merge; consistent with four existing docs and a pinned test) |
| Proposed fix | 0.85 (tested locally on three trees; no CI run yet; the wording is a suggestion) |

Next step: the writer applies the fix, or an equivalent, plus the A4-2 wording. Then a narrow re-audit of that commit re-runs `mutants_fix.py`, `mutants_r3.py` and the docs mutants, followed by the red-team.
