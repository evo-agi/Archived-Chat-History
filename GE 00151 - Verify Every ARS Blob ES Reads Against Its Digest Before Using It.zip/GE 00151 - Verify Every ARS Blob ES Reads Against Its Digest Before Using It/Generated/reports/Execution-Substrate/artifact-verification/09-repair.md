# ES PR #29 repair after red-team 08, and trunk_dev sync

**Outcome:** done. Both red-team findings are fixed, and the branch now includes trunk_dev `76c030f` (PR #27). The new head is `91dbad69d6111a5bc57b71df5e3331d665d855a2`, a fast-forward from `e548b07`. The only product-code change is the red-team's own line in `newDependencyClient`, applied unchanged. I added a same-origin redirect case to the test, a 5A rule with its doc pin, and a hermetic `go list` environment for the guard. All 8 mutants are killed. No test that passes on trunk_dev fails on the new head.

| Item | Value |
| --- | --- |
| Repository / branch | `evo-agi/Execution-Substrate`, `claude/project-thread-urwhl2`, draft PR #29 |
| Previous head (red-teamed) | `e548b0726e9e1c4c2f0c964f1465019197b57b6a` |
| Commit 1 | `14572f1d2396fa8510854fe1619a9354879020cc`: merge of trunk_dev `76c030f` (PR #27). No conflicts. Its tree, `721bd01f…`, equals `git merge-tree e548b07 76c030f` |
| Commit 2 | `91dbad69d6111a5bc57b71df5e3331d665d855a2`, tree `d87d39a0770304bd39bde4cb9908e20f89334341`: the RT8-1 and RT8-2 fixes (5 paths, +252/-15) |
| New base | trunk_dev `76c030fa7872dd22dda731591878ef284c01bd9b` |
| Recipe | v2, source SHA-256 `c08597e2…a3ca` (checked before the run) |
| Textual diff SHA-256 | `a8d506524740be25531df90621ac01929c8ef1462ea61fadcba50d08418ef30c` |
| Canonical manifest SHA-256 | `dab632ae4b206bdab85dff9aad8fb9f448878e034aea68d72b921f42febcb19a`, 29 files, `76c030f..91dbad6` (the 28 paths from before, plus `es/admission/dependency_client_redirect_test.go`) |

The evidence is in `09-evidence/` next to this file. `SHA256SUMS.txt` lists every file.

## 1. What changed

| Finding | Change | Where |
| --- | --- | --- |
| RT8-1 (Low, pre-existing) | Red-team diff, unchanged. `newDependencyClient` sets `CheckRedirect` to return `http.ErrUseLastResponse`. A `3xx` from ARS or EGS is now the final answer. ES never requests the address it names. | `es/admission/service.go:844-849` (the `CheckRedirect` field at :847) |
| RT8-1 test | The red-team's `TestDependencyClientsDoNotFollowRedirects`, plus one case of mine: a same-origin redirect (`307` to another path on the dependency). Without that case, a policy that refuses only cross-host redirects (R2) or only plain-HTTP targets (R3) passes the test. With it, both fail. | `es/admission/dependency_client_redirect_test.go` |
| RT8-1 contract | Mine. 5A gains a rule: "ES's ARS and EGS clients do not follow redirects. A `3xx` answer is the dependency's final answer: ES refuses it like any other unexpected status and sends no request to the address it names, on the dependency or elsewhere." The rule is pinned in the docs test. | `contracts.md` 5A Rules; `ars_blob_verification_docs_contract_test.go` |
| RT8-2 (Low, test-only) | Red-team diff. The blob-read guard now also inspects every non-test file of every module package outside `es/` that `cmd/es` links, on linux/amd64 and darwin/arm64, with the same rules. The ARS server's route constant in `ars/api/server.go` is pinned as the only other `"/v1/blobs/"` literal that ES links. One change of mine: the `go list` call uses the package's existing `productionGoListEnvironment`, as the other production guards do. The red-team's version appended to `os.Environ()`. Mine also sets `GOTOOLCHAIN=local`, `GOPROXY=off` and `GOENV=off`, and drops inherited `GIT_*` variables, so the guard cannot download a toolchain or read a stray Git environment. | `es/admission/ars_blob_fetch_test.go:941-977`, `:1023-1059` |

**Review of the red-team diff before applying it:**

- Every caller of `dependencyClient.get` accepts only `200`. The callers are the trust model (`service.go:295`), the discovery read (`:476` switch), the health check (`:872`) and the verified blob read (`ars_blob_fetch.go:82` switch). So a returned `3xx` is refused on every path. No caller can mistake it for success.
- `get` cleans the path on the client side (`path.Clean`), so ServeMux path-cleaning redirects cannot occur for ES's own requests. No ARS, EGS or AGS handler issues redirects (red-team grep), so an honest deployment sees no change.
- ES's Nomad client (`submit.go:226`) is a separate client with no `CheckRedirect`. It is outside this finding and is O8-3, for the Nomad-lock PR #31, which adds the token header.
- The guard's listing uses `runtime.GOROOT()/bin/go`, as `workstream_c_guardrails_test.go` already does. This matters because the `go` on PATH here is 1.24.7 while `go.mod` needs 1.26.5. On David's Mac, too, 1.26.5 exists only in the module cache.
- PR #27 added `internal/callerauth` to the ES binary. The widened guard finds it and passes, so it needed no new pin. Mutant G3 shows that a read placed there is caught.

`09-evidence/delta/additions-beyond-redteam-both-fixes.diff` shows everything beyond `14572f1` plus `both-fixes.diff`: 48 added and 17 removed lines across four files. `service.go` is byte-identical to the red-team's version.

## 2. Validation (tree `d87d39a0…`)

| Command | Result |
| --- | --- |
| `go build ./...`, `go vet ./...`, `GOOS=darwin GOARCH=arm64 go vet ./es/... ./internal/... ./cmd/...`, `gofmt -l` | clean |
| `go test -count=1 ./es/admission/` (root, this container) | ok: 1,279 pass, 11 skip, 0 fail. That is 3 more than `e548b07`: the redirect test and its two subtests |
| `go test -count=1 ./...`, new head against trunk_dev `76c030f` | The same 254 failing names on both trees, and no failure only on one side. They fail only in this container (root user; Remote Alpha scripts, two SQLite old-binary tests, es/app script tests). No test that passes on trunk_dev stops passing. 113 passing names are new (`09-evidence/suite/full-module-tip-vs-trunk_dev.txt`) |
| `-race -count=3` on the redirect test and the guard | ok |
| Mutants: each applied to a clean worktree, must build (plus darwin vet), and must make its target test fail | **8 of 8 killed** (`09-evidence/mutants/mutant-results.txt`) |

| Mutant | What it does | Killed by |
| --- | --- | --- |
| G1 (red-team) | New `internal/blobcache` package that reads `"/v1/blobs/"` unverified, called from es/admission with `s.cfg.Dependencies` | guard: blob literal outside the helper |
| G1b (red-team) | Same, but with `s.cfg` passed whole, the route split as `"/v1/blob"+"s/"`, and `http.DefaultClient` | guard: ARS config read outside NewService |
| G3 (mine) | G1b placed in `internal/callerauth`, the package PR #27 added | guard |
| G4 (mine) | G1b with the outside package imported only by a `//go:build darwin` file | guard (darwin/arm64 listing) |
| R1 (red-team) | `CheckRedirect` removed | redirect test |
| R2 (mine) | Refuses only redirects that leave the dependency's host | redirect test, same-origin case. **Survives the red-team's original test** |
| R3 (mine) | Refuses only redirects to plain HTTP | redirect test, same-origin case. **Survives the red-team's original test** |
| D1 (mine) | The new 5A redirect rule deleted | root docs pin |

The R2 and R3 survival runs against the original test are in `mutants/mutant-results-original-test.txt`.

## 3. Provenance

This followed `provenance-and-audit-evidence.md` §5.5:

1. Recorded the remote tip `e548b07`. Merged `origin/trunk_dev` (`76c030f`) locally as `14572f1`.
2. Confirmed `origin/trunk_dev` is still `76c030f`. Nothing was staged.
3. Ran `git reset --mixed 76c030f` and pinned the upstream to `origin/trunk_dev`.
4. Ran v2 twice into a fresh 0700 directory. The two outputs are byte-identical.
5. Ran `git reset --mixed 14572f1`, then `git add -A` (5 paths), and committed once. `git status --porcelain` is empty afterwards.

I then checked the commit against the manifest:

- `git diff --name-only 76c030f 91dbad6` equals the 29 manifest paths.
- Every committed blob hashes to its manifest entry, and every one is mode 100644.

The push `e548b07..91dbad6` was a fast-forward. The tested working tree is the committed tree.

## 4. PR 12 line

- `91dbad6` with PR #32's head `4416699`: one conflict, in `PLANS.md`.
- trunk_dev `76c030f` with `4416699` alone gives the same `PLANS.md` conflict. It comes from PR #27, not from PR #29.
- `e548b07` with `4416699` merges cleanly, as the red-team found (tree `a772e0e0…`).

Whichever of #29 and the PR 12 line lands second re-runs the blob-read guard. That guard now covers the whole ES binary.

## 5. Scope for the red-team re-check and the narrow audit

The delta is `e548b07..91dbad6`:

1. The trunk_dev merge `14572f1`. Its tree equals `git merge-tree e548b07 76c030f`.
2. The fix commit: 5 paths. `service.go` is identical to the red-team diff. The test and doc additions are in `additions-beyond-redteam-both-fixes.diff`.

Points to check:

1. Re-run the red-team's redirect probes and the live-stack probe on `91dbad6`.
2. The same-origin case and the 5A rule.
3. The hermetic environment in the guard's listing.
4. Re-run `mutants/mutants_09.py.txt` (it takes the worktree path and the output path).

## 6. Non-claims

- The guard is still syntactic. It cannot see reflection, `unsafe` or linkname. It also cannot see a direct read of ARS's storage through `ars/store`, which re-hashes on read itself.
- The Nomad client still follows redirects (O8-3). That belongs with PR #31.
- es/app's Docker and Nomad tests skip in this container. CI runs them.
- O8-1 (non-canonical evidence encodings) feeds the A2-5 design item and is not changed here.
