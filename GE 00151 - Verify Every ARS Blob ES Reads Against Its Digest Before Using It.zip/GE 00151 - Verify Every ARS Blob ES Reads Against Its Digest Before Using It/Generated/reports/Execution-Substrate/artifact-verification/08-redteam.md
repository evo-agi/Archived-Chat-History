# ES PR #29 red-team (08): ARS blob byte verification

| Item | Value |
| --- | --- |
| Repository / PR | `evo-agi/Execution-Substrate`, draft PR [#29](https://github.com/evo-agi/Execution-Substrate/pull/29), branch `claude/project-thread-urwhl2` |
| Target head | `e548b0726e9e1c4c2f0c964f1465019197b57b6a`, tree `1c68dd98cf8efbb7af696d79b009f40957af5efe` (PR head on GitHub at the start and at the close) |
| Base | `trunk_dev` `8ba1edb8af52214ec1bfbb5b93e5a4dc4e51b1ce` (unchanged at the start and at the close) |
| Role | Red-team thread, separate from the writer and from the correctness auditor. Read-only toward the repo: nothing pushed, no PR edit, no comment |
| Window | 2026-11-23, 19:32Z to about 20:15Z |
| Evidence | `08-redteam-evidence/` next to this file (`SHA256SUMS.txt` lists every file) |

## Verdict

**HOLDS, with two Low findings. Both have a failing regression test and a tested fix.**

*Re-check of the repaired head `91dbad6`: see Addendum A at the end. RT8-1 is closed. RT8-2 is closed for the reported case, and a residual RT8-3 (Low, test-only) is open, with a fix.*

*Head `06e84e5`: see Addendum B. RT8-3 is closed, and no red-team finding is open.*

I found no way to make ES use bytes that do not hash to the digest it asked for. That held under substitution, truncation, extension, lying lengths, gzip encoding, digest-spelling tricks, re-encoded evidence, 560 concurrent Submits against an ARS that flaps between good and bad answers, about 3.0 million fuzz executions, and a live attack on a local stack of the real ES, ARS, EGS and AGS services.

| ID | Severity | Type | Summary | Status |
| --- | --- | --- | --- | --- |
| RT8-1 | Low | Security risk, pre-existing | ES's ARS and EGS clients follow HTTP redirects, including to plain HTTP on any host and port. A compromised ARS can make ES send GET requests anywhere ES can reach and learn their status through ES's errors | Fix + regression test attached; recommended in this PR |
| RT8-2 | Low | Test/guard gap, residual of A2-4 | The blob-read guard walks only `es/`. An unverified ARS read in a module package outside `es/` that ES links passes every guard and test | Test-only fix attached; recommended in this PR |

---

## 1. Plain-language summary for David

I tried to break the new check from the side of a registry (ARS) that has been taken over. The check itself held every time: whatever ARS sent, ES either used exactly the right bytes or refused before anything happened. I ran it against the real ES service talking to a real ARS over encrypted connections, with a fake "evil ARS" in between.

I found two smaller problems.

1. **ES obeys "go look over there" answers.** If ARS answers "the file has moved to this other address", ES goes there, even to an unencrypted address on another machine. The fingerprint check still saves the file contents. But an evil ARS could use ES to knock on other internal services' doors, and ES's error messages would tell it what answered. This is older than PR 29. The fix is six lines that tell ES to treat such an answer as a refusal.
2. **The safety net for "no other file reads" has a hole.** The test that makes sure nobody adds a second, unchecked way to read registry files only looks inside the `es/` folder. Code in a shared folder that ES also uses would slip past it. The fix makes the test look at every folder ES is built from. It is test-only.

Both fixes are written and tested: they fail on today's PR and pass with the fix, and nothing else breaks. I recommend adding both to PR 29 before your review.

---

## 2. Target and provenance

- Recipe `governed_execution_audit_patch_manifest_v2.py`, SHA-256 `c08597e2…a3ca`, checked with `sha256sum -c` before the opening and the closing run; not edited.
- Procedure: `provenance-and-audit-evidence.md` §5.3 in a fresh clone (`/opt/rt/es-prov`): fetch, PR tip equals `e548b07`, `8ba1edb` is an ancestor, `checkout -f -B`, clean status, `reset --mixed 8ba1edb`, upstream pinned to `origin/trunk_dev`, two runs into a fresh 0700 directory.
- Opening (19:35Z): two runs byte-identical; canonical manifest SHA-256 `6e91a985c446c4d24ce7f0a38dd06d70da1b4dd6d3501fe3f11fe5745d4d9a35`, 28 files. Byte-identical to the writer's `07-evidence/manifest/1.json`.
- Closing (20:05Z): byte-identical to the opening. PR head still `e548b07`, `trunk_dev` still `8ba1edb`.
- PR on GitHub: head `e548b07`, base `trunk_dev` `8ba1edb`, draft, 28 files.
- Every attack ran in separate clones. The provenance clone was never used for tests.

Provenance confidence: 0.99.

## 3. Threat model and method

The attacker is a compromised or malicious ARS. It holds ARS's TLS key and answers ES's requests however it likes. It also tries forged or stale inputs: other sealed artifacts, old or re-encoded evidence, odd digests. Targets were local only (this container); nothing outside systems David owns was touched.

Read before attacking: the whole audit chain (01 to 07); `ars_blob_fetch.go`; every caller of the five reads and of the discovery read; `newDependencyClient` and `dependencyClient.get`; `readBoundedResponseBody`; the evidence contract (`internal/contracts/evidence/v1`: canonical form, `Validate`, `Verify`); the trust-model check; the mount archive validator; the policy and runtime archive parsers; the reliable-submit replay hydration path; the guard test.

Environment: Linux cloud container, Go 1.26.5, tests as unprivileged user `ci` (uid 1500, gid 1600) under an emptied environment, `umask 022`, HUP/INT/QUIT/TERM/PIPE/XFSZ at default, `GOPROXY=off`.

Baselines on the exact head: `go test ./es/admission/` 1,275 pass, 0 fail, 12 skip (the skips need FUSE, supplementary groups or opt-in stress, same set in every run); `go test ./es/app/` 496 pass, 0 fail, 84 skip (Docker/Nomad not available here).

The parallel delta check (`08-audit.md`) counts 1,294 pass and 4 skip in es/admission on the same head. *Inference:* the difference is environmental: that container runs eight of the tests mine skips, and their subtests add to its total. My comparisons are always tip against fix in my own environment, with identical skip sets.

---

## 4. Findings

```text
RED-TEAM FINDING RT8-1
Type / Severity: security risk (pre-existing, not introduced by PR 29) / low
Current contract: 5A says ES trusts ARS for no blob bytes; the ES-to-ARS channel is mTLS with a
  pinned server name (newDependencyClient). Nothing says ES follows ARS's redirects.
Path and line: es/admission/service.go:807-846 at e548b07 (http.Client at :841 has no CheckRedirect);
  identical on base 8ba1edb (:817) and on 036d507. Used for ARS (:191) and EGS (:195).
Evidence:
  1. Unit probe with the production constructor and a real mTLS "ARS" that answers 302 to a
     plain-HTTP origin (logs/redirect-unit-probe-tip.log): ES followed both the blob read and the
     discovery read to the plain origin; the verified read returned the bytes the plain origin served.
     A redirect to another TLS origin is stopped by the pinned ServerName (same log, second test).
  2. Live local stack (logs/live-stack-tip.log): real ES, ARS, EGS and AGS apps in-process with their
     real mTLS config and a fake Nomad. A compromised-ARS interposer holding ARS's server key sits in
     front of the real ARS. mode=redirect: ES's public submit returned 202, Nomad got a registration,
     and the plain-HTTP origin received "GET /redirected/v1/blobs/sha256:1efe…:bytes".
Impact: byte integrity still holds, because the bytes are hashed wherever they come from (PR 29 is what
  guarantees that). New capability for a compromised ARS or EGS: make ES send GET requests to any origin
  ES can reach (loopback admin APIs, LAN hosts), over cleartext, and read the outcome back through ES's
  public errors. The primary payload read even puts the status number in its message
  ("artifact payload read returned status %d", submit.go:147). Blind SSRF; no ES secret travels with
  the request (ES sends no credential header to ARS; the client certificate is not offered over plain
  HTTP).
Required correction: treat a redirect as the dependency's final answer:
  CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }
  in newDependencyClient, plus TestDependencyClientsDoNotFollowRedirects
  (proposed-fix/redirect-fix.diff, 2 files, +134 lines).
Regression test: fails on e548b07 (both clients follow; the verified read returns bytes; logs/
  redirect-test-on-tip.log) and passes with the fix, also under -race (logs/redirect-test-with-fix.log).
  With the fix the live-stack redirect is refused (403, Nomad 0, plain origin 0 hits) and the honest
  pass-through still returns 202 (logs/live-stack-with-fix.log).
Uncertainty: whether anything on the Remote Alpha host answers a blind GET with a side effect is
  Unknown (not probed; the box was out of scope). No ARS or EGS server code issues redirects
  (grep of ars/, egs/, ags/, es/, internal/, cmd/), so the fix changes nothing for an honest deployment.
```

```text
RED-TEAM FINDING RT8-2
Type / Severity: test/guard gap (residual of A2-4, whose scope remark was not acted on) / low
Current contract: 5A "These are all of ES's reads of GET /v1/blobs/{digest}"; the guard
  TestFetchVerifiedARSBlobIsTheOnlyARSBlobReadInES enforces it for ES production code.
Path and line: es/admission/ars_blob_fetch_test.go:849 at e548b07: filepath.WalkDir(esRoot, …) walks
  es/ only. cmd/es links module packages outside es/: internal/httpx, internal/observability,
  internal/contracts/*, egs/model, ars/api, ars/store, ars/index, cmd/es (go list -deps ./cmd/es).
Evidence: two mutants pass the guard AND the whole es/admission package, internal/..., and the root
  docs pins (mutants/, G1-whole-es-admission-internal.log):
  G1: new package internal/blobcache with Read(ctx, deps esconfig.DependenciesConfig, digest) that reads
      deps.ArtifactRegistry and GETs BaseURL+"/v1/blobs/"+digest+":bytes" unverified; es/admission
      gains fetchArtifactSBOM calling blobcache.Read(ctx, s.cfg.Dependencies, digest). No arsClient,
      no ArtifactRegistry selector and no "blobs" literal appear under es/.
  G1b: the same with s.cfg passed whole and the route split as "/v1/blob"+"s/".
  This is the plausible honest mistake too: a shared ARS client package in internal/.
Impact: merge-time safeguard only; production code at e548b07 has no such read.
Required correction: also walk every module package that cmd/es links, on linux/amd64 and darwin/arm64,
  with the same rules; the ARS server's own route constant (ars/api/server.go, package scope,
  "/v1/blobs/") is pinned as the only other "blobs" literal ES links
  (proposed-fix/guard-scope-fix.diff, test-only, +87/-15).
Regression test: with the fix, G1 and G1b both fail the guard; the tip passes.
Uncertainty: a syntactic guard still cannot see reflection, unsafe or linkname (as audits 02/04 said),
  nor a direct read of ARS's storage directory through ars/store (which re-hashes on read itself,
  filesystem.go:57-85, so integrity would hold).
```

---

## 5. Attacks that held

| # | Attack | How | Result |
| --- | --- | --- | --- |
| 1 | Substitution, truncation, extension, empty body | Existing tests re-run; flapping-ARS stress (#5); live stack mode=substitute | Refused every time with no run effects. Live stack: 403 `admission_policy_input_unavailable`, Nomad 0 (the stack's default policy reads the payload, so the fixed policy error applies) |
| 2 | Lying `Content-Length` (shorter, longer), chunked, `Content-Encoding: gzip`, 206, 3xx, malformed status lines and headers | `FuzzRedTeamVerifiedFetchRaw`: a raw TCP server answers with fuzzed bytes; property: bytes returned only if they hash to the canonical digest and fit the limit, no bytes on error, zero requests for a non-canonical digest | 309,089 executions, no violation (`logs/FuzzRedTeamVerifiedFetchRaw.txt`). gzip: Go decodes transparently; ES hashes and uses the decoded bytes and the limit applies to them (`logs/gzip-length-probe.log`) |
| 3 | Digest spelling: uppercase, prefix, whitespace, other algorithms, Unicode digits, arbitrary strings | Same fuzzer (fuzzed digest strings), plus the existing whole-digest and call-site tests | No request for any non-canonical digest; whole-digest comparison (`ars_blob_fetch.go:94`) |
| 4 | Replay of old or other sealed records | Code read: discovery bound to the requested digest on both paths (`service.go:545`, `mounts.go:261`); signer allowlist, signer and artifact revocation (`service.go:708-740`); single provenance key ID (`record.go:65`). Evidence re-encoding probe (O8-1) | Only the already documented variant choice (A2-5 residual) remains. A whitespace-padded `key_id` passes `Verify` but fails the exact allowlist match (fail closed). Not run: an evidence document sealed by a rotated key (code read only) |
| 5 | Races between discovery and fetch; concurrent Submits | Primary path does one discovery read per Submit (`resolved_execution_plan.go:438` → `service.go:433`), and policy and staging share it. Stress: 56 concurrent Submits with a mount, ARS answering each payload and mount read with signed, substituted, truncated, extended, gzip-of-other or short-`Content-Length` bytes; both payload paths (Submit's own read and policy read); 5 rounds under `-race` | 560 Submits: every success staged exactly the signed payload and mount; every refusal had no run of its own; Nomad registrations and staged runs equal successes; no race report (`logs/concurrency-stress.log`) |
| 6 | Retries | Code read: ES never retries an ARS read; Go's transport re-sends an idempotent GET only after a reused connection fails before any answer, and that answer is verified like any other | No gap |
| 7 | Redirects | Unit and live-stack probes | **RT8-1** |
| 8 | Path and symlink tricks in mount archives | `FuzzRedTeamMountArchiveValidation`: invariants on every accepted archive (clean relative names, no `..`, no duplicate files, no special mode bits, budgets kept, input bytes carried) | 1,767,481 executions, no violation. Links and device files are refused (`mounts.go:609`). Staging custody itself was not re-attacked (unchanged by PR 29; red-teamed in PR 20) |
| 9 | Parser fuzzing of evidence and discovery decoding | `FuzzRedTeamEvidenceAndDiscoveryDecode` (strict decode, then `Validate`) | 902,040 executions, no panic |
| 10 | Guard bypasses | In-package aliases, second clients and copies: covered by audits 02/04 and still killed. New: code outside `es/` | **RT8-2** |
| 11 | Policy versus runtime archive parsing (does the policy inspect what runs?) | Code read: policy (`policy_payload.go:101`) and runtime extraction (`supervisor.go:636-643`) both use `es/internal/staticarchive` with the same `Namespace`; the policy side is stricter (16 MiB decoded, 64 entries) | No differential found. Not fuzzed |

## 6. Observations (no change required for this PR)

- **O8-1. One sealed claim set has unlimited evidence encodings.** The seal covers the canonical claims (trimmed strings, sorted sets; `claims.go:19-36`, `execution_claims.go:54-67`), and the signature is base64 that Go decodes ignoring newlines (`record.go:79`). The probe (`logs/evidence-variant-probe.log`) padded the environment allowlist entries, the schema version, the target platform and the seal's content digest, put a newline into the signature, and served the result under its own digest with discovery pointing at it. `Verify` accepted it and Submit admitted it. **No permissive effect found:** every raw field ES uses is either trimmed or compared exactly with a canonical value, so padding fails closed (`service.go:545-570`, `:600-628`, `:789`; `resolved_execution_plan.go:451`, `:458`). Two consequences for the A2-5 design item (with gaps 2 and 3): a decision record should name the seal's canonical content digest rather than the evidence blob digest, since the blob digest does not identify the claims uniquely; and ES should either consume canonical claims or refuse non-canonical evidence, so that a future raw use cannot drift from what was signed. Check AGS's stored form before making the second one a rule (Unknown whether AGS stores null or empty sets).
- **O8-2. Test clients do not model transparent gzip.** `newResolvedPlanDependencyClient` uses a recorder round-tripper, so a gzip-encoded good answer is refused in those tests while production accepts it after decoding. That is correct production behaviour, and no test depends on it.
- **O8-3. For the Nomad lock thread (cross-reference, not PR 29).** Draft PR #31 (`78fd064`) adds an `X-Nomad-Token` header to ES's Nomad client, which also has no `CheckRedirect`. Go forwards custom headers on redirects, so a redirect from whatever answers on Nomad's address would carry ES's Nomad token to another origin. *Inference:* the practical gain is small, because whoever answers as Nomad already receives the token, but the same one-line policy and a test would make it explicit there too.
- **O8-4. The private replay hydration path** (`reliable_submit_replay_hydration.go:655-690`) holds payload and mount bytes from authenticated replay records. It has no runtime caller (`reliable_submit_replay_private.go:212`), so it was not attacked.

## 7. Proposed fixes and their validation

| File | Content | SHA-256 |
| --- | --- | --- |
| `proposed-fix/redirect-fix.diff` | RT8-1: `service.go` +6 (CheckRedirect), new `dependency_client_redirect_test.go` (+128) | `ccc350ef6f4f51556419a5d16b6a9a36d9aed19ca2ff83e123ea4b800c669456` |
| `proposed-fix/guard-scope-fix.diff` | RT8-2: `ars_blob_fetch_test.go` (+87/-15), test-only | `a173645bf7fcb8e67a8286d90c538ddad80b56050ae591083f1077c8745bf60e` |
| `proposed-fix/both-fixes.diff` | Both together, against `e548b07` | `2f81e9cdf9e8b4730a555d2bbde2903548fb210d66478ed68d9d60409ae67b19` |

| Check (on `e548b07` + both fixes unless stated) | Result |
| --- | --- |
| `gofmt`, `go vet ./es/...`, `GOOS=darwin GOARCH=arm64 go vet ./es/admission/` | clean |
| `go test -count=1 ./es/admission/` | 1,278 pass, 0 fail, 12 skip (tip: 1,275 / 0 / 12; +3 = the new test and its two subtests; same skips) |
| `go test -count=1 ./es/app/` with the redirect fix | 497 pass, 0 fail, 84 skip (tip: 496 / 0 / 84; +1 = the live probe; same skips) |
| Redirect regression test | fails on tip, passes with fix, passes under `-race` |
| Guard regression | G1 and G1b fail the fixed guard; tip passes it |
| Live stack with redirect fix | redirect refused (403, Nomad 0, plain origin 0 hits); honest pass 202 |
| PR 12 line: PR #32 head `4416699` + `e548b07` (clean merge, tree `a772e0e0…`), then both fixes | applies cleanly; build and vet clean; guard, redirect test and every ARS-blob test pass (`logs/pr12-trial-merge-targeted.log`). Full `es/admission` not run on this merge |

## 8. Coverage I could not get

- **Linux box:** not used. It is reachable only through David's Mac, and PR 29 has no box-facing surface beyond Submit refusals. So whether a blind GET from ES on the Remote Alpha host could reach anything with a side effect (RT8-1) is Unknown.
- **Docker/Nomad end-to-end:** none in this container. The live stack used the real ES, ARS, EGS and AGS apps with a fake Nomad. es/app's 84 Docker/Nomad tests skipped here; CI ran them green on the PR head (per audit 06 and the writer, not re-observed by me).
- **macOS:** not run (darwin vet only).
- **Fuzzing depth:** 150 s per harness (about 3.0 million executions in all). Longer campaigns could still find something.
- **Not attacked:** reflection, `unsafe` or linkname guard bypasses; staging custody (unchanged; PR 20 red-team); the policy/runtime parser pair by fuzzing; an evidence document sealed by a rotated key (code read only); the full es/admission suite on the PR 12 merge.

## 9. Recommendation

1. The writer applies `both-fixes.diff` (or equivalent) to PR 29. RT8-1 changes product code: one `http.Client` field, in the same ES-to-ARS trust boundary this PR hardens. Fixing it here follows the project's "no revisit later" rule. If the coordinator prefers a separate PR, it needs a machine-enforced trigger, and the regression test is that trigger.
2. A narrow re-audit of that commit. Then I re-run the two regression probes and the live-stack probe on the new head.
3. Then David's product review.
4. Forward O8-3 to the Nomad lock thread, and O8-1 to the A2-5 design item.

## 10. Confidence

| Area | Confidence |
| --- | --- |
| Provenance | 0.99 (manifest reproduced, opening equals closing, PR head unchanged) |
| "Byte verification holds" | 0.9 (unit, stress, fuzz and live-stack evidence; limits in §8) |
| RT8-1 | 0.95 that it is real (reproduced in two independent harnesses); impact on the real host is Unknown |
| RT8-2 | 0.95 (two surviving mutants; the fix kills both) |
| Proposed fixes | 0.85 (whole es/admission and es/app runs here; no CI run, because nothing was pushed) |

## 11. Effects and sensitive material

No repository write, push, PR edit, comment or merge. Only this report and `08-redteam-evidence/` were written, to the project folder. Probes, mutants and fixes lived in scratch clones under `/opt/rt` and were never committed. Every key and certificate was generated in-process for tests. The evidence holds manifests, test logs, probe and mutant sources, and diffs. No secret was read or produced.

## 12. Evidence index (`08-redteam-evidence/`)

- `provenance/`: `1.json`, `2.json`, `close.json`, `run-1.out`, `run-close.out`
- `probes/`: probe sources (`*.go.txt`, scratch only): redirect (unit), live stack, `stack-interposer-hook.diff` (the scratch hook it needs in `submit_integration_test.go`), concurrency stress, evidence variant, gzip and length, fuzz harnesses
- `mutants/`: G1 and G1b sources, and G1's whole-package run
- `proposed-fix/`: the three diffs in §7
- `logs/`: every result cited above

---

## Addendum A: re-check of the repaired head `91dbad6` (2026-11-23, 20:25Z to 20:45Z)

Requested by the coordinator after the writer's `09-repair.md`. Evidence: `08-redteam-evidence/recheck-91dbad6/` (`SHA256SUMS.txt` inside).

**Result: RT8-1 is closed. RT8-2 is closed for the case I reported, but my own proposed guard fix still had gaps. Five more ways past the guard pass on `91dbad6`; I file them as RT8-3 (Low, test-only), with a fix attached.** Byte verification itself is unchanged and still holds.

### A.1 Target and provenance

- PR head `91dbad69d6111a5bc57b71df5e3331d665d855a2`, tree `d87d39a0…`, base `trunk_dev` `76c030fa…` (PR #27). This is a fast-forward from `e548b07`. The merge commit `14572f1` has tree `721bd01f…`, which equals `git merge-tree e548b07 76c030f`.
- Recipe v2 hash checked before each run, and the recipe was not edited. The §5.3 procedure was run in the fresh provenance clone. Both opening runs are byte-identical and equal to the writer's `09-evidence/manifest/1.json`: manifest `dab632ae4b206bdab85dff9aad8fb9f448878e034aea68d72b921f42febcb19a`, 29 files, textual diff `a8d50652…f30c`. The closing run equals the opening one. The PR head and `trunk_dev` were unchanged at the close.
- The fix commit touches 5 paths. `es/admission/service.go` is byte-identical to my RT8-1 version. Everything else is in the writer's `additions-beyond-redteam-both-fixes.diff`, which I reviewed line by line.

### A.2 RT8-1: closed

- The writer's extended `TestDependencyClientsDoNotFollowRedirects` fails on `e548b07` (`writer-redirect-test-on-e548b07.log`: final status 200, and the verified read returns the other origin's bytes). It passes on `91dbad6`, in the full suite and in `-race -count=3`.
- The same-origin `307` case is a real improvement: it fails a policy that refuses only cross-host redirects or only plain-HTTP ones. The writer's mutants R2 and R3 show this.
- The new 5A rule matches the code, and the docs test pins it.
- Live stack, same probe as §4 on `91dbad6` (`live-stack-91dbad6.log`): the redirect mode gets `403 admission_policy_input_unavailable`, with Nomad +0 and 0 hits on the plain origin. The honest pass gets 202 before and after.

### A.3 RT8-2: the case I reported is closed; RT8-3 is still open

The writer's change to my guard diff is good. The `go list` call now uses `productionGoListEnvironment`, so an inherited `GOFLAGS`, `GOTOOLCHAIN`, `GOENV` or `GIT_*` setting cannot steer it. My original mutant (an unverified read in `internal/blobcache`) is killed on `91dbad6`.

**RT8-3. Low. Test/guard gap, a residual of RT8-2, carried in from the red-team's own diff.** The widened guard skips every linked directory under `es/`, on the assumption that the `es/` source walk already covers them. That walk skips `testdata`, `_*` and `.*` directories. The listing also keeps only main-module packages, and it covers two platforms where the repository's other production guards cover three. Each mutant below puts an unverified `"/v1/blobs/"` read, which reads `cfg.Dependencies.ArtifactRegistry`, into a package that `cmd/es` really links (checked with `go list -deps` and with `go build`):

| Mutant | Where the read lives | `91dbad6` guard | Hardened guard |
| --- | --- | --- | --- |
| C1 (control) | `internal/blobcache` | killed | killed |
| G5 | `es/_blobcache` | **passes** | killed |
| G6 | `es/admission/testdata/blobcache` | **passes** | killed |
| G6b | `es/.blobcache` | **passes** | killed |
| G7 | nested module `internal/blobmod` (own `go.mod`, replaced in the root `go.mod`) | **passes** | killed |
| G8 | `internal/blobcache`, imported only by a `//go:build linux && arm64` file. linux/arm64 is a real ES target: the control-plane image on Apple Silicon, and the other production guards list it | **passes** | killed |
| G9 | a module replaced with a directory outside the repository | **passes** | refused: "outside the repository, which this guard cannot inspect" |

G5, G6 and G6b need nothing but a new directory. G7 and G9 also need a `go.mod` edit, and G8 needs a build-tagged file. All of them would stand out in review, which is why this is Low.

**Fix (test-only):** `recheck-91dbad6/proposed-fix/guard-walk-hardening.diff`, SHA-256 `22c5f116c8eece8c5eeb54d7e86de2963cc9a7d2fb7da1efd465cf5649b46a12`. It applies to `91dbad6` and changes one file, `ars_blob_fetch_test.go` (+162/-22). The diff does four things:

- The guard inspects every directory that `cmd/es` links from inside the repository, including those under `es/`. Each file is inspected once, keyed by its resolved path, so the two walks never record a site twice.
- The listing keeps any non-standard package whose directory is inside the repository. That covers nested and replaced modules, not only the main module.
- It refuses a linked module that is replaced with a directory outside the repository.
- It lists three targets, darwin/arm64, linux/amd64 and linux/arm64, the same set as `loadTypedProductionPackages`.

The listing helper now returns an error instead of calling `t.Fatal`. A new permanent test, `TestESBinaryRepositoryPackageDirsSeesEveryLinkedRepositoryPackage`, builds a small module shaped like this repository and checks the helper against both cases: the directories the source walk skips, and the outside replacement.

Validation of the fix, as user `ci` with Go 1.26.5:

- The guard passes on `91dbad6` with the fix.
- C1 and G5 to G9 are all killed or refused (`mutant-*-on-fix.log`).
- Four mutants of the new helper are each killed by its self-test (`selftest-mutants.log`): skip directories under `es/` again, keep main-module packages only, drop linux/arm64, and accept outside replacements.
- Full `go test -count=1 ./es/admission/`: 1,281 pass, 0 fail, 12 skip. Without the fix it is 1,278 / 0 / 12. The difference is the new test and its two subtests, and the skips are the same.
- `-race -count=3` on the guard and the self-test passes. vet passes on linux and on darwin/arm64, and gofmt is clean.

### A.4 Updated verdict and next step

**HOLDS.** RT8-1 is closed. RT8-2 is closed for the case reported in §4. RT8-3 (Low, test-only) is open, with a tested fix.

I recommend that the writer applies `guard-walk-hardening.diff` in PR 29. It is test-only, and it finishes the guard this PR introduced. After that, a narrow delta check, and I can re-run `mutants/run-mutant.sh.txt` against the new head. RT8-3 does not touch product code. If the coordinator decides it should not hold up David's review, the "no revisit later" rule still needs it to land in this PR or behind a machine-enforced trigger.

Coverage added by this re-check: the redirect test on the old and new heads, the live stack on `91dbad6`, full es/admission on `91dbad6` with and without the hardening, 7 guard mutants (each run on both heads), and 4 helper mutants. Still not covered: es/app's full suite on `91dbad6` (only the live probe ran here); CI on `91dbad6`, which was still running at 20:40Z and which I did not observe finishing; and the §8 limits. Confidence: RT8-1 closed 0.97; RT8-3 real 0.95; the hardening fix 0.85 (no CI run on it, because nothing was pushed).

Effects: none outside the project folder. Nothing was pushed, and no PR edit or comment was made. Mutants ran in throwaway copies under `/opt/rt`, which were deleted after each run.

---

## Addendum B: RT8-3 on head `06e84e5` (2026-11-23, 20:47Z to 21:00Z)

Requested by the coordinator after `11-repair.md`. Evidence: `08-redteam-evidence/recheck-06e84e5/` (`SHA256SUMS.txt` inside).

**Result: RT8-3 is closed. All three findings, RT8-1, RT8-2 and RT8-3, are closed on `06e84e5`. Verdict: HOLDS, with no open red-team findings.**

- **Target.** PR head `06e84e517964360698052f39ed757b74c83d939a`, tree `7ba2f726…`, base `trunk_dev` `76c030f` (unchanged). This is a fast-forward from `91dbad6`.
- **Provenance.** Recipe v2 hash checked, and the recipe was not edited. Ran §5.3 in the fresh clone. Both opening runs are byte-identical and equal to the writer's `11-evidence/manifest/1.json`: manifest `5e3590e2b1d3bec27c8816c8d5cd3b1dd334dbdf7f95f7525179f33b14130043`, 29 files. The closing run equals the opening one, and the PR head was unchanged at the close.
- **Delta.** `91dbad6..06e84e5` touches one path, `es/admission/ars_blob_fetch_test.go`. The new file equals `91dbad6` plus `guard-walk-hardening.diff` plus 8 more lines, which resolve the ES root with `filepath.EvalSymlinks` before walking. Nothing else differs.
- **The writer's 8 lines are a real fix to my diff.**
  - Control run (`symlink-checkout-control-hardening-without-root-resolution.log`): with my diff alone, the guard fails falsely when it runs from a symbolic-link path to the checkout, because `ars/api/server.go` is labelled `../../rc-fix/ars/...`.
  - With the head's version, the guard and the self-test pass from that path (`symlink-checkout-06e84e5.log`).
  - The change cannot open the guard: if `es` itself resolved elsewhere, the existing `Base == "es"` check would still refuse.
- **Guard mutants on `06e84e5`.** C1, G5, G6, G6b, G7 and G8 are all killed. G9 (a module replaced with a directory outside the repository) is refused.
- **One new mutant, G10.** `internal/blobcache` committed as a symbolic link to a directory outside the repository. `go build` links it, and the guard refuses it ("outside the repository, which this guard cannot inspect"), because the path check resolves links on both sides.
- **Self-test mutants.** M1 to M4 are all killed by `TestESBinaryRepositoryPackageDirsSeesEveryLinkedRepositoryPackage`.
- **Suite.** Full `go test -count=1 ./es/admission/` as user `ci`: 1,281 pass, 0 fail, 12 skip, the same skips as on `91dbad6`. `-race -count=3` on the guard, the self-test and the redirect test passes.
- **Nit in `11-repair.md`, for the writer.** The report quotes my diff's SHA-256 as `22c5f116…6b12`. It is `22c5f116…6a12`. The applied bytes match the diff, so only the report text is wrong.

Not covered by this addendum: es/app and the root package (unchanged by this one-file delta); CI on `06e84e5` (not observed); the §8 limits. Confidence that RT8-3 is closed: 0.95. Effects: none outside the project folder, nothing pushed, and the mutant copies were deleted after each run.
