# ES PR #29 (ARS blob byte verification): independent audit

Date: 2026-11-23, 16:29Z to 17:35Z. Fresh, read-only audit thread started by the coordinator; not the writer. Repository `evo-agi/Execution-Substrate`. Writer report: `01-implementation.md` in this folder. Evidence: `02-audit-evidence/` next to this file (`SHA256SUMS.txt` lists every file).

**Final verdict: ACCEPT** (five Low findings, all test or documentation; a tested, test-only fix diff is in `02-audit-evidence/proposed-fix/`). Recommendation: apply the fix (or an equivalent) on the topic branch before PR #29 leaves draft, then a narrow re-audit of that commit, then the red-team and David's review.

---

## 1. Plain-language summary for David

The change does what it says. ES now checks the fingerprint of every file it fetches from the artifact registry by fingerprint, and it uses exactly the bytes it checked: the program it stages, the bytes the safety policy inspects, the mounted files, the signed evidence and the Vault settings. A wrong fingerprint stops the request before anything happens. I checked this in the code, ran the tests myself, ran them under the race detector, tried 44 deliberate breakages of my own, and merged it with the PR 12 work (now on PR 12's branch): no conflict, no change in results.

What I found is about the tests and one sentence in the contract, not the running code:

1. Two older tests silently stopped testing what they were written for. Because ES now refuses bad bytes earlier, two existing safety checks behind it (strict reading of the evidence file, and the reliable-submit layer's own check of mounted files) no longer have any test. I proved this by breaking each check: on today's `trunk_dev` a test catches it, on PR #29 none does.
2. The size limits of three reads are not pinned by any test (a larger limit would pass every test).
3. The new guard test can be walked around in two ways I tried (a second registry client, or reusing the existing one twice).
4. The contract's first sentence says ES trusts the registry for no bytes; it still trusts it for the discovery record, which picks the evidence file. The sentence should say so.

I wrote and ran the test changes that close 1 to 3 (and a small extra gap that predates this PR). Nothing is needed from you now.

---

## 2. Audit target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Base | `trunk_dev` `036d50724b499b020c5149c55ad902cfcb1482c0` (unchanged at 16:31Z and at 17:19Z) |
| Topic branch / commit | `claude/project-thread-urwhl2` / `f8c1a73b5a14b99a40e9c54910a76e14d30e5312` (one commit; remote tip equal at 16:31Z and 17:19Z) |
| Tree | `6b72ef78ba077c0f7a396227f69c12d3c9c7d3d8` |
| PR | [#29](https://github.com/evo-agi/Execution-Substrate/pull/29), draft, head `f8c1a73`, base `trunk_dev` `036d507`, mergeable state `clean` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified with `sha256sum -c` before use; byte-equal to the project copy) |
| Textual diff SHA-256 | `c900bbff00cf1ac8ce10fa118eef0d918cbc630ccf41a574118f86111a370072` |
| Canonical manifest SHA-256 | `32310cac508a305413825bf6f240d299c411e5ff5425920ec3ff52fb39b5fe7c` |
| Paths | 22 (3 untracked/new, 19 modified), all `0644` |
| CI | run [45211410865](https://github.com/evo-agi/Execution-Substrate/actions/runs/45211410865), job 137820940719, "build, vet and test" **success** on `f8c1a73` (15:59:45Z to 16:28:15Z, Go 1.26.5, all 16 listed environment tests still fail as required). Read from GitHub by this audit; excerpt in `ci/` |

## 3. Audit posture

- Read-only. No repository write, commit, push, PR edit, comment or merge. Only this report and its evidence were written, to the project folder.
- No subagents; the parent did every inspection and run.
- Runs: Linux cloud container, Go 1.26.5 (toolchain fetched by `GOTOOLCHAIN=auto`, copied to `/opt`), tests as unprivileged user `ci` (uid 1500, gid 1600) under an emptied environment, `umask 022`, HUP/INT/QUIT/TERM/PIPE/XFSZ reset to default, `GOPROXY=off`, bindfs 1.14.7 installed. Test trees were separate clones; the provenance tree was never used for tests.

## 4. Provenance reproduction

Commands as in `provenance-and-audit-evidence.md` §5.3: fetch, `test origin/$TOPIC = f8c1a73`, base is an ancestor, `checkout -f -B $TOPIC $TIP`, clean status, `reset --mixed 036d507`, `--set-upstream-to=origin/trunk_dev`, v2 twice into a fresh `0700` directory outside the repo.

| Check | Result |
| --- | --- |
| Two runs | byte-identical (`cmp`), manifest SHA-256 `32310cac…fe7c`, 22 files |
| Against the writer's `01-evidence/manifest/manifest-1.json` | byte-identical |
| Mode differences | none |
| Closing manifest (17:19Z, same tree, after all audit work) | byte-identical to the opening manifest |

Provenance confidence: about 1.0 (PR head equals the audited commit; manifest reproduced and stable).

## 5. Coverage

Read in full: `es/admission/ars_blob_fetch.go`; the diffs of `service.go`, `submit.go`, `policy_payload.go`; all five call sites and their callers (`enforceAdmissionPolicy`, `resolveExecutionForSubmit` incl. the policy-buffer reuse at `resolved_execution_plan.go:480-488`, `resolveRuntimeMounts`, `fetchValidatedMountPayload`, `prepareMountArtifact`, `fetchArtifactDiscovery`); `readBoundedResponseBody`, `dependencyClient.get`, `decodeJSON`, `digestBytes`, `labeledSHA256DigestPattern`; `Submit` up to `submitJob` (freeze ordering); the ARS server's blob and artifact routes (`ars/api/server.go`) and digest pattern (`ars/store/filesystem.go:15`); the evidence digest validator (`internal/contracts/evidence/v1/claims.go:79-91`); the reliable-submit binding checks (`reliable_submit_binding.go:280-281, 359-361`); every test diff (22 paths), the new test file and the root docs test; contract 5A and the four other doc edits; `AGENTS.md` §7.

Also checked: every ES production use of `arsClient` and of `Dependencies.ArtifactRegistry`; no other HTTP client in `es/` or `cmd/es` reads ARS; no cache or second read on any of the five paths; PR 12's entry points (`reliable_submit_replay_private.go:218`, `reliable_submit_operational_handoff.go:21`) reach ARS only through `resolveExecutionForSubmit`.

Not inspected: macOS behaviour; the root package and `es/app` integration suites locally (CI ran them on the exact commit, see §8); red-team-style live attacks (out of scope for a correctness audit).

## 6. What was verified (the coordinator's list)

| Question | Result | Evidence |
| --- | --- | --- |
| Verified bytes are exactly the bytes decoded, inspected, staged and executed; no TOCTOU, second read or cache | **Holds.** The helper returns the `io.ReadAll` buffer it hashed (`ars_blob_fetch.go:90-97`). Evidence and Vault decode that buffer (`service.go:535, 676`); policy inspects it; Submit stages the policy buffer when present (`resolved_execution_plan.go:480-488`) and otherwise its own verified read; mounts parse the verified buffer. No other ARS client, no cache in `es/admission`. A TOCTOU mutant (X14: verify the first read, return a second) is killed | §7, mutants X14 |
| Non-canonical digests refused before any request | **Holds** inside the helper (`ars_blob_fetch.go:73-75`, Go `$` is end-of-text). 15 forms, 0 requests (test passes; X11 killed). End-to-end refusal at the call sites is not pinned (O2-1) | X11, X17, X18 |
| Bounded reads | **Holds** in code: same limits as before (evidence and Vault 256 KiB, policy 256 KiB, primary 32 MiB, mount ≤ 8 MiB); Content-Length precheck plus limit+1 read. Three of the limits are not pinned by tests (A2-3) | X5-X8, X13 |
| Fail closed before any effect | **Holds.** All five reads run inside `resolveExecutionForSubmit` (or Prepare, which has no effect) before `newExecutionLocator`, root claim, staging and `submitJob` (`submit.go:36-40`). The new end-to-end tests assert no Nomad call and empty staging/results roots | §5 |
| Status codes and contracts updated | **Holds.** Status and code unchanged per read; only the mismatch message is new; non-canonical maps to each read's "unavailable" message; contract 5A, implementation, storage, runtime-config docs and `PLANS.md:940` updated and pinned by the root docs test (two docs mutants caught). One over-broad sentence (A2-5) | docs tests |
| Guard that no other `/v1/blobs` read exists | **Holds for what it checks**, but evadable (A2-4) | X19, X20 |
| `TestPrivateReplayConcurrentWinnerClassification` now fails bounded | **Holds.** Reproduced independently with a production mutant that refuses every `:bytes` read: new body fails in 0.10 s with `concurrent admission: private replay: unavailable`; the `036d507` body hangs until `panic: test timed out after 30s`. The arrival bound itself is not pinned (O2-2) | `tests/replay-*.log` |
| Digest-true fixtures did not weaken tests | **Two weakenings found** (A2-1, A2-2). Method: an instrumented binary logged every mismatch per top-level test (447 tests, each run alone); besides the new tests only two older tests hit the mismatch branch, and base-versus-tip mutants show what each lost | `probe/`, X1c, Y1 |
| Clean merge with the PR 12 combined change (PR #28 head) | **Holds.** PR #28 was merged at 16:40:45Z by fast-forwarding PR #12's branch `codex/reliable-submit-operational-handoff-v1` to `2c8bf35` (tree `df3ff9dd…`), the head I trial-merged. See §9 | `trial-merges/` |

## 7. Findings

No critical, high or medium finding. Five Low findings, all patch defects of type test/doc gap; four observations.

```text
AUDIT FINDING A2-1
Type / Severity: test gap (regression of existing coverage) / low
Current contract: contracts.md 5A "Strict JSON decoding ... consume that buffer"; evidence decode failure maps to 503 artifact_evidence_unavailable "artifact evidence payload was invalid".
Path and line: es/admission/artifact_prepare_test.go:93-104 (subtest "invalid payload") at f8c1a73; production service.go:535-537.
Evidence: the subtest serves `{"claims":` under fixture.discovery.Evidence.Digest, so the digest check refuses it
  before the decoder (instrumented run: 1 mismatch); it asserts only code and status. Mutant X1c (decode
  error ignored) SURVIVES on f8c1a73 and on the PR 12 merge 81b6320; the same mutant on 036d507 (B-X1c) is
  KILLED by this subtest. X1a (message changed) and X1b (lenient decoder) also survive.
Impact: a regression of strict evidence decoding (truncated JSON, unknown field, trailing document) would
  pass every test. Today's code is correct.
Required correction: name each served body by its own digest, pin the message, add unknown-field and
  trailing-document cases (proposed diff; kills X1a, X1b, X1c).
Uncertainty: none. Patch defect.
```

```text
AUDIT FINDING A2-2
Type / Severity: test gap (regression of existing coverage) / low
Current contract: the reliable-submit binding refuses mount material whose compressed bytes do not hash to
  the mount payload digest (reliable_submit_binding.go:359-361), a second line behind the new read check.
Path and line: es/admission/reliable_submit_binding_test.go:526 and 567-575 ("A A Q byte mismatch") at f8c1a73.
Evidence: the case now asserts the resolver's earlier refusal and returns before the binding layer.
  Mutant Y1 (drop `digestBytes(archive.compressedBytes) != mount.payloadDigest`) SURVIVES on f8c1a73 and on
  81b6320; on 036d507 (B-Y1) it is KILLED by this case. (The primary-payload binding check, Y2, is still
  killed by TestReliableSubmitBindingCapturedMaterialProvenance.)
Impact: the defence-in-depth mount check of the binding layer can be removed without a failing test.
Required correction: a binding-level test that attaches a mount whose bytes differ from its payload digest
  and requires refusal, next to a building control (proposed diff; kills Y1).
Uncertainty: none. Patch defect.
```

```text
AUDIT FINDING A2-3
Type / Severity: test gap / low
Current contract: 5A "using the existing per-read size limits".
Path and line: call sites service.go:521, 661, policy_payload.go:81 pass the limit explicitly; tests
  resource_limits_test.go:106-150 send Content-Length = limit+1 with an EMPTY body.
Evidence: mutants widening the evidence (X5), Vault (X6) and policy (X7) limits to 32 MiB all SURVIVE: with a
  larger limit the empty body still fails as a Content-Length mismatch, with the same message. (Mount limit X8
  and the helper's own bound X13 are killed.) The evidence and Vault limits used to be fixed inside the shared
  decodeBoundedJSONResponse; this patch made them per-call arguments. The policy limit was already per-call.
Impact: a read could silently accept up to 32 MiB more than its contract limit.
Required correction: serve limit+1 real bytes with no Content-Length; with a non-matching digest for evidence,
  Vault and primary payload (a wider limit then yields the mismatch message) and a matching digest for the
  policy read (a wider limit then returns bytes) (proposed diff; kills X5, X6, X7).
Uncertainty: none. Patch defect for X5/X6 (new degree of freedom); X7 predates the patch.
```

```text
AUDIT FINDING A2-4
Type / Severity: test/guard gap / low
Current contract: 5A "These are all of ES's reads of GET /v1/blobs/{digest}. There is no other"; guard
  TestFetchVerifiedARSBlobIsTheOnlyARSBlobReadInES (ars_blob_fetch_test.go:596-683).
Evidence: two unverified reads pass the guard and the WHOLE es/admission package (every other inventory too):
  X19, a new method that builds a second client with newDependencyClient(s.cfg.Dependencies.ArtifactRegistry, …)
  and reads "/v1/blob"+"s/"+d+":bytes"; X20, `client := s.arsClient` inside fetchArtifactDiscoveryRecord
  followed by two reads, one of them ARS's /v1/artifacts/{d}/evidence route, which serves the evidence blob
  without "blobs" in its path (ars/api/server.go:384-397). The guard counts arsClient selectors, so one alias
  hides any number of reads. Scope is es/ only (cmd/es and internal/ are not walked; neither has an ARS client
  today). The writer's report §6 names the first class as a known limit; the repo does not.
Impact: the guard is a merge-time safeguard; production code is correct today.
Required correction: require every arsClient use to be the receiver of a direct method call and pin
  (function, method) pairs; pin Dependencies.ArtifactRegistry to NewService and Config.Validate (proposed diff;
  kills X19, X20; passes on f8c1a73 and on the PR 12 merge).
Uncertainty: a deliberately adversarial author can still evade a syntactic guard (reflection, unsafe); that
  stays a review matter.
```

```text
AUDIT FINDING A2-5
Type / Severity: doc/contract precision / low
Current contract: contracts.md:653 "ES does not trust ARS for the integrity of the bytes it reads";
  artifact_publication_storage.md:77 "ES does not trust ARS for byte integrity"; 5A "Outside this contract"
  (contracts.md:703-706) lists staged files, the runtime-support binary and the profile image only.
Evidence: ES still reads the discovery record (GET /v1/artifacts/{digest}/discovery, service.go:465-511)
  without byte verification, and cannot (no trusted digest exists for it). That record supplies the evidence
  digest that the evidence read is then verified against (contracts.md:662 says so in its table cell).
Impact: the opening sentence over-claims. Within the set of validly sealed evidence documents for the requested
  artifact digest and derivation inputs, ARS still chooses which one ES uses; the new check binds the evidence
  bytes to ARS's pointer, not to a trusted digest. Pre-existing seam, newly stated too broadly.
Required correction: scope the two sentences to blob reads by digest, and add the discovery read to
  "Outside this contract" with its actual binding (artifact identity, type, intent and payload cross-checks plus
  the evidence seal). The root docs test pins the current wording, so it changes with it.
Uncertainty: whether two differently-claimed sealed evidence documents can exist for one artifact digest
  depends on AGS publishing; Inference: yes (admission claims are not part of the artifact digest).
```

Observations (no change required for acceptance):

- **O2-1** End-to-end refusal of a non-canonical digest at the call sites is not pinned: X17 (evidence call site trims the digest) and X18 (payload call site lowercases it) survive. No integrity effect (the bytes are still hashed against the string requested). Note that the evidence validator accepts uppercase hex (`claims.go:79-91`, `hex.DecodeString`), so a sealed uppercase `payload_digest` reaches the payload read and is refused there (503 `payload_unavailable`, "artifact payload is unavailable"). A one-case test would pin it.
- **O2-2** The rendezvous helper's arrival bound is not pinned (X22 survives); only early return is tested. Test-only code.
- **O2-3** Pre-existing gaps, unchanged by the patch: the Vault blob's strict decoding was never tested (X4, X4c survive; B-X4c survives on `036d507` too), and the payload 404 message is untested (X15). The proposed diff also covers the Vault decoding.
- **O2-4** Mutant hygiene: X12 (compare 39-character prefix) is equivalent in practice (needs a 128-bit prefix collision); X9 did not compile (counted as invalid, the writer's M6 covers 206).

## 8. Validation assessment

Run by this audit on exact bytes (tree `6b72ef78…` unless stated):

| Command | Result |
| --- | --- |
| `go build ./...`, `go vet ./...`, `GOOS=darwin GOARCH=arm64 go vet ./...`, `gofmt -l` on changed Go files | clean |
| `go test -count=1 ./es/admission/` (user `ci`) | ok (72.0 s; again 23.4 s with `-json`): 1,181 pass, 4 skip, 0 fail. Base `036d507`: 1,118 pass, 4 skip; same 4 skips (setgid/supplementary group, two opt-in stress tests); no test passing on base is missing on the branch; 63 new results |
| `go test -race -count=1 ./es/admission/` (whole package) | ok, 99.5 s, no race report |
| `go test -run ARSBlobVerification -v .` (root docs tests) | 3 of 3 pass |
| Instrumented per-test run (447 top-level tests, each alone) | only expected hits (§6); one expected failure, `TestAdmissionProductionHasOneResolverAndOneMaterializationPath`, caused by the instrumentation's own `os.OpenFile` (its inventory guard working) |
| Replay hang check | §6 |
| Mutants: 25 code and 2 docs mutants on `f8c1a73`, 4 base equivalents, 2 on the PR 12 merge, 11 against the proposed fix (44 in all) | `mutants/results.txt`, `mutants/docs-mutants.txt` |

Mutant summary on `f8c1a73` (each alone, whole `es/admission` package with `-failfast`):

| Killed | Survived (finding) | Not counted |
| --- | --- | --- |
| X2, X3 (bound-read messages), X8 (mount limit), X10 (404 class), X11 (trimming check), X13 (limit+1), X14 (TOCTOU), Y2 (binding primary check); docs mutants D1 (message in Go only), D2 (5A rule text) | X1a, X1b, X1c (A2-1); Y1 (A2-2); X5, X6, X7 (A2-3); X19, X20 (A2-4); X17, X18 (O2-1); X22 (O2-2); X4, X4c, X15 (O2-3, pre-existing) | X12 equivalent, X9 invalid |

With the proposed fix applied: all 11 survivors that it targets (X1a, X1b, X1c, X4, X4c, X5, X6, X7, X19, X20, Y1) are killed; `es/admission` ok (36.4 s); the new tests pass under `-race`.

Not re-run here, taken from CI (observed on GitHub, run 45211410865 on `f8c1a73`): the root package (128.5 s ok), `es/app` integration with Nomad, Vault and SPIRE (both runs ok), `reliablesubmit`, every other package, the gate self-test and the environment-only list. The writer's own results (old-code e2e run, 19 mutants) were read, not re-run; my mutants were designed independently.

## 9. Trial merges

| Merge | Result |
| --- | --- |
| `f8c1a73` into PR 12's head `2c8bf35` (was PR #28's head; PR #12's branch now points at it) | clean, no conflict; merge `81b6320`, tree `29bae96436063735d69b81fe466a1c9ce2d48cfb`, identical to the writer's reported tree. `"/v1/blobs/"` appears once (in the helper); `arsClient` uses unchanged. Build, vet, macOS vet clean. `go test ./internal/testtmpdir/ ./es/admission/...`: merge 3,391 pass / 7 skip / 3 fail, `2c8bf35` alone 3,328 / 7 / 3; the same 3 failures on both, all `reliablesubmit` probe tests on that branch's `.github/ci/environment-only-tests.txt:117-119`; `es/admission` ok on both (253 s / 263 s). Root docs/contract tests ok on both. A2-1 and A2-2 also hold on the merge (M-X1c, M-Y1 survive) |
| Proposed fix diff on top of `81b6320` | applies cleanly; its tests and the old binding test pass |
| `f8c1a73` into PR #26's current head `c99a1b4` | clean (merge `ff7ff71`, tree `4780a4e5…`); `es/admission` ok (35.8 s) |

## 10. Proposed fix (test-only)

`02-audit-evidence/proposed-fix/proposed-test-fix.diff` (3 files, +137/-15, against `f8c1a73`):

- `artifact_prepare_test.go`: the evidence failure cases become digest-true and pin "artifact evidence payload was invalid" (truncated, unknown field, trailing document). A2-1.
- `reliable_submit_binding_test.go`: `TestReliableSubmitBindingRefusesMountBytesThatDoNotHashToTheMountPayloadDigest` (control builds, mismatched mount refuses). A2-2.
- `ars_blob_fetch_test.go`: `TestARSBlobReadsKeepTheirOwnReadLimits` (A2-3); the guard records each `arsClient` use with its called method, records a use that is not a direct call as such, and pins `Dependencies.ArtifactRegistry` to `NewService` and `Config.Validate` (A2-4); `TestWorkloadZoneVaultBlobIsDecodedStrictlyFromVerifiedBytes` (O2-3, optional).

A2-5 needs a wording change in `contracts.md`, `artifact_publication_storage.md` and the root docs test; I did not draft that text, since the writer owns the contract wording.

## 11. Sensitive-material handling

No secrets were read or produced. Fixtures use test keys generated in-process. Evidence holds manifests (paths, sizes, hashes), test logs, mutant descriptions and a test diff. The CI excerpt is limited to toolchain, package-result and list-check lines.

## 12. Remaining uncertainty and stop conditions

- Nothing ran on macOS (CI is Linux only).
- If PR #29's head moves, or it is rebased on a moved `trunk_dev`, this audit no longer binds; provenance must be re-taken (§5.4).
- PR #12 lands on `trunk_dev` second or first: in either order, re-run `TestFetchVerifiedARSBlobIsTheOnlyARSBlobReadInES` (and, with the fix, the two new binding and limit tests) after that merge.

## 13. Confidence

- Provenance: 0.99 (reproduced byte-for-byte, opening equals closing, PR head equals target).
- Validation: 0.9 (all decisive suites re-run here on exact bytes; the integration and root suites rest on CI, observed directly; no macOS).
- Implementation: 0.9 for the production change (small, single choke point, verified by reading and by killed mutants X10, X11, X13, X14 and the end-to-end tests); test adequacy lower until A2-1 to A2-4 are fixed.

## 14. Effect status

Repair, commit, push, PR change and merge: not performed. Nothing was posted on GitHub.

## 15. Report delivery

This file: `/mnt/project-files/reports/Execution-Substrate/artifact-verification/02-audit.md`; its SHA-256 is given in the thread reply. Evidence: `02-audit-evidence/` with `SHA256SUMS.txt`.

**Final verdict: ACCEPT**
