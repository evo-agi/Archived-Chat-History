Re-check of PR 29 at 91dbad6: **RT8-1 is closed, and RT8-2 is closed for the case I reported. My own guard fix still had holes, though.** An unchecked registry read placed in `es/_x`, `es/.x`, a `testdata` folder, a nested module, or a file built only for linux/arm64 still passes the guard. I filed this as RT8-3 (Low, test-only), with a tested fix: `guard-walk-hardening.diff` (all 7 mutants caught, es/admission 1,281 pass, 0 fail). The head bytes match the writer's manifest, and Addendum A is in 08-redteam.md.

STATUS: WAITING (on the writer applying the RT8-3 fix; nothing needed from David)
