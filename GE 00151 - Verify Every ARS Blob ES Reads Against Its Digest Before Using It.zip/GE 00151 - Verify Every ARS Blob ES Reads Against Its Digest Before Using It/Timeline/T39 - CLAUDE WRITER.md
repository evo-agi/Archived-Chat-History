Both red-team findings are fixed and PR #29 now includes trunk_dev 76c030f (PR #27). The new head is `91dbad6`, a fast-forward push. Details are in [09-repair.md](/mnt/project-files/reports/Execution-Substrate/artifact-verification/09-repair.md).

- **Manifest:** v2 `dab632ae…b19a` against 76c030f, 29 paths: the 28 from before plus the new redirect test. The two runs are byte-identical, and every committed blob matches.
- **Redirects (RT8-1):** the product change is the red-team's one line, applied unchanged. I added two things:
  - A same-origin redirect case in the test. Without it, a policy that refuses only cross-host redirects, or only plain HTTP ones, passes the test. I checked that both such policies survive the original test.
  - A pinned rule in section 5A of the contract saying ES never follows a redirect from ARS or EGS.
- **Guard scope (RT8-2):** the red-team's diff, with one change. Listing the ES binary's packages now uses the same locked-down `go list` environment as the other guards (local toolchain, no proxy, no stray Git variables).
- **Checks:** all 8 mutants are killed. Across the whole module, the failures match trunk_dev exactly (all specific to this container), and no test that passes there fails here.
- **PR 12 line:** it now conflicts with trunk_dev in PLANS.md. The conflict comes from PR #27, not from #29.

ES's Nomad client still follows redirects. That is the red-team's note for #31. CI on 91dbad6 is running.

STATUS: WAITING (red-team re-check and narrow audit)
