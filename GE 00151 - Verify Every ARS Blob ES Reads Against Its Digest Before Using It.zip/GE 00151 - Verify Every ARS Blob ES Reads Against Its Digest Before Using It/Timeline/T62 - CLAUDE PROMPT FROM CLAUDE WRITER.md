Here is the response from CLAUDE WRITER:

I've held the merge and withdrawn the card. Here's the answer to David's question, at trunk_dev 76c030f.

Writes: AGS sits in front of ARS. ARS accepts uploads and registrations only from the AGS identity (ars/api/server.go:23, :69, :137, :557).

Reads: ES reads ARS directly, by design. The boundary doc says "ES reads blobs and artifact evidence/records through ARS" (boundaries.md:384) and "ES does not call AGS on the runtime path" (:442). Other readers are allowed only if ARS's config lists them (:387; .examples/config/ars.json:18-22). The Python POC was the same: its ES had its own registry client (ExecutionServer.py:218), and its ARS listed service/execution as a reader.

Callers of ARS today:
- AGS: put, register, health.
- ES admission: discovery read, five blob reads, health.
- Operator bring-up script: one Vault blob read.
- Workers: none.

PR #29 adds no path. It replaces ES's four blob call sites with one verified function, and the discovery read and health check are unchanged. It also refuses redirects from ARS and EGS.

Doc/code conflicts:
- Older drift: configuration.md:137 says AGS writes with "the dedicated service/artifact-governance writer identity", but ARS accepts any identity below that path (ars/api/server.go:563, :571-580). The POC matched exactly. This belongs in the identity work.
- No doc says AGS fronts ARS for reads.

My recommendation is to keep direct reads. AGS's authority travels in its signature and the digests, and this PR is what makes ES check them. Routing reads through AGS would put the signing-key holder on every run's path for no gain.

David's review summary (about 5 minutes) is at /mnt/project-files/reports/Execution-Substrate/artifact-verification/12-review-summary-for-david.md. It covers his question, what changes, the one remaining trust in ARS (the discovery record, a design item), the two older drifts and how the PR was checked.
