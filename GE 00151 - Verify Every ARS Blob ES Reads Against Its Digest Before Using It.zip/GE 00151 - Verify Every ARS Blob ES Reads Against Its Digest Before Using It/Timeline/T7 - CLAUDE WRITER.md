**Short answer: the Python version was built to have the bytes checked, though ES never hashed them itself. The Go rewrite dropped that check.** I read your snapshot (zip SHA-256 `50836e20…cd55b`, repo `Monolith` at `cbbac0e6`, 2026-03-29) without running anything from it.

**Python version**
- ES never downloaded program or mount bytes itself. It asked the artifact store for a signed download link and gave Nomad that link along with `checksum = <signed digest>`. Nomad's downloader is meant to refuse any file that doesn't match. See `services/execution/intent/NomadJobSpecFactory.py:301-340`, used at `:190-200`, and `ExecutionServer.py:787-795` and `:2059-2081`.
- Caveat (Inference): the job JSON named those fields `source`/`options` (`NomadJobSpecFactory.py:1676-1685`). Nomad's JSON API calls them `GetterSource`/`GetterOptions` (Nomad v1.9.7 `api/tasks.go:860-868`, which I fetched). So Nomad probably never received the checksum on a live run. I can't tell whether that path ever ran live.
- The Vault settings file was never checked (`ExecutionServer.py:2027-2035`). An opt-in hash helper, `get_blob_bytes(verify=False)` at `ArtifactRegistryClient.py:454-505`, existed but nothing in ES called it.

**Go rewrite**
- The first Go submit commit, `a771825` (2026-04-01), moved the download into ES. It reads `/v1/blobs/{digest}:bytes` with no hash (`es/admission/submit.go:181-220` at that commit).
- On `trunk_dev` `792f17c` today, none of the live reads hashes what it receives: program, mounts, policy copy and Vault settings. I checked every hashing site in `es/`.

Next I'm designing the fix and checking where it overlaps PR 12/13.

STATUS: WORKING (design and overlap check; next update by ~~about 16:30 your time,~~ 15:30Z [Edit: I don't know your time zone, so I gave UTC only])
