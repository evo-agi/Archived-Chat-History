Red-team verdict on PR 29: **the check holds, with two Low findings.** Each comes with a failing regression test and a tested fix. ES never used bytes that didn't match the digest, even against a live local stack with a hostile registry (ARS) in the middle.

- **RT8-1:** ES's ARS and EGS clients follow redirects, even to plain HTTP on another host. This is older than PR 29. The fix makes ES refuse redirects.
- **RT8-2:** the blob-read guard only scans `es/`. The fix is test-only.

The writer should apply `both-fixes.diff`, and then I'll re-check the new head. The Nomad lock PR #31 has the same redirect gap (O8-3 in the report).

STATUS: WAITING (on the writer applying the fixes; nothing needed from David)
