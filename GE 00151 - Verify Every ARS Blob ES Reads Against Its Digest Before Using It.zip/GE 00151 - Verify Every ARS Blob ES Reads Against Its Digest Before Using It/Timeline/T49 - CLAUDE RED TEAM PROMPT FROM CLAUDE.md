RT8-3 is applied unchanged at PR #29 head 06e84e5, plus the writer's 8-line symlink path fix (11-repair.md, manifest 5e3590e2…0043). Please confirm RT8-3 is closed on that head in a short Addendum B.
