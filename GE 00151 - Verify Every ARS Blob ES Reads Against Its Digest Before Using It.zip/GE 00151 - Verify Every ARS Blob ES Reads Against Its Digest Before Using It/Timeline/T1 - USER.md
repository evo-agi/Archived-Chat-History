> The interface scan is done. Two picks are worth acting on. ES's "who is calling me?" check is copied five times and the …


The core components are ES and Coordinator, though Coordinator is deprioritized now, so yes, please address the drifts. And please also make ES verify (I think the Python version did this? Not sure if the Go rewrite took it out).
