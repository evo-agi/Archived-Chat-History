> The answer to your ARS question: for writes, yes. AGS sits in front, and ARS accepts uploads and registrations only from…


Fair. And I just remembered that the design decision was to keep AGS off the critical path, or something like that.

If PR is ready, please let the thread merge, or I can do it.
