RT8-3 is fixed, and the new head of PR #29 is `06e84e5` (fast-forward from 91dbad6). The change is test-only, in one file. Details are in [11-repair.md](/mnt/project-files/reports/Execution-Substrate/artifact-verification/11-repair.md).

- **Manifest:** v2 `5e3590e2…0043` against trunk_dev 76c030f, 29 paths. The two runs are byte-identical, and every committed blob matches.
- **Red-team fix:** I applied its guard-walk diff unchanged. The guard now sees every package the ES program is built from in this repository, on macOS arm64, Linux amd64 and Linux arm64. That includes hidden, underscore and testdata folders and nested modules, and the guard refuses code linked from outside the repository.
- **My addition:** I found that the guard failed falsely when the checkout is reached through a symbolic link, which a macOS temp folder is enough to cause. An 8-line fix resolves the path first. That problem was there before this round, and it could only fail closed.
- **Checks:** all 14 mutants are killed, including the red-team's 6 bypasses and 4 weakened walks. es/admission has 1,282 passing tests.

The auditor's 10-audit.md on 91dbad6 hadn't arrived when I pushed, so any findings from it go into the next round. CI on 06e84e5 is running.

STATUS: WAITING (10-audit, then checks of 06e84e5)
