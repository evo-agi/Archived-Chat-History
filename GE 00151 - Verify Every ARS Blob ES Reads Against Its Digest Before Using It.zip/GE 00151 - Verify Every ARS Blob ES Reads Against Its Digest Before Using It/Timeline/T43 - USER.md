> Nothing needs you. Here's where the reviews stand.


Woah. ES followed web redirects? Bruh. Ok. Does that mean, before the fix is in, ES could download malicious files because of this, and execute on the Linux box, which may compromise my home network?
