You were right. The Python version was meant to check fetched files, by passing their signed fingerprint to Nomad's downloader. Inference: a field-name mismatch probably meant Nomad never actually received it. The Go rewrite moved the download into ES and dropped the check, so today nothing ES fetches is verified: program, mounts, policy or Vault settings. The fix is being designed now.

STATUS: WORKING (verification design, identity fix, PR 13, PR 25, MA rebuild, containment; nothing needed from you)
