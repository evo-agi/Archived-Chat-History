Merge of PR #29 is on hold for your review, and the merge card is withdrawn. Your review summary is attached. It takes about 5 minutes and answers your AGS question first: AGS stands in front of ARS for writes only. ES reads from ARS directly, which is the documented design and was the same in the Python POC. PR #29 adds no new path to ARS. It checks the files on the reads that already existed.

STATUS: NEEDS DAVID (review PR #29)
