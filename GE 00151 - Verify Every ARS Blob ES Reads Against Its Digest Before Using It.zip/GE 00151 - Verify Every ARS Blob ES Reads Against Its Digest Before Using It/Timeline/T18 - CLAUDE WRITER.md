PR #29 is repaired after audit 02, and the new head 89da53d is with the same auditor for a narrow re-audit. CI on that commit is still running.

**A2-1 to A2-4:** I applied the auditor's tested test fix unchanged. I also fixed two of their optional observations: call sites must pass the digest through exactly as given, and the replay test's wait for workers to arrive is now bounded. All 14 targeted mutants and all 8 doc mutants die. No product code changed.

**A2-5 can't be fixed properly in this PR.** It is about the discovery record, which ES reads from ARS without a hash check and which tells ES which evidence document to use. A signature wouldn't help: the signer can seal several valid evidence documents for one artifact, for example one allowing network access and one not. A compromised ARS can then pick between them. I showed this with a throwaway test. Pinning the choice would need a new field in the run request, which collides with PR 12. So the contract now says exactly that, and a test pins the wording.

My recommendation is a separate design item, taken up with the trust/revocation and admission-record work after PR 12. Callers would name the evidence document, and old versions would be retired through revocation. Details are in the report.

STATUS: WAITING (narrow re-audit, then red-team)
