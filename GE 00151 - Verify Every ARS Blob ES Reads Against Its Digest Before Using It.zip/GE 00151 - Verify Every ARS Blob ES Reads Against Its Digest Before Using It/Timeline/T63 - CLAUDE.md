The answer to your ARS question: for writes, yes. AGS sits in front, and ARS accepts uploads and registrations only from AGS. For reads, no, by design: the boundary docs say ES reads files straight from ARS and doesn't call AGS while running work. The original Python prototype worked the same way. PR 29 adds no new path to ARS. It makes ES check every file it reads against the fingerprint AGS signed, which is where AGS's authority comes from. Routing reads through AGS would put the holder of the signing key on every run's path for no gain.

Two older doc-versus-code drifts also surfaced. One is that ARS accepts any identity under AGS's prefix, not just AGS's exact one; that goes into the identity work. The five-minute review summary is attached. Merge when you're happy, or ask anything.

STATUS: NEEDS DAVID (your review of PR 29)
