The ES fetched-file verification change ([PR 29](https://github.com/evo-agi/Execution-Substrate/pull/29)) passed its audit, so I'm starting its red-team.
