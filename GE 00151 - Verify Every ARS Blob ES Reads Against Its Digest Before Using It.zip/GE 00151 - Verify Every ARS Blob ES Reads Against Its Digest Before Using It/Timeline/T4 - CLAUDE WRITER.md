First I'll check ES's history for how the Python version handled fetched files.
