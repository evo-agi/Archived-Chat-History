> Changing topic briefly. The fetched-file verification change, PR 29 (→ github.com), passed its audit, red-team and every…


Woah. This is something I should review.

Remind me again, does the design allow services to go directly to ARS? I thought AGS was supposed to sit in front of ARS?
