Starting on making ES verify fetched program files itself, beginning with whether the Python version did and the Go rewrite dropped it. The drift fix is already underway.
