Here is the response from CLAUDE WRITER:

Overlap report (ES byte verification), as your brief asked before editing PR 12/13 files. Nothing is pushed.

Design (local trial on 792f17c): a new fetchVerifiedARSBlob (new file es/admission/ars_blob_fetch.go) becomes ES's only "/v1/blobs/" read. It refuses a non-canonical digest before any request and hashes exactly the bounded buffer it read. It returns that buffer only on an exact match, and that same buffer is what gets decoded, inspected, parsed and staged. All five reads (evidence, Vault config, policy payload, primary payload, mount payload) happen before the freeze point. Each keeps its status and code; a new message names the mismatch.

Measured overlap with PR 13:
1. service.go: I edit only fetchArtifactEvidenceBlob and fetchWorkloadZoneVaultConfig, which PR 13 does not touch.
2. PLANS.md:940 must change ("ARS remains their integrity authority"); PR 13's hunks are at lines 2-40. implementation.md: mine are at 250-330 and 650, PR 13's at 1085.
3. Test fixtures are the real overlap. Shared fixtures sign made-up digests, so 24+ tests fail and one (TestPrivateReplayConcurrentWinnerClassification) hangs instead of failing. The fix is about 80 call sites in 14 test files. Four of those files are also in PR 13: workstream_a/c guardrails, reliable_submit_replay_private_test, reliable_submit_guardrails_test.

Recommendation: land on trunk_dev now, with disjoint hunks and shared helpers made digest-true behind an unchanged API where possible. Before leaving draft, I trial-merge into PR 13 head e060449, run the combined suite, and hand the PR 13 writer an exact change list. The alternative, waiting for PR 12 to land first, leaves ES trusting ARS for days. I'm continuing locally on the recommended path and won't push until you answer.
