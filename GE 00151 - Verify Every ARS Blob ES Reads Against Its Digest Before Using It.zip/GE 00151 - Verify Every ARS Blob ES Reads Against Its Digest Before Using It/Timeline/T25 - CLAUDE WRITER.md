PR #29 is repaired after re-audit 04, and the new head bb177ae is back with the same auditor for a short re-audit. CI is still running.

**A4-1 (mounts) is fixed in this PR**, as you decided. Submit now refuses a mount when ARS answers its lookup with a different artifact's record, with the existing 409 `mount_artifact_invalid`. Before, a compromised ARS could make ES stage any other sealed artifact as the mount. I reviewed the auditor's fix and applied it unchanged. It's a 6-line check plus tests, and four docs that called this a known gap now say it's closed. Honest deployments see no change.

**A4-2 and A4-3 are fixed too.** A4-3 is contained: the guard now catches the client being copied into a second field or local. Reflection and `unsafe` stay out of scope.

I also added three things:
- The guard now lists every caller of the unchecked ARS lookup, so a future one can't skip this check. That is what would have caught A4-1.
- A test for each read's "not found" answer.
- 5A now says that for mounts the remaining ARS choice changes no staged bytes.

All 15 targeted mutants die. Trial merges into PR 12 and PR 26 are clean and pass.

STATUS: WAITING (short re-audit, then red-team)
