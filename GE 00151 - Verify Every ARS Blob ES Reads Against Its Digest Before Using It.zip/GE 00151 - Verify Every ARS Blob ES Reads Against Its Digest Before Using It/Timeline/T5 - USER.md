@"/mnt/project-files/Execution Substrate POC - Snapshot.zip"
<!-- reply 1 -->
> Starting on making ES verify fetched program files itself, beginning with whether the Python version did and the Go rewr…


Do you have access to the Python version? If not, here it is.
