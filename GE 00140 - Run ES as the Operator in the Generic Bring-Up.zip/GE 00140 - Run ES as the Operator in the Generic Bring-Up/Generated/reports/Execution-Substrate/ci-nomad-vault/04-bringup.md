# ES: bring-up runs the ES container as the operator

Report 04 of the CI Nomad/Vault track. Follows `02-repair-tests.md` (section 4 described the bring-up defect) and the coordinator's decision of 2026-11-22 19:04Z: fix the script so ES runs in its container as the operator user that owns the run folders, do not make the test run as root, separate commit on its own branch and draft PR to `trunk_dev`.

Date: 2026-11-22. Repository: `evo-agi/Execution-Substrate`. Evidence: `04-evidence/` beside this file (`SHA256SUMS.txt` lists every file).

## 1. Outcome

| Item | Result |
| --- | --- |
| Bring-up fix | **Done**, draft [PR #18](https://github.com/evo-agi/Execution-Substrate/pull/18) into `trunk_dev`, one commit `bede334` on `claude/project-thread-a9tcoa-bringup`. Not in PR #17. |
| `TestBringupScriptUpCheckDownFullProfile` | **Green on the GitHub runner as the non-root runner user, 3 runs out of 3** (run 45061834564), and green again inside the whole `es/app` package run. Each run's `es.log` shows `docker run ... --user 1001:1001`. |
| New launcher test | `TestESLauncherContainerUser` pins the exact `docker run` arguments with a fake Docker daemon, so it runs in CI without Nomad. It catches 6 of 6 mutants of the script change. |
| Runbooks | In-repo `.runbooks/system/v1_bringup.md` updated in the PR. No runbook in `Archived-Runbooks` describes bring-up, so nothing to update there (section 8). |
| One change from the plan I gave | The decision card said "rootless unchanged". The fix has **no rootless branch**: the repo's rules forbid branching on daemon labels for capability-sensitive behaviour (section 4). On a rootless or user-namespace-remapped daemon, ES now refuses to start at its own startup check. Neither daemon kind is a documented bring-up setup, and the full profile's Nomad path is rootful. |
| PR #17 | Audit finding NV3-F1 fixed in `962bc89` (comment path only); new manifest in section 2. |

Nothing was merged.

## 2. Target identity

| Field | Value |
| --- | --- |
| Base | `trunk_dev` at `ae326b0ddc30ec6b35883ee32945c622405b68b6` |
| Topic branch | `claude/project-thread-a9tcoa-bringup` |
| Tip | `bede33446fd76426d00f32605ef61b905e82fab6`, one commit |
| Draft PR | [#18](https://github.com/evo-agi/Execution-Substrate/pull/18) into `trunk_dev`, assigned to SeritArbores |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked with `sha256sum -c` before each run |
| Base-relative manifest | `7d2177bec833a90a61e153805e76bf1914b879285a9693f98fa6c679278c3554` (1,852 bytes), HEAD `ae326b0`, upstream `origin/trunk_dev`, 8 files: 7 `tracked_modified`, 1 `untracked` (the new test file); textual diff `513b252ef40743a0bd10c8842371af96bee23b12b0e2549307f2ea212c380158`. Taken twice in a fresh clone from GitHub after the push, byte-identical (`cmp`). Copy: `04-evidence/manifest-v2-bringup-bede334.json` |
| Files | `scripts/05_start_es.sh`, `es/app/es_launcher_container_user_test.go` (new), `es/app/operator_scripts_integration_test.go`, `PLANS.md`, `.docs/execution_lifecycle/contracts.md`, `.docs/execution_lifecycle/implementation.md`, `.docs/system_overview/capability_probing.md`, `.runbooks/system/v1_bringup.md` |

PR #17 after NV3-F1: head `962bc8956b4a38e18a7443a66ede2a60254a1ca3`, one comment line changed since `dac9736` (`es/app/staging_cleanup_integration_test.go:249`, `.docs/execution_lifecycle/` to `.docs/system_overview/`). Manifest at `962bc89`: `a205eb8df3bef52dde5069ef193ac56dd03753c9fcadb3daf9783c936052708d` (890 bytes, 3 files `tracked_modified`, textual diff `d1b2011935025ee3dfc14b8b048bc3b62314e24c51e72c72acc83df3254e3dd5`), taken twice, identical. Copy: `04-evidence/manifest-v2-repair-962bc89.json`.

## 3. The defect and the fix

Line numbers are at `ae326b0` unless a line says otherwise.

- **What bring-up did.** Without `SUPPORTED_LOCAL_ES_ROOTS_PROFILE`, `verify_es_staging_invariant` creates missing execution roots as the calling operator (`mkdir -p`) and requires only that both roots are writable by that operator (`scripts/internal/control_plane.sh:368-391`, inside the function that starts at :291). The launcher then started ES with no `--user` (`scripts/05_start_es.sh:34` printed, `:38` executed), so on a rootful daemon ES ran as the image's default user, root. The control-plane image's final stage is `alpine:3.20` with no `USER` line (`scripts/generate_control_plane_dockerfile.sh:52`).
- **The #8 check that refuses this.** Configured-Submit startup creates a result directory naturally and requires it to carry the roots' owner: `qualifiedExecutionRoots.owner()` (`es/admission/execution_roots.go:379-386`) and `probeNaturalResultDirectory` (`:551-580`, refusal text at :577, "natural retained result directory creation is unavailable"). `git blame` attributes all of these lines to `2478a24` (#8). ES running as root creates a `0:0` directory under operator-owned roots, so it refuses to start.
- **The fix** (`scripts/05_start_es.sh:33-53` at `bede334`). In the generic path the launcher passes `--user "$(id -u):$(id -g)"`, the caller's UID:GID, to both the printed and the executed `docker run`. The `service-root-v1` profile keeps the default user, because its roots are `0:0` by contract. The array is expanded as `${USER_SPECS[@]+"${USER_SPECS[@]}"}`, the repo's existing idiom (`scripts/remote_alpha_operator.sh:3243`), so an empty array also works under `set -u` on macOS's bash 3.2.
- **Why the caller and not the roots' owner.** Running as the caller gives ES no more host authority than the operator who started it. If the roots belong to someone else, ES's own startup check refuses, which is the behaviour the contract asks for.
- **The retained-result key now matches.** ES requires the key file to be owned by its effective UID (`es/admission/result_auth.go:109`) and its parent to be owned by that UID or by 0 (`:57`). With ES running as the operator, an operator-written key works. The key is bind-mounted as a single file, so inside the container its parent is a root-owned mount point.

## 4. No daemon-label branch, and what that means for rootless

My first draft read `docker info` and skipped `--user` when the daemon reported `name=rootless`. I removed it before committing, for two reasons:

- `AGENTS.md` section 12: "NEVER introduce OS-based branching for capability-sensitive behavior. ALWAYS validate capability by behavior or static resource checks, not by platform labels." `.docs/system_overview/capability_probing.md` (Core Principle): no "runtime-label checks to change behavior for capability-sensitive slices", and on failure "must not … switch to fallback behavior".
- Whether ES can create correctly owned directories is exactly that kind of capability, and ES already checks it by behaviour at startup.

So the launcher has one rule for the generic path, and ES's startup probe is the only gate. Consequences:

| Daemon | Before (`ae326b0`) | After (`bede334`) |
| --- | --- | --- |
| Rootful, non-root operator | ES refuses to start (the defect) | ES runs as the operator and starts (runner, 3 of 3) |
| Rootful, operator is root | ES runs as root | `--user 0:0`, same identity |
| Rootless (container root is the daemon's user) | Probably started, never tested | ES runs as a subordinate ID and refuses at startup |
| User-namespace remapped | ES refuses (container root is not the operator) | ES refuses |
| `service-root-v1` profile | default user | unchanged (test pins it) |

Neither rootless nor remapped daemons are a documented bring-up setup. The full profile also needs Nomad's Docker driver, and the docs keep the Nomad client root-managed and rootless out of every claim (`.docs/system_overview/remote_supported_host_alpha.md:150`; `.docs/execution_lifecycle/contracts.md:1530-1532` at `ae326b0` for the profile). If rootless bring-up should become supported, it needs its own decision and a behaviour-based way to choose the identity. This is the one point where I departed from the card's wording; the coordinator may want to confirm it.

## 5. Test changes

### 5.1 TestBringupScriptUpCheckDownFullProfile (two stale assertions)

- **Retained-result key.** The test supplied none. `execution.retained_result_auth` has been required at configured-Submit startup since #8 (`.docs/execution_lifecycle/contracts.md:1488-1497`; `es/config/config.go:514`, with `RetainedResultAuthConfig.Validate` at :520-523; 7 of those 10 lines blame to `2478a24`). The test now uses the shared helper `newSubmitStackSyntheticRetainedResultAuth(t, rootDir)` (`es/app/submit_integration_test.go:1476-1487`): 32 synthetic bytes, mode `0600`, written by the operator, outside both roots (`operator_scripts_integration_test.go:267` at `bede334`).
- **SPIRE bind source.** The test allowed the socket file as the workload's only external bind source (`:444` at both `8a5e166` and `ae326b0`). ES has mounted the socket's directory since the import: `filepath.Dir(cfg.Execution.SPIREWorkloadAPISocketPath)` at `es/admission/executionpackage.go:272` in `8a5e166`; today `spireSourceDir := filepath.Dir(spireSocketPath)` at `es/admission/resolved_execution_plan.go:404`, used at `es/admission/executionpackage.go:285`. The submit test has asserted the directory since the import (`es/app/submit_integration_test.go:717`, blamed to `8a5e166`). The test now names `filepath.Dir(...)` (`:447` at `bede334`).
- **Strictness.** `assertNomadBindSourcesUnderStagingRoot` (`operator_scripts_integration_test.go:3885-3960` at `bede334`) matches external sources exactly, fails on any other external source, and fails if an allowed source is missing. So the assertion is exactly as strict as before, with the correct path. The test still runs as the runner user; nothing runs it as root.

### 5.2 TestESLauncherContainerUser (new, no Nomad needed)

`es/app/es_launcher_container_user_test.go` runs `scripts/05_start_es.sh` with a fake `docker` that accepts only `image inspect`, `rm -f` and `run --rm` (anything else exits 97), and records the `run` arguments one per line.

- **Generic path:** calls are exactly image, rm, run. The `docker run` arguments equal, in order, `run --rm --name <execution-substrate-…-es> --network host --user <caller UID:GID>`, then the three mounts, the image, `/usr/local/bin/es -config <config>`. Both roots are created, and the printed command contains ` --user <UID:GID> `.
- **`service-root-v1` path:** a fake `python3` passes only the static root check (which needs `0:0` roots that a non-root test cannot make) and runs everything else with the real interpreter. Calls are exactly image, root-check, rm, run; no `--user` in the arguments or the printed line; no root is created.
- **Mutants** (`04-evidence/launcher-mutants.log`): never pass `--user`; pass it in the profile path too; UID without GID; omit it from the printed line only; omit it from the executed line only; a fixed `1000:1000`. Each one fails the test. The unmutated script passes.

## 6. Docs

AGENTS.md section 7 asks for docs with the change. Each addition says the same thing in its document's terms:

Line numbers in this section are at `bede334`.

- `PLANS.md:220`: new bullet `GENERIC-ES-LAUNCHER-USER-01`, a **Bounded slice rule** refinement of the generic launcher: why the caller's UID:GID, no daemon-label branch, remapping daemons refused by ES, profile unchanged, other bring-up services unchanged.
- `.docs/execution_lifecycle/contracts.md:1529-1532`: the generic launcher runs ES as the caller's UID:GID; no label branch; a remapping daemon is refused by the startup probe.
- `.docs/execution_lifecycle/implementation.md:999-1000`: the probe sees ES create directories as the operator who owns the roots.
- `.docs/system_overview/capability_probing.md:159-161`: the launcher does not inspect daemon labels; ES's natural-directory probe alone decides.
- `.runbooks/system/v1_bringup.md:248`: an operator must own the roots and the retained-result key; ES refuses otherwise, and on rootless or remapped daemons.

No existing sentence was changed or removed. The docs contract tests in the root package pass at `bede334` (section 7).

## 7. Validation

| Where | What | Result |
| --- | --- | --- |
| GitHub runner, `ubuntu-24.04` image 20261116.376.1, user `runner` 1001:1001, pinned Nomad 2.1.1, Vault 2.2.2, SPIRE 1.14.4 | Bring-up test 3 times in a row, probe run 45061834564 (probe commit `d38be14` = `bede334` plus a workflow file) | 3 of 3 passed (55 s, 18 s, 18 s); each `es.log` has `--user 1001:1001` |
| same run | Launcher test and the supported-local root tests | passed |
| same run | Whole `es/app` package | Only the expected failures: the 3 tests that PR #17 repairs, the witness test (CI branch entry), and the 2 missing-Go subtests on PR #14's list. Bring-up passed. |
| earlier probe run 45061049559 | Bring-up once | passed (the step then failed in my probe loop, which could not delete files that the ARS container writes as root; fixed in `d38be14`, see section 9) |
| GitHub runner, run 45062879872, two jobs: `bede334` and base `ae326b0` | Root package with the 11 environment-only skips that PR #14's gate uses | Identical at base and change: one failure, `TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSpireBundleReadClassifiesTraversalAmbiguityWithSudoVisibleInspection`, which also fails alone at both. It is a GNU/BSD `stat` order bug in the test harness that PR #14 already fixes (`remote_alpha_operator_test.go:4022`, commit `c4a84f5`); PR #14's own CI passed it. Not this change. All docs contract tests pass. |
| Cloud container, user `ci` (non-root, docker group) | Launcher test and supported-local root tests on `git archive bede334` | passed (`04-evidence/container-launcher-tests-bede334.log`) |
| Cloud container | `gofmt -l es/app`, `go vet ./es/app`, `bash -n scripts/05_start_es.sh` | clean |

Bring-up itself cannot run in the cloud container: it builds the control-plane image, and the container has no egress for image builds.

## 8. Runbooks

- `evo-agi/Archived-Runbooks` at `a834b3d` (main): its seven runbooks cover Remote Alpha recovery, network move, healthcheck, Claude access, the Maintenance Agent install, provenance and chat archiving. None runs `scripts/01_bringup.sh` or `scripts/05_start_es.sh`; Remote Alpha runs ES as the systemd service `es.service`, which this change does not touch. Nothing to update there.
- The in-repo bring-up runbook `.runbooks/system/v1_bringup.md` is updated in the PR (section 6).

## 9. Limits and what this does not cover

- **Other bring-up services still run as root.** ARS, EGS and AGS start the same image without `--user`. On the runner, ARS wrote root-owned files under the test's kept workspace (`rm: cannot remove '.out/bringup-script-…/ars-storage/…': Permission denied`, run 45061049559). The coordinator scoped this change to ES only; the tests still pass and clean up through their own paths. Making the other services run as the operator would be a separate change.
- **Not tested:** Docker Desktop on macOS, a rootless daemon, a user-namespace-remapped daemon, and Remote Alpha (not affected: systemd service). The behaviour on those daemons in section 4 is from the code and docs, not a run.
- **Probe branch** `claude/project-thread-a9tcoa-bringup-probe` (commits `075b028`, `d38be14`, `6b4fa95`) holds only probe workflows. Deleting it, like the three earlier probe branches, needs David's go.

## 10. Next steps

1. Fresh audit of PR #18 (base `ae326b0`, tip `bede334`, manifest `7d2177be…3554`), and the narrow audit of PR #17's `dac9736..962bc89`.
2. After PR #14, PR #17 and the bring-up PR land: rebase the CI branch `claude/project-thread-a9tcoa-ci`, drop nothing for bring-up (it now passes), re-take its manifest, open it, fresh audit. The witness test stays the one expected-skip entry.
