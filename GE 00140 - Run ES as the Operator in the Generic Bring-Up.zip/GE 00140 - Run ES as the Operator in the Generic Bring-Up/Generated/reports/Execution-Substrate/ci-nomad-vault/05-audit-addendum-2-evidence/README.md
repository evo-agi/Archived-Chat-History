# 05-audit addendum 2 evidence (ES PR #18, head c291503)

Written by the independent audit thread "Audit the bring-up fix", 2026-11-22 21:38Z to about 22:00Z.
Every file here was produced in the audit's cloud container. `SHA256SUMS.txt` lists all files.
Nothing in this folder is authority; it is evidence for `../05-audit-addendum-2.md`.

## Setup

- Same container, toolchain, pinned Nomad/Vault/SPIRE, audit image and test users as in 05 and addendum 1.
  `ci` = 1500:1600 (groups cigrp, docker). `ci2` = 1700:1700; by now it is also in group cigrp, which these tests do not use (the
  mutant subtests use a fake `id`, and the real-`id` subtest reads only `id -u` and `id -g`).
- Trees from `git archive c291503`: `/home/ci/es9` (ci) and `/home/ci2/es9` (ci2). Copies `/home/ci/es9sg` (`.out` is
  `ci:proj` 2755, proj = gid 1800 with no members) and `/home/ci/es9dg` (`.out` is `ci:cigrp` 0755; a root-side watcher
  changes the group of the two roots directly).
- dockerd was restarted at about 21:41Z, having stopped after about 21:22Z.

## Files

| File | What |
| --- | --- |
| manifest-v2-open-c291503-base-pinned.json, manifest-v2-close-c291503-base-pinned.json | Base-pinned manifest (upstream origin/trunk_dev) at the start and the end: d3cfd4f4…8dcb |
| manifest-v2-c291503-topic-upstream-rerun.json | One run with upstream origin/claude/project-thread-a9tcoa-bringup: byte-identical to the writer's ecde9a97…2735 |
| manifest-diff-upstream.txt | JSON diff of the two: only the `upstream` line differs |
| launcher-and-docs-test-c291503.log | vet, gofmt, `bash -n` per script, TestESLauncherContainerUser (8/8), `go test . -run Doc` (ok), as ci |
| mutants9.py.txt, mutants9-uid1500-gid1600.log, mutants9-uid1700-gid1700.log | 31 mutants (addendum 1's 24 plus N25-N31 anchor/pattern variants) as ci and ci2: 30 caught, N28 survived |
| bringup_run9.sh.txt | Bring-up runner with a container and ownership poller (the 05 runner, output folder changed) |
| bringup-setgid-parent-c291503*.log | Setgid workspace: up and check pass; first submit fails "stage artifact payload failed" (substrate failure); owners show 1500:1800 roots/probes and a 1500:1600 payload directory |
| chgrp_roots_watcher.sh.txt, direct-group-watcher.log | Watcher that set `es-stage` and `es-results` to `ci:proj` 755 right after bring-up created them |
| bringup-direct-group-c291503*.log | Direct-group roots: bring-up up fails at ES health. The containers log is empty because ES exited before the poller sampled it. Owners show one staging-probe directory 1500:1600 |
| es-log-excerpts-c291503.txt | ES `docker run … --user` prefixes, the setgid run's event/route/status lines, and the direct-group refusal line "validate execution root capabilities: operation not permitted" |
| ci-env.sh.txt | Environment of every run (`env -i` plus this file) |

## Sensitive material

The bring-up tests use synthetic fixtures. No key, certificate body, token or config file is copied
here. The private service logs stayed in the container. A pattern scan for private-key headers and
Vault, JWT, GitHub, Anthropic and AWS token shapes found nothing.
