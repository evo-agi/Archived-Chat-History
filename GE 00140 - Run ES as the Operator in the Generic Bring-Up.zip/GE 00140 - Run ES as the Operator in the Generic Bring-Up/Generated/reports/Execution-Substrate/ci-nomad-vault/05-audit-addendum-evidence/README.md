# 05-audit addendum evidence (ES PR #18, head f5510db)

Written by the independent audit thread "Audit the bring-up fix", 2026-11-22 21:13Z to about 21:45Z.
Every file here was produced in the audit's cloud container. `SHA256SUMS.txt` lists all files.
Nothing in this folder is authority; it is evidence for `../05-audit-addendum.md`.

## Setup

- Same container, toolchain, pinned Nomad/Vault/SPIRE, test users and audit image as in 05
  (`../05-audit-evidence/README.md`): `ci` = 1500:1600 (groups cigrp, docker), `ci2` = 1700:1700.
- Trees: the `f5510db` tree, owned by `ci` at `/home/ci/es5` and by `ci2` at `/home/ci2/es5`. The two copies are byte-identical.
- Audit image: unchanged from 05, built offline from `bede334` sources. It is valid for `f5510db` because
  `git diff --name-only bede334 f5510db` lists no non-test `.go` file (`files-bede334-f5510db.txt`,
  `merge-check.txt`).
- Setgid case: `groupadd -g 1800 proj` (no members). The tree was copied to `/home/ci/es5sg` (identical to
  `/home/ci/es5` except `.out`), then `install -d -o ci -g proj -m 2755 /home/ci/es5sg/.out`. The test's
  workspace (`.out/bringup-script-*`) and the ES roots under it inherit GID 1800.

## Files

| File | What |
| --- | --- |
| merge-check.txt | Per-path blob table (ae326b0, b8d6bc3, 008f4d7, f5510db). Merge-brought diff equals PR #17; PR diff equals bede334 plus repair; writer's diff copy is exact; f5510db tree equals `git merge-tree --write-tree 008f4d7 b8d6bc3`; parents |
| manifest-v2-open-f5510db.json, manifest-v2-close-f5510db.json | Manifest v2 at the start and the end, both sha256 4d6d2c1c…16d1, equal to the writer's copy |
| files-bede334-f5510db.txt | All 10 paths that differ between bede334 and f5510db (7 repair paths plus PR #17's three tests) |
| launcher-test-f5510db.log | vet, gofmt, `bash -n` per script, TestESLauncherContainerUser as ci: 6/6 pass |
| mutants6.py.txt, mutants6-uid1500-gid1600.log, mutants6-uid1700-gid1700.log | 24 mutants of the repaired launcher as ci and ci2: 23 caught, N12 (no end anchor) survived |
| docker-invalid-user.log | Docker refuses `--user 1500x:1600`, `1500:1600x` and `1500 :1600` (exit 125) |
| bringup_run6.sh.txt | Bring-up runner with a container and ownership poller (the 05 runner, output folder changed) |
| bringup-head-f5510db-run{1,2,3}*.log | 3 runs, all PASS. ES PID 1 has Uid 1500, Gid 1600 and Groups 1600; ARS/EGS/AGS have Uid 0 |
| bringup-setgid-parent-f5510db*.log | Setgid workspace: up and check pass, first submit fails "stage artifact payload failed" (substrate failure); run-folder owners show 1500:1800 roots and probes, and a 1500:1600 payload directory |
| es-log-excerpt-setgid.txt | That run's es.log: the `docker run … --user` prefix and the event/route/status lines, with IDs and digests removed |
| setgid-kernel-semantics.log | As 1500:1600 with no supplementary groups (`setpriv --reuid 1500 --regid 1600 --clear-groups`) in a ci:proj 2755 directory: mkdir inherits 1800; chmod 0750 clears setgid; child gets 1600; chgrp child to 1800 is "Operation not permitted"; chgrp to the current group is ok |
| ci-env.sh.txt | Environment of every run (`env -i` plus this file) |

## Sensitive material

The bring-up test uses synthetic fixtures. No key, certificate body, token or config file is copied
here. The private bring-up logs stayed in the container. A pattern scan for private-key headers and
Vault, JWT, GitHub, Anthropic and AWS token shapes found nothing.
