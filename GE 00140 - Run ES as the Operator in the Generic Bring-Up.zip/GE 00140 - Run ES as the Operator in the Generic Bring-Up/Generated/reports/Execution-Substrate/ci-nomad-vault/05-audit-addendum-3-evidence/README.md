# 05-audit addendum 3 evidence (ES PR #18, head d6aded1)

Written by the independent audit thread "Audit the bring-up fix", 2026-11-22 21:53Z to about 22:05Z.
Every file here was produced in the audit's cloud container. `SHA256SUMS.txt` lists all files.
Nothing in this folder is authority; it is evidence for `../05-audit-addendum-3.md`.

Setup is as in addendum 2 (`../05-audit-addendum-2-evidence/README.md`). Trees come from `git archive d6aded1`:
`/home/ci/es10` (ci, 1500:1600), `/home/ci2/es10` (ci2, 1700:1700) and `/home/ci/es10dg` (direct-group case). dockerd was
restarted at about 21:54Z.

| File | What |
| --- | --- |
| manifest-v2-open-d6aded1.json, manifest-v2-close-d6aded1.json | Base-pinned manifest (upstream origin/trunk_dev) at the start and the end: 77017ca3…5786, equal to the reported value and the writer's copy |
| launcher-and-docs-test-d6aded1.log | vet, gofmt, `bash -n` per script, TestESLauncherContainerUser (9/9), `go test . -run Doc` (ok), as ci |
| mutants9.py.txt, mutants9-d6aded1-uid1500-gid1600.log, mutants9-d6aded1-uid1700-gid1700.log | 31 mutants as ci and ci2: 31 caught each; N28 caught by "user name with a digit refused" |
| bringup_run10.sh.txt, chgrp_roots_watcher.sh.txt, direct-group-watcher.log | Bring-up runner, and the watcher that set the two roots to `ci:proj` 755 right after creation |
| bringup-direct-group-d6aded1*.log | Direct-group run: up fails at ES health. The containers log is empty because ES exited before the poller sampled it. Owners show one staging-probe directory 1500:1600 |
| es-log-excerpt-direct-group-d6aded1.txt | `docker run … --user 1500:1600` prefix and "build app: validate execution root capabilities: operation not permitted" |
| ci-env.sh.txt | Environment of every run (`env -i` plus this file) |

No key, certificate body, token or config file is copied here. A pattern scan for private-key headers and Vault,
JWT, GitHub, Anthropic and AWS token shapes found nothing.
