# ES PR #18 audit addendum 2: narrow follow-up audit of head c291503

Second addendum to `05-audit.md` (ACCEPT for `bede334`). The first addendum, `05-audit-addendum.md`, gave BLOCK for `f5510db`. Both files are left unchanged.
Requested by the coordinator on 2026-11-22 21:38Z. Written by the independent audit thread "Audit the bring-up fix", 21:38Z to about 22:00Z.
Evidence: `05-audit-addendum-2-evidence/` beside this file (`SHA256SUMS.txt` lists every file).

**Final verdict for `c291503`: AUDIT_PROVENANCE_MISMATCH.** It covers one field only, and the code passed review.
- **The mismatch.** The writer's manifest (`ecde9a97…2735`) records upstream `origin/claude/project-thread-a9tcoa-bringup`. Provenance §5 rule 2 requires `origin/trunk_dev`. With the upstream pinned to the base, the manifest is `d3cfd4f4be7aaa69b101de04c41850c0ef2b10a75ee8109496044078927e8dcb`. Everything else is byte-identical: commit, tree, path set, classification, every file hash and the textual diff. §5.3 step 3 tolerates only non-executable mode-bit differences, so I cannot accept the reported manifest as it stands.
- **The code review.** I recorded the full review anyway, because the code's identity was established independently of that field (section 2). A6-1 and A6-2 are closed. Two observations remain, and neither blocks.
- **The way out.** If the writer re-takes the manifest with the upstream pinned and gets `d3cfd4f4…8dcb`, my verdict becomes ACCEPT without further code review.

## 1. Audit target

| Field | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate`, draft PR #18 into `trunk_dev` |
| Topic branch | `claude/project-thread-a9tcoa-bringup` |
| Head | `c29150366dcf063fc68f86a92b8c4ecf9a6d4a5d`, also `refs/pull/18/head` (`git ls-remote` at the start and at the end) |
| Head tree | `54bbd9c599885e7f7701595b5f26873c4186aedb`; single parent `f5510db` |
| Base | `trunk_dev` at `b8d6bc3abb8c8c38481c7835824bd79ba26e467b`, unchanged at the end |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2…a3ca`, checked with `sha256sum -c` before each run |
| Writer report | `08-repair-bringup-a6.md`, SHA-256 `1c36e42ca0bc8fda931f02bb72a74cd94d734a5c6ab67e0645f705baeefead66` (matches the coordinator's prefix); `08-evidence/SHA256SUMS.txt` checks OK |

Posture: read-only. No push, PR comment, review, edit or merge. No subagents.

## 2. Provenance

- **Manifest, base-pinned (per provenance §5.3).** HEAD was reset to `b8d6bc3`, the tip bytes were in the tree and upstream was `origin/trunk_dev`. Two opening and two closing runs are byte-identical: `d3cfd4f4be7aaa69b101de04c41850c0ef2b10a75ee8109496044078927e8dcb`. The manifest has 8 paths, and the textual diff is `0aed15a156ad2aae7c1c3a5e94f85755771b14b0d020afe976480f6edab81656`.
- **Writer's manifest.** The writer reported `ecde9a9758af…2735`. Their report (§2) says the upstream was `origin/claude/project-thread-a9tcoa-bringup`. I re-ran the recipe once with that upstream, and the output is byte-identical to `08-evidence/manifest-v2-c291503.json`. A JSON diff of the two manifests shows one line: `"upstream"` (`manifest-diff-upstream.txt`).
- **Classification.** This is the pitfall the provenance guide lists: a manifest taken after `git push -u` without re-pinning the upstream. By §5.3 step 3, it is `AUDIT_PROVENANCE_MISMATCH`.
- **Code identity holds anyway.** It does not rest on that field:
  - the fetched tip equals the reported tip;
  - `git diff f5510db c291503` is byte-identical to `08-evidence/delta-f5510db-c291503.diff`;
  - the textual-diff hash and all eight path hashes are equal.

Order of work: I read the delta before running the manifest, which reverses §5.3's order. I am recording that here.

## 3. Delta `f5510db..c291503`

There are 4 files, +13 −4:
- `.docs/execution_lifecycle/implementation.md`
- `.docs/system_overview/capability_probing.md`
- `.runbooks/system/v1_bringup.md`
- `es/app/es_launcher_container_user_test.go` (two table rows)

No script, product or other test file changed. `git diff --quiet f5510db c291503 -- scripts` holds, and the bring-up test file is unchanged.

## 4. Closure of the addendum-1 findings

| Finding | Status | Basis |
| --- | --- | --- |
| A6-1: runbook said setgid-inherited roots are refused | **Closed** | See the two runs below. The three edited docs match both runs. `PLANS.md` and `contracts.md` state a requirement ("the roots must carry the caller's UID and primary GID"), not a startup refusal. That stays true. |
| A6-2: missing end anchor not caught | **Closed** | N12 is caught by both new subtests, as `ci` and as `ci2`. The one-sided versions N25 (UID) and N26 (GID) are caught by the matching subtest. |
| A6-3: ES readiness gap | Out of scope | The writer moved it to a separate product PR. The new docs say "do not yet catch" and expect A6-3 to change them. |

The two A6-1 runs:
- **Setgid case, re-run on `c291503`.** The workspace was under a `ci:proj` (gid 1800) 2755 directory. `up` and `check` passed. ES ran as 1500:1600, Groups 1600, and answered `/health` and prepare. The first submit failed: HTTP 500, "stage artifact payload failed", reported as a substrate failure. The leftover state is the same as on `f5510db`: roots and probes 1500:1800, a run directory 1500:1800 750 and a payload directory 1500:1600.
- **New direct-group case.** A root-side watcher changed the group of `es-stage` and `es-results` to `proj` right after bring-up created them, with no setgid bit (`chgrp_roots_watcher.sh.txt`, `direct-group-watcher.log`: `ci:proj 755`). ES refused at startup: "build app: validate execution root capabilities: operation not permitted". Bring-up failed at ES health and stopped the other services. ES created one staging-probe directory owned 1500:1600 and nothing after it.

## 5. Validation

| Check | Result |
| --- | --- |
| `go vet ./es/app`, `gofmt -l es/app scripts`, `bash -n` on the three scripts, as `ci` | clean |
| `TestESLauncherContainerUser` as `ci` (1500:1600) | 8 of 8 subtests pass |
| `go test . -run Doc` as `ci` | ok |
| 31 mutants (`mutants9.py.txt`: the 24 from addendum 1, plus N25 to N31), each on a fresh copy, as `ci` (1500:1600) | 30 caught, N28 survived |
| The same 31 as `ci2` (1700:1700) | 30 caught, N28 survived |
| Bring-up, setgid workspace, `c291503` | as in section 4 (`bringup-setgid-parent-c291503*.log`) |
| Bring-up, direct-group roots, `c291503` | as in section 4 (`bringup-direct-group-c291503*.log`) |

The anchor and pattern mutants N25 to N31 are:
- each anchor removed on one side only;
- both anchors removed;
- `[[:alnum:]]`;
- a quoted regex (a literal match).

I wrote them myself; I did not reuse the writer's `mutants8.py`.

Not re-run:
- the ordinary bring-up pass. Scripts, product code and the bring-up test are unchanged since `f5510db`, which passed 3 of 3. Both runs above also went through ordinary `up` (and `check` in the setgid case) on `c291503`.
- the GitHub runner.

Environment events:
- The audit container's dockerd stopped between about 21:22Z and 21:41Z, and I restarted it.
- One setgid attempt skipped because Docker was unreachable. Another never started because it could not write its log. Both outputs were discarded.

## 6. Findings

```text
AUDIT FINDING A7-1
Type / Severity: test coverage; observation
Patch defect or pre-existing: patch (launcher test)
Path: scripts/05_start_es.sh:41 (addendum 1 said :42 for A6-2; the check is on line 41);
  es/app/es_launcher_container_user_test.go
Evidence: mutant N28 (`^` removed on the UID side only) passes all 8 subtests as both users.
  "staff1" covers the GID side only (N29 is caught). No row gives a UID with a leading
  non-digit.
Impact: none today. Real `id -u` prints digits only. Inference: Docker resolves a non-numeric
  user through the image's passwd file and refuses one that is not there, as it did for
  "1500x" (05-audit-addendum-evidence/docker-invalid-user.log). So the gap fails closed.
Suggested correction: a "staff1"-style UID row, if the test is touched again. Not required.
```

```text
AUDIT FINDING A7-2
Type / Severity: docs precision; observation
Patch defect or pre-existing: patch (implementation.md sentence from c291503) and 08 report §3.3
Path: .docs/execution_lifecycle/implementation.md:1002 "A root whose group was set to another group fails it",
  where "it" is the natural 0750 result run-directory probe. 08-repair-bringup-a6.md §3.3 places
  that refusal at es/admission/execution_roots.go:575.
Evidence: the direct-group run refused at startup with "operation not permitted". Only the staging
  probe directory exists, owned 1500:1600, with no results probe file.
Inference: the refusal is the Fchown of the staging probe at execution_roots.go:472, inside the same
  startup capability probes, before the natural-directory check at :575 is reached.
Impact: none for operators. The runbook's "refused" is right, and so is the outcome the sentence
  describes. Only the named check is imprecise.
Suggested correction: optional ("fails ES's startup capability probes"). Fold it into the A6-3 PR,
  which rewrites these sentences anyway.
```

Report only, unchanged: ARS, EGS and AGS still run as root (the services-nonroot tranche).

## 7. Sensitive material

The bring-up tests use synthetic fixtures. No key, certificate body, token or config file is in the evidence. Private service logs stayed in the container. The ES excerpts contain event names, routes and statuses, plus the one startup refusal line, with mounts and digests elided. A pattern scan of the evidence (private-key headers; Vault, JWT, GitHub, Anthropic and AWS token shapes) found nothing.

## 8. Cleanup and effect status

- The audit created container-only artifacts: trees `/home/ci/es9`, `/home/ci2/es9`, `/home/ci/es9sg` and `/home/ci/es9dg`, and the bring-up workspaces, which were removed. No test container is left.
- No push, comment, review, edit, merge or branch change.

## 9. What turns this into ACCEPT

1. **Recommended: the writer re-takes the manifest.** Pin the upstream with `git branch --set-upstream-to=origin/trunk_dev` and take it twice. It should be `d3cfd4f4be7aaa69b101de04c41850c0ef2b10a75ee8109496044078927e8dcb`. Then correct the hash in report 08 and the PR body. No bytes change. I then re-check provenance only and issue ACCEPT for `c291503`.
2. **Alternatively, the coordinator rules the upstream field a recording slip.** It can adopt my base-pinned `d3cfd4f4…8dcb` as the canonical manifest and ask me to issue ACCEPT on that basis. That departs from the letter of §5.3 step 3, so I do not choose it myself.

A7-1 and A7-2 are optional and do not affect either path.

Confidence:
- Provenance: high. The difference is exactly one field.
- Docs against behaviour: high. Both cases were run on `c291503`.
- Test repair: high.

Final verdict: AUDIT_PROVENANCE_MISMATCH
