# ES PR #18 audit addendum: narrow follow-up audit of head f5510db

Addendum to `05-audit.md` (ACCEPT for `bede334`, SHA-256 `bfce8f15626ccf4c850a65be01cd84d093f03d7c06a5488b11504369d5a44bb8`, left unchanged).
Requested by the coordinator on 2026-11-22 21:12Z. Written by the independent audit thread "Audit the bring-up fix", 21:13Z to about 21:45Z.
Evidence: `05-audit-addendum-evidence/` beside this file (`SHA256SUMS.txt` lists every file).

**Final verdict for `f5510db`: BLOCK.** The script and test repair is sound and A5-1, A5-2 and O-2 are closed. A5-3 is not closed: the repaired runbook says ES refuses to start when the roots carry a group handed down by a setgid parent directory. I ran that case. ES started, bring-up reported `submit-ready: true`, and the first submission failed with "stage artifact payload failed", classed as a substrate failure (finding A6-1, low). Correcting that text changes the PR's bytes, so a fresh narrow audit follows either way.

## 1. Audit target

| Field | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate`, draft PR #18 into `trunk_dev` |
| Topic branch | `claude/project-thread-a9tcoa-bringup` |
| Head | `f5510dbbeb9ee4cb4af21347fa3dac8c1d00b65f`, also `refs/pull/18/head`, by `git ls-remote` at the start and again at the end |
| Head tree | `e3149ba15200e2c97433235c857df76fd0aadf82` |
| Base | `trunk_dev` at `b8d6bc3abb8c8c38481c7835824bd79ba26e467b` (PR #17), unchanged at the end |
| Commits since `bede334` | `008f4d7` (repair, parent `bede334`) and `f5510db` (merge, parents `008f4d7` and `b8d6bc3`) |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked with `sha256sum -c` before each run |
| Canonical manifest | `4d6d2c1c9008dda3bfa93fec17d46b61d3a8a5f0780ee0c1a36d42b95c2e16d1`, 8 paths, textual diff `101630ff…6d85f` |
| Writer report | `06-repair-bringup.md`, SHA-256 `bb47bfe71a67ba1134c80d05328bbfe9fbe14b440dbbb82ba0bb83d37deaa4aa` (matches the coordinator's prefix); `06-evidence/SHA256SUMS.txt` checks OK |

Posture: read-only. No push, PR comment, review, edit or merge. No subagents.

## 2. Provenance and the merge claim

All checked in a clean clone (`merge-check.txt`):

- **The merge changed none of the PR's 8 files.** For every path, the blob at `b8d6bc3` equals the blob at `ae326b0`, and the blob at `f5510db` equals the blob at `008f4d7`. The test file is absent at both bases.
- **What the merge brought in is exactly PR #17.** `git diff 008f4d7 f5510db` equals `git diff ae326b0 b8d6bc3`. Both touch only three es/app test files, none of them in the PR.
- **The PR diff equals the repair applied to the audited content.** The PR diff against `b8d6bc3` equals `bede334` plus `008f4d7` against `ae326b0`.
- **The tree matches.** `f5510db^{tree}` equals `git merge-tree --write-tree 008f4d7 b8d6bc3` (`e3149ba1…`).
- **The writer's diff copy is exact.** `06-evidence/repair-bede334-008f4d7.diff.txt` is byte-identical to `git diff bede334 008f4d7` (7 files, +127 −47).
- **The manifest reproduces.** It was taken twice at the start and twice at the end, with HEAD reset to `b8d6bc3`, the tip bytes in the tree and upstream `origin/trunk_dev`. All four copies are byte-identical, and they equal the writer's `06-evidence/manifest-v2-bringup-f5510db.json`.

The writer's claim holds. The repair delta to audit is `git diff bede334 008f4d7`.

## 3. Closure of the 05 findings

| Finding | Status at `f5510db` | Basis |
| --- | --- | --- |
| A5-1: test blind to a UID/GID mix-up when UID equals GID | **Closed** | A new subtest runs the launcher with a fake `id` that prints 4242 and 4343, and checks `--user 4242:4343` in both the printed and the executed command. The swap, GID-is-UID and UID-is-GID mutants (N03, N04, N05) are caught as `ci2` (1700:1700, UID equal to GID) as well as `ci` (1500:1600). |
| A5-2: docs named the wrong gate on remapped daemons | **Closed** | The script comment, `PLANS.md`, `contracts.md`, `capability_probing.md` and the runbook now say what happens: Docker refuses host networking and bring-up stops at its host-loopback check. That matches the 05 run (`05-audit-evidence/userns-remap-docker.log`). Rootless Docker is described as untested and unsupported, with no claim about which check refuses. |
| A5-3: runbook ownership requirement incomplete | **Not closed: A6-1** | The key-file bullet and the config-file bullet are right, as far as code reading and Docker's group behaviour show. The roots bullet is wrong in its setgid example (section 5). |
| O-2: empty UID becomes `--user :GID`, which Docker runs as root | **Closed** | `scripts/05_start_es.sh:37-46` reads `id -u` and `id -g` as two plain assignments under `set -e`, refuses unless both match `^[0-9]+$` and exits 1. The block sits before `ensure_control_plane_image` (`:48`), `verify_es_staging_invariant` (`:49`) and both `docker run` lines (`:58`, `:62`). The empty-UID, failing-`id` and group-name subtests pin the refusal, check that no `docker run` happens, and check that no roots are created. |
| O-4, O-5 | Closed | The `capability_probing.md` wording is now "ES's startup checks, not the launcher". The `contracts.md` profile sentence now names `service-root-v1` and sits before the generic-launcher paragraph. |

Nothing outside the PR's 8 paths changed. `scripts/internal/control_plane.sh`, the profile path and every non-test Go file are unchanged from `bede334` (zero non-test `.go` paths in `git diff bede334 f5510db`).

## 4. Validation re-run

All runs used `env -i` plus `ci-env.sh` (umask 022, `AWS_EC2_METADATA_DISABLED=true`, `GOTOOLCHAIN=local`), Go 1.26.5, Nomad 2.1.1, Vault 2.2.2, SPIRE 1.14.4 musl, and Docker 29.10.0. The setup is the same as in 05 (`05-audit-evidence/README.md`).

| Check | Result |
| --- | --- |
| `go vet ./es/app`, `gofmt -l` on the test, `bash -n` on the three scripts, as `ci` | clean (`launcher-test-f5510db.log`) |
| `TestESLauncherContainerUser` as `ci` (1500:1600) | 6 of 6 subtests pass |
| 24 mutants of the repaired script (`mutants6.py.txt`) as `ci` (1500:1600) | 23 caught, N12 survived (A6-2) |
| The same 24 as `ci2` (1700:1700) | 23 caught, N12 survived. N03 to N05 are caught by the 4242:4343 subtest alone, as intended. |
| `TestBringupScriptUpCheckDownFullProfile` on `f5510db` as `ci`, 3 runs (`bringup_run6.sh.txt`) | **3 of 3 PASS** (38.6 s, 58.1 s, 31.1 s). ES PID 1 has Uid 1500, Gid 1600 and Groups 1600, with `Config.User` `1500:1600`. ARS, EGS and AGS have Uid 0. Run-folder entries ES creates are `1500:1600`, and workload entries are `10000:10000`. |
| The same test with the workspace under a setgid directory of a foreign group | **FAIL at the first submission**, after `up` and `check` passed (section 5) |
| Docker with `--user 1500x:1600`, `1500:1600x` or `1500 :1600` | exit 125, "unable to find user/group … no matching entries" (`docker-invalid-user.log`) |

The mutants cover:

- dropping `--user`;
- adding it to the profile path;
- swaps and substitutions;
- reading `-g` twice;
- checking only one ID, `||` turned into `&&`, `+` turned into `*`, either anchor removed;
- no exit after the refusal, a swallowed `id` failure, the identity block moved after root creation;
- the old inline `$(id -u):$(id -g)` form, `id -ru`/`-rg`;
- the flag omitted from the printed line or from the executed line;
- `--privileged`, a fixed 1000:1000, explicit `0:0`;
- the empty-UID fallback to root.

The audit image is the one from 05: binaries built offline from `bede334` sources. It is valid for `f5510db` because no non-test Go file differs (section 3). The bring-up runs override only `CONTROL_PLANE_DOCKERFILE`, as in 05.

Not re-run:

- the whole es/app and root packages, because the PR's product and test bytes outside the launcher test are unchanged from 05;
- the userns-remap daemon, because the docs now match the 05 observation;
- the GitHub runner. The writer's run 45069185789 log is in `06-evidence`, and I did not re-trigger it.

I did not run a case with a root-only or other-group-only TLS key. The third runbook bullet is reasoned from Docker's empty supplementary group list (`05-audit-evidence/docker-user-identity.log`) and the read-only single-file mounts.

## 5. Findings

```text
AUDIT FINDING A6-1
Type / Severity: docs / operator-runbook accuracy; low
Patch defect or pre-existing: patch defect (text added by the A5-3 repair in 008f4d7)
Current contract: the runbook ES bullet and implementation.md describe what ES refuses at startup
  when it runs as the operator.
Path and line:
  .runbooks/system/v1_bringup.md:248-249 "ES refuses to start unless: the configured staging and
    results roots are owned by your UID and your primary group; roots that carry another group,
    for example a shared project group or the group a setgid parent directory hands down, are refused"
  .docs/execution_lifecycle/implementation.md:999-1002 "this probe sees ES create directories with the
    UID and GID of roots the operator created; roots that carry another group fail it."
  06-repair-bringup.md §3.3 maps the setgid case to es/admission/execution_roots.go:575.
Evidence (bringup-setgid-parent-f5510db*.log, setgid-kernel-semantics.log):
  Same f5510db tree; its .out made ci:proj (gid 1800, ci not a member) mode 2755.
  Roots inherit 1500:1800. `01_bringup.sh up` passed, and `check` printed prepare-ready: true and
  submit-ready: true (the test asserts both before its execute loop, operator_scripts_integration_test.go:384-395).
  ES ran as 1500:1600, Groups 1600, and its startup probes ran: the probe entries are 1500:1800, and the
  natural result directory probe dir is 2750, which passes because the probe compares Perm() and the
  inherited GID equals the root's GID. Prepare succeeded. Submit returned HTTP 500 "stage artifact
  payload failed", reported as "failure category: substrate failure (Docker / Nomad / runtime
  availability)". Its next-step text points the operator at Docker, Nomad and images.
  Left behind: run-…/ 1500:1800 750 (setgid bit cleared) and run-…/payload 1500:1600 750.
Mechanism (Inference, strongly supported): ES creates the run directory in the setgid root, so it gets
  GID 1800. Fchown to 1500:1800 is allowed, because 1800 is the file's current group. Fchmod to 0750
  then clears the setgid bit, so the payload directory created next gets ES's egid 1600.
  Fchown(payload, 1500, 1800) at es/admission/staging_custody.go:578 then fails with EPERM, because
  ES has no supplementary groups. setgid-kernel-semantics.log reproduces each kernel step as
  1500:1600 with no supplementary groups: mkdir → 1500:1800 2755; chmod 0750 → 750; child → 1500:1600;
  chgrp child 1800 → "Operation not permitted"; chgrp to the current group → ok.
  ES did not log the errno.
Impact: an operator whose workspace sits under a setgid directory owned by another group, which is
  common for shared project directories on Linux, gets a ready ES whose submissions fail as a
  substrate failure. The runbook tells them that case is refused at startup, so it steers them away
  from the cause. Fails closed: no privilege widening, nothing staged.
  The roots-with-another-group case without setgid is refused at startup, as written. A new directory
  then gets egid 1600, which is not the root's GID (execution_roots.go:575). That half is from code
  reading only; I did not run it.
Required correction (in PR #18's scope): make the runbook and implementation.md say what happens.
  Roots whose group differs from your primary group are refused at startup when the group was set
  directly. When it is inherited from a setgid parent, ES passes its startup checks and reports
  ready, but every submission fails with "stage artifact payload failed". So keep the bring-up
  workspace out of setgid directories whose group is not your primary group.
  Optionally, the generic path could also refuse that case before starting ES. Whether a launcher-side
  check fits "ES's behavioral startup checks stay the only capability gate" (PLANS.md:220) is the
  coordinator's call. The product-side fix is A6-3.
Uncertainty: one run only. "Every submission fails" is Inference from the mechanism.
```

```text
AUDIT FINDING A6-2
Type / Severity: test coverage; observation
Patch defect or pre-existing: patch (new test)
Path: scripts/05_start_es.sh:42; es/app/es_launcher_container_user_test.go
Evidence: mutant N12 (`^[0-9]+$` turned into `^[0-9]+`) passes all six subtests as both users.
  No subtest feeds a value with a numeric prefix and trailing characters. "staff1" only
  exercises the start anchor (N13 is caught).
Impact: none today. Real `id` prints only digits, and Docker rejects such a value
  (docker-invalid-user.log: exit 125, "unable to find user 1500x"), so the gap fails closed.
Suggested correction: one more refusal case, for example a UID of "4242x", if the writer touches
  the test again for A6-1.
```

```text
AUDIT FINDING A6-3 (report only)
Type / Severity: product readiness gap; low
Patch defect or pre-existing: pre-existing in ES. It applies to any ES that runs without root,
  and PR #18 makes it reachable through the generic launcher.
Path: es/admission/execution_roots.go:449-583 (probeCapabilities, probeNaturalResultDirectory).
  The probes Fchown entries created directly in the roots. They never create an entry inside a
  directory that ES itself has chmodded and then chown that entry, which is what staging does
  (staging_custody.go:503, :578).
Evidence: A6-1's run. Startup probes passed and `check` said submit-ready: true. Staging then failed.
Impact: readiness and "ES's behavioral startup checks stay the only capability gate" (PLANS.md:220)
  over-claim for setgid-inherited roots: ES says ready and cannot submit.
Suggested correction: an ES product change, outside this PR. Extend the startup probe to mirror the
  staging sequence (create a child in the roots, chmod it to 0750, create a grandchild, chown the
  grandchild to the roots' owner), or refuse setgid roots whose GID differs from the egid. This is
  product code, so the merge policy's product-code review applies. Under the project rule on
  remaining edges, it needs a machine-enforced trigger if it is not fixed now.
```

Report only, unchanged from 05: ARS, EGS and AGS still run as root (PID 1 Uid 0 in every run). The coordinator has moved that to a separate tranche.

## 6. Sensitive material

The bring-up test uses synthetic fixtures. No key, certificate body, token or config file is in the evidence. The private ES, Nomad and service logs stayed in the container. The ES log was read only for event names and statuses, with trace and request IDs masked. A pattern scan of the evidence for private-key headers and Vault, JWT, GitHub, Anthropic and AWS token shapes found nothing.

## 7. Cleanup and effect status

- The audit created container-only artifacts: tree copies under `/home/ci` and `/home/ci2`, group `proj` (1800), and the bring-up workspaces. The setgid run's leftover workspace and all test containers were removed.
- No push, comment, review, edit, merge or branch change on GitHub.
- The writer's probe branch `claude/project-thread-a9tcoa-bringup-probe` still exists. Deleting it needs David, since this session cannot delete remote branches.

## 8. Confidence

- Provenance: high.
- Script and test repair: high.
- A6-1: high on the observed behaviour (ES started, check said ready, submit failed); medium-high on the exact failing call, which is Inference backed by the kernel reproduction.
- A6-3: medium on the best fix.

## 9. What would make this ACCEPT

1. Correct the two sentences in A6-1, and the section 3.3 mapping if the writer reissues the report.
2. Optionally add the A6-2 test case.
3. Write a new manifest, then run a fresh narrow audit of that delta.

The coordinator decides A6-3 separately: fix it in ES now, or track it with a machine-enforced trigger.

Final verdict: BLOCK
