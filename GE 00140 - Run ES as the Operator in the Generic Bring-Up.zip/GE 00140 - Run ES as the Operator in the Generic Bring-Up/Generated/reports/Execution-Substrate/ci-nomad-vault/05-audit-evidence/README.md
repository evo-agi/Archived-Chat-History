# 05-audit evidence (ES PR #18, head bede334)

Written by the independent audit thread "Audit the bring-up fix", 2026-11-22 19:58Z to about 20:45Z.
Every file here was produced in the audit's cloud container. `SHA256SUMS.txt` lists all files.
Nothing in this folder is authority; it is evidence for `../05-audit.md`.

## Container setup (no repository bytes changed)

- Ubuntu 24.04 container, kernel 6.18, 4 CPUs, Docker 29.10.0 started inside the container
  (cgroup v1, overlayfs), proxy only in dockerd's own environment. `iproute2` installed so that the
  non-dev Nomad agent of the bring-up test can fingerprint the network (the first two head runs
  failed with `fork/exec /sbin/ip: no such file or directory`; those runs are not kept).
- Go 1.26.5 (`/opt/go1.26.5`), Nomad 2.1.1 and Vault 2.2.2 from the pinned zips
  (`073084f7…3f39`, `5700edf1…d3c4`, checked with `sha256sum --check --strict`), SPIRE 1.14.4 musl
  tarball (`4482db43…cbf5`). Images pulled by the digests of `01-implementation.md` and tagged.
- Test users: `ci` = uid 1500, primary gid 1600 (deliberately different), groups docker;
  `ci2` = uid 1700, gid 1700 (UID equal to GID, like the GitHub runner's 1001:1001).
- Trees: `git archive bede334` -> /home/ci/es, `git archive ae326b0` -> /home/ci/es-base, owned by ci.
  Runs used `env -i` plus `ci-env.sh.txt` (no proxy variables, umask 022,
  `AWS_EC2_METADATA_DISABLED=true`, `GOTOOLCHAIN=local`).
- Audit image: the containers have no egress, so the generated control-plane Dockerfile cannot
  build here. The six service binaries were built offline inside `golang:1.26.5-alpine3.24`
  (`--network none`, `GOPROXY=off`, module cache read-only, same `CGO_ENABLED=0 GOOS=linux
  GOARCH=amd64 go build -o /out/<svc> ./cmd/<svc>` as the generated Dockerfile) from the bede334
  tree, then copied into `alpine:3.20` with no USER line (`Dockerfile.prebuilt.txt`;
  `apk add ca-certificates` omitted, alpine:3.20 already ships the CA bundle).
  The bring-up runs set `CONTROL_PLANE_DOCKERFILE` to `Dockerfile.test.txt` (one `FROM` line), so
  bring-up's own `docker build` step only re-tagged the audit image. Head and base differ in no Go
  product source (`git diff --name-only ae326b0 bede334 -- ags ars cgs cmd egs es internal go.mod
  go.sum` lists only two es/app test files), so one image serves both trees.

## Files

| File | What |
| --- | --- |
| manifest-v2-open-bede334.json, manifest-v2-close-bede334.json | Canonical manifests at audit start and end; both sha256 7d2177be…3554, equal to the writer's copy |
| launcher-test-head.log | vet, gofmt, `bash -n`, TestESLauncherContainerUser on head as ci (1500:1600) |
| mutants.py.txt, mutants-uid1500-gid1600.log | 18 script mutants against the launcher test as ci |
| mutants_ci2.py.txt, mutants-uid1700-gid1700.log | UID/GID mutants rerun as ci2 (UID == GID) |
| profile_values.sh.txt, profile-values.log | Unknown/blank profile values refuse before any root creation or `docker run` |
| docker-user-identity.log | What Docker does with `--user 1500:1600`, `--user :1600`, `--user 1500` |
| bringup_run.sh.txt | Runner for TestBringupScriptUpCheckDownFullProfile with a container/ownership poller |
| bringup-head-bede334-run{1,2,3}*.log | Head, 3 runs, all PASS; ES PID 1 Uid 1500 Gid 1600 Groups 1600; ARS/EGS/AGS Uid 0 (run1 has no ownership log: the poller gained that step after run1) |
| bringup-head-tests-base-script*.log | Head tree with the base `05_start_es.sh` (ES as root): FAIL, ES refuses the operator-owned key |
| bringup-head-mutant-M05-gid-is-uid*.log | Head with `--user $(id -u):$(id -u)` on a 1500:1600 caller: FAIL, ES refuses root capabilities |
| bringup-base-ae326b0*.log | Base tree: FAIL, ES config lacks retained_result_auth |
| es-log-excerpts.txt | The `docker run` prefix and the startup refusal line of each run's es.log (full logs kept out) |
| esapp_whole.sh.txt, esapp-whole-head-summary.txt | Whole es/app package on head: 157 PASS, 4 FAIL (summary; the full 0.9 MB log is not delivered) |
| supported_local_setup.sh.txt, supported-local-setup-head-bede334.log | The supported-local setup test alone without the audit Dockerfile override: the PR #17 failure |
| root_pkg.sh.txt, root-pkg-*.txt | Root package on head and base: identical 32-test failing sets, 429 PASS each, 67 docs tests PASS |
| userns_probe.sh.txt, userns-bringup-head.log, userns-remap-docker.log | dockerd `--userns-remap=default`: Docker refuses host networking; the bring-up test skips at its host-loopback precondition. The script's second step (direct launcher start) had no workspace to use because the test skipped before creating one; its output is not kept. The normal daemon was restored afterwards. |
| merged_check.sh.txt, merged-b8d6bc3-bede334.log | Local trial merge of new trunk_dev b8d6bc3 (#17) with bede334 (tree be39e53e, not pushed): vet ok, launcher and bring-up tests PASS |
| ci-env.sh.txt, Dockerfile.prebuilt.txt, Dockerfile.test.txt, audit-image-binaries.sha256.txt, audit-images.txt | Environment and image identity |

## Sensitive material

The bring-up test uses synthetic fixtures (fixed 0x53 retained-result key bytes, test CAs).
No key, certificate body, token or config file is copied here. The private bring-up logs stayed in
the container. A pattern scan (private-key headers, Vault/JWT/GitHub/Anthropic/AWS token shapes)
found only test names in the root-package logs, which are delivered as summaries only.
