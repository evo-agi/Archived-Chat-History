# ES PR #18: final commit for A7-1 and A7-2, and a base-pinned manifest

Report 09 of the CI Nomad/Vault track. Follows `05-audit-addendum-2.md` (AUDIT_PROVENANCE_MISMATCH for `c291503`: the code passed, but my manifest recorded the topic branch as upstream) and the coordinator's request of 2026-11-22 21:46Z: fix the two observations in one final commit, then take the manifest with the upstream pinned to `origin/trunk_dev`, twice from a fresh clone.

Date: 2026-11-22. Repository: `evo-agi/Execution-Substrate`. Evidence: `09-evidence/` beside this file (`SHA256SUMS.txt` lists every file).

## 1. Outcome

| Item | Result |
| --- | --- |
| Provenance slip in report 08 | **Corrected.** Report 08's manifest `ecde9a97…2735` recorded upstream `origin/claude/project-thread-a9tcoa-bringup`, because `git push -u` had moved it. Provenance guide §5 rule 2 requires the base ref. The new manifest below is pinned to `origin/trunk_dev`. The auditor's base-pinned manifest for `c291503`, `d3cfd4f4…8dcb`, is the correct one for that commit. |
| A7-2 (`implementation.md` named the wrong startup check) | **Fixed.** Roots whose group was set directly are refused earlier in ES's startup capability probes, when ES cannot give its staging probe directory that group. The natural result directory check is never reached. The sentence now says that. |
| A7-1 (UID start-anchor mutant N28 survived) | **Fixed.** New refusal row "user name with a digit refused" (UID `staff1`). N28 is caught, as `ci` and `ci3`. |
| New head | `d6aded1747903013745cc897b2c2d13df53612c6`, tree `9be504588d946443defcf476100453e5ca7e92c1`, parent `c291503` (`git ls-remote` after the push) |
| New manifest | `77017ca39f453e2ea9eb477b73518edf2cb957c743c4d98883b0cda32a435786`, base `b8d6bc3`, upstream `origin/trunk_dev`, 8 files, textual diff `b5c68cf2bd129e334553a98b5576b652e4a8e13278216fb3da45f50656439734` |

Nothing was merged. PR #18 stays a draft.

## 2. Target identity

| Field | Value |
| --- | --- |
| Base | `trunk_dev` at `b8d6bc3abb8c8c38481c7835824bd79ba26e467b` |
| Topic branch and tip | `claude/project-thread-a9tcoa-bringup` at `d6aded1747903013745cc897b2c2d13df53612c6` |
| Delta since the audited `c291503` | 2 files, +6 −3: `.docs/execution_lifecycle/implementation.md`, `es/app/es_launcher_container_user_test.go`. Full diff: `09-evidence/delta-c291503-d6aded1.diff` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked with `sha256sum -c` |
| Manifest procedure | `umask 022`; fresh clone of the topic branch from GitHub after the push; `git fetch origin trunk_dev`; `git reset --mixed b8d6bc3`; `git branch --set-upstream-to=origin/trunk_dev` before each of the two runs; output into a `0700` directory; the two outputs are byte-identical. 8 files: 7 `tracked_modified`, 1 `untracked` (the launcher test). Copy: `09-evidence/manifest-v2-d6aded1-upstream-trunk_dev.json` |

## 3. Changes

- `.docs/execution_lifecycle/implementation.md`: "A root whose group was set to another group fails it. A setgid root with another group passes it, because the new directory inherits the root's group; …" is now "Roots whose group was set directly to another group are refused earlier in ES's startup capability probes, when ES cannot give its staging probe directory that group. Roots that inherit another group from a setgid parent pass those probes, because entries created directly in them inherit that group; …". The rest of the sentence is unchanged. This matches the auditor's direct-group run (refusal "validate execution root capabilities: operation not permitted", with only the staging probe directory created).
- `es/app/es_launcher_container_user_test.go`: one row, "user name with a digit refused". The fake `id` prints `staff1` and `4343`. The launcher must refuse with "id -u and id -g must print numeric IDs, got staff1 and 4343" after calling only `id -u` and `id -g`, with no `docker run`, no run-arguments file and no roots.

**Correction to `08-repair-bringup-a6.md` §3.3.** It said the direct-group refusal happens at `es/admission/execution_roots.go:575`. That was also wrong. The refusal is the staging probe's `Fchown` (`:472` at `c291503`), before line 575 is reached, as the auditor's run shows. Report 08 is left unchanged because its hash was handed over.

## 4. Checks

| Check | `ci` 30033:30033 | `ci3` 31500:31600 |
| --- | --- | --- |
| `gofmt -l es/app scripts`, `go vet ./es/app`, `bash -n scripts/05_start_es.sh` | clean | clean |
| `TestESLauncherContainerUser`, 9 subtests | pass | pass |
| `go test . -run Doc` | ok | not run (does not depend on the user) |
| The auditor's `mutants9.py` (31 mutants, byte-identical to `05-audit-addendum-2-evidence/mutants9.py.txt`) | 31 caught, unmutated passes | 31 caught, unmutated passes |
| My `mutants8.py` (26 mutants, byte-identical to `08-evidence/mutants8.py.txt`) | 26 caught, unmutated passes | 26 caught, unmutated passes |

The anchor mutants: N28 (UID start anchor) is caught by the new row, N29 (GID start anchor) by the "group name with a digit" row, N25 and N26 by the two trailing-characters rows, and N27 and N30 by all four rows.

Logs: `launcher-and-docs-test-d6aded1.log`, `a7-mutants-uid30033-gid30033.log`, `a7-mutants-uid31500-gid31600.log`.

**Runner.** No separate runner run: the delta is one docs sentence and one table row of a test that needs no Docker. The services tranche (report 07) merges this head before its next runner run, so the GitHub runner runs the new row there.

## 5. Effects

- Pushed `d6aded1` to `claude/project-thread-a9tcoa-bringup` (fast-forward from `c291503`).
- PR #18 description updated for the new head and manifest.
- No merge.

## 6. Request

Final narrow audit of `c291503..d6aded1` (one docs sentence, one test row) with manifest `77017ca3…5786`.
