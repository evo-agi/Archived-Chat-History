# ES PR #18 audit addendum 3: final narrow audit of head d6aded1

Third addendum to `05-audit.md` (ACCEPT `bede334`).
- `05-audit-addendum.md` gave BLOCK for `f5510db`.
- `05-audit-addendum-2.md` gave AUDIT_PROVENANCE_MISMATCH for `c291503`, on the manifest's upstream field only; the code passed.

All three files are left unchanged.
Requested by the coordinator on 2026-11-22 21:52Z. Written by the independent audit thread "Audit the bring-up fix", 21:53Z to about 22:05Z.
Evidence: `05-audit-addendum-3-evidence/` beside this file (`SHA256SUMS.txt` lists every file).

**Final verdict for `d6aded1`: ACCEPT.**
- The reported manifest reproduces exactly, with the upstream pinned to `origin/trunk_dev`.
- The delta is the one doc sentence and the one test row described.
- The sentence matches ES's behaviour, which I re-ran on this head.
- Mutant N28 is now caught.
- No finding is open.

## 1. Audit target

| Field | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate`, draft PR #18 into `trunk_dev` |
| Topic branch | `claude/project-thread-a9tcoa-bringup` |
| Head | `d6aded1747903013745cc897b2c2d13df53612c6`, also `refs/pull/18/head` (`git ls-remote` at the start and at the end) |
| Head tree | `9be504588d946443defcf476100453e5ca7e92c1`; single parent `c291503` |
| Base | `trunk_dev` at `b8d6bc3abb8c8c38481c7835824bd79ba26e467b`, unchanged at the end |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked with `sha256sum -c` before each run |
| Canonical manifest | `77017ca39f453e2ea9eb477b73518edf2cb957c743c4d98883b0cda32a435786`, upstream `origin/trunk_dev`, 8 paths, textual diff `b5c68cf2bd129e334553a98b5576b652e4a8e13278216fb3da45f50656439734` |
| Writer report | `09-repair-bringup-a7.md`, SHA-256 `5e8865fa37ad87af43a483b61b4cb490269cbc468e1c5247a70a5c2d0319a78f` (matches the coordinator's prefix); `09-evidence/SHA256SUMS.txt` checks OK |

Posture: read-only. No push, PR comment, review, edit or merge. No subagents.

## 2. Provenance

I took the manifest first, before reading the delta, following provenance §5.3. It was taken in a clean clone, with HEAD reset to `b8d6bc3`, the tip bytes in the tree and upstream `origin/trunk_dev`.
- Two opening and two closing runs are byte-identical: `77017ca3…5786`.
- They equal the reported value and the writer's copy `09-evidence/manifest-v2-d6aded1-upstream-trunk_dev.json`.
- The path set and classification are the same 8 paths as in the `f5510db` and `c291503` manifests.

The manifest is base-relative, so it covers the PR's whole range, not only the delta.

## 3. Delta `c291503..d6aded1`

Two files, +6 −3. `git diff c291503 d6aded1` is byte-identical to `09-evidence/delta-c291503-d6aded1.diff`. No script, product or other test file changed: there are no non-test paths under `scripts`, `ags`, `ars`, `cgs`, `cmd`, `egs`, `es`, `internal`, `go.mod` or `go.sum`.

- **`.docs/execution_lifecycle/implementation.md:1002-1008`.** The sentence now reads: "Roots whose group was set directly to another group are refused earlier in ES's startup capability probes, when ES cannot give its staging probe directory that group. Roots that inherit another group from a setgid parent pass those probes, because entries created directly in them inherit that group; staging then clears the setgid bit …".
  - **Correct:** in the direct-group run on `d6aded1` (section 4), ES refused at startup with "build app: validate execution root capabilities: operation not permitted". The only entry it created is the staging-probe directory, owned 1500:1600.
  - That is the `Fchown` of the staging probe to the roots' owner in `probeCapabilities` (`es/admission/execution_roots.go:472`), before the natural-directory check at `:575`. The product code is unchanged since addendum 2.
  - In the setgid run (addendum 2, `c291503`, same product bytes), the probe entries were 1500:1800 and passed, as the second sentence says.
  - This closes A7-2. The writer's correction of report 08 §3.3 in report 09 §3 agrees.
- **`es/app/es_launcher_container_user_test.go`.** One refusal row, "user name with a digit refused": fake `id` prints `staff1` and `4343`, and the launcher must refuse after only `id -u` and `id -g`, with no `docker run`, no run-arguments file and no roots. This closes A7-1.

## 4. Validation

| Check | Result |
| --- | --- |
| `go vet ./es/app`, `gofmt -l es/app scripts`, `bash -n` on the three scripts, as `ci` (1500:1600) | clean |
| `TestESLauncherContainerUser` as `ci` | 9 of 9 subtests pass |
| `go test . -run Doc` as `ci` | ok |
| My 31 mutants (`mutants9.py`, unchanged since addendum 2), each on a fresh copy, as `ci` (1500:1600) | **31 of 31 caught**; unmutated passes. N28 is caught by "user name with a digit refused". |
| The same 31 as `ci2` (1700:1700) | **31 of 31 caught**; N28 caught by the same row |
| Bring-up with the two roots' group changed directly to `proj` (gid 1800, no setgid) right after creation, on `d6aded1` | ES refused at startup ("validate execution root capabilities: operation not permitted"). Bring-up failed at ES health and stopped the other services. Only a staging-probe directory owned 1500:1600 exists. |

Not re-run:
- the ordinary bring-up pass and the setgid case. Scripts, product code and the bring-up test are unchanged since `f5510db`, which passed 3 of 3, and since `c291503`, where I re-ran the setgid case. The setgid sentence is unchanged apart from "pass those probes, because entries created directly in them inherit that group", which matches the 1500:1800 probe entries of that run.
- the GitHub runner.

The container's dockerd had stopped again by about 21:54Z, and I restarted it before the bring-up run.

## 5. Findings

None open.

| Finding | Status at `d6aded1` |
| --- | --- |
| A5-1, A5-2, O-2 | Closed (addendum 1) |
| A5-3 / A6-1 | Closed (addendum 2; sentence wording refined here) |
| A6-2 | Closed (addendum 2) |
| A7-1 | **Closed**: N28 caught as both users |
| A7-2 | **Closed**: sentence names the staging probe, matching the run |
| Addendum-2 provenance mismatch | **Resolved**: manifest taken with upstream `origin/trunk_dev` and reproduced |

Report only, unchanged:
- A6-3: ES's startup probes do not catch setgid-inherited roots. This is a product gap with its own PR planned, and the docs say "do not yet catch".
- ARS, EGS and AGS still run as root. That belongs to the services-nonroot tranche.

## 6. Sensitive material

The bring-up test uses synthetic fixtures. No key, certificate body, token or config file is in the evidence. Private service logs stayed in the container. The ES excerpt holds the `docker run … --user` prefix and the one refusal line. A pattern scan of the evidence (private-key headers; Vault, JWT, GitHub, Anthropic and AWS token shapes) found nothing.

## 7. Cleanup and effect status

- The audit created container-only artifacts: trees `/home/ci/es10`, `/home/ci2/es10` and `/home/ci/es10dg`, and the bring-up workspace, which was removed. No test container is left.
- No push, comment, review, edit, merge or branch change.
- The probe branch `claude/project-thread-a9tcoa-bringup-probe` from report 06 still needs deleting by David, since this session cannot delete remote branches.

## 8. Confidence

- Provenance: high.
- Test repair: high (31 of 31 as two users).
- Docs against behaviour: high (run on this head).

Merge gate per provenance §5.4: the PR head must still be `d6aded1` and `trunk_dev` still `b8d6bc3` at merge time. If `trunk_dev` moves, the branch update needs a new manifest.

Final verdict: ACCEPT
