# ES PR #18: independent audit of "Run ES as the operator in the generic bring-up"

Report 05 of the CI Nomad/Vault track. Fresh, read-only audit thread "Audit the bring-up fix", started by the coordinator 2026-11-22 19:58Z, finished about 20:50Z. Evidence: `05-audit-evidence/` beside this file (`SHA256SUMS.txt` lists every file, `README.md` describes the setup).

**Final verdict: ACCEPT** for head `bede33446fd76426d00f32605ef61b905e82fab6`, with three **low** findings open (one test gap, two doc accuracy gaps) and no medium or higher finding. The script change does what it claims, narrows ES's privilege, and I ran the bring-up integration test green 3 of 3 as a non-root user whose UID differs from its GID. Recommendation: repair A5-1 to A5-3 in the same branch update that trunk_dev's move now requires (section 9), then a narrow audit.

## 1. Audit target

| Field | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| PR | [#18](https://github.com/evo-agi/Execution-Substrate/pull/18), draft, into `trunk_dev`, 1 commit, 8 files, +206 −4 (GitHub API, read 19:59Z) |
| Base | `ae326b0ddc30ec6b35883ee32945c622405b68b6` (trunk_dev when the PR was opened; trunk_dev has since moved, section 9) |
| Topic branch and tip | `claude/project-thread-a9tcoa-bringup` at `bede33446fd76426d00f32605ef61b905e82fab6` (`git ls-remote` at 20:36Z: unchanged) |
| Tree | `97646f8ef2f9ef0f7c7631edc9fa14300a8a424f` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (checked with `sha256sum -c` before each run) |
| Canonical manifest | `7d2177bec833a90a61e153805e76bf1914b879285a9693f98fa6c679278c3554`, 8 files (7 `tracked_modified`, 1 `untracked`), textual diff `513b252ef40743a0bd10c8842371af96bee23b12b0e2549307f2ea212c380158` |
| Writer report | `04-bringup.md`, SHA-256 `945b95e16ba96830d6e8503a88fccb5111b2fef7e56ae0ebf9f927d8936df3cb` at 19:59Z and again at 20:30Z (the writer's reply stated no hash, observation O-6). Its evidence `04-evidence/SHA256SUMS.txt` verifies (12 of 12 OK). |

## 2. Audit posture

- Read-only. No repository edit, commit, push, PR comment or review. Work happened in a fresh clone under `/opt/audit/es` and in `git archive` copies owned by test users.
- No subagents. I covered the four audit perspectives (contract and authority, correctness and state, test adequacy, security, filesystem and process) myself; the diff is 8 files. Limitation: no second, independent reading inside this audit.
- Side effects: inside the audit container only (dockerd, test users, `iproute2`, a temporary `--userns-remap` daemon that I replaced with the normal one).

## 3. Provenance reproduction

Commands as in provenance §5.3 (umask 022, fresh clone, `git fetch origin trunk_dev <topic>`, tip and ancestor checks, `git reset --mixed ae326b0`, upstream pinned to `origin/trunk_dev`, recipe run twice into a fresh 0700 directory).

| Check | Result |
| --- | --- |
| Pushed tip equals reported tip | yes, `bede334` |
| Base is an ancestor of the tip | yes; 1 commit in `ae326b0..bede334` |
| Two opening runs | byte-identical (`cmp`) |
| Equal to the writer's manifest | yes, byte for byte (`cmp` against `04-evidence/manifest-v2-bringup-bede334.json`) |
| Closing runs (after all tests) | byte-identical to the opening manifest |
| Tolerated mode-bit differences | none |

Copies: `05-audit-evidence/manifest-v2-open-bede334.json`, `manifest-v2-close-bede334.json`.

## 4. What changed (all 8 paths read in full at bede334)

| Path | Change | Checked |
| --- | --- | --- |
| `scripts/05_start_es.sh` | +19 −2: a comment, `USER_SPECS=()`, and `USER_SPECS=(--user "$(id -u):$(id -g)")` when `SUPPORTED_LOCAL_ES_ROOTS_PROFILE` is empty; the array is expanded as `${USER_SPECS[@]+"${USER_SPECS[@]}"}` in both the printed and the executed `docker run` | section 5 |
| `es/app/es_launcher_container_user_test.go` (new, 176 lines) | Fake `docker` and fake `python3`; pins the exact `docker run` arguments for the generic path and the `service-root-v1` path | section 6 |
| `es/app/operator_scripts_integration_test.go` | +2 −1: supplies `RetainedResultAuth` from the existing helper; the allowed SPIRE bind source becomes `filepath.Dir(socket)` | section 7 |
| `PLANS.md`, `.docs/execution_lifecycle/contracts.md`, `.docs/execution_lifecycle/implementation.md`, `.docs/system_overview/capability_probing.md`, `.runbooks/system/v1_bringup.md` | One added bullet, sentence or line each; no existing sentence changed (`git diff` shows only additions there, except the one runbook line, which is extended) | section 8 |

Nothing else changed: the manifest holds exactly these 8 paths, GitHub reports 8 files and +206 −4, which equals `git diff --stat` (+30 −4) plus the 176-line new file. `git diff --check` is clean; no CR characters.

## 5. The script change

**Privilege.** Repo-validated at bede334:

- Generic path (no profile): ES now runs as the caller's effective UID and primary GID. Observed in all three head runs: ES PID 1 `Uid: 1500 1500 1500 1500; Gid: 1600 1600 1600 1600; Groups: 1600` and `docker inspect` `Config.User=1500:1600` (`bringup-head-bede334-run*-containers.log`). Before, ES ran as the image's default user, root, with root's supplementary groups. No capability, device, `--privileged` or `--group-add` option was added; the launcher test fails if one is (mutants M15, M16 in section 6).
- `service-root-v1` path: unchanged, no `--user` (pinned by the second subtest; mutant M02 caught).
- So the change narrows ES's privilege. It widens nothing.

**Can the UID:GID be spoofed through the environment?**

- `USER_SPECS` is assigned in the script before use (`scripts/05_start_es.sh:43`); bash does not import arrays from the environment.
- The branch variable `SUPPORTED_LOCAL_ES_ROOTS_PROFILE` is tested with the same emptiness rule that `verify_es_staging_invariant` uses (`scripts/internal/control_plane.sh:303-312`, `:368`), and that function runs first (`scripts/05_start_es.sh:25`) and refuses every value except empty and `service-root-v1`. Observed: `bogus`, a single space, `service-root-v2` and `SERVICE-ROOT-V1` each exit 1 with "unsupported supported-local roots profile", create no root and call no `docker rm` or `docker run` (`profile-values.log`). Choosing `service-root-v1` also requires the static validator to accept `0:0` roots, proof binding, image, Dockerfile and mounts.
- `id` is found through `PATH` (observation O-2). A caller who plants an `id` can pick any `--user`, but that caller can already run `docker` directly (docker group access is root-equivalent on a rootful daemon). No boundary is crossed.

**Is the derivation right?** `id -u`/`id -g` are the effective UID and primary GID, the identity that `mkdir -p` in `verify_es_staging_invariant` (`scripts/internal/control_plane.sh:369-374`) uses when it creates missing roots. ES compares both UID and GID of its naturally created directory with the roots (`es/admission/execution_roots.go:575`) and chowns probe objects to that owner (`:472`, `:516`), so the GID matters as much as the UID. Under `sudo`, `id -u` is 0 and the roots are created by root, which stays consistent.

**Ownership of run folders.** With ES at 1500:1600, everything ES created under the staging and results roots was `1500:1600` (probe directories `0750`, run directories `0750`, payload `0600`); the workload's `run/work` and `run/result` were `10000:10000` while the task ran, and the runtime helper's `ownership-normalization.json` and the platform files were `1500:1600` (`bringup-head-bede334-run2-run-folder-owners.log`, same in run 3). This matches the existing hand-back design: ES passes the roots' owner to the helper (`es/admission/submit.go:20-22`) and the helper normalizes the tree back to it (`es/runtimehelper/supervisor.go:333-345`). The test's own cleanup removed both roots without a permission error. The only residue after a passing run was ARS's root-owned storage (O-9).

**Retained-result key.** ES requires the key to be owned by its effective UID (`es/admission/result_auth.go:109`) and its parent to be owned by that UID or by 0 and not group- or world-writable (`:55-58`). The launcher mounts every config `*_file` path as a single read-only file (`scripts/internal/control_plane.sh:165-174`), so inside the container the parent is a Docker-created root-owned directory. Observed: with the base script (ES as root) and the operator-written key, ES stops with "retained result authentication key has unsafe identity, access or length"; with the fix it starts (`es-log-excerpts.txt`).

**Edge observed but not reachable in practice:** `docker run --user :1600` runs as uid 0 (`docker-user-identity.log`). The script would produce that only if `id -u` printed nothing while `id -g` worked (bash keeps going in an array assignment when an earlier command substitution fails; checked). That needs a broken or planted `id` (O-2).

## 6. The launcher test

`TestESLauncherContainerUser` passes on head as `ci` (1500:1600) and as `ci2` (1700:1700) (`launcher-test-head.log`, `mutants-uid1700-gid1700.log`). `gofmt -l es/app scripts` prints nothing, `go vet ./es/app` and `bash -n scripts/05_start_es.sh` are clean.

I wrote 18 mutants of `scripts/05_start_es.sh` (`mutants.py.txt`), each applied to a fresh copy of the head tree, test run as `ci` (UID ≠ GID):

| Result | Mutants |
| --- | --- |
| Caught (15) | M01 never pass `--user`; M02 pass it in the profile path too; M03 inverted condition; M04 UID only (Docker then uses GID 0); M05 GID replaced by UID; M06 UID replaced by GID; M07 UID and GID swapped; M09 fixed `1000:1000`; M10 explicit `0:0`; M11 names instead of numbers; M12 omitted from the printed line only; M13 omitted from the executed line only; M14 `--user` passed after the image (as an ES argument); M15 extra `--privileged`; M16 extra `--group-add 0` |
| Survived, equivalent (3) | M08 `id -ru`/`id -rg` (same as effective IDs for a non-setuid shell script); M17 test `!= service-root-v1` instead of emptiness (equivalent because every other value is refused first, `profile-values.log`); M18 unquoted `${USER_SPECS[*]:-}` (the words contain no spaces or glob characters) |

The writer's six mutants are a subset of these. As `ci2`, whose UID equals its GID like the GitHub runner's `1001:1001`, M05, M06 and M07 **survive** (`mutants-uid1700-gid1700.log`). That is finding A5-1.

The test pins argument order (for example `--user` before the mounts). A harmless reorder would fail it; I consider that acceptable strictness.

## 7. The bring-up integration test

Run as `ci` (1500:1600), Nomad 2.1.1, `AWS_EC2_METADATA_DISABLED=true`, audit image (deviation described in the evidence README: binaries built offline in the pinned Go image, bring-up's build step only re-tagged it).

| Run | Result | ES identity | Startup refusal in es.log |
| --- | --- | --- | --- |
| head `bede334`, run 1 | PASS 30.9 s | `1500:1600` | none, ES healthy |
| head, run 2 | PASS 30.2 s | `1500:1600` | none |
| head, run 3 | PASS 30.3 s | `1500:1600` | none |
| head inside the whole es/app run | PASS 25.7 s | | |
| head tree with the **base** `05_start_es.sh` | FAIL (bring-up up) | root | "retained result authentication key has unsafe identity, access or length" |
| head with mutant M05 (`--user 1500:1500`) | FAIL | `1500:1500` | "validate execution root capabilities: operation not permitted" |
| base tree `ae326b0` as is | FAIL | root | "load config: execution.retained_result_auth.store_id must be a canonical 1-32 byte identifier" (the stale-test failure the writer described) |
| trial merge of trunk_dev `b8d6bc3` + `bede334` (local tree `be39e53e`, not pushed) | PASS 49.3 s, launcher test PASS, vet ok | | |

My head runs are stronger than the runner's on one point: here UID and GID differ, so they show the GID half is right; on the runner both are 1001.

**The two test-assertion changes are correct.** The retained-result key helper (`es/app/submit_integration_test.go:1476-1487`) writes 32 fixed bytes, mode 0600, outside both roots, as the operator, which matches the contract (`.docs/execution_lifecycle/contracts.md:1488-1497`). ES mounts the SPIRE socket's directory (`es/admission/resolved_execution_plan.go:404`, used at `es/admission/executionpackage.go:285`). `assertNomadBindSourcesUnderStagingRoot` (`es/app/operator_scripts_integration_test.go:3885-3960`) matches external sources exactly, fails on any other external source and fails if an allowed one is missing, so it is as strict as before.

**Whole `es/app` package on head** (`esapp-whole-head-summary.txt`): 157 PASS, 4 FAIL. The four: the two stale tests PR #17 repairs (stage-root count, symlink-entry 403), the installed-source witness (envelope incomplete, expected), and the supported-local setup test. That last one first failed because my audit Dockerfile override leaked into it; run alone without the override it fails with "supported-local execution-root scope is invalid", which is PR #17's third repaired test (`03-audit.md` section 5.3; `supported-local-setup-head-bede334.log`). No failure is attributable to PR #18.

**Root package**, head and base, same container (`root-pkg-summary.txt`): 429 PASS and 32 FAIL on both, identical failing sets (Remote Alpha environment tests, and the artifact-hygiene test that needs a `.git` directory). All 67 docs tests whose names contain "Doc" pass on both.

## 8. Contract, AGENTS.md section 12, docs and runbook

**AGENTS.md section 12 reading: correct.** Section 12 says "NEVER introduce OS-based branching for capability-sensitive behavior", "ALWAYS validate capability by behavior or static resource checks, not by platform labels" and "FAIL fast … do not add fallback behavior". `.docs/system_overview/capability_probing.md:13` adds that services must not use "runtime-label checks to change behavior for capability-sensitive slices". A launcher that read `docker info` and skipped `--user` on a daemon reporting `rootless` would be exactly such a label check, and it would add a fallback identity. The remaining branch on `SUPPORTED_LOCAL_ES_ROOTS_PROFILE` is explicit operator configuration with its own static validator, not a platform label, and it predates this PR.

**Seam classification.** PLANS.md:220 files the change as a **Bounded slice rule** refinement (`GENERIC-ES-LAUNCHER-USER-01`), with docs in the same commit, as AGENTS.md section 7 requires. Non-root ES has precedent: archived v1 evidence records Remote Alpha's `es.service` running as `User=es`, `Group=es` (`.docs/system_overview/configuration.md:983-984`; the same doc calls that service-user route retired, `:972-974`). The existing sentence "This profile does not … approve rootless/non-root variants" (`contracts.md:1534-1536`) is about `service-root-v1`, so it does not conflict (O-5 on its placement).

**Runbook versus script.** The added runbook line (`.runbooks/system/v1_bringup.md:248`) matches the script on what it states: generic path, your own UID:GID, roots and key must be yours, ES refuses otherwise. It is incomplete on two points (A5-3), and it names the wrong refusing gate for remapped daemons (A5-2).

**Remapped and rootless daemons.** I restarted dockerd with `--userns-remap=default` and ran the head bring-up test there. Docker refused the host-network container itself: `docker run --rm --network host --user 1500:1600 alpine:3.20 id` gives "cannot share the host's network namespace when user namespaces are enabled", exit 125, and the bring-up test skips at its own host-loopback precondition (`userns-remap-docker.log`, `userns-bringup-head.log`). ES never starts on such a daemon, before or after this PR, but the new docs say ES's startup probe is what refuses (A5-2). I did not test a rootless daemon. Inference, from Docker's documented rootless networking and not verified here: `--network host` there joins RootlessKit's namespace, so bring-up's host-loopback preflight would probably refuse before ES. Unknown until someone runs it. That also makes the writer's table row "Rootless: before, probably started" doubtful (O-7).

## 9. Findings

### A5-1: CI cannot detect UID/GID confusion in the launcher test

- **Type / severity:** test gap / **low**. Patch defect (new test).
- **Path:** `es/app/es_launcher_container_user_test.go:26` (`callerUser` from the host's real IDs) and `:130-131`.
- **Evidence:** as `ci2` (1700:1700), mutants M05 `$(id -u):$(id -u)`, M06 `$(id -g):$(id -g)` and M07 `$(id -g):$(id -u)` pass the test; as `ci` (1500:1600) all three fail it (`mutants-uid1700-gid1700.log`, `mutants-uid1500-gid1600.log`). The GitHub runner is `1001:1001` (`04-bringup.md` section 7).
- **Impact:** a later edit that mixes up UID and GID would pass CI and break bring-up for every operator whose primary GID differs from the UID. It fails closed: in my M05 integration run ES refused at startup ("validate execution root capabilities: operation not permitted"). No privilege widening.
- **Required correction:** make the generic case independent of the host's IDs. One way: a fake `id` on the test's `PATH` that prints distinct values for `-u` and `-g` (and fails for any other argument), with the test expecting exactly `--user <fake UID>:<fake GID>` in both the executed and the printed command. Keeping the real-ID case as well is fine. Show M05 to M07 caught on a host whose UID equals its GID.
- **Uncertainty:** none on the survival; it is observed.

### A5-2: the new docs name the wrong gate on user-namespace-remapped daemons

- **Type / severity:** doc/contract accuracy / **low**. Patch defect.
- **Paths at bede334:** `scripts/05_start_es.sh:38-41` (comment), `PLANS.md:220` ("so ES refuses to start"), `.docs/execution_lifecycle/contracts.md:1531-1532` ("ES's startup capability probe refuses instead"), `.runbooks/system/v1_bringup.md:248` ("ES refuses to start … on a rootless or user-namespace-remapped Docker daemon"). Related wording in `.docs/system_overview/capability_probing.md:159-161` (O-4).
- **Evidence:** on a `--userns-remap=default` daemon, Docker rejects the launcher's own `docker run --network host --user …` form with exit 125, and the bring-up test skips at its host-loopback precondition (`userns-remap-docker.log`, `userns-bringup-head.log`). ES is never started, so its probe never runs. Rootless was not run by the writer or by me.
- **Impact:** none on behaviour (no ES starts, nothing widens). But four added contract and runbook statements describe a refusal path that does not happen for remapped daemons, and AGENTS.md section 9 requires docs, tests and code to "describe the same current reality". An operator debugging a remapped host would look in `es.log` for a refusal that is not there.
- **Required correction:** state what is observed: on a user-namespace-remapped daemon Docker refuses host networking, so bring-up cannot start ES (or any service). For rootless, say it is untested and unsupported for bring-up, without claiming which check refuses, unless someone runs it. The writer's report table (section 4) should be corrected the same way.

### A5-3: the runbook's ownership requirement is incomplete

- **Type / severity:** runbook/doc gap / **low**. Patch defect.
- **Path:** `.runbooks/system/v1_bringup.md:248` ("you must own the configured staging and results roots and the retained-result key file").
- **Evidence:**
  - (a) **Group.** ES compares UID **and** GID of its natural result directory with the roots (`es/admission/execution_roots.go:575`) and chowns probe objects to the roots' UID:GID (`:472`, `:516`). Roots that you own but that carry another group (for example a shared project group) are refused. The M05 run shows the refusal when the container GID differs from the roots' GID.
  - (b) **Other configured files.** ES now reads every `*_file` the config names (TLS cert and key, client CA, the ARS and EGS client cert and key, root CA), each mounted read-only (`scripts/internal/control_plane.sh:165-174`), as your UID and primary GID only. Docker gives `--user uid:gid` no supplementary groups (`docker-user-identity.log`; ES PID 1 `Groups: 1600`). Before, ES read them as root. A key that is readable only by root, or only through a supplementary group, will now stop ES when it loads that file, not at the root probe. Inference from file permissions and Docker's behaviour; I did not run that case.
- **Impact:** operators can follow the runbook and still hit a startup failure it does not explain. No security impact.
- **Required correction:** in the runbook (and, if wanted, the contracts.md sentence): the roots must be owned by your UID **and** your primary group, and every file named in the ES config must be readable by your UID and primary group alone.

### Observations (no change required by this audit)

- **O-1 (contract):** the AGENTS.md section 12 reading is right (section 8).
- **O-2 (security):** `id` is resolved through `PATH` and its output is not checked to be numeric; `--user :GID` would run as root (observed). Only a caller who controls `PATH` can cause it, and that caller already has Docker. Using bash's `$EUID` plus a numeric check would remove the dependency; optional.
- **O-3 (security):** ES now lives in the operator's same-UID domain: a host process with the operator's UID can signal the ES process and, depending on the kernel's ptrace policy, read its memory, including the retained-result key. The same UID already owns the key file, both roots and Docker access, and `contracts.md:1498-1503` already states that static checks cannot establish isolation against an arbitrary same-UID process. Not a widening.
- **O-4 (doc wording):** `capability_probing.md:160` says "ES's natural-directory probe alone decides". In my runs the refusals came from the key-owner check (ES as root) and from root-capability validation (`operation not permitted`). All are ES startup checks, so the doc's point (the launcher does not decide) holds. "ES's startup checks" would be exact; worth fixing together with A5-2.
- **O-5 (doc placement):** in `contracts.md:1529-1536` the new generic-launcher sentences sit between two profile sentences, so "This profile does not … approve rootless/non-root variants" now follows a sentence about the non-root generic launcher. It reads correctly, but naming "The `service-root-v1` profile" there would remove the ambiguity.
- **O-6 (report delivery):** the writer's reply did not give `04-bringup.md`'s SHA-256 (protocol §3.6 step 2), and the brief had none. I recorded `945b95e1…f8cc` at the start and end of this audit; the file did not change.
- **O-7 (report accuracy):** in `04-bringup.md` section 4, the row "User-namespace remapped: ES refuses" is wrong about the gate (Docker refuses, observed), and "Rootless: probably started" is doubtful (Unknown, see section 8).
- **O-8 (merge gate):** trunk_dev moved to `b8d6bc3` (PR #17 merged 2026-11-22 20:20:05Z) during this audit. It touches no PR #18 path; `git merge-tree` is clean (tree `be39e53e`), and in that trial tree vet, the launcher test and the bring-up test pass (`merged-b8d6bc3-bede334.log`). Updating the branch creates new bytes, so provenance §5.4 applies (new manifest, `git range-diff`). Folding the A5-1 to A5-3 repairs into that update costs one narrow audit instead of two.
- **O-9 (report-only, as asked): ARS, EGS and AGS still run as root in bring-up.** In every run their PID 1 was `Uid 0, Gid 0, Groups 0 1 2 3 4 6 10 11 20 26 27` with an empty `Config.User` (`bringup-*-containers.log`). After a passing head run, ARS left 15 root-owned entries under `ars-storage/sha256/` in the operator's test workspace, which the operator cannot delete without sudo (the same residue the writer hit on the runner, run 45061049559). This is outside PR #18's scope and unchanged by it.
- **O-10 (red-team scope):** whether this ES PR needs a red-team pass is the coordinator's call under the project rule. For that decision: the change only lowers a container's identity and adds tests and docs; it touches no admission, runtime-authority or durable-state code.

## 10. Validation assessment

| Command (all as non-root `ci` 1500:1600 unless noted, `env -i`) | Result |
| --- | --- |
| manifest v2 ×2 at start, ×2 at end | identical, equal to the writer's |
| `go vet ./es/app`, `gofmt -l es/app scripts`, `bash -n scripts/05_start_es.sh` | clean |
| `go test ./es/app -run '^TestESLauncherContainerUser$'` | PASS as 1500:1600 and as 1700:1700 |
| 18 mutants (section 6) | 15 caught, 3 equivalent; 3 survive at UID == GID (A5-1) |
| profile values (section 5) | all refused before any effect |
| `go test ./es/app -run '^TestBringupScriptUpCheckDownFullProfile$'` head | 3 of 3 PASS, plus PASS in the whole-package run |
| same, base script / M05 mutant / base tree | FAIL, each at an ES startup check (section 7) |
| `go test ./es/app` (whole package) head | 157 PASS, 4 FAIL, none caused by PR #18 |
| `go test .` head and base | identical failing sets, docs tests 67/67 PASS |
| userns-remap daemon | Docker refuses host networking (A5-2) |
| trial merge with trunk_dev `b8d6bc3` | vet ok, launcher and bring-up PASS |

**Not run, and why:**

- The real image build of the generated Dockerfile inside bring-up: the container has no egress. I used binaries built offline in the pinned Go image instead. The writer's runner runs (45061834564) cover the real build; I did not rerun them.
- The GitHub runner itself: not rerun by me (writer-reported 3 of 3 there).
- A rootless Docker daemon, Docker Desktop on macOS, cgroup v2 (this container is cgroup v1), Remote Alpha (not affected: ES runs there as the `es.service` systemd unit, which this PR does not touch).
- The A5-3(b) case (a TLS key readable only by root): reasoned, not run.

## 11. Sensitive-material handling

Only synthetic fixtures were involved (fixed 0x53 key bytes, test CAs). No key, certificate body, token or config file was copied into the evidence. The full bring-up service logs stayed in the container; `es-log-excerpts.txt` carries only the `docker run` prefix and the refusal line of each run. The large test logs are delivered as summaries; a pattern scan of them found only test names.

## 12. Confidence

- **Provenance:** 0.99. Manifest reproduced byte for byte at start and end; tip unchanged at 20:36Z.
- **Validation:** 0.9. I reran everything the writer reported except the runner runs, plus mutants, negative controls and a remapped daemon. Lowered by the offline image deviation and cgroup v1.
- **Implementation:** 0.9 for the script change (correct, narrowing, fail-closed). The open items are in the test (A5-1) and the docs (A5-2, A5-3), not in the behaviour.

## 13. Effect status and delivery

- Repair, commit, push, PR comment, review, merge: **not performed**.
- Report delivery: this file, `/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/05-audit.md`, SHA-256 in the thread reply; evidence in `05-audit-evidence/`.

**Final verdict: ACCEPT** (`bede334`; three low findings open: A5-1, A5-2, A5-3).
