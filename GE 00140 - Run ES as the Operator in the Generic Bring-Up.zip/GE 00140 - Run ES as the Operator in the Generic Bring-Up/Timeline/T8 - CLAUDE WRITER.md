Asked the project to choose an option

How should the bring-up script run ES so its test can pass in CI?

1. Run ES as the logged-in user (recommended): Bring-up starts the ES container as the user who runs it (root stays root; rootless Docker unchanged). Small script change, test runs in CI. Shown passing on the runner.
2. Leave the script, skip the test in CI: No script change. The test gets its two test fixes, and CI lists it as a second expected failure. Bring-up stays broken for non-root users on standard Docker.

Why recommended: It fixes a real broken path for the usual Linux setup and keeps the full operator path tested in CI. It passed on the runner.
