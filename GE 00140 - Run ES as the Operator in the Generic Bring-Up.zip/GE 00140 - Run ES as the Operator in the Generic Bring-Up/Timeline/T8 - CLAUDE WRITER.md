Asked the project to choose an option

```json
{"kind":"activity","tool":"ask_decision","text":"Asked the project to choose an option","decision":{"version":1,"question":"How should the bring-up script run ES so its test can pass in CI?","options":[{"label":"Run ES as the logged-in user","consequence":"Bring-up starts the ES container as the user who runs it (root stays root; rootless Docker unchanged). Small script change, test runs in CI. Shown passing on the runner."},{"label":"Leave the script, skip the test in CI","consequence":"No script change. The test gets its two test fixes, and CI lists it as a second expected failure. Bring-up stays broken for non-root users on standard Docker."}],"recommended":0,"reason":"It fixes a real broken path for the usual Linux setup and keeps the full operator path tested in CI. It passed on the runner."}}
```
