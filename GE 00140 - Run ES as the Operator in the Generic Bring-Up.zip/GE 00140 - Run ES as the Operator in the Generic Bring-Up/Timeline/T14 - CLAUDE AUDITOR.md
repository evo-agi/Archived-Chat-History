Audit the bring-up fix
