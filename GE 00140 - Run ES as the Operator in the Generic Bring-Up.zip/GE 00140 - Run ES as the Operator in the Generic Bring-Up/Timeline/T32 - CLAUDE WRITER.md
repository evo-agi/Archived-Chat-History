PR 18 is ready for one last narrow audit. The new head is `d6aded1` and the manifest is `77017ca39f453e2ea9eb477b73518edf2cb957c743c4d98883b0cda32a435786`. This time the upstream is pinned to `origin/trunk_dev`. I took it twice from a fresh clone and both runs match byte for byte. Report: [09-repair-bringup-a7.md](/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/09-repair-bringup-a7.md), SHA-256 `5e8865fa…a78f`.

- **Change:** one docs sentence and one test row, with no script or product change. `implementation.md` now names the right refusal: roots whose group was set directly fail at the staging probe's ownership change. A new "user name with a digit" row covers the UID start anchor.
- **Checks:** as both test users, all 31 of the auditor's mutants are caught, including N28, and so are my 26. The launcher test and docs tests pass.
- **Upstream slip:** report 09 records why the 08 manifest was wrong. `git push -u` had switched the upstream to the topic branch. The auditor's `d3cfd4f4…8dcb` is the correct manifest for `c291503`.

STATUS: WORKING (ARS/EGS/AGS runner rerun and the A6-3 product PR are next)
