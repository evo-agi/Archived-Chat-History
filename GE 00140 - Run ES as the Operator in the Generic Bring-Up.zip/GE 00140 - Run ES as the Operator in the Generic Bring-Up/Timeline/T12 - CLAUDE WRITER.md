The bring-up fix is done and green. It is its own draft [PR #18](https://github.com/evo-agi/Execution-Substrate/pull/18) into trunk_dev, so PR 17 doesn't change because of it. Without a roots profile, ES now runs in its container as the operator's own user ID and group, instead of root.

- **Runner:** the bring-up test passed 3 times out of 3 on GitHub's runner, as the normal runner user and never as root. Each run's ES log shows the operator's ID on the container.
- **New test:** a launcher test runs without Nomad, so CI will run it. It pins the exact Docker command, and all 6 broken versions of the script I tried made it fail.
- **One change from my earlier card:** the card said rootless Docker would stay unchanged. I dropped that special case, because the repo's rules (AGENTS.md section 12) forbid switching behaviour on a Docker daemon's reported mode. On a rootless or remapped daemon, ES now refuses to start at its own check. Neither setup is a documented bring-up setup, but tell me if rootless needs to work.
- **Runbooks:** none in Archived-Runbooks covers bring-up, so nothing to change there. The in-repo bring-up runbook is updated in the PR.
- **PR 17:** audit finding NV3-F1 is fixed (one comment line, new head 962bc89).

Two things are outside this PR: ARS, EGS and AGS still run as root during bring-up, and the probe branches need your go before I delete them.

STATUS: READY (fresh audit of PR #18 next)
