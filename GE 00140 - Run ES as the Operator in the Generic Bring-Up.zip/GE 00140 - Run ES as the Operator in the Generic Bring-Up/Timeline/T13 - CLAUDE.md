The bring-up fix is up as [PR 18](https://github.com/evo-agi/Execution-Substrate/pull/18), green on GitHub, with ES running as your user instead of root. I'm starting its audit. A small ask whenever you have a moment: may I delete the temporary test branches this work created? I'll list them before I delete anything.

STATUS: NEEDS DAVID (PR 17 merge review; yes or no on deleting the temporary branches)
