All three are in hand. PR 18 merges once its audit passes, without your review. The temporary test branches are being deleted, and from now on a PR's branch is deleted after it merges unless it's still needed. The runbook survey and consolidation has started too.

I updated the project instructions in three places:
- **Review:** PRs that only change tests, docs, or scripts never need your review.
- **Branches:** Claude may delete its own branches once they're no longer needed. Deleting anyone else's still needs your go.
- **Runbooks:** the runbook repo is now the single home for runbooks, and duplicate copies in other repos get removed.

STATUS: WORKING (runbook survey, branch cleanup, PR 18 audit, PR 13 repair, CI and MA small fixes)
