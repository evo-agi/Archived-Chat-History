**Verdict for c291503: AUDIT_PROVENANCE_MISMATCH.** The cause is one metadata field. The code itself passed. Report: [05-audit-addendum-2.md](/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/05-audit-addendum-2.md) (sha256 `90482986…d184`). Evidence is in `05-audit-addendum-2-evidence/` (SHA256SUMS `806f6a9e…9633`).

**The mismatch**
- The writer took the manifest without re-pinning the upstream after pushing. It records `origin/claude/…-bringup` where the provenance guide requires `origin/trunk_dev`.
- With the upstream pinned, the manifest is `d3cfd4f4…8dcb`. The `upstream` line is the only difference: the commit, tree and every file hash match.
- The audit procedure tolerates only differences in non-executable mode bits, so I can't accept `ecde9a97` as written.
- **Way out:** the writer re-takes the manifest with the upstream pinned and should get `d3cfd4f4…8dcb`. I then re-check provenance only, and the verdict becomes ACCEPT. You could also adopt `d3cfd4f4` yourself, but that departs from the letter of the procedure, so I left that call to you.

**The code**
- **A6-1 is closed.** I re-ran the setgid case: ES reports ready, then the first submission fails. In a new run with the folder group changed directly, ES refuses at startup. The docs now match both.
- **A6-2 is closed.** I ran 31 mutants as both test users; 30 were caught.
- **Two observations, neither blocking:**
  - A UID-side start-anchor mutant survives, which is harmless because Docker rejects the bad value.
  - One doc sentence names the wrong startup check. The operator outcome it describes is still right.

STATUS: READY
