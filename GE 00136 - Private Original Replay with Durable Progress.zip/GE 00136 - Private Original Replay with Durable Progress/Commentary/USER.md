I just realized after `T2` that I did not upload a new snapshot to project sources for the last tranche. I'll refrain from uploading now, until reliable submission is integrated or until ChatGPT requests it.

I intervened in `Timeline/T9 - USER.md`. :/

`Timeline/T38 - CHATGPT.md` is not the first, but I wonder why ChatGPT started asking Codex to build the snapshot, instead of asking me to upload the snapshot to project sources.

`Timeline/T39 - USER.md` made me question the current workflow. I was under the impression that ChatGPT would still be the designer, and Codex would only be the implementer, but now it looks like ChatGPT and Codex are co-designing... If I'm not making it up, I wonder what caused this shift. Honestly, the lines are being blurred, with ChatGPT being able to spawn next Codex chats, and Codex being able to spawn new Codex chats, we might have to explore new workflows.

`Timeline/T40 - CODEX PROMPT FROM CHATGPT.md` is not executed in this tranche.
