# Execution Substrate — residual M-1 pre-COMMIT recovery and synchronization-owner alignment

Date: 2026-11-19 (America/New_York)
Engagement: bounded parent-only repair, validation and exact source delivery.

## Objective and route

Continue in the SAME foreground Codex conversation that returned the latest
REJECT in Appendix A. All four independent reviewers must be closed before
workspace-write begins. Spawn no writer or audit subagents in this repair turn.
The foreground parent is the sole repository writer. This turn is implementation,
not independent acceptance; a later fresh read-only conversation audits new bytes.

The ONLY source-edit, test and provenance target is:

    /Users/ds/Repositories/ES-Private-Replay-Progress-v1

Use explicit command working directories and absolute edit targets. A conversation
attachment or initial shell elsewhere, including the preserved A1 checkout, is
not itself source drift. It does not authorize edits there. Do not copy the patch,
create another checkout/branch, reset, rebase, fetch, synchronize, or move refs.

Close the two remaining findings against the exact existing thirty-path candidate:
1. M-1 residual: pre-COMMIT rollback uncertainty on an already-closed sql.Conn
   must enter the existing unpublished-opener close-and-nonmigrating-readback
   boundary when its lock-held opening baseline is valid.
2. DOC-SYNC (repair label for Appendix A's second finding): align admission §7.4
   and its permit readers/writers with the already implemented, exact structural
   synchronization inventory. Do not change that implementation or inventory.

Seven previous findings were independently resolved for the current candidate:
M-2, SR-1, SR-2, K1-1, T-1, R2-1 and N-1. Preserve their repairs and evidence.
M-1's original lock-order problem is repaired; only the specifically identified
cleanup/result path remains. The new REJECT supersedes no historical verdict or
run record. Do not repeat the eight-finding implementation campaign.

## 1. Baseline, source scope and opening authentication

Required root: the physical/Git top-level above, with its own .git/common directory.
Branch: codex/private-replay-progress-v1
Upstream: origin/trunk_dev
Origin: git@github.com:evo-agi/Execution-Substrate.git
HEAD: f1aa8b934cc26c16a966a110c7b408abdaeadce7
Sole parent: fb9ae55797d9fcc02863c23fe8d3e43d16eac542
Committed tree: 8dd27f9acba98ed70d93736bdef8300ef1aba53f
Committed subject: Harden original-key read transaction cleanup (A1) (#10)

Opening canonical bytes: exact Appendix B, 6,813 bytes.
Canonical SHA-256: 0812091529c67f4bc46d0bc343b3dea8595e63a461264e143d51606e581e0c06
Tracked full-index diff: 68339ba85b7b22d86bdaa21ed4fdccebc5021f82912344e0507862d1624cb791
Recipe: exact Appendix C, governed-execution.audit-patch-manifest.v2,
7,275 bytes, SHA-256 c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca.

Authenticate appendices and the material source before edits. Run that unchanged
recipe twice from the target checkout, writing to two distinct absent paths under
one NEW private external root. Match Appendix B exactly and independently read
all thirty candidate rows. Verify all 400 other tracked leaves against HEAD,
index == HEAD, 27 unstaged tracked modifications, exactly the three declared
ordinary-untracked additions, no ignored/unmerged/staged/deleted/renamed/type-
changed or extra paths. Total physical source leaves: 430. No Git command that
mutates index/refs or lazily fetches objects is authorized.

The prior pasted repair report's 66-character hash for replay_custody_structure.go
was a transport error, already adjudicated by the latest audit. Appendix B and
the actual archived/live file contain the correct 64-character hash:
4916268757b93d409cbc13ba9c0da14e009499b4db7cadd52bc7ccd47c6a86ad.
Do not regenerate or edit source to match the malformed historical transcript.
That issue is closed unless actual bytes now fail the authenticated target.

Use the material subset of the latest audit root:
/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB
Its artifact-index.json SHA-256 is:
0fd8c79d0b2ac8e20f23aadd92045b03df30528e07331225aa58f124fb0a43bf.
Authenticate the report, diagnostic source/construction/log, selected recovery
records, both old probe bindings, and records actually used. The complete audit
transport is Appendix A. Resolve exact local filenames through the authenticated
index, not guessed names. The migration diagnostic source is SHA-256:
e0b662c8c5d084b209362be82ad54198a7cee85fa1966e9228953bbedad3ba21.
Its raw log is:
28b632fc2d5c1a9cac35586eb0ca7454ff7d9530c22a8c04c12c0a5a728b2375.

Do not require rehashing all 4,901 historical material records or every historical
evidence directory. Never import a verifier in place in a prior evidence root;
copy authenticated source to the new root and disable Python bytecode. Directory
timestamps and unrelated global ref aggregates are not source identity gates.
Record named identity differences; do not change them to satisfy a gate. No
network or remote-ref observation is required for this local repair.

## 2. Governing documents and precise write allowance

Read current AGENTS.md, the opening PLANS.md and relevant owner sections before
editing. This is a Bounded slice rule refinement on the reliable-submit Reopened
redesign seam, within synthetic_progress_nonoperational_v1. It changes no selected
architecture, provider authority, codec, migration version or runtime permission.

Exactly these SIX existing candidate files may receive repair bytes:

1. PLANS.md — narrow current-status entry for this two-finding repair. Preserve
   historical selections and no-effect/nonclaim boundaries; do not claim acceptance.
2. .docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md —
   clarify §15B.5's pre-COMMIT uncertainty/readback routing and result ownership.
   Keep the selected existing rule, not a weaker substitute.
3. .docs/execution_lifecycle/es_execution_admission_model.md — correct §7.4,
   relevant permit entries and direct cross-references. Preserve rejected A3
   topology and private/operational authority distinctions.
4. docs_contract_test.go — bounded executable doc/source consistency checks
   and negative document mutants for the repaired owner inventory, plus any
   precise assertion needed for the migration clarification.
5. es/admission/internal/reliablesubmit/sqlite_store.go — migration/opening-local
   control flow and result routing only; this is the SOLE production behavior file.
6. es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go — maintained
   real-SQLite regression for the residual exit and bounded controls.

All other 24 candidate rows and 400 HEAD-identical files remain byte/mode frozen.
No new repository path is authorized. All three existing new files remain
ordinary-untracked source. The complete candidate remains 27 tracked modifications
and three additions. The six-path list is a ceiling, not a requirement to churn
unnecessary bytes. The owner clarification and admission correction are required.

In sqlite_store.go preserve byte-for-byte the shared discard, BEGIN, COMMIT and
rollback helpers, loadClaim, loadClaimFresh, claim/grant/CAS and A1/O2/C1/D1 paths,
and their existing test-seam declarations. Change only the private opener and
migration-local functions/comments directly required by M-1. No public/exported
API, module pin, new atomic/lock/registry/worker/background retry, new test hook,
whole-store policy for existing published stores, or general error-map change.
Use the already available beforeMigrationCommit and migrationCommit collaborators.
Do not turn sql.ErrConnDone into globally successful cleanup.

Workstream C source and its exact typed/reference inventories remain FROZEN.
No change to schemas, migration 1–4 SQL literals/hashes, authentic schema hashes,
formats, operation encodings, sealed objects, key/grant policy, capability types,
terminal evidence, public structural refusal, unkeyed Submit, or live configuration.
If safe completion genuinely requires another production boundary or path, stop
with the exact dependency and partial results. Do not preemptively broaden scope.

## 3. M-1 residual: close, observe, then classify — never infer from wrapper state

### Observed defect, not an assumed corruption event

The independent diagnostic reached fully verified schema 4 INSIDE the transaction,
then closed its high-level connection wrapper through beforeMigrationCommit and
returned an error BEFORE any COMMIT attempt. Deferred ROLLBACK returned
sql.ErrConnDone; Raw-based discard could not confirm discard. The current code
returned generic unavailable before the opener's checked fresh recovery read.
Both schema-0 and populated-schema-3 cases left the full logical opening state
unchanged and returned no usable handle. The defect is failure to perform and
report the specified recovered-old refusal, not observed data loss or false success.

The previous generation-1 correction handled a DIFFERENT exit: an error returned
from the migrationCommit collaborator AFTER commitAttempted was set. Preserve it.
Do not change a test's injection point to make the two paths appear equivalent.

### Selected control-flow contract

A. A lock-held authenticated opening version/pristine state must already exist
   before migration uncertainty can use this recovery route. Failed BEGIN, invalid
   opening, and ordinary unsupported input cannot acquire recovery authority from
   default fields. Preserve the original M-1 under-lock qualification and M-2.
B. On known-BEGIN pre-COMMIT exits, retain the private request-independent bounded
   ROLLBACK and its post-response context observation BEFORE self-cancel. Successful
   timely rollback retains the ordinary safe refusal; it does not invent uncertainty.
C. If migration has begun and that cleanup is unconfirmed because the exact wrapper
   is already closed, hand control to the owning UNPUBLISHED opener's existing
   pool-disposition and checked nonmigrating classification boundary. This must not
   require the shared Raw helper to reinterpret a closed wrapper as proven discard.
   A migration-local recovery-needed route is acceptable. An existing internal
   dispatch signal may be reused only with explicit local meaning; zero COMMIT
   attempts must remain zero and must not be reported as a lost COMMIT response.
D. Before any fresh classification, finish the original transaction function's
   connection ownership and close the original unpublished pool. Check the close
   result under the existing contract. Do not read from that pool or expose its
   handle. ErrConnDone alone proves neither physical disposal nor rollback, nor
   the opening/current schema; it is not the classifier.
E. Open one fresh checked NONMIGRATING observation under the existing caller-context
   and qualification rules. Authenticate application ID, supported version, full
   schema and ledger or pristine condition against the lock-held baseline:
   - authenticated old/pristine state -> errClaimStoreMigrationRecoveredOld,
     no handle; close the fresh observation pool;
   - authentic complete current state -> only the already selected checked-current
     outcome, without attributing it to an unattempted COMMIT;
   - failed, canceled, invalid, mixed/intermediate or unqualified readback -> fixed
     unavailable and no handle. Do not promote it to recovered old/new.
F. No migration replay, second semantic write, retry loop, schema repair, fallback
   adoption or new object/grant is permitted during recovery. Existing completed-
   COMMIT response-loss recovery and valid competing-head handling remain intact.
G. For failures not shown safely transferred to the closed unpublished-pool boundary,
   retain fail-closed unavailable. Never read back while an undisposed borrowed
   connection can still own the uncertain transaction. Physical-close failure and
   duration remain unqualified; do not claim they have been solved here.

Use the smallest local implementation that enforces these rules. Do not make
ordinary classification depend on a fixture flag or only modify error text. The
checked independent readback, not sql.ErrConnDone or a prior observed version,
must cause the recovered-old result. Keep old helper contracts unchanged.

### Required maintained regression and controls

Add TestSQLiteMigrationPrecommitClosedWrapperRecovery to the existing migration
test file. Preserve the exact audit source as historical evidence. New test inputs
must be bound before they are used for red/green claims.

At minimum test pristine schema 0 and genuinely populated schema 3. Include
historical 1/2 controls using existing fixtures where applicable to the same
opening route. For each decisive case:
- Build a valid baseline with the authentic literal migrations and independent
  full logical witness. Schema 3 includes its real row/key/grant/ledger fixtures;
  retain sealed originals where that fixture has them.
- In beforeMigrationCommit, prove all migration writes and final schema checks
  completed on that exact transaction connection. Close the real sql.Conn wrapper,
  return a modeled pre-COMMIT error, and keep caller context live for readback.
- Count the migrationCommit collaborator and require ZERO calls, not only no
  successful commit. Do not inject through that later collaborator for this case.
- Require nil store plus exact recovered-old category after the opener's own
  disposal/readback. Compare complete logical opening state before/after using
  an independent nonmigrating witness. Observe state BEFORE any new successful
  product opener or test teardown could repair/conceal the behavior.
- Match ordinary rollback controls (same boundary, wrapper kept open): preserve
  their existing generic refusal, logical preservation and zero COMMITs.
- Include canceled/failed recovery refusal controls available through existing
  collaborators; an authentic old state whose observation is unavailable must
  NOT be classified recovered old from metadata alone.
- Retain existing actual-COMMIT/lost-response, interrupted migrationCommit,
  authentic 0–4, competing current head, invalid opening, mixed/intermediate,
  migration-copy and both historical opener regressions.

No race-by-sleep test, process-wide FD-count oracle, physical-close platform, new
source hook or global cleanup sweep is needed. A later separate valid opener may
be tested only AFTER the preservation/classification assertions, and is a new
operation rather than the first invocation silently retrying.

Create one byte-bound differential using the same regression/test assertions on
opening production bytes and repaired production bytes. Opening red must reach
this pre-COMMIT boundary and fail the classification assertion, not setup. Green
must pass. Retain full test and instrumentation bytes, environment, argv, outputs
and command integrity records. Existing seams suffice. If setup is repaired,
version its attempts and preserve failures; do not relabel old runs. Normal
engineering iterations inside this scope are authorized without another turn.

## 4. DOC-SYNC: document the exact existing facts, not broader authority

Read the entire current admission §7.4 and neighboring §7.5, plus the FROZEN:
- workstream_c_guardrails_test.go:TestExecutionSubstrateProductionHasNoA3LeaseRegistryOrPoisonDesign
- workstream_c_guardrails_test.go:TestExecutionSubstrateSynchronizedMutableStateReferenceInventoryIsExact
and the actual corresponding declarations and callers.

The thirty-two structural entries are NOT thirty-two independent locks. In the
current source they comprise five direct lock fields, three atomic Bool fields,
and twenty-four transitively synchronization-bearing reference/request/wrapper
fields. The old five-entry subset was four locks plus one permit wrapper. The
27 additions are one per-custody RWMutex, three invocation-local atomic flags,
and 23 references/request fields. Verify those categories from the actual typed
inventory; do not edit production to fit the prose or remove wrappers from scope.

Correct the present-tense owner section to enumerate the exact same field set
and describe, with a readable table/grouping:
- the three existing service/app/runtime-helper locks and protected facts;
- the operation-local privateSealPermit mutex, one-use latch, wrappers and readers;
- PrivateReplayProgressCustody.mu and closed/issuer validation coordination;
- progressAccessState.used, progressAttemptState.used and
  progressOriginalLifetime.closed, plus the exact reference/request carriers;
- owner, protected fact, reader/writer and lifetime for each primitive/role, with
  exact field identities and explicit mapping of all transitively included fields.

Update scope-1 and scope-2 permit rows using the already frozen per-method reference
inventory: shared publishReplayOriginal, ReserveSealUse, PublishProgressOriginal,
ReserveProgressSealUse, matchesAllocation, consume and burn as appropriate. Do
not leave the obsolete statement that only PublishSealedSynthetic reads the old
wrapper or that only consume reads the latch. References that are not primitive
owners must not be presented as separate authorities.

Make the namespace distinction explicit: these private definitions are part of
non-test production SOURCE under ./es/... and ./cmd/es/..., but runtime-unwired
fixture reachability remains separate. Do not silently narrow the inventory to
public reachable methods to keep an inaccurate five/zero count. SQLite remains
owner of committed claim/progress/key/grant facts. These fields protect handles,
one-use consumption, issuer/lifetime checks; they are not durable run truth,
process-global state, leases, a registry, a poison subsystem or a worker.

Preserve §7.5's rejected A3 topology and all current authority exclusions. Do not
retrospectively rewrite historical five-field records elsewhere as if they had
been wrong when written; qualify only current statements and direct references.

Add TestPrivateReplayProgressSynchronizationInventoryDocsContract in the ROOT
existing docs_contract_test.go. It must compare the documented exact field set
with the frozen finite source inventory (a bounded AST extraction of the named
literal is sufficient), verify category/count consistency and required permit
roles, and keep explicit no-new-authority/nonwiring assertions. Do not add another
general scanner framework or run a new package loader from root tests. The existing
typed guards still validate actual source and will run below.

The doc check must reject the actual opening stale owner description and bounded
mutants for missing an atomic field, an omitted scope-2 wrapper/shared allocator
reader, and misclassifying reference carriers as primitive ownership. Do not make
a mere new date or a phrase-presence assertion stand in for set consistency. Keep
workstream_c_guardrails_test.go and all production synchronization fields byte-frozen.

## 5. Environment, permitted test effects and evidence hygiene

Use pinned local Go 1.26.5 darwin/arm64 with its sibling gofmt. Preflight actual
resolved executable paths and hashes; require known-good Python 3.13.4 with
tomllib, OpenSSL 3.6.2 and the existing Git. Do not install or download tools.
Use cached modules and:

    GOTOOLCHAIN=local
    GOPROXY=off
    GOSUMDB=off
    GOWORK=off
    GOFLAGS=-mod=readonly
    CGO_ENABLED=0
    GOTELEMETRY=off
    GOMODCACHE=/Users/ds/go/pkg/mod
    GIT_OPTIONAL_LOCKS=0
    GIT_NO_LAZY_FETCH=1
    GIT_TERMINAL_PROMPT=0
    PYTHONDONTWRITEBYTECODE=1

Set fresh task-owned GOCACHE, GOTMPDIR and TMPDIR OUTSIDE the checkout. Evidence
root mode 0700; retained non-source evidence 0600; preserve declared copied-source
modes, and use Go-test umask 027 inside outer umask 077. Existing tests may create
test-owned files under /tmp or /private/tmp and a disposable Git fixture, use
loopback mocks and bounded helper processes, and perform read-only Docker
capability probes. This does not authorize starting Docker or a live stack,
operational migrations, real keys, host operations, provider effects, network
Git, or broad deletion. Track only task-owned effects; never clean shared caches,
other checkouts, prior evidence, or arbitrary temp roots. Report cleanup limits.

Authenticate and COPY the two distinct old opener binaries without rebuilding:
- PB1/schema-2: 14,350,930 bytes,
  b205a31bac091cbcf5b3f4826bc359455625316908051131733622813e34adcf;
- previous-schema-3: 15,601,186 bytes,
  42614a50812a65ba52b53488d872884e59ce7b4f57dece6a66642d4eb8de1409.
Bind ES_REPLAY_PB1_PROBE and ES_REPLAY_SCHEMA3_PROBE to those task-owned copies.
Their tests supply their separate child target variables; a direct child launch
must bind its correct target explicitly. Preserve their different historical
source/witness purposes. No old binary can be built from the evolving candidate.

Build the final N1_SOURCE from all 430 FINAL frozen candidate leaves plus EXACT
Appendix D/E files at their declared package paths. Bridge and witness remain
external only. Reuse no stale pre-repair source view. Bind all 432 inputs and
actual compiled/generated inputs, recording any reproducibility limitations;
retain generated evidence inputs before cache cleanup. Existing construction
records can guide setup but cannot substitute for new source bindings. This
replays the already accepted witness structure on the new bytes, not a new
cross-process revocation or terminal-evidence campaign.

## 6. Frozen integrated validation — eleven serial commands

After normal development and targeted red/green checks, freeze the final candidate,
external N1 source, environment and exact argv. Run each final command serially,
once for that declared generation. A substantive failure invalidates that final
sequence; correct only within scope, retain the failed run, refreeze and rerun the
complete final sequence. Do not rerun selectively until a previously failing
unchanged assertion happens to pass, remove coverage, or invent a new skip.

The following is the exact command plan. Commands 1–10 use the target checkout;
command 11 uses the newly bound task-owned N1_SOURCE. Environment setup and any
build-input inspection commands must be recorded separately.

```sh
GO=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go
GOFMT=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/gofmt
I=es/admission/internal/reliablesubmit
A=es/admission
# Set N1_SOURCE to the new private external 432-file final view, not prior evidence.

"$GO" version
"$GOFMT" -d docs_contract_test.go "$I/sqlite_store.go" "$I/sqlite_replay_claim.go" \
  "$I/sqlite_migrations.go" "$I/sqlite_replay_progress_schema.go" "$I/sqlite_replay_shape.go" \
  "$I/durable_record.go" "$I/durable_operation.go" "$I/durable_service.go" \
  "$I/replay_custody_format.go" "$I/replay_custody_structure.go" "$I/replay_custody_file.go" \
  "$A/reliable_submit_replay_format.go" "$A/reliable_submit_replay_hydration.go" \
  "$A/reliable_submit_replay_private.go" "$I/sqlite_pooled_claim_read_cleanup_test.go" \
  "$I/replay_progress_test.go" "$I/replay_custody_file_test.go" "$I/sqlite_store_test.go" \
  "$I/sqlite_physical_test.go" "$I/sqlite_replay_migration_test.go" \
  "$I/sqlite_replay_shape_test.go" "$I/guardrails_test.go" "$A/reliable_submit_guardrails_test.go" \
  "$A/reliable_submit_replay_private_test.go" "$A/workstream_c_guardrails_test.go"
git --no-pager diff --check
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateReplayProgressSynchronizationInventoryDocsContract|TestPrivateOriginalReplayProgressContractSelection|TestReliableSubmitPersistenceAndConcurrencyADRDocsContract|TestSubmitIdempotencyCorrelationAndRecoveryDocsContract|TestReliableSubmitPureModelDocsAndSourceContract|TestReliableSubmitPublicOptInAndVersioningDocsContract|TestReliableSubmitContractAdapterFoundationDocsAndSourceContract|TestReliableSubmitBindingProducerDocsContract|TestIntegratedAcceptanceGateDocumentationIsConsistent|TestIntegratedCandidateStatusSeparatesCAndT)$' .
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestSQLitePooledClaimReadCleanup$' ./es/admission/internal/reliablesubmit
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestSQLiteMigrationPrecommitClosedWrapperRecovery|TestPrivateReplayProgressConfirmationEligibility|TestPrivateReplayProgressReconciliationEligibility|TestPrivateReplayProgressTerminalEvidenceBinding|TestSQLiteMigrationOpeningRevalidatedUnderLock|TestSQLiteLiteralInternalNamespaceQualification|TestPrivateReplayScope1PublicationPreflight|TestPrivateReplaySharedObjectAllocation|TestReplayPublicationFaultAndIdentity|TestPrivateReplayProgressFormatVectors|TestPrivateReplayProgressTransitions|TestPrivateReplayProgressConcurrencyAndCommitOutcome|TestSQLiteV4MigrationPreservesFullState|TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation|TestSQLiteV3OldBinaryRefusesWithoutMutation|TestSQLiteLegacyCASConnectionCleanup|TestReplayOriginalKeyReadCleanup|TestReplayOriginalKeyReadCallerRefusal|TestReplayGrantC1PreCommitConnectionQuarantine|TestReplayGrantD1BeginResponseLossQuarantine|TestReplayKeyStateD1BeginResponseLossQuarantine|TestReliableSubmitPrivatePersistenceStaticGuardrails)$' ./es/admission/internal/reliablesubmit
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestExecutionSubstrateProductionHasNoA3LeaseRegistryOrPoisonDesign|TestExecutionSubstrateSynchronizedMutableStateReferenceInventoryIsExact|TestPrivateReplayProgressOccupiedDisposition|TestPrivateReplayProgressAdmissionReplay|TestPrivateReplayProgressHasNoEffectPaths|TestReliableSubmitFoundationHasNoRuntimeWiring|TestReliableSubmitBindingProducerHasNoProductionCaller|TestPrepareRequestShapeRemainsLegacyAndUnkeyed|TestResolvedSubmitLegacyEquivalenceOneNomadRegistrationAndAuthorityRecovery)$' ./es/admission
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestWorkstreamCContractPrepareAndSubmitRemainSeparatedAtAPIBoundary|TestSubmitPublicRouteRejectsStructuralReliableBody)$' ./es/api ./es/app
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=600s ./es/admission/internal/reliablesubmit ./es/admission ./es/api ./es/app
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=600s ./...
(cd "$N1_SOURCE" && "$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestPrivateReplayProgressAdmissionUnknownNoEffects$' ./es/admission)
```

Immediately after EVERY validation/diagnostic command, freshly observe all 430
candidate files (complete bytes/modes), HEAD, branch, upstream, index, tracked path
set and BOTH ordinary-untracked and ignored inventories. Index must equal HEAD,
not the working candidate. Exactly the three declared source additions are
expected ordinary-untracked files; do not demand an empty inventory or stage them.
The 24 frozen candidate rows and 400 other tracked leaves remain opening-identical.
The external witness requires its separate 432-file before/after source guard.
Associate each actual guard execution with its command; matching deterministic
hashes alone are not proof that a fresh observation ran.

Use at least these two explicit inventory queries with checked exit codes:
    git ls-files --others --exclude-standard -z
    git ls-files --others --ignored --exclude-standard -z

The prior independent baseline is 5,174 full-tree passing test identities, zero
failures, 39 skips, 21 test-bearing packages and 20 no-test packages. New tests
will change pass counts; enumerate all additions/removals/renames, and require
all intended selectors to reach their parents. Expected skip identities remain
the two helper sentinels and 37 capability-dependent App cases. Classify actual
skip reasons rather than hiding changed conditions or forcing their wording.
No new repair case may skip. The allocator parent must again prove child execution.
N1 has five separate identities, not part of the ordinary full-suite count.

## 7. Closeout, delivery and stop conditions

After task-owned scratch cleanup, execute the unchanged v2 recipe twice to fresh
external absent files. Require byte-identical canonical manifests. Generate a
source map comparing the rejected opening with the repaired target and HEAD.
At most six rows can change from Appendix B, and the complete path set remains 30.
Check complete function preservation for loadClaimFresh and the other frozen
sqlite_store.go boundaries, not merely that their containing file is permitted.

Deliver a private review ZIP with all 30 complete source files, both exact
manifests, tracked HEAD patch, opening-to-repaired patch including additions,
source map, safe README and a self-excluding inventory. Include the exact new
maintained regression bytes and external N1 bridge/witness/construction identities;
no real key material, live databases, credentials, binaries, module caches, Git
administration, pyc or OS metadata. Verify unique safe regular names, bytes, modes,
sizes, both patch reconstructions in task-owned copies and the final archive hash.
The source archive must not conceal omitted untracked files behind tracked diff.
All retained evidence is evidence only, not new execution authority.

Return the COMPLETE decision-relevant human-readable report INLINE. A duplicate
file may supplement it; it cannot replace findings, results, qualifications,
command lists, skipped work, remaining seams or effect status. State:
- exact baseline and new canonical manifest JSON/digest, diff and recipe identity;
- touched paths and frozen rows/functions; opening/closeout source/index identity;
- M-1 pre-COMMIT trace, actual error category, counts and full preservation witness;
- exact documentation/typed inventory reconciliation and negative checks;
- red/green source construction and any setup/modeling limitations;
- all executed commands/results, final generation and preserved earlier failures;
- full test identity and skip reconciliation, both probe identities, N1 outcome;
- remaining physical-close/native/operational qualifications and cleanup limits;
- exact review ZIP path, byte length, SHA-256 and duplicate report/index identities.

Do not call this independent acceptance or mark the other audit's REJECT erased.
Use the sole successful progression marker only when the required work completes:

    ES_PRIVATE_REPLAY_PROGRESS_M1_PRECOMMIT_AND_OWNER_INVENTORY_REPAIR_READY_FOR_FRESH_INDEPENDENT_AUDIT

Otherwise use one honest bounded BLOCKED status with the actual achieved state and
reason. Stop on source/provenance mismatch, unsafe disposal/readback ordering,
unresolved owner semantics, out-of-scope edit need, failed final validation or
unexplained change to frozen material. Preserve partial work without staging or
rewriting the baseline. Do not demand a separate turn for ordinary in-scope test
fixture development; retain and classify its attempts.

No staging, commit, push, PR mutation, remote effect, checkout synchronization,
operational migration, native qualification or runtime wiring. Public reliable
Submit remains unavailable; the cross-restart operational write-uncertainty gate
remains unimplemented. A fresh read-only audit of new exact bytes follows delivery.

## Appendix transport

The payload begins immediately after its BEGIN delimiter newline. Read exactly
the declared byte count; preserve whether the original ends with a newline. One
additional framing newline precedes the END delimiter and is NOT payload.
Authenticate the declared length/hash; do not reserialize Appendix B.
Appendix A is the latest complete audit, not a paraphrase. Appendix B is the correct
archived manifest, not the malformed older pasted field. Appendix D/E remain
external diagnostic inputs only. Inspect executable inputs before using them.

## Appendix A — Complete latest independent REJECT report

Bytes: 32838
SHA-256: 2f26df84e9376b24d9bf29a2a25ae729a8fa270f7c8450a5dcb6ed684e570c1b

<!-- BEGIN APPENDIX A -->
# REJECT

The exact thirty-path candidate is ineligible for a later local commit gate. All eleven prescribed commands passed, including the fresh admission response-loss witness. Two findings still prevent acceptance.

1. **M-1 remains incomplete at the pre-COMMIT rollback boundary.** After migration writes and final schema checks, an already-closed connection wrapper makes both `ROLLBACK` and `Raw` return `sql.ErrConnDone`. The opener takes its generic unavailable exit and skips the checked nonmigrating read required by ADR §15B.5. The independent diagnostic reproduced this on pristine schema 0 and populated schema 3. Both cases reached verified schema 4 inside the transaction, attempted zero COMMITs, returned no handle, and preserved the complete logical opening state. The opener returned generic unavailable in both cases. The required result for an authenticated old-state readback is recovered-old refusal. The two ordinary rollback controls passed. [Rollback branch](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_store.go:676) · [Opener recovery branch](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_store.go:96) · [Owner rule](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1712) · [Diagnostic log](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/migration-diagnostic/stdout)
2. **Admission §7.4 contradicts the candidate’s exact synchronization inventory.** The owner document says production ES and `cmd/es` have five synchronization-bearing fields and zero atomic fields. The typed inventory covers those same trees and records 32 entries. The 27 additions are one per-custody `RWMutex`, three invocation-local atomic flags, and 23 references or request fields. The owner’s permit table also omits the scope-2 wrapper and shared allocator readers. This is unintended documentation drift in the private **Bounded slice rule** on the reliable-submit **Reopened redesign seam**. The implementation keeps these fields within the selected fixture boundary. The owner table’s present-tense, production-wide wording makes the discrepancy material to this exact candidate. [Admission §7.4](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/es_execution_admission_model.md:910) · [Typed field inventory](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/workstream_c_guardrails_test.go:2280) · [Permit inventory](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/workstream_c_guardrails_test.go:2463)

## Target and provenance

I used this fresh, target-bound chat for the independent audit. The physical root was `/Users/ds/Repositories/ES-Private-Replay-Progress-v1`, with `.git` as both the Git and common directory. Branch `codex/private-replay-progress-v1` tracked `origin/trunk_dev`, with origin `git@github.com:evo-agi/Execution-Substrate.git`. Both scoped refs pointed to `f1aa8b934cc26c16a966a110c7b408abdaeadce7` throughout. Its sole parent was `fb9ae55797d9fcc02863c23fe8d3e43d16eac542`, its tree was `8dd27f9acba98ed70d93736bdef8300ef1aba53f`, and its subject was `Harden original-key read transaction cleanup (A1) (#10)`.

The 427-entry index matched HEAD. All 430 physical leaves were independently read and checked for bytes and modes. The result was 400 HEAD-identical leaves, 27 unstaged modifications and exactly the three authorized ordinary-untracked files. All 30 candidate files were regular `0644`. The staged, unmerged and ignored inventories were empty, with no deleted, renamed, type-changed or extra paths. The raw index SHA-256 was `1c6218366e333383b205833fce0ceaa5d462fa7264cf51cbdcd35aa05855b018` and the raw local Git config SHA-256 was `4c98ee1729d2d3321c357ec922f6dafc19b6ac167a8a24ed636d359ab6642485`. Both also matched the retained author opening values. I observed no scoped ref difference. The separately disclosed historical all-ref aggregate difference did not affect the named identities. [Opening guard](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/opening-guard.json)

| Provenance item | Verified SHA-256 |
|---|---|
| Canonical Appendix B, 6,813 bytes | `0812091529c67f4bc46d0bc343b3dea8595e63a461264e143d51606e581e0c06` |
| Full-index tracked HEAD diff | `68339ba85b7b22d86bdaa21ed4fdccebc5021f82912344e0507862d1624cb791` |
| Appendix C recipe, 7,275 bytes | `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` |
| Repaired ZIP, 900,863 bytes and 44 regular entries | `e3cac3bc27bbfd8c1c18d1abf3aabc00077e632e14bd6e6b92e26e020c9c1be6` |
| Rejected ZIP, 718,150 bytes | `bc4bc721f7aa0f02da9f2427625973e883a82fdc0988e4f587c2140792245cf3` |
| Rejected canonical manifest | `110cef71ba25f61b70297b37cc5a50a68732d639845e0ac4315d06cedcdbc1e3` |
| Rejected tracked diff | `e45e3bd85391191702673b2d40fc2d06d865503004e09a8094c2f6a7081fe0c4` |
| Rejected-to-repaired patch | `cd1ddb5b23d124c931c449e7a09bd81e3d6e5307d105d3d19eeca179a5a068c5` |
| Repaired source map | `fa58e64ecf8c2872bd8ff29357fa2266108e98df272344a349b061f39f784d23` |
| Repaired delivery inventory | `c2a2b842265eace578bfe61a5944b1c91826194f17129ea691bd88a6dde419a1` |

I checked all source-map rows against both archives, the live files, and the pinned HEAD blobs where applicable. The set was exactly 17 repaired and 13 unchanged rows across the same 30 paths. I reviewed the integrated slice against HEAD as well as the repair delta. The four executions of the authenticated recipe, two opening and two closing, produced exact Appendix B bytes in absent external outputs. [Row comparison](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/repair-delta-rows.json) · [Closing manifest](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/closing-b.json)

**Appendix A adjudication.** Its original bytes were preserved. Its inline JSON canonicalized to 6,815 bytes with SHA-256 `adc82e9b55e088a33b66e72c75cadda4835f81e82c94cdac8abb1856bc33f7b8`. The sole discrepancy was the disclosed 66-character hash for `replay_custody_structure.go`. Both archives and the live 18,640-byte file gave `4916268757b93d409cbc13ba9c0da14e009499b4db7cadd52bc7ccd47c6a86ad`. An in-memory field comparison reconciled every other field to Appendix B. The live source independently reproduced Appendix B. [Preserved transport](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/appendix-A)

## Eight finding dispositions

| Finding | Independent disposition |
|---|---|
| **M-1** | **Incomplete.** The original lock-order defect is repaired. The maintained clock witness committed a second writer after preflight and before `BEGIN IMMEDIATE`. Lock-held application ID, version, ledger and shape or pristine verification govern migration writes and set the recovery baseline. Invalid app, ledger, schema, future version and nonempty bootstrap refused. The valid competing head opened with cleanup and zero migration writes. Authentic openings 0–4 and the maintained lost-response controls passed. The separate already-closed pre-COMMIT branch failed the fresh diagnostic described above. |
| **M-2** | **Resolved.** Both pristine and schema-digest qualification use a literal seven-character `sqlite_` check with SQLite ASCII `NOCASE`. The digest encoding and authentic constants are preserved. The pinned SQLite source reserves that literal prefix. The fresh tests refused the collision table, mixed-case index and mixed-case view, using unfiltered schema and full logical-state witnesses independent of the filter. |
| **SR-1** | **Resolved for the selected lifetime contract.** The confirmation path checks the borrow after acquiring the issuer lock, matches the original descriptor’s key IDs and fingerprints, checks the retained active-or-retired binding and envelope keys together, then checks qualification and lifetime again before projection. Fresh tests covered both pre-entry revocations, active and retired controls, known and recoverable-unknown establishment, ordinary-current reads, and callback return or cancellation after initial consumption while blocked on the issuer lock. Refusal preserved `Committed` or `WriteUnknown` and withheld projection. The source trace also checked closed, copied and foreign access, and the separate eligibility of the known committed snapshot after advancement of the same original. |
| **SR-2** | **Resolved.** Every fresh codec-4 reconciliation checks the current recording predicate before reaching a same-fact no-op. Historical tuple validation stays separate and preserves the recorded tuple through later provider and terminal activity. Legitimate exact latest replay, changed-input conflict and stale classification retain their order. Fresh tests covered pending, ambiguous and inconsistent after incompatible provider activity and both terminals, plus eligible no-ops, no-marker, terminal corroboration and negative reconciliation without a provider. The legacy branch retains its predicates. |
| **K1-1** | **Resolved.** Once establishment proves a definite loser, failed winner disclosure preserves `Occupied` and zero projection. The deterministic test covered disjoint catalogs, an unavailable winner object, equivalent winner projection and proved changed-intent conflict, with one winning row and no repeat admission attempt. I source-traced later cancellation, key selection and authentication failures to the same local branch. Generic lookup refusal and write uncertainty retain separate outcomes. The branch performs no second resolution, Seal or semantic write. |
| **T-1** | **Resolved.** The redacted synthetic assertion carries private claim, run, marker, fact, outcome and receipt fields. Acceptance binds the independently constructed exact receipt. Negative evidence carries no receipt and binds its fact. Evidence validation precedes relying on replay or no-op. Candidate-phase checks follow legitimate exact replay. Fresh tests covered receipt substitution, opposite polarity, zero and malformed values, wrong attempt and negative fact, terminal restart replay, receipt immutability and opposite-terminal refusal. The accepted constructor has four test calls and the negative constructor has two, with zero production calls. |
| **R2-1** | **Resolved for both selected publisher paths.** Scope 1 qualifies scope, custody and parents, frozen input and permit presence before arranging burn. The maintained test proved that an ineligible preflight preserves eligible first use by the issuer, while a qualified foreign issuer or allocation collision burns the permit. Scope 2 retains wrapper burn. Both paths use the same checked count-and-create allocator, with confirmed rollback and identity recheck before FD transfer, one discard rescue, withholding after two uncertain responses, and charged reservations and counted orphans on refusal. |
| **N-1** | **Resolved by fresh admission-level execution.** The exact external bridge and witness ran against an independently copied and guarded 432-file view. All five identities passed. The four case results and build bindings are below. |

The four independent read-only reviews completed. The SQLite reviewer identified the residual pre-COMMIT branch and verified the historical cleanup and migration paths. The custody reviewer verified SR-1/R2-1 and identified the owner-table drift. The durable/admission reviewer verified SR-2/K1-1/T-1, including the exact replay/CAS ordering and the rejected terminal adapter. The evidence/effect reviewer independently confirmed the owner-table drift, both old-probe bindings, generation and skip reconciliation, and the fixture caller exclusions. I checked both material findings against the owner text and candidate source and ran the separate migration diagnostic. The reviews had no material dissent. Each reviewer’s dynamic conclusions were limited to inspected retained evidence. The foreground ran the fresh validation.

## Integrated slice and historical evidence

- The finite `(codec, scope, format)` dispatch preserves historical codec 1/2 and immutable codec 3. Codec 4 retains global caller/key occupancy, one original and physical row ID, one attempt and one assigned run. The durable service owns semantic successors. SQLite enforces physical shape and CAS. The original stays sealed with scope-separated AEAD and commitments, exact retained key purposes and fingerprints, strict typed decoding and parser budgets. Progress and receipts live in SQLite under the fixture model. Current replay and exact latest replay leave earlier invocation dispositions intact. The operational §8 predicate and cross-restart write-uncertainty authority remain outside the implemented facade.
- Migration 4’s copy proof preserves rowid plus all 46 named columns, typed contents, registry and grant rows, and prior ledger rows. Fresh logical preservation checks passed across the selected known-COMMIT, rollback and lost-response cases. The sealed originals are outside the schema rewrite. This evidence qualifies logical preservation. Physical database and sidecar byte equality, physical-close success and duration, capacity under actual double withholding, and real-time enforcement of the 16 MiB detection budget remain unqualified.
- The distinct retained schema-2 PB1 and previous-schema-3 probe copies ran under their respective focused parents. PB1 was 14,350,930 bytes with SHA-256 `b205a31bac091cbcf5b3f4826bc359455625316908051131733622813e34adcf`, bound to its original build, harness and 404 historical source leaves. The other probe was 15,601,186 bytes with SHA-256 `42614a50812a65ba52b53488d872884e59ce7b4f57dece6a66642d4eb8de1409`. Its 427 exported leaves matched pinned HEAD, its test overlay had one entry, and all 1,354 compiled inputs matched, including the retained copy of one generated input. That inventory SHA-256 was `50a81fa5a042e135abfc9f6bad68d20abc4575f881945ecc84252c14910dde8f`. The probes exercised schema-2 refusal of schema 3 and schema-3 refusal of schema 4, respectively. Each supplies its own historical refusal evidence. [Probe bindings](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/probe-material.json)
- `loadClaimFresh`, including its final blank separator, was exactly 1,077 bytes at HEAD, in the rejected archive and in the candidate, with SHA-256 `3a47f8b5e0c5bf7bec899987aa78fdf4ef48a585086d9eb975e576896ab4b61c`. The retained pooled-reader differential used the same regression bytes. It recorded two passes and 14 failures on the pinned reader with test instrumentation and 16 passes on the repaired reader. Fresh gate 5 reproduced the 16 passes, including same-store fresh-context reads and CAS where disposal or transaction end was confirmed. I reviewed preserved A1/O2/C1/D1 paths and the pinned Go discard behavior. `Raw` with `driver.ErrBadConn` excludes the connection from the pool. The driver close result can be discarded inside `database/sql`, and the double-withholding control models responses.
- The typed caller inventory and source trace kept the scope-2 facade in the private admission composer. I found no startup, configuration, App/API, script or example caller. The finite selector mutants supplement the typed inventory and call trace. Fresh boundary tests preserved public structural reliable-request refusal and unkeyed Submit. Coordinator authority remained separate. Fixture facts and receipts confer no provider acceptance evidence.

| Version | Migration SQL literal SHA-256 | Authentic schema shape SHA-256 |
|---|---|---|
| 1 | `9613ba74cd6573626277b1f04a20b9c3ec5f9edf8b6b7408e94cbb45edc32dcd` | `031abaada34a63834d3466081ed04afef6b7c9f55103cd2b57fe3033b8c45ef0` |
| 2 | `9280a62450488dfa54907d268d693f3f7d4f0b78b9a3553a1b659206d2c970e9` | `944094f4e5fae102ea2882a076f580c69494678f41acedf9eaa971fe836eb280` |
| 3 | `4dafddbf477fd7f64ad88cf2b1e2b2becb378827e81cd6cc694456798c9a00be` | `15ab48bde4d53bb252dc954a2aa3b1db12de7295111f23bb0264f74f153dba92` |
| 4 | `879b24ac563d37ccdd1bdb5ec13c923b93213f2caea69a1110281796e20e667e` | `2ae4721c8526ed9b8de35fd3acdfa31448eae9b547ba8662a22ed130035f7c15` |

Migrations 1–3 matched HEAD, and the migration 4 literal matched both packets. The operation and record encodings, Workstream C source and pooled regression were among the byte-identical repair rows. [Format evidence](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/format-material.json)

### Retained differential and generation results

The prior independent SR diagnostic authenticated at 10 passes and 13 failures on the rejected target. The four primary repair differentials authenticated against their frozen inputs, immediate guards and raw logs.

| Retained differential | Red pass/fail | Green pass/fail |
|---|---:|---:|
| Migration opening and namespace | 8/9 | 41/0 |
| Confirmation lifetime and permit preflight | 13/9 | 66/0 |
| Reconciliation and terminal evidence | 14/19 | 77/0 |
| Occupied disclosure | 2/3 | 22/0 |

The primary reds reached behavioral assertions. The superseded migration BLOB-ledger setup error was corrected to invalid TEXT. The superseded custody red was repeated on the exact rejected production inputs. The terminal adapter supplies only the rejected assertion’s common claim/run/marker/fact fields. Receipt substitution and representable polarity substitutions provide causal red controls. The malformed discriminator and receipt cases on green exercise fields that did not exist in the old interface. The broader green selectors were reconciled by matched assertions and actual inputs. No full historical compile ledger was inferred.

Generation 1 passed gates 1–8 and failed gate 9 with 2,043 passes, 39 skips and six failing identities. The failing leaves were `TestSQLiteV4BootstrapCommitUnknownReopenZeroOrFour/interrupted_before_commit`, `TestSQLiteV4UpgradeFromOneCommitUnknownNoIntermediate/false` and `TestSQLiteV4UpgradeFromTwoCommitUnknownOldOrNew/false`, plus their three parents. Gates 10 and 11 were unrun in generation 1. The retained recovery rerun passed 42 identities. All six identities passed in retained generation 2 and in fresh gate 9. Those interruptions originate in the migration COMMIT collaborator. The new diagnostic exercises the earlier `beforeMigrationCommit` collaborator and the rollback-uncertainty branch. Its exit 1 comprised two passing controls, two failing classification leaves and their failing parent. The setup reached the intended boundary in all four cases, and I ran it once. [Authenticated historical identities](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/history-identities.json) · [New diagnostic result](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/migration-diagnostic/result.json)

## Fresh N-1 witness

The audit-owned view contained all 430 actual candidate leaves plus the exact Appendix F bridge and Appendix G witness. Their SHA-256 values were `14f0e9e92a37e1d1bf624f1f052a62a6d56e5b82f988698abbf6e1b5bcf9196d` and `8da31dd61c9af2537c15f4376a330d05cb2e55dd2efd0ea610472a0c6ffa5c6a`. Both were absent from the source checkout and ordinary suite. The 432-file before/after guard matched `4d99551a4b41a89884b6a0edb221628eb2abc1cfe4bd8524cb2937377b5f1320`.

The bridge attached and restored only the selected store hook. Every case performed one real COMMIT and then modeled a lost response. Recovery ran through existing production disposition and projection code. The hook was restored before the later read.

| Case | Invocation result | Projection revision | Later current revision |
|---|---|---:|---:|
| Establish / Canceled | `WriteUnknown` | 0 | 1 |
| Establish / AuthenticatedExact | `OwnCommitConfirmed` | 1 | 1 |
| AssignRun / Canceled | `WriteUnknown` | 0 | 2 |
| AssignRun / AuthenticatedExact | `OwnCommitConfirmed` | 2 | 2 |

Each case checked the earlier disposition, fixture-only references, one sealed object, zero provider/staging/EGS contacts and empty operational roots. `AssignRun` preserved the original object bytes. The raw witness SHA-256 was `39020d0d23630d74e87e698f4b91aab975586f6ce18503d89f19b3d084602d29`. [Fresh N-1 raw log](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/gate-11/stdout)

The packet’s view-command and build-input records matched `942000138cc35778e4eb175d9be01737fe6f95af790f84233335fc3e2fa7340a` and `a84ab3946242c1b026ef6d8d14af09776aaf0be6d501d25abbc9d39b7296913c`. The fresh package graph matched all 291 retained package records after path normalization. All 2,801 physical input digests matched, including the formerly absent 57,754-byte generated test-main input, reproduced by this audit and preserved before cache cleanup. The fresh graph SHA-256 was `00d65eddf204471a5e2482e944d71cae79aa66133bc5b39c03cc0200f417762e`. [Input reconciliation](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/n1-resolved-inputs.json)

## Fresh command record

Commands 1–10 ran from `/Users/ds/Repositories/ES-Private-Replay-Progress-v1`. Command 11 ran from `N1_SOURCE` below. Go was `go1.26.5 darwin/arm64`, with sibling `gofmt`, Python 3.13.4 with `tomllib`, OpenSSL 3.6.2 and Git 2.49.0. The runner used the declared offline Go settings, Git optional locks and lazy fetch disabled, Python bytecode disabled, audit-owned cache/temp directories, outer umask `077` and test umask `027`. [Executable paths, versions and hashes](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/preflight.json) · [Recorded environment](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/validation-environment.json)

| Gate | Exit | Test pass/fail/skip | Package result |
|---|---:|---:|---|
| 1 Go version | 0 | — | Go 1.26.5, Darwin arm64 |
| 2 `gofmt -d` | 0 | — | Empty output |
| 3 Diff check | 0 | — | Empty output |
| 4 Owner contracts | 0 | 22/0/0 | 1 tested |
| 5 Pooled reader | 0 | 16/0/0 | 1 tested |
| 6 Internal focused and old probes | 0 | 208/0/0 | 1 tested |
| 7 Admission focused | 0 | 24/0/0 | 1 tested |
| 8 API/App boundaries | 0 | 2/0/0 | 2 tested |
| 9 Four-package suite | 0 | 2,049/0/39 | 4 tested |
| 10 Full repository | 0 | 5,174/0/39 | 21 tested, 20 with no tests |
| 11 External N-1 | 0 | 5/0/0 | 1 tested |

All 11 primary commands ran serially and once. Fresh pass/fail/skip identities matched retained generation 2 at every gate. Gate 9 was exactly the four-package projection of gate 10. The full run added 72 internal and six admission pass identities over the rejected 5,096, with zero removals. N-1’s five identities were disjoint. [Exact identities, packages and per-command hashes](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/fresh-reconciliation.json)

```sh
GO=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go
GOFMT=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/gofmt
N1_SOURCE=/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/n1-source
M_SOURCE=/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/migration-source
I=es/admission/internal/reliablesubmit
A=es/admission

"$GO" version
"$GOFMT" -d docs_contract_test.go "$I/sqlite_store.go" "$I/sqlite_replay_claim.go" \
  "$I/sqlite_migrations.go" "$I/sqlite_replay_progress_schema.go" "$I/sqlite_replay_shape.go" \
  "$I/durable_record.go" "$I/durable_operation.go" "$I/durable_service.go" \
  "$I/replay_custody_format.go" "$I/replay_custody_structure.go" "$I/replay_custody_file.go" \
  "$A/reliable_submit_replay_format.go" "$A/reliable_submit_replay_hydration.go" \
  "$A/reliable_submit_replay_private.go" "$I/sqlite_pooled_claim_read_cleanup_test.go" \
  "$I/replay_progress_test.go" "$I/replay_custody_file_test.go" "$I/sqlite_store_test.go" \
  "$I/sqlite_physical_test.go" "$I/sqlite_replay_migration_test.go" \
  "$I/sqlite_replay_shape_test.go" "$I/guardrails_test.go" "$A/reliable_submit_guardrails_test.go" \
  "$A/reliable_submit_replay_private_test.go" "$A/workstream_c_guardrails_test.go"
git --no-pager diff --check
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateOriginalReplayProgressContractSelection|TestReliableSubmitPersistenceAndConcurrencyADRDocsContract|TestSubmitIdempotencyCorrelationAndRecoveryDocsContract|TestReliableSubmitPureModelDocsAndSourceContract|TestReliableSubmitPublicOptInAndVersioningDocsContract|TestReliableSubmitContractAdapterFoundationDocsAndSourceContract|TestReliableSubmitBindingProducerDocsContract|TestIntegratedAcceptanceGateDocumentationIsConsistent|TestIntegratedCandidateStatusSeparatesCAndT)$' .
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestSQLitePooledClaimReadCleanup$' ./es/admission/internal/reliablesubmit
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateReplayProgressConfirmationEligibility|TestPrivateReplayProgressReconciliationEligibility|TestPrivateReplayProgressTerminalEvidenceBinding|TestSQLiteMigrationOpeningRevalidatedUnderLock|TestSQLiteLiteralInternalNamespaceQualification|TestPrivateReplayScope1PublicationPreflight|TestPrivateReplaySharedObjectAllocation|TestReplayPublicationFaultAndIdentity|TestPrivateReplayProgressFormatVectors|TestPrivateReplayProgressTransitions|TestPrivateReplayProgressConcurrencyAndCommitOutcome|TestSQLiteV4MigrationPreservesFullState|TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation|TestSQLiteV3OldBinaryRefusesWithoutMutation|TestSQLiteLegacyCASConnectionCleanup|TestReplayOriginalKeyReadCleanup|TestReplayOriginalKeyReadCallerRefusal|TestReplayGrantC1PreCommitConnectionQuarantine|TestReplayGrantD1BeginResponseLossQuarantine|TestReplayKeyStateD1BeginResponseLossQuarantine|TestReliableSubmitPrivatePersistenceStaticGuardrails)$' ./es/admission/internal/reliablesubmit
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateReplayProgressOccupiedDisposition|TestPrivateReplayProgressAdmissionReplay|TestPrivateReplayProgressHasNoEffectPaths|TestReliableSubmitFoundationHasNoRuntimeWiring|TestReliableSubmitBindingProducerHasNoProductionCaller|TestPrepareRequestShapeRemainsLegacyAndUnkeyed|TestResolvedSubmitLegacyEquivalenceOneNomadRegistrationAndAuthorityRecovery)$' ./es/admission
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestWorkstreamCContractPrepareAndSubmitRemainSeparatedAtAPIBoundary|TestSubmitPublicRouteRejectsStructuralReliableBody)$' ./es/api ./es/app
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=600s ./es/admission/internal/reliablesubmit ./es/admission ./es/api ./es/app
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=600s ./...
(cd "$N1_SOURCE" && "$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestPrivateReplayProgressAdmissionUnknownNoEffects$' ./es/admission)

# Additional guarded commands, after the primary sequence.
(cd "$N1_SOURCE" && "$GO" list -mod=readonly -deps -test -json ./es/admission)
(cd "$M_SOURCE" && "$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestIndependentMigrationClosedWrapperBeforeCommit$' ./es/admission/internal/reliablesubmit)
```

The additional `go list` exited 0. The migration diagnostic ran with 430 matched candidate leaves and one added test, SHA-256 `e0b662c8c5d084b209362be82ad54198a7cee85fa1966e9228953bbedad3ba21`. Its 431-file view digest was `6b461c8188c7397cdadc7a1b1dae9db0f2e856886548b9b8fadd75bfd4beeeda`, and its raw log SHA-256 was `28b632fc2d5c1a9cac35586eb0ca7454ff7d9530c22a8c04c12c0a5a728b2375`. Audit harness setup corrected a Python literal and followed the Homebrew Git executable symlink before the product commands. Neither attempt executed a product test.

### All 39 skips

The two direct helper skips were `TestPrivateReplayObjectAllocatorHelperProcess` and `TestSQLiteClaimStoreLockHelperProcess`. The shared allocator’s parent logged both `SHARED_ALLOCATOR_READY` and `SHARED_ALLOCATOR_WON`, proving child execution. The Docker daemon was unreachable in the `desktop-linux` context. `TestBringupScriptUpCheckDownFullProfile` skipped on that failed reachability requirement. `TestSubmitFlowMountsGovernedArtifactAndLifecycleWithInstalledSourceIdentity` skipped because the direct Docker Unix socket was unavailable. The other 35 App identities below skipped with Docker daemon probe exit 1 and connection unavailable.

```text
TestControlPlaneStaticScriptAPIPathCancelSucceeds
TestControlPlaneStaticScriptAPIPathFetchesRetainedResultBundle
TestDiagnosticsScriptRunIDBundleCollectsLifecycleSignalsAndStaging
TestExecuteLoopScriptFailureSummary
TestExecuteLoopScriptSuccessAndDeterministicDigests
TestExecutionCancelRetainsStageRootForDebugging
TestExecutionCancelStopsNomadJob
TestExecutionLogsReturnConflictWhenAllocationNotReady
TestExecutionLogsReturnRealContainerOutput
TestExecutionLoopScriptSuccessRetainsDistinctStageRootsAcrossRepeatedRuns
TestExecutionResultBundleAndStageRetainedAcrossStatusAndRepeatFetch
TestExecutionResultReturns404ForTerminalExecutionWithoutResultOutput
TestExecutionStatusReflectsFailedAllocation
TestExecutionStatusReflectsNomadJobState
TestExecutionStatusRetainsFailedStageRootForDebugging
TestExecutionStatusRetainsSuccessfulStageRootAndLogsStillWork
TestExecutionStatusReturns503WhenNomadUnavailable
TestLifecycleScriptCategorizesExecutionFailure
TestLifecycleScriptObservesExecutionViaPublicRunID
TestRuntimeIdentityIntegrationCapabilityProbe
TestSubmitFlowAllowsConfiguredControlPlaneCallerHandoff
TestSubmitFlowDoesNotStartWorkloadBeforeHelperReadiness
TestSubmitFlowHelperDeathIsTaskFatal
TestSubmitFlowInjectsWorkloadIdentityEndpointAndLifecycleStillWorks
TestSubmitFlowMountsGovernedArtifactAndLifecycleStillWorks
TestSubmitFlowProvidesPlatformOwnedRuntimeIdentityThroughBoundedEndpoint
TestSubmitFlowRejectsRuntimeIdentityPassthroughRequests
TestSubmitFlowRejectsWorkloadArchiveWithSymlinkEntry
TestSubmitFlowRemovesRuntimeMountArchiveResidueAfterExtraction
TestSubmitFlowRunsStaticScriptInNomadDocker
TestSubmitFlowUsesBridgeNetworkWhenNetworkAccessEnabled
TestSubmitFlowUsesConfiguredRuntimeIdentityTmpfsSize
TestSubmitFlowUsesPlatformOwnedIdentityForVaultLoginAndSecretRead
TestSubmitValidOperatorCallerReturnsAcceptedSubmissionReceipt
TestWorkloadCanCreateAndUseLocalRuntimeIdentityEndpointFromTmpfsWorkspace
```

## Closing record

Each primary command and external diagnostic had separately executed before/after source checks. The complete 430-leaf scoped guard remained `f1c6f9004eebcf317da80402e152ed95af2a8a0d98c1d9308e2b50976208fcef`. Closing rechecked 4,901 relied-upon file bindings, removed the audit-owned cache and temp directories, restored the copied probes to `0600`, and reran the authenticated recipe twice on the actual checkout. The test-owned temporary fixtures and helper processes used their maintained cleanup paths. I performed no global temp sweep. Both external source views and their guards were retained under private `0700` parents, with retained regular evidence at `0600` and copied source modes preserved.

The audit artifact index SHA-256 is `0fd8c79d0b2ac8e20f23aadd92045b03df30528e07331225aa58f124fb0a43bf`. Fresh reconciliation is `e08c3eaf8fab07238773f3d39278590c7e950344d26f60c96874de579a40c285`. Retained generation and differential reconciliation is `753254dcea05f88575517733cab446390d7be856a8850e8869111ec3f2054c77`. [Artifact index](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/artifact-index.json) · [Closing result](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/closing-b-result.json)

The performed effects were local read-only inspection, private evidence creation, offline builds, fixture migrations, maintained loopback mocks and helpers, and read-only Docker capability checks. Dependency downloads, installations, network Git operations, live stack, operational migration, real key loading, deployment and product repair were outside the executed scope.

```text
SOURCE_REPOSITORY_NOT_MUTATED
SOURCE_REFS_NOT_UPDATED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PRS_NOT_MODIFIED
EXISTING_OTHER_SOURCE_CHECKOUTS_NOT_SYNCHRONIZED
CROSS_RESTART_OPERATIONAL_WRITE_UNCERTAINTY_GATE_NOT_IMPLEMENTED
RUNTIME_WIRING_NOT_PERFORMED
PUBLIC_RELIABLE_SUBMIT_NOT_ENABLED
NATIVE_INSTALLED_SOURCE_WITNESS_NOT_QUALIFIED_BY_THIS_SLICE
```
<!-- END APPENDIX A -->

## Appendix B — Exact archived thirty-file opening canonical manifest

Bytes: 6813
SHA-256: 0812091529c67f4bc46d0bc343b3dea8595e63a461264e143d51606e581e0c06

<!-- BEGIN APPENDIX B -->
{"branch":"codex/private-replay-progress-v1","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/es_execution_admission_model.md","sha256":"b137a82d65da89428c5311f648fc664bea383ff61bf08c7868ec1a0df201016c","size":80816},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md","sha256":"ee2827be90bced19f0660a8378778898cd9970a08ebea49f0a94dfcf6c42d6ea","size":160692},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md","sha256":"1b03cc40b48861c7220a7b85d20b1f8d232690f17460e3eee0df33af4659e3f3","size":103025},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"30c2008df895f1ad9332a5e5e8a36cdea7719300ac52706ead4630a4fabf3e6e","size":301817},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"059a55f9cdac5cd802323aed29cf7a3a68c8a03bddc94b3225c54510903d116f","size":792416},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_operation.go","sha256":"b7761f001a1f67349ed51f2b79012194a7d45bb19c79e0ca2c0c22b8227320f9","size":9548},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_record.go","sha256":"999db7db6550c5031b023a9613825504e30e971a179298cc43e09cf8c5c5d7cd","size":25226},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_service.go","sha256":"ef0bc6f4d125f3986c46901cbe05bc2cb447af7dfbf51cee4653d7ce696c0945","size":49972},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/guardrails_test.go","sha256":"9a300f0553fd6ac3003a048a7309060a4ec6f618eacd94139bd4bb29c011bc60","size":32231},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_file.go","sha256":"61c4006e1e4a3feb7c0ec0e7d4685dc2c3fe8c1e2165d1529d2c86ae8fa137b5","size":50461},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_file_test.go","sha256":"207d9f17658cd50f6c4bea8e293b12abd89455a174b2d96bac84742a66b0afdf","size":69995},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_format.go","sha256":"b8cb8e31edd9d854317a0d6a456f25d5ab1838498623881e429dec2155e1ea67","size":16488},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_structure.go","sha256":"4916268757b93d409cbc13ba9c0da14e009499b4db7cadd52bc7ccd47c6a86ad","size":18640},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_progress_test.go","sha256":"0952fff321daa368dee1d32ed39a2a5b417e7d2779ae4e1015ab3c12b1021048","size":61314},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_migrations.go","sha256":"7736e30a1d0c6e9584d9050cc6ebf8bfaf900d424f764ebe61af8ec8ddaec0c9","size":17407},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_physical_test.go","sha256":"2c125b6373f83467d542db45473cc79b888ed3a665e65ef6bf013655f461a7ba","size":14539},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_pooled_claim_read_cleanup_test.go","sha256":"0ec3060ed3c30a6327ec49b0291d5c761c20894986c9b6b1e1be384694312823","size":8912},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_claim.go","sha256":"8ddec89b4ca5702591bdf2060062016d7fb54264fc7df57af5ead1d161eb9de3","size":8301},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go","sha256":"188425870bbe4bee37e176c4bee565b6aa61bc27b4a165a2dcf4a0efd6aa6b3c","size":25073},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_progress_schema.go","sha256":"132d8ab87f5658cab3477b9f6913538013ba922d4768192a96be960df7bbb149","size":30612},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_shape.go","sha256":"29cdbba2e5b1fee069989f6e6423dccc1c69c843de22b6504f68a7d199b317be","size":2751},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_shape_test.go","sha256":"3552ea5fafbc59e43cc21b1007486e98da4d59b6d0ea98db92646e0c8478adfb","size":8815},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_store.go","sha256":"f6db4f75bb5324b4459ac8337867d4f7d65f348a85f2f91381c5ab76e5518aea","size":62863},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_store_test.go","sha256":"c99e7659b1059431911557ba43ef7fa982e373bba939f610bd41ea0622cee96f","size":57339},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_guardrails_test.go","sha256":"32de42b7bf8974e36c014d3d9ce6d24e0994fbbc03bb1587c4c4fddd32c80f6e","size":50991},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_format.go","sha256":"0a21803b03308332613481f89ce4b595512b31b073c56b31fe7d8000519c3beb","size":17326},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_hydration.go","sha256":"b5ff16b96178c45b53165ebb2bcbdc67991bb145276ca4a11a598f1430745b9c","size":28800},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_private.go","sha256":"d17927a23a57c808a8f0ebc4bad3e9912e42d7da497033637102bae2c45fd278","size":20440},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_private_test.go","sha256":"4e4e7c7fad2ed2b88b35801841044f4b1f049a4cb6d0435499bb87699467e9f2","size":45171},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/workstream_c_guardrails_test.go","sha256":"68f2fe4e31e5d862be161c3ba1071a511935b32e90cf9021755fe4dcb045fab5","size":297009}],"head":"f1aa8b934cc26c16a966a110c7b408abdaeadce7","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"68339ba85b7b22d86bdaa21ed4fdccebc5021f82912344e0507862d1624cb791","upstream":"origin/trunk_dev"}

<!-- END APPENDIX B -->

## Appendix C — Exact v2 provenance recipe source

Bytes: 7275
SHA-256: c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca

<!-- BEGIN APPENDIX C -->
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
import sys
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v2"


def fail(message: str) -> "NoReturn":
    raise SystemExit(message)


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env.update(
        {
            "LC_ALL": "C",
            "LANG": "C",
            "GIT_OPTIONAL_LOCKS": "0",
            "GIT_NO_LAZY_FETCH": "1",
            "GIT_TERMINAL_PROMPT": "0",
            "GIT_PAGER": "cat",
        }
    )
    result = subprocess.run(
        [
            "git",
            "--no-pager",
            "-c",
            "core.fsmonitor=false",
            "-c",
            "core.untrackedCache=false",
            *args,
        ],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


def validate_output_path(output_path: Path, repository_root: Path) -> None:
    if not output_path.is_absolute():
        fail("output path must be absolute")

    parent = output_path.parent
    parent_metadata = parent.lstat()
    if not stat.S_ISDIR(parent_metadata.st_mode) or stat.S_ISLNK(parent_metadata.st_mode):
        fail("output parent must be a nonsymlink directory")
    if parent_metadata.st_uid != os.getuid():
        fail("output parent must be owned by the current user")
    if stat.S_IMODE(parent_metadata.st_mode) & 0o022:
        fail("output parent must not be group- or world-writable")

    try:
        output_path.lstat()
    except FileNotFoundError:
        pass
    else:
        fail("output path already exists")

    repository_text = os.path.realpath(os.fspath(repository_root))
    output_text = os.path.realpath(os.fspath(output_path))
    try:
        common = os.path.commonpath([repository_text, output_text])
    except ValueError:
        common = ""
    if common == repository_text:
        fail("output path must be outside the repository")


def write_exclusive(output_path: Path, payload: bytes) -> None:
    flags = (
        os.O_WRONLY
        | os.O_CREAT
        | os.O_EXCL
        | getattr(os, "O_NOFOLLOW", 0)
        | getattr(os, "O_CLOEXEC", 0)
    )
    fd = os.open(os.fspath(output_path), flags, 0o600)
    try:
        view = memoryview(payload)
        while view:
            written = os.write(fd, view)
            if written <= 0:
                fail("short provenance-output write")
            view = view[written:]
        os.fsync(fd)
    finally:
        os.close(fd)

    metadata = output_path.lstat()
    if not stat.S_ISREG(metadata.st_mode) or stat.S_ISLNK(metadata.st_mode):
        fail("provenance output is not a regular nonsymlink file")
    if metadata.st_uid != os.getuid():
        fail("provenance output owner mismatch")
    if stat.S_IMODE(metadata.st_mode) != 0o600:
        fail("provenance output mode mismatch")
    if metadata.st_nlink != 1:
        fail("provenance output link-count mismatch")
    if metadata.st_size != len(payload):
        fail("provenance output size mismatch")

    read_flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_CLOEXEC", 0)
    read_fd = os.open(os.fspath(output_path), read_flags)
    try:
        observed = bytearray()
        while len(observed) <= len(payload):
            chunk = os.read(read_fd, min(1 << 20, len(payload) + 1 - len(observed)))
            if not chunk:
                break
            observed.extend(chunk)
    finally:
        os.close(read_fd)
    if bytes(observed) != payload:
        fail("provenance output byte mismatch")


if len(sys.argv) != 2:
    fail("usage: governed_execution_audit_patch_manifest_v2.py ABSOLUTE_OUTPUT_PATH")

repository_root = Path(git_text("rev-parse", "--show-toplevel"))
output_path = Path(sys.argv[1])
validate_output_path(output_path, repository_root)

head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    fail("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            fail(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()

write_exclusive(output_path, canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")

<!-- END APPENDIX C -->

## Appendix D — External N-1 bridge — es/admission/internal/reliablesubmit/admission_unknown_witness_bridge.go

Bytes: 789
SHA-256: 14f0e9e92a37e1d1bf624f1f052a62a6d56e5b82f988698abbf6e1b5bcf9196d

<!-- BEGIN APPENDIX D -->
package reliablesubmit

import (
	"context"
	"database/sql"
)

// AttachAdmissionUnknownWitnessCommit is present only in the external fixture
// view. It models response loss after the selected store's real COMMIT.
func AttachAdmissionUnknownWitnessCommit(c *PrivateReplayProgressCustody, afterCommit func()) (counts func() (int, int), restore func()) {
	store := c.custody.store
	previous := store.claimCommit
	attempted, committed := 0, 0
	store.claimCommit = func(ctx context.Context, conn *sql.Conn) error {
		attempted++
		if err := commit(ctx, conn); err != nil {
			return err
		}
		committed++
		if afterCommit != nil {
			afterCommit()
		}
		return errClaimStoreCommitUnknown
	}
	return func() (int, int) { return attempted, committed }, func() { store.claimCommit = previous }
}

<!-- END APPENDIX D -->

## Appendix E — External N-1 witness — es/admission/reliable_submit_admission_unknown_witness_test.go

Bytes: 5897
SHA-256: 8da31dd61c9af2537c15f4376a330d05cb2e55dd2efd0ea610472a0c6ffa5c6a

<!-- BEGIN APPENDIX E -->
package admission

import (
	"context"
	"crypto/sha256"
	"errors"
	"maps"
	"net/http"
	"os"
	"path/filepath"
	"sync/atomic"
	"testing"

	"execution-substrate/es/admission/internal/reliablesubmit"
)

func TestPrivateReplayProgressAdmissionUnknownNoEffects(t *testing.T) {
	for _, operation := range []string{"Establish", "AssignRun"} {
		for _, recovery := range []string{"Canceled", "AuthenticatedExact"} {
			t.Run(operation+"/"+recovery, func(t *testing.T) {
				ctx := context.Background()
				s, raw, caller, keys, image := privateReplayServiceFixture(t)
				var provider, staging, egs atomic.Int64
				s.nomadClient = newResolvedPlanNomadClient(t, http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
					provider.Add(1)
					w.WriteHeader(http.StatusInternalServerError)
				}))
				s.egsClient = newResolvedPlanDependencyClient(t, http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
					egs.Add(1)
					w.WriteHeader(http.StatusInternalServerError)
				}))
				beforeStagingChildRegistrationStatForTest = func(string, int, bool) { staging.Add(1) }
				beforeStagingHandoffValidationForTest = func(*stagingCustody) { staging.Add(1) }
				defer func() {
					beforeStagingChildRegistrationStatForTest = nil
					beforeStagingHandoffValidationForTest = nil
				}()
				catalog, err := newPrivateSyntheticKeyCatalog(keys)
				if err != nil {
					t.Fatal(err)
				}
				root := privateReplayTestRoot(t)
				c, err := reliablesubmit.OpenPrivateReplayProgressCustody(ctx, root)
				if err != nil {
					t.Fatal(err)
				}
				defer c.Close()
				objects := func() map[string][32]byte {
					t.Helper()
					dir := filepath.Join(root, "objects", "v1")
					entries, err := os.ReadDir(dir)
					if err != nil {
						t.Fatal(err)
					}
					got := make(map[string][32]byte, len(entries))
					for _, entry := range entries {
						b, err := os.ReadFile(filepath.Join(dir, entry.Name()))
						if err != nil {
							t.Fatal(err)
						}
						got[entry.Name()] = sha256.Sum256(b)
					}
					return got
				}
				if operation == "AssignRun" {
					status, p, err := s.admitPrivateProgressReplay(ctx, c, raw, caller, catalog, image, reliablesubmit.FixturePendingBeforeAssignment)
					if err != nil || status != reliablesubmit.FixtureProgressCommitted || p.Revision() != 1 {
						t.Fatalf("initial control did not establish: %d %d %v", status, p.Revision(), err)
					}
				}
				before := objects()
				invocation, cancel := context.WithCancel(ctx)
				defer cancel()
				var after func()
				if recovery == "Canceled" {
					after = cancel
				}
				counts, restore := reliablesubmit.AttachAdmissionUnknownWitnessCommit(c, after)
				defer restore()
				var disposition reliablesubmit.FixtureProgressDisposition
				var projected reliablesubmit.FixtureProgress
				run := reliablesubmit.NewFixtureRunRef([32]byte{91})
				revision := int64(1)
				if operation == "Establish" {
					disposition, projected, err = s.admitPrivateProgressReplay(invocation, c, raw, caller, catalog, image,
						reliablesubmit.FixturePendingBeforeAssignment)
				} else {
					revision = 2
					disposition, projected, err = s.applyPrivateProgressReplay(invocation, c, raw, caller, catalog, 1,
						reliablesubmit.NewFixtureMutationRef([32]byte{92}), reliablesubmit.FixtureAssignRun{Run: run})
				}
				restore()
				attempted, committed := counts()
				if attempted != 1 || committed != 1 {
					t.Fatalf("expected one intended real COMMIT, attempts=%d committed=%d", attempted, committed)
				}
				want := reliablesubmit.FixtureProgressOwnCommitConfirmed
				projection := revision
				var wantErr error
				if recovery == "Canceled" {
					want, projection, wantErr = reliablesubmit.FixtureProgressWriteUnknown, 0, errPrivateReplayCommitUnknown
				}
				if disposition != want || !errors.Is(err, wantErr) || projected.Revision() != projection {
					t.Fatalf("invocation disposition=%d projection=%d err=%v", disposition, projected.Revision(), err)
				}
				if gotRun, present := projected.Run(); present != (projection == 2) || (present && !gotRun.Equal(run)) {
					t.Fatal("faulted invocation exposed an ineligible run")
				}
				if _, present := projected.Receipt(); present {
					t.Fatal("faulted invocation exposed a receipt")
				}
				committedObjects := objects()
				if len(committedObjects) != 1 || (operation == "AssignRun" && !maps.Equal(before, committedObjects)) {
					t.Fatal("faulted invocation sealed an additional object or replaced the original")
				}
				later, current, err := (&Service{}).admitPrivateProgressReplay(ctx, c, raw, caller, catalog, privateSyntheticImagePlacement{}, 0)
				if later != reliablesubmit.FixtureProgressCurrent || current.Revision() != revision || err != nil || disposition != want {
					t.Fatalf("later read changed invocation or lost current state: %d %d %v", later, current.Revision(), err)
				}
				got, present := current.Run()
				if present != (revision == 2) || (present && !got.Equal(run)) {
					t.Fatal("later current read did not preserve assigned fixture run")
				}
				if _, operational := any(got).(reliablesubmit.RunRef); operational {
					t.Fatal("test received an operational run reference")
				}
				if provider.Load() != 0 || staging.Load() != 0 || egs.Load() != 0 || !maps.Equal(committedObjects, objects()) {
					t.Fatalf("private admission caused effects: provider=%d staging=%d EGS=%d", provider.Load(), staging.Load(), egs.Load())
				}
				for _, effectRoot := range []string{s.cfg.Execution.StagingRootDir, s.cfg.Execution.ResultsRootDir} {
					entries, err := os.ReadDir(effectRoot)
					if err != nil || len(entries) != 0 {
						t.Fatalf("operational root was not empty: %v", err)
					}
				}
				t.Logf("one real COMMIT, modeled lost reply, disposition=%d projection=%d later revision=%d, provider/staging/EGS=0/0/0, empty roots", disposition, projection, current.Revision())
			})
		}
	}
}

<!-- END APPENDIX E -->
