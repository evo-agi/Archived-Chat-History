## Contract revisions are needed before implementation

**The direction is sound, but I would not freeze this contract for production-code implementation yet.** The report exposes an inherited reconciliation-model conflict and introduces a transaction/filesystem boundary whose failure rules need to be explicit. Both should be settled in the existing five-file contract candidate—not through another implementation-and-repair cycle.

The documentation validation reportedly passed all nine selected parents and eight subtests, with no failures or skips. The candidate remains unstaged and uncommitted, and the other 422 tracked files are unchanged. Those results support the document handoff; they do not establish that the proposed progression model is internally complete. Pasted text

I read the complete supplied report and preceding brief, then checked the relevant **pinned baseline** source and owner contract. I have not inspected the actual five uncommitted candidate files.

## 1. Reconciliation must not strand the attempt it is meant to recover

The draft selects a reconciliation tuple that is **set once**. Its transition table then says:

> “No-dispatch reconciliation precludes a later marker.”

It also retains pending, ambiguous, and inconsistent reconciliation states tied to particular current phases. Pasted text Pasted text

This needs reconciliation with two required progression sequences.

### Validated no-dispatch → first dispatch

The existing owner contract explicitly permits the **first dispatch for the same claim and `RunRef`** after the complete Validated No-Dispatch Evidence predicate passes, the current revision is validated, and the dispatch marker commits successfully. It does not permit a second send after possible dispatch. See the persistence ADR, §8, particularly `:442–506`. 

The draft’s unconditional prohibition would prevent:

```text
assigned run + committed intent
→ recorded validated no-dispatch reconciliation
→ fresh revision and uncertainty checks
→ first dispatch marker for that same run
```

Recording the observation should not, by itself, make the otherwise permitted recovery path impossible.

### Nonterminal reconciliation → stronger terminal evidence

The baseline reveals a related problem. `durable_record.go:417–430` requires pending reconciliation to coexist with the pending phase, and ambiguous/inconsistent reconciliation with the ambiguous phase. `durable_service.go:405–417` refuses replacement of an existing reconciliation tuple. The terminal operations clone that existing tuple into their successor.  

**Under those inherited rules, a recorded nonterminal reconciliation can invalidate a later accepted or provably-not-accepted successor.** The new contract’s phrase “compatible facts” does not resolve that interaction.

This is a **static contract/model finding**, not a newly executed failure and not a reason to reopen A1 acceptance. It is exactly the kind of inherited limitation we should avoid preserving by inertia when introducing a progress-bearing codec.

### Selected direction

Keep the existing seven phases, one claim/attempt, durable service, and revision CAS. **Explicitly refine codec-4 reconciliation semantics so a nonterminal observation does not permanently prohibit later stronger facts.**

The revised contract must choose one concrete treatment for carrying or superseding that observation and specify the exact successor fields. Prefer retaining it as historical evidence where the existing representation permits that safely. Do not add a history table, alternate state machine, reset, second attempt, or new `RunRef`.

The safety boundaries remain firm:

- A previous no-dispatch observation is **not** continuing permission to dispatch. The full current predicate and expected revision must be checked again.
- An existing dispatch marker is never cleared or used to authorize another send.
- Pending or ambiguous evidence does not itself establish acceptance. Stronger, positively bound evidence must justify the terminal transition.
- Legacy codec-1/2 and immutable codec-3 behavior remain unchanged; the refinement must be explicitly scoped to codec 4.

The acceptance plan needs both sequences across restart, plus stale-revision, unresolved-write, existing-marker, wrong-run, and contradictory-terminal negatives. Testing operations individually would miss this composition problem.

## 2. Shared object allocation introduces a new cleanup boundary

The draft proposes sharing the existing fixture root and budgets, with the SQLite writer lock serializing **object count plus exclusive creation** across both selectors, then releasing before permit consumption and Seal. That is a reasonable direction. Pasted text

But using the existing lock mechanism here is **new behavior**, not an already accepted allocator protocol. At the pinned baseline, `PublishSealedSynthetic`, `replay_custody_file.go:399–435`, checks the object budget and performs exclusive `Openat` without a surrounding SQLite transaction at that call site. 

The new contract needs an exit table as precise as the pooled-reader table:

```text
acquire checked connection
→ own BEGIN uncertainty
→ count and exclusively create under the shared lock
→ confirm transaction end
→ release database ownership
→ only then permit later key checking and Seal
```

The central distinction is simple: **rolling back SQLite does not remove a file already created in the filesystem.** An error after creation must preserve that object as inert and counted, retain no-refund/no-adoption semantics, and withhold a usable publication result or Seal when allocation cleanup is unconfirmed.

The documents must identify the exact connection and descriptor owner on every exit, including cancellation, transaction-end uncertainty, disposal failure, and the bounded rescue/withholding case. They must also identify **every scope-1 and scope-2 producer** participating in the same critical section. Locking only the new producer would not establish a shared cross-scope bound.

This does not require another general cleanup framework. It requires one complete, bounded allocation contract and targeted prospective tests near the final shared slot, including failure after exclusive creation.

## What I would retain

The report makes several important decisions correctly:

**The immutable/mutable split is explicit.** Original identity, binding, witness, commitments, key associations, and sealed-object descriptor remain fixed; revision and progress evolve without resealing. The original AEAD is not presented as authentication of arbitrary future progress. Pasted text

**Version and occupation boundaries are separate.** Schema 4, codec 4, scope 2, and envelope versions are individually specified. Codec 3 remains immutable, and an occupied caller/key does not become available merely because another scope requests it. Pasted text Pasted text

**Read failure does not erase preceding write uncertainty.** The outcome table requires exact full expected-row equality for own-COMMIT confirmation and preserves unknown when recovery or authentication fails. Pasted text

**The reader scope remains appropriately narrow.** The pooled `loadClaim` prerequisite is selected, while `loadClaimFresh` and its tested function-owned lifetime remain excluded. Pasted text

The migration compatibility inventory and explicit unsupported-codec fixture updates are also useful. They should remain in the revised candidate rather than be rediscovered through successive scope-widening failures. Pasted text

## Tighten the probe instructions and deliver the actual patch

The report correctly requires a distinct schema-3 binary to refuse schema 4. Its prospective command should also show the **build working directory explicitly**. A test overlay alone does not identify which production tree is being compiled. The revised instructions should bind the build to an external export of the pinned PR #10 source, never the evolving schema-4 candidate. The historical PB1 probe keeps its original purpose and identity. Pasted text Pasted text

For the next architectural review, Codex should also return a small review ZIP containing the **complete five changed files, complete diff, canonical manifest, and delivery inventory**. The inline report remains required.

That is not a request for another full repository snapshot. It closes a specific inspection gap: the report describes the new contract, but its local links and hashes do not expose the uncommitted document and assertion bytes here.

## Next Codex turn

Continue in the **same contract-authoring conversation**, rooted at:

```text
/Users/ds/Repositories/ES-Private-Replay-Progress-v1
```

Use:

:chatgpt-content-reference{index="16"}[Download the contract-reconciliation and exact-review-delivery prompt](sandbox:/mnt/data/ES_Private_Replay_Progress_Contract_Reconciliation_And_Review_Delivery_20261118.md)

SHA-256:

```text
8160f6e29c7f29f6de55e2725eb11a01aeec4c5f3c343fd0efbae06ad46a7a81
```

The write scope remains exactly the same five files:

```text
PLANS.md
.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md
.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md
.docs/execution_lifecycle/es_execution_admission_model.md
docs_contract_test.go
```

The prompt embeds the complete supplied report, exact opening manifest, and exact v2 recipe. I verified those three embedded payloads byte-for-byte. I also reproduced the report’s **1,331-byte canonical JSON** and its stated digest:

```text
4857bbf5f1572dbfb78c221a13d657107bcfbf6690d830b7769cc35465bdb0da
```

That verifies transport consistency—not the live checkout’s equality with the manifest. The latter remains an opening requirement for Codex.

The turn authorizes contract revisions, the same four documentation-validation commands, and exact review exports. **No product implementation, behavioral diagnostic, migration execution, old-binary build, full-suite replay, staging, commit, or publication is authorized.**

Expected endpoint:

```text
ES_PRIVATE_REPLAY_PROGRESS_CONTRACT_RECONCILED_READY_FOR_REVIEW
```

If the detailed candidate already resolves an ambiguity omitted from the report, Codex should identify the exact text and correct the report rather than introduce a redundant redesign. The substantive reconciliation conflict still needs an explicit disposition.

This remains **one integrated source slice**. After the revised contract is reviewed, the pooled-reader correction, versioned custody/migration, durable composition, and integrated validation can proceed in that candidate, followed by fresh independent audit. No separate documentation-only or reader-only PR is selected.

**Sources:** Complete attached owner-contract report; preceding owner-contract brief; pinned persistence contract, durable record/service, and publisher source cited above. I inspected those materials but did not execute repository tests or inspect the uncommitted five-file patch.

**Confidence:** **0.97** in the reconciliation finding; **0.95** that the new allocation boundary needs the stated clarification; **0.98** in keeping this next turn contract-only. Exact candidate correctness remains unassessed until its source bytes are delivered and reviewed.
