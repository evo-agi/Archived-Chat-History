# Execution Substrate — consolidated private replay-progress repair

## Objective and endpoint

Repair the eight findings in the supplied independent REJECT against the existing
thirty-path private replay-progress candidate. Preserve the accepted K1 operating
model and R1/R2/R3 architecture. This is one integrated repair, not eight PRs or a
new architecture reset. Include the SR-1 confirmation-borrow lifetime concern in
that finding's repair. Do not treat the earlier green suite as acceptance.

The foreground parent is authorized to make the bounded source/test/document
changes below, run offline implementation validation, and create new private
external evidence. Normal engineering iterations within this scope are permitted;
retain failed attempts and refreeze after actual corrections. They are not
independent acceptance. Complete the available work in this turn; if incomplete,
return a precise partial checkpoint without a readiness verdict.

Successful endpoint only after all findings have evidence-backed dispositions,
all required final validation succeeds, and final provenance is complete:

    ES_PRIVATE_REPLAY_PROGRESS_CONSOLIDATED_REPAIR_READY_FOR_FRESH_INDEPENDENT_AUDIT

Stop UNSTAGED and UNCOMMITTED. No commit, staging, amendment, ref update, push,
PR operation, merge, runtime wiring, operational migration, deployment, real key
loading, live stack, dependency download, or public reliable Submit is authorized.
A later fresh read-only conversation independently audits the complete new patch.
The earlier REJECT remains attached to its exact rejected manifest.

## 1. Conversation routing and one writer

Continue in the SAME foreground Codex conversation that returned the supplied
independent REJECT. Its four reviewers have closed; verify that before writing.
Transition the foreground parent to workspace-write. Spawn no writer or audit
subagents in this turn. Do not claim your repairs independently accepted.

The sole writable source checkout and EVERY product test/recipe working directory:

    /Users/ds/Repositories/ES-Private-Replay-Progress-v1

Use explicit working directories, absolute edit paths, and scoped `git -C` reads.
A conversation attachment or initial shell elsewhere is not the edit target. If
it still starts in `/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1`, leave
that checkout read-only and target the progress checkout explicitly. Do not move
a patch, synchronize either checkout, create another clone/worktree, switch or
reset a branch, or bypass workspace permissions.

Preserve the original ES, A1, O2, replay-publication and every other checkout.
Only the progress checkout and new repair-owned evidence/fixtures may change.

## 2. Exact opening gate

Expected progress repository:

    branch: codex/private-replay-progress-v1
    upstream: origin/trunk_dev
    origin: git@github.com:evo-agi/Execution-Substrate.git
    HEAD: f1aa8b934cc26c16a966a110c7b408abdaeadce7
    sole parent: fb9ae55797d9fcc02863c23fe8d3e43d16eac542
    HEAD tree: 8dd27f9acba98ed70d93736bdef8300ef1aba53f
    physical root, Git top-level: /Users/ds/Repositories/ES-Private-Replay-Progress-v1
    git-dir and common-dir: the target's own .git
    baseline tracked leaves: 427
    candidate: 27 unstaged tracked modifications + 3 authorized untracked files
    other tracked leaves: 400, HEAD-identical
    complete candidate source inventory: 430 leaves
    index: HEAD-identical; no staged or unmerged entries
    ignored and unexpected untracked paths: none

Rejected manifest, exact Appendix B:

    6813 bytes
    SHA-256 110cef71ba25f61b70297b37cc5a50a68732d639845e0ac4315d06cedcdbc1e3
    tracked full-index diff e45e3bd85391191702673b2d40fc2d06d865503004e09a8094c2f6a7081fe0c4

Authenticate the exact Appendix C recipe before executing a new repair-owned copy:

    governed-execution.audit-patch-manifest.v2
    7275 bytes
    c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca

Run it twice from the target to distinct absent external outputs; require exact
Appendix B bytes. Independently compare the 30 file rows, index and all 430 source
leaves. The three expected untracked source files are not unwanted artifacts.
Stop before source edits on mismatch; do not reset/rebaseline to force agreement.

Read the entire Appendix A rejection. Authenticate these material local records:

    audit root:
    /Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42
    audit-report.md SHA-256:
    b26b4be5f09d067184c9a00f837c20cabb200438230b2b86bdcefdc24d1e24c1
    artifact-inventory.json SHA-256:
    20bd8b3c998e6865490ea606281ea05788fe8987244857425fce5e97f8cb6879

    implementation packet:
    /Users/ds/Repositories/ES-Private-Replay-Progress-Implementation-20261119-kadgzy4t/ES-Private-Replay-Progress-Implementation-Review.zip
    718150 bytes
    bc4bc721f7aa0f02da9f2427625973e883a82fdc0988e4f587c2140792245cf3

Read/authenticate the retained SR-1/SR-2 diagnostic source, source-view inventory,
freeze, execution records and log, as identified by the audit inventory. Copy any
verifier source into the NEW root before execution. Do not import code from prior
roots. The separately rendered private audit and transport may have different
hashes; their decision facts must agree. The implementation had no standalone
whole-report duplicate/index: do not invent one or block on that absent artifact.
Use its actual packet, source map, generation records and transported closeout.
Authenticate only material evidence relied upon, not every historical root.

No network/ref observation is necessary for repair. Any optional remote read is
report-only and cannot authorize rebase or replacement of this exact local base.

## 3. Governing contracts and preserved decisions

Read AGENTS.md; current/relevant PLANS.md; the three changed lifecycle owner docs;
the entire impacted functions/callers/tests, schema and migration code; relevant
static inventories and public App/API boundaries; pinned Go/SQLite code where
needed. Do not execute repository scripts merely to inspect them.

Classification: a Bounded slice rule refinement on the reliable-submit Reopened
redesign seam. The current candidate remains private
`synthetic_progress_nonoperational_v1`, runtime-unwired and effect-ineligible.

Preserve:
- global caller/key occupation; one immutable original and one attempt per row;
- codec-4 rowid/original identity and descriptor, one assigned run, fixed marker
  and receipt, revision CAS, original format/domain encodings and fixture limits;
- K1: invocation-specific write disposition is independent of projection and of
  any later explicit fixture command; no response ledger or hidden knownness;
- R1: historical first reconciliation tuple survives stronger current facts;
- R2: both qualified publishers share bounded count/create and orphan semantics;
- R3: separately bound schema-2/PB1 and previous-schema-3 opener evidence;
- operational §8 Validated No-Dispatch Evidence unchanged and unimplemented by
  the fixture facade; no fixture outcome supplies provider permission;
- caller authentication before disclosure, changed-intent privacy, ordinary
  unkeyed Submit and public structural reliable-request refusal;
- ES owning admission/runtime facts, the existing durable service owning semantic
  progress, SQLite physical constraints, and separate Coordinator progression;
- loadClaimFresh BODY and function-owned pool lifetime; existing A1/O2/C1/D1
  cleanup, generic error mapper and exact-discard primitive behavior;
- migration literal bytes 1–4, ledger/source hashes and schema shape constants;
  no new schema version, stored column, row codec, envelope or digest version.

Update narrow governing text BEFORE corresponding behavior. The existing
contracts control SR-1, SR-2, M-1, M-2, K1-1 and R2-1; clarify them rather than
weaken them. Section 5 below freezes the concrete fixture-only T-1 association.
N-1 is a new acceptance witness, not an excuse to expose fault control publicly.
Record the rejected candidate and repair selection in current plan status; do
not rewrite historical reports or claim acceptance/publication.

## 4. Writable source scope: existing thirty-path candidate only

Primary repair paths (15; changes must be relevant to named findings):

    PLANS.md
    .docs/execution_lifecycle/es_execution_admission_model.md
    .docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md
    .docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md
    docs_contract_test.go
    es/admission/internal/reliablesubmit/replay_custody_file.go
    es/admission/internal/reliablesubmit/durable_service.go
    es/admission/internal/reliablesubmit/sqlite_store.go
    es/admission/internal/reliablesubmit/sqlite_replay_shape.go
    es/admission/reliable_submit_replay_private.go
    es/admission/internal/reliablesubmit/replay_progress_test.go
    es/admission/internal/reliablesubmit/replay_custody_file_test.go
    es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go
    es/admission/internal/reliablesubmit/sqlite_replay_shape_test.go
    es/admission/reliable_submit_replay_private_test.go

Conditional companion paths (5; inventory/assertion/test changes ONLY, with
specific cause recorded in the owner path map before editing):

    es/admission/internal/reliablesubmit/sqlite_store_test.go
    es/admission/internal/reliablesubmit/sqlite_physical_test.go
    es/admission/internal/reliablesubmit/guardrails_test.go
    es/admission/reliable_submit_guardrails_test.go
    es/admission/workstream_c_guardrails_test.go

These accommodate focused refusal/compatibility coverage and exact source/caller
inventories for the repaired helper/terminal constructor sites. Keep negative
mutants active; no wholesale allowlist, count loosening or deletion of assertions.

The remaining TEN rows of the opening thirty-file manifest and all 400 other
tracked leaves are byte/mode frozen. No new source path is authorized. In
particular, do not edit migration literal files, durable_record/operation, formats,
hydration, the completed pooled-reader regression, go.mod/go.sum, startup/config,
API/App code, scripts or examples. The aggregate patch stays exactly 30 paths,
27 modified + 3 untracked. Up to 20 rows may receive repair bytes; this is a ceiling,
not a requirement. No deletion/rename/type or mode change.

Keep production changes local to the five named production files. Small nil-default
per-instance test seams in existing store/custody fields are allowed only where a
deterministic M-1 or SR-1-lifetime interleaving cannot otherwise be observed. They
must not create an API, environment switch, global registry, persistent flag or
runtime path. Record instrumentation before using it as causal evidence.

External test-only views/overlays for N-1 and differential controls are permitted
under section 7; they are NOT additional repository files or product interfaces.
Stop with the exact unresolved seam and preserved state if more source authority
or a stored-format change is actually required. Do not patch around the boundary.

## 5. Complete repair requirements

### M-2 — literal internal namespace, not LIKE wildcard

Repair BOTH pristine-bootstrap qualification and complete schema inventory.
`NOT LIKE 'sqlite_%'` wrongly hides legal user names such as `sqliteXforeign`.
Use one consistently defined LITERAL seven-character `sqlite_` prefix rule with
explicit ASCII case treatment consistent with the pinned engine. A substring
comparison with explicit NOCASE collation, for example, avoids underscore and
percent wildcard interpretation. Do not use an unescaped LIKE or hide every
object whose name merely begins `sqlite`.

Preserve the existing ordered digest encoding and every legitimate schema hash
1–4. Correctly including previously invisible EXTRA objects changes their
qualification, not the digest of an authentic schema. Verify genuine internal
objects/autoindexes remain handled as before. Do not bless extra objects, learn
hashes from the target DB, delete objects or alter constants to match bad state.

Regressions on real pinned SQLite must include:
- app/version 0 database containing a legal `sqliteXforeign` table and sentinel
  rows: refuse bootstrap; no ES tables/ledger/application ID adoption;
- authentic schema-3 upgrade target and schema-4 current target with legal extra
  objects using the wildcard-collision prefix, including mixed ASCII case:
  refuse without deleting/adopting them or changing their logical contents;
- at least a table plus another supported schema-object type in separate cases;
- authentic 0–4 controls, ordinary foreign names, and unchanged digest constants.
Witness schema rows, pragma identity, ledger and contents by independent read
queries that do NOT reuse the flawed exclusion rule. Logical refusal preservation
is not a claim that opening never alters SQLite file/sidecar bytes or metadata.

### M-1 — authorize migration from the state inside BEGIN IMMEDIATE

Pre-lock observations may reject obviously unsupported input, but cannot authorize
DDL, ledger writes or PRAGMA identity/version changes. On EVERY bootstrap/upgrade
route, acquire the guarded writer transaction first, then reread and authenticate
the actual opening application ID, user_version, complete schema and ledger or
literal pristine condition before the first migration write. Capture migration
opening-version/recovery baselines only from this lock-held validated state.

Avoid nesting BEGIN. One function must clearly own transaction start, precommit
rollback, attempted-COMMIT handling and result classification. Use existing
bounded migration recovery and disposal; do not add a retry loop or treat mere
pool invalidation as proof of physical close. Do not change shared A1/O2 helpers.

The lock-held state is authoritative. Never overwrite an unsupported, foreign or
malformed state because an earlier observation was valid. If another legitimate
opener advanced the database before this transaction acquired the lock, fully
validate that ACTUAL state and choose the remaining supported migration once;
if it is already the authentic current head, finish the lock-only transaction
with known cleanup and no migration write. Do not splice an old ledger or source
version into the newer route. No automatic second migration attempt after an
uncertain outcome is authorized.

Deterministic real-SQLite tests must order an independent connection's COMMIT
between the opening preflight (when retained) and the guarded decision. Cover:
- authentic v3 -> a disallowed version such as 99 before writer acquisition;
- pristine-looking v0 -> committed foreign schema/content before acquisition;
- changed application ID or ledger/schema invalidation before acquisition;
- a legitimate competing migration reaching authenticated schema 4;
- ordinary authentic 0/1/2/3 -> 4 and already-current controls;
- rejection of mixed/intermediate state and continued lost-COMMIT recovery.

Use a barrier/seam and a second real writer, not sleep-dependent luck. The red
case must reach candidate behavior and exhibit the incorrect adoption/overwrite,
not only a test setup error. Green must refuse the disallowed actual opening
state without product DDL/DML/identity changes; compare the state AFTER the second
writer's intentional commit with the post-refusal state. Preserve old migration
literals, their hashes, full logical state, and both historical binary purposes.

### SR-1 — confirmation eligibility and live borrow

Before disclosing an establishment-confirmation snapshot, require the same exact
active-or-retired original-key eligibility as ordinary existing-original reads.
Use the existing paired-key checker, caller context and exact retained key IDs,
purposes and fingerprints. Do not choose new active keys or register absent keys.

Recheck live issuer-bound access after acquiring the issuer lock and after the
key-read/qualification boundary, before projection. Preserve one-use consumption,
copy/foreign-issuer refusal, cancellation, callback-return and Close semantics.
The asynchronous late-use schedule described by the audit must be deterministically
exercised: pass the first consumption check, wait for issuer lock, return/cancel
the owning callback, then release the wait; no projection may escape. Do not
introduce background authority or promise atomic instantaneous revocation beyond
the selected observation boundaries.

Keep the selected committed snapshot for a known successful establishment;
current-key eligibility does not require replacing it with later row progress.
On failed entry/lifetime checks: zero projection; known COMMIT remains Committed;
a failed recoverable-unknown confirmation remains WriteUnknown. Never manufacture
OwnCommitConfirmed from an ineligible snapshot or erase a known write.

Promote the audit's real SQLite SR-1 cases to maintained regressions: known
establishment and real-COMMIT/lost-response establishment, active and retired
controls, revoked-before-read-entry for EACH original key role, ordinary current
read refusal, cancellation/closed/escaped borrow, rows and sealed bytes unchanged.
Retain the exact audit diagnostic as historical evidence and bind new red/green
sources rather than claiming the old test file was something it was not.

### SR-2 — present eligibility before fresh reconciliation no-op

For codec 4, enforce the selected CURRENT recording predicate before a fresh
same-fact reconciliation can return NoChange. Row-valid historical storage is
not the predicate for a new command. Preserve the historical tuple unchanged,
eligible same-fact no-ops, exact-latest replay before stale classification,
changed-input conflict, current revision checks and legacy codec-1/2 behavior.
Do not remove historical evidence or reintroduce the old terminal phase trap.

Exercise Pending, Ambiguous and Inconsistent after incompatible provider progress,
Accepted and NotAccepted, with a NEW mutation at the CURRENT revision. Require
refusal and zero projection, with zero durable changes. Preserve valid controls
before/in compatible progression, exact latest replay, stale older mutation and
changed-input conflict. Include the other reconciliation kinds in the predicate
table so a local fix does not bypass their selected conditions. Coordinate with
T-1's negative-terminal evidence predicate. Test latest replay independently from
a fresh no-op; do not move candidate-phase checks ahead of legitimate exact replay.

### K1-1 — preserve definite Occupied when winner disclosure fails

A completed establish attempt that definitely lost the global caller/key slot
retains Occupied if subsequent winner key lookup or authentication cannot produce
an eligible projection. Successful winner projection still returns Occupied;
proved changed incoming intent retains the selected Conflict result. Missing key
material, revoked keys, cancellation or unavailable authentication must withhold
progress/run/receipt without downgrading known occupancy into generic Refused.

Keep this mapping LOCAL to the known-loser path. Do not expose Occupied from an
unauthenticated generic lookup, conflate initial hits with this invocation's write
disposition, turn an uncertain write into Occupied, or retry/reseal/re-resolve.

Use a deterministic same-key race with disjoint catalogs: both legitimate initial
proposals, one winner, and a loser unable to retrieve the winner's original pair.
Check occupied + zero projection, no second write/Seal from recovery, winner and
orphan preservation. Include valid equivalent winner disclosure, changed-intent
conflict with accessible originals, and canceled/unavailable disclosure controls.

### T-1 — explicit fixture outcome and receipt association (selected refinement)

Freeze this narrow owner-contract refinement before code. Terminal evidence is a
bounded SYNTHETIC assertion, not an independently observed provider receipt or
runtime trust mechanism. The durable service must validate the association
independently of the selected command; command choice or a digest of that same
command cannot manufacture the missing assertion.

Retain FixtureTerminalEvidence as a redacted value with private fields. Give it
an explicit two-value outcome discriminator and, for Accepted ONLY, an exact
fixture receipt association. Select two finite internal-package constructors:

    NewFixtureAcceptedEvidence(claim ClaimID, run FixtureRunRef,
        marker FixtureFactRef, fact FixtureFactRef,
        receipt FixtureReceiptRef) (FixtureTerminalEvidence, error)

    NewFixtureNotAcceptedEvidence(claim ClaimID, run FixtureRunRef,
        marker FixtureFactRef, fact FixtureFactRef) (FixtureTerminalEvidence, error)

The zero value and invalid shapes refuse. Neither constructor grants authority or
asserts that the described event occurred outside the fixture. Their only
consumers are the existing private fixture surface and named tests. No registry,
signature system, new DB/columns, provider adapter, arbitrary verified boolean,
raw record getter or dynamic callback is selected. They are the only new exported
fixture constructors authorized by this repair, still behind admission's internal
package boundary; record the exact caller/aggregate inventory.

Acceptance must compare all of: authenticated access/immutable original and claim,
assigned run, fixed marker, positive Accepted discriminator, valid fact, and exact
equality of the independently constructed evidence receipt with the command's
receipt. Reject/negative reconciliation must require NotAccepted, no receipt,
matching claim/run/marker, and exact fact association. Do not derive or repair an
evidence discriminator/receipt from the command under validation. Do not silently
convert old untagged evidence to accepted evidence. Corroborative kind-4
reconciliation still cannot create acceptance/receipt; it checks an already
accepted row under its existing current predicate.

The existing operation kind/receipt/fact inputs already bind the selected command;
no durable-operation encoding, domain, schema, sealed original or stored-format
change is selected. Validate evidence before relying on replay/no-op where
required, but preserve legitimate exact-latest replay for the same valid evidence.
No candidate-phase precondition may accidentally reject exact replay of its own
terminal result. Scope these checks to codec 4; legacy requests stay unchanged.

Construct evidence separately, then substitute only the command receipt or command
kind in negative tests. Cover: accepted evidence with a different receipt;
positive evidence used for rejection/negative reconciliation; negative evidence
used for acceptance; missing/invalid discriminator and receipt; wrong original/
claim/run/marker/fact; valid accepted and negative controls, terminal replay,
opposite terminal attempts, and receipt immutability. Invalid assertions must
produce zero projection and no write. Do not call this provider acceptance proof.

### R2-1 — restore scope-1 publication preflight/burn ordering

HEAD qualified custody/parents, the frozen value and permit presence BEFORE
arranging irreversible burn. Restore that boundary for scope 1. Once a valid
publication attempt is entered, arrange burn before qualified foreign-issuer
refusal/allocation so the intentional no-refund/no-reuse rule remains. Do not
move the burn below allocation or consume/Seal, or convert the permit to reusable
after an eligible attempt fails. Preserve the selected scope-2 wrapper rules.

Test a legitimate permit presented through a closed/unqualified scope-1 handle:
no allocation or Seal and the original issuing handle can still perform its
eligible first attempt. A qualified wrong issuer must still burn/refuse before
allocation. Include invalid frozen/nil-permit preflight, allocation fault, success,
second-use refusal and cross-scope controls. Durable reservation counters never
reset or refund. The shared allocator itself, filename bound and orphan policy
stay selected; no new allocator design/campaign is required.

### N-1 — admission-level lost-response/no-effect witness

Exercise the REAL admission composer/mutation entry, real SQLite COMMIT and
unchanged response handling under the same provider/staging/EGS counters and
staging/results-root checks. A synthetic returned error without real COMMIT is
not this witness; a lower-level custody test alone is insufficient.

Do not add a product fault API to cross the internal package boundary. Selected
mechanism: one private external source view of the frozen candidate, with a
bounded test-only bridge source file in the internal package and an admission
_test.go file (or equivalently bound overlay). The bridge may only attach and
restore existing per-store commit-response hooks on the exact test custody; it
must perform real COMMIT and then inject its response error, optionally invoking
the test's cancellation/cleanup action. It cannot replace admission outcome
mapping, inject successful projections, bypass authentication, or write arbitrary
claims. All original candidate production bytes remain identical in that view;
only the two new diagnostic files are added. The bridge is absent from the actual
repository, ordinary build and final source manifest. Retain all source and the
explicit run command in the delivery packet for independent rerun.

Before execution bind the complete view, two diagnostic files, toolchain/module
inputs, fault schedule and expected counters/dispositions. Name the parent:

    TestPrivateReplayProgressAdmissionUnknownNoEffects

Cover both initial establishment and a later progress mutation:
- real COMMIT + lost response + recovery unavailable/canceled: WriteUnknown,
  zero projection, exactly one intended durable write, no automatic retry;
- real COMMIT + lost response + authenticated exact readback: OwnCommitConfirmed
  for that invocation, no extra write, zero effect contacts;
- a separate later authenticated read sees current state without rewriting the
  earlier recorded invocation outcome.

Counters must surround the entire admission call, not only a helper. Record zero
provider, staging and EGS contacts; empty operational roots; fixture-only refs;
all owned handles/processes cleaned. Clear fault hooks before later controls.
Use only loopback mocks and disposable fixture databases. Label response loss a
fault model, not a physically reproduced network/OS failure.

This supplemental view is an acceptance witness, not a new product test-skip or
shipping fault-control export. The ten ordinary validation commands remain against
the real candidate without this bridge. Keep the bounded static guard and
independent caller trace; report its direct receiver/alias limitations honestly.
A general transitive call-graph framework is NOT a repair prerequisite. Any exact
inventory update in allowed guard files must keep the runtime/startup exclusion
and existing negative mutants; new constructors or local helpers require traceable
finite inventory, not a blanket allowance.

## 6. Repair order and red/green evidence

Use one writer and one candidate. Order:

    doc refinements and explicit T-1 assertion contract
    -> M-2 namespace and M-1 lock-held opening gate
    -> SR-1 confirmation/lifetime + R2-1 publication compatibility
    -> T-1 typed assertion + SR-2 fresh no-op predicates
    -> K1-1 admission disposition + N-1 end-to-end witness
    -> integrated validation and provenance

These are internal phases, not routine user approval stops or separate PRs.
Source-local refactoring inside the allowed production functions is permitted
only when needed for these fixes and must preserve other contracts.

For each behavioral finding preserve a byte-bound negative control using the
REJECTED implementation, not an unrelated older baseline. Use real SQLite and
original production branches. Bind exact test bytes and any nil-default seam-only
instrumentation BEFORE interpreting a result. Keep test assertions identical
between red and green. For T-1 constructor evolution, retain a narrow test-only
adapter on the old view that represents the same adversarial association, and
state the interface difference; a compile failure is not a red result.

Retain the auditor's SR-1/SR-2 result (10 passes, 13 failures) unchanged. A repair
regression may promote those cases and add controls but is new evidence, not a
retroactive rerendering of the old diagnostic. The unexecuted M-1/M-2/K1-1/T-1/R2-1
cases need new regression evidence before claiming reproduced defects or closure.
N-1 fills a missing witness and need not manufacture a failing old-source result.

No sleep-only timing race or process-wide FD-count equality oracle. Use explicit
barriers, actual independent SQLite connections and source-bound observation
points. No new socket harness or physical-close-fault subsystem.

Normal development failures/corrections remain visible. Once the final source is
frozen, run one complete final sequence. If source changes after it, refreeze and
rerun; do not present older successful logs as evidence for different bytes.

## 7. Evidence hygiene, environment and permitted test effects

Create a fresh absent private external root, for example using mkdtemp:

    /Users/ds/Repositories/ES-Private-Replay-Progress-Consolidated-Repair-20261119-<unique>

Current-user-owned nonsymlink directories 0700, retained regular files 0600.
Do not alter /Users/ds/Repositories permissions or any prior evidence root.
Repository source files remain 0644. Export source fixtures can use source modes
inside private 0700 parents. Execute copied probe files only while needed, then
restore retained copies to 0600. Never expose keys/credentials or raw unsafe logs.

For every Python execution use PYTHONDONTWRITEBYTECODE=1 and python3 -B; set
sys.dont_write_bytecode in in-process helpers. Authenticate and copy prior verifier
source before running it from the new root. Timestamps, inode allocation and
directory mtimes are not canonical provenance gates.

Use pinned Go:

    /Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go

and its sibling gofmt. Preflight actual executable resolution for Go 1.26.5,
Python 3.13 with tomllib, OpenSSL 3 (prior 3.6.2), and Git. Record paths, versions,
hashes, working directory and safe explicit environment overrides, not raw ambient
credential/environment dumps. Offline cached modules only:

    GOTOOLCHAIN=local
    GOPROXY=off
    GOSUMDB=off
    GOWORK=off
    GOFLAGS=-mod=readonly
    CGO_ENABLED=0
    GOTELEMETRY=off
    GOMODCACHE=/Users/ds/go/pkg/mod
    GIT_OPTIONAL_LOCKS=0
    GIT_NO_LAZY_FETCH=1
    GIT_TERMINAL_PROMPT=0
    PYTHONDONTWRITEBYTECODE=1
    fresh repair-owned GOCACHE, GOTMPDIR, TMPDIR
    outer umask 077; Go-test subprocess umask 027

Authenticate and reuse task-owned copies of the DISTINCT retained probes; do not
rebuild them from this repair:

    historical PB1/schema-2 probe: 14350930 bytes
    b205a31bac091cbcf5b3f4826bc359455625316908051131733622813e34adcf
    previous-schema-3 probe: 15601186 bytes
    42614a50812a65ba52b53488d872884e59ce7b4f57dece6a66642d4eb8de1409
    retained schema-3 compiled-input inventory:
    50a81fa5a042e135abfc9f6bad68d20abc4575f881945ecc84252c14910dde8f

Bind ES_REPLAY_PB1_PROBE and ES_REPLAY_SCHEMA3_PROBE to those copies. Tests supply
their own ES_REPLAY_PB1_TARGET / ES_REPLAY_SCHEMA3_TARGET child targets. Continue
authentic schema-3 for PB1 and schema-4 for the previous-schema-3 opener. Do not
expect the old binaries to enforce new M-1/M-2 semantics; they only serve the
preserved version-refusal purposes. New qualification tests run the repaired opener.

Permitted effects: real disposable SQLite DBs/migrations, synthetic keys/files,
controlled helper processes, local loopback mocks, and existing test-owned /tmp
or /private/tmp fixtures and temporary Git repositories as used by the maintained
suite. New runner caches and retained evidence belong under the private root.
Identify ownership and remove only task-created fixtures. Do not sweep global tmp,
start a Docker/ES/Nomad/live stack, contact deployment hosts, load deployed keys,
install dependencies or widen capability skips. Tests may perform their existing
local Docker capability probes; an unavailable capability remains a classified
skip, not native qualification. Stop before newly available live-stack effects
rather than silently granting them or claiming the skipped proof passed.

## 8. Exact final validation

Use the following NEW maintained regression parents in the named existing files:

    TestPrivateReplayProgressConfirmationEligibility  (replay_progress_test.go)
    TestPrivateReplayProgressReconciliationEligibility (replay_progress_test.go)
    TestPrivateReplayProgressTerminalEvidenceBinding   (replay_progress_test.go)
    TestSQLiteMigrationOpeningRevalidatedUnderLock     (sqlite_replay_migration_test.go)
    TestSQLiteLiteralInternalNamespaceQualification    (sqlite_replay_shape_test.go)
    TestPrivateReplayScope1PublicationPreflight         (replay_custody_file_test.go)
    TestPrivateReplayProgressOccupiedDisposition        (admission/reliable_submit_replay_private_test.go)

Use exact names to make selection evidence unambiguous. Keep existing parents and
assertions. The overlay-only N-1 parent has the name specified above and introduces
NO direct helper skip in the ordinary source suite.

The final ladder is the original ten commands, with the new parents included in
their relevant focused selectors, plus ONE supplemental N-1 command: eleven serial
commands total. GO and GOFMT below expand to the authenticated pinned absolute
paths; CANDIDATE is the exact checkout; N1_SOURCE is the authenticated final
external view of all 430 candidate leaves plus the two bridge/diagnostic files.
No product source overlay is present in the ten ordinary commands.

```sh
# cwd = CANDIDATE for commands 1–10
"$GO" version
"$GOFMT" -d docs_contract_test.go es/admission/internal/reliablesubmit/sqlite_store.go es/admission/internal/reliablesubmit/sqlite_replay_claim.go es/admission/internal/reliablesubmit/sqlite_migrations.go es/admission/internal/reliablesubmit/sqlite_replay_progress_schema.go es/admission/internal/reliablesubmit/sqlite_replay_shape.go es/admission/internal/reliablesubmit/durable_record.go es/admission/internal/reliablesubmit/durable_operation.go es/admission/internal/reliablesubmit/durable_service.go es/admission/internal/reliablesubmit/replay_custody_format.go es/admission/internal/reliablesubmit/replay_custody_structure.go es/admission/internal/reliablesubmit/replay_custody_file.go es/admission/reliable_submit_replay_format.go es/admission/reliable_submit_replay_hydration.go es/admission/reliable_submit_replay_private.go es/admission/internal/reliablesubmit/sqlite_pooled_claim_read_cleanup_test.go es/admission/internal/reliablesubmit/replay_progress_test.go es/admission/internal/reliablesubmit/replay_custody_file_test.go es/admission/internal/reliablesubmit/sqlite_store_test.go es/admission/internal/reliablesubmit/sqlite_physical_test.go es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go es/admission/internal/reliablesubmit/sqlite_replay_shape_test.go es/admission/internal/reliablesubmit/guardrails_test.go es/admission/reliable_submit_guardrails_test.go es/admission/reliable_submit_replay_private_test.go es/admission/workstream_c_guardrails_test.go

git --no-pager diff --check

"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateOriginalReplayProgressContractSelection|TestReliableSubmitPersistenceAndConcurrencyADRDocsContract|TestSubmitIdempotencyCorrelationAndRecoveryDocsContract|TestReliableSubmitPureModelDocsAndSourceContract|TestReliableSubmitPublicOptInAndVersioningDocsContract|TestReliableSubmitContractAdapterFoundationDocsAndSourceContract|TestReliableSubmitBindingProducerDocsContract|TestIntegratedAcceptanceGateDocumentationIsConsistent|TestIntegratedCandidateStatusSeparatesCAndT)$' .

"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestSQLitePooledClaimReadCleanup$' ./es/admission/internal/reliablesubmit

"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateReplayProgressConfirmationEligibility|TestPrivateReplayProgressReconciliationEligibility|TestPrivateReplayProgressTerminalEvidenceBinding|TestSQLiteMigrationOpeningRevalidatedUnderLock|TestSQLiteLiteralInternalNamespaceQualification|TestPrivateReplayScope1PublicationPreflight|TestPrivateReplaySharedObjectAllocation|TestReplayPublicationFaultAndIdentity|TestPrivateReplayProgressFormatVectors|TestPrivateReplayProgressTransitions|TestPrivateReplayProgressConcurrencyAndCommitOutcome|TestSQLiteV4MigrationPreservesFullState|TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation|TestSQLiteV3OldBinaryRefusesWithoutMutation|TestSQLiteLegacyCASConnectionCleanup|TestReplayOriginalKeyReadCleanup|TestReplayOriginalKeyReadCallerRefusal|TestReplayGrantC1PreCommitConnectionQuarantine|TestReplayGrantD1BeginResponseLossQuarantine|TestReplayKeyStateD1BeginResponseLossQuarantine|TestReliableSubmitPrivatePersistenceStaticGuardrails)$' ./es/admission/internal/reliablesubmit

"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateReplayProgressOccupiedDisposition|TestPrivateReplayProgressAdmissionReplay|TestPrivateReplayProgressHasNoEffectPaths|TestReliableSubmitFoundationHasNoRuntimeWiring|TestReliableSubmitBindingProducerHasNoProductionCaller|TestPrepareRequestShapeRemainsLegacyAndUnkeyed|TestResolvedSubmitLegacyEquivalenceOneNomadRegistrationAndAuthorityRecovery)$' ./es/admission

"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestWorkstreamCContractPrepareAndSubmitRemainSeparatedAtAPIBoundary|TestSubmitPublicRouteRejectsStructuralReliableBody)$' ./es/api ./es/app

"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=600s ./es/admission/internal/reliablesubmit ./es/admission ./es/api ./es/app

"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=600s ./...

# 11: separately bound N-1 view; actual candidate is untouched
(cd "$N1_SOURCE" && "$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestPrivateReplayProgressAdmissionUnknownNoEffects$' ./es/admission)
```

Before freezing, format the supplemental diagnostic sources in their private
root; retain their bytes. All required parents must actually start and finish;
regex exit zero with no matching test is not coverage. If the focused internal
set genuinely needs more time because new deterministic barriers add cases,
record the reason and raise only that final frozen command's deadline BEFORE
execution (maximum 600s); never erase a timeout or change timing merely to hide
an unbounded operation.

After EVERY final command, and each relied-upon red/green or supplemental run,
execute a fresh integrity observation against all 430 candidate source leaves,
HEAD/branch/upstream/index, exact path set, unchanged frozen rows, and:

    git ls-files --others --exclude-standard -z
    git ls-files --others --ignored --exclude-standard -z

The first must equal the three authorized source additions; the second empty.
Record separate execution/log/exit associations even if deterministic guard
outputs are identical. Check external diagnostic source inventories separately.
No staged, unmerged, extra, ignored, deleted or mode-changed paths.

The previous implementation full count is 5096/0/39, NOT the expected new count.
Reconcile additions and any changed test identities, package results and skip
names/reasons. Preserve the 37 App capability classifications and two direct
helper sentinels where capabilities are unchanged. The allocator child must run
under its parent despite its direct sentinel skip. No new repair path may be
unexercised via skip. The independent audit did NOT rerun commands 9/10; preserve
that historical fact. This repair must execute its complete final ladder before
readiness. No old fourteen-gate/socket campaign or machine-wide FD sweep.

## 9. Closeout and exact review delivery

After task-owned cache/scratch cleanup, run Appendix C twice to distinct absent
external outputs. Require byte-identical new canonical manifests. Compare every
row with Appendix B and report exactly which of the at-most-20 permitted rows
changed and which remained frozen. Preserve the exact thirty-path classifications,
400 other tracked files, HEAD and clean unstaged index posture. Verify the shared
loadClaimFresh body and frozen literal/shape identities rather than claiming their
behavior from a function hash alone.

Provide one complete, decision-ready human-readable report INLINE, including:
- all eight finding dispositions, SR-1 lifetime coverage, precise remaining limits;
- source paths/line ranges, doc-first T-1 representation and finite API inventory;
- red/green source identities, actual observations versus injected response models;
- all eleven final argv, environments, results, executed guard associations,
  test/skip/package reconciliation, and every unrun/failed attempt;
- logical migration preservation versus physical-close/file-byte qualifications;
- no-effect counters at admission level, N-1 external-only bridge classification;
- exact full canonical manifest JSON, recipe/diff/manifest digests and file count;
- effect inventory, untouched other-checkout state and the required nonclaims.

Retain a supplementary private whole report and a safe self-excluding artifact
index. Unlike the earlier implementation, create these explicitly this time; the
whole report supplements, never replaces, the inline report. Bulky raw logs stay
private. Do not emit raw keys, unsafe environment values or secrets.

Return a review ZIP containing all 30 COMPLETE candidate files, full tracked HEAD
patch, complete rejected-to-repaired delta including all untracked source bytes,
new canonical manifest, per-path source map, README and exact self-excluding
inventory. Include a separately labeled evidence directory in the ZIP containing
the two safe N-1 diagnostic/bridge sources and its exact view/command binding;
they are not product source rows. Include safe regression construction metadata
and necessary test-only adapters, never DBs, keys, binary probes or raw sensitive
logs. Do not assume a tracked diff carries untracked content.

Verify both patch targets in disposable copies under private parents, with source
modes explicitly established; don't repeat the umask packaging incident. Bind ZIP
size/hash and all entry names/types/modes/hashes. Upload via an actually available
attachment surface if supported; otherwise give the exact local ZIP path and
state it requires upload. Do not push an artifact to GitHub or create a PR to
work around attachment limits.

No source bytes may change after final frozen validation except by a newly recorded
repair generation with fresh validation. Do not return ACCEPT in this writer turn.
If any mandatory evidence or repair remains incomplete, state it and use a partial
or blocked repair verdict, not READY. If the safe human-readable report cannot be
fully transported inline, return REPORT_INLINE_BLOCKED with current effects and
no readiness verdict.

Successful ending:

    ES_PRIVATE_REPLAY_PROGRESS_CONSOLIDATED_REPAIR_READY_FOR_FRESH_INDEPENDENT_AUDIT
    INDEPENDENT_ACCEPTANCE_NOT_PERFORMED
    STAGING_NOT_PERFORMED
    COMMIT_NOT_PERFORMED
    PUSH_NOT_PERFORMED
    PRS_NOT_MODIFIED
    EXISTING_OTHER_SOURCE_CHECKOUTS_NOT_SYNCHRONIZED
    LOADCLAIMFRESH_LIFECYCLE_PRESERVED
    CROSS_RESTART_OPERATIONAL_WRITE_UNCERTAINTY_GATE_NOT_IMPLEMENTED
    RUNTIME_WIRING_NOT_PERFORMED
    PUBLIC_RELIABLE_SUBMIT_NOT_ENABLED
    NATIVE_INSTALLED_SOURCE_WITNESS_NOT_QUALIFIED_BY_THIS_SLICE

## 10. Hard stops

Stop on candidate/provenance mismatch, unauthorized path or effect need, required
module download, live key/host/stack requirement, changed original-format or
migration-literal necessity, unresolvable T-1 authority expansion, source loss,
or substantive regression outside this bounded repair. Preserve partial work,
exact identities and safe evidence; do not reset, discard another writer's work,
forge outcomes, relax security checks, or silently move to another checkout.

## 11. Embedded input identities

Appendices are exact transport bytes between their delimiters, ending with their
original final newline. Their source identity is independent of this prompt's
own hash. No recipe or repository source below is executed by ChatGPT.

| Appendix | Bytes | SHA-256 |
|---|---:|---|
| A: complete supplied independent rejection | 32151 | `da618d64527ed921138be23cc764d23012531f584769ab40e4fb968fb7844e5b` |
| B: exact rejected candidate manifest | 6813 | `110cef71ba25f61b70297b37cc5a50a68732d639845e0ac4315d06cedcdbc1e3` |
| C: exact v2 recipe source | 7275 | `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` |

## Appendix A — Complete supplied independent audit

<BEGIN_APPENDIX_A>
# REJECT

The exact thirty-path candidate is **ineligible for a later local commit gate**. Independent SQLite diagnostics reproduced SR-1 and SR-2. Source review also confirmed two defects in migration opening validation. The focused suite passed, including both historical opener probes. Those tests do not exercise the defective branches.

No repository files were changed. All four independent reviewers completed their read-only reviews and closed.

## Findings

| ID | Severity and basis | Finding and required correction |
|---|---|---|
| **SR-1** | **High · Introduced · Reproduced** | Both establishment confirmation paths disclose a committed snapshot after the original key has been revoked. The confirmation branch at lines 1340–1351 checks custody qualification and skips the exact-key check performed by the ordinary branch at lines 1353–1376. The owner contract at lines 907 and 923–937 requires eligible keys at operation entry. Require the exact active-or-retired registry check and live borrow before disclosing the snapshot. Keep known COMMIT known and failed recoverable-unknown confirmation unknown, with zero projection in either refusal case. The impact is private fixture disclosure and confirmation. [Confirmation read](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/replay_custody_file.go:1340) · [Owner contract](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md:923) |
| **M-1** | **High · Inherited ordering defect in the selected migration · Source-confirmed** | `openGate` samples opening application ID, version, schema and ledger at lines 550–604. Bootstrap and upgrade take `BEGIN IMMEDIATE` later, at lines 672–705 and 720–757, then write from the earlier observation. A second SQLite writer can change the observed schema-3 version before the lock is taken. Migration 4 can overwrite that disallowed version and still pass the final shape checks. ADR lines 1683–1686 and 1708–1714 require verifying the actual opening state inside the transaction before writing. Move that verification under the lock and preserve the literal migrations and bounded recovery. This interleaving was reviewed statically. [Opening gate](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_store.go:550) · [Upgrade](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_store.go:720) · [Migration contract](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1683) |
| **M-2** | **High · Inherited schema qualification defect · Source-confirmed** | The pristine check at lines 772–784 and schema digest at lines 22–24 use `NOT LIKE 'sqlite_%'`. `_` matches any single character. The pinned SQLite source reserves the literal `sqlite_` prefix, so an ordinary name such as `sqliteXforeign` is legal and invisible to both checks. The opener can claim a nonempty version-0 database or accept an extra object at the current head. Use a literal namespace check at both boundaries, retain the legitimate schema hashes, and cover both refusal cases. The existing foreign-database test uses `foreign_*` names. No new migration diagnostic was run for this finding. [Pristine check](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_store.go:772) · [Schema digest](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_replay_shape.go:22) · [Pinned SQLite name check](/Users/ds/go/pkg/mod/modernc.org/sqlite@v1.54.0/lib/sqlite_g_0000000000000003.go:59855) |
| **SR-2** | **Medium · Introduced · Reproduced** | A fresh same-fact op 7 can return `FixtureProgressNoChange` with current progress after the recording predicate has failed. The equality return at lines 443–445 bypasses phase/provider eligibility and becomes a no-change result at lines 1221–1226. ADR lines 1471–1490 distinguish admissible historical storage from a currently eligible command. Check codec-4 current predicates before returning a fresh same-fact no-op. Preserve the historical tuple, exact latest replay, stale/conflict handling and codec-1/2 semantics. The counterexamples disclosed progress without a durable change. [Reconciliation](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/durable_service.go:421) · [Result classification](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/durable_service.go:1193) · [R1 contract](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1471) |
| **K1-1** | **Medium · Introduced · Source-confirmed** | A same-key loser can lose its definite `Occupied` disposition after a successful winner lookup. Lines 297–308 remap successful `Current` to `Occupied`, but lines 325–359 can return `Refused` if the losing catalog lacks the winner’s key pair or later authentication fails. The owner preserves the definite occupied outcome. Keep `Occupied` when winner disclosure fails and preserve the selected changed-intent conflict result. This path has zero projection and issues no second write. The disjoint-catalog race was reviewed statically. [Composer](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/reliable_submit_replay_private.go:297) · [Winner authentication](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/reliable_submit_replay_private.go:325) · [Disposition contract](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md:911) |
| **N-1** | **Medium · Acceptance evidence gap** | ADR acceptance row N requires an unknown-write case under the admission effect counters. The admission fixture at lines 874–973 covers match, mismatch, acceptance, cancellation and incompatibility. The real lost-response cases run at the custody/service boundary. Add an admission-level lost-response witness that asserts the resulting disposition, projection and zero effect contacts. The eight effect guard mutants ran. The mutant for an unreviewed method checks a direct call on receiver `s`, so the guard alone cannot establish transitive closure through aliases or free helpers. The current call graph was reviewed independently. [Acceptance row N](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1848) · [Admission fixture](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/reliable_submit_replay_private_test.go:874) · [Effect guard](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/reliable_submit_guardrails_test.go:93) |
| **T-1** | **Medium · Terminal fixture evidence limitation · Source-only** | ADR lines 1526–1532 require positive same-attempt evidence and receipt association. Lines 1108–1118 and 1177–1183 check claim, run, marker and fact presence. The receipt is separately shape-checked and bound in the operation digest. The fixture has no independent receipt-to-evidence association check, and the evidence type carries no polarity apart from command selection. Establish the bounded association before claiming independent terminal evidence validation. No terminal counterexample was executed. [Terminal contract](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1526) · [Evidence type and check](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/durable_service.go:1108) |
| **R2-1** | **Low · Introduced scope-1 compatibility drift · Source-only** | HEAD checked custody, frozen value and permit presence before arranging burn. Lines 406–419 now arrange burn before that preflight. Presenting a legitimate scope-1 permit through a closed or unqualified handle can burn it where HEAD left it usable at the issuing handle. Restore the inherited preflight boundary and retain the intentional qualified foreign-issuer burn before allocation. Durable reservation counts are unaffected by this difference. No new execution covered this case. [Publisher entry](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/replay_custody_file.go:406) · [Allocator contract](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1752) |

The custody review also identified an in-flight borrow lifetime concern in the SR-1 branch. A direct asynchronous fixture callback can pass the first lifetime check and race callback return while waiting for the issuer lock. The confirmation branch lacks the ordinary branch’s second lifetime check. The sole admission continuation is synchronous. This schedule was unexecuted and should be covered by the confirmation-boundary correction. [Borrow consumption and confirmation](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/replay_custody_file.go:1328)

## Independent diagnostic results

**SR-1.** The callback ran after original authentication. A separate fixture handle committed the key transition. The original handle observed the revoked registry state before entering `ReadFixtureProgress`. For the recoverable-unknown case, the existing COMMIT seam executed one real COMMIT and then modeled loss of its response.

| Route | Active and retired controls | Revoked before read entry |
|---|---|---|
| Known establishment | `Committed`, revision 1 | `Committed`, revision 1 returned. Expected retained `Committed` with zero projection and a read error. |
| Recoverable-unknown establishment | `OwnCommitConfirmed`, revision 1 | `OwnCommitConfirmed`, revision 1 returned. Expected retained `WriteUnknown` with zero projection. |
| Ordinary current read | Revision 1 returned | Read refused with revision 0, as required. |

The claim and sealed bytes stayed equal in all nine cases. The observation concerns revocation already committed and visible at method entry. [Diagnostic source](/Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42/audit-progress-diagnostic.bytes.go) · [Raw diagnostic log](/Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42/run-diagnostic/stdout)

**SR-2.** After restart and fresh authentication, each of Pending, Ambiguous and Inconsistent accepted a new mutation identity at the current revision in three ineligible states: incompatible provider observation, Accepted and Provably Not Accepted. All nine returned `NoChange`, revision 6 and no error. Compatible-provider no-ops, pre-advancement no-ops, exact latest replay, changed-input conflict and stale replay passed. Full rows, historical tuples and sealed bytes stayed equal across the observations. The diagnostic exited **1**, with **10 passing and 13 failing test identities**, including the two failed parents. Neither finding was rerun with altered assertions. [Frozen diagnostic](/Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42/diagnostic-freeze.json) · [Executed command and guard](/Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42/run-diagnostic/run.json)

## Provenance and integrated review

The physical and Git root was `/Users/ds/Repositories/ES-Private-Replay-Progress-v1`, with its own `.git`. Branch `codex/private-replay-progress-v1` tracked `origin/trunk_dev` at HEAD `f1aa8b934cc26c16a966a110c7b408abdaeadce7`, sole parent `fb9ae55797d9fcc02863c23fe8d3e43d16eac542`, tree `8dd27f9acba98ed70d93736bdef8300ef1aba53f`, subject “Harden original-key read transaction cleanup (A1) (#10).” Origin matched `git@github.com:evo-agi/Execution-Substrate.git`. There were 27 unstaged tracked changes, three authorized untracked additions and 400 unchanged tracked leaves. The index equaled HEAD. Both untracked inventories matched, with zero ignored paths. There were zero staged, unmerged, deleted, renamed, type-changed or extra paths. [Source inventory](/Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42/source-inventory.json)

The four appended payloads, both ZIPs, all 36 implementation members, source map, inventory and both retained implementation manifests authenticated. The five K1 owner/test files matched the opening side of the source map and were compared with the candidate. Two opening and two closing executions of the unchanged 7,275-byte recipe reproduced the **6,813-byte manifest** at SHA-256 `110cef71ba25f61b70297b37cc5a50a68732d639845e0ac4315d06cedcdbc1e3`. The tracked full-index diff was `e45e3bd85391191702673b2d40fc2d06d865503004e09a8094c2f6a7081fe0c4`. Appendix A authenticated as supplied. The scoped implementation root had no standalone whole-report duplicate or index. The transport, its inventory and the generation records bind their respective contents. [Packet verification](/Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42/packets.json) · [Closing manifest](/Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42/close-a.json)

The owners select a private **Bounded slice rule** on the reliable-submit **Reopened redesign seam**, limited to `synthetic_progress_nonoperational_v1`. The audit retained four independent perspectives and checked their load-bearing conclusions against the owning contracts and source. The reviewers agreed on SR-1 and SR-2. The evidence limits below remain relevant to any later gate. [Planning selection](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/PLANS.md:16) · [Admission boundary](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/es_execution_admission_model.md:603)

- **Pooled reader and inherited cleanup.** Verified cancellation before dispatch, exact disposal on ambiguous BEGIN or read COMMIT, request-independent bounded rollback after known BEGIN, cleanup context observation before self-cancel, one discard rescue, double withholding and post-COMMIT cancellation. The retained red/green runs used the exact final 8,912-byte regression. Red exited 1 and showed fresh-context same-store read and CAS failures after real BEGIN or SELECT cancellation and modeled loss of a real BEGIN response. Green exited 0 with all 16 identities passing. The final `loadClaim` body equals green. `loadClaimFresh` remains byte-identical across HEAD, red, green and candidate at 1,077 bytes, with its independent pool lifetime intact. Shared scanner validation and the expected schema head changed. The v2 differential binds the exact test and store sources through retained phase-1 records and has no separate complete v2 compile ledger or direct nested-BEGIN observation. [Reader source](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_store.go:278) · [Retained reader differential](/Users/ds/Repositories/ES-Private-Replay-Progress-Implementation-20261119-kadgzy4t/phase1-v2)

- **Durable transitions and K1.** The existing durable service remains the semantic writer. The SQLite CAS compares full immutable identity and current row, checks key eligibility in the same transaction, advances the exact revision through mutable columns only, and verifies the postimage. Reviewed known CAS loss, exact latest replay, stale and changed-input conflict, committed-snapshot handling, and exact full-record recovery after write uncertainty. Recovery performs one bounded authenticated read after disposal permits it, with no automatic second write or rebase. The operation digest binds typed ordered inputs and the predecessor, with mutation identity compared separately. Run, receipt, marker and the first reconciliation tuple remain protected, subject to the findings above. Codec-1/2 historical predicates and the immutable codec-3 route remain distinct. [CAS and writer](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_store.go:1813) · [Fixture result handling](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/durable_service.go:1193)

- **Custody and allocation.** Reviewed the separate schema, codec, scope and envelope axes, exact format dispatch, AEAD/AAD and commitment association, parser budgets, SQL storage classes and enum checks before narrowing, and issuer, context, Close and one-use checks. The independent vectors passed. The publisher uses random-nonce GCM. Both scope selectors share one checked SQLite writer lock for count and exclusive create. Verified release and FD handoff precede permit consumption and Seal. The independent child reached `SHARED_ALLOCATOR_READY` and `SHARED_ALLOCATOR_WON`. The parent required successful child exit, one verified winner, one full refusal, 32 names, two reservations and zero claims. Fault cases exercised exact disposal, owned-FD closure and counted inert orphans. SQL-pool quarantine shows exclusion and invocation of driver `Close`. Physical teardown and close duration remain unmeasured, and double withholding can retain capacity. The DB/sidecar budget is a detection boundary. [Format selection](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/replay_custody_format.go:184) · [Shared allocator](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/replay_custody_file.go:578) · [Independent process assertions](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/replay_custody_file_test.go:1548)

- **Migration and old openers.** Literal migrations 1–3 and their hashes held. Focused tests exercised authentic openings at 0–3, full logical claim/registry/counter/ledger preservation, precommit rollback, real COMMIT with a lost response, and intermediate/mixed refusal. Those fixtures do not exercise M-1 or M-2. The complete 427-leaf schema-3 export matched pinned PR #10. All 1,354 recorded inputs authenticated, including the retained generated test main and one-entry test-only overlay. The separate 15,601,186-byte schema-3 binary refused a schema-4 target populated with all four codecs. Full logical witnesses and both sealed originals stayed equal. The 14,350,930-byte PB1 binary and its three bound source/harness/build records matched the historical originals. PB1 refused its distinct authentic schema-3 target under the preserved narrower witness. Both probes ran from authenticated copies without rebuild. The migration matrix establishes logical preservation. The direct sealed-byte checks come from the old-opener fixture. [Migration matrix](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go:454) · [Distinct probe tests](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_replay_shape_test.go:17) · [Probe evidence](/Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42/retained-evidence-summary.json)

- **Admission and no-effect boundary.** Authenticated hits chose retained keys after lookup and avoided new resolution, acquisition and Seal. Restart drift, same-key race, opposite-scope occupation, both initial phases and shared capacity were exercised. Checked all 32 typed Workstream C entries and the changed per-method references. The 27 additions comprise one mutex, three atomic flags and 23 references or request fields. Retained exact inventory and negative reference/structural mutants ran, and fresh admission effect mutants passed. The finite 11-entry effect inventory and source trace found no route from public ingress, startup, configuration, scripts or examples into the private composers. App/API structural refusal and unkeyed compatibility passed against local mocks. SR-1 widens **private** disclosure eligibility, and M-1/M-2 compromise private database qualification. I found no public or operational authority widening. Coordinator authority remains separate. Operational Validated No-Dispatch Evidence, cross-restart write-uncertainty authority, provider eligibility and native installed-source qualification remain open. [Admission replay cases](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/reliable_submit_replay_private_test.go:671) · [Workstream C inventory](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/workstream_c_guardrails_test.go:2280) · [Public refusal](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/app/submit_integration_test.go:3517)

## Validation and skips

The independent run used pinned Go 1.26.5 `darwin/arm64`, Python 3.13.4 with `tomllib`, OpenSSL 3.6.2, Git 2.49.0, cached modules and the prescribed offline readonly environment. Executable paths, hashes and environment are retained. Each of the eight candidate commands and the diagnostic had a separately executed immediate guard against all 430 files, index and routing. Every guard passed. Focused test identity multisets matched retained generation 2 exactly. [Preflight](/Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42/preflight.json) · [Fresh command records](/Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42/fresh-validation-summary.json)

| Gate | Independent execution | Authenticated retained generation 2 |
|---|---:|---:|
| 1 · Go version | Exit 0, pinned version | Exit 0 |
| 2 · Formatting | Exit 0, clean | Exit 0, clean |
| 3 · Diff whitespace | Exit 0, clean | Exit 0, clean |
| 4 · Contract | Exit 0, 22 passed | Exit 0, 22 passed |
| 5 · Pooled reader | Exit 0, 16 passed | Exit 0, 16 passed |
| 6 · Storage, custody and historical probes | Exit 0, 136 passed | Exit 0, 136 passed |
| 7 · Admission and effects | Exit 0, 18 passed | Exit 0, 18 passed |
| 8 · API/App | Exit 0, 2 passed | Exit 0, 2 passed |
| 9 · Four-package suite | **Unrun** | Exit 0, 1,971 passed, 39 skipped |
| 10 · Full tree | **Unrun** | Exit 0, 5,096 passed, 39 skipped |

Gates 9 and 10 were omitted under the confirmed-blocker rule. Retained generation 2 had zero failures, 21 test-bearing packages and 20 no-test packages. I reconciled all ten raw logs, their exit records and distinct guard associations. Focused start and terminal identities were subsets of the full run, and gate 9 was the exact four-package projection. The independent gates and diagnostic had zero skips. [Retained evidence reconciliation](/Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42/retained-evidence-summary.json)

The retained skip inventory comprises:

- **Two helper sentinels:** `TestPrivateReplayObjectAllocatorHelperProcess` and `TestSQLiteClaimStoreLockHelperProcess`. The allocator helper ran under its parent.
- **Three App capability cases with distinct reasons:** `TestBringupScriptUpCheckDownFullProfile` required a reachable Docker daemon. `TestWorkloadCanCreateAndUseLocalRuntimeIdentityEndpointFromTmpfsWorkspace` required a healthy daemon. `TestSubmitFlowMountsGovernedArtifactAndLifecycleWithInstalledSourceIdentity` required a direct Docker Unix socket.
- **34 App daemon-probe failures:** `TestControlPlaneStaticScriptAPIPathCancelSucceeds`, `TestControlPlaneStaticScriptAPIPathFetchesRetainedResultBundle`, `TestDiagnosticsScriptRunIDBundleCollectsLifecycleSignalsAndStaging`, `TestExecuteLoopScriptFailureSummary`, `TestExecuteLoopScriptSuccessAndDeterministicDigests`, `TestExecutionCancelRetainsStageRootForDebugging`, `TestExecutionCancelStopsNomadJob`, `TestExecutionLogsReturnConflictWhenAllocationNotReady`, `TestExecutionLogsReturnRealContainerOutput`, `TestExecutionLoopScriptSuccessRetainsDistinctStageRootsAcrossRepeatedRuns`, `TestExecutionResultBundleAndStageRetainedAcrossStatusAndRepeatFetch`, `TestExecutionResultReturns404ForTerminalExecutionWithoutResultOutput`, `TestExecutionStatusReflectsFailedAllocation`, `TestExecutionStatusReflectsNomadJobState`, `TestExecutionStatusRetainsFailedStageRootForDebugging`, `TestExecutionStatusRetainsSuccessfulStageRootAndLogsStillWork`, `TestExecutionStatusReturns503WhenNomadUnavailable`, `TestLifecycleScriptCategorizesExecutionFailure`, `TestLifecycleScriptObservesExecutionViaPublicRunID`, `TestRuntimeIdentityIntegrationCapabilityProbe`, `TestSubmitFlowAllowsConfiguredControlPlaneCallerHandoff`, `TestSubmitFlowDoesNotStartWorkloadBeforeHelperReadiness`, `TestSubmitFlowHelperDeathIsTaskFatal`, `TestSubmitFlowInjectsWorkloadIdentityEndpointAndLifecycleStillWorks`, `TestSubmitFlowMountsGovernedArtifactAndLifecycleStillWorks`, `TestSubmitFlowProvidesPlatformOwnedRuntimeIdentityThroughBoundedEndpoint`, `TestSubmitFlowRejectsRuntimeIdentityPassthroughRequests`, `TestSubmitFlowRejectsWorkloadArchiveWithSymlinkEntry`, `TestSubmitFlowRemovesRuntimeMountArchiveResidueAfterExtraction`, `TestSubmitFlowRunsStaticScriptInNomadDocker`, `TestSubmitFlowUsesBridgeNetworkWhenNetworkAccessEnabled`, `TestSubmitFlowUsesConfiguredRuntimeIdentityTmpfsSize`, `TestSubmitFlowUsesPlatformOwnedIdentityForVaultLoginAndSecretRead`, and `TestSubmitValidOperatorCallerReturnsAcceptedSubmissionReceipt`.

### Exact gate commands

The first eight ran in the actual checkout. The last two are the unrun commands.

```sh
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go version
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/gofmt -d docs_contract_test.go es/admission/internal/reliablesubmit/sqlite_store.go es/admission/internal/reliablesubmit/sqlite_replay_claim.go es/admission/internal/reliablesubmit/sqlite_migrations.go es/admission/internal/reliablesubmit/sqlite_replay_progress_schema.go es/admission/internal/reliablesubmit/sqlite_replay_shape.go es/admission/internal/reliablesubmit/durable_record.go es/admission/internal/reliablesubmit/durable_operation.go es/admission/internal/reliablesubmit/durable_service.go es/admission/internal/reliablesubmit/replay_custody_format.go es/admission/internal/reliablesubmit/replay_custody_structure.go es/admission/internal/reliablesubmit/replay_custody_file.go es/admission/reliable_submit_replay_format.go es/admission/reliable_submit_replay_hydration.go es/admission/reliable_submit_replay_private.go es/admission/internal/reliablesubmit/sqlite_pooled_claim_read_cleanup_test.go es/admission/internal/reliablesubmit/replay_progress_test.go es/admission/internal/reliablesubmit/replay_custody_file_test.go es/admission/internal/reliablesubmit/sqlite_store_test.go es/admission/internal/reliablesubmit/sqlite_physical_test.go es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go es/admission/internal/reliablesubmit/sqlite_replay_shape_test.go es/admission/internal/reliablesubmit/guardrails_test.go es/admission/reliable_submit_guardrails_test.go es/admission/reliable_submit_replay_private_test.go es/admission/workstream_c_guardrails_test.go
git --no-pager diff --check
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateOriginalReplayProgressContractSelection|TestReliableSubmitPersistenceAndConcurrencyADRDocsContract|TestSubmitIdempotencyCorrelationAndRecoveryDocsContract|TestReliableSubmitPureModelDocsAndSourceContract|TestReliableSubmitPublicOptInAndVersioningDocsContract|TestReliableSubmitContractAdapterFoundationDocsAndSourceContract|TestReliableSubmitBindingProducerDocsContract|TestIntegratedAcceptanceGateDocumentationIsConsistent|TestIntegratedCandidateStatusSeparatesCAndT)$' .
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestSQLitePooledClaimReadCleanup$' ./es/admission/internal/reliablesubmit
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateReplaySharedObjectAllocation|TestReplayPublicationFaultAndIdentity|TestPrivateReplayProgressFormatVectors|TestPrivateReplayProgressTransitions|TestPrivateReplayProgressConcurrencyAndCommitOutcome|TestSQLiteV4MigrationPreservesFullState|TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation|TestSQLiteV3OldBinaryRefusesWithoutMutation|TestSQLiteLegacyCASConnectionCleanup|TestReplayOriginalKeyReadCleanup|TestReplayOriginalKeyReadCallerRefusal|TestReplayGrantC1PreCommitConnectionQuarantine|TestReplayGrantD1BeginResponseLossQuarantine|TestReplayKeyStateD1BeginResponseLossQuarantine|TestReliableSubmitPrivatePersistenceStaticGuardrails)$' ./es/admission/internal/reliablesubmit
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateReplayProgressAdmissionReplay|TestPrivateReplayProgressHasNoEffectPaths|TestReliableSubmitFoundationHasNoRuntimeWiring|TestReliableSubmitBindingProducerHasNoProductionCaller|TestPrepareRequestShapeRemainsLegacyAndUnkeyed|TestResolvedSubmitLegacyEquivalenceOneNomadRegistrationAndAuthorityRecovery)$' ./es/admission
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestWorkstreamCContractPrepareAndSubmitRemainSeparatedAtAPIBoundary|TestSubmitPublicRouteRejectsStructuralReliableBody)$' ./es/api ./es/app
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=600s ./es/admission/internal/reliablesubmit ./es/admission ./es/api ./es/app
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=600s ./...
```

The diagnostic ran in the private external view of all 430 authenticated source leaves plus one test-only file.

```sh
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestAuditProgressConfirmationRechecksOriginalKeys|TestAuditProgressReconciliationNoopRequiresCurrentPredicate)$' ./es/admission/internal/reliablesubmit
```

## Closeout

Only audit-owned files and disposable fixtures were created. The runs used fixture SQLite databases, sealed objects, helper processes and loopback mocks. I removed the audit-owned cache and the two empty scratch directories. I retained the source view, diagnostic and run records, restored the copied probes to mode `0600`, and rechecked 1,865 relied-upon material records. Final source, index, configuration and ref observations matched opening. No external network, operational migration, live stack, publication or other-checkout work occurred. [Source closeout](/Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42/source-closeout.json) · [Material recheck](/Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42/prior-material-closeout.json)

The supplementary report SHA-256 is `b26b4be5f09d067184c9a00f837c20cabb200438230b2b86bdcefdc24d1e24c1`. The self-excluding 517-file inventory SHA-256 is `20bd8b3c998e6865490ea606281ea05788fe8987244857425fce5e97f8cb6879`. [Private report](/Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42/audit-report.md) · [Artifact inventory](/Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42/artifact-inventory.json)

```text
SOURCE_REPOSITORY_NOT_MUTATED
SOURCE_REFS_NOT_UPDATED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PRS_NOT_MODIFIED
EXISTING_OTHER_SOURCE_CHECKOUTS_NOT_SYNCHRONIZED
RUNTIME_WIRING_NOT_PERFORMED
PUBLIC_RELIABLE_SUBMIT_NOT_ENABLED
CROSS_RESTART_OPERATIONAL_WRITE_UNCERTAINTY_GATE_NOT_IMPLEMENTED
NATIVE_INSTALLED_SOURCE_WITNESS_NOT_QUALIFIED_BY_THIS_SLICE
```<END_APPENDIX_A>

## Appendix B — Exact rejected thirty-file canonical manifest

<BEGIN_APPENDIX_B>
{"branch":"codex/private-replay-progress-v1","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/es_execution_admission_model.md","sha256":"03f03a378beecb53f4c996022ef004e892922bbfd69972d3887ba618dd26011c","size":80361},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md","sha256":"6e69af309b665e6769590a1206df4e2ff6d244ebe2446d88458bcb4570fa2c66","size":156221},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md","sha256":"5640ab0307e251eb304258a1017509c6ed0f9021210931f808c9854b99d818c0","size":102166},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"cf7c3fc49c71ee62a5c6121c9154f7c3fafeaa667a6bf6a711e380e812a88477","size":300922},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"4d9c5cda8bf6b768cbda818c1f8583e2b3954abf6a49cd2c8effa3141afe946d","size":791928},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_operation.go","sha256":"b7761f001a1f67349ed51f2b79012194a7d45bb19c79e0ca2c0c22b8227320f9","size":9548},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_record.go","sha256":"999db7db6550c5031b023a9613825504e30e971a179298cc43e09cf8c5c5d7cd","size":25226},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_service.go","sha256":"caa5139671d91f18e269256dc11ea12cb949c2737f0d9eb81fb0afa2cb529232","size":47166},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/guardrails_test.go","sha256":"9812c719dd31b594c59dbf6daf47dc43fdac1bdb483346d0ec0be83b1688f4ea","size":30905},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_file.go","sha256":"8eeac273d6db099ef15c68021e48c6f013253088b83f4318ce530acc52151cea","size":50001},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_file_test.go","sha256":"3e6fcca31873ba5d54b0f4ee389e09a2613eb38269c217f00078c43bcf63e167","size":66823},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_format.go","sha256":"b8cb8e31edd9d854317a0d6a456f25d5ab1838498623881e429dec2155e1ea67","size":16488},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_structure.go","sha256":"4916268757b93d409cbc13ba9c0da14e009499b4db7cadd52bc7ccd47c6a86ad","size":18640},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_progress_test.go","sha256":"470bd6250f0c34800a2c099e96fbe5fd0b43398296b82904a0e56ff7f85b6f7f","size":43192},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_migrations.go","sha256":"7736e30a1d0c6e9584d9050cc6ebf8bfaf900d424f764ebe61af8ec8ddaec0c9","size":17407},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_physical_test.go","sha256":"2c125b6373f83467d542db45473cc79b888ed3a665e65ef6bf013655f461a7ba","size":14539},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_pooled_claim_read_cleanup_test.go","sha256":"0ec3060ed3c30a6327ec49b0291d5c761c20894986c9b6b1e1be384694312823","size":8912},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_claim.go","sha256":"8ddec89b4ca5702591bdf2060062016d7fb54264fc7df57af5ead1d161eb9de3","size":8301},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go","sha256":"953c87d23f80d5ecbd78507b1a81b2ce9f861c84eb811273e1a0f40c7d5242b4","size":20291},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_progress_schema.go","sha256":"132d8ab87f5658cab3477b9f6913538013ba922d4768192a96be960df7bbb149","size":30612},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_shape.go","sha256":"043cc868afe925e51df77cfca5246004f86feac6fd1dab17be4bb00138e175a7","size":2588},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_shape_test.go","sha256":"b8742a0aeb31b7777a357a6375eb140d7355afd9a69786316da550044ce00eb1","size":7230},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_store.go","sha256":"520dd8f39a32dea946b66620ed48058084ad255aefbc43b167c62b900822222f","size":63712},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_store_test.go","sha256":"c99e7659b1059431911557ba43ef7fa982e373bba939f610bd41ea0622cee96f","size":57339},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_guardrails_test.go","sha256":"a8f7938c6d5efd4d1600ade03bfca46d1cb89a7a46ea48b33b9590b79ce3b851","size":50444},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_format.go","sha256":"0a21803b03308332613481f89ce4b595512b31b073c56b31fe7d8000519c3beb","size":17326},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_hydration.go","sha256":"b5ff16b96178c45b53165ebb2bcbdc67991bb145276ca4a11a598f1430745b9c","size":28800},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_private.go","sha256":"20ea7b2682bf8be47f03924342fe87c0d8326b8fce7ed8afdfb57cec95a9f934","size":20253},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_private_test.go","sha256":"9a1ca86e26438c90a372b64cf50cb704c97444b48556bedfa891b1722aafbeef","size":39376},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/workstream_c_guardrails_test.go","sha256":"68f2fe4e31e5d862be161c3ba1071a511935b32e90cf9021755fe4dcb045fab5","size":297009}],"head":"f1aa8b934cc26c16a966a110c7b408abdaeadce7","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"e45e3bd85391191702673b2d40fc2d06d865503004e09a8094c2f6a7081fe0c4","upstream":"origin/trunk_dev"}
<END_APPENDIX_B>

## Appendix C — Exact v2 provenance recipe source

<BEGIN_APPENDIX_C>
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
import sys
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v2"


def fail(message: str) -> "NoReturn":
    raise SystemExit(message)


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env.update(
        {
            "LC_ALL": "C",
            "LANG": "C",
            "GIT_OPTIONAL_LOCKS": "0",
            "GIT_NO_LAZY_FETCH": "1",
            "GIT_TERMINAL_PROMPT": "0",
            "GIT_PAGER": "cat",
        }
    )
    result = subprocess.run(
        [
            "git",
            "--no-pager",
            "-c",
            "core.fsmonitor=false",
            "-c",
            "core.untrackedCache=false",
            *args,
        ],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


def validate_output_path(output_path: Path, repository_root: Path) -> None:
    if not output_path.is_absolute():
        fail("output path must be absolute")

    parent = output_path.parent
    parent_metadata = parent.lstat()
    if not stat.S_ISDIR(parent_metadata.st_mode) or stat.S_ISLNK(parent_metadata.st_mode):
        fail("output parent must be a nonsymlink directory")
    if parent_metadata.st_uid != os.getuid():
        fail("output parent must be owned by the current user")
    if stat.S_IMODE(parent_metadata.st_mode) & 0o022:
        fail("output parent must not be group- or world-writable")

    try:
        output_path.lstat()
    except FileNotFoundError:
        pass
    else:
        fail("output path already exists")

    repository_text = os.path.realpath(os.fspath(repository_root))
    output_text = os.path.realpath(os.fspath(output_path))
    try:
        common = os.path.commonpath([repository_text, output_text])
    except ValueError:
        common = ""
    if common == repository_text:
        fail("output path must be outside the repository")


def write_exclusive(output_path: Path, payload: bytes) -> None:
    flags = (
        os.O_WRONLY
        | os.O_CREAT
        | os.O_EXCL
        | getattr(os, "O_NOFOLLOW", 0)
        | getattr(os, "O_CLOEXEC", 0)
    )
    fd = os.open(os.fspath(output_path), flags, 0o600)
    try:
        view = memoryview(payload)
        while view:
            written = os.write(fd, view)
            if written <= 0:
                fail("short provenance-output write")
            view = view[written:]
        os.fsync(fd)
    finally:
        os.close(fd)

    metadata = output_path.lstat()
    if not stat.S_ISREG(metadata.st_mode) or stat.S_ISLNK(metadata.st_mode):
        fail("provenance output is not a regular nonsymlink file")
    if metadata.st_uid != os.getuid():
        fail("provenance output owner mismatch")
    if stat.S_IMODE(metadata.st_mode) != 0o600:
        fail("provenance output mode mismatch")
    if metadata.st_nlink != 1:
        fail("provenance output link-count mismatch")
    if metadata.st_size != len(payload):
        fail("provenance output size mismatch")

    read_flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_CLOEXEC", 0)
    read_fd = os.open(os.fspath(output_path), read_flags)
    try:
        observed = bytearray()
        while len(observed) <= len(payload):
            chunk = os.read(read_fd, min(1 << 20, len(payload) + 1 - len(observed)))
            if not chunk:
                break
            observed.extend(chunk)
    finally:
        os.close(read_fd)
    if bytes(observed) != payload:
        fail("provenance output byte mismatch")


if len(sys.argv) != 2:
    fail("usage: governed_execution_audit_patch_manifest_v2.py ABSOLUTE_OUTPUT_PATH")

repository_root = Path(git_text("rev-parse", "--show-toplevel"))
output_path = Path(sys.argv[1])
validate_output_path(output_path, repository_root)

head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    fail("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            fail(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()

write_exclusive(output_path, canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")
<END_APPENDIX_C>
