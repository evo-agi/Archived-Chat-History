## Select original replay plus durable progress — specify the contract before implementing it

**I agree with the recommended next source slice.** It addresses the actual integration gap: preserving one authenticated original while the same claim acquires a stable `RunRef` and advances through durable progress. The pooled-reader correction belongs inside that slice as its first implementation prerequisite—not as another standalone cleanup campaign. Pasted text

**The immediate next turn should write the owner contract and its documentation tests, not implement the entire proposed production scope.** The reconnaissance explicitly leaves the exact format, associated-data domain, successor invariants, and compatibility matrix to be frozen before implementation. Those are substantive decisions, not details to discover while editing the migration and durable service. Pasted text

I reviewed the complete report and reopened the pinned plan, record constructor, durable-service validation/recovery, reader implementations, and envelope framing. I did not execute the private diagnostic or inspect its retained source exports and raw logs.

## The two readers now have different, evidence-backed dispositions

| Reader | Supported disposition | Selected treatment |
|---|---|---|
| `loadClaim` | **Confirmed reachable cleanup/availability defect.** Cancellation left a transaction on a connection returned to the long-lived pool. Later fresh-context reads and CAS failed on the same store. | Repair before introducing the progress-bearing consumer. |
| `loadClaimFresh` | **No defect demonstrated in the tested function-owned lifetime.** Its private pool closed, failed operations invoked no authenticated callback, and later legitimate work succeeded. | Preserve its current implementation and callers in this slice. Retain its operational qualifications separately. |

The pooled diagnostic demonstrated unavailable subsequent work and a retained transaction—not a stale record returned successfully or an unsafe durable mutation. The fresh-reader result does not prove physical-close success under every failure or a bounded close duration. Pasted text

The distinction is supported by the source: `sqlite_store.go:260–324` shows a borrowed long-lived connection in one reader and a separately opened, zero-idle, function-owned pool in the other. Applying the same repair indiscriminately to both would disregard their different lifetimes. 

One important contract detail needs explicit treatment: **a failed recovery read must not erase uncertainty about the preceding write.** The report correctly observes that a read can emit the shared write-shaped COMMIT-unknown sentinel. Normalizing that read failure to unavailable must not turn an earlier uncertain mutation into known failure, known success, or permission to repeat an effect. The durable service’s current `reloadAfterUnknown` path makes that distinction especially relevant. Pasted text 

## The composition gap is real—not a missing wiring call

The pinned source confirms both obstacles identified by Codex:

`durable_record.go:506–529` constructs successors as codec 2 without carrying a replay descriptor. Its validator permits a replay descriptor only for codec 3’s restricted initial shape. Meanwhile, `durable_service.go:661–670` explicitly refuses codec 3. Simply removing one refusal would not preserve the original through later transitions.  

The next slice therefore needs a deliberate separation:

> **Immutable original:** caller/key identity, original intent and presence, bound plan and witness, sealed-object association, commitments, and original key identities.  
> **Mutable progress:** revision, phase, assignment, effect-intent and handoff facts, observations, reconciliation, latest-operation identity, and receipt—under the existing model and CAS rules.

`RunRef` is absent before assignment and immutable afterward. Advancing progress must not reseal the original, switch its keys, reconstruct it from current defaults, or silently drop its descriptor. This follows the report’s proposed single-domain composition rather than introducing another database or state machine. Pasted text

## Direction selected for the contract candidate

These are **next-slice design selections**, not claims about implemented behavior.

**Use one existing ES claim authority domain and the existing durable service.** Preserve caller/key uniqueness across scopes. An occupied key in an incompatible scope remains occupied; adding scope to the uniqueness key would create an unintended route around that protection.

**Introduce schema migration 4 and a distinct progress-bearing codec 4.** Preserve migration 1–3 literals and hashes, authentic historical codec-1/2 behavior, and codec 3’s immutable synthetic contract. Do not promote a codec-3 row into codec 4 or reinterpret its envelope. The new semantic scope selected for the draft is:

```text
synthetic_progress_nonoperational_v1
```

Its encoded value, payload/header versions, cryptographic domains, root compatibility, and refusal matrix must be specified exactly in the owner documents. Schema, row codec, and envelope versions remain separate version axes.

**Keep immutable-original authentication separate from mutable-progress authority.** The envelope must not acquire mutable revision, phase, or later-assigned values that would require resealing at every transition. Conversely, the documents must not suggest that authenticating the original cryptographically authenticates arbitrary later progress. The existing envelope already has explicit version, scope, association, and commitment fields; the new format needs an explicit compatibility/domain decision rather than permissive parsing. 

**Keep every new outcome fixture-scoped and effect-ineligible.** A synthetic accepted phase or receipt is not evidence of Nomad acceptance. The private composer must remain unreachable from production Submit, startup, staging, provider calls, or operational key loading.

The pooled-reader contract should reuse A1’s *observed boundaries*: cleanup ownership before BEGIN dispatch, caller-context semantic work, bounded request-independent rollback, expiry observation before self-cancel, exact disposal on uncertainty, and no ordinary return of a possibly transactional connection. It should remain local to `loadClaim`, preserving the completed A1/O2/C1/D1 paths and the disclosed physical-close limitations. 

## Why the next turn is limited to the contract

The report’s prospective path list is useful, but it is not yet a complete implementation allowance. A new codec and schema affect more than the main constructor and SQL literal: validators, hydration, migration-shape checks, deliberate-corruption fixtures, old-binary tests, and static inventories can all contain assumptions that **4 means unsupported**. Those dependencies should be identified together now, rather than through successive test failures and scope-widening stops.

There is also a specific compatibility-evidence requirement:

**The historical PB1/schema-2 probe cannot substitute for proving that the current schema-3 binary refuses schema 4.** The eventual implementation needs a separate, source-bound schema-3 probe from the pre-migration baseline. The old PB1 evidence retains its original purpose; it should neither be relabeled nor rebuilt from the new implementation. The reconnaissance already requires schema-3-binary refusal as part of migration isolation. Pasted text

This contract turn is not another open-ended reconnaissance or a separate documentation-publication campaign. It produces the concrete field, format, transition, migration, interface, error-precedence, and acceptance tables needed to implement the selected slice.

## Next Codex turn

Continue in the **same Codex conversation that produced this reconnaissance**. Close any remaining explorers, then let the foreground parent create the new standalone candidate:

```text
Checkout:
/Users/ds/Repositories/ES-Private-Replay-Progress-v1

Branch:
codex/private-replay-progress-v1

Base:
f1aa8b934cc26c16a966a110c7b408abdaeadce7
```

My current official-ref read still returns that base. Existing A1, O2, replay-custody, and original ES checkouts remain untouched. 

:chatgpt-content-reference{index="14"}[Download the private replay-progress owner-contract prompt](sandbox:/mnt/data/ES_Private_Original_Replay_Progress_Owner_Contract_20261118.md)

SHA-256:

```text
3080c8755bab9352dd85aa43947423bf945623fe37fa3c9ef63f778330ab51b9
```

The prompt embeds the **complete supplied reconnaissance and exact v2 provenance recipe**. I verified both embedded payloads byte-for-byte.

### This turn’s write scope

Only these five existing files may change:

```text
PLANS.md
.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md
.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md
.docs/execution_lifecycle/es_execution_admission_model.md
docs_contract_test.go
```

The plan records PR #10’s completed source publication alongside the next selection. The owner documents distinguish current behavior from the proposed contract. Documentation tests check that selection without pretending the new codec, migration, or composer already exists.

Validation is limited to formatting, whitespace, and the relevant documentation-contract selectors, with immediate source/index/untracked checks. **No product repair, migration execution, diagnostic rerun, full-suite replay, PB1 rebuild, staging, commit, push, or PR change is authorized.**

Expected endpoint:

```text
ES_PRIVATE_REPLAY_PROGRESS_OWNER_CONTRACT_READY_FOR_REVIEW
```

The draft remains unstaged and uncommitted. After architectural review, implementation can continue in the same candidate in this order:

```text
pooled-reader prerequisite
→ versioned format/schema and migration preservation
→ durable successors and private composition
→ integrated restart/concurrency/uncertainty validation
→ fresh independent audit of the complete slice
```

Those are implementation phases, **not automatically separate commits or PRs**.

## What remains later

The report’s disabled-by-default ingress, state/key provisioning, authenticated SPIFFE selection, public response vocabulary, fake-provider handoff proof, and separately authorized native execution form a useful continuation plan. Their exact config spelling, host/profile choice, receipt-recovery policy, and provider acceptance predicate remain **proposals requiring later owner contracts**, not permissions conferred by this source slice. Pasted text

That keeps the critical path focused: join the authenticated original to durable progress, repair the reader that this composition actually needs, and preserve the boundary between fixture evidence and real execution.

**Sources:** Complete attached reconnaissance; pinned post-PR #10 plan, owner rules, durable record/service, readers, and envelope source; project snapshot inspected as baseline material. Private diagnostic artifacts were not independently rerun.

**Confidence:** Source grounding **0.98**; reported diagnostic interpretation **0.95**; selected sequencing **0.97**. Correctness of the new format, migration, and composition remains unvalidated until the contract is reviewed and the implementation independently audited.
