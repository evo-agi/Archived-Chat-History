# Execution Substrate — Private Replay Progress Contract Reconciliation
# Revision closure and exact five-file review delivery

## Objective and endpoint

Continue the same foreground Codex conversation that produced Appendix A,
rooted at:

    /Users/ds/Repositories/ES-Private-Replay-Progress-v1

Keep the existing integrated slice: authenticated immutable original plus
fixture-only durable progress in one ES SQLite domain, with the pooled
`loadClaim` correction as the first later implementation prerequisite.

Do NOT begin product implementation. This turn revises only the same five
owner-contract/documentation-test files and supplies their complete exact bytes
for architectural review. It is not an independent audit, a new reconnaissance
programme, a standalone documentation PR, or permission to publish source.

Resolve two concrete owner-contract issues:

1. Reconciliation evidence must not strand a codec-4 attempt merely because
   nonterminal evidence was recorded. Reconcile the draft's set-once/current-
   phase interpretation with validated first-dispatch recovery and subsequent
   terminal resolution. Name the inherited contract/source mismatch; do not
   silently copy it into the new codec or rewrite legacy semantics.
2. Shared object-count-plus-create serialization is a newly selected
   transaction/filesystem boundary. Specify its owners, exact lifetime,
   failure dispositions and cross-scope participation before coding it.

Also make the baseline schema-3 probe's build root unambiguous, keep the SQL
versus durable-service authority split explicit, and deliver the actual
five-file patch rather than only its report and local links.

Successful endpoint:

    ES_PRIVATE_REPLAY_PROGRESS_CONTRACT_RECONCILED_READY_FOR_REVIEW

This means the revised document candidate and exact review packet are ready
for ChatGPT's architectural decision. It does not accept the new format,
implement schema/codec 4, fix the pooled reader, or authorize a later effect.

## Posture and effects

The foreground parent is the sole writer. Close any still-active previous
explorers before editing. No independent audit or writer subagents in this
turn. Read-only source inspection is permitted within the selected ES checkout
and its pinned committed objects. Do not broaden to other GE repositories.

Authorized effects are:

- changes within the five existing paths below;
- bounded documentation-test validation;
- new private external provenance, review exports, and a delivery ZIP.

Not authorized: product source/behavioral-test edits, migration execution,
reader diagnostics, old-binary compilation, full-suite replay, dependency
installation/download, live services or host contact, staging, commits,
fetch/reset/rebase of an existing checkout, push, PR changes, merge, runtime
wiring, deletion of prior evidence, or operational public reliable Submit.

Use the existing checkout. Do not create another branch or clone. Ordinary
engineering iterations of the document candidate are permitted and retained.
A final freeze failure stays visible; a corrected run gets its own source and
run identity. Do not invent a one-shot calibration campaign for this task.

## Exact opening target

    branch: codex/private-replay-progress-v1
    upstream: origin/trunk_dev
    origin: git@github.com:evo-agi/Execution-Substrate.git
    HEAD: f1aa8b934cc26c16a966a110c7b408abdaeadce7
    sole parent: fb9ae55797d9fcc02863c23fe8d3e43d16eac542
    HEAD tree: 8dd27f9acba98ed70d93736bdef8300ef1aba53f
    HEAD leaves: 427
    index: equals HEAD
    worktree: exactly five unstaged tracked modifications

Opening candidate canonical manifest:

    4857bbf5f1572dbfb78c221a13d657107bcfbf6690d830b7769cc35465bdb0da

Opening tracked-diff SHA-256:

    8bf2dc2d8ae5027b8b21b53d7cd51598d07c5b2c5a744933a572338f894aa9bf

Appendix B contains the exact 1,331 canonical bytes. Appendix C contains the
exact v2 recipe, 7,275 bytes, SHA-256:

    c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca

Reproduce Appendix B twice before editing and compare all five complete files,
not just diff text. Verify the other 422 tracked paths and modes against HEAD.
Require zero staged, unmerged, ordinary-untracked and ignored paths. If that
opening candidate differs, stop with the exact discrepancy; do not rebaseline.

An optional read-only official-base observation can be recorded once at opening
and closeout. Remote movement is a publication/reconciliation observation, not
by itself proof that the pinned local patch changed. Never change the selected
base or reset this candidate in response.

## Evidence basis and inspection limit

Read the complete Appendix A. Its uploaded transport bytes are 40,665 bytes,
SHA-256:

    472497a77c677bb25e94df6ceb76b42b0b5861dfe15291e9e8bb87a30ba9ea6d

The preceding contract evidence root is:

    /Users/ds/Repositories/ES-Private-Replay-Progress-Contract-20261118-8o8gnc8g

Material artifacts:

    opening-inventory.json
    v3-closeout-checkpoint.json
    v3-final/owner-contract-review.md
    v3-final/artifact-index.json
    v3-final/manifest-a.json
    v3-final/manifest-b.json
    v3-validation-freeze.json
    v3-go-test-run.json

The reported v3 index SHA-256 is:

    31d2900bfde6f6da19e3bb53a843b6c16352eae31802a6f0f1683a98540d17af

Authenticate material artifacts actually used and report the exact subset.
Do not rehash every prior evidence universe or rerun the already bound
characterization. Reports are evidence, not repository or runtime authority.

ChatGPT has read the complete transport report and the pinned base source, not
the five uncommitted file contents. A source path and hash are not a substitute
for those contents. This turn's delivery must close that precise access gap.
If the detailed existing candidate already resolves part of a report-level
ambiguity, identify the exact text and correct the report; do not introduce a
redundant or contradictory redesign merely to satisfy a summary finding.

## Same exact write scope

1. PLANS.md
2. .docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md
3. .docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md
4. .docs/execution_lifecycle/es_execution_admission_model.md
5. docs_contract_test.go

No addition, deletion, rename, type or mode change. All 422 other tracked
leaves remain byte- and mode-identical to HEAD, including production Go, SQL,
module pins, behavioral tests, scripts, configs and examples.

Keep the source/target distinction prominent: current source is schema 3 with
historical codecs 1/2 and immutable codec 3. Proposed schema 4, codec 4 and
`synthetic_progress_nonoperational_v1` are not implemented.

Preserve the already selected essentials unless an explicit conflict is
reported:

- one claim table/domain and global caller/key occupation across codecs/scopes;
- one immutable authenticated original, one assigned run/attempt;
- existing seven phases, existing durable service, expected-revision CAS;
- distinct scope 2 and exact format tuple, no codec-3 promotion or resealing;
- all phases and receipts remain fixture-only and effect-ineligible;
- migration 1–3 literals/hashes and authentic legacy rows unchanged;
- original AEAD does not authenticate arbitrary later progress;
- no current-default or active-key resolution on an authenticated replay hit;
- exact own-write proof remains full expected-record equality;
- prior write uncertainty survives a failed recovery read;
- A1/O2/C1/D1 and the current `loadClaimFresh` lifetime are not reopened;
- no public structural reliable request, staging or provider path is enabled.

## R1 — Reconciliation must describe observations without trapping progress

### Verified baseline and report conflict

Read these exact pinned source/owner sections and their related tests, not only
Appendix A:

    .docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md
      §8, especially baseline lines 442–506:
      Validated No-Dispatch Evidence permits the first same-RunRef dispatch
      after fresh revision/uncertainty checks and known marker COMMIT.

    es/admission/internal/reliablesubmit/durable_record.go:351–430
      existing fact compatibility ties reconciliation NoDispatch to assigned
      with no marker/provider; Pending to pending; Ambiguous/Inconsistent to
      ambiguous; terminal reconciliation to its corresponding terminal phase.

    es/admission/internal/reliablesubmit/durable_service.go:377–417
      reconciliation is set once; a different subsequent tuple is refused.

    es/admission/internal/reliablesubmit/durable_service.go:422–499
      terminal operations clone the existing reconciliation fact when
      constructing an accepted/not-accepted successor.

    es/admission/internal/reliablesubmit/durable_service_test.go
    es/admission/internal/reliablesubmit/durable_record_test.go
    es/admission/internal/reliablesubmit/sqlite_migrations.go
    es/admission/internal/reliablesubmit/sqlite_replay_schema.go

The draft report says the reconciliation tuple is set once and that recorded
NoDispatch precludes a later dispatch marker. It also carries forward
Pending/Ambiguous/Inconsistent phase compatibility. This exposes two concrete
sequences which the future contract must settle rather than hide behind the
word 'compatible':

    assigned + committed intent
      -> validated no-dispatch reconciliation
      -> first same-run dispatch marker

    pending/ambiguous + nonterminal reconciliation
      -> newly established positive accepted/not-accepted evidence
      -> terminal result for the same run

The first is expressly refused by the report. For the second, the pinned
set-once tuple plus current-phase compatibility would invalidate a terminal
successor unless the new codec explicitly changes how that earlier observation
is carried. This is a static contract/model concern, not a new executed product
failure or a reopening of the accepted A1 implementation.

### Architectural direction for this revision

Do not freeze these dead ends into codec 4. The new source-only composition
must represent both sequences with typed fixture evidence, without performing
a real dispatch. The eventual runtime safety predicate is not reduced to a
boolean fixture marker.

Keep the existing seven-phase model and one row. Explicitly refine codec-4
handling of nonterminal reconciliation as an observation of a particular
validated attempt state, not a permanent assertion that no stronger fact may
subsequently exist. Keep terminal outcomes/receipts immutable. Freeze ONE
concrete representation and transition table in the candidate, not a menu of
alternatives or an implementation-time TBD.

Prefer retaining a nonterminal observation as historical evidence when a later
validated transition advances the same attempt. If the exact existing shape
instead requires bounded supersession, spell out the permitted changes and
what is no longer retained; do not claim history-wide evidence from a latest-
record design. Do not add a new history table, second phase algebra, reset,
second attempt, delete/reinsert, or RunRef reassignment. If neither treatment
can satisfy the required sequences within this direction, stop with a focused
owner conflict rather than silently choosing a larger architecture.

The contract must state:

1. How every reconciliation kind relates to the phase WHEN RECORDED and to
   legal later phases. Distinguish current decision facts from retained
   earlier observations; don't silently reinterpret old rows.
2. Exact tuple preservation or replacement for each relevant operation,
   including provider-observation compatibility and terminal operation 8/9.
3. NoDispatch observation alone never authorizes dispatch. First-marker
   creation requires the complete validated current no-dispatch predicate,
   same original and RunRef, expected revision, no prior marker/provider
   evidence, and no unresolved relevant write. Its known commit is a separate
   future-effect prerequisite. This slice performs no effect.
4. Once a dispatch marker exists, it is never cleared/replaced and no earlier
   NoDispatch fact can authorize a second send. Absence in a failed/stale read
   is not positive no-dispatch proof.
5. An earlier pending/ambiguous/inconsistent observation must not block later
   stronger, positively authenticated terminal evidence solely by being
   present. It must not itself supply that terminal evidence either.
6. Exact latest-operation replay, changed-input conflict and stale revision
   rules remain. The same claim cannot acquire a fresh attempt or mutation
   simply to escape uncertainty.
7. Legacy codec-1/2 and immutable codec-3 behavior remains unchanged. Any new
   interpretation is named and selected for codec 4. Document the older
   contract/source tension without claiming the legacy implementation was
   repaired by this documentation turn.
8. Go/durable service remains the semantic transition writer. SQL constrains
   row shape, immutability, CAS and permitted storage deltas, not cryptographic
   original verification or an independently authoritative second phase
   machine. Map each check to its owner.

Supply complete before/after field examples for the two sequences, plus the
negative cases: unknown marker COMMIT, stale predecessor, existing marker,
changed original, wrong run, contradictory terminal evidence, and a late replay
of the old reconciliation mutation. They are document examples, not new product
fixtures or executable model substitutes.

Add exact prospective acceptance cases under the selected transition and
concurrency tests. They must include restart between reconciliation and the
next transition, with no additional actual effect. Update the prospective path
map if codec-specific compatibility checks/tests need further named files;
that map is still not code-write permission this turn.

## R2 — Explicit count/create transaction and cross-scope budget ownership

### Why the new contract needs a complete lifecycle

At the pinned base, `PublishSealedSynthetic` in
`es/admission/internal/reliablesubmit/replay_custody_file.go:399–435`
checks object budget then performs exclusive Openat before permit consumption
and Seal. That count/create sequence is not enclosed in a SQLite transaction
at that call site.

The draft selects using the SQLite writer lock to serialize BOTH selectors'
object count plus exclusive create, with release before permit consumption and
Seal. The SQLite lock mechanism already exists, but this use and protected
critical section are new. Do not label the entire allocator protocol as
already implemented or as covered by earlier A1/O2 acceptance.

### Required owner decision table

Freeze the smallest complete synchronous allocator protocol, including:

- the owning helper and every scope-1/scope-2 producer that must participate;
- the exact checked connection and BEGIN-dispatch ownership;
- what counts as an occupied slot/object name, including inert files/orphans;
- how count plus exclusive create is serialized across separate handles and
  processes using the SAME database/root domain;
- exact parent/descriptor identity checks and collision refusal;
- how the no-database-mutation critical section ends and how its end is
  confirmed independently of canceled semantic work;
- observed expiry and error handling BEFORE self-cancel;
- uncertain BEGIN/end, failed disposal, bounded rescue and withholding;
- file-descriptor ownership on every return;
- the exact point permitting later permit consumption, key checks and Seal;
- the behavior when a filesystem entry exists but the database transaction's
  end cannot be confirmed.

A database rollback does NOT remove an already created filesystem object.
The contract must preserve inert retention, no deletion/adoption/reuse, and
capacity accounting for that object. Withhold a usable publication result and
Seal on unconfirmed allocation cleanup. An already issued permit follows its
burn/no-refund semantics; neither failed allocation nor migration replenishes
durable grant budget. Keep the database lock out of Seal, general material
acquisition, external callbacks and later claim/CAS operations. No background
worker, retry loop, new lock file or registry is selected.

For each shared bound, identify the enforcing transaction/check and its exact
claim strength:

    four custody-bearing claim slots across codecs 3/4
    32 object names, including retained orphans, across both selectors
    32 aggregate durable reservations
    2^32 per-envelope-key reservations
    16 MiB database/sidecar budget

Distinguish a failure-detecting budget check from a proved hard physical ceiling
through every possible OS/write/close failure. Do not invent a stronger claim
than the selected mechanism establishes.

Sharing the fixture root means scope-1 publication must participate in the
same serialized count/create mechanism; merely locking the new scope-2 path
would not establish a cross-scope bound. Document this narrow future scope-1
allocator change explicitly, while preserving codec-3 format, immutable rows,
existing key/grant semantics and `loadClaimFresh` caller/lifetime behavior.
Retain the requirement to close older-version fixture handles before upgrade;
no live rolling-upgrade or mixed-old-binary writer guarantee is selected.

Add prospective tests to the implementation map, including:

- two handles/processes and two selectors near the final shared object slot;
- an allocation failure after exclusive create but before confirmed release;
- cancellation and ambiguous transaction-end response;
- exact descriptor and pool disposition before subsequent legitimate work;
- orphan remains counted and no refund/Seal/claim occurs;
- the normal publisher still reaches the unchanged custody verification path.

Keep tests at the specific resource boundary. No process-wide FD-count oracle,
physical-close fault platform, or old socket-calibration campaign is required.
No such test runs in this documentation turn.

## R3 — Build-origin and delivery precision, not another product scope

Retain the distinct historical PB1 and current schema-3 probe purposes.
Correct/expand the prospective build sequence so a reviewer can see the actual
working directory and bound inputs, e.g.:

    (
      cd "$SCHEMA3_SOURCE"  # authenticated export of f1aa8b... tree 8dd27f...
      "$GO" test -mod=readonly -overlay "$SCHEMA3_OVERLAY" -c \
        -o "$SCHEMA3_PROBE" ./es/admission/internal/reliablesubmit
    )

`SCHEMA3_SOURCE` is a complete pinned external source export; the overlay adds
only the named test harness. It must not silently compile schema-4 candidate
production inputs. Bind every compiled source/embed/module input, the overlay
mapping, helper bytes and binary. The later schema-4 target is separate and
exists before the old opener is invoked. Before/after verification must not
itself migrate the target. Paths and build-environment reproducibility limits
are reported separately from source identity.

Preserve the existing schema-2 PB1 binary and its authentic schema-3 fixture;
no historical rebuild or relabeling is selected. This turn does not compile or
run either probe.

The report's method table is useful, but the review delivery must include the
exact candidate contract sections defining the opaque types, typed verifier
view, one synchronous borrow, issuer/rowid/original binding, cancellation and
no-escape behavior. Check those sections for unbound verified flags or general
plaintext/store access. Do not invent missing signatures in the report or
claim ChatGPT has inspected those bytes before the packet is delivered.

## Documentation validation

Preserve repository guidance in AGENTS.md and the current selected plan. Update
the owning tables first and their existing documentation assertions afterward.
This remains one integrated source slice; no separate docs commit/PR or reader-
only workstream is selected.

Use the pinned Go 1.26.5 toolchain and existing offline module cache. Keep the
known-good Python 3.13/OpenSSL 3 environment without installation. Set:

    GOTOOLCHAIN=local
    GOPROXY=off
    GOSUMDB=off
    GOWORK=off
    GOFLAGS=-mod=readonly
    CGO_ENABLED=0
    GOTELEMETRY=off
    GOMODCACHE=/Users/ds/go/pkg/mod
    GIT_OPTIONAL_LOCKS=0
    GIT_NO_LAZY_FETCH=1
    GIT_TERMINAL_PROMPT=0
    PYTHONDONTWRITEBYTECODE=1

Run Python with -B, and copy authenticated verifier bytes into the NEW evidence
root before executing them. Never import from prior evidence directories.
Use fresh external GOCACHE/GOTMPDIR/TMPDIR, outer umask 077, Go-child umask 027.
Do not gate on volatile timestamps/inode allocation or chmod shared parents.

After the final document freeze, run the same four commands once, serially:

```sh
GO=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go
GOFMT=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/gofmt
"$GO" version
"$GOFMT" -d docs_contract_test.go
git --no-pager diff --check
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateOriginalReplayProgressContractSelection|TestReliableSubmitPersistenceAndConcurrencyADRDocsContract|TestSubmitIdempotencyCorrelationAndRecoveryDocsContract|TestReliableSubmitPureModelDocsAndSourceContract|TestReliableSubmitPublicOptInAndVersioningDocsContract|TestReliableSubmitContractAdapterFoundationDocsAndSourceContract|TestReliableSubmitBindingProducerDocsContract|TestIntegratedAcceptanceGateDocumentationIsConsistent|TestIntegratedCandidateStatusSeparatesCAndT)$' .
```

Do not run ./..., migrations, behavioral diagnostics or old probes. Require
all selected parents to run and no new capability skip. Check the revised
assertions do not claim schema 4 or codec 4 already exists in production, nor
freeze the identified contradiction into a required phrase.

Immediately after each command, bind an executed integrity observation:
unchanged HEAD/branch/upstream/index; only the allowed tracked edits; all 422
other tracked files equal HEAD; empty ordinary-untracked and ignored lists:

    git ls-files --others --exclude-standard -z
    git ls-files --others --ignored --exclude-standard -z

Identical state/checkpoint hashes are permitted; each observation needs its
own executed command record. Preserve failed generations with their true
source/environment identity, never silently rerun into a first-pass claim.

## Exact review packet and inline report

Use a new unique private external root, for example:

    /Users/ds/Repositories/ES-Private-Replay-Progress-Contract-Revision-20261118-<random>

Root/directories 0700, retained reports/evidence 0600. Source exports preserve
ordinary 0644 source mode. Never overwrite an earlier evidence root.

At final closeout:

1. Run Appendix C twice to different absent external paths. Require identical
   canonical bytes and publish the complete new canonical manifest inline.
2. Export the COMPLETE five changed candidate files, preserving relative paths,
   mode, byte count and SHA-256. No reconstruction from prose or excerpt.
3. Export the complete HEAD-to-candidate full-index binary diff with no external
   diff/textconv/rename transformations, and bind its exact digest.
4. Export the complete delta from the opening five-file candidate to the
   revised candidate, with a short per-finding explanation.
5. Include a small README identifying base, old/new manifests, exact scope,
   current-vs-target status and inspection/validation limits.
6. Package those five files, both diffs, manifest and per-entry delivery
   inventory into one safe ZIP in the external evidence root. No .git, caches,
   compiled objects, databases, live keys, raw private diagnostics, secrets or
   unrelated source files. Do not chmod or include old evidence roots.
7. Verify ZIP paths are unique, relative, non-traversing regular-file entries;
   reread exported file bytes and compare every source export to the candidate.
   Record archive byte count and SHA-256. The archive is review transport,
   not acceptance or source authority.
8. Provide a file attachment when the Codex surface supports it. Otherwise give
   the precise local ZIP path for upload. The full human-readable review report
   must still be inline; the ZIP supplies exact source bytes, not a substitute
   for the report.

The inline report must include the complete revised reconciliation table,
allocation lifecycle/budget table, updated path/acceptance map, exact commands
and results, byte/mode scope, complete manifest, archive identity, unresolved
seams, skipped validation, and explicit current/target distinction. Cite actual
candidate path:line ranges for every substantive decision. Give one concrete
contract, not unresolved alternatives. If a requested decision remains
unsettled, report the precise conflict rather than readiness.

State what changed in response to R1/R2/R3 and what was already defined in the
full candidate but missing/ambiguous in the report. Preserve the original
v3 report and its passed documentation results for their original bytes.

Do not claim independent acceptance, product implementation, native installed-
source qualification, or runtime permission. If the complete safe human report
cannot be delivered inline, use only REPORT_INLINE_BLOCKED, not a simultaneous
readiness verdict.

Ordinary successful closeout ends with:

    ES_PRIVATE_REPLAY_PROGRESS_CONTRACT_RECONCILED_READY_FOR_REVIEW
    PRODUCT_SOURCE_BYTES_UNCHANGED
    POOLED_LOADCLAIM_DEFECT_NOT_REPAIRED_IN_THIS_TURN
    LOADCLAIMFRESH_BEHAVIOR_PRESERVED
    SCHEMA4_AND_CODEC4_NOT_IMPLEMENTED
    INDEPENDENT_ACCEPTANCE_NOT_PERFORMED
    STAGING_NOT_PERFORMED
    COMMIT_NOT_PERFORMED
    PUSH_NOT_PERFORMED
    PRS_NOT_MODIFIED
    EXISTING_SOURCE_CHECKOUTS_NOT_SYNCHRONIZED
    RUNTIME_WIRING_NOT_PERFORMED
    PUBLIC_RELIABLE_SUBMIT_NOT_ENABLED

## Stop conditions

Stop without broadening effects on opening candidate mismatch, a required edit
outside the five paths, needed production behavior/migration execution,
contradictory owner authority, an inability to preserve legacy/codec-3 behavior,
unsafe export material, failure of the final documentation validation, or
failure to produce deterministic exact provenance. Record source/transport
mismatches separately from remote movement or tooling failures. Resolve normal
in-scope drafting iterations before final freeze; do not use this turn to
silently implement around an unresolved design decision.


---

# Appendix A — Complete supplied owner-contract report

Exact payload: 40665 bytes; SHA-256 `472497a77c677bb25e94df6ceb76b42b0b5861dfe15291e9e8bb87a30ba9ea6d`.
The payload starts immediately after the BEGIN delimiter newline.
Extract exactly the stated byte count; framing newlines are not payload.

<BEGIN_OWNER_CONTRACT_REPORT>
The five-file owner-contract candidate is ready for architectural review. All nine selected documentation test parents and eight subtests passed, with zero failures or skips. The patch remains unstaged and uncommitted. All 422 other tracked files match the pinned base byte-for-byte and mode-for-mode.

## Source and evidence

| Item | Verified identity |
| --- | --- |
| Standalone checkout | `/Users/ds/Repositories/ES-Private-Replay-Progress-v1`, with its own `.git` common directory and object store |
| Origin and tracking | `git@github.com:evo-agi/Execution-Substrate.git`, branch `codex/private-replay-progress-v1`, upstream `origin/trunk_dev` |
| PR #10 squash and trunk | `f1aa8b934cc26c16a966a110c7b408abdaeadce7` at opening and closeout. No remote drift observed. |
| Sole parent | `fb9ae55797d9fcc02863c23fe8d3e43d16eac542` |
| Complete tree | `8dd27f9acba98ed70d93736bdef8300ef1aba53f`, 427 leaves |
| Preserved A1 source | `fd2115ca8f44a615627adb08926896a1e052dc30`, same tree and a separate commit |
| Opening inventory | `7d5c60054418e58fc2f3014e8f978845e07dd17ad89f617b0ad6db8233b16ccf` |
| Final integrity checkpoint | `5b03c815d6233735e88b0a96de970ed8cf75c4959ee0ec3ab1bbb5960b674648` |
| Final private artifact index | `31d2900bfde6f6da19e3bb53a843b6c16352eae31802a6f0f1683a98540d17af` |

The opening inventory binds each committed path, Git mode, blob ID, byte count and SHA-256. All five edits are ordinary files with disk mode `0644` and Git mode `100644`. The index equals `HEAD`, with zero staged, unmerged, untracked or ignored paths. [Opening inventory](/Users/ds/Repositories/ES-Private-Replay-Progress-Contract-20261118-8o8gnc8g/opening-inventory.json) · [Final checkpoint](/Users/ds/Repositories/ES-Private-Replay-Progress-Contract-20261118-8o8gnc8g/v3-closeout-checkpoint.json) · [Private review packet](/Users/ds/Repositories/ES-Private-Replay-Progress-Contract-20261118-8o8gnc8g/v3-final/owner-contract-review.md) · [Artifact index](/Users/ds/Repositories/ES-Private-Replay-Progress-Contract-20261118-8o8gnc8g/v3-final/artifact-index.json)

The supplied Appendix A SHA-256 was `48690bf07ef258752fda89213d0f888df2233f1f419fa11992058f29e8526bfb`. The authenticated private report and its index were `c473578e8439cf4dcb79b8b42fb627cdea51c2a9a287a74b1a2d7261157629af` and `9ee2b802f36a6cee0aedea2558f2737bb9dcdf75f9d6e643d17ebbb4fbcc5be1`. The pristine inventory, diagnostic freeze, instrumentation diff, complete diagnostic test and diagnostic stdout matched the five hashes in the brief. The underlying diagnostic supplied 12 passing observation identities and was not rerun. [Evidence authentication record](/Users/ds/Repositories/ES-Private-Replay-Progress-Contract-20261118-8o8gnc8g/evidence-authentication.json)

## Selected scope and authority

Current source runs schema 3 with historical codecs 1/2 and the immutable codec-3 scope `synthetic_nonoperational_v1`. The proposed bounded extension joins authenticated original replay to durable progress in the same ES SQLite domain. Schema migration 4 and claim codec 4 are separate version axes. Scope `synthetic_progress_nonoperational_v1` is fixture-only, runtime-unwired and effect-ineligible at every phase, including synthetic accepted and receipt states. All codecs share the same caller/key occupation. Each row holds one original and one attempt. [Plan](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/PLANS.md:5) · [Admission classification](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/es_execution_admission_model.md:603)

Admission interprets typed intent and recomputes PB1. Custody authenticates the sealed original and validates keys and grants. The existing durable service is the sole semantic writer of progress, with SQLite enforcing persisted constraints. Public structural reliable-request refusal, unkeyed Submit, authentication before existence disclosure, conflict privacy and bounded CP compatibility remain current invariants. ES retains admission and runtime fact ownership. Nomad retains accepted-execution lifecycle authority. Coordinator durable programme progression remains separate. IM and MA are supplementary, and Bridge does not establish run truth. Operational ingress and SPIFFE selection, state-path and key loading, live image and host qualifications, first-effect authorization, creation-only provider registration, correlated recovery and public responses remain later decisions. [Admission classification](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/es_execution_admission_model.md:603)

## Pooled reader prerequisite

The real-SQLite diagnostic exposed a retained transaction after cancellation following real BEGIN, cancellation after successful SELECT and a modeled error after real BEGIN. Later same-store reads and CAS failed, and a nested-BEGIN probe confirmed the retained transaction. The diagnostic showed no stale successful read or durable mutation. Its successful exit meant the observation assertions held. In the tested `loadClaimFresh` cases, the function-owned zero-idle pool closed, no failed authentication callback ran and later codec-3 discovery and verification succeeded. Physical-close failures and universal close or latency guarantees remain unproved. The existing read COMMIT error supplies no evidence of a write. [Reader evidence and contract](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1292)

| Pooled `loadClaim` exit | Selected disposition |
| --- | --- |
| Invalid input | Existing invalid classification and zero record. No acquisition. |
| Canceled before acquisition or BEGIN dispatch | Fixed read unavailable and zero record. An acquired connection with no dispatch can return normally. |
| Acquisition failure with live context | Preserve the safe acquisition classification. Observed cancellation takes precedence. |
| BEGIN dispatched, response unconfirmed | Disable ordinary release and dispose of that exact connection. Fixed read unavailable. No rollback or read retry. |
| Known BEGIN, before COMMIT attempt | Use a private request-independent five-second rollback context on the same connection. Sample the rollback response and `cleanupCtx.Err()` immediately, before self-cancel. |
| Rollback error, observed expiry even with nil response, or uncertainty | Override ordinary outcomes with a zero record and read unavailable. Disable ordinary release and dispose of the exact connection. |
| Confirmed rollback | Preserve safe not-found or corrupt classifications when the request is live. Observed request cancellation yields read unavailable. |
| COMMIT attempted, response unconfirmed | Dispose of the exact connection. Return zero record and read unavailable. No subsequent rollback or semantic retry. |
| Confirmed read COMMIT | Normal release after a known transaction end. Return the validated record only if the final context observation is live. |

Disposal allows one synchronous rescue with the real primitive on the same connection. If both responses remain unconfirmed, withhold ordinary close and pool return. Confirmed discard proves quarantine within the pinned pool behavior. Physical close and universal unblock time remain outside that proof. The local repair excludes `loadClaimFresh`, its callers and pool lifetime, shared mappings and helpers, and A1/O2/C1/D1. Scope 2 uses the repaired pooled reader. An earlier write’s unresolved outcome survives a failed read. [Reader exit table](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1292)

## Immutable original and evolving progress

`B32` denotes exactly 32 BLOB bytes. Times are positive UTC Unix nanoseconds in signed SQLite INTEGERs. SQL enforces storage class, nullability, ranges, joint shape and allowed deltas. Go checks raw persisted enums before narrowing, preserves NULL versus empty, validates typed values and recomputes the evidence it owns. This is the complete physical field set for codec 4. [Owner field table](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1338)

| Fields | Type, initial value and evolution | Evidence owner |
| --- | --- | --- |
| `claim_rowid` | SQLite-generated INTEGER PK, fixed | SQLite, exact private row identity |
| `caller_ref`, `submit_key_ref` | B32 each, jointly unique, fixed | Admission safe identity, matched against header and payload |
| `plan_binding` | BLOB 1–256, fixed | Admission PB1 recomputation |
| `witness_resolved_mask`, `witness_inapplicable_mask` | INTEGER 0–16383 each, disjoint, union 16383, inapplicable mask disjoint from 7935, fixed | Admission’s complete 14-category witness |
| `created_at_unix_ns` | Creation timestamp, fixed | Durable service clock |
| `codec_version`, `replay_scope`, `intent_format` | INTEGER `4, 2, 1`, fixed | Custody dispatch and admission intent grammar |
| `intent_commitment`, `context_commitment` | B32 each, fixed | Custody domain-specific HMAC recomputation |
| `envelope_wrapper_format`, `envelope_payload_format`, `envelope_algorithm` | INTEGER `2, 2, 1`, fixed | Custody strict format match |
| `envelope_ref` | Exact 75-byte TEXT path, unique when non-NULL, fixed | Custody object and descriptor association |
| `envelope_size`, `envelope_sha256` | INTEGER 29–2,097,152 and B32, fixed | Custody actual sealed size and digest |
| `binding_key_id`, `envelope_key_id` | Distinct case-sensitive ASCII TEXT IDs, 1–64 bytes, registry FKs, fixed | Custody key ID, purpose, state and envelope association |
| `binding_key_fingerprint`, `envelope_key_fingerprint` | Distinct B32, fixed | Custody registry match and shared fingerprint domain |
| `phase_tag` | INTEGER 1–7, starts at 1 or 2 | Existing durable phase model |
| `run_ref`, `assigned_at_unix_ns` | B32 and time, initially NULL, both required at phases 3–7 and fixed once assigned | Durable service, one fixture run |
| `receipt_ref` | Initially NULL, B32 only at phase 6 and then fixed | Durable service, atomic fixture acceptance |
| `revision`, `updated_at_unix_ns` | Revision starts at 1 and increments one without overflow. Update time starts at creation and is nondecreasing. | Durable service clock and CAS |
| `last_mutation_ref`, `latest_operation_kind`, `latest_operation_input_digest` | B32, INTEGER 1–9, B32. Start with random mutation, op 1 and derived digest. Advance together. | Durable service, full predecessor-bound latest-operation descriptor |
| `effect_intent_ref`, `effect_intent_at_unix_ns` | B32 and time, initially both NULL, set once by op 3 | Durable fixture intent |
| `staging_ref`, `staging_at_unix_ns` | B32 and time, initially both NULL, set once by op 4 | Durable fixture staging evidence |
| `dispatch_ref`, `dispatch_at_unix_ns` | B32 and time, initially both NULL, set once by op 5 | Durable fixture marker |
| `provider_observation_kind`, `provider_observation_ref`, `provider_observation_at_unix_ns` | INTEGER 0–5, B32 and time. Starts at `0/NULL/NULL`. Ops 6, 8 and 9 supply the tuple. Only terminal ops 8/9 may replace a nonterminal observation. | Durable service verifies run, evidence and resulting phase |
| `reconciliation_kind`, `reconciliation_ref`, `reconciliation_at_unix_ns` | INTEGER 0–6, B32 and time. Starts at `0/NULL/NULL`. Set once by op 7. | Durable service verifies association and joint facts |
| `expires_at_unix_ns`, `retention_state`, `unavailable_at_unix_ns`, `unavailable_reason` | Fixed `NULL`, INTEGER `1`, `NULL`, empty TEXT | Durable service enforces permanent occupation. No codec-4 expiry, GC or manual tombstone operation. |

The sealed original contains typed intent and presence, plan, material, PB1 assessment, image, placement, provenance and format facts. The row stores only the listed projections. Creation identity is part of the SQLite record comparison. The AEAD authenticates the immutable original. Revision, phase, assignment, later evidence and receipt rely on validated ES transitions and CAS and never require resealing. Legacy retention and registry key retirement/revocation keep their existing rules. [Sealed original and row relationship](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1338)

## Format and private interface

| Admitting schema | Row codec and scope | Intent / PB1 / wrapper / payload / algorithm | Payload / header / AAD | Intent / context / permit |
| --- | --- | --- | --- | --- |
| Supported historical schemas, carried through 4 | 1 or 2, no scope | Legacy binding, all custody columns NULL | None | Existing operation binding |
| 3 or 4 | 3, `synthetic_nonoperational_v1`, integer 1 | `1 / 1 / 1 / 1 / 1` | `ESRSPAY1` / `ESRSENV1` / `ESRSAAD1` | `ESRSINT1` / `ESRSCTX1` / `ESRSFRZ1` |
| 4 | 4, `synthetic_progress_nonoperational_v1`, integer 2 | `1 / 1 / 2 / 2 / 1` | `ESRSPAY2` / `ESRSENV2` / `ESRSAAD2` | `ESRSINT2` / `ESRSCTX2` / `ESRSFRZ2` |
| Any other or mixed tuple | Refuse | Refuse | Refuse | No fallback decoder or key search |

Payload framing is `ESRSPAY2 || u16(2) || u32(body length) || u16(10) || TLVs`. TLVs use big-endian `u16 ID`, `u8 state`, `u32 length` and the value. State 0 is absent with zero length, state 1 is present and all other states refuse. The ten required IDs, in order, are identity `(2)`, original intent `(15)`, effective plan `(14)`, material `(5)`, PB1 assessment `(4)`, image `(5)`, placement `(6)`, provenance `(6)`, key/format `(6)` and `u8(2)` scope. Every nested ID, width, count, map and sequence order, presence rule and semantic restriction from §6A applies. The substitutions are provenance leaf 1, exactly 36 ASCII bytes `synthetic_progress_nonoperational_v1`, and wrapper/payload values `2,2` at key/format leaves 4 and 5. Codec 3 retains its `synthetic_signed_dependencies_v1` provenance. [Nested grammar](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md:648) · [Codec-4 dispatch](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md:801)

Header framing is `ESRSENV2 || u16(2) || u32(complete header length) || u16(14) || TLVs`. IDs 1–4 are algorithm `u16(1)`, payload `u16(2)`, scope `u8(2)` and binding `u16(1)`. IDs 5–6 are the original key IDs, 1–64 ASCII bytes with an alphanumeric first byte and alphanumeric, period, underscore or hyphen thereafter. IDs 7–9 are the 32-byte object ID, caller ref and submit-key ref. ID 10 is raw PB1 binding of 1–256 bytes. IDs 11–12 are B32 intent and context commitments. IDs 13–14 are `u32` plaintext and combined lengths. The header is 289 bytes plus both key-ID lengths and the binding length, or 292–673 bytes. AES-256-GCM produces a random 12-byte nonce, ciphertext and 16-byte tag. The combined length is plaintext plus 28. [Exact header and commitments](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md:843)

AAD is `ESRSAAD2 || complete raw header`. Intent HMAC-SHA-256 covers `ESRSINT2 || TLV 2`, and context HMAC covers `ESRSCTX2 || TLV 6 || TLV 7 || TLV 8`, including each TLV frame. The permit binds `SHA256(ESRSFRZ2 || bindingFP32 || envelopeFP32 || header || plaintext)`. The complete-file SHA-256 is unprefixed. PB1 and the shared `ESRSKEY1` key fingerprint namespace are preserved. Wrong versions, keys, scope, object association, commitments, provenance or PB1, and unknown, reordered, repeated or trailing fields fail closed. Limits are 262,144 bytes each for raw JSON and decoded intent, JSON depth 8, 1 MiB each for plaintext and retained binary leaves, 2 MiB sealed, 4 KiB header, 256 KiB per captured component, 64 KiB per data string, object depth 5, container depth 8, 32,768 TLV nodes and 8,192 sequence elements, subject to narrower source domain limits. [Format and limits](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md:801)

Both selectors share the existing owner-only fixture root and `synthetic-replay-v1.marker` with exact bytes `synthetic_nonoperational_v1\n`. Objects use `objects/v1/` plus 64 lowercase hex digits for the header object ID. Reuse no-follow, descriptor identity, exclusive creation, fsync and no-adoption rules. The proposal shares four custody-bearing slots, 32 object names including orphans, 32 aggregate durable reservations, `2^32` reservations per envelope key and a 16 MiB aggregate DB/sidecar budget. The existing interprocess SQLite writer lock serializes the two selectors’ object count plus exclusive create. That section records no grant or claim, and releases before permit consumption and Seal. Existing one-use, known-COMMIT, issuing-store and no-refund rules apply. Exact retired originals can verify fixture replay and progress. New reservation, Seal and establishment require active keys. Revoked, missing, wrong-purpose or mismatched keys refuse. The design adds no instantaneous revocation guarantee. [Root contract](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md:875) · [Shared budgets](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1580)

| Internal method | Inputs, result and authority |
| --- | --- |
| `OpenPrivateReplayProgressCustody` / `Close` | Check fixture root and schema, issue opaque custody and invalidate its borrows on close. |
| `LookupProgressOriginal` | Use the validated fixture caller/key before resolution or key choice. Return opaque absent, compatible locator or occupied/refused. Only the injected catalog gets the exact retained key IDs. |
| `FreezeProgressOriginal` | Check issuer-bound miss, initial phase 1/2, same parsed typed delivery, bound plan/witness, scope and input bounds. Issue opaque frozen original. |
| `ReserveProgressSealUse` | Require exact active purpose/fingerprint pair and known reservation COMMIT. Issue one digest-bound permit. |
| `PublishProgressOriginal` | Match issuer, permit, frozen digest, active eligibility and object identity. Consume once before Seal. Return only an opaque synced publication. Preserve any orphan. |
| `EstablishProgress` | Check frozen/publication binding and active registry pair in the insert transaction. Return created, occupied or write unknown and opaque attempt identity. Retain full expected row and generated rowid internally. |
| `WithAuthenticatedProgressOriginal` | Take locator, retained keys, incoming typed intent and closed purpose of replay or issued-attempt confirmation. Verify exact immutable row, paired keys, file, AEAD and HMACs. Pass a bounded typed view to the sole admission verifier. Compare its reconstructed claim, canonical intent and recomputed PB1/witness against authenticated values, then compare incoming intent before granting one synchronous access. |
| `ReadFixtureProgress` / `ApplyFixtureProgress` | Recheck live issuer-bound access, keys, request and full immutable identity. Read a bounded fixture projection or apply one closed command with expected revision and fixture mutation. Recheck registry eligibility in the CAS transaction. Borrow expires on return or cancellation. |

The only new non-test cross-package consumer is `es/admission/reliable_submit_replay_private.go`. The facade exposes no raw plaintext buffer, raw store, full record, arbitrary verified boolean or effect-capable handle. Fixture RunRefs and receipts have no operational or public conversion. [Finite interface](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md:885)

## Transition and outcome decisions

Phases 1/2 are pending/ambiguous before assignment, 3 assigned, 4/5 pending/ambiguous after assignment, 6 accepted and 7 provably not accepted. The successor uses the same durable model and keeps codec 4 and every original field. [Transition table](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1394)

| Operation and ordered digest part IDs | Selected change |
| --- | --- |
| 1 establish `[10]` | True miss, revision 1, phase 1 or 2, absent assignment and progress, active retention |
| 2 assign `[3]` | Phase 1/2 to 3, one immutable run and assignment time |
| 3 intent `[4]` | Set once after assignment |
| 4 staging `[4]` | Set once after intent |
| 5 dispatch `[4]` | Set once after intent. Staging optional. No-dispatch reconciliation precludes a later marker. |
| 6 observation `[3,5,4]` | Exact run, candidate 3/4/5, intent and dispatch. Kind 1 gives phase 4, kinds 2/5 give phase 5. |
| 7 reconciliation `[3,6,4]` | Exact run and intent, set once. Kind 1 stays at 3 with no dispatch/provider. Kinds 2/3/6 require dispatch and give 4/5/5. Kind 4 adds compatible evidence at 6. Kind 5 moves a compatible candidate to 7 or adds evidence at 7. |
| 8 accept `[7,4]` | Candidate with dispatch and compatible facts, atomically phase 6, provider kind 3 and immutable receipt |
| 9 provably not accepted `[4]` | Candidate with dispatch and compatible facts, phase 7 and provider kind 4, receipt NULL |

The existing digest uses `SHA256("es/reliable-submit/durable-operation-input/v1\0" || u16(kind) || i64(predecessor) || parts)` with big-endian `u16 tag`, `u32 length`, value. Refs are 32 bytes, and parts 5/6 carry `u16` kinds. Op 1 uses predecessor zero and part 10 ordered as `ESRSEST2`, caller and key refs, length-prefixed binding, two witness `u16`s, initial phase `u8`, creation `i64`, codec `u16`, scope `u8`, intent `u16`, both MACs, wrapper/payload/algorithm `u16`s, exact object ref, sealed size `u32`, file SHA, then each `u16`-length-prefixed key ID and fingerprint. The separately compared mutation ref and generated rowid stay outside the digest. Valid equivalent no-ops preserve both revision and latest operation. [Operation encoding](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1394)

| Condition | Result |
| --- | --- |
| Same original, including restart or advancement during authentication | Current authenticated projection of the same attempt. No current resolver, material, active-key selection or Seal. |
| Changed incoming original or same latest mutation with changed kind/input | Fixed conflict, with no prior progress, run or receipt. |
| Exact latest mutation, kind and predecessor-bound input | Exact latest replay before stale checking. |
| Revision mismatch without exact latest replay | Stale without run or receipt. No rebase. |
| Definite initial loser or known CAS loss | Reread and reauthenticate. Equivalent initial winner may return winner replay. Exact latest CAS winner may return replay. Advanced unrelated CAS winner is stale. |
| Invalid, unsupported, wrong scope, corrupt, missing after occupancy or unavailable read | Fixed refusal or read unavailable. Only validated absence on initial lookup permits a first proposal. |
| Known write COMMIT | Retain committed disposition. Authenticate the same original before projecting the committed snapshot. Withhold projection if checking fails or the request is canceled. |
| Earlier write COMMIT unconfirmed | After confirmed quarantine of the write connection, one checked recovery read and reauthentication. Only exact full expected row, including rowid, immutable descriptor, revision, latest operation and every progress fact, confirms own COMMIT. |
| Equivalent or advanced winner, recovery read failure, cancellation, missing/corrupt record or auth failure after write uncertainty | Preserve write unknown. No projected state or second write. |

Every later read or CAS matches the original-bound issuer, rowid, identity, codec/scope, full binding/witness, creation time and all 14 descriptor fields. CAS uses dedicated mutable-only SQL and the caller’s exact expected revision. The selected proof concerns the latest operation. [Replay and uncertainty table](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1454)

## Migration 4

| Schema object | Selected manifest |
| --- | --- |
| `reliable_submit_migrations` | Preserve STRICT definition and complete rows 1–3. Append ledger row 4. |
| `reliable_submit_claims` | Rebuild STRICT with the same 47 fields, physical rowid PK, unique caller/key, witness and phase/effect checks, both registry FKs and exact codec-specific shape. |
| `reliable_submit_claims_envelope_ref_unique` | Recreate same nonpartial unique index, with legacy NULLs permitted. |
| `reliable_submit_claims_no_delete` | Recreate unconditional deletion guard. Verified recursive triggers cover managed REPLACE. |
| `reliable_submit_claims_guard_insert_v4` | Admit exact initial codec 3 or 4 only, with active purpose/fingerprint registry matches. Preserve targeted caller/key `DO NOTHING` and winner validation. |
| `reliable_submit_claims_guard_update` | Preserve historical 1→2 and 2→2, refuse all codec-3 updates, require exact immutable originals and rowid on 4→4. Enforce revision, latest descriptor, terminal/receipt locks, active-or-retired key identities and the selected operation footprint. |
| Key registry and seal-use tables, indexes and six triggers | Keep exact definitions and rows. Key identity and purpose stay fixed, state moves only along 1→2, 1→3 or 2→3, and active envelope counters increment by one within their cap. |

The new literal is `private original replay and fixture claim progress` in `sqlite_replay_progress_schema.go`. Under one `BEGIN IMMEDIATE`, authenticate the opening ledger, shape and application ID `1163088467`. Bootstrap `0→1→2→3→4`, upgrade `1→2→3→4`, `2→3→4` or `3→4`, and open authentic 4 without migration. Keep checked WAL, synchronous FULL, foreign keys and recursive triggers ON, and trusted schema OFF. Close prior-version handles before fixture upgrade. Preserve literal and shape hashes 1–3. Snapshot complete registry, counter and ledger rows, drop the three claims triggers, rename the old claims table and copy physical rowids and all 46 named columns into the new table. Prove counts and both complete `EXCEPT` directions, with exact types and binary text comparison, for claims, registry, counters and ledger. Copy carried state without applying new active-key eligibility. Drop scratch and old table, recreate the index and triggers, then verify exact shape, ledger, application ID and zero FK violations before COMMIT. No backfill, downgrade, resealing, repair or adopted objects. [Migration manifest and preservation](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1492)

| Migration outcome | Disposition |
| --- | --- |
| Unsupported or corrupt opening | Refuse before mutation |
| Pre-COMMIT failure and confirmed rollback | Preserve exact opening state and refuse the handle |
| Known COMMIT | Accept the verified complete new head |
| Lost COMMIT or unconfirmed rollback | Close uncertain pool and classify with one checked nonmigrating open. Exact authenticated new state accepts. Exact recorded old state or pristine zero returns recovered-old refusal. Intermediate, malformed, unreadable, canceled or close failure returns unavailable. |

Schema-4 literal and shape hashes will be derived from the reviewed implementation with the pinned driver. The existing PB1 schema-2 probe retains its original identity and a pinned authentic schema-3 target. Its historical harness and source provenance are needed to reconstruct it. A distinct probe will compile exact PR #10 schema-3 source with one bound test-only overlay and compare complete schema-4 logical and object witnesses before and after refusal. Logical preservation and physical byte or close guarantees are separate claims. [Old-binary evidence contract](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1565)

## Prospective implementation and acceptance

Phase 0 reviews this contract. Phase 1 repairs the pooled reader and binds its regression. Phase 2 implements codec, scope, format and schema. Phase 3 adds durable successors and private composition. Phase 4 proves restart, contention, unknown outcomes and no effects. Phase 5 is one fresh independent audit. The selected target is one integrated source slice. [Phase and path inventory](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1597)

In the table, `I/` is `es/admission/internal/reliablesubmit/` and `A/` is `es/admission/`.

| Owner | Exact prospective paths and change |
| --- | --- |
| SQLite | `I/sqlite_store.go` for pooled repair, strict hydration, scope gates and protected CAS. `I/sqlite_replay_claim.go` for the new initial shape and descriptor. `I/sqlite_migrations.go`, new `I/sqlite_replay_progress_schema.go` and `I/sqlite_replay_shape.go` for append-only schema 4. |
| Durable service | `I/durable_record.go`, `I/durable_operation.go`, `I/durable_service.go` for exact codec-4 constructors, equality, operation binding, successors and unknown recovery. Preserve existing legacy and codec-3 replay behavior. |
| Custody | `I/replay_custody_format.go`, `I/replay_custody_structure.go`, `I/replay_custody_file.go` for finite dispatch, bounded projection, fixture facade and shared physical budgets. Keep old vectors, secure file rules and the codec-3 fresh reader. |
| Admission | `A/reliable_submit_replay_format.go`, `A/reliable_submit_replay_hydration.go`, `A/reliable_submit_replay_private.go` for the scoped format, semantic verification and composition. Keep intent parser and PB1 sources. |
| SQLite and custody tests | New `I/sqlite_pooled_claim_read_cleanup_test.go` and `I/replay_progress_test.go`. Update `I/sqlite_store_test.go`, `I/sqlite_physical_test.go`, `I/sqlite_replay_migration_test.go` and `I/sqlite_replay_shape_test.go`. |
| Admission and static guards | `I/guardrails_test.go`, `A/reliable_submit_guardrails_test.go` and `A/reliable_submit_replay_private_test.go` for finite imports/callers, negative mutants, real fixture composition and no effects. |
| Owner status | The same five files changed in this turn. Advance production schema assertions only when the code lands. |

The four codec-`Synthetic+1` invalid fixtures are in `sqlite_store_test.go` at 545, 620 and 649 and `sqlite_physical_test.go` at 128. They will use explicit unsupported codec 5, with malformed 4 tested separately. The deliberate insert-trigger drops at store lines 651 and 756 and physical line 130 will name the v4 trigger. The existing codec-2-plus-one conformance case still means malformed codec 3. Retain schema 99 as unsupported, the 33-field historical seed projection, the pinned historical PB1 test purpose, and existing codec-3 schema/REPLACE tests. The proposed key-use source change in Appendix A is unnecessary because existing key-use primitives can consume the new domain-separated digest. Existing O2, A1/F1, C1/D1 and file/key privacy tests remain regression evidence. [Exact blast radius](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1597)

| Exact future test | Required witness |
| --- | --- |
| `TestSQLitePooledClaimReadCleanup` | Real BEGIN/SELECT cancellation, ambiguous real BEGIN/read COMMIT, rollback error, actual expiry with nil response, timely control, discard rescue and withholding, predispatch cancel, safe not-found/corrupt. Same test and instrumentation bytes on old and repaired readers. Remove fault hooks before healthy same-store reads/CAS, compare rows and avoid FD-count oracles. |
| `TestPrivateReplayProgressFormatVectors` | Independently authored payload/header/AAD/HMAC/permit/establishment and AEAD vectors, strict bounds, parser corruption and cross-scope refusal. |
| `TestPrivateReplayProgressAdmissionReplay` | Real restart with changed defaults/material/active key, no acquisitions on hit, intent conflict privacy, wrong-scope occupation, concurrent first winner and shared capacity. |
| `TestPrivateReplayProgressTransitions` | Both initial phases, all legal transitions and incompatible joint facts, stable run/receipt and full immutable row/file preservation. Malformed 4, unknown 5, narrowing aliases and capability misuse refuse. |
| `TestPrivateReplayProgressConcurrencyAndCommitOutcome` | Advancement between authentication and read/CAS, exact latest versus stale or changed mutation, full own-COMMIT proof, restart, equivalent/advanced winner and unresolved failed recovery reads with zero extra writes. |
| `TestSQLiteV4MigrationPreservesFullState` | Authentic 0/1/2/3 starts, complete row/key/grant/ledger equality, rollback and lost response, codec-3 immutability, forbidden downgrade/REPLACE/UPSERT and historical CAS. |
| `TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation` | Actual old opener compiled with `TestPreviousSchema3OpenerProbe`, authentic schema-4 target and exact nonmigrating before/after witnesses. Preserve the independent PB1 probe on schema 3. |
| `TestPrivateReplayProgressHasNoEffectPaths` | Finite static reachability and behavior with fail-on-contact fixture counters. Include accepted, unknown, mismatch and cancellation. Existing App/API refusal and unkeyed behavior are regression evidence. |

The future command sequence uses the pinned readonly Go environment and authentic probe artifacts. It accounts for new identities and explains changes in skips, with no skip accepted for a new bounded path. [Acceptance suite and commands](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1642)

```sh
"$GO" test -mod=readonly -overlay "$SCHEMA3_OVERLAY" -c -o "$SCHEMA3_PROBE" ./es/admission/internal/reliablesubmit
ES_REPLAY_SCHEMA3_TARGET="$SCHEMA4_TARGET" "$SCHEMA3_PROBE" '-test.run=^TestPreviousSchema3OpenerProbe$' -test.v
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestSQLitePooledClaimReadCleanup$' ./es/admission/internal/reliablesubmit
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateReplayProgressFormatVectors|TestPrivateReplayProgressTransitions|TestPrivateReplayProgressConcurrencyAndCommitOutcome|TestSQLiteV4MigrationPreservesFullState|TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation|TestSQLiteV3OldBinaryRefusesWithoutMutation|TestSQLiteLegacyCASConnectionCleanup|TestReplayOriginalKeyReadCleanup|TestReplayGrantC1PreCommitConnectionQuarantine|TestReplayGrantD1BeginResponseLossQuarantine|TestReplayKeyStateD1BeginResponseLossQuarantine)$' ./es/admission/internal/reliablesubmit
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateReplayProgressAdmissionReplay|TestPrivateReplayProgressHasNoEffectPaths|TestReliableSubmitFoundationHasNoRuntimeWiring|TestReliableSubmitBindingProducerHasNoProductionCaller|TestPrepareRequestShapeRemainsLegacyAndUnkeyed|TestResolvedSubmitLegacyEquivalenceOneNomadRegistrationAndAuthorityRecovery)$' ./es/admission
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestWorkstreamCContractPrepareAndSubmitRemainSeparatedAtAPIBoundary|TestSubmitPublicRouteRejectsStructuralReliableBody)$' ./es/api ./es/app
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=600s ./es/admission/internal/reliablesubmit ./es/admission ./es/api ./es/app
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=600s ./...
```

## Executed documentation validation

Final generation `v3` used Go 1.26.5 `darwin/arm64`, its sibling `gofmt`, offline cached modules, Python 3.13, OpenSSL 3.6.2, a private external cache and temp root, umask `077` outside Go test and `027` inside it. The first submit-section edit script failed parsing before writing any source. Validation generations `v1` and `v2` passed and are retained. `v2` clarified historical disposal evidence and fixture migration boundaries. `v3` made the future old-binary overlay invocation explicit. Each final command had its own executed integrity checkpoint. No full suite, old-binary build, diagnostic rerun, native-host validation or runtime test ran in this turn. [Final freeze and exact environment](/Users/ds/Repositories/ES-Private-Replay-Progress-Contract-20261118-8o8gnc8g/v3-validation-freeze.json) · [Outcomes by test identity](/Users/ds/Repositories/ES-Private-Replay-Progress-Contract-20261118-8o8gnc8g/v3-go-test-run.json) · [New documentation assertion](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/docs_contract_test.go:12549)

```sh
"$GO" version
"$GOFMT" -d docs_contract_test.go
git --no-pager diff --check
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateOriginalReplayProgressContractSelection|TestReliableSubmitPersistenceAndConcurrencyADRDocsContract|TestSubmitIdempotencyCorrelationAndRecoveryDocsContract|TestReliableSubmitPureModelDocsAndSourceContract|TestReliableSubmitPublicOptInAndVersioningDocsContract|TestReliableSubmitContractAdapterFoundationDocsAndSourceContract|TestReliableSubmitBindingProducerDocsContract|TestIntegratedAcceptanceGateDocumentationIsConsistent|TestIntegratedCandidateStatusSeparatesCAndT)$' .
```

All four commands exited zero. `gofmt -d` and `diff --check` emitted nothing. The eight subtests under `TestSubmitIdempotencyCorrelationAndRecoveryDocsContract` passed: `actual_provider_bullet`, `harmless_continuation_reflow`, `removed_provider_warning`, `reversed_provider_warning`, `warning_relocated_into_SubmitResult_bullet`, `missing_provider_bullet_with_warning_elsewhere`, `duplicate_provider_bullet` and `malformed_provider_continuation`. [Run record](/Users/ds/Repositories/ES-Private-Replay-Progress-Contract-20261118-8o8gnc8g/v3-go-test-run.json)

## Canonical manifest

The exact Appendix B recipe `governed-execution.audit-patch-manifest.v2` has source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`. Both final runs produced byte-identical mode-`0600` manifests outside the checkout. Manifest SHA-256 is `4857bbf5f1572dbfb78c221a13d657107bcfbf6690d830b7769cc35465bdb0da`. Tracked-diff SHA-256 is `8bf2dc2d8ae5027b8b21b53d7cd51598d07c5b2c5a744933a572338f894aa9bf`. [Manifest A](/Users/ds/Repositories/ES-Private-Replay-Progress-Contract-20261118-8o8gnc8g/v3-final/manifest-a.json) · [Manifest B](/Users/ds/Repositories/ES-Private-Replay-Progress-Contract-20261118-8o8gnc8g/v3-final/manifest-b.json)

```json
{"branch":"codex/private-replay-progress-v1","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/es_execution_admission_model.md","sha256":"c9f14b62f5aa8dbef7cd3edbb04854d75cfa61cedf2a5ae13cfc8925010fbcc5","size":79799},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md","sha256":"0da27df416db33bc7f71e97a0e64fc31416c765757b9ee1f74fcd719d60e08f9","size":132867},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md","sha256":"30d949fc219d2b5f659b9d79d18ced8dc42e89d3a24f25b35066a8b896490f9a","size":100202},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"a361f4abdb620fb12bd4adfc6c2539c5722eae92101b471b968b33026ac72531","size":300012},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"a40de2eac02e205d4088b94ce40cdf44f6d69cc807a7b5c33d48675d04474b6b","size":784233}],"head":"f1aa8b934cc26c16a966a110c7b408abdaeadce7","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"8bf2dc2d8ae5027b8b21b53d7cd51598d07c5b2c5a744933a572338f894aa9bf","upstream":"origin/trunk_dev"}
```

```text
ES_PRIVATE_REPLAY_PROGRESS_OWNER_CONTRACT_READY_FOR_REVIEW
POOLED_LOADCLAIM_DEFECT_NOT_REPAIRED_IN_THIS_TURN
LOADCLAIMFRESH_BEHAVIOR_PRESERVED
SCHEMA4_AND_CODEC4_NOT_IMPLEMENTED
PRODUCT_SOURCE_BYTES_UNCHANGED
INDEPENDENT_ACCEPTANCE_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PRS_NOT_MODIFIED
EXISTING_SOURCE_CHECKOUTS_NOT_SYNCHRONIZED
RUNTIME_WIRING_NOT_PERFORMED
PUBLIC_RELIABLE_SUBMIT_NOT_ENABLED
```
<END_OWNER_CONTRACT_REPORT>


---

# Appendix B — Exact opening canonical five-file manifest

Exact payload: 1331 bytes; SHA-256 `4857bbf5f1572dbfb78c221a13d657107bcfbf6690d830b7769cc35465bdb0da`.
The payload starts immediately after the BEGIN delimiter newline.
Extract exactly the stated byte count; framing newlines are not payload.

<BEGIN_OPENING_MANIFEST>
{"branch":"codex/private-replay-progress-v1","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/es_execution_admission_model.md","sha256":"c9f14b62f5aa8dbef7cd3edbb04854d75cfa61cedf2a5ae13cfc8925010fbcc5","size":79799},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md","sha256":"0da27df416db33bc7f71e97a0e64fc31416c765757b9ee1f74fcd719d60e08f9","size":132867},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md","sha256":"30d949fc219d2b5f659b9d79d18ced8dc42e89d3a24f25b35066a8b896490f9a","size":100202},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"a361f4abdb620fb12bd4adfc6c2539c5722eae92101b471b968b33026ac72531","size":300012},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"a40de2eac02e205d4088b94ce40cdf44f6d69cc807a7b5c33d48675d04474b6b","size":784233}],"head":"f1aa8b934cc26c16a966a110c7b408abdaeadce7","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"8bf2dc2d8ae5027b8b21b53d7cd51598d07c5b2c5a744933a572338f894aa9bf","upstream":"origin/trunk_dev"}

<END_OPENING_MANIFEST>


---

# Appendix C — Exact v2 patch-manifest recipe source

Exact payload: 7275 bytes; SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`.
The payload starts immediately after the BEGIN delimiter newline.
Extract exactly the stated byte count; framing newlines are not payload.

<BEGIN_PROVENANCE_RECIPE>
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
import sys
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v2"


def fail(message: str) -> "NoReturn":
    raise SystemExit(message)


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env.update(
        {
            "LC_ALL": "C",
            "LANG": "C",
            "GIT_OPTIONAL_LOCKS": "0",
            "GIT_NO_LAZY_FETCH": "1",
            "GIT_TERMINAL_PROMPT": "0",
            "GIT_PAGER": "cat",
        }
    )
    result = subprocess.run(
        [
            "git",
            "--no-pager",
            "-c",
            "core.fsmonitor=false",
            "-c",
            "core.untrackedCache=false",
            *args,
        ],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


def validate_output_path(output_path: Path, repository_root: Path) -> None:
    if not output_path.is_absolute():
        fail("output path must be absolute")

    parent = output_path.parent
    parent_metadata = parent.lstat()
    if not stat.S_ISDIR(parent_metadata.st_mode) or stat.S_ISLNK(parent_metadata.st_mode):
        fail("output parent must be a nonsymlink directory")
    if parent_metadata.st_uid != os.getuid():
        fail("output parent must be owned by the current user")
    if stat.S_IMODE(parent_metadata.st_mode) & 0o022:
        fail("output parent must not be group- or world-writable")

    try:
        output_path.lstat()
    except FileNotFoundError:
        pass
    else:
        fail("output path already exists")

    repository_text = os.path.realpath(os.fspath(repository_root))
    output_text = os.path.realpath(os.fspath(output_path))
    try:
        common = os.path.commonpath([repository_text, output_text])
    except ValueError:
        common = ""
    if common == repository_text:
        fail("output path must be outside the repository")


def write_exclusive(output_path: Path, payload: bytes) -> None:
    flags = (
        os.O_WRONLY
        | os.O_CREAT
        | os.O_EXCL
        | getattr(os, "O_NOFOLLOW", 0)
        | getattr(os, "O_CLOEXEC", 0)
    )
    fd = os.open(os.fspath(output_path), flags, 0o600)
    try:
        view = memoryview(payload)
        while view:
            written = os.write(fd, view)
            if written <= 0:
                fail("short provenance-output write")
            view = view[written:]
        os.fsync(fd)
    finally:
        os.close(fd)

    metadata = output_path.lstat()
    if not stat.S_ISREG(metadata.st_mode) or stat.S_ISLNK(metadata.st_mode):
        fail("provenance output is not a regular nonsymlink file")
    if metadata.st_uid != os.getuid():
        fail("provenance output owner mismatch")
    if stat.S_IMODE(metadata.st_mode) != 0o600:
        fail("provenance output mode mismatch")
    if metadata.st_nlink != 1:
        fail("provenance output link-count mismatch")
    if metadata.st_size != len(payload):
        fail("provenance output size mismatch")

    read_flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_CLOEXEC", 0)
    read_fd = os.open(os.fspath(output_path), read_flags)
    try:
        observed = bytearray()
        while len(observed) <= len(payload):
            chunk = os.read(read_fd, min(1 << 20, len(payload) + 1 - len(observed)))
            if not chunk:
                break
            observed.extend(chunk)
    finally:
        os.close(read_fd)
    if bytes(observed) != payload:
        fail("provenance output byte mismatch")


if len(sys.argv) != 2:
    fail("usage: governed_execution_audit_patch_manifest_v2.py ABSOLUTE_OUTPUT_PATH")

repository_root = Path(git_text("rev-parse", "--show-toplevel"))
output_path = Path(sys.argv[1])
validate_output_path(output_path, repository_root)

head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    fail("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            fail(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()

write_exclusive(output_path, canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")

<END_PROVENANCE_RECIPE>
