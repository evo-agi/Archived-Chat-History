Here is Codex's response:

# ES_PRIVATE_REPLAY_PROGRESS_LOCAL_COMMIT_CREATED

Created and verified one local commit, **`dbdc433283617b9e3b233f75c92f1179c2ece91f`**, on `codex/private-replay-progress-v1`. It contains all 30 accepted paths exactly. The worktree and index are clean. All 12 staged validation commands passed, including **5,192 full-suite passes, zero failures, and 39 expected skips**. The separate N-1 witness passed all four cases and its parent.

| Commit field | Verified value |
|---|---|
| Subject | `feat: add private original replay with durable progress` |
| Sole parent | `f1aa8b934cc26c16a966a110c7b408abdaeadce7` |
| Complete tree | `e066cd4afa77fcb665f31b69bf00465989f9744e` |
| Author and committer | `AlacerMortis <david.shaw.dev@gmail.com>` |
| Author and committer time | November 19, 2026, 17:54:30 EST |
| Signing | Unsigned, with commit signing unset in the existing configuration |

## Opening and acceptance evidence

The sole checkout was `/Users/ds/Repositories/ES-Private-Replay-Progress-v1`. Its own `.git` served as both Git directory and common directory. Its origin was `git@github.com:evo-agi/Execution-Substrate.git`. The branch and upstream name `origin/trunk_dev` were preserved. The local tracking ref stayed at the opening HEAD, and the topic branch finished one commit ahead.

Opening HEAD was the new commit’s sole parent shown above. Its parent was `fb9ae55797d9fcc02863c23fe8d3e43d16eac542`, its tree was `8dd27f9acba98ed70d93736bdef8300ef1aba53f`, and its subject was `Harden original-key read transaction cleanup (A1) (#10)`. The 427-entry opening index equaled HEAD. Independent reads bound all 427 committed blobs and all 430 physical files. The candidate consisted of 400 HEAD-identical files, 27 unstaged modifications, and three ordinary-untracked additions. All 60 baseline executables retained disk mode `0755` and Git mode `100755`.

The attachment SHA-256 was `540633b602a6fbf0bb07af4131515c29b29f0a77e7dad8bcf5afe0a24983242b`. Each framed payload authenticated before use.

| Appendix | Bytes | SHA-256 |
|---|---:|---|
| A, independent ACCEPT | 46,438 | `332349b4ce386ce8a7da9f64dd2807dd33f1d259cf287fccd49eaf286af11f28` |
| B, accepted manifest | 6,813 | `f92b57f48a701a606e8a0697b75dac8f691e3eb44c13b9c92afb894ec6e1d718` |
| C, unchanged v2 recipe | 7,275 | `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` |
| D, external bridge | 789 | `14f0e9e92a37e1d1bf624f1f052a62a6d56e5b82f988698abbf6e1b5bcf9196d` |
| E, external witness | 5,897 | `8da31dd61c9af2537c15f4376a330d05cb2e55dd2efd0ea610472a0c6ffa5c6a` |

The unchanged recipe ran twice from the exact checkout using pinned Python `-B`, into separate absent `opening-a.json` and `opening-b.json` files. Both exited 0 and reproduced Appendix B byte for byte. Each stdout SHA-256 was `9b829ba8118a6d13d27630e70c4037cae1d724401891c3f9237e609327cfced1`, with empty stderr.

I authenticated 108 acceptance artifacts and 1,376 probe-material and binding records at opening, before staging, before commit, and at closeout. The checked subset included both manifest pairs, source and closeout proofs, eleven historical argv/cwd/exit records, raw stdout and stderr, identity multisets, skip reasons, immediate guards, host preflight, both probe source/build bindings, and the external N-1 view and build records. The principal acceptance anchors were:

| Prior acceptance record | SHA-256 |
|---|---|
| `artifact-index.json` | `7847cde1799ec2166cf599fb73ad726ab056b82bb128dd6b695f107f1e858205` |
| `closing-a.json`, `closing-b.json` | `f92b57f48a701a606e8a0697b75dac8f691e3eb44c13b9c92afb894ec6e1d718` |
| `closing-guard.json` | `a670d3738e2ea00f911233948d0c08daed3b76073bbc80a95b2df01e5f205ede` |
| `fresh-reconciliation.json` | `d49c9d3d551e6e1608a07ff7a10295eb9d4d3b9c4396635e5d70da472451f813` |
| `retained-reconciliation.json` | `effd722966ad2e22d130e6c30329e2029800d1737747758ae94d9bb2fdd22b9e` |
| `n1-build-reconciliation.json` | `4af8b5c1497b41f3eee8ba0e0084b8eb66118cf6424b7682b8d3dbc6c8e7f9f0` |
| `gate-10/stdout`, historical full suite | `5e9c8153bd96d3eaf4a35caf89fd29b601620686d86a0306eb4deb38ef1277eb` |
| `gate-11/stdout`, historical N-1 | `1cef79c15b80c7cf5c56ac1e11598cd30bc4af83291625ec83927ebf9ba65b2a` |

The accepted review ZIP authenticated at 955,015 bytes and SHA-256 `3b27c483036296304a9fbca77dcd5fe522dee64b8eabf392057b6c573160f59a`. All 47 regular members and 46 inventory rows authenticated. The embedded manifest, recipe, and 30 source payloads matched the supplied and live bytes. [Accepted review ZIP](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/ES-Private-Replay-Progress-M1-Owner-Repair-Review.zip)

## Exact staging and committed bindings

The pinned Git ran `--literal-pathspecs add -- PATH` once for each row below, in order, from the target checkout. All 30 exited 0. The transition was **27 unstaged modifications + 3 ordinary-untracked files → 27 staged modifications + 3 staged additions**. `git write-tree` froze the complete 430-entry tree before validation.

- Full staged and committed diff SHA-256 was `1b1d1486ee301898835c059306bf81c4a4d167b99b1320a0b9a428c2a81d98e4`.
- The exact 27-path tracked subset of each diff reproduced `793e6697cf2342ce41f08ed8f59a0a14eb5c288c74780f158731d55dbe17bcca`.
- Opening index SHA-256 was `1c6218366e333383b205833fce0ceaa5d462fa7264cf51cbdcd35aa05855b018`. Staged and closing index SHA-256 was `eceb865ee65dcbff43da6d75ec659a74e557f4617b171590f967b3969780328f`. Local config SHA-256 was `4c98ee1729d2d3321c357ec922f6dafc19b6ac167a8a24ed636d359ab6642485` throughout.

Table path prefixes `L`, `A`, and `I` expand under `/Users/ds/Repositories/ES-Private-Replay-Progress-v1` to `.docs/execution_lifecycle`, `es/admission`, and `es/admission/internal/reliablesubmit` respectively. Every row was regular `0644` on disk and `100644` in Git. The staged and committed blobs were read independently and compared byte for byte. The other 400 entries retained the parent’s object IDs and modes.

| Path | Delta | Bytes | Accepted, staged, committed SHA-256 | Staged and committed blob |
|---|:---:|---:|---|---|
| `L/es_execution_admission_model.md` | M | 88702 | `bedc87c611b5c9340ffaafb0866f028dc9daf2f22552efec47491f1b4ae713f2` | `0f5c56cdbf11b80158f29700a31fef5dc20f335f` |
| `L/reliable_submit_persistence_and_concurrency.md` | M | 161666 | `34e06ff10148d67a49000868499294873c732279d7f399a5f2cb910b0c12f40e` | `772fb7dbd4bfb1d8162b87b0d66c0803957cbdd9` |
| `L/submit_idempotency_correlation_and_recovery.md` | M | 103025 | `1b03cc40b48861c7220a7b85d20b1f8d232690f17460e3eee0df33af4659e3f3` | `94fe56e0cdea71acf29c2df1074bcd4048c0bc0b` |
| `PLANS.md` | M | 302636 | `c4fdbfb4acd3c2a27f679f6575798c4553e94110c4aa7177f590e90fe89c5e31` | `b74440dc7d3ef2e488d92a7fb9f6f64d7cecdcee` |
| `docs_contract_test.go` | M | 799914 | `dd433f02e783aa265d775bd411c95433e369642e2aafbdb32c72b75f78b4ebff` | `e69ada92d1e723e1b70f03e5191e96145e687713` |
| `I/durable_operation.go` | M | 9548 | `b7761f001a1f67349ed51f2b79012194a7d45bb19c79e0ca2c0c22b8227320f9` | `94a7d56b5f8ef5501f92abf7cb0c7732a490859d` |
| `I/durable_record.go` | M | 25226 | `999db7db6550c5031b023a9613825504e30e971a179298cc43e09cf8c5c5d7cd` | `41e2dc127cd0a56163a9f9c42992e3e2dad9643b` |
| `I/durable_service.go` | M | 49972 | `ef0bc6f4d125f3986c46901cbe05bc2cb447af7dfbf51afe993a59c2afaf7971` | `25ef96d035c6be87209d81c7b831a366f47d6e94` |
| `I/guardrails_test.go` | M | 32231 | `9a300f0553fd6ac3003a048a7309060a4ec6f618eacd94139bd4bb29c011bc60` | `ebadc607372c586f1681d6290037cac50b0167fe` |
| `I/replay_custody_file.go` | M | 50461 | `61c4006e1e4a3feb7c0ec0e7d4685dc2c3fe8c1e2165d1529d2c86ae8fa137b5` | `b1bc86218f53653d04eda1840ced29c8688ce098` |
| `I/replay_custody_file_test.go` | M | 69995 | `207d9f17658cd50f6c4bea8e293b12abd89455a174b2d96bac84742a66b0afdf` | `d5b0f305b3809520f79c4ef1f9ab206292be7578` |
| `I/replay_custody_format.go` | M | 16488 | `b8cb8e31edd9d854317a0d6a456f25d5ab1838498623881e429dec2155e1ea67` | `134c37fff7318ccc356a0ce34ced924eb16b95a1` |
| `I/replay_custody_structure.go` | M | 18640 | `4916268757b93d409cbc13ba9c0da14e009499b4db7cadd52bc7ccd47c6a86ad` | `f1aed2819f38138264e5691432f849079252a3bb` |
| `I/replay_progress_test.go` | A | 61314 | `0952fff321daa368dee1d32ed39a2a5b417e7d2779ae4e1015ab3c12b1021048` | `f055ead2af265d3ac5d28c4c6a6698f46449a389` |
| `I/sqlite_migrations.go` | M | 17407 | `7736e30a1d0c6e9584d9050cc6ebf8bfaf900d424f764ebe61af8ec8ddaec0c9` | `7814a04f4962fbdb8cec4a1d3a24201ea10f9bca` |
| `I/sqlite_physical_test.go` | M | 14539 | `2c125b6373f83467d542db45473cc79b888ed3a665e65ef6bf013655f461a7ba` | `620899f647432e48789bee7df219b5689ef417c7` |
| `I/sqlite_pooled_claim_read_cleanup_test.go` | A | 8912 | `0ec3060ed3c30a6327ec49b0291d5c761c20894986c9b6b1e1be384694312823` | `4aa80cca7b7c3d3011dd277aaaeda4f59b02011a` |
| `I/sqlite_replay_claim.go` | M | 8301 | `8ddec89b4ca5702591bdf2060062016d7fb54264fc7df57af5ead1d161eb9de3` | `4f4ce954febca494bada72ebc2e5f95bc43af2fb` |
| `I/sqlite_replay_migration_test.go` | M | 28903 | `e0765e59cb00ace73e8a88c92b9d7e830b39766792120845220b2fd407d357fa` | `8191f490886cef673e1ce98dc30dc982e69d3e61` |
| `I/sqlite_replay_progress_schema.go` | A | 30612 | `132d8ab87f5658cab3477b9f6913538013ba922d4768192a96be960df7bbb149` | `1317d92ba935f9cd1b9532ca0807a5c9cf05282c` |
| `I/sqlite_replay_shape.go` | M | 2751 | `29cdbba2e5b1fee069989f6e6423dccc1c69c843de22b6504f68a7d199b317be` | `b4b5f18f5686a912cf02f9164cc2e27ff6ffa59a` |
| `I/sqlite_replay_shape_test.go` | M | 8815 | `3552ea5fafbc59e43cc21b1007486e98da4d59b6d0ea98db92646e0c8478adfb` | `3f938be010268b950351c0ec72922e2379a297d2` |
| `I/sqlite_store.go` | M | 63299 | `e448d265516aae1d7efd2c06170d8cfa2cc8c0258f82dfc15a3279e65efad4c1` | `97a9d8f5c8b74a1c7d05812a0d6f80073d613dd4` |
| `I/sqlite_store_test.go` | M | 57339 | `c99e7659b1059431911557ba43ef7fa982e373bba939f610bd41ea0622cee96f` | `ee2f8c5b6255d3ba4990fc23c2b393bda85e0d77` |
| `A/reliable_submit_guardrails_test.go` | M | 50991 | `32de42b7bf8974e36c014d3d9ce6d24e0994fbbc03bb1587c4fddd32c80f6e` | `56ee45b1a99e453a96bcbce21095ccd894deb26f` |
| `A/reliable_submit_replay_format.go` | M | 17326 | `0a21803b03308332613481f89ce4b595512b31b073c56b31fe7d8000519c3beb` | `533877eea3ef937d8d7c77c85e2ac160a43af790` |
| `A/reliable_submit_replay_hydration.go` | M | 28800 | `b5ff16b96178c45b53165ebb2bcbdc67991bb145276ca4a11a598f1430745b9c` | `97f3eec0f78b20a7afc4b1f6e53df55c5911ee6c` |
| `A/reliable_submit_replay_private.go` | M | 20440 | `d17927a23a57c808a8f0ebc4bad3e9912e42d7da497033637102bae2c45fd278` | `ace0e7c6a7e35c8e8385e49008e06a567a17b5cd` |
| `A/reliable_submit_replay_private_test.go` | M | 45171 | `4e4e7c7fad2ed2b88b35801841044f4b1f049a4cb6d0435499bb87699467e9f2` | `e45e87ec5fa7abbaccd1d365cab1d642d8f6c44b` |
| `A/workstream_c_guardrails_test.go` | M | 297009 | `68f2fe4e31e5d862be161c3ba1071a511935b32e90cf9021755fe4dcb045fab5` | `59bac2e2b3f3214dbaaf6c080d6356df9d84e31c` |

## Host, policy, and fixtures

Preflight matched the accepted Darwin arm64 executables. The repository used its configured identity. The resolved hooks directory held only inactive sample hooks. Applicable source attributes were empty, fsmonitor was unset, and signing policy was unchanged.

| Tool | Verified executable and version | SHA-256 |
|---|---|---|
| Go | `/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go`, 1.26.5 darwin/arm64 | `3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19` |
| gofmt | `gofmt` beside the pinned Go binary | `3b87c876b1255feb8ecc539afff2eadd9dcc76e0e34657bdab6d32fd03329f81` |
| Python | `/Library/Frameworks/Python.framework/Versions/3.13/bin/python3` → sibling `python3.13`, 3.13.4 with `tomllib` | `f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b` |
| OpenSSL | `/opt/homebrew/Cellar/openssl@3/3.6.2/bin/openssl`, 3.6.2 | `bf63843e6856e1994ca71092ff3b46834236eb2144dd9b6ceb85d511128b836e` |
| Git | `/opt/homebrew/Cellar/git/2.49.0/bin/git`, 2.49.0 | `03d4a6c5328d4a1ce84eba2765664284b1fb2414d9e657358733056a89a95954` |

`GATE_ROOT` was `/Users/ds/Repositories/ES-Private-Replay-Progress-Commit-Gate-20261119-U0JC7ELW`, owned by uid 501, device 16777231, inode 214786937. The safe environment record, SHA-256 `d007e2abbd016b1748107ef3a089a49940d962451169c3c22914612a0e8c5b91`, bound these settings:

```text
PATH=/Library/Frameworks/Python.framework/Versions/3.13/bin:/opt/homebrew/Cellar/openssl@3/3.6.2/bin:/opt/homebrew/Cellar/git/2.49.0/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin
LC_ALL=C  LANG=C
GOTOOLCHAIN=local  GOPROXY=off  GOSUMDB=off  GOWORK=off
GOFLAGS=-mod=readonly  GOENV=off  CGO_ENABLED=0  GOTELEMETRY=off
GOMODCACHE=/Users/ds/go/pkg/mod
GIT_OPTIONAL_LOCKS=0  GIT_NO_LAZY_FETCH=1  GIT_TERMINAL_PROMPT=0  GIT_PAGER=cat
PYTHONDONTWRITEBYTECODE=1
GOCACHE=$GATE_ROOT/cache  GOTMPDIR=$GATE_ROOT/gotmp  TMPDIR=$GATE_ROOT/tmp
ES_REPLAY_PB1_PROBE=$GATE_ROOT/historical-pb1.test
ES_REPLAY_SCHEMA3_PROBE=$GATE_ROOT/previous-schema3.test
```

Python ran with `-B`. The outer umask was `077`, and test subprocesses used `027`. The PB1 copy was 14,350,930 bytes at SHA-256 `b205a31bac091cbcf5b3f4826bc359455625316908051131733622813e34adcf`. The previous schema-3 copy was 15,601,186 bytes at `42614a50812a65ba52b53488d872884e59ce7b4f57dece6a66642d4eb8de1409`. Its source and build-input inventory bound to `50a81fa5a042e135abfc9f6bad68d20abc4575f881945ecc84252c14910dde8f`. The maintained tests set distinct child target bindings and verified PB1 schema 2 refusing schema 3 and the previous schema-3 opener refusing schema 4.

Tests used the authorized synthetic SQLite fixtures, synthetic keys and certificates, helper processes, loopback mocks, and test-owned temporary paths and Git fixtures. Before gates 9–11, `/usr/local/bin/docker context inspect --format '{{.Endpoints.docker.Host}}'` exited 0 and selected `unix:///Users/ds/.docker/run/docker.sock`. `/usr/local/bin/docker info --format '{{.ServerVersion}}'` exited 1 with `Cannot connect to the Docker daemon`. The direct `/var/run/docker.sock` capability was absent. Both commands in each pair ran from the checkout and received fresh immediate guards. Context and daemon guard times were `17:46:09.272985` / `17:46:09.867702`, `17:46:14.353869` / `17:46:14.680895`, and `17:48:24.358596` / `17:48:24.693191` EST.

Two gate harness failures were retained. The first opening attempt expected both historical binaries in one material list. The correction resolved the omitted schema-3 binary through authenticated indexes. The first validation launch mistook the retained `gate-initial.py` for a gate result and stopped before launching any primary command. Each actual primary command ran once.

## Fresh validation

Commands 1–11 ran from `/Users/ds/Repositories/ES-Private-Replay-Progress-v1`. Command 12 and the supplemental `go list` ran from `/Users/ds/Repositories/ES-Private-Replay-Progress-Commit-Gate-20261119-U0JC7ELW/n1-source`. The following reproduces the argv in order. Comments mark gate numbers.

```sh
GO=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go
GOFMT=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/gofmt
GIT=/opt/homebrew/Cellar/git/2.49.0/bin/git
I=es/admission/internal/reliablesubmit
A=es/admission

# 1–4
"$GO" version
"$GOFMT" -d docs_contract_test.go "$I/sqlite_store.go" "$I/sqlite_replay_claim.go" \
  "$I/sqlite_migrations.go" "$I/sqlite_replay_progress_schema.go" "$I/sqlite_replay_shape.go" \
  "$I/durable_record.go" "$I/durable_operation.go" "$I/durable_service.go" \
  "$I/replay_custody_format.go" "$I/replay_custody_structure.go" "$I/replay_custody_file.go" \
  "$A/reliable_submit_replay_format.go" "$A/reliable_submit_replay_hydration.go" \
  "$A/reliable_submit_replay_private.go" "$I/sqlite_pooled_claim_read_cleanup_test.go" \
  "$I/replay_progress_test.go" "$I/replay_custody_file_test.go" "$I/sqlite_store_test.go" \
  "$I/sqlite_physical_test.go" "$I/sqlite_replay_migration_test.go" \
  "$I/sqlite_replay_shape_test.go" "$I/guardrails_test.go" "$A/reliable_submit_guardrails_test.go" \
  "$A/reliable_submit_replay_private_test.go" "$A/workstream_c_guardrails_test.go"
"$GIT" --no-pager diff --check
"$GIT" --no-pager diff --cached --check

# 5–8
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateReplayProgressSynchronizationInventoryDocsContract|TestPrivateOriginalReplayProgressContractSelection|TestReliableSubmitPersistenceAndConcurrencyADRDocsContract|TestSubmitIdempotencyCorrelationAndRecoveryDocsContract|TestReliableSubmitPureModelDocsAndSourceContract|TestReliableSubmitPublicOptInAndVersioningDocsContract|TestReliableSubmitContractAdapterFoundationDocsAndSourceContract|TestReliableSubmitBindingProducerDocsContract|TestIntegratedAcceptanceGateDocumentationIsConsistent|TestIntegratedCandidateStatusSeparatesCAndT)$' .
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestSQLitePooledClaimReadCleanup$' ./es/admission/internal/reliablesubmit
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestSQLiteMigrationPrecommitClosedWrapperRecovery|TestPrivateReplayProgressConfirmationEligibility|TestPrivateReplayProgressReconciliationEligibility|TestPrivateReplayProgressTerminalEvidenceBinding|TestSQLiteMigrationOpeningRevalidatedUnderLock|TestSQLiteLiteralInternalNamespaceQualification|TestPrivateReplayScope1PublicationPreflight|TestPrivateReplaySharedObjectAllocation|TestReplayPublicationFaultAndIdentity|TestPrivateReplayProgressFormatVectors|TestPrivateReplayProgressTransitions|TestPrivateReplayProgressConcurrencyAndCommitOutcome|TestSQLiteV4MigrationPreservesFullState|TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation|TestSQLiteV3OldBinaryRefusesWithoutMutation|TestSQLiteLegacyCASConnectionCleanup|TestReplayOriginalKeyReadCleanup|TestReplayOriginalKeyReadCallerRefusal|TestReplayGrantC1PreCommitConnectionQuarantine|TestReplayGrantD1BeginResponseLossQuarantine|TestReplayKeyStateD1BeginResponseLossQuarantine|TestReliableSubmitPrivatePersistenceStaticGuardrails)$' ./es/admission/internal/reliablesubmit
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestExecutionSubstrateProductionHasNoA3LeaseRegistryOrPoisonDesign|TestExecutionSubstrateSynchronizedMutableStateReferenceInventoryIsExact|TestPrivateReplayProgressOccupiedDisposition|TestPrivateReplayProgressAdmissionReplay|TestPrivateReplayProgressHasNoEffectPaths|TestReliableSubmitFoundationHasNoRuntimeWiring|TestReliableSubmitBindingProducerHasNoProductionCaller|TestPrepareRequestShapeRemainsLegacyAndUnkeyed|TestResolvedSubmitLegacyEquivalenceOneNomadRegistrationAndAuthorityRecovery)$' ./es/admission

# 9–11
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestWorkstreamCContractPrepareAndSubmitRemainSeparatedAtAPIBoundary|TestSubmitPublicRouteRejectsStructuralReliableBody)$' ./es/api ./es/app
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=600s ./es/admission/internal/reliablesubmit ./es/admission ./es/api ./es/app
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=600s ./...

# 12 and supplemental inspection, both in N1_SOURCE
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestPrivateReplayProgressAdmissionUnknownNoEffects$' ./es/admission
"$GO" list -mod=readonly -deps -test -json ./es/admission
```

Every command received a new immediate guard over 430 actual working files and index blobs, the frozen tree, scoped Git state, and all path inventories. Each staged observation produced SHA-256 `d8605f260d8fdb25c81a6af8b9b00e99fdb1b60159a3f4660575cfac869b0c57`. The distinct observation times below are EST. All stderr and the three empty stdout streams had SHA-256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

| Gate | Exit | Test pass/fail/skip | Packages tested/no tests | Immediate guard time | Stdout SHA-256 |
|---|---:|---:|---:|---|---|
| 1 Go version | 0 | — | — | `17:45:08.665699` | `278375c8a03c34bb0f855154850de7c4f217fd3b8cdf37986819e3f05d0a4c33` |
| 2 Formatting | 0 | — | — | `17:45:09.020364` | empty |
| 3 Unstaged whitespace | 0 | — | — | `17:45:09.340478` | empty |
| 4 Staged whitespace | 0 | — | — | `17:45:09.684398` | empty |
| 5 Owner contracts | 0 | 27/0/0 | 1/0 | `17:45:19.907556` | `5ac1ecbd7a1b525a8475a2f014f631085507ac64ae10e5a1e76a19add0b3361c` |
| 6 Pooled reader | 0 | 16/0/0 | 1/0 | `17:45:31.305706` | `9421c25cb74e742593660e58403bf176802662e65e41453b0071e40fb2794aa6` |
| 7 Internal and historical probes | 0 | 221/0/0 | 1/0 | `17:45:45.342020` | `4fb8e14ec55d7b29aacf7efe3eff8d94aa33431ce0ccf064728fba56471406cb` |
| 8 Admission and typed inventories | 0 | 26/0/0 | 1/0 | `17:46:08.920378` | `327eca717ba8639d0bb17bfe6d684f7c3c056b8db589b8ebfaaefd5ab57b5886` |
| 9 API/App boundaries | 0 | 2/0/0 | 2/0 | `17:46:14.046586` | `fb9cbbae16c9f098859cf2e59fba32194d15b1f56e7b69fdc440ae606dba0798` |
| 10 Four-package suite | 0 | 2062/0/39 | 4/0 | `17:48:24.035863` | `31290f482b5fcc2b097ae047aca58672bcd4eaecb414da205a1b82def057fc16` |
| 11 Full repository | 0 | 5192/0/39 | 21/20 | `17:54:12.188026` | `885155c9716b250f2a74994dc3ed942fd0b1ea1343e26355fafe94fa0709c5ff` |
| 12 External N-1 | 0 | 5/0/0 | 1/0 | `17:54:14.886886` | `257523ccb6e49a30aa83f20ffa853cfd54e91f03c8d249ce1ac78426066d70dd` |
| Supplemental build inputs | 0 | — | 291 records | `17:54:15.465215` | `eed496c9b25f6d93ed8c8b0c8e25633d8efaeb5581b0ca47cd7974f9180ff3d9` |

The fresh test and package identity multisets matched the independent audit. All selector parents ran. Gate 10 was the exact four-package projection of gate 11. The full suite passed `TestResolvedPlanDocumentationTruthAndFiniteInventoriesContract`. The allocator parent passed and recorded helper readiness, the winning outcome, and reaping. Gate 7 passed all 12 pre-COMMIT leaves with zero COMMIT attempts. The historical red and green records remained historical. No selected validation was left unrun.

The 39 skip identities and reason groups were:

- **Two direct helper sentinels.** `TestPrivateReplayObjectAllocatorHelperProcess` reported `allocator helper control, executed by TestPrivateReplaySharedObjectAllocation`. `TestSQLiteClaimStoreLockHelperProcess` reported `helper process only`.
- **One native App witness.** `TestSubmitFlowMountsGovernedArtifactAndLifecycleWithInstalledSourceIdentity` reported `mounted-source native witness not qualified by this test: direct Docker Unix socket unavailable`.
- **Two App daemon prerequisites with specialized messages.** `TestBringupScriptUpCheckDownFullProfile` reported `slice 0 bringup requires a reachable docker daemon: exit status 1 output=Client:`. `TestWorkloadCanCreateAndUseLocalRuntimeIdentityEndpointFromTmpfsWorkspace` reported the healthy Docker daemon prerequisite and the same exit-1 probe failure.
- **Thirty-four App daemon-probe skips.** These reported `docker daemon probe failed: exit status 1 output=Client:`, with retained output identifying the unavailable daemon. The exact identities were:

```text
TestControlPlaneStaticScriptAPIPathCancelSucceeds
TestControlPlaneStaticScriptAPIPathFetchesRetainedResultBundle
TestDiagnosticsScriptRunIDBundleCollectsLifecycleSignalsAndStaging
TestExecuteLoopScriptFailureSummary
TestExecuteLoopScriptSuccessAndDeterministicDigests
TestExecutionCancelRetainsStageRootForDebugging
TestExecutionCancelStopsNomadJob
TestExecutionLogsReturnConflictWhenAllocationNotReady
TestExecutionLogsReturnRealContainerOutput
TestExecutionLoopScriptSuccessRetainsDistinctStageRootsAcrossRepeatedRuns
TestExecutionResultBundleAndStageRetainedAcrossStatusAndRepeatFetch
TestExecutionResultReturns404ForTerminalExecutionWithoutResultOutput
TestExecutionStatusReflectsFailedAllocation
TestExecutionStatusReflectsNomadJobState
TestExecutionStatusRetainsFailedStageRootForDebugging
TestExecutionStatusRetainsSuccessfulStageRootAndLogsStillWork
TestExecutionStatusReturns503WhenNomadUnavailable
TestLifecycleScriptCategorizesExecutionFailure
TestLifecycleScriptObservesExecutionViaPublicRunID
TestRuntimeIdentityIntegrationCapabilityProbe
TestSubmitFlowAllowsConfiguredControlPlaneCallerHandoff
TestSubmitFlowDoesNotStartWorkloadBeforeHelperReadiness
TestSubmitFlowHelperDeathIsTaskFatal
TestSubmitFlowInjectsWorkloadIdentityEndpointAndLifecycleStillWorks
TestSubmitFlowMountsGovernedArtifactAndLifecycleStillWorks
TestSubmitFlowProvidesPlatformOwnedRuntimeIdentityThroughBoundedEndpoint
TestSubmitFlowRejectsRuntimeIdentityPassthroughRequests
TestSubmitFlowRejectsWorkloadArchiveWithSymlinkEntry
TestSubmitFlowRemovesRuntimeMountArchiveResidueAfterExtraction
TestSubmitFlowRunsStaticScriptInNomadDocker
TestSubmitFlowUsesBridgeNetworkWhenNetworkAccessEnabled
TestSubmitFlowUsesConfiguredRuntimeIdentityTmpfsSize
TestSubmitFlowUsesPlatformOwnedIdentityForVaultLoginAndSecretRead
TestSubmitValidOperatorCallerReturnsAcceptedSubmissionReceipt
```

## External N-1 witness

The new view was exported from all 430 actual staged blobs. It added only `I/admission_unknown_witness_bridge.go` and `A/reliable_submit_admission_unknown_witness_test.go` from Appendices D and E. All 432 files matched the view map at SHA-256 `05f6d69aa56210c33ccf6c998502345426ff5e0817365ada213a2a61af1afe53` before and after both external commands. The two witness files remained external throughout staging and commit. Their five test identities were disjoint from the ordinary suite.

| Case | Invocation disposition | Projected revision | Later current revision |
|---|---|---:|---:|
| Establish, canceled recovery | `WriteUnknown` | none | 1 |
| Establish, exact authenticated recovery | `OwnCommitConfirmed` | 1 | 1 |
| AssignRun, canceled recovery | `WriteUnknown` | none | 2 |
| AssignRun, exact authenticated recovery | `OwnCommitConfirmed` | 2 | 2 |

Each case observed one real intended COMMIT, restored the hook before the later read, retained the original, and measured zero provider, staging, and EGS contacts with empty operational roots. The later current reads preserved the original invocation dispositions.

The supplemental inspection reconciled 291 package records and 2,801 physical inputs: 2,289 toolchain, 375 module-cache, 136 view, and one generated cache input. Path translation covered the declared view and cache prefixes only. The bridge appeared in the internal package’s compiled source list, and its internal dependency tests appeared as metadata. The actual generated test main was retained at 57,754 bytes and SHA-256 `07a228ee0649b9846a21c3293b2171364db3ced5d64e10020f9cb317122877b4`. The fresh normalized graph SHA-256 was `302b8f6eefe9e7a6cf85aad97fb5ee41a761194ceb3af93f01eb5a497e01a4ba`.

## Commit closeout and limits

The single command `/opt/homebrew/Cellar/git/2.49.0/bin/git commit -m 'feat: add private original replay with durable progress'` ran from the target checkout and exited 0. Its stdout SHA-256 was `5cfee29829820db00c6505d0211ea55bd76e31ad70e788690fae4f8365c62a3e`, with empty stderr. The independently read commit object had the exact subject, sole parent, and frozen tree. The commit range contains exactly one new commit. The full committed diff equaled the frozen staged diff byte for byte, and the parent delta contained exactly 27 modifications and three additions. HEAD, the complete index, and all 430 working files agreed. The staged, unstaged, unmerged, ordinary-untracked, and ignored inventories were empty. The closing guard authenticated to `380b3092685c8e99081417ce0fc96c9ba96d1bf8ece5a3d6c3438a73bb2eb507`.

The gate preserved the selected `synthetic_progress_nonoperational_v1` scope, M-1 and DOC-SYNC closure, earlier repairs, and the existing ES, SQLite, custody, and Coordinator ownership boundaries. Qualification remains limited to private synthetic fixture evidence. Physical-close success, hard timing, double-withholding capacity, SQLite file and sidecar byte preservation, real provider and receipt claims, native and operational qualification, cross-restart write-uncertainty authority, and remote publication or CI eligibility remain outside the result. The observation pool’s unchecked close return on refusal remains part of the accepted bytes.

Cleanup removed only `cache`, `gotmp`, and `tmp` under the gate root. Both copied probes were returned to `0600`. The external source view retained source modes, private directories are `0700`, and retained evidence is `0600`. The artifact index lists 252 private files, including the report, and 432 source-view files. It excludes itself.

- Private report SHA-256 `e1813a68c168c18879ef7e369c64638835aca4c05805f2141fae36d6e76a6999`. [Private report](/Users/ds/Repositories/ES-Private-Replay-Progress-Commit-Gate-20261119-U0JC7ELW/report.md)
- Self-excluding index SHA-256 `858d4b7208532dd2d1c45a847c207d9236f09624a958a48251e81d3c21d3a153`. [Artifact index](/Users/ds/Repositories/ES-Private-Replay-Progress-Commit-Gate-20261119-U0JC7ELW/artifact-index.json)

```text
ES_PRIVATE_REPLAY_PROGRESS_LOCAL_COMMIT_CREATED
SOURCE_BYTES_NOT_CHANGED_BY_COMMIT_GATE
THIRTY_ACCEPTED_PATHS_COMMITTED_EXACTLY
PUSH_NOT_PERFORMED
REMOTE_TOPIC_NOT_CREATED_BY_THIS_GATE
PRS_NOT_CREATED_OR_MODIFIED
MERGE_NOT_PERFORMED
AUTO_MERGE_NOT_ENABLED
EXISTING_SOURCE_CHECKOUTS_NOT_SYNCHRONIZED
RUNTIME_WIRING_NOT_PERFORMED
PUBLIC_RELIABLE_SUBMIT_NOT_ENABLED
CROSS_RESTART_OPERATIONAL_WRITE_UNCERTAINTY_GATE_NOT_IMPLEMENTED
NATIVE_INSTALLED_SOURCE_WITNESS_NOT_QUALIFIED_BY_THIS_SLICE
```
