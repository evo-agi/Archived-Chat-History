# Execution Substrate — M-1 pre-COMMIT / owner-inventory repair: fresh independent audit

Date: 2026-11-19 (America/New_York)
Engagement: independent repository-read-only audit of the complete exact candidate.
This turn does not authorize product repair, staging, commit, publication or runtime effects.

## Objective, routing and decision boundary

Start a FRESH read-only Codex conversation, not the conversation that authored
this repair. The only source/provenance/test target is:

    /Users/ds/Repositories/ES-Private-Replay-Progress-v1

Use explicit command working directories. The author conversation may remain
attached to /Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1; do not move,
synchronize, fetch, reset, copy the patch into, or write that checkout or any
other source checkout. A different initial shell cwd is not itself source drift.
Verify the actual target and work there. If inaccessible, stop without substituting
another checkout or requesting a new source candidate.

Independently adjudicate the two remaining findings:
- M-1 residual: the already-closed-wrapper pre-COMMIT rollback branch must safely
  reach the unpublished opener's checked nonmigrating observation, not infer an
  outcome from wrapper state or silently retry migration.
- DOC-SYNC: admission §7.4 must match the existing exact source synchronization
  and permit inventories without narrowing their source scope or widening authority.

The complete thirty-path slice also remains the acceptance target. The previous
audit independently resolved M-2, SR-1, SR-2, K1-1, T-1, R2-1 and N-1, and M-1's
original lock-order defect, for its own bytes. Authenticate those findings and
verify preserved bytes and interactions. Do not reopen their design choices by
default or ignore a concrete newly discovered defect. The current repair's six-file
delta does not inherit a blanket ACCEPT from any earlier report.

ChatGPT's Appendix E is a targeted static review, not proof of correctness or a
required verdict. It found no additional blocker and executed no product code.
Reach an independent conclusion from owner contracts, actual source and evidence.

## 1. Exact source target and opening gate

Required source identity:
- physical and Git top-level: /Users/ds/Repositories/ES-Private-Replay-Progress-v1
- Git and common directory: this standalone checkout's own .git
- branch: codex/private-replay-progress-v1
- upstream name: origin/trunk_dev
- origin: git@github.com:evo-agi/Execution-Substrate.git
- HEAD: f1aa8b934cc26c16a966a110c7b408abdaeadce7
- sole parent: fb9ae55797d9fcc02863c23fe8d3e43d16eac542
- HEAD tree: 8dd27f9acba98ed70d93736bdef8300ef1aba53f
- HEAD subject: Harden original-key read transaction cleanup (A1) (#10)
- index: exactly the 427-entry HEAD tree
- physical candidate: 430 leaves: 400 HEAD-identical, 27 tracked modifications,
  and exactly three existing ordinary-untracked additions
- every candidate row: regular 0644; no staged, unmerged, deleted, renamed,
  type-changed, ignored or extra source path.

Exact final canonical target is Appendix B, 6,813 bytes:
    f92b57f48a701a606e8a0697b75dac8f691e3eb44c13b9c92afb894ec6e1d718
Tracked full-index HEAD diff:
    793e6697cf2342ce41f08ed8f59a0a14eb5c288c74780f158731d55dbe17bcca

Exact active recipe is Appendix C, 7,275 bytes:
    governed-execution.audit-patch-manifest.v2
    c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca

Read and authenticate all appendices before using executable inputs. Run the
unchanged recipe twice from the actual checkout into two absent files in one
new private external root. Match Appendix B bytes exactly, not merely fields
copied from a report. Independently read every candidate row and all 400 other
HEAD blobs/working files. Read complete index entries and both untracked lists.
A recipe/source/target mismatch stops source review with AUDIT_PROVENANCE_MISMATCH.
Do not fix, replace, reserialize, stage or normalize candidate bytes to pass.

The three expected ordinary-untracked sources are:
    es/admission/internal/reliablesubmit/replay_progress_test.go
    es/admission/internal/reliablesubmit/sqlite_pooled_claim_read_cleanup_test.go
    es/admission/internal/reliablesubmit/sqlite_replay_progress_schema.go

Record source-scoped branch/ref/config state at opening and closeout. Historical
whole-ref aggregates, mtime and inode allocation are not identity gates. Do not
require every unrelated Codex/helper ref to match old observations. HEAD, branch,
upstream name, candidate bytes, index and origin must meet the selected target;
record an unrelated upstream-ref movement separately for later publication
reconciliation without fetching, rebasing or changing the source. No current
remote read is needed for this local acceptance audit.

### Required archive and six-row comparison

Current packet, in the author's evidence root:
    /Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/ES-Private-Replay-Progress-M1-Owner-Repair-Review.zip
955,015 bytes:
    3b27c483036296304a9fbca77dcd5fe522dee64b8eabf392057b6c573160f59a

Reference packet:
    /Users/ds/Repositories/ES-Private-Replay-Progress-Consolidated-Repair-20261119-S2jmvkfy/ES-Private-Replay-Progress-Consolidated-Repair-Review.zip
900,863 bytes:
    e3cac3bc27bbfd8c1c18d1abf3aabc00077e632e14bd6e6b92e26e020c9c1be6

Reference canonical target:
    0812091529c67f4bc46d0bc343b3dea8595e63a461264e143d51606e581e0c06
Reference tracked HEAD diff:
    68339ba85b7b22d86bdaa21ed4fdccebc5021f82912344e0507862d1624cb791

Authenticate safe unique regular archive members, all inventory records, canonical
manifests, source map and complete payloads. The current packet has 47 entries and
46 self-excluding inventory rows. Source rows must equal actual live source.
Verify all three patch relations using disposable external copies if needed;
do not apply any patch to the candidate.

Exactly these six rows differ from the reference:
1. PLANS.md
2. .docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md
3. .docs/execution_lifecycle/es_execution_admission_model.md
4. docs_contract_test.go
5. es/admission/internal/reliablesubmit/sqlite_store.go
6. es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go

Other 24 candidate rows must remain byte/mode-identical. Source delta is within
the same total thirty-path set; there is no thirty-first path. Confirm the store
change is limited to openSQLiteClaimStore, migrateSQLite, the private recovery
signal and verifyMigrationRecovery commentary. Its classifier executable body,
loadClaim, loadClaimFresh, shared helpers, claim/grant/CAS paths and seams are frozen.

Relevant delivery digests:
    full opening delta:
      211a5522dfc8b5401f7361c5148ce53dc7eaef06e56787231e2624783d064cc2
    tracked-opening delta plus additions:
      951c9353a69a37340f122bfd92b4c17ec3e2f514c70cd1e614d7665c3cf0175c
    source map:
      d8bae35ede66a6b66b093e457a879ba4b633c7b8dc14ad7c8742801f2a3fc976
    delivery inventory:
      a24629ff1c02e4498dcb5a7f66779faf4057d29b00bce9b756572d77236cd6ee

The older 66-character replay_custody_structure.go hash is a closed transport
transcription incident. Appendix B, both relevant actual archives and the live
file must contain the correct digest:
    4916268757b93d409cbc13ba9c0da14e009499b4db7cadd52bc7ccd47c6a86ad
Do not relitigate that historical pasted field or change source to match it.

## 2. Governing contracts and material evidence

Read the actual AGENTS.md, PLANS.md, pertinent .docs guidance, persistence ADR
§15B (especially §15B.5), admission §7.4/7.5 and §6B, submit/recovery fixture
contract, changed source/tests and relevant unchanged callers. Review source,
tests, schemas, scripts/config/examples and source reachability together where
they bear on the private/operational boundary; do not launch a broad new redesign.

Classification remains a Bounded slice rule refinement on the reliable-submit
Reopened redesign seam, limited to synthetic_progress_nonoperational_v1.
ES's existing durable service remains semantic claim writer; SQLite owns committed
claim/progress/key/grant state. Custody owns original authentication and private
object handling. Invocation-local synchronization and test evidence do not create
durable authority. Coordinator programme progression remains separate. Neither
CP compatibility nor helper repositories become core orchestration authority.

The fixture scope, global caller/key occupation, one original/attempt/run, codec
separation, K1 per-invocation knownness, R1 historical reconciliation and R2 shared
allocation remain selected. Public structural reliable-request refusal and
unkeyed Submit remain current boundaries. No runtime caller, state/key provisioning,
provider effect, native qualification or operational no-dispatch proof is enabled.

Authenticate a material subset, not every historical file/root:
- latest repair root:
  /Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE
  repair-report.md SHA-256:
    6c249d2f2c2b219b6b07ba57d3236ab37d8ffbc1eb2872986489547c2e629f49
  artifact-index.json SHA-256:
    82860422eaa259508b55b4f5911925ca5d7cc6b3d8aff66fa178e7e9aef7d939
- latest rejecting independent audit:
  /Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB
  artifact-index.json SHA-256:
    0fd8c79d0b2ac8e20f23aadd92045b03df30528e07331225aa58f124fb0a43bf

Use authenticated indexes to resolve actual filenames, not guessed private paths.
Check report/source-map/freezes, new regression construction and raw red/green
logs, final eleven command logs/exit/identity records and each immediate guard,
generation-1 failure and final notation correction, store preservation, and N-1
view/build records actually relied on. Read the complete previous REJECT in
Appendix D. Its preserved source and failed diagnostic are historical evidence:
diagnostic source e0b662c8c5d084b209362be82ad54198a7cee85fa1966e9228953bbedad3ba21;
raw log 28b632fc2d5c1a9cac35586eb0ca7454ff7d9530c22a8c04c12c0a5a728b2375.

Transport and private duplicate reports may have different hashes while agreeing
on decision facts. Appendix A preserves the complete supplied transport exactly.
Do not require a missing historical whole-report duplicate where earlier records
explicitly did not contain one. No need to rehash all 4,901 or other prior records.
Do not overwrite history, import scripts in place, restore timestamps or rewrite
evidence to claim that earlier failed generations passed.

## 3. Four independent read-only perspectives

After the opening provenance gate, spawn exactly four read-only reviewers.
Give each a self-contained capsule: actual root, exact manifest bytes/hash, full
objective, prior findings, source/target distinction, authority limits, non-goals,
coverage and standard finding format. Do not assume explorer context forking.
No nested agents, writer agents or concurrent test runners. Subagents inspect;
the foreground alone runs authorized builds/tests and owns the audit conclusion.
If a reviewer is unavailable, permit at most one retry; report missing coverage
and do not fabricate independent concurrence. Wait for all and close all.

1. SQLite/opening and recovery:
   entire migration lifecycle, M-1 old/new branch, invalid baselines, connection
   ownership, pool disposition, classifier, cancellation/error precedence,
   migration 1–4 preservation, probes and existing cleanup boundaries.
2. Owner contract and synchronization:
   DOC-SYNC field/category and permit tables against exact typed declarations,
   new root checker/mutants, notation-only companion assertions, no A3/public
   authority widening, private source versus operational reachability.
3. Durable/custody/admission interactions:
   complete integrated original/progress and invocation paths; preserve the seven
   prior resolved findings, callback lifetime, terminal synthetic evidence,
   known-write versus projection, allocation and no-effect exclusions.
4. Evidence, regressions and scope:
   six-file/24-row preservation, red/green causal inputs and setup failures,
   generation 1 versus 2, exact argv/parents/skips/guards, N-1 source and build
   binding, external-only diagnostics and artifact hygiene.

Each reports inspected files/line ranges, concrete findings with severity and
type, source versus executed/retained evidence, inherited versus introduced,
unvalidated claims, disagreements and remaining limits. A passing count cannot
override a substantive defect. A residual outside-slice qualification is not
automatically a new blocker.

## 4. Required M-1 adjudication

Inspect the complete functions, not only the new sentinel branch:
- openSQLiteClaimStore around :58–130;
- openGate and verifySQLiteOpening around :557–602;
- verifyMigrationRecovery around :625–667;
- migrateSQLite around :669–751;
- maintained test :715–811 of sqlite_replay_migration_test.go;
- unfiltered witness :579–624;
- owner §15B.5 around :1706–1755.

Answer these specifically:
A. Is the readback signal reachable only with the required authenticated
   lock-held baseline and eligible migration uncertainty? Invalid BEGIN/opening
   or a default version cannot acquire recovered-old/current authority.
B. Is rollback independently bounded, and its context sampled before self-cancel?
   Does a timely ordinary rollback preserve ordinary refusal without fabricating
   migration uncertainty?
C. Does a closed wrapper transfer ownership rather than establish success?
   A live wrapper with unconfirmed disposal must not allow premature readback.
   The migration-local route must not weaken shared ErrConnDone/discard behavior.
D. Does original openGate connection ownership end before original pool close,
   and is that close checked before opening the independent observation pool?
   No old pool can be exposed as accepted or used for classification.
E. Does recovery call a NONMIGRATING classifier once, retain the caller context,
   refuse failed/canceled/mixed/invalid observations, and return no handle for an
   authenticated old/pristine state? Verify final context precedence and closure
   of the fresh observation pool on refusal.
F. Does a qualified current observation remain observational, not an own-COMMIT
   claim for an invocation with zero COMMIT attempts? Preserve existing accepted
   current and actual-COMMIT/lost-response recovery semantics.
G. Is there no migration replay, implicit second mutation, repair/adoption,
   attempt reset, new source hook or new process-wide mechanism?

The maintained regression must reach real in-transaction schema 4 through
beforeMigrationCommit for schemas 0–3, invalidate the actual wrapper, and count
ZERO commitMigration invocations. Do not substitute a failure in migrationCommit
after commitAttempted has been set. Confirm full independent old-state witnesses,
populated schema-3 claim/key/grant/ledger/seal coverage, and that observations occur
before normal reopening/teardown. Inspect the OrdinaryRollback and CanceledReadback
controls; they must not pass by performing hidden recovery writes.

Authenticate retained red inputs against the rejected opening source and green
against final source, with identical maintained regression bytes. Red is reported
8 pass / 5 fail including parent, green 13 pass. Raw logs must show substantive
classification failures, not setup/compile failure. A fresh replay of every
historical red is not mandatory when the retained binding is sufficient; the
repaired maintained regression MUST run freshly in gate 6. A narrowly scoped
external diagnostic is permitted when needed to investigate a concrete unresolved
branch, but it may neither repair the candidate nor become a general fault platform.

Do not convert successful pool exclusion or invocation of driver Close into a
physical-close or hard-latency guarantee. Authenticate the pinned local Go/SQLite
source where a conclusion depends on it. Actual OS/device-close failure and
double-withholding capacity are retained qualifications, not silently proven.

## 5. Required DOC-SYNC and preservation adjudication

Compare the exact documented thirty-two field identities against
TestExecutionSubstrateProductionHasNoA3LeaseRegistryOrPoisonDesign's frozen literal,
and actual typed scanner/declarations. Verify five direct locks, three atomic.Bool
fields, twenty-four carriers. Do not call these thirty-two independent locks.
Verify lifetime, protected fact and reader/writer roles, both permit wrappers,
shared publisher, matchesAllocation, consume and burn. Confirm non-test production
source includes the private fixture definitions despite runtime nonreachability.

Read TestPrivateReplayProgressSynchronizationInventoryDocsContract and its helper.
It should extract the selected finite literal, compare field/category sets and
permit roles, and fail the actual stale owner plus the four intended mutants for
their intended reasons. It supplements, not replaces, the unchanged typed scanner.
Confirm §7.5 A3 exclusions are preserved. The three older resolved-plan assertions
must still check the same lock identities under corrected notation.

Both selected typed Workstream C parents run in gate 7. The older resolved-plan
test also runs under the full repository gate; no assertion may be skipped or
weakened to avoid the recorded generation-1 failure.

Verify all 24 frozen source rows and relevant complete integrated interactions.
Individually record preservation/disposition of M-2, SR-1, SR-2, K1-1, T-1, R2-1,
N-1 and the original M-1 lock-order fix. Their architecture is not reopened absent
new contrary evidence. Verify unchanged migration literals and legitimate shape
hashes, formats, original/row identity, key/grant semantics, public refusal and
unkeyed path. The final loadClaimFresh function including separator must remain
1,077 bytes at:
    3a47f8b5e0c5bf7bec899987aa78fdf4ef48a585086d9eb975e576896ab4b61c

This audit may rely on authenticated historical evidence for unchanged controls,
but cannot ACCEPT solely on the previous author/auditor's judgment. Inspect the
complete integrated slice and the code paths affected by opening/recovery.

## 6. Environment and authorized local effects

Create one new exclusive private root outside all source/old evidence:
    ES-Private-Replay-Progress-M1-Owner-Independent-Audit-20261119-<unique>
under /Users/ds/Repositories. Set AUDIT_ROOT to it. Directories 0700; retained
non-source evidence 0600; preserve actual copied-source modes. Never chmod the
existing parent or old roots. Do not reuse a prior run directory.

Preflight pinned local Go 1.26.5 darwin/arm64 and sibling gofmt, known-good Python
3.13.4 with tomllib, OpenSSL 3.6.2 and Git 2.49.0; record actual paths, versions
and hashes. Record substantive differences before execution. Do not install,
download or silently select Apple Python/LibreSSL. Use cached modules:
    GOTOOLCHAIN=local
    GOPROXY=off
    GOSUMDB=off
    GOWORK=off
    GOFLAGS=-mod=readonly
    CGO_ENABLED=0
    GOTELEMETRY=off
    GOMODCACHE=/Users/ds/go/pkg/mod
    GIT_OPTIONAL_LOCKS=0
    GIT_NO_LAZY_FETCH=1
    GIT_TERMINAL_PROMPT=0
    PYTHONDONTWRITEBYTECODE=1
Use Python -B, audit-owned GOCACHE/GOTMPDIR/TMPDIR, outer umask 077 and Go-test
subprocess umask 027. Copy authenticated helper/verifier source before importing
or running it; never create bytecode in prior evidence roots.

Existing maintained tests may use their test-owned /tmp or /private/tmp fixtures,
helper processes, loopback mocks, test certificates and disposable Git fixtures.
They may perform read-only Docker capability probes. This does not authorize
starting Docker, a live stack, live services, host operations, real keys, network
Git, dependency download, deployment or operational database migration. If host
capability would newly enable an unapproved live test, classify that conflict;
do not silently invoke it or manufacture a skip. No global temporary-file sweep.

Authenticate and copy, without rebuilding, the two distinct historical probes:
- PB1/schema 2: 14,350,930 bytes,
  b205a31bac091cbcf5b3f4826bc359455625316908051131733622813e34adcf
- previous schema 3: 15,601,186 bytes,
  42614a50812a65ba52b53488d872884e59ce7b4f57dece6a66642d4eb8de1409

Use ES_REPLAY_PB1_PROBE and ES_REPLAY_SCHEMA3_PROBE for those owned copies. The
tests bind distinct child target variables; any direct child invocation must do
so explicitly. Preserve PB1's schema-3 refusal and the schema-3 opener's schema-4
refusal as different claims. Authenticate the relied-on source/overlay/build
bindings (including schema-3 inventory
50a81fa5a042e135abfc9f6bad68d20abc4575f881945ecc84252c14910dde8f).
Missing historical binary evidence is a declared gap, not permission to rebuild
an "old" opener from the current source. Restore copies to 0600 after execution.

## 7. Fresh N-1 view and test-evidence boundaries

Build a NEW audit-owned source view from all 430 actual frozen candidate leaves,
plus the exact Appendix F and G inputs:
F -> es/admission/internal/reliablesubmit/admission_unknown_witness_bridge.go
G -> es/admission/reliable_submit_admission_unknown_witness_test.go

F/G are EXTERNAL ONLY. They must remain absent from the candidate and ordinary
full-suite source. Preserve source modes under private parent directories. Bind
all 432 files before and after execution. Do not reuse the author's older source
view or treat the copied bridge as an accepted product API.

Inspect the bridge and assertion call paths. It attaches/restores only the
selected store's existing hook, executes real COMMIT then models response loss.
Freshly verify all four establishment/AssignRun × canceled/exact-recovery cases,
disposition versus projected revision versus later-current revision, one intended
commit, retained original, zero provider/staging/EGS counters, and empty operational
roots. The hook is removed before later reads; later current state does not
rewrite an earlier unknown invocation.

Authenticate archived metadata/inputs and construct fresh build bindings. The
author reports 291 package records and 2,801 physical inputs with a retained
generated test-main. Those counts are evidence to reconcile, not values to force.
Read actual production compiled inputs and distinguish dependency test metadata
from package compile inputs. Normalize only declared root/cache prefixes when
comparing graphs; never normalize differing source bytes. Preserve actual generated
source used as evidence before deleting caches. The optional go list command
below is authorized build-input inspection and must be reported separately from
the eleven primary acceptance commands.

## 8. Independent validation and immediate guards

Before testing, verify a checker actually covers all 430 source leaves and modes,
HEAD/branch/upstream/index, complete path classification, and BOTH:
    git ls-files --others --exclude-standard -z
    git ls-files --others --ignored --exclude-standard -z
The first list must equal exactly the three authorized source additions; the
second must be empty. Also verify no staged/unmerged/extra paths.

Execute a new checkpoint after EVERY command and external experiment, and at
closeout. Record actual command/checkpoint association, not copied earlier
results. Identical deterministic hashes can be correct but do not prove repeated
observation by themselves. Also guard all 432 N-1 view files around its command.

Run the eleven primary commands below serially once on the frozen candidate.
Commands 1–10 run in the actual progress checkout. N1_SOURCE is a new audit view.
Inspect environment, selector names and child probe binding before invocation.

If a substantive blocker is confirmed, all source perspectives still finish and
the parent consolidates findings. Broad gates 9/10 that cannot change REJECT may
be omitted with an exact unrun-command inventory. A distinct bounded finding/N-1
diagnostic may still be material. ACCEPT requires all eleven primary commands,
every mandatory parent, no new bounded-path skip, satisfied source judgment and
closing provenance. A green author report alone cannot satisfy fresh acceptance.

Correcting an external setup error may produce a declared new generation with
failed attempts preserved. Never rerun a substantive failure until it disappears,
relax assertions, mask a capability result, change candidate bytes, or edit an
expected source digest to achieve acceptance. Bounded external instrumentation
for a concrete review question is permitted if complete exact inputs are retained
and it does not repair product behavior. No socket campaign, physical-close
platform, broad fuzzing, old PB1 rebuild or historical fourteen-gate ladder.

### Exact primary commands

```sh
GO=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go
GOFMT=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/gofmt
I=es/admission/internal/reliablesubmit
A=es/admission
N1_SOURCE="$AUDIT_ROOT/n1-source"

"$GO" version
"$GOFMT" -d docs_contract_test.go "$I/sqlite_store.go" "$I/sqlite_replay_claim.go" \
  "$I/sqlite_migrations.go" "$I/sqlite_replay_progress_schema.go" "$I/sqlite_replay_shape.go" \
  "$I/durable_record.go" "$I/durable_operation.go" "$I/durable_service.go" \
  "$I/replay_custody_format.go" "$I/replay_custody_structure.go" "$I/replay_custody_file.go" \
  "$A/reliable_submit_replay_format.go" "$A/reliable_submit_replay_hydration.go" \
  "$A/reliable_submit_replay_private.go" "$I/sqlite_pooled_claim_read_cleanup_test.go" \
  "$I/replay_progress_test.go" "$I/replay_custody_file_test.go" "$I/sqlite_store_test.go" \
  "$I/sqlite_physical_test.go" "$I/sqlite_replay_migration_test.go" \
  "$I/sqlite_replay_shape_test.go" "$I/guardrails_test.go" "$A/reliable_submit_guardrails_test.go" \
  "$A/reliable_submit_replay_private_test.go" "$A/workstream_c_guardrails_test.go"
git --no-pager diff --check
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateReplayProgressSynchronizationInventoryDocsContract|TestPrivateOriginalReplayProgressContractSelection|TestReliableSubmitPersistenceAndConcurrencyADRDocsContract|TestSubmitIdempotencyCorrelationAndRecoveryDocsContract|TestReliableSubmitPureModelDocsAndSourceContract|TestReliableSubmitPublicOptInAndVersioningDocsContract|TestReliableSubmitContractAdapterFoundationDocsAndSourceContract|TestReliableSubmitBindingProducerDocsContract|TestIntegratedAcceptanceGateDocumentationIsConsistent|TestIntegratedCandidateStatusSeparatesCAndT)$' .
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestSQLitePooledClaimReadCleanup$' ./es/admission/internal/reliablesubmit
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestSQLiteMigrationPrecommitClosedWrapperRecovery|TestPrivateReplayProgressConfirmationEligibility|TestPrivateReplayProgressReconciliationEligibility|TestPrivateReplayProgressTerminalEvidenceBinding|TestSQLiteMigrationOpeningRevalidatedUnderLock|TestSQLiteLiteralInternalNamespaceQualification|TestPrivateReplayScope1PublicationPreflight|TestPrivateReplaySharedObjectAllocation|TestReplayPublicationFaultAndIdentity|TestPrivateReplayProgressFormatVectors|TestPrivateReplayProgressTransitions|TestPrivateReplayProgressConcurrencyAndCommitOutcome|TestSQLiteV4MigrationPreservesFullState|TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation|TestSQLiteV3OldBinaryRefusesWithoutMutation|TestSQLiteLegacyCASConnectionCleanup|TestReplayOriginalKeyReadCleanup|TestReplayOriginalKeyReadCallerRefusal|TestReplayGrantC1PreCommitConnectionQuarantine|TestReplayGrantD1BeginResponseLossQuarantine|TestReplayKeyStateD1BeginResponseLossQuarantine|TestReliableSubmitPrivatePersistenceStaticGuardrails)$' ./es/admission/internal/reliablesubmit
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestExecutionSubstrateProductionHasNoA3LeaseRegistryOrPoisonDesign|TestExecutionSubstrateSynchronizedMutableStateReferenceInventoryIsExact|TestPrivateReplayProgressOccupiedDisposition|TestPrivateReplayProgressAdmissionReplay|TestPrivateReplayProgressHasNoEffectPaths|TestReliableSubmitFoundationHasNoRuntimeWiring|TestReliableSubmitBindingProducerHasNoProductionCaller|TestPrepareRequestShapeRemainsLegacyAndUnkeyed|TestResolvedSubmitLegacyEquivalenceOneNomadRegistrationAndAuthorityRecovery)$' ./es/admission
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestWorkstreamCContractPrepareAndSubmitRemainSeparatedAtAPIBoundary|TestSubmitPublicRouteRejectsStructuralReliableBody)$' ./es/api ./es/app
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=600s ./es/admission/internal/reliablesubmit ./es/admission ./es/api ./es/app
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=600s ./...
(cd "$N1_SOURCE" && "$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestPrivateReplayProgressAdmissionUnknownNoEffects$' ./es/admission)
```

Optional separately reported build-input inspection:
```sh
(cd "$N1_SOURCE" && "$GO" list -mod=readonly -deps -test -json ./es/admission)
```

Generation-2 report expectations, to authenticate and compare by identities:
- owner contract gate 27/0/0;
- pooled reader 16/0/0;
- internal focused/probes 221/0/0;
- admission including two typed Workstream C parents 26/0/0;
- App/API 2/0/0;
- four-package suite 2062/0/39;
- ordinary full tree 5192/0/39; 21 tested packages, 20 with no tests;
- external N-1 5/0/0, disjoint from ordinary suite.

The ordinary full suite adds 13 migration identities and 5 doc-owner identities
over the previous independent 5174, with zero removals/renames. Verify the 39
skip names/reasons rather than counting them as successes: two direct helper
sentinels and 37 App capability cases. The allocator parent must demonstrate
helper readiness, executed outcome and reaping; its direct sentinel skip is
not skipped allocator proof. Native installed-source witness remains unqualified.

Retain and inspect generation-1's 5191/1/39 result and unrun N-1 gate: the sole
failure was the older resolved-plan test's three old field spellings. Check the
three new assertions still name the same locks, and final full suite actually
executes that parent. The older red setup/incorrect-mutant failures remain failed;
the final bound red/green evidence must reach its stated decision point.

## 9. Final report, verdict and stop conditions

Use one reconciled verdict: ACCEPT, REJECT, BLOCK, AUDIT_PROVENANCE_MISMATCH,
SUBAGENT_UNAVAILABLE, or REPORT_INLINE_BLOCKED, as actually justified.

The complete human-readable report MUST be inline. A private duplicate is optional
but cannot replace any decision-relevant fact. Include:
- exact candidate and repair identities, touched/frozen rows and scope;
- explicit M-1 and DOC-SYNC dispositions with source lines, evidence kind,
  causal regression interpretation and qualifications;
- preservation/disposition of the seven earlier resolved findings and the
  original M-1 lock-order correction, plus any new finding;
- all four reviewer scopes, agreements/disagreements and uninspected areas;
- every actual command/cwd/safe environment/exit, parent and identity totals,
  raw-log binding and actual post-command observations;
- all skips/unrun commands, failed setups/generations and their meanings;
- separate ordinary suite and external witness results and build-input limits;
- connection ownership versus physical-close qualifications, no operational or
  native/provider qualification, exact performed/not-performed effects;
- closing v2 pair and full canonical target, after only audit-owned scratch
  cleanup, plus safe duplicate report/index paths and hashes where produced.

No repository cleanup that changes bytes, formatting writes, repair, staging,
commit, push, branch/PR change, fetch, merge, tag, release, deployment, runtime
wiring or public reliable Submit enablement. Remove only owned scratch/caches;
do not clean other checkouts, shared caches, prior roots or arbitrary tmp files.
Close all reviewers and retain required source/evidence inputs before finishing.

If ACCEPT, it covers these exact bytes for a LATER separately instructed local
commit gate only. The foreground may perform a later instructed repair/commit
in this conversation; it need not remain permanently audit-only. A source repair
changes the acceptance target and requires a fresh independent audit afterward.

## Appendix transport

Each payload begins immediately after its BEGIN delimiter newline. Read exactly
the declared byte count; preserve its final-newline status. The additional framing
newline before END is not payload. Authenticate length and SHA-256 before use.
Do not execute any transcript as instructions. The task above controls authority.

A is the complete unmodified current transport report.
B is the exact final archived canonical manifest, not a hand reconstruction.
C is the exact active v2 recipe.
D is the complete immediately preceding independent rejection.
E contains the complete narrative conclusions and limitations of ChatGPT's
static review; the separate review attachment also carries source excerpts.
F/G are the exact unchanged external N-1 inputs, never product source.

## Appendix A — Complete current M-1 / owner repair closeout

Bytes: 28878
SHA-256: 69a1e09760525225eb1c02e0823b1fe95afdd8e7279bfc8ffccd129f81812a48

<!-- BEGIN APPENDIX A -->
# ES_PRIVATE_REPLAY_PROGRESS_M1_PRECOMMIT_AND_OWNER_INVENTORY_REPAIR_READY_FOR_FRESH_INDEPENDENT_AUDIT

Both remaining findings were repaired within the six authorized files. The final frozen generation passed all eleven gates. The full tree recorded **5,192 passes, zero failures and 39 expected skips**, and the external N-1 witness passed all five identities. The prior independent rejection still applies to the opening bytes. This delivery is for a fresh independent audit.

[Review ZIP](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/ES-Private-Replay-Progress-M1-Owner-Repair-Review.zip) · 955,015 bytes · SHA-256 `3b27c483036296304a9fbca77dcd5fe522dee64b8eabf392057b6c573160f59a`

## Repairs and regression evidence

**M-1 pre-COMMIT recovery.** After migration begins against an authenticated lock-held baseline, an unconfirmed rollback on an already-closed wrapper can now hand cleanup to the unpublished opener. The migration-local signal also carries the existing post-COMMIT response-loss route. It grants no outcome by itself. The original connection ownership ends, the opener checks the original pool’s close result, and one fresh checked nonmigrating observation classifies the file. An authentic old state returns `errClaimStoreMigrationRecoveredOld` with no handle. A qualified current state is an observation of that head. Canceled, failed or unqualified observations remain unavailable. A timely ordinary rollback retains ordinary refusal. Recovery issues zero migration retries. [SQLite opener and migration](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_store.go:59) · [Persistence ADR §15B.5](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1712)

The maintained differential used the same regression bytes with opening and repaired SQLite production source. On opening source, all four closed-wrapper cases for schemas 0–3 returned `errClaimStoreUnavailable` and failed the recovered-old assertion. On repaired source, all four returned `errClaimStoreMigrationRecoveredOld`. The eight ordinary-rollback and canceled-readback controls retained generic unavailable in both runs. All 12 cases reached verified schema 4 on the exact transaction connection, entered the migration once, attempted zero COMMITs, returned no usable handle, and preserved the unfiltered schema, application/version pragmas, table rows and rowids in an independent nonmigrating read. Populated schema 3 included claims, keys, grants, ledger and a sealed original whose bytes were also checked. Wrapper closure and the pre-COMMIT error were modeled through the existing collaborator. SQLite transactions and the readbacks were real. [Maintained regression](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go:715) · [Red log](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/migration-red/stdout) · [Green log](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/migration-green/stdout)

**DOC-SYNC.** Admission §7.4 now enumerates the exact 32 fields in non-test production source: five direct locks, three `atomic.Bool` fields and 24 transitive references, requests or wrappers. It records both permit wrappers, the shared `publishReplayOriginal` reader, and the `matchesAllocation`, `consume` and `burn` roles. The fixtures remain runtime-unwired, and SQLite owns committed claim, progress, key and grant/use facts. The root test compares exact field identities and categories with the frozen typed-inventory literal. The actual stale opening document failed. The repaired document passed checks for a missing atomic, omitted scope-2 wrapper, omitted shared reader and a carrier misclassified as a primitive. The existing resolved-plan contract now checks the same three lock identities using the corrected notation. [Admission §7.4](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/es_execution_admission_model.md:910) · [Root contract test](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/docs_contract_test.go:12556)

The six changed files were [PLANS.md](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/PLANS.md:5), the two owner documents, `docs_contract_test.go`, `sqlite_replay_migration_test.go` and `sqlite_store.go`. The other 24 candidate rows and 400 HEAD-identical leaves stayed byte- and mode-identical. Within `sqlite_store.go`, the only changed functions or function comments were `openSQLiteClaimStore`, `migrateSQLite` and `verifyMigrationRecovery`, plus the private recovery signal. The rest of the file matched opening byte-for-byte, including `loadClaim`, `loadClaimFresh`, shared transaction and discard helpers, claim/grant/CAS paths, A1/O2/C1/D1 and all existing seams. The 1,077-byte `loadClaimFresh` body retained SHA-256 `3a47f8b5e0c5bf7bec899987aa78fdf4ef48a585086d9eb975e576896ab4b61c`. The Workstream C source, schema literals and hashes, formats, and other seven prior finding repairs were preserved. [Source map](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/source-map.json) · [Store preservation proof](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/preserved-store.json)

## Provenance and delivery

The physical and Git top-level was `/Users/ds/Repositories/ES-Private-Replay-Progress-v1`, with its own `.git` as the common directory. Branch `codex/private-replay-progress-v1` tracked `origin/trunk_dev` at origin `git@github.com:evo-agi/Execution-Substrate.git`. Both scoped refs remained at:

- HEAD `f1aa8b934cc26c16a966a110c7b408abdaeadce7`, `Harden original-key read transaction cleanup (A1) (#10)`
- Sole parent `fb9ae55797d9fcc02863c23fe8d3e43d16eac542`
- Committed tree `8dd27f9acba98ed70d93736bdef8300ef1aba53f`

The 427-entry index remained HEAD-identical, with raw SHA-256 `1c6218366e333383b205833fce0ceaa5d462fa7264cf51cbdcd35aa05855b018`. Local Git config and the named refs matched opening. All 430 physical source leaves were checked after each validation run. The final classification was 27 unstaged tracked modifications and exactly the three original ordinary-untracked files, `replay_progress_test.go`, `sqlite_pooled_claim_read_cleanup_test.go` and `sqlite_replay_progress_schema.go`. There were zero ignored, staged, unmerged, deleted, renamed, type-changed or extra paths. [Closing guard](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/closing-b-guard.json)

| Identity | SHA-256 |
|---|---|
| Exact opening manifest, 6,813 bytes | `0812091529c67f4bc46d0bc343b3dea8595e63a461264e143d51606e581e0c06` |
| Opening tracked full-index diff | `68339ba85b7b22d86bdaa21ed4fdccebc5021f82912344e0507862d1624cb791` |
| Exact final manifest, 6,813 bytes | `f92b57f48a701a606e8a0697b75dac8f691e3eb44c13b9c92afb894ec6e1d718` |
| Final tracked full-index diff | `793e6697cf2342ce41f08ed8f59a0a14eb5c288c74780f158731d55dbe17bcca` |
| Unchanged v2 recipe, 7,275 bytes | `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` |
| Final source guard | `81caa55b927963348f8c960a0bdba593056646094cdd5c1d0b6a46e72fd4fe98` |

Two opening recipe runs matched Appendix B. Two closing runs after scratch cleanup matched the final freeze byte-for-byte. I authenticated the prior audit index and rechecked the material records used in this repair. The historical malformed `replay_custody_structure.go` transcription stayed confined to its original report. The live and archived file retained the correct digest ending `c6a86ad`. [Exact opening JSON](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/appendix-B) · [Exact final JSON](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/closing-b.json) · [Authenticated prior report](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/appendix-A)

The ZIP contains 47 unique regular entries, including all 30 complete source files, both exact manifests, the source map, the maintained regression, and the external N-1 inputs and bindings. The tracked HEAD patch plus the three explicit additions, the full-opening delta, and the tracked-only opening delta with additions each reconstructed all 430 final leaves in private copies. Both `git diff --no-index` commands returned the expected exit 1 for differences. All three `git apply` commands exited 0. ZIP member names, modes, sizes, bytes and the self-excluding inventory were verified. [Archive receipt](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/packet-receipt.json)

| Delivery evidence | SHA-256 |
|---|---|
| Exact opening-to-repaired patch | `211a5522dfc8b5401f7361c5148ce53dc7eaef06e56787231e2624783d064cc2` |
| Opening tracked-only patch with additions | `951c9353a69a37340f122bfd92b4c17ec3e2f514c70cd1e614d7665c3cf0175c` |
| Source map | `d8bae35ede66a6b66b093e457a879ba4b633c7b8dc14ad7c8742801f2a3fc976` |
| ZIP delivery inventory | `a24629ff1c02e4498dcb5a7f66779faf4057d29b00bce9b756572d77236cd6ee` |
| Duplicate report | `6c249d2f2c2b219b6b07ba57d3236ab37d8ffbc1eb2872986489547c2e629f49` |
| Private artifact index | `82860422eaa259508b55b4f5911925ca5d7cc6b3d8aff66fa178e7e9aef7d939` |

[Duplicate report](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/repair-report.md) · [Private artifact index](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/artifact-index.json)

## Executed validation

Development used pinned Go 1.26.5 `darwin/arm64` and its sibling `gofmt`, Python 3.13.4 with `tomllib`, OpenSSL 3.6.2 and Git 2.49.0. The recorded environment used the specified offline Go controls, Git optional locks and lazy fetch disabled, Python bytecode disabled, task-owned cache/temp directories, outer umask `077` and test umask `027`. [Preflight paths and hashes](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/preflight.json) · [Environment](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/environment.json)

The differential tests used the same Go test flags as the focused gates below. Migration red ran from `red-source`, using `-run '^TestSQLiteMigrationPrecommitClosedWrapperRecovery$' ./es/admission/internal/reliablesubmit`. Green ran from the actual checkout with the same selector. Owner reds ran from the recorded private `owner-red-source-*` views against the exact opening owner document with `-run '^TestPrivateReplayProgressSynchronizationInventoryDocsContract$' .`. Owner greens ran in the actual checkout. The final owner green also selected `TestResolvedPlanDocumentationTruthAndFiniteInventoriesContract`.

| Development run | Exit | Result |
|---|---:|---|
| Migration red | 1 | 8 pass, 5 fail including the parent. All failures reached classification. |
| Migration green | 0 | 13 pass. |
| First owner red | 1 | Build setup failed on a duplicate local name. This run supplies no behavioral red evidence. |
| Owner red 2 | 1 | Exact stale owner document failed the field-set check. |
| First owner green | 1 | 3 pass, 2 fail. The carrier mutant was rejected on table width before it reached category. |
| Owner red 3 / green 2 | 1 / 0 | Stale document failed the field-set check. The corrected parent and all four mutants passed on green. |
| Final owner red 4 / green 3 | 1 / 0 | Stale document again failed on the final test bytes. The new owner test and existing resolved-plan contract passed, six identities total. |

The integrated **generation 1** passed gates 1–9. Gate 10 exited 1 with 5,191 passes, one failure and 39 skips. The sole failure was `TestResolvedPlanDocumentationTruthAndFiniteInventoriesContract`, which still expected the old spelling of three lock fields. Gate 11 was unrun in that generation. I updated those three assertions to the corrected document’s exact field names, preserved the first freeze and raw logs, and reran the entire sequence on **generation 2**. [Generation 1 failure record](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/generation-1/gate-10/result.json) · [Differential construction and exact command records](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/differential.json)

### Final generation 2

| Gate | Exit | Pass/fail/skip | Package result |
|---|---:|---:|---|
| 1 Go version | 0 | — | Go 1.26.5, Darwin arm64 |
| 2 `gofmt -d` | 0 | — | Empty output |
| 3 Diff check | 0 | — | Empty output |
| 4 Owner contracts | 0 | 27/0/0 | 1 tested |
| 5 Pooled reader | 0 | 16/0/0 | 1 tested |
| 6 Internal focused and old probes | 0 | 221/0/0 | 1 tested |
| 7 Admission and typed Workstream C | 0 | 26/0/0 | 1 tested |
| 8 API/App boundaries | 0 | 2/0/0 | 2 tested |
| 9 Four packages | 0 | 2,062/0/39 | 4 tested |
| 10 Full repository | 0 | 5,192/0/39 | 21 tested, 20 with no tests |
| 11 External N-1 | 0 | 5/0/0 | 1 tested |

Commands 1–10 used `/Users/ds/Repositories/ES-Private-Replay-Progress-v1`. Command 11 and the subsequent build-graph command used `N1_SOURCE`. Every selected parent executed. Each command had a freshly executed post-command source/index guard, and command 11 had a separate 432-file before/after view guard. [Final argv, identities, skips and raw-log hashes](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/validation-summary.json)

```sh
GO=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go
GOFMT=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/gofmt
I=es/admission/internal/reliablesubmit
A=es/admission
N1_SOURCE=/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/n1-source

"$GO" version
"$GOFMT" -d docs_contract_test.go "$I/sqlite_store.go" "$I/sqlite_replay_claim.go" \
  "$I/sqlite_migrations.go" "$I/sqlite_replay_progress_schema.go" "$I/sqlite_replay_shape.go" \
  "$I/durable_record.go" "$I/durable_operation.go" "$I/durable_service.go" \
  "$I/replay_custody_format.go" "$I/replay_custody_structure.go" "$I/replay_custody_file.go" \
  "$A/reliable_submit_replay_format.go" "$A/reliable_submit_replay_hydration.go" \
  "$A/reliable_submit_replay_private.go" "$I/sqlite_pooled_claim_read_cleanup_test.go" \
  "$I/replay_progress_test.go" "$I/replay_custody_file_test.go" "$I/sqlite_store_test.go" \
  "$I/sqlite_physical_test.go" "$I/sqlite_replay_migration_test.go" \
  "$I/sqlite_replay_shape_test.go" "$I/guardrails_test.go" "$A/reliable_submit_guardrails_test.go" \
  "$A/reliable_submit_replay_private_test.go" "$A/workstream_c_guardrails_test.go"
git --no-pager diff --check
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateReplayProgressSynchronizationInventoryDocsContract|TestPrivateOriginalReplayProgressContractSelection|TestReliableSubmitPersistenceAndConcurrencyADRDocsContract|TestSubmitIdempotencyCorrelationAndRecoveryDocsContract|TestReliableSubmitPureModelDocsAndSourceContract|TestReliableSubmitPublicOptInAndVersioningDocsContract|TestReliableSubmitContractAdapterFoundationDocsAndSourceContract|TestReliableSubmitBindingProducerDocsContract|TestIntegratedAcceptanceGateDocumentationIsConsistent|TestIntegratedCandidateStatusSeparatesCAndT)$' .
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestSQLitePooledClaimReadCleanup$' ./es/admission/internal/reliablesubmit
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestSQLiteMigrationPrecommitClosedWrapperRecovery|TestPrivateReplayProgressConfirmationEligibility|TestPrivateReplayProgressReconciliationEligibility|TestPrivateReplayProgressTerminalEvidenceBinding|TestSQLiteMigrationOpeningRevalidatedUnderLock|TestSQLiteLiteralInternalNamespaceQualification|TestPrivateReplayScope1PublicationPreflight|TestPrivateReplaySharedObjectAllocation|TestReplayPublicationFaultAndIdentity|TestPrivateReplayProgressFormatVectors|TestPrivateReplayProgressTransitions|TestPrivateReplayProgressConcurrencyAndCommitOutcome|TestSQLiteV4MigrationPreservesFullState|TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation|TestSQLiteV3OldBinaryRefusesWithoutMutation|TestSQLiteLegacyCASConnectionCleanup|TestReplayOriginalKeyReadCleanup|TestReplayOriginalKeyReadCallerRefusal|TestReplayGrantC1PreCommitConnectionQuarantine|TestReplayGrantD1BeginResponseLossQuarantine|TestReplayKeyStateD1BeginResponseLossQuarantine|TestReliableSubmitPrivatePersistenceStaticGuardrails)$' ./es/admission/internal/reliablesubmit
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestExecutionSubstrateProductionHasNoA3LeaseRegistryOrPoisonDesign|TestExecutionSubstrateSynchronizedMutableStateReferenceInventoryIsExact|TestPrivateReplayProgressOccupiedDisposition|TestPrivateReplayProgressAdmissionReplay|TestPrivateReplayProgressHasNoEffectPaths|TestReliableSubmitFoundationHasNoRuntimeWiring|TestReliableSubmitBindingProducerHasNoProductionCaller|TestPrepareRequestShapeRemainsLegacyAndUnkeyed|TestResolvedSubmitLegacyEquivalenceOneNomadRegistrationAndAuthorityRecovery)$' ./es/admission
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestWorkstreamCContractPrepareAndSubmitRemainSeparatedAtAPIBoundary|TestSubmitPublicRouteRejectsStructuralReliableBody)$' ./es/api ./es/app
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=600s ./es/admission/internal/reliablesubmit ./es/admission ./es/api ./es/app
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=600s ./...
(cd "$N1_SOURCE" && "$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestPrivateReplayProgressAdmissionUnknownNoEffects$' ./es/admission)
(cd "$N1_SOURCE" && "$GO" list -mod=readonly -deps -test -json ./es/admission)
```

The full suite added 18 passing identities over the independently audited 5,174. These were `TestSQLiteMigrationPrecommitClosedWrapperRecovery` and its 12 `Schema{0,1,2,3}/{ClosedWrapper,OrdinaryRollback,CanceledReadback}` leaves, plus `TestPrivateReplayProgressSynchronizationInventoryDocsContract` and its four `MissingAtomic`, `OmittedScope2Wrapper`, `OmittedSharedPermitReader` and `ReferenceClaimedAsPrimitive` leaves. There were zero removals or renames. Gate 9 was exactly the four-package projection of gate 10. All 39 skip identities matched the prior audit: the two direct helper sentinels, 36 App cases with Docker daemon unavailable, and the installed-source case with direct Docker Unix socket unavailable. No repair case skipped. The allocator parent logged both `SHARED_ALLOCATOR_READY` and `SHARED_ALLOCATOR_WON`. [Exact skip and identity reconciliation](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/validation-summary.json)

Both historical opener probes ran from authenticated task-owned copies. PB1/schema 2 was 14,350,930 bytes with SHA-256 `b205a31bac091cbcf5b3f4826bc359455625316908051131733622813e34adcf`. The previous schema-3 probe was 15,601,186 bytes with SHA-256 `42614a50812a65ba52b53488d872884e59ce7b4f57dece6a66642d4eb8de1409`. They retained their separate schema-3 and schema-4 refusal purposes and their prior source and witness bindings.

### External N-1

The final N-1 view contained all 430 final leaves plus exact Appendix D/E files. The bridge digest was `14f0e9e92a37e1d1bf624f1f052a62a6d56e5b82f988698abbf6e1b5bcf9196d`, the witness digest was `8da31dd61c9af2537c15f4376a330d05cb2e55dd2efd0ea610472a0c6ffa5c6a`, and the 432-file view digest was `d232b4a270cfe3af072794a24a2b188d9c3e1f553d85bd6e72c13485ff6933fd`. The separate `go list` exited 0. The 291-package graph bound 2,801 physical inputs, including the generated test-main source preserved before cache cleanup. The migration regression appears in dependency test-file metadata only. The bridge and witness remain external to the ordinary checkout.

| Case | Invocation result | Projected revision | Later current revision |
|---|---|---:|---:|
| Establish / Canceled | `WriteUnknown` | 0 | 1 |
| Establish / AuthenticatedExact | `OwnCommitConfirmed` | 1 | 1 |
| AssignRun / Canceled | `WriteUnknown` | 0 | 2 |
| AssignRun / AuthenticatedExact | `OwnCommitConfirmed` | 2 | 2 |

Each case executed one real COMMIT followed by modeled response loss. The later read preserved the earlier disposition. Provider, staging and EGS counters were zero, operational roots were empty, and each case retained one sealed original. These five identities are outside the ordinary suite. [N-1 raw log](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/gate-11/stdout) · [Build-input inventory](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/n1-build-inputs.json)

## Scope and closeout

Only the foreground wrote repository source, after the four earlier reviewers had closed. No subagents were started for the repair. The evidence qualifies the observed logical states and cleanup ordering. Physical driver-close success and duration, native installed-source qualification, provider acceptance and operational cross-restart write-uncertainty authority remain unqualified.

I removed only task-owned compile caches, temp directories and patch-reconstruction fixtures. The retained probes were returned to `0600`. The maintained tests used bounded temporary fixtures, helper processes, loopback mocks and read-only Docker capability probes. No shared caches or prior evidence were cleaned.

No staging, commit, push, PR mutation, ref update, remote effect, checkout synchronization, dependency download or installation, live stack, real key loading, operational migration, native qualification or runtime wiring occurred. Public reliable Submit remains unavailable. The cross-restart operational write-uncertainty gate remains unimplemented.

## Exact final canonical manifest

```json
{"branch":"codex/private-replay-progress-v1","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/es_execution_admission_model.md","sha256":"bedc87c611b5c9340ffaafb0866f028dc9daf2f22552efec47491f1b4ae713f2","size":88702},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md","sha256":"34e06ff10148d67a49000868499294873c732279d7f399a5f2cb910b0c12f40e","size":161666},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md","sha256":"1b03cc40b48861c7220a7b85d20b1f8d232690f17460e3eee0df33af4659e3f3","size":103025},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"c4fdbfb4acd3c2a27f679f6575798c4553e94110c4aa7177f590e90fe89c5e31","size":302636},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"dd433f02e783aa265d775bd411c95433e369642e2aafbdb32c72b75f78b4ebff","size":799914},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_operation.go","sha256":"b7761f001a1f67349ed51f2b79012194a7d45bb19c79e0ca2c0c22b8227320f9","size":9548},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_record.go","sha256":"999db7db6550c5031b023a9613825504e30e971a179298cc43e09cf8c5c5d7cd","size":25226},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_service.go","sha256":"ef0bc6f4d125f3986c46901cbe05bc2cb447af7dfbf51cee4653d7ce696c0945","size":49972},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/guardrails_test.go","sha256":"9a300f0553fd6ac3003a048a7309060a4ec6f618eacd94139bd4bb29c011bc60","size":32231},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_file.go","sha256":"61c4006e1e4a3feb7c0ec0e7d4685dc2c3fe8c1e2165d1529d2c86ae8fa137b5","size":50461},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_file_test.go","sha256":"207d9f17658cd50f6c4bea8e293b12abd89455a174b2d96bac84742a66b0afdf","size":69995},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_format.go","sha256":"b8cb8e31edd9d854317a0d6a456f25d5ab1838498623881e429dec2155e1ea67","size":16488},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_structure.go","sha256":"4916268757b93d409cbc13ba9c0da14e009499b4db7cadd52bc7ccd47c6a86ad","size":18640},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_progress_test.go","sha256":"0952fff321daa368dee1d32ed39a2a5b417e7d2779ae4e1015ab3c12b1021048","size":61314},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_migrations.go","sha256":"7736e30a1d0c6e9584d9050cc6ebf8bfaf900d424f764ebe61af8ec8ddaec0c9","size":17407},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_physical_test.go","sha256":"2c125b6373f83467d542db45473cc79b888ed3a665e65ef6bf013655f461a7ba","size":14539},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_pooled_claim_read_cleanup_test.go","sha256":"0ec3060ed3c30a6327ec49b0291d5c761c20894986c9b6b1e1be384694312823","size":8912},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_claim.go","sha256":"8ddec89b4ca5702591bdf2060062016d7fb54264fc7df57af5ead1d161eb9de3","size":8301},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go","sha256":"e0765e59cb00ace73e8a88c92b9d7e830b39766792120845220b2fd407d357fa","size":28903},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_progress_schema.go","sha256":"132d8ab87f5658cab3477b9f6913538013ba922d4768192a96be960df7bbb149","size":30612},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_shape.go","sha256":"29cdbba2e5b1fee069989f6e6423dccc1c69c843de22b6504f68a7d199b317be","size":2751},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_shape_test.go","sha256":"3552ea5fafbc59e43cc21b1007486e98da4d59b6d0ea98db92646e0c8478adfb","size":8815},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_store.go","sha256":"e448d265516aae1d7efd2c06170d8cfa2cc8c0258f82dfc15a3279e65efad4c1","size":63299},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_store_test.go","sha256":"c99e7659b1059431911557ba43ef7fa982e373bba939f610bd41ea0622cee96f","size":57339},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_guardrails_test.go","sha256":"32de42b7bf8974e36c014d3d9ce6d24e0994fbbc03bb1587c4c4fddd32c80f6e","size":50991},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_format.go","sha256":"0a21803b03308332613481f89ce4b595512b31b073c56b31fe7d8000519c3beb","size":17326},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_hydration.go","sha256":"b5ff16b96178c45b53165ebb2bcbdc67991bb145276ca4a11a598f1430745b9c","size":28800},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_private.go","sha256":"d17927a23a57c808a8f0ebc4bad3e9912e42d7da497033637102bae2c45fd278","size":20440},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_private_test.go","sha256":"4e4e7c7fad2ed2b88b35801841044f4b1f049a4cb6d0435499bb87699467e9f2","size":45171},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/workstream_c_guardrails_test.go","sha256":"68f2fe4e31e5d862be161c3ba1071a511935b32e90cf9021755fe4dcb045fab5","size":297009}],"head":"f1aa8b934cc26c16a966a110c7b408abdaeadce7","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"793e6697cf2342ce41f08ed8f59a0a14eb5c288c74780f158731d55dbe17bcca","upstream":"origin/trunk_dev"}
```
<!-- END APPENDIX A -->

## Appendix B — Exact final thirty-file canonical manifest

Bytes: 6813
SHA-256: f92b57f48a701a606e8a0697b75dac8f691e3eb44c13b9c92afb894ec6e1d718

<!-- BEGIN APPENDIX B -->
{"branch":"codex/private-replay-progress-v1","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/es_execution_admission_model.md","sha256":"bedc87c611b5c9340ffaafb0866f028dc9daf2f22552efec47491f1b4ae713f2","size":88702},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md","sha256":"34e06ff10148d67a49000868499294873c732279d7f399a5f2cb910b0c12f40e","size":161666},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md","sha256":"1b03cc40b48861c7220a7b85d20b1f8d232690f17460e3eee0df33af4659e3f3","size":103025},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"c4fdbfb4acd3c2a27f679f6575798c4553e94110c4aa7177f590e90fe89c5e31","size":302636},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"dd433f02e783aa265d775bd411c95433e369642e2aafbdb32c72b75f78b4ebff","size":799914},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_operation.go","sha256":"b7761f001a1f67349ed51f2b79012194a7d45bb19c79e0ca2c0c22b8227320f9","size":9548},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_record.go","sha256":"999db7db6550c5031b023a9613825504e30e971a179298cc43e09cf8c5c5d7cd","size":25226},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_service.go","sha256":"ef0bc6f4d125f3986c46901cbe05bc2cb447af7dfbf51cee4653d7ce696c0945","size":49972},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/guardrails_test.go","sha256":"9a300f0553fd6ac3003a048a7309060a4ec6f618eacd94139bd4bb29c011bc60","size":32231},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_file.go","sha256":"61c4006e1e4a3feb7c0ec0e7d4685dc2c3fe8c1e2165d1529d2c86ae8fa137b5","size":50461},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_file_test.go","sha256":"207d9f17658cd50f6c4bea8e293b12abd89455a174b2d96bac84742a66b0afdf","size":69995},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_format.go","sha256":"b8cb8e31edd9d854317a0d6a456f25d5ab1838498623881e429dec2155e1ea67","size":16488},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_structure.go","sha256":"4916268757b93d409cbc13ba9c0da14e009499b4db7cadd52bc7ccd47c6a86ad","size":18640},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_progress_test.go","sha256":"0952fff321daa368dee1d32ed39a2a5b417e7d2779ae4e1015ab3c12b1021048","size":61314},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_migrations.go","sha256":"7736e30a1d0c6e9584d9050cc6ebf8bfaf900d424f764ebe61af8ec8ddaec0c9","size":17407},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_physical_test.go","sha256":"2c125b6373f83467d542db45473cc79b888ed3a665e65ef6bf013655f461a7ba","size":14539},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_pooled_claim_read_cleanup_test.go","sha256":"0ec3060ed3c30a6327ec49b0291d5c761c20894986c9b6b1e1be384694312823","size":8912},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_claim.go","sha256":"8ddec89b4ca5702591bdf2060062016d7fb54264fc7df57af5ead1d161eb9de3","size":8301},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go","sha256":"e0765e59cb00ace73e8a88c92b9d7e830b39766792120845220b2fd407d357fa","size":28903},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_progress_schema.go","sha256":"132d8ab87f5658cab3477b9f6913538013ba922d4768192a96be960df7bbb149","size":30612},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_shape.go","sha256":"29cdbba2e5b1fee069989f6e6423dccc1c69c843de22b6504f68a7d199b317be","size":2751},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_shape_test.go","sha256":"3552ea5fafbc59e43cc21b1007486e98da4d59b6d0ea98db92646e0c8478adfb","size":8815},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_store.go","sha256":"e448d265516aae1d7efd2c06170d8cfa2cc8c0258f82dfc15a3279e65efad4c1","size":63299},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_store_test.go","sha256":"c99e7659b1059431911557ba43ef7fa982e373bba939f610bd41ea0622cee96f","size":57339},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_guardrails_test.go","sha256":"32de42b7bf8974e36c014d3d9ce6d24e0994fbbc03bb1587c4c4fddd32c80f6e","size":50991},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_format.go","sha256":"0a21803b03308332613481f89ce4b595512b31b073c56b31fe7d8000519c3beb","size":17326},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_hydration.go","sha256":"b5ff16b96178c45b53165ebb2bcbdc67991bb145276ca4a11a598f1430745b9c","size":28800},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_private.go","sha256":"d17927a23a57c808a8f0ebc4bad3e9912e42d7da497033637102bae2c45fd278","size":20440},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_private_test.go","sha256":"4e4e7c7fad2ed2b88b35801841044f4b1f049a4cb6d0435499bb87699467e9f2","size":45171},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/workstream_c_guardrails_test.go","sha256":"68f2fe4e31e5d862be161c3ba1071a511935b32e90cf9021755fe4dcb045fab5","size":297009}],"head":"f1aa8b934cc26c16a966a110c7b408abdaeadce7","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"793e6697cf2342ce41f08ed8f59a0a14eb5c288c74780f158731d55dbe17bcca","upstream":"origin/trunk_dev"}

<!-- END APPENDIX B -->

## Appendix C — Exact active v2 provenance recipe

Bytes: 7275
SHA-256: c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca

<!-- BEGIN APPENDIX C -->
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
import sys
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v2"


def fail(message: str) -> "NoReturn":
    raise SystemExit(message)


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env.update(
        {
            "LC_ALL": "C",
            "LANG": "C",
            "GIT_OPTIONAL_LOCKS": "0",
            "GIT_NO_LAZY_FETCH": "1",
            "GIT_TERMINAL_PROMPT": "0",
            "GIT_PAGER": "cat",
        }
    )
    result = subprocess.run(
        [
            "git",
            "--no-pager",
            "-c",
            "core.fsmonitor=false",
            "-c",
            "core.untrackedCache=false",
            *args,
        ],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


def validate_output_path(output_path: Path, repository_root: Path) -> None:
    if not output_path.is_absolute():
        fail("output path must be absolute")

    parent = output_path.parent
    parent_metadata = parent.lstat()
    if not stat.S_ISDIR(parent_metadata.st_mode) or stat.S_ISLNK(parent_metadata.st_mode):
        fail("output parent must be a nonsymlink directory")
    if parent_metadata.st_uid != os.getuid():
        fail("output parent must be owned by the current user")
    if stat.S_IMODE(parent_metadata.st_mode) & 0o022:
        fail("output parent must not be group- or world-writable")

    try:
        output_path.lstat()
    except FileNotFoundError:
        pass
    else:
        fail("output path already exists")

    repository_text = os.path.realpath(os.fspath(repository_root))
    output_text = os.path.realpath(os.fspath(output_path))
    try:
        common = os.path.commonpath([repository_text, output_text])
    except ValueError:
        common = ""
    if common == repository_text:
        fail("output path must be outside the repository")


def write_exclusive(output_path: Path, payload: bytes) -> None:
    flags = (
        os.O_WRONLY
        | os.O_CREAT
        | os.O_EXCL
        | getattr(os, "O_NOFOLLOW", 0)
        | getattr(os, "O_CLOEXEC", 0)
    )
    fd = os.open(os.fspath(output_path), flags, 0o600)
    try:
        view = memoryview(payload)
        while view:
            written = os.write(fd, view)
            if written <= 0:
                fail("short provenance-output write")
            view = view[written:]
        os.fsync(fd)
    finally:
        os.close(fd)

    metadata = output_path.lstat()
    if not stat.S_ISREG(metadata.st_mode) or stat.S_ISLNK(metadata.st_mode):
        fail("provenance output is not a regular nonsymlink file")
    if metadata.st_uid != os.getuid():
        fail("provenance output owner mismatch")
    if stat.S_IMODE(metadata.st_mode) != 0o600:
        fail("provenance output mode mismatch")
    if metadata.st_nlink != 1:
        fail("provenance output link-count mismatch")
    if metadata.st_size != len(payload):
        fail("provenance output size mismatch")

    read_flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_CLOEXEC", 0)
    read_fd = os.open(os.fspath(output_path), read_flags)
    try:
        observed = bytearray()
        while len(observed) <= len(payload):
            chunk = os.read(read_fd, min(1 << 20, len(payload) + 1 - len(observed)))
            if not chunk:
                break
            observed.extend(chunk)
    finally:
        os.close(read_fd)
    if bytes(observed) != payload:
        fail("provenance output byte mismatch")


if len(sys.argv) != 2:
    fail("usage: governed_execution_audit_patch_manifest_v2.py ABSOLUTE_OUTPUT_PATH")

repository_root = Path(git_text("rev-parse", "--show-toplevel"))
output_path = Path(sys.argv[1])
validate_output_path(output_path, repository_root)

head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    fail("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            fail(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()

write_exclusive(output_path, canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")

<!-- END APPENDIX C -->

## Appendix D — Complete preceding independent REJECT report

Bytes: 32838
SHA-256: 2f26df84e9376b24d9bf29a2a25ae729a8fa270f7c8450a5dcb6ed684e570c1b

<!-- BEGIN APPENDIX D -->
# REJECT

The exact thirty-path candidate is ineligible for a later local commit gate. All eleven prescribed commands passed, including the fresh admission response-loss witness. Two findings still prevent acceptance.

1. **M-1 remains incomplete at the pre-COMMIT rollback boundary.** After migration writes and final schema checks, an already-closed connection wrapper makes both `ROLLBACK` and `Raw` return `sql.ErrConnDone`. The opener takes its generic unavailable exit and skips the checked nonmigrating read required by ADR §15B.5. The independent diagnostic reproduced this on pristine schema 0 and populated schema 3. Both cases reached verified schema 4 inside the transaction, attempted zero COMMITs, returned no handle, and preserved the complete logical opening state. The opener returned generic unavailable in both cases. The required result for an authenticated old-state readback is recovered-old refusal. The two ordinary rollback controls passed. [Rollback branch](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_store.go:676) · [Opener recovery branch](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_store.go:96) · [Owner rule](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1712) · [Diagnostic log](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/migration-diagnostic/stdout)
2. **Admission §7.4 contradicts the candidate’s exact synchronization inventory.** The owner document says production ES and `cmd/es` have five synchronization-bearing fields and zero atomic fields. The typed inventory covers those same trees and records 32 entries. The 27 additions are one per-custody `RWMutex`, three invocation-local atomic flags, and 23 references or request fields. The owner’s permit table also omits the scope-2 wrapper and shared allocator readers. This is unintended documentation drift in the private **Bounded slice rule** on the reliable-submit **Reopened redesign seam**. The implementation keeps these fields within the selected fixture boundary. The owner table’s present-tense, production-wide wording makes the discrepancy material to this exact candidate. [Admission §7.4](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/es_execution_admission_model.md:910) · [Typed field inventory](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/workstream_c_guardrails_test.go:2280) · [Permit inventory](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/workstream_c_guardrails_test.go:2463)

## Target and provenance

I used this fresh, target-bound chat for the independent audit. The physical root was `/Users/ds/Repositories/ES-Private-Replay-Progress-v1`, with `.git` as both the Git and common directory. Branch `codex/private-replay-progress-v1` tracked `origin/trunk_dev`, with origin `git@github.com:evo-agi/Execution-Substrate.git`. Both scoped refs pointed to `f1aa8b934cc26c16a966a110c7b408abdaeadce7` throughout. Its sole parent was `fb9ae55797d9fcc02863c23fe8d3e43d16eac542`, its tree was `8dd27f9acba98ed70d93736bdef8300ef1aba53f`, and its subject was `Harden original-key read transaction cleanup (A1) (#10)`.

The 427-entry index matched HEAD. All 430 physical leaves were independently read and checked for bytes and modes. The result was 400 HEAD-identical leaves, 27 unstaged modifications and exactly the three authorized ordinary-untracked files. All 30 candidate files were regular `0644`. The staged, unmerged and ignored inventories were empty, with no deleted, renamed, type-changed or extra paths. The raw index SHA-256 was `1c6218366e333383b205833fce0ceaa5d462fa7264cf51cbdcd35aa05855b018` and the raw local Git config SHA-256 was `4c98ee1729d2d3321c357ec922f6dafc19b6ac167a8a24ed636d359ab6642485`. Both also matched the retained author opening values. I observed no scoped ref difference. The separately disclosed historical all-ref aggregate difference did not affect the named identities. [Opening guard](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/opening-guard.json)

| Provenance item | Verified SHA-256 |
|---|---|
| Canonical Appendix B, 6,813 bytes | `0812091529c67f4bc46d0bc343b3dea8595e63a461264e143d51606e581e0c06` |
| Full-index tracked HEAD diff | `68339ba85b7b22d86bdaa21ed4fdccebc5021f82912344e0507862d1624cb791` |
| Appendix C recipe, 7,275 bytes | `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` |
| Repaired ZIP, 900,863 bytes and 44 regular entries | `e3cac3bc27bbfd8c1c18d1abf3aabc00077e632e14bd6e6b92e26e020c9c1be6` |
| Rejected ZIP, 718,150 bytes | `bc4bc721f7aa0f02da9f2427625973e883a82fdc0988e4f587c2140792245cf3` |
| Rejected canonical manifest | `110cef71ba25f61b70297b37cc5a50a68732d639845e0ac4315d06cedcdbc1e3` |
| Rejected tracked diff | `e45e3bd85391191702673b2d40fc2d06d865503004e09a8094c2f6a7081fe0c4` |
| Rejected-to-repaired patch | `cd1ddb5b23d124c931c449e7a09bd81e3d6e5307d105d3d19eeca179a5a068c5` |
| Repaired source map | `fa58e64ecf8c2872bd8ff29357fa2266108e98df272344a349b061f39f784d23` |
| Repaired delivery inventory | `c2a2b842265eace578bfe61a5944b1c91826194f17129ea691bd88a6dde419a1` |

I checked all source-map rows against both archives, the live files, and the pinned HEAD blobs where applicable. The set was exactly 17 repaired and 13 unchanged rows across the same 30 paths. I reviewed the integrated slice against HEAD as well as the repair delta. The four executions of the authenticated recipe, two opening and two closing, produced exact Appendix B bytes in absent external outputs. [Row comparison](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/repair-delta-rows.json) · [Closing manifest](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/closing-b.json)

**Appendix A adjudication.** Its original bytes were preserved. Its inline JSON canonicalized to 6,815 bytes with SHA-256 `adc82e9b55e088a33b66e72c75cadda4835f81e82c94cdac8abb1856bc33f7b8`. The sole discrepancy was the disclosed 66-character hash for `replay_custody_structure.go`. Both archives and the live 18,640-byte file gave `4916268757b93d409cbc13ba9c0da14e009499b4db7cadd52bc7ccd47c6a86ad`. An in-memory field comparison reconciled every other field to Appendix B. The live source independently reproduced Appendix B. [Preserved transport](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/appendix-A)

## Eight finding dispositions

| Finding | Independent disposition |
|---|---|
| **M-1** | **Incomplete.** The original lock-order defect is repaired. The maintained clock witness committed a second writer after preflight and before `BEGIN IMMEDIATE`. Lock-held application ID, version, ledger and shape or pristine verification govern migration writes and set the recovery baseline. Invalid app, ledger, schema, future version and nonempty bootstrap refused. The valid competing head opened with cleanup and zero migration writes. Authentic openings 0–4 and the maintained lost-response controls passed. The separate already-closed pre-COMMIT branch failed the fresh diagnostic described above. |
| **M-2** | **Resolved.** Both pristine and schema-digest qualification use a literal seven-character `sqlite_` check with SQLite ASCII `NOCASE`. The digest encoding and authentic constants are preserved. The pinned SQLite source reserves that literal prefix. The fresh tests refused the collision table, mixed-case index and mixed-case view, using unfiltered schema and full logical-state witnesses independent of the filter. |
| **SR-1** | **Resolved for the selected lifetime contract.** The confirmation path checks the borrow after acquiring the issuer lock, matches the original descriptor’s key IDs and fingerprints, checks the retained active-or-retired binding and envelope keys together, then checks qualification and lifetime again before projection. Fresh tests covered both pre-entry revocations, active and retired controls, known and recoverable-unknown establishment, ordinary-current reads, and callback return or cancellation after initial consumption while blocked on the issuer lock. Refusal preserved `Committed` or `WriteUnknown` and withheld projection. The source trace also checked closed, copied and foreign access, and the separate eligibility of the known committed snapshot after advancement of the same original. |
| **SR-2** | **Resolved.** Every fresh codec-4 reconciliation checks the current recording predicate before reaching a same-fact no-op. Historical tuple validation stays separate and preserves the recorded tuple through later provider and terminal activity. Legitimate exact latest replay, changed-input conflict and stale classification retain their order. Fresh tests covered pending, ambiguous and inconsistent after incompatible provider activity and both terminals, plus eligible no-ops, no-marker, terminal corroboration and negative reconciliation without a provider. The legacy branch retains its predicates. |
| **K1-1** | **Resolved.** Once establishment proves a definite loser, failed winner disclosure preserves `Occupied` and zero projection. The deterministic test covered disjoint catalogs, an unavailable winner object, equivalent winner projection and proved changed-intent conflict, with one winning row and no repeat admission attempt. I source-traced later cancellation, key selection and authentication failures to the same local branch. Generic lookup refusal and write uncertainty retain separate outcomes. The branch performs no second resolution, Seal or semantic write. |
| **T-1** | **Resolved.** The redacted synthetic assertion carries private claim, run, marker, fact, outcome and receipt fields. Acceptance binds the independently constructed exact receipt. Negative evidence carries no receipt and binds its fact. Evidence validation precedes relying on replay or no-op. Candidate-phase checks follow legitimate exact replay. Fresh tests covered receipt substitution, opposite polarity, zero and malformed values, wrong attempt and negative fact, terminal restart replay, receipt immutability and opposite-terminal refusal. The accepted constructor has four test calls and the negative constructor has two, with zero production calls. |
| **R2-1** | **Resolved for both selected publisher paths.** Scope 1 qualifies scope, custody and parents, frozen input and permit presence before arranging burn. The maintained test proved that an ineligible preflight preserves eligible first use by the issuer, while a qualified foreign issuer or allocation collision burns the permit. Scope 2 retains wrapper burn. Both paths use the same checked count-and-create allocator, with confirmed rollback and identity recheck before FD transfer, one discard rescue, withholding after two uncertain responses, and charged reservations and counted orphans on refusal. |
| **N-1** | **Resolved by fresh admission-level execution.** The exact external bridge and witness ran against an independently copied and guarded 432-file view. All five identities passed. The four case results and build bindings are below. |

The four independent read-only reviews completed. The SQLite reviewer identified the residual pre-COMMIT branch and verified the historical cleanup and migration paths. The custody reviewer verified SR-1/R2-1 and identified the owner-table drift. The durable/admission reviewer verified SR-2/K1-1/T-1, including the exact replay/CAS ordering and the rejected terminal adapter. The evidence/effect reviewer independently confirmed the owner-table drift, both old-probe bindings, generation and skip reconciliation, and the fixture caller exclusions. I checked both material findings against the owner text and candidate source and ran the separate migration diagnostic. The reviews had no material dissent. Each reviewer’s dynamic conclusions were limited to inspected retained evidence. The foreground ran the fresh validation.

## Integrated slice and historical evidence

- The finite `(codec, scope, format)` dispatch preserves historical codec 1/2 and immutable codec 3. Codec 4 retains global caller/key occupancy, one original and physical row ID, one attempt and one assigned run. The durable service owns semantic successors. SQLite enforces physical shape and CAS. The original stays sealed with scope-separated AEAD and commitments, exact retained key purposes and fingerprints, strict typed decoding and parser budgets. Progress and receipts live in SQLite under the fixture model. Current replay and exact latest replay leave earlier invocation dispositions intact. The operational §8 predicate and cross-restart write-uncertainty authority remain outside the implemented facade.
- Migration 4’s copy proof preserves rowid plus all 46 named columns, typed contents, registry and grant rows, and prior ledger rows. Fresh logical preservation checks passed across the selected known-COMMIT, rollback and lost-response cases. The sealed originals are outside the schema rewrite. This evidence qualifies logical preservation. Physical database and sidecar byte equality, physical-close success and duration, capacity under actual double withholding, and real-time enforcement of the 16 MiB detection budget remain unqualified.
- The distinct retained schema-2 PB1 and previous-schema-3 probe copies ran under their respective focused parents. PB1 was 14,350,930 bytes with SHA-256 `b205a31bac091cbcf5b3f4826bc359455625316908051131733622813e34adcf`, bound to its original build, harness and 404 historical source leaves. The other probe was 15,601,186 bytes with SHA-256 `42614a50812a65ba52b53488d872884e59ce7b4f57dece6a66642d4eb8de1409`. Its 427 exported leaves matched pinned HEAD, its test overlay had one entry, and all 1,354 compiled inputs matched, including the retained copy of one generated input. That inventory SHA-256 was `50a81fa5a042e135abfc9f6bad68d20abc4575f881945ecc84252c14910dde8f`. The probes exercised schema-2 refusal of schema 3 and schema-3 refusal of schema 4, respectively. Each supplies its own historical refusal evidence. [Probe bindings](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/probe-material.json)
- `loadClaimFresh`, including its final blank separator, was exactly 1,077 bytes at HEAD, in the rejected archive and in the candidate, with SHA-256 `3a47f8b5e0c5bf7bec899987aa78fdf4ef48a585086d9eb975e576896ab4b61c`. The retained pooled-reader differential used the same regression bytes. It recorded two passes and 14 failures on the pinned reader with test instrumentation and 16 passes on the repaired reader. Fresh gate 5 reproduced the 16 passes, including same-store fresh-context reads and CAS where disposal or transaction end was confirmed. I reviewed preserved A1/O2/C1/D1 paths and the pinned Go discard behavior. `Raw` with `driver.ErrBadConn` excludes the connection from the pool. The driver close result can be discarded inside `database/sql`, and the double-withholding control models responses.
- The typed caller inventory and source trace kept the scope-2 facade in the private admission composer. I found no startup, configuration, App/API, script or example caller. The finite selector mutants supplement the typed inventory and call trace. Fresh boundary tests preserved public structural reliable-request refusal and unkeyed Submit. Coordinator authority remained separate. Fixture facts and receipts confer no provider acceptance evidence.

| Version | Migration SQL literal SHA-256 | Authentic schema shape SHA-256 |
|---|---|---|
| 1 | `9613ba74cd6573626277b1f04a20b9c3ec5f9edf8b6b7408e94cbb45edc32dcd` | `031abaada34a63834d3466081ed04afef6b7c9f55103cd2b57fe3033b8c45ef0` |
| 2 | `9280a62450488dfa54907d268d693f3f7d4f0b78b9a3553a1b659206d2c970e9` | `944094f4e5fae102ea2882a076f580c69494678f41acedf9eaa971fe836eb280` |
| 3 | `4dafddbf477fd7f64ad88cf2b1e2b2becb378827e81cd6cc694456798c9a00be` | `15ab48bde4d53bb252dc954a2aa3b1db12de7295111f23bb0264f74f153dba92` |
| 4 | `879b24ac563d37ccdd1bdb5ec13c923b93213f2caea69a1110281796e20e667e` | `2ae4721c8526ed9b8de35fd3acdfa31448eae9b547ba8662a22ed130035f7c15` |

Migrations 1–3 matched HEAD, and the migration 4 literal matched both packets. The operation and record encodings, Workstream C source and pooled regression were among the byte-identical repair rows. [Format evidence](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/format-material.json)

### Retained differential and generation results

The prior independent SR diagnostic authenticated at 10 passes and 13 failures on the rejected target. The four primary repair differentials authenticated against their frozen inputs, immediate guards and raw logs.

| Retained differential | Red pass/fail | Green pass/fail |
|---|---:|---:|
| Migration opening and namespace | 8/9 | 41/0 |
| Confirmation lifetime and permit preflight | 13/9 | 66/0 |
| Reconciliation and terminal evidence | 14/19 | 77/0 |
| Occupied disclosure | 2/3 | 22/0 |

The primary reds reached behavioral assertions. The superseded migration BLOB-ledger setup error was corrected to invalid TEXT. The superseded custody red was repeated on the exact rejected production inputs. The terminal adapter supplies only the rejected assertion’s common claim/run/marker/fact fields. Receipt substitution and representable polarity substitutions provide causal red controls. The malformed discriminator and receipt cases on green exercise fields that did not exist in the old interface. The broader green selectors were reconciled by matched assertions and actual inputs. No full historical compile ledger was inferred.

Generation 1 passed gates 1–8 and failed gate 9 with 2,043 passes, 39 skips and six failing identities. The failing leaves were `TestSQLiteV4BootstrapCommitUnknownReopenZeroOrFour/interrupted_before_commit`, `TestSQLiteV4UpgradeFromOneCommitUnknownNoIntermediate/false` and `TestSQLiteV4UpgradeFromTwoCommitUnknownOldOrNew/false`, plus their three parents. Gates 10 and 11 were unrun in generation 1. The retained recovery rerun passed 42 identities. All six identities passed in retained generation 2 and in fresh gate 9. Those interruptions originate in the migration COMMIT collaborator. The new diagnostic exercises the earlier `beforeMigrationCommit` collaborator and the rollback-uncertainty branch. Its exit 1 comprised two passing controls, two failing classification leaves and their failing parent. The setup reached the intended boundary in all four cases, and I ran it once. [Authenticated historical identities](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/history-identities.json) · [New diagnostic result](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/migration-diagnostic/result.json)

## Fresh N-1 witness

The audit-owned view contained all 430 actual candidate leaves plus the exact Appendix F bridge and Appendix G witness. Their SHA-256 values were `14f0e9e92a37e1d1bf624f1f052a62a6d56e5b82f988698abbf6e1b5bcf9196d` and `8da31dd61c9af2537c15f4376a330d05cb2e55dd2efd0ea610472a0c6ffa5c6a`. Both were absent from the source checkout and ordinary suite. The 432-file before/after guard matched `4d99551a4b41a89884b6a0edb221628eb2abc1cfe4bd8524cb2937377b5f1320`.

The bridge attached and restored only the selected store hook. Every case performed one real COMMIT and then modeled a lost response. Recovery ran through existing production disposition and projection code. The hook was restored before the later read.

| Case | Invocation result | Projection revision | Later current revision |
|---|---|---:|---:|
| Establish / Canceled | `WriteUnknown` | 0 | 1 |
| Establish / AuthenticatedExact | `OwnCommitConfirmed` | 1 | 1 |
| AssignRun / Canceled | `WriteUnknown` | 0 | 2 |
| AssignRun / AuthenticatedExact | `OwnCommitConfirmed` | 2 | 2 |

Each case checked the earlier disposition, fixture-only references, one sealed object, zero provider/staging/EGS contacts and empty operational roots. `AssignRun` preserved the original object bytes. The raw witness SHA-256 was `39020d0d23630d74e87e698f4b91aab975586f6ce18503d89f19b3d084602d29`. [Fresh N-1 raw log](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/gate-11/stdout)

The packet’s view-command and build-input records matched `942000138cc35778e4eb175d9be01737fe6f95af790f84233335fc3e2fa7340a` and `a84ab3946242c1b026ef6d8d14af09776aaf0be6d501d25abbc9d39b7296913c`. The fresh package graph matched all 291 retained package records after path normalization. All 2,801 physical input digests matched, including the formerly absent 57,754-byte generated test-main input, reproduced by this audit and preserved before cache cleanup. The fresh graph SHA-256 was `00d65eddf204471a5e2482e944d71cae79aa66133bc5b39c03cc0200f417762e`. [Input reconciliation](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/n1-resolved-inputs.json)

## Fresh command record

Commands 1–10 ran from `/Users/ds/Repositories/ES-Private-Replay-Progress-v1`. Command 11 ran from `N1_SOURCE` below. Go was `go1.26.5 darwin/arm64`, with sibling `gofmt`, Python 3.13.4 with `tomllib`, OpenSSL 3.6.2 and Git 2.49.0. The runner used the declared offline Go settings, Git optional locks and lazy fetch disabled, Python bytecode disabled, audit-owned cache/temp directories, outer umask `077` and test umask `027`. [Executable paths, versions and hashes](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/preflight.json) · [Recorded environment](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/validation-environment.json)

| Gate | Exit | Test pass/fail/skip | Package result |
|---|---:|---:|---|
| 1 Go version | 0 | — | Go 1.26.5, Darwin arm64 |
| 2 `gofmt -d` | 0 | — | Empty output |
| 3 Diff check | 0 | — | Empty output |
| 4 Owner contracts | 0 | 22/0/0 | 1 tested |
| 5 Pooled reader | 0 | 16/0/0 | 1 tested |
| 6 Internal focused and old probes | 0 | 208/0/0 | 1 tested |
| 7 Admission focused | 0 | 24/0/0 | 1 tested |
| 8 API/App boundaries | 0 | 2/0/0 | 2 tested |
| 9 Four-package suite | 0 | 2,049/0/39 | 4 tested |
| 10 Full repository | 0 | 5,174/0/39 | 21 tested, 20 with no tests |
| 11 External N-1 | 0 | 5/0/0 | 1 tested |

All 11 primary commands ran serially and once. Fresh pass/fail/skip identities matched retained generation 2 at every gate. Gate 9 was exactly the four-package projection of gate 10. The full run added 72 internal and six admission pass identities over the rejected 5,096, with zero removals. N-1’s five identities were disjoint. [Exact identities, packages and per-command hashes](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/fresh-reconciliation.json)

```sh
GO=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go
GOFMT=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/gofmt
N1_SOURCE=/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/n1-source
M_SOURCE=/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/migration-source
I=es/admission/internal/reliablesubmit
A=es/admission

"$GO" version
"$GOFMT" -d docs_contract_test.go "$I/sqlite_store.go" "$I/sqlite_replay_claim.go" \
  "$I/sqlite_migrations.go" "$I/sqlite_replay_progress_schema.go" "$I/sqlite_replay_shape.go" \
  "$I/durable_record.go" "$I/durable_operation.go" "$I/durable_service.go" \
  "$I/replay_custody_format.go" "$I/replay_custody_structure.go" "$I/replay_custody_file.go" \
  "$A/reliable_submit_replay_format.go" "$A/reliable_submit_replay_hydration.go" \
  "$A/reliable_submit_replay_private.go" "$I/sqlite_pooled_claim_read_cleanup_test.go" \
  "$I/replay_progress_test.go" "$I/replay_custody_file_test.go" "$I/sqlite_store_test.go" \
  "$I/sqlite_physical_test.go" "$I/sqlite_replay_migration_test.go" \
  "$I/sqlite_replay_shape_test.go" "$I/guardrails_test.go" "$A/reliable_submit_guardrails_test.go" \
  "$A/reliable_submit_replay_private_test.go" "$A/workstream_c_guardrails_test.go"
git --no-pager diff --check
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateOriginalReplayProgressContractSelection|TestReliableSubmitPersistenceAndConcurrencyADRDocsContract|TestSubmitIdempotencyCorrelationAndRecoveryDocsContract|TestReliableSubmitPureModelDocsAndSourceContract|TestReliableSubmitPublicOptInAndVersioningDocsContract|TestReliableSubmitContractAdapterFoundationDocsAndSourceContract|TestReliableSubmitBindingProducerDocsContract|TestIntegratedAcceptanceGateDocumentationIsConsistent|TestIntegratedCandidateStatusSeparatesCAndT)$' .
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestSQLitePooledClaimReadCleanup$' ./es/admission/internal/reliablesubmit
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateReplayProgressConfirmationEligibility|TestPrivateReplayProgressReconciliationEligibility|TestPrivateReplayProgressTerminalEvidenceBinding|TestSQLiteMigrationOpeningRevalidatedUnderLock|TestSQLiteLiteralInternalNamespaceQualification|TestPrivateReplayScope1PublicationPreflight|TestPrivateReplaySharedObjectAllocation|TestReplayPublicationFaultAndIdentity|TestPrivateReplayProgressFormatVectors|TestPrivateReplayProgressTransitions|TestPrivateReplayProgressConcurrencyAndCommitOutcome|TestSQLiteV4MigrationPreservesFullState|TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation|TestSQLiteV3OldBinaryRefusesWithoutMutation|TestSQLiteLegacyCASConnectionCleanup|TestReplayOriginalKeyReadCleanup|TestReplayOriginalKeyReadCallerRefusal|TestReplayGrantC1PreCommitConnectionQuarantine|TestReplayGrantD1BeginResponseLossQuarantine|TestReplayKeyStateD1BeginResponseLossQuarantine|TestReliableSubmitPrivatePersistenceStaticGuardrails)$' ./es/admission/internal/reliablesubmit
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateReplayProgressOccupiedDisposition|TestPrivateReplayProgressAdmissionReplay|TestPrivateReplayProgressHasNoEffectPaths|TestReliableSubmitFoundationHasNoRuntimeWiring|TestReliableSubmitBindingProducerHasNoProductionCaller|TestPrepareRequestShapeRemainsLegacyAndUnkeyed|TestResolvedSubmitLegacyEquivalenceOneNomadRegistrationAndAuthorityRecovery)$' ./es/admission
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestWorkstreamCContractPrepareAndSubmitRemainSeparatedAtAPIBoundary|TestSubmitPublicRouteRejectsStructuralReliableBody)$' ./es/api ./es/app
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=600s ./es/admission/internal/reliablesubmit ./es/admission ./es/api ./es/app
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=600s ./...
(cd "$N1_SOURCE" && "$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestPrivateReplayProgressAdmissionUnknownNoEffects$' ./es/admission)

# Additional guarded commands, after the primary sequence.
(cd "$N1_SOURCE" && "$GO" list -mod=readonly -deps -test -json ./es/admission)
(cd "$M_SOURCE" && "$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestIndependentMigrationClosedWrapperBeforeCommit$' ./es/admission/internal/reliablesubmit)
```

The additional `go list` exited 0. The migration diagnostic ran with 430 matched candidate leaves and one added test, SHA-256 `e0b662c8c5d084b209362be82ad54198a7cee85fa1966e9228953bbedad3ba21`. Its 431-file view digest was `6b461c8188c7397cdadc7a1b1dae9db0f2e856886548b9b8fadd75bfd4beeeda`, and its raw log SHA-256 was `28b632fc2d5c1a9cac35586eb0ca7454ff7d9530c22a8c04c12c0a5a728b2375`. Audit harness setup corrected a Python literal and followed the Homebrew Git executable symlink before the product commands. Neither attempt executed a product test.

### All 39 skips

The two direct helper skips were `TestPrivateReplayObjectAllocatorHelperProcess` and `TestSQLiteClaimStoreLockHelperProcess`. The shared allocator’s parent logged both `SHARED_ALLOCATOR_READY` and `SHARED_ALLOCATOR_WON`, proving child execution. The Docker daemon was unreachable in the `desktop-linux` context. `TestBringupScriptUpCheckDownFullProfile` skipped on that failed reachability requirement. `TestSubmitFlowMountsGovernedArtifactAndLifecycleWithInstalledSourceIdentity` skipped because the direct Docker Unix socket was unavailable. The other 35 App identities below skipped with Docker daemon probe exit 1 and connection unavailable.

```text
TestControlPlaneStaticScriptAPIPathCancelSucceeds
TestControlPlaneStaticScriptAPIPathFetchesRetainedResultBundle
TestDiagnosticsScriptRunIDBundleCollectsLifecycleSignalsAndStaging
TestExecuteLoopScriptFailureSummary
TestExecuteLoopScriptSuccessAndDeterministicDigests
TestExecutionCancelRetainsStageRootForDebugging
TestExecutionCancelStopsNomadJob
TestExecutionLogsReturnConflictWhenAllocationNotReady
TestExecutionLogsReturnRealContainerOutput
TestExecutionLoopScriptSuccessRetainsDistinctStageRootsAcrossRepeatedRuns
TestExecutionResultBundleAndStageRetainedAcrossStatusAndRepeatFetch
TestExecutionResultReturns404ForTerminalExecutionWithoutResultOutput
TestExecutionStatusReflectsFailedAllocation
TestExecutionStatusReflectsNomadJobState
TestExecutionStatusRetainsFailedStageRootForDebugging
TestExecutionStatusRetainsSuccessfulStageRootAndLogsStillWork
TestExecutionStatusReturns503WhenNomadUnavailable
TestLifecycleScriptCategorizesExecutionFailure
TestLifecycleScriptObservesExecutionViaPublicRunID
TestRuntimeIdentityIntegrationCapabilityProbe
TestSubmitFlowAllowsConfiguredControlPlaneCallerHandoff
TestSubmitFlowDoesNotStartWorkloadBeforeHelperReadiness
TestSubmitFlowHelperDeathIsTaskFatal
TestSubmitFlowInjectsWorkloadIdentityEndpointAndLifecycleStillWorks
TestSubmitFlowMountsGovernedArtifactAndLifecycleStillWorks
TestSubmitFlowProvidesPlatformOwnedRuntimeIdentityThroughBoundedEndpoint
TestSubmitFlowRejectsRuntimeIdentityPassthroughRequests
TestSubmitFlowRejectsWorkloadArchiveWithSymlinkEntry
TestSubmitFlowRemovesRuntimeMountArchiveResidueAfterExtraction
TestSubmitFlowRunsStaticScriptInNomadDocker
TestSubmitFlowUsesBridgeNetworkWhenNetworkAccessEnabled
TestSubmitFlowUsesConfiguredRuntimeIdentityTmpfsSize
TestSubmitFlowUsesPlatformOwnedIdentityForVaultLoginAndSecretRead
TestSubmitValidOperatorCallerReturnsAcceptedSubmissionReceipt
TestWorkloadCanCreateAndUseLocalRuntimeIdentityEndpointFromTmpfsWorkspace
```

## Closing record

Each primary command and external diagnostic had separately executed before/after source checks. The complete 430-leaf scoped guard remained `f1c6f9004eebcf317da80402e152ed95af2a8a0d98c1d9308e2b50976208fcef`. Closing rechecked 4,901 relied-upon file bindings, removed the audit-owned cache and temp directories, restored the copied probes to `0600`, and reran the authenticated recipe twice on the actual checkout. The test-owned temporary fixtures and helper processes used their maintained cleanup paths. I performed no global temp sweep. Both external source views and their guards were retained under private `0700` parents, with retained regular evidence at `0600` and copied source modes preserved.

The audit artifact index SHA-256 is `0fd8c79d0b2ac8e20f23aadd92045b03df30528e07331225aa58f124fb0a43bf`. Fresh reconciliation is `e08c3eaf8fab07238773f3d39278590c7e950344d26f60c96874de579a40c285`. Retained generation and differential reconciliation is `753254dcea05f88575517733cab446390d7be856a8850e8869111ec3f2054c77`. [Artifact index](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/artifact-index.json) · [Closing result](/Users/ds/Repositories/ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-SWraKalB/closing-b-result.json)

The performed effects were local read-only inspection, private evidence creation, offline builds, fixture migrations, maintained loopback mocks and helpers, and read-only Docker capability checks. Dependency downloads, installations, network Git operations, live stack, operational migration, real key loading, deployment and product repair were outside the executed scope.

```text
SOURCE_REPOSITORY_NOT_MUTATED
SOURCE_REFS_NOT_UPDATED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PRS_NOT_MODIFIED
EXISTING_OTHER_SOURCE_CHECKOUTS_NOT_SYNCHRONIZED
CROSS_RESTART_OPERATIONAL_WRITE_UNCERTAINTY_GATE_NOT_IMPLEMENTED
RUNTIME_WIRING_NOT_PERFORMED
PUBLIC_RELIABLE_SUBMIT_NOT_ENABLED
NATIVE_INSTALLED_SOURCE_WITNESS_NOT_QUALIFIED_BY_THIS_SLICE
```
<!-- END APPENDIX D -->

## Appendix E — Exact-source review conclusions and inspection limits

Bytes: 14501
SHA-256: 331e72b2914d45dd5dbba5aaa282b81f71f6f911b28941738573dd25cd45f3d4

<!-- BEGIN APPENDIX E -->
# Private replay-progress M-1 / owner-inventory repair — exact-source review

Date: 2026-11-19 (America/New_York)
Posture: static inspection of supplied archives and reports. No repository command,
product test, migration, probe, dependency installation, patch application or live
service was executed. Hashing and in-memory text comparisons inspect artifacts only.

## Decision

The exact packet is internally consistent. The six-file repair implements the
selected pre-COMMIT recovery routing and synchronization-owner correction in the
inspected source. No additional blocker was identified in this targeted pass.
Proceed to a fresh independent audit of the complete thirty-path candidate. This
is not independent behavioral acceptance, a local commit gate, or runtime authority.

The previous REJECT remains attached to canonical manifest
`0812091529c67f4bc46d0bc343b3dea8595e63a461264e143d51606e581e0c06`.
The new target is `f92b57f48a701a606e8a0697b75dac8f691e3eb44c13b9c92afb894ec6e1d718`.
No historical verdict or failed validation is relabeled.

## 1. Exact packet and preservation checks

Inspected upload: `ES-Private-Replay-Progress-M1-Owner-Repair-Review.zip`.
955,015 bytes; SHA-256
`3b27c483036296304a9fbca77dcd5fe522dee64b8eabf392057b6c573160f59a`.

Opening reference upload:
`ES-Private-Replay-Progress-Consolidated-Repair-Review.zip`.
900,863 bytes; SHA-256
`e3cac3bc27bbfd8c1c18d1abf3aabc00077e632e14bd6e6b92e26e020c9c1be6`.

Checks completed:
- All 47 entries are uniquely named regular files, without absolute, traversal,
  backslash or link entries. There are no extracted repository or Git mutations.
- The self-excluding inventory covers all other 46 entries exactly, with matching
  SHA-256, byte length and archived mode. Source members are 0644; evidence 0600.
- All thirty full source payloads match the new canonical manifest.
- The archived opening manifest equals the previously verified reference
  manifest byte-for-byte.
- Exactly six paths changed; twenty-four full candidate payloads and modes are
  identical to the reference archive. No path was added to the candidate.
- The source map agrees with both archived manifests and all delivered payloads.
  Pinned HEAD source-map rows are reference evidence, not independently fetched
  live Git objects in this pass.
- `HEAD.patch` has 27 file sections and 180 hunks. All target-side hunks and full
  target Git blob identifiers match delivered source. Its complete pinned-HEAD
  origin and 400 unchanged source leaves remain for host audit.
- `opening-to-repaired.patch` has six file sections and sixteen hunks. Both
  sides, Git blob identifiers, and every unchanged interval match the full
  supplied opening and repaired files.
- `opening-tracked-to-repaired-with-additions.patch` has nine sections and nineteen
  hunks: the same six modifications plus the three pre-existing untracked source
  additions expressed as new-file diffs. Its source/target hunks, Git blobs and
  unchanged intervals also match. No patch was applied to a repository.
- The exact 7,275-byte v2 recipe matches
  `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`.
  It was read as source and not executed here.
- The exact inline report JSON equals the archived final manifest; the older
  malformed hash transcription is not repeated in this target.

| Item | Bytes / SHA-256 |
|---|---|
| Final canonical manifest | 6,813 / `f92b57f48a701a606e8a0697b75dac8f691e3eb44c13b9c92afb894ec6e1d718` |
| Opening canonical manifest | 6,813 / `0812091529c67f4bc46d0bc343b3dea8595e63a461264e143d51606e581e0c06` |
| Final tracked HEAD patch | `793e6697cf2342ce41f08ed8f59a0a14eb5c288c74780f158731d55dbe17bcca` |
| Full opening delta | `211a5522dfc8b5401f7361c5148ce53dc7eaef06e56787231e2624783d064cc2` |
| Tracked-opening delta plus additions | `951c9353a69a37340f122bfd92b4c17ec3e2f514c70cd1e614d7665c3cf0175c` |
| Source map | `d8bae35ede66a6b66b093e457a879ba4b633c7b8dc14ad7c8742801f2a3fc976` |
| Delivery inventory | `a24629ff1c02e4498dcb5a7f66779faf4057d29b00bce9b756572d77236cd6ee` |

The six changed paths are:
1. `PLANS.md`
2. `.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md`
3. `.docs/execution_lifecycle/es_execution_admission_model.md`
4. `docs_contract_test.go`
5. `es/admission/internal/reliablesubmit/sqlite_store.go`
6. `es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go`

## 2. M-1: the missed boundary now reaches checked observation

Source inspection:
- `sqlite_store.go:58–59` introduces a migration-local recovery-needed sentinel,
  not a new durable result or general error-mapping rule.
- `:669–709` retains guarded BEGIN, independent bounded rollback, cleanup-context
  observation before self-cancel, and lock-held opening verification. The recovery
  route requires `migrationStarted`, set only after authentic opening qualification.
- `:687–693` permits the closed-wrapper case or confirmed exact discard to hand
  off to the unpublished opener. `sql.ErrConnDone` is not classified as recovered
  old, physical-close success, or successful rollback.
- `openGate` still defers connection release (`:557–568`). Its ownership completes
  before the opener handles the new sentinel.
- `openSQLiteClaimStore:99–123` checks original pool closure before opening the
  new observation pool, invokes `verifyMigrationRecovery` rather than `openGate`,
  and gives observed caller cancellation precedence over an otherwise safe
  classification. Refusal closes the observation pool and returns no store.
- `verifyMigrationRecovery:628–667` remains executable-byte-identical to opening.
  Its comment now explicitly separates a current-state observation from
  attribution to the transaction with uncertain cleanup/response.
- `:744–748` routes actual COMMIT-response loss through the same local readback
  signal while retaining the distinct COMMIT-attempt boundary.
- Shared discard, BEGIN, rollback, readers and claim/CAS code are unchanged.

Only `openSQLiteClaimStore` and `migrateSQLite` have changed executable function
bytes. The third function named in the report has a comment-only change.
`loadClaimFresh`, including its final separator, is 1,077 bytes and equals both
packets at SHA-256
`3a47f8b5e0c5bf7bec899987aa78fdf4ef48a585086d9eb975e576896ab4b61c`.

The owner ADR at :1706–1755 states the same sequence: valid lock-held baseline,
safe ownership handoff, checked unpublished-pool close, fresh caller-context
nonmigrating observation, then classification. The signal itself grants no result.
A current head is not own-COMMIT confirmation for a call with zero COMMIT attempts.
There is no migration retry in this path.

### Maintained regression

`sqlite_replay_migration_test.go:715–811` has twelve leaves:
schemas 0/1/2/3 × ClosedWrapper / OrdinaryRollback / CanceledReadback.

The decisive case:
1. Constructs authentic fixtures, with populated schema-3 rows, registry, grants,
   ledger and a separately retained sealed original.
2. Calls the real opener and verifies current schema 4 on the exact transaction
   connection inside `beforeMigrationCommit`.
3. Closes the actual high-level wrapper, independently checks its unusable state,
   and returns an injected pre-COMMIT error. It does not inject through the later
   COMMIT collaborator.
4. Requires one migration-entry observation and pre-COMMIT callback, zero COMMIT
   calls, no store handle, and the exact recovered-old category.
5. Compares unfiltered logical schema/pragmas/all fixture rows with an independent
   read before teardown or any later normal opener. It also compares seal bytes.

The witness at :579–624 reads unfiltered `sqlite_schema`, both identity/version
pragmas, and `rowid,*` for every fixture table; it does not rely on the previously
defective schema filter. Ordinary rollback and canceled-readback controls demand
unavailable and logical preservation. The retained 3,823-byte regression duplicate
equals the exact maintained function at SHA-256
`d620acb40a0374532c0e0b80a595fa55d32e72139c2d997ce6547a69f1587511`.

The packet's metadata reports eight red passes and five failures, including the
parent, versus thirteen green passes. These logs were not included and not run
here. The fresh auditor must authenticate the retained source views, outcomes and
run records, and independently execute the maintained cases.

### Qualifications to retain

Wrapper invalidation, pool close and physical driver teardown are not synonymous.
This code now checks the owning pool's close result before observation, but this
review does not prove physical-close failure behavior or bounded close duration.
No hard latency promise, blanket ErrConnDone success rule, store-wide poison
flag, or automatic retry should be inferred. The previously accepted logical
preservation and operational restrictions remain the relevant bounded contract.

## 3. DOC-SYNC: exact source inventory, no implementation widening

Admission §7.4 (:910–977) now contains the exact thirty-two structural field
identities from the archived frozen Workstream C literal. Independent text/set
comparison found exact equality and the same categories:
- five direct mutex fields;
- three atomic.Bool fields;
- twenty-four transitively synchronization-bearing reference/request/wrapper fields.

This is not thirty-two independent locks. The two tables distinguish primitive
owners from carriers; a third table binds permit construction, readers, consume,
matchesAllocation and burn. Runtime-unwired fixture code is still included in
non-test production-source inventory, and SQLite remains committed-fact authority.
The following rejected A3 topology §7.5 remains unchanged.

`docs_contract_test.go:12556–12719` parses only the named finite Go string literal,
normalizes its module prefix, compares exact document field/category sets, checks
the permit role table and boundaries, and includes four targeted mutants:
MissingAtomic, OmittedScope2Wrapper, OmittedSharedPermitReader, and
ReferenceClaimedAsPrimitive. The checks are not a substitute for the separate typed
scanner; that scanner remains byte-frozen and is explicitly included in the audit
validation selector.

At :414–416 the older resolved-plan test changes only three exact field spelling
assertions from the prior notation to the new documented notation. It neither
drops those locks nor suppresses that test. Other owner-assertion changes reflect
the selected pre-COMMIT observation rule. PLANS.md records pending independent
acceptance rather than claiming the repair accepted.

The report preserves development setup/mutant failures and the first full-suite
failure caused by those old spellings. Generation 2, not generation 1, is the
advertised final target. Exact-source inspection supports the limited nature of
that change; it does not establish the recorded execution results.

## 4. Preserved integrated slice and external N-1 inputs

The other twenty-four full source files are byte- and mode-identical to the
previously audited candidate. This includes Workstream C, all format/schema
literal files in the patch, durable-operation/record files, the seven earlier
finding repairs, and the pooled-reader regression. This is preservation, not an
automatic transfer of an acceptance verdict to a newly changed complete candidate.

Both N-1 additions are byte-identical to the prior packet and prior prompt:
- bridge: 789 bytes,
  `14f0e9e92a37e1d1bf624f1f052a62a6d56e5b82f988698abbf6e1b5bcf9196d`;
- witness: 5,897 bytes,
  `8da31dd61c9af2537c15f4376a330d05cb2e55dd2efd0ea610472a0c6ffa5c6a`.

I reread both. They remain external-only. The bridge attaches/restores the chosen
store's existing COMMIT hook, performs a real COMMIT and models loss of its
response. The witness independently exercises establishment and AssignRun with
canceled or exact authenticated recovery, restores the hook before later reads,
and checks one COMMIT, disposition/projection, sealed-object count, zero effect
contacts and empty operational roots.

The archived view metadata binds 432 files and the new manifest. All thirty
delivered source rows and both external additions match those entries. The
build-input inventory has 2,801 physical-input rows and 291 package records.
The generated test-main source is retained as evidence text, not repository
product source or a new authority. Its payload is inspectable, but host module,
toolchain, cached inputs and omitted baseline files were not reproduced here.

## 5. Reported validation and next gate

Report-derived final generation 2:
- owner contracts: 27/0/0;
- pooled reader: 16/0/0;
- internal focused and historical probes: 221/0/0;
- admission including typed Workstream C: 26/0/0;
- App/API: 2/0/0;
- four packages: 2,062/0/39;
- full tree: 5,192/0/39 (21 tested, 20 no-test packages);
- external N-1: 5/0/0, separate from ordinary suite.
The full suite adds thirteen migration identities and five owner identities to
5,174. Counts are consistent; raw identity multisets/guards require host audit.

Next: fresh repository-read-only independent audit at
`/Users/ds/Repositories/ES-Private-Replay-Progress-v1`.
Adjudicate M-1 and DOC-SYNC explicitly, verify preservation of the seven prior
resolved findings, and inspect complete integrated interactions. Run all eleven
final commands for ACCEPT, including a fresh external N-1 view of the actual final
candidate. No source repair, staging, commit, publication or runtime wiring.

## 6. Where inspection stopped

Directly inspected: every six-file repair hunk, the complete relevant opener and
migration functions, existing current/old readback classifier, cleanup helpers,
maintained regression and witness, owner tables and their root tests, corresponding
frozen typed inventory, N-1 source and metadata, canonical maps and all archive
payload hashes. The appendices below preserve the load-bearing source excerpts.

Not established here: live branch/index/ref/config state; byte equality of the
400 absent unchanged baseline files; actual red/green or generation-2 execution;
private raw logs and probe binaries; host build-input identities; physical-close
faults; native installed-source identity; provider acceptance; operational
cross-restart write-uncertainty eligibility. These remain reported evidence or
outside-slice nonclaims, not inferred successes.

Confidence: packet/source binding 0.99; targeted static repair assessment 0.96;
fresh-audit handoff readiness 0.98. No independent implementation acceptance.

<!-- END APPENDIX E -->

## Appendix F — External N-1 bridge — es/admission/internal/reliablesubmit/admission_unknown_witness_bridge.go

Bytes: 789
SHA-256: 14f0e9e92a37e1d1bf624f1f052a62a6d56e5b82f988698abbf6e1b5bcf9196d

<!-- BEGIN APPENDIX F -->
package reliablesubmit

import (
	"context"
	"database/sql"
)

// AttachAdmissionUnknownWitnessCommit is present only in the external fixture
// view. It models response loss after the selected store's real COMMIT.
func AttachAdmissionUnknownWitnessCommit(c *PrivateReplayProgressCustody, afterCommit func()) (counts func() (int, int), restore func()) {
	store := c.custody.store
	previous := store.claimCommit
	attempted, committed := 0, 0
	store.claimCommit = func(ctx context.Context, conn *sql.Conn) error {
		attempted++
		if err := commit(ctx, conn); err != nil {
			return err
		}
		committed++
		if afterCommit != nil {
			afterCommit()
		}
		return errClaimStoreCommitUnknown
	}
	return func() (int, int) { return attempted, committed }, func() { store.claimCommit = previous }
}

<!-- END APPENDIX F -->

## Appendix G — External N-1 witness — es/admission/reliable_submit_admission_unknown_witness_test.go

Bytes: 5897
SHA-256: 8da31dd61c9af2537c15f4376a330d05cb2e55dd2efd0ea610472a0c6ffa5c6a

<!-- BEGIN APPENDIX G -->
package admission

import (
	"context"
	"crypto/sha256"
	"errors"
	"maps"
	"net/http"
	"os"
	"path/filepath"
	"sync/atomic"
	"testing"

	"execution-substrate/es/admission/internal/reliablesubmit"
)

func TestPrivateReplayProgressAdmissionUnknownNoEffects(t *testing.T) {
	for _, operation := range []string{"Establish", "AssignRun"} {
		for _, recovery := range []string{"Canceled", "AuthenticatedExact"} {
			t.Run(operation+"/"+recovery, func(t *testing.T) {
				ctx := context.Background()
				s, raw, caller, keys, image := privateReplayServiceFixture(t)
				var provider, staging, egs atomic.Int64
				s.nomadClient = newResolvedPlanNomadClient(t, http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
					provider.Add(1)
					w.WriteHeader(http.StatusInternalServerError)
				}))
				s.egsClient = newResolvedPlanDependencyClient(t, http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
					egs.Add(1)
					w.WriteHeader(http.StatusInternalServerError)
				}))
				beforeStagingChildRegistrationStatForTest = func(string, int, bool) { staging.Add(1) }
				beforeStagingHandoffValidationForTest = func(*stagingCustody) { staging.Add(1) }
				defer func() {
					beforeStagingChildRegistrationStatForTest = nil
					beforeStagingHandoffValidationForTest = nil
				}()
				catalog, err := newPrivateSyntheticKeyCatalog(keys)
				if err != nil {
					t.Fatal(err)
				}
				root := privateReplayTestRoot(t)
				c, err := reliablesubmit.OpenPrivateReplayProgressCustody(ctx, root)
				if err != nil {
					t.Fatal(err)
				}
				defer c.Close()
				objects := func() map[string][32]byte {
					t.Helper()
					dir := filepath.Join(root, "objects", "v1")
					entries, err := os.ReadDir(dir)
					if err != nil {
						t.Fatal(err)
					}
					got := make(map[string][32]byte, len(entries))
					for _, entry := range entries {
						b, err := os.ReadFile(filepath.Join(dir, entry.Name()))
						if err != nil {
							t.Fatal(err)
						}
						got[entry.Name()] = sha256.Sum256(b)
					}
					return got
				}
				if operation == "AssignRun" {
					status, p, err := s.admitPrivateProgressReplay(ctx, c, raw, caller, catalog, image, reliablesubmit.FixturePendingBeforeAssignment)
					if err != nil || status != reliablesubmit.FixtureProgressCommitted || p.Revision() != 1 {
						t.Fatalf("initial control did not establish: %d %d %v", status, p.Revision(), err)
					}
				}
				before := objects()
				invocation, cancel := context.WithCancel(ctx)
				defer cancel()
				var after func()
				if recovery == "Canceled" {
					after = cancel
				}
				counts, restore := reliablesubmit.AttachAdmissionUnknownWitnessCommit(c, after)
				defer restore()
				var disposition reliablesubmit.FixtureProgressDisposition
				var projected reliablesubmit.FixtureProgress
				run := reliablesubmit.NewFixtureRunRef([32]byte{91})
				revision := int64(1)
				if operation == "Establish" {
					disposition, projected, err = s.admitPrivateProgressReplay(invocation, c, raw, caller, catalog, image,
						reliablesubmit.FixturePendingBeforeAssignment)
				} else {
					revision = 2
					disposition, projected, err = s.applyPrivateProgressReplay(invocation, c, raw, caller, catalog, 1,
						reliablesubmit.NewFixtureMutationRef([32]byte{92}), reliablesubmit.FixtureAssignRun{Run: run})
				}
				restore()
				attempted, committed := counts()
				if attempted != 1 || committed != 1 {
					t.Fatalf("expected one intended real COMMIT, attempts=%d committed=%d", attempted, committed)
				}
				want := reliablesubmit.FixtureProgressOwnCommitConfirmed
				projection := revision
				var wantErr error
				if recovery == "Canceled" {
					want, projection, wantErr = reliablesubmit.FixtureProgressWriteUnknown, 0, errPrivateReplayCommitUnknown
				}
				if disposition != want || !errors.Is(err, wantErr) || projected.Revision() != projection {
					t.Fatalf("invocation disposition=%d projection=%d err=%v", disposition, projected.Revision(), err)
				}
				if gotRun, present := projected.Run(); present != (projection == 2) || (present && !gotRun.Equal(run)) {
					t.Fatal("faulted invocation exposed an ineligible run")
				}
				if _, present := projected.Receipt(); present {
					t.Fatal("faulted invocation exposed a receipt")
				}
				committedObjects := objects()
				if len(committedObjects) != 1 || (operation == "AssignRun" && !maps.Equal(before, committedObjects)) {
					t.Fatal("faulted invocation sealed an additional object or replaced the original")
				}
				later, current, err := (&Service{}).admitPrivateProgressReplay(ctx, c, raw, caller, catalog, privateSyntheticImagePlacement{}, 0)
				if later != reliablesubmit.FixtureProgressCurrent || current.Revision() != revision || err != nil || disposition != want {
					t.Fatalf("later read changed invocation or lost current state: %d %d %v", later, current.Revision(), err)
				}
				got, present := current.Run()
				if present != (revision == 2) || (present && !got.Equal(run)) {
					t.Fatal("later current read did not preserve assigned fixture run")
				}
				if _, operational := any(got).(reliablesubmit.RunRef); operational {
					t.Fatal("test received an operational run reference")
				}
				if provider.Load() != 0 || staging.Load() != 0 || egs.Load() != 0 || !maps.Equal(committedObjects, objects()) {
					t.Fatalf("private admission caused effects: provider=%d staging=%d EGS=%d", provider.Load(), staging.Load(), egs.Load())
				}
				for _, effectRoot := range []string{s.cfg.Execution.StagingRootDir, s.cfg.Execution.ResultsRootDir} {
					entries, err := os.ReadDir(effectRoot)
					if err != nil || len(entries) != 0 {
						t.Fatalf("operational root was not empty: %v", err)
					}
				}
				t.Logf("one real COMMIT, modeled lost reply, disposition=%d projection=%d later revision=%d, provider/staging/EGS=0/0/0, empty roots", disposition, projection, current.Revision())
			})
		}
	}
}

<!-- END APPENDIX G -->
