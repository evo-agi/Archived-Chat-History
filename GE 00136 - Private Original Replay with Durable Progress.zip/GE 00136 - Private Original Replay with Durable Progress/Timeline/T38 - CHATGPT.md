## PR #11 is merged — the private replay-and-progress source slice is complete

**The merge reached the intended endpoint: the expected sole parent and exactly the accepted tree. No further repair, acceptance audit, or publication gate is indicated for these bytes.**

My live GitHub reads confirm that PR #11 is closed and merged, and official `trunk_dev` points to the reported squash commit.  

| Identity | Verified value |
|---|---|
| Squash commit / official `trunk_dev` | `ae326b0ddc30ec6b35883ee32945c622405b68b6` |
| Sole parent | `f1aa8b934cc26c16a966a110c7b408abdaeadce7` |
| Complete accepted tree | `e066cd4afa77fcb665f31b69bf00465989f9744e` |
| Preserved topic commit | `dbdc433283617b9e3b233f75c92f1179c2ece91f` |
| Merge time | November 19, 2026, at 6:47:16 p.m. EST |

The live commit object confirms the parent, tree, subject, and GitHub-verified signature. Codex additionally reports complete comparison of all 430 leaves and preservation of the thirty accepted changes. **I verified the Git identities, not every remote payload again.**  Pasted text

The retained **5,192 passes, zero failures, and 39 skips**, plus five separate N-1 identities, remain authenticated local validation. The merge correctly did not rerun that campaign or claim passing CI. It proceeded under the selected optional-Claude allowance; neither Claude nor security-review acceptance was established. Pasted text

The local checkout remains clean at the topic commit. Its stale `origin/trunk_dev` is intentional. **No pull, reset, branch deletion, or checkout synchronization is needed to close this tranche.** Pasted text

## Next: settle operational dispatch and restart authority before wiring ingress

**I recommend putting the operational handoff/restart contract ahead of disabled-by-default ingress and startup implementation.**

The earlier roadmap proposed ingress/startup after private composition. During this tranche, K1 exposed a prerequisite that must now govern that ordering: the fixture implementation can authenticate current durable state and preserve an invocation’s write disposition, but it deliberately does **not** establish operational permission after restart. The merged contract explicitly requires a separately reviewed operating model before provider wiring. Pasted text 

That is a sequencing refinement, not a reason to reopen the completed fixture work.

### The critical question is permission to act—not merely the ability to load progress

The current operational no-dispatch predicate requires known outcomes for relevant intent, marker, and revision writes. Marker absence alone does not satisfy it. Meanwhile, the accepted fixture contract retains no history-wide response knowledge and expressly prevents fixture markers or receipts from becoming operational authority. Those two boundaries remain intentional. See the persistence ADR `:471–527, 1642–1654`.  

The next design must therefore answer:

> **After uncertainty or restart, which authoritative facts permit this ES instance to perform the first provider dispatch—and what prevents another request, stale holder, or replacement process from doing so as well?**

It must identify sufficient durable evidence or another explicitly governed input, **or explicitly re-derive the operational predicate with a safety argument**. It must not silently substitute a later current-state read, an expired invocation token, a caller’s assertion, or a report.

Nor should we assume that a new response-history ledger is the answer. The decision should establish the minimum facts required by the selected safety model, including any deliberate loss of availability when an outcome remains ambiguous.

### Ordinary Submit is still a separate effect path

The merged ordinary `Submit` still resolves a request, creates a locator, claims and materializes staging, builds a job, and calls the Nomad registration client. The client posts to `/v1/jobs` and checks the response. That path is not yet the reliable progression protocol, and the private fixture facade cannot simply be inserted ahead of it as an authorization switch. See `es/admission/submit.go:36–115, 257–289`.  

The next contract must connect the boundaries deliberately: original authentication, stable run assignment, durable intent, staging ownership, marker commitment, exclusive first send, provider evidence, and recoverable receipt. **Public ingress should consume that selected model—not force its semantics to emerge during wiring.**

## One bounded design pass, with a checkpoint snapshot

The next Codex turn should produce **one concrete operating-model recommendation, proposed owner-contract text, and an implementation acceptance matrix**. It should not be another general “what next?” inventory or a new cleanup campaign.

Its central outputs are:

| Decision | Required result |
|---|---|
| **First dispatch and restart** | Exact authoritative inputs, ownership lifetime, uncertainty treatment, and a complete crash/concurrency table. |
| **Provider and staging boundary** | Creation/collision semantics, transport behavior, positive acceptance evidence, and treatment of partial staging or possible prior sends. |
| **Operational entry and compatibility** | Explicit separation from synthetic scopes, caller/key authorization, state and key ownership, receipt disclosure, and preserved unkeyed behavior. |

The recommendation should distinguish **the full operational target** from **the next source slice**. My preferred next source deliverable is a controlled handoff/restart proof with a fake provider, before public enablement or native execution. Its provider semantics still need grounding in the actual provider contract; a fake provider cannot prove those external guarantees.

The accepted physical-close, timing, capacity, and native-qualification limits should be assessed for their actual impact on that target. They should **not automatically become another series of helper-repair PRs**. Where a residual matters, the design must select either an explicit operating restriction or a concrete prerequisite.

### This is now an appropriate snapshot checkpoint

PR #11 completed an architecture-defining composition and schema change. A new committed-source snapshot is useful here, unlike requiring one after every small reader correction. Project provenance guidance expressly recommends snapshots at architecture-defining checkpoints. Governed Execution Provenance G…

The same turn should export the exact 430-leaf tree and a complete source sidecar. **Snapshot production is a supporting deliverable, not a reason to suspend the design pass pending another upload.**

The merged `PLANS.md` still contains pre-acceptance wording at its top. The next design record should propose the minimal PR #11 closure update alongside the next owner-contract selection—not create a separate cosmetic publication campaign. 

## Next Codex turn

Continue in the **same Codex conversation that completed PR #11’s merge**, using this source checkout explicitly:

```text
/Users/ds/Repositories/ES-Private-Replay-Progress-v1
```

:chatgpt-content-reference{index="15"}[Download the post-PR #11 operational-contract selection and snapshot prompt](sandbox:/mnt/data/ES_Post_PR11_Operational_Submit_Contract_Selection_And_Snapshot_20261119.md)

SHA-256:

```text
be7c51869912f8f3cba7f9b70e31216a91c506e1935e70c6a01da7c420a8caab
```

The prompt embeds the **complete supplied merge closeout unchanged**; I verified the embedded bytes. It permits bounded read-only exploration, source inspection, and external design/snapshot artifacts.

Its intended sequence is:

```text
bind the published checkpoint to the preserved local source
→ inspect the operational boundaries and their tests
→ select one proposed operating model and resolve its critical decisions
→ specify the next doc-first source scope and acceptance evidence
→ export and verify the exact committed-source snapshot
→ deliver the complete report inline
```

The preserved topic and squash have the same tree. **An unfetched local squash object is not a blocker and does not authorize checkout synchronization.** The prompt explicitly permits committed-object inspection and export from the verified topic commit.

Expected endpoint:

```text
ES_POST_PR11_OPERATIONAL_SUBMIT_CONTRACT_DECISION_READY
```

That means the model is ready for owner review and a finite implementation brief. It does **not** mean the proposed contract is implemented.

**No source edits, tests, builds, diagnostics, migrations, probe rebuilds, staging, commits, PR changes, host contact, or runtime wiring are authorized in this turn.** The completed acceptance campaigns stay closed.

## Inspection boundary

I reviewed the complete merge report, verified live PR/commit/base identities, and reopened the merged plan, agent rules, operational persistence and recovery contracts, API handler, and ordinary Submit/provider-call path. I did not execute repository commands or re-audit the complete implementation.

**Source publication is complete. Operational reliable submission remains the next programme objective—not a capability enabled by this merge.** Pasted text

**Sources:** Supplied PR #11 merge closeout; live GitHub PR, squash and branch objects; pinned merged `PLANS.md`, persistence ADR §8/§15B.4, submit/recovery contract, and Submit source; project provenance guidance.

**Confidence:** Merge identity and publication closure **0.99**; assessment of retained validation **0.98**; next-step sequencing **0.96**. The operational model itself remains to be selected and validated.
