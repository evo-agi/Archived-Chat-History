## Exact source review found two implementation gaps — keep the candidate frozen and send it to independent audit

**The packet is authentic and complete. The remaining concerns are in implementation behavior, not provenance or the accepted architecture.** I found two paths that do not enforce their written owner-contract conditions. Their control flow is directly inspectable; I have not dynamically reproduced the proposed counterexamples.

The best next step is **one fresh independent audit of the complete patch**, with these two findings investigated first. Do not start a piecemeal repair yet: the independent reviewers should finish their complementary source reviews and consolidate any additional findings before the next writer turn.

:chatgpt-content-reference{index="4"}[Download the exact-source review, including line-numbered supporting excerpts](sandbox:/mnt/data/ES_Private_Replay_Progress_Implementation_Exact_Source_Review_20261119.md)

## Packet verification passed

The uploaded ZIP matches the reported identity:

```text
Size:
718,150 bytes

SHA-256:
bc4bc721f7aa0f02da9f2427625973e883a82fdc0988e4f587c2140792245cf3
```

I verified all 36 archive entries, the self-excluding delivery inventory, all thirty complete source files, their sizes and archived modes, and the canonical manifest. Both patches’ target-side hunks match the delivered files; the incremental patch’s old-side contract hunks match the previously reviewed K1 packet. The reported archive identity is recorded in the closeout. Pasted text

The exact candidate remains:

```text
Canonical manifest:
110cef71ba25f61b70297b37cc5a50a68732d639845e0ac4315d06cedcdbc1e3

Tracked HEAD diff:
e45e3bd85391191702673b2d40fc2d06d865503004e09a8094c2f6a7081fe0c4

Scope:
27 tracked modifications
3 untracked additions
```

**I did not apply patches or execute repository code, commands, tests, migrations, or probes.** This was static inspection of the supplied artifacts. The live checkout, 400 unchanged tracked files, raw validation logs, and probe binaries remain for Codex’s independent audit to authenticate.

## SR-1: establishment-confirmation reads bypass the operation-entry key check

**Proposed classification: high-severity contract/security-boundary enforcement gap within the private fixture surface.** Final severity and behavioral reachability should be independently adjudicated.

The owner contract requires `ReadFixtureProgress` to check the live access, context, and original-key eligibility at operation entry. Revoked, missing, mismatched, or wrong-purpose keys must refuse. Separately, it permits an establishment-confirmation read to project the known committed snapshot. That snapshot permission does not expressly waive key eligibility.

The implementation has two different paths:

```text
Ordinary progress read
→ reload current row
→ match immutable original
→ checkOriginalReplayKeys
→ project

Establishment-confirmation read
→ consume access
→ check c.qualified
→ project state.confirmed
```

`c.qualified` checks issuer/context, filesystem parents, and database budget—not registry eligibility.

**Exact source:**  
`es/admission/internal/reliablesubmit/replay_custody_file.go:1263–1278, 1300–1315, 1340–1377`  
**Owner:**  
`.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md:907, 911–932`

The resulting counterexample to test is narrowly ordered:

```text
legitimate establishment
→ original authentication succeeds
→ another fixture handle commits original-key revocation
→ enter ReadFixtureProgress on confirmation access
→ confirmation branch returns its snapshot without rechecking that key
```

This is **not** a demand for instantaneous cross-process revocation. The proposed test places the revocation commit **before the read method’s entry**, where the contract requires the check.

Nor does the correction need to replace the permitted committed snapshot with later progress. **Which snapshot may be returned and whether the operation is currently eligible are separate questions.** If projection is refused, a previously known commit must remain known; withholding its projection does not undo that write.

The audit should cover both known-committed establishment and recoverable uncertain establishment, with active/retired controls and the ordinary current-read path. No new claim mutation, Seal operation, or public disclosure has been demonstrated by this static finding.

## SR-2: retained reconciliation history can be accepted as an ineligible fresh no-op

**Proposed classification: medium-severity durable-service semantic/contract mismatch.**

R1 deliberately permits a nonterminal reconciliation tuple to remain as historical evidence after later progress. The contract also says that an identical reconciliation fact may be accepted as a fresh no-op **only while that kind’s current evidence predicates still hold**.

The implementation checks whether the stored reconciliation kind and reference equal the request and returns the current record immediately. For Pending, Ambiguous, and Inconsistent reconciliation, that equality return precedes a general check of the current recording predicate.

**Exact source:**  
`es/admission/internal/reliablesubmit/durable_service.go:402–457, 1193–1227`  
**Owner:**  
`.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1471–1490`

A concrete sequence is:

```text
record Pending reconciliation
→ accept the same attempt with valid stronger evidence
→ retain the historical Pending tuple, as R1 requires
→ authenticate afresh
→ submit the same Pending fact with a new mutation ID
   and the current revision
→ equality branch reports NoChange
```

That request is **neither exact latest-operation replay nor stale**. Yet the Pending recording predicate requires a candidate phase, not the accepted terminal phase.

The predicted defect is an ineligible command being reported as a valid no-op, potentially with a terminal projection—not a second durable mutation. The same distinction should be checked after incompatible provider progression.

The repair, if confirmed, must preserve all three legitimate behaviors: historical tuples remain retained; eligible same-fact no-ops remain available; exact latest replay keeps its precedence. **Dropping history or reinstating R1’s old phase trap would be the wrong correction.**

## The accepted architecture remains selected

Neither finding requires reopening K1, R1, the shared allocator design, or the old-binary strategy.

The implementation contains the intended original-preserving successor and same-original checks, distinct fixture capability types, invocation-scoped recovery, and shared allocation path. The review’s remaining questions concern whether those mechanisms enforce every selected condition on every exit—not whether the system should return to the earlier design.

The audit must still examine the rest of the integration, especially migration preservation and recovery, capability/close ordering, known CAS-loss and other no-write returns, and admission-level uncertainty mapping. The expanded synchronization inventory is an exact-source inventory to inspect, **not proof of safe lifetimes and not “32 new locks.”** Codex reports that it expanded from five to thirty-two typed entries. Pasted text

The reported **5,096 passes, zero failures, and 39 skips** remain valuable validation evidence, but they do not resolve branches that the exercised assertions may not cover. The additional helper-only skip is explained in the report; independent audit should verify that its parent actually executed and checked the helper. Pasted text

## Next Codex conversation

Open a **fresh read-only Codex conversation directly at**:

```text
/Users/ds/Repositories/ES-Private-Replay-Progress-v1
```

Use:

:chatgpt-content-reference{index="5"}[Download the complete private replay-progress independent-audit prompt](sandbox:/mnt/data/ES_Private_Replay_Progress_Fresh_Independent_Audit_20261119.md)

SHA-256:

```text
036898e3dfa8137b9986f085bbe31a12b1e65783233849c3f56513b9643bf652
```

The prompt embeds four byte-verified inputs: the complete implementation closeout, exact thirty-file manifest, exact v2 provenance recipe, and this source review with its supporting excerpts.

The author conversation may remain attached to A1. **Do not move or synchronize either checkout.** This fresh audit simply targets the progress checkout explicitly.

### Audit sequence

The prompt directs Codex to authenticate the exact candidate, then use four independent read-only perspectives covering contract/state semantics, SQLite/migration correctness, custody/capability/filesystem boundaries, and test/evidence/no-effect assurance.

The foreground parent runs bounded external diagnostics for SR-1 and SR-2 using real SQLite and the existing fixture APIs. Those diagnostics must preserve complete source and test bytes, distinguish setup failures from substantive outcomes, and independently confirm or refute the findings rather than treat my review as an oracle.

**The source-review perspectives should finish even if one blocker is confirmed**, so the next repair can address a consolidated finding set.

If a blocking defect is confirmed, the auditor may omit an expensive whole-suite replay that cannot change the verdict, while explicitly listing every unrun command. If no blocker remains, `ACCEPT` requires the complete ten-command validation sequence against the unchanged target. No acceptance follows merely from authenticating the implementation’s earlier green logs.

The audit authorizes **no source repair, staging, commit, push, PR change, or runtime action**. It does not reopen the historical socket campaign, rebuild PB1, require a new snapshot, or fingerprint every old evidence directory. After it concludes, the same audit conversation may perform a separately instructed repair; changed bytes will require fresh independent acceptance.

## Inspection boundary

This was a **targeted exact-source review**, not exhaustive certification of all 430 candidate leaves. I inspected the relevant complete functions, schemas, changed contract passages, tests, and guard inventories. I did not independently execute the advertised validation or establish physical-close behavior.

The bounded disposal limitations, database-size detection limit, native installed-source gap, and unimplemented operational cross-restart write-uncertainty gate remain unchanged. **Public reliable Submit is still unavailable.** The implementation closeout explicitly preserves those nonclaims. Pasted text

**Sources:** Exact uploaded implementation ZIP; prior K1 contract ZIP; delivered owner contracts and source locations cited above; implementation closeout for reported validation. The linked review contains verbatim line-numbered excerpts supporting both findings.

**Confidence:** Packet/source binding **0.99**; SR-1 static finding **0.94**; SR-2 static finding **0.98**. Dynamic confirmation and overall implementation acceptance remain outstanding.
