# Execution Substrate — Implement private original replay with durable claim progress

## Objective, acceptance target and permitted endpoint

Implement the integrated fixture-only source slice selected by the exact K1-corrected owner contract. Preserve one authenticated immutable original while its single claim/attempt acquires one stable fixture RunRef and advances through the existing durable service and revision CAS. Include the pooled `loadClaim` prerequisite and shared object allocator before their new consumers. Prove restart, concurrency, exact-operation replay, per-invocation commit uncertainty, migration isolation, bounded custody and zero runtime effects.

ChatGPT has inspected the actual K1 review packet and accepts its owner operating model FOR BOUNDED IMPLEMENTATION. K1 is closed. R1 historical reconciliation, R2 allocator ownership and R3 pinned probe origin remain selected. This is not code acceptance or permission for runtime effects. Do not run another contract-only review or create a separate documentation/reader-only PR merely to begin.

The foreground parent is authorized to edit only the source/test/document paths below and run the specified offline implementation validation and test-owned fixtures. Proceed through the implementation phases in order within the same candidate. They are internal dependency gates, not separate commits, PRs or routine human approvals. Complete the available work in the foreground; report a precise partial checkpoint if unfinished rather than claiming readiness.

Successful endpoint, only after complete final validation and provenance:

    ES_PRIVATE_REPLAY_PROGRESS_IMPLEMENTATION_READY_FOR_FRESH_INDEPENDENT_AUDIT

Stop unstaged and uncommitted. No staging, commit, amend, push, PR creation/change, merge, auto-merge, deployment, host operation, public reliable Submit, provider-wired path, or runtime wiring is authorized. A later fresh read-only conversation independently audits the entire final patch.

## 1. Conversation routing and sole-writer posture

Continue in the SAME foreground Codex conversation that authored the K1 contract. It may remain attached to and initially open at:

    /Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1

That is NOT the source target. The sole writable checkout is the existing standalone:

    /Users/ds/Repositories/ES-Private-Replay-Progress-v1

Use explicit working directories for EVERY relevant command, `git -C` for scoped Git reads, and absolute edit paths. Do not assume shell `cd` persists. The manifest recipe runs from the progress checkout. Do not relocate the conversation or require a new one for routing alone.

Close prior explorers. The foreground parent is the only writer; spawn no writer or audit subagents in this implementation turn. Inspection and tests here are engineering validation, not independent acceptance.

Verify physical target, Git top-level, git-dir and common-dir. They must identify the expected independent progress checkout, not A1 or shared Git administration. Record starting shell separately. Preserve A1, O2, replay-custody publication, the original ES checkout, and every other repository. A small read-only opening/closing A1 identity/status observation is sufficient; do not repeat its audit or fingerprint unrelated history.

If the target is absent, inaccessible, unexpectedly aliased or mismatched, stop before source writes. Do not substitute A1, create another clone/worktree, switch/reset/rebase branches, move a patch, synchronize checkouts or bypass sandbox permissions.

## 2. Exact opening baseline and evidence

Expected source:

    branch: codex/private-replay-progress-v1
    upstream: origin/trunk_dev
    origin: git@github.com:evo-agi/Execution-Substrate.git
    HEAD: f1aa8b934cc26c16a966a110c7b408abdaeadce7
    HEAD sole parent: fb9ae55797d9fcc02863c23fe8d3e43d16eac542
    HEAD tree: 8dd27f9acba98ed70d93736bdef8300ef1aba53f
    committed leaves: 427
    opening changes: exactly five unstaged tracked regular files, 0644/100644
    index: equals HEAD; no staged or unmerged changes
    ordinary-untracked and ignored-untracked: both empty
    other 422 tracked files: HEAD-identical bytes and modes

Opening canonical manifest:

    1331 bytes
    79c3554da0dbbb5c45677092aee07093ee3b5f10d306ed656a7e9922c6c7733b

Opening HEAD-to-candidate full-index binary patch:

    107601 bytes
    75582f2e9b91fdc0ef879c802b4e9af9b04784db48e385e024996c716f480821

Exact reviewed archive, retained locally:

    /Users/ds/Repositories/ES-Private-Replay-Progress-K1-Contract-20261119-fzxf8tt8/ES-Private-Replay-Progress-K1-Contract.zip
    420293 bytes
    SHA-256 03dddf54b405e27fcdeafec2bc40165a2948d15be83a94ef5129c4d26b3c12d7

It contains the five complete source files, both patches, manifest, README and self-excluding inventory. Authenticate the archive and every used entry without executing content from it. Compare the five live files to Appendix B and the complete archive payload. Authenticate the exact Appendix C recipe (7275 bytes; SHA-256 c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca); run it twice to distinct absent private outputs and require the exact opening canonical bytes.

Keep this archive and historical contract reports unchanged. Preserve a complete opening source inventory and the opening five-file target for final delta comparison. The archive does not establish live refs/index/other-file preservation; measure those locally.

The pinned candidate is the source target. No remote query or fetch is required for implementation. Any optional read-only remote observation must be recorded separately; remote movement does not authorize rebasing or silently changing this target. Publication reconciliation occurs later.

Authenticate only material prior evidence actually used. Do not rehash every old evidence root, require timestamp equality, recover old audit-directory mtimes, or repeat completed A1/O2/socket campaigns.

## 3. Governing files and classifications

Read `AGENTS.md`, the current and relevant historical `PLANS.md`, the three selected lifecycle owner docs, relevant system boundary/capability guidance, module pins, the complete touched source/tests, and relevant API/App/startup/config/script/example compatibility surfaces before changing behavior. No scripts or live stack need to run to inspect them.

Owner contract at the reviewed bytes:

- `PLANS.md:5–49`: single integrated source slice and phase order.
- `.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md` §15B (`:1279–1887` approximately): pooled reader, full row, operation/transition/reconciliation, K1 scope matrix, migration, allocator and acceptance rules.
- `.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md` §6B (`:780–952` approximately): strict format, finite interface, borrowed capability and invocation lifetime.
- `.docs/execution_lifecycle/es_execution_admission_model.md:603–635`: ownership and no-effect boundary.
- `docs_contract_test.go:12549–12760`: contract assertions including five K1 mutants.

Classify this as a Bounded slice rule extension on the reliable-submit Reopened redesign seam. Preserve current public structural reliable-request refusal, unkeyed Submit, authentication before existence disclosure, conflict privacy and bounded existing CP compatibility. ES admission/custody/durable service/SQLite keep their defined ownership; Coordinator programme progression and Nomad accepted-execution lifecycle remain separate. No helper repo, report, test, trace or model output gains runtime authority.

Before production edits, update the existing owner status/path map to record architectural selection and implementation in progress. Do not say schema 4 is implemented until it actually is. At closeout describe an uncommitted, validated source candidate awaiting independent acceptance, never publication/operational acceptance. Preserve historical sections and exact selected semantics. Update source-head assertions only with the corresponding implementation.

## 4. Frozen semantic decisions

### 4.1 One original, one attempt, one durable authority

Use the existing ES SQLite domain, globally occupied `(caller_ref,submit_key_ref)`, one immutable original and one attempt per row. Add schema migration 4 and claim codec 4 as independent version axes; scope 2 is `synthetic_progress_nonoperational_v1`. All phases, including accepted/receipt, remain fixture-only and effect-ineligible.

Keep caller/key identity, physical rowid, codec/scope, original PB1 binding/witness, creation identity and the complete 14-field replay descriptor fixed. Clone them into every successor. Progress never reseals or substitutes the original. RunRef is absent before assignment and immutable afterward; receipt is phase-6-only and then fixed. No new row, new run, reset, delete, TTL/GC, tombstone operation, object adoption or cross-scope key-reuse route.

Use the selected format tuple and exact `ESRSPAY2`, `ESRSENV2`, `ESRSAAD2`, `ESRSINT2`, `ESRSCTX2`, `ESRSFRZ2`, `ESRSEST2` encodings from the contract. Preserve intent/PB1 v1 and shared `ESRSKEY1` fingerprint semantics. Schema, row, scope, payload, wrapper and algorithm must agree; no fallback decoder/key search. Reject raw enum aliases before narrowing, NULL/empty confusion, arithmetic overflow, noncanonical fields and allocation-limit violations. Original AEAD is not authority for arbitrary mutable progress.

### 4.2 K1: separate invocation outcome from later current-state work

Within one write invocation: preserve known commit, evidenced not-applied/refused, or unknown. Recovery never performs a second semantic write, automatic replacement mutation, rebase or retry loop. Failed recovery withholds projection without inferring noncommit. Known commit survives failed post-authentication with projection withheld. Only authenticated exact full expected-record equality, including rowid and all progress fields, confirms that invocation's own uncertain COMMIT.

A later explicit fixture command/read requires fresh original authentication and its own live single-use borrow. It observes/acts on current state, not a retained history of all response outcomes. Identical retained histories A/B with identical later inputs have identical fixture eligibility. A stored marker blocks a new marker command; a true current absence plus the selected current-row predicate can admit the first synthetic marker. Count a later explicit command separately. Current replay/exact latest replay never rewrites a prior invocation's disposition.

Operational §8 Validated No-Dispatch Evidence stays unchanged. Do not implement or claim the cross-restart operational knowledge mechanism in this slice. No fixture result authorizes provider I/O, staging, production startup or public reliable Submit. Do not introduce a response ledger, caller-verified bit, poison registry, scheduler, queue, second attempt or second database to evade K1.

### 4.3 R1: historical reconciliation with current decisions

Scope the revised interpretation to codec 4. Preserve the first reconciliation tuple byte-for-byte as specified while current provider/marker/phase/receipt facts control later progress. Implement the exact when-recorded and later-row conditions, time relations, operation footprints and terminal locks. Keep first-marker-after-restart and stronger-terminal transitions possible; never silently relax legacy codec-1/2 checks or codec-3 immutability.

Latest-operation identity is compared before stale/transition classification after original authentication. The codec-4 marker digest binds both assigned run and marker. Full own-write proof is not replaced by equal intent or an advanced/equivalent winner.

### 4.4 Capability and authority boundary

Implement only the finite §6B facade. The private admission composer is the sole new non-test cross-package consumer. It interprets typed original semantics and recomputes PB1; custody verifies bytes, keys, commitments and issuer/row/original association; the existing durable service is the sole semantic progress writer. SQL enforces physical constraints and allowed storage deltas, not evidence authenticity or historical write knowledge.

Use opaque, redacted, nonserializable issuer-bound values and bounded typed views. No raw plaintext/full-record/store getter or arbitrary verified boolean. Verify the admission callback's returned match against authenticated values; no bypass via a supplied callback claiming success. No general runtime-capable handle.

Make lifetime ownership concrete: the encompassing private establishment invocation includes lower-level establish and bounded confirmation. A lower-level returned `ProgressAttempt` is usable only inside that owning invocation, invalidated before its outer return/cancellation; it supplies no restart input. Each `ProgressAccess` allows one read or mutation including bounded recovery and expires on return/cancellation/issuer close. An operation-scoped child context and defer within the existing private composition are acceptable lifetime mechanics, not a retained authority subsystem. Test escape, copy/foreign issuer, use after close/cancel/return and second-operation refusal. Do not accidentally expire the low-level returned attempt before its one permitted confirmation, or let it outlive the encompassing invocation.

### 4.5 Narrow cleanup and allocation lifecycles

Repair pooled `loadClaim` first. Install ownership before read BEGIN, retain caller-context semantic work, use a new request-independent five-second rollback context on known pre-COMMIT exits, sample its error immediately after rollback and BEFORE self-cancel, and always release cancel. Cleanup failure/observed expiry overrides success/not-found/corrupt with zero record and read unavailable. Uncertain BEGIN/read COMMIT requires exact quarantine and no semantic retry/post-COMMIT rollback. Use at most one direct synchronous rescue; if both disposal responses remain unconfirmed, suppress ordinary pool return and report the resource/capacity residual honestly. No new background disposer, pool-poison registry or whole-store reopen.

Preserve `loadClaimFresh` body/callers/function-owned lifetime, shared transaction/error helpers and A1/O2/C1/D1 behavior. Its generic current-shape verifier may naturally recognize the appended schema head; that is not a rewrite of its read lifecycle. Scope 2 uses the repaired pooled reader.

Implement the same allocator for both scope-1 and scope-2 publishers per §15B.5A. It owns one checked connection and every created/count FD, serializes at-most-33-name count and one exclusive create under `BEGIN IMMEDIATE`, performs ZERO DML/COMMIT, and confirms independent bounded rollback plus wrapper release before descriptor transfer. Keep key/grant checks, Seal, writes, fsync and callbacks outside that lock. A refusal after creation closes owned FDs once, keeps the inert name counted, burns the attempted permit under the publisher rule, and never refunds/adopts/deletes/reuses it. Confirmed discard does not rescue the failed allocation. No unmanaged-writer, mixed-old-binary, physical-close deadline or crash-persistent orphan guarantee.

### 4.6 Migration and compatibility

Append migration 4 in the new literal file. Preserve migration 1–3 literal bytes, ledger/source hashes and historical shape identities. Preserve global caller/key occupation, rowids, all columns, full key/counter/ledger rows and envelope files. Retired/revoked carried originals are migrated as state, not re-admitted as new ACTIVE claims. Use exact bidirectional copy witnesses and atomic old-or-new treatment from the contract; no backfill, reseal, disabled checks, writable_schema or downgrade.

Historical 1/2 load/permitted CAS remains compatible. Codec 3 stays initial-only, immutable, scoped and readable by its existing facade. Generic legacy entrypoints refuse codec 4; new facade refuses wrong-scope occupied rows without treating them as misses. Initial occupation classification precedes the shared four-claim capacity check. Keep the shared key/grant/object budgets and distinguish detection-only DB-size checks from hard bounds.

## 5. Exact writable scope

This is a ceiling, not a requirement to modify every listed file. All ordinary source files retain their existing modes; new Go source/test files are regular 0644. No additions/deletions/renames outside the enumerated list.

Owner docs and root assertions (5 existing):

    PLANS.md
    .docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md
    .docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md
    .docs/execution_lifecycle/es_execution_admission_model.md
    docs_contract_test.go

Production implementation (13 existing plus 1 new):

    es/admission/internal/reliablesubmit/sqlite_store.go
    es/admission/internal/reliablesubmit/sqlite_replay_claim.go
    es/admission/internal/reliablesubmit/sqlite_migrations.go
    es/admission/internal/reliablesubmit/sqlite_replay_progress_schema.go   [NEW]
    es/admission/internal/reliablesubmit/sqlite_replay_shape.go
    es/admission/internal/reliablesubmit/durable_record.go
    es/admission/internal/reliablesubmit/durable_operation.go
    es/admission/internal/reliablesubmit/durable_service.go
    es/admission/internal/reliablesubmit/replay_custody_format.go
    es/admission/internal/reliablesubmit/replay_custody_structure.go
    es/admission/internal/reliablesubmit/replay_custody_file.go
    es/admission/reliable_submit_replay_format.go
    es/admission/reliable_submit_replay_hydration.go
    es/admission/reliable_submit_replay_private.go

Tests/guards (8 existing plus 2 new):

    es/admission/internal/reliablesubmit/sqlite_pooled_claim_read_cleanup_test.go   [NEW]
    es/admission/internal/reliablesubmit/replay_progress_test.go                   [NEW]
    es/admission/internal/reliablesubmit/replay_custody_file_test.go
    es/admission/internal/reliablesubmit/sqlite_store_test.go
    es/admission/internal/reliablesubmit/sqlite_physical_test.go
    es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go
    es/admission/internal/reliablesubmit/sqlite_replay_shape_test.go
    es/admission/internal/reliablesubmit/guardrails_test.go
    es/admission/reliable_submit_guardrails_test.go
    es/admission/reliable_submit_replay_private_test.go

One CONDITIONAL test-only companion allowance:

    es/admission/workstream_c_guardrails_test.go

That file has exact resolver caller, original hydration, aggregate and synchronization inventories in the project snapshot (e.g. :359–365, 1726, 2286–2287, 2438–2442, 3707–3748 and 4900–4911). Confirm the pinned HEAD sites. The new finite private facade/composer may change those exact inventories. If necessary, first add this conditional companion to the existing owner path/acceptance map, then update only exact sites/counts tied to the selected private scope and matching synthetic checker fixtures/negative mutants. Report each old/new inventory item and reason. No permissive prefix matching, disabled runtime exclusion, removed negative, new global lock/registry authority or production source expansion. Leave the file untouched if no update is needed.

Maximum authorized scope: 30 paths, comprising 27 existing and 3 new. Changes outside it require an explicit rescope; do not silently widen it after a failure. Expected path counts derive from actual edits, not a guessed final count.

Explicit preservation: `sqlite_replay_schema.go` including migration 3, `replay_key_use_sqlite.go`, `model.go`, `store.go`, the intent parser and PB1 producer sources, current codec-3 vectors, go.mod/go.sum, public DTO/API/App/config/Submit/provider/staging/runtime code, scripts/examples, and unrelated tests/checkout state. Preserve historical source/probe artifacts. New vectors may live as literals in the selected new test file; no undeclared testdata paths are needed.

## 6. Execution order and evidence before results

### Phase 1 — pooled-reader prerequisite

Record a compact transaction/exit inventory from actual source, implement the local contract and write `TestSQLitePooledClaimReadCleanup`. Retain complete test and instrumentation bytes, commands, environment and expectations BEFORE a result is relied upon.

Supply a causal red/green comparison using the same complete assertions/fixtures. The negative keeps the pinned old pooled cleanup/order, with explicitly labeled seam-only instrumentation; it must not manufacture failure by disabling unrelated queries. Prefer keeping the same package/source context on both sides with only the old-versus-repaired reader differing. An integration-time negative formed by substituting the authenticated old reader into the new context is a labeled counterfactual, not unchanged baseline source or proof of test-first chronology. Retain source inventories and exact deltas. A compile/setup failure is not a red defect witness.

Prove real after-BEGIN/after-SELECT cancellation, ambiguous dispatched BEGIN/read COMMIT, failed rollback, actual five-second expiry followed by nil response, timely rollback, first-discard rescue and two-unconfirmed withholding, predispatch cancel, ordinary not-found/corrupt and same-store recovery before teardown. Clear all hooks before follow-up work. Use exact driver identity through supported interfaces and independent guarded durable witnesses, not global FD counts. Do not require a healthy subsequent operation when both disposals are explicitly unconfirmed.

Pass the targeted P test before introducing the new progress consumer. Retain intermediate source identity; if later integration changes its semantics or assertions, identify that delta and bind the final negative/positive evidence accordingly.

### Phase 2 — strict format, schema and allocator

Implement and independently vector-test the exact selected encodings. Do not use the producer under test as the sole vector oracle. Deterministic nonce/ciphertext is test evidence only; production remains random-nonce GCM. Preserve older vectors and cross-scope refusal.

Append schema 4, then derive and freeze the actual new SQL literal and shape hashes from reviewed bytes/pinned driver. Document them without altering old hashes. Implement full copy proof, rollback/uncertain-open classification, raw-type hydration and codec-specific physical guards. Fix only the enumerated stale unsupported-codec/trigger/head-shape test assumptions; codec2+1 that intentionally denotes malformed codec3 stays as such. Keep authentic historical seed projections.

Implement R2 once and route both publishers through it. Test interprocess and cross-selector contention for the final shared name; after-created failures must retain the orphan and burn the attempt without Seal or claim. Use real prior permits and independent child process; parent bounds/reaps it and records actual reached markers. No independent calibration programme or machine-wide descriptor inventory.

### Phase 3 — durable successors and private composition

Add the explicit codec-4 original-bound path to the existing durable service, retaining full original/rowid equality, dedicated mutable-only CAS, original key rechecks, exact operation digests, terminal invariants, R1 history and K1 result distinctions. Do not fall through the legacy codec2 constructor or permit legacy entrypoints to mutate scope2.

Implement the finite private custody/admission composition using actual parsed delivery, real resolver/PB1 on a genuine miss, original key catalog lookup and no current acquisitions on a hit. Fixture facts and projected references cannot become operational handles. Keep all production callers private and enumerated. Bind each stage to the accepted field/interface/transition tables.

### Phase 4 — integrated source acceptance evidence

Implement every P/F/R/T/U/L/M/N case in the owner acceptance matrix, including:

- Both initial phases, all allowed transitions, forbidden joint facts and unknown/narrowing-alias codecs.
- Original preservation and one run/receipt across ordinary progression and true close/reopen restart.
- Historical no-marker observation then a later explicit first marker; nonterminal reconciliation then stronger accepted/not-accepted evidence; current provider versus historical tuple semantics.
- Authentication-versus-CAS advancement, exact latest replay versus stale/changed input, no implicit rebase, wrong original/run/marker, terminal contradictions.
- Real COMMIT followed by injected lost response; exact expected-row own confirmation versus equivalent/advanced winner and failed recovery with no projection/second write.
- Identical persisted A/B histories and identical later explicit input produce identical fixture eligibility; earlier unknown result remains unknown. Count that explicit later command separately, with no caller memory used as authority.
- Current replay does not confirm a prior unknown. Stored marker admits exact replay only, not a new marker.
- Key retirement/revocation/missing/mismatch, reused/foreign/escaped/closed/canceled capabilities, burned permits, orphan/cap budgets and no new acquisition on an occupied hit.
- Static finite reachability plus fail-on-contact fixture counters: private paths never stage, submit to a provider, load live credentials, start services or return a public/operational receipt. Keep baseline unkeyed mocked-submit behavior separately tested.

Real SQLite statements, pooled handles, filesystem objects and cryptography are required where the contract calls for them. Label injected response faults; do not call them reproduced OS or storage failures. No new required bounded case may skip because its implementation fixture is unavailable.

## 7. Distinct old-binary evidence

Before final validation, authenticate and copy the retained PB1/schema-2 probe and its bound source/harness/build identity from material existing evidence. Do not rebuild or relabel it. Keep `TestSQLiteV3OldBinaryRefusesWithoutMutation` on an authentic schema-3 target constructed independently of the current schema-4 opener. If that material is unavailable, report the exact missing record; do not substitute a new binary while calling it historical.

Build the NEW schema-3 opener only from a complete external committed-blob export of HEAD f1aa8b934cc26c16a966a110c7b408abdaeadce7 / tree 8dd27f9acba98ed70d93736bdef8300ef1aba53f. The candidate's edited docs/source are not build inputs. Bind every exported leaf, the sole test-only overlay, actual compiled/embed/module inputs, toolchain, environment, argv and resulting binary. The sole overlay target adds `previous_schema3_probe_test.go` with `TestPreviousSchema3OpenerProbe`.

    (
      cd "$SCHEMA3_SOURCE" || exit
      "$GO" test -mod=readonly -overlay "$SCHEMA3_OVERLAY" -c -o "$SCHEMA3_PROBE" ./es/admission/internal/reliablesubmit
    )
    ES_REPLAY_SCHEMA3_TARGET="$SCHEMA4_TARGET" "$SCHEMA3_PROBE" '-test.run=^TestPreviousSchema3OpenerProbe$' -test.v

The populated authentic schema-4 target and full nonmigrating before witness must exist before the old opener runs. Assert actual unsupported refusal, the fixed `SCHEMA3_REFUSED_SCHEMA4` witness and complete after comparison; no current opener in the comparison. New test uses `ES_REPLAY_SCHEMA3_PROBE`. Bind `ES_REPLAY_PB1_PROBE` separately to the preserved historical copy. Logical state/object preservation does not imply byte-identical SQLite files or universal physical-close proof.

## 8. Environment, fixtures and iteration rules

Use the already pinned Go 1.26.5 binary:

    /Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go

Use its sibling `gofmt`. Preflight actual executable resolution and functional availability of the known-good Python 3.13/tomllib and OpenSSL 3 environment; do not repeat the Apple Python/LibreSSL PATH mistake or claim every previous failure's individual mechanism is known. No installations or dependency downloads.

    GOTOOLCHAIN=local
    GOPROXY=off
    GOSUMDB=off
    GOWORK=off
    GOFLAGS=-mod=readonly
    CGO_ENABLED=0
    GOTELEMETRY=off
    GOMODCACHE=/Users/ds/go/pkg/mod
    GIT_OPTIONAL_LOCKS=0
    GIT_NO_LAZY_FETCH=1
    GIT_TERMINAL_PROMPT=0
    PYTHONDONTWRITEBYTECODE=1

Create one absent private evidence root, e.g. an exclusive `ES-Private-Replay-Progress-Implementation-20261119-*` under `/Users/ds/Repositories`, with 0700 directories and 0600 retained reports/logs. Do not chmod the existing parent. Exact exported source retains Git modes under private parents. Keep task-managed GOCACHE/GOTMPDIR/TMPDIR there. Use outer umask 077 and test-child umask 027, with explicit modes on test-owned fixtures where required.

Existing tests' disposable `/tmp` or `/private/tmp` fixtures, helper children, loopback mocks and temporary Git repositories are allowed only as test-owned effects and cleaned by established test ownership. Do not claim a complete outside-temp sweep if not measured. Do not clean shared temp/cache roots. Read-only Docker/capability probes already in existing tests are permitted, not starting a real stack or using a live service; a change in capabilities that would cause unapproved host/runtime effects is a stop/qualification issue, not permission to spoof a skip.

Never execute/import verifier code directly from a prior evidence root. Authenticate and copy it into this root; use `python3 -B` and `sys.dont_write_bytecode=True`. Do not change old logs, archive entries, indexes or timestamps. No raw ambient-environment dump or unsafe keys/certificates/provider data in the inline report. Fixture keys/vectors must be classified as synthetic.

Normal engineering iterations are permitted within the exact scope and frozen semantics. Preserve failed attempts and their true causes. Correct a local fixture/runner issue without hiding its failure. Source fixes require a new frozen generation and fresh complete final validation. Never rerun unchanged flaky assertions until green or weaken timeout/capability/assertion conditions to conceal a substantive failure. A failing development test does not itself demand a new conversation or permission for already authorized repairs.

## 9. Final frozen validation

Freeze all candidate source/test/fixture inputs and exact environment before the final sequence. The formatting command names the complete finite Go source/test allowance (including the optional existing guard file); it changes no bytes. `GOFMT` below is read-only (`-d`), not `-w`. Bind both authenticated probe binaries and required target-selection variables for every command that needs them. Include the complete exact argv in the report, not unresolved shell placeholders.

Run these ten commands serially, once per final frozen generation:

    "$GO" version
    "$GOFMT" -d docs_contract_test.go es/admission/internal/reliablesubmit/sqlite_store.go es/admission/internal/reliablesubmit/sqlite_replay_claim.go es/admission/internal/reliablesubmit/sqlite_migrations.go es/admission/internal/reliablesubmit/sqlite_replay_progress_schema.go es/admission/internal/reliablesubmit/sqlite_replay_shape.go es/admission/internal/reliablesubmit/durable_record.go es/admission/internal/reliablesubmit/durable_operation.go es/admission/internal/reliablesubmit/durable_service.go es/admission/internal/reliablesubmit/replay_custody_format.go es/admission/internal/reliablesubmit/replay_custody_structure.go es/admission/internal/reliablesubmit/replay_custody_file.go es/admission/reliable_submit_replay_format.go es/admission/reliable_submit_replay_hydration.go es/admission/reliable_submit_replay_private.go es/admission/internal/reliablesubmit/sqlite_pooled_claim_read_cleanup_test.go es/admission/internal/reliablesubmit/replay_progress_test.go es/admission/internal/reliablesubmit/replay_custody_file_test.go es/admission/internal/reliablesubmit/sqlite_store_test.go es/admission/internal/reliablesubmit/sqlite_physical_test.go es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go es/admission/internal/reliablesubmit/sqlite_replay_shape_test.go es/admission/internal/reliablesubmit/guardrails_test.go es/admission/reliable_submit_guardrails_test.go es/admission/reliable_submit_replay_private_test.go es/admission/workstream_c_guardrails_test.go
    git --no-pager diff --check
    "$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateOriginalReplayProgressContractSelection|TestReliableSubmitPersistenceAndConcurrencyADRDocsContract|TestSubmitIdempotencyCorrelationAndRecoveryDocsContract|TestReliableSubmitPureModelDocsAndSourceContract|TestReliableSubmitPublicOptInAndVersioningDocsContract|TestReliableSubmitContractAdapterFoundationDocsAndSourceContract|TestReliableSubmitBindingProducerDocsContract|TestIntegratedAcceptanceGateDocumentationIsConsistent|TestIntegratedCandidateStatusSeparatesCAndT)$' .
    "$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestSQLitePooledClaimReadCleanup$' ./es/admission/internal/reliablesubmit
    "$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateReplaySharedObjectAllocation|TestReplayPublicationFaultAndIdentity|TestPrivateReplayProgressFormatVectors|TestPrivateReplayProgressTransitions|TestPrivateReplayProgressConcurrencyAndCommitOutcome|TestSQLiteV4MigrationPreservesFullState|TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation|TestSQLiteV3OldBinaryRefusesWithoutMutation|TestSQLiteLegacyCASConnectionCleanup|TestReplayOriginalKeyReadCleanup|TestReplayOriginalKeyReadCallerRefusal|TestReplayGrantC1PreCommitConnectionQuarantine|TestReplayGrantD1BeginResponseLossQuarantine|TestReplayKeyStateD1BeginResponseLossQuarantine|TestReliableSubmitPrivatePersistenceStaticGuardrails)$' ./es/admission/internal/reliablesubmit
    "$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateReplayProgressAdmissionReplay|TestPrivateReplayProgressHasNoEffectPaths|TestReliableSubmitFoundationHasNoRuntimeWiring|TestReliableSubmitBindingProducerHasNoProductionCaller|TestPrepareRequestShapeRemainsLegacyAndUnkeyed|TestResolvedSubmitLegacyEquivalenceOneNomadRegistrationAndAuthorityRecovery)$' ./es/admission
    "$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestWorkstreamCContractPrepareAndSubmitRemainSeparatedAtAPIBoundary|TestSubmitPublicRouteRejectsStructuralReliableBody)$' ./es/api ./es/app
    "$GO" test -mod=readonly -count=1 -p=1 -json -timeout=600s ./es/admission/internal/reliablesubmit ./es/admission ./es/api ./es/app
    "$GO" test -mod=readonly -count=1 -p=1 -json -timeout=600s ./...

Confirm each named new/existing parent and every required new subcase actually executes; zero-test selector success is not evidence. Keep K1 documentation mutants as selected. Full-package/full-tree tests exercise existing suites outside the focused selection, including the conditional Workstream C checker if touched.

After EACH command, execute and retain a separate integrity observation binding all candidate paths/complete bytes/modes, unchanged tracked paths, HEAD, branch, upstream and unchanged index. Independently record BOTH:

    git ls-files --others --exclude-standard -z
    git ls-files --others --ignored --exclude-standard -z

The three authorized new files are expected ordinary-untracked entries until a later commit gate. Compare them to the exact frozen allowlist; do not require empty ordinary-untracked output once they exist. No other untracked/ignored artifact is permitted. Require zero staged/unmerged entries and index == HEAD throughout this turn. Identical checkpoint bytes are allowed for identical observed state, but each must be tied to an actual post-command execution.

Keep counts by test/package identity and skip reason, not display order. The historical 4,970/0/38 source result is context, not a mandatory count after new tests. Explain added/changed identities and any capability skip. No required new behavior may skip; a direct helper-only sentinel may be separately accounted for only if the parent proved its actual helper execution. A capability skip never qualifies the native installed-source witness.

## 10. Final provenance, exact review delivery and report

After authorized task-owned cache/temp cleanup, freeze source and run the exact Appendix C v2 recipe twice to different absent outputs from the progress checkout. Require byte-identical canonical outputs. Do not edit the recipe, rebaseline silently or omit untracked content. Record full changed-path classification/mode/size/SHA-256 rows, HEAD/branch/upstream, tracked full-index diff digest and recipe source identity. The final manifest is a NEW implementation target, not the opening contract's hash.

Supply a safe review packet outside every checkout containing all complete changed/new source files, complete HEAD diff, contract-opening-to-implementation delta/source map, canonical manifest, README and self-excluding inventory. Untracked new files must be delivered in full and bound; a tracked diff alone does not carry their content. Bind archive byte count/hash and per-entry bytes/types/modes. Reject path traversal/links/special entries and unsafe material. Do not include .git, runtime databases, actual keys, caches, .pyc, unrelated archives or raw sensitive logs. Actual raw validation logs, source inventories, probe/source bindings and failed attempts remain in the private evidence root for independent audit.

Return the complete decision-relevant human-readable report INLINE; a local duplicate is supplementary. Include:

- initial conversation/root versus actual edit/test/provenance target and preserved A1 identity;
- exact baseline, new source map, migration 4 literal/shape identities and unchanged historical hashes;
- phase completion, touched paths and conditional guardrail disposition;
- concrete lifetime/result/transaction/FD/authority decisions mapped to owner path:line;
- source-bound red/green results, fault models versus real observations, full expected-row and K1/R1/R2/R3 evidence;
- exact commands, exit codes, selector coverage, package/test/skip counts/reasons, actual environment, immediate integrity records and any failed generations;
- old probes as two distinct identities/purposes;
- all limitations, untested cases, residual physical-close semantics, external test-owned temp qualification and any unresolved seam;
- canonical manifest in full, recipe/source/diff/archive hashes and artifact locations;
- explicit unchanged operational/public boundaries and no publication effects.

A local pathname is not a delivered attachment. Attach the review ZIP where supported; otherwise give its exact absolute path, size/hash and state that upload is required. Do not replace the inline report with a short verdict and link.

Use the success marker only after all required work/tests/provenance are complete. Otherwise use a precise blocked or incomplete checkpoint, disclose remaining work and preserve exact bytes; do not pretend readiness, promise background work, or ask for routine approval to complete already authorized work. A source/authority need outside the scope requires an explicit reported rescope, not automatic widening.

Successful closing nonclaims:

    ES_PRIVATE_REPLAY_PROGRESS_IMPLEMENTATION_READY_FOR_FRESH_INDEPENDENT_AUDIT
    INDEPENDENT_ACCEPTANCE_NOT_PERFORMED
    STAGING_NOT_PERFORMED
    COMMIT_NOT_PERFORMED
    PUSH_NOT_PERFORMED
    PRS_NOT_MODIFIED
    EXISTING_OTHER_SOURCE_CHECKOUTS_NOT_SYNCHRONIZED
    LOADCLAIMFRESH_LIFECYCLE_PRESERVED
    CROSS_RESTART_OPERATIONAL_WRITE_UNCERTAINTY_GATE_NOT_IMPLEMENTED
    RUNTIME_WIRING_NOT_PERFORMED
    PUBLIC_RELIABLE_SUBMIT_NOT_ENABLED
    NATIVE_INSTALLED_SOURCE_WITNESS_NOT_QUALIFIED_BY_THIS_SLICE

## 11. Stop boundaries

Stop before source changes on opening source/recipe/archive/provenance mismatch, wrong/inaccessible target, missing essential build/probe material or permissions. Stop widening if the frozen architecture cannot be realized without another state authority, format/migration decision, public/runtime change, dependency or path outside the list. Preserve findings and exact source state.

Do not stop solely because the conversation is attached to A1, a helper-only metadata ref changed before this turn, a diagnostic initially fails for the intended negative, an authorized in-scope engineering repair is needed, or the current candidate is uncommitted. Do not restart completed historical campaigns to solve unrelated setup issues.

The acceptance basis is the exact owner contract plus the explicit implementation instructions here. Any substantive deviation must be surfaced; passing tests cannot silently ratify it.

---

## Appendix A — complete supplied K1 closeout

This is source/evidence input, not independent implementation acceptance.

Exact UTF-8 payload: 16061 bytes; SHA-256 `430a7ece909275203d8bcfb31f0acff16612269085fa719f05b9dd0a7b7616ed`.

<BEGIN_K1_CLOSEOUT>
The K1 contract correction is ready for architectural review. Recovery now applies to one write invocation and its own evidence. A later, explicitly supplied fixture command can act on the authenticated current row without resolving an earlier unknown response. The operational no-dispatch requirement is unchanged.

**Exact review packet** · [ES-Private-Replay-Progress-K1-Contract.zip](/Users/ds/Repositories/ES-Private-Replay-Progress-K1-Contract-20261119-fzxf8tt8/ES-Private-Replay-Progress-K1-Contract.zip)

The ZIP is **420,293 bytes**, mode `0600`, SHA-256 `03dddf54b405e27fcdeafec2bc40165a2948d15be83a94ef5129c4d26b3c12d7`. Its ten verified entries contain the five complete source files, both patches, the canonical manifest, a README and a self-excluding inventory. Both patches independently reconstructed the exact five delivered files and their `0644` modes in private disposable copies. This is the local ZIP for upload. [Delivery receipt](/Users/ds/Repositories/ES-Private-Replay-Progress-K1-Contract-20261119-fzxf8tt8/delivery-receipt.json) · [Per-entry inventory](/Users/ds/Repositories/ES-Private-Replay-Progress-K1-Contract-20261119-fzxf8tt8/review-packet/delivery-inventory.json)

## Routing and baseline

The user-reported chat attachment and observed initial physical shell directory were both `/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1`. All edits, tests and manifest executions targeted `/Users/ds/Repositories/ES-Private-Replay-Progress-v1`. That directory is its own physical and Git top-level root, with Git and common directory both `/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.git`. A1’s HEAD, tree, status, refs, index and config fingerprints matched at opening and closeout. No remote observation was made. [Opening routing record](/Users/ds/Repositories/ES-Private-Replay-Progress-K1-Contract-20261119-fzxf8tt8/routing-opening.json) · [Closeout routing record](/Users/ds/Repositories/ES-Private-Replay-Progress-K1-Contract-20261119-fzxf8tt8/routing-closeout.json)

| Item | Verified identity |
| --- | --- |
| Branch and upstream | `codex/private-replay-progress-v1` → `origin/trunk_dev` |
| Origin | `git@github.com:evo-agi/Execution-Substrate.git` |
| Pinned PR #10 HEAD | `f1aa8b934cc26c16a966a110c7b408abdaeadce7` |
| Sole parent | `fb9ae55797d9fcc02863c23fe8d3e43d16eac542` |
| Complete tree | `8dd27f9acba98ed70d93736bdef8300ef1aba53f`, 427 leaves |
| Opening canonical manifest | `ad2e60dfb5f4377cbd4531ab9555c90ec0391b76b7c879764b18ddf5693f0491` |
| Opening full-index binary diff | `3497dab92bda92ad7b56a6eac76fa8995859106a7c1c4a67ad739bf2f80f7665` |
| Opening-to-corrected patch | `67c2cc0aad9e4accd912a3a23e765df97f90879c2149839a05bc682ecc0c0700` |
| Final `HEAD`-to-candidate full-index binary patch | `75582f2e9b91fdc0ef879c802b4e9af9b04784db48e385e024996c716f480821` |

Both opening recipe runs reproduced the supplied 1,331 canonical bytes. The five live opening files matched both Appendix B and the authenticated 419,360-byte review ZIP, SHA-256 `8d0734b788cb04e23624ee2282bba9e08153caafacfe447d2f33639601f01af9`. I checked that archive’s inventory, README, manifest, diffs and source members. Appendix A matched its 28,423-byte transport hash, `bf7adf63e242081186b22e80a9a93ac1d9602d738bf8929c44b52b9c3d7f56af`. The prior evidence used beyond the archive was the authenticated inventory and the two verifier scripts, copied into the new evidence root before execution. [Material authentication record](/Users/ds/Repositories/ES-Private-Replay-Progress-K1-Contract-20261119-fzxf8tt8/opening-material-authentication.json)

Exactly five paths changed. Each remains an unstaged regular file, disk mode `0644` and Git mode `100644`. All 422 other tracked files match the pinned bytes and modes. The index equals `HEAD`, with zero staged, unmerged, ordinary-untracked or ignored paths. [Opening checkpoint](/Users/ds/Repositories/ES-Private-Replay-Progress-K1-Contract-20261119-fzxf8tt8/k1-opening-checkpoint.json) · [Closeout checkpoint](/Users/ds/Repositories/ES-Private-Replay-Progress-K1-Contract-20261119-fzxf8tt8/k1-closeout-checkpoint.json)

## K1 decision

The reconciled draft required the first fixture marker to know the dispositions of earlier relevant writes after restart. The 47-field row retains no such response history, and the one-use borrow expires. The corrected contract limits fixture eligibility to the current row and the explicit command. It adds no ledger, caller-verified flag, registry, database or attempt. [Plan selection](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/PLANS.md:27) · [ADR scope matrix](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1616)

| Scope | Corrected guarantee |
| --- | --- |
| **One write invocation and its recovery** | Preserve known commit, evidenced not-applied/refused, or unknown. After safe connection disposition and authentication, only full expected-record equality can confirm that invocation’s own COMMIT. An advanced or different winner, missing state, or failed, canceled or corrupt recovery leaves the write unknown and withholds projection. Recovery issues no second write, replacement mutation, rebase or retry loop. Failed post-commit authentication withholds projection while preserving known commit. |
| **Later explicit fixture command** | Require fresh original authentication, a new live one-use borrow, and the caller’s exact current expected revision and mutation input. The service checks the supported codec/schema, active row, matching original and run, committed intent, absent marker/provider and exact predecessor, then rechecks the row in CAS. An existing marker is immutable and refuses a new marker command. No automatic transition from unknown to a new invocation is selected. |
| **Later authenticated fixture read** | May project current authenticated fixture state. Exact latest-operation replay describes the current descriptor. Neither changes the earlier disposition or establishes ownership of an earlier uncertain write. |
| **Operational dispatch and restart recovery** | The full operational §8 Validated No-Dispatch Evidence requirement remains in force. Before provider wiring, a separately reviewed model must identify durable ES-owned evidence or other governed authoritative input for the relevant write dispositions, or explicitly re-derive the requirement with adequate safety proof. Fixture results grant zero provider-I/O permission. |

The two restart histories make the input gap concrete. Both retain the same authenticated phase-3 row at revision 4, with the same original, run, committed intent, kind-1 observation and absent marker/provider. [Restart examples](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1528)

| History | Before restart | Eligibility after restart |
| --- | --- | --- |
| **A** | Intent and reconciliation are known committed. No marker invocation occurred. | The explicit, freshly authenticated fixture command at revision 4 may create the first stored synthetic marker. |
| **B** | On the same predecessor, the earlier marker transaction did not commit. Its response was unknown, recovery was unavailable, and cleanup was confirmed. | The same explicit command has the same eligibility and may create the first stored synthetic marker. The earlier invocation remains unknown. |

A diagnostic driver can distinguish A and B for a test, but its memory supplies no authority to the facade. The later command is counted separately. If an earlier marker actually committed, the stored marker blocks a new command. Codec-4 kind-1 `NoDispatch` records only a bounded fixture no-marker observation. [First-marker rules](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1498) · [Borrow and attempt lifetime](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md:908)

## Preserved directions and exact edit scope

| Changed file | K1 correction |
| --- | --- |
| [PLANS.md](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/PLANS.md:27) | Selects current-row fixture eligibility and the per-invocation recovery boundary. Keeps the pre-provider operational decision separate. |
| [Persistence ADR](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1498) | Aligns ops 5/7, restart histories, result and authority tables, implementation map and prospective test identities. Go owns transition semantics and per-invocation proof. SQL owns row shape, immutable fields, CAS and storage deltas. |
| [Submit contract](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md:908) | Gives a later read or command its own live borrow. Keeps the opaque establishment attempt inside its owning invocation and makes clear that it supplies no restart input. |
| [Admission classification](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/es_execution_admission_model.md:603) | Aligns fixture marker and terminal authority with the same current-row and operational boundaries. |
| [Documentation assertions](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/docs_contract_test.go:12549) | Checks the corrected scope table and five targeted mutants. Preserves current/target, legacy, authority and R1/R2/R3 assertions. |

R1 retains the immutable reconciliation tuple through later marker, provider and terminal transitions. Positive terminal evidence still binds the same original, run and marker. R2’s shared scope-1/scope-2 count/create lifecycle and budget section, R3’s exact schema-3 probe build section, the pooled-reader prerequisite, and the operational §8 predicate were verified byte-identical to the opening candidate. Section §8 also matched the pinned `HEAD` bytes. [R1 reconciliation](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1447) · [R2 allocator](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1724) · [R3 probe](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1852) · [Retained-section proof](/Users/ds/Repositories/ES-Private-Replay-Progress-K1-Contract-20261119-fzxf8tt8/retained-contract-sections.json)

Prospective tests now use `FixtureNoMarkerThenFirstMarkerAfterRestart` and `UnknownMarkerCommitDoesNotRetryWithinInvocation`. The matrix includes `IndistinguishableRestartHistoriesHaveSameFixtureEligibility`, `ExplicitLaterFixtureCommandDoesNotConfirmPriorUnknown`, `CurrentReplayDoesNotConfirmPriorUnknown` and `ExistingMarkerExactReplayOnly`. It retains stale predecessor, wrong original/run, contradictory terminal evidence, full expected-row own-COMMIT confirmation and zero-effect cases. [Prospective acceptance matrix](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1819)

Current source remains schema 3 with historical codecs 1/2 and immutable codec 3. Schema 4, codec 4 and scope 2 remain proposals. The pooled `loadClaim` repair is still the first implementation prerequisite. Public structural refusal and current unkeyed Submit remain in force.

## Documentation validation

Generation `k1-v1` passed on its first frozen run. Go reported `go1.26.5 darwin/arm64`. `gofmt -d` and `diff --check` produced no output. The Go run passed **nine parents and 13 subtests**, with zero failures or skips. Actual executable resolutions and hashes were recorded, with offline cached modules, fresh private cache/temp directories, outer umask `077` and Go test umask `027`. Each command had its own executed integrity observation. [Frozen argv and environment](/Users/ds/Repositories/ES-Private-Replay-Progress-K1-Contract-20261119-fzxf8tt8/k1-v1-validation-freeze.json) · [Go outcomes by identity](/Users/ds/Repositories/ES-Private-Replay-Progress-K1-Contract-20261119-fzxf8tt8/k1-v1-go-test-run.json)

```sh
"$GO" version
"$GOFMT" -d docs_contract_test.go
git --no-pager diff --check
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateOriginalReplayProgressContractSelection|TestReliableSubmitPersistenceAndConcurrencyADRDocsContract|TestSubmitIdempotencyCorrelationAndRecoveryDocsContract|TestReliableSubmitPureModelDocsAndSourceContract|TestReliableSubmitPublicOptInAndVersioningDocsContract|TestReliableSubmitContractAdapterFoundationDocsAndSourceContract|TestReliableSubmitBindingProducerDocsContract|TestIntegratedAcceptanceGateDocumentationIsConsistent|TestIntegratedCandidateStatusSeparatesCAndT)$' .
```

The five K1 subtests each changed one normative table statement and verified rejection at the expected row. They cover claiming the full operational predicate, resolving an earlier unknown from current replay, resolving it from marker absence, permitting automatic fresh mutation/rebase, and omitting the fixture-versus-operational permission boundary. These are bounded documentation checks. Product diagnostics, behavioral tests, migrations, old-opener builds, the full suite, native installed-source qualification, module downloads and live services were unperformed. [Mutation checks](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/docs_contract_test.go:12606)

## Canonical manifest

The exact 7,275-byte recipe `governed-execution.audit-patch-manifest.v2` matched SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`. The two final external manifests were byte-identical. Their SHA-256 is `79c3554da0dbbb5c45677092aee07093ee3b5f10d306ed656a7e9922c6c7733b`. [Manifest A](/Users/ds/Repositories/ES-Private-Replay-Progress-K1-Contract-20261119-fzxf8tt8/final-a.json) · [Manifest B](/Users/ds/Repositories/ES-Private-Replay-Progress-K1-Contract-20261119-fzxf8tt8/final-b.json)

```json
{"branch":"codex/private-replay-progress-v1","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/es_execution_admission_model.md","sha256":"323af61fa84bbbec3a699654758989918e9d1ef74d9f18d01eb4f1efbeeddcb8","size":80367},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md","sha256":"29e203e6b6dd37a2ca8f331ee9da9de45b1f7b04090d7da73008705efeb06fbc","size":155140},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md","sha256":"932ad4bbf1db53ae3f04d5e713648a6d395fcbb676097ec48f5af75aff3bd802","size":102189},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"49a1a04ca31a852a34b6899e98adb889b791aab34555545df649e11f6be22792","size":300847},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"0dea4847b311e5f0135072a7539f11c0b5e40e103923b81b4e570feb134837d8","size":791661}],"head":"f1aa8b934cc26c16a966a110c7b408abdaeadce7","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"75582f2e9b91fdc0ef879c802b4e9af9b04784db48e385e024996c716f480821","upstream":"origin/trunk_dev"}
```

```text
ES_PRIVATE_REPLAY_PROGRESS_K1_CONTRACT_CORRECTED_READY_FOR_REVIEW
PRODUCT_SOURCE_BYTES_UNCHANGED
POOLED_LOADCLAIM_DEFECT_NOT_REPAIRED_IN_THIS_TURN
LOADCLAIMFRESH_BEHAVIOR_PRESERVED
SCHEMA4_AND_CODEC4_NOT_IMPLEMENTED
CROSS_RESTART_OPERATIONAL_WRITE_UNCERTAINTY_GATE_NOT_IMPLEMENTED
INDEPENDENT_ACCEPTANCE_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PRS_NOT_MODIFIED
EXISTING_SOURCE_CHECKOUTS_NOT_SYNCHRONIZED
RUNTIME_WIRING_NOT_PERFORMED
PUBLIC_RELIABLE_SUBMIT_NOT_ENABLED
```<END_K1_CLOSEOUT>

## Appendix B — exact opening canonical manifest

Exact UTF-8 payload: 1331 bytes; SHA-256 `79c3554da0dbbb5c45677092aee07093ee3b5f10d306ed656a7e9922c6c7733b`.

<BEGIN_OPENING_MANIFEST>
{"branch":"codex/private-replay-progress-v1","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/es_execution_admission_model.md","sha256":"323af61fa84bbbec3a699654758989918e9d1ef74d9f18d01eb4f1efbeeddcb8","size":80367},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md","sha256":"29e203e6b6dd37a2ca8f331ee9da9de45b1f7b04090d7da73008705efeb06fbc","size":155140},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md","sha256":"932ad4bbf1db53ae3f04d5e713648a6d395fcbb676097ec48f5af75aff3bd802","size":102189},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"49a1a04ca31a852a34b6899e98adb889b791aab34555545df649e11f6be22792","size":300847},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"0dea4847b311e5f0135072a7539f11c0b5e40e103923b81b4e570feb134837d8","size":791661}],"head":"f1aa8b934cc26c16a966a110c7b408abdaeadce7","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"75582f2e9b91fdc0ef879c802b4e9af9b04784db48e385e024996c716f480821","upstream":"origin/trunk_dev"}
<END_OPENING_MANIFEST>

## Appendix C — exact v2 provenance recipe source
Copy only the payload bytes to an audit-owned file; never execute from this prompt or a historical evidence root.

Exact UTF-8 payload: 7275 bytes; SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`.

<BEGIN_V2_RECIPE_SOURCE>
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
import sys
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v2"


def fail(message: str) -> "NoReturn":
    raise SystemExit(message)


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env.update(
        {
            "LC_ALL": "C",
            "LANG": "C",
            "GIT_OPTIONAL_LOCKS": "0",
            "GIT_NO_LAZY_FETCH": "1",
            "GIT_TERMINAL_PROMPT": "0",
            "GIT_PAGER": "cat",
        }
    )
    result = subprocess.run(
        [
            "git",
            "--no-pager",
            "-c",
            "core.fsmonitor=false",
            "-c",
            "core.untrackedCache=false",
            *args,
        ],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


def validate_output_path(output_path: Path, repository_root: Path) -> None:
    if not output_path.is_absolute():
        fail("output path must be absolute")

    parent = output_path.parent
    parent_metadata = parent.lstat()
    if not stat.S_ISDIR(parent_metadata.st_mode) or stat.S_ISLNK(parent_metadata.st_mode):
        fail("output parent must be a nonsymlink directory")
    if parent_metadata.st_uid != os.getuid():
        fail("output parent must be owned by the current user")
    if stat.S_IMODE(parent_metadata.st_mode) & 0o022:
        fail("output parent must not be group- or world-writable")

    try:
        output_path.lstat()
    except FileNotFoundError:
        pass
    else:
        fail("output path already exists")

    repository_text = os.path.realpath(os.fspath(repository_root))
    output_text = os.path.realpath(os.fspath(output_path))
    try:
        common = os.path.commonpath([repository_text, output_text])
    except ValueError:
        common = ""
    if common == repository_text:
        fail("output path must be outside the repository")


def write_exclusive(output_path: Path, payload: bytes) -> None:
    flags = (
        os.O_WRONLY
        | os.O_CREAT
        | os.O_EXCL
        | getattr(os, "O_NOFOLLOW", 0)
        | getattr(os, "O_CLOEXEC", 0)
    )
    fd = os.open(os.fspath(output_path), flags, 0o600)
    try:
        view = memoryview(payload)
        while view:
            written = os.write(fd, view)
            if written <= 0:
                fail("short provenance-output write")
            view = view[written:]
        os.fsync(fd)
    finally:
        os.close(fd)

    metadata = output_path.lstat()
    if not stat.S_ISREG(metadata.st_mode) or stat.S_ISLNK(metadata.st_mode):
        fail("provenance output is not a regular nonsymlink file")
    if metadata.st_uid != os.getuid():
        fail("provenance output owner mismatch")
    if stat.S_IMODE(metadata.st_mode) != 0o600:
        fail("provenance output mode mismatch")
    if metadata.st_nlink != 1:
        fail("provenance output link-count mismatch")
    if metadata.st_size != len(payload):
        fail("provenance output size mismatch")

    read_flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_CLOEXEC", 0)
    read_fd = os.open(os.fspath(output_path), read_flags)
    try:
        observed = bytearray()
        while len(observed) <= len(payload):
            chunk = os.read(read_fd, min(1 << 20, len(payload) + 1 - len(observed)))
            if not chunk:
                break
            observed.extend(chunk)
    finally:
        os.close(read_fd)
    if bytes(observed) != payload:
        fail("provenance output byte mismatch")


if len(sys.argv) != 2:
    fail("usage: governed_execution_audit_patch_manifest_v2.py ABSOLUTE_OUTPUT_PATH")

repository_root = Path(git_text("rev-parse", "--show-toplevel"))
output_path = Path(sys.argv[1])
validate_output_path(output_path, repository_root)

head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    fail("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            fail(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()

write_exclusive(output_path, canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")
<END_V2_RECIPE_SOURCE>
