# Execution Substrate — Post-PR #10 Reliable-Submit Integration Selection

## Objective and decision boundary

Close the completed A1 source-publication tranche as a fact, then produce a
finite, source-grounded recommendation for the next reliable-submit integration
slice. Do not automatically turn every inherited audit observation into a new
implementation tranche, and do not treat the synthetic foundation as an
operational reliable-submit implementation.

This turn is repository-read-only reconnaissance plus narrowly authorized,
offline diagnostics in new external source copies. It is not implementation,
independent product acceptance, or runtime qualification.

Required output:

1. a pinned post-PR #10 baseline and a bounded capability/dependency map;
2. a disposition for the two remaining claim-read cleanup paths, distinguishing
   their actual connection/pool lifetimes and actual callers;
3. one recommended next slice, with its owner decisions, dependency order,
   prospective path scope, compatibility treatment, and acceptance evidence;
4. a short critical path from today's private foundation to a first explicitly
   bounded reliable execution, separating source work from later runtime proof.

Do not change governing documents or code in this turn. Propose precise owner
contract and test changes; ChatGPT will review the operating-model selection
before issuing implementation authority. Do not stop to ask routine questions
when the authorized inspection can resolve them. Preserve any genuinely
unresolved authority choice explicitly instead of coding around it.

Successful endpoint:

```text
ES_POST_PR10_RELIABLE_SUBMIT_NEXT_SLICE_RECON_READY
```

That endpoint means the reconnaissance produced a decision-ready recommendation,
not that reliable Submit is available or any proposed design is implemented.

## Conversation, topology, and effects

Continue in the same foreground conversation that completed PR #10's merge,
rooted at:

```text
/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1
```

All existing repositories, worktrees, Git administration, branches, PRs,
configuration, and prior evidence roots are read-only. The foreground parent
alone may create new external evidence/source copies and run the authorized
synthetic diagnostics. No repository mutation is permitted.

Governed Execution has two core components: ES and Coordinator. This task is
ES-local. ES owns execution admission, submission/runtime handoff and its
execution facts. Coordinator's durable programme progression is a separate
core concern, not implemented here. CP is historical/demo compatibility, not a
new orchestration dependency. IM/MA are supplementary; Bridge is not run truth.
Do not inspect or mutate other repositories merely to reconfirm that topology.

Not authorized:

- edits, formatting writes, chmod, cleanup, or generated artifacts in an
  existing source checkout;
- staging, commits, branch creation, fetch into existing repositories, pull,
  reset, restore, stash, merge, rebase, cherry-pick, push, or ref updates;
- any PR/comment/review/check/ruleset/integration write;
- changes to the queued Claude suites or an organization-integration audit;
- dependency installation/download, new infrastructure, live credentials,
  deployment, live hosts, real Nomad/Docker jobs, or public Submit calls;
- a full-suite replay, historical PB1 rebuild, socket-calibration campaign,
  physical-close fault platform, or whole-history evidence inventory;
- runtime wiring, a public reliable-submit switch, or new execution authority.

Read-only official GitHub/API and `git ls-remote` observations are allowed.
No background monitoring or asynchronous follow-up is part of this task.

## Pinned baseline

```text
Official repository:
evo-agi/Execution-Substrate

official origin:
git@github.com:evo-agi/Execution-Substrate.git

Merged PR:
#10 — Harden original-key read transaction cleanup (A1)

Squash / selected post-PR #10 baseline:
f1aa8b934cc26c16a966a110c7b408abdaeadce7

Squash sole parent:
fb9ae55797d9fcc02863c23fe8d3e43d16eac542

Accepted complete tree:
8dd27f9acba98ed70d93736bdef8300ef1aba53f

Preserved local topic and source commit:
fd2115ca8f44a615627adb08926896a1e052dc30

Local branch:
codex/reliable-submit-original-key-read-cleanup-v1

Local upstream:
origin/codex/reliable-submit-original-key-read-cleanup-v1

Local origin/trunk_dev, intentionally not synchronized:
fb9ae55797d9fcc02863c23fe8d3e43d16eac542

Tree size:
427 tracked leaf blobs

A1 source delta from parent:
7 modifications; 420 unchanged entries; no additions/deletions/type changes
```

First read Appendix A completely. Authenticate its private duplicate:

```text
Root:
/Users/ds/Repositories/ES-A1-PR10-Squash-Merge-Gate-20261118-do68yxjg

Report:
merge-closeout.txt
SHA-256:
005982497903cbd72bcc59c035ab8e31cd26998585883f67d378674857864b67

Self-excluding artifact index:
artifact-index.json
SHA-256:
f543b8e36cd538863e7f8223f6dbaed9ef0c4b9a71a385ede92eba773a8603a5
```

Authenticate the report/index and only the indexed records actually relied
upon for source/merge identity and retained validation. Do not make every prior
audit root, directory timestamp, internal Codex ref, or artifact count a new
product progression gate. The report is evidence, not authority.

Confirm PR #10 is merged and read the squash, source commit, and official base
identities. Verify clean local index/worktree, both ordinary-untracked and
ignored inventories, and complete tree equality of the preserved source commit
and squash. A squash commit need not already be in the local object database:
verified remote commit/tree metadata plus identical local source tree permits
committed-blob inspection/export from the topic. Do not fetch simply to make a
squash SHA locally resolvable.

If official trunk has advanced, retain the pinned baseline and record the new
tip separately. Classify any material overlap before choosing a future write
base; do not rewrite history, silently substitute HEAD, or mislabel unrelated
remote progress as a candidate provenance mismatch. If local source differs
from the expected clean tree, stop diagnostics and report the exact discrepancy.

## New private external evidence

Use one unique task-owned root, for example a safely created `mkdtemp` child
with prefix:

```text
/Users/ds/Repositories/ES-Post-PR10-Integration-Recon-20261118-
```

The root/subdirectories must be current-user-owned nonsymlink `0700` and
retained reports/logs regular `0600`. Committed source copies may preserve Git
`0644`/`0755` modes inside the private root. Executable diagnostic/probe copies
may be executable only when needed and returned to private retained modes.
Do not chmod the existing `/Users/ds/Repositories` parent.

Copy exact committed blob bytes, not checkout overlays or `git archive` output
with unexamined export transforms. Record the 427-path inventory with origin
commit/tree, Git mode, blob ID, size and SHA-256. All instrumentation and test
bytes must be retained and bound before their results are relied upon.

Never execute/import a historical verifier in its old evidence root. Read and
authenticate source, copy it into this task's root, inspect it, then run only
that copy when needed. Use `PYTHONDONTWRITEBYTECODE=1`, `python3 -B`, and
`sys.dont_write_bytecode = True` for Python helpers. Binding continuity is
content/identity-based, not timestamps or inode allocation. No secret material,
ambient environment dumps, real database rows, or tokens in reports.

## Governing inspection — required before selecting the next slice

Read the pinned `AGENTS.md` and the latest `PLANS.md` in full as relevant to
current status, active reliable-submit selection, reopened seams, and priority.
Preserve the distinction between current status and historical selections.

Inspect together:

- `.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md`;
- `.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md`;
- `.docs/execution_lifecycle/es_execution_admission_model.md`;
- relevant lifecycle contracts/design/implementation and system boundary,
  configuration, key/isolation, and capability-probing contracts;
- `es/admission/reliable_submit_replay_private.go`, private binding/original
  replay representations and resolver, and their tests;
- `es/admission/submit.go`, actual reliable-request refusal entry points and
  tests, request authentication and caller namespace derivation;
- `es/admission/internal/reliablesubmit/` claim store, durable service/record/
  operations, codec/schema/migration, custody and key-use source and tests;
- the actual `es/api`, `es/app`, and `es/config` call/configuration boundaries
  implicated by a proposed first integration slice;
- relevant script/runbook/example fixtures and validation paths. Enumerate what
  is relevant and what was deliberately not inspected; do not execute scripts.

Read controlling tests and SQL constraints as contracts to evaluate, not as
obstacles to bypass. Current synthetic limits are real until revised explicitly.

### Observed starting points — verify rather than assume

The following were inspected in the pinned merged tree by ChatGPT. Recheck the
full surrounding context and callers, and provide your own path/line citations.

- `PLANS.md:5–32` records PR #8/#9 source publication and A1 selection, but not
  a post-PR #10 closure/next-slice entry. Do not interpret the timeless statement
  that source work alone grants no qualification as itself a defect. Propose
  the minimal current-status update alongside the next selected owner slice.
- `reliable_submit_persistence_and_concurrency.md:1011–1075` and
  `sqlite_replay_schema.go:209–240` restrict new claims to codec 3's synthetic
  initial shape and refuse codec-3 UPDATE. Migrated codec-1/2 historical
  transitions are not a ready-made execution path for a new codec-3 claim.
- `reliable_submit_replay_private.go:140–258` composes private replay lookup,
  original reconstruction and PB1 verification, without a runtime caller or
  effect-eligible result. `submit.go:34–110` retains the existing separate
  unkeyed submit/stage/Nomad path.
- `sqlite_store.go:260–324` contains two different read lifetimes:
  `loadClaim` borrows from the store pool; `loadClaimFresh` opens an independent
  pool, sets max-idle to zero, verifies current schema without migration, and
  defers both connection and DB closure. They share old read cleanup but must
  not be declared equivalent solely from that syntax.
- `replay_custody_file.go:644` calls `loadClaimFresh` before original-key
  verification. A1 acceptance did not repair this earlier read.
- Owner ADR section 16 leaves state-path configuration, authenticated caller
  source wiring, operational envelope/key custody, retention/restore policy,
  provider reconciliation, public result/error vocabulary and runtime submit
  integration as separately governed decisions.

Do not infer that the existing codec-3 update prohibition is a bug. It is an
intentional synthetic-only boundary. Do not propose removing a trigger or
flipping an effect-ready flag as sufficient integration.

## Two bounded read-only perspectives

Use at most two read-only explorer subagents, with no nested delegation or
command/test execution. Supply each the exact pinned source identity and task
boundaries; do not assume inherited context.

1. Admission-to-runtime integration and owner contracts: map the actual
   request/replay/state/staging/provider/recovery chain; identify missing
   decisions and the smallest useful next slice.
2. Persistence/read lifetimes and residual-risk relevance: trace loadClaim,
   loadClaimFresh, their callers and tests, and classify cleanup exposure by
   actual lifetime and proposed integration reachability.

The parent reviews the load-bearing conclusions and owns the disposition. Close
both explorers before parent-run diagnostics. A subagent recommendation is
neither independent acceptance nor permission to widen the task.

## Critical deliverable A — integration dependency map

Produce a compact source-grounded table for these stages:

```text
trusted caller + submit key
→ original-claim lookup / changed-intent decision
→ first-request resolution and complete bound plan
→ original-input/key custody
→ durable claim and exact attempt identity
→ RunRef / effect-intent ownership and legal state transitions
→ staging / runtime handoff
→ ambiguous provider outcome reconciliation
→ retained receipt / replay / recovery presentation
```

For each stage state:

- actual owner and implemented entry points;
- supported current behavior versus selected synthetic proof;
- current invariants, Bounded slice rules, compatibility edges and reopened
  decisions (using repository terminology);
- missing contract/source/test/qualification necessary for the first bounded
  runtime path;
- whether it is a prerequisite for the *next source slice*, only before first
  runtime wiring, only before an operational claim, or outside the chosen path.

Do not call the table a new authority. Do not promote CP, reports, fixture keys,
model output, app summaries, or diagnostics into execution truth.

Recommend one native state/custody composition. Explain how immutable original
replay material relates to mutable execution-attempt progress, who writes each
fact, and how accepted historical codec-1/2 and synthetic codec-3 data remain
readable or intentionally refused. Any schema/codec extension requires an
explicit append-only migration/version treatment, not editing accepted migration
literals or silently adopting synthetic rows as effect-ready work.

Map this to the existing durable operation model before proposing a second
state algebra, database, registry, queue, scheduler, or generic orchestration
framework. Record and justify any genuine redesign need. No implementation is
authorized on an unresolved operating-model/authority choice.

## Critical deliverable B — bounded claim-read characterization

The question is not whether cancellation returns an error. It is whether the
actual remaining read path leaves an unusable pooled transaction, stale snapshot,
misclassified success, unintended durable mutation, or unintended callback, and
whether that consequence blocks the recommended integration path.

First inspect the complete source, lifetime and caller graph. If those reads
remain a material unresolved dependency, the parent is authorized to perform
one narrow diagnostic programme on external source copies only:

- at most two diagnostic parents, one for pooled `loadClaim` and one for
  independent-pool `loadClaimFresh`;
- at most five declared cases per parent: ordinary control, pre-canceled
  control, cancellation after real successful BEGIN, cancellation after a real
  successful claim SELECT, and execute-BEGIN-then-error response model if
  relevant to the uncertainty boundary;
- actual pinned SQLite, on-disk disposable databases and correct current
  schema/codec fixtures; use authentic migrated rows when the test targets
  historical claims, and valid synthetic codec-3 rows when it targets their
  current caller;
- use the existing test seam when adequate; otherwise add narrowly recorded
  external-only instrumentation preserving the original cleanup ordering and
  behavior. No candidate repair or shared-helper replacement in these views.

Give the diagnostic parents these names if creating new external tests:

```text
TestPostPR10PooledClaimReadDiagnostic
TestPostPR10FreshClaimReadDiagnostic
```

Run only that assigned selector, once per frozen diagnostic version:

```sh
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s \
  -run '^(TestPostPR10PooledClaimReadDiagnostic|TestPostPR10FreshClaimReadDiagnostic)$' \
  ./es/admission/internal/reliablesubmit
```

Require every declared parent/subtest to be observed. A missing selector is not
a pass. If source inspection makes a parent unnecessary, document why and freeze
an exact reduced selector before execution; do not silently skip its question.

Bind the pristine export, instrumentation diff, complete test bytes, complete
source inventory, safe environment and expected observations before each run.
Setup/fixture iterations are allowed within this turn and must retain their
versions and failed results. Correct fixture defects before making behavioral
claims. Do not rerun away a substantive source failure or repair it here.

Clear injected hooks immediately after the targeted call and unconditionally
at cleanup. Measure subsequent legitimate calls with fresh contexts before
tearing down the long-lived store. For the fresh-pool reader, distinguish its
normal function-owned closure from an artificial end-of-test close/reopen.
An independent writer alone does not prove absence of a stale WAL read snapshot.
Verify relevant durable rows, returned records, and callback/no-effect facts.
Observe driver identity only through supported Raw callbacks; never operate a
driver escaped from them. Avoid process-wide FD-count equality and a new socket
or global descriptor harness. Physical OS-close fault injection is not in scope.

Use the pinned local toolchain and existing module cache:

```text
GO=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go
GOTOOLCHAIN=local
GOPROXY=off
GOSUMDB=off
GOWORK=off
GOFLAGS=-mod=readonly
CGO_ENABLED=0
GOTELEMETRY=off
GOMODCACHE=/Users/ds/go/pkg/mod
GIT_OPTIONAL_LOCKS=0
GIT_NO_LAZY_FETCH=1
GIT_TERMINAL_PROMPT=0
PYTHONDONTWRITEBYTECODE=1
```

Use task-owned GOCACHE/GOTMPDIR/TMPDIR, evidence umask 077, test umask 027, serial
execution, and a bounded parent timeout sufficient for the declared SQLite
busy/cleanup limits. No dependency download or OS-label fallback. If scripts are
needed by a relevant fixture, preflight actual Python/tomllib and OpenSSL
capabilities using the known-good recorded executable paths; do not run the
full-suite environment campaign for this narrow diagnostic unnecessarily.

No historical PB1 binary is needed unless a selected diagnostic actually invokes
its test. Do not rebuild it or run the old-binary suite by habit. No Docker/Nomad
capability checks, network listeners or live stack are needed for these reads.

After every diagnostic command verify the existing checkout's clean index,
working files/modes, source branch/upstream and both untracked inventories, plus
the external frozen source view. Remove only task-owned diagnostic DB/cache/temp
resources after recording results. Preserve exact diagnostic source and logs.

For each reader return one of:

```text
CONFIRMED_REACHABLE_CLEANUP_OR_AVAILABILITY_DEFECT
NO_DEFECT_DEMONSTRATED_IN_TESTED_LIFETIME
SOURCE_SUPPORTED_RISK_NOT_DYNAMICALLY_REPRODUCED
OUTSIDE_RECOMMENDED_NEXT_PATH_WITH_EXPLICIT_REENTRY_GATE
```

A benign independent-pool result does not qualify every physical-close outcome.
A problem found in a historical pooled reader is not automatically a blocker for
an insert-only synthetic path; connect the finding to real consumers. Conversely,
do not waive a reachable source defect solely because current public reliable
Submit is still disabled. Explain the exact dependency and bounded correction.

## Critical deliverable C — one next slice and finite sequence

Reconcile the mapping and read diagnostics. Recommend exactly one primary next
slice, with a short dependency order of no more than four named gates to the
first bounded reliable execution. Group necessary related work; do not invent
one micro-tranche per helper or historical observation.

Your recommendation must specify:

- outcome observable to a real caller or the concrete prerequisite it unlocks;
- current owning contract and classification;
- decisions that must be frozen in PLANS/owner docs before implementation;
- exact prospective files and permitted production behavior;
- preservation/migration/refusal treatment for existing data and consumers;
- affected test, schema, API, configuration, script and example surfaces;
- authoritative fact writers and source/evidence/runtime separation;
- exact prospective validation commands or clearly identified new test names;
- accepted nonclaims and any stop condition before runtime/host effects.

The first runtime target, if recommended, must have a bounded single-host,
local-first operating envelope consistent with ES contracts. Explicitly decide
trusted caller namespace, key source/lifetime, state path, stable RunRef/attempt,
first-effect boundary, duplicate/race behavior, ambiguous provider response,
process-restart recovery, and receipt/error semantics. Refuse unsupported
restore/rollback/topology conditions rather than implying they are solved.
No HA, multi-tenant, general key-management platform or broad deployment track.

Acceptance criteria should include the applicable same-key/same-intent replay,
changed-intent conflict, concurrent winner, changed defaults/original inputs,
key retirement/revocation, process restart and unknown-outcome cases. Define
what remains unknown and what prevents repeating an effect; never equate a
synthetic claim, retained log, status projection, or HTTP success with proof of
one authorized runtime effect. Preserve scheduler/runtime lifecycle authority.

Classify residuals rather than treating them uniformly:

- inherited read cleanup: by actual lifetime/reachability and characterization;
- physical teardown / two-unconfirmed-disposal resource retention: accepted
  source limits requiring operational treatment, not newly closed by A1;
- older physical-close wording: clarify when its owning section is touched;
- native installed-source/Linux proof: later explicit qualification gate, not a
  requirement to start source-only selection;
- stale/current publication-status entries: minimal proposed correction with
  the next selected owner slice, not a standalone cosmetic PR by default;
- queued empty Claude suites: preserved no-result observation, unrelated to
  the reliable-submit data-plane design; do not repair integrations here.

Do not create a new snapshot solely because this bounded slice merged. Use the
pinned commit/tree and closeout overlay. Recommend a snapshot at the next
architecture-defining checkpoint if the selected model warrants it.

## Closeout and report

Recheck the selected local identities, all 427 source bytes/modes, index, clean
ordinary/ignored inventories, and official baseline/topic observations. Remote
trunk drift is a labeled publication overlay, not permission to change the
pinned reconnaissance base. Recheck only material prior evidence used.

Deliver the complete decision-ready human-readable report inline. A private
report is supplementary; no finding, qualification, failed attempt, proposed
scope, authority change or next-step prerequisite may exist only in a file.
Raw logs and large machine inventories may remain private, referenced by exact
path and digest. Include:

1. baseline, source/merge authentication, effects, and inspection limits;
2. completed PR #8/#9/#10 source facts and remaining capability boundaries;
3. integration dependency table and shortest justified path;
4. separate reader-lifetime findings and every diagnostic command/result;
5. one selected next-slice recommendation, alternatives rejected with reason,
   exact prospective scope, validation and unresolved owner decisions;
6. retained historical/operational qualifications;
7. exact artifact/report/index identities and all skipped validation.

If the evidence is insufficient, report exactly what was inspected and the
smallest missing input or check. Do not label lack of a new snapshot, unfetched
squash object with proved tree equality, or volatile directory timestamps as
product defects. Do not claim an acceptance verdict in this reconnaissance.

End with the truthful disposition and effect statements, including:

```text
ES_POST_PR10_RELIABLE_SUBMIT_NEXT_SLICE_RECON_READY
SOURCE_REPOSITORIES_NOT_MUTATED
SOURCE_REFS_NOT_UPDATED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PRS_NOT_MODIFIED
EXISTING_SOURCE_CHECKOUTS_NOT_SYNCHRONIZED
PRODUCT_REPAIR_NOT_PERFORMED
INDEPENDENT_ACCEPTANCE_NOT_PERFORMED
RUNTIME_WIRING_NOT_PERFORMED
PUBLIC_RELIABLE_SUBMIT_NOT_ENABLED
NATIVE_INSTALLED_SOURCE_WITNESS_NOT_QUALIFIED_BY_THIS_TURN
```

Use the success marker only when the recommendation is actually decision-ready.
If safe inline transport cannot be completed, use REPORT_INLINE_BLOCKED instead
of a readiness marker. The source-effect statements remain accurate in all cases.

---

## Appendix A — Complete supplied PR #10 squash-merge closeout

The following bytes are the exact uploaded transport rendition, not the private
report's different rendering. Authenticate each by its own digest; compare
human-readable renditions on decision facts without normalizing their hashes.

Transport bytes: 14690

Transport SHA-256: `9b3cc894ec73b1a7163efb14bcc1fd9df0210dff995ee844db38812ef2e2a8fd`

<BEGIN_EXACT_PR10_MERGE_CLOSEOUT>
# A1 PR #10 exact-tree squash merge

[PR #10](https://github.com/evo-agi/Execution-Substrate/pull/10) was squash-merged into `trunk_dev` as [`f1aa8b934cc26c16a966a110c7b408abdaeadce7`](https://github.com/evo-agi/Execution-Substrate/commit/f1aa8b934cc26c16a966a110c7b408abdaeadce7). GitHub accepted one synchronous merge request. The squash has the exact accepted tree and the pinned sole parent. The remote topic was preserved, and the local checkout remains clean at the original source commit.

## Exact source and retained evidence

The standalone checkout was `/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1` on `codex/reliable-submit-original-key-read-cleanup-v1`, tracking `origin/codex/reliable-submit-original-key-read-cleanup-v1`. Both origin URLs were `git@github.com:evo-agi/Execution-Substrate.git`.

The local HEAD, remote topic, and PR head were `fd2115ca8f44a615627adb08926896a1e052dc30`. The unsigned source commit was `fix: harden original-key read transaction cleanup`, with `AlacerMortis <david.shaw.dev@gmail.com>` as author and committer at `2026-11-18T21:24:27-05:00`. Its sole parent and the opening official `trunk_dev` tip were `fb9ae55797d9fcc02863c23fe8d3e43d16eac542`. The parent tree was `be8437c8ce48cbcbed53f60a03810283abbd9235`, and the accepted tree was `8dd27f9acba98ed70d93736bdef8300ef1aba53f`. [Opening local proof](/Users/ds/Repositories/ES-A1-PR10-Squash-Merge-Gate-20261118-do68yxjg/opening-local/source-proof.json) · [Opening remote source proof](/Users/ds/Repositories/ES-A1-PR10-Squash-Merge-Gate-20261118-do68yxjg/opening-source/source-summary.json)

I authenticated all four appendices by byte count and SHA-256. The 13,551-byte transport report, SHA-256 `bb01fe37760e8a9c8678667cdf648f4d48bff65e6608cabc61d45f9563b3f3bc`, agreed with the private publication report on decision facts. The historical 1,787-byte manifest retained its original parent and upstream and matched SHA-256 `11d7ef82fddd181fab5d8883765095b35f9b599cff5b8a7892c8fcb889e2367f`. The committed comparison below reproduced `b6c030a16eb1b427d6d22572d76bd418c9b5c7acfeb82d1dd86f6202905d4a5c`.

```sh
git --no-pager -c core.fsmonitor=false -c core.untrackedCache=false diff --full-index --binary --no-ext-diff --no-textconv --no-renames fb9ae55797d9fcc02863c23fe8d3e43d16eac542 fd2115ca8f44a615627adb08926896a1e052dc30 --
```

| Private evidence | Report SHA-256 | Index SHA-256 |
| --- | --- | --- |
| Publication gate | `07da4afec582a9685061fe7f87b79b27f77631df08a48f6f3df0e5f8dbcd0a8f` | `82c76aa13ddac5c8851d24101d497a7fe497817c9fd81a5143dc42913d8280e3` |
| Local commit gate | `945ad513d63e6daebccac60cd2d82ca3be0997f87b9b29bc12f068755b0bd291` | `17f32834762fb45f2a134bc184acc3e7f15c983a645f0659125f22bd62b6abb8` |
| Independent acceptance | `25b53c636e5353cae220bb53b254cff4a098cce3aad5634b4fc42bb3034228e8` | `b7f4d2837f9254e0085410c26e7210f506eb71602cf4985231db70d7cb4a1a56` |

The authenticated subset covered 17 publication records, 96 commit-gate records, and seven acceptance records. It included the source proofs, validation freeze, all nine staged runs and their fresh guards, raw logs, and parsed identity reconciliation. I authenticated and copied the prior verifier into the new evidence root and used only its read-only functions. Material records matched again at closeout. [Exact authenticated subset](/Users/ds/Repositories/ES-A1-PR10-Squash-Merge-Gate-20261118-do68yxjg/authenticated-evidence.json)

The retained validation was focused A1 **31/0/0**, protections and PB1 **16/0/0**, documentation **12/0/0**, reliable-submit package **383/0/1**, and full repository **4,970/0/38**. The full run had 21 passing tested packages, 20 packages without tests, and zero malformed events. Its stdout SHA-256 was `a1a6c28c4863c365571f6c9a3eb0c7ea6fbff1d21e5f96588d24f0fee561265d`. The 38 skips remain one helper-only case and 37 Docker or capability-dependent cases. This gate ran no product tests, builds, diagnostics, or acceptance replays. Historical failures, verifier corrections, temporary-fixture limits, and the pre-stage file-mode incident retain their recorded dispositions.

## Fresh merge decision

Immediately before the request, Git and GitHub agreed on the exact base and topic. PR #10 was open, non-draft, unmerged, and `MERGEABLE` / `CLEAN`, with auto-merge unset. It contained one source commit and seven modified existing files. Its title and 4,644-byte body, including the final newline, matched the authorized publication at SHA-256 `035cde04d090c3b522cd979ceec4a3c622ce0406be970b6516a045516cc93256`.

The complete effective branch rules showed only active ruleset **17579282** for `trunk_dev`, with no bypass actors. It requires the PR path, squash merge, and resolved review threads, and restricts creation, deletion, and non-fast-forward updates. No required checks, approvals, named reviewers, code-owner approval, last-push approval, signature rule, merge queue, deployment requirement, or branch-update check applied. The extra approval option for unattributed Copilot changes has no effect with zero required approvals. Classic protection returned the explicit `Branch not protected` response, and the complete GraphQL classic inventory was empty. Repository settings enabled squash and disabled auto-merge and automatic head deletion. [Effective policy proof](/Users/ds/Repositories/ES-A1-PR10-Squash-Merge-Gate-20261118-do68yxjg/prewrite-policy/summary.json) · [GitHub ruleset semantics](https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/available-rules-for-rulesets)

The paginated reads showed zero formal reviews, inline review comments, or review threads. The one general comment was the Codex bot summary, which reported completed code review with no findings on exact head `fd2115ca…` and recorded no security review. There was no active changes request or new substantive finding. The summary carries no formal approval. [Codex review summary](https://github.com/evo-agi/Execution-Substrate/pull/10#issuecomment-6998150008)

Claude app **1236702** suite **120315156237** was queued with a null conclusion. Both the suite and exact-head inventories contained zero check runs. There was no associated visible workflow, job, or active review, and effective policy required no such check. The merge proceeded under the explicit empty-suite allowance **without a Claude result**. The aggregate legacy status was `pending` with zero contexts. The merge preview `1d2a387aefb9dbc49e6852c4eedd18d3bf7c2df4` had the expected tree and base/head parents, with zero suites, check runs, or workflows. [Prewrite activity](/Users/ds/Repositories/ES-A1-PR10-Squash-Merge-Gate-20261118-do68yxjg/prewrite-activity/summary.json) · [Decision record](/Users/ds/Repositories/ES-A1-PR10-Squash-Merge-Gate-20261118-do68yxjg/prewrite-decision.json) · [GitHub check-suite semantics](https://docs.github.com/en/rest/checks/suites?apiVersion=2026-03-10)

The accepted tree had no workflow definitions. Actions were enabled, with zero visible workflows, environments, or repository hooks. The organization listed selected Codex and Claude installations. Organization hook and ruleset inventory reads lacked scope, while the effective branch policy read succeeded. The visible configuration showed no prohibited merge-triggered action. Other external integration behavior remains partly unobservable. [Automation and policy observations](/Users/ds/Repositories/ES-A1-PR10-Squash-Merge-Gate-20261118-do68yxjg/prewrite-policy/summary.json)

## One request and verified squash

```sh
gh api --hostname github.com --method PUT \
  -H 'Accept: application/vnd.github+json' \
  -H 'X-GitHub-Api-Version: 2026-03-10' \
  repos/evo-agi/Execution-Substrate/pulls/10/merge \
  --input /Users/ds/Repositories/ES-A1-PR10-Squash-Merge-Gate-20261118-do68yxjg/merge-request.json
```

The exact 1,169-byte request had SHA-256 `9d390769572f4f77665979cbf25e347ef12a977e0fa7f0cd775d206ecb5e1ac5`. The command exited `0`, recorded one PUT and HTTP `200`, and returned `merged: true` with SHA `f1aa8b934cc26c16a966a110c7b408abdaeadce7`. The retained response SHA-256 is `8b19bfa173b02ad79ea02f0568b999d4dea762c54af66d6b9d14b0c4e9988b45`. The request’s SHA guarded the PR head. The immediately preceding base read and the verified squash parent establish the observed base result. [Request and HTTP record](/Users/ds/Repositories/ES-A1-PR10-Squash-Merge-Gate-20261118-do68yxjg/merge-response.run.json) · [GitHub synchronous merge API](https://docs.github.com/en/rest/pulls/pulls?apiVersion=2026-03-10#merge-a-pull-request)

GitHub recorded `SeritArbores` as the merger at **10:12:31 p.m. EST on November 18, 2026**. The squash author was `David Shaw <david.shaw.dev@gmail.com>` and the committer was `GitHub <noreply@github.com>`, both at `2026-11-18T22:12:31-05:00`. GitHub reported signature verification `true`, reason `valid`. The subject `Harden original-key read transaction cleanup (A1) (#10)` and the full message matched Appendix D.

The base-to-squash comparison showed exactly one new commit, with sole parent `fb9ae55797d9fcc02863c23fe8d3e43d16eac542` and tree `8dd27f9acba98ed70d93736bdef8300ef1aba53f`. Complete nontruncated remote trees confirmed 427 leaves and 420 parent-identical entries. Every remote blob below was decoded and compared in full to the local accepted payload and manifest, with Git mode `100644`.

| Modified path | Bytes | Verified blob ID | SHA-256 |
| --- | ---: | --- | --- |
| `.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md` | 87,948 | `5e3b51ff22d05ffc58985553e39ea982321446a7` | `0ab5160a49461b93cb70c55606cb7a4b876b1061da272d83501f50cd5e0c2fca` |
| `PLANS.md` | 297,778 | `6644fab61084be2b269f5bf3aa1a53c7c681ecc8` | `46a8797432c4993563a2bae64c74fbf03d489cc7701f93e5359a9ed3f8bdfdf6` |
| `docs_contract_test.go` | 778,818 | `7d00df75b7ba78f862e6208b8fe242fc8d9c8e34` | `c386e73e6af36c1957e375ec41bd506df94a04213d305f9f4a6a15fea070233e` |
| `es/admission/internal/reliablesubmit/replay_custody_file_test.go` | 55,545 | `9030dbceb1fdf43194b67e1bda5c8430cdf4d846` | `300ac3628a4f7e97b2769368bab170e162a2bac32ad050fa3671a1d7acb44e31` |
| `es/admission/internal/reliablesubmit/replay_key_use_sqlite.go` | 12,380 | `aa63a0d010e359901dcb3688d7db32155892ce18` | `1010d65f608a329f0c423d2fab8d3034f7facfacea20fcb2c32b7393fab7cdb2` |
| `es/admission/internal/reliablesubmit/replay_key_use_sqlite_test.go` | 38,744 | `440f027bbe5cd92af07305257804e881971a3eea` | `34808437df35da8559d20af02bdb2c3a6c879b89ff5df6d853ed7be5d6e2a89e` |
| `es/admission/internal/reliablesubmit/sqlite_store.go` | 50,759 | `0b013925af418c76946d23772a499f632920ecb5` | `15bb182b48dc45ea748fe1aedd31d60bccd73b24f39711af04ff27f36e02a812` |

Two postwrite Git and GitHub ref reads put official `trunk_dev` at the verified squash and the topic at `fd2115ca8f44a615627adb08926896a1e052dc30`. PR #10 was closed and merged with that actual `merge_commit_sha`, its original head, title, and exact body preserved, and auto-merge unset. [Squash object and blob proof](/Users/ds/Repositories/ES-A1-PR10-Squash-Merge-Gate-20261118-do68yxjg/closing-squash/source-summary.json) · [Closing disposition](/Users/ds/Repositories/ES-A1-PR10-Squash-Merge-Gate-20261118-do68yxjg/disposition.json)

Post-merge activity showed no new review or substantive finding. The PR head still had the queued empty Claude suite **120315156237**. The squash acquired Claude suite **120322828008**, also queued with a null conclusion and zero runs. Both exact commits had zero check runs, zero legacy contexts, aggregate `pending` status, and zero visible workflow runs at readback. Neither suite established a check result. [Head activity](/Users/ds/Repositories/ES-A1-PR10-Squash-Merge-Gate-20261118-do68yxjg/closing-head-activity/summary.json) · [Squash activity](/Users/ds/Repositories/ES-A1-PR10-Squash-Merge-Gate-20261118-do68yxjg/closing-squash-activity/summary.json)

## Local preservation and limits

The local HEAD, branch, upstream, index, all 427 working file bytes and modes, configured identity, and scoped Git configuration were unchanged. The local topic tracking ref stayed at `fd2115ca8f44a615627adb08926896a1e052dc30`. Local `origin/trunk_dev` intentionally remains at `fb9ae55797d9fcc02863c23fe8d3e43d16eac542`; no fetch occurred. Staged, unstaged, unmerged, ordinary-untracked, and ignored-untracked inventories were empty. [Closing local proof](/Users/ds/Repositories/ES-A1-PR10-Squash-Merge-Gate-20261118-do68yxjg/closing-local/source-proof.json)

This closes source publication for A1, a **Bounded slice rule refinement** on the reliable-submit **Reopened redesign seam**. F1 observes cleanup-context expiry after rollback responds and before self-cancel. The five seconds bound the context. Exact pool eviction and driver Close invocation leave physical teardown and close duration unqualified, and two unconfirmed disposals can retain resources or reduce pool capacity. Direct SELECT transport faults, immediate cross-process revocation, inherited `loadClaim`/`loadClaimFresh` cleanup, and older physical-close wording remain separately scoped. No-Seal evidence remains source order plus dynamic refusal and file observations. The prior rejection and failed runs retain their original bindings. Private `synthetic_nonoperational_v1` remains runtime-unwired and effect-ineligible, and local validation supplies no CI, native installed-source, or live-host qualification.

The evidence root is `/Users/ds/Repositories/ES-A1-PR10-Squash-Merge-Gate-20261118-do68yxjg`. The private report SHA-256 is `005982497903cbd72bcc59c035ab8e31cd26998585883f67d378674857864b67`. The self-excluding index binds **318 files and 20 directories** and has SHA-256 `f543b8e36cd538863e7f8223f6dbaed9ef0c4b9a71a385ede92eba773a8603a5`. The retained files and directories were verified as regular `0600` and nonsymlink `0700`, respectively. [Private report](/Users/ds/Repositories/ES-A1-PR10-Squash-Merge-Gate-20261118-do68yxjg/merge-closeout.txt) · [Artifact index](/Users/ds/Repositories/ES-A1-PR10-Squash-Merge-Gate-20261118-do68yxjg/artifact-index.json)

```text
ES_A1_ORIGINAL_KEY_READ_CLEANUP_SQUASH_MERGED
SOURCE_BYTES_NOT_CHANGED_BY_MERGE_GATE
LOCAL_HEAD_AND_INDEX_NOT_MOVED
TOPIC_BRANCH_PRESERVED
PRODUCT_TESTS_NOT_RERUN_IN_MERGE_GATE
PR8_AND_PR9_NOT_MODIFIED
PRIOR_REJECT_PRESERVED_FOR_ITS_EXACT_BYTES
AUTO_MERGE_NOT_ENABLED
TAG_NOT_CREATED_BY_THIS_GATE
RELEASE_NOT_CREATED_BY_THIS_GATE
DEPLOYMENT_NOT_PERFORMED_BY_THIS_GATE
EXISTING_SOURCE_CHECKOUTS_NOT_SYNCHRONIZED
RUNTIME_WIRING_NOT_PERFORMED
PUBLIC_RELIABLE_SUBMIT_NOT_ENABLED
NATIVE_INSTALLED_SOURCE_WITNESS_NOT_QUALIFIED_BY_THIS_SLICE
```
<END_EXACT_PR10_MERGE_CLOSEOUT>
