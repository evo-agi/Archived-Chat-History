## Select the permanent-marker / single-live-sender model — formalize the contract before implementation

**I agree with the proposed operating model and select it for the next contract candidate.** It addresses the operational uncertainty problem without inventing a response-history ledger or promoting fixture state into execution authority.

There is **one concrete inconsistency in the proposed acceptance matrix**, and several bindings need exact definitions before production code changes. Those belong in the contract-authoring turn—not another broad reconnaissance or an implementation-and-repair cycle. The report correctly labels the model proposed and unimplemented. Pasted text

I read the complete report and preceding brief, reopened the pinned governing rules and relevant ES source, and checked the cited Nomad creation boundary. I did not inspect the new snapshot ZIP or sidecar, access the local checkout, or run repository code.

## Why this is the right direction

The proposal separates two questions that the older operational predicate conflated:

**What did an earlier invocation learn about its write?** Its unknown response stays unknown.

**Can a new invocation safely act on the current authoritative state?** That can be decided independently, provided the new operation obtains the checked writer turn and satisfies the remaining original, revision, key, staging, and marker conditions. This is the report’s explicit codec-5 re-derivation of ADR §8, not an assertion that the existing predicate already permits it. Pasted text

The intended safety argument is:

```text
Qualified current state, held stage, and absent marker
→ one applied first-marker CAS
→ directly observed successful COMMIT
→ one nonrecoverable, one-use send continuation
```

Under that model, writer serialization and the permanent marker prevent another invocation from obtaining a second first-marker transition. A committed marker does not itself grant a sender to its readers. **Readback can establish stored facts without recreating the right to send.**

That is a coherent conditional argument to specify and test. SQLite documents the immediate writer-transaction behavior on which the serialization premise relies; the rest—including complete path coverage and continuation lifetime—must be established by the ES implementation and its evidence. [SQLite](https://sqlite.org/lang_transaction.html)

The availability cost is deliberate: a marker may commit and then lose its sender before any POST occurs. A later process cannot distinguish that history from some possible-send histories merely by observing the marker, so it may remain ambiguous indefinitely. The proposal states that limitation rather than promising exactly-once execution. Pasted text

## Correct the rolled-back-marker acceptance case

The report’s staging rule says a later invocation cannot adopt an existing stage or recover the original holder’s dispatch authority. Its crash table explicitly says a stranded stage still refuses after a marker rollback. But the prospective test row says:

> “A rolled-back marker plus settled writer and untouched stage allows a distinct qualifying invocation to win.” Pasted text Pasted text

**That positive case conflicts with the selected staging rule.** A valid marker attempt already requires completed staging and its stamp. Rolling back the marker does not remove that stage or give a different invocation its descriptors.

Preserve the no-reattachment rule and correct the tests:

| History | Required result |
|---|---|
| Settled **pre-stage** uncertainty; no stage stamp and no physical stage | A distinct qualified invocation may create the first stage and proceed toward the first marker. |
| Marker rollback or uncertainty **after valid staging**; original invocation has failed | No send by that invocation, and no send by a distinct invocation that cannot acquire the existing stage. Preserve residue. |
| Marker COMMIT succeeds but its response is lost | No sender, including after exact readback confirms the marker. |
| First marker is directly acknowledged and its live continuation remains eligible | One permitted transport entry; no additional POST from replay or restart. |

This is a **specification inconsistency**, not a demonstrated source defect. It can be corrected while drafting the owner contract; no diagnostic run is needed now.

## Freeze the bindings that make the argument enforceable

### Sender issuance must distinguish “applied” from merely “successful”

The report already requires direct success of the first `NULL → marker` COMMIT. The contract must carry that distinction through the exact result interface.

A generic successful return is insufficient: it could represent a replay, no-op, losing CAS, or recovered write. The current durable service has replay/no-op paths alongside mutations, so the new sender cannot be minted simply because an existing mutation method returned no error. See `durable_service.go:247–351`. 

The draft must specify the applied-transition witness, direct COMMIT outcome, issuer and invocation ownership, held-stage/request binding, one-use consumption, and cancellation/closure boundaries. It must also distinguish the encompassing handoff invocation from its individual durable commands.

For this first operational slice, I select the conservative rule: **an uncertain durable command stops that invocation’s effect-producing sequence.** Safe readback may classify the command; it does not implicitly resume staging or recreate a sender. A later explicit invocation can reconsider only work whose durable **and physical** prerequisites still permit it.

### Stage and provider proofs need exact representations

The report names the right ingredients, but “complete stage proof” and “versioned effect-bearing projection” still need finite encodings and comparison rules. The next document must define the fields, ordering, limits, normalization, association with the original/run/marker, and treatment of changed or extra content. It must also avoid a digest that indirectly includes itself. Pasted text

These are not cosmetic serialization decisions: they determine whether a verified stage, prepared request, and observed provider job refer to the **same admitted effect**.

I independently confirmed that Nomad tag `v2.0.3` resolves to the cited commit and that its state-store path performs the existing-job lookup and `EnforceIndex` check within the write transaction. Official API documentation describes `EnforceIndex=true` with index zero as new-job-only registration. That supports the proposed reference contract.   [HashiCorp Developer](https://developer.hashicorp.com/nomad/api-docs/jobs)

**It does not qualify the installed provider.** The current ES installer uses an unversioned `apt-get install -y nomad vault`; no host inspection occurred. The exact installed build, namespace control, transport, normalization, and observation provenance remain native prerequisites.  Pasted text

### Receipt recovery and first-effect admission should remain separate

I also select the proposed receipt policy: a currently authorized equivalent caller may recover an authenticated committed receipt without rerunning mutable execution admission, resolution, staging, or provider calls. First effects still require current admission and eligible active keys.

The report correctly identifies **claim-scoped lifecycle authorization** as a separate requirement before exposing reliable runs through public lifecycle routes. Neither a valid receipt nor the existing route-level ACL should silently substitute for that ownership check. Pasted text

## The missing remote topic is now reconciled at the event level

The report’s “unexplained disappearance” is no longer the complete observation.

My live reads confirm that the old topic is absent and `trunk_dev` remains at `ae326b0d…`. GitHub records a **`head_ref_deleted` event at November 19, 2026, 6:50:02 p.m. EST**, attributed to account `SeritArbores`, after the merge at 6:47:16 p.m.   

That establishes the recorded deletion event—not its motive or UI route. **It does not invalidate the merged checkpoint or require restoring the branch.** The next candidate should derive from the immutable squash, leaving the preserved checkout and its tracking configuration untouched.

## Next Codex turn: one contract candidate, not production implementation

Continue in the **same Codex conversation that produced this decision report**.

:chatgpt-content-reference{index="20"}[Download the operational-submit handoff owner-contract prompt](sandbox:/mnt/data/ES_Operational_Submit_Handoff_Owner_Contract_20261119.md)

SHA-256:

```text
ccece9b4aa7b26b39a06cdd03e5339fc12a23be72c54e311132bb6ca5ebe33f8
```

The prompt embeds the **complete supplied report unchanged** and the exact v2 provenance recipe. I verified both embedded payloads byte-for-byte. The report’s original branch observation and contradictory test sentence remain preserved as historical input; the controlling instructions explicitly reconcile them.

### Routing and scope

The existing progress checkout remains read-only. Codex may create this new standalone candidate from the exact PR #11 squash:

```text
Checkout:
/Users/ds/Repositories/ES-Operational-Submit-Handoff-v1

Branch:
codex/reliable-submit-operational-handoff-v1

Base:
ae326b0ddc30ec6b35883ee32945c622405b68b6
```

The conversation’s attached workspace need not move. All edits and validation must explicitly target the new candidate.

The write allowance is **six files**:

```text
PLANS.md
.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md
.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md
.docs/execution_lifecycle/es_execution_admission_model.md
.docs/execution_lifecycle/reliable_submit_operational_handoff.md   [new]
docs_contract_test.go
```

The new document holds the detailed operational contract. The existing owners retain their respective authority and cross-reference it; this avoids scattering another large operating model across historical sections.

The turn must make the schema/scope compatibility, sender results and lifetime, canonical stage/job associations, positive provider evidence, receipt behavior, crash table, and prospective implementation acceptance matrix concrete. It also records PR #11’s completed source publication and labels the older plan entries as history. The merged plan currently still carries those pre-acceptance entries. 

Validation is limited to **four final documentation commands**, with exact selector execution and immediate integrity checks. There is no production-code edit, migration, fault diagnostic, full-suite replay, probe rebuild, public configuration, provider contact, or runtime wiring.

Expected endpoint:

```text
ES_OPERATIONAL_SUBMIT_HANDOFF_OWNER_CONTRACT_READY_FOR_REVIEW
```

The candidate remains **unstaged and uncommitted**, with a small exact six-file review packet. After architectural review, the integrated implementation can proceed in that candidate, followed by fresh independent audit. No standalone documentation PR is selected.

## Preserve the snapshot already produced

The report identifies an exact 430-leaf committed-source snapshot and sidecar, but neither is attached here yet. Their identity and content verification remain **Codex-reported**, not independently checked in this turn. Pasted text

Please upload the existing snapshot ZIP and `snapshot-source.json` from:

```text
/Users/ds/Downloads/ES-Post-PR11-Operational-Contract-2026-11-19-NwraN5aU/
```

Reported ZIP:

```text
Execution Substrate - Snapshot - 2026-11-19 - ae326b0d.zip
10,034,395 bytes
SHA-256:
e8110c68814318e215eb6a5c21e9ce2d1c5bddd2f65296b8ad18a6575c14a1d4
```

That upload does **not** hold up the contract-only turn, and no snapshot regeneration or old-checkout synchronization is needed.

**Sources:** Complete supplied decision report; preceding selection brief; pinned ES rules, plan, persistence contract, durable service, staging implementation, fixture test, example configuration and installer; live GitHub ref/deletion event; pinned Nomad source and official SQLite/Nomad documentation.

**Confidence:** **0.96** in selecting this model for contract drafting; **0.99** in the acceptance-matrix inconsistency and recorded branch-deletion reconciliation. Snapshot bytes remain uninspected; operational safety remains unimplemented and unvalidated.
