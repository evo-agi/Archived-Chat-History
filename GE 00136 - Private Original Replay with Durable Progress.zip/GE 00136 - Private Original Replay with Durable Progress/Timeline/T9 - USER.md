Before we proceed, I have to highlight that the prompts were sent to `/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1`, not `/Users/ds/Repositories/ES-Private-Replay-Progress-v1`.
