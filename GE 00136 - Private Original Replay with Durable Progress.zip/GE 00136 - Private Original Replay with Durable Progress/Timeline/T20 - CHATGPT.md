## `REJECT` stands — proceed with one consolidated repair

**The audit establishes real implementation defects, not a provenance failure or another audit-process problem.** SR-1 and SR-2 were independently reproduced. The reviewers also identified two migration-opening defects and four additional correctness, compatibility, or evidence issues. All four reviewers completed; the repository was left unchanged. Pasted text

The next step is **one repair turn in the same Codex conversation that returned this rejection**, followed by fresh independent acceptance of the resulting bytes. There is no reason to rerun the unchanged candidate or start eight separate repair tracks.

I read the complete audit and reopened the affected functions, contracts, and tests in the previously supplied implementation ZIP. I did not run repository code or inspect the auditor’s private diagnostic files.

## The consolidated finding set

| Finding | Evidence status | Selected correction |
|---|---|---|
| **SR-1 — confirmation eligibility** | High; reproduced on both establishment-confirmation paths | Recheck exact original-key eligibility and the live borrow before projecting the committed snapshot. Preserve the write’s disposition when projection is refused. |
| **M-1 — migration opening race** | High; source-confirmed inherited ordering defect | Authenticate the actual opening state **inside the migration writer transaction**, before migration writes. |
| **M-2 — schema namespace filter** | High; source-confirmed inherited qualification defect | Replace the wildcard namespace exclusion at both qualification boundaries with a literal `sqlite_` prefix rule. |
| **SR-2 — ineligible reconciliation no-op** | Medium; reproduced | Check the current recording predicate before accepting a fresh same-fact no-op. Preserve historical storage and legitimate exact replay. |
| **K1-1 — occupied disposition lost** | Medium; source-confirmed | Keep a definite losing establishment `Occupied` when subsequent winner disclosure fails. Preserve authenticated changed-intent conflict. |
| **N-1 — missing admission-level uncertainty witness** | Medium; acceptance-evidence gap | Exercise real COMMIT response loss through admission under the effect counters, rather than relying solely on lower-level tests. |
| **T-1 — terminal evidence association** | Medium; source-only evidence limitation | Bind terminal polarity and the acceptance receipt explicitly in the fixture evidence and validate them independently of command choice. |
| **R2-1 — scope-1 permit-burn drift** | Low; source-only compatibility change | Restore the inherited preflight-before-burn boundary without weakening burn after an eligible publication attempt begins. |

These classifications and limits come from the audit. **Only SR-1 and SR-2 have new dynamic reproductions in this audit; the other behavioral findings need their own regression evidence during repair.** Pasted text

## The most important repair decisions

### Preserve write knowledge while refusing disclosure

SR-1 is now demonstrated precisely: revocation was committed through another fixture handle and visible **before `ReadFixtureProgress` entry**. The confirmation paths still returned revision 1, while the ordinary current-read path correctly refused. The durable claim and sealed bytes remained unchanged. This is private fixture disclosure and confirmation—not a demonstrated public bypass or unsafe claim mutation. Pasted text

The repair must distinguish:

```text
Known establishment commit + failed eligibility check
→ retain Committed
→ return no projection

Uncertain establishment + failed confirmation
→ retain WriteUnknown
→ return no projection
```

It must also cover the associated borrow-lifetime concern: a use that passed its first check but waited for the issuer lock cannot disclose after the owning callback has ended. Rechecks belong after acquiring the relevant lock and before projection; no new capability registry or background mechanism is selected. The audit identifies that schedule as unexecuted, so it needs a deterministic test rather than a claim of already demonstrated failure. Pasted text

K1-1 applies the same separation to a definite loser: **failure to disclose the winner must not erase an already established `Occupied` result**. That mapping stays local to the known-loser path; it must not expose occupancy from an unauthenticated lookup or convert uncertainty into a definite outcome. Pasted text

### Fix migration qualification without changing the stored format

M-1 and M-2 belong in this repair even though their underlying patterns are inherited. They affect the opener used by the selected schema-4 migration, and the current owner contract already requires the stronger qualification. They are not unrelated cleanup work. Pasted text

For **M-1**, pre-lock observations may help reject input, but they cannot authorize subsequent migration writes. The transaction must reread and authenticate the actual application ID, version, schema, and ledger—or the pristine condition—before changing them. SQLite’s `BEGIN IMMEDIATE` establishes the write transaction immediately; observations made earlier are not retroactively protected by that lock. [SQLite](https://www.sqlite.org/lang_transaction.html)

The regression should deliberately commit a disallowed state through a second connection between preflight and lock acquisition. The repaired opener must refuse that actual state rather than overwrite it. A legitimate concurrent opener that has already completed the migration also needs a control: validate the authentic current state without replaying migrations.

For **M-2**, the error is the expression itself:

```sql
name NOT LIKE 'sqlite_%'
```

In SQLite `LIKE`, `_` means any single character, so this excludes more than the literal reserved prefix. The repair must correct both the pristine check and schema inventory, with an explicit literal-prefix and case rule. It must **not** change the legitimate migration literals or schema-hash constants to accommodate an extra object. Pasted text [SQLite](https://www.sqlite.org/lang_expr.html)

Both fixes require logical before/after witnesses that do not reuse the defective filter. Refusal preservation must not be inflated into a claim that opening SQLite never changes file or sidecar metadata.

### Make terminal association concrete, but keep it synthetic

T-1 needs a small explicit contract refinement before its code change. The present evidence value binds claim, run, marker, and fact presence, but carries neither independent outcome polarity nor the receipt association required by the contract. The audit did not execute a terminal counterexample. Pasted text

The selected correction uses a redacted fixture-evidence value with private fields and two finite constructors:

```text
NewFixtureAcceptedEvidence(..., receipt)
NewFixtureNotAcceptedEvidence(...)
```

Accepted evidence carries an exact receipt association; negative evidence carries no receipt. The durable service checks the evidence’s outcome, original/claim association, run, marker, fact, and receipt against the requested operation. Tests construct evidence first and then substitute the command’s receipt or polarity.

**This validates a bounded synthetic assertion. It does not establish that a provider accepted or rejected anything.** No signature system, evidence registry, new database, stored column, or provider adapter is selected. Existing operation encodings and durable formats stay unchanged.

## N-1 must reach admission without adding a product fault API

The audit correctly distinguishes lower-level uncertainty coverage from the required admission-level no-effect witness. The existing admission fixture does not exercise that unknown-write case under its provider, staging, and EGS counters. Pasted text

The prompt selects a **private external source view** containing the exact repaired candidate plus a narrowly bounded test bridge and admission diagnostic. The bridge attaches existing per-store commit-response hooks; it performs a real COMMIT and then models loss of the response. It does not replace admission result mapping or bypass authentication.

This keeps fault controls out of the product source. The witness must establish the admission-level disposition, projection, durable-write count, zero effect contacts, and unchanged operational roots. Its source and construction record must be retained for independent rerun.

The static guard’s limited treatment of aliases and free helpers remains disclosed. A general call-graph framework is **not** a prerequisite for this repair.

## The audit’s validation was useful—and correctly stopped short

The independent audit ran the first eight validation commands successfully, including the focused storage/custody checks and both historical opener probes. It then omitted the four-package and full-tree runs under the confirmed-blocker rule. **The 5,096-pass, 39-skip result is authenticated implementation evidence, not a fresh full-suite result from this audit.** Pasted text

The diagnostic itself exited 1 with **ten passing and thirteen failing identities**, including the failed parents. SR-2’s nine ineligible requests returned `NoChange` without changing the rows or sealed objects. The defect is false eligibility and projection, not an extra durable write. Pasted text

There is no benefit in rerunning the omitted suites before correcting these branches.

## Next Codex turn

Continue in the **same conversation that returned `REJECT`**, with all audit reviewers closed. Transition the foreground parent to workspace-write.

The sole source target remains:

```text
/Users/ds/Repositories/ES-Private-Replay-Progress-v1
```

:chatgpt-content-reference{index="14"}[Download the consolidated audit-repair prompt](sandbox:/mnt/data/ES_Private_Replay_Progress_Consolidated_Audit_Repair_20261119.md)

SHA-256:

```text
745c810b0f3fdfe42a74c0152058705b98e1e510024030cce86df797e74e4ebd
```

The prompt embeds the **complete supplied rejection, exact thirty-file opening manifest, and exact v2 provenance recipe**. I verified those three embedded payloads byte-for-byte.

The repair allowance covers **fifteen primary paths and five conditional companion paths**, all already in the thirty-path candidate. Production behavior changes are limited to five files. The remaining ten candidate rows and all 400 unchanged tracked files stay frozen. No new repository path, schema version, migration literal, envelope format, or operational authority is authorized.

The sequence is:

```text
owner-contract clarification
→ migration qualification
→ confirmation/lifetime and publication compatibility
→ terminal association and reconciliation predicates
→ admission disposition and uncertainty witness
→ final integrated validation and provenance
```

These are internal phases of one repair—not separate approval stops or PRs.

Final validation comprises the existing ten-command ladder, expanded with the new focused regression parents, plus the admission-level external witness: **eleven serial commands**. New counts must be reconciled rather than forced to equal 5,096. All commands require fresh integrity observations, including both untracked inventories.

Expected endpoint:

```text
ES_PRIVATE_REPLAY_PROGRESS_CONSOLIDATED_REPAIR_READY_FOR_FRESH_INDEPENDENT_AUDIT
```

The candidate stops **unstaged and uncommitted**, with a new exact review packet. Fresh independent audit then evaluates the complete repaired patch. The accepted architecture stays selected; the original rejection remains attached to manifest `110cef71…`.

**Sources:** Complete independent rejection; reopened implementation ZIP and preceding implementation/audit briefs; project provenance guidance; official SQLite documentation for transaction and pattern semantics. I inspected supplied source and reports, but did not rerun diagnostics or tests.

**Confidence:** **0.98** in the consolidated repair direction. Dynamic confirmation of SR-1/SR-2 is audit-reported; the other behavioral findings still require the specified regression evidence. Overall implementation acceptance remains outstanding.
