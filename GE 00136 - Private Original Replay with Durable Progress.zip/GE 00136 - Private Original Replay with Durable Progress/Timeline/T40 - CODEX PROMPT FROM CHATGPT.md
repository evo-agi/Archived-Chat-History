# Execution Substrate — Operational Submit Handoff Owner-Contract Candidate

Date: 2026-11-19 (America/New_York)
Posture: one parent writer; isolated documentation and documentation-test candidate.
No product implementation, schema execution, provider adapter, or runtime wiring.

## 1. Objective and selected direction

PR #11 completed the private original-replay/progress source slice. Select the
report's permanent-marker / one-live-sender operating model for the next bounded
CONTRACT CANDIDATE. Do not repeat the completed implementation, independent
acceptance, commit, push, or merge gates. Do not treat this prompt as acceptance
of unwritten production code or qualification of a deployed system.

Produce concrete, mutually consistent owner contracts and documentation tests
for one private operational handoff/restart slice, to be implemented later using
real SQLite, owned staging fixtures, and a controllable provider. Public ingress,
startup/config enablement, installed-state/key provisioning, a live Nomad
adapter, and native execution remain later gates. This is one integrated future
source slice; do not create a documentation-only PR or separate reader campaign.

The architectural selection is:
- one qualified local SQLite/custody domain, one immutable original/claim/attempt,
  one assigned run, and the existing durable service and phase algebra;
- new schema 5 / codec 5 / operational_local_v1, encoded scope 3, with explicitly
  independent original/wrapper/authentication version axes;
- current-state first-effect eligibility under a checked writer transaction,
  explicitly re-deriving the codec-5 reading of ADR §8 conditions 9–10;
- a permanent dispatch marker; only the invocation that actually applies the
  first NULL-to-marker transition and directly observes its COMMIT succeed may
  obtain one private, live, one-use send continuation;
- no sender from readback, recovered own-COMMIT, replay, no-op, a losing CAS,
  restart, generic current state, fixture output, or an externally supplied flag;
- no cross-invocation stage reattachment or automatic restaging/reclamation;
- conservative ambiguity after a committed marker with no conclusive positive
  acceptance evidence, including the possibility of indefinite ambiguity;
- accepted receipt recovery for the currently authorized equivalent caller,
  using the qualified retained original, without rerunning mutable first-effect
  admission, current resolution, staging, or provider operations.

The current merged implementation remains schema 4 and fixture-only. Mark every
new rule as selected target / contract candidate, not implemented behavior.
Preserve the old invocation's observed disposition even when a distinct later
operation is independently eligible. This is a re-derivation of a Reopened
redesign seam, not a reinterpretation of fixture success as authority.

## 2. Conversation routing and one-writer boundary

Continue in the SAME foreground conversation that produced Appendix A.
The conversation may remain associated with A1 or the private-progress checkout.
Its attached workspace is not the write target. Use explicit command cwd and
absolute edit paths. Close prior explorers before enabling writes. The parent is
the sole writer; spawn no subagents during this writing turn.

Preserved, READ-ONLY reference checkout:

    /Users/ds/Repositories/ES-Private-Replay-Progress-v1

New standalone candidate (must be absent before creation):

    /Users/ds/Repositories/ES-Operational-Submit-Handoff-v1
    branch: codex/reliable-submit-operational-handoff-v1

Create a normal independent clone from the official origin, not a linked
worktree, hard-linked local clone, shared object store, alternates, or a copy of
an existing working-tree overlay. A clone/fetch INTO THIS NEW CANDIDATE ONLY and
local initial branch/tracking setup are authorized. Fetch no existing checkout.
Bind and check out the exact squash below without force, reset, or replacement.
No source commit is authorized. Set the new branch's upstream to origin/trunk_dev.

If that proposed directory already exists, do not erase, reuse, repair, or select
another directory silently. Report the actual collision and stop before writes.
An existing candidate supplied by an explicit subsequent routing instruction can
be used only after exact baseline reconciliation.

Existing ES, A1, O2, custody and progress checkouts remain byte/ref/index/config
unchanged. Coordinator and supplementary repositories are outside this turn.
GE core comprises ES and Coordinator; CP is compatibility/reference, not a new
peer authority. Reports, snapshots, model output, and this prompt own no run truth.

## 3. Pinned source and the deleted historical topic

Official repository: evo-agi/Execution-Substrate
Official origin: git@github.com:evo-agi/Execution-Substrate.git
Merged checkpoint: PR #11
Required new candidate HEAD: ae326b0ddc30ec6b35883ee32945c622405b68b6
Required sole parent: f1aa8b934cc26c16a966a110c7b408abdaeadce7
Required tree: e066cd4afa77fcb665f31b69bf00465989f9744e
Required subject: Add private original replay with durable progress (#11)
Committed source: 430 regular leaves, 370 Git 100644 and 60 Git 100755.
Preserved equivalent local source: dbdc433283617b9e3b233f75c92f1179c2ece91f.

ChatGPT refreshed official trunk at this squash. The old remote topic
codex/private-replay-progress-v1 is absent. GitHub issue event 36713565764 on
PR #11 records head_ref_deleted at 2026-11-19T23:50:02Z (18:50:02 EST), attributed
to account SeritArbores, after the merge at 23:47:16Z. This is a new read-only
observation correcting Appendix A's unexplained-absence status; it does not
prove motive, UI route, or automatic-deletion settings. It does not authorize
restoration, deletion, or upstream repair in any existing checkout.

Event source:
https://api.github.com/repos/evo-agi/Execution-Substrate/issues/events/36713565764

The new candidate is based on the immutable squash, NOT on the deleted topic.
No remote-topic restoration or forensic campaign is a prerequisite. Preserve
historical reports unchanged and report this reconciled ref status separately.

Authenticate Appendix A and the report's material snapshot/decision identities
actually used. The supplied report and private report may be different transport
renditions; compare decision facts without silently rewriting either. Do not
rehash unrelated acceptance histories, caches, or all past evidence roots.

Snapshot already produced by the prior turn (do not regenerate):
/Users/ds/Downloads/ES-Post-PR11-Operational-Contract-2026-11-19-NwraN5aU/Execution Substrate - Snapshot - 2026-11-19 - ae326b0d.zip
  size 10034395
  SHA-256 e8110c68814318e215eb6a5c21e9ce2d1c5bddd2f65296b8ad18a6575c14a1d4
Sidecar in the same directory: snapshot-source.json
  size 119616
  SHA-256 9f60338fa5dadcfdef77163a3da32df56f1d2edc60c142a7770e0e1503b5f6bd
Decision record: decision-record.json
  SHA-256 499f3b7dfd33215fcdb1f26b30b6386837ee566948ebc2ed4068cf57419a1481
Private report: report.txt
  SHA-256 7dcd3472cff6d0cd4ae7d9117f3e2632b3f6a6c725299a20ed3f1758c69f35a4
Prior evidence index: artifact-index.json
  SHA-256 48602d721cc67c301314bbeeb4a8ec60a76ac68554a14a2c793cd09d6e36f397

Snapshot upload to ChatGPT is useful but is not a prerequisite for this bounded
host-side contract turn. The committed Git objects are available independently.

At opening, verify repository root, own Git/common directories, exact committed
identities, complete 430-leaf tree, clean index/worktree and both untracked
categories. Record new candidate remote/tracking and the preserved checkout's
named branch/HEAD/index/config/status before and after setup. Do not depend on
unstable unrelated Codex session-ref aggregates.

Observe official trunk before setup and closeout. If it has advanced, disclose
that newer-base overlay; keep the selected immutable checkpoint. Do not silently
rebase or edit another tree. This contract-only pass can continue at the verified
pin if no relevant authority conflict is demonstrated; a later source/publication
gate must reconcile any intervening delta. If the pin itself is inaccessible or
cannot be bound, stop; never substitute a remembered tree.

## 4. Complete write allowance — six files

Five existing files:

    PLANS.md
    .docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md
    .docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md
    .docs/execution_lifecycle/es_execution_admission_model.md
    docs_contract_test.go

One new owner document:

    .docs/execution_lifecycle/reliable_submit_operational_handoff.md

The new document is the detailed codec-5 handoff/restart contract owner, not
another implementation or authority. Link it from the existing owners and keep
one definition of each new rule. Use the existing persistence ADR for SQLite and
migration authority, submit/recovery for caller/disclosure semantics, and the
admission model for composition and transient-ownership boundaries. State a
clear precedence/cross-reference map; no conflicting duplicate specifications.

No other file may change. In particular no production .go, schema, migration
literal, go.mod/go.sum, typed Workstream C inventory, public API, startup,
configuration, script, example, runtime helper, or deployment change is allowed.
The root Go change is documentation-test code only. The 425 other committed
leaves must match the pinned bytes and modes. Maximum final source count is 431.

Use the new contract document to avoid burying this operating model in another
large historical report section. This is not a general documentation cleanup.
Preserve historical decisions/failures and accepted fixture text. Correct current
status in PLANS.md with the exact PR #11 squash/tree and next selection, clearly
labeling the previous rejection/candidate entries as historical. Do not amend
past reports or claim independent acceptance of this new document candidate.

## 5. Required source grounding before drafting

Read AGENTS.md, the top and relevant active portions of PLANS.md, and the actual
owners and tests together. Use Appendix A's inspected paths and prospective map
as starting anchors, not proof that source already implements the proposal.

Required current sources include:
- persistence ADR §8, §15B (especially K1), §16, deployment/state/key ownership;
- submit/recovery §6B, caller/key and receipt/disclosure rules, retention and open
  operational seams; admission §7.4/§7.5;
- system boundaries, capability probing and supported-local Linux qualifications;
- actual durable service/CAS, migrations and schema-4 checks, original custody,
  paired-key eligibility and their tests;
- staging creation/materialization/revalidation and current ordinary Submit,
  Nomad request builder/transport, lifecycle query/auth routes and tests;
- API caller identity, current config/startup, installer/provider pinning, and
  examples as current-behavior evidence only; inspect, do not execute scripts;
- root documentation tests and finite caller/field inventories relevant to new
  target statements. Preserve their current-source expectations.

ChatGPT reopened the pinned rules, plan, §8, durable_service.go:230–355 and
staging_custody.go:451–548. Those are source anchors, not a complete implementation
review. Re-find exact lines and read enough surrounding code to prevent a
contract that cannot be represented or conflicts with unchanged invariants.

Do not run product tests, diagnostics, migrations or provider calls to resolve
design questions in this turn. Static draft review and the exact documentation
validation below are the execution allowance.

## 6. Finite owner decisions to express in the draft

### 6A. Scope, compatibility, stable domain and state shape

Carry the proposed first target as a bounded future qualification: one ES
installation on governed Ubuntu 24.04 Linux arm64 supported-local, one authorized
workload identity, asynchronous static-script/default, an immutable qualified
image, one nonperiodic/nonparameterized/single-region batch with one group/task,
and no added workload mounts or network access. This does not qualify the current
host, rootful deployment, binary, storage or key installation.

Cooperating instances may overlap only at the same qualified release, immutable
installation policy epoch, and same unchanged local DB/custody/staging domain.
A changed epoch requires actual withdrawal of older effect-enabled instances and
requalification. It is installation policy, not a per-request human approval.
No HA, mixed-version effect writers, restore/rollback/clone of runtime state,
failover to an empty DB, automatic expiry/GC, key reuse, semantic retry, or new
response-history ledger is selected. Describe administrative violations that
invalidate the safety premise; a filesystem path alone is not domain identity.

Freeze schema 5, row codec 5 and encoded scope 3 separately. Preserve schema/migration
1–4 literals, hashes and meanings, historic codecs 1/2, immutable codec 3 and
fixture codec 4. No promotion/relabeling of existing rows, objects, grants,
markers, borrows or receipts. Preserve global caller/key occupation. Define a
codec-5-only operational RunRef uniqueness rule, absent-run treatment, and exact
collision refusal without reassignment. Freeze a disjoint safe internal stage
and provider-locator grammar without silently changing current public run grammar.

Specify the complete retained-field and immutable/mutable matrix, cross-scope
read/write/dispatch refusal matrix, original framing and independent version axes,
parser and allocation bounds, cryptographic purposes/domains, and migration shape
and recovery requirements. Reuse existing fields where their semantics fit;
justify every new stored field, rather than adding one for an implementation
convenience. The draft must give exact formats/limits or explicitly mark a
material selection blocked; do not leave an implementer to invent them.

Require preprovisioned exact ACTIVE original keys for new operational grants,
claim establishment, staging authorization and marker admission. Missing-key
auto-registration in fixture paths is not operational provisioning. Define paired
eligibility cuts and ACTIVE/RETIRED recovery precisely. Do not promise atomic
retraction of a sender whose admission already preceded revocation, or of I/O
already in flight. Distinguish current caller authorization from current
first-effect admission and from retained-original authentication.

### 6B. Explicit §8 re-derivation and narrow safety argument

Keep conditions 1–8 and 11–12 with the selected precise current-revision checks.
For codec 5 ONLY, replace history-wide known-disposition conditions 9–10 with a
fresh checked writer turn that reads current authenticated state after BEGIN
IMMEDIATE succeeds, on the unchanged shared authority domain. Preflight, a stale
read snapshot, cached row or unlocked absence is not that observation. Bind any
prior original authentication to the exact row/physical original used under the
writer turn. Specify bounded read-only qualification versus effect-producing
filesystem/provider I/O; staging and transport never occur inside SQLite.

State the proof premises and outcomes explicitly:
1. Every eligible operational send must originate in the unique applied
   NULL-to-marker mutation; marker identity is permanent and never cleared.
2. Same-domain writer serialization, constraints and expected-revision CAS permit
   only one such transition; the old unsettled writer either excludes the new
   turn or has settled before it reads.
3. Only direct observed success for THAT APPLIED mutation can mint the one-use
   sender. A successful no-op/read/CAS loser or generic nil error is insufficient.
4. All later reads, recovery, replay and restarts produce zero senders. A live
   continuation can be consumed at most once and cannot be reconstructed from
   retained facts.
5. Prepared request and held staging are bound to the same original/run/marker;
   the transport does not introduce another application-level POST delivery.

This is a conditional at-most-once ES registration-dispatch argument. It is not
exactly-once execution, guaranteed send, guaranteed acceptance, job completion,
or a universal prevention of workload side effects. Nomad lifecycle/scheduling
and Coordinator semantic acceptance remain their respective authorities.

Earlier unknown responses remain unknown. Present eligibility must not claim to
reconstruct prior caller observations. A fresh invocation evaluates identical
retained facts and identical fresh qualified inputs identically. The completed
fixture §15B K1 contract remains unchanged; give codec 5 an explicit distinct
operational rule rather than weakening every scope's semantics.

### 6C. Sender lifetime and result vocabulary

Specify exact typed operation/result/error interfaces, not a raw bool `committed`
or freely constructible callback token. Explain how the store/durable service
reports an actual applied first-marker transition and its DIRECT COMMIT outcome
without conflating it with OwnCommitConfirmed, replay/no-change, stale, conflict,
occupied or refused results. Give every result row its returned projection,
side effects and sender count.

The sender is private, issuer-bound, invocation-bound, one-use and nontransferable,
with copied/foreign/zero/closed/escaped instances refusing. Define its original,
run, marker, stage-descriptor and prepared-request bindings; issuance, consumption,
cancellation/close linearization and disposal owners. Consume before the single
synchronous transport entry. Burn on observed cancellation, callback return,
closed custody, denied final validation or failure. No later callback/goroutine
may use an expired owner. Do not invent a global capability registry, lease,
root-pair registry, flock or poison subsystem. Any proposed local synchronization
owner must protect a named transient fact and be inventoried later with source.
A process-image clone/fork of a live capability is not covered by a Go-type claim.

No sender from a real marker COMMIT whose response was lost, even if an exact
subsequent read confirms that mutation. A known marker followed by a crash before
send may remain ambiguous permanently; positive recovery never resends.

Distinguish a handoff invocation from its individual durable commands. Specify
what happens after uncertain claim/assignment/intent/stamp writes, and when the
invocation terminates without another effect. For this first slice, choose a
conservative stop of the effect-producing sequence after an uncertain durable
command; safe readback may classify that command but cannot implicitly resume
staging or mint a sender. A later explicit invocation can reconsider pre-stage
work only where both the durable and physical prerequisites permit it. This does
not change the already accepted fixture API.

### 6D. Staging boundary and correction to Appendix A's matrix

Keep the no-reattachment selection. Claim/run/intent must be durable before any
execution-producing stage creation. Only a successful exclusive descriptor-relative
creation under a qualified parent obtains a new live staging owner. Preserve
residue on every failure. An existing partial or complete directory, a durable
stamp without its original live owner, a missing directory despite a stamp, or
unsettled custody yields zero send permission. No adoption, reopening for dispatch,
delete-and-recreate, retry with a new run, or capacity refund is selected.

The still-live original owner may finish a nonfailed materialization sequence
subject to the selected checks. A later invocation cannot inherit it. Differentiate
that live continuation from recovering a dead owner's files as read-only evidence.
A complete stamp or valid digest is evidence, not a replacement for held custody.

CORRECT THIS REPORT CONTRADICTION without adding another model: Appendix A's
acceptance row says a rolled-back marker with an untouched stage allows a
DISTINCT qualifying invocation to win. But a valid marker attempt requires the
complete stage/stamp, and its prior invocation's failure leaves a stage that the
new invocation cannot acquire. Preserve the staging restriction, not that test.

Required future cases:
- Positive restart eligibility after a settled pre-stage claim/assignment/intent
  uncertainty, with no retained stage stamp AND no physical stage, then one new
  qualified creation and one directly acknowledged first marker/send.
- Real marker rollback or failed/uncertain marker after valid staging: the failed
  invocation sends zero; a distinct invocation also sends zero because it cannot
  reattach, despite a subsequently authenticated absent marker. Preserve residue
  and capacity charge.
- Real marker COMMIT with lost response: zero send by that invocation and every
  later one; readback may observe the marker but grants no sender.
- Known marker followed by one valid consumed continuation: exactly one receiver
  delivery total; every redelivery/restart/replay produces zero additional POSTs.

Specify canonical stage proof encoding over ordered paths, type, mode, bounded
size and bytes, exact original/run association, held/visible identities and the
versioned prepared job projection. Freeze symlink/hard-link/type/extra-path,
parser/order/size and changed-content refusal. Explain which roots/mounts and
post-check filesystem integrity assumptions still require native qualification.
Avoid a hash cycle: define what fields a stage stamp or keyed correlation covers,
which carrier fields are excluded from their own preimage, and how all excluded
values are separately bound. A generic 'canonical digest' is not sufficient.

### 6E. Provider exchange, positive evidence and receipt

Use a typed private provider boundary for the later controlled proof. The same
handoff control flow must exercise actual fixture SQLite/staging and a counting
loopback receiver; do not create a second orchestrator solely in tests. Runtime
constructors and real endpoint/key configuration remain absent. The fake can
exhibit the documented provider behaviors; passing it does not qualify Nomad.

Select direct bounded create-only registration: EnforceIndex=true,
JobModifyIndex=0, exact authenticated installation/region/datacenter/namespace,
and disjoint job locator. No redirect following, application retry/resend,
implicit client/proxy replay, POST fallback, or alternate provider on refusal.
Define what transport/body settings uphold the single-exchange claim. Count
actual logical POST ingress, not TCP retransmitted packets, and distinguish
transport invocation count from receiver-delivery count.

External evidence checked during this handoff:
- Nomad refs/tags/v2.0.3 resolves to
  a2a5fee9c42d6481adcb9be865bcbccf8fd4d725.
- nomad/state/state_store.go:1785–1832 opens the write transaction, looks up the
  existing job and evaluates EnforceIndex in that transaction.
- nomad/job_endpoint.go:290–375 builds the job-register evaluation and populates
  response indexes for the selected path; nomad/fsm.go:795–806 applies evaluation
  state separately. Read the entire relevant call chain before freezing equality
  constraints. Do not infer one atomic Job+Eval observation from one Raft request.
- Official API documents the zero-index new-job condition. Neither that text nor
  the source pin qualifies the ES installation, whose installer is unpinned.

Source links:
https://developer.hashicorp.com/nomad/api-docs/jobs#register-job
https://developer.hashicorp.com/nomad/api-docs#consistency-modes
https://github.com/hashicorp/nomad/blob/a2a5fee9c42d6481adcb9be865bcbccf8fd4d725/nomad/state/state_store.go
https://github.com/hashicorp/nomad/blob/a2a5fee9c42d6481adcb9be865bcbccf8fd4d725/nomad/job_endpoint.go
https://github.com/hashicorp/nomad/blob/a2a5fee9c42d6481adcb9be865bcbccf8fd4d725/nomad/fsm.go

A tag is supporting reference evidence, not 'the installed version' or permission
to upgrade a host. Recheck version-specific facts against pinned primary source;
do not substitute a latest-version response example for that source's relation.

Freeze exact bounded Job GET and Evaluations GET request/response contracts,
observation provenance/consistency conditions, body/count/time limits, selected
initial generation indexes and field relations, unique matching registration
evaluation, and comparison with any authenticated immediate POST response. Separate
mutable status/ModifyIndex from initial effect-bearing JobModifyIndex/CreateIndex
where the provider source does. Do not assume matching arbitrary metadata proves
receipt authenticity. Specify the ES-keyed marker correlation and its exact
purpose-separated preimage and validation key, with no raw secret in provider
metadata. Avoid self-referential job digests.

Name every effect-bearing projection field and an exact permitted normalization
map. Unknown or unsupported effect-bearing values, malformed/duplicate fields,
foreign identities, wrong indexes/receipt polarity, collisions, job-without-eval,
missing/stale/unqualified observations, timeout and oversize must not yield a
receipt or a second POST. A 404 is not proof of no acceptance. No provider-forced
resubmission or negative terminal inference from generic absence is selected.

Provider query witness verifies registration acceptance, not completed execution
or semantic work acceptance. Choose a single bounded positive-evidence representation
and receipt CAS, with its same-claim/run/marker binding, replay and concurrent-winner
semantics. Do not add a provider-history mirror. A durable accepted receipt remains
immutable and caller-authorized; receipt COMMIT response loss must permit recovery
of the same receipt without another effect or a new receipt identity. Failed
recovery preserves the old invocation's unknown disposition.

### 6F. Ingress/disclosure and deployment are later gates

Select the report's receipt policy: current exact caller authorization and
qualified equivalent retained original; ACTIVE/RETIRED keys permitted for accepted
receipt verification, revoked/missing/wrong-purpose keys withhold disclosure;
no rerunning mutable execution admission or current resolver defaults to read
that accepted receipt. First effects require current admission and ACTIVE keys.

Keep unauthorized before lookup and conflict/unavailable privacy. Distinguish
pre-assignment no-run outcomes from after-assignment same-run outcomes. Define
private result mappings now; do not select new public JSON fields, HTTP statuses,
producer declaration or configuration spelling incidentally. Future public
lifecycle access must be claim-scoped; existing route-level ACL is not proof of
ownership. Preserve unkeyed compatibility and current public keyed refusal.

Record explicit later qualification gates: one canonical verified workload SPIFFE
identity; default-off startup; owner-only preprovisioned DB/custody/keys; stable
installation identity and policy epoch; exact installed provider build and ACL /
exclusive writer namespace; qualified direct transport and observation provenance;
installed stage/mount identity; finite retained storage; caller-scoped lifecycle.
The rootful supported-local profile does not establish es:es private-store ownership.
Do not resolve that conflict by silently weakening private file/key ownership.

### 6G. Boundedness and historical-residual treatment

Carry the four operational-claim-slot, 32-object-name and 32-nonrefundable-reservation
values as finite PROOF PROFILE values, not universal native sizing. Account for
legacy/synthetic scope occupation and orphan/reservation sharing explicitly.
Classify existing keys normally at capacity; refuse new work without expiry,
refund, key reuse, auto-GC or manual routine approval. Bound staging and byte
consumption separately before native enablement.

Unconfirmed cleanup/disposal withholds authority. Keep hard-close latency,
physical/device close, actual double withholding, SQLite sidecar/file-byte
preservation, hostile native filesystem behavior and restore limitations visible.
Do not open a new helper-repair campaign solely because a residual exists.
Separate a concrete prerequisite for the selected safety property from a bounded
availability/qualification limit. No operational proof follows from a green
documentation test or the already accepted fixture test suite.

## 7. Deliver an implementation-ready acceptance specification

In the new owner document, provide:
- a current / selected target / proof-only / native prerequisite classification;
- explicit state, format, association and compatibility tables;
- one exact operation/API and result table, including sender count and effect
  permissions at every outcome and uncertainty exit;
- the crash/concurrency table, corrected as in §6D, and the K1 indistinguishable
  histories; show no unrecorded response history decides eligibility;
- the actual safety assumptions, stated availability losses, all authority
  writers, and explicit forbidden transitions;
- a finite prospective touched-path map with governing sections and exact named
  new behavior tests, not a broad allowance to edit an entire package;
- positive and adversarial witnesses for two processes/handles, stale/canceled
  owners, direct-vs-recovered COMMIT, two competing marker attempts, stage residue,
  changed key/policy cuts, foreign/expired sender use, real POST count, redirect
  targets, lost response, positive-provider witness and receipt replay;
- migration/old-binary/refusal evidence and no synthetic-to-operational conversion.
  Plan a separately source-bound schema-4 opener for the schema-5 refusal proof;
  historical schema-2 and schema-3 probes cannot supply that evidence. Do not
  build or rerun any probe in this turn;
- explicit public/startup/ordinary Submit/fixture no-caller and compatibility
  evidence, with no current field-inventory update before a source change exists.

Complete the exact selections in the document; do not leave materially undefined
sentences such as 'canonical proof', 'validated receipt', 'current ownership' or
'known COMMIT' for a production implementer to interpret. If the retained model
cannot express a required safety association, surface that precise contract
conflict and stop before expanding scope. Ordinary drafting refinements within
these selections do not need per-table approval stops.

## 8. Documentation tests and bounded validation

Add the exact parents:

    TestOperationalSubmitHandoffContractSelection
    TestOperationalSubmitHandoffContractRejectsUnsafeMutants

They read the governing files and statically assert selected target semantics;
they must not import or invoke nonexistent future implementations, migrations,
providers, listeners or host scripts. Use semantic bounded section extraction and
negative mutants, not only presence of attractive phrases. Retain unrelated
assertions. Revise only existing assertions made intentionally obsolete by the
explicit codec-5 target split, explaining each change; preserve codec-4 invariants.

Required mutants reject at least:
1. mint sender from recovered own-COMMIT, latest replay, no-op or current read;
2. marker absence without a fresh qualified writer turn / physical prerequisites;
3. new invocation adopts a staged directory or stamp after owner loss;
4. unknown marker invocation proceeds to POST or auto-retries a marker;
5. automatic POST/redirect replay or a provider 404 converted into no-acceptance;
6. synthetic row/object/capability converted to operational authority;
7. accepted receipt replay requires mutable first-effect re-resolution;
8. route-level authorization treated as claim ownership or public wiring current;
9. the erroneous rolled-back-marker/new-owner positive case from Appendix A;
10. a known marker is treated as guaranteed send/acceptance/execution.

Use the known pinned offline tools; do not install or update dependencies:

    GO=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go
    GOFMT=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/gofmt
    PYTHON=/Library/Frameworks/Python.framework/Versions/3.13/bin/python3

Record actual safe executable identities and behavior; do not assume the path's
name is proof. Preflight existing Python tomllib and required read-only root-test
tools without network, service discovery, certificate provisioning or downloads.
Use GOTOOLCHAIN=local, GOPROXY=off, GOSUMDB=off, GOWORK=off, GOFLAGS=-mod=readonly,
GOENV=off, CGO_ENABLED=0, GOTELEMETRY=off, GOMODCACHE=/Users/ds/go/pkg/mod,
GIT_OPTIONAL_LOCKS=0, GIT_NO_LAZY_FETCH=1, GIT_TERMINAL_PROMPT=0,
PYTHONDONTWRITEBYTECODE=1 and Python -B. Use external owned GOCACHE/GOTMPDIR/TMPDIR,
outer umask 077 and test subprocess umask 027. Do not write caches into source or
historical evidence. Permit existing synthetic test-owned temporary files only
where these selected documentation tests actually require them; no live service.

Four final primary commands, serially from the NEW candidate:

```sh
"$GO" version
"$GOFMT" -d docs_contract_test.go
git --no-pager diff --check
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestOperationalSubmitHandoffContractSelection|TestOperationalSubmitHandoffContractRejectsUnsafeMutants|TestPrivateOriginalReplayProgressContractSelection|TestPrivateReplayProgressSynchronizationInventoryDocsContract|TestReliableSubmitPersistenceAndConcurrencyADRDocsContract|TestSubmitIdempotencyCorrelationAndRecoveryDocsContract|TestReliableSubmitPublicOptInAndVersioningDocsContract|TestReliableSubmitContractAdapterFoundationDocsAndSourceContract|TestResolvedPlanDocumentationTruthAndFiniteInventoriesContract|TestIntegratedAcceptanceGateDocumentationIsConsistent|TestIntegratedCandidateStatusSeparatesCAndT)$' .
```

Require actual execution of all eleven named parents; 'no tests to run' is not
success. Record the real leaf identities/counts; do not freeze an invented total.
Require formatting to produce no diff and both whitespace checks (including the
new file's text hygiene) to be clean. Formatting during authorized development
may change only docs_contract_test.go. Keep every failed development run with
its source generation and cause; ordinary in-scope repairs are allowed before
final freeze. After any edit, rerun all four final commands on a newly frozen
generation. No silent rerun-until-green or omitted selector.

After each primary command, freshly check exact allowed changed rows, all 425
other tracked blobs/modes, HEAD/branch/upstream, index equals HEAD, ordinary
untracked (only the one authorized new document) and ignored inventories.
Check the preserved reference checkout at setup/closeout, not every historical
root after each command. No full ./..., admission/internal package test replay,
fault diagnostic, snapshot/probe rebuild, capability campaign or live-host check.

## 9. New patch provenance and exact review delivery

This new branch is a NEW provenance target. The prior clean committed tree and
historical f92b57f4... patch manifest are not its expected final canonical bytes.
Use the exact Appendix B v2 recipe, unchanged. Before executing it read/authenticate
its complete bytes. Run twice from the new candidate into two distinct absent
files in a fresh private external directory. Its immediate parent must be owned,
nonsymlink and non-group/world-writable; use 0700 on the NEW evidence root. Do not
chmod an existing 0755 ancestor such as /Users/ds/Repositories.

Example interface after binding the exact payload and private root:

    (cd "$CANDIDATE" && "$PYTHON" -B "$EVIDENCE/governed_execution_audit_patch_manifest_v2.py" "$EVIDENCE/manifest-a.json")
    (cd "$CANDIDATE" && "$PYTHON" -B "$EVIDENCE/governed_execution_audit_patch_manifest_v2.py" "$EVIDENCE/manifest-b.json")

Require byte-identical final outputs and report recipe/source/diff/manifest hashes.
Do not stage the new document just to put it into an ordinary tracked diff.

Return one small exact contract review ZIP, not another full snapshot, containing:
- all six complete changed files with accurate modes;
- the complete tracked HEAD diff and an explicit complete new-document payload
  (or a separately identified full six-path patch);
- final canonical manifest, source map and reviewed baseline identities;
- safe README, decision/scope summary and self-excluding delivery inventory.
Verify every ZIP member and both patch sides against actual files and committed
baseline. Use unique regular safe members, no .git/cache/SQLite/secret material,
and preserve source modes in metadata. Classify any suspicious material first.
Do not assert you attached a local file; give its exact upload path, size and
SHA-256. The already produced post-PR11 snapshot/sidecar stay unchanged.

The full human-readable closeout must be INLINE. A local report is a duplicate,
not a substitute. Include the selected decisions, exact touched files, one clear
disposition of the corrected matrix row, actual commands/results/failed runs,
source/provenance hashes, remaining undefined or blocked seams, external research
versions, skip inventory, authority/security widening, and effects performed.
Compute hash/path tables from machine records and parse them back before delivery;
do not hand-transcribe or silently repair prior report cells. Exact bulky machine
data may be linked privately, but every decision-relevant fact must be inline.

## 10. Stops and endpoint

Stop rather than bypass on wrong source identity, missing pin, unexpected write
path, existing new-candidate collision, actual authority conflict, unsafe archive
or secrets, need for schema/product/runtime code, a materially unrepresentable
contract, or inability to run the allowed final checks. Preserve source and
failed evidence; do not reset, clean, switch targets or weaken safety assertions.
Remote deletion of the historical topic is known and not itself a stop condition.

Authorized endpoint:

    ES_OPERATIONAL_SUBMIT_HANDOFF_OWNER_CONTRACT_READY_FOR_REVIEW

Also state:

    PRODUCT_IMPLEMENTATION_NOT_PERFORMED
    SCHEMA5_NOT_EXECUTED
    SOURCE_INDEPENDENT_ACCEPTANCE_NOT_PERFORMED
    STAGING_COMMIT_PUSH_PR_MUTATION_NOT_PERFORMED
    EXISTING_CHECKOUTS_NOT_SYNCHRONIZED
    REAL_PROVIDER_OR_HOST_NOT_CONTACTED
    RUNTIME_WIRING_NOT_PERFORMED
    PUBLIC_RELIABLE_SUBMIT_NOT_ENABLED
    OPERATIONAL_SAFETY_NOT_YET_VALIDATED

The candidate stops unstaged and uncommitted. After exact architectural review,
a separate prompt can authorize the integrated source implementation in the same
candidate, followed by fresh independent audit. Do not implement that later phase
merely because the document describes it.

## Framed appendices — exact source inputs, not executable instructions by themselves

Extract by the byte length below, not by Markdown reflow or a guessed fence.
Verify SHA-256 before interpreting or executing Appendix B. Framing separators
are not payload bytes. Appendix A remains the original report, including its now
reconciled remote-ref observation and the acceptance-matrix sentence corrected
by §6D above.

### Appendix A — Complete supplied post-PR11 decision report

Payload bytes: 32243
SHA-256: 8e7a73bab851f3ba7cf13e5d8d69ef78ff299cb225d8726b4f3194c1657ff928

<!-- BEGIN APPENDIX A EXACT PAYLOAD -->
# ES_POST_PR11_OPERATIONAL_SUBMIT_CONTRACT_DECISION_READY

**Recommendation:** Use one checked SQLite writer domain, a permanent dispatch marker, and one live sender issued only to the invocation that directly observes the first marker COMMIT succeed. A later invocation may qualify a fresh first-effect decision while the claim is still unmarked. Once the marker exists, every later invocation is limited to authenticated recovery and reconciliation of that same run.

This explicitly re-derives the operational rule in persistence ADR §8. **It is proposed, pending owner review, and unimplemented.** Prove the handoff and restart behavior with real SQLite and a controllable provider before public ingress, startup enablement, or a live Nomad adapter.

## Checkpoint and delivery

I verified merged [PR #11](https://github.com/evo-agi/Execution-Substrate/pull/11), squash `ae326b0ddc30ec6b35883ee32945c622405b68b6`, sole parent `f1aa8b934cc26c16a966a110c7b408abdaeadce7`, and all 430 leaves of tree `e066cd4afa77fcb665f31b69bf00465989f9744e`. The squash object is absent locally. The export used the preserved local commit `dbdc433283617b9e3b233f75c92f1179c2ece91f` after complete tree equality was established.

**Remote ref drift:** Official `trunk_dev` pointed to the pinned squash at opening and closing. The remote topic was absent at both observations. Git omitted it and the authenticated GitHub ref API returned 404. The merged PR still binds the exact topic commit, and the local topic, upstream configuration, tracking ref, index, and all working bytes and modes were unchanged. The initial verifier stopped on the missing ref. I preserved that result, reconciled the absence against the immutable PR/squash and local tree, and used that same pinned tree throughout. The branch’s disappearance remains unexplained and needs reconciliation before any future work that relies on it.

| Deliverable | Identity |
|---|---|
| [Exact snapshot ZIP](</Users/ds/Downloads/ES-Post-PR11-Operational-Contract-2026-11-19-NwraN5aU/Execution Substrate - Snapshot - 2026-11-19 - ae326b0d.zip>) | 10,034,395 bytes · `e8110c68814318e215eb6a5c21e9ce2d1c5bddd2f65296b8ad18a6575c14a1d4` |
| [Committed-source sidecar](/Users/ds/Downloads/ES-Post-PR11-Operational-Contract-2026-11-19-NwraN5aU/snapshot-source.json) | 119,616 bytes · `9f60338fa5dadcfdef77163a3da32df56f1d2edc60c142a7770e0e1503b5f6bd` |
| [Decision record](/Users/ds/Downloads/ES-Post-PR11-Operational-Contract-2026-11-19-NwraN5aU/decision-record.json) | `499f3b7dfd33215fcdb1f26b30b6386837ee566948ebc2ed4068cf57419a1481` |
| [Private report](/Users/ds/Downloads/ES-Post-PR11-Operational-Contract-2026-11-19-NwraN5aU/report.txt) | `7dcd3472cff6d0cd4ae7d9117f3e2632b3f6a6c725299a20ed3f1758c69f35a4` |
| [Self-excluding evidence index](/Users/ds/Downloads/ES-Post-PR11-Operational-Contract-2026-11-19-NwraN5aU/artifact-index.json) | 188 entries · `48602d721cc67c301314bbeeb4a8ec60a76ac68554a14a2c793cd09d6e36f397` |

The ZIP contains exactly 370 regular `100644` files and 60 `100755` files under `Execution Substrate/`. I exported sorted Git blobs with fixed archive metadata, then reread committed objects to compare every archived payload, mode, object ID, size, and SHA-256. The three tracked example archives each contain one text entrypoint. The tracked PEM is a public synthetic parser certificate. Scoped inspection classified credential-shaped hits as code, marker literals, or synthetic redaction fixtures. The ZIP has no working-tree overlay, Git administration, external N-1 sources, or private evidence.

## Current behavior and proposed change

The merged plan’s pre-acceptance wording is historical. PR #11 completed the accepted private source slice, and codec 4 remains an effect-ineligible fixture. This recommendation supersedes the proposed ingress/startup-first ordering. The next slice proves the effect boundary before giving any public route a way to reach it.

| Surface | Current at the checkpoint | Proposed boundary |
|---|---|---|
| HTTP and identity | mTLS and prefix/path authorization lead to ordinary `Submit`. The structural reliable body is refused. The private caller/key derivation helper does not verify canonical SPIFFE identity. | Future reliable ingress selects one verified canonical full SPIFFE ID, authorizes before lookup, and uses the existing structural opt-in. [API handler](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/api/server.go:129) · [Caller derivation](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/reliable_submit_identity.go:24) |
| Original custody and lifecycle progress | PB1, codec-3 immutable custody, and codec-4 progress are private. K1 provides invocation-local outcome handling and authenticated current fixture reads. | Reuse the algorithms, checked SQLite writer, and phase algebra through a distinct operational codec. Fixture objects, borrows, markers, and receipts remain ineligible. [Private composer](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/reliable_submit_replay_private.go:211) · [K1 and operational deferral](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1602) |
| Staging and provider | Ordinary `Submit` resolves a plan, allocates a fresh locator, exclusively creates and materializes the stage, revalidates custody, and registers the Nomad job. The client checks HTTP 200 and a nonempty `EvalID`. | Retain the ordinary path. Add a private stage-to-marker handoff and a qualified positive registration witness for the keyed path. [Submit and Nomad client](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/submit.go:36) · [Stage acquisition](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/staging_custody.go:451) |
| Startup and qualification | App startup wires ordinary execution roots and Nomad when configured. The installer does not pin a Nomad build. The supported-local rootful staging profile does not qualify a new private ES database or key store. | Future enablement is separately default-off, with private state, keys, and provider qualified before use. The next source slice adds no runtime construction or configuration. [App startup](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/app/app.go:72) · [Admission startup](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/service.go:185) · [Nomad installation](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/scripts/70_linux_setup.sh:528) |

I read the persistence, submission, admission, lifecycle, capability, and supported-local owner guidance alongside the committed implementation, tests, configuration, and examples. The three read-only explorers completed complementary traces of durability and custody, stage and provider behavior, and ingress and qualification. No installed host or live provider was examined. [Service boundaries](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/system_overview/boundaries.md:461) · [Admission synchronization and A3 exclusions](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/es_execution_admission_model.md:910) · [Supported Linux qualification](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/system_overview/supported_linux_host_qualification.md:117)

## Selected operating model

Select one ES installation on the governed **Ubuntu 24.04 Linux arm64 supported-local** baseline. Limit it to one authorized workload SPIFFE identity, asynchronous `static-script/default`, an immutable qualified image, and one nonperiodic, nonparameterized, single-region batch with one group and one task. No extra mounts or workload network access are selected. ES uses one unchanged local SQLite and custody domain across a restart. A same-release replacement may briefly overlap the prior process on that domain. Correctness derives from the writer and stage boundaries below. HA, mixed-version effect writers, restored or cloned state, automatic expiry, GC, key reuse, and semantic retry stay outside the model.

Propose **schema 5, codec 5, `operational_local_v1` with encoded scope 3**, and separately versioned wrapper, payload, and authentication domains. Migration 5 carries forward all prior rows, key and grant facts, and ledger entries without conversion. Old scopes continue to occupy their global caller/key pairs. Add a codec-5-only unique operational `RunRef` constraint, reserve one private random `RunRef` on assignment, and derive a disjoint safe stage and provider locator from it. A collision refuses without replacing an assigned run. Freeze provider deployment identity and job-projection version in the sealed original. Reuse the existing intent, stage, marker, receipt, and revision fields. The model needs no response-history table.

| Authority | Facts it owns |
|---|---|
| ES ingress and policy | Verified caller and exact profile authorization before lookup. One owner-approved installation policy epoch applies to cooperating instances. Changing that epoch requires withdrawal of the old effect-enabled instances and requalification. |
| ES durable submit service | Sole semantic writer of the claim, assignment, effect intent, complete-stage stamp, marker, and accepted receipt. SQLite owns their atomic visibility, uniqueness, revisions, and key/grant constraints. |
| Custody and staging | Custody authenticates the same physical original, immutable descriptor, encrypted content, and exact purpose-separated key pair. The live staging owner creates and holds the exclusive run directory, materializes captured bytes, and supplies verified content and identity to the durable service. |
| Nomad and Coordinator | Nomad supplies provider registration, evaluation, and lifecycle observations. ES decides whether a submit was accepted and persists its receipt. Coordinator owns semantic work acceptance and programme progression. |

Require an **existing exact ACTIVE original key pair** for new sealing, claim establishment, staging authorization, and the marker. The fixture helper’s register-on-missing behavior cannot be used at this boundary. A later authorized recovery of an accepted original may use the exact retained ACTIVE or RETIRED pair. Missing, revoked, mismatched, or wrong-purpose keys withhold disclosure and effect authority. No key material, provider token, raw job ID, path, or private diagnostic enters a public receipt. [Registry checks](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/replay_key_use_sqlite.go:95)

### Proposed owner text for the critical boundary

**PROPOSED, NOT IMPLEMENTED.** In persistence ADR §8, replace the operational reading of conditions **9 and 10** and the associated authorization to repair or reuse staging, **only for codec 5**. Retain conditions 1–8 and 11–12, marker-before-I/O ordering, and §15B’s fixture contract. Condition 12 must be satisfied in the exact writer turn for the next CAS.

> To decide a new first effect, acquire a checked `BEGIN IMMEDIATE` turn in the same qualified SQLite domain. Authenticate the current physical original, scope, caller/key, plan and assigned run. Check the current revision, current scoped authorization, the existing ACTIVE original pair, committed intent, and absent marker. An earlier unsettled writer either excludes this turn or has settled before its state is read. Failure to establish that state grants no authority. This decision concerns the current state and preserves every earlier invocation’s observed disposition.
>
> After a cleanly ended writer turn, only exclusive descriptor-relative creation may acquire the assigned run’s new stage. The same live owner verifies the complete captured contents and identity, commits the exact stage stamp, and keeps the descriptors. An existing stage, a durable stage stamp whose live owner is gone, a missing stage after a durable stamp, and any unsettled custody result refuse. The marker CAS recertifies the exact original, current eligibility, revision, absent marker, and complete staging proof. Staging and provider transport run outside SQLite.
>
> Only direct observed success of the first `NULL → marker` COMMIT grants the winning invocation one private, nontransferable send continuation. Its inputs are the live invocation, exact original and run, permanent marker, held stage, and prepared request. Consume it before the one synchronous transport entry. Observed cancellation, closure, denial, or failed final custody revalidation burns it. Replay, readback, exact recovery of an uncertain COMMIT, and restart never create it. Retirement or revocation ordered before the marker blocks the grant. A later change cannot instantaneously retract an already admitted or in-flight send.
>
> With a marker present, future invocations may authenticate, reconcile that exact run through positive evidence, or recover its accepted receipt. They cannot clear the marker, create another run or attempt, or send another POST. If histories have identical retained facts and identical fresh checked inputs, they receive the same eligibility. A committed marker before a crash and a lost provider response may therefore remain indistinguishable. Without sufficient positive evidence, the claim can remain ambiguous indefinitely.

This preserves K1’s distinction between current state and historical acknowledgement. A fresh writer can prove present marker absence after the prior writer settles. It cannot learn what the earlier caller observed. The irreversible marker and same-domain serialization ensure only one directly acknowledged transition can grant a sender. Exclusive staging and the live holder prevent a second caller from inheriting that transition’s execution inputs. There is no root-pair registry, lease, `flock`, or poison subsystem. [Current §8 predicate](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:419) · [Checked writer and CAS](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_store.go:1793)

The smallest alternative is to retain literal §8(9–10) and allow effects only within an uninterrupted invocation that observed every relevant write result. That freezes even unmarked pre-stage claims after restart. A durable acknowledgement journal adds another authoritative write with its own crash gap. The selected design recovers eligible pre-stage work and accepts the availability loss for stranded stages and committed markers with no send evidence.

## Staging, provider evidence, and disclosure

**Staging order:** authenticate the original → commit claim and assignment → commit intent → qualify current state and end the writer turn → exclusively create and materialize → verify contents and commit the complete stage stamp → recertify in the marker CAS → revalidate live custody → consume the sender. Integrity-checked reads of captured material are preparatory. Run-directory creation and materialization are execution-producing. Reuse the committed root and descriptor checks, and add a bounded content proof over ordered paths, type, mode, size, bytes, frozen job projection, and stage identity. A pathname, existing directory, durable stamp, or current resolver default cannot restore the live holder. Partial and completed stages remain retained on refusal. [Materialization](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/executionpackage.go:302) · [Custody revalidation](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/staging_custody.go:766)

**Provider creation:** bind one authenticated Nomad installation, explicit region and datacenter, reserved operational namespace with exclusive ES writing, and a disjoint job ID. Send one direct bounded `POST /v1/jobs` with `EnforceIndex=true` and `JobModifyIndex=0`. Refuse redirects, proxy or library resend paths, replayable bodies used for retries, and fallback. Count actual POST deliveries at the receiver. Nomad v2.0.3 at `a2a5fee9c42d6481adcb9be865bcbccf8fd4d725` supplies source evidence for the create-only check within the applied state transaction. The v1.9.0 source has an earlier snapshot check and a plain FSM upsert, so it does not establish that atomic guarantee. The current ES installer supplies no installed-version pin. Provider collision protection supplements the ES marker gate. [Register API](https://developer.hashicorp.com/nomad/api-docs/jobs#register-job) · [v2.0.3 state transaction](https://github.com/hashicorp/nomad/blob/a2a5fee9c42d6481adcb9be865bcbccf8fd4d725/nomad/state/state_store.go#L1788-L1832) · [v1.9.0 FSM](https://github.com/hashicorp/nomad/blob/7ad36851ec02f875e0814775ecf1df0229f0a615/nomad/fsm.go#L612-L631)

**Positive acceptance:** select one bounded Job GET and one bounded job Evaluations GET for the exact locator, after either direct response or response loss. Require the initial job generation with positive matching creation and job-modify indexes, an ES-keyed marker-bound correlation, the full versioned effect-bearing job projection, and a unique matching `job-register` evaluation with the selected identity and index relation. Any validated immediate response’s indexes and `EvalID` must agree. The pinned source applies job and evaluation writes separately, so an exact job alone is insufficient. Require qualified endpoint and observation provenance. Default consistency alone supplies no linearizability guarantee. Collision, 404, timeout, stale or weak read, job/eval mismatch, and missing evaluation remain ambiguous and cannot authorize another POST. Exact installed build, normalization, exclusive writing, retention, and positive-read provenance are **native prerequisites**, still unqualified. [Register response](https://github.com/hashicorp/nomad/blob/a2a5fee9c42d6481adcb9be865bcbccf8fd4d725/nomad/job_endpoint.go#L296-L370) · [Evaluation apply](https://github.com/hashicorp/nomad/blob/a2a5fee9c42d6481adcb9be865bcbccf8fd4d725/nomad/fsm.go#L795-L806) · [Nomad consistency modes](https://developer.hashicorp.com/nomad/api-docs#consistency-modes)

**Ingress and receipts:** later use the existing proposed versioned `reliable_submit` opt-in and authenticated producer negotiation. A disabled or malformed keyed request refuses without fallback. Select exactly one verified canonical workload identity and reject bootstrap, ambiguous identity, and duplicate or case-equivalent reserved fields before keyed lookup. Startup must qualify preprovisioned private state and externally provisioned distinct keys before enabling the path. Missing or replaced runtime state refuses. Disabled mode constructs no reliable dependencies. No new public field, status code, or configuration key is selected here.

A currently authorized caller with an authenticated equivalent original may recover a committed accepted receipt without rerunning mutable execution admission, current defaults, staging, or provider calls. First effect requires current admission. Pending or ambiguous before assignment exposes no run. After assignment, only a qualified equivalent caller may receive the same durable `RunRef`. Accepted requires the committed receipt. Conflict and unavailable expose no run or receipt, and unauthorized returns before lookup without revealing existence. Before using a reliable run as a public lifecycle handle, add claim-scoped authorization. The existing route-level ACL does not establish that ownership. [Outcome and replay contract](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md:1026) · [Current lifecycle routing](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/api/server.go:148)

## Crash and concurrency decisions

| Boundary | Durable input and trustworthy observation | Allowed action | Forbidden action and result |
|---|---|---|---|
| Before claim or uncertain claim write | Qualified same-key writer read finds an authentic row or qualified absence | A distinct authorized invocation can observe the winner or establish once on qualified absence | Unknown invocation makes no second write. Occupied key grants no reseal or adoption. Pending has no run. Orphans count. |
| After claim, before or during assignment | Exact physical row, current revision, assigned field under lock | One unique first-assignment CAS or retain the exact winner | No alternate run or loser disclosure. Pending has no run until durable assignment is authenticated. |
| After assignment, before or during intent | Exact durable run, current authorization and revision, no marker | Commit intent for that same run, or independently observe committed intent after restart | No staging before durable intent and a clean writer-turn end. An unknown invocation withholds projection. |
| Before staging with no stage fact | Checked current intent, qualified root, no stage fact, successful exclusive create | The winning descriptor holder may materialize captured inputs | No stage acquisition from an unguarded name. Restart may attempt first creation only when the required fact and physical checks pass. |
| Partial stage or complete stage before a known stamp | Existing path or incomplete evidence, with original live holder possibly still active | The still-qualified original holder may finish. Other callers preserve residue | No adoption, deletion, unstamped marker, or POST. Stranded work becomes unavailable and consumes capacity. |
| Complete stage with lost owner | Durable stage fact or residue, without live original descriptors | Authenticate retained material for recovery evidence | No reopen or restage for dispatch. Pre-marker availability is deliberately lost. |
| Marker dispatch or COMMIT uncertain | Unsettled writer, or checked state after settlement | Original invocation sends zero. A new invocation may evaluate fresh absence under lock, subject to its own stage eligibility | No authority from recovered marker or unlocked absence. An existing stranded stage still refuses even after confirmed rollback. |
| Known marker, then crash or cancellation before send | Permanent marker with no remaining eligible continuation | Restart reads or reconciles the same run | No synthesized sender. The run may remain ambiguous even if the receiver saw zero POSTs. |
| Provider response lost, collision, or after-send failure | Marker, exact run and locator, observed evidence or its absence | One bounded read-only reconciliation attempt per authorized invocation | No additional POST or inferred non-acceptance. Same run remains ambiguous until sufficient positive evidence. |
| Positive evidence before receipt | Exact verified job/eval evidence and qualified original | Expected-revision receipt CAS for the same run, or fresh positive evidence after a crash | No resend or durable accepted projection before the receipt is established. |
| Receipt COMMIT or caller response uncertain | Independent authenticated current receipt, or fresh positive evidence if receipt is absent | Recover the same receipt, or perform the one allowed new receipt CAS from fresh evidence | No retrospective change to the old invocation’s unknown response. No second receipt, run, or dispatch. |
| Competing request, stale holder, or overlapping replacement | Same writer domain, current CAS revision, exclusive stage owner, one-way marker | The current winner alone keeps its live right. Equivalent redelivery authenticates current state | No late callback, stale CAS, or replacement process can mint another sender. Busy or unqualified work can refuse. |

## Next source slice and acceptance

Use **one doc-first private operational handoff and restart slice**. Update `PLANS.md`, persistence ADR §§8/15B/16, submit/recovery §§6B and 7–17, and admission §7.4 before expressing the new rules in tests. Adjust the finite typed field and caller inventories if a private continuation adds a synchronization-bearing carrier. Preserve A3 exclusions and the existing API, App, config, ordinary `Submit`, and fixture boundaries.

Proposed plan status text:

> PR #11 completed exact-tree private replay-progress source integration at `ae326b0ddc30ec6b35883ee32945c622405b68b6`, tree `e066cd4afa77fcb665f31b69bf00465989f9744e`. The final audited candidate was accepted. Earlier rejection entries are historical. The synthetic codec-4 boundary remains effect-ineligible. After owner selection, the next source slice proves operational first effect and restart behavior with real SQLite and a controllable provider before ingress, startup enablement, or native provider wiring.

Then extend `docs_contract_test.go` and the typed admission guardrails. Prospectively add `sqlite_operational_submit_schema.go`, `sqlite_operational_submit_test.go`, and `operational_submit.go` under `es/admission/internal/reliablesubmit`, with narrow changes to `sqlite_migrations.go`, `sqlite_store.go`, `durable_record.go`, `durable_service.go`, and custody/key helpers. Add private `es/admission/reliable_submit_operational.go` and its tests for stage orchestration and the typed provider boundary. Add stage byte binding in `staging_custody.go` where required. Test with a finite pilot profile of four operational claim slots, 32 object names including orphans, and 32 nonrefundable reservations in the shared test domain. Native sizing must bound all shared claims, grants, objects, staging, and bytes. At capacity, classify existing keys normally and refuse new work. Expiry, refunds, and automatic reclamation remain outside the slice.

| Invariant | Prospective positive evidence | Negative control |
|---|---|---|
| Migration and scope isolation | Migrate a populated mixed schema-4 store, comparing prior rows, objects, shapes, counters, and ledger. | Old, mixed, corrupt, synthetic, and duplicate tuples produce zero operational POSTs. |
| Unique sender across requests and processes | Two actual helper processes share the same SQLite and staging domain. Exercise both winning orders and pause predecessors on either side of the lock and COMMIT. A live directly acknowledged winner delivers one POST. | A real marker COMMIT followed by an injected lost reply produces zero POSTs. A rolled-back marker plus settled writer and untouched stage allows a distinct qualifying invocation to win. Stale and canceled holders produce zero. |
| Stage authority | One real exclusive create and descriptor-held complete stage. | Partial stage, complete stage after holder loss, changed bytes, root substitution, or unsettled stamp produce zero POSTs and preserve residue. |
| One exchange | Count actual POST ingress across redelivery and reopen. The positive case delivers exactly one create-only POST. | Forced 307/308 redirect target receives zero. Before-send restart receives zero. Response loss after send stays at one total. |
| Provider evidence | Matching initial job and registration evaluation yield one same-run receipt using bounded GETs. | Foreign scope, mismatched projection, stale views, collision, exact job without eval, 404, timeout, and oversized response yield no receipt or extra POST. |
| Receipt and authorization | Real receipt COMMIT with response loss. Reopen and recover the same receipt for the qualified equivalent caller with zero resolver, stage, or provider calls. | Unauthorized input makes zero keyed lookups. Pre-marker key retirement or revocation makes zero sends. Revoked or wrong-purpose original yields no disclosure. The previous invocation stays unknown. |
| Compatibility | Existing unkeyed test still sees one ordinary Nomad registration. Structural keyed refusal, fixture isolation, docs, and A3 inventories remain covered. | No operational caller appears in API, App, producer declaration, ordinary `Submit`, or the fixture composer. |

These focused commands are **future validation only**. `TestOperational…` selectors are prospective. Existing selectors were located in the pinned source.

```sh
export GOTOOLCHAIN=local GOPROXY=off GOSUMDB=off GOWORK=off GOFLAGS=-mod=readonly CGO_ENABLED=0 GOTELEMETRY=off
GO=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go

"$GO" test -mod=readonly -count=1 -p=1 -run '^(TestReliableSubmitPersistenceAndConcurrencyADRDocsContract|TestSubmitIdempotencyCorrelationAndRecoveryDocsContract|TestPrivateReplayProgressSynchronizationInventoryDocsContract)$' .
"$GO" test -mod=readonly -count=1 -p=1 -run '^(TestOperationalSchema5PreservesPriorScopes|TestOperationalFirstDispatchOwnership|TestOperationalRestartNeverResendsMarkedClaim|TestSQLitePooledClaimReadCleanup|TestSQLiteMigrationPrecommitClosedWrapperRecovery)$' ./es/admission/internal/reliablesubmit
"$GO" test -mod=readonly -count=1 -p=1 -run '^(TestOperationalStageRefusesReattach|TestOperationalNomadCreateOnlyAndSingleExchange|TestOperationalNomadAcceptanceIdentity|TestOperationalReceiptRecovery|TestPrivateReplayProgressHasNoEffectPaths|TestExecutionSubstrateProductionHasNoA3LeaseRegistryOrPoisonDesign|TestExecutionSubstrateSynchronizedMutableStateReferenceInventoryIsExact|TestResolvedSubmitLegacyEquivalenceOneNomadRegistrationAndAuthorityRecovery)$' ./es/admission
"$GO" test -mod=readonly -count=1 -p=1 -run '^(TestWorkstreamCContractPrepareAndSubmitRemainSeparatedAtAPIBoundary|TestSubmitPublicRouteRejectsStructuralReliableBody)$' ./es/api ./es/app
```

## Remaining qualification and effects

- **Before source work:** ES persistence and admission owners must select the explicit §8 replacement, migration and scope, canonical stage/job proof, and receipt rule. The accepted fixture contract leaves these decisions open.
- **Before real effects:** ES provider and deployment owners must qualify the exact installed Nomad build, exclusive writer namespace, authenticated direct transport, positive observation provenance, stable storage domain, and installed stage-to-provider mount identity. The rootful supported-local `service-root-v1` is not evidence for the ADR’s separate `es:es` private state and keys. Reconcile that deployment seam explicitly. [State ownership constraints](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:891) · [Supported-local root profile](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/contracts.md:1519)
- **Before public enablement:** ES API and policy owners must select public receipt and error mappings, verify the canonical caller boundary, and qualify claim-scoped lifecycle authorization. The fixed policy epoch avoids promising hot cross-process revocation.
- **Pilot availability:** Unconfirmed cleanup or disposal withholds authority. Cleanup context bounds do not establish hard close latency or physical device close. Double withholding may exhaust finite pool capacity and make the service unavailable. The accepted observation-pool close-on-refusal residual returns no handle and does not by itself require a new repair campaign. Logical SQLite durability and preservation do not qualify physical sidecar bytes, restore, or rollback administration.

Opening and closing used read-only `git rev-parse`, `ls-tree`, and `cat-file`, complete clean inventories, and comparisons of all 430 working files. Official `gh api` reads bound PR #11, the squash, both refs, and the recursive tree. Official HTTPS `git ls-remote` agreed with GitHub. The framed supplied Appendix A and the private merge report, index, squash proof, and signed object authenticated. I did not rehash unrelated historical tests or caches. Command argv, working directories, exits, and digests are in the evidence index. Only the new Downloads directory and its artifacts were created.

```text
SOURCE_REPOSITORIES_NOT_MUTATED
SOURCE_REFS_NOT_UPDATED
PRODUCT_TESTS_NOT_RUN
HISTORICAL_ACCEPTANCE_NOT_REOPENED
IMPLEMENTATION_NOT_PERFORMED
STAGING_COMMIT_PUSH_PR_MUTATION_NOT_PERFORMED
EXISTING_CHECKOUTS_NOT_SYNCHRONIZED
RUNTIME_WIRING_NOT_PERFORMED
PUBLIC_RELIABLE_SUBMIT_NOT_ENABLED
OPERATIONAL_CROSS_RESTART_AUTHORITY_NOT_IMPLEMENTED_BY_THIS_TURN
NATIVE_INSTALLED_SOURCE_NOT_QUALIFIED_BY_THIS_TURN
```
<!-- END APPENDIX A EXACT PAYLOAD -->

### Appendix B — Exact governed-execution.audit-patch-manifest.v2 source

Payload bytes: 7275
SHA-256: c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca

<!-- BEGIN APPENDIX B EXACT PAYLOAD -->
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
import sys
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v2"


def fail(message: str) -> "NoReturn":
    raise SystemExit(message)


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env.update(
        {
            "LC_ALL": "C",
            "LANG": "C",
            "GIT_OPTIONAL_LOCKS": "0",
            "GIT_NO_LAZY_FETCH": "1",
            "GIT_TERMINAL_PROMPT": "0",
            "GIT_PAGER": "cat",
        }
    )
    result = subprocess.run(
        [
            "git",
            "--no-pager",
            "-c",
            "core.fsmonitor=false",
            "-c",
            "core.untrackedCache=false",
            *args,
        ],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


def validate_output_path(output_path: Path, repository_root: Path) -> None:
    if not output_path.is_absolute():
        fail("output path must be absolute")

    parent = output_path.parent
    parent_metadata = parent.lstat()
    if not stat.S_ISDIR(parent_metadata.st_mode) or stat.S_ISLNK(parent_metadata.st_mode):
        fail("output parent must be a nonsymlink directory")
    if parent_metadata.st_uid != os.getuid():
        fail("output parent must be owned by the current user")
    if stat.S_IMODE(parent_metadata.st_mode) & 0o022:
        fail("output parent must not be group- or world-writable")

    try:
        output_path.lstat()
    except FileNotFoundError:
        pass
    else:
        fail("output path already exists")

    repository_text = os.path.realpath(os.fspath(repository_root))
    output_text = os.path.realpath(os.fspath(output_path))
    try:
        common = os.path.commonpath([repository_text, output_text])
    except ValueError:
        common = ""
    if common == repository_text:
        fail("output path must be outside the repository")


def write_exclusive(output_path: Path, payload: bytes) -> None:
    flags = (
        os.O_WRONLY
        | os.O_CREAT
        | os.O_EXCL
        | getattr(os, "O_NOFOLLOW", 0)
        | getattr(os, "O_CLOEXEC", 0)
    )
    fd = os.open(os.fspath(output_path), flags, 0o600)
    try:
        view = memoryview(payload)
        while view:
            written = os.write(fd, view)
            if written <= 0:
                fail("short provenance-output write")
            view = view[written:]
        os.fsync(fd)
    finally:
        os.close(fd)

    metadata = output_path.lstat()
    if not stat.S_ISREG(metadata.st_mode) or stat.S_ISLNK(metadata.st_mode):
        fail("provenance output is not a regular nonsymlink file")
    if metadata.st_uid != os.getuid():
        fail("provenance output owner mismatch")
    if stat.S_IMODE(metadata.st_mode) != 0o600:
        fail("provenance output mode mismatch")
    if metadata.st_nlink != 1:
        fail("provenance output link-count mismatch")
    if metadata.st_size != len(payload):
        fail("provenance output size mismatch")

    read_flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_CLOEXEC", 0)
    read_fd = os.open(os.fspath(output_path), read_flags)
    try:
        observed = bytearray()
        while len(observed) <= len(payload):
            chunk = os.read(read_fd, min(1 << 20, len(payload) + 1 - len(observed)))
            if not chunk:
                break
            observed.extend(chunk)
    finally:
        os.close(read_fd)
    if bytes(observed) != payload:
        fail("provenance output byte mismatch")


if len(sys.argv) != 2:
    fail("usage: governed_execution_audit_patch_manifest_v2.py ABSOLUTE_OUTPUT_PATH")

repository_root = Path(git_text("rev-parse", "--show-toplevel"))
output_path = Path(sys.argv[1])
validate_output_path(output_path, repository_root)

head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    fail("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            fail(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()

write_exclusive(output_path, canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")

<!-- END APPENDIX B EXACT PAYLOAD -->
