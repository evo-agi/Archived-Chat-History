Here is Codex's response:

The K1 contract correction is ready for architectural review. Recovery now applies to one write invocation and its own evidence. A later, explicitly supplied fixture command can act on the authenticated current row without resolving an earlier unknown response. The operational no-dispatch requirement is unchanged.

**Exact review packet** · [ES-Private-Replay-Progress-K1-Contract.zip](/Users/ds/Repositories/ES-Private-Replay-Progress-K1-Contract-20261119-fzxf8tt8/ES-Private-Replay-Progress-K1-Contract.zip)

The ZIP is **420,293 bytes**, mode `0600`, SHA-256 `03dddf54b405e27fcdeafec2bc40165a2948d15be83a94ef5129c4d26b3c12d7`. Its ten verified entries contain the five complete source files, both patches, the canonical manifest, a README and a self-excluding inventory. Both patches independently reconstructed the exact five delivered files and their `0644` modes in private disposable copies. This is the local ZIP for upload. [Delivery receipt](/Users/ds/Repositories/ES-Private-Replay-Progress-K1-Contract-20261119-fzxf8tt8/delivery-receipt.json) · [Per-entry inventory](/Users/ds/Repositories/ES-Private-Replay-Progress-K1-Contract-20261119-fzxf8tt8/review-packet/delivery-inventory.json)

## Routing and baseline

The user-reported chat attachment and observed initial physical shell directory were both `/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1`. All edits, tests and manifest executions targeted `/Users/ds/Repositories/ES-Private-Replay-Progress-v1`. That directory is its own physical and Git top-level root, with Git and common directory both `/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.git`. A1’s HEAD, tree, status, refs, index and config fingerprints matched at opening and closeout. No remote observation was made. [Opening routing record](/Users/ds/Repositories/ES-Private-Replay-Progress-K1-Contract-20261119-fzxf8tt8/routing-opening.json) · [Closeout routing record](/Users/ds/Repositories/ES-Private-Replay-Progress-K1-Contract-20261119-fzxf8tt8/routing-closeout.json)

| Item | Verified identity |
| --- | --- |
| Branch and upstream | `codex/private-replay-progress-v1` → `origin/trunk_dev` |
| Origin | `git@github.com:evo-agi/Execution-Substrate.git` |
| Pinned PR #10 HEAD | `f1aa8b934cc26c16a966a110c7b408abdaeadce7` |
| Sole parent | `fb9ae55797d9fcc02863c23fe8d3e43d16eac542` |
| Complete tree | `8dd27f9acba98ed70d93736bdef8300ef1aba53f`, 427 leaves |
| Opening canonical manifest | `ad2e60dfb5f4377cbd4531ab9555c90ec0391b76b7c879764b18ddf5693f0491` |
| Opening full-index binary diff | `3497dab92bda92ad7b56a6eac76fa8995859106a7c1c4a67ad739bf2f80f7665` |
| Opening-to-corrected patch | `67c2cc0aad9e4accd912a3a23e765df97f90879c2149839a05bc682ecc0c0700` |
| Final `HEAD`-to-candidate full-index binary patch | `75582f2e9b91fdc0ef879c802b4e9af9b04784db48e385e024996c716f480821` |

Both opening recipe runs reproduced the supplied 1,331 canonical bytes. The five live opening files matched both Appendix B and the authenticated 419,360-byte review ZIP, SHA-256 `8d0734b788cb04e23624ee2282bba9e08153caafacfe447d2f33639601f01af9`. I checked that archive’s inventory, README, manifest, diffs and source members. Appendix A matched its 28,423-byte transport hash, `bf7adf63e242081186b22e80a9a93ac1d9602d738bf8929c44b52b9c3d7f56af`. The prior evidence used beyond the archive was the authenticated inventory and the two verifier scripts, copied into the new evidence root before execution. [Material authentication record](/Users/ds/Repositories/ES-Private-Replay-Progress-K1-Contract-20261119-fzxf8tt8/opening-material-authentication.json)

Exactly five paths changed. Each remains an unstaged regular file, disk mode `0644` and Git mode `100644`. All 422 other tracked files match the pinned bytes and modes. The index equals `HEAD`, with zero staged, unmerged, ordinary-untracked or ignored paths. [Opening checkpoint](/Users/ds/Repositories/ES-Private-Replay-Progress-K1-Contract-20261119-fzxf8tt8/k1-opening-checkpoint.json) · [Closeout checkpoint](/Users/ds/Repositories/ES-Private-Replay-Progress-K1-Contract-20261119-fzxf8tt8/k1-closeout-checkpoint.json)

## K1 decision

The reconciled draft required the first fixture marker to know the dispositions of earlier relevant writes after restart. The 47-field row retains no such response history, and the one-use borrow expires. The corrected contract limits fixture eligibility to the current row and the explicit command. It adds no ledger, caller-verified flag, registry, database or attempt. [Plan selection](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/PLANS.md:27) · [ADR scope matrix](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1616)

| Scope | Corrected guarantee |
| --- | --- |
| **One write invocation and its recovery** | Preserve known commit, evidenced not-applied/refused, or unknown. After safe connection disposition and authentication, only full expected-record equality can confirm that invocation’s own COMMIT. An advanced or different winner, missing state, or failed, canceled or corrupt recovery leaves the write unknown and withholds projection. Recovery issues no second write, replacement mutation, rebase or retry loop. Failed post-commit authentication withholds projection while preserving known commit. |
| **Later explicit fixture command** | Require fresh original authentication, a new live one-use borrow, and the caller’s exact current expected revision and mutation input. The service checks the supported codec/schema, active row, matching original and run, committed intent, absent marker/provider and exact predecessor, then rechecks the row in CAS. An existing marker is immutable and refuses a new marker command. No automatic transition from unknown to a new invocation is selected. |
| **Later authenticated fixture read** | May project current authenticated fixture state. Exact latest-operation replay describes the current descriptor. Neither changes the earlier disposition or establishes ownership of an earlier uncertain write. |
| **Operational dispatch and restart recovery** | The full operational §8 Validated No-Dispatch Evidence requirement remains in force. Before provider wiring, a separately reviewed model must identify durable ES-owned evidence or other governed authoritative input for the relevant write dispositions, or explicitly re-derive the requirement with adequate safety proof. Fixture results grant zero provider-I/O permission. |

The two restart histories make the input gap concrete. Both retain the same authenticated phase-3 row at revision 4, with the same original, run, committed intent, kind-1 observation and absent marker/provider. [Restart examples](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1528)

| History | Before restart | Eligibility after restart |
| --- | --- | --- |
| **A** | Intent and reconciliation are known committed. No marker invocation occurred. | The explicit, freshly authenticated fixture command at revision 4 may create the first stored synthetic marker. |
| **B** | On the same predecessor, the earlier marker transaction did not commit. Its response was unknown, recovery was unavailable, and cleanup was confirmed. | The same explicit command has the same eligibility and may create the first stored synthetic marker. The earlier invocation remains unknown. |

A diagnostic driver can distinguish A and B for a test, but its memory supplies no authority to the facade. The later command is counted separately. If an earlier marker actually committed, the stored marker blocks a new command. Codec-4 kind-1 `NoDispatch` records only a bounded fixture no-marker observation. [First-marker rules](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1498) · [Borrow and attempt lifetime](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md:908)

## Preserved directions and exact edit scope

| Changed file | K1 correction |
| --- | --- |
| [PLANS.md](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/PLANS.md:27) | Selects current-row fixture eligibility and the per-invocation recovery boundary. Keeps the pre-provider operational decision separate. |
| [Persistence ADR](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1498) | Aligns ops 5/7, restart histories, result and authority tables, implementation map and prospective test identities. Go owns transition semantics and per-invocation proof. SQL owns row shape, immutable fields, CAS and storage deltas. |
| [Submit contract](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md:908) | Gives a later read or command its own live borrow. Keeps the opaque establishment attempt inside its owning invocation and makes clear that it supplies no restart input. |
| [Admission classification](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/es_execution_admission_model.md:603) | Aligns fixture marker and terminal authority with the same current-row and operational boundaries. |
| [Documentation assertions](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/docs_contract_test.go:12549) | Checks the corrected scope table and five targeted mutants. Preserves current/target, legacy, authority and R1/R2/R3 assertions. |

R1 retains the immutable reconciliation tuple through later marker, provider and terminal transitions. Positive terminal evidence still binds the same original, run and marker. R2’s shared scope-1/scope-2 count/create lifecycle and budget section, R3’s exact schema-3 probe build section, the pooled-reader prerequisite, and the operational §8 predicate were verified byte-identical to the opening candidate. Section §8 also matched the pinned `HEAD` bytes. [R1 reconciliation](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1447) · [R2 allocator](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1724) · [R3 probe](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1852) · [Retained-section proof](/Users/ds/Repositories/ES-Private-Replay-Progress-K1-Contract-20261119-fzxf8tt8/retained-contract-sections.json)

Prospective tests now use `FixtureNoMarkerThenFirstMarkerAfterRestart` and `UnknownMarkerCommitDoesNotRetryWithinInvocation`. The matrix includes `IndistinguishableRestartHistoriesHaveSameFixtureEligibility`, `ExplicitLaterFixtureCommandDoesNotConfirmPriorUnknown`, `CurrentReplayDoesNotConfirmPriorUnknown` and `ExistingMarkerExactReplayOnly`. It retains stale predecessor, wrong original/run, contradictory terminal evidence, full expected-row own-COMMIT confirmation and zero-effect cases. [Prospective acceptance matrix](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1819)

Current source remains schema 3 with historical codecs 1/2 and immutable codec 3. Schema 4, codec 4 and scope 2 remain proposals. The pooled `loadClaim` repair is still the first implementation prerequisite. Public structural refusal and current unkeyed Submit remain in force.

## Documentation validation

Generation `k1-v1` passed on its first frozen run. Go reported `go1.26.5 darwin/arm64`. `gofmt -d` and `diff --check` produced no output. The Go run passed **nine parents and 13 subtests**, with zero failures or skips. Actual executable resolutions and hashes were recorded, with offline cached modules, fresh private cache/temp directories, outer umask `077` and Go test umask `027`. Each command had its own executed integrity observation. [Frozen argv and environment](/Users/ds/Repositories/ES-Private-Replay-Progress-K1-Contract-20261119-fzxf8tt8/k1-v1-validation-freeze.json) · [Go outcomes by identity](/Users/ds/Repositories/ES-Private-Replay-Progress-K1-Contract-20261119-fzxf8tt8/k1-v1-go-test-run.json)

```sh
"$GO" version
"$GOFMT" -d docs_contract_test.go
git --no-pager diff --check
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateOriginalReplayProgressContractSelection|TestReliableSubmitPersistenceAndConcurrencyADRDocsContract|TestSubmitIdempotencyCorrelationAndRecoveryDocsContract|TestReliableSubmitPureModelDocsAndSourceContract|TestReliableSubmitPublicOptInAndVersioningDocsContract|TestReliableSubmitContractAdapterFoundationDocsAndSourceContract|TestReliableSubmitBindingProducerDocsContract|TestIntegratedAcceptanceGateDocumentationIsConsistent|TestIntegratedCandidateStatusSeparatesCAndT)$' .
```

The five K1 subtests each changed one normative table statement and verified rejection at the expected row. They cover claiming the full operational predicate, resolving an earlier unknown from current replay, resolving it from marker absence, permitting automatic fresh mutation/rebase, and omitting the fixture-versus-operational permission boundary. These are bounded documentation checks. Product diagnostics, behavioral tests, migrations, old-opener builds, the full suite, native installed-source qualification, module downloads and live services were unperformed. [Mutation checks](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/docs_contract_test.go:12606)

## Canonical manifest

The exact 7,275-byte recipe `governed-execution.audit-patch-manifest.v2` matched SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`. The two final external manifests were byte-identical. Their SHA-256 is `79c3554da0dbbb5c45677092aee07093ee3b5f10d306ed656a7e9922c6c7733b`. [Manifest A](/Users/ds/Repositories/ES-Private-Replay-Progress-K1-Contract-20261119-fzxf8tt8/final-a.json) · [Manifest B](/Users/ds/Repositories/ES-Private-Replay-Progress-K1-Contract-20261119-fzxf8tt8/final-b.json)

```json
{"branch":"codex/private-replay-progress-v1","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/es_execution_admission_model.md","sha256":"323af61fa84bbbec3a699654758989918e9d1ef74d9f18d01eb4f1efbeeddcb8","size":80367},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md","sha256":"29e203e6b6dd37a2ca8f331ee9da9de45b1f7b04090d7da73008705efeb06fbc","size":155140},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md","sha256":"932ad4bbf1db53ae3f04d5e713648a6d395fcbb676097ec48f5af75aff3bd802","size":102189},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"49a1a04ca31a852a34b6899e98adb889b791aab34555545df649e11f6be22792","size":300847},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"0dea4847b311e5f0135072a7539f11c0b5e40e103923b81b4e570feb134837d8","size":791661}],"head":"f1aa8b934cc26c16a966a110c7b408abdaeadce7","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"75582f2e9b91fdc0ef879c802b4e9af9b04784db48e385e024996c716f480821","upstream":"origin/trunk_dev"}
```

```text
ES_PRIVATE_REPLAY_PROGRESS_K1_CONTRACT_CORRECTED_READY_FOR_REVIEW
PRODUCT_SOURCE_BYTES_UNCHANGED
POOLED_LOADCLAIM_DEFECT_NOT_REPAIRED_IN_THIS_TURN
LOADCLAIMFRESH_BEHAVIOR_PRESERVED
SCHEMA4_AND_CODEC4_NOT_IMPLEMENTED
CROSS_RESTART_OPERATIONAL_WRITE_UNCERTAINTY_GATE_NOT_IMPLEMENTED
INDEPENDENT_ACCEPTANCE_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PRS_NOT_MODIFIED
EXISTING_SOURCE_CHECKOUTS_NOT_SYNCHRONIZED
RUNTIME_WIRING_NOT_PERFORMED
PUBLIC_RELIABLE_SUBMIT_NOT_ENABLED
```
