# Execution Substrate — Private Original Replay + Durable Claim Progress
# Owner-contract candidate and implementation acceptance specification

## Objective and endpoint

Select one integrated source slice that joins authenticated original replay to
existing durable claim progression. Its first implementation phase will repair
the demonstrated pooled `loadClaim` cleanup defect; it will not become a
separate cleanup-only workstream by default.

THIS TURN writes only the governing documents and their documentation-contract
tests in a new standalone checkout. It must produce an exact, reviewable owner
contract and implementation/acceptance map before broad product changes.

Do not implement the reader correction, codec, migration, custody format,
durable-service extension, admission composition, or runtime path in this turn.
Do not run another characterization campaign. The preceding reconnaissance is
the evidence basis, not permission to skip exact operating-model decisions.

Successful endpoint:

    ES_PRIVATE_REPLAY_PROGRESS_OWNER_CONTRACT_READY_FOR_REVIEW

This means a proposed contract patch is ready for ChatGPT's architectural
review. It does not mean product implementation, independent acceptance, or
operational qualification. The intended continuation is product implementation
in this same candidate, followed by one fresh independent audit of the complete
integrated slice. No standalone documentation-only PR or reader-only PR is
selected here.

## Conversation and execution posture

Continue in the foreground Codex conversation that produced Appendix A,
initially rooted at:

    /Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1

Close any remaining reconnaissance subagents before mutation. The foreground
parent is the sole writer. Do not spawn writer subagents or independent auditors
in this turn. Perform all source writes and validation only in the new verified
standalone checkout below. The original conversation's starting directory does
not authorize edits to the old A1 checkout.

ChatGPT selects the architectural direction and reviews remaining semantic
choices. Codex authors the exact repository contract candidate and validates
its documentation assertions. Do not frame the user as a routine approval
service. Do not ask routine questions resolvable by the authorized inspection.

Governed Execution's core is ES plus Coordinator. This is ES-local work.
Coordinator's intended durable programme progression remains a separate
strategic responsibility; do not claim that its worker/orchestration target is
already implemented. Preserve ES admission/runtime fact ownership and Nomad's
current accepted-execution lifecycle authority. CP is bounded compatibility;
IM/MA are supplementary; Bridge is not run truth. Inspect no other repository
merely to reconfirm this split.

## Baseline and candidate checkout

Pinned published baseline:

    repository: evo-agi/Execution-Substrate
    official origin: git@github.com:evo-agi/Execution-Substrate.git
    PR #10 squash: f1aa8b934cc26c16a966a110c7b408abdaeadce7
    sole parent: fb9ae55797d9fcc02863c23fe8d3e43d16eac542
    complete tree: 8dd27f9acba98ed70d93736bdef8300ef1aba53f
    tracked leaves: 427

Preserved A1 source commit:

    fd2115ca8f44a615627adb08926896a1e052dc30

Its tree equals the squash tree, but it is not the new branch's parent.

Create only if absent:

    checkout: /Users/ds/Repositories/ES-Private-Replay-Progress-v1
    branch: codex/private-replay-progress-v1
    HEAD: f1aa8b934cc26c16a966a110c7b408abdaeadce7
    upstream: origin/trunk_dev

Authorized setup is a new independent clone/object store from the official
origin, an exact checkout of the pinned squash, and creation of the named local
branch and tracking configuration in that new clone only. Do not use a linked
worktree, alternates, shared Git administration, or fetch into an existing
checkout. Do not overwrite an existing candidate path or branch. Verify the
physical root, Git top-level and common directory before any write.

Read official trunk before setup and at closeout. If it has advanced, keep the
pinned source facts and report drift/overlap; do not rebase, silently change the
base, or mutate existing checkouts. An exact-baseline contract draft can still
be prepared, but any prospective implementation on another base needs explicit
reconciliation. Do not describe remote movement as a patch-byte mismatch.

Record the full 427-leaf opening inventory by Git path, mode, blob ID, size and
SHA-256. Use exact committed bytes. No source script or repository program is
executed merely to obtain this inventory.

## Evidence basis and limits

Read Appendix A completely. Authenticate the private duplicate and material
records actually used, not every historical evidence universe:

    root:
    /Users/ds/Repositories/ES-Post-PR10-Integration-Recon-20261118-4pz7ugvx
    report: recon-report.txt
    report SHA-256:
    c473578e8439cf4dcb79b8b42fb627cdea51c2a9a287a74b1a2d7261157629af
    self-excluding index: artifact-index.json
    index SHA-256:
    9ee2b802f36a6cee0aedea2558f2737bb9dcdf75f9d6e643d17ebbb4fbcc5be1

Material diagnostic bindings:

    pristine inventory:
    3dd848d7ce644250b6be4554d9e27319907011b1f95b759aadd06fca1bdef23b
    diagnostic freeze:
    76ca88a5048a0d33a0a0b0ecb44caf830ef519c8404d0246deac8dd0509f3b11
    instrumentation diff:
    3cb8a9f6ab61cb57a24e87c271f5117f4530b991a756ff48a8ee83cacba8ed7f
    complete diagnostic test:
    e442ad888290dd79ca21bdc408bd96a917ae83bf6298efa36437ab47b304a368
    diagnostic stdout:
    939b3c2b8c32e8b126b4b16513400b62056654a0dfbd4ef9f3c11feadbdd94e3

Preserve these distinctions:

- Pooled `loadClaim`: confirmed reachable cleanup/availability defect in the
  reported real-SQLite fixture. Same-store later reads/CAS failed and a direct
  probe observed a retained transaction. No stale successful record or unsafe
  durable mutation was demonstrated.
- `loadClaimFresh`: no defect demonstrated in the tested function-owned
  lifetime. Its normal zero-idle, function-owned pool closed; failed callbacks
  stayed refused; later work succeeded. Physical-close failure and universal
  cleanup/latency guarantees were not proved.
- Exit zero from the characterization meant its observation assertions held,
  including the defect witness. It was not a product-regression pass.
- Both readers' write-shaped COMMIT-unknown output is not evidence that the
  read wrote anything. The new pooled-reader contract must distinguish read
  failure from uncertainty of an earlier write.

No reexecution of those diagnostics is authorized in this contract turn.

## Exact writable scope — five existing files only

1. PLANS.md
2. .docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md
3. .docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md
4. .docs/execution_lifecycle/es_execution_admission_model.md
5. docs_contract_test.go

No additions, deletions, renames, type or mode changes. All production .go,
existing behavioral tests, module pins, SQL literals, schemas, scripts,
examples, API, App, configuration, staging, provider and runtime source remain
byte- and mode-identical to the pinned base. `docs_contract_test.go` is the sole
Go edit and may change only documentation-selection/status assertions and add
the new documentation-only test specified below. No test-execution harness,
behavioral substitute, broad guardrail weakening, skip, environment bypass, or
new product test seam belongs there.

`PLANS.md` must accurately record completed A1 source publication at PR #10's
squash/tree, preserve the historical selections, and select this next
source-only slice. Clearly separate currently implemented behavior from the
proposed contract. Current codec 3 remains immutable and public reliable Submit
remains refused until a later accepted implementation changes named private
surfaces. Do not present new-codec behavior as already implemented.

## Architectural direction selected for the contract candidate

### A. One existing authority domain; one original and one attempt

Use the existing ES SQLite claim authority domain, existing claim uniqueness,
existing durable service, expected-revision CAS and existing phase/effect-fact
model. Do not introduce a second database, queue, scheduler, event-sourced
history, Coordinator programme state, or alternate phase algebra.

Select a new progress-bearing claim codec 4 and append-only schema migration 4
as the proposed implementation target. They are independent version axes; do
not imply that all future schema and codec versions must match.

Select the new semantic scope name:

    synthetic_progress_nonoperational_v1

It is distinct from existing `synthetic_nonoperational_v1`, explicitly fixture
only, runtime-unwired and effect-ineligible at EVERY phase, including synthetic
accepted/receipt states. Freeze its encoded scope value and exact format
identifiers in the document candidate after checking unused values; do not
change source constants this turn.

The row retains one immutable authenticated original and mutable progress.
Keep the existing caller/key uniqueness across all codecs/scopes. Do not add
scope to that uniqueness key to make an occupied key appear available. No
replacement, claim reset, second attempt, RunRef reassignment, same-key retry
as a new claim, or automatic replay-object adoption is selected.

Admission owns typed original interpretation and PB1 verification. Custody owns
sealed bytes and key/grant checks. The existing durable service is the sole
semantic writer of progress facts; SQLite enforces its persisted constraints.
A physical writer lock is not a new semantic authority.

### B. Immutable original versus mutable progress

Supply an exhaustive field table: logical name, storage column/encoded field,
type/size/nullability, initial value, mutation rule, evidence owner, and
validation in SQL and Go.

At minimum the immutable class includes caller/key identity, original intent
and presence semantics, bound plan and complete witness, creation identity,
codec/scope, replay format/algorithm identity, original object reference,
original commitments, key IDs/fingerprints, sealed size and digest. Explain
which fields are directly stored and which are authenticated inside the sealed
original; do not fabricate an additional plaintext store.

The evolving class uses existing revision, phase, latest-operation identity,
assignment, intent, staging, dispatch, provider observation, reconciliation and
receipt semantics. RunRef is absent before assignment and immutable afterward;
receipt identity and terminal outcomes retain their existing rules. Every
successor retains the full original descriptor and codec 4. It must never fall
back to the legacy constructor's codec-2/no-replay shape.

Do not bind mutable revision, current phase, a later RunRef or receipt into an
original AEAD value that would require resealing on each transition. The
cryptographic envelope authenticates the immutable original; the persisted
progress has the separate authority of validated ES transitions and CAS. Do not
claim that AEAD authenticates arbitrary future progress.

### C. Format, crypto separation, and finite private interface

Freeze concrete payload, wrapper/header, associated-data and commitment domains;
field IDs/order, lengths, byte ordering, presence rules, strict parsing,
maximum sizes/depth/counts, version dispatch and refusal categories. Reuse the
reviewed crypto algorithms and PB1 v1 semantics; do not add crypto primitives,
new dependencies or a changed PB1 grammar.

Specify both allowed reuse and required domain separation. Cross-scope,
wrong-codec, mixed-header/payload, substituted-object, wrong-key, unknown-format
and unknown-field combinations must fail closed without fallback. Do not
silently reinterpret a codec-3 envelope as a codec-4 original.

Specify root/marker/open compatibility and object-reference grammar explicitly.
A fixture marker, fixture key set, injected caller fact or synthetic image can
never qualify operational startup. No production key loader or operational root
provisioning is selected. Preserve old codec-3 root/caller semantics; any
shared-format helper widening must be finite, documented and tested.

Specify a finite private interface connecting admission, custody and the
existing durable service. Enumerate prospective types/methods, inputs, outputs,
authentication before disclosure, redaction and cancellation. No raw plaintext,
raw store or full-record getter, arbitrary verified boolean, public route,
configuration switch, or effect-eligible handle is selected. Code exported
only across Go's internal import boundary is not a public service API; record
its exact consumers.

Keep current key lifecycle, fingerprint/purpose uniqueness, reservation budget,
known-COMMIT one-use permit and no-refund behavior. Migration or new scope must
not reset counts, duplicate allowances, resurrect permits or replenish sealed
object capacity. State whether a retired original can verify a given private
operation; a verified fixture transition never supplies current first-effect
eligibility. No instantaneous cross-process revocation claim is added.

### D. Replay, exact attempts, and concurrent progress

Existing caller/key lookup precedes current resolution, defaults, material
acquisition, active-key choice and new Seal. Same original can replay after
progress and restart; changed original is a conflict with no prior RunRef or
receipt disclosure.

An occupied incompatible scope is not absence. New-codec lookup must refuse
without replacement, upgrade, resealing or switching identities. The old
codec-3 reader retains its documented behavior for old claims.

Freeze a result table for current replay, exact latest-operation replay,
changed-input conflict, stale revision, equivalent concurrent winner, advanced
winner, missing/unsupported/corrupt record, read unavailability, known write
COMMIT and write COMMIT uncertainty. A matching caller/key or equivalent
original is NOT proof that this particular mutation committed. Exact own-commit
confirmation requires the full expected record, including codec/scope,
immutable descriptor, revision, latest-operation binding and all progress facts.

Preserve an unresolved write outcome when its recovery read fails. Normalizing
a read-COMMIT error to read unavailable must not turn the earlier write into
known failure, known success, or authority to repeat an effect. Preserve
latest-operation-only guarantees: no unselected history-wide proof of an older
mutation once another mutation has advanced the record.

Define how an authenticated original observation is correlated with a later
progress snapshot and mutation. Immutable original identity must still match;
expected revision/CAS protects changing progress. Do not pass an unbound or
stale 'verified' result into an arbitrary other row. Define concurrency tests
for advancement between original authentication and progress read/CAS.

### E. Migration and compatibility matrix

Do not edit migration 1, 2 or 3 source literals/hashes. Append migration 4.
Provide a complete proposed schema object/constraint manifest and preservation
algorithm, including rowid and every inherited projection, foreign keys,
indexes, triggers, key/grant rows and counts. Do not prescribe unexamined ALTER
semantics: derive the exact table-copy/rebuild and verification strategy needed
for widened CHECKs and triggers.

Selected compatibility decisions:

- Authentic codec-1/2 historical rows retain existing load and permitted CAS
  semantics; no new codec-1/2 insertion is enabled.
- Codec 3 remains insert-only in its exact existing synthetic initial shape and
  permanently non-progressing. Its existing private constructor remains usable
  in the migrated store unless a material incompatibility is surfaced for owner
  review. No 3-to-4 promotion, mutation or claim/key reclamation is allowed.
- Codec 4 admits only a fully authenticated original in its initial shape and
  only the existing model's authorized successors. Its immutable fields remain
  fixed under INSERT/UPDATE/DELETE/REPLACE and conflict attempts.
- Unknown codec/scope/version combinations fail closed.
- All codecs share caller/key occupation; no cross-scope escape is introduced.
- No automatic downgrade, destructive repair, backfill, resealing, key rotation,
  expiry/GC, backup/restore, production promotion or adopted object is selected.

Enumerate permitted upgrade starting schemas (0/1/2/3), atomicity, rollback,
lost-response/nonmigrating recovery, and old-versus-new classification. A
migration failure cannot authorize a claim, grant, retry or effect. Logical
preservation proof must compare complete old records/key state/counts, not
just row counts.

Define retention/expiry/tombstone behavior for codec 4 explicitly. Preserve
legacy retention behavior, but select no wall-clock automatic expiry, GC or key
reuse for the new fixture scope. If a manual model transition is included,
spell its no-reuse and original-retention semantics; do not silently expose it
because the legacy enum exists.

Important compatibility evidence: the older PB1/schema-2 probe does NOT prove
that the current schema-3 binary refuses schema 4. Plan a distinct baseline
schema-3 probe built later from exact `f1aa8b...`/tree `8dd27f...` source plus a
bound test-only harness. No build occurs in this turn. Preserve the existing
historical PB1 probe and its original test purpose; do not relabel it or rebuild
it from future schema-4 source. State any source-path reproducibility limit.

### F. Pooled-reader prerequisite within this slice

Specify `loadClaim`-local cleanup before the new durable-service consumer is
implemented. Use A1-equivalent observed boundaries, not a global shared-helper
rewrite:

- distinguish invalid input, acquisition/pre-dispatch cancellation,
  BEGIN-dispatched uncertainty, known transaction, COMMIT attempted and known
  transaction end;
- establish release/cleanup ownership before dispatch;
- keep semantic BEGIN/SELECT/COMMIT on the caller context;
- after known BEGIN and before COMMIT attempt, use a private request-independent
  five-second rollback context;
- observe both the rollback response and cleanupCtx.Err() immediately after
  response and BEFORE self-cancel; release the cancel function;
- failed/observed-expired/unconfirmed cleanup overrides the result with a zero
  record and fixed read unavailable, then disposes the exact connection;
- uncertain BEGIN or read COMMIT disposes the exact connection before ordinary
  pool return; no post-attempt rollback or semantic read retry is selected;
- no read-level write-COMMIT-unknown claim; cancellation observed before success
  cannot be erased by successful cleanup;
- successful cleanup preserves safe ordinary outcomes such as not-found or
  corrupt classification according to an explicit precedence table;
- preserve the bounded A1 rescue/withholding limitations without introducing a
  store-wide poison registry, retry loop, background disposer or whole-store
  close/reopen.

This is a later implementation prerequisite, NOT implemented in this document
turn. Do not modify `loadClaimFresh`, its function-owned pool, current codec-3
callers, shared rollback/COMMIT/error mapping, or completed A1/O2/C1/D1 behavior
by analogy. Record the fresh reader's future operational qualification and
read-error normalization separately. Any new use of that fresh reader requires
an explicit consumer contract; do not quietly extend its role.

### G. Fixture scope and authority ceiling

The new source slice can exercise the existing model's phases and observations
with typed fixture facts, including accepted/receipt projections, but never
create staging directories, send a provider request, invoke a runtime, or claim
actual provider acceptance. Synthetic progress, RunRef and receipt values stay
unambiguously fixture-scoped and cannot be consumed as operational authority.

Freeze static and behavioral no-effect guards. Public structural reliable
request refusal and unkeyed Submit stay unchanged. Authentication-before-
existence-disclosure, conflict privacy, and existing CP compatibility stay
unchanged. No call into App startup, HTTP, live keys, staging, Nomad/Docker,
Coordinator or publication machinery is reachable from the new composer.

Later ingress/operational state/key choices, exact authenticated SPIFFE
selection, public responses, current first-effect admission, creation-only
provider registration and correlated recovery remain later decisions. The
reconnaissance's proposed config key, host/profile, HTTP vocabulary and accepted
receipt recovery policy are proposals, not enacted contracts here.

## Required contract deliverables

Put authoritative semantics in the existing owning documents, cross-reference
rather than duplicate divergent tables, and expose the following completely in
the final report:

1. Current versus selected target and the exact immutable/mutable field table.
2. Complete codec/schema/scope/payload/header/AAD/version compatibility matrix.
3. Finite private interface and exact provenance/authority checks at each call.
4. Migration preservation algorithm, constraint manifest and uncertain-outcome
   recovery table; identify any still-unsettled physical wording honestly.
5. Transition/replay/concurrency/error-precedence tables, including read failure
   during prior write-uncertainty classification.
6. Pooled-reader local exit/cleanup table and the explicit fresh-reader exclusion.
7. Acceptance matrix and complete prospective source/test/migration path map.

Do not leave required source-slice choices as 'TBD during coding'. Mechanically
select exact encodings from the constraints and existing grammar, then report
them for review. If a substantive contradiction cannot be resolved without
changing this selected direction, return the precise conflict and safe completed
draft sections; do not implement around it or invent hidden authority.

## Prospective implementation phases and path map

The following is a future implementation order, NOT code-write authority now:

    0. Reviewed owner contract and acceptance map
    1. Local pooled loadClaim repair + bound real-SQLite regression
    2. Codec/scope/schema/format and migration preservation
    3. Durable successors and finite private admission/custody composition
    4. Integrated restart/concurrency/unknown-outcome/no-effect validation
    5. Fresh independent audit of the complete candidate

No phase is automatically a separate commit or PR. Keep one integrated
acceptance target unless a later concrete evidence/dependency conflict justifies
changing the split. Do not automatically harden every residual SQLite helper.

Start the prospective inventory with the paths listed by Appendix A, then
actually inspect all affected validators, codecs, hydration, SQL shape/migration
checks, conformance tests, deliberate-corruption fixtures, old-binary tests,
static inventories and source guards. Specifically find numeric assumptions
that currently use codec/schema 4 as an invalid future value. Do not defer these
known migration blast-radius decisions to successive scope-widening stops.

Give each prospective path its owner, reason, edit class, preserved invariants
and validating tests. Identify missing paths or unnecessary paths in Appendix
A's recommendation. This list is an implementation proposal, not permission to
edit it now. No 'related tests as needed' wildcard.

## Acceptance specification to freeze

Define exact test names/fixtures/assertions and prospective commands. Preserve
existing good evidence and require at least:

- new pooled-reader real-BEGIN/real-SELECT cancellation regressions, ambiguous
  BEGIN/COMMIT, rollback error, actual expiry with nil response, timely control,
  zero result on unconfirmed cleanup, and fresh-context same-store reads/CAS
  before teardown; compare identical test bytes against old and new reader;
- no fault-hook leakage into healthy follow-ups; no process-wide FD-count oracle;
- original replay under changed defaults/material/active-key selection, changed
  intent conflict, wrong-scope occupied key and concurrent initial winner;
- immutable full original/descriptor through every legal successor and failure,
  stable assigned RunRef, phase/effect ordering and receipt rules;
- concurrent revision changes between authentication and progress/CAS, stale
  operation replay, same mutation with changed payload and old-operation limits;
- restart using reopened real SQLite and sealed files, exact own-COMMIT versus
  equivalent/advanced winner and unresolved recovery reads without duplicate
  mutation or permission for an effect;
- authentic migration from earlier schemas with full old row/key/grant equality,
  preserved migration hashes, codec-3 immutability, forbidden downgrade/REPLACE,
  and pre-migration schema-3 binary refusal of schema 4 without logical mutation;
- domain-separation vectors and parser corruption tests independently derived
  from the published encoding, not only round trips through the same encoder;
- static and behavioral absence of production callers/effect paths, authentic
  public-refusal regression and unchanged unkeyed compatibility.

Preserve existing O2, A1/F1, C1/D1 and key/permit/file privacy protections. State
which future focused, internal-package, admission, API/App refusal and full-tree
commands will run and why. Do not freeze the old 4,970 pass count as a new count;
require accounted-for new identities and explained skip changes instead.

This turn validates only the changed owner documents and documentation tests.

## Documentation tests and validation for this turn

Update only relevant existing documentation status/selection anchors, and add:

    TestPrivateOriginalReplayProgressContractSelection

The test must assert the owner-selection tables, compatibility/nonclaims,
immutable-original/mutable-progress distinction and explicit prerequisite. It
must not pretend codec 4 or schema 4 exists in production, construct a mock
implementation, or remove the source's existing codec-3/public-refusal guards.
A passing documentation test is evidence of the contract candidate's consistency,
not correctness of the future product.

Use the pinned local Go 1.26.5 toolchain and existing cached modules:

    GO=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go
    GOFMT=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/gofmt
    GOTOOLCHAIN=local
    GOPROXY=off
    GOSUMDB=off
    GOWORK=off
    GOFLAGS=-mod=readonly
    CGO_ENABLED=0
    GOTELEMETRY=off
    GOMODCACHE=/Users/ds/go/pkg/mod
    GIT_OPTIONAL_LOCKS=0
    GIT_NO_LAZY_FETCH=1
    GIT_TERMINAL_PROMPT=0

Use private external GOCACHE/GOTMPDIR/TMPDIR; outer umask 077 and Go-test umask
027. Retain the known-good Python 3.13/OpenSSL 3 PATH when available, record
actual executable resolutions, and do not install or download dependencies.
No TLS/Docker/native-host capability campaign is needed for the selected doc
checks. No old PB1 binary is required by the selected root-doc selectors.

Engineering iterations within the five-file scope are permitted and recorded.
Before final validation freeze the candidate, exact argv and safe environment.
Then run serially from the new checkout:

```sh
"$GO" version
"$GOFMT" -d docs_contract_test.go
git --no-pager diff --check
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateOriginalReplayProgressContractSelection|TestReliableSubmitPersistenceAndConcurrencyADRDocsContract|TestSubmitIdempotencyCorrelationAndRecoveryDocsContract|TestReliableSubmitPureModelDocsAndSourceContract|TestReliableSubmitPublicOptInAndVersioningDocsContract|TestReliableSubmitContractAdapterFoundationDocsAndSourceContract|TestReliableSubmitBindingProducerDocsContract|TestIntegratedAcceptanceGateDocumentationIsConsistent|TestIntegratedCandidateStatusSeparatesCAndT)$' .
```

Statically confirm all selected test parents exist and then verify every parent
actually runs. No zero-selected-test pass. Record passes/failures/skips by
identity; a doc selector must not acquire a capability skip to become green.
Do not run `./...`, the two-reader diagnostic, historical socket matrices, a
PB1 rebuild, scripts, live services or public endpoints in this turn.

Immediately after each final command, record an executed integrity checkpoint:
unchanged HEAD/branch/upstream and index; only the authorized unstaged paths;
all 422 other tracked files equal the base; and both inventories below empty:

    git ls-files --others --exclude-standard -z
    git ls-files --others --ignored --exclude-standard -z

Identical deterministic checkpoint bytes are permitted; bind each observation
to its own run record rather than asserting a repeated hash proves execution.
Failure after the freeze remains a retained result. Any corrected final run
must declare its new candidate/environment version; no failed result is erased.

## Evidence, provenance and closeout

Create one unique private external evidence root, for example:

    /Users/ds/Repositories/ES-Private-Replay-Progress-Contract-20261118-<unique>

Use nonsymlink current-user-owned 0700 directories and regular 0600 retained
reports/logs. Do not chmod parent repositories or old evidence. Avoid executing
or importing a verifier in its historical directory: authenticate and copy it
into the new root first. Use PYTHONDONTWRITEBYTECODE=1, python3 -B, and
sys.dont_write_bytecode=True. Content/identity, not volatile timestamps, governs
continuity. Do not dump ambient environment, live databases, secrets or raw key
material.

Appendix B is the complete exact v2 recipe. Inspect and extract its exact bytes;
do not use a digest-only substitute or a newly invented canonical schema.
After transient cleanup, run it twice to absent absolute paths outside the repo:

    python3 -B <task-owned-exact-v2-recipe> <private-root>/manifest-a.json
    python3 -B <task-owned-exact-v2-recipe> <private-root>/manifest-b.json

Require byte identity. Include the complete safe canonical manifest JSON,
tracked-diff SHA-256, recipe ID/source hash, exact touched paths and modes, and
validation outcomes in the handoff. Bind every current changed file and confirm
all product bytes remain base-identical. Keep the new candidate unstaged and
uncommitted.

The final human-readable report must be complete inline and carry:

- exact source/branch/evidence identities, touched files and validation commands;
- selected design and complete required tables, with path/line citations;
- current/target distinctions and every unsettled decision or contradiction;
- the two readers' distinct dispositions and limits;
- exact future implementation phases, path map and acceptance requirements;
- migration/codec/scope/domain decisions and old-binary evidence treatment;
- no-effect boundaries, skipped validation and retained historical limitations;
- source preservation and all effect statuses.

A private duplicate may supplement, not replace, the inline report. If safe
report transport cannot be decision-complete, use REPORT_INLINE_BLOCKED rather
than a readiness verdict. Do not stage, commit, push, create/modify PRs, alter
checks, resolve reviews, merge, deploy, enable runtime wiring or public Submit.

Stop before prohibited widening; explain the precise unresolved semantic or
scope conflict without undoing legitimate unrelated work. New runtime/config,
provider, cross-repo authority, migration execution, or broad product writes
are never implicit permissions from this contract draft.

End a successful report with:

    ES_PRIVATE_REPLAY_PROGRESS_OWNER_CONTRACT_READY_FOR_REVIEW
    POOLED_LOADCLAIM_DEFECT_NOT_REPAIRED_IN_THIS_TURN
    LOADCLAIMFRESH_BEHAVIOR_PRESERVED
    SCHEMA4_AND_CODEC4_NOT_IMPLEMENTED
    PRODUCT_SOURCE_BYTES_UNCHANGED
    INDEPENDENT_ACCEPTANCE_NOT_PERFORMED
    STAGING_NOT_PERFORMED
    COMMIT_NOT_PERFORMED
    PUSH_NOT_PERFORMED
    PRS_NOT_MODIFIED
    EXISTING_SOURCE_CHECKOUTS_NOT_SYNCHRONIZED
    RUNTIME_WIRING_NOT_PERFORMED
    PUBLIC_RELIABLE_SUBMIT_NOT_ENABLED

---

## Appendix A — Complete supplied reconnaissance

The exact uploaded transport bytes are bound below. Their private duplicate
has the separate report hash given above; transport rendition differences must
not be confused with different source facts.

APPENDIX_A_BYTES=30130
APPENDIX_A_SHA256=48690bf07ef258752fda89213d0f888df2233f1f419fa11992058f29e8526bfb

<BEGIN_EXACT_RECON_REPORT>
# Post-PR #10 reliable-submit integration reconnaissance

**Recommendation: select private original replay custody with durable claim progress as the next source slice.** Prove that ES can preserve one authenticated original, assign one stable `RunRef`, and advance the existing durable claim through revision CAS across restart and uncertain commits. Keep the composition runtime-unwired. Fix the pooled `loadClaim` defect as the first prerequisite within this slice, because the proposed composition would use the durable service’s pooled reads.

The two claim readers warrant different dispositions. The pooled reader demonstrably returned a driver connection with an open transaction to its long-lived pool. The fresh reader closed its function-owned pool, refused the affected callbacks, and allowed later legitimate work in every tested case.

## Pinned source and evidence

| Published source | Squash | Complete tree |
| --- | --- | --- |
| PR #8, private synthetic replay custody | `2478a24a18852f1abd7d474c0525c46bd2c05e5e` | `e7defd3a0df278ad70762f17f0f2a5b1c14a795b` |
| PR #9, O2 historical CAS cleanup | `fb9ae55797d9fcc02863c23fe8d3e43d16eac542` | `be8437c8ce48cbcbed53f60a03810283abbd9235` |
| PR #10, A1 original-key read cleanup including F1 | `f1aa8b934cc26c16a966a110c7b408abdaeadce7` | `8dd27f9acba98ed70d93736bdef8300ef1aba53f` |

PR #10 is closed and merged, with PR #9’s squash as its sole parent. Official `trunk_dev` matched the PR #10 squash at opening and closeout. The preserved local and remote topic stayed at `fd2115ca8f44a615627adb08926896a1e052dc30`, on `codex/reliable-submit-original-key-read-cleanup-v1`, tracking its same-topic origin ref. Local `origin/trunk_dev` stayed at the old parent. I independently matched the complete remote tree to the local committed blobs, index, and all 427 working files and modes. Seven leaves differ from the parent and 420 match. All five local hygiene inventories stayed empty. [Opening remote proof](/Users/ds/Repositories/ES-Post-PR10-Integration-Recon-20261118-4pz7ugvx/opening-remote.json) · [Closing remote proof](/Users/ds/Repositories/ES-Post-PR10-Integration-Recon-20261118-4pz7ugvx/closeout-remote.json) · [Closing local proof](/Users/ds/Repositories/ES-Post-PR10-Integration-Recon-20261118-4pz7ugvx/closeout-local.json)

I authenticated the 14,690-byte transport closeout at `9b3cc894ec73b1a7163efb14bcc1fd9df0210dff995ee844db38812ef2e2a8fd`, the private merge report at `005982497903cbd72bcc59c035ab8e31cd26998585883f67d378674857864b67`, and its index at `f543b8e36cd538863e7f8223f6dbaed9ef0c4b9a71a385ede92eba773a8603a5`. The renditions agree on merge and source facts. I rechecked the indexed source, merge response, and retained validation records used for this recommendation. Both read-only explorers finished before the diagnostic run. Their conclusions agreed on the composition gap and the importance of separating the read lifetimes. [Material authentication](/Users/ds/Repositories/ES-Post-PR10-Integration-Recon-20261118-4pz7ugvx/input-authentication.json)

Inspection covered the governing plan and owner contracts, admission and replay, the SQLite schema and durable service, HTTP authentication and refusal, App startup and config, the local ES example, the Submit and lifecycle scripts, and the supported-local consumer runbook. The current Submit script treats HTTP `202` as unkeyed acceptance, so it cannot serve as a keyed pending or receipt client. I left other repositories, broad deployment scripts, operation of the live stack, earlier experimental evidence universes, and organization integrations outside this reconnaissance. No scripts were executed. [Current Submit script](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1/scripts/40_submit.sh:53) · [Local example config](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1/.examples/config/es.json:70)

## Integration dependency map

ES owns admission, submission correlation, and the handoff facts it records. Nomad owns accepted execution lifecycle. Coordinator owns durable programme progression separately. CP is a compatibility consumer, IM and MA are supplementary, and Bridge supplies no run truth. [Authority contract](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1/.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md:222) · [System boundaries](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1/.docs/system_overview/boundaries.md:82)

| Stage | Implemented behavior and controlling boundary | Dependency |
| --- | --- | --- |
| Trusted caller and submit key | ES authorizes a verified peer, refuses the bootstrap issuer, checks path prefixes, then strictly decodes `PrepareRequest`. The public path refuses structural reliable requests. The private parser and caller-scoped safe-reference derivation exist. Authentication before existence disclosure is a **Current invariant**. [API authorization](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1/es/api/server.go:249) · [Identity derivation](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1/es/admission/reliable_submit_identity.go:24) | Before runtime, select one exact canonical SPIFFE URI from the verified peer and preserve the versioned structural opt-in. Use injected caller facts only for the next source slice. |
| Original lookup and intent conflict | The private **Bounded slice rule** looks up caller/key before current resolution or active-key selection, authenticates the winner’s original, and compares canonical intent and field presence. [Private composer](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1/es/admission/reliable_submit_replay_private.go:138) | Next source slice preserves that ordering as the winner acquires progress. Changed intent yields conflict without exposing the existing run or receipt. |
| First resolution and bound plan | Admission owns one resolved plan and captured material snapshot. The private composer calls the actual resolver and PB1, with synthetic image and placement and an effect-ineligible result. [Resolver](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1/es/admission/resolved_execution_plan.go:429) · [PB1 composition](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1/es/admission/reliable_submit_replay_private.go:207) | Preserve the complete witness in the next slice. Prove real image digest, profile, material and host binding before runtime. |
| Original input and keys | Codec 3 seals the original before claim insertion. SQLite owns key purpose, fingerprint, lifecycle and one-use grant accounting. ES custody owns the immutable file. This is a synthetic **Bounded slice rule**. [Sealed publication](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1/es/admission/internal/reliablesubmit/replay_custody_file.go:399) · [Claim establishment](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1/es/admission/internal/reliablesubmit/replay_custody_file.go:608) | Next source slice freezes a distinct progress-bearing format and immutable descriptor. Operational root, keys, retention and restore are later owner decisions. |
| Durable claim and exact attempt | SQLite owns caller/key uniqueness and revision CAS. Codec 3 deliberately admits only the initial synthetic claim and forbids updates. Codec 1/2 retain historical transitions. The successor constructor emits codec 2 and drops the replay descriptor, and the durable service refuses codec 3. [SQLite guards](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1/es/admission/internal/reliablesubmit/sqlite_replay_schema.go:207) · [Record constructor](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1/es/admission/internal/reliablesubmit/durable_record.go:506) · [Service validation](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1/es/admission/internal/reliablesubmit/durable_service.go:661) | This is the next-source composition gap. Add a versioned row that preserves the original through successors, and retain full expected-record equality for exact own-commit confirmation. |
| `RunRef`, intent and progress | The private durable model already covers assignment, intent, staging, dispatch, observation, reconciliation, receipt and latest-operation replay. Immutable assignment, intent before staging, and a committed dispatch marker before provider I/O are controlling invariants. [Durable operations](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1/es/admission/internal/reliablesubmit/durable_service.go:190) · [Effect ordering](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:419) | Exercise legal transitions with fixture facts in the next slice. Prove actual boundary ordering before runtime. |
| Staging and handoff | Current unkeyed Submit creates a locator, claims and materializes staging, revalidates custody, then registers the Nomad job. Legacy unkeyed Submit remains supported. CP, scripts and examples remain compatibility consumers. [Unkeyed Submit](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1/es/admission/submit.go:36) | Before keyed runtime, recover the persisted run and qualify staging ownership and provider handoff. An existing stage cannot be adopted by inference. |
| Ambiguous provider response | Current registration sends `/v1/jobs` and checks HTTP `200` plus EvalID. ES has a Nomad job lookup for lifecycle, while reliable acceptance reconciliation remains a **Reopened redesign seam**. [Registration](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1/es/admission/submit.go:257) · [Lifecycle lookup](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1/es/admission/lifecycle.go:272) | Before runtime, prove creation-only registration and positive correlation to the exact assigned attempt. Absence, mismatch, and transport uncertainty after possible send retain pending or ambiguous state. |
| Receipt and recovery | Transport-neutral outcomes already distinguish phase-specific run and receipt disclosure. Public reliable response vocabulary stays open. Current unkeyed status, logs, result and cancel keep their existing authority. [Outcome contract](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1/.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md:850) | Freeze the opt-in response and recovery contract before runtime. Native installed-source, host, and provider evidence belong to the later operational gate. |

## Claim-read characterization

### `loadClaim` — `CONFIRMED_REACHABLE_CLEANUP_OR_AVAILABILITY_DEFECT`

`loadClaim` borrows from the long-lived `s.db`, installs ordinary connection close before raw read BEGIN, and installs rollback only after a nil BEGIN response. That rollback uses the caller context and ignores its result. The existing durable service reaches this reader for exact replay, mutation pre-read, and write-COMMIT-unknown reload. The defect therefore matters before connecting progress-bearing original claims to that service. [Pooled reader](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1/es/admission/internal/reliablesubmit/sqlite_store.go:260) · [Shared cleanup](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1/es/admission/internal/reliablesubmit/sqlite_store.go:911) · [Mutation pre-read](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1/es/admission/internal/reliablesubmit/durable_service.go:543) · [Unknown-outcome reload](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1/es/admission/internal/reliablesubmit/durable_service.go:726)

The diagnostic used an authentic schema-2 claim migrated into the current schema and the existing one-connection fixture. After real BEGIN cancellation, real hydrated SELECT cancellation, and the separately modeled late BEGIN error, a legitimate fresh-context read on the same store refused. A supported `Raw` identity observation and direct BEGIN probe then demonstrated a nested-transaction error on the same driver. A later legitimate CAS refused without applying or classifying success. An independently guarded full-record comparison found no durable change. The ordinary and pre-canceled controls allowed later same-store reads. The demonstrated consequence is loss of usable pool capacity and same-store availability in this fixture. The test observed no stale record returned as success. [Migrated fixture](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1/es/admission/internal/reliablesubmit/sqlite_store_test.go:1058) · [Diagnostic test](/Users/ds/Repositories/ES-Post-PR10-Integration-Recon-20261118-4pz7ugvx/diagnostic-v1/source/es/admission/internal/reliablesubmit/post_pr10_claim_read_diagnostic_test.go)

### `loadClaimFresh` — `NO_DEFECT_DEMONSTRATED_IN_TESTED_LIFETIME`

The reader opens an independent one-connection pool with zero idle capacity, verifies the current schema without migrating, and owns both connection and pool closure inside the function. `LoadSyntheticClaim` uses it for lookup and key discovery. `WithAuthenticatedClaim` uses it again before A1 key verification, object authentication, and the callback. The dynamic fault was applied to the latter caller. Subsequent legitimate work exercised both callers. [Independent reader](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1/es/admission/internal/reliablesubmit/sqlite_store.go:285) · [Discovery caller](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1/es/admission/internal/reliablesubmit/replay_custody_file.go:334) · [Callback caller](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1/es/admission/internal/reliablesubmit/replay_custody_file.go:640)

In all five cases the captured function-owned pool was closed and had zero open connections by return. The ordinary case invoked one authenticated callback, and the four failed cases invoked zero. The full claim, guarded logical facts, and sealed bytes matched their pre-call values. Fresh discovery and authenticated access then succeeded on the same live custody instance before teardown. This exercises normal function-owned closure. Physical close failure, close duration, and every possible late-response ordering remain outside the test.

| Case | Pooled target result | Fresh target result |
| --- | --- | --- |
| Ordinary | Success and healthy follow-up | Success, one callback |
| Pre-canceled | Internal persistence failure and healthy follow-up | Temporary unavailable, zero callbacks |
| Canceled after real BEGIN | Internal persistence failure and retained transaction | Internal persistence failure, zero callbacks |
| Canceled after real SELECT | Commit-outcome-unknown sentinel and retained transaction | Commit-outcome-unknown sentinel, zero callbacks |
| Modeled error after real BEGIN | Temporary unavailable and retained transaction | Temporary unavailable, zero callbacks |

Both readers can emit the shared **write-shaped** commit-unknown sentinel after a read COMMIT failure. That result supplies no write-outcome evidence. Preserve the current fresh caller and lifetime in the recommended slice. Before the fresh reader takes on an operational recovery role, explicitly qualify its cleanup and latency boundary and normalize uncertainty as read unavailable at that boundary.

### Executed diagnostic

The sole test command ran once in the frozen external copy. The copy had 428 files, consisting of the 427 committed inputs with observation-only changes in `sqlite_store.go` and one added diagnostic test. The pristine copy came from committed blobs. The overlay retained the original SQL and cleanup ordering, and the late BEGIN error was explicitly modeled after real BEGIN. Hooks cleared immediately after each target and in unconditional cleanup.

```sh
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=180s \
  -run '^(TestPostPR10PooledClaimReadDiagnostic|TestPostPR10FreshClaimReadDiagnostic)$' \
  ./es/admission/internal/reliablesubmit
```

Exit `0` means the observation assertions held, including the pooled defect witnesses. Both parents and all ten cases ran, with zero failures, skips, or malformed events. The pinned toolchain and cached modules ran offline, with umasks `077` for evidence and `027` for the test child. There was no diagnostic retry, setup failure, dependency download, or live service. Immediate verification matched the checkout and both complete external inventories, and the task-owned transient cache and temp storage were removed. Full-suite replay, PB1 rebuild, physical-close injection, socket calibration, Docker/Nomad probes, and native installed-source validation were outside this run. [Frozen command and environment](/Users/ds/Repositories/ES-Post-PR10-Integration-Recon-20261118-4pz7ugvx/diagnostic-v1/freeze.json) · [Instrumentation diff](/Users/ds/Repositories/ES-Post-PR10-Integration-Recon-20261118-4pz7ugvx/diagnostic-v1/instrumentation.diff) · [Run and immediate guards](/Users/ds/Repositories/ES-Post-PR10-Integration-Recon-20261118-4pz7ugvx/diagnostic-v1/run.json)

## Recommended source slice

Use **one existing ES SQLite authority domain**. Keep the authenticated caller/key, canonical original intent and presence, bound plan, witness, and sealed original descriptor immutable on the claim. Advance revision, phase, `RunRef`, intent, staging, dispatch, observation, reconciliation, latest-operation descriptor, and receipt through the existing durable service and CAS. ES admission owns original interpretation, ES custody owns sealed bytes and key/grant checks, and the durable service owns the narrow progress record. Fixture observations can exercise the model. Runtime authority must come from separately qualified callers and effect paths.

Propose an **append-only schema migration 4 and a distinct progress-bearing row codec and replay scope**. Freeze the exact format, associated-data domain, successor invariants, and compatibility matrix in the owner docs before implementation. Retain migration 1–3 literals and hashes, row IDs, legacy projections, and historical codec-1/2 load and permitted CAS behavior. Keep codec 3 immutable and synthetic. Older binaries and unknown or wrong-scope rows fail closed. An occupied key in an incompatible scope remains occupied. A verified current winner supports current replay; exact own-commit confirmation still requires full expected-record equality. Fixture roots, caller facts, key material, and image facts must never qualify for operational startup.

Order the pooled reader correction **before** the new consumer within that same slice. Use A1-equivalent observed boundaries for read BEGIN, bounded pre-COMMIT rollback, and uncertain read COMMIT. Unconfirmed cleanup prevents ordinary pool return and yields fixed read unavailable, with exact disposal and bounded rescue/withholding as selected. Preserve safe ordinary outcomes and existing write transition semantics. Leave the fresh historical behavior and current codec-3 caller bodies in place. The reproduced pooled defect can block the proposed integration; a standalone cleanup tranche would leave that integration’s format and authority gap open.

**Exact prospective scope for owner review**

- **Docs and assertions:** `PLANS.md`, `.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md`, `.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md`, `.docs/execution_lifecycle/es_execution_admission_model.md`, and `docs_contract_test.go`. Add the factual PR #10 closure alongside the new selection. Revise the bounded read rule and the immutable-original/mutable-progress contract together. Clarify older physical-close wording where its owning section is touched.
- **Admission composition:** `es/admission/reliable_submit_replay_private.go`, `reliable_submit_replay_format.go`, and `reliable_submit_replay_hydration.go`. Preserve the synthetic parser and PB1 v1 grammar. Add only the privately reachable, separately versioned model composition and exact original verification needed by the new format.
- **Persistence and custody:** under `es/admission/internal/reliablesubmit/`, scope changes to `durable_record.go`, `durable_operation.go`, `durable_service.go`, `sqlite_store.go`, `sqlite_migrations.go`, `sqlite_replay_claim.go`, `sqlite_replay_shape.go`, `replay_custody_file.go`, `replay_custody_format.go`, `replay_custody_structure.go`, and `replay_key_use_sqlite.go`. Put the new SQL literal in `sqlite_replay_progress_schema.go` and preserve the migration-3 literal. The allowed behavior is fixture-driven private establishment, authenticated replay, and existing-model progress, including restart and commit uncertainty.
- **Tests:** new `sqlite_pooled_claim_read_cleanup_test.go` and `replay_progress_test.go`, plus `guardrails_test.go` and `es/admission/reliable_submit_replay_private_test.go`. API, App startup, config, staging, provider handoff, scripts, and examples remain outside the first-slice write scope. Their existing refusal and compatibility tests are regression evidence.

**Prospective evidence, subject to implementation authority**

| New test | Required witness |
| --- | --- |
| `TestSQLitePooledClaimReadCleanup` | Real cancellation after BEGIN and SELECT, bounded and expired rollback classification, uncertain BEGIN/COMMIT disposal, no success after observed cancellation, unchanged rows, and legitimate same-store work before teardown. |
| `TestReliableReplayProgressComposition` | Same-key original replay despite changed defaults or material inputs, changed-intent conflict, concurrent winner, retired/revoked/missing original keys, immutable envelope and `RunRef`, and legal progress transitions using fixture facts. |
| `TestReliableReplayProgressRestartAndUnknownCommit` | Reopen without losing original or progress, exact own-success versus equivalent or advanced winner, stale/latest-operation conflicts, and unresolved write outcomes that confer no authority to repeat an effect. |
| `TestReliableReplayProgressMigrationIsolation` | Append-only migration, authentic legacy preservation, schema-3 binary refusal of a newer schema before mutation, permanent codec-3 immutability, and fail-closed overlap or wrong-scope rows. |
| `TestPrivateReliableReplayProgressNoEffect` | Private admission verifies the complete original, with no path to staging or provider I/O and public structural refusal preserved. |

Include the governing docs-contract selectors and existing `TestSQLiteLegacyCASConnectionCleanup`, `TestReplayOriginalKeyReadCleanup`, `TestReplayOriginalKeyReadCallerRefusal`, `TestReliableSubmitPrivatePersistenceStaticGuardrails`, and `TestSubmitPublicRouteRejectsStructuralReliableBody`, plus the existing C1/D1 and migration protections. The future source gate needs its own exact-byte validation and independent review. It cannot inherit that result from this reconnaissance.

Directly enabling codec 3 would violate its insert-only synthetic contract. Repurposing historical rows would lose original-input authority. A second database, scheduler, queue, or phase algebra would add coordination work without addressing the evidenced seam.

## Four gates to one bounded reliable execution

1. **Private composition.** Freeze the next-slice owner decisions, close the reproduced pooled-read exposure, then prove the new versioned original-plus-progress composition with fixtures and the current model. Scope, immutable-field preservation, exact attempt equality, and format isolation are prerequisites for source acceptance.

2. **Disabled-by-default ingress and startup.** For the first runtime target, select one ES process on a supported local Linux host, one qualified static-script profile with an immutable image digest, and one expressly authorized execution. Admit one configured exact canonical SPIFFE URI from the verified client leaf, with unambiguous identity selection, current authorization, and bootstrap refusal. Keep the selected producer negotiation and structural keyed body on the existing Submit route, preserving unkeyed behavior. Use a dedicated absolute ES-owned local root for one SQLite DB and immutable objects, separate from staging and results. A proposed config key is `execution.reliable_submit.state_root_dir`; the owner must freeze its spelling and installed path. Use externally provisioned, owner-only, purpose-distinct binding and envelope keys. Retain retired originals for verification, refuse missing, revoked or mismatched keys, and keep new grants and first-effect authorization subject to current eligibility. Select hard claim, grant and storage bounds. Retain the initial window’s correlations without automatic expiry, GC, key reuse, restore or rollback, and refuse unsupported topology or exhaustion.

   For receipt recovery, require the same currently authorized caller and a verified equivalent original. Preserve the existing original and accepted receipt across mutable defaults. Recommend that read-only accepted receipt recovery keep current caller authorization without re-running mutable first-effect admission. Require current admission for any first effect. Before assignment, pending or ambiguity discloses no run. After assignment it exposes the same `run_id`. Only durable accepted evidence yields a receipt. Conflict, unauthorized and unavailable outcomes reveal no prior run or receipt. The owner must approve that read-only recovery policy and freeze exact response fields, HTTP statuses, and retention limits before runtime.

3. **Handoff and restart proof with a fake provider.** Assign one ES `RunRef` through CAS, retaining today’s run grammar and the `exec-<run_id>` locator derived from the persisted run. Refuse collisions. Commit effect intent before staging and the dispatch marker before the first provider request. Require a creation-only registration contract with no redirect or client replay of a POST. On restart before dispatch, require the full validated no-dispatch predicate and qualified staging ownership. Refuse an existing or partial stage when safe re-entry cannot be proved. After a marker or any possible send, retain the same attempt and prohibit another POST. Positive acceptance evidence must bind the trusted configured provider, exact job locator and namespace, run, and expected authorized job identity. Absence, mismatches, timeout and lost response remain pending or ambiguous. ES records the qualifying observation and durable receipt; Nomad retains lifecycle authority. Freeze and test the provider query, consistency guarantees and acceptance predicate before any host run. [Validated no-dispatch rule](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:471) · [Current locator](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1/es/admission/executionlocator.go:11)

4. **Separately authorized native execution.** Prove the exact installed source, local state/key and staging topology, and provider evidence on the selected governed Ubuntu 24.04 Linux/arm64 supported-local host. Obtain explicit authority for one run and verify same-key replay and restart without another effect. First select the fail-closed availability response to unresolved disposal and resource retention. Missing evidence stops before host effects. HA, multi-tenant service, restore, Coordinator progression, and deployment rollout remain outside this target. [Supported Linux qualification](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1/.docs/system_overview/supported_linux_host_qualification.md:124)

The queued empty Claude suites from publication remain no-result observations with no bearing on the data-plane design. F1 still establishes a post-response observation before self-cancel. Five seconds bounds the rollback context, and usable-pool eviction or driver Close invocation leaves physical termination and duration unqualified. Both-disposal resource retention, direct SELECT transport faults, instant cross-process revocation, and older close wording remain separate. No-Seal evidence remains source order plus dynamic refusal and file observations. The prior rejection and historical failed runs remain attached to their exact bytes. Use the pinned commit and closeout as today’s baseline, and consider a new snapshot after the owner-approved composition becomes an architecture-defining accepted checkpoint.

## Private evidence

The root is `/Users/ds/Repositories/ES-Post-PR10-Integration-Recon-20261118-4pz7ugvx`. The report SHA-256 is `c473578e8439cf4dcb79b8b42fb627cdea51c2a9a287a74b1a2d7261157629af`. The self-excluding index binds **874 files and 172 directories** and has SHA-256 `9ee2b802f36a6cee0aedea2558f2737bb9dcdf75f9d6e643d17ebbb4fbcc5be1`. Retained evidence uses `0600` files and `0700` directories, with the copied and instrumented source views preserving Git file modes. [Private report](/Users/ds/Repositories/ES-Post-PR10-Integration-Recon-20261118-4pz7ugvx/recon-report.txt) · [Artifact index](/Users/ds/Repositories/ES-Post-PR10-Integration-Recon-20261118-4pz7ugvx/artifact-index.json)

| Diagnostic binding | SHA-256 |
| --- | --- |
| Pristine 427-leaf inventory | `3dd848d7ce644250b6be4554d9e27319907011b1f95b759aadd06fca1bdef23b` |
| Frozen diagnostic | `76ca88a5048a0d33a0a0b0ecb44caf830ef519c8404d0246deac8dd0509f3b11` |
| Instrumentation diff | `3cb8a9f6ab61cb57a24e87c271f5117f4530b991a756ff48a8ee83cacba8ed7f` |
| Complete diagnostic test | `e442ad888290dd79ca21bdc408bd96a917ae83bf6298efa36437ab47b304a368` |
| Diagnostic stdout | `939b3c2b8c32e8b126b4b16513400b62056654a0dfbd4ef9f3c11feadbdd94e3` |
| Immediate local source proof | `6f0c487f3620bd6b7c4ce970b95473aaaa9a3afff9d5dec645c13e7aa1c241fb` |

```text
ES_POST_PR10_RELIABLE_SUBMIT_NEXT_SLICE_RECON_READY
SOURCE_REPOSITORIES_NOT_MUTATED
SOURCE_REFS_NOT_UPDATED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PRS_NOT_MODIFIED
EXISTING_SOURCE_CHECKOUTS_NOT_SYNCHRONIZED
PRODUCT_REPAIR_NOT_PERFORMED
INDEPENDENT_ACCEPTANCE_NOT_PERFORMED
RUNTIME_WIRING_NOT_PERFORMED
PUBLIC_RELIABLE_SUBMIT_NOT_ENABLED
NATIVE_INSTALLED_SOURCE_WITNESS_NOT_QUALIFIED_BY_THIS_TURN
```
<END_EXACT_RECON_REPORT>

---

## Appendix B — Exact provenance recipe source

RECIPE_ID=governed-execution.audit-patch-manifest.v2
APPENDIX_B_BYTES=7275
APPENDIX_B_SHA256=c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca

<BEGIN_EXACT_V2_RECIPE>
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
import sys
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v2"


def fail(message: str) -> "NoReturn":
    raise SystemExit(message)


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env.update(
        {
            "LC_ALL": "C",
            "LANG": "C",
            "GIT_OPTIONAL_LOCKS": "0",
            "GIT_NO_LAZY_FETCH": "1",
            "GIT_TERMINAL_PROMPT": "0",
            "GIT_PAGER": "cat",
        }
    )
    result = subprocess.run(
        [
            "git",
            "--no-pager",
            "-c",
            "core.fsmonitor=false",
            "-c",
            "core.untrackedCache=false",
            *args,
        ],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


def validate_output_path(output_path: Path, repository_root: Path) -> None:
    if not output_path.is_absolute():
        fail("output path must be absolute")

    parent = output_path.parent
    parent_metadata = parent.lstat()
    if not stat.S_ISDIR(parent_metadata.st_mode) or stat.S_ISLNK(parent_metadata.st_mode):
        fail("output parent must be a nonsymlink directory")
    if parent_metadata.st_uid != os.getuid():
        fail("output parent must be owned by the current user")
    if stat.S_IMODE(parent_metadata.st_mode) & 0o022:
        fail("output parent must not be group- or world-writable")

    try:
        output_path.lstat()
    except FileNotFoundError:
        pass
    else:
        fail("output path already exists")

    repository_text = os.path.realpath(os.fspath(repository_root))
    output_text = os.path.realpath(os.fspath(output_path))
    try:
        common = os.path.commonpath([repository_text, output_text])
    except ValueError:
        common = ""
    if common == repository_text:
        fail("output path must be outside the repository")


def write_exclusive(output_path: Path, payload: bytes) -> None:
    flags = (
        os.O_WRONLY
        | os.O_CREAT
        | os.O_EXCL
        | getattr(os, "O_NOFOLLOW", 0)
        | getattr(os, "O_CLOEXEC", 0)
    )
    fd = os.open(os.fspath(output_path), flags, 0o600)
    try:
        view = memoryview(payload)
        while view:
            written = os.write(fd, view)
            if written <= 0:
                fail("short provenance-output write")
            view = view[written:]
        os.fsync(fd)
    finally:
        os.close(fd)

    metadata = output_path.lstat()
    if not stat.S_ISREG(metadata.st_mode) or stat.S_ISLNK(metadata.st_mode):
        fail("provenance output is not a regular nonsymlink file")
    if metadata.st_uid != os.getuid():
        fail("provenance output owner mismatch")
    if stat.S_IMODE(metadata.st_mode) != 0o600:
        fail("provenance output mode mismatch")
    if metadata.st_nlink != 1:
        fail("provenance output link-count mismatch")
    if metadata.st_size != len(payload):
        fail("provenance output size mismatch")

    read_flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_CLOEXEC", 0)
    read_fd = os.open(os.fspath(output_path), read_flags)
    try:
        observed = bytearray()
        while len(observed) <= len(payload):
            chunk = os.read(read_fd, min(1 << 20, len(payload) + 1 - len(observed)))
            if not chunk:
                break
            observed.extend(chunk)
    finally:
        os.close(read_fd)
    if bytes(observed) != payload:
        fail("provenance output byte mismatch")


if len(sys.argv) != 2:
    fail("usage: governed_execution_audit_patch_manifest_v2.py ABSOLUTE_OUTPUT_PATH")

repository_root = Path(git_text("rev-parse", "--show-toplevel"))
output_path = Path(sys.argv[1])
validate_output_path(output_path, repository_root)

head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    fail("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            fail(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()

write_exclusive(output_path, canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")

<END_EXACT_V2_RECIPE>
