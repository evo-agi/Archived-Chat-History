Here is Codex's response:

# ES_PRIVATE_REPLAY_PROGRESS_M1_PRECOMMIT_AND_OWNER_INVENTORY_REPAIR_READY_FOR_FRESH_INDEPENDENT_AUDIT

Both remaining findings were repaired within the six authorized files. The final frozen generation passed all eleven gates. The full tree recorded **5,192 passes, zero failures and 39 expected skips**, and the external N-1 witness passed all five identities. The prior independent rejection still applies to the opening bytes. This delivery is for a fresh independent audit.

[Review ZIP](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/ES-Private-Replay-Progress-M1-Owner-Repair-Review.zip) · 955,015 bytes · SHA-256 `3b27c483036296304a9fbca77dcd5fe522dee64b8eabf392057b6c573160f59a`

## Repairs and regression evidence

**M-1 pre-COMMIT recovery.** After migration begins against an authenticated lock-held baseline, an unconfirmed rollback on an already-closed wrapper can now hand cleanup to the unpublished opener. The migration-local signal also carries the existing post-COMMIT response-loss route. It grants no outcome by itself. The original connection ownership ends, the opener checks the original pool’s close result, and one fresh checked nonmigrating observation classifies the file. An authentic old state returns `errClaimStoreMigrationRecoveredOld` with no handle. A qualified current state is an observation of that head. Canceled, failed or unqualified observations remain unavailable. A timely ordinary rollback retains ordinary refusal. Recovery issues zero migration retries. [SQLite opener and migration](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_store.go:59) · [Persistence ADR §15B.5](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1712)

The maintained differential used the same regression bytes with opening and repaired SQLite production source. On opening source, all four closed-wrapper cases for schemas 0–3 returned `errClaimStoreUnavailable` and failed the recovered-old assertion. On repaired source, all four returned `errClaimStoreMigrationRecoveredOld`. The eight ordinary-rollback and canceled-readback controls retained generic unavailable in both runs. All 12 cases reached verified schema 4 on the exact transaction connection, entered the migration once, attempted zero COMMITs, returned no usable handle, and preserved the unfiltered schema, application/version pragmas, table rows and rowids in an independent nonmigrating read. Populated schema 3 included claims, keys, grants, ledger and a sealed original whose bytes were also checked. Wrapper closure and the pre-COMMIT error were modeled through the existing collaborator. SQLite transactions and the readbacks were real. [Maintained regression](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go:715) · [Red log](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/migration-red/stdout) · [Green log](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/migration-green/stdout)

**DOC-SYNC.** Admission §7.4 now enumerates the exact 32 fields in non-test production source: five direct locks, three `atomic.Bool` fields and 24 transitive references, requests or wrappers. It records both permit wrappers, the shared `publishReplayOriginal` reader, and the `matchesAllocation`, `consume` and `burn` roles. The fixtures remain runtime-unwired, and SQLite owns committed claim, progress, key and grant/use facts. The root test compares exact field identities and categories with the frozen typed-inventory literal. The actual stale opening document failed. The repaired document passed checks for a missing atomic, omitted scope-2 wrapper, omitted shared reader and a carrier misclassified as a primitive. The existing resolved-plan contract now checks the same three lock identities using the corrected notation. [Admission §7.4](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/es_execution_admission_model.md:910) · [Root contract test](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/docs_contract_test.go:12556)

The six changed files were [PLANS.md](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/PLANS.md:5), the two owner documents, `docs_contract_test.go`, `sqlite_replay_migration_test.go` and `sqlite_store.go`. The other 24 candidate rows and 400 HEAD-identical leaves stayed byte- and mode-identical. Within `sqlite_store.go`, the only changed functions or function comments were `openSQLiteClaimStore`, `migrateSQLite` and `verifyMigrationRecovery`, plus the private recovery signal. The rest of the file matched opening byte-for-byte, including `loadClaim`, `loadClaimFresh`, shared transaction and discard helpers, claim/grant/CAS paths, A1/O2/C1/D1 and all existing seams. The 1,077-byte `loadClaimFresh` body retained SHA-256 `3a47f8b5e0c5bf7bec899987aa78fdf4ef48a585086d9eb975e576896ab4b61c`. The Workstream C source, schema literals and hashes, formats, and other seven prior finding repairs were preserved. [Source map](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/source-map.json) · [Store preservation proof](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/preserved-store.json)

## Provenance and delivery

The physical and Git top-level was `/Users/ds/Repositories/ES-Private-Replay-Progress-v1`, with its own `.git` as the common directory. Branch `codex/private-replay-progress-v1` tracked `origin/trunk_dev` at origin `git@github.com:evo-agi/Execution-Substrate.git`. Both scoped refs remained at:

- HEAD `f1aa8b934cc26c16a966a110c7b408abdaeadce7`, `Harden original-key read transaction cleanup (A1) (#10)`
- Sole parent `fb9ae55797d9fcc02863c23fe8d3e43d16eac542`
- Committed tree `8dd27f9acba98ed70d93736bdef8300ef1aba53f`

The 427-entry index remained HEAD-identical, with raw SHA-256 `1c6218366e333383b205833fce0ceaa5d462fa7264cf51cbdcd35aa05855b018`. Local Git config and the named refs matched opening. All 430 physical source leaves were checked after each validation run. The final classification was 27 unstaged tracked modifications and exactly the three original ordinary-untracked files, `replay_progress_test.go`, `sqlite_pooled_claim_read_cleanup_test.go` and `sqlite_replay_progress_schema.go`. There were zero ignored, staged, unmerged, deleted, renamed, type-changed or extra paths. [Closing guard](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/closing-b-guard.json)

| Identity | SHA-256 |
|---|---|
| Exact opening manifest, 6,813 bytes | `0812091529c67f4bc46d0bc343b3dea8595e63a461264e143d51606e581e0c06` |
| Opening tracked full-index diff | `68339ba85b7b22d86bdaa21ed4fdccebc5021f82912344e0507862d1624cb791` |
| Exact final manifest, 6,813 bytes | `f92b57f48a701a606e8a0697b75dac8f691e3eb44c13b9c92afb894ec6e1d718` |
| Final tracked full-index diff | `793e6697cf2342ce41f08ed8f59a0a14eb5c288c74780f158731d55dbe17bcca` |
| Unchanged v2 recipe, 7,275 bytes | `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` |
| Final source guard | `81caa55b927963348f8c960a0bdba593056646094cdd5c1d0b6a46e72fd4fe98` |

Two opening recipe runs matched Appendix B. Two closing runs after scratch cleanup matched the final freeze byte-for-byte. I authenticated the prior audit index and rechecked the material records used in this repair. The historical malformed `replay_custody_structure.go` transcription stayed confined to its original report. The live and archived file retained the correct digest ending `c6a86ad`. [Exact opening JSON](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/appendix-B) · [Exact final JSON](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/closing-b.json) · [Authenticated prior report](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/appendix-A)

The ZIP contains 47 unique regular entries, including all 30 complete source files, both exact manifests, the source map, the maintained regression, and the external N-1 inputs and bindings. The tracked HEAD patch plus the three explicit additions, the full-opening delta, and the tracked-only opening delta with additions each reconstructed all 430 final leaves in private copies. Both `git diff --no-index` commands returned the expected exit 1 for differences. All three `git apply` commands exited 0. ZIP member names, modes, sizes, bytes and the self-excluding inventory were verified. [Archive receipt](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/packet-receipt.json)

| Delivery evidence | SHA-256 |
|---|---|
| Exact opening-to-repaired patch | `211a5522dfc8b5401f7361c5148ce53dc7eaef06e56787231e2624783d064cc2` |
| Opening tracked-only patch with additions | `951c9353a69a37340f122bfd92b4c17ec3e2f514c70cd1e614d7665c3cf0175c` |
| Source map | `d8bae35ede66a6b66b093e457a879ba4b633c7b8dc14ad7c8742801f2a3fc976` |
| ZIP delivery inventory | `a24629ff1c02e4498dcb5a7f66779faf4057d29b00bce9b756572d77236cd6ee` |
| Duplicate report | `6c249d2f2c2b219b6b07ba57d3236ab37d8ffbc1eb2872986489547c2e629f49` |
| Private artifact index | `82860422eaa259508b55b4f5911925ca5d7cc6b3d8aff66fa178e7e9aef7d939` |

[Duplicate report](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/repair-report.md) · [Private artifact index](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/artifact-index.json)

## Executed validation

Development used pinned Go 1.26.5 `darwin/arm64` and its sibling `gofmt`, Python 3.13.4 with `tomllib`, OpenSSL 3.6.2 and Git 2.49.0. The recorded environment used the specified offline Go controls, Git optional locks and lazy fetch disabled, Python bytecode disabled, task-owned cache/temp directories, outer umask `077` and test umask `027`. [Preflight paths and hashes](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/preflight.json) · [Environment](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/environment.json)

The differential tests used the same Go test flags as the focused gates below. Migration red ran from `red-source`, using `-run '^TestSQLiteMigrationPrecommitClosedWrapperRecovery$' ./es/admission/internal/reliablesubmit`. Green ran from the actual checkout with the same selector. Owner reds ran from the recorded private `owner-red-source-*` views against the exact opening owner document with `-run '^TestPrivateReplayProgressSynchronizationInventoryDocsContract$' .`. Owner greens ran in the actual checkout. The final owner green also selected `TestResolvedPlanDocumentationTruthAndFiniteInventoriesContract`.

| Development run | Exit | Result |
|---|---:|---|
| Migration red | 1 | 8 pass, 5 fail including the parent. All failures reached classification. |
| Migration green | 0 | 13 pass. |
| First owner red | 1 | Build setup failed on a duplicate local name. This run supplies no behavioral red evidence. |
| Owner red 2 | 1 | Exact stale owner document failed the field-set check. |
| First owner green | 1 | 3 pass, 2 fail. The carrier mutant was rejected on table width before it reached category. |
| Owner red 3 / green 2 | 1 / 0 | Stale document failed the field-set check. The corrected parent and all four mutants passed on green. |
| Final owner red 4 / green 3 | 1 / 0 | Stale document again failed on the final test bytes. The new owner test and existing resolved-plan contract passed, six identities total. |

The integrated **generation 1** passed gates 1–9. Gate 10 exited 1 with 5,191 passes, one failure and 39 skips. The sole failure was `TestResolvedPlanDocumentationTruthAndFiniteInventoriesContract`, which still expected the old spelling of three lock fields. Gate 11 was unrun in that generation. I updated those three assertions to the corrected document’s exact field names, preserved the first freeze and raw logs, and reran the entire sequence on **generation 2**. [Generation 1 failure record](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/generation-1/gate-10/result.json) · [Differential construction and exact command records](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/differential.json)

### Final generation 2

| Gate | Exit | Pass/fail/skip | Package result |
|---|---:|---:|---|
| 1 Go version | 0 | — | Go 1.26.5, Darwin arm64 |
| 2 `gofmt -d` | 0 | — | Empty output |
| 3 Diff check | 0 | — | Empty output |
| 4 Owner contracts | 0 | 27/0/0 | 1 tested |
| 5 Pooled reader | 0 | 16/0/0 | 1 tested |
| 6 Internal focused and old probes | 0 | 221/0/0 | 1 tested |
| 7 Admission and typed Workstream C | 0 | 26/0/0 | 1 tested |
| 8 API/App boundaries | 0 | 2/0/0 | 2 tested |
| 9 Four packages | 0 | 2,062/0/39 | 4 tested |
| 10 Full repository | 0 | 5,192/0/39 | 21 tested, 20 with no tests |
| 11 External N-1 | 0 | 5/0/0 | 1 tested |

Commands 1–10 used `/Users/ds/Repositories/ES-Private-Replay-Progress-v1`. Command 11 and the subsequent build-graph command used `N1_SOURCE`. Every selected parent executed. Each command had a freshly executed post-command source/index guard, and command 11 had a separate 432-file before/after view guard. [Final argv, identities, skips and raw-log hashes](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/validation-summary.json)

```sh
GO=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go
GOFMT=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/gofmt
I=es/admission/internal/reliablesubmit
A=es/admission
N1_SOURCE=/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/n1-source

"$GO" version
"$GOFMT" -d docs_contract_test.go "$I/sqlite_store.go" "$I/sqlite_replay_claim.go" \
  "$I/sqlite_migrations.go" "$I/sqlite_replay_progress_schema.go" "$I/sqlite_replay_shape.go" \
  "$I/durable_record.go" "$I/durable_operation.go" "$I/durable_service.go" \
  "$I/replay_custody_format.go" "$I/replay_custody_structure.go" "$I/replay_custody_file.go" \
  "$A/reliable_submit_replay_format.go" "$A/reliable_submit_replay_hydration.go" \
  "$A/reliable_submit_replay_private.go" "$I/sqlite_pooled_claim_read_cleanup_test.go" \
  "$I/replay_progress_test.go" "$I/replay_custody_file_test.go" "$I/sqlite_store_test.go" \
  "$I/sqlite_physical_test.go" "$I/sqlite_replay_migration_test.go" \
  "$I/sqlite_replay_shape_test.go" "$I/guardrails_test.go" "$A/reliable_submit_guardrails_test.go" \
  "$A/reliable_submit_replay_private_test.go" "$A/workstream_c_guardrails_test.go"
git --no-pager diff --check
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateReplayProgressSynchronizationInventoryDocsContract|TestPrivateOriginalReplayProgressContractSelection|TestReliableSubmitPersistenceAndConcurrencyADRDocsContract|TestSubmitIdempotencyCorrelationAndRecoveryDocsContract|TestReliableSubmitPureModelDocsAndSourceContract|TestReliableSubmitPublicOptInAndVersioningDocsContract|TestReliableSubmitContractAdapterFoundationDocsAndSourceContract|TestReliableSubmitBindingProducerDocsContract|TestIntegratedAcceptanceGateDocumentationIsConsistent|TestIntegratedCandidateStatusSeparatesCAndT)$' .
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestSQLitePooledClaimReadCleanup$' ./es/admission/internal/reliablesubmit
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestSQLiteMigrationPrecommitClosedWrapperRecovery|TestPrivateReplayProgressConfirmationEligibility|TestPrivateReplayProgressReconciliationEligibility|TestPrivateReplayProgressTerminalEvidenceBinding|TestSQLiteMigrationOpeningRevalidatedUnderLock|TestSQLiteLiteralInternalNamespaceQualification|TestPrivateReplayScope1PublicationPreflight|TestPrivateReplaySharedObjectAllocation|TestReplayPublicationFaultAndIdentity|TestPrivateReplayProgressFormatVectors|TestPrivateReplayProgressTransitions|TestPrivateReplayProgressConcurrencyAndCommitOutcome|TestSQLiteV4MigrationPreservesFullState|TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation|TestSQLiteV3OldBinaryRefusesWithoutMutation|TestSQLiteLegacyCASConnectionCleanup|TestReplayOriginalKeyReadCleanup|TestReplayOriginalKeyReadCallerRefusal|TestReplayGrantC1PreCommitConnectionQuarantine|TestReplayGrantD1BeginResponseLossQuarantine|TestReplayKeyStateD1BeginResponseLossQuarantine|TestReliableSubmitPrivatePersistenceStaticGuardrails)$' ./es/admission/internal/reliablesubmit
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestExecutionSubstrateProductionHasNoA3LeaseRegistryOrPoisonDesign|TestExecutionSubstrateSynchronizedMutableStateReferenceInventoryIsExact|TestPrivateReplayProgressOccupiedDisposition|TestPrivateReplayProgressAdmissionReplay|TestPrivateReplayProgressHasNoEffectPaths|TestReliableSubmitFoundationHasNoRuntimeWiring|TestReliableSubmitBindingProducerHasNoProductionCaller|TestPrepareRequestShapeRemainsLegacyAndUnkeyed|TestResolvedSubmitLegacyEquivalenceOneNomadRegistrationAndAuthorityRecovery)$' ./es/admission
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestWorkstreamCContractPrepareAndSubmitRemainSeparatedAtAPIBoundary|TestSubmitPublicRouteRejectsStructuralReliableBody)$' ./es/api ./es/app
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=600s ./es/admission/internal/reliablesubmit ./es/admission ./es/api ./es/app
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=600s ./...
(cd "$N1_SOURCE" && "$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestPrivateReplayProgressAdmissionUnknownNoEffects$' ./es/admission)
(cd "$N1_SOURCE" && "$GO" list -mod=readonly -deps -test -json ./es/admission)
```

The full suite added 18 passing identities over the independently audited 5,174. These were `TestSQLiteMigrationPrecommitClosedWrapperRecovery` and its 12 `Schema{0,1,2,3}/{ClosedWrapper,OrdinaryRollback,CanceledReadback}` leaves, plus `TestPrivateReplayProgressSynchronizationInventoryDocsContract` and its four `MissingAtomic`, `OmittedScope2Wrapper`, `OmittedSharedPermitReader` and `ReferenceClaimedAsPrimitive` leaves. There were zero removals or renames. Gate 9 was exactly the four-package projection of gate 10. All 39 skip identities matched the prior audit: the two direct helper sentinels, 36 App cases with Docker daemon unavailable, and the installed-source case with direct Docker Unix socket unavailable. No repair case skipped. The allocator parent logged both `SHARED_ALLOCATOR_READY` and `SHARED_ALLOCATOR_WON`. [Exact skip and identity reconciliation](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/validation-summary.json)

Both historical opener probes ran from authenticated task-owned copies. PB1/schema 2 was 14,350,930 bytes with SHA-256 `b205a31bac091cbcf5b3f4826bc359455625316908051131733622813e34adcf`. The previous schema-3 probe was 15,601,186 bytes with SHA-256 `42614a50812a65ba52b53488d872884e59ce7b4f57dece6a66642d4eb8de1409`. They retained their separate schema-3 and schema-4 refusal purposes and their prior source and witness bindings.

### External N-1

The final N-1 view contained all 430 final leaves plus exact Appendix D/E files. The bridge digest was `14f0e9e92a37e1d1bf624f1f052a62a6d56e5b82f988698abbf6e1b5bcf9196d`, the witness digest was `8da31dd61c9af2537c15f4376a330d05cb2e55dd2efd0ea610472a0c6ffa5c6a`, and the 432-file view digest was `d232b4a270cfe3af072794a24a2b188d9c3e1f553d85bd6e72c13485ff6933fd`. The separate `go list` exited 0. The 291-package graph bound 2,801 physical inputs, including the generated test-main source preserved before cache cleanup. The migration regression appears in dependency test-file metadata only. The bridge and witness remain external to the ordinary checkout.

| Case | Invocation result | Projected revision | Later current revision |
|---|---|---:|---:|
| Establish / Canceled | `WriteUnknown` | 0 | 1 |
| Establish / AuthenticatedExact | `OwnCommitConfirmed` | 1 | 1 |
| AssignRun / Canceled | `WriteUnknown` | 0 | 2 |
| AssignRun / AuthenticatedExact | `OwnCommitConfirmed` | 2 | 2 |

Each case executed one real COMMIT followed by modeled response loss. The later read preserved the earlier disposition. Provider, staging and EGS counters were zero, operational roots were empty, and each case retained one sealed original. These five identities are outside the ordinary suite. [N-1 raw log](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/gate-11/stdout) · [Build-input inventory](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/n1-build-inputs.json)

## Scope and closeout

Only the foreground wrote repository source, after the four earlier reviewers had closed. No subagents were started for the repair. The evidence qualifies the observed logical states and cleanup ordering. Physical driver-close success and duration, native installed-source qualification, provider acceptance and operational cross-restart write-uncertainty authority remain unqualified.

I removed only task-owned compile caches, temp directories and patch-reconstruction fixtures. The retained probes were returned to `0600`. The maintained tests used bounded temporary fixtures, helper processes, loopback mocks and read-only Docker capability probes. No shared caches or prior evidence were cleaned.

No staging, commit, push, PR mutation, ref update, remote effect, checkout synchronization, dependency download or installation, live stack, real key loading, operational migration, native qualification or runtime wiring occurred. Public reliable Submit remains unavailable. The cross-restart operational write-uncertainty gate remains unimplemented.

## Exact final canonical manifest

```json
{"branch":"codex/private-replay-progress-v1","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/es_execution_admission_model.md","sha256":"bedc87c611b5c9340ffaafb0866f028dc9daf2f22552efec47491f1b4ae713f2","size":88702},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md","sha256":"34e06ff10148d67a49000868499294873c732279d7f399a5f2cb910b0c12f40e","size":161666},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md","sha256":"1b03cc40b48861c7220a7b85d20b1f8d232690f17460e3eee0df33af4659e3f3","size":103025},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"c4fdbfb4acd3c2a27f679f6575798c4553e94110c4aa7177f590e90fe89c5e31","size":302636},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"dd433f02e783aa265d775bd411c95433e369642e2aafbdb32c72b75f78b4ebff","size":799914},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_operation.go","sha256":"b7761f001a1f67349ed51f2b79012194a7d45bb19c79e0ca2c0c22b8227320f9","size":9548},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_record.go","sha256":"999db7db6550c5031b023a9613825504e30e971a179298cc43e09cf8c5c5d7cd","size":25226},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_service.go","sha256":"ef0bc6f4d125f3986c46901cbe05bc2cb447af7dfbf51cee4653d7ce696c0945","size":49972},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/guardrails_test.go","sha256":"9a300f0553fd6ac3003a048a7309060a4ec6f618eacd94139bd4bb29c011bc60","size":32231},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_file.go","sha256":"61c4006e1e4a3feb7c0ec0e7d4685dc2c3fe8c1e2165d1529d2c86ae8fa137b5","size":50461},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_file_test.go","sha256":"207d9f17658cd50f6c4bea8e293b12abd89455a174b2d96bac84742a66b0afdf","size":69995},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_format.go","sha256":"b8cb8e31edd9d854317a0d6a456f25d5ab1838498623881e429dec2155e1ea67","size":16488},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_structure.go","sha256":"4916268757b93d409cbc13ba9c0da14e009499b4db7cadd52bc7ccd47c6a86ad","size":18640},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_progress_test.go","sha256":"0952fff321daa368dee1d32ed39a2a5b417e7d2779ae4e1015ab3c12b1021048","size":61314},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_migrations.go","sha256":"7736e30a1d0c6e9584d9050cc6ebf8bfaf900d424f764ebe61af8ec8ddaec0c9","size":17407},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_physical_test.go","sha256":"2c125b6373f83467d542db45473cc79b888ed3a665e65ef6bf013655f461a7ba","size":14539},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_pooled_claim_read_cleanup_test.go","sha256":"0ec3060ed3c30a6327ec49b0291d5c761c20894986c9b6b1e1be384694312823","size":8912},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_claim.go","sha256":"8ddec89b4ca5702591bdf2060062016d7fb54264fc7df57af5ead1d161eb9de3","size":8301},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go","sha256":"e0765e59cb00ace73e8a88c92b9d7e830b39766792120845220b2fd407d357fa","size":28903},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_progress_schema.go","sha256":"132d8ab87f5658cab3477b9f6913538013ba922d4768192a96be960df7bbb149","size":30612},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_shape.go","sha256":"29cdbba2e5b1fee069989f6e6423dccc1c69c843de22b6504f68a7d199b317be","size":2751},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_shape_test.go","sha256":"3552ea5fafbc59e43cc21b1007486e98da4d59b6d0ea98db92646e0c8478adfb","size":8815},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_store.go","sha256":"e448d265516aae1d7efd2c06170d8cfa2cc8c0258f82dfc15a3279e65efad4c1","size":63299},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_store_test.go","sha256":"c99e7659b1059431911557ba43ef7fa982e373bba939f610bd41ea0622cee96f","size":57339},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_guardrails_test.go","sha256":"32de42b7bf8974e36c014d3d9ce6d24e0994fbbc03bb1587c4c4fddd32c80f6e","size":50991},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_format.go","sha256":"0a21803b03308332613481f89ce4b595512b31b073c56b31fe7d8000519c3beb","size":17326},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_hydration.go","sha256":"b5ff16b96178c45b53165ebb2bcbdc67991bb145276ca4a11a598f1430745b9c","size":28800},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_private.go","sha256":"d17927a23a57c808a8f0ebc4bad3e9912e42d7da497033637102bae2c45fd278","size":20440},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_private_test.go","sha256":"4e4e7c7fad2ed2b88b35801841044f4b1f049a4cb6d0435499bb87699467e9f2","size":45171},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/workstream_c_guardrails_test.go","sha256":"68f2fe4e31e5d862be161c3ba1071a511935b32e90cf9021755fe4dcb045fab5","size":297009}],"head":"f1aa8b934cc26c16a966a110c7b408abdaeadce7","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"793e6697cf2342ce41f08ed8f59a0a14eb5c288c74780f158731d55dbe17bcca","upstream":"origin/trunk_dev"}
```
