## PR #10 is merged — A1 source publication is complete

**The merge reached the intended endpoint: one squash commit, the expected sole parent, and exactly the accepted tree. No further A1 repair, acceptance audit, or publication gate is indicated for these bytes.**

My live GitHub reads confirm that PR #10 is closed and merged, and official `trunk_dev` points to the reported squash commit.  

| Identity | Verified value |
|---|---|
| Squash commit / official `trunk_dev` | `f1aa8b934cc26c16a966a110c7b408abdaeadce7` |
| Sole parent | `fb9ae55797d9fcc02863c23fe8d3e43d16eac542` |
| Complete accepted tree | `8dd27f9acba98ed70d93736bdef8300ef1aba53f` |
| Subject | `Harden original-key read transaction cleanup (A1) (#10)` |
| Merge time | November 18, 2026, at 10:12:31 p.m. EST |

The live commit object confirms the parent, tree, subject, and verified signature. Codex additionally reports complete comparison of all 427 leaves and all seven replacement payloads, with the other 420 unchanged. **I verified the Git identities, not every remote blob payload again.**  Pasted text

The retained **4,970 passes, zero failures, and 38 skips** remain authenticated local validation. The merge gate correctly did not rerun that validation or describe it as passing CI. It also explicitly proceeded **without a Claude result**, after establishing that the empty queued suite was not required by effective policy. Neither the head’s suite nor the newly created squash suite supplied a check result. Pasted text Pasted text

The A1 checkout remains clean at source commit `fd2115ca…`; local `origin/trunk_dev` intentionally remains at the previous squash. **No pull, reset, checkout synchronization, or branch cleanup is needed to close this tranche.** Pasted text

## Next: select the integration path, not another repair by default

We should now return to the actual objective: reliable submission. The next step should establish **which missing capability blocks the first bounded reliable execution**, rather than automatically promote the next residual audit observation into another implementation campaign.

I inspected the merged plan, persistence contract, schema, private replay composer, ordinary Submit path, and remaining claim readers. Two distinctions matter.

### The synthetic foundation cannot simply be wired into Submit

The current schema permits new claims only in codec 3’s synthetic initial shape and explicitly refuses updates to those claims. Historical codec-1/2 progression does not supply a progression path for a newly created codec-3 claim. This is an intentional boundary, not a defect to remove casually. See `sqlite_replay_schema.go:209–240`. 

The private replay composer remains separate from the ordinary Submit → staging → Nomad path. The owner contract also explicitly leaves operational key custody, authenticated caller wiring, state-path configuration, provider reconciliation, public recovery vocabulary, and the runtime integration tranche open. Therefore, **completing O2 and A1 does not make reliable submission a configuration switch**.   

The next operating-model decision must explain how immutable original replay material relates to mutable execution-attempt progress, which component writes each fact, and how the first runtime effect is guarded. That needs to be selected before broad implementation.

### The remaining readers must be assessed separately

Both remaining readers use the older cleanup pattern, but their resource lifetimes differ:

| Reader | Current lifetime |
|---|---|
| `loadClaim` | Borrows a connection from the existing store pool. |
| `loadClaimFresh` | Opens an independent pool, sets maximum idle connections to zero, verifies current state without migration, and defers connection and database closure. |

Those differences are explicit in `sqlite_store.go:260–324`. Applying the A1 repair wholesale to both would be premature. Conversely, `WithAuthenticatedClaim` does call `loadClaimFresh` before its repaired original-key check, so the earlier read cannot simply disappear from the integration assessment.  

The right question is whether each reader leaves a persistent availability, snapshot, result-classification, or resource problem **under its actual lifetime and callers**—and whether that problem is a prerequisite for the selected next path. I have not dynamically established that result.

## Next Codex turn

Continue in the **same Codex conversation that completed PR #10’s merge**, rooted at:

```text
/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1
```

Use:

:chatgpt-content-reference{index="16"}[Download the post-PR #10 reliable-submit integration-selection prompt](sandbox:/mnt/data/ES_Post_PR10_Reliable_Submit_Integration_Selection_20261118.md)

SHA-256:

```text
80acd79384517a90fe00d0a48c1e031a6c3f255949d453abec59c9d108ceba88
```

The prompt embeds the complete supplied merge closeout. I verified the embedded report byte-for-byte.

This turn is **repository-read-only reconnaissance, with narrowly authorized offline diagnostics in external source copies**. It does not select or perform a product repair.

Its required outputs are:

1. **An integration dependency map:** trusted caller/key → original lookup and replay → bound plan/custody → durable attempt and RunRef → staging/handoff → ambiguous-outcome reconciliation → receipt/recovery.
2. **A separate disposition for each remaining claim reader:** bounded diagnostics where needed, measuring subsequent legitimate work before store teardown and distinguishing the fresh reader’s normal function-owned closure.
3. **One recommended next slice:** exact owner decisions, prospective files, compatibility/migration treatment, acceptance evidence, and a short dependency sequence toward the first bounded reliable execution.

The diagnostics are limited to the two readers, real disposable SQLite fixtures, and a small declared set of controls and cancellation/uncertainty cases. They must retain complete instrumentation and test bytes and clear fault hooks before healthy follow-ups. They do not require another socket harness, global descriptor inventory, physical-close fault platform, or full-suite replay.

The preserved topic tree is identical to the squash tree. **An unfetched squash object is not a reason to synchronize the checkout**: the prompt permits committed-blob inspection from the preserved source after proving tree equality.

Expected endpoint:

```text
ES_POST_PR10_RELIABLE_SUBMIT_NEXT_SLICE_RECON_READY
```

That means the recommendation is decision-ready—not that its proposed operating model is implemented or that runtime effects are authorized.

## Keep the remaining work differentiated

The physical-close and both-disposal resource limits remain operational qualifications. The shared-read concern needs its own lifetime-based assessment. Native installed-source and live-host evidence remain later explicit qualification gates. None is closed by A1, but neither should all of them become prerequisites for every source-only planning step. Pasted text

The merged `PLANS.md` currently records A1 selection rather than a post-PR #10 closure and next-slice entry. The reconnaissance should propose that minimal current-status update **with the next selected owner-contract work**, not create another standalone cosmetic PR. 

A new snapshot is not a prerequisite for this bounded reconnaissance. The exact merged tree and supplied closeout provide a usable overlay on the project snapshot; project guidance explicitly avoids requiring a snapshot solely because a bounded private reader tranche committed. Governed Execution Provenance G…

**Sources:** Complete attached merge closeout; live GitHub PR, branch and commit objects; pinned merged planning, persistence, schema, admission and reader source cited above. I inspected those materials but did not execute repository commands, tests, or diagnostics.

**Confidence:** Merge identity and source-publication closure **0.99**; retained validation assessment **0.98**; integration-selection direction **0.96**. The exact next implementation scope remains to be established by the bounded reconnaissance.
