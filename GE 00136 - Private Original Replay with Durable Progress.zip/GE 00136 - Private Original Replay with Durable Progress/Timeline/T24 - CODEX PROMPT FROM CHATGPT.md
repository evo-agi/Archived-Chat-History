# Execution Substrate — consolidated replay-progress repair, fresh independent audit

## Objective and authority

Open a FRESH read-only Codex conversation directly at:

    /Users/ds/Repositories/ES-Private-Replay-Progress-v1

Independently decide whether the exact thirty-path repaired candidate is eligible
for a later separately instructed local commit gate. Inspect the complete integrated
slice and explicitly adjudicate SR-1, M-1, M-2, SR-2, K1-1, N-1, T-1 and R2-1.
The prior REJECT belongs to the rejected bytes; the author's readiness report and
ChatGPT's static review are evidence to test, not acceptance.

The source repository, index, refs, Git config, prior evidence and all other
checkouts are read-only. The audit parent may create private external artifacts,
copy authenticated source into external fixture views, compile and run the bounded
offline tests/probes below, and inspect pinned dependency source. No product repair,
formatting write, staging, commit, fetch, push, PR action, merge, dependency download,
installation, live stack, operational migration, real key loading, deployment or
runtime wiring is authorized. Fixture DB migrations and loopback mocks are allowed
only within the declared tests.

The author/repair conversation may remain attached to the A1 checkout. This fresh
audit targets the progress checkout explicitly. Do not move historical conversations,
substitute A1 as target, synchronize another checkout or bypass permissions. Use
explicit cwd/absolute paths. After this independent audit ends and reviewers close,
the same foreground conversation may perform a later separately instructed repair
or commit; it is not permanently audit-only.

## 1. Exact target and provenance

    root / Git top-level:
    /Users/ds/Repositories/ES-Private-Replay-Progress-v1

    Git/common directory:
    /Users/ds/Repositories/ES-Private-Replay-Progress-v1/.git

    branch: codex/private-replay-progress-v1
    upstream: origin/trunk_dev
    origin: git@github.com:evo-agi/Execution-Substrate.git

    HEAD: f1aa8b934cc26c16a966a110c7b408abdaeadce7
    sole parent: fb9ae55797d9fcc02863c23fe8d3e43d16eac542
    HEAD tree: 8dd27f9acba98ed70d93736bdef8300ef1aba53f
    HEAD subject: Harden original-key read transaction cleanup (A1) (#10)

    baseline: 427 tracked leaves
    candidate: 27 unstaged tracked modifications + 3 authorized untracked files
    400 other tracked leaves HEAD-identical; 430 total source leaves
    index: HEAD-identical
    zero staged, unmerged, deleted, renamed, type-changed, ignored or extra paths
    all thirty candidate source rows: regular 0644 (Git 100644 when tracked)

    repaired canonical manifest (Appendix B): 6813 bytes
    0812091529c67f4bc46d0bc343b3dea8595e63a461264e143d51606e581e0c06
    tracked full-index HEAD diff:
    68339ba85b7b22d86bdaa21ed4fdccebc5021f82912344e0507862d1624cb791

    exact recipe (Appendix C): governed-execution.audit-patch-manifest.v2
    7275 bytes
    c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca

The three EXPECTED ordinary-untracked source files:
    es/admission/internal/reliablesubmit/replay_progress_test.go
    es/admission/internal/reliablesubmit/sqlite_pooled_claim_read_cleanup_test.go
    es/admission/internal/reliablesubmit/sqlite_replay_progress_schema.go

Do not require the ordinary-untracked query to be empty and do not stage those
files to make the tracked diff complete. Authenticate their full bytes separately.

Author-host repaired packet:
    /Users/ds/Repositories/ES-Private-Replay-Progress-Consolidated-Repair-20261119-S2jmvkfy/ES-Private-Replay-Progress-Consolidated-Repair-Review.zip
    900863 bytes
    e3cac3bc27bbfd8c1c18d1abf3aabc00077e632e14bd6e6b92e26e020c9c1be6

Archive identities:
    44 regular entries: 30 complete source files and 14 metadata/evidence files
    rejected-to-repaired.patch:
    cd1ddb5b23d124c931c449e7a09bd81e3d6e5307d105d3d19eeca179a5a068c5
    source-map.json:
    fa58e64ecf8c2872bd8ff29357fa2266108e98df272344a349b061f39f784d23
    delivery-inventory.json:
    c2a2b842265eace578bfe61a5944b1c91826194f17129ea691bd88a6dde419a1

Rejected packet:
    /Users/ds/Repositories/ES-Private-Replay-Progress-Implementation-20261119-kadgzy4t/ES-Private-Replay-Progress-Implementation-Review.zip
    718150 bytes
    bc4bc721f7aa0f02da9f2427625973e883a82fdc0988e4f587c2140792245cf3

Rejected manifest: 6813 bytes
    110cef71ba25f61b70297b37cc5a50a68732d639845e0ac4315d06cedcdbc1e3
Rejected tracked diff:
    e45e3bd85391191702673b2d40fc2d06d865503004e09a8094c2f6a7081fe0c4

Require exactly 17 repaired rows and 13 unchanged rows versus the rejected manifest,
and the same 30-path set. Use the exact source-map rows, not a copied count alone.
No new repository path, stored-format change or migration literal was authorized
by the repair. Audit the original implementation against pinned HEAD as well as
the seventeen-row repair delta; an unchanged row is not automatically accepted.

### 1.1 Explicit report transcription adjudication

Appendix A is the COMPLETE UNMODIFIED transported repair report. Its inline JSON
has one malformed 66-hex-character SHA-256 for:

    es/admission/internal/reliablesubmit/replay_custody_structure.go

The actual archived canonical manifest and full file are correct. The exact
18640-byte source and both old/new archives reproduce:

    4916268757b93d409cbc13ba9c0da14e009499b4db7cadd52bc7ccd47c6a86ad

The pasted JSON canonicalizes to 6815 bytes / SHA-256
    adc82e9b55e088a33b66e72c75cadda4835f81e82c94cdac8abb1856bc33f7b8
whereas Appendix B is the archived 6813-byte target above. All other JSON fields
agree. Preserve Appendix A and the historical report; do not edit either.
Appendix B and the authenticated archived manifest are the explicit audit target.
This is a disclosed transport transcription error, NOT a recipe transition,
source rebaseline, waiver for live drift or permission to synthesize target bytes.
Reproduce the target from actual source. Do not stop merely because the known
bad pasted field remains in Appendix A; do stop on any additional unexplained
discrepancy, actual file mismatch or failure to reproduce Appendix B.

No separate writer/report-reissue turn or validation rerun is required merely
to correct that pasted field. Include this disposition in the audit closeout.

### 1.2 Opening and closing gate

Authenticate Appendix C before executing an audit-owned copy. Run it twice from
the actual progress checkout to two absent outputs outside the repository.
Require exact Appendix B bytes. Independently read every candidate file, file
mode, index entry and all 430 source leaves, including the 400 unchanged base
leaves. Check physical root and Git/common directory, named branch/upstream,
HEAD/parent/tree, index and both untracked categories. Stop before judging source
with AUDIT_PROVENANCE_MISMATCH if the actual target differs.

Record scoped refs/config at audit opening and closing and do not write them.
The repair disclosed a different historical all-ref fingerprint from its own
opening. A global historical ref-set hash is NOT an extra opening gate. Classify
any relevant observed ref difference; do not demand rewriting Codex-managed refs
or unconnected refs to reproduce a historical aggregate. The named source
identities and byte/index target above remain mandatory.

Remote observation is unnecessary. Do not fetch or treat later remote-base drift
as a local patch mismatch. Publication reconciliation is a separate future gate.

## 2. Material evidence and governing contracts

Read AGENTS.md, candidate and HEAD PLANS.md, the three changed lifecycle owner
documents and relevant system boundary/capability/security guidance. Inspect
source, tests, schemas/migrations, go.mod/go.sum, pinned Go/SQLite behavior where
needed, relevant startup/config/App/API callers and script/example exclusions.
Do not execute repository scripts to inspect them.

Owners:
    .docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md
    .docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md
    .docs/execution_lifecycle/es_execution_admission_model.md

Classification: private Bounded slice rule on the reliable-submit Reopened redesign
seam, limited to synthetic_progress_nonoperational_v1. Preserve the accepted
original/progress split, one ES claim/key/grant domain, global caller/key occupancy,
one attempt and assigned run, existing durable service as semantic writer, SQL as
physical constraints/CAS, legacy codec-1/2 semantics and immutable codec 3.
K1 separates invocation knowledge from later explicit fixture commands; the
operational §8 predicate remains unimplemented by this facade. R1 retains history
without freezing future progress; R2 covers both allocator callers; R3 keeps the
two old-binary probes distinct. Preserve public refusal, unkeyed Submit and
separate Coordinator authority. No fixture result is provider acceptance proof.

Repair material root:
    /Users/ds/Repositories/ES-Private-Replay-Progress-Consolidated-Repair-20261119-S2jmvkfy
    private repair-report.md:
    fc6c9e1b1eb67cf63a9405ff6e105fddc326dbb5406816c72169c067068a6a0e
    artifact-inventory.json:
    ab93206822178e51b74b30cd1edd607bbb45390b3a0ebf5084f9813dc8b59792

Prior independent rejection root:
    /Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42
    audit-report.md:
    b26b4be5f09d067184c9a00f837c20cabb200438230b2b86bdcefdc24d1e24c1
    artifact-inventory.json:
    20bd8b3c998e6865490ea606281ea05788fe8987244857425fce5e97f8cb6879

Authenticate/read the report/index and only relied-upon records:
- both current manifests, source map, packet inventory and rejected archive;
- four primary red and green construction/run records and exact source inputs;
- original independent SR-1/SR-2 diagnostic as historical failed evidence;
- generation-1 failed migration gate, generation-2 freeze, all eleven raw results,
  immediate guards and parsed identity/skip reconciliation;
- N-1 two source additions, full view/command, build-input inventory and raw log;
- material migration, old-probe and frozen-body/source preservation records;
- retained pooled-reader differential insofar as used for full-slice acceptance.

Do not rehash every historical evidence universe or demand an artifact that never
existed. The original implementation root had no standalone report/index; its
packet, transport and generation records were the material records. Private and
transport report renditions can have different hashes; their decision facts must
agree after the explicitly adjudicated transcription error.

No in-place imports of verifier code in prior evidence roots. Authenticate and
copy required verifier bytes into this audit's private root before execution with
Python bytecode disabled. Prior timestamps/inode allocation are not provenance gates.

## 3. Four independent source perspectives

After provenance matches, spawn exactly four bounded READ-ONLY reviewers with the
same exact canonical target, owner contracts, prior rejection and explicit repair
selection. No nested agents, no mutations and no concurrent test execution.
The foreground parent owns all validation, synthesis and final disposition.

1. SQLite transaction/migration reviewer:
   M-1/M-2, current/old-head/bootstrap qualification, writer-lock observation,
   rollback/COMMIT unknown handling, recovered-old/new paths and full preservation.
   Recheck pooled cleanup and historical A1/O2/C1/D1 boundaries without expanding
   the slice. Inspect pinned driver behavior where an actual claim relies on it.

2. Custody, security and lifetime reviewer:
   SR-1 plus pending-callback use, R2-1, full shared allocator exits, issuer/context
   one-use enforcement, exact retained keys, no raw projection on refusal, filesystem
   identity, AEAD/parser budgets, Close and modeled disposal limits.

3. Durable/admission semantic reviewer:
   SR-2, K1-1, T-1, exact replay versus fresh no-op, current predicate versus retained
   historical tuple, typed fixture evidence, known outcome versus withheld projection,
   original-preserving successor, concurrent CAS and K1 no retry/hidden history.

4. Tests/evidence/effect-boundary reviewer:
   maintained regressions, real versus modeled faults, red adapters and source binding,
   N-1 admission bridge and counters, all constructor/caller inventories, skip and
   generation reconciliation, old probes and public/startup/runtime exclusion.

All perspectives must finish source review even if a blocker is found, so a later
repair can use one consolidated list. Preserve dissent and limits; parent independently
checks load-bearing findings. Close all reviewers before final response. If a required
perspective is unavailable, report the missing review honestly rather than claiming
four independent reviews.

## 4. Required adjudication of each prior finding

Use the actual owner text and complete code paths. Do not merely check that a new
test with a finding's name exists.

### M-1/M-2 and generation-2 recovery
Verify every migration write uses the actual lock-held opening app ID/version,
schema and ledger/pristine condition, not preflight. Re-read before writes and
capture recovery baseline only there. Confirm authentic competing-current-head
behavior: no unnecessary migration writes, known cleanup and no nested BEGIN.
Verify literal ASCII sqlite_ prefix handling at both pristine/digest boundaries
without changing migration literals, digest encoding or authentic constants.
Independent witnesses must not reuse the flawed exclusion.

Generation 1 failed before-COMMIT recovery cases, then changed migration handling.
Inspect the FINAL functions end-to-end: begin ownership, precommit rollback,
request-independent cleanup/expiry observation, post-COMMIT uncertainty, wrapper
already closed, unpublished pool closure and one checked nonmigrating read. Do not
infer physical close from a sentinel or ignore lost capacity. Do not authorize
success/known noncommit without the owner-required evidence. Preserve inherited
logical-preservation versus physical-byte qualifications.

The maintained tests use the existing clock collaborator to order a second
SQLite writer. Confirm this reaches the intended between-preflight-and-lock
boundary and actual disallowed-state refusal, not just a setup failure. Include
ordinary 0–4, invalid app/ledger/schema/version, foreign bootstrap, legitimate
competing head, lost response and old-state recovery controls. The three
generation-1 interrupted cases are included in ordinary package runs and must
be accounted for explicitly in this audit.

### SR-1 and borrow lifetime
Establishment confirmation must check retained active-or-retired key pair and
live access after issuer-lock acquisition and again after the key/qualification
boundary, before snapshot projection. Revoked/missing/mismatched keys refuse;
known COMMIT remains Committed, uncertain failure remains WriteUnknown, and both
withhold projection. Preserve allowed committed-snapshot selection independently
of current-key eligibility. Ordinary-current read remains a control.

Verify both binding/envelope revocation-before-method-entry, active/retired controls,
known and recoverable-unknown establishment, callback return/cancellation after
initial consumption while blocked on issuer lock, closed/copied/foreign access,
and no mutation of original/row. Late observed revocation refusal is not a promise
of instantaneous revocation across processes. Do not require an unselected stronger
atomicity between the final observation and return.

### SR-2
Check current recording predicates for every codec-4 reconciliation kind BEFORE
fresh same-fact no-op, but preserve latest replay/conflict/stale ordering and
legacy behavior. Historical tuple storage remains valid after progression.
Cover pending/ambiguous/inconsistent after incompatible provider and both
terminals, eligible no-ops, no-marker and terminal corroboration, negative
reconciliation without provider, exact latest, changed-input conflict and stale.

### K1-1
A definitely losing establishment must retain Occupied when later winner lookup,
original key selection, authentication, cancellation or unavailable disclosure
fails. Proved changed intent remains Conflict; valid winner projection remains
Occupied. The mapping must be local to this definite-loser branch, not generic
unauthenticated existence or write-unknown paths. Inspect deterministic disjoint
catalog, unavailable winner, equivalent winner and changed-intent race controls.
No second write, new Seal or re-resolution is allowed during recovery.

### T-1
Verify the narrow owner-doc refinement: synthetic terminal assertion, not independent
provider observation. The redacted value has private claim/run/marker/fact/outcome/
receipt fields; accepted evidence owns an exact receipt association, negative owns
none. Validate independently constructed evidence before relying on replay/no-op,
while keeping candidate-phase checks after legitimate exact replay.
Test receipt/command substitution, opposite polarity, zero/malformed discriminator,
wrong attempt and negative fact, valid terminal/restart replay, immutable receipt and
opposite terminal refusal. Constructors must have no production call sites.

Inspect the retained rejected-interface test adapter and altered malformed-value
helper. Its old interface has no outcome/receipt fields; do not pretend those
fields were dynamically corrupted in old code. Confirm adversarial representable
commands/assertions remain comparable, and source generation/compile input binding
is sufficient for the claimed regressions. No compile failure is a red proof.

### R2-1
Restore scope-1 custody/parents/frozen/permit-presence preflight BEFORE burn, then
retain burn for an eligible attempt including qualified foreign issuer and
allocation failure. Scope-2 wrapper burn remains selected. Verify legitimate
issuing-handle first use remains possible after ineligible preflight but not after
an eligible failed attempt; no reservation refund, adoption or second publication.
Keep both shared allocator callers and counted-orphan/FD-transfer rules.

### N-1
Independently run the bound admission-level witness from an AUDIT-OWNED source view
with all 430 actual candidate leaves byte/mode-identical and only these two added
diagnostic files:
    es/admission/internal/reliablesubmit/admission_unknown_witness_bridge.go
    es/admission/reliable_submit_admission_unknown_witness_test.go

The additions are exact Appendices F/G, also in the packet:
    bridge 789 bytes:
    14f0e9e92a37e1d1bf624f1f052a62a6d56e5b82f988698abbf6e1b5bcf9196d
    witness 5897 bytes:
    8da31dd61c9af2537c15f4376a330d05cb2e55dd2efd0ea610472a0c6ffa5c6a

Authenticate:
    evidence/n1-view-command.json:
    942000138cc35778e4eb175d9be01737fe6f95af790f84233335fc3e2fa7340a
    evidence/n1-build-inputs.json:
    a84ab3946242c1b026ef6d8d14af09776aaf0be6d501d25abbc9d39b7296913c
The latter contains 2801 recorded physical inputs / 291 package records.
The former binds final manifest and 432-file view, and records five pass identities.
Neither JSON replaces a raw log or fresh execution.

The bridge may only attach/restore the selected per-store existing hook. It must
execute real COMMIT then model response loss; it must not replace production
outcome mapping or successful projections. In both establishment and AssignRun,
check canceled/unavailable recovery (WriteUnknown + zero projection), exact
authenticated readback (OwnCommitConfirmed), later current read without rewriting
the earlier disposition, one intended real COMMIT, zero provider/staging/EGS
contacts and empty operational roots. Fault hooks clear before healthy follow-ups.
The bridge is absent from actual source, ordinary tests and product manifest.
Do not broaden it into a shipping fault API.

## 5. Whole integrated slice and inspection limits

Review original replay/intent-conflict privacy, one claim/rowid/original descriptor
across durable transitions, strict finite format dispatch, canonical commitments,
key purpose/fingerprint/lifecycle, grant use and shared budgets, full migration
logical preservation, startup/public API refusal and no runtime reachability.
The selected tuple semantics and K1 fixture-versus-operational split are not
automatically reopened because implementation defects existed.

Check all exact typed synchronization and constructor references, not merely the
advertised count. Workstream C stayed byte-identical in this repair. Its earlier
32 typed entries were one mutex, three atomic flags and 23 references/request
fields added to five existing entries, not 32 new locks. Direct-selector mutants
are bounded and do not by themselves prove arbitrary transitive closure; inspect
the actual call graph and alternate spellings rather than claiming a whole-program
guarantee from that helper.

Verify migration literal files 1–4, operation/record formats, frozen 13 rows, and
loadClaimFresh body (1077 bytes INCLUDING its trailing blank separator):
    3a47f8b5e0c5bf7bec899987aa78fdf4ef48a585086d9eb975e576896ab4b61c
Do not conflate a whitespace boundary difference in a separately selected excerpt
with source drift. Compare the full source function against HEAD/rejected source.
Inherited behavior and physical disposal qualifiers must remain explicit.

This audit must assess the complete repaired target, not declare the 13 frozen
rows accepted because this writer did not change them. Earlier reviews can supply
authenticated context; the complete integrated judgment is yours.

## 6. Environment, permitted effects and evidence hygiene

Create one fresh private external root under `/Users/ds/Repositories` using an
exclusive temp-directory operation, e.g.
    ES-Private-Replay-Progress-Repair-Independent-Audit-20261119-<unique>
Root/subdirectories 0700, retained regular evidence 0600; preserve source modes
within private external parents. Do not chmod /Users/ds/Repositories or old roots.
Transient copied probe executables may be owner-executable while run, then 0600.

Use Python -B with PYTHONDONTWRITEBYTECODE=1; never import prior-root scripts in
place. Copy authenticated verifier source first. Do not restore timestamps or
require volatile mtime/inode equality. Remove only audit-created scratch/cache/
fixtures. Existing test-owned /tmp or /private/tmp fixtures, helper processes,
loopback mocks, test certificates and disposable Git repositories are permitted
within the maintained suite; disclose their bounded cleanup. No global tmp sweep.

Pinned Go and sibling gofmt:
    /Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go
    /Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/gofmt

Preflight actual Go 1.26.5, Python 3.13 with tomllib, OpenSSL 3 (reported 3.6.2),
and Git executable paths, versions and hashes. Do not repeat the earlier ambient
Apple Python/LibreSSL resolution error. Record safe explicit environment only:
    GOTOOLCHAIN=local
    GOPROXY=off
    GOSUMDB=off
    GOWORK=off
    GOFLAGS=-mod=readonly
    CGO_ENABLED=0
    GOTELEMETRY=off
    GOMODCACHE=/Users/ds/go/pkg/mod
    GIT_OPTIONAL_LOCKS=0
    GIT_NO_LAZY_FETCH=1
    GIT_TERMINAL_PROMPT=0
    PYTHONDONTWRITEBYTECODE=1
    audit-owned GOCACHE, GOTMPDIR, TMPDIR
    outer umask 077; Go-test subprocess umask 027

Authenticate and reuse audit-owned copies of the two DISTINCT retained probes:
    historical PB1/schema-2: 14350930 bytes
    b205a31bac091cbcf5b3f4826bc359455625316908051131733622813e34adcf
    previous schema-3 opener: 15601186 bytes
    42614a50812a65ba52b53488d872884e59ce7b4f57dece6a66642d4eb8de1409
Authenticate the schema-3 original 427-leaf source export, one test-only overlay,
1354-input compiled inventory
    50a81fa5a042e135abfc9f6bad68d20abc4575f881945ecc84252c14910dde8f
and material historical PB1 build/source bindings. Do not rebuild either binary
from this candidate or relabel one as the other. Use ES_REPLAY_PB1_PROBE and
ES_REPLAY_SCHEMA3_PROBE bound to the copies; tests supply child target env vars.
The old binaries prove their original version-refusal purposes, not the repaired
opener's new qualification semantics.

Existing test-only local Docker capability checks are permitted; absent capability
must remain a recorded skip, not native qualification. Do not start a live stack
or execute now-available operational tests without authority. Stop/classify that
scope conflict rather than silently skip a required available case or enable it.

## 7. Independent validation and continuity

Before any product command, validate the guard against the exact source/index
target. At opening, after EACH command and external experiment, and closeout:
- all 430 candidate leaves, full bytes and modes;
- branch, upstream, HEAD and index equal frozen opening;
- unstaged thirty-path classification;
- `git ls-files --others --exclude-standard -z` equals the three authorized files;
- `git ls-files --others --ignored --exclude-standard -z` is empty;
- no extra path, unmerged entry or generated artifact.
Record separate executed checkpoint/command associations. Identical deterministic
hashes across checkpoints can be correct, but copying one result is not repeated
observation. Also guard all 432 external source-view files around command 11.

Authenticate generation-1 failures and intermediate engineering corrections as
history. Final generation 2 binds the candidate. Compare actual test identities,
not counts alone. Do not portray different red/green selector breadth or a
test-only old-interface adapter as identical total inputs. Compare the matched
assertions and explicit adapters. No history-only complete compile ledger is to
be invented; identify exactly which source/input facts were retained and whether
fresh independent evidence supplies any necessary present acceptance fact.

Primary sequence: all eleven commands below, serially, once on frozen source.
Commands 1–10 run in the ACTUAL progress checkout, with no bridge or overlay.
Command 11 runs in the audit-owned 432-file N1_SOURCE. Keep its actual fresh cwd
and environment, not the author's retained source view.

If a substantive blocker is independently confirmed, finish all source perspectives
and consolidate findings. You may omit broad gates 9/10 that cannot change REJECT;
explicitly inventory each unrun command. A bounded N-1 or finding-specific diagnostic
may still run for a distinct material conclusion. Do not claim a complete ordered
eleven-gate replay in that case. ACCEPT requires all eleven commands, all mandatory
parents, no new bounded-path skip, a complete source judgment and closing provenance.

New independent fault instrumentation is permitted only in explicitly inventory-bound
external source copies when required to confirm/refute a concrete finding. It must
not repair production behavior, manufacture test success, change the repository or
turn into a general fuzzing/OS-close/socket calibration campaign. Preserve all
attempts and separate fixture setup failures from substantive candidate outcomes.
A corrected setup may run as a new declared generation; substantive failure cannot
be rerun away. Any candidate-byte change belongs to a later writer turn and fresh
independent acceptance.

```sh
# Commands 1–10: cwd=/Users/ds/Repositories/ES-Private-Replay-Progress-v1
# Set N1_SOURCE to the authenticated AUDIT-OWNED external view before command 11.
GO=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go
GOFMT=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/gofmt

"$GO" version
"$GOFMT" -d docs_contract_test.go es/admission/internal/reliablesubmit/sqlite_store.go es/admission/internal/reliablesubmit/sqlite_replay_claim.go es/admission/internal/reliablesubmit/sqlite_migrations.go es/admission/internal/reliablesubmit/sqlite_replay_progress_schema.go es/admission/internal/reliablesubmit/sqlite_replay_shape.go es/admission/internal/reliablesubmit/durable_record.go es/admission/internal/reliablesubmit/durable_operation.go es/admission/internal/reliablesubmit/durable_service.go es/admission/internal/reliablesubmit/replay_custody_format.go es/admission/internal/reliablesubmit/replay_custody_structure.go es/admission/internal/reliablesubmit/replay_custody_file.go es/admission/reliable_submit_replay_format.go es/admission/reliable_submit_replay_hydration.go es/admission/reliable_submit_replay_private.go es/admission/internal/reliablesubmit/sqlite_pooled_claim_read_cleanup_test.go es/admission/internal/reliablesubmit/replay_progress_test.go es/admission/internal/reliablesubmit/replay_custody_file_test.go es/admission/internal/reliablesubmit/sqlite_store_test.go es/admission/internal/reliablesubmit/sqlite_physical_test.go es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go es/admission/internal/reliablesubmit/sqlite_replay_shape_test.go es/admission/internal/reliablesubmit/guardrails_test.go es/admission/reliable_submit_guardrails_test.go es/admission/reliable_submit_replay_private_test.go es/admission/workstream_c_guardrails_test.go
git --no-pager diff --check
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateOriginalReplayProgressContractSelection|TestReliableSubmitPersistenceAndConcurrencyADRDocsContract|TestSubmitIdempotencyCorrelationAndRecoveryDocsContract|TestReliableSubmitPureModelDocsAndSourceContract|TestReliableSubmitPublicOptInAndVersioningDocsContract|TestReliableSubmitContractAdapterFoundationDocsAndSourceContract|TestReliableSubmitBindingProducerDocsContract|TestIntegratedAcceptanceGateDocumentationIsConsistent|TestIntegratedCandidateStatusSeparatesCAndT)$' .
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestSQLitePooledClaimReadCleanup$' ./es/admission/internal/reliablesubmit
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateReplayProgressConfirmationEligibility|TestPrivateReplayProgressReconciliationEligibility|TestPrivateReplayProgressTerminalEvidenceBinding|TestSQLiteMigrationOpeningRevalidatedUnderLock|TestSQLiteLiteralInternalNamespaceQualification|TestPrivateReplayScope1PublicationPreflight|TestPrivateReplaySharedObjectAllocation|TestReplayPublicationFaultAndIdentity|TestPrivateReplayProgressFormatVectors|TestPrivateReplayProgressTransitions|TestPrivateReplayProgressConcurrencyAndCommitOutcome|TestSQLiteV4MigrationPreservesFullState|TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation|TestSQLiteV3OldBinaryRefusesWithoutMutation|TestSQLiteLegacyCASConnectionCleanup|TestReplayOriginalKeyReadCleanup|TestReplayOriginalKeyReadCallerRefusal|TestReplayGrantC1PreCommitConnectionQuarantine|TestReplayGrantD1BeginResponseLossQuarantine|TestReplayKeyStateD1BeginResponseLossQuarantine|TestReliableSubmitPrivatePersistenceStaticGuardrails)$' ./es/admission/internal/reliablesubmit
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateReplayProgressOccupiedDisposition|TestPrivateReplayProgressAdmissionReplay|TestPrivateReplayProgressHasNoEffectPaths|TestReliableSubmitFoundationHasNoRuntimeWiring|TestReliableSubmitBindingProducerHasNoProductionCaller|TestPrepareRequestShapeRemainsLegacyAndUnkeyed|TestResolvedSubmitLegacyEquivalenceOneNomadRegistrationAndAuthorityRecovery)$' ./es/admission
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestWorkstreamCContractPrepareAndSubmitRemainSeparatedAtAPIBoundary|TestSubmitPublicRouteRejectsStructuralReliableBody)$' ./es/api ./es/app
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=600s ./es/admission/internal/reliablesubmit ./es/admission ./es/api ./es/app
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=600s ./...
(cd "$N1_SOURCE" && "$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestPrivateReplayProgressAdmissionUnknownNoEffects$' ./es/admission)
```

Reported generation-2 expectations (not forced numeric oracles):
    contract 22/0/0
    pooled reader 16/0/0
    internal focused/probes 208/0/0
    admission 24/0/0
    App/API 2/0/0
    four-package suite 2049/0/39
    full repository 5174/0/39; 21 tested packages, 20 no-test packages
    external N-1 5/0/0 (one parent, four leaves)
The ordinary full suite adds 72 internal and six admission identities over 5096,
removing zero. N-1's five are separate. The 39 skips are 37 App capabilities and
two direct helper sentinels, not 39 unqualified successes. Prove the shared
allocator helper actually ran under its parent and retain exact skip names/reasons.
Any discrepancy needs an evidence-based disposition; do not change assertions or
expected source bytes solely to match a count.

## 8. Closeout and sole verdict

Rerun the exact recipe twice after audit-owned scratch cleanup, outside the
repository, and match Appendix B. Recheck scoped source/index/ref/config continuity
and relied-upon prior artifact content. No historical root-wide metadata campaign.

The complete safe human-readable audit report MUST be inline. Include:
- exact source/manifest identity and transcription adjudication;
- a reasoned disposition for each of the eight findings, including dynamically
  observed versus source-only conclusions;
- each independent perspective, material dissent and parent adjudication;
- every exact command/cwd/exit, test/package/skip evidence, and unrun validation;
- generation-1 failure and any new attempt classifications;
- the N-1 external-view/digest/build/effect evidence and bridge exclusion;
- historical compatibility, migration literal/shape identities, retained key and
  original boundaries, no-effect trace and physical-resource qualifications;
- artifact locations/hashes, scope limits and all performed/unperformed effects.

A duplicate private report/index may supplement but cannot replace inline delivery.
Do not issue a readiness/acceptance verdict with only a path. On genuinely blocked
complete safe report transport, use REPORT_INLINE_BLOCKED rather than a verdict.

Exactly one final audit verdict:
    ACCEPT
    BLOCK
    REJECT
    AUDIT_PROVENANCE_MISMATCH
ACCEPT means these exact bytes may later enter a separately instructed local commit
gate. It is not permission to stage or commit now. No partial acceptance of a repair
row can authorize the full thirty-path patch.

Preserve these nonclaims in all dispositions:
    SOURCE_REPOSITORY_NOT_MUTATED
    SOURCE_REFS_NOT_UPDATED
    STAGING_NOT_PERFORMED
    COMMIT_NOT_PERFORMED
    PUSH_NOT_PERFORMED
    PRS_NOT_MODIFIED
    EXISTING_OTHER_SOURCE_CHECKOUTS_NOT_SYNCHRONIZED
    CROSS_RESTART_OPERATIONAL_WRITE_UNCERTAINTY_GATE_NOT_IMPLEMENTED
    RUNTIME_WIRING_NOT_PERFORMED
    PUBLIC_RELIABLE_SUBMIT_NOT_ENABLED
    NATIVE_INSTALLED_SOURCE_WITNESS_NOT_QUALIFIED_BY_THIS_SLICE

## Appendix transport

Each appended payload is exact UTF-8 bytes between its BEGIN/END markers.
Extract exactly the declared byte length immediately after the BEGIN line.
An added separator newline immediately before END is not part of the payload.
Keep the supplied report unchanged, including its explicitly adjudicated bad field.
| Appendix | Bytes | SHA-256 |
|---|---:|---|
| A: Complete unmodified transported consolidated repair report | 30813 | `be17b2ff7f0c9677f50cd890dc286dfc77e5349443b34824a79f021151f6a88a` |
| B: Exact repaired canonical manifest from authenticated ZIP | 6813 | `0812091529c67f4bc46d0bc343b3dea8595e63a461264e143d51606e581e0c06` |
| C: Exact v2 recipe source | 7275 | `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` |
| D: Complete prior independent REJECT | 32151 | `da618d64527ed921138be23cc764d23012531f584769ab40e4fb968fb7844e5b` |
| E: Exact-source review and transport adjudication | 14017 | `c221655907ae2a2b88496be056270a410cfe192635ce32133e3ba6e6bf30fe56` |
| F: Exact external internal-package N-1 bridge | 789 | `14f0e9e92a37e1d1bf624f1f052a62a6d56e5b82f988698abbf6e1b5bcf9196d` |
| G: Exact external admission N-1 witness | 5897 | `8da31dd61c9af2537c15f4376a330d05cb2e55dd2efd0ea610472a0c6ffa5c6a` |


## Appendix A — Complete unmodified transported consolidated repair report

<BEGIN_APPENDIX_A>
The consolidated repair is ready for a fresh independent audit. All eight findings have repair evidence, and all eleven final commands passed on the same frozen source. The checkout remains unstaged and uncommitted.

[Review ZIP](/Users/ds/Repositories/ES-Private-Replay-Progress-Consolidated-Repair-20261119-S2jmvkfy/ES-Private-Replay-Progress-Consolidated-Repair-Review.zip) · **900,863 bytes** · SHA-256 `e3cac3bc27bbfd8c1c18d1abf3aabc00077e632e14bd6e6b92e26e020c9c1be6`. The ZIP is local and requires upload.

## Repair dispositions

| Finding | Repair and verification |
|---|---|
| **M-2 · SQLite namespace** | Bootstrap and schema digest share a literal seven-character `sqlite_` prefix check with ASCII `NOCASE`. The rejected code admitted the collision table, mixed-case index and mixed-case view. The repair refused them and preserved the independently queried schema, pragmas, ledger and contents. Authentic schema hashes 1–4 and ordinary foreign-name refusal held. [Schema predicate, lines 22–28](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_replay_shape.go:22) · [Bootstrap qualification, lines 744–757](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_store.go:744) |
| **M-1 · Migration opening authority** | One migration transaction revalidates the actual opening state under `BEGIN IMMEDIATE` before allowing writes or recording the recovery baseline. The existing clock collaborator deterministically ordered an independent SQLite COMMIT before acquisition. The rejected code overwrote version 99 and a changed trigger, adopted a nonempty bootstrap and failed on a valid competing head. The repair preserved the disallowed states and opened the authenticated competing head without migration writes. Authentic 0–4 and historical recovery controls passed. [Opening check, lines 550–591](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_store.go:550) · [Transaction, lines 662–742](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_store.go:662) |
| **SR-1 · Confirmation eligibility and lifetime** | Confirmation checks the live borrow after taking the issuer lock, verifies the exact original key pair and rechecks lifetime before projecting the committed snapshot. Revocation of either key before read entry withheld projection for both known COMMIT and modeled lost-response establishment. Known `Committed` and unresolved `WriteUnknown` survived the refusal. Active, retired and ordinary-current controls passed. The lifetime test observed initial consumption, held the issuer lock across callback return or cancellation, then released the in-flight read. It disclosed no progress. Rows and sealed bytes stayed equal. [Confirmation, lines 1344–1370](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/replay_custody_file.go:1344) · [Regression](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/replay_progress_test.go:1129) |
| **SR-2 · Reconciliation eligibility** | Fresh codec-4 same-fact reconciliation checks the present predicate for every kind before returning `NoChange`. Exact latest replay, mutation conflict and stale classification keep their order. Pending, Ambiguous and Inconsistent each refused after incompatible provider progress and after either terminal decision. Other-kind controls, eligible no-ops and replay controls passed. The historical tuple, row and seal stayed equal. [Current predicate, lines 833–857](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/durable_service.go:833) · [Regression](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/replay_progress_test.go:1304) |
| **K1-1 · Definite occupied disposition** | A definite establishment loser retains `Occupied` when winner disclosure fails. Separate catalogs and an unavailable winner object reproduced generic refusal on the rejected bytes. The repair returned occupied with zero projection. Equivalent winner disclosure and proved changed-intent conflict passed. The barrier established two legitimate seals, one revision-1 winner and no repeat of the admission attempt. Both sealed objects stayed equal. [Composer, lines 297–316](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/reliable_submit_replay_private.go:297) · [Regression](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/reliable_submit_replay_private_test.go:980) |
| **T-1 · Terminal fixture assertion** | The owner docs first selected private claim, run, marker, fact, outcome and receipt fields with redaction. The two added internal constructors are `NewFixtureAcceptedEvidence` and `NewFixtureNotAcceptedEvidence`. The service validates polarity and exact same-attempt association before relying on the assertion. Acceptance also compares the independently constructed evidence receipt with the command receipt. Substitution, opposite polarity, malformed evidence, wrong-attempt and valid terminal replay cases ran. The old test-only adapter represents only the common fields available on the rejected interface. The assertions exercise synthetic fixture authority. [Owner contract, lines 1527–1551](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1527) · [Constructors and checks, lines 1137–1185](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/durable_service.go:1137) · [Regression](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/replay_progress_test.go:1423) |
| **R2-1 · Scope-1 permit preflight** | Scope 1 qualifies custody, the frozen value and permit presence before arranging irreversible burn. Closed custody and invalid frozen inputs preserve the issuer’s eligible first attempt. A qualified foreign issuer and an allocation collision still burn. Nil permit, wrong scope, successful publication and second use were exercised. Durable reservation counts stayed equal. [Publication, lines 406–434](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/replay_custody_file.go:406) · [Regression](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/replay_custody_file_test.go:1826) |
| **N-1 · Admission lost-response witness** | The external view adds two diagnostic files to all 430 source leaves. Its bridge attaches and restores the existing per-store COMMIT response hook. Each case executed one real COMMIT and then modeled a lost response. Establishment and `AssignRun` both preserved `WriteUnknown` with zero projection after cancellation and returned `OwnCommitConfirmed` after exact authenticated readback. Later reads returned current revision 1 or 2 while the earlier dispositions held. Each case recorded zero provider, staging and EGS contacts, empty operational roots and one sealed object. [Bound bridge and witness](/Users/ds/Repositories/ES-Private-Replay-Progress-Consolidated-Repair-20261119-S2jmvkfy/g2-final-freeze.json) · [Final witness log](/Users/ds/Repositories/ES-Private-Replay-Progress-Consolidated-Repair-20261119-S2jmvkfy/g2-final-11/stdout) |

The terminal constructors have zero production call sites. The accepted constructor has three internal test call sites and one admission test call site. The negative constructor has two internal test call sites. The aggregate and typed caller checks bind the exact additions. The existing Workstream C inventory remained byte-identical and passed. The direct-selector guard has limits around aliases and free helpers, so the production exclusion also relies on the typed inventory and source trace. [Aggregate guard](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/guardrails_test.go:572) · [Caller guard](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/reliable_submit_guardrails_test.go:13)

## Red and green evidence

The original independent diagnostic remains unchanged at **10 passes and 13 failures**. These are new repair regressions with separately frozen sources, commands, results and post-run guards. The four primary red controls used the exact rejected production bytes.

| Differential | Red result and freeze SHA-256 | Green result and freeze SHA-256 |
|---|---|---|
| M-1 and M-2 | Exit 1, 8 passed, 9 failed. `e25f8ae856e19321d6b64d2de79172557e48d8da6d30e80eb214c0a38d84e950` | Exit 0, 41 passed. `634db6fdbe2fa5299896a5fbf43ebccda074236399e44821ae3c84e39d5bb3f9` |
| SR-1 and R2-1 | Exit 1, 13 passed, 9 failed. `eae1dd1fd46b208e6b9ca5ce6e0900f107a2f4cf983f3237d4cce7d02be7d22f` | Exit 0, 66 passed. `ea1418cabb19e2e1443a2bda3f0824b2adc9801750fea7ecffad3995bb21f0ee` |
| SR-2 and T-1 | Exit 1, 14 passed, 19 failed. `e69291f50c1efea860428225d07bb89b838c259d0bf882ee6063701a53ebb9b2` | Exit 0, 77 passed. `b9c09ba567a18ecb6ae4c5b8e7b79e80eceead31c8915ebd8b1450b8c4b369de` |
| K1-1 | Exit 1, 2 passed, 3 failed. `5aef52678abec9b1ed992edc52e81e300ede38f367a226a3f8af01fb4e311eeb` | Exit 0, 22 passed. `30a4580b3b39a62721e2e6420a5215f2f37db61e0d8a1bb9ed455e13253b812b` |

The first migration red also reproduced the defects, but one ledger setup case failed on a BLOB value in a strict TEXT column. The corrected red supplied an invalid TEXT digest and reached the intended decision. The first custody red ran after the migration edits. Its exact rejected-production repeat is the differential above. The opening shell harness also hit a reserved `zsh` variable after extracting the inputs. The corrected invocation ran both recipe commands and verified the opening source and index. [Regression construction and run records](/Users/ds/Repositories/ES-Private-Replay-Progress-Consolidated-Repair-20261119-S2jmvkfy/regression-construction.json)

**Generation 1 passed gates 1–8 and failed gate 9** with 2,043 passes, 39 skips and six failing identities across three interrupted-before-COMMIT cases and their parents. My initial migration refactor treated an already-closed wrapper as unavailable before the opener could close its unpublished pool and verify the old state. I restored that recovery boundary. The recovery rerun passed 42 identities, then I froze generation 2 and reran all eleven commands. Gates 10 and 11 were unrun on generation 1. [Superseded gate 9](/Users/ds/Repositories/ES-Private-Replay-Progress-Consolidated-Repair-20261119-S2jmvkfy/final-09/result.json) · [Recovery rerun](/Users/ds/Repositories/ES-Private-Replay-Progress-Consolidated-Repair-20261119-S2jmvkfy/m-recovery-fix/result.json)

## Final validation

All generation-2 commands exited **0**. Each had a separately executed immediate guard over all 430 candidate leaves, HEAD, branch, upstream, index and both untracked inventories. Each reproduced guard SHA-256 `35df1bbe8a4063bba09b1feea899d76dfc9aa4861109be53d62e9af40637f1fe`. Command 11 also checked all 432 files in the external view. There were no unrun or failed commands in this generation. [Executed guards and log identities](/Users/ds/Repositories/ES-Private-Replay-Progress-Consolidated-Repair-20261119-S2jmvkfy/validation-summary.json)

| Gate | Result |
|---|---:|
| 1 · Go version | `go1.26.5 darwin/arm64` |
| 2 · Formatting | Clean |
| 3 · Diff whitespace | Clean |
| 4 · Contract | 22 passed |
| 5 · Pooled reader | 16 passed |
| 6 · Internal regressions and probes | 208 passed |
| 7 · Admission | 24 passed |
| 8 · API and App | 2 passed |
| 9 · Four-package suite | 2,049 passed, 39 skipped |
| 10 · Full tree | **5,174 passed, 39 skipped** |
| 11 · External N-1 witness | 5 passed, including four fault cases |

The full tree recorded 21 test-bearing packages and 20 packages without tests. Compared with the retained 5,096-pass implementation, it added 72 internal and six admission identities and removed zero. All 39 skip names matched. The 37 App skips comprise 34 Docker daemon probe failures, one bringup daemon reachability requirement, one healthy-daemon requirement and one direct Docker Unix socket requirement for native qualification. The two helper sentinels were `TestPrivateReplayObjectAllocatorHelperProcess` and `TestSQLiteClaimStoreLockHelperProcess`. The allocator child ran under its parent and logged readiness and its verified outcome. No new repair path skipped. [Exact skip identities and reasons](/Users/ds/Repositories/ES-Private-Replay-Progress-Consolidated-Repair-20261119-S2jmvkfy/validation-summary.json)

Python 3.13.4 with `tomllib`, OpenSSL 3.6.2 and Git 2.49.0 resolved to the pinned local executables. The run used `GOTOOLCHAIN=local`, `GOPROXY=off`, `GOSUMDB=off`, `GOWORK=off`, `GOFLAGS=-mod=readonly`, `CGO_ENABLED=0`, `GOTELEMETRY=off`, and `GOMODCACHE=/Users/ds/go/pkg/mod`. Git optional locks, lazy fetch and prompting were disabled. Python bytecode was disabled. Outer umask was `077` and Go test subprocess umask was `027`. The local Docker daemon capability probe failed. N-1 bound 2,801 physical build inputs from 291 package records before execution and rechecked them at closeout. [Preflight and safe environment](/Users/ds/Repositories/ES-Private-Replay-Progress-Consolidated-Repair-20261119-S2jmvkfy/preflight.json) · [N-1 build inputs](/Users/ds/Repositories/ES-Private-Replay-Progress-Consolidated-Repair-20261119-S2jmvkfy/g2-n1-build-inputs.json)

### Exact final commands

Commands 1–10 ran in `/Users/ds/Repositories/ES-Private-Replay-Progress-v1`.

```sh
GO=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go
GOFMT=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/gofmt
N1_SOURCE=/Users/ds/Repositories/ES-Private-Replay-Progress-Consolidated-Repair-20261119-S2jmvkfy/g2-n1-source

"$GO" version
"$GOFMT" -d docs_contract_test.go es/admission/internal/reliablesubmit/sqlite_store.go es/admission/internal/reliablesubmit/sqlite_replay_claim.go es/admission/internal/reliablesubmit/sqlite_migrations.go es/admission/internal/reliablesubmit/sqlite_replay_progress_schema.go es/admission/internal/reliablesubmit/sqlite_replay_shape.go es/admission/internal/reliablesubmit/durable_record.go es/admission/internal/reliablesubmit/durable_operation.go es/admission/internal/reliablesubmit/durable_service.go es/admission/internal/reliablesubmit/replay_custody_format.go es/admission/internal/reliablesubmit/replay_custody_structure.go es/admission/internal/reliablesubmit/replay_custody_file.go es/admission/reliable_submit_replay_format.go es/admission/reliable_submit_replay_hydration.go es/admission/reliable_submit_replay_private.go es/admission/internal/reliablesubmit/sqlite_pooled_claim_read_cleanup_test.go es/admission/internal/reliablesubmit/replay_progress_test.go es/admission/internal/reliablesubmit/replay_custody_file_test.go es/admission/internal/reliablesubmit/sqlite_store_test.go es/admission/internal/reliablesubmit/sqlite_physical_test.go es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go es/admission/internal/reliablesubmit/sqlite_replay_shape_test.go es/admission/internal/reliablesubmit/guardrails_test.go es/admission/reliable_submit_guardrails_test.go es/admission/reliable_submit_replay_private_test.go es/admission/workstream_c_guardrails_test.go
git --no-pager diff --check
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateOriginalReplayProgressContractSelection|TestReliableSubmitPersistenceAndConcurrencyADRDocsContract|TestSubmitIdempotencyCorrelationAndRecoveryDocsContract|TestReliableSubmitPureModelDocsAndSourceContract|TestReliableSubmitPublicOptInAndVersioningDocsContract|TestReliableSubmitContractAdapterFoundationDocsAndSourceContract|TestReliableSubmitBindingProducerDocsContract|TestIntegratedAcceptanceGateDocumentationIsConsistent|TestIntegratedCandidateStatusSeparatesCAndT)$' .
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestSQLitePooledClaimReadCleanup$' ./es/admission/internal/reliablesubmit
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateReplayProgressConfirmationEligibility|TestPrivateReplayProgressReconciliationEligibility|TestPrivateReplayProgressTerminalEvidenceBinding|TestSQLiteMigrationOpeningRevalidatedUnderLock|TestSQLiteLiteralInternalNamespaceQualification|TestPrivateReplayScope1PublicationPreflight|TestPrivateReplaySharedObjectAllocation|TestReplayPublicationFaultAndIdentity|TestPrivateReplayProgressFormatVectors|TestPrivateReplayProgressTransitions|TestPrivateReplayProgressConcurrencyAndCommitOutcome|TestSQLiteV4MigrationPreservesFullState|TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation|TestSQLiteV3OldBinaryRefusesWithoutMutation|TestSQLiteLegacyCASConnectionCleanup|TestReplayOriginalKeyReadCleanup|TestReplayOriginalKeyReadCallerRefusal|TestReplayGrantC1PreCommitConnectionQuarantine|TestReplayGrantD1BeginResponseLossQuarantine|TestReplayKeyStateD1BeginResponseLossQuarantine|TestReliableSubmitPrivatePersistenceStaticGuardrails)$' ./es/admission/internal/reliablesubmit
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateReplayProgressOccupiedDisposition|TestPrivateReplayProgressAdmissionReplay|TestPrivateReplayProgressHasNoEffectPaths|TestReliableSubmitFoundationHasNoRuntimeWiring|TestReliableSubmitBindingProducerHasNoProductionCaller|TestPrepareRequestShapeRemainsLegacyAndUnkeyed|TestResolvedSubmitLegacyEquivalenceOneNomadRegistrationAndAuthorityRecovery)$' ./es/admission
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestWorkstreamCContractPrepareAndSubmitRemainSeparatedAtAPIBoundary|TestSubmitPublicRouteRejectsStructuralReliableBody)$' ./es/api ./es/app
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=600s ./es/admission/internal/reliablesubmit ./es/admission ./es/api ./es/app
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=600s ./...
(cd "$N1_SOURCE" && "$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestPrivateReplayProgressAdmissionUnknownNoEffects$' ./es/admission)
```

## Provenance and delivery

Both opening executions reproduced the rejected manifest `110cef71ba25f61b70297b37cc5a50a68732d639845e0ac4315d06cedcdbc1e3`. The four prior reviewers were closed before edits. All 430 source leaves, the index and the specified checkout identity matched. The historical all-ref observation differed from the opening observation for this turn. The named branch, upstream, HEAD, parent, tree and index matched the selected gate, and this repair issued no ref writes. [Opening inventory](/Users/ds/Repositories/ES-Private-Replay-Progress-Consolidated-Repair-20261119-S2jmvkfy/opening-inventory.json)

Both closing executions, after scratch cleanup, reproduced the validated **6,813-byte manifest** `0812091529c67f4bc46d0bc343b3dea8595e63a461264e143d51606e581e0c06` using the authenticated **7,275-byte recipe** `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`. HEAD stayed `f1aa8b934cc26c16a966a110c7b408abdaeadce7`, with sole parent `fb9ae55797d9fcc02863c23fe8d3e43d16eac542` and tree `8dd27f9acba98ed70d93736bdef8300ef1aba53f`. The index still equals HEAD. The exact aggregate remains 27 unstaged tracked modifications and three authorized untracked additions, with 400 HEAD-identical tracked leaves and zero ignored or extra paths. [Closing manifest](/Users/ds/Repositories/ES-Private-Replay-Progress-Consolidated-Repair-20261119-S2jmvkfy/close-a.json) · [Closing source inventory](/Users/ds/Repositories/ES-Private-Replay-Progress-Consolidated-Repair-20261119-S2jmvkfy/source-closeout.json)

| Path group | 17 rows changed by repair | 13 rows byte-identical to the rejected candidate |
|---|---|---|
| Repository root and lifecycle docs | `PLANS.md`, `docs_contract_test.go`, `es_execution_admission_model.md`, `reliable_submit_persistence_and_concurrency.md`, `submit_idempotency_correlation_and_recovery.md` | — |
| `es/admission/internal/reliablesubmit/` | `durable_service.go`, `guardrails_test.go`, `replay_custody_file.go`, `replay_custody_file_test.go`, `replay_progress_test.go`, `sqlite_replay_migration_test.go`, `sqlite_replay_shape.go`, `sqlite_replay_shape_test.go`, `sqlite_store.go` | `durable_operation.go`, `durable_record.go`, `replay_custody_format.go`, `replay_custody_structure.go`, `sqlite_migrations.go`, `sqlite_physical_test.go`, `sqlite_pooled_claim_read_cleanup_test.go`, `sqlite_replay_claim.go`, `sqlite_replay_progress_schema.go`, `sqlite_store_test.go` |
| `es/admission/` | `reliable_submit_guardrails_test.go`, `reliable_submit_replay_private.go`, `reliable_submit_replay_private_test.go` | `reliable_submit_replay_format.go`, `reliable_submit_replay_hydration.go`, `workstream_c_guardrails_test.go` |

The unchanged 1,077-byte `loadClaimFresh` function hashes to `3a47f8b5e0c5bf7bec899987aa78fdf4ef48a585086d9eb975e576896ab4b61c`. I checked its independent pool and callers in source and exercised the reader, custody and historical probe tests. Migration literal files 1–4, ledger hashes and all four authentic schema hashes held. The distinct authenticated probe copies ran without rebuild. PB1 refused its schema-3 target, and the previous-schema-3 opener refused its schema-4 target with equal full logical witnesses and both sealed originals. The migration regressions establish logical preservation. SQLite file and sidecar byte equality and physical connection-close timing remain outside those measurements. [Preservation record](/Users/ds/Repositories/ES-Private-Replay-Progress-Consolidated-Repair-20261119-S2jmvkfy/preservation.json)

The ZIP’s 44 regular entries include all 30 complete source files, the tracked HEAD patch, the rejected-to-repaired delta including the changed untracked regression, both manifests, the source map and separate diagnostic evidence. I applied both patches in disposable private copies and verified all 430 modes and hashes. The tracked patch is `68339ba85b7b22d86bdaa21ed4fdccebc5021f82912344e0507862d1624cb791`, the rejected-to-repaired patch is `cd1ddb5b23d124c931c449e7a09bd81e3d6e5307d105d3d19eeca179a5a068c5`, the source map is `fa58e64ecf8c2872bd8ff29357fa2266108e98df272344a349b061f39f784d23`, and the ZIP inventory is `c2a2b842265eace578bfe61a5944b1c91826194f17129ea691bd88a6dde419a1`. [Delivery receipt](/Users/ds/Repositories/ES-Private-Replay-Progress-Consolidated-Repair-20261119-S2jmvkfy/review-receipt.json)

Effects were limited to the target checkout, repair-owned evidence and disposable fixtures. I removed 7,884 cache files and nine task-owned scratch files, and restored the two probe copies to mode `0600`. Other checkouts were outside the write scope. Public structural refusal and the unkeyed path passed. The fixture still supplies no operational dispatch or cross-restart recovery permission. The private report SHA-256 is `fc6c9e1b1eb67cf63a9405ff6e105fddc326dbb5406816c72169c067068a6a0e`. The 2,822-entry self-excluding artifact index SHA-256 is `ab93206822178e51b74b30cd1edd607bbb45390b3a0ebf5084f9813dc8b59792`. [Whole report](/Users/ds/Repositories/ES-Private-Replay-Progress-Consolidated-Repair-20261119-S2jmvkfy/repair-report.md) · [Artifact index](/Users/ds/Repositories/ES-Private-Replay-Progress-Consolidated-Repair-20261119-S2jmvkfy/artifact-inventory.json)

### Exact canonical manifest

```json
{"branch":"codex/private-replay-progress-v1","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/es_execution_admission_model.md","sha256":"b137a82d65da89428c5311f648fc664bea383ff61bf08c7868ec1a0df201016c","size":80816},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md","sha256":"ee2827be90bced19f0660a8378778898cd9970a08ebea49f0a94dfcf6c42d6ea","size":160692},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md","sha256":"1b03cc40b48861c7220a7b85d20b1f8d232690f17460e3eee0df33af4659e3f3","size":103025},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"30c2008df895f1ad9332a5e5e8a36cdea7719300ac52706ead4630a4fabf3e6e","size":301817},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"059a55f9cdac5cd802323aed29cf7a3a68c8a03bddc94b3225c54510903d116f","size":792416},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_operation.go","sha256":"b7761f001a1f67349ed51f2b79012194a7d45bb19c79e0ca2c0c22b8227320f9","size":9548},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_record.go","sha256":"999db7db6550c5031b023a9613825504e30e971a179298cc43e09cf8c5c5d7cd","size":25226},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_service.go","sha256":"ef0bc6f4d125f3986c46901cbe05bc2cb447af7dfbf51cee4653d7ce696c0945","size":49972},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/guardrails_test.go","sha256":"9a300f0553fd6ac3003a048a7309060a4ec6f618eacd94139bd4bb29c011bc60","size":32231},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_file.go","sha256":"61c4006e1e4a3feb7c0ec0e7d4685dc2c3fe8c1e2165d1529d2c86ae8fa137b5","size":50461},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_file_test.go","sha256":"207d9f17658cd50f6c4bea8e293b12abd89455a174b2d96bac84742a66b0afdf","size":69995},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_format.go","sha256":"b8cb8e31edd9d854317a0d6a456f25d5ab1838498623881e429dec2155e1ea67","size":16488},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_structure.go","sha256":"4916268757b93d409cbc13ba9c0da14e009499b4db7c5578f47a6b97b5419545ad","size":18640},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_progress_test.go","sha256":"0952fff321daa368dee1d32ed39a2a5b417e7d2779ae4e1015ab3c12b1021048","size":61314},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_migrations.go","sha256":"7736e30a1d0c6e9584d9050cc6ebf8bfaf900d424f764ebe61af8ec8ddaec0c9","size":17407},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_physical_test.go","sha256":"2c125b6373f83467d542db45473cc79b888ed3a665e65ef6bf013655f461a7ba","size":14539},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_pooled_claim_read_cleanup_test.go","sha256":"0ec3060ed3c30a6327ec49b0291d5c761c20894986c9b6b1e1be384694312823","size":8912},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_claim.go","sha256":"8ddec89b4ca5702591bdf2060062016d7fb54264fc7df57af5ead1d161eb9de3","size":8301},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go","sha256":"188425870bbe4bee37e176c4bee565b6aa61bc27b4a165a2dcf4a0efd6aa6b3c","size":25073},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_progress_schema.go","sha256":"132d8ab87f5658cab3477b9f6913538013ba922d4768192a96be960df7bbb149","size":30612},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_shape.go","sha256":"29cdbba2e5b1fee069989f6e6423dccc1c69c843de22b6504f68a7d199b317be","size":2751},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_shape_test.go","sha256":"3552ea5fafbc59e43cc21b1007486e98da4d59b6d0ea98db92646e0c8478adfb","size":8815},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_store.go","sha256":"f6db4f75bb5324b4459ac8337867d4f7d65f348a85f2f91381c5ab76e5518aea","size":62863},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_store_test.go","sha256":"c99e7659b1059431911557ba43ef7fa982e373bba939f610bd41ea0622cee96f","size":57339},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_guardrails_test.go","sha256":"32de42b7bf8974e36c014d3d9ce6d24e0994fbbc03bb1587c4c4fddd32c80f6e","size":50991},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_format.go","sha256":"0a21803b03308332613481f89ce4b595512b31b073c56b31fe7d8000519c3beb","size":17326},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_hydration.go","sha256":"b5ff16b96178c45b53165ebb2bcbdc67991bb145276ca4a11a598f1430745b9c","size":28800},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_private.go","sha256":"d17927a23a57c808a8f0ebc4bad3e9912e42d7da497033637102bae2c45fd278","size":20440},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_private_test.go","sha256":"4e4e7c7fad2ed2b88b35801841044f4b1f049a4cb6d0435499bb87699467e9f2","size":45171},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/workstream_c_guardrails_test.go","sha256":"68f2fe4e31e5d862be161c3ba1071a511935b32e90cf9021755fe4dcb045fab5","size":297009}],"head":"f1aa8b934cc26c16a966a110c7b408abdaeadce7","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"68339ba85b7b22d86bdaa21ed4fdccebc5021f82912344e0507862d1624cb791","upstream":"origin/trunk_dev"}
```

```text
ES_PRIVATE_REPLAY_PROGRESS_CONSOLIDATED_REPAIR_READY_FOR_FRESH_INDEPENDENT_AUDIT
INDEPENDENT_ACCEPTANCE_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PRS_NOT_MODIFIED
EXISTING_OTHER_SOURCE_CHECKOUTS_NOT_SYNCHRONIZED
LOADCLAIMFRESH_LIFECYCLE_PRESERVED
CROSS_RESTART_OPERATIONAL_WRITE_UNCERTAINTY_GATE_NOT_IMPLEMENTED
RUNTIME_WIRING_NOT_PERFORMED
PUBLIC_RELIABLE_SUBMIT_NOT_ENABLED
NATIVE_INSTALLED_SOURCE_WITNESS_NOT_QUALIFIED_BY_THIS_SLICE
```
<END_APPENDIX_A>

## Appendix B — Exact repaired canonical manifest from authenticated ZIP

<BEGIN_APPENDIX_B>
{"branch":"codex/private-replay-progress-v1","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/es_execution_admission_model.md","sha256":"b137a82d65da89428c5311f648fc664bea383ff61bf08c7868ec1a0df201016c","size":80816},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md","sha256":"ee2827be90bced19f0660a8378778898cd9970a08ebea49f0a94dfcf6c42d6ea","size":160692},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md","sha256":"1b03cc40b48861c7220a7b85d20b1f8d232690f17460e3eee0df33af4659e3f3","size":103025},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"30c2008df895f1ad9332a5e5e8a36cdea7719300ac52706ead4630a4fabf3e6e","size":301817},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"059a55f9cdac5cd802323aed29cf7a3a68c8a03bddc94b3225c54510903d116f","size":792416},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_operation.go","sha256":"b7761f001a1f67349ed51f2b79012194a7d45bb19c79e0ca2c0c22b8227320f9","size":9548},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_record.go","sha256":"999db7db6550c5031b023a9613825504e30e971a179298cc43e09cf8c5c5d7cd","size":25226},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_service.go","sha256":"ef0bc6f4d125f3986c46901cbe05bc2cb447af7dfbf51cee4653d7ce696c0945","size":49972},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/guardrails_test.go","sha256":"9a300f0553fd6ac3003a048a7309060a4ec6f618eacd94139bd4bb29c011bc60","size":32231},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_file.go","sha256":"61c4006e1e4a3feb7c0ec0e7d4685dc2c3fe8c1e2165d1529d2c86ae8fa137b5","size":50461},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_file_test.go","sha256":"207d9f17658cd50f6c4bea8e293b12abd89455a174b2d96bac84742a66b0afdf","size":69995},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_format.go","sha256":"b8cb8e31edd9d854317a0d6a456f25d5ab1838498623881e429dec2155e1ea67","size":16488},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_structure.go","sha256":"4916268757b93d409cbc13ba9c0da14e009499b4db7cadd52bc7ccd47c6a86ad","size":18640},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_progress_test.go","sha256":"0952fff321daa368dee1d32ed39a2a5b417e7d2779ae4e1015ab3c12b1021048","size":61314},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_migrations.go","sha256":"7736e30a1d0c6e9584d9050cc6ebf8bfaf900d424f764ebe61af8ec8ddaec0c9","size":17407},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_physical_test.go","sha256":"2c125b6373f83467d542db45473cc79b888ed3a665e65ef6bf013655f461a7ba","size":14539},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_pooled_claim_read_cleanup_test.go","sha256":"0ec3060ed3c30a6327ec49b0291d5c761c20894986c9b6b1e1be384694312823","size":8912},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_claim.go","sha256":"8ddec89b4ca5702591bdf2060062016d7fb54264fc7df57af5ead1d161eb9de3","size":8301},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go","sha256":"188425870bbe4bee37e176c4bee565b6aa61bc27b4a165a2dcf4a0efd6aa6b3c","size":25073},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_progress_schema.go","sha256":"132d8ab87f5658cab3477b9f6913538013ba922d4768192a96be960df7bbb149","size":30612},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_shape.go","sha256":"29cdbba2e5b1fee069989f6e6423dccc1c69c843de22b6504f68a7d199b317be","size":2751},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_shape_test.go","sha256":"3552ea5fafbc59e43cc21b1007486e98da4d59b6d0ea98db92646e0c8478adfb","size":8815},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_store.go","sha256":"f6db4f75bb5324b4459ac8337867d4f7d65f348a85f2f91381c5ab76e5518aea","size":62863},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_store_test.go","sha256":"c99e7659b1059431911557ba43ef7fa982e373bba939f610bd41ea0622cee96f","size":57339},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_guardrails_test.go","sha256":"32de42b7bf8974e36c014d3d9ce6d24e0994fbbc03bb1587c4c4fddd32c80f6e","size":50991},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_format.go","sha256":"0a21803b03308332613481f89ce4b595512b31b073c56b31fe7d8000519c3beb","size":17326},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_hydration.go","sha256":"b5ff16b96178c45b53165ebb2bcbdc67991bb145276ca4a11a598f1430745b9c","size":28800},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_private.go","sha256":"d17927a23a57c808a8f0ebc4bad3e9912e42d7da497033637102bae2c45fd278","size":20440},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_private_test.go","sha256":"4e4e7c7fad2ed2b88b35801841044f4b1f049a4cb6d0435499bb87699467e9f2","size":45171},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/workstream_c_guardrails_test.go","sha256":"68f2fe4e31e5d862be161c3ba1071a511935b32e90cf9021755fe4dcb045fab5","size":297009}],"head":"f1aa8b934cc26c16a966a110c7b408abdaeadce7","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"68339ba85b7b22d86bdaa21ed4fdccebc5021f82912344e0507862d1624cb791","upstream":"origin/trunk_dev"}

<END_APPENDIX_B>

## Appendix C — Exact v2 recipe source

<BEGIN_APPENDIX_C>
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
import sys
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v2"


def fail(message: str) -> "NoReturn":
    raise SystemExit(message)


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env.update(
        {
            "LC_ALL": "C",
            "LANG": "C",
            "GIT_OPTIONAL_LOCKS": "0",
            "GIT_NO_LAZY_FETCH": "1",
            "GIT_TERMINAL_PROMPT": "0",
            "GIT_PAGER": "cat",
        }
    )
    result = subprocess.run(
        [
            "git",
            "--no-pager",
            "-c",
            "core.fsmonitor=false",
            "-c",
            "core.untrackedCache=false",
            *args,
        ],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


def validate_output_path(output_path: Path, repository_root: Path) -> None:
    if not output_path.is_absolute():
        fail("output path must be absolute")

    parent = output_path.parent
    parent_metadata = parent.lstat()
    if not stat.S_ISDIR(parent_metadata.st_mode) or stat.S_ISLNK(parent_metadata.st_mode):
        fail("output parent must be a nonsymlink directory")
    if parent_metadata.st_uid != os.getuid():
        fail("output parent must be owned by the current user")
    if stat.S_IMODE(parent_metadata.st_mode) & 0o022:
        fail("output parent must not be group- or world-writable")

    try:
        output_path.lstat()
    except FileNotFoundError:
        pass
    else:
        fail("output path already exists")

    repository_text = os.path.realpath(os.fspath(repository_root))
    output_text = os.path.realpath(os.fspath(output_path))
    try:
        common = os.path.commonpath([repository_text, output_text])
    except ValueError:
        common = ""
    if common == repository_text:
        fail("output path must be outside the repository")


def write_exclusive(output_path: Path, payload: bytes) -> None:
    flags = (
        os.O_WRONLY
        | os.O_CREAT
        | os.O_EXCL
        | getattr(os, "O_NOFOLLOW", 0)
        | getattr(os, "O_CLOEXEC", 0)
    )
    fd = os.open(os.fspath(output_path), flags, 0o600)
    try:
        view = memoryview(payload)
        while view:
            written = os.write(fd, view)
            if written <= 0:
                fail("short provenance-output write")
            view = view[written:]
        os.fsync(fd)
    finally:
        os.close(fd)

    metadata = output_path.lstat()
    if not stat.S_ISREG(metadata.st_mode) or stat.S_ISLNK(metadata.st_mode):
        fail("provenance output is not a regular nonsymlink file")
    if metadata.st_uid != os.getuid():
        fail("provenance output owner mismatch")
    if stat.S_IMODE(metadata.st_mode) != 0o600:
        fail("provenance output mode mismatch")
    if metadata.st_nlink != 1:
        fail("provenance output link-count mismatch")
    if metadata.st_size != len(payload):
        fail("provenance output size mismatch")

    read_flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_CLOEXEC", 0)
    read_fd = os.open(os.fspath(output_path), read_flags)
    try:
        observed = bytearray()
        while len(observed) <= len(payload):
            chunk = os.read(read_fd, min(1 << 20, len(payload) + 1 - len(observed)))
            if not chunk:
                break
            observed.extend(chunk)
    finally:
        os.close(read_fd)
    if bytes(observed) != payload:
        fail("provenance output byte mismatch")


if len(sys.argv) != 2:
    fail("usage: governed_execution_audit_patch_manifest_v2.py ABSOLUTE_OUTPUT_PATH")

repository_root = Path(git_text("rev-parse", "--show-toplevel"))
output_path = Path(sys.argv[1])
validate_output_path(output_path, repository_root)

head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    fail("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            fail(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()

write_exclusive(output_path, canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")

<END_APPENDIX_C>

## Appendix D — Complete prior independent REJECT

<BEGIN_APPENDIX_D>
# REJECT

The exact thirty-path candidate is **ineligible for a later local commit gate**. Independent SQLite diagnostics reproduced SR-1 and SR-2. Source review also confirmed two defects in migration opening validation. The focused suite passed, including both historical opener probes. Those tests do not exercise the defective branches.

No repository files were changed. All four independent reviewers completed their read-only reviews and closed.

## Findings

| ID | Severity and basis | Finding and required correction |
|---|---|---|
| **SR-1** | **High · Introduced · Reproduced** | Both establishment confirmation paths disclose a committed snapshot after the original key has been revoked. The confirmation branch at lines 1340–1351 checks custody qualification and skips the exact-key check performed by the ordinary branch at lines 1353–1376. The owner contract at lines 907 and 923–937 requires eligible keys at operation entry. Require the exact active-or-retired registry check and live borrow before disclosing the snapshot. Keep known COMMIT known and failed recoverable-unknown confirmation unknown, with zero projection in either refusal case. The impact is private fixture disclosure and confirmation. [Confirmation read](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/replay_custody_file.go:1340) · [Owner contract](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md:923) |
| **M-1** | **High · Inherited ordering defect in the selected migration · Source-confirmed** | `openGate` samples opening application ID, version, schema and ledger at lines 550–604. Bootstrap and upgrade take `BEGIN IMMEDIATE` later, at lines 672–705 and 720–757, then write from the earlier observation. A second SQLite writer can change the observed schema-3 version before the lock is taken. Migration 4 can overwrite that disallowed version and still pass the final shape checks. ADR lines 1683–1686 and 1708–1714 require verifying the actual opening state inside the transaction before writing. Move that verification under the lock and preserve the literal migrations and bounded recovery. This interleaving was reviewed statically. [Opening gate](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_store.go:550) · [Upgrade](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_store.go:720) · [Migration contract](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1683) |
| **M-2** | **High · Inherited schema qualification defect · Source-confirmed** | The pristine check at lines 772–784 and schema digest at lines 22–24 use `NOT LIKE 'sqlite_%'`. `_` matches any single character. The pinned SQLite source reserves the literal `sqlite_` prefix, so an ordinary name such as `sqliteXforeign` is legal and invisible to both checks. The opener can claim a nonempty version-0 database or accept an extra object at the current head. Use a literal namespace check at both boundaries, retain the legitimate schema hashes, and cover both refusal cases. The existing foreign-database test uses `foreign_*` names. No new migration diagnostic was run for this finding. [Pristine check](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_store.go:772) · [Schema digest](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_replay_shape.go:22) · [Pinned SQLite name check](/Users/ds/go/pkg/mod/modernc.org/sqlite@v1.54.0/lib/sqlite_g_0000000000000003.go:59855) |
| **SR-2** | **Medium · Introduced · Reproduced** | A fresh same-fact op 7 can return `FixtureProgressNoChange` with current progress after the recording predicate has failed. The equality return at lines 443–445 bypasses phase/provider eligibility and becomes a no-change result at lines 1221–1226. ADR lines 1471–1490 distinguish admissible historical storage from a currently eligible command. Check codec-4 current predicates before returning a fresh same-fact no-op. Preserve the historical tuple, exact latest replay, stale/conflict handling and codec-1/2 semantics. The counterexamples disclosed progress without a durable change. [Reconciliation](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/durable_service.go:421) · [Result classification](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/durable_service.go:1193) · [R1 contract](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1471) |
| **K1-1** | **Medium · Introduced · Source-confirmed** | A same-key loser can lose its definite `Occupied` disposition after a successful winner lookup. Lines 297–308 remap successful `Current` to `Occupied`, but lines 325–359 can return `Refused` if the losing catalog lacks the winner’s key pair or later authentication fails. The owner preserves the definite occupied outcome. Keep `Occupied` when winner disclosure fails and preserve the selected changed-intent conflict result. This path has zero projection and issues no second write. The disjoint-catalog race was reviewed statically. [Composer](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/reliable_submit_replay_private.go:297) · [Winner authentication](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/reliable_submit_replay_private.go:325) · [Disposition contract](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md:911) |
| **N-1** | **Medium · Acceptance evidence gap** | ADR acceptance row N requires an unknown-write case under the admission effect counters. The admission fixture at lines 874–973 covers match, mismatch, acceptance, cancellation and incompatibility. The real lost-response cases run at the custody/service boundary. Add an admission-level lost-response witness that asserts the resulting disposition, projection and zero effect contacts. The eight effect guard mutants ran. The mutant for an unreviewed method checks a direct call on receiver `s`, so the guard alone cannot establish transitive closure through aliases or free helpers. The current call graph was reviewed independently. [Acceptance row N](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1848) · [Admission fixture](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/reliable_submit_replay_private_test.go:874) · [Effect guard](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/reliable_submit_guardrails_test.go:93) |
| **T-1** | **Medium · Terminal fixture evidence limitation · Source-only** | ADR lines 1526–1532 require positive same-attempt evidence and receipt association. Lines 1108–1118 and 1177–1183 check claim, run, marker and fact presence. The receipt is separately shape-checked and bound in the operation digest. The fixture has no independent receipt-to-evidence association check, and the evidence type carries no polarity apart from command selection. Establish the bounded association before claiming independent terminal evidence validation. No terminal counterexample was executed. [Terminal contract](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1526) · [Evidence type and check](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/durable_service.go:1108) |
| **R2-1** | **Low · Introduced scope-1 compatibility drift · Source-only** | HEAD checked custody, frozen value and permit presence before arranging burn. Lines 406–419 now arrange burn before that preflight. Presenting a legitimate scope-1 permit through a closed or unqualified handle can burn it where HEAD left it usable at the issuing handle. Restore the inherited preflight boundary and retain the intentional qualified foreign-issuer burn before allocation. Durable reservation counts are unaffected by this difference. No new execution covered this case. [Publisher entry](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/replay_custody_file.go:406) · [Allocator contract](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1752) |

The custody review also identified an in-flight borrow lifetime concern in the SR-1 branch. A direct asynchronous fixture callback can pass the first lifetime check and race callback return while waiting for the issuer lock. The confirmation branch lacks the ordinary branch’s second lifetime check. The sole admission continuation is synchronous. This schedule was unexecuted and should be covered by the confirmation-boundary correction. [Borrow consumption and confirmation](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/replay_custody_file.go:1328)

## Independent diagnostic results

**SR-1.** The callback ran after original authentication. A separate fixture handle committed the key transition. The original handle observed the revoked registry state before entering `ReadFixtureProgress`. For the recoverable-unknown case, the existing COMMIT seam executed one real COMMIT and then modeled loss of its response.

| Route | Active and retired controls | Revoked before read entry |
|---|---|---|
| Known establishment | `Committed`, revision 1 | `Committed`, revision 1 returned. Expected retained `Committed` with zero projection and a read error. |
| Recoverable-unknown establishment | `OwnCommitConfirmed`, revision 1 | `OwnCommitConfirmed`, revision 1 returned. Expected retained `WriteUnknown` with zero projection. |
| Ordinary current read | Revision 1 returned | Read refused with revision 0, as required. |

The claim and sealed bytes stayed equal in all nine cases. The observation concerns revocation already committed and visible at method entry. [Diagnostic source](/Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42/audit-progress-diagnostic.bytes.go) · [Raw diagnostic log](/Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42/run-diagnostic/stdout)

**SR-2.** After restart and fresh authentication, each of Pending, Ambiguous and Inconsistent accepted a new mutation identity at the current revision in three ineligible states: incompatible provider observation, Accepted and Provably Not Accepted. All nine returned `NoChange`, revision 6 and no error. Compatible-provider no-ops, pre-advancement no-ops, exact latest replay, changed-input conflict and stale replay passed. Full rows, historical tuples and sealed bytes stayed equal across the observations. The diagnostic exited **1**, with **10 passing and 13 failing test identities**, including the two failed parents. Neither finding was rerun with altered assertions. [Frozen diagnostic](/Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42/diagnostic-freeze.json) · [Executed command and guard](/Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42/run-diagnostic/run.json)

## Provenance and integrated review

The physical and Git root was `/Users/ds/Repositories/ES-Private-Replay-Progress-v1`, with its own `.git`. Branch `codex/private-replay-progress-v1` tracked `origin/trunk_dev` at HEAD `f1aa8b934cc26c16a966a110c7b408abdaeadce7`, sole parent `fb9ae55797d9fcc02863c23fe8d3e43d16eac542`, tree `8dd27f9acba98ed70d93736bdef8300ef1aba53f`, subject “Harden original-key read transaction cleanup (A1) (#10).” Origin matched `git@github.com:evo-agi/Execution-Substrate.git`. There were 27 unstaged tracked changes, three authorized untracked additions and 400 unchanged tracked leaves. The index equaled HEAD. Both untracked inventories matched, with zero ignored paths. There were zero staged, unmerged, deleted, renamed, type-changed or extra paths. [Source inventory](/Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42/source-inventory.json)

The four appended payloads, both ZIPs, all 36 implementation members, source map, inventory and both retained implementation manifests authenticated. The five K1 owner/test files matched the opening side of the source map and were compared with the candidate. Two opening and two closing executions of the unchanged 7,275-byte recipe reproduced the **6,813-byte manifest** at SHA-256 `110cef71ba25f61b70297b37cc5a50a68732d639845e0ac4315d06cedcdbc1e3`. The tracked full-index diff was `e45e3bd85391191702673b2d40fc2d06d865503004e09a8094c2f6a7081fe0c4`. Appendix A authenticated as supplied. The scoped implementation root had no standalone whole-report duplicate or index. The transport, its inventory and the generation records bind their respective contents. [Packet verification](/Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42/packets.json) · [Closing manifest](/Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42/close-a.json)

The owners select a private **Bounded slice rule** on the reliable-submit **Reopened redesign seam**, limited to `synthetic_progress_nonoperational_v1`. The audit retained four independent perspectives and checked their load-bearing conclusions against the owning contracts and source. The reviewers agreed on SR-1 and SR-2. The evidence limits below remain relevant to any later gate. [Planning selection](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/PLANS.md:16) · [Admission boundary](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/es_execution_admission_model.md:603)

- **Pooled reader and inherited cleanup.** Verified cancellation before dispatch, exact disposal on ambiguous BEGIN or read COMMIT, request-independent bounded rollback after known BEGIN, cleanup context observation before self-cancel, one discard rescue, double withholding and post-COMMIT cancellation. The retained red/green runs used the exact final 8,912-byte regression. Red exited 1 and showed fresh-context same-store read and CAS failures after real BEGIN or SELECT cancellation and modeled loss of a real BEGIN response. Green exited 0 with all 16 identities passing. The final `loadClaim` body equals green. `loadClaimFresh` remains byte-identical across HEAD, red, green and candidate at 1,077 bytes, with its independent pool lifetime intact. Shared scanner validation and the expected schema head changed. The v2 differential binds the exact test and store sources through retained phase-1 records and has no separate complete v2 compile ledger or direct nested-BEGIN observation. [Reader source](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_store.go:278) · [Retained reader differential](/Users/ds/Repositories/ES-Private-Replay-Progress-Implementation-20261119-kadgzy4t/phase1-v2)

- **Durable transitions and K1.** The existing durable service remains the semantic writer. The SQLite CAS compares full immutable identity and current row, checks key eligibility in the same transaction, advances the exact revision through mutable columns only, and verifies the postimage. Reviewed known CAS loss, exact latest replay, stale and changed-input conflict, committed-snapshot handling, and exact full-record recovery after write uncertainty. Recovery performs one bounded authenticated read after disposal permits it, with no automatic second write or rebase. The operation digest binds typed ordered inputs and the predecessor, with mutation identity compared separately. Run, receipt, marker and the first reconciliation tuple remain protected, subject to the findings above. Codec-1/2 historical predicates and the immutable codec-3 route remain distinct. [CAS and writer](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_store.go:1813) · [Fixture result handling](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/durable_service.go:1193)

- **Custody and allocation.** Reviewed the separate schema, codec, scope and envelope axes, exact format dispatch, AEAD/AAD and commitment association, parser budgets, SQL storage classes and enum checks before narrowing, and issuer, context, Close and one-use checks. The independent vectors passed. The publisher uses random-nonce GCM. Both scope selectors share one checked SQLite writer lock for count and exclusive create. Verified release and FD handoff precede permit consumption and Seal. The independent child reached `SHARED_ALLOCATOR_READY` and `SHARED_ALLOCATOR_WON`. The parent required successful child exit, one verified winner, one full refusal, 32 names, two reservations and zero claims. Fault cases exercised exact disposal, owned-FD closure and counted inert orphans. SQL-pool quarantine shows exclusion and invocation of driver `Close`. Physical teardown and close duration remain unmeasured, and double withholding can retain capacity. The DB/sidecar budget is a detection boundary. [Format selection](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/replay_custody_format.go:184) · [Shared allocator](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/replay_custody_file.go:578) · [Independent process assertions](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/replay_custody_file_test.go:1548)

- **Migration and old openers.** Literal migrations 1–3 and their hashes held. Focused tests exercised authentic openings at 0–3, full logical claim/registry/counter/ledger preservation, precommit rollback, real COMMIT with a lost response, and intermediate/mixed refusal. Those fixtures do not exercise M-1 or M-2. The complete 427-leaf schema-3 export matched pinned PR #10. All 1,354 recorded inputs authenticated, including the retained generated test main and one-entry test-only overlay. The separate 15,601,186-byte schema-3 binary refused a schema-4 target populated with all four codecs. Full logical witnesses and both sealed originals stayed equal. The 14,350,930-byte PB1 binary and its three bound source/harness/build records matched the historical originals. PB1 refused its distinct authentic schema-3 target under the preserved narrower witness. Both probes ran from authenticated copies without rebuild. The migration matrix establishes logical preservation. The direct sealed-byte checks come from the old-opener fixture. [Migration matrix](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go:454) · [Distinct probe tests](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_replay_shape_test.go:17) · [Probe evidence](/Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42/retained-evidence-summary.json)

- **Admission and no-effect boundary.** Authenticated hits chose retained keys after lookup and avoided new resolution, acquisition and Seal. Restart drift, same-key race, opposite-scope occupation, both initial phases and shared capacity were exercised. Checked all 32 typed Workstream C entries and the changed per-method references. The 27 additions comprise one mutex, three atomic flags and 23 references or request fields. Retained exact inventory and negative reference/structural mutants ran, and fresh admission effect mutants passed. The finite 11-entry effect inventory and source trace found no route from public ingress, startup, configuration, scripts or examples into the private composers. App/API structural refusal and unkeyed compatibility passed against local mocks. SR-1 widens **private** disclosure eligibility, and M-1/M-2 compromise private database qualification. I found no public or operational authority widening. Coordinator authority remains separate. Operational Validated No-Dispatch Evidence, cross-restart write-uncertainty authority, provider eligibility and native installed-source qualification remain open. [Admission replay cases](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/reliable_submit_replay_private_test.go:671) · [Workstream C inventory](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/workstream_c_guardrails_test.go:2280) · [Public refusal](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/app/submit_integration_test.go:3517)

## Validation and skips

The independent run used pinned Go 1.26.5 `darwin/arm64`, Python 3.13.4 with `tomllib`, OpenSSL 3.6.2, Git 2.49.0, cached modules and the prescribed offline readonly environment. Executable paths, hashes and environment are retained. Each of the eight candidate commands and the diagnostic had a separately executed immediate guard against all 430 files, index and routing. Every guard passed. Focused test identity multisets matched retained generation 2 exactly. [Preflight](/Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42/preflight.json) · [Fresh command records](/Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42/fresh-validation-summary.json)

| Gate | Independent execution | Authenticated retained generation 2 |
|---|---:|---:|
| 1 · Go version | Exit 0, pinned version | Exit 0 |
| 2 · Formatting | Exit 0, clean | Exit 0, clean |
| 3 · Diff whitespace | Exit 0, clean | Exit 0, clean |
| 4 · Contract | Exit 0, 22 passed | Exit 0, 22 passed |
| 5 · Pooled reader | Exit 0, 16 passed | Exit 0, 16 passed |
| 6 · Storage, custody and historical probes | Exit 0, 136 passed | Exit 0, 136 passed |
| 7 · Admission and effects | Exit 0, 18 passed | Exit 0, 18 passed |
| 8 · API/App | Exit 0, 2 passed | Exit 0, 2 passed |
| 9 · Four-package suite | **Unrun** | Exit 0, 1,971 passed, 39 skipped |
| 10 · Full tree | **Unrun** | Exit 0, 5,096 passed, 39 skipped |

Gates 9 and 10 were omitted under the confirmed-blocker rule. Retained generation 2 had zero failures, 21 test-bearing packages and 20 no-test packages. I reconciled all ten raw logs, their exit records and distinct guard associations. Focused start and terminal identities were subsets of the full run, and gate 9 was the exact four-package projection. The independent gates and diagnostic had zero skips. [Retained evidence reconciliation](/Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42/retained-evidence-summary.json)

The retained skip inventory comprises:

- **Two helper sentinels:** `TestPrivateReplayObjectAllocatorHelperProcess` and `TestSQLiteClaimStoreLockHelperProcess`. The allocator helper ran under its parent.
- **Three App capability cases with distinct reasons:** `TestBringupScriptUpCheckDownFullProfile` required a reachable Docker daemon. `TestWorkloadCanCreateAndUseLocalRuntimeIdentityEndpointFromTmpfsWorkspace` required a healthy daemon. `TestSubmitFlowMountsGovernedArtifactAndLifecycleWithInstalledSourceIdentity` required a direct Docker Unix socket.
- **34 App daemon-probe failures:** `TestControlPlaneStaticScriptAPIPathCancelSucceeds`, `TestControlPlaneStaticScriptAPIPathFetchesRetainedResultBundle`, `TestDiagnosticsScriptRunIDBundleCollectsLifecycleSignalsAndStaging`, `TestExecuteLoopScriptFailureSummary`, `TestExecuteLoopScriptSuccessAndDeterministicDigests`, `TestExecutionCancelRetainsStageRootForDebugging`, `TestExecutionCancelStopsNomadJob`, `TestExecutionLogsReturnConflictWhenAllocationNotReady`, `TestExecutionLogsReturnRealContainerOutput`, `TestExecutionLoopScriptSuccessRetainsDistinctStageRootsAcrossRepeatedRuns`, `TestExecutionResultBundleAndStageRetainedAcrossStatusAndRepeatFetch`, `TestExecutionResultReturns404ForTerminalExecutionWithoutResultOutput`, `TestExecutionStatusReflectsFailedAllocation`, `TestExecutionStatusReflectsNomadJobState`, `TestExecutionStatusRetainsFailedStageRootForDebugging`, `TestExecutionStatusRetainsSuccessfulStageRootAndLogsStillWork`, `TestExecutionStatusReturns503WhenNomadUnavailable`, `TestLifecycleScriptCategorizesExecutionFailure`, `TestLifecycleScriptObservesExecutionViaPublicRunID`, `TestRuntimeIdentityIntegrationCapabilityProbe`, `TestSubmitFlowAllowsConfiguredControlPlaneCallerHandoff`, `TestSubmitFlowDoesNotStartWorkloadBeforeHelperReadiness`, `TestSubmitFlowHelperDeathIsTaskFatal`, `TestSubmitFlowInjectsWorkloadIdentityEndpointAndLifecycleStillWorks`, `TestSubmitFlowMountsGovernedArtifactAndLifecycleStillWorks`, `TestSubmitFlowProvidesPlatformOwnedRuntimeIdentityThroughBoundedEndpoint`, `TestSubmitFlowRejectsRuntimeIdentityPassthroughRequests`, `TestSubmitFlowRejectsWorkloadArchiveWithSymlinkEntry`, `TestSubmitFlowRemovesRuntimeMountArchiveResidueAfterExtraction`, `TestSubmitFlowRunsStaticScriptInNomadDocker`, `TestSubmitFlowUsesBridgeNetworkWhenNetworkAccessEnabled`, `TestSubmitFlowUsesConfiguredRuntimeIdentityTmpfsSize`, `TestSubmitFlowUsesPlatformOwnedIdentityForVaultLoginAndSecretRead`, and `TestSubmitValidOperatorCallerReturnsAcceptedSubmissionReceipt`.

### Exact gate commands

The first eight ran in the actual checkout. The last two are the unrun commands.

```sh
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go version
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/gofmt -d docs_contract_test.go es/admission/internal/reliablesubmit/sqlite_store.go es/admission/internal/reliablesubmit/sqlite_replay_claim.go es/admission/internal/reliablesubmit/sqlite_migrations.go es/admission/internal/reliablesubmit/sqlite_replay_progress_schema.go es/admission/internal/reliablesubmit/sqlite_replay_shape.go es/admission/internal/reliablesubmit/durable_record.go es/admission/internal/reliablesubmit/durable_operation.go es/admission/internal/reliablesubmit/durable_service.go es/admission/internal/reliablesubmit/replay_custody_format.go es/admission/internal/reliablesubmit/replay_custody_structure.go es/admission/internal/reliablesubmit/replay_custody_file.go es/admission/reliable_submit_replay_format.go es/admission/reliable_submit_replay_hydration.go es/admission/reliable_submit_replay_private.go es/admission/internal/reliablesubmit/sqlite_pooled_claim_read_cleanup_test.go es/admission/internal/reliablesubmit/replay_progress_test.go es/admission/internal/reliablesubmit/replay_custody_file_test.go es/admission/internal/reliablesubmit/sqlite_store_test.go es/admission/internal/reliablesubmit/sqlite_physical_test.go es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go es/admission/internal/reliablesubmit/sqlite_replay_shape_test.go es/admission/internal/reliablesubmit/guardrails_test.go es/admission/reliable_submit_guardrails_test.go es/admission/reliable_submit_replay_private_test.go es/admission/workstream_c_guardrails_test.go
git --no-pager diff --check
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateOriginalReplayProgressContractSelection|TestReliableSubmitPersistenceAndConcurrencyADRDocsContract|TestSubmitIdempotencyCorrelationAndRecoveryDocsContract|TestReliableSubmitPureModelDocsAndSourceContract|TestReliableSubmitPublicOptInAndVersioningDocsContract|TestReliableSubmitContractAdapterFoundationDocsAndSourceContract|TestReliableSubmitBindingProducerDocsContract|TestIntegratedAcceptanceGateDocumentationIsConsistent|TestIntegratedCandidateStatusSeparatesCAndT)$' .
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestSQLitePooledClaimReadCleanup$' ./es/admission/internal/reliablesubmit
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateReplaySharedObjectAllocation|TestReplayPublicationFaultAndIdentity|TestPrivateReplayProgressFormatVectors|TestPrivateReplayProgressTransitions|TestPrivateReplayProgressConcurrencyAndCommitOutcome|TestSQLiteV4MigrationPreservesFullState|TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation|TestSQLiteV3OldBinaryRefusesWithoutMutation|TestSQLiteLegacyCASConnectionCleanup|TestReplayOriginalKeyReadCleanup|TestReplayOriginalKeyReadCallerRefusal|TestReplayGrantC1PreCommitConnectionQuarantine|TestReplayGrantD1BeginResponseLossQuarantine|TestReplayKeyStateD1BeginResponseLossQuarantine|TestReliableSubmitPrivatePersistenceStaticGuardrails)$' ./es/admission/internal/reliablesubmit
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateReplayProgressAdmissionReplay|TestPrivateReplayProgressHasNoEffectPaths|TestReliableSubmitFoundationHasNoRuntimeWiring|TestReliableSubmitBindingProducerHasNoProductionCaller|TestPrepareRequestShapeRemainsLegacyAndUnkeyed|TestResolvedSubmitLegacyEquivalenceOneNomadRegistrationAndAuthorityRecovery)$' ./es/admission
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestWorkstreamCContractPrepareAndSubmitRemainSeparatedAtAPIBoundary|TestSubmitPublicRouteRejectsStructuralReliableBody)$' ./es/api ./es/app
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=600s ./es/admission/internal/reliablesubmit ./es/admission ./es/api ./es/app
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=600s ./...
```

The diagnostic ran in the private external view of all 430 authenticated source leaves plus one test-only file.

```sh
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestAuditProgressConfirmationRechecksOriginalKeys|TestAuditProgressReconciliationNoopRequiresCurrentPredicate)$' ./es/admission/internal/reliablesubmit
```

## Closeout

Only audit-owned files and disposable fixtures were created. The runs used fixture SQLite databases, sealed objects, helper processes and loopback mocks. I removed the audit-owned cache and the two empty scratch directories. I retained the source view, diagnostic and run records, restored the copied probes to mode `0600`, and rechecked 1,865 relied-upon material records. Final source, index, configuration and ref observations matched opening. No external network, operational migration, live stack, publication or other-checkout work occurred. [Source closeout](/Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42/source-closeout.json) · [Material recheck](/Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42/prior-material-closeout.json)

The supplementary report SHA-256 is `b26b4be5f09d067184c9a00f837c20cabb200438230b2b86bdcefdc24d1e24c1`. The self-excluding 517-file inventory SHA-256 is `20bd8b3c998e6865490ea606281ea05788fe8987244857425fce5e97f8cb6879`. [Private report](/Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42/audit-report.md) · [Artifact inventory](/Users/ds/Repositories/ES-Private-Replay-Progress-Independent-Audit-20261119-ZaLRiQ42/artifact-inventory.json)

```text
SOURCE_REPOSITORY_NOT_MUTATED
SOURCE_REFS_NOT_UPDATED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PRS_NOT_MODIFIED
EXISTING_OTHER_SOURCE_CHECKOUTS_NOT_SYNCHRONIZED
RUNTIME_WIRING_NOT_PERFORMED
PUBLIC_RELIABLE_SUBMIT_NOT_ENABLED
CROSS_RESTART_OPERATIONAL_WRITE_UNCERTAINTY_GATE_NOT_IMPLEMENTED
NATIVE_INSTALLED_SOURCE_WITNESS_NOT_QUALIFIED_BY_THIS_SLICE
```
<END_APPENDIX_D>

## Appendix E — Exact-source review and transport adjudication

<BEGIN_APPENDIX_E>
# Execution Substrate — consolidated replay-progress repair exact-source review

Date: 2026-11-19.
Decision: READY FOR FRESH INDEPENDENT AUDIT; this is not implementation ACCEPT.
Review posture: static inspection of supplied archives, source, patches, construction
records and the transported report. No repository commands, patches, source code,
tests, migrations, probes, supplied scripts or dependency code were executed.

## 1. Inputs and exact target

Current ZIP: `ES-Private-Replay-Progress-Consolidated-Repair-Review.zip`
- Bytes: 900863
- SHA-256: `e3cac3bc27bbfd8c1c18d1abf3aabc00077e632e14bd6e6b92e26e020c9c1be6`
- Entries: 44 uniquely named regular files; no absolute/traversal names,
  duplicates, links, special entries or extra archive metadata.
- Self-excluding inventory: 43 payload entries verified by complete bytes,
  archived mode, size and SHA-256.
- Complete changed/new source: 30 regular mode-0644 files.

Previous ZIP: `ES-Private-Replay-Progress-Implementation-Review.zip`
- Bytes: 718150
- SHA-256: `bc4bc721f7aa0f02da9f2427625973e883a82fdc0988e4f587c2140792245cf3`

Current canonical manifest: `repair-manifest-v2.json`
- Bytes: 6813
- SHA-256: `0812091529c67f4bc46d0bc343b3dea8595e63a461264e143d51606e581e0c06`
- Tracked HEAD patch SHA-256: `68339ba85b7b22d86bdaa21ed4fdccebc5021f82912344e0507862d1624cb791`
- Repair delta SHA-256: `cd1ddb5b23d124c931c449e7a09bd81e3d6e5307d105d3d19eeca179a5a068c5`
- Source map SHA-256: `fa58e64ecf8c2872bd8ff29357fa2266108e98df272344a349b061f39f784d23`
- Delivery inventory SHA-256: `c2a2b842265eace578bfe61a5944b1c91826194f17129ea691bd88a6dde419a1`

Target checkout: `/Users/ds/Repositories/ES-Private-Replay-Progress-v1`.
Branch `codex/private-replay-progress-v1`; upstream `origin/trunk_dev`.
HEAD `f1aa8b934cc26c16a966a110c7b408abdaeadce7`, sole parent
`fb9ae55797d9fcc02863c23fe8d3e43d16eac542`, HEAD tree
`8dd27f9acba98ed70d93736bdef8300ef1aba53f`.
The live repository identity is report-based and must be checked by Codex.
The thirty-path target is 27 tracked modifications and three untracked additions,
over 427 baseline tracked leaves: 400 unchanged tracked leaves and 430 total
candidate source leaves. This packet does not contain the 400 unchanged files.

Verified all 30 source rows against canonical manifest; all source-map rejected/
repaired records against both exact packets; 17 rows changed and 13 stayed equal.
Verified 50 incremental-patch hunks across 17 paths against both complete source
sides, including unchanged intervals and target/old Git blob IDs. Verified 173
HEAD-patch target-side hunks across all 27 tracked modifications and target Git
blob IDs. I did not apply either patch. HEAD old-side full source was not
reconstructed from the patch here. The untracked regression is included in the
incremental repair delta; all three additions are also complete source payloads.

## 2. Manifest transport discrepancy adjudication

The unmodified uploaded repair report is 30813 bytes, SHA-256
`be17b2ff7f0c9677f50cd890dc286dfc77e5349443b34824a79f021151f6a88a`. Its inline canonical JSON contains one malformed field:
`es/admission/internal/reliablesubmit/replay_custody_structure.go` has a
66-character value where a SHA-256 should have 64 characters. Canonicalizing that
pasted object gives 6815 bytes and SHA-256
`adc82e9b55e088a33b66e72c75cadda4835f81e82c94cdac8abb1856bc33f7b8`.

The ZIP's actual manifest is already correct. It contains:
`4916268757b93d409cbc13ba9c0da14e009499b4db7cadd52bc7ccd47c6a86ad`.
The complete 18640-byte source payload reproduces that hash and is byte-identical
to the rejected implementation's same file. The archived manifest reproduces
the claimed 6813 bytes and `08120915...` digest. No other JSON field differs.

Disposition: confirmed one-field report transcription error, not demonstrated
candidate drift. Preserve the report as supplied; use the verified exact archived
canonical bytes for the next target. No repository edit, packet regeneration,
validation replay or separate report-reissue task is required merely for this
discrepancy. The next audit must still reproduce the correct archived manifest
from the actual checkout. A live mismatch is not excused by this adjudication.

## 3. Static repair assessment

No additional implementation blocker was identified in this targeted pass.
All eight findings have source/test treatment consistent with the selected repair.
They remain pending fresh independent closure; static review is not a replacement
for independent execution or complete integrated review.

### M-1 — migration opening state and recovery

`sqlite_store.go:550–595, 662–742` separates early qualification from the decisive
lock-held qualification. `migrateSQLite` obtains guarded BEGIN IMMEDIATE, rereads
the opening state, and only then assigns `migrationOpeningVersion` and starts
migration. An authentic current head reached by a competing opener returns
through lock-only cleanup without replaying migration writes.
`sqlite_replay_migration_test.go:569–712` uses the existing clock collaborator
to order a second real writer before acquisition, covers disallowed version,
nonempty bootstrap, app ID, ledger, schema, legitimate competing head and 0–4
controls, and compares an unfiltered logical witness.

Generation-1 migration recovery failed and was corrected; do not relabel it.
For a nonnil migration COMMIT response, `sqlite_store.go:735–739` routes the
unpublished opener into its existing unknown-outcome path; `:96–116` closes that
pool before one fresh nonmigrating classifier. The unchanged tests at migration
test `:102–225` model both pre-COMMIT interruption by wrapper closure and lost
response after real COMMIT. The distinction between wrapper closure, pool closure
and proven physical close remains relevant; the latter is not established here.
Review all rollback/disposal/error precedence during independent audit.

### M-2 — literal internal namespace

`sqlite_replay_shape.go:22–28` defines one substring/ASCII-NOCASE literal prefix
predicate; the pristine gate at `sqlite_store.go:744–755` uses the same predicate.
No new schema hash is learned from an unqualified database. `sqlite_replay_shape_test.go:199–233`
covers a version-0 collision table, ordinary foreign table, mixed-case schema-3
index and schema-4 view with before/after logical witnesses. Authentic schema
constants and the schema-4 migration literal are unchanged across the two packets.
This is a logical qualification result, not file/sidecar-byte preservation.

### SR-1 — establishment-confirmation entry and lifetime

`replay_custody_file.go:1344–1387` now rechecks the live borrow after taking the
issuer lock; verifies retained descriptor/key match; invokes the paired original
key checker; and rechecks custody/context and lifetime before projecting the
committed snapshot. Ordinary current reads still use `reload`.
`WithAuthenticatedProgressOriginal:1257–1318` retains known commit on refusal
and returns WriteUnknown if recoverable-unknown confirmation/use fails.
Tests `replay_progress_test.go:1129–1302` cover both original key roles, active/
retired controls, known/unknown/current routes and a deterministic in-flight
read waiting behind the issuer lock while its callback returns or cancels.
No instantaneous revocation or observation-free final atomicity is claimed.

### SR-2 — historical tuple versus current command

`durable_service.go:402–451, 830–857` validates codec-4 current reconciliation
eligibility before the existing tuple-equality no-op. `:1260–1293` still
classifies exact latest replay, conflict and stale before applying that
predicate. Legacy requests remain outside the progress-specific branch.
Tests `replay_progress_test.go:1304–1411` separate valid historical storage,
fresh same-fact commands and exact latest replay across provider/terminal
advancement and restart. No history is deleted and the R1 phase trap is not
reintroduced.

### T-1 — explicit synthetic assertion

`durable_service.go:1131–1189` uses redacted private fields for claim, run,
marker, fact, outcome and acceptance receipt. Two constructors supply the
declared finite fixture assertions. The service checks polarity, association,
fact and exact receipt independently of command selection before relying on
replay/no-op; candidate-phase checks remain later.
Tests `replay_progress_test.go:1413–1531` construct evidence before command
substitution and include wrong receipt/polarity, malformed values, wrong attempt,
negative fact mismatch, valid terminals, restart replay and immutable receipt.

The retained old-interface adapter cannot represent outcome/receipt fields.
Its only test-view helper change returns the available old assertions rather
than mutating nonexistent fields. The archive includes both exact sources.
Treat representable receipt/command substitution and polarity negatives as
causal controls; do not claim malformed legacy fields existed. Green controls
cover new-field validity. This is synthetic association, not external provider
receipt authenticity.

### K1-1 — known occupied outcome

`reliable_submit_replay_private.go:297–316` preserves Occupied on failed
winner disclosure in the definite-loser branch, allows authenticated Current
projection as Occupied, and preserves proved Conflict with zero projection.
It does not grant occupancy from a generic unauthenticated lookup or a write
unknown. The maintained test at `:980–1149` orders both legitimate seals before
the winner, then covers disjoint catalogs, equivalent winner, changed intent and
unavailable winner with unchanged sealed bytes and no repeat admission attempt.
Audit cancellation/key-revocation and other failed-disclosure exits against this
same mapping without broadening the result vocabulary.

### R2-1 — scope-1 preflight and burn

`replay_custody_file.go:406–435` restores the scope-1 custody/frozen/permit
preflight before burn. Once qualified, burn remains before issuer/allocation/
consume/Seal. Scope-2 wrapper treatment is preserved. Tests at
`replay_custody_file_test.go:1826–1909` cover closed custody, invalid frozen
input, nil permit, wrong scope, qualified foreign issuer and collision; check
issuing-handle first use, subsequent refusal and unchanged reservation counts.
The shared allocator design itself is not reopened.

### N-1 — admission-level response-loss witness

Two external source additions, absent from the thirty-file candidate:
- internal bridge: 789 bytes,
  `14f0e9e92a37e1d1bf624f1f052a62a6d56e5b82f988698abbf6e1b5bcf9196d`;
- admission test: 5897 bytes,
  `8da31dd61c9af2537c15f4376a330d05cb2e55dd2efd0ea610472a0c6ffa5c6a`.

The bridge only attaches/restores the exact fixture store's existing claim
COMMIT seam, performs real COMMIT, counts it and models a lost response.
The test surrounds actual admission establishment/AssignRun with provider,
staging and EGS counters; checks canceled recovery versus exact authenticated
recovery; clears the hook before later current read; and checks one sealed object,
fixture-only refs, unchanged earlier disposition and empty operational roots.

Verified the packet's N-1 full-view entries for all 30 available candidate files
and both additions, its 432-entry count, target manifest, metadata and build-input
file digest. The other 400 candidate files and 2801 actual build inputs are not
present here for byte comparison. JSON records of a result are not raw execution
logs. A fresh audit must authenticate them on the author host and independently
run an audit-owned 432-file view.

## 4. Preservation and test evidence limits

All 13 frozen rows match the rejected archive, including Workstream C inventory,
durable record/operation encodings, migration literal files available in the
packet and the complete pooled-reader regression. `loadClaimFresh`, including
its trailing blank separator, is 1077 bytes and reproduces
`3a47f8b5e0c5bf7bec899987aa78fdf4ef48a585086d9eb975e576896ab4b61c`
on both supplied versions. This proves source continuity, not dynamic lifetime
properties. The terminal aggregate and typed caller guard edits are narrow; the
direct-selector guard's alias/free-helper limitations remain explicitly stated.

The red/green construction records include differing selector breadth and
intermediate green generations. Equal aggregate counts are not an input-binding
requirement, nor do unequal counts prove a bad differential. Compare the actual
tested assertions, adapters and production generations. The earlier superseded
setup/runs remain distinct. Final generation 2, not those intermediate greens,
is the repaired target.

The report states all eleven final commands passed, with 5174 full-tree pass
identities and 39 skips; N-1 contributes five external pass identities, not five
additional ordinary-suite identities. This review did not execute or independently
authenticate raw logs. It does not close the eight findings dynamically.

## 5. Next action and limitations

Use a fresh independent read-only Codex conversation at the progress checkout.
It must reproduce the exact current manifest, inspect the full thirty-file
integrated candidate plus seventeen-row repair delta, independently adjudicate
all eight findings, and run the eleven-command sequence with a separately bound
N-1 external view before ACCEPT. The prior REJECT remains attached to its old
manifest. No staging, commit, ref change, publication or runtime permission follows
from this review.

No further source correction is selected by this static review alone. Preserve
the accepted K1/R1/R2/R3 operating model and all public refusal/operational limits.
Physical close outcome/duration, double-withholding capacity, DB-size detection
limits, native installed-source qualification and operational cross-restart
write-uncertainty authority remain unqualified.

Confidence: packet/source binding 0.99; targeted static repair review 0.96.
Independent implementation correctness and runtime readiness are not established.


<END_APPENDIX_E>

## Appendix F — Exact external internal-package N-1 bridge

<BEGIN_APPENDIX_F>
package reliablesubmit

import (
	"context"
	"database/sql"
)

// AttachAdmissionUnknownWitnessCommit is present only in the external fixture
// view. It models response loss after the selected store's real COMMIT.
func AttachAdmissionUnknownWitnessCommit(c *PrivateReplayProgressCustody, afterCommit func()) (counts func() (int, int), restore func()) {
	store := c.custody.store
	previous := store.claimCommit
	attempted, committed := 0, 0
	store.claimCommit = func(ctx context.Context, conn *sql.Conn) error {
		attempted++
		if err := commit(ctx, conn); err != nil {
			return err
		}
		committed++
		if afterCommit != nil {
			afterCommit()
		}
		return errClaimStoreCommitUnknown
	}
	return func() (int, int) { return attempted, committed }, func() { store.claimCommit = previous }
}

<END_APPENDIX_F>

## Appendix G — Exact external admission N-1 witness

<BEGIN_APPENDIX_G>
package admission

import (
	"context"
	"crypto/sha256"
	"errors"
	"maps"
	"net/http"
	"os"
	"path/filepath"
	"sync/atomic"
	"testing"

	"execution-substrate/es/admission/internal/reliablesubmit"
)

func TestPrivateReplayProgressAdmissionUnknownNoEffects(t *testing.T) {
	for _, operation := range []string{"Establish", "AssignRun"} {
		for _, recovery := range []string{"Canceled", "AuthenticatedExact"} {
			t.Run(operation+"/"+recovery, func(t *testing.T) {
				ctx := context.Background()
				s, raw, caller, keys, image := privateReplayServiceFixture(t)
				var provider, staging, egs atomic.Int64
				s.nomadClient = newResolvedPlanNomadClient(t, http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
					provider.Add(1)
					w.WriteHeader(http.StatusInternalServerError)
				}))
				s.egsClient = newResolvedPlanDependencyClient(t, http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
					egs.Add(1)
					w.WriteHeader(http.StatusInternalServerError)
				}))
				beforeStagingChildRegistrationStatForTest = func(string, int, bool) { staging.Add(1) }
				beforeStagingHandoffValidationForTest = func(*stagingCustody) { staging.Add(1) }
				defer func() {
					beforeStagingChildRegistrationStatForTest = nil
					beforeStagingHandoffValidationForTest = nil
				}()
				catalog, err := newPrivateSyntheticKeyCatalog(keys)
				if err != nil {
					t.Fatal(err)
				}
				root := privateReplayTestRoot(t)
				c, err := reliablesubmit.OpenPrivateReplayProgressCustody(ctx, root)
				if err != nil {
					t.Fatal(err)
				}
				defer c.Close()
				objects := func() map[string][32]byte {
					t.Helper()
					dir := filepath.Join(root, "objects", "v1")
					entries, err := os.ReadDir(dir)
					if err != nil {
						t.Fatal(err)
					}
					got := make(map[string][32]byte, len(entries))
					for _, entry := range entries {
						b, err := os.ReadFile(filepath.Join(dir, entry.Name()))
						if err != nil {
							t.Fatal(err)
						}
						got[entry.Name()] = sha256.Sum256(b)
					}
					return got
				}
				if operation == "AssignRun" {
					status, p, err := s.admitPrivateProgressReplay(ctx, c, raw, caller, catalog, image, reliablesubmit.FixturePendingBeforeAssignment)
					if err != nil || status != reliablesubmit.FixtureProgressCommitted || p.Revision() != 1 {
						t.Fatalf("initial control did not establish: %d %d %v", status, p.Revision(), err)
					}
				}
				before := objects()
				invocation, cancel := context.WithCancel(ctx)
				defer cancel()
				var after func()
				if recovery == "Canceled" {
					after = cancel
				}
				counts, restore := reliablesubmit.AttachAdmissionUnknownWitnessCommit(c, after)
				defer restore()
				var disposition reliablesubmit.FixtureProgressDisposition
				var projected reliablesubmit.FixtureProgress
				run := reliablesubmit.NewFixtureRunRef([32]byte{91})
				revision := int64(1)
				if operation == "Establish" {
					disposition, projected, err = s.admitPrivateProgressReplay(invocation, c, raw, caller, catalog, image,
						reliablesubmit.FixturePendingBeforeAssignment)
				} else {
					revision = 2
					disposition, projected, err = s.applyPrivateProgressReplay(invocation, c, raw, caller, catalog, 1,
						reliablesubmit.NewFixtureMutationRef([32]byte{92}), reliablesubmit.FixtureAssignRun{Run: run})
				}
				restore()
				attempted, committed := counts()
				if attempted != 1 || committed != 1 {
					t.Fatalf("expected one intended real COMMIT, attempts=%d committed=%d", attempted, committed)
				}
				want := reliablesubmit.FixtureProgressOwnCommitConfirmed
				projection := revision
				var wantErr error
				if recovery == "Canceled" {
					want, projection, wantErr = reliablesubmit.FixtureProgressWriteUnknown, 0, errPrivateReplayCommitUnknown
				}
				if disposition != want || !errors.Is(err, wantErr) || projected.Revision() != projection {
					t.Fatalf("invocation disposition=%d projection=%d err=%v", disposition, projected.Revision(), err)
				}
				if gotRun, present := projected.Run(); present != (projection == 2) || (present && !gotRun.Equal(run)) {
					t.Fatal("faulted invocation exposed an ineligible run")
				}
				if _, present := projected.Receipt(); present {
					t.Fatal("faulted invocation exposed a receipt")
				}
				committedObjects := objects()
				if len(committedObjects) != 1 || (operation == "AssignRun" && !maps.Equal(before, committedObjects)) {
					t.Fatal("faulted invocation sealed an additional object or replaced the original")
				}
				later, current, err := (&Service{}).admitPrivateProgressReplay(ctx, c, raw, caller, catalog, privateSyntheticImagePlacement{}, 0)
				if later != reliablesubmit.FixtureProgressCurrent || current.Revision() != revision || err != nil || disposition != want {
					t.Fatalf("later read changed invocation or lost current state: %d %d %v", later, current.Revision(), err)
				}
				got, present := current.Run()
				if present != (revision == 2) || (present && !got.Equal(run)) {
					t.Fatal("later current read did not preserve assigned fixture run")
				}
				if _, operational := any(got).(reliablesubmit.RunRef); operational {
					t.Fatal("test received an operational run reference")
				}
				if provider.Load() != 0 || staging.Load() != 0 || egs.Load() != 0 || !maps.Equal(committedObjects, objects()) {
					t.Fatalf("private admission caused effects: provider=%d staging=%d EGS=%d", provider.Load(), staging.Load(), egs.Load())
				}
				for _, effectRoot := range []string{s.cfg.Execution.StagingRootDir, s.cfg.Execution.ResultsRootDir} {
					entries, err := os.ReadDir(effectRoot)
					if err != nil || len(entries) != 0 {
						t.Fatalf("operational root was not empty: %v", err)
					}
				}
				t.Logf("one real COMMIT, modeled lost reply, disposition=%d projection=%d later revision=%d, provider/staging/EGS=0/0/0, empty roots", disposition, projection, current.Revision())
			})
		}
	}
}

<END_APPENDIX_G>
