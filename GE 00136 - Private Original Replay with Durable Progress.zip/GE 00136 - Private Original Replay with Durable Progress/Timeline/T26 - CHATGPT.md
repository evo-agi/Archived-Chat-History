## `REJECT` stands — make one narrow two-finding repair

**Seven of the eight earlier findings are now independently resolved.** M-1’s original lock-order defect is also repaired, but a different pre-COMMIT cleanup exit still violates the recovery contract. The second blocker is a stale synchronization-owner table—not a newly discovered synchronization mechanism or authority expansion. Pasted text

The next step is **a bounded repair in the same Codex conversation that returned this rejection**, followed by fresh independent acceptance. There is no reason to repeat the earlier eight-finding repair campaign.

I read the complete audit and reopened the relevant opener, migration, owner-document, inventory, and test source in the supplied repair ZIP. I did not execute repository code or the auditor’s private diagnostic. My previous targeted review missed this earlier cleanup exit and the stale owner table.

## 1. M-1: recovery is skipped before COMMIT is attempted

The independent diagnostic establishes a precise failure:

```text
Authenticate opening state under the writer lock
→ perform migration writes
→ verify schema 4 inside the transaction
→ close the high-level connection wrapper
→ return an error before COMMIT
→ ROLLBACK and Raw cannot use that wrapper
→ return generic unavailable without checked readback
```

Both pristine schema 0 and populated schema 3 reproduced it. **There were zero COMMIT attempts, no returned store handle, and no change to the complete logical opening state.** The missing behavior is the checked readback and resulting **recovered-old refusal**. This diagnostic did not demonstrate data loss, accidental migration acceptance, or an exposed unsafe handle. Pasted text

### This is not the branch repaired in the previous iteration

The previous generation-1 regression involved the `migrationCommit` collaborator, after the code had marked COMMIT attempted. That path now reaches the opener’s recovery logic.

The new diagnostic injects through **`beforeMigrationCommit`**, before that flag is set. It therefore reaches the deferred rollback branch instead. The audit explicitly distinguishes these injection points and retains the earlier successful recovery tests. Pasted text

In the delivered source, the relevant locations are:

```text
sqlite_store.go:96–116       unpublished opener recovery
sqlite_store.go:662–688      migration cleanup and result routing
sqlite_store.go:727–739      pre-COMMIT versus COMMIT-attempt boundary
```

### Selected correction

**Do not map `sql.ErrConnDone` directly to recovered-old—or globally redefine it as successful disposal.** An unusable wrapper is not evidence of the durable outcome.

The repair must transfer this migration-local exit to the existing owning-opener sequence:

```text
Valid lock-held opening baseline exists
→ finish original connection ownership
→ close the unpublished opener’s pool
→ perform one fresh checked, nonmigrating observation
→ classify only what that observation authenticates
```

| Fresh observation | Result |
|---|---|
| Authenticated old/pristine state | Recovered-old refusal; no store handle |
| Authentic complete current state | Only the already selected checked-current outcome |
| Failed, canceled, invalid, mixed, or intermediate readback | Unavailable; no handle |

A checked-current observation must not be attributed to an unattempted COMMIT. Recovery must perform **no migration replay, second semantic write, automatic retry, or schema repair**.

The maintained regression must preserve the diagnostic’s exact boundary: real migration writes, verified in-transaction schema 4, wrapper closure **before** COMMIT, and an explicit zero-COMMIT count. Ordinary successful-rollback controls must retain their existing refusal behavior. The opening version must come from the authenticated lock-held observation, not an earlier preflight or default field.

The shared discard helper, completed reader repairs, and normal claim/CAS paths stay unchanged. Physical-close success and duration remain outside this correction.

## 2. Correct the owner inventory—not the implementation to fit the old prose

Admission §7.4 currently says that production ES and `cmd/es` contain five synchronization-bearing fields and no atomic fields. The candidate’s typed inventory covers those same source trees and contains thirty-two entries. The audit also identifies missing scope-2 permit and shared-allocator readers in the owner table. Pasted text

I independently counted the exact delivered inventory:

| Structural category | Entries |
|---|---:|
| Direct lock fields | 5 |
| Atomic Boolean fields | 3 |
| Transitively synchronization-bearing references, wrappers, and request fields | 24 |
| **Total** | **32** |

**These are not thirty-two locks.** The documentation needs to identify the primitive owners, the facts they protect, and the fields that merely carry references to those owners.

It must also distinguish **non-test production source** from **operational reachability**. The private fixture definitions are included in the source inventory even though the facade remains runtime-unwired. Narrowing the prose silently to public callers would conceal the mismatch rather than repair it.

The correction should enumerate the existing fields and permit readers/writers, retain SQLite’s ownership of committed claim/key/grant facts, and preserve the rejected A3 registry/lease/poison boundaries. **No lock, atomic, capability, registry, or runtime caller needs to be added or removed.**

The prompt adds a bounded documentation test that compares the owner’s field set with the existing finite inventory and rejects the actual stale description and targeted omissions. The Workstream C typed inventory and its production-reference expectations remain byte-frozen.

## The successful audit work remains valuable

Unlike the preceding rejection, this audit independently ran **all eleven prescribed commands**:

```text
Full repository: 5,174 passes, zero failures, 39 skips
External N-1:       5 passes, zero failures, zero skips
```

The fresh identities matched retained generation 2, and the four-package result matched the corresponding full-suite packages. The additional migration diagnostic then exposed the missing branch; it does not invalidate the reported results of the prescribed commands, but it prevents acceptance of their source target. Pasted text Pasted text

The audit independently closes **M-2, SR-1, SR-2, K1-1, T-1, R2-1, and N-1** within their stated scope. Those repairs should be preserved, not redesigned. Pasted text

The malformed historical manifest field is also closed as a transport-only discrepancy: the live source and archived manifest reproduced the correct target. It is not a reason for another provenance-reconciliation turn. Pasted text

## Next Codex turn

Continue in the **same foreground conversation that returned this `REJECT`**. Close any remaining reviewers and transition the parent to workspace-write.

The sole source target remains:

```text
/Users/ds/Repositories/ES-Private-Replay-Progress-v1
```

Use:

:chatgpt-content-reference{index="9"}[Download the M-1 pre-COMMIT recovery and owner-inventory repair prompt](sandbox:/mnt/data/ES_Private_Replay_Progress_M1_Precommit_Recovery_And_Owner_Inventory_Repair_20261119.md)

SHA-256:

```text
30bdbd8d1c68c645620bd9952a9191b97889bb2c7dc58f52804b4cc1b77112df
```

The prompt embeds five byte-verified inputs: the complete latest rejection, correct thirty-file opening manifest, exact v2 recipe, and both existing external N-1 source files.

### Six-file repair ceiling

```text
PLANS.md
.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md
.docs/execution_lifecycle/es_execution_admission_model.md
docs_contract_test.go
es/admission/internal/reliablesubmit/sqlite_store.go
es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go
```

**Only `sqlite_store.go` receives production-behavior changes**, confined to the opener and migration-local recovery routing. The other twenty-four candidate rows and all four hundred HEAD-identical files remain frozen. No new repository file, migration literal, schema hash, format, module dependency, or operational authority is selected.

The prompt requires a source-bound red/green regression, the corrected owner inventory and negative checks, then the eleven-command final sequence with the new regressions included. The existing N-1 witness runs from a **new external view of the repaired candidate**, not the older source copy. Neither historical opener probe is rebuilt.

Expected endpoint:

```text
ES_PRIVATE_REPLAY_PROGRESS_M1_PRECOMMIT_AND_OWNER_INVENTORY_REPAIR_READY_FOR_FRESH_INDEPENDENT_AUDIT
```

The turn stops **unstaged and uncommitted**, with a new exact review packet. The current rejection remains attached to manifest `08120915…`; new bytes require fresh independent acceptance under the project’s transaction-sensitive provenance process. Governed Execution Provenance G…

No separate reconnaissance, checkout move, historical audit replay, or preliminary upload is needed before this repair. Runtime wiring, native installed-source qualification, and the operational cross-restart write-uncertainty gate remain outside the slice.

**Sources:** Complete latest independent audit; reopened consolidated-repair ZIP, especially `sqlite_store.go:58–123, 618–742`, admission §7.4, and `workstream_c_guardrails_test.go:2280–2515`; project provenance and operating guidance. Diagnostic execution is audit-reported, not rerun here.

**Confidence:** Source-path diagnosis and repair scope **0.98**; provenance binding **0.99**. Correctness of the forthcoming repair remains unestablished until its regression evidence and fresh independent review.
