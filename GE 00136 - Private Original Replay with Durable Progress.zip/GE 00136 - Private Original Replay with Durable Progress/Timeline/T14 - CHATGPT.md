## K1 is closed — proceed with the integrated implementation

**The exact delivered contract is ready to implement. No further contract-only correction is indicated by this review.** This is architectural acceptance of the fixture-only operating model—not acceptance of code that has yet to be written, and not runtime permission.

I inspected the actual five files, the complete K1 delta, the relevant surrounding contracts, and the documentation assertions. The correction is consistent across the plan, persistence rules, interface, restart examples, outcome tables, and prospective tests.

:chatgpt-content-reference{index="4"}[Download the complete exact-contract review, including line-numbered source excerpts](sandbox:/mnt/data/ES_Private_Replay_Progress_K1_Exact_Review_20261119.md)

## Packet verification

The uploaded archive matches the reported identity:

```text
ZIP size:
420,293 bytes

ZIP SHA-256:
03dddf54b405e27fcdeafec2bc40165a2948d15be83a94ef5129c4d26b3c12d7

Canonical manifest SHA-256:
79c3554da0dbbb5c45677092aee07093ee3b5f10d306ed656a7e9922c6c7733b
```

All ten entries are uniquely named regular files. Every inventory entry and all five source-file rows match their complete bytes, sizes, and archived modes. Both patches’ target-side hunks and Git blob identifiers match the delivered files. The incremental patch also matches the previously reviewed ZIP’s old-side contents, with no additional differences outside its hunks.

**I did not apply patches, run repository commands, or execute tests.** The nine passing documentation parents and thirteen subtests remain Codex-reported validation; their raw logs are not in this packet. Pasted text

## Why K1 is resolved

The delivered contract now makes three separate guarantees:

| Boundary | Accepted meaning |
|---|---|
| **One write invocation** | Preserve its known, evidenced-not-applied, or unknown disposition. Recovery performs no second semantic write, automatic replacement mutation, rebase, or retry loop. |
| **Later explicit fixture operation** | Authenticate afresh and evaluate the current row with the supplied command and exact expected revision. Current replay does not retrospectively confirm an earlier uncertain write. |
| **Operational dispatch** | Remains outside this fixture slice. The full operational Validated No-Dispatch Evidence requirement is unchanged. |

The controlling text is in the persistence ADR at `:1500–1515, 1590–1628` and the submit/recovery contract at `:905–944`.

The restart examples at ADR `:1530–1541` now give **the same eligibility to identical retained facts and identical later inputs**. History B’s earlier unknown response remains unknown. A later explicit command may create the first synthetic marker when none is stored; an actually stored marker still prevents a new marker command.

That resolves the original contradiction without adding hidden knowledge, a response-history ledger, another database, or another attempt. The five new documentation mutants protect the specific distinctions, although behavioral implementation tests must still prove them. Pasted text Pasted text

### The earlier architectural decisions remain closed

I directly compared the new and prior packets. These sections are byte-identical:

- The existing operational §8 requirement.
- The pooled-reader prerequisite.
- R2’s shared allocator and budget rules.
- R3’s previous-schema probe build-origin instructions.

R1’s historical reconciliation treatment is also retained, with kind 1 now explicitly narrowed to a **fixture no-marker observation**. It does not regain the earlier permanent progression trap.

There is no reason to repeat those contract-review campaigns before implementation.

## Next Codex turn

Continue in the **same Codex conversation that authored the K1 correction**. It may remain attached to:

```text
/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1
```

The sole edit, test, and provenance target remains:

```text
/Users/ds/Repositories/ES-Private-Replay-Progress-v1
```

Use:

:chatgpt-content-reference{index="5"}[Download the integrated private replay-progress implementation prompt](sandbox:/mnt/data/ES_Private_Replay_Progress_Integrated_Implementation_20261119.md)

SHA-256:

```text
b658639e3e5f804ac385ffc0d56b81bef2929761a11838ffcf7d30db08ece9a4
```

The prompt embeds the complete supplied K1 closeout, exact opening manifest, and exact v2 provenance recipe. I verified all three embedded payloads byte-for-byte.

### One integrated slice, with ordered prerequisites

The implementation proceeds in the existing candidate:

```text
pooled loadClaim cleanup and bound regression
→ versioned original format, schema 4, and shared allocator
→ codec-4 durable successors and private admission composition
→ integrated restart, concurrency, uncertainty, and no-effect evidence
→ fresh independent audit of the complete resulting patch
```

**These are internal implementation phases—not separate PRs or routine approval stops.** Normal engineering corrections within the authorized scope are permitted and must remain recorded.

This moves the work beyond isolated cleanup: the target joins authenticated original replay to durable claim progress, while preserving one original, one attempt, one assigned run, and the existing ES authority split.

### One narrow test-scope addition

I included a conditional allowance for:

```text
es/admission/workstream_c_guardrails_test.go
```

The inspected snapshot contains exact resolver-caller, hydration, aggregate, and synchronization inventories there. The new private facade may legitimately affect those inventories.

The allowance permits only exact, source-justified updates for the selected private paths, with corresponding negative tests and runtime exclusions preserved. Codex must confirm the pinned sites and record the companion change in the existing owner path map first. **It does not permit loosening the checker or adding production authority.**

The full allowance is capped at **30 paths: 27 existing and three new**, including that conditional test file. It is a scope ceiling, not a requirement to modify every file.

## What the implementation must demonstrate

The prompt carries the complete acceptance matrix. Its most consequential checks are:

**Transaction and result ownership.** The pooled reader must recover without returning an uncertain connection to its usable pool. Write disposition and returned projection must remain separate: failed authentication cannot erase a known commit, and a successful later read cannot rewrite an earlier unknown response.

**Actual composition.** Successors must retain codec 4, the complete immutable original descriptor, physical row identity, binding and witness. They must not fall through the legacy codec-2 constructor or reseal the original. Historical reconciliation must coexist with later valid progress.

**Invocation lifetime.** The encompassing establishment call must own its attempt through bounded confirmation and invalidate it before returning or cancellation. Each progress borrow permits one operation. A lower-level returned token must neither expire before its permitted confirmation nor escape into later calls.

**Migration and compatibility.** Migrations 1–3, legacy behavior, codec-3 immutability, old vectors, and global caller/key occupation stay preserved. The historical PB1/schema-2 probe and the new pinned schema-3 opener remain distinct evidence with distinct targets.

**Shared allocation and no effects.** Both publishers must participate in the same count/create protocol. Failed allocations retain counted orphans without Seal, claim, adoption, or refund. No private fixture outcome may reach operational staging, provider submission, startup, or public reliable Submit.

The final frozen validation has **ten serial commands**, including focused checks, relevant packages, and one full `go test ./...`. Counts must account for new tests rather than reproduce the old total artificially. Every command receives fresh integrity observations, including both ordinary-untracked and ignored inventories; the three authorized new files are expected untracked source, not unwanted artifacts.

## Endpoint and remaining boundary

Expected successful closeout:

```text
ES_PRIVATE_REPLAY_PROGRESS_IMPLEMENTATION_READY_FOR_FRESH_INDEPENDENT_AUDIT
```

The candidate remains **unstaged and uncommitted**. Codex must deliver the complete report inline, new exact provenance, and a source review packet. Independent acceptance then belongs in a fresh read-only conversation, consistent with the project’s transaction-sensitive provenance chain. Governed Execution Provenance G…

**Operational reliable submission remains unimplemented.** In particular, this slice does not supply the cross-restart operational write-uncertainty gate, provider dispatch/reconciliation contract, native installed-source qualification, or live key and state provisioning. Those limits are preserved rather than inferred away from successful fixture progression.

**Sources:** Exact uploaded K1 ZIP and preceding reconciled ZIP; delivered persistence ADR §15B, submit/recovery §6B, plan, admission classification, and documentation assertions. The linked review contains exact excerpts. Codex’s closeout supplies reported validation and live-workspace preservation.

**Confidence:** Packet identity **0.99**; K1 closure and bounded architectural readiness **0.97**. Implementation correctness and runtime readiness are not established by this contract review.
