Here is Codex's response:

`ES_PRIVATE_REPLAY_PROGRESS_IMPLEMENTATION_READY_FOR_FRESH_INDEPENDENT_AUDIT`

Implemented the K1 private original replay and durable claim progress slice in [ES-Private-Replay-Progress-v1](/Users/ds/Repositories/ES-Private-Replay-Progress-v1). All ten final commands passed on the frozen source. The full tree recorded **5,096 passing test identities, zero failures, and 39 skips**. Every immediate integrity check matched the frozen source and index.

[Review ZIP](/Users/ds/Repositories/ES-Private-Replay-Progress-Implementation-20261119-kadgzy4t/ES-Private-Replay-Progress-Implementation-Review.zip) · **718,150 bytes** · SHA-256 `bc4bc721f7aa0f02da9f2427625973e883a82fdc0988e4f587c2140792245cf3`. The ZIP is local and requires upload. The available attachment action supports pull requests only.

## Source and scope

The conversation opened at [the A1 checkout](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1). That checkout remains clean at `fd2115ca8f44a615627adb08926896a1e052dc30`, with the same refs, index, config, and tree as at opening. The implementation, tests, and manifest ran from the standalone progress checkout, whose Git directory and common directory both resolve to its own `.git`.

- **Candidate branch** `codex/private-replay-progress-v1`, upstream `origin/trunk_dev`
- **HEAD** `f1aa8b934cc26c16a966a110c7b408abdaeadce7`
- **Parent** `fb9ae55797d9fcc02863c23fe8d3e43d16eac542`
- **Committed tree** `8dd27f9acba98ed70d93736bdef8300ef1aba53f`, 427 tracked paths
- **K1 opening target** Both recipe runs reproduced the 1,331-byte opening manifest, SHA-256 `79c3554da0dbbb5c45677092aee07093ee3b5f10d306ed656a7e9922c6c7733b`. Its five source files matched the authenticated 420,293-byte K1 archive, SHA-256 `03dddf54b405e27fcdeafec2bc40165a2948d15be83a94ef5129c4d26b3c12d7`.
- **Final scope** 27 tracked modifications and the three authorized new files. The index still equals HEAD. Each check found zero ignored, staged, or unmerged paths. [Opening routing](/Users/ds/Repositories/ES-Private-Replay-Progress-Implementation-20261119-kadgzy4t/routing-opening.json) · [Closing routing](/Users/ds/Repositories/ES-Private-Replay-Progress-Implementation-20261119-kadgzy4t/routing-closing.json)

## Implementation and evidence

| Gate | Result |
|---|---|
| **P · Pooled reader prerequisite** | The same 8,912-byte regression exited 1 against the pinned reader with seam-only instrumentation and 0 against the repaired reader. The old reader caused fresh-context same-store read and CAS failures after real BEGIN or SELECT cancellation and after modeled loss of the response to real BEGIN. The repaired reader passed the actual five-second expiry, nil-response-after-expiry, exact-connection discard and rescue, double-withholding, and same-store follow-up cases. `loadClaimFresh` is byte-identical across its 1,077-byte function boundary. Its SHA-256 is `3a47f8b5e0c5bf7bec899987aa78fdf4ef48a585086d9eb975e576896ab4b61c`. [Reader contract](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1296) · [Red/green evidence](/Users/ds/Repositories/ES-Private-Replay-Progress-Implementation-20261119-kadgzy4t/phase1-v2) |
| **F / M · Format and migration** | Codec 4 uses scope 2 with the selected payload, envelope, AAD, and commitment domains. Tests independently assembled the framing, MACs, permit and establishment preimages, and deterministic test AEAD. The production publisher uses random-nonce GCM. Migration tests exercised genuine openings at schema 0–3, complete row and registry/counter/ledger witnesses, rollback, real COMMIT with lost response, and refusal of mixed or intermediate recovery. [Format contract](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md:787) · [Migration contract](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1639) |
| **L / R2 · Shared allocation** | Both selectors use one checked SQLite `BEGIN IMMEDIATE` count-and-exclusive-create path. Confirmed rollback and wrapper release precede FD transfer, permit consumption, and Seal. The final-slot tests ran across separate handles and a separate process. The child reached `SHARED_ALLOCATOR_READY` and `SHARED_ALLOCATOR_WON` in the final run. The result was one verified object and no 33rd name. Post-create refusal retained the inert name, closed the owned FD, and burned the permit. [Allocator contract](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1735) · [Allocator implementation](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/replay_custody_file.go:578) |
| **R / T / R1 · Original and progress** | The genuine miss uses the parsed delivery, real resolver, and PB1 producer. An occupied hit uses the retained original keys and the typed authenticated original. Tests exercised restart with key and input drift, a concurrent first winner, shared capacity, opposite-scope refusal, both initial phases, and the legal transition branches. Successors keep the physical rowid and complete original descriptor. The first reconciliation tuple survives a later first marker, provider progress, and stronger terminal evidence. [Private composer](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/reliable_submit_replay_private.go:262) · [Transitions](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1403) |
| **U / K1 · Invocation authority** | The operation-scoped child context and one-use borrow bind authentication, use, and recovery. The durable service classifies exact latest replay, conflict, and staleness before a new transition. Recovery after a real COMMIT with an injected lost response confirms ownership only on full expected-row equality. An advanced winner, absent or wrong-scope recovery row, unusable original, or canceled recovery leaves the invocation unknown and withholds projection. The two indistinguishable restart histories retained equal rows and sealed bytes. Each separately supplied later marker command committed once. Their earlier dispositions remained distinct. [K1 contract](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1625) · [Durable service](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/durable_service.go:1193) |
| **N · Effect boundary** | The finite typed caller inventory and negative mutants passed. The fixture observed zero provider, staging, and EGS dependency contacts and empty staging and results roots. It exercised accepted fixture receipt projection, changed intent, cancellation, and an incompatible selector. Unknown-result behavior was exercised at the custody and durable-service boundary. Runtime and startup exclusion were checked by source reachability and the App/API gates. The public rejection and baseline unkeyed-submit tests passed. [Admission boundary](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/es_execution_admission_model.md:603) |

The conditional Workstream C guard was needed. I recorded its scope in the owner map before editing it. The synchronized-field inventory went from 5 to 32 exact entries, covering the per-custody lock and references to issuer-bound invocation state. The old permit wrapper’s three publisher references became four in the shared publisher, plus one in scope-2 reserve and two in scope-2 publish. Its existing scope-1 reserve reference stayed at one. The new wrapper has one reserve and three publish references. The shared allocation eligibility check added two references to the existing permit lock and one to its use flag. Resolver, hydration, aggregate, and package-state inventories kept their existing counts. [Owner map](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1783) · [Exact guard inventories](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/workstream_c_guardrails_test.go:2279)

The connection evidence establishes bounded quarantine through `database/sql`. Two unconfirmed disposal responses can leave the wrapper withheld and consume capacity. Physical-close timing and a machine-wide temporary-file sweep were outside the measurements. The database size check is a detection boundary. The 27 remaining reports under the task-owned `TMPDIR` were identified and removed along with the task-owned cache and scratch directories. [Cleanup record](/Users/ds/Repositories/ES-Private-Replay-Progress-Implementation-20261119-kadgzy4t/task-scratch-cleanup.json)

### Schema identities

| Version | Migration literal SHA-256 | Pinned-driver schema shape SHA-256 |
|---|---|---|
| 1, preserved | `9613ba74cd6573626277b1f04a20b9c3ec5f9edf8b6b7408e94cbb45edc32dcd` | `031abaada34a63834d3466081ed04afef6b7c9f55103cd2b57fe3033b8c45ef0` |
| 2, preserved | `9280a62450488dfa54907d268d693f3f7d4f0b78b9a3553a1b659206d2c970e9` | `944094f4e5fae102ea2882a076f580c69494678f41acedf9eaa971fe836eb280` |
| 3, preserved | `4dafddbf477fd7f64ad88cf2b1e2b2becb378827e81cd6cc694456798c9a00be` | `15ab48bde4d53bb252dc954a2aa3b1db12de7295111f23bb0264f74f153dba92` |
| 4, appended | `879b24ac563d37ccdd1bdb5ec13c923b93213f2caea69a1110281796e20e667e` | `2ae4721c8526ed9b8de35fd3acdfa31448eae9b547ba8662a22ed130035f7c15` |

**Distinct old-binary probes.** The preserved historical PB1/schema-2 binary is 14,350,930 bytes, SHA-256 `b205a31bac091cbcf5b3f4826bc359455625316908051131733622813e34adcf`. It refused the authenticated schema-3 target in its own test. The separately built previous-schema-3 opener is 15,601,186 bytes, SHA-256 `42614a50812a65ba52b53488d872884e59ce7b4f57dece6a66642d4eb8de1409`. It used the verified 427-leaf PR #10 source export and one test overlay. It emitted `SCHEMA3_REFUSED_SCHEMA4` against a target populated with all four codecs. Nonmigrating witnesses agreed across the full logical state and both sealed originals. The compiled-input inventory binds 1,354 unique inputs and has SHA-256 `50a81fa5a042e135abfc9f6bad68d20abc4575f881945ecc84252c14910dde8f`. [PB1 authentication](/Users/ds/Repositories/ES-Private-Replay-Progress-Implementation-20261119-kadgzy4t/historical-pb1/authentication.json) · [Schema-3 build inputs](/Users/ds/Repositories/ES-Private-Replay-Progress-Implementation-20261119-kadgzy4t/schema3-probe/compiled-and-export-inputs.json)

## Final frozen validation

Go reported `go1.26.5 darwin/arm64`. The environment used Python 3.13.4 with `tomllib`, OpenSSL 3.6.2, cached modules at `/Users/ds/go/pkg/mod`, `GOTOOLCHAIN=local`, `GOPROXY=off`, `GOSUMDB=off`, `GOWORK=off`, `GOFLAGS=-mod=readonly`, `CGO_ENABLED=0`, and `GOTELEMETRY=off`. Both probe paths were pinned by size and SHA-256. The probe tests supplied `ES_REPLAY_PB1_TARGET` and `ES_REPLAY_SCHEMA3_TARGET` to their respective child processes. [Environment and validation records](/Users/ds/Repositories/ES-Private-Replay-Progress-Implementation-20261119-kadgzy4t/final-generation-2)

| Command | Exit | Test identities passed / failed / skipped |
|---|---:|---:|
| 1 · Go version | 0 | — |
| 2 · Read-only formatting | 0 | Clean |
| 3 · Diff whitespace check | 0 | Clean |
| 4 · Contract documentation | 0 | 22 / 0 / 0 |
| 5 · Pooled reader | 0 | 16 / 0 / 0 |
| 6 · Storage, custody, and historical probes | 0 | 136 / 0 / 0 |
| 7 · Admission and effect boundary | 0 | 18 / 0 / 0 |
| 8 · App/API contract | 0 | 2 / 0 / 0 |
| 9 · Four-package run | 0 | 1,971 / 0 / 39 |
| 10 · Full tree | 0 | 5,096 / 0 / 39 |

All named parents ran. Each command had its own post-command observation of all 430 paths, file modes and bytes, both untracked listings, HEAD, branch, upstream, and index. The observations independently reproduced SHA-256 `e71aa89b78da8a5bd5985d05237140602a8facdf47b13d5de2d366a2557e5347`. The index SHA-256 stayed `1c6218366e333383b205833fce0ceaa5d462fa7264cf51cbdcd35aa05855b018`.

The full tree had 21 test-bearing packages and 20 packages without tests. The four-package pass counts were admission 1,048, reliable-submit 489, API 33, and App 401. The other counts were root 2,230, `ags/app` 24, `ags/publish` 1, `ars/app` 64, `cgs/app` 31, `cgs/policy` 4, `egs/app` 19, `es/config` 70, `es/internal/outsideobserverprotocol` 549, `es/internal/ownershipnorm` 5, `es/internal/staticarchive` 14, its `testcorpus` 9, `es/runtimehelper` 81, `internal/contracts/evidence/v1` 4, `internal/contracts/runtimeconfig/v1` 6, `internal/httpx` 7, and `internal/observability` 7.

The 39 skips comprise 37 App capability cases and two direct helper sentinels. The capability reasons were 34 failed Docker daemon probes, one reachability requirement for Slice 0 bringup, one healthy-daemon integration prerequisite, and one unavailable direct Docker Unix socket for the mounted-source witness. The two sentinels were `TestPrivateReplayObjectAllocatorHelperProcess` and `TestSQLiteClaimStoreLockHelperProcess`. The allocator parent independently proved its helper executed. The additional sentinel accounts for the extra skip relative to the historical 38. [Counts and reasons by test identity](/Users/ds/Repositories/ES-Private-Replay-Progress-Implementation-20261119-kadgzy4t/final-generation-2/summary.json)

The first frozen generation also passed all ten commands. I refroze and reran after tightening closed-issuer handling and adding direct assertions for parser limits, migration recovery, and absent or wrong-scope recovery rows. Retained development failures include the corruption fixture’s stale trigger restoration, a test hook signature mismatch, and stale source inventories for the shared publisher and package file set. Those failures were corrected before the final generation.

<details>
<summary>Exact final argv, in execution order</summary>

```sh
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go version
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/gofmt -d docs_contract_test.go es/admission/internal/reliablesubmit/sqlite_store.go es/admission/internal/reliablesubmit/sqlite_replay_claim.go es/admission/internal/reliablesubmit/sqlite_migrations.go es/admission/internal/reliablesubmit/sqlite_replay_progress_schema.go es/admission/internal/reliablesubmit/sqlite_replay_shape.go es/admission/internal/reliablesubmit/durable_record.go es/admission/internal/reliablesubmit/durable_operation.go es/admission/internal/reliablesubmit/durable_service.go es/admission/internal/reliablesubmit/replay_custody_format.go es/admission/internal/reliablesubmit/replay_custody_structure.go es/admission/internal/reliablesubmit/replay_custody_file.go es/admission/reliable_submit_replay_format.go es/admission/reliable_submit_replay_hydration.go es/admission/reliable_submit_replay_private.go es/admission/internal/reliablesubmit/sqlite_pooled_claim_read_cleanup_test.go es/admission/internal/reliablesubmit/replay_progress_test.go es/admission/internal/reliablesubmit/replay_custody_file_test.go es/admission/internal/reliablesubmit/sqlite_store_test.go es/admission/internal/reliablesubmit/sqlite_physical_test.go es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go es/admission/internal/reliablesubmit/sqlite_replay_shape_test.go es/admission/internal/reliablesubmit/guardrails_test.go es/admission/reliable_submit_guardrails_test.go es/admission/reliable_submit_replay_private_test.go es/admission/workstream_c_guardrails_test.go
git --no-pager diff --check
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateOriginalReplayProgressContractSelection|TestReliableSubmitPersistenceAndConcurrencyADRDocsContract|TestSubmitIdempotencyCorrelationAndRecoveryDocsContract|TestReliableSubmitPureModelDocsAndSourceContract|TestReliableSubmitPublicOptInAndVersioningDocsContract|TestReliableSubmitContractAdapterFoundationDocsAndSourceContract|TestReliableSubmitBindingProducerDocsContract|TestIntegratedAcceptanceGateDocumentationIsConsistent|TestIntegratedCandidateStatusSeparatesCAndT)$' .
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestSQLitePooledClaimReadCleanup$' ./es/admission/internal/reliablesubmit
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateReplaySharedObjectAllocation|TestReplayPublicationFaultAndIdentity|TestPrivateReplayProgressFormatVectors|TestPrivateReplayProgressTransitions|TestPrivateReplayProgressConcurrencyAndCommitOutcome|TestSQLiteV4MigrationPreservesFullState|TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation|TestSQLiteV3OldBinaryRefusesWithoutMutation|TestSQLiteLegacyCASConnectionCleanup|TestReplayOriginalKeyReadCleanup|TestReplayOriginalKeyReadCallerRefusal|TestReplayGrantC1PreCommitConnectionQuarantine|TestReplayGrantD1BeginResponseLossQuarantine|TestReplayKeyStateD1BeginResponseLossQuarantine|TestReliableSubmitPrivatePersistenceStaticGuardrails)$' ./es/admission/internal/reliablesubmit
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateReplayProgressAdmissionReplay|TestPrivateReplayProgressHasNoEffectPaths|TestReliableSubmitFoundationHasNoRuntimeWiring|TestReliableSubmitBindingProducerHasNoProductionCaller|TestPrepareRequestShapeRemainsLegacyAndUnkeyed|TestResolvedSubmitLegacyEquivalenceOneNomadRegistrationAndAuthorityRecovery)$' ./es/admission
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestWorkstreamCContractPrepareAndSubmitRemainSeparatedAtAPIBoundary|TestSubmitPublicRouteRejectsStructuralReliableBody)$' ./es/api ./es/app
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=600s ./es/admission/internal/reliablesubmit ./es/admission ./es/api ./es/app
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=600s ./...
```

</details>

## Review packet and canonical manifest

The 36-entry ZIP contains all 30 complete source files, the two patches, the source map, the canonical manifest, a README, and the self-excluding delivery inventory. The HEAD patch independently reconstructed the 27 tracked modifications. The opening-to-implementation patch independently reconstructed all 30 files. Both checks verified sizes, hashes, and `0644` modes. The final ZIP verification checked every member’s name, regular-file type, mode, and bytes. [Delivery receipt](/Users/ds/Repositories/ES-Private-Replay-Progress-Implementation-20261119-kadgzy4t/review-packet-receipt.json)

| Artifact | SHA-256 |
|---|---|
| Recipe `governed-execution.audit-patch-manifest.v2`, 7,275 bytes | `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` |
| Canonical manifest, 6,813 bytes, both runs identical | `110cef71ba25f61b70297b37cc5a50a68732d639845e0ac4315d06cedcdbc1e3` |
| Tracked full-index HEAD diff | `e45e3bd85391191702673b2d40fc2d06d865503004e09a8094c2f6a7081fe0c4` |
| Contract-opening delta | `631ee93e57691352f099cee09d32cd958772960784c6eb2b3c6dc0e35fad97e0` |
| Source map | `d214f2e5cef18a4a40c4826a4ae027e1f822ae240bcade7b94e02cd91b59e566` |
| Delivery inventory | `2c5e906cccbe078b39df283b109dd9c6d9342bada0b3d30753c87450314f2109` |

[Manifest A](/Users/ds/Repositories/ES-Private-Replay-Progress-Implementation-20261119-kadgzy4t/implementation-manifest-a.json) · [Manifest B](/Users/ds/Repositories/ES-Private-Replay-Progress-Implementation-20261119-kadgzy4t/implementation-manifest-b.json)

<details>
<summary>All 30 canonical file entries</summary>

The manifest’s HEAD, branch, upstream, recipe, and diff hash appear above. Every file entry has type `regular` and mode `0644`.

| Repository path | Kind | Bytes | SHA-256 |
|---|---|---:|---|
| `.docs/execution_lifecycle/es_execution_admission_model.md` | tracked_modified | 80361 | `03f03a378beecb53f4c996022ef004e892922bbfd69972d3887ba618dd26011c` |
| `.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md` | tracked_modified | 156221 | `6e69af309b665e6769590a1206df4e2ff6d244ebe2446d88458bcb4570fa2c66` |
| `.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md` | tracked_modified | 102166 | `5640ab0307e251eb304258a1017509c6ed0f9021210931f808c9854b99d818c0` |
| `PLANS.md` | tracked_modified | 300922 | `cf7c3fc49c71ee62a5c6121c9154f7c3fafeaa667a6bf6a711e380e812a88477` |
| `docs_contract_test.go` | tracked_modified | 791928 | `4d9c5cda8bf6b768cbda818c1f8583e2b3954abf6a49cd2c8effa3141afe946d` |
| `es/admission/internal/reliablesubmit/durable_operation.go` | tracked_modified | 9548 | `b7761f001a1f67349ed51f2b79012194a7d45bb19c79e0ca2c0c22b8227320f9` |
| `es/admission/internal/reliablesubmit/durable_record.go` | tracked_modified | 25226 | `999db7db6550c5031b023a9613825504e30e971a179298cc43e09cf8c5c5d7cd` |
| `es/admission/internal/reliablesubmit/durable_service.go` | tracked_modified | 47166 | `caa5139671d91f18e269256dc11ea12cb949c2737f0d9eb81fb0afa2cb529232` |
| `es/admission/internal/reliablesubmit/guardrails_test.go` | tracked_modified | 30905 | `9812c719dd31b594c59dbf6daf47dc43fdac1bdb483346d0ec0be83b1688f4ea` |
| `es/admission/internal/reliablesubmit/replay_custody_file.go` | tracked_modified | 50001 | `8eeac273d6db099ef15c68021e48c6f013253088b83f4318ce530acc52151cea` |
| `es/admission/internal/reliablesubmit/replay_custody_file_test.go` | tracked_modified | 66823 | `3e6fcca31873ba5d54b0f4ee389e09a2613eb38269c217f00078c43bcf63e167` |
| `es/admission/internal/reliablesubmit/replay_custody_format.go` | tracked_modified | 16488 | `b8cb8e31edd9d854317a0d6a456f25d5ab1838498623881e429dec2155e1ea67` |
| `es/admission/internal/reliablesubmit/replay_custody_structure.go` | tracked_modified | 18640 | `4916268757b93d409cbc13ba9c0da14e009499b4db7cadd52bc7ccd47c6a86ad` |
| `es/admission/internal/reliablesubmit/replay_progress_test.go` | untracked | 43192 | `470bd6250f0c34800a2c099e96fbe5fd0b43398296b82904a0e56ff7f85b6f7f` |
| `es/admission/internal/reliablesubmit/sqlite_migrations.go` | tracked_modified | 17407 | `7736e30a1d0c6e9584d9050cc6ebf8bfaf900d424f764ebe61af8ec8ddaec0c9` |
| `es/admission/internal/reliablesubmit/sqlite_physical_test.go` | tracked_modified | 14539 | `2c125b6373f83467d542db45473cc79b888ed3a665e65ef6bf013655f461a7ba` |
| `es/admission/internal/reliablesubmit/sqlite_pooled_claim_read_cleanup_test.go` | untracked | 8912 | `0ec3060ed3c30a6327ec49b0291d5c761c20894986c9b6b1e1be384694312823` |
| `es/admission/internal/reliablesubmit/sqlite_replay_claim.go` | tracked_modified | 8301 | `8ddec89b4ca5702591bdf2060062016d7fb54264fc7df57af5ead1d161eb9de3` |
| `es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go` | tracked_modified | 20291 | `953c87d23f80d5ecbd78507b1a81b2ce9f861c84eb811273e1a0f40c7d5242b4` |
| `es/admission/internal/reliablesubmit/sqlite_replay_progress_schema.go` | untracked | 30612 | `132d8ab87f5658cab3477b9f6913538013ba922d4768192a96be960df7bbb149` |
| `es/admission/internal/reliablesubmit/sqlite_replay_shape.go` | tracked_modified | 2588 | `043cc868afe925e51df77cfca5246004f86feac6fd1dab17be4bb00138e175a7` |
| `es/admission/internal/reliablesubmit/sqlite_replay_shape_test.go` | tracked_modified | 7230 | `b8742a0aeb31b7777a357a6375eb140d7355afd9a69786316da550044ce00eb1` |
| `es/admission/internal/reliablesubmit/sqlite_store.go` | tracked_modified | 63712 | `520dd8f39a32dea946b66620ed48058084ad255aefbc43b167c62b900822222f` |
| `es/admission/internal/reliablesubmit/sqlite_store_test.go` | tracked_modified | 57339 | `c99e7659b1059431911557ba43ef7fa982e373bba939f610bd41ea0622cee96f` |
| `es/admission/reliable_submit_guardrails_test.go` | tracked_modified | 50444 | `a8f7938c6d5efd4d1600ade03bfca46d1cb89a7a46ea48b33b9590b79ce3b851` |
| `es/admission/reliable_submit_replay_format.go` | tracked_modified | 17326 | `0a21803b03308332613481f89ce4b595512b31b073c56b31fe7d8000519c3beb` |
| `es/admission/reliable_submit_replay_hydration.go` | tracked_modified | 28800 | `b5ff16b96178c45b53165ebb2bcbdc67991bb145276ca4a11a598f1430745b9c` |
| `es/admission/reliable_submit_replay_private.go` | tracked_modified | 20253 | `20ea7b2682bf8be47f03924342fe87c0d8326b8fce7ed8afdfb57cec95a9f934` |
| `es/admission/reliable_submit_replay_private_test.go` | tracked_modified | 39376 | `9a1ca86e26438c90a372b64cf50cb704c97444b48556bedfa891b1722aafbeef` |
| `es/admission/workstream_c_guardrails_test.go` | tracked_modified | 297009 | `68f2fe4e31e5d862be161c3ba1071a511935b32e90cf9021755fe4dcb045fab5` |

</details>

```text
INDEPENDENT_ACCEPTANCE_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PRS_NOT_MODIFIED
EXISTING_OTHER_SOURCE_CHECKOUTS_NOT_SYNCHRONIZED
LOADCLAIMFRESH_LIFECYCLE_PRESERVED
CROSS_RESTART_OPERATIONAL_WRITE_UNCERTAINTY_GATE_NOT_IMPLEMENTED
RUNTIME_WIRING_NOT_PERFORMED
PUBLIC_RELIABLE_SUBMIT_NOT_ENABLED
NATIVE_INSTALLED_SOURCE_WITNESS_NOT_QUALIFIED_BY_THIS_SLICE
```
