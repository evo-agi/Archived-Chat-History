## Exact review complete: R1–R3 are resolved, but one contract gap remains

**The packet is authentic and complete. The remaining issue is architectural—not missing evidence, packaging, or another failed test.** I would not yet freeze this contract for implementation.

I verified the ZIP’s **419,360 bytes** and SHA-256:

```text
8d0734b788cb04e23624ee2282bba9e08153caafacfe447d2f33639601f01af9
```

All ten archive entries are uniquely named regular files. The inventory matches all nine covered entries; the five source files match their manifest hashes, sizes, and archived modes. Both patches’ target-side hunks and target Git blob identifiers match the delivered complete files. I inspected both complete patches, every changed contract passage and documentation assertion, and the relevant surrounding contracts. I did not apply patches or execute repository commands.

The canonical manifest also matches:

```text
ad2e60dfb5f4377cbd4531ab9555c90ec0391b76b7c879764b18ddf5693f0491
```

Codex’s four passing documentation commands, nine test parents, and eight subtests remain **reported validation**, not tests I reran. The packet does not contain their raw logs. Pasted text

:chatgpt-content-reference{index="1"}[Download the complete architectural review, including exact source excerpts](sandbox:/mnt/data/ES_Private_Replay_Progress_Exact_Contract_Review_20261118.md)

## What the actual files resolve

**R1 — reconciliation history:** The persistence ADR now keeps the first reconciliation tuple as historical evidence while current marker, provider, phase, and receipt facts govern subsequent progress. The concrete examples cover restart followed by a first marker and independent accepted/not-accepted successors. That removes the previously identified permanent phase trap without adding another attempt or history table.

Source: `.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1447–1496, 1534–1568`.

**R2 — shared allocation:** The ADR explicitly makes both publishers use the new allocator. It owns BEGIN uncertainty, bounded rollback, connection release/disposal, and file descriptors. A created name remains a counted inert orphan after failure; transaction rollback is not confused with filesystem rollback. Permit consumption and Seal follow confirmed allocation release, outside the critical section.

Source: the same ADR, `:1702–1748`.

**R3 — previous-schema probe:** The build command explicitly enters the authenticated PR #10 source export, with one declared test overlay and independently witnessed schema-4 target. The historical PB1 probe retains its separate purpose.

Source: the same ADR, `:1683–1700, 1830–1854`.

**Those architectural corrections should stay closed.** The remaining issue concerns what the new fixture interface can know after restart.

## K1: the contract requires a distinction that its retained state does not encode

The proposed first-marker rule requires “known dispositions of all relevant intent/marker/revision writes.” It permits a first marker after a clean restart, but says an earlier unknown marker result cannot be bypassed by a fresh mutation or observed absence.

At the same time, the complete 47-field record contains no unresolved-call history, and the finite progress capability expires on return or cancellation. The contract excludes a process-local flag, public proof object, and extra history as substitutes.

The relevant locations are:

| Contract element | Exact delivered location |
|---|---|
| Complete retained record | Persistence ADR `:1338–1392` |
| Required prior-write knowledge | Persistence ADR `:1500–1514` |
| Successful restart → first-marker example | Persistence ADR `:1547–1549` |
| Unknown-write restrictions | Persistence ADR `:1560–1564, 1595–1606` |
| Finite interface and expiring borrow | Submit/recovery contract `:900–929` |

### The counterexample

Consider two histories starting from the same revision-4 claim, with an assigned run, committed intent, recorded reconciliation, and no marker.

**History A:** No marker operation occurs. The process restarts. The contract’s example permits the first marker.

**History B:** A marker transaction is attempted but does not commit. Its response is classified unknown, recovery fails, and confirmed disposal ends the transaction. The same predecessor remains durable. The process then restarts.

After restart, both can expose the **same contract-visible claim, sealed original, key/grant facts, and latest-operation descriptor**. The failed operation in B left no committed successor. Its earlier returned error and expired capability are not inputs to the new call.

Given the same subsequent authenticated command, the declared interface cannot distinguish these histories solely from those retained facts. Yet the draft asks it to permit A and reject B because of the earlier unresolved history.

**A test driver remembering which scenario it executed is not a durable ES authority input.** Implementing this literally would require an unselected source of retained knowledge, unjustified inference from absence, or broader refusal than the positive restart example promises.

This is a **static contract/input gap**, not a newly reproduced SQLite defect or a finding against the accepted A1 implementation.

## Selected correction: narrow the fixture claim, not runtime safety

I recommend **not adding a durable uncertainty subsystem to this source slice**. Its purpose is to join authenticated originals to durable progress while remaining runtime-unwired. The contract should distinguish three guarantees.

### 1. Preserve each invocation’s write disposition

An unknown write remains unknown unless the specified exact expected-record proof confirms it. A failed recovery read must not convert it into success or known noncommit.

That invocation performs no second semantic write, automatic rebase, replacement mutation-ID generation, or retry loop. Its recovery failure withholds projection. These protections remain unchanged.

### 2. Treat a later explicit fixture command as a separate model operation

A later command requires fresh original authentication, a new live borrow, an explicitly supplied command, and the exact current expected revision.

It may inspect or advance the **current durable fixture state**. That observation does not retrospectively establish what happened to an earlier invocation.

Where no marker is stored, a separately issued fixture command may create the first synthetic marker under the current row and CAS rules. Where a marker exists, it remains immutable: exact latest replay may describe it, but a new marker command refuses. There is still no automatic retry and no effect authority.

For the two indistinguishable histories, identical retained facts and identical new fixture inputs must therefore have the same eligibility. A later valid model transition does **not** turn B’s earlier unknown response into own-COMMIT confirmation.

### 3. Leave operational dispatch eligibility explicitly unimplemented

The existing operational **Validated No-Dispatch Evidence** requirement remains in force. This fixture facade must not claim to implement its full cross-invocation or cross-restart knowledge requirements.

Before provider-wired reliable execution, the owner contract must identify the durable evidence or other explicitly governed authoritative input that establishes the required dispositions—or deliberately re-derive that requirement with an adequate safety argument.

That is a later runtime prerequisite, not something supplied by fixture success, logs, chat history, or a caller’s `verified` flag.

**My earlier brief contributed to this overconstraint:** it carried the full operational no-dispatch prerequisite into the fixture-only contract without selecting a representation capable of proving it after restart. The correction should make that scope distinction explicit rather than leave Codex to invent hidden state.

## Next Codex turn

Continue in the **same contract-authoring conversation**, rooted at:

```text
/Users/ds/Repositories/ES-Private-Replay-Progress-v1
```

Use:

:chatgpt-content-reference{index="2"}[Download the K1 contract-correction prompt](sandbox:/mnt/data/ES_Private_Replay_Progress_K1_Knownness_Contract_Correction_20261118.md)

SHA-256:

```text
483ae7a52d67d66dc5bb0822cdfc5a94650ce485d1a9f6672fdf005c220c5955
```

This is a **bounded correction of the existing five-file candidate**, not another reconnaissance campaign. The prompt carries the explicit selection above and embeds the complete preceding Codex report, exact opening manifest, and exact v2 recipe source; I verified those embedded payloads byte-for-byte.

The writable scope remains:

```text
PLANS.md
.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md
.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md
.docs/execution_lifecycle/es_execution_admission_model.md
docs_contract_test.go
```

The correction must align the operation table, restart examples, unknown-outcome table, facade, authority split, future tests, and plan. **Appending a disclaimer while leaving the stronger promise elsewhere is insufficient.**

The future acceptance cases must separately establish:

- no second write within an unknown invocation;
- later current-state replay without retroactive own-COMMIT confirmation;
- an explicitly supplied later fixture command under fresh CAS;
- identical eligibility for indistinguishable retained histories;
- refusal of a new marker when one already exists;
- zero runtime/provider effects throughout.

The documentation assertions also need bounded negative coverage. The delivered new test primarily checks phrase presence at `docs_contract_test.go:12549–12648`; that can preserve a stated requirement without proving the requirement has a realizable input. The next checks should reject claims that fixture replay resolves prior unknown writes, that the facade proves full operational no-dispatch eligibility, or that unknown automatically leads to a fresh mutation.

The turn runs only the same four documentation-validation commands and returns another exact five-file packet. **No product implementation, diagnostic replay, migration, probe build, full-suite run, staging, commit, or publication is authorized.** R1, R2, R3, and the completed historical audit campaigns are not reopened.

Expected endpoint:

```text
ES_PRIVATE_REPLAY_PROGRESS_K1_CONTRACT_CORRECTED_READY_FOR_REVIEW
```

This remains one integrated source slice. Once the corrected operating model is consistent, implementation can proceed through the pooled-reader prerequisite, versioned custody/migration, and durable composition, followed by fresh independent audit.

**Sources:** Exact uploaded ZIP; delivered persistence ADR §15B, submit/recovery §6B, plan, admission classification, and changed documentation assertions. The linked review includes verbatim line-numbered excerpts. Codex’s validation and live-checkout preservation remain report-based.

**Confidence:** Packet identity **0.99**; R1–R3 architectural resolution **0.97**; K1 contract finding **0.97**, given the declared complete state and interface. No implementation or runtime correctness claim is made.
