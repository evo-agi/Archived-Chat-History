# Execution Substrate — Private replay progress K1 contract correction

## Objective and disposition

Continue in the same foreground Codex conversation that authored the reconciled five-file contract. This is a narrowly bounded owner-contract correction, not another reconnaissance campaign and not product implementation.

The exact review packet authenticated successfully. R1 reconciliation-history semantics, R2 shared object-allocation lifecycle, and R3 previous-schema probe build origin are accepted as architectural directions. The delivered contract is not yet frozen for implementation because K1 requires knowledge about past unresolved writes that the declared retained state and finite interface do not supply after restart.

Correct that overclaim using the explicit scope selection below. Do not invent a durable knowledge ledger, caller-verified flag, global registry, hidden report authority, second database, queue, or extra attempt. Do not silently lower a production safety requirement. The existing operational Validated No-Dispatch Evidence requirement remains unchanged and unimplemented by this fixture slice.

Expected successful endpoint:

```text
ES_PRIVATE_REPLAY_PROGRESS_K1_CONTRACT_CORRECTED_READY_FOR_REVIEW
```

A complete inline report and exact five-file review packet are required. No implementation, staging, commit, push, PR mutation, merge, deployment or runtime wiring is authorized.

## Conversation attachment versus execution target — routing clarification

Continue in the SAME foreground Codex conversation, which the user confirms is
attached to or initially rooted at:

    /Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1

That is the conversation's starting workspace, NOT this tranche's writable
source target. Do not require a new conversation merely because its attachment
still names A1. The original owner-contract prompt explicitly permitted this
conversation to create and work in the standalone progress candidate.

The only source checkout eligible for the five-file K1 edits and the selected
documentation validation is:

    /Users/ds/Repositories/ES-Private-Replay-Progress-v1

Use an explicit command working directory, a scoped `cd` in each relevant shell
invocation, or `git -C` for Git reads. Use absolute target paths for file edits.
Do not assume a prior `cd` persists across tool invocations. Run the manifest
recipe from the progress checkout, never from the conversation's starting
workspace. All existing evidence/output rules below remain unchanged.

Fold these observations into the existing opening provenance check; do not
create a separate reconnaissance turn, test replay or acceptance campaign:

- Record the observed initial physical working directory separately from the
  execution target's physical root, Git top-level, Git directory and common
  directory. Confirm the target is the reported standalone checkout rather
  than an alias for A1 or shared Git administration.
- Verify the progress target against the exact branch, HEAD, index posture,
  five-file manifest and unchanged-file requirements below. The conversation's
  attachment naming A1 is not itself a candidate provenance mismatch.
- Keep the A1 checkout read-only and preserve its source, index, refs and config.
  A small read-only identity/status observation may record that preservation;
  no historical A1 validation campaign is required.
- If the target is missing, inaccessible, aliased unexpectedly, or does not
  match the supplied candidate, stop before source writes and state the actual
  discrepancy. Do not edit A1 instead, move/copy the patch between checkouts,
  create another clone, switch branches, reset, rebase, or normalize either
  checkout to make an identity check pass. Do not bypass sandbox permissions.

At closeout identify both the conversation attachment (user-reported where it
cannot be observed) and the actual edit/test/provenance target. Do not claim
that the chat was relocated. Report any source or routing discrepancy honestly.

This clarification changes routing language only. It does not change K1,
R1/R2/R3, the accepted review-packet identity, the five-path write scope,
validation commands, source baseline, appendices, or stop-before-commit posture.

## Repository, frozen opening target, and provenance

```text
physical/Git root:
/Users/ds/Repositories/ES-Private-Replay-Progress-v1
branch:
codex/private-replay-progress-v1
upstream:
origin/trunk_dev
HEAD:
f1aa8b934cc26c16a966a110c7b408abdaeadce7
HEAD sole parent:
fb9ae55797d9fcc02863c23fe8d3e43d16eac542
HEAD complete tree:
8dd27f9acba98ed70d93736bdef8300ef1aba53f
source leaves:
427
opening state:
exactly five unstaged tracked regular modifications, disk 0644 / Git 100644
index equals HEAD
zero staged, unmerged, ordinary-untracked, ignored or extra repository paths
other 422 tracked files equal HEAD bytes and modes
canonical opening manifest:
ad2e60dfb5f4377cbd4531ab9555c90ec0391b76b7c879764b18ddf5693f0491
opening full-index binary diff:
3497dab92bda92ad7b56a6eac76fa8995859106a7c1c4a67ad739bf2f80f7665
recipe ID:
governed-execution.audit-patch-manifest.v2
recipe bytes / SHA-256:
7275 / c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca
```

Authenticated review ZIP:

```text
/Users/ds/Repositories/ES-Private-Replay-Progress-Contract-Revision-20261118-bjtsyaja/ES-Private-Replay-Progress-Contract-Reconciled.zip
419360 bytes
SHA-256 8d0734b788cb04e23624ee2282bba9e08153caafacfe447d2f33639601f01af9
```

Prior revision evidence root:

```text
/Users/ds/Repositories/ES-Private-Replay-Progress-Contract-Revision-20261118-bjtsyaja
```

Authenticate the five live files against Appendix B and this archive. Inspect the archive inventory, README and source payload without executing anything from a prior evidence root. Run the exact Appendix C recipe twice to distinct absent outputs, require the supplied canonical bytes and no hidden extra paths. Use material prior evidence actually relied upon; do not fingerprint all historical roots or require volatile timestamps. Record any remote observation separately; no fetch, rebase, checkout synchronization or source-ref movement is permitted or needed. The pinned local candidate remains the review target.

## Posture and permitted writes

The foreground parent is the sole writer. Close previous explorers. No subagents are necessary for this bounded correction. No independent-audit verdict is issued in this turn.

Only these existing five files may change:

```text
PLANS.md
.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md
.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md
.docs/execution_lifecycle/es_execution_admission_model.md
docs_contract_test.go
```

All product Go, existing migration literals, APIs, app/config, examples/scripts, historical artifacts and other checkout bytes are frozen. Do not implement the pooled reader, allocator, codec, migration, facade or progress service. Do not run product diagnostics, full-suite tests, old-opener builds, migration tests, live services or module downloads.

Create one absent private external evidence root, for example a fresh `ES-Private-Replay-Progress-K1-Contract-20261118-*` directory under `/Users/ds/Repositories`. Use 0700 for owned directories and 0600 for reports/logs. Do not chmod the existing parent. Exact exported source files retain 0644 inside private parent directories. Do not overwrite prior outputs or restore timestamps. Use `PYTHONDONTWRITEBYTECODE=1`, `python3 -B`, and `sys.dont_write_bytecode=True` in any copied verifier. Never import or execute source directly from a historical evidence root.

## Governing files and classification

Read AGENTS.md, PLANS.md, the three affected lifecycle owner documents, the exact changed documentation assertions, and the directly relevant pinned durable-service caller/model contracts. The current implementation is schema 3 with historical codecs 1/2 and immutable codec 3. Codec 4/scope 2 remains a proposed Bounded slice rule extension on the reliable-submit Reopened redesign seam. No current public or runtime behavior is changed.

The attached architectural review is a chat-selected correction to the proposed fixture operating model. Record that selection in owner docs before updating assertions. Do not present the corrected proposal as implemented or independently accepted.

## K1 — exact issue to resolve

The delivered ADR requires, at lines 1500–1514, complete operational no-dispatch validation and knowledge of all relevant previous write outcomes; it permits the example's first marker after restart. Lines 1560–1564 and 1595–1606 disallow deriving a fresh marker from an earlier unknown response and an absent marker. The 47-field row has no persistent unresolved-call history, and the finite synchronous borrow in submit §6B ends on return/cancellation. No declared restart input records the earlier unknown response.

Make the two histories explicit in the revised contract:

- A: predecessor with known committed intent/reconciliation and no marker, then restart.
- B: the same predecessor, marker transaction not committed, error response classified unknown with unavailable recovery, confirmed cleanup, then restart.

The declared retained facts can be identical. The same later authenticated fixture request cannot be classified differently solely because a diagnostic driver remembers which history occurred. This is a contract/input gap, not a newly executed source regression.

## Selected resolution — three distinct guarantees

### 1. One write invocation and its own recovery

Preserve known-committed, evidenced not-applied/refused and unknown dispositions exactly. Never turn unavailable/canceled/corrupt recovery into known noncommit or success. Unknown recovery performs no second semantic write, no rebase, no newly minted replacement mutation ID and no retry loop. Confirm own COMMIT only from the currently selected full expected-record equality after authentication. Advanced or different winners do not confirm that particular invocation.

A failed recovery response withholds projection in that invocation. Known commit with failed post-authentication retains its known committed disposition while withholding its projection. A later current-state read must not rewrite either earlier result.

### 2. A later explicit fixture command or current-state read

This facade models current persisted state, not a durable history of every failed response. A later call is a separately and explicitly supplied fixture operation, with fresh original authentication, a new live one-use borrow and the caller's exact current expected revision/mutation input. Do not automatically turn an unknown response into this call.

An authenticated read may return current fixture state; it is not own-COMMIT proof for an earlier call. Existing latest-operation replay rules remain distinct from history-wide proof.

A new explicit fixture marker is a storage-model transition. It requires the supported current schema/codec, matching authenticated immutable original, active retained row, exact run, required intent, absent marker/provider, exact expected revision and the selected current row/transition constraints, rechecked in the CAS transaction. Do not claim it establishes knowledge about every prior response or the full operational §8 predicate.

A stored marker remains immutable. Exact latest replay may describe it but cannot create another marker. A new marker command against an existing marker refuses. A stale predecessor cannot be rebased. Preserve all codec-4 reconciliation-history and terminal evidence rules already selected by R1.

For the two indistinguishable histories, the same explicit fixture command has the same eligibility from the same retained state. Where no marker committed, that command may create the first stored synthetic marker in either history. The prior unknown result remains historically unknown and is not relabeled. All outcomes remain effect-ineligible.

Kind-1 codec-4 NoDispatch records a bounded fixture no-marker observation; it is NOT a certificate of operational no-dispatch eligibility. Do not change the inherited codec-1/2 rule or operational §8. Keep the existing type/tag only with this explicit scope qualification; add no new phase or storage field.

### 3. Operational dispatch and restart recovery

The complete operational Validated No-Dispatch Evidence requirement remains in force. This source-only fixture slice does not implement its cross-invocation/cross-restart evidence/authorization mechanism. Before any provider-wired reliable execution, a separately reviewed operating model must identify the durable ES-owned evidence or other explicitly governed authoritative input that establishes the relevant dispositions, or explicitly re-derive that requirement with an adequate safety proof. No present facade result authorizes provider I/O.

Do not add that future mechanism now, and do not imply that fixture success qualifies it. No traces, reports, test ledgers, local flags, chat history or caller `verified` boolean may silently supply product authority.

This is an explicit narrowing of the new fixture proof claim, not a loosening of existing runtime safeguards. State it plainly in PLANS.md and both owning contracts.

## Consistency corrections

Inspect all five changed files for the old overclaim, not merely the two quoted paragraphs. In particular align:

- ADR §15B.3 op5 and op7 tables, first-marker predicate, examples and negatives;
- ADR §15B.4 per-invocation recovery versus separate later reads/commands;
- ADR §15B.5 authority/storage table (do not assert that Go manufactures missing past knowledge);
- ADR §15B.6 implementation path descriptions;
- ADR §15B.7 future acceptance matrix and test names;
- submit §6B ApplyFixtureProgress and capability lifetime;
- admission classification and PLANS.md;
- root documentation assertions currently requiring full historical knownness.

Do not leave the stronger old promise in place with a disclaimer appended elsewhere. Preserve exact write-unknown classification and no-automatic-retry language within the correct invocation scope.

Rename prospective tests where needed so their names express bounded guarantees. Use these explicit replacements:

```text
NoDispatchThenFirstMarkerAfterRestart
  -> FixtureNoMarkerThenFirstMarkerAfterRestart
UnknownMarkerCommitDoesNotAuthorizeNextMarker
  -> UnknownMarkerCommitDoesNotRetryWithinInvocation
```

Add prospective cases (no product implementation now):

```text
IndistinguishableRestartHistoriesHaveSameFixtureEligibility
ExplicitLaterFixtureCommandDoesNotConfirmPriorUnknown
CurrentReplayDoesNotConfirmPriorUnknown
ExistingMarkerExactReplayOnly
```

Retain stale/predecessor, wrong-original/run, terminal contradiction, exact expected-row own-confirmation and zero-effect tests. State the distinction between exact latest replay and ownership of an earlier uncertain transaction. A fresh test-only command is not an automatic retry and must be counted separately.

## Documentation tests

The current new root test largely asserts phrase presence. Refine only its relevant sections and add bounded negative/mutant coverage for K1. At least prove that the documentation checks reject:

1. changing the fixture statement to claim it establishes the complete operational no-dispatch predicate;
2. stating that a current replay or absent marker resolves a prior unknown write;
3. permitting automatic fresh mutation/rebase after write unknown;
4. omitting the distinction between explicit later model commands and operational permission.

Keep the positive current/target separation, all R1/R2/R3 assertions, legacy scope and authority checks. Avoid a giant universal markdown parser. Use the existing section extraction and local semantic-check style; report precisely what each negative case establishes.

The corrected text and its positive/negative documentation tests are the output. Do not create product test skeletons that skip or assert fake success.

## Validation

Use the already qualified environment, but authenticate actual executables instead of assuming PATH:

```text
GO=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go
GOFMT is its sibling gofmt
GOTOOLCHAIN=local
GOPROXY=off
GOSUMDB=off
GOWORK=off
GOFLAGS=-mod=readonly
CGO_ENABLED=0
GOTELEMETRY=off
GOMODCACHE=/Users/ds/go/pkg/mod
GIT_OPTIONAL_LOCKS=0
GIT_NO_LAZY_FETCH=1
GIT_TERMINAL_PROMPT=0
PYTHONDONTWRITEBYTECODE=1
fresh task-owned GOCACHE/GOTMPDIR/TMPDIR
outer umask 077; Go-test subprocess umask 027
```

Use the same four serial commands, including any new K1 subtests under the existing selected parent:

```sh
"$GO" version
"$GOFMT" -d docs_contract_test.go
git --no-pager diff --check
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateOriginalReplayProgressContractSelection|TestReliableSubmitPersistenceAndConcurrencyADRDocsContract|TestSubmitIdempotencyCorrelationAndRecoveryDocsContract|TestReliableSubmitPureModelDocsAndSourceContract|TestReliableSubmitPublicOptInAndVersioningDocsContract|TestReliableSubmitContractAdapterFoundationDocsAndSourceContract|TestReliableSubmitBindingProducerDocsContract|TestIntegratedAcceptanceGateDocumentationIsConsistent|TestIntegratedCandidateStatusSeparatesCAndT)$' .
```

After every final validation command independently observe HEAD/index, exact five-path scope and all frozen bytes/modes, with both:

```sh
git ls-files --others --exclude-standard -z
git ls-files --others --ignored --exclude-standard -z
```

Retain actual execution associations, commands/exits/log identities, reached test parents/subtests, expected negative cases and skips. Passing phrase checks do not prove the future product. Development iterations are allowed within scope and retained honestly; freeze a final coherent generation. Do not rerun a failed final result away without documenting its cause and any changed input. A new product scope need stops, not an unauthorized fix.

## Review delivery and closeout

Generate the exact v2 manifest twice externally and require byte equality. Compare the five rows to the opening target and account for every change. No new source path, deletion, rename, type or mode change. Recheck all 422 other files and empty index/untracked inventories.

Create a small new ZIP with:

- the five complete current source files under `source/`;
- exact full-index binary HEAD-to-candidate patch;
- exact opening-to-corrected five-file patch;
- canonical v2 manifest;
- README identifying both baselines and K1's explicit selection;
- self-excluding per-entry path/type/mode/size/hash inventory.

Use unique regular-file members, safe relative paths, source modes 0644, retained evidence modes 0600, and no Git admin, caches, secrets, databases or extra files. Verify every entry against its actual source. Reconstruct both patch targets only in authorized disposable task-owned copies if using that packaging check; preserve repository modes without chmodding original roots. Do not use archive mtime as provenance. Keep the new ZIP outside source and report exact size and SHA-256. Attach it where supported; otherwise give the exact local upload path. Do not pretend a Mac-local path is a ChatGPT attachment.

Deliver the full human-readable closeout inline: exact baseline, changed paths, K1 resolution, revised per-invocation/later-fixture/runtime matrix, the two indistinguishable histories, preserved R1/R2/R3, test commands/results and negatives, skipped/unperformed validation, remaining operational prerequisite, full canonical JSON, and ZIP identity. Private reports are supplementary. No verdict-only local-file answer. On report transport failure, return REPORT_INLINE_BLOCKED without a readiness verdict.

End with:

```text
ES_PRIVATE_REPLAY_PROGRESS_K1_CONTRACT_CORRECTED_READY_FOR_REVIEW
PRODUCT_SOURCE_BYTES_UNCHANGED
POOLED_LOADCLAIM_DEFECT_NOT_REPAIRED_IN_THIS_TURN
LOADCLAIMFRESH_BEHAVIOR_PRESERVED
SCHEMA4_AND_CODEC4_NOT_IMPLEMENTED
CROSS_RESTART_OPERATIONAL_WRITE_UNCERTAINTY_GATE_NOT_IMPLEMENTED
INDEPENDENT_ACCEPTANCE_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PRS_NOT_MODIFIED
EXISTING_SOURCE_CHECKOUTS_NOT_SYNCHRONIZED
RUNTIME_WIRING_NOT_PERFORMED
PUBLIC_RELIABLE_SUBMIT_NOT_ENABLED
```

## Stop conditions

Stop and report on opening candidate/recipe mismatch, an unsupported object, unexplained retained-source drift, required changes outside the five paths, an attempted runtime-policy relaxation, missing raw material evidence actually needed for a claim, or an unresolved contradiction in this explicit fixture/runtime separation. Do not introduce a hidden retained knowledge source as a workaround. Do not reopen R1/R2/R3 or historical evidence campaigns absent a concrete newly demonstrated conflict.

---

# Appendix A — Complete preceding Codex reconciliation report

Exact transported bytes are delimited below. They describe the opening candidate; K1 above is the selected correction, not a retroactive change to that report.

Bytes: 28423
SHA-256: `bf7adf63e242081186b22e80a9a93ac1d9602d738bf8929c44b52b9c3d7f56af`

<BEGIN_COMPLETE_CODEX_RECONCILIATION_REPORT>
The reconciled five-file contract is ready for architectural review. All four frozen validation commands passed, including nine documentation test parents and eight subtests, with zero failures or skips. The five changes remain unstaged and uncommitted. All 422 other tracked files match `HEAD` byte-for-byte and mode-for-mode.

**Exact review packet:** [ES-Private-Replay-Progress-Contract-Reconciled.zip](/Users/ds/Repositories/ES-Private-Replay-Progress-Contract-Revision-20261118-bjtsyaja/ES-Private-Replay-Progress-Contract-Reconciled.zip)

The ZIP is **419,360 bytes**, mode `0600`, SHA-256 `8d0734b788cb04e23624ee2282bba9e08153caafacfe447d2f33639601f01af9`. Its ten verified regular-file entries contain the five complete `0644` files, both patches, the canonical manifest, a README and the delivery inventory. Both patches independently reconstructed all five delivered files from their stated baselines in private copies. The available attachment tool is limited to pull requests, so the link above is the precise local ZIP for upload. [Delivery receipt](/Users/ds/Repositories/ES-Private-Replay-Progress-Contract-Revision-20261118-bjtsyaja/delivery-receipt.json) · [Per-entry inventory](/Users/ds/Repositories/ES-Private-Replay-Progress-Contract-Revision-20261118-bjtsyaja/review-packet/delivery-inventory.json)

## Source and evidence

| Item | Verified identity |
| --- | --- |
| Checkout | `/Users/ds/Repositories/ES-Private-Replay-Progress-v1` |
| Branch and upstream | `codex/private-replay-progress-v1` → `origin/trunk_dev` |
| Origin | `git@github.com:evo-agi/Execution-Substrate.git` |
| PR #10 squash | `f1aa8b934cc26c16a966a110c7b408abdaeadce7` |
| Sole parent | `fb9ae55797d9fcc02863c23fe8d3e43d16eac542` |
| Complete tree | `8dd27f9acba98ed70d93736bdef8300ef1aba53f`, 427 leaves |
| Opening canonical manifest | `4857bbf5f1572dbfb78c221a13d657107bcfbf6690d830b7769cc35465bdb0da` |
| Opening tracked diff | `8bf2dc2d8ae5027b8b21b53d7cd51598d07c5b2c5a744933a572338f894aa9bf` |
| Opening-to-revised patch | `91ad2f6e0365604bd7ccb46d845158a6e58213ad84782f4e786ab8281d9aadb4` |
| Final `HEAD`-to-candidate full-index binary patch | `3497dab92bda92ad7b56a6eac76fa8995859106a7c1c4a67ad739bf2f80f7665` |

Both opening recipe runs reproduced all 1,331 supplied canonical bytes. I independently matched the five complete opening files to their hashes, sizes and modes. The index equaled `HEAD`, with zero staged, unmerged, ordinary-untracked or ignored paths, at opening and closeout. I omitted the optional remote observation. [Opening checkpoint](/Users/ds/Repositories/ES-Private-Replay-Progress-Contract-Revision-20261118-bjtsyaja/revision-opening-checkpoint.json) · [Final checkpoint](/Users/ds/Repositories/ES-Private-Replay-Progress-Contract-Revision-20261118-bjtsyaja/final-revision-closeout-checkpoint.json)

Appendix A matched its 40,665-byte transport hash, `472497a77c677bb25e94df6ceb76b42b0b5861dfe15291e9e8bb87a30ba9ea6d`. The authenticated prior subset was the opening inventory, v3 closeout checkpoint, v3 review report, both v3 manifests, v3 validation freeze and Go test record, and the two verifier scripts copied into the new root. The v3 artifact index matched `31d2900bfde6f6da19e3bb53a843b6c16352eae31802a6f0f1683a98540d17af`. The previous report and passed results remain bound to their original bytes. [Exact authentication subset](/Users/ds/Repositories/ES-Private-Replay-Progress-Contract-Revision-20261118-bjtsyaja/opening-prior-authentication.json)

## R1 — Preserve earlier reconciliation without blocking the same attempt

The pinned ADR allows first same-run dispatch after the full no-dispatch predicate, current revision validation and known marker COMMIT. The inherited Go validator and migration CHECKs instead make a stored `NoDispatch` tuple incompatible with any later marker. The service also sets reconciliation once and copies it into terminal successors, while the validator requires Pending, Ambiguous and Inconsistent reconciliation to match a nonterminal current phase. Those are static contract/source mismatches. The revision selects a codec-4-only interpretation and preserves the inherited codec-1/2 rules and immutable codec 3. [Baseline dispatch rule](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:443) · [Pinned record validator](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/durable_record.go:351) · [Pinned reconciliation and terminal service](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/durable_service.go:377) · [Revised contract](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1447)

The existing kind/ref/time tuple is written once. Kinds 1, 2, 3 and 6 record what the service observed at that time. The current phase, marker, provider and receipt supply the current decision. Ops 5, 6, 8 and 9 preserve the tuple byte-for-byte. Op 7 fills an empty tuple only. An identical fact can be a no-op at the current revision only while its current evidence predicates still hold. That no-op supplies no new COMMIT proof. [Reconciliation table](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1473)

| Kind | When recorded | Legal later shape |
| --- | --- | --- |
| 0 Absent | Initial `0/NULL/NULL`. Op 7 never writes kind 0. | Any phase, subject to the current decision facts that phase requires. |
| 1 NoDispatch | Phase 3, same run, committed intent, no marker or provider, complete current no-dispatch proof. Stays 3. | Without marker, phase 3 with no provider. With marker, phase 3 or 4–7. Observation time is at or before marker time. |
| 2 Pending | Candidate 3/4/5 with marker and absent or kind-1 provider. Records at phase 4. | Phases 4–7 with marker. Original tuple retained. |
| 3 Ambiguous | Candidate 3/4/5 with marker and absent or kind-2/5 provider. Records at phase 5. | Phases 4–7 with marker. Original tuple retained. |
| 4 Accepted | Corroborates existing phase 6 with marker, provider kind 3 and receipt. | Phase 6 only, with the same marker, provider and receipt. |
| 5 NotAccepted | Positive same-attempt negative evidence with marker moves a candidate with absent provider to 7, or corroborates an existing phase 7 with provider kind 4. | Phase 7 only, provider absent or kind 4, no receipt. |
| 6 Inconsistent | Candidate 3/4/5 with marker and absent or kind-2/5 provider. Records at phase 5. | Phases 4–7 with marker. Original tuple retained. |

Every nonzero tuple needs an assigned run, committed intent and time at or after intent. Kinds 2–6 also need time at or after the marker. Provider evidence stays tied to current phase. Kind 1 requires phase 4, kinds 2/5 require 5, kind 3 requires 6 and kind 4 requires 7. Op 6 fills an absent provider tuple and may move a reconciled nonterminal row to the newly observed phase. Ops 8/9 independently validate positive evidence tied to the same original, run and marker, and may replace a nonterminal provider tuple. Phase 6 requires an immutable receipt. Phase 7 requires provider kind 4 or reconciliation kind 5. Terminal phases stay fixed. [Provider and terminal rules](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1483)

A new op 5 revalidates the full current no-dispatch predicate even when kind 1 is already stored. It checks the existing authenticated active original, hydrated phase 3, same claim/plan/run, committed intent, absent marker and provider, known dispositions of all relevant writes, exact current predecessor and the same row in the CAS writer transaction. Codec-4 op 5 binds ordered digest parts `[3,4]`, the run and marker refs. A retained observation, failed read or caller flag cannot establish missing write knowledge. A known marker COMMIT would be a separate prerequisite on a later governed effect path. The fixture performs zero provider I/O. [First-marker and terminal predicates](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1498)

These examples use creation time 10, active retention, NULL expiry/unavailable time and an empty unavailable reason. Each example keeps its complete authenticated original, physical rowid, caller/key, codec and scope fixed. Tuple times are symbolic nanoseconds and `—` is NULL. The two terminal branches use independent copies of the same predecessor. [Complete example states](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1534)

| State | Phase/rev/update | Latest op/predecessor/mutation and inputs | Run | Intent | Stage | Marker | Provider | Reconciliation | Receipt |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A before reconciliation | `3/3/13` | `3/2/m3 [I]` | `R/12` | `I/13` | — | — | `0/—/—` | `0/—/—` | — |
| A after reconciliation and restart | `3/4/14` | `7/3/m4 [R,1,N]` | `R/12` | `I/13` | — | — | `0/—/—` | `1/N/14` | — |
| A after first marker | `3/5/15` | `5/4/m5 [R,D]` | `R/12` | `I/13` | — | `D/15` | `0/—/—` | `1/N/14` | — |
| B before reconciliation | `4/5/15` | `6/4/m5 [R,1,P]` | `R/12` | `I/13` | — | `D/14` | `1/P/15` | `0/—/—` | — |
| B after Pending and restart | `4/6/16` | `7/5/m6 [R,2,Q]` | `R/12` | `I/13` | — | `D/14` | `1/P/15` | `2/Q/16` | — |
| B accepted branch | `6/7/17` | `8/6/m7a [C,A]` | `R/12` | `I/13` | — | `D/14` | `3/A/17` | `2/Q/16` | C |
| B not-accepted branch | `7/7/17` | `9/6/m7n [X]` | `R/12` | `I/13` | — | `D/14` | `4/X/17` | `2/Q/16` | — |

Ambiguous and Inconsistent use phase 5 with reconciliation kind 3 or 6 and absent or compatible provider. Both terminal branches preserve that original tuple. [Examples and refusals](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1534)

| Negative or replay case | Selected result |
| --- | --- |
| Unknown marker COMMIT, with failed, missing or advanced readback | Preserve write unknown and withhold projection. Only exact full expected-row proof can confirm the original write. |
| Stale predecessor without exact latest match | Stale. No rebase or write. |
| Already stored marker and fresh marker command | Refuse even with the same marker ref. Exact latest read replay reflects the recorded result. |
| Changed original | Fixed conflict before disclosure or write. |
| Wrong run or marker association | Refuse before state change. |
| Opposite terminal evidence or alternate receipt | Refuse without changing the terminal row. |
| Old reconciliation mutation after marker or terminal advancement | Stale. While it is still latest, exact input replays and changed input under the same mutation conflicts. |

Admission and custody qualify the original and the scoped capability. Go remains the sole semantic transition writer, including typed evidence, operation digest, when-recorded conditions and write knownness. SQL constrains row shape, immutable columns, expected revision, fixed marker/reconciliation/receipt and permitted per-op storage deltas. Its codec-4 historical tuple branch leaves the older CHECK branch intact. [Authority and storage-delta table](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1632)

## R2 — Shared count and exclusive create

`PublishSealedSynthetic` currently checks the budget and creates the file outside a SQLite transaction. The proposal introduces one custody-owned `allocateReplayObject` used by both `PublishSealedSynthetic` and `PublishProgressOriginal` on the same qualified database and object namespace. This is a future narrow scope-1 change as well as a scope-2 boundary. Codec-3 format, immutable rows, key/grant rules and `loadClaimFresh` callers and lifetime are preserved. [Current publisher](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/replay_custody_file.go:399) · [Proposed allocator](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1702)

| Boundary | Selected lifecycle |
| --- | --- |
| Publisher entry | Validate custody, permit, frozen identity and request. Arrange the existing irreversible burn at the publication attempt boundary. The allocator neither consumes a permit nor changes a grant. |
| Acquire and dispatch | Acquire the exact checked connection and install allocator-local release ownership before one caller-context `BEGIN IMMEDIATE`. Predispatch cancellation normally releases an unused connection. Uncertain dispatched BEGIN forbids ordinary release and proceeds to exact discard. |
| Count and create | Validate held and visible root/objects/v1 identity. Count all existing names, including inert and orphan names, reading at most 33. Refuse at 32. Otherwise make one descriptor-relative `O_CREAT\|O_EXCL\|O_RDWR\|O_NOFOLLOW\|O_CLOEXEC` create at the preselected basename. Refuse collision, I/O failure, drift or cancellation. |
| Descriptor ownership | Own a created FD immediately. Check empty regular file, owner/group, `0600`, one link and matching held/visible device and inode. Recheck the parent chain and close the count descriptor. |
| End known transaction | The allocator issues zero DML and zero COMMIT. Use private request-independent five-second `ROLLBACK` on known-BEGIN exits. Sample response and `cleanupCtx.Err()` immediately before self-cancel. Require confirmed end and ordinary wrapper return. |
| Uncertain BEGIN or end | Disable ordinary release, discard the exact connection, permit one real synchronous rescue, and withhold ordinary close if both remain unconfirmed. A nil rollback response after observed expiry is unavailable. Confirmed quarantine does not restore the allocation result. |
| Refusal after create | Close each owned FD once and keep the name as an inert counted orphan. No descriptor transfer, Seal, claim, adoption, reuse or refund. SQL rollback does not undo the filesystem entry. |
| Successful handoff | After confirmed rollback and wrapper release, recheck request and held/visible identity. Transfer one unpublished FD. Permit consumption, active-key check and normal Seal/write/fsync/close/reopen/verification occur outside the lock. |

The critical section excludes callbacks, material acquisition, encryption, file writes, fsync, grant transactions, claim establishment and CAS. Its cleanup budget bounds the context observation. It carries no physical-close deadline, mixed-old-binary guarantee or protection against unmanaged replacement. Older fixture handles must close before upgrade. A1/O2/C1/D1 and shared SQLite helpers stay outside this change. [Allocation lifecycle and limits](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1719)

| Shared bound | Owner and claim strength |
| --- | --- |
| Four custody-bearing claims | Establish writer transaction classifies occupation first and counts all codec-3/4 rows, including every progress phase, before inserting a new key. |
| 32 object names | Shared allocator serializes qualified same-domain count/create. Existing orphans count. The bound does not prove persistence of unsynced names after crash or constrain unmanaged insertion. |
| 32 aggregate durable reservations | Existing `reserveReplaySealUse` writer transaction with the shared fixture profile. Only known COMMIT issues a permit. |
| `2^32` reservations per envelope key | Same reservation transaction, registry fingerprint identity and counter. Scope, failure and migration grant no reset or refund. |
| 16 MiB database and sidecars | Existing summed `checkReplayDBFiles` check for DB, WAL, SHM and journal. It detects unsafe metadata and observed overrun at fixture boundaries. It is not a hard physical ceiling or a reason to rewrite an earlier write’s disposition. |

[Budget ownership](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1742)

## R3 — Probe build origin and exact contract access

The earlier candidate already defined the opaque facade, typed `ProgressOriginalView`, issuer/rowid/original binding, one synchronous borrow, cancellation and no raw plaintext/store/full-record escape. The revised file ties that interface to R1 and R2. The ZIP now supplies the actual complete bytes, including that interface. The prior candidate also had a one-entry probe overlay. The revision pins the complete external build root and binds every actual compiled source, embed and module input, plus the overlay, harness, toolchain, environment, argv and binary. [Exact facade and borrow contract](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md:891) · [Build-origin contract](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1830)

The following is prospective. `SCHEMA3_SOURCE` is the complete authenticated PR #10 export. The sole overlay entry adds `es/admission/internal/reliablesubmit/previous_schema3_probe_test.go`. The independently populated schema-4 target exists before the old opener runs, and both witnesses use nonmigrating reads. Build paths and environment can affect binary reproducibility separately from source identity. Preserve the existing historical PB1 binary and authentic schema-3 fixture for their distinct purpose. [Old-binary witness](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1686)

```sh
(
  cd "$SCHEMA3_SOURCE" || exit
  "$GO" test -mod=readonly -overlay "$SCHEMA3_OVERLAY" -c -o "$SCHEMA3_PROBE" ./es/admission/internal/reliablesubmit
)
ES_REPLAY_SCHEMA3_TARGET="$SCHEMA4_TARGET" "$SCHEMA3_PROBE" '-test.run=^TestPreviousSchema3OpenerProbe$' -test.v
```

## Prospective path and acceptance map

Phase 0 is this contract review. Phase 1 remains the local pooled `loadClaim` repair. Phases 2–4 add codec/schema/format, compose the same durable service and prove restart, concurrency and no effects. Phase 5 is one fresh independent audit of the integrated slice. [Plan](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/PLANS.md:5) · [Full path inventory](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1750)

`I/` denotes `es/admission/internal/reliablesubmit/` and `A/` denotes `es/admission/`.

| Owner | Prospective paths |
| --- | --- |
| SQLite | `I/sqlite_store.go`, `I/sqlite_replay_claim.go`, `I/sqlite_migrations.go`, new `I/sqlite_replay_progress_schema.go`, `I/sqlite_replay_shape.go`. Preserve migration-3 literal source and prior hashes. |
| Durable model and service | `I/durable_record.go`, `I/durable_operation.go`, `I/durable_service.go`. Add the distinct codec-4 observation compatibility and semantic predicates. |
| Custody | `I/replay_custody_format.go`, `I/replay_custody_structure.go`, `I/replay_custody_file.go`. The last owns both publishers’ allocator. Reuse existing `I/replay_key_use_sqlite.go` primitives. |
| Admission | `A/reliable_submit_replay_format.go`, `A/reliable_submit_replay_hydration.go`, `A/reliable_submit_replay_private.go`. Preserve intent parser and PB1 sources. |
| Storage tests | New `I/sqlite_pooled_claim_read_cleanup_test.go` and `I/replay_progress_test.go`; existing `I/replay_custody_file_test.go`, `I/sqlite_store_test.go`, `I/sqlite_physical_test.go`, `I/sqlite_replay_migration_test.go`, `I/sqlite_replay_shape_test.go`. |
| Admission and static tests | `I/guardrails_test.go`, `A/reliable_submit_guardrails_test.go`, `A/reliable_submit_replay_private_test.go`. |
| Documentation status | The same five delivered files. Existing schema-3 production assertions advance only when implementation lands. |

The previous explicit codec-4-invalid and insert-trigger fixtures remain mapped to unsupported codec 5, a separate malformed-4 case and the v4 trigger as applicable. The inherited record/service tests remain legacy regression evidence. [Compatibility test inventory](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1763)

| Future test | Required coverage |
| --- | --- |
| `TestSQLitePooledClaimReadCleanup` | Real BEGIN/SELECT and read-COMMIT faults, independently bounded cleanup, exact disposal, zero result on uncertainty and healthy same-store follow-ups. |
| `TestPrivateReplayProgressFormatVectors` | Independent wire and digest vectors, corruption and cross-scope refusal. |
| `TestPrivateReplayProgressAdmissionReplay` | Real restart, same original despite changed current inputs, conflict privacy and shared occupation. |
| `TestPrivateReplayProgressTransitions` | `NoDispatchThenFirstMarkerAfterRestart`, `NonterminalReconciliationThenPositiveAcceptedAfterRestart`, `NonterminalReconciliationThenPositiveNotAcceptedAfterRestart`, `HistoricalReconciliationProviderProgress` and `TerminalReconciliationAndContradictions`. Compare unchanged original and retained tuple. Zero effects. |
| `TestPrivateReplayProgressConcurrencyAndCommitOutcome` | `UnknownMarkerCommitDoesNotAuthorizeNextMarker`, `StaleMarkerAndLateReconciliationReplay`, `ExistingMarkerExactReplayOnly` and `WrongOriginalOrRunCannotAdvance`, with exact own-COMMIT proof and failed recovery cases. |
| `TestPrivateReplaySharedObjectAllocation` | Two handles and an independent helper process on the last slot with both selectors. Start with 31 inert names and two real permits. Require one verified publication and no 33rd name. Inject cancellation after create, ambiguous BEGIN/rollback, expiry with nil response, rescue and withholding. Check FD/pool disposition, counted orphan, permit burn, no Seal/claim/refund and normal verification. |
| `TestSQLiteV4MigrationPreservesFullState` | Authentic starting schemas, full old-row/key/grant equality, rollback/lost reply and codec-specific storage constraints. |
| `TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation` | Actual old opener on the already witnessed schema-4 target. Preserve the separate `TestSQLiteV3OldBinaryRefusesWithoutMutation`. |
| `TestPrivateReplayProgressHasNoEffectPaths` | Static and fixture-behavior checks, including conflict, acceptance, unknown and cancellation. Preserve App/API refusal and unkeyed compatibility. |

The allocator cases live in `I/replay_custody_file_test.go` beside `TestReplayPublicationFaultAndIdentity`. Its sole child control is `TestPrivateReplayObjectAllocatorHelperProcess`. The future focused command includes both allocator and existing publication regression tests. [Acceptance identities and commands](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1797)

Current source remains schema 3, historical codecs 1/2 and immutable codec 3. Schema 4, codec 4 and scope `synthetic_progress_nonoperational_v1` are proposed. Each fixture state remains effect-ineligible. The pooled repair, native installed-source qualification, operational ingress and identity, live keys, staging, provider dispatch/recovery, and public reliable Submit remain outside this review. No product tests, diagnostic replay, migrations, probes, full suite, downloads or service calls ran. [Current and target status](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/PLANS.md:15) · [Admission authority](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/es_execution_admission_model.md:603)

## Executed validation and final manifest

Generation `revised-v1` used Go 1.26.5 `darwin/arm64`, sibling `gofmt`, the pinned offline cache, Python 3.13 and OpenSSL 3, fresh private cache/temp directories, outer umask `077` and Go-test umask `027`. Each command below exited zero and had its own executed integrity observation. `gofmt -d` and `diff --check` emitted nothing. All nine selected parents ran. [Frozen environment and argv](/Users/ds/Repositories/ES-Private-Replay-Progress-Contract-Revision-20261118-bjtsyaja/revised-v1-validation-freeze.json) · [Outcomes by identity](/Users/ds/Repositories/ES-Private-Replay-Progress-Contract-Revision-20261118-bjtsyaja/revised-v1-go-test-run.json) · [Revised assertions](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/docs_contract_test.go:12549)

```sh
"$GO" version
"$GOFMT" -d docs_contract_test.go
git --no-pager diff --check
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateOriginalReplayProgressContractSelection|TestReliableSubmitPersistenceAndConcurrencyADRDocsContract|TestSubmitIdempotencyCorrelationAndRecoveryDocsContract|TestReliableSubmitPureModelDocsAndSourceContract|TestReliableSubmitPublicOptInAndVersioningDocsContract|TestReliableSubmitContractAdapterFoundationDocsAndSourceContract|TestReliableSubmitBindingProducerDocsContract|TestIntegratedAcceptanceGateDocumentationIsConsistent|TestIntegratedCandidateStatusSeparatesCAndT)$' .
```

The first packaging verification reconstructed the bytes but failed its mode check because `git apply` inherited umask `077` in the disposable copies. I retained that attempt and verified both patches again with apply subprocesses using `022` inside private `0700` directories. Both then reconstructed all bytes and mode `0644`. The frozen candidate and documentation validation were unchanged. [Packaging attempt record](/Users/ds/Repositories/ES-Private-Replay-Progress-Contract-Revision-20261118-bjtsyaja/packet-v1-failure.json)

The exact 7,275-byte Appendix C recipe `governed-execution.audit-patch-manifest.v2` has SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`. Both final external runs produced identical canonical bytes. Final manifest SHA-256 is `ad2e60dfb5f4377cbd4531ab9555c90ec0391b76b7c879764b18ddf5693f0491`. All five tracked files retain disk mode `0644` and Git mode `100644`. [Final manifest A](/Users/ds/Repositories/ES-Private-Replay-Progress-Contract-Revision-20261118-bjtsyaja/final-a.json) · [Final manifest B](/Users/ds/Repositories/ES-Private-Replay-Progress-Contract-Revision-20261118-bjtsyaja/final-b.json)

```json
{"branch":"codex/private-replay-progress-v1","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/es_execution_admission_model.md","sha256":"2cbd5a6976c9f03f39f84f80197feee76c6f2c72e831032d5575efd67d21be03","size":80097},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md","sha256":"1f32968c6bd2521d0d1ed8548b5f5bd81d2d03da86efb63651208bf8c46635db","size":151285},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md","sha256":"458ed55fc63fefa7d583d522c80dd3a9b3feb47d466f778c8faceff5da16b326","size":101030},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"d223285d17c1b6c7eb107facd71018ca753bbedd2fc1a81062849c1c265935bf","size":300387},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"3752958cd1871a4bd40fac6fcd06bc24bd69deb8e3cfb6bdb9cc01cfc3f00f33","size":786413}],"head":"f1aa8b934cc26c16a966a110c7b408abdaeadce7","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"3497dab92bda92ad7b56a6eac76fa8995859106a7c1c4a67ad739bf2f80f7665","upstream":"origin/trunk_dev"}
```

```text
ES_PRIVATE_REPLAY_PROGRESS_CONTRACT_RECONCILED_READY_FOR_REVIEW
PRODUCT_SOURCE_BYTES_UNCHANGED
POOLED_LOADCLAIM_DEFECT_NOT_REPAIRED_IN_THIS_TURN
LOADCLAIMFRESH_BEHAVIOR_PRESERVED
SCHEMA4_AND_CODEC4_NOT_IMPLEMENTED
INDEPENDENT_ACCEPTANCE_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PRS_NOT_MODIFIED
EXISTING_SOURCE_CHECKOUTS_NOT_SYNCHRONIZED
RUNTIME_WIRING_NOT_PERFORMED
PUBLIC_RELIABLE_SUBMIT_NOT_ENABLED
```
<END_COMPLETE_CODEX_RECONCILIATION_REPORT>

# Appendix B — Exact opening canonical manifest

Bytes: 1331
SHA-256: `ad2e60dfb5f4377cbd4531ab9555c90ec0391b76b7c879764b18ddf5693f0491`

<BEGIN_OPENING_CANONICAL_MANIFEST>
{"branch":"codex/private-replay-progress-v1","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/es_execution_admission_model.md","sha256":"2cbd5a6976c9f03f39f84f80197feee76c6f2c72e831032d5575efd67d21be03","size":80097},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md","sha256":"1f32968c6bd2521d0d1ed8548b5f5bd81d2d03da86efb63651208bf8c46635db","size":151285},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md","sha256":"458ed55fc63fefa7d583d522c80dd3a9b3feb47d466f778c8faceff5da16b326","size":101030},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"d223285d17c1b6c7eb107facd71018ca753bbedd2fc1a81062849c1c265935bf","size":300387},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"3752958cd1871a4bd40fac6fcd06bc24bd69deb8e3cfb6bdb9cc01cfc3f00f33","size":786413}],"head":"f1aa8b934cc26c16a966a110c7b408abdaeadce7","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"3497dab92bda92ad7b56a6eac76fa8995859106a7c1c4a67ad739bf2f80f7665","upstream":"origin/trunk_dev"}

<END_OPENING_CANONICAL_MANIFEST>

# Appendix C — Exact v2 provenance recipe

Bytes: 7275
SHA-256: `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`

<BEGIN_EXACT_V2_RECIPE>
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
import sys
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v2"


def fail(message: str) -> "NoReturn":
    raise SystemExit(message)


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env.update(
        {
            "LC_ALL": "C",
            "LANG": "C",
            "GIT_OPTIONAL_LOCKS": "0",
            "GIT_NO_LAZY_FETCH": "1",
            "GIT_TERMINAL_PROMPT": "0",
            "GIT_PAGER": "cat",
        }
    )
    result = subprocess.run(
        [
            "git",
            "--no-pager",
            "-c",
            "core.fsmonitor=false",
            "-c",
            "core.untrackedCache=false",
            *args,
        ],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


def validate_output_path(output_path: Path, repository_root: Path) -> None:
    if not output_path.is_absolute():
        fail("output path must be absolute")

    parent = output_path.parent
    parent_metadata = parent.lstat()
    if not stat.S_ISDIR(parent_metadata.st_mode) or stat.S_ISLNK(parent_metadata.st_mode):
        fail("output parent must be a nonsymlink directory")
    if parent_metadata.st_uid != os.getuid():
        fail("output parent must be owned by the current user")
    if stat.S_IMODE(parent_metadata.st_mode) & 0o022:
        fail("output parent must not be group- or world-writable")

    try:
        output_path.lstat()
    except FileNotFoundError:
        pass
    else:
        fail("output path already exists")

    repository_text = os.path.realpath(os.fspath(repository_root))
    output_text = os.path.realpath(os.fspath(output_path))
    try:
        common = os.path.commonpath([repository_text, output_text])
    except ValueError:
        common = ""
    if common == repository_text:
        fail("output path must be outside the repository")


def write_exclusive(output_path: Path, payload: bytes) -> None:
    flags = (
        os.O_WRONLY
        | os.O_CREAT
        | os.O_EXCL
        | getattr(os, "O_NOFOLLOW", 0)
        | getattr(os, "O_CLOEXEC", 0)
    )
    fd = os.open(os.fspath(output_path), flags, 0o600)
    try:
        view = memoryview(payload)
        while view:
            written = os.write(fd, view)
            if written <= 0:
                fail("short provenance-output write")
            view = view[written:]
        os.fsync(fd)
    finally:
        os.close(fd)

    metadata = output_path.lstat()
    if not stat.S_ISREG(metadata.st_mode) or stat.S_ISLNK(metadata.st_mode):
        fail("provenance output is not a regular nonsymlink file")
    if metadata.st_uid != os.getuid():
        fail("provenance output owner mismatch")
    if stat.S_IMODE(metadata.st_mode) != 0o600:
        fail("provenance output mode mismatch")
    if metadata.st_nlink != 1:
        fail("provenance output link-count mismatch")
    if metadata.st_size != len(payload):
        fail("provenance output size mismatch")

    read_flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_CLOEXEC", 0)
    read_fd = os.open(os.fspath(output_path), read_flags)
    try:
        observed = bytearray()
        while len(observed) <= len(payload):
            chunk = os.read(read_fd, min(1 << 20, len(payload) + 1 - len(observed)))
            if not chunk:
                break
            observed.extend(chunk)
    finally:
        os.close(read_fd)
    if bytes(observed) != payload:
        fail("provenance output byte mismatch")


if len(sys.argv) != 2:
    fail("usage: governed_execution_audit_patch_manifest_v2.py ABSOLUTE_OUTPUT_PATH")

repository_root = Path(git_text("rev-parse", "--show-toplevel"))
output_path = Path(sys.argv[1])
validate_output_path(output_path, repository_root)

head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    fail("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            fail(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()

write_exclusive(output_path, canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")

<END_EXACT_V2_RECIPE>
