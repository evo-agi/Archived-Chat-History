Here is Codex's response:

# ACCEPT

The exact 30-path candidate at manifest SHA-256 `f92b57f48a701a606e8a0697b75dac8f691e3eb44c13b9c92afb894ec6e1d718` is eligible for a separately instructed local commit gate. **M-1 and DOC-SYNC are resolved.** All eleven prescribed commands passed. The ordinary full suite recorded **5,192 passes, zero failures and 39 expected skips** across 21 tested packages. The separate N-1 witness passed all five identities. This acceptance is limited to the audited bytes and the private synthetic fixture slice.

## Target and provenance

The physical and Git top-level was `/Users/ds/Repositories/ES-Private-Replay-Progress-v1`. Its own `.git` was both the Git directory and common directory. Branch `codex/private-replay-progress-v1` tracked `origin/trunk_dev`, with origin `git@github.com:evo-agi/Execution-Substrate.git`. Both scoped refs pointed to `f1aa8b934cc26c16a966a110c7b408abdaeadce7` at opening and closing. The sole parent was `fb9ae55797d9fcc02863c23fe8d3e43d16eac542`, the tree was `8dd27f9acba98ed70d93736bdef8300ef1aba53f`, and the subject was `Harden original-key read transaction cleanup (A1) (#10)`. There was no scoped upstream-ref movement.

The complete 427-entry index equaled HEAD. I read all 427 committed blobs and all 430 physical leaves, including byte comparisons against the 400 HEAD-identical files. The 30 candidate rows were regular `0644`. The baseline included 60 existing `0755` executables, all matching HEAD. The working tree held 27 unstaged modifications and exactly three ordinary-untracked additions in `es/admission/internal/reliablesubmit/`:

- `replay_progress_test.go`
- `sqlite_pooled_claim_read_cleanup_test.go`
- `sqlite_replay_progress_schema.go`

The staged, unmerged and ignored inventories were empty. The complete path check found zero deleted, renamed, type-changed or extra leaves. The raw index SHA-256 was `1c6218366e333383b205833fce0ceaa5d462fa7264cf51cbdcd35aa05855b018` and local config SHA-256 was `4c98ee1729d2d3321c357ec922f6dafc19b6ac167a8a24ed636d359ab6642485`. [Opening guard](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Independent-Audit-20261119-tDnKaFZH/opening-guard.json)

I authenticated the complete attachment and each framed appendix A–G before executing the recipe. The unchanged 7,275-byte v2 recipe ran twice at opening and twice at closing, each time from the actual checkout into a separate absent file. All four outputs matched the 6,813 bytes of Appendix B.

| Evidence | Verified SHA-256 |
|---|---|
| Complete attachment | `74878f466a9189512ce37fde82eeeaf751f035c3b997ffd014f9f048db5ca547` |
| Final canonical manifest | `f92b57f48a701a606e8a0697b75dac8f691e3eb44c13b9c92afb894ec6e1d718` |
| Final tracked full-index HEAD diff | `793e6697cf2342ce41f08ed8f59a0a14eb5c288c74780f158731d55dbe17bcca` |
| v2 recipe | `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` |
| Current ZIP, 955,015 bytes | `3b27c483036296304a9fbca77dcd5fe522dee64b8eabf392057b6c573160f59a` |
| Reference ZIP, 900,863 bytes | `e3cac3bc27bbfd8c1c18d1abf3aabc00077e632e14bd6e6b92e26e020c9c1be6` |
| Reference canonical manifest | `0812091529c67f4bc46d0bc343b3dea8595e63a461264e143d51606e581e0c06` |
| Reference tracked full-index HEAD diff | `68339ba85b7b22d86bdaa21ed4fdccebc5021f82912344e0507862d1624cb791` |
| Full opening delta | `211a5522dfc8b5401f7361c5148ce53dc7eaef06e56787231e2624783d064cc2` |
| Tracked-opening delta plus additions | `951c9353a69a37340f122bfd92b4c17ec3e2f514c70cd1e614d7665c3cf0175c` |
| Current source map | `d8bae35ede66a6b66b093e457a879ba4b633c7b8dc14ad7c8742801f2a3fc976` |
| Current delivery inventory | `a24629ff1c02e4498dcb5a7f66779faf4057d29b00bce9b756572d77236cd6ee` |

Both ZIPs contained safe, unique regular members. I verified all payloads and the complete self-excluding inventories, 47 members and 46 inventory rows in the current ZIP, and 44 and 43 in the reference ZIP. The source maps agreed with the archived manifests, pinned HEAD data and live file bytes where applicable. All three patch relations independently reconstructed the full 430-leaf target in disposable copies: tracked HEAD with the three explicit additions, full opening delta, and tracked-only opening delta with additions. Each applied patch exited zero. The live `replay_custody_structure.go` and both ZIPs carried the correct digest `4916268757b93d409cbc13ba9c0da14e009499b4db7cadd52bc7ccd47c6a86ad`. The earlier transcription incident remains closed. [Archive comparison](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Independent-Audit-20261119-tDnKaFZH/archives.json)

Exactly six rows changed from the rejected reference: `PLANS.md`, the persistence ADR, the admission model, `docs_contract_test.go`, `sqlite_store.go`, and `sqlite_replay_migration_test.go`. The other 24 rows in the canonical manifest below matched both archives byte for byte and mode for mode. Inside `sqlite_store.go`, executable differences are confined to `openSQLiteClaimStore`, `migrateSQLite` and the private signal declaration. `verifyMigrationRecovery` changed only in commentary. The shared cleanup and transaction helpers, `loadClaim`, claim/grant/CAS paths and existing seams equal the reference. `loadClaimFresh`, including its separator, matched HEAD and both delivery archives at 1,077 bytes, SHA-256 `3a47f8b5e0c5bf7bec899987aa78fdf4ef48a585086d9eb975e576896ab4b61c`. [Store preservation](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Independent-Audit-20261119-tDnKaFZH/store-preservation.json)

## M-1 and DOC-SYNC

**M-1 residual — resolved.** The previous unwanted generic refusal was a defect in the selected SQLite opening rule. The repaired source and fresh execution support the following conclusions.

| Question | Disposition |
|---|---|
| A. Baseline and eligibility | `guardedBeginImmediate` protects uncertain BEGIN dispatch. The migration establishes eligibility only after successful lock-held authentication of an old or pristine opening and a live caller context. Invalid openings and the default version have no route to recovered-old/current authority. An authenticated current head found under the lock ends the lock-only transaction. |
| B. Rollback ordering | Pre-COMMIT rollback uses a request-independent five-second context. It samples `cleanup.Err()` before self-cancel. A timely ordinary rollback preserves the ordinary refusal. |
| C. Ownership transfer | `sql.ErrConnDone` authorizes the handoff to the unpublished opener. The observation supplies the classification. With a live wrapper, unconfirmed exact discard withholds readback. Shared `ErrConnDone` and `Raw(ErrBadConn)` semantics are unchanged. |
| D. Checked pool disposal | The `openGate` connection defer completes before the opener handles the signal. The opener checks the original pool’s `Close` result before creating the observation pool. Accepted recovery uses the fresh pool. |
| E. Classification and precedence | One checked, nonmigrating classifier uses the caller context. It accepts only a qualified current head and returns recovered-old with zero handle for the exact authenticated baseline, including pristine version 0. Mixed, failed and invalid observations refuse. The opener checks `ctx.Err()` after classification and calls fresh-pool `Close` on refusal. |
| F. Meaning of current | A qualified current result records the observed head. `migrationRecoveredNew` is only read by tests. Zero COMMIT attempts confer zero own-COMMIT attribution. The separate actual-COMMIT dispatch and lost-response path still enter checked observation. |
| G. Mutation scope | The recovery route calls only the classifier. It adds no migration replay, second mutation, adoption, repair, attempt reset, collaborator or process-wide state. |

The decisive source is `sqlite_store.go` at lines 58–130, 557–602, 625–751 and 953–1012. The owner rule is persistence ADR §15B.5. The pinned Go `database/sql` source distinguishes wrapper return, exclusion and driver close. The pinned modernc SQLite v1.54.0 source reaches `sqlite3_close_v2` and ordinary finalization rolls back the transaction. `database/sql` can discard the driver close result on its bad-connection return path, and the fresh observation pool’s close result is ignored on refusal. The evidence qualifies connection ownership and logical preservation. Physical/device-close failures, hard close latency and capacity under actual double withholding remain unqualified. [Opener](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_store.go:58) · [Migration and classifier](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_store.go:625) · [Owner rule](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1706)

Both differential runs used the maintained regression bytes. The red bound the rejected store. The green bound the repaired compiled package, with the root documentation test still at its earlier revision. All 12 leaves reached verified schema 4 inside the actual transaction through `beforeMigrationCommit`, counted one migration and **zero** `migrationCommit` calls, and compared independent old-state witnesses before normal reopening or teardown. The closed-wrapper leaves closed the real wrapper and verified `Raw` returned `ErrConnDone`. The unfiltered witness checked all of `sqlite_schema`, both pragmas and `rowid,*` for every fixture table. Populated schema 3 included claim, key, grant and ledger rows and a byte-compared sealed original. The four red closed-wrapper leaves failed at classification, producing 8 passes and 5 failures including the parent. The eight ordinary-rollback and canceled-readback controls preserved generic refusal and logical state in both runs. Retained green and fresh gate 6 each passed all 13 identities. The preceding independent diagnostic remains a historical failure with 2 passes and 3 failures. Its source and raw log authenticated to `e0b662c8c5d084b209362be82ad54198a7cee85fa1966e9228953bbedad3ba21` and `28b632fc2d5c1a9cac35586eb0ca7454ff7d9530c22a8c04c12c0a5a728b2375`. [Unfiltered witness](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go:579) · [Maintained regression](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go:715) · [Fresh gate 6 log](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Independent-Audit-20261119-tDnKaFZH/gate-06/stdout)

**DOC-SYNC — resolved.** Admission §7.4 now matches the frozen typed declaration inventory exactly across the selected non-test production source. The 32 fields comprise five direct locks, three `atomic.Bool` latches and 24 transitive carriers. I checked the protected facts, lifetimes, readers and writers, including both permit wrappers, the shared `publishReplayOriginal` reader, and `matchesAllocation`, `consume` and `burn`. The production-source inventory includes the runtime-unwired fixture definitions. The A3 exclusions in §7.5 are byte-identical to the reference. The checked-in root test extracts the finite literal, compares exact field/category sets and permit roles, and supplements the unchanged typed scanner. The final stale-owner red reached the missing-field assertion with the final checker bytes. The repaired test exercised `MissingAtomic`, `OmittedScope2Wrapper`, `OmittedSharedPermitReader` and `ReferenceClaimedAsPrimitive` at their intended assertions. Gate 7 passed both typed Workstream C parents. The ordinary full suite passed the older resolved-plan parent with all three same-lock assertions in their corrected notation. [Admission §7.4](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/es_execution_admission_model.md:910) · [Typed field inventory](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/workstream_c_guardrails_test.go:2280) · [Permit inventory](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/workstream_c_guardrails_test.go:2463) · [Root checker](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/docs_contract_test.go:12556)

## Preservation and reviewer coverage

The candidate remains a **Bounded slice rule** refinement on the reliable-submit **Reopened redesign seam**, limited to `synthetic_progress_nonoperational_v1`. The durable ES service owns semantic successors, SQLite owns committed claim/progress/key/grant state, and custody owns authentication and private objects. Coordinator programme progression remains separate. The design retains global caller/key occupation, one original and physical row, one attempt and one assigned run, and distinct legacy, immutable-original and progress codecs. The schema-4 insert checks the exact active key pair in the write transaction. CAS checks the same immutable original and eligible retained key pair. The original stays sealed as revisions advance. Public structural reliable-request refusal and unkeyed Submit remain current invariants. The source trace covered the private composer, unchanged public entry points, typed caller inventory, and startup, configuration, scripts and examples. [Selected plan](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/PLANS.md:5) · [Fixture contract §6B](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md:787) · [Insert checks](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_replay_progress_schema.go:237) · [CAS key checks](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_store.go:1912) · [Public route](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/api/server.go:249)

| Prior finding | Independent disposition for these bytes |
|---|---|
| Original M-1 lock order | **Preserved.** The maintained competing-writer witness and invalid baseline cases passed. Lock-held application ID, version, shape and ledger or pristine verification govern writes and the recovery baseline. |
| M-2 | **Preserved.** The literal seven-character `sqlite_` check with ASCII `NOCASE` preserves genuine shape digests and rejects lookalike namespace cases. Fresh tests used the independent unfiltered witness. |
| SR-1 | **Preserved.** The one-use borrow is checked after acquiring the issuer lock and again before projection. Exact retained key-pair qualification and callback lifetime remain enforced. Ineligible projection leaves a known commit or write uncertainty intact. |
| SR-2 | **Preserved.** Fresh reconciliation checks current eligibility before a same-fact no-op. Historical tuple validation, exact latest replay, changed-input conflict and stale precedence keep their selected order. |
| K1-1 | **Preserved.** Failed disclosure of a definite winner keeps `Occupied` and zero projection. Proven changed intent gives `Conflict`. The losing branch issues zero second resolutions, Seals or establishment attempts. |
| T-1 | **Preserved.** Synthetic evidence binds polarity, claim, run, marker and fact, and accepted evidence binds the exact receipt before replay or no-op classification. The constructors have zero production callers. |
| R2-1 | **Preserved.** Scope 1 qualifies the publisher before arranging permit burn. Scope 2 retains wrapper burn. Both use the common checked allocator, with rollback and identity recheck before descriptor transfer. The process helper reached readiness, recorded the allocation winner and was reaped. |
| N-1 | **Preserved by fresh admission-level execution.** The exact external inputs reproduced all four expected outcomes with zero measured effects, as recorded below. |

Migration literals 1–3 matched HEAD, and migration 4 matched both archives. The authenticated literal and shape digests are below. The format, operation identity, carried claim/key/grant rows, previous ledger rows and original-object association were checked against the source and fresh controls. The pooled-reader gate independently passed all 16 identities, including later same-store use after confirmed cleanup. [Schema qualification](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_replay_shape.go:23) · [Custody](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/replay_custody_file.go:1257) · [Durable replay ordering](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/durable_service.go:1259) · [Occupied path](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/reliable_submit_replay_private.go:297)

| Schema | Migration SQL SHA-256 | Authentic shape SHA-256 |
|---|---|---|
| 1 | `9613ba74cd6573626277b1f04a20b9c3ec5f9edf8b6b7408e94cbb45edc32dcd` | `031abaada34a63834d3466081ed04afef6b7c9f55103cd2b57fe3033b8c45ef0` |
| 2 | `9280a62450488dfa54907d268d693f3f7d4f0b78b9a3553a1b659206d2c970e9` | `944094f4e5fae102ea2882a076f580c69494678f41acedf9eaa971fe836eb280` |
| 3 | `4dafddbf477fd7f64ad88cf2b1e2b2becb378827e81cd6cc694456798c9a00be` | `15ab48bde4d53bb252dc954a2aa3b1db12de7295111f23bb0264f74f153dba92` |
| 4 | `879b24ac563d37ccdd1bdb5ec13c923b93213f2caea69a1110281796e20e667e` | `2ae4721c8526ed9b8de35fd3acdfa31448eae9b547ba8662a22ed130035f7c15` |

All four read-only reviewers completed and concurred within their scopes, with no material dissent or additional finding. The SQLite reviewer covered the complete opening and cleanup lifecycle, pinned driver behavior, migration literals and regression. The owner reviewer covered the declarations, typed inventories, permit roles, documentation checker and exact notation repair. The integrated reviewer covered custody, durable operation and admission interactions, effect exclusions and the earlier findings. The evidence reviewer independently reconciled the archives, probes, command records, causal inputs and N-1 graph. They used static analysis and authenticated retained evidence. The foreground alone ran fresh builds and tests. Device faults, hard timing guarantees, actual double-withholding capacity, native installed-source qualification, provider acceptance and cross-restart operational eligibility remain outside their evidence and this acceptance.

## Retained history and fresh setup

I authenticated the author report at `6c249d2f2c2b219b6b07ba57d3236ab37d8ffbc1eb2872986489547c2e629f49`, the author index at `82860422eaa259508b55b4f5911925ca5d7cc6b3d8aff66fa178e7e9aef7d939` and the prior independent index at `0fd8c79d0b2ac8e20f23aadd92045b03df30528e07331225aa58f124fb0a43bf`. I reconciled the author’s eleven final argv, cwd, exits, raw logs, identities and immediate guards to the final freeze. The prior REJECT continues to apply to the reference manifest. Appendix E supplied static review evidence. The fresh source and execution adjudicated the two findings.

| Retained run | Observed result |
|---|---|
| Migration red / green | Exit 1 / 0. Red 8 pass, 5 fail and green 13 pass. Both reached the intended boundary. |
| Owner red 1 | Exit 1 at compile setup because of a duplicate local. Zero behavioral red evidence. |
| Owner reds 2, 3 and 4 | Exit 1 for each. The stale owner reached the exact-field failure. Red 4 used the final checker. |
| Owner green 1 | Exit 1 with 3 passes and 2 failures. The carrier mutant encountered row width before the category assertion. |
| Owner greens 2 and 3 | Exit 0. Green 2 passed 5 identities. Green 3 passed 6 including the existing resolved-plan parent. |
| Author generation 1 | Gates 1–9 passed. Gate 10 exited 1 with 5,191 passes, 1 failure and 39 skips. Gate 11 was unrun. The single failure was `TestResolvedPlanDocumentationTruthAndFiniteInventoriesContract` at the three old lock spellings. |
| Author generation 2 | All 11 passed against the final manifest. The generation-1-to-2 source change was exactly three notation substitutions at `docs_contract_test.go:414–416` for the same lock identities. |

The migration red stdout was `5cc6d8d70ba633646b24da7746806479a1e5a7aceb5935361526377216450538`, the green stdout was `344c75d7590a8d925e38ae61043333eb513e936bca9ff37979f607ec47aeadcb`, the final owner red stdout was `01c6e6310784ffc02811928f649d086a14fe2b3fadb52df33fd1be5bdc306132`, and the generation-1 full-suite stdout was `dc6a47a828d5c2b365335fe992d2fa9c323b8da38e96d1aab6f95456d69d6254`. Earlier failed retained generations remain recorded as failures. [Retained reconciliation](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Independent-Audit-20261119-tDnKaFZH/retained-reconciliation.json)

Fresh audit tooling needed corrections in the private root. The initial checker applied `0644` to the unchanged executable baseline. The patch scratch then inherited `0600` under the audit umask. I corrected the checker to use the actual HEAD modes for the baseline and reproduced source modes in the disposable patch copies. An attempted helper edit had a quoting error. Probe setup initially expected the schema-3 binary in the historical material list, then resolved it through both authenticated indexes. I also corrected a static-check import and accounted for the supplemental toolchain and module files in the build-input checker. These were audit tooling errors. Each primary command ran exactly once against the frozen bytes.

The historical binaries ran from separate authenticated audit-owned copies. PB1/schema 2 was 14,350,930 bytes, SHA-256 `b205a31bac091cbcf5b3f4826bc359455625316908051131733622813e34adcf`, bound to its build, exact harness and inventory of 404 historical source leaves. The previous schema-3 opener was 15,601,186 bytes, SHA-256 `42614a50812a65ba52b53488d872884e59ce7b4f57dece6a66642d4eb8de1409`, bound to its 427 HEAD-identical exports, single overlay and 1,354-input inventory `50a81fa5a042e135abfc9f6bad68d20abc4575f881945ecc84252c14910dde8f`. The maintained parents ran the existing binaries with their distinct `ES_REPLAY_PB1_TARGET` and `ES_REPLAY_SCHEMA3_TARGET` bindings. Gate 6 passed both refusal parents, preserving the separate schema-2→3 and schema-3→4 claims and their logical-state witnesses. [Probe material](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Independent-Audit-20261119-tDnKaFZH/probe-material.json) · [Probe callers](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/sqlite_replay_shape_test.go:17)

## Fresh command record

Go 1.26.5 `darwin/arm64` and sibling `gofmt` came from the pinned toolchain below. Python 3.13.4 with `tomllib` ran from `/Library/Frameworks/Python.framework/Versions/3.13/bin/python3` with `-B`. OpenSSL 3.6.2 resolved to `/opt/homebrew/Cellar/openssl@3/3.6.2/bin/openssl`, and Git 2.49.0 to `/opt/homebrew/Cellar/git/2.49.0/bin/git`. Executable SHA-256 values were `3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19` for Go, `3b87c876b1255feb8ecc539afff2eadd9dcc76e0e34657bdab6d32fd03329f81` for `gofmt`, `f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b` for Python, `bf63843e6856e1994ca71092ff3b46834236eb2144dd9b6ceb85d511128b836e` for OpenSSL and `03d4a6c5328d4a1ce84eba2765664284b1fb2414d9e657358733056a89a95954` for Git. [Preflight](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Independent-Audit-20261119-tDnKaFZH/preflight.json)

The environment used `GOTOOLCHAIN=local`, `GOPROXY=off`, `GOSUMDB=off`, `GOWORK=off`, `GOFLAGS=-mod=readonly`, `CGO_ENABLED=0`, `GOTELEMETRY=off`, `GOMODCACHE=/Users/ds/go/pkg/mod`, `GIT_OPTIONAL_LOCKS=0`, `GIT_NO_LAZY_FETCH=1`, `GIT_TERMINAL_PROMPT=0` and `PYTHONDONTWRITEBYTECODE=1`. I set `GOENV=off` to exclude user Go defaults. The outer umask was `077` and test subprocess umask `027`. `GOCACHE`, `GOTMPDIR` and `TMPDIR` were audit-owned `cache`, `gotmp` and `tmp`. `ES_REPLAY_PB1_PROBE` and `ES_REPLAY_SCHEMA3_PROBE` identified the audit-owned `historical-pb1.test` and `previous-schema3.test` copies. The recorded environment SHA-256 is `3e6c6a80bfdfa428c8afd2a8f79367dd2303df936bb77069248baec612237254`. Read-only capability checks before App-containing commands observed Docker daemon unavailability in `desktop-linux` and no direct socket at the required path. The maintained tests produced their natural skip results. [Environment](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Independent-Audit-20261119-tDnKaFZH/environment.json)

Commands 1–10 ran from `/Users/ds/Repositories/ES-Private-Replay-Progress-v1`. Command 11 and the separate build-input inspection ran from `N1_SOURCE`. These are the exact argv in shell notation, in execution order.

```sh
AUDIT_ROOT=/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Independent-Audit-20261119-tDnKaFZH
N1_SOURCE="$AUDIT_ROOT/n1-source"
GO=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go
GOFMT=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/gofmt
I=es/admission/internal/reliablesubmit
A=es/admission

"$GO" version
"$GOFMT" -d docs_contract_test.go "$I/sqlite_store.go" "$I/sqlite_replay_claim.go" \
  "$I/sqlite_migrations.go" "$I/sqlite_replay_progress_schema.go" "$I/sqlite_replay_shape.go" \
  "$I/durable_record.go" "$I/durable_operation.go" "$I/durable_service.go" \
  "$I/replay_custody_format.go" "$I/replay_custody_structure.go" "$I/replay_custody_file.go" \
  "$A/reliable_submit_replay_format.go" "$A/reliable_submit_replay_hydration.go" \
  "$A/reliable_submit_replay_private.go" "$I/sqlite_pooled_claim_read_cleanup_test.go" \
  "$I/replay_progress_test.go" "$I/replay_custody_file_test.go" "$I/sqlite_store_test.go" \
  "$I/sqlite_physical_test.go" "$I/sqlite_replay_migration_test.go" \
  "$I/sqlite_replay_shape_test.go" "$I/guardrails_test.go" "$A/reliable_submit_guardrails_test.go" \
  "$A/reliable_submit_replay_private_test.go" "$A/workstream_c_guardrails_test.go"
git --no-pager diff --check
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateReplayProgressSynchronizationInventoryDocsContract|TestPrivateOriginalReplayProgressContractSelection|TestReliableSubmitPersistenceAndConcurrencyADRDocsContract|TestSubmitIdempotencyCorrelationAndRecoveryDocsContract|TestReliableSubmitPureModelDocsAndSourceContract|TestReliableSubmitPublicOptInAndVersioningDocsContract|TestReliableSubmitContractAdapterFoundationDocsAndSourceContract|TestReliableSubmitBindingProducerDocsContract|TestIntegratedAcceptanceGateDocumentationIsConsistent|TestIntegratedCandidateStatusSeparatesCAndT)$' .
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestSQLitePooledClaimReadCleanup$' ./es/admission/internal/reliablesubmit
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestSQLiteMigrationPrecommitClosedWrapperRecovery|TestPrivateReplayProgressConfirmationEligibility|TestPrivateReplayProgressReconciliationEligibility|TestPrivateReplayProgressTerminalEvidenceBinding|TestSQLiteMigrationOpeningRevalidatedUnderLock|TestSQLiteLiteralInternalNamespaceQualification|TestPrivateReplayScope1PublicationPreflight|TestPrivateReplaySharedObjectAllocation|TestReplayPublicationFaultAndIdentity|TestPrivateReplayProgressFormatVectors|TestPrivateReplayProgressTransitions|TestPrivateReplayProgressConcurrencyAndCommitOutcome|TestSQLiteV4MigrationPreservesFullState|TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation|TestSQLiteV3OldBinaryRefusesWithoutMutation|TestSQLiteLegacyCASConnectionCleanup|TestReplayOriginalKeyReadCleanup|TestReplayOriginalKeyReadCallerRefusal|TestReplayGrantC1PreCommitConnectionQuarantine|TestReplayGrantD1BeginResponseLossQuarantine|TestReplayKeyStateD1BeginResponseLossQuarantine|TestReliableSubmitPrivatePersistenceStaticGuardrails)$' ./es/admission/internal/reliablesubmit
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestExecutionSubstrateProductionHasNoA3LeaseRegistryOrPoisonDesign|TestExecutionSubstrateSynchronizedMutableStateReferenceInventoryIsExact|TestPrivateReplayProgressOccupiedDisposition|TestPrivateReplayProgressAdmissionReplay|TestPrivateReplayProgressHasNoEffectPaths|TestReliableSubmitFoundationHasNoRuntimeWiring|TestReliableSubmitBindingProducerHasNoProductionCaller|TestPrepareRequestShapeRemainsLegacyAndUnkeyed|TestResolvedSubmitLegacyEquivalenceOneNomadRegistrationAndAuthorityRecovery)$' ./es/admission
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestWorkstreamCContractPrepareAndSubmitRemainSeparatedAtAPIBoundary|TestSubmitPublicRouteRejectsStructuralReliableBody)$' ./es/api ./es/app
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=600s ./es/admission/internal/reliablesubmit ./es/admission ./es/api ./es/app
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=600s ./...
(cd "$N1_SOURCE" && "$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestPrivateReplayProgressAdmissionUnknownNoEffects$' ./es/admission)

# Separate guarded build-input inspection
(cd "$N1_SOURCE" && "$GO" list -mod=readonly -deps -test -json ./es/admission)
```

Each command had a separately executed before/after observation of all 430 files and modes, complete path classification, both untracked lists, HEAD, branch, upstream, index and scoped config. All immediate post-command observations matched opening guard `a670d3738e2ea00f911233948d0c08daed3b76073bbc80a95b2df01e5f205ede`. Gate 11 and `go list` also had their own view guards. Times are Eastern on November 19. All stderr files were empty, SHA-256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

| Gate | Exit | Pass/fail/skip | Tested / no tests | Immediate post-check | Stdout SHA-256 |
|---|---:|---:|---:|---|---|
| 1 Go version | 0 | — | — | 12:53:56.436 | `278375c8a03c34bb0f855154850de7c4f217fd3b8cdf37986819e3f05d0a4c33` |
| 2 Formatting | 0 | — | — | 12:53:56.804 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| 3 Diff check | 0 | — | — | 12:53:57.193 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| 4 Owner contracts | 0 | 27/0/0 | 1/0 | 12:54:08.056 | `9dbbcf690bd121ec5ef68c91fa721799e240ebf8723f40a4c4fa8e3624bde716` |
| 5 Pooled reader | 0 | 16/0/0 | 1/0 | 12:54:19.962 | `35caaad76f254e36dc8aefd6f617de69cf4a8aacab6d20efb157b2a91a1dcaa7` |
| 6 Internal and historical probes | 0 | 221/0/0 | 1/0 | 12:54:34.206 | `91666c8c681c184b6885af547130638f2dbf9b36b9350e4027f30ddaf4e11b28` |
| 7 Admission and typed inventories | 0 | 26/0/0 | 1/0 | 12:54:57.667 | `c5c22f9055a5a7e04a345ebfca742158436345d540a7e5de70efac3bf7db9a2e` |
| 8 API/App boundary | 0 | 2/0/0 | 2/0 | 12:55:02.514 | `f0f55eb404a2f7081c6feb258a1c3c3d557627d2e8426e13fc56e464960cca2c` |
| 9 Four-package suite | 0 | 2,062/0/39 | 4/0 | 12:57:12.956 | `b538bb3c99acf6a0a18785f645ddff58116ac0299a3c2bd3412d1be2dce62d8e` |
| 10 Full repository | 0 | 5,192/0/39 | 21/20 | 13:03:06.446 | `5e9c8153bd96d3eaf4a35caf89fd29b601620686d86a0306eb4deb38ef1277eb` |
| 11 External N-1 | 0 | 5/0/0 | 1/0 | 13:03:09.266 | `1cef79c15b80c7cf5c56ac1e11598cd30bc4af83291625ec83927ebf9ba65b2a` |
| Separate `go list` | 0 | — | — | 13:03:09.791 | `bab40128c30b8577c6963cf7f7ad8fb6edfe376869516747640f9d9c67f22bae` |

The foreground reconciled all selected parent names and identity multisets against the fresh raw streams and the retained final generation. Gate 9 was the exact four-package projection of gate 10. The ordinary full suite added 18 identities over the prior independent 5,174, with zero removals or renames. These were the new migration parent and its 12 leaves, and the new owner-inventory parent and its four mutants. All five N-1 identities were disjoint. Every primary command ran. Historical red reruns, additional diagnostics and operational qualification were outside fresh execution. [Fresh reconciliation](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Independent-Audit-20261119-tDnKaFZH/fresh-reconciliation.json)

### All 39 expected skips

The raw reason lines matched both retained suites. `TestPrivateReplayObjectAllocatorHelperProcess` and `TestSQLiteClaimStoreLockHelperProcess` were the two direct helper sentinels. The allocator parent logged `SHARED_ALLOCATOR_READY` and `SHARED_ALLOCATOR_WON`, with `cmd.Wait` checked before the success log. `TestBringupScriptUpCheckDownFullProfile` skipped on Docker reachability, and `TestSubmitFlowMountsGovernedArtifactAndLifecycleWithInstalledSourceIdentity` skipped because the required direct Unix socket was unavailable. The other 35 App identities skipped with Docker daemon probe exit 1 and connection unavailable.

```text
TestControlPlaneStaticScriptAPIPathCancelSucceeds
TestControlPlaneStaticScriptAPIPathFetchesRetainedResultBundle
TestDiagnosticsScriptRunIDBundleCollectsLifecycleSignalsAndStaging
TestExecuteLoopScriptFailureSummary
TestExecuteLoopScriptSuccessAndDeterministicDigests
TestExecutionCancelRetainsStageRootForDebugging
TestExecutionCancelStopsNomadJob
TestExecutionLogsReturnConflictWhenAllocationNotReady
TestExecutionLogsReturnRealContainerOutput
TestExecutionLoopScriptSuccessRetainsDistinctStageRootsAcrossRepeatedRuns
TestExecutionResultBundleAndStageRetainedAcrossStatusAndRepeatFetch
TestExecutionResultReturns404ForTerminalExecutionWithoutResultOutput
TestExecutionStatusReflectsFailedAllocation
TestExecutionStatusReflectsNomadJobState
TestExecutionStatusRetainsFailedStageRootForDebugging
TestExecutionStatusRetainsSuccessfulStageRootAndLogsStillWork
TestExecutionStatusReturns503WhenNomadUnavailable
TestLifecycleScriptCategorizesExecutionFailure
TestLifecycleScriptObservesExecutionViaPublicRunID
TestRuntimeIdentityIntegrationCapabilityProbe
TestSubmitFlowAllowsConfiguredControlPlaneCallerHandoff
TestSubmitFlowDoesNotStartWorkloadBeforeHelperReadiness
TestSubmitFlowHelperDeathIsTaskFatal
TestSubmitFlowInjectsWorkloadIdentityEndpointAndLifecycleStillWorks
TestSubmitFlowMountsGovernedArtifactAndLifecycleStillWorks
TestSubmitFlowProvidesPlatformOwnedRuntimeIdentityThroughBoundedEndpoint
TestSubmitFlowRejectsRuntimeIdentityPassthroughRequests
TestSubmitFlowRejectsWorkloadArchiveWithSymlinkEntry
TestSubmitFlowRemovesRuntimeMountArchiveResidueAfterExtraction
TestSubmitFlowRunsStaticScriptInNomadDocker
TestSubmitFlowUsesBridgeNetworkWhenNetworkAccessEnabled
TestSubmitFlowUsesConfiguredRuntimeIdentityTmpfsSize
TestSubmitFlowUsesPlatformOwnedIdentityForVaultLoginAndSecretRead
TestSubmitValidOperatorCallerReturnsAcceptedSubmissionReceipt
TestWorkloadCanCreateAndUseLocalRuntimeIdentityEndpointFromTmpfsWorkspace
```

## External N-1 witness

The new view bound all 430 live candidate leaves and exactly two external-only files. Appendix F’s bridge was 789 bytes at `14f0e9e92a37e1d1bf624f1f052a62a6d56e5b82f988698abbf6e1b5bcf9196d`. Appendix G’s witness was 5,897 bytes at `8da31dd61c9af2537c15f4376a330d05cb2e55dd2efd0ea610472a0c6ffa5c6a`. Both matched both archives. The fresh 432-file before/after guard was `05f6d69aa56210c33ccf6c998502345426ff5e0817365ada213a2a61af1afe53`. Both files were absent from the ordinary checkout.

| Case | Invocation disposition | Projected revision | Later current revision |
|---|---|---:|---:|
| Establish / Canceled | `WriteUnknown` | 0 | 1 |
| Establish / AuthenticatedExact | `OwnCommitConfirmed` | 1 | 1 |
| AssignRun / Canceled | `WriteUnknown` | 0 | 2 |
| AssignRun / AuthenticatedExact | `OwnCommitConfirmed` | 2 | 2 |

Each case performed one real COMMIT followed by a modeled lost response. The bridge used the selected store’s existing hook and restored it before the later read. The later read preserved the earlier invocation’s disposition. All cases retained one sealed original, and `AssignRun` preserved its bytes. Provider, staging and EGS contacts were zero, with empty operational staging and results roots. This evidence covers the bounded fixture calls and their measured effects. [N-1 log](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Independent-Audit-20261119-tDnKaFZH/gate-11/stdout)

The separate fresh `go list` reconciled all **291 package records** and **2,801 physical inputs** to the archived build record. The inputs comprised 2,289 Go distribution files, 375 module-cache files, 136 view files and one generated test main. The input reconciliation bound the package file lists and checked the supplemental executable and module metadata files. Only declared view/cache prefixes were translated. The internal production dependency compiled the bridge and the repaired store. `sqlite_replay_migration_test.go` appeared only in the dependency’s test metadata. The admission test package compiled the witness. I preserved the actual 57,754-byte generated test main before cache cleanup and verified its SHA-256 `07a228ee0649b9846a21c3293b2171364db3ced5d64e10020f9cb317122877b4`. [Build reconciliation](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Independent-Audit-20261119-tDnKaFZH/n1-build-reconciliation.json)

## Closing record

I removed only the audit’s patch scratch, compile cache and temporary directories, and returned both copied probes to `0600`. The two closing v2 outputs independently reproduced Appendix B after that cleanup. The closing guard equaled opening across all 430 leaves and the recorded Git state. Private directories are `0700`, retained evidence is `0600`, and the copied N-1 source retains its original modes.

The audit performed local inspection, external patch reconstruction, offline builds, fixture migrations, maintained loopback mocks and helper processes, and read-only capability probes. Repository edits, prior-evidence edits, staging, commits, ref changes, fetches, pushes, PR changes, publication, dependency installation, live-stack or deployment effects, real-key provisioning and operational migration were all zero. The private facade remains runtime-unwired. Native installed-source qualification, provider acceptance, operational no-dispatch proof and cross-restart operational write-uncertainty authority remain outside this verdict.

| Closing artifact | SHA-256 |
|---|---|
| [Closing manifest A](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Independent-Audit-20261119-tDnKaFZH/closing-a.json) and [closing manifest B](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Independent-Audit-20261119-tDnKaFZH/closing-b.json) | `f92b57f48a701a606e8a0697b75dac8f691e3eb44c13b9c92afb894ec6e1d718` |
| [Closing source guard](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Independent-Audit-20261119-tDnKaFZH/closing-guard.json) | `a670d3738e2ea00f911233948d0c08daed3b76073bbc80a95b2df01e5f205ede` |
| [Private artifact index](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Independent-Audit-20261119-tDnKaFZH/artifact-index.json) | `7847cde1799ec2166cf599fb73ad726ab056b82bb128dd6b695f107f1e858205` |
| [Fresh reconciliation](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Independent-Audit-20261119-tDnKaFZH/fresh-reconciliation.json) | `d49c9d3d551e6e1608a07ff7a10295eb9d4d3b9c4396635e5d70da472451f813` |
| [Retained reconciliation](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Independent-Audit-20261119-tDnKaFZH/retained-reconciliation.json) | `effd722966ad2e22d130e6c30329e2029800d1737747758ae94d9bb2fdd22b9e` |
| [N-1 build reconciliation](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Independent-Audit-20261119-tDnKaFZH/n1-build-reconciliation.json) | `4af8b5c1497b41f3eee8ba0e0084b8eb66118cf6424b7682b8d3dbc6c8e7f9f0` |

### Full canonical target

```json
{"branch":"codex/private-replay-progress-v1","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/es_execution_admission_model.md","sha256":"bedc87c611b5c9340ffaafb0866f028dc9daf2f22552efec47491f1b4ae713f2","size":88702},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md","sha256":"34e06ff10148d67a49000868499294873c732279d7f399a5f2cb910b0c12f40e","size":161666},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md","sha256":"1b03cc40b48861c7220a7b85d20b1f8d232690f17460e3eee0df33af4659e3f3","size":103025},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"c4fdbfb4acd3c2a27f679f6575798c4553e94110c4aa7177f590e90fe89c5e31","size":302636},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"dd433f02e783aa265d775bd411c95433e369642e2aafbdb32c72b75f78b4ebff","size":799914},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_operation.go","sha256":"b7761f001a1f67349ed51f2b79012194a7d45bb19c79e0ca2c0c22b8227320f9","size":9548},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_record.go","sha256":"999db7db6550c5031b023a9613825504e30e971a179298cc43e09cf8c5c5d7cd","size":25226},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_service.go","sha256":"ef0bc6f4d125f3986c46901cbe05bc2cb447af7dfbf51cee4653d7ce696c0945","size":49972},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/guardrails_test.go","sha256":"9a300f0553fd6ac3003a048a7309060a4ec6f618eacd94139bd4bb29c011bc60","size":32231},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_file.go","sha256":"61c4006e1e4a3feb7c0ec0e7d4685dc2c3fe8c1e2165d1529d2c86ae8fa137b5","size":50461},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_file_test.go","sha256":"207d9f17658cd50f6c4bea8e293b12abd89455a174b2d96bac84742a66b0afdf","size":69995},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_format.go","sha256":"b8cb8e31edd9d854317a0d6a456f25d5ab1838498623881e429dec2155e1ea67","size":16488},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_structure.go","sha256":"4916268757b93d409cbc13ba9c0da14e009499b4db7cadd52bc7ccd47c6a86ad","size":18640},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_progress_test.go","sha256":"0952fff321daa368dee1d32ed39a2a5b417e7d2779ae4e1015ab3c12b1021048","size":61314},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_migrations.go","sha256":"7736e30a1d0c6e9584d9050cc6ebf8bfaf900d424f764ebe61af8ec8ddaec0c9","size":17407},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_physical_test.go","sha256":"2c125b6373f83467d542db45473cc79b888ed3a665e65ef6bf013655f461a7ba","size":14539},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_pooled_claim_read_cleanup_test.go","sha256":"0ec3060ed3c30a6327ec49b0291d5c761c20894986c9b6b1e1be384694312823","size":8912},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_claim.go","sha256":"8ddec89b4ca5702591bdf2060062016d7fb54264fc7df57af5ead1d161eb9de3","size":8301},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go","sha256":"e0765e59cb00ace73e8a88c92b9d7e830b39766792120845220b2fd407d357fa","size":28903},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_progress_schema.go","sha256":"132d8ab87f5658cab3477b9f6913538013ba922d4768192a96be960df7bbb149","size":30612},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_shape.go","sha256":"29cdbba2e5b1fee069989f6e6423dccc1c69c843de22b6504f68a7d199b317be","size":2751},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_shape_test.go","sha256":"3552ea5fafbc59e43cc21b1007486e98da4d59b6d0ea98db92646e0c8478adfb","size":8815},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_store.go","sha256":"e448d265516aae1d7efd2c06170d8cfa2cc8c0258f82dfc15a3279e65efad4c1","size":63299},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_store_test.go","sha256":"c99e7659b1059431911557ba43ef7fa982e373bba939f610bd41ea0622cee96f","size":57339},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_guardrails_test.go","sha256":"32de42b7bf8974e36c014d3d9ce6d24e0994fbbc03bb1587c4c4fddd32c80f6e","size":50991},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_format.go","sha256":"0a21803b03308332613481f89ce4b595512b31b073c56b31fe7d8000519c3beb","size":17326},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_hydration.go","sha256":"b5ff16b96178c45b53165ebb2bcbdc67991bb145276ca4a11a598f1430745b9c","size":28800},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_private.go","sha256":"d17927a23a57c808a8f0ebc4bad3e9912e42d7da497033637102bae2c45fd278","size":20440},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_private_test.go","sha256":"4e4e7c7fad2ed2b88b35801841044f4b1f049a4cb6d0435499bb87699467e9f2","size":45171},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/workstream_c_guardrails_test.go","sha256":"68f2fe4e31e5d862be161c3ba1071a511935b32e90cf9021755fe4dcb045fab5","size":297009}],"head":"f1aa8b934cc26c16a966a110c7b408abdaeadce7","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"793e6697cf2342ce41f08ed8f59a0a14eb5c288c74780f158731d55dbe17bcca","upstream":"origin/trunk_dev"}
```
