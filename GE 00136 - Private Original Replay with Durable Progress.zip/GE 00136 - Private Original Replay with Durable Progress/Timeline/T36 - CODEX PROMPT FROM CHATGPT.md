# Execution Substrate — PR #11 Exact-Tree Squash Merge and Closeout Gate

Date: 2026-11-19 (America/New_York)
Selected action: one conditional normal synchronous squash merge; no source edits.

## 1. Objective, routing, and authority

Continue in the SAME foreground Codex conversation that published the accepted
private replay-progress commit and created PR #11. Close any remaining subagents;
spawn none for this gate. The foreground parent is the sole operator.

Use this exact source checkout with explicit command working directories:

```text
/Users/ds/Repositories/ES-Private-Replay-Progress-v1
```

The conversation may remain associated with the earlier A1 workspace. That is not
permission to operate on A1 or to move either checkout. Read-only verification and
the permitted GitHub write target the progress checkout/repository only.

Authorized effects:
- create one new private external evidence root;
- read local committed objects, working/index state, necessary material evidence,
  and official GitHub/Git state;
- after all prewrite gates, issue AT MOST ONE normal synchronous squash-merge
  request for PR #11, pinned to the exact head;
- verify the resulting commit, PR, and refs; retain a complete inline closeout.

No source/doc/test/permission/dependency/config edit, staging, local commit,
amendment, re-signing, push, rebase, branch update, cherry-pick, reset, restore,
stash, clean, fetch, pull, prune, branch deletion, tag, release, deployment,
operational migration, live-service action, real-key loading, runtime wiring,
review submission/reply/dismissal/resolution, reviewer request, PR title/body/base
change, label/assignee/milestone change, policy change, check rerun/cancellation,
auto-merge, queue enrollment or async-merge fallback is authorized.

Do not alter PRs #8, #9 or #10. No other checkout or old evidence root may change.
Do not rerun product tests, diagnostic cases, migration fixtures, N-1, independent
acceptance, historical red controls, probes or the socket campaign. Those results
are authenticated retained evidence, not a new validation assignment.

The selected scope is source integration of a private Bounded slice rule on the
reliable-submit Reopened redesign seam, limited to
`synthetic_progress_nonoperational_v1`. Git merge does not authorize effects from
synthetic phases/receipts, operational reliable Submit, or Coordinator progression.

## 2. Exact identities and appendices

```text
Repository: evo-agi/Execution-Substrate
PR: 11
URL: https://github.com/evo-agi/Execution-Substrate/pull/11
Local branch: codex/private-replay-progress-v1
Local upstream: origin/codex/private-replay-progress-v1
Fetch and push origin: git@github.com:evo-agi/Execution-Substrate.git
Git/common directory: /Users/ds/Repositories/ES-Private-Replay-Progress-v1/.git

Local HEAD / remote topic / required PR head:
dbdc433283617b9e3b233f75c92f1179c2ece91f

Accepted complete source tree:
e066cd4afa77fcb665f31b69bf00465989f9744e

Required sole parent / normal premerge official trunk_dev:
f1aa8b934cc26c16a966a110c7b408abdaeadce7

Parent complete tree:
8dd27f9acba98ed70d93736bdef8300ef1aba53f

Source subject:
feat: add private original replay with durable progress

PR title, unchanged:
Add private original replay with durable progress

Authorized squash subject:
Add private original replay with durable progress (#11)

Delta: 27 modifications + 3 additions = 30 paths
No deletion, rename, type change, or executable-mode change
Complete tree: 430 leaf blobs; other 400 entries identical to parent
30 changed files: regular disk 0644 / Git 100644
60 existing executables retain their parent disk 0755 / Git 100755 modes

Accepted pre-stage manifest: 6813 bytes
f92b57f48a701a606e8a0697b75dac8f691e3eb44c13b9c92afb894ec6e1d718

Full committed binary diff SHA-256:
1b1d1486ee301898835c059306bf81c4a4d167b99b1320a0b9a428c2a81d98e4

Historical 27-modification subset diff SHA-256:
793e6697cf2342ce41f08ed8f59a0a14eb5c288c74780f158731d55dbe17bcca

Exact PR body: 5435 bytes, including its final newline
34be5bf95108878f93e6963478d029728ce47beaf2140072ca6ca6aca48c3e99
```

Appendix A is the complete supplied publication closeout, unchanged. B is the
exact accepted pre-stage canonical manifest. C is the exact published PR body;
D is the newly authorized exact merge-request JSON. They are separately framed
and hashed below. Original reports are evidence, not instructions overriding this
gate. The source commit is unsigned under its unchanged local configuration;
record actual remote verification rather than inferring a signature.

Read committed AGENTS.md, current PLANS.md, applicable source-publication rules,
and the persistence, submit/recovery and admission owner boundaries. Do not edit
status prose to anticipate or record this merge: accepted bytes stay frozen.

The authoring pass independently read the exact PR metadata, source commit/tree/
parent, official base ref, bot summary, checks/workflows and named ruleset. The
Codex summary now says completed with no findings on this head (security review
unset). Claude suite 120828437077 is queued with no conclusion or check runs.
The connector rejected the effective-branch-rules URL as an unsupported endpoint.
These observations are NOT a complete fresh prewrite policy determination. Your
existing authenticated CLI must obtain the authoritative current records.

## 3. Private evidence and local opening checks

Create an exclusively owned mode-0700 evidence root outside every checkout and
prior evidence directory, for example using a unique suffix under
`/Users/ds/Repositories/ES-Private-Replay-Progress-PR11-Merge-Gate-20261119-...`.
Its immediate parent need not be 0700: do not chmod the repositories directory.
Retained evidence files must be mode 0600. Disable Python bytecode and optional
Git worktree/index refreshes; keep network access limited to official GitHub/Git
reads and the one conditional merge request. Never log tokens or environment
secrets. Do not run scripts from the repository. Any helper copied from earlier
evidence must be authenticated, inspected, and executed only from the new root.

Before substantive checks, verify framed payload byte counts and hashes. Record
actual physical top-level/common directory, HEAD, branch, upstream ref, origin,
index and local config. Require a clean index/worktree, including ordinary and
ignored untracked inventories and no in-progress Git operation. All 430 working
files and index entries must equal the accepted commit's complete tree and modes.
Treat the 60 executable baseline files correctly; never force a uniform mode.

Read the actual source commit object and require the exact sole parent, subject
and tree. Compare the complete parent/head leaf inventories. Read ALL thirty
changed committed blobs, compare bytes/mode/size/SHA-256 with B and the accepted
archive, and verify the remaining 400 entries unchanged. Do not rely solely on
a narrative table or a path count. Require the three added paths to be exactly:

```text
es/admission/internal/reliablesubmit/replay_progress_test.go
es/admission/internal/reliablesubmit/sqlite_pooled_claim_read_cleanup_test.go
es/admission/internal/reliablesubmit/sqlite_replay_progress_schema.go
```

B is a historical PRE-STAGE manifest with an old HEAD/upstream and three
`untracked` classifications. Those are not today's hygiene requirements. Do not
run the working-tree recipe on the clean committed checkout and demand B's old
output, and do not try to convert B silently. Actual committed blobs/tree and
historical validation bindings are the bridge. The full committed diff includes
the additions and is intentionally different from the 27-path historical subset.

Reproduce the full and restricted committed comparisons using the deterministic
read-only options recorded by publication. Exact full comparison:

```sh
git --no-pager -c core.fsmonitor=false -c core.untrackedCache=false \
  diff --full-index --binary --no-ext-diff --no-textconv --no-renames \
  f1aa8b934cc26c16a966a110c7b408abdaeadce7 \
  dbdc433283617b9e3b233f75c92f1179c2ece91f --
```

For the subset, use the exact 27 `tracked_modified` paths from B as literal
pathspecs. Never include the three additions when comparing its old digest.

## 4. Authenticate retained evidence, not another test campaign

Publication evidence root:
`/Users/ds/Repositories/ES-Private-Replay-Progress-Publication-Gate-20261119-XWwXcqzr`

| Record | SHA-256 |
|---|---|
| report.md | f7a56bc6d71ad277c7b2684207cf0d8be63a3cd62d61f5201046f10bd89af110 |
| artifact-index.json | e0b9f0ea3abd1d6e41f9e91eedcd79713e63fb0eaeb12b1d03bd76c71667f713 |
| publication-bindings.json | 368786271c125b01fd0990eaf82f23ccc93a06edd6af4b65c5f6e20b58324d25 |
| verified-source-table.md | 1e0d79db52cf23f1d6b570c495d7fbf0ff75dd88facc88cf39ba22f7a014eeb4 |
| closing-observation.json | 17ad0e2b35847f7bfd60e506c9a07ae66a531a878736c86016ac7c7f44bde78b |
| final-local-verified.json | 340efbebc16a30fbe60bddddd2f14d1fefff21fa44328d0945c90bbc463c28a3 |

Local commit evidence root:
`/Users/ds/Repositories/ES-Private-Replay-Progress-Commit-Gate-20261119-U0JC7ELW`
- report.md: `e1813a68c168c18879ef7e369c64638835aca4c05805f2141fae36d6e76a6999`
- artifact-index.json: `858d4b7208532dd2d1c45a847c207d9236f09624a958a48251e81d3c21d3a153`

Independent acceptance root:
`/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Independent-Audit-20261119-tDnKaFZH`
- artifact-index.json: `7847cde1799ec2166cf599fb73ad726ab056b82bb128dd6b695f107f1e858205`
- exact ACCEPT transport (46438 bytes), resolve from authenticated index:
  `332349b4ce386ce8a7da9f64dd2807dd33f1d259cf287fccd49eaf286af11f28`

Accepted archive:
`/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/ES-Private-Replay-Progress-M1-Owner-Repair-Review.zip`
- 955015 bytes: `3b27c483036296304a9fbca77dcd5fe522dee64b8eabf392057b6c573160f59a`

Authenticate these reports/indexes and the material records necessary to bind
accepted files, the staged tree, actual commit, publication bytes, all twelve
staged command outcomes/guards, identity/skip reconciliation, and the retained
full-suite and N-1 results. Resolve exact child paths from the authenticated
indexes rather than guessing. Include actual relied-upon paths/hashes in the new
ledger. Recheck that subset before the write and at closeout.

Expected retained local validation: owner 27/0/0; pooled reader 16/0/0; internal
and probes 221/0/0; admission/inventories 26/0/0; API/App 2/0/0; four packages
2062/0/39; full repository 5192/0/39, 21 tested + 20 no-test packages; external
N-1 5/0/0. All twelve staged commands ran, with fresh integrity observations.
These are local results, NOT passing CI. Preserve the 39 skip identities and
qualifications. Native installed-source witnessing remains unqualified.

No probe execution/rebuild, source-view compilation, build-graph rerun, physical
fault campaign or historical red replay is selected. Do not recursively require
a new hash census of all old evidence roots, module cache files or unrelated
checkouts. Authenticate only material retained evidence actually used.

The two SHA cells in the earlier supplied commit report were already adjudicated
as transport-only errors against actual committed bytes before publication. The
private duplicate was correct. Preserve both historic renditions. Require the
correct actual blobs and current generated table, not another report-reissue:
- durable_service.go: ef0bc6f4d125f3986c46901cbe05bc2cb447af7dfbf51cee4653d7ce696c0945
- reliable_submit_guardrails_test.go: 32de42b7bf8974e36c014d3d9ce6d24e0994fbbc03bb1587c4c4fddd32c80f6e
Any new substantive discrepancy stops the merge; do not repair history.

## 5. Fresh official source and PR verification

Use existing authenticated official Git/GitHub read routes; no new credentials
or installations. Authenticate the destination/owner/repository identity. An
unrelated remote ref movement is not a source mismatch and must not be undone.
No local fetch, including trunk or topic, is needed or permitted here.

Before requiring the normal old-base state, check whether PR #11 is already
merged. If so, perform the completed-merge verification in section 9 without
another write. A closed/unmerged PR, conflicting merge/tree/base, or unexplained
state stops; do not reopen, replace or retarget it.

For a normal unmerged gate, require:
- official trunk_dev = `f1aa8b...` and topic = `dbdc433...` by fresh refs;
- the exact source commit metadata/tree/parent and thirty-path scope;
- complete nontruncated head and parent trees (or full directory traversal), with
  all 430 head leaf path/type/mode/object-ID entries matching the accepted tree;
- all thirty decoded remote changed blobs equal the local committed bytes, B,
  and archived accepted payloads; the other 400 equal the remote parent;
- exactly PR #11 for this owner/head, open, non-draft, unmerged, with no auto-merge
  or queue entry, exact head repo/branch/SHA, base repo/branch/SHA, title and C body;
- exactly one source commit and exactly the thirty changed paths, with correct
  additions/modifications and no delete/rename/type/mode drift;
- true mergeability and a normal clean/eligible merge state, not blocked/behind/
  conflicting/unknown. Record REST and GraphQL results where available.

GitHub's premerge `merge_commit_sha` may name a preview merge. It is not the
completed squash and must never be used as proof that the merge occurred.
Use bounded observations; an unsettled or unreadable required state stops this
turn rather than launching a polling or waiting campaign.

## 6. Effective policy, reviews, checks, and automation

Read the COMPLETE effective rules for `trunk_dev`, including applicable inherited
rules, and classic protection separately. Paginate material collections through
completion. The named ruleset alone is not enough. An explicit classic response
`Branch not protected` may establish absence of classic protection while rulesets
still apply; a permission error or generic 404 does not. Use the existing CLI and
GraphQL as supported; if effective merge requirements cannot be established,
stop before the write. Do not change authentication, protections or bypass policy.

The earlier named ruleset 17579282 was active, squash-only, PR-required, thread-
resolution-required, with zero approving reviews and no bypass actors. Treat this
as a prior observation, not a policy override. Satisfy all actual current review,
check, signature, branch-update, deployment and queue requirements. The unsigned
source is acceptable only when current policy permits it. Confirm normal viewer
permission to merge. No administrator-bypass path is authorized.

Verify repository squash availability, auto-merge unset, no required merge queue
or stacked/downstack merging, and automatic head-branch deletion DISABLED. If
policy would require updating the branch or using an async/queue path, stop; do
not widen this gate. If automatic deletion is enabled, stop rather than changing
that setting or silently allowing deletion of the preserved topic.

Read and paginate formal reviews, active changes requests, inline comments,
review threads with resolution/outdated state, issue comments and automated
summaries, requested reviewers, check suites, ALL check runs (not just a hidden
latest subset), legacy status contexts, and Actions/workflow runs for the exact
head and any preview SHA required by effective policy. Inspect annotations and
findings when present. Check available merge-triggered repository workflows,
hooks/deployments/environments and relevant settings without exposing credentials.
Stop on a known unapproved deployment, release, live-host or runtime effect.
Explicitly disclose inaccessible organization/external integrations; never claim
absence from missing permissions. Do not turn this into an unrelated org audit.

Require no unresolved substantive finding, active change request, required
review/check deficit, or actual active review/check/job. Do not dismiss, resolve,
reply, approve, cancel, rerun or mark anything successful. The Codex issue-summary
comment at ID 7025022350 must refer to the exact head. Its current completed/no-
findings code-review status is neither formal approval nor a security-review pass;
null security fields remain no result. Fresh records, not this sentence, control.

### Explicit narrow allowance: empty optional Claude suite

This gate permits proceeding WITHOUT A CLAUDE RESULT if, and only if, all of these
freshly checked conditions hold:
1. The suite is precisely `120828437077`, from app `claude`, for exact head
   `dbdc433...`, still queued with null conclusion and zero associated check runs.
2. Complete effective policy does not require that suite, its app, or a missing
   associated result. No required check or workflow is missing or pending.
3. Full check-run/workflow/job/review/comment observations reveal no associated
   active work, queued/running job, review-in-progress marker, adverse result or
   substantive finding. The independently completed Codex review is accounted for.
4. The ordinary non-bypass GitHub path is currently eligible and all other source,
   policy and review checks pass.

This is a decision to proceed without the optional result, NOT proof that the app
is inactive, stale, broken, finished, passed, or incapable of later findings.
State that limitation explicitly in the closeout. An empty legacy pending
aggregate with zero contexts is likewise not passing CI and may coexist with
this allowance only when complete policy requires no absent result.

If the suite completes before the gate, inspect its actual conclusion, runs and
findings; a passing/neutral nonrequired no-finding result can be recorded normally.
Any actual queued/running check, job or review, failure/adverse conclusion, new
finding, additional unexplained pending suite, or inability to establish these
conditions stops this turn before merge. No suite cancellation or suppression,
standing exemption for future PRs, or indefinite polling is authorized.

## 7. Immediate prewrite checkpoint and single request

Immediately before writing, re-read the exact base and topic refs, PR head/base,
open/draft/merged state, exact title/C body, reviews/threads/findings, check state,
effective rules and relevant settings. Recheck local source and material evidence.
Record one consolidated proceed/stop decision. Any drift in the selected base,
head, tree, acceptance binding or material policy stops; do not rebase/rederive.

Extract exact D to a private mode-0600 file and verify its byte count/hash. D has
exactly `sha`, `merge_method`, `commit_title` and `commit_message`; do not add
bypass, auto-merge, branch-delete, queue or asynchronous options. No per-call
source mutation is needed. Issue at most one normal request with the installed
GitHub CLI, using its existing authenticated identity:

```sh
gh api --method PUT \
  -H 'Accept: application/vnd.github+json' \
  -H 'X-GitHub-Api-Version: 2026-03-10' \
  repos/evo-agi/Execution-Substrate/pulls/11/merge \
  --input "$MERGE_REQUEST_FILE"
```

MERGE_REQUEST_FILE must contain exactly D. Record the actual executable, command,
input hash, timing, exit status and safe complete response. Do not use an implicit
`gh pr merge`, local merge, direct trunk push, a different merge method, asynchronous
endpoint, CLI retry loop or fallback request.

The expected-head `sha` guards the PR HEAD, not the base atomically. The immediate
base read reduces but does not eliminate a concurrent-base race. Verify the actual
squash parent and tree after the write; do not claim this request atomically pinned
both. A newly observed parent/tree discrepancy is an incident, not permission to
rewrite trunk or accept a new integration target.

## 8. Ambiguous or rejected response

No second merge request is authorized. On timeout, transport ambiguity, 403/405/
409/422, or unexpected response, use bounded read-only reconciliation. Read the
PR merge status, actual merge object and refs. If the exact intended merge can be
conclusively verified, report it and distinguish readback from the unobserved or
rejected transport. Otherwise preserve the actual state and stop with an explicit
uncertainty/blocker. Do not compensate by reopening, reverting, deleting branches,
force pushing or retrying with different parameters.

A successful merge can occur before a later verification problem. Report the
completed effect first; never claim no mutation merely because closeout is blocked.

## 9. Verify actual squash and preserve local state

For a success response or an already merged exact PR, independently read the
actual squash commit object. Require:
- a new real commit associated with PR #11, not the preview or the topic commit;
- exactly one parent: `f1aa8b934cc26c16a966a110c7b408abdaeadce7`;
- complete tree: `e066cd4afa77fcb665f31b69bf00465989f9744e`;
- exact authorized squash subject and intended message content from D;
- complete 430-leaf tree equal to the already checked accepted tree;
- exact delta of 27 modifications and 3 additions, with other 400 unchanged;
- all thirty changed payloads byte/mode/size/SHA-256/object-ID equal to B and the
  accepted local source. Previously decoded immutable blobs may be reused only
  after the actual squash tree independently names the same exact object IDs;
- PR closed and merged, actual merge SHA/time recorded, body/title/head/base
  preserved, no auto-merge/queue action and no extra effect requested;
- official trunk_dev equals the verified squash at normal closeout;
- official topic and local HEAD remain `dbdc433...` with same-topic upstream;
- unchanged local index/config/refs/worktree and all 430 files/modes; all five
  hygiene inventories empty.

Record actual author/committer/signature verification instead of assuming signing.
Do not reset or fetch the source checkout to the squash. Local origin/trunk_dev
may remain intentionally at `f1aa8b...`; that is not a failed source-publication
result. Do not delete or clean the topic or existing checkouts.

If the exact squash is verified but trunk advances again before closeout, report
that observed later movement separately. Do not undo it or assert trunk still
points at the squash. If available, use read-only ancestry/compare evidence to
separate a valid completed merge from a conflicting or unknown later ref state.
The normal exact-tip success marker below requires its stated postconditions;
an already completed exact merge can be reported verified without a duplicate
write, with any later-trunk qualification plainly stated.

Read postmerge checks/reviews and visible automation once for unexpected effects.
New squash suites are not retroactively passing CI. New substantive findings are
reported, not repaired in this gate. Source merge is not deployment or runtime
permission. Recheck all materially relied-upon prior evidence without altering it.

## 10. Complete inline closeout and stop conditions

Deliver a decision-complete human-readable report INLINE, plus a private duplicate
and bounded self-excluding index. Include actual local/remote identities, request
outcome and effect count, exact parent/tree proof, source scope, thirty-file binding
summary, retained validation versus CI, fresh policy and review conclusions, the
Claude allowance's actual application or nonapplication, automation visibility
limits, observed merge SHA/time/signature, local preservation, all skipped work,
setup errors, any uncertainty and remaining operational nonclaims.

Generate hash/source tables from verified machine bindings and parse them back.
Do not hand-copy the old erroneous cells. An external artifact is a supplement,
not a replacement for the inline decision. Preserve raw historical reports.
Clean only this gate's positively owned scratch. Prior evidence, module caches,
Git objects/refs, repositories and user temporary directories are not cleanup scope.

Normal success:

```text
ES_PRIVATE_REPLAY_PROGRESS_PR11_SQUASH_MERGED
SOURCE_BYTES_NOT_CHANGED
LOCAL_HEAD_AND_TOPIC_PRESERVED
PRODUCT_TESTS_NOT_RERUN_IN_MERGE_GATE
PR8_PR9_PR10_NOT_MODIFIED
AUTO_MERGE_NOT_ENABLED
BRANCH_NOT_DELETED
TAG_NOT_CREATED
RELEASE_NOT_CREATED
DEPLOYMENT_NOT_PERFORMED
EXISTING_OTHER_SOURCE_CHECKOUTS_NOT_SYNCHRONIZED
RUNTIME_WIRING_NOT_PERFORMED
PUBLIC_RELIABLE_SUBMIT_NOT_ENABLED
CROSS_RESTART_OPERATIONAL_WRITE_UNCERTAINTY_GATE_NOT_IMPLEMENTED
NATIVE_INSTALLED_SOURCE_WITNESS_NOT_QUALIFIED_BY_THIS_SLICE
```

An already exact merge uses `ES_PRIVATE_REPLAY_PROGRESS_PR11_EXISTING_MERGE_VERIFIED`
and explicitly records zero new merge requests. A prewrite blocker uses a concrete
blocked verdict and states no merge request was issued. Ambiguous or postwrite
failures state actual effects and exact uncertainty. Do not collapse these states.

Physical/device-close success, hard close duration, capacity under actual double
withholding, SQLite file/sidecar byte preservation, real provider/receipt evidence,
native installed-source qualification, operational no-dispatch proof, and cross-
restart operational write-uncertainty authority remain unqualified. The accepted
observation pool's unchecked close return on refusal stays disclosed. No new
product repair, snapshot, acceptance audit, or runtime-slice decision is selected.

### Public API reference checked during prompt preparation

GitHub REST pull-request documentation identifies the synchronous
`PUT /repos/{owner}/{repo}/pulls/{pull_number}/merge` endpoint and its expected-head
`sha`, squash method and message fields. The synchronous path does not support a
merge queue or stacked requests; this gate stops if either is required. Reference:
`https://docs.github.com/en/rest/pulls/pulls#merge-a-pull-request`.

## Appendix transport

The payload starts immediately after its BEGIN marker's newline. Read exactly the
declared UTF-8 byte count and verify its hash; the extra framing newline before
END is not part of the payload. Preserve all original newlines and bytes. A, B and
C retain their received/extracted content; D is the exact newly selected request.

### Appendix A — Complete supplied publication closeout, unmodified

Bytes: 19395
SHA-256: ade6d4ddc82ebbbc6af9c41698349ca9b90af9ddef055374434d3b0efc7d7ac0

<!-- BEGIN APPENDIX A -->
# ES_PRIVATE_REPLAY_PROGRESS_PR_CREATED

Opened [PR #11, Add private original replay with durable progress](https://github.com/evo-agi/Execution-Substrate/pull/11) with one non-force topic push and one PR creation. It is open, non-draft, and unmerged, with auto-merge unset. GitHub returned the exact authorized 5,435-byte body, including its final newline. The local checkout and index are clean.

| Published identity | Verified value |
|---|---|
| Repository | `evo-agi/Execution-Substrate` |
| Head branch and commit | `codex/private-replay-progress-v1` at `dbdc433283617b9e3b233f75c92f1179c2ece91f` |
| Base branch and sole parent | `trunk_dev` at `f1aa8b934cc26c16a966a110c7b408abdaeadce7` |
| Head tree | `e066cd4afa77fcb665f31b69bf00465989f9744e` |
| Parent tree | `8dd27f9acba98ed70d93736bdef8300ef1aba53f` |
| Commit subject | `feat: add private original replay with durable progress` |
| Author and committer | `AlacerMortis <david.shaw.dev@gmail.com>` at `2026-11-19T17:54:30-05:00`, unsigned |
| PR scope | One commit, 27 modified files, three added files |
| Exact PR body SHA-256 | `34be5bf95108878f93e6963478d029728ce47beaf2140072ca6ca6aca48c3e99` |

## Report reconciliation and source proof

Before any write, I independently read the 30 committed blobs, their index and working-file counterparts, and the archived payloads. The only discrepancies were two SHA-256 cells in supplied Appendix A. Both corresponding cells in the private commit-gate report were correct. All sizes, change kinds, and Git blob IDs agreed. The archived payloads, manifest, staged freeze, actual commit, and retained validation bind the same complete tree. Both historical reports were preserved byte for byte.

| Path | Supplied Appendix A line | Private report line | Correct SHA-256 |
|---|---:|---:|---|
| `es/admission/internal/reliablesubmit/durable_service.go` | 66, incorrect 64-character value | 58, correct | `ef0bc6f4d125f3986c46901cbe05bc2cb447af7dfbf51cee4653d7ce696c0945` |
| `es/admission/reliable_submit_guardrails_test.go` | 83, malformed 62-character value | 75, correct | `32de42b7bf8974e36c014d3d9ce6d24e0994fbbc03bb1587c4c4fddd32c80f6e` |

The sole checkout was `/Users/ds/Repositories/ES-Private-Replay-Progress-v1`, with its own `.git` as both Git and common directory. Opening and closing checks independently compared all 430 local files and modes to the index and committed tree. GitHub supplied complete, nontruncated head and parent trees. All 430 remote leaf paths, modes, and blob IDs matched locally. I decoded and compared all 30 remote changed blobs by complete bytes, size, SHA-256, and Git object ID. The other 400 entries matched the parent, including all 60 baseline executables. The external N-1 sources were absent from the checkout, index, and remote tree.

The full parent-to-commit binary diff with renames, text conversion, and external diff disabled reproduced `1b1d1486ee301898835c059306bf81c4a4d167b99b1320a0b9a428c2a81d98e4`. Restricting that command to the 27 tracked modifications reproduced the historical digest `793e6697cf2342ce41f08ed8f59a0a14eb5c288c74780f158731d55dbe17bcca`.

### All thirty exact bindings

Path prefixes `L`, `A`, and `I` expand under the checkout to `.docs/execution_lifecycle`, `es/admission`, and `es/admission/internal/reliablesubmit`, respectively. All 30 rows are disk `0644` and Git `100644`. The generated report table was parsed back and checked against the computed bindings before delivery.

| Path | Delta | Bytes | SHA-256 | Git blob |
|---|:---:|---:|---|---|
| `L/es_execution_admission_model.md` | M | 88702 | `bedc87c611b5c9340ffaafb0866f028dc9daf2f22552efec47491f1b4ae713f2` | `0f5c56cdbf11b80158f29700a31fef5dc20f335f` |
| `L/reliable_submit_persistence_and_concurrency.md` | M | 161666 | `34e06ff10148d67a49000868499294873c732279d7f399a5f2cb910b0c12f40e` | `772fb7dbd4bfb1d8162b87b0d66c0803957cbdd9` |
| `L/submit_idempotency_correlation_and_recovery.md` | M | 103025 | `1b03cc40b48861c7220a7b85d20b1f8d232690f17460e3eee0df33af4659e3f3` | `94fe56e0cdea71acf29c2df1074bcd4048c0bc0b` |
| `PLANS.md` | M | 302636 | `c4fdbfb4acd3c2a27f679f6575798c4553e94110c4aa7177f590e90fe89c5e31` | `b74440dc7d3ef2e488d92a7fb9f6f64d7cecdcee` |
| `docs_contract_test.go` | M | 799914 | `dd433f02e783aa265d775bd411c95433e369642e2aafbdb32c72b75f78b4ebff` | `e69ada92d1e723e1b70f03e5191e96145e687713` |
| `I/durable_operation.go` | M | 9548 | `b7761f001a1f67349ed51f2b79012194a7d45bb19c79e0ca2c0c22b8227320f9` | `94a7d56b5f8ef5501f92abf7cb0c7732a490859d` |
| `I/durable_record.go` | M | 25226 | `999db7db6550c5031b023a9613825504e30e971a179298cc43e09cf8c5c5d7cd` | `41e2dc127cd0a56163a9f9c42992e3e2dad9643b` |
| `I/durable_service.go` | M | 49972 | `ef0bc6f4d125f3986c46901cbe05bc2cb447af7dfbf51cee4653d7ce696c0945` | `25ef96d035c6be87209d81c7b831a366f47d6e94` |
| `I/guardrails_test.go` | M | 32231 | `9a300f0553fd6ac3003a048a7309060a4ec6f618eacd94139bd4bb29c011bc60` | `ebadc607372c586f1681d6290037cac50b0167fe` |
| `I/replay_custody_file.go` | M | 50461 | `61c4006e1e4a3feb7c0ec0e7d4685dc2c3fe8c1e2165d1529d2c86ae8fa137b5` | `b1bc86218f53653d04eda1840ced29c8688ce098` |
| `I/replay_custody_file_test.go` | M | 69995 | `207d9f17658cd50f6c4bea8e293b12abd89455a174b2d96bac84742a66b0afdf` | `d5b0f305b3809520f79c4ef1f9ab206292be7578` |
| `I/replay_custody_format.go` | M | 16488 | `b8cb8e31edd9d854317a0d6a456f25d5ab1838498623881e429dec2155e1ea67` | `134c37fff7318ccc356a0ce34ced924eb16b95a1` |
| `I/replay_custody_structure.go` | M | 18640 | `4916268757b93d409cbc13ba9c0da14e009499b4db7cadd52bc7ccd47c6a86ad` | `f1aed2819f38138264e5691432f849079252a3bb` |
| `I/replay_progress_test.go` | A | 61314 | `0952fff321daa368dee1d32ed39a2a5b417e7d2779ae4e1015ab3c12b1021048` | `f055ead2af265d3ac5d28c4c6a6698f46449a389` |
| `I/sqlite_migrations.go` | M | 17407 | `7736e30a1d0c6e9584d9050cc6ebf8bfaf900d424f764ebe61af8ec8ddaec0c9` | `7814a04f4962fbdb8cec4a1d3a24201ea10f9bca` |
| `I/sqlite_physical_test.go` | M | 14539 | `2c125b6373f83467d542db45473cc79b888ed3a665e65ef6bf013655f461a7ba` | `620899f647432e48789bee7df219b5689ef417c7` |
| `I/sqlite_pooled_claim_read_cleanup_test.go` | A | 8912 | `0ec3060ed3c30a6327ec49b0291d5c761c20894986c9b6b1e1be384694312823` | `4aa80cca7b7c3d3011dd277aaaeda4f59b02011a` |
| `I/sqlite_replay_claim.go` | M | 8301 | `8ddec89b4ca5702591bdf2060062016d7fb54264fc7df57af5ead1d161eb9de3` | `4f4ce954febca494bada72ebc2e5f95bc43af2fb` |
| `I/sqlite_replay_migration_test.go` | M | 28903 | `e0765e59cb00ace73e8a88c92b9d7e830b39766792120845220b2fd407d357fa` | `8191f490886cef673e1ce98dc30dc982e69d3e61` |
| `I/sqlite_replay_progress_schema.go` | A | 30612 | `132d8ab87f5658cab3477b9f6913538013ba922d4768192a96be960df7bbb149` | `1317d92ba935f9cd1b9532ca0807a5c9cf05282c` |
| `I/sqlite_replay_shape.go` | M | 2751 | `29cdbba2e5b1fee069989f6e6423dccc1c69c843de22b6504f68a7d199b317be` | `b4b5f18f5686a912cf02f9164cc2e27ff6ffa59a` |
| `I/sqlite_replay_shape_test.go` | M | 8815 | `3552ea5fafbc59e43cc21b1007486e98da4d59b6d0ea98db92646e0c8478adfb` | `3f938be010268b950351c0ec72922e2379a297d2` |
| `I/sqlite_store.go` | M | 63299 | `e448d265516aae1d7efd2c06170d8cfa2cc8c0258f82dfc15a3279e65efad4c1` | `97a9d8f5c8b74a1c7d05812a0d6f80073d613dd4` |
| `I/sqlite_store_test.go` | M | 57339 | `c99e7659b1059431911557ba43ef7fa982e373bba939f610bd41ea0622cee96f` | `ee2f8c5b6255d3ba4990fc23c2b393bda85e0d77` |
| `A/reliable_submit_guardrails_test.go` | M | 50991 | `32de42b7bf8974e36c014d3d9ce6d24e0994fbbc03bb1587c4c4fddd32c80f6e` | `56ee45b1a99e453a96bcbce21095ccd894deb26f` |
| `A/reliable_submit_replay_format.go` | M | 17326 | `0a21803b03308332613481f89ce4b595512b31b073c56b31fe7d8000519c3beb` | `533877eea3ef937d8d7c77c85e2ac160a43af790` |
| `A/reliable_submit_replay_hydration.go` | M | 28800 | `b5ff16b96178c45b53165ebb2bcbdc67991bb145276ca4a11a598f1430745b9c` | `97f3eec0f78b20a7afc4b1f6e53df55c5911ee6c` |
| `A/reliable_submit_replay_private.go` | M | 20440 | `d17927a23a57c808a8f0ebc4bad3e9912e42d7da497033637102bae2c45fd278` | `ace0e7c6a7e35c8e8385e49008e06a567a17b5cd` |
| `A/reliable_submit_replay_private_test.go` | M | 45171 | `4e4e7c7fad2ed2b88b35801841044f4b1f049a4cb6d0435499bb87699467e9f2` | `e45e87ec5fa7abbaccd1d365cab1d642d8f6c44b` |
| `A/workstream_c_guardrails_test.go` | M | 297009 | `68f2fe4e31e5d862be161c3ba1071a511935b32e90cf9021755fe4dcb045fab5` | `59bac2e2b3f3214dbaaf6c080d6356df9d84e31c` |

## Publication and tracking

Fresh `git ls-remote --refs` and GitHub ref reads agreed at opening, before push, before PR creation, and at closeout. The official base stayed at the selected parent. The topic was absent before the push. Fully paginated, all-state PR queries for the exact owner and head returned zero matches before creation and exactly PR #11 afterward. The prewrite reads establish what was observed at each check. The push itself returned one new-branch result, which the remote readback confirmed.

Each command below ran once from `/Users/ds/Repositories/ES-Private-Replay-Progress-v1` and exited 0.

```sh
GIT=/opt/homebrew/Cellar/git/2.49.0/bin/git
SPEC=dbdc433283617b9e3b233f75c92f1179c2ece91f:refs/heads/codex/private-replay-progress-v1
BODY_FILE=/Users/ds/Repositories/ES-Private-Replay-Progress-Publication-Gate-20261119-XWwXcqzr/pr-body.md

"$GIT" -c push.followTags=false -c remote.origin.mirror=false \
  push --dry-run --porcelain origin "$SPEC"
"$GIT" -c push.followTags=false -c remote.origin.mirror=false \
  push --porcelain origin "$SPEC"
"$GIT" branch --set-upstream-to origin/codex/private-replay-progress-v1 \
  codex/private-replay-progress-v1
/opt/homebrew/bin/gh pr create --repo evo-agi/Execution-Substrate --base trunk_dev \
  --head codex/private-replay-progress-v1 \
  --title 'Add private original replay with durable progress' --body-file "$BODY_FILE"
```

| Command | Exit time, EST | Stdout SHA-256 |
|---|---|---|
| Dry run | `18:20:53.615444` | `d8975c1feb5d76e1eda9957e26890b4a2feb0a4a32ab5419042caf73310def06` |
| Push | `18:21:18.658794` | `d8975c1feb5d76e1eda9957e26890b4a2feb0a4a32ab5419042caf73310def06` |
| Set upstream | `18:21:37.463391` | `4127b3bb559fee5b3275c86730f237775fb917f7dc228fd9df0979d0023b9432` |
| Create PR | `18:21:47.019785` | `3b64b94b1ff9b829dbd5f6e1c2a480139152abe759d4948c1339405879d08c06` |

Push stderr contained GitHub’s new-PR invitation and authenticated to `8bc825d543bfe671fc048d2bd3df4c0b662f8f3d9c0f4885f1178cd6ca8911a6`. The other three stderr streams were empty, SHA-256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

The push populated `refs/remotes/origin/codex/private-replay-progress-v1`, and the existing wildcard fetch mapping already covered it. I skipped the fetch and additional mapping. Local upstream moved from `origin/trunk_dev` to `origin/codex/private-replay-progress-v1`. Only the topic branch’s merge key changed in local config. Both effective remote URLs remained `git@github.com:evo-agi/Execution-Substrate.git`. The local trunk tracking ref stayed at the selected parent. Raw index SHA-256 remained `eceb865ee65dcbff43da6d75ec659a74e557f4617b171590f967b3969780328f`. All five staged, unstaged, unmerged, ordinary-untracked, and ignored inventories were empty.

## Policy, reviews, and checks

GitHub reported push, maintain, and admin access for the authenticated viewer. The topic had zero effective branch rules, and the API showed zero active repository push rulesets. The effective `trunk_dev` ruleset requires a PR, resolved threads, and a squash merge, with zero required approving reviews. It also protects trunk creation, deletion, and non-fast-forward updates. The classic-protection endpoint returned `404 Branch not protected`, while ruleset protections remained visible. Actions were enabled, squash was allowed, and auto-merge was disabled. Before publication the visible workflow, repository hook, and deployment lists were empty, and the base and head trees contained no workflow files. The repository hook inventory does not cover all organization integrations. [Effective trunk ruleset](https://github.com/evo-agi/Execution-Substrate/rules/17579282)

The bounded, fully paginated check and review snapshot finished at **18:23:21 EST on November 19, 2026**.

| Surface | Observed |
|---|---|
| Mergeability | REST `true` / `clean`, GraphQL `MERGEABLE` / `CLEAN` |
| Formal reviews and discussions | Zero formal reviews, inline review comments, review threads, unresolved threads, or requested reviewers |
| Automated issue comments | One Codex summary for the exact head. Code review was running and no security-review result was shown |
| Check suites | One Claude suite, `120828437077`, queued with no conclusion |
| Check and workflow runs | Zero check runs and zero workflow runs |
| Legacy statuses | Pending aggregate, zero contexts |

No substantive finding had been returned at that observation. Pending review, a queued suite, and zero runs leave CI and review outcomes unresolved. The next gate is a separately authorized merge-readiness decision. [Codex review summary](https://github.com/evo-agi/Execution-Substrate/pull/11#issuecomment-7025022350)

## Retained validation and evidence

The publication gate authenticated the retained validation without executing product tests, N-1, migrations, diagnostics, or probe builds. The twelve retained primary commands had exit 0, and their raw logs, identities, guards, and staged tree binding reconciled to the independent acceptance. Counts below are retained local test identities.

| Group | Pass / fail / skip |
|---|---:|
| Owner contracts | 27 / 0 / 0 |
| Pooled reader | 16 / 0 / 0 |
| Internal regressions and historical openers | 221 / 0 / 0 |
| Admission and typed inventories | 26 / 0 / 0 |
| API/App boundaries | 2 / 0 / 0 |
| Four-package suite | 2062 / 0 / 39 |
| Full repository | 5192 / 0 / 39, across 21 tested and 20 no-test packages |
| Separate external N-1 | 5 / 0 / 0 |

The retained 39 skips were two direct helper sentinels and 37 App capability cases. The allocator parent executed its helper. The separate N-1 evidence bound the 432-file view, 291 package records, and 2,801 build inputs. Its four response-loss cases distinguished unknown from authenticated own-COMMIT confirmation, with zero measured provider, staging, or EGS contacts and empty operational roots. The earlier commit-gate harness failures occurred before primary execution and remain recorded as such.

The current attachment authenticated at `3604771b0df462285d1b4ffe23a68a2db5f7c448af270f131153ecdc4fa2160c`. Exact framed payloads were:

| Appendix | Bytes | SHA-256 |
|---|---:|---|
| A, supplied commit closeout | 29499 | `0998241f845e69720c91bd2441a1e03385b1dff9cc66e6f2451ae51339f77e3f` |
| B, accepted manifest | 6813 | `f92b57f48a701a606e8a0697b75dac8f691e3eb44c13b9c92afb894ec6e1d718` |
| C, authorized PR body | 5435 | `34be5bf95108878f93e6963478d029728ce47beaf2140072ca6ca6aca48c3e99` |
| D, comparison map | 8971 | `fcf5e5be3a69c8a5598ba2e3bba49d78d9061cbe7fcb7cbd8075cb37545cfcb8` |

I rechecked 140 indexed commit-gate records and 82 indexed independent-acceptance records, plus the retained 432-file view. This subset included the staged freeze, committed bindings, closeout, all 12 command and guard records, test and skip identities, both probe bindings, and N-1 source and build evidence. The commit-gate report and index authenticated to `e1813a68c168c18879ef7e369c64638835aca4c05805f2141fae36d6e76a6999` and `858d4b7208532dd2d1c45a847c207d9236f09624a958a48251e81d3c21d3a153`. The independent acceptance index authenticated to `7847cde1799ec2166cf599fb73ad726ab056b82bb128dd6b695f107f1e858205`. Its retained 46,438-byte ACCEPT report authenticated to `332349b4ce386ce8a7da9f64dd2807dd33f1d259cf287fccd49eaf286af11f28`. The 955,015-byte review ZIP authenticated to `3b27c483036296304a9fbca77dcd5fe522dee64b8eabf392057b6c573160f59a`, including all 47 members and 46 inventory rows.

The gate used installed Git 2.49.0, Python 3.13.4 with `-B`, and GitHub CLI 2.92.0. Read-only Git checks disabled optional index updates, fsmonitor, untracked caching, lazy fetch, and prompting. The effective remote destination, applicable attributes, hooks, and signing posture were inspected before publication. No active push hook or URL rewrite was in effect, and no policy was bypassed.

Four verifier issues were corrected in new private evidence. The local checker initially read its command-scoped fsmonitor override as persistent config. The hook query initially combined unsupported CLI pagination flags. The dry-run parser initially rejected Git’s rendering of the same SSH destination without `git@`, though the command exited 0 and proposed the exact branch. The closeout formatter lacked an import and resumed from authenticated API responses, with a fresh official ref check. No write command was retried.

The publication preserves the fixture-only `synthetic_progress_nonoperational_v1` scope, M-1 and DOC-SYNC closure, legacy codec and immutable-original behavior, public structural reliable-request refusal, and unkeyed Submit. Physical close, hard latency, actual double-withholding capacity, device and sidecar byte preservation, real provider or receipt evidence, and native and operational qualification remain outside the evidence. The accepted observation pool’s unchecked close return on refusal remains disclosed.

The private root contains `0700` directories and `0600` evidence files. No temporary source export or cache needed cleanup. The self-excluding index authenticated all 527 retained entries.

| Artifact | SHA-256 |
|---|---|
| [Private publication report](/Users/ds/Repositories/ES-Private-Replay-Progress-Publication-Gate-20261119-XWwXcqzr/report.md) | `f7a56bc6d71ad277c7b2684207cf0d8be63a3cd62d61f5201046f10bd89af110` |
| [Self-excluding evidence index](/Users/ds/Repositories/ES-Private-Replay-Progress-Publication-Gate-20261119-XWwXcqzr/artifact-index.json) | `e0b9f0ea3abd1d6e41f9e91eedcd79713e63fb0eaeb12b1d03bd76c71667f713` |
| [Complete machine bindings](/Users/ds/Repositories/ES-Private-Replay-Progress-Publication-Gate-20261119-XWwXcqzr/publication-bindings.json) | `368786271c125b01fd0990eaf82f23ccc93a06edd6af4b65c5f6e20b58324d25` |
| [Verified source table](/Users/ds/Repositories/ES-Private-Replay-Progress-Publication-Gate-20261119-XWwXcqzr/verified-source-table.md) | `1e0d79db52cf23f1d6b570c495d7fbf0ff75dd88facc88cf39ba22f7a014eeb4` |
| [Closing GitHub observation](/Users/ds/Repositories/ES-Private-Replay-Progress-Publication-Gate-20261119-XWwXcqzr/closing-observation.json) | `17ad0e2b35847f7bfd60e506c9a07ae66a531a878736c86016ac7c7f44bde78b` |
| [Final local verification](/Users/ds/Repositories/ES-Private-Replay-Progress-Publication-Gate-20261119-XWwXcqzr/final-local-verified.json) | `340efbebc16a30fbe60bddddd2f14d1fefff21fa44328d0945c90bbc463c28a3` |

```text
ES_PRIVATE_REPLAY_PROGRESS_PR_CREATED
REPORT_TABLE_DISCREPANCIES_RECONCILED_AGAINST_COMMITTED_BYTES
SOURCE_BYTES_NOT_CHANGED
NEW_COMMIT_NOT_CREATED
PRODUCT_TESTS_NOT_RERUN_IN_PUBLICATION_GATE
PR8_PR9_PR10_NOT_MODIFIED
MERGE_NOT_PERFORMED
AUTO_MERGE_NOT_ENABLED
TAG_NOT_CREATED
RELEASE_NOT_CREATED
DEPLOYMENT_NOT_PERFORMED
EXISTING_OTHER_SOURCE_CHECKOUTS_NOT_SYNCHRONIZED
RUNTIME_WIRING_NOT_PERFORMED
PUBLIC_RELIABLE_SUBMIT_NOT_ENABLED
CROSS_RESTART_OPERATIONAL_WRITE_UNCERTAINTY_GATE_NOT_IMPLEMENTED
NATIVE_INSTALLED_SOURCE_WITNESS_NOT_QUALIFIED_BY_THIS_SLICE
```
<!-- END APPENDIX A -->

### Appendix B — Exact accepted pre-stage canonical manifest

Bytes: 6813
SHA-256: f92b57f48a701a606e8a0697b75dac8f691e3eb44c13b9c92afb894ec6e1d718

<!-- BEGIN APPENDIX B -->
{"branch":"codex/private-replay-progress-v1","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/es_execution_admission_model.md","sha256":"bedc87c611b5c9340ffaafb0866f028dc9daf2f22552efec47491f1b4ae713f2","size":88702},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md","sha256":"34e06ff10148d67a49000868499294873c732279d7f399a5f2cb910b0c12f40e","size":161666},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md","sha256":"1b03cc40b48861c7220a7b85d20b1f8d232690f17460e3eee0df33af4659e3f3","size":103025},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"c4fdbfb4acd3c2a27f679f6575798c4553e94110c4aa7177f590e90fe89c5e31","size":302636},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"dd433f02e783aa265d775bd411c95433e369642e2aafbdb32c72b75f78b4ebff","size":799914},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_operation.go","sha256":"b7761f001a1f67349ed51f2b79012194a7d45bb19c79e0ca2c0c22b8227320f9","size":9548},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_record.go","sha256":"999db7db6550c5031b023a9613825504e30e971a179298cc43e09cf8c5c5d7cd","size":25226},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_service.go","sha256":"ef0bc6f4d125f3986c46901cbe05bc2cb447af7dfbf51cee4653d7ce696c0945","size":49972},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/guardrails_test.go","sha256":"9a300f0553fd6ac3003a048a7309060a4ec6f618eacd94139bd4bb29c011bc60","size":32231},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_file.go","sha256":"61c4006e1e4a3feb7c0ec0e7d4685dc2c3fe8c1e2165d1529d2c86ae8fa137b5","size":50461},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_file_test.go","sha256":"207d9f17658cd50f6c4bea8e293b12abd89455a174b2d96bac84742a66b0afdf","size":69995},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_format.go","sha256":"b8cb8e31edd9d854317a0d6a456f25d5ab1838498623881e429dec2155e1ea67","size":16488},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_structure.go","sha256":"4916268757b93d409cbc13ba9c0da14e009499b4db7cadd52bc7ccd47c6a86ad","size":18640},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_progress_test.go","sha256":"0952fff321daa368dee1d32ed39a2a5b417e7d2779ae4e1015ab3c12b1021048","size":61314},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_migrations.go","sha256":"7736e30a1d0c6e9584d9050cc6ebf8bfaf900d424f764ebe61af8ec8ddaec0c9","size":17407},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_physical_test.go","sha256":"2c125b6373f83467d542db45473cc79b888ed3a665e65ef6bf013655f461a7ba","size":14539},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_pooled_claim_read_cleanup_test.go","sha256":"0ec3060ed3c30a6327ec49b0291d5c761c20894986c9b6b1e1be384694312823","size":8912},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_claim.go","sha256":"8ddec89b4ca5702591bdf2060062016d7fb54264fc7df57af5ead1d161eb9de3","size":8301},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go","sha256":"e0765e59cb00ace73e8a88c92b9d7e830b39766792120845220b2fd407d357fa","size":28903},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_progress_schema.go","sha256":"132d8ab87f5658cab3477b9f6913538013ba922d4768192a96be960df7bbb149","size":30612},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_shape.go","sha256":"29cdbba2e5b1fee069989f6e6423dccc1c69c843de22b6504f68a7d199b317be","size":2751},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_shape_test.go","sha256":"3552ea5fafbc59e43cc21b1007486e98da4d59b6d0ea98db92646e0c8478adfb","size":8815},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_store.go","sha256":"e448d265516aae1d7efd2c06170d8cfa2cc8c0258f82dfc15a3279e65efad4c1","size":63299},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_store_test.go","sha256":"c99e7659b1059431911557ba43ef7fa982e373bba939f610bd41ea0622cee96f","size":57339},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_guardrails_test.go","sha256":"32de42b7bf8974e36c014d3d9ce6d24e0994fbbc03bb1587c4c4fddd32c80f6e","size":50991},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_format.go","sha256":"0a21803b03308332613481f89ce4b595512b31b073c56b31fe7d8000519c3beb","size":17326},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_hydration.go","sha256":"b5ff16b96178c45b53165ebb2bcbdc67991bb145276ca4a11a598f1430745b9c","size":28800},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_private.go","sha256":"d17927a23a57c808a8f0ebc4bad3e9912e42d7da497033637102bae2c45fd278","size":20440},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_private_test.go","sha256":"4e4e7c7fad2ed2b88b35801841044f4b1f049a4cb6d0435499bb87699467e9f2","size":45171},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/workstream_c_guardrails_test.go","sha256":"68f2fe4e31e5d862be161c3ba1071a511935b32e90cf9021755fe4dcb045fab5","size":297009}],"head":"f1aa8b934cc26c16a966a110c7b408abdaeadce7","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"793e6697cf2342ce41f08ed8f59a0a14eb5c288c74780f158731d55dbe17bcca","upstream":"origin/trunk_dev"}

<!-- END APPENDIX B -->

### Appendix C — Exact published PR body, including final newline

Bytes: 5435
SHA-256: 34be5bf95108878f93e6963478d029728ce47beaf2140072ca6ca6aca48c3e99

<!-- BEGIN APPENDIX C -->
## Summary

Add private original replay with durable claim progress as one integrated, independently accepted source slice. The path is limited to `synthetic_progress_nonoperational_v1`: fixture-only, runtime-unwired, and effect-ineligible, including synthetic accepted and receipt states.

Schema 4 and codec 4 join authenticated original custody to the existing ES durable service in one SQLite authority domain. They preserve global caller/key occupation, one immutable original and physical row, one attempt, and one assigned run. Durable successors preserve the original descriptor and sealed object rather than resealing or reconstructing them from current defaults.

## Selected behavior and compatibility

- Preserve migration literals 1-3, authentic schema and ledger checks, historical codec-1/2 behavior, and immutable codec-3 `synthetic_nonoperational_v1`. The schema-2 PB1 probe and previous-schema-3 opener retain their separate schema-3 and schema-4 refusal purposes.
- Authenticate the actual migration opening state under the writer lock. Unconfirmed eligible migration cleanup routes through original-pool disposition and one checked nonmigrating observation; recovery performs no migration retry or second write. A qualified current head is an observation, not attribution to an unattempted COMMIT.
- Preserve exact original-key eligibility, one-use borrow lifetime, safe confirmation projection, shared object allocation, and permit-burn boundaries. SQLite owns committed claims, progress, keys and grant/use facts; custody owns private-object authentication.
- Preserve earlier reconciliation as history without making an ineligible new command a valid no-op. Synthetic terminal evidence binds outcome, attempt, fact and exact receipt association. It does not establish external provider acceptance.
- Preserve an invocation's own write disposition. Later authenticated reads or explicitly supplied fixture commands do not resolve an earlier unknown response. Failed winner disclosure preserves a definite occupied result without disclosing progress.
- Harden the pooled `loadClaim` prerequisite while leaving `loadClaimFresh` unchanged. Align the owner inventory with the existing private fixture synchronization fields without creating a new registry or runtime authority.

Public structural reliable-request refusal and ordinary unkeyed Submit remain unchanged. ES admission/runtime facts and Coordinator programme progression remain separate.

## Exact source

Source commit: `dbdc433283617b9e3b233f75c92f1179c2ece91f`  
Sole parent / selected base: `f1aa8b934cc26c16a966a110c7b408abdaeadce7`  
Complete source tree: `e066cd4afa77fcb665f31b69bf00465989f9744e`

The delta is exactly 30 files: 27 modifications and three additions. The complete tree contains 430 leaves; 400 are unchanged from the parent. The three added files are internal progress tests, pooled-reader cleanup tests, and the private schema-4 definition. No deletion, rename, type change, or executable-mode change is selected.

Accepted pre-stage manifest: `f92b57f48a701a606e8a0697b75dac8f691e3eb44c13b9c92afb894ec6e1d718`  
Complete committed-diff SHA-256: `1b1d1486ee301898835c059306bf81c4a4d167b99b1320a0b9a428c2a81d98e4`

## Acceptance and validation

Fresh independent audit returned ACCEPT for the complete thirty-path candidate, closing the remaining M-1 pre-COMMIT recovery and DOC-SYNC findings and preserving the other resolved findings. The exact local commit gate compared accepted, staged and committed blobs and complete trees without editing source.

All twelve staged commands passed. The ordinary full suite recorded **5,192 passes, zero failures and 39 skips**, with 21 tested packages and 20 packages without tests. All selected parents ran; the test identities matched the independent audit. The 39 skips remain two direct helper sentinels and 37 App capability cases, including the unavailable native installed-source witness. The allocator parent executed and verified its helper.

A separate source-bound admission diagnostic passed five identities covering four real-COMMIT/modeled-response-loss cases for establishment and AssignRun. It preserved unknown versus authenticated own-COMMIT confirmation, subsequent current reads, zero measured provider/staging/EGS contacts and empty operational roots. Its two diagnostic source files are external evidence and are not committed.

These are authenticated **local** validation results, not a claim that CI passed. Publication authenticates the existing results without another test or probe rebuild. Earlier failed runs remain historical failures.

## Explicit limits

This PR does not enable public reliable Submit, operational ingress/key provisioning, provider dispatch or reconciliation, deployment, or native installed-source qualification. The operational no-dispatch predicate and cross-restart write-uncertainty authority remain unimplemented by this facade.

Physical/device-close success, hard close latency, capacity under actual double withholding, SQLite file/sidecar byte preservation, and real provider/receipt claims remain unqualified. The accepted observation pool's unchecked close return on refusal remains disclosed. Logical preservation and fixture outcomes must not be described as operational guarantees.

PRs #8, #9 and #10 remain completed history. This publication requests review of unchanged accepted source, not merge or runtime permission.

<!-- END APPENDIX C -->

### Appendix D — Exact authorized synchronous squash-merge request JSON

Bytes: 1433
SHA-256: b1c1619c9ebb2d7e897b00cfd935a2e53b87904ce5ab093c69d1a9c326cdec6a

<!-- BEGIN APPENDIX D -->
{"commit_message":"Integrate the independently accepted private original-replay and durable-progress source slice.\n\nSource commit: dbdc433283617b9e3b233f75c92f1179c2ece91f\nAccepted complete tree: e066cd4afa77fcb665f31b69bf00465989f9744e\nAccepted pre-stage manifest: f92b57f48a701a606e8a0697b75dac8f691e3eb44c13b9c92afb894ec6e1d718\n\nSchema 4 and codec 4 preserve one authenticated immutable original, one claim/attempt and assigned run, global caller/key occupation, legacy behavior, and invocation-scoped write dispositions. M-1 and DOC-SYNC are independently closed; the earlier accepted repairs are preserved.\n\nRetained local staged validation: 5,192 passes, zero failures and 39 documented skips; the separate admission response-loss witness passed five identities. These are local results, not a CI-pass claim.\n\nScope remains synthetic_progress_nonoperational_v1: private, fixture-only, runtime-unwired and effect-ineligible. No public reliable Submit, provider acceptance, deployment, native installed-source qualification, operational no-dispatch proof or cross-restart operational write-uncertainty authority is enabled. Physical-close, hard-latency and actual double-withholding limits, and the observation pool's unchecked close return on refusal, remain disclosed.","commit_title":"Add private original replay with durable progress (#11)","merge_method":"squash","sha":"dbdc433283617b9e3b233f75c92f1179c2ece91f"}

<!-- END APPENDIX D -->
