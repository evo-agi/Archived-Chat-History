# Execution Substrate — Private Replay-Progress Exact-Commit Publication Gate

Date: 2026-11-19 (America/New_York)
Engagement: pre-publication report reconciliation, unchanged-source verification,
one exact topic push and one new PR; STOP BEFORE MERGE.

## 1. Objective, routing and exact effect authority

Continue in the SAME foreground Codex conversation that created local commit
`dbdc433283617b9e3b233f75c92f1179c2ece91f`. Close any remaining reviewers; spawn no
subagents. The foreground parent is the sole operator. This is not a new product
repair, independent audit, validation campaign or merge gate.

The sole source checkout is:

```text
/Users/ds/Repositories/ES-Private-Replay-Progress-v1
```

Use explicit command working directories. The conversation may still be associated
with the A1 checkout, but that does not authorize source or Git administration
changes there. Do not move, copy, synchronize or substitute any other checkout.

Authorized effects are limited to:
- One new private external publication-evidence root.
- Read-only local source/evidence and official Git/GitHub verification.
- The narrowly defined report-field reconciliation in section 3, recorded only
  in new evidence; do not modify the supplied or historical report.
- At most ONE exact non-force single-topic push after at most one dry run.
- Only necessary same-topic local tracking administration in this checkout.
- At most ONE non-draft PR into `trunk_dev`, with the exact title and body below.

No source, tests, docs, modes, dependencies or product configuration may change.
No staging, new commit, amend, re-sign, rebase, cherry-pick, merge, reset, restore,
stash, clean, new source branch/worktree, broad fetch, pull, prune, tag, release,
deployment, operational migration, live service, real-key loading, runtime wiring,
review request, review reply, thread resolution, label/assignee/milestone change,
auto-merge or branch deletion is authorized. Do not modify PRs #8, #9 or #10.

Do not rerun product tests, N-1, diagnostics, migration fixtures, historical red
controls, socket campaigns or old-binary builds. Authenticate retained validation.
Read-only source/evidence verification and temporary evidence files are permitted.
Do not install or download dependencies.

Successful normal endpoint:

```text
ES_PRIVATE_REPLAY_PROGRESS_PR_CREATED
```

A clean GitHub merge state does not extend this gate to merge.

## 2. Exact publication target and source boundaries

```text
Physical/Git top-level:
/Users/ds/Repositories/ES-Private-Replay-Progress-v1

Git/common directory:
/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.git

Branch:
codex/private-replay-progress-v1

Normal opening upstream:
origin/trunk_dev
(The idempotent existing-publication cases permit an already exact
origin/codex/private-replay-progress-v1 upstream.)

Official origin fetch and push:
git@github.com:evo-agi/Execution-Substrate.git

Official repository:
evo-agi/Execution-Substrate

Accepted local commit:
dbdc433283617b9e3b233f75c92f1179c2ece91f

Complete accepted tree:
e066cd4afa77fcb665f31b69bf00465989f9744e

Required sole parent / selected official trunk_dev base:
f1aa8b934cc26c16a966a110c7b408abdaeadce7

Parent tree:
8dd27f9acba98ed70d93736bdef8300ef1aba53f

Exact source subject:
feat: add private original replay with durable progress

Reported author and committer:
AlacerMortis <david.shaw.dev@gmail.com>
2026-11-19T17:54:30-05:00
Unsigned under the existing local configuration.

Delta:
30 paths = 27 modified existing files + 3 additions
No deletion, rename, type change or executable-mode change
All 30 changed files: regular disk 0644 / Git 100644
Complete tree: 430 leaves; other 400 equal parent
All 60 baseline executable leaves keep disk 0755 / Git 100755

Full 30-path committed diff SHA-256:
1b1d1486ee301898835c059306bf81c4a4d167b99b1320a0b9a428c2a81d98e4

27-path tracked-only historical diff SHA-256:
793e6697cf2342ce41f08ed8f59a0a14eb5c288c74780f158731d55dbe17bcca

Accepted pre-stage manifest: 6813 bytes
f92b57f48a701a606e8a0697b75dac8f691e3eb44c13b9c92afb894ec6e1d718

Remote topic:
refs/heads/codex/private-replay-progress-v1

PR base:
trunk_dev

Exact PR title:
Add private original replay with durable progress

PR body:
Exact Appendix C bytes, including the final newline.

Expected PR:
one commit, exactly 27 modified files and 3 added files
open, non-draft, unmerged, auto-merge unset
```

Read committed AGENTS.md, current PLANS.md, applicable publication instructions,
and the persistence, submit/recovery and admission owner contracts. The accepted
classification is a Bounded slice rule on the reliable-submit Reopened redesign
seam, restricted to `synthetic_progress_nonoperational_v1`. It preserves legacy
codecs, immutable codec 3, public structural reliable-request refusal and
unkeyed Submit. Fixture results, evidence and Git publication do not confer
provider or Coordinator programme authority.

Do not update PLANS.md during publication. Its historical selection/acceptance
wording is part of the accepted source. New publication facts belong in this
closeout and PR; later owner work can update current status with its own scope.

Appendix A is the complete supplied local commit report, unchanged, INCLUDING
the two incorrect SHA-256 cells described below. B is the exact accepted manifest
from the authenticated source archive. C is the exact authorized PR body. D is a
derived thirty-row expected Git-blob map and explicit discrepancy ledger. D was
computed from the archive's complete payloads; it is not proof of the live commit.

The authoring review observed official trunk_dev at the parent, an absent topic,
and zero all-state exact-head PR matches. Those are prior read-only observations,
not current permission or a substitute for this gate's fresh reads.

## 3. Mandatory report-field reconciliation BEFORE any remote or tracking write

The supplied report's per-path table has exactly two SHA-256 cells that disagree
with the accepted archive and B. The thirty Git blob IDs, byte sizes and change
kinds in that table agree with hashes independently computed from the accepted
payloads. The erroneous cells are:

### durable_service.go

```text
Path:
es/admission/internal/reliablesubmit/durable_service.go
Bytes: 49972
Git blob (reported and independently computed from accepted payload):
25ef96d035c6be87209d81c7b831a366f47d6e94

Supplied report SHA-256, incorrect:
ef0bc6f4d125f3986c46901cbe05bc2cb447af7dfbf51afe993a59c2afaf7971

Accepted manifest and complete payload SHA-256:
ef0bc6f4d125f3986c46901cbe05bc2cb447af7dfbf51cee4653d7ce696c0945
```

### reliable_submit_guardrails_test.go

```text
Path:
es/admission/reliable_submit_guardrails_test.go
Bytes: 50991
Git blob (reported and independently computed from accepted payload):
56ee45b1a99e453a96bcbce21095ccd894deb26f

Supplied report SHA-256, malformed 62-character value:
32de42b7bf8974e36c014d3d9ce6d24e0994fbbc03bb1587c4fddd32c80f6e

Accepted manifest and complete payload SHA-256:
32de42b7bf8974e36c014d3d9ce6d24e0994fbbc03bb1587c4c4fddd32c80f6e
```

This gate authorizes direct read-only adjudication of these report fields. It
does NOT presume that the local commit matches just because the object-ID cells
look correct. Before any push, tracking/config write or PR creation:

1. Authenticate A, B, C and D by exact framing/byte count/hash, then the accepted
   source archive and the private commit-gate report/index.
2. Read ALL thirty actual committed blobs from `dbdc433...`, their tree entries,
   all corresponding index/working files, and the accepted archive payloads.
   Independently compute complete-byte SHA-256 and Git blob IDs. Require exact
   equality with B and D, including these two paths.
3. Verify the complete 430-leaf commit/tree and all 400 unchanged parent entries,
   plus the exact staged-tree and retained validation bindings in section 4.
4. Compare the supplied report with the private duplicate, whose rendered bytes
   may differ. Determine whether its two cells are also erroneous or correct.
   Read the authenticated source/staged/committed proof records rather than
   treating the narrative table as source truth.
5. Require the source, accepted manifest, staged freeze, committed proof and
   validation records to bind the same complete tree without substantive conflict.
   Record the exact observed values and report locations in NEW evidence.

If the discrepancy is limited to these supplied narrative cells (and the same
cells in a duplicate, if present), with all underlying binding records and
actual objects agreeing, classify it as a verified report transcription defect
and continue through this SAME gate. No separate report-reissue turn, source
repair, re-acceptance or test rerun is needed. Preserve the original report bytes
and make the correct values explicit in the new inline closeout.

Any actual blob/tree mismatch, unexplained additional discrepancy, contradictory
source/validation binding or inaccessible material evidence stops ALL publication.
Do not substitute accepted archive bytes into the checkout, rewrite the commit,
edit past evidence, infer acceptance from a digest, or silently "correct" A.
A syntactically valid but wrong 64-character hash is not a verified source match.

## 4. Authenticate material evidence without rerunning validation

Commit-gate evidence root:

```text
/Users/ds/Repositories/ES-Private-Replay-Progress-Commit-Gate-20261119-U0JC7ELW
```

| Record | SHA-256 |
|---|---|
| report.md | e1813a68c168c18879ef7e369c64638835aca4c05805f2141fae36d6e76a6999 |
| artifact-index.json | 858d4b7208532dd2d1c45a847c207d9236f09624a958a48251e81d3c21d3a153 |
| Closing guard, resolve actual path from index | 380b3092685c8e99081417ce0fc96c9ba96d1bf8ece5a3d6c3438a73bb2eb507 |
| Full-suite stdout, resolve from index | 885155c9716b250f2a74994dc3ed942fd0b1ea1343e26355fafe94fa0709c5ff |
| N-1 stdout, resolve from index | 257523ccb6e49a30aa83f20ffa853cfd54e91f03c8d249ce1ac78426066d70dd |

Independent acceptance root:

```text
/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Independent-Audit-20261119-tDnKaFZH
```

| Record | SHA-256 |
|---|---|
| artifact-index.json | 7847cde1799ec2166cf599fb73ad726ab056b82bb128dd6b695f107f1e858205 |
| closing-a.json and closing-b.json | f92b57f48a701a606e8a0697b75dac8f691e3eb44c13b9c92afb894ec6e1d718 |
| closing-guard.json | a670d3738e2ea00f911233948d0c08daed3b76073bbc80a95b2df01e5f205ede |
| fresh-reconciliation.json | d49c9d3d551e6e1608a07ff7a10295eb9d4d3b9c4396635e5d70da472451f813 |
| retained-reconciliation.json | effd722966ad2e22d130e6c30329e2029800d1737747758ae94d9bb2fdd22b9e |
| n1-build-reconciliation.json | 4af8b5c1497b41f3eee8ba0e0084b8eb66118cf6424b7682b8d3dbc6c8e7f9f0 |

Authenticate the complete ACCEPT report through the retained commit-gate Appendix
A binding: 46438 bytes, SHA-256
`332349b4ce386ce8a7da9f64dd2807dd33f1d259cf287fccd49eaf286af11f28`.
It is carried by the prior exact local commit prompt, complete SHA-256
`540633b602a6fbf0bb07af4131515c29b29f0a77e7dad8bcf5afe0a24983242b`,
and retained gate evidence. Do not invent a private audit report filename;
use the authenticated index or the already retained exact appendix.

Accepted source archive:

```text
/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/ES-Private-Replay-Progress-M1-Owner-Repair-Review.zip
955015 bytes
3b27c483036296304a9fbca77dcd5fe522dee64b8eabf392057b6c573160f59a
```

An index-bound identical copy at a different location is acceptable when recorded;
never fabricate or rewrite an old path. Verify source/staged/committed proof,
complete tree freeze, twelve argv/cwd/exit records, raw logs, test and skip
reconciliation, immediate guards, and N-1 source/view bindings needed to substantiate
this publication. The exact checked subset must be recorded and rechecked before
the write and at closeout. Do not require a whole-history directory census or
repeat all 1,376 historical probe-material records when the authenticated accepted
bindings and actual retained tests supply the same scoped claim. Retain historical
failure qualifications without reopening their campaigns.

Retained results, not a new execution claim:

| Staged gate group | Test passes/failures/skips |
|---|---|
| Owner contracts | 27/0/0 |
| Pooled reader | 16/0/0 |
| Internal regressions and historical openers | 221/0/0 |
| Admission and typed inventories | 26/0/0 |
| API/App boundaries | 2/0/0 |
| Four packages | 2062/0/39 |
| Ordinary full repository | 5192/0/39; 21 tested packages, 20 without tests |
| External N-1 | 5/0/0, disjoint from the ordinary suite |

There were twelve primary commands including version, formatting, both diff
checks, the package gates and external witness. The supplemental go-list build
inspection was separate. Two disclosed gate harness incidents occurred before
any primary execution; retain that distinction. Do not describe local results
as passing CI or any skipped native witness as qualified.

## 5. Private evidence, read posture and local source gate

Create one absent unique external root beneath `/Users/ds/Repositories/` with
prefix `ES-Private-Replay-Progress-Publication-Gate-20261119-`. It must be outside
all repositories and prior evidence roots. Use current-user-owned nonsymlink
0700 directories and 0600 evidence, and do not chmod the existing parent.

Use existing authenticated Git, Python and GitHub CLI installations. No upgrades,
credential rotation, token printing, sensitive environment dumps or broad private
directory scans. Use Python `-B` and `PYTHONDONTWRITEBYTECODE=1`; if a historical
verifier is necessary, inspect and copy it into the new root rather than importing
it in place. Disable optional Git index refresh/fsmonitor/untracked caches,
lazy fetching and prompting for read-only verification. Explicit authorized
network operations below are distinct from lazy fetch.

Record exact source root, Git/common directories, branch, upstream, origin fetch
and push URLs, HEAD metadata and absence of active Git operations. Require the
reported commit and sole parent/tree. No placeholder or sibling tree is accepted.
The opening local `origin/trunk_dev` is expected at the parent but is not a fresh
remote observation. Upstream migration is limited to section 8.

Read complete commit/index/worktree maps and compare all 430 leaves. Require
empty staged, unstaged, unmerged, ordinary-untracked and ignored inventories.
Preserve modes of the 60 baseline executables, including in any evidence export.
The two external N-1 files must be absent from the repository/index/tree.

Read applicable attributes, hooks, signing/identity policy and remote URL rewrite
configuration. Require one effective official fetch/push destination; no additional
push URL, mirror action, hidden refspec effect, automatic source repair or
unapproved runtime action is acceptable. Do not disable hooks, policy or signing
requirements to permit publication. The accepted commit is unsigned; report that
fact, and stop if applicable policy prohibits it rather than rewriting it.

Reproduce the FULL 30-path parent-to-commit diff using the active recipe's diff
options:

```sh
git --no-pager -c core.fsmonitor=false -c core.untrackedCache=false \
  diff --full-index --binary --no-ext-diff --no-textconv --no-renames \
  f1aa8b934cc26c16a966a110c7b408abdaeadce7 \
  dbdc433283617b9e3b233f75c92f1179c2ece91f --
```

Require full hash `1b1d1486...`. Also compare the same diff restricted using literal
argument-array pathspecs to the 27 B rows whose kind is tracked_modified, requiring
the historical `793e6697...` hash. Verify the three additions by exact blob bytes.
Do not reconstruct the patch in the source checkout or stage anything.

B is immutable pre-stage evidence: its three `untracked` rows became actual
additions. Do not run a clean-checkout v2 manifest and require it to reproduce B;
that would legitimately have no patch and a different HEAD. Do not edit the
historical manifest's upstream or classifications after setting topic tracking.

Raw index serialization and unrelated internal Codex refs are not substitutes for
logical index/object equality. If only serialization or unrelated refs differ,
record that fact rather than resetting them. Named source identity and complete
bytes must still match exactly.

## 6. Fresh remote state, policy and idempotency before publication

Use the official repository, read-only Git observations and existing GitHub
authentication. Paginate material collections fully and retain errors distinctly
from empty results.

Before any remote write:
- Confirm official `trunk_dev` remains exactly the selected parent using Git and
  API reads. A moved or unknown base stops this publication; no rebase, new base,
  changed source or alternate topic is authorized.
- Confirm exact remote topic state and all-state PRs for
  `evo-agi:codex/private-replay-progress-v1`, without filtering away a conflicting
  base. Do not select a PR number in advance or infer absence from a title search.
- Inspect applicable effective topic creation/push and base-PR policy, relevant
  repository settings, and visible push/PR automation. A source- or security-
  policy conflict, required signing mismatch or known unapproved deployment/
  release/live-host trigger stops its effect. Use the normal path; no bypass.
- Ordinary automatic CI and code review responses to this source publication
  are permitted. Do not manually dispatch, configure, cancel or rerun them.
  Record visibility limitations; unknown organization integrations are not absent.
- Complete future merge eligibility is NOT a prerequisite for a reviewable PR.
  A missing access scope needed to establish publication permission is a stop;
  an inaccessible future merge-only detail is a disclosed limit, not a false
  claim of either merge eligibility or failed local source acceptance.

The last observed named trunk ruleset requires PRs, resolved threads and squash
merge, with zero required approving reviews. Re-read the applicable policy;
neither that historical observation nor a zero count grants this gate merge
permission. Current optional integrations/reviews are not assumed unchanged.

Idempotent states:
1. Topic absent and no exact-head PR: normal one-push/one-create path.
2. Topic already equals this exact commit/tree and no PR: verify it, skip both
   push requests, and permit only the single PR creation after the other gates.
3. Exactly one open non-draft PR already matches owner/head/base/commit/tree,
   thirty-file delta, title and exact C body: verify existing publication with no
   duplicate remote write. Necessary same-topic tracking remains permitted.
4. Different topic bytes, different/draft/body-mismatched PR, multiple PRs, or a
   closed/merged exact-head PR: stop new writes for reconciliation. Do not edit,
   reopen, replace or create a duplicate.

Unrelated remote ref movement alone does not invalidate this commit and must not
be undone. Any change to the selected base/head or relevant policy is material.
An immediate prewrite read is not an atomic absence lock; preserve and report the
actual push response and readback rather than asserting a stronger race guarantee.

## 7. Exact single-topic push

Only after sections 3–6 pass and only when the topic is absent, run once:

```sh
git -c push.followTags=false -c remote.origin.mirror=false \
  push --dry-run --porcelain origin \
  dbdc433283617b9e3b233f75c92f1179c2ece91f:refs/heads/codex/private-replay-progress-v1
```

Require exit zero and exactly one intended new-branch proposal. Recheck the local
source, official base, absent topic, duplicate-PR set and applicable permission
immediately before one actual push:

```sh
git -c push.followTags=false -c remote.origin.mirror=false \
  push --porcelain origin \
  dbdc433283617b9e3b233f75c92f1179c2ece91f:refs/heads/codex/private-replay-progress-v1
```

No wildcard, force, `--all`, `--mirror`, tag following, other ref, deletion or
second push is permitted. Record exact command, exit and safe outputs. Unexpected
ref movement or a non-new-branch result stops before PR creation.

For a lost/timeout/ambiguous response, perform read-only reconciliation, NEVER a
blind retry. Continue only if the exact remote object/tree and intended single-ref
state are conclusively established without conflicting writer/state. Distinguish
verified readback from an unobserved transport result. An absent or unresolved
outcome stops; do not compensate by deleting the branch.

## 8. Same-topic tracking only

After the remote topic is conclusively exact, permit only necessary administration
in this standalone checkout:
- Preserve existing trunk fetch mapping and every unrelated setting.
- If no existing mapping covers the topic, add ONE exact non-wildcard
  topic-to-topic fetch mapping; do not duplicate an existing mapping.
- If the matching remote-tracking ref was not already updated, fetch ONLY it:

```sh
git fetch --no-tags --no-write-fetch-head origin \
  refs/heads/codex/private-replay-progress-v1:refs/remotes/origin/codex/private-replay-progress-v1
```

- Set upstream to `origin/codex/private-replay-progress-v1`; verify its ref is the
  exact published commit. If already exact, do not make a redundant change.

Do not fetch trunk, tags or other refs, prune, force an unexpected tracking ref,
pull, change HEAD or synchronize another checkout. Record the actual tracking/
config changes. The local old origin/trunk_dev may remain deliberately stale.

## 9. Create one non-draft PR using the exact body

Recheck official base unchanged, exact published commit and complete tree,
thirty-file scope, local source/evidence continuity, and all-state exact-head PR
absence. Extract C as a private file preserving its exact bytes. Create once with
the existing authenticated CLI:

```sh
gh pr create --repo evo-agi/Execution-Substrate --base trunk_dev \
  --head codex/private-replay-progress-v1 \
  --title 'Add private original replay with durable progress' \
  --body-file "$BODY_FILE"
```

BODY_FILE is an absolute private path containing exact C. Do not use `--fill`,
`--draft`, inline substitutions, a guessed PR number or implicit branch selection.
Do not add reviewers, teams, labels, milestones or assignees. C is the complete
authorized public-facing text; do not publish private machine paths, raw reports,
logs, databases, keys, synthetic fixture contents or the malformed source table.

At most one creation request is authorized. On ambiguity query the all-state
exact-head set and validate the result without retry. A readback body mismatch is
recorded and stops the gate; no editing to hide newline/content normalization is
authorized. Preserve the actual created PR identity and actual write outcomes.

## 10. Full readback and closeout

Independently verify:
1. Official topic equals `dbdc433...`; official base is still `f1aa8b...`.
2. Remote commit metadata, sole parent, subject and tree equal the accepted local
   objects. Obtain a complete nontruncated recursive tree, or complete directory
   traversal, and compare all 430 leaf paths/types/modes/blob IDs.
3. Decode and compare ALL thirty remote changed-file blobs to the actual local
   committed blobs, archive and B/D by complete bytes, size, SHA-256 and Git object
   ID. Check the other 400 entries against the remote parent. Never replace this
   with filename or count equality alone.
4. PR is open/non-draft/unmerged, auto-merge unset, exact owner/head/branch/SHA and
   base repo/branch/SHA, exact title and byte-identical C body.
5. PR has precisely one commit and 30 changed files: 27 modifications, 3 additions,
   zero deletion/rename/type/mode change. All names equal B's exact set.
6. Fresh reviews, review comments/threads, issue comments/automated summaries,
   check suites and runs, legacy statuses and visible workflow runs for the actual
   head. Fully paginate material collections and distinguish missing permission,
   empty, queued, running, failed and passed results.
7. Current mergeability and visible rules, including unresolved threads and any
   new substantive finding. Use bounded current reads, not waiting for a bot or
   repeated CI polling. Completed bot code review is not formal approval or
   security qualification unless the returned record supports that scope.
8. Final local HEAD/tree/index/all 430 file bytes and modes, five clean inventories,
   scoped config/tracking and materially relied-upon prior evidence unchanged
   except the explicitly allowed topic-tracking transition.

Publication may succeed even if a later bot finding or check blocks progression
toward merge. Report both facts. Do not repair, reply, dismiss, resolve, mark a
check successful, cancel a suite, rerun CI, auto-merge or merge. In particular,
zero runs or aggregate pending with zero contexts is NOT a passing CI result.
Do not reuse the historical empty-Claude-suite exception as a current finding.

The report must include the section-3 adjudication and all correct thirty-row
source bindings, not repeat the two bad cells. Make the human-readable closeout
complete inline, with a private duplicate as a supplement. Include actual effect
counts, local/remote identities, exact commands, retained validation limitations,
PR identity/title/body digest, current reviews/checks/policy and access limits,
clean-state readback, artifact identities, any setup failures, every skipped
action and the next unresolved gate.

Authenticate evidence after creation with a bounded self-excluding index. Prior
reports remain immutable. Recheck new report hash fields programmatically against
the computed bindings before delivery; a copied or manually typed SHA table is
not itself a validation step. Provide complete machine bindings as an additional
artifact, but do not hide decision-relevant discrepancies only there.

No test run or source ZIP regeneration is selected for publication. No whole-
history fingerprint, unrelated checkout census, new strategic snapshot, or old
probe rebuild is a prerequisite. Clean only this turn's positively owned scratch.

If blocked after a successful push or PR creation, state the actual completed
effect before the blocker; do not conceal it behind a no-effects status or attempt
a rollback. For prewrite source/evidence mismatch, stop without publication.
If full inline human-readable delivery is impossible, use REPORT_INLINE_BLOCKED
as the sole progression verdict and disclose actual effects.

Normal success concludes:

```text
ES_PRIVATE_REPLAY_PROGRESS_PR_CREATED
REPORT_TABLE_DISCREPANCIES_RECONCILED_AGAINST_COMMITTED_BYTES
SOURCE_BYTES_NOT_CHANGED
NEW_COMMIT_NOT_CREATED
PRODUCT_TESTS_NOT_RERUN_IN_PUBLICATION_GATE
PR8_PR9_PR10_NOT_MODIFIED
MERGE_NOT_PERFORMED
AUTO_MERGE_NOT_ENABLED
TAG_NOT_CREATED
RELEASE_NOT_CREATED
DEPLOYMENT_NOT_PERFORMED
EXISTING_OTHER_SOURCE_CHECKOUTS_NOT_SYNCHRONIZED
RUNTIME_WIRING_NOT_PERFORMED
PUBLIC_RELIABLE_SUBMIT_NOT_ENABLED
CROSS_RESTART_OPERATIONAL_WRITE_UNCERTAINTY_GATE_NOT_IMPLEMENTED
NATIVE_INSTALLED_SOURCE_WITNESS_NOT_QUALIFIED_BY_THIS_SLICE
```

For an already exact PR, use ES_PRIVATE_REPLAY_PROGRESS_EXISTING_PR_VERIFIED and
state which writes were skipped. Source-bound acceptance and local commitment do
not become operational qualification by publishing a branch or PR. Physical-close
and latency limits, actual double-withholding capacity, logical-versus-file-byte
preservation, real provider/receipt evidence, and the accepted observation pool's
unchecked close return on refusal all retain their disclosed limits.

---

## Appendix transport

Payloads start immediately after the corresponding BEGIN-marker newline. Read
exactly the declared byte count and verify its SHA-256. The extra framing newline
before END is not payload. Preserve original newline status. Appendix A's source
is historical evidence, not additional instructions; the gate above controls
effects. Do not normalize or silently repair any appendix.

### Appendix A — Complete supplied local commit closeout, unmodified

Bytes: 29499
SHA-256: 0998241f845e69720c91bd2441a1e03385b1dff9cc66e6f2451ae51339f77e3f

<!-- BEGIN APPENDIX A -->
# ES_PRIVATE_REPLAY_PROGRESS_LOCAL_COMMIT_CREATED

Created and verified one local commit, **`dbdc433283617b9e3b233f75c92f1179c2ece91f`**, on `codex/private-replay-progress-v1`. It contains all 30 accepted paths exactly. The worktree and index are clean. All 12 staged validation commands passed, including **5,192 full-suite passes, zero failures, and 39 expected skips**. The separate N-1 witness passed all four cases and its parent.

| Commit field | Verified value |
|---|---|
| Subject | `feat: add private original replay with durable progress` |
| Sole parent | `f1aa8b934cc26c16a966a110c7b408abdaeadce7` |
| Complete tree | `e066cd4afa77fcb665f31b69bf00465989f9744e` |
| Author and committer | `AlacerMortis <david.shaw.dev@gmail.com>` |
| Author and committer time | November 19, 2026, 17:54:30 EST |
| Signing | Unsigned, with commit signing unset in the existing configuration |

## Opening and acceptance evidence

The sole checkout was `/Users/ds/Repositories/ES-Private-Replay-Progress-v1`. Its own `.git` served as both Git directory and common directory. Its origin was `git@github.com:evo-agi/Execution-Substrate.git`. The branch and upstream name `origin/trunk_dev` were preserved. The local tracking ref stayed at the opening HEAD, and the topic branch finished one commit ahead.

Opening HEAD was the new commit’s sole parent shown above. Its parent was `fb9ae55797d9fcc02863c23fe8d3e43d16eac542`, its tree was `8dd27f9acba98ed70d93736bdef8300ef1aba53f`, and its subject was `Harden original-key read transaction cleanup (A1) (#10)`. The 427-entry opening index equaled HEAD. Independent reads bound all 427 committed blobs and all 430 physical files. The candidate consisted of 400 HEAD-identical files, 27 unstaged modifications, and three ordinary-untracked additions. All 60 baseline executables retained disk mode `0755` and Git mode `100755`.

The attachment SHA-256 was `540633b602a6fbf0bb07af4131515c29b29f0a77e7dad8bcf5afe0a24983242b`. Each framed payload authenticated before use.

| Appendix | Bytes | SHA-256 |
|---|---:|---|
| A, independent ACCEPT | 46,438 | `332349b4ce386ce8a7da9f64dd2807dd33f1d259cf287fccd49eaf286af11f28` |
| B, accepted manifest | 6,813 | `f92b57f48a701a606e8a0697b75dac8f691e3eb44c13b9c92afb894ec6e1d718` |
| C, unchanged v2 recipe | 7,275 | `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` |
| D, external bridge | 789 | `14f0e9e92a37e1d1bf624f1f052a62a6d56e5b82f988698abbf6e1b5bcf9196d` |
| E, external witness | 5,897 | `8da31dd61c9af2537c15f4376a330d05cb2e55dd2efd0ea610472a0c6ffa5c6a` |

The unchanged recipe ran twice from the exact checkout using pinned Python `-B`, into separate absent `opening-a.json` and `opening-b.json` files. Both exited 0 and reproduced Appendix B byte for byte. Each stdout SHA-256 was `9b829ba8118a6d13d27630e70c4037cae1d724401891c3f9237e609327cfced1`, with empty stderr.

I authenticated 108 acceptance artifacts and 1,376 probe-material and binding records at opening, before staging, before commit, and at closeout. The checked subset included both manifest pairs, source and closeout proofs, eleven historical argv/cwd/exit records, raw stdout and stderr, identity multisets, skip reasons, immediate guards, host preflight, both probe source/build bindings, and the external N-1 view and build records. The principal acceptance anchors were:

| Prior acceptance record | SHA-256 |
|---|---|
| `artifact-index.json` | `7847cde1799ec2166cf599fb73ad726ab056b82bb128dd6b695f107f1e858205` |
| `closing-a.json`, `closing-b.json` | `f92b57f48a701a606e8a0697b75dac8f691e3eb44c13b9c92afb894ec6e1d718` |
| `closing-guard.json` | `a670d3738e2ea00f911233948d0c08daed3b76073bbc80a95b2df01e5f205ede` |
| `fresh-reconciliation.json` | `d49c9d3d551e6e1608a07ff7a10295eb9d4d3b9c4396635e5d70da472451f813` |
| `retained-reconciliation.json` | `effd722966ad2e22d130e6c30329e2029800d1737747758ae94d9bb2fdd22b9e` |
| `n1-build-reconciliation.json` | `4af8b5c1497b41f3eee8ba0e0084b8eb66118cf6424b7682b8d3dbc6c8e7f9f0` |
| `gate-10/stdout`, historical full suite | `5e9c8153bd96d3eaf4a35caf89fd29b601620686d86a0306eb4deb38ef1277eb` |
| `gate-11/stdout`, historical N-1 | `1cef79c15b80c7cf5c56ac1e11598cd30bc4af83291625ec83927ebf9ba65b2a` |

The accepted review ZIP authenticated at 955,015 bytes and SHA-256 `3b27c483036296304a9fbca77dcd5fe522dee64b8eabf392057b6c573160f59a`. All 47 regular members and 46 inventory rows authenticated. The embedded manifest, recipe, and 30 source payloads matched the supplied and live bytes. [Accepted review ZIP](/Users/ds/Repositories/ES-Private-Replay-Progress-M1-Owner-Repair-20261119-jdpA1kZE/ES-Private-Replay-Progress-M1-Owner-Repair-Review.zip)

## Exact staging and committed bindings

The pinned Git ran `--literal-pathspecs add -- PATH` once for each row below, in order, from the target checkout. All 30 exited 0. The transition was **27 unstaged modifications + 3 ordinary-untracked files → 27 staged modifications + 3 staged additions**. `git write-tree` froze the complete 430-entry tree before validation.

- Full staged and committed diff SHA-256 was `1b1d1486ee301898835c059306bf81c4a4d167b99b1320a0b9a428c2a81d98e4`.
- The exact 27-path tracked subset of each diff reproduced `793e6697cf2342ce41f08ed8f59a0a14eb5c288c74780f158731d55dbe17bcca`.
- Opening index SHA-256 was `1c6218366e333383b205833fce0ceaa5d462fa7264cf51cbdcd35aa05855b018`. Staged and closing index SHA-256 was `eceb865ee65dcbff43da6d75ec659a74e557f4617b171590f967b3969780328f`. Local config SHA-256 was `4c98ee1729d2d3321c357ec922f6dafc19b6ac167a8a24ed636d359ab6642485` throughout.

Table path prefixes `L`, `A`, and `I` expand under `/Users/ds/Repositories/ES-Private-Replay-Progress-v1` to `.docs/execution_lifecycle`, `es/admission`, and `es/admission/internal/reliablesubmit` respectively. Every row was regular `0644` on disk and `100644` in Git. The staged and committed blobs were read independently and compared byte for byte. The other 400 entries retained the parent’s object IDs and modes.

| Path | Delta | Bytes | Accepted, staged, committed SHA-256 | Staged and committed blob |
|---|:---:|---:|---|---|
| `L/es_execution_admission_model.md` | M | 88702 | `bedc87c611b5c9340ffaafb0866f028dc9daf2f22552efec47491f1b4ae713f2` | `0f5c56cdbf11b80158f29700a31fef5dc20f335f` |
| `L/reliable_submit_persistence_and_concurrency.md` | M | 161666 | `34e06ff10148d67a49000868499294873c732279d7f399a5f2cb910b0c12f40e` | `772fb7dbd4bfb1d8162b87b0d66c0803957cbdd9` |
| `L/submit_idempotency_correlation_and_recovery.md` | M | 103025 | `1b03cc40b48861c7220a7b85d20b1f8d232690f17460e3eee0df33af4659e3f3` | `94fe56e0cdea71acf29c2df1074bcd4048c0bc0b` |
| `PLANS.md` | M | 302636 | `c4fdbfb4acd3c2a27f679f6575798c4553e94110c4aa7177f590e90fe89c5e31` | `b74440dc7d3ef2e488d92a7fb9f6f64d7cecdcee` |
| `docs_contract_test.go` | M | 799914 | `dd433f02e783aa265d775bd411c95433e369642e2aafbdb32c72b75f78b4ebff` | `e69ada92d1e723e1b70f03e5191e96145e687713` |
| `I/durable_operation.go` | M | 9548 | `b7761f001a1f67349ed51f2b79012194a7d45bb19c79e0ca2c0c22b8227320f9` | `94a7d56b5f8ef5501f92abf7cb0c7732a490859d` |
| `I/durable_record.go` | M | 25226 | `999db7db6550c5031b023a9613825504e30e971a179298cc43e09cf8c5c5d7cd` | `41e2dc127cd0a56163a9f9c42992e3e2dad9643b` |
| `I/durable_service.go` | M | 49972 | `ef0bc6f4d125f3986c46901cbe05bc2cb447af7dfbf51afe993a59c2afaf7971` | `25ef96d035c6be87209d81c7b831a366f47d6e94` |
| `I/guardrails_test.go` | M | 32231 | `9a300f0553fd6ac3003a048a7309060a4ec6f618eacd94139bd4bb29c011bc60` | `ebadc607372c586f1681d6290037cac50b0167fe` |
| `I/replay_custody_file.go` | M | 50461 | `61c4006e1e4a3feb7c0ec0e7d4685dc2c3fe8c1e2165d1529d2c86ae8fa137b5` | `b1bc86218f53653d04eda1840ced29c8688ce098` |
| `I/replay_custody_file_test.go` | M | 69995 | `207d9f17658cd50f6c4bea8e293b12abd89455a174b2d96bac84742a66b0afdf` | `d5b0f305b3809520f79c4ef1f9ab206292be7578` |
| `I/replay_custody_format.go` | M | 16488 | `b8cb8e31edd9d854317a0d6a456f25d5ab1838498623881e429dec2155e1ea67` | `134c37fff7318ccc356a0ce34ced924eb16b95a1` |
| `I/replay_custody_structure.go` | M | 18640 | `4916268757b93d409cbc13ba9c0da14e009499b4db7cadd52bc7ccd47c6a86ad` | `f1aed2819f38138264e5691432f849079252a3bb` |
| `I/replay_progress_test.go` | A | 61314 | `0952fff321daa368dee1d32ed39a2a5b417e7d2779ae4e1015ab3c12b1021048` | `f055ead2af265d3ac5d28c4c6a6698f46449a389` |
| `I/sqlite_migrations.go` | M | 17407 | `7736e30a1d0c6e9584d9050cc6ebf8bfaf900d424f764ebe61af8ec8ddaec0c9` | `7814a04f4962fbdb8cec4a1d3a24201ea10f9bca` |
| `I/sqlite_physical_test.go` | M | 14539 | `2c125b6373f83467d542db45473cc79b888ed3a665e65ef6bf013655f461a7ba` | `620899f647432e48789bee7df219b5689ef417c7` |
| `I/sqlite_pooled_claim_read_cleanup_test.go` | A | 8912 | `0ec3060ed3c30a6327ec49b0291d5c761c20894986c9b6b1e1be384694312823` | `4aa80cca7b7c3d3011dd277aaaeda4f59b02011a` |
| `I/sqlite_replay_claim.go` | M | 8301 | `8ddec89b4ca5702591bdf2060062016d7fb54264fc7df57af5ead1d161eb9de3` | `4f4ce954febca494bada72ebc2e5f95bc43af2fb` |
| `I/sqlite_replay_migration_test.go` | M | 28903 | `e0765e59cb00ace73e8a88c92b9d7e830b39766792120845220b2fd407d357fa` | `8191f490886cef673e1ce98dc30dc982e69d3e61` |
| `I/sqlite_replay_progress_schema.go` | A | 30612 | `132d8ab87f5658cab3477b9f6913538013ba922d4768192a96be960df7bbb149` | `1317d92ba935f9cd1b9532ca0807a5c9cf05282c` |
| `I/sqlite_replay_shape.go` | M | 2751 | `29cdbba2e5b1fee069989f6e6423dccc1c69c843de22b6504f68a7d199b317be` | `b4b5f18f5686a912cf02f9164cc2e27ff6ffa59a` |
| `I/sqlite_replay_shape_test.go` | M | 8815 | `3552ea5fafbc59e43cc21b1007486e98da4d59b6d0ea98db92646e0c8478adfb` | `3f938be010268b950351c0ec72922e2379a297d2` |
| `I/sqlite_store.go` | M | 63299 | `e448d265516aae1d7efd2c06170d8cfa2cc8c0258f82dfc15a3279e65efad4c1` | `97a9d8f5c8b74a1c7d05812a0d6f80073d613dd4` |
| `I/sqlite_store_test.go` | M | 57339 | `c99e7659b1059431911557ba43ef7fa982e373bba939f610bd41ea0622cee96f` | `ee2f8c5b6255d3ba4990fc23c2b393bda85e0d77` |
| `A/reliable_submit_guardrails_test.go` | M | 50991 | `32de42b7bf8974e36c014d3d9ce6d24e0994fbbc03bb1587c4fddd32c80f6e` | `56ee45b1a99e453a96bcbce21095ccd894deb26f` |
| `A/reliable_submit_replay_format.go` | M | 17326 | `0a21803b03308332613481f89ce4b595512b31b073c56b31fe7d8000519c3beb` | `533877eea3ef937d8d7c77c85e2ac160a43af790` |
| `A/reliable_submit_replay_hydration.go` | M | 28800 | `b5ff16b96178c45b53165ebb2bcbdc67991bb145276ca4a11a598f1430745b9c` | `97f3eec0f78b20a7afc4b1f6e53df55c5911ee6c` |
| `A/reliable_submit_replay_private.go` | M | 20440 | `d17927a23a57c808a8f0ebc4bad3e9912e42d7da497033637102bae2c45fd278` | `ace0e7c6a7e35c8e8385e49008e06a567a17b5cd` |
| `A/reliable_submit_replay_private_test.go` | M | 45171 | `4e4e7c7fad2ed2b88b35801841044f4b1f049a4cb6d0435499bb87699467e9f2` | `e45e87ec5fa7abbaccd1d365cab1d642d8f6c44b` |
| `A/workstream_c_guardrails_test.go` | M | 297009 | `68f2fe4e31e5d862be161c3ba1071a511935b32e90cf9021755fe4dcb045fab5` | `59bac2e2b3f3214dbaaf6c080d6356df9d84e31c` |

## Host, policy, and fixtures

Preflight matched the accepted Darwin arm64 executables. The repository used its configured identity. The resolved hooks directory held only inactive sample hooks. Applicable source attributes were empty, fsmonitor was unset, and signing policy was unchanged.

| Tool | Verified executable and version | SHA-256 |
|---|---|---|
| Go | `/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go`, 1.26.5 darwin/arm64 | `3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19` |
| gofmt | `gofmt` beside the pinned Go binary | `3b87c876b1255feb8ecc539afff2eadd9dcc76e0e34657bdab6d32fd03329f81` |
| Python | `/Library/Frameworks/Python.framework/Versions/3.13/bin/python3` → sibling `python3.13`, 3.13.4 with `tomllib` | `f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b` |
| OpenSSL | `/opt/homebrew/Cellar/openssl@3/3.6.2/bin/openssl`, 3.6.2 | `bf63843e6856e1994ca71092ff3b46834236eb2144dd9b6ceb85d511128b836e` |
| Git | `/opt/homebrew/Cellar/git/2.49.0/bin/git`, 2.49.0 | `03d4a6c5328d4a1ce84eba2765664284b1fb2414d9e657358733056a89a95954` |

`GATE_ROOT` was `/Users/ds/Repositories/ES-Private-Replay-Progress-Commit-Gate-20261119-U0JC7ELW`, owned by uid 501, device 16777231, inode 214786937. The safe environment record, SHA-256 `d007e2abbd016b1748107ef3a089a49940d962451169c3c22914612a0e8c5b91`, bound these settings:

```text
PATH=/Library/Frameworks/Python.framework/Versions/3.13/bin:/opt/homebrew/Cellar/openssl@3/3.6.2/bin:/opt/homebrew/Cellar/git/2.49.0/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin
LC_ALL=C  LANG=C
GOTOOLCHAIN=local  GOPROXY=off  GOSUMDB=off  GOWORK=off
GOFLAGS=-mod=readonly  GOENV=off  CGO_ENABLED=0  GOTELEMETRY=off
GOMODCACHE=/Users/ds/go/pkg/mod
GIT_OPTIONAL_LOCKS=0  GIT_NO_LAZY_FETCH=1  GIT_TERMINAL_PROMPT=0  GIT_PAGER=cat
PYTHONDONTWRITEBYTECODE=1
GOCACHE=$GATE_ROOT/cache  GOTMPDIR=$GATE_ROOT/gotmp  TMPDIR=$GATE_ROOT/tmp
ES_REPLAY_PB1_PROBE=$GATE_ROOT/historical-pb1.test
ES_REPLAY_SCHEMA3_PROBE=$GATE_ROOT/previous-schema3.test
```

Python ran with `-B`. The outer umask was `077`, and test subprocesses used `027`. The PB1 copy was 14,350,930 bytes at SHA-256 `b205a31bac091cbcf5b3f4826bc359455625316908051131733622813e34adcf`. The previous schema-3 copy was 15,601,186 bytes at `42614a50812a65ba52b53488d872884e59ce7b4f57dece6a66642d4eb8de1409`. Its source and build-input inventory bound to `50a81fa5a042e135abfc9f6bad68d20abc4575f881945ecc84252c14910dde8f`. The maintained tests set distinct child target bindings and verified PB1 schema 2 refusing schema 3 and the previous schema-3 opener refusing schema 4.

Tests used the authorized synthetic SQLite fixtures, synthetic keys and certificates, helper processes, loopback mocks, and test-owned temporary paths and Git fixtures. Before gates 9–11, `/usr/local/bin/docker context inspect --format '{{.Endpoints.docker.Host}}'` exited 0 and selected `unix:///Users/ds/.docker/run/docker.sock`. `/usr/local/bin/docker info --format '{{.ServerVersion}}'` exited 1 with `Cannot connect to the Docker daemon`. The direct `/var/run/docker.sock` capability was absent. Both commands in each pair ran from the checkout and received fresh immediate guards. Context and daemon guard times were `17:46:09.272985` / `17:46:09.867702`, `17:46:14.353869` / `17:46:14.680895`, and `17:48:24.358596` / `17:48:24.693191` EST.

Two gate harness failures were retained. The first opening attempt expected both historical binaries in one material list. The correction resolved the omitted schema-3 binary through authenticated indexes. The first validation launch mistook the retained `gate-initial.py` for a gate result and stopped before launching any primary command. Each actual primary command ran once.

## Fresh validation

Commands 1–11 ran from `/Users/ds/Repositories/ES-Private-Replay-Progress-v1`. Command 12 and the supplemental `go list` ran from `/Users/ds/Repositories/ES-Private-Replay-Progress-Commit-Gate-20261119-U0JC7ELW/n1-source`. The following reproduces the argv in order. Comments mark gate numbers.

```sh
GO=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go
GOFMT=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/gofmt
GIT=/opt/homebrew/Cellar/git/2.49.0/bin/git
I=es/admission/internal/reliablesubmit
A=es/admission

# 1–4
"$GO" version
"$GOFMT" -d docs_contract_test.go "$I/sqlite_store.go" "$I/sqlite_replay_claim.go" \
  "$I/sqlite_migrations.go" "$I/sqlite_replay_progress_schema.go" "$I/sqlite_replay_shape.go" \
  "$I/durable_record.go" "$I/durable_operation.go" "$I/durable_service.go" \
  "$I/replay_custody_format.go" "$I/replay_custody_structure.go" "$I/replay_custody_file.go" \
  "$A/reliable_submit_replay_format.go" "$A/reliable_submit_replay_hydration.go" \
  "$A/reliable_submit_replay_private.go" "$I/sqlite_pooled_claim_read_cleanup_test.go" \
  "$I/replay_progress_test.go" "$I/replay_custody_file_test.go" "$I/sqlite_store_test.go" \
  "$I/sqlite_physical_test.go" "$I/sqlite_replay_migration_test.go" \
  "$I/sqlite_replay_shape_test.go" "$I/guardrails_test.go" "$A/reliable_submit_guardrails_test.go" \
  "$A/reliable_submit_replay_private_test.go" "$A/workstream_c_guardrails_test.go"
"$GIT" --no-pager diff --check
"$GIT" --no-pager diff --cached --check

# 5–8
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateReplayProgressSynchronizationInventoryDocsContract|TestPrivateOriginalReplayProgressContractSelection|TestReliableSubmitPersistenceAndConcurrencyADRDocsContract|TestSubmitIdempotencyCorrelationAndRecoveryDocsContract|TestReliableSubmitPureModelDocsAndSourceContract|TestReliableSubmitPublicOptInAndVersioningDocsContract|TestReliableSubmitContractAdapterFoundationDocsAndSourceContract|TestReliableSubmitBindingProducerDocsContract|TestIntegratedAcceptanceGateDocumentationIsConsistent|TestIntegratedCandidateStatusSeparatesCAndT)$' .
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestSQLitePooledClaimReadCleanup$' ./es/admission/internal/reliablesubmit
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestSQLiteMigrationPrecommitClosedWrapperRecovery|TestPrivateReplayProgressConfirmationEligibility|TestPrivateReplayProgressReconciliationEligibility|TestPrivateReplayProgressTerminalEvidenceBinding|TestSQLiteMigrationOpeningRevalidatedUnderLock|TestSQLiteLiteralInternalNamespaceQualification|TestPrivateReplayScope1PublicationPreflight|TestPrivateReplaySharedObjectAllocation|TestReplayPublicationFaultAndIdentity|TestPrivateReplayProgressFormatVectors|TestPrivateReplayProgressTransitions|TestPrivateReplayProgressConcurrencyAndCommitOutcome|TestSQLiteV4MigrationPreservesFullState|TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation|TestSQLiteV3OldBinaryRefusesWithoutMutation|TestSQLiteLegacyCASConnectionCleanup|TestReplayOriginalKeyReadCleanup|TestReplayOriginalKeyReadCallerRefusal|TestReplayGrantC1PreCommitConnectionQuarantine|TestReplayGrantD1BeginResponseLossQuarantine|TestReplayKeyStateD1BeginResponseLossQuarantine|TestReliableSubmitPrivatePersistenceStaticGuardrails)$' ./es/admission/internal/reliablesubmit
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestExecutionSubstrateProductionHasNoA3LeaseRegistryOrPoisonDesign|TestExecutionSubstrateSynchronizedMutableStateReferenceInventoryIsExact|TestPrivateReplayProgressOccupiedDisposition|TestPrivateReplayProgressAdmissionReplay|TestPrivateReplayProgressHasNoEffectPaths|TestReliableSubmitFoundationHasNoRuntimeWiring|TestReliableSubmitBindingProducerHasNoProductionCaller|TestPrepareRequestShapeRemainsLegacyAndUnkeyed|TestResolvedSubmitLegacyEquivalenceOneNomadRegistrationAndAuthorityRecovery)$' ./es/admission

# 9–11
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestWorkstreamCContractPrepareAndSubmitRemainSeparatedAtAPIBoundary|TestSubmitPublicRouteRejectsStructuralReliableBody)$' ./es/api ./es/app
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=600s ./es/admission/internal/reliablesubmit ./es/admission ./es/api ./es/app
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=600s ./...

# 12 and supplemental inspection, both in N1_SOURCE
"$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestPrivateReplayProgressAdmissionUnknownNoEffects$' ./es/admission
"$GO" list -mod=readonly -deps -test -json ./es/admission
```

Every command received a new immediate guard over 430 actual working files and index blobs, the frozen tree, scoped Git state, and all path inventories. Each staged observation produced SHA-256 `d8605f260d8fdb25c81a6af8b9b00e99fdb1b60159a3f4660575cfac869b0c57`. The distinct observation times below are EST. All stderr and the three empty stdout streams had SHA-256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

| Gate | Exit | Test pass/fail/skip | Packages tested/no tests | Immediate guard time | Stdout SHA-256 |
|---|---:|---:|---:|---|---|
| 1 Go version | 0 | — | — | `17:45:08.665699` | `278375c8a03c34bb0f855154850de7c4f217fd3b8cdf37986819e3f05d0a4c33` |
| 2 Formatting | 0 | — | — | `17:45:09.020364` | empty |
| 3 Unstaged whitespace | 0 | — | — | `17:45:09.340478` | empty |
| 4 Staged whitespace | 0 | — | — | `17:45:09.684398` | empty |
| 5 Owner contracts | 0 | 27/0/0 | 1/0 | `17:45:19.907556` | `5ac1ecbd7a1b525a8475a2f014f631085507ac64ae10e5a1e76a19add0b3361c` |
| 6 Pooled reader | 0 | 16/0/0 | 1/0 | `17:45:31.305706` | `9421c25cb74e742593660e58403bf176802662e65e41453b0071e40fb2794aa6` |
| 7 Internal and historical probes | 0 | 221/0/0 | 1/0 | `17:45:45.342020` | `4fb8e14ec55d7b29aacf7efe3eff8d94aa33431ce0ccf064728fba56471406cb` |
| 8 Admission and typed inventories | 0 | 26/0/0 | 1/0 | `17:46:08.920378` | `327eca717ba8639d0bb17bfe6d684f7c3c056b8db589b8ebfaaefd5ab57b5886` |
| 9 API/App boundaries | 0 | 2/0/0 | 2/0 | `17:46:14.046586` | `fb9cbbae16c9f098859cf2e59fba32194d15b1f56e7b69fdc440ae606dba0798` |
| 10 Four-package suite | 0 | 2062/0/39 | 4/0 | `17:48:24.035863` | `31290f482b5fcc2b097ae047aca58672bcd4eaecb414da205a1b82def057fc16` |
| 11 Full repository | 0 | 5192/0/39 | 21/20 | `17:54:12.188026` | `885155c9716b250f2a74994dc3ed942fd0b1ea1343e26355fafe94fa0709c5ff` |
| 12 External N-1 | 0 | 5/0/0 | 1/0 | `17:54:14.886886` | `257523ccb6e49a30aa83f20ffa853cfd54e91f03c8d249ce1ac78426066d70dd` |
| Supplemental build inputs | 0 | — | 291 records | `17:54:15.465215` | `eed496c9b25f6d93ed8c8b0c8e25633d8efaeb5581b0ca47cd7974f9180ff3d9` |

The fresh test and package identity multisets matched the independent audit. All selector parents ran. Gate 10 was the exact four-package projection of gate 11. The full suite passed `TestResolvedPlanDocumentationTruthAndFiniteInventoriesContract`. The allocator parent passed and recorded helper readiness, the winning outcome, and reaping. Gate 7 passed all 12 pre-COMMIT leaves with zero COMMIT attempts. The historical red and green records remained historical. No selected validation was left unrun.

The 39 skip identities and reason groups were:

- **Two direct helper sentinels.** `TestPrivateReplayObjectAllocatorHelperProcess` reported `allocator helper control, executed by TestPrivateReplaySharedObjectAllocation`. `TestSQLiteClaimStoreLockHelperProcess` reported `helper process only`.
- **One native App witness.** `TestSubmitFlowMountsGovernedArtifactAndLifecycleWithInstalledSourceIdentity` reported `mounted-source native witness not qualified by this test: direct Docker Unix socket unavailable`.
- **Two App daemon prerequisites with specialized messages.** `TestBringupScriptUpCheckDownFullProfile` reported `slice 0 bringup requires a reachable docker daemon: exit status 1 output=Client:`. `TestWorkloadCanCreateAndUseLocalRuntimeIdentityEndpointFromTmpfsWorkspace` reported the healthy Docker daemon prerequisite and the same exit-1 probe failure.
- **Thirty-four App daemon-probe skips.** These reported `docker daemon probe failed: exit status 1 output=Client:`, with retained output identifying the unavailable daemon. The exact identities were:

```text
TestControlPlaneStaticScriptAPIPathCancelSucceeds
TestControlPlaneStaticScriptAPIPathFetchesRetainedResultBundle
TestDiagnosticsScriptRunIDBundleCollectsLifecycleSignalsAndStaging
TestExecuteLoopScriptFailureSummary
TestExecuteLoopScriptSuccessAndDeterministicDigests
TestExecutionCancelRetainsStageRootForDebugging
TestExecutionCancelStopsNomadJob
TestExecutionLogsReturnConflictWhenAllocationNotReady
TestExecutionLogsReturnRealContainerOutput
TestExecutionLoopScriptSuccessRetainsDistinctStageRootsAcrossRepeatedRuns
TestExecutionResultBundleAndStageRetainedAcrossStatusAndRepeatFetch
TestExecutionResultReturns404ForTerminalExecutionWithoutResultOutput
TestExecutionStatusReflectsFailedAllocation
TestExecutionStatusReflectsNomadJobState
TestExecutionStatusRetainsFailedStageRootForDebugging
TestExecutionStatusRetainsSuccessfulStageRootAndLogsStillWork
TestExecutionStatusReturns503WhenNomadUnavailable
TestLifecycleScriptCategorizesExecutionFailure
TestLifecycleScriptObservesExecutionViaPublicRunID
TestRuntimeIdentityIntegrationCapabilityProbe
TestSubmitFlowAllowsConfiguredControlPlaneCallerHandoff
TestSubmitFlowDoesNotStartWorkloadBeforeHelperReadiness
TestSubmitFlowHelperDeathIsTaskFatal
TestSubmitFlowInjectsWorkloadIdentityEndpointAndLifecycleStillWorks
TestSubmitFlowMountsGovernedArtifactAndLifecycleStillWorks
TestSubmitFlowProvidesPlatformOwnedRuntimeIdentityThroughBoundedEndpoint
TestSubmitFlowRejectsRuntimeIdentityPassthroughRequests
TestSubmitFlowRejectsWorkloadArchiveWithSymlinkEntry
TestSubmitFlowRemovesRuntimeMountArchiveResidueAfterExtraction
TestSubmitFlowRunsStaticScriptInNomadDocker
TestSubmitFlowUsesBridgeNetworkWhenNetworkAccessEnabled
TestSubmitFlowUsesConfiguredRuntimeIdentityTmpfsSize
TestSubmitFlowUsesPlatformOwnedIdentityForVaultLoginAndSecretRead
TestSubmitValidOperatorCallerReturnsAcceptedSubmissionReceipt
```

## External N-1 witness

The new view was exported from all 430 actual staged blobs. It added only `I/admission_unknown_witness_bridge.go` and `A/reliable_submit_admission_unknown_witness_test.go` from Appendices D and E. All 432 files matched the view map at SHA-256 `05f6d69aa56210c33ccf6c998502345426ff5e0817365ada213a2a61af1afe53` before and after both external commands. The two witness files remained external throughout staging and commit. Their five test identities were disjoint from the ordinary suite.

| Case | Invocation disposition | Projected revision | Later current revision |
|---|---|---:|---:|
| Establish, canceled recovery | `WriteUnknown` | none | 1 |
| Establish, exact authenticated recovery | `OwnCommitConfirmed` | 1 | 1 |
| AssignRun, canceled recovery | `WriteUnknown` | none | 2 |
| AssignRun, exact authenticated recovery | `OwnCommitConfirmed` | 2 | 2 |

Each case observed one real intended COMMIT, restored the hook before the later read, retained the original, and measured zero provider, staging, and EGS contacts with empty operational roots. The later current reads preserved the original invocation dispositions.

The supplemental inspection reconciled 291 package records and 2,801 physical inputs: 2,289 toolchain, 375 module-cache, 136 view, and one generated cache input. Path translation covered the declared view and cache prefixes only. The bridge appeared in the internal package’s compiled source list, and its internal dependency tests appeared as metadata. The actual generated test main was retained at 57,754 bytes and SHA-256 `07a228ee0649b9846a21c3293b2171364db3ced5d64e10020f9cb317122877b4`. The fresh normalized graph SHA-256 was `302b8f6eefe9e7a6cf85aad97fb5ee41a761194ceb3af93f01eb5a497e01a4ba`.

## Commit closeout and limits

The single command `/opt/homebrew/Cellar/git/2.49.0/bin/git commit -m 'feat: add private original replay with durable progress'` ran from the target checkout and exited 0. Its stdout SHA-256 was `5cfee29829820db00c6505d0211ea55bd76e31ad70e788690fae4f8365c62a3e`, with empty stderr. The independently read commit object had the exact subject, sole parent, and frozen tree. The commit range contains exactly one new commit. The full committed diff equaled the frozen staged diff byte for byte, and the parent delta contained exactly 27 modifications and three additions. HEAD, the complete index, and all 430 working files agreed. The staged, unstaged, unmerged, ordinary-untracked, and ignored inventories were empty. The closing guard authenticated to `380b3092685c8e99081417ce0fc96c9ba96d1bf8ece5a3d6c3438a73bb2eb507`.

The gate preserved the selected `synthetic_progress_nonoperational_v1` scope, M-1 and DOC-SYNC closure, earlier repairs, and the existing ES, SQLite, custody, and Coordinator ownership boundaries. Qualification remains limited to private synthetic fixture evidence. Physical-close success, hard timing, double-withholding capacity, SQLite file and sidecar byte preservation, real provider and receipt claims, native and operational qualification, cross-restart write-uncertainty authority, and remote publication or CI eligibility remain outside the result. The observation pool’s unchecked close return on refusal remains part of the accepted bytes.

Cleanup removed only `cache`, `gotmp`, and `tmp` under the gate root. Both copied probes were returned to `0600`. The external source view retained source modes, private directories are `0700`, and retained evidence is `0600`. The artifact index lists 252 private files, including the report, and 432 source-view files. It excludes itself.

- Private report SHA-256 `e1813a68c168c18879ef7e369c64638835aca4c05805f2141fae36d6e76a6999`. [Private report](/Users/ds/Repositories/ES-Private-Replay-Progress-Commit-Gate-20261119-U0JC7ELW/report.md)
- Self-excluding index SHA-256 `858d4b7208532dd2d1c45a847c207d9236f09624a958a48251e81d3c21d3a153`. [Artifact index](/Users/ds/Repositories/ES-Private-Replay-Progress-Commit-Gate-20261119-U0JC7ELW/artifact-index.json)

```text
ES_PRIVATE_REPLAY_PROGRESS_LOCAL_COMMIT_CREATED
SOURCE_BYTES_NOT_CHANGED_BY_COMMIT_GATE
THIRTY_ACCEPTED_PATHS_COMMITTED_EXACTLY
PUSH_NOT_PERFORMED
REMOTE_TOPIC_NOT_CREATED_BY_THIS_GATE
PRS_NOT_CREATED_OR_MODIFIED
MERGE_NOT_PERFORMED
AUTO_MERGE_NOT_ENABLED
EXISTING_SOURCE_CHECKOUTS_NOT_SYNCHRONIZED
RUNTIME_WIRING_NOT_PERFORMED
PUBLIC_RELIABLE_SUBMIT_NOT_ENABLED
CROSS_RESTART_OPERATIONAL_WRITE_UNCERTAINTY_GATE_NOT_IMPLEMENTED
NATIVE_INSTALLED_SOURCE_WITNESS_NOT_QUALIFIED_BY_THIS_SLICE
```
<!-- END APPENDIX A -->

### Appendix B — Exact accepted pre-stage canonical manifest

Bytes: 6813
SHA-256: f92b57f48a701a606e8a0697b75dac8f691e3eb44c13b9c92afb894ec6e1d718

<!-- BEGIN APPENDIX B -->
{"branch":"codex/private-replay-progress-v1","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/es_execution_admission_model.md","sha256":"bedc87c611b5c9340ffaafb0866f028dc9daf2f22552efec47491f1b4ae713f2","size":88702},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md","sha256":"34e06ff10148d67a49000868499294873c732279d7f399a5f2cb910b0c12f40e","size":161666},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md","sha256":"1b03cc40b48861c7220a7b85d20b1f8d232690f17460e3eee0df33af4659e3f3","size":103025},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"c4fdbfb4acd3c2a27f679f6575798c4553e94110c4aa7177f590e90fe89c5e31","size":302636},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"dd433f02e783aa265d775bd411c95433e369642e2aafbdb32c72b75f78b4ebff","size":799914},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_operation.go","sha256":"b7761f001a1f67349ed51f2b79012194a7d45bb19c79e0ca2c0c22b8227320f9","size":9548},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_record.go","sha256":"999db7db6550c5031b023a9613825504e30e971a179298cc43e09cf8c5c5d7cd","size":25226},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_service.go","sha256":"ef0bc6f4d125f3986c46901cbe05bc2cb447af7dfbf51cee4653d7ce696c0945","size":49972},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/guardrails_test.go","sha256":"9a300f0553fd6ac3003a048a7309060a4ec6f618eacd94139bd4bb29c011bc60","size":32231},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_file.go","sha256":"61c4006e1e4a3feb7c0ec0e7d4685dc2c3fe8c1e2165d1529d2c86ae8fa137b5","size":50461},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_file_test.go","sha256":"207d9f17658cd50f6c4bea8e293b12abd89455a174b2d96bac84742a66b0afdf","size":69995},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_format.go","sha256":"b8cb8e31edd9d854317a0d6a456f25d5ab1838498623881e429dec2155e1ea67","size":16488},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_structure.go","sha256":"4916268757b93d409cbc13ba9c0da14e009499b4db7cadd52bc7ccd47c6a86ad","size":18640},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_progress_test.go","sha256":"0952fff321daa368dee1d32ed39a2a5b417e7d2779ae4e1015ab3c12b1021048","size":61314},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_migrations.go","sha256":"7736e30a1d0c6e9584d9050cc6ebf8bfaf900d424f764ebe61af8ec8ddaec0c9","size":17407},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_physical_test.go","sha256":"2c125b6373f83467d542db45473cc79b888ed3a665e65ef6bf013655f461a7ba","size":14539},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_pooled_claim_read_cleanup_test.go","sha256":"0ec3060ed3c30a6327ec49b0291d5c761c20894986c9b6b1e1be384694312823","size":8912},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_claim.go","sha256":"8ddec89b4ca5702591bdf2060062016d7fb54264fc7df57af5ead1d161eb9de3","size":8301},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go","sha256":"e0765e59cb00ace73e8a88c92b9d7e830b39766792120845220b2fd407d357fa","size":28903},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_progress_schema.go","sha256":"132d8ab87f5658cab3477b9f6913538013ba922d4768192a96be960df7bbb149","size":30612},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_shape.go","sha256":"29cdbba2e5b1fee069989f6e6423dccc1c69c843de22b6504f68a7d199b317be","size":2751},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_shape_test.go","sha256":"3552ea5fafbc59e43cc21b1007486e98da4d59b6d0ea98db92646e0c8478adfb","size":8815},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_store.go","sha256":"e448d265516aae1d7efd2c06170d8cfa2cc8c0258f82dfc15a3279e65efad4c1","size":63299},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_store_test.go","sha256":"c99e7659b1059431911557ba43ef7fa982e373bba939f610bd41ea0622cee96f","size":57339},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_guardrails_test.go","sha256":"32de42b7bf8974e36c014d3d9ce6d24e0994fbbc03bb1587c4c4fddd32c80f6e","size":50991},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_format.go","sha256":"0a21803b03308332613481f89ce4b595512b31b073c56b31fe7d8000519c3beb","size":17326},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_hydration.go","sha256":"b5ff16b96178c45b53165ebb2bcbdc67991bb145276ca4a11a598f1430745b9c","size":28800},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_private.go","sha256":"d17927a23a57c808a8f0ebc4bad3e9912e42d7da497033637102bae2c45fd278","size":20440},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_private_test.go","sha256":"4e4e7c7fad2ed2b88b35801841044f4b1f049a4cb6d0435499bb87699467e9f2","size":45171},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/workstream_c_guardrails_test.go","sha256":"68f2fe4e31e5d862be161c3ba1071a511935b32e90cf9021755fe4dcb045fab5","size":297009}],"head":"f1aa8b934cc26c16a966a110c7b408abdaeadce7","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"793e6697cf2342ce41f08ed8f59a0a14eb5c288c74780f158731d55dbe17bcca","upstream":"origin/trunk_dev"}

<!-- END APPENDIX B -->

### Appendix C — Exact authorized PR body

Bytes: 5435
SHA-256: 34be5bf95108878f93e6963478d029728ce47beaf2140072ca6ca6aca48c3e99

<!-- BEGIN APPENDIX C -->
## Summary

Add private original replay with durable claim progress as one integrated, independently accepted source slice. The path is limited to `synthetic_progress_nonoperational_v1`: fixture-only, runtime-unwired, and effect-ineligible, including synthetic accepted and receipt states.

Schema 4 and codec 4 join authenticated original custody to the existing ES durable service in one SQLite authority domain. They preserve global caller/key occupation, one immutable original and physical row, one attempt, and one assigned run. Durable successors preserve the original descriptor and sealed object rather than resealing or reconstructing them from current defaults.

## Selected behavior and compatibility

- Preserve migration literals 1-3, authentic schema and ledger checks, historical codec-1/2 behavior, and immutable codec-3 `synthetic_nonoperational_v1`. The schema-2 PB1 probe and previous-schema-3 opener retain their separate schema-3 and schema-4 refusal purposes.
- Authenticate the actual migration opening state under the writer lock. Unconfirmed eligible migration cleanup routes through original-pool disposition and one checked nonmigrating observation; recovery performs no migration retry or second write. A qualified current head is an observation, not attribution to an unattempted COMMIT.
- Preserve exact original-key eligibility, one-use borrow lifetime, safe confirmation projection, shared object allocation, and permit-burn boundaries. SQLite owns committed claims, progress, keys and grant/use facts; custody owns private-object authentication.
- Preserve earlier reconciliation as history without making an ineligible new command a valid no-op. Synthetic terminal evidence binds outcome, attempt, fact and exact receipt association. It does not establish external provider acceptance.
- Preserve an invocation's own write disposition. Later authenticated reads or explicitly supplied fixture commands do not resolve an earlier unknown response. Failed winner disclosure preserves a definite occupied result without disclosing progress.
- Harden the pooled `loadClaim` prerequisite while leaving `loadClaimFresh` unchanged. Align the owner inventory with the existing private fixture synchronization fields without creating a new registry or runtime authority.

Public structural reliable-request refusal and ordinary unkeyed Submit remain unchanged. ES admission/runtime facts and Coordinator programme progression remain separate.

## Exact source

Source commit: `dbdc433283617b9e3b233f75c92f1179c2ece91f`  
Sole parent / selected base: `f1aa8b934cc26c16a966a110c7b408abdaeadce7`  
Complete source tree: `e066cd4afa77fcb665f31b69bf00465989f9744e`

The delta is exactly 30 files: 27 modifications and three additions. The complete tree contains 430 leaves; 400 are unchanged from the parent. The three added files are internal progress tests, pooled-reader cleanup tests, and the private schema-4 definition. No deletion, rename, type change, or executable-mode change is selected.

Accepted pre-stage manifest: `f92b57f48a701a606e8a0697b75dac8f691e3eb44c13b9c92afb894ec6e1d718`  
Complete committed-diff SHA-256: `1b1d1486ee301898835c059306bf81c4a4d167b99b1320a0b9a428c2a81d98e4`

## Acceptance and validation

Fresh independent audit returned ACCEPT for the complete thirty-path candidate, closing the remaining M-1 pre-COMMIT recovery and DOC-SYNC findings and preserving the other resolved findings. The exact local commit gate compared accepted, staged and committed blobs and complete trees without editing source.

All twelve staged commands passed. The ordinary full suite recorded **5,192 passes, zero failures and 39 skips**, with 21 tested packages and 20 packages without tests. All selected parents ran; the test identities matched the independent audit. The 39 skips remain two direct helper sentinels and 37 App capability cases, including the unavailable native installed-source witness. The allocator parent executed and verified its helper.

A separate source-bound admission diagnostic passed five identities covering four real-COMMIT/modeled-response-loss cases for establishment and AssignRun. It preserved unknown versus authenticated own-COMMIT confirmation, subsequent current reads, zero measured provider/staging/EGS contacts and empty operational roots. Its two diagnostic source files are external evidence and are not committed.

These are authenticated **local** validation results, not a claim that CI passed. Publication authenticates the existing results without another test or probe rebuild. Earlier failed runs remain historical failures.

## Explicit limits

This PR does not enable public reliable Submit, operational ingress/key provisioning, provider dispatch or reconciliation, deployment, or native installed-source qualification. The operational no-dispatch predicate and cross-restart write-uncertainty authority remain unimplemented by this facade.

Physical/device-close success, hard close latency, capacity under actual double withholding, SQLite file/sidecar byte preservation, and real provider/receipt claims remain unqualified. The accepted observation pool's unchecked close return on refusal remains disclosed. Logical preservation and fixture outcomes must not be described as operational guarantees.

PRs #8, #9 and #10 remain completed history. This publication requests review of unchanged accepted source, not merge or runtime permission.

<!-- END APPENDIX C -->

### Appendix D — Derived accepted blob map and report discrepancy ledger

Bytes: 8971
SHA-256: fcf5e5be3a69c8a5598ba2e3bba49d78d9061cbe7fcb7cbd8075cb37545cfcb8

<!-- BEGIN APPENDIX D -->
{"accepted_manifest_sha256":"f92b57f48a701a606e8a0697b75dac8f691e3eb44c13b9c92afb894ec6e1d718","accepted_source_zip_sha256":"3b27c483036296304a9fbca77dcd5fe522dee64b8eabf392057b6c573160f59a","all_30_reported_blob_ids_match_packet":true,"all_30_reported_sizes_and_change_kinds_match_packet":true,"files":[{"blob":"0f5c56cdbf11b80158f29700a31fef5dc20f335f","delta":"M","disk_mode":"0644","git_mode":"100644","path":".docs/execution_lifecycle/es_execution_admission_model.md","sha256":"bedc87c611b5c9340ffaafb0866f028dc9daf2f22552efec47491f1b4ae713f2","size":88702},{"blob":"772fb7dbd4bfb1d8162b87b0d66c0803957cbdd9","delta":"M","disk_mode":"0644","git_mode":"100644","path":".docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md","sha256":"34e06ff10148d67a49000868499294873c732279d7f399a5f2cb910b0c12f40e","size":161666},{"blob":"94fe56e0cdea71acf29c2df1074bcd4048c0bc0b","delta":"M","disk_mode":"0644","git_mode":"100644","path":".docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md","sha256":"1b03cc40b48861c7220a7b85d20b1f8d232690f17460e3eee0df33af4659e3f3","size":103025},{"blob":"b74440dc7d3ef2e488d92a7fb9f6f64d7cecdcee","delta":"M","disk_mode":"0644","git_mode":"100644","path":"PLANS.md","sha256":"c4fdbfb4acd3c2a27f679f6575798c4553e94110c4aa7177f590e90fe89c5e31","size":302636},{"blob":"e69ada92d1e723e1b70f03e5191e96145e687713","delta":"M","disk_mode":"0644","git_mode":"100644","path":"docs_contract_test.go","sha256":"dd433f02e783aa265d775bd411c95433e369642e2aafbdb32c72b75f78b4ebff","size":799914},{"blob":"94a7d56b5f8ef5501f92abf7cb0c7732a490859d","delta":"M","disk_mode":"0644","git_mode":"100644","path":"es/admission/internal/reliablesubmit/durable_operation.go","sha256":"b7761f001a1f67349ed51f2b79012194a7d45bb19c79e0ca2c0c22b8227320f9","size":9548},{"blob":"41e2dc127cd0a56163a9f9c42992e3e2dad9643b","delta":"M","disk_mode":"0644","git_mode":"100644","path":"es/admission/internal/reliablesubmit/durable_record.go","sha256":"999db7db6550c5031b023a9613825504e30e971a179298cc43e09cf8c5c5d7cd","size":25226},{"blob":"25ef96d035c6be87209d81c7b831a366f47d6e94","delta":"M","disk_mode":"0644","git_mode":"100644","path":"es/admission/internal/reliablesubmit/durable_service.go","sha256":"ef0bc6f4d125f3986c46901cbe05bc2cb447af7dfbf51cee4653d7ce696c0945","size":49972},{"blob":"ebadc607372c586f1681d6290037cac50b0167fe","delta":"M","disk_mode":"0644","git_mode":"100644","path":"es/admission/internal/reliablesubmit/guardrails_test.go","sha256":"9a300f0553fd6ac3003a048a7309060a4ec6f618eacd94139bd4bb29c011bc60","size":32231},{"blob":"b1bc86218f53653d04eda1840ced29c8688ce098","delta":"M","disk_mode":"0644","git_mode":"100644","path":"es/admission/internal/reliablesubmit/replay_custody_file.go","sha256":"61c4006e1e4a3feb7c0ec0e7d4685dc2c3fe8c1e2165d1529d2c86ae8fa137b5","size":50461},{"blob":"d5b0f305b3809520f79c4ef1f9ab206292be7578","delta":"M","disk_mode":"0644","git_mode":"100644","path":"es/admission/internal/reliablesubmit/replay_custody_file_test.go","sha256":"207d9f17658cd50f6c4bea8e293b12abd89455a174b2d96bac84742a66b0afdf","size":69995},{"blob":"134c37fff7318ccc356a0ce34ced924eb16b95a1","delta":"M","disk_mode":"0644","git_mode":"100644","path":"es/admission/internal/reliablesubmit/replay_custody_format.go","sha256":"b8cb8e31edd9d854317a0d6a456f25d5ab1838498623881e429dec2155e1ea67","size":16488},{"blob":"f1aed2819f38138264e5691432f849079252a3bb","delta":"M","disk_mode":"0644","git_mode":"100644","path":"es/admission/internal/reliablesubmit/replay_custody_structure.go","sha256":"4916268757b93d409cbc13ba9c0da14e009499b4db7cadd52bc7ccd47c6a86ad","size":18640},{"blob":"f055ead2af265d3ac5d28c4c6a6698f46449a389","delta":"A","disk_mode":"0644","git_mode":"100644","path":"es/admission/internal/reliablesubmit/replay_progress_test.go","sha256":"0952fff321daa368dee1d32ed39a2a5b417e7d2779ae4e1015ab3c12b1021048","size":61314},{"blob":"7814a04f4962fbdb8cec4a1d3a24201ea10f9bca","delta":"M","disk_mode":"0644","git_mode":"100644","path":"es/admission/internal/reliablesubmit/sqlite_migrations.go","sha256":"7736e30a1d0c6e9584d9050cc6ebf8bfaf900d424f764ebe61af8ec8ddaec0c9","size":17407},{"blob":"620899f647432e48789bee7df219b5689ef417c7","delta":"M","disk_mode":"0644","git_mode":"100644","path":"es/admission/internal/reliablesubmit/sqlite_physical_test.go","sha256":"2c125b6373f83467d542db45473cc79b888ed3a665e65ef6bf013655f461a7ba","size":14539},{"blob":"4aa80cca7b7c3d3011dd277aaaeda4f59b02011a","delta":"A","disk_mode":"0644","git_mode":"100644","path":"es/admission/internal/reliablesubmit/sqlite_pooled_claim_read_cleanup_test.go","sha256":"0ec3060ed3c30a6327ec49b0291d5c761c20894986c9b6b1e1be384694312823","size":8912},{"blob":"4f4ce954febca494bada72ebc2e5f95bc43af2fb","delta":"M","disk_mode":"0644","git_mode":"100644","path":"es/admission/internal/reliablesubmit/sqlite_replay_claim.go","sha256":"8ddec89b4ca5702591bdf2060062016d7fb54264fc7df57af5ead1d161eb9de3","size":8301},{"blob":"8191f490886cef673e1ce98dc30dc982e69d3e61","delta":"M","disk_mode":"0644","git_mode":"100644","path":"es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go","sha256":"e0765e59cb00ace73e8a88c92b9d7e830b39766792120845220b2fd407d357fa","size":28903},{"blob":"1317d92ba935f9cd1b9532ca0807a5c9cf05282c","delta":"A","disk_mode":"0644","git_mode":"100644","path":"es/admission/internal/reliablesubmit/sqlite_replay_progress_schema.go","sha256":"132d8ab87f5658cab3477b9f6913538013ba922d4768192a96be960df7bbb149","size":30612},{"blob":"b4b5f18f5686a912cf02f9164cc2e27ff6ffa59a","delta":"M","disk_mode":"0644","git_mode":"100644","path":"es/admission/internal/reliablesubmit/sqlite_replay_shape.go","sha256":"29cdbba2e5b1fee069989f6e6423dccc1c69c843de22b6504f68a7d199b317be","size":2751},{"blob":"3f938be010268b950351c0ec72922e2379a297d2","delta":"M","disk_mode":"0644","git_mode":"100644","path":"es/admission/internal/reliablesubmit/sqlite_replay_shape_test.go","sha256":"3552ea5fafbc59e43cc21b1007486e98da4d59b6d0ea98db92646e0c8478adfb","size":8815},{"blob":"97a9d8f5c8b74a1c7d05812a0d6f80073d613dd4","delta":"M","disk_mode":"0644","git_mode":"100644","path":"es/admission/internal/reliablesubmit/sqlite_store.go","sha256":"e448d265516aae1d7efd2c06170d8cfa2cc8c0258f82dfc15a3279e65efad4c1","size":63299},{"blob":"ee2f8c5b6255d3ba4990fc23c2b393bda85e0d77","delta":"M","disk_mode":"0644","git_mode":"100644","path":"es/admission/internal/reliablesubmit/sqlite_store_test.go","sha256":"c99e7659b1059431911557ba43ef7fa982e373bba939f610bd41ea0622cee96f","size":57339},{"blob":"56ee45b1a99e453a96bcbce21095ccd894deb26f","delta":"M","disk_mode":"0644","git_mode":"100644","path":"es/admission/reliable_submit_guardrails_test.go","sha256":"32de42b7bf8974e36c014d3d9ce6d24e0994fbbc03bb1587c4c4fddd32c80f6e","size":50991},{"blob":"533877eea3ef937d8d7c77c85e2ac160a43af790","delta":"M","disk_mode":"0644","git_mode":"100644","path":"es/admission/reliable_submit_replay_format.go","sha256":"0a21803b03308332613481f89ce4b595512b31b073c56b31fe7d8000519c3beb","size":17326},{"blob":"97f3eec0f78b20a7afc4b1f6e53df55c5911ee6c","delta":"M","disk_mode":"0644","git_mode":"100644","path":"es/admission/reliable_submit_replay_hydration.go","sha256":"b5ff16b96178c45b53165ebb2bcbdc67991bb145276ca4a11a598f1430745b9c","size":28800},{"blob":"ace0e7c6a7e35c8e8385e49008e06a567a17b5cd","delta":"M","disk_mode":"0644","git_mode":"100644","path":"es/admission/reliable_submit_replay_private.go","sha256":"d17927a23a57c808a8f0ebc4bad3e9912e42d7da497033637102bae2c45fd278","size":20440},{"blob":"e45e87ec5fa7abbaccd1d365cab1d642d8f6c44b","delta":"M","disk_mode":"0644","git_mode":"100644","path":"es/admission/reliable_submit_replay_private_test.go","sha256":"4e4e7c7fad2ed2b88b35801841044f4b1f049a4cb6d0435499bb87699467e9f2","size":45171},{"blob":"59bac2e2b3f3214dbaaf6c080d6356df9d84e31c","delta":"M","disk_mode":"0644","git_mode":"100644","path":"es/admission/workstream_c_guardrails_test.go","sha256":"68f2fe4e31e5d862be161c3ba1071a511935b32e90cf9021755fe4dcb045fab5","size":297009}],"purpose":"Derived comparison of the supplied commit-report rows with the authenticated accepted source packet; NOT a live committed-object verification.","report_transport_sha256":"0998241f845e69720c91bd2441a1e03385b1dff9cc66e6f2451ae51339f77e3f","reported_commit":"dbdc433283617b9e3b233f75c92f1179c2ece91f","reported_parent":"f1aa8b934cc26c16a966a110c7b408abdaeadce7","reported_tree":"e066cd4afa77fcb665f31b69bf00465989f9744e","sha256_cell_discrepancies":[{"mismatches":{"sha256":{"packet":"ef0bc6f4d125f3986c46901cbe05bc2cb447af7dfbf51cee4653d7ce696c0945","reported":"ef0bc6f4d125f3986c46901cbe05bc2cb447af7dfbf51afe993a59c2afaf7971"}},"path":"es/admission/internal/reliablesubmit/durable_service.go"},{"mismatches":{"sha256":{"packet":"32de42b7bf8974e36c014d3d9ce6d24e0994fbbc03bb1587c4c4fddd32c80f6e","reported":"32de42b7bf8974e36c014d3d9ce6d24e0994fbbc03bb1587c4fddd32c80f6e"}},"path":"es/admission/reliable_submit_guardrails_test.go"}]}

<!-- END APPENDIX D -->
