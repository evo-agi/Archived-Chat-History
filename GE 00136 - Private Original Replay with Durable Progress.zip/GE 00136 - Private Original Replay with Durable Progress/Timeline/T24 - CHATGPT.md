## Exact repair review complete — proceed to a fresh independent audit

**The manifest discrepancy is resolved, and I found no additional blocker in this targeted source review.** The eight findings now have source and test changes consistent with the selected repair. They still require fresh independent closure; this review does not authorize staging or commit.

I inspected the actual repair files, the complete seventeen-file repair delta, relevant surrounding functions and contracts, maintained regressions, and the external admission diagnostic. **I did not apply patches or execute repository code, tests, migrations, or probes.**

:chatgpt-content-reference{index="3"}[Download the complete exact-source review, including line-numbered supporting excerpts](sandbox:/mnt/data/ES_Private_Replay_Progress_Consolidated_Repair_Exact_Source_Review_20261119.md)

## The manifest error was confined to the pasted report

The uploaded archive matches the reported **900,863 bytes** and SHA-256:

```text
e3cac3bc27bbfd8c1c18d1abf3aabc00077e632e14bd6e6b92e26e020c9c1be6
```

Its actual `repair-manifest-v2.json` is already correct:

```text
Bytes:
6,813

SHA-256:
0812091529c67f4bc46d0bc343b3dea8595e63a461264e143d51606e581e0c06
```

The complete `replay_custody_structure.go` payload reproduces the correct 64-character hash and is byte-identical to the rejected implementation’s file:

```text
4916268757b93d409cbc13ba9c0da14e009499b4db7cadd52bc7ccd47c6a86ad
```

**No source correction, manifest regeneration, or separate report-reissue turn is needed for that transcription error.** The next audit prompt preserves the supplied report unchanged, explicitly identifies its bad field, and supplies the verified archived manifest as the target. An actual live-checkout mismatch would still stop the audit.

The rest of the packet also checks out: all 44 entries are uniquely named regular files; all 43 inventoried payloads match their bytes, sizes, and archived modes; all thirty source rows match the manifest. Exactly **seventeen rows changed and thirteen remained frozen**. Both sides of the incremental patch match the supplied old and new files, including unchanged intervals; the tracked HEAD patch’s target-side hunks and blob identifiers match the delivered files.

## What the source review establishes

The following locations refer to the authenticated repaired packet. Full supporting excerpts are in the linked review.

| Finding | Source-level assessment |
|---|---|
| **M-1 — migration opening race** | `sqlite_store.go:550–595, 662–742` now separates preflight from the decisive lock-held verification. The actual opening state is authenticated before selecting migration writes or recording the recovery baseline. An authentic competing current head takes a lock-only cleanup path. |
| **M-2 — namespace qualification** | `sqlite_replay_shape.go:22–28` defines the literal prefix predicate, and `sqlite_store.go:744–755` uses it for pristine qualification. The legitimate schema constants remain unchanged. |
| **SR-1 — confirmation eligibility/lifetime** | `replay_custody_file.go:1344–1387` now checks the live borrow after acquiring the issuer lock, verifies the retained key pair, and checks qualification/lifetime again before projecting the committed snapshot. |
| **SR-2 — reconciliation no-op** | `durable_service.go:402–451, 830–857` checks current recording eligibility before a fresh same-fact no-op. Exact latest replay, conflict, and stale classification remain earlier in the mutation path. |
| **K1-1 — definite occupied outcome** | `reliable_submit_replay_private.go:297–316` preserves `Occupied` when winner disclosure fails, while retaining authenticated changed-intent `Conflict`. The change stays local to the definite-loser branch. |
| **T-1 — terminal association** | `durable_service.go:1131–1189` adds the selected private outcome and receipt fields and validates them against the requested operation. The evidence remains explicitly synthetic. |
| **R2-1 — scope-1 permit burn** | `replay_custody_file.go:406–435` restores scope-1 preflight before burn, while keeping burn before eligible issuer/allocation failure. Scope-2 wrapper treatment remains selected. |
| **N-1 — admission-level uncertainty** | The supplied external bridge and test reach actual admission establishment and `AssignRun`, perform real COMMIT followed by modeled response loss, and check disposition, projection, subsequent reads, and effect counters. They are absent from the repository source manifest. |

The maintained tests correspond to those corrections rather than merely carrying the finding names. For example, SR-1’s lifetime test holds the issuer lock after initial access consumption, ends or cancels the owning callback, and only then releases the pending read. The migration regression uses the existing clock collaborator to order a second SQLite writer before lock acquisition. These are concrete interleavings, not sleep-dependent assumptions.

**This supports the audit handoff; it does not independently establish that the tests passed.** Codex’s report supplies those execution claims. Pasted text

## Three qualifications matter for the next audit

### Migration recovery must be reviewed as a complete path

The generation-1 failure remains material history: the initial refactor mishandled an already-closed connection wrapper before old-state recovery. Codex reports correcting it and rerunning the complete sequence on generation 2. Pasted text

The final source routes a nonnil migration COMMIT response through the unpublished opener’s unknown-outcome path. That path closes the pool before a fresh nonmigrating classification. The unchanged regression cases cover interruption before COMMIT and lost response after real COMMIT.

The auditor should verify that complete lifecycle—including rollback failures and result precedence—not just the new lock-held qualification. **Wrapper closure, pool closure, and guaranteed physical teardown remain different claims.**

### T-1’s old-interface adapter is legitimate but limited

The packet contains the exact rejected-interface adapter and its test-view variant. The old evidence type has no outcome or receipt fields, so it cannot literally represent malformed versions of those new fields. The adapter retains the old common associations; receipt substitution and opposite-command cases remain meaningful negative controls.

The fresh audit should distinguish those representable counterexamples from new-field validity tests. It should not describe all red and green inputs as identical or treat aggregate counts as causal proof.

The repaired constructors and checks establish **synthetic association**, not authenticity of an external provider receipt. That is the selected boundary, and the updated owner documents preserve it.

### N-1 is now inspectable, but its execution still needs independent confirmation

I verified the supplied bridge and witness against their recorded hashes and the final manifest. The bridge attaches and restores only the selected store’s existing COMMIT hook; it does not replace admission outcome mapping or inject successful projections.

The witness covers four combinations: establishment and `AssignRun`, each with canceled recovery and exact authenticated recovery. It checks one intended real COMMIT, clears the hook before the later read, and asserts zero provider/staging/EGS contacts and empty operational roots.

The packet includes source, construction metadata, and build-input records—not the underlying raw execution logs or all 400 unchanged source files. Those remain for the auditor to authenticate on the host and rerun in its own external view.

## Reported validation remains bound to generation 2

Codex reports all eleven final commands passing, including **5,174 ordinary full-suite pass identities, zero failures, and 39 skips**. The increase over 5,096 is 72 internal and six admission identities; the five external N-1 identities are separate. The additional helper sentinel is not an allocator-proof skip when its parent actually executes and verifies the helper. Pasted text

The fresh audit must verify those identities, skips, logs, and immediate integrity observations. It should not turn the retained green result into independent acceptance without execution.

## Next Codex conversation

Open a **fresh read-only Codex conversation directly at**:

```text
/Users/ds/Repositories/ES-Private-Replay-Progress-v1
```

Use:

:chatgpt-content-reference{index="4"}[Download the consolidated-repair fresh independent-audit prompt](sandbox:/mnt/data/ES_Private_Replay_Progress_Consolidated_Repair_Fresh_Independent_Audit_20261119.md)

SHA-256:

```text
4eca740e2bdee81c6819b3e5ec63ba392f593089e582b9866871f1719b787ba4
```

The prompt embeds seven byte-verified inputs: the complete unmodified repair report, correct archived manifest, exact v2 recipe, complete prior rejection, this review’s findings and qualifications, and both external N-1 source files.

The audit will authenticate the live thirty-path candidate, review the full integrated slice and seventeen-row repair, and use four independent perspectives covering migrations, custody/lifetimes, durable/admission semantics, and evidence/effect boundaries. **Each of the eight findings needs an explicit disposition.**

An `ACCEPT` requires the complete eleven-command sequence, including one full repository run and an independently constructed N-1 view. If a substantive blocker is confirmed, the reviewers should still finish their complementary source reviews; broad runs that cannot change the rejection may be omitted with an exact skip inventory. This avoids another piecemeal repair cycle without requiring pointless execution.

The prompt also avoids two unnecessary obstacles: it does not require historical global ref fingerprints to match unrelated current refs, and it does not rebuild either historical opener probe. Named repository identities, actual source bytes, index state, and the two probes’ distinct purposes remain mandatory.

**No source edit, staging, commit, push, PR change, or runtime action is authorized.** The authoring conversation may remain attached to A1; nothing needs to be moved or synchronized. After this audit concludes, its foreground conversation may perform a separately instructed next step.

The earlier rejection remains attached to manifest `110cef71…`. The repaired `08120915…` candidate is now ready for independent review—not yet accepted. Public reliable Submit and the operational cross-restart write-uncertainty gate remain unimplemented.

**Sources:** Exact repaired and rejected ZIPs; delivered owner contracts, source, tests, and diagnostic construction records; complete repair closeout for reported execution results. The linked review contains exact source excerpts and inspection limits.

**Confidence:** Packet/source binding **0.99**; targeted static repair assessment **0.96**; readiness for fresh independent audit **0.98**. Dynamic repair correctness and overall implementation acceptance remain outstanding.
