# Execution Substrate — private original replay/progress fresh independent audit

## Objective and permission

Start a **fresh Codex conversation**, independent of the authoring conversation,
opened directly at:

```text
/Users/ds/Repositories/ES-Private-Replay-Progress-v1
```

Independently audit the exact thirty-path uncommitted implementation of private
original replay custody with durable claim progress. Decide whether those bytes
are eligible for a later separately instructed local commit gate. Independently
confirm or refute the two static source findings in Appendix D, and inspect the
complete integrated slice in the same pass. Neither a passing test count nor this
ChatGPT review is a substitute for your judgment.

This audit is repository-read-only. The parent may create private external audit
artifacts, copy authenticated source into external diagnostic views, compile and
run the explicitly bounded offline fixture tests/probes below, and inspect local
pinned dependency source. No repository source, Git index, ref, configuration,
prior evidence, or other existing checkout may be changed. No product repair,
staging, commit, fetch, push, PR action, merge, installation, dependency download,
live stack, operational migration, deployment or runtime wiring is authorized.

A fresh audit must begin independently. After this audit concludes and all audit
subagents close, this same foreground conversation may perform a later explicitly
authorized repair or commit task. It is not permanently audit-only.

The author's earlier conversation was attached to the A1 checkout. That routing
history does not change this target. Do not operate on A1 by substitution, create
another candidate checkout, synchronize any checkout, or require the user to move
historical conversations. Use explicit cwd and absolute artifact paths.

## 1. Exact target

```text
physical and Git root:
/Users/ds/Repositories/ES-Private-Replay-Progress-v1

Git/common directory:
/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.git

branch:
codex/private-replay-progress-v1

upstream:
origin/trunk_dev

origin:
git@github.com:evo-agi/Execution-Substrate.git

HEAD:
f1aa8b934cc26c16a966a110c7b408abdaeadce7

sole parent:
fb9ae55797d9fcc02863c23fe8d3e43d16eac542

HEAD tree:
8dd27f9acba98ed70d93736bdef8300ef1aba53f

HEAD subject:
Harden original-key read transaction cleanup (A1) (#10)

baseline:
427 tracked leaves

candidate:
27 unstaged tracked modifications
3 authorized untracked additions
400 other tracked leaves unchanged
430 total source leaves
0 staged, unmerged, deleted, renamed, type-changed, ignored or extra paths
index equals HEAD

canonical manifest:
6813 bytes
110cef71ba25f61b70297b37cc5a50a68732d639845e0ac4315d06cedcdbc1e3

tracked full-index HEAD diff:
e45e3bd85391191702673b2d40fc2d06d865503004e09a8094c2f6a7081fe0c4

recipe:
governed-execution.audit-patch-manifest.v2
7275 bytes
c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca
```

All changed/new source files are regular disk mode `0644` / Git mode `100644`
when tracked. The complete thirty-file target is Appendix B. The three expected
untracked files are:

```text
es/admission/internal/reliablesubmit/replay_progress_test.go
es/admission/internal/reliablesubmit/sqlite_pooled_claim_read_cleanup_test.go
es/admission/internal/reliablesubmit/sqlite_replay_progress_schema.go
```

The ordinary untracked inventory must equal those three paths, not be empty.
The tracked diff does not contain their complete bytes; compare them separately.
Do not stage them to make the diff look complete.

Review ZIP on the author host:

```text
/Users/ds/Repositories/ES-Private-Replay-Progress-Implementation-20261119-kadgzy4t/ES-Private-Replay-Progress-Implementation-Review.zip
718150 bytes
bc4bc721f7aa0f02da9f2427625973e883a82fdc0988e4f587c2140792245cf3
```

ZIP identities:

```text
36 regular-file entries: 30 complete source files and six metadata files
source-map.json:
d214f2e5cef18a4a40c4826a4ae027e1f822ae240bcade7b94e02cd91b59e566

delivery-inventory.json:
2c5e906cccbe078b39df283b109dd9c6d9342bada0b3d30753c87450314f2109

contract-opening-to-implementation.patch:
631ee93e57691352f099cee09d32cd958772960784c6eb2b3c6dc0e35fad97e0
```

The prior accepted architectural K1 packet is:

```text
/Users/ds/Repositories/ES-Private-Replay-Progress-K1-Contract-20261119-fzxf8tt8/ES-Private-Replay-Progress-K1-Contract.zip
420293 bytes
03dddf54b405e27fcdeafec2bc40165a2948d15be83a94ef5129c4d26b3c12d7

K1 five-file canonical manifest:
79c3554da0dbbb5c45677092aee07093ee3b5f10d306ed656a7e9922c6c7733b
```

Remote state is not needed for this uncommitted source audit. Do not fetch or
turn a later remote-base movement into a candidate-byte mismatch. Publication
reconciliation is a later gate.

## 2. Governing sources and scope

Read `AGENTS.md`, the current candidate and pinned HEAD `PLANS.md`, relevant
`.docs/system_overview/` authority/capability/security guidance, and these owners:

```text
.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md
.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md
.docs/execution_lifecycle/es_execution_admission_model.md
```

Inspect docs, source, tests, schema/migration, module pins, relevant caller/config/
startup/script and example exclusions, and actual retained validation together.
Use the owning contracts rather than the implementation report as design authority.
Distinguish pinned base facts, newly implemented candidate facts, accepted design,
reported test results, independently observed results and inference.

Selected classification: a private **Bounded slice rule** on the reliable-submit
**Reopened redesign seam**, limited to `synthetic_progress_nonoperational_v1`.
The private fixture facade is not a public service, runtime effect path or
operational recovery gate.

Preserve the accepted architecture:
- one existing ES SQLite claim/key/grant domain and caller/key occupation;
- immutable original and sealed descriptor, one attempt and assigned RunRef;
- existing durable service as semantic progress writer, SQLite as durable storage
  and constraint/CAS boundary, no second state machine or authority ledger;
- schema 4 / codec 4 / scope 2 / envelope versions are separate axes;
- authentic historical codec 1/2 semantics, immutable codec 3 and migration 1–3
  literals/hashes remain preserved except the explicitly selected scope-1 shared
  allocator call-site refinement;
- R1 retains historical reconciliation while current facts control progression;
- R2 serializes both publishers' count/create, owns every connection/FD exit,
  retains counted orphans and does not refund a permit or adopt/reuse objects;
- R3 old schema-3 opener is compiled from the exact pre-migration PR #10 source,
  not from this candidate; historical PB1/schema-2 evidence stays distinct;
- K1 preserves an invocation's write disposition and performs no automatic
  second write. A later explicit command has fresh authentication/current CAS
  eligibility and cannot retroactively confirm an earlier unknown response;
- operational §8 Validated No-Dispatch Evidence remains unchanged and is NOT
  implemented by the fixture no-marker observation;
- public structural reliable-request refusal and unkeyed Submit remain current;
  CP compatibility is not broadened, Coordinator authority remains separate,
  and no report or model response becomes run truth.

Do not reopen these choices merely to avoid repairing an implementation gap.
Raise a genuine contradictory contract explicitly, with source citations.

## 3. Private audit workspace and hygiene

Create a new absent, current-user-owned nonsymlink private evidence directory via
an exclusive temporary-directory operation beneath `/Users/ds/Repositories`,
with prefix:

```text
ES-Private-Replay-Progress-Independent-Audit-20261119-
```

Root/subdirectories `0700`; retained evidence files `0600`. Do not chmod the
existing parent, reuse an old root or overwrite another artifact. External
source views preserve reviewed source modes inside private parents; transient
executables may be owner-executable while used. Record the actual root once.

Set `PYTHONDONTWRITEBYTECODE=1`, invoke `python3 -B`, and use
`sys.dont_write_bytecode = True` where relevant. Never import or execute verifier
source directly from a prior evidence root. Authenticate and copy it to this root
first. Do not restore timestamps or use volatile directory metadata as a gate.

Existing fixture-owned disposable temporary paths, helper processes, local mock
listeners, test certificates and temporary Git repositories may be exercised by
the specified tests. Their existence is not an operational stack authorization.
Use audit-owned caches/TMPDIR where tests permit it. Record bounded ownership and
cleanup, not an invented machine-wide residue proof. Do not delete unrelated
`/tmp`, `/private/tmp`, caches, state or other checkouts.

Read-only capability probes by existing tests are permitted. Do not start or
use a live Docker/Nomad/ES stack for an effect. If newly available capabilities
would cause an unapproved live integration run, stop that gate and report it;
do not spoof a capability failure or silently edit/skip the test.

## 4. Opening provenance before behavioral judgment

1. Authenticate all four appended byte payloads by their declared lengths/hashes.
2. Verify physical root, Git top-level/common directory, HEAD/parent/tree/subject,
   branch/upstream, origin, index and working-tree posture.
3. Authenticate the supplied ZIP, reject duplicate/traversal/link/special entries,
   verify all inventory members, canonical source rows and source map.
4. Copy Appendix C's exact recipe to an audit-owned file without executing any
   prior-root source. Inspect it, then execute twice from the actual progress
   checkout to distinct absent audit-owned outputs:

   ```sh
   (cd "$CANDIDATE" && PYTHONDONTWRITEBYTECODE=1 python3 -B "$RECIPE_COPY" "$OPEN_A")
   (cd "$CANDIDATE" && PYTHONDONTWRITEBYTECODE=1 python3 -B "$RECIPE_COPY" "$OPEN_B")
   ```

5. Require byte equality with Appendix B and both retained implementation
   manifests. Verify every path/type/mode/size/hash and the full tracked diff.
6. Verify all 427 HEAD entries: 27 reviewed modifications and 400 unchanged
   working files; verify the three additions separately. The combined source set
   is 430, not 427. Bind an audit-owned full source inventory.
7. Verify the index equals HEAD and both untracked inventories explicitly:

   ```sh
   git ls-files --others --exclude-standard -z
   git ls-files --others --ignored --exclude-standard -z
   ```

8. Compare the five owner/test changes from K1 to the actual implementation. Do
   not treat the older contract manifest as the new whole-patch target.
9. Authenticate material implementation evidence listed below. A missing material
   result is an evidence gap, not an inferred pass. Exact candidate/recipe/packet
   mismatch requires `AUDIT_PROVENANCE_MISMATCH` before behavioral judgment.

Do not inventory every historical audit root. Do not require a fresh snapshot,
remote tip, historical directory timestamp, or unchanged Codex-private ref set
as a prerequisite for unrelated source inspection. Record only relevant baseline
or effect-state changes and distinguish their categories.

## 5. Material evidence to authenticate

Implementation root:

```text
/Users/ds/Repositories/ES-Private-Replay-Progress-Implementation-20261119-kadgzy4t
```

Use the exact source maps, final manifests and retained material records relied
upon, including:
- `final-generation-2`: frozen source/env/argv, all ten raw logs and exit/event
  records, distinct executed immediate guards, skip/identity reconciliation;
- `phase1-v2`: red and green source views, exact seam instrumentation and the
  same complete 8912-byte reader test, expected failure assertions and actual
  real-BEGIN/SELECT observations; verify how final source changes relate to
  that differential rather than assuming old green bytes equal the final tree;
- allocator final-slot helper readiness/win/exit records and parent assertions;
- migration rollback/lost-response and full logical/object preservation witnesses;
- `historical-pb1/authentication.json` and original binary/source/harness binding;
- `schema3-probe/compiled-and-export-inputs.json` and exact baseline export,
  one-entry overlay, test harness, build argv/cwd/environment and binary;
- relevant source/no-effect/guardrail mutants, cleanups and routing preservation.

The report supplies no externally fixed full implementation-report/index digest
beyond the transport and listed artifacts. Do not invent one. Record observed
local duplicate/index identities and compare decision facts with Appendix A;
use externally pinned ZIP/manifests/records for their actual binding scope.

Probe identities:

```text
historical PB1/schema-2 probe:
14350930 bytes
b205a31bac091cbcf5b3f4826bc359455625316908051131733622813e34adcf

distinct previous-schema-3 probe:
15601186 bytes
42614a50812a65ba52b53488d872884e59ce7b4f57dece6a66642d4eb8de1409

schema-3 compiled/export input inventory:
50a81fa5a042e135abfc9f6bad68d20abc4575f881945ecc84252c14910dde8f
```

Authenticate and copy the probes to this audit root; only the copies become
executable. Reuse the historical PB1 binary without relabeling or rebuilding it.
For schema 3, inspect that every production input came from the pinned PR #10
export and the overlay only added its test harness. A new binary build is not
required merely to change the audit directory. If authentication fails, report
that gap; do not quietly compile the schema-4 candidate and call it an old opener.

Bind `ES_REPLAY_PB1_PROBE` and `ES_REPLAY_SCHEMA3_PROBE` to the authenticated copies.
The respective tests supply their child target variables
`ES_REPLAY_PB1_TARGET` and `ES_REPLAY_SCHEMA3_TARGET`. Check that each receives the
correct authentic schema target, and that schema-4 refusal checks the whole
logical state and both originals without migration.

## 6. Independent perspectives

After opening provenance, use four bounded read-only subagents with no nested
delegation. Every reviewer receives the same exact manifest and short context
capsule. The foreground parent alone runs validation and diagnostics to avoid
uncoordinated test/evidence effects. Reviewers may inspect source/artifacts but
may not edit, run tests or perform network effects.

1. **Contract, authority and durable semantics:** K1, R1, private/public split,
   every transition and no-op/replay result, caller/key occupation, run/receipt
   immutability, latest-operation input binding and invocation dispositions.
   Independently assess SR-2 and the interaction with legacy rules.
2. **SQLite, transaction and migration correctness:** pooled reader; all write
   exits, both CAS outcomes, cleanup/disposal and uncertainty; opening state at
   actual migration boundaries; full schema/row/registry/counter/ledger
   preservation; old-opener proof and strict raw hydration before narrowing.
3. **Custody, crypto, filesystem and capabilities:** four format domains and
   their strict dispatch, AEAD/MAC association, issuer/Close/context/one-use
   lifetime, snapshot versus eligibility, both publishers' allocator, bounded
   resource ownership and the SR-1 confirmation-read branch.
4. **Tests, evidence and no-effect assurance:** independent vectors, true
   red/green causality, caller-level uncertainty composition, helper execution,
   test identities/skips, material artifact binding, exact static inventories
   and negative mutants, actual reachability to operational surfaces.

Keep minority views and limitations. Parent reads the load-bearing source
independently, resolves disagreement with evidence, waits for and closes each
reviewer, then returns one consolidated verdict. No writer subagent.

## 7. SR-1 and SR-2: adversarial audit inputs, not verdict instructions

Appendix D contains the complete static review with exact source excerpts. It
states two source-supported mismatches and predicted diagnostics. No ChatGPT
behavioral test was run. Reproduce or refute independently against the actual
owning contract. Distinguish concrete control flow, reachability, runtime result,
severity, and public/operational impact. Do not repair during this audit.

### SR-1: confirmation read bypasses operation-entry key eligibility

Inspect `replay_custody_file.go:1263–1278,1300–1315,1340–1377` and the owner's
submit/recovery `:907,911–932`. The confirmed-establishment branch projects
`state.confirmed` after only `c.qualified`, bypassing the normal reload's key
check. The known-commit snapshot permission is distinct from operation-entry
eligibility.

In a bounded external test, use real SQLite and legitimate existing fixture
APIs to establish and authenticate an original. Commit revocation through an
independent fixture handle after original authentication but **before entering
ReadFixtureProgress** on the confirmation access. Test known-committed and
recoverable-unknown establishment separately. Include active and retired controls
and the ordinary current-read branch. Record disposition separately from whether
a projection is returned. A known write stays known even when projection refuses.

This orders revocation COMMIT before the relevant method entry. Do not demand
instantaneous detection of a revocation after the checked observation boundary,
and do not require returning later progress instead of a permitted committed
snapshot. No public exploit or claim mutation is alleged by this sequence.

Suggested test identity:
`TestAuditProgressConfirmationRechecksOriginalKeys`.

### SR-2: historical reconciliation accepted as fresh no-op after eligibility ends

Inspect `durable_service.go:402–457,1193–1227` against persistence ADR
`:1471–1490`. Use valid transitions to retain a Pending, Ambiguous or Inconsistent
reconciliation tuple through stronger terminal evidence. Then authenticate
freshly and submit op 7 with the same stored fact, a **new mutation identity**,
and the **current** expected revision. Distinguish that from latest replay and
stale replay. The equality return must not bypass the selected current recording
predicate merely because the historical tuple remains valid storage.

Controls: legitimate same-fact no-op while predicates hold; exact latest replay;
stale old revision; changed input under the same latest mutation; immutable
historical tuple; no durable mutation on refusal. Test compatible and incompatible
current provider facts where relevant. Do not propose dropping R1 history or
changing historical codec-1/2 semantics.

Suggested test identity:
`TestAuditProgressReconciliationNoopRequiresCurrentPredicate`.

### Diagnostic construction and interpretation

Use audit-owned exports of all 430 candidate inputs with exact identities, plus
bounded test-only files or overlays. Freeze complete test and instrumentation
bytes, command/env and expected outcomes before relying on a result. Do not
mutate the actual candidate, relax guards or alter a production body to make a
counterexample reachable. Prefer existing fixture helpers and public-to-package
private APIs. Explicitly identify any observation-only seam.

External fixture setup may be corrected in versioned attempts when it failed
before the target behavior. Preserve each attempt. A substantive failure is a
finding, not permission to change assertions and rerun it into green. Repeated
runs, if independently necessary, retain all outcomes and their purpose.

The exact additional command after the diagnostic view is frozen is:

```sh
(cd "$DIAGNOSTIC_VIEW" && "$GO" test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestAuditProgressConfirmationRechecksOriginalKeys|TestAuditProgressReconciliationNoopRequiresCurrentPredicate)$' ./es/admission/internal/reliablesubmit)
```

A source-conclusive finding can remain blocking even if the diagnostic setup
fails; do not fabricate a dynamic result. Conversely, explain a refutation with
the exact contract and reachable path, not merely a passing existing suite.

## 8. Complete-patch review requirements

The two named findings do not replace the integrated audit. Cover at least:

- Every pooled-reader state before/after BEGIN and COMMIT, independent bounded
  rollback, post-response context observation before self-cancel, exact discard,
  rescue and double-withholding; same-store healthy work before teardown.
- Preserve `loadClaimFresh`'s source/lifetime and inspect changes to shared
  hydration/migration helpers on its call path. Preserve A1/F1/O2/C1/D1 semantics.
- Full original equality: rowid, claim, codec/scope, creation, binding/witness and
  all replay fields; protected mutable-only CAS predicates and exact expected
  revision; zero record/projection on disallowed outcomes.
- All operation digests and closed command kinds; distinguish own-commit proof,
  current replay, same-fact no-op, conflict, stale, occupied and known CAS loss.
  Check authentication at no-write return paths as well as applied/unknown paths.
- Registry eligibility inside write transactions and at the selected read/use
  boundaries; unchanged burn/refund/lifecycle/purpose/fingerprint rules.
- Opaque original view, borrowed access, establishment attempt and invocation
  context lifetimes; context cancellation, copied/escaped/foreign tokens, Close,
  one-use and synchronization. Static field inventories are not lifetime proof.
- R1 sequences across restart, current provider/terminal constraints and fixture
  no-marker rules. Current-state progression cannot silently authorize effects.
- R2 both-scope last-slot contention, independent child process, before/after
  create faults, close/rollback/discard ordering, counted orphan and no Seal
  before allocation/permit qualification. Do not use a global FD count as oracle.
- Migration 4: exact old/new definitions, full original rows and key/grant/ledger
  state, authentic schema 0/1/2/3 paths, transaction-boundary validation, logical
  preservation versus physical byte claims, unknown migration classification,
  forbidden partial/repair/downgrade states and old binary nonmutation proof.
- Independent wire/digest/AEAD vectors and parser budgets, unknown/mixed versions,
  wrong association and malicious raw storage classes/enums before narrowing.
- End-to-end admission mapping, changed-current-input restart replay, same-key
  races, wrong-scope occupation, keys selected only after original lookup, no new
  resolution/acquisition/Seal on authenticated hits.
- Finite production caller inventory, App/API public refusal and current unkeyed
  compatibility, no startup/runtime/provider/staging reachability. Distinguish
  tests at internal boundaries from an actually exercised end-to-end failure.
- Conditional Workstream C inventory changes: verify all 32 typed entries/sites
  and expected references rather than simply accepting the new constants. Do not
  equate 32 typed entries with 32 new locks. Check the negative mutants still fail
  for their intended reason and no broad allowlist was introduced.

No new operational authority, process registry, dispatcher, worker, background
cleanup, physical-close fault platform or history ledger may be inferred or
implemented by this audit.

## 9. Execution environment and independent validation

Use:

```text
GO=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go
GOFMT=the sibling gofmt
GOTOOLCHAIN=local
GOPROXY=off
GOSUMDB=off
GOWORK=off
GOFLAGS=-mod=readonly
CGO_ENABLED=0
GOTELEMETRY=off
GOMODCACHE=/Users/ds/go/pkg/mod
GIT_OPTIONAL_LOCKS=0
GIT_NO_LAZY_FETCH=1
GIT_TERMINAL_PROMPT=0
PYTHONDONTWRITEBYTECODE=1
fresh audit-owned GOCACHE, GOTMPDIR and TMPDIR
outer umask 077; Go test subprocess umask 027
ES_REPLAY_PB1_PROBE=authenticated audit-owned historical binary
ES_REPLAY_SCHEMA3_PROBE=authenticated audit-owned schema-3 binary
```

Preflight the actual executable resolution: pinned Go 1.26.5, Python 3.13 with
`tomllib`, and OpenSSL 3 (implementation reports 3.6.2). Record exact executable
paths, versions and hashes and the safe explicit PATH/overrides. Do not silently
select Apple Python without tomllib or LibreSSL. Do not print a raw ambient
credential environment. A changed or unavailable material prerequisite is an
explicit setup/evidence limit, not permission to download or weaken assertions.

If no blocking finding remains, acceptance requires the exact ten serial
commands below on the frozen actual checkout. This is one final acceptance
sequence, not the earlier fourteen-gate campaign. If a blocking defect is
independently confirmed, complete the bounded diagnostics and all source-review
perspectives, but you may omit expensive whole-suite replays that cannot change
the verdict. Report each unrun command explicitly. Never return ACCEPT without
the required complete sequence.

Only runner paths and audit-owned cache/probe locations may change. Preserve
selectors, package scope, readonly flags and deadlines. Do not turn substantive
failures into success by rerun. Correct an actual external setup fault only with
retained evidence, unchanged candidate and explicit classification.

### Exact ten commands

```sh
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go version
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/gofmt -d docs_contract_test.go es/admission/internal/reliablesubmit/sqlite_store.go es/admission/internal/reliablesubmit/sqlite_replay_claim.go es/admission/internal/reliablesubmit/sqlite_migrations.go es/admission/internal/reliablesubmit/sqlite_replay_progress_schema.go es/admission/internal/reliablesubmit/sqlite_replay_shape.go es/admission/internal/reliablesubmit/durable_record.go es/admission/internal/reliablesubmit/durable_operation.go es/admission/internal/reliablesubmit/durable_service.go es/admission/internal/reliablesubmit/replay_custody_format.go es/admission/internal/reliablesubmit/replay_custody_structure.go es/admission/internal/reliablesubmit/replay_custody_file.go es/admission/reliable_submit_replay_format.go es/admission/reliable_submit_replay_hydration.go es/admission/reliable_submit_replay_private.go es/admission/internal/reliablesubmit/sqlite_pooled_claim_read_cleanup_test.go es/admission/internal/reliablesubmit/replay_progress_test.go es/admission/internal/reliablesubmit/replay_custody_file_test.go es/admission/internal/reliablesubmit/sqlite_store_test.go es/admission/internal/reliablesubmit/sqlite_physical_test.go es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go es/admission/internal/reliablesubmit/sqlite_replay_shape_test.go es/admission/internal/reliablesubmit/guardrails_test.go es/admission/reliable_submit_guardrails_test.go es/admission/reliable_submit_replay_private_test.go es/admission/workstream_c_guardrails_test.go
git --no-pager diff --check
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateOriginalReplayProgressContractSelection|TestReliableSubmitPersistenceAndConcurrencyADRDocsContract|TestSubmitIdempotencyCorrelationAndRecoveryDocsContract|TestReliableSubmitPureModelDocsAndSourceContract|TestReliableSubmitPublicOptInAndVersioningDocsContract|TestReliableSubmitContractAdapterFoundationDocsAndSourceContract|TestReliableSubmitBindingProducerDocsContract|TestIntegratedAcceptanceGateDocumentationIsConsistent|TestIntegratedCandidateStatusSeparatesCAndT)$' .
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestSQLitePooledClaimReadCleanup$' ./es/admission/internal/reliablesubmit
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateReplaySharedObjectAllocation|TestReplayPublicationFaultAndIdentity|TestPrivateReplayProgressFormatVectors|TestPrivateReplayProgressTransitions|TestPrivateReplayProgressConcurrencyAndCommitOutcome|TestSQLiteV4MigrationPreservesFullState|TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation|TestSQLiteV3OldBinaryRefusesWithoutMutation|TestSQLiteLegacyCASConnectionCleanup|TestReplayOriginalKeyReadCleanup|TestReplayOriginalKeyReadCallerRefusal|TestReplayGrantC1PreCommitConnectionQuarantine|TestReplayGrantD1BeginResponseLossQuarantine|TestReplayKeyStateD1BeginResponseLossQuarantine|TestReliableSubmitPrivatePersistenceStaticGuardrails)$' ./es/admission/internal/reliablesubmit
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateReplayProgressAdmissionReplay|TestPrivateReplayProgressHasNoEffectPaths|TestReliableSubmitFoundationHasNoRuntimeWiring|TestReliableSubmitBindingProducerHasNoProductionCaller|TestPrepareRequestShapeRemainsLegacyAndUnkeyed|TestResolvedSubmitLegacyEquivalenceOneNomadRegistrationAndAuthorityRecovery)$' ./es/admission
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestWorkstreamCContractPrepareAndSubmitRemainSeparatedAtAPIBoundary|TestSubmitPublicRouteRejectsStructuralReliableBody)$' ./es/api ./es/app
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=600s ./es/admission/internal/reliablesubmit ./es/admission ./es/api ./es/app
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=600s ./...
```

After EVERY new candidate test/format/diff command and each diagnostic command:
- execute a new post-command integrity observation, not a copied old JSON;
- compare all 430 paths/modes/hashes to the frozen inventory;
- verify HEAD, branch, upstream, index and exact 30-path scope;
- run both untracked queries: three expected source additions, zero ignored;
- check no unmerged/staged/extra paths;
- record that command's exit/log identities and executed guard association.

Identical deterministic checkpoint bytes are expected for identical state; their
hash alone does not prove separate execution. Verify the execution records.

The implementation's final generation 2 reports 5096/0/39, 21 tested packages and 20
no-test packages. Reconcile actual test identity multisets, not just totals or
output ordering. Exact candidate selectors must reach all intended parents.
The 39 skips comprise 37 App capability cases and two helper-only sentinels. The
new allocator helper must actually execute under its parent, with readiness,
outcome, exit, assertions and cleanup verified. Its direct sentinel skip is not
a skipped new allocator proof. Native installed-source qualification stays open.
No skip is acceptable for an unexercised new bounded acceptance path.

Do not repeat the historical socket campaign, add a machine-wide descriptor
oracle, rebuild PB1, or require all old evidence roots to rehash. The distinct
schema-3 provenance and retained reader differential must authenticate; running
a new experiment cannot retroactively recover missing historical source bytes.

## 10. Synthesis, closeout and verdict

Complete all four independent perspectives even if one reports a blocker. Parent
reviews shared conclusions and disagreements, closes reviewers, rechecks every
load-bearing source conclusion and produces one severity-ranked finding ledger.
For each finding state:

```text
ID / type / severity
owning contract or selected target
exact repository path and line range
source evidence and diagnostic result (or explicit non-execution)
reachable impact and affected scope
smallest required correction, without performing it
uncertainty and limits
introduced regression, inherited issue, evidence gap or operational nonclaim
```

Specifically disposition SR-1 and SR-2 as confirmed, refuted with reasons, or
unresolved with an exact limitation. Keep diagnostics and safe source review
separate from alleged public or operational impact. Do not invent a changed
contract to accommodate current code. Do not assume a green suite resolves a
branch its tests do not cover.

Preserve limits: SQL pool quarantine/driver Close invocation is not proof of all
physical teardown or bounded close duration; two unconfirmed disposal responses
may retain capacity. The DB/sidecar budget is a detection boundary. Fixture
progress does not implement operational cross-restart write-uncertainty proof,
provider eligibility, public reliable Submit or native host qualification.

At closeout:
1. Clean only owned transient caches/fixtures, retaining exact audit inputs and
   useful logs. Never clean or repair the candidate or prior evidence.
2. Run the unchanged v2 recipe twice to new absent external outputs and require
   equality with Appendix B/opening bytes.
3. Recheck complete source/index posture and the material prior artifacts actually
   relied upon. Source-reference checks remain scoped, no whole-history ritual.
4. Retain a private duplicate report and self-excluding safe artifact inventory;
   record their hashes and any evidence/coverage gaps.
5. Deliver the entire decision-complete human-readable report INLINE. Local
   report files are supplementary, never a verdict-and-path replacement.

Return one ordinary verdict:
- `ACCEPT`: exact candidate eligible for a later separately instructed local
  commit gate; no unresolved blocker and complete required acceptance evidence.
- `REJECT`: confirmed blocking source/contract defect.
- `BLOCK`: evidence, capability or unresolved judgment prevents acceptance.
- `AUDIT_PROVENANCE_MISMATCH`: exact target/input provenance fails before behavior.

A report transport failure is `REPORT_INLINE_BLOCKED`, with no simultaneous
acceptance verdict. Do not use it merely to avoid a long but bounded report.

Include touched files (none in repository), exact commands/results and skip
inventory, assumptions, unresolved seams, retained artifacts, actual effects and
whether any authority/security widening was found. End with:

```text
SOURCE_REPOSITORY_NOT_MUTATED
SOURCE_REFS_NOT_UPDATED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PRS_NOT_MODIFIED
EXISTING_OTHER_SOURCE_CHECKOUTS_NOT_SYNCHRONIZED
RUNTIME_WIRING_NOT_PERFORMED
PUBLIC_RELIABLE_SUBMIT_NOT_ENABLED
CROSS_RESTART_OPERATIONAL_WRITE_UNCERTAINTY_GATE_NOT_IMPLEMENTED
NATIVE_INSTALLED_SOURCE_WITNESS_NOT_QUALIFIED_BY_THIS_SLICE
```

## 11. Embedded inputs

The source review in Appendix D is a cognitive-engineering review, not an owning
repository contract and not a dynamic test result. Its hypotheses must be checked.
The supplied implementation report is evidence, not self-acceptance. Appendix B
is the exact current target; Appendix C is source to copy unchanged, never guess
from a digest. Payload delimiters and the surrounding markdown are not part of
any payload's length or digest. Each payload begins immediately after its BEGIN
line's newline and has the declared byte length. One additional separator LF
precedes each END line and is not payload. This preserves the report's missing
terminal newline rather than silently normalizing it.

## Appendix A — Complete supplied implementation closeout

Bytes: `25521`

SHA-256: `065b1b7fd51a59548aa41cdcb2250de54e06f2c198fafe73a8431daaff63869b`

<BEGIN_APPENDIX_A_EXACT_BYTES>
`ES_PRIVATE_REPLAY_PROGRESS_IMPLEMENTATION_READY_FOR_FRESH_INDEPENDENT_AUDIT`

Implemented the K1 private original replay and durable claim progress slice in [ES-Private-Replay-Progress-v1](/Users/ds/Repositories/ES-Private-Replay-Progress-v1). All ten final commands passed on the frozen source. The full tree recorded **5,096 passing test identities, zero failures, and 39 skips**. Every immediate integrity check matched the frozen source and index.

[Review ZIP](/Users/ds/Repositories/ES-Private-Replay-Progress-Implementation-20261119-kadgzy4t/ES-Private-Replay-Progress-Implementation-Review.zip) · **718,150 bytes** · SHA-256 `bc4bc721f7aa0f02da9f2427625973e883a82fdc0988e4f587c2140792245cf3`. The ZIP is local and requires upload. The available attachment action supports pull requests only.

## Source and scope

The conversation opened at [the A1 checkout](/Users/ds/Repositories/ES-Original-Key-Read-Cleanup-v1). That checkout remains clean at `fd2115ca8f44a615627adb08926896a1e052dc30`, with the same refs, index, config, and tree as at opening. The implementation, tests, and manifest ran from the standalone progress checkout, whose Git directory and common directory both resolve to its own `.git`.

- **Candidate branch** `codex/private-replay-progress-v1`, upstream `origin/trunk_dev`
- **HEAD** `f1aa8b934cc26c16a966a110c7b408abdaeadce7`
- **Parent** `fb9ae55797d9fcc02863c23fe8d3e43d16eac542`
- **Committed tree** `8dd27f9acba98ed70d93736bdef8300ef1aba53f`, 427 tracked paths
- **K1 opening target** Both recipe runs reproduced the 1,331-byte opening manifest, SHA-256 `79c3554da0dbbb5c45677092aee07093ee3b5f10d306ed656a7e9922c6c7733b`. Its five source files matched the authenticated 420,293-byte K1 archive, SHA-256 `03dddf54b405e27fcdeafec2bc40165a2948d15be83a94ef5129c4d26b3c12d7`.
- **Final scope** 27 tracked modifications and the three authorized new files. The index still equals HEAD. Each check found zero ignored, staged, or unmerged paths. [Opening routing](/Users/ds/Repositories/ES-Private-Replay-Progress-Implementation-20261119-kadgzy4t/routing-opening.json) · [Closing routing](/Users/ds/Repositories/ES-Private-Replay-Progress-Implementation-20261119-kadgzy4t/routing-closing.json)

## Implementation and evidence

| Gate | Result |
|---|---|
| **P · Pooled reader prerequisite** | The same 8,912-byte regression exited 1 against the pinned reader with seam-only instrumentation and 0 against the repaired reader. The old reader caused fresh-context same-store read and CAS failures after real BEGIN or SELECT cancellation and after modeled loss of the response to real BEGIN. The repaired reader passed the actual five-second expiry, nil-response-after-expiry, exact-connection discard and rescue, double-withholding, and same-store follow-up cases. `loadClaimFresh` is byte-identical across its 1,077-byte function boundary. Its SHA-256 is `3a47f8b5e0c5bf7bec899987aa78fdf4ef48a585086d9eb975e576896ab4b61c`. [Reader contract](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1296) · [Red/green evidence](/Users/ds/Repositories/ES-Private-Replay-Progress-Implementation-20261119-kadgzy4t/phase1-v2) |
| **F / M · Format and migration** | Codec 4 uses scope 2 with the selected payload, envelope, AAD, and commitment domains. Tests independently assembled the framing, MACs, permit and establishment preimages, and deterministic test AEAD. The production publisher uses random-nonce GCM. Migration tests exercised genuine openings at schema 0–3, complete row and registry/counter/ledger witnesses, rollback, real COMMIT with lost response, and refusal of mixed or intermediate recovery. [Format contract](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md:787) · [Migration contract](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1639) |
| **L / R2 · Shared allocation** | Both selectors use one checked SQLite `BEGIN IMMEDIATE` count-and-exclusive-create path. Confirmed rollback and wrapper release precede FD transfer, permit consumption, and Seal. The final-slot tests ran across separate handles and a separate process. The child reached `SHARED_ALLOCATOR_READY` and `SHARED_ALLOCATOR_WON` in the final run. The result was one verified object and no 33rd name. Post-create refusal retained the inert name, closed the owned FD, and burned the permit. [Allocator contract](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1735) · [Allocator implementation](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/replay_custody_file.go:578) |
| **R / T / R1 · Original and progress** | The genuine miss uses the parsed delivery, real resolver, and PB1 producer. An occupied hit uses the retained original keys and the typed authenticated original. Tests exercised restart with key and input drift, a concurrent first winner, shared capacity, opposite-scope refusal, both initial phases, and the legal transition branches. Successors keep the physical rowid and complete original descriptor. The first reconciliation tuple survives a later first marker, provider progress, and stronger terminal evidence. [Private composer](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/reliable_submit_replay_private.go:262) · [Transitions](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1403) |
| **U / K1 · Invocation authority** | The operation-scoped child context and one-use borrow bind authentication, use, and recovery. The durable service classifies exact latest replay, conflict, and staleness before a new transition. Recovery after a real COMMIT with an injected lost response confirms ownership only on full expected-row equality. An advanced winner, absent or wrong-scope recovery row, unusable original, or canceled recovery leaves the invocation unknown and withholds projection. The two indistinguishable restart histories retained equal rows and sealed bytes. Each separately supplied later marker command committed once. Their earlier dispositions remained distinct. [K1 contract](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1625) · [Durable service](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/internal/reliablesubmit/durable_service.go:1193) |
| **N · Effect boundary** | The finite typed caller inventory and negative mutants passed. The fixture observed zero provider, staging, and EGS dependency contacts and empty staging and results roots. It exercised accepted fixture receipt projection, changed intent, cancellation, and an incompatible selector. Unknown-result behavior was exercised at the custody and durable-service boundary. Runtime and startup exclusion were checked by source reachability and the App/API gates. The public rejection and baseline unkeyed-submit tests passed. [Admission boundary](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/es_execution_admission_model.md:603) |

The conditional Workstream C guard was needed. I recorded its scope in the owner map before editing it. The synchronized-field inventory went from 5 to 32 exact entries, covering the per-custody lock and references to issuer-bound invocation state. The old permit wrapper’s three publisher references became four in the shared publisher, plus one in scope-2 reserve and two in scope-2 publish. Its existing scope-1 reserve reference stayed at one. The new wrapper has one reserve and three publish references. The shared allocation eligibility check added two references to the existing permit lock and one to its use flag. Resolver, hydration, aggregate, and package-state inventories kept their existing counts. [Owner map](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1783) · [Exact guard inventories](/Users/ds/Repositories/ES-Private-Replay-Progress-v1/es/admission/workstream_c_guardrails_test.go:2279)

The connection evidence establishes bounded quarantine through `database/sql`. Two unconfirmed disposal responses can leave the wrapper withheld and consume capacity. Physical-close timing and a machine-wide temporary-file sweep were outside the measurements. The database size check is a detection boundary. The 27 remaining reports under the task-owned `TMPDIR` were identified and removed along with the task-owned cache and scratch directories. [Cleanup record](/Users/ds/Repositories/ES-Private-Replay-Progress-Implementation-20261119-kadgzy4t/task-scratch-cleanup.json)

### Schema identities

| Version | Migration literal SHA-256 | Pinned-driver schema shape SHA-256 |
|---|---|---|
| 1, preserved | `9613ba74cd6573626277b1f04a20b9c3ec5f9edf8b6b7408e94cbb45edc32dcd` | `031abaada34a63834d3466081ed04afef6b7c9f55103cd2b57fe3033b8c45ef0` |
| 2, preserved | `9280a62450488dfa54907d268d693f3f7d4f0b78b9a3553a1b659206d2c970e9` | `944094f4e5fae102ea2882a076f580c69494678f41acedf9eaa971fe836eb280` |
| 3, preserved | `4dafddbf477fd7f64ad88cf2b1e2b2becb378827e81cd6cc694456798c9a00be` | `15ab48bde4d53bb252dc954a2aa3b1db12de7295111f23bb0264f74f153dba92` |
| 4, appended | `879b24ac563d37ccdd1bdb5ec13c923b93213f2caea69a1110281796e20e667e` | `2ae4721c8526ed9b8de35fd3acdfa31448eae9b547ba8662a22ed130035f7c15` |

**Distinct old-binary probes.** The preserved historical PB1/schema-2 binary is 14,350,930 bytes, SHA-256 `b205a31bac091cbcf5b3f4826bc359455625316908051131733622813e34adcf`. It refused the authenticated schema-3 target in its own test. The separately built previous-schema-3 opener is 15,601,186 bytes, SHA-256 `42614a50812a65ba52b53488d872884e59ce7b4f57dece6a66642d4eb8de1409`. It used the verified 427-leaf PR #10 source export and one test overlay. It emitted `SCHEMA3_REFUSED_SCHEMA4` against a target populated with all four codecs. Nonmigrating witnesses agreed across the full logical state and both sealed originals. The compiled-input inventory binds 1,354 unique inputs and has SHA-256 `50a81fa5a042e135abfc9f6bad68d20abc4575f881945ecc84252c14910dde8f`. [PB1 authentication](/Users/ds/Repositories/ES-Private-Replay-Progress-Implementation-20261119-kadgzy4t/historical-pb1/authentication.json) · [Schema-3 build inputs](/Users/ds/Repositories/ES-Private-Replay-Progress-Implementation-20261119-kadgzy4t/schema3-probe/compiled-and-export-inputs.json)

## Final frozen validation

Go reported `go1.26.5 darwin/arm64`. The environment used Python 3.13.4 with `tomllib`, OpenSSL 3.6.2, cached modules at `/Users/ds/go/pkg/mod`, `GOTOOLCHAIN=local`, `GOPROXY=off`, `GOSUMDB=off`, `GOWORK=off`, `GOFLAGS=-mod=readonly`, `CGO_ENABLED=0`, and `GOTELEMETRY=off`. Both probe paths were pinned by size and SHA-256. The probe tests supplied `ES_REPLAY_PB1_TARGET` and `ES_REPLAY_SCHEMA3_TARGET` to their respective child processes. [Environment and validation records](/Users/ds/Repositories/ES-Private-Replay-Progress-Implementation-20261119-kadgzy4t/final-generation-2)

| Command | Exit | Test identities passed / failed / skipped |
|---|---:|---:|
| 1 · Go version | 0 | — |
| 2 · Read-only formatting | 0 | Clean |
| 3 · Diff whitespace check | 0 | Clean |
| 4 · Contract documentation | 0 | 22 / 0 / 0 |
| 5 · Pooled reader | 0 | 16 / 0 / 0 |
| 6 · Storage, custody, and historical probes | 0 | 136 / 0 / 0 |
| 7 · Admission and effect boundary | 0 | 18 / 0 / 0 |
| 8 · App/API contract | 0 | 2 / 0 / 0 |
| 9 · Four-package run | 0 | 1,971 / 0 / 39 |
| 10 · Full tree | 0 | 5,096 / 0 / 39 |

All named parents ran. Each command had its own post-command observation of all 430 paths, file modes and bytes, both untracked listings, HEAD, branch, upstream, and index. The observations independently reproduced SHA-256 `e71aa89b78da8a5bd5985d05237140602a8facdf47b13d5de2d366a2557e5347`. The index SHA-256 stayed `1c6218366e333383b205833fce0ceaa5d462fa7264cf51cbdcd35aa05855b018`.

The full tree had 21 test-bearing packages and 20 packages without tests. The four-package pass counts were admission 1,048, reliable-submit 489, API 33, and App 401. The other counts were root 2,230, `ags/app` 24, `ags/publish` 1, `ars/app` 64, `cgs/app` 31, `cgs/policy` 4, `egs/app` 19, `es/config` 70, `es/internal/outsideobserverprotocol` 549, `es/internal/ownershipnorm` 5, `es/internal/staticarchive` 14, its `testcorpus` 9, `es/runtimehelper` 81, `internal/contracts/evidence/v1` 4, `internal/contracts/runtimeconfig/v1` 6, `internal/httpx` 7, and `internal/observability` 7.

The 39 skips comprise 37 App capability cases and two direct helper sentinels. The capability reasons were 34 failed Docker daemon probes, one reachability requirement for Slice 0 bringup, one healthy-daemon integration prerequisite, and one unavailable direct Docker Unix socket for the mounted-source witness. The two sentinels were `TestPrivateReplayObjectAllocatorHelperProcess` and `TestSQLiteClaimStoreLockHelperProcess`. The allocator parent independently proved its helper executed. The additional sentinel accounts for the extra skip relative to the historical 38. [Counts and reasons by test identity](/Users/ds/Repositories/ES-Private-Replay-Progress-Implementation-20261119-kadgzy4t/final-generation-2/summary.json)

The first frozen generation also passed all ten commands. I refroze and reran after tightening closed-issuer handling and adding direct assertions for parser limits, migration recovery, and absent or wrong-scope recovery rows. Retained development failures include the corruption fixture’s stale trigger restoration, a test hook signature mismatch, and stale source inventories for the shared publisher and package file set. Those failures were corrected before the final generation.

<details>
<summary>Exact final argv, in execution order</summary>

```sh
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go version
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/gofmt -d docs_contract_test.go es/admission/internal/reliablesubmit/sqlite_store.go es/admission/internal/reliablesubmit/sqlite_replay_claim.go es/admission/internal/reliablesubmit/sqlite_migrations.go es/admission/internal/reliablesubmit/sqlite_replay_progress_schema.go es/admission/internal/reliablesubmit/sqlite_replay_shape.go es/admission/internal/reliablesubmit/durable_record.go es/admission/internal/reliablesubmit/durable_operation.go es/admission/internal/reliablesubmit/durable_service.go es/admission/internal/reliablesubmit/replay_custody_format.go es/admission/internal/reliablesubmit/replay_custody_structure.go es/admission/internal/reliablesubmit/replay_custody_file.go es/admission/reliable_submit_replay_format.go es/admission/reliable_submit_replay_hydration.go es/admission/reliable_submit_replay_private.go es/admission/internal/reliablesubmit/sqlite_pooled_claim_read_cleanup_test.go es/admission/internal/reliablesubmit/replay_progress_test.go es/admission/internal/reliablesubmit/replay_custody_file_test.go es/admission/internal/reliablesubmit/sqlite_store_test.go es/admission/internal/reliablesubmit/sqlite_physical_test.go es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go es/admission/internal/reliablesubmit/sqlite_replay_shape_test.go es/admission/internal/reliablesubmit/guardrails_test.go es/admission/reliable_submit_guardrails_test.go es/admission/reliable_submit_replay_private_test.go es/admission/workstream_c_guardrails_test.go
git --no-pager diff --check
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateOriginalReplayProgressContractSelection|TestReliableSubmitPersistenceAndConcurrencyADRDocsContract|TestSubmitIdempotencyCorrelationAndRecoveryDocsContract|TestReliableSubmitPureModelDocsAndSourceContract|TestReliableSubmitPublicOptInAndVersioningDocsContract|TestReliableSubmitContractAdapterFoundationDocsAndSourceContract|TestReliableSubmitBindingProducerDocsContract|TestIntegratedAcceptanceGateDocumentationIsConsistent|TestIntegratedCandidateStatusSeparatesCAndT)$' .
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^TestSQLitePooledClaimReadCleanup$' ./es/admission/internal/reliablesubmit
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateReplaySharedObjectAllocation|TestReplayPublicationFaultAndIdentity|TestPrivateReplayProgressFormatVectors|TestPrivateReplayProgressTransitions|TestPrivateReplayProgressConcurrencyAndCommitOutcome|TestSQLiteV4MigrationPreservesFullState|TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation|TestSQLiteV3OldBinaryRefusesWithoutMutation|TestSQLiteLegacyCASConnectionCleanup|TestReplayOriginalKeyReadCleanup|TestReplayOriginalKeyReadCallerRefusal|TestReplayGrantC1PreCommitConnectionQuarantine|TestReplayGrantD1BeginResponseLossQuarantine|TestReplayKeyStateD1BeginResponseLossQuarantine|TestReliableSubmitPrivatePersistenceStaticGuardrails)$' ./es/admission/internal/reliablesubmit
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestPrivateReplayProgressAdmissionReplay|TestPrivateReplayProgressHasNoEffectPaths|TestReliableSubmitFoundationHasNoRuntimeWiring|TestReliableSubmitBindingProducerHasNoProductionCaller|TestPrepareRequestShapeRemainsLegacyAndUnkeyed|TestResolvedSubmitLegacyEquivalenceOneNomadRegistrationAndAuthorityRecovery)$' ./es/admission
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=180s -run '^(TestWorkstreamCContractPrepareAndSubmitRemainSeparatedAtAPIBoundary|TestSubmitPublicRouteRejectsStructuralReliableBody)$' ./es/api ./es/app
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=600s ./es/admission/internal/reliablesubmit ./es/admission ./es/api ./es/app
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -mod=readonly -count=1 -p=1 -json -timeout=600s ./...
```

</details>

## Review packet and canonical manifest

The 36-entry ZIP contains all 30 complete source files, the two patches, the source map, the canonical manifest, a README, and the self-excluding delivery inventory. The HEAD patch independently reconstructed the 27 tracked modifications. The opening-to-implementation patch independently reconstructed all 30 files. Both checks verified sizes, hashes, and `0644` modes. The final ZIP verification checked every member’s name, regular-file type, mode, and bytes. [Delivery receipt](/Users/ds/Repositories/ES-Private-Replay-Progress-Implementation-20261119-kadgzy4t/review-packet-receipt.json)

| Artifact | SHA-256 |
|---|---|
| Recipe `governed-execution.audit-patch-manifest.v2`, 7,275 bytes | `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` |
| Canonical manifest, 6,813 bytes, both runs identical | `110cef71ba25f61b70297b37cc5a50a68732d639845e0ac4315d06cedcdbc1e3` |
| Tracked full-index HEAD diff | `e45e3bd85391191702673b2d40fc2d06d865503004e09a8094c2f6a7081fe0c4` |
| Contract-opening delta | `631ee93e57691352f099cee09d32cd958772960784c6eb2b3c6dc0e35fad97e0` |
| Source map | `d214f2e5cef18a4a40c4826a4ae027e1f822ae240bcade7b94e02cd91b59e566` |
| Delivery inventory | `2c5e906cccbe078b39df283b109dd9c6d9342bada0b3d30753c87450314f2109` |

[Manifest A](/Users/ds/Repositories/ES-Private-Replay-Progress-Implementation-20261119-kadgzy4t/implementation-manifest-a.json) · [Manifest B](/Users/ds/Repositories/ES-Private-Replay-Progress-Implementation-20261119-kadgzy4t/implementation-manifest-b.json)

<details>
<summary>All 30 canonical file entries</summary>

The manifest’s HEAD, branch, upstream, recipe, and diff hash appear above. Every file entry has type `regular` and mode `0644`.

| Repository path | Kind | Bytes | SHA-256 |
|---|---|---:|---|
| `.docs/execution_lifecycle/es_execution_admission_model.md` | tracked_modified | 80361 | `03f03a378beecb53f4c996022ef004e892922bbfd69972d3887ba618dd26011c` |
| `.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md` | tracked_modified | 156221 | `6e69af309b665e6769590a1206df4e2ff6d244ebe2446d88458bcb4570fa2c66` |
| `.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md` | tracked_modified | 102166 | `5640ab0307e251eb304258a1017509c6ed0f9021210931f808c9854b99d818c0` |
| `PLANS.md` | tracked_modified | 300922 | `cf7c3fc49c71ee62a5c6121c9154f7c3fafeaa667a6bf6a711e380e812a88477` |
| `docs_contract_test.go` | tracked_modified | 791928 | `4d9c5cda8bf6b768cbda818c1f8583e2b3954abf6a49cd2c8effa3141afe946d` |
| `es/admission/internal/reliablesubmit/durable_operation.go` | tracked_modified | 9548 | `b7761f001a1f67349ed51f2b79012194a7d45bb19c79e0ca2c0c22b8227320f9` |
| `es/admission/internal/reliablesubmit/durable_record.go` | tracked_modified | 25226 | `999db7db6550c5031b023a9613825504e30e971a179298cc43e09cf8c5c5d7cd` |
| `es/admission/internal/reliablesubmit/durable_service.go` | tracked_modified | 47166 | `caa5139671d91f18e269256dc11ea12cb949c2737f0d9eb81fb0afa2cb529232` |
| `es/admission/internal/reliablesubmit/guardrails_test.go` | tracked_modified | 30905 | `9812c719dd31b594c59dbf6daf47dc43fdac1bdb483346d0ec0be83b1688f4ea` |
| `es/admission/internal/reliablesubmit/replay_custody_file.go` | tracked_modified | 50001 | `8eeac273d6db099ef15c68021e48c6f013253088b83f4318ce530acc52151cea` |
| `es/admission/internal/reliablesubmit/replay_custody_file_test.go` | tracked_modified | 66823 | `3e6fcca31873ba5d54b0f4ee389e09a2613eb38269c217f00078c43bcf63e167` |
| `es/admission/internal/reliablesubmit/replay_custody_format.go` | tracked_modified | 16488 | `b8cb8e31edd9d854317a0d6a456f25d5ab1838498623881e429dec2155e1ea67` |
| `es/admission/internal/reliablesubmit/replay_custody_structure.go` | tracked_modified | 18640 | `4916268757b93d409cbc13ba9c0da14e009499b4db7cadd52bc7ccd47c6a86ad` |
| `es/admission/internal/reliablesubmit/replay_progress_test.go` | untracked | 43192 | `470bd6250f0c34800a2c099e96fbe5fd0b43398296b82904a0e56ff7f85b6f7f` |
| `es/admission/internal/reliablesubmit/sqlite_migrations.go` | tracked_modified | 17407 | `7736e30a1d0c6e9584d9050cc6ebf8bfaf900d424f764ebe61af8ec8ddaec0c9` |
| `es/admission/internal/reliablesubmit/sqlite_physical_test.go` | tracked_modified | 14539 | `2c125b6373f83467d542db45473cc79b888ed3a665e65ef6bf013655f461a7ba` |
| `es/admission/internal/reliablesubmit/sqlite_pooled_claim_read_cleanup_test.go` | untracked | 8912 | `0ec3060ed3c30a6327ec49b0291d5c761c20894986c9b6b1e1be384694312823` |
| `es/admission/internal/reliablesubmit/sqlite_replay_claim.go` | tracked_modified | 8301 | `8ddec89b4ca5702591bdf2060062016d7fb54264fc7df57af5ead1d161eb9de3` |
| `es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go` | tracked_modified | 20291 | `953c87d23f80d5ecbd78507b1a81b2ce9f861c84eb811273e1a0f40c7d5242b4` |
| `es/admission/internal/reliablesubmit/sqlite_replay_progress_schema.go` | untracked | 30612 | `132d8ab87f5658cab3477b9f6913538013ba922d4768192a96be960df7bbb149` |
| `es/admission/internal/reliablesubmit/sqlite_replay_shape.go` | tracked_modified | 2588 | `043cc868afe925e51df77cfca5246004f86feac6fd1dab17be4bb00138e175a7` |
| `es/admission/internal/reliablesubmit/sqlite_replay_shape_test.go` | tracked_modified | 7230 | `b8742a0aeb31b7777a357a6375eb140d7355afd9a69786316da550044ce00eb1` |
| `es/admission/internal/reliablesubmit/sqlite_store.go` | tracked_modified | 63712 | `520dd8f39a32dea946b66620ed48058084ad255aefbc43b167c62b900822222f` |
| `es/admission/internal/reliablesubmit/sqlite_store_test.go` | tracked_modified | 57339 | `c99e7659b1059431911557ba43ef7fa982e373bba939f610bd41ea0622cee96f` |
| `es/admission/reliable_submit_guardrails_test.go` | tracked_modified | 50444 | `a8f7938c6d5efd4d1600ade03bfca46d1cb89a7a46ea48b33b9590b79ce3b851` |
| `es/admission/reliable_submit_replay_format.go` | tracked_modified | 17326 | `0a21803b03308332613481f89ce4b595512b31b073c56b31fe7d8000519c3beb` |
| `es/admission/reliable_submit_replay_hydration.go` | tracked_modified | 28800 | `b5ff16b96178c45b53165ebb2bcbdc67991bb145276ca4a11a598f1430745b9c` |
| `es/admission/reliable_submit_replay_private.go` | tracked_modified | 20253 | `20ea7b2682bf8be47f03924342fe87c0d8326b8fce7ed8afdfb57cec95a9f934` |
| `es/admission/reliable_submit_replay_private_test.go` | tracked_modified | 39376 | `9a1ca86e26438c90a372b64cf50cb704c97444b48556bedfa891b1722aafbeef` |
| `es/admission/workstream_c_guardrails_test.go` | tracked_modified | 297009 | `68f2fe4e31e5d862be161c3ba1071a511935b32e90cf9021755fe4dcb045fab5` |

</details>

```text
INDEPENDENT_ACCEPTANCE_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PRS_NOT_MODIFIED
EXISTING_OTHER_SOURCE_CHECKOUTS_NOT_SYNCHRONIZED
LOADCLAIMFRESH_LIFECYCLE_PRESERVED
CROSS_RESTART_OPERATIONAL_WRITE_UNCERTAINTY_GATE_NOT_IMPLEMENTED
RUNTIME_WIRING_NOT_PERFORMED
PUBLIC_RELIABLE_SUBMIT_NOT_ENABLED
NATIVE_INSTALLED_SOURCE_WITNESS_NOT_QUALIFIED_BY_THIS_SLICE
```
<END_APPENDIX_A_EXACT_BYTES>

## Appendix B — Exact canonical thirty-file target

Bytes: `6813`

SHA-256: `110cef71ba25f61b70297b37cc5a50a68732d639845e0ac4315d06cedcdbc1e3`

<BEGIN_APPENDIX_B_EXACT_BYTES>
{"branch":"codex/private-replay-progress-v1","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/es_execution_admission_model.md","sha256":"03f03a378beecb53f4c996022ef004e892922bbfd69972d3887ba618dd26011c","size":80361},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md","sha256":"6e69af309b665e6769590a1206df4e2ff6d244ebe2446d88458bcb4570fa2c66","size":156221},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md","sha256":"5640ab0307e251eb304258a1017509c6ed0f9021210931f808c9854b99d818c0","size":102166},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"cf7c3fc49c71ee62a5c6121c9154f7c3fafeaa667a6bf6a711e380e812a88477","size":300922},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"4d9c5cda8bf6b768cbda818c1f8583e2b3954abf6a49cd2c8effa3141afe946d","size":791928},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_operation.go","sha256":"b7761f001a1f67349ed51f2b79012194a7d45bb19c79e0ca2c0c22b8227320f9","size":9548},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_record.go","sha256":"999db7db6550c5031b023a9613825504e30e971a179298cc43e09cf8c5c5d7cd","size":25226},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/durable_service.go","sha256":"caa5139671d91f18e269256dc11ea12cb949c2737f0d9eb81fb0afa2cb529232","size":47166},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/guardrails_test.go","sha256":"9812c719dd31b594c59dbf6daf47dc43fdac1bdb483346d0ec0be83b1688f4ea","size":30905},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_file.go","sha256":"8eeac273d6db099ef15c68021e48c6f013253088b83f4318ce530acc52151cea","size":50001},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_file_test.go","sha256":"3e6fcca31873ba5d54b0f4ee389e09a2613eb38269c217f00078c43bcf63e167","size":66823},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_format.go","sha256":"b8cb8e31edd9d854317a0d6a456f25d5ab1838498623881e429dec2155e1ea67","size":16488},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_structure.go","sha256":"4916268757b93d409cbc13ba9c0da14e009499b4db7cadd52bc7ccd47c6a86ad","size":18640},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_progress_test.go","sha256":"470bd6250f0c34800a2c099e96fbe5fd0b43398296b82904a0e56ff7f85b6f7f","size":43192},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_migrations.go","sha256":"7736e30a1d0c6e9584d9050cc6ebf8bfaf900d424f764ebe61af8ec8ddaec0c9","size":17407},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_physical_test.go","sha256":"2c125b6373f83467d542db45473cc79b888ed3a665e65ef6bf013655f461a7ba","size":14539},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_pooled_claim_read_cleanup_test.go","sha256":"0ec3060ed3c30a6327ec49b0291d5c761c20894986c9b6b1e1be384694312823","size":8912},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_claim.go","sha256":"8ddec89b4ca5702591bdf2060062016d7fb54264fc7df57af5ead1d161eb9de3","size":8301},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_migration_test.go","sha256":"953c87d23f80d5ecbd78507b1a81b2ce9f861c84eb811273e1a0f40c7d5242b4","size":20291},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_progress_schema.go","sha256":"132d8ab87f5658cab3477b9f6913538013ba922d4768192a96be960df7bbb149","size":30612},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_shape.go","sha256":"043cc868afe925e51df77cfca5246004f86feac6fd1dab17be4bb00138e175a7","size":2588},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_shape_test.go","sha256":"b8742a0aeb31b7777a357a6375eb140d7355afd9a69786316da550044ce00eb1","size":7230},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_store.go","sha256":"520dd8f39a32dea946b66620ed48058084ad255aefbc43b167c62b900822222f","size":63712},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_store_test.go","sha256":"c99e7659b1059431911557ba43ef7fa982e373bba939f610bd41ea0622cee96f","size":57339},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_guardrails_test.go","sha256":"a8f7938c6d5efd4d1600ade03bfca46d1cb89a7a46ea48b33b9590b79ce3b851","size":50444},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_format.go","sha256":"0a21803b03308332613481f89ce4b595512b31b073c56b31fe7d8000519c3beb","size":17326},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_hydration.go","sha256":"b5ff16b96178c45b53165ebb2bcbdc67991bb145276ca4a11a598f1430745b9c","size":28800},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_private.go","sha256":"20ea7b2682bf8be47f03924342fe87c0d8326b8fce7ed8afdfb57cec95a9f934","size":20253},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_replay_private_test.go","sha256":"9a1ca86e26438c90a372b64cf50cb704c97444b48556bedfa891b1722aafbeef","size":39376},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/workstream_c_guardrails_test.go","sha256":"68f2fe4e31e5d862be161c3ba1071a511935b32e90cf9021755fe4dcb045fab5","size":297009}],"head":"f1aa8b934cc26c16a966a110c7b408abdaeadce7","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"e45e3bd85391191702673b2d40fc2d06d865503004e09a8094c2f6a7081fe0c4","upstream":"origin/trunk_dev"}

<END_APPENDIX_B_EXACT_BYTES>

## Appendix C — Exact v2 provenance recipe source

Bytes: `7275`

SHA-256: `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`

<BEGIN_APPENDIX_C_EXACT_BYTES>
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
import sys
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v2"


def fail(message: str) -> "NoReturn":
    raise SystemExit(message)


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env.update(
        {
            "LC_ALL": "C",
            "LANG": "C",
            "GIT_OPTIONAL_LOCKS": "0",
            "GIT_NO_LAZY_FETCH": "1",
            "GIT_TERMINAL_PROMPT": "0",
            "GIT_PAGER": "cat",
        }
    )
    result = subprocess.run(
        [
            "git",
            "--no-pager",
            "-c",
            "core.fsmonitor=false",
            "-c",
            "core.untrackedCache=false",
            *args,
        ],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


def validate_output_path(output_path: Path, repository_root: Path) -> None:
    if not output_path.is_absolute():
        fail("output path must be absolute")

    parent = output_path.parent
    parent_metadata = parent.lstat()
    if not stat.S_ISDIR(parent_metadata.st_mode) or stat.S_ISLNK(parent_metadata.st_mode):
        fail("output parent must be a nonsymlink directory")
    if parent_metadata.st_uid != os.getuid():
        fail("output parent must be owned by the current user")
    if stat.S_IMODE(parent_metadata.st_mode) & 0o022:
        fail("output parent must not be group- or world-writable")

    try:
        output_path.lstat()
    except FileNotFoundError:
        pass
    else:
        fail("output path already exists")

    repository_text = os.path.realpath(os.fspath(repository_root))
    output_text = os.path.realpath(os.fspath(output_path))
    try:
        common = os.path.commonpath([repository_text, output_text])
    except ValueError:
        common = ""
    if common == repository_text:
        fail("output path must be outside the repository")


def write_exclusive(output_path: Path, payload: bytes) -> None:
    flags = (
        os.O_WRONLY
        | os.O_CREAT
        | os.O_EXCL
        | getattr(os, "O_NOFOLLOW", 0)
        | getattr(os, "O_CLOEXEC", 0)
    )
    fd = os.open(os.fspath(output_path), flags, 0o600)
    try:
        view = memoryview(payload)
        while view:
            written = os.write(fd, view)
            if written <= 0:
                fail("short provenance-output write")
            view = view[written:]
        os.fsync(fd)
    finally:
        os.close(fd)

    metadata = output_path.lstat()
    if not stat.S_ISREG(metadata.st_mode) or stat.S_ISLNK(metadata.st_mode):
        fail("provenance output is not a regular nonsymlink file")
    if metadata.st_uid != os.getuid():
        fail("provenance output owner mismatch")
    if stat.S_IMODE(metadata.st_mode) != 0o600:
        fail("provenance output mode mismatch")
    if metadata.st_nlink != 1:
        fail("provenance output link-count mismatch")
    if metadata.st_size != len(payload):
        fail("provenance output size mismatch")

    read_flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_CLOEXEC", 0)
    read_fd = os.open(os.fspath(output_path), read_flags)
    try:
        observed = bytearray()
        while len(observed) <= len(payload):
            chunk = os.read(read_fd, min(1 << 20, len(payload) + 1 - len(observed)))
            if not chunk:
                break
            observed.extend(chunk)
    finally:
        os.close(read_fd)
    if bytes(observed) != payload:
        fail("provenance output byte mismatch")


if len(sys.argv) != 2:
    fail("usage: governed_execution_audit_patch_manifest_v2.py ABSOLUTE_OUTPUT_PATH")

repository_root = Path(git_text("rev-parse", "--show-toplevel"))
output_path = Path(sys.argv[1])
validate_output_path(output_path, repository_root)

head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    fail("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            fail(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()

write_exclusive(output_path, canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")

<END_APPENDIX_C_EXACT_BYTES>

## Appendix D — Complete static source review and supporting source excerpts

Bytes: `34748`

SHA-256: `5417cd22d9bcb794522dcca80f1cfc5ace6654edb8d43892ba0c9f3bbc5d5b6f`

<BEGIN_APPENDIX_D_EXACT_BYTES>
# Private original replay and durable progress — exact-source pre-audit review

Date: 2026-11-19
Reviewer: ChatGPT, cognitive engineering review of supplied artifacts.
Posture: static source and artifact inspection only. No repository code, tests,
migration, probe, Git command, patch application, or live-service operation was run.

## Decision

Keep the exact candidate frozen and proceed to one fresh independent Codex audit.
Do not stage or commit. The audit should independently adjudicate SR-1 and SR-2
below and inspect the rest of the integrated slice in the same pass.

The uploaded source is sufficient to identify two implementation/owner-contract
mismatches. Their control flow is directly inspectable; the concrete diagnostic
outcomes below are predictions, not tests performed by ChatGPT. These findings
are not an independent Codex acceptance verdict. Neither establishes a public
exploit, a provider effect, or an unsafe durable mutation.

No architectural reset is selected. K1's per-invocation uncertainty/current-state
distinction, R1 historical observations, R2 shared allocation and R3 old-opener
origin remain the accepted fixture-only design. The independent auditor must
challenge these findings if the actual owning contract or reachable caller
semantics contradict them, rather than assume this review is infallible.

## Exact target and artifact verification

Archive: ES-Private-Replay-Progress-Implementation-Review.zip
Bytes: 718150
SHA-256: bc4bc721f7aa0f02da9f2427625973e883a82fdc0988e4f587c2140792245cf3

Candidate:
- checkout: /Users/ds/Repositories/ES-Private-Replay-Progress-v1
- branch: codex/private-replay-progress-v1
- upstream: origin/trunk_dev
- HEAD: f1aa8b934cc26c16a966a110c7b408abdaeadce7
- HEAD parent: fb9ae55797d9fcc02863c23fe8d3e43d16eac542
- HEAD tree: 8dd27f9acba98ed70d93736bdef8300ef1aba53f
- source target: 27 tracked modifications and three untracked additions
- source target total: 430 leaves after combining the 427-leaf base and additions

Canonical manifest: 6813 bytes
SHA-256: 110cef71ba25f61b70297b37cc5a50a68732d639845e0ac4315d06cedcdbc1e3
Tracked HEAD patch SHA-256:
e45e3bd85391191702673b2d40fc2d06d865503004e09a8094c2f6a7081fe0c4
Contract-opening delta SHA-256:
631ee93e57691352f099cee09d32cd958772960784c6eb2b3c6dc0e35fad97e0
Source map SHA-256:
d214f2e5cef18a4a40c4826a4ae027e1f822ae240bcade7b94e02cd91b59e566
Delivery inventory SHA-256:
2c5e906cccbe078b39df283b109dd9c6d9342bada0b3d30753c87450314f2109

Independent archive checks completed:
- Exactly 36 uniquely named regular-file entries, no absolute/traversal paths,
  links, directories masquerading as source, or special objects.
- All 35 entries covered by the self-excluding inventory match complete bytes,
  length, type and archived mode. The inventory's own hash matches the report.
- All 30 complete source files match their canonical rows; all are archived 0644.
- Canonical JSON serialization reproduces the exact 6813 bytes and digest.
- All 30 implementation rows in source-map.json equal the canonical rows.
- The five contract-opening rows match the previously reviewed K1 archive.
- The tracked HEAD patch's 27 paths, target Git blob identities and 165 target-side
  hunks match the complete delivered files.
- The incremental unified patch's 30 paths and 175 target-side hunks match the
  complete delivered files. Its 20 old-side hunks in the five K1 files match the
  prior K1 packet.
- These are byte comparisons, not patch application. The remaining baseline
  leaves and live refs/index are not independently authenticated by this ZIP.
- Migration 4's exact literal is 30468 bytes and hashes to
  879b24ac563d37ccdd1bdb5ec13c923b93213f2caea69a1110281796e20e667e.
  The driver-produced shape digest remains reported evidence, not recomputed here.
- The reported 1077-byte loadClaimFresh slice, including its trailing blank line,
  reproduces SHA-256
  3a47f8b5e0c5bf7bec899987aa78fdf4ef48a585086d9eb975e576896ab4b61c.
  This does not independently validate every helper on its call path.

Raw validation logs, independent runtime measurements, opener binaries, and
complete historical compiled-input inventories are not in the 36-entry source
packet. They remain material evidence for Codex to authenticate locally.

## Coverage and limits

This is a targeted, exact-source pre-audit review, not a claim of exhaustive
independent certification of all 430 leaves. Inspection included:
- Complete K1-to-implementation document/assertion changes and governing plan.
- The finite facade, issuer/context/borrow/attempt lifetime, authentication,
  confirmed projection, current reload and admission composition paths.
- The new durable-service dispatch, latest-operation classification, no-op,
  CAS/recovery and result-projection paths; R1 operation and row predicates.
- Pooled-reader exit/disposal ordering and the shared count/create allocator.
- Migration orchestration, appended schema-4 SQL, shape validation, raw storage
  hydration and original-preserving successor construction.
- Format dispatch, bounds, typed view, commitment and operation encoding.
- Relevant progress, reader, migration, caller, allocator and guard-inventory tests.

The static review did not independently execute the advertised 5096/0/39 run,
its helper process, schema probes, historical red/green, or migration behavior.
Unchanged source outside the packet, exact pinned driver internals, all live
workspace state, and raw private logs remain for the independent audit.

## SR-1 — establishment-confirmation projection omits operation-entry key recheck

Type: contract/security-boundary enforcement gap.
Suggested severity: high within this bounded custody slice; independent auditor
must assign final severity and verdict.
Evidence status: direct source branch plus static reachability; not dynamically
reproduced here.

Owner contract:
- submit_idempotency_correlation_and_recovery.md:907 requires ReadFixtureProgress
  to check live issuer-bound access, keys and context and reread/match identity.
- :923–932 requires exact active-or-retired original keys to be rechecked on
  operation entry; revoked/missing/mismatched/wrong-purpose keys refuse.
- :911–921 permits projection of a known insertion's committed snapshot after
  authentication. That is not an explicit exemption from key eligibility.

Source:
- replay_custody_file.go:1267–1277 places an establishment attempt's expected row
  in the `confirmed` field, for known commit or uncertain-attempt confirmation.
- :1304–1307 issues an access containing that field.
- ReadFixtureProgress at :1340–1357 consumes the live one-use access. If
  confirmed.progressRowID != 0, it checks only c.qualified(ctx) and returns
  fixtureProgressProjection(state.confirmed).
- That branch skips state.reload. The ordinary branch's reload at :1360–1377
  rereads the row and invokes checkOriginalReplayKeys.
- c.qualified at :1081–1082 checks issuer, request, parent identity and the
  fixture database budget, not registry eligibility.

Predicted counterexample:
1. Create a legitimate scope-2 original and obtain a known-committed
   establishment attempt (repeat separately for a recoverable lost response).
2. Complete initial original authentication.
3. Before entering ReadFixtureProgress, commit revocation of an original key
   through an independent permitted fixture handle.
4. Invoke ReadFixtureProgress on the establishment-confirmation access.
5. The confirmed branch has no key read and can project its stored snapshot;
   the ordinary current-read branch would check the revoked registry pair.

This is not an instantaneous-revocation claim: the proposed negative orders the
revocation COMMIT before the progress-read method's entry. It also does not
require substituting a later row's progress for the permitted committed snapshot.
Operation eligibility and which snapshot may be projected are separate concerns.

Required independent adjudication:
- Exercise active, retired and revoked controls.
- Exercise both known establishment and recoverable uncertain establishment.
- Require no projection after a fully committed pre-entry revocation according
  to the owner rule.
- Preserve the already known write disposition; failure to disclose cannot
  retroactively undo a known commit.
- Assess the exact selected uncertainty disposition if confirmation fails.
- Do not mislabel the defect as a new claim mutation, Seal, or public disclosure.

The delivered tests cover retirement/revocation before a fresh general operation
and closed/copied/escaped access. I did not find a test for the confirmed-branch
pre-entry revocation sequence in the inspected new tests.

Smallest likely correction, if independently confirmed:
Revalidate key and immutable-original eligibility at confirmation-read entry,
while keeping the permitted committed snapshot and invocation disposition.
No new state authority, key lifecycle, schema or runtime behavior is needed.

## SR-2 — historical reconciliation can be accepted as a fresh no-op after its
## current evidence predicate has become false

Type: durable-service semantic/contract mismatch.
Suggested severity: medium.
Evidence status: direct source path and valid-state counterexample; not run here.

Owner contract:
- persistence ADR:1471–1480 allows a same-fact no-op at the current revision ONLY
  if that kind's current evidence predicates still hold.
- :1482–1490 requires Pending/Ambiguous/Inconsistent recording to originate from
  candidate phases 3/4/5 with compatible current provider facts.
- Their retained historical tuples may legitimately coexist with terminal
  phases. Retaining history is not permission to issue the observation again.

Source:
- durable_service.go:402–457, recordReconciliationEvidence checks run, intent,
  valid kind/fact and two progress-specific conditions (NoDispatch and a negative
  evidence case).
- At :443–445, identical stored kind/ref immediately returns the current record,
  before phaseForReconciliation or a general when-recorded predicate check.
- mutateFixtureProgress at :1206–1226 distinguishes latest replay and stale
  predecessor first, then turns an equal `apply` result into FixtureProgressNoChange
  with a projection.
- A fresh mutation at the current revision is therefore not protected by the
  old-command stale rule.

Predicted counterexample:
1. Establish, assign, record intent and marker; record Pending reconciliation.
2. Advance with valid positive acceptance to phase 6. The earlier Pending tuple
   is intentionally retained by R1.
3. Freshly authenticate and issue op 7 with that same Pending fact, the exact
   current revision, and a new mutation reference.
4. It is neither exact latest replay nor stale.
5. The equality branch returns the terminal record as a successful NoChange,
   although the Pending recording predicate requires a candidate phase.

The same issue should be checked for Ambiguous/Inconsistent and for provider
progress that makes the original recording condition false while history remains
valid. This predicts no new durable mutation; the mismatch is an ineligible
command being reported as a valid no-op (and possibly projecting terminal refs).

Required independent adjudication:
- Test fresh current-revision/new-mutation commands after terminal advancement.
- Preserve legitimate same-fact no-ops while the current predicate still holds.
- Preserve exact latest-operation replay and separately verify stale old inputs.
- Verify no storage mutation in either the accepted control or refused negative.
- Do not repair this by dropping the historical tuple or reviving the R1 phase trap.

Smallest likely correction, if confirmed:
Validate the codec-4 kind-specific current evidence predicate before returning
the same-fact no-op, while retaining legacy codec behavior and latest replay
precedence. No architecture or migration redesign follows from this finding.

## Other mandatory audit attention, not additional adjudicated defects

1. Migrations: distinguish exact source/literal/shape identity from row/data
   preservation. Verify opening authentication at the actual transaction boundary,
   complete migration copies, changed migration-error classification, recovery,
   foreign keys and older opener refusal. The present review does not elevate a
   schema digest into a full database-content witness.

2. Custody lifetime: the structural synchronization inventory grows from 5 to 32
   typed entries. It includes references, not 32 new locks. Verify actual lock and
   close ordering, one-use token behavior, canceled and copied contexts, and
   trusted-callback ordering. The inventory is evidence, not lifecycle proof.

3. Unknown result composition: audit the outer admission error/disposition
   mapping as well as internal service tests. A missing end-to-end assertion
   must be distinguished from an unsafe source path.

4. CAS-loss and no-write return paths: check authentication/identity/key
   requirements on exact replay, no-op, stale, occupied and known CAS loss, not
   only applied/unknown writes. Verify whether any claimed reauthentication is
   actually full original validation or only a row/key read.

5. Shared allocator: both scopes, after-create faults, permit burn, raw descriptor
   ownership, exact discard/withholding and helper execution. Maintain no-adoption
   and no-refund. A filesystem name is not rolled back by SQLite.

6. Original and state semantics: the original-preserving successor and
   sameProgressOriginal checks retain codec, rowid, claim, plan/witness, creation
   identity and all replay fields. Validate exact input digests and every
   transition, not just equality of a few projected fields.

7. Preserve historical codec-1/2, immutable codec 3, migrations 1–3, A1/F1/O2/C1/D1,
   old vectors, public refusal, unkeyed Submit and no runtime reachability.

## Reported validation (not independently rerun)

Final generation 2 reports 10 passing commands and full-tree 5096 pass identities,
zero failures, 39 skips, 21 tested packages and 20 no-test packages. The extra
skip is the direct allocator helper sentinel; its parent reportedly ran and
checked the separate child. Verify the parent markers and assertions rather
than treating a direct helper skip as either a product pass or a missing proof.

The first full frozen generation also passed, followed by source tightening and
a second frozen validation. Acceptance must bind the final generation and the
actual final test/source bytes, including the retained reader differential.

## Recommended next action

Start a fresh read-only Codex audit on the exact progress checkout. Confirm or
refute SR-1/SR-2 with bounded audit-owned diagnostics, while all independent
reviewers inspect the complete slice. The current writer does not repair it first.
This batches additional findings and preserves a clean independent assessment.

If a substantive blocker is confirmed, the auditor may omit the expensive
full-suite rerun, explain exactly what was not run, and return REJECT/BLOCK after
completing all relevant source perspectives. No ACCEPT is possible without the
complete required independent validation and material evidence authentication.

After that audit, the same foreground audit conversation may perform a later
explicitly instructed repair. Any repaired bytes then need fresh independent
acceptance. No commit, push, PR or runtime effect is authorized now.

## Confidence and boundary

Packet/manifest identity: 0.99.
SR-1 static mismatch: 0.94, pending independent contract interpretation and
bounded dynamic confirmation.
SR-2 static mismatch: 0.98, pending independent dynamic confirmation.
Whole implementation correctness: not accepted.
Operational qualification: none.

Sources are the exact uploaded ZIP, its complete source files, the prior
accepted K1 contract ZIP and implementation brief, plus the supplied
implementation closeout for reported tests and workspace state.

## Appendix — exact line-numbered source excerpts

### `.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md:898–944`

Complete-file SHA-256: `5640ab0307e251eb304258a1017509c6ed0f9021210931f808c9854b99d818c0`

```text
898: | Method and inputs | Output and required authority check |
899: | --- | --- |
900: | `OpenPrivateReplayProgressCustody(ctx, root)` | Opaque `PrivateReplayProgressCustody` using existing fixture root, file and schema checks. Closed or canceled custody refuses. |
901: | `LookupProgressOriginal(ctx, claimID)` | Opaque `ProgressLookup` of validated absent, compatible locator or occupied/refused. Issuer-bound locator permits only exact original key IDs to the injected catalog. Identity and strict parsed delivery precede lookup. No phase/ref/dependency disclosure. |
902: | `FreezeProgressOriginal(ctx, miss, initialPhase, boundPlan, keys, ProgressOriginalInput)` | Opaque `ProgressFrozen` after checking same issuer/claim, absent lookup, initial fixture phase 1 or 2, bounded typed fields, full witness and scope. The admission input comes from the resolver/assessment on the same parsed fixture delivery. |
903: | `ReserveProgressSealUse(ctx, frozen)` | Opaque `ProgressSealPermit` only after known durable reservation COMMIT for the exact active purpose/fingerprint pair and frozen digest. Uncertain COMMIT grants no permit. |
904: | `PublishProgressOriginal(ctx, frozen, permit)` | Opaque `ProgressPublication` for one exclusive, identity-checked and synced file. Verify issuer, frozen digest, object association and active eligibility, consume permit before Seal and retain any orphan. No refund. |
905: | `EstablishProgress(ctx, frozen, publication)` | Opaque `ProgressAttempt` and created, occupied or write-unknown disposition. Validate full issued binding, exact active registry pair in write transaction and existing caller/key occupation. Retain the expected full record and generated rowid inside the owning establishment invocation for its bounded recovery. |
906: | `WithAuthenticatedProgressOriginal(ctx, locator, retainedKeys, incomingIntent, purpose, verify, use)` | Repaired pooled read matches the locator's full immutable identity. Check both retained keys in one snapshot, then securely open exact file, verify descriptor/AEAD/commitments and decode fixed `ProgressOriginalView` (identity, typed intent with presence, plan, material, PB1 assessment, image, placement, provenance, formats). The sole admission verifier validates semantic domains, recanonicalizes and recomputes PB1. Custody compares its returned `ProgressOriginalMatch` (claim, recomputed bound plan/witness and reconstructed canonical typed intent) with authenticated data and compares incoming canonical intent in constant time. Mismatch refuses before `use`. Match grants a synchronous opaque `ProgressAccess` to the sole admission continuation. |
907: | `ReadFixtureProgress(ctx, access)` | `FixtureProgress` with revision, fixture phase and phase-appropriate fixture run/receipt. Check live issuer-bound borrow, keys and context, reread through repaired pooled reader, match complete immutable identity. Current projection leaves any earlier write disposition unchanged. |
908: | `ApplyFixtureProgress(ctx, access, expectedRevision, fixtureMutation, FixtureProgressCommand)` | Finite ADR outcome and eligible fixture projection. Same live access, key and identity checks and one existing durable-service conditional transition and CAS. The command union and historical reconciliation are defined in ADR §15B.3. A separately supplied command uses a new live one-use borrow and its exact revision and mutation input. The service rechecks the current-row fixture predicate for a new same-run marker in CAS and separately validates positive terminal fixture evidence. Kind 1 records a bounded fixture no-marker observation and supplies no operational permission. |
909: | `Close()` | Closes only the issuing custody. Outstanding borrows become invalid. |
910: 
911: The closed authentication purpose is current replay or establishment
912: confirmation with the issued `ProgressAttempt` within the owning
913: establishment invocation. The attempt expires when that invocation returns
914: or is canceled and supplies no restart input. Confirmation checks the
915: attempt issuer/claim before reading and compares the opaque expected full
916: initial record to the authenticated row. It returns only the comparison's
917: finite disposition, invoking `use` for progress only when the ADR permits
918: disclosure. Known created, definite occupied and write-unknown cases retain
919: their distinct dispositions. An uncertain attempt never discloses a
920: different winner. A known successful insert's committed snapshot is
921: eligible only after authenticating the same immutable original.
922: 
923: Each borrow allows one progress read or mutation, including its bounded
924: recovery. Its lifetime ends on return or cancellation. Capabilities never
925: authorize another row, scope or issuer. The boundary has no full plaintext
926: buffer, raw store, full-record getter or verified boolean. The typed view
927: carries only bounded admission input. The single invocation cannot export a
928: plaintext buffer, extend its lifetime or turn fixture evidence into a
929: provider or staging capability. Recheck exact active or retired
930: original keys on operation entry and recheck them in the write transaction
931: before CAS. Revoked, missing, changed fingerprint and wrong-purpose keys
932: refuse. There is no instantaneous cross-process revocation guarantee.
933: 
934: K1 limits an invocation's recovery to authenticating an exact full expected
935: record to confirm its own write. Failed recovery preserves unknown, withholds
936: its projection and starts no second write, new mutation or rebase. Failed
937: post-commit authentication preserves known commit and withholds projection.
938: A later explicit command or authenticated current-state read uses fresh
939: authentication and its own live borrow. It cannot change the earlier
940: disposition. A fixture marker is a current-state transition only. No
941: marker, read, exact latest replay or fixture outcome supplies operational
942: permission. The full operational Validated No-Dispatch Evidence requirement
943: in the persistence ADR §8 remains unchanged. Its cross-restart evidence
944: and authority are outside this fixture operating model.
```

### `.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1471–1498`

Complete-file SHA-256: `6e69af309b665e6769590a1206df4e2ff6d244ebe2446d88458bcb4570fa2c66`

```text
1471: Use the existing single kind/ref/time tuple as the first reconciliation
1472: observation of one attempt. No new fields, supersession or history table.
1473: Kinds 1/2/3/6 describe the state when recorded. Current phase, marker,
1474: provider and receipt give the current decision. Ops 5, 6, 8 and 9 preserve
1475: every byte of the prior reconciliation tuple including kind and timestamp.
1476: Op 7 can fill an empty tuple only. An identical fact at current revision
1477: may return a validated no-op only if the kind's current evidence predicates
1478: still hold, with no new evidence of COMMIT. After a marker, kind 1 cannot
1479: return that no-op. A differing tuple is refused. Replaying an older reconciliation command never refreshes
1480: the observation or claims history-wide write proof.
1481: 
1482: | Reconciliation kind | Op 7 conditions and phase when recorded | Legal phase and relation on later reads |
1483: | --- | --- | --- |
1484: | 0 Absent | Initial tuple is `0/NULL/NULL`. Op 7 never writes kind 0. | May stay absent in any phase. Terminal phase still needs its positive decision fact. |
1485: | 1 NoDispatch (fixture no-marker observation) | Authenticated active phase-3 row, exact run and predecessor, committed intent and no marker/provider. Stays at 3. | Without marker, phase 3 and provider absent. With marker, phase 3 or 4–7. The observation time is no later than marker time. The old absence supplies no operational authority or evidence of a past write disposition. |
1486: | 2 Pending | Candidate 3/4/5, marker present. Provider absent or kind 1. Record at resulting phase 4. | Phases 4–7 with marker. Retain the original tuple, including on transition to stronger evidence. |
1487: | 3 Ambiguous | Candidate 3/4/5, marker present. Provider absent or kind 2/5. Record at resulting phase 5. | Phases 4–7 with marker, same tuple. |
1488: | 4 Accepted | Add to existing phase 6 with marker, provider kind 3 and receipt. No new terminal decision. | Phase 6 only, same marker, provider and receipt. |
1489: | 5 NotAccepted | With marker and positive same-attempt negative evidence, move candidate 3/4/5 with absent provider to 7, or corroborate existing 7 with provider kind 4. No receipt. | Phase 7 only, same marker, provider absent or kind 4. |
1490: | 6 Inconsistent | Candidate 3/4/5, marker present. Provider absent or kind 2/5. Record at resulting phase 5. | Phases 4–7 with marker, same tuple. |
1491: 
1492: Every nonzero tuple needs assigned run and committed intent, with
1493: reconciliation time no earlier than intent time. Kinds 2–6 also require
1494: the observation time to be no earlier than the marker time. Provider
1495: kind 1 requires phase 4, kinds 2/5 require phase 5, kind 3 requires
1496: phase 6 and kind 4 requires phase 7. Nonzero provider needs the immutable
1497: marker and fact time at or after that marker. Op 6 only fills an empty
1498: provider tuple. With no provider yet, op 6 can advance either nonterminal
```

### `es/admission/internal/reliablesubmit/replay_custody_file.go:1081–1083`

Complete-file SHA-256: `8eeac273d6db099ef15c68021e48c6f013253088b83f4318ce530acc52151cea`

```text
1081: func (c *PrivateReplayProgressCustody) qualified(ctx context.Context) bool {
1082: 	return c.self == c && ctx.Err() == nil && c.custody != nil && c.custody.checkParents() == nil && c.custody.checkFixtureDBBudget() == nil
1083: }
```

### `es/admission/internal/reliablesubmit/replay_custody_file.go:1263–1278`

Complete-file SHA-256: `8eeac273d6db099ef15c68021e48c6f013253088b83f4318ce530acc52151cea`

```text
1263: 	original := l.original
1264: 	status := FixtureProgressCurrent
1265: 	confirmed := durableClaimRecord{}
1266: 	exact := false
1267: 	if attempt := purpose.token; attempt != nil {
1268: 		if attempt.issuer != c || !l.claim.Equal(attempt.record.claim) ||
1269: 			!progressSameInvocation(ctx, attempt.owner) || !attempt.used.CompareAndSwap(false, true) {
1270: 			return FixtureProgressRefused, errClaimStoreUnavailable
1271: 		}
1272: 		original, status = attempt.record, attempt.disposition
1273: 		exact = status == FixtureProgressWriteUnknown
1274: 		if exact && !attempt.recoverable {
1275: 			return status, errClaimStoreCommitUnknown
1276: 		}
1277: 		confirmed = attempt.record
1278: 	} else if !l.found {
```

### `es/admission/internal/reliablesubmit/replay_custody_file.go:1300–1315`

Complete-file SHA-256: `8eeac273d6db099ef15c68021e48c6f013253088b83f4318ce530acc52151cea`

```text
1300: 	}
1301: 	if exact {
1302: 		status = FixtureProgressOwnCommitConfirmed
1303: 	}
1304: 	life := &progressOriginalLifetime{ctx: ctx}
1305: 	access := &ProgressAccess{}
1306: 	access.state = &progressAccessState{self: access, issuer: c, life: life, original: r, confirmed: confirmed, keys: k, verify: verify}
1307: 	defer life.closed.Store(true)
1308: 	if err := use(access); err != nil {
1309: 		if exact {
1310: 			return FixtureProgressWriteUnknown, errClaimStoreCommitUnknown
1311: 		}
1312: 		return status, err
1313: 	}
1314: 	return status, nil
1315: }
```

### `es/admission/internal/reliablesubmit/replay_custody_file.go:1328–1378`

Complete-file SHA-256: `8eeac273d6db099ef15c68021e48c6f013253088b83f4318ce530acc52151cea`

```text
1328: func (c *PrivateReplayProgressCustody) consumeProgressAccess(ctx context.Context, access *ProgressAccess) (*progressAccessState, error) {
1329: 	if c == nil || access == nil || access.state == nil {
1330: 		return nil, errClaimStoreUnavailable
1331: 	}
1332: 	state := access.state
1333: 	if state.self != access || state.issuer != c || !state.life.live() || !progressSameInvocation(ctx, state.life.ctx) ||
1334: 		!state.used.CompareAndSwap(false, true) {
1335: 		return nil, errClaimStoreUnavailable
1336: 	}
1337: 	return state, nil
1338: }
1339: 
1340: func (c *PrivateReplayProgressCustody) ReadFixtureProgress(ctx context.Context, access *ProgressAccess) (FixtureProgress, error) {
1341: 	state, err := c.consumeProgressAccess(ctx, access)
1342: 	if err != nil {
1343: 		return FixtureProgress{}, err
1344: 	}
1345: 	if state.confirmed.progressRowID != 0 {
1346: 		c.mu.RLock()
1347: 		defer c.mu.RUnlock()
1348: 		if !c.qualified(ctx) {
1349: 			return FixtureProgress{}, errClaimStoreUnavailable
1350: 		}
1351: 		return fixtureProgressProjection(state.confirmed), nil
1352: 	}
1353: 	r, err := state.reload(ctx)
1354: 	if err != nil {
1355: 		return FixtureProgress{}, err
1356: 	}
1357: 	return fixtureProgressProjection(r), nil
1358: }
1359: 
1360: func (s *progressAccessState) reload(ctx context.Context) (durableClaimRecord, error) {
1361: 	c := s.issuer
1362: 	c.mu.RLock()
1363: 	defer c.mu.RUnlock()
1364: 	if !s.life.live() || !c.qualified(ctx) {
1365: 		return durableClaimRecord{}, errClaimStoreUnavailable
1366: 	}
1367: 	r, err := c.custody.store.loadClaim(ctx, loadClaimQuery{claim: s.original.claim})
1368: 	if err != nil || !s.original.sameProgressOriginal(r) || !progressKeysMatch(r.replay, s.keys) {
1369: 		return durableClaimRecord{}, errClaimStoreUnavailable
1370: 	}
1371: 	if err := c.custody.store.checkOriginalReplayKeys(ctx, s.keys, false); err != nil {
1372: 		return durableClaimRecord{}, err
1373: 	}
1374: 	if ctx.Err() != nil || !s.life.live() || c.custody.checkFixtureDBBudget() != nil {
1375: 		return durableClaimRecord{}, errClaimStoreUnavailable
1376: 	}
1377: 	return r, nil
1378: }
```

### `es/admission/internal/reliablesubmit/durable_service.go:402–457`

Complete-file SHA-256: `caa5139671d91f18e269256dc11ea12cb949c2737f0d9eb81fb0afa2cb529232`

```text
402: func (s *durableClaimService) recordReconciliationEvidence(ctx context.Context, req recordReconciliationEvidenceRequest) (durableClaimOutcome, error) {
403: 	return s.mutate(ctx, mutationRequest{
404: 		progress:         req.progress,
405: 		claim:            req.claim,
406: 		binding:          req.binding,
407: 		expectedRevision: req.expectedRevision,
408: 		mutation:         req.mutation,
409: 		operationKind:    durableOperationRecordReconciliationEvidence,
410: 		operationInput: func() []durableOperationInputPart {
411: 			return []durableOperationInputPart{
412: 				operationPartRunRef(req.run),
413: 				operationPartUint16(durableOperationPartReconciliationKind, uint16(req.kind)),
414: 				operationPartFactRef(req.reconciliation),
415: 			}
416: 		},
417: 		authorize: func(record durableClaimRecord) bool {
418: 			return req.progress == nil || req.kind != durableReconciliationNotAccepted || req.evidence.matches(record)
419: 		},
420: 		successKind: durableClaimOutcomeReconciliationRecorded,
421: 		apply: func(record durableClaimRecord, nowUTC time.Time, operation durableLatestOperationDescriptor) (durableClaimRecord, error) {
422: 			if err := validateRecordRunRef(record, req.run); err != nil {
423: 				return durableClaimRecord{}, err
424: 			}
425: 			if !record.effects.intent.present() {
426: 				return durableClaimRecord{}, errInvalidDurableRecord
427: 			}
428: 			if req.kind == durableReconciliationInvalid {
429: 				return durableClaimRecord{}, errInvalidDurableRecord
430: 			}
431: 			if !req.reconciliation.valid() {
432: 				return durableClaimRecord{}, errInvalidDurableRecord
433: 			}
434: 			if req.progress != nil {
435: 				if req.kind == durableReconciliationNoDispatch && !progressCurrentNoMarker(record) {
436: 					return durableClaimRecord{}, errInvalidDurableRecord
437: 				}
438: 				if req.kind == durableReconciliationNotAccepted &&
439: 					record.phase.tag != durablePhaseProvablyNotAcceptedAfterAssignment && record.effects.provider.present() {
440: 					return durableClaimRecord{}, errInvalidDurableRecord
441: 				}
442: 			}
443: 			if record.effects.reconciliation.present() {
444: 				if record.effects.reconciliation.kind == req.kind && record.effects.reconciliation.fact.ref.equal(req.reconciliation) {
445: 					return record, nil
446: 				}
447: 				return durableClaimRecord{}, errInvalidDurableRecord
448: 			}
449: 			effects := record.effects.clone()
450: 			effects.reconciliation = durableReconciliationFact{kind: req.kind, fact: newDurableEffectRefTime(req.reconciliation, nowUTC)}
451: 			phase, err := phaseForReconciliation(record, req.kind)
452: 			if err != nil {
453: 				return durableClaimRecord{}, err
454: 			}
455: 			return record.withPhaseAndOperation(phase, operation, nowUTC, record.assignedAt, effects, record.retention)
456: 		},
457: 	})
```

### `es/admission/internal/reliablesubmit/durable_service.go:1193–1227`

Complete-file SHA-256: `caa5139671d91f18e269256dc11ea12cb949c2737f0d9eb81fb0afa2cb529232`

```text
1193: func (s *durableClaimService) mutateFixtureProgress(ctx context.Context, req mutationRequest) (durableClaimOutcome, error) {
1194: 	state := req.progress
1195: 	record, err := state.reload(ctx)
1196: 	if err != nil {
1197: 		return durableClaimOutcome{}, err
1198: 	}
1199: 	if req.authorize != nil && !req.authorize(record) {
1200: 		return durableClaimOutcome{}, errClaimStoreUnavailable
1201: 	}
1202: 	op, err := deriveDurableOperationDescriptor(req.mutation, req.operationKind, req.expectedRevision, req.operationInput()...)
1203: 	if err != nil {
1204: 		return durableClaimOutcome{}, err
1205: 	}
1206: 	classify := func(r durableClaimRecord) (durableClaimOutcome, bool) {
1207: 		switch compareDurableLatestOperation(r.latestOperation, op) {
1208: 		case durableOperationReplayExact:
1209: 			return fixtureMutationResult(FixtureProgressExactReplay, r), true
1210: 		case durableOperationReplayConflict:
1211: 			return fixtureMutationResult(FixtureProgressConflict, durableClaimRecord{}), true
1212: 		}
1213: 		if r.revision != req.expectedRevision {
1214: 			return fixtureMutationResult(FixtureProgressStale, durableClaimRecord{}), true
1215: 		}
1216: 		return durableClaimOutcome{}, false
1217: 	}
1218: 	if out, done := classify(record); done {
1219: 		return out, nil
1220: 	}
1221: 	next, err := req.apply(record, s.now(), op)
1222: 	if err != nil {
1223: 		return durableClaimOutcome{}, err
1224: 	}
1225: 	if next.equal(record) {
1226: 		return fixtureMutationResult(FixtureProgressNoChange, record), nil
1227: 	}
```


<END_APPENDIX_D_EXACT_BYTES>
