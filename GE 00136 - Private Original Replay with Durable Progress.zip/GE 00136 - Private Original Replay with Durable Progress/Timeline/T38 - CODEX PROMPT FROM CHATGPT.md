# Execution Substrate — Post-PR #11 Operational Submit Contract Selection and Snapshot

Checkpoint: 2026-11-19 (America/New_York)
Posture: repository-read-only design/reconnaissance and committed-source snapshot export.
No implementation, tests, operational effects, or repository/remote mutation.

## 1. Objective and decision boundary

PR #11 has completed source publication of private original replay with durable
progress. Do not repeat its acceptance, cleanup repairs, commit, publication or
merge campaigns. The next critical path is to make the first operational
reliable-submit handoff and restart model decision-ready before enabling ingress
or connecting any fixture result to an effect.

Produce ONE recommended, source-grounded operating model, not an open-ended list
of possible features. Resolve the relationship among durable write uncertainty,
exclusive first-dispatch ownership, current original/key eligibility, staging,
provider acceptance evidence, and restart recovery. Name exact authoritative
inputs and the facts each writer may change. Propose a bounded next doc-first
implementation slice and its acceptance evidence. This turn proposes that
contract; it does not make it current by writing a report.

Also export the exact completed PR #11 committed tree as a new project snapshot.
This is an architecture-defining checkpoint, not a new acceptance test. Snapshot
creation is a supporting output of this same turn, not a separate prerequisite
that requires another user relay before you can inspect source and design.

The primary functional objective remains reliable submission of one governed
execution with stable caller/key correlation and no duplicate provider dispatch
on redelivery or restart. Keep the distinction between acceptance of a submit,
execution lifecycle, and semantic work acceptance. Do not add another generic
fixture-only progress vocabulary, broad scheduler, queue, or work programme.

## 2. Conversation routing, effects and preserved repositories

Continue in the SAME foreground Codex conversation that completed PR #11's merge.
The conversation may still be associated with the older A1 workspace. Use explicit
working directories; it is not permission to change A1 or move either checkout.

Primary read-only source:

    /Users/ds/Repositories/ES-Private-Replay-Progress-v1

At most three bounded read-only explorers may inspect complementary source
surfaces. Give each an explicit pin and scope. They must not run product tests,
create source changes, invoke the provider or inspect operational secrets. The
foreground parent reconciles their reports, verifies the load-bearing claims,
closes every explorer and delivers the consolidated report. Do not switch to a
source-writing phase in this turn.

Authorized effects:
- ordinary read-only local Git/object/source inspection with optional locks and
  lazy fetch disabled;
- bounded read-only official GitHub/Git metadata and immutable source reads;
- one fresh, user-owned external output directory and its snapshot, sidecar,
  design record, evidence index and safe duplicate report;
- offline parsing/hashing/archive verification of committed source and supplied
  evidence, never execution of repository scripts or fixture payloads;
- read-only official provider documentation or pinned provider source when needed
  for a consequential design claim. Record versions and citations. Do not infer
  provider guarantees from memory or from a fake-provider test.

Not authorized: repository source/doc/test/config changes; staging; commits;
fetch/pull into any existing checkout; branch/ref/upstream changes; clone/worktree
creation; reset/restore/stash/clean; pushes or PR writes; comments/review-state
changes; policy changes; test/build/diagnostic/probe execution; dependency download
or installation; Docker/VM/SSH/service contact; live or fixture migration runs;
operational database access; real-key reading/provisioning; runtime wiring;
deployment; external-effect authorization. This is not a new audit or a request
to repair the accepted observation-pool close residual.

Other ES, A1, O2 and replay-custody checkouts, Coordinator, supplementary repos,
shared caches and all historical evidence roots remain untouched. Do not scan or
fingerprint those roots merely because they exist. GE's core components are ES
and Coordinator. CP is historical/demo compatibility, not a new orchestration
peer. IM/MA are supplementary. Bridge, reports and snapshots own no run truth.

## 3. Exact checkpoint and opening source binding

    Repository: evo-agi/Execution-Substrate
    Official origin: git@github.com:evo-agi/Execution-Substrate.git
    PR: 11 (merged)
    Squash: ae326b0ddc30ec6b35883ee32945c622405b68b6
    Squash sole parent: f1aa8b934cc26c16a966a110c7b408abdaeadce7
    Squash subject: Add private original replay with durable progress (#11)
    Complete accepted tree: e066cd4afa77fcb665f31b69bf00465989f9744e
    Complete tree leaf count: 430

    Preserved local/remote topic: codex/private-replay-progress-v1
    Preserved source commit: dbdc433283617b9e3b233f75c92f1179c2ece91f
    Source sole parent: f1aa8b934cc26c16a966a110c7b408abdaeadce7
    Source tree: e066cd4afa77fcb665f31b69bf00465989f9744e
    Expected upstream: origin/codex/private-replay-progress-v1
    Historical local origin/trunk_dev: f1aa8b934cc26c16a966a110c7b408abdaeadce7

Appendix A is the complete supplied merge closeout. Authenticate its framed
bytes. Its private report/index pair is:

    /Users/ds/Repositories/ES-Private-Replay-Progress-PR11-Merge-Gate-20261119-20VzJnFU/report.md
    201502d98a85b0a961f5a81121e40e8a9169e12e4a652851c030caf2d154914b
    /Users/ds/Repositories/ES-Private-Replay-Progress-PR11-Merge-Gate-20261119-20VzJnFU/artifact-index.json
    d404df048de2e3c9a8e32ba51d453595aca047ae8ef931ec1cf11c546fe7154e

Read/authenticate that pair and only the material source/merge identity records
actually used. There is no instruction to recursively rehash historical test
logs, probe inputs, audit histories or generated caches. Source equality and
merge identity, rather than the number of past evidence files, bind this pass.
Reports are evidence, not permission to reinterpret source contracts.

Read the actual local physical root, Git/common directory, named branch/HEAD,
upstream, index and complete tracked/untracked/ignored inventories. Use committed
objects for design and export, never an uncommitted overlay. Verify source commit
parent/tree and official merged PR/squash identity. A missing LOCAL squash object
is NOT a blocker: after proving the published squash and preserved local source
have the same complete tree, inspect/export local source commit dbdc433... and
label that provenance accurately. Do not fetch simply to make the squash local.

Observe official trunk and topic at opening and closing. If remote trunk has
advanced, record that drift and keep this checkpoint pinned; complete the
read-only design where possible, flag the new-base reconciliation needed before
a future mutation, and do not silently choose a new baseline. Likewise unrelated
Codex session-ref churn is not source drift. If the named source cannot be bound
to the accepted tree, stop using it; report the actual discrepancy rather than
resetting/copying/repairing a checkout. Dirty working files are not permission to
use them as committed source or discard them.

The old pre-stage v2 manifest f92b57f4... and its untracked classifications remain
historical. Do not rerun that patch recipe on the clean committed checkout and
expect the old bytes. A new deterministic snapshot sidecar records committed
objects. It is evidence, not a replacement for the accepted audit target.

## 4. Read the controlling sources together

Read AGENTS.md and the current PLANS.md first, then the relevant architecture,
source, tests, scripts, examples and configuration. The top of the merged plan
still contains pre-acceptance wording. Record PR #11 publication as an explicitly
supported overlay; do not report the historical rejection as the current status
or silently edit the plan. Propose the minimal status correction with the next
owner-contract change, not a standalone cosmetic PR.

Required governing surfaces:
- .docs/system_overview/boundaries.md and relevant change-governance/capability
  guidance;
- .docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:
  storage/deployment boundaries, §8 (including all twelve no-dispatch conditions),
  operation/replay/crash semantics, §15A, §15B and §16;
- .docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md:
  current behavior, caller identity, key and RunRef disclosure, §6B fixture facade,
  §7–13 and required-before-implementation/open-seam sections;
- .docs/execution_lifecycle/es_execution_admission_model.md including §7.4 and
  the rejected-A3 exclusions; relevant lifecycle contracts/design/implementation;
- current supported-local consumer and supported-Linux qualification docs, only
  for the selected topology and later acceptance gates.

Required implementation trace:
- es/api/server.go authorized decoding/Submit/authenticated identity and tests;
- es/config/config.go, es/app/app.go and relevant startup/config tests;
- es/admission/service.go, submit.go (ordinary Submit and nomadClient.submitJob),
  executionlocator.go, resolved_execution_plan.go, replay identity/format/
  hydration/private composer and public reliable-request refusal;
- existing internal durable model, records, operation identity, service,
  SQLite/schema/migrations, custody, key-use and shared allocator;
- staging/root qualification, materialization, job-spec construction and lifecycle
  provider queries, with their tests and caller inventories;
- docs_contract_test.go and relevant reliable-submit/Workstream C guardrails;
- .examples/config/es.json, scripts/40_submit.sh, provider startup/config examples
  and runbooks as evidence of current installation/version choices, not design
  authority. Inspect scripts; do not run them.

Starting anchors at the pinned tree (re-find after inspection):
- PLANS.md:5–80: source candidate/status and explicit operational deferral.
- persistence ADR:419–527: external I/O ordering and full no-dispatch predicate.
- persistence ADR:1602–1654: invocation outcome versus later fixture command and
  explicit separate operational gate.
- persistence ADR:1968–2004: nonclaims and runtime open decisions.
- submit/recovery:891–961: finite private fixture interface and nonconversion.
- submit/recovery:963–1078: narrow correlation, provider reconciliation,
  authorization and retention semantics.
- es/admission/submit.go:36–115 and :257–289: existing ordinary effect path and
  registration client; these are compatibility behavior, not a reliable adapter.
- es/api/server.go:129–145: existing handler delegates and returns accepted.

Each explorer should report exact paths/lines, source truth versus target,
contradictions, and its inspection limits. Parent synthesis must resolve actual
conflicts rather than collect three independent feature proposals.

## 5. One operational design, with these decisions made explicit

### A. Bounded target and version boundary

Recommend the smallest supported first target: one ES installation, one qualified
local state domain, a bounded caller/profile/job class and no HA, backup restore,
automatic expiry/GC, key reuse, remote orchestrator or automatic semantic retry.
Verify the owning docs' supported host/profile instead of inferring current host
qualification. Source design and fake-provider evidence must not depend on live
Linux restoration or running a stack in this turn.

Do not relabel codec-3/codec-4 synthetic rows, borrows, receipts or fixture markers
as operational. Recommend an explicit version/scope and migration/compatibility
boundary for any later operational state. Distinguish reusable algorithms from
non-convertible stored fixture facts. Do not select another database, history
store or phase algebra merely to make an implementation convenient. Explain any
new durable field and its single owner.

### B. Cross-restart uncertainty and permission to act

This is the critical decision. The current §8 rule requires known relevant write
dispositions, while §15B intentionally implements only invocation-local recovery
and later current-state fixture operations. An absent marker, latest-operation
match or invocation token alone is not the missing operational authority.

Provide one concrete recommendation, with a comparison to the smallest credible
alternative. Either identify finite durable ES-owned evidence/explicitly governed
input that satisfies the existing operational predicate, or explicitly propose
its re-derivation with a safety argument. Do not quietly weaken §8. Do not assume
that a response-history ledger is necessary without showing the minimum facts
that the chosen proof needs. Do not infer old COMMIT disposition from a later
current row. Preserve historical unknown responses even where a separately
proved current action may be safe under a proposed new contract.

For every fact used, name who creates it, when it is durable, how restart reads
it, how an uncertain write affects it, and why it cannot be fabricated by a
caller flag, a report, memory or Coordinator. Include the indistinguishable-
history case from K1: histories yielding identical retained facts and identical
fresh inputs cannot acquire different eligibility through an unrecorded fact.
If the selected safety model deliberately refuses some histories indefinitely,
state that liveness loss and its recovery treatment plainly.

### C. Exclusive first-dispatch ownership and concurrency

A single configured process is not itself a proof against concurrent requests,
old callbacks or overlapping replacement processes. A row CAS does not by itself
explain the authority to perform external I/O after that transaction ends.
Specify exactly who can send the first request after a known marker COMMIT and
how competing requests, cancellation, stale holders and restart are excluded.
Specify what remains in force between commit and send. Keep external I/O outside
the SQLite transaction. Do not revive the rejected A3 lock/registry/lease/poison
model implicitly; name and justify any genuinely different ownership mechanism.

Keep one claim/attempt and stable RunRef. No new key/run/attempt, ordinary Submit
fallback, re-registration or automatic second POST may be inferred from an
ambiguous outcome or provider absence. A committed marker followed by a crash
before send is a required ambiguity case, not a loophole for automatic redispatch.
Explain separately the initial request, same-key concurrent request, same-process
redelivery and restart paths.

### D. Staging and immutable material

Trace the existing custody/materialization call graph. Define the necessary
ordering from original authentication to assigned run, effect intent, staging
ownership, dispatch marker and provider I/O. Classify material reads versus
execution-producing staging. State whether the first operational slice can
refuse partial existing stages instead of repairing them. Do not assume a
pathname, old directory, metadata annotation or current material defaults prove
ownership or equivalence. Preserve original binding/material semantics and
current compatibility behavior on unkeyed Submit.

### E. Provider submission and reconciliation evidence

Identify the actual provider client/version and source contracts available.
Recommend precise creation/collision semantics, namespace/job locator, redirect
and transport-retry treatment, response acceptance evidence, bounded lookup and
same-job identity checks. An HTTP response, EvalID or arbitrary job metadata is
not sufficient by assertion; explain what the selected provider contract proves.
Separate an accepted submission from running/completed work and from Coordinator
semantic acceptance. Generic absence, timeout, transport failure and weak/stale
reads do not prove non-acceptance after a possible send.

Use primary official documentation/pinned source for external semantics if they
are needed. Record their exact version and unsupported gaps. A fake provider must
exercise the selected semantics but cannot establish the real provider's API
or consistency guarantees. If a provider guarantee cannot be established here,
keep that guarantee a named unresolved dependency; do not broaden this turn into
an installation, live probe or redesign of Nomad.

### F. Ingress, startup, credentials and disclosure

Specify the minimal dependency contract, not a configuration-first implementation:
verified canonical caller identity, authorization before existence disclosure,
structural keyed opt-in/producer negotiation, disabled-by-default behavior,
operational scope selection, state ownership/path and multi-process posture,
externally provisioned purpose-distinct keys, ACTIVE/retired/revoked behavior,
bounded claim/grant/object capacity and retention/no-reuse. Propose exact keys
or public field/status names only with their owner-doc and compatibility impact.
They are proposed contract text, not current configuration.

Distinguish read-only receipt recovery from admission of a first effect. Recommend
whether a currently authorized caller may recover an authenticated equivalent
original receipt without rerunning mutable execution admission; specify that any
first effect still needs current eligibility. Define what pending, ambiguous,
conflict, unavailable and unauthorized disclose before and after run assignment.
Do not broaden the API just to expose a success shape from the fixture facade.

### G. Qualification boundaries and availability

Classify the accepted residuals by their actual bearing on the proposed first
operational path: physical-close uncertainty, bounded context versus unbounded
close latency, both-disposal withholding/capacity, observation-pool refusal close,
logical versus physical SQLite preservation, native source identity and host/key
qualification. Select either a bounded operating restriction with fail-closed
response or a necessary prerequisite, with a concrete reason. Do not automatically
open another helper-hardening campaign for every disclosed limitation. Do not
claim those limits solved by successful source tests or a supervisor not selected
in the operating model.

## 6. Required design outputs and acceptance map

Deliver these together in one decision-complete report and external decision
record. No repository edits are authorized.

1. Current-to-target capability map with implemented/private/operationally absent
   labels and exact source citations. Identify any decision now superseding the
   pre-PR #11 proposal to do ingress/startup before handoff proof.
2. One recommended operating model and a concise alternative comparison. For
   every unresolved material seam state its owner, why evidence is missing and
   whether it blocks the next source slice or only later native qualification.
   No routine user approval in the normal runtime lifecycle.
3. A complete crash/concurrency table. At minimum cover before/after claim,
   assignment, intent, partial/completed staging, marker dispatch/COMMIT,
   known marker-before-send, response loss, known acceptance-before-receipt,
   ambiguous receipt COMMIT, restart and a competing/stale operation. Each row
   names durable input, trustworthy observation, allowed action, forbidden action,
   result/disclosure and liveness cost. Exercise the model logically; no code runs.
4. Exact proposed owner-contract text for the critical operational boundary,
   including any explicit §8 re-derivation, scope/version/migration treatment,
   authority split and the minimal PLANS.md post-PR #11 status update. Label it
   PROPOSED, NOT IMPLEMENTED; do not merely append a disclaimer to incompatible
   current text. Preserve the completed fixture contract as fixture contract.
5. One next doc-first implementation scope with actual prospective files, expected
   additions, dependency order and non-goals. Separate the full target from what
   that source slice delivers. Prefer a source-level effect-handoff/restart proof
   with a controllable provider before public ingress/native effects. Do not
   split it into unnecessary reader, cosmetic-status and fixture-only PRs.
6. Acceptance matrix mapping each invariant to an observable assertion, fixture
   setup and negative control. Include durable reopening, real SQLite commit
   response loss, concurrent requests and process overlap where selected,
   no-second-POST after marker, before-send crash, provider collision/identity
   mismatch/staleness, receipt recovery, key/authorization changes, strict
   synthetic/operational separation and existing unkeyed compatibility. Fake-
   provider counts and fault boundaries must be explicit. Name prospective test
   selectors as prospective, not existing passed tests. Propose exact future
   validation commands only after finding relevant current tests and constraints.

The output must be enough for ChatGPT to issue a finite owner-contract/implementation
brief without repeating this same general reconnaissance. Do not implement to
resolve an undecided operating-model question during this turn.

## 7. Exact committed-source checkpoint snapshot

Create one unique external directory under /Users/ds/Downloads, for example:

    ES-Post-PR11-Operational-Contract-<actual-date>-<unique>/

Only that new directory and its contents may be created/removed. Require the new
root to be current-user-owned, nonsymlink, mode 0700; do not require its existing
Downloads parent to be 0700 or chmod it. Evidence files are 0600. Preserve Git file
modes in archive metadata and any temporary source exports. No cache/build outputs
are needed. Use Python -B/PYTHONDONTWRITEBYTECODE=1 for inspection scripts.

Snapshot filename:

    Execution Substrate - Snapshot - 2026-11-19 - ae326b0d.zip

Export EXACTLY the 430 tracked leaf blobs of tree e066cd4... using Git objects,
without working-tree overlays or .gitattributes export transformations. Use an
explicit archive root such as Execution Substrate/. Do not include Git
administration, private reports/logs, operational databases/keys, cached binaries,
external N-1 bridge/witness, OS metadata or untracked/ignored content. Tracked
example archives, public test certificates and synthetic fixtures must be
classified before inclusion; do not blanket-delete legitimate tracked fixtures
or expose secrets. If a tracked path is unsafe to share, report the path/class
without contents and do not label a silently redacted export an exact snapshot.
Continue the design with the safe available source; snapshot delivery may carry
a distinct block without fabricating success for it.

Write a deterministic source sidecar with the published squash and source-export
commit separately, complete tree, every leaf path/Git mode/type/object ID/size/
SHA-256, exporter provenance and explicit no-working-overlay statement. Verify
all archived entries independently against those committed bytes/modes: no
missing/extra/duplicate/traversal/symlink/special entry, and no executable-mode
loss. Record archive size and digest. A receipt may hash the ZIP and sidecar;
do not make files circularly hash themselves. The snapshot is source evidence,
not a renewed validation or a claim of operational readiness.

The exact new source snapshot is useful for project re-grounding. It need not
include historical audit directories or private test data. Do not demand that
all prior evidence be uploaded to make the snapshot useful.

## 8. Inspection commands, verification and stop conditions

Use explicit source paths and read-only Git controls. Illustrative exact reads
that may be used (all are inspection, not permission for a Git mutation):

```sh
SOURCE=/Users/ds/Repositories/ES-Private-Replay-Progress-v1
SOURCE_COMMIT=dbdc433283617b9e3b233f75c92f1179c2ece91f
SQUASH=ae326b0ddc30ec6b35883ee32945c622405b68b6
export GIT_OPTIONAL_LOCKS=0 GIT_NO_LAZY_FETCH=1 GIT_TERMINAL_PROMPT=0
export GIT_PAGER=cat PYTHONDONTWRITEBYTECODE=1

git --no-pager -c core.fsmonitor=false -c core.untrackedCache=false -C "$SOURCE" rev-parse --show-toplevel --git-common-dir
git --no-pager -c core.fsmonitor=false -c core.untrackedCache=false -C "$SOURCE" show -s --format='%H%n%T%n%P%n%s' "$SOURCE_COMMIT"
git --no-pager -c core.fsmonitor=false -c core.untrackedCache=false -C "$SOURCE" ls-tree -r -z --full-tree "$SOURCE_COMMIT"
git --no-pager -c core.fsmonitor=false -c core.untrackedCache=false -C "$SOURCE" status --porcelain=v1 --untracked-files=all
git --no-pager -c core.fsmonitor=false -c core.untrackedCache=false -C "$SOURCE" ls-files --others --ignored --exclude-standard -z
gh api repos/evo-agi/Execution-Substrate/pulls/11
gh api "repos/evo-agi/Execution-Substrate/git/commits/$SQUASH"
git -C "$SOURCE" ls-remote --refs git@github.com:evo-agi/Execution-Substrate.git refs/heads/trunk_dev refs/heads/codex/private-replay-progress-v1
```

Use exact committed blob reads for source content and raw bytes for snapshot
verification. Record actual argv/results and any source-material differences.
Do not run go test, go build, go list, shell scripts, old binaries, migrations,
N-1, Docker or live-host diagnostics in this turn. Future validation commands
are a design deliverable, not execution authority now.

Opening/closing integrity must establish no change to the actual source/index,
branch/upstream/config and no new repository files. Preserve existing modes,
including 60 tracked executables. Compare scoped source refs, not unrelated
volatile session refs or historical directory times. Do not restore metadata,
import an old verifier in place or modify prior evidence. Safe artifact processing
uses a new helper copy under this turn's output root if a helper is necessary.

Stop any proposed broadening on source identity mismatch, secret discovery,
missing required operating-model evidence or a needed nonauthorized effect.
Report the useful completed analysis and exact continuation point. A design gap
is not permission to run a live diagnostic, silently relax a contract or implement
an alternative. A lack of a local squash object, an intentionally stale tracking
ref, or the same conversation's A1 attachment is not independently a blocker.

## 9. Delivery and endpoint

Deliver the entire human-readable report INLINE. The private duplicate may
supplement it, never replace it. The report must state source pins, inspected
paths and limits, findings and recommendations, the single proposed next slice,
exact proposed critical contract text or its full decision summary, acceptance
matrix, snapshot identity, commands/results, assumptions, uncertainties, skips,
authority/security implications and exact effects/non-effects.

Bulky source inventories, raw API evidence and the snapshot can remain separate
with safe paths and SHA-256. Return one snapshot upload path and its sidecar,
one decision-record path and a self-excluding evidence index. Do not ask the
user to find a report inside an unspecified evidence directory. Machine hashes
must be computed from actual bytes and parsed back before being pasted inline.

Expected decision-ready endpoint:

    ES_POST_PR11_OPERATIONAL_SUBMIT_CONTRACT_DECISION_READY

Use it only if the critical model is concrete enough for owner review. Otherwise
state the exact unresolved decision/evidence, while delivering the completed
source map and snapshot separately. Snapshot success is not design acceptance.
Neither outcome authorizes runtime effects or implementation. Explicitly retain:

    SOURCE_REPOSITORIES_NOT_MUTATED
    SOURCE_REFS_NOT_UPDATED
    PRODUCT_TESTS_NOT_RUN
    HISTORICAL_ACCEPTANCE_NOT_REOPENED
    IMPLEMENTATION_NOT_PERFORMED
    STAGING_COMMIT_PUSH_PR_MUTATION_NOT_PERFORMED
    EXISTING_CHECKOUTS_NOT_SYNCHRONIZED
    RUNTIME_WIRING_NOT_PERFORMED
    PUBLIC_RELIABLE_SUBMIT_NOT_ENABLED
    OPERATIONAL_CROSS_RESTART_AUTHORITY_NOT_IMPLEMENTED_BY_THIS_TURN
    NATIVE_INSTALLED_SOURCE_NOT_QUALIFIED_BY_THIS_TURN

---

## Appendix transport

Appendix A below is the complete user-supplied merge report, unchanged. It is a
transport rendition; do not expect it to share the private duplicate's hash.
Read exactly the declared byte count immediately after the BEGIN marker newline.
Authenticate SHA-256 before use; the framing separator is not part of its bytes.

### Appendix A — Complete supplied PR #11 merge closeout

Bytes: 11841
SHA-256: 7b532fe5f9a87748a2bf6a6738f688c966c465415317dd06a8061ea51d2693bd
<!-- BEGIN APPENDIX A -->
# ES_PRIVATE_REPLAY_PROGRESS_PR11_SQUASH_MERGED

[PR #11, Add private original replay with durable progress](https://github.com/evo-agi/Execution-Substrate/pull/11) merged into `trunk_dev` on **November 19, 2026 at 18:47:16 EST**. One synchronous squash request succeeded. Official `trunk_dev` pointed to the verified squash at closeout. The remote topic, local HEAD, and clean checkout were preserved.

| Identity | Verified value |
|---|---|
| Squash commit | `ae326b0ddc30ec6b35883ee32945c622405b68b6` |
| Sole parent | `f1aa8b934cc26c16a966a110c7b408abdaeadce7` |
| Complete accepted tree | `e066cd4afa77fcb665f31b69bf00465989f9744e` |
| Topic and local HEAD | `dbdc433283617b9e3b233f75c92f1179c2ece91f` |
| Squash subject | `Add private original replay with durable progress (#11)` |
| Merge actor | `SeritArbores` |
| Author | `David Shaw <david.shaw.dev@gmail.com>` |
| Committer | `GitHub <noreply@github.com>` |
| Signature | GitHub reported `verified: true`, reason `valid`, at `2026-11-19T23:47:16Z` |

## Request and independent readback

The final prewrite decision at `18:47:14.895789` EST bound the exact head, base, accepted tree, PR body, request bytes, and effective policy. The single command ran from `/Users/ds/Repositories/ES-Private-Replay-Progress-v1`.

```sh
/opt/homebrew/bin/gh api --method PUT \
  -H 'Accept: application/vnd.github+json' \
  -H 'X-GitHub-Api-Version: 2026-03-10' \
  repos/evo-agi/Execution-Substrate/pulls/11/merge \
  --input /Users/ds/Repositories/ES-Private-Replay-Progress-PR11-Merge-Gate-20261119-20VzJnFU/merge-request.json
```

Appendix D was **1,433 bytes**, SHA-256 `b1c1619c9ebb2d7e897b00cfd935a2e53b87904ce5ab093c69d1a9c326cdec6a`. The command ran from `18:47:14.896645` to `18:47:18.008092` EST, exited 0, and produced empty stderr. The complete response was:

```json
{"sha":"ae326b0ddc30ec6b35883ee32945c622405b68b6","merged":true,"message":"Pull Request successfully merged"}
```

Response stdout SHA-256 was `21903ee43b2ddbf63f70450d96faa5252f3db81ce178e19307435fe223b8605b`. The request’s `sha` guarded the PR head. Fresh ref reads established the premerge base, and the actual squash object independently confirmed its sole parent. [GitHub synchronous merge API](https://docs.github.com/en/rest/pulls/pulls#merge-a-pull-request)

The PR readback showed **closed and merged**, one source commit, 30 changed files, the original title and head/base branches, and the exact 5,435-byte PR body including its final newline. Its SHA-256 remained `34be5bf95108878f93e6963478d029728ce47beaf2140072ca6ca6aca48c3e99`. Auto-merge, queue entry, and stack membership were unset. The actual squash is distinct from the premerge preview `57dacb8edb7ef825bc6a0d53c06590318d4bda70`.

The squash message matched Appendix D’s title and body in full, at SHA-256 `9101003c3fb64174d60bd6d9fabee9055060aadea9daad4c8c6cf37862774b1b`. Reconstructing the signed object from GitHub’s payload and signature reproduced the actual Git object ID. The 2,349-byte reconstruction authenticated to `9fe24960126b94f7defa7896b34f1126181c27e5a114d6be22b3c8dee44727d7`. [Verified squash on GitHub](https://github.com/evo-agi/Execution-Substrate/commit/ae326b0ddc30ec6b35883ee32945c622405b68b6)

## Exact-tree and local preservation

The complete, nontruncated remote squash tree contained **430 leaf blobs**. All matched the accepted local tree by path, mode, and object ID. The other **400 entries** matched parent tree `8dd27f9acba98ed70d93736bdef8300ef1aba53f`, including all 60 baseline executables. Before the request, I decoded all 30 changed remote payloads and compared them to local committed bytes and the accepted archive. The independently read squash tree named those same 30 immutable blobs.

| Scope | Modified | Added |
|---|---:|---:|
| Lifecycle owner documents | 3 | 0 |
| Root plan and contract test | 2 | 0 |
| Internal reliable-submit package | 16 | 3 |
| Admission source and tests | 6 | 0 |
| **Total** | **27** | **3** |

All 30 paths are disk mode `0644` and Git mode `100644`. The three additions were `replay_progress_test.go`, `sqlite_pooled_claim_read_cleanup_test.go`, and `sqlite_replay_progress_schema.go` in `es/admission/internal/reliablesubmit`. There were zero deletions, renames, type changes, or executable-mode changes. The full diff SHA-256 was `1b1d1486ee301898835c059306bf81c4a4d167b99b1320a0b9a428c2a81d98e4`. The literal 27-path historical subset reproduced `793e6697cf2342ce41f08ed8f59a0a14eb5c288c74780f158731d55dbe17bcca`.

The earlier report transcription discrepancies remained confined to the historical supplied report. The actual bytes and generated table give `ef0bc6f4d125f3986c46901cbe05bc2cb447af7dfbf51cee4653d7ce696c0945` for `durable_service.go` and `32de42b7bf8974e36c014d3d9ce6d24e0994fbbc03bb1587c4c4fddd32c80f6e` for `reliable_submit_guardrails_test.go`. Both historical renditions were preserved. The complete 30-row source table was generated from verified bindings and parsed back against them.

The checkout’s Git and common directory remained its own `.git`. Branch `codex/private-replay-progress-v1` still tracks `origin/codex/private-replay-progress-v1` at the topic commit. Fetch and push origin remained `git@github.com:evo-agi/Execution-Substrate.git`. Opening and closing local HEAD, full ref map, config, index, and all working bytes and modes agreed. The local `origin/trunk_dev` ref remains at the original parent. Staged, unstaged, unmerged, ordinary-untracked, and ignored inventories were empty. Both external N-1 sources stayed outside the checkout. No fetch, push, or branch administration ran in this gate.

## Eligibility and observed automation

The complete effective `trunk_dev` rules and applicable inherited rules were checked at opening and immediately before the request. Ruleset `17579282` requires a PR, thread resolution, and squash, and protects trunk creation, deletion, and non-fast-forward updates. The configured approval count was zero. There were no required checks, deployments, signatures, or merge queue, and the ruleset listed no bypass actors. Classic protection explicitly returned `404 Branch not protected`. GitHub showed normal write authority, `viewerCanMergeAsAdmin: false`, REST `clean`, and GraphQL `MERGEABLE` / `CLEAN`. Automatic head deletion was disabled before and after the merge. [Effective ruleset](https://github.com/evo-agi/Execution-Substrate/rules/17579282)

At the immediate checkpoint, the Codex summary identified the exact topic head and reported completed code review with no findings. Security review remained unset. The fresh collections showed zero formal reviews, active change requests, inline comments, requested reviewers, and unresolved threads. [Codex review summary](https://github.com/evo-agi/Execution-Substrate/pull/11#issuecomment-7025022350)

**The narrow Claude allowance applied.** Suite `120828437077` was queued for the exact source head, with a null conclusion and zero associated check runs. Complete policy required no result from it. There were zero head check runs, workflow runs, jobs, or additional active review markers. The gate proceeded without a Claude result. Its eventual activity and outcome were unknown. The legacy aggregate was `pending` with zero contexts.

The bounded postmerge snapshot found the original Claude suite still queued and new suite `120837738064` queued on the squash. Both had zero check runs and null conclusions. Both commits had zero workflow runs, jobs, and legacy contexts. The PR review and thread collections remained empty, apart from the separate Codex issue-summary comment. Visible repository workflow, hook, deployment, and environment inventories were empty. Organization and external integrations remain outside that visibility. These observations leave CI and security review outcomes unestablished.

## Retained validation and evidence

The gate reauthenticated 15 publication records and 222 commit-gate and independent-audit records at opening, before the write, and at closeout. The subset bound the accepted archive and manifest, complete staged and committed trees, twelve staged command records and guards, raw logs, identity and skip reconciliation, historical probes, and separate N-1 source and build evidence. The 955,015-byte accepted archive authenticated to `3b27c483036296304a9fbca77dcd5fe522dee64b8eabf392057b6c573160f59a`. The accepted pre-stage manifest remained `f92b57f48a701a606e8a0697b75dac8f691e3eb44c13b9c92afb894ec6e1d718`.

| Retained local validation | Pass / fail / skip |
|---|---:|
| Owner contracts | 27 / 0 / 0 |
| Pooled reader | 16 / 0 / 0 |
| Internal and historical probes | 221 / 0 / 0 |
| Admission and inventories | 26 / 0 / 0 |
| API/App | 2 / 0 / 0 |
| Four packages | 2062 / 0 / 39 |
| Full repository | 5192 / 0 / 39, with 21 tested and 20 no-test packages |
| Separate external N-1 | 5 / 0 / 0 |

The 39 retained skips were two helper sentinels and 37 App capability cases, including the unavailable native installed-source witness. The N-1 cases remain bounded synthetic evidence. No product tests, diagnostics, migration fixtures, source-view builds, probes, or independent acceptance were rerun.

No setup failure blocked the gate. An optional signed-object reconstruction initially omitted the PGP header’s final blank continuation. Preserving that continuation reproduced the exact object ID. This was a read-only evidence correction.

The merge integrates the private fixture-only `synthetic_progress_nonoperational_v1` scope. Physical close, hard close duration, actual double-withholding capacity, SQLite file and sidecar byte preservation, real provider or receipt evidence, operational no-dispatch proof, cross-restart write-uncertainty authority, and native installed-source qualification remain outside the evidence. The observation pool’s unchecked close result on refusal remains disclosed.

The new evidence root uses `0700` directories and `0600` files. Its self-excluding index verified 510 entries. No temporary cache or source export required cleanup.

| Artifact | SHA-256 |
|---|---|
| [Private closeout report](/Users/ds/Repositories/ES-Private-Replay-Progress-PR11-Merge-Gate-20261119-20VzJnFU/report.md) | `201502d98a85b0a961f5a81121e40e8a9169e12e4a652851c030caf2d154914b` |
| [Self-excluding evidence index](/Users/ds/Repositories/ES-Private-Replay-Progress-PR11-Merge-Gate-20261119-20VzJnFU/artifact-index.json) | `d404df048de2e3c9a8e32ba51d453595aca047ae8ef931ec1cf11c546fe7154e` |
| [Complete machine bindings](/Users/ds/Repositories/ES-Private-Replay-Progress-PR11-Merge-Gate-20261119-20VzJnFU/machine-bindings.json) | `a635e0e675f3eda6c7753dbd62d7212d1e0c1dba2b03e799f4e00d6051d62c9a` |
| [Verified 30-row table](/Users/ds/Repositories/ES-Private-Replay-Progress-PR11-Merge-Gate-20261119-20VzJnFU/verified-source-table.md) | `1e0d79db52cf23f1d6b570c495d7fbf0ff75dd88facc88cf39ba22f7a014eeb4` |
| [Prewrite decision](/Users/ds/Repositories/ES-Private-Replay-Progress-PR11-Merge-Gate-20261119-20VzJnFU/prewrite-decision.json) | `fc981f8ca8d088465f4a56441de02bf16e16fa5f1c981606575978b48e365af3` |
| [Closing evidence ledger](/Users/ds/Repositories/ES-Private-Replay-Progress-PR11-Merge-Gate-20261119-20VzJnFU/closeout-evidence-ledger.json) | `3c5dc15f9ccebceb58acd1244f962ceddd2622eddc5c68eb67ef00a92c8789b7` |

```text
ES_PRIVATE_REPLAY_PROGRESS_PR11_SQUASH_MERGED
SOURCE_BYTES_NOT_CHANGED
LOCAL_HEAD_AND_TOPIC_PRESERVED
PRODUCT_TESTS_NOT_RERUN_IN_MERGE_GATE
PR8_PR9_PR10_NOT_MODIFIED
AUTO_MERGE_NOT_ENABLED
BRANCH_NOT_DELETED
TAG_NOT_CREATED
RELEASE_NOT_CREATED
DEPLOYMENT_NOT_PERFORMED
EXISTING_OTHER_SOURCE_CHECKOUTS_NOT_SYNCHRONIZED
RUNTIME_WIRING_NOT_PERFORMED
PUBLIC_RELIABLE_SUBMIT_NOT_ENABLED
CROSS_RESTART_OPERATIONAL_WRITE_UNCERTAINTY_GATE_NOT_IMPLEMENTED
NATIVE_INSTALLED_SOURCE_WITNESS_NOT_QUALIFIED_BY_THIS_SLICE
```
<!-- END APPENDIX A -->
