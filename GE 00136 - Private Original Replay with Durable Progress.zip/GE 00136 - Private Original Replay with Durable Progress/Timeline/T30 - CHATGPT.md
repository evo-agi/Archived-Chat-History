## Exact repair review complete — proceed to a fresh independent audit

**The packet is consistent, and I found no additional blocker in this targeted source review.** The supplied code addresses the missed pre-COMMIT recovery path, and the owner documentation now matches the frozen synchronization inventory. Neither finding is independently closed yet; staging and commit remain premature.

I inspected the complete six-file repair delta, the relevant surrounding functions and contracts, the maintained regression, the documentation checks, and the external N-1 inputs. **I did not apply patches or execute repository commands, tests, migrations, or probes.**

:chatgpt-content-reference{index="7"}[Download the complete exact-source review, including line-numbered supporting excerpts](sandbox:/mnt/data/ES_Private_Replay_Progress_M1_Owner_Repair_Exact_Source_Review_20261119.md)

## Packet and preservation checks passed

The archive matches the reported **955,015 bytes** and SHA-256:

```text
3b27c483036296304a9fbca77dcd5fe522dee64b8eabf392057b6c573160f59a
```

I verified all **47 uniquely named regular-file entries**, the 46 self-excluding inventory records, and all thirty complete source payloads against their hashes, sizes, and archived modes. Exactly **six source files changed and twenty-four remained byte-identical** to the preceding packet. The new report’s inline canonical JSON also matches the archived manifest; this delivery does not repeat the earlier transcription error.

```text
Final canonical manifest — 6,813 bytes:
f92b57f48a701a606e8a0697b75dac8f691e3eb44c13b9c92afb894ec6e1d718

Final tracked HEAD diff:
793e6697cf2342ce41f08ed8f59a0a14eb5c288c74780f158731d55dbe17bcca
```

Both opening-delta variants match their supplied old and new files, including unchanged intervals and Git blob identifiers. The tracked HEAD patch’s target-side hunks match the delivered files. **Reconstructing the complete pinned HEAD and verifying the 400 unchanged files remain host-audit tasks**; those files are not all supplied in this packet.

## M-1 now routes the missed exit through checked readback

The correction is local and preserves the selected distinction between **requesting recovery** and **establishing an outcome**.

In `sqlite_store.go:669–709`, migration still authenticates its opening state while holding the writer transaction before setting the recovery baseline. A pre-COMMIT cleanup failure can request readback only after that prerequisite and an eligible connection-disposition path.

The new `errSQLiteMigrationNeedsReadback` signal does **not** mean that rollback succeeded, the old state survived, or the migration committed. It transfers control to the unpublished opener:

```text
Migration returns the recovery-needed signal
→ openGate finishes its connection ownership
→ opener checks closure of the original unpublished pool
→ a fresh pool performs nonmigrating verification
→ the observed state determines the result
```

The ordering is explicit in:

```text
sqlite_store.go:58–59       migration-local signal
sqlite_store.go:99–123      pool disposition, fresh observation, cancellation
sqlite_store.go:557–568     original connection ownership
sqlite_store.go:628–667     old/current classification
sqlite_store.go:687–693     pre-COMMIT cleanup handoff
sqlite_store.go:744–748     existing COMMIT-response-loss handoff
```

Two preservation details matter:

**The classifier’s executable body is unchanged.** Only its comment now clarifies that observing the current head does not attribute it to a transaction whose cleanup or response was uncertain.

**The shared helpers are unchanged.** The repair does not globally reinterpret `sql.ErrConnDone` as successful disposal. Only `openSQLiteClaimStore` and `migrateSQLite` have changed executable function bodies, alongside the new private signal. I also reproduced the unchanged **1,077-byte `loadClaimFresh`** hash.

This is consistent with the report’s stated ownership model, but physical driver-close success and duration remain unproved. A checked pool-close return must not be inflated into a universal teardown guarantee. Pasted text

### The regression reaches the previously missed boundary

`sqlite_replay_migration_test.go:715–811` contains the twelve selected cases:

```text
Schemas 0, 1, 2 and 3
× ClosedWrapper, OrdinaryRollback and CanceledReadback
```

The decisive cases verify schema 4 on the actual transaction connection inside `beforeMigrationCommit`, close that wrapper, and require **zero calls to the COMMIT collaborator**. They then assert no returned store, the appropriate classification, and preservation through an independent logical-state witness. The populated schema-3 fixture includes claims, keys, grants, ledger, and a retained sealed original.

The witness reads unfiltered schema entries, application/version pragmas, and table contents with row identities. It does not reuse the formerly defective namespace filter.

That is the correct test structure for this finding. The report’s **eight red passes/five failures and thirteen green passes** remain execution evidence for the auditor to authenticate and independently exercise—not results I reran. Pasted text Pasted text

## DOC-SYNC now matches the actual finite inventory

I independently compared admission §7.4’s documented field set with the archived Workstream C inventory. They match exactly:

| Category | Entries |
|---|---:|
| Direct lock fields | 5 |
| `atomic.Bool` fields | 3 |
| Reference, request, and wrapper fields | 24 |
| **Total** | **32** |

The owner text distinguishes primitive owners from fields carrying references to them. It includes both permit wrappers, the shared publisher, and the `matchesAllocation`, `consume`, and `burn` roles. It also distinguishes **non-test production source** from **operational reachability**: fixture definitions belong in the source inventory without becoming runtime-enabled authority.

Relevant source locations:

```text
es_execution_admission_model.md:910–977
docs_contract_test.go:12556–12719
workstream_c_guardrails_test.go:2280 onward
```

The new root test performs an exact field/category comparison and checks the permit table. Its four mutants target the omissions and misclassification identified by the repair brief. The separate typed scanner remains byte-frozen; the documentation checker supplements rather than replaces it.

The three older resolved-plan assertions changed only their field notation. They still name the same locks. **The following rejected-A3 section is unchanged.** This addresses the generation-1 failure without weakening that boundary. Codex preserves the failed generation and reports a complete generation-2 rerun. Pasted text

## What remains for independent verification

The packet supplies enough source to review these corrections, but it does not turn retained execution metadata into fresh acceptance.

Codex reports generation 2 at **5,192 ordinary full-suite passes, zero failures, and 39 skips**, plus **five separate external N-1 identities**. The eighteen new ordinary-suite identities reconcile to thirteen migration identities and five documentation identities. Pasted text Pasted text

I verified that both N-1 source additions remain byte-identical to the preceding packet and that the new view metadata binds the final candidate. The retained generated test-main is classified as **build evidence**, not repository source. Raw logs, host toolchain/module inputs, probe binaries, and the remaining baseline files still require host authentication.

The fresh audit should focus on the complete recovery lifecycle—not merely the recovered-old error constant—and verify preservation of the seven previously resolved findings. It need not repeat their design or every historical diagnostic campaign.

## Next Codex conversation

Open a **fresh read-only Codex conversation directly at**:

```text
/Users/ds/Repositories/ES-Private-Replay-Progress-v1
```

Use:

:chatgpt-content-reference{index="8"}[Download the M-1 and owner-inventory fresh independent-audit prompt](sandbox:/mnt/data/ES_Private_Replay_Progress_M1_Owner_Repair_Fresh_Independent_Audit_20261119.md)

SHA-256:

```text
74878f466a9189512ce37fde82eeeaf751f035c3b997ffd014f9f048db5ca547
```

The prompt contains seven byte-verified inputs: the complete latest closeout, exact final manifest, exact v2 recipe, complete preceding rejection, this review’s conclusions and limitations, and both external N-1 source files.

It requires four complementary read-only perspectives, explicit **M-1 and DOC-SYNC dispositions**, and review of the complete integrated candidate. An `ACCEPT` requires the eleven-command sequence, including the full repository run and a freshly constructed N-1 view of the actual final bytes.

The authoring conversation may remain attached to A1. **No checkout move, synchronization, historical-probe rebuild, source edit, staging, commit, or publication is authorized by this audit.** After the audit concludes, its foreground conversation may perform a separately instructed next step; it need not remain permanently audit-only.

The prior rejection remains attached to `08120915…`. The new `f92b57f4…` candidate is ready for independent review, **not yet accepted**. Public reliable Submit and the operational cross-restart write-uncertainty gate remain unimplemented. Pasted text

**Sources:** Exact current and preceding repair ZIPs; delivered owner contracts, source, tests, manifests, and diagnostic bindings; latest closeout for reported execution. The linked review preserves the supporting source excerpts and inspection limits.

**Confidence:** Packet/source binding **0.99**; targeted static repair assessment **0.96**; fresh-audit readiness **0.98**. Test execution remains report-based until independently rerun.
