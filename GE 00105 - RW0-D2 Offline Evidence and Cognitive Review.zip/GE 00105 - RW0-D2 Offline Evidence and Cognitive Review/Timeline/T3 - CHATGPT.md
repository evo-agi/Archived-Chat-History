**This is another failed audit start, not a finding against V4. No implementation repair or new candidate version is justified.**

Codex stopped correctly under the instruction I issued. But that instruction turned a startup-order mistake into another round trip through you. The archive records the same failure at T2, T21, and T33. Reissuing the same hard-stop rule would perpetuate that problem.

**I’m changing the recovery rule—not the substantive audit requirements.**

## Resume the same independent auditor

:chatgpt-content-reference{index="0"}[Download the complete V4 audit re-entry prompt](sandbox:/mnt/data/Coordinator_RW0_D2_V4_Independent_Audit_Prospective_Reentry_Prompt.txt)

Send it once to **the same independent audit conversation**, not the implementation/repair conversation. It replaces the previous mandate in full.

The revised procedure permits a **new, explicitly bounded preservation interval** after the reported preliminary reads. It does not retroactively validate the failed interval. Recovery is conditional:

- **Classify the actual prior commands.** The auditor must inspect its visible tool transcript, not rely solely on its summary. Only narrowly classified preliminary inspection qualifies. Unknown commands, actual unaccounted mutations, repository execution, or competing writers remain blocking.
- **Authenticate the fixed target before execution.** The new opening must match the supplied index digest, all 70 V4 endpoint receipts, the baseline relationships, and the complete replacement digest. A mismatch cannot be normalized into a new baseline.
- **Preserve the new interval and disclose the old gap.** Index/cache metadata observations begin at the actual new opening. They do not prove earlier preservation. Once that opening succeeds, it cannot be replaced to excuse drift.

The next repository action remains the explicit `AGENTS.md` read, followed by the existing filesystem-only opener. A qualifying preliminary inspection no longer forces a terminal return **solely because its ordering was wrong**. That is the narrow procedural amendment; raw Git has not been declared harmless.

## What stays unchanged

I preserved **Sections 1–8 byte-for-byte**, including the existing opener/helper, all 70 receipts, strict-expiry checks, relationship controls, A01–A13 register, six focused validation groups, selector-free full suite, and prohibition on live repository mutation.

The prompt remains a **whole-D2 independent audit**, not a two-file V4 check. Passing it would establish eligibility for a separate commit gate—not permission to commit.

The delivered file was saved, reopened, and compared with the previous mandate. Its identity is:

```text
Bytes: 135,715
SHA-256: 5be28595feb7d1e4ca02554a6448c65a09e1080c6b7a594293279a306e86d53b
```

:chatgpt-content-reference{index="1"}[Artifact consistency check](sandbox:/mnt/data/RW0_D2_V4_Reentry_Handoff_Artifact_Check.json)

**Current disposition:** V4 remains the expected audit target. This latest attempt authenticated none of its bytes and completed no semantic review or tests. I inspected the supplied history and handoff text; I did not access the live checkout or execute repository code.

**Sources:** Your latest Codex report; Coordinator_RW0_D2_Repaired_V4_Independent_Reaudit_Prompt.txt[previous V4 mandate](sandbox:/mnt/data/Coordinator_RW0_D2_Repaired_V4_Independent_Reaudit_Prompt.txt), §0, lines 24–30; history archive `Timeline/T2 - USER.md:3–4`, `T21 - USER.md:3–5`, and `T33 - USER.md:3–5`.

**Confidence:** 0.98 in the procedural diagnosis and handoff preservation. Live provenance, independent validation, and V4 implementation acceptance remain pending.
