# Governed Execution Coordinator — RW0-D2 V4 bounded audit-receipt reconciliation

## Active objective and effect ceiling

Continue in the SAME independent audit conversation that returned
`RW0_D2_OFFLINE_EVIDENCE_COGNITIVE_REVIEW_ACCEPTED_READY_FOR_COMMIT_GATE`.
Do not route this to the implementation/repair conversation. One parent, no subagents,
no additional models. Other repository conversations remain idle.

Resolve one concrete final-report receipt discrepancy and clarify one historical
qualification. This is NOT a new implementation, a V5 candidate, a whole-D2 re-audit,
a fresh architecture investigation, or a commit/publication gate. Preserve the
previous report and all correctly scoped independent evidence. Do not silently
replace the report, its erroneous/uncertain field, or the supplied expected hash.

NO repository writes, repairs, formatting, staging, commits, ref/config/index writes,
push/fetch/PR/merge, installs, sibling repositories, providers, network, services,
operator/product databases, or credential/private provider/session-state access.
No live-checkout imports, tests, scripts, fixtures or children. Any permitted new
executable checking occurs only in a newly owned authenticated external copy.
Owning repository guidance remains authoritative; report a real conflict rather
than silently bypassing it.

This mandate defines the COMPLETE supplemental task. The old whole-audit register
is not being reissued. Its source-review and semantic-control results remain
Codex-reported independent evidence for the original authenticated interval.
Successful reconciliation restores eligibility for a SEPARATE commit gate only.
It does not authorize that gate or any product/runtime effect.

## A. Inputs, fixed discrepancy and retained credit

The lead inspected these exact supplied artifacts as inert text:

- Prior complete re-entry mandate: 135,715 bytes; SHA-256
  `5be28595feb7d1e4ca02554a6448c65a09e1080c6b7a594293279a306e86d53b`.
- Your delivered 131-line independent-audit report: 25,886 bytes; SHA-256
  `66c71f97bc40d138802e67c690ce9cd3b003d2018971acc8c2ac03bdcfbf8561`.

These identities describe the supplied artifacts, not files you are required to
find at an invented local path. Do not reconstruct deleted artifacts to match them.

Your report's final table, line 124, says:

```text
GUARDS: 24 modules; 4,162 collected and passed
MODULE SHA-256: 4533bd1c1f6ee61c1e96847b3d6ce684af46046304ae9a6df28348eaace2b617
REPORTED NODE SHA-256: 547c990afa2ac226f2316e0d3c276b6709afa0c4deb20493a1e3db2230b9260b
```

The fixed V4 receipt in the mandate, section 7 / line 1829, and the retained V4
writer report T41 / line 47 is:

```text
EXPECTED NODE SHA-256: 547c990efa2ac226f2316e0d3c276b6709afa0c4deb20493a1e3db2230b9260b
```

The difference is `547c990e...` versus `547c990a...`. Do not assume this is a
transcription error simply because one hex character differs. Do not normalize
node IDs, alter selectors or tests, or substitute the reported hash as a new oracle.

All seven final module hashes and the OTHER SIX node hashes agree with the supplied
mandate in the lead's inert comparison. Reported counts also reconcile: six focused
groups have 5,448 occurrences / 5,446 distinct nodes; FULL has 9,098 with 3,652 beyond
that union. The lead independently reconstructed GUARDS' 24-module inventory hash
from snapshot bytes for unchanged modules plus the supplied changed-file digests.
That confirms the supplied module bookkeeping, NOT live V4 payloads, collected node
IDs, or execution. No repository code or uploaded helper was executed by the lead.

Keep the previous exact-subject, full source-review, A01-A13, E01/E02, X01/X02b,
R01/J01/J02, C10, cleanup, and other six final-group observations at their original
reported scope. Preserve the overlap/causal-credit qualifications. No need to rerun
those controls, five subprocess demonstrations, or the selector-free full suite
solely to reconcile this one receipt.

Your prior root and its logs/records were deleted under the prior closing mandate.
That deletion is NOT a newly discovered defect and does not create a requirement
to recover unavailable logs. Use the shortest supported route below.

## B. Evidence-only route first; no retrospective reconstruction

First inspect only the actual execution records already visible in this audit
conversation. No repository operation is needed for this step. Do not scan Codex,
provider, machine-wide process, private session files or deleted temp directories.

1. Find the original GUARDS collection/run node-inventory result, exact command,
   source/copy association and completion evidence, if genuinely still visible.
   A command body plus its actual returned output is evidence; an intended command,
   narrative summary, expected digest copied from the prompt, or recollection of
   a digest alone is not a replacement for unavailable execution records.
2. If those records unambiguously establish the expected NODE digest and the
   reported 4,162-pass run, issue an additive report correction identifying precisely
   which final-table text was wrong. State the record used and its scope. Do not
   invoke any tests or live checkout solely to repeat already sufficient evidence.
3. If the original execution receipt cannot be recovered from the visible record,
   use section D's new bounded GUARDS check. This supplies NEW evidence; it does
   not prove what a deleted old file contained or prove the cause of the old typo.
4. If actual original output is discrepant, or its source/grammar is uncertain,
   preserve it as such. Use the bounded check to distinguish current reproduction
   from historical reporting. Never claim a correction was verified from an old
   log when the new run is the only evidence.

## C. Historical re-entry qualification — one precise clarification

Your report line 11 says the repository listing's exact shell text and order are
not retained in the compacted record, but that eligible inspections were classified
before re-entry. The old section 0R required inspecting complete arguments and
shell composition, not merely labels such as "listing" or a user's summary.

State which actually happened:

- You inspected the COMPLETE actual preliminary invocations/arguments/composition
  from the visible tool record before the successful prospective opener, and their
  literal text was subsequently lost to compaction; OR
- At that decision point you had only summaries/action labels or could not classify
  an invocation's full effect from the visible record.

Do not invent exact text, ordering, workdirs or a chronology now. Provide exact
invocation text only where still genuinely visible. If complete-argument inspection
was actually performed, its later unavailability remains a report-backed historical
reconstructibility limitation; this task does not require reproducing the old
interval. Relative order among already classified eligible parallel inspections
must remain unknown where unknown. If the second case applies, or the decision
cannot be supported even as an honest account of what you did, the original re-entry
eligibility is unresolved: qualify/withdraw the overall acceptance token and return
an audit-procedure limitation, NOT a V4 code defect. Do not silently waive the rule
or start a whole audit to hide the missing predicate.

The old raw-status interval remains unpreserved. This later evidence never backdates
preservation. Keep the unresolved V1 ref incident and original .git/config opening-
byte limitation separate; do not restore refs, infer a culprit, expand configuration
preservation claims, or begin a new forensic program.

## D. New supplementary interval, only if B lacks sufficient actual records

This is a separately labeled supplemental observation interval after the original
audit closed and its root was removed. Its opening is NOT a replacement opening
for that completed audit. It may corroborate the same fixed candidate, not erase
history or accept drift. Do not begin D while an unresolved section-C eligibility
problem would make the intended overall acceptance unsupported; report that limit.

Before the first protected-repository action, read the complete current guidance
from workdir `/`, using ONLY:

```sh
python3 -I -B -S - <<'PY_GUIDANCE'
from pathlib import Path
print(Path('/Users/ds/Repositories/Governed Execution Coordinator/AGENTS.md').read_text(encoding='utf-8'), end='')
PY_GUIDANCE
```

If output truncates, finish reading only that file as inert text. Then run the
unchanged opener in Appendix 1 ONCE from `/`. No preliminary status/listing is
requested. If an eligible inert instruction read or fully inspectable filename/
Git-status/branch/log read nevertheless precedes this FIRST successful opening,
record its actual full invocation and classify it under the same narrow rule as
prior 0R; ordering alone does not force another user round trip. Unknown bodies,
actual unaccounted mutation, execution, imports, tests, installs, network, private
state, or competing writers cannot qualify. No post-opening replacement is allowed.

Before any live Git read or executable work, opening index SHA-256 MUST equal:
`7af425d5a47b91b0a14294660f5d449f5ba6308dc8846a8b13aca371c191a587`.

Use only the emitted helper for subsequent LIVE Git reads; never fall back to raw
Git after a helper error. Authenticate Appendix 1's fixed baseline, all 70 endpoint
receipts and baseline/absence relations, all 216 remaining baseline endpoints,
current guidance, index/cache types/bytes/metadata, full current source inventory,
and fixed raw replacement twice before executing anything from the candidate.
Preserve the unrelated OS-0600 test file; do not normalize it. Do not import the
known opaque cache or copy it into any executable source location.

Apply Appendix 1R to actual refs and source-selection dependencies. The prior report
had 54 records, 28 protected / 26 qualified diagnostic, hash
`eef25591b98fe5b402e9e03f13d3755c41fa2c59bf72ca3f2e01f51a46e3e2fb` and zero interval
delta. That is a PRIOR OBSERVATION, not a fixed current ref-count/hash requirement.
Protect source/index/guidance/cache/configuration and all protected refs through
this new interval. Capture exact safe current preservation observations without
printing secret configuration. Do not retroactively infer old config byte equality.

Create exactly one normal external copy from the authenticated baseline and all
working overlays. Local `--no-hardlinks` clone or a complete inert-data copy is
allowed; no fetch/network. Prove zero remotes before executing the copy. Include
all 286 source endpoints, no live ignored state, cache, databases or secrets. No
source repair, mutant or monkeypatch of product/test behavior is commissioned.

Manifest EVERY source endpoint before and after collection and execution: path,
regular type, Git/OS mode, size, SHA-256. The optional complete-source grammar is
`RW0-D2-INDEPENDENT-AUDIT-SOURCE-V1\0` (one terminal NUL), followed by UTF-8-path-sorted
u32be(path length)+path+u32be(Git mode)+u64be(payload length)+raw payload rows. The
prior reported normal-copy SHA-256 was
`c37155124f5e4eb1ac49834a160e0ef4e7c66d09b4b1bbc0aea6a932e81cc307`.
This is corroborating reported identity; exact baseline plus 70 fixed raw endpoints
remain the primary supplied subject. Investigate and disclose any derived-identity
difference; do not silently change its grammar or select different source bytes.

### D1. Exact GUARDS scope and commands

Use installed `/Library/Frameworks/Python.framework/Versions/3.13/bin/python3` and
record actual version plus pytest version. Prior settings were Python 3.13.4 and
pytest 8.4.1. No installs or silent tool substitution. Run serially with umask 022,
owned TMPDIR and separate owned collection/execution basetemp paths, created before
invocation. Never run these commands in the live checkout.

In the authenticated EXTERNAL COPY, bind PY, OWNED_TMP, OWNED_COLLECT, OWNED_RUN and
OWNED_JUNIT to actual verified absolute paths. Record expanded commands; do not
assume tool-call shell variables persist. The exact module vector is:

```bash
GUARDS=(
  tests/test_architecture_contracts.py
  tests/test_autonomous_software_development_operating_model.py
  tests/test_b2a_writer_session_contract.py
  tests/test_b3a_persistence_contracts.py
  tests/test_b3b2a_read_scope_and_query_contracts.py
  tests/test_b3b2b_select_readers.py
  tests/test_b3c4c_prerequisite_contract.py
  tests/test_c2a_nonimplementation.py
  tests/test_c2b0_durable_state_contract.py
  tests/test_c2b2_development_reader_contracts.py
  tests/test_c2b2_development_row_value_boundaries.py
  tests/test_post_execution_pure_owner_boundaries.py
  tests/test_post_execution_pure_owner_vectors.py
  tests/test_runtime_non_authority.py
  tests/test_rw0_b1_boundaries.py
  tests/test_rw0_b2_capability_boundaries.py
  tests/test_rw0_b2_wire_boundaries.py
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
  tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
  tests/test_rw0_c2_private_value_versioning_contract.py
  tests/test_rw0_remote_contact_phase_entry_contract.py
  tests/test_sqlite_b1_runtime_boundary.py
  tests/test_sqlite_b2c_writer_session.py
  tests/test_sqlite_backend_b0_contract.py
)

umask 022
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src TMPDIR="$OWNED_TMP" \
  "$PY" -B -m pytest -q -p no:cacheprovider \
  --basetemp="$OWNED_COLLECT" --collect-only "${GUARDS[@]}"

PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src TMPDIR="$OWNED_TMP" \
  "$PY" -B -m pytest -q -p no:cacheprovider \
  --basetemp="$OWNED_RUN" --junitxml="$OWNED_JUNIT" "${GUARDS[@]}"
```

Capture COMPLETE original pytest node IDs without whitespace tokenization or
parameter normalization. Prefer already sufficient structured output. A newly
owned external, purely observational pytest hook may record session.items and
per-node completion if necessary; report its source/hash and exact invocation.
It must not modify items, collection order, marks, fixtures, tests, product code,
expected results, warnings, skips or selection. It is audit instrumentation, not
an additional candidate endpoint, and must never run from the live checkout.

Compute exact inventories with the ORIGINAL grammars:

```text
MODULE (no prefix): unique module paths sorted by UTF-8 bytes;
  u32be(path byte length) + path UTF-8 + raw 32-byte module SHA-256.
NODE (no prefix): deduplicated COMPLETE node IDs sorted by UTF-8 bytes;
  u32be(ID byte length) + exact ID UTF-8.
```

Expected: 24 modules, 4,162 collected node IDs, 4,162 executed and passed; MODULE
`4533bd1c1f6ee61c1e96847b3d6ce684af46046304ae9a6df28348eaace2b617`; NODE
`547c990efa2ac226f2316e0d3c276b6709afa0c4deb20493a1e3db2230b9260b`.
Verify collection and executed node membership, not just counts. Record JUnit
failures/errors/skips, exit code and actual completion. No -k/-m, xdist, skips,
xfails, warning suppression, hidden deselection, or dropped/rewritten parameter IDs.

Expected environment-matched warnings are the same three DeprecationWarnings in
unchanged `tests/test_sqlite_b2c_writer_session.py`:
- test_operation_guard_close_waits_and_retains_authority_until_exit
- test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
- test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock

Record actual node/category/location/message/count; do not suppress unexpected
warnings or declare three dots to be completion evidence. The prior report placed
warnings at multiprocessing/popen_fork.py:67 and test lines 1442/1554; verify, do not
copy them as new observations.

One full-suite COLLECTION ONLY is permitted solely if required to investigate a
real selection discrepancy; no full-suite EXECUTION is required by this supplement.
No rerunning five other focused groups or all semantic/causal controls. A bounded
external report/collector-driver correction may rerun only the affected check;
preserve failed trials and never change candidate/test bytes. Stop on a real source,
subject, protected-preservation, unexpected validation or unresolved inventory
problem rather than turning reconciliation into open-ended implementation.

### D2. Closing, bounded retention and cleanup

Recheck all fixed raw subject conditions twice, the 286 source manifest, index
bytes/metadata, current guidance, full known cache and protected refs against this
supplement's original opening; report qualified diagnostic deltas explicitly.
Check after collection and execution that the external source is unchanged. Actual
reads and before/after identities are required, not an unexecuted claim.

For this SUPPLEMENT ONLY, preserve a compact safe evidence record outside the
repository before deleting its disposable executable copy. A fresh private directory
under `/Users/ds/Downloads` may hold the concise addendum, exact module and node
inventories, command/completion summary, JUnit, and source/preservation digests.
No databases, raw fixtures, secrets, private config content, copied repository or
opaque cache need be retained. This is evidence, not product or orchestration truth.
Report actual paths, sizes and hashes. Do not overwrite an existing user artifact.

Classify task-owned temporary files with lstat; do not follow symlinks or open FIFOs/
sockets/devices for inventory. Let owned test processes finish; verify their cleanup.
Remove only positively owned disposable copies/helpers/fixtures after preservation
checks. Report retained compact records separately from removed roots. Do not assert
that the prior root, deleted logs or this supplement's removed paths survive. Do not
repair source, refs, metadata, index or unrelated artifacts as cleanup.

## E. Required concise addendum and disposition

Return one additive correction/qualification, not a replacement 131-line audit:

1. State whether the original expected GUARDS receipt is established from retained
   ACTUAL execution output, or from a NEW authenticated GUARDS run. Distinguish
   verified transcription error from an unproved historical cause.
2. Show both original strings and the supported corrected/new receipt; exact source
   identity, module/node counts, grammar, commands/exits, membership, warnings,
   failures/corrections and immutable-source evidence for any new execution.
3. Resolve C's factual chronology honestly and preserve all historical limitations.
   Do not claim missing command text was reconstructed or old metadata preserved.
4. Identify the unaffected original audit evidence carried forward as reported,
   not rerun. The original FULL 9,098 pass is not a newly observed supplemental run.
5. Report current-interval preservation/cleanup and any actual retained safe artifacts.
   For the evidence-only route, say no repository/test action was performed and no
   fresh live identity was established. A future commit gate still reauthenticates.
6. Give a justified overall disposition for the SAME 70-receipt V4 candidate.

Use `RW0_D2_OFFLINE_EVIDENCE_COGNITIVE_REVIEW_ACCEPTED_READY_FOR_COMMIT_GATE` only
if the discrepancy is supportedly resolved, the original eligible-opening claim
is qualified without inventing evidence, and no new material finding or preservation
limit remains. This relies on the correctly scoped original audit plus explicitly
identified supplemental evidence; it does not mean every original check ran again.

Otherwise use `RW0_D2_OFFLINE_EVIDENCE_COGNITIVE_REVIEW_AUDIT_BLOCKED` with precise
receipt/procedure/validation scope, or `RW0_D2_AUDIT_PROVENANCE_MISMATCH` for a fixed
subject/preservation authentication failure. A hash mismatch alone is not an
implementation bug; an unsupported re-entry claim is not a V5 repair instruction.
Do not publish a new expected hash to force acceptance.

NO staging, commit, push or publication in either route. No broader product claim,
rank-15 admission, Section 41 post-execution insertion, physical C2 decision,
migration 0005, runtime provider/ES/Bridge route, terminal acceptance or RW0-E effect.

---
# Fixed authentication appendices — inert supplied identity, not a repeated whole audit

Only the guidance/opening, exact-source authentication, ref classification and
preservation machinery below applies to a NEW D interval. No historical root or
metadata is recreated. The reusable opener source and all 70 receipts are copied
byte-for-byte from the prior mandate; embedded programs have NOT been run by the lead.

## 1. Fixed subject and preserved opening

Repository: `/Users/ds/Repositories/Governed Execution Coordinator`

```text
branch: trunk_dev
HEAD: 43ae26b9bccf9ad6ce61ec4722e14ac7b460ab18
tree: cc3cc104300f553ada581cee24e80dab6dd885b1
sole parent: 0d0926e3a483a3ab1a4fd597ac0495927352bf35
subject: feat: add RW0-D1 offline process and capsule spine
upstream: origin/trunk_dev at the same locally observed commit; divergence 0/0
worktrees: one
index: exactly 263 stage-zero HEAD entries; no staged/unmerged change
working candidate: exactly 47 modified tracked + 23 working creations = 70 paths
other tracked working endpoints: 216 HEAD-exact
current source endpoints: 286 = 263 baseline + 23 additions
SQL resources/catalog: existing 0001-0004 only; no 0005 or other new migration
current AGENTS SHA-256: ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166
reported unchanged index SHA-256: 7af425d5a47b91b0a14294660f5d449f5ba6308dc8846a8b13aca371c191a587
known opaque cache: src/ge_nwp_coordinator/__pycache__, directory + 37 regular members
```

No network check is authorized. Local tracking equality is not current remote
truth. Do not require a clean working tree, the old ten-file prototype, or an older
D1 candidate. All 23 additions are PRESENT in the working tree and ABSENT from HEAD
and the index. The index remains the baseline tree, not the candidate tree.

Baseline corroboration: the uploaded 3,134,667-byte snapshot, SHA-256
`06d981b6100fc1d6ad9792aff35800eb0772b8d35f708ed030177967ccb9c40e`, reconstructs the
263-leaf tree above. The commit/branch association is report-backed until checked
locally. An old date in the archive filename is not authority. No snapshot is
needed by the auditor when these exact local objects and working files are present.

Establish THIS attempt's index, cache and source-mode observations. Preserve the
known unrelated mode-0600 file
`tests/test_c2b3_private_atomic_program_initialization.py`; its Git mode remains
100644. Do not normalize it. Earlier missing metadata and raw-status deviations
remain historical qualifications; a fresh correct interval does not prove those
older intervals, and those qualifications do not authorize resetting current files.


Use the following unchanged filesystem-only opener from `/` once for this supplemental interval, if D is required:

```sh
python3 -I -B -S - <<'PY_OPEN'
import hashlib
import json
import os
import stat
from pathlib import Path

REPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')
AGENTS_SHA = 'ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166'
GUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',
          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}
OVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',
             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',
             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')

def meta(st):
    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,
            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),
            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,
            'mtime_ns': st.st_mtime_ns}

def regular_record(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise RuntimeError('opening_requires_regular_nonsymlink_file')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_before_read')
        h = hashlib.sha256()
        while True:
            chunk = os.read(fd, 1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_during_read')
    finally:
        os.close(fd)
    if meta(path.lstat()) != meta(before):
        raise RuntimeError('opening_file_changed_after_read')
    return {**meta(before), 'sha256': h.hexdigest()}

def index_path():
    dotgit = REPO / '.git'
    st = dotgit.lstat()
    if stat.S_ISDIR(st.st_mode):
        gitdir = dotgit
    elif stat.S_ISREG(st.st_mode):
        regular_record(dotgit)
        raw = dotgit.read_text(encoding='utf-8').strip()
        if not raw.startswith('gitdir: ') or '\n' in raw:
            raise RuntimeError('unsupported_gitdir_pointer')
        pointed = Path(raw[len('gitdir: '):])
        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()
        if not stat.S_ISDIR(gitdir.lstat().st_mode):
            raise RuntimeError('gitdir_not_directory')
    else:
        raise RuntimeError('unsupported_dotgit_type')
    return gitdir / 'index'

def cache_record():
    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'
    st = cache.lstat()
    if not stat.S_ISDIR(st.st_mode):
        raise RuntimeError('cache_directory_missing_or_unsafe')
    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))
    if len(members) != 37:
        raise RuntimeError('unexpected_cache_membership')
    out = {'.': meta(st)}
    for path in members:
        out[path.name] = regular_record(path)
    if meta(cache.lstat()) != meta(st):
        raise RuntimeError('cache_directory_changed_during_read')
    return out

def guarded_environment():
    present = [name for name in OVERRIDES if name in os.environ]
    if present:
        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))
    env = dict(os.environ)
    env.update(GUARDS)
    env['GIT_PAGER'] = 'cat'
    env['PAGER'] = 'cat'
    return env


import datetime
import shutil
import tempfile

guarded_environment()
agents = regular_record(REPO / 'AGENTS.md')
if agents['sha256'] != AGENTS_SHA:
    raise RuntimeError('guidance_not_exact_audited_candidate')
index = index_path()
index_before = regular_record(index)
cache_before = cache_record()
git = shutil.which('git')
if git is None:
    raise RuntimeError('installed_git_unavailable')
gate_root = Path(tempfile.mkdtemp(prefix='rw0-d2-repaired-v4-audit-'))
os.chmod(gate_root, 0o700)
print('GATE_OWNED_ROOT=' + str(gate_root), flush=True)
record = {
    'schema': 'rw0-d2-repaired-v4-audit-opening-observation',
    'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'repo': str(REPO), 'guidance': agents, 'index_path': str(index),
    'index': index_before, 'cache': cache_before, 'git_executable': git,
    'git_environment': GUARDS,
    'limit': 'This re-audit interval only. Source, index, guidance, cache and protected refs remain unchanged. Section 1R governs separately observed and conditionally classified turn-diffs refs; no auditor ref write, source repair, staging, commit or remote action is authorized.'
}
READ_HELPER = "import hashlib\nimport json\nimport os\nimport stat\nfrom pathlib import Path\n\nREPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')\nAGENTS_SHA = 'ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166'\nGUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',\n          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}\nOVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',\n             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',\n             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')\n\ndef meta(st):\n    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,\n            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),\n            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,\n            'mtime_ns': st.st_mtime_ns}\n\ndef regular_record(path):\n    before = path.lstat()\n    if not stat.S_ISREG(before.st_mode):\n        raise RuntimeError('opening_requires_regular_nonsymlink_file')\n    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)\n    try:\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_before_read')\n        h = hashlib.sha256()\n        while True:\n            chunk = os.read(fd, 1024 * 1024)\n            if not chunk:\n                break\n            h.update(chunk)\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_during_read')\n    finally:\n        os.close(fd)\n    if meta(path.lstat()) != meta(before):\n        raise RuntimeError('opening_file_changed_after_read')\n    return {**meta(before), 'sha256': h.hexdigest()}\n\ndef index_path():\n    dotgit = REPO / '.git'\n    st = dotgit.lstat()\n    if stat.S_ISDIR(st.st_mode):\n        gitdir = dotgit\n    elif stat.S_ISREG(st.st_mode):\n        regular_record(dotgit)\n        raw = dotgit.read_text(encoding='utf-8').strip()\n        if not raw.startswith('gitdir: ') or '\\n' in raw:\n            raise RuntimeError('unsupported_gitdir_pointer')\n        pointed = Path(raw[len('gitdir: '):])\n        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()\n        if not stat.S_ISDIR(gitdir.lstat().st_mode):\n            raise RuntimeError('gitdir_not_directory')\n    else:\n        raise RuntimeError('unsupported_dotgit_type')\n    return gitdir / 'index'\n\ndef cache_record():\n    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'\n    st = cache.lstat()\n    if not stat.S_ISDIR(st.st_mode):\n        raise RuntimeError('cache_directory_missing_or_unsafe')\n    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))\n    if len(members) != 37:\n        raise RuntimeError('unexpected_cache_membership')\n    out = {'.': meta(st)}\n    for path in members:\n        out[path.name] = regular_record(path)\n    if meta(cache.lstat()) != meta(st):\n        raise RuntimeError('cache_directory_changed_during_read')\n    return out\n\ndef guarded_environment():\n    present = [name for name in OVERRIDES if name in os.environ]\n    if present:\n        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))\n    env = dict(os.environ)\n    env.update(GUARDS)\n    env['GIT_PAGER'] = 'cat'\n    env['PAGER'] = 'cat'\n    return env\n\n\nimport subprocess\nimport sys\nopening = json.loads(Path(__file__).with_name('opening.json').read_text(encoding='utf-8'))\n\ndef immutable_checks():\n    if str(index_path()) != opening['index_path']:\n        raise RuntimeError('index_location_drift')\n    if regular_record(index_path()) != opening['index']:\n        raise RuntimeError('audit_index_content_or_metadata_drift')\n    if regular_record(REPO / 'AGENTS.md') != opening['guidance']:\n        raise RuntimeError('audit_guidance_content_or_metadata_drift')\n    if cache_record() != opening['cache']:\n        raise RuntimeError('live_cache_drift')\n\nimmutable_checks()\nindex_before_read = regular_record(index_path())\nargs = sys.argv[1:]\nif args == ['--check']:\n    print('READ_HELPER_IMMUTABLE_SURFACES_MATCH')\n    print('CURRENT_INDEX_SHA256=' + index_before_read['sha256'])\n    print('Index content and metadata equal this audit opening; no stage or index write is permitted.')\n    raise SystemExit(0)\nallowed = {'status', 'rev-parse', 'rev-list', 'ls-files', 'ls-tree',\n           'cat-file', 'diff', 'show', 'log', 'symbolic-ref', 'worktree',\n           'check-attr', 'for-each-ref', 'reflog'}\nif not args or args[0] not in allowed:\n    raise RuntimeError('unapproved_live_read_command')\nif args[0] == 'symbolic-ref' and args[1:] not in (['HEAD'], ['-q', 'HEAD'], ['--quiet', 'HEAD']):\n    raise RuntimeError('readonly_head_query_only')\nif args[0] == 'worktree' and args[1:] not in (['list'], ['list', '--porcelain']):\n    raise RuntimeError('readonly_worktree_list_only')\nif args[0] == 'reflog' and (len(args) < 2 or args[1] != 'show'):\n    raise RuntimeError('readonly_reflog_show_only')\nfor arg in args[1:]:\n    if arg in ('--ext-diff', '--textconv', '--filters', '--output', '--exec') or arg.startswith(('--output=', '--exec=')):\n        raise RuntimeError('unapproved_output_or_execution_option')\nif args[0] in ('diff', 'show', 'log'):\n    args = [args[0], '--no-ext-diff', '--no-textconv', *args[1:]]\ncommand = [opening['git_executable'], '--no-pager', '-c', 'core.fsmonitor=false',\n           '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', '-C', str(REPO), *args]\ntry:\n    result = subprocess.run(command, env=guarded_environment(), check=False)\nfinally:\n    immutable_checks()\n    if regular_record(index_path()) != index_before_read:\n        raise RuntimeError('index_changed_during_read_command')\nraise SystemExit(result.returncode)\n"

def write_private(path, payload):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as f:
        f.write(payload)

try:
    write_private(gate_root / 'opening.json',
                  (json.dumps(record, sort_keys=True, separators=(',', ':')) + '\n').encode())
    write_private(gate_root / 'live_read.py', READ_HELPER.encode())
    if regular_record(index) != index_before or cache_record() != cache_before:
        raise RuntimeError('opening_changed_before_first_git')
    print('OPENING_RECORD=' + str(gate_root / 'opening.json'))
    print('LIVE_READ_HELPER=' + str(gate_root / 'live_read.py'))
    print('OPENING_INDEX_SHA256=' + index_before['sha256'])
    print('RW0_D2_AUDIT_PRE_GIT_OPENING_RECORDED')
except BaseException:
    for name in ('opening.json', 'live_read.py'):
        p = gate_root / name
        if p.exists():
            if not stat.S_ISREG(p.lstat().st_mode):
                raise RuntimeError('unexpected_owned_helper_type')
            p.unlink()
    gate_root.rmdir()
    raise
PY_OPEN
```

Use only ACTUAL emitted paths. Every live Git read goes through this helper:

```sh
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> --check
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> rev-parse HEAD
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> status --short --untracked-files=all
```

Authenticate all baseline/index/source conditions before cloning or tests. Current
working endpoints must be the exact 47 M + 23 C, all other 216 HEAD-exact; no staged
or unmerged entries, unknown source changes, active conflicting Git operations,
unexpected locks, or unsupported source types. Read metadata without normalizing it.
Live cached code is opaque and excluded from executable selection. An opener/helper
failure, unguarded post-opening Git, protected drift or unknown competing writer
blocks rather than authorizing a new opening or fallback. Use the same helper for
this interval's closing and then remove only its positively owned disposable root.

## 1R. Protected refs and conditional diagnostic observation

The V4 writer reports 53 refs, unchanged across its opening, pre-execution and
closing serializations, SHA-256
16e44ef6fcd901ec330dde4db7f54921535c9c349e9377f5c5fa3ad0702e0b33.
The immediately preceding independent V3 audit reported 52 refs (28 protected and
24 conditionally diagnostic), zero interval delta, snapshot SHA-256
e4b7d69b413ddf78d66a9ddd934b9312e1c8cc1f3c07b2af065c97203120b226.
These are separate interval observations, NOT fixed ref counts or serialization
anchors for this new audit. Record the actual current inventory. A between-interval
count difference alone establishes neither within-interval drift nor its cause.

The earlier V1 repair's all-ref preservation assertion DID fail: two removed refs
at object 014f6845ec3672c7a2c2e54f8745e8d2e0505a06 and two additions at
1450a5e4845d20d9199004ea862ebdeadb8139e0. Its writer/cause remains unestablished.
Do not attribute that failure to the zero-delta later intervals, restore a historical
ref, infer harmlessness from a namespace name, or start a forensic/ref-repair program.

After the opener and BEFORE external execution, use the emitted live-read helper
for complete actual names/OIDs/symbolic targets, including these read arguments:

```text
for-each-ref --format=%(refname)%09%(objectname)%09%(symref)
symbolic-ref -q HEAD
```

Record exact serialization and its hash outside the checkout. Protect EVERY ref
by default, HEAD's symbolic target and resolved object separately, all branch/tag/
tracking refs and all source-selection dependencies. Only actual records beneath:

```text
refs/codex/turn-diffs/captures/
refs/codex/turn-diffs/checkpoints/
```

may receive a conditional non-authoritative diagnostic classification. Inspect
actual use in source/guidance/config and available task records, including generic
ref enumeration or `--all` source selection where relevant. No program, baseline,
policy/admission, publication, recovery or validation source/expectation may depend
on a diagnostic ref. No protected symbolic ref may resolve through one. A literal
search absence alone is not proof when indirect selection exists. This audit's
executable source is the supplied fixed HEAD plus the aggregate-authenticated
working payloads, never a captured ref/tree. Prior classification may support the
bounded current check where supplying code and dependencies remain exact.

All unknown/out-of-scope refs, and any record inside those subtrees actually used
as a protected dependency, remain protected. No blanket refs/codex/** exemption.
New records or symbolic dependencies require the same qualification. No provider
state inspection, recursive captured-blob dump, fetch of unavailable objects,
checkout of captured trees, ref recreation or object restoration. Minimal available
object type/commit-header/tree metadata may be used when material; missing history
stays unavailable. `origin/HEAD -> origin/main` need not equal this branch's upstream
and must not be "corrected".

Record full ref snapshots after opening, before executable work/final validation,
and at closing. Compare protected records to the SAME opening, never replace it
on drift. Disclose qualified diagnostic old/new deltas separately. They are real
Git changes, not automatically candidate defects or permission for auditor writes.
Unknown protected dependency, source/index/protected-ref drift or observed competing
source writer blocks before further execution. A diagnostic exception never excuses
changed source, index, cache, guidance, configuration or authority.

On successful classification continue the audit in the same engagement. No new
approval or classification-only transport task. The first V1 all-ref failure and
all later correctly recorded intervals retain their own provenance.

## 2. Exact V4 subject: all seventy fixed endpoint receipts

Exactly 47 modified tracked paths and 23 working creations against the fixed HEAD.
All 70 are regular nonsymlink OS 0644 / Git 100644 files. The other 216 tracked
working files equal HEAD, preserving their actual opening OS modes. The index
contains the 263 stage-zero baseline entries, not the working candidate tree.

```text
Rows: 70 (47 M, 23 C)
Raw payload bytes: 5,856,685
Encoded row bytes: 5,862,083
Complete framed bytes: 5,862,108
Fixed complete RAW replacement SHA-256:
9b14b520984e5e6a090482ee473b45a301b762176b94e3acd1ad05f786188efd
```

Authenticate every supplied receipt and its baseline/absence relationship BEFORE
repository code executes. Reconstruct the complete raw replacement twice from fresh
reads, preferably once streaming and once explicitly concatenated. Exact framing:

```text
25-byte prefix: ASCII RW0-D2-BINARY-REPLACE-V1 followed by one NUL
Rows sorted by UTF-8 repository-relative path bytes:
  u16be(path byte length) + exact path UTF-8
  ASCII M or C relative to fixed HEAD
  u32be(0o100644)
  20 raw baseline Git blob bytes for M, or 20 zero bytes for C
  u64be(payload byte length) + exact current raw payload bytes
```

Both constructions must match ALL stated sizes, the fixed digest, every endpoint
receipt and stable metadata. Hash raw payloads, not strings containing their hashes.
An unrecognized path, mode, baseline, receipt or protected-surface mismatch blocks
before code/tests. Do not select new acceptable bytes, normalize or repair files,
accept a preceding version, or use passing counts to excuse a mismatch.

This table derives from T40's complete V3 receipts with only the two T41 replacements.
The original handback and integration receipts previously omitted by the V3 writer
were resolved by the independent V3 audit; they are fixed entries here, not measured
wildcards. The unchanged checkpoint is also fixed. These are supplied audit anchors,
not a claim that ChatGPT authenticated the live candidate.

| Path | Status | Baseline Git blob (C: absent) | Current bytes | Current SHA-256 |
|---|---|---|---:|---|
| `.docs/architecture.md` | M | `7d21418a68d2d3002753227da08cf059836d0260` | 44,745 | `5075b772afddcfe8276933d189155aa689dc4c1ee162bb702c7c7f4efaf04635` |
| `.docs/authority-boundaries.md` | M | `3524d11d67a46344214b455396afeeaa3754b41d` | 36,175 | `79c57d377b6ef7f2460ee5a5827b9c5c61334e656be9eeed73264a6906e55e32` |
| `.docs/autonomous-software-development-operating-model.md` | M | `a46d51fe3ea480e39c8c7989a08e80d9db21f5b8` | 41,197 | `926468bad8cd51c57e3aec6da775c6dced52880215f24d5b03177499a119c6c2` |
| `.docs/b3b2a-read-scope-and-query-contracts.md` | M | `c3237c31fc4b59dcd632b827a4be9907cfcfb998` | 10,013 | `74b1d21b02cd9886a697e1f1cb01dca6977cabb2da194269a35d49745fe548f6` |
| `.docs/b3b2b-select-readers.md` | M | `f1ba74b0a5cd3946a3138de326949d29f789cfac` | 6,477 | `fa7a364ce070b3fcef44907bc884bc783200e1951c618fd7e392d485497c7f07` |
| `.docs/c2b-durable-development-state.md` | M | `04c068d07cd08feaf6c56dafbf3494ccde037ede` | 1,891,411 | `8db2ba24f0685ac21fae2103bb664727a8d9635d3ead5f6bae0d42b35aaf34d2` |
| `.docs/c2b2-private-readers.md` | M | `018b3d905f5db80cf15b546f881dc8c1de3a67b7` | 14,020 | `f765b2dcd74979e235cb04c15dd1fbc81eca149aec017ca500708903bbc105d2` |
| `.docs/c2b2-pure-durable-row-values.md` | M | `1cab6d886f2cd3101987476064a9ce82d2eb4dd2` | 8,540 | `0970595b4c292517d0770542ff8e12a03b98ea93057d4e715d6518415e83aaf3` |
| `.docs/durable-state-model.md` | M | `49694cd86a51f3fb0fb3799e734a52c1a395b8c7` | 42,053 | `7f9cba19f491322dd2fc0f1656ac6b76e698723a6700d1f9919d22b2196e9e80` |
| `.docs/rw0-b1-pure-phase-values.md` | M | `5b7fb0072c6d04898cd212fdc4ff5f63903cf13b` | 35,115 | `7294e7b3aabad5338c4d846e44686ffd075b3e8fe4598495a3e7267103a9ef1e` |
| `.docs/rw0-b2-wire-protocol.md` | M | `5e41d1cb3b2f430d29eb88bdbf2b46570faf3c6b` | 26,084 | `ac1091f043f5fa6042ced1e919c740a08af975b7df1e5e97b66634f85cb68e69` |
| `.docs/rw0-c1-durable-evidence.md` | M | `a7111c4dcf761b60df35c59794bf2e3acd949745` | 15,037 | `f2c6c51d0437aa78b7975bfca3e6fc629fc2898d55c0c696750221000343a02c` |
| `.docs/rw0-c2-first-live-proof-posture.md` | M | `4b69e424655ea67900f6c6042c0cbacaf2d53f8a` | 17,674 | `ba61008234eb5ec85416c459dab0a82b19f7e1a0662dcb15f1289ba445fdf5bd` |
| `.docs/rw0-d1-offline-process-and-capsule-spine.md` | M | `f3557ca523cac0d6fa26647b17a84aef66fecc15` | 5,624 | `b537fbe074717aacdfaefd2cf32cd22c46046034ae115453ddded4e2dc25201b` |
| `.docs/rw0-d2-offline-evidence-and-review.md` | C | `absent` | 8,348 | `f9306ad7333ae08aefd62456041629380c05e984bddc3925258c655a28fa7580` |
| `.docs/rw0-remote-worker-contact-phase-entry.md` | M | `230167a39b115634c8f9b5ae5a0699639f6ff454` | 59,586 | `bee20ed00c7e6f86db3394351f0cbe29626413c635cd9a982416984b288e6fbd` |
| `.docs/worker-execution-boundary.md` | M | `464aef2aa7a561e4adc6792d1d07642d3576f364` | 32,409 | `3cfc1208d96e1f59a81dcd70dce5d43d89f2cb70cc5af6eca453650c33742769` |
| `AGENTS.md` | M | `254854d4a57487d97ce02a73ce2ed26c86ece170` | 64,142 | `ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166` |
| `README.md` | M | `088c832ca7e28d18c82ff6317738ac8ca1c7b5d1` | 47,694 | `f48f2439d282350e36b5d8374864cb5dfe19eb417672737e820500c3a68224f3` |
| `src/ge_nwp_coordinator/_cognitive_proposal_semantic_values.py` | M | `c164616b9e86379c3c6a9210cf4941429a596d4c` | 71,190 | `40243b96765ee0bf49e56a36123e0553f3bb9ab3e0fada38dbe619a2acc1eacd` |
| `src/ge_nwp_coordinator/_development_bound_effect_establishment_contracts.py` | C | `absent` | 43,039 | `fd8fb53c8129001b74df8fa5b15ae69bb45fd970e2aa93f3bc5c20eeeeb1b370` |
| `src/ge_nwp_coordinator/_rw0_d1_fake_worker.py` | M | `cb37f733141f1e3c3ce874fcc052149de1f82881` | 3,668 | `21e0c9d6c2ece57b87dfb05e961ba1a99a48e72346bbab2c4c1ed571eb5f1f00` |
| `src/ge_nwp_coordinator/_rw0_d1_handback.py` | M | `ecfcf767a5f1c32c0cf007a2c8aa3137ef92374d` | 16,920 | `3cae7fa4423187d53382ba23d9e459a5f0efcb6900a4deed6d4498ed2534ed56` |
| `src/ge_nwp_coordinator/_rw0_d1_offline.py` | M | `4f2a82e46fda9be8123888f5ca46968a4345c25f` | 23,371 | `9546f06f211253d72ea91e0dc2eaf4f0b47fdd54e3d431207f59960fbc742c95` |
| `src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py` | M | `7dc90a0442e348aaac985d711c4d1a97adb7cc05` | 12,175 | `a236bbf599e7d32b4edcc31d23182fd9613c5d290f31a0f1e57961b6a104fe56` |
| `src/ge_nwp_coordinator/_rw0_d2_handback.py` | C | `absent` | 28,905 | `85ea3872fe52dbf12608b1dcd47499b76ff11fc556b0c689498fdce56346f7ed` |
| `src/ge_nwp_coordinator/_rw0_d2_offline.py` | C | `absent` | 6,967 | `d838dd02495cab5cbafa2e6e0b99d6a4e6b4b30e4ac5cb288cb9dd2db02d0d44` |
| `src/ge_nwp_coordinator/_rw0_d2a_evidence.py` | C | `absent` | 53,134 | `e93c2592c8f838bd178ffa8e57f57a9116fcdf567b248e511496d00384968ec9` |
| `src/ge_nwp_coordinator/_rw0_d2a_fake_reviewer.py` | C | `absent` | 2,878 | `0d061fdf600039ff69ba0d0dc3f1a0239c2527500461244bb53455bbdd326973` |
| `src/ge_nwp_coordinator/_rw0_d2a_fake_validator.py` | C | `absent` | 2,726 | `c1eb49503b4345d25047814e089545f9d1cd4c85f10ae20254b8b6283fa58fbe` |
| `src/ge_nwp_coordinator/_rw0_d2a_handback.py` | C | `absent` | 20,455 | `7d1fc29c303666907c3f6e863f551d448684009db0d0b1db9881d64889e0e14f` |
| `src/ge_nwp_coordinator/_rw0_d2a_offline.py` | C | `absent` | 30,416 | `d81db9535b17c7daae7be449d7e30dbcaaa599749ddc2619dbfa7d40f87db838` |
| `src/ge_nwp_coordinator/_rw0_d2a_process_frames.py` | C | `absent` | 6,397 | `2c969b1ec303674500143bbbd721e4fe5f7ee161e00b4343f71a611a7f075c8d` |
| `src/ge_nwp_coordinator/_rw0_d2a_workspace.py` | C | `absent` | 5,075 | `45086c2b216639d3a35deef972acda526f004608780a8a8b5e30ed51253f0697` |
| `src/ge_nwp_coordinator/_rw0_d2b_fake_review_model.py` | C | `absent` | 3,771 | `492288c84c2491120a56c7056000f8ec3860c7fbce2bcb3c33249e5e1af5d93a` |
| `src/ge_nwp_coordinator/_rw0_d2b_model_frames.py` | C | `absent` | 8,032 | `e4b7cddc6cfd4caa7e34781e1c34c00833d6f83a98477d46ce55e878e97dfcef` |
| `src/ge_nwp_coordinator/_rw0_d2b_model_input.py` | C | `absent` | 81,718 | `e2bbe585f8ae19df5dd6547212cf239ac58411795cbae904cf3ed869910bdd9a` |
| `src/ge_nwp_coordinator/_rw0_d2b_proposal.py` | C | `absent` | 22,718 | `deec7caf82206c40545a308f3a8845fb867e64a211a81e055fb29ffbafc0666a` |
| `src/ge_nwp_coordinator/_sqlite_development_bound_effect_establishment.py` | C | `absent` | 23,760 | `c1005096ec8761257927a7b983dcb43b922cd89193338a761ba15ae5368cb5f5` |
| `src/ge_nwp_coordinator/_sqlite_rw0_c1.py` | M | `635b5dd49256e14103fced6ff8ea4db76649e22c` | 203,409 | `d17490b3ce1b136eeb3d559f01f44e97836827bc137325b306ec01530e06e9e7` |
| `src/ge_nwp_coordinator/sqlite_transition_transaction.py` | M | `f8053db4010faaba41b38b531d93a8b21e80daa8` | 180,600 | `6d662dcb83a2641b9d95dee7209ddbd0d8b991bc720da3aafa5b4b9fb3bc5521` |
| `src/ge_nwp_coordinator/sqlite_writer_session.py` | M | `97162e3a749a7f1f1ae75de90c4b2d9092068107` | 299,804 | `54f9c5a0844421686c1c89cdecf3c2865263b3339d2faec933c615ca2ca3d404` |
| `tests/test_b2a_writer_session_contract.py` | M | `ccadd884de29d606c9243ea7796cc380e29fe5c2` | 29,168 | `835b386274f410f2fc52b1a40b2c936009ac5286fb22bc23cc28efa789be0664` |
| `tests/test_b3b2a_read_scope_and_query_contracts.py` | M | `66cab4655d33c1b864f5fb4c22e853a39c5a8188` | 26,502 | `4cabeed0c37a99c0f937c0b49f25c7c6a049eb9125e64127019c449dcd86313a` |
| `tests/test_b3b2b_select_readers.py` | M | `c0c5a0e091572f30a428fd5a2634c21d25a6ad64` | 118,350 | `22061f6846b0ebc969f9b67bac399b8d8eb237c8df0e2de92d84d477c0f1ce2b` |
| `tests/test_b3c4c_prerequisite_contract.py` | M | `f1ee03232e33da8bbfa5592fe81c53414acb25b1` | 36,340 | `3d25c2ffb8ee86856c154cfc9dd842bab2db87ea2b200cd75758a62f372b5cd8` |
| `tests/test_c2a_nonimplementation.py` | M | `3f343ae5886c92941ebfff63ba4213de2109025e` | 30,650 | `c0db68e10f4588c02bbc38da1b95d6898a3d7896c127038533ce0c8a6715442e` |
| `tests/test_c2b0_durable_state_contract.py` | M | `b910d61aaf670ba40a0d649f933c06767e7360e5` | 887,367 | `995c3690500e3d3009f1fe93b276db506e1d454764dd2e5167df52bf81252c1a` |
| `tests/test_c2b2_development_reader_contracts.py` | M | `122f0d44b46e0a8d7b283d5baec1ce465e2028b6` | 71,365 | `28dbf4fff09d75d7522af35c8fddc8908b7c4c1d18ff8043d19dbf6b90f30970` |
| `tests/test_c2b2_development_row_value_boundaries.py` | M | `d7dea23786bec2ca98bb702bbe93cc31e4192221` | 17,972 | `f2a7089748f39dc8c40a932ac770edd3ffa7f8ea581b053af101dfda8100c830` |
| `tests/test_post_execution_pure_owner_boundaries.py` | M | `437a4e7cbd39682bdd08f03b3a30c0bbbd057614` | 19,302 | `7945be6d5e01c2a1b437cabc57972bbd70a725da9c14f7dd92574ff8f8633014` |
| `tests/test_post_execution_pure_owner_vectors.py` | M | `3eed1c6bc08b6876d1e74d94a4e5509c14786eb0` | 103,682 | `3d526cabcead871b5bba47952b914df76a34b5d85a7b730e55afb951c050de16` |
| `tests/test_runtime_non_authority.py` | M | `79d4ab185815234c9d087c48d2439b9a1d95d95d` | 48,343 | `fef5729d8e7f4c619ddb2731b52d3500bc8e75988a3f422648b9dea743ef01c9` |
| `tests/test_rw0_b1_boundaries.py` | M | `17d1e09c30b01287718c6b5175bac76b03daf458` | 52,838 | `af8d9f7507733876a5978d1a3f5b871a81030380eba929cbffe6959f9d639aaa` |
| `tests/test_rw0_b2_capability_boundaries.py` | M | `4668d2a2c285d2d79bf6ebfb0c9c9f60166bcb27` | 50,538 | `85ee20f37629ffc852154cea67dd5dc983b0f2f74ab2d370192c13d999b397c3` |
| `tests/test_rw0_b2_wire_boundaries.py` | M | `9e04f528326a6f337a4f47e7e9f9eda3c9a82e0a` | 38,513 | `13531d5d46258ca67cc7bf0bddd78c560ce9b7308ff296068a146299f349ba27` |
| `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | M | `0f0159c172e1448d2b96ab19411e1f85467a2931` | 120,405 | `af7f49ac8da64c12e97d03a536ee10b89a11996651b0d712dc04baef427d8cf3` |
| `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | M | `e9d95b54a4b5921be8ec39d2bf3f6216204750c7` | 247,679 | `e8de37791388c28f1b1626747af6c4094622469168ed9799eaa78f7f6f4d3613` |
| `tests/test_rw0_d1_handback_values.py` | M | `982be9b37aa05db0c6d6a3321b775c7c64f2142d` | 30,189 | `e8addc00e8b37aa5e6f24a91a637c9f5053656c58a0d4c06e713618229e448b6` |
| `tests/test_rw0_d1_offline_integration.py` | M | `33c2d85012cbdf0e7e04fdeb7d333d2c8675ae3f` | 53,132 | `c5997a4e9161253974b04b203bf55754c12b465c3b0b5924247e6c1df8e05c9e` |
| `tests/test_rw0_d1_worker_process.py` | M | `e2a83abe44db720b5ce0725682ac71d30372959d` | 1,737 | `512d7d61083e8ad8c61c197aefc86f70d61a1f7e41273fab435bb493cc08631f` |
| `tests/test_rw0_d2_bound_effect_contracts.py` | C | `absent` | 5,636 | `4c8f04a5f16d0e0b236f8fff636e5d9a5d41c465dad6fc726bd488fb76b59574` |
| `tests/test_rw0_d2_bound_effect_persistence.py` | C | `absent` | 20,950 | `af0e25fe73742b82ce205c420646a18221325c15820a6c3893719eaaeec436f0` |
| `tests/test_rw0_d2_c1_checked_readback.py` | C | `absent` | 17,750 | `20237660028125bacccf52bb695cb275adebefb2ed1f0a28bb271688f7aadb01` |
| `tests/test_rw0_d2_evidence_children.py` | C | `absent` | 3,635 | `fd4cd60a30cb641d34b458f7782bcc27d020a37f47f6523c37cfcf83895d516b` |
| `tests/test_rw0_d2_model_handback.py` | C | `absent` | 4,966 | `89c53206f1b636257ecf5f71027e11ca4ef4cfdd00883e55b2c0fa02fe2a7a6e` |
| `tests/test_rw0_d2_offline_integration.py` | C | `absent` | 51,581 | `e682b402875f7115d210d9c11bf1211f004efc388f8414163e4b42556ab96e36` |
| `tests/test_rw0_d2_process_frames.py` | C | `absent` | 6,894 | `f77f49268e4ed693d049560307aa3794538842efc8afa24e1500664fc4884264` |
| `tests/test_rw0_remote_contact_phase_entry_contract.py` | M | `2a9144c3dfd2c883555703c8adecd21f447d6d34` | 177,317 | `6df3c991a219633d148106396336f2702c323b6cddb82932b41152ea3e5ac16a` |
| `tests/test_sqlite_backend_b0_contract.py` | M | `c646df6d439d0b70f45d6d72200fbedb5e730779` | 26,412 | `1eb038201c19be7e9680f5ee6c4425fb50051b8bc0df31e3feeab06620cc094e` |
