# Governed Execution Coordinator — RW0-D2 status normalization with an exact P11 successor

This is the complete replacement mandate for the blocked status-normalization
attempt. It supersedes the preceding status-maintenance prompt, including its
two-test-file edit limit. It does not supersede the accepted D2 implementation,
its independent audit, or its commit gate.

Selected decision: correct the current D2 status and explicitly maintain P11's
live identity through a bounded, documented status-only successor. Preserve the
64,142-byte predecessor as a fixed historical identity and prove exact two-span
reconstruction. Do NOT remove P11, normalize the bytes used by its current live
checks, or merely regenerate hashes until a test passes. The companion bootstrap
guard's independent P11 expectation is in scope too; preserve its real checks.

## 1. Objective and effect ceiling

Use the implementation/repair Codex conversation, with repository write permission.
One parent, one repository writer; no subagents. Keep other repository conversations
idle. Complete the bounded inspection, edit, validation, and evidence handoff in
this engagement without a separate reconnaissance/approval round trip.

Objective: correct the two reported CURRENT RW0-D2 repository-status projections
so they accurately distinguish the independently accepted, locally committed
implementation from future product capabilities. Preserve the D2 implementation
commit intact. Return a small uncommitted status-maintenance patch for independent
artifact review, not a new D2 implementation candidate or a new product tranche.

This engagement authorizes:
- Inert inspection of the one repository and the named retained commit-gate bundle.
- Minimal current-status edits in AGENTS.md and
  .docs/c2b-durable-development-state.md.
- A small assurance note in the existing Capability owner explaining the exact
  later P11 status-only successor, without changing Capability semantics.
- Narrow current-status tests and P11 successor maintenance in the FOUR existing
  test modules named in section 5. No other source edit is authorized.
- Focused validation in an authenticated, disposable EXTERNAL source copy.
- Creation of a safe, reviewable external handoff package and its receipts.

It does NOT authorize staging, committing, amending, resetting, restoring,
stashing, cleaning the live checkout, rebasing, cherry-picking, branch creation,
ref mutation, fetching, pushing, PR creation, merging, network access, dependency
installation, production-source/runtime/schema/configuration changes, or another tranche.
Do not invoke repository code, tests, plugins, scripts, or product child processes
from the live checkout. Do not execute a retained gate/audit helper just because
it exists in an evidence bundle. This is repository documentation maintenance,
not a Coordinator product effect or acceptance decision.

Classifications:
- D2 runtime/authority behavior and the original implementation commit: preserved
  current contracts and bounded proof, not reopened by this task.
- The two D2 current-status projections: evidence/status maintenance.
- P11's application of whole-file identity to mutable current-status prose:
  explicitly reopened TEST-ASSURANCE seam, settled narrowly by section 5 here.
- No new autonomous-development capability, general status framework, contract
  reset, or new historical-source owner is selected.

## 2. Fixed baseline and accepted evidence

Repository:
  /Users/ds/Repositories/Governed Execution Coordinator/
Branch:
  codex/rw0-d2-offline-evidence-cognitive-review-v1
HEAD:
  59621aa041a409c6ead27b74ffe25598c159e78e
HEAD subject:
  feat: add RW0-D2 offline evidence and cognitive review
Sole parent:
  43ae26b9bccf9ad6ce61ec4722e14ac7b460ab18
Tree:
  532f52a7c81b13ad3cbd4f60318f4c3ad137af90
Complete committed/index inventory:
  286 entries
Expected opening source/index posture:
  clean; no staged or unmerged entry; topic has no upstream
Locally observed trunk_dev and origin/trunk_dev:
  43ae26b9bccf9ad6ce61ec4722e14ac7b460ab18
No current remote observation is supplied or authorized.

The independently reviewed implementation changed 70 paths against that parent:
47 modifications and 23 additions; the other 216 paths were parent-exact. Its
accepted raw-replacement SHA-256 remains:
  9b14b520984e5e6a090482ee473b45a301b762176b94e3acd1ad05f786188efd
That identity continues to describe the ORIGINAL implementation commit, not the
later uncommitted documentation patch. Do not replace or recompute old accepted
receipts as though the status patch were V4 bytes.

The supplied independent audit and its original-record correction accepted the
whole selected offline candidate. The subsequent local commit gate reported exact
working/staged/committed identity and one selector-free full run: 131 modules,
9,098 passed, zero failures/errors/skips; Python 3.13.4 and pytest 8.4.1.
FULL module SHA-256:
  3c0ebcd7195ebfb0f483820c25a2f94f613ba42c67e7f714df90873f52ad1061
FULL node SHA-256:
  13298265ca6c9c023008e6051719065b3e9c78e1c2524413f9f7035090cfcbaf
The three reported warnings were the existing Python 3.13 fork DeprecationWarnings
in tests/test_sqlite_b2c_writer_session.py. These are historical validation of the
implementation commit, not a claim that the new status patch has run FULL.

The commit-gate report describes an external checkpoint error after one successful
write-tree, followed by reconstruction/readback of the already-written tree,
without repeating that mutation. Treat that as the reported driver-only correction,
not a source repair or a reason to rerun write-tree. This task must authenticate
current committed objects independently of the old wrapper's success message.
Older audit preservation gaps and the unattributed historical V1 ref incident
remain historical limits; this task does not repair or investigate them.

Named existing evidence root:
  /Users/ds/Downloads/RW0_D2_V4_Local_Commit_Gate_20261021T034406Z_9a5f8274/
Anchors:
- report.md: 3,352 bytes;
  SHA-256 53041b9588ac5dd1492bb93101ba2a8a1b12a26c654068f19070bd515f786435
- result.json: 6,347 bytes;
  SHA-256 f7475faef983db4381e7b36c054ff9f8b23496432d38c153a9cb8a80dca0e231
- file_manifest.json: 5,878 bytes;
  SHA-256 b440653b09be726c8ccbd790b8767d6bc8d5d65898e33febf5d6058f87d7d99a
Read these as inert evidence after checking their exact bytes. Use the manifest to
locate necessary safe committed-inventory receipts within that root; do not scan
unrelated Downloads contents or execute old helpers. Do not mutate this bundle or
require recovery of deleted temporary validation files. An absent or mismatched
anchor must be reported honestly, not silently replaced by a newly generated one.

### 2.1 Latest blocked attempt — evidence, not a new baseline

The supplied report says the preceding attempt stopped before editing because
P11 pins the entire current AGENTS.md to 64,142 bytes and SHA-256
  ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166
It reports the same 59621aa commit, 286-entry tree/index, clean worktree, absent
upstream, and preserved refs/configuration/cache at close. It ran no tests and
made no patch. Do not treat that report as current live authentication.

Latest report anchors and inspection coordinates:
- AGENTS.md:116-123 and 962-972: current D2 status spans.
- .docs/c2b-durable-development-state.md:24934-24947: current D2 status.
- tests/test_c2b0_durable_state_contract.py:19150-19165,19204: status suffix
  consumer requiring a corresponding exact update.
- tests/test_rw0_b2_capability_boundaries.py:144-145,208-228,692-755:
  P11 live identity row, raw byte helper, and mandatory consuming test.
These coordinates are a discovery aid. Re-establish exact ranges on the fixed
commit; do not edit by line number without checking the actual bytes.

The report-only blocker bundle is:
  /Users/ds/Downloads/RW0_D2_Postcommit_Status_Normalization_BLOCKED_20261021T110112Z_9734c949.zip
Reported size: 52,885 bytes.
Reported SHA-256:
  47b31fb942b65b3e3cc2f2af136d3bcad7742f4101aab7e36c245b0984d44efc
Its sibling retained report root is:
  /Users/ds/Downloads/RW0_D2_Postcommit_Status_Normalization_BLOCKED_20261021T110112Z_9734c949/
The supplied report.md is 2,550 bytes, SHA-256
  abb6587ea9daeff659c151bde9b9589e3bf147ac8118bea5301cfc8bfa20ad5f
These are inert optional corroborating sources, not executable helpers or patch
acceptance. The report was inspected here; the ZIP was NOT supplied to ChatGPT.
Do not pretend that ZIP was independently verified. Its absence is not a reason
to abandon the task when the fixed commit and mandatory gate anchors authenticate.

## 3. Entry, preservation, and source grounding

First read the complete current AGENTS.md as inert text and applicable nested
instructions. Respect .docs/ as contract authority. Before Git reads, capture a
NEW filesystem-first observation of the actual index, guidance, relevant config
metadata/digest, protected source modes, and known ignored cache. Do not execute
the previous audit/commit preflight opener: it expects a 263-entry precommit index
and an old dirty-working-tree posture and is not this task's opener.

A fully visible preliminary inert listing/status/branch/log read can be classified
and disclosed before this new opening; ordering alone is not a terminal failure.
Never backdate preservation, replace a successful opening after drift, or excuse
an unknown command, repository execution, competing writer, or unexplained change.

Use installed Git with command-scoped protections, no implicit repository code:
  GIT_OPTIONAL_LOCKS=0
  GIT_NO_LAZY_FETCH=1
  GIT_TERMINAL_PROMPT=0
  GIT_PAGER=cat
  git --no-pager -c core.fsmonitor=false -c gc.auto=0 \
      -c maintenance.auto=false -C <exact-repository> <explicit-read-argv>
Reject inherited Git location/index/object/config selection overrides. Inspect
relevant attribute/filter/command settings without exposing secrets. Use
--no-ext-diff and --no-textconv for applicable diff/show/log reads. No Git command
that writes objects, index, refs, configuration, or working files is needed.

Authenticate the actual commit object, exact subject, sole parent, tree, complete
286-entry inventory, index equality, clean source state, and absent upstream.
Check all working tracked payloads and modes against their committed counterparts;
do not use file counts or status alone as identity. Preserve the unrelated OS-0600
file tests/test_c2b3_private_atomic_program_initialization.py (Git mode 100644).
The known src/ge_nwp_coordinator/__pycache__ has 37 members: treat it as opaque
pre-existing material, never copy/import/delete it. Unexpected files must be
classified without opening private state or silently expanding source selection.

Record the actual ref inventory. Only the existing qualified diagnostic subtrees
refs/codex/turn-diffs/captures/ and refs/codex/turn-diffs/checkpoints/ may be treated
as tooling diagnostics after checking they do not select source, policy, tests,
recovery, or publication. No ref mutation by this task is authorized. Do not pin
historical diagnostic counts or grant a blanket refs/codex/** exception. Stop on
unexplained protected-ref, index, configuration, or source drift.

Read the exact current D2 status regions and their surrounding text in the two
status documents. Also read, as needed to avoid changing meaning:
- .docs/rw0-d2-offline-evidence-and-review.md
- .docs/rw0-d1-offline-process-and-capsule-spine.md
- .docs/autonomous-software-development-operating-model.md
- .docs/worker-execution-boundary.md
- relevant Section 41/current-status portions of the durable-state document
- .docs/rw0-b2-capability.md, especially its governing-reset identity review
- the direct status/byte-preservation test consumers and their helper calls
- tests/test_rw0_b2_capability_boundaries.py: PROTECTED_CONTENT_ROWS,
  CAPABILITY_REPLACEMENT_EXPECTED, CAPABILITY_OLD_IDENTITIES, semantic markers,
  raw-byte identity helper, source-table validator, mandatory consumer, and
  existing hostile controls
- tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py:
  GUARD_CAPABILITY_EXPECTED, its literal/source checker, document checker,
  and hostile variants; do not overlook this independent companion expectation
- pyproject.toml and applicable validation policy

Inspect all references to P11, those expectation/helper names, AGENTS.md hashes,
and the two status regions within tracked docs/tests before writing. Include the
actual dependency closure in the compact source map. The earlier snapshot shows
that the companion module validates the Capability table's literal AST AND reads
raw AGENTS.md bytes independently. That observation is a predecessor-source aid,
not a claim that the current raw test sources were supplied to ChatGPT. Authenticate
and inspect the actual current files before authoring. In particular, a change to
only the P11 table in the primary module is not the selected complete repair.

The supplied earlier snapshot is a baseline aid, not a replacement for these
current committed bytes. Before editing, record a compact path:line map of the
actual stale assertions, their status-only classification, the test consumers,
and the exact intended touched-file set. This is an internal checkpoint, not a
request for another user turn. Proceed when the bounded scope is satisfied.

## 4. Required status meaning

Correct ONLY statements presenting this D2 implementation as currently awaiting
its independent audit or as an uncommitted implementation candidate. Do not run a
global replacement for 'pending', 'uncommitted', 'accepted', or 'future'. Historical
tranche records, future work, pending/external_verification_pending authority rows,
and frozen semantic contracts keep their existing meanings and bytes.

The current D2 status must state, in the existing document style:
- The bounded offline implementation was independently reviewed and introduced
  by commit 59621aa041a409c6ead27b74ffe25598c159e78e.
- The local commit gate did not push, create a PR, or merge. Express this as a
  historical gate observation, NOT a timeless promise that the branch remains
  unpublished. The text is not a live remote-ref/publication-status view.
- Git owns committed object/ref truth. Audit, validation, provenance, and reports
  are evidence, not Coordinator durable authority or effect permission.
- Existing implementation ownership and the proof's narrow endpoint remain intact.

Preferred short status wording, adapted to the inspected existing region without
rewriting unrelated contract text:

  RW0-D2's bounded private offline implementation was independently reviewed and
  introduced by commit `59621aa041a409c6ead27b74ffe25598c159e78e`. Its local commit
  gate recorded no push, PR, or merge; this statement records that gate, not live
  publication status. Git owns committed object and ref truth. Audit, validation,
  provenance, and closeout records remain evidence rather than Coordinator durable
  authority or permission to perform effects.

Preserve the surrounding scope statement: one artificial offline D1-to-D2 proof,
distinct checking processes and checked evidence, nine-role fake cognitive review,
and a typed transient preadmission handback. It does not add C1 rank-15 admission,
Section 41 POST-execution recording, a physical C2 decision, terminal acceptance,
migration 0005, a live provider/Codex invocation, ES/Bridge routing, a product Git
handler, or an autonomous loop. Do not imply existing pre-execution Section 41
behavior is absent, or that the historical repository commit itself is a product
Git-effect implementation. Preserve standing ownership boundaries.

Use the existing current-status regions rather than inventing a parallel status
owner. In AGENTS.md, preserve every byte outside the TWO explicitly fixed status
spans, including any line endings or surrounding whitespace. In the durable-state
document, preserve every byte outside its fixed D2 status span, including all
historical prefixes and other successors. Only necessary line wrapping INSIDE
those spans is allowed. Do not reorganize AGENTS.md, prune history, reformat the
large durable document, or append a general 'all previous restrictions are
superseded' escape hatch. The separate P11 assurance successor is expressly
selected in section 5; no document-wide normalization grammar is authorized.
Do not embed a future status-commit hash or treat this uncommitted follow-up as
already independently reviewed/committed.

## 5. Permitted touched surfaces and exact P11 treatment

### 5.1 Closed path set

Status documents:
1. AGENTS.md
   baseline 64,142 bytes;
   SHA-256 ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166
2. .docs/c2b-durable-development-state.md
   baseline 1,891,411 bytes;
   SHA-256 8db2ba24f0685ac21fae2103bb664727a8d9635d3ead5f6bae0d42b35aaf34d2

Assurance documentation, one narrow addition to its existing identity-review area:
3. .docs/rw0-b2-capability.md
   baseline 17,753 bytes;
   SHA-256 171341fc60cbe762403f1e64676ca35c9ea2f778a10d0fc66d668f1c84dc884c

Existing test modules, only the bounded changes described below:
4. tests/test_c2b0_durable_state_contract.py
   baseline 887,367 bytes;
   SHA-256 995c3690500e3d3009f1fe93b276db506e1d454764dd2e5167df52bf81252c1a
5. tests/test_architecture_contracts.py
   baseline 100,517 bytes;
   SHA-256 de1a71a6a7ef40dc0ae9509409dd04157e479d3954eafb37e053ef77cb6dcc0b
6. tests/test_rw0_b2_capability_boundaries.py
   baseline 50,538 bytes;
   SHA-256 85ee20f37629ffc852154cea67dd5dc983b0f2f74ab2d370192c13d999b397c3
7. tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
   baseline 120,405 bytes;
   SHA-256 af7f49ac8da64c12e97d03a536ee10b89a11996651b0d712dc04baef427d8cf3

AGENTS, the durable document, its direct test, and both P11 modules are anchored
by the accepted 70-path receipt set. The architecture test and Capability owner
are anchored by the supplied 2026-10-16 snapshot and were absent from that
70-path change set. Authenticate ALL SEVEN against the fixed current commit.
Do not silently adopt a different version. Derive each actual baseline Git blob
from that commit; old receipt 'baseline blob' columns refer to the earlier parent
and must not be mistaken for the 59621aa committed blobs.

Seven is the maximum, not a quota. Do not edit the architecture test merely
because it is allowed. No new tracked file, fixture, shared helper, snapshot
bundle, registry, plugin, conftest, or production import is authorized.

### 5.2 Governing assurance decision

The current P11 identity is a deliberately fixed predecessor for this update:
  path: AGENTS.md
  predecessor commit: 59621aa041a409c6ead27b74ffe25598c159e78e
  predecessor size: 64142
  predecessor SHA-256:
    ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166

The selected successor permits ONLY the two enumerated D2 status replacements.
It does not authorize modifying unrelated instructions, weakening governance,
changing Capability semantics, or recasting the whole document as history.

Keep current raw-file protection AND historical preservation as separate checks:
A. The existing primary and independent companion checks continue hashing the
   complete, ACTUAL current AGENTS.md bytes against explicit current literals.
B. A separate finite successor regression reconstructs the exact predecessor
   by reversing only the two frozen status replacements and verifies the fixed
   predecessor size and SHA-256 above.
C. Current-status assertions check the NEW status meaning and scope, not the
   historical precommit words, in both status documents.

Do not put reconstruction/normalization into A. Do not replace live inspection
with hashing a baseline fixture, a Git-show result, or a cached historical file.
The historical reconstruction is an additional test, not a bypass for the live
identity/semantic check.

### 5.3 Minimal edits to the existing P11 consumers

After inspecting and fixing the exact allowed status text, compute its successor
AGENTS.md size/SHA-256. Freeze that pair as source literals at authoring time in:
- the P11 row of PROTECTED_CONTENT_ROWS in the Capability boundary module;
- P11's replacement_identity in CAPABILITY_REPLACEMENT_EXPECTED there;
- P11's replacement_identity in GUARD_CAPABILITY_EXPECTED in the companion module.

These three current-identity pairs are expressly allowed to change. They must
agree with the same raw successor bytes. Do not calculate expected hashes from
the file under test during test execution or rewrite the table dynamically.
Do not apply a global search/replace to hashes or P11 occurrences.

Retain the 64,142-byte predecessor identity as an explicit NEW historical
status-successor anchor used by the executable regression. Do not confuse it
with, or overwrite, the existing earlier bootstrap-reset old_identity values.
Preserve existing old_identity fields, CAPABILITY_OLD_IDENTITIES, semantic markers,
paths, classes, purposes, other P rows, row counts, literal binding structure,
existing hostile parameter inventories, and all non-P11 expectations unchanged.

Keep the existing raw identity helpers, semantic-observation helpers, literal AST
checks, and mandatory consuming test bodies unchanged. In particular do not
change _assert_exact_content_identity, _guard_replacement_semantic_evidence,
_assert_capability_semantic_integrity, _assert_single_literal_protected_rows_source,
_assert_capability_semantic_source, or _assert_capability_documents_integrity to
accept normalized bytes, skip P11, weaken comparison, catch-and-ignore failures,
return expected evidence, or grant success through a comment/string/no-op call.
The expected-literal changes above plus a separate test-local successor regression
are the intended small patch. Source differences from the predecessor snapshot
must be inspected; do not copy predecessor functions over current ones.

### 5.4 Finite predecessor-to-successor regression

Add the focused historical/status regression in the existing Capability boundary
module, using small pure test-local helpers as needed. No general patch language,
document parser framework, Git subprocess in tests, dynamic discovery, external
runtime dependency, or whole-file duplicated fixture is needed.

Before editing the docs, freeze the exact old bytes of the TWO minimal status
spans from the authenticated commit, with their unambiguous location/context.
Freeze the two new byte strings separately after writing the intended status.
This finite relation must NOT read or derive its expected old/new text from the
document under test during execution.

The historical check must:
- require exact occurrences and ordering of the two intended new spans in their
  expected structural context, with no missing, duplicated, overlapping, or
  ambiguous substitution;
- replace ONLY those two exact spans in memory with the fixed old bytes;
- preserve every other byte, not trim whitespace, normalize LF/CRLF, ignore unknown
  prose, erase entire sections, or strip all text between broad delimiters;
- verify the reconstructed full document is exactly 64,142 bytes with the fixed
  predecessor SHA-256;
- reject the original stale predecessor and a one-span-only update AS CURRENT
  successor input; no fallback branch accepting either old or new status;
- leave the existing independent raw-current identity checks in effect.

Retain the exact before/after bytes and span map in the handoff, so independent
review can verify the relation without trusting the new helper or author report.

Minimum bounded in-memory controls (combine related cases rather than building
an unrelated mutation campaign):
1. Actual successor is accepted; reversing its two spans reproduces the fixed
   predecessor identity. Forward construction from authenticated predecessor
   reproduces the actual successor byte-for-byte during implementation validation.
2. Fully stale status and each mixed old/new two-span combination are rejected.
3. Missing, duplicate, or reordered expected status spans are rejected.
4. Wrong/missing implementation commit and product-authority/acceptance overclaims
   in a status span are rejected.
5. An unrelated one-byte change outside the spans, including an authority sentence,
   is rejected by predecessor identity, even when the new status remains correct.
6. A substantively changed non-status sentence within the containing status region
   is rejected; it must not disappear behind a broad span erasure.

Assert each intended boundary with a valid control rather than counting any
exception as a causal success. Keep these controls pure/in-memory except existing
safe test reads. Do not mutate the live checkout to create test negatives.

### 5.5 Status and owning-document alignment

In tests/test_c2b0_durable_state_contract.py, update only the current D2 status
suffix literal/expectation and, if necessary, add scoped status assertions. Keep
the historical prefix, guard successor, Section 41 meanings, existing D1 status,
and prior authority/currentness negatives intact. Do not regenerate historical
prefix hashes or treat earlier frozen sections as newly editable.

Use tests/test_architecture_contracts.py only if its actual consumers require a
status-literal correction or it is the smallest existing home for the bounded
current-status regression. The real new status must pass. Stale precommit status,
a wrong/missing implementation commit, or a claim that audit/commit grants product
acceptance/runtime authority must fail. Expected semantics are section 4, not
whatever text happens to appear in the edited document.

In .docs/rw0-b2-capability.md, preserve the existing bootstrap-reset identity review
and all Capability semantics. Add one small later assurance paragraph/subsection
WITHIN the existing visible owner block, before its existing end marker, describing
this P11-only postcommit status successor. Clarify that the earlier reset record is
historical, that only the two D2 status spans change here, and that raw current
identity plus exact predecessor reconstruction and unchanged governance markers
remain checked. Other protected identities and bootstrap guard semantics remain
unchanged. It creates no runtime permission, general normalization rule, or automatic
acceptance of future text changes. Do not claim this uncommitted status patch has
already passed independent review. Do not append text after a marker whose layout
contract requires the owner block to end the file.

All other files remain commit-exact, including the D2 detailed owner, production
Python, SQL/migrations, package exports, fixtures, scripts, and configuration.
Any newly discovered additional FILE edit or substantive semantic change is a
scope conflict: stop and identify it, rather than deleting a check or broadening
this allowance. Mere discovery of the named P11/companion dependency is already
resolved here and is not a reason to return another reconnaissance-only report.

## 6. Focused validation only

Build one new positively owned EXTERNAL source copy from the authenticated
59621aa commit, overlaying only this status patch. Verify all 286 paths, modes,
and raw payload identities before tests; the path inventory remains 286 because
no tracked file is added or removed. Preserve the source's safe recorded OS
modes, including the unrelated 0600 file. Do not hardlink live source, copy ignored
caches/private state, leave remotes/alternates, execute hooks/filters, or install
anything. Helpers and outputs live outside the validation source tree. If the
tests require Git context, use a remote-free external copy with inert hooks, not
live-repository commands from a test process.

Inspect the actual current doc readers and freeze the test selection before
execution. The minimum focused set is:
  tests/test_architecture_contracts.py
  tests/test_c2b0_durable_state_contract.py
  tests/test_post_execution_pure_owner_boundaries.py
  tests/test_rw0_b1_boundaries.py
  tests/test_rw0_b2_capability_boundaries.py
  tests/test_rw0_b2_wire_boundaries.py
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
Add any other existing module demonstrably consuming the edited current-status
region or an affected preservation check. Explain each addition by path:line;
do not expand to unrelated runtime suites or semantic mutants by inertia.

Use the installed interpreter from the accepted gate when available:
  /Library/Frameworks/Python.framework/Versions/3.13/bin/python3
Record actual interpreter and pytest versions. From the verified external source
copy, under umask 022, invoke the following explicit argument lists (append any
source-justified extra module paths to BOTH invocations):

PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src TMPDIR=<owned-tmp> \
<actual-python> -B -m pytest -q -p no:cacheprovider --collect-only \
  --basetemp=<owned-collect> \
  tests/test_architecture_contracts.py \
  tests/test_c2b0_durable_state_contract.py \
  tests/test_post_execution_pure_owner_boundaries.py \
  tests/test_rw0_b1_boundaries.py \
  tests/test_rw0_b2_capability_boundaries.py \
  tests/test_rw0_b2_wire_boundaries.py \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py

PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src TMPDIR=<owned-tmp> \
<actual-python> -B -m pytest -q -p no:cacheprovider \
  --basetemp=<owned-run> --junitxml=<owned-junit> \
  tests/test_architecture_contracts.py \
  tests/test_c2b0_durable_state_contract.py \
  tests/test_post_execution_pure_owner_boundaries.py \
  tests/test_rw0_b1_boundaries.py \
  tests/test_rw0_b2_capability_boundaries.py \
  tests/test_rw0_b2_wire_boundaries.py \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py

Require complete collection and completed exit-zero execution with zero unexpected
failures/errors/skips/xfails. Record all warnings and actual exact argv/environment
selection, redacting sensitive values. Disable inherited pytest selection, plugin,
and warning-suppression overrides; no xdist, -k/-m, last-failed, or warning suppression.
Do not compare the successor's new test-module hashes to the old FULL hashes as if
they should remain identical. Bind this focused run to its own exact patch bytes.

Also perform guarded whitespace/diff checks and an independent raw before/after
comparison proving that all production code, all non-allowlisted files, and all
out-of-span document text stayed exact. Check the Capability owner separately:
its only difference is the declared assurance insertion inside the owner block.
Verify the two P11 source modules changed only in the authorized current-identity
literals and added successor regression, not existing guard/helper behavior.
Retain both raw current and reconstructed predecessor AGENTS identities distinctly. Verify after testing that the external
source manifest and the live patch have not drifted. No full 9,098-test rerun,
E/X/R/J/C10 mutation campaign, D2 process proof, or new audit of the original 70
files is requested. If owning repo policy actually mandates additional validation,
identify that source and follow it without silently dropping the policy.

Repair only failures caused by a permitted status/P11-successor edit within this
fixed scope, then validate the final bytes. A test's existing raw-file comparison
must not be changed into a projected or historical-file comparison to obtain a pass. Retain failed attempts honestly. A
production failure, new semantic issue, or dependency requiring broader edits is
a separate blocker, not permission to repair D2 in this engagement.

## 7. Reviewable provenance and retained handoff

Produce a NEW status-patch manifest, clearly separate from the original V4 raw
replacement recipe. Suggested recipe ID:
  governed-execution.rw0-d2-status-normalization-p11-successor.patch.v1
Bind it to the fixed branch, commit, tree, and null upstream. For every changed
path, include original/current type, Git/OS mode, size, raw SHA-256, and the original
Git blob identity. Sort paths by UTF-8 bytes. Include the exact complete binary
full-index, no-renames, no-ext-diff, no-textconv patch digest. Use deterministic
UTF-8 canonical JSON with sorted keys, compact separators, and one terminal LF;
exclude volatile timestamps/temporary paths from canonical identity. Retain the
exact externally authored recipe source. Run it twice from fresh reads and require
byte-identical output. This is an explicitly new recipe for a new status patch,
not a modification of the implementation's accepted provenance grammar.

Retain one safe external handoff package under a new owned Downloads directory:
- report.md: exact scope, current identity, stale-before/corrected-after assertions,
  path:line evidence, actual test results, limitations, and non-authority statement.
- diff.patch: complete exact patch, not selected display excerpts.
- before/ and after/: complete raw copies of ONLY the touched safe documents/test
  files, sufficient to independently reconstruct and inspect the complete change.
- manifest.json and its exact recipe source; both reproducibility results.
- p11_successor.json: fixed predecessor identity, actual raw successor identity,
  exact old/new byte spans and their locations, reconstruction/forward equality,
  and all three independent literal locations. Label this as evidence, not authority.
  Encode raw span bytes losslessly where needed; include no secret material.
- tests_before_after.json: non-P11 rows, historical bootstrap identities, markers,
  guard/helper bodies, existing hostile inventories, and unrelated tests preserved;
  list every newly added control and its reached assertion.
- safe structured test selection, complete node IDs, results/warnings, helper source
  where relevant, and source-preservation comparisons.
- a safe inventory of retained files, with size/SHA-256. Define whether it excludes
  itself; do not create an impossible self-hash requirement.

Classify these source documents/tests as safe before including them. Exclude live
.git contents/config, credentials, environment dumps, provider/session material,
databases, cache payloads, temporary state, unrelated source, and raw sensitive
logs. Save/reopen the package and verify its member list and content hashes. Return
one actual ZIP path with exact byte size/SHA-256, plus the concise report. Keep the
retained evidence; remove only this task's positively owned disposable validation
copy/test state after checking child/descriptor cleanup. Never clean the live
checkout or the previous commit-gate bundle.

Final readback must show: same HEAD/branch/parent/tree; unchanged index; no upstream;
no unexplained protected-ref or configuration delta; unchanged opaque cache and
unrelated file mode; only the permitted unstaged status/test patch; no generated
repository artifacts. Record any qualified tooling-diagnostic ref changes without
attributing the old historical incident.

Success disposition:
  RW0_D2_POSTCOMMIT_STATUS_AND_P11_SUCCESSOR_READY_FOR_REVIEW

Report the actual changed paths and line ranges, exact commands/results, every
failed/skipped validation, baseline and successor patch identities, the explicit
P11 assurance change and unchanged runtime/authority semantics, evidence paths,
cleanup, unresolved seams, and whether any authority/security boundary changed.
Explicitly state: independent acceptance of this NEW patch not yet performed;
staging/commit/push/PR/merge not performed; D2 implementation commit preserved.
A truthful blocked/partial result must identify actual remaining edits/state; do
not auto-rollback or claim no mutation after writing.

Continuation after artifact review: a separate gate may commit this small status
follow-up and authorize publication of the preserved implementation lineage. This
prompt itself authorizes neither. No new C2/RW0-E/provider work is selected here.

## 8. Provenance of this revised instruction

ChatGPT inspected the supplied blocker report and earlier handoff text, read the
2026-10-16 snapshot's primary/companion P11 checks and Capability owner as inert
source, and reconciled the two newer test-file identities with the fixed D2
receipts. ChatGPT did not inspect the current raw 59621aa source payloads or the
blocker ZIP, access the live checkout, or execute repository code/tests/helpers.
The live source inspection and exact byte authentication above are therefore
required, not claimed to have happened here.

Predecessor-source discovery coordinates (not current line-number guarantees):
- tests/test_rw0_b2_capability_boundaries.py:120-147,150-192,205-225,
  689-753,885-975: literal rows, independent current identities, raw helper,
  semantic evidence, and earlier historical bootstrap identities.
- tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py:127-150,
  625-628,777-854: companion literal/source and actual-document checks.
- .docs/rw0-b2-capability.md:343-355: owning identity-review record and end marker.
- .docs/ remains owning contract guidance; the selected P11 assurance change is
  explicitly documented with its tests, never smuggled in as a passing hash update.
