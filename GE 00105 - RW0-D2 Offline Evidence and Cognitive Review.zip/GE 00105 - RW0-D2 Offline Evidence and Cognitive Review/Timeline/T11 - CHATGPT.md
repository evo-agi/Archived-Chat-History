**This is a scope error in my previous handoff, not a new D2 implementation defect. Codex stopped correctly.** I authorized changing `AGENTS.md` while excluding a required test that pins its entire contents. The report says the attempt preserved the committed candidate and stopped before editing or testing. REPORT

**Keep `59621aa041a409c6ead27b74ffe25598c159e78e` intact.** The next action is the same status correction, with its actual test dependencies explicitly included—not a V5 implementation candidate or another whole-D2 audit.

## The missing dependency is broader than one literal

The reported immediate blocker is P11’s exact size/hash comparison against live `AGENTS.md`, through `tests/test_rw0_b2_capability_boundaries.py`. REPORT

I also inspected the available Coordinator snapshot. Its companion module, `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py:777–854`, independently checks both the primary module’s literal expectations and the actual document bytes. Merely adding the first test file to the edit allowance would leave another predictable conflict.

That companion relationship is **snapshot-inspected**; the newer modules’ identities are retained in the accepted D2 receipts. Their current raw contents still need Codex’s fixed-commit inspection.

## The selected correction

**Authorize an exact P11 status-only successor while retaining both current-byte protection and historical preservation.**

The revised mandate requires three distinct checks:

1. **Current identity stays literal and strict.** Both existing test modules continue checking the complete, actual current `AGENTS.md` bytes. Only P11’s explicitly identified current size/hash expectations change.
2. **The predecessor remains independently checkable.** Retain the original 64,142-byte identity. A separate bounded regression must reverse exactly the two authorized status replacements and reproduce that original size and SHA-256. Changes anywhere else must fail.
3. **The new status must be true.** Reject stale or mixed old/new status, a wrong implementation commit, and claims that audit or commitment grants product acceptance or runtime authority.

Crucially, **the existing live-file checks must not be changed to hash normalized text or a historical copy**. Historical reconstruction is an additional check, not a way around current-file verification. Existing bootstrap identities, non-P11 rows, semantic markers, and hostile controls remain unchanged.

This permits the deliberate status update without deleting the protection or blindly refreshing hashes until tests pass.

## Next Codex handoff

:chatgpt-content-reference{index="3"}[Download the complete status-normalization and P11-successor prompt](sandbox:/mnt/data/Coordinator_RW0_D2_Status_Normalization_P11_Successor_Prompt.txt)

Send it to **the same implementation/repair Codex conversation**. It replaces the blocked status-normalization mandate in full.

The closed scope contains at most seven existing files: the two status documents, the two previously permitted status-test modules, both P11 test consumers, and a small assurance note in the Capability owner. That note records the narrow successor without changing Capability or bootstrap-guard semantics.

The prompt retains the same seven-module focused collection and execution commands. It requests **no 9,098-test full-suite rerun, semantic mutation campaign, or re-audit of the original implementation**. It requires the complete before/after files, exact diff, successor evidence, and validation results in one reviewable package.

**No staging, commit, push, PR, merge, production-code edit, or new product capability is authorized.** The new status-and-assurance patch returns for independent review before its commit gate.

I saved and reopened the handoff, checked its retained baseline anchors, and confirmed that the two focused validation command blocks are unchanged. RW0_D2_Status_P11_Successor_Handoff_Check.json[Handoff integrity record](sandbox:/mnt/data/RW0_D2_Status_P11_Successor_Handoff_Check.json).

**Inspection limit:** I inspected the attached report, prior mandate, fixed receipts, and relevant snapshot source. The blocker ZIP and current committed source payloads were not supplied here. I did not access the live checkout or execute repository code, tests, or uploaded helpers.

**Sources:** Attached blocker report, particularly its dependency and preservation findings. REPORT Coordinator snapshot: `tests/test_rw0_b2_capability_boundaries.py:150–225,689–753,885–975`; `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py:777–854`; `.docs/rw0-b2-capability.md:343–355`.

**Confidence:** diagnosis and dependency mapping **0.97**; proposed bounded correction **0.93**. The successor patch’s implementation and validation remain unassessed until it exists.
