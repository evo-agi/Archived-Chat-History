# Governed Execution Coordinator — RW0-D2 V4 Independent Audit: Prospective Re-entry
# ACTIVE TASK: complete the existing whole-D2 V4 audit, not implementation or recon
# Same independent auditor; all 70 fixed receipts; ZERO live repository mutations

## 0. Immediate action, routing and limited procedural amendment

Resume the SAME independent Codex auditor conversation that just reported a
pre-opening procedural block. Do not use implementation/repair chat "00077 54".
No implementation or semantic audit was reported in the blocked attempt; it remains
history, not acceptance and not a finding against V4. Leave other repository
conversations idle. This is one complete replacement mandate, not an addendum that
requires merging earlier prompt versions.

Your NEXT protected repository tool action must have workdir `/` and contain ONLY
this plain-data guidance read. Do not prepend status, branch, log, ls, find, settings
inspection, source inspection or a compound reconnaissance command:

```sh
python3 -I -B -S - <<'PY_GUIDANCE'
from pathlib import Path
print(Path('/Users/ds/Repositories/Governed Execution Coordinator/AGENTS.md').read_text(encoding='utf-8'), end='')
PY_GUIDANCE
```

Read the complete guidance. If output is truncated, continue with bounded plain-file
reads of this exact guidance file, from `/`, without Git or imports from the repo.
Then apply section 0R using the already visible session tool transcript and run
section 1's filesystem-only opener ONCE. Do not return an opening-only handoff;
after successful authentication, proceed through the entire audit in this turn.

The following is an explicit lead-selected change to the audit PROCEDURE, not a
source repair, product-contract change, new V4 implementation, or retroactive
waiver. The old rule that EVERY pre-opening Git inspection forces a terminal return
to the user is replaced by section 0R's bounded prospective re-entry. Guidance-first
ordering remains the required behavior. Actual mutation, unknown operations, imports,
tests, failed authentication, or post-opening drift are NOT covered by this change.

Owning repository guidance and product contracts still govern. This mandate does not
authorize violating a conflicting owning contract; report an actual conflict with
path:line instead of inventing an exemption. It supersedes earlier task-routing,
restart and mutation permissions only for this independent read-only audit. The
active source subject is repaired V4, not Continuation 04, V1, V2 or V3.

## 0R. Bounded prospective re-entry; no reconstruction of missing history

### The incident and the permitted recovery

The preceding report says repository listing and raw Git status, branch and log
reads occurred before guidance/opening, followed by a procedural stop. It reports
no intentional edits, no candidate authentication, no source review, and no tests.
These statements are REPORTS, not proof of an unchanged index, cache or checkout.
Retain that result and its missing preservation observations explicitly.

This mandate authorizes ONE new, prospective audit opening in the same independent
auditor conversation. It is not permission to backdate a record, declare the failed
interval preserved, restore metadata, reset the index, or delete the earlier report.
A same-conversation restart does not turn the auditor into the implementation writer.

Before the opener, classify the ACTUAL commands already visible in your own session
transcript. Do not issue another command to rediscover them, scan provider/private
session state, or reconstruct absent logs. Record safe exact invocation text and the
known order/workdirs; redact sensitive arguments and mark anything not visible.
The user's summary alone is not sufficient to classify unknown command bodies.

Re-entry is eligible only when the complete visible pre-opening sequence consists
of inert instruction/guidance reads, directory/filename listings, and inspectable
Git status/branch/log READ invocations. Inspect complete arguments and any shell
composition: no branch creation/deletion/rename, ref/config/index write, staging,
checkout/reset, external diff/textconv/exec option, output-file redirection into the
repository, repository-code execution, installation, network or live-service work.
Do not infer that a command is harmless merely from its leading verb. Git-status
inspection does not establish that index bytes or metadata were unaffected.

No import, test, build, compilation, repository script, repository child, semantic
fixture, repair, product-state access, credential/provider-state access, or unknown
side-effecting command is eligible. If an invocation cannot be classified from the
visible record, or if an actual unaccounted mutation/competing writer is observed,
stop as an incomplete audit/provenance problem with its exact scope. Do not use a
later snapshot to erase it or begin a separate forensic/cleanup program.

This is not advance permission to perform preliminary raw Git/listing work. The
next-action instruction above remains mandatory. However, if another eligible
inspection-only action is nevertheless issued BEFORE the first successful opener
under this mandate, disclose it in the same incident record and apply this rule
rather than returning solely because of ordering. There is still only ONE successful
opening, not a sequence of replacement baselines or unbounded retry attempts.

### Fixed identity before any execution

After the existing section 1 opener succeeds, compare its emitted opening index
SHA-256 with the already supplied reference BEFORE any live Git read or executable
audit work:

```text
7af425d5a47b91b0a14294660f5d449f5ba6308dc8846a8b13aca371c191a587
```

This reference was reported in the prior independent audit and carried through the
V4 repair mandate; it is a supplied anchor to check, not a fresh lead observation.
A different value is `RW0_D2_AUDIT_PROVENANCE_MISMATCH`. Report expected/actual safely;
do not substitute the new value, reset the index, refresh it, or accept merely
semantically equivalent index entries. Preserve and account for any external root
created by the opener; failure never authorizes repository cleanup.

Using only the emitted guarded helper for subsequent live Git, independently verify
all section 1 baseline/index/ref/worktree conditions; all 70 fixed section 2
endpoint receipts and their baseline/absence relationships; all 216 other tracked
endpoints; the complete fixed raw replacement twice; actual types and source modes;
and the complete known cache. The exact V4 subject and all executable-source
selection requirements remain unchanged. No executable audit work precedes those
checks. The opaque live cache remains excluded from executable copies/imports.

Record current index/cache/guidance metadata at this NEW opening and enforce the
same record through closing. Current byte equality can support current subject
identity; it cannot establish the absence of intermediate changes or preservation
of earlier metadata. Do not require invented historical metadata that was never
captured, and do not label current observations as the missing earlier ones.

### Hard stops and acceptance boundary

Once the opener has succeeded, it must not be replaced or rerun to normalize drift.
All original live-read/helper, source/index/cache, protected-ref, external-copy,
process/cleanup and final-validation requirements apply without relaxation.
Unguarded live Git after that opening, source or protected-state drift, mutation,
unknown effects, helper failure, or fixed-identity mismatch remain blocking. No
self-authorized repair, second opening or change to expected receipts is permitted.

The earlier missing preservation comparison is a DISCLOSED HISTORICAL LIMITATION,
not by itself a finding against V4 or a mandatory blocker of a later correctly
bounded audit. This exception applies only after the eligible-command check and
all fixed/current authentication gates succeed. Any unresolved issue that could
affect the present source, executable inputs, authority, validation, custody or
protected preservation still blocks. Unexplained change is not downgraded to a
historical limitation merely by giving it that name.

For sections 1 and 8, preservation claims cover only the actual new opening-to-close
interval. At final delivery add the incident's actual command inventory, eligibility
decision, observed opening index comparison, and precise before-opening evidence
limit. Retain the earlier procedural-block result. A fully successful later audit
may use the existing acceptance token only if ALL original independent substantive
and final-validation obligations pass. It never accepts or reconstructs the failed
interval, and it never authorizes a commit.

## 0S. Unchanged audit scope and execution boundaries

One parent only: no subagents, additional model sessions, providers, network or
cross-chat delegation. Report actually visible model/effort/permissions or
`not visible`. Instruction-level dispatch discipline is not OS-level exclusion.
Competing source/index writes are a stop, not permission to race, inspect provider
state, scan machine-wide process arguments, signal unknown processes or add locks.

ZERO LIVE REPOSITORY MUTATIONS: no repair, format, stage, add -N, write-tree/index
refresh, ref/config/worktree write, commit/fetch/push/PR/merge, installation,
service/deployment, operator/product database, credential/TLS/Vault/provider material
or sibling-repository access. No imports, tests, repository scripts, fixtures or
children from the live checkout. Prior repair permissions have NO force here.

Permitted: inert guidance/source/docs/diff/schema/config inspection; guarded local
Git reads through the emitted helper; hashes and AST/JSON/TOML/SQL-text reading;
new positively owned external audit code and exact remote-free copies. Execute
source, disposable fixtures and the five fixed fake process roles ONLY there, using
installed tools. Never execute an uploaded predecessor program as an oracle.

The latest writer reports V4 ready for re-audit: only the native bound-effect writer
and persistence tests changed; 68 other candidate endpoints remained exact. It reports
both strict expiry comparisons, durable before/at/after cases for both effect classes,
post-expiry replay/recovery, E01/E02, six focused groups and 9,098 FULL passes. Those
are implementation evidence, NOT independent acceptance. All final endpoint and
module/node inventory receipts are now supplied below; no aggregate-bound missing-
receipt exception or report-completion-only detour is needed.

The preceding independent V3 audit authenticated that earlier candidate and passed
49 integration tests, then reproduced a real equal-expiry durable commit. It did NOT
complete A01-A13, C10, X01/X02/R01/J01/J02, six final groups or FULL in that interval.
Earlier independent role/reason controls retain only their exact earlier scope.

After correct opening and authentication, continue automatically through the whole
selected audit. First inspect/reproduce section 3E's corrected boundary, then the
retained joins and outstanding finite register. This is not another mapping program,
new product-contract tranche or audit limited to the latest two files. A material
finding permits an early block with exact remaining omissions. No implementation,
new schema, authority expansion or publication is authorized.

## 1. Fixed subject and preserved opening

Repository: `/Users/ds/Repositories/Governed Execution Coordinator`

```text
branch: trunk_dev
HEAD: 43ae26b9bccf9ad6ce61ec4722e14ac7b460ab18
tree: cc3cc104300f553ada581cee24e80dab6dd885b1
sole parent: 0d0926e3a483a3ab1a4fd597ac0495927352bf35
subject: feat: add RW0-D1 offline process and capsule spine
upstream: origin/trunk_dev at the same locally observed commit; divergence 0/0
worktrees: one
index: exactly 263 stage-zero HEAD entries; no staged/unmerged change
working candidate: exactly 47 modified tracked + 23 working creations = 70 paths
other tracked working endpoints: 216 HEAD-exact
current source endpoints: 286 = 263 baseline + 23 additions
SQL resources/catalog: existing 0001-0004 only; no 0005 or other new migration
current AGENTS SHA-256: ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166
reported unchanged index SHA-256: 7af425d5a47b91b0a14294660f5d449f5ba6308dc8846a8b13aca371c191a587
known opaque cache: src/ge_nwp_coordinator/__pycache__, directory + 37 regular members
```

No network check is authorized. Local tracking equality is not current remote
truth. Do not require a clean working tree, the old ten-file prototype, or an older
D1 candidate. All 23 additions are PRESENT in the working tree and ABSENT from HEAD
and the index. The index remains the baseline tree, not the candidate tree.

Baseline corroboration: the uploaded 3,134,667-byte snapshot, SHA-256
`06d981b6100fc1d6ad9792aff35800eb0772b8d35f708ed030177967ccb9c40e`, reconstructs the
263-leaf tree above. The commit/branch association is report-backed until checked
locally. An old date in the archive filename is not authority. No snapshot is
needed by the auditor when these exact local objects and working files are present.

Establish THIS attempt's index, cache and source-mode observations. Preserve the
known unrelated mode-0600 file
`tests/test_c2b3_private_atomic_program_initialization.py`; its Git mode remains
100644. Do not normalize it. Earlier missing metadata and raw-status deviations
remain historical qualifications; a fresh correct interval does not prove those
older intervals, and those qualifications do not authorize resetting current files.

The data-only opener below is the existing mechanism adapted to read-only audit.
It authenticates the current guidance and records index/cache bytes and metadata.
It writes only a new external private helper/record root and invokes no Git or
repository code. Do not run it twice to replace an inconvenient opening.

```sh
python3 -I -B -S - <<'PY_OPEN'
import hashlib
import json
import os
import stat
from pathlib import Path

REPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')
AGENTS_SHA = 'ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166'
GUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',
          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}
OVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',
             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',
             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')

def meta(st):
    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,
            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),
            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,
            'mtime_ns': st.st_mtime_ns}

def regular_record(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise RuntimeError('opening_requires_regular_nonsymlink_file')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_before_read')
        h = hashlib.sha256()
        while True:
            chunk = os.read(fd, 1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_during_read')
    finally:
        os.close(fd)
    if meta(path.lstat()) != meta(before):
        raise RuntimeError('opening_file_changed_after_read')
    return {**meta(before), 'sha256': h.hexdigest()}

def index_path():
    dotgit = REPO / '.git'
    st = dotgit.lstat()
    if stat.S_ISDIR(st.st_mode):
        gitdir = dotgit
    elif stat.S_ISREG(st.st_mode):
        regular_record(dotgit)
        raw = dotgit.read_text(encoding='utf-8').strip()
        if not raw.startswith('gitdir: ') or '\n' in raw:
            raise RuntimeError('unsupported_gitdir_pointer')
        pointed = Path(raw[len('gitdir: '):])
        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()
        if not stat.S_ISDIR(gitdir.lstat().st_mode):
            raise RuntimeError('gitdir_not_directory')
    else:
        raise RuntimeError('unsupported_dotgit_type')
    return gitdir / 'index'

def cache_record():
    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'
    st = cache.lstat()
    if not stat.S_ISDIR(st.st_mode):
        raise RuntimeError('cache_directory_missing_or_unsafe')
    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))
    if len(members) != 37:
        raise RuntimeError('unexpected_cache_membership')
    out = {'.': meta(st)}
    for path in members:
        out[path.name] = regular_record(path)
    if meta(cache.lstat()) != meta(st):
        raise RuntimeError('cache_directory_changed_during_read')
    return out

def guarded_environment():
    present = [name for name in OVERRIDES if name in os.environ]
    if present:
        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))
    env = dict(os.environ)
    env.update(GUARDS)
    env['GIT_PAGER'] = 'cat'
    env['PAGER'] = 'cat'
    return env


import datetime
import shutil
import tempfile

guarded_environment()
agents = regular_record(REPO / 'AGENTS.md')
if agents['sha256'] != AGENTS_SHA:
    raise RuntimeError('guidance_not_exact_audited_candidate')
index = index_path()
index_before = regular_record(index)
cache_before = cache_record()
git = shutil.which('git')
if git is None:
    raise RuntimeError('installed_git_unavailable')
gate_root = Path(tempfile.mkdtemp(prefix='rw0-d2-repaired-v4-audit-'))
os.chmod(gate_root, 0o700)
print('GATE_OWNED_ROOT=' + str(gate_root), flush=True)
record = {
    'schema': 'rw0-d2-repaired-v4-audit-opening-observation',
    'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'repo': str(REPO), 'guidance': agents, 'index_path': str(index),
    'index': index_before, 'cache': cache_before, 'git_executable': git,
    'git_environment': GUARDS,
    'limit': 'This re-audit interval only. Source, index, guidance, cache and protected refs remain unchanged. Section 1R governs separately observed and conditionally classified turn-diffs refs; no auditor ref write, source repair, staging, commit or remote action is authorized.'
}
READ_HELPER = "import hashlib\nimport json\nimport os\nimport stat\nfrom pathlib import Path\n\nREPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')\nAGENTS_SHA = 'ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166'\nGUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',\n          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}\nOVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',\n             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',\n             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')\n\ndef meta(st):\n    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,\n            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),\n            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,\n            'mtime_ns': st.st_mtime_ns}\n\ndef regular_record(path):\n    before = path.lstat()\n    if not stat.S_ISREG(before.st_mode):\n        raise RuntimeError('opening_requires_regular_nonsymlink_file')\n    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)\n    try:\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_before_read')\n        h = hashlib.sha256()\n        while True:\n            chunk = os.read(fd, 1024 * 1024)\n            if not chunk:\n                break\n            h.update(chunk)\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_during_read')\n    finally:\n        os.close(fd)\n    if meta(path.lstat()) != meta(before):\n        raise RuntimeError('opening_file_changed_after_read')\n    return {**meta(before), 'sha256': h.hexdigest()}\n\ndef index_path():\n    dotgit = REPO / '.git'\n    st = dotgit.lstat()\n    if stat.S_ISDIR(st.st_mode):\n        gitdir = dotgit\n    elif stat.S_ISREG(st.st_mode):\n        regular_record(dotgit)\n        raw = dotgit.read_text(encoding='utf-8').strip()\n        if not raw.startswith('gitdir: ') or '\\n' in raw:\n            raise RuntimeError('unsupported_gitdir_pointer')\n        pointed = Path(raw[len('gitdir: '):])\n        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()\n        if not stat.S_ISDIR(gitdir.lstat().st_mode):\n            raise RuntimeError('gitdir_not_directory')\n    else:\n        raise RuntimeError('unsupported_dotgit_type')\n    return gitdir / 'index'\n\ndef cache_record():\n    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'\n    st = cache.lstat()\n    if not stat.S_ISDIR(st.st_mode):\n        raise RuntimeError('cache_directory_missing_or_unsafe')\n    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))\n    if len(members) != 37:\n        raise RuntimeError('unexpected_cache_membership')\n    out = {'.': meta(st)}\n    for path in members:\n        out[path.name] = regular_record(path)\n    if meta(cache.lstat()) != meta(st):\n        raise RuntimeError('cache_directory_changed_during_read')\n    return out\n\ndef guarded_environment():\n    present = [name for name in OVERRIDES if name in os.environ]\n    if present:\n        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))\n    env = dict(os.environ)\n    env.update(GUARDS)\n    env['GIT_PAGER'] = 'cat'\n    env['PAGER'] = 'cat'\n    return env\n\n\nimport subprocess\nimport sys\nopening = json.loads(Path(__file__).with_name('opening.json').read_text(encoding='utf-8'))\n\ndef immutable_checks():\n    if str(index_path()) != opening['index_path']:\n        raise RuntimeError('index_location_drift')\n    if regular_record(index_path()) != opening['index']:\n        raise RuntimeError('audit_index_content_or_metadata_drift')\n    if regular_record(REPO / 'AGENTS.md') != opening['guidance']:\n        raise RuntimeError('audit_guidance_content_or_metadata_drift')\n    if cache_record() != opening['cache']:\n        raise RuntimeError('live_cache_drift')\n\nimmutable_checks()\nindex_before_read = regular_record(index_path())\nargs = sys.argv[1:]\nif args == ['--check']:\n    print('READ_HELPER_IMMUTABLE_SURFACES_MATCH')\n    print('CURRENT_INDEX_SHA256=' + index_before_read['sha256'])\n    print('Index content and metadata equal this audit opening; no stage or index write is permitted.')\n    raise SystemExit(0)\nallowed = {'status', 'rev-parse', 'rev-list', 'ls-files', 'ls-tree',\n           'cat-file', 'diff', 'show', 'log', 'symbolic-ref', 'worktree',\n           'check-attr', 'for-each-ref', 'reflog'}\nif not args or args[0] not in allowed:\n    raise RuntimeError('unapproved_live_read_command')\nif args[0] == 'symbolic-ref' and args[1:] not in (['HEAD'], ['-q', 'HEAD'], ['--quiet', 'HEAD']):\n    raise RuntimeError('readonly_head_query_only')\nif args[0] == 'worktree' and args[1:] not in (['list'], ['list', '--porcelain']):\n    raise RuntimeError('readonly_worktree_list_only')\nif args[0] == 'reflog' and (len(args) < 2 or args[1] != 'show'):\n    raise RuntimeError('readonly_reflog_show_only')\nfor arg in args[1:]:\n    if arg in ('--ext-diff', '--textconv', '--filters', '--output', '--exec') or arg.startswith(('--output=', '--exec=')):\n        raise RuntimeError('unapproved_output_or_execution_option')\nif args[0] in ('diff', 'show', 'log'):\n    args = [args[0], '--no-ext-diff', '--no-textconv', *args[1:]]\ncommand = [opening['git_executable'], '--no-pager', '-c', 'core.fsmonitor=false',\n           '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', '-C', str(REPO), *args]\ntry:\n    result = subprocess.run(command, env=guarded_environment(), check=False)\nfinally:\n    immutable_checks()\n    if regular_record(index_path()) != index_before_read:\n        raise RuntimeError('index_changed_during_read_command')\nraise SystemExit(result.returncode)\n"

def write_private(path, payload):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as f:
        f.write(payload)

try:
    write_private(gate_root / 'opening.json',
                  (json.dumps(record, sort_keys=True, separators=(',', ':')) + '\n').encode())
    write_private(gate_root / 'live_read.py', READ_HELPER.encode())
    if regular_record(index) != index_before or cache_record() != cache_before:
        raise RuntimeError('opening_changed_before_first_git')
    print('OPENING_RECORD=' + str(gate_root / 'opening.json'))
    print('LIVE_READ_HELPER=' + str(gate_root / 'live_read.py'))
    print('OPENING_INDEX_SHA256=' + index_before['sha256'])
    print('RW0_D2_AUDIT_PRE_GIT_OPENING_RECORDED')
except BaseException:
    for name in ('opening.json', 'live_read.py'):
        p = gate_root / name
        if p.exists():
            if not stat.S_ISREG(p.lstat().st_mode):
                raise RuntimeError('unexpected_owned_helper_type')
            p.unlink()
    gate_root.rmdir()
    raise
PY_OPEN
```

Use only the ACTUAL emitted paths; do not assume shell variables survive tools.
Every LIVE Git inspection is invoked through that helper, for example:

```sh
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> --check
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> rev-parse HEAD
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> status --short --untracked-files=all
```

The helper sets optional-lock, lazy-fetch and prompt suppression inside each Git
subprocess, disables fsmonitor/autogc/maintenance, and compares index/cache before
and after it. A helper error is not permission to use raw Git or fetch missing
objects. Missing required objects or unexplained drift block authentication.

Before cloning or tests: read all HEAD blobs/entries, record all current source
endpoint types and OS/Git modes, authenticate section 2 twice, and preserve an
external exact current manifest. Read changed tracked diffs with no ext-diff or
textconv. No `git add -N`, checkout/reset, write-tree or index refresh. Unknown
untracked files, active Git operations/unexpected locks, symlinks/special files
where regular source is required, or unexplained protected-ref/index/cache changes
block under section 1R. Record all ref observations; never clean up or restore refs
to make the comparison pass. A qualified diagnostic delta is not blanket preservation.

A metadata mismatch is not an invitation to restore times. Hashing only the index
is not its complete metadata observation. Explicitly record where any required
opening evidence is unavailable, and never present a post-action record as pre-action.

## 1R. Protected refs and conditional diagnostic observation

The V4 writer reports 53 refs, unchanged across its opening, pre-execution and
closing serializations, SHA-256
16e44ef6fcd901ec330dde4db7f54921535c9c349e9377f5c5fa3ad0702e0b33.
The immediately preceding independent V3 audit reported 52 refs (28 protected and
24 conditionally diagnostic), zero interval delta, snapshot SHA-256
e4b7d69b413ddf78d66a9ddd934b9312e1c8cc1f3c07b2af065c97203120b226.
These are separate interval observations, NOT fixed ref counts or serialization
anchors for this new audit. Record the actual current inventory. A between-interval
count difference alone establishes neither within-interval drift nor its cause.

The earlier V1 repair's all-ref preservation assertion DID fail: two removed refs
at object 014f6845ec3672c7a2c2e54f8745e8d2e0505a06 and two additions at
1450a5e4845d20d9199004ea862ebdeadb8139e0. Its writer/cause remains unestablished.
Do not attribute that failure to the zero-delta later intervals, restore a historical
ref, infer harmlessness from a namespace name, or start a forensic/ref-repair program.

After the opener and BEFORE external execution, use the emitted live-read helper
for complete actual names/OIDs/symbolic targets, including these read arguments:

```text
for-each-ref --format=%(refname)%09%(objectname)%09%(symref)
symbolic-ref -q HEAD
```

Record exact serialization and its hash outside the checkout. Protect EVERY ref
by default, HEAD's symbolic target and resolved object separately, all branch/tag/
tracking refs and all source-selection dependencies. Only actual records beneath:

```text
refs/codex/turn-diffs/captures/
refs/codex/turn-diffs/checkpoints/
```

may receive a conditional non-authoritative diagnostic classification. Inspect
actual use in source/guidance/config and available task records, including generic
ref enumeration or `--all` source selection where relevant. No program, baseline,
policy/admission, publication, recovery or validation source/expectation may depend
on a diagnostic ref. No protected symbolic ref may resolve through one. A literal
search absence alone is not proof when indirect selection exists. This audit's
executable source is the supplied fixed HEAD plus the aggregate-authenticated
working payloads, never a captured ref/tree. Prior classification may support the
bounded current check where supplying code and dependencies remain exact.

All unknown/out-of-scope refs, and any record inside those subtrees actually used
as a protected dependency, remain protected. No blanket refs/codex/** exemption.
New records or symbolic dependencies require the same qualification. No provider
state inspection, recursive captured-blob dump, fetch of unavailable objects,
checkout of captured trees, ref recreation or object restoration. Minimal available
object type/commit-header/tree metadata may be used when material; missing history
stays unavailable. `origin/HEAD -> origin/main` need not equal this branch's upstream
and must not be "corrected".

Record full ref snapshots after opening, before executable work/final validation,
and at closing. Compare protected records to the SAME opening, never replace it
on drift. Disclose qualified diagnostic old/new deltas separately. They are real
Git changes, not automatically candidate defects or permission for auditor writes.
Unknown protected dependency, source/index/protected-ref drift or observed competing
source writer blocks before further execution. A diagnostic exception never excuses
changed source, index, cache, guidance, configuration or authority.

On successful classification continue the audit in the same engagement. No new
approval or classification-only transport task. The first V1 all-ref failure and
all later correctly recorded intervals retain their own provenance.

## 2. Exact V4 subject: all seventy fixed endpoint receipts

Exactly 47 modified tracked paths and 23 working creations against the fixed HEAD.
All 70 are regular nonsymlink OS 0644 / Git 100644 files. The other 216 tracked
working files equal HEAD, preserving their actual opening OS modes. The index
contains the 263 stage-zero baseline entries, not the working candidate tree.

```text
Rows: 70 (47 M, 23 C)
Raw payload bytes: 5,856,685
Encoded row bytes: 5,862,083
Complete framed bytes: 5,862,108
Fixed complete RAW replacement SHA-256:
9b14b520984e5e6a090482ee473b45a301b762176b94e3acd1ad05f786188efd
```

Authenticate every supplied receipt and its baseline/absence relationship BEFORE
repository code executes. Reconstruct the complete raw replacement twice from fresh
reads, preferably once streaming and once explicitly concatenated. Exact framing:

```text
25-byte prefix: ASCII RW0-D2-BINARY-REPLACE-V1 followed by one NUL
Rows sorted by UTF-8 repository-relative path bytes:
  u16be(path byte length) + exact path UTF-8
  ASCII M or C relative to fixed HEAD
  u32be(0o100644)
  20 raw baseline Git blob bytes for M, or 20 zero bytes for C
  u64be(payload byte length) + exact current raw payload bytes
```

Both constructions must match ALL stated sizes, the fixed digest, every endpoint
receipt and stable metadata. Hash raw payloads, not strings containing their hashes.
An unrecognized path, mode, baseline, receipt or protected-surface mismatch blocks
before code/tests. Do not select new acceptable bytes, normalize or repair files,
accept a preceding version, or use passing counts to excuse a mismatch.

This table derives from T40's complete V3 receipts with only the two T41 replacements.
The original handback and integration receipts previously omitted by the V3 writer
were resolved by the independent V3 audit; they are fixed entries here, not measured
wildcards. The unchanged checkpoint is also fixed. These are supplied audit anchors,
not a claim that ChatGPT authenticated the live candidate.

| Path | Status | Baseline Git blob (C: absent) | Current bytes | Current SHA-256 |
|---|---|---|---:|---|
| `.docs/architecture.md` | M | `7d21418a68d2d3002753227da08cf059836d0260` | 44,745 | `5075b772afddcfe8276933d189155aa689dc4c1ee162bb702c7c7f4efaf04635` |
| `.docs/authority-boundaries.md` | M | `3524d11d67a46344214b455396afeeaa3754b41d` | 36,175 | `79c57d377b6ef7f2460ee5a5827b9c5c61334e656be9eeed73264a6906e55e32` |
| `.docs/autonomous-software-development-operating-model.md` | M | `a46d51fe3ea480e39c8c7989a08e80d9db21f5b8` | 41,197 | `926468bad8cd51c57e3aec6da775c6dced52880215f24d5b03177499a119c6c2` |
| `.docs/b3b2a-read-scope-and-query-contracts.md` | M | `c3237c31fc4b59dcd632b827a4be9907cfcfb998` | 10,013 | `74b1d21b02cd9886a697e1f1cb01dca6977cabb2da194269a35d49745fe548f6` |
| `.docs/b3b2b-select-readers.md` | M | `f1ba74b0a5cd3946a3138de326949d29f789cfac` | 6,477 | `fa7a364ce070b3fcef44907bc884bc783200e1951c618fd7e392d485497c7f07` |
| `.docs/c2b-durable-development-state.md` | M | `04c068d07cd08feaf6c56dafbf3494ccde037ede` | 1,891,411 | `8db2ba24f0685ac21fae2103bb664727a8d9635d3ead5f6bae0d42b35aaf34d2` |
| `.docs/c2b2-private-readers.md` | M | `018b3d905f5db80cf15b546f881dc8c1de3a67b7` | 14,020 | `f765b2dcd74979e235cb04c15dd1fbc81eca149aec017ca500708903bbc105d2` |
| `.docs/c2b2-pure-durable-row-values.md` | M | `1cab6d886f2cd3101987476064a9ce82d2eb4dd2` | 8,540 | `0970595b4c292517d0770542ff8e12a03b98ea93057d4e715d6518415e83aaf3` |
| `.docs/durable-state-model.md` | M | `49694cd86a51f3fb0fb3799e734a52c1a395b8c7` | 42,053 | `7f9cba19f491322dd2fc0f1656ac6b76e698723a6700d1f9919d22b2196e9e80` |
| `.docs/rw0-b1-pure-phase-values.md` | M | `5b7fb0072c6d04898cd212fdc4ff5f63903cf13b` | 35,115 | `7294e7b3aabad5338c4d846e44686ffd075b3e8fe4598495a3e7267103a9ef1e` |
| `.docs/rw0-b2-wire-protocol.md` | M | `5e41d1cb3b2f430d29eb88bdbf2b46570faf3c6b` | 26,084 | `ac1091f043f5fa6042ced1e919c740a08af975b7df1e5e97b66634f85cb68e69` |
| `.docs/rw0-c1-durable-evidence.md` | M | `a7111c4dcf761b60df35c59794bf2e3acd949745` | 15,037 | `f2c6c51d0437aa78b7975bfca3e6fc629fc2898d55c0c696750221000343a02c` |
| `.docs/rw0-c2-first-live-proof-posture.md` | M | `4b69e424655ea67900f6c6042c0cbacaf2d53f8a` | 17,674 | `ba61008234eb5ec85416c459dab0a82b19f7e1a0662dcb15f1289ba445fdf5bd` |
| `.docs/rw0-d1-offline-process-and-capsule-spine.md` | M | `f3557ca523cac0d6fa26647b17a84aef66fecc15` | 5,624 | `b537fbe074717aacdfaefd2cf32cd22c46046034ae115453ddded4e2dc25201b` |
| `.docs/rw0-d2-offline-evidence-and-review.md` | C | `absent` | 8,348 | `f9306ad7333ae08aefd62456041629380c05e984bddc3925258c655a28fa7580` |
| `.docs/rw0-remote-worker-contact-phase-entry.md` | M | `230167a39b115634c8f9b5ae5a0699639f6ff454` | 59,586 | `bee20ed00c7e6f86db3394351f0cbe29626413c635cd9a982416984b288e6fbd` |
| `.docs/worker-execution-boundary.md` | M | `464aef2aa7a561e4adc6792d1d07642d3576f364` | 32,409 | `3cfc1208d96e1f59a81dcd70dce5d43d89f2cb70cc5af6eca453650c33742769` |
| `AGENTS.md` | M | `254854d4a57487d97ce02a73ce2ed26c86ece170` | 64,142 | `ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166` |
| `README.md` | M | `088c832ca7e28d18c82ff6317738ac8ca1c7b5d1` | 47,694 | `f48f2439d282350e36b5d8374864cb5dfe19eb417672737e820500c3a68224f3` |
| `src/ge_nwp_coordinator/_cognitive_proposal_semantic_values.py` | M | `c164616b9e86379c3c6a9210cf4941429a596d4c` | 71,190 | `40243b96765ee0bf49e56a36123e0553f3bb9ab3e0fada38dbe619a2acc1eacd` |
| `src/ge_nwp_coordinator/_development_bound_effect_establishment_contracts.py` | C | `absent` | 43,039 | `fd8fb53c8129001b74df8fa5b15ae69bb45fd970e2aa93f3bc5c20eeeeb1b370` |
| `src/ge_nwp_coordinator/_rw0_d1_fake_worker.py` | M | `cb37f733141f1e3c3ce874fcc052149de1f82881` | 3,668 | `21e0c9d6c2ece57b87dfb05e961ba1a99a48e72346bbab2c4c1ed571eb5f1f00` |
| `src/ge_nwp_coordinator/_rw0_d1_handback.py` | M | `ecfcf767a5f1c32c0cf007a2c8aa3137ef92374d` | 16,920 | `3cae7fa4423187d53382ba23d9e459a5f0efcb6900a4deed6d4498ed2534ed56` |
| `src/ge_nwp_coordinator/_rw0_d1_offline.py` | M | `4f2a82e46fda9be8123888f5ca46968a4345c25f` | 23,371 | `9546f06f211253d72ea91e0dc2eaf4f0b47fdd54e3d431207f59960fbc742c95` |
| `src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py` | M | `7dc90a0442e348aaac985d711c4d1a97adb7cc05` | 12,175 | `a236bbf599e7d32b4edcc31d23182fd9613c5d290f31a0f1e57961b6a104fe56` |
| `src/ge_nwp_coordinator/_rw0_d2_handback.py` | C | `absent` | 28,905 | `85ea3872fe52dbf12608b1dcd47499b76ff11fc556b0c689498fdce56346f7ed` |
| `src/ge_nwp_coordinator/_rw0_d2_offline.py` | C | `absent` | 6,967 | `d838dd02495cab5cbafa2e6e0b99d6a4e6b4b30e4ac5cb288cb9dd2db02d0d44` |
| `src/ge_nwp_coordinator/_rw0_d2a_evidence.py` | C | `absent` | 53,134 | `e93c2592c8f838bd178ffa8e57f57a9116fcdf567b248e511496d00384968ec9` |
| `src/ge_nwp_coordinator/_rw0_d2a_fake_reviewer.py` | C | `absent` | 2,878 | `0d061fdf600039ff69ba0d0dc3f1a0239c2527500461244bb53455bbdd326973` |
| `src/ge_nwp_coordinator/_rw0_d2a_fake_validator.py` | C | `absent` | 2,726 | `c1eb49503b4345d25047814e089545f9d1cd4c85f10ae20254b8b6283fa58fbe` |
| `src/ge_nwp_coordinator/_rw0_d2a_handback.py` | C | `absent` | 20,455 | `7d1fc29c303666907c3f6e863f551d448684009db0d0b1db9881d64889e0e14f` |
| `src/ge_nwp_coordinator/_rw0_d2a_offline.py` | C | `absent` | 30,416 | `d81db9535b17c7daae7be449d7e30dbcaaa599749ddc2619dbfa7d40f87db838` |
| `src/ge_nwp_coordinator/_rw0_d2a_process_frames.py` | C | `absent` | 6,397 | `2c969b1ec303674500143bbbd721e4fe5f7ee161e00b4343f71a611a7f075c8d` |
| `src/ge_nwp_coordinator/_rw0_d2a_workspace.py` | C | `absent` | 5,075 | `45086c2b216639d3a35deef972acda526f004608780a8a8b5e30ed51253f0697` |
| `src/ge_nwp_coordinator/_rw0_d2b_fake_review_model.py` | C | `absent` | 3,771 | `492288c84c2491120a56c7056000f8ec3860c7fbce2bcb3c33249e5e1af5d93a` |
| `src/ge_nwp_coordinator/_rw0_d2b_model_frames.py` | C | `absent` | 8,032 | `e4b7cddc6cfd4caa7e34781e1c34c00833d6f83a98477d46ce55e878e97dfcef` |
| `src/ge_nwp_coordinator/_rw0_d2b_model_input.py` | C | `absent` | 81,718 | `e2bbe585f8ae19df5dd6547212cf239ac58411795cbae904cf3ed869910bdd9a` |
| `src/ge_nwp_coordinator/_rw0_d2b_proposal.py` | C | `absent` | 22,718 | `deec7caf82206c40545a308f3a8845fb867e64a211a81e055fb29ffbafc0666a` |
| `src/ge_nwp_coordinator/_sqlite_development_bound_effect_establishment.py` | C | `absent` | 23,760 | `c1005096ec8761257927a7b983dcb43b922cd89193338a761ba15ae5368cb5f5` |
| `src/ge_nwp_coordinator/_sqlite_rw0_c1.py` | M | `635b5dd49256e14103fced6ff8ea4db76649e22c` | 203,409 | `d17490b3ce1b136eeb3d559f01f44e97836827bc137325b306ec01530e06e9e7` |
| `src/ge_nwp_coordinator/sqlite_transition_transaction.py` | M | `f8053db4010faaba41b38b531d93a8b21e80daa8` | 180,600 | `6d662dcb83a2641b9d95dee7209ddbd0d8b991bc720da3aafa5b4b9fb3bc5521` |
| `src/ge_nwp_coordinator/sqlite_writer_session.py` | M | `97162e3a749a7f1f1ae75de90c4b2d9092068107` | 299,804 | `54f9c5a0844421686c1c89cdecf3c2865263b3339d2faec933c615ca2ca3d404` |
| `tests/test_b2a_writer_session_contract.py` | M | `ccadd884de29d606c9243ea7796cc380e29fe5c2` | 29,168 | `835b386274f410f2fc52b1a40b2c936009ac5286fb22bc23cc28efa789be0664` |
| `tests/test_b3b2a_read_scope_and_query_contracts.py` | M | `66cab4655d33c1b864f5fb4c22e853a39c5a8188` | 26,502 | `4cabeed0c37a99c0f937c0b49f25c7c6a049eb9125e64127019c449dcd86313a` |
| `tests/test_b3b2b_select_readers.py` | M | `c0c5a0e091572f30a428fd5a2634c21d25a6ad64` | 118,350 | `22061f6846b0ebc969f9b67bac399b8d8eb237c8df0e2de92d84d477c0f1ce2b` |
| `tests/test_b3c4c_prerequisite_contract.py` | M | `f1ee03232e33da8bbfa5592fe81c53414acb25b1` | 36,340 | `3d25c2ffb8ee86856c154cfc9dd842bab2db87ea2b200cd75758a62f372b5cd8` |
| `tests/test_c2a_nonimplementation.py` | M | `3f343ae5886c92941ebfff63ba4213de2109025e` | 30,650 | `c0db68e10f4588c02bbc38da1b95d6898a3d7896c127038533ce0c8a6715442e` |
| `tests/test_c2b0_durable_state_contract.py` | M | `b910d61aaf670ba40a0d649f933c06767e7360e5` | 887,367 | `995c3690500e3d3009f1fe93b276db506e1d454764dd2e5167df52bf81252c1a` |
| `tests/test_c2b2_development_reader_contracts.py` | M | `122f0d44b46e0a8d7b283d5baec1ce465e2028b6` | 71,365 | `28dbf4fff09d75d7522af35c8fddc8908b7c4c1d18ff8043d19dbf6b90f30970` |
| `tests/test_c2b2_development_row_value_boundaries.py` | M | `d7dea23786bec2ca98bb702bbe93cc31e4192221` | 17,972 | `f2a7089748f39dc8c40a932ac770edd3ffa7f8ea581b053af101dfda8100c830` |
| `tests/test_post_execution_pure_owner_boundaries.py` | M | `437a4e7cbd39682bdd08f03b3a30c0bbbd057614` | 19,302 | `7945be6d5e01c2a1b437cabc57972bbd70a725da9c14f7dd92574ff8f8633014` |
| `tests/test_post_execution_pure_owner_vectors.py` | M | `3eed1c6bc08b6876d1e74d94a4e5509c14786eb0` | 103,682 | `3d526cabcead871b5bba47952b914df76a34b5d85a7b730e55afb951c050de16` |
| `tests/test_runtime_non_authority.py` | M | `79d4ab185815234c9d087c48d2439b9a1d95d95d` | 48,343 | `fef5729d8e7f4c619ddb2731b52d3500bc8e75988a3f422648b9dea743ef01c9` |
| `tests/test_rw0_b1_boundaries.py` | M | `17d1e09c30b01287718c6b5175bac76b03daf458` | 52,838 | `af8d9f7507733876a5978d1a3f5b871a81030380eba929cbffe6959f9d639aaa` |
| `tests/test_rw0_b2_capability_boundaries.py` | M | `4668d2a2c285d2d79bf6ebfb0c9c9f60166bcb27` | 50,538 | `85ee20f37629ffc852154cea67dd5dc983b0f2f74ab2d370192c13d999b397c3` |
| `tests/test_rw0_b2_wire_boundaries.py` | M | `9e04f528326a6f337a4f47e7e9f9eda3c9a82e0a` | 38,513 | `13531d5d46258ca67cc7bf0bddd78c560ce9b7308ff296068a146299f349ba27` |
| `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | M | `0f0159c172e1448d2b96ab19411e1f85467a2931` | 120,405 | `af7f49ac8da64c12e97d03a536ee10b89a11996651b0d712dc04baef427d8cf3` |
| `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | M | `e9d95b54a4b5921be8ec39d2bf3f6216204750c7` | 247,679 | `e8de37791388c28f1b1626747af6c4094622469168ed9799eaa78f7f6f4d3613` |
| `tests/test_rw0_d1_handback_values.py` | M | `982be9b37aa05db0c6d6a3321b775c7c64f2142d` | 30,189 | `e8addc00e8b37aa5e6f24a91a637c9f5053656c58a0d4c06e713618229e448b6` |
| `tests/test_rw0_d1_offline_integration.py` | M | `33c2d85012cbdf0e7e04fdeb7d333d2c8675ae3f` | 53,132 | `c5997a4e9161253974b04b203bf55754c12b465c3b0b5924247e6c1df8e05c9e` |
| `tests/test_rw0_d1_worker_process.py` | M | `e2a83abe44db720b5ce0725682ac71d30372959d` | 1,737 | `512d7d61083e8ad8c61c197aefc86f70d61a1f7e41273fab435bb493cc08631f` |
| `tests/test_rw0_d2_bound_effect_contracts.py` | C | `absent` | 5,636 | `4c8f04a5f16d0e0b236f8fff636e5d9a5d41c465dad6fc726bd488fb76b59574` |
| `tests/test_rw0_d2_bound_effect_persistence.py` | C | `absent` | 20,950 | `af0e25fe73742b82ce205c420646a18221325c15820a6c3893719eaaeec436f0` |
| `tests/test_rw0_d2_c1_checked_readback.py` | C | `absent` | 17,750 | `20237660028125bacccf52bb695cb275adebefb2ed1f0a28bb271688f7aadb01` |
| `tests/test_rw0_d2_evidence_children.py` | C | `absent` | 3,635 | `fd4cd60a30cb641d34b458f7782bcc27d020a37f47f6523c37cfcf83895d516b` |
| `tests/test_rw0_d2_model_handback.py` | C | `absent` | 4,966 | `89c53206f1b636257ecf5f71027e11ca4ef4cfdd00883e55b2c0fa02fe2a7a6e` |
| `tests/test_rw0_d2_offline_integration.py` | C | `absent` | 51,581 | `e682b402875f7115d210d9c11bf1211f004efc388f8414163e4b42556ab96e36` |
| `tests/test_rw0_d2_process_frames.py` | C | `absent` | 6,894 | `f77f49268e4ed693d049560307aa3794538842efc8afa24e1500664fc4884264` |
| `tests/test_rw0_remote_contact_phase_entry_contract.py` | M | `2a9144c3dfd2c883555703c8adecd21f447d6d34` | 177,317 | `6df3c991a219633d148106396336f2702c323b6cddb82932b41152ea3e5ac16a` |
| `tests/test_sqlite_backend_b0_contract.py` | M | `c646df6d439d0b70f45d6d72200fbedb5e730779` | 26,412 | `1eb038201c19be7e9680f5ee6c4425fb50051b8bc0df31e3feeab06620cc094e` |

The historical V3 aggregate a9d32c58a765c49301db989de1bbd2d8359a2499535dc2e65a2043527c27dc2a
is NOT an acceptable current opening. Its 5,847,228 framed bytes increased by 14,880:
the native writer decreased by 2 bytes and the persistence tests increased by 14,882.
A reported two-file transition is not an independently inspected V3-to-V4 diff if
those historical source bytes are unavailable. Review all current source and all
HEAD-relative changes; do not demand deleted writer copies merely to reconstruct
history. No historical source is needed to authenticate the fixed current subject.

After authentication, create normal external copies from exact local baseline
plus these authenticated payloads, without live ignored cache, databases or secrets.
A local-only clone may read the local baseline object store; do not contact its
origin. Remove the external clone's remote before execution and prove zero remotes.
Do not invoke a live-repository script to create it. Ordinary copying/archiving by
new audit code is also allowed when all 286 endpoints and relevant Git metadata
needed by tests match the authenticated subject. No hardlinking mutable live source.

For every new external copy, retain an exact source-endpoint manifest BEFORE and
AFTER execution: path, regular-file type, byte length, SHA-256, Git/OS mode. An
optional full-copy digest must have a disclosed unambiguous grammar. For this audit
use, if needed:
`RW0-D2-INDEPENDENT-AUDIT-SOURCE-V1\0`, then UTF-8-path-sorted rows of
u32be(path length)+path+u32be(Git mode)+u64be(payload length)+raw payload bytes.
Hash only the 286 product/test/doc/config source endpoints, not clone .git or
fixtures. This is the retained audit-copy grammar, distinct from the writer's repair framing. Do not compare its output to
the writer's differently specified `RW0-D2-SOURCE-COPY-V1` digest as byte identity.
A copied manifest or hash is evidence, never another Coordinator state authority.

## 3. Audit sequence and evidence levels

This is whole-D2 independent acceptance on repaired V4. The last independent audit
found the native lifetime defect and stopped with substantial work unperformed.
V4's writer results do not complete that independent register. Preserve earlier
properly scoped observations without converting them into current whole-D2 proof.

Order:
1. New valid opening; all 70 endpoint/baseline conditions and raw aggregate verified
   twice; conditional ref treatment. Do not stop merely to report successful entry.
2. Read the complete native writer and persistence module and reached owners. Run
   section 3E's independent fresh-lifetime, replay/recovery and E01/E02 checks.
3. Read the complete final/checkpoint validators, integration module, A/B producers
   and suppliers. Perform sections 3X/3R/3J with honest overlapping-predicate credit.
4. Complete the outstanding 47-diff/23-creation source review, C10/guard checks and
   original A01-A13 register. Reuse an actual specimen across rows only where its
   observed effects establish the claimed predicates; no duplicate mutant quota.
5. One fresh normal final external copy; all six focused collections/executions and
   one selector-free FULL collection/execution. No full suite per mutant.
6. Exact evidence ledger; closing source/index/cache/ref checks; positively owned
   cleanup and a severity-ranked verdict. No source repair in this engagement.

Label contracts, inert inspection, direct execution, actual causal omission results,
prior independent evidence, writer reports, inference and unperformed obligations
separately. A material finding can stop costly remaining work, but disclose every
remaining gap and any adjacent concrete defect already observed. Do not infer
acceptance from fixed hashes, object counts, progress dots or a READY token.

Derive expectations from owning contracts and actual producers, not the writer's
summary or the predicate being tested. Shared source-supported prefixes can prove
a pure shape relation, not an unexecuted distinct transaction or cleanup cause.
The original A04/A05/A08/A09 obligations still require their actual fault evidence.
No new history field, clock contract, documentation prelude, schema or authority
decision is selected. Read governing docs and report substantive contradictions.

### 3E. Strict fresh lifetime, historical replay and recovery (A02/A03/A04)

Read both native bound-effect modules, their session/controller callers, complete
persistence tests, B1's now_utc < expires_at rule, and the actual binding/current-
fence/attempt containment relations. The reported native comparison is near line
271; follow current source rather than trusting a line number or Boolean helper.

For a FRESH operation, both binding.expires_at > transaction_now and
attempt.expires_at > transaction_now must hold. Equality is expired. The existing
controller supplies its whole-second UTC time after writer fencing; freshness must
be enforced on the genuine transaction path after required owner checks and before
any target insertion. Both validate_candidate and review_candidate are in scope.
Do not broaden the claim into continuously verified authority through later wall-
clock COMMIT, external grant verification, production execution or host-clock trust.

Preserve exact node/digest/owner validation and legal binding expiry <= attempt
expiry. Containment equality is allowed; current-time equality at an upper bound is
not. A strict binding test can mask an attempt-only weakening. Verify BOTH production
comparisons in source without creating an invalid wider binding just to isolate the
attempt check. No grace period, clamping, backdating, sleep, clock change, renewal,
new injection API, retry or child launch may rescue an expired fresh operation.

Using real valid commands, the fenced writer/controller and disposable SQLite in an
external copy, independently exercise BOTH classes with a separate fresh fixture
for each row. Inspect existing fixture helpers before reuse. Never seed the target
family/receipt or mock the writer's success/refusal as proof.

| Valid fixture | Controlled transaction time | Required fresh result |
|---|---|---|
| Binding and attempt both expire at E | E minus one second | committed, exact target family and receipt |
| Same expiries | E | CURRENT_STATE_CONFLICT; no target durable mutation |
| Same expiries | E plus one second | CURRENT_STATE_CONFLICT; no target durable mutation |
| Binding expires at E; attempt expires later | E minus one second | committed |
| Same narrower binding; attempt still valid | E | CURRENT_STATE_CONFLICT; no target durable mutation |
| Same narrower binding; attempt still valid | E plus one second, before attempt expiry | CURRENT_STATE_CONFLICT; no target durable mutation |

Use the actual existing transaction clock seam, reported as
sqlite_transition_transaction._capture_transaction_timestamp. The writer used
2099-01-01T00:00:00Z as E: controlled fixture time, not the real date. Hold all other
prerequisites valid so an earlier stale head/fence/invalid command does not mask the
boundary. Review's legitimate predecessor must be created through its owner and
recorded separately; zero TARGET receipts does not mean an empty database.

Success must reconstruct all six target members (intent, current fence, pending
authority evaluation, initial delivery, effect head, delivery head) and the receipt,
including complete keys/columns/digests/joins/time. Refusal must demonstrate that no
partial member, head, delivery or receipt survived and that predecessor logical rows
remain unchanged. Returned conflict and absent receipt alone are insufficient. Use
logical persisted-row comparisons and target-key probes; database byte equality is
not the sole no-write oracle. Observers must call through, not suppress operations.

For EACH class, first commit the exact family strictly before expiry. Identical
commands at expiry and afterward must preserve existing exact_replay. Fresh-session
readback-only recovery must preserve committed_exact. Verify original refs/digests,
row values, receipt and stored timestamp, with no duplicate or renewal. This applies
only to valid BEFORE-expiry commits, not old invalid equality-time fixtures. No live
database inspection, migration or retrospective approval is authorized.

Distinguish sampling from authorization: the existing apply path may sample its
transaction time once before receipt lookup. That alone is NOT timestamp renewal or
fresh-operation reauthorization of an exact historical family. Inspect actual use;
replay must not replace stored time or fail solely because the lifetime has since
expired. Recovery reportedly does not call this clock seam; observe that behavior
without injecting a new recovery-time input. Keep missing/partial-family and
commit-uncertainty negatives effective. No new general fault matrix is commissioned.

From authenticated FINAL V4 source, build these two separate one-source-delta
external copies with FINAL tests unchanged:

E01: restore BOTH fresh comparisons to inclusive. Before-expiry positives still pass;
both classes' equal-expiry tests must lose their intended rejection. Independently
record the erroneous target family plus receipt. This is combined-boundary causal
evidence, not isolation of both redundant comparisons.

E02: restore ONLY binding comparison to inclusive; leave attempt strict. A valid
shorter-binding/later-attempt fixture must commit erroneously at binding expiry for
both classes, while the before-expiry positives pass. Record the actual reached
comparison and target durable effects. An attempt-only mutant may remain masked;
no E03 campaign or dishonest independent-kill claim is requested.

Every copy must retain all 286 authenticated source endpoints except its one declared
delta before/after execution, parse/import the complete writer, and collect the same
complete current persistence node set (writer reports 19). Capture exact positive
and failed rejection node IDs/signals, clocks, deltas and copy manifests. Syntax,
import, collection, source-hash or unrelated predecessor failure earns no lifetime
causal credit. A disclosed audit-copy grammar differs from the writer's framing;
do not compare differently framed hashes as if they identify identical streams.

Run the normal persistence/contract/checked-readback selection (writer reports 23
nodes), plus the selected E01/E02 controls. These tests do not establish the rest of
A04 or whole D2. Map results into A02/A03/A04 and continue through the existing gate.

### 3X. Early A-to-B evidence association gate (part of A10/A12)

#### The fixed defect and current claim

The prior independent V2 audit formed two real invocations with different candidate
capsules and accept_candidate versus repair_candidate recommendations. A recipient
kept its own D1, committed bound-effect/C1 evidence and checkpoint but accepted the
donor's COMPLETE internally consistent B graph, model process and recommendation.
Both construction and a forged exact wrapper's explicit validate() accepted it.
A genuine stopped recipient also accepted the donor's paired input context/supply.
In-memory substitutions changed neither fixture DB bytes nor child identities.
This was a consuming evidence-integrity defect, not proof of a naturally wrong
ordinary producer, new durable decision or live permission.

The retained V3 repair claims a pure final join whenever a B input pair is present, including stopped
and cleanup states, preserving sampled B time and all prior validators. It reports
crossed-ready, crossed-stopped, cleanup and same-capsule/noncapsule rejection,
canonically reconstructed positives, no validation-side child/DB effects, and
49 normal integration passes. The subsequent independent V3 audit also passed 49
nodes and traced the nine-role map, but did not execute X01/X02 in that interval.
V4 reports these handback/test bytes unchanged. Independently read current code,
not just prior reports; do not derive new production semantics from audit wording.

#### Independently trace every existing role

Read the final/checkpoint validators and complete current B input constructor,
projection/supply/normalization consumers. Read relevant pure suppliers and the D2
owner document. Map each B role/value/support/lineage field to its independent
retained A owner, identifying B-only observed metadata separately. Record this map
inline with exact source/consumer paths and line ranges. Do not create a new type,
run UUID, generic join library, schema, profile or unretained execution history.

The existing nine roles and support counts are fixed:

| Role | Support count | Existing independent association to inspect |
|---|---:|---|
| candidate_capsule | 0 | This A manifest/capture/D1 candidate and lineage, full canonical value and digest; fixed ref names may repeat across disposable databases. |
| worker_result | 0 | This A rank-14 checked classification value and exact membership, including author result/adapter lineage. |
| validation_result | 6 | Actual validation disposition, source/result set, bound effect/fence/qualification and its existing supports. |
| independent_review | 7 | Actual review disposition, reviewer source/results/separation and correct review effect/qualification/supports. |
| standing_policy | 4 | Retained policy/source/matrix and support values consumed by B, under existing profile semantics. |
| risk_lane | 4 | Actual risk profile/matrix/source bindings and work/candidate supports, not just a matching lane label. |
| authority_currentness_attestation | 0 | THIS A author-role rank-1 value with exact checked membership; validation/review authority cannot substitute. |
| global_stop | 2 | A-derived inputs and represented B-time snapshot/support relationships; preserve distinct sampling meaning. |
| effect_ceiling | 5 | Represented ceiling evidence and actual attempt/effect/authority/policy/stop supports. |

Verify original program/version/work/revisions, semantic attempt, candidate,
WorkSpec/basis relationships where represented, grant, attempt/author fences,
command/delivery and phase_basis ref AND digest. Original development decision
and pre-execution cognitive selection are distinct. Role/profile/schema/membership
identity, canonical role values and every required support relation must match;
counts, label equality, a shared capsule or values inferred solely FROM B are not
an independent expectation. Passing a pure evidence-supply function with donor-B
owners reconstructed from B only repeats the defect.

Check types/self-digests BEFORE equality/dependent lookups. Existing scalar and
nested validation must not be bypassed through subclasses/coercion or bool-as-int.
A supplies expected relations; B supplies assertions. Preserve direct C1 posture
only for actual admitted roles. The final validator must not manufacture a checked
family or call V22-V34 decision/admitted-family helpers.

Pure checking must not call B's I/O/currentness-aware constructor, open SQLite,
read current heads/stop, renew authority, sample a clock, read run/workspace paths,
launch a child, replace the recipient checkpoint, rewrite a recommendation or
silently regenerate/reseal the donor's graph. Compare retained historical semantics.
B context/supply times and B-only observed stop/head facts need not equal earlier
A timestamps. Do not demand an unretained observation or make historical validation
depend on wall time now. If a required relation is not representable, report the
exact missing owner/fact rather than inventing a field or accepting a weaker claim.

A separately reconstructed semantically identical graph remains valid. No Python
`is`, PID inequality, sample capsule literal, unique fixture name or added session
identity supplies the association. A foreign allocation with ALL relevant canonical
relations identical is not automatically an invalid specimen.

#### Current ready, stopped and cleanup specimens

Use actual owned D2 invocations run_alpha and run_beta (D2A/D2B denote phases, not
run names). Keep owners separate and establish both own-graph positives first.
Use legitimate candidate/policy evidence variations, not an expected-answer bit
passed to the fake model. Retain exact differently bound evidence with real C1
families; do not seed expected memberships or construct an admitted positive by hand.

1. Ready transplant: keep alpha's full A/D1/checked/capsule facts, substitute beta's
   complete internally coherent B input/model/output graph and only the model part
   of child_outcomes as needed for its existing B-internal relation. Record EVERY
   substituted field. Construction/replacement AND an independently reached forged
   exact final wrapper's validate() must reject. Do not call the new helper first
   and credit its earlier exception as final-consumer protection.
2. Genuine stopped recipient: produce an existing post-input stopped path with a
   real controlled fault. Swap only donor context/supply where that shape retains
   them, preserving its valid reason/prefix and A graph. Both consumption boundaries
   reject. Include an actually supported cleanup-unresolved pair-bearing shape;
   preserve legitimate early stops with NO B input. Do not invent a stopped reason.
3. Same capsule/different noncapsule evidence: use two actual valid evidence contexts
   with equal canonical capsule but materially differing retained role/support facts
   such as a legal policy/source variation. Demonstrate the actual differing value
   and the donor graph's internal validity, then reject its binding to alpha. A
   second PID or context timestamp alone is not the intended noncapsule mismatch.
4. Independently reconstructed equal values: canonical reconstruction preserves
   the relation despite new Python objects; legitimate recommendations and B-time
   metadata relationships remain admitted by their existing contract.
5. Bounded nine-role mismatch coverage: inspect the permanent test matrix and use
   valid typed/resealed relationships where needed in external negative specimens.
   Confirm what reaches the new join versus earlier B node/internal checks. One
   specimen may demonstrate several actual associations; do not claim nine distinct
   proofs from a count or add a 9xall-fields Cartesian-product quota.

All source/checkpoint/nested validators and V2 reason/facts rules remain operative.
The join is required whenever a pair exists; it cannot be gated on ready/proposal/
model_input_binding. Preserve input/output safe-projection distinction and the
already selected context -> model/source/artifact/bindings/set/proposal relations.
A ready or stopped graph cannot be repaired by stripping evidence or swapping in
the donor's A checkpoint. No new schema/field/currentness/producer semantics.

Observe actual DB identity and owned child handles through the substitution phase.
The preceding genuine invocations have their own writes/processes; in-memory
validation must produce no additional DB read/write/admission, child, renewal or
run disposal. Keep available instrumentation observational, not a sanitizer or
missing production gate. Fully account for alpha, beta, workspaces, handles/groups
and failed-assertion cleanup. Runtime cleanup and audit emergency rescue differ.

#### X01/X02 and overlap with prior repair controls

Construct each from authenticated FINAL V4 bytes; final tests stay unchanged.
Record full endpoint and copy manifests before/after, exact deltas, complete node
IDs and targeted rejection/positive signals. A writer's blanket claim that all
omissions worked is not an independently established causal record.

X01: omit ONLY the A-to-B consuming relation, preserving checkpoint, role, reason
and B-internal checks. Positives pass; crossed ready and stopped negatives lose
rejection at the intended permanent assertions. Independently exercise consumer
validation, not constructor rejection alone.

X02: preserve capsule association while removing the remaining noncapsule A-to-B
associations. The own-graph positive and capsule-mismatch rejection must remain;
the internally coherent same-capsule/different-evidence negative loses rejection.
Identify the actual noncapsule relation isolated. This proves capsule-only weakness,
not every possible projection separately. Do not remove validate() wholesale.

R01: remove only reason/reached-facts enforcement; use coherent same-run early/late
positives and reason-only negatives with the A-to-B join intact.
J01: remove only checkpoint role-join enforcement; exercise its direct valid
same-role negative without mistaking later B rejection for that checkpoint check.
J02: remove only final present-checkpoint revalidation; keep checkpoint correctness,
reason checking and the new A-to-B join. Use source-supported ready/stopped shapes.

The V3 writer reported that each one-change copy lost its intended assertion;
that blanket report is not independent V4 causal proof. Inspect overlap honestly:
a stronger new join may legitimately mask an older J02 authority specimen. Do NOT
weaken the new join or falsify expectations to recover a historical mutation result.
Use an existing checkpoint-only inconsistency that reaches the intended consumer
when possible within the selected scope. Otherwise retain the call and report the
combined invariant and limitation. An unexplained actual mismatch survivor is a
finding; inability to isolate redundant predicates is not proof of both separately.
Apply the same evidence discipline to X01/X02 and R01.

Each omission copy must parse/import and collect the same complete CURRENT integration
node set (writer reports 49). Syntax/collection, source-hash, stale-digest or unrelated
prefix/type failure receives no runtime association credit. No full suite per mutant.
Run the unmodified integration module and each selected focused control, then continue
the original A01-A13 gate. Successful X/R/J checks do not establish complete acceptance.

### 3R. Early V2 status/reason/reached-facts gate (part of A12)

The direct prior counterexample used genuine stopped/model_input_or_normalization_failed
AFTER decoding a real model response. It held capsule_ready D1, two bound effects,
14 checked families, a complete A checkpoint and three D2 child outcomes. Changing
ONLY reason to d1_stopped passed construction and explicit consumption. That prior
observation showed a false explanation accepted, not a naturally false producer
reason, a new write, or executable authority.

The V2 reason repair remains in the V4 subject. Section 2 supplies fixed current
handback and integration receipts; no missing-receipt procedure is required.
The pure reason/reached-facts rule must remain independently effective.

The new pure call is reported as _validate_reason_reached_facts(self) in the final
validate() path. Confirm actual code, exact-type checks, ordering and callers.
Construction, dataclasses.replace and explicit consumption must check PRESENT facts,
not trust a cached validity flag or an earlier constructor. No new schema, field,
status/reason vocabulary, producer, clock/DB access, currentness policy or authority
owner was selected. Rejection retains invalid_d2_preadmission_handback without data.

#### Reported producer relation — claims to verify, not the auditor's oracle

In this table E/A/C denotes retained bound-effect proofs / checked admissions /
D2 child outcomes, NOT physical database row counts or proof of unretained events.
D2 producer is src/ge_nwp_coordinator/_rw0_d2_offline.py; A producer is
src/ge_nwp_coordinator/_rw0_d2a_offline.py. Line numbers are writer pointers, not
fixed after-edit facts. Independently derive semantics from actual code and owners.

| Reason / status | Reported source | Reported compatible facts and evidence limit |
|---|---|---|
| d1_stopped / stopped | D2:44 | Validated non-continuing D1, no D2 E/A/C/checkpoint/B. Direct nonselection and D1 cleanup propagation reported. |
| invalid_d1_input, d1_genesis_mismatch / stopped | A:336,121 | Ready D1, (0,0,0), no checkpoint/B. Genesis mismatch induced directly; invalid input is bounded A forwarding, not independently induced through normal outer call. |
| bound_effect_conflict, bound_effect_commit_unresolved / stopped | A:180,191 | (0..1,0,0). Direct conflict before either proof and after one commit; distinct commit-uncertainty cause not induced in this repair matrix. |
| writer_cleanup_unresolved / cleanup_unresolved | A:186,237 | (0..1,0,0), OR 2 effects and ordered 0..13 admissions with corresponding clean prior children. Direct close-fault shapes (0,0,0),(1,0,0),(2,0,0),(2,10,1),(2,12,2). |
| c1_admission_failed, c1_readback_failed, c1_commit_unresolved / stopped | A:223,230,243 | 2 effects, 0..13 ordered admissions. Child count 0 at admission counts 0..9, 1 at 10..11, 2 at 12..13; prior children clean. Admission faults at 0,10,12,13; other causes share a shape but were not separately induced. |
| process_cleanup_unresolved / cleanup_unresolved | A:317 | (2,10,1) or (2,12,2), last checker cleanup incomplete; previous checker clean. Both checking start-failure prefixes reported. |
| validator_process_failed, reviewer_process_failed / stopped | A:319 | (2,10,1) or (2,12,2) respectively; last child non-successful with complete cleanup. Both real cancellation paths reported. |
| reconstruction_not_independent / stopped | A:527 | (2,13,2), clean checking outcomes and no checkpoint. Direct root fault reported. |
| evidence_incomplete, evidence_mismatch / stopped | A:74,607 | (2,14,2), clean checking outcomes but no completed checkpoint. Bundle-validation faults after real A evidence reported. |
| model_input_or_normalization_failed / stopped | D2:71,139 | Complete A (2,14,2) and checkpoint; B failure may precede input, follow paired context/supply, or follow a clean third child and a decoded response. All three reported. |
| model_process_failed / stopped; model_process_cleanup_unresolved / cleanup_unresolved | D2:119 | Complete A, paired B input, third child; cancellation/start-failure preserve distinct failure/cleanup observations. |
| model_workspace_cleanup_unresolved / cleanup_unresolved | D2:113 | Complete A, paired B input and retained model outcome. Real scratch-cleanup fault reported. |
| complete / preadmission_ready | D2:151 | Complete A/B, three clean D2 children, exact nine-role input and typed proposal. All five legitimate recommendations remain valid. |

Inspect complete return, forwarding, exception and finally paths. Do not merely
copy this table into a test or infer correctness from matching its counts. Check
actual admission order/identities, role-specific children/cleanup and full field
absence/presence. The V1 authority-source join and final checkpoint revalidation
must remain intact in ready AND legitimate complete-A stopped results.

The d1_stopped implication has TWO independent requirements: (1) D1 really has the
supported non-continuing status, not capsule_ready; (2) no later D2 evidence is
retained. Ready D1 + an empty D2 portion is still not a D1 stop. Do not erase
legitimate D1-owned history from early negative returns. Conversely, a changed D1
label cannot justify actual later D2 evidence.

A reason can permit several prefixes. Preserve actual prelaunch AND late decoded
model failures and genuine cleanup ambiguity. The pure validator can refute an
explanation contradicted by retained facts, not prove an unrecorded writer-close,
scratch failure, external event or complete execution history. No demand to add an
event ledger is selected. Report actual ambiguities, not fabricated precision.

#### Independent direct and consumer checks

Use a real current V4 invocation with a controlled fault at the actual post-decode boundary;
observe the real response and the later fault, not a prepared stopped object.
Its original late model failure must pass unchanged. Its ONLY-reason d1_stopped
replacement must fail both dataclasses.replace/construction and a genuinely reached
explicit validate() on a test-only forged exact wrapper. Do not call a different
validator from the test and count that earlier refusal as final consumption.

Retain actual normal ready results and all five recommendations, a genuine early
D1 stop with its legitimate D1 history, and ready D1 with an empty D2 prefix that
must not accept d1_stopped. Check representatives of the distinct source-supported
partial-A, checking, cleanup and B shapes above, including a genuine complete-A
stopped path. Use source-derived fixed expectations, not the mutable production
predicate. Shared shapes need no combinatorial fault cross product; cause-specific
coverage stays in the owning A04/A05/A08/A09 obligations.

Probe reason-only moves across materially incompatible retained prefixes and
ready/stopped/cleanup combinations. Unknown or wrong-runtime-type labels are useful
but do not substitute for valid-string wrong-history specimens. Stop on a real
contradiction; do not rename the cause, strip evidence or weaken expectations.

Observe external DB identity and actual owned child handles before/after in-memory
substitution where practical. The genuine run's writes are distinct from the
substitution, which must create no child, admission, clock renewal or cleanup of
another run. Hold custody separately and close only the positively owned run.

#### R01 with J01/J02 preserved

From FINAL V4 bytes, remove only the new operative reason/reached-facts call or
precisely equivalent predicate. All role joins, nested checks, checkpoint revalidation,
frame and model validators remain intact. Current positives must still pass;
reason-only construction and forged explicit-consumer negatives must fail their
permanent rejection tests with the intended lost-rejection signal. Do not delete
validate() wholesale or modify test expectations. An unrelated syntax/import,
source-hash, prefix-shape or stale-digest failure receives no credit.

Writer's reported R01 source-copy digest:
b1b31c6ed269c9176304fb16ee464f09d1afaddaadb60e9121f930ecfcc98c01
under the V2 REPAIR copy grammar. Reported signals were DID NOT RAISE ValueError in
- test_final_stopped_consumer_revalidates_complete_a_checkpoint
  at its reason-only constructor rejection; and
- test_late_reason_only_forged_wrapper_fails_explicit_consumption
  at explicit consumption.
Treat the names as pointers; collect exact current IDs and inspect the assertions.
Your audit copies have their own identities. A current synthetic omission proves
protection of that omission, not reproduction of old payloads you no longer have.

Run the current reported 49-node integration module before proceeding to expensive final
validation; verify its full collection/IDs rather than counting progress dots.
Include section 3J's small current omission controls without duplicate quota.
If another guard masks a predicate, identify the reached layer and credit only its
actual proof. The previous independent 19-node V1 result is prior evidence, not
current execution of this amended module.

### 3J. Retained authority-role and final-consumer gate (also part of A12)

The preceding independent V1 audit reproduced the authority-role positives,
source/paired/same-role negatives and J01/J02, before finding the distinct stop-
reason issue. Keep that as prior independent evidence. This V4 audit rechecks the
changed final consuming validator and tests; it does not reopen implementation.

The checkpoint source itself is unchanged from V1: 20,455 bytes, SHA-256
7d1fc29c303666907c3f6e863f551d448684009db0d0b1db9881d64889e0e14f.
The existing role relation is:

| Role | Source slot | C1 family slot | Existing membership | Independent role anchor |
|---|---:|---:|---|---|
| validation | 0 | 6 | membership.d2.validation-authority | validate_candidate command/result and effect-fence.d2.validation |
| review | 1 | 7 | membership.d2.review-authority | review_candidate command/result and effect-fence.d2.review |
| author | 2 | 13 | membership.d2.author-authority | original D1 author lineage and fence |

Read actual producer and all related validators. Expected admission ranks are
(12,12,12,12,13,14,1,1,5,6,12,6,12,1); names and numeric slots are not the whole
relation. Exact nested type/value checks precede comparisons. Independently verify
schema/ref/digest, complete canonical source, C1 registry/payload/member/receipt/
result, same phase, role command/attempt/grant/current fence and relevant relation
operands and qualification pointers. A shared issuer may be legitimate; Python
object identity is not required for semantic equality. Moving both source and
family together cannot evade a fixed role/lineage anchor.

Use real ready values and a canonically identical reconstruction as positives;
source-only transpositions, duplicate, family-only and paired swaps and a resealed
same-role alternate as negatives. Let a family-internal inconsistency be credited
to its actual earlier validator, not a later join it never reached.

Reach final consumption with a test-only forged exact checkpoint without allowing
constructor rejection to mask it. The stopped consumer must be a GENUINE complete-A
failure supported by V2's reason relation, never an impossible early d1_stopped
label. Keep a valid early no-checkpoint stop and data-only historical semantics.

J01: omit only the checkpoint role-join call; keep the new reason predicate and
final checkpoint revalidation. Normal passes; valid same-role/source/paired cases
must discriminate actual loss of role protection where they reach it.
J02: omit only final checkpoint revalidation; keep the checkpoint validator and
V2 reason check AND the new A-to-B relation. Direct checkpoint rejection and normal positives remain effective;
forged ready and genuine complete-A stopped consumers must lose rejection at the
intended final assertions when independently reachable. Apply section 3X's overlap
rule; a reason-stage or new A-to-B rejection must not be credited as J02 protection.

Historical V2 writer repair-copy hashes (NOT current V4 identities):
J01 871344c2f438f0a82210f5d9d683421754c280b6eb5d155a1514d964a463cecc;
J02 dddd15d5b21df3f7911fd9d67e861fba32423143c34fca2b617d0e1480f46105.
Those V2 copies reportedly retained all 46 then-current integration nodes; J01 failed same_role_alternate
and J02 failed the two final-consumer negatives with DID NOT RAISE ValueError.
These are source-bound writer observations, not audit results or expected hashes
for your differently framed copies. Identify actual one-file deltas and all copy
endpoints before/after. No live repair, new import, alias/reflection workaround or
SQL read is authorized to make pure handback validation look authoritative.

X01/X02/R01/J01/J02 together address the repaired A12 predicates only. They do not prove
whole-graph custody, native durable correctness, or all A01-A13 obligations. Continue
the finite original register without another user approval once they pass.

### Independent source review scope

Read all 23 new files in full, all seven D2 test modules in full, and the current
D1 handback/runner/worker/supervisor changes with their directly changed D1 tests.
Read the two native bound-effect modules, C1 added checked readback, concrete
session and transaction changes completely at their new/modified methods and
follow every caller, capability, close/uncertainty path and actual SQL operation.
Review ALL 47 tracked semantic diffs, including owning docs/status/guard projections.
A passing test does not replace reading the amended check or a diff.

Do not print or restudy unrelated megabytes of historical C2B ledgers. Verify the
1,887,232-byte protected C2B prefix against HEAD, then inspect the changed successor
and exact Sections 11-13/38-42/Section-41/preimage/transaction cross-references reached
by D2. No root PLANS.md is assumed; D1's artificial PLANS.md is candidate fixture data.
Follow any live guidance for the fixed snapshot; baseline drift blocks, not silent
adoption of another current repo. .docs is authoritative within its actual owning
scope; inspect current implementation-status edits as claims needing evidence, not
as a way to authorize behavior absent from the accepted D2 scope.

Supporting owners and direct contracts to inspect at relevant source ranges:
- `.docs/writer-session-authority.md`, `.docs/durable-state-model.md`,
  `.docs/c2b-durable-development-state.md`, `.docs/c2a-first-slice-semantic-protocol-contract.md`;
- `.docs/rw0-d1-offline-process-and-capsule-spine.md`, `.docs/rw0-d2-offline-evidence-and-review.md`,
  `.docs/rw0-c1-durable-evidence.md`, `.docs/rw0-b1-pure-phase-values.md`,
  `.docs/rw0-b2-wire-protocol.md`, `.docs/rw0-b2-capability.md`;
- `.docs/authority-boundaries.md`, `.docs/architecture.md`,
  `.docs/autonomous-software-development-operating-model.md`,
  `.docs/rw0-remote-worker-contact-phase-entry.md`,
  `.docs/rw0-c2-first-live-proof-posture.md`,
  `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`,
  `.docs/rw0-c2-private-value-versioning.md`;
- C2B row, read-scope/private-reader and B3c4c prerequisite/public-wrapper owners;
- `_development_author_effect_establishment_contracts.py`,
  `_sqlite_development_author_effect_establishment.py`, effect/decision row values,
  `_worker_execution_semantic_values.py`, `_rw0_phase_entry_semantic_values.py`,
  `_rw0_wire_protocol_values.py`, C1 semantic/mutation/row/reader contracts and readers,
  the unchanged six pure post-execution/role/projection/decision-input suppliers,
  common cognitive semantic/row values, state authority, writer state, connection,
  SQLite security, mutation controller and session;
- migrations 0001-0004, SQL/catalog/schema resources, pyproject, package exports,
  actual consumed config/scripts/fixtures, all affected inventory/consumer helpers.

Production paths above are under `src/ge_nwp_coordinator/`. Read schemas/configs/
scripts/fixture definitions as data before any permitted external use. Never
import a test seed into production or count test-seeded memberships as a current
supported writer. Do not inspect supporting repositories, hosts or live providers.

## 4. Required operating result and authority split

One private `run_rw0_d2_offline(work_spec, fixture, *, cancelled=...)` invocation:

```text
D1 program/author/Section-41 preselection/C1 phase through existing guarded owners
 -> D1 separate planner and coding worker, parent capture and verified capsule
 -> two initial validation/review bound-effect families under existing controller
 -> genuine required C1 evidence, qualification and readback
 -> separate validator and independent reviewer, each checking its own reconstruction
 -> resource-free A evidence checkpoint
 -> fresh fenced B-entry owner-head/stop observation and expiration checks
 -> exact nine-role input -> separate deterministic fake review-model process
 -> verified canonical transient proposal/evidence -> typed preadmission handback
```

The overview is not an instruction to admit every member before the children.
Trace the actual dependency order: each new bound family exists before evidence
for its fence; qualification before the corresponding checking child; each child
observation only after its actual check; model only after required evidence and
B-entry checks. Exactly 14 checked memberships in the complete selected normal
case: ranks 1x3, 5x1, 6x2, 12x6, 13x1, 14x1. The reported order is
(12,12,12,12,13,14,1,1,5,6,12,6,12,1); derive whether this fits the actual owners.
Failure paths retain only their true dependency-closed reached prefix. No golden
rows, fixture memberships, receipt seeding or orchestration SQL may supply it.

Coordinator's existing durable owners keep program/work, author lineage, selection
and C1 phase facts. The new native owner creates only the selected bound-effect
family. C1 remains relation/admission, not source-authentication, completeness,
acceptance, execution permission or an alternative Section-41 family producer.
All writes and checked reads use the existing concrete writer operation lease and
single transaction/nominal-capability owner. No new SQLite connection authority,
shadow in-memory program head, queue, scheduler or restart protocol is allowed.

D1 disposable-state custody stays in its creator-process `RW0D1OfflineRun`.
`RW0D2OfflineRun` wraps that ONE underlying owner plus handback/housekeeping; it
creates no second state location. D2 separately owns its new reconstruction roots
and children. The evidence checkpoint and final handback contain no live owner,
WorkSpec/fixture object, session, cursor, proof, connection, FD, lock, capability or
absolute state path, including transitively. Allowed relative paths and opaque
captured bytes remain data. A frozen/nonprinting object is not automatically safe.

The five child roles use the existing single supervisor call site only: planner,
coding worker, validator, reviewer, review model. No routine user artifact/message
relay between A/B or within the run. Five PIDs alone do not establish correct
ordering, source separation or the absence of a hidden sixth process.

Explicit nonclaims: no production live model or Codex adapter, hostile same-UID
sandbox, live authority/source/supplier qualification, new standing grant, remote
ES/Bridge route, public CLI/service/StateStore or WriterSession protocol expansion,
Git/publication/deployment effect, new author attempt, redelivery/retry or repair/
replan execution. Parent cancellation/timeout is bounded process control, not a
new durable cancellation-effect decision. No SQL/catalog migration changes,
Section-41 post-execution recording/receipt, rank-15 member/projection, complete
C2 decision-time basis, C2-derived branch, acceptance fact, terminal outcome or RW0-E.

The five model literals remain accept_candidate, repair_candidate, replan,
terminal_reject, block. They are recommendations. A genuinely negative checker
result may still supply evidence for a recommendation. A missing child, malformed
result, nonzero exit, timeout/cancellation or cleanup uncertainty must not be
converted to a fabricated `block` model recommendation or empty successful evidence.

## 5. Early C10 closure and coupled guard review

Read the ENTIRE current vector and primary boundary modules. The current vector
is 103,682 bytes, SHA-256 `3d526cabcead871b5bba47952b914df76a34b5d85a7b730e55afb951c050de16`.
The primary remains 19,302 bytes, SHA-256
`7945be6d5e01c2a1b437cabc57972bbd70a725da9c14f7dd92574ff8f8633014`.
Neither is mutable in this audit.

The permitted module pairs, in the vector's normalized representation, are:

```text
_rw0_d2_handback.py     -> ge_nwp_coordinator._post_execution_evidence_values
_rw0_d2a_evidence.py    -> ge_nwp_coordinator._finite_backlog_risk_source_adapter
_rw0_d2a_evidence.py    -> ge_nwp_coordinator._post_execution_evidence_values
_rw0_d2a_evidence.py    -> ge_nwp_coordinator._post_execution_policy_values
_rw0_d2a_handback.py    -> ge_nwp_coordinator._finite_backlog_risk_source_adapter
_rw0_d2a_handback.py    -> ge_nwp_coordinator._post_execution_evidence_values
_rw0_d2a_handback.py    -> ge_nwp_coordinator._post_execution_policy_values
_rw0_d2b_model_input.py -> ge_nwp_coordinator._post_execution_evidence_values
_rw0_d2b_proposal.py    -> ge_nwp_coordinator._post_execution_evidence_values
```

All source modules above are under src/ge_nwp_coordinator. The six supplying owners
remain `_post_execution_evidence_values`, `_post_execution_policy_values`,
`_finite_backlog_risk_source_adapter`, `_section41_post_execution_proposal_family_projection`,
`_section41_post_execution_role_resolution`, `_rw0_c_decision_input_values`.
The last three receive NO new D2 external consumer permission from this list.

Independently compare fixed literals, the bounded source collector and actual
source ImportFrom statements. Relative/absolute target normalization must be
explicit and lossless for the supported grammar. The vector's runtime expectation
must not be learned from observed production imports or loaded from the primary
test. A one-sided inert literal comparison is corroboration, not a borrowed oracle.
Exact set equality means empty, missing, same-count substitution, or extra/StateStore
pairs fail; no wildcard D2 naming rule, count-only check, historical-empty alternative
or filtering unexpected source paths. This is the existing bounded ImportFrom
coverage, NOT authorization to build or demand a universal dynamic-import analyzer.

Preserve all 93 malformed and 126 assurance IDs, descriptors, rejection labels,
golden records and existing pre/post pure allocations. These nodes must each
still execute their real baseline -> synthetic addition -> original baseline path:

```text
tests/test_post_execution_pure_owner_vectors.py::test_each_of_93_malformed_controls_executes_its_causal_mutation[malformed.V3G039.production-caller-widening]
tests/test_post_execution_pure_owner_vectors.py::test_each_of_126_assurances_executes_its_named_responsibility[assurance.V3G039.production-caller-widening]
```

Collect and run both exact nodes, the four new vector controls, and the entire
vector/primary modules from a normal external copy. Verify reported 328-node
combined scope rather than assuming it. Reproduce two independent current defect
copies with final tests unmodified:
- add the direct pure-owner import to state_store.py; both vector nodes must fail
  their OWN initial baseline assertion, not an unrelated hash/export test;
- neutralize only the operative vector predicate; its legitimate positive can
  pass, but hostile controls and original synthetic-edge assertions must fail.
Identify current copies; the writer's reported hashes are not your fresh identities.
No D2 child is needed for these static mutation specimens.

Review the earlier retained guard successors without editing or reauthorizing them:
- B1 distinguishes basis construction/evaluation from evidence holding, and both
  independent projections must enforce actual selected imports/symbols.
- Wire keeps its classifier owner and finite consumer/export/dynamic-loader rules;
  a handback does not run the classifier. Exact type/source checks precede comparison.
- Capability P02 preserves the author-only contract, public surfaces and fixed
  status/content predicates; AGENTS/README expected hashes are independent literals,
  not runtime computations from the same documents.
- B2a narrows ONLY the `expiry` sentinel to the fixed nine writer-authority sources:
  __init__.py, state_store.py, state_authority_lock.py, sqlite_writer_state.py,
  sqlite_writer_session.py, sqlite_connection.py, sqlite_security.py,
  sqlite_mutation_transaction_contracts.py, sqlite_transition_transaction.py.
  Other banned release/takeover/reconstruction fragments retain whole-source checks;
  `_source`, `_source_without_lock` and `_sqlite_sources` retain their other meanings.
- B3c4c has one CURRENT controller identity
  6d662dcb83a2641b9d95dee7209ddbd0d8b991bc720da3aafa5b4b9fb3bc5521,
  preserving the older 683387... hash as historical only. Dry-run/write-contract
  identities, initialization AST/call relationships, public delegation, resource
  lifecycle/cleanup and sole-controller checks remain effective. Hash identity
  proves chosen bytes, not controller correctness.
- Existing SQLite/row/reader guard amendments may name the new bound owner as the
  fifth actual private reader consumer, not widen the 12-role/24-query inventory,
  SQL primitives, public query API or nominal capability access generally.
- Source and child inventories admit 15 new runtime modules (two native owners and
  13 offline modules), of which exactly THREE new executable children are allowed;
  the six pure supplier modules gain no I/O or internal allocation/DAG change.
- Pre-execution common values keep existing field orders/digest domains and behavior;
  only the selected closed post-execution branch is added. V22-V34 remain without
  production admitted-family or decision-time consumers; no rank-15 or C2 substitute.

Reproduce the finite scope/causality checks implicated by these actual changes.
Do not claim that the last C10 repair is the whole D2 audit, and do not add another
open-ended syntactic mutation quota. Section 6 includes this consumer obligation.

## 6. Substantive acceptance: finite independent register

Use the following A01-A13 register to organize the ALREADY SELECTED implementation
obligations. These IDs are audit bookkeeping, not new product schemas, gates, or
a larger mutation quota. Each row requires source/contract inspection, an ordinary
positive, direct hostile/fault specimens at the real owning/consuming boundary,
and the relevant small omission/replacement control where the original mandate
requires permanent discrimination. A specimen can cover multiple rows when the
observed effect and targeted assertion really establish each predicate; map it.
Do not run a full suite per mutant or make a combinatorial cross product.

The writer's eight-row summary combines several of these obligations. It is a
useful index, not proof of individual negative experiments. In this independent
pass derive fixed expectations from owning contracts and actual producer sites,
not golden test output or the helper being mutated. Prior writer reports may guide
specimen selection; do not count them as independent execution. Missing historical
copy bytes are not a user-delivery requirement: construct precise bounded current
specimens and record their new identities.

### A01 — D1 producer identity, capture and adapter retention

Inspect actual WorkerObservationV1 creation -> classify_wire_process_result ->
17-field RW0D1HandbackV1 -> C1 rank-12 adapter member -> rank-14 recomputation.
The exact originally produced ref/digest/time must survive; a classification label
or exit scalar is not its underlying evidence. The new local correlation with
worker PID and exact output digest must reject a valid other-run adapter while
preserving the original classifier observation. It is not source authentication,
permanent PID uniqueness or proof that same-user forged data cannot exist.

Exercise normal two/three-observation Wire paths and reached negative prefixes.
No adapter is fabricated on failed start, predecode/cleanup failure or before its
producer site. Classification refusal and later capture/capsule/cleanup failures
retain true already-created facts. Invalid inner values, mismatched delivery,
command, fences, kind/source, digest or foreign capsule fail at consumption.
Control normal construction and forged-exact-wrapper consumption separately; an
earlier constructor failure is not evidence that a later consumer revalidates.
Known prior test names include retained_adapter_is_the_classifier_input_and_has_real_event_time
and retained_adapter_rejects_a_different_worker_run; inspect actual names and bodies.

### A02 — Causal timestamps and currentness versus historical evidence

Map section 3E's strict fresh-boundary and post-expiry historical checks into this
row and A03/A04 without another duplicate control campaign.

Inspect start sampled after launch decode and before work, optional capture after
the real change, completion after work/before output, parent adapter after actual
supervisor outcome/decode and before classification. The worker must not stamp all
events at the end or retain the 2028 literals in D1+D2. Current source timestamps
may vary; outcome determinism does not require identical timestamps. Whole-second
UTC equality is valid where the owning relation uses <=. Monotonic deadline clocks
are not wall-clock evidence clocks.

Check started <= optional captured <= completed <= parent adapter. Qualification
must be evaluated and admitted before its relevant checking child. Actual receipt
and controller times are not future external observation times. Historical replay
and readback preserve their original times. B entry reads current heads/stop and
checks expiry rather than treating A as indefinitely current. Exercise misplacement,
reversal, stale/expired source or qualification and old-fixture reuse, with a
same-second positive. No sleep/clamping/backdating/clock-advancement repair is allowed.
No retroactive live qualification of D1's earlier author from the new author rank 1.

### A03 — Native command and distinct safe-binding semantics

Read both native bound modules in full and all callers. Support exactly ONE initial
validate_candidate and ONE initial review_candidate per D1 candidate; no author,
cancel, Git/publication/deployment effect or retries. Preserve the original author-only
DevelopmentEffectAuthorizationSafeBindingV1 owner/source/vector and receipt identities.
The new exact DevelopmentBoundEffectAuthorizationSafeBindingV1 is a local assertion,
schema `governed-execution.nwp-development-bound-effect-authorization-safe-binding.v1`,
with `.identity` domain. It must have no subclass/coercion escape into an old author
or broader effect contract.

Its exact fields: schema_id; parent_standing_grant_ref/digest;
effect_authorization_ref/digest; attempt_fence_ref/digest; semantic_attempt_ref;
effect_intent_ref; effect_class; path_ceiling; effect_ceilings; expires_at;
global_stop_ref/version; safe_binding_digest. Validate exact nested CeilingsV1 and
safe paths before equality/digest comparisons. Source-authorization digest, local
safe-binding digest, fence digest and command digest are not interchangeable.

The native command schema is
`governed-execution.nwp-establish-development-bound-effect-intent-command.v1` and
`.identity` domain. It binds the 31 selected scalar coordinates (schema, mutation,
class, program/version/intent revision, work item/revision, ORIGINAL basis decision,
attempt/candidate, attempt fence, originating author command/fence, selected Section-41
disposition, phase basis, capsule, requirement, new intent/fence/authority/delivery,
adapter correlation) and retains exact bound safe binding, real manifest, class-specific
requirement, immutable ordered before/after blob pairs, derived fence and delivery.
The identity includes complete canonical typed mappings and freshly computed
path/byte-length/SHA-256 descriptors. No filesystem path, live handle, arbitrary
mapping or digest-only surrogate supplies absent raw transient values.

Independently check canonical preimage/domain/self-digest with a fixed vector,
exact data types (including bool versus int and hostile nested subclasses), and
all command-to-body and body-to-owner joins. Validation/review use their corresponding
requirement classes; grant/attempt/stop/current effect/class/path/ceiling/expiry and
capsule match their actual authoritative predecessors. Test correctly resealed
sibling/class/intent/fence/requirement substitutions, not only stale self-digests.
Positive commands use actual D1 values. Controlled forged values are for negative
consumer tests only. Revalidation after writer fencing cannot be replaced by a
constructor that was trusted once in the offline parent.

The operation-result schema is
`governed-execution.nwp-development-bound-effect-establishment-result.v1`; it is
NOT the reserved nine-field receipt projection
`governed-execution.nwp-establish-development-bound-effect-intent-result.v1`.
Verify the distinct exact fields/domains and their authoritative row bindings.

### A04 — Native transaction, exact graph, replay and uncertainty

Observe the actual existing operation lease -> controller/connection -> fence ->
receipt/preimage queries -> write/readback -> capability invalidation -> single
commit attempt -> cleanup -> caller return. The pending authority-evaluation row
remains `pending/external_verification_pending`, not permission. Only the controller
owns BEGIN/COMMIT/rollback and nominal capability. No orchestration SQL or secondary
connection owner is allowed.

Fresh path: authoritative current program/work preimages; original initialize
decision linked to semantic attempt; original author command and post-bound author
fence; selection predecessor `selected_for_dispatch_gates`; C1 phase/basis;
requirements/capsule/blobs; current global stop, lifetime and actual collisions.
Original basis_decision_ref is not the cognitive selection disposition. Count the
actual stored effect/delivery set, not caller labels, for attempt max_deliveries=3
and selected per-effect maximum 1. Existing author heads/preimages are not rewritten.

For EACH of validation/review, independently read and reconstruct the six immutable
row members (intent, new current fence, pending authority evaluation, initial delivery,
effect head, delivery head) plus final receipt. Verify full refs, columns, canonical
self-digests, graph cardinality/order, result projection, command, timestamp and all
joins using the existing owner factories and independently checked binding rules.
Do not accept row presence, a count, or a nonempty opaque graph alone. Existing
program/work/author/selection/C1 phase heads and history must remain as required.

Receipt-first exact replay occurs only after fencing and full original-family
validation. It writes nothing, never replaces persisted timestamps or renews grants,
and cannot rely on transient expected rows replacing persisted evidence. An existing
transaction-clock sample before receipt lookup is not itself renewal; apply section
3E's distinction between fresh admission and exact historical replay. Wrong ref/digest,
partial/extra family, resealed collision, stale CAS or class/fence mismatch fails closed.
Before and after actual commit-attempt faults exercise both effect classes and
representative cleanup/publication-of-result faults. Classify uncertainty honestly.
A fresh fenced writer's exact-command recovery is READ-ONLY. committed_exact can
continue only after verified close; definitely_not_committed and unresolved stop
this D2 invocation without retry, second command identity or downstream child.
A physical commit with a lost result is not a caller-visible resolved admission.
Verify no duplicate family/delivery and unchanged original times on replay/recovery.

### A05 — C1 membership, dependency order and checked readback

Use actual `_admit_rw0_evidence`/recovery and the new checked-family entry. Complete
normal ranks are 1x3,5x1,6x2,12x6,13x1,14x1. New effect families exist before rank-1
references to them; rank-6 depends on real rank-1/rank-5 memberships and precedes
each checking launch. Four historical D1 observations include the SAME retained
adapter; rank 13 joins actual author observations and rank 14 the rank-13 result
and admitted adapter. Reviewer separation uses exact checked reviewer rank-12,
author rank-13 and author rank-12 member/relation rows, not PID inequality alone.
No ranks 7-9 admitted for appearance of completeness, and no rank 15.

Independently compare every admitted normal member's applicable registry, typed
payload, child rows, membership, relation/operands, graph, result and receipt with
its source and current family reconstruction. These are 14 FAMILIES, not 14 SQL
rows. Readback must prove the exact selectors and full persisted relationships.
Respect C1's fixed fifteen-kind grammar, immutable phase program/work CAS preimages,
receipt-first replay, and correct no-relation cases. Do not hard-code an invented
physical row total or populate all kinds. Reconstruct only the actual used family
closure, not a new audit of unused database tables.

Checked readback's selector `RW0C1AdmitEvidenceResultV1` is an assertion, not a
capability. Compare every selector ref/digest/rank/schema/time/result/graph field
AFTER fencing. The returned checked value contains detached admission_result,
phase,registry,payload,children,membership,relations,receipt,evidence_value, all exact
nested types and relations. It returns no cursor/capability/connection and survives
only verified read rollback/close. Returning an old well-formed family for another
selector, copied golden memberships, constructor-only validation or raw row tuples
without actual readback is not acceptable. Capability-after-invalidation, missing
receipt, partial graph and close-failure specimens must reach the intended check.
If one redundant check masks deletion of another, credit only the demonstrated
combined invariant, not an unexecuted individual layer.

Inspect the separate B-entry fenced current-head/global-stop reader: detached
actual owner rows plus observed time, no arbitrary query interface or stop writer.
A new read method or check never claims continuous currentness. Representative
C1 response loss/unresolved faults stop dependent children/model steps, with no
new source observation fabricated to make the graph complete.

### A06 — Two evidence producers and semantic reviewer separation

Observe actual validator and reviewer calls with independently rebuilt workspaces,
distinct current bound effects/fences/deliveries and source invocations. They perform
finite real checks of actual files; a caller `passed` flag, expected recommendation,
shared author observation or validator result cannot serve as independent review.
Derive valid outcomes from the checked bytes and the selected artificial requirement.
Separate PID alone is inadequate; actual V40 relationships must hold.

Test omission of either child, authoritative-looking supplied/resealed replacement
observation, swapped effect/fence/delivery/capsule/requirement, relabeling the validator
as reviewer, reused author invocation and valid negative source outcomes. An
unavailable/malformed source is absence, not a manufactured `not_run` or `block`.
Respect the exact validator/reviewer vocabularies. Classifier/process zero exit
cannot make a malformed source result valid. Parent normalization retains the
child-authored result/time/identity and checks its actual canonical binding.

### A07 — Reconstruction, independent verification and no candidate mutation

Original immutable D1 base/capture/manifest is the handoff, not the deleted author
workspace. Parent reconstructs separately for validator/reviewer, verifies before
launch and verifies unchanged after. Exact three-file paths, modes, bounds, one
candidate change, link/special-file/no-follow rules and base/capsule relation remain.
No Git or arbitrary captured-code execution. Candidate content may choose different
finite check outcomes, not a child argument that bypasses the check.

Use real no-alias positive; outside-owned-sibling hardlink with the workspace path
set otherwise exact; separate extra-path and cross-bound capsule cases. Do not let
extra-path refusal mask the link predicate. Check actual independent reconstruction
and capsule verification before readiness, real refusal handling, and a bounded
omission/neutralization copy that the intended permanent test must reject. A test
that itself verifies a returned artifact does not prove the runner performed the
required verification before evidence/model readiness. Keep audit rescue separate
from workspace ownership and child immutability assertions.

### A08 — Actual launch ordering, frames and child-input exclusion

Observe the existing real supervisor Popen lookup for the WHOLE invocation. Record
all attempts, role derived from original argv, actual created handles/PIDs or start
failure, and original argv/env/cwd/stdin/options; not just reported child_outcomes or
the last returned PID. The observer calls through and never sanitizes inputs,
prevents a forbidden launch, or supplies the missing production gate. Closed
writer/session/lock completion must precede EACH dependent launch. Compare the
actual effective result returned through fault wrappers, not a successful inner
return later replaced by unresolved. Exactly five roles for the complete path,
zero inappropriate dependent launches after an unresolved prerequisite, and no
extra unreported child or second Popen owner.

Preserve sys.executable absolute -B -m, exact closed five-module allowlist,
shell=False, start_new_session, close_fds, empty pass_fds, no preexec, seven-key
environment, bounded stdin/stdout/stderr and fixed D2V1/D2R1/D2M1 frame grammars.
Checking requests carry small path/length/digest records, not multi-MiB file bodies.
Request <=256 KiB; evidence response <=64 KiB; model artifact <=64 KiB and model
response <=128 KiB within admitted supervisor parameters. Duplicate/unknown keys,
wrong scalar types/magic/length, trailing or multiple frames, malformed/oversize
results cannot pass by truncation or zero process exit.

Inspect both parent's actual launch inputs and bounded child descriptor evidence
in the external proof. Explicitly known actual parent DB/state-root values must
not reach a child through allowed-key substitutions, env/argv/cwd/stdin/inherited
FDs or handles. Distinguish parent database root from legitimate shared outer audit
root and separately owned child cwd. Tests cannot infer exclusion from a path-free
handback or only an unrelated direct-supervisor fixture. A foreign state sentinel
must not be scrubbed by the observer. Keep this claim at the existing fixed-child
same-UID proof level, not arbitrary-host sandbox conformance.

### A09 — Process evidence, actual reaping and ownership-safe cleanup

Validate both process observations and actual children: successful ready requires
positive exact-integer PID/group, reason ok, exact-int zero exit, reap and all cleanup
proofs. Nonzero/signal exits, legitimate failed launch, timeout or cancellation,
late zero exit and known exit with unresolved cleanup retain truthful meanings.
Negative return code is not a negative process identity. Observe direct-child reap,
TERM/KILL where needed, selector/stream closure, group-clear and bounded exceptions.
Do not accept a good-looking value while a real child remains.

Use the existing D1 process controls plus affected D2 timeout/cancel/cleanup paths,
including one relevant actual omission of reap/group/selector cleanup in a bounded
defect copy. The permanent assertion must fail for a real cleanup consequence,
not an unrelated syntax or type error before launch. Record the resulting handle
and emergency rescue separately. Positively owned unreported children and workspace
roots remain accounted for even when the candidate omits them from a handback.
Never kill by name or sweep /tmp. PID reuse/current-group uncertainty is not
permission to signal a process not proven to belong to the experiment.

### A10 — Nine-role supply, fresh B checks and model causality

The exact role order is capsule, worker result, validation result, independent
review, standing policy, risk lane, authority currentness, global stop, effect
ceiling; canonical names are those in section 4/5 and the owning profile. Support
counts (0,0,6,7,4,4,0,2,5) are necessary cardinalities, not proof of correct joins.
Worker result and author authority are actual C1-admitted values (ranks 14 and 1);
other roles retain their exact transient/source posture. Artificial authority,
readiness, policy and risk observations are explicit, independently correlated
proof inputs. A source ref/digest, PID, complete membership or expected fixture
cannot turn them into live standing policy or source authentication.

Verify V01/V03/V05/V07/V02/V10/V11 construction from actual sources before model
entry, and V09 binding only after the genuine model output exists. No V22-V34
admitted-family or decision-time function is invoked using fake owner rows or a
model-selected authoritative branch. Check real fresh stop/head read and expiration
at B, rather than replaying a cached A snapshot or silently renewing timestamps.

Real fake-model output must depend on its bound evidence. Test all five allowed
recommendations with actual allowed content/policy variations; check a causal
change in input makes the applicable output differ, and an omitted model, stale/
ignored response, role/support substitution or expected_recommendation override
is detected. No fixture action bit is delivered as the answer, no parent overwrite
supplies the answer the test wanted. The fake model is not expected to show genuine
semantic competence; its finite check/policy behavior must simply be real and bound.
Valid evidence-negative outcomes differ from process failure/missing evidence.

### A11 — Canonical post-execution content and unchanged pre-execution values

Inspect all changed common validators and new private artifact/normalizer code.
The current historical-name PreExecutionModelProposalV1 may realize the selected
closed post_execution_semantic_review branch; do not infer that all contexts or
artifacts are interchangeable. Preserve old pre-execution behavior, field order,
digest domains and 14/15 evidence grammar. Post input uses nine roles. Distinct
input and output safe projections remain distinct identities.

Post schemas:
- governed-execution.nwp-post-execution-semantic-review-context.v1
- governed-execution.nwp-post-execution-semantic-review-artifact.v1
- governed-execution.nwp-post-execution-semantic-review-safe-projection.v1
- governed-execution.nwp-model-proposal-envelope.v1 (common envelope)

Artifact ordered fields: schema_id,artifact_ref,proposal_ref,proposal_phase,
input_context_ref,capsule_manifest_ref,validation_disposition_ref,review_disposition_ref,
findings,recommendation,reason_code,artifact_digest.
Projection: schema_id,proposal_ref,proposal_phase,artifact_schema_id,artifact_ref,
artifact_digest,input_context_schema_id,input_context_ref,input_context_digest,
recommendation,reason_code,safe_projection_digest.
Finding (0..8 tuple): finding_ref,source_role,source_value_ref,source_value_digest,reason_code.
Each finding resolves to an actual role input; unique refs and canonical order,
no raw model-text/metadata escape hatch. Digests follow their actual schema.identity
canonical mapping and exclude only the self field; use independent fixed preimage
and class/ref/digest checks, not the normalizer's own expected output.

Verify real bounded child response -> artifact validation -> private bytes/digest ->
source invocation, binding, nine evidence rows/semantic bindings and set -> proposal
-> V09/input relation. Model source completion cannot be claimed before execution.
Nondecreasing context/start/completion/validation/binding/proposal times preserve
who observed or normalized each value; no future recording/receipt/decision timestamp
exists here. Verify exact prospective Section-41 column/type/ref/digest destination
from the common grammar WITHOUT inserting those rows or claiming they exist.
Later rejection for stale data is not translation of the historical recommendation.
Reject mixed phase, inconsistent cardinality, cross-bound response and invalid
canonical content; no schema aliasing or speculative membership defaults.

### A12 — Whole-graph handback safety and same-process custody

Complete sections 3X, 3R and 3J first; map their exact observations here without
duplicating a mutation quota. Wider nested-evidence and custody obligations remain.

Inspect constructor AND consuming validators for RW0D2EvidenceCheckpointV1,
RW0D2BoundEffectProofV1, checked C1 families and RW0D2PreadmissionHandbackV1. Derive
closed allowed nested types, counts and reason/evidence matrix from ACTUAL producer
sites, not only a matching test table. Ready means complete justified evidence,
model content and cleanup; stopped/cleanup_unresolved retain true reached facts.
No erased negative fact or later impossible stage can be admitted merely because
an optional outer field has the right class.

Probe normal and forged exact wrappers independently with an open D1/D2 run,
actual owned state Path, arbitrary object, mutable mapping, field subclass and
wrong family/ref/digest at relevant nested slots. Repr concealment and no pickle
are not validation. Legitimate relative paths and opaque captured bytes are not
banned by scanning them for secret-looking text. Any absolute parent state path,
capability or resource must remain outside the evidence graph.

Separate RW0D2OfflineRun delegates explicit idempotent close to original D1 owner;
wrong PID and closed owner fail before resource exposure. Check actual fork and
exception/cancel paths using safe existing proof controls. A borrowed continuation
cleans only newly owned resources, not an unrelated original run used for a
specimen. No destructor-owned authority, implicit resurrection, second database,
serialized transport or user-maintained live A checkpoint between engagements.

### A13 — Authority, guard successors and integrated contract preservation

Complete section 5, all 47 diffs, and unchanged-baseline checks. Confirm C10 exact
nine pairs, primary and vector independently fixed; retained 93/126 records; B1 and
Wire symbols/roles; finite dynamic/re-export restrictions; Capability literal
content and five status projections; B2a scoped expiry and still-global prohibitions;
B3c4c current controller hash plus retained structure; native SQLite/reader access;
no new public exports/StateStore members, migration, C2 or Section-41 output writer.
Literal source identity alone cannot authenticate the correctness of the referenced
source. Conversely, do not block selected D2 purely because a historical no-D2
status exists in a deliberately preserved historical record with a truthful successor.

Inspect all config/script/example/resource changes and actual runtime consumers.
The six pure suppliers stay pure; expected identities cannot be computed from the
same current docs under test. Reproduce owning guard negative controls relevant
to each changed permission/successor, without inventing universal syntax coverage
or reauditing unrelated repos. A test passing through another guard does not prove
its own causal enforcement. The no-post-execution-persistence/no-rank15/no-complete-C2
cut must agree across source, schemas, examples, docs and outcomes.

### Evidence ledger and what counts

For EACH A01-A13 row, report precise owning path:line, actual normal specimen,
mutated layer or fault, full selected node IDs/commands and outcomes, the actual
effects before refusal, targeted assertion/exception, source identity and preserved
copy/cleanup facts. Mark source-only reasoning versus direct execution versus
mutant failure. Document overlap where one proof genuinely covers multiple rows.

Neither a missing historical full-copy digest nor an aggregate count creates a
new requirement to obtain deleted payloads. Fresh copies get an explicit manifest
and disclosed digest grammar; earlier endpoint-only reports stay endpoint-only.
For your new copies, report exact mutations and full identities before/after.
The writer's eight-row ledger is not independent completion. A passing unmodified
suite cannot close a named omission-control requirement. A fully enumerated ledger
with honest holes is better than a claim that the entire register passed.

If a hostile change is rejected by a stronger preceding predicate, credit that
observed invariant only. To test a dependent layer use a valid predecessor reaching
it, or a precisely explained combined-boundary specimen. Do not claim both redundant
layers were independently exercised when only one was. Syntax/import/format errors
cannot be credited for runtime/evidence rejection; static source-hash controls have
their stated static scope and must not masquerade as runtime proofs.

## 7. Independent final validation and exact memberships

All final execution must use one fresh normal external copy matching the 286
current source endpoints, rebuilt after any diagnostic/mutant work. It must have
zero remotes and no copied live ignored state. Run installed Python 3.13/pytest,
umask 022, owned TMPDIR, PYTHONDONTWRITEBYTECODE=1, PYTHONPATH=.:src, -B and disabled
pytest cache. No installs, network, xdist, parallel groups, extra model or live child.
Precreate separate collect/run basetemp parents under the owned root. Record exact
interpreter/version and invocation used; the unavailable model selector is not a
reason to seek extra access.

For each group, collection precedes execution. Recommended explicit shape:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src TMPDIR=<owned-tmp> \
python3 -B -m pytest -q -p no:cacheprovider \
  --basetemp=<owned-group-collect> --collect-only <group-paths>

PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src TMPDIR=<owned-tmp> \
python3 -B -m pytest -q -p no:cacheprovider \
  --basetemp=<owned-group-run> <group-paths>
```

Run all SIX focused groups serially, then ONE full collection/execution with NO
path selector. Do not infer a full run from the focused union, or drop the unselected
3,652 reported full-suite nodes. No full suite per mutant. A fully traceable identical
unmodified final audit execution need not be rerun only to give it another name;
implementation executions do not substitute for this independent final gate.
A material earlier finding permits an explicit block with these gates unperformed.

All six groups and FULL now have fixed supplied V4 module and node receipts.
Module inventories were also recomputed by the lead from the inert baseline plus
reported endpoint hashes and agree. That is identity bookkeeping, not proof of
candidate payloads, node collection or successful execution. Authenticate the raw
subject first; then independently reproduce complete actual module and node sets.
Do not normalize parameter strings, change selectors/source, skip/xfail, suppress
warnings or substitute an observed expectation to force a reported hash. Investigate
and disclose any discrepancy; explain a real environment effect with evidence, not
a guessed pass. The full collector has 131 test modules; the two noncollecting test
support .py files are source endpoints, not additional collected modules.

Inventory grammars (no prefix, unless reporting an explicitly different artifact):
- MODULE: unique test paths sorted by UTF-8 bytes, each u32be(path byte length) +
  path UTF-8 + raw 32-byte SHA-256 of module payload.
- NODE: deduplicated complete node IDs sorted by UTF-8 bytes, each u32be(ID byte
  length) + exact ID UTF-8. Do not split ID parameter text on whitespace.

### Exact final groups

#### A0_D1

```text
tests/test_rw0_d1_handback_values.py
tests/test_rw0_d1_offline_integration.py
tests/test_rw0_d1_planner_process.py
tests/test_rw0_d1_process_frames.py
tests/test_rw0_d1_process_supervisor.py
tests/test_rw0_d1_worker_process.py
tests/test_rw0_d1_workspace_capsule.py
```

#### BINDING_COMPAT

```text
tests/test_c2b3c_author_effect_contract.py
tests/test_c2b3d_author_effect_establishment_contracts.py
tests/test_c2b3d_author_effect_establishment_recovery.py
tests/test_c2b3d_private_atomic_author_effect_establishment.py
tests/test_c2b3d_private_author_effect_delegation.py
tests/test_worker_execution_semantic_relations.py
tests/test_worker_execution_semantic_vectors.py
```

#### A_NATIVE

```text
tests/test_rw0_c1_mutation_contracts.py
tests/test_rw0_c1_private_atomic_persistence.py
tests/test_rw0_c1_private_readers.py
tests/test_rw0_c1_reader_contracts.py
tests/test_rw0_c1_recovery.py
tests/test_rw0_c1_row_values.py
tests/test_rw0_c1_semantic_values.py
tests/test_rw0_c1_writer_session_delegation.py
tests/test_rw0_d2_bound_effect_contracts.py
tests/test_rw0_d2_bound_effect_persistence.py
tests/test_rw0_d2_c1_checked_readback.py
```

#### A_EVIDENCE

```text
tests/test_post_execution_pure_owner_relations.py
tests/test_post_execution_pure_owner_values.py
tests/test_rw0_d2_c1_checked_readback.py
tests/test_rw0_d2_evidence_children.py
tests/test_rw0_d2_process_frames.py
```

#### B_MODEL

```text
tests/test_rw0_d2_model_handback.py
tests/test_rw0_d2_offline_integration.py
tests/test_section41_cognitive_proposal_row_values.py
tests/test_section41_cognitive_proposal_semantic_values.py
tests/test_section41_pre_execution_plan_disposition_contracts.py
tests/test_section41_pre_execution_plan_disposition_recovery.py
tests/test_section41_private_atomic_pre_execution_plan_disposition.py
tests/test_section41_private_pre_execution_plan_disposition_delegation.py
```

#### GUARDS

```text
tests/test_architecture_contracts.py
tests/test_autonomous_software_development_operating_model.py
tests/test_b2a_writer_session_contract.py
tests/test_b3a_persistence_contracts.py
tests/test_b3b2a_read_scope_and_query_contracts.py
tests/test_b3b2b_select_readers.py
tests/test_b3c4c_prerequisite_contract.py
tests/test_c2a_nonimplementation.py
tests/test_c2b0_durable_state_contract.py
tests/test_c2b2_development_reader_contracts.py
tests/test_c2b2_development_row_value_boundaries.py
tests/test_post_execution_pure_owner_boundaries.py
tests/test_post_execution_pure_owner_vectors.py
tests/test_runtime_non_authority.py
tests/test_rw0_b1_boundaries.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
tests/test_rw0_c2_private_value_versioning_contract.py
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_sqlite_b1_runtime_boundary.py
tests/test_sqlite_b2c_writer_session.py
tests/test_sqlite_backend_b0_contract.py
```

#### FULL

No test-path argument for either collection or execution. All 131 repository test modules are in scope.

| Group | Modules | V4 writer-reported passed | Fixed module SHA-256 | Supplied node SHA-256 |
|---|---:|---:|---|---|
| A0_D1 | 7 | 117 | bd79dcd6261a545b90e3709e7bff2b16fa00d9fb71f67baa4082f71de6b75236 | 8ba8dc88ab588e3e12d56d8c3db542b08f04ddb1d1714a4e687e62697ab849ad |
| BINDING_COMPAT | 7 | 160 | 0851123786b9bcbab0f2f417539ec3d1a0e6ffc753c4075e3d33b15e27dccd30 | fddc0c493b032ecac479c59e6480a1f58c52759b8133f829795f6a82d8856806 |
| A_NATIVE | 11 | 132 | 1d59cdd9b2eb38fda5506dd2c7fb941d5a8f9458cf192798c0e029f47385028f | ea80c0671804f63da9e349cfc9a0b8f532e0a25aa5fe1b1c8787f1db7fbcbf82 |
| A_EVIDENCE | 5 | 659 | d74195c30fd2f5c9e56591b2365651836ec7c982d0c1fe96da3f1fc26850b1ba | 8c27f90a27da2fe62242f3bf3c368b2ce5792e102354c685bc8d99e1e19c35f2 |
| B_MODEL | 8 | 218 | d00d48fcba4bf4f95bc359c59c57233dc770eafe51957ca40068a46c2c685147 | 9e5dd25ed281aab9958cb52db24833fd3264ae2f5419cfb61ddcb09d956033a5 |
| GUARDS | 24 | 4,162 | 4533bd1c1f6ee61c1e96847b3d6ce684af46046304ae9a6df28348eaace2b617 | 547c990efa2ac226f2316e0d3c276b6709afa0c4deb20493a1e3db2230b9260b |
| FULL, no path selector | 131 | 9,098 | 3c0ebcd7195ebfb0f483820c25a2f94f613ba42c67e7f714df90873f52ad1061 | 13298265ca6c9c023008e6051719065b3e9c78e1c2524413f9f7035090cfcbaf |

The persistence module grew by 14 nodes, A_NATIVE from 118 to 132 and FULL from
9,084 to 9,098. The integration module remains 49 nodes; B_MODEL remains 218.
This reconciles counts, not semantic coverage. The six focused groups report 5,448
occurrences and 5,446 distinct IDs, with only the two checked-C1 overlaps between
A_NATIVE/A_EVIDENCE. FULL contains that union plus 3,652 nodes. Independently compute
all complete IDs, intersections and inclusion; writer totals are not your results.

The writer used Python 3.13.4 and pytest 8.4.1. Record your actual interpreter,
commands, environment, exits and warnings. Its external builder import correction
preceded its first copy/test; its 133-to-131 report correction excluded two support
files and reportedly changed no candidate byte or test command. Preserve this
history without repeating those errors or treating it as independently observed.

Report integration and persistence current module/node identities, all six groups
and FULL, all failed/interrupted or corrected audit trials, complete source manifests,
actual effects, warnings and cleanup. Deleted writer logs are not a new delivery
prerequisite. Your independent executions and copies have their own evidence.

Only the three existing Python 3.13 multithreaded-fork DeprecationWarnings in
unchanged tests/test_sqlite_b2c_writer_session.py are expected:

```text
test_operation_guard_close_waits_and_retains_authority_until_exit
test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock
```

Inspect structured records, actual node/category/location/message and counts.
No warning suppression, relabeling new warnings, skip/xfail or deselection. Group
GUARDS and FULL should each report the known three if environment matches; other
observations must be stated. Record pytest exit/completion evidence, not progress
dots or a process assumed complete. Failed/interrupted or missing-receipt trials
receive no final credit. A concrete audit-driver correction may be made outside
the repository and only affected gates rerun; retain the correction history.

All tracked diff and all 23 addition no-index whitespace checks must pass; ordinary
no-index differences are not a whitespace defect. Validate strict UTF-8, no BOM/CR,
no trailing whitespace, exactly the selected terminal LF form, and actual file
modes. Check SQL inventory, catalog/resource and public/author/factory protections.
Source endpoints must match before/after every normal run. A controlled mutant's
source manifest must differ at exactly its declared entries before and after use.

## 8. Closing preservation, delivery and verdict

Preserve all seventy fixed V4 receipts, every stated framing length and the fixed
aggregate throughout this interval. Do not remeasure drift into new acceptable
expectations. Source/copy equality does not grant semantic acceptance.
Before finalizing, read all 263 baseline and 70 candidate relationships again,
reconstruct the exact raw replacement twice, and compare the original opening
source modes, index bytes AND metadata, current guidance, complete known cache
(directory and members), HEAD/tree/parent/protected-ref/upstream/worktree facts.
Apply section 1R to the COMPLETE observed ref inventory: disclose every qualified
diagnostic delta separately and never claim all refs were unchanged when they were
not. No unknown/out-of-scope ref delta is silently tolerated. There must
be exactly 47 M and 23 C; no staged, unmerged, candidate repair, generated repository
artifact or other content change. Do not claim fresh remote truth.

Record every child handle/group and every audit-owned root. Classify external
artifacts with lstat; hash only regular files, follow no symlinks, open no FIFO/
socket/device for inventory. Some tests deliberately create SQLite fixtures,
symlinks and special files; their mere existence is not a repo defect. Remove only
positively owned external material after processes finish and preservation checks
succeed. Never clean another run or generic /tmp content. Keep audit emergency
rescue separate from normal supervisor cleanup. If anything is still unproved,
report its precise scope rather than saying cleanup passed.

Use the SAME opening helper for closing comparisons, then remove its own helper/
record root and verify removal without further live Git. The record's deletion
after its results are reported is not permission to invent its values. Return
operative results INLINE, including exact subject and ledger; no audit ZIP, new
repository report, snapshot, patch or evidence-transport prerequisite is requested.
Do not claim an artifact survives after reporting its removal.

Return a severity-ranked result. Include finding type (contract/authority drift,
security risk, runtime bug, transaction/durable-state error, test-causality or
doc gap, provenance/procedure limit, or report-only uncertainty), exact owning
path:line, reproduction and observed effect, consequence, and minimum repair
boundary for lead review. Do not author a repair prompt or apply the repair.
Identify retained passing checks and every omission, not just the first failure.

Required closeout:
1. Verdict, actual visible settings and independent read-only scope.
2. Complete subject authentication, all 70 supplied receipts confirmed (name every mismatch), fixed raw replacement
   payload/encoded/framed sizes and hash reproduced twice, baseline/ref versus remote
   limitations, source/index/cache and cleanup interval; section-1R classification,
   protected-ref equality and explicit diagnostic old/new observations. The prior
   all-ref-preservation failure and unidentified writer remain qualified history.
3. Current source/call graph, distinct authority owners, five roles, selected
   preadmission capability/nonclaims, and full 47-diff/23-creation review coverage.
4. C10 fixed nine pairs, both original nodes and actual current defect controls,
   preserved records, primary/vector independence and earlier guard successors.
   Include the complete nine-role A-owner -> B-role/support/lineage map, B-only
   sampling semantics, present-pair consumers in ready/stopped/cleanup states,
   crossed-ready/stopped/same-capsule/equivalent positives and negatives, and X01/X02.
   Include the source-derived reason/prefix review, real early/late positives,
   shared-shape versus distinct-fault limits, and constructor/consumer results.
5. A01-A13 evidence ledger, including section 3E's both-class fresh/no-write,
   valid-before-expiry replay/recovery and E01/E02 results, plus independent
   X01/X02, reason/R01 and retained role/J01/J02 results,
   with direct/negative/copy identity/selected-node signals,
   actual persisted families, replay/recovery/no-duplicate proof, effect order,
   real source semantics, model binding and custody. Explicit unsupported rows.
6. All six final groups and FULL: exact commands, complete source and reproduced V4 test inventories,
   collected/passed nodes, overlaps/inclusion, structured warnings and corrections.
7. Sensitive authority, runtime, filesystem/process, SQL/schema/public preservation,
   no hidden provider/Git effects, and complete task-owned resource treatment.
8. Continuation capsule identifying the exact candidate and remaining gate,
   no runtime/publication permission inferred from evidence or model output.

Supported final tokens:

`RW0_D2_OFFLINE_EVIDENCE_COGNITIVE_REVIEW_ACCEPTED_READY_FOR_COMMIT_GATE`
  The exact V4 subject authenticated through the fixed aggregate and all 70 endpoint conditions; section 1R is satisfied and its
  diagnostic qualification is disclosed; all material selected contracts and
  independent proof obligations established; all required final execution passed;
  no unresolved material finding or protected-preservation/cleanup limit prevents acceptance. This means
  eligibility for a SEPARATE commit/publication gate only, not authorization to
  perform it. It does not activate post-execution persistence, physical C2, live
  authority, ES/Bridge, deployment or RW0-E.

`RW0_D2_OFFLINE_EVIDENCE_COGNITIVE_REVIEW_AUDIT_BLOCKED`
  A material defect, missing required evidence, failed validation or preservation/
  cleanup uncertainty prevents acceptance. State whether a candidate defect was
  actually found or only the audit is incomplete. Preserve live bytes.

`RW0_D2_AUDIT_PROVENANCE_MISMATCH`
  A fixed baseline/candidate/receipt/index/protected-ref condition does not
  authenticate, or section 1R cannot safely qualify the reported ref exception.
  Report the exact expected/actual mismatch without accepting another subject,
  editing state, or continuing semantic execution on unbound bytes.

A partial green pass, a test count, fixed digest, model recommendation, proof-source
qualification or the writer's READY token can never independently grant acceptance.
No asynchronous continuation or user approval step is part of the running audit.
