# Governed Execution Coordinator — RW0-D2 V4 local commit gate

## 0. Objective, routing and explicit effect ceiling

Use the implementation/repair Codex conversation with repository write permission.
The independent audit has finished; keep that conversation and all other repository
conversations idle. One parent, one writer, no subagents or additional models.
This is a repository-maintenance commit gate, not a new independent audit or a
product-level autonomous acceptance/Git-effect operation.

Objective: reauthenticate the independently accepted 70-receipt V4 candidate,
create one local topic branch, stage only those bytes, validate a complete external
copy of the staged tree, and make exactly one verified local commit if every gate
passes. Do not stop merely to request another routine approval between these steps.

Authorized repository effects, conditional on the gates below:
- Create and select the new local branch
  `codex/rw0-d2-offline-evidence-cognitive-review-v1` at the fixed baseline.
- Stage exactly the 70 paths in Appendix B; normal corresponding Git object/index
  writes are authorized, not working-source edits.
- One ordinary commit with the exact subject
  `feat: add RW0-D2 offline evidence and cognitive review`.
- The corresponding local branch/HEAD/reflog/object/index changes only.

Not authorized: implementation or documentation repairs; formatting; changing test
expectations; editing guidance, configuration, attributes, hooks or dependencies;
stash/reset/restore/clean/rebase/merge/amend/cherry-pick; deleting or force-moving
refs; a second commit; fetch, pull, push, PR, merge, auto-merge, deployment, network,
providers, sibling repositories, live product state or credential/session access.
No live-checkout imports, tests, fixtures, scripts or product child processes.

The publication ceiling is ZERO. Leave trunk_dev and origin/trunk_dev at their
observed baseline values. The topic branch must have no upstream. Local tracking
observations are not current remote verification. No snapshot or next-tranche
implementation is required by this gate.

Owning repo guidance remains authoritative. Stop on a real conflict rather than
bypassing required controls. Product-level prohibitions on a Coordinator Git effect
are not permission to implement one; this task only records already audited source
using normal development Git operations.

## 1. Accepted evidence and what remains unproved

The supplied independent report accepted the whole selected offline D2 candidate:
70 matching receipts, complete changed-source review, A01–A13, E01/E02, X01/X02b,
R01/J01/J02, C10, process/cleanup observations, six focused groups and selector-free
FULL 9,098 passes. It grants commit-gate eligibility only. The report's raw artifact
identity is 25,886 bytes, SHA-256
66c71f97bc40d138802e67c690ce9cd3b003d2018971acc8c2ac03bdcfbf8561.
This identifies supplied evidence; do not invent a local path or try to reconstruct
an absent copy to that hash.

The subsequent user-supplied auditor addendum resolves both held questions:
1. The ORIGINAL completed final_driver_gate.py invocation and returned output
   establish GUARDS 24 modules / 4,162 IDs, module digest
   4533bd1c1f6ee61c1e96847b3d6ce684af46046304ae9a6df28348eaace2b617,
   node digest
   547c990efa2ac226f2316e0d3c276b6709afa0c4deb20493a1e3db2230b9260b,
   PASSED GUARDS, exit zero, and contemporaneous JUnit 4,162 tests with no failures,
   errors or skips. The report's `547c990afa...` field was a transcription error.
   The record does not establish how that character changed. No new run or recovery
   of deleted raw logs occurred.
2. The auditor reports inspecting the complete preliminary command bodies and shell
   composition BEFORE prospective re-entry. The still-visible commands were:
   `pwd && rg --files -g 'AGENTS.md' -g '.docs/**' | head -80`
   and `git status --short && git branch --show-current && git log -1 --oneline`,
   from the repo workdir. Relative timing within their parallel call is not known.

The addendum restores the exact disposition:
RW0_D2_OFFLINE_EVIDENCE_COGNITIVE_REVIEW_ACCEPTED_READY_FOR_COMMIT_GATE

This is accepted Codex-reported independent evidence, not a new execution or live
identity observed by ChatGPT. No V5, source repair, repeated semantic-mutation
program, historical forensic program, or whole independent re-audit is selected.
The original audit root was deleted under its mandate; do not require its recovery.
Preserve overlapping-predicate and causal-credit limits from the audit.

Historical limits remain: the old raw-status interval was unpreserved; the earlier
V1 removed/added-ref incident remains unattributed; exact .git/config opening-byte
equality was not established for the old audit. None is retrospectively repaired
by this gate. This gate records its own actual current configuration and intervals.
The addendum did not freshly authenticate the checkout; the next section must.

## 2. Exact subject and guidance-first entry

Repository: /Users/ds/Repositories/Governed Execution Coordinator
Opening branch: trunk_dev
HEAD: 43ae26b9bccf9ad6ce61ec4722e14ac7b460ab18
HEAD tree: cc3cc104300f553ada581cee24e80dab6dd885b1
HEAD sole parent: 0d0926e3a483a3ab1a4fd597ac0495927352bf35
HEAD subject: feat: add RW0-D1 offline process and capsule spine
Locally observed upstream: origin/trunk_dev at HEAD, divergence 0/0; no fetch.
Worktrees: one.
Index: 263 stage-zero baseline entries, no staged or unmerged change.
Working candidate: 47 modified tracked paths + 23 creations = 70 changed paths.
Other tracked paths: 216 HEAD-exact.
Complete source inventory: 286 endpoints.
All 70 candidates: regular nonsymlink OS 0644, Git 100644.
Fixed opening index SHA-256:
7af425d5a47b91b0a14294660f5d449f5ba6308dc8846a8b13aca371c191a587
Fixed candidate AGENTS.md SHA-256:
ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166
Fixed raw replacement SHA-256:
9b14b520984e5e6a090482ee473b45a301b762176b94e3acd1ad05f786188efd

The known opaque cache is src/ge_nwp_coordinator/__pycache__: directory plus
37 regular members. Never import, copy into executable selection, delete or repair
it. Preserve the unrelated OS-0600
`tests/test_c2b3_private_atomic_program_initialization.py`; its Git mode is 100644.
Do not normalize existing file modes. Inspect ignored/unknown entries by safe
metadata only; unknown source-selection dependencies block. Do not open private
state merely to inventory it.

The first protected-repository action is this complete inert guidance read from /:

```sh
python3 -I -B -S - <<'PY_GUIDANCE'
from pathlib import Path
print(Path('/Users/ds/Repositories/Governed Execution Coordinator/AGENTS.md').read_text(encoding='utf-8'), end='')
PY_GUIDANCE
```

Finish any truncated guidance output before proceeding. Then run Appendix A once
from /. That exact retained opener is used ONLY for this gate's read-only
preflight. Its historical audit schema/token/limit describe that preflight phase,
not a prohibition on the later explicitly authorized commit phase. Do not edit the
embedded helper to accept changed indexes or replace its opening on drift.

A fully inspectable preliminary inert instruction/filename/status/branch/log read,
if one has already occurred in THIS engagement, may be classified from its actual
complete tool invocation and disclosed before the first successful opening. A
pure ordering mistake alone need not force another round trip. Unknown commands,
unaccounted mutation, source execution/import/tests, network, competing writers or
an unexplained index mismatch do not qualify. No prior-period preservation is
inferred, and no post-opening replacement is allowed.

Before any executable validation, verify Appendix B's complete fixed identity.
Reconstruct its RAW replacement twice from fresh raw reads, with exact baseline
blob/absence relationships, row order, modes, framing, lengths and aggregate.
Use the unchanged recipe, not the older generic textual-diff recipe. Count/hash
agreement alone is not a substitute for every per-path comparison. Verify all
216 other tracked endpoints against HEAD and record their current metadata.

Read the current governing docs as inert text, especially:
- AGENTS.md: Ownership and Change Rules; .docs/ as authority.
- .docs/rw0-d2-offline-evidence-and-review.md, the accepted D2 owner.
- .docs/rw0-d1-offline-process-and-capsule-spine.md.
- .docs/autonomous-software-development-operating-model.md.
- .docs/worker-execution-boundary.md and relevant current Section 41/status
  passages in .docs/c2b-durable-development-state.md.
Read any applicable nested guidance and existing commit/validation policy.
This is enough to check gate constraints; do not repeat the whole semantic audit.

## 3. Preflight preservation, refs and execution dependencies

Until the deliberate transition in section 4, EVERY live Git read must use the
ACTUAL helper path emitted by Appendix A, under its immutable index/cache/guidance
checks. Never use an invented /tmp path. Record complete source and ref snapshots,
configuration bytes/metadata through a bounded non-disclosing filesystem read,
and the resolved installed Git path. Do not print credentials, remote URLs or
unrestricted Git config/environment. Preserve configuration bytes/metadata during
this gate; a new observation cannot prove the old audit's missing observation.
Inspect included config dependencies only as needed to classify effective Git
behavior; a sensitive/unavailable dependency remains a limit, not permission to
read private key/provider/session material.

Protect every ref by default. Preserve symbolic targets as well as object IDs.
The expected audit report's 54 refs / 28 protected / 26 diagnostic is historical,
not a fixed current count. Classify the actual current inventory. Only records
beneath these exact subtrees can be conditionally diagnostic:
  refs/codex/turn-diffs/captures/
  refs/codex/turn-diffs/checkpoints/
No blanket refs/codex/** exemption. Qualification requires no source-selection,
validation, policy/admission, recovery, publication or protected-symbolic dependency.
Use the fixed baseline plus authenticated raw bytes, never a captured ref/tree.
Disclose qualified diagnostic deltas; they cannot excuse source/index/cache/config
or protected-ref drift. Do not alter those refs. Do not attribute or repair the
historical V1 incident. origin/HEAD need not point to trunk_dev; do not change it.

Require no active Git operation, unexpected lock, unaccounted competing writer,
additional worktree, staged change or foreign source endpoint. Require that the
selected topic branch does NOT already exist. Existing branch/commit state is a
reason to inspect and report, not force-create, reuse or create a second commit.

Inspect applicable attributes, hooks, templates, signing and identity settings
without running them or printing secrets. Prevent implicit repository execution:
fsmonitor, external diff/textconv, hooks, clean/process filters, conversions,
signing helpers, maintenance and lazy network fetching must not run unexpectedly.
This gate permits command-scoped inert hooks and unsigned commit ONLY where no
owning policy requires those controls. A required hook/signature or an unsafe
attribute/filter requirement blocks; do not silently waive policy. Do not change
persistent configuration, hooks, attributes, identity or source to get through.

Using an audit-owned external empty hooks directory and an empty template directory
is authorized for this gate's local Git invocations/copies, after policy inspection.
No hook is executed by this mandate. No new credential/signing access is authorized.
Require existing author/committer identity; absence blocks rather than inventing it.
All candidate bytes are already text/raw-policy checked by the audit; verify the
current staged/working whitespace checks without repairing any failure.

Close the preflight with helper --check, twice-matching replacement, complete
baseline/index/working/ref/config observations, and a saved PRE_MUTATION checkpoint.
No source bytes or protected observations may have changed. Do not treat successful
preflight as completion; continue to the authorized local Git gate.

## 4. Deliberate transition to the mutation phase

The helper's opening-index-equality invariant ENDS at the explicit PRE_MUTATION
checkpoint before branch/index writes. Do not run that helper after staging and
misclassify the intended index change as an audit failure. Do not reset its record
or use a new opener to excuse drift. Preserve the original checkpoint permanently
in the gate evidence; subsequent checks compare against the same source/cache/
configuration metadata and the narrowly enumerated authorized Git transitions.

Use the resolved installed Git executable via one parent-owned wrapper, stored
OUTSIDE the checkout. The wrapper is newly authored gate machinery, not an
independently audited product component. It must use explicit argv (no shell
interpolation of received paths), record commands/exits, enforce the approved
subcommands, preserve the environment guards from Appendix A, and check immutable
surfaces before/after every live operation. Retain its exact source/digest.

Command-scoped guard settings for this phase:
  GIT_OPTIONAL_LOCKS=0
  GIT_NO_LAZY_FETCH=1
  GIT_TERMINAL_PROMPT=0
  PYTHONDONTWRITEBYTECODE=1
  GIT_PAGER=cat; PAGER=cat; GIT_EDITOR=true
  git --no-pager -c core.fsmonitor=false -c gc.auto=0
      -c maintenance.auto=false -c core.hooksPath=<actual-owned-empty-hooks>
      -c commit.gpgSign=false -C <exact-repo> <explicit-argv>
Reject Git location/index/object/config environment overrides as in the opener.
Use --no-ext-diff and --no-textconv for diff/show/log. Prevent inherited selection,
warning-suppression and pytest-plugin options from changing the supplied gate.
No calls to an unknown executable or an unsigned/signed policy bypass.

Authorized state transitions, and no others:
1. New local topic ref: absent -> fixed baseline. HEAD symbolic target changes from
   refs/heads/trunk_dev to refs/heads/codex/rw0-d2-offline-evidence-cognitive-review-v1.
   HEAD's resolved object remains the fixed baseline. No working-source write.
2. Index: exact 263-entry baseline -> exact 286-entry candidate, after staging only
   the 70 paths. No unrelated staged path or source change.
3. One commit: topic ref/HEAD resolved object baseline -> new one-parent commit,
   with exact staged tree and subject. Expected associated local reflog/commit
   metadata and necessary object/index bookkeeping may change. No other protected
   ref, configuration, working-source or opaque-cache change is authorized.

Use these explicit branch-selection commands through the wrapper, not a checkout
that materializes or rewrites source:

```text
branch --no-track codex/rw0-d2-offline-evidence-cognitive-review-v1 43ae26b9bccf9ad6ce61ec4722e14ac7b460ab18
symbolic-ref -m "RW0-D2 V4 local commit gate" HEAD refs/heads/codex/rw0-d2-offline-evidence-cognitive-review-v1
```

Verify each completed transition. The new branch must have no upstream or
branch-specific configuration write. If a command fails or its outcome is unclear,
perform bounded readback only. Do not force, delete, roll back, retry a mutation or
repair the repository automatically. A blocked gate can truthfully leave the
known created branch/selected HEAD or staged index and report exactly that state.

## 5. Exact staging and tree verification

Build one UTF-8, NUL-terminated pathspec file from Appendix B's 70 unique paths,
sorted by UTF-8 bytes, inside the external gate root. Verify the file by reopening
it; include its byte count/digest in the record. No directory globs, `add .`, `-A`,
`commit -a` or source generation is allowed. Recheck all 70 source endpoints and
pre-stage index before the one staging operation. Invoke via the wrapper:

```text
--literal-pathspecs add --pathspec-from-file=<actual-owned-pathspec-file> --pathspec-file-nul
```

Here --literal-pathspecs is a Git GLOBAL option before `add`; construct the argv
accordingly. The wrapper must support that exact global option without widening
its subcommand allowlist. Any conversions/filter invocation must already have been
ruled out. Stop on byte mismatch; do not disable a policy or restage modified bytes.

Read complete NUL-safe stage-zero index entries and each blob without filters.
Require exactly 286 entries; all 70 staged payloads match the fixed mode/length/
SHA-256 and M/C baseline relation; all other 216 entries equal the baseline tree.
Require exactly 47 modifications and 23 additions relative to the fixed HEAD,
no deletion/rename/type change/unmerged entry, and no unstaged source change.
Do not infer this from status/counts alone.

Reproduce Appendix B's raw replacement from the STAGED blobs, always relative to
the ORIGINAL fixed HEAD, and require the same fixed aggregate. Recompute twice.
Independently compute expected Git blob identities from exact raw payloads; verify
stage entries. Use `write-tree` (authorized Git object write) to record the complete
staged candidate tree, then independently enumerate that tree and verify all 286
path/mode/blob/payload relationships against the audited candidate + baseline.
Never accept a tree merely because Git returned an OID.

Run guarded `diff --cached --check` and `diff --check`; inspect status/path sets via
NUL-safe outputs. Preserve the live index content and metadata from this successful
STAGED checkpoint through final validation and the immediately-before-commit
checkpoint. Only the later commit may perform its ordinary accounted index writes.
Record all expected deltas, not an assertion that this was a read-only engagement.

## 6. One staged-source final validation, no repeated independent audit

Build one fresh disposable external validation copy from the actual staged tree,
not mutable working-file reads after staging and not an old audit copy. A local
`--no-hardlinks` clone at the fixed baseline with no remotes may supply Git context;
overwrite/materialize its complete source selection from raw staged blobs and
verify all 286 endpoints. Use inert hooks/templates. Do not hardlink live source,
copy ignored caches/state, retain object alternates or remotes, execute hooks,
checkout captured refs, install dependencies, or use network. If cloning uses the
live repo, bracket that read with the current gate preservation checks as well.

Use staged blob payloads to supply the 70 changed endpoints; exact HEAD blobs
supply the other 216. Preserve the recorded safe source OS modes in the copy,
including the unrelated 0600 file. Check the full path set, source metadata and
bytes before/after collection and execution. No source drift is acceptable.
The external checkout must have no extra executable source/import/test dependency
on the live checkout or ignored state. Gate helpers/results live outside that
validation checkout, not among its collected source/test modules.

Run ONE full collection and ONE full execution, serially, from this verified copy.
The six focused groups and semantic mutants are NOT rerun; their independent
acceptance remains credited at its original scope. FULL includes their tests.
Use the installed interpreter used by the accepted audit when available:
  /Library/Frameworks/Python.framework/Versions/3.13/bin/python3
Record actual executable/version and pytest version (accepted record: Python
3.13.4, pytest 8.4.1). No install or substitution of expected test identities.

Use umask 022. Precreate distinct owned temporary parents. Commands are:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src TMPDIR=<owned-tmp> \
<actual-python> -B -m pytest -q -p no:cacheprovider \
  --basetemp=<owned-full-collect> --collect-only

PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src TMPDIR=<owned-tmp> \
<actual-python> -B -m pytest -q -p no:cacheprovider \
  --basetemp=<owned-full-run> --junitxml=<owned-full-junit>
```

There is NO test-path argument, -k/-m selector, last-failed selection, xdist,
deselection, skip/xfail acceptance or warning suppression. Capture complete
collection IDs without splitting parameter text at whitespace or accepting a
truncated console stream. An external observational collector may retain exact
items/IDs without modifying selection; record its source and ensure it adds no
collected test/module. Verify actual module and node inventories before execution.

Fixed FULL receipt:
  collecting modules: 131
  complete unique node IDs / passed: 9,098
  module SHA-256:
  3c0ebcd7195ebfb0f483820c25a2f94f613ba42c67e7f714df90873f52ad1061
  node SHA-256:
  13298265ca6c9c023008e6051719065b3e9c78e1c2524413f9f7035090cfcbaf

Inventory grammars (no prefix):
MODULE: unique test paths sorted by UTF-8 bytes; each u32be(path length), exact
path UTF-8, and raw 32-byte SHA-256 of its module payload.
NODE: complete unique node IDs sorted by UTF-8 bytes; each u32be(ID byte length)
and exact ID UTF-8. Preserve all parameter text exactly. Two noncollecting test
support .py files remain source endpoints, not collecting modules.

Require completed command exit 0 plus structured JUnit/execution evidence of 9,098
passes and zero failures/errors/skips. Dots or an intended command are insufficient.
Inspect the complete warning records. The accepted environment observed only these
three Python 3.13 fork DeprecationWarnings in unchanged test_sqlite_b2c_writer_session.py:
- test_operation_guard_close_waits_and_retains_authority_until_exit
- test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
- test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock

Report actual category/location/message/count; never suppress or silently label a
new warning as historical. An unexplained collection/source/result discrepancy or
new material warning blocks commit; no source or expectation repair in this gate.
A demonstrable external DRIVER-only mistake may be corrected in the owned external
root, with failed/interrupted attempts retained and only the affected gate rerun.
An actual test/source defect returns to the implementation/audit lifecycle instead.

After validation, verify staged tree and all 286 blobs still match the authenticated
STAGED checkpoint, working bytes/modes/metadata and opaque cache still match the
original source opening, config is unchanged, and every protected ref has only its
explicitly authorized branch-selection delta. Reproduce the same replacement again.
Retain the new test records; do not claim they recover deleted historical records.

## 7. Single commit and post-commit authentication

Immediately before committing require: all prior gates passed; branch is exactly
the selected topic, HEAD resolves to the fixed baseline; index is the recorded
staged tree with unchanged STAGED metadata; no unstaged/foreign files; no locks or
competing writer; immutable source/cache/config still preserved; no unexplained
protected-ref drift. Recheck local trunk_dev and origin/trunk_dev.

Invoke exactly once through the guarded wrapper:

```text
commit --no-gpg-sign -m "feat: add RW0-D2 offline evidence and cognitive review"
```

The inert hooks directory remains in effect for all hooks. These command-scoped
choices are authorized only after section 3 has
established that no owning policy requires hooks/signing. They are not a general
permission to bypass governance. No --amend, --allow-empty, automatic retry or
second commit. A command failure/timeout/uncertainty permits readback, not rerun.

Read the resulting actual commit object, parent list and tree. Require:
- Exactly one parent, equal to the fixed baseline.
- Exactly the verified staged tree and exact subject.
- Complete committed inventory of 286 entries; all 70 modes/lengths/raw payload
  SHA-256 values match Appendix B; all 216 other entries remain HEAD-baseline exact.
- The committed replacement, reconstructed against ORIGINAL baseline (not new HEAD),
  matches the fixed framed SHA-256; independently repeated reconstruction agrees.
- Topic ref and HEAD point to that commit, trunk_dev and origin/trunk_dev are unchanged,
  no upstream configured for the new branch, no other protected ref/config changes.
- Working source bytes/modes/metadata, guidance and opaque cache equal the opening;
  actual index logically equals the committed tree; no staged/unstaged/untracked
  source changes. Known ignored cache may remain; do not call it absent.

Inspect final state with guarded reads. A post-commit mismatch is not repaired by
amend/reset/recommit. Report the actual committed object and scope of uncertainty;
do not publish. Exact hashes prove identity, not implementation correctness.

## 8. Retained receipt, cleanup and final response

Create a small private closeout bundle outside the repository, preferably in a
new uniquely named RW0_D2_V4_Local_Commit_Gate directory under /Users/ds/Downloads.
Use actual paths, exclusive creation and safe permissions. Retain:
- A concise report and machine-readable result with original candidate identity,
  actual branch/commit/tree/parent, expected/observed comparisons and authorized
  Git mutations.
- Complete 70-path working/staged/committed comparisons and full 286-entry staged/
  committed manifest; original/pre-mutation/staged/precommit/close observations.
- Exact commands/exits, actual module/node inventory receipts, complete collected
  IDs and reviewed safe structured test-result/warning evidence.
- Exact gate helper source/digests; checkpoint, preservation and cleanup records.

Review retained content for secrets/private state; retain safe paths/digests and
metadata, not database fixtures, source copies, environment dumps, credentials,
provider/session files or raw sensitive logs. Do not claim original raw audit logs
survive. The retained bundle is evidence/projection only, not Coordinator state or
effect permission. Save and reopen each delivered receipt; report actual byte
sizes/SHA-256 and existing paths. Do not delete the sole new gate receipt.

Clean only positively owned disposable external clones, temporary test state and
logs after safe result retention and child/descriptor cleanup. Classify symlinks,
FIFOs, databases and caches without following unsafe entries. Do not clean the
live repo, pre-existing cache, another task's files, refs or arbitrary temp paths.
Do a final preservation/readback after cleanup. No follow-on publication, snapshot
program, docs status edit or C2/RW0-E work in this engagement.

Success verdict:
RW0_D2_OFFLINE_EVIDENCE_COGNITIVE_REVIEW_COMMITTED_LOCALLY_NOT_PUBLISHED

Otherwise use a precise BLOCKED or COMMIT_OUTCOME_UNCERTAIN disposition, recording
whether branch creation, HEAD selection, staging or commit actually occurred.
Do not roll back automatically or say "no mutation" after an authorized mutation.

Final report must include: objective; exact opening; 70/286 and repeated replacement
checks; branch/index/tree transitions; final validation commands and actual results;
warnings; actual commit identity/subject/parent/tree and 70/286 committed comparisons;
protected/diagnostic ref deltas; config/source/cache/mode preservation; retained
artifact paths/sizes/hashes; cleanup; failed/skipped validation; unresolved seams;
and an explicit no push/PR/merge/provider/ES/Bridge/migration/runtime-widening statement.

Keep claims bounded: D2 remains one offline artificial D1 -> validation/review ->
checked evidence -> nine-role fake cognitive review -> typed transient preadmission
handback. No rank-15 admission, Section 41 post-execution recording, physical C2,
terminal acceptance, migration 0005, live provider, product Git handler or autonomous
loop is inferred from this repository commit.

## Appendix A. Exact retained opener — PRE-MUTATION ONLY

The source below is copied unchanged from the accepted audit chain. Its old audit
labels remain literal; section 4 explicitly closes this preflight before authorized
Git mutation. Never alter or rerun it to accept drift.

```sh
python3 -I -B -S - <<'PY_OPEN'
import hashlib
import json
import os
import stat
from pathlib import Path

REPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')
AGENTS_SHA = 'ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166'
GUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',
          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}
OVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',
             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',
             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')

def meta(st):
    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,
            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),
            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,
            'mtime_ns': st.st_mtime_ns}

def regular_record(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise RuntimeError('opening_requires_regular_nonsymlink_file')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_before_read')
        h = hashlib.sha256()
        while True:
            chunk = os.read(fd, 1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_during_read')
    finally:
        os.close(fd)
    if meta(path.lstat()) != meta(before):
        raise RuntimeError('opening_file_changed_after_read')
    return {**meta(before), 'sha256': h.hexdigest()}

def index_path():
    dotgit = REPO / '.git'
    st = dotgit.lstat()
    if stat.S_ISDIR(st.st_mode):
        gitdir = dotgit
    elif stat.S_ISREG(st.st_mode):
        regular_record(dotgit)
        raw = dotgit.read_text(encoding='utf-8').strip()
        if not raw.startswith('gitdir: ') or '\n' in raw:
            raise RuntimeError('unsupported_gitdir_pointer')
        pointed = Path(raw[len('gitdir: '):])
        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()
        if not stat.S_ISDIR(gitdir.lstat().st_mode):
            raise RuntimeError('gitdir_not_directory')
    else:
        raise RuntimeError('unsupported_dotgit_type')
    return gitdir / 'index'

def cache_record():
    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'
    st = cache.lstat()
    if not stat.S_ISDIR(st.st_mode):
        raise RuntimeError('cache_directory_missing_or_unsafe')
    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))
    if len(members) != 37:
        raise RuntimeError('unexpected_cache_membership')
    out = {'.': meta(st)}
    for path in members:
        out[path.name] = regular_record(path)
    if meta(cache.lstat()) != meta(st):
        raise RuntimeError('cache_directory_changed_during_read')
    return out

def guarded_environment():
    present = [name for name in OVERRIDES if name in os.environ]
    if present:
        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))
    env = dict(os.environ)
    env.update(GUARDS)
    env['GIT_PAGER'] = 'cat'
    env['PAGER'] = 'cat'
    return env


import datetime
import shutil
import tempfile

guarded_environment()
agents = regular_record(REPO / 'AGENTS.md')
if agents['sha256'] != AGENTS_SHA:
    raise RuntimeError('guidance_not_exact_audited_candidate')
index = index_path()
index_before = regular_record(index)
cache_before = cache_record()
git = shutil.which('git')
if git is None:
    raise RuntimeError('installed_git_unavailable')
gate_root = Path(tempfile.mkdtemp(prefix='rw0-d2-repaired-v4-audit-'))
os.chmod(gate_root, 0o700)
print('GATE_OWNED_ROOT=' + str(gate_root), flush=True)
record = {
    'schema': 'rw0-d2-repaired-v4-audit-opening-observation',
    'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'repo': str(REPO), 'guidance': agents, 'index_path': str(index),
    'index': index_before, 'cache': cache_before, 'git_executable': git,
    'git_environment': GUARDS,
    'limit': 'This re-audit interval only. Source, index, guidance, cache and protected refs remain unchanged. Section 1R governs separately observed and conditionally classified turn-diffs refs; no auditor ref write, source repair, staging, commit or remote action is authorized.'
}
READ_HELPER = "import hashlib\nimport json\nimport os\nimport stat\nfrom pathlib import Path\n\nREPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')\nAGENTS_SHA = 'ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166'\nGUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',\n          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}\nOVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',\n             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',\n             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')\n\ndef meta(st):\n    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,\n            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),\n            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,\n            'mtime_ns': st.st_mtime_ns}\n\ndef regular_record(path):\n    before = path.lstat()\n    if not stat.S_ISREG(before.st_mode):\n        raise RuntimeError('opening_requires_regular_nonsymlink_file')\n    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)\n    try:\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_before_read')\n        h = hashlib.sha256()\n        while True:\n            chunk = os.read(fd, 1024 * 1024)\n            if not chunk:\n                break\n            h.update(chunk)\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_during_read')\n    finally:\n        os.close(fd)\n    if meta(path.lstat()) != meta(before):\n        raise RuntimeError('opening_file_changed_after_read')\n    return {**meta(before), 'sha256': h.hexdigest()}\n\ndef index_path():\n    dotgit = REPO / '.git'\n    st = dotgit.lstat()\n    if stat.S_ISDIR(st.st_mode):\n        gitdir = dotgit\n    elif stat.S_ISREG(st.st_mode):\n        regular_record(dotgit)\n        raw = dotgit.read_text(encoding='utf-8').strip()\n        if not raw.startswith('gitdir: ') or '\\n' in raw:\n            raise RuntimeError('unsupported_gitdir_pointer')\n        pointed = Path(raw[len('gitdir: '):])\n        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()\n        if not stat.S_ISDIR(gitdir.lstat().st_mode):\n            raise RuntimeError('gitdir_not_directory')\n    else:\n        raise RuntimeError('unsupported_dotgit_type')\n    return gitdir / 'index'\n\ndef cache_record():\n    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'\n    st = cache.lstat()\n    if not stat.S_ISDIR(st.st_mode):\n        raise RuntimeError('cache_directory_missing_or_unsafe')\n    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))\n    if len(members) != 37:\n        raise RuntimeError('unexpected_cache_membership')\n    out = {'.': meta(st)}\n    for path in members:\n        out[path.name] = regular_record(path)\n    if meta(cache.lstat()) != meta(st):\n        raise RuntimeError('cache_directory_changed_during_read')\n    return out\n\ndef guarded_environment():\n    present = [name for name in OVERRIDES if name in os.environ]\n    if present:\n        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))\n    env = dict(os.environ)\n    env.update(GUARDS)\n    env['GIT_PAGER'] = 'cat'\n    env['PAGER'] = 'cat'\n    return env\n\n\nimport subprocess\nimport sys\nopening = json.loads(Path(__file__).with_name('opening.json').read_text(encoding='utf-8'))\n\ndef immutable_checks():\n    if str(index_path()) != opening['index_path']:\n        raise RuntimeError('index_location_drift')\n    if regular_record(index_path()) != opening['index']:\n        raise RuntimeError('audit_index_content_or_metadata_drift')\n    if regular_record(REPO / 'AGENTS.md') != opening['guidance']:\n        raise RuntimeError('audit_guidance_content_or_metadata_drift')\n    if cache_record() != opening['cache']:\n        raise RuntimeError('live_cache_drift')\n\nimmutable_checks()\nindex_before_read = regular_record(index_path())\nargs = sys.argv[1:]\nif args == ['--check']:\n    print('READ_HELPER_IMMUTABLE_SURFACES_MATCH')\n    print('CURRENT_INDEX_SHA256=' + index_before_read['sha256'])\n    print('Index content and metadata equal this audit opening; no stage or index write is permitted.')\n    raise SystemExit(0)\nallowed = {'status', 'rev-parse', 'rev-list', 'ls-files', 'ls-tree',\n           'cat-file', 'diff', 'show', 'log', 'symbolic-ref', 'worktree',\n           'check-attr', 'for-each-ref', 'reflog'}\nif not args or args[0] not in allowed:\n    raise RuntimeError('unapproved_live_read_command')\nif args[0] == 'symbolic-ref' and args[1:] not in (['HEAD'], ['-q', 'HEAD'], ['--quiet', 'HEAD']):\n    raise RuntimeError('readonly_head_query_only')\nif args[0] == 'worktree' and args[1:] not in (['list'], ['list', '--porcelain']):\n    raise RuntimeError('readonly_worktree_list_only')\nif args[0] == 'reflog' and (len(args) < 2 or args[1] != 'show'):\n    raise RuntimeError('readonly_reflog_show_only')\nfor arg in args[1:]:\n    if arg in ('--ext-diff', '--textconv', '--filters', '--output', '--exec') or arg.startswith(('--output=', '--exec=')):\n        raise RuntimeError('unapproved_output_or_execution_option')\nif args[0] in ('diff', 'show', 'log'):\n    args = [args[0], '--no-ext-diff', '--no-textconv', *args[1:]]\ncommand = [opening['git_executable'], '--no-pager', '-c', 'core.fsmonitor=false',\n           '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', '-C', str(REPO), *args]\ntry:\n    result = subprocess.run(command, env=guarded_environment(), check=False)\nfinally:\n    immutable_checks()\n    if regular_record(index_path()) != index_before_read:\n        raise RuntimeError('index_changed_during_read_command')\nraise SystemExit(result.returncode)\n"

def write_private(path, payload):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as f:
        f.write(payload)

try:
    write_private(gate_root / 'opening.json',
                  (json.dumps(record, sort_keys=True, separators=(',', ':')) + '\n').encode())
    write_private(gate_root / 'live_read.py', READ_HELPER.encode())
    if regular_record(index) != index_before or cache_record() != cache_before:
        raise RuntimeError('opening_changed_before_first_git')
    print('OPENING_RECORD=' + str(gate_root / 'opening.json'))
    print('LIVE_READ_HELPER=' + str(gate_root / 'live_read.py'))
    print('OPENING_INDEX_SHA256=' + index_before['sha256'])
    print('RW0_D2_AUDIT_PRE_GIT_OPENING_RECORDED')
except BaseException:
    for name in ('opening.json', 'live_read.py'):
        p = gate_root / name
        if p.exists():
            if not stat.S_ISREG(p.lstat().st_mode):
                raise RuntimeError('unexpected_owned_helper_type')
            p.unlink()
    gate_root.rmdir()
    raise
PY_OPEN
```

## Appendix B. Exact accepted seventy-path subject and unchanged raw framing

Exactly 47 modified tracked paths and 23 working creations against the fixed HEAD.
All 70 are regular nonsymlink OS 0644 / Git 100644 files. The other 216 tracked
working files equal HEAD, preserving their actual opening OS modes. The index
contains the 263 stage-zero baseline entries, not the working candidate tree.

```text
Rows: 70 (47 M, 23 C)
Raw payload bytes: 5,856,685
Encoded row bytes: 5,862,083
Complete framed bytes: 5,862,108
Fixed complete RAW replacement SHA-256:
9b14b520984e5e6a090482ee473b45a301b762176b94e3acd1ad05f786188efd
```

Authenticate every supplied receipt and its baseline/absence relationship BEFORE
repository code executes. Reconstruct the complete raw replacement twice from fresh
reads, preferably once streaming and once explicitly concatenated. Exact framing:

```text
25-byte prefix: ASCII RW0-D2-BINARY-REPLACE-V1 followed by one NUL
Rows sorted by UTF-8 repository-relative path bytes:
  u16be(path byte length) + exact path UTF-8
  ASCII M or C relative to fixed HEAD
  u32be(0o100644)
  20 raw baseline Git blob bytes for M, or 20 zero bytes for C
  u64be(payload byte length) + exact current raw payload bytes
```

Both constructions must match ALL stated sizes, the fixed digest, every endpoint
receipt and stable metadata. Hash raw payloads, not strings containing their hashes.
An unrecognized path, mode, baseline, receipt or protected-surface mismatch blocks
before code/tests. Do not select new acceptable bytes, normalize or repair files,
accept a preceding version, or use passing counts to excuse a mismatch.

This table derives from T40's complete V3 receipts with only the two T41 replacements.
The original handback and integration receipts previously omitted by the V3 writer
were resolved by the independent V3 audit; they are fixed entries here, not measured
wildcards. The unchanged checkpoint is also fixed. These are supplied audit anchors,
not a claim that ChatGPT authenticated the live candidate.

| Path | Status | Baseline Git blob (C: absent) | Current bytes | Current SHA-256 |
|---|---|---|---:|---|
| `.docs/architecture.md` | M | `7d21418a68d2d3002753227da08cf059836d0260` | 44,745 | `5075b772afddcfe8276933d189155aa689dc4c1ee162bb702c7c7f4efaf04635` |
| `.docs/authority-boundaries.md` | M | `3524d11d67a46344214b455396afeeaa3754b41d` | 36,175 | `79c57d377b6ef7f2460ee5a5827b9c5c61334e656be9eeed73264a6906e55e32` |
| `.docs/autonomous-software-development-operating-model.md` | M | `a46d51fe3ea480e39c8c7989a08e80d9db21f5b8` | 41,197 | `926468bad8cd51c57e3aec6da775c6dced52880215f24d5b03177499a119c6c2` |
| `.docs/b3b2a-read-scope-and-query-contracts.md` | M | `c3237c31fc4b59dcd632b827a4be9907cfcfb998` | 10,013 | `74b1d21b02cd9886a697e1f1cb01dca6977cabb2da194269a35d49745fe548f6` |
| `.docs/b3b2b-select-readers.md` | M | `f1ba74b0a5cd3946a3138de326949d29f789cfac` | 6,477 | `fa7a364ce070b3fcef44907bc884bc783200e1951c618fd7e392d485497c7f07` |
| `.docs/c2b-durable-development-state.md` | M | `04c068d07cd08feaf6c56dafbf3494ccde037ede` | 1,891,411 | `8db2ba24f0685ac21fae2103bb664727a8d9635d3ead5f6bae0d42b35aaf34d2` |
| `.docs/c2b2-private-readers.md` | M | `018b3d905f5db80cf15b546f881dc8c1de3a67b7` | 14,020 | `f765b2dcd74979e235cb04c15dd1fbc81eca149aec017ca500708903bbc105d2` |
| `.docs/c2b2-pure-durable-row-values.md` | M | `1cab6d886f2cd3101987476064a9ce82d2eb4dd2` | 8,540 | `0970595b4c292517d0770542ff8e12a03b98ea93057d4e715d6518415e83aaf3` |
| `.docs/durable-state-model.md` | M | `49694cd86a51f3fb0fb3799e734a52c1a395b8c7` | 42,053 | `7f9cba19f491322dd2fc0f1656ac6b76e698723a6700d1f9919d22b2196e9e80` |
| `.docs/rw0-b1-pure-phase-values.md` | M | `5b7fb0072c6d04898cd212fdc4ff5f63903cf13b` | 35,115 | `7294e7b3aabad5338c4d846e44686ffd075b3e8fe4598495a3e7267103a9ef1e` |
| `.docs/rw0-b2-wire-protocol.md` | M | `5e41d1cb3b2f430d29eb88bdbf2b46570faf3c6b` | 26,084 | `ac1091f043f5fa6042ced1e919c740a08af975b7df1e5e97b66634f85cb68e69` |
| `.docs/rw0-c1-durable-evidence.md` | M | `a7111c4dcf761b60df35c59794bf2e3acd949745` | 15,037 | `f2c6c51d0437aa78b7975bfca3e6fc629fc2898d55c0c696750221000343a02c` |
| `.docs/rw0-c2-first-live-proof-posture.md` | M | `4b69e424655ea67900f6c6042c0cbacaf2d53f8a` | 17,674 | `ba61008234eb5ec85416c459dab0a82b19f7e1a0662dcb15f1289ba445fdf5bd` |
| `.docs/rw0-d1-offline-process-and-capsule-spine.md` | M | `f3557ca523cac0d6fa26647b17a84aef66fecc15` | 5,624 | `b537fbe074717aacdfaefd2cf32cd22c46046034ae115453ddded4e2dc25201b` |
| `.docs/rw0-d2-offline-evidence-and-review.md` | C | `absent` | 8,348 | `f9306ad7333ae08aefd62456041629380c05e984bddc3925258c655a28fa7580` |
| `.docs/rw0-remote-worker-contact-phase-entry.md` | M | `230167a39b115634c8f9b5ae5a0699639f6ff454` | 59,586 | `bee20ed00c7e6f86db3394351f0cbe29626413c635cd9a982416984b288e6fbd` |
| `.docs/worker-execution-boundary.md` | M | `464aef2aa7a561e4adc6792d1d07642d3576f364` | 32,409 | `3cfc1208d96e1f59a81dcd70dce5d43d89f2cb70cc5af6eca453650c33742769` |
| `AGENTS.md` | M | `254854d4a57487d97ce02a73ce2ed26c86ece170` | 64,142 | `ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166` |
| `README.md` | M | `088c832ca7e28d18c82ff6317738ac8ca1c7b5d1` | 47,694 | `f48f2439d282350e36b5d8374864cb5dfe19eb417672737e820500c3a68224f3` |
| `src/ge_nwp_coordinator/_cognitive_proposal_semantic_values.py` | M | `c164616b9e86379c3c6a9210cf4941429a596d4c` | 71,190 | `40243b96765ee0bf49e56a36123e0553f3bb9ab3e0fada38dbe619a2acc1eacd` |
| `src/ge_nwp_coordinator/_development_bound_effect_establishment_contracts.py` | C | `absent` | 43,039 | `fd8fb53c8129001b74df8fa5b15ae69bb45fd970e2aa93f3bc5c20eeeeb1b370` |
| `src/ge_nwp_coordinator/_rw0_d1_fake_worker.py` | M | `cb37f733141f1e3c3ce874fcc052149de1f82881` | 3,668 | `21e0c9d6c2ece57b87dfb05e961ba1a99a48e72346bbab2c4c1ed571eb5f1f00` |
| `src/ge_nwp_coordinator/_rw0_d1_handback.py` | M | `ecfcf767a5f1c32c0cf007a2c8aa3137ef92374d` | 16,920 | `3cae7fa4423187d53382ba23d9e459a5f0efcb6900a4deed6d4498ed2534ed56` |
| `src/ge_nwp_coordinator/_rw0_d1_offline.py` | M | `4f2a82e46fda9be8123888f5ca46968a4345c25f` | 23,371 | `9546f06f211253d72ea91e0dc2eaf4f0b47fdd54e3d431207f59960fbc742c95` |
| `src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py` | M | `7dc90a0442e348aaac985d711c4d1a97adb7cc05` | 12,175 | `a236bbf599e7d32b4edcc31d23182fd9613c5d290f31a0f1e57961b6a104fe56` |
| `src/ge_nwp_coordinator/_rw0_d2_handback.py` | C | `absent` | 28,905 | `85ea3872fe52dbf12608b1dcd47499b76ff11fc556b0c689498fdce56346f7ed` |
| `src/ge_nwp_coordinator/_rw0_d2_offline.py` | C | `absent` | 6,967 | `d838dd02495cab5cbafa2e6e0b99d6a4e6b4b30e4ac5cb288cb9dd2db02d0d44` |
| `src/ge_nwp_coordinator/_rw0_d2a_evidence.py` | C | `absent` | 53,134 | `e93c2592c8f838bd178ffa8e57f57a9116fcdf567b248e511496d00384968ec9` |
| `src/ge_nwp_coordinator/_rw0_d2a_fake_reviewer.py` | C | `absent` | 2,878 | `0d061fdf600039ff69ba0d0dc3f1a0239c2527500461244bb53455bbdd326973` |
| `src/ge_nwp_coordinator/_rw0_d2a_fake_validator.py` | C | `absent` | 2,726 | `c1eb49503b4345d25047814e089545f9d1cd4c85f10ae20254b8b6283fa58fbe` |
| `src/ge_nwp_coordinator/_rw0_d2a_handback.py` | C | `absent` | 20,455 | `7d1fc29c303666907c3f6e863f551d448684009db0d0b1db9881d64889e0e14f` |
| `src/ge_nwp_coordinator/_rw0_d2a_offline.py` | C | `absent` | 30,416 | `d81db9535b17c7daae7be449d7e30dbcaaa599749ddc2619dbfa7d40f87db838` |
| `src/ge_nwp_coordinator/_rw0_d2a_process_frames.py` | C | `absent` | 6,397 | `2c969b1ec303674500143bbbd721e4fe5f7ee161e00b4343f71a611a7f075c8d` |
| `src/ge_nwp_coordinator/_rw0_d2a_workspace.py` | C | `absent` | 5,075 | `45086c2b216639d3a35deef972acda526f004608780a8a8b5e30ed51253f0697` |
| `src/ge_nwp_coordinator/_rw0_d2b_fake_review_model.py` | C | `absent` | 3,771 | `492288c84c2491120a56c7056000f8ec3860c7fbce2bcb3c33249e5e1af5d93a` |
| `src/ge_nwp_coordinator/_rw0_d2b_model_frames.py` | C | `absent` | 8,032 | `e4b7cddc6cfd4caa7e34781e1c34c00833d6f83a98477d46ce55e878e97dfcef` |
| `src/ge_nwp_coordinator/_rw0_d2b_model_input.py` | C | `absent` | 81,718 | `e2bbe585f8ae19df5dd6547212cf239ac58411795cbae904cf3ed869910bdd9a` |
| `src/ge_nwp_coordinator/_rw0_d2b_proposal.py` | C | `absent` | 22,718 | `deec7caf82206c40545a308f3a8845fb867e64a211a81e055fb29ffbafc0666a` |
| `src/ge_nwp_coordinator/_sqlite_development_bound_effect_establishment.py` | C | `absent` | 23,760 | `c1005096ec8761257927a7b983dcb43b922cd89193338a761ba15ae5368cb5f5` |
| `src/ge_nwp_coordinator/_sqlite_rw0_c1.py` | M | `635b5dd49256e14103fced6ff8ea4db76649e22c` | 203,409 | `d17490b3ce1b136eeb3d559f01f44e97836827bc137325b306ec01530e06e9e7` |
| `src/ge_nwp_coordinator/sqlite_transition_transaction.py` | M | `f8053db4010faaba41b38b531d93a8b21e80daa8` | 180,600 | `6d662dcb83a2641b9d95dee7209ddbd0d8b991bc720da3aafa5b4b9fb3bc5521` |
| `src/ge_nwp_coordinator/sqlite_writer_session.py` | M | `97162e3a749a7f1f1ae75de90c4b2d9092068107` | 299,804 | `54f9c5a0844421686c1c89cdecf3c2865263b3339d2faec933c615ca2ca3d404` |
| `tests/test_b2a_writer_session_contract.py` | M | `ccadd884de29d606c9243ea7796cc380e29fe5c2` | 29,168 | `835b386274f410f2fc52b1a40b2c936009ac5286fb22bc23cc28efa789be0664` |
| `tests/test_b3b2a_read_scope_and_query_contracts.py` | M | `66cab4655d33c1b864f5fb4c22e853a39c5a8188` | 26,502 | `4cabeed0c37a99c0f937c0b49f25c7c6a049eb9125e64127019c449dcd86313a` |
| `tests/test_b3b2b_select_readers.py` | M | `c0c5a0e091572f30a428fd5a2634c21d25a6ad64` | 118,350 | `22061f6846b0ebc969f9b67bac399b8d8eb237c8df0e2de92d84d477c0f1ce2b` |
| `tests/test_b3c4c_prerequisite_contract.py` | M | `f1ee03232e33da8bbfa5592fe81c53414acb25b1` | 36,340 | `3d25c2ffb8ee86856c154cfc9dd842bab2db87ea2b200cd75758a62f372b5cd8` |
| `tests/test_c2a_nonimplementation.py` | M | `3f343ae5886c92941ebfff63ba4213de2109025e` | 30,650 | `c0db68e10f4588c02bbc38da1b95d6898a3d7896c127038533ce0c8a6715442e` |
| `tests/test_c2b0_durable_state_contract.py` | M | `b910d61aaf670ba40a0d649f933c06767e7360e5` | 887,367 | `995c3690500e3d3009f1fe93b276db506e1d454764dd2e5167df52bf81252c1a` |
| `tests/test_c2b2_development_reader_contracts.py` | M | `122f0d44b46e0a8d7b283d5baec1ce465e2028b6` | 71,365 | `28dbf4fff09d75d7522af35c8fddc8908b7c4c1d18ff8043d19dbf6b90f30970` |
| `tests/test_c2b2_development_row_value_boundaries.py` | M | `d7dea23786bec2ca98bb702bbe93cc31e4192221` | 17,972 | `f2a7089748f39dc8c40a932ac770edd3ffa7f8ea581b053af101dfda8100c830` |
| `tests/test_post_execution_pure_owner_boundaries.py` | M | `437a4e7cbd39682bdd08f03b3a30c0bbbd057614` | 19,302 | `7945be6d5e01c2a1b437cabc57972bbd70a725da9c14f7dd92574ff8f8633014` |
| `tests/test_post_execution_pure_owner_vectors.py` | M | `3eed1c6bc08b6876d1e74d94a4e5509c14786eb0` | 103,682 | `3d526cabcead871b5bba47952b914df76a34b5d85a7b730e55afb951c050de16` |
| `tests/test_runtime_non_authority.py` | M | `79d4ab185815234c9d087c48d2439b9a1d95d95d` | 48,343 | `fef5729d8e7f4c619ddb2731b52d3500bc8e75988a3f422648b9dea743ef01c9` |
| `tests/test_rw0_b1_boundaries.py` | M | `17d1e09c30b01287718c6b5175bac76b03daf458` | 52,838 | `af8d9f7507733876a5978d1a3f5b871a81030380eba929cbffe6959f9d639aaa` |
| `tests/test_rw0_b2_capability_boundaries.py` | M | `4668d2a2c285d2d79bf6ebfb0c9c9f60166bcb27` | 50,538 | `85ee20f37629ffc852154cea67dd5dc983b0f2f74ab2d370192c13d999b397c3` |
| `tests/test_rw0_b2_wire_boundaries.py` | M | `9e04f528326a6f337a4f47e7e9f9eda3c9a82e0a` | 38,513 | `13531d5d46258ca67cc7bf0bddd78c560ce9b7308ff296068a146299f349ba27` |
| `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | M | `0f0159c172e1448d2b96ab19411e1f85467a2931` | 120,405 | `af7f49ac8da64c12e97d03a536ee10b89a11996651b0d712dc04baef427d8cf3` |
| `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | M | `e9d95b54a4b5921be8ec39d2bf3f6216204750c7` | 247,679 | `e8de37791388c28f1b1626747af6c4094622469168ed9799eaa78f7f6f4d3613` |
| `tests/test_rw0_d1_handback_values.py` | M | `982be9b37aa05db0c6d6a3321b775c7c64f2142d` | 30,189 | `e8addc00e8b37aa5e6f24a91a637c9f5053656c58a0d4c06e713618229e448b6` |
| `tests/test_rw0_d1_offline_integration.py` | M | `33c2d85012cbdf0e7e04fdeb7d333d2c8675ae3f` | 53,132 | `c5997a4e9161253974b04b203bf55754c12b465c3b0b5924247e6c1df8e05c9e` |
| `tests/test_rw0_d1_worker_process.py` | M | `e2a83abe44db720b5ce0725682ac71d30372959d` | 1,737 | `512d7d61083e8ad8c61c197aefc86f70d61a1f7e41273fab435bb493cc08631f` |
| `tests/test_rw0_d2_bound_effect_contracts.py` | C | `absent` | 5,636 | `4c8f04a5f16d0e0b236f8fff636e5d9a5d41c465dad6fc726bd488fb76b59574` |
| `tests/test_rw0_d2_bound_effect_persistence.py` | C | `absent` | 20,950 | `af0e25fe73742b82ce205c420646a18221325c15820a6c3893719eaaeec436f0` |
| `tests/test_rw0_d2_c1_checked_readback.py` | C | `absent` | 17,750 | `20237660028125bacccf52bb695cb275adebefb2ed1f0a28bb271688f7aadb01` |
| `tests/test_rw0_d2_evidence_children.py` | C | `absent` | 3,635 | `fd4cd60a30cb641d34b458f7782bcc27d020a37f47f6523c37cfcf83895d516b` |
| `tests/test_rw0_d2_model_handback.py` | C | `absent` | 4,966 | `89c53206f1b636257ecf5f71027e11ca4ef4cfdd00883e55b2c0fa02fe2a7a6e` |
| `tests/test_rw0_d2_offline_integration.py` | C | `absent` | 51,581 | `e682b402875f7115d210d9c11bf1211f004efc388f8414163e4b42556ab96e36` |
| `tests/test_rw0_d2_process_frames.py` | C | `absent` | 6,894 | `f77f49268e4ed693d049560307aa3794538842efc8afa24e1500664fc4884264` |
| `tests/test_rw0_remote_contact_phase_entry_contract.py` | M | `2a9144c3dfd2c883555703c8adecd21f447d6d34` | 177,317 | `6df3c991a219633d148106396336f2702c323b6cddb82932b41152ea3e5ac16a` |
| `tests/test_sqlite_backend_b0_contract.py` | M | `c646df6d439d0b70f45d6d72200fbedb5e730779` | 26,412 | `1eb038201c19be7e9680f5ee6c4425fb50051b8bc0df31e3feeab06620cc094e` |

## Appendix C. Handoff provenance and review boundary

This handoff was authored from the user-supplied auditor addendum, retained audit
report, prior receipt-reconciliation mandate, and available Coordinator snapshot
guidance. The 70 endpoint rows and Appendix A source are byte-preserved from the
prior mandate; the raw replacement recipe is unchanged. ChatGPT inspected those
materials as inert text and checked artifact consistency. ChatGPT did not inspect
the live checkout, execute the opener, run repository code/tests or independently
reproduce the auditor's implementation results. The local topic-branch commit/no-
publication ceiling and one staged-source FULL run are the new gate directions.

Source coordinates:
- Supplied independent audit report: lines 5, 19–32, 111–131, with GUARDS line 124
  corrected by the subsequently supplied auditor addendum.
- Prior reconciliation mandate: sections A–C and fixed authentication appendices.
- Coordinator snapshot AGENTS.md:3 and 618–628 (.docs authority and change rules);
  current candidate guidance must be read and authenticated before effects.
- Project Codex Subagent Operating Protocol: section 4.5 / lines 265–283 and
  section 15 / lines 739–754 (stage, final validation, one commit, blob comparison;
  separate publication authorization).
- Project Provenance Guidance: sections 5.4 and 9 (exact staged/committed binding,
  no automatic amend/repair after mismatch).
