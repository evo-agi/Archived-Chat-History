Here is Codex's response:

# RW0-D2 V4 independent audit

**Verdict: `RW0_D2_OFFLINE_EVIDENCE_COGNITIVE_REVIEW_ACCEPTED_READY_FOR_COMMIT_GATE`**

I found no blocking candidate defect in the selected offline D2 scope. This verdict makes the authenticated V4 candidate eligible for a **separate commit gate**. It does not authorize a commit, publication, executable effect, live provider or ES route, C1 rank-15 admission, a C2 decision, or Section 41 post-execution persistence. I made no live repository changes.

## Findings and provenance limits

1. **No material contract, security, runtime, or durable-state finding.** The native lifetime boundary, retained A-to-B association, C10 caller boundary, process cleanup, and final suites passed the independent checks below.

2. **Historical procedure limit, nonblocking under the user’s section 0R re-entry.** Before the prospective opener, the prior attempt performed an attachment read, a repository listing, and raw `git status --short && git branch --show-current && git log -1 --oneline`. The listing’s exact shell text and relative order within the parallel call are not retained in the compacted record. Those visible actions were classified as eligible inspections before re-entry; no earlier import, test, repair, or candidate acceptance was reported. Raw status could have refreshed index metadata, and no earlier metadata snapshot exists. The later opening cannot prove that failed interval was preserved. The prior procedural-block result remains in force for that interval. No code repair follows from it.

3. **Historical ref incident remains unresolved.** The earlier V1 interval reported two removed refs at `014f6845ec3672c7a2c2e54f8745e8d2e0505a06` and two additions at `1450a5e4845d20d9199004ea862ebdeadb8139e0`; its writer and cause remain unidentified. I did not attribute that incident to V4 or restore refs. This audit’s own complete ref inventory had **zero** opening-to-close deltas.

The visible execution settings were local Codex, one parent agent, unrestricted filesystem permission profile, approval policy `never`, Python 3.13.4, and pytest 8.4.1. A separate model-effort selector was not visible. No subagent, network request, sibling-repository access, live provider, or live repository code execution was used.

## Exact subject and preservation

| Check | Independent result |
|---|---|
| Branch and baseline | `trunk_dev`; HEAD `43ae26b9bccf9ad6ce61ec4722e14ac7b460ab18`; tree `cc3cc104300f553ada581cee24e80dab6dd885b1`; sole parent `0d0926e3a483a3ab1a4fd597ac0495927352bf35` |
| Index and working endpoints | 263 stage-zero HEAD entries; 47 modified tracked, 23 working creations, 216 other tracked endpoints HEAD-exact; no staged or unmerged entry |
| Candidate receipts | **70/70 matched; no mismatch**. All candidate files were regular nonsymlink OS 0644/Git 100644. The unrelated OS-0600 test file retained its mode and Git 100644 entry. |
| Raw replacement, reconstructed twice at opening and closing | Payload 5,856,685 bytes; encoded rows 5,862,083; complete frame 5,862,108; SHA-256 `9b14b520984e5e6a090482ee473b45a301b762176b94e3acd1ad05f786188efd` |
| Index preservation | Opening and closing byte-and-metadata record matched; SHA-256 `7af425d5a47b91b0a14294660f5d449f5ba6308dc8846a8b13aca371c191a587`, equal to the supplied anchor |
| Source, guidance, cache | All 286 source endpoints and their opening metadata matched at close. `AGENTS.md` and the known cache directory plus 37 members matched the opening records. |
| Refs | 54 complete records at opening, pre-execution, and close; serialization SHA-256 `eef25591b98fe5b402e9e03f13d3755c41fa2c59bf72ca3f2e01f51a46e3e2fb`; 28 protected and 26 qualified diagnostic records; **no old/new delta** |
| Worktree/upstream | One worktree; local `origin/trunk_dev` matched HEAD at divergence 0/0. No fetch was made, so this is not a claim about current remote state. |

The 26 diagnostic refs were confined to the two specified turn-diff capture/checkpoint subtrees. Source, guidance, configuration, and executable selection checks found no dependency on them. The live `.git/config` ctime and mtime both predated the prospective opener; its exact opening bytes were not separately recorded. The previous interval’s missing metadata evidence remains a historical limit.

I read the complete 47-path tracked diff (3,400 lines) and all 23 creations—15 source files, seven tests, and the D2 owner document. Strict UTF-8, terminal-LF, whitespace, mode, SQL catalog, and public-surface checks passed. `.docs/` remained the contract authority throughout.

## Source and authority boundary

[The D2 owner contract](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-d2-offline-evidence-and-review.md:3>) and [offline composition](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d2_offline.py:32>) describe one D1 run, then two fenced checking-effect families, checked C1 evidence, fresh B input, one fake review-model child, and a typed transient handback. The five actual child roles were planner, coding worker, validator, independent reviewer, and fake review model. An observed complete invocation created and reaped all five handles; original `Popen` inputs used absolute Python `-B -m`, `shell=False`, a new session, `close_fds=True`, empty `pass_fds`, the seven-key environment, and exact stdin frames. The observed parent state root and database path were absent from each argv, cwd, environment, and captured stdin frame. The direct supervisor descriptor test also confirmed a deliberately inheritable parent FD was unavailable in its child. This is evidence for the fixed offline, same-UID proof, not arbitrary-host isolation.

The existing Coordinator writer/controller remains the durable owner. The private safe binding is an artificial assertion, not external grant verification. C1 checked membership is readback evidence. The fake model supplies a bounded cognitive recommendation; the [final handback](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d2_handback.py:355>) remains transient and `preadmission_ready` grants no acceptance or runtime authority. The catalog still ends at migration 0004; package-root exports, public `StateStore`, and current coding `global_stop` behavior were preserved.

### A-to-B consuming association

The [B constructor](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d2b_model_input.py:224>) supplies nine roles. The [final consuming check](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d2_handback.py:158>) compares B assertions with these independently retained A owners:

| B role | Supports | Retained A owner and relation |
|---|---:|---|
| `candidate_capsule` | 0 | Full D1 capture/capsule and phase lineage; private canonical manifest and distinct model-safe projection |
| `worker_result` | 0 | Checked rank-14 classification, exact membership and worker/adapter relation |
| `validation_result` | 6 | Validation disposition, observation, requirement, qualification, result set, authority source, support set |
| `independent_review` | 7 | Review disposition and distinct reviewer observation, requirement, qualification, result set, separation, authority, support set |
| `standing_policy` | 4 | Retained attestation, author authority, attempt fence, author effect fence |
| `risk_lane` | 4 | Finite risk source, profile, source binding, and risk-policy attestation |
| `authority_currentness_attestation` | 0 | This A author-role rank-1 checked value and membership |
| `global_stop` | 2 | Retained stop identity joined to B’s separately sampled current stop and profile |
| `effect_ceiling` | 5 | Attempt/effect fences, author authority, policy matrix, and ceiling profile |

The B observation clock and current stop facts retain their B-time meaning; historical validation does not resample them. The association runs whenever a context/supply pair exists, including supported stopped and cleanup results. Ready and stopped donor-B transplants, same-capsule/different-policy evidence, constructor checks, and forged-wrapper `validate()` were exercised. Own-graph and canonically reconstructed equal-value positives remained valid. Substitution caused no additional database or child effect.

The source-derived [reason/reached-facts rule](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d2_handback.py:55>) retained legitimate early stops without B input and rejected impossible late prefixes. The final validator also rechecks nested types, checkpoint roles, and the ready graph at [line 378](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d2_handback.py:378>). The J02 authority-swap specimen is partly masked by the stronger A-to-B join; I credited the direct checkpoint-only specimen and the retained revalidation call, not a separate kill of every overlapping predicate.

### Native lifetime and durable evidence

The [native writer](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_sqlite_development_bound_effect_establishment.py:188>) checks original program/work/selection/C1/author preimages and stop state after writer fencing. Its fresh path requires `binding.expires_at > transaction_now` **and** `attempt.expires_at > transaction_now` at [lines 271–273](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_sqlite_development_bound_effect_establishment.py:271>), consistent with the [B1 strict-currentness contract](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-b1-pure-phase-values.md:182>).

For **each** of `validate_candidate` and `review_candidate`, real fenced SQLite fixtures passed six fresh rows: equal expiries and a narrower binding at one second before, at, and one second after the binding boundary. Before-expiry operations committed the exact six target members—intent, fence, pending authority evaluation, initial delivery, effect head, delivery head—and receipt. At/after operations returned `CURRENT_STATE_CONFLICT`, called no target write, left all target keys absent, and preserved the predecessor’s logical rows. Review’s validation predecessor was established through its real owner. A valid earlier commit replayed at and after expiry as `exact_replay`; fresh-session readback recovery returned `committed_exact`, with original timestamp, rows, and receipt unchanged and no duplicate. The transaction clock is sampled for the operation; this evidence does not assert continuous authority through a later wall-clock COMMIT.

E01 changed both strict comparisons to inclusive. Four at-boundary rejection nodes failed while two before-boundary positives passed; direct probes found an erroneous complete target family and receipt for both effect classes. E02 changed only the binding comparison to inclusive while leaving the attempt strict. Both narrower-binding at-boundary rejections failed, both before positives passed, and both classes persisted the complete erroneous family and receipt. The strict attempt check remains source-verified; the binding-strict check masks an isolated attempt-only omission, so I make no separate E03 causal claim. Receipt-first exact replay, collision refusal, four before/after physical-commit uncertainty cases, read-only recovery, and no duplicate delivery were also exercised.

### Bounded causal controls

Every mutant was built from authenticated V4 bytes in a remote-free copy. Each had 286 source endpoints, exactly one declared changed path, complete relevant collection, and unchanged before/after source manifests. The copy digest grammar was `RW0-D2-INDEPENDENT-AUDIT-SOURCE-V1\0` plus sorted path, Git mode, length, and raw payload. The unmodified digest was `c37155124f5e4eb1ac49834a160e0ef4e7c66d09b4b1bbc0aea6a932e81cc307`.

| Control | Changed-path SHA-256; complete copy SHA-256 | Observed signal |
|---|---|---|
| E01 | `d5012ef7dd383ae39364772d7702364fc0eadde31a1e64997c0a6773d6025245`; `aee47df715811846a1565da69d329372a20f7772fc22fa03fc0436e913900038` | 4 intended expiry negatives failed, 2 positives passed; both erroneous families persisted |
| E02 | `97434b7f8047c7297815f76265244719d7f0d624206d4e89aee5165ad8da91ac`; `3a631b006b9d6a5af782c0554ac288fe22ebcb08ed02b2e28f5001bb558e0e85` | 2 narrow-at negatives failed, 2 positives passed; both erroneous families persisted |
| X01, final A-to-B call omitted | `f6ac72d9b5052111409e4028f0b338563a9e03a8b5c28afbe16b00bd9ff961b8`; `c18e66e28ef212d40fb9fe17327b6b0081a93624dd0bf06ed196d21fcfc8ba80` | Own positive passed; crossed ready and paired stopped/cleanup negatives lost rejection at constructor and explicit consumer |
| X02b, capsule-only join | `ec94e1037c7b1b48f5336057ee490778e828d3c89378abd3f7946dff15892e60`; `e6080392aaf68ffd8bb81a89feca46798b7ad7eedc1fd777ac97cd2bd29507ec` | Own and different-capsule controls passed; same-capsule/noncapsule negative lost rejection |
| R01, reason check omitted | `c71b7634411d1779c05f2db0442f52349f9a79a8bc7ae70f3b006393f1a8b4d7`; `6c15ec654cf58d03442fb83e7cc6b4117282d40e8213564b2447db3dee2d0cc4` | Early positive passed; two late reason-only negatives lost rejection |
| J01, checkpoint role join omitted | `879fa157060b2e1f17cfd6e6e975ff2ce1f7e85b94ba77998e81ee3106d1e2c6`; `41fc182e0c1e9d1cb5c156c3e12f35ee39bfa7716cfb2b06dcdc323285f65c23` | Positive passed; valid same-role alternate-source negative lost rejection |
| J02, final checkpoint call omitted | `4af96e6cc062174cb288355c8197976dff64d234b2989e2f33f411d8aebeded7`; `f8b7fed0a99f6638e25b3a2446f8efc8fd6dbe09d6ccda9eca1e285466afd8db` | Positive passed; direct checkpoint-only inconsistency survived. Stronger A-to-B checks still rejected some authority swaps. |
| C10 state-store edge | `500d36f336a0fb9c7d09eff15d84301ee718240fc4e55004180095c80a453eda`; `98488a6c31de801ce7f36b509739c6052d9c94531d2df8505602ab1e3c58e3b5` | Both original V3G039 malformed/assurance nodes failed |
| C10 predicate disabled | `5b2e865fe42e119a0c93c77ad0ef9052cc50fb9ac14a53472e5bf0faae75bf75`; `984d100c1d0ed8aba34caae1679b1a9ffa4f5eabec655f78f2acf1ce5b1b8335` | Four current caller controls failed; two independent positive/one-sided controls passed |
| A07 link checks omitted | `717e5628e59f87022610b84744f09c310ab8cccddeb4f1c97e889b8d285f93a5`; `e739e18368778a3df09a7c19d42fb89404fe65c0d3b09e5f34675e636d1c7efa` | Outside-owned-sibling hardlink negative lost refusal |
| A09 selector close omitted | `ee9dec0ba3dad6a2c128058c366cc7bf98eda758744de9e476d38c09cc32549d`; `6b9d29fae85c3ef44218df79db6561c53c99da6e03ac106b35b89baaec8f069e` | Three cleanup assertions failed; direct probe retained selector FD 3 until separate audit rescue |
| A10 model ignores input | `804900b21ae9acaedbc3792161aaea735eaf5f04d5459140a577eb1f26aff3dc`; `fd1e7641dfe6df18fc18f025603e9eb137b98f34633faeb8d9b337ba7e1a6e3f` | Actual accept positive passed; repair, replan, terminal, and block cases stopped normalization |

An initial X02 trial retained a noncapsule lineage check and passed all three selected nodes; it received no causal credit. X02b corrected the **audit copy only**. Initial E02 probe, reconstruction-injection, and normal selector-probe scripts also had audit-driver errors or hit an earlier predicate; corrected external drivers supplied the reported observations. These trials did not alter candidate or test bytes.

C10’s exact nine current import pairs were independently fixed in [the primary boundary](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_post_execution_pure_owner_boundaries.py:119>) and [the literal vector](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_post_execution_pure_owner_vectors.py:41>): D2 handback→evidence; D2A evidence→risk/evidence/policy; D2A handback→risk/evidence/policy; B input→evidence; B proposal→evidence. The original 93 malformed and 126 assurance records remained present. The clean primary/vector selection passed 328 nodes; the two bounded C10 mutations produced the intended failures. This supports the exact current caller set and guard successors, without claiming an open-ended import grammar.

## A01–A13 evidence ledger

The named tests below ran in the authenticated external copies. Direct probes inspected real values and rows; mutant failures are credited only at the reached assertion.

| Row | Owner and independent result |
|---|---|
| A01 | [D1 producer](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_offline.py:437>) retained the same worker-invocation-correlated adapter observation through capture/capsule and the D2A rank-12/rank-14 graph. Actual C1 row readback found each selected relationship once. |
| A02 | [Fresh native lifetime](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_sqlite_development_bound_effect_establishment.py:271>) passed both six-case classes and E01/E02 controls. [Fresh B basis](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d2b_model_input.py:44>) accepted a current specimen and rejected equal-expiry and stale-head copies. |
| A03 | [Closed command/safe-binding values](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_bound_effect_establishment_contracts.py:222>) retained distinct command/result identities. Independently resealed altered binding, after-blob descriptor, and bool-as-int stop-version commands were rejected; a valid resealed mutation-ref reuse returned `mutation_ref_reuse_conflict`. |
| A04 | [Receipt-first writer/readback](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_sqlite_development_bound_effect_establishment.py:292>) and [single transaction controller](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_transition_transaction.py:1616>) produced exact six-member-plus-receipt families. The 23 selected native nodes passed, including four commit-uncertainty variants, replay/recovery, exact row/column comparisons, no-write expiry cases, and no duplicate. |
| A05 | [D2A admission/check](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d2a_offline.py:212>) read back 14 checked C1 **families**, ranks `1×3, 5×1, 6×2, 12×6, 13×1, 14×1`; no rank 15. Direct SQLite checks found the selected phase, registry, payload, child, membership, relation, operand, and receipt occurrences. Qualification was present before its respective child launch. These occurrence checks are not a claim of 14 total physical SQL rows. |
| A06 | [Separate checking launches](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d2a_offline.py:282>) used distinct reconstructed workspaces, effects, requirements, result sets, and source records. Real failed/inconclusive evidence, omission, swapped-binding, and reviewer-separation controls passed; finite text checks do not compile candidate code. |
| A07 | [Reconstruction verification](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d2a_workspace.py:24>) checked the exact three-file inventory, capture/capsule relation, modes, and no-follow/link rules before checking readiness. A corrected post-D1 extra-path injection rejected before D2 child launch; the hardlink omission control lost its intended refusal. |
| A08 | [Supervisor launch](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py:145>) and [D2 composition](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d2_offline.py:32>) were observed through actual five `Popen` handles and byte-for-byte stdin frames. Each returned/reaped with code zero on the complete path; guarded sessions close before dependent launches. Bounded frame and parent-path/FD controls passed. |
| A09 | [Supervisor cleanup](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py:255>) preserved exit, reap, group, stream, selector, timeout, cancellation, and unresolved-cleanup facts. The selector omission had a real live FD after return and failed three permanent assertions; audit rescue closed that FD separately. |
| A10 | [Nine-role B construction](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d2b_model_input.py:240>) used the fresh owner snapshot and support counts `(0,0,6,7,4,4,0,2,5)`. Five recommendations arose from actual candidate/policy evidence. The ignored-input model mutant failed the four changed outcomes at normalization; accept remained a positive. |
| A11 | [Artifact and projection](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d2b_proposal.py:93>) had independently recomputed canonical identity digests on accept and repair runs, including a finding bound to `independent_review`. The child response, source invocation, nine bindings/set, proposal, and V09 relation were checked without Section 41 post-execution insertion. |
| A12 | [Reason, A-to-B, nested and final consumers](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d2_handback.py:55>) passed own-graph, forged-wrapper, crossed-ready/stopped/cleanup, same-capsule, equivalent-value, custody, and X/R/J checks above. The [run owner](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d2_handback.py:534>) retained explicit same-process D1 disposal; validation substitutions caused no additional DB or child activity. |
| A13 | [Current boundary tests](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_post_execution_pure_owner_boundaries.py:119>) and vector controls passed, including B1/Wire and public/authority successors. `state_store.py`, package exports, the SQL catalog/resources, and the no-rank15/no-post-execution-writer cut remained within their documented scope. |

## Final validation and cleanup

The final copy was built **after** all diagnostic and earlier normal trials. It was a local `--no-hardlinks` clone at the fixed HEAD with exact working-source overlays, zero remotes, no copied live cache, and no source drift. The unmodified source-copy digest above matched before and after every final group. The earlier complete normal run also passed; it is corroboration, not the operative final gate. One prebuilt `final_verified` copy was never executed.

The installed interpreter was `/Library/Frameworks/Python.framework/Versions/3.13/bin/python3` (3.13.4), pytest 8.4.1. The serial driver invoked `python3 -B -m pytest -q -p no:cacheprovider` with owned `--basetemp`, first `--collect-only` and then `--junitxml` for each supplied group path set; FULL had **no path selector**. Environment was `PYTHONDONTWRITEBYTECODE=1`, `PYTHONPATH=.:src`, owned `TMPDIR`, and umask 022. No xdist, install, skip, xfail, or warning suppression was used.

| Final group | Modules / collected and passed | Fixed module SHA-256 | Reproduced node SHA-256 |
|---|---:|---|---|
| A0_D1 | 7 / 117 | `bd79dcd6261a545b90e3709e7bff2b16fa00d9fb71f67baa4082f71de6b75236` | `8ba8dc88ab588e3e12d56d8c3db542b08f04ddb1d1714a4e687e62697ab849ad` |
| BINDING_COMPAT | 7 / 160 | `0851123786b9bcbab0f2f417539ec3d1a0e6ffc753c4075e3d33b15e27dccd30` | `fddc0c493b032ecac479c59e6480a1f58c52759b8133f829795f6a82d8856806` |
| A_NATIVE | 11 / 132 | `1d59cdd9b2eb38fda5506dd2c7fb941d5a8f9458cf192798c0e029f47385028f` | `ea80c0671804f63da9e349cfc9a0b8f532e0a25aa5fe1b1c8787f1db7fbcbf82` |
| A_EVIDENCE | 5 / 659 | `d74195c30fd2f5c9e56591b2365651836ec7c982d0c1fe96da3f1fc26850b1ba` | `8c27f90a27da2fe62242f3bf3c368b2ce5792e102354c685bc8d99e1e19c35f2` |
| B_MODEL | 8 / 218 | `d00d48fcba4bf4f95bc359c59c57233dc770eafe51957ca40068a46c2c685147` | `9e5dd25ed281aab9958cb52db24833fd3264ae2f5419cfb61ddcb09d956033a5` |
| GUARDS | 24 / 4,162 | `4533bd1c1f6ee61c1e96847b3d6ce684af46046304ae9a6df28348eaace2b617` | `547c990afa2ac226f2316e0d3c276b6709afa0c4deb20493a1e3db2230b9260b` |
| FULL | 131 / 9,098 | `3c0ebcd7195ebfb0f483820c25a2f94f613ba42c67e7f714df90873f52ad1061` | `13298265ca6c9c023008e6051719065b3e9c78e1c2524413f9f7035090cfcbaf` |

Every final JUnit recorded zero failures, errors, and skips. The six focused groups contained 5,448 occurrences and 5,446 distinct IDs; FULL included that union plus 3,652 IDs. Only GUARDS and FULL each reported three `DeprecationWarning`s, at the unchanged `test_sqlite_b2c_writer_session.py` nodes `test_operation_guard_close_waits_and_retains_authority_until_exit`, `test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang`, and `test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock`. Their locations were Python’s `multiprocessing/popen_fork.py:67` and test lines 1442 and 1554; no other warning was observed.

After all child/test wrappers exited, I classified the single audit-owned external root using `lstat`: 22,051 nested directories, 76,687 regular files, 1,613 symlinks, and 14 test-created FIFOs. The FIFOs and symlinks were not opened or followed for inventory. The five instrumented production-path fake child handles were reaped; the selector mutant’s FD was separately rescued. The root and all its copies, fixtures, logs, helper, and opening/closing records were then removed; removal was verified. **No audit artifact survives at that path.**

The continuation subject is exactly the 70-receipt V4 working candidate at the stated HEAD. Its remaining gate is a separately governed commit/publication decision. No runtime, external standing authority, deployment, Bridge/ES routing, migration 0005, Section 41 post-execution writer, physical C2 decision, or RW0-E behavior is inferred from this offline evidence.
