## Disposition

**Accept the V2 re-audit block. Repair only the new provisioning checker/test module; keep all five candidate documents unchanged. Do not stage or commit.**

The re-audit confirms that the three earlier P1/P2 defects were repaired:

- disclosure denial now prevents protected receipt, family, and alias reads;
- independently authored A, B, and C source subjects are bound to their own act, lineage, enrollment, incarnation, and custody coordinates;
- malformed observed families remain inside the closed apply/readback result grammar rather than leaking `KeyError`. Pasted text

The remaining two Medium-severity findings are real checker-evidence defects. They do not require another contract or architecture tranche.

## Engineering adjudication

### 1. Exact built-in typing must precede canonical equality

The owning value contract requires exact built-in types, including no Boolean-as-integer coercion. The checker nevertheless accepts a `str` subclass in a command `schema_id`, and it accepts a `str` subclass in a stored receipt’s `outcome` as if it were a complete exact family. Matching string content and digest cannot erase that type distinction. Pasted text

The repair should introduce one small checker-local exact-type path used consistently for:

```text
command validation
act/fact/basis/result/receipt validation
observed-family shape validation
complete-family replay validation
readback classification
```

The relevant rule is:

```python
type(value) is str
type(value) is int
type(value) is bool
```

according to the actual closed field grammar—not `isinstance`.

Permanent hostile specimens should cover at least:

- a `str` subclass in command `schema_id`;
- a `str` subclass in command `guard_profile`;
- a `str` subclass in an observed receipt `outcome`;
- a subclass in a nested observed act, fact, basis, or result field.

The first two must fail as structural `invalid_input` before source evaluation or protected reads. Stored malformed values must remain no-write `family_unverifiable` on apply and `unresolved` on readback.

### 2. Structural profile shape and source authority are different gates

The second finding exposes a useful distinction.

The adopted field grammar defines both `guard_profile` and `applicability` as exact nonempty strings. `guard_profile` is part of the source-authored admission binding. The current guard owner separately fixes the only supported applicability for this profile to:

```text
admitted_direct_local_bootstrap
```

The current checker hard-codes both too early, causing resealed candidate-owned mismatches to return generic `invalid_input` before the independent source relation is tested. Pasted text

The corrected sequence should be:

```text
exact built-in/nonempty structural validation
→ independent source and owner relation
→ disclosure gate
→ protected store reads
```

For `guard_profile`, a different exact nonempty string is structurally well formed but must fail because it does not match the independently authored verified source.

For `applicability`, another exact nonempty string is also structurally well formed at the generic value layer, but is **semantically unsupported** because the current guard owner fixes direct-local applicability. It should fail at the source/owner applicability boundary, not be described as authorized and not be rejected merely as the wrong Python type.

Neither repair broadens supported profiles or applicability values.

### Required evidence

The repaired checker should demonstrate:

| Specimen | Required boundary |
|---|---|
| `str` subclass in command field | Structural `invalid_input`; no source/store access |
| `str` subclass in stored receipt outcome | No exact replay or committed recovery |
| Resealed foreign `guard_profile`, source A fixed | Source/profile refusal before protected reads |
| Resealed foreign applicability, source A fixed | Source/owner refusal before protected reads |
| Independently valid A, B, and C sources | Continue to succeed under the selected profile and applicability |
| Renewed evidence for the same stable subject | Does not change historical family or relax profile/applicability binding |

This keeps the source relation independently authored rather than deriving expected values from the submitted command.

## What remains fixed

The five documents should not change. The audit found no authority or contract defect requiring an amendment. It also confirmed that:

- the final six-file provenance and `83,215`-byte patch reproduce;
- all required suites pass;
- all noncandidate paths and the live cache remain unchanged;
- the prior disclosure, source-binding, and malformed-orphan fixes work as intended. Pasted text Pasted text

The current validation baseline is:

```text
Provisioning checker:     27 passed
Owning/composition group: 3,208 passed
Complete repository:      8,785 passed, 3 existing warnings
```

The pending-operation interval remains audit-oracle evidence rather than a concurrency proof. That limitation should stay explicit; it does not justify building a scheduler or transaction simulator. Pasted text

## Codex handoff

Resume the **same implementation Codex conversation**, keep the parent as the sole writer, and use the exact V2 candidate as the opening state.

:chatgpt-content-reference{index="6"}[Download the V3 checker-repair prompt](sandbox:/mnt/data/Coordinator_RW0_C2_Scope_Admission_Provisioning_Checker_Repair_V3_Prompt.txt)

```text
Filename:
Coordinator_RW0_C2_Scope_Admission_Provisioning_Checker_Repair_V3_Prompt.txt

Bytes:
20,933

SHA-256:
ef1191eba9a514b992b1e9e7a6b71418b85f34915740a4cb17bd8badd0efcd50

Logical lines:
554

Final newline:
present
```

The prompt binds the exact opening candidate:

```text
HEAD:
630414faa07f4ac39c4a870a9cc44c7f92d46b80

Tree:
cd81f7cca8b64cb9ff221537257e70e2c5a655a3

Opening verifier:
51,303 bytes
1c50db7048a7f4e40a942a65c3e0fb92840ca7b3457be48977311b37dcff5667

Opening six-path patch:
83,215 bytes
c87d6fc097a4f3d462edb37782fabb5989e6654bb7775b85f0f385303dccef10
```

The only permitted changed file is:

```text
tests/test_rw0_c2_scope_admission_provisioning_contract.py
```

It requires:

- exact built-in validation at command and observed-family boundaries;
- hostile subclass specimens that retain matching text and digests;
- semantic source joining for `guard_profile`;
- explicit owner-literal enforcement for applicability;
- content-free refusal before protected reads for both mismatches;
- preservation of independently valid A/B/C subjects;
- four targeted transformed copies;
- serial external validation and exact five-document/source/migration/cache preservation.

Success token:

```text
RW0_C2_SCOPE_ADMISSION_PROVISIONING_CHECKER_REPAIRED_V3_READY_FOR_INDEPENDENT_AUDIT
```

Blocking token:

```text
RW0_C2_SCOPE_ADMISSION_PROVISIONING_CHECKER_V3_REPAIR_BLOCKED
```

A successful result authorizes only another fresh independent read-only re-audit. It does not authorize publication, source implementation, migration `0005`, supplier qualification, runtime provisioning, enrollment, deployment, RW0-D implementation, or RW0-E execution.

Some older project uploads have expired, but none is needed for this repair. Re-upload an older original only if a later task requires its exact bytes.

**Source:** Fresh V2 independent re-audit attached in this turn.  
**Confidence:** High on the audit block and checker-only repair boundary. High that exact-type enforcement and moving profile/applicability equality into the semantic source-owner relation are the narrowest sufficient fixes.
