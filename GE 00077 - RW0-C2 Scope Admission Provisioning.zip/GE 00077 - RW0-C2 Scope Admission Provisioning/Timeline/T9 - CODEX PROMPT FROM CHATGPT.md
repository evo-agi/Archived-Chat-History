# Governed Execution Coordinator — Scope-Admission Provisioning: V3 Checker Repair

## Mandate

Resume the implementation conversation that owns the uncommitted six-path
scope-admission provisioning candidate.

Repair only the new synthetic checker/test module after the fresh V2 independent
re-audit returned:

`RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_AUDIT_BLOCKED`

The V2 re-audit established exact provenance, independently reproduced the
three earlier repairs, and passed the required 27 / 3,208 / 8,785 test groups.
It found two remaining Medium-severity checker-evidence defects:

1. exact built-in types are not enforced before canonical equality/digest
   checks; a `str` subclass can record at command entry and can be accepted in
   an observed receipt as exact replay / committed recovery;
2. candidate-owned `guard_profile` equality is not proven against the
   independently authored source because command validation hard-codes profile
   and applicability before the source relation is reached.

There is a narrow applicability clarification:

- the adopted value grammar gives `applicability` the structural type
  `nonempty_exact_str`;
- the current guard owner fixes the supported direct-local semantic value to
  `admitted_direct_local_bootstrap`;
- therefore another nonempty string is structurally well formed but is not
  authorized under this support profile;
- it must fail at the semantic source/owner applicability boundary, not be
  mistaken for valid authority and not be rejected merely as a wrong Python
  type.

The owning documentation already requires exact built-in types, source-authored
guard-profile verification, and the fixed direct-local applicability. Do not
modify any document.

The parent is the sole writer. No subagents. Use the highest exposed reasoning
setting and record visible model, reasoning effort, and permission posture, or
`not visible`. Do not seek additional account/computer access to expose hidden
settings.

Return one substantive inline closeout and a continuation capsule no longer
than 800 words. Do not deliver a report, manifest, receipt, patch, snapshot, or
package. Disposable external validation material is permitted and must be
removed. Do not issue a subsequent implementation prompt.

## 1. Exact committed baseline

Repository:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed coordinates:

- branch: `trunk_dev`
- HEAD: `630414faa07f4ac39c4a870a9cc44c7f92d46b80`
- tree: `cd81f7cca8b64cb9ff221537257e70e2c5a655a3`
- sole parent: `d070bf05d2e68472e18b1b077259e67864923e8f`
- subject: `docs: freeze RW0-C2 first-live proof posture`
- upstream: `origin/trunk_dev`
- locally observed divergence: `0 ahead / 0 behind`
- exactly one live worktree
- index matches HEAD
- zero staged or unmerged paths
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or unexpected
  lock.

Read `AGENTS.md` first. Use non-mutating Git inspection with optional locks
suppressed where appropriate. Do not fetch, normalize, change configuration,
discard another actor's work, or treat tracking-ref equality as fresh remote
truth.

Stop before editing on any baseline, path-set, index, endpoint, type, mode,
byte, or patch mismatch.

## 2. Exact opening repaired candidate

Require exactly four tracked documentation modifications and two untracked
additions.

All six endpoints must be regular, nonsymlink, OS mode `0644`, strict UTF-8,
one final LF, no BOM, no CR, and no trailing whitespace. The four tracked Git
entries remain mode `100644`; both new paths remain absent from HEAD and index.

| Status | Repository-relative path | Bytes | SHA-256 | HEAD blob |
|---|---|---:|---|---|
| `M` | `.docs/autonomous-software-development-operating-model.md` | 39,708 | `ccca078da9da0eca90d6e0f86bb30dbda9960765276e7737d4af8b66cc9197a1` | `9207ff698920682dc25057a9fc12b9f2a8cb28d7` |
| `M` | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 26,041 | `0ebe519379a689f87a2f6ddabeeede5f96d1c5d4ec8f90373f555f38fc61ca44` | `b737b4feff254e2da5d04151575acfbd06f201f3` |
| `M` | `.docs/rw0-c2-first-live-proof-posture.md` | 15,857 | `ab0c7a57b5807207203c5c31a4ba00b671a4e898264c4e9c1119d3517d959ce3` | `d88c3a6a0ec032e460cbd68c97dfe5b915a0514d` |
| `M` | `.docs/rw0-c2-private-value-versioning.md` | 207,681 | `966a1f5ac158ad6e597aa7922328612d0993e6e8c109f766aedd9ac7cc8bd251` | `54f84052d97d927e8ccc874b39b1fe8aa8596cff` |
| `??` | `.docs/rw0-c2-scope-admission-provisioning-contract.md` | 23,631 | `9af662213b3a9fe51a0c2f12449e46a3a1ea9d3172ac7e3d99ce7ce9fd509449` | absent |
| `??` | `tests/test_rw0_c2_scope_admission_provisioning_contract.py` | 51,303 | `1c50db7048a7f4e40a942a65c3e0fb92840ca7b3457be48977311b37dcff5667` | absent |

The opening test module is the independently audited V2 endpoint. Historical
earlier checker bytes are not required.

### Exact opening patch

Visit the six paths in table order.

Tracked paths:

```sh
git diff --binary --full-index --no-ext-diff --no-textconv HEAD -- PATH
```

New paths:

```sh
git diff --no-index --binary --full-index --no-ext-diff --no-textconv -- /dev/null PATH
```

Concatenate exact stdout without separators. Exit status `1` for the two
no-index commands is expected.

Required component lengths:

```text
1,435 / 1,230 / 1,425 / 2,162 / 24,271 / 52,692
```

Required opening patch:

```text
83,215 bytes
SHA-256:
c87d6fc097a4f3d462edb37782fabb5989e6654bb7775b85f0f385303dccef10
```

Reconstruct twice from fresh reads. Do not use external diff helpers or text
conversion. No canonical manifest is required.

## 3. One-file mutation ceiling

Only this file may change:

`tests/test_rw0_c2_scope_admission_provisioning_contract.py`

The five candidate documents must remain byte-identical to the table above.

Every noncandidate tracked path must remain byte-identical to HEAD with unchanged
Git-relevant mode. Do not modify:

- any documentation;
- `AGENTS.md` or `README.md`;
- existing tracked tests;
- product source;
- schemas;
- migrations;
- SQL;
- scripts;
- configuration;
- package exports.

The private-value machine block and its existing verifier/parser remain exact.
Migration resources remain `0001`–`0004`; `0005` remains absent.

No staging, commit, push, PR, merge, branch switch, reset, rebase, network,
installation, credential, supplier, enrollment, launch, fencing, live
provisioning, worker, ES, Bridge, RW0-D/E, sibling-repository, or subagent
effect.

Test-local helpers and fixtures may be refactored only to enforce the already
selected contract.

## 4. Re-grounding

Read both new candidate files fully and compare the four tracked document edits
to HEAD.

Inspect the actual final V2 checker, especially:

- closed command/value validation;
- canonical encoding/digest helpers;
- act/fact/basis/result/receipt validators;
- observed-family shape and complete-binding validators;
- source/enrollment/custody relation;
- `_entry`, `_apply`, `_readback`, alias and replay paths;
- the V2 disclosure, A/B/C source, malformed-orphan, and transformed-copy tests.

Consult the owning documents at their current sections:

- `.docs/rw0-c2-scope-admission-provisioning-contract.md`
- `.docs/rw0-c2-private-value-versioning.md`
- `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md`
- `.docs/rw0-c2-first-live-proof-posture.md`
- `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
- current writer-session/recovery owner sections as compatibility evidence.

Before editing, record a compact diagnosis and one-file plan. Resolve ordinary
helper/test design without asking the user.

Preserve every V2 repair:

- disclosure gates protected reads;
- recording-only permission cannot reveal receipt/family state;
- read-only exact replay/readback remains distinct from fresh recording;
- A/B/C source subjects are independently authored;
- foreign source relations fail before protected reads or family construction;
- malformed observed members stay inside closed apply/readback outcomes;
- different complete provisioning winner remains fresh conflict and original
  recovery `unresolved`;
- late-writer exclusion remains necessary for definite noncommit;
- same-process local session renewal remains distinct from forbidden process or
  supervisor restart.

## 5. Finding 1 — exact built-in types

### Contract rule

The owning private-value contract defines canonicalization with:

`exact_builtin_no_bool_as_int`

The provisioning owner requires exact built-in fields before digest/equality
comparison.

Canonical text equality or a matching SHA-256 is not enough: Python subclasses
of `str`, `int`, `bool`, `dict`, `list`, or other built-ins must not be accepted
where the grammar requires the exact built-in type.

### Validation architecture

Create or refine one small checker-local exact-type validator used consistently
by:

- command-local validation before source/disclosure/store access;
- supplied act/fact/basis/result/receipt validation;
- observed-family shape validation;
- complete-family replay validation;
- readback classification.

Use exact checks such as `type(value) is str`, `type(value) is int`, and exact
container types according to the actual closed schema.

Do not use `isinstance` for canonical fields.

Preserve:

- Boolean fields as exact `bool`;
- integer fields as exact `int` and never `bool`;
- lower-case SHA-256 syntax after exact-string validation;
- nonempty-string rules after exact-string validation;
- exact unknown-key and duplicate-key rejection;
- array ordering and exact container shape.

Do not overgeneralize this into a production schema framework.

### Required direct hostile specimens

Define local subclasses for testing, for example a `str` subclass and, where
relevant, an `int`/container subclass.

At minimum prove:

1. a `str` subclass in command `schema_id` is rejected as `invalid_input`
   before source join, protected reads, family construction, or write;
2. a `str` subclass in another command field such as `guard_profile` is likewise
   rejected structurally;
3. a `str` subclass in an observed receipt's `outcome` cannot produce
   `exact_replay` or `committed_exact`;
4. a subclass in a nested observed act/fact/basis/result field cannot be credited
   as a complete family;
5. exact built-in values with identical text continue to work;
6. the existing bool-as-int and malformed-type controls remain intact.

Matching canonical text/digests must not sanitize or collapse the hostile value
before type validation. Preserve the actual subclass through the checker entry
or observed-family path until the exact-type boundary is exercised.

For malformed observed stored values:

- `_apply` remains no-write and returns the existing
  `family_unverifiable` category;
- `_readback` returns `unresolved`;
- no raw exception or member detail escapes.

## 6. Finding 2 — candidate-owned profile and applicability relation

### Separate structural shape from semantic authority

Command-local validation should enforce that `guard_profile` and
`applicability` are exact, nonempty built-in strings.

It must not treat equality to the expected source/profile subjects as a Python
shape rule.

The source/authority relation must then prove:

- command, verified act, immutable fact, and independent source observation have
  the same `guard_profile`;
- command, act, fact, and source observation have the same `applicability`;
- the applicability equals the currently selected guard-owner literal:
  `admitted_direct_local_bootstrap`.

This keeps three distinctions explicit:

1. wrong Python type or empty string → `invalid_input`;
2. structurally valid but source/profile-mismatched value →
   content-free source/recording-authority refusal before protected reads;
3. exact independently verified supported value → continue.

Do not introduce support for a new guard profile or applicability. Do not change
the owner documents.

### Guard-profile specimen

Hold an independently authored source A fixed.

Create candidate-owned act, fact, and command values with:

- a different nonempty exact-string `guard_profile`;
- all candidate-controlled digests correctly resealed;
- otherwise valid lineage, scope, applicability, audience, enrollment,
  incarnation, and custody coordinates.

Require the specimen to pass structural type/shape validation, reach the
independent source/profile relation, and fail there before protected store
access or family construction.

It must not fail merely because command validation hard-coded one profile
literal.

The result should use the existing content-free source/recording-authority
refusal taxonomy; do not add a new durable event or receipt.

### Applicability specimen and clarification

The current guard owner fixes this support profile's applicability to:

`admitted_direct_local_bootstrap`

Create candidate-owned act, fact, and command values with another nonempty
exact-string applicability and fully resealed candidate digests while keeping
source A fixed.

This specimen is:

- structurally well formed under the generic exact-string field grammar;
- semantically unsupported by the current guard owner;
- not valid recording authority.

Require it to reach the semantic source/owner applicability check and fail
content-free before protected reads or family construction.

Do not describe the foreign applicability as authorized, and do not create a
positive fixture for it.

### Positive behavior

Preserve at least three distinct positive A/B/C subjects under the selected
guard profile and exact direct-local applicability. Different opaque lineage,
scope, enrollment, incarnation, custody, and evidence identifiers remain
supported.

Renewed evidence for the same stable subjects may change current evidence
coordinates without changing the original historical family.

## 7. Immediate interactions

Add only bounded compositions needed to prove the two repairs:

1. command `schema_id` is a `str` subclass while an exact stored family exists:
   reject structurally before protected disclosure/store access;
2. observed receipt `outcome` is a `str` subclass with otherwise matching
   command/digests:
   no exact replay or committed recovery;
3. foreign guard profile under valid disclosure and an exact existing family:
   source/profile refusal occurs before protected reads;
4. foreign applicability under valid disclosure and an exact existing family:
   source/owner refusal occurs before protected reads;
5. renewed evidence for original subjects followed by a foreign profile or
   applicability request:
   renewal does not relax stable source/owner binding.

Keep expectations outside the helper path being checked.

Do not add a general field-fuzz engine, schema library, prose parser, or huge
mutation matrix.

## 8. Transformed-copy evidence

Create a small set of disposable transformed copies of the exact final checker.

At minimum:

1. relax command exact-type validation from `type(x) is str` to
   `isinstance(x, str)`;
2. relax observed-family exact-type validation so a receipt `outcome` subclass
   is credited;
3. move `guard_profile` equality back into hard-coded command validation and
   bypass the independent source-profile join;
4. bypass the fixed applicability/source relation while keeping structural
   string validation.

Each transformed copy must:

- parse and import;
- collect the selected permanent regression normally;
- fail semantically at the intended boundary;
- receive no credit for syntax/import/collection failure.

Report permanent tests, direct hostile specimens, transformed copies, and any
audit-side oracle evidence separately.

The mutable checker cannot authenticate arbitrary coordinated changes to itself
and all expectations. Exact-byte independent re-audit owns that boundary.

## 9. Validation

All executable work must occur in a fresh local-only external clone of exact
HEAD overlaid with the six candidate files. Remove its configured remote. Do not
import, test, compile, or open databases from the live checkout.

Create a task-owned external root mode `0700`. Test processes use normal
`umask 022`. Precreate distinct basetemp parents. Run collection then execution
serially:

```sh
set -euo pipefail
umask 022
mkdir -p "$REPAIR_ROOT/basetemps"

run_group() {
  local label="$1"
  shift
  PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src \
    python3 -m pytest -q -p no:cacheprovider \
    --basetemp="$REPAIR_ROOT/basetemps/${label}-collect" \
    --collect-only "$@"
  PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src \
    python3 -m pytest -q -p no:cacheprovider \
    --basetemp="$REPAIR_ROOT/basetemps/${label}-run" \
    "$@"
}

run_group provisioning \
  tests/test_rw0_c2_scope_admission_provisioning_contract.py

run_group owning_contracts \
  tests/test_rw0_c2_first_live_proof_posture_contract.py \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py \
  tests/test_rw0_c2_private_value_versioning_contract.py \
  tests/test_rw0_c2_durable_progression_decision_semantic_contract.py \
  tests/test_rw0_remote_contact_phase_entry_contract.py \
  tests/test_architecture_contracts.py \
  tests/test_autonomous_software_development_operating_model.py \
  tests/test_c2b0_durable_state_contract.py \
  tests/test_sqlite_backend_b0_contract.py \
  tests/test_b2a_writer_session_contract.py

run_group full
```

Opening references:

- provisioning module: `27`
- owning/composition group: `3,208`
- full repository: `8,785`
- merged repository baseline excluding the provisioning module: `8,758`
- three known Python 3.13 multithreaded-fork warnings.

The repaired module may add bounded tests; do not force a count. Reconcile:

- actual unique node IDs;
- A/B disjointness;
- A/B inclusion in C;
- full count = `8,758 + final provisioning-module count`;
- actual structured warning records.

No warning suppression, test removal, parallel execution, xdist, or overlapping
runs.

After final edits, rebuild the external clone from the final candidate and run
all required groups again. No late edit may inherit an earlier full-suite
result.

Run:

- `git diff --check`;
- both new-file no-index whitespace checks;
- strict UTF-8/BOM/CR/trailing-whitespace/final-LF checks;
- candidate type/mode/path checks;
- five-document byte preservation;
- all 240 noncandidate tracked paths against HEAD;
- source/schema/migration/catalog preservation;
- migration `0005` absence;
- before/after clone endpoint equality.

Before executable work, inventory only the known live `__pycache__` as opaque
metadata and hashes. The current observed inventory is 37 regular bytecode files
plus the directory. Require exact opening/closing equality.

External artifact scans use `lstat`; hash only regular files; never follow
symlinks or open FIFOs/sockets/devices. Remove only the task-owned external root
after all processes finish.

## 10. Closeout

Opening and closing committed coordinates must match. Final index still matches
HEAD. Exactly four modified docs and two untracked files remain. Only the new
test file differs from the opening table.

Recompute all six endpoint receipts twice. Report:

- path;
- status;
- regular-file mode;
- size;
- SHA-256;
- HEAD blob.

Recompute the final six-path patch twice using the same ordered full-index recipe
from section 2. Report component lengths, total length, and SHA-256.

The closeout must include:

1. verdict and visible settings;
2. opening/closing coordinates and one-file transition;
3. all six endpoint receipts and final patch;
4. exact-type validator scope and hostile subclass outcomes;
5. command versus observed-family type behavior;
6. guard-profile structural/source relation and reached boundary;
7. applicability structural/owner relation and reached boundary;
8. A/B/C positive preservation and renewed-evidence behavior;
9. permanent tests, direct hostile specimens, transformed copies, and evidence
   limits;
10. exact validation commands/counts/warnings, preliminary errors, rebuilds,
    skipped work, and cleanup;
11. five-document, noncandidate, source, migration, and cache preservation;
12. remaining supplier/physical/runtime gates and continuation capsule.

Stop rather than widen if exact built-in enforcement or the semantic profile
relation conflicts with an owning document, requires documentation changes,
requires production source/SQL/migration, or changes the adopted act/fact
canonical meanings.

Success:

`RW0_C2_SCOPE_ADMISSION_PROVISIONING_CHECKER_REPAIRED_V3_READY_FOR_INDEPENDENT_AUDIT`

Blocked:

`RW0_C2_SCOPE_ADMISSION_PROVISIONING_CHECKER_V3_REPAIR_BLOCKED`

Success authorizes only a fresh provenance-bound independent read-only re-audit.
It authorizes no staging, commit, publication, source/migration work, supplier
qualification, runtime provisioning, enrollment, launch, recovery runtime,
deployment, RW0-D implementation, or RW0-E execution.

State actual non-actions and temporary external validation effects truthfully.
