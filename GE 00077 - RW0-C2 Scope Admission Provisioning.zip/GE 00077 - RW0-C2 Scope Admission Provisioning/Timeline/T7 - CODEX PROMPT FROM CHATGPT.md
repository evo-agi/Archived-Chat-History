# Governed Execution Coordinator — Scope-Admission Provisioning V2 Checker: Independent Re-audit

## Objective and authority

Perform one fresh, parent-only, repository-first, READ-ONLY independent re-audit
of the exact uncommitted six-path scope-admission provisioning candidate after
the one-file V2 checker repair.

The prior independent audit returned:

`RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_AUDIT_BLOCKED`

It reproduced exact provenance and all required regression suites, but found
three bounded defects in the new synthetic checker:

1. protected receipt/family information was inspected before current disclosure
   permission, allowing receipt-derived conflict/corruption classes to escape;
2. a Boolean/suffix-based synthetic source premise did not bind the verified act
   and lineage to the independent enrollment/incarnation/custody subjects;
3. receipt-absent readback could index a malformed orphan before validating its
   shape, raising `KeyError` instead of returning `unresolved`.

The repair closeout reports:

`RW0_C2_SCOPE_ADMISSION_PROVISIONING_CHECKER_REPAIRED_V2_READY_FOR_INDEPENDENT_AUDIT`

That closeout is evidence to verify, not acceptance.

Do not repair, stage, commit, publish, implement, qualify a supplier, or perform
any live provisioning or custody work. Return one substantive INLINE report with
repository-relative `path:line` evidence and a continuation capsule of at most
800 words. Do not create or attach a report, manifest, receipt, patch, snapshot,
or evidence package.

Use the highest exposed reasoning setting. Record the visible model, reasoning
setting/effort, and permission posture, or `not visible`. Do not seek additional
account or computer access merely to reveal hidden settings. No subagents or
other model/worker invocation.

## 1. Exact committed baseline

Repository:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required opening coordinates:

- branch: `trunk_dev`
- HEAD: `630414faa07f4ac39c4a870a9cc44c7f92d46b80`
- tree: `cd81f7cca8b64cb9ff221537257e70e2c5a655a3`
- sole parent: `d070bf05d2e68472e18b1b077259e67864923e8f`
- subject: `docs: freeze RW0-C2 first-live proof posture`
- upstream: `origin/trunk_dev`
- locally observed divergence: `0 ahead / 0 behind`
- exactly one live worktree
- index matches HEAD
- no staged or unmerged paths
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or unexpected
  Git lock.

Read `AGENTS.md` first. Use non-mutating Git inspection with optional-lock
suppression where appropriate. Do not fetch, refresh, normalize, clean, or
repair the live checkout. Local tracking equality is not fresh remote truth.

Any baseline, path-set, classification, file-type, mode, byte-size, SHA-256, or
patch mismatch requires:

`AUDIT_PROVENANCE_MISMATCH`

Stop before semantic acceptance.

## 2. Exact repaired six-path candidate

Require exactly four tracked documentation modifications and two untracked
additions, with no other tracked or untracked difference from HEAD.

All six endpoints must be regular, nonsymlink, OS mode `0644`, strict UTF-8,
exactly one final LF, no BOM, no CR, and no trailing whitespace. The four
tracked Git entries remain mode `100644`. Both additions are absent from HEAD
and the opening index.

| Status | Repository-relative path | Bytes | SHA-256 | HEAD blob OID |
|---|---|---:|---|---|
| `M` | `.docs/autonomous-software-development-operating-model.md` | 39,708 | `ccca078da9da0eca90d6e0f86bb30dbda9960765276e7737d4af8b66cc9197a1` | `9207ff698920682dc25057a9fc12b9f2a8cb28d7` |
| `M` | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 26,041 | `0ebe519379a689f87a2f6ddabeeede5f96d1c5d4ec8f90373f555f38fc61ca44` | `b737b4feff254e2da5d04151575acfbd06f201f3` |
| `M` | `.docs/rw0-c2-first-live-proof-posture.md` | 15,857 | `ab0c7a57b5807207203c5c31a4ba00b671a4e898264c4e9c1119d3517d959ce3` | `d88c3a6a0ec032e460cbd68c97dfe5b915a0514d` |
| `M` | `.docs/rw0-c2-private-value-versioning.md` | 207,681 | `966a1f5ac158ad6e597aa7922328612d0993e6e8c109f766aedd9ac7cc8bd251` | `54f84052d97d927e8ccc874b39b1fe8aa8596cff` |
| `??` | `.docs/rw0-c2-scope-admission-provisioning-contract.md` | 23,631 | `9af662213b3a9fe51a0c2f12449e46a3a1ea9d3172ac7e3d99ce7ce9fd509449` | absent |
| `??` | `tests/test_rw0_c2_scope_admission_provisioning_contract.py` | 51,303 | `1c50db7048a7f4e40a942a65c3e0fb92840ca7b3457be48977311b37dcff5667` | absent |

The repair closeout reports that only the final path changed from the blocked
opening candidate:

- opening verifier:
  - 35,014 bytes
  - SHA-256
    `01bf5a93ee151399911f784f5f00b90b0d4c372d02fd2f2c225e0877d7237de5`
- repaired verifier:
  - 51,303 bytes
  - SHA-256
    `1c50db7048a7f4e40a942a65c3e0fb92840ca7b3457be48977311b37dcff5667`

The five document endpoints must be byte-identical to the prior blocked
candidate. The live repaired verifier is the primary audit target; historical
opening bytes are corroborating transition evidence only.

Read each of the four HEAD blobs directly. Verify the exact candidate path set,
the index, all 240 noncandidate tracked paths, and Git-relevant modes. Preserve
any pre-existing nonexecuting OS mode such as `0600`; do not normalize unrelated
files to `0644`.

Preserve `AGENTS.md`, `README.md`, source, schemas, migrations, configuration,
scripts, all existing tracked tests, and every other noncandidate byte.
Migrations remain exactly `0001`–`0004`; `0005` is absent.

## 3. Exact final ordered patch

Visit the six candidate paths in the table order, which is lexicographic
repo-relative order.

For each tracked path:

```sh
git diff --binary --full-index --no-ext-diff --no-textconv HEAD -- PATH
```

For each new path:

```sh
git diff --no-index --binary --full-index --no-ext-diff --no-textconv -- /dev/null PATH
```

Concatenate exact stdout bytes without separators. A no-index exit status of `1`
means differences found and is expected.

Required component lengths:

```text
1,435 / 1,230 / 1,425 / 2,162 / 24,271 / 52,692
```

Required final patch:

```text
83,215 bytes
SHA-256:
c87d6fc097a4f3d462edb37782fabb5989e6654bb7775b85f0f385303dccef10
```

Reconstruct twice from fresh reads. Do not invoke configured external diff
helpers or text conversion. Do not invent a canonical manifest prerequisite.

## 4. Audit effect ceiling

Live checkout permits read-only Git, text, metadata, and hashing only.

Do not:

- import or execute repository modules in the live checkout;
- run pytest, compile, repository scripts, or SQLite connections there;
- edit, stage, commit, push, create a PR, merge, switch branches, or reset;
- fetch or contact a remote;
- install dependencies;
- access a supplier, service, provider, credentials, enrollment, launch,
  fencing, worker, ES, Bridge, or sibling repository;
- open unrelated ignored operator/product state;
- create delivered artifacts.

Executable audit work is permitted only in disposable, local-only external
clones of exact HEAD with no configured remote and exactly the six verified
candidate files overlaid. Existing tests may create isolated temporary
databases and special files under audit-owned external basetemps.

Before executable work, inventory only the known live
`src/ge_nwp_coordinator/__pycache__/` members as opaque data: path, type, mode,
size, nanosecond mtime, and hash for regular files. The prior audit observed 37
regular bytecode files plus their directory. Require exact member-level
opening/closing equality. Never import, move, delete, regenerate, or clean that
cache.

When inventorying external test artifacts, use `lstat` before opening paths.
Hash only regular files. Do not follow symlinks or open FIFOs, sockets, devices,
or other special files.

## 5. Source hierarchy and focused scope

Owning documents define current and accepted-target semantics. Source and
migrations define implemented behavior. Tests, reports, hashes, and synthetic
premises are evidence, not authority or implementation.

Read both new candidate files completely. Read every change in the four existing
documents in context against HEAD. Follow only the relevant owner/test edges in:

- `AGENTS.md`
- `.docs/rw0-c2-first-live-proof-posture.md`
- `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md`
- `.docs/rw0-c2-private-value-versioning.md`
- `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
- `.docs/writer-session-authority.md`
- `.docs/rw0-c1-durable-evidence.md`
- `.docs/c2b-durable-development-state.md`, current recovery successor clauses
- `src/ge_nwp_coordinator/lease.py`
- current writer-session and transaction/recovery source as data
- migration-0002 and migration-0004 definitions as data
- the exact existing tests in the validation group.

Verify that the private-value machine block from its begin marker through EOF is
byte-identical to HEAD and its existing verifier/parser is unchanged. Do not
restart the prior private-value/parser audit.

The five candidate documents are preservation obligations. The substantive
repair is in the new checker/test file only.

## 6. Preservation of the selected provisioning contract

Verify that the repaired checker still enforces, rather than redefines:

- external policy authors admission;
- the qualified source verifies the exact act and subjects;
- the independent source owns enrollment;
- the managed cell supplies current original-incarnation custody;
- Coordinator’s provisioner records only the already authorized immutable fact;
- initial recording does not require the absent local fact it is creating;
- no development program or dummy `program_ref` is created;
- the adopted act/fact schemas and identities remain unchanged;
- the separate recording family and one original timestamp remain unchanged;
- exact replay is same operation + same command + complete original family only;
- same act under a new operation or alternate fact ref is a conflict, not replay;
- a different complete provisioning winner is a fresh conflict and leaves
  original-operation recovery `unresolved`;
- definite noncommit requires exhaustive absence plus intact original custody
  and proved old-execution exclusion;
- recovery does not write, repair, retry, renew admission, or restart a proof;
- a new local `WriterSession` can qualify only inside the same original authority
  process under existing local fencing;
- process/supervisor restart and custody loss cannot resume this profile;
- supplier conformance, physical storage, migration `0005`, and runtime remain
  future.

Block any checker change that weakens those existing owner rules.

## 7. Finding 1 — disclosure must gate protected observation

### Actual ordering

Trace the final `_entry`, `_apply`, `_readback`, store-access helpers, alias
scans, and family validators.

Require current source/custody and disclosure permission to succeed before any
protected operation receipt lookup, family/member inspection, alias scan,
receipt-derived conflict distinction, or readback classification.

Command-local structural validation may precede the gate. Recording permission
alone is not disclosure permission.

### Direct fixed specimens

With a well-formed command, valid source/custody, recording permission `true`,
and disclosure permission `false`, prepare separately:

1. empty store;
2. exact original family;
3. existing operation receipt bound to another command;
4. malformed or unverifiable original family;
5. same-act alias under another operation;
6. malformed orphan in the collision/read set.

Every case must return the same content-free:

`recording_authority_unavailable`

Require:

- no protected receipt/family/alias read;
- no family construction;
- no write;
- no receipt/family-derived reason leakage;
- no exception from malformed stored data.

Use an instrumented or fail-on-read store that observes the actual paths used by
the checker. Reset traces after fixture arrangement so setup reads do not count.

A checker that reads first and then redacts the outcome is still defective.

### Required positive distinctions

With disclosure permission valid:

- exact same-command complete-family replay may succeed even when current
  recording permission is revoked;
- readback may classify under its own valid current disclosure/custody premise;
- an absent receipt under read-only permission must not trigger a write;
- fresh recording requires recording permission plus the disclosure/custody
  needed for its protected read set.

Do not make replay depend on a new timestamp, current recording eligibility, or
an unclaimed acceptance allowance.

## 8. Finding 2 — synthetic source must bind the actual subjects

Inspect the final synthetic policy/source, enrollment, custody, and evidence
records and the source-join path.

Require explicit binding of at least:

- exact verified act identity;
- exact verified act content digest;
- lineage;
- scope;
- guard profile;
- applicability;
- audience;
- current recording/disclosure permission as applicable;
- independently enrolled lineage/scope;
- original incarnation;
- original-state/custody observations;
- the command’s stable expected enrollment/incarnation coordinates.

The source record must be independently authored from the request under test.
It must not:

- reduce authentication to a Boolean;
- derive expected subjects by copying the supplied command;
- parse opaque identifier suffixes as authority;
- synthesize a source on demand to make an arbitrary command valid.

### Positive independence

Require at least three distinct complete, independently authored positive
sources A, B, and C with materially different opaque identifiers. Each must
record successfully only under its own evidence.

This proves that the checker is not a hard-coded A/B allowlist.

### Resealed foreign specimens

Hold source A fixed while supplying syntactically valid and fully resealed
candidate-owned values for:

- a B act/fact/command under A enrollment/custody;
- foreign scope;
- foreign profile or applicability;
- wrong exact act digest under matching labels;
- wrong enrollment/incarnation/original-state binding.

Each must fail at the source/custody/authority boundary before protected reads or
family construction, with no modeled write.

Renewed current evidence for the same stable subjects may carry new evidence
coordinates without changing the original command, fact, historical basis,
result, receipt, or recording time.

A currently permitted historical read after recording revocation remains
distinct from fresh-write authorization.

## 9. Finding 3 — malformed observations remain inside closed classification

Inspect the observed-family shape validator, complete-binding validator,
alias extraction, `_apply`, and `_readback`.

Require validation of the safe shape, built-in types, required member
containers, and required identity/content bindings before any alias or
completeness extraction.

With:

- valid canonical command;
- current disclosure permission;
- valid source/custody;
- admissible local readback premise;
- original operation receipt absent;

supply actual raw observed specimens:

- missing act mapping;
- act mapping with wrong container type;
- act missing a required field;
- missing fact member;
- missing basis member;
- null observed family;
- malformed nested member required for alias inspection.

Do not set a synthetic `fragments` flag merely to bypass the actual path.

Required behavior:

- `_readback` returns `unresolved`;
- `_apply` returns its existing no-write `family_unverifiable` class;
- no observed object is filled, rewritten, removed, adopted, or treated as
  absence;
- no raw `KeyError`, `TypeError`, or protected member detail escapes.

Do not accept a blanket `except Exception: unresolved`, hidden `.get` defaults,
or swallowed programming/assertion errors.

Preserve:

- complete exact family → `committed_exact`;
- exhaustive absence plus old-execution exclusion →
  `definitely_not_committed`;
- possible late commit → `unresolved`;
- partial/duplicate/unreadable/foreign family → `unresolved`;
- different complete provisioning winner → fresh-call conflict and original
  recovery `unresolved`.

## 10. Immediate compositions and evidence honesty

Independently test these two compositions:

1. disclosure denied + malformed orphan:
   the disclosure refusal must occur before malformed-member inspection;
2. renewed current evidence for the original stable subjects, followed by a
   resealed foreign source relation:
   renewed evidence must not relax stable identity binding.

Verify that the former “interleaving” test is accurately named and documented
as sequential duplicate replay after a modeled lost response. It does not prove
pending-interval serialization.

Keep late-writer exclusion evidence distinct. The audit may use a small fixed
outside oracle for the pending interval, but must label that as audit-side
evidence rather than candidate-test coverage. Do not build a scheduler, lock
emulator, or general transition engine.

## 11. Transformed-copy verification

Against the exact final repaired checker, create three disposable transformed
copies:

1. move disclosure gating after receipt-derived conflict/corruption inspection;
2. replace exact source-subject joins with the prior Boolean/suffix acceptance;
3. bypass malformed-member validation before alias extraction.

For each:

- keep independent expected specimens unchanged;
- require the selected permanent test to collect normally;
- require semantic failure at the intended boundary;
- do not credit parse, import, syntax, or collection failure.

Report permanent tests, direct hostile specimens, transformed copies, and any
outside-oracle evidence separately.

The mutable checker cannot authenticate arbitrary coordinated edits to itself
and all expectations; this independent audit owns the exact-byte and fixed-
expectation boundary.

## 12. Exact serial validation

After provenance passes, create one fresh private mode-`0700` external root.
Build a local-only clone from exact HEAD, remove its remote, and overlay exactly
the six verified candidate files. Verify all 246 candidate endpoints before
testing.

Use normal test-process `umask 022`. Precreate separate external basetemp
parents. Run collection then execution serially with:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src \
python3 -m pytest -q -p no:cacheprovider \
  --basetemp=<external-precreated-path> [--collect-only] <group>
```

Exact groups:

### A. Repaired provisioning checker

```text
tests/test_rw0_c2_scope_admission_provisioning_contract.py
```

Reported final result:

```text
27 unique collected / 27 passed
```

### B. Owning/composition regressions

```text
tests/test_rw0_c2_first_live_proof_posture_contract.py
tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
tests/test_rw0_c2_private_value_versioning_contract.py
tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_architecture_contracts.py
tests/test_autonomous_software_development_operating_model.py
tests/test_c2b0_durable_state_contract.py
tests/test_sqlite_backend_b0_contract.py
tests/test_b2a_writer_session_contract.py
```

Reported final result:

```text
3,208 unique collected / 3,208 passed
```

### C. Complete repository

No path arguments.

Reported final result:

```text
8,785 unique collected / 8,785 passed
3 existing Python 3.13 multithreaded-fork DeprecationWarnings
```

The three expected warnings are attached to these existing tests in
`tests/test_sqlite_b2c_writer_session.py`:

- `test_operation_guard_close_waits_and_retains_authority_until_exit`
- `test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang`
- `test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock`

Require unique node IDs, A/B disjointness, and A/B inclusion in C. Removing A
from C should leave the 8,758-test merged baseline.

Inspect structured warning records. Do not suppress warnings, remove tests, or
manufacture historical totals.

Run:

- `git diff --check`;
- both new-file no-index whitespace checks;
- UTF-8/BOM/CR/trailing-whitespace/final-LF checks;
- exact path/type/mode checks;
- preservation checks for all five documents and all 240 noncandidate tracked
  paths;
- source/schema/migration/catalog preservation;
- migration `0005` absence;
- before/after clone endpoint equality.

Correct only clearly identified audit-runner errors outside the live checkout.
Rebuild from the same exact candidate and rerun the affected required gates.
Candidate defects are findings, not audit repair authority.

## 13. Cleanup and live preservation

Inventory external audit artifacts with `lstat` before opening. Hash only
regular files. Never follow symlinks or open FIFOs, sockets, or devices.

Classify temporary SQLite files and special fixtures under the audit-owned root,
then remove only that root after all processes terminate. Do not touch live
cache or unrelated temporary/operator state.

Require final live equality for:

- HEAD, tree, parent, branch, upstream, worktree count;
- index and unmerged state;
- all six candidate endpoints;
- all 240 noncandidate tracked paths;
- migrations and source;
- live cache member paths, types, modes, sizes, mtimes, and hashes.

## 14. Verdict rules

### Accept only if

- exact provenance and the final 83,215-byte patch reproduce;
- all five documents remain unchanged from the blocked candidate;
- disclosure permission gates every protected observation;
- recording-only permission never reveals receipt/family state;
- valid read-only replay/readback remains possible under its distinct current
  authorization;
- source subjects bind exact act, lineage, scope, profile, applicability,
  audience, enrollment, incarnation, and custody;
- A, B, and C positive sources all work under their own evidence;
- foreign/resealed source joins are refused before protected reads/writes;
- malformed observations stay within the closed apply/readback outcomes;
- the three transformed defects are detected semantically;
- all required validation and preservation checks pass;
- no unresolved High- or Medium-severity in-scope finding remains.

Use:

`RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE`

### Block for

- any surviving protected-state disclosure;
- source-subject mismatch acceptance;
- uncaught malformed-observation access;
- hidden write or family construction on denied paths;
- regression in replay, conflict, recovery, first-live, act/fact, or C2
  separation;
- candidate/provenance drift;
- material transformed-copy or required validation gap.

Use:

`RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_AUDIT_BLOCKED`

### Provenance mismatch

Use:

`AUDIT_PROVENANCE_MISMATCH`

## 15. Inline report

Return:

1. primary verdict and visible settings;
2. opening/closing coordinates and exact six receipts;
3. final patch reproduction and one-file transition evidence;
4. preservation of the five documents, private-value machine block, source,
   migrations, noncandidate paths, and cache;
5. disclosure-gate order and protected-read trace results;
6. fresh-write versus read-only replay/readback distinctions;
7. source-subject relation, A/B/C positives, and resealed foreign specimens;
8. malformed-observation validation and closed outcomes;
9. compositions, renamed sequential test, and pending-interval evidence limit;
10. permanent tests, direct specimens, transformed copies, and outside oracle
    separated clearly;
11. exact validation commands, counts, warnings, setup errors, cleanup, and
    skipped work;
12. severity-ranked findings or explicit no remaining in-scope findings;
13. exact next boundary and continuation capsule of at most 800 words.

Acceptance authorizes only a separately issued commit/publication gate for the
exact six audited files. It does not authorize source, migration `0005`,
supplier qualification, runtime provisioning, enrollment, launch, recovery
runtime, deployment, RW0-D implementation, or RW0-E execution.

State actual non-actions and temporary effects truthfully. End with exactly one
of the three verdict tokens.
