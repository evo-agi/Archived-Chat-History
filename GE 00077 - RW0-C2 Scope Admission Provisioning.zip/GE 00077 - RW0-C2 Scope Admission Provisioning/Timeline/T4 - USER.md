Here is Codex's response:

# Independent audit: blocked

The six-file candidate has exact provenance, and all required tests pass. **I cannot accept it for the commit gate** because direct specimens found material gaps in the new synthetic checker. The governing prose keeps admission recording separate from external admission, enrollment, and C2 acceptance; the blocking findings concern whether the candidate’s tests enforce those boundaries.

Visible model: GPT-6. Reasoning effort: not visible; no higher setting was exposed. Permission posture: unrestricted filesystem, approval policy `never`. This was one parent-only, repository-first audit. I used no subagents.

## Provenance and preservation

Opening and closing coordinates were identical: `trunk_dev` at HEAD `630414faa07f4ac39c4a870a9cc44c7f92d46b80`, tree `cd81f7cca8b64cb9ff221537257e70e2c5a655a3`, sole parent `d070bf05d2e68472e18b1b077259e67864923e8f`, subject `docs: freeze RW0-C2 first-live proof posture`. The local `origin/trunk_dev` comparison was 0 ahead / 0 behind; that is **not** fresh remote truth. There was one live worktree, an index matching HEAD, and no staged, unmerged, sequencer, or Git-lock state.

| Candidate path | Status | Bytes | Working SHA-256 | HEAD blob OID |
| --- | --- | ---: | --- | --- |
| `.docs/autonomous-software-development-operating-model.md` | M | 39,708 | `ccca078da9da0eca90d6e0f86bb30dbda9960765276e7737d4af8b66cc9197a1` | `9207ff698920682dc25057a9fc12b9f2a8cb28d7` |
| `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | M | 26,041 | `0ebe519379a689f87a2f6ddabeeede5f96d1c5d4ec8f90373f555f38fc61ca44` | `b737b4feff254e2da5d04151575acfbd06f201f3` |
| `.docs/rw0-c2-first-live-proof-posture.md` | M | 15,857 | `ab0c7a57b5807207203c5c31a4ba00b671a4e898264c4e9c1119d3517d959ce3` | `d88c3a6a0ec032e460cbd68c97dfe5b915a0514d` |
| `.docs/rw0-c2-private-value-versioning.md` | M | 207,681 | `966a1f5ac158ad6e597aa7922328612d0993e6e8c109f766aedd9ac7cc8bd251` | `54f84052d97d927e8ccc874b39b1fe8aa8596cff` |
| `.docs/rw0-c2-scope-admission-provisioning-contract.md` | ?? | 23,631 | `9af662213b3a9fe51a0c2f12449e46a3a1ea9d3172ac7e3d99ce7ce9fd509449` | absent |
| `tests/test_rw0_c2_scope_admission_provisioning_contract.py` | ?? | 35,014 | `01bf5a93ee151399911f784f5f00b90b0d4c372d02fd2f2c225e0877d7237de5` | absent |

I read the four HEAD blobs directly. Their baseline byte counts were 39,079 / 26,007 / 15,741 / 207,512; their SHA-256 values were, in table order, `cba69a4e88eeb34bb0f25d3ac8f2ca8774b471fd6dc70a6af1211b3d661b963f`, `e91b82190ccb4969ff670a365b66419e7c5ac945ca328f3c832c5db1e5eb0d09`, `0064fd833337dee2503da1296525e32e4e76a799c803a86122434b86919f6541`, and `8d0477a2d1ba0cc6f94bacb59927932123582231ebecf345355492e3e6817a37`.

The six ordered diff stdout parts were 1,435 / 1,230 / 1,425 / 2,162 / 24,271 / 36,037 bytes. Concatenation reproduced **66,560 bytes**, SHA-256 `90065f492ed1667d3ad4fd83a72e4effd23bdf1bdb0562ad8c126f208218f7fc`, twice at opening and again at closing. The two no-index diff status codes were the expected `1`.

All six endpoints were regular nonsymlink mode `0644`, strict UTF-8, with exactly one final LF and no BOM, CR, or trailing whitespace. The four tracked Git modes remained `100644`; the new paths were absent from HEAD and index. All **240 noncandidate tracked paths** matched HEAD bytes and Git-relevant modes. Migrations remained 0001–0004; 0005 was absent. The private-value machine block from its begin marker through EOF was byte-identical to HEAD, and its existing verifier was unchanged (`tests/test_rw0_c2_private_value_versioning_contract.py:16`). The known live `__pycache__` directory and **37 bytecode files** matched their opening membership, type, mode, size, nanosecond mtime, and regular-file hashes exactly after cleanup.

## Authority and contract judgment

| Boundary | Current or selected posture |
| --- | --- |
| External standing policy | Authors admission and applicable authority; a digest or local absence cannot substitute for it. `.docs/rw0-c2-scope-admission-provisioning-contract.md:37-56` |
| Qualified verifier and independent enrollment | Future source checks must bind the exact act, lineage, scope, profile, audience, current permission, original incarnation, and custody. Enrollment and launch remain outside the provisioner. `.docs/rw0-c2-scope-admission-provisioning-contract.md:37-61` |
| Coordinator provisioner | Target-only owner of recording the unchanged fact and its separate result, receipt, replay, and readback. It creates no program or C2 acceptance. `.docs/rw0-c2-scope-admission-provisioning-contract.md:3-35` |
| C2 decision writer | Separate future owner of the five-branch decision and acceptance family. `.docs/rw0-c2-durable-progression-decision-semantic-contract.md:447-475` |
| Current implementation | Writer-fenced SQLite mutation and RW0-C1 evidence exist; admission provisioning and executable authorization do not. The default provider remains fail-closed. `src/ge_nwp_coordinator/lease.py:335-350`; `.docs/architecture.md:30-74` |

The four tracked edits are direct routing links at `.docs/autonomous-software-development-operating-model.md:101-109`, `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md:56-63`, `.docs/rw0-c2-first-live-proof-posture.md:58-68`, and `.docs/rw0-c2-private-value-versioning.md:19-26,559-566`. They do not change the adopted eleven-value machine block or claim implementation. The new owner is reachable from the operating model, guard, first-live profile, and private-value owner without changing unrelated architecture files.

The new prose gives initial recording a noncircular bootstrap entry: it uses the independently verified act, enrollment, original custody, recording permission, and local fencing **without requiring the admission row it creates**. Unrelated initialized programs need not be absent (`.docs/rw0-c2-scope-admission-provisioning-contract.md:20-35,49-61`). It preserves the adopted act/fact fields; `admission_fact_ref` is a stable preassigned reference, distinct from its digest, and `one_shot_ceiling` is exact integer `1` (`:63-72,85-101`). Fact identity has no recording time, operation, program, or incarnation field.

The separately versioned command, basis, result, receipt, conflict, and readback forms are closed at `:120-173`. Their dependency order is acyclic: act and fact → command → historical basis and one transaction-owned time → result → receipt (`:194-207`). I independently encoded the fixed vector before comparing with the checker: act projection `cfcd726c…634b1c`, fact `68303f1a…b5d33ae1`, command `edbe634a…62d72b`, basis `0e919e35…09bafb2`, result `c3946a12…1caddd9`, receipt `738fc310…30e6f6`, and selector `718deb68…a0870b`. The complete values matched the candidate helper. These are identity checks, not authentication or permission.

The prose also states the required receipt-first order, exhaustive fresh collision checks, no durable refusal event, one local COMMIT as the recording point, and read-only three-way recovery (`:209-303`). It correctly makes a different complete provisioning winner a fresh conflict but **original-operation recovery `unresolved`**, rather than importing the C2 acceptance shortcut (`:283-295`). A same-process fresh writer may qualify under existing acquisition and fencing without proving the old resource reached X; a process or supervisor restart cannot resume this first-live profile (`:296-303`; `.docs/c2b-durable-development-state.md:19555-19579`). RW0-D remains offline with fake sources, while real-custody entry and RW0-E still require supplier conformance and separate authorization (`.docs/rw0-c2-scope-admission-provisioning-contract.md:305-315`; `.docs/rw0-c2-first-live-proof-posture.md:187-219`).

## Blocking findings

1. **P1 — protected receipt information escapes the checker’s disclosure gate.** `_entry` admits a request with recording permission alone (`tests/test_rw0_c2_scope_admission_provisioning_contract.py:293-311`). `_apply` then reads the existing receipt and can return `operation_identity_conflict` or `family_unverifiable` **before** checking disclosure permission (`:330-341`). With recording permission true and disclosure permission false, both direct specimens produced those revealing classes instead of content-free `recording_authority_unavailable`; neither wrote. The owner requires protected receipt-first disclosure permission (`.docs/rw0-c2-scope-admission-provisioning-contract.md:215-236`). This is a candidate checker and gate-order evidence defect, not a claim about a nonexistent production provisioner.

2. **P1 — the synthetic positive source premise does not bind act lineage to enrollment.** `_Premises.authenticated_act` is a Boolean, while `_entry` compares the source suffix only with four enrollment/custody refs (`tests/test_rw0_c2_scope_admission_provisioning_contract.py:136-151,293-311`). I supplied a valid, resealed act/fact for lineage B with enrollment and custody refs A under the fixture’s source A. The checker returned `scope_admission_recorded` and added one family; the fixed source-binding expectation was a custody/authority refusal. The prose requires independently verified act and original enrollment bindings (`.docs/rw0-c2-scope-admission-provisioning-contract.md:37-61`). Synthetic premises remain legitimate, but this fixture cannot demonstrate that required relation.

3. **P2 — malformed orphan readback misses the closed classifier.** When the original receipt is absent, `_readback` calls `_aliases` on another observed family without first checking that member’s shape (`tests/test_rw0_c2_scope_admission_provisioning_contract.py:314-322,382-395`). An orphan with a missing act mapping raised `KeyError`, rather than returning `unresolved`. The existing `fragments=True` test models a partial family as a flag and does not reach this malformed-member path (`:564-581`). The owner requires malformed or unreadable observations to fail closed (`.docs/rw0-c2-scope-admission-provisioning-contract.md:283-287`).

These are **test-model/causal-evidence defects**. I found no separate authority drift in the four routing edits and no product-source bug in this documentation-and-test-only candidate. The missing real supplier, SQL layout, migration 0005, and runtime are expressly deferred and are not reasons for this disposition.

## Causal evidence and validation

The 18 collected nodes consist of 16 test functions, one parameterized into three nodes. Their actual reach is:

| Test function(s) in `tests/test_rw0_c2_scope_admission_provisioning_contract.py` | Nodes | Histories and reached boundary |
| --- | ---: | --- |
| `test_owner_inventory_and_preserved_adopted_schemas` | 1 | Static owner/schema comparison; no apply boundary |
| `test_fixed_vector_and_two_distinct_positive_sources`; `test_first_recording_before_program_and_forged_or_empty_local_state` | 2 | Histories 1–3; canonical values, positive A/B applies, empty/unverified refusal, no program mutation |
| `test_replay_uses_original_family_after_fresh_evidence_and_downstream_use` | 1 | Histories 4–5; original family/time retained, later acceptance ignored, new-operation alias denied |
| `test_same_operation_change_is_no_write`; `test_same_operation_different_valid_fact_command_conflicts`; `test_foreign_alias_and_occupied_target_do_not_mutate` | 5 | History 5; three parameter cases include two custody/structure preflight outcomes; the valid resealed cases reach receipt or alias checks |
| `test_two_interleaved_requests_commit_at_most_one_family` | 1 | History 7 after a modeled committed/lost response; it is sequential and has no pending-operation state |
| `test_precommit_failure_attempted_commit_and_cleanup_loss` | 1 | History 8; modeled no-write versus uncertainty and readback |
| `test_readback_complete_absent_partial_duplicate_unreadable_and_foreign` | 1 | Histories 6, 9–10; boolean fragments, duplicates, winner, and receipt corruption |
| `test_old_execution_exclusion_and_explicit_resubmission` | 1 | Histories 11 and 15; late-writer premise and separate same-command resubmission |
| `test_same_process_fresh_writer_vs_restart_and_restore` | 1 | Histories 12 and 14; synthetic custody loss and clone refusal |
| `test_revocation_and_disclosure_permission_are_current_separate_checks` | 1 | History 13; allowed read after recording revocation and denied read |
| `test_closed_inputs_and_bool_as_int_fail_before_local_absence` | 1 | Closed input and recursive-duplicate example |
| `test_direct_counterexamples_to_missing_checks_and_widened_powers`; `test_offline_repetition_and_future_owner_nonclaims` | 2 | Histories 2, 11–12, 16; direct assertions and static owner claims |

The checker counts families, enrollment writes, and acceptances; it has no actual clock, launch, SQL, or supplier. Its “interleaving” test exercises a postcommit second call. My small fixed oracle covered the pending interval separately, then invoked the checker after commit or clean rollback; I give the pending interval **oracle-only** credit.

Direct specimens reached `unresolved` for a lost response followed by missing receipt and a partial family; `unresolved` for absent slots while an old writer could still commit; `definitely_not_committed` only with the separately asserted exclusion premise; and fresh conflict versus recovery `unresolved` for a different complete winner. Renewed evidence followed by an alternate fact reference preserved the original family and refused the second operation. A third distinct synthetic source C recorded successfully, so there is no A/B fixture allowlist. Resealed foreign act and substituted-receipt-member specimens reached the intended collision and family checks. The four mismatches are the findings above.

Five **in-memory transformed copies of the complete observed checker** parsed, compiled, and imported. Removing enrollment/custody checks recorded without them; permitting a same-act alternate fact minted a second family; treating missing receipt as noncommit returned `definitely_not_committed` despite a fragment; allowing restart recorded after process loss; and adding provisioner powers incremented enrollment and acceptance counters. Fixed external expectations rejected all five, and a selected existing candidate test raised an assertion for each. No mutant received credit from a parse, import, or collection failure.

All executable work ran in one mode-0700, local-only external clone of exact HEAD, with its remote removed and only the six verified files overlaid. Before and after testing, all **246 file endpoints** matched by bytes and Git-relevant modes; no extra clone file appeared. Python was 3.13.4, pytest 8.4.1, and SQLite 3.49.1. The serial commands used `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src python3 -m pytest -q -p no:cacheprovider`, distinct precreated external basetemp parents, `--collect-only` before execution for each group, no xdist, and:

| Group | Selectors | Collected / passed |
| --- | --- | ---: |
| A | `tests/test_rw0_c2_scope_admission_provisioning_contract.py` | 18 / 18 |
| B | The ten exact contract modules specified in section 7, from `test_rw0_c2_first_live_proof_posture_contract.py` through `test_b2a_writer_session_contract.py` | 3,208 / 3,208 |
| C | No path selector; complete repository | 8,776 / 8,776 |

A and B were disjoint and both were subsets of C; C contained 5,550 other unique nodes. The three actual warning records were `DeprecationWarning` for multithreaded `fork()` in `tests/test_sqlite_b2c_writer_session.py::test_operation_guard_close_waits_and_retains_authority_until_exit`, `::test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang`, and `::test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock`. There were no skips or test corrections. Tracked `git diff --check` returned 0; both new-file no-index whitespace checks returned difference status 1 with no diagnostics.

The isolated basetemps contained 8,397 directories, 5,024 regular files—including 1,355 SQLite-header files—five FIFOs, and seven symlinks. My first **post-test inventory scanner**, not a test runner, blocked when it opened a FIFO. I stopped it and reran only that inventory with `lstat` before opening regular files. No validation gate was changed or given credit from that scan. The entire audit-created external root was then removed.

I made no live edit, staging, import, test, SQLite connection, cache mutation, source/schema/migration/config change, network or provider call, supplier qualification, credential use, service call, sibling or subagent invocation, enrollment, launch, acceptance, worker, ES or Bridge effect, commit, push, PR, or merge. No external evidence artifact was delivered. The final live HEAD, index, six paths, patch, protected paths, and bytecode inventory remained unchanged.

## Next boundary and continuation capsule

The next permitted boundary is correction of the **six-file candidate’s semantic test evidence**, including the disclosure gate and synthetic source/member observations, followed by a fresh provenance-bound independent audit. This report does not authorize a commit gate or any source, supplier, enrollment, runtime, RW0-D, or RW0-E work.

**Continuation capsule (under 800 words).** Audit target: the six uncommitted paths at HEAD `630414faa07f4ac39c4a870a9cc44c7f92d46b80`; ordered patch SHA-256 `90065f492ed1667d3ad4fd83a72e4effd23bdf1bdb0562ad8c126f208218f7fc`. Provenance and preservation passed; 18, 3,208, and 8,776 tests passed serially, with three known Python 3.13 fork warnings. The target prose maintains external admission authorship, independent enrollment, original first-live custody, program-independent recording, separate C2 acceptance, one COMMIT, and readback-only uncertainty. Audit blocks acceptance on three candidate-checker defects: write-only requests disclose receipt-derived conflict classes; a foreign act can record under another synthetic enrollment binding; malformed orphan readback raises `KeyError` instead of `unresolved`. Five requested transformed counterexamples were semantically detected; two compositions and late-writer/winner checks reached their intended boundaries. All external audit files were removed and the live checkout is unchanged. Re-audit corrected candidate bytes before any separately authorized commit/publication decision.

RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_AUDIT_BLOCKED
