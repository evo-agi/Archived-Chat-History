## Disposition

**Proceed to a fresh independent read-only re-audit of the exact V4 candidate. Do not stage or commit it.**

Codex returned the intended outcome:

```text
RW0_C2_SCOPE_ADMISSION_PROVISIONING_CHECKER_REPAIRED_V4_READY_FOR_INDEPENDENT_AUDIT
```

The closeout presents no deterministic pre-audit blocker:

- only `tests/test_rw0_c2_scope_admission_provisioning_contract.py` changed from V3;
- all five candidate documents retained their exact previous receipts;
- the final six-path patch was reconstructed twice;
- source, schemas, migrations, existing tests, configuration, and runtime surfaces remain unchanged;
- migration `0005` remains absent;
- the complete repository passed **8,812 tests with the same three expected warnings**.

This is audit-ready, not commit-ready.

## Repair reconciliation

### Source observations now receive exact type validation

The V3 audit demonstrated that checking an observation wrapper’s class was insufficient when its scalar fields were later compared using ordinary equality. A hostile string subclass could influence both candidate/source equality and the fixed owner-literal comparison. Pasted text

V4 reports exact validation of:

```text
10 policy strings
4 enrollment strings
5 custody strings
6 evidence strings
12 premise Booleans
the observation wrapper classes themselves
```

The claimed ordering is correct:

```text
wrapper and scalar exact-type validation
→ source/request equality
→ selected owner-literal checks
→ disclosure authorization
→ protected reads
→ family construction and append
```

The independent audit must verify the **entire inventory**, not only the four profile/applicability specimens. In particular, it should use malicious subclasses that override equality, and wrong built-in values such as integer `1` in Boolean permission fields.

No canonical encoder, string conversion, copy helper, JSON round-trip, or digest function may erase the hostile runtime type before the exact-type boundary is reached.

### The transaction timestamp is now a fresh-write-only validated input

V4 reports that a fresh `recorded_at` must be:

```text
exact built-in str
YYYY-MM-DDTHH:MM:SSZ
whole-second UTC
real calendar time
canonical round-trip text
```

and is validated before family construction, append, and success.

That addresses the V3 finding where both a timestamp subclass and the built-in string `not-a-timestamp` received `scope_admission_recorded` before the resulting malformed family later failed readback.

The audit should independently test, at minimum:

```text
valid canonical time
str subclass with valid text
not-a-timestamp
fractional seconds
+00:00 offset
lowercase z
leading/trailing whitespace
impossible date
impossible time or leap second
non-zero-padded fields
valid leap day
```

The crucial ordering proof is not merely the returned label. Instrumented construction and append counters must remain zero for an invalid fresh timestamp.

### Replay and readback must remain independent of a new timestamp

The closeout correctly reports that exact replay with an invalid newly supplied time still returns the original stored family and timestamp, and that readback has no new-time argument.

The audit must verify both sides:

- an invalid **new** time is ignored for exact replay;
- an invalid **stored** time prevents exact replay and `committed_exact`;
- renewed current evidence does not rewrite the original timestamp;
- timestamp validation is not applied globally before the receipt lookup.

## Validation reconciliation

The collection changes are internally exact:

| Surface | V3 | V4 | Delta |
|---|---:|---:|---:|
| Provisioning checker | 38 | 54 | +16 |
| Owning/composition group | 3,208 | 3,208 | 0 |
| Full repository | 8,796 | 8,812 | +16 |

The full count remains:

```text
8,812 = 8,758 merged baseline + 54 provisioning tests
```

The reported final endpoint and patch are:

```text
V4 checker:
71,224 bytes
6a9ec185d9595aeb51708c92827fc2798a2ae5497de54fa3e563a20791b7b093

Six-path patch:
103,561 bytes
77abc6ae33e52ac907a1d2ce4d3fa2c3710c114ffdb08d5467ad38b0973bdf58
```

The seven transformed copies are useful implementation evidence, but the independent audit should add two important adversarial checks:

1. a regex-only timestamp validator that accepts an impossible calendar date;
2. global validation of the new timestamp that incorrectly breaks exact replay.

## Preserved obligations

The re-audit must also reconfirm that V4 did not regress the previously accepted repairs:

- denied disclosure causes zero protected receipt, family, or alias reads;
- read-only replay remains available under valid disclosure after recording permission is revoked;
- A, B, and C independent sources remain generic positive fixtures;
- candidate/source agreement on a foreign profile or applicability still fails the fixed owner literal;
- malformed stored observations remain `family_unverifiable` or `unresolved`;
- a different complete provisioning winner remains a fresh-call conflict and leaves original-operation recovery `unresolved`;
- old-writer exclusion remains necessary for `definitely_not_committed`;
- same-process local-session renewal remains distinct from a process or supervisor restart.

## Fresh independent re-audit handoff

Start a **fresh parent-only read-only Codex conversation**, select the highest exposed reasoning setting, and attach nothing.

:chatgpt-content-reference{index="2"}[Download the V4 independent re-audit prompt](sandbox:/mnt/data/Coordinator_RW0_C2_Scope_Admission_Provisioning_V4_Independent_Reaudit_Prompt.txt)

```text
Filename:
Coordinator_RW0_C2_Scope_Admission_Provisioning_V4_Independent_Reaudit_Prompt.txt

Bytes:
25,166

SHA-256:
9cd0a12a3e2eb56ffcdb0183540b307bfd52b7ba011ae48ff7c05ee106f5f870

Logical lines:
692

Final newline:
present
```

The prompt binds the exact candidate to:

```text
HEAD:
630414faa07f4ac39c4a870a9cc44c7f92d46b80

Tree:
cd81f7cca8b64cb9ff221537257e70e2c5a655a3

V4 checker:
71,224 bytes
6a9ec185d9595aeb51708c92827fc2798a2ae5497de54fa3e563a20791b7b093

Final six-path patch:
103,561 bytes
77abc6ae33e52ac907a1d2ce4d3fa2c3710c114ffdb08d5467ad38b0973bdf58
```

It requires independent verification of:

- every source-observation field and exact runtime type;
- malicious equality-overriding subclasses;
- exact wrapper-class requirements;
- source-validation ordering before disclosure and protected reads;
- A/B/C positive independence and fixed owner-literal enforcement;
- exact canonical timestamp grammar and real calendar validity;
- pre-construction and pre-append timestamp validation;
- replay/readback independence from a newly supplied time;
- rejection of an invalid stored timestamp;
- preservation of all V2/V3 repairs;
- nine focused transformed copies;
- exact 54 / 3,208 / 8,812 serial validation;
- member-level cache preservation and external cleanup.

Possible verdicts:

```text
RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE

RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_AUDIT_BLOCKED

AUDIT_PROVENANCE_MISMATCH
```

Acceptance would authorize only a separately issued commit and PR publication gate for the exact six audited files. It would not authorize source implementation, migration `0005`, supplier qualification, runtime provisioning, enrollment, launch, recovery runtime, deployment, RW0-D implementation, or RW0-E execution.

Some older project uploads have expired. They are not needed for this re-audit; re-upload an older original only when a later task requires inspecting its bytes.

**Sources:** Codex’s V4 repair closeout supplied in this turn; the preceding V3 independent audit, particularly its source-scalar and timestamp findings. Pasted text  
**Confidence:** High that V4 is ready for this bounded independent audit. Commit readiness remains unresolved until complete source-field typing, timestamp ordering and grammar, replay/readback separation, and all preserved earlier boundaries are independently reproduced.
