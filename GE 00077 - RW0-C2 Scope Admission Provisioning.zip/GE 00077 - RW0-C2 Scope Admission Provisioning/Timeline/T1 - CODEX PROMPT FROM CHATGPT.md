# Governed Execution Coordinator — Program-Independent Scope-Admission Provisioning Contract

## Objective and effect ceiling

Write one repository-first documentation-and-causal-contract-test candidate for
the separate scope-admission RECORDING operation. The first-live posture is
already merged. Do not reopen continuity architecture or commission another
reconnaissance pass.

Create one semantic owner:
 .docs/rw0-c2-scope-admission-provisioning-contract.md
and its bounded test module:
 tests/test_rw0_c2_scope_admission_provisioning_contract.py

This owner defines the target provisioning command, logical recording family,
result/receipt, exact replay, no-write conflicts, and readback-only recovery.
It records an already externally authorized admission; it does not admit the
lineage by itself, enroll or launch an incarnation, or authorize C2 execution.

The parent is the sole writer; no subagents. Only the allowed documentation and
tests may change. No product source, schema, SQL, migration, config, public API,
runtime, service, supplier experiment, credential work, network, enrollment,
launch, deployment, RW0-D/E execution, or sibling-repository work. No staging,
commit, push, PR, merge, or live branch changes.

Use the highest exposed reasoning setting. Record visible model, effort, and
permission posture, or "not visible"; do not seek additional account/computer
access merely to identify settings.

Return ONE inline closeout and a continuation capsule of at most 800 words.
Do not deliver reports, JSON manifests, packages, or patches. Disposable external
validation files are permitted and must be removed. No historical attachment
or earlier prompt is a prerequisite. Do not issue a subsequent implementation
prompt.

## 1. Exact merged baseline

Repository:
 /Users/ds/Repositories/Governed Execution Coordinator

Required opening:
 branch: trunk_dev
 HEAD: 630414faa07f4ac39c4a870a9cc44c7f92d46b80
 tree: cd81f7cca8b64cb9ff221537257e70e2c5a655a3
 sole parent: d070bf05d2e68472e18b1b077259e67864923e8f
 subject: docs: freeze RW0-C2 first-live proof posture
 upstream: origin/trunk_dev
 locally observed divergence: 0 ahead / 0 behind
 one worktree; clean tracked/untracked/staged/unmerged state
 no active Git operation or unexpected lock.

Read AGENTS.md first. Verify opening and closing with non-mutating Git
inspection and optional-lock suppression where appropriate. Do not fetch or
normalize the checkout. A locally observed tracking ref is not fresh remote
truth. Stop on baseline drift or another actor's unexpected changes.

Git owns object/ref facts. Owning documents define current and accepted-target
contracts. Source and migrations establish implemented behavior. Tests, reports,
and this prompt are not evidence that external custody or authorization exists.

PR #12 adopted rw0-c2-single-realization-proof-v1 and synthetic contract tests.
It implemented no admission provisioner, guarded C2 writer, migration 0005,
supplier, recovery runtime, or live proof.

## 2. Fixed engineering decisions

A. Provisioning is program-independent and can precede any development program.
   It neither requires an empty database nor requires that unrelated programs
   be absent. It creates no dummy program, program head, progression decision,
   worker attempt, acceptance, or terminal outcome.

B. Use a separately versioned provisioning operation family. Do not reuse
   development_mutation_receipts by inventing a program_ref or widening its
   five-family result algebra. Existing C1 receipts are also not admission
   receipts. A provisioning receipt/classifier concerns ONLY admission
   recording; it is not a second C2 acceptance receipt or recovery owner.

C. Reuse the exact adopted verified-admission-act and scope-admission-fact
   grammars and identity meanings. Keep the fact independent of operation,
   timestamp, program, incarnation, machine, database, grant renewal, and retry.
   Its one_shot_ceiling remains exact integer 1, never Boolean True.
   Invocation/enrollment/custody/time bindings belong to the new operation
   context and receipt, not new fields in the admission fact.

D. First-live order is:
   authenticated external admission and independent enrollment
   -> one managed incarnation activated
   -> separately authorized admission recording in its original state
   -> later guarded C2 commands may consume the recorded fact.
   Recording does not require the admission row it is about to create.
   Existing applicable C2 command requirements are not weakened: provisioning
   is a distinct bootstrap recording entry, not a C2 command bypass.

E. There is no external pre-commit arm, post-commit checkpoint, settlement,
   general continuity custodian, or per-mutation remote write. Fresh evidence
   and current permission remain required under the merged first-live profile.
   No routine user relay or per-command approval is introduced.

F. Same original operation and canonical command is the only exact-replay key.
   The same act under a new operation is not another recording or exact replay.
   Conflicting acts, aliases, occupied target identities, and partial families
   cannot be repaired by this writer.

G. Commit uncertainty is resolved only by this provisioning owner's complete
   original-family readback under intact original-incarnation custody. Recovery
   performs no write or retry. Custody/process restart cannot be used to resume
   the first-live proof. A new local WriterSession, if its existing acquisition
   rules permit it IN THE SAME original process/custody, is not a new incarnation.

H. Freeze semantic values and logical atomicity now, not SQL tables, indexes,
   reader queries, migration layout, callable production signatures, transport,
   trust-root encoding, or supplier implementation. Those remain later gates.

These are selected target decisions. Explain their derivation from the owning
contracts in the new document and closeout; never report them as implemented.

## 3. Focused re-grounding before editing

Read the new tranche's dependencies, following actual owner edges:

Guidance/status:
 AGENTS.md; README.md; pyproject.toml; .gitignore
 .docs/architecture.md
 .docs/autonomous-software-development-operating-model.md
 .docs/authority-boundaries.md

Semantic owners:
 .docs/rw0-c2-first-live-proof-posture.md
 .docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md
 .docs/rw0-c2-private-value-versioning.md
 .docs/rw0-c2-durable-progression-decision-semantic-contract.md
 .docs/rw0-remote-worker-contact-phase-entry.md

Current mechanics as compatibility evidence, not ready-made provisioning:
 .docs/c2b-durable-development-state.md: current Section 38 genesis/recovery and
   directly relevant successor clauses; do not promote older planning projections
 .docs/writer-session-authority.md
 .docs/rw0-c1-durable-evidence.md: mutation/recovery and cleanup-publication rules
 .docs/sqlite-operations-and-recovery.md: current administrative restore boundary
 src/ge_nwp_coordinator/_development_decision_row_values.py
 src/ge_nwp_coordinator/_development_program_initialization_contracts.py
 src/ge_nwp_coordinator/_sqlite_development_program_initialization.py
 src/ge_nwp_coordinator/_sqlite_development_readers.py and reader contracts
 src/ge_nwp_coordinator/sqlite_mutation_transaction_contracts.py
 src/ge_nwp_coordinator/sqlite_transition_transaction.py
 src/ge_nwp_coordinator/sqlite_writer_session.py
 src/ge_nwp_coordinator/state_authority_lock.py
 src/ge_nwp_coordinator/lease.py
 src/ge_nwp_coordinator/sqlite_migration.py
 src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql
 src/ge_nwp_coordinator/sqlite_migrations/0004_rw0_c1_durable_evidence.sql

Read relevant owning tests, especially those listed in validation. Do not execute
or import repository source from the live checkout.

Useful locators; verify actual text rather than freezing line numbers:
- first-live profile:32-65,67-145,184-216;
- guard:36-62,95-121;
- private values:19-59,584-630,554-564;
- migration 0002:537-566, including required program_ref and closed algebra;
- initialization runtime:196-271, receipt-first apply and readback;
- C2B Section 38:19534-19585, current cross-session recovery gate;
- C1 owner:162-210, commit uncertainty and cleanup-publication limits.

Keep old C2B3 planning-status paragraphs separate from current owning successors
and actual source. Do not broaden this tranche into historical status cleanup.

Before editing, record a compact selected touched-file plan, owner/consumer
mapping, and the family/identity/recovery design. Ordinary engineering choices
are yours to resolve from these constraints, not questions for the user.

## 4. Allowed doc/test surfaces

Create exactly the two new files named at the top.

These existing documents MAY change only for direct ownership routing and
truthful target-versus-implemented status:
 .docs/architecture.md
 .docs/autonomous-software-development-operating-model.md
 .docs/authority-boundaries.md
 .docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md
 .docs/rw0-c2-first-live-proof-posture.md
 .docs/rw0-c2-private-value-versioning.md
 .docs/rw0-c2-durable-progression-decision-semantic-contract.md
 .docs/rw0-remote-worker-contact-phase-entry.md
 .docs/c2b-durable-development-state.md

These existing tests MAY change only for the corresponding direct owner-link or
status assertions, not to change accepted behavior:
 tests/test_rw0_c2_first_live_proof_posture_contract.py
 tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
 tests/test_rw0_c2_private_value_versioning_contract.py
 tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
 tests/test_rw0_remote_contact_phase_entry_contract.py
 tests/test_architecture_contracts.py
 tests/test_autonomous_software_development_operating_model.py
 tests/test_c2b0_durable_state_contract.py

Use the smallest coherent subset, not a target file count. Justify every edit.

Keep AGENTS.md, README.md, all product source, schemas, migrations, configs,
scripts, SQLite administrative/writer-session mechanics, and other tests exact.
Preserve all existing machine inventories, schema IDs, canonical fields/domains,
private owner-assertion profile, and parser logic. In particular, the existing
private-value machine block from its begin marker through EOF remains exact.
The new operation schemas belong to the new owner; do not append them to the
eleven-schema inventory or reinterpret that inventory as all future schemas.

Do not revise first-live gate B or turn its no-restart rule into session-level
failure on every connection refresh. Do not insert supplier conformance into
offline fixture execution. A genuine conflicting governing invariant is a
bounded stop, not permission to weaken its test.

## 5. Authority, inputs, and bootstrap admission

State the author, verifier, recorder, custodian, lifetime, and effect ceiling
for:
- external standing-policy act;
- immutable verified-act safe projection;
- independent incarnation enrollment;
- fresh current permission and custody observations;
- requested recording operation;
- scope-admission fact;
- historical operation verification basis;
- committed result/receipt;
- transient conflict and recovery projections.

External policy authors the act. The future provisioner verifies the act against
its qualified source and records the exact binding. The managed cell provides
custody/sole-incarnation observations. None of these becomes C2 branch,
acceptance, retry, grant-renewal, or enrollment-issuance authority.

Fresh recording requires current authority specifically sufficient for this
bounded recording action, audience/lineage/scope/profile equality, original
enrolled incarnation/storage custody, and applicable stop/revocation/expiry
checks. Enrollment lookup alone is not permission to record. A shaped safe
value or matching digest is not signature or freshness verification.

Bootstrap checks use the independently verified act and live source/custody
premises; requiring an already recorded admission fact here would be circular.
This exception is confined to the provisioning entry. It is not a fallback
inside a C2 decision writer.

Preserve the current UnsupportedAuthorizationProvider's fail-closed behavior.
Select no wire protocol, trust root, provider, or production verifier. Define
required verified logical inputs and their safe projection bindings only.

## 6. One minimal program-independent recording family

Freeze separately versioned logical command, successful result, receipt and
transient conflict/readback forms in the new owner. Use one concise normative
machine inventory and direct human explanation, not duplicated giant registries.

The complete logical committed family contains:
- the exact adopted verified-admission-act safe projection or its fully
  reconstructible retained binding;
- the exact adopted immutable scope-admission fact;
- a safe historical recording basis binding the operation to the enrolled
  incarnation and the current verification evidence used at recording;
- one successful provisioning result;
- one provisioning receipt binding the original command, fact, evidence basis,
  result and original recording time.

These are logical membership requirements, NOT one SQL row/table per role.
The result/basis may be embedded in the receipt; physical normalization is
deferred. Every relied-on safe member must be reconstructible or resolvable
under the qualified custody boundary; an unexplained digest alone is not proof.

Do not persist raw credentials, keys, signatures, private connection objects,
paths, bearer capabilities or full unclassified external messages. Retained safe
evidence is historical observation, never renewed current authority.

No new C2 progression decision, C2 result/receipt/graph role, accepted candidate,
program head/version, external enrollment write, or acceptance fact is produced.
The C2 writer's existing consumption of admission fact ref/digest remains
unchanged. This provisioner's recovery owner classifies only its recording
family, not the subsequent acceptance family.

## 7. Identities, time, and canonical bindings

Define every new field's exact type, origin, equality obligations, nullability
and canonical digest preimage. Reject unknown keys, duplicate JSON keys,
coercion, and bool-as-int. Use repository-compatible safe refs, digest syntax
and canonicalization. Include a small independently authored fixed vector.

The command binds one operation identity, one exact verified act, the intended
lineage/scope/profile/applicability, the expected immutable admission fact
identity/content, and the stable enrollment/incarnation expectations required
by this proof. No program_ref or dummy development identity.

The fact's preassigned admission_fact_ref is a private stable reference, not
an authorization selector or a synonym for its digest. Preserve its existing
meaning. Validate it before recording, bind it to the verified admission basis,
and keep it independent of program, timestamp and recording-operation identity.
Scope/lineage/act collision checks must catch an alternate-ref alias; changing
a proposed fact ref never creates a second allowance. Do not invent an extra
mandatory ref-derivation constraint for the already adopted v1 fact schema.

Keep stable command expectations distinct from fresh verification observations.
Current observation renewal for replay/readback must not change the historical
command, its digest, fact, result or receipt. Retain the evidence used at the
original recording in the historical family; check fresh disclosure posture
separately. Neither a stale grant nor a historical receipt supplies permission
for a new effect.

Use one transaction-owned original recording timestamp for the new family.
The unchanged admission fact has NO timestamp field. Command digest and
precommit lookup identities must not depend on final timestamp/result/receipt.

Give a small acyclic dependency map:
 verified immutable act and preassigned fact expectation
 -> canonical fact identity and recording command
 -> historical operation basis and one chosen recording time
 -> result and receipt family
 -> exact replay/readback.
Separate fresh readback evidence from historical family dependencies.
No reciprocal result/receipt hashes, hidden self-input, or undeclared digest.
Do not choose SQL, physical reader selectors, or production entry signatures.

## 8. Fresh apply and exact replay

Require these stages:
1. command-local structural/identity validation;
2. current recording-or-disclosure authorization and original live custody
   verification, with local writer fencing composed under its own owner;
3. provisioning-receipt lookup for the exact operation;
4. receipt-present exact replay or a no-write identity conflict;
5. receipt-absent exhaustive logical admission-family and alias checks;
6. construction and one atomic commit attempt for the previously absent family.

Receipt-first replay never bypasses current protected-disclosure permission.
Conversely, replay does not demand that a new recording be currently eligible
or rewrite historical evidence to the new clock. Explain the distinct
write-authority and current-readback checks. An act's revocation or expired
current permission cannot delete a committed admission; it can bar fresh
effects and protected disclosure according to the applicable current policy.

Freeze this outcome table:

- Empty target recording slots, exact verified external act, correct enrollment
  and current custody/recording authority: one exact family may be recorded.
  Local absence by itself is never sufficient.
- Same operation ID + different canonical command: no-write identity conflict.
- Same operation ID + same command + complete exact family: return original
  result/receipt/time, no clock or write.
- Same act + different operation ID, even with another proposed fact ref:
  no-write already-recorded/identity conflict, no second receipt; not exact
  replay of the new operation. A protected reference to the existing original
  receipt is evidence only, not a newly committed result.
- Different act, lineage/scope alias, occupied fact identity, or contradictory
  recording basis: no-write conflict.
- Partial/orphan/duplicate/malformed/unreadable original family: fail closed;
  never complete, relabel, repair, or silently adopt fragments.

Name safe, nonoverlapping reason codes owned by this new operation. Explain
invalid input, rejected/no-write, successful record, exact replay and unknown
commit separately. A rejection creates no durable domain event/receipt.

Logical collision coverage must include operation receipt, fact identity,
lineage occupancy, scope occupancy, and verified-act binding. Include any new
preassigned family identity actually introduced. Enumerating only the proposed
fact ref is insufficient. Current initialized but unrelated program state is
preserved; missing admission referenced by an observed downstream family must
not be "repaired" by this operation.

## 9. Commit uncertainty and readback

The local recording-family COMMIT is the recording linearization point.
External enrollment is earlier, unrelated to whether this commit occurred.
There is no cross-store atomicity claim or external arm/settlement.

Before any commit attempt, a provably clean rejection/rollback is no write.
Once commit is attempted, an exception, lost result, or unproved connection/
capability/operation cleanup cannot be called definite noncommit. Preserve
possible commitment until readback proves an outcome.

Successful publication of a result requires the existing transaction and
writer-resource cleanup obligations to have completed. Do not invent a
stronger "method returned means received by caller" guarantee. Detailed Python
exception/cleanup implementation remains with its existing owners/later
integration tranche.

Readback for the original command is read-only and uses:
- valid canonical command/selector coordinates;
- positive CURRENT disclosure authorization and original-incarnation custody;
- a currently admissible fenced local read capability;
- exhaustive original recording-family and collision observations;
- proof that the original execution can no longer append a late commit before
  definite-noncommit is released.

Three outcomes under this provisioning owner:
 committed_exact:
   complete original family, exact command/member/result/receipt bindings;
 definitely_not_committed:
   all prospective original recording slots absent, no fragment/alias/conflict,
   intact original custody and old execution unable to commit;
 unresolved:
   anything partial, inconsistent, unreadable, conflicting, unproved, or with
   lost current custody/old-writer exclusion.

For this first recording contract, a different complete provisioning winner
is a fresh-call conflict and leaves original-operation recovery unresolved.
Do not import the C2 acceptance classifier's competing-winner shortcut.

No result authorizes automatic retry, fragment completion, new operation ID,
new enrollment, new incarnation, or a different admission act. After proven
noncommit a future caller may explicitly resubmit the SAME original command
only when standing policy and all fresh entry requirements authorize it;
recovery itself never performs or schedules that retry. This does not require
a new human approval per attempt.

A fresh concrete WriterSession inside the SAME original authority process may
be usable under existing local acquisition/fencing rules. Do not require the
old resource to reach a superseded X-state before using the actual current
cross-session gate. Do not transplant current generic recovery's
different-process case into first-live proof permission: process/supervisor
restart or storage-custody loss forbids productive resumption.

Content-free unresolved reporting after custody loss cannot disclose an
unverified protected family or synthesize a C2 terminal/cancel/block/noncommit
fact. Proving enrollment still exists is not regaining a live incarnation.

## 10. Scope of preservation and later gates

Keep first-live supplier conformance mandatory before real-custody-dependent
source/runtime work and live RW0-E entry; this doc/test tranche does not pass it.
RW0-D remains independently repeatable offline engineering with explicitly fake
sources/disposable state and no real enrollment, credentials, network or
allowance use. Do not claim it is already implemented.

After acceptance of this semantic owner, remaining separate gates include:
- qualified source/supplier and currentness-envelope contracts/conformance;
- safe provisioning operation values/readset bindings where not already frozen;
- bounded-hybrid physical representation, including additive migration 0005;
- provisioning and guarded-C2 transaction/recovery implementation;
- terminal, offline-process, and live-proof prerequisites under their owners.
Do not start them or prescribe a full-custodian successor by default.

## 11. Finite causal tests; no new assurance framework

Use small hand-authored histories and independently fixed expected results.
A bounded pure test-side recording/readback checker is allowed; no production
writer, SQL engine, general reducer, new Markdown parser, enormous manifest,
or arbitrary minimum node count. Synthetic verified-source premises remain
explicit assumptions, not signature/fencing conformance.

Cover at least these focused histories:
1. Authentic act + live enrolled original incarnation, no local fact or program:
   recording permitted; no program, acceptance or enrollment write.
2. Local empty state or well-formed forged act without verified external
   authority: rejected. Absence of the fact must not cause a circular
   prerequisite for otherwise valid first recording.
3. Two distinct genuinely verified positive fixtures: generic recording rules,
   no hard-coded positive-vector equality.
4. Exact same-command replay preserves fact, receipt and time after fresh
   evidence changes or later downstream program use while original custody and
   current disclosure permission remain valid. It does not recheck whether
   acceptance is unclaimed. New-operation/same-act and alternate-ref aliases conflict.
5. Different command under same operation; foreign lineage/scope/act/profile/
   enrollment/incarnation; occupied target identity: no mutation.
6. One attempted recording, two interleaved requests: at most one committed
   family; identical duplicate gets original result only after complete proof.
7. Failure before commit versus attempted commit/reply lost versus commit
   successful but cleanup/result publication incomplete.
8. Complete original family, exhaustive absent family, and partial/duplicate/
   unreadable/foreign family under same-incarnation readback.
9. Original family absent but old operation may still commit: unresolved;
   only owner-established exclusion plus complete absence supports noncommit.
10. New local writer session in the same original process versus authority or
    supervisor restart: local rules may admit the former, profile denies latter.
11. Act revoked/current permission unavailable: immutable history survives,
    new recording denied, protected readback obeys current authorization.
12. Restore/clone with identical pre-recording bytes and retained enrollment:
    no regained custody or permission; no replacement fact or orphan repair.
13. Readback never retries; separately permitted same-command resubmission after
    definite noncommit creates at most the original requested fact family.
14. Repeated offline fixtures use no real enrollment or supplier and consume no
    live allowance; future C2/terminal/ES ownership remains unchanged.

Add a few direct counterexamples that remove enrollment/custody verification,
permit same-act re-recording under new ID, infer noncommit from missing receipt
alone, authorize restart, or give the provisioner acceptance/enrollment powers.
Hold expected outcomes outside mutated subject structures. Report boundaries
actually reached. Do not reproduce the old private parser mutation campaign.
A simple compatibility assertion of the two preserved act/fact schemas and
their domains is enough; do not clone the entire old verifier.

## 12. Exact validation and preservation

Only execute tests in a fresh local-only external clone from exact HEAD,
overlaid with the complete candidate and with no configured remote. Never
import repository modules or run tests in the live checkout. Use installed
dependencies. Existing tests may create isolated temporary SQLite fixtures,
which are validation effects, not live product migration.

Create a private external root with mode 0700. Keep request/log/temporary files
there. For test processes use normal umask 022; do not apply umask 077 to the
whole suite because permission-negative tests intentionally create unsafe
fixtures. The private parent directory still protects those fixtures.

From the external clone run collection, then execution SERIALly with:
 PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src python3 -m pytest \
   -q -p no:cacheprovider --basetemp=<precreated-external-parent/group>
Add --collect-only for collection. Use different named basetemp paths for each
collect/run invocation. Do not parallelize or leave competing test processes.

A. New test:
 tests/test_rw0_c2_scope_admission_provisioning_contract.py

B. Owning contract regressions:
 tests/test_rw0_c2_first_live_proof_posture_contract.py
 tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
 tests/test_rw0_c2_private_value_versioning_contract.py
 tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
 tests/test_rw0_remote_contact_phase_entry_contract.py
 tests/test_architecture_contracts.py
 tests/test_autonomous_software_development_operating_model.py
 tests/test_c2b0_durable_state_contract.py
 tests/test_sqlite_backend_b0_contract.py
 tests/test_b2a_writer_session_contract.py

C. Full repository with no path arguments.

The merged baseline report was 8,758 passed with three existing writer-session
Python 3.13 fork warnings. Report actual unique collected nodes, changes and
warnings; do not force historic counts or suppress warnings. No word searches
over test names as warning detection.

Additional focused suites only when an inspected dependency justifies them.
Correct external setup errors outside the live checkout, rebuild from the
same exact candidate and rerun cleanly. Candidate defects can be repaired only
inside the authorized doc/test scope. No acceptance credit to failed trials,
unreported skipped work or altered expectations that discard the intended rule.

Run git diff --check; new-file no-index whitespace checks; exact UTF-8/BOM/CR/
trailing-whitespace/final-LF and regular-file/mode checks. No-index status 1
without diagnostics denotes a difference, not a whitespace failure.

Prove noncandidate live bytes and Git-relevant modes match HEAD. Preserve
pre-existing nonexecuting OS mode 0600 where present; don't normalize unrelated
files to 0644. New/touched candidate files should be regular mode 0644.

Inventory only the known live bytecode cache as opaque metadata/hash inputs,
not imports. It previously contained 37 files and their directory. Require
actual member-level path/type/mode/size/mtime/hash equality, not an invented
historical aggregate. Never inspect unrelated ignored sensitive state.

Remove only this task's external clones, fixtures and logs after all validation.
Preserve live cache, databases and user files.

## 13. Inline provenance, closeout, and stops

Opening and closing commit/tree/parent/upstream/worktree count must match, with
zero staged/unmerged paths. Report actual changed/new paths and every justified
existing-file edit.

For each candidate path provide change type, regular-file mode, size, SHA-256
and HEAD blob (null if new), recomputed twice from fresh reads. Exact endpoint
identity and HEAD bind the later audit.

Also provide ONE complete ordered patch recipe, byte count and SHA-256:
- visit actual candidate paths in lexicographic repo-relative order;
- tracked: git diff --binary --full-index --no-ext-diff --no-textconv HEAD -- PATH;
- new: git diff --no-index --binary --full-index --no-ext-diff --no-textconv -- /dev/null PATH;
- concatenate stdout without separators; new-file status 1 is expected.
Recompute twice. Do not change recipes midway or require a new manifest input.

Closeout:
- verdict, visible settings, opening/closing coordinates;
- touched set, endpoint receipts and patch recipe;
- authority mapping and bootstrap/non-circular input check;
- canonical family/identity/time design and unchanged act/fact contracts;
- exact replay/collision/recovery results, same-process session distinction;
- finite histories and counterexamples with actual reached boundaries;
- exact validation commands/results, errors, repairs and skipped work;
- preservation, cleanup and concrete supplier/physical proofs NOT performed;
- continuation capsule <=800 words. No next implementation prompt.

Stop before edits for baseline drift or unavailable primary owners. Stop during
work if an unapproved path, source/SQL/migration change, altered v1 canonical
meaning, new continuity service, enrollment write, restart permission, second
C2 recovery/acceptance owner, or ungrounded verification claim is required.
Preserve useful reasoning; don't paper over contradictory owners.

Restore only this task's identifiable edits if blocked and no concurrent actor
has changed them. Otherwise preserve and report the state; no broad reset.

Success:
 RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_READY_FOR_INDEPENDENT_AUDIT

Blocked:
 RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_BLOCKED

State actual non-actions: no source/schema/migration/config/runtime/public
changes; no supplier qualification or external proof; no enrollment, launch,
fencing, acceptance, worker, ES or Bridge effect; no live DB/import/test/cache
mutation; no network/install/sibling/subagent; no staging/commit/push/PR/merge;
no delivered evidence package. Report external test files/databases truthfully.

Success supports only a fresh independent read-only audit of the exact doc/test
candidate. It authorizes no commit, publication, supplier, source, migration,
deployment, RW0-D implementation or RW0-E execution.
