## Disposition

**Proceed to a fresh independent read-only re-audit of the exact V3 candidate. Do not stage or commit it.**

Codex returned the intended repair outcome:

```text
RW0_C2_SCOPE_ADMISSION_PROVISIONING_CHECKER_REPAIRED_V3_READY_FOR_INDEPENDENT_AUDIT
```

The closeout presents no deterministic pre-audit blocker:

- only `tests/test_rw0_c2_scope_admission_provisioning_contract.py` changed from V2;
- all five candidate documents retained their exact prior receipts;
- the final six-path patch was reproduced twice;
- source, schemas, migrations, configuration, existing tests, and runtime surfaces remain unchanged;
- migration `0005` remains absent;
- the complete repository passed **8,796 tests with the same three expected warnings**.

This is audit-ready, not commit-ready.

## What V3 appears to close

### Exact built-in type enforcement

The earlier audit demonstrated that matching canonical text and hashes were insufficient: a `str` subclass could pass as command `schema_id`, and a subclassed stored receipt `outcome` could be credited as exact replay or committed recovery. Pasted text

V3 now claims to enforce exact field types before equality or digest checks across command and observed-family paths. The intended distinction is:

```text
exact built-in value
    → eligible for later validation

subclass with identical content
    → structurally invalid
```

The independent audit must establish that no encoder, JSON round-trip, `str()`, `dict()`, copy helper, or digest helper converts the hostile subclass into a built-in before the type check.

It should verify the rule across all complete-family entry points—not only fresh command creation. A field checked exactly on apply but only by equality on replay would remain defective.

### Structural shape versus semantic authority

The V2 checker hard-coded `guard_profile` and `applicability` during command validation, so fully resealed mismatches returned generic `invalid_input` before the independent source relation was exercised. Pasted text

V3 reports the corrected sequence:

```text
exact built-in and nonempty-string validation
→ candidate/source/owner semantic relation
→ disclosure gate
→ protected receipt and family reads
```

That is the correct architecture.

For `guard_profile`, a foreign exact nonempty string is structurally valid but must fail because it does not match the independently authored verified source and selected profile.

For `applicability`, another exact nonempty string is also structurally valid at the generic value layer, but remains semantically unsupported because this guard fixes:

```text
admitted_direct_local_bootstrap
```

It must fail at the source/owner authority boundary—not be treated as authorized and not be rejected merely as the wrong Python type.

## Validation reconciliation

The reported collection changes reconcile:

| Surface | V2 | V3 | Delta |
|---|---:|---:|---:|
| Provisioning checker | 27 | 38 | +11 |
| Owning/composition group | 3,208 | 3,208 | 0 |
| Full repository | 8,785 | 8,796 | +11 |

The full count remains:

```text
8,796 = 8,758 merged baseline + 38 provisioning tests
```

The final endpoint and patch reported by Codex are:

```text
V3 checker:
59,562 bytes
b85d061237bb7a8be463c2efacc80a65b13f9dbe8a8a65f0fd148aeff3b5e346

Six-path patch:
91,648 bytes
aece13844db1769ff2167ef8a7ec4966299785d92e474f29fd48d109fefeef43
```

The four transformed copies are useful repair evidence, but the audit should add one further distinction: **source and request agreeing with each other is not sufficient when both violate the fixed owner literal.**

The audit should therefore cover both:

```text
foreign candidate + fixed valid source
```

and:

```text
foreign candidate + coordinated foreign source
```

The second case proves the checker still consults the selected guard-owner profile and applicability, rather than treating source/request agreement as authority.

## Principal re-audit risks

### Type checks may be incomplete or occur too late

The auditor should directly test:

- command `schema_id` subclass;
- command `guard_profile` subclass;
- another command ref/digest subclass;
- observed receipt `outcome` subclass;
- nested act, fact, basis, result, and retained-command subclasses;
- mapping or sequence subclasses where the actual grammar requires exact containers;
- Boolean-as-integer and integer-subclass behavior where applicable.

Command-side failures must happen before source or protected-store access.

Stored-family failures must produce:

```text
apply    → family_unverifiable, no write
readback → unresolved
```

They must never produce exact replay or `committed_exact`.

### The independent source relation must remain independent

The audit should reconstruct A, B, and C subjects independently from the candidate request and verify all three continue to succeed under:

```text
guard_profile = rw0-c2-guard-v1
applicability = admitted_direct_local_bootstrap
```

Expected source values must not be copied from the command being tested, inferred from identifier suffixes, or generated on demand.

### V2 repairs must not have regressed

The re-audit must also reconfirm:

- denied disclosure causes zero protected reads for every stored-state shape;
- read-only replay remains available under valid disclosure after recording permission is revoked;
- missing receipt under read-only permission never triggers a write;
- malformed stored families remain inside closed outcomes;
- different complete provisioning winner remains a fresh conflict and original recovery `unresolved`;
- old-writer exclusion remains necessary for `definitely_not_committed`;
- same-process local-session renewal remains distinct from process or supervisor restart.

## Fresh independent re-audit handoff

Start a **fresh parent-only read-only Codex conversation**, select the highest exposed reasoning setting, and attach nothing.

:chatgpt-content-reference{index="3"}[Download the V3 independent re-audit prompt](sandbox:/mnt/data/Coordinator_RW0_C2_Scope_Admission_Provisioning_V3_Independent_Reaudit_Prompt.txt)

```text
Filename:
Coordinator_RW0_C2_Scope_Admission_Provisioning_V3_Independent_Reaudit_Prompt.txt

Bytes:
23,968

SHA-256:
edda9b22b562208cdf686a96f327473d223adebcc50b22d488ac6fe2fd905b71

Logical lines:
647

Final newline:
present
```

The prompt binds the exact candidate to:

```text
HEAD:
630414faa07f4ac39c4a870a9cc44c7f92d46b80

Tree:
cd81f7cca8b64cb9ff221537257e70e2c5a655a3

V3 checker:
59,562 bytes
b85d061237bb7a8be463c2efacc80a65b13f9dbe8a8a65f0fd148aeff3b5e346

Final six-path patch:
91,648 bytes
aece13844db1769ff2167ef8a7ec4966299785d92e474f29fd48d109fefeef43
```

It requires independent verification of:

- exact six-file provenance and the one-file V2→V3 transition;
- exact built-in typing across command and observed-family paths;
- preservation of hostile subclass objects until the intended validation boundary;
- structural versus semantic profile/applicability handling;
- candidate-to-source equality and fixed owner-literal enforcement;
- coordinated foreign source/request controls;
- independent A/B/C positive sources;
- preservation of all V2 disclosure, source-binding, and malformed-observation repairs;
- five bounded transformed copies;
- exact 38 / 3,208 / 8,796 serial validation;
- member-level live-cache preservation and external cleanup.

Possible verdicts:

```text
RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE

RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_AUDIT_BLOCKED

AUDIT_PROVENANCE_MISMATCH
```

Acceptance would authorize only a separately issued commit and PR publication gate for the exact six audited files. It would not authorize source implementation, migration `0005`, supplier qualification, runtime provisioning, enrollment, launch, recovery runtime, deployment, RW0-D implementation, or RW0-E execution.

Some older uploaded files have expired. They are not needed for this re-audit; re-upload an older original only when a later task requires inspecting its bytes.

**Sources:** Codex’s V3 closeout pasted in this turn; the preceding V2 independent re-audit, particularly its exact-type and profile/applicability findings. Pasted text

**Confidence:** High that V3 is ready for this bounded independent audit. Commit readiness remains unresolved until exact-type coverage, semantic source/owner joins, coordinated foreign-value cases, and all preserved V2 boundaries are independently reproduced.
