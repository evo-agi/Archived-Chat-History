# Governed Execution Coordinator — Scope-Admission Provisioning Contract: Commit and PR Publication Gate

## Mandate and bounded effects

Perform one parent-only commit and pull-request publication gate for the exact
accepted six-path scope-admission provisioning contract candidate below.

Accepted evidence:

`RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE`

This task is publication finalization, not another semantic design or audit
tranche.

The prompt authorizes only, in order:

1. exact local provenance and candidate-byte verification;
2. fresh authenticated read-only verification of the configured GitHub
   repository, remote base, actor, branch rules, selected topic availability,
   and absence of a conflicting PR;
3. staging exactly the six accepted paths;
4. exact staged/index blob and tree verification;
5. serial validation of the staged bytes in one remote-free external clone;
6. one local source commit with the exact message below;
7. one ordinary non-force push of that exact commit to the selected topic
   branch;
8. creation and verification of one open, non-draft PR against `trunk_dev`;
9. cleanup of this gate's task-owned external files.

This task does NOT authorize:

- merge, squash merge, auto-merge, merge queue, or update-branch;
- direct push to `trunk_dev`;
- candidate repair, formatting, documentation changes, or test changes;
- amendment, rebase, reset, cherry-pick, local merge, local squash, checkout,
  branch deletion, tag, release, or deployment;
- source, schema, SQL, migration, config, API, runtime, service, supplier,
  enrollment, launch, fencing, live provisioning, worker, ES, Bridge, RW0-D, or
  RW0-E work;
- dependency installation, sibling repositories, or subagents;
- delivered report, receipt, manifest, patch, package, or snapshot artifact.

Use the highest exposed reasoning setting. Report visible model, reasoning
setting/effort, and permission posture, or `not visible`. Do not seek additional
account or computer access merely to reveal hidden settings. Broad permissions
do not widen this mandate.

Return one substantive INLINE closeout plus a continuation capsule no longer
than 800 words. Request no earlier prompt, audit bundle, JSONL, receipt,
snapshot, or manifest attachment. This prompt is self-contained.

## 1. Exact opening repository and candidate

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Configured origin identity:

`github.com/evo-agi/Governed-Execution-Coordinator`

Required opening local state:

- branch: `trunk_dev`
- HEAD: `630414faa07f4ac39c4a870a9cc44c7f92d46b80`
- tree: `cd81f7cca8b64cb9ff221537257e70e2c5a655a3`
- sole parent: `d070bf05d2e68472e18b1b077259e67864923e8f`
- subject: `docs: freeze RW0-C2 first-live proof posture`
- upstream: `origin/trunk_dev`
- locally observed divergence: `0 ahead / 0 behind`
- exactly one live worktree
- index matches HEAD
- exactly four modified documentation paths and two untracked additions below
- zero staged and unmerged paths
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or unexpected
  lock.

Read `AGENTS.md` first. Use non-mutating Git inspection with optional locks
suppressed where appropriate. Do not fetch or normalize local state before the
opening checks. Local tracking equality is not fresh remote truth.

Require exactly these six candidate endpoints:

| Status | Repository-relative path | Bytes | SHA-256 | HEAD blob |
|---|---|---:|---|---|
| `M` | `.docs/autonomous-software-development-operating-model.md` | 39,708 | `ccca078da9da0eca90d6e0f86bb30dbda9960765276e7737d4af8b66cc9197a1` | `9207ff698920682dc25057a9fc12b9f2a8cb28d7` |
| `M` | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 26,041 | `0ebe519379a689f87a2f6ddabeeede5f96d1c5d4ec8f90373f555f38fc61ca44` | `b737b4feff254e2da5d04151575acfbd06f201f3` |
| `M` | `.docs/rw0-c2-first-live-proof-posture.md` | 15,857 | `ab0c7a57b5807207203c5c31a4ba00b671a4e898264c4e9c1119d3517d959ce3` | `d88c3a6a0ec032e460cbd68c97dfe5b915a0514d` |
| `M` | `.docs/rw0-c2-private-value-versioning.md` | 207,681 | `966a1f5ac158ad6e597aa7922328612d0993e6e8c109f766aedd9ac7cc8bd251` | `54f84052d97d927e8ccc874b39b1fe8aa8596cff` |
| `??` | `.docs/rw0-c2-scope-admission-provisioning-contract.md` | 23,631 | `9af662213b3a9fe51a0c2f12449e46a3a1ea9d3172ac7e3d99ce7ce9fd509449` | absent |
| `??` | `tests/test_rw0_c2_scope_admission_provisioning_contract.py` | 71,224 | `6a9ec185d9595aeb51708c92827fc2798a2ae5497de54fa3e563a20791b7b093` | absent |

All six must be regular, nonsymlink OS-mode `0644` files, strict UTF-8, one
final LF, no BOM, no CR, and no trailing whitespace. The four tracked Git
entries remain mode `100644`. Both additions must be absent from HEAD and the
opening index.

Read each tracked HEAD blob directly. Verify all 240 noncandidate tracked paths
against HEAD by bytes and Git-relevant modes. Preserve any unrelated
pre-existing OS mode such as `0600`; do not normalize all paths to `0644`.

Preserve `AGENTS.md`, `README.md`, source, schemas, migrations, SQL,
configuration, scripts, package exports, and existing tracked tests. Migration
resources remain exactly `0001`–`0004`; `0005` is absent.

Stop before any mutation for baseline, candidate, type, mode, byte, index,
working-state, or path-set drift. Use:

`AUDIT_PROVENANCE_MISMATCH`

Do not repair or adopt another candidate.

## 2. Exact accepted patch identity

Visit the six paths in the table order, which is lexicographic repo-relative
order.

For each tracked path:

```sh
git diff --binary --full-index --no-ext-diff --no-textconv HEAD -- PATH
```

For each new path:

```sh
git diff --no-index --binary --full-index --no-ext-diff --no-textconv -- /dev/null PATH
```

Concatenate exact stdout without separators. A no-index exit status of `1` is
expected.

Required component lengths:

```text
1,435 / 1,230 / 1,425 / 2,162 / 24,271 / 73,038
```

Required patch:

```text
103,561 bytes
SHA-256:
77abc6ae33e52ac907a1d2ce4d3fa2c3710c114ffdb08d5467ad38b0973bdf58
```

Reconstruct twice from fresh reads before staging. Do not invoke external diff
helpers or text conversion. Do not invent a canonical manifest prerequisite.

## 3. Live cache and preservation

Before any authorized mutation, inventory only the known live
`src/ge_nwp_coordinator/__pycache__/` by member path, type, OS mode, size,
nanosecond mtime, and hash for regular files.

The accepted audit observed 37 regular bytecode files plus the directory.
Reconcile actual membership rather than imposing an invented aggregate.

Treat bytecode as opaque data. Never import, move, delete, regenerate, or clean
the live cache. Do not open unrelated ignored operator/product state, secrets,
credentials, or private databases for cleanliness checks.

Require exact live-cache member equality:

- before staging;
- after staging;
- after validation;
- after commit;
- after push/PR creation;
- at closeout.

External test-artifact scans use `lstat` before opening. Hash only regular
files. Never follow symlinks or open FIFOs, sockets, devices, or other special
files.

## 4. Fresh remote and publication-policy preflight

After local provenance passes, use authenticated read-only access only to the
configured origin repository and policy metadata directly relevant to
`trunk_dev` and the selected topic.

Verify:

- configured origin repository identity exactly matches
  `evo-agi/Governed-Execution-Coordinator`;
- authenticated actor identity; use the existing actor and credentials only;
- remote `refs/heads/trunk_dev` still equals
  `630414faa07f4ac39c4a870a9cc44c7f92d46b80`;
- selected topic branch does not exist:
  `codex/rw0-c2-scope-admission-provisioning-v1`;
- no open, closed, or merged PR already uses that exact head branch;
- effective organization/repository/branch rules for `trunk_dev`;
- whether PR publication is required;
- allowed merge methods, required reviews/checks/conversation resolution,
  attribution rules, signing rules, merge queue, bypass posture, and automatic
  source-branch deletion;
- no policy requires a prohibited publication mechanism.

This is a commit/PR gate, not a merge gate. Empty checks or reviews do not block
PR creation unless current publication rules explicitly require something
before branch publication or PR creation.

Do not change actor, credentials, rules, settings, branch protection, signing
configuration, or repository settings. Do not create a token.

If remote trunk has moved, the topic exists, a conflicting PR exists, the actor
is unexpected, origin is wrong, or policy is ambiguous/materially incompatible,
stop before staging or commit:

`RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_COMMIT_GATE_BLOCKED`

Do not fetch, rebase, or adopt a newer base.

Inspect active local Git hooks and signing configuration as data. If an active
hook would execute repository code or create effects outside this mandate, stop
rather than bypass or execute it. Do not alter hook/signing configuration. Use
the existing configured author/committer identity; do not change it to satisfy
attribution policy.

## 5. Stage exactly six accepted paths

Stage exactly:

```text
.docs/autonomous-software-development-operating-model.md
.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md
.docs/rw0-c2-first-live-proof-posture.md
.docs/rw0-c2-private-value-versioning.md
.docs/rw0-c2-scope-admission-provisioning-contract.md
tests/test_rw0_c2_scope_admission_provisioning_contract.py
```

No pathspec broadening. No `git add -A`, `git add .`, or interactive staging.

After staging require:

- exactly four `M` and two `A` stage-0 index entries;
- no unstaged, untracked, unmerged, intent-to-add, skip-worktree, assume-unchanged,
  or alternate-stage candidate state;
- all noncandidate index entries equal HEAD;
- staged blobs equal the accepted working bytes, sizes, SHA-256 values, modes,
  and computed Git blob OIDs;
- `git diff --cached --check` passes;
- working files equal their staged blobs;
- the accepted full patch identity remains exact.

Write and record the staged tree with ordinary Git plumbing as needed. Object
database writes from staging and tree creation are authorized. No source commit
exists yet.

Any mismatch after staging is a commit-gate block. Do not repair, restage other
bytes, or reset broadly. If safe, unstage only this gate's exact six paths and
report the actual state; otherwise preserve and report it.

## 6. Validate exact staged bytes

Build one fresh local-only external clone from exact baseline HEAD with no
configured remote. Populate the six candidate paths from the staged index blobs,
not from an independently edited approximation.

Verify the external clone's complete 246-file endpoint set against:

- HEAD for all 240 noncandidate tracked paths;
- staged blobs and modes for the six candidate paths.

Use installed dependencies only. No network, installation, or live-checkout
import/test/database access.

Create one task-owned external root mode `0700`. Use test-process `umask 022`.
Precreate distinct basetemp parents. Run collection then execution serially:

```sh
set -euo pipefail
umask 022
mkdir -p "$GATE_ROOT/basetemps"

run_group() {
  local label="$1"
  shift
  PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src     python3 -m pytest -q -p no:cacheprovider     --basetemp="$GATE_ROOT/basetemps/${label}-collect"     --collect-only "$@"
  PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src     python3 -m pytest -q -p no:cacheprovider     --basetemp="$GATE_ROOT/basetemps/${label}-run"     "$@"
}

run_group provisioning   tests/test_rw0_c2_scope_admission_provisioning_contract.py

run_group owning_contracts   tests/test_rw0_c2_first_live_proof_posture_contract.py   tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py   tests/test_rw0_c2_private_value_versioning_contract.py   tests/test_rw0_c2_durable_progression_decision_semantic_contract.py   tests/test_rw0_remote_contact_phase_entry_contract.py   tests/test_architecture_contracts.py   tests/test_autonomous_software_development_operating_model.py   tests/test_c2b0_durable_state_contract.py   tests/test_sqlite_backend_b0_contract.py   tests/test_b2a_writer_session_contract.py

run_group full
```

Required accepted results:

```text
provisioning:     54 unique collected / 54 passed
owning contracts: 3,208 unique collected / 3,208 passed
full repository:  8,812 unique collected / 8,812 passed
```

Require:

- unique node IDs;
- first two groups disjoint;
- both included in full;
- `8,812 = 8,758 + 54`;
- exactly the three known Python 3.13 multithreaded-fork
  `DeprecationWarning` records attached to:
  - `test_operation_guard_close_waits_and_retains_authority_until_exit`
  - `test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang`
  - `test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock`.

Do not run the prior hostile-copy audit again. Do not expand the suite, change
tests, suppress warnings, delete tests, use xdist, parallelize, or overlap
groups.

A clearly identified external runner/setup error may be corrected only outside
the live checkout. Rebuild the external clone from the same staged blobs and
rerun every affected required gate. Give failed trials no acceptance credit.
A candidate/test failure blocks publication; no candidate repair is authorized.

After testing:

- verify all 246 clone endpoints still match the staged/HEAD manifest;
- classify task-owned artifacts with `lstat`, opening only regular files;
- remove only the positively identified task-owned external root after all
  processes terminate;
- verify the external root is gone;
- recheck live index, working bytes, patch identity, noncandidate bytes, and
  cache equality.

## 7. Create one exact local commit

Use exact subject:

```text
docs: freeze RW0-C2 scope admission provisioning
```

Use exact body, excluding its terminal LF in this block:

```text
Adopt the target-only program-independent scope-admission recording contract
and its bounded causal checker.

Preserve external standing-policy authorship, independent enrollment and
original-incarnation custody, the unchanged verified-act and admission-fact
meanings, and Coordinator ownership of the separate recording result, receipt,
exact replay, and readback-only recovery.

This change implements no source provider, admission provisioner, SQL schema,
migration 0005, guarded decision writer, recovery runtime, public API, RW0-D/E
execution, supplier qualification, or Execution Substrate integration.

Audit:
RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE
```

Source commit message equals:

```text
subject + two LF bytes + body + one final LF
```

Required raw source message:

```text
743 bytes
SHA-256:
f6baa313f1663c50f7c62f37ea0f95dfd2741e9f3cc1a9e2e94d614165010b48
```

Body without final LF:

```text
692 bytes
SHA-256:
a2b4afc4aa3b4738cf733ef01589ec4b2e0559e9692760594d067ba685e23a62
```

Body with one final LF:

```text
693 bytes
SHA-256:
6c2b983bc0a7e43f6527f4bebf9d7c639a6f00cda415308c371ce4f8be14c55c
```

Create exactly one local commit on the checked-out `trunk_dev`.

Require:

- sole parent equals opening HEAD;
- tree equals the verified staged tree;
- exactly the six accepted path effects;
- all staged blob OIDs and modes preserved;
- all noncandidate tree entries equal the parent;
- exact raw message bytes;
- configured author/committer identity accurately reported;
- signing status accurately reported;
- no amendment.

After commit require:

- local `trunk_dev` and HEAD equal the new source commit;
- index and working tree are clean;
- upstream remains `origin/trunk_dev`;
- divergence is `1 ahead / 0 behind`;
- local `origin/trunk_dev` still equals the opening baseline;
- cache remains unchanged.

If commit creation reports an error or ambiguous result, inspect HEAD, reflog,
tree, and index read-only. Do not retry. If the exact intended commit exists,
verify it and continue only with the remaining not-yet-performed steps.
Otherwise return the incomplete status below.

## 8. Push once to the exact topic

Selected topic branch:

```text
codex/rw0-c2-scope-admission-provisioning-v1
```

Immediately before push, re-read remote `trunk_dev` and confirm it still equals
the opening parent. Reconfirm the topic remains absent and no conflicting PR
exists. Reconfirm local commit/tree/message/cleanliness/cache.

Perform exactly one ordinary, non-force push of the exact commit:

```sh
git push origin <SOURCE_COMMIT>:refs/heads/codex/rw0-c2-scope-admission-provisioning-v1
```

Do not push local `trunk_dev` to remote `trunk_dev`. Do not use force, force with
lease, atomic multi-ref push, tags, or alternate topics.

If the push response is ambiguous, use bounded read-only remote ref inspection.
Do not retry. If the topic now equals the exact source commit, continue. If it
does not, preserve the local commit and report publication incomplete.

After push require:

- remote topic equals exact source commit;
- remote `trunk_dev` still equals the baseline;
- no unrelated remote ref was moved;
- local tree/index/worktree/cache unchanged.

## 9. Create one exact non-draft PR

PR base:

```text
trunk_dev
```

PR head:

```text
codex/rw0-c2-scope-admission-provisioning-v1
```

Exact PR title:

```text
docs: freeze RW0-C2 scope admission provisioning
```

Exact PR body, including one terminal LF:

```markdown
## Summary

- adopt the target-only program-independent scope-admission provisioning contract
- record an already externally authorized admission without creating a development program or widening the existing program-bound receipt algebra
- preserve the unchanged verified-admission-act and scope-admission-fact meanings
- keep enrollment, current custody, C2 progression, productive acceptance, and terminal ownership separate
- define exact replay, no-write conflicts, and readback-only three-way recovery for the admission-recording family

## Validation

Validated exact candidate bytes in a remote-free local clone, serially:

- provisioning contract checker: 54 passed
- ten owning and composition contract files: 3,208 passed
- complete repository: 8,812 passed, with 3 unchanged writer-session fork warnings

The prior independent audit accepted the bounded target documentation and synthetic checker. It does not qualify an external source, custody supplier, storage layout, or runtime implementation.

## Non-implementation

No product source, schema, SQL, migration, configuration, supplier, service,
deployment, admission provisioner, guarded decision writer, recovery runtime,
terminal implementation, public API, RW0-D implementation, RW0-E execution, or
Execution Substrate integration is introduced.

Audit:
`RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE`
```

Required body with final LF:

```text
1403 bytes
SHA-256:
742e00879a5e88a4e1f1ef84901c2df8e1fe7e28bc37ab52f53472f87e0e3bd7
```

The only permitted API representation difference is omission of the single
terminal LF. If omitted, compute and report the exact no-final-LF length/hash.
No other text, generated source list, co-author trailer, PR number suffix,
labels, assignees, reviewers, milestone, project, or metadata change is allowed.

Create one open, non-draft PR. Do not enable auto-merge or a merge queue. Do not
request reviews, approve, resolve conversations, or trigger workflows.

If PR creation response is ambiguous, perform bounded read-only lookup by exact
repository/head/base. Do not issue another create request. Continue only if
exactly one PR with the required identity and text exists.

Verify by readback:

- exact repository and PR identity/number/node ID;
- OPEN, non-draft, unmerged;
- base `trunk_dev`;
- exact topic head and source OID;
- exactly one source commit;
- exactly six changed files with complete effects;
- complete source tree equals the local source tree;
- exact title and permitted body representation;
- no auto-merge or queue entry;
- no unexpected labels, assignees, reviewers, milestones, projects, or branch
  deletion;
- remote topic preserved at source commit;
- remote trunk unchanged.

Read and report immediate mergeability/check/review state as observation only.
Empty check/review inventories are not CI success and do not authorize merge.

## 10. Stop rules and closeout tokens

Before a source commit exists:

- provenance mismatch:
  `AUDIT_PROVENANCE_MISMATCH`
- policy, remote-base, actor, topic/PR collision, hook/signing conflict, staging
  mismatch, validation failure, or other precommit block:
  `RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_COMMIT_GATE_BLOCKED`

After the exact local commit exists, if push or PR publication remains
incomplete:

`RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_COMMITTED_PUBLICATION_INCOMPLETE`

Do not amend, delete, reset, or hide the exact local commit.

Success requires the exact local commit, exact remote topic, exact open
non-draft PR, clean local tree/index, unchanged remote trunk, preserved cache,
and no unauthorized effect:

`RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_COMMITTED_AND_PR_OPENED`

## 11. Inline closeout

Return:

1. primary outcome and visible settings;
2. opening local and fresh remote/policy coordinates;
3. exact six-file opening/staged/committed table with mode, bytes, SHA-256,
   parent blob, staged/committed blob;
4. staged tree identity and unaffected-tree proof;
5. exact staged-byte validation commands, node counts, warnings, failed trials,
   corrections, and cleanup;
6. source commit OID, tree, parent, raw-message coordinates, identity, and
   signing status;
7. exact push command, response, remote topic/trunk readback, and push count;
8. PR number/URL/node ID, title/body form, exact base/head/source, file/tree
   effects, draft/merge state, and immediate check/review observations;
9. final local branch/upstream/divergence/status/cache state;
10. all temporary effects and actual non-actions;
11. continuation capsule no longer than 800 words.

A successful publication records only the accepted target documentation and
bounded synthetic checker. It does not qualify a source or supplier, implement
admission provisioning, create migration `0005`, activate a runtime, enroll or
launch an incarnation, execute RW0-D/E, or authorize merge. A separate,
explicitly authorized merge gate is required.
