## Disposition

**Accept the audit block. Repair only the new provisioning checker/test module; keep all five candidate documents unchanged. Do not stage or commit.**

The audit reproduced exact provenance and all required validation, but found three concrete failures in the synthetic checker. It found **no separate authority drift in the governing prose or routing edits, and no production-source defect**. The narrow next step is therefore a one-file evidence repair—not another contract or continuity-architecture tranche. Pasted text

## The three findings

### 1. Recording permission incorrectly permits receipt-derived disclosure — P1

With recording permission enabled and disclosure permission disabled, the checker can inspect an existing receipt and return either:

```text
operation_identity_conflict
family_unverifiable
```

Those outcomes reveal protected stored-state information even though no write occurs. Both audit specimens should instead receive the existing content-free `recording_authority_unavailable` refusal. The reported defect is in `_entry`/`_apply` ordering, not merely the final error label. Pasted text

**The repair must put the disclosure gate before receipt lookup, family inspection, and alias scans.** A small instrumented or fail-on-read test store should prove that the unauthorized path never reaches those reads. Returning a generic error *after* inspecting the receipt would not establish the required boundary.

The converse must remain intact: current disclosure permission can authorize exact replay or readback even when new-recording permission is unavailable. The repair must not require both permissions for every operation or turn historical replay into a new-recording eligibility check.

### 2. The positive source premise does not identify what was verified — P1

The auditor supplied a valid, resealed act/fact for **lineage B**, combined with enrollment and custody references belonging to **source A**. The checker recorded a family because its authentication premise was a Boolean and the remaining source check matched reference suffixes rather than the act-to-enrollment relationship. Pasted text

**The synthetic source needs explicit, independently authored subjects.** The checker must join the supplied act, fact, and command to the independently verified lineage, scope, profile, enrollment, incarnation, and original-custody observations required by the existing owner.

This does not call for implementing signatures or a supplier. A synthetic authentication premise is legitimate for these tests; an **unbound** premise cannot demonstrate which act and lineage it authenticates.

The negative control must keep source A fixed while resealing candidate-owned B values. A separate, independently valid B source must still succeed. The auditor already demonstrated a third valid source C, so the repair should preserve generic behavior rather than introduce an A/B allowlist. Pasted text

### 3. A malformed orphan escapes the readback classifier — P2

When the original receipt is absent, `_readback` invokes `_aliases` on an observed family without first validating the shape needed for alias extraction. An orphan missing its act mapping raises `KeyError` instead of producing `unresolved`.

The existing `fragments=True` case does not exercise this actual malformed-member path. Pasted text

**The repair must validate observed member shape before extracting aliases.** Tests should supply the malformed mapping itself—not a flag that bypasses inspection—and reach readback under valid disclosure and custody premises.

This should not become a blanket `except Exception: return unresolved`. Explicit malformed-observation handling must preserve programming-error visibility, avoid filling missing fields with defaults, and never reinterpret unclassifiable evidence as absence.

## Preserve the sound parts

The audit independently found the governing design coherent: noncircular initial recording, program independence, unchanged act/fact meanings, an acyclic canonical family, receipt-first replay, and separate provisioning recovery. In particular, **a different complete provisioning winner remains a fresh-call conflict and leaves original-operation recovery `unresolved`**. It must not inherit the C2 acceptance classifier’s competing-winner shortcut. Pasted text

Those surfaces should remain fixed. The new checker should enforce them, not redefine them.

The validation result also remains useful evidence:

| Gate | Independently reproduced result |
|---|---:|
| New provisioning module | 18 passed |
| Ten owning/composition contract files | 3,208 passed |
| Complete repository | **8,776 passed, 3 existing warnings** |

The audit found no skips or test corrections, and all live candidate, noncandidate, and cache bytes were preserved. These passing suites do not outweigh the direct counterexamples; they establish the regression baseline for the repair. Pasted text

## Two evidence qualifications—not reasons to expand the tranche

The test described as an “interleaving” actually exercises a second request **after** a modeled commit with lost response. The pending interval received audit-oracle-only coverage. The repair should correct misleading names or comments and retain that limitation explicitly. It should not grow a scheduler, transaction simulator, or general concurrency framework to manufacture a broader proof. Pasted text

The auditor’s FIFO incident was a **post-test inventory-scanner error**, not a test failure. The corrected scanner used `lstat` before opening regular files, and cleanup completed. The repair handoff carries that precaution forward: classify special files without opening them, and never follow fixture symlinks outside the task-owned root. Pasted text

## Codex handoff

Resume the **same implementation Codex conversation**, with the parent as the sole writer and the highest exposed reasoning setting. No attachments are required.

:chatgpt-content-reference{index="11"}[Download the complete V2 provisioning-checker repair prompt](sandbox:/mnt/data/Coordinator_RW0_C2_Scope_Admission_Provisioning_Checker_Repair_V2_Prompt.txt)

```text
Bytes: 29,419
Lines: 527
Final newline: present

SHA-256:
5f8e9ed8dca96ddd44e1e593637083078badb1d6a3c7d6d7d5b230694fb56016
```

The **only permitted changed file** is:

```text
tests/test_rw0_c2_scope_admission_provisioning_contract.py
```

All five candidate documents—including the new provisioning owner—must retain their exact opening bytes. The prompt binds the repair to:

```text
HEAD:
630414faa07f4ac39c4a870a9cc44c7f92d46b80

Tree:
cd81f7cca8b64cb9ff221537257e70e2c5a655a3

Opening verifier:
35,014 bytes
01bf5a93ee151399911f784f5f00b90b0d4c372d02fd2f2c225e0877d7237de5

Opening six-path patch:
66,560 bytes
90065f492ed1667d3ad4fd83a72e4effd23bdf1bdb0562ad8c126f208218f7fc
```

It includes the complete six-file receipt table, the existing full-index patch recipe, all three counterexamples, the one-file ceiling, and the exact serial validation commands.

The repair evidence is deliberately bounded: permanent direct specimens, one targeted checker regression per finding, and two small compositions. One composition combines denied disclosure with a malformed orphan to verify that permission is checked first. The other combines renewed replay evidence with a foreign source binding to verify that freshness does not relax stable identity checks.

Successful closeout is:

```text
RW0_C2_SCOPE_ADMISSION_PROVISIONING_CHECKER_REPAIRED_V2_READY_FOR_INDEPENDENT_AUDIT
```

A bounded stop is:

```text
RW0_C2_SCOPE_ADMISSION_PROVISIONING_CHECKER_V2_REPAIR_BLOCKED
```

If the actual owner contradicts this repair or another file must change, Codex must stop rather than silently widen the tranche.

Success supports only a **fresh provenance-bound independent read-only re-audit**. It authorizes no commit, publication, source implementation, migration, supplier qualification, provisioning runtime, enrollment, launch, RW0-D implementation, or RW0-E execution.

**Evidence boundary:** I read the attached audit and its issued scope, checked the relevant original tranche requirements, and corroborated the four baseline blob identities against the mounted October 14 snapshot. I did not inspect or execute the live modified checker or independently reproduce the audit’s probes. The generated handoff was reopened and checked for exact receipts, paths, and validation selections.

**Sources:** The attached independent audit, especially its three findings and bounded continuation; the issued provisioning contract and audit mandates. Pasted text Pasted text Some older uploads have expired; re-upload an older original when a later comparison requires its bytes. The current report and mandates were readable.

**Confidence:** High on accepting the audit block and selecting a checker-only repair. The sufficiency of the repaired bytes remains subject to fresh independent audit; concrete source authentication and custody conformance remain separate, unperformed gates.
