# Governed Execution Coordinator — Scope-Admission Provisioning: V4 Checker Repair

## Mandate

Resume the implementation conversation that owns the uncommitted six-path
scope-admission provisioning candidate.

Repair only the new synthetic checker/test module after the V3 independent
re-audit returned:

`RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_AUDIT_BLOCKED`

The audit established exact candidate provenance, independently preserved the
V2 and V3 repairs, and passed the required 38 / 3,208 / 8,796 test groups. It
found two remaining Medium-severity checker-evidence defects:

1. the independently supplied source-observation wrapper types are checked, but
   their scalar fields are compared by ordinary equality before exact built-in
   type validation; a hostile `str` subclass can therefore satisfy or bypass
   selected profile/applicability comparisons;
2. the synthetic transaction-owned `recorded_at` value is copied into a fresh
   family and appended before its exact whole-second UTC grammar is validated;
   both a `str` subclass carrying valid text and the built-in string
   `not-a-timestamp` can receive the fresh success label.

The owning documentation already requires exact built-in fields, qualified
source verification, and one exact transaction-owned recording timestamp.
The audit found no documentation, authority, product-source, migration, or
operating-model defect requiring amendment.

This is a ONE-FILE TEST/CHECKER repair. Do not modify any document or existing
tracked test. Do not implement product source, SQL, migration 0005, a provider,
supplier, service, runtime, public API, or live proof.

The parent is the sole writer. No subagents. Use the highest exposed reasoning
setting and report visible model, reasoning effort, and permission posture, or
`not visible`. Do not seek additional account/computer access merely to expose
hidden settings.

Return one substantive INLINE closeout and a continuation capsule no longer
than 800 words. Do not deliver a report, manifest, receipt, patch, snapshot, or
package. Disposable external validation material is permitted and must be
removed. Do not issue a later implementation prompt.

## 1. Exact committed baseline

Repository:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed coordinates:

- branch: `trunk_dev`
- HEAD: `630414faa07f4ac39c4a870a9cc44c7f92d46b80`
- tree: `cd81f7cca8b64cb9ff221537257e70e2c5a655a3`
- sole parent: `d070bf05d2e68472e18b1b077259e67864923e8f`
- subject: `docs: freeze RW0-C2 first-live proof posture`
- upstream: `origin/trunk_dev`
- locally observed divergence: `0 ahead / 0 behind`
- exactly one live worktree
- index matches HEAD
- zero staged or unmerged paths
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or unexpected
  lock.

Read `AGENTS.md` first. Use non-mutating Git inspection with optional locks
suppressed where appropriate. Do not fetch, normalize the checkout, change
configuration, or discard another actor's work. Tracking equality is not fresh
remote truth.

Stop before editing on any baseline, index, path-set, endpoint, type, mode,
byte, or patch mismatch.

## 2. Exact opening V3 candidate

Require exactly four tracked documentation modifications and two untracked
additions.

All six endpoints must be regular, nonsymlink, OS mode `0644`, strict UTF-8,
one final LF, no BOM, no CR, and no trailing whitespace. The four tracked Git
entries remain mode `100644`. Both additions remain absent from HEAD and index.

| Status | Repository-relative path | Bytes | SHA-256 | HEAD blob |
|---|---|---:|---|---|
| `M` | `.docs/autonomous-software-development-operating-model.md` | 39,708 | `ccca078da9da0eca90d6e0f86bb30dbda9960765276e7737d4af8b66cc9197a1` | `9207ff698920682dc25057a9fc12b9f2a8cb28d7` |
| `M` | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 26,041 | `0ebe519379a689f87a2f6ddabeeede5f96d1c5d4ec8f90373f555f38fc61ca44` | `b737b4feff254e2da5d04151575acfbd06f201f3` |
| `M` | `.docs/rw0-c2-first-live-proof-posture.md` | 15,857 | `ab0c7a57b5807207203c5c31a4ba00b671a4e898264c4e9c1119d3517d959ce3` | `d88c3a6a0ec032e460cbd68c97dfe5b915a0514d` |
| `M` | `.docs/rw0-c2-private-value-versioning.md` | 207,681 | `966a1f5ac158ad6e597aa7922328612d0993e6e8c109f766aedd9ac7cc8bd251` | `54f84052d97d927e8ccc874b39b1fe8aa8596cff` |
| `??` | `.docs/rw0-c2-scope-admission-provisioning-contract.md` | 23,631 | `9af662213b3a9fe51a0c2f12449e46a3a1ea9d3172ac7e3d99ce7ce9fd509449` | absent |
| `??` | `tests/test_rw0_c2_scope_admission_provisioning_contract.py` | 59,562 | `b85d061237bb7a8be463c2efacc80a65b13f9dbe8a8a65f0fd148aeff3b5e346` | absent |

The opening test module is the independently audited V3 endpoint. Earlier
checker bytes are not required.

### Exact opening patch

Visit the six paths in table order.

Tracked paths:

```sh
git diff --binary --full-index --no-ext-diff --no-textconv HEAD -- PATH
```

New paths:

```sh
git diff --no-index --binary --full-index --no-ext-diff --no-textconv -- /dev/null PATH
```

Concatenate exact stdout without separators. Exit status `1` for the two
no-index commands is expected.

Required component lengths:

```text
1,435 / 1,230 / 1,425 / 2,162 / 24,271 / 61,125
```

Required opening patch:

```text
91,648 bytes
SHA-256:
aece13844db1769ff2167ef8a7ec4966299785d92e474f29fd48d109fefeef43
```

Reconstruct twice from fresh reads. Do not invoke external diff helpers or text
conversion. No canonical manifest is required.

## 3. One-file mutation ceiling

Only this file may change:

`tests/test_rw0_c2_scope_admission_provisioning_contract.py`

The five candidate documents must remain byte-identical to the table above.

Every noncandidate tracked path must remain byte-identical to HEAD with unchanged
Git-relevant mode. Do not modify:

- any documentation;
- `AGENTS.md` or `README.md`;
- existing tracked tests;
- product source;
- schemas;
- migrations;
- SQL;
- scripts;
- configuration;
- package exports.

The private-value machine block and its existing verifier/parser remain exact.
Migration resources remain `0001`–`0004`; `0005` remains absent.

No staging, commit, push, PR, merge, branch switch, reset, rebase, network,
installation, credential, supplier, enrollment, launch, fencing, live
provisioning, worker, ES, Bridge, RW0-D/E, sibling-repository, or subagent
effect.

Test-local helpers and fixtures may be refactored only to enforce the already
selected contract.

## 4. Re-grounding and preservation

Read both new candidate files fully and compare the four tracked document edits
to HEAD.

Inspect the exact V3 checker, especially:

- source observation wrapper classes and every scalar field;
- source/profile/applicability relation;
- exact-field validation and all callers;
- transaction-time selection/argument;
- family construction and append;
- replay and readback paths;
- V2/V3 permanent regressions and transformed-copy fixtures.

Consult the owning documents:

- `.docs/rw0-c2-scope-admission-provisioning-contract.md`
- `.docs/rw0-c2-private-value-versioning.md`
- `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md`
- `.docs/rw0-c2-first-live-proof-posture.md`
- `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
- current writer-session/recovery owner sections as compatibility evidence.

Before editing, record a compact diagnosis and one-file plan. Resolve ordinary
helper/test design without asking the user.

Preserve every prior repair and selected rule:

- disclosure permission gates protected receipt/family/alias reads;
- recording-only permission cannot reveal protected stored-state classes;
- read-only exact replay/readback remains distinct from fresh recording;
- A/B/C source subjects are independently authored;
- candidate/source profile and applicability bindings plus fixed owner literals
  are enforced before protected reads;
- malformed observed members remain inside closed apply/readback outcomes;
- exact built-in types are enforced across command and stored-family values;
- same operation + same command + complete original family is the only replay;
- same act under a different operation or alternate fact reference is conflict;
- different complete provisioning winner leaves original recovery unresolved;
- late-writer exclusion remains required for definite noncommit;
- same-process local session renewal remains distinct from forbidden restart.

## 5. Finding 1 — exact types for source-observation scalars

### Scope

The V3 checker validates the source wrapper classes but compares their scalar
fields by ordinary equality. A hostile scalar subclass with custom equality can
therefore satisfy candidate/source equality or the selected owner literal.

Inventory every field of every independent source/policy/enrollment/custody/
evidence observation used by the checker. Derive its exact built-in type from
the synthetic schema and owning contract.

At minimum cover:

- verified act identity;
- verified act content digest;
- lineage;
- scope;
- guard profile;
- applicability;
- audience;
- recording permission;
- disclosure permission;
- enrollment identity;
- incarnation identity;
- original-state/custody refs and digests;
- any source status or evidence coordinate used by the relation.

Use exact checks:

```python
type(value) is str
type(value) is bool
type(value) is int
type(value) is dict
type(value) is list
```

as applicable. Do not use `isinstance` for canonical source fields.

Perform exact-type and closed-shape validation before:

- any candidate/source equality;
- any selected owner-literal comparison;
- any canonicalization or digest helper;
- disclosure gating that depends on source permission;
- protected store access or family construction.

A malformed source observation must return the existing content-free
source/recording-authority refusal, with no protected read or write. It must not
escape a custom comparison result or raw exception.

Do not create a production attestation schema or modify owner documents.

### Hostile source specimens

Use subclasses that retain valid-looking text and, where useful, override
equality so ordinary comparison would pass.

At minimum test:

1. source `guard_profile` as a `str` subclass containing the selected literal;
2. source `guard_profile` subclass carrying a foreign value but comparing equal
   to the selected literal;
3. source `applicability` as a subclass containing the selected literal;
4. source `applicability` subclass carrying a foreign value but comparing equal
   to the selected literal;
5. source act identity or digest as a subclass matching the candidate value;
6. source lineage or scope as a subclass matching the candidate;
7. source enrollment/incarnation/custody scalar as a subclass;
8. wrong built-in type for a Boolean permission or other non-string scalar.

Required result:

- content-free `recording_authority_unavailable`;
- no protected source-to-store transition beyond the source validation itself;
- zero receipt/family/alias reads;
- zero family construction, clock use, or append;
- no raw comparison/field exception.

Exact built-in source values continue to work.

### Positive and semantic controls

Preserve A/B/C independently authored positive sources under:

```text
guard_profile = rw0-c2-guard-v1
applicability = admitted_direct_local_bootstrap
```

Preserve V3 cases where:

- candidate and fixed source disagree on profile/applicability;
- candidate and a coordinated foreign source agree with each other but violate
  the fixed owner literal.

Those exact built-in mismatches remain semantic authority refusals, distinct
from source-type failures.

## 6. Finding 2 — transaction-owned timestamp validation

### Derive the exact grammar

Read the provisioning owner’s actual `recorded_at` field definition and fixed
vector. Enforce its exact existing grammar without changing documentation.

At minimum the value must be:

- exact built-in `str`;
- the owner-defined canonical whole-second UTC representation;
- a real valid timestamp under that representation;
- round-trippable to the identical canonical text;
- free of unsupported fractional seconds, offsets, case variants, whitespace,
  or impossible calendar/time components when those are excluded by the owner.

Do not invent a new timestamp format. Use the exact owner-selected one.

### Fresh-write ordering

The transaction-owned time is not a command field and is not replay authority.

For a fresh recording path:

```text
command/source/disclosure/custody checks
→ protected receipt/family/alias reads
→ establish fresh recording is otherwise eligible
→ choose one transaction-owned time
→ validate that time
→ construct result/receipt/family
→ append one family
```

The selected time must be validated before it is copied into any family member,
before a success result is returned, and before append/write.

An invalid selected time must:

- produce no `scope_admission_recorded` result;
- construct no complete family credited as valid;
- append nothing;
- mint no receipt/result/timestamp;
- return an existing safe no-write checker outcome consistent with the current
  taxonomy;
- expose no raw parser exception.

Do not add a new durable reason code or modify the owner contract merely for the
synthetic checker.

### Replay/readback distinction

Exact replay and readback return the original stored timestamp. They must not
choose, validate, substitute, or depend on a new transaction time.

If the checker helper signature carries a synthetic time argument for all
paths, prove that:

- exact replay ignores it and returns the original family/time;
- readback ignores it;
- an invalid fresh-time argument cannot override or corrupt an existing family;
- only a fresh family construction consumes the selected time.

### Hostile time specimens

At minimum test:

1. a `str` subclass containing the exact valid timestamp text;
2. built-in `str` value `not-a-timestamp`;
3. each materially distinct owner-invalid boundary form confirmed from the
   actual grammar, such as unsupported fractional seconds, unsupported offset,
   wrong case, surrounding whitespace, or impossible calendar values;
4. valid exact built-in canonical timestamp;
5. exact replay with an invalid newly supplied time still returns the original
   stored time and performs no write;
6. readback with an invalid newly supplied time still classifies the stored
   family from its original timestamp;
7. fresh recording with invalid time under otherwise fully valid A/B/C source
   premises never appends.

Instrument family construction and append so the test proves ordering rather
than merely checking the final label.

## 7. Immediate interactions

Add only bounded interactions needed for these repairs:

1. source profile subclass + exact stored family:
   source-type refusal before protected reads;
2. source applicability subclass + valid disclosure:
   source-type refusal before protected reads;
3. source permission wrong built-in type:
   no disclosure/store access;
4. valid source + invalid fresh timestamp + empty eligible store:
   no family construction or append;
5. valid source + invalid fresh timestamp + exact existing family:
   exact replay returns original family/time and ignores the new time;
6. disclosure denied + invalid fresh timestamp:
   content-free disclosure refusal occurs before time selection/validation;
7. renewed evidence for the same stable subjects + invalid fresh timestamp on
   a genuinely fresh eligible operation:
   stable source binding passes, timestamp boundary rejects without write.

Keep expectations outside the helper path being tested.

Do not add a general schema engine, timestamp library abstraction, prose parser,
or large field-fuzz campaign.

## 8. Transformed-copy evidence

Create a small set of disposable transformed copies of the exact final checker.

At minimum:

1. relax source scalar exact typing to `isinstance(value, str)`;
2. remove source exact-type validation for `guard_profile`/`applicability`;
3. compare source scalars before exact-type validation;
4. bypass transaction-time validation entirely;
5. change timestamp validation to accept any nonempty string;
6. coerce the selected time through `str(...)` before validation;
7. validate the timestamp only after append or after the success result is
   formed.

For each transformed copy:

- keep fixed expected specimens unchanged;
- require normal parse/import/collection;
- require semantic failure at the intended permanent regression;
- credit no syntax, import, or collection failure.

Report permanent tests, direct hostile specimens, transformed copies, and any
outside-oracle evidence separately.

The mutable checker cannot authenticate arbitrary coordinated edits to itself
and all expectations. Exact-byte independent re-audit owns that boundary.

## 9. Validation

All executable work occurs in a fresh local-only external clone of exact HEAD
overlaid with the six candidate files. Remove its configured remote. Do not
import, test, compile, or open databases in the live checkout.

Create one task-owned external root mode `0700`. Use test-process `umask 022`.
Precreate distinct basetemp parents. Run collection then execution serially:

```sh
set -euo pipefail
umask 022
mkdir -p "$REPAIR_ROOT/basetemps"

run_group() {
  local label="$1"
  shift
  PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src \
    python3 -m pytest -q -p no:cacheprovider \
    --basetemp="$REPAIR_ROOT/basetemps/${label}-collect" \
    --collect-only "$@"
  PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src \
    python3 -m pytest -q -p no:cacheprovider \
    --basetemp="$REPAIR_ROOT/basetemps/${label}-run" \
    "$@"
}

run_group provisioning \
  tests/test_rw0_c2_scope_admission_provisioning_contract.py

run_group owning_contracts \
  tests/test_rw0_c2_first_live_proof_posture_contract.py \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py \
  tests/test_rw0_c2_private_value_versioning_contract.py \
  tests/test_rw0_c2_durable_progression_decision_semantic_contract.py \
  tests/test_rw0_remote_contact_phase_entry_contract.py \
  tests/test_architecture_contracts.py \
  tests/test_autonomous_software_development_operating_model.py \
  tests/test_c2b0_durable_state_contract.py \
  tests/test_sqlite_backend_b0_contract.py \
  tests/test_b2a_writer_session_contract.py

run_group full
```

Opening references:

- provisioning module: `38`
- owning/composition group: `3,208`
- full repository: `8,796`
- merged baseline excluding provisioning module: `8,758`
- three known Python 3.13 multithreaded-fork warnings.

The repaired module may add bounded tests; do not force a count. Reconcile:

- actual unique node IDs;
- A/B disjointness;
- A/B inclusion in C;
- full count = `8,758 + final provisioning-module count`;
- actual structured warning records.

Do not suppress warnings, remove tests, parallelize, use xdist, or overlap runs.

After the last edit, rebuild the external clone from final bytes and rerun every
required group. No late edit inherits an earlier full-suite result.

Run:

- `git diff --check`;
- both new-file no-index whitespace checks;
- strict UTF-8/BOM/CR/trailing-whitespace/final-LF checks;
- candidate type/mode/path checks;
- five-document byte preservation;
- all 240 noncandidate tracked paths against HEAD;
- source/schema/migration/catalog preservation;
- migration `0005` absence;
- before/after clone endpoint equality.

Before executable work, inventory only the known live `__pycache__` as opaque
metadata and hashes. The observed inventory is 37 regular bytecode files plus
the directory. Require exact opening/closing equality.

External artifact scans use `lstat`; hash only regular files; never follow
symlinks or open FIFOs/sockets/devices. Remove only the task-owned external root
after all processes finish.

## 10. Closeout

Opening and closing committed coordinates must match. The final index still
matches HEAD. Exactly four modified docs and two untracked files remain. Only
the new test file differs from the opening table.

Recompute all six endpoint receipts twice and report:

- path;
- status;
- regular-file mode;
- size;
- SHA-256;
- HEAD blob.

Recompute the final six-path patch twice with the same ordered full-index recipe
from section 2. Report component lengths, total bytes, and SHA-256.

The closeout must include:

1. verdict and visible settings;
2. opening/closing coordinates and one-file V3→V4 transition;
3. all six receipts and final patch;
4. exact inventory of source-observation fields and their exact types;
5. hostile source-subclass outcomes and protected-read/write traces;
6. transaction timestamp grammar, ordering, and hostile outcomes;
7. replay/readback behavior with an invalid newly supplied time;
8. preservation of V2/V3 disclosure, source, profile/applicability,
   malformed-observation, replay, and recovery boundaries;
9. permanent tests, direct hostile specimens, transformed copies, and evidence
   limits;
10. exact validation commands/counts/warnings, setup errors, rebuilds, skipped
    work, external effects, and cleanup;
11. five-document, noncandidate, source, migration, and cache preservation;
12. remaining supplier/physical/runtime gates and continuation capsule.

Stop rather than widen if source-observation exact typing or timestamp validation
conflicts with an owning document, needs documentation changes, requires
production source/SQL/migration, or changes adopted canonical meanings.

Success:

`RW0_C2_SCOPE_ADMISSION_PROVISIONING_CHECKER_REPAIRED_V4_READY_FOR_INDEPENDENT_AUDIT`

Blocked:

`RW0_C2_SCOPE_ADMISSION_PROVISIONING_CHECKER_V4_REPAIR_BLOCKED`

Success authorizes only a fresh provenance-bound independent read-only re-audit.
It authorizes no staging, commit, publication, source/migration work, supplier
qualification, runtime provisioning, enrollment, launch, recovery runtime,
deployment, RW0-D implementation, or RW0-E execution.

State actual non-actions and temporary external validation effects truthfully.
