# Governed Execution Coordinator — Scope-Admission Provisioning V4 Checker: Independent Re-audit

## Objective and authority

Perform one fresh, parent-only, repository-first, READ-ONLY independent re-audit
of the exact uncommitted six-path scope-admission provisioning candidate after
the one-file V4 checker repair.

The preceding V3 independent re-audit returned:

`RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_AUDIT_BLOCKED`

It independently preserved the earlier disclosure, source-binding,
malformed-observation, exact-command/family-type, profile, applicability,
replay, and recovery repairs, but found two remaining Medium-severity
checker-evidence defects:

1. source-observation wrapper classes were checked while their scalar fields
   were compared before exact built-in type validation, allowing hostile
   subclasses to influence candidate/source and selected-owner comparisons;
2. the synthetic transaction-owned `recorded_at` was copied into and appended
   with a fresh family before its exact canonical whole-second UTC grammar was
   validated.

The repair closeout reports:

`RW0_C2_SCOPE_ADMISSION_PROVISIONING_CHECKER_REPAIRED_V4_READY_FOR_INDEPENDENT_AUDIT`

That closeout is evidence to verify, not acceptance.

Do not repair, stage, commit, publish, implement, qualify a supplier, or perform
live provisioning/custody work. Return one substantive INLINE report with exact
repository-relative `path:line` evidence and a continuation capsule no longer
than 800 words. Create no delivered report, manifest, receipt, patch, snapshot,
or evidence package.

Use the highest exposed reasoning setting. Report visible model, reasoning
setting/effort, and permission posture, or `not visible`. Do not seek additional
account or computer access merely to reveal hidden settings. No subagents or
other model/worker invocations.

## 1. Exact committed baseline

Repository:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required opening coordinates:

- branch: `trunk_dev`
- HEAD: `630414faa07f4ac39c4a870a9cc44c7f92d46b80`
- tree: `cd81f7cca8b64cb9ff221537257e70e2c5a655a3`
- sole parent: `d070bf05d2e68472e18b1b077259e67864923e8f`
- subject: `docs: freeze RW0-C2 first-live proof posture`
- upstream: `origin/trunk_dev`
- locally observed divergence: `0 ahead / 0 behind`
- exactly one live worktree
- index matches HEAD
- no staged or unmerged paths
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or unexpected
  Git lock.

Read `AGENTS.md` first. Use non-mutating Git inspection with optional-lock
suppression where appropriate. Do not fetch, refresh, normalize, clean, or
repair the live checkout. Local tracking equality is not fresh remote truth.

Any baseline, path-set, classification, file-type, mode, byte-size, SHA-256, or
patch mismatch requires:

`AUDIT_PROVENANCE_MISMATCH`

Stop before semantic inspection.

## 2. Exact final V4 six-path candidate

Require exactly four tracked documentation modifications and two untracked
additions, with no other tracked or untracked difference from HEAD.

All six endpoints must be regular, nonsymlink, OS mode `0644`, strict UTF-8,
exactly one final LF, no BOM, no CR, and no trailing whitespace. The four
tracked Git entries remain mode `100644`. Both additions remain absent from
HEAD and the opening index.

| Status | Repository-relative path | Bytes | SHA-256 | HEAD blob |
|---|---|---:|---|---|
| `M` | `.docs/autonomous-software-development-operating-model.md` | 39,708 | `ccca078da9da0eca90d6e0f86bb30dbda9960765276e7737d4af8b66cc9197a1` | `9207ff698920682dc25057a9fc12b9f2a8cb28d7` |
| `M` | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 26,041 | `0ebe519379a689f87a2f6ddabeeede5f96d1c5d4ec8f90373f555f38fc61ca44` | `b737b4feff254e2da5d04151575acfbd06f201f3` |
| `M` | `.docs/rw0-c2-first-live-proof-posture.md` | 15,857 | `ab0c7a57b5807207203c5c31a4ba00b671a4e898264c4e9c1119d3517d959ce3` | `d88c3a6a0ec032e460cbd68c97dfe5b915a0514d` |
| `M` | `.docs/rw0-c2-private-value-versioning.md` | 207,681 | `966a1f5ac158ad6e597aa7922328612d0993e6e8c109f766aedd9ac7cc8bd251` | `54f84052d97d927e8ccc874b39b1fe8aa8596cff` |
| `??` | `.docs/rw0-c2-scope-admission-provisioning-contract.md` | 23,631 | `9af662213b3a9fe51a0c2f12449e46a3a1ea9d3172ac7e3d99ce7ce9fd509449` | absent |
| `??` | `tests/test_rw0_c2_scope_admission_provisioning_contract.py` | 71,224 | `6a9ec185d9595aeb51708c92827fc2798a2ae5497de54fa3e563a20791b7b093` | absent |

The repair closeout reports that only the final path changed from the V3
candidate:

- V3 verifier:
  - 59,562 bytes
  - SHA-256:
    `b85d061237bb7a8be463c2efacc80a65b13f9dbe8a8a65f0fd148aeff3b5e346`
- V4 verifier:
  - 71,224 bytes
  - SHA-256:
    `6a9ec185d9595aeb51708c92827fc2798a2ae5497de54fa3e563a20791b7b093`

The five document endpoints must be byte-identical to the previously audited
candidate. Historical V3 verifier bytes are corroborating transition evidence;
the live V4 bytes are the primary target.

Read the four baseline blobs directly. Verify all 240 noncandidate tracked paths
and Git-relevant modes. Preserve pre-existing unrelated OS modes; do not
normalize all files to `0644`.

Preserve `AGENTS.md`, `README.md`, all source, schemas, migrations, SQL,
configuration, scripts, package exports, and existing tracked tests. Migrations
remain exactly `0001`–`0004`; `0005` is absent.

## 3. Exact final ordered patch

Visit the six candidate paths in table order, which is lexicographic
repo-relative order.

For each tracked path:

```sh
git diff --binary --full-index --no-ext-diff --no-textconv HEAD -- PATH
```

For each new path:

```sh
git diff --no-index --binary --full-index --no-ext-diff --no-textconv -- /dev/null PATH
```

Concatenate exact stdout bytes without separators. A no-index exit status of `1`
is expected.

Required component lengths:

```text
1,435 / 1,230 / 1,425 / 2,162 / 24,271 / 73,038
```

Required final patch:

```text
103,561 bytes
SHA-256:
77abc6ae33e52ac907a1d2ce4d3fa2c3710c114ffdb08d5467ad38b0973bdf58
```

Reconstruct twice from fresh reads. Do not invoke external diff helpers or text
conversion. Do not invent a canonical manifest prerequisite.

## 4. Audit effect ceiling

The live checkout permits read-only Git, text, metadata, and hashing only.

Do not:

- import or execute repository modules in the live checkout;
- run pytest, compile, repository scripts, or SQLite connections there;
- edit, stage, commit, push, create a PR, merge, switch branches, or reset;
- fetch or contact a remote;
- install dependencies;
- access a supplier, provider, service, credentials, enrollment, launch,
  fencing, worker, ES, Bridge, or sibling repository;
- open unrelated ignored operator/product state;
- create a delivered artifact.

Executable audit work is allowed only in disposable local-only external clones
of exact HEAD with no configured remote and exactly the six verified candidate
files overlaid.

Before executable work, inventory only the known live
`src/ge_nwp_coordinator/__pycache__/` members as opaque data: path, type, mode,
size, nanosecond mtime, and hash for regular files. The reported opening
inventory is 37 regular bytecode files plus the directory. Require exact
opening/closing equality. Never import, move, delete, regenerate, or clean that
cache.

External artifact scans must use `lstat` before opening. Hash only regular
files. Never follow symlinks or open FIFOs, sockets, devices, or other special
files.

## 5. Source hierarchy and focused inspection

Owning documents define current and accepted-target semantics. Source and
migrations define implemented behavior. Tests, reports, digests, and synthetic
premises are evidence only.

Read both new candidate files completely. Read every change in the four existing
documents in context against HEAD. Follow only relevant owner/test edges in:

- `.docs/rw0-c2-first-live-proof-posture.md`
- `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md`
- `.docs/rw0-c2-private-value-versioning.md`
- `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
- `.docs/writer-session-authority.md`
- `.docs/rw0-c1-durable-evidence.md`
- current C2B recovery successor clauses
- current writer-session/transaction source as read-only compatibility evidence
- migration-0002 and migration-0004 as read-only compatibility evidence
- the exact existing tests in the validation group.

Verify the private-value machine block from its begin marker through EOF is
byte-identical to HEAD and its existing verifier/parser is unchanged. Do not
restart the prior private-value/parser audit.

The five documents are preservation obligations. The substantive V4 repair is
in the new checker/test module only.

## 6. Preserve all prior accepted repairs

Before assessing V4, independently reconfirm that the final checker preserves:

- disclosure permission before every protected receipt/family/alias read;
- recording-only permission cannot reveal stored-state distinctions;
- exact read-only replay/readback remains available under its separate current
  disclosure/custody authorization after recording permission is revoked;
- A, B, and C source subjects are independently authored and work only under
  their own evidence;
- candidate/source profile and applicability joins plus fixed owner literals
  are enforced before protected reads;
- malformed observed members remain inside closed apply/readback outcomes;
- exact built-in types are enforced for command, act, fact, basis, result,
  receipt, retained command, and observed-family containers;
- same operation + same command + complete original family is the only replay;
- same act under a new operation or alternate fact reference is conflict;
- different complete provisioning winner is a fresh conflict and leaves
  original recovery `unresolved`;
- definite noncommit requires exhaustive absence, intact original custody, and
  old-execution exclusion;
- recovery never writes, repairs, retries, renews admission, or restarts a proof;
- same-process local session renewal remains distinct from process/supervisor
  restart.

Any regression is blocking.

## 7. Finding 1 — exact source-observation scalar types

### Inventory and validation placement

Independently inventory every scalar field used in the synthetic source
observations. The closeout reports:

Policy strings:
- `audience`
- `act_ref`
- `act_digest`
- `projection_digest`
- `lineage_ref`
- `scope_ref`
- `guard_profile`
- `applicability`
- `provenance_ref`
- `provenance_digest`

Enrollment strings:
- `lineage_ref`
- `scope_ref`
- `enrollment_ref`
- `incarnation_ref`

Custody strings:
- `lineage_ref`
- `scope_ref`
- `incarnation_ref`
- `authority_process_ref`
- `storage_custody_ref`

Evidence strings:
- `enrollment_ref`
- `enrollment_digest`
- `recording_permission_ref`
- `recording_permission_digest`
- `custody_ref`
- `custody_digest`

Premise Booleans:
- `authenticated_act`
- `original_enrollment`
- `activated_original_incarnation`
- `original_process_and_storage`
- `sole_active_no_foreign`
- `same_original_process`
- `supervisor_live`
- `recording_permission`
- `disclosure_permission`
- `current_source`
- `local_writer_fenced`
- `old_execution_excluded`

Also inspect any additional source/status/evidence scalar actually used by the
checker.

Require exact wrapper classes where the checker contract defines exact wrapper
types, and exact built-in scalar types inside them.

Validation must occur before:

- candidate/source equality;
- selected owner-literal comparison;
- any canonicalization or digest helper;
- disclosure gating that consumes source permission;
- protected store reads;
- family construction;
- clock selection;
- append/write.

Use `type(value) is ...`, not `isinstance`, for canonical source fields.

### Direct hostile subclasses

Use subclasses that retain valid-looking text and, where useful, override
equality so ordinary comparison would pass.

At minimum exercise:

1. source `guard_profile` subclass containing the selected literal;
2. source `guard_profile` subclass carrying a foreign value but comparing equal
   to the selected literal;
3. source `applicability` subclass containing the selected literal;
4. source `applicability` subclass carrying a foreign value but comparing equal
   to the selected literal;
5. source act identity and act digest subclasses matching the candidate;
6. source lineage and scope subclasses;
7. enrollment, incarnation, and custody-reference subclasses;
8. evidence-ref and evidence-digest subclasses;
9. integer `1` or another wrong exact built-in type in each Boolean permission/
   premise category that can influence entry, disclosure, replay, or recovery;
10. a wrapper subclass if the final checker claims exact wrapper classes.

Required outcome:

- content-free `recording_authority_unavailable`;
- no protected receipt/family/alias reads;
- no family construction;
- no time validation/selection;
- no append/write;
- no raw comparison, field, or hashing exception.

A hostile source value must not be coerced through `str`, JSON round-trip,
copying, hashing, or equality before its exact-type boundary.

### Exhaustiveness without a fuzz campaign

A compact parameterized audit probe may cover the complete field inventory.
Hold independent expected outcomes outside the checker.

Do not accept a test that merely checks four profile/applicability examples while
leaving another authority-bearing source scalar unchecked.

### Positive and semantic controls

Preserve independently authored exact-built-in A/B/C positive sources under:

```text
guard_profile = rw0-c2-guard-v1
applicability = admitted_direct_local_bootstrap
```

Preserve V3 semantic controls where:

- candidate and fixed source disagree on profile/applicability;
- candidate and coordinated foreign source agree with each other but violate
  the fixed owner literal.

The latter must still fail even though all values are exact built-ins.

Renewed current evidence for the same stable subjects may change evidence
coordinates without changing the historical family or relaxing bindings.

## 8. Finding 2 — exact transaction-owned timestamp

### Derive the owner grammar

Read the provisioning owner’s exact `recorded_at` definition and fixed vector.

Independently verify that the final checker requires:

- exact built-in `str`;
- exact canonical form `YYYY-MM-DDTHH:MM:SSZ`;
- a real Gregorian calendar date/time;
- UTC `Z`, no offset;
- whole seconds, no fractional component;
- exact zero padding and uppercase form;
- no surrounding whitespace;
- parse-and-round-trip equality to the original text.

Do not infer a new format or accept another semantically equivalent encoding.

### Fresh-write ordering

Trace the actual fresh-recording path.

Require:

```text
command/source/disclosure/custody validation
→ protected receipt/family/alias read set
→ establish fresh operation is otherwise eligible
→ select one transaction-owned time
→ validate time
→ construct result/receipt/family
→ append once
→ return scope_admission_recorded
```

An invalid time must be rejected before:

- result construction;
- receipt construction;
- complete-family construction;
- append/write;
- success label.

Instrument build, time-check, and append paths to prove the order.

The selected time is not part of the command and must not affect precommit
lookup identity.

### Direct timestamp specimens

At minimum test:

1. exact canonical valid value:
   `2026-10-14T12:00:00Z`;
2. `str` subclass containing that valid text;
3. `not-a-timestamp`;
4. unsupported fractional seconds;
5. `+00:00` offset instead of `Z`;
6. lower-case `z`;
7. leading or trailing whitespace;
8. impossible date such as February 30;
9. impossible hour/minute/second or leap-second form;
10. non-zero-padded month/day/hour/minute/second;
11. a valid leap-day value when canonical.

For fresh eligible recording, every invalid specimen must produce the existing
safe no-write invalid-input outcome with zero builds and zero appends.

### Replay and readback distinction

With a complete exact existing family:

- exact replay must return the original result/receipt/time even if a newly
  supplied synthetic time argument is invalid;
- replay must not call the fresh time-selection/validation path;
- readback must have no new-time dependency and must validate/classify the
  stored original timestamp as part of complete-family verification;
- an invalid stored timestamp must make apply no-write
  `family_unverifiable` and readback `unresolved`;
- a valid original timestamp remains unchanged under renewed evidence.

A globally applied time-argument check that breaks replay is blocking.

## 9. Immediate compositions

Independently exercise:

1. hostile source scalar + exact stored family:
   source-type refusal before protected reads;
2. wrong Boolean type + malformed stored family:
   source-type refusal before disclosure/store access;
3. valid source + invalid fresh time + empty eligible store:
   no build, append, or success;
4. disclosure denied + invalid fresh time:
   disclosure refusal before time selection/validation;
5. exact existing family + invalid newly supplied time:
   exact replay with original time and no write;
6. malformed stored timestamp + valid source/disclosure:
   no exact replay/committed recovery;
7. renewed evidence for original subjects + invalid fresh time on a genuinely
   fresh operation:
   stable source join passes, timestamp boundary refuses without write;
8. coordinated foreign exact-built-in source/request profile or applicability +
   invalid time:
   semantic source/owner refusal occurs before time validation.

Keep expectations outside checker helpers.

## 10. Transformed-copy verification

Against exact final V4 bytes, create at least these disposable transformed
copies:

1. change source exact typing to `isinstance(value, str)`;
2. omit exact typing for source `guard_profile`/`applicability`;
3. perform source comparisons before exact-type validation;
4. coerce source scalars through `str(...)` before validation;
5. bypass timestamp validation;
6. accept any nonempty timestamp string;
7. use a regex-only timestamp check that accepts an impossible calendar date;
8. validate time after family construction or append;
9. validate the new time globally so exact replay with invalid new time fails.

For each:

- keep independent expected specimens fixed;
- require normal parse/import/collection;
- require semantic failure at the intended permanent regression;
- credit no syntax, import, or collection failure.

Report permanent tests, direct hostile specimens, transformed copies, and any
audit-side oracle separately.

The checker cannot self-authenticate arbitrary coordinated edits to itself and
all expectations. This audit owns the exact-byte and fixed-expectation boundary.

## 11. Exact serial validation

Create one fresh private mode-`0700` external audit root. Build a local-only
clone from exact HEAD, remove its remote, and overlay exactly the six verified
candidate files. Verify all 246 candidate endpoints before testing.

Use normal test-process `umask 022`. Precreate distinct basetemp parents. Run
collection and execution serially:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src \
python3 -m pytest -q -p no:cacheprovider \
  --basetemp=<precreated-external-path> [--collect-only] <group>
```

### A. V4 provisioning checker

```text
tests/test_rw0_c2_scope_admission_provisioning_contract.py
```

Reported:

```text
54 unique collected / 54 passed
```

### B. Owning/composition regressions

```text
tests/test_rw0_c2_first_live_proof_posture_contract.py
tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
tests/test_rw0_c2_private_value_versioning_contract.py
tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_architecture_contracts.py
tests/test_autonomous_software_development_operating_model.py
tests/test_c2b0_durable_state_contract.py
tests/test_sqlite_backend_b0_contract.py
tests/test_b2a_writer_session_contract.py
```

Reported:

```text
3,208 unique collected / 3,208 passed
```

### C. Complete repository

No path arguments.

Reported:

```text
8,812 unique collected / 8,812 passed
3 existing Python 3.13 multithreaded-fork DeprecationWarnings
```

The three warnings are attached to the existing
`tests/test_sqlite_b2c_writer_session.py` tests:

- `test_operation_guard_close_waits_and_retains_authority_until_exit`
- `test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang`
- `test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock`

Require:

- unique node IDs;
- A/B disjointness;
- A/B inclusion in C;
- `8,812 = 8,758 + 54`;
- structured warning records matching the three existing warnings.

Do not suppress warnings, remove tests, force counts, parallelize, use xdist, or
overlap groups.

Run:

- `git diff --check`;
- both new-file no-index whitespace checks;
- strict UTF-8/BOM/CR/trailing-whitespace/final-LF checks;
- candidate type/mode/path checks;
- five-document preservation;
- all 240 noncandidate tracked paths against HEAD;
- source/schema/migration/catalog preservation;
- migration `0005` absence;
- before/after clone endpoint equality.

A clearly identified audit-runner error may be corrected only outside the live
checkout. Rebuild from the same exact candidate and rerun affected gates.
Candidate defects are findings, not audit repair authority.

## 12. Cleanup and live preservation

Inventory audit-owned external artifacts with `lstat` before opening. Hash only
regular files. Never follow symlinks or open FIFOs, sockets, or devices.

Classify temporary SQLite files and special fixtures under the audit-owned root,
then remove only that root after all processes end.

Require final live equality for:

- HEAD, tree, parent, branch, upstream, worktree count;
- index and unmerged state;
- all six candidate endpoints;
- all 240 noncandidate tracked paths;
- source, migrations, and catalog;
- live cache member paths, types, modes, sizes, mtimes, and hashes.

## 13. Verdict rules

### Accept only if

- exact provenance and the 103,561-byte patch reproduce;
- the five documents remain unchanged;
- every source-observation scalar is exact-typed before comparison,
  canonicalization, disclosure, or protected reads;
- malicious subclasses cannot influence source/request or owner-literal checks;
- exact-built-in A/B/C and semantic foreign-profile/applicability controls remain
  correct;
- fresh transaction time is exact, canonical, real, and validated before
  construction/append/success;
- replay and readback ignore any new synthetic time and preserve the original;
- invalid stored time cannot replay or classify committed;
- all prior V2/V3 repairs remain intact;
- all transformed copies are detected semantically;
- all required validation and preservation gates pass;
- no unresolved High- or Medium-severity in-scope finding remains.

Use:

`RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE`

### Block for

- any source-scalar subclass or wrong built-in value affecting authority;
- source comparison/canonicalization before exact-type validation;
- malformed or noncanonical fresh time receiving a success label or append;
- replay incorrectly depending on a new time argument;
- invalid stored time credited as complete;
- regression in disclosure, source binding, profile/applicability, malformed
  observation, replay, collision, recovery, first-live, or C2 separation;
- provenance or required validation drift.

Use:

`RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_AUDIT_BLOCKED`

### Provenance mismatch

Use:

`AUDIT_PROVENANCE_MISMATCH`

## 14. Inline report

Return:

1. primary verdict and visible settings;
2. exact opening/closing coordinates and six receipts;
3. final patch reproduction and one-file V3→V4 transition;
4. five-document, private-machine-block, noncandidate, source, migration, and
   cache preservation;
5. complete source-observation field/type inventory and validation order;
6. hostile source-subclass outcomes and protected-read/write traces;
7. exact timestamp grammar, direct specimens, and fresh-write ordering;
8. replay/readback behavior with invalid new and stored timestamps;
9. preservation of all V2/V3 repairs and immediate compositions;
10. permanent tests, direct specimens, transformed copies, and audit-side
    evidence limits;
11. exact validation commands, counts, warnings, setup corrections, skipped
    work, external effects, and cleanup;
12. severity-ranked findings or explicit no remaining in-scope findings;
13. exact next boundary and continuation capsule no longer than 800 words.

Acceptance authorizes only a separately issued commit/publication gate for the
exact six audited files. It authorizes no source implementation, migration
`0005`, supplier qualification, runtime provisioning, enrollment, launch,
recovery runtime, deployment, RW0-D implementation, or RW0-E execution.

State actual non-actions and external validation effects truthfully. End with
exactly one verdict token.
