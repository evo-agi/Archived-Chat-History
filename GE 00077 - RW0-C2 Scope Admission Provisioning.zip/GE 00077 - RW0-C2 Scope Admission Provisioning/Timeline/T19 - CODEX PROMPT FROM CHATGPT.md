# Governed Execution Coordinator — Scope-Admission Provisioning: PR #13 Squash Merge and Local Realignment

## Mandate and bounded effects

Perform one parent-only merge gate for the exact published source commit and
PR #13 below. This is merge/publication finalization, not implementation,
contract revision, or another semantic audit.

Prior accepted evidence:

```text
RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE
RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_COMMITTED_AND_PR_OPENED
```

The publication gate reports exact working/index/committed six-file equality
and serial validation from index-derived bytes:

- provisioning checker: 54 passed;
- ten owning/composition contract files: 3,208 passed;
- complete repository: 8,812 passed with three unchanged Python 3.13
  writer-session fork warnings.

That is historical validation evidence. Do not rerun pytest, collection,
repository scripts, transformed copies, supplier probes, migrations, or any
semantic assurance campaign in this gate.

This prompt authorizes only, in order:

1. read-only local Git-object, ref, index, worktree, cache, and file verification;
2. fresh authenticated read-only verification of the configured GitHub
   repository, PR, refs, effective rules, reviews, discussions, checks, and
   readiness;
3. at most ONE ordinary synchronous head-SHA-guarded squash-merge request for
   this exact PR and source;
4. independent remote readback and verification of the resulting squash commit,
   parent, tree, message, attribution/signature state, and exact file effects;
5. after those checks pass, ONE narrow fetch of `trunk_dev` into
   `origin/trunk_dev`;
6. after raw fetched-object verification, ONE expected-old-object-guarded update
   of the already checked-out local `trunk_dev` to the verified squash commit;
7. final synchronization, topic preservation, cache equality, and cleanup of
   only this gate's disposable external files.

Ordinary object-database, `FETCH_HEAD`, remote-tracking-ref, and reflog writes
caused by the exact authorized fetch/ref update are permitted. They authorize
no other branch, worktree, source, index, or repository operation.

Never:

- edit, stage, format, or repair candidate files;
- create, amend, rebase, cherry-pick, reset, checkout, switch, merge, or locally
  squash a source commit;
- push any ref;
- delete or move the topic branch;
- change PR title/body/metadata;
- enable auto-merge, use a merge queue, issue an async merge, or update the PR
  branch;
- request reviews, approve, resolve conversations, or alter repository policy;
- create tags, releases, deployments, credentials, tokens, supplier state,
  enrollment, launch, fencing, live provisioning, workers, ES, Bridge, RW0-D,
  or RW0-E effects;
- install dependencies, start services, access product/operator databases,
  import repository modules, contact sibling repositories, or spawn subagents.

Ordinary platform notifications and already configured non-deploying checks
caused by an ordinary merge are implicit publication effects. They do not
authorize deployment or manual workflow dispatch. Inspect known merge/push
workflow and webhook behavior as data. If the merge inherently requires or
triggers a prohibited operational effect, stop rather than disabling controls.

Use the highest exposed reasoning setting. Report visible model, reasoning
setting/effort, and permission posture, or `not visible`. Do not seek additional
account or computer access merely to reveal hidden settings.

Return one substantive INLINE closeout plus a continuation capsule no longer
than 800 words. Create no delivered receipt, manifest, patch, snapshot, or
evidence package. This prompt is self-contained.

## 1. Exact opening repository and PR

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Configured origin identity:

`github.com/evo-agi/Governed-Execution-Coordinator`

PR:

`https://github.com/evo-agi/Governed-Execution-Coordinator/pull/13`

PR number: `13`

PR node ID:

`PR_kwDOTYw1Ic8AAAABIvZjmg`

Base branch:

`trunk_dev`

Head branch:

`codex/rw0-c2-scope-admission-provisioning-v1`

### Required local opening state

- branch: `trunk_dev`
- HEAD/source commit:
  `ab26bf80daf0907a26fe336e1ef1e432f4c0fb59`
- source tree:
  `45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4`
- sole parent:
  `630414faa07f4ac39c4a870a9cc44c7f92d46b80`
- parent tree:
  `cd81f7cca8b64cb9ff221537257e70e2c5a655a3`
- subject:
  `docs: freeze RW0-C2 scope admission provisioning`
- upstream: `origin/trunk_dev`
- local `origin/trunk_dev`:
  `630414faa07f4ac39c4a870a9cc44c7f92d46b80`
- divergence: `1 ahead / 0 behind`
- exactly one live worktree
- index and working tree match the source commit
- no staged, unstaged, untracked, or unmerged change
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or unexpected
  lock.

### Required remote opening state, freshly verified

- `refs/heads/trunk_dev` points to
  `630414faa07f4ac39c4a870a9cc44c7f92d46b80`;
- `refs/heads/codex/rw0-c2-scope-admission-provisioning-v1` points to
  `ab26bf80daf0907a26fe336e1ef1e432f4c0fb59`;
- PR #13 is OPEN, non-draft, unmerged, with exact base/head repositories and
  branches, exact source OID, one source commit, and exactly six file effects.

The configured actor was reported as `SeritArbores`. Verify current authenticated
login and GitHub attribution of the source author and committer without exposing
credentials. Use the existing actor only; do not switch identities. A different
actor is a preflight block.

Read `AGENTS.md` and applicable local guidance first. Read the new provisioning
owner and changed routing sections only as needed to understand this merge.
Do not restart semantic design.

Inspect local hook and signing configuration as data. Do not execute repository
hooks, external diff helpers, or repository code. Confirm `HEAD` symbolically
points to the direct `refs/heads/trunk_dev` ref.

Use read-only object/status commands with optional locks suppressed where
appropriate. Do not fetch or normalize local state before opening checks.

If another actor already merged, closed, altered, or replaced the PR before this
gate, report the actual state and stop without sending a merge request or moving
local refs. Do not silently reinterpret this task as reconciliation of another
actor's write.

## 2. Exact source tree and accepted endpoints

The source tree contains 246 tracked regular file entries: 240 unchanged from
the parent, four modifications, and two additions.

Reproduce exact path sets and Git-relevant modes. No rename, deletion,
executable-bit change, symlink, submodule, extra path, or alternate blob is
permitted.

All six changed entries are Git mode `100644`. Their worktree endpoints are
regular nonsymlink OS-mode `0644`, strict UTF-8, one final LF, no BOM/CR, and no
trailing whitespace.

| Effect | Repository-relative path | Bytes | SHA-256 | Parent blob | Source/squash blob |
|---|---|---:|---|---|---|
| `M` | `.docs/autonomous-software-development-operating-model.md` | 39,708 | `ccca078da9da0eca90d6e0f86bb30dbda9960765276e7737d4af8b66cc9197a1` | `9207ff698920682dc25057a9fc12b9f2a8cb28d7` | `e3c1b8adde40075da050eefcf555414b2396574f` |
| `M` | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 26,041 | `0ebe519379a689f87a2f6ddabeeede5f96d1c5d4ec8f90373f555f38fc61ca44` | `b737b4feff254e2da5d04151575acfbd06f201f3` | `cccf77873e8c27a3f2507b1dd4273a009115d3b8` |
| `M` | `.docs/rw0-c2-first-live-proof-posture.md` | 15,857 | `ab0c7a57b5807207203c5c31a4ba00b671a4e898264c4e9c1119d3517d959ce3` | `d88c3a6a0ec032e460cbd68c97dfe5b915a0514d` | `bf184e13fa11c8642e839a4e1ae41c4b78fa3719` |
| `M` | `.docs/rw0-c2-private-value-versioning.md` | 207,681 | `966a1f5ac158ad6e597aa7922328612d0993e6e8c109f766aedd9ac7cc8bd251` | `54f84052d97d927e8ccc874b39b1fe8aa8596cff` | `0cdd242dcfb84e4c0ef4b193c03e6f6092a203b3` |
| `A` | `.docs/rw0-c2-scope-admission-provisioning-contract.md` | 23,631 | `9af662213b3a9fe51a0c2f12449e46a3a1ea9d3172ac7e3d99ce7ce9fd509449` | absent | `eca1341a6edaf29c5ec8f362e168ac0054fe8aa7` |
| `A` | `tests/test_rw0_c2_scope_admission_provisioning_contract.py` | 71,224 | `6a9ec185d9595aeb51708c92827fc2798a2ae5497de54fa3e563a20791b7b093` | absent | `0806155b517b89334460834f0cf8cd8c54ca4e6d` |

Read every source and parent blob directly as data. Verify raw sizes, SHA-256
values, computed Git blob identities, and index/worktree equality.

Verify all 240 unaffected source-tree entries against the parent and all 246
working files against the source commit by content/type and Git-relevant mode.

An unrelated pre-existing nonexecuting tracked file may have OS mode `0600`
while Git represents it as `100644`. Preserve the actual OS mode. The OS-mode
`0644` requirement applies only to the six accepted endpoints.

Preserve `AGENTS.md`, `README.md`, source, schemas, migrations, scripts,
configuration, exports, and unaffected tests. Migration resources remain
exactly `0001`–`0004`; `0005` is absent.

The historical unstaged candidate patch was 103,561 bytes with SHA-256:

`77abc6ae33e52ac907a1d2ce4d3fa2c3710c114ffdb08d5467ad38b0973bdf58`

That is prior acceptance evidence, not a current clean-worktree representation.
Do not rerun the old unstaged patch recipe against the committed checkout and
interpret empty output as candidate loss. Current provenance is the exact
commit, parent, tree, blob, message, and endpoint identity above.

## 3. Exact source message and PR text

Read the source message from the RAW Git commit object, separating commit
headers from message bytes at the true blank header separator. Do not hash
pretty-print output. Signature headers are not message bytes.

Read source author/committer and signature status accurately. The publication
gate reported author and committer as the existing configured:

`AlacerMortis <david.shaw.dev@gmail.com>`

with GitHub attribution to `SeritArbores`, and reported the source commit as
unsigned. Verify rather than assume.

Exact subject:

```text
docs: freeze RW0-C2 scope admission provisioning
```

Exact source body, excluding terminal LF in this block:

```text
Adopt the target-only program-independent scope-admission recording contract
and its bounded causal checker.

Preserve external standing-policy authorship, independent enrollment and
original-incarnation custody, the unchanged verified-act and admission-fact
meanings, and Coordinator ownership of the separate recording result, receipt,
exact replay, and readback-only recovery.

This change implements no source provider, admission provisioner, SQL schema,
migration 0005, guarded decision writer, recovery runtime, public API, RW0-D/E
execution, supplier qualification, or Execution Substrate integration.

Audit:
RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE
```

Source message equals:

```text
subject + two LF bytes + body + one final LF
```

Required raw source message:

```text
743 bytes
SHA-256:
f6baa313f1663c50f7c62f37ea0f95dfd2741e9f3cc1a9e2e94d614165010b48
```

Body without final LF:

```text
692 bytes
SHA-256:
a2b4afc4aa3b4738cf733ef01589ec4b2e0559e9692760594d067ba685e23a62
```

Body with one final LF:

```text
693 bytes
SHA-256:
6c2b983bc0a7e43f6527f4bebf9d7c639a6f00cda415308c371ce4f8be14c55c
```

The squash request uses the same title and the body without its terminal LF.

Allowed final squash-message forms are exactly:

1. no final LF:
   - 742 bytes
   - SHA-256:
     `487d386898c0c6997ae240fcf2fe6455a5fe26096564f78151205dc276eed5cf`
2. exactly one final LF:
   - 743 bytes
   - SHA-256:
     `f6baa313f1663c50f7c62f37ea0f95dfd2741e9f3cc1a9e2e94d614165010b48`

Do not accept an appended PR number, generated source list, co-author trailer,
scope change, or whitespace rewrite.

Exact PR title equals the subject.

Exact PR body with one final LF:

```markdown
## Summary

- adopt the target-only program-independent scope-admission provisioning contract
- record an already externally authorized admission without creating a development program or widening the existing program-bound receipt algebra
- preserve the unchanged verified-admission-act and scope-admission-fact meanings
- keep enrollment, current custody, C2 progression, productive acceptance, and terminal ownership separate
- define exact replay, no-write conflicts, and readback-only three-way recovery for the admission-recording family

## Validation

Validated exact candidate bytes in a remote-free local clone, serially:

- provisioning contract checker: 54 passed
- ten owning and composition contract files: 3,208 passed
- complete repository: 8,812 passed, with 3 unchanged writer-session fork warnings

The prior independent audit accepted the bounded target documentation and synthetic checker. It does not qualify an external source, custody supplier, storage layout, or runtime implementation.

## Non-implementation

No product source, schema, SQL, migration, configuration, supplier, service,
deployment, admission provisioner, guarded decision writer, recovery runtime,
terminal implementation, public API, RW0-D implementation, RW0-E execution, or
Execution Substrate integration is introduced.

Audit:
`RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE`
```

Required PR body with final LF:

```text
1403 bytes
SHA-256:
742e00879a5e88a4e1f1ef84901c2df8e1fe7e28bc37ab52f53472f87e0e3bd7
```

Only permitted API representation difference: omission of that single final LF:

```text
1402 bytes
SHA-256:
d6b5905b7a154efda02391d77d238074ad05799d74a311fa27fe8d5e07af826a
```

Verify exact text by readback. Do not edit the PR merely to normalize the
permitted final-LF difference. Any other title/body or identity change is a
preflight block.

## 4. Live cache and local preservation

Before any authorized remote mutation, inventory only the known live cache
under `src/ge_nwp_coordinator/__pycache__/` by member path, type, OS mode, size,
nanosecond mtime, and hash for regular files.

The publication gate reported 37 regular bytecode files plus their directory.
Reconcile actual membership rather than imposing an invented aggregate.

Treat bytecode as opaque. Never import, move, delete, regenerate, or clean it.
Do not inspect unrelated ignored operator state, credentials, secrets, or
private databases.

Require exact cache equality:

- at opening;
- immediately before merge;
- before local ref update;
- at closeout.

No test run or live module import is authorized. Safe standard-library
byte/hash/JSON processing of inspected data may be used outside the live
checkout.

## 5. Fresh remote, policy, and readiness preflight

After local provenance passes, authenticated read-only access is permitted only
to the configured origin repository and policy directly governing its trunk and
PR.

The publication closeout observations are historical:

- PR mergeable/clean;
- zero checks, statuses, workflows, reviews, and unresolved conversations;
- combined status pending because there were no contexts;
- no auto-merge or queue;
- ruleset `18957283`, zero ordinary approvals, conversation resolution, and
  conditional attribution approval;
- automatic source-branch deletion disabled.

Re-read every material fact.

Verify:

- repository and PR node identity, number, base/head repositories and branches;
- remote base equals the exact parent;
- topic and PR head equal the exact source;
- one source commit and exactly six complete file effects;
- complete source tree equals all 246 local source entries and modes;
- exact PR title/body and source attribution;
- PR is OPEN, non-draft, unmerged;
- no auto-merge, queue entry, async merge request, stacked-PR requirement, or
  update-branch request;
- current mergeability is conclusively mergeable/clean for these exact OIDs.

Follow pagination for commits, changed files, check runs, status contexts,
workflow runs, reviews, comments, and review threads. A first page, truncated
patch preview, or directory-inclusive recursive tree count is insufficient.
Compare exact leaf entries and require complete, untruncated data.

Read effective organization, repository, branch rules, and classic protection
for `trunk_dev`; actor applicability and bypass posture; allowed merge methods;
required reviews, attribution, code-owner and last-push obligations; required
conversation resolution; checks/workflows; signing; merge queue; and automatic
source-branch deletion.

Do not treat a listed ruleset as applicable without verifying scope. Do not
treat API capability or `CLEAN` as a policy bypass.

Require an ordinary NON-BYPASS squash merge to be permitted and every applicable
review/check/conversation/signing condition to be satisfied.

Do not:

- dismiss reviews;
- resolve discussions;
- approve;
- change rules or settings;
- switch actor;
- trigger or retry workflows;
- fabricate a required check.

Empty status contexts with combined state `pending` are not CI success. If
fresh policy requires no checks and the inventories are genuinely empty, report
that fact. If a real pending/failing requirement or ambiguous policy remains,
stop.

Require automatic source-branch deletion to remain disabled. The topic must stay
at the exact source throughout. Capture the complete remote-head inventory for
post-merge non-trunk preservation.

Inspect configured workflows/webhooks as data to identify merge-induced effects.
If ordinary merge would inherently trigger a prohibited deployment or external
operation, stop. Do not disable protections.

A transient mergeability calculation may receive bounded read-only refreshes.
Do not poll indefinitely or turn a blocked task into future work.

## 6. Final pre-merge barrier and exact request

Immediately before the only merge request, recheck:

- local source HEAD/tree and clean index/worktree;
- six endpoints and 240 unaffected entries;
- live cache;
- remote base and topic;
- PR head/state/text;
- actor attribution;
- readiness and effective policy.

Record the observation time in UTC.

Base must still be:

`630414faa07f4ac39c4a870a9cc44c7f92d46b80`

Head must still be:

`ab26bf80daf0907a26fe336e1ef1e432f4c0fb59`

Use only the ordinary synchronous REST merge endpoint:

`PUT /repos/evo-agi/Governed-Execution-Coordinator/pulls/13/merge`

Use existing authenticated tooling with explicit JSON input and recorded API
version/headers. Ensure no client write retry. Do not use admin merge, queue,
async merge, update-branch, or a CLI operation that also checks out, updates, or
deletes branches.

The canonical request has exactly four string-valued fields:

- `commit_message`: the exact 692-byte body above, no final LF;
- `commit_title`: the exact 48-byte subject;
- `merge_method`: `squash`;
- `sha`: `ab26bf80daf0907a26fe336e1ef1e432f4c0fb59`.

Serialization:

- recursively sorted object keys;
- compact comma/colon separators;
- `ensure_ascii=false`;
- `allow_nan=false`;
- UTF-8;
- exactly one terminal LF on the JSON bytes.

The JSON terminal LF is not inside `commit_message`.

Exact request:

```text
866 bytes
SHA-256:
cb4232a17a75cee1a8fb017b00b83ba98e3acf84c7f9e6de35ff88ab88b81ea1
```

Reconstruct independently twice and require byte equality before sending. A
private mode-`0600` request file outside the repository is permitted but not
required.

The `sha` field guards the PR head, not the base. Do not claim atomic base
protection. Immediate base readback reduces the window; mandatory post-merge
parent/tree verification detects an unexpected result.

Send at most ONE merge write. Preserve response status, response body, merged
flag, returned SHA, and any error before interpretation.

## 7. Resolve outcome and verify remotely before fetch

Do not use the pre-merge test `merge_commit_sha` as the expected squash OID.
The resulting squash SHA is discovered from the write/readback.

After a successful or ambiguous response, perform bounded read-only authoritative
readback of PR #13, base/topic refs, remote heads, and resulting commit/tree.
An ambiguous response never authorizes a second merge write.

Before fetch, require:

- PR #13 is CLOSED and merged, with `merged_at` and merger recorded;
- exact preserved base/head repository and branch identities;
- PR merge-commit SHA equals the returned/intended squash;
- remote `trunk_dev` equals that squash exactly, not a descendant;
- topic still equals
  `ab26bf80daf0907a26fe336e1ef1e432f4c0fb59`;
- squash has exactly one parent:
  `630414faa07f4ac39c4a870a9cc44c7f92d46b80`;
- squash tree equals:
  `45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4`;
- exact four modified and two added effects;
- all six source blob OIDs appear unchanged in the squash tree;
- all 246 exact leaf entries and all 240 unaffected parent entries are preserved;
- full message matches one of the two allowed LF forms;
- no generated PR/co-author text or semantic message change;
- source identity, local index/worktree, and cache remain unchanged.

Read GitHub signature-verification status and reason for both source and squash.
Distinguish a signature header from verified cryptographic evidence. If squash
is signed, require valid verification. If fresh policy requires signing, require
that result. Do not configure or create signing keys.

Compare final non-trunk remote heads to the opening inventory. Topic deletion or
unrelated ref drift must be reported; no corrective push is authorized.

If the remote merge occurred with unexpected parent, tree, message, head,
signature/policy result, or concurrently advanced trunk, preserve the remote
effect, do not fetch or realign, and return the incomplete status. No revert or
remote rollback is authorized.

## 8. One narrow fetch and raw-object verification

Only after all remote checks pass, recheck local source/cleanliness/cache and
remote trunk/topic once more.

Then perform exactly once:

```sh
git -c gc.auto=0 -c maintenance.auto=false fetch   --no-auto-maintenance --no-tags --no-recurse-submodules   origin refs/heads/trunk_dev:refs/remotes/origin/trunk_dev
```

Do not fetch all, prune, force a refspec, fetch the topic/tags, recurse
submodules, or perform a second fetch. Command-scoped maintenance suppression
must not change stored configuration.

Verify `origin/trunk_dev` equals the exact verified squash.

Read the raw fetched commit and recheck:

- sole parent;
- tree;
- exact allowed message bytes;
- headers/signature presence;
- all six blob receipts;
- all 246 tree entries;
- source/squash tree equality;
- all 240 unaffected entries.

GitHub API message presentation is not a substitute for raw fetched-object
verification.

The fetch may update object storage, `FETCH_HEAD`, and the one remote-tracking
ref/reflog. It must not move local `trunk_dev` or rewrite working files.

## 9. One expected-old-object local realignment

Immediately before local update require:

- `HEAD` symbolically points to direct `refs/heads/trunk_dev`;
- local `trunk_dev` still equals
  `ab26bf80daf0907a26fe336e1ef1e432f4c0fb59`;
- source and verified squash have identical tree
  `45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4`;
- index and working files equal that tree;
- `origin/trunk_dev` and freshly observed remote trunk equal the squash;
- topic remains at the source and PR reports this exact merge;
- one worktree, no active operation/lock, unchanged cache.

Run ONCE, substituting only the verified squash SHA:

```sh
git update-ref   -m "realign trunk_dev after PR #13 squash merge"   refs/heads/trunk_dev   <verified_squash_sha>   ab26bf80daf0907a26fe336e1ef1e432f4c0fb59
```

The expected-old argument is mandatory.

Do not use reset, checkout, switch, read-tree, cherry-pick, rebase, local merge,
new commit, or any worktree rewrite.

Verify the reflog old/new transition and exact reason text.

Final state must satisfy:

- local `HEAD` = local `trunk_dev` = `origin/trunk_dev` = remote `trunk_dev` =
  verified squash;
- source, squash, index, and worktree tree =
  `45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4`;
- divergence `0 ahead / 0 behind`;
- clean staged/unstaged/untracked/unmerged posture;
- one worktree and no active operation/lock;
- unchanged six endpoints and 240 unaffected paths;
- unchanged cache;
- preserved remote topic at the original source.

Do not delete the topic branch or source commit.

## 10. Stop rules and partial outcomes

Before the merge write:

- baseline/source/tree/blob/message/index/worktree mismatch:
  `AUDIT_PROVENANCE_MISMATCH`;
- policy, readiness, actor, PR-text, source-branch-deletion, unsupported route,
  hook/signing, unavailable read, pre-existing merge, or other preflight block:
  `RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_MERGE_GATE_BLOCKED`.

After the one merge request:

- known refusal with conclusive unmerged readback:
  `RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_MERGE_GATE_BLOCKED`;
- outcome not conclusively known after bounded read-only reconciliation:
  `RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_MERGE_OUTCOME_UNRESOLVED`;
- exact desired merge conclusively occurred despite response loss:
  continue only with still-unperformed authorized fetch/ref update after all
  verification passes;
- merge occurred but verification, fetch, local realignment, cleanup, or final
  synchronization is incomplete:
  `RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_MERGED_LOCAL_REALIGNMENT_INCOMPLETE`.

If fetch or `update-ref` returns an error or ambiguous response, inspect actual
refs/objects read-only. Do not repeat either command. If the exact intended
effect already occurred, verify and continue only to remaining authorized
checks.

Never roll back a completed remote merge, force refs, delete the source, amend
the source, or hide partial effects.

Success:

`RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_PR_SQUASH_MERGED_AND_LOCAL_REALIGNED`

## 11. Cleanup and inline closeout

Remove only this gate's positively identified external request/response/helper
files after all processes finish. Do not clean repository state or pre-existing
cache.

Return:

1. primary outcome and visible settings;
2. opening local coordinates and fresh remote/PR/policy/readiness coordinates;
3. exact source commit/tree/parent/message/identity/signature status;
4. six-file parent/source/squash table with mode, size, SHA-256, and blob OIDs;
5. exact canonical request bytes/hash and merge request count/response;
6. final PR state, merger/time, remote trunk/topic and non-trunk-head preservation;
7. verified squash OID, parent, tree, message form, attribution/signature status;
8. exact fetch command, fetched raw-object verification, and fetch count;
9. exact `update-ref` command, reflog reason, and update count;
10. final local branch/upstream/divergence/status/tree/cache state;
11. all task-created temporary effects and actual non-actions;
12. continuation capsule no longer than 800 words.

Do not rerun tests in this gate. State explicitly that the previously accepted
8,812-test result is historical validation evidence, not a merge-gate run.

A successful merge adopts only the target documentation and bounded synthetic
checker. It does not qualify an external source or supplier, implement
scope-admission provisioning, create migration `0005`, activate runtime
recovery, enroll or launch an incarnation, implement RW0-D, or execute RW0-E.
