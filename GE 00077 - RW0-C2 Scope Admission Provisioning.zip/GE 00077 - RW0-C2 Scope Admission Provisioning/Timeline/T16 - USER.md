Here is Codex's response:

## Independent re-audit

**Accepted for a separately issued commit gate.** No High- or Medium-severity in-scope finding remains. This is an audit of target-only documentation and a synthetic checker; it is not approval for live provisioning.

**Visible settings:** Codex, GPT-6 based; specific model variant and reasoning effort not visible. Filesystem permission was unrestricted, with approval policy `never`. No subagents or model workers were invoked.

### Provenance and preservation

Opening and closing coordinates matched: `trunk_dev`; HEAD `630414faa07f4ac39c4a870a9cc44c7f92d46b80`; tree `cd81f7cca8b64cb9ff221537257e70e2c5a655a3`; sole parent `d070bf05d2e68472e18b1b077259e67864923e8f`; subject `docs: freeze RW0-C2 first-live proof posture`; upstream `origin/trunk_dev`; locally observed divergence `0/0`. There was one worktree, an index equal to HEAD, and no staged, unmerged, operation, sequencer, or Git-lock state. Tracking equality was **not** treated as fresh remote truth.

| Status | Repository-relative path | Bytes | SHA-256 | HEAD blob |
|---|---|---:|---|---|
| M | `.docs/autonomous-software-development-operating-model.md` | 39,708 | `ccca078da9da0eca90d6e0f86bb30dbda9960765276e7737d4af8b66cc9197a1` | `9207ff698920682dc25057a9fc12b9f2a8cb28d7` |
| M | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 26,041 | `0ebe519379a689f87a2f6ddabeeede5f96d1c5d4ec8f90373f555f38fc61ca44` | `b737b4feff254e2da5d04151575acfbd06f201f3` |
| M | `.docs/rw0-c2-first-live-proof-posture.md` | 15,857 | `ab0c7a57b5807207203c5c31a4ba00b671a4e898264c4e9c1119d3517d959ce3` | `d88c3a6a0ec032e460cbd68c97dfe5b915a0514d` |
| M | `.docs/rw0-c2-private-value-versioning.md` | 207,681 | `966a1f5ac158ad6e597aa7922328612d0993e6e8c109f766aedd9ac7cc8bd251` | `54f84052d97d927e8ccc874b39b1fe8aa8596cff` |
| ?? | `.docs/rw0-c2-scope-admission-provisioning-contract.md` | 23,631 | `9af662213b3a9fe51a0c2f12449e46a3a1ea9d3172ac7e3d99ce7ce9fd509449` | absent |
| ?? | `tests/test_rw0_c2_scope_admission_provisioning_contract.py` | 71,224 | `6a9ec185d9595aeb51708c92827fc2798a2ae5497de54fa3e563a20791b7b093` | absent |

All six were regular, nonsymlink mode `0644`, strict UTF-8, with one final LF and no BOM, CR, or trailing whitespace. The four tracked entries retained Git mode `100644`. Both additions were absent from HEAD and the index. Two fresh ordered patch reconstructions each produced component lengths `1,435 / 1,230 / 1,425 / 2,162 / 24,271 / 73,038`, totaling **103,561 bytes**, SHA-256 `77abc6ae33e52ac907a1d2ce4d3fa2c3710c114ffdb08d5467ad38b0973bdf58`.

The five document hashes match the supplied prior-candidate receipts. The supplied V3 checker receipt was 59,562 bytes, SHA-256 `b85d061237bb7a8be463c2efacc80a65b13f9dbe8a8a65f0fd148aeff3b5e346`; its historical bytes were not available for a direct V3-to-V4 diff. I read the four HEAD blobs directly and checked every edit against them. The private-value machine block from `.docs/rw0-c2-private-value-versioning.md:575` through EOF is byte-identical to HEAD; its existing verifier is unchanged. All 240 noncandidate tracked paths, their bytes and Git-relevant modes, source, catalog, schemas, migrations `0001`–`0004`, and existing tests remained HEAD-exact. Migration `0005` is absent. The opening and closing live cache inventories matched: one directory and 37 regular files, aggregate inventory SHA-256 `45d3e5458d2baea95036f8904cfdfb015c18882a4e470ff19304cc95e0c50487`.

### Source authority and timestamp checks

The complete source-observation inventory in `tests/test_rw0_c2_scope_admission_provisioning_contract.py:184`–`322` is:

| Wrapper | Exact built-in string fields |
|---|---|
| Policy | `audience`, `act_ref`, `act_digest`, `projection_digest`, `lineage_ref`, `scope_ref`, `guard_profile`, `applicability`, `provenance_ref`, `provenance_digest` |
| Enrollment | `lineage_ref`, `scope_ref`, `enrollment_ref`, `incarnation_ref` |
| Custody | `lineage_ref`, `scope_ref`, `incarnation_ref`, `authority_process_ref`, `storage_custody_ref` |
| Evidence | `enrollment_ref`, `enrollment_digest`, `recording_permission_ref`, `recording_permission_digest`, `custody_ref`, `custody_digest` |

The 12 exact built-in booleans are `authenticated_act`, `original_enrollment`, `activated_original_incarnation`, `original_process_and_storage`, `sole_active_no_foreign`, `same_original_process`, `supervisor_live`, `recording_permission`, `disclosure_permission`, `current_source`, `local_writer_fenced`, and `old_execution_excluded`. I compared that fixed inventory with every dataclass field. The synthetic `commit` argument and `_Store` fault flags are fixture controls, not additional source-observation fields.

`_valid_source_observation` checks exact wrapper classes and every scalar with `type(...) is ...` before `_source_boundary` compares candidate/source fields or fixed owner literals (`tests/test_rw0_c2_scope_admission_provisioning_contract.py:293`–`322`, `:483`–`521`). Disclosure gating then precedes protected reads (`:525`–`533`, `:561`–`570`, `:605`–`613`). Independent probes covered all 25 string fields, all 12 booleans as integer `1`, a wrapper subclass, and four profile/applicability subclasses with hostile equality. Across **42 cases and 84 apply/readback calls**, every result was content-free `recording_authority_unavailable`, with zero protected reads, family builds, or time checks and no hostile comparison, coercion, hashing, or raw exception. Wrong-type disclosure with a malformed stored family also refused before its read. Exact-built-in A/B/C sources succeeded; coordinated exact-built-in foreign profile and applicability values failed the fixed owner gate (`:493`–`503`; permanent controls at `:1127`–`1275`).

The owner requires an exact whole-second UTC calendar `recorded_at` at `.docs/rw0-c2-scope-admission-provisioning-contract.md:97`–`100`. The checker requires exact `str`, the 20-character uppercase `YYYY-MM-DDTHH:MM:SSZ` form, a real parsed date/time, and round-trip equality (`tests/test_rw0_c2_scope_admission_provisioning_contract.py:337`–`346`). Direct positive specimens included the fixed `2026-10-14T12:00:00Z`, a leap day, and years `0001` and `9999`. **Seventeen invalid specimens** covered a `str` subclass, arbitrary text, fraction, offset, lowercase `z`, surrounding whitespace or LF, February 30, invalid hour/minute/second and leap second, and non-zero-padded components. Every invalid fresh call returned `invalid_input` with zero builds and appends. Tracing established protected read → time validation → build → append for valid fresh recording (`:595`–`601`).

Exact replay with an invalid *new* synthetic time returned the unchanged original family and checked only its stored time. Readback has no new-time argument. Invalid stored time yielded apply `family_unverifiable` and readback `unresolved` (`:400`–`420`, `:571`–`580`, `:605`–`626`). Disclosure denial preceded invalid-time validation; renewed evidence passed the stable-source join but could not permit an invalid fresh time. These direct compositions also preserved the earlier disclosure, malformed-observation, collision, exhaustive-absence, old-execution-exclusion, no-repair, and same-process-versus-restart boundaries (`:566`–`626`; `.docs/rw0-c2-scope-admission-provisioning-contract.md:263`–`303`).

### Validation and effects

A remote-free local clone of exact HEAD received only the six verified overlays. Its 246 endpoints matched before and after testing. With `umask 022`, `PYTHONDONTWRITEBYTECODE=1`, `PYTHONPATH=.:src`, and distinct precreated external basetemp parents, I ran serial `python3 -m pytest -q -p no:cacheprovider --basetemp=<group-specific external path>` collection and execution for:

- **A:** `tests/test_rw0_c2_scope_admission_provisioning_contract.py` — 54 unique collected, 54 passed.
- **B:** the ten owning/composition files listed in the request, in that order — 3,208 unique collected, 3,208 passed.
- **C:** no path selector — 8,812 unique collected, 8,812 passed.

A and B node IDs were disjoint and included in C; `8,812 = 8,758 + 54`. C reported exactly three `DeprecationWarning` records about multithreaded `fork()` on Python 3.13, attached respectively to `tests/test_sqlite_b2c_writer_session.py::test_operation_guard_close_waits_and_retains_authority_until_exit`, `::test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang`, and `::test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock`. `git diff --check` was clean; each new-file no-index check returned the expected difference status `1` with no whitespace diagnostic.

Against V4 bytes, nine disposable transformations weakened source typing, reordered or coerced source checks, weakened or delayed timestamp validation, or made replay depend on a new time. **Every copy parsed, imported, collected 54 tests, and failed semantically at its intended unchanged permanent test** (`tests/test_rw0_c2_scope_admission_provisioning_contract.py:1181`–`1275`, `:1278`–`1387`). The independent direct specimens used fixed expected outcomes outside checker helpers. One external audit-runner assertion initially counted four scalar type expressions where the validator has five including its boolean expression; I corrected that runner assertion outside the live checkout and reran the entire affected probe and mutant gate from the same V4 candidate. No candidate defect or required skipped gate resulted.

The external scan used `lstat` before opening and hashed regular files only. It classified 1,355 SQLite-header files, 50 further SQLite-named regular fixtures, 624 symlinks, five FIFOs, and no sockets or devices. All processes ended; that single mode-`0700` audit root was removed. Post-cleanup live status and cache equality were checked again. No live module, pytest, script, or SQLite connection was run; no file was edited, staged, committed, published, fetched, or sent to a remote. No supplier, provider, credential, enrollment, launch, ES, Bridge, or sibling-repository work occurred.

**Findings:** none in scope. The synthetic checker and passing tests do not qualify a source or implement provisioning.

**Continuation capsule:** A separate commit/publication gate may consider only these exact six endpoint hashes and the 103,561-byte patch hash above, after rechecking provenance. This acceptance grants no source implementation, migration `0005`, supplier qualification, runtime provisioning or recovery, deployment, RW0-D implementation, or RW0-E execution.

RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE
