## Disposition

**Accept the V3 re-audit block. Repair only the new provisioning checker/test module; keep all five candidate documents unchanged. Do not stage or commit.**

The audit independently confirmed the V2 and V3 repairs:

- disclosure permission now gates protected receipt/family observation;
- the synthetic source binds candidate act, lineage, scope, enrollment, incarnation, and custody;
- malformed stored members remain inside the closed apply/readback classifications;
- exact built-in checking works for command and stored-family values;
- foreign exact-string profile and applicability values reach the semantic source/owner boundary rather than being rejected as mere shape errors;
- the required 38 / 3,208 / 8,796 validation groups pass. Pasted text

The two remaining findings are genuine checker defects, but neither requires a contract amendment or product-source change.

## Finding 1: source-observation scalars still lack exact runtime typing

The checker verifies the source wrapper classes, but then compares their scalar fields using normal equality. A hostile `str` subclass can override or influence equality and appear to satisfy:

```text
candidate profile == source profile
source profile == selected owner profile
```

The auditor demonstrated this for both `guard_profile` and `applicability`: a subclassed source value allowed `_apply` to report `scope_admission_recorded` and `_readback` to report `committed_exact`. Even a subclass carrying the correct selected literal was accepted, despite the contract’s exact-built-in rule. Pasted text

The repair must inventory and validate **every scalar field in the independently authored source observations before any comparison**, including:

```text
verified act ref and digest
lineage and scope
guard profile and applicability
audience
recording and disclosure permission
enrollment and incarnation
original-state/custody refs and digests
source status or evidence coordinates
```

The correct ordering is:

```text
source wrapper shape
→ exact built-in scalar types
→ closed syntax
→ candidate/source equality
→ fixed owner-literal checks
→ disclosure gate
→ protected store reads
```

A matching digest or canonical text must not sanitize a hostile subclass. The audit should later verify malicious subclasses that preserve valid-looking text and override equality, not merely benign subclasses.

## Finding 2: the fresh transaction timestamp is appended before validation

The checker accepts a synthetic transaction-owned time, copies it into the new family, appends the family, and returns `scope_admission_recorded` without first validating the owner’s exact whole-second UTC `recorded_at` grammar.

The auditor demonstrated successful recording with both:

```text
a str subclass containing the valid timestamp text
"not-a-timestamp"
```

The resulting family later failed completeness and read back as `unresolved`, but the checker had already emitted a false fresh-recording success. Pasted text

The repair must validate the selected timestamp:

- as an exact built-in `str`;
- against the existing owner-defined canonical whole-second UTC grammar;
- by a strict parse-and-round-trip check;
- before result or receipt construction;
- before family append;
- before any success label.

It must not invent a new timestamp format or contract reason.

The fresh-write sequence should become:

```text
command/source/disclosure/custody validation
→ protected read set and collision checks
→ establish otherwise eligible fresh recording
→ select one transaction-owned timestamp
→ validate timestamp
→ construct family
→ append once
→ return success
```

### Replay and readback must not consume a new timestamp

The transaction time is not a command coordinate and is not replay authority. Exact replay and readback must return the original stored time without selecting, validating, or substituting a new one.

A useful required control is:

```text
exact committed family
+ invalid newly supplied synthetic time
→ exact replay of original family/time
→ no write
```

That distinguishes a true fresh-write timestamp boundary from an accidentally global helper-argument check.

## Repair boundary

The narrowest sufficient mutation ceiling remains exactly one file:

```text
tests/test_rw0_c2_scope_admission_provisioning_contract.py
```

The five documents must remain byte-identical:

```text
.docs/autonomous-software-development-operating-model.md
.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md
.docs/rw0-c2-first-live-proof-posture.md
.docs/rw0-c2-private-value-versioning.md
.docs/rw0-c2-scope-admission-provisioning-contract.md
```

The audit found no governing-contract defect requiring a documentation change. It also confirmed that profile and applicability mismatches with exact built-in strings now reach the correct semantic relation. The next repair must preserve those V3 advances rather than move the owner literals back into structural command validation. Pasted text

## Codex handoff

Resume the **same implementation Codex conversation**, keep the parent as sole writer, and use the exact V3 candidate as the opening state.

:chatgpt-content-reference{index="6"}[Download the V4 checker-repair prompt](sandbox:/mnt/data/Coordinator_RW0_C2_Scope_Admission_Provisioning_Checker_Repair_V4_Prompt.txt)

```text
Filename:
Coordinator_RW0_C2_Scope_Admission_Provisioning_Checker_Repair_V4_Prompt.txt

Bytes:
22,038

SHA-256:
a8099a1e598a7fe615d823cbfd695e7f55eb520a6b68567821b5d2b879c5e021

Logical lines:
582

Final newline:
present
```

The prompt binds the exact opening candidate:

```text
HEAD:
630414faa07f4ac39c4a870a9cc44c7f92d46b80

Tree:
cd81f7cca8b64cb9ff221537257e70e2c5a655a3

Opening V3 checker:
59,562 bytes
b85d061237bb7a8be463c2efacc80a65b13f9dbe8a8a65f0fd148aeff3b5e346

Opening six-path patch:
91,648 bytes
aece13844db1769ff2167ef8a7ec4966299785d92e474f29fd48d109fefeef43
```

It requires:

- exact built-in validation for every source-observation scalar before comparison or canonicalization;
- hostile source subclasses with custom equality behavior;
- preservation of exact A/B/C positive sources;
- preservation of candidate/source and fixed-owner profile/applicability checks;
- owner-defined canonical timestamp validation before family construction and append;
- fresh-write-only timestamp consumption;
- exact replay/readback preservation of the original timestamp;
- source-type and timestamp compositions with disclosure and stored-family cases;
- seven focused transformed copies;
- serial external validation using the provisioning, owning-contract, and full-repository groups;
- exact preservation of the five documents, all noncandidate paths, migrations, and live cache.

Success token:

```text
RW0_C2_SCOPE_ADMISSION_PROVISIONING_CHECKER_REPAIRED_V4_READY_FOR_INDEPENDENT_AUDIT
```

Blocking token:

```text
RW0_C2_SCOPE_ADMISSION_PROVISIONING_CHECKER_V4_REPAIR_BLOCKED
```

A successful V4 result authorizes only another fresh independent read-only re-audit. It does not authorize publication, product source, migration `0005`, supplier qualification, runtime provisioning, enrollment, launch, deployment, RW0-D implementation, or RW0-E execution.

**Source:** Fresh V3 independent re-audit supplied in this turn. The audit reproduced exact provenance and validation and explicitly identified these two remaining Medium-severity checker defects. Pasted text Pasted text

**Confidence:** High on the audit block and one-file repair boundary. High that exact source-scalar typing and pre-append timestamp validation are the narrowest sufficient fixes.
