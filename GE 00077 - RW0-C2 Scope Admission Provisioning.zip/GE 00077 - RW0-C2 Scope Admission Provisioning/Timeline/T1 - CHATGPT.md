## Next tranche

**Proceed with a program-independent scope-admission provisioning contract: documentation and finite causal tests only.**

The first-live custody model is already settled. This tranche should define **how Coordinator records an externally authorized admission**, not redesign who admits the lineage, how the incarnation is enrolled, or how a custody supplier operates.

I re-grounded on the October 14 snapshot. The new provisioning owner and test module are absent; the existing first-live profile explicitly reserves this separate recording operation before any development program exists. The private-value owner already fixes the admission fact’s representation and assigns recording/readback to a separate provisioner. [1][2]

**No additional broad reconnaissance is needed.** The remaining choices are sufficiently bounded to give Codex a complete contract-writing task.

## Engineering decisions

### 1. A separate recording family—not a dummy development program

Current `development_mutation_receipts` requires a `program_ref`, references a program head, and has a closed set of mutation families and result classes. It cannot represent program-independent admission recording without changing its meaning. [3]

The new owner should therefore define one separately versioned provisioning operation family:

```text
verified admission-act binding
+ unchanged immutable scope-admission fact
+ historical recording evidence
+ one provisioning result and receipt
```

Those are **logical membership requirements**, not a decision to create one SQL table or row for each item.

This separate receipt is justified because it records a different operation. It is **not** a second receipt for productive acceptance. Likewise, its recovery classifier answers whether admission recording committed; it does not classify the subsequent C2 acceptance family.

The operation may run before any program exists, but should not require an otherwise empty database. Unrelated initialized programs remain untouched.

### 2. Preserve the admission fact; put operation-specific information elsewhere

The adopted admission fact binds the authenticated act, lineage, scope, guard profile, applicability, provenance, and one-shot ceiling. Its closed grammar contains **no program, incarnation, recording-operation, or timestamp field**. Its identity is expressly independent of operational realization and command identity. [2]

That rules out adding those fields for convenience.

The recording command and receipt must instead bind the operation to its verified enrollment/incarnation context, the evidence used at recording, and one original recording timestamp. The fact itself remains unchanged.

Fresh verification for later readback must remain separate from that historical family. Refreshing current evidence must not change the original command digest, admission fact, receipt, or timestamp.

### 3. Bootstrap recording must not require the fact it is creating

The first-live sequence is:

```text
externally authenticated admission
→ independent non-reissuable incarnation enrollment
→ one managed authority activation
→ separate admission recording
→ later guarded C2 commands consume the recorded fact
```

The provisioner verifies the external act, current recording authority, and original live custody **without requiring an existing local admission row**. Otherwise, first recording would be impossible.

That is a narrowly scoped bootstrap entry—not a relaxation of C2’s admission checks. The guarded decision writer still cannot initialize missing admission, and a shaped value, local empty database, or existing enrollment record does not independently authorize recording. [1][2]

No external pre-commit arm, settlement, or checkpoint write is introduced. The merged first-live profile explicitly excludes those mechanisms for admission and acceptance recording. [1]

### 4. Exact replay is operation-specific; duplicates do not create another receipt

I am selecting the following behavior for the new provisioning owner:

| Observed condition | Selected behavior |
|---|---|
| Verified act, current authorized original custody, and all target recording identities absent | Record one atomic family |
| Same operation and same command, complete exact family | Return the original result and receipt without writing |
| Same operation, different command | No-write identity conflict |
| Same act under a different operation, including an alternate proposed fact reference | No-write already-recorded/identity conflict—not another recording or exact replay |
| Different act, lineage/scope alias, occupied identity, or contradictory binding | No-write conflict |
| Partial, orphaned, duplicate, malformed, or unreadable family | Fail closed; do not complete or repair it |

These are **proposed provisioning semantics**, not current runtime behavior.

The read set must cover operation identity, fact identity, lineage occupancy, scope occupancy, and act binding—not merely the proposed fact reference. Otherwise, choosing another reference could disguise duplicate recording.

Exact replay also must not recheck whether productive acceptance is still unclaimed. Admission recording and acceptance eligibility are different operations. Provided original custody and current disclosure permission remain valid, later downstream use does not change the original provisioning receipt.

### 5. Recovery stays inside the original incarnation

Current program-initialization and RW0-C1 code provide useful precedents: receipt-first replay, one commit attempt, complete-family readback, and explicit commit-uncertainty handling. They do **not** supply the new provisioning semantics automatically. [4]

For this operation:

```text
complete exact original family
    → committed_exact

all prospective family identities absent,
original custody intact,
and the old execution unable to commit later
    → definitely_not_committed

anything partial, conflicting, unreadable, or unproved
    → unresolved
```

A missing receipt alone is insufficient. Recovery performs no write, fragment completion, automatic retry, enrollment renewal, or replacement launch.

There is an important compatibility distinction: **acquiring a fresh local `WriterSession` is not necessarily restarting the Coordinator authority process.** The existing local recovery contract permits fresh-session acquisition under its own fencing and cleanup rules. The first-live profile separately forbids productive resumption after authority-process or custody loss. The new contract must compose those rules rather than transplant generic different-process recovery into first-live permission. [4][5]

After proved noncommit, a future caller may explicitly resubmit the **same original command** under current standing policy. Recovery itself does not schedule that action, and this does not require a new human approval for every attempt.

## Keep the tranche proportional

The new files are:

```text
.docs/rw0-c2-scope-admission-provisioning-contract.md
tests/test_rw0_c2_scope_admission_provisioning_contract.py
```

The prompt permits only directly justified ownership-link and status amendments in the existing governing documents and their corresponding tests. It preserves the eleven private-value schemas, their machine inventory and digest meanings, the owner-assertion profile, and the completed prose parser.

Testing should establish the recording operation’s causal boundaries: first recording without a program, rejected unauthenticated emptiness, exact replay, duplicate/alias conflicts, commit-response loss, partial families, late-writer exclusion, same-process session renewal versus forbidden restart, and offline fixture independence.

**No new generic protocol engine, extensive prose-verification framework, physical schema design, or supplier experiment belongs here.**

Concrete supplier conformance remains mandatory before work relying on real custody guarantees and live RW0-E entry. It does not become a prerequisite for these synthetic contract tests or repeatable RW0-D fake-source engineering. [1]

## Codex handoff

Start a **fresh parent-only Codex conversation with documentation/test write permissions**, select the highest exposed reasoning setting, and attach nothing.

:chatgpt-content-reference{index="1"}[Download the complete scope-admission provisioning contract prompt](sandbox:/mnt/data/Coordinator_RW0_C2_Scope_Admission_Provisioning_Contract_Tranche_Prompt.txt)

```text
Bytes: 32,402
Lines: 602
Final newline: present

SHA-256:
21fbf2ee2fbeeb94c56bfa619566018add34e53211e0c8dcde305fea3fc4a943
```

The prompt binds the current merged baseline:

```text
Repository:
 /Users/ds/Repositories/Governed Execution Coordinator

Branch:
 trunk_dev

HEAD:
 630414faa07f4ac39c4a870a9cc44c7f92d46b80

Tree:
 cd81f7cca8b64cb9ff221537257e70e2c5a655a3

Sole parent:
 d070bf05d2e68472e18b1b077259e67864923e8f
```

It contains the complete operating decisions, inspection scope, doc/test allowlist, semantic family requirements, replay/conflict/recovery rules, finite evidence cases, exact validation groups, preservation requirements, and inline provenance recipe.

Success is:

```text
RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_READY_FOR_INDEPENDENT_AUDIT
```

A bounded stop is:

```text
RW0_C2_SCOPE_ADMISSION_PROVISIONING_CONTRACT_BLOCKED
```

Success supports only a **fresh independent read-only audit**. It authorizes no commit, publication, source implementation, migration `0005`, supplier qualification, runtime provisioning, deployment, or live proof.

## Sources and inspection boundary

Primary source: Governed Execution Coordinator - Snapshot - 2026-10-14.zip[October 14 Coordinator snapshot](sandbox:/mnt/data/Governed%20Execution%20Coordinator%20-%20Snapshot%20-%202026-10-14.zip), available as the current project snapshot. [Governed Execution Coordinator - Snapshot - 2026-10-14.zip](https://chatgpt.com/library/d/file_00000000cc7c81f6881a367df8d0489d)

**[1] First-live ownership, recording, and external participation:** `.docs/rw0-c2-first-live-proof-posture.md:32–65,79–113,184–216`.

**[2] Immutable admission and private-value constraints:** `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md:36–62`; `.docs/rw0-c2-private-value-versioning.md:19–59,584–630`.

**[3] Program-bound receipt implementation:** `src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql:537–566`; `_development_decision_row_values.py:458–499`.

**[4] Existing replay and recovery precedents:** `_sqlite_development_program_initialization.py:196–271`; `.docs/c2b-durable-development-state.md:19534–19585`; `.docs/rw0-c1-durable-evidence.md:162–210`.

**[5] Original-incarnation restriction:** `.docs/rw0-c2-first-live-proof-posture.md:115–145`.

I inspected the snapshot’s relevant documents, source, SQL, configuration, and tests **as data**. I did not access the live repository or execute repository code or tests. The generated handoff was reopened, and its explicit existing file paths were checked against the snapshot.

Some older uploads have expired. Please re-upload an older original only when a later comparison needs its bytes; this tranche needs none.

**Confidence:** High on the next-tranche boundary, separate program-independent receipt requirement, and preservation of the merged first-live model. The new operation’s exact contract remains a candidate until written and independently audited; physical and supplier feasibility remain separate gates.
