# Governed Execution Coordinator — RW0-C2 Bootstrap Acceptance-Guard Governing Reset Independent Audit

## Role

Perform a fresh, parent-led, local, read-only independent audit of the
uncommitted RW0-C2 bootstrap acceptance-guard governing-reset candidate.

Use the highest available Codex reasoning setting. At the beginning of the
report, record exactly what the interface visibly shows for:

- model name;
- reasoning setting or effort.

Do not infer hidden configuration. Record `not visible` when necessary.

The checked-out repository is the sole audit target and source of current
contract truth.

Do not request or use chat exports, prior audit attachments, Downloads
artifacts, Project artifacts, generated manifests, or historical design
packages. The implementation closeout is evidence only; reproduce every
material claim from the live repository.

Do not repair the candidate.

Return one substantive audit report inline. Do not create or attach a report,
manifest, package, freeze artifact, or other client-visible file.

## Repository and committed baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Expected committed baseline beneath the candidate:

- branch: `trunk_dev`
- HEAD: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- HEAD tree: `42cc0757b3d9604dfe7fdbda158074b8b48dac7b`
- sole parent: `db16de711986ae40a2bb848ed00cdddd3145ee02`
- subject: `docs: freeze RW0-C durable decision branch contract`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- zero staged paths
- zero unmerged paths
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Do not fetch or contact remotes.

Any baseline, path-set, classification, type, mode, size, or per-file SHA-256
mismatch requires:

`AUDIT_PROVENANCE_MISMATCH`

Stop before correctness inspection.

## Exact 28-path candidate

Require exactly 26 tracked modifications and two untracked files, with no other
tracked or untracked difference from HEAD.

All 28 paths must be regular, non-symlink mode-`0644` files, valid UTF-8, with
no CR bytes, no trailing whitespace, and one final newline.

| # | Status | Path | Bytes | SHA-256 |
|---:|---|---|---:|---|
| 1 | `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 70,858 | `4fc2b7f9d5810105c28a7ce11abe85d08a48f915a87b088ae86e5520aa2142e2` |
| 2 | `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | 57,192 | `2c0c9565f7fb4ae79eca998080f3b70734f9a4fd1e555132daf9b94daab1dc97` |
| 3 | `M` | `.docs/c2a-first-slice-semantic-protocol-contract.md` | 103,413 | `a690441d046d147cf11a068e07a894858e3d32476e19fef84a9bb26e6e6f0d99` |
| 4 | `M` | `.docs/c2b-durable-development-state.md` | 1,889,083 | `db065fd8fd37d537bdac3194f021995dfcf2fbd92a31d2c7e4f0dc4c4e3a60d7` |
| 5 | `M` | `AGENTS.md` | 61,466 | `001595cdec75b176abbfb99b91b2b06c45f2f2ff1a28c704ded7054c27c7e74e` |
| 6 | `M` | `README.md` | 45,849 | `b66fb689d9f0849eee1d62f12dda93d83dcc9f4cce2fa008696878b44256ad1a` |
| 7 | `M` | `.docs/architecture.md` | 43,007 | `60a884471d655ee6eddad8c405aa218eab492e3c610b101c0736fc9f2546288f` |
| 8 | `M` | `.docs/autonomous-software-development-operating-model.md` | 37,829 | `115ed6c16141f821147f640131bed904526cee914dbec6951f3667b0da100f05` |
| 9 | `M` | `.docs/authority-boundaries.md` | 34,686 | `69d524c839a2195cf0b5840be424c021305825fd0db1d85c76ed28b99c1bf055` |
| 10 | `M` | `.docs/durable-state-model.md` | 40,564 | `e14a421698f0735fa098fe6ce1063b64d07e1c212fd6b60755e1068c9caf5955` |
| 11 | `M` | `.docs/worker-execution-boundary.md` | 30,920 | `6f7d2f7855fcbdecc757af4dde7a7bb091ab1e8c60057a2fefe407f74de4055f` |
| 12 | `M` | `.docs/software-development-progression-boundary.md` | 28,654 | `b8761655ee42512c0e77ab8c774c2b2d3d8f9ac36a9bd0c74872ad4bf2994419` |
| 13 | `M` | `.docs/c2b3-program-initialization.md` | 27,687 | `8e9c2c6f49551b28d95de28f6d7b071c89dd0ea155ce7d7a6e21e8d88e73d1f7` |
| 14 | `M` | `.docs/rw0-b2-wire-protocol.md` | 24,346 | `7f977a5a60fd66c69464190731e09611ca24854313e145b73cc73f564776477b` |
| 15 | `M` | `.docs/rw0-b2-capability.md` | 17,753 | `171341fc60cbe762403f1e64676ca35c9ea2f778a10d0fc66d668f1c84dc884c` |
| 16 | `M` | `.docs/rw0-b1-pure-phase-values.md` | 33,032 | `8bccdaa31fa66821b73c136936c12ef001157209c72b9991839905c1a8e0e053` |
| 17 | `M` | `tests/test_architecture_contracts.py` | 100,410 | `555ac490738d12075d3908ec2ddfd090fdbb32d8a6fd53d1b3136d24485e1169` |
| 18 | `M` | `tests/test_rw0_remote_contact_phase_entry_contract.py` | 173,524 | `42d6d265c0a9ba5047aa37ec3a4daae30847d486d39ead6374685b451a1d445c` |
| 19 | `M` | `tests/test_remote_worker_pre_execution_planning_contract.py` | 913,152 | `92b0f3917f0572492357447211a1f0f0cc7f8edb7e8b5f18233ed80397879b29` |
| 20 | `M` | `tests/test_software_development_progression_boundary.py` | 42,899 | `bd9b10f62e3bbfb3dc5fc845958fe0087363a0afa0b80649853faac85235c7a3` |
| 21 | `M` | `tests/test_autonomous_software_development_operating_model.py` | 72,904 | `e9a77edb1f99b181c612e52c4a7cfee814ac3f0df4d974e7c3a0756aec6da8df` |
| 22 | `M` | `tests/c2a_contract_support.py` | 154,372 | `58be92ddffae6f4b901ae3632521481ab8d9ce0e02a819ef9421408d08eedd85` |
| 23 | `M` | `tests/test_rw0_b1_boundaries.py` | 38,321 | `bd52384897f8f7a7129023c693ef67b1ff453a006723438dfa4f06df08e4121f` |
| 24 | `M` | `tests/test_rw0_b2_capability_boundaries.py` | 39,011 | `51e728f48b6c024f782f7b32b46e5c8de11bb519702e7478d3fb420655c4822a` |
| 25 | `M` | `tests/test_c2b0_durable_state_contract.py` | 882,642 | `deb6164d311189fa1eeab68dbf4296bdaf6b9bafe6e1808ce8122d1a8e4dd2ec` |
| 26 | `M` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | 245,532 | `718d10e2047b49a5e5baa65db92e434b0fcd1d23a821124529e13e10b26951ff` |
| 27 | `??` | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 25,151 | `bf65ba7f04411bb6e6febec2285b33721eb2ff895e2c60aee97878b1fa7c9b46` |
| 28 | `??` | `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | 35,975 | `d919401246964c0db667db5d42df7bcc454a689964bc11cf91913d181b2f604d` |

Require:

- zero staged paths;
- zero unmerged paths;
- zero deletions, renames, type changes, symlinks, executable-mode changes, or
  additional untracked paths;
- every tracked path outside this set byte-identical to HEAD.

## Complete patch and receipt corroboration

Construct the complete candidate patch in the exact 28-path table order.

For each tracked path:

```text
git diff --binary --full-index --no-ext-diff --no-textconv HEAD -- <path>
```

For each new path:

```text
git diff --no-index --binary --full-index --no-ext-diff --no-textconv -- /dev/null <path>
```

Treat expected `git diff --no-index` status `1` as “differences found.”

Concatenate exact stdout bytes in table order.

Implementation-reported coordinate:

- bytes: `237,485`
- SHA-256:
  `aee578da6130705e8b1275397c53862060a3b2bff097c0a325cd985bfa8e9bbc`

Implementation-reported canonical receipt:

- bytes: `10,139`
- SHA-256:
  `2f7a5adec5d5d43d156e84974bc86256b836fe3a835bd44b6fd08e65ec5c6cb1`

Run both calculations twice.

The exact path set and per-file receipts are primary provenance. If those
coordinates are exact but a derived aggregate differs, reproduce the prescribed
assembly, determine the envelope difference, and continue only when there is no
candidate-byte ambiguity. Any unresolved baseline, path, or file-byte mismatch
remains `AUDIT_PROVENANCE_MISMATCH`.

## Historical-byte coordinates

### C2B durable-state document

Require the final file to begin with the exact complete committed opening bytes:

- opening bytes: `1,887,232`
- opening SHA-256:
  `77bf3d3c6ed710da669db7fa4353f46f3d1e9b4e09636918046d16d94ed962e5`

The implementation reports one 1,851-byte append after the original EOF.

Verify exact prefix equality. Inspect the successor’s authority and placement;
do not rely only on length.

### C2B3 program-initialization document

The implementation reports:

- original bytes: `26,747`
- original SHA-256:
  `3d93195ab570e96f8f535feb38f83ebcd6b6ba112ca1db2a47d04b19258ef567`
- bounded insertion: `940` bytes;
- insertion immediately before the existing final committed-current-status end
  marker.

Independently remove exactly the candidate insertion and require byte-exact
reconstruction of the committed file, including its original EOF structure.

Verify that no historical planning/genesis claim was rewritten.

## Audit posture

This is an independent audit, not implementation validation.

Permitted:

- read-only Git inspection;
- static inspection of documentation, source, schemas, migrations, tests,
  examples, and configuration;
- read-only lexical and AST analysis with `PYTHONDONTWRITEBYTECODE=1`;
- pytest and hostile mutants only in private external local clones;
- at most three bounded read-only explorer subagents with self-contained
  prompts.

Prohibited:

- editing, formatting, cleaning, or repairing live files;
- staging, committing, pushing, PR operations, or merging;
- remote or sibling-repository contact;
- moving, deleting, rewriting, or importing through the live ignored cache;
- opening or mutating an operator or product-state database;
- running migrations or services;
- installing dependencies;
- generating client-visible artifacts.

Remove all audit-created temporary data at closeout.

## Source-of-truth and classification

Apply the repository authority hierarchy:

- Git owns commit/tree/blob/ref facts.
- `AGENTS.md` owns repository guidance and routing.
- `.docs/` owns current and accepted-target semantics within declared scopes.
- the operating model owns composition and current-status classification.
- source and migrations own current implementation and durable representation.
- tests are evidence and drift guards, not independent semantic owners.
- reports are evidence only.

Classify each finding as:

- current implemented contract;
- accepted target contract;
- bounded compatibility edge;
- historical/proof precursor;
- reopened future seam;
- authority/contract drift;
- semantic defect;
- test-adequacy defect;
- documentation/supersession defect;
- provenance mismatch;
- validation defect;
- artifact/security concern;
- report-only uncertainty.

## Recommended explorer structure

At most three bounded read-only explorers may be used.

### Explorer 1 — authority, scope, and historical supersession

Audit:

- Option A lineage policy;
- immutable admission/acceptance facts;
- four-document normalization;
- C2/C2A/C2B/C2B3/AGENTS/README/progression routing;
- stale mutable-latch target language;
- historical versus current authority.

### Explorer 2 — replay, recovery, branch, and B1 compatibility

Audit:

- the C2/guard two-owner split;
- ordering, branch effects, replay, collisions, and one whole-family classifier;
- terminal and ES boundaries;
- B1 legacy-field compatibility and nonproof;
- no shadow implementation.

### Explorer 3 — test causality, protected identities, and provenance

Audit:

- human/machine equivalence;
- hostile/mutant independence;
- four-body map tests;
- P08/P11/P12/P13 semantic supersession;
- historical-prefix preservation;
- source/migration/public/runtime nonimplementation;
- validation and artifacts.

The parent must independently inspect the central evidence and reconcile all
findings.

## Required inspection

Read the complete changed regions and all relevant owner/test edges, including
at minimum all 28 candidate paths.

Also inspect current unchanged owners needed to verify nonimplementation and
compatibility, including:

- `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`
- `src/ge_nwp_coordinator/sqlite_migration.py`
- migrations 0001–0004;
- package exports;
- `StateStore`;
- `WriterSession`;
- transaction, reader, and writer surfaces;
- B1 phase-value, relation, and vector tests;
- C2A nonimplementation tests;
- B2 Wire and cancellation-control tests;
- C2B3 program-initialization tests;
- runtime-nonauthority and public-surface guards.

Follow every additional exact owner/test edge discovered.

## Audit question 1 — authority and current-versus-target truth

Verify:

- the reset changes accepted target semantics but makes no implementation claim;
- the operating model remains composition/current-status authority;
- `AGENTS.md` changes only routing and strategic target rules, without widening
  repository permissions or execution authority;
- source and migrations remain authoritative for current implementation;
- the C2 owner and new guard owner have non-overlapping authority;
- no test becomes the semantic owner;
- no generated evidence is promoted to authority.

Block any competing owner, implementation overclaim, or permission widening.

## Audit question 2 — complete stale-latch supersession

Perform repository-wide, context-aware inventories for at least:

```text
latch
available
consumed
latch_postimage
acceptance_latch_precondition_conflict
bootstrap_acceptance_guard_conflict
```

Classify every live occurrence as:

- current immutable-guard target;
- explicit legacy compatibility name;
- historical/proof precursor;
- accurate current nonimplementation statement;
- unrelated process/resource terminology;
- stale contradictory current target.

Require zero stale current-target mutable-latch requirement outside explicitly
bounded historical or compatibility contexts.

Specifically verify:

- the merged C2 owner no longer normatively requires a mutable preimage,
  available/consumed state transition, latch revision, consumed-latch
  postimage, separate latch receipt, separate replay, or separate recovery;
- remote-phase target language is consistent;
- C2A expansion language routes to immutable facts;
- B2 and progression projections contain no hidden mutable-latch authority;
- historical C2B material is not silently promoted back to current truth.

## Audit question 3 — exact Option A policy

Require the new guard owner and all current projections to agree that:

- one scope belongs to one explicitly standing-policy-admitted Coordinator
  authority lineage;
- deployment, machine, process, database, file, repository, program, attempt,
  candidate, command, parent grant, restore, rollback, clone, passive backup,
  or relocation does not create a lineage or allowance;
- independent lineages require independent admission acts;
- one active Coordinator authority per lineage is supported;
- active-active or ambiguous active authority fails closed;
- continuity after replacement/restore/relocation/clone must be positively
  established;
- local row absence never proves unclaimed status;
- the allowance is permanent and non-renewable after one acceptance;
- later ES operation is separate and never replenishes or resets the allowance.

Require explicit causal tests for every item, not only prose presence.

## Audit question 4 — owner split and no duplicate truth

Verify that the existing C2 owner remains sole owner of:

- command-local reduction;
- currentness, V14/V15, matrices, and branch precedence;
- five branches;
- decision/version/head semantics;
- result and receipt roles;
- mutation identity and command digest;
- exact replay;
- the one whole-family recovery classifier;
- no-write/block/unresolved distinctions.

Verify that the guard owner alone owns:

- lineage and scope semantics;
- standing-policy admission binding;
- continuity and sole-active-authority posture;
- immutable admission and acceptance facts;
- fresh-acceptance guard eligibility;
- permanent non-replenishment;
- guard-facing terminal and ES boundaries.

Block if the guard document or verifier defines a second reducer, receipt,
replay path, or recovery classifier.

## Audit question 5 — ordering and disclosure

Inspect the documented and executable oracle ordering.

Require:

1. command-local grammar and nonsecret structural checks;
2. writer/session admission and fencing before protected receipt/collision
   disclosure;
3. exact receipt-first replay and mutation/family-route collision checks;
4. authoritative currentness/matrix/branch reduction;
5. acceptance-only guard eligibility and unclaimed-scope proof;
6. construction of one atomic decision/version/head/result/receipt/
   acceptance-fact family;
7. exactly one commit attempt;
8. readback-only uncertainty classification.

Universal lineage/admission/continuity/sole-authority requirements must not
silently become a second mutable guard evaluation.

Exact replay must not re-prove that the scope is unclaimed and must not create a
new fact or timestamp.

A different digest under the same mutation must remain
`mutation_ref_reuse_conflict`.

## Audit question 6 — five branch effects

Require exact effects:

- `candidate_acceptance`: one immutable acceptance fact in the atomic family;
- `candidate_repair`: no fact;
- `attempt_selecting_replan`: no fact;
- `program_terminal_reject`: no fact;
- `post_execution_program_block`: no fact.

A guard conflict must be no-write and never converted into durable block.

When lineage/admission/sole-authority posture is exact but only claimed-status
is unresolved, verify the contract’s precise nonaccept rule:

- a nonaccept branch may commit only if it does not depend on an unclaimed-scope
  assertion;
- it creates no fact;
- it makes no projection that the scope is unclaimed.

Require direct causal tests for this distinction.

## Audit question 7 — immutable facts and digest DAG

Independently derive and reconcile the human and machine inventories for:

- admission-fact roles;
- command-facing lineage/scope relation;
- acceptance-fact roles;
- branch effects;
- outcome taxonomy;
- replay/recovery;
- terminal and ES boundaries.

Require an acyclic dependency graph:

1. standing-policy admission act;
2. immutable admission fact;
3. command-local expectation and command digest;
4. decision and resulting version/head;
5. immutable acceptance fact;
6. result;
7. receipt;
8. replay/recovery projections.

Block:

- caller- or model-authored admission or acceptance facts;
- command-selected fresh scope;
- acceptance fact depending on final receipt/result digest in a cycle;
- timestamp required by precommit command digest;
- duplicate JSON keys;
- human/machine drift.

## Audit question 8 — closed taxonomy and competing winner

Verify exact, non-overlapping ownership for:

- missing/duplicate/malformed/foreign/unreadable admission;
- lineage or continuity mismatch;
- multiple/ambiguous active authorities;
- wrong/stale scope expectation;
- unreadable guard family;
- zero exact acceptance facts;
- same-command complete family;
- different-command complete winner;
- duplicate/partial/malformed fact family;
- identity/family-route collision;
- same mutation/different digest;
- nonaccept branches;
- reset/delete/reopen/renew/replenish attempts;
- ES transition.

Require use of:

- `bootstrap_acceptance_guard_conflict`;
- `mutation_ref_reuse_conflict`;
- `preassigned_identity_or_family_route_collision`;
- ordinary command/basis/head owners;
- recovery `committed_exact`, `definitely_not_committed`, `unresolved`.

The superseded `acceptance_latch_precondition_conflict` must not remain a second
active owner.

A competing complete acceptance may prove the original command
`definitely_not_committed`, but must separately make fresh retry ineligible.

## Audit question 9 — one atomic family and recovery

Require one family containing:

- decision;
- resulting version/head;
- result;
- receipt;
- acceptance fact for acceptance only.

Require:

- acceptance fact atomic with the family;
- no second guard transaction;
- decision-without-fact and fact-without-decision are `unresolved`;
- exact replay returns the original fact without another mutation;
- recovery never completes fragments, creates facts, changes scope, reevaluates
  branch, creates a timestamp, or retries automatically;
- mutable heads need not remain at historical postcommit values for replay.

Block any separate guard recovery truth.

## Audit question 10 — terminal and ES boundaries

Require:

- later terminal fact may bind immutable acceptance-fact identity/digest and the
  exact committed family;
- terminal cannot create, consume, reset, update, delete, renew, repair, or
  replenish guard truth;
- acceptance without terminal means terminal record absent;
- unresolved acceptance forbids terminal inference;
- terminal uncertainty leaves acceptance permanent;
- later ES route is separately governed and never replenishes direct-local
  allowance;
- bootstrap fact is not ES admission/runtime authority.

## Audit question 11 — B1 legacy compatibility

Inspect unchanged `RW0TerminalOutcomeV1` source and changed B1 owner/boundary
docs/tests.

Require all of the following:

- `latch_postimage_ref` and `latch_postimage_digest` remain byte-for-byte v1
  field names and grammar;
- schema ID, field order, nullability, canonical bytes, digest domains, budgets,
  and source behavior are unchanged;
- docs openly classify the old target meaning as superseded;
- the pair’s replacement-target obligation is an immutable acceptance-fact
  identity/digest binding;
- the pair implies no mutable preimage/state/revision/transition/classifier;
- current B1 validates supplied representation/coherence only;
- current B1 does not prove lineage scope, admission, uniqueness, commitment,
  atomic family membership, or recovery;
- no new target consumer may treat the pair as durable guard proof before a
  separate safe-value compatibility/versioning decision.

Block silent semantic repurposing or any claim that current B1 implements the
guard.

## Audit question 12 — four-document normalized projection

Independently parse the target body in:

- operating model;
- worker boundary;
- authority boundaries;
- durable-state model.

Require:

- exact four-document inventory;
- exact normalized body equality;
- correct owner markers;
- correct visibility and heading ancestry;
- duplicate/missing/misplaced body rejection;
- identical immutable-guard semantics;
- accurate implementation nonclaims.

Create independent one-body drift and mutable-latch restoration mutants.

## Audit question 13 — historical C2B and C2B3 treatment

### C2B

Require:

- complete opening bytes preserved as exact prefix;
- one bounded successor only;
- old tables, seeds, state/revision transitions, postimages, SQL, triggers,
  indexes, and migration allocations remain historical/proof precursor or
  reopened physical choices;
- the one-shot ceiling and no-reset rule remain;
- current target routes to the guard owner;
- historical tests preserve evidence rather than current physical authority.

### C2B3

Require:

- exact reconstruction of committed bytes after removing only the bounded
  projection;
- no rewrite of historical planning/genesis;
- no claim that a current provisioner exists;
- unchanged `tests/test_c2b3_program_initialization_contract.py` still passes.

Block historical erasure or promotion of historical latch representation into
current authority.

## Audit question 14 — C2A, B2, progression, AGENTS, and README

Verify:

- C2A preserves the one-shot expansion gate and nonauthoritative markers while
  routing enforcement to immutable facts;
- B2 Wire remains representation/classification only;
- B2 Capability remains supplied evidence/qualification only;
- progression boundaries preserve current authority and C1 exclusions;
- `AGENTS.md` changes are minimal, durable, and do not widen permissions;
- README changes are status/product projection only;
- no document claims physical storage, provisioner, reader, writer, public
  surface, or runtime implementation.

## Audit question 15 — capability P08/P11/P12/P13 supersession

Inspect the old HEAD documents, changed documents, and amended capability tests.

Require:

- only P08/P11/P12/P13 changed among protected identities;
- each identity change is explained by the governing semantic reset;
- replacement semantic assertions protect the new meaning;
- no test merely refreshes a byte hash to make changed docs pass;
- unrelated protected identities remain exact.

Create an independent hash-refresh-without-semantic-assertion mutant.

## Audit question 16 — human/machine/test independence

For both the amended C2 contract and the new guard contract, require real
independence among:

1. normative prose;
2. human closed tables;
3. machine JSON;
4. fixed test expectations;
5. interpreter/reducer output;
6. hostile expectations.

Block if one mutable table authors both expected and observed truth.

Require:

- recursive duplicate-key rejection;
- exact human/machine equivalence;
- finite scalar/leaf coverage;
- prose-only and machine-only drift detection;
- exact failure boundaries rather than generic assertions.

## Audit question 17 — all 24 external mutants

Independently recreate all 24 reported mutants:

1. mutable latch restored in one normalized body;
2. one-body drift;
3. C2 mutable-latch prose;
4. C2 machine-only latch restoration;
5. database used as scope;
6. restore creates fresh allowance;
7. admission omitted;
8. active-active accepted;
9. local absence proves eligibility;
10. second unrelated program accepts;
11. nonaccept branch creates fact;
12. guard conflict becomes durable block;
13. replay creates new timestamp/fact;
14. partial family becomes committed;
15. competing winner permits retry;
16. terminal deletes/resets/creates guard truth;
17. ES replenishes allowance;
18. B1 pair treated as durable proof;
19. P08/P11/P12/P13 hashes refreshed without semantic assertions;
20. historical C2B mutable representation promoted to current authority;
21. duplicate JSON key;
22. prose-only drift;
23. machine-only drift;
24. implementation/migration/provisioner/writer/runtime claim.

For each mutant require:

- unchanged expected test collection;
- failure at the intended semantic boundary;
- no syntax-only, format-only, or collection-shrinkage failure;
- exact failed test or boundary ID.

## Audit question 18 — verifier size and shadow-owner risk

Inspect the amended 245,532-byte C2 verifier and new 35,975-byte guard verifier.

Accept document-driven finite contract verification.

Block:

- a second production reducer;
- a second replay/recovery owner;
- source behavior emulation replacing production/source inspection;
- test-local semantics overriding the owner docs;
- self-authored hostile outcomes;
- broad source-manifest freezes presented as architecture.

## Audit question 19 — nonimplementation and protected surfaces

Independently verify:

- all 212 tracked paths outside the ceiling equal HEAD;
- all 66 source/resource paths equal HEAD;
- migrations are exactly 0001–0004;
- migration `0005` absent;
- SQL resource hashes unchanged;
- package exports unchanged;
- `StateStore`, `WriterSession`, readers, writers, and transaction surfaces
  unchanged;
- no guard, admission, acceptance, provisioner, decision-writer, reader,
  recovery, terminal, caller, public, runtime, RW0-D/E, or ES implementation;
- no database or runtime artifact.

## Independent validation

Create a private external local clone from exact committed HEAD without remote
contact. Overlay exactly the 28 verified candidate files.

Do not import from or alter the live ignored cache.

Run serially with:

```text
PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=.:src
python3 -m pytest -q -p no:cacheprovider --basetemp=<external>
```

### New guard verifier

Expected implementation claim:

```text
159 passed
```

### Exact targeted command

Run:

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_architecture_contracts.py \
  tests/test_rw0_remote_contact_phase_entry_contract.py \
  tests/test_remote_worker_pre_execution_planning_contract.py \
  tests/test_software_development_progression_boundary.py \
  tests/test_autonomous_software_development_operating_model.py \
  tests/test_c2a_first_slice_semantic_protocol_contract.py \
  tests/test_c2a_nonimplementation.py \
  tests/test_rw0_b1_phase_values.py \
  tests/test_rw0_b1_vectors.py \
  tests/test_rw0_b1_relations.py \
  tests/test_rw0_b1_boundaries.py \
  tests/test_rw0_b2_wire_boundaries.py \
  tests/test_rw0_b2_capability_boundaries.py \
  tests/test_rw0_b2_wire_cancellation_control_boundaries.py \
  tests/test_c2b0_durable_state_contract.py \
  tests/test_rw0_c2_durable_progression_decision_semantic_contract.py \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

Expected claim:

```text
3,459 passed
```

### Exact broader command

Run:

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_c2a*.py \
  tests/test_worker_execution_semantic*.py \
  tests/test_rw0_b1*.py \
  tests/test_rw0_b2*.py \
  tests/test_rw0_c1*.py \
  tests/test_post_execution_pure_owner*.py \
  tests/test_c2b2*.py \
  tests/test_c2b3*.py \
  tests/test_section41*.py \
  tests/test_runtime_non_authority.py \
  tests/test_state_store_contract.py \
  tests/test_b2a_writer_session_contract.py \
  tests/test_sqlite*.py
```

Expected claim:

```text
3,607 passed, 3 warnings
```

### Full repository

Run:

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external>
```

Expected claim:

```text
7,670 passed, 3 warnings
```

The only expected warnings are the pre-existing Python 3.13 multi-threaded
`fork()` deprecations from unchanged writer-session tests. Record exact warning
identities.

Also run:

- `git diff --check`;
- both new-file `/dev/null` whitespace checks;
- UTF-8/CR/trailing-whitespace/final-newline checks;
- source/migration/public-surface preservation checks;
- C2B/C2B3 historical reconstruction checks;
- artifact scans.

Any count difference or warning difference must be investigated.

## Live cache and cleanup

At opening, record the live ignored-cache inventory read-only:

- path;
- type;
- mode;
- size;
- modification timestamp if used by the implementation receipt;
- SHA-256;
- deterministic canonical inventory.

Implementation-reported coordinate:

- members: `37`
- canonical SHA-256:
  `a2cd6f1a6259e1121b434096d730c83a01043e8993be5471f09a7efd1f00ed65`

Treat this as evidence to reproduce, not authority.

At closeout require exact opening/closing equality.

Remove only audit-created temporary data.

## Final provenance

After audit cleanup, require:

- exact baseline HEAD and branch;
- exact 28-path status and receipts;
- zero staged/unmerged paths;
- no additional path;
- exact complete patch or explained aggregate-envelope discrepancy with no byte
  ambiguity;
- unchanged source/migration/public surfaces;
- exact historical-prefix reconstruction;
- exact ignored-cache equality;
- no audit-created repository artifact.

Run the complete receipt twice and require byte-identical output.

## Severity and verdict rules

Blocking findings include:

- provenance mismatch;
- stale current mutable-latch authority;
- incorrect Option A lineage scope;
- row absence treated as eligibility;
- active-active allowance;
- scope renewal or ES replenishment;
- overlapping C2/guard owner authority;
- separate replay/recovery classifier;
- incorrect ordering or replay re-consumption;
- acceptance fact on a nonaccept branch;
- guard conflict converted to durable block;
- partial family classified committed;
- competing winner permitting retry;
- terminal guard mutation;
- B1 legacy pair treated as current durable proof;
- historical C2B erasure or promotion;
- hash-only capability protection;
- human/machine self-confirmation;
- surviving required mutant;
- source/migration/public/runtime widening;
- unexplained validation mismatch.

### Accept

Use only when no unresolved High- or Medium-severity finding remains:

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_ACCEPTED_READY_FOR_COMMIT_GATE`

Acceptance authorizes only a separate commit/publication gate for the exact
28 audited paths.

It does not authorize:

- source or safe-value changes;
- migration `0005`;
- scope provisioning;
- durable decision writing;
- guard persistence;
- readers or recovery implementation;
- terminal persistence;
- public API widening;
- runtime activation;
- RW0-D/E;
- Execution Substrate work.

### Block

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_AUDIT_BLOCKED`

### Provenance mismatch

`AUDIT_PROVENANCE_MISMATCH`

## Inline report structure

Return:

1. primary verdict;
2. visible model/reasoning setting;
3. exact baseline and candidate provenance;
4. patch/receipt and historical-byte reconciliation;
5. inspection scope and limits;
6. authority/current-versus-target audit;
7. stale-latch supersession inventory;
8. Option A lineage-policy audit;
9. two-owner split audit;
10. ordering/disclosure audit;
11. branch-effect audit;
12. fact/DAG/taxonomy audit;
13. replay/recovery audit;
14. terminal/ES audit;
15. B1 compatibility audit;
16. four-document normalization audit;
17. C2B/C2B3 historical audit;
18. C2A/B2/progression/AGENTS/README audit;
19. P08/P11/P12/P13 supersession audit;
20. human/machine/test-independence audit;
21. all 24 mutant results;
22. shadow-owner audit;
23. nonimplementation/protected-surface audit;
24. independent validation results;
25. final live provenance and cache equality;
26. severity-ranked findings;
27. exact next boundary;
28. required non-actions;
29. final token.

## Required non-actions

State:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIRS_NOT_PERFORMED
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
SCHEMAS_NOT_MODIFIED
NON_CEILING_DOCS_NOT_MODIFIED
NON_CEILING_TESTS_NOT_MODIFIED
OPERATOR_OR_PRODUCT_DATABASE_NOT_OPENED_OR_MUTATED
LIVE_IGNORED_CACHE_NOT_MOVED_OR_MODIFIED
DEPENDENCIES_NOT_INSTALLED
SERVICES_NOT_STARTED
REMOTE_CONTACT_NOT_PERFORMED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
MERGE_NOT_PERFORMED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
BOOTSTRAP_SCOPE_PROVISIONER_NOT_IMPLEMENTED
BOOTSTRAP_ACCEPTANCE_GUARD_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUBAGENTS_READ_ONLY_IF_USED
EXTERNAL_ARTIFACTS_NOT_GENERATED
```
