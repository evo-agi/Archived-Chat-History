# Governed Execution Coordinator — RW0-C2 Bootstrap Acceptance-Latch Owner Contract Freeze

## Role and objective

Resume the same Coordinator reconnaissance conversation after changing the parent
permission posture to workspace-write.

The parent is the sole writer. Do not spawn subagents.

Write and validate one documentation/contract-test-only freeze for the bounded
RW0-C2 **bootstrap acceptance-latch owner**.

The freeze must preserve the merged five-branch decision owner and define the
complete logical owner of the retained one-productive-bootstrap-acceptance
allowance. It must not select or implement SQL, migration bytes, source values,
a writer, readers, public methods, runtime behavior, terminal storage, or the
later physical persistence family.

The owner is deliberately bootstrap-scoped. Do not generalize it into a
permanent universal one-acceptance limit for autonomous development.

Return one substantive inline closeout report. Do not create or attach a report,
manifest, package, or freeze artifact outside the repository.

## Repository and exact baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required opening baseline:

- branch: `trunk_dev`
- HEAD: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- tree: `42cc0757b3d9604dfe7fdbda158074b8b48dac7b`
- sole parent: `db16de711986ae40a2bb848ed00cdddd3145ee02`
- subject: `docs: freeze RW0-C durable decision branch contract`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- clean tracked, untracked, staged, and unmerged state
- no active Git operation or index lock

Do not fetch or contact remotes.

Stop before editing on any mismatch:

`RW0_C_BOOTSTRAP_ACCEPTANCE_LATCH_OWNER_CONTRACT_FREEZE_BLOCKED`

## Current contract truth

Treat the current merged repository as authoritative.

Preserve the existing RW0-C2 semantic owner:

`.docs/rw0-c2-durable-progression-decision-semantic-contract.md`

Current exact receipt:

- bytes: `68,944`
- SHA-256:
  `92f1d2b34f9cf2486102edf31de142acc07db9a116f64d64212ca497d0a554c1`

Preserve its accepted semantics:

- exactly five non-cancel branches;
- Coordinator-derived branch authority;
- no-write versus durable block versus recovery-unresolved;
- every decision command binds a non-authoritative latch selector;
- only derived acceptance tests and consumes the latch;
- acceptance atomically commits the decision family and consumed postimage;
- nonaccept branches create no latch mutation or latch postimage;
- exact replay returns the committed postimage without another mutation;
- decision and latch recover as one committed family;
- terminal outcome later binds but never mutates the latch;
- no accept writer becomes callable before logical and physical latch contracts
  are frozen.

Do not modify the existing semantic owner or its verifier:

`tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`

Current verifier receipt:

- bytes: `239,999`
- SHA-256:
  `9b0751f55b238c55130b6481bbea34454c5ed8866212f5546baa6e5af1b0fa19`

## Historical latch classification

Preserve Section 19 of:

`.docs/c2b-durable-development-state.md`

as historical/proof-only source material. Do not rewrite it.

Its reusable logical concepts are:

- one shared Coordinator bootstrap scope;
- one-way available-to-consumed transition;
- no reset, deletion, or reuse;
- atomic binding to the accepted decision;
- fail-closed treatment of missing, duplicate, malformed, ambiguous, or
  already-consumed state.

Its old table, key, seed, migration-0003 inventory, SQL, trigger, index, and
exact physical representation are superseded/reopened and non-operative.

The current binding constraint is only:

> At most one productive bootstrap acceptance across the governed bootstrap
> scope.

Do not extend that ceiling to all future autonomous development.

## Exact mutation ceiling

Only these six paths may differ from HEAD at closeout:

1. `.docs/architecture.md`
2. `.docs/autonomous-software-development-operating-model.md`
3. `.docs/c2b-durable-development-state.md`
4. `.docs/rw0-remote-worker-contact-phase-entry.md`
5. `.docs/rw0-c2-bootstrap-acceptance-latch-owner-contract.md`
6. `tests/test_rw0_c2_bootstrap_acceptance_latch_owner_contract.py`

The first four are bounded cross-reference/status updates only.

The C2B change must be append-only after the existing EOF and must not rewrite
Sections 1–42 or earlier successor overlays.

The last two are new files.

No other existing test may change.

The following protected paths must remain byte-identical:

| Path | Bytes | SHA-256 |
|---|---:|---|
| `AGENTS.md` | 60,530 | `c12a3449e761728f2093c19bb30134c54994b045843313471a6d715b648355a6` |
| `README.md` | 44,919 | `80428110e282c8c17e23c5929a9b7110c098979fee8629dda436ac54ac5418cb` |
| `.docs/software-development-progression-boundary.md` | 27,704 | `ab5c686211065eee0d9ad603b11eb32d61f1744a92660104108ead673ae9f4b4` |
| `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 68,944 | `92f1d2b34f9cf2486102edf31de142acc07db9a116f64d64212ca497d0a554c1` |
| `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | 239,999 | `9b0751f55b238c55130b6481bbea34454c5ed8866212f5546baa6e5af1b0fa19` |

Also preserve byte-for-byte:

- all `src/`;
- all migrations and migration catalog source;
- all schemas;
- package exports;
- `StateStore`;
- `WriterSession`;
- transaction, reader, and writer source;
- all other `.docs/`;
- all other tests;
- configuration and examples.

Migration `0005` must remain absent.

## Owner name and authority classification

Create:

`.docs/rw0-c2-bootstrap-acceptance-latch-owner-contract.md`

Title it as the **RW0-C2 Bootstrap Acceptance-Latch Owner Contract**.

The document is the sole accepted-future logical owner of the bounded bootstrap
acceptance allowance.

It is not:

- current implementation;
- a permanent product-wide acceptance limit;
- a scheduler, queue, backlog, lease, program head, or general run truth;
- standing policy, global stop, ES admission, runtime authority, or Git
  authority;
- a second writer or recovery service.

The future durable decision writer remains the sole writer that may perform the
acceptance consumption inside its guarded transaction.

## 1. Non-redundant invariant

Freeze this exact invariant:

> Across all programs, attempts, and candidates participating in the governed
> bootstrap proof scope, at most one fresh productive acceptance may commit.

Explain and freeze why this is independent of:

- per-program head/version CAS;
- decision identity;
- `mutation_ref` idempotency;
- program-scoped attempt uniqueness;
- candidate identity;
- result/receipt identity;
- effect and delivery heads.

Two different valid commands for two different programs must not both consume
the same shared bootstrap allowance.

Exact replay of one command and prevention of a second fresh acceptance are
different invariants.

## 2. Scope and cardinality

Freeze:

- one logical allowance;
- one shared Coordinator bootstrap scope;
- cardinality exactly one within that scope;
- no per-program, per-head, per-attempt, per-candidate, per-run, or
  per-work-item recreation;
- no reset, reopening, deletion, renewal, or replenishment;
- no caller-selected fresh epoch.

A later expansion or retirement requires a separately accepted owner/policy
change. It must not be modeled as another row or reset under this contract.

Repair and replan do not consume the allowance. After consumption, further
productive bootstrap acceptance is unavailable until separately governed
post-bootstrap semantics exist.

## 3. Initial allowance establishment

The logical owner must include the genesis requirement rather than leaving
creation ambiguous.

Freeze:

- the `available` preimage must exist before any RW0-C2 decision command;
- it is established exactly once by a separately authorized bootstrap
  provisioning/physical contract;
- the decision writer, caller, model, reducer, replay path, and recovery path
  cannot create it lazily;
- missing genesis state is an acceptance precondition conflict, not permission
  to initialize;
- establishment carries immutable provenance sufficient to identify the
  governing bootstrap scope and owner profile;
- the physical establishment mechanism remains deferred.

Do not select migration seed bytes, administrative APIs, SQL, or a current
operator workflow.

## 4. Logical identity and authority inventory

Freeze one closed authority table covering:

- owner/profile identity;
- shared bootstrap scope identity;
- latch identity;
- logical state;
- logical revision;
- available-preimage identity and digest;
- preassigned consumed-postimage identity;
- consumed-postimage content and digest;
- establishment provenance;
- consuming `mutation_ref`;
- consuming command digest;
- acceptance decision identity and digest;
- resulting program version/head binding;
- selected attempt/candidate and immutable basis binding;
- replay projection;
- recovery classification;
- later terminal binding.

Classify every item as one of:

- current Git fact;
- current Coordinator durable fact;
- future latch-owner fact;
- future durable-decision-writer fact;
- future terminal-outcome fact;
- external evidence;
- derived projection.

There must be one authoritative latch mutation writer: the future guarded
decision transaction.

## 5. Selector contract

Freeze one closed canonical selector carried by every future decision command.

It must bind, by semantic role:

- latch owner/profile identity;
- shared bootstrap scope identity;
- latch identity;
- exact expected `available` state and revision;
- expected available-preimage digest;
- preassigned consumed-postimage identity;
- one exact reference/digest binding to the command-owned acceptance-family
  route.

The surrounding command owns:

- program identity;
- expected current head revision and digest;
- basis program version;
- selected semantic attempt and candidate;
- immutable phase/evidence/currentness basis;
- `mutation_ref`;
- command digest;
- preassigned decision/result/receipt/version/head family identities.

The selector may bind that command-owned route through one acyclic relation. It
must not duplicate the entire command or author a completed postimage.

The selector:

- is covered by the command digest;
- is covered by the recovery selector;
- grants no authority;
- requests no branch;
- cannot make acceptance true;
- contains no model recommendation authority;
- contains no commit timestamp;
- avoids command/postimage/receipt digest cycles.

Validate selector grammar for every command. Evaluate the durable
available-state precondition only when the reducer derives acceptance.

## 6. Available preimage

Freeze the complete logical available preimage, without physical names:

- exact owner/profile identity;
- shared scope identity;
- latch identity;
- state `available`;
- exact initial logical revision selected by this contract;
- immutable establishment-provenance reference/digest;
- canonical preimage digest;
- absence of consuming-family bindings;
- no expiry, reset, renewal, or reusable epoch.

Select the initial and successor revision semantics explicitly. Historical
`0 -> 1` is precedent, not authority; if retained, state why.

## 7. Consumed postimage

Freeze the complete logical consumed postimage:

- same owner/profile, scope, and latch identities;
- state `consumed`;
- exact successor logical revision;
- exact predecessor preimage identity and digest;
- preassigned consumed-postimage identity;
- consuming `mutation_ref`;
- canonical command digest;
- exact acceptance decision identity and digest;
- resulting program-version identity and committed head-postimage binding;
- selected attempt/candidate lineage;
- immutable decision-basis binding;
- one transaction timestamp;
- canonical consumed-postimage digest.

Result and receipt bind this exact postimage through the shared committed
family. Do not embed final result or receipt digests back into the postimage if
that creates a cycle.

Acceptance does not fabricate new accepted-intent or work-item revisions.
Existing references may be retained only as validated lineage evidence.

## 8. State machine and closed outcome taxonomy

Freeze a complete finite table for:

- exact available preimage + derived acceptance;
- exact same-command complete committed family;
- same `mutation_ref`, different command digest;
- fresh preassigned identity/family-route collision;
- missing state;
- duplicate state;
- malformed state;
- ambiguous state;
- wrong profile/scope/latch identity;
- wrong preimage digest;
- wrong revision;
- already consumed by the exact same command with complete family;
- already consumed with only a matching command label but incomplete family;
- consumed by a different command;
- preassigned postimage collision;
- partial decision/latch family after commit uncertainty;
- each of the four nonaccept branches;
- reset/delete/reopen/replenish attempts.

Map each case exactly to:

- fresh atomic transition;
- exact replay;
- `mutation_ref_reuse_conflict`;
- `preassigned_identity_or_family_route_collision`;
- `acceptance_latch_precondition_conflict`;
- recovery `committed_exact`;
- recovery `definitely_not_committed`;
- recovery `unresolved`;
- existing command/basis/current-head rejection owner;
- forbidden operation.

Do not invent overlapping rejection owners.

Receipt-first replay and collision checks precede fresh latch precondition
evaluation.

A consumed latch plus matching command label is not replay unless the complete
committed family is exact.

## 9. Atomicity, replay, and recovery

Freeze the acceptance transaction order:

1. closed command-local grammar/preflight;
2. writer/session admission and fencing;
3. receipt-first mutation lookup and exact replay/collision checks;
4. caller expectations, basis/currentness, and branch reduction;
5. acceptance-only exact available-preimage check;
6. construction of one decision/version/head/result/receipt/latch family;
7. atomic application of the whole family;
8. read-capability invalidation;
9. exactly one commit attempt;
10. readback-only resolution of uncertainty.

No latch write occurs after decision commit or in a second transaction.

Freeze one shared whole-family recovery classifier:

- `committed_exact`: the complete expected family, including consumed
  postimage, is present and exact;
- `definitely_not_committed`: the complete newly created family is provably
  absent, with no alias, collision, fragment, or read fault, and current latch
  state separately remains eligible for a fresh retry;
- `unresolved`: neither proposition is provable.

The pre-existing available preimage is not itself part of the newly created
family-absence proposition.

Decision-without-latch and latch-without-decision are `unresolved`.

Recovery never:

- completes fragments;
- reevaluates the reducer;
- changes the branch;
- consumes the latch again;
- creates a new timestamp;
- retries automatically after `unresolved`.

Replay verifies the original committed postimage and does not require mutable
heads to remain at their historical postcommit values.

## 10. Standalone owner versus co-freeze stop condition

The intended outcome is a standalone logical latch-owner freeze.

To make that truthful, include a closed relational interface table naming every
external command/result/receipt/recovery role the latch owner relies on.

The table must be sufficient to prove:

- which command identity the selector binds;
- which preassigned family route is collision-checked;
- which decision identity consumes the latch;
- how result and receipt bind the postimage;
- how replay returns it;
- how one classifier determines the entire family.

Do not select the complete external schemas in this tranche.

If the relational interface cannot be made complete and acyclic without
freezing the full command/result/receipt/recovery value family, stop without
writing a partial owner and return:

`RW0_C_BOOTSTRAP_ACCEPTANCE_LATCH_OWNER_CO_FREEZE_REQUIRED`

Do not paper over missing roles with prose such as “future binding.”

## 11. Terminal boundary

Freeze only the latch-facing terminal rule:

- a later terminal fact binds the immutable consumed-postimage identity/digest
  and exact committed acceptance family;
- it cannot consume, reset, update, delete, or repair the latch;
- exact acceptance with no terminal fact means acceptance committed and
  terminal recording absent;
- unresolved acceptance family forbids terminal inference;
- provably absent acceptance family has no postimage to bind;
- terminal uncertainty leaves the latch consumed.

Do not design terminal storage, writer, receipt, or recovery.

## 12. Future physical-persistence handoff

Freeze only future representation constraints:

- migration-0002 decision/version/head/receipt facts remain canonical;
- existing per-program state cannot substitute for the shared latch;
- cognitive proposal/selection rows and RW0-C1 evidence rows cannot be
  reinterpreted as latch truth;
- the physical family must prove scope cardinality, exact available-state
  observation, atomic conditional consumption, immutable postimage readback,
  alias/collision detection, and whole-family recovery;
- migration-free reuse, additive migration `0005`, and bounded hybrid remain
  future options;
- the existing transaction controller and WriterSession may remain sole
  mutation authority in principle, but current code does not support RW0-C2.

Do not select SQL, migration IDs/checksums, tables, keys, indexes, triggers,
reader symbols, writer symbols, or application-generation changes.

## 13. Security and non-authority

Freeze fail-closed behavior for:

- caller- or model-authored latch state/postimage;
- stale or foreign selector/preimage;
- duplicate or ambiguous reads;
- cross-program, cross-attempt, or cross-candidate substitution;
- replay under a different command digest;
- branch requests hidden in the selector;
- result/receipt/postimage digest cycles;
- terminal mutation;
- public/API widening;
- external evidence masquerading as latch authority.

The latch grants no standing authority, execution permission, global-stop
override, ES admission/runtime authority, publication authority, or Git
authority.

Fencing precedes receipt/collision disclosure. Reader faults cannot become
absence.

## 14. Owner document representation

The new document is the sole semantic owner.

Use:

- concise normative prose;
- closed tables for scope, authority, selector roles, preimage/postimage roles,
  state transitions, outcome taxonomy, recovery, branch effects, terminal
  boundary, and nonclaims;
- one compact duplicate-key-free canonical JSON block only for the finite
  closed tables needed by contract tests.

Do not encode SQL or full future value schemas.

Human tables and the machine block must be exact equivalent representations.

The machine block must not become a second owner and must not contain unused
decorative fields.

## 15. Cross-reference updates

### `.docs/architecture.md`

Route the bounded bootstrap latch semantics to the new owner. State that there
is still no implementation, storage, writer, migration, public export, or
runtime path.

### `.docs/autonomous-software-development-operating-model.md`

Record:

- the standalone logical bootstrap latch owner as accepted target;
- the bounded shared acceptance ceiling;
- historical physical design reopened;
- post-bootstrap expansion unresolved;
- physical family and exact safe values still blocked.

### `.docs/c2b-durable-development-state.md`

Append one successor section after current EOF.

It must:

- leave Section 19 byte-exact as historical/proof-only source;
- classify the old physical migration/table selections as superseded/reopened;
- preserve the one shared bootstrap acceptance ceiling;
- route current logical ownership to the new document;
- state that existing historical tests pin historical content, not current
  physical authority;
- preserve all current migrations and implementation nonclaims.

### `.docs/rw0-remote-worker-contact-phase-entry.md`

Update the tranche/status map so the logical bootstrap latch owner is accepted,
while physical storage, exact safe values, decision writer, terminal owner,
RW0-D/E, and runtime remain future.

Do not modify `AGENTS.md`, `README.md`,
`.docs/software-development-progression-boundary.md`, the existing RW0-C2
semantic owner, or its verifier merely to add cross-references.

## 16. Contract-test architecture

Create:

`tests/test_rw0_c2_bootstrap_acceptance_latch_owner_contract.py`

Keep it finite and document-driven. Do not recreate the large reducer verifier
or implement source behavior.

The test must independently fix and causally check:

1. sole owner path, status, and authority routing;
2. historical Section 19 classification and unchanged historical text;
3. exact global-bootstrap scope and cardinality;
4. two-program competing acceptance;
5. no per-program/attempt/candidate/run replenishment;
6. no lazy creation and exact genesis requirements;
7. selector role inventory and prohibited authority fields;
8. acyclic digest dependency order;
9. exact preimage and postimage role inventories;
10. all five branches:
    - acceptance consumes once;
    - repair, replan, terminal reject, and block create no latch mutation or
      postimage;
11. every state/precondition/reuse/collision outcome;
12. receipt-first exact replay with zero second mutation;
13. whole-family three-way recovery;
14. partial decision-without-latch and latch-without-decision;
15. fault-versus-absence and duplicate/ambiguous reads;
16. terminal binding with zero latch mutation;
17. caller/model/ES/Git/public/runtime non-authority;
18. physical representation non-selection;
19. absence of migration `0005`, source implementation, writer, reader,
    public export, production caller, and runtime activation;
20. the standalone-versus-co-freeze relational interface completeness.

Required causal hostiles include:

- second fresh acceptance from another program;
- selector changes after command digest binding;
- caller-authored state or consumed postimage;
- wrong scope, identity, revision, digest, mutation, command, decision, or
  basis binding;
- consumed-by-same-label but incomplete family;
- same mutation with different digest;
- preassigned route collision;
- replay attempting a second mutation or new timestamp;
- recovery completing a fragment;
- terminal resetting or consuming;
- added reset, renewal, deletion, or second latch;
- adding a per-program allowance;
- omitting one external family role from the relational interface;
- introducing a digest cycle;
- claiming migration/table/writer implementation.

Each hostile must fail at an exact intended boundary.

Do not add a complete source-manifest hash barrier. The implementation and
independent-audit provenance gates own the exact six-path mutation ceiling.
Use existing repository nonimplementation guards plus focused structural
absence assertions.

## 17. Validation

Run serially with:

```text
PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=.:src
-p no:cacheprovider
--basetemp=<external path>
```

At minimum run:

1. new latch-owner contract module;
2. existing RW0-C2 semantic-contract module;
3. architecture/operating-model/progression tests;
4. C2B durable-state contract tests;
5. remote-phase contract tests;
6. migration catalog and 0002/0003/0004 contract tests;
7. runtime-nonauthority and C2A nonimplementation tests;
8. full repository suite;
9. `git diff --check`;
10. new-file whitespace checks;
11. CR, trailing-whitespace, and final-newline checks;
12. exact protected-file and source/migration preservation;
13. artifact/cache scan.

Use an external local-only clone for the full suite if the live pre-existing
ignored cache would interfere. Do not move or modify that live cache.

No product or operator database may be opened.

## 18. Closeout provenance

Report inline:

- opening and closing Git coordinates;
- exact six-path status;
- mode, bytes, and SHA-256 for each changed/new path;
- proof the protected files remain exact;
- proof all source, migrations, schemas, existing tests, and other docs remain
  unchanged;
- deterministic full binary patch bytes and SHA-256;
- two independent complete receipt calculations;
- exact validation commands/results;
- failed or skipped validation;
- artifact/cache posture;
- accepted logical decisions;
- rejected alternatives;
- whether the standalone relational interface closed;
- unresolved physical/value seams;
- all required non-actions.

Do not generate an external manifest or report.

## Success token

Use only when the standalone owner and its relational interface are complete:

`RW0_C_BOOTSTRAP_ACCEPTANCE_LATCH_OWNER_CONTRACT_WRITTEN_VALIDATED_READY_FOR_INDEPENDENT_AUDIT`

## Co-freeze token

Use when a truthful logical owner requires the complete command/result/receipt/
recovery semantic family:

`RW0_C_BOOTSTRAP_ACCEPTANCE_LATCH_OWNER_CO_FREEZE_REQUIRED`

Do not leave partial candidate changes under this outcome; restore the exact
opening worktree before returning it.

## Blocking token

`RW0_C_BOOTSTRAP_ACCEPTANCE_LATCH_OWNER_CONTRACT_FREEZE_BLOCKED`

## Required non-actions

State:

```text
AGENTS_NOT_MODIFIED
README_NOT_MODIFIED
PROGRESSION_BOUNDARY_NOT_MODIFIED
EXISTING_RW0_C2_SEMANTIC_OWNER_NOT_MODIFIED
EXISTING_RW0_C2_SEMANTIC_VERIFIER_NOT_MODIFIED
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
SCHEMAS_NOT_MODIFIED
EXISTING_TESTS_NOT_MODIFIED
OPERATOR_OR_PRODUCT_DATABASE_NOT_OPENED_OR_MUTATED
LIVE_IGNORED_CACHE_NOT_MOVED_OR_MODIFIED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
ACCEPTANCE_LATCH_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
REMOTE_CONTACT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
SUBAGENTS_NOT_SPAWNED
EXTERNAL_ARTIFACTS_NOT_GENERATED
```
