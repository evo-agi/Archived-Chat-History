# Governed Execution Coordinator — RW0-C2 Bootstrap Guard Governing Reset V3 Actual-Call Independent Re-audit

## Objective

Perform a fresh, parent-led, local, read-only independent re-audit of the
uncommitted RW0-C2 bootstrap acceptance-guard governing-reset V3 candidate.

This audit follows a one-file verifier repair intended to close three prior
findings:

1. actual model-consistency entry could occur before guard eligibility and be
   discarded without detection;
2. actual persisted-family replay entry could occur before writer/session
   fencing and be discarded without detection;
3. a nominal cross-program scenario could collapse to one program without
   detection.

Use the highest available Codex reasoning setting. At the beginning of the
report, record exactly what the interface visibly shows for:

- model name;
- reasoning setting or effort.

Do not infer hidden configuration. Record `not visible` when necessary.

The checked-out repository is the sole audit target and source of current
contract truth. Do not request or use chat exports, prior report attachments,
Downloads artifacts, Project artifacts, or generated manifests.

The implementation closeout is evidence only. Reproduce every material claim
from the live repository.

Do not repair the candidate.

Return one substantive inline audit report. Do not create or attach a report,
manifest, package, patch, freeze artifact, or other client-visible file.

## Exact committed baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed baseline beneath the candidate:

- branch: `trunk_dev`
- HEAD: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- HEAD tree: `42cc0757b3d9604dfe7fdbda158074b8b48dac7b`
- sole parent: `db16de711986ae40a2bb848ed00cdddd3145ee02`
- subject: `docs: freeze RW0-C durable decision branch contract`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- zero staged paths
- zero unmerged paths
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Do not fetch or contact remotes.

Any baseline, path-set, classification, file-type, mode, size, or per-file
SHA-256 mismatch requires:

`AUDIT_PROVENANCE_MISMATCH`

Stop before correctness inspection.

## Exact V3 28-path candidate

Require exactly 26 tracked modifications and two untracked files, with no other
tracked or untracked difference from HEAD.

All 28 paths must be regular, non-symlink mode-`0644` files, valid UTF-8, with
no BOM, no CR bytes, no trailing whitespace, and exactly one final newline.

| # | Status | Path | Bytes | SHA-256 |
|---:|---|---|---:|---|
| 1 | `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 70,858 | `4fc2b7f9d5810105c28a7ce11abe85d08a48f915a87b088ae86e5520aa2142e2` |
| 2 | `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | 57,192 | `2c0c9565f7fb4ae79eca998080f3b70734f9a4fd1e555132daf9b94daab1dc97` |
| 3 | `M` | `.docs/c2a-first-slice-semantic-protocol-contract.md` | 103,413 | `a690441d046d147cf11a068e07a894858e3d32476e19fef84a9bb26e6e6f0d99` |
| 4 | `M` | `.docs/c2b-durable-development-state.md` | 1,889,329 | `6115a29d5bbfb8ffb17404e9acbefcb8edc958554683afa3538e9d959e184ef8` |
| 5 | `M` | `AGENTS.md` | 61,466 | `001595cdec75b176abbfb99b91b2b06c45f2f2ff1a28c704ded7054c27c7e74e` |
| 6 | `M` | `README.md` | 45,849 | `b66fb689d9f0849eee1d62f12dda93d83dcc9f4cce2fa008696878b44256ad1a` |
| 7 | `M` | `.docs/architecture.md` | 43,007 | `60a884471d655ee6eddad8c405aa218eab492e3c610b101c0736fc9f2546288f` |
| 8 | `M` | `.docs/autonomous-software-development-operating-model.md` | 37,829 | `115ed6c16141f821147f640131bed904526cee914dbec6951f3667b0da100f05` |
| 9 | `M` | `.docs/authority-boundaries.md` | 34,686 | `69d524c839a2195cf0b5840be424c021305825fd0db1d85c76ed28b99c1bf055` |
| 10 | `M` | `.docs/durable-state-model.md` | 40,564 | `e14a421698f0735fa098fe6ce1063b64d07e1c212fd6b60755e1068c9caf5955` |
| 11 | `M` | `.docs/worker-execution-boundary.md` | 30,920 | `6f7d2f7855fcbdecc757af4dde7a7bb091ab1e8c60057a2fefe407f74de4055f` |
| 12 | `M` | `.docs/software-development-progression-boundary.md` | 28,654 | `b8761655ee42512c0e77ab8c774c2b2d3d8f9ac36a9bd0c74872ad4bf2994419` |
| 13 | `M` | `.docs/c2b3-program-initialization.md` | 27,687 | `8e9c2c6f49551b28d95de28f6d7b071c89dd0ea155ce7d7a6e21e8d88e73d1f7` |
| 14 | `M` | `.docs/rw0-b2-wire-protocol.md` | 24,346 | `7f977a5a60fd66c69464190731e09611ca24854313e145b73cc73f564776477b` |
| 15 | `M` | `.docs/rw0-b2-capability.md` | 17,753 | `171341fc60cbe762403f1e64676ca35c9ea2f778a10d0fc66d668f1c84dc884c` |
| 16 | `M` | `.docs/rw0-b1-pure-phase-values.md` | 33,032 | `8bccdaa31fa66821b73c136936c12ef001157209c72b9991839905c1a8e0e053` |
| 17 | `M` | `tests/test_architecture_contracts.py` | 100,410 | `555ac490738d12075d3908ec2ddfd090fdbb32d8a6fd53d1b3136d24485e1169` |
| 18 | `M` | `tests/test_rw0_remote_contact_phase_entry_contract.py` | 173,524 | `42d6d265c0a9ba5047aa37ec3a4daae30847d486d39ead6374685b451a1d445c` |
| 19 | `M` | `tests/test_remote_worker_pre_execution_planning_contract.py` | 913,152 | `92b0f3917f0572492357447211a1f0f0cc7f8edb7e8b5f18233ed80397879b29` |
| 20 | `M` | `tests/test_software_development_progression_boundary.py` | 42,899 | `bd9b10f62e3bbfb3dc5fc845958fe0087363a0afa0b80649853faac85235c7a3` |
| 21 | `M` | `tests/test_autonomous_software_development_operating_model.py` | 72,904 | `e9a77edb1f99b181c612e52c4a7cfee814ac3f0df4d974e7c3a0756aec6da8df` |
| 22 | `M` | `tests/c2a_contract_support.py` | 154,372 | `58be92ddffae6f4b901ae3632521481ab8d9ce0e02a819ef9421408d08eedd85` |
| 23 | `M` | `tests/test_rw0_b1_boundaries.py` | 38,321 | `bd52384897f8f7a7129023c693ef67b1ff453a006723438dfa4f06df08e4121f` |
| 24 | `M` | `tests/test_rw0_b2_capability_boundaries.py` | 45,708 | `4e4824b5974778cbef147e7f5a5684de34e5006464156cbb7be2958c33ce1a84` |
| 25 | `M` | `tests/test_c2b0_durable_state_contract.py` | 884,862 | `45a539a810deb8884c3f0158887a0d4fd06778a59e833c6b9d89365990ed62fd` |
| 26 | `M` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | 249,444 | `480bd282646304c70116f69faecabc1fea94d83ef54ec77b780a869ace5431c4` |
| 27 | `??` | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 25,151 | `bf65ba7f04411bb6e6febec2285b33721eb2ff895e2c60aee97878b1fa7c9b46` |
| 28 | `??` | `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | 89,437 | `e6555cc5155bfbaa1031de43dcfc6b3534f60457d5a34b72b245d6f769a8d795` |

Require:

- zero staged paths;
- zero unmerged paths;
- zero deletions, renames, type changes, symlinks, executable-mode changes, or
  additional untracked paths;
- every tracked path outside this set byte-identical to HEAD.

## Complete patch corroboration

Construct the complete candidate patch in the exact 28-path table order.

For each tracked path:

```text
git diff --binary --full-index --no-ext-diff --no-textconv HEAD -- <path>
```

For each new path:

```text
git diff --no-index --binary --full-index --no-ext-diff --no-textconv -- /dev/null <path>
```

Treat expected `git diff --no-index` status `1` as “differences found.”

Concatenate exact stdout bytes without separators.

Expected V3 coordinate:

- bytes: `308,892`
- SHA-256:
  `1d875ae83857db8fc4dd4c142800ced5682ff03c384c3e95430c5e33b48ea682`

Run the assembly twice.

The exact path set and per-file receipts are primary provenance. An unresolved
patch difference is `AUDIT_PROVENANCE_MISMATCH`.

## Canonical receipt corroboration

Reconstruct this exact canonical receipt.

Root:

```text
{"baseline": object, "files": array}
```

`baseline` has exactly these nine string fields:

- `branch`
- `head`
- `tree`
- `parent`
- `subject`
- `upstream`
- `divergence`
- `staged`
- `unmerged`

Values:

- `branch`: `trunk_dev`
- `head`: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- `tree`: `42cc0757b3d9604dfe7fdbda158074b8b48dac7b`
- `parent`: `db16de711986ae40a2bb848ed00cdddd3145ee02`
- `subject`: `docs: freeze RW0-C durable decision branch contract`
- `upstream`: `origin/trunk_dev`
- `divergence`: literal string `0\t0`, containing one tab
- `staged`: empty string
- `unmerged`: empty string

`files` contains exactly 28 objects in table order. Each object has exactly:

- `status`
- `path`
- `type`
- `mode`
- `bytes`
- `sha256`

Rules:

- object keys lexicographically sorted;
- arrays retain order;
- status is `M` or `??`;
- type is `regular`;
- mode is `0644`;
- bytes is a decimal integer;
- SHA-256 is lowercase hexadecimal;
- compact JSON with `,` and `:` separators;
- UTF-8, `ensure_ascii=false`, one final LF;
- slash characters unescaped.

Expected V3 receipt:

- bytes: `5,593`
- SHA-256:
  `a59f7c53ae4cbbdf33d7c5b69bd7ece58f2ada796c0195536bec23a0b687f8ae`

Run two independent implementations and require byte-identical output.

## Exact V2-to-V3 transition

Only this path may have changed from the independently audited V2 candidate:

`tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py`

Reported transition:

- V2: `63,314` bytes /
  `0b5f13f41707413f051ef9a450b62242734e7978d30ebf99b1deb6f7f5f232cf`
- V3: `89,437` bytes /
  `e6555cc5155bfbaa1031de43dcfc6b3534f60457d5a34b72b245d6f769a8d795`

The other 27 candidate paths must match the fixed V3 receipts above and their
V2 receipts.

Historical V2 bytes are corroborating transition evidence. The live V3
candidate is the audit target.

## Historical-byte coordinates

### C2B durable-state document

Require the complete committed HEAD content to remain an exact prefix:

- committed prefix bytes: `1,887,232`
- committed prefix SHA-256:
  `77bf3d3c6ed710da669db7fa4353f46f3d1e9b4e09636918046d16d94ed962e5`

Require the unchanged appended successor:

- bytes: `2,097`
- SHA-256:
  `f34b64471dca1276470bf92195f9b318193701f1af03baf1f911091a8ba80c5c`

### C2B3 program initialization

Require exact reconstruction:

- committed bytes: `26,747`
- committed SHA-256:
  `3d93195ab570e96f8f535feb38f83ebcd6b6ba112ca1db2a47d04b19258ef567`
- candidate insertion: `940` bytes;
- insertion range: `[26691,27631)`;
- insertion immediately before
  `COORDINATOR_C2B3D_COMMITTED_CURRENT_STATUS_END`.

Removing only that insertion must reconstruct committed HEAD exactly.

## Audit posture

This is an independent audit, not implementation validation.

Permitted:

- read-only Git inspection;
- static inspection of docs, source, schemas, migrations, tests, examples, and
  configuration;
- read-only lexical, AST, and bytecode/code-object inspection with
  `PYTHONDONTWRITEBYTECODE=1`;
- pytest and hostile mutants only in private external local clones;
- disposable audit-local harnesses outside the live repository;
- at most three bounded read-only explorer subagents with self-contained
  prompts.

Prohibited:

- editing, formatting, cleaning, or repairing live files;
- staging, committing, pushing, PR operations, or merging;
- remote or sibling-repository contact;
- moving, deleting, rewriting, or importing through the live ignored cache;
- opening or mutating an operator or product-state database;
- running migrations or services;
- installing dependencies;
- generating client-visible artifacts.

Remove all audit-created temporary data at closeout.

## Source-of-truth posture

Apply the repository authority hierarchy:

- Git owns commit/tree/blob/ref facts.
- `AGENTS.md` owns repository guidance and routing.
- `.docs/` owns current and accepted-target semantics within declared scopes.
- the operating model owns composition/current-status classification.
- source and migrations own current implemented behavior and representation.
- tests are evidence and drift guards, not semantic owners.
- reports are evidence only.

The selected target architecture remains:

- one standing-policy-admitted Coordinator authority lineage per bootstrap scope;
- operational realizations do not mint lineages or allowances;
- one active Coordinator authority per lineage;
- immutable admission fact;
- zero or one immutable bootstrap-acceptance fact;
- one productive direct-local acceptance per admitted lineage scope;
- permanent non-replenishment;
- acceptance fact in the durable decision family;
- no mutable latch subsystem;
- exact receipt-first replay;
- one whole-family recovery classifier;
- no fact on nonaccept branches;
- terminal nonmutation;
- later ES operation separately governed and non-replenishing;
- B1 legacy field names as compatibility/nonproof only;
- no guard implementation, storage, provisioner, reader, writer, public API, or
  runtime activation.

Do not reopen that architecture unless V3 introduced a direct contradiction.

## Recommended explorer structure

At most three read-only explorers may be used.

### Explorer 1 — independent actual-entry observation

Audit:

- model and replay target function identity;
- all live aliases/defaults/closures/registries used by composition;
- candidate actual-call probe and restoration;
- independent code-object-level call observation;
- direct, alias, wrapper, default, closure, and discarded-result mutants.

### Explorer 2 — scenario integrity and semantic regression

Audit:

- actual two-program scenario coordinates;
- fixed expected relationships versus builder values;
- shared lineage/scope and distinct program/basis/command/mutation lineage;
- cross-program behavioral ceiling;
- all accepted architecture, branch, replay, recovery, terminal, ES, and B1
  compatibility semantics.

### Explorer 3 — provenance, test independence, and protected surfaces

Audit:

- exact one-file transition;
- test-oracle versus shadow-owner boundary;
- all 76 mutants and parser positive;
- selector reproducibility;
- source/migration/public/runtime preservation;
- full validation and artifact hygiene.

The parent must independently inspect the central evidence and reconcile all
findings.

## Required inspection

Read all 28 candidate paths and every unchanged owner/test edge needed to verify:

- C2 and guard owner authority;
- C2 pre-model/model split;
- replay and collision ownership;
- B1 compatibility source/schema behavior;
- migration inventory 0001–0004;
- package exports;
- StateStore and WriterSession;
- transaction/read/write surfaces;
- C2A nonimplementation;
- B1 phase-value/relation/vector/schema/budget tests;
- B2 Wire and cancellation-control tests;
- C2B3 program-initialization tests;
- runtime-nonauthority and public-surface guards.

Follow additional exact owner/test edges discovered.

## Audit question 1 — one-file V3 repair boundary

Verify:

- exactly one candidate file changed from V2 to V3;
- all other 27 candidate paths remain byte-identical;
- all source, schemas, migrations, exports, StateStore, WriterSession, readers,
  writers, transactions, public surfaces, runtime surfaces, configuration, and
  examples remain byte-identical to HEAD;
- no normative contract or selected architecture changed;
- V3 contains test-observation and scenario-integrity work only.

Any hidden semantic redesign or source widening is blocking.

## Audit question 2 — identify the actual callable graph

Independently identify the exact runtime callable graph for:

- C2 `_model_consistency_phase`;
- guard `_receipt_replay_check`;
- C2 `_replay_family`;
- C2 pre-model reduction;
- acceptance guard eligibility;
- the composed guard evaluator.

Inventory every live reference used by the candidate:

- defining-module canonical attributes;
- imported aliases;
- module-global aliases;
- dictionary/list/tuple registries;
- function defaults and keyword defaults;
- closure cells;
- one-level wrappers;
- `functools.partial` or bound-callable containers if present;
- dynamically resolved `getattr` paths if present.

Distinguish:

- actual live call paths;
- structural defenses against future hidden aliases;
- irrelevant equal-code or same-name functions.

Block if a live target call path is outside both the candidate probe and the
independent audit observer.

## Audit question 3 — independent code-object-level observation

Do not rely only on the candidate's `_actual_call_probe`.

Build a disposable audit-local observer outside the repository using
`sys.setprofile`, `sys.settrace`, or an equivalently independent code-object
entry mechanism.

Bind observations to exact target `__code__` objects rather than module aliases.
The observer must count actual function entry regardless of whether the call
travels through:

- a defining-module global;
- imported alias;
- captured default;
- closure cell;
- registry;
- one-level wrapper;
- discarded return value;
- removed returned trace marker.

Use the observer on the live repaired candidate and on external mutant copies.

Reconcile independent counts with candidate-probe counts. A mismatch is
blocking.

## Audit question 4 — model-entry causality

Independently require actual model-entry counts:

| Case | Expected actual model entries |
|---|---:|
| exact same-command replay | 0 |
| lineage mismatch | 0 |
| missing admission | 0 |
| foreign admission | 0 |
| multiple active authorities | 0 |
| claimed scope, otherwise valid acceptance | 0 |
| unresolved scope, otherwise valid acceptance | 0 |
| eligible acceptance, recognized recommendation | 1 |
| eligible acceptance, out-of-vocabulary recommendation | 1 |
| `candidate_repair` under exact universal posture | owner-derived fixed value |
| `attempt_selecting_replan` under exact universal posture | owner-derived fixed value |
| `program_terminal_reject` under exact universal posture | owner-derived fixed value |
| `post_execution_program_block` under exact universal posture | owner-derived fixed value |

Independently derive the four nonaccept expectations from the normative C2
owner, not from observed candidate behavior.

Require the candidate's fixed expectations to match that derivation.

Verify:

- zero-call cases hard-fail on actual entry;
- positive cases call exactly once;
- model entry occurs after every applicable guard gate;
- returned traces and actual-entry observations agree, but returned traces are
  not treated as proof of non-entry;
- patch restoration occurs even when the wrapped function raises.

## Audit question 5 — replay/fencing causality

Independently require:

| Case | Receipt checks | Persisted replay calls | Fresh pre-model | Guard | Model |
|---|---:|---:|---:|---:|---:|
| unfenced caller | 0 | 0 | 0 | 0 | 0 |
| invalid writer/session admission | 0 | 0 | 0 | 0 | 0 |
| lineage mismatch before protected disclosure | 0 | 0 | 0 | 0 | 0 |
| missing/foreign admission before protected disclosure | 0 | 0 | 0 | 0 | 0 |
| fenced fresh acceptance | 1 | 0 | 1 | 1 | 1 |
| exact replay | 1 | 1 | 0 | 0 | 0 |
| mutation-ref reuse conflict | 1 | 1 | 0 | 0 | 0 |
| family-route collision | owner-derived exact counts and stop stage |

Verify the actual eligible-acceptance order:

```text
writer_or_session_fenced
receipt_or_collision_helper_entered
authoritative_pre_model_entered
acceptance_guard_entered
model_consistency_entered
```

Omit inapplicable stages without reordering.

Inspect `_receipt_replay_check` carefully. It may expose supplied-receipt
presence and delegate to C2-owned replay, but must not become:

- a second replay owner;
- a second collision taxonomy;
- a second recovery classifier;
- a hidden branch reducer.

Block if the adapter contains independent replay semantics rather than
observation/delegation.

## Audit question 6 — probe integrity and restoration

Inspect candidate probe implementation and its AST/integrity tests.

Require:

- defining-module canonical attributes are patched;
- every relevant alias/reference used by the composition is patched or observed
  independently;
- entry is recorded before delegation;
- zero-call wrapper raises before any hidden effect;
- positive wrapper delegates exactly once;
- exceptions do not prevent restoration;
- every patched identity is restored exactly;
- nested probes do not leak;
- probe state is isolated across parameterized tests;
- call count and order are asserted after invocation;
- no test passes solely from returned trace inspection;
- no self-authored boolean substitutes for fixed comparison;
- no line-number freeze masquerades as semantic protection.

Create an independent restoration-failure mutant and require the suite to detect
it or demonstrate that the test framework guarantees cleanup with a separate
post-case identity assertion.

## Audit question 7 — adversarial model-entry mutants

Independently reproduce at least:

1. direct defining-module model call, result discarded;
2. imported-alias model call, result discarded;
3. one-level wrapper call, result discarded;
4. captured default call;
5. closure-cell call;
6. registry-held call;
7. `getattr`-resolved canonical module call;
8. forged guard-passed stamp;
9. actual call with returned trace marker removed;
10. early call followed by normal later call.

Each must retain the complete ordered test collection and fail at an exact
actual-entry count/order boundary.

If the candidate intentionally forbids a reference shape structurally instead
of dynamically observing it, reproduce the structural failure and document why
that shape cannot be live.

## Audit question 8 — adversarial replay-entry mutants

Independently reproduce at least:

1. defining-module replay before fencing;
2. imported-alias replay before fencing;
3. one-level wrapper replay before fencing;
4. captured default replay before fencing;
5. closure/registry replay before fencing;
6. duplicate replay with first result discarded;
7. exact replay also running model consistency;
8. exact replay also running fresh guard eligibility;
9. mutation conflict continuing into fresh branch reduction;
10. replay result discarded and normal fenced path resumed.

Each must fail at an exact actual-entry count/order boundary with unchanged
collection.

## Audit question 9 — cross-program scenario integrity

Independently inspect the scenario builder and fixed expectations.

Require two commands with:

- same admitted lineage;
- same bootstrap scope;
- same admission fact;
- exact nonempty and unequal program refs;
- each head and basis bound to its own program;
- distinct semantic attempt and candidate lineage where declared;
- distinct mutation refs;
- distinct command digests;
- first acceptance creating the one fact;
- second fresh acceptance rejected because the shared scope is claimed.

Require relationship expectations to be authored independently from the builder.

Block if labels such as `program_B` or `unrelated_program_B` substitute for
actual coordinate comparison.

Independently reproduce:

1. program B ref collapsed to A;
2. B head/basis collapsed to A;
3. B attempt/candidate collapsed to A;
4. mutation ref reused;
5. command digest reused;
6. B assigned a different scope;
7. B assigned a different lineage/admission;
8. same-program second attempt substituted;
9. scenario builder and expected relation mutated together.

Each must fail at a precise scenario-integrity or shared-scope boundary. Mutating
builder and expected relation together must be caught by a third independent
owner-derived invariant.

## Audit question 10 — all prior architecture and V2 repairs

Verify no regression in:

- Option A lineage policy;
- explicit standing-policy admission;
- one active authority;
- continuity fail-closed;
- local absence not proving eligibility;
- immutable admission and acceptance facts;
- cross-program one-shot ceiling;
- five branch effects;
- guard conflict no-write, never block;
- receipt-first replay;
- one complete-family recovery classifier;
- partial families unresolved;
- competing winner prohibits retry;
- terminal nonmutation;
- later ES non-replenishment;
- C2 versus guard owner non-overlap;
- B1 compatibility/nonproof;
- four-document normalized body;
- C2A/B2/progression/AGENTS/README routing;
- historical C2B/C2B3 preservation;
- P08/P11/P12/P13 substantive semantic supersession;
- type-exact human/machine equality;
- closed Markdown table parsing;
- complete operational-realization inventory;
- capability structured-evidence integrity;
- C2B current-status clarification.

## Audit question 11 — all negative mutants and positive parser probe

Independently reproduce the implementation's full negative inventory:

- 44 original V2 negatives;
- 14 additional V2 audit probes;
- 18 V3-specific negatives.

Total required negatives: `76`.

Every negative must:

- retain the complete ordered `7,778`-node collection;
- fail at the intended exact semantic boundary;
- avoid syntax/import/format/collection/parameter-count-only failure.

Also reproduce the legitimate human-table backtick-removal positive and require:

- unchanged collection;
- passing semantics.

Report every mutant ID, intended boundary, actual failed node/boundary, and
whether independent code-object observation confirmed the hidden call where
applicable.

## Audit question 12 — selector reproducibility

For the exact four-module set:

- `tests/test_rw0_b2_capability_boundaries.py`
- `tests/test_c2b0_durable_state_contract.py`
- `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`
- `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py`

run `--collect-only -q` before each selector execution.

Expected:

| Selector | Selected / passed |
|---|---:|
| `actual_model_entry` | `14 / 14` |
| `actual_replay_entry` | `9 / 9` |
| `fencing_before_replay_actual` | `9 / 9` |
| `model_after_guard_actual` | `13 / 13` |
| `cross_program_scenario_integrity` | `6 / 6` |
| `cross_program_ceiling` | `1 / 1` |
| `hostile` | `658 / 658` |
| `capability_semantic_integrity` | `9 / 9` |
| `guard_ordering_integrity` | `4 / 4` |
| `typed_human_machine_equivalence` | `23 / 23` |
| `closed_human_table` | `11 / 11` |
| `model_after_guard` | `26 / 26` |
| `operational_realization` | `18 / 18` |
| `c2b_current_status_authority` | `3 / 3` |

No selector may select zero or unrelated tests.

## Audit question 13 — exact collection and validation

Create a private external local clone from exact committed HEAD without remote
contact. Overlay exactly the 28 verified candidate files.

Do not import from or alter the live ignored cache.

Run serially with:

```text
PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=.:src
python3 -m pytest -q -p no:cacheprovider --basetemp=<external>
```

### Exact module collections

Expected:

| Module/run | Collection |
|---|---:|
| C2 verifier | `1,334` |
| Guard verifier | `250` |
| C2 + guard | `1,584` |
| Four focused modules | `1,958` |
| Exact 17 modules | `3,567` |
| Exact broader command | `3,611` |
| Full repository | `7,778` |

### C2 + guard

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_rw0_c2_durable_progression_decision_semantic_contract.py \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

Expected:

`1,584 passed`

### Four focused modules

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_rw0_b2_capability_boundaries.py \
  tests/test_c2b0_durable_state_contract.py \
  tests/test_rw0_c2_durable_progression_decision_semantic_contract.py \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

Expected:

`1,958 passed`

### Exact 17 modules

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_architecture_contracts.py \
  tests/test_rw0_remote_contact_phase_entry_contract.py \
  tests/test_remote_worker_pre_execution_planning_contract.py \
  tests/test_software_development_progression_boundary.py \
  tests/test_autonomous_software_development_operating_model.py \
  tests/test_c2a_first_slice_semantic_protocol_contract.py \
  tests/test_c2a_nonimplementation.py \
  tests/test_rw0_b1_phase_values.py \
  tests/test_rw0_b1_vectors.py \
  tests/test_rw0_b1_relations.py \
  tests/test_rw0_b1_boundaries.py \
  tests/test_rw0_b2_wire_boundaries.py \
  tests/test_rw0_b2_capability_boundaries.py \
  tests/test_rw0_b2_wire_cancellation_control_boundaries.py \
  tests/test_c2b0_durable_state_contract.py \
  tests/test_rw0_c2_durable_progression_decision_semantic_contract.py \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

Expected:

`3,567 passed`

### Exact broader command

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_c2a*.py \
  tests/test_worker_execution_semantic*.py \
  tests/test_rw0_b1*.py \
  tests/test_rw0_b2*.py \
  tests/test_rw0_c1*.py \
  tests/test_post_execution_pure_owner*.py \
  tests/test_c2b2*.py \
  tests/test_c2b3*.py \
  tests/test_section41*.py \
  tests/test_runtime_non_authority.py \
  tests/test_state_store_contract.py \
  tests/test_b2a_writer_session_contract.py \
  tests/test_sqlite*.py
```

Expected:

`3,611 passed, 3 warnings`

### Full repository

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external>
```

Expected:

`7,778 passed, 3 warnings`

The only expected warnings are the unchanged Python 3.13 multi-threaded
`fork()` deprecations from:

- `test_operation_guard_close_waits_and_retains_authority_until_exit`;
- `test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang`;
- `test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock`.

Investigate every count or warning mismatch.

Also require:

- `git diff --check`;
- both new-file `/dev/null` whitespace checks;
- UTF-8/BOM/CR/trailing-whitespace/final-newline checks;
- source/migration/public-surface preservation;
- C2B/C2B3 historical reconstruction;
- artifact scans.

## Audit question 14 — nonimplementation and protected surfaces

Independently verify:

- all 212 tracked paths outside the candidate equal HEAD;
- all 66 source/resource paths equal HEAD;
- migrations exactly 0001–0004;
- migration `0005` absent;
- SQL resource hashes unchanged;
- package exports unchanged;
- StateStore, WriterSession, readers, writers, transactions unchanged;
- no guard/admission/acceptance source module;
- no provisioner;
- no durable decision writer;
- no reader/recovery implementation;
- no production caller;
- no public API;
- no runtime activation;
- no RW0-D/E or Execution Substrate modification;
- no product database or runtime artifact.

## Live cache and cleanup

At opening and closeout, inventory the 37 pre-existing ignored cache members
without importing, moving, deleting, or rewriting them.

Canonical cache grammar:

- root: path-sorted JSON array;
- each object has exactly:
  - `path`
  - `type`
  - `mode`
  - `size`
  - `mtime_ns`
  - `sha256`
- object keys lexicographically sorted;
- compact JSON;
- UTF-8;
- one final LF.

Expected implementation evidence:

- bytes: `8,897`
- SHA-256:
  `3902e30eb9f5e229bb61b46d3b77a001f6b86371a717f9b3c324407d8818ebec`

Member equality is primary. If the aggregate differs solely because of an
identified metadata/envelope variation while every opening/closing member is
exact, classify it report-only rather than candidate drift.

Remove all audit-created temporary data.

## Final provenance

After cleanup, require:

- exact baseline HEAD and branch;
- exact 28-path status and receipts;
- zero staged/unmerged paths;
- no additional path;
- exact complete patch;
- exact canonical receipt;
- unchanged source/migration/public surfaces;
- exact C2B and C2B3 historical reconstruction;
- exact ignored-cache opening/closing member equality;
- no audit-created repository or deliverable artifact.

Run patch and receipt calculations twice and require byte-identical outputs.

## Severity and verdict rules

Blocking findings include:

- provenance mismatch;
- candidate probe missing a live function reference;
- independent code-object observer detecting a call that candidate tests miss;
- hidden model entry before guard eligibility;
- hidden replay entry before fencing;
- duplicate or discarded replay/model entry surviving;
- probe restoration failure;
- `_receipt_replay_check` becoming an independent replay/collision owner;
- cross-program scenario not actually using distinct programs;
- builder and expected relation self-confirming together;
- any surviving required mutant;
- regression in Option A lineage or immutable-fact architecture;
- overlapping C2/guard replay or recovery authority;
- acceptance fact on a nonaccept branch;
- guard conflict converted to durable block;
- partial family classified committed;
- competing winner permitting retry;
- B1 legacy pair treated as durable proof;
- verifier becoming a shadow semantic owner;
- source/migration/public/runtime widening;
- unexplained collection, test-count, or warning mismatch.

### Accept

Use only when no unresolved High- or Medium-severity finding remains:

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_ACCEPTED_READY_FOR_COMMIT_GATE`

Acceptance authorizes only a separate commit/publication gate for the exact
28 audited paths.

It does not authorize:

- source or safe-value changes;
- migration `0005`;
- scope provisioning;
- durable decision writing;
- guard persistence;
- readers or recovery implementation;
- terminal persistence;
- public API widening;
- runtime activation;
- RW0-D/E;
- Execution Substrate work.

### Block

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_AUDIT_BLOCKED`

### Provenance mismatch

`AUDIT_PROVENANCE_MISMATCH`

## Inline report structure

Return:

1. primary verdict;
2. visible model/reasoning setting;
3. exact baseline and V3 candidate provenance;
4. patch, receipt, one-file transition, and historical-byte reconciliation;
5. inspection scope and limits;
6. one-file repair-boundary audit;
7. actual callable-graph inventory;
8. independent code-object observation method/results;
9. model-entry causality audit;
10. replay/fencing causality audit;
11. probe integrity/restoration audit;
12. cross-program scenario-integrity audit;
13. preserved architecture and owner-split audit;
14. all 76 mutant results and positive parser probe;
15. selector reproducibility;
16. independent collection and validation;
17. nonimplementation/protected-surface audit;
18. live-cache and final provenance;
19. severity-ranked findings;
20. exact next boundary;
21. required non-actions;
22. final token.

## Required non-actions

State:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIRS_NOT_PERFORMED
NORMATIVE_DOCUMENTS_NOT_MODIFIED
C2_VERIFIER_NOT_MODIFIED
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
SCHEMAS_NOT_MODIFIED
OTHER_27_CANDIDATE_PATHS_NOT_MODIFIED
NON_CEILING_DOCS_NOT_MODIFIED
NON_CEILING_TESTS_NOT_MODIFIED
OPERATOR_OR_PRODUCT_DATABASE_NOT_OPENED_OR_MUTATED
LIVE_IGNORED_CACHE_NOT_MOVED_OR_MODIFIED
DEPENDENCIES_NOT_INSTALLED
SERVICES_NOT_STARTED
REMOTE_CONTACT_NOT_PERFORMED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
MERGE_NOT_PERFORMED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
BOOTSTRAP_SCOPE_PROVISIONER_NOT_IMPLEMENTED
BOOTSTRAP_ACCEPTANCE_GUARD_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUBAGENTS_READ_ONLY_IF_USED
EXTERNAL_ARTIFACTS_NOT_GENERATED
```
