# Governed Execution Coordinator — RW0-C2 Bootstrap Guard Governing-Reset Impact Reconciliation

## Role

Perform one fresh, parent-led, repository-first, read-only reconciliation of the
current Coordinator contracts that still encode the superseded mutable
acceptance-latch architecture.

Use the highest available Codex reasoning setting. At the start of the report,
record exactly what the interface visibly shows for:

- model name;
- reasoning setting or effort.

Do not infer hidden configuration. Use `not visible` when necessary.

The previous workspace-write engagement correctly stopped before editing because
its eight-path mutation ceiling protected governing documents and tests that
still require one-way latch consumption and terminal binding to a committed
latch postimage.

This reconnaissance must determine the complete truthful successor boundary
before another write prompt is issued.

Do not edit the repository. Do not issue an implementation prompt.

## Repository and exact baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required baseline:

- branch: `trunk_dev`
- HEAD: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- tree: `42cc0757b3d9604dfe7fdbda158074b8b48dac7b`
- sole parent: `db16de711986ae40a2bb848ed00cdddd3145ee02`
- subject: `docs: freeze RW0-C durable decision branch contract`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- clean tracked, untracked, staged, and unmerged state
- no active Git operation or index lock

Do not fetch or contact remotes.

Stop on any mismatch:

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_RECONNAISSANCE_BLOCKED`

## Accepted product and target architecture

Treat this as the accepted strategic target:

- one explicitly standing-policy-admitted Coordinator authority lineage;
- deployments, machines, processes, databases, database files, repositories,
  programs, attempts, candidates, commands, parent grants, restores, rollbacks,
  clones, passive backups, and relocations do not create a lineage or allowance;
- genuinely independent lineages require separate standing-policy admission;
- one active Coordinator authority per lineage; active-active copies are
  unsupported and ambiguity fails closed;
- one immutable bootstrap-scope admission fact;
- at most one immutable bootstrap-acceptance fact for that scope;
- the acceptance fact commits atomically in the durable decision family;
- no mutable `available -> consumed` latch subsystem;
- no lazy scope creation by the decision writer;
- exact replay and one whole-family three-way recovery classifier;
- no acceptance fact on nonaccept branches;
- terminal outcome remains later and non-mutating;
- later ES-routed operation is separately governed and never replenishes this
  direct-local proof allowance.

The historical standalone-latch freeze prompt was never executed and is
superseded.

## Current blocker to reconcile

The current repository contains a four-document live cross-reference body in:

1. `.docs/autonomous-software-development-operating-model.md`
2. `.docs/worker-execution-boundary.md`
3. `.docs/authority-boundaries.md`
4. `.docs/durable-state-model.md`

The body currently requires:

- the accepted direct-local decision to consume a one-way latch; and
- terminal `accept` to bind the committed latch postimage.

Current architecture and remote-phase tests require all four bodies to be
identical and require that latch sentence literally.

The write prompt protected three of those four documents and their owning tests,
so the stop was correct.

A deeper current-implementation seam also exists:

- `RW0TerminalOutcomeV1` in
  `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`
  currently owns `latch_postimage_ref` and `latch_postimage_digest`;
- its normal accept shape requires that pair;
- `.docs/rw0-b1-pure-phase-values.md` and current B1 tests pin those fields;
- C2A and B2 governing documents still use “one-shot latch” or “acceptance
  latch” target language.

Determine whether a documentation/test-only governing reset can truthfully
retain those current source fields as a bounded compatibility edge, or whether
the private pure semantic source contract must be co-frozen and versioned.

Do not assume either answer.

## Posture

Read-only only.

Permitted:

- read-only Git inspection;
- static inspection of docs, source, schemas, migrations, tests, examples, and
  configuration;
- exact repository-wide lexical/AST occurrence inventories;
- at most three bounded read-only explorer subagents with self-contained
  prompts.

Prohibited:

- editing, formatting, creating, deleting, or moving files;
- running tests, scripts, migrations, services, or repository imports;
- opening or mutating a database;
- dependency installation;
- staging, commit, push, PR, or merge;
- remote or sibling-repository contact;
- retained artifact generation.

At closeout, verify unchanged HEAD and status.

## Required inspection

Inspect at minimum:

### Governing and composition documents

- `AGENTS.md`
- `README.md`
- `.docs/architecture.md`
- `.docs/autonomous-software-development-operating-model.md`
- `.docs/authority-boundaries.md`
- `.docs/durable-state-model.md`
- `.docs/worker-execution-boundary.md`
- `.docs/software-development-progression-boundary.md`
- `.docs/rw0-remote-worker-contact-phase-entry.md`
- `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
- `.docs/c2a-first-slice-semantic-protocol-contract.md`
- `.docs/rw0-b1-pure-phase-values.md`
- `.docs/rw0-b2-wire-protocol.md`
- `.docs/rw0-b2-capability.md`
- `.docs/c2b-durable-development-state.md`
- `.docs/c2b3-program-initialization.md`

### Current source/value contracts

- `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`
- any other production source containing latch, latch-postimage, or terminal
  acceptance semantics;
- migration catalog and migrations 0001–0004;
- public exports, `StateStore`, `WriterSession`, transaction, reader, and writer
  surfaces relevant to proving implementation absence.

### Contract and source tests

- `tests/test_architecture_contracts.py`
- `tests/test_rw0_remote_contact_phase_entry_contract.py`
- `tests/test_remote_worker_pre_execution_planning_contract.py`
- `tests/test_software_development_progression_boundary.py`
- `tests/c2a_contract_support.py`
- relevant C2A semantic-protocol tests;
- `tests/test_rw0_b1_phase_values.py`
- `tests/test_rw0_b1_vectors.py`
- `tests/test_rw0_b1_boundaries.py`
- `tests/test_rw0_b2_wire_boundaries.py`
- `tests/test_rw0_b2_capability_boundaries.py`
- `tests/test_rw0_b2_wire_cancellation_control_boundaries.py`
- `tests/test_c2b0_durable_state_contract.py`
- `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`
- current migration, runtime-nonauthority, public-surface, and
  nonimplementation tests relevant to the reset.

Follow every additional exact owner/test edge found during inspection.

## Explorer structure

Use at most three read-only explorers:

1. **Governing-contract and supersession explorer**
   - map all live current target wording;
   - separate current owner text, historical/proof material, and status overlays;
   - identify every document that must change together.

2. **Private semantic-value compatibility explorer**
   - inspect `RW0TerminalOutcomeV1`, `latch_postimage_*`, and owning B1 tests/docs;
   - determine whether compatibility reclassification is truthful or whether
     source/schema versioning is required.

3. **Contract-test and validation-surface explorer**
   - map exact phrase pins, normalized cross-reference maps, source grammar
     tests, and expected validation commands;
   - derive the smallest complete mutation ceiling.

The parent must independently inspect the central evidence, preserve
disagreements, and reconcile one recommendation.

No nested subagents. At most one bounded retry for a failed explorer.

## Required questions

### 1. Four-document cross-reference ownership

Determine the exact authority status of the identical four-document RW0
cross-reference body.

Decide whether the mutable-latch sentence is:

- current binding target contract;
- a compatibility statement;
- a superseded target seam;
- or historical evidence.

Identify exactly which documents and tests must change atomically.

### 2. Other current governing latch clauses

Classify every live latch/guard occurrence outside historical Section 19 and
other explicitly superseded planning text.

At minimum adjudicate:

- C2A “durable one-shot latch” expansion requirement;
- RW0-B1 terminal outcome and latch-pair contract;
- RW0-B2 Wire and Capability ownership statements;
- architecture/AOM/C2B/remote-phase current-status language;
- authority-boundary fact-owner language;
- terminal outcome binding language;
- any current “latch schema remains future” statements.

For each occurrence classify:

- amend in guard reset;
- retain as historical/proof precursor;
- retain as bounded compatibility edge with an exact interpretation;
- defer to later physical/value freeze;
- or source amendment required.

### 3. `RW0TerminalOutcomeV1` compatibility decision

Decide one:

#### A. Compatibility treatment is truthful

The existing private field names:

- `latch_postimage_ref`
- `latch_postimage_digest`

may remain temporarily unchanged only if all of the following can be frozen
without contradiction:

- they are legacy compatibility names;
- the pair binds the immutable bootstrap-acceptance fact identity/digest;
- it does not imply a mutable preimage, state transition, revision, or separate
  classifier;
- target contracts route authority to the new guard owner;
- no new target implementation may consume these fields without a separately
  accepted safe-value compatibility/versioning decision;
- current B1 source remains private pure representation, not durable guard
  implementation.

Specify the exact docs/tests needed to prove that treatment.

#### B. Source co-freeze is required

If the current schema name/field grammar cannot truthfully carry the new meaning
without silent semantic repurposing, specify:

- exact source path(s);
- exact current schemas/classes;
- whether a new version rather than in-place mutation is required;
- exact existing tests/docs that must change;
- migration/public/runtime nonclaims;
- whether source changes remain private pure values only.

Do not design or implement the source change.

### 4. Historical C2B contract treatment

Preserve historical Sections 1–42 and their tests as historical/proof evidence
unless a current test incorrectly promotes them to current target authority.

Determine how a new append-only successor should:

- retain the shared one-shot ceiling;
- supersede mutable latch representation;
- preserve no reset/reuse;
- preserve historical tests without treating old SQL/migration/table choices as
  current authority.

### 5. Exact mutation ceiling

Return a complete, closed path list for the next write tranche.

Separate paths into:

- governing semantic owners;
- status/cross-reference projections;
- current private value-owner docs/source, if any;
- existing contract tests;
- new guard owner and verifier.

Do not provide a “likely” list. Give the smallest complete ceiling supported by
the repository.

State which previously protected paths must now be intentionally reopened.

### 6. Contract-test strategy

Define the exact responsibilities of:

- amended C2 durable-decision verifier;
- new bootstrap-guard verifier;
- four-document cross-reference tests;
- remote-phase tests;
- C2A expansion-gate tests;
- B1 terminal-value tests, if relevant;
- B2/progression boundary tests;
- historical C2B tests.

Distinguish tests that preserve historical text from tests that own current
target semantics.

No test may be changed merely to obtain a pass; governing semantics must change
first.

### 7. Sequencing

Determine whether the next write tranche can remain:

`docs + contract tests only`

or must be:

`docs + contract tests + private pure semantic-value source/versioning`

Source/migration/writer/runtime work beyond any required private pure
value-schema co-freeze remains prohibited.

### 8. Validation and audit boundary

Specify exact targeted test modules, broader groups, full-suite requirement,
provenance, hostile controls, and independent-audit perspectives.

## Report requirements

Return one inline report with:

1. primary disposition;
2. visible model and reasoning setting;
3. exact baseline and unchanged closeout;
4. inspection scope and limits;
5. blocker confirmation;
6. four-document cross-reference adjudication;
7. complete current latch/guard occurrence classification;
8. `RW0TerminalOutcomeV1` compatibility/source decision;
9. historical C2B treatment;
10. exact closed mutation ceiling;
11. exact governing semantic changes;
12. exact contract-test changes;
13. validation plan;
14. security/authority analysis;
15. rejected alternatives;
16. unresolved seams;
17. exact next permitted write decision;
18. compact continuation capsule of no more than 1,000 words;
19. required non-actions;
20. final token.

Use exact repo-relative path-and-line evidence for every substantive claim.

Separate current implemented contract, current target contract, historical/proof
material, compatibility edge, strategic target, inference, and uncertainty.

Do not issue an implementation prompt.

## Disposition tokens

### A documentation/test-only reset is truthful

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_READY_NO_SOURCE`

### Private pure semantic source/versioning must be co-frozen

`RW0_C_BOOTSTRAP_GUARD_PRIVATE_SEMANTIC_SOURCE_CO_FREEZE_REQUIRED`

### A further authority or product decision blocks the reset

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_BLOCKED`

## Required non-actions

State:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
DATABASE_NOT_OPENED_OR_MUTATED
DEPENDENCIES_NOT_INSTALLED
SERVICES_NOT_STARTED
REMOTE_CONTACT_NOT_PERFORMED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
ARTIFACTS_NOT_GENERATED
IMPLEMENTATION_PROMPT_NOT_ISSUED
SOURCE_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
BOOTSTRAP_SCOPE_PROVISIONER_NOT_IMPLEMENTED
BOOTSTRAP_ACCEPTANCE_GUARD_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
SUBAGENTS_READ_ONLY_IF_USED
```
