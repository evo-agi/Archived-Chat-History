## Disposition

**Accept the reconnaissance result. Proceed with one atomic, documentation-and-contract-test-only governing reset.**

Codex’s conclusion is well supported:

```text
RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_READY_NO_SOURCE
```

The current private B1 source does not implement a mutable latch. It carries only an opaque `latch_postimage_ref` / `latch_postimage_digest` pair, requires joint presence for normal acceptance, and does not verify a latch preimage, state transition, revision, guard scope, uniqueness, or committed-family membership. Therefore, the source can remain unchanged while those field names are explicitly frozen as a **bounded legacy representation edge**, not as proof that a latch or immutable guard currently exists. :chatgpt-content-reference{index="0"}

This compatibility treatment is valid only under the restrictions Codex identified:

- the legacy pair’s target interpretation is an immutable bootstrap-acceptance fact reference and digest;
- it implies no mutable preimage, `available`/`consumed` state, revision, or independent classifier;
- current B1 validates supplied representation coherence only;
- no future target implementation may consume the pair as durable guard evidence before a separate safe-value compatibility/versioning decision.

That is explicit semantic supersession—not silent repurposing.

## Why the 28-path reset is justified

The previous eight-path ceiling was not merely a little too narrow. The mutable-latch target is presently enforced across a normalized four-document governing body:

```text
.docs/autonomous-software-development-operating-model.md
.docs/worker-execution-boundary.md
.docs/authority-boundaries.md
.docs/durable-state-model.md
```

The body is current accepted-target policy, and its equality, placement, and exact semantics are independently enforced by architecture, remote-phase, and pre-execution contract tests. All four copies and those test owners must therefore move together. :chatgpt-content-reference{index="1"}

The reset also has to reconcile:

- the merged RW0-C2 owner and verifier;
- the remote-phase owner;
- C2A’s one-shot expansion gate;
- B1’s legacy compatibility projection;
- B2 Wire and Capability ownership statements;
- software-progression boundaries;
- AGENTS, README, architecture, and operating-model routing;
- C2B historical proofs versus current target authority.

Codex derived a closed set of **28 paths: 16 documents, 10 existing test/support files, and two new owner/verifier paths**. No production source path belongs in the ceiling. :chatgpt-content-reference{index="2"}

This should be one atomic governing reset. Splitting it would temporarily leave multiple current semantic owners in contradiction.

## Architectural result to implement

The reset must replace the accepted-target mutable latch with:

```text
one immutable standing-policy-admitted scope fact
+ zero or one immutable bootstrap-acceptance fact
+ atomic membership in the durable decision family
+ one exact replay path
+ one whole-family three-way recovery classifier
```

It must preserve:

- Option A’s Coordinator authority-lineage scope;
- one active authority per lineage;
- restore, clone, relocation, machine, and database non-replenishment;
- local row absence never proving eligibility;
- one permanent productive direct-local acceptance per admitted scope;
- no acceptance fact on repair, replan, terminal-reject, or block;
- guard conflict as no-write, never fallback block;
- terminal outcome as later and non-mutating;
- ES-routed operation as separate and non-replenishing.

The existing five-branch reducer, matrix logic, currentness, model non-authority, and no-write/block/unresolved distinctions remain controlling. :chatgpt-content-reference{index="3"}

## Implementation handoff

Resume the **same reconnaissance Codex conversation**, change it to workspace-write, keep the highest available reasoning setting selected, and use the parent as the sole writer. No subagents.

:chatgpt-content-reference{index="7"}[Download the complete 28-path governing-reset implementation prompt](sandbox:/mnt/data/Coordinator_RW0_C2_Bootstrap_Guard_Governing_Reset_Implementation_Prompt.txt)

```text
Filename:
Coordinator_RW0_C2_Bootstrap_Guard_Governing_Reset_Implementation_Prompt.txt

Size:
42,973 bytes

SHA-256:
18286e15c89036b97624adb0cc34dbf431cc30f3629b1365ec6484afc9f00c08

Logical lines:
1,259

Final newline:
present
```

The exact changed-path set is:

```text
.docs/rw0-c2-durable-progression-decision-semantic-contract.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/c2a-first-slice-semantic-protocol-contract.md
.docs/c2b-durable-development-state.md
AGENTS.md
README.md
.docs/architecture.md
.docs/autonomous-software-development-operating-model.md
.docs/authority-boundaries.md
.docs/durable-state-model.md
.docs/worker-execution-boundary.md
.docs/software-development-progression-boundary.md
.docs/c2b3-program-initialization.md
.docs/rw0-b2-wire-protocol.md
.docs/rw0-b2-capability.md
.docs/rw0-b1-pure-phase-values.md
tests/test_architecture_contracts.py
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_software_development_progression_boundary.py
tests/test_autonomous_software_development_operating_model.py
tests/c2a_contract_support.py
tests/test_rw0_b1_boundaries.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_c2b0_durable_state_contract.py
tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md
tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

The prompt requires:

- exact four-document normalized-body preservation after semantic replacement;
- append-only preservation of the complete existing C2B document;
- historical C2B latch proofs retained but demoted from current target authority;
- deliberate, semantic—not hash-only—supersession of B2 Capability protections P08/P11/P12/P13;
- unchanged B1 source, schemas, field grammar, domains, budgets, and value/vector tests;
- causal hostile tests for lineage substitution, clone/restore renewal, local-absence inference, active-copy ambiguity, cross-program second acceptance, partial-family recovery, terminal mutation, ES replenishment, and B1 compatibility overclaim;
- exact targeted, broad, and full-suite validation;
- zero source or migration diff;
- inline per-file and complete-patch provenance, calculated twice;
- no external manifest/report artifact.

Success token:

```text
RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_WRITTEN_VALIDATED_READY_FOR_INDEPENDENT_AUDIT
```

Blocking token:

```text
RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_BLOCKED
```

A successful result authorizes only a fresh, read-only independent audit of the exact 28-path candidate. It does not authorize safe-value source changes, migration `0005`, scope provisioning, durable decision writing, guard persistence, readers, terminal persistence, public exports, or runtime activation.

No new snapshot is needed before this implementation: the reconnaissance made no repository mutation, and opening/closing Git state remained exactly clean at the current merged baseline. :chatgpt-content-reference{index="4"}

**Sources:** Codex governing-reset reconnaissance, including the primary disposition, complete latch/guard inventory, B1 compatibility adjudication, exact mutation ceiling, test responsibilities, and next permitted write boundary. :chatgpt-content-reference{index="5"} :chatgpt-content-reference{index="6"}

**Confidence:** High that no production source amendment is required for this governing reset. High that the 28-path atomic ceiling is justified. Medium-high that the legacy B1 pair can remain safely unchanged; that confidence depends on the implementation and later audit enforcing its nonproof compatibility status exactly.
