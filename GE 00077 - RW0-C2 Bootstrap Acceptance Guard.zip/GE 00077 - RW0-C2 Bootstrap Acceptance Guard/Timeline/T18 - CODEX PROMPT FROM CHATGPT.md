# Governed Execution Coordinator — RW0-C2 Bootstrap Guard Governing Reset V2 Independent Re-audit

## Role

Perform a fresh, parent-led, local, read-only independent re-audit of the
uncommitted RW0-C2 bootstrap acceptance-guard governing-reset V2 candidate.

Use the highest available Codex reasoning setting. At the beginning of the
report, record exactly what the interface visibly shows for:

- model name;
- reasoning setting or effort.

Do not infer hidden configuration. Record `not visible` when necessary.

The checked-out repository is the sole audit target and source of current
contract truth.

Do not request or use chat exports, prior audit attachments, Downloads
artifacts, Project artifacts, generated manifests, or historical design
packages. The prior audit and implementation closeout are evidence only; every
material claim must be reproduced from the live repository.

Do not repair the candidate.

Return one substantive audit report inline. Do not create or attach a report,
manifest, package, freeze artifact, or other client-visible file.

## Exact committed baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed baseline beneath the candidate:

- branch: `trunk_dev`
- HEAD: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- HEAD tree: `42cc0757b3d9604dfe7fdbda158074b8b48dac7b`
- sole parent: `db16de711986ae40a2bb848ed00cdddd3145ee02`
- subject: `docs: freeze RW0-C durable decision branch contract`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- zero staged paths
- zero unmerged paths
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Do not fetch or contact remotes.

Any baseline, path-set, classification, file-type, mode, size, or per-file
SHA-256 mismatch requires:

`AUDIT_PROVENANCE_MISMATCH`

Stop before correctness inspection.

## Exact repaired 28-path candidate

Require exactly 26 tracked modifications and two untracked files, with no other
tracked or untracked difference from HEAD.

All 28 paths must be regular, non-symlink mode-`0644` files, valid UTF-8, with
no CR bytes, no trailing whitespace, and exactly one final newline.

| # | Status | Path | Bytes | SHA-256 |
|---:|---|---|---:|---|
| 1 | `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 70,858 | `4fc2b7f9d5810105c28a7ce11abe85d08a48f915a87b088ae86e5520aa2142e2` |
| 2 | `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | 57,192 | `2c0c9565f7fb4ae79eca998080f3b70734f9a4fd1e555132daf9b94daab1dc97` |
| 3 | `M` | `.docs/c2a-first-slice-semantic-protocol-contract.md` | 103,413 | `a690441d046d147cf11a068e07a894858e3d32476e19fef84a9bb26e6e6f0d99` |
| 4 | `M` | `.docs/c2b-durable-development-state.md` | 1,889,329 | `6115a29d5bbfb8ffb17404e9acbefcb8edc958554683afa3538e9d959e184ef8` |
| 5 | `M` | `AGENTS.md` | 61,466 | `001595cdec75b176abbfb99b91b2b06c45f2f2ff1a28c704ded7054c27c7e74e` |
| 6 | `M` | `README.md` | 45,849 | `b66fb689d9f0849eee1d62f12dda93d83dcc9f4cce2fa008696878b44256ad1a` |
| 7 | `M` | `.docs/architecture.md` | 43,007 | `60a884471d655ee6eddad8c405aa218eab492e3c610b101c0736fc9f2546288f` |
| 8 | `M` | `.docs/autonomous-software-development-operating-model.md` | 37,829 | `115ed6c16141f821147f640131bed904526cee914dbec6951f3667b0da100f05` |
| 9 | `M` | `.docs/authority-boundaries.md` | 34,686 | `69d524c839a2195cf0b5840be424c021305825fd0db1d85c76ed28b99c1bf055` |
| 10 | `M` | `.docs/durable-state-model.md` | 40,564 | `e14a421698f0735fa098fe6ce1063b64d07e1c212fd6b60755e1068c9caf5955` |
| 11 | `M` | `.docs/worker-execution-boundary.md` | 30,920 | `6f7d2f7855fcbdecc757af4dde7a7bb091ab1e8c60057a2fefe407f74de4055f` |
| 12 | `M` | `.docs/software-development-progression-boundary.md` | 28,654 | `b8761655ee42512c0e77ab8c774c2b2d3d8f9ac36a9bd0c74872ad4bf2994419` |
| 13 | `M` | `.docs/c2b3-program-initialization.md` | 27,687 | `8e9c2c6f49551b28d95de28f6d7b071c89dd0ea155ce7d7a6e21e8d88e73d1f7` |
| 14 | `M` | `.docs/rw0-b2-wire-protocol.md` | 24,346 | `7f977a5a60fd66c69464190731e09611ca24854313e145b73cc73f564776477b` |
| 15 | `M` | `.docs/rw0-b2-capability.md` | 17,753 | `171341fc60cbe762403f1e64676ca35c9ea2f778a10d0fc66d668f1c84dc884c` |
| 16 | `M` | `.docs/rw0-b1-pure-phase-values.md` | 33,032 | `8bccdaa31fa66821b73c136936c12ef001157209c72b9991839905c1a8e0e053` |
| 17 | `M` | `tests/test_architecture_contracts.py` | 100,410 | `555ac490738d12075d3908ec2ddfd090fdbb32d8a6fd53d1b3136d24485e1169` |
| 18 | `M` | `tests/test_rw0_remote_contact_phase_entry_contract.py` | 173,524 | `42d6d265c0a9ba5047aa37ec3a4daae30847d486d39ead6374685b451a1d445c` |
| 19 | `M` | `tests/test_remote_worker_pre_execution_planning_contract.py` | 913,152 | `92b0f3917f0572492357447211a1f0f0cc7f8edb7e8b5f18233ed80397879b29` |
| 20 | `M` | `tests/test_software_development_progression_boundary.py` | 42,899 | `bd9b10f62e3bbfb3dc5fc845958fe0087363a0afa0b80649853faac85235c7a3` |
| 21 | `M` | `tests/test_autonomous_software_development_operating_model.py` | 72,904 | `e9a77edb1f99b181c612e52c4a7cfee814ac3f0df4d974e7c3a0756aec6da8df` |
| 22 | `M` | `tests/c2a_contract_support.py` | 154,372 | `58be92ddffae6f4b901ae3632521481ab8d9ce0e02a819ef9421408d08eedd85` |
| 23 | `M` | `tests/test_rw0_b1_boundaries.py` | 38,321 | `bd52384897f8f7a7129023c693ef67b1ff453a006723438dfa4f06df08e4121f` |
| 24 | `M` | `tests/test_rw0_b2_capability_boundaries.py` | 45,708 | `4e4824b5974778cbef147e7f5a5684de34e5006464156cbb7be2958c33ce1a84` |
| 25 | `M` | `tests/test_c2b0_durable_state_contract.py` | 884,862 | `45a539a810deb8884c3f0158887a0d4fd06778a59e833c6b9d89365990ed62fd` |
| 26 | `M` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | 249,444 | `480bd282646304c70116f69faecabc1fea94d83ef54ec77b780a869ace5431c4` |
| 27 | `??` | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 25,151 | `bf65ba7f04411bb6e6febec2285b33721eb2ff895e2c60aee97878b1fa7c9b46` |
| 28 | `??` | `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | 63,314 | `0b5f13f41707413f051ef9a450b62242734e7978d30ebf99b1deb6f7f5f232cf` |

Require:

- zero staged paths;
- zero unmerged paths;
- zero deletions, renames, type changes, symlinks, executable-mode changes, or
  additional untracked paths;
- every tracked path outside this set byte-identical to HEAD.

## Complete patch corroboration

Construct the complete candidate patch in the exact 28-path table order.

For each tracked path:

```text
git diff --binary --full-index --no-ext-diff --no-textconv HEAD -- <path>
```

For each new path:

```text
git diff --no-index --binary --full-index --no-ext-diff --no-textconv -- /dev/null <path>
```

Treat expected `git diff --no-index` status `1` as “differences found.”

Concatenate exact stdout bytes in table order.

Expected repaired candidate:

- bytes: `282,372`
- SHA-256:
  `d16aecc7db8afd9a65c65dd8c228730562c2531a282ea3bb379a1af0ce6701ff`

Run the assembly twice.

The path set and per-file receipts are primary provenance. An unresolved patch
difference is a provenance mismatch.

## Canonical receipt corroboration

Reconstruct this exact canonical receipt.

Root:

```text
{"baseline": object, "files": array}
```

`baseline` has exactly these nine string fields:

- `branch`
- `head`
- `tree`
- `parent`
- `subject`
- `upstream`
- `divergence`
- `staged`
- `unmerged`

Values:

- `branch`: `trunk_dev`
- `head`: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- `tree`: `42cc0757b3d9604dfe7fdbda158074b8b48dac7b`
- `parent`: `db16de711986ae40a2bb848ed00cdddd3145ee02`
- `subject`: `docs: freeze RW0-C durable decision branch contract`
- `upstream`: `origin/trunk_dev`
- `divergence`: the string `0\t0`, containing one tab
- `staged`: empty string
- `unmerged`: empty string

`files` contains exactly 28 objects in the table order. Each object has exactly:

- `status`
- `path`
- `type`
- `mode`
- `bytes`
- `sha256`

Rules:

- object keys lexicographically sorted;
- arrays retain order;
- status is `M` or `??`;
- type is `regular`;
- mode is `0644`;
- bytes is a decimal integer;
- SHA-256 is lowercase hexadecimal;
- UTF-8 without BOM;
- compact JSON using `,` and `:` separators;
- `ensure_ascii=false`;
- one final LF;
- slashes unescaped;
- normal JSON string escaping.

Expected:

- bytes: `5,593`
- SHA-256:
  `5bd53947d2187a3bacc710684ba35b646cb55fb4a1eaa3e91d18ecbf54accabb`

Run two independent implementations and require byte-identical output.

## V1-to-V2 repair transition

Only these five paths may have changed from the independently blocked V1
candidate:

1. `.docs/c2b-durable-development-state.md`
2. `tests/test_rw0_b2_capability_boundaries.py`
3. `tests/test_c2b0_durable_state_contract.py`
4. `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`
5. `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py`

Reported transitions:

| Path | V1 bytes / SHA-256 | V2 bytes / SHA-256 |
|---|---|---|
| `.docs/c2b-durable-development-state.md` | `1,889,083` / `db065fd8fd37d537bdac3194f021995dfcf2fbd92a31d2c7e4f0dc4c4e3a60d7` | `1,889,329` / `6115a29d5bbfb8ffb17404e9acbefcb8edc958554683afa3538e9d959e184ef8` |
| `tests/test_rw0_b2_capability_boundaries.py` | `39,011` / `51e728f48b6c024f782f7b32b46e5c8de11bb519702e7478d3fb420655c4822a` | `45,708` / `4e4824b5974778cbef147e7f5a5684de34e5006464156cbb7be2958c33ce1a84` |
| `tests/test_c2b0_durable_state_contract.py` | `882,642` / `deb6164d311189fa1eeab68dbf4296bdaf6b9bafe6e1808ce8122d1a8e4dd2ec` | `884,862` / `45a539a810deb8884c3f0158887a0d4fd06778a59e833c6b9d89365990ed62fd` |
| `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | `245,532` / `718d10e2047b49a5e5baa65db92e434b0fcd1d23a821124529e13e10b26951ff` | `249,444` / `480bd282646304c70116f69faecabc1fea94d83ef54ec77b780a869ace5431c4` |
| `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | `35,975` / `d919401246964c0db667db5d42df7bcc454a689964bc11cf91913d181b2f604d` | `63,314` / `0b5f13f41707413f051ef9a450b62242734e7978d30ebf99b1deb6f7f5f232cf` |

The other 23 final candidate paths must equal their V1 candidate receipts,
which also equal the exact final receipts above.

Historical V1 bytes are corroborating transition evidence. The live V2 bytes
are the audit target.

## Historical-byte coordinates

### C2B durable-state document

Require the complete committed HEAD content to remain an exact prefix:

- committed prefix bytes: `1,887,232`
- committed prefix SHA-256:
  `77bf3d3c6ed710da669db7fa4353f46f3d1e9b4e09636918046d16d94ed962e5`

The repaired append is reported as:

- bytes: `2,097`
- SHA-256:
  `f34b64471dca1276470bf92195f9b318193701f1af03baf1f911091a8ba80c5c`

Verify exact prefix equality and inspect the appended successor semantically.

It must state unambiguously that:

- historical mutable-latch sections and their physical selections are
  historical/proof precursors or reopened choices;
- later committed current-status successors, migration facts, owner routing,
  and current-family statements retain their existing authority;
- only mutable-latch target representation is superseded;
- the complete opening document is not demoted to historical evidence.

### C2B3 program initialization

The unchanged V1 candidate must still support exact reconstruction:

- committed file bytes: `26,747`
- committed SHA-256:
  `3d93195ab570e96f8f535feb38f83ebcd6b6ba112ca1db2a47d04b19258ef567`
- candidate insertion: `940` bytes at byte `26,691`
- insertion immediately before
  `COORDINATOR_C2B3D_COMMITTED_CURRENT_STATUS_END`

Remove only that insertion and require exact committed-file reconstruction.

## Audit posture

This is an independent audit, not implementation validation.

Permitted:

- read-only Git inspection;
- static inspection of docs, source, schemas, migrations, tests, examples, and
  configuration;
- read-only lexical and AST analysis with `PYTHONDONTWRITEBYTECODE=1`;
- pytest and hostile mutants only in private external local clones;
- at most three bounded read-only explorer subagents with self-contained
  prompts.

Prohibited:

- editing, formatting, cleaning, or repairing live files;
- staging, committing, pushing, PR operations, or merging;
- remote or sibling-repository contact;
- moving, deleting, rewriting, or importing through the live ignored cache;
- opening or mutating an operator or product-state database;
- running migrations or services;
- installing dependencies;
- generating client-visible artifacts.

Remove all audit-created temporary data at closeout.

## Source-of-truth posture

Apply the repository authority hierarchy:

- Git owns commit/tree/blob/ref facts.
- `AGENTS.md` owns repository guidance and routing.
- `.docs/` owns current and accepted-target semantics within declared scopes.
- the operating model owns composition/current-status classification.
- source and migrations own current implemented behavior and representation.
- tests are executable evidence and drift guards, not semantic owners.
- reports are evidence only.

The selected architecture remains:

- one standing-policy-admitted Coordinator authority lineage per bootstrap scope;
- operational realizations do not mint lineages or allowances;
- one active Coordinator authority per lineage;
- immutable admission fact;
- zero or one immutable bootstrap-acceptance fact;
- one productive direct-local acceptance per admitted lineage scope;
- permanent non-replenishment;
- acceptance fact in the durable decision family;
- no mutable latch subsystem;
- exact replay;
- one whole-family classifier;
- no fact on nonaccept branches;
- terminal nonmutation;
- later ES operation separately governed and non-replenishing.

Do not reopen that architecture unless the live repository contains a direct
contradiction introduced by V2.

## Recommended explorer structure

At most three read-only explorers may be used.

### Explorer 1 — repair causality and test independence

Audit:

- capability structured evidence and AST integrity;
- type-exact human/machine comparison;
- closed Markdown table parsing;
- operational-realization completeness;
- all repair-specific mutants.

### Explorer 2 — C2/guard ordering and oracle integrity

Audit:

- fencing before protected receipt disclosure;
- receipt-first replay;
- authoritative pre-model C2 reduction;
- acceptance-only guard eligibility;
- model consistency last;
- exact replay bypass of fresh evaluation;
- no second reducer/replay/recovery owner.

### Explorer 3 — architecture regression, history, and protected surfaces

Audit:

- Option A lineage policy;
- owner split and branch effects;
- B1 compatibility;
- C2B/C2B3 historical treatment;
- P08/P11/P12/P13 semantic supersession;
- source/migration/public/runtime preservation;
- validation/provenance.

The parent must independently inspect the central evidence and reconcile all
findings.

## Required inspection

Read all 28 candidate paths and every current unchanged owner/test edge needed
to verify:

- current B1 source/schema behavior;
- migration inventory 0001–0004;
- package exports;
- StateStore and WriterSession;
- transaction/read/write surfaces;
- C2A nonimplementation;
- B1 phase-value/relation/vector/schema/budget tests;
- B2 Wire and cancellation-control tests;
- C2B3 program-initialization tests;
- runtime-nonauthority and public-surface guards.

Follow additional exact owner/test edges discovered.

## Audit question 1 — five-file repair boundary

Verify:

- exactly the five specified files changed from V1 to V2;
- the other 23 candidate paths remain byte-identical;
- all source, schemas, migrations, package exports, StateStore, WriterSession,
  readers, writers, transactions, public surfaces, runtime surfaces,
  configuration, and examples remain byte-identical to HEAD;
- no accepted semantic architecture changed outside the C2B wording
  clarification;
- the V2 work remains test adequacy, test-oracle correction, and one bounded
  documentation clarification.

Any hidden semantic redesign or source widening is blocking.

## Audit question 2 — capability semantic-integrity repair

Inspect the repaired P08/P11/P12/P13 semantic-evidence path.

Require:

1. a structured result with fixed, explicit entries for P08, P11, P12, P13;
2. each entry binds:
   - exact protected path;
   - exact contract class;
   - old protected identity changed;
   - replacement identity;
   - exact replacement semantic markers;
   - unchanged purpose and ownership boundary;
3. the caller compares the entire structured result with independent fixed
   expectations;
4. `None`, empty mapping, missing entry, ignored return, missing marker, or
   wrong purpose fails;
5. the guard verifier independently:
   - parses the capability test AST;
   - proves the helper/evidence path exists;
   - proves the result is consumed and compared;
   - rejects `pass`, empty body, call-only, or ignored-return forms;
   - parses the four protected documents directly.

Block hash-only protection or self-confirmation from capability test source.

Independently reproduce:

- helper body replaced by `pass`;
- helper returns empty mapping;
- helper call retained but result ignored;
- one P entry removed;
- one semantic marker removed;
- hashes refreshed without replacement assertions.

Require exact intended failure boundaries.

## Audit question 3 — normative ordering protection

Inspect the guard owner’s normative ordering and the repaired verifier.

Require structural protection of these edges:

1. writer/session admission and fencing precede protected receipt/collision
   disclosure;
2. receipt replay/collision handling precedes fresh branch or guard evaluation;
3. fresh authoritative branch derivation precedes acceptance-only guard
   eligibility;
4. guard eligibility precedes model consistency;
5. model consistency is absent after an earlier universal or acceptance-only
   guard no-write;
6. exact replay runs no fresh branch, guard, or model evaluation.

The tests must parse the normative ordered prose/table directly, not rely on a
second duplicate prose constant or only machine JSON.

Independently mutate:

- fencing after receipt lookup;
- guard eligibility before replay;
- model consistency before guard eligibility;
- exact replay performing fresh model evaluation.

Require precise trace/order failures.

## Audit question 4 — C2 pre-model split and shadow-owner risk

Inspect the amended C2 test-local oracle.

Require:

- one authoritative pre-model phase containing the prior C2 basis/currentness/
  matrix/branch semantics;
- one deferred model-consistency phase;
- an ordinary C2 wrapper preserving standalone C2 behavior;
- the guard composition invoking pre-model C2, then applicable guard gates,
  then model consistency;
- no second reducer, branch owner, replay owner, or recovery classifier;
- existing C2 source-evidence, matrix, currentness, branch, retained-evidence,
  model-authority, replay, and recovery controls remain causal.

Directly test:

- claimed scope + otherwise valid acceptance;
- unresolved scope + otherwise valid acceptance;
- lineage mismatch;
- multiple active authorities;
- eligible acceptance with recognized recommendation;
- eligible acceptance with out-of-vocabulary recommendation;
- all four nonaccept branches under exact universal posture;
- exact replay.

Block if a guard rejection trace contains `model_consistency_evaluated`.

## Audit question 5 — type-exact human/machine equivalence

Inspect both C2 and guard recursive comparators.

Require exact built-in-type semantics:

- bool only equals bool;
- int excludes bool;
- str only equals str;
- None only equals None;
- exact mapping/container types as declared;
- exact key set and, where normative, order;
- exact sequence type, length, and order;
- recursive comparison;
- exact JSON-pointer/table-role failure locations;
- no subclass or numeric coercion.

Independently reproduce at least:

- human `true` versus machine `1`;
- human `1` versus machine `true`;
- human `false` versus machine `0`;
- human `0` versus machine `false`;
- sibling string drift;
- null/value drift;
- a mapping/list container-type substitution.

Require exact type/equivalence boundaries.

## Audit question 6 — closed human Markdown tables

Inspect every normative guard human table.

Require:

- exact table inventory and headings;
- exact header and separator;
- every nonblank bounded line consumed;
- exact column count;
- cells parsed with or without backticks;
- duplicate role/key rejection;
- extra/missing row rejection;
- malformed/unescaped-pipe rejection;
- type-exact value conversion;
- exact full row-set equality to independent fixed expectations and machine
  data;
- no silent row skipping.

Independently reproduce:

- unbackticked contradictory `scope.identity = database`;
- duplicate conflicting row;
- extra column;
- unparseable value;
- missing row;
- legitimate backtick removal.

The contradictory and malformed variants must fail. The legitimate backtick
removal must pass without collection change.

## Audit question 7 — operational-realization completeness

Independently derive the owner’s closed inventory and compare it with the fixed
test inventory.

Required members:

- deployment;
- machine;
- process;
- database;
- database file;
- repository;
- program;
- attempt;
- candidate;
- command;
- parent grant;
- restore;
- rollback;
- clone;
- passive backup;
- relocation.

Require:

- exact set equality;
- one causal nonidentity/ non-replenishment case per member;
- independently admitted lineages may each have one scope;
- removing one case fails a fixed completeness assertion rather than shrinking
  collection silently.

Independently mutate deployment, attempt, candidate, and command to mint a fresh
allowance. Require exact realization-specific failures.

## Audit question 8 — C2B current-status clarification

Verify:

- complete committed 1,887,232-byte prefix is exact;
- only the appended successor changed from V1;
- historical mutable-latch sections and physical selections are historical or
  reopened;
- later committed current-status successors, current migration facts, owner
  routing, and current-family statements retain authority;
- the complete opening document is not classified as historical;
- current target routes to the immutable guard owner;
- no source, migration, table, or provisioner implementation is claimed.

Independently broaden the historical classification to the whole opening
document. Require rejection at:

`c2b:current_status_authority`

## Audit question 9 — preserved architecture and owner split

Verify no regression in:

- Option A lineage policy;
- standing-policy admission;
- one active authority;
- continuity fail-closed;
- local absence not proving eligibility;
- immutable admission and acceptance facts;
- cross-program one-shot ceiling;
- five branch effects;
- guard conflict no-write, never block;
- receipt-first replay;
- one complete-family recovery classifier;
- partial families unresolved;
- competing winner prohibits retry;
- terminal nonmutation;
- later ES non-replenishment;
- C2 owner versus guard owner non-overlap;
- B1 legacy compatibility and nonproof;
- four-document normalized body;
- C2A/B2/progression/AGENTS/README routing;
- historical C2B/C2B3 preservation;
- P08/P11/P12/P13 substantive semantic supersession.

Block any second replay/recovery owner or acceptance fact on a nonaccept branch.

## Audit question 10 — test independence and shadow-owner risk

Require real independence among:

- fixed expectations;
- parsed owner prose;
- parsed owner machine JSON;
- parsed human tables;
- capability structured evidence;
- C2 pre-model output;
- guard composition output;
- hostile expectations.

Block if one mutable table authors expected and observed truth.

Inspect the enlarged 249,444-byte C2 verifier and 63,314-byte guard verifier.

Accept finite document-driven contract checking.

Block:

- a second production reducer;
- test-local physical storage model;
- independent replay/recovery semantics;
- source behavior emulation replacing source inspection;
- self-authored hostile boundaries;
- broad source-manifest freezes presented as architecture.

## Audit question 11 — complete mutant reproduction

Independently recreate all 44 reported negative variants.

### Original O01–O24

1. mutable latch restored in one normalized body;
2. one-body drift;
3. C2 mutable-latch prose;
4. C2 machine-only latch restoration;
5. database used as scope;
6. restore creates fresh allowance;
7. admission omitted;
8. active-active accepted;
9. local absence proves eligibility;
10. second unrelated program accepts;
11. nonaccept branch creates fact;
12. guard conflict becomes durable block;
13. replay creates a fact/timestamp;
14. partial family becomes committed;
15. competing winner permits retry;
16. terminal changes guard truth;
17. ES replenishes allowance;
18. B1 pair treated as durable proof;
19. capability semantics removed;
20. historical C2B physical representation promoted;
21. duplicate JSON key;
22. normative prose ordering drift;
23. machine-only drift;
24. migration/provisioner/writer/runtime claim.

### Repair N01–N15

25. capability helper body replaced by `pass`;
26. capability helper returns empty mapping;
27. fencing/replay reversed;
28. eligibility before replay;
29. model before eligibility;
30. human true changed to integer;
31. human zero changed to false;
32. bare contradictory scope row;
33. duplicate scope row;
34. extra table column;
35. deployment creates allowance;
36. attempt creates allowance;
37. candidate creates allowance;
38. command creates allowance;
39. complete C2B opening document classified historical.

### Supplementary S01–S05

40. C2 human false changed to zero;
41. early model despite premature guard stamp;
42. realization case omitted;
43. unparseable human value;
44. second unrelated program accepts through the behavioral oracle.

For each require:

- the complete ordered 7,741-test collection;
- failure at the intended semantic boundary;
- no syntax/import/format-only failure;
- no collection shrinkage;
- exact failed test or boundary ID.

Also reproduce the legitimate human-row backtick-removal positive and require it
to pass with unchanged collection.

## Audit question 12 — selector reproducibility

For the exact relevant module sets, run `--collect-only -q` before execution.

Expected selectors:

| Selector | Expected selected / passed |
|---|---:|
| `capability_semantic_integrity` | `9 / 9` |
| `guard_ordering_integrity` | `4 / 4` |
| `typed_human_machine_equivalence` | `23 / 23` |
| `closed_human_table` | `11 / 11` |
| `model_after_guard` | `13 / 13` |
| `operational_realization` | `18 / 18` |
| `c2b_current_status_authority` | `3 / 3` |
| `hostile` | `646 / 646` |

No selector may select zero or unrelated tests.

## Audit question 13 — exact collection and validation

Create a private external local clone from exact committed HEAD without remote
contact. Overlay exactly the 28 verified candidate files.

Do not import from or alter the live ignored cache.

Run serially with:

```text
PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=.:src
python3 -m pytest -q -p no:cacheprovider --basetemp=<external>
```

### Exact module collection

Expected:

| Module/run | Expected collection |
|---|---:|
| `tests/test_rw0_b2_capability_boundaries.py` | `23` |
| `tests/test_c2b0_durable_state_contract.py` | `351` |
| `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | `1,334` |
| `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | `213` |
| Combined four modules | `1,921` |
| Full repository | `7,741` |

### Focused command

Run:

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_rw0_b2_capability_boundaries.py \
  tests/test_c2b0_durable_state_contract.py \
  tests/test_rw0_c2_durable_progression_decision_semantic_contract.py \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

Expected:

`1,921 passed`

### Exact 17-module targeted command

Run the same 17-module command used by the V1 audit, ending with the repaired
guard verifier.

Expected:

`3,530 passed`

### Exact broader command

Run the same broader glob/list command used by V1.

Expected:

`3,611 passed, 3 warnings`

### Full repository

Expected:

`7,741 passed, 3 warnings`

The only expected warnings are the unchanged Python 3.13 multi-threaded
`fork()` deprecations from these three writer-session tests:

- `test_operation_guard_close_waits_and_retains_authority_until_exit`;
- `test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang`;
- `test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock`.

Investigate every count or warning mismatch.

Also require:

- `git diff --check`;
- both new-file `/dev/null` whitespace checks;
- UTF-8/CR/trailing-whitespace/final-newline checks;
- source/migration/public-surface preservation;
- C2B/C2B3 historical reconstruction;
- artifact scan.

## Audit question 14 — nonimplementation and protected surfaces

Independently verify:

- all 212 tracked paths outside the candidate equal HEAD;
- all 66 source/resource paths equal HEAD;
- migrations exactly 0001–0004;
- migration `0005` absent;
- SQL resource hashes unchanged;
- package exports unchanged;
- StateStore, WriterSession, readers, writers, transactions unchanged;
- no guard/admission/acceptance source module;
- no provisioner;
- no durable decision writer;
- no reader/recovery implementation;
- no production caller;
- no public API;
- no runtime activation;
- no RW0-D/E or Execution Substrate modification;
- no product database or runtime artifact.

## Live cache and cleanup

At opening and closeout, inventory the 37 pre-existing ignored cache members
without importing, moving, deleting, or rewriting them.

Canonical cache grammar:

- root: path-sorted JSON array;
- each object has exactly:
  - `path`
  - `type`
  - `mode`
  - `size`
  - `mtime_ns`
  - `sha256`
- object keys lexicographically sorted;
- compact JSON;
- UTF-8;
- one final LF.

Expected implementation evidence:

- bytes: `8,934`
- SHA-256:
  `5115f03863b1ab265957809d6e33ccf12f18b73f61fe9f2998c150573bbf570a`

Treat member equality as primary. If the aggregate differs solely because of a
clearly identified canonical-envelope issue while every member is exact,
classify it as report-only; do not invent a candidate mismatch.

Remove all audit-created temporary data.

## Final provenance

After cleanup, require:

- exact baseline HEAD and branch;
- exact 28-path status and receipts;
- zero staged/unmerged paths;
- no additional path;
- exact complete patch;
- exact canonical receipt;
- unchanged source/migration/public surfaces;
- exact C2B and C2B3 historical reconstruction;
- exact ignored-cache opening/closing member equality;
- no audit-created repository or deliverable artifact.

Run patch and receipt calculations twice and require byte-identical outputs.

## Severity and verdict rules

Blocking findings include:

- provenance mismatch;
- any surviving required mutant;
- capability semantics removable or self-confirming;
- normative ordering drift undetected;
- bool/int or other type-coercion drift;
- unconsumed or ignored human table rows;
- model consistency before a guard gate;
- incomplete operational-realization coverage;
- broad C2B historical demotion;
- regression in Option A lineage or immutable-fact architecture;
- overlapping C2/guard replay or recovery ownership;
- acceptance fact on a nonaccept branch;
- guard conflict converted to durable block;
- partial family classified committed;
- competing winner permitting retry;
- B1 legacy pair treated as durable proof;
- test verifier becoming a shadow owner;
- source/migration/public/runtime widening;
- unexplained collection, test-count, or warning mismatch.

### Accept

Use only when no unresolved High- or Medium-severity finding remains:

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_ACCEPTED_READY_FOR_COMMIT_GATE`

Acceptance authorizes only a separate commit/publication gate for the exact 28
audited paths.

It does not authorize:

- source or safe-value changes;
- migration `0005`;
- scope provisioning;
- durable decision writing;
- guard persistence;
- readers or recovery implementation;
- terminal persistence;
- public API widening;
- runtime activation;
- RW0-D/E;
- Execution Substrate work.

### Block

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_AUDIT_BLOCKED`

### Provenance mismatch

`AUDIT_PROVENANCE_MISMATCH`

## Inline report structure

Return:

1. primary verdict;
2. visible model/reasoning setting;
3. exact baseline and V2 candidate provenance;
4. patch, receipt, repair-transition, and historical-byte reconciliation;
5. inspection scope and limits;
6. five-file repair-boundary audit;
7. capability semantic-integrity audit;
8. normative ordering audit;
9. C2 pre-model and model-after-guard audit;
10. type-exact human/machine audit;
11. closed human-table audit;
12. operational-realization audit;
13. C2B current-status clarification audit;
14. preserved architecture and owner-split audit;
15. test-independence and shadow-owner audit;
16. all 44 mutant results and positive parser probe;
17. selector reproducibility;
18. independent collection and validation;
19. nonimplementation/protected-surface audit;
20. live-cache and final provenance;
21. severity-ranked findings;
22. exact next boundary;
23. required non-actions;
24. final token.

## Required non-actions

State:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIRS_NOT_PERFORMED
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
SCHEMAS_NOT_MODIFIED
NON_CEILING_DOCS_NOT_MODIFIED
NON_CEILING_TESTS_NOT_MODIFIED
OPERATOR_OR_PRODUCT_DATABASE_NOT_OPENED_OR_MUTATED
LIVE_IGNORED_CACHE_NOT_MOVED_OR_MODIFIED
DEPENDENCIES_NOT_INSTALLED
SERVICES_NOT_STARTED
REMOTE_CONTACT_NOT_PERFORMED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
MERGE_NOT_PERFORMED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
BOOTSTRAP_SCOPE_PROVISIONER_NOT_IMPLEMENTED
BOOTSTRAP_ACCEPTANCE_GUARD_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUBAGENTS_READ_ONLY_IF_USED
EXTERNAL_ARTIFACTS_NOT_GENERATED
```
