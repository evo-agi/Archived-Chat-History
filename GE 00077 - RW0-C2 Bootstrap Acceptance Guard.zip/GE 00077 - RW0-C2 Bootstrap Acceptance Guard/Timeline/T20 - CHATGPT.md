## Disposition

**Accept the independent audit’s `BLOCKED` verdict. Do not stage or commit the V2 candidate.**

The candidate itself remains well bounded:

- baseline and all 28 file receipts matched;
- the patch and canonical receipt reproduced;
- every source and migration path remained unchanged;
- the selected immutable lineage/admission/acceptance architecture remained coherent;
- the full repository passed **7,741 tests with the three expected warnings**. :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"}

The remaining defects are in **causal observation**, not in the governing semantics or production implementation. The audit explicitly found no production-source or selected-architecture regression. :chatgpt-content-reference{index="2"}

## Why the block is correct

### 1. A real model call can occur before guard eligibility without detection

The required S02 mutant calls `_model_consistency_phase` inside the C2 defining module’s pre-model return path, discards the result, and returns the unchanged prepared object. Because the existing spies patch aliases imported by the guard verifier rather than the function’s defining-module global, the actual call escapes observation. The returned trace remains clean even though model evaluation occurred. :chatgpt-content-reference{index="3"}

This is a genuine authority-sensitive test defect. A returned trace proves only what was retained in the returned value; it does not prove that an unauthorized helper was never entered.

### 2. Replay can be entered before fencing and then discarded

The auditor added an early replay call before writer fencing. The call’s result was discarded, after which normal fenced evaluation continued. All guard tests still passed. Independent observation confirmed one replay call in the mutant and zero in the baseline for the unfenced case. :chatgpt-content-reference{index="4"}

Even though the current verifier helpers are pure test code, this ordering contract protects future receipt and collision information from pre-fence disclosure. It needs actual-entry observation, not only outcome comparison.

### 3. The “cross-program” case does not prove two programs

Replacing `unrelated_program_B` with program A leaves all guard tests green. The behavioral test still proves that a second acceptance is rejected, but no longer proves the intended **cross-program** ceiling. :chatgpt-content-reference{index="5"} :chatgpt-content-reference{index="6"}

The scenario must independently establish:

```text
same admitted lineage and bootstrap scope
+ distinct program A and program B identities
+ distinct command/mutation coordinates
+ first acceptance claims the scope
+ second fresh cross-program acceptance is rejected
```

A label containing “B” is not evidence of a different program identity.

## Repair boundary

The narrowest truthful repair is **one file only**:

```text
tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

No document amendment is required. No C2 verifier amendment is required. No accepted semantics need to change.

The guard verifier can close all three findings by:

- wrapping the actual helper attributes in their **defining modules**, as well as relevant imported aliases;
- recording or hard-failing on actual model and replay helper entry;
- asserting zero actual calls on all earlier rejection paths;
- asserting exact helper-entry order on successful and replay paths;
- adding a fixed scenario-integrity check over actual program, scope, head/basis, command, mutation, attempt, and candidate coordinates.

If the defining-module and alias paths cannot be observed reliably within that one verifier file, the repair must stop rather than widen the tranche.

## V3 repair handoff

Resume the **original governing-reset implementation conversation**, change it to workspace-write, and keep the parent as the sole writer. Attach nothing.

:chatgpt-content-reference{index="9"}[Download the complete V3 actual-call causality repair prompt](sandbox:/mnt/data/Coordinator_RW0_C2_Bootstrap_Guard_Governing_Reset_V3_Actual_Call_Causality_Repair_Prompt.txt)

```text
Filename:
Coordinator_RW0_C2_Bootstrap_Guard_Governing_Reset_V3_Actual_Call_Causality_Repair_Prompt.txt

Size:
26,287 bytes

SHA-256:
0f5c2531c8e9018087d048bb7ecd6acde6a526e3c074eaf17679aa57468dc4bd

Logical lines:
716

Final newline:
present
```

The prompt requires three concrete repairs.

### Actual model-entry causality

It instruments both:

```text
the C2 function’s defining-module global
and
every relevant imported alias used by the guard verifier
```

Zero-call paths use a hard-fail or equivalent probe, so a call cannot be hidden by discarding its output or deleting its trace marker.

It directly covers:

- replay;
- lineage mismatch;
- missing or foreign admission;
- multiple active authorities;
- claimed scope;
- unresolved scope;
- eligible recognized and unrecognized model recommendations;
- all four nonaccept branches.

### Actual replay-entry and fencing causality

It requires exact helper-entry counts and order for:

- unfenced caller;
- invalid writer/session admission;
- fresh fenced command;
- exact replay;
- mutation-reference reuse;
- family-route collision.

The expected actual-entry order is bound as:

```text
writer/session fenced
→ receipt or collision helper entered
→ authoritative pre-model phase
→ acceptance guard, when applicable
→ model consistency, when applicable
```

The repair must catch direct, aliased, wrapped, duplicated, and discarded early replay calls.

### Cross-program scenario integrity

It freezes a real two-program scenario and asserts before behavioral execution that:

- the two program identities are nonempty and unequal;
- each head/basis belongs to its own program;
- mutation and command identities differ;
- both commands share the same admitted lineage and bootstrap scope.

It adds exact mutants for collapsed program, head/basis, mutation, scope, and same-program-attempt substitutions.

## Validation improvements

The preceding audit could not reproduce the exact historical targeted and broader commands because the audit prompt referred to them indirectly rather than listing their arguments. The V3 repair prompt includes the complete commands explicitly.

It requires:

- all original 44 negative mutants;
- the legitimate table-format positive;
- the S02, early-replay, and collapsed-program mutants;
- direct and indirect helper-call variants;
- selector-level collection and execution;
- focused C2/guard validation;
- the exact 17-module targeted command;
- the exact broader command;
- the complete repository suite;
- exact 28-path provenance and preservation of the other 27 candidate files.

Success token:

```text
RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_REPAIRED_V3_VALIDATED_READY_FOR_REAUDIT
```

Blocking token:

```text
RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_V3_REPAIR_BLOCKED
```

A successful repair authorizes only another fresh independent read-only audit. The commit/publication gate remains closed until that audit verifies actual-call causality and scenario distinctness. The audit itself prescribed exactly this next boundary. :chatgpt-content-reference{index="7"}

**Sources:** Independent V2 re-audit report attached in this turn. :chatgpt-content-reference{index="8"}

**Confidence:** High that the block is correct. High that no governing-document or production-source change is required. Medium-high that the one-file verifier repair is sufficient; the prompt explicitly stops rather than widening if defining-module call observation cannot be closed within that boundary.
