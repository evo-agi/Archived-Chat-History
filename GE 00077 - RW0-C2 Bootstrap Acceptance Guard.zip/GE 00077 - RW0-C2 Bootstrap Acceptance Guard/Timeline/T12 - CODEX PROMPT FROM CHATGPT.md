# Governed Execution Coordinator — RW0-C2 Bootstrap Acceptance-Guard Governing Reset

## Role and execution posture

Continue the same read-only governing-reset reconnaissance conversation after
the operator changes the parent permission posture to workspace-write.

Use the highest reasoning setting already selected by the operator. Record
exactly what the interface visibly shows for:

- model name;
- reasoning setting or effort.

Do not infer hidden configuration. Record `not visible` when necessary.

The parent is the sole repository writer. Do not spawn subagents.

Implement and validate one atomic **documentation-and-contract-test-only
governing reset** that replaces the current accepted-target mutable
acceptance-latch architecture with the accepted immutable bootstrap
acceptance-guard architecture.

This tranche must reconcile every current governing owner and every existing
test that promotes the mutable-latch wording into current target authority.

Do not modify production source, schemas, migrations, readers, writers,
transactions, public APIs, package exports, runtime behavior, RW0-D/E, or
Execution Substrate behavior.

Return one substantive inline closeout report. Do not create or attach an
external report, manifest, package, freeze artifact, or other client-visible
file.

## Exact repository baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required opening baseline:

- branch: `trunk_dev`
- HEAD: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- tree: `42cc0757b3d9604dfe7fdbda158074b8b48dac7b`
- sole parent: `db16de711986ae40a2bb848ed00cdddd3145ee02`
- subject: `docs: freeze RW0-C durable decision branch contract`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- clean tracked, untracked, staged, and unmerged state
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Do not fetch or contact remotes.

Stop before editing on any mismatch:

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_BLOCKED`

## Authority and truth posture

Apply the repository authority hierarchy:

- Git owns commit, tree, blob, and ref facts.
- `AGENTS.md` owns repository guidance and routing.
- `.docs/` owns current and accepted-target semantics within each document’s
  declared scope.
- `.docs/autonomous-software-development-operating-model.md` remains the
  composition/current-status authority.
- source and migrations own current implemented behavior and durable
  representation.
- tests are executable evidence and drift guards, not independent semantic
  owners.
- reports and generated artifacts are evidence only.

This reset changes accepted target contracts. It does not change current
implementation.

Classify all statements as one of:

- current implemented contract;
- accepted target contract;
- bounded compatibility edge;
- historical/proof precursor;
- reopened future seam;
- evidence/projection;
- nonclaim.

Do not silently rewrite historical material into current truth.

## Accepted product policy and target architecture

Freeze the following accepted strategic decision exactly.

### Coordinator authority lineage

One bootstrap scope belongs to one explicitly admitted **Coordinator authority
lineage**.

A deployment, machine, process, database, database file, repository, program,
attempt, candidate, command, parent grant, restore, rollback, clone, passive
backup, or relocation does not create a lineage or bootstrap allowance merely
by existing.

A genuinely independent Coordinator authority lineage may receive a distinct
bounded direct-local bootstrap scope only through an explicit standing-policy
admission act.

### Continuity and active authority

Machine replacement, database replacement, restore, rollback, cloning, passive
backup, and relocation do not create a new scope or allowance.

Lineage continuity must be positively established. The target supports one
active Coordinator authority per lineage, not active-active operation by
multiple database copies or Coordinator authorities claiming one lineage.

Missing, ambiguous, foreign, stale, conflicting, unreadable, or unfenced
lineage/continuity/sole-active-authority evidence fails closed.

A machine, database, process, or local lock is evidence about an operational
realization, not the lineage identity.

### Permanent direct-local bootstrap ceiling

For one admitted lineage scope, across every participating direct-local
bootstrap program, attempt, candidate, command, restart, restore, replacement,
relocation, clone, and parent grant:

> At most one distinct productive `candidate_acceptance` may commit.

After that acceptance:

- the immutable bootstrap-acceptance fact remains permanent;
- the scope is never reset, renewed, reopened, replenished, deleted, or
  recreated;
- a new grant, policy epoch, program, command, machine, database, restore, or
  relocation creates no new allowance.

Later ES-routed operation is governed separately. It does not consume,
replenish, reset, or reinterpret this bounded direct-local proof allowance.

### Selected immutable-fact design

The target owns:

1. one immutable bootstrap-scope admission fact; and
2. zero or one immutable bootstrap-acceptance fact for that admitted scope.

The acceptance fact is an immutable member of the exact durable acceptance
decision/result/receipt family.

There is no target mutable `available -> consumed` latch subsystem, latch state
row, latch revision transition, reset path, separate latch commit, separate
latch receipt, separate latch replay classifier, or separate latch recovery
classifier.

The decision writer may later record acceptance against an admitted scope. It
may not create, admit, renew, or replenish the scope.

Mere absence of a local row, relation, projection, database, or file is never
sufficient evidence that the scope is unclaimed.

## Current blocker and required explicit supersession

The current repository still has a live accepted-target mutable-latch contract.

It appears in:

- the merged RW0-C2 durable-decision owner;
- the remote-phase owner;
- an identical four-document cross-reference body in the operating model,
  worker boundary, authority boundaries, and durable-state model;
- C2A expansion language;
- B1/B2/progression target projections;
- historical/current-status material and contract tests.

This reset must openly supersede those current target requirements. Do not call
the target meaning unchanged.

Historical latch material remains proof/precursor evidence where explicitly
classified as such.

## Exact 28-path mutation set

At closeout, the changed/untracked set must be exactly these 28 repo-relative
paths and no others.

### Governing semantic owners

1. `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
2. `.docs/rw0-remote-worker-contact-phase-entry.md`
3. `.docs/c2a-first-slice-semantic-protocol-contract.md`
4. `.docs/c2b-durable-development-state.md`

### Status, composition, and cross-reference projections

5. `AGENTS.md`
6. `README.md`
7. `.docs/architecture.md`
8. `.docs/autonomous-software-development-operating-model.md`
9. `.docs/authority-boundaries.md`
10. `.docs/durable-state-model.md`
11. `.docs/worker-execution-boundary.md`
12. `.docs/software-development-progression-boundary.md`
13. `.docs/c2b3-program-initialization.md`
14. `.docs/rw0-b2-wire-protocol.md`
15. `.docs/rw0-b2-capability.md`

### Current private value-owner documentation

16. `.docs/rw0-b1-pure-phase-values.md`

### Existing contract tests/support

17. `tests/test_architecture_contracts.py`
18. `tests/test_rw0_remote_contact_phase_entry_contract.py`
19. `tests/test_remote_worker_pre_execution_planning_contract.py`
20. `tests/test_software_development_progression_boundary.py`
21. `tests/test_autonomous_software_development_operating_model.py`
22. `tests/c2a_contract_support.py`
23. `tests/test_rw0_b1_boundaries.py`
24. `tests/test_rw0_b2_capability_boundaries.py`
25. `tests/test_c2b0_durable_state_contract.py`
26. `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`

### New owner and verifier

27. `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md`
28. `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py`

No other path is authorized.

If truthful closure requires another document, test, support file, or source
path, stop and restore the exact opening worktree before returning the blocking
token.

## Protected implementation surfaces

Preserve byte-for-byte:

- every `src/` path;
- every migration and `src/ge_nwp_coordinator/sqlite_migration.py`;
- every schema;
- package exports;
- `StateStore`;
- `WriterSession`;
- transaction, reader, and writer source;
- every existing test outside the exact list above;
- every document outside the exact list above;
- configuration and examples.

Migration `0005` must remain absent.

No product or operator database may be opened or mutated.

Do not move, rewrite, import through, or delete the pre-existing ignored cache.

## Append-only historical treatment

### C2B durable-state document

`.docs/c2b-durable-development-state.md` must be append-only.

Capture the complete opening bytes before editing. The final bytes must start
with that exact complete opening byte sequence.

Append one bounded current successor after the existing EOF. Do not rewrite
Sections 1–42 or any existing successor/status text.

The successor must:

- retain the one-shot cross-program bootstrap ceiling;
- preserve no reset, deletion, renewal, or reuse;
- classify historical mutable-latch tables, seed rows, migration allocations,
  SQL, triggers, indexes, state/revision transitions, and consumed-postimage
  representation as historical/proof precursors or reopened selections;
- route current accepted-target semantics to the new immutable guard owner;
- bind scope to explicitly admitted Coordinator authority lineage;
- state that infrastructure replacement, restore, cloning, grants, and ES route
  transition do not replenish the allowance;
- preserve migrations 0001–0004 and all implementation nonclaims;
- explain that historical tests preserve historical evidence, not current
  physical authority.

### C2B3 program-initialization document

Preserve its historical planning/genesis content. Add only the bounded current
projection required to route the accepted guard target. Do not rewrite
historical literals or claim a current provisioner.

## Two-owner semantic split

Freeze a closed, non-overlapping owner split.

### RW0-C2 durable-decision semantic owner

`.docs/rw0-c2-durable-progression-decision-semantic-contract.md` remains sole
semantic owner of:

- command-local grammar and authoritative input reduction;
- currentness, V14/V15, matrix, and branch precedence;
- exactly five non-cancel branches;
- decision, program-version, and head semantics;
- result and receipt roles;
- mutation identity and canonical command digest;
- branch-neutral exact replay;
- the one complete-family recovery classifier;
- no-write versus durable block versus recovery-unresolved;
- model and caller non-authority;
- terminal-outcome separation.

It must route all bootstrap admission, lineage, eligibility, and acceptance-fact
semantics to the new guard owner.

### Bootstrap acceptance-guard semantic owner

Create:

`.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md`

Title:

`RW0-C2 Bootstrap Acceptance-Guard Semantic Contract`

It is sole accepted-target semantic owner of:

- admitted Coordinator authority-lineage scope;
- immutable bootstrap-scope admission fact;
- direct-local bootstrap applicability;
- exact lineage continuity and sole-active-authority posture;
- cross-program one-shot acceptance invariant;
- immutable bootstrap-acceptance fact;
- acceptance-guard eligibility and fail-closed classifications;
- the acceptance fact’s membership in the durable decision family;
- permanent non-replenishment;
- the guard-facing terminal boundary;
- the later ES non-replenishment boundary.

It does not own:

- branch derivation;
- complete command/result/receipt schemas;
- a separate mutation receipt;
- a separate replay path;
- a separate recovery classifier;
- physical storage;
- standing-policy issuance;
- execution admission or runtime authority;
- Git or publication authority.

The future guarded durable-decision transaction remains the sole writer that may
atomically create the acceptance fact.

## Immutable bootstrap-scope admission fact

Freeze a logical immutable admission fact binding, by semantic role:

- guard owner/profile identity;
- Coordinator authority-lineage identity;
- bootstrap scope identity;
- standing-policy admission act identity and digest;
- bounded direct-local applicability;
- admission provenance;
- non-renewable one-shot ceiling;
- admission-fact identity and canonical digest.

Authority rules:

- standing policy owns admission of an independent lineage;
- the Coordinator may later durably record the exact admitted binding under a
  separately accepted provisioning/physical contract;
- the decision writer, reducer, caller, model, replay path, and recovery path
  cannot create, replace, renew, or repair the admission fact;
- schema installation, an empty database, a copied database, or missing local
  rows do not admit a scope;
- the fact grants no execution, branch, runtime, publication, Git, or ES
  authority.

Physical admission/provisioning remains future.

## Command-facing admitted-lineage relation

Every applicable direct-local bootstrap command must bind canonical admitted
lineage and scope-expectation coordinates sufficient for conflict detection and
one exact scope derivation.

The relation must be:

- covered by the command digest;
- covered by the complete-family recovery selector;
- non-authoritative;
- incapable of requesting acceptance;
- incapable of selecting, admitting, minting, or renewing a scope;
- sufficient to detect stale, foreign, substituted, or ambiguous lineage
  expectations;
- acyclic with decision, acceptance-fact, result, receipt, and timestamp
  identities.

Delete as mandatory target architecture:

- mutable-latch selector;
- expected mutable `available` state or revision;
- available-preimage latch digest;
- preassigned consumed-latch postimage identity;
- separate latch result/receipt;
- separate latch replay or recovery classification.

Retain deterministic family-route identities where needed for collision
detection and recovery.

## Guard derivation and branch effects

### Conditions that must be exact for every applicable direct-local command

- admitted lineage identity;
- scope identity;
- admission fact binding;
- continuity across restore/replacement/relocation/clone history;
- sole-active-authority posture;
- no foreign or conflicting lineage claim.

If any of those are missing, ambiguous, stale, conflicting, unreadable, or
unfenced, the complete RW0-C2 command is no-write.

### Acceptance-only scope-unclaimed evaluation

A fresh `candidate_acceptance` is eligible only when the Coordinator proves:

1. exact admitted lineage and scope;
2. exact lineage continuity;
3. exact one-active-authority posture;
4. exhaustive guard-family read;
5. zero committed bootstrap-acceptance facts for the scope;
6. zero duplicate, alias, collision, partial, malformed, foreign, or unreadable
   acceptance families;
7. exact command-family route;
8. every ordinary RW0-C2 acceptance precondition.

Mere local absence receives no semantic credit.

Use one guard-specific no-write reason:

`bootstrap_acceptance_guard_conflict`

The previous target reason
`acceptance_latch_precondition_conflict` is superseded terminology, not a second
active reason owner.

A guard conflict never falls back to durable block.

### Nonaccept branches

`candidate_repair`, `attempt_selecting_replan`,
`program_terminal_reject`, and `post_execution_program_block` create no
bootstrap-acceptance fact and do not consume or replenish an allowance.

When lineage/admission/sole-active-authority posture is exact but only the
scope’s claimed/unclaimed status cannot be proven, a nonaccept branch may commit
only if:

- its authoritative derivation does not rely on an unclaimed-scope assertion;
- every other command, currentness, matrix, and branch precondition is exact;
- it creates no acceptance fact;
- it makes no projection claiming the scope is unclaimed.

No nonaccept branch may initialize, reset, repair, or renew guard truth.

## Immutable bootstrap-acceptance fact

For derived `candidate_acceptance` only, create at most one immutable fact per
admitted scope.

The logical fact binds, by semantic role:

- guard owner/profile identity;
- lineage and scope identities;
- admission-fact identity and digest;
- acceptance-fact identity;
- consuming `mutation_ref`;
- canonical command digest;
- exact durable acceptance-decision identity and digest;
- resulting program-version identity;
- committed head-postimage identity and digest;
- selected semantic attempt and candidate lineage;
- immutable decision-basis identity/digest;
- family-route identity;
- one transaction timestamp;
- canonical acceptance-fact digest.

The fact is an immutable member of the same atomic
decision/version/head/result/receipt family.

It has no mutable successor state.

No fact exists for the four nonaccept branches.

## Identity and digest DAG

Freeze an acyclic semantic dependency order:

1. standing-policy admission act;
2. immutable scope-admission fact;
3. command-local lineage/scope expectation and command digest;
4. decision and resulting program-version/head identities;
5. immutable bootstrap-acceptance fact;
6. result;
7. receipt;
8. replay projection and one whole-family recovery classification.

The acceptance fact may bind decision and committed version/head identities.

Result and receipt may bind the acceptance-fact identity and digest.

The acceptance fact must not require final result or receipt digests if that
creates a cycle.

No commit timestamp or postcommit projection may be needed to construct the
precommit command digest.

## Closed outcome taxonomy

Freeze exact treatment for:

- missing, duplicate, malformed, foreign, or unreadable admission fact;
- standing-policy admission substitution;
- lineage identity mismatch;
- continuity not established;
- multiple active authorities or ambiguous active authority;
- stale or wrong scope expectation;
- unreadable guard-family state;
- zero exact acceptance facts;
- one exact acceptance fact for the same complete command/family;
- one exact acceptance fact for a different command/family;
- duplicate acceptance facts;
- malformed or partial acceptance family;
- acceptance-fact identity collision;
- family-route collision;
- same `mutation_ref` with different command digest;
- exact same-command complete family;
- each nonaccept branch;
- reset, delete, reopen, renew, or replenish attempt;
- ES route transition.

Use existing owners where applicable:

- `mutation_ref_reuse_conflict`;
- `preassigned_identity_or_family_route_collision`;
- ordinary command/basis/current-head rejection owners;
- recovery `committed_exact`;
- recovery `definitely_not_committed`;
- recovery `unresolved`;
- `bootstrap_acceptance_guard_conflict`.

Do not create overlapping rejection owners.

Receipt-first replay and collision checks precede fresh guard eligibility
evaluation.

## Atomic family, exact replay, and recovery

### Fresh acceptance

The future guarded transaction will eventually:

1. complete command-local grammar and basis checks;
2. satisfy writer/session admission and fencing;
3. perform receipt-first mutation lookup and replay/collision checks;
4. derive the authoritative branch;
5. perform acceptance-only guard eligibility;
6. construct one decision/version/head/result/receipt/acceptance-fact family;
7. apply the whole family atomically;
8. invalidate read capability;
9. attempt commit exactly once;
10. use readback only to resolve uncertainty.

No second guard transaction exists.

### Exact replay

For the exact same `mutation_ref` and command digest:

- return the original complete family;
- include the original acceptance fact on acceptance;
- do not reevaluate branch or guard eligibility;
- do not require mutable heads to remain at historical postcommit values;
- do not create a second fact or timestamp.

Same mutation with another digest is `mutation_ref_reuse_conflict`.

### One whole-family recovery classifier

There is one classifier for decision, version/head, result, receipt, and, for
acceptance, the bootstrap-acceptance fact.

- `committed_exact`: every expected immutable member is present and exact;
- `definitely_not_committed`: the original command’s complete newly created
  family is exhaustively absent with no fragment, alias, collision, or read
  fault;
- `unresolved`: neither proposition is provable.

A competing complete acceptance by another command may establish that the
original command is `definitely_not_committed`, but separately makes a fresh
retry ineligible because the scope is already claimed.

Decision-without-acceptance-fact and acceptance-fact-without-decision are
`unresolved`.

Recovery never completes fragments, creates a fact, reevaluates the branch,
changes the scope, renews an allowance, creates a timestamp, or retries
automatically after `unresolved`.

## Terminal boundary

A later terminal fact may bind:

- the immutable bootstrap-acceptance fact identity and digest; and
- the exact committed decision/result/receipt family.

It cannot create the admission fact or acceptance fact and cannot consume,
reset, update, delete, renew, repair, or replenish guard truth.

Acceptance committed without a terminal fact means terminal recording is
absent, not that acceptance is uncommitted.

Unresolved acceptance family forbids terminal inference.

Terminal uncertainty leaves the acceptance fact permanent.

Do not design terminal storage, writer, receipt, or recovery.

## Later ES-routed operation

The guard applies only to the explicitly admitted bounded direct-local
bootstrap route.

Later ES-routed progression:

- is separately governed;
- does not consume this proof allowance;
- does not replenish or reset it;
- does not use the bootstrap acceptance fact as general ES admission or runtime
  authority.

ES readiness, a new grant, a new policy epoch, a restored database, or a new
machine creates no new direct-local allowance.

## B1 legacy compatibility edge

Production source remains unchanged.

The existing private `RW0TerminalOutcomeV1` fields:

- `latch_postimage_ref`
- `latch_postimage_digest`

remain exact v1 representation names with unchanged:

- schema ID;
- field order;
- nullability;
- canonical bytes;
- digest domain;
- budgets;
- source validation behavior.

Amend `.docs/rw0-b1-pure-phase-values.md` and
`tests/test_rw0_b1_boundaries.py` to freeze all of the following:

1. The names are a bounded legacy compatibility edge.
2. Their replacement-target binding obligation is the immutable
   bootstrap-acceptance fact identity/digest.
3. The pair implies no mutable preimage, available/consumed state, transition,
   revision, or separate classifier.
4. Current B1 code validates pair presence/absence and supplied-value coherence
   only.
5. Current B1 code does not prove lineage scope, standing-policy admission,
   uniqueness, commitment, atomic family membership, or recovery truth.
6. No new target implementation may consume the pair as durable guard proof
   until a separately accepted safe-value compatibility/versioning decision.
7. B1 phase-value, relation, vector, schema, field, domain, and budget tests stay
   unchanged.

Do not claim unchanged target meaning. Record semantic supersession explicitly.

A future rename/removal, new field grammar, or B1 proof responsibility requires
a separate private safe-value/versioning tranche.

## Four-document normalized target projection

Update the identical current-target body in all four documents:

- `.docs/autonomous-software-development-operating-model.md`
- `.docs/worker-execution-boundary.md`
- `.docs/authority-boundaries.md`
- `.docs/durable-state-model.md`

The bodies must remain exact normalized equivalents with the same owner
inventory, heading ancestry, markers, and visibility rules.

Replace mutable-latch consumption and terminal-postimage wording with the
immutable guard target.

Retain accurate current implementation absence statements.

State that physical values, storage, provisioning, readers, writers, migration
treatment, and runtime remain future.

## Other governing projections

### `AGENTS.md`

Make the minimum durable repository-guidance amendment required to:

- route the one-shot direct-local bootstrap ceiling to the new guard owner;
- bind scope to admitted Coordinator authority lineage;
- classify mutable-latch target language as superseded;
- retain current implementation absence paragraphs accurately.

Do not add detailed procedure or historical narrative.

### `README.md`

Amend only live product/status projection:

- lineage-scoped direct-local allowance;
- no infrastructure-derived replenishment;
- later ES route is separate and non-replenishing;
- no current guard implementation.

Retain accurate absence statements.

### `.docs/architecture.md`

Route five-branch semantics to the amended C2 owner and bootstrap
lineage/admission/acceptance semantics to the new guard owner.

State that no physical storage, migration, provisioner, writer, reader, public
export, or runtime path exists.

### `.docs/software-development-progression-boundary.md`

Amend deferred target ownership from mutable latch to immutable guard. Preserve
C1 exclusion, progression authority, and nonimplementation boundaries.

### `.docs/c2a-first-slice-semantic-protocol-contract.md`

Preserve the one-shot expansion gate and migration-review requirement.

Route enforcement to immutable admitted-scope and acceptance facts.

Keep markers, reports, adapter memory, chat, Bridge ledgers, and capsules
non-authoritative.

### `.docs/c2b3-program-initialization.md`

Preserve historical planning/genesis content and add a bounded current
projection. Do not claim a current scope provisioner.

### `.docs/rw0-b2-wire-protocol.md`

Wire remains pure representation/classification. It owns no admission, guard,
B1 schema, acceptance, durable decision, replay, recovery, or runtime truth.

### `.docs/rw0-b2-capability.md`

Capability remains supplied declaration/observation/qualification. It owns no
durable guard or acceptance authority.

Deliberately supersede only the protected P08/P11/P12/P13 document identities
required by the governing reset. Do not refresh unrelated identities.

## New guard-owner representation

The new guard document is the sole semantic owner for the bootstrap guard.

Use:

- concise normative prose;
- closed human-readable tables;
- one compact duplicate-key-free canonical JSON block only for finite
  contract-test inventories.

At minimum include exact finite inventories for:

- authority roles;
- lineage and scope rules;
- admission-fact roles;
- command-facing relation roles;
- acceptance-fact roles;
- branch effects;
- no-write/collision/replay/recovery taxonomy;
- terminal boundary;
- ES boundary;
- B1 compatibility nonproof;
- implementation nonclaims.

Human tables and machine data must be exact equivalent representations.

Do not encode SQL, table/column/index names, migration IDs/checksums, source
symbols, or full future value schemas.

Do not add decorative machine fields unused by tests.

## Contract-test amendment requirements

### Amended C2 durable-decision verifier

Preserve all accepted reducer, source-evidence, matrix, currentness, branch,
model-nonauthority, retained-evidence, hostile, and structural coverage.

Replace mutable-latch fixed expectations, prose/machine data, interpreter,
trace, branch effects, replay/recovery, and terminal assertions with the
immutable guard dependency.

Require:

- admitted-lineage relation on every applicable command;
- scope-unclaimed evaluation only for acceptance;
- `bootstrap_acceptance_guard_conflict` is no-write, never block;
- acceptance has exactly one acceptance-fact family member;
- four nonaccept branches have none;
- exact replay returns the same fact without another action;
- one whole-family classifier includes the fact;
- terminal binds without mutation;
- the new guard owner is the sole owner of guard tables.

Do not create a second reducer or source implementation in tests.

### New bootstrap-guard verifier

Create:

`tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py`

Keep it finite, document-driven, and independent.

It must causally verify:

1. sole guard owner path and two-owner split;
2. exact Option A lineage policy;
3. scope is lineage, not deployment/machine/database/repository/program/grant;
4. explicit standing-policy admission;
5. one active authority per lineage;
6. restore/rollback/clone/backup/relocation non-replenishment;
7. continuity uncertainty fail-closed;
8. local absence is insufficient;
9. immutable admission-fact inventory;
10. immutable acceptance-fact inventory;
11. one acceptance across two unrelated programs in one scope;
12. independently admitted lineages may each have one scope;
13. separate databases or machines do not imply independent lineages;
14. all five branch effects;
15. acceptance fact is in the durable decision family;
16. no separate mutable latch, state, revision, postimage, replay, receipt, or
    classifier;
17. command-facing relation and prohibited authority fields;
18. acyclic identity/digest graph;
19. closed outcome taxonomy;
20. receipt-first exact replay;
21. same mutation/different digest conflict;
22. competing winner versus original-command `definitely_not_committed`;
23. whole-family `committed_exact`, `definitely_not_committed`, `unresolved`;
24. partial decision/fact families unresolved;
25. terminal binding and nonmutation;
26. later ES operation non-replenishing and separately governed;
27. B1 legacy pair is compatibility/nonproof only;
28. physical representation remains unselected;
29. source, migration `0005`, writer, reader, provisioner, caller, public,
    runtime, RW0-D/E, and ES nonimplementation;
30. cross-document human/machine equivalence;
31. no competing semantic owner.

Required causal hostiles include:

- second acceptance from another program in the same scope;
- scope inferred from a machine, process, database, file, repository, grant, or
  restore;
- independent lineage without standing-policy admission;
- cloned/restored database treated as fresh;
- local absence treated as eligibility without continuity proof;
- two active authorities for one lineage;
- lineage/admission substitution;
- caller-authored admission or acceptance fact;
- model-authored scope or branch;
- mutable available/consumed latch reintroduced;
- latch revision or preassigned consumed-postimage reintroduced;
- reset, renewal, deletion, or second allowance;
- nonaccept branch creating a fact;
- guard conflict converted to durable block;
- replay creating a second fact or timestamp;
- partial family classified committed;
- competing winner treated as retry permission;
- terminal creating/resetting/deleting the fact;
- ES route replenishing allowance;
- digest cycle;
- duplicate JSON key;
- prose-only or machine-only drift;
- B1 legacy pair treated as current durable guard proof;
- implementation, migration, provisioner, or runtime overclaim.

Each hostile must fail at an exact intended boundary.

Fixed expectations, parsed machine data, human prose, interpreter results, and
hostile expectations must remain independently authored. Do not allow one
mutable table to author both expected and observed truth.

### Four-document map tests

Amend:

- `tests/test_architecture_contracts.py`
- `tests/test_rw0_remote_contact_phase_entry_contract.py`
- `tests/test_remote_worker_pre_execution_planning_contract.py`

Preserve:

- exact four-document inventory;
- structural owner/visibility controls;
- heading ancestry;
- normalized equality;
- duplicate/missing/misplaced body rejection.

Replace all independent literal latch pins with exact immutable-guard pins.

### Remote-phase tests

Replace consumption/postimage target controls with immutable admission/fact
controls.

Preserve cancellation decision/effect ordering, uncertainty stops, no
successor/Git/publication behavior, current implementation nonclaims, and
historical-prefix protections.

### C2A support/tests

Amend `tests/c2a_contract_support.py` current target stop text.

Preserve direct ordered-list and deletion/weakening protections.

`tests/test_c2a_nonimplementation.py` remains unchanged and must continue to
pass.

### B1 tests

Amend only `tests/test_rw0_b1_boundaries.py`:

- route current target ownership to the new guard owner;
- assert the two legacy field names are compatibility names;
- assert current B1 is representation/coherence only and nonproof;
- assert source/schema/field/domain/budget bytes remain unchanged;
- reject any new current consumer or implementation claim.

Do not modify B1 phase-value, relation, vector, schema, or budget tests.

### B2/progression tests

Amend:

- `tests/test_software_development_progression_boundary.py`
- `tests/test_rw0_b2_capability_boundaries.py`

Preserve pure/non-authorizing boundaries.

For capability protections, explicitly review and supersede only P08/P11/P12/P13
as required by the changed governing documents. Add semantic assertions for
their replacements; do not merely update hashes.

Wire and cancellation-control test modules remain unchanged and must pass.

### Historical C2B tests

Amend only `tests/test_c2b0_durable_state_contract.py` to:

- preserve every historical literal/proof;
- recognize the append-only current successor;
- classify historical latch representation as precursor evidence, not current
  target authority;
- verify no reset/reuse ceiling remains;
- verify current semantics route to the guard owner;
- verify old SQL/migration/table choices remain non-operative.

`tests/test_c2b3_program_initialization_contract.py` remains unchanged and must
pass.

## Nonimplementation and structural guards

The reset must prove:

- zero production-source diff;
- migrations remain exactly 0001–0004;
- migration `0005` is absent;
- no guard/admission/acceptance source module;
- no provisioner;
- no durable decision writer;
- no reader/recovery implementation;
- no `StateStore` or `WriterSession` method;
- no package export;
- no production caller;
- no public API;
- no runtime activation;
- no RW0-D/E or Execution Substrate change.

Do not add a complete source-manifest hash barrier to the new guard test.
Repository provenance and existing structural guards own exact source
preservation. Add only focused semantic absence checks needed for this reset.

## Validation

Run all pytest commands serially with:

```text
PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=.:src
-p no:cacheprovider
--basetemp=<external path>
```

Do not run tests concurrently.

Use a clean local-only external clone for the full suite if the pre-existing
live ignored cache would interfere. Do not move or modify the live cache.

### Targeted governing reset

Run exactly:

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_architecture_contracts.py \
  tests/test_rw0_remote_contact_phase_entry_contract.py \
  tests/test_remote_worker_pre_execution_planning_contract.py \
  tests/test_software_development_progression_boundary.py \
  tests/test_autonomous_software_development_operating_model.py \
  tests/test_c2a_first_slice_semantic_protocol_contract.py \
  tests/test_c2a_nonimplementation.py \
  tests/test_rw0_b1_phase_values.py \
  tests/test_rw0_b1_vectors.py \
  tests/test_rw0_b1_relations.py \
  tests/test_rw0_b1_boundaries.py \
  tests/test_rw0_b2_wire_boundaries.py \
  tests/test_rw0_b2_capability_boundaries.py \
  tests/test_rw0_b2_wire_cancellation_control_boundaries.py \
  tests/test_c2b0_durable_state_contract.py \
  tests/test_rw0_c2_durable_progression_decision_semantic_contract.py \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

### Broader regression groups

Run:

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_c2a*.py \
  tests/test_worker_execution_semantic*.py \
  tests/test_rw0_b1*.py \
  tests/test_rw0_b2*.py \
  tests/test_rw0_c1*.py \
  tests/test_post_execution_pure_owner*.py \
  tests/test_c2b2*.py \
  tests/test_c2b3*.py \
  tests/test_section41*.py \
  tests/test_runtime_non_authority.py \
  tests/test_state_store_contract.py \
  tests/test_b2a_writer_session_contract.py \
  tests/test_sqlite*.py
```

### Full repository

Run:

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external>
```

Also require:

```sh
git diff --check
```

For both new files run whitespace checks against `/dev/null`.

Check all 28 paths for:

- regular non-symlink type;
- mode `0644`;
- UTF-8;
- no CR bytes;
- no trailing whitespace;
- final newline present.

Verify:

- C2B final bytes begin with the exact complete opening bytes;
- C2B3 historical prefix remains exact except for the bounded current projection
  location selected by its existing structure;
- source and migration trees equal HEAD;
- all non-ceiling paths equal HEAD;
- migration catalog and SQL hashes remain unchanged;
- public/package/StateStore/WriterSession inventories remain unchanged;
- no database, journal, WAL/SHM, cache, bytecode, build, archive, lock, or
  generated report artifact was created by the engagement.

Remove only engagement-created temporary data.

## External hostile validation

In disposable external copies, independently prove at least these mutants fail
at their intended boundaries:

1. mutable-latch sentence restored in one of the four normalized bodies;
2. four-document body drift in only one owner;
3. standalone mutable-latch requirements restored in C2 human prose;
4. standalone mutable-latch requirements restored only in C2 machine data;
5. lineage scope replaced by database identity;
6. clone/restore treated as a fresh allowance;
7. standing-policy admission omitted;
8. two active authorities treated as valid;
9. local row absence treated as unclaimed proof;
10. second program accepts under the same scope;
11. nonaccept branch creates an acceptance fact;
12. guard conflict becomes durable block;
13. replay creates another fact or timestamp;
14. partial family becomes `committed_exact`;
15. competing winner permits retry;
16. terminal creates, resets, or deletes guard truth;
17. ES route replenishes allowance;
18. B1 legacy pair treated as current durable guard proof;
19. P08/P11/P12/P13 hashes refreshed without replacement semantic assertions;
20. historical C2B mutable representation promoted back to current authority;
21. duplicate JSON key;
22. prose-only/machine-only guard drift;
23. source, migration `0005`, writer, provisioner, reader, caller, public, or
    runtime implementation claim.

Each mutant must retain expected test collection and fail at an exact intended
semantic boundary, not a generic assertion, syntax error, or parameter-count
shrinkage.

## Provenance and closeout

Before editing:

1. capture exact opening Git coordinates;
2. capture opening status;
3. capture per-path Git blob/mode/size/SHA for all 26 existing ceiling paths;
4. capture the complete opening bytes/digest for C2B and the preserved C2B3
   historical prefix;
5. capture a safe repository-relative ignored-cache inventory without reading
   bytecode as executable code.

At closeout:

- final status must be exactly 26 tracked modifications and two untracked new
  regular files;
- zero staged and unmerged paths;
- no additional path;
- all 28 modes `0644`;
- report byte size and SHA-256 for all 28 paths;
- construct a deterministic complete binary patch:
  - tracked paths from `git diff --binary --full-index --no-ext-diff
    --no-textconv HEAD -- <path>`;
  - new paths from `git diff --no-index --binary --full-index --no-ext-diff
    --no-textconv -- /dev/null <path>`;
  - concatenate in the exact 28-path order above;
- report complete patch byte size and SHA-256;
- calculate the complete receipt twice using two independent implementations
  and require byte-identical canonical output;
- verify opening/closing ignored-cache equality;
- report every validation command and observed result;
- state all skipped validation and unresolved seams.

Do not generate an external manifest or report. Include the complete receipt
table inline.

## Stop conditions

Stop, restore the exact opening worktree, and return the blocking token if:

- baseline or cleanliness differs;
- exact 28-path closure is insufficient;
- source or migration changes are required;
- B1 compatibility cannot remain truthful without source/schema versioning;
- the two-owner split creates overlapping replay/recovery authority;
- current historical bytes cannot be preserved as required;
- validation exposes a governing contradiction that cannot be repaired inside
  the ceiling;
- any required protected path outside the ceiling must change.

Do not widen the tranche.

## Success token

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_WRITTEN_VALIDATED_READY_FOR_INDEPENDENT_AUDIT`

Success authorizes only a fresh independent read-only audit of the exact
28-path candidate.

## Blocking token

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_BLOCKED`

## Required non-actions

State:

```text
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
SCHEMAS_NOT_MODIFIED
NON_CEILING_DOCS_NOT_MODIFIED
NON_CEILING_TESTS_NOT_MODIFIED
OPERATOR_OR_PRODUCT_DATABASE_NOT_OPENED_OR_MUTATED
LIVE_IGNORED_CACHE_NOT_MOVED_OR_MODIFIED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
BOOTSTRAP_SCOPE_PROVISIONER_NOT_IMPLEMENTED
BOOTSTRAP_ACCEPTANCE_GUARD_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
REMOTE_CONTACT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
MERGE_NOT_PERFORMED
SUBAGENTS_NOT_SPAWNED
EXTERNAL_ARTIFACTS_NOT_GENERATED
```

## Inline closeout report structure

Return:

1. primary outcome token;
2. visible model/reasoning setting;
3. opening and closing Git coordinates;
4. exact 28-path receipt table;
5. semantic-owner and authority split;
6. four-document normalization result;
7. B1 compatibility treatment;
8. historical C2B/C2B3 preservation;
9. C2/C2A/B2/progression amendments;
10. new guard contract and verifier summary;
11. hostile/mutant results;
12. targeted, broad, and full validation;
13. protected source/migration/public-surface proof;
14. binary-patch and double-receipt provenance;
15. cache/artifact posture;
16. unresolved future safe-value/physical seams;
17. all non-actions.
