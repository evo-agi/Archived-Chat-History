# Governed Execution Coordinator — RW0-C2 Bootstrap Guard Governing Reset V4 Code-Object Causality Repair

## Role and objective

Resume the original governing-reset implementation conversation after the
operator changes the parent permission posture to workspace-write.

Use the highest available Codex reasoning setting. Record exactly what the
interface visibly shows for:

- model name;
- reasoning setting or effort.

Do not infer hidden configuration. Record `not visible` when necessary.

The parent is the sole repository writer. Do not spawn subagents.

Repair the exact uncommitted 28-path RW0-C2 bootstrap acceptance-guard
governing-reset V3 candidate after its fresh independent audit returned:

`AUDIT_PROVENANCE_MISMATCH`

The audit established all of the following:

- the committed baseline and all 28 candidate path receipts were exact;
- the complete patch and canonical receipt reproduced exactly;
- no tracked candidate file was changed by the audit;
- the audit itself created 12 ignored `.pyc` files in the live checkout through
  delegated imports without bytecode suppression;
- a prebound tuple containing the original model and replay callables bypassed
  the candidate reference-patching probe;
- a coupled change to program B's admission and the verifier's expectation
  bypassed the cross-program same-admission proof;
- removal of manual list restoration was not caught by the focused suite;
- the audit did not complete the full, 17-module, or broader validation runs;
- the previous report's “76 external mutants” wording was not supportable from
  repository evidence: most were permanent internal negative controls that
  pass by catching exact exceptions.

This engagement has two tightly bounded effects:

1. restore the exact pre-audit ignored-cache baseline by removing only the
   twelve audit-created cache files and any now-empty audit-created
   `tests/__pycache__` directory;
2. repair exactly one untracked verifier file so actual code-object entry,
   probe restoration, and shared-admission scenario integrity are causally
   protected.

Do not modify normative documents, the C2 verifier, production source, schemas,
migrations, readers, writers, transactions, public APIs, runtime behavior,
RW0-D/E, or Execution Substrate behavior.

Return one substantive inline closeout report. Do not create or attach an
external report, manifest, package, patch, freeze artifact, or other
client-visible file.

## Repository and exact committed baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed baseline beneath the candidate:

- branch: `trunk_dev`
- HEAD: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- tree: `42cc0757b3d9604dfe7fdbda158074b8b48dac7b`
- sole parent: `db16de711986ae40a2bb848ed00cdddd3145ee02`
- subject: `docs: freeze RW0-C durable decision branch contract`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- zero staged paths
- zero unmerged paths
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Do not fetch or contact remotes.

## Exact opening V3 candidate

Require exactly 26 tracked modifications and two untracked files and no other
tracked or untracked difference from HEAD.

All 28 paths must be regular, non-symlink mode-`0644` files, valid UTF-8,
without BOM or CR bytes, without trailing whitespace, and with exactly one
final newline.

| # | Status | Path | Bytes | SHA-256 |
|---:|---|---|---:|---|
| 1 | `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 70,858 | `4fc2b7f9d5810105c28a7ce11abe85d08a48f915a87b088ae86e5520aa2142e2` |
| 2 | `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | 57,192 | `2c0c9565f7fb4ae79eca998080f3b70734f9a4fd1e555132daf9b94daab1dc97` |
| 3 | `M` | `.docs/c2a-first-slice-semantic-protocol-contract.md` | 103,413 | `a690441d046d147cf11a068e07a894858e3d32476e19fef84a9bb26e6e6f0d99` |
| 4 | `M` | `.docs/c2b-durable-development-state.md` | 1,889,329 | `6115a29d5bbfb8ffb17404e9acbefcb8edc958554683afa3538e9d959e184ef8` |
| 5 | `M` | `AGENTS.md` | 61,466 | `001595cdec75b176abbfb99b91b2b06c45f2f2ff1a28c704ded7054c27c7e74e` |
| 6 | `M` | `README.md` | 45,849 | `b66fb689d9f0849eee1d62f12dda93d83dcc9f4cce2fa008696878b44256ad1a` |
| 7 | `M` | `.docs/architecture.md` | 43,007 | `60a884471d655ee6eddad8c405aa218eab492e3c610b101c0736fc9f2546288f` |
| 8 | `M` | `.docs/autonomous-software-development-operating-model.md` | 37,829 | `115ed6c16141f821147f640131bed904526cee914dbec6951f3667b0da100f05` |
| 9 | `M` | `.docs/authority-boundaries.md` | 34,686 | `69d524c839a2195cf0b5840be424c021305825fd0db1d85c76ed28b99c1bf055` |
| 10 | `M` | `.docs/durable-state-model.md` | 40,564 | `e14a421698f0735fa098fe6ce1063b64d07e1c212fd6b60755e1068c9caf5955` |
| 11 | `M` | `.docs/worker-execution-boundary.md` | 30,920 | `6f7d2f7855fcbdecc757af4dde7a7bb091ab1e8c60057a2fefe407f74de4055f` |
| 12 | `M` | `.docs/software-development-progression-boundary.md` | 28,654 | `b8761655ee42512c0e77ab8c774c2b2d3d8f9ac36a9bd0c74872ad4bf2994419` |
| 13 | `M` | `.docs/c2b3-program-initialization.md` | 27,687 | `8e9c2c6f49551b28d95de28f6d7b071c89dd0ea155ce7d7a6e21e8d88e73d1f7` |
| 14 | `M` | `.docs/rw0-b2-wire-protocol.md` | 24,346 | `7f977a5a60fd66c69464190731e09611ca24854313e145b73cc73f564776477b` |
| 15 | `M` | `.docs/rw0-b2-capability.md` | 17,753 | `171341fc60cbe762403f1e64676ca35c9ea2f778a10d0fc66d668f1c84dc884c` |
| 16 | `M` | `.docs/rw0-b1-pure-phase-values.md` | 33,032 | `8bccdaa31fa66821b73c136936c12ef001157209c72b9991839905c1a8e0e053` |
| 17 | `M` | `tests/test_architecture_contracts.py` | 100,410 | `555ac490738d12075d3908ec2ddfd090fdbb32d8a6fd53d1b3136d24485e1169` |
| 18 | `M` | `tests/test_rw0_remote_contact_phase_entry_contract.py` | 173,524 | `42d6d265c0a9ba5047aa37ec3a4daae30847d486d39ead6374685b451a1d445c` |
| 19 | `M` | `tests/test_remote_worker_pre_execution_planning_contract.py` | 913,152 | `92b0f3917f0572492357447211a1f0f0cc7f8edb7e8b5f18233ed80397879b29` |
| 20 | `M` | `tests/test_software_development_progression_boundary.py` | 42,899 | `bd9b10f62e3bbfb3dc5fc845958fe0087363a0afa0b80649853faac85235c7a3` |
| 21 | `M` | `tests/test_autonomous_software_development_operating_model.py` | 72,904 | `e9a77edb1f99b181c612e52c4a7cfee814ac3f0df4d974e7c3a0756aec6da8df` |
| 22 | `M` | `tests/c2a_contract_support.py` | 154,372 | `58be92ddffae6f4b901ae3632521481ab8d9ce0e02a819ef9421408d08eedd85` |
| 23 | `M` | `tests/test_rw0_b1_boundaries.py` | 38,321 | `bd52384897f8f7a7129023c693ef67b1ff453a006723438dfa4f06df08e4121f` |
| 24 | `M` | `tests/test_rw0_b2_capability_boundaries.py` | 45,708 | `4e4824b5974778cbef147e7f5a5684de34e5006464156cbb7be2958c33ce1a84` |
| 25 | `M` | `tests/test_c2b0_durable_state_contract.py` | 884,862 | `45a539a810deb8884c3f0158887a0d4fd06778a59e833c6b9d89365990ed62fd` |
| 26 | `M` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | 249,444 | `480bd282646304c70116f69faecabc1fea94d83ef54ec77b780a869ace5431c4` |
| 27 | `??` | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 25,151 | `bf65ba7f04411bb6e6febec2285b33721eb2ff895e2c60aee97878b1fa7c9b46` |
| 28 | `??` | `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | 89,437 | `e6555cc5155bfbaa1031de43dcfc6b3534f60457d5a34b72b245d6f769a8d795` |

Required opening complete patch, assembled twice in the table order:

- bytes: `308,892`
- SHA-256:
  `1d875ae83857db8fc4dd4c142800ced5682ff03c384c3e95430c5e33b48ea682`

Required opening canonical receipt:

- bytes: `5,593`
- SHA-256:
  `a59f7c53ae4cbbdf33d7c5b69bd7ece58f2ada796c0195536bec23a0b687f8ae`

Use the existing fully specified compact sorted-key JSON receipt grammar with
one final LF.

Stop before any cleanup or edit on candidate or baseline mismatch:

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_V4_REPAIR_BLOCKED`

## Phase A — exact audit-residue cleanup

This cleanup is explicitly authorized because the immediately preceding audit
created ignored bytecode in the live checkout and then left it untouched.

### Accepted pre-cleanup states

Proceed only if the live ignored cache is exactly one of:

#### Already restored

- member count: `37`
- canonical bytes: `8,897`
- SHA-256:
  `3902e30eb9f5e229bb61b46d3b77a001f6b86371a717f9b3c324407d8818ebec`

#### Exact audit residue present

- member count: `49`
- canonical bytes: `11,813`
- SHA-256:
  `50ea875055567f83f7885dcc8d0031176f6d56f22c7f3987ba1c6e7507bf84b4`
- the original 37 members equal the restored baseline by path, type, mode,
  size, `mtime_ns`, and SHA-256;
- the only additional members are exactly:

```text
src/ge_nwp_coordinator/__pycache__/_finite_backlog_risk_source_adapter.cpython-313.pyc
src/ge_nwp_coordinator/__pycache__/_post_execution_evidence_values.cpython-313.pyc
src/ge_nwp_coordinator/__pycache__/_post_execution_policy_values.cpython-313.pyc
src/ge_nwp_coordinator/__pycache__/_rw0_c_decision_input_values.cpython-313.pyc
src/ge_nwp_coordinator/__pycache__/_section41_post_execution_proposal_family_projection.cpython-313.pyc
src/ge_nwp_coordinator/__pycache__/_section41_post_execution_role_resolution.cpython-313.pyc
tests/__pycache__/c2a_contract_support.cpython-313.pyc
tests/__pycache__/test_post_execution_pure_owner_relations.cpython-313.pyc
tests/__pycache__/test_post_execution_pure_owner_values.cpython-313.pyc
tests/__pycache__/test_rw0_b1_vectors.cpython-313.pyc
tests/__pycache__/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.cpython-313.pyc
tests/__pycache__/test_rw0_c2_durable_progression_decision_semantic_contract.cpython-313.pyc
```

For every additional file require:

- regular non-symlink type;
- filename matches the exact path above;
- corresponding `.py` source exists;
- it is ignored by Git;
- it is not one of the original 37 members.

### Authorized cleanup effect

If the 49-member state is exact:

1. delete only the twelve listed regular `.pyc` files;
2. remove `tests/__pycache__` only if it is empty and did not exist in the
   restored 37-member baseline;
3. do not remove or rewrite `src/ge_nwp_coordinator/__pycache__`;
4. do not change any original cache member;
5. do not use broad cache-cleaning commands.

After cleanup require exactly:

- member count: `37`
- canonical bytes: `8,897`
- SHA-256:
  `3902e30eb9f5e229bb61b46d3b77a001f6b86371a717f9b3c324407d8818ebec`

The canonical cache grammar is:

- path-sorted root JSON array;
- exact keys `path`, `type`, `mode`, `size`, `mtime_ns`, `sha256`;
- lexicographically sorted object keys;
- compact UTF-8 JSON;
- `ensure_ascii=false`;
- one final LF.

If neither accepted pre-cleanup state is exact, stop without deleting anything.

After this phase, do not import repository modules from the live checkout.
All execution must occur in external local-only clones with
`PYTHONDONTWRITEBYTECODE=1`.

## Exact candidate mutation ceiling

Only this path may change from its opening V3 bytes:

`tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py`

The other 27 candidate paths must remain byte-identical.

All source, migration, schema, package-export, StateStore, WriterSession,
transaction, reader, writer, public, runtime, configuration, and example paths
must remain byte-identical to HEAD.

Migration `0005` must remain absent.

If this one-file ceiling is insufficient, restore the exact opening verifier
bytes and stop. Do not widen the tranche.

## Accepted semantics that must not be reopened

Preserve exactly:

- one explicitly standing-policy-admitted Coordinator authority lineage per
  bootstrap scope;
- operational realizations do not mint lineages or allowances;
- one active authority per lineage;
- continuity and sole-active-authority ambiguity fail closed;
- immutable admission and acceptance facts;
- one productive direct-local acceptance per admitted scope;
- permanent non-replenishment;
- acceptance fact integrated into the durable decision family;
- no mutable available/consumed latch subsystem;
- no acceptance fact on nonaccept branches;
- guard conflict is no-write, never durable block;
- receipt-first exact replay;
- one whole-family recovery classifier;
- partial families are unresolved;
- a competing winner makes fresh retry ineligible;
- terminal is later and non-mutating;
- ES routing is separate and non-replenishing;
- B1 legacy fields remain compatibility/nonproof only;
- no production implementation exists.

This repair changes verifier observation, restoration tests, and scenario
integrity only.

## Finding H1 — prebound callables bypass reference patching

The prior verifier patches known references, but a tuple containing the original
model and replay callables can be captured before patching and invoked later.
Because the tuple is immutable and prebound, the current patch scan misses it.

### Authoritative code-object entry observer

Add a generic, test-local code-object entry observer that is independent of
reference replacement.

Use `sys.setprofile`, `sys.settrace`, or an equivalently direct Python
frame-entry mechanism to observe `call` events by exact target `__code__`
identity.

The observer must:

- bind exact target code objects for:
  - C2 `_model_consistency_phase`;
  - guard `_receipt_replay_check`;
  - C2 `_replay_family`;
  - C2 pre-model reduction;
  - acceptance guard eligibility;
- count entry regardless of defining-module global, imported alias, tuple,
  list, dict, default, keyword default, closure, registry, partial, wrapper,
  dynamic `getattr`, or discarded return value;
- record actual entry before function body effects;
- preserve and chain any pre-existing profile/trace callback safely;
- restore `sys` and `threading` profile/trace state in `finally`;
- support nesting or explicitly reject nested use at a fixed boundary;
- isolate state across parameterized tests;
- expose exact event order and counts;
- never treat returned trace markers as proof of non-entry.

The code-object observer is the authoritative actual-entry oracle. The existing
reference-patching probe may remain as a structural defense, but its counts must
agree with code-object observations on every live case.

### Required baseline cases

Independently assert actual code-object entry for:

- exact replay;
- mutation-ref reuse conflict;
- family-route collision;
- unfenced caller;
- invalid writer/session admission;
- lineage mismatch;
- missing admission;
- foreign admission;
- multiple active authorities;
- claimed scope;
- unresolved scope;
- eligible acceptance with recognized recommendation;
- eligible acceptance with out-of-vocabulary recommendation;
- all four valid nonaccept branches.

Require exact owner-derived counts and exact stage ordering.

### Required hidden-call variants

Permanent hostiles or external mutants must include:

1. model call from a prebound tuple before guard eligibility;
2. replay call from a prebound tuple before fencing;
3. tuple-held call with discarded return;
4. tuple-held call with removed returned trace marker;
5. tuple-held early call followed by the normal later call;
6. `functools.partial` or equivalent bound wrapper around the original target;
7. dynamic `getattr` resolution of the defining-module target;
8. a new function object built from the same target code object where safely
   constructible;
9. duplicate replay entry with the first result discarded;
10. exact replay followed by fresh model or guard evaluation.

Each negative must retain collection and fail at an exact actual-entry count or
ordering boundary.

## Finding H2 — shared admission can be changed with its expectation

The cross-program ceiling requires two commands to compete under one immutable
admission fact. The current behavior ledger keys only lineage and scope, while
the scenario's admission expectation can be changed together with program B's
admission.

### Canonical guard-posture fixture

Create one independently authored immutable guard-posture fixture containing:

- lineage identity;
- scope identity;
- admission-fact identity;
- admission-fact digest;
- active-authority posture.

The scenario builder must consume that posture. It must not author its own
expected relationship.

### Generic same-admission invariant

Before behavioral execution, validate each command against the posture and
validate the pair generically:

- same lineage;
- same scope;
- same admission-fact identity;
- same admission-fact digest;
- same admitted applicability;
- distinct program identities;
- program-specific head/basis coordinates;
- distinct command digest and mutation reference;
- distinct attempt/candidate lineage where declared.

The equality of admission coordinates must be derived from the actual two
command objects and the separate posture object, not from a mutable expected
boolean or label.

Add exact boundaries, including:

```text
guard:cross_program_scenario:shared_admission:ref
guard:cross_program_scenario:shared_admission:digest
guard:cross_program_scenario:command_admission_binding:A
guard:cross_program_scenario:command_admission_binding:B
```

### Behavioral posture binding

The finite behavioral scenario must validate each command's admission against
the guard posture before checking or updating the claimed-scope ledger.

The ledger key must include the immutable admission identity/digest, or an exact
pre-ledger binding must make omission impossible. Do not let a foreign
admission be rejected only because lineage/scope happens to be claimed.

### Required scenario mutants

Include:

1. B admission ref changed while expectation changes with it;
2. B admission digest changed while expectation changes with it;
3. B admission ref and digest changed together;
4. A and B admissions changed to different foreign facts;
5. B lineage/scope unchanged but admission foreign;
6. builder and relationship expectation mutated together;
7. ledger key or pre-ledger validation omits admission;
8. B program ref collapsed to A;
9. B head/basis collapsed to A;
10. command/mutation identity reused;
11. B assigned a different scope;
12. same-program second attempt substituted.

The first seven must fail at admission-binding boundaries, independent of the
one-shot ledger outcome.

## Finding M1 — list restoration path lacks permanent coverage

The existing reference-patching probe currently restores target-bearing lists,
but removal of that restoration survived because no test supplied such a list.

Add direct permanent tests that:

- provide a target-bearing list to the probe;
- verify the list element is patched during the probe;
- force normal delegation;
- force a wrapped-target exception;
- force an exception in the caller body;
- verify exact identity restoration after every path;
- verify no wrapper remains after context exit;
- verify a second probe starts from the original identity;
- verify nested-probe behavior, or reject nesting at one exact boundary;
- separately preserve dict/default/closure restoration coverage.

Add a structural integrity test requiring a list restoration path, but do not
rely on AST inspection alone.

Required mutant:

- remove only list restoration while retaining list patching and all other
  restoration.

It must retain collection and fail at:

`guard:actual_entry:restoration:list`

## Evidence-language correction

Do not claim that historical external mutant sets were reproduced unless the
engagement actually creates and executes those transformed external copies.

Separate closeout evidence into:

1. permanent internal negative controls that pass by catching exact exceptions;
2. external transformed mutants actually executed in disposable copies;
3. independent ordinary validation.

For every external mutant report:

- exact transformation;
- unchanged collection count;
- exact failing node;
- exact boundary;
- confirmation that failure was not syntax/import/collection shrinkage.

Do not describe internal caught-exception nodes as externally failed pytest
mutants.

## Structural and anti-shortcut requirements

Require permanent checks that:

- the code-object observer binds exact target `__code__` objects;
- actual counts are asserted after invocation;
- prebound tuple and partial references are exercised;
- profile/trace callbacks are restored after normal and exceptional exit;
- candidate patch-probe counts are reconciled with code-object counts;
- scenario commands bind to a third, independent posture object;
- admission equality is checked from actual coordinates;
- behavioral execution validates admission before the ledger;
- list restoration is dynamically exercised;
- no helper returns a self-authored boolean accepted without fixed comparison;
- no line-number freeze substitutes for semantic protection;
- no generic `pytest.raises(AssertionError)` receives credit without an exact
  boundary.

Do not create a second reducer, replay owner, recovery classifier, or physical
guard model.

## External mutant battery

At minimum create and execute external transformed copies for:

### Code-object causality

1. prebound tuple early model call;
2. prebound tuple early replay call;
3. tuple early call with trace removal;
4. tuple early call followed by normal later call;
5. partial-wrapped early model call;
6. partial-wrapped early replay call;
7. dynamic-`getattr` early call;
8. duplicate replay with discarded first result;
9. exact replay with fresh model evaluation;
10. exact replay with fresh guard evaluation.

### Admission/scenario integrity

11. B admission ref and expectation changed together;
12. B admission digest and expectation changed together;
13. B admission ref/digest both changed;
14. builder and relation expectation changed together;
15. admission omitted from pre-ledger binding;
16. program B collapsed to A;
17. B head/basis collapsed to A;
18. mutation/command identity reused;
19. B moved to another scope;
20. same-program second attempt substituted.

### Restoration

21. list restoration removed;
22. profile/trace restoration removed;
23. restoration skipped after wrapped-target exception;
24. restoration skipped after caller-body exception.

Every negative must retain the exact expected collection and fail at the
intended semantic boundary.

The legitimate human-table no-backtick positive must continue to pass.

## Reproducible selectors

Add and run at least:

```text
-k code_object_actual_entry
-k prebound_callable_actual_entry
-k code_object_probe_restoration
-k list_reference_restoration
-k shared_admission_integrity
-k command_admission_binding
-k cross_program_scenario_integrity
-k cross_program_ceiling
-k hostile
```

Preserve and rerun existing selectors:

```text
actual_model_entry
actual_replay_entry
fencing_before_replay_actual
model_after_guard_actual
capability_semantic_integrity
guard_ordering_integrity
typed_human_machine_equivalence
closed_human_table
operational_realization
c2b_current_status_authority
```

For each relevant module set:

1. run `--collect-only -q`;
2. record exact selected count;
3. execute;
4. require no zero-selection or unrelated selection.

## Validation

Perform all execution in a clean local-only external clone created from exact
HEAD and overlaid with the 28 candidate files.

Never import modules from the live checkout.

Use:

```text
PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=.:src
-p no:cacheprovider
--basetemp=<external path>
```

Run serially.

### Guard verifier

Collect and execute:

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

Opening V3 collection: `250`.

Final collection may increase but must not shrink.

### C2 plus guard

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_rw0_c2_durable_progression_decision_semantic_contract.py \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

Opening V3 collection: `1,584`.

### Four focused modules

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_rw0_b2_capability_boundaries.py \
  tests/test_c2b0_durable_state_contract.py \
  tests/test_rw0_c2_durable_progression_decision_semantic_contract.py \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

Opening V3 collection: `1,958`.

### Exact 17-module targeted command

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_architecture_contracts.py \
  tests/test_rw0_remote_contact_phase_entry_contract.py \
  tests/test_remote_worker_pre_execution_planning_contract.py \
  tests/test_software_development_progression_boundary.py \
  tests/test_autonomous_software_development_operating_model.py \
  tests/test_c2a_first_slice_semantic_protocol_contract.py \
  tests/test_c2a_nonimplementation.py \
  tests/test_rw0_b1_phase_values.py \
  tests/test_rw0_b1_vectors.py \
  tests/test_rw0_b1_relations.py \
  tests/test_rw0_b1_boundaries.py \
  tests/test_rw0_b2_wire_boundaries.py \
  tests/test_rw0_b2_capability_boundaries.py \
  tests/test_rw0_b2_wire_cancellation_control_boundaries.py \
  tests/test_c2b0_durable_state_contract.py \
  tests/test_rw0_c2_durable_progression_decision_semantic_contract.py \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

Opening V3 reference: `3,567 passed`.

### Exact broader command

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_c2a*.py \
  tests/test_worker_execution_semantic*.py \
  tests/test_rw0_b1*.py \
  tests/test_rw0_b2*.py \
  tests/test_rw0_c1*.py \
  tests/test_post_execution_pure_owner*.py \
  tests/test_c2b2*.py \
  tests/test_c2b3*.py \
  tests/test_section41*.py \
  tests/test_runtime_non_authority.py \
  tests/test_state_store_contract.py \
  tests/test_b2a_writer_session_contract.py \
  tests/test_sqlite*.py
```

Opening V3 reference: `3,611 passed, 3 warnings`.

### Full repository

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external>
```

Opening V3 reference: `7,778 passed, 3 warnings`.

Final counts may increase but must not shrink without an exact justified
collection change.

The only expected warnings remain the three unchanged Python 3.13
multi-threaded `fork()` deprecations in:

- `test_operation_guard_close_waits_and_retains_authority_until_exit`;
- `test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang`;
- `test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock`.

Also require:

- `git diff --check`;
- both new-file `/dev/null` whitespace checks;
- UTF-8/BOM/CR/trailing-whitespace/final-newline checks for all 28 paths;
- exact source/migration/schema/public/runtime preservation;
- exact C2B and C2B3 historical reconstruction;
- artifact scans in the external clone.

No product or operator database may be opened.

## Final live-cache gate

After all external validation and cleanup, inventory the live cache again.

Require exact equality with the restored 37-member baseline:

- members: `37`
- canonical bytes: `8,897`
- SHA-256:
  `3902e30eb9f5e229bb61b46d3b77a001f6b86371a717f9b3c324407d8818ebec`

No live repository import is permitted after the opening cleanup.

## Closeout provenance

Return inline:

1. outcome token;
2. visible model/reasoning setting;
3. opening and closing Git coordinates;
4. pre-cleanup cache state;
5. exact cleanup effect and restored cache receipt;
6. exact final 28-path receipt table;
7. exact one-file V3-to-V4 transition;
8. proof the other 27 candidate paths stayed byte-identical;
9. code-object observer design and independently checked baseline counts;
10. prebound tuple/partial/`getattr` causality;
11. shared-admission posture and scenario proof;
12. list/profile/trace restoration proof;
13. internal negative controls versus actual external mutants;
14. selector collection/execution;
15. guard, C2+guard, focused, 17-module, broader, and full validation;
16. source/migration/public/runtime preservation;
17. deterministic complete binary patch bytes and SHA-256;
18. fully specified canonical receipt bytes and SHA-256;
19. final live-cache equality;
20. cleanup and artifact posture;
21. remaining physical/value seams;
22. all required non-actions.

Calculate the final complete patch twice in the fixed 28-path order.

Calculate the canonical receipt twice with two independent implementations.

Do not stage, commit, push, create or modify a PR, or merge.

## Success token

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_REPAIRED_V4_VALIDATED_READY_FOR_REAUDIT`

Success authorizes only a fresh independent read-only audit of the exact V4
candidate.

## Blocking token

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_V4_REPAIR_BLOCKED`

Use the blocking token if:

- baseline or candidate provenance differs;
- the cache is neither exact 37-member baseline nor exact 49-member audit
  residue;
- exact cleanup cannot restore the 37-member baseline;
- the one-file ceiling is insufficient;
- a normative document or C2 verifier must change;
- production source, schema, migration, writer, or runtime changes are required;
- accepted architecture must change;
- any other candidate path must change.

Under a blocking outcome, restore the exact opening verifier bytes. Do not
recreate removed audit bytecode.

## Required non-actions

State:

```text
NORMATIVE_DOCUMENTS_NOT_MODIFIED
C2_VERIFIER_NOT_MODIFIED
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
SCHEMAS_NOT_MODIFIED
OTHER_27_CANDIDATE_PATHS_NOT_MODIFIED
NON_CEILING_DOCS_NOT_MODIFIED
NON_CEILING_TESTS_NOT_MODIFIED
OPERATOR_OR_PRODUCT_DATABASE_NOT_OPENED_OR_MUTATED
ORIGINAL_37_CACHE_MEMBERS_NOT_MOVED_OR_MODIFIED
LIVE_REPOSITORY_MODULES_NOT_IMPORTED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
BOOTSTRAP_SCOPE_PROVISIONER_NOT_IMPLEMENTED
BOOTSTRAP_ACCEPTANCE_GUARD_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
REMOTE_CONTACT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
MERGE_NOT_PERFORMED
SUBAGENTS_NOT_SPAWNED
EXTERNAL_ARTIFACTS_NOT_GENERATED
```
