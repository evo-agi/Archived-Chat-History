Here is Codex's response:

**1. Outcome**

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_REPAIRED_V3_VALIDATED_READY_FOR_REAUDIT`

The one-file verifier repair is applied. **7,778 tests passed, with the three expected warnings.** All 76 negative mutants were rejected at their intended boundaries; the legitimate positive parser probe passed.

This outcome authorizes only a fresh independent read-only audit of the exact repaired candidate.

**2. Visible model and reasoning**

- Model name: `not visible`
- Reasoning setting or effort: `not visible`

No hidden configuration was inferred.

**3. Opening and closing Git coordinates**

Opening and closing coordinates matched exactly:

| Field | Value |
|---|---|
| Branch | `trunk_dev` |
| HEAD | `6f11d6b0b6f38995123434945d86db0b169bb8f8` |
| Tree | `42cc0757b3d9604dfe7fdbda158074b8b48dac7b` |
| Sole parent | `db16de711986ae40a2bb848ed00cdddd3145ee02` |
| Subject | `docs: freeze RW0-C durable decision branch contract` |
| Upstream | `origin/trunk_dev` |
| Divergence | `0 ahead / 0 behind`; canonical string `0\t0` |
| Worktrees | Exactly one |
| Staged paths | Zero |
| Unmerged paths | Zero |

No merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock was present. No remote contact occurred.

**4. Exact final 28-path receipt**

Paths below are repository-relative receipt fields under `/Users/ds/Repositories/Governed Execution Coordinator`. Every file is regular, non-symlink, mode `0644`.

| # | Status | Path | Bytes | SHA-256 |
|---:|---|---|---:|---|
| 1 | `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 70,858 | `4fc2b7f9d5810105c28a7ce11abe85d08a48f915a87b088ae86e5520aa2142e2` |
| 2 | `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | 57,192 | `2c0c9565f7fb4ae79eca998080f3b70734f9a4fd1e555132daf9b94daab1dc97` |
| 3 | `M` | `.docs/c2a-first-slice-semantic-protocol-contract.md` | 103,413 | `a690441d046d147cf11a068e07a894858e3d32476e19fef84a9bb26e6e6f0d99` |
| 4 | `M` | `.docs/c2b-durable-development-state.md` | 1,889,329 | `6115a29d5bbfb8ffb17404e9acbefcb8edc958554683afa3538e9d959e184ef8` |
| 5 | `M` | `AGENTS.md` | 61,466 | `001595cdec75b176abbfb99b91b2b06c45f2f2ff1a28c704ded7054c27c7e74e` |
| 6 | `M` | `README.md` | 45,849 | `b66fb689d9f0849eee1d62f12dda93d83dcc9f4cce2fa008696878b44256ad1a` |
| 7 | `M` | `.docs/architecture.md` | 43,007 | `60a884471d655ee6eddad8c405aa218eab492e3c610b101c0736fc9f2546288f` |
| 8 | `M` | `.docs/autonomous-software-development-operating-model.md` | 37,829 | `115ed6c16141f821147f640131bed904526cee914dbec6951f3667b0da100f05` |
| 9 | `M` | `.docs/authority-boundaries.md` | 34,686 | `69d524c839a2195cf0b5840be424c021305825fd0db1d85c76ed28b99c1bf055` |
| 10 | `M` | `.docs/durable-state-model.md` | 40,564 | `e14a421698f0735fa098fe6ce1063b64d07e1c212fd6b60755e1068c9caf5955` |
| 11 | `M` | `.docs/worker-execution-boundary.md` | 30,920 | `6f7d2f7855fcbdecc757af4dde7a7bb091ab1e8c60057a2fefe407f74de4055f` |
| 12 | `M` | `.docs/software-development-progression-boundary.md` | 28,654 | `b8761655ee42512c0e77ab8c774c2b2d3d8f9ac36a9bd0c74872ad4bf2994419` |
| 13 | `M` | `.docs/c2b3-program-initialization.md` | 27,687 | `8e9c2c6f49551b28d95de28f6d7b071c89dd0ea155ce7d7a6e21e8d88e73d1f7` |
| 14 | `M` | `.docs/rw0-b2-wire-protocol.md` | 24,346 | `7f977a5a60fd66c69464190731e09611ca24854313e145b73cc73f564776477b` |
| 15 | `M` | `.docs/rw0-b2-capability.md` | 17,753 | `171341fc60cbe762403f1e64676ca35c9ea2f778a10d0fc66d668f1c84dc884c` |
| 16 | `M` | `.docs/rw0-b1-pure-phase-values.md` | 33,032 | `8bccdaa31fa66821b73c136936c12ef001157209c72b9991839905c1a8e0e053` |
| 17 | `M` | `tests/test_architecture_contracts.py` | 100,410 | `555ac490738d12075d3908ec2ddfd090fdbb32d8a6fd53d1b3136d24485e1169` |
| 18 | `M` | `tests/test_rw0_remote_contact_phase_entry_contract.py` | 173,524 | `42d6d265c0a9ba5047aa37ec3a4daae30847d486d39ead6374685b451a1d445c` |
| 19 | `M` | `tests/test_remote_worker_pre_execution_planning_contract.py` | 913,152 | `92b0f3917f0572492357447211a1f0f0cc7f8edb7e8b5f18233ed80397879b29` |
| 20 | `M` | `tests/test_software_development_progression_boundary.py` | 42,899 | `bd9b10f62e3bbfb3dc5fc845958fe0087363a0afa0b80649853faac85235c7a3` |
| 21 | `M` | `tests/test_autonomous_software_development_operating_model.py` | 72,904 | `e9a77edb1f99b181c612e52c4a7cfee814ac3f0df4d974e7c3a0756aec6da8df` |
| 22 | `M` | `tests/c2a_contract_support.py` | 154,372 | `58be92ddffae6f4b901ae3632521481ab8d9ce0e02a819ef9421408d08eedd85` |
| 23 | `M` | `tests/test_rw0_b1_boundaries.py` | 38,321 | `bd52384897f8f7a7129023c693ef67b1ff453a006723438dfa4f06df08e4121f` |
| 24 | `M` | `tests/test_rw0_b2_capability_boundaries.py` | 45,708 | `4e4824b5974778cbef147e7f5a5684de34e5006464156cbb7be2958c33ce1a84` |
| 25 | `M` | `tests/test_c2b0_durable_state_contract.py` | 884,862 | `45a539a810deb8884c3f0158887a0d4fd06778a59e833c6b9d89365990ed62fd` |
| 26 | `M` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | 249,444 | `480bd282646304c70116f69faecabc1fea94d83ef54ec77b780a869ace5431c4` |
| 27 | `??` | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 25,151 | `bf65ba7f04411bb6e6febec2285b33721eb2ff895e2c60aee97878b1fa7c9b46` |
| 28 | `??` | `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | 89,437 | `e6555cc5155bfbaa1031de43dcfc6b3534f60457d5a34b72b245d6f769a8d795` |

**5. Exact one-file V2-to-V3 transition**

Only the [guard verifier](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py>) changed from its opening bytes.

| Version | Bytes | SHA-256 |
|---|---:|---|
| Opening V2 | 63,314 | `0b5f13f41707413f051ef9a450b62242734e7978d30ebf99b1deb6f7f5f232cf` |
| Repaired V3 | 89,437 | `e6555cc5155bfbaa1031de43dcfc6b3534f60457d5a34b72b245d6f769a8d795` |

The increase is **26,123 bytes**. The final status set remains exactly 26 tracked modifications and two untracked files.

**6. Preservation of the other 27 candidate paths**

All other 27 paths were compared directly against retained opening bytes. They matched before live application, after application, and after temporary-data cleanup. Their receipt sizes and hashes also remain unchanged.

The repair was developed and tested in the external clone. The live verifier was copied only after all required validation passed.

**7. Actual model-entry instrumentation and results**

The [generic actual-call probe](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py:1073>) patches the defining module’s canonical attribute, every matching function-identity alias in the defining and guard modules, one-level dictionary/list registries, positional and keyword defaults, and closure cells holding the callable.

Model and replay wrappers record entry before delegation. A call expected to occur zero times raises immediately at its exact forbidden-entry boundary. Positive calls are counted and checked against the fixed event sequence. Every patched reference is restored and checked by identity.

The direct defining-module integrity test resolves the real C2 module, verifies its function/global identity, proves its canonical attribute and guard alias are wrapped, invokes the composition, checks actual counts/order, and verifies restoration.

| Model-entry case | Actual calls |
|---|---:|
| Exact replay | 0 |
| Lineage mismatch | 0 |
| Missing admission | 0 |
| Foreign admission | 0 |
| Multiple active authorities | 0 |
| Claimed scope | 0 |
| Unresolved scope | 0 |
| Eligible acceptance, recognized recommendation | 1 |
| Eligible acceptance, out-of-vocabulary recommendation | 1 |
| `candidate_repair` | 1 |
| `attempt_selecting_replan` | 1 |
| `program_terminal_reject` | 1 |
| `post_execution_program_block` | 1 |

The four nonaccept expectations are fixed from C2 normative steps 7–8: model consistency follows all authoritative no-write gates and is the last evaluation stage while the basis remains valid. The tests bind that prose and the exact five-branch inventory. They do not derive the expectation from observed implementation behavior.

**8. Actual replay-entry instrumentation and results**

The probe observes both:

- `_receipt_replay_check`, a thin test-local adapter exposing the existing absent/present supplied-receipt check;
- C2’s `_replay_family`, which retains ownership of persisted-family replay semantics.

The adapter delegates present-family handling without adding replay, collision, or recovery semantics.

| Case | Receipt checks | Persisted replay calls | Fresh pre-model | Guard eligibility | Model |
|---|---:|---:|---:|---:|---:|
| Unfenced caller | 0 | 0 | 0 | 0 | 0 |
| Invalid writer/session admission | 0 | 0 | 0 | 0 | 0 |
| Lineage mismatch | 0 | 0 | 0 | 0 | 0 |
| Missing admission | 0 | 0 | 0 | 0 | 0 |
| Foreign admission | 0 | 0 | 0 | 0 | 0 |
| Fenced fresh acceptance | 1 | 0 | 1 | 1 | 1 |
| Exact replay | 1 | 1 | 0 | 0 | 0 |
| Mutation-ref reuse conflict | 1 | 1 | 0 | 0 | 0 |
| Family-route collision | 1 | 0 | 1 | 0 | 0 |

The finite oracle represents invalid session admission through its existing rejected writer-fencing posture; this adds no production session mechanism.

The observed eligible-acceptance sequence is exactly:

```text
writer_or_session_fenced
receipt_or_collision_helper_entered
authoritative_pre_model_entered
acceptance_guard_entered
model_consistency_entered
```

Replay and mutation-ref conflict stop after the receipt stage. Family-route collision stops after pre-model. Claimed/unresolved scope stops after guard eligibility. Valid nonaccept branches omit guard eligibility. Prefix rejections enter none of these protected helpers.

These assertions use actual helper entry, independent of returned trace markers.

**9. Cross-program scenario integrity**

The [scenario integrity check](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py:1250>) independently requires:

| Coordinate | Command A | Command B |
|---|---|---|
| Actual program ref | `program_A` | `program_B` |
| Lineage / scope / admission | `L / S / A` | `L / S / A` |
| Program coordinates | `program_A`, `program_A:head`, `program_A:basis` | `program_B`, `program_B:head`, `program_B:basis` |
| Attempt / candidate | `program_A:attempt`, `program_A:candidate` | `program_B:attempt`, `program_B:candidate` |
| Mutation ref | `mutation_A` | `mutation_B` |
| Command digest | `digest_A` | `digest_B` |

Program refs must be exact nonempty strings and unequal before behavioral execution. Fixed relationship assertions live outside the builder; labels do not establish identity.

The finite oracle produces the first acceptance family, then rejects the second fresh acceptance because the shared scope is claimed. An independently admitted `L2/S2/A2` remains eligible. These are semantic fixture results, not physical database commits.

**10. Original and new mutant results**

Every variant retained the complete ordered **7,778-node collection**. Each negative received semantic credit only for its intended exact boundary. No syntax, import, formatting, collection, or parameter-count failure received credit.

The full suite was executed on the restored repaired candidate. Each mutant received full collection followed by targeted semantic execution.

All **44 original V2 negatives** were rejected:

| ID | Exact rejection boundary |
|---|---|
| O01 | `guard:four_body_immutable_fact:.docs/autonomous-software-development-operating-model.md` |
| O02 | `guard:four_body_drift` |
| O03 | `c2:mutable_latch_requirement` |
| O04 | `c2:human_machine_equivalence:/:keys` |
| O05 | `guard:inventory:/scope/identity` |
| O06 | `guard:prose:nonreplenishment` |
| O07 | `guard:prose:universal` |
| O08 | `guard:inventory:/scope/active_authorities` |
| O09 | `guard:inventory:/scope/local_absence_is_proof` |
| O10 | `guard:inventory:/scope/distinct_productive_acceptances` |
| O11 | `guard:inventory:/branch_effects/candidate_repair` |
| O12 | `guard:inventory:/eligibility/conflict_outcome` |
| O13 | `guard:inventory:/family/replay_new_fact` |
| O14 | `guard:recovery:decision_only` |
| O15 | `guard:inventory:/family/competing_winner_retry` |
| O16 | `guard:inventory:/terminal/mutates_guard` |
| O17 | `guard:inventory:/es/replenishes` |
| O18 | `guard:inventory:/b1/durable_guard_proof` |
| O19 | `guard:capability_semantic_integrity:compared_return` |
| O20 | `c2b:guard_current_successor` |
| O21 | `guard:duplicate_json_key:active_authorities` |
| O22 | `guard_ordering_integrity:model_after_guard` |
| O23 | `guard:human_machine_equivalence:/scope.active_authorities:value` |
| O24 | `guard:inventory:/implementation/writer` |
| N01, N02 | `guard:capability_semantic_integrity:helper_body` |
| N03 | `guard_ordering_integrity:fencing_before_receipt` |
| N04 | `guard_ordering_integrity:replay_before_eligibility` |
| N05 | `guard_ordering_integrity:model_after_guard` |
| N06 | `guard:human_machine_equivalence:/relation.command_digest_covered:type` |
| N07 | `guard:human_machine_equivalence:/branch_effects.candidate_repair:type` |
| N08, N09 | `guard:closed_human_table:duplicate:scope.identity` |
| N10 | `guard:closed_human_table:columns:Scope:1` |
| N11 | `guard:nonreplenishment:deployment` |
| N12 | `guard:nonreplenishment:attempt` |
| N13 | `guard:nonreplenishment:candidate` |
| N14 | `guard:nonreplenishment:command` |
| N15 | `c2b:current_status_authority` |
| S01 | `c2:human_machine_equivalence:/terminal/mutates_guard:type` |
| S02 | `guard:actual_entry:forbidden:model:claimed_scope` |
| S03 | `guard:operational_realization:case_inventory` |
| S04 | `guard:closed_human_table:value:scope.identity` |
| S05 | `guard:cross_program_ceiling:unrelated_program_B` |

All **14 additional audit probes** were rejected:

| ID | Probe | Exact rejection boundary |
|---|---|---|
| X01 | Ignored semantic evidence | `guard:capability_semantic_integrity:compared_return` |
| X02 | Missing P08 | `capability_semantic_integrity:/:keys` |
| X03 | Missing P11 marker | `capability_semantic_integrity:/P11/semantic_markers:length` |
| X04 | Human `1` changed to `true` | `guard:human_machine_equivalence:/scope.active_authorities:type` |
| X05 | Human `false` changed to `0` | `guard:human_machine_equivalence:/terminal.mutates_guard:type` |
| X06 | Missing human row | `guard:closed_human_table:rows:Scope` |
| X07 | Replay runs fresh model | `guard:actual_entry:forbidden:model:replay` |
| X08 | Discarded replay before fencing | `guard:actual_entry:forbidden:persisted_replay:unfenced` |
| X09 | Second program collapsed | `guard:cross_program_scenario:program_identity_distinct` |
| X10 | Wrong protected purpose | `capability_semantic_integrity:/P11/purpose:value` |
| X11 | Mapping replaces list | `guard:human_machine_equivalence:/scope.nonidentity:type` |
| X12 | Sibling string drift | `guard:human_machine_equivalence:/scope.identity:value` |
| X13 | Null drift | `guard:human_machine_equivalence:/family.separate_receipt:type` |
| X14 | Contradictory bare valid JSON | `guard:human_machine_equivalence:/scope.identity:value` |

All **18 V3-specific negatives** were rejected:

| ID | Variant | Exact rejection boundary |
|---|---|---|
| V3M01 | Direct defining-module model call, discarded | `guard:actual_entry:forbidden:model:claimed_scope` |
| V3M02 | Imported-alias model call, discarded | `guard:actual_entry:forbidden:model:claimed_scope` |
| V3M03 | One-level wrapper model call, discarded | `guard:actual_entry:forbidden:model:claimed_scope` |
| V3M04 | Forged guard-passed stamp | `guard:actual_entry:forbidden:model:claimed_scope` |
| V3M05 | Actual model call with trace removed | `guard:actual_entry:forbidden:model:claimed_scope` |
| V3M06 | Model call through captured default | `guard:actual_entry:forbidden:model:claimed_scope` |
| V3R01 | Defining-module replay before fencing | `guard:actual_entry:forbidden:persisted_replay:unfenced` |
| V3R02 | Imported-alias replay before fencing | `guard:actual_entry:forbidden:persisted_replay:unfenced` |
| V3R03 | Wrapper replay before fencing, discarded | `guard:actual_entry:forbidden:persisted_replay:unfenced` |
| V3R04 | Duplicate replay, first result discarded | `guard:actual_entry:count:persisted_replay:replay` |
| V3R05 | Exact replay runs fresh model | `guard:actual_entry:forbidden:model:replay` |
| V3R06 | Exact replay runs fresh guard | `guard:actual_entry:forbidden:acceptance:replay` |
| V3R07 | Replay through captured closure before fencing | `guard:actual_entry:forbidden:persisted_replay:unfenced` |
| V3S01 | B program ref collapsed to A | `guard:cross_program_scenario:program_identity_distinct` |
| V3S02 | B head/basis collapsed to A | `guard:cross_program_scenario:program_basis_binding:/0:value` |
| V3S03 | Command/mutation identity reused | `guard:cross_program_scenario:command_identity_distinct:mutation_ref` |
| V3S04 | B assigned a different scope | `guard:cross_program_scenario:shared_scope:/1:value` |
| V3S05 | Same-program second attempt substituted | `guard:cross_program_scenario:program_identity_distinct` |

**P01**, legitimate removal of human-table backticks, retained collection and **passed**.

Some document mutants raised their exact semantic assertions during fixture setup; their collection remained complete. The three V2 survivors—S02, X08, and X09—now fail at the required actual-entry or scenario-integrity boundaries.

**11. Reproducible selector results**

Every selector was collected before execution against the exact four-module set shown below. No selector selected zero tests.

| `-k` selector | Collected | Passed |
|---|---:|---:|
| `actual_model_entry` | 14 | 14 |
| `actual_replay_entry` | 9 | 9 |
| `fencing_before_replay_actual` | 9 | 9 |
| `model_after_guard_actual` | 13 | 13 |
| `cross_program_scenario_integrity` | 6 | 6 |
| `cross_program_ceiling` | 1 | 1 |
| `hostile` | 658 | 658 |
| `capability_semantic_integrity` | 9 | 9 |
| `guard_ordering_integrity` | 4 | 4 |
| `typed_human_machine_equivalence` | 23 | 23 |
| `closed_human_table` | 11 | 11 |
| `model_after_guard` | 26 | 26 |
| `operational_realization` | 18 | 18 |
| `c2b_current_status_authority` | 3 | 3 |

The reproducible selector command is the four-module command below with `-k SELECTOR`; collection additionally uses `--collect-only`.

**12. Focused, targeted, broader, and full validation**

All pytest invocations ran serially in the local-only external clone, using existing Python 3.13.4, `PYTHONDONTWRITEBYTECODE=1`, `PYTHONPATH=.:src`, `-p no:cacheprovider`, and separate external basetemps. No dependency was installed.

| Run | Collected | Execution result |
|---|---:|---|
| C2 alone | 1,334 | Included in passing pair |
| Guard alone | 250 | Included in passing pair |
| C2 + guard | 1,584 | 1,584 passed in 9.12s |
| Four focused modules | 1,958 | 1,958 passed in 443.13s |
| Exact 17 modules | 3,567 | 3,567 passed in 489.34s |
| Exact broader command | 3,611 | 3,611 passed, 3 warnings in 571.73s |
| Full repository | 7,778 | 7,778 passed, 3 warnings in 1,593.54s |

All original 7,741 ordered nodes were retained. The guard grew from 213 to 250 nodes, accounting for all 37 additions:

| Added test group | Nodes |
|---|---:|
| Actual model-entry cases listed in section 7 | 13 |
| Actual replay-entry cases listed in section 8 | 9 |
| Direct defining-module integrity | 1 |
| Hostile alias/registry/default/closure and restoration tests, model and replay roles | 2 |
| Positive cross-program scenario integrity | 1 |
| Scenario hostiles: program, basis, command, scope, same-program attempt | 5 |
| Positive probe AST integrity | 1 |
| AST hostiles: defining-module patch, restoration, recording, counts/order, coordinates | 5 |

The final ordered collection, serialized as newline-joined node IDs with one final LF, has SHA-256:

`063f282f58c24bda19eac044131bbeae7c87b9ed93b750e3cd416a81cc04725a`

The following exact module arguments were used. Each collection used the same arguments plus `--collect-only`; `<external>` denotes its separate basetemp.

Focused pair:

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_rw0_c2_durable_progression_decision_semantic_contract.py \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

Four focused modules:

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_rw0_b2_capability_boundaries.py \
  tests/test_c2b0_durable_state_contract.py \
  tests/test_rw0_c2_durable_progression_decision_semantic_contract.py \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

Exact 17 modules:

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_architecture_contracts.py \
  tests/test_rw0_remote_contact_phase_entry_contract.py \
  tests/test_remote_worker_pre_execution_planning_contract.py \
  tests/test_software_development_progression_boundary.py \
  tests/test_autonomous_software_development_operating_model.py \
  tests/test_c2a_first_slice_semantic_protocol_contract.py \
  tests/test_c2a_nonimplementation.py \
  tests/test_rw0_b1_phase_values.py \
  tests/test_rw0_b1_vectors.py \
  tests/test_rw0_b1_relations.py \
  tests/test_rw0_b1_boundaries.py \
  tests/test_rw0_b2_wire_boundaries.py \
  tests/test_rw0_b2_capability_boundaries.py \
  tests/test_rw0_b2_wire_cancellation_control_boundaries.py \
  tests/test_c2b0_durable_state_contract.py \
  tests/test_rw0_c2_durable_progression_decision_semantic_contract.py \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

Exact broader command, with globs expanded in the supplied order:

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_c2a*.py \
  tests/test_worker_execution_semantic*.py \
  tests/test_rw0_b1*.py \
  tests/test_rw0_b2*.py \
  tests/test_rw0_c1*.py \
  tests/test_post_execution_pure_owner*.py \
  tests/test_c2b2*.py \
  tests/test_c2b3*.py \
  tests/test_section41*.py \
  tests/test_runtime_non_authority.py \
  tests/test_state_store_contract.py \
  tests/test_b2a_writer_session_contract.py \
  tests/test_sqlite*.py
```

Full repository:

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external>
```

The broader and full runs each emitted exactly the three unchanged Python 3.13 multithreaded `fork()` deprecations:

- `test_operation_guard_close_waits_and_retains_authority_until_exit`
- `test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang`
- `test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock`

**13. Source, migration, public, and runtime preservation**

All **212 tracked paths outside the candidate** matched HEAD byte-for-byte. All **66 source/resource paths**, including 62 Python sources and four SQL migrations, matched HEAD. The Python sources parsed successfully.

The migration inventory remains exactly:

```text
0001_initial.sql
0002_development_program_and_effect_state.sql
0003_cognitive_proposal_and_selection_state.sql
0004_rw0_c1_durable_evidence.sql
```

Migration `0005` is absent. Schemas, package exports, StateStore, WriterSession, transactions, readers, writers, public surfaces, runtime, configuration, and examples were preserved.

Historical reconstruction also passed:

- C2B’s first **1,887,232 bytes** exactly reconstruct committed HEAD. Its unchanged 2,097-byte appendix has SHA-256 `f34b64471dca1276470bf92195f9b318193701f1af03baf1f911091a8ba80c5c`.
- Removing the existing **940-byte** C2B3 insertion at byte range `[26691,27631)` exactly reconstructs committed HEAD’s 26,747 bytes; the committed-current-status end marker remains intact.

`git diff --check` and both new-file `/dev/null` whitespace checks passed. All 28 files passed UTF-8, no-BOM, no-CR, trailing-whitespace, and exactly-one-final-LF checks.

**14. Deterministic complete binary patch**

The complete patch was calculated twice in the exact receipt order and compared byte-for-byte. It was recalculated after cleanup with the same result.

For each tracked modification, the construction used:

```text
git diff --binary --full-index --no-ext-diff --no-textconv HEAD -- PATH
```

For each untracked file:

```text
git diff --no-index --binary --full-index --no-ext-diff --no-textconv -- /dev/null PATH
```

Outputs were concatenated without added separators.

| Candidate | Bytes | SHA-256 |
|---|---:|---|
| Opening V2, verified | 282,372 | `d16aecc7db8afd9a65c65dd8c228730562c2531a282ea3bb379a1af0ce6701ff` |
| Final V3, both calculations | 308,892 | `1d875ae83857db8fc4dd4c142800ced5682ff03c384c3e95430c5e33b48ea682` |

No patch file was delivered.

**15. Canonical receipt**

The receipt grammar is:

- Root object containing `baseline` and ordered `files`.
- Baseline fields: `branch`, `head`, `tree`, `parent`, `subject`, `upstream`, `divergence`, `staged`, `unmerged`.
- Baseline values are strings; divergence contains a literal tab between the zeroes, and staged/unmerged are empty strings.
- File fields: `status`, `path`, `type`, `mode`, `bytes`, `sha256`.
- `bytes` is an integer; other file values are strings, with `type="regular"` and `mode="0644"`.
- Object keys sort lexicographically; files retain the exact 28-path order.
- Compact UTF-8 JSON, `ensure_ascii=false`, no insignificant whitespace, and one final LF.

Two independent serializers—standard JSON serialization and a separate recursive encoder—produced identical bytes in both calculation rounds. The result remained identical after cleanup.

| Candidate | Bytes | SHA-256 |
|---|---:|---|
| Opening V2, verified | 5,593 | `5bd53947d2187a3bacc710684ba35b646cb55fb4a1eaa3e91d18ecbf54accabb` |
| Final V3 | 5,593 | `a59f7c53ae4cbbdf33d7c5b69bd7ece58f2ada796c0195536bec23a0b687f8ae` |

**16. Live cache equality**

All **37 opening cache members** matched at closing and after cleanup for every recorded field: repository-relative path, type, mode, byte size, native integer `mtime_ns`, and SHA-256.

The cache was not moved, rewritten, imported through, or deleted.

The reported aggregate uses a root array sorted by repository-relative path. Each object contains `path`, `type`, `mode`, `size`, `mtime_ns`, and `sha256`; keys sort lexicographically. Mode is a four-digit octal string, size and timestamp are integers, hashes are lowercase hexadecimal. Serialization is compact UTF-8 JSON with `ensure_ascii=false` and one final LF.

Opening and closing aggregate:

- Bytes: **8,897**
- SHA-256: `3902e30eb9f5e229bb61b46d3b77a001f6b86371a717f9b3c324407d8818ebec`

Member-level equality was authoritative; no comparison with the audit’s unresolved historical aggregate was required.

**17. Cleanup and artifact posture**

The engagement-created temporary root, clone, runners, mutant overlays, logs, test databases, and basetemps were removed. Closing checks ran again after removal and matched the preceding final snapshot.

The final repository artifact scan found exactly the 28 candidate paths plus the 37 pre-existing ignored cache files. No client-visible report, manifest, package, patch, freeze artifact, or attachment was generated.

**18. Remaining physical/value seams**

Bootstrap-scope provisioning, physical admission/acceptance-fact representation, safe-value compatibility, and separately authorized reader, writer, recovery, and terminal integration remain future seams governed by the existing contracts.

This repair changes verifier observation and scenario integrity only. It selects no physical schema or DTO and activates no production caller, public surface, RW0-D, RW0-E, or ES routing. The next authorized step is the fresh independent read-only audit of the exact V3 candidate identified above.

**19. Required non-actions**

These statements apply to this V3 repair and its future RW0-C2 implementation boundaries:

```text
NORMATIVE_DOCUMENTS_NOT_MODIFIED
C2_VERIFIER_NOT_MODIFIED
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
SCHEMAS_NOT_MODIFIED
OTHER_27_CANDIDATE_PATHS_NOT_MODIFIED
NON_CEILING_DOCS_NOT_MODIFIED
NON_CEILING_TESTS_NOT_MODIFIED
OPERATOR_OR_PRODUCT_DATABASE_NOT_OPENED_OR_MUTATED
LIVE_IGNORED_CACHE_NOT_MOVED_OR_MODIFIED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
BOOTSTRAP_SCOPE_PROVISIONER_NOT_IMPLEMENTED
BOOTSTRAP_ACCEPTANCE_GUARD_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
REMOTE_CONTACT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
MERGE_NOT_PERFORMED
SUBAGENTS_NOT_SPAWNED
EXTERNAL_ARTIFACTS_NOT_GENERATED
```
