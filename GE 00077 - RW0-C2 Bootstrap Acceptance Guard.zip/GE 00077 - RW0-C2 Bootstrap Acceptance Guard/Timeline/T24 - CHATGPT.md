## Disposition

**Accept the audit verdict. The commit gate remains closed.**

The audit result is:

```text
AUDIT_PROVENANCE_MISMATCH
```

This is primarily an **audit-process provenance failure**, not evidence that the 28 candidate files drifted. The baseline, exact path set, all file receipts, the `308,892`-byte patch, and the `5,593`-byte canonical receipt still reproduced. :chatgpt-content-reference{index="0"}

The mismatch arose because a delegated explorer imported repository modules from the live checkout without bytecode suppression. The live ignored-cache inventory grew from 37 to 49 members, adding twelve `.pyc` files. The auditor correctly left them untouched because the audit prompt prohibited cleanup. :chatgpt-content-reference{index="1"}

The audit also found two blocking verifier defects and one narrower coverage defect, so simply removing the cache residue would not make the candidate commit-ready.

## Substantive findings

### 1. Prebound callables can bypass the actual-call probe

The V3 probe patches module attributes, imported aliases, shallow registries, defaults, and closure cells. However, an external mutant captured the original model and replay functions inside an immutable tuple before patching, then invoked those originals early and discarded their outputs.

The verifier still reported expected counts, while an independent `sys.setprofile` observer saw:

```text
unfenced model calls: verifier 0 / independent observer 1
unfenced replay calls: verifier 0 / independent observer 1
```

The mutant retained the complete `7,778`-node collection and all `1,584` C2-plus-guard tests passed. :chatgpt-content-reference{index="2"}

The repair therefore needs a **code-object-level observer** as the authoritative actual-entry mechanism. Monitoring exact `__code__` identities catches invocation through tuples, aliases, defaults, closures, wrappers, partials, registries, `getattr`, and discarded return values without depending on which reference was patched.

### 2. The cross-program scenario does not independently prove one admission fact

The live scenario correctly uses distinct programs, bases, attempts, candidates, mutations, and command digests under one lineage and scope. But a coupled mutant changed program B’s admission from `A` to `A2` and changed the verifier’s expectation with it. All 250 guard tests and all 1,584 C2-plus-guard tests still passed.

The behavioral ledger is keyed only by lineage and scope, so it still rejects the second acceptance without proving that both commands were bound to the **same immutable admission fact**. :chatgpt-content-reference{index="3"}

The repair needs a third, independently authored guard-posture fixture. Both commands must bind to its exact lineage, scope, admission identity, and admission digest before the one-shot ledger is evaluated.

### 3. List restoration works, but its protection is not causal

The current probe does restore target-bearing list entries. However, deleting only that restoration logic left the focused suite green because no permanent test supplied a target-bearing list. An audit-local list demonstrated that the wrapper remained installed after the probe raised. :chatgpt-content-reference{index="4"}

A direct dynamic test must cover list patching and restoration during:

- normal delegation;
- wrapped-target exceptions;
- caller-body exceptions;
- repeated probes;
- nested probes or an exact nesting rejection.

### 4. Full independent validation did not finish

The cache change required the auditor to halt. The C2 and guard modules passed, but the four-module run was interrupted; the full suite stopped after 1,524 tests; the exact 17-module and broader runs were never started. Their expected results remain unverified rather than failed. :chatgpt-content-reference{index="5"}

### 5. The mutant evidence must be described more precisely

The implementation report characterized 76 negatives as mutants. The audit found that most were permanent internal tests that **pass by catching the expected exception**, not 76 independently transformed external copies that failed pytest. Only a smaller set of true external transformations was reproduced. :chatgpt-content-reference{index="6"}

Future closeout must distinguish:

```text
permanent internal negative controls
external transformed mutants actually executed
ordinary regression validation
```

## Cache restoration boundary

The live checkout should first be returned from the exact 49-member audit-residue state to the exact 37-member pre-audit state.

Only these twelve audit-created files may be deleted:

```text
src/ge_nwp_coordinator/__pycache__/_finite_backlog_risk_source_adapter.cpython-313.pyc
src/ge_nwp_coordinator/__pycache__/_post_execution_evidence_values.cpython-313.pyc
src/ge_nwp_coordinator/__pycache__/_post_execution_policy_values.cpython-313.pyc
src/ge_nwp_coordinator/__pycache__/_rw0_c_decision_input_values.cpython-313.pyc
src/ge_nwp_coordinator/__pycache__/_section41_post_execution_proposal_family_projection.cpython-313.pyc
src/ge_nwp_coordinator/__pycache__/_section41_post_execution_role_resolution.cpython-313.pyc
tests/__pycache__/c2a_contract_support.cpython-313.pyc
tests/__pycache__/test_post_execution_pure_owner_relations.cpython-313.pyc
tests/__pycache__/test_post_execution_pure_owner_values.cpython-313.pyc
tests/__pycache__/test_rw0_b1_vectors.cpython-313.pyc
tests/__pycache__/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.cpython-313.pyc
tests/__pycache__/test_rw0_c2_durable_progression_decision_semantic_contract.cpython-313.pyc
```

The original 37 members reportedly remain byte- and metadata-exact. The target restored inventory is:

```text
Members:
37

Canonical bytes:
8,897

SHA-256:
3902e30eb9f5e229bb61b46d3b77a001f6b86371a717f9b3c324407d8818ebec
```

The audit itself identifies the correct next boundary as a verifier-only repair covering prebound calls, independent admission binding, and list restoration, followed by a new audit with a restored cache baseline and completed validation. :chatgpt-content-reference{index="7"}

## V4 repair handoff

Resume the **original governing-reset implementation conversation**, switch it to workspace-write, keep the parent as the sole writer, and attach nothing.

:chatgpt-content-reference{index="9"}[Download the V4 code-object causality repair prompt](sandbox:/mnt/data/Coordinator_RW0_C2_Bootstrap_Guard_Governing_Reset_V4_Code_Object_Causality_Repair_Prompt.txt)

```text
Filename:
Coordinator_RW0_C2_Bootstrap_Guard_Governing_Reset_V4_Code_Object_Causality_Repair_Prompt.txt

Size:
30,206 bytes

SHA-256:
83cd525d8c37fb25a9476fd94e7100d454a2fad4f571387d4693b9de44f6ae1c

Logical lines:
809

Final newline:
present
```

The prompt authorizes exactly:

1. removal of the twelve audit-created `.pyc` files, after exact inventory verification;
2. removal of the now-empty audit-created `tests/__pycache__` directory, when applicable;
3. modification of only:

```text
tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

The other 27 candidate paths remain fixed.

The repair must add:

- exact code-object entry observation independent of reference patching;
- prebound tuple, partial, `getattr`, default, closure, wrapper, and duplicate-call controls;
- exact profile/trace restoration checks;
- a separately authored immutable guard-posture fixture;
- exact command-to-admission binding before ledger evaluation;
- generic same-admission invariants for both cross-program commands;
- direct target-bearing-list restoration tests;
- honest separation of internal negative controls from external transformed mutants;
- complete guard, C2-plus-guard, focused, 17-module, broader, and full-suite validation;
- final proof that the live cache remains at the restored 37-member baseline.

Success token:

```text
RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_REPAIRED_V4_VALIDATED_READY_FOR_REAUDIT
```

Blocking token:

```text
RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_V4_REPAIR_BLOCKED
```

A successful repair still authorizes only a fresh independent read-only audit. It does not authorize staging, commit, publication, safe-value changes, migration `0005`, provisioning, durable writing, guard persistence, readers, terminal persistence, public APIs, runtime activation, RW0-D/E, or Execution Substrate work.

**Source:** Fresh V3 independent re-audit attached in this turn. Its final provenance records that the 28 candidate paths remained exact even though the audit left twelve new ignored cache files. :chatgpt-content-reference{index="8"}

**Confidence:** High that the audit verdict is correct. High that candidate semantics remain intact. High that exact cache restoration plus a one-file code-object/scenario/restoration repair is the narrowest sufficient next tranche.
