# Governed Execution Coordinator — RW0-C2 Bootstrap Guard Governing Reset V4 Independent Re-audit

## Objective

Perform a fresh, parent-only, local, read-only independent re-audit of the
uncommitted RW0-C2 bootstrap acceptance-guard governing-reset V4 candidate.

This audit follows a one-file verifier repair plus exact cleanup of twelve
audit-created live-checkout bytecode files. The repair is intended to close:

1. hidden model or replay calls through prebound references;
2. coupled cross-program admission mutations;
3. unprotected list and profile/trace restoration;
4. the live-cache provenance mismatch caused by the preceding audit.

Use the highest available Codex reasoning setting. At the beginning of the
report, record exactly what the interface visibly shows for:

- model name;
- reasoning setting or effort.

Do not infer hidden configuration. Record `not visible` when necessary.

The checked-out repository is the sole audit target and source of current
contract truth. Do not request or use chat exports, prior report attachments,
Downloads artifacts, Project artifacts, or generated manifests. The
implementation closeout is evidence only; reproduce every material claim from
the live repository.

Do not repair the candidate.

Return one substantive inline audit report. Do not create or attach a report,
manifest, package, patch, freeze artifact, or other client-visible file.

## Parent-only audit

Do not spawn subagents.

The preceding audit's delegated explorer imported repository modules from the
live checkout and created ignored bytecode. This audit must remain parent-only
so that one process owns the no-live-import discipline and cleanup accounting.

## Exact committed baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed baseline beneath the candidate:

- branch: `trunk_dev`
- HEAD: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- HEAD tree: `42cc0757b3d9604dfe7fdbda158074b8b48dac7b`
- sole parent: `db16de711986ae40a2bb848ed00cdddd3145ee02`
- subject: `docs: freeze RW0-C durable decision branch contract`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- zero staged paths
- zero unmerged paths
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Do not fetch or contact remotes.

Any baseline, path-set, classification, file-type, mode, size, or per-file
SHA-256 mismatch requires:

`AUDIT_PROVENANCE_MISMATCH`

Stop before correctness inspection.

## Exact V4 28-path candidate

Require exactly 26 tracked modifications and two untracked files, with no other
tracked or untracked difference from HEAD.

All 28 paths must be regular, non-symlink mode-`0644` files, valid UTF-8,
without BOM or CR bytes, without trailing whitespace, and with exactly one
final newline.

| # | Status | Path | Bytes | SHA-256 |
|---:|---|---|---:|---|
| 1 | `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 70,858 | `4fc2b7f9d5810105c28a7ce11abe85d08a48f915a87b088ae86e5520aa2142e2` |
| 2 | `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | 57,192 | `2c0c9565f7fb4ae79eca998080f3b70734f9a4fd1e555132daf9b94daab1dc97` |
| 3 | `M` | `.docs/c2a-first-slice-semantic-protocol-contract.md` | 103,413 | `a690441d046d147cf11a068e07a894858e3d32476e19fef84a9bb26e6e6f0d99` |
| 4 | `M` | `.docs/c2b-durable-development-state.md` | 1,889,329 | `6115a29d5bbfb8ffb17404e9acbefcb8edc958554683afa3538e9d959e184ef8` |
| 5 | `M` | `AGENTS.md` | 61,466 | `001595cdec75b176abbfb99b91b2b06c45f2f2ff1a28c704ded7054c27c7e74e` |
| 6 | `M` | `README.md` | 45,849 | `b66fb689d9f0849eee1d62f12dda93d83dcc9f4cce2fa008696878b44256ad1a` |
| 7 | `M` | `.docs/architecture.md` | 43,007 | `60a884471d655ee6eddad8c405aa218eab492e3c610b101c0736fc9f2546288f` |
| 8 | `M` | `.docs/autonomous-software-development-operating-model.md` | 37,829 | `115ed6c16141f821147f640131bed904526cee914dbec6951f3667b0da100f05` |
| 9 | `M` | `.docs/authority-boundaries.md` | 34,686 | `69d524c839a2195cf0b5840be424c021305825fd0db1d85c76ed28b99c1bf055` |
| 10 | `M` | `.docs/durable-state-model.md` | 40,564 | `e14a421698f0735fa098fe6ce1063b64d07e1c212fd6b60755e1068c9caf5955` |
| 11 | `M` | `.docs/worker-execution-boundary.md` | 30,920 | `6f7d2f7855fcbdecc757af4dde7a7bb091ab1e8c60057a2fefe407f74de4055f` |
| 12 | `M` | `.docs/software-development-progression-boundary.md` | 28,654 | `b8761655ee42512c0e77ab8c774c2b2d3d8f9ac36a9bd0c74872ad4bf2994419` |
| 13 | `M` | `.docs/c2b3-program-initialization.md` | 27,687 | `8e9c2c6f49551b28d95de28f6d7b071c89dd0ea155ce7d7a6e21e8d88e73d1f7` |
| 14 | `M` | `.docs/rw0-b2-wire-protocol.md` | 24,346 | `7f977a5a60fd66c69464190731e09611ca24854313e145b73cc73f564776477b` |
| 15 | `M` | `.docs/rw0-b2-capability.md` | 17,753 | `171341fc60cbe762403f1e64676ca35c9ea2f778a10d0fc66d668f1c84dc884c` |
| 16 | `M` | `.docs/rw0-b1-pure-phase-values.md` | 33,032 | `8bccdaa31fa66821b73c136936c12ef001157209c72b9991839905c1a8e0e053` |
| 17 | `M` | `tests/test_architecture_contracts.py` | 100,410 | `555ac490738d12075d3908ec2ddfd090fdbb32d8a6fd53d1b3136d24485e1169` |
| 18 | `M` | `tests/test_rw0_remote_contact_phase_entry_contract.py` | 173,524 | `42d6d265c0a9ba5047aa37ec3a4daae30847d486d39ead6374685b451a1d445c` |
| 19 | `M` | `tests/test_remote_worker_pre_execution_planning_contract.py` | 913,152 | `92b0f3917f0572492357447211a1f0f0cc7f8edb7e8b5f18233ed80397879b29` |
| 20 | `M` | `tests/test_software_development_progression_boundary.py` | 42,899 | `bd9b10f62e3bbfb3dc5fc845958fe0087363a0afa0b80649853faac85235c7a3` |
| 21 | `M` | `tests/test_autonomous_software_development_operating_model.py` | 72,904 | `e9a77edb1f99b181c612e52c4a7cfee814ac3f0df4d974e7c3a0756aec6da8df` |
| 22 | `M` | `tests/c2a_contract_support.py` | 154,372 | `58be92ddffae6f4b901ae3632521481ab8d9ce0e02a819ef9421408d08eedd85` |
| 23 | `M` | `tests/test_rw0_b1_boundaries.py` | 38,321 | `bd52384897f8f7a7129023c693ef67b1ff453a006723438dfa4f06df08e4121f` |
| 24 | `M` | `tests/test_rw0_b2_capability_boundaries.py` | 45,708 | `4e4824b5974778cbef147e7f5a5684de34e5006464156cbb7be2958c33ce1a84` |
| 25 | `M` | `tests/test_c2b0_durable_state_contract.py` | 884,862 | `45a539a810deb8884c3f0158887a0d4fd06778a59e833c6b9d89365990ed62fd` |
| 26 | `M` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | 249,444 | `480bd282646304c70116f69faecabc1fea94d83ef54ec77b780a869ace5431c4` |
| 27 | `??` | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 25,151 | `bf65ba7f04411bb6e6febec2285b33721eb2ff895e2c60aee97878b1fa7c9b46` |
| 28 | `??` | `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | 116,659 | `299b5ffdf3ed0f983068e0d42ee99474a600dce9201c38724ec9371d73ac01e3` |

Require:

- zero staged paths;
- zero unmerged paths;
- zero deletions, renames, type changes, symlinks, executable-mode changes, or
  additional untracked paths;
- every tracked path outside this set byte-identical to HEAD.

## Complete patch corroboration

Construct the complete candidate patch in the exact 28-path table order.

For each tracked path:

```text
git diff --binary --full-index --no-ext-diff --no-textconv HEAD -- <path>
```

For each new path:

```text
git diff --no-index --binary --full-index --no-ext-diff --no-textconv -- /dev/null <path>
```

Treat expected `git diff --no-index` status `1` as “differences found.”

Concatenate exact stdout bytes without separators.

Expected V4 coordinate:

- bytes: `336,588`
- SHA-256:
  `1f020195ad27f9b47ae4a9df3d8824669c0501f5e1f56022f3488ef19c001f35`

Run the assembly twice.

The exact path set and per-file receipts are primary provenance. An unresolved
patch difference is `AUDIT_PROVENANCE_MISMATCH`.

## Canonical receipt corroboration

Reconstruct this exact canonical receipt.

Root:

```text
{"baseline": object, "files": array}
```

`baseline` has exactly these nine string fields:

- `branch`
- `head`
- `tree`
- `parent`
- `subject`
- `upstream`
- `divergence`
- `staged`
- `unmerged`

Values:

- `branch`: `trunk_dev`
- `head`: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- `tree`: `42cc0757b3d9604dfe7fdbda158074b8b48dac7b`
- `parent`: `db16de711986ae40a2bb848ed00cdddd3145ee02`
- `subject`: `docs: freeze RW0-C durable decision branch contract`
- `upstream`: `origin/trunk_dev`
- `divergence`: literal string `0\t0`, containing one tab
- `staged`: empty string
- `unmerged`: empty string

`files` contains exactly 28 objects in table order. Each object has exactly:

- `status`
- `path`
- `type`
- `mode`
- `bytes`
- `sha256`

Rules:

- object keys lexicographically sorted;
- arrays retain order;
- status is `M` or `??`;
- type is `regular`;
- mode is `0644`;
- bytes is a decimal integer;
- SHA-256 is lowercase hexadecimal;
- compact JSON with `,` and `:` separators;
- UTF-8, `ensure_ascii=false`, one final LF;
- slash characters unescaped.

Expected V4 receipt:

- bytes: `5,594`
- SHA-256:
  `f89483fdd31c633c4a631afee36a6727bf99c95e837e9265065a94d4687d4ffd`

Run two independent implementations and require byte-identical output.

## Exact V3-to-V4 transition

Only this path may have changed from the independently inspected V3 candidate:

`tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py`

Reported transition:

- V3: `89,437` bytes /
  `e6555cc5155bfbaa1031de43dcfc6b3534f60457d5a34b72b245d6f769a8d795`
- V4: `116,659` bytes /
  `299b5ffdf3ed0f983068e0d42ee99474a600dce9201c38724ec9371d73ac01e3`

The other 27 candidate paths must match the fixed V4 receipts above.

Historical V3 bytes are corroborating transition evidence. The live V4
candidate is the audit target.

## Historical-byte coordinates

### C2B durable-state document

Require the complete committed HEAD content to remain an exact prefix:

- committed prefix bytes: `1,887,232`
- committed prefix SHA-256:
  `77bf3d3c6ed710da669db7fa4353f46f3d1e9b4e09636918046d16d94ed962e5`

Independently compute the HEAD blob and require exact equality.

The candidate append must remain:

- bytes: `2,097`
- SHA-256:
  `f34b64471dca1276470bf92195f9b318193701f1af03baf1f911091a8ba80c5c`

Verify exact prefix equality against the Git blob and inspect the appended
successor semantically.

### C2B3 program initialization

Require exact reconstruction from the committed Git blob by removing only the
candidate's bounded projection insertion immediately before:

`COORDINATOR_C2B3D_COMMITTED_CURRENT_STATUS_END`

Do not trust historical byte offsets until reproduced from the live candidate
and HEAD blobs.

## Live ignored-cache gate

Before any Python import or test action, inventory the live ignored cache using
only file metadata and byte hashing. Do not import repository modules.

Require exactly:

- members: `37`
- canonical bytes: `8,897`
- SHA-256:
  `3902e30eb9f5e229bb61b46d3b77a001f6b86371a717f9b3c324407d8818ebec`

Canonical cache grammar:

- path-sorted root JSON array;
- exact object keys:
  - `path`
  - `type`
  - `mode`
  - `size`
  - `mtime_ns`
  - `sha256`
- object keys lexicographically sorted;
- compact UTF-8 JSON;
- `ensure_ascii=false`;
- one final LF.

If any live cache member differs or another ignored cache path exists, return
`AUDIT_PROVENANCE_MISMATCH`.

After this gate:

- do not import any repository module from the live checkout;
- do not run pytest from the live checkout;
- do not run a Python script whose import path includes the live repository;
- do not delete, move, rewrite, or clean any live cache file;
- do not create `tests/__pycache__`.

All executable work must occur in a private external clone.

## Audit posture

Permitted:

- read-only Git and byte inspection of the live checkout;
- static source/AST inspection that does not import repository modules;
- executable checks only in private external local clones;
- audit-local transformed mutant copies inside the external clone.

Prohibited:

- live-checkout imports;
- live-checkout pytest;
- editing, formatting, cleaning, or repairing live files;
- staging, committing, pushing, PR operations, or merging;
- remote or sibling-repository contact;
- opening or mutating an operator or product-state database;
- running migrations or services;
- installing dependencies;
- generating client-visible artifacts;
- subagents.

Remove all audit-created temporary data at closeout.

## Source-of-truth posture

Apply the repository authority hierarchy:

- Git owns commit/tree/blob/ref facts.
- `AGENTS.md` owns repository guidance and routing.
- `.docs/` owns current and accepted-target semantics within declared scopes.
- the operating model owns composition/current-status classification.
- source and migrations own current implemented behavior and representation.
- tests are evidence and drift guards, not semantic owners.
- reports are evidence only.

The selected target architecture remains:

- one standing-policy-admitted Coordinator authority lineage per bootstrap scope;
- operational realizations do not mint lineages or allowances;
- one active Coordinator authority per lineage;
- immutable admission fact;
- zero or one immutable bootstrap-acceptance fact;
- one productive direct-local acceptance per admitted lineage scope;
- permanent non-replenishment;
- acceptance fact in the durable decision family;
- no mutable latch subsystem;
- exact receipt-first replay;
- one whole-family recovery classifier;
- no fact on nonaccept branches;
- terminal nonmutation;
- later ES operation separately governed and non-replenishing;
- B1 legacy field names as compatibility/nonproof only;
- no guard implementation, storage, provisioner, reader, writer, public API, or
  runtime activation.

Do not reopen that architecture unless V4 introduced a direct contradiction.

## Required inspection

Read all 28 candidate paths and every unchanged owner/test edge needed to verify:

- C2 and guard owner authority;
- C2 pre-model/model split;
- replay and collision ownership;
- B1 compatibility source/schema behavior;
- migration inventory 0001–0004;
- package exports;
- StateStore and WriterSession;
- transaction/read/write surfaces;
- C2A nonimplementation;
- B1 phase-value/relation/vector/schema/budget tests;
- B2 Wire and cancellation-control tests;
- C2B3 program-initialization tests;
- runtime-nonauthority and public-surface guards.

Follow additional exact owner/test edges discovered.

## Audit question 1 — one-file V4 repair boundary

Verify:

- exactly one candidate file changed from V3 to V4;
- all other 27 candidate paths remain byte-identical to their supplied V3/V4
  receipts;
- all source, schemas, migrations, exports, StateStore, WriterSession, readers,
  writers, transactions, public surfaces, runtime surfaces, configuration, and
  examples remain byte-identical to HEAD;
- no normative contract or selected architecture changed;
- V4 contains test-observation, restoration, and scenario-integrity work only.

Any hidden semantic redesign or source widening is blocking.

## Audit question 2 — code-object observer authority and scope

Inspect the V4 code-object observer.

Require:

- exact target `__code__` identities for:
  - C2 model consistency;
  - C2 persisted-family replay;
  - C2 authoritative pre-model reduction;
  - guard receipt/collision check;
  - acceptance guard eligibility;
- entry observation by exact frame code identity before body effects;
- exact role-to-code mapping with no accidental alias collision;
- actual count and order recorded independently of returned trace markers;
- no result/reason/branch semantics authored by the observer;
- no production or physical guard model inside the observer;
- no claim of protecting arbitrary distinct-code bytecode clones.

The observer may protect exact target code objects and common reference shapes.
Do not credit or require a general proof against malicious creation of
semantically equivalent new code objects. Instead verify that the live verifier
does not use `CodeType`, code-object `.replace()`, `marshal`, `compile`, or
`exec` to create an unobserved semantic duplicate.

Block if a live target call path uses a different code object that carries the
same semantic role without an explicit owner or test boundary.

## Audit question 3 — independent outer observer

Do not rely only on V4's observer.

In the external clone, build an audit-local outer `sys.setprofile` observer
before entering the candidate observer. Bind it independently to the same exact
target code objects.

Require:

- the candidate observer chains the pre-existing callback;
- outer and candidate counts agree on all baseline cases;
- outer and candidate order projections reconcile;
- candidate exit restores the exact previous `sys` and `threading`
  profile/trace callbacks;
- exceptional exit also restores them;
- a new thread inherits the intended callback only while the observer is active;
- no callback remains after exit;
- nesting is rejected at the documented exact boundary or safely isolated.

A mismatch between independent outer observation and candidate observation is
blocking.

## Audit question 4 — actual-entry baseline matrix

Independently reproduce these expected code-object entry orders:

| Case | Exact expected order |
|---|---|
| unfenced caller | none |
| invalid session | none |
| lineage mismatch | fence only |
| missing admission | fence only |
| foreign admission | fence only |
| multiple active authorities | fence only |
| exact replay | fence → receipt → persisted replay |
| mutation-ref reuse conflict | fence → receipt → persisted replay |
| family-route collision | fence → receipt → pre-model |
| claimed scope | fence → receipt → pre-model → acceptance eligibility |
| unresolved scope | fence → receipt → pre-model → acceptance eligibility |
| eligible recognized acceptance | fence → receipt → pre-model → acceptance eligibility → model |
| eligible unrecognized recommendation | fence → receipt → pre-model → acceptance eligibility → model |
| repair | fence → receipt → pre-model → model |
| replan | fence → receipt → pre-model → model |
| terminal reject | fence → receipt → pre-model → model |
| post-execution block | fence → receipt → pre-model → model |

Every listed role has count one and every omitted role has count zero.

Derive nonaccept model expectations from the normative C2 owner, not from
observed test behavior.

## Audit question 5 — transformed callable paths

Independently reproduce external transformed copies for at least:

1. prebound tuple early model call;
2. prebound tuple early replay call;
3. early tuple call with returned trace marker removed;
4. early tuple call followed by the normal later call;
5. `functools.partial` early model call;
6. `functools.partial` early replay call;
7. dynamic `getattr` early model call;
8. a new function object using the same target code object;
9. duplicate replay with the first result discarded;
10. exact replay followed by fresh model evaluation;
11. exact replay followed by fresh guard eligibility;
12. hidden call from a new thread through a prebound reference.

Each negative must:

- retain exact expected collection;
- fail at an actual-entry count/order boundary;
- avoid syntax/import/format/collection shrinkage;
- be confirmed by the independent outer observer where applicable.

If one of these transformations is structurally impossible in the live
verifier, reproduce the exact structural rejection rather than silently
skipping it.

## Audit question 6 — reference-patching probe and restoration

The reference-patching probe is a secondary structural defense.

Require dynamic coverage for:

- defining-module attributes;
- imported aliases;
- dict registries;
- list registries;
- defaults;
- keyword defaults;
- closure cells;
- one-level wrappers where supported.

Require exact restoration after:

- normal delegation;
- wrapped-target exception;
- caller-body exception;
- a second probe;
- nested-probe rejection;
- profile callback exception if the verifier supports chaining such callbacks.

Independently mutate:

1. list restoration removed;
2. dict restoration removed;
3. default restoration removed;
4. closure restoration removed;
5. profile restoration removed;
6. trace restoration removed;
7. restoration skipped after target exception;
8. restoration skipped after caller exception.

Each must fail at an exact restoration boundary.

## Audit question 7 — immutable admission posture

Inspect the independently authored frozen guard posture and both command
fixtures.

Require the posture to bind:

- lineage identity;
- scope identity;
- admission-fact identity;
- admission-fact digest;
- admitted direct-local applicability;
- one active authority.

For both actual commands require exact binding to that posture before ledger
access.

The relation must be established from actual command coordinates and the
separate posture object—not a label, self-authored boolean, or builder-returned
expected result.

The behavior ledger must either:

- key on lineage, scope, admission identity, and admission digest; or
- have an exact pre-ledger binding that makes omission semantically impossible.

V4 claims both; independently verify both.

## Audit question 8 — cross-program scenario integrity

Require:

- same lineage;
- same scope;
- same admission fact identity and digest;
- same applicability;
- distinct nonempty program identities;
- program-specific head/basis bindings;
- distinct attempt/candidate lineage where declared;
- distinct mutation references;
- distinct command digests;
- first acceptance creates the one fact;
- second fresh command is rejected because the same admitted scope is claimed.

Independently reproduce external mutants for:

1. B admission ref and expectation changed together;
2. B admission digest and expectation changed together;
3. B admission ref and digest both changed;
4. builder admissions and relation comparison changed together;
5. pre-ledger admission validation removed;
6. admission omitted from ledger key;
7. program B collapsed to A;
8. B head/basis collapsed to A;
9. B attempt/candidate collapsed to A;
10. mutation ref reused;
11. command digest reused;
12. B moved to another scope;
13. B moved to another lineage;
14. same-program second attempt substituted.

Each must fail at a scenario-integrity or command-admission boundary before a
misleading ledger outcome receives credit.

A transformation that changes the posture and both commands together while
preserving all owner-defined relationships is a new valid fixture, not a
required failure. Do not mistake fixture-value identity for semantic authority.

## Audit question 9 — evidence classification

Verify the report and tests distinguish:

1. permanent internal negative controls that pass by catching exact expected
   exceptions;
2. external transformed mutant copies actually executed;
3. ordinary regression validation.

The 24 implementation-reported external mutants must exist as actual
transformations in the audit clone and fail their specified nodes.

Do not accept a claim that internal caught-exception tests are externally failed
mutants.

Classify this V4 closeout statement as report-only wording drift:

`EXTERNAL_ARTIFACTS_NOT_GENERATED`

The implementation necessarily generated disposable clones and transformed
copies, then removed them. The accurate nonclaim is that no external artifact
was retained or delivered. This wording defect is not a candidate-byte defect
unless repository text repeats the overclaim.

## Audit question 10 — all 24 implementation-reported external mutants

Independently reproduce all 24 exact transformations:

1. prebound tuple model before eligibility;
2. prebound tuple replay before fencing;
3. early model call with returned marker removed;
4. early model call plus normal later call;
5. partial-wrapped model call;
6. partial-wrapped replay call;
7. dynamic-`getattr` model call;
8. duplicate replay with discarded first result;
9. replay plus fresh model;
10. replay plus fresh guard;
11. B admission ref plus expectation changed;
12. B admission digest plus expectation changed;
13. B admission ref and digest changed;
14. builder admissions and relation comparison changed;
15. pre-ledger command-admission check removed;
16. B program collapsed to A;
17. B head/basis collapsed to A;
18. B mutation and digest reused from A;
19. B moved to another scope;
20. same-program second attempt substituted;
21. list restoration removed;
22. profile and trace restoration removed;
23. list restoration skipped after target exception;
24. list restoration skipped after caller exception.

Require:

- guard collection `289`;
- full repository collection `7,817`;
- exact intended failing node and boundary;
- no syntax/import/collection shrinkage;
- clean restoration of the clone between mutants.

If current collection differs, stop and explain rather than normalizing the
claim.

## Audit question 11 — additional independent mutants

In addition to the exact 24, independently test:

1. dict restoration removed;
2. default restoration removed;
3. closure restoration removed;
4. callback chaining removed while restoration remains;
5. new-thread callback installation removed;
6. nesting rejection removed without isolation;
7. admission digest omitted from ledger key;
8. same admission relation checked only after ledger lookup;
9. outer observer and candidate observer intentionally disagree;
10. one actual target role mapped to the wrong code object.

Each must fail at an exact restoration, ordering, binding, or observer-integrity
boundary.

## Audit question 12 — preserved architecture and owner split

Verify no regression in:

- Option A lineage policy;
- explicit standing-policy admission;
- one active authority;
- continuity fail-closed;
- local absence not proving eligibility;
- immutable admission and acceptance facts;
- cross-program one-shot ceiling;
- five branch effects;
- guard conflict no-write, never block;
- receipt-first replay;
- one complete-family recovery classifier;
- partial families unresolved;
- competing winner prohibits retry;
- terminal nonmutation;
- later ES non-replenishment;
- C2 versus guard owner non-overlap;
- B1 compatibility/nonproof;
- four-document normalized body;
- C2A/B2/progression/AGENTS/README routing;
- historical C2B/C2B3 preservation;
- P08/P11/P12/P13 substantive semantic supersession;
- type-exact human/machine equality;
- closed Markdown table parsing;
- complete operational-realization inventory;
- capability structured-evidence integrity;
- C2B current-status clarification.

Block:

- a second reducer;
- a second replay or recovery owner;
- acceptance fact on a nonaccept branch;
- guard conflict converted into durable block;
- partial family classified committed;
- competing winner allowing fresh retry;
- B1 pair treated as current durable proof;
- test-local physical guard implementation.

## Audit question 13 — selector reproducibility

For the exact four-module set:

- `tests/test_rw0_b2_capability_boundaries.py`
- `tests/test_c2b0_durable_state_contract.py`
- `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`
- `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py`

run `--collect-only -q` before each selector execution.

Expected:

| Selector | Selected / passed |
|---|---:|
| `code_object_actual_entry` | `7 / 7` |
| `actual_model_entry` | `14 / 14` |
| `prebound_callable_actual_entry` | `13 / 13` |
| `actual_replay_entry` | `9 / 9` |
| `code_object_probe_restoration` | `3 / 3` |
| `fencing_before_replay_actual` | `9 / 9` |
| `list_reference_restoration` | `4 / 4` |
| `model_after_guard_actual` | `13 / 13` |
| `shared_admission_integrity` | `8 / 8` |
| `capability_semantic_integrity` | `5 / 5` |
| `command_admission_binding` | `7 / 7` |
| `guard_ordering_integrity` | `4 / 4` |
| `cross_program_scenario_integrity` | `6 / 6` |
| `typed_human_machine_equivalence` | `14 / 14` |
| `cross_program_ceiling` | `1 / 1` |
| `closed_human_table` | `11 / 11` |
| `hostile` | `96 / 96` |
| `operational_realization` | `18 / 18` |
| `c2b_current_status_authority` | `3 / 3` |

No selector may select zero or unrelated tests.

## Audit question 14 — exact collection and validation

Create a private external local clone from exact committed HEAD without remote
contact. Overlay exactly the 28 verified candidate files.

The clone must have no configured remote.

Never import from or alter the live ignored cache.

Run serially with:

```text
PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=.:src
python3 -m pytest -q -p no:cacheprovider --basetemp=<external>
```

### Exact module collections and results

Expected:

| Run | Collection and result |
|---|---:|
| Guard verifier | `289 collected; 289 passed` |
| C2 + guard | `1,623 collected; 1,623 passed` |
| Four focused modules | `1,997 collected; 1,997 passed` |
| Exact 17-module command | `3,606 collected; 3,606 passed` |
| Exact broader command | `3,611 collected; 3,611 passed, 3 warnings` |
| Full repository | `7,817 collected; 7,817 passed, 3 warnings` |

### Guard verifier

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

### C2 plus guard

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_rw0_c2_durable_progression_decision_semantic_contract.py \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

### Four focused modules

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_rw0_b2_capability_boundaries.py \
  tests/test_c2b0_durable_state_contract.py \
  tests/test_rw0_c2_durable_progression_decision_semantic_contract.py \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

### Exact 17-module command

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_architecture_contracts.py \
  tests/test_rw0_remote_contact_phase_entry_contract.py \
  tests/test_remote_worker_pre_execution_planning_contract.py \
  tests/test_software_development_progression_boundary.py \
  tests/test_autonomous_software_development_operating_model.py \
  tests/test_c2a_first_slice_semantic_protocol_contract.py \
  tests/test_c2a_nonimplementation.py \
  tests/test_rw0_b1_phase_values.py \
  tests/test_rw0_b1_vectors.py \
  tests/test_rw0_b1_relations.py \
  tests/test_rw0_b1_boundaries.py \
  tests/test_rw0_b2_wire_boundaries.py \
  tests/test_rw0_b2_capability_boundaries.py \
  tests/test_rw0_b2_wire_cancellation_control_boundaries.py \
  tests/test_c2b0_durable_state_contract.py \
  tests/test_rw0_c2_durable_progression_decision_semantic_contract.py \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

### Exact broader command

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_c2a*.py \
  tests/test_worker_execution_semantic*.py \
  tests/test_rw0_b1*.py \
  tests/test_rw0_b2*.py \
  tests/test_rw0_c1*.py \
  tests/test_post_execution_pure_owner*.py \
  tests/test_c2b2*.py \
  tests/test_c2b3*.py \
  tests/test_section41*.py \
  tests/test_runtime_non_authority.py \
  tests/test_state_store_contract.py \
  tests/test_b2a_writer_session_contract.py \
  tests/test_sqlite*.py
```

### Full repository

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external>
```

The only expected warnings are the unchanged Python 3.13 multi-threaded
`fork()` deprecations from:

- `test_operation_guard_close_waits_and_retains_authority_until_exit`;
- `test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang`;
- `test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock`.

Investigate every count or warning mismatch.

Also require:

- `git diff --check`;
- both new-file `/dev/null` whitespace checks;
- UTF-8/BOM/CR/trailing-whitespace/final-newline checks;
- source/migration/public-surface preservation;
- C2B/C2B3 historical reconstruction;
- artifact scans.

## Audit question 15 — nonimplementation and protected surfaces

Independently verify:

- all tracked paths outside the candidate equal HEAD;
- all 66 source/resource paths equal HEAD;
- migrations exactly 0001–0004;
- migration `0005` absent;
- SQL resource hashes unchanged;
- package exports unchanged;
- StateStore, WriterSession, readers, writers, transactions unchanged;
- no guard/admission/acceptance source module;
- no provisioner;
- no durable decision writer;
- no reader/recovery implementation;
- no production caller;
- no public API;
- no runtime activation;
- no RW0-D/E or Execution Substrate modification;
- no product database or runtime artifact.

## Final live-cache and cleanup gate

After all external work and removal of the external clone, repeat the live cache
inventory using no repository imports.

Require exact equality with opening:

- members: `37`
- canonical bytes: `8,897`
- SHA-256:
  `3902e30eb9f5e229bb61b46d3b77a001f6b86371a717f9b3c324407d8818ebec`

Require no `tests/__pycache__` directory and no audit-created live path.

Remove every audit-created external clone, basetemp, transformed copy, and log.

Do not claim that external artifacts were never generated. State that no
audit-created external artifact was retained or delivered.

## Final provenance

After cleanup, require:

- exact baseline HEAD and branch;
- exact 28-path status and receipts;
- zero staged/unmerged paths;
- no additional path;
- exact complete patch;
- exact canonical receipt;
- unchanged source/migration/public surfaces;
- exact C2B and C2B3 historical reconstruction;
- exact ignored-cache opening/closing equality;
- no audit-created repository or delivered artifact.

Run patch and receipt calculations twice and require byte-identical outputs.

## Severity and verdict rules

Blocking findings include:

- provenance mismatch;
- live-cache drift;
- a live semantic target call outside both candidate and independent observer;
- outer and candidate code-object counts disagree;
- hidden early model or replay entry survives;
- duplicate or discarded call survives;
- callback or reference restoration failure;
- admission posture not independent from command builders;
- command admission not validated before ledger access;
- admission omitted from the ledger key without an equivalent exact binding;
- cross-program fixture not actually cross-program;
- any required external mutant survives;
- candidate evidence mislabeled as external transformed evidence;
- regression in Option A lineage or immutable-fact architecture;
- overlapping C2/guard replay or recovery authority;
- acceptance fact on a nonaccept branch;
- guard conflict converted to durable block;
- partial family classified committed;
- competing winner permitting retry;
- B1 legacy pair treated as durable proof;
- verifier becoming a shadow semantic owner;
- source/migration/public/runtime widening;
- unexplained collection, test-count, or warning mismatch.

### Accept

Use only when no unresolved High- or Medium-severity finding remains:

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_ACCEPTED_READY_FOR_COMMIT_GATE`

Acceptance authorizes only a separate commit/publication gate for the exact 28
audited paths.

It does not authorize:

- source or safe-value changes;
- migration `0005`;
- scope provisioning;
- durable decision writing;
- guard persistence;
- readers or recovery implementation;
- terminal persistence;
- public API widening;
- runtime activation;
- RW0-D/E;
- Execution Substrate work.

### Block

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_AUDIT_BLOCKED`

### Provenance mismatch

`AUDIT_PROVENANCE_MISMATCH`

## Inline report structure

Return:

1. primary verdict;
2. visible model/reasoning setting;
3. exact baseline and V4 candidate provenance;
4. patch, receipt, transition, historical-byte, and live-cache reconciliation;
5. inspection scope and limits;
6. one-file V4 repair-boundary audit;
7. code-object observer scope and independent outer-observer results;
8. actual-entry baseline matrix;
9. transformed callable-path mutants;
10. reference-patching restoration audit;
11. independent admission posture and cross-program scenario audit;
12. evidence-classification audit;
13. all 24 required external mutants;
14. additional independent mutants;
15. preserved architecture and owner split;
16. selector reproducibility;
17. independent collection and validation;
18. nonimplementation/protected-surface audit;
19. final live-cache and provenance;
20. severity-ranked findings;
21. exact next boundary;
22. required non-actions;
23. final token.

## Required non-actions

State:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIRS_NOT_PERFORMED
NORMATIVE_DOCUMENTS_NOT_MODIFIED
C2_VERIFIER_NOT_MODIFIED
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
SCHEMAS_NOT_MODIFIED
OTHER_27_CANDIDATE_PATHS_NOT_MODIFIED
NON_CEILING_DOCS_NOT_MODIFIED
NON_CEILING_TESTS_NOT_MODIFIED
OPERATOR_OR_PRODUCT_DATABASE_NOT_OPENED_OR_MUTATED
LIVE_IGNORED_CACHE_NOT_MOVED_OR_MODIFIED
DEPENDENCIES_NOT_INSTALLED
SERVICES_NOT_STARTED
REMOTE_CONTACT_NOT_PERFORMED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
MERGE_NOT_PERFORMED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
BOOTSTRAP_SCOPE_PROVISIONER_NOT_IMPLEMENTED
BOOTSTRAP_ACCEPTANCE_GUARD_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUBAGENTS_NOT_SPAWNED
EXTERNAL_ARTIFACTS_NOT_RETAINED_OR_DELIVERED
```
