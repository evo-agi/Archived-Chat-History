# Governed Execution Coordinator — RW0-C2 Bootstrap Guard Governing Reset V2 Test-Adequacy Repair

## Role and objective

Resume the original governing-reset implementation conversation after the
operator changes the parent permission posture to workspace-write.

Use the highest available Codex reasoning setting. Record exactly what the
interface visibly shows for:

- model name;
- reasoning setting or effort.

Do not infer hidden configuration; use `not visible` when necessary.

The parent is the sole repository writer. Do not spawn subagents.

Repair the exact uncommitted 28-path RW0-C2 bootstrap acceptance-guard
governing-reset candidate after its independent audit returned:

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_AUDIT_BLOCKED`

The audit found:

- exact provenance;
- no High-severity finding;
- no semantic-authority, source, migration, public-surface, or runtime widening;
- the intended Option A lineage policy and immutable-guard architecture
  substantively coherent;
- six Medium test/test-oracle defects;
- one Low C2B wording ambiguity.

This is a narrow five-file documentation/test repair. Do not reopen the selected
architecture or implement product behavior.

Return one substantive inline closeout report. Do not create or attach an
external report, manifest, package, patch, freeze artifact, or other
client-visible file.

## Repository and committed baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed baseline beneath the candidate:

- branch: `trunk_dev`
- HEAD: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- tree: `42cc0757b3d9604dfe7fdbda158074b8b48dac7b`
- sole parent: `db16de711986ae40a2bb848ed00cdddd3145ee02`
- subject: `docs: freeze RW0-C durable decision branch contract`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- zero staged paths
- zero unmerged paths
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Do not fetch or contact remotes.

## Exact opening 28-path candidate

Require exactly 26 tracked modifications and two untracked files and no other
difference from HEAD.

All 28 paths must be regular, non-symlink mode-`0644` files, valid UTF-8, with
no CR bytes, no trailing whitespace, and one final newline.

| # | Status | Path | Bytes | SHA-256 |
|---:|---|---|---:|---|
| 1 | `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 70,858 | `4fc2b7f9d5810105c28a7ce11abe85d08a48f915a87b088ae86e5520aa2142e2` |
| 2 | `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | 57,192 | `2c0c9565f7fb4ae79eca998080f3b70734f9a4fd1e555132daf9b94daab1dc97` |
| 3 | `M` | `.docs/c2a-first-slice-semantic-protocol-contract.md` | 103,413 | `a690441d046d147cf11a068e07a894858e3d32476e19fef84a9bb26e6e6f0d99` |
| 4 | `M` | `.docs/c2b-durable-development-state.md` | 1,889,083 | `db065fd8fd37d537bdac3194f021995dfcf2fbd92a31d2c7e4f0dc4c4e3a60d7` |
| 5 | `M` | `AGENTS.md` | 61,466 | `001595cdec75b176abbfb99b91b2b06c45f2f2ff1a28c704ded7054c27c7e74e` |
| 6 | `M` | `README.md` | 45,849 | `b66fb689d9f0849eee1d62f12dda93d83dcc9f4cce2fa008696878b44256ad1a` |
| 7 | `M` | `.docs/architecture.md` | 43,007 | `60a884471d655ee6eddad8c405aa218eab492e3c610b101c0736fc9f2546288f` |
| 8 | `M` | `.docs/autonomous-software-development-operating-model.md` | 37,829 | `115ed6c16141f821147f640131bed904526cee914dbec6951f3667b0da100f05` |
| 9 | `M` | `.docs/authority-boundaries.md` | 34,686 | `69d524c839a2195cf0b5840be424c021305825fd0db1d85c76ed28b99c1bf055` |
| 10 | `M` | `.docs/durable-state-model.md` | 40,564 | `e14a421698f0735fa098fe6ce1063b64d07e1c212fd6b60755e1068c9caf5955` |
| 11 | `M` | `.docs/worker-execution-boundary.md` | 30,920 | `6f7d2f7855fcbdecc757af4dde7a7bb091ab1e8c60057a2fefe407f74de4055f` |
| 12 | `M` | `.docs/software-development-progression-boundary.md` | 28,654 | `b8761655ee42512c0e77ab8c774c2b2d3d8f9ac36a9bd0c74872ad4bf2994419` |
| 13 | `M` | `.docs/c2b3-program-initialization.md` | 27,687 | `8e9c2c6f49551b28d95de28f6d7b071c89dd0ea155ce7d7a6e21e8d88e73d1f7` |
| 14 | `M` | `.docs/rw0-b2-wire-protocol.md` | 24,346 | `7f977a5a60fd66c69464190731e09611ca24854313e145b73cc73f564776477b` |
| 15 | `M` | `.docs/rw0-b2-capability.md` | 17,753 | `171341fc60cbe762403f1e64676ca35c9ea2f778a10d0fc66d668f1c84dc884c` |
| 16 | `M` | `.docs/rw0-b1-pure-phase-values.md` | 33,032 | `8bccdaa31fa66821b73c136936c12ef001157209c72b9991839905c1a8e0e053` |
| 17 | `M` | `tests/test_architecture_contracts.py` | 100,410 | `555ac490738d12075d3908ec2ddfd090fdbb32d8a6fd53d1b3136d24485e1169` |
| 18 | `M` | `tests/test_rw0_remote_contact_phase_entry_contract.py` | 173,524 | `42d6d265c0a9ba5047aa37ec3a4daae30847d486d39ead6374685b451a1d445c` |
| 19 | `M` | `tests/test_remote_worker_pre_execution_planning_contract.py` | 913,152 | `92b0f3917f0572492357447211a1f0f0cc7f8edb7e8b5f18233ed80397879b29` |
| 20 | `M` | `tests/test_software_development_progression_boundary.py` | 42,899 | `bd9b10f62e3bbfb3dc5fc845958fe0087363a0afa0b80649853faac85235c7a3` |
| 21 | `M` | `tests/test_autonomous_software_development_operating_model.py` | 72,904 | `e9a77edb1f99b181c612e52c4a7cfee814ac3f0df4d974e7c3a0756aec6da8df` |
| 22 | `M` | `tests/c2a_contract_support.py` | 154,372 | `58be92ddffae6f4b901ae3632521481ab8d9ce0e02a819ef9421408d08eedd85` |
| 23 | `M` | `tests/test_rw0_b1_boundaries.py` | 38,321 | `bd52384897f8f7a7129023c693ef67b1ff453a006723438dfa4f06df08e4121f` |
| 24 | `M` | `tests/test_rw0_b2_capability_boundaries.py` | 39,011 | `51e728f48b6c024f782f7b32b46e5c8de11bb519702e7478d3fb420655c4822a` |
| 25 | `M` | `tests/test_c2b0_durable_state_contract.py` | 882,642 | `deb6164d311189fa1eeab68dbf4296bdaf6b9bafe6e1808ce8122d1a8e4dd2ec` |
| 26 | `M` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | 245,532 | `718d10e2047b49a5e5baa65db92e434b0fcd1d23a821124529e13e10b26951ff` |
| 27 | `??` | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 25,151 | `bf65ba7f04411bb6e6febec2285b33721eb2ff895e2c60aee97878b1fa7c9b46` |
| 28 | `??` | `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | 35,975 | `d919401246964c0db667db5d42df7bcc454a689964bc11cf91913d181b2f604d` |

Required opening complete patch:

- bytes: `237,485`
- SHA-256:
  `aee578da6130705e8b1275397c53862060a3b2bff097c0a325cd985bfa8e9bbc`

Construct it in the table order with full-index binary Git diffs, using
`/dev/null` for the two new files.

Do not rely on the prior canonical-receipt digest because its envelope was not
fully specified. Produce a newly defined deterministic receipt at closeout and
report its exact grammar.

Stop before editing on any baseline, status, type, mode, size, per-file digest,
or patch mismatch:

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_V2_REPAIR_BLOCKED`

## Exact repair mutation ceiling

Only these five paths may change from their opening candidate bytes:

1. `.docs/c2b-durable-development-state.md`
2. `tests/test_c2b0_durable_state_contract.py`
3. `tests/test_rw0_b2_capability_boundaries.py`
4. `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`
5. `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py`

The final changed/untracked path set relative to committed HEAD must remain the
same exact 28 paths.

All other 23 candidate paths must remain byte-identical to the opening table.

Every source, migration, schema, package export, StateStore, WriterSession,
transaction, reader, writer, public, runtime, configuration, and example path
must remain byte-identical to HEAD.

Migration `0005` must remain absent.

## Accepted semantics that must not be reopened

Preserve the candidate’s accepted target architecture:

- one explicitly standing-policy-admitted Coordinator authority lineage per
  bootstrap scope;
- operational realizations do not create lineages or allowances;
- one active authority per lineage; active-active ambiguity fails closed;
- immutable bootstrap-scope admission fact;
- zero or one immutable bootstrap-acceptance fact;
- one productive direct-local acceptance per admitted lineage scope;
- permanent non-replenishment across restore, clone, replacement, relocation,
  grants, programs, attempts, candidates, commands, and ES transition;
- acceptance fact atomically integrated into the durable
  decision/version/head/result/receipt family;
- no mutable available/consumed latch subsystem;
- no acceptance fact on nonaccept branches;
- guard conflict is no-write, never durable block;
- receipt-first exact replay;
- one whole-family recovery classifier;
- partial families are unresolved;
- competing winner can prove original absence but forbids fresh retry;
- terminal is later and non-mutating;
- later ES operation is separately governed and non-replenishing;
- B1 `latch_postimage_*` fields are legacy compatibility names and nonproof;
- no implementation exists.

This repair is about causal test adequacy and one wording clarification, not
semantic redesign.

## Audit findings to close

### F1 — capability replacement assertions are deletable

Audit finding:

Replacing the semantic-supersession helper body in
`tests/test_rw0_b2_capability_boundaries.py` with `pass` retained collection and
passed the relevant 178 tests.

Required repair:

1. Refactor the capability semantic-supersession evidence so the test receives
   and compares a fixed structured result, rather than relying solely on
   assertion side effects in a helper.
2. The structured evidence must independently bind P08, P11, P12, and P13:
   - exact protected path;
   - exact contract class;
   - old identity changed;
   - replacement document identity;
   - exact replacement semantic markers;
   - unchanged purpose/ownership boundary.
3. A helper returning `None`, an empty mapping, missing one P entry, or omitting
   semantic markers must fail.
4. The new guard verifier must independently:
   - parse the capability test’s AST;
   - require the structured helper/evidence path;
   - require the caller to compare its exact result with fixed expectations;
   - reject `pass`, empty-body, call-only, or ignored-return implementations.
5. Also parse the four replacement documents directly in the guard verifier so
   capability-test source is not its own expected answer.
6. Do not merely add another hash check.

Exact external mutant:

- replace the capability semantic-evidence helper body with `pass` while
  retaining the call;
- preserve collection;
- require failure at an exact capability-semantic-integrity boundary.

### F2 — fencing-before-replay prose is not causally protected

Audit finding:

Reversing the guard owner’s normative fencing/replay prose passed all guard
tests.

The owner document is correct and outside this repair ceiling. Do not edit it.

Required repair:

1. Expand the guard verifier’s fixed prose inventory to cover the exact
   ordering requirements.
2. Parse the relevant normative ordered list or table structurally, not by broad
   substring presence.
3. Require:
   - writer/session admission and fencing precede protected receipt/collision
     disclosure;
   - receipt-first replay/collision handling precedes fresh guard eligibility;
   - fresh acceptance eligibility precedes family construction;
   - model consistency is after every guard gate.
4. Bind each ordering edge to an exact fixed expectation and an exact failure
   boundary.
5. Reversing either side of an edge must fail without depending on machine JSON
   or a second prose copy.

Exact external mutants:

- reverse fencing and receipt lookup;
- move fresh guard eligibility before receipt replay;
- move model consistency before guard eligibility.

### F3 — human/machine comparison is not type-exact

Audit finding:

Python equality allowed human `true` to equal machine `1`, and human `0` to
equal machine `false`.

Required repair in both:

- `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`
- `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py`

Implement and use one local recursive **type-exact** comparison policy in each
module:

- mappings: exact built-in mapping type required by that verifier, exact key
  set/order where normative, and recursive value comparison;
- lists/tuples: exact declared container type, length, order, and recursive
  comparison;
- booleans: type `bool` only;
- integers: type `int` but not `bool`;
- strings: type `str`;
- null: exact `None`;
- no numeric/bool coercion;
- no subclass equivalence;
- exact JSON-pointer or table-role failure location.

Permanent integrity tests must cover at least:

- human `true` versus machine `1`;
- human `1` versus machine `true`;
- human `false` versus machine `0`;
- human `0` versus machine `false`;
- sibling strings and null/value mismatch.

Each must fail at an exact type/equivalence boundary.

Do not change the normative machine inventories or scalar meanings.

### F4 — the human Markdown inventory is not closed

Audit finding:

The guard parser ignored an added contradictory Markdown row when its values
lacked backticks.

Required repair:

1. Identify every normative human table by exact heading/table markers.
2. Parse every nonblank table line between its exact boundaries.
3. Require exact header and separator rows.
4. Require the exact declared column count for every data row.
5. Parse cells whether or not they contain backticks.
6. Reject:
   - unrecognized rows;
   - duplicate role/key rows;
   - extra rows;
   - missing rows;
   - unescaped pipes or malformed cells;
   - values that cannot be converted under the table’s declared grammar.
7. Compare the complete parsed row set, with type-exact values, to independent
   fixed expectations and machine data.
8. Do not silently skip a syntactically plausible row.

Exact external mutants:

- add `scope.identity = database` without backticks;
- add a duplicate conflicting row;
- remove backticks from a legitimate row;
- add an extra column;
- add an unparseable value.

The first two must fail because the complete row inventory changed, not because
of incidental formatting.

### F5 — the composed oracle evaluates model consistency before guard eligibility

Audit finding:

The guard verifier called the complete C2 interpreter before actual acceptance
posture. With a claimed scope, the inner trace reached
`model_consistency_evaluated` before the outer guard returned
`bootstrap_acceptance_guard_conflict`.

The owner contracts require model consistency after every guard gate.

Required repair:

1. Do not add another reducer.
2. Refactor the existing test-local C2 oracle into:
   - an authoritative pre-model phase that performs existing basis/currentness/
     matrix/branch derivation and returns the derived branch, retained evidence,
     trace, and deferred model inputs;
   - one model-consistency phase applied only after all authoritative guard
     gates pass.
3. Preserve a convenience wrapper used by ordinary C2 tests that composes:
   pre-model C2 → model consistency, so existing standalone C2 semantics remain
   unchanged.
4. The guard composed oracle must mirror the owner-defined ordering exactly:
   - command-local structural checks and writer/session fencing remain before
     protected receipt/collision disclosure;
   - receipt-first exact replay and collision handling remain before every
     fresh branch or guard evaluation;
   - on a fresh command, universal lineage/admission/continuity/
     sole-authority posture is evaluated at its existing owner-defined stage;
   - C2 pre-model authoritative reduction derives the branch;
   - acceptance-only guard eligibility is evaluated only for derived
     acceptance;
   - model consistency is evaluated last, after every applicable guard gate;
   - final projection follows.
   Do not move a universal check merely to satisfy a trace assertion; preserve
   the normative owner order and add exact trace markers for it.
5. Earlier no-write at any universal or acceptance-only guard gate must omit
   `model_consistency_evaluated`.
6. Exact replay must remain receipt-first and must not run fresh branch, guard,
   or model evaluation.
7. Guard conflict remains no-write, never block.
8. Preserve all existing C2 matrix/currentness/branch/model causality tests.

Required direct cases:

- claimed scope + otherwise valid acceptance;
- unresolved scope + otherwise valid acceptance;
- lineage mismatch;
- multiple active authorities;
- accepted unclaimed scope with recognized recommendation;
- accepted unclaimed scope with out-of-vocabulary recommendation;
- nonaccept branches under exact universal posture;
- exact replay.

Required trace ordering:

```text
receipt_replay_checked
...
authoritative_branch_derived
bootstrap_guard_evaluated   # acceptance only
model_consistency_evaluated # only after every earlier gate passes
```

Exact external mutant:

- invoke model consistency before the guard eligibility call;
- preserve collection;
- require failure at an exact trace/order boundary.

### F6 — operational-realization nonidentity is incomplete

Audit finding:

The fixed causal cases omitted deployment, attempt, candidate, and command; a
deployment-specific fresh-allowance mutant survived.

Required repair:

1. Create one fixed closed operational-realization inventory matching the
   accepted owner contract, including at least:
   - deployment;
   - machine;
   - process;
   - database;
   - database file;
   - repository;
   - program;
   - attempt;
   - candidate;
   - command;
   - parent grant;
   - restore;
   - rollback;
   - clone;
   - passive backup;
   - relocation.
2. Independently parse the owner’s normative inventory and compare exact set
   equality with the fixed test inventory.
3. Parameterize a causal hostile for every member:
   changing only that realization must not create an independent lineage,
   scope, or fresh allowance.
4. Preserve the separately admitted independent-lineage positive case.
5. Removing one realization from parameterization must fail a fixed completeness
   assertion rather than silently reducing collection.

Exact external mutants:

- deployment creates a fresh allowance;
- attempt creates a fresh allowance;
- candidate creates a fresh allowance;
- command creates a fresh allowance.

Each must fail at an exact realization-specific boundary.

### L1 — C2B successor wording is overbroad

Audit finding:

The append-only successor can be read as classifying the complete opening C2B
document, including later current-status successors, as historical/proof
evidence.

Required repair:

1. Modify only the candidate’s appended successor region after the exact
   committed 1,887,232-byte prefix.
2. State unambiguously that:
   - historical mutable-latch sections and their physical selections are
     historical/proof precursors or reopened choices;
   - later committed current-status successors, current migration facts,
     current owner routing, and current-family statements retain their existing
     authority;
   - the successor supersedes only mutable-latch target representation, not the
     complete opening document.
3. Update `tests/test_c2b0_durable_state_contract.py` with an exact hostile that
   broadens the classification to the whole opening document and require
   rejection at a specific current-status-authority boundary.
4. Preserve the complete committed prefix byte-for-byte.
5. Do not rewrite historical text.

## Test architecture requirements

### Independent authorship

Keep these layers independent:

- fixed expectations;
- parsed normative prose/tables;
- parsed machine JSON;
- test-oracle output;
- capability semantic evidence;
- hostile expectations.

No mutable table may author both expected and observed truth.

### Duplicate-key rejection

Preserve recursive duplicate-key rejection for every normative JSON object and
hostile copy.

### Exact failure boundaries

Every new positive/hostile/integrity test must assert:

- exact exception class;
- exact boundary/reason identifier;
- exact path/row/key/stage where applicable.

Bare `pytest.raises(AssertionError)` without an exact boundary receives no
semantic credit.

### No shadow implementation

Do not add:

- a production reducer;
- a second semantic owner;
- a second replay or recovery classifier;
- a source-behavior emulator;
- a complete physical guard model.

The work remains test-oracle integrity plus the C2B clarification.

## Required external mutant battery

In disposable external copies, rerun all original 24 audit mutants and add at
least these repair-specific variants:

1. capability semantic-evidence helper body replaced by `pass`;
2. capability helper returns an empty mapping;
3. fencing/replay prose order reversed;
4. guard eligibility moved before receipt replay;
5. model consistency moved before guard eligibility;
6. human `true` changed to `1`;
7. human `0` changed to `false`;
8. unbackticked contradictory scope row added;
9. duplicate human row added;
10. extra Markdown table column added;
11. deployment creates a fresh allowance;
12. attempt creates a fresh allowance;
13. candidate creates a fresh allowance;
14. command creates a fresh allowance;
15. C2B successor classifies the complete opening document as historical.

For every mutant require:

- unchanged expected collection;
- failure at the intended exact boundary;
- no syntax-only, formatting-only, import-only, or collection-shrinkage
  failure.

Report exact failed test IDs or boundary IDs.

## Validation

Run all pytest commands serially in a clean local-only external clone with:

```text
PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=.:src
-p no:cacheprovider
--basetemp=<external path>
```

Do not move, rewrite, import through, or delete the live ignored cache.

### Focused repair modules

Run:

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_rw0_b2_capability_boundaries.py \
  tests/test_c2b0_durable_state_contract.py \
  tests/test_rw0_c2_durable_progression_decision_semantic_contract.py \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

Before execution, record `--collect-only -q` counts for each module and for the
combined command. No opening candidate collection may shrink; additions must be
explained.

Add uniquely reproducible selectors for at least:

```text
-k capability_semantic_integrity
-k guard_ordering_integrity
-k typed_human_machine_equivalence
-k closed_human_table
-k model_after_guard
-k operational_realization
-k c2b_current_status_authority
-k hostile
```

Run `--collect-only -q` and then execute each selector against the exact
relevant module set. No selector may select zero or unrelated tests.

### Exact prior targeted command

Rerun the original 17-module targeted command:

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_architecture_contracts.py \
  tests/test_rw0_remote_contact_phase_entry_contract.py \
  tests/test_remote_worker_pre_execution_planning_contract.py \
  tests/test_software_development_progression_boundary.py \
  tests/test_autonomous_software_development_operating_model.py \
  tests/test_c2a_first_slice_semantic_protocol_contract.py \
  tests/test_c2a_nonimplementation.py \
  tests/test_rw0_b1_phase_values.py \
  tests/test_rw0_b1_vectors.py \
  tests/test_rw0_b1_relations.py \
  tests/test_rw0_b1_boundaries.py \
  tests/test_rw0_b2_wire_boundaries.py \
  tests/test_rw0_b2_capability_boundaries.py \
  tests/test_rw0_b2_wire_cancellation_control_boundaries.py \
  tests/test_c2b0_durable_state_contract.py \
  tests/test_rw0_c2_durable_progression_decision_semantic_contract.py \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

Opening-candidate reference: `3,459 passed`.

### Exact prior broader command

Rerun:

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_c2a*.py \
  tests/test_worker_execution_semantic*.py \
  tests/test_rw0_b1*.py \
  tests/test_rw0_b2*.py \
  tests/test_rw0_c1*.py \
  tests/test_post_execution_pure_owner*.py \
  tests/test_c2b2*.py \
  tests/test_c2b3*.py \
  tests/test_section41*.py \
  tests/test_runtime_non_authority.py \
  tests/test_state_store_contract.py \
  tests/test_b2a_writer_session_contract.py \
  tests/test_sqlite*.py
```

Opening-candidate reference: `3,607 passed, 3 warnings`.

### Full repository

Run:

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external>
```

Opening-candidate reference: `7,670 passed, 3 warnings`.

Final counts may increase but must not shrink without an exact, justified
collection change. The only expected warnings remain the three unchanged Python
3.13 multi-threaded `fork()` deprecations in writer-session tests.

Also require:

- `git diff --check`;
- UTF-8/CR/trailing-whitespace/final-newline checks for all 28 paths;
- both new-file `/dev/null` whitespace checks;
- exact committed C2B prefix preservation;
- exact source/migration/schema/public/runtime preservation;
- artifact scan.

No product or operator database may be opened.

## Live cache and temporary data

At opening and closeout, record a safe repository-relative inventory of the 37
pre-existing ignored cache members:

- path;
- type;
- mode;
- size;
- modification timestamp;
- SHA-256.

Require exact member equality. Define and report the canonical serialization
used for any aggregate digest; do not compare against an unspecified historical
envelope.

Remove only engagement-created temporary data.

## Closeout provenance

Return inline:

1. primary outcome token;
2. visible model/reasoning setting;
3. opening and closing Git coordinates;
4. exact final 28-path receipt table;
5. exact five-file opening-to-closing transition;
6. proof the other 23 candidate paths stayed byte-identical;
7. C2B committed-prefix preservation;
8. capability semantic-integrity repair;
9. ordering/model-after-guard repair;
10. type-exact human/machine repair;
11. closed human-table parser repair;
12. operational-realization completeness;
13. all original and new mutant results;
14. selector collection/execution results;
15. focused, targeted, broad, and full validation;
16. source/migration/public/runtime preservation;
17. deterministic complete binary patch bytes and SHA-256;
18. a fully specified canonical receipt grammar, bytes, and SHA-256;
19. cache opening/closing equality;
20. cleanup and artifact posture;
21. remaining physical/value seams;
22. all required non-actions.

Calculate the final complete patch twice, in the original 28-path order, and
require byte-identical output.

Calculate the fully specified canonical receipt twice with two independent
implementations and require byte-identical output.

Do not stage, commit, push, create/modify a PR, or merge.

## Success token

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_REPAIRED_V2_VALIDATED_READY_FOR_REAUDIT`

Success authorizes only a fresh independent read-only audit of the exact repaired
28-path candidate.

## Blocking token

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_V2_REPAIR_BLOCKED`

Use the blocking token if:

- the opening candidate differs;
- the five-file repair ceiling is insufficient;
- source or migration changes are required;
- accepted semantics would need to change;
- a direct governing contradiction is found;
- any non-ceiling candidate path must change.

Do not leave partial repair bytes under a blocking outcome; restore the exact
opening candidate.

## Required non-actions

State:

```text
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
SCHEMAS_NOT_MODIFIED
OTHER_23_CANDIDATE_PATHS_NOT_MODIFIED
NON_CEILING_DOCS_NOT_MODIFIED
NON_CEILING_TESTS_NOT_MODIFIED
OPERATOR_OR_PRODUCT_DATABASE_NOT_OPENED_OR_MUTATED
LIVE_IGNORED_CACHE_NOT_MOVED_OR_MODIFIED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
BOOTSTRAP_SCOPE_PROVISIONER_NOT_IMPLEMENTED
BOOTSTRAP_ACCEPTANCE_GUARD_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
REMOTE_CONTACT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
MERGE_NOT_PERFORMED
SUBAGENTS_NOT_SPAWNED
EXTERNAL_ARTIFACTS_NOT_GENERATED
```
