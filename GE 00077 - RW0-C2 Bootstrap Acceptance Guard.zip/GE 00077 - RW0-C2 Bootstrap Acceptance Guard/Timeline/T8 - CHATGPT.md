## Decision recorded

Option A now closes the product-policy seam:

> One explicitly admitted Coordinator authority lineage owns one bounded direct-local bootstrap scope. Operational realizations—including deployments, machines, databases, restores, relocations, and clones—do not create new scopes. A separate lineage requires a separate standing-policy admission act.

The unexecuted standalone latch-owner prompt remains unexecuted and is now **formally superseded**. :chatgpt-content-reference{index="0"}

The successor architecture follows the adversarial recommendation: record the protected event directly as one immutable bootstrap-acceptance fact in the durable decision family rather than maintaining a second mutable `available → consumed` object. :chatgpt-content-reference{index="1"} The retained invariant is still cross-program and distinct from command replay: two independently valid commands for different programs must not both commit productive bootstrap acceptance. :chatgpt-content-reference{index="2"}

## Tranche boundary

The contract amendment touches exactly eight paths:

```text
.docs/architecture.md
.docs/autonomous-software-development-operating-model.md
.docs/c2b-durable-development-state.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/rw0-c2-durable-progression-decision-semantic-contract.md
.docs/rw0-c2-bootstrap-acceptance-guard-contract.md
tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
tests/test_rw0_c2_bootstrap_acceptance_guard_contract.py
```

The existing durable-decision owner remains authoritative for branch derivation, command/result/receipt roles, replay, and the single whole-family recovery classifier. The new guard owner is authoritative only for:

- standing-policy admission of a Coordinator authority lineage;
- immutable scope-admission facts;
- lineage continuity and sole-active-authority requirements;
- the cross-program one-shot ceiling;
- the immutable bootstrap-acceptance fact;
- permanent non-replenishment;
- guard-facing terminal semantics.

The prompt deliberately prevents the new guard document from becoming a second replay or recovery owner.

### Fail-closed distinction

The contract freezes this operational distinction:

- Unresolved lineage identity, continuity, admission, or sole-active-authority posture blocks every RW0-C2 branch.
- When lineage is exact but only the scope’s claimed/unclaimed status cannot be proven, acceptance is no-write. A nonaccept branch may proceed only when it does not depend on unclaimed status and every other branch precondition remains exact; it creates no acceptance fact.

This preserves terminal/block and bounded repair/replan semantics without allowing uncertainty to become a second acceptance.

## Codex handoff

Start a **fresh parent-only Codex conversation**, select the **highest available reasoning setting**, and send the prompt below. The prompt requires Codex to record the visible model and reasoning setting exactly; it must report `not visible` rather than infer hidden configuration.

:chatgpt-content-reference{index="5"}[Download the RW0-C2 bootstrap acceptance-guard semantic amendment prompt](sandbox:/mnt/data/Coordinator_RW0_C2_Bootstrap_Acceptance_Guard_Semantic_Amendment_Prompt.txt)

```text
Filename:
Coordinator_RW0_C2_Bootstrap_Acceptance_Guard_Semantic_Amendment_Prompt.txt

Size:
32,677 bytes

SHA-256:
1858c5b281c208c08734ff763f9ce6ab7217168228056a988dde51b22442a7d6

Logical lines:
1,012

Final newline:
present
```

The prompt requires the merged semantic owner to remove as mandatory architecture:

```text
mutable available/consumed latch state
latch revision transition
expected available-preimage latch digest
preassigned consumed-latch postimage
separate latch replay truth
separate latch recovery classifier
```

It replaces those concepts with:

```text
immutable standing-policy-admitted scope fact
+ exact lineage continuity and one-active-authority proof
+ zero-or-one immutable bootstrap-acceptance fact
+ atomic membership in the decision/result/receipt family
+ one replay path
+ one three-way family classifier
```

It also freezes:

- database or row absence never proving an unclaimed scope;
- cloned/restored copies never creating independence;
- a competing complete winner making retry ineligible even when the original command is provably not committed;
- decision-without-acceptance-fact and acceptance-fact-without-decision as `unresolved`;
- no reset, renewal, deletion, or replenishment;
- later ES-routed operation as separate and non-replenishing;
- terminal outcome as later and non-mutating.

Physical representation remains deliberately open: migration-free reuse, migration `0005`, and bounded hybrid remain engineering options for a later value/physical-family freeze.

Success token:

```text
RW0_C_BOOTSTRAP_ACCEPTANCE_GUARD_SEMANTIC_AMENDMENT_WRITTEN_VALIDATED_READY_FOR_INDEPENDENT_AUDIT
```

Blocking token:

```text
RW0_C_BOOTSTRAP_ACCEPTANCE_GUARD_SEMANTIC_AMENDMENT_BLOCKED
```

A successful result authorizes only a fresh independent read-only audit of the exact eight-path candidate. It does not authorize source, migration, provisioning, writer, reader, terminal, public, runtime, RW0-D/E, or Execution Substrate implementation.

**Sources:** The standalone-latch recommendation was reconnaissance inference rather than accepted contract, and it identified the same non-redundant cross-program ceiling. :chatgpt-content-reference{index="3"} The later independent challenge was expressly adversarial evidence, not an implementation or audit result. :chatgpt-content-reference{index="4"}

**Confidence:** High. The product-policy ambiguity is resolved, the immutable-fact architecture is selected, and the amendment boundary cleanly separates semantic ownership from the later physical and implementation decisions.
