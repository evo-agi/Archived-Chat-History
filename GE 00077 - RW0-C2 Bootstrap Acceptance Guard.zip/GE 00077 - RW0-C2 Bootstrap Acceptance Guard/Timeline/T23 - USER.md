Here is Codex's response:

### 1. Primary verdict

**`AUDIT_PROVENANCE_MISMATCH`**

The live ignored cache had 37 members at opening and 49 at closeout. Twelve `.pyc` files appeared during the audit. A delegated explorer confirmed running repository imports from the live checkout without bytecode suppression. I stopped further correctness runs and left the cache untouched because the request forbids changing it.

The completed adversarial checks also found **two blocking verifier gaps**. This candidate is not ready for the commit gate.

### 2. Visible model and reasoning setting

- Model name shown to this audit interface: **not visible**
- Reasoning setting or effort shown: **not visible**

I cannot verify that the highest available setting was selected.

### 3. Baseline and V3 candidate provenance

At opening and final recheck: branch `trunk_dev`; HEAD `6f11d6b0b6f38995123434945d86db0b169bb8f8`; tree `42cc0757b3d9604dfe7fdbda158074b8b48dac7b`; sole parent `db16de711986ae40a2bb848ed00cdddd3145ee02`; subject `docs: freeze RW0-C durable decision branch contract`; upstream `origin/trunk_dev`, `0 ahead / 0 behind`; one worktree; zero staged or unmerged paths. No active Git operation was found.

The status set remained exactly **26 tracked modifications and two untracked files**. All 28 matched the supplied byte counts and SHA-256 values and were regular mode-`0644` UTF-8 files with the required newline and whitespace form. All 212 tracked paths outside the candidate matched HEAD.

### 4. Patch, receipt, transition, and historical bytes

Both ordered patch assemblies were identical: **308,892 bytes**, SHA-256 `1d875ae83857db8fc4dd4c142800ced5682ff03c384c3e95430c5e33b48ea682`. Independent Python and Ruby canonical-receipt encoders produced **5,593 bytes**, SHA-256 `a59f7c53ae4cbbdf33d7c5b69bd7ece58f2ada796c0195536bec23a0b687f8ae`. Patch and receipt calculations were repeated at closeout with the same results.

The C2B document retained the exact 1,887,232-byte committed prefix and 2,097-byte appendix with the supplied hashes. Removing the specified 940-byte C2B3 insertion reconstructed HEAD exactly. The V3 guard verifier matched its supplied **89,437-byte** receipt. The historical V2 file was unavailable in the sole permitted checkout, so the claimed *exactly one-file* V2-to-V3 transition could not be independently reconstructed.

### 5. Inspection scope and limits

I byte-checked all 28 candidate paths and inspected their changed contract and test portions, the C2 and guard owners, relevant B1/B2 and progression edges, source, migrations, exports, and mutation surfaces. Dynamic checks ran in disposable external local clones. No remote or sibling repository was contacted.

The cache mismatch required a halt. Consequently, the full repository test run and the 17-module and broader runs do **not** have completion results.

### 6. One-file repair boundary

The V3 receipts show no source, schema, migration, export, configuration, or runtime change from HEAD. The visible repair work is in the guard verifier’s observation and scenario tests. Historical V2 bytes for the other 27 paths were not available for an independent transition comparison.

### 7. Actual callable graph

The composed [guard evaluator](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py:394>) calls the guard relation, receipt helper, C2 pre-model reducer, acceptance eligibility when applicable, C2 guard gate, and C2 model phase. The [receipt helper](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py:989>) checks presence and delegates to C2’s replay function; it adds no independent replay taxonomy.

The live model and replay references are their C2 defining-module attributes and the guard module’s imported aliases. No target-bearing registry, default, closure, tuple, partial, bound callable, or dynamic `getattr` route is live. C2’s existing `functools.partial` values bind unrelated witness helpers.

### 8. Independent code-object observation

A disposable `sys.setprofile` observer counted entry by the exact C2 model and replay `__code__` objects. On the unmodified candidate, its counts agreed with the candidate probe across all 17 tested cases.

An external mutant held the original callables in a prebound tuple, then discarded extra calls before fencing and guard eligibility. The candidate probe still reported its expected counts; the independent observer saw **unfenced model 1 versus probe 0**, **unfenced replay 1 versus probe 0**, and duplicate entries on accepted or replay paths. The complete **7,778-node collection** and **1,584 passing C2-plus-guard tests** survived that mutant. The [probe’s reference scan](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py:1073>) does not cover that shape, and its source-integrity check does not prohibit it.

### 9. Model-entry causality

For the unmodified candidate, independent counts were zero on replay, lineage/admission/active-authority failures, claimed or unresolved acceptance scope, and pre-fence cases. Recognized and unrecognized eligible acceptance each entered once. All four valid nonaccept branches entered once after their applicable no-write gates, as required by [C2 steps 7–8](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-c2-durable-progression-decision-semantic-contract.md:362>). Accepted order was fence → receipt → pre-model → acceptance guard → model.

The tuple mutant proves these passing live-case tests do not reliably reject a hidden early entry.

### 10. Replay and fencing causality

The unmodified candidate made no receipt or persisted replay call before fencing or universal admission. Fresh acceptance entered the receipt helper once and persisted replay zero times; exact replay and mutation conflict each entered persisted replay once, without fresh reduction. Family-route collision stopped after the receipt and pre-model stages. The tuple mutant made an additional discarded persisted replay call before fencing without failing the focused suite.

### 11. Probe integrity and restoration

The current probe patches canonical attributes, aliases, shallow dict/list registries, direct defaults, keyword defaults, and direct closure cells. It records before delegation and restores its patched identities when the wrapper raises. An explicit supplied-list check confirmed current list restoration.

A second external mutant removed only manual list restoration. The **1,584 focused tests still passed** because no existing test supplied a target-bearing list. When an audit-local list was supplied, the probe raised `guard:actual_entry:restoration` but left that list entry wrapped. Thus the current code restores it, while the suite does not protect that restoration path. Nested-probe behavior was not independently established.

### 12. Cross-program scenario integrity

The live scenario uses distinct program, basis, attempt/candidate, mutation, and digest coordinates under one lineage, scope, and admission. Nine single-coordinate changes failed precise scenario assertions.

A **coupled mutant survived**: program B’s admission changed from `A` to `A2`, and the verifier’s shared-admission expectation changed with it. The ordered 7,778-node collection was identical; all **250 guard** and **1,584 C2-plus-guard** tests passed. The behavioral test creates a fresh posture without binding each command’s admission and keys its ledger only by lineage and scope ([scenario test](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py:468>)). No third invariant catches the changed admission. That defeats the same immutable admission premise required by the [guard owner](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md:25>).

### 13. Preserved architecture and owner split

The inspected contracts retain Option A’s explicit standing-policy admission, one active authority, permanent cross-program one-shot ceiling, five branch effects, receipt-first replay, one whole-family recovery classifier, nonaccept no-fact behavior, terminal nonmutation, later ES non-replenishment, and the B1 legacy pair as compatibility rather than proof. C2 owns branch, replay, and recovery semantics; the guard owns admitted lineage, scope, eligibility, and acceptance-fact semantics. These are target contracts, with no guard runtime implemented.

### 14. Negative mutants and parser probe

The repository contains no manifest or transformations for the stated **historical 44 + 14 + 18 external mutants**. I cannot claim their exact reproduction from the permitted source alone. An audit-local reconstruction identified 76 **internal negative probes**: their 70 pytest nodes **passed by catching the stated exact exception**, so they are not 76 externally failed pytest nodes. The legitimate unbackticked human-table parser probe passed.

The complete reconstructed ID-to-boundary map is below. Each range shares the named pytest node; “→” gives the intended and observed caught assertion. `O01–O16` use `test_inventory_hostiles_have_exact_boundaries` and prefix `guard:inventory:`:

```text
O01 scope.identity→/scope/identity; O02 scope.independence→/scope/independence
O03 scope.active_authorities→/scope/active_authorities
O04 scope.local_absence_is_proof→/scope/local_absence_is_proof
O05 scope.distinct_productive_acceptances→/scope/distinct_productive_acceptances
O06 branch_effects.candidate_repair→/branch_effects/candidate_repair
O07 eligibility.conflict_outcome→/eligibility/conflict_outcome
O08 family.replay_new_fact→/family/replay_new_fact
O09 family.replay_new_timestamp→/family/replay_new_timestamp
O10 family.committed_exact→/family/committed_exact
O11 family.competing_winner_retry→/family/competing_winner_retry
O12 terminal.mutates_guard→/terminal/mutates_guard
O13 es.replenishes→/es/replenishes
O14 b1.durable_guard_proof→/b1/durable_guard_proof
O15 implementation.writer→/implementation/writer
O16 relation.authority→/relation/authority
```

`O17–O34` use `test_prose_only_drift_has_exact_boundary`; the prefix is `guard:prose:` except the two ordering entries:

```text
O17 scope; O18 sole_active; O19 local_absence; O20 cross_program
O21 nonreplenishment; O22 universal; O23 acceptance_only; O24 nonaccept
O25 membership; O26 replay; O27 partial; O28 competing_winner
O29 terminal; O30 es; O31 b1
O32 fencing_before_receipt→guard_ordering_integrity:fencing_before_receipt
O33 replay_before_eligibility→guard_ordering_integrity:replay_before_eligibility
O34 implementation
```

`O35–O44` use `test_closed_human_table_hostile`, prefix `guard:closed_human_table:`:

```text
O35 bare_duplicate→duplicate:scope.identity; O36 duplicate→duplicate:scope.identity
O37 extra→extra:scope.extra; O38 missing→rows:Scope
O39 column→columns:Scope:1; O40 value→value:scope.identity
O41 header→header:Authority; O42 separator→separator:Authority
O43 pipe→columns:Scope:1; O44 cell→cell:scope.identity
```

`A01–A08` use `test_typed_human_machine_equivalence_guard_scalars`; `A09–A14` use `test_typed_human_machine_equivalence_guard_document`. Prefix: `guard:human_machine_equivalence:`.

```text
A01 True→1→/role:type; A02 1→True→/role:type
A03 False→0→/role:type; A04 0→False→/role:type
A05 sibling→original→/role:value; A06 None→value→/role:type
A07 [True]→[1]→/role/0:type; A08 (1,)→[1]→/role:type
A09 scope.active_authorities 1→true→/scope.active_authorities:type
A10 relation.command_digest_covered true→1→/relation.command_digest_covered:type
A11 branch_effects.candidate_repair 0→false→/branch_effects.candidate_repair:type
A12 terminal.mutates_guard false→0→/terminal.mutates_guard:type
A13 scope.identity original→sibling→/scope.identity:value
A14 family.separate_receipt false→null→/family.separate_receipt:type
```

`V01–V08` are routes inside `test_actual_call_probe_hostile_alias_registry_and_restoration`; `V09–V13` use `test_cross_program_scenario_integrity_hostile`; `V14–V18` use `test_actual_call_probe_source_hostile`:

```text
V01 model alias; V02 model registry; V03 model default; V04 model closure
  → guard:actual_entry:forbidden:model:zero_probe
V05 replay alias; V06 replay registry; V07 replay default; V08 replay closure
  → guard:actual_entry:forbidden:persisted_replay:zero_probe
V09 program→guard:cross_program_scenario:program_identity_distinct
V10 basis→guard:cross_program_scenario:program_basis_binding:/0:value
V11 command→guard:cross_program_scenario:command_identity_distinct:mutation_ref
V12 scope→guard:cross_program_scenario:shared_scope:/1:value
V13 same_program_attempt→guard:cross_program_scenario:program_identity_distinct
V14 defining_patch→guard:actual_entry:source:defining_module_patch
V15 restoration→guard:actual_entry:source:restoration
V16 record→guard:actual_entry:source:record_before_delegate
V17 counts→guard:actual_entry:source:counts_and_order
V18 coordinates→guard:actual_entry:source:scenario_coordinates
```

Three separate external mutants retained 7,778-node collection and **failed** their intended nodes: discarded canonical early model at `test_actual_model_entry_model_after_guard_actual[replay]` (`guard:actual_entry:forbidden:model:replay`); discarded canonical early replay at `test_actual_replay_entry_fencing_before_replay_actual[unfenced]` (`guard:actual_entry:forbidden:persisted_replay:unfenced`); collapsed B program at `test_cross_program_scenario_integrity` (`guard:cross_program_scenario:program_identity_distinct`). The tuple and coupled-admission mutants described above instead **survived** focused tests; independent code-object observation confirmed the tuple mutant’s hidden calls.

### 15. Selector reproducibility

A fresh 1,958-node four-module collect-only preceded each selector. Selected and passed counts matched: `actual_model_entry` 14, `actual_replay_entry` 9, `fencing_before_replay_actual` 9, `model_after_guard_actual` 13, `cross_program_scenario_integrity` 6, `cross_program_ceiling` 1, `hostile` 658, `capability_semantic_integrity` 9, `guard_ordering_integrity` 4, `typed_human_machine_equivalence` 23, `closed_human_table` 11, `model_after_guard` 26, `operational_realization` 18, and `c2b_current_status_authority` 3. No selector selected zero tests.

### 16. Independent collection and validation

In external clones, C2 collected and passed **1,334/1,334**; guard **250/250**; combined **1,584/1,584**. The four-module run collected 1,958 but was interrupted. Full repository collection was 7,778; the parent full run had **1,524 passed** when interrupted at the provenance halt. The 17-module and broader runs were not started. Thus their expected pass and warning totals remain **unverified**, not failed.

`git diff --check` found no issue. Both new-file `/dev/null` whitespace checks emitted no issue; their diff status `1` was expected.

### 17. Nonimplementation and protected surfaces

All **66 source/resource paths** matched HEAD, including package exports, `StateStore`, `WriterSession`, readers, writers, and transactions. SQL remained exactly migrations `0001`–`0004`, with hashes unchanged and no `0005`. No guard source module, provisioner, durable decision writer, recovery reader, production caller, public API, or runtime activation appeared.

### 18. Live cache and final provenance

Opening cache: **37 members**, 8,897 canonical bytes, SHA-256 `3902e30eb9f5e229bb61b46d3b77a001f6b86371a717f9b3c324407d8818ebec`. Closeout: **49 members**, 11,813 bytes, SHA-256 `50ea875055567f83f7885dcc8d0031176f6d56f22c7f3987ba1c6e7507bf84b4`. The original 37 members retained exact path, type, mode, size, mtime, and hash; these 12 appeared:

```text
src/ge_nwp_coordinator/__pycache__/_finite_backlog_risk_source_adapter.cpython-313.pyc
src/ge_nwp_coordinator/__pycache__/_post_execution_evidence_values.cpython-313.pyc
src/ge_nwp_coordinator/__pycache__/_post_execution_policy_values.cpython-313.pyc
src/ge_nwp_coordinator/__pycache__/_rw0_c_decision_input_values.cpython-313.pyc
src/ge_nwp_coordinator/__pycache__/_section41_post_execution_proposal_family_projection.cpython-313.pyc
src/ge_nwp_coordinator/__pycache__/_section41_post_execution_role_resolution.cpython-313.pyc
tests/__pycache__/c2a_contract_support.cpython-313.pyc
tests/__pycache__/test_post_execution_pure_owner_relations.cpython-313.pyc
tests/__pycache__/test_post_execution_pure_owner_values.cpython-313.pyc
tests/__pycache__/test_rw0_b1_vectors.cpython-313.pyc
tests/__pycache__/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.cpython-313.pyc
tests/__pycache__/test_rw0_c2_durable_progression_decision_semantic_contract.cpython-313.pyc
```

All four disposable audit directories were removed. The tracked/untracked 28-path candidate, baseline, patch, and receipt still matched at final recheck. The 12 ignored cache files remain untouched.

### 19. Severity-ranked findings

| Severity | Finding |
|---|---|
| Provenance blocking | Live ignored cache changed from 37 to 49 members during the audit. |
| High | Prebound tuple calls before fencing or guard eligibility escaped the probe and survived 1,584 focused tests. |
| High | Coupled program-B admission and expectation changes survived 1,584 focused tests, defeating independent shared-admission proof. |
| Medium | Removing manual list restoration survived the focused suite; current implementation’s list restoration itself worked. |
| Evidence limit | Exact historical 76 external mutants, V2-to-V3 bytes, full validation, and expected warnings were not verified. |

### 20. Exact next boundary

The commit gate remains closed. The next candidate work is a **verifier-only repair** that detects prebound target calls, independently binds each scenario command’s admission to its posture, and tests list restoration. A fresh independent audit then needs a resolved cache baseline and completed validation. This report authorizes no implementation or publication step.

### 21. Required non-actions

These requested non-actions were satisfied:

```text
REPAIRS_NOT_PERFORMED
NORMATIVE_DOCUMENTS_NOT_MODIFIED
C2_VERIFIER_NOT_MODIFIED
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
SCHEMAS_NOT_MODIFIED
OTHER_27_CANDIDATE_PATHS_NOT_MODIFIED
NON_CEILING_DOCS_NOT_MODIFIED
NON_CEILING_TESTS_NOT_MODIFIED
OPERATOR_OR_PRODUCT_DATABASE_NOT_OPENED_OR_MUTATED
DEPENDENCIES_NOT_INSTALLED
SERVICES_NOT_STARTED
REMOTE_CONTACT_NOT_PERFORMED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
MERGE_NOT_PERFORMED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
BOOTSTRAP_SCOPE_PROVISIONER_NOT_IMPLEMENTED
BOOTSTRAP_ACCEPTANCE_GUARD_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
EXTERNAL_ARTIFACTS_NOT_GENERATED
```

These three statements **cannot** be made: `REPOSITORY_MUTATION_NOT_PERFORMED`, `LIVE_IGNORED_CACHE_NOT_MOVED_OR_MODIFIED`, and `SUBAGENTS_READ_ONLY_IF_USED`. The delegated live imports and new ignored cache entries are the reason. No tracked candidate file was changed by the audit.

### 22. Final token

`AUDIT_PROVENANCE_MISMATCH`
