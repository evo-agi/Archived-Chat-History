Important provenance clarification before you interpret the Codex response below:

This is NOT a response to the latest standalone acceptance-latch contract-freeze
prompt you generated. That prompt was never sent to Codex and remains
unexecuted.

After your initial latch reconnaissance, I commissioned a separate,
independent read-only architecture challenge from another Governed Execution
discussion. The purpose was to test whether:

- the earlier GPT-6.1 Sol + Light reconnaissance had prematurely fixed the
  standalone-latch abstraction;
- its prompt framing had constrained Codex to choose only among latch scopes;
  and
- a higher-reasoning review would reach a materially different architecture.

The independent challenge used GPT-6.1 Sol with the highest available reasoning
setting, against the same repository baseline. It was explicitly permitted to
challenge the merged abstract latch interface and compare a standalone latch
against other ways of enforcing the one-productive-bootstrap-acceptance
invariant.

Treat the response below as adversarial architectural evidence, not as authority
and not as an implementation or audit result.

Please reconcile it against:

- the current merged repository contracts;
- your earlier latch reconnaissance;
- the unexecuted standalone latch-owner freeze prompt; and
- the intended bounded direct-local bootstrap product policy.

In your response:

1. State which material conclusions you accept, reject, or qualify, with your
   engineering reasons.

2. Decide explicitly whether the unexecuted standalone latch-owner freeze
   prompt is:
   - retained;
   - revised;
   - or abandoned and superseded.

3. Determine whether the merged RW0-C durable-decision semantic contract must
   be amended before any latch/guard owner freeze proceeds.

4. Distinguish:
   - the safety invariant that engineering can resolve;
   - the physical representation that remains an engineering decision; and
   - any genuine product-policy question that only I should decide.

5. If a product-policy decision is genuinely required, present one bounded fork
   with:
   - your recommended default;
   - the practical consequence of each choice;
   - what work each choice enables or blocks; and
   - what remains unchanged.

Do not ask me to choose table design, transaction mechanics, selector shape,
migration details, replay behavior, recovery behavior, or other ordinary
engineering matters.

Do not issue another Codex prompt in this response. First make the architectural
judgment and identify whether a product-level decision is actually necessary.

Here is the independent Codex architecture-challenge response:

**Recommend a unique, immutable bootstrap-acceptance fact integrated into the durable decision family.** Retain the shared one-shot ceiling, but revise the abstract latch interface before freezing its owner. The exact meaning of “global Coordinator bootstrap” still requires a product-policy decision; storage design cannot safely supply that meaning.

The required baseline matched: `trunk_dev`, HEAD `6f11d6b0b6f38995123434945d86db0b169bb8f8`, tree `42cc0757b3d9604dfe7fdbda158074b8b48dac7b`, upstream `origin/trunk_dev`, divergence `0/0`, one clean worktree, and no observed Git operation or lock. No fetch occurred.

**1. Selected architecture**

Use one immutable fact recording that the designated initial bootstrap scope has received its sole productive acceptance. Commit that fact atomically with the accepted decision, resulting program version/head, decision basis, result, and receipt.

This remains a durable global guard. Its representation records the authoritative event directly rather than maintaining a separate mutable `available → consumed` object.

The proposed structure is:

- An explicitly admitted bootstrap scope, bound to its governing policy and Coordinator progression authority.
- At most one acceptance fact for that scope, independent of program, attempt, command, or parent-grant identity.
- A complete acceptance family whose immutable graph binds that fact to the exact decision and candidate/capsule evidence.
- Availability derived from a valid admitted scope **and proved absence of its acceptance fact**. Mere absence of a row is insufficient.

Scope admission is a prerequisite, not executable permission. The decision writer may record acceptance against an admitted scope; it may not create or replenish that scope.

Keep migration-0002 decisions canonical. “Integrated” means membership in the same atomic family, potentially through a supplemental relation—not adding latch fields to the existing decision row. The current adapter’s acceptance grammar requires capsule fields absent, and its column inventory contains no guard fields. See [src/ge_nwp_coordinator/_development_decision_row_values.py:35–61](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_decision_row_values.py:35>) and [632–641](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_decision_row_values.py:632>).

This is an **architectural recommendation**, not a currently accepted physical schema.

**2. Strongest alternative**

A standalone, one-way latch is coherent if it has the same exact scope, provisioning authority, transaction owner, family verification, and permanent non-replenishment rule.

Its strongest advantage is explicit installation state: a missing allowance cannot accidentally mean “available.” Its principal disadvantage is that acceptance and latch consumption become separately represented facts that must always be reconciled together.

The integrated fact makes the accepted decision’s consumption evidence part of its family. It avoids freezing a reusable latch subsystem for a single proof ceiling. That advantage is modest: both designs need equivalent uniqueness, admission, replay, and recovery guarantees.

The repository permits this reconsideration. Section 36 explicitly supersedes `direct_local_first_productive_acceptance` **as the required durable representation**, while retaining the policy ceiling. See [.docs/c2b-durable-development-state.md:18530–18563](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md:18530>).

**3. Exact safety invariant**

For one designated initial Coordinator bootstrap scope \(B\):

> Across every participating program and attempt, at most one distinct productive direct-local `candidate_acceptance` decision may commit. Its bootstrap-consumption evidence must commit in the same complete family. Replay, recovery, restart, a new command identity, or a different parent grant must not create another allowance.

The harmful outcome is **a second durable productive bootstrap acceptance despite the accepted one-shot ceiling**. Serialization alone does not prevent it: two fresh commands for different programs can execute sequentially and both pass their own head checks.

Separate concerns remain separately owned:

| Concern | Required protection | Authoritative owner |
|---|---|---|
| Replay of one command | Same mutation reference and canonical command return the original complete family | Coordinator mutation/replay owner |
| Two fresh programs accepting | Shared scope invariant and atomic uniqueness enforcement | Coordinator durable progression |
| Repeated acceptance within one program | Current-head/version checks, phase lineage, and the shared bootstrap invariant | Coordinator |
| Continued productive work after proof | Route/phase admission gate; acceptance consumption alone cannot stop new invocation or dispatch | Governing policy; Coordinator records progression; execution owners enforce their boundaries |
| External effects | Fresh grant verification, fences, current stop, and effect ceilings | External standing-policy authority and applicable effect/runtime owners |
| Git or publication | Separate effect decision and outcome reconciliation | Coordinator eligibility/progression; Git/forge fact ownership |

The guard does not itself enforce one invocation, validate evidence, authorize a commit, or prevent publication. RW0 already separately forbids relaunch/redelivery and ends every terminal branch without a successor, Git, or publication effect. See [.docs/rw0-remote-worker-contact-phase-entry.md:125–166](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-remote-worker-contact-phase-entry.md:125>).

**4. Scope and owner matrix**

The strongest supported interpretation is **one shared, non-renewable initial Coordinator bootstrap scope**, covering unrelated programs participating in that proof. It is not one allowance per program, attempt, repository, or grant.

Historical Section 19 explicitly names “global Coordinator bootstrap” and forbids reset, deletion, and reuse. Section 36 reopens its representation, not permission to multiply the ceiling. However, neither supplies a contemporary identity contract connecting “global” to deployment, tenant, database replacement, or multiple installations. See [.docs/c2b-durable-development-state.md:640–663](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md:640>) and [18607–18645](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md:18607>).

| Candidate scope | Assessment |
|---|---|
| Entire database forever | A database can enforce the local invariant, but a permanent restriction on **all** future acceptance would wrongly include ES operation |
| One deployment | Plausible authority boundary; deployment identity, replacement, and inheritance are unresolved |
| One repository | Repository bounds constrain the proof; they do not establish a separate allowance per repository |
| `direct_local_bootstrap` route | Necessary applicability condition; the route name alone cannot identify the shared authority scope |
| Explicit bootstrap policy epoch | Useful identity only if non-renewable for the initial proof; issuing another epoch cannot silently replenish it |
| External parent grant | Insufficient: two distinct valid grants must not independently authorize two acceptances under the same bootstrap ceiling |
| Designated initial bootstrap authority scope | Recommended semantic scope, requiring an explicit identity and stewardship decision |

Two unrelated programs admitted to the same initial bootstrap scope share the allowance, even if their grants differ. Later ES-routed programs do not consume this proof allowance. A different database or deployment is **not automatically an independent scope**.

Policy authorship remains external/operator/repo-policy authority. Coordinator alone records and enforces the corresponding local progression facts. ES owns admission/runtime, not semantic acceptance. These separations are explicit in [.docs/authority-boundaries.md:143–203](</Users/ds/Repositories/Governed Execution Coordinator/.docs/authority-boundaries.md:143>).

**5. Atomicity and recovery comparison**

The following assessments are architectural inferences. Every viable local design must use the existing guarded Coordinator writer and transaction controller; none justifies another authoritative writer.

| Design | Cross-program concurrency and atomicity | Replay, uncertainty, and partial families | Provisioning, scope, retirement, and ES consequences |
|---|---|---|---|
| **Standalone one-way latch** | Safe when every applicable acceptance checks and changes the same latch inside its decision transaction | Replay returns original consumed binding; recovery must prove decision and latch together; missing or contradictory members fail closed | Explicit allowance provisioning required. Scope must exclude ordinary ES acceptance. Retain consumed evidence permanently. Risk: proof bookkeeping becomes a general runtime dependency |
| **Route/policy-epoch phase state** | Safe only with one shared, authoritative epoch and acceptance update; per-program phases fail | Must preserve the exact historical epoch and postimage; changing “current epoch” cannot erase consumption | Natural place for route disablement, but rollover is a replenishment hazard. Existing C1 phase rows are not global epoch authority. Broader phase machinery risks hardening proof architecture |
| **Unique fact in decision family** | Safe with an enforced unique scope binding and atomic family commit | Exact replay returns the original fact; recovery verifies its complete family and all collision routes. Partial/orphan facts block progress | Requires explicit scope admission, but no mutable allowance seed. Retained proof fact does not constrain ES acceptance. Best fit for the existing family model |
| **External one-time capability with local redemption** | Safe within one designated redemption authority; per-grant or per-database redemption alone is insufficient | Redemption must co-commit with acceptance. External consumption outside SQLite introduces another uncertainty boundary | Aligns with external ceiling authorship, but issuance uniqueness and multiple redeemers are unresolved. A new grant cannot replenish the bootstrap ceiling. Adds unimplemented authority machinery |
| **Per-program/per-attempt guard** | Does not prevent different programs or attempts each accepting | Can give exact local replay while violating the global ceiling | Automatically creates multiple allowances. Useful supplementary lineage checks, unsuitable replacement |
| **No additional durable global invariant** | Writer serialization, idempotency, and per-program CAS do not enforce a total of one | Existing replay handles the same command, not distinct fresh commands | Acceptable only if another frozen durable invariant already enforces the ceiling. None is implemented or selected |

Migration 0002 has unique decision and mutation identities, plus per-program version uniqueness. Those do not conflict when two programs use different identities. See [0002_development_program_and_effect_state.sql:24–27](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql:24>) and [519–521](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql:519>).

For the recommended design:

- Fence the writer before replay or collision disclosure.
- Derive the applicable scope from admitted lineage/policy bindings; a caller cannot choose an independent allowance.
- For fresh derived acceptance, verify the scope and enforce its unclaimed condition inside the transaction.
- Co-commit the complete family with exactly one commit attempt.
- Replay the historical family without reevaluation or another consumption.
- Recover only as `committed_exact`, `definitely_not_committed`, or `unresolved`.

A missing receipt alone proves neither absence nor availability. A competing winner cannot be recovered as the original command, and definite noncommit does not itself permit retry after that winner consumed the scope. The physical freeze must resolve these locator and classification cases explicitly.

These requirements preserve [.docs/rw0-c2-durable-progression-decision-semantic-contract.md:417–441](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-c2-durable-progression-decision-semantic-contract.md:417>). External I/O remains outside the SQLite transaction boundary; an online external redemption protocol cannot be inserted casually. See [.docs/authority-boundaries.md:277–281](</Users/ds/Repositories/Governed Execution Coordinator/.docs/authority-boundaries.md:277>).

**6. Provisioning and retirement**

**No authoritative initial provisioning event is currently selected.**

The historical proposal seeded an available latch through a planned observation/progression migration 0003. That inventory was reopened. Actual migration 0003 implements cognitive pre-execution selection; the production catalog contains exactly 0001–0004, and administration verifies the newly added tables are empty. See [.docs/c2b-durable-development-state.md:848–918](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md:848>), [src/ge_nwp_coordinator/sqlite_migration.py:388–429](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migration.py:388>) and [2313–2336](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migration.py:2313>).

Recommended provisioning is an explicit **policy-adoption/bootstrap-scope admission event**:

- Operator/repo policy determines the designated scope and one-shot ceiling.
- Coordinator records its safe binding through a separately governed provisioning role.
- Schema installation creates representation, not executable authority or an automatically renewed allowance.
- The C2 decision writer cannot lazily provision a missing scope, replace a malformed one, or mint another epoch.

After acceptance, retain the immutable acceptance fact permanently. Terminal uncertainty does not release it. Nonaccept branches do not consume it, but that does not authorize another invocation within RW0.

Later productive continuation requires accepted ES reliable-submit and adapter-conformance gates plus a separately governed route transition and fresh applicable authority. Neither acceptance nor terminal closure creates that permission. The operating model requires migration before another productive bootstrap slice and disables direct-local by default after accepted ES routing. See [.docs/autonomous-software-development-operating-model.md:303–320](</Users/ds/Repositories/Governed Execution Coordinator/.docs/autonomous-software-development-operating-model.md:303>) and [541–565](</Users/ds/Repositories/Governed Execution Coordinator/.docs/autonomous-software-development-operating-model.md:541>).

Retirement should retain evidence and remove ordinary route eligibility. It need not require SQL migration if existing representation can express that policy transition. A new policy epoch alone cannot replenish the allowance. Historical Section 19’s mandatory reviewed-migration wording must therefore be reconciled explicitly; it cannot simply be ignored.

**7. Merged-contract clauses to retain, revise, or delete**

RW0-C2 currently freezes the selector/preimage/postimage interface at [.docs/rw0-c2-durable-progression-decision-semantic-contract.md:443–463](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-c2-durable-progression-decision-semantic-contract.md:443>).

| Clause | Treatment |
|---|---|
| Exactly five non-cancel branches, selected authoritatively by Coordinator | **Retain unchanged** |
| No-write, durable block, and recovery unresolved remain disjoint | **Retain unchanged** |
| Every future decision command binds a guard selector | **Revise:** every applicable RW0-C2 command must bind sufficient admitted lineage to derive the exact scope. It need not carry a mutable-latch selector |
| Command preassigns consumed-postimage identity | **Delete as a mandatory latch requirement.** Retain command-covered deterministic family identities where necessary for collision detection and recovery |
| Acceptance and consumption evidence co-commit | **Retain the invariant; revise the representation** to include the immutable acceptance fact |
| Nonaccept branches carry but do not consume the selector | **Retain nonconsumption.** Require scope/phase lineage, not unused available-state expectations or consumed identities |
| Invalid acceptance guard causes no-write, never fallback block | **Retain.** Reconcile the rejection name with the revised owner |
| Replay/recovery verify decision and guard as one family | **Retain unchanged in meaning** |
| Terminal acceptance binds committed latch postimage | **Revise:** bind the committed acceptance fact and family; terminal creates no second consumption |
| Separate complete latch owner precedes callable acceptance | **Replace:** complete bootstrap invariant, scope admission, decision family, and recovery contracts precede callable acceptance |
| Standalone latch owner must be frozen first | **Remove that required sequencing** |

The generic decision mapping and terminal separation remain justified. See [.docs/rw0-c2-durable-progression-decision-semantic-contract.md:322–337](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-c2-durable-progression-decision-semantic-contract.md:322>) and [465–475](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-c2-durable-progression-decision-semantic-contract.md:465>).

**8. Standalone versus co-freeze**

A standalone **architecture decision** can coherently establish the invariant, authority owner, and prohibition on replenishment.

A complete, implementation-ready **latch-owner freeze** cannot be treated as closed while scope, provisioning, safe values, family membership, uniqueness enforcement, and recovery remain unresolved. Those seams determine whether the ceiling actually holds.

Co-freeze the acceptance guard with the bounded decision family’s:

- Safe command and derived-scope bindings.
- Fact identity/digest and result/receipt projections.
- Physical uniqueness, immutable constraints, and family locator coverage.
- Exact replay and commit-uncertainty recovery.
- Provisioning boundary and retained historical evidence.

The reason is atomic integrity, not tranche size. This does not require implementing the writer or freezing terminal-outcome storage, transport, Git, or ES runtime. RW0-C2 already blocks source until the complete safe values, physical family, authority integration, and causal tests are frozen. See [.docs/rw0-c2-durable-progression-decision-semantic-contract.md:488–501](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-c2-durable-progression-decision-semantic-contract.md:488>).

**9. Exact next permitted tranche**

The next appropriate tranche is **docs and documentation-contract tests only**, beginning with an explicit scope-policy decision and amendment of RW0-C2’s abstract latch dependency.

It should:

1. Define the designated bootstrap authority scope and its inheritance across programs, restarts, replacement, and restore.
2. Select authoritative provisioning and prohibit automatic replenishment.
3. Replace mandatory latch preimage/postimage semantics with the selected acceptance-family invariant.
4. Reconcile Section 19 and the phase-entry/composition cross-references.
5. Preserve five branches, Coordinator branch authority, no-write/block/unresolved separation, exact replay, atomic consumption evidence, and later terminal closure.

Then freeze the complete bounded physical/value family before authorizing source.

Do not proceed with the existing standalone latch-owner freeze substantially unchanged. Do not alter migrations 0001–0004, add 0005, introduce a writer, or enable acceptance in this next amendment. The current governing narrowing freezes authority and ceilings, not future schemas. See [AGENTS.md:626–648](</Users/ds/Repositories/Governed Execution Coordinator/AGENTS.md:626>).

**10. Unresolved product-policy questions**

The required decision is more specific than choosing a table:

- Does “global Coordinator bootstrap” mean one authority installation, one deployment lineage, or one shared proof initiative spanning installations?
- Does replacing or restoring the database preserve the original scope and consumption? What prevents an empty replacement from being treated as another allowance?
- Which operator/repo-policy act admits the initial scope, and which component verifies and records it?
- Can genuinely independent deployments receive independent proofs? What authoritative relationship establishes independence?
- What distinct policy permits direct-local proof/recovery after ES migration, and can that policy ever permit another productive acceptance?
- Which accepted route-transition decision records ES readiness and bootstrap disablement?

These are not ordinary implementation choices. In particular, local uniqueness cannot enforce one redemption across copied or independent databases. The SQLite threat model provides local writer exclusion and filesystem binding, with explicitly limited same-account resistance; it does not establish distributed single-use authority. See [.docs/sqlite-threat-model.md:238–302](</Users/ds/Repositories/Governed Execution Coordinator/.docs/sqlite-threat-model.md:238>).

**11. Source classification and inspection limits**

The inspected evidence supports these classifications:

| Evidence | Classification |
|---|---|
| AGENTS vertical-slice narrowing and operating-model sequencing | Current repository governance describing accepted, unimplemented target constraints |
| Historical Section 19’s global one-shot ceiling | Retained target policy; literal latch identity/version/representation reopened |
| Historical latch seed and proposed migration 0003 inventory | Superseded target representation |
| RW0-C2 selector/postimage interface | Current accepted strategic target, unimplemented and legitimately challengeable |
| Migration 0002 decisions/versions/receipts | Implemented durable representation, without global acceptance enforcement |
| Actual migration 0003 | Implemented cognitive pre-execution selection representation; see [0003_cognitive_proposal_and_selection_state.sql:381–408](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migrations/0003_cognitive_proposal_and_selection_state.sql:381>) |
| Actual migration 0004 | Implemented C1 phase/evidence representation. K8 uniqueness is program/attempt/effect lineage, not global bootstrap scope; see [0004_rw0_c1_durable_evidence.sql:969–975](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migrations/0004_rw0_c1_durable_evidence.sql:969>) |
| Historical latch tests | Documentation-preservation evidence, not installed runtime enforcement; see [tests/test_c2b0_durable_state_contract.py:3873–3889](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_c2b0_durable_state_contract.py:3873>) |
| Narrowing tests | Evidence that representation reopened while maximum one remained; see [tests/test_c2b3_program_initialization_contract.py:362–374](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_c2b3_program_initialization_contract.py:362>) |
| Accepted RW0-C2 oracle | Tests abstract state and nonaccept nonconsumption, not scope reconstruction or cross-program concurrency; see [tests/test_rw0_c2_durable_progression_decision_semantic_contract.py:1347–1371](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_c2_durable_progression_decision_semantic_contract.py:1347>) and [5184–5247](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_c2_durable_progression_decision_semantic_contract.py:5184>) |
| Current nonimplementation guards | Temporary source-manifest/API/migration barriers, not acceptance runtime proof; see [same test:6407–6431](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_c2_durable_progression_decision_semantic_contract.py:6407>) and [6600–6608](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_c2_durable_progression_decision_semantic_contract.py:6600>) |

The durable-state successor explicitly leaves the physical family and possible migration 0005 unresolved. See [.docs/c2b-durable-development-state.md:24879–24897](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md:24879>). The operating model independently classifies RW0-C2 as target-only and excludes its writer, latch, terminal owner, migration, caller, and runtime. See [.docs/autonomous-software-development-operating-model.md:65–89](</Users/ds/Repositories/Governed Execution Coordinator/.docs/autonomous-software-development-operating-model.md:65>).

Inspection used the required repository sources and exactly two bounded read-only explorers. Tests were read, not executed. No databases were opened, migrations executed, dependencies installed, services started, remotes contacted, files changed, or artifacts generated. Installed-state behavior, runtime races, external issuer guarantees, and cross-deployment enforcement were not verified.

BOOTSTRAP_SCOPE_POLICY_DECISION_REQUIRED
