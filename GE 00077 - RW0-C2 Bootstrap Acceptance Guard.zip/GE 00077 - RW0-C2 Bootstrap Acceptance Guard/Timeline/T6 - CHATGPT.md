# Architectural judgment

The adversarial challenge materially changes the selected architecture.

**The unexecuted standalone latch-owner freeze prompt is abandoned and superseded.** It was never executed, so no repository work needs to be reverted. :chatgpt-content-reference{index="0"}

The retained safety requirement is real, but the best logical representation is no longer a separately mutable `available → consumed` latch. It should be:

1. an explicitly admitted, non-renewable bootstrap authority scope; and  
2. at most one immutable bootstrap-acceptance fact for that scope, committed as part of the exact durable acceptance decision family.

The current merged RW0-C2 semantic contract **must be amended before, or atomically with, any acceptance-guard owner freeze**. A separate owner freeze under the present selector/preimage/postimage language would create two incompatible target contracts.

## Material conclusions

| Challenge conclusion | Judgment | Engineering reason |
|---|---|---|
| The cross-program one-shot invariant is real | **Accept** | Per-program head CAS, decision identity, and mutation idempotency do not prevent two fresh commands for two different programs from each accepting. The earlier reconnaissance reached the same non-redundancy result. :chatgpt-content-reference{index="1"} |
| The guard should be an immutable fact integrated into the accepted decision family | **Accept as the selected logical architecture** | The protected event is “this admitted bootstrap scope has received its one productive acceptance.” Recording that event directly avoids a second mutable truth whose state must forever be reconciled with the decision family. :chatgpt-content-reference{index="2"} |
| A standalone one-way latch is coherent | **Qualify** | It is technically safe if scope, provisioning, atomicity, replay, recovery, and permanent non-replenishment are identical. But it is not the narrowest architecture for a one-shot proof ceiling; its explicit installation-state advantage can instead be supplied by a separate immutable scope-admission fact. :chatgpt-content-reference{index="3"} |
| “Available” should mean admitted scope plus absence of an acceptance fact | **Accept, with a fail-closed condition** | Mere absence of an acceptance row is never enough. The scope-admission fact must be exact and readable; duplicate, ambiguous, malformed, foreign, or unreadable state cannot be interpreted as availability. |
| The acceptance guard must share replay and recovery truth with the durable decision family | **Accept** | An independent guard classifier could say “consumed” while the decision classifier says “not committed,” or vice versa. There must be one complete-family classifier for the decision, version/head, result, receipt, and acceptance fact. |
| The complete guard should be co-frozen with physical uniqueness and safe values | **Qualify on sequencing** | Implementation readiness requires that full co-freeze. It does not require SQL in the first amendment tranche. First amend the logical contracts; then freeze exact safe values and physical persistence before source work. |
| A one-time external capability should own the ceiling | **Reject for the current target** | It adds an unimplemented issuer/redemption authority and another commit-uncertainty boundary. The current local-first bootstrap can enforce the invariant within one explicitly admitted Coordinator authority lineage without introducing an online external authority. |
| A per-program, per-attempt, per-candidate, per-grant, or renewable epoch guard is sufficient | **Reject** | Each recreates the allowance and permits multiple acceptances under what is supposed to be one shared bootstrap ceiling. |
| Existing serialization and idempotency are sufficient without another invariant | **Reject** | They prevent duplicate execution of one command, not two valid fresh commands for different programs. The challenge states the exact harmful outcome correctly. :chatgpt-content-reference{index="4"} |

## Selected logical architecture

The term **latch** should cease being the primary target abstraction. The target should be a **bootstrap acceptance guard** with two immutable facts.

### 1. Bootstrap-scope admission fact

This establishes that one specifically identified Coordinator authority lineage is participating in the bounded direct-local bootstrap policy.

It must be:

- admitted by standing operator/repository policy, not minted by the decision writer;
- non-renewable within that lineage;
- independent of any individual program, attempt, candidate, command, repository, or parent grant;
- preserved through restart, database restoration, and replacement of the local machine or database;
- incapable of authorizing execution, branch selection, ES admission, Git activity, or publication by itself.

Schema installation alone cannot admit a scope. A missing scope-admission fact is fail-closed, not permission to initialize lazily.

### 2. Bootstrap-acceptance fact

This records that the admitted scope has received its sole productive direct-local `candidate_acceptance`.

It must be:

- unique by admitted scope identity;
- immutable;
- co-committed with the accepted decision, resulting version/head, exact basis, result, and receipt;
- part of the same replay and recovery family;
- retained permanently as evidence of consumption;
- absent on repair, replan, terminal-reject, and block branches.

No reset, reopening, renewal, deletion, or replacement epoch is defined.

Availability is therefore:

```text
exact admitted bootstrap scope
+ no exact committed bootstrap-acceptance fact for that scope
+ no ambiguity, collision, fragment, or read failure
```

It is not simply “row missing.”

## Why this is better than the standalone latch

The earlier design modeled:

```text
available preimage → consumed postimage
```

That is safe, but it creates two durable representations of the same one-shot event:

- the accepted decision family;
- the consumed latch state.

Every replay, recovery, migration, reader, and terminal binding must then prove that the two representations agree.

The selected design models:

```text
admitted scope
+ zero or one acceptance fact in the decision family
```

This makes the accepted decision family itself the authoritative consumption evidence. It still requires exact uniqueness, atomicity, replay, recovery, and scope admission, but it avoids inventing a reusable mutable latch subsystem for a single bounded proof ceiling. The challenge’s comparison correctly identifies that advantage. :chatgpt-content-reference{index="5"}

## Status of the unexecuted prompt

**Abandoned and superseded. Do not send it to Codex.**

This is not a small revision. Its central assumptions are no longer selected:

- a standalone latch owner;
- an authoritative `available` state row;
- a mandatory expected preimage revision/digest on every command;
- a preassigned consumed-postimage identity as a universal latch requirement;
- a separate latch postimage later bound by terminal outcome;
- mandatory sequencing in which the standalone latch owner is frozen before reconsidering the decision-family contract.

Useful requirements from that prompt survive and should migrate into the successor architecture:

- one shared bounded scope;
- permanent non-replenishment;
- no lazy creation;
- acceptance-only effect;
- same-transaction commitment;
- no-write on invalid guard state;
- exact replay without a second action;
- three-way whole-family recovery;
- terminal nonmutation;
- no source or migration work before the contracts are complete.

The prompt itself should remain historical planning evidence only.

# The merged RW0-C2 contract must be amended

The current merged contract is not neutral about representation. It freezes a selector, expected available preimage, preassigned consumed postimage, separate latch ownership, and terminal binding to the latch postimage.

Those clauses conflict with the selected immutable-fact design. The adversarial review identifies the necessary treatments explicitly. :chatgpt-content-reference{index="6"}

## Retain unchanged

- exactly five non-cancel branches;
- Coordinator-authoritative branch derivation;
- no-write, durable block, and recovery-unresolved as distinct outcomes;
- acceptance evidence must co-commit atomically with the decision family;
- nonaccept branches create no consumption evidence;
- exact replay creates no second action;
- decision and guard evidence recover as one family;
- terminal outcome remains later and separate;
- caller and model remain non-authoritative.

## Revise

Current concept:

```text
every decision command binds a mutable-latch selector
```

Replacement:

```text
every applicable direct-local bootstrap command binds admitted lineage
sufficient for the Coordinator to derive one exact bootstrap scope
```

The caller may assert expected scope lineage for conflict detection, but cannot select a new allowance.

Current concept:

```text
acceptance consumes an available preimage and commits a consumed postimage
```

Replacement:

```text
acceptance proves an admitted, as-yet-unclaimed scope and atomically creates
the unique immutable bootstrap-acceptance fact in the decision family
```

Current concept:

```text
terminal outcome binds the consumed latch postimage
```

Replacement:

```text
terminal outcome binds the immutable bootstrap-acceptance fact and its exact
committed decision/result/receipt family
```

## Delete as mandatory architecture

- mandatory mutable `available` latch state;
- mandatory latch revision transition;
- mandatory preassigned consumed-latch postimage;
- unused latch selectors on nonaccept branches;
- a separate latch replay/recovery classifier;
- the sequencing rule that a standalone latch owner must be frozen before the durable decision family can be completed.

The current rejection name `acceptance_latch_precondition_conflict` must also be reconsidered. A guard-oriented successor name would be clearer, but exact compatibility and taxonomy treatment are an engineering decision for the amendment tranche.

The amendment must occur **before or in the same atomic documentation/test tranche as the guard contract**. It must not be deferred until after a new guard owner is written.

# What engineering can decide

## Safety invariant

Engineering can freeze this without further product input:

> For one explicitly admitted initial bootstrap scope, across every participating program, attempt, candidate, command, restart, and parent grant, at most one distinct productive direct-local `candidate_acceptance` may commit. Its bootstrap-acceptance fact must commit in the same complete durable decision family.

Consequences are also engineering decisions:

- same-command replay returns the original complete family;
- a fresh command cannot obtain a new allowance;
- nonaccept branches do not create the fact;
- a competing winner prevents retry merely because the original command is definitely not committed;
- partial acceptance families are `unresolved`;
- recovery never repairs fragments or creates the fact;
- terminal outcome cannot reset or consume anything;
- database/read faults are not absence;
- scope admission and consumption evidence have an acyclic digest graph.

## Logical representation

I am selecting the immutable-fact design above as the engineering architecture.

It is not a table-design decision. It defines which fact is authoritative and how it relates to the durable decision family.

## Physical representation

The following remain ordinary engineering work and should not be sent to the user for product approval:

- supplemental relation versus dedicated table;
- exact row and index layout;
- unique-constraint mechanics;
- migration-free reuse, migration `0005`, or bounded hybrid;
- selector and safe-value field names;
- digest domains;
- reader and recovery query shapes;
- writer-session integration;
- collision and alias enumeration;
- transaction ordering;
- staged migration and causal test design.

Migration-0002 decisions, versions, heads, and receipts should remain canonical. The likely physical result is still a bounded hybrid, but that choice belongs to the later physical/value freeze.

# The genuine product-policy decision

The repository does not define what makes two installations part of the same “global Coordinator bootstrap.” It explicitly lacks a contemporary identity rule connecting that term to deployment, database restore, replacement, tenant, or multiple installations. :chatgpt-content-reference{index="7"}

That is not table design. It decides who is entitled to an independent bootstrap proof.

There is one bounded fork.

## A. One scope per explicitly admitted Coordinator deployment lineage — **recommended**

A deployment lineage includes its restores, database replacements, machine moves, and passive backups. Those do not create a new scope or allowance.

A genuinely independent deployment may receive a distinct scope only through an explicit standing policy-admission act. A repository, program, grant, database file, or command cannot create independence by itself.

### Practical consequence

- Each deliberate local-first installation can perform one bounded direct-local productive acceptance.
- Cloning, restoring, or replacing its database does not reset that acceptance.
- Two active copies claiming the same lineage are not independently authoritative; the current target remains a single active Coordinator authority, not active-active HA.
- After transition to the ES route, the direct-local scope remains consumed and is not renewed.

### Enables

- the intended local-first bootstrap product;
- independent developer/customer installations;
- locally enforceable uniqueness within one Coordinator authority lineage;
- a bounded SQLite-backed implementation without a new online global issuer;
- later migration to ES without making the bootstrap guard part of normal ES operation.

### Blocks

- treating an empty replacement database as a fresh allowance;
- per-program or per-repository allowances;
- silent renewal through a new grant or policy epoch;
- multiple active databases using one lineage concurrently;
- a second direct-local productive acceptance after ES transition in that lineage.

## B. One shared proof-initiative scope spanning installations

Every installation participating in one named proof initiative shares a single allowance.

### Practical consequence

A productive acceptance on one installation consumes the allowance for all participating installations.

### Enables

- the strongest interpretation of one centrally coordinated project-wide demonstration;
- a single acceptance across multiple machines or deployments.

### Blocks or delays

- purely local enforcement;
- independent installations each running their own bootstrap proof;
- implementation using only local Coordinator durability;
- recovery after copied databases without a cross-installation authority.

It would require an external scope issuer, global redemption/consumption authority, or equivalent cross-installation coordination before the invariant could be enforced honestly.

## What remains unchanged under either choice

- one productive acceptance per chosen scope;
- immutable acceptance fact in the decision family;
- no reset or replenishment;
- atomic co-commit;
- exact replay and three-way recovery;
- no mutation on nonaccept branches;
- terminal nonmutation;
- no authority granted by the fact;
- ES, standing-policy, global-stop, runtime, Git, and publication authority remain separate;
- no source, migration, or writer work before semantic and physical contracts are frozen.

# Recommended sequence

1. **Resolve the single scope-policy fork above.**
2. **Amend the merged RW0-C2 semantic owner and its contract tests.** Remove the mandatory standalone-latch interface and replace it with admitted scope plus immutable acceptance fact.
3. **Freeze the bootstrap acceptance-guard semantics in the same documentation/test program.** It must share the durable decision family’s identities, result/receipt bindings, replay, and classifier rather than create another interpretation of committed truth.
4. **Freeze exact safe values and the physical family.** Resolve scope admission representation, uniqueness, locators, aliases, migration treatment, and writer integration.
5. Only then define an implementation boundary.

The challenge is right that source work must remain blocked until the safe-value and physical family are complete. :chatgpt-content-reference{index="8"}

## Decision required

Adopt either:

```text
A — one explicitly admitted Coordinator deployment lineage
    Recommended default
```

or:

```text
B — one shared proof initiative spanning installations
```

No other product decision is needed before engineering resumes. Database layout, transaction mechanics, selector shape, replay, recovery, and migration treatment remain engineering responsibilities.

**Sources:** Independent adversarial architecture challenge, treated as evidence rather than authority; earlier repository-first latch reconnaissance; current merged contract posture as quoted and inspected in both reports. The challenge was explicitly separate from—and not a response to—the unexecuted freeze prompt. :chatgpt-content-reference{index="9"}

**Confidence:** High on abandoning the mutable standalone-latch prompt, amending the merged contract, and selecting the immutable acceptance-fact architecture. High that the deployment-lineage option best fits the stated bounded local-first product. The remaining uncertainty is genuinely product-level: whether independently admitted deployments should each receive their own one-shot bootstrap scope.
