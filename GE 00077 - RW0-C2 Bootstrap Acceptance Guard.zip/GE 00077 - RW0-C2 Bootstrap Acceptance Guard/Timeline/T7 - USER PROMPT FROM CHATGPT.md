I accept Option A, with the following clarification.

The scope is one explicitly admitted Coordinator authority lineage. A deployment,
machine, or database is an operational realization of that lineage; none creates
a new scope merely by existing.

A genuinely independent Coordinator authority lineage may receive its own
bounded direct-local bootstrap scope only through an explicit standing-policy
admission act.

Machine replacement, database replacement, restore, rollback, cloning, passive
backup, or relocation do not create a new scope or allowance. If continuity of
the lineage and its bootstrap-acceptance status cannot be positively established
after such an event, the guard is unresolved and must fail closed. Absence of a
local acceptance row is never sufficient evidence that the scope is unclaimed.

The current target supports one active Coordinator authority per lineage, not
active-active operation by multiple database copies.

After the one productive direct-local candidate acceptance commits, the
bootstrap-acceptance fact remains permanent and the scope is never renewed.
Later ES-routed operation is governed separately and does not replenish this
proof allowance.

Proceed with the recommended immutable architecture:

- one immutable bootstrap-scope admission fact;
- at most one immutable bootstrap-acceptance fact for that scope;
- acceptance evidence atomically integrated into the durable decision family;
- no mutable available-to-consumed latch subsystem;
- no lazy scope creation by the decision writer;
- exact replay and whole-family three-way recovery;
- no consumption on nonaccept branches;
- terminal outcome remains later and non-mutating.

Amend the merged RW0-C durable-decision semantic contract and its causal contract
tests before or atomically with the bootstrap-guard contract.

Keep physical representation, migration treatment, row/index layout, selectors,
readers, transaction mechanics, collision handling, replay, and recovery
implementation as engineering responsibilities.

Use the highest available Codex reasoning setting for the authority-sensitive
contract amendment and record the visible model and reasoning setting. Do not
begin source, migration, writer, or runtime implementation in that tranche.
