# Governed Execution Coordinator — RW0-C2 Bootstrap Guard Governing Reset PR #10 Squash-Merge and Local-Realignment Gate

## Role and authorized effects

Perform one parent-only squash-merge and local-realignment gate for the exact
published RW0-C2 bootstrap acceptance-guard governing-reset candidate in PR #10.

Use the highest available Codex reasoning setting. At the beginning of the
report, record exactly what the interface visibly shows for:

- model name;
- reasoning setting or effort.

Do not infer hidden configuration. Record `not visible` when necessary.

Do not spawn subagents.

This prompt authorizes only:

1. local committed-object and live remote/PR/policy verification;
2. exactly one guarded squash-merge API write for PR #10;
3. independent verification of the resulting remote squash commit;
4. one narrow fetch updating only `origin/trunk_dev`;
5. one expected-old-object-guarded local `trunk_dev` ref update to the verified
   squash commit;
6. cleanup of gate-created temporary material.

This prompt does **not** authorize:

- candidate-byte changes;
- another commit;
- commit amendment;
- rebase, cherry-pick, local squash, or merge-commit creation;
- direct push to `trunk_dev`;
- force push;
- auto-merge or merge queue;
- topic-branch deletion;
- tag, release, or deployment;
- source, migration, schema, public, runtime, RW0-D/E, or Execution Substrate
  changes;
- test reruns.

Return one substantive inline closeout report. Do not create or attach an
external report, receipt, manifest, package, or other client-visible artifact.

Temporary API request/response or verification material may exist only outside
the repository and must be removed at closeout.

## Repository and exact opening local state

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required opening local coordinates:

- checked-out branch: `trunk_dev`
- HEAD/source commit:
  `c5aec83addf765b824f30dfdc907da61541be64c`
- tree:
  `edd773fe66f8aca9a8eaec0c4ad43d99d73a20a3`
- sole parent:
  `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- subject:
  `docs: adopt RW0-C2 bootstrap acceptance guard`
- upstream: `origin/trunk_dev`
- divergence: `1 ahead / 0 behind`
- exactly one worktree
- clean index, worktree, untracked, and unmerged sets
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Required source-commit message coordinates:

- body bytes with one final LF: `697`
- body SHA-256 with final LF:
  `1bbc0b69769e3ed45b135c2f92fa9cd670bf52885d033cc0f8db6d4ebf050f1f`
- complete subject-plus-body message SHA-256 with final LF:
  `b86b830182daf84a48ad446b8b7bd717d919e7edaf6159da31b50c1fdbf98091`

Exact source body:

```text
Adopt the accepted target contract for one standing-policy-admitted
Coordinator authority lineage and its immutable bootstrap admission and
acceptance facts.

Replace the superseded mutable acceptance-latch target across governing
documents and causal contract tests while preserving the five RW0-C2 branches,
receipt-first exact replay, one whole-family recovery classifier, historical
C2B evidence, and the private B1 compatibility edge.

This change adds no scope provisioner, guard storage, durable decision writer,
migration, reader, public API, runtime behavior, RW0-D/E behavior, or
Execution Substrate behavior.

Audit:
RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_ACCEPTED_READY_FOR_COMMIT_GATE
```

The local commit must have exactly 28 changed paths relative to its parent, all
mode `100644`, and no second parent.

Any local commit, tree, parent, message, cleanliness, or worktree mismatch
requires:

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_MERGE_GATE_BLOCKED`

Stop before remote mutation.

## Live ignored-cache gate

Before any repository import or executable validation, inventory the live
ignored cache by metadata and byte hashing only.

Require exactly:

- members: `37`
- canonical bytes: `8,897`
- SHA-256:
  `3902e30eb9f5e229bb61b46d3b77a001f6b86371a717f9b3c324407d8818ebec`
- no `tests/__pycache__`

Canonical grammar:

- path-sorted JSON array;
- exact object keys:
  `path`, `type`, `mode`, `size`, `mtime_ns`, `sha256`;
- lexicographically sorted object keys;
- compact UTF-8 JSON;
- `ensure_ascii=false`;
- one final LF.

Do not import live repository modules. Do not move, delete, or rewrite any live
cache member.

## Expected opening remote and PR state

Repository:

`evo-agi/Governed-Execution-Coordinator`

Authenticated identity observed by the publication gate:

`SeritArbores`

Base branch:

`trunk_dev`

Required opening base OID:

`6f11d6b0b6f38995123434945d86db0b169bb8f8`

Topic branch:

`codex/rw0-c2-bootstrap-acceptance-guard-governing-reset-v1`

Required topic OID:

`c5aec83addf765b824f30dfdc907da61541be64c`

Pull request:

- number: `10`
- state: `OPEN`
- draft: `false`
- merged: `false`
- base ref: `trunk_dev`
- base OID:
  `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- head ref:
  `codex/rw0-c2-bootstrap-acceptance-guard-governing-reset-v1`
- head OID:
  `c5aec83addf765b824f30dfdc907da61541be64c`
- source commits: exactly `1`
- changed files: exactly `28`
- source tree:
  `edd773fe66f8aca9a8eaec0c4ad43d99d73a20a3`
- auto-merge: absent
- expected mergeability immediately before merge: mergeable / clean
- reviews: `0`
- review threads: `0`
- review comments: `0`
- check runs: `0`
- status contexts: `0`
- workflow runs: `0`

GitHub may report aggregate commit status `pending` while exposing zero status
contexts. That alone is not a required-check failure. Reconcile it against the
effective ruleset.

Exact PR title:

```text
docs: adopt RW0-C2 bootstrap acceptance guard
```

Exact PR body, including one final LF:

```markdown
## Summary

- replace the superseded mutable acceptance-latch target with one explicitly admitted Coordinator authority lineage and immutable bootstrap admission and acceptance facts
- preserve the five RW0-C2 decision branches, receipt-first exact replay, and one whole-family three-way recovery classifier
- preserve historical C2B evidence and retain the private B1 `latch_postimage_*` pair only as a bounded compatibility/nonproof edge
- keep later ES-routed operation separately governed and non-replenishing

## Validation

- bootstrap guard verifier: 289 passed
- RW0-C2 plus guard: 1,623 passed
- focused governing-reset modules: 1,997 passed
- exact 17-module group: 3,606 passed
- broader regression group: 3,611 passed with 3 expected warnings
- full repository: 7,817 passed with 3 expected warnings
- independent transformed-mutant audit: accepted

## Non-implementation

This change adds no scope provisioner, guard storage, durable decision writer,
migration `0005`, reader or recovery implementation, terminal persistence,
production caller, public API, runtime activation, RW0-D/E behavior, or
Execution Substrate behavior.

Audit:
`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_ACCEPTED_READY_FOR_COMMIT_GATE`
```

PR-body coordinates:

- bytes with final LF: `1,220`
- SHA-256 with final LF:
  `2c8817e90dcc993884ef2b0d97ba5155d7f4dbd361359c422a45301cdaef647d`

## Effective publication policy

Reproduce the live policy immediately before merge.

The publication gate observed:

- active ruleset for `refs/heads/trunk_dev`;
- pull request required;
- required approving reviews: `0`;
- review-thread resolution required;
- extra approval required only for unattributed changes;
- required status checks: `0`;
- bypass actors: `0`;
- allowed branch-rule merge method: exactly `squash`;
- repository auto-merge: disabled;
- automatic source-branch deletion: disabled;
- repository-wide merge, squash, and rebase settings enabled, but the active
  branch rules narrow this PR route to squash.

Verify the source commit is attributed sufficiently for any unattributed-change
rule. Do not attempt a bypass.

If the base has drifted, the head differs, the PR is no longer open and clean,
a review thread is unresolved, a required approval/check has appeared and is
unsatisfied, or the effective merge method is no longer squash, return:

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_MERGE_GATE_BLOCKED`

Do not merge.

## Gate A — exact source-commit and PR verification

Before the merge write:

1. verify the exact local source commit and clean posture;
2. verify remote base and topic refs;
3. verify PR #10 coordinates, title, body, one-commit history, and 28-file
   inventory;
4. verify the PR head commit tree is exactly
   `edd773fe66f8aca9a8eaec0c4ad43d99d73a20a3`;
5. verify the PR’s 28 remote file blobs equal the source commit tree entries;
6. verify there is no base drift;
7. verify reviews, threads, checks, statuses, workflows, auto-merge, and policy;
8. verify the topic branch is preserved and no alternate PR/head exists;
9. verify the live cache is unchanged.

Do not rerun tests. The commit/publication gate already validated the exact
index and committed bytes through the full 7,817-test suite, and the accepted
independent audit owns mutant adequacy.

## Gate B — canonical squash-merge request

Perform exactly one mutating merge API call.

Use:

- method: `squash`;
- head-SHA guard:
  `c5aec83addf765b824f30dfdc907da61541be64c`;
- exact title:
  `docs: adopt RW0-C2 bootstrap acceptance guard`;
- exact commit body below, **without** a terminal LF.

Exact squash body:

```text
Adopt the accepted target contract for one standing-policy-admitted
Coordinator authority lineage and its immutable bootstrap admission and
acceptance facts.

Replace the superseded mutable acceptance-latch target across governing
documents and causal contract tests while preserving the five RW0-C2 branches,
receipt-first exact replay, one whole-family recovery classifier, historical
C2B evidence, and the private B1 compatibility edge.

This change adds no scope provisioner, guard storage, durable decision writer,
migration, reader, public API, runtime behavior, RW0-D/E behavior, or
Execution Substrate behavior.

Audit:
RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_ACCEPTED_READY_FOR_COMMIT_GATE
```

Canonical compact sorted-key request JSON, with one final LF, must be exactly
868 bytes with SHA-256:

`fbe2088fd2eb3546a39e407da8a0485737a6f795db01f2529fe68c43e20f6d82`

Its semantic fields are:

```json
{
  "commit_message": "<exact body above without terminal LF>",
  "commit_title": "docs: adopt RW0-C2 bootstrap acceptance guard",
  "merge_method": "squash",
  "sha": "c5aec83addf765b824f30dfdc907da61541be64c"
}
```

Hold the request in memory or in one private external mode-`0600` file. If a
file is used, delete it after verification.

Immediately before the mutating call, repeat a narrow read-only check of:

- PR open/non-draft/unmerged state;
- exact head and base OIDs;
- mergeability and merge state;
- unresolved review threads;
- required checks/approvals;
- both remote refs.

Then perform exactly one squash-merge API write.

No retry, alternate method, auto-merge, merge queue, bypass, or head update is
authorized.

## Partial-effect handling

### Merge API reports not merged

Do not retry.

Re-read PR and refs.

- If no merge effect occurred, preserve local and remote state and return:

  `RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_MERGE_GATE_BLOCKED`

- If state is ambiguous, preserve every observed effect and return:

  `RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_MERGE_STATE_UNRESOLVED`

### Merge succeeds but later verification or local realignment is incomplete

Do not retry the merge, revert, close the PR, delete the topic branch, or alter
the remote squash commit.

Return:

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_MERGED_LOCAL_REALIGNMENT_INCOMPLETE`

Report the exact completed and incomplete effects.

## Gate C — exact post-merge remote verification

After a successful merge response, independently verify:

### PR

- state `CLOSED`;
- merged `true`;
- exact merge timestamp and actor recorded;
- base `trunk_dev`;
- source head ref and source OID unchanged in PR history;
- auto-merge absent;
- merge-commit SHA equals the returned squash SHA.

### Remote refs

- remote `trunk_dev` equals the returned squash SHA;
- topic branch remains at
  `c5aec83addf765b824f30dfdc907da61541be64c`;
- no unrelated remote ref was changed by this gate.

### Squash commit object

Require:

- exactly one parent:
  `6f11d6b0b6f38995123434945d86db0b169bb8f8`;
- tree:
  `edd773fe66f8aca9a8eaec0c4ad43d99d73a20a3`;
- subject:
  `docs: adopt RW0-C2 bootstrap acceptance guard`;
- exact raw body without terminal LF:
  - bytes: `696`
  - SHA-256:
    `2f11870e4cb8f3058f664bb7edcd8da4b1f0db10857f00490dccb2bf674d3d8b`;
- exact complete subject-plus-body message without terminal LF:
  - bytes: `743`
  - SHA-256:
    `ae8ee03bd267cb869f77b0b5842936e0c0d42482cbf405a789f2cf0a7c3c3dd6`;
- exactly the same 28 path effects as the source commit;
- every final tree blob equal to the source tree blob;
- GitHub signature/verification status recorded; any reported invalid signature
  is blocking.

The squash commit’s tree identity proves byte equality, but also enumerate and
compare the 28 path modes/blob OIDs so a report does not substitute the tree
claim for inspection.

No tests are rerun.

## Gate D — narrow remote-tracking update

After the remote squash object is verified, execute exactly:

```sh
git fetch --no-tags origin \
  refs/heads/trunk_dev:refs/remotes/origin/trunk_dev
```

Do not fetch the topic branch, tags, or other refs.

Require:

- `origin/trunk_dev` equals the verified squash SHA;
- local `trunk_dev` still equals
  `c5aec83addf765b824f30dfdc907da61541be64c`;
- working tree and index remain clean;
- local and remote source/squash trees remain identical;
- live cache remains exact.

## Gate E — guarded local realignment

Because the source commit tree and verified squash tree are identical, realign
only the local branch ref.

Execute exactly one expected-old-object-guarded update:

```sh
git update-ref \
  -m "realign trunk_dev after PR #10 squash merge" \
  refs/heads/trunk_dev \
  <verified_squash_sha> \
  c5aec83addf765b824f30dfdc907da61541be64c
```

Do not use:

- checkout;
- switch;
- reset;
- rebase;
- cherry-pick;
- local merge;
- local squash;
- worktree rewrite.

Verify the reflog reason exactly.

After update require:

- checked-out branch remains `trunk_dev`;
- local HEAD equals the verified squash SHA;
- local tree equals
  `edd773fe66f8aca9a8eaec0c4ad43d99d73a20a3`;
- upstream remains `origin/trunk_dev`;
- divergence `0 ahead / 0 behind`;
- index, worktree, untracked, and unmerged sets clean;
- one worktree;
- no active Git operation or lock;
- topic branch preserved remotely at the source commit;
- live cache exact.

## Cleanup

Remove all gate-created private request/response files, temporary verification
material, and logs.

Do not remove or modify the 37 original cache members.

Do not retain or deliver an external artifact. The inline report is the only
deliverable.

## Success token

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_PR_SQUASH_MERGED_AND_LOCAL_REALIGNED`

Success authorizes no source implementation, migration, deployment, branch
deletion, tag, release, or later tranche automatically.

## Inline closeout report

Return:

1. primary outcome token;
2. visible model/reasoning setting;
3. opening local commit/tree/parent/message and cache;
4. opening remote refs, PR, reviews/checks, and effective policy;
5. exact canonical merge request bytes/SHA;
6. merge API response and whether a retry occurred;
7. final PR state and merge actor/time;
8. remote squash commit SHA/tree/parent/title/body/signature;
9. exact 28-path/source-tree equality;
10. final remote refs and topic preservation;
11. narrow fetch command/result;
12. guarded `update-ref` command/result and reflog reason;
13. final local coordinates, divergence, cleanliness, and cache;
14. cleanup;
15. every diagnostic or partial effect;
16. all required non-actions.

## Required non-actions

State:

```text
CANDIDATE_BYTES_NOT_CHANGED
NEW_SOURCE_COMMIT_NOT_CREATED
SOURCE_COMMIT_NOT_AMENDED
REBASE_NOT_PERFORMED
CHERRY_PICK_NOT_PERFORMED
MERGE_COMMIT_METHOD_NOT_USED
LOCAL_SQUASH_NOT_PERFORMED
AUTO_MERGE_NOT_ENABLED
MERGE_QUEUE_NOT_USED
DIRECT_PUSH_TO_TRUNK_DEV_NOT_PERFORMED
FORCE_PUSH_NOT_PERFORMED
TOPIC_BRANCH_NOT_DELETED
TAG_NOT_CREATED
RELEASE_NOT_CREATED
DEPLOYMENT_NOT_PERFORMED
TESTS_NOT_RERUN
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
SCHEMAS_NOT_MODIFIED
OPERATOR_OR_PRODUCT_DATABASE_NOT_OPENED_OR_MUTATED
LIVE_IGNORED_CACHE_NOT_MOVED_OR_MODIFIED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
BOOTSTRAP_SCOPE_PROVISIONER_NOT_IMPLEMENTED
BOOTSTRAP_ACCEPTANCE_GUARD_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
SUBAGENTS_NOT_SPAWNED
EXTERNAL_ARTIFACTS_NOT_RETAINED_OR_DELIVERED
```
