## Disposition

**Proceed to a fresh independent read-only re-audit. Do not stage or commit the V4 candidate.**

Codex returned the intended repair outcome:

```text
RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_REPAIRED_V4_VALIDATED_READY_FOR_REAUDIT
```

The repair has the correct narrow boundary: only the bootstrap-guard verifier changed, from 89,437 to 116,659 bytes, while the other 27 candidate paths remained byte-identical. The committed baseline, branch posture, and exact 28-path candidate set remained unchanged. :chatgpt-content-reference{index="0"}

This is the strongest candidate so far, but it is not yet independently accepted.

## What V4 appears to close

### Actual-call observation

The verifier now observes entry by exact Python `__code__` identity rather than relying only on patched aliases or returned traces. It covers the model phase, persisted replay, pre-model reduction, receipt checking, and acceptance eligibility. It also chains pre-existing profile callbacks and restores `sys` and `threading` profile/trace state in `finally`. :chatgpt-content-reference{index="1"}

That directly addresses the prior audit’s most serious finding: prebound tuple references could invoke model or replay functions early while the verifier still reported zero calls. The previous independent observer measured one hidden call where the V3 probe reported none. :chatgpt-content-reference{index="2"}

### Independent admission posture

The cross-program scenario now binds both commands to a separate immutable posture containing lineage, scope, admission identity, admission digest, applicability, and active-authority count. Admission is checked before the claimed-scope ledger, and the ledger key now includes admission identity and digest. :chatgpt-content-reference{index="3"}

This directly addresses the prior coupled mutant in which program B’s admission and its test expectation changed together while all focused tests still passed. :chatgpt-content-reference{index="4"}

### Restoration coverage

The report now claims dynamic coverage for:

- target-bearing lists;
- normal delegation;
- wrapped-target exceptions;
- caller exceptions;
- repeated probes;
- nested-probe rejection;
- profile and trace restoration;
- a newly created thread.

That closes the prior case where list restoration happened in the implementation but removing it did not fail any permanent test. :chatgpt-content-reference{index="5"}

### Real external mutants

The evidence classification is improved. Codex explicitly separates permanent internal negative controls from 24 transformed external copies. Each external mutant retained guard collection 289 and full collection 7,817, then failed one exact semantic boundary rather than failing through syntax, imports, or collection shrinkage. :chatgpt-content-reference{index="6"}

### Full validation

Reported validation is complete:

```text
Guard verifier:            289 passed
C2 + guard:              1,623 passed
Four focused modules:    1,997 passed
Exact 17-module group:   3,606 passed
Broader group:           3,611 passed, 3 warnings
Full repository:         7,817 passed, 3 warnings
```

The additional 39 tests are entirely attributable to the guard verifier’s growth from 250 to 289 nodes. :chatgpt-content-reference{index="7"}

### Cache restoration

The prior audit-created residue was removed exactly. The live cache returned from 49 members to the original 37-member baseline, with identical path, type, mode, size, `mtime_ns`, and SHA-256 for every retained member. The external clone and temporary mutant infrastructure were removed. :chatgpt-content-reference{index="8"}

## Remaining independent-audit risks

The re-audit should concentrate on four points.

### 1. Independent observation must not reuse the candidate oracle

The auditor should install an outer code-object observer before entering the candidate’s observer. Candidate and outer counts must agree on every baseline and hostile case. This verifies that the new observer is measuring actual entry rather than simply replacing one self-confirming instrument with another.

The audit must also test callback chaining, exceptional restoration, new-thread behavior, and nested-probe handling.

### 2. Exact code-object scope must be stated honestly

The observer can prove entry into the exact target code objects. It cannot prove that arbitrary maliciously cloned, semantically equivalent bytecode is impossible.

That is an acceptable boundary, provided:

- no live target role uses another code object;
- the verifier does not create semantic duplicates through `CodeType`, code replacement, `marshal`, `compile`, or `exec`;
- the closeout does not overclaim general protection against arbitrary code generation.

### 3. Admission posture must remain independently authored

The audit must independently mutate:

- B’s admission identity;
- B’s admission digest;
- both together;
- builder and comparison logic together;
- pre-ledger admission validation;
- ledger-key admission coordinates.

It should also confirm the important distinction that changing the posture and both commands together while preserving every required relation merely creates another valid fixture. Fixture literal values are not semantic authority.

### 4. Restoration tests must be dynamic

The auditor should remove list, dictionary, default, closure, profile, and trace restoration independently. Every removal must fail a dynamic post-exit identity check, not only an AST check.

## Report-only wording defect

The V4 closeout states:

```text
EXTERNAL_ARTIFACTS_NOT_GENERATED
```

That is not literally accurate. Codex generated disposable clones, transformed copies, basetemps, and a mutant runner, then deleted them. The accurate nonclaim is:

```text
EXTERNAL_ARTIFACTS_NOT_RETAINED_OR_DELIVERED
```

This is a Low report-only defect, not a candidate-byte or semantic defect. The re-audit prompt explicitly corrects the evidence language. The closeout itself confirms that disposable external copies were created. :chatgpt-content-reference{index="9"} :chatgpt-content-reference{index="10"}

## Fresh independent re-audit handoff

Start a **fresh parent-only, read-only Codex conversation**, select the highest available reasoning setting, and attach nothing.

Parent-only is deliberate: the previous audit’s delegated explorer imported modules from the live checkout and created the cache provenance mismatch. :chatgpt-content-reference{index="11"}

:chatgpt-content-reference{index="12"}[Download the V4 independent re-audit prompt](sandbox:/mnt/data/Coordinator_RW0_C2_Bootstrap_Guard_Governing_Reset_V4_Independent_Reaudit_Prompt.txt)

```text
Filename:
Coordinator_RW0_C2_Bootstrap_Guard_Governing_Reset_V4_Independent_Reaudit_Prompt.txt

Size:
37,657 bytes

SHA-256:
be3410191f37a0691e2c19b629170cc7b2722b25d5b3043e9e67d0645662162b

Logical lines:
1,075

Final newline:
present
```

The prompt binds:

- all 28 exact V4 receipts;
- the `336,588`-byte complete patch;
- the `5,594`-byte canonical receipt;
- the one-file V3-to-V4 transition;
- the restored 37-member live-cache baseline;
- an independent outer code-object observer;
- all 24 implementation-reported external mutants;
- additional independent observer, restoration, admission, and scenario mutants;
- exact selector counts;
- guard, C2-plus-guard, focused, 17-module, broader, and full-suite validation;
- complete source, migration, public-surface, historical-byte, cache, and artifact preservation.

Possible outcomes:

```text
RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_ACCEPTED_READY_FOR_COMMIT_GATE
```

```text
RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_AUDIT_BLOCKED
```

```text
AUDIT_PROVENANCE_MISMATCH
```

Even an acceptance authorizes only a separate commit/publication gate for the exact 28 audited paths. It does not authorize safe-value source changes, migration `0005`, lineage provisioning, durable decision writing, guard persistence, readers, terminal persistence, public APIs, runtime activation, RW0-D/E, or Execution Substrate work.

**Sources:** V4 implementation and validation closeout; preceding V3 independent audit.

**Confidence:** High that V4 is ready for independent re-audit. No commit-readiness judgment is warranted until an outer observer independently corroborates actual code-object entry, admission posture independence, complete restoration, and exact cache stability.
