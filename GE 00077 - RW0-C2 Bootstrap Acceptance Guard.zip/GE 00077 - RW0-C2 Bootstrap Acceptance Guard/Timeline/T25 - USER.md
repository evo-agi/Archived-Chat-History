`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_REPAIRED_V4_VALIDATED_READY_FOR_REAUDIT`

## Result and provenance

The V4 repair changed only [the bootstrap guard verifier](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py:1071>). Its code-object observer now detects calls through prebound references, and its cross-program scenario binds both commands to an independent immutable admission posture. The list and callback restoration paths have dynamic coverage.

The interface did not visibly expose a model name or reasoning setting. Recorded values: **model: not visible; reasoning effort: not visible**.

| Coordinate | Opening and closing value |
|---|---|
| Branch | `trunk_dev` |
| HEAD | `6f11d6b0b6f38995123434945d86db0b169bb8f8` |
| Tree | `42cc0757b3d9604dfe7fdbda158074b8b48dac7b` |
| Sole parent | `db16de711986ae40a2bb848ed00cdddd3145ee02` |
| Subject | `docs: freeze RW0-C durable decision branch contract` |
| Upstream; divergence | `origin/trunk_dev`; `0 ahead / 0 behind` |
| Worktrees; index; operations | One; zero staged or unmerged paths; no active Git operation |
| Candidate status | Exactly 26 modified tracked paths and two untracked paths |

The opening verifier was **89,437 bytes**, SHA-256 `e6555cc5155bfbaa1031de43dcfc6b3534f60457d5a34b72b245d6f769a8d795`. The closing verifier is **116,659 bytes**, SHA-256 `299b5ffdf3ed0f983068e0d42ee99474a600dce9201c38724ec9371d73ac01e3`. The other **27 candidate paths remain byte-identical** to their opening V3 receipts.

## Repair evidence

The observer binds the exact `__code__` object for the C2 model phase, C2 replay, C2 pre-model reduction, guard receipt check, and guard eligibility function. A profile `call` event records entry by `frame.f_code is code`, before body effects. It records order and count, chains pre-existing profile callbacks, preserves trace callbacks, restores `sys` and `threading` profile/trace state in `finally`, and rejects nesting at a fixed boundary. The reference-patching probe is reconciled with the code-object counts for the entry roles on every live case.

Each role below has count **one** when listed and **zero** otherwise; the listed order was asserted after invocation:

| Cases | Exact code-object entry order |
|---|---|
| Unfenced; invalid session | none |
| Lineage mismatch; missing or foreign admission; multiple active authorities | fence |
| Exact replay; mutation-ref conflict | fence → receipt → persisted replay |
| Family-route collision | fence → receipt → pre-model |
| Claimed or unresolved scope | fence → receipt → pre-model → acceptance eligibility |
| Recognized or unrecognized eligible acceptance | fence → receipt → pre-model → acceptance eligibility → model |
| Repair, replan, terminal reject, post-execution block | fence → receipt → pre-model → model |

Permanent tests exercise prebound tuples, discarded calls, removed trace markers, duplicate calls, partials, dynamic `getattr`, and a new function object using the same code object. A prebound tuple bypasses the reference probe while the frame observer detects its actual entry. Restoration tests supply a target-bearing list and verify normal delegation, a wrapped-target exception, a caller exception, a second probe, and the nested-probe boundary. Existing dict/default/closure restoration tests still pass. Profile and trace tests verify normal and exceptional exit, callback chaining, and restoration on the current and a new thread.

The scenario’s independent frozen posture is `(L, S, A, admission_digest_A, admitted_direct_local_bootstrap, 1 active authority)`. Both actual commands must share its lineage, scope, admission identity, digest, and applicability while retaining distinct program, head/basis, attempt/candidate, mutation, and command-digest coordinates. The behavioral loop checks each command against that posture **before** consulting the claimed-scope ledger; its ledger key includes admission identity and digest. Source checks protect this ordering and the binding comparisons without freezing line numbers or accepting a self-authored success boolean.

## Negative controls and validation

**Permanent internal controls** pass by catching exact asserted boundaries; the `-k hostile` selector passed **96** tests. Separately, **24 transformed external copies** were created and executed in the disposable clone. For **each** mutant, guard collection remained **289**, full repository collection remained **7,817**, and the specified single pytest node failed at the exact boundary below. None failed through syntax, import, or collection shrinkage. The clone was restored between mutants.

All node IDs in this table have the prefix `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py::`.

| # | Exact transformation | Failing node suffix | Exact boundary |
|---:|---|---|---|
| 1 | Prebound tuple calls model before eligibility | `test_actual_model_entry_model_after_guard_actual[claimed_scope]` | `guard:code_object_actual_entry:counts:model:claimed_scope` |
| 2 | Prebound tuple calls replay before fencing | `test_actual_replay_entry_fencing_before_replay_actual[unfenced]` | `guard:code_object_actual_entry:counts:persisted_replay:unfenced` |
| 3 | Early tuple model call; appended trace marker removed | `test_actual_model_entry_model_after_guard_actual[claimed_scope]` | `guard:code_object_actual_entry:counts:model:claimed_scope` |
| 4 | Early tuple model call followed by normal model call | `test_actual_model_entry_model_after_guard_actual[accepted_recognized]` | `guard:code_object_actual_entry:counts:model:accepted_recognized` |
| 5 | `partial` wraps early model call | `test_actual_model_entry_model_after_guard_actual[claimed_scope]` | `guard:code_object_actual_entry:counts:model:claimed_scope` |
| 6 | `partial` wraps early replay call | `test_actual_replay_entry_fencing_before_replay_actual[unfenced]` | `guard:code_object_actual_entry:counts:persisted_replay:unfenced` |
| 7 | Dynamic `getattr` calls a captured defining-module model target | `test_actual_model_entry_model_after_guard_actual[claimed_scope]` | `guard:code_object_actual_entry:counts:model:claimed_scope` |
| 8 | Receipt helper discards a first replay result and calls replay again | `test_actual_replay_entry_fencing_before_replay_actual[replay]` | `guard:code_object_actual_entry:counts:persisted_replay:replay` |
| 9 | Exact replay then fresh model evaluation | `test_actual_replay_entry_fencing_before_replay_actual[replay]` | `guard:code_object_actual_entry:counts:model:replay` |
| 10 | Exact replay then fresh guard eligibility | `test_actual_replay_entry_fencing_before_replay_actual[replay]` | `guard:code_object_actual_entry:counts:acceptance:replay` |
| 11 | B admission ref and its expectation changed together | `test_cross_program_scenario_integrity` | `guard:cross_program_scenario:shared_admission:ref` |
| 12 | B admission digest and its expectation changed together | `test_cross_program_scenario_integrity` | `guard:cross_program_scenario:shared_admission:digest` |
| 13 | B admission ref and digest both changed | `test_cross_program_scenario_integrity` | `guard:cross_program_scenario:shared_admission:ref` |
| 14 | Builder admissions and binding comparison changed together | `test_code_object_actual_entry_source_integrity` | `guard:cross_program_scenario:source:independent_admission_relation` |
| 15 | Pre-ledger command-admission check removed | `test_code_object_actual_entry_source_integrity` | `guard:cross_program_scenario:command_admission_binding:preledger_source` |
| 16 | Program B identity collapsed to A | `test_cross_program_scenario_integrity` | `guard:cross_program_scenario:program_identity_distinct` |
| 17 | B head/basis collapsed to A | `test_cross_program_scenario_integrity` | `guard:cross_program_scenario:program_basis_binding:/0:value` |
| 18 | B mutation ref and digest reused from A | `test_cross_program_scenario_integrity` | `guard:cross_program_scenario:command_identity_distinct:mutation_ref` |
| 19 | B moved to another scope | `test_cross_program_scenario_integrity` | `guard:cross_program_scenario:shared_scope:/1:value` |
| 20 | Same-program second attempt substituted for B | `test_cross_program_scenario_integrity` | `guard:cross_program_scenario:program_identity_distinct` |
| 21 | List restoration assignment removed | `test_list_reference_restoration[normal]` | `guard:actual_entry:restoration:list` |
| 22 | Profile and trace restoration calls removed | `test_code_object_probe_restoration[normal]` | `guard:code_object_probe_restoration:sys_profile` |
| 23 | List restoration skipped after wrapped-target `KeyError` | `test_list_reference_restoration[target_exception]` | `guard:actual_entry:restoration:list` |
| 24 | List restoration skipped after caller `RuntimeError` | `test_list_reference_restoration[caller_exception]` | `guard:actual_entry:restoration:list` |

Every requested selector was collected and then executed against its relevant module; selected counts equaled passed counts, with no zero selection or unrelated module:

| Selector | Selected / passed | Selector | Selected / passed |
|---|---:|---|---:|
| `code_object_actual_entry` | 7 / 7 | `actual_model_entry` | 14 / 14 |
| `prebound_callable_actual_entry` | 13 / 13 | `actual_replay_entry` | 9 / 9 |
| `code_object_probe_restoration` | 3 / 3 | `fencing_before_replay_actual` | 9 / 9 |
| `list_reference_restoration` | 4 / 4 | `model_after_guard_actual` | 13 / 13 |
| `shared_admission_integrity` | 8 / 8 | `capability_semantic_integrity` | 5 / 5 |
| `command_admission_binding` | 7 / 7 | `guard_ordering_integrity` | 4 / 4 |
| `cross_program_scenario_integrity` | 6 / 6 | `typed_human_machine_equivalence` | 14 / 14 |
| `cross_program_ceiling` | 1 / 1 | `closed_human_table` | 11 / 11 |
| `hostile` | 96 / 96 | `operational_realization` | 18 / 18 |
| `c2b_current_status_authority` | 3 / 3 |  |  |

The legitimate unbackticked human-table positive remains passing.

| Ordinary validation in the external clone | Collected | Result |
|---|---:|---|
| Guard verifier | 289 | 289 passed |
| C2 verifier plus guard | 1,623 | 1,623 passed |
| Four focused modules | 1,997 | 1,997 passed |
| Exact 17-module command | 3,606 | 3,606 passed |
| Exact broader command | 3,611 | 3,611 passed; 3 warnings |
| Full repository | 7,817 | **7,817 passed; 3 warnings** |

The three broader/full warnings are the specified, unchanged Python 3.13 multithreaded-`fork()` deprecations in the three writer-session tests. The broader and full runs include the C2B/C2B3 historical reconstruction checks.

## Exact final candidate receipts

The path labels below are the 28 path values in canonical receipt order; links resolve to the absolute workspace files. Every path is regular, non-symlink mode `0644`, valid UTF-8, with no BOM, CR, trailing whitespace, or extra final newline.

| # | Status | Path | Bytes | SHA-256 |
|---:|:---:|---|---:|---|
| 1 | M | [.docs/rw0-c2-durable-progression-decision-semantic-contract.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-c2-durable-progression-decision-semantic-contract.md>) | 70,858 | `4fc2b7f9d5810105c28a7ce11abe85d08a48f915a87b088ae86e5520aa2142e2` |
| 2 | M | [.docs/rw0-remote-worker-contact-phase-entry.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-remote-worker-contact-phase-entry.md>) | 57,192 | `2c0c9565f7fb4ae79eca998080f3b70734f9a4fd1e555132daf9b94daab1dc97` |
| 3 | M | [.docs/c2a-first-slice-semantic-protocol-contract.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2a-first-slice-semantic-protocol-contract.md>) | 103,413 | `a690441d046d147cf11a068e07a894858e3d32476e19fef84a9bb26e6e6f0d99` |
| 4 | M | [.docs/c2b-durable-development-state.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md>) | 1,889,329 | `6115a29d5bbfb8ffb17404e9acbefcb8edc958554683afa3538e9d959e184ef8` |
| 5 | M | [AGENTS.md](</Users/ds/Repositories/Governed Execution Coordinator/AGENTS.md>) | 61,466 | `001595cdec75b176abbfb99b91b2b06c45f2f2ff1a28c704ded7054c27c7e74e` |
| 6 | M | [README.md](</Users/ds/Repositories/Governed Execution Coordinator/README.md>) | 45,849 | `b66fb689d9f0849eee1d62f12dda93d83dcc9f4cce2fa008696878b44256ad1a` |
| 7 | M | [.docs/architecture.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/architecture.md>) | 43,007 | `60a884471d655ee6eddad8c405aa218eab492e3c610b101c0736fc9f2546288f` |
| 8 | M | [.docs/autonomous-software-development-operating-model.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/autonomous-software-development-operating-model.md>) | 37,829 | `115ed6c16141f821147f640131bed904526cee914dbec6951f3667b0da100f05` |
| 9 | M | [.docs/authority-boundaries.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/authority-boundaries.md>) | 34,686 | `69d524c839a2195cf0b5840be424c021305825fd0db1d85c76ed28b99c1bf055` |
| 10 | M | [.docs/durable-state-model.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/durable-state-model.md>) | 40,564 | `e14a421698f0735fa098fe6ce1063b64d07e1c212fd6b60755e1068c9caf5955` |
| 11 | M | [.docs/worker-execution-boundary.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/worker-execution-boundary.md>) | 30,920 | `6f7d2f7855fcbdecc757af4dde7a7bb091ab1e8c60057a2fefe407f74de4055f` |
| 12 | M | [.docs/software-development-progression-boundary.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/software-development-progression-boundary.md>) | 28,654 | `b8761655ee42512c0e77ab8c774c2b2d3d8f9ac36a9bd0c74872ad4bf2994419` |
| 13 | M | [.docs/c2b3-program-initialization.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b3-program-initialization.md>) | 27,687 | `8e9c2c6f49551b28d95de28f6d7b071c89dd0ea155ce7d7a6e21e8d88e73d1f7` |
| 14 | M | [.docs/rw0-b2-wire-protocol.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-b2-wire-protocol.md>) | 24,346 | `7f977a5a60fd66c69464190731e09611ca24854313e145b73cc73f564776477b` |
| 15 | M | [.docs/rw0-b2-capability.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-b2-capability.md>) | 17,753 | `171341fc60cbe762403f1e64676ca35c9ea2f778a10d0fc66d668f1c84dc884c` |
| 16 | M | [.docs/rw0-b1-pure-phase-values.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-b1-pure-phase-values.md>) | 33,032 | `8bccdaa31fa66821b73c136936c12ef001157209c72b9991839905c1a8e0e053` |
| 17 | M | [tests/test_architecture_contracts.py](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_architecture_contracts.py>) | 100,410 | `555ac490738d12075d3908ec2ddfd090fdbb32d8a6fd53d1b3136d24485e1169` |
| 18 | M | [tests/test_rw0_remote_contact_phase_entry_contract.py](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_remote_contact_phase_entry_contract.py>) | 173,524 | `42d6d265c0a9ba5047aa37ec3a4daae30847d486d39ead6374685b451a1d445c` |
| 19 | M | [tests/test_remote_worker_pre_execution_planning_contract.py](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_remote_worker_pre_execution_planning_contract.py>) | 913,152 | `92b0f3917f0572492357447211a1f0f0cc7f8edb7e8b5f18233ed80397879b29` |
| 20 | M | [tests/test_software_development_progression_boundary.py](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_software_development_progression_boundary.py>) | 42,899 | `bd9b10f62e3bbfb3dc5fc845958fe0087363a0afa0b80649853faac85235c7a3` |
| 21 | M | [tests/test_autonomous_software_development_operating_model.py](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_autonomous_software_development_operating_model.py>) | 72,904 | `e9a77edb1f99b181c612e52c4a7cfee814ac3f0df4d974e7c3a0756aec6da8df` |
| 22 | M | [tests/c2a_contract_support.py](</Users/ds/Repositories/Governed Execution Coordinator/tests/c2a_contract_support.py>) | 154,372 | `58be92ddffae6f4b901ae3632521481ab8d9ce0e02a819ef9421408d08eedd85` |
| 23 | M | [tests/test_rw0_b1_boundaries.py](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_b1_boundaries.py>) | 38,321 | `bd52384897f8f7a7129023c693ef67b1ff453a006723438dfa4f06df08e4121f` |
| 24 | M | [tests/test_rw0_b2_capability_boundaries.py](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_b2_capability_boundaries.py>) | 45,708 | `4e4824b5974778cbef147e7f5a5684de34e5006464156cbb7be2958c33ce1a84` |
| 25 | M | [tests/test_c2b0_durable_state_contract.py](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_c2b0_durable_state_contract.py>) | 884,862 | `45a539a810deb8884c3f0158887a0d4fd06778a59e833c6b9d89365990ed62fd` |
| 26 | M | [tests/test_rw0_c2_durable_progression_decision_semantic_contract.py](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_c2_durable_progression_decision_semantic_contract.py>) | 249,444 | `480bd282646304c70116f69faecabc1fea94d83ef54ec77b780a869ace5431c4` |
| 27 | ?? | [.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md>) | 25,151 | `bf65ba7f04411bb6e6febec2285b33721eb2ff895e2c60aee97878b1fa7c9b46` |
| 28 | ?? | [tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py>) | 116,659 | `299b5ffdf3ed0f983068e0d42ee99474a600dce9201c38724ec9371d73ac01e3` |

The complete binary patch, concatenated in that order, was assembled twice with matching results: **336,588 bytes**, SHA-256 `1f020195ad27f9b47ae4a9df3d8824669c0501f5e1f56022f3488ef19c001f35`. The fully specified compact, sorted-key JSON receipt with one final LF was independently generated by Python and Ruby: **5,594 bytes**, SHA-256 `f89483fdd31c633c4a631afee36a6727bf99c95e837e9265065a94d4687d4ffd`.

For comparison, the opening V3 complete patch was 308,892 bytes, SHA-256 `1d875ae83857db8fc4dd4c142800ced5682ff03c384c3e95430c5e33b48ea682`; its canonical receipt was 5,593 bytes, SHA-256 `a59f7c53ae4cbbdf33d7c5b69bd7ece58f2ada796c0195536bec23a0b687f8ae`.

## Cache, artifacts, and boundaries

The opening ignored-cache residue was exactly **49 members / 11,813 canonical bytes**, SHA-256 `50ea875055567f83f7885dcc8d0031176f6d56f22c7f3987ba1c6e7507bf84b4`. After verifying each added file, I deleted exactly these twelve audit-created `.pyc` files and the resulting empty `tests/__pycache__` directory:

```text
src/ge_nwp_coordinator/__pycache__/_finite_backlog_risk_source_adapter.cpython-313.pyc
src/ge_nwp_coordinator/__pycache__/_post_execution_evidence_values.cpython-313.pyc
src/ge_nwp_coordinator/__pycache__/_post_execution_policy_values.cpython-313.pyc
src/ge_nwp_coordinator/__pycache__/_rw0_c_decision_input_values.cpython-313.pyc
src/ge_nwp_coordinator/__pycache__/_section41_post_execution_proposal_family_projection.cpython-313.pyc
src/ge_nwp_coordinator/__pycache__/_section41_post_execution_role_resolution.cpython-313.pyc
tests/__pycache__/c2a_contract_support.cpython-313.pyc
tests/__pycache__/test_post_execution_pure_owner_relations.cpython-313.pyc
tests/__pycache__/test_post_execution_pure_owner_values.cpython-313.pyc
tests/__pycache__/test_rw0_b1_vectors.cpython-313.pyc
tests/__pycache__/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.cpython-313.pyc
tests/__pycache__/test_rw0_c2_durable_progression_decision_semantic_contract.cpython-313.pyc
```

After all validation and disposal of the clone, the live cache was again exactly **37 members / 8,897 canonical bytes**, SHA-256 `3902e30eb9f5e229bb61b46d3b77a001f6b86371a717f9b3c324407d8818ebec`. The original 37 members retained their path, type, mode, size, `mtime_ns`, and hash. The external clone contained no bytecode or pytest cache at its final scan; the clone, test base directory, and audit-local mutant runner were removed.

`git diff --check` and both new-file `/dev/null` whitespace checks were clean. Closing status still contains exactly the 28 paths above. No `src/` path changed, and migration `0005` remains absent. The remaining seams are the separately governed physical/value contracts: this verifier supplies no durable decision writer, scope provisioner, executable guard, terminal outcome, production caller, or runtime authority.

```text
NORMATIVE_DOCUMENTS_NOT_MODIFIED
C2_VERIFIER_NOT_MODIFIED
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
SCHEMAS_NOT_MODIFIED
OTHER_27_CANDIDATE_PATHS_NOT_MODIFIED
NON_CEILING_DOCS_NOT_MODIFIED
NON_CEILING_TESTS_NOT_MODIFIED
OPERATOR_OR_PRODUCT_DATABASE_NOT_OPENED_OR_MUTATED
ORIGINAL_37_CACHE_MEMBERS_NOT_MOVED_OR_MODIFIED
LIVE_REPOSITORY_MODULES_NOT_IMPORTED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
BOOTSTRAP_SCOPE_PROVISIONER_NOT_IMPLEMENTED
BOOTSTRAP_ACCEPTANCE_GUARD_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
REMOTE_CONTACT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
MERGE_NOT_PERFORMED
SUBAGENTS_NOT_SPAWNED
EXTERNAL_ARTIFACTS_NOT_GENERATED
```
