# Governed Execution Coordinator — RW0-C2 Bootstrap Guard Governing Reset V3 Actual-Call Causality Repair

## Role and objective

Resume the original governing-reset implementation conversation after the
operator changes the parent permission posture to workspace-write.

Use the highest available Codex reasoning setting. Record exactly what the
interface visibly shows for:

- model name;
- reasoning setting or effort.

Do not infer hidden configuration. Record `not visible` when necessary.

The parent is the sole repository writer. Do not spawn subagents.

Repair the exact uncommitted 28-path RW0-C2 bootstrap acceptance-guard
governing-reset V2 candidate after its fresh independent audit returned:

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_AUDIT_BLOCKED`

The audit established:

- exact candidate provenance;
- exact 28-path patch and canonical receipt;
- exact source, migration, public-surface, and runtime preservation;
- full repository validation at `7,741 passed, 3 warnings`;
- no selected-architecture or production-source defect;
- one High test-adequacy defect:
  actual model-consistency entry can occur before acceptance eligibility and be
  discarded without detection;
- one Medium test-adequacy defect:
  replay-helper entry can occur before writer fencing and be discarded without
  detection;
- one Low scenario-integrity defect:
  the supposedly unrelated second program can collapse to the first program
  without detection.

This is a **one-file verifier repair**. Do not reopen the selected architecture
or modify normative documents, the C2 verifier, production source, schemas,
migrations, readers, writers, transactions, public APIs, or runtime behavior.

Return one substantive inline closeout report. Do not create or attach an
external report, manifest, package, patch, freeze artifact, or other
client-visible file.

## Repository and committed baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed baseline beneath the candidate:

- branch: `trunk_dev`
- HEAD: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- tree: `42cc0757b3d9604dfe7fdbda158074b8b48dac7b`
- sole parent: `db16de711986ae40a2bb848ed00cdddd3145ee02`
- subject: `docs: freeze RW0-C durable decision branch contract`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- zero staged paths
- zero unmerged paths
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Do not fetch or contact remotes.

## Exact opening V2 candidate

Require exactly 26 tracked modifications and two untracked files and no other
difference from HEAD.

All 28 paths must be regular, non-symlink mode-`0644` files, valid UTF-8, with
no CR bytes, no trailing whitespace, and exactly one final newline.

| # | Status | Path | Bytes | SHA-256 |
|---:|---|---|---:|---|
| 1 | `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 70,858 | `4fc2b7f9d5810105c28a7ce11abe85d08a48f915a87b088ae86e5520aa2142e2` |
| 2 | `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | 57,192 | `2c0c9565f7fb4ae79eca998080f3b70734f9a4fd1e555132daf9b94daab1dc97` |
| 3 | `M` | `.docs/c2a-first-slice-semantic-protocol-contract.md` | 103,413 | `a690441d046d147cf11a068e07a894858e3d32476e19fef84a9bb26e6e6f0d99` |
| 4 | `M` | `.docs/c2b-durable-development-state.md` | 1,889,329 | `6115a29d5bbfb8ffb17404e9acbefcb8edc958554683afa3538e9d959e184ef8` |
| 5 | `M` | `AGENTS.md` | 61,466 | `001595cdec75b176abbfb99b91b2b06c45f2f2ff1a28c704ded7054c27c7e74e` |
| 6 | `M` | `README.md` | 45,849 | `b66fb689d9f0849eee1d62f12dda93d83dcc9f4cce2fa008696878b44256ad1a` |
| 7 | `M` | `.docs/architecture.md` | 43,007 | `60a884471d655ee6eddad8c405aa218eab492e3c610b101c0736fc9f2546288f` |
| 8 | `M` | `.docs/autonomous-software-development-operating-model.md` | 37,829 | `115ed6c16141f821147f640131bed904526cee914dbec6951f3667b0da100f05` |
| 9 | `M` | `.docs/authority-boundaries.md` | 34,686 | `69d524c839a2195cf0b5840be424c021305825fd0db1d85c76ed28b99c1bf055` |
| 10 | `M` | `.docs/durable-state-model.md` | 40,564 | `e14a421698f0735fa098fe6ce1063b64d07e1c212fd6b60755e1068c9caf5955` |
| 11 | `M` | `.docs/worker-execution-boundary.md` | 30,920 | `6f7d2f7855fcbdecc757af4dde7a7bb091ab1e8c60057a2fefe407f74de4055f` |
| 12 | `M` | `.docs/software-development-progression-boundary.md` | 28,654 | `b8761655ee42512c0e77ab8c774c2b2d3d8f9ac36a9bd0c74872ad4bf2994419` |
| 13 | `M` | `.docs/c2b3-program-initialization.md` | 27,687 | `8e9c2c6f49551b28d95de28f6d7b071c89dd0ea155ce7d7a6e21e8d88e73d1f7` |
| 14 | `M` | `.docs/rw0-b2-wire-protocol.md` | 24,346 | `7f977a5a60fd66c69464190731e09611ca24854313e145b73cc73f564776477b` |
| 15 | `M` | `.docs/rw0-b2-capability.md` | 17,753 | `171341fc60cbe762403f1e64676ca35c9ea2f778a10d0fc66d668f1c84dc884c` |
| 16 | `M` | `.docs/rw0-b1-pure-phase-values.md` | 33,032 | `8bccdaa31fa66821b73c136936c12ef001157209c72b9991839905c1a8e0e053` |
| 17 | `M` | `tests/test_architecture_contracts.py` | 100,410 | `555ac490738d12075d3908ec2ddfd090fdbb32d8a6fd53d1b3136d24485e1169` |
| 18 | `M` | `tests/test_rw0_remote_contact_phase_entry_contract.py` | 173,524 | `42d6d265c0a9ba5047aa37ec3a4daae30847d486d39ead6374685b451a1d445c` |
| 19 | `M` | `tests/test_remote_worker_pre_execution_planning_contract.py` | 913,152 | `92b0f3917f0572492357447211a1f0f0cc7f8edb7e8b5f18233ed80397879b29` |
| 20 | `M` | `tests/test_software_development_progression_boundary.py` | 42,899 | `bd9b10f62e3bbfb3dc5fc845958fe0087363a0afa0b80649853faac85235c7a3` |
| 21 | `M` | `tests/test_autonomous_software_development_operating_model.py` | 72,904 | `e9a77edb1f99b181c612e52c4a7cfee814ac3f0df4d974e7c3a0756aec6da8df` |
| 22 | `M` | `tests/c2a_contract_support.py` | 154,372 | `58be92ddffae6f4b901ae3632521481ab8d9ce0e02a819ef9421408d08eedd85` |
| 23 | `M` | `tests/test_rw0_b1_boundaries.py` | 38,321 | `bd52384897f8f7a7129023c693ef67b1ff453a006723438dfa4f06df08e4121f` |
| 24 | `M` | `tests/test_rw0_b2_capability_boundaries.py` | 45,708 | `4e4824b5974778cbef147e7f5a5684de34e5006464156cbb7be2958c33ce1a84` |
| 25 | `M` | `tests/test_c2b0_durable_state_contract.py` | 884,862 | `45a539a810deb8884c3f0158887a0d4fd06778a59e833c6b9d89365990ed62fd` |
| 26 | `M` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | 249,444 | `480bd282646304c70116f69faecabc1fea94d83ef54ec77b780a869ace5431c4` |
| 27 | `??` | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 25,151 | `bf65ba7f04411bb6e6febec2285b33721eb2ff895e2c60aee97878b1fa7c9b46` |
| 28 | `??` | `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | 63,314 | `0b5f13f41707413f051ef9a450b62242734e7978d30ebf99b1deb6f7f5f232cf` |

Required opening complete patch, constructed in the exact actual 28-path order:

- bytes: `282,372`
- SHA-256:
  `d16aecc7db8afd9a65c65dd8c228730562c2531a282ea3bb379a1af0ce6701ff`

Required opening canonical receipt:

- bytes: `5,593`
- SHA-256:
  `5bd53947d2187a3bacc710684ba35b646cb55fb4a1eaa3e91d18ecbf54accabb`

Use the fully specified receipt grammar from the V2 repair closeout:

- root object with `baseline` object and ordered `files` array;
- baseline fields:
  `branch`, `head`, `tree`, `parent`, `subject`, `upstream`, `divergence`,
  `staged`, `unmerged`;
- `divergence` is the literal string `0\t0`;
- file fields:
  `status`, `path`, `type`, `mode`, `bytes`, `sha256`;
- lexicographically sorted object keys;
- compact UTF-8 JSON, `ensure_ascii=false`, one final LF;
- files remain in exact candidate order.

Stop before editing on any mismatch:

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_V3_REPAIR_BLOCKED`

## Exact mutation ceiling

Only this one path may change from its opening V2 bytes:

`tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py`

The final changed/untracked path set relative to committed HEAD must remain the
same exact 28 paths.

The other 27 candidate paths must remain byte-identical to their opening
receipts.

Every source, migration, schema, package export, StateStore, WriterSession,
transaction, reader, writer, public, runtime, configuration, and example path
must remain byte-identical to HEAD.

Migration `0005` must remain absent.

If the one-file ceiling is insufficient, stop and restore the exact opening
candidate. Do not widen the tranche.

## Accepted semantics that must not be reopened

Preserve exactly:

- Option A: one explicitly standing-policy-admitted Coordinator authority
  lineage per bootstrap scope;
- operational realizations do not mint independent lineages or allowances;
- one active authority per lineage;
- continuity and sole-active-authority ambiguity fail closed;
- immutable admission and acceptance facts;
- one productive direct-local acceptance per admitted scope;
- permanent non-replenishment;
- acceptance fact integrated into the durable decision family;
- no mutable available/consumed latch subsystem;
- no acceptance fact on nonaccept branches;
- guard conflict is no-write, never durable block;
- receipt-first exact replay;
- one whole-family recovery classifier;
- partial families are unresolved;
- competing winner makes retry ineligible;
- terminal is later and non-mutating;
- ES routing is separate and non-replenishing;
- B1 legacy pair remains compatibility/nonproof only;
- no source, schema, migration, writer, reader, provisioner, caller, public, or
  runtime implementation exists.

This repair changes only verifier observation and scenario integrity.

## Finding H1 — actual model entry is not observed

The independent audit proved that required mutant S02 survives all C2 and guard
tests.

The mutant invokes `_model_consistency_phase` from inside the C2 defining
module's pre-model return path, discards its output, and returns the unchanged
prepared value. Returned traces therefore omit `model_consistency_evaluated`
even though the actual call occurred.

Current guard spies patch imported aliases only. Python global-name resolution
inside the C2 function uses the defining module's globals and bypasses those
spies.

### Required actual-call probe

Add one generic test-local actual-call probe mechanism that can instrument:

1. the callable's defining module attribute;
2. every relevant imported alias in the guard verifier;
3. any registry or bound reference actually used by the composed oracle.

Do not rely on returned trace markers as proof of non-entry.

For zero-call cases, the probe should make an unexpected entry impossible to
hide. A raising sentinel or equivalent hard-fail wrapper is preferred.

For positive-call cases, use a counting/order wrapper that delegates to the
original function and records actual helper entry.

The probe must restore every patched reference exactly.

### Required model-entry cases

Observe actual `_model_consistency_phase` entry for at least:

- exact same-command replay: zero;
- lineage mismatch: zero;
- missing/foreign admission: zero;
- multiple active authorities: zero;
- claimed scope on otherwise valid acceptance: zero;
- unresolved scope on otherwise valid acceptance: zero;
- eligible acceptance with recognized recommendation: exactly one;
- eligible acceptance with out-of-vocabulary recommendation: exactly one;
- each of the four nonaccept branches under exact universal posture: exactly
  one only when the owner contract requires model consistency for that branch;
  otherwise zero, with the exact owner-derived expectation fixed explicitly.

Do not infer the nonaccept expectation from current implementation behavior.
Derive it from the owner contract and bind it as a fixed expectation.

### Required defining-module integrity

Add a direct integrity test that:

- resolves the actual C2 test module object;
- identifies the exact function object used as the defining-module global;
- proves the probe wraps that module attribute;
- invokes the guard composition;
- asserts the observed call count and order from actual entry.

Add a structural guard requiring the actual-call test to patch the defining
module attribute, not only a local/imported alias.

### Required S02 variants

External mutants must include:

1. direct model call from `_c2_pre_model_phase` through the defining-module
   global, result discarded;
2. model call through an imported alias, result discarded;
3. model call through a one-level wrapper/indirection, result discarded;
4. forged `_guard_gates_passed=True` before calling the model phase;
5. actual call followed by removal of any returned trace marker.

Each must retain full collection and fail at an exact actual-entry or
phase-order boundary.

## Finding M1 — replay entry before fencing is invisible

The audit's X08 mutant invokes the replay helper at evaluator entry before
writer fencing, discards its result, and then follows the normal fenced path.
All guard tests pass because only the returned outcome/trace is inspected.

### Required replay actual-call probe

Identify the exact replay/collision helper or helpers used by the guard
composition.

Instrument:

1. the defining module attribute;
2. all relevant imported aliases;
3. any actual registry/bound reference used by the evaluator.

Observe actual entry and order. Do not infer entry from returned trace.

### Required replay/fencing cases

At minimum:

- unfenced caller: zero replay-helper entries;
- invalid writer/session admission: zero replay-helper entries;
- lineage/admission rejection that occurs before protected receipt disclosure:
  zero replay-helper entries;
- fenced fresh command: exactly one replay/collision check before fresh branch
  or guard evaluation;
- exact replay: exactly one replay/collision check, then no fresh branch,
  guard-eligibility, or model-consistency entry;
- mutation-ref reuse conflict: exactly one replay/collision check and no fresh
  branch/guard/model evaluation;
- family-route collision: exact owner-defined call count and no unauthorized
  later phase.

Capture one actual-entry event sequence and assert exact owner-derived order:

```text
writer_or_session_fenced
receipt_or_collision_helper_entered
authoritative_pre_model_entered
acceptance_guard_entered   # acceptance only
model_consistency_entered  # only after all earlier gates
```

Omit stages not applicable to a case, but never reorder them.

### Required replay variants

External mutants must include:

1. replay helper called before fencing through the defining-module global;
2. replay helper called before fencing through an imported alias;
3. replay helper called through a one-level wrapper, result discarded;
4. replay helper called twice, with the first call discarded;
5. exact replay also running fresh model consistency;
6. exact replay also running fresh guard eligibility.

Each must fail at an exact actual-entry count or order boundary.

## Finding L1 — cross-program scenario distinctness

The audit's X09 mutant replaces the second program identity with the first
program identity while retaining the test's labels and other behavior. All guard
tests pass.

The ordinary behavior test therefore no longer proves a cross-program ceiling.

### Required fixed scenario integrity

Freeze one explicit two-command cross-program scenario in the verifier.

Require:

- same admitted lineage;
- same bootstrap scope;
- same admission fact;
- first command targets program A;
- second command targets program B;
- program A and program B are exact, nonempty, and unequal;
- their program-head/basis coordinates belong to their respective programs;
- their command digests and mutation references are distinct;
- their candidate/attempt lineages are distinct where the scenario declares
  them distinct;
- the first acceptance commits the one fact;
- the second fresh acceptance is rejected because the shared scope is already
  claimed.

The direct integrity test must fail before behavioral execution if the scenario
does not actually contain two distinct program identities.

Do not let a human-readable label such as `unrelated_program_B` substitute for
the actual program identity assertion.

### Required scenario independence

Use fixed expected relationship assertions that are separate from the scenario
builder.

The scenario builder must not author its own expected `distinct=True` result.

Add an exact boundary such as:

`guard:cross_program_scenario:program_identity_distinct`

### Required X09 variants

External mutants must include:

1. program B ref changed to program A ref;
2. program B head/basis coordinates changed to program A while its label remains
   B;
3. command/mutation identity reused across A and B;
4. scope accidentally changed between A and B;
5. second scenario reduced to a same-program second attempt.

Each must retain collection and fail at a precise scenario-integrity or shared-
scope boundary.

## Structural and anti-shortcut requirements

Add AST/integrity checks proving:

- actual-call probes patch the defining module attributes;
- the probes inspect actual call counts/order after invocation;
- zero-call tests cannot pass merely by inspecting returned traces;
- model/replay wrappers either hard-fail or record before delegation;
- patched references are restored;
- cross-program tests compare actual program coordinates;
- no helper returns a self-authored boolean that is accepted without fixed
  comparison;
- no generic `pytest.raises(AssertionError)` receives semantic credit without an
  exact boundary.

Do not freeze incidental function line numbers.

Do not create a second reducer, replay owner, recovery classifier, or physical
guard model.

## Mutant battery

Rerun all 44 V2 negative mutants and the legitimate positive parser probe.

Also reproduce the audit's additional probes and at least these V3-specific
mutants:

### Model-entry mutants

- direct defining-module S02;
- imported-alias early model call;
- wrapper-indirected early model call;
- forged guard-passed stamp;
- discarded call with no trace marker.

### Replay-entry mutants

- defining-module replay before fencing;
- imported-alias replay before fencing;
- wrapper-indirected replay before fencing;
- duplicate replay call with discarded first result;
- exact replay with fresh model evaluation;
- exact replay with fresh guard evaluation.

### Scenario-integrity mutants

- B program ref collapsed to A;
- B head/basis collapsed to A;
- mutation/command identity reused;
- B assigned a different scope;
- same-program second attempt substituted for unrelated program B.

For every negative mutant require:

- complete expected collection;
- failure at the intended exact boundary;
- no syntax, import, formatting, fixture-collection, or parameter-count failure.

The legitimate no-backtick human-table positive must continue to pass.

## Reproducible selectors

Add uniquely reproducible selectors for at least:

```text
-k actual_model_entry
-k actual_replay_entry
-k fencing_before_replay_actual
-k model_after_guard_actual
-k cross_program_scenario_integrity
-k cross_program_ceiling
-k hostile
```

For each exact relevant module set:

1. run `--collect-only -q`;
2. record exact selected count;
3. execute the selector;
4. report exact result.

No selector may select zero or unrelated tests.

Preserve and rerun existing selectors:

```text
capability_semantic_integrity
guard_ordering_integrity
typed_human_machine_equivalence
closed_human_table
model_after_guard
operational_realization
c2b_current_status_authority
```

## Validation

Run all pytest commands serially in a clean local-only external clone with:

```text
PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=.:src
-p no:cacheprovider
--basetemp=<external path>
```

Do not move, rewrite, import through, or delete the live ignored cache.

### Focused C2 and guard modules

Run collection and execution for:

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_rw0_c2_durable_progression_decision_semantic_contract.py \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

V2 opening collection:

- C2: `1,334`
- Guard: `213`
- Combined: `1,547`

Final collection may increase but must not shrink. Explain every added node.

### Four focused modules

Run:

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_rw0_b2_capability_boundaries.py \
  tests/test_c2b0_durable_state_contract.py \
  tests/test_rw0_c2_durable_progression_decision_semantic_contract.py \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

V2 reference: `1,921 passed`.

### Exact 17-module targeted command

Run exactly:

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_architecture_contracts.py \
  tests/test_rw0_remote_contact_phase_entry_contract.py \
  tests/test_remote_worker_pre_execution_planning_contract.py \
  tests/test_software_development_progression_boundary.py \
  tests/test_autonomous_software_development_operating_model.py \
  tests/test_c2a_first_slice_semantic_protocol_contract.py \
  tests/test_c2a_nonimplementation.py \
  tests/test_rw0_b1_phase_values.py \
  tests/test_rw0_b1_vectors.py \
  tests/test_rw0_b1_relations.py \
  tests/test_rw0_b1_boundaries.py \
  tests/test_rw0_b2_wire_boundaries.py \
  tests/test_rw0_b2_capability_boundaries.py \
  tests/test_rw0_b2_wire_cancellation_control_boundaries.py \
  tests/test_c2b0_durable_state_contract.py \
  tests/test_rw0_c2_durable_progression_decision_semantic_contract.py \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

V2 implementation reference: `3,530 passed`.

### Exact broader command

Run exactly:

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_c2a*.py \
  tests/test_worker_execution_semantic*.py \
  tests/test_rw0_b1*.py \
  tests/test_rw0_b2*.py \
  tests/test_rw0_c1*.py \
  tests/test_post_execution_pure_owner*.py \
  tests/test_c2b2*.py \
  tests/test_c2b3*.py \
  tests/test_section41*.py \
  tests/test_runtime_non_authority.py \
  tests/test_state_store_contract.py \
  tests/test_b2a_writer_session_contract.py \
  tests/test_sqlite*.py
```

V2 implementation reference: `3,611 passed, 3 warnings`.

### Full repository

Run:

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external>
```

V2 reference: `7,741 passed, 3 warnings`.

Final counts may increase but must not shrink without an exact justified
collection change.

The only expected warnings remain the three unchanged Python 3.13 multi-
threaded `fork()` deprecations in:

- `test_operation_guard_close_waits_and_retains_authority_until_exit`;
- `test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang`;
- `test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock`.

Also require:

- `git diff --check`;
- both new-file `/dev/null` whitespace checks;
- UTF-8/CR/trailing-whitespace/final-newline checks for all 28 paths;
- exact source/migration/schema/public/runtime preservation;
- exact C2B and C2B3 historical reconstruction;
- artifact scan.

No product or operator database may be opened.

## Live cache and temporary data

At opening and closeout, record member-level equality for the 37 pre-existing
ignored cache files:

- repository-relative path;
- type;
- mode;
- byte size;
- `mtime_ns`;
- SHA-256.

Member equality is authoritative for this engagement.

If an aggregate is reported, define its complete canonical grammar in the
closeout. Do not require equality with the V2 audit's unresolved historical
aggregate.

Remove only engagement-created temporary data.

## Closeout provenance

Return inline:

1. primary outcome token;
2. visible model/reasoning setting;
3. opening and closing Git coordinates;
4. exact final 28-path receipt table;
5. exact one-file V2-to-V3 transition;
6. proof the other 27 candidate paths stayed byte-identical;
7. actual model-entry instrumentation and results;
8. actual replay-entry instrumentation and results;
9. cross-program scenario-integrity repair;
10. all original and new mutant results;
11. selector collection/execution results;
12. focused, targeted, broader, and full validation;
13. source/migration/public/runtime preservation;
14. deterministic complete binary patch bytes and SHA-256;
15. fully specified canonical receipt grammar, bytes, and SHA-256;
16. cache opening/closing member equality;
17. cleanup and artifact posture;
18. remaining physical/value seams;
19. all required non-actions.

Calculate the final complete patch twice, in the exact 28-path order, and
require byte-identical output.

Calculate the canonical receipt twice with two independent implementations and
require byte-identical output.

Do not stage, commit, push, create/modify a PR, or merge.

## Success token

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_REPAIRED_V3_VALIDATED_READY_FOR_REAUDIT`

Success authorizes only a fresh independent read-only audit of the exact
repaired 28-path candidate.

## Blocking token

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_V3_REPAIR_BLOCKED`

Use the blocking token if:

- the opening candidate differs;
- the one-file ceiling is insufficient;
- a normative document or C2 verifier must change;
- production source, schema, migration, writer, or runtime changes are required;
- accepted architecture must change;
- another candidate path must change.

Do not leave partial repair bytes under a blocking outcome; restore the exact
opening V2 candidate.

## Required non-actions

State:

```text
NORMATIVE_DOCUMENTS_NOT_MODIFIED
C2_VERIFIER_NOT_MODIFIED
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
SCHEMAS_NOT_MODIFIED
OTHER_27_CANDIDATE_PATHS_NOT_MODIFIED
NON_CEILING_DOCS_NOT_MODIFIED
NON_CEILING_TESTS_NOT_MODIFIED
OPERATOR_OR_PRODUCT_DATABASE_NOT_OPENED_OR_MUTATED
LIVE_IGNORED_CACHE_NOT_MOVED_OR_MODIFIED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
BOOTSTRAP_SCOPE_PROVISIONER_NOT_IMPLEMENTED
BOOTSTRAP_ACCEPTANCE_GUARD_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
REMOTE_CONTACT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
MERGE_NOT_PERFORMED
SUBAGENTS_NOT_SPAWNED
EXTERNAL_ARTIFACTS_NOT_GENERATED
```
