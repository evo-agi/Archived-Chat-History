# Governed Execution Coordinator — RW0-C2 Acceptance-Latch Owner Read-Only Reconnaissance

## Role

Perform one parent-led, repository-first, read-only architecture reconnaissance
of the missing RW0-C2 acceptance-latch owner.

Use the current merged Coordinator repository as the sole source of current
contract truth. Historical reports, prior chat artifacts, package freezes, and
unmerged design proposals are evidence only and must not silently become current
contracts.

Return one substantive report inline in the Codex response with exact
repo-relative path-and-line evidence.

Do not generate or attach a report, JSON manifest, freeze package, or other
artifact. Do not issue an implementation prompt.

## Repository and exact baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required baseline:

- branch: `trunk_dev`
- HEAD: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- tree: `42cc0757b3d9604dfe7fdbda158074b8b48dac7b`
- sole parent: `db16de711986ae40a2bb848ed00cdddd3145ee02`
- subject: `docs: freeze RW0-C durable decision branch contract`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- clean tracked, untracked, staged, and unmerged state
- no active Git operation or index lock

Do not fetch or contact remotes.

Stop before architecture inspection if any coordinate or cleanliness property
differs, and return:

`RW0_C_ACCEPTANCE_LATCH_OWNER_RECONNAISSANCE_BLOCKED`

## Posture

This engagement is read-only.

Permitted:

- read-only Git inspection;
- static inspection of repository guidance, documents, source, SQL, migrations,
  tests, examples, and configuration;
- at most three bounded read-only explorer subagents with self-contained prompts.

Prohibited:

- editing, formatting, creating, deleting, or moving repository files;
- running tests, migrations, scripts, or services;
- opening or mutating a database;
- installing dependencies;
- importing repository modules for execution;
- staging, committing, pushing, creating or modifying a PR, or merging;
- contacting networks or sibling repositories;
- generating retained artifacts;
- inspecting or exposing secret-bearing or ignored runtime state.

At closeout, verify HEAD and repository status remain unchanged.

## Current merged contract that must be preserved

The merged repository now owns the accepted future RW0-C2 progression-decision
semantic contract in:

`.docs/rw0-c2-durable-progression-decision-semantic-contract.md`

Treat these as fixed accepted semantics unless repository evidence exposes a
direct contradiction:

- exactly five non-cancel progression branches;
- no-write versus durable decision versus recovery-unresolved separation;
- acceptance is derived by the Coordinator, not requested by the caller or
  model;
- every future decision command binds a future-owner-defined latch selector;
- the selector identifies one exact expected `available` preimage and one
  preassigned `consumed` postimage;
- the selector is covered by the command digest and recovery selector;
- the selector grants no authority and does not request acceptance;
- acceptance verifies the available preimage and atomically commits the
  decision plus consumed postimage;
- missing, duplicate, malformed, ambiguous, mismatched, or already-consumed
  state is `acceptance_latch_precondition_conflict`, with no durable write and
  no fallback block;
- exact replay returns the committed latch postimage without a second mutation;
- committed-recovery verifies decision and latch as one family;
- nonaccept branches create no latch mutation and no latch postimage;
- a later terminal-outcome fact may bind the already committed latch postimage
  but never consumes or mutates it;
- no accept writer may become callable before the complete latch owner and later
  physical family are frozen.

The current repository implements none of the following:

- RW0-C2 durable decision command or writer;
- acceptance-latch owner or storage;
- terminal-outcome owner;
- migration `0005`;
- production caller;
- public export;
- runtime activation.

Do not report accepted future semantics as current implementation.

## Historical-latch conflict that must be adjudicated

Early sections of `.docs/c2b-durable-development-state.md` describe a target
`development_first_slice_latch` with global-bootstrap scope and a one-way
`available -> consumed` transition.

Do not assume that design is current or enduring.

The current repository also states:

- application generation remains `2`;
- the implemented migration tip is
  `0004_rw0_c1_durable_evidence`;
- actual migration `0003` is
  `0003_cognitive_proposal_and_selection_state`, not the historical latch
  migration described by early C2B planning;
- the latest append-only C2B and operating-model overlays say no latch owner,
  latch storage, reader, writer, or mutation is implemented;
- migration `0005` is absent;
- the separate RW0-C2 semantic owner freezes only an abstract latch dependency.

Determine exactly whether the historical first-slice latch is:

- a historical or superseded target;
- a bounded proof-only precursor;
- a compatibility concept worth reusing;
- a still-binding target invariant;
- or an architecture that must be rejected for the durable autonomy target.

State conflicts. Do not reconcile them silently.

## Primary objective

Determine the narrowest truthful logical acceptance-latch ownership contract
that must be frozen before any RW0-C2 accept writer or physical-persistence
implementation can be designed.

The reconnaissance must decide whether:

1. one standalone logical latch-owner contract can now be frozen; or
2. the latch cannot be truthfully frozen without co-freezing a larger safe
   command/result/receipt/replay/recovery semantic family; or
3. repository contradictions or missing operating-model decisions block the
   freeze.

Do not select SQL, table names, migration bytes, source modules, public methods,
or writer implementation in this engagement.

## Required architecture questions

### 1. Non-redundant invariant

Identify the exact mutable fact the latch owns that is not already owned by:

- program-head/version CAS;
- decision identity and branch uniqueness;
- `mutation_ref` idempotency;
- decision/result/receipt family identity;
- accepted-intent/work-item identities;
- candidate or attempt identity;
- effect/delivery heads.

If the latch has no independent non-redundant invariant, surface that conflict
rather than inventing a new mutable fact.

Explain the specific double-action or replay hazard prevented by latch
consumption.

### 2. Scope and cardinality

Determine the correct logical latch scope.

Compare at minimum:

- one global Coordinator bootstrap latch;
- one latch per development program;
- one latch per program epoch or expected program-head/version preimage;
- one latch per semantic attempt;
- one latch per candidate;
- one latch per accepted-intent/work-item creation boundary;
- any better repository-grounded scope.

For each option, test whether it:

- permits continuing autonomous program progression;
- prevents duplicate acceptance;
- preserves exact replay;
- avoids turning one historical first-slice constraint into permanent product
  architecture;
- avoids duplicating existing CAS or idempotency ownership;
- supports future repair/replan/accept cycles.

Select one scope, or state why a larger operating-model decision is required.

### 3. Logical owner and mutable-fact authority

Identify the exact future owner of:

- latch identity;
- latch scope identity;
- latch state;
- latch version or revision, if any;
- available preimage;
- consumed postimage;
- selector identity and digest;
- postimage binding to the committed acceptance family;
- replay projection;
- recovery classification.

For every field or fact, classify it as:

- current Git fact;
- current Coordinator durable fact;
- future latch-owner fact;
- future durable-decision-writer fact;
- future terminal-outcome fact;
- external evidence;
- derived projection.

Preserve one authoritative writer per mutable fact.

### 4. Selector contract

Determine the minimum selector sufficient to identify exactly one expected
available preimage and one preassigned consumed postimage.

Decide which current/future coordinates it must bind, such as:

- program reference;
- expected program-head revision;
- basis program version;
- semantic attempt;
- candidate;
- accepted-intent revision;
- work item;
- phase/evidence closure;
- latch epoch or scope reference;
- preimage version;
- preassigned decision/result/receipt identities.

Do not include a field merely because it exists.

Require the selector to be:

- canonical;
- covered by the command digest;
- covered by the recovery selector;
- non-authoritative;
- incapable of requesting acceptance;
- sufficient for exact replay and committed-family readback.

### 5. Available preimage and consumed postimage

Specify the complete logical preimage and postimage without selecting physical
storage.

Determine whether the preimage needs:

- schema/profile identity;
- latch reference;
- scope reference;
- state `available`;
- version/revision;
- expected program/head/version binding;
- creation or validity coordinates;
- canonical digest.

Determine whether the consumed postimage must bind:

- the same latch/scope identity;
- state `consumed`;
- successor version/revision;
- exact acceptance decision;
- resulting program version/head;
- selected semantic attempt;
- accepted candidate;
- resulting accepted-intent revision;
- resulting work item/revision;
- result and receipt;
- mutation reference and command digest;
- commit timestamp;
- postimage digest.

Distinguish identities needed for authority from identities retained only as
evidence.

### 6. State machine and closed no-write taxonomy

Freeze the logical state machine.

At minimum adjudicate:

- available -> consumed;
- consumed -> consumed replay;
- missing;
- duplicate;
- malformed;
- ambiguous;
- scope mismatch;
- identity mismatch;
- digest mismatch;
- version/revision mismatch;
- already consumed by the exact same command;
- already consumed by a different command;
- preassigned postimage collision;
- partial committed family.

Determine which cases are:

- exact replay;
- `acceptance_latch_precondition_conflict`;
- `mutation_ref_reuse_conflict`;
- `preassigned_identity_or_family_route_collision`;
- committed-recovery `unresolved`;
- another already-owned rejection class.

Do not invent overlapping error owners.

### 7. Atomicity, replay, and committed recovery

Determine the exact logical transaction family for acceptance.

Require analysis of:

- preflight/read-before-write;
- expected preimage;
- decision, version/head, result, receipt, and latch postimage atomicity;
- exactly one commit attempt;
- same-command replay;
- different-command reuse conflict;
- commit-attempt exception;
- readback selector;
- `committed_exact`;
- `definitely_not_committed`;
- `unresolved`;
- partial decision-without-latch;
- partial latch-without-decision;
- no second latch mutation during replay or recovery;
- conditions under which a clean retry is permitted.

Compare with current implemented mutation/recovery patterns, but do not claim
they currently support RW0-C2.

### 8. Relationship to command/result/receipt semantic ownership

Determine whether a latch owner can be frozen independently while merely
referencing future command/result/receipt contracts.

Alternatively, determine whether the following must be co-frozen in one
logical contract because they share identities and recovery truth:

- decision command;
- latch selector;
- preassigned family identities;
- result;
- receipt;
- replay projection;
- recovery selector;
- committed-family classifier.

Select the narrowest coherent freeze. Avoid a split that allows disagreement
about what was committed.

### 9. Relationship to terminal outcome

Preserve the separate terminal owner.

Specify only the latch-facing boundary:

- which immutable consumed-postimage identity terminal outcome later binds;
- why terminal outcome cannot consume, reset, or update the latch;
- how terminal readback distinguishes absent terminal fact from an absent or
  unresolved acceptance family.

Do not design terminal storage or terminal writer behavior.

### 10. Physical-persistence handoff

Do not select the physical design, but determine the constraints it must satisfy.

Compare as future physical options:

- migration-free reuse of current decision/version/head/receipt tables;
- additive migration `0005`;
- bounded hybrid.

Identify:

- which current migration-0002 facts can remain canonical;
- which latch facts cannot be represented truthfully today;
- whether any historical C2B latch shape is reusable;
- what immutable relation or current-row capability a later physical freeze
  must add;
- whether the existing transaction controller and `WriterSession` can remain
  the sole mutation authority in principle;
- what reader/recovery surfaces would be required.

Do not select the smallest diff by default. Select the narrowest truthful
future representation constraint.

### 11. Security and authority boundaries

Require fail-closed treatment of:

- caller-authored state or postimages;
- model-authored state or branch;
- stale selector/preimage;
- ambiguous reads;
- duplicate rows;
- cross-program or cross-candidate confusion;
- replay under a different command digest;
- terminal mutation of latch state;
- public/API widening;
- external authority masquerading as latch ownership.

The latch grants no execution authority and does not displace standing-policy,
global-stop, ES admission/runtime, or Git authority.

### 12. Contract and test surfaces for the next tranche

Identify the exact governing-document and contract-test surfaces required for a
future documentation/contract freeze.

Recommend:

- the owning document path;
- status and authority language;
- cross-reference updates;
- finite contract-test responsibilities;
- hostile and causality requirements;
- nonimplementation guards;
- exact stop conditions before source or migration work.

Do not write the contract or tests now.

## Minimum inspection

Inspect at minimum:

### Guidance and governing documents

- `AGENTS.md`
- `README.md`
- `.docs/autonomous-software-development-operating-model.md`
- `.docs/architecture.md`
- `.docs/authority-boundaries.md`
- `.docs/software-development-progression-boundary.md`
- `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
- `.docs/rw0-c1-durable-evidence.md`
- `.docs/rw0-remote-worker-contact-phase-entry.md`
- `.docs/c2b-durable-development-state.md`
- `.docs/durable-state-model.md`
- `.docs/sqlite-operations-and-recovery.md`
- `.docs/sqlite-threat-model.md`

### Current durable representation

- `src/ge_nwp_coordinator/sqlite_migration.py`
- `src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql`
- `src/ge_nwp_coordinator/sqlite_migrations/0003_cognitive_proposal_and_selection_state.sql`
- `src/ge_nwp_coordinator/sqlite_migrations/0004_rw0_c1_durable_evidence.sql`
- `src/ge_nwp_coordinator/_development_decision_row_values.py`
- `src/ge_nwp_coordinator/_development_program_row_values.py`
- `src/ge_nwp_coordinator/_development_effect_row_values.py`
- `src/ge_nwp_coordinator/_development_row_value_support.py`
- `src/ge_nwp_coordinator/_rw0_c1_mutation_contracts.py`
- `src/ge_nwp_coordinator/_rw0_c1_row_values.py`
- `src/ge_nwp_coordinator/_rw0_c1_semantic_values.py`

### Readers, mutation, transaction, and recovery patterns

- `src/ge_nwp_coordinator/_sqlite_development_reader_contracts.py`
- `src/ge_nwp_coordinator/_sqlite_development_readers.py`
- `src/ge_nwp_coordinator/_sqlite_development_program_initialization.py`
- `src/ge_nwp_coordinator/_sqlite_development_author_effect_establishment.py`
- `src/ge_nwp_coordinator/_sqlite_rw0_c1.py`
- `src/ge_nwp_coordinator/_sqlite_rw0_c1_reader_contracts.py`
- `src/ge_nwp_coordinator/_sqlite_rw0_c1_readers.py`
- `src/ge_nwp_coordinator/sqlite_mutation_transaction_contracts.py`
- `src/ge_nwp_coordinator/sqlite_transition_transaction.py`
- `src/ge_nwp_coordinator/sqlite_writer_session.py`
- `src/ge_nwp_coordinator/state_store.py`

### Relevant tests

- `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`
- `tests/test_c2b0_durable_state_contract.py`
- `tests/test_sqlite_c2b2_migration_0002.py`
- `tests/test_sqlite_section41_migration_0003.py`
- `tests/test_sqlite_rw0_c1_migration_0004.py`
- `tests/test_c2b2_development_decision_row_values.py`
- `tests/test_c2b2_development_program_row_values.py`
- `tests/test_c2b2_development_reader_contracts.py`
- `tests/test_c2b2_private_development_readers.py`
- `tests/test_c2b3_private_atomic_program_initialization.py`
- `tests/test_c2b3_program_initialization_recovery.py`
- `tests/test_c2b3d_private_atomic_author_effect_establishment.py`
- `tests/test_c2b3d_author_effect_establishment_recovery.py`
- `tests/test_rw0_c1_private_atomic_persistence.py`
- `tests/test_rw0_c1_recovery.py`
- `tests/test_rw0_c1_writer_session_delegation.py`
- current nonimplementation, public-surface, migration, and runtime-authority
  tests relevant to a future latch owner.

Follow additional relevant source/test edges discovered during inspection.

## Explorer structure

Use at most three bounded read-only explorers.

Suggested scopes:

1. **Contract/history explorer**
   - classify current versus historical latch claims;
   - determine the non-redundant latch invariant and scope;
   - inspect operating-model and authority implications.

2. **Durable-state/recovery explorer**
   - map existing decision/version/head/receipt/readback patterns;
   - derive selector, preimage, postimage, replay, and recovery constraints;
   - compare future physical options without selecting SQL.

3. **Security/test-boundary explorer**
   - identify authority, ambiguity, collision, stale-state, and replay risks;
   - map governing docs and contract tests for the next tranche;
   - identify source/migration stop conditions.

The parent must inspect the central evidence independently, preserve
disagreements, and reconcile the final recommendation.

No nested subagents. Make at most one bounded retry for a failed explorer.

## Report requirements

Return one inline report with:

1. primary disposition;
2. exact baseline and unchanged closeout;
3. inspection scope and limits;
4. current implementation versus accepted target;
5. disposition of the historical `development_first_slice_latch`;
6. non-redundant invariant;
7. selected latch scope and rejected scopes;
8. complete logical fact and authority inventory;
9. selector contract;
10. available-preimage and consumed-postimage contract;
11. state machine and no-write taxonomy;
12. atomicity, replay, and committed-recovery contract;
13. standalone versus co-freeze decision;
14. terminal-outcome boundary;
15. future physical-persistence constraints;
16. security and authority analysis;
17. exact next contract/test surfaces;
18. rejected alternatives;
19. unresolved seams;
20. exact next permitted decision;
21. compact continuation capsule of no more than 1,000 words;
22. required non-actions;
23. final disposition token.

Use exact repo-relative path-and-line evidence for every substantive claim and
recommendation.

Separate:

- current implemented contract;
- historical or superseded design;
- accepted strategic target;
- reopened seam;
- inference;
- report-only uncertainty.

Do not use unsupported numerical confidence percentages.

## Disposition tokens

Return exactly one:

### Standalone logical owner can be frozen next

`RW0_C_ACCEPTANCE_LATCH_OWNER_READY_FOR_CONTRACT_FREEZE`

### Latch must be co-frozen with a larger semantic family

`RW0_C_ACCEPTANCE_LATCH_OWNER_CO_FREEZE_REQUIRED`

### Contradiction or missing operating-model decision blocks a truthful freeze

`RW0_C_ACCEPTANCE_LATCH_OWNER_BLOCKED`

Do not issue an implementation prompt under any disposition.

## Required non-actions

State:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
DATABASE_NOT_OPENED_OR_MUTATED
DEPENDENCIES_NOT_INSTALLED
SERVICES_NOT_STARTED
REMOTE_CONTACT_NOT_PERFORMED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
ARTIFACTS_NOT_GENERATED
JSON_MANIFEST_NOT_GENERATED
CONTRACT_NOT_WRITTEN
IMPLEMENTATION_PROMPT_NOT_ISSUED
SOURCE_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
ACCEPTANCE_LATCH_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
SUBAGENTS_READ_ONLY_IF_USED
```
