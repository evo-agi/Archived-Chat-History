# Governed Execution Coordinator — RW0-C2 Bootstrap Acceptance-Guard Semantic Amendment

## Role and execution posture

Use a fresh Codex conversation configured by the operator to the **highest
available reasoning setting**.

Before repository inspection, record exactly what the Codex interface visibly
shows for:

- model name;
- reasoning setting or effort.

Do not infer hidden configuration. If either value is not exposed, record
`not visible`. Do not downgrade the selected reasoning setting during this
engagement.

This is a parent-only workspace-write tranche. Do not spawn subagents.

Amend and validate the merged RW0-C2 durable-decision semantic contract and its
causal verifier **atomically with** a new bootstrap acceptance-guard owner
contract and verifier.

The selected architecture is:

- one immutable bootstrap-scope admission fact;
- at most one immutable bootstrap-acceptance fact for that scope;
- acceptance evidence integrated atomically into the durable decision family;
- no mutable `available -> consumed` latch subsystem;
- no lazy scope creation by the decision writer;
- exact replay and one whole-family three-way recovery classifier;
- no acceptance fact on nonaccept branches;
- terminal outcome remains later and non-mutating.

Do not implement source, migrations, schemas, readers, writers, transactions,
public APIs, production callers, runtime behavior, RW0-D/E, or Execution
Substrate behavior.

Return one substantive inline closeout report. Do not create or attach an
external report, manifest, package, or freeze artifact.

## Exact repository baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required opening baseline:

- branch: `trunk_dev`
- HEAD: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- tree: `42cc0757b3d9604dfe7fdbda158074b8b48dac7b`
- sole parent: `db16de711986ae40a2bb848ed00cdddd3145ee02`
- subject: `docs: freeze RW0-C durable decision branch contract`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- clean tracked, untracked, staged, and unmerged state
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Do not fetch or contact remotes.

Stop before editing on any mismatch:

`RW0_C_BOOTSTRAP_ACCEPTANCE_GUARD_SEMANTIC_AMENDMENT_BLOCKED`

## Product-policy decision — authoritative strategic input

Freeze the following accepted product policy exactly.

### Coordinator authority lineage

The scope is one explicitly admitted **Coordinator authority lineage**.

A deployment, machine, process, database, database file, repository, program,
attempt, candidate, command, parent grant, or runtime realization does not
create a new lineage or bootstrap scope merely by existing.

A genuinely independent Coordinator authority lineage may receive its own
bounded direct-local bootstrap scope only through an explicit standing-policy
admission act.

### Continuity

Machine replacement, database replacement, restore, rollback, cloning, passive
backup, or relocation do not create a new scope or allowance.

After any such event, lineage continuity and bootstrap-acceptance status must be
positively established. If either cannot be established exactly, the relevant
guard state is unresolved and must fail closed.

Absence of a local bootstrap-acceptance row, relation, or projection is never
sufficient evidence that the scope is unclaimed.

### Single active authority

The current target supports one active Coordinator authority per lineage.

Active-active operation by multiple database copies or multiple Coordinator
authorities claiming one lineage is unsupported. Ambiguous, conflicting, or
unfenced active-authority evidence fails closed.

### Permanent one-shot ceiling

After one productive direct-local `candidate_acceptance` commits:

- the immutable bootstrap-acceptance fact remains permanent;
- the scope is never reset, renewed, reopened, replenished, deleted, or
  recreated;
- a new grant, policy epoch, program, command, machine, database, restore, or
  relocation cannot create another allowance.

Later ES-routed operation is governed separately and does not consume,
replenish, or reset this bounded direct-local proof allowance.

## Current merged truth and required amendment

The current merged RW0-C2 semantic owner is:

`.docs/rw0-c2-durable-progression-decision-semantic-contract.md`

Opening receipt:

- bytes: `68,944`
- SHA-256:
  `92f1d2b34f9cf2486102edf31de142acc07db9a116f64d64212ca497d0a554c1`

Its causal verifier is:

`tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`

Opening receipt:

- bytes: `239,999`
- SHA-256:
  `9b0751f55b238c55130b6481bbea34454c5ed8866212f5546baa6e5af1b0fa19`

These two files are intentionally in scope for amendment.

Preserve the accepted reducer semantics:

- exactly five non-cancel branches;
- Coordinator-derived branch authority;
- no-write versus durable block versus recovery-unresolved;
- V14/V15 reduction, currentness, matrix, and branch precedence;
- model and caller non-authority;
- exact migration-0002 branch mapping;
- exact replay and whole-family recovery;
- terminal outcome separation;
- physical persistence remaining future.

Replace the merged abstract standalone-latch interface.

The prior standalone latch-owner prompt was never executed and is superseded.
Do not preserve its mutable `available -> consumed` architecture by inertia.

## Historical material

Historical Section 19 of:

`.docs/c2b-durable-development-state.md`

remains historical/proof-only source material.

Retain as current strategic constraints:

- one shared bounded bootstrap acceptance ceiling;
- no reset, deletion, reuse, or replenishment;
- atomic binding of consumption evidence to acceptance;
- fail-closed treatment of missing, duplicate, malformed, ambiguous, or
  conflicting state.

Classify as reopened or superseded:

- a mutable latch row;
- `available` and `consumed` state ownership;
- latch revision transition;
- seed-row semantics;
- historical migration-0003 allocation;
- old table, key, trigger, and index selections;
- mandatory preassigned consumed-latch postimage;
- standalone latch replay or recovery ownership.

Do not rewrite historical sections. Add a current append-only successor
classification.

## Exact mutation ceiling

Only these eight paths may differ from HEAD at closeout:

1. `.docs/architecture.md`
2. `.docs/autonomous-software-development-operating-model.md`
3. `.docs/c2b-durable-development-state.md`
4. `.docs/rw0-remote-worker-contact-phase-entry.md`
5. `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
6. `.docs/rw0-c2-bootstrap-acceptance-guard-contract.md`
7. `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`
8. `tests/test_rw0_c2_bootstrap_acceptance_guard_contract.py`

Paths 1–4 are bounded status, composition, and cross-reference updates.

Path 3 must change only by appending a successor section after the current EOF.
Every opening byte before the append point must remain exact.

Path 5 is the existing semantic-owner amendment.

Path 6 is the new guard owner.

Path 7 is the existing causal-verifier amendment.

Path 8 is the new guard contract verifier.

No other existing test may change.

Protected paths include, at minimum:

- `AGENTS.md`;
- `README.md`;
- `.docs/authority-boundaries.md`;
- `.docs/software-development-progression-boundary.md`;
- `.docs/rw0-c1-durable-evidence.md`;
- all `src/`;
- every migration and the migration catalog;
- all schemas;
- package exports;
- `StateStore`;
- `WriterSession`;
- transaction, reader, and writer source;
- every other `.docs/` path;
- every other test;
- configuration and examples.

Migration `0005` must remain absent.

If a direct contradiction in a protected governing document makes the eight-path
contract impossible, stop rather than widen scope.

## Authority split between the two semantic owners

Freeze a non-overlapping two-owner split.

### Existing RW0-C2 durable-decision owner

It remains sole semantic owner of:

- command-local grammar and authoritative input reduction;
- the five branches;
- decision, program-version, and head semantics;
- result and receipt roles;
- mutation identity and command digest;
- branch-neutral replay semantics;
- the one complete-family recovery classifier;
- no-write, durable-block, and recovery-unresolved distinctions;
- terminal-outcome separation.

### New bootstrap acceptance-guard owner

Create:

`.docs/rw0-c2-bootstrap-acceptance-guard-contract.md`

Title:

`RW0-C2 Bootstrap Acceptance-Guard Contract`

It is sole semantic owner of:

- admitted Coordinator authority-lineage scope;
- immutable bootstrap-scope admission fact;
- direct-local bootstrap applicability;
- the one-shot cross-program acceptance invariant;
- the immutable bootstrap-acceptance fact;
- acceptance-guard eligibility and fail-closed classifications;
- the acceptance fact’s membership in the durable decision family;
- permanent non-replenishment;
- the guard-facing terminal boundary.

It does not own:

- branch derivation;
- the complete command/result/receipt schemas;
- a separate receipt;
- a separate replay classifier;
- a separate recovery classifier;
- physical storage;
- standing-policy issuance;
- execution authority;
- ES runtime;
- Git or publication.

The future guarded durable-decision transaction remains the sole writer of the
bootstrap-acceptance fact.

## 1. Safety invariant

Freeze:

> For one explicitly admitted Coordinator authority lineage, across every
> participating direct-local bootstrap program, attempt, candidate, command,
> restart, restore, replacement, relocation, clone, and parent grant, at most
> one distinct productive `candidate_acceptance` may commit.

The corresponding immutable bootstrap-acceptance fact must commit in the same
complete durable decision family.

Distinguish:

- exact replay of one command; and
- prevention of a second fresh acceptance by another valid command.

Program-head CAS, decision identity, `mutation_ref`, candidate identity, and
receipt identity do not replace this cross-program invariant.

## 2. Immutable bootstrap-scope admission fact

Freeze one immutable admission fact for the lineage.

It must bind, by semantic role:

- guard owner/profile identity;
- Coordinator authority-lineage identity;
- bootstrap scope identity;
- standing-policy admission act identity and digest;
- bounded direct-local applicability;
- admission provenance;
- non-renewable one-shot ceiling;
- admission fact identity and canonical digest.

Authority treatment:

- standing policy owns whether an independent lineage is admitted;
- Coordinator durably records the exact admitted binding under a future
  separately authorized provisioning family;
- the durable decision writer cannot create, replace, renew, or repair the
  admission fact;
- schema installation or an empty database does not admit a scope;
- the fact grants no execution, branch, runtime, publication, or Git authority.

The physical provisioning mechanism remains future.

## 3. Lineage continuity and active-authority condition

Freeze a logical continuity predicate.

Every applicable direct-local bootstrap command must bind exact admitted lineage
coordinates sufficient for the Coordinator to derive one scope.

Acceptance eligibility requires exact evidence that:

- the current Coordinator is operating as the one active authority for that
  lineage;
- the admission fact belongs to that lineage;
- restore/replacement/relocation continuity is exact;
- no competing active authority or conflicting lineage claim is known;
- the bootstrap-acceptance status can be classified exhaustively.

A machine, database, or process identifier is evidence about an operational
realization, not the lineage identity.

A copied or restored database does not create independence.

If lineage identity, continuity, or sole-active-authority posture is missing,
ambiguous, foreign, stale, conflicting, unreadable, or unfenced, no RW0-C2
branch commits.

If lineage is exact but only the acceptance-status read is unresolved:

- `candidate_acceptance` is no-write;
- a nonaccept branch may commit only when it does not depend on an unclaimed
  scope and every other command/branch precondition remains exact;
- it creates no bootstrap-acceptance fact.

This distinction must be explicit and causally tested.

## 4. Immutable bootstrap-acceptance fact

For `candidate_acceptance` only, create at most one immutable fact per admitted
scope.

The fact must bind, by semantic role:

- guard owner/profile identity;
- lineage and scope identities;
- admission-fact identity and digest;
- acceptance-fact identity;
- consuming `mutation_ref`;
- canonical command digest;
- exact durable acceptance decision identity and digest;
- resulting program-version identity;
- committed head-postimage identity and digest;
- selected semantic attempt and candidate lineage;
- immutable decision-basis identity/digest;
- family-route identity;
- one transaction timestamp;
- canonical acceptance-fact digest.

The fact is a member of the same atomic decision/result/receipt family.

It is not a mutable row state and has no successor state.

No fact is created for repair, replan, terminal reject, or block.

## 5. Guard derivation

Availability is not a stored mutable `available` state.

A fresh acceptance is eligible only when all of the following are proved:

1. exact admitted scope;
2. exact lineage continuity;
3. exact sole-active-authority posture;
4. exhaustive guard read;
5. zero committed bootstrap-acceptance facts for the scope;
6. zero duplicate, alias, collision, fragment, malformed, foreign, or unreadable
   guard families;
7. exact command-family route;
8. every ordinary RW0-C2 acceptance precondition.

Absence of a local row alone receives no semantic credit.

## 6. Command-facing relation

Amend the current command contract so every applicable direct-local bootstrap
command binds admitted lineage and scope-expectation coordinates.

The relation must be:

- canonical;
- covered by the command digest;
- covered by the complete-family recovery selector;
- non-authoritative;
- incapable of requesting acceptance;
- incapable of choosing a new scope;
- incapable of admitting or renewing a lineage;
- sufficient to detect stale, foreign, or substituted scope expectations.

Delete as mandatory architecture:

- mutable-latch selector;
- expected mutable `available` revision;
- available-preimage digest as a latch-state requirement;
- preassigned consumed-latch postimage identity;
- unused mutable-latch selector semantics on nonaccept branches.

Retain deterministic preassigned family-route identities where needed for
collision detection and recovery.

Do not let the caller author the completed acceptance fact or its commit
timestamp.

## 7. Digest and identity DAG

Freeze an acyclic semantic dependency order.

At minimum:

1. standing-policy admission act;
2. immutable scope-admission fact;
3. command-local admitted-lineage expectation and command digest;
4. decision and resulting program-version/head identities;
5. immutable bootstrap-acceptance fact;
6. result;
7. receipt;
8. replay projection and recovery classification.

The acceptance fact may reference the decision and committed head/version.

Result and receipt may reference the acceptance-fact identity and digest.

The acceptance fact must not require final result or receipt digests if that
would create a cycle.

No timestamp or postcommit fact may be required to construct the precommit
command digest.

## 8. Closed branch effects

Freeze exact behavior for all five branches.

### Acceptance

- exact guard eligibility required;
- unique acceptance fact created;
- fact co-commits atomically with decision, version/head, result, and receipt;
- no second acceptance fact or second mutation on replay.

### Repair

- no acceptance fact;
- no claim that scope remains unclaimed unless guard status was independently
  and exactly read for another reason;
- no allowance creation or replenishment.

### Replan

Same guard behavior as repair.

### Terminal reject

- no acceptance fact;
- cannot mark the scope consumed;
- cannot reset or renew the scope.

### Program block

Same guard behavior as terminal reject.

No guard failure falls back to durable block. A guard conflict is no-write.

## 9. Closed outcome taxonomy

Replace latch-specific taxonomy with guard-specific semantics.

Freeze exact treatment for:

- missing admission fact;
- duplicate admission fact;
- malformed admission fact;
- foreign standing-policy admission;
- lineage identity mismatch;
- continuity not established;
- multiple active authorities or ambiguous active authority;
- wrong scope expectation;
- stale scope binding;
- unreadable admission or guard state;
- zero exact acceptance facts;
- one exact acceptance fact for the same command/family;
- one exact acceptance fact for a different command/family;
- duplicate acceptance facts;
- malformed or partial acceptance family;
- acceptance-fact identity collision;
- family-route collision;
- same `mutation_ref`, different command digest;
- exact same-command complete family;
- nonaccept branch;
- reset, delete, reopen, renew, or replenish attempt.

Use existing owners where applicable:

- `mutation_ref_reuse_conflict`;
- `preassigned_identity_or_family_route_collision`;
- ordinary command/basis/current-head rejection owners;
- recovery `committed_exact`;
- recovery `definitely_not_committed`;
- recovery `unresolved`.

Create one guard-specific no-write reason class, recommended:

`bootstrap_acceptance_guard_conflict`

If the current contract retains a compatibility reference to
`acceptance_latch_precondition_conflict`, classify it explicitly as superseded
target terminology rather than a second active reason owner.

No overlapping rejection owner is allowed.

## 10. Replay and one whole-family recovery classifier

Preserve receipt-first replay.

### Exact replay

For the exact same `mutation_ref` and canonical command digest:

- return the original complete family;
- include the original bootstrap-acceptance fact for acceptance;
- do not reevaluate the reducer;
- do not recheck mutable current heads as historical truth;
- do not create another fact;
- do not create another timestamp;
- do not perform another guard mutation.

### Different command under same mutation

Return `mutation_ref_reuse_conflict`.

### Whole-family recovery

There is one classifier for decision, version/head, result, receipt, and, for
acceptance, the bootstrap-acceptance fact.

- `committed_exact`: every expected immutable member is present and exact;
- `definitely_not_committed`: the original command’s complete newly created
  family is exhaustively absent with no fragment, alias, or collision;
- `unresolved`: neither proposition is provable.

A competing complete acceptance by another command may prove that the original
command is `definitely_not_committed`, but separately makes fresh retry
ineligible because the scope is already claimed.

Decision-without-acceptance-fact and acceptance-fact-without-decision are
`unresolved`.

Recovery never completes fragments, creates the fact, reevaluates the branch,
changes the scope, renews the allowance, or retries automatically.

## 11. Terminal boundary

A later terminal fact may bind:

- the immutable bootstrap-acceptance fact identity/digest;
- the exact committed decision/result/receipt family.

It cannot:

- create the admission fact;
- create the acceptance fact;
- consume, reset, update, delete, renew, or repair guard truth.

Acceptance committed with no terminal fact means terminal recording is absent,
not that acceptance is uncommitted.

Unresolved acceptance family forbids terminal inference.

Terminal uncertainty leaves the acceptance fact permanent.

Do not design terminal storage or its writer.

## 12. Later ES-routed operation

Freeze that the bootstrap guard applies only to the explicitly admitted bounded
direct-local bootstrap route.

Later ES-routed progression:

- is separately governed;
- does not consume this proof allowance;
- does not replenish it;
- does not reset it;
- does not treat the bootstrap acceptance fact as general ES admission or
  runtime authority.

No new direct-local productive allowance follows from ES readiness or route
transition.

## 13. Physical-persistence handoff

Do not select physical representation.

Freeze only these constraints:

- migration-0002 decisions, versions, heads, and receipts remain canonical;
- the scope-admission and acceptance facts must not create parallel progression
  truth;
- the physical family must enforce one exact acceptance fact per admitted
  lineage scope;
- restore/clone/replacement handling must preserve or positively re-establish
  lineage continuity and prior acceptance status;
- local absence cannot imply unclaimed state;
- active-active copies of one lineage are unsupported and must fail closed;
- the existing transaction controller and `WriterSession` may remain sole
  mutation authority in principle;
- migration-free reuse, additive migration `0005`, and bounded hybrid remain
  future engineering options;
- exact rows, indexes, readers, locators, collisions, transaction ordering,
  replay queries, and recovery queries remain future engineering work.

Do not choose a table, column, index, trigger, migration checksum, source symbol,
or application-generation change.

## 14. Security and non-authority

Freeze fail-closed treatment of:

- caller- or model-authored scope admission;
- caller- or model-authored acceptance facts;
- scope selection hidden in command data;
- stale or foreign admission;
- cross-lineage substitution;
- cross-program/candidate substitution;
- clone/restore ambiguity;
- multiple active authorities;
- unreadable or ambiguous absence;
- replay under another digest;
- digest cycles;
- terminal mutation;
- public/API widening;
- external evidence masquerading as guard authority.

The guard grants no:

- standing authority;
- execution permission;
- global-stop override;
- ES admission or runtime authority;
- Git or publication authority;
- model authority;
- caller branch authority.

## 15. Existing semantic-owner amendment

Amend the merged RW0-C2 owner so it:

- preserves the five-branch reducer unchanged;
- replaces every normative standalone-latch requirement with the guard owner;
- validates admitted lineage for every applicable direct-local command;
- evaluates scope-unclaimed eligibility only for derived acceptance;
- creates one immutable acceptance-family member on acceptance;
- creates no guard member on nonaccept branches;
- keeps model consistency last;
- keeps guard conflict as no-write, never block;
- binds replay and recovery to one complete family;
- binds later terminal outcome to the immutable acceptance fact;
- explicitly states no current source, migration, writer, reader, public, or
  runtime implementation.

The existing owner must not duplicate the guard’s complete scope/admission
tables. It should route guard semantics to the new owner.

## 16. New guard-owner document representation

The new document is the sole owner of bootstrap admission and acceptance-guard
semantics.

Use:

- concise normative prose;
- closed human-readable tables;
- one compact duplicate-key-free canonical JSON block for finite contract-test
  inventories only.

At minimum encode closed tables for:

- authority roles;
- scope and lineage rules;
- admission fact roles;
- acceptance fact roles;
- command-facing relation roles;
- branch effects;
- outcome taxonomy;
- replay and recovery;
- terminal boundary;
- nonclaims.

Human tables and machine data must be exact equivalent representations.

Do not encode SQL or full future value schemas.

Do not create unused decorative machine fields.

## 17. Cross-reference updates

### `.docs/architecture.md`

Route:

- five-branch semantics to the amended RW0-C2 owner;
- bootstrap lineage/admission/acceptance semantics to the new guard owner.

State that no physical storage, migration, writer, reader, public export, or
runtime path exists.

### `.docs/autonomous-software-development-operating-model.md`

Record:

- Option A as accepted product policy;
- one explicitly admitted Coordinator authority lineage per scope;
- operational realizations do not create scope;
- one active authority per lineage;
- permanent one-shot direct-local acceptance;
- later ES operation is separate and non-replenishing;
- standalone mutable latch architecture is superseded;
- physical representation and exact safe values remain blocked future work.

### `.docs/c2b-durable-development-state.md`

Append one successor section after current EOF.

It must:

- preserve every prior byte;
- classify historical Section 19 as proof precursor;
- retain the one-shot ceiling;
- supersede the mutable latch representation;
- adopt immutable scope admission plus acceptance fact;
- record the accepted lineage policy;
- state that historical latch tests preserve history, not current physical
  authority;
- preserve migrations 0001–0004 and all implementation nonclaims.

### `.docs/rw0-remote-worker-contact-phase-entry.md`

Update the current tranche map and target boundary:

- durable-decision reducer remains accepted target;
- standalone latch is superseded;
- bootstrap guard semantic amendment is accepted target after this tranche;
- source, physical storage, writer, terminal owner, RW0-D/E, and runtime remain
  future.

## 18. Existing causal-verifier amendment

Amend:

`tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`

Preserve all accepted reducer coverage.

Remove causal assumptions that require:

- mutable available/consumed latch state;
- preassigned consumed-latch postimage;
- separate latch replay/recovery truth.

Add causal checks proving:

- admitted-lineage relation is required for every applicable command;
- scope-unclaimed evaluation occurs only for acceptance;
- guard conflict is no-write, never block;
- acceptance retains one acceptance-fact member;
- nonaccept branches retain none;
- model recommendation remains non-authoritative;
- exact replay returns the same acceptance fact without another action;
- whole-family recovery includes the acceptance fact;
- terminal binds the fact without mutation;
- the new guard owner is the sole source for guard tables.

No source implementation is permitted.

## 19. New guard contract verifier

Create:

`tests/test_rw0_c2_bootstrap_acceptance_guard_contract.py`

Keep it finite, document-driven, and independent of production implementation.

It must causally check:

1. sole owner path and authority split;
2. exact Option A policy;
3. scope is authority lineage, not deployment/machine/database/program/grant;
4. explicit standing-policy admission;
5. one active authority per lineage;
6. restore/rollback/clone/backup/relocation non-replenishment;
7. continuity uncertainty fail-closed;
8. local row absence is insufficient;
9. immutable admission fact inventory;
10. immutable acceptance fact inventory;
11. one acceptance across two unrelated programs in one scope;
12. independent admitted lineages may each have one scope;
13. no implicit independence from separate databases or machines;
14. all five branch effects;
15. acceptance fact integrated into the decision family;
16. no separate latch state, revision, postimage, replay, or classifier;
17. command-facing relation and prohibited fields;
18. acyclic identity/digest graph;
19. closed outcome taxonomy;
20. receipt-first exact replay;
21. same-mutation/different-digest conflict;
22. competing winner and retry-ineligibility distinction;
23. whole-family `committed_exact`, `definitely_not_committed`, `unresolved`;
24. partial decision/fact families unresolved;
25. terminal binding and nonmutation;
26. later ES operation is non-replenishing and separately governed;
27. physical representation non-selection;
28. absence of source, migration `0005`, writer, reader, caller, public export,
    runtime, RW0-D/E, and ES modification;
29. cross-document human/machine equivalence;
30. no competing semantic owner.

Required hostiles include:

- second acceptance from another program in the same scope;
- scope inferred from another database or machine;
- independent scope without standing-policy admission;
- cloned database treated as fresh;
- acceptance-row absence treated as eligibility without continuity proof;
- two active authorities for one lineage;
- lineage substitution;
- standing-policy admission substitution;
- caller-authored acceptance fact;
- model-authored scope;
- mutable available/consumed latch reintroduced;
- preassigned consumed-latch postimage reintroduced;
- reset, renewal, deletion, or second allowance;
- nonaccept branch creating a fact;
- guard conflict converted to durable block;
- replay creating a second fact or timestamp;
- partial family classified committed;
- competing winner treated as retry permission;
- terminal resetting or creating the fact;
- ES route replenishing the allowance;
- digest cycle;
- duplicate JSON key;
- prose-only or machine-only drift;
- implementation or migration claim.

Each hostile must fail at an exact intended boundary.

Do not build a shadow durable writer or physical storage model in tests.

## 20. Validation

Run serially with:

```text
PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=.:src
-p no:cacheprovider
--basetemp=<external path>
```

At minimum run:

1. amended RW0-C2 semantic-contract verifier;
2. new bootstrap acceptance-guard verifier;
3. architecture, operating-model, and progression-boundary tests;
4. C2B durable-state contract tests;
5. remote-phase contract tests;
6. migration catalog and 0002/0003/0004 tests;
7. runtime-nonauthority and C2A nonimplementation tests;
8. full repository suite;
9. `git diff --check`;
10. new-file whitespace checks;
11. CR, trailing-whitespace, and final-newline checks;
12. exact protected-file and source/migration preservation;
13. artifact/cache scan.

Use a clean local-only external clone for the full suite if the live ignored
cache would interfere.

Do not move, rewrite, import through, or delete the live ignored cache.

No product or operator database may be opened.

## 21. Closeout provenance

Return inline:

- visible model name;
- visible reasoning setting;
- opening and closing Git coordinates;
- exact eight-path status;
- mode, bytes, and SHA-256 for every changed/new path;
- proof C2B changed append-only;
- proof protected files remain exact;
- proof all source, migrations, schemas, other tests, and other docs remain
  unchanged;
- deterministic full binary patch bytes and SHA-256;
- two independent complete receipt calculations;
- exact validation commands and results;
- failed or skipped validation;
- artifact/cache posture;
- semantic decisions adopted;
- historical latch clauses superseded;
- remaining physical/value seams;
- any authority or security widening;
- all required non-actions.

Do not stage, commit, push, create or modify a PR, or merge.

## Success token

`RW0_C_BOOTSTRAP_ACCEPTANCE_GUARD_SEMANTIC_AMENDMENT_WRITTEN_VALIDATED_READY_FOR_INDEPENDENT_AUDIT`

## Blocking token

`RW0_C_BOOTSTRAP_ACCEPTANCE_GUARD_SEMANTIC_AMENDMENT_BLOCKED`

Use the blocking token if:

- the baseline differs;
- the eight-path ceiling is insufficient because of a direct governing
  contradiction;
- the two-owner split cannot remain non-overlapping;
- the guard cannot share one family classifier without selecting physical
  implementation;
- source, migration, writer, or runtime work would be required.

Do not leave partial candidate changes under a blocking outcome; restore the
exact opening worktree before returning.

## Required non-actions

State:

```text
AGENTS_NOT_MODIFIED
README_NOT_MODIFIED
AUTHORITY_BOUNDARIES_NOT_MODIFIED
PROGRESSION_BOUNDARY_NOT_MODIFIED
RW0_C1_OWNER_NOT_MODIFIED
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
SCHEMAS_NOT_MODIFIED
OTHER_DOCS_NOT_MODIFIED
OTHER_TESTS_NOT_MODIFIED
OPERATOR_OR_PRODUCT_DATABASE_NOT_OPENED_OR_MUTATED
LIVE_IGNORED_CACHE_NOT_MOVED_OR_MODIFIED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
BOOTSTRAP_SCOPE_PROVISIONER_NOT_IMPLEMENTED
BOOTSTRAP_ACCEPTANCE_GUARD_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
REMOTE_CONTACT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
MERGE_NOT_PERFORMED
SUBAGENTS_NOT_SPAWNED
EXTERNAL_ARTIFACTS_NOT_GENERATED
```
