# Governed Execution Coordinator — RW0-C2 Bootstrap Guard Governing Reset Commit and PR Publication Gate

## Role and authorized effects

Perform one parent-only commit and pull-request publication gate for the exact
independently accepted 28-path RW0-C2 bootstrap acceptance-guard governing-reset
candidate.

Use the highest available Codex reasoning setting. At the beginning of the
report, record exactly what the interface visibly shows for:

- model name;
- reasoning setting or effort.

Do not infer hidden configuration. Record `not visible` when necessary.

Do not spawn subagents.

This prompt authorizes only:

1. live local and remote read-only preflight;
2. exact staging of the 28 audited paths;
3. staged-byte validation in a private local-only external clone;
4. one local commit with the exact prescribed message;
5. one plain non-force push of that exact commit to the exact topic branch;
6. creation and verification of one non-draft pull request.

This prompt does **not** authorize:

- direct push to `trunk_dev`;
- rebase, cherry-pick, merge, or local squash;
- commit amendment;
- force push;
- auto-merge;
- PR merge;
- merge queue;
- branch deletion;
- tags, releases, or deployment;
- source, migration, schema, public, runtime, RW0-D/E, or Execution Substrate
  changes;
- repair or alteration of candidate bytes.

Return one substantive inline closeout report. Do not create or attach an
external report, receipt, manifest, package, or other client-visible artifact.

Temporary validation and API-request material may exist only outside the
repository and must be removed at closeout.

## Accepted independent-audit authority

The fresh independent audit returned:

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_ACCEPTED_READY_FOR_COMMIT_GATE`

Its accepted boundary is:

- no unresolved High- or Medium-severity candidate finding;
- exact 28 audited paths only;
- exact patch and receipt below;
- separate commit/publication gate authorized;
- no implementation or merge authority.

Treat the checked-out repository and Git objects as the source of current byte
truth. The embedded audit coordinates are the authorization boundary, not a
substitute for live reproduction.

## Repository and exact opening baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required opening baseline beneath the uncommitted candidate:

- checked-out branch: `trunk_dev`
- HEAD: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- HEAD tree: `42cc0757b3d9604dfe7fdbda158074b8b48dac7b`
- sole parent: `db16de711986ae40a2bb848ed00cdddd3145ee02`
- subject: `docs: freeze RW0-C durable decision branch contract`
- upstream: `origin/trunk_dev`
- divergence against the existing tracking ref: `0 ahead / 0 behind`
- exactly one worktree
- zero staged paths
- zero unmerged paths
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Do not alter the candidate while checking provenance.

Any local baseline, path-set, classification, type, mode, size, or SHA-256
mismatch requires:

`AUDIT_PROVENANCE_MISMATCH`

Stop before staging.

## Exact audited candidate

Require exactly 26 tracked modifications and two untracked files, with no other
tracked or untracked difference from HEAD.

All 28 files must be regular, non-symlink mode-`0644`, valid UTF-8, without BOM
or CR bytes, without trailing whitespace, and with exactly one final newline.

| # | Status | Path | Bytes | SHA-256 |
|---:|---|---|---:|---|
| 1 | `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 70,858 | `4fc2b7f9d5810105c28a7ce11abe85d08a48f915a87b088ae86e5520aa2142e2` |
| 2 | `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | 57,192 | `2c0c9565f7fb4ae79eca998080f3b70734f9a4fd1e555132daf9b94daab1dc97` |
| 3 | `M` | `.docs/c2a-first-slice-semantic-protocol-contract.md` | 103,413 | `a690441d046d147cf11a068e07a894858e3d32476e19fef84a9bb26e6e6f0d99` |
| 4 | `M` | `.docs/c2b-durable-development-state.md` | 1,889,329 | `6115a29d5bbfb8ffb17404e9acbefcb8edc958554683afa3538e9d959e184ef8` |
| 5 | `M` | `AGENTS.md` | 61,466 | `001595cdec75b176abbfb99b91b2b06c45f2f2ff1a28c704ded7054c27c7e74e` |
| 6 | `M` | `README.md` | 45,849 | `b66fb689d9f0849eee1d62f12dda93d83dcc9f4cce2fa008696878b44256ad1a` |
| 7 | `M` | `.docs/architecture.md` | 43,007 | `60a884471d655ee6eddad8c405aa218eab492e3c610b101c0736fc9f2546288f` |
| 8 | `M` | `.docs/autonomous-software-development-operating-model.md` | 37,829 | `115ed6c16141f821147f640131bed904526cee914dbec6951f3667b0da100f05` |
| 9 | `M` | `.docs/authority-boundaries.md` | 34,686 | `69d524c839a2195cf0b5840be424c021305825fd0db1d85c76ed28b99c1bf055` |
| 10 | `M` | `.docs/durable-state-model.md` | 40,564 | `e14a421698f0735fa098fe6ce1063b64d07e1c212fd6b60755e1068c9caf5955` |
| 11 | `M` | `.docs/worker-execution-boundary.md` | 30,920 | `6f7d2f7855fcbdecc757af4dde7a7bb091ab1e8c60057a2fefe407f74de4055f` |
| 12 | `M` | `.docs/software-development-progression-boundary.md` | 28,654 | `b8761655ee42512c0e77ab8c774c2b2d3d8f9ac36a9bd0c74872ad4bf2994419` |
| 13 | `M` | `.docs/c2b3-program-initialization.md` | 27,687 | `8e9c2c6f49551b28d95de28f6d7b071c89dd0ea155ce7d7a6e21e8d88e73d1f7` |
| 14 | `M` | `.docs/rw0-b2-wire-protocol.md` | 24,346 | `7f977a5a60fd66c69464190731e09611ca24854313e145b73cc73f564776477b` |
| 15 | `M` | `.docs/rw0-b2-capability.md` | 17,753 | `171341fc60cbe762403f1e64676ca35c9ea2f778a10d0fc66d668f1c84dc884c` |
| 16 | `M` | `.docs/rw0-b1-pure-phase-values.md` | 33,032 | `8bccdaa31fa66821b73c136936c12ef001157209c72b9991839905c1a8e0e053` |
| 17 | `M` | `tests/test_architecture_contracts.py` | 100,410 | `555ac490738d12075d3908ec2ddfd090fdbb32d8a6fd53d1b3136d24485e1169` |
| 18 | `M` | `tests/test_rw0_remote_contact_phase_entry_contract.py` | 173,524 | `42d6d265c0a9ba5047aa37ec3a4daae30847d486d39ead6374685b451a1d445c` |
| 19 | `M` | `tests/test_remote_worker_pre_execution_planning_contract.py` | 913,152 | `92b0f3917f0572492357447211a1f0f0cc7f8edb7e8b5f18233ed80397879b29` |
| 20 | `M` | `tests/test_software_development_progression_boundary.py` | 42,899 | `bd9b10f62e3bbfb3dc5fc845958fe0087363a0afa0b80649853faac85235c7a3` |
| 21 | `M` | `tests/test_autonomous_software_development_operating_model.py` | 72,904 | `e9a77edb1f99b181c612e52c4a7cfee814ac3f0df4d974e7c3a0756aec6da8df` |
| 22 | `M` | `tests/c2a_contract_support.py` | 154,372 | `58be92ddffae6f4b901ae3632521481ab8d9ce0e02a819ef9421408d08eedd85` |
| 23 | `M` | `tests/test_rw0_b1_boundaries.py` | 38,321 | `bd52384897f8f7a7129023c693ef67b1ff453a006723438dfa4f06df08e4121f` |
| 24 | `M` | `tests/test_rw0_b2_capability_boundaries.py` | 45,708 | `4e4824b5974778cbef147e7f5a5684de34e5006464156cbb7be2958c33ce1a84` |
| 25 | `M` | `tests/test_c2b0_durable_state_contract.py` | 884,862 | `45a539a810deb8884c3f0158887a0d4fd06778a59e833c6b9d89365990ed62fd` |
| 26 | `M` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | 249,444 | `480bd282646304c70116f69faecabc1fea94d83ef54ec77b780a869ace5431c4` |
| 27 | `??` | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 25,151 | `bf65ba7f04411bb6e6febec2285b33721eb2ff895e2c60aee97878b1fa7c9b46` |
| 28 | `??` | `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | 116,659 | `299b5ffdf3ed0f983068e0d42ee99474a600dce9201c38724ec9371d73ac01e3` |

Require:

- zero staged paths;
- zero unmerged paths;
- no deletion, rename, type change, executable-mode change, symlink, or
  additional untracked path;
- every tracked path outside this table byte-identical to HEAD.

## Exact patch and canonical receipt

Construct the complete candidate patch in the exact 28-path table order.

For each tracked path:

```text
git diff --binary --full-index --no-ext-diff --no-textconv HEAD -- <path>
```

For each new path:

```text
git diff --no-index --binary --full-index --no-ext-diff --no-textconv -- /dev/null <path>
```

Treat expected `git diff --no-index` status `1` as “differences found.”

Concatenate exact stdout bytes without separators.

Required patch:

- bytes: `336,588`
- SHA-256:
  `1f020195ad27f9b47ae4a9df3d8824669c0501f5e1f56022f3488ef19c001f35`

Reconstruct the accepted canonical receipt.

Root:

```text
{"baseline": object, "files": array}
```

`baseline` has exactly these nine string fields:

- `branch`
- `head`
- `tree`
- `parent`
- `subject`
- `upstream`
- `divergence`
- `staged`
- `unmerged`

Values:

- `branch`: `trunk_dev`
- `head`: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- `tree`: `42cc0757b3d9604dfe7fdbda158074b8b48dac7b`
- `parent`: `db16de711986ae40a2bb848ed00cdddd3145ee02`
- `subject`: `docs: freeze RW0-C durable decision branch contract`
- `upstream`: `origin/trunk_dev`
- `divergence`: literal string `0\t0`, containing one tab
- `staged`: empty string
- `unmerged`: empty string

`files` contains exactly the 28 table entries in order. Each object has exactly:

- `status`
- `path`
- `type`
- `mode`
- `bytes`
- `sha256`

Rules:

- object keys lexicographically sorted;
- arrays retain order;
- `status` is `M` or `??`;
- `type` is `regular`;
- `mode` is `0644`;
- `bytes` is a decimal integer;
- SHA-256 is lowercase hexadecimal;
- compact JSON with `,` and `:` separators;
- UTF-8, `ensure_ascii=false`, one final LF;
- slash characters unescaped.

Required receipt:

- bytes: `5,594`
- SHA-256:
  `f89483fdd31c633c4a631afee36a6727bf99c95e837e9265065a94d4687d4ffd`

Run both patch and receipt calculations twice.

## Historical-byte and cache gates

Require:

### C2B

The candidate must begin with the exact committed `HEAD` blob for
`.docs/c2b-durable-development-state.md`:

- prefix bytes: `1,887,232`
- prefix SHA-256:
  `77bf3d3c6ed710da669db7fa4353f46f3d1e9b4e09636918046d16d94ed962e5`

The append must be:

- bytes: `2,097`
- SHA-256:
  `f34b64471dca1276470bf92195f9b318193701f1af03baf1f911091a8ba80c5c`

### C2B3

Removing only the candidate’s 940-byte projection immediately before the full
`COORDINATOR_C2B3D_COMMITTED_CURRENT_STATUS_END` marker must reconstruct the
committed HEAD blob exactly.

### Live ignored cache

Before any staging or repository import, require exactly:

- members: `37`
- canonical bytes: `8,897`
- SHA-256:
  `3902e30eb9f5e229bb61b46d3b77a001f6b86371a717f9b3c324407d8818ebec`
- no `tests/__pycache__`

Canonical cache grammar:

- path-sorted JSON array;
- object keys exactly `path`, `type`, `mode`, `size`, `mtime_ns`, `sha256`;
- lexicographically sorted object keys;
- compact UTF-8 JSON;
- one final LF.

Do not import repository modules from the live checkout. All validation must
occur in the external clone.

## Gate A — live remote and publication-policy preflight

After exact local provenance passes, authenticated remote read-only inspection
is authorized.

Required topic branch:

`codex/rw0-c2-bootstrap-acceptance-guard-governing-reset-v1`

Required base branch:

`trunk_dev`

Before staging:

1. resolve the live remote repository identity;
2. verify remote `refs/heads/trunk_dev` equals
   `6f11d6b0b6f38995123434945d86db0b169bb8f8`;
3. verify the exact topic branch is absent;
4. verify there is no open or closed PR whose head is that exact topic branch;
5. inspect the active branch ruleset and repository merge settings;
6. require a pull request for `trunk_dev`;
7. record required approvals, review-thread policy, required checks, bypass
   actors, allowed merge methods, auto-merge setting, and branch-deletion
   setting;
8. verify the authenticated publication identity without exposing secrets.

If the remote base has drifted, the topic branch exists, a PR already exists, or
the publication policy cannot be determined safely, stop before staging:

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_COMMIT_PUBLICATION_BLOCKED`

Do not attempt a direct push to `trunk_dev`.

A read-only fetch updating only `origin/trunk_dev` is permitted after the live
remote OID is verified. It must not change the worktree, index, or candidate.

## Gate B — exact staging

Stage exactly the 28 audited paths, in table order or from a mechanically parsed
fixed path list.

After staging require:

- exactly 28 stage-0 entries;
- every entry mode `100644`;
- no conflict stages;
- no intent-to-add;
- no deletion, rename, symlink, submodule, or executable mode;
- staged path set exactly equals the audited set;
- every index blob’s bytes, byte count, and SHA-256 equal the accepted receipt;
- every index blob equals its working-tree file;
- no unstaged tracked difference;
- no remaining untracked candidate file;
- no additional staged, unstaged, untracked, or unmerged path;
- `git diff --cached --check` passes.

Construct and record the exact staged tree:

```sh
git write-tree
```

Do not edit any file after staging.

If staging or byte verification fails:

1. unstage only the 28 audited paths;
2. require the exact opening unstaged candidate to be restored;
3. stop with:

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_COMMIT_PUBLICATION_BLOCKED`

## Gate C — staged-byte validation

Create a private external validation root with mode `0700`.

Construct a local-only clone from the exact committed baseline:

- no network;
- no configured remote in the validation clone;
- exact HEAD
  `6f11d6b0b6f38995123434945d86db0b169bb8f8`;
- safe clone-time umask preserving regular mode `0644`.

Populate exactly the 28 candidate files from the live **index blobs**, not from
the working tree. Use `git cat-file blob :<path>` or an equivalent exact index
read.

Require before testing:

- all 28 clone files match the accepted size and SHA-256;
- all other clone files equal committed HEAD;
- clone status is exactly the 28 intended paths;
- no bytecode, pytest cache, database, journal, WAL/SHM, lock, build, archive,
  or generated report artifact exists.

Run all commands serially with:

```text
PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=.:src
python3 -m pytest -q -p no:cacheprovider --basetemp=<external>
```

### 1. Guard verifier

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

Required:

`289 passed`

### 2. C2 plus guard

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_rw0_c2_durable_progression_decision_semantic_contract.py \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

Required:

`1,623 passed`

### 3. Four focused modules

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_rw0_b2_capability_boundaries.py \
  tests/test_c2b0_durable_state_contract.py \
  tests/test_rw0_c2_durable_progression_decision_semantic_contract.py \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

Required:

`1,997 passed`

### 4. Exact 17-module command

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_architecture_contracts.py \
  tests/test_rw0_remote_contact_phase_entry_contract.py \
  tests/test_remote_worker_pre_execution_planning_contract.py \
  tests/test_software_development_progression_boundary.py \
  tests/test_autonomous_software_development_operating_model.py \
  tests/test_c2a_first_slice_semantic_protocol_contract.py \
  tests/test_c2a_nonimplementation.py \
  tests/test_rw0_b1_phase_values.py \
  tests/test_rw0_b1_vectors.py \
  tests/test_rw0_b1_relations.py \
  tests/test_rw0_b1_boundaries.py \
  tests/test_rw0_b2_wire_boundaries.py \
  tests/test_rw0_b2_capability_boundaries.py \
  tests/test_rw0_b2_wire_cancellation_control_boundaries.py \
  tests/test_c2b0_durable_state_contract.py \
  tests/test_rw0_c2_durable_progression_decision_semantic_contract.py \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

Required:

`3,606 passed`

### 5. Exact broader command

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external> \
  tests/test_c2a*.py \
  tests/test_worker_execution_semantic*.py \
  tests/test_rw0_b1*.py \
  tests/test_rw0_b2*.py \
  tests/test_rw0_c1*.py \
  tests/test_post_execution_pure_owner*.py \
  tests/test_c2b2*.py \
  tests/test_c2b3*.py \
  tests/test_section41*.py \
  tests/test_runtime_non_authority.py \
  tests/test_state_store_contract.py \
  tests/test_b2a_writer_session_contract.py \
  tests/test_sqlite*.py
```

Required:

`3,611 passed, 3 warnings`

### 6. Full repository

```sh
python3 -m pytest -q -p no:cacheprovider --basetemp=<external>
```

Required:

`7,817 passed, 3 warnings`

The only accepted warnings are the unchanged Python 3.13 multi-threaded
`fork()` deprecations from:

- `test_operation_guard_close_waits_and_retains_authority_until_exit`;
- `test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang`;
- `test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock`.

After validation require:

- all 28 clone candidate bytes still equal the index receipts;
- clone contains no bytecode, pytest cache, database, journal, WAL/SHM, lock,
  build, archive, or generated report artifact;
- live index, worktree, staged tree, and cache remain unchanged.

Do not run transformed mutants at the commit gate. The accepted independent
audit already owns mutant adequacy.

If any staged-byte validation fails:

1. do not edit the candidate;
2. remove the external validation root;
3. unstage the exact 28 paths;
4. require restoration of the exact opening candidate and cache;
5. stop with:

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_COMMIT_PUBLICATION_BLOCKED`

## Gate D — exact commit

Immediately before commit, re-verify:

- remote `trunk_dev` still equals
  `6f11d6b0b6f38995123434945d86db0b169bb8f8`;
- topic branch remains absent;
- no PR exists for the topic;
- staged tree is unchanged;
- index blobs and working-tree files remain exact;
- live cache remains the exact 37-member baseline;
- no unstaged/untracked/unmerged path exists.

Commit exactly once on the checked-out local `trunk_dev`.

Use the repository’s configured author identity. Do not override it.

Exact commit subject:

```text
docs: adopt RW0-C2 bootstrap acceptance guard
```

Exact commit body:

```text
Adopt the accepted target contract for one standing-policy-admitted
Coordinator authority lineage and its immutable bootstrap admission and
acceptance facts.

Replace the superseded mutable acceptance-latch target across governing
documents and causal contract tests while preserving the five RW0-C2 branches,
receipt-first exact replay, one whole-family recovery classifier, historical
C2B evidence, and the private B1 compatibility edge.

This change adds no scope provisioner, guard storage, durable decision writer,
migration, reader, public API, runtime behavior, RW0-D/E behavior, or
Execution Substrate behavior.

Audit:
RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_ACCEPTED_READY_FOR_COMMIT_GATE
```

The commit message must have one final LF.

Do not amend.

After commit require:

- one parent only:
  `6f11d6b0b6f38995123434945d86db0b169bb8f8`;
- committed tree equals the staged tree exactly;
- exactly 28 changed paths relative to the parent;
- all committed modes are `100644`;
- every committed blob OID equals its staged blob OID;
- every committed blob’s bytes, size, and SHA-256 equal the audited receipt;
- local working tree and index are clean;
- local `trunk_dev` is ahead `1`, behind `0` relative to unchanged
  `origin/trunk_dev`;
- live cache remains exact.

If the commit fails before a commit object is created, restore the exact opening
unstaged candidate if safely possible and return the blocked token.

If the commit object is created, do not reset, amend, rebase, or delete it.

## Gate E — exact topic-branch publication

Immediately before push, repeat a live read-only remote check:

- remote `trunk_dev` remains at the audited parent;
- topic branch remains absent;
- no PR exists for the topic;
- effective publication policy has not materially changed.

If the base drifted after commit, do not push. Preserve the exact local commit
and return:

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_COMMITTED_PUBLICATION_INCOMPLETE`

Push exactly once, plain and non-force:

```text
<new_commit_oid>:refs/heads/codex/rw0-c2-bootstrap-acceptance-guard-governing-reset-v1
```

Do not push local `trunk_dev`.

After push require the remote topic branch to equal the exact local commit.

Do not retry with another branch, force push, or alter the commit.

## Gate F — exact pull request

Create exactly one non-draft PR.

Required coordinates:

- repository: live `origin` repository;
- base: `trunk_dev`;
- head:
  `codex/rw0-c2-bootstrap-acceptance-guard-governing-reset-v1`;
- head OID: exact new local commit;
- auto-merge: disabled.

Exact PR title:

```text
docs: adopt RW0-C2 bootstrap acceptance guard
```

Exact PR body:

```markdown
## Summary

- replace the superseded mutable acceptance-latch target with one explicitly admitted Coordinator authority lineage and immutable bootstrap admission and acceptance facts
- preserve the five RW0-C2 decision branches, receipt-first exact replay, and one whole-family three-way recovery classifier
- preserve historical C2B evidence and retain the private B1 `latch_postimage_*` pair only as a bounded compatibility/nonproof edge
- keep later ES-routed operation separately governed and non-replenishing

## Validation

- bootstrap guard verifier: 289 passed
- RW0-C2 plus guard: 1,623 passed
- focused governing-reset modules: 1,997 passed
- exact 17-module group: 3,606 passed
- broader regression group: 3,611 passed with 3 expected warnings
- full repository: 7,817 passed with 3 expected warnings
- independent transformed-mutant audit: accepted

## Non-implementation

This change adds no scope provisioner, guard storage, durable decision writer,
migration `0005`, reader or recovery implementation, terminal persistence,
production caller, public API, runtime activation, RW0-D/E behavior, or
Execution Substrate behavior.

Audit:
`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_ACCEPTED_READY_FOR_COMMIT_GATE`
```

Do not add labels, assignees, review requests, milestones, projects, or
auto-merge.

After creation verify:

- PR state `OPEN`;
- draft `false`;
- merged `false`;
- exact base and head refs;
- exact head OID;
- exact title;
- exact body;
- exactly one source commit;
- exactly 28 changed files;
- no auto-merge request;
- mergeability and merge state, when available;
- checks, reviews, review threads, statuses, and workflow runs;
- effective branch rules and allowed merge methods.

Do not merge.

## Partial-effect handling

### No commit created

If blocked before the commit object exists:

- remove temporary data;
- restore the exact opening candidate/index posture;
- return:

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_COMMIT_PUBLICATION_BLOCKED`

### Commit created but publication incomplete

If the commit exists but push or PR publication/verification is incomplete:

- do not reset, amend, rebase, delete, or replace the commit;
- do not force push or use an alternate branch;
- preserve every successful remote effect;
- report the exact local and remote state;
- return:

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_COMMITTED_PUBLICATION_INCOMPLETE`

### PR created but verification incomplete

Treat this as publication incomplete. Preserve the PR and topic branch. Do not
close or delete them automatically.

## Cleanup and final posture

Remove all gate-created external clones, basetemps, request files, response
files, and logs.

Do not remove or alter the original 37 ignored cache members.

Final successful local posture:

- branch `trunk_dev`;
- HEAD is the new exact commit;
- clean index and working tree;
- upstream remains `origin/trunk_dev`;
- divergence `1 ahead / 0 behind`;
- one worktree;
- no active Git operation or lock;
- live cache exact.

Final successful remote posture:

- `trunk_dev` remains
  `6f11d6b0b6f38995123434945d86db0b169bb8f8`;
- topic branch equals the exact new commit;
- one open, non-draft, unmerged PR;
- no auto-merge.

## Success token

`RW0_C_BOOTSTRAP_GUARD_GOVERNING_RESET_COMMITTED_AND_PR_OPENED`

Success authorizes no merge. A separate merge gate is required.

## Inline closeout report

Return:

1. primary outcome token;
2. visible model/reasoning setting;
3. opening local and remote coordinates;
4. effective publication policy;
5. exact opening candidate and cache provenance;
6. staged path, mode, blob, size, and SHA-256 table;
7. staged tree;
8. staged-byte validation commands and results;
9. commit OID, tree, parent, subject, and body SHA-256;
10. committed blob equality;
11. topic-branch push result;
12. PR number, URL, exact coordinates, title/body verification, and live state;
13. final local and remote refs;
14. cleanup and cache equality;
15. every partial or diagnostic event;
16. all required non-actions.

## Required non-actions

State:

```text
CANDIDATE_BYTES_NOT_CHANGED
REPAIRS_NOT_PERFORMED
COMMIT_NOT_AMENDED
REBASE_NOT_PERFORMED
CHERRY_PICK_NOT_PERFORMED
LOCAL_SQUASH_NOT_PERFORMED
DIRECT_PUSH_TO_TRUNK_DEV_NOT_PERFORMED
FORCE_PUSH_NOT_PERFORMED
AUTO_MERGE_NOT_ENABLED
MERGE_NOT_PERFORMED
MERGE_QUEUE_NOT_USED
TOPIC_BRANCH_NOT_DELETED
TAG_NOT_CREATED
RELEASE_NOT_CREATED
DEPLOYMENT_NOT_PERFORMED
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
SCHEMAS_NOT_MODIFIED
NON_CANDIDATE_DOCS_NOT_MODIFIED
NON_CANDIDATE_TESTS_NOT_MODIFIED
OPERATOR_OR_PRODUCT_DATABASE_NOT_OPENED_OR_MUTATED
LIVE_IGNORED_CACHE_NOT_MOVED_OR_MODIFIED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
BOOTSTRAP_SCOPE_PROVISIONER_NOT_IMPLEMENTED
BOOTSTRAP_ACCEPTANCE_GUARD_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
SUBAGENTS_NOT_SPAWNED
EXTERNAL_ARTIFACTS_NOT_RETAINED_OR_DELIVERED
```
