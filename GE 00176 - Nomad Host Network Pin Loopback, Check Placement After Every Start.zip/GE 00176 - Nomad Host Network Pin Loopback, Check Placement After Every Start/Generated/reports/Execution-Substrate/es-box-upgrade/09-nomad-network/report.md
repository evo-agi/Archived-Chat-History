# Box Nomad host-network repair: report

Run on 2026-11-24, 22:15 to 22:18 UTC, through Remote Control on David's Mac (bundled box runs approved by David 04:23Z; box turn from the coordinator 22:03Z). Script `box-nomad-network-run.sh` (SHA-256 c34adfcd…0f85, 21461 bytes; the Mac's copy matched), brief `brief.txt`, local test `local-test/README.md`. Evidence: `box-run/1-before.txt`, `2-apply.txt`, `3-verify.txt`, verbatim; each file's SHA-256 matches the one the Mac printed. Marks: **Ran** (printed by the run), **Inference**.

## Result

The box is back to working and Nomad places jobs again (Ran). `apply` ran once and recorded `repaired`. Nomad was the only service restarted.

## Cause

Diagnosed by the PR 12 thread (`../../pr12-current-admission/box-live-run/partd/log-excerpt.md`) and confirmed here before the change (Ran, `1-before.txt`):
- the box's nomad.hcl, the Remote Alpha 0.7 config, pins `client { network_interface = "enp1s0" }`, and the lock run of 19:33Z kept that line;
- enp1s0 is down with no carrier and no address; the box runs on Wi-Fi, through wlp2s0, as it has since the 2026-11-10 move (Archived-Runbooks "Network Move"). David (2026-11-24 22:21Z, corrected 22:22Z): the cable just happens to be unplugged; it is not deliberate and may change. Setups must work on Wi-Fi or a cable and assume neither;
- after the lock run restarted Nomad, the node had only a bridge network. ES's job shapes, network mode none and bridge with no Nomad network block, need a host-mode network, so every plan failed with `ConstraintFiltered {"missing network": 1}`.

The lock run's restart exposed a link loss of unknown date. None of that run's post-restart checks (services, endpoints, Vault, anonymous 403, the ACL check) could see it.

## What changed on the box (Ran)

| Item | Before | After |
|---|---|---|
| `/etc/nomad.d/nomad.hcl` line 25 | `network_interface = "enp1s0"`, sha256 4b3be7d7…1886 | `network_interface = "lo"`, sha256 ea333055…5163, still root:root 0640 |
| Node networks | `[bridge]` | bridge, host `lo` 127.0.0.1/32, host `lo` ::1/128; `unique.network.ip-address` 127.0.0.1 |
| Plan, network_mode none, ES token, es-submit-v1 | failed, missing network | place 1, no failures |
| Plan, network_mode bridge, ES token, es-submit-v1 | failed, missing network | place 1, no failures |
| nomad.service | active since 14:33:40 EST | restarted once, active since 17:17:20 EST (22:17:20Z) |
| `/var/backups/es-nomad-network/` | absent | root 0700: `nomadnet.py`, and `20261124T221711Z/` with `nomad.hcl.before` (the old file, root:root 0640) and `candidate/nomad.hcl` |

The repair validated the edited copy with `nomad config validate` first. Validate printed two warnings, "mTLS is not configured" and "Bootstrap mode enabled"; both were already true of the config.

## Verification (Ran, `3-verify.txt`)

- All ten services active, Vault unsealed, ES and AGS 200 (Healthcheck steps 1, 2 and 4).
- Lock unchanged: anonymous `/v1/jobs` and `/v1/agent/self` 403, and `nomad_acl_setup.sh check` passes with the management token. Anonymous `/v1/status/leader` and `/v1/namespaces` answer 200, as before.
- Both plans placeable, as in the table.
- A bridge-mode job (alpine:3.20, `/bin/true`, default namespace, management token) was placed, ran and exited 0. It was purged, and a lookup afterwards returned 404. Nomad garbage-collected the allocation; Docker may still list the exited container 88afa186… (Inference: Nomad's GC removes it in time).

## Notes

1. **This run's wait works.** `wait_unit` now matches `<unit>.service`, and the apply phase waited about 15 s for the unit to finish.
2. **Left on the box:** `/var/backups/es-nomad-network/` (above); `/tmp/es-upgrade.yBrDew` from the upgrade run, root-only, until a reboot.
3. **Rollback** of this repair, if ever needed: put `nomad.hcl.before` back (root:root 0640) and restart Nomad. With enp1s0 still down, that brings back the "missing network" failure.
4. **Guard against a repeat:** the follow-up scripts PR adds a post-restart host-network and plan check (upgrade script and bring-up readiness) and pins `lo` in the supported Linux config.
