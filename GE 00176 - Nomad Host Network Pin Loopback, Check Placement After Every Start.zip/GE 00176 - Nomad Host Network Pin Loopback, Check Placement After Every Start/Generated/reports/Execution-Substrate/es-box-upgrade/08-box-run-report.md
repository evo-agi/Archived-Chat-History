# Box ES upgrade and Nomad lock: run report

Run on 2026-11-24, 19:32 to 19:35 UTC, through Remote Control on David's Mac
(bundled box runs approved by David 04:23Z; box turn from the coordinator
19:25Z). Script: ES PR #54, merged into `trunk_dev` as `16cbf73`. Orchestration:
`07-box-run/box-es-upgrade-run.sh` (SHA-256 a70eff5f…f0b5), brief
`07-box-run/brief.txt`. Evidence: `07-box-run/1-build.txt` (verbatim, SHA-256
matches the Mac's), `2-check-excerpt.txt`, `3-apply.txt` (verbatim, matches),
`3b-status-events.txt`, `4-verify.txt` (journals summarized). Marks: **Ran**
(printed by the run), **Inference**.

## Result

`apply` ran once and recorded `applied` with no rollback (Ran). The box is back
to working: all ten services active as at the baseline, Vault unsealed, ES and
AGS endpoints 200 (Healthcheck steps 1, 2 and 4), and Nomad now refuses
anonymous job and agent requests (403) while `nomad_acl_setup.sh check` passes.

## What changed on the box (Ran)

| What | Before | After |
|---|---|---|
| ES binary `/usr/local/lib/execution-substrate/bin/es` | build `74748063` | `16cbf739…`, go1.26.5, `vcs.modified=false`, sha256 88f5edf7…196d, root:root 0755 |
| `/usr/local/bin/es-runtime-support` | build `74748063` | `16cbf739…`, sha256 6326cf34…d903 |
| `/etc/execution-substrate/es.json` | sha256 2129c3d6…7d13 | + `nomad.token_file` `/etc/execution-substrate/nomad-acl/es-token`, + `execution.retained_result_auth` {remote-alpha, k1, es.key}; root:es 0640, 3563 bytes |
| `/etc/execution-substrate/retained-result-auth/es.key` | absent | 32 bytes, es:es 0400 (folder root:root 0755) |
| `/etc/execution-substrate/nomad-acl/` | absent | es-token es:es 0400; management-token root 0600; observer-token root 0400 |
| `/etc/nomad.d/nomad.hcl` | nomad:nomad 0644, sha256 5d5e106c…96b8 | root:root 0640, sha256 4b3be7d7…1886 (acl block, Docker driver allowlist, plugin block) |
| `/etc/nomad.d/nomad.env` | nomad:nomad 0644 | root:root 0640 |
| `/etc/nomad.d` | nomad:nomad 0755 | root:root 0755 |
| `/opt/nomad`, `/opt/nomad/data` | already root 0755 / 0700 | unchanged; 0 data entries changed owner |
| Nomad ACLs | off | bootstrapped; namespace `es-submit-v1`, policies, no anonymous policy |
| Services restarted | | `es` once (stop 19:33:32Z, start 19:33:40Z); `nomad` once |

Not touched: AGS, ARS, EGS (`feb899c9`), unit files, Vault, SPIRE, Docker, the
firewall. No reboot. Backup: `/var/backups/execution-substrate-es-upgrade/20261124T193332Z-16cbf739eea8`
(root 0700). The build folder `/tmp/es-upgrade.yBrDew` (root:root 0700, clone
and payload) stays for `rollback --backup-dir`; `/tmp` clears it at reboot.

Before the apply (Ran): box-checks row 6, `/tmp` root:root 1777; the Vault
ownership find lists only `vault.hcl` (root:vault 0640) and
`vault.hcl.package-default` (root:root 0600), as at the preflight.

## Notes

1. **Orchestration bug, mine, no effect on the box.** `wait_unit` in
   `box-es-upgrade-run.sh` passed the bare unit name to `systemctl list-units`,
   which matches only `<name>.service`, so the apply phase stopped waiting
   after 5 s. The Mac session noticed, ran the read-only `status` phase (which
   uses `es-upgrade-*` and matches) and only then `verify`. Fix for any later
   copy: pass `"$unit.service"`, or match with `es-upgrade-*`.
2. **summary.json's top-level fields are the pre-apply check report** (for
   example `retained_result_key: "would create"`, the old `nomad.hcl` and
   `es.json` hashes); `events`, `after` and `result` record what apply did.
   That is how the script builds it (Read). It is accurate but easy to misread;
   I propose no change, since the script refuses a second run on this host.
3. **Anonymous `/v1/status/leader` and `/v1/namespaces` still answer 200.**
   Nomad serves the leader endpoint without a token, and filters the namespace
   list to what the caller may see (Inference: an empty list for the
   anonymous token; the body was not printed). `nomad_acl_setup.sh check`
   confirms there is no anonymous policy.
4. **Nomad 2.1.1 is available** (the box runs 2.0.0). Out of scope.
5. **Operators now need a token for Nomad's API.** PR 12 Part A must send the
   management token through `NOMAD_TOKEN` set inside a root shell (02-plan.md
   section 6); read-only checks can use the root-only observer token.
