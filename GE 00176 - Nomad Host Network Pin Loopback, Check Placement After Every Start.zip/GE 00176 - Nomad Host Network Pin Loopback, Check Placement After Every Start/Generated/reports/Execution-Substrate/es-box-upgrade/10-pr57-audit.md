# Audit of ES PR #57 at ac36d49 (loopback pin and placement check)

Verdict: **ACCEPT**.

- **Wired-port pins.** The claim holds: no wired-port pin is left (Ran).
  - `enp1s0` appears only where the upgrade script looks for the box's old
    pin to replace it, in that script's test fixtures, and in the doc line
    that describes the replacement.
  - Every config the repo writes or ships pins `network_interface = "lo"`.
- **New root code.** It only reads (Read, Ran):
  - `placement` reads node state and asks Nomad for plans. A plan is a dry
    run and registers nothing.
  - It never uses the management token.
  - It reads ES's config with `O_NOFOLLOW`.
  - The tokens go through the audited token reader and the loopback
    listener guard.
- **The new health test fails on trunk_dev** `8129b82` (Ran).
- **The fresh-node check works on real Nomad.** After a restart, Nomad
  2.0.0 and 2.1.1 keep serving the old node for 20 to 24 s, and the check
  waits for the new one (Ran).
- **Round 1 findings are closed at `ac36d49`.** I found three Low findings
  at `ea6d277`, and the writer fixed all three (Ran, Read):
  - A22-1: two readiness tests failed (CI failed on them too);
  - A22-2: the docs left out the `ES_USER` and `OBSERVER_USER` that
    placement needs;
  - A22-3: the setup script's host-network check had no test.
- **The full suite at `ac36d49` fails only where base `8129b82` fails**
  (Ran).
  - Every failing test, subtests included, is the same as on base, apart
    from two `es/admission` tests that failed once in the parallel run.
  - Those two pass alone (3 of 3), and the whole `es/admission` package
    passes in its own run at the same head (I22-5).
- **CI run 45511632013 on `ac36d49` passed** at 00:21Z. That covers the
  build, vet, the tests and the listed-test steps (Ran, `ci/runs.txt`).
- **Red-team.** I agree with the writer and the coordinator: this needs
  no red-team. The section "Red-team view" gives the reasons.

Statements are marked **Ran**, **Read** or **Inference**. Evidence paths
are relative to `10-pr57-audit-evidence/`. Files under `ac36d49/` are from
the second head; the rest are from `ea6d277`.

```text
INDEPENDENT AUDIT REPORT
```

## Target

- Repository: evo-agi/Execution-Substrate, PR #57, branch
  `claude/es-box-upgrade` (reused after #54's squash merge), on trunk_dev
  `8129b82`.
- First head: `ea6d277d19a99055804df9d6933bdb69107c7424`, one commit on
  `8129b82`.
  - 19 paths: 5 docs, the example Nomad config, 5 scripts and 8 test
    files. No `.github` path.
  - Recipe v2 manifest_sha256
    `1ab28aed191aff83ffdd2eef1838461360a1edd1c7d8b3683e4ae3e5dc82dc29`.
- Final head: `ac36d49aee50399167d92a7da9b12c46741487ff`, one commit on
  `ea6d277` (the fixes for A22-1 to A22-3).
  - 20 paths: the 19 above and `supported_local_execution_roots_test.go`.
    Still no `.github` path.
  - Recipe v2 (source sha256 `c08597e2…a3ca`, verified) manifest_sha256
    `cd8a6f077258144bb54cfc165b04b2d321605d212eec118144cd2c3ed429c10c`.
  - textual_diff_sha256 `00a9ccf9…9249`.
- Scope: the coordinator's request of 23:04Z. The background is
  `08-box-run-report.md` and `09-nomad-network/report.md`.

## Provenance (Ran, `provenance/`)

- At each head, two opening runs on a local branch with the PR's name
  give identical output. At `ea6d277`, two closing runs after the tests
  match the opening ones. The closing runs at `ac36d49` are listed under
  "Effect status".
- Delta `ea6d277..ac36d49`: 6 files, +87/−6
  (`delta-ea6d277-ac36d49.diff`, sha256 `15f8091e…fbef3`).

## What the PR does (Read)

- **Pin loopback everywhere.**
  - `scripts/70_linux_setup.sh` and `.examples/config/nomad.hcl` write
    `client { network_interface = "lo" }`.
  - The upgrade script's lock now also swaps the box's
    `network_interface = "enp1s0"` for `"lo"`.
  - A static test requires exactly one `network_interface` setting, the
    loopback pin, in each config the repo writes.
- **Check placement after every Nomad start.** The new
  `nomad_acl_setup.sh placement` runs `nomad_acl.py placement`:
  - With the observer token, it waits for a node that is all of these:
    ready, eligible, carrying a healthy Docker driver and a host-mode
    network, and, with `--fresh-after`, registered since the start.
  - With ES's token, it plans both of ES's job shapes (Docker,
    `network_mode` `none` and `bridge`) in `es-submit-v1` and in the
    datacenter that ES's config names. Each plan must place exactly one
    allocation.
- **The upgrade script.**
  - `apply` notes the time before `systemctl start nomad`.
  - After `provision`, it runs `placement` with that time and 120 s to
    wait.
  - Any failure rolls back.
- **Bring-up readiness and setup qualify** now refuse a node with no
  host-mode network (`no-host-network`).

## Round 1 at ea6d277: findings (all closed at ac36d49)

### A22-1 (Low, Ran): two readiness tests failed at ea6d277

`TestSupportedLocalFullReadinessActualEntrypoints` and
`TestSupportedLocalFullReadinessStillChecksSubmitPrerequisites` failed at
`ea6d277` and passed on base (`tests/es-app-211.txt`,
`tests/three-on-base.txt`).

- Cause: their fake Nomad node had no `NodeResources.Networks`
  (`supported_local_execution_roots_test.go:91`), so the new readiness
  check refused it.
- CI run 45506675569 on `ea6d277` failed on exactly these two tests
  (`ci/runs.txt`).
- **Fixed at `ac36d49`:** the fixture node reports a host-mode `lo`
  network. Both tests pass on Nomad 2.0.0 and 2.1.1
  (`ac36d49/tests/es-app-200.txt`, `ac36d49/tests/es-app-211.txt`).

### A22-2 (Low, Ran): placement by hand needs ES_USER and OBSERVER_USER

On the box, provision ran with `ES_USER=es OBSERVER_USER=root`.

- A later `sudo nomad_acl_setup.sh placement` without those values
  refuses, because it expects a root-owned ES token. Its message names an
  owner and gives no hint about the cause (`probes/placement-es-user.txt`).
- The docs told operators to pass them only to `check` and `rotate`.
- **Fixed at `ac36d49`** (Read). The wrapper header,
  `remote_supported_host_alpha.md` step 4, the configuration.md "Placement
  check" entry and the setup script's next-steps echo now all say that
  `check`, `rotate` and `placement` need the users that provision used.
  - I checked the docs' reasons against the code (Read):
    - `check` and `placement` refuse a token file another user owns;
    - `rotate` writes the new files for the users named;
    - provision replaces a token whose file has the wrong owner.
  - The upgrade script passes both values itself, so its own run was never
    affected (Read).

### A22-3 (Low, Ran): the setup qualify check had no test

At `ea6d277`, mutant S1 survived. It drops the `no-host-network` reason
from the qualify program in `scripts/70_linux_setup.sh`.

- **Fixed at `ac36d49`.** `TestLinuxSetupQualifyRequiresAHostNetwork`
  extracts that program, and requires there to be exactly one. It runs the
  program against a fake node in three cases:

  | Fake node | Expected |
  | --- | --- |
  | `lo` host network | passes |
  | bridge network only | refused |
  | no networks | refused |

- S1 is now killed by both refusal cases (`ac36d49/mutants/mut22c.txt`).
- The test passes as `ci` and as root
  (`ac36d49/tests/wrapper-and-qualify-as-root.txt`).

## The questions asked

### No other wired-port pins (Ran, `ac36d49/wired-port-grep-ac36d49.txt`)

I searched the tree for `network_interface` and for interface names
(`enp*`, `eth*`, `eno*`, `ens*`, `wlp*`, `wlan*`). There were 50 hits:

- **`enp1s0`:**
  - `NOMAD_WIRED_PIN` in the upgrade script, which is the line it
    replaces;
  - the upgrade test fixtures for the box's old file and for a wrong pin;
  - the doc line that describes the swap.
- **`network_interface`:** `"lo"` in every config the repo writes or
  ships. The other hits are the static test, refusal messages and docs.
- **The firewall tests:** sample data (`wlp2s0` in fake `ss` and `ip`
  output) and their lab's container `eth0`. Neither configures Nomad.
- No script, config or example sets another interface.

### The new root code only reads (Read, Ran)

- **`placement`:**
  - It sends `GET /v1/nodes` and `GET /v1/node/<id>` with the observer
    token.
  - It sends `POST /v1/job/<id>/plan` with ES's token. A plan is a dry run:
    Nomad registers nothing.
  - It never reads or uses the management token. In the wrapper,
    `placement` runs with `exec`, before the step that creates the token
    folder.
- **Tokens:** both go through `read_token_file`, which checks:
  - the owner;
  - mode 0400 or 0600 and one link;
  - a safe parent folder;
  - that the token is a canonical UUID.

  They are sent in a header to a loopback address, with no proxy and no
  redirects. The `Nomad` class from #48 checks the listener's owner uid on
  every connection.
- **ES's config** (`es_config_datacenter`) is read with:
  - an absolute, clean path required;
  - `O_RDONLY|O_NOFOLLOW|O_CLOEXEC`;
  - a regular file of at most 1 MiB, required.

  Only `nomad.datacenter` is used, and it must match the datacenter
  pattern.
- **Mutants** on this code are all killed (`mutants/mut22.txt`;
  `mutants/mut22-as-root.txt` for W1 and W2):
  - P1–P9: placement ignoring each condition, following a link, skipping
    the path or datacenter checks, or planning with the observer token;
  - W1 and W2: the wrapper passing the management token as ES's, or
    dropping `NOMAD_STARTED_AT`.

    W1 and W2 need root, because the wrapper test skips as `ci`. As root,
    both are killed.
- **Upgrade script:**
  - Mutants U1–U4 are killed: placement not run, the wired pin kept, any
    pin accepted, no start time passed.
  - The box's own file and its locked form still pass the hash check:
    - `plan_nomad_hcl` on the box's original `nomad.hcl` (sha256
      `5d5e106c…96b8`) gives sha256 `ea333055…5163`.
    - That is exactly the file on the box since the 22:17Z hand repair.
    - On that file it returns `applied` and changes nothing
      (`ac36d49/box-locked-hcl-sha.txt`).
    - So a later upgrade run on the box sees its config as already
      locked (Ran).

### The new health test fails on trunk_dev (Ran, `tests/health-test-on-trunk-dev.txt`)

With trunk_dev's `bringup.sh` (sha256 `6692a60f…`) put into the PR tree,
`TestHealthCheckScriptRejectsNomadNodeWithoutHostNetwork` fails: the node
without a host network is accepted. The tree was clean afterwards. Mutant
B1, the same check removed in the PR, is killed by it.

### The fresh-node check on real Nomad (Ran, `probes/fresh-after.txt`)

I restarted a real one-host Nomad agent (server and client, not dev mode,
pinned to `lo`) and polled the node:

| Nomad | First answer after the restart | `StatusUpdatedAt` reaches the start time |
| --- | --- | --- |
| 2.1.1 | old node, `ready`, old `StatusUpdatedAt` | after 23.7 s |
| 2.0.0 | old node, `ready`, old `StatusUpdatedAt` | after 19.9 s |

So without `--fresh-after`, placement could pass on the node as it was
before the restart. The check is needed, and it works: P2 and U4 are
killed.

## Red-team view

I agree that this PR needs no red-team (Inference, from the reading
above):

- It adds no write primitive. The root path's new requests are reads and
  dry-run plans.
- It uses no new credential. It reuses the token reader and listener guard
  that #31 and #48 audited, and the red-team saw both.
- The upgrade script's change is a one-line string swap. It is bound to
  the box's file by the existing hash check, and a failed placement check
  rolls back.
- The readiness and qualify changes only add refusals.

## Observations (Info, no action required)

- **I22-1:** `es_config_datacenter` refuses a link only as the last path
  component and does not check the parent folders. Root chooses the path,
  and only the datacenter name is read, so this is fine for a read.
- **I22-2:** The box's health-check runbook (Archived-Runbooks) does not
  run `placement` after a reboot.
  - Bring-up readiness now refuses a node with no host network, which
    covers the main case.
  - Adding `placement` there would also cover a failed plan.
  - This is outside the PR.
- **I22-3:** Provision with the wrong `ES_USER` replaces ES's token with
  one ES cannot read (pre-existing, from #31). A22-2's docs now warn about
  it.
- **I22-4:** Some tests fail in my container on base as well, because of
  the environment:
  - `TestBringupScriptUpCheckDownFullProfile`: the image build has no DNS.
    The writer reports that it passes with an offline control-plane image.
  - `TestSubmitFlowMountsGovernedArtifactAndLifecycleWithInstalledSourceIdentity`.
  - Three `reliablesubmit` old-binary tests.
  - The `scripts` package's remote-alpha TLS-status and operator tests.
  - None of them stops CI's test step, which passed on `ac36d49`.
- **I22-5:** `TestRetainedResultReviewStartupPreservesSpaceBearingKeyAncestor`
  and `TestRetainedResultReviewFreshServiceReopensPersistedResultWithReloadedKey`
  failed once, in the full `./...` run at `ac36d49`.
  - The PR changes nothing under `es/`, apart from `es/app` tests (Read).
  - At the same head, both tests pass alone, 3 of 3, and the whole package
    passes in its own run (Ran).
  - So they are flaky under parallel load in this container (Inference).
  - CI's run is the gate.

## Validation (Ran, as `ci` unless noted)

| Run | `ea6d277` | `ac36d49` |
| --- | --- | --- |
| `go build ./...`, `go vet ./...`, `GOOS=darwin go vet ./...`, `gofmt -l` on the changed Go files | pass (`tests/build-vet.txt`) | pass (`ac36d49/tests/build-vet.txt`) |
| targeted es/app set, Nomad 2.1.1 | A22-1's two fail; bring-up full profile fails as on base (`tests/es-app-211.txt`) | all pass except the bring-up full profile, as on base; 37 passes (`ac36d49/tests/es-app-211.txt`) |
| targeted es/app set, Nomad 2.0.0 | the same (`tests/es-app-200.txt`) | all pass except the bring-up full profile, as on base; 37 passes (`ac36d49/tests/es-app-200.txt`) |
| `TestRemoteAlphaUpgradeES*` | pass (`tests/upgrade-tests.txt`) | unchanged code; in the full suite |
| root package, `./internal/testutil/`, `./es/admission/` | pass (`tests/guards-root.txt`) | pass, `es/admission` in 258 s (`ac36d49/tests/guards-root.txt`) |
| wrapper test (and qualify test) as root | pass (`tests/wrapper-test-as-root.txt`) | pass (`ac36d49/tests/wrapper-and-qualify-as-root.txt`) |
| full suite `go test ./...` | see A22-1 | the same failing tests and subtests as base `8129b82`, plus I22-5's two (`ac36d49/tests/full-suite-*.txt`, `ac36d49/tests/admission-two-rerun.txt`) |
| mutants | 15 of 18 killed as `ci`; W1 and W2 killed as root; S1 survived (`mutants/`) | S1, S2, B1 killed (`ac36d49/mutants/mut22c.txt`) |
| CI | run 45506675569 failed (A22-1) | run 45511632013 passed, 00:21Z (`ci/runs.txt`) |

- In my first 2.1.1 run at `ac36d49`, the container's Docker daemon had
  stopped. I restarted it and ran that set again; the first output is kept
  as `ac36d49/tests/es-app-211-dockerd-down.txt`.

## Sensitive material

- The tests use random or fixed fake tokens (for example, the new qualify
  test's UUID-shaped constant) and test fixtures.
- In my copy of the interface search, LAN addresses from the firewall test
  data are replaced by `<lan-addr>`.
- A scan of the evidence found three kinds of match, all fake or redacted. UUID-shaped strings appear only as the tests' fake token constants, in the diffs. The firewall test data's LAN addresses are replaced with `<lan-addr>`. A repo subtest name that holds a user and host is replaced with `<user>@<host>`. The scan found no e-mail address and no "SecretID".

## Effect status

- No commit, push, PR comment, review or merge.
- Nothing outside this container changed. I did not touch the box.
- Temporary changes, all undone:
  - mutants were applied in my mutant clone, and the tree was clean after
    each batch;
  - trunk_dev's `bringup.sh` was copied into my test clone for the health
    test, then restored;
  - the root copy is a local `git archive` with a local commit.
- At `ac36d49`, two closing recipe runs equal the opening runs. The local branch was deleted, and every clone's tree was clean afterwards.

## Final verdict

**ACCEPT**

For the merge gate:

- the PR head must equal `ac36d49`;
- CI run 45511632013 on it passed;
- no red-team is needed, in my view; the coordinator decides.

The Info items need no change to this PR. I22-2, adding `placement` to the box's health-check runbook, would be a separate Archived-Runbooks change.
