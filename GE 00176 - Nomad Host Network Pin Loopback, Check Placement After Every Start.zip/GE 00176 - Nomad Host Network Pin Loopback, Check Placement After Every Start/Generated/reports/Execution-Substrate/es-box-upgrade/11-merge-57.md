# ES PR #57 merge record

Merged 2026-11-25 ~00:24Z into trunk_dev by squash: fd0529a206cf079b979129b6f533ea73dae9be17.

Gate (checked just before the merge):
- head = ac36d49aee50399167d92a7da9b12c46741487ff, the audited head (10-pr57-audit.md, ACCEPT, sha256 3bb2a7be…eacb)
- base trunk_dev = 8129b82 and an ancestor of the head (up to date); mergeable_state clean
- CI "build, vet and test" run 45511632013 on ac36d49: success (00:21Z)
- no review threads; Codex review on ea6d277: no findings
- no red-team (coordinator 23:04Z, auditor agreed); scripts/tests/docs only, so no David review (merge policy)
- merge called with expectedHeadSha = ac36d49

After the merge: fd0529a's parent is 8129b82, and its tree 964e1050…acb equals ac36d49's tree.

No box run needed: the box's nomad.hcl (ea333055…5163) is byte for byte the script's locked output.
