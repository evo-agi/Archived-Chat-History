~~The box is back to working.~~ [Edit: not fully. Since this run restarted Nomad, it places no jobs, because of an old network setting; see my later message.] Its ES now runs `trunk_dev` 16cbf73, and Nomad is locked so only ES can submit. The script's `apply` ran once at 19:33Z and finished with "applied" and no rollback.

**What changed**
- The ES binaries were rebuilt on the box from 16cbf73, replacing the May build.
- `es.json` gained the Nomad token file and the retained-result key setting. The key is new, and only `es` can read it.
- Nomad now has ACLs, Docker is its only allowed driver, and its config is root-owned. ES uses its own token. The management and observer tokens can be read only by root.
- Nomad and ES restarted once each. AGS, ARS and EGS were not touched.

**How it was verified**
- All ten services are active and Vault is unsealed.
- ES and AGS answer 200.
- Requests to Nomad's jobs and agent with no token now get 403, and the ACL setup check passes.
- The installed binaries carry the 16cbf73 commit, with no local changes.

A backup and the build folder are kept on the box for rollback. The runbook History line is merged in Archived-Runbooks PR #6. I've told the PR 12 thread that Part B can now run. Part A now needs the management token, set inside a root shell.

The Nomad HTTPS part is still paused for quota.

STATUS: box returned and working; lock live; this thread's part 2b paused until you say.
