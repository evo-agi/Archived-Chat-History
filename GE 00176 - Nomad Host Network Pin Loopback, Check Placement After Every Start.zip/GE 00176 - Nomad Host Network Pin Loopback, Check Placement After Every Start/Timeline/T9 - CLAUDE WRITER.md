Correction: the box isn't fully working. Since my lock run restarted Nomad at 19:33Z, Nomad places no jobs. Its config still pins the Ethernet port, but the cable is unplugged and the box is on Wi-Fi. The PR 12 checks found this.

The fix is mine. I'll point Nomad at loopback, back up the file first, restart only Nomad, and check that jobs can be placed again. I've asked for a box turn, and the script is nearly ready.

STATUS: box Nomad can't place jobs; repair prepared, waiting for a box turn.
