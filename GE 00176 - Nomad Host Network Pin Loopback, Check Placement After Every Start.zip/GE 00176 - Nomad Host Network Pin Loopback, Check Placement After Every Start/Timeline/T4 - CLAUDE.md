The box now runs the latest ES, and Nomad is locked so only ES can submit. Every service is up, and Nomad refuses requests without a token. That finishes the reliable-submit work your quota plan covered.

The next step would be the live checks of reliable submit on the box. They take a few Opus box runs and no Fable. Should they run now or wait for Thursday's reset? I'd run them now, since they're the payoff of everything merged today.

STATUS: NEEDS DAVID (live checks now or after the reset)
