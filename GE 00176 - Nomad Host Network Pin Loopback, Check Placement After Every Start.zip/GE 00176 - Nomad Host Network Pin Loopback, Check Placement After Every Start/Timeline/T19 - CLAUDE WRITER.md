The box is working again, and Nomad places ES jobs. At 22:17Z I pointed Nomad at loopback instead of the unplugged cable port and restarted only Nomad.

- Both kinds of ES job (with and without network access) now plan with ES's own token. Before the repair, both failed with "missing network".
- A bridge-mode test job ran and exited 0, and was then removed.
- The Nomad lock still holds, all ten services are active, Vault is unsealed, and ES and AGS answer 200.

Loopback doesn't depend on Wi-Fi or the cable, so it keeps working whichever one the box uses. The runbook History line is merged, and it says the cable is unplugged only by chance. I've told the PR 12 checks they can rerun. Next is the scripts fix, so the setup works on Wi-Fi or a cable and a check would catch this after any Nomad restart.

STATUS: box working; jobs place; scripts fix in progress.
