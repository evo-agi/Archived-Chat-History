PR #57 is merged into trunk_dev as `fd0529a`. The box can no longer silently lose its Nomad host network after a restart.

Gate, checked just before the merge: the head was still the audited `ac36d49`, the branch was up to date with trunk_dev `8129b82`, and CI was green on that head. After the merge I checked that the merged tree is the same as the audited head's. The audit found three small issues (A22-1 to A22-3), which I fixed before it accepted:
- a readiness test fixture needed a host network;
- the docs now say `placement` needs the same `ES_USER` and `OBSERVER_USER` as provision;
- a new test covers the setup script's own readiness step.

The box needs no run, since it already has the loopback pin. I've added a #57 note to the part 2b resume notes: 2b's HTTPS change must also cover the new `placement` check.

STATUS: scripts PR done (fd0529a); part 2b (Nomad HTTPS) still paused per the quota plan.
