Got it. The repair already works on Wi-Fi, and the scripts fix will make the whole setup work on Wi-Fi or a cable, checking every script for any other wired-only assumption.

STATUS: WORKING (Nomad repair on the box, then the reliable-submit checks)
