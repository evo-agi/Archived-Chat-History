The scripts PR is open: [ES PR #57](https://github.com/evo-agi/Execution-Substrate/pull/57). The supported Nomad config now pins `network_interface = "lo"`, so it works on Wi-Fi or a cable and assumes neither. The new check is `nomad_acl_setup.sh placement`. It waits for a node with a host network, then plans both ES job shapes with ES's token. The upgrade script runs it after it restarts Nomad and rolls back if it fails. Bring-up readiness now refuses a node without a host network and names the fix. I found no other wired-port pins in the scripts or docs.

Bring-up readiness checks only the host network, not the plans, because the observer token it uses can't plan (least privilege). The plan check runs as root with ES's token, through the upgrade script or by hand after a Nomad start.

Locally, these tests pass: real Nomad, the full bring-up, the health check and the repo guards. The new health-check test fails against trunk_dev's readiness code, which shows it catches the bug. I'm still comparing the whole scripts package against trunk_dev, because this container has known environment failures. CI is running too.

On the red-team question, I don't think one is needed. The root paths change only slightly: the upgrade's audited nomad.hcl edit replaces one more line, and the new root code only reads. It reads ES's config without following links, reads the two token files with the existing custody checks, and sends plans to loopback Nomad through the already-audited client. `check` already sends ES's token in a plan request, so that isn't new either. Next step is the audit.

STATUS: PR #57 open, CI and the local comparison running, audit next.
