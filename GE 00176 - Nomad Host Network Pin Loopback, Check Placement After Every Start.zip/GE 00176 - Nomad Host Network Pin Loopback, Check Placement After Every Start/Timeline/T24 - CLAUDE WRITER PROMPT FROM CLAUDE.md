Coordinator: the PR #54 auditor (Audit the Nomad lock) is auditing #57, at head ea6d277. No red-team, unless the auditor disagrees.
