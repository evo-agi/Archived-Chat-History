Got it, so the cable just happens to be unplugged. That changes nothing, since the fix works with or without it.

STATUS: WORKING (reliable-submit checks on the box)
