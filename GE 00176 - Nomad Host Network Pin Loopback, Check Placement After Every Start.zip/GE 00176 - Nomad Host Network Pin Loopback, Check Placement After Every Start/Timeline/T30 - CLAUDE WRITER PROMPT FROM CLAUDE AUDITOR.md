Here is the response from CLAUDE AUDITOR:

Two more Low items from the PR #57 audit at ea6d277. Since you are still preparing the A22-1 commit, they could go into the same push. Otherwise the verdict stays BLOCK on them.

A22-2 (docs, Ran). On the box, `sudo scripts/nomad_acl_setup.sh placement` run by hand refuses unless the operator passes the values provision used: `ES_USER=es OBSERVER_USER=root`. Without them it stops with "ES token file ... must be ... owned by uid 0", which gives no hint about the cause. The upgrade script passes these values, so its own run is fine. Three places name the wrong or incomplete set:
- `.docs/system_overview/remote_supported_host_alpha.md:7362` tells the operator to pass the same `ES_USER` and `OBSERVER_USER` to a later `check` or `rotate`, and leaves out `placement`.
- The "Placement check" entry at `configuration.md:714` names only `ES_CONFIG`.
- The `scripts/70_linux_setup.sh:842` echo also names only `ES_CONFIG`.
Fix: name `placement` with `check` and `rotate`, and have the 842 echo say to reuse step 4's `ES_USER` and `OBSERVER_USER`. Making the owner refusal mention those variables would also help, but it is optional.

A22-3 (tests, Ran, mutant S1). If I remove the new `no-host-network` reason from the qualify Python in `scripts/70_linux_setup.sh` (around line 700), everything still passes. The bringup.sh counterpart is covered by `TestHealthCheckScriptRejectsNomadNodeWithoutHostNetwork`, but nothing covers the setup one. The SPIRE/Vault setup test that skips here would not catch it either, because a real node always has a host network. Fix: add a test that drives that qualify heredoc against a fake Nomad node with no host-mode network and expects the `no-host-network` refusal. Extracting the heredoc the way your health test drives bringup.sh would work.

Send me the new head when it is pushed, and I'll do the delta check, the full suite and CI.
