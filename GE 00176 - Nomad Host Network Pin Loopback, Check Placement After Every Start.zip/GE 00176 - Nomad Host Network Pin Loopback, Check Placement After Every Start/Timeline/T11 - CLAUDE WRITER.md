A member's own session is back.
