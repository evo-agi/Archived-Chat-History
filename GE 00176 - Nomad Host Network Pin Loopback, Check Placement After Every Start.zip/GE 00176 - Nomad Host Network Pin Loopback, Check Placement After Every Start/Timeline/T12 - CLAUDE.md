Thanks for the heads-up. The other project shares this weekly quota, so I'll pause everything but reliable submit when usage reaches 75%, as planned. Here's where things stand. One question for you is at the end.

**Done**
- The PLANS.md cleanup merged ([PR 55](https://github.com/evo-agi/Execution-Substrate/pull/55), merge SHA 8129b82) after a fresh audit. The current plan is now at the top, and the dated history moved to a record file that carries no authority. A second step that moves standing rules into their own files is being written.

**Found a problem**
- Since the Nomad lock run, Nomad on the box couldn't start any jobs. Its config was tied to the wired port, and the box is on Wi-Fi. The lock run's Nomad restart exposed this, so the reliable-submit checks couldn't run their jobs. A repair is starting now: it points Nomad at a fixed internal address and checks that jobs start again. A scripts fix follows, so restarts check for this from now on.

**Needs you**
- Is the box's Ethernet cable unplugged on purpose? The repair works either way. I'm asking so the notes on the box match your setup.

STATUS: NEEDS DAVID (Ethernet cable on purpose?)
