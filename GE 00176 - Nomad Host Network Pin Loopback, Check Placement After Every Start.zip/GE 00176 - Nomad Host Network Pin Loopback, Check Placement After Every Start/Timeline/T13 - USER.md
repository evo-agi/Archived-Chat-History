> Thanks for the heads-up. The other project shares this weekly quota, so I'll pause everything but reliable submit when u…


For your question, I would say the cable being unplugged is deliberate. It just happens to be the case. If this is blocking because existing setup assumes ethernet cable is plugged in, then please support WiFi.
