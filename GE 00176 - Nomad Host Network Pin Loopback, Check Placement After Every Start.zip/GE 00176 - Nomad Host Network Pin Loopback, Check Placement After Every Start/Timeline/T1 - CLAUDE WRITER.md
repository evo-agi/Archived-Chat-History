Handed the machine session instructions

ES upgrade and Nomad lock on David's Linux test box (ssh alias [test box name withheld]). David approved the bundled box runs on 2026-11-24 at 04:23 UTC, and the coordinator gave this thread the box turn. The change itself is made only by the merged, audited ES script (PR #54), which rolls itself back on any failure. Your job is to run the phases below in order and report their output.

Rules on the Mac:
- Create exactly one new folder: T=$(mktemp -d /Users/ds/Repositories/Playground/es-box-run.XXXXXX) and print it. Shell variables may not survive between your commands, so after printing T use its literal value wherever these steps say "$T".
- Keep /Users/ds/Repositories/Playground as your working directory for the whole run. Never cd into "$T" or below it; use full paths.
- No sudo on the Mac. No git commands, no installs, no downloads. Do not change, stage or delete anything in any existing folder. Do not change any macOS setting. Playground itself must still exist at the end.
- Give every ssh command in steps 3 to 6 a tool timeout of 10 minutes (600000 ms).

Rules on the box:
- Reach it only with: ssh -T -o BatchMode=yes -o ConnectTimeout=15 -o ServerAliveInterval=15 -o ServerAliveCountMax=4 [test box name withheld] ...
- Run nothing on the box except the phases of the script below, in the order given. Do not fix, edit, start, stop or restart anything there by hand.
- Never run the apply phase (step 5) more than once, even after a dropped connection.
- The script prints no secrets. Report its output as it is.

Step 0. Connectivity (Mac):
  route -n get [home network address withheld] | /usr/bin/grep -E 'interface|gateway'; ping -c 3 -t 5 [home network address withheld] | tail -2; nc -z -G 5 -w 5 [home network address withheld] 22; echo "nc22 EXIT=$?"; ssh -T -o BatchMode=yes -o ConnectTimeout=15 [test box name withheld] true; echo "ssh EXIT=$?"
  If ssh fails ("No route to host", a timeout, or exit 255), wait five minutes and run step 0 once more. If it still fails, stop and report both outputs.

Step 1. Create "$T" as above and print it.

Step 2. Write the script below, byte for byte, to "$T/box-es-upgrade-run.sh": everything between the BEGIN and END marker lines, not including the marker lines, ending with a single newline. Then print:
  shasum -a 256 "$T/box-es-upgrade-run.sh"; wc -c < "$T/box-es-upgrade-run.sh"
  Expected: a70eff5f67045cdb97021f9c86a50053adae8585cfa7b9ab78b069eeb974f0b5 and 8230 bytes. If either differs, do NOT run it: print the file with cat -n, remove "$T" (step 7) and stop.

Step 3. Build (unprivileged, a few minutes):
  ssh -T -o BatchMode=yes -o ConnectTimeout=15 -o ServerAliveInterval=15 -o ServerAliveCountMax=4 [test box name withheld] 'bash -s -- build' < "$T/box-es-upgrade-run.sh" > "$T/1-build.txt" 2>&1; echo "exit=$?"
  Print the whole of "$T/1-build.txt". Note the line "DIR=/tmp/es-upgrade.XXXXXX"; that literal path is <DIR> below.
  If the output does not contain "build exit=0" followed by "===== done =====" (for example exit=255 or a cut-off output), run step 0, wait five minutes, and run step 3 once more (it makes a new folder; use the new DIR). If it fails again, go to step 7 and report.

Step 4. Check (read-only apart from handing <DIR> to root):
  ssh ...same options... [test box name withheld] 'bash -s -- check <DIR>' < "$T/box-es-upgrade-run.sh" > "$T/2-check.txt" 2>&1; echo "exit=$?"
  Print the whole of "$T/2-check.txt".
  If the connection dropped (exit=255 or no "===== done ====="), run step 0, wait five minutes and run step 4 once more.
  If the output does not contain "check exit=0", do NOT run step 5 or 6: go to step 7 and report.

Step 5. Apply (changes the box; run it ONCE):
  ssh ...same options... [test box name withheld] 'bash -s -- apply <DIR>' < "$T/box-es-upgrade-run.sh" > "$T/3-apply.txt" 2>&1; echo "exit=$?"
  Print the whole of "$T/3-apply.txt". It starts the upgrade as a systemd unit on the box (line "UNIT=es-upgrade-..."), which keeps running even if this SSH session drops, then waits for it.
  - If the connection dropped, or the output says "still running after about" followed by a unit name (not "nothing"): do NOT run apply again. Run step 0 until ssh works, then:
      ssh ...same options... [test box name withheld] 'bash -s -- status' < "$T/box-es-upgrade-run.sh" > "$T/3b-status.txt" 2>&1; echo "exit=$?"
    and print it. Repeat that status call (new file name each time) until it says "still running after about ... s: nothing", at most four times.

Step 6. Verify (read-only), whatever step 5 printed:
  ssh ...same options... [test box name withheld] 'bash -s -- verify <DIR>' < "$T/box-es-upgrade-run.sh" > "$T/4-verify.txt" 2>&1; echo "exit=$?"
  Print the whole of "$T/4-verify.txt". If the connection dropped, run step 0 and run step 6 once more.

Step 7. rm -rf "$T" (only that folder). Then: ls -d "$T" 2>/dev/null || echo removed; ls -d /Users/ds/Repositories/Playground

Report, for every step, the command, its exit status, and its output file printed WHOLE and verbatim inside fenced code blocks. Do not summarize, shorten or redact the outputs.

-----BEGIN box-es-upgrade-run.sh-----
#!/usr/bin/env bash
# ES upgrade and Nomad lock on the Remote Alpha box (ES PR #54, merged into
# trunk_dev as 16cbf73; plan es-box-upgrade/02-plan.md section 5).
#
# Run from a Remote Control session on David's Mac, one phase per call:
#   ssh -T -o BatchMode=yes [test box name withheld] 'bash -s -- <phase> [arg]' < box-es-upgrade-run.sh
#
#   build           new folder /tmp/es-upgrade.XXXXXX, fresh clone at the
#                   commit, unprivileged build of the payload (prints DIR=)
#   check <dir>     hand the folder to root, box-checks row 6, the Vault
#                   ownership find, then the upgrade's read-only check
#   apply <dir>     the upgrade's apply under systemd-run, detached from this
#                   SSH session (prints UNIT=), then waits and prints the
#                   unit's journal and summary.json
#   status [unit]   after a dropped session: waits for the unit (or for every
#                   es-upgrade-* unit) and prints the same journal and summary
#   verify <dir>    healthcheck runbook steps 1, 2 and 4, the Nomad lock, the
#                   installed binaries, es.json's new keys, owners and modes
#
# Only apply changes the box, and only through the merged, audited script,
# which rolls itself back on any failure. Nothing here prints a token, a key
# or a secret value; UUIDs in journal output are redacted as well.

set -u
export LC_ALL=C
COMMIT=16cbf739eea8c6a673aef8048aefb69cebd5121b
REPO_URL=https://github.com/evo-agi/Execution-Substrate.git
SUDO="sudo -n"
S() { printf '\n===== %s =====\n' "$1"; }
redact() { sed -E 's/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/<uuid>/g; s/(hvs|s)\.[A-Za-z0-9]{20,}/<token>/g'; }
phase="${1:-}"
arg="${2:-}"

need_dir() {
  if [[ ! "$arg" =~ ^/tmp/es-upgrade\.[A-Za-z0-9]{6}$ ]]; then
    echo "refusing: '$arg' is not a /tmp/es-upgrade.XXXXXX folder"; exit 2
  fi
  $SUDO test -d "$arg" -a ! -L "$arg" || { echo "refusing: $arg is not a directory"; exit 2; }
  D="$arg"
}

wait_unit() {
  # $1 is a unit name or the pattern es-upgrade-*. Waits up to 8 minutes, so
  # that one call ends within a 10-minute tool timeout; call status again if
  # the unit is still running.
  local unit="$1" i running
  for i in $(seq 1 96); do
    running="$(systemctl list-units --all --plain --no-legend --state=active,activating,deactivating,reloading "$unit" 2>/dev/null)"
    [ -n "$running" ] || break
    sleep 5
  done
  echo "still running after about $((i * 5)) s: ${running:-nothing}"
  S "journal of $unit (last 3 hours)"
  $SUDO journalctl -u "$unit" --since -3h --no-pager -o short-iso 2>&1 | redact | tail -250
  S "summary.json of the newest backup"
  local latest
  latest="$($SUDO find /var/backups/execution-substrate-es-upgrade -mindepth 1 -maxdepth 1 -type d -printf '%T@ %p\n' 2>/dev/null | sort -n | tail -1 | cut -d' ' -f2-)"
  echo "backup: ${latest:-none}"
  [ -n "$latest" ] && $SUDO cat "$latest/summary.json" 2>&1 | redact
  [ -n "$latest" ] && $SUDO ls -la "$latest" 2>&1
}

case "$phase" in
build)
  S "host"
  hostname; date -u +%Y-%m-%dT%H:%M:%SZ; id -un
  umask 022; echo "umask $(umask)"
  $SUDO true && echo "sudo -n: ok"
  S "box-checks row 6: /tmp"
  stat -c '/tmp %U:%G %a' /tmp
  D="$(mktemp -d /tmp/es-upgrade.XXXXXX)" || { echo "mktemp failed"; exit 1; }
  echo "DIR=$D"
  S "fresh clone at $COMMIT"
  if ! git clone --quiet --no-checkout "$REPO_URL" "$D/repo" || ! git -C "$D/repo" checkout --quiet --detach "$COMMIT"; then
    echo "clone failed"; exit 1
  fi
  echo "HEAD $(git -C "$D/repo" rev-parse HEAD)"
  echo "changed or untracked files: $(git -C "$D/repo" status --porcelain | wc -l)"
  git -C "$D/repo" log -1 --format='%H %cI %s'
  S "build (unprivileged)"
  "$D/repo/scripts/remote_alpha_upgrade_es.sh" build --out "$D/payload" --commit "$COMMIT"
  echo "build exit=$?"
  ls -la "$D/payload" 2>&1
  ;;
check)
  need_dir
  S "hand the folder to root"
  $SUDO chown -R root:root "$D" && $SUDO chmod -R go-w "$D" && echo "chown and chmod done"
  $SUDO find "$D" "$D/payload" -maxdepth 1 -printf '%u:%g %m %p\n' 2>&1
  echo "entries not root:root, or writable by group or others: $($SUDO find "$D" \( ! -user root -o ! -group root -o -perm /022 \) ! -type l | wc -l)"
  S "box-checks row 6: /tmp"
  stat -c '/tmp %U:%G %a' /tmp
  S "Vault ownership: find /etc/vault.d /opt/vault ! -user vault"
  $SUDO find /etc/vault.d /opt/vault ! -user vault -ls 2>&1 | head -40
  echo "(end of list)"
  S "the upgrade's read-only check"
  $SUDO "$D/repo/scripts/remote_alpha_upgrade_es.sh" check --payload "$D/payload" --commit "$COMMIT"
  echo "check exit=$?"
  ;;
apply)
  need_dir
  UNIT="es-upgrade-$(date -u +%Y%m%dT%H%M%SZ)"
  echo "UNIT=$UNIT"
  if ! $SUDO systemd-run --unit "$UNIT" --collect -p Type=exec -p KillMode=mixed -p TimeoutStopSec=20min \
      --setenv=HOME=/root -- "$D/repo/scripts/remote_alpha_upgrade_es.sh" apply --payload "$D/payload" --commit "$COMMIT"; then
    echo "systemd-run failed; nothing was started"; exit 1
  fi
  wait_unit "$UNIT"
  ;;
status)
  if [ -z "$arg" ]; then
    wait_unit 'es-upgrade-*'
  elif [[ "$arg" =~ ^es-upgrade-[0-9]{8}T[0-9]{6}Z$ ]]; then
    wait_unit "$arg"
  else
    echo "refusing: '$arg' is not an es-upgrade unit name"; exit 2
  fi
  ;;
verify)
  need_dir
  S "healthcheck runbook step 1: services"
  systemctl is-active ars ags egs es vault spire-server spire-agent nomad docker es-host-firewall 2>&1 | paste -sd' ' -
  systemctl show es.service -p ActiveEnterTimestamp -p NRestarts -p User 2>&1 | paste -sd' ' -
  S "step 2: Vault"
  $SUDO curl --noproxy '*' -fsS -m 5 --cacert /opt/vault/tls/ca.pem https://172.17.0.1:8200/v1/sys/seal-status 2>&1 \
    | python3 -I -c 'import json, sys; d = json.load(sys.stdin); print({k: d.get(k) for k in ("initialized", "sealed", "t", "n")})' 2>&1
  S "step 4: ES and AGS"
  $SUDO bash -c '. /etc/execution-substrate/healthcheck.env
for u in https://[home network address withheld]:8445/health https://[home network address withheld]:8445/v1/executions:contract https://[home network address withheld]:8444/health; do
  curl --noproxy "*" -sS -m 10 -o /dev/null -w "%{http_code} $u\n" --cacert "$CA_CERT" --cert "$OPERATOR_CERT" --key "$OPERATOR_KEY" "$u"
done' 2>&1
  S "Nomad lock"
  for p in /v1/status/leader /v1/jobs /v1/namespaces /v1/agent/self; do
    printf 'anonymous GET %s -> %s\n' "$p" "$(curl --noproxy '*' -sS -m 5 -o /dev/null -w '%{http_code}' "http://127.0.0.1:4646$p" 2>&1)"
  done
  $SUDO env NOMAD_ACL_DIR=/etc/execution-substrate/nomad-acl ES_USER=es OBSERVER_USER=root NOMAD_USER=root \
    NOMAD_ADDR=http://127.0.0.1:4646 "$D/repo/scripts/nomad_acl_setup.sh" check 2>&1 | redact
  echo "nomad_acl_setup.sh check exit=${PIPESTATUS[0]}"
  $SUDO find /etc/execution-substrate/nomad-acl -maxdepth 1 -printf '%u:%g %m %p\n' 2>&1
  $SUDO find /etc/nomad.d /opt/nomad /opt/nomad/data -maxdepth 1 -printf '%u:%g %m %p\n' 2>&1
  echo "entries under /opt/nomad/data not root:root: $($SUDO find /opt/nomad/data \( ! -user root -o ! -group root \) | wc -l)"
  echo "nomad.hcl sha256 $($SUDO sha256sum /etc/nomad.d/nomad.hcl | cut -c1-64)"
  S "installed binaries"
  for b in /usr/local/lib/execution-substrate/bin/es /usr/local/bin/es-runtime-support; do
    echo "$b: $($SUDO stat -c '%U:%G %a %s bytes' "$b") sha256 $($SUDO sha256sum "$b" | cut -c1-64)"
    /usr/local/go/bin/go version -m "$b" 2>&1 | grep -E "^$b: |vcs\.(revision|modified)="
  done
  $SUDO cat "$D/payload/provenance.json" 2>&1
  S "es.json"
  $SUDO stat -c '%U:%G %a %s bytes' /etc/execution-substrate/es.json
  $SUDO python3 -I -c 'import json; d = json.load(open("/etc/execution-substrate/es.json")); print("nomad.token_file =", d["nomad"].get("token_file")); a = d["execution"].get("retained_result_auth") or {}; print("execution.retained_result_auth =", {k: a.get(k) for k in ("store_id", "key_id", "key_file")})' 2>&1
  $SUDO find /etc/execution-substrate/retained-result-auth -printf '%u:%g %m %s %p\n' 2>&1
  S "ES journal (last 15 lines)"
  $SUDO journalctl -u es.service --no-pager -n 15 -o short-iso 2>&1 | redact
  S "Nomad journal (last 10 lines)"
  $SUDO journalctl -u nomad.service --no-pager -n 10 -o short-iso 2>&1 | redact
  ;;
*)
  echo "usage: bash -s -- build | check <dir> | apply <dir> | status [unit] | verify <dir>"; exit 2
  ;;
esac
S "done"
-----END box-es-upgrade-run.sh-----
