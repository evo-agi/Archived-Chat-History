Handed the machine session instructions

Nomad host-network repair on David's Linux test box (ssh alias [test box name withheld]). David approved the bundled box runs on 2026-11-24 at 04:23 UTC, and the coordinator gave this thread the box turn for this repair. Since the earlier lock run restarted Nomad, Nomad places no jobs because its config pins an Ethernet link that is down. The script below repoints Nomad at loopback, restarting Nomad only, and restores the backup by itself on any failure. Your job is to run its phases in order and report their output.

Rules on the Mac:
- Create exactly one new folder: T=$(mktemp -d /Users/ds/Repositories/Playground/es-box-net.XXXXXX) and print it. Shell variables may not survive between your commands, so after printing T use its literal value wherever these steps say "$T".
- Keep /Users/ds/Repositories/Playground as your working directory for the whole run. Never cd into "$T" or below it; use full paths.
- No sudo on the Mac. No git commands, no installs, no downloads. Do not change, stage or delete anything in any existing folder. Do not change any macOS setting. Playground itself must still exist at the end.
- Give every ssh command in steps 3 to 5 a tool timeout of 10 minutes (600000 ms).

Rules on the box:
- Reach it only with: ssh -T -o BatchMode=yes -o ConnectTimeout=15 -o ServerAliveInterval=15 -o ServerAliveCountMax=4 [test box name withheld] ...
- Run nothing on the box except the phases of the script below, in the order given. Do not fix, edit, start, stop or restart anything there by hand.
- Never run the apply phase (step 4) more than once, even after a dropped connection.
- The script prints no secrets. Report its output as it is.

Step 0. Connectivity (Mac):
  route -n get [home network address withheld] | /usr/bin/grep -E 'interface|gateway'; ping -c 3 -t 5 [home network address withheld] | tail -2; nc -z -G 5 -w 5 [home network address withheld] 22; echo "nc22 EXIT=$?"; ssh -T -o BatchMode=yes -o ConnectTimeout=15 [test box name withheld] true; echo "ssh EXIT=$?"
  If ssh fails ("No route to host", a timeout, or exit 255), wait five minutes and run step 0 once more. If it still fails, stop and report both outputs.

Step 1. Create "$T" as above and print it.

Step 2. Write the script below, byte for byte, to "$T/box-nomad-network-run.sh": everything between the BEGIN and END marker lines, not including the marker lines, ending with a single newline. Then print:
  shasum -a 256 "$T/box-nomad-network-run.sh"; wc -c < "$T/box-nomad-network-run.sh"
  Expected: c34adfcd44627d999f30912b698c78730d398ad26635411a060c7ca5a6d70f85 and 21461 bytes. If either differs, do NOT run it: print the file with cat -n, remove "$T" (step 6) and stop.

Step 3. Before (read-only apart from installing the script's helper):
  ssh -T -o BatchMode=yes -o ConnectTimeout=15 -o ServerAliveInterval=15 -o ServerAliveCountMax=4 [test box name withheld] 'bash -s -- before' < "$T/box-nomad-network-run.sh" > "$T/1-before.txt" 2>&1; echo "exit=$?"
  Print the whole of "$T/1-before.txt".
  If the connection dropped (exit=255 or no "===== done ====="), run step 0, wait five minutes and run step 3 once more.
  If the output does not contain a line "tool /var/backups/es-nomad-network/nomadnet.py sha256 f7c4a5d652899935c5e5e57b40a3d80066fb330ae157ba9c4d780e645c83f544", or the grep line under "Nomad config" is not exactly 'network_interface = "enp1s0"' (with its line number) and not 'network_interface = "lo"', do NOT run step 4: go to step 6 and report.

Step 4. Apply (changes the box; run it ONCE):
  ssh ...same options... [test box name withheld] 'bash -s -- apply' < "$T/box-nomad-network-run.sh" > "$T/2-apply.txt" 2>&1; echo "exit=$?"
  Print the whole of "$T/2-apply.txt". It starts the repair as a systemd unit on the box (line "UNIT=es-nomad-net-..."), which keeps running even if this SSH session drops, then waits for it (normally under a minute).
  - If the connection dropped, or the output says "still running after about" followed by a unit name (not "nothing"): do NOT run apply again. Run step 0 until ssh works, then:
      ssh ...same options... [test box name withheld] 'bash -s -- status' < "$T/box-nomad-network-run.sh" > "$T/2b-status.txt" 2>&1; echo "exit=$?"
    and print it. Repeat that status call (new file name each time) until it says "still running after about ... s: nothing", at most four times.

Step 5. Verify, whatever step 4 printed (read-only apart from one short probe job that it purges):
  ssh ...same options... [test box name withheld] 'bash -s -- verify' < "$T/box-nomad-network-run.sh" > "$T/3-verify.txt" 2>&1; echo "exit=$?"
  Print the whole of "$T/3-verify.txt". If the connection dropped, run step 0 and run step 5 once more.

Step 6. rm -rf "$T" (only that folder). Then: ls -d "$T" 2>/dev/null || echo removed; ls -d /Users/ds/Repositories/Playground

Report, for every step, the command, its exit status, and its output file printed WHOLE and verbatim inside fenced code blocks. Do not summarize, shorten or redact the outputs.

-----BEGIN box-nomad-network-run.sh-----
#!/usr/bin/env bash
# Nomad host-network repair on the Remote Alpha box (thread "Lock Nomad so
# only ES can submit"; report es-box-upgrade/09-nomad-network/).
#
# Since the lock run restarted Nomad (2026-11-24 19:33Z), Nomad places no job:
# nomad.hcl pins network_interface = "enp1s0", that link is down, so the node
# has no host-mode network and every placement fails "missing network". The
# repair pins "lo" instead (always up; Nomad already binds and advertises on
# 127.0.0.1; ES jobs ask for no ports).
#
# Run from a Remote Control session on David's Mac, one phase per call:
#   ssh -T -o BatchMode=yes [test box name withheld] 'bash -s -- <phase>' < box-nomad-network-run.sh
#
#   before   read-only apart from installing nomadnet.py (root-only, under
#            /var/backups/es-nomad-network): services, Nomad's unit and
#            config, links, the node's networks, plans of both ES job shapes
#            with ES's own token (a plan registers nothing)
#   apply    backs up nomad.hcl, then runs the repair under systemd-run,
#            detached from this SSH session (prints UNIT=), waits, prints its
#            journal. The repair validates the edited copy with `nomad config
#            validate`, writes it in place (root:root 0640), restarts Nomad
#            only, checks, and restores the backup on any failure.
#   status   after a dropped session: waits for es-nomad-net-* units and
#            prints their journal
#   verify   read-only apart from one probe job: healthcheck steps 1, 2 and 4,
#            the Nomad lock, nomad.hcl, the node's networks, both plans, and
#            one bridge-mode job that must run and exit 0 (default namespace,
#            management token, purged afterwards)
#
# Nothing here prints a token or a key; UUIDs in journal output are redacted.

set -u
export LC_ALL=C
SUDO="sudo -n"
TOOL_DIR=/var/backups/es-nomad-network
TOOL="$TOOL_DIR/nomadnet.py"
ACL_CHECK_REPO=/tmp/es-upgrade.yBrDew/repo
S() { printf '\n===== %s =====\n' "$1"; }
redact() { sed -E 's/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/<uuid>/g; s/(hvs|s)\.[A-Za-z0-9]{20,}/<token>/g'; }
phase="${1:-}"

install_tool() {
  $SUDO install -d -m 0700 -o root -g root "$TOOL_DIR" || { echo "cannot create $TOOL_DIR"; exit 1; }
  $SUDO tee "$TOOL.new" >/dev/null <<'PY'
"""Nomad host-network checks and repair for the Remote Alpha box.

  state             read-only: the node's networks and two plans with ES's token
  run-bridge        one bridge-mode job in the default namespace with the
                    management token; it must run and exit 0; then purged
  repair <workdir>  network_interface "enp1s0" -> "lo", restart Nomad, check,
                    restore <workdir>/nomad.hcl.before on any failure

Prints JSON lines. Never prints a token.
"""
import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import time
import urllib.error
import urllib.request

ADDR = "http://127.0.0.1:4646"
CONFIG_DIR = "/etc/nomad.d"
CONFIG_NAME = "nomad.hcl"
ACL_DIR = "/etc/execution-substrate/nomad-acl"
SYSTEMCTL = "/usr/bin/systemctl"
UNIT = "nomad.service"
ES_NAMESPACE = "es-submit-v1"
IMAGE = "alpine:3.20"
OLD_LINE = '  network_interface = "enp1s0"\n'
NEW_LINE = '  network_interface = "lo"\n'
TOKEN_RE = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\Z")
OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))
WAIT_SECONDS = 120


def out(**fields):
    print(json.dumps(fields), flush=True)


class Failure(Exception):
    pass


def read_token(name):
    fd = os.open(os.path.join(ACL_DIR, name), os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise Failure(name + " is not a regular file")
        data = os.read(fd, 4096)
    finally:
        os.close(fd)
    token = data.decode("ascii", "replace").strip()
    if not TOKEN_RE.match(token):
        raise Failure(name + " does not hold a Nomad token")
    return token


def request(method, path, token=None, body=None, timeout=10):
    data = None if body is None else json.dumps(body).encode()
    req = urllib.request.Request(ADDR + path, data=data, method=method)
    if token:
        req.add_header("X-Nomad-Token", token)
    if data is not None:
        req.add_header("Content-Type", "application/json")
    try:
        with OPENER.open(req, timeout=timeout) as resp:
            return resp.status, resp.read(1 << 22)
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read(4096)
    except (urllib.error.URLError, OSError) as exc:
        return 0, str(exc).encode()


def text(raw, limit=300):
    return raw[:limit].decode("utf-8", "replace")


def nodes(observer):
    status, raw = request("GET", "/v1/nodes", observer)
    if status != 200:
        return {"error": "GET /v1/nodes returned %d: %s" % (status, text(raw))}
    found = []
    for stub in json.loads(raw):
        status, raw = request("GET", "/v1/node/" + stub["ID"], observer)
        if status != 200:
            found.append({"id": stub["ID"][:8], "error": status})
            continue
        node = json.loads(raw)
        res = node.get("NodeResources") or {}
        found.append({
            "id": node["ID"][:8],
            "status": node.get("Status"),
            "eligibility": node.get("SchedulingEligibility"),
            "networks": [{k: n.get(k) for k in ("Mode", "Device", "IP", "CIDR")} for n in res.get("Networks") or []],
            "node_networks": [
                {"Mode": n.get("Mode"), "Device": n.get("Device"),
                 "Addresses": [a.get("Address") for a in n.get("Addresses") or []]}
                for n in res.get("NodeNetworks") or []
            ],
            "unique_network": {k: v for k, v in (node.get("Attributes") or {}).items() if k.startswith("unique.network.")},
        })
    return found


def host_network_ready(found):
    """The scheduler's network check reads NodeResources.Networks: a job with
    no network block needs a ready node with a host-mode entry there."""
    return isinstance(found, list) and any(
        n.get("status") == "ready" and n.get("eligibility") == "eligible"
        and any(net.get("Mode") == "host" for net in n.get("networks") or [])
        for n in found
    )


def probe_job(job_id, namespace, network_mode):
    return {
        "ID": job_id, "Name": job_id, "Type": "batch", "Namespace": namespace, "Datacenters": ["dc1"],
        "TaskGroups": [{
            "Name": "g", "Count": 1,
            "RestartPolicy": {"Attempts": 0, "Mode": "fail"},
            "ReschedulePolicy": {"Attempts": 0, "Unlimited": False},
            "Tasks": [{
                "Name": "t", "Driver": "docker",
                "Config": {"image": IMAGE, "command": "/bin/true", "network_mode": network_mode},
                "Resources": {"CPU": 100, "MemoryMB": 64},
            }],
        }],
    }


def plan(token, network_mode):
    """Plan an ES-shaped job (Docker, network_mode none or bridge, no Nomad
    network block, no ports) in ES's namespace with ES's own token. A plan
    registers nothing."""
    job_id = "es-net-probe-" + network_mode
    body = {"Job": probe_job(job_id, ES_NAMESPACE, network_mode), "Diff": False}
    status, raw = request("POST", "/v1/job/%s/plan?namespace=%s" % (job_id, ES_NAMESPACE), token, body)
    if status != 200:
        return {"network_mode": network_mode, "status": status, "error": text(raw), "feasible": False}
    result = json.loads(raw)
    failed = result.get("FailedTGAllocs") or {}
    place = (((result.get("Annotations") or {}).get("DesiredTGUpdates") or {}).get("g") or {}).get("Place")
    return {
        "network_mode": network_mode, "namespace": ES_NAMESPACE, "status": status, "place": place,
        "failed": {g: {k: (v or {}).get(k) for k in ("ConstraintFiltered", "NodesEvaluated", "NodesFiltered", "DimensionExhausted")}
                   for g, v in failed.items()},
        "feasible": not failed and place == 1,
    }


def state():
    observer = read_token("observer-token")
    es = read_token("es-token")
    found = nodes(observer)
    out(step="nodes", nodes=found, host_network_ready=host_network_ready(found))
    plans = [plan(es, mode) for mode in ("none", "bridge")]
    for p in plans:
        out(step="plan", **p)
    return host_network_ready(found) and all(p["feasible"] for p in plans)


def run_bridge():
    management = read_token("management-token")
    job_id, ns = "es-net-probe-run", "default"
    status, _ = request("GET", "/v1/job/%s?namespace=%s" % (job_id, ns), management)
    if status != 404:
        raise Failure("job %s already exists or Nomad answered %d; not touching it" % (job_id, status))
    ok = False
    try:
        status, raw = request("POST", "/v1/jobs?namespace=" + ns, management, {"Job": probe_job(job_id, ns, "bridge")})
        out(step="register", job=job_id, namespace=ns, status=status, error=None if status == 200 else text(raw))
        if status != 200:
            return False
        eval_id = json.loads(raw).get("EvalID", "")
        deadline = time.monotonic() + WAIT_SECONDS
        alloc = None
        while time.monotonic() < deadline:
            status, raw = request("GET", "/v1/job/%s/allocations?namespace=%s" % (job_id, ns), management)
            allocs = json.loads(raw) if status == 200 else []
            if allocs:
                alloc = allocs[0]
                if alloc.get("ClientStatus") in ("complete", "failed", "lost"):
                    break
            time.sleep(2)
        if alloc is None:
            status, raw = request("GET", "/v1/evaluation/%s?namespace=%s" % (eval_id, ns), management)
            ev = json.loads(raw) if status == 200 else {}
            out(step="allocation", placed=False, eval_status=ev.get("Status"),
                failed_tg_allocs={g: (v or {}).get("ConstraintFiltered") for g, v in (ev.get("FailedTGAllocs") or {}).items()})
            return False
        task = (alloc.get("TaskStates") or {}).get("t") or {}
        events = [{"type": e.get("Type"), "exit_code": e.get("ExitCode"), "message": e.get("DisplayMessage")}
                  for e in task.get("Events") or []]
        exit_codes = [e["exit_code"] for e in events if e["type"] == "Terminated"]
        ok = alloc.get("ClientStatus") == "complete" and task.get("Failed") is False and exit_codes == [0]
        out(step="allocation", placed=True, client_status=alloc.get("ClientStatus"), task_state=task.get("State"),
            task_failed=task.get("Failed"), events=events, ran_and_exited_0=ok)
        return ok
    finally:
        status, raw = request("DELETE", "/v1/job/%s?namespace=%s&purge=true" % (job_id, ns), management)
        left, _ = request("GET", "/v1/job/%s?namespace=%s" % (job_id, ns), management)
        out(step="purge", status=status, job_lookup_after=left)


def config_fd():
    return os.open(CONFIG_DIR, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)


def read_config():
    dir_fd = config_fd()
    try:
        fd = os.open(CONFIG_NAME, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=dir_fd)
        try:
            st = os.fstat(fd)
            if not stat.S_ISREG(st.st_mode) or (st.st_uid, st.st_gid) != (0, 0) or stat.S_IMODE(st.st_mode) != 0o640:
                raise Failure("nomad.hcl is not a root:root 0640 regular file")
            chunks = []
            while True:
                chunk = os.read(fd, 1 << 16)
                if not chunk:
                    break
                chunks.append(chunk)
            return b"".join(chunks)
        finally:
            os.close(fd)
    finally:
        os.close(dir_fd)


def write_config(data):
    tmp = ".nomad.hcl.repair-tmp"
    dir_fd = config_fd()
    try:
        try:
            os.unlink(tmp, dir_fd=dir_fd)
        except FileNotFoundError:
            pass
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600, dir_fd=dir_fd)
        try:
            os.fchown(fd, 0, 0)
            os.fchmod(fd, 0o640)
            view = memoryview(data)
            while view:
                view = view[os.write(fd, view):]
            os.fsync(fd)
        finally:
            os.close(fd)
        os.rename(tmp, CONFIG_NAME, src_dir_fd=dir_fd, dst_dir_fd=dir_fd)
        os.fsync(dir_fd)
    finally:
        os.close(dir_fd)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def restart_and_wait(observer, expect_ready):
    run = subprocess.run([SYSTEMCTL, "restart", UNIT], capture_output=True, text=True, timeout=180)
    out(step="restart", returncode=run.returncode, stderr=run.stderr.strip()[-300:])
    if run.returncode != 0:
        return False
    deadline = time.monotonic() + WAIT_SECONDS
    found, active, leader = None, "", ""
    while time.monotonic() < deadline:
        active = subprocess.run([SYSTEMCTL, "is-active", UNIT], capture_output=True, text=True, timeout=30).stdout.strip()
        status, raw = request("GET", "/v1/status/leader")
        leader = text(raw).strip() if status == 200 else ""
        if active == "active" and leader not in ("", '""'):
            found = nodes(observer)
            if not expect_ready or host_network_ready(found):
                break
        time.sleep(3)
    out(step="after restart", active=active, leader=leader, nodes=found, host_network_ready=host_network_ready(found))
    return active == "active" and leader not in ("", '""') and (not expect_ready or host_network_ready(found))


def repair(workdir):
    nomad = shutil.which("nomad") or ""
    backup_path = os.path.join(workdir, "nomad.hcl.before")
    with open(backup_path, "rb") as f:
        backup = f.read()
    current = read_config()
    out(step="config", sha256=sha(current), backup_sha256=sha(backup), nomad=nomad)
    if current != backup:
        raise Failure("nomad.hcl changed since the backup was taken; nothing changed")
    lines = current.decode("utf-8").splitlines(keepends=True)
    pins = [line for line in lines if "network_interface" in line]
    if pins == [NEW_LINE]:
        out(step="edit", result="already pinned to lo; nothing changed")
        return host_network_ready(nodes(read_token("observer-token")))
    if pins != [OLD_LINE]:
        raise Failure("expected exactly one line %r, found %r; nothing changed" % (OLD_LINE, pins))
    edited = current.decode("utf-8").replace(OLD_LINE, NEW_LINE, 1).encode("utf-8")
    candidate_dir = os.path.join(workdir, "candidate")
    os.mkdir(candidate_dir, 0o700)
    candidate = os.path.join(candidate_dir, CONFIG_NAME)
    with open(candidate, "xb") as f:
        f.write(edited)
    if not nomad:
        raise Failure("nomad binary not found; nothing changed")
    observer = read_token("observer-token")
    es = read_token("es-token")
    check = subprocess.run([nomad, "config", "validate", candidate], capture_output=True, text=True, timeout=60)
    out(step="validate", returncode=check.returncode, output=(check.stdout + check.stderr).strip()[-600:])
    if check.returncode != 0:
        raise Failure("nomad config validate refused the edited copy; nothing changed")
    # From here on nomad.hcl may differ from the backup: any failure or
    # exception restores the backup and restarts Nomad on it.
    ok = False
    try:
        write_config(edited)
        out(step="written", sha256=sha(read_config()), line=NEW_LINE.strip())
        ok = restart_and_wait(observer, expect_ready=True)
        if ok:
            plans = [plan(es, mode) for mode in ("none", "bridge")]
            for p in plans:
                out(step="plan", **p)
            ok = all(p["feasible"] for p in plans)
    except BaseException as exc:  # noqa: BLE001 - restore first, whatever happened
        out(step="error", error="%s: %s" % (type(exc).__name__, exc))
        ok = False
    if ok:
        out(result="repaired")
        return True
    out(step="restore", reason="a step or check after the edit failed")
    write_config(backup)
    out(step="restored", sha256=sha(read_config()), matches_backup=read_config() == backup)
    restart_and_wait(observer, expect_ready=False)
    out(result="restored the backup; Nomad still has no host network")
    return False


def main(argv):
    try:
        if argv[1:] == ["state"]:
            ok = state()
        elif argv[1:] == ["run-bridge"]:
            ok = run_bridge()
        elif len(argv) == 3 and argv[1] == "repair":
            ok = repair(argv[2])
        else:
            out(error="usage: state | run-bridge | repair <workdir>")
            return 2
    except (Failure, OSError, ValueError) as exc:
        out(result="refused", reason="%s: %s" % (type(exc).__name__, exc))
        return 1
    out(exit=0 if ok else 1)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
PY
  $SUDO chmod 0600 "$TOOL.new" && $SUDO mv -f "$TOOL.new" "$TOOL" || { echo "cannot install $TOOL"; exit 1; }
  echo "tool $TOOL sha256 $($SUDO sha256sum "$TOOL" | cut -c1-64)"
}

wait_unit() {
  # $1 is a unit name or a glob. Waits up to 8 minutes.
  local unit="$1" pattern i running
  case "$unit" in *'*'*) pattern="$unit" ;; *) pattern="$unit.service" ;; esac
  for i in $(seq 1 96); do
    running="$(systemctl list-units --all --plain --no-legend --state=active,activating,deactivating,reloading "$pattern" 2>/dev/null)"
    [ -n "$running" ] || break
    sleep 5
  done
  echo "still running after about $((i * 5)) s: ${running:-nothing}"
  S "journal of $pattern (last 3 hours)"
  $SUDO journalctl -u "$pattern" --since -3h --no-pager -o cat 2>&1 | redact | tail -120
}

health() {
  S "healthcheck runbook step 1: services"
  systemctl is-active ars ags egs es vault spire-server spire-agent nomad docker es-host-firewall 2>&1 | paste -sd' ' -
  systemctl show nomad.service -p ActiveEnterTimestamp -p NRestarts -p ExecStart 2>&1 | sed -E 's/ ; (pid|start_time|stop_time|status)=[^;]*//g'
  S "step 2: Vault"
  $SUDO curl --noproxy '*' -fsS -m 5 --cacert /opt/vault/tls/ca.pem https://172.17.0.1:8200/v1/sys/seal-status 2>&1 \
    | python3 -I -c 'import json, sys; d = json.load(sys.stdin); print({k: d.get(k) for k in ("initialized", "sealed", "t", "n")})' 2>&1
  S "step 4: ES and AGS"
  $SUDO bash -c '. /etc/execution-substrate/healthcheck.env
for u in https://[home network address withheld]:8445/health https://[home network address withheld]:8445/v1/executions:contract https://[home network address withheld]:8444/health; do
  curl --noproxy "*" -sS -m 10 -o /dev/null -w "%{http_code} $u\n" --cacert "$CA_CERT" --cert "$OPERATOR_CERT" --key "$OPERATOR_KEY" "$u"
done' 2>&1
}

nomad_config() {
  S "Nomad config"
  $SUDO find /etc/nomad.d -maxdepth 1 -printf '%u:%g %m %p\n' 2>&1
  echo "nomad.hcl sha256 $($SUDO sha256sum /etc/nomad.d/nomad.hcl | cut -c1-64)"
  $SUDO grep -n 'network_interface' /etc/nomad.d/nomad.hcl 2>&1
  nomad version 2>&1 | head -1
}

case "$phase" in
before)
  S "host"
  hostname; date -u +%Y-%m-%dT%H:%M:%SZ; id -un
  $SUDO true && echo "sudo -n: ok"
  health
  nomad_config
  S "links (no MAC or IPv6 addresses)"
  for i in /sys/class/net/*; do printf '%s operstate=%s carrier=%s\n' "${i##*/}" "$(cat "$i/operstate" 2>/dev/null)" "$(cat "$i/carrier" 2>/dev/null)"; done
  ip -4 -br addr 2>&1
  ip route 2>&1
  S "image"
  docker image inspect alpine:3.20 --format 'alpine:3.20 {{.Id}}' 2>&1 | head -1
  install_tool
  S "node networks and plans (expected now: no host network, both plans fail)"
  $SUDO python3 -I "$TOOL" state
  echo "state exit=$?"
  ;;
apply)
  install_tool
  STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
  W="$TOOL_DIR/$STAMP"
  $SUDO install -d -m 0700 -o root -g root "$W" || { echo "cannot create $W"; exit 1; }
  $SUDO cp -p /etc/nomad.d/nomad.hcl "$W/nomad.hcl.before" || { echo "backup failed; nothing changed"; exit 1; }
  echo "BACKUP=$W/nomad.hcl.before sha256 $($SUDO sha256sum "$W/nomad.hcl.before" | cut -c1-64) $($SUDO stat -c '%U:%G %a' "$W/nomad.hcl.before")"
  UNIT="es-nomad-net-$STAMP"
  echo "UNIT=$UNIT"
  if ! $SUDO systemd-run --unit "$UNIT" --collect -p Type=exec -p TimeoutStopSec=10min \
      -- /usr/bin/python3 -I "$TOOL" repair "$W"; then
    echo "systemd-run failed; nothing was started"; exit 1
  fi
  wait_unit "$UNIT"
  ;;
status)
  wait_unit 'es-nomad-net-*'
  ;;
verify)
  health
  S "Nomad lock"
  for p in /v1/status/leader /v1/jobs /v1/namespaces /v1/agent/self; do
    printf 'anonymous GET %s -> %s\n' "$p" "$(curl --noproxy '*' -sS -m 5 -o /dev/null -w '%{http_code}' "http://127.0.0.1:4646$p" 2>&1)"
  done
  if $SUDO test -x "$ACL_CHECK_REPO/scripts/nomad_acl_setup.sh"; then
    $SUDO env NOMAD_ACL_DIR=/etc/execution-substrate/nomad-acl ES_USER=es OBSERVER_USER=root NOMAD_USER=root \
      NOMAD_ADDR=http://127.0.0.1:4646 "$ACL_CHECK_REPO/scripts/nomad_acl_setup.sh" check 2>&1 | redact
    echo "nomad_acl_setup.sh check exit=${PIPESTATUS[0]}"
  else
    echo "nomad_acl_setup.sh not found under $ACL_CHECK_REPO (folder gone after a reboot?)"
  fi
  nomad_config
  install_tool
  S "node networks and plans (expected now: host network on lo, both plans feasible)"
  $SUDO python3 -I "$TOOL" state
  echo "state exit=$?"
  S "one bridge-mode job runs and exits 0"
  $SUDO python3 -I "$TOOL" run-bridge
  echo "run-bridge exit=$?"
  S "Nomad journal (last 15 lines)"
  $SUDO journalctl -u nomad.service --no-pager -n 15 -o short-iso 2>&1 | redact
  ;;
*)
  echo "usage: bash -s -- before | apply | status | verify"; exit 2
  ;;
esac
S "done"
-----END box-nomad-network-run.sh-----
