Reliable submit passed its live checks on the box. All 14 ES checks behaved as designed: every bad request was refused, and the four runs ES admitted received their arguments exactly as sent. For comparison, the checks also sent jobs straight to Nomad, skipping ES. Those showed the problems ES's rules exist to stop, including a container crash caused by two near-identical paths. The box is back to normal.

**Still working**
- The scripts fix that makes the setup work on Wi-Fi or a cable.
- The second PLANS.md step.

STATUS: WORKING (Wi-Fi scripts fix; PLANS.md step 2)
