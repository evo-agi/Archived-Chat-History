# Audit: ES PR #45, docs tests that run without .git

Auditor: read-only audit thread, 2026-11-24 01:48Z to 01:58Z. Nothing pushed, no PR comment.

**Verdict: ACCEPT.** No findings. Merge after CI is green. The "build, vet and test" job 138155259735 on `d8d75e9` was in progress at 01:50Z.

## Target and provenance

- **PR and commits.** PR #45 is one commit, `d8d75e9473b0784ba36989e9681e7f5f2c5f1ed1`, on trunk_dev `6ce00347c6d3d90d8d11649e925927f539437f74`. The base is its ancestor.
- **Files.** `artifact_hygiene_test.go` (+158 −8), `runbook_paths_docs_contract_test.go` (+23 −28), and `.docs/system_overview/artifact_hygiene.md` (§4, +7).
- **Manifest.** I took a fresh-clone v2 manifest twice, with the recipe hash verified first. The two runs were identical, and **byte-identical to the writer's copy** (`manifest-d8d75e9.json`, SHA-256 `d7141c12eb13e826b40e59d8e4450de77053acce7a7b1074706f5dc31e462913`). The textual_diff is `d55a7ae3…c548`, with 3 entries, and every blob matches.

## Shared helper (`repositoryFiles` / `repositoryFilesIn`)

| Check | Result |
| --- | --- |
| Uses tracked files when `.git` exists | Yes. If `os.Lstat(root/.git)` succeeds (a directory, or the `.git` file of a worktree or submodule), the list is `git ls-files -z` run in the root. The old behaviour is unchanged in every git checkout |
| Unreadable git metadata fails, with no fallback | Yes. A git failure returns an error. A `.git` that cannot be stat'ed for any reason other than "does not exist" also returns an error. Only a missing `.git` reaches the directory walk. Pinned by the subtest "git metadata that git cannot read fails" (mutations M1 and M2 below) |
| Walk errors | Returned as an error, not skipped |

## The no-.git file set

- **Contents.** The set is every file in the tree, minus the paths `isGeneratedArtifactByproduct` names, unless `intentionalGeneratedArtifacts` allowlists them.
- **Cannot hide a tracked file.** In every git checkout, CI included, `TestTrackedGeneratedArtifactHygiene` fails if any tracked file is a non-allowlisted byproduct. So the tracked set and the excluded set are disjoint by an enforced rule.
- **Measured on an export.** On a `git archive d8d75e9` export, an independent reimplementation of the walk gives exactly the 507 tracked paths, with no difference (`audit-evidence/walk-vs-tracked.txt`).
- **Symlinks** are listed but then skipped as non-regular files, the same as tracked symlinks in git mode.
- **Untracked local files are read on purpose.** A local `notes.md` with a broken link fails (X1), and so does an untracked script naming a missing runbook (X3). That is a false alarm, not a miss. It is the behaviour §4 now describes. Byproducts are ignored: `build/`, `__pycache__/` and `.out/` (X2, X4, X5).

## The one skip

`TestTrackedGeneratedArtifactHygiene` skips when there is no `.git`. This is justified:

- The test's subject is tracked files.
- Without `.git` nothing records what is tracked, and the walk list excludes byproducts by construction, so running the test on it would be vacuous.
- The skip message names the reason.
- CI checks out with `actions/checkout` (`.github/workflows/go.yml:49`), which keeps `.git`, so the check runs there.

## Assertions

Nothing was weakened.

- **`TestTrackedGeneratedArtifactHygiene`.** In git mode the loop body, the allowlist and the failure are unchanged. Only the source of the list moved into the helper, and it is the same `git ls-files` call.
- **The two docs tests.** They keep every check: link resolution, the allowlisted external target, the "no links found" and "no mentions in scripts/" guards, and the empty-list failure. Only the file source and the message wording changed.
- **§4 text** matches the code.

## Runs (cloud container, Go 1.26.5)

- `go vet .`: exit 0. `gofmt -l` on both files: clean.
- In a git checkout of `d8d75e9`, all 6 tests pass, including the 3 subtests of the new pin test: the hygiene test, the docs-classification test, the pin test, the link test, the mention test and the link-form test.
- In a `git archive d8d75e9` export with no `.git`, the hygiene test SKIPs with its message, and the other 5 pass.
- In a `git archive` export of the base `6ce0034`, the hygiene, link and mention tests all FAIL with "git ls-files inventory failed: exit status 128". That is the problem this PR fixes (`audit-evidence/base-export.log`).

Probes and mutations, run in the export (`audit-evidence/export-probes.log`). The log's first M1 to M4 lines ran on a file left broken by an invalid first edit, and the first M2 still errored through the else-if branch. Each is re-run with a valid edit at the end of the log:

```text
X1 untracked notes.md with a broken link                  exit 1
X2 build/copy.md with a broken link (byproduct)           exit 0
X3 untracked script naming a missing runbook              exit 1
X4 __pycache__ file naming a missing runbook (byproduct)  exit 0
X5 .out/notes.md with a broken link (byproduct)           exit 0
M0 unmodified                                             exit 0
M1 git failure ignored (empty list, no error)             exit 1  (pin test: unreadable .git)
M2 fall back to the walk when git cannot read .git        exit 1  (pin test: unreadable .git)
M3 walk keeps byproducts                                  exit 1  (pin test: no-.git list)
M4 walk drops allowlisted fixtures too                    exit 1  (pin test: no-.git list)
```

## Observations (no action needed)

- **O1. The hygiene check depends on CI keeping `.git`.** It does today, through the pinned `actions/checkout`. If CI ever ran on an export, the check would skip with its message instead of failing.
- **O2. A nested copy is treated as an export.** A copy of ES inside another repository, with no `.git` of its own, now counts as an export (walk mode, hygiene skipped) instead of using the parent's index. That is not a supported layout.

## Report fields

- Touched files: none in any repo. Wrote this report and `audit-evidence/`.
- Assumptions: none.
- Inferences: none.
- Skipped validation: the full root package (only the touched tests were run, and they compile the whole package). The CI result (in progress).
- Authority or security widening: none. Test and doc files only.
- Confidence: high.
