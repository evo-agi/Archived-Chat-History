Quick status while you're out: nothing needs you. The docs-test fix (#45) merged, the TLS collector fix (#30) is taking its merge turn now, and the core-dump fix (#51) follows it.

STATUS: WORKING (merge queue: #30, then #51 and #52; next catch-up when the queue moves)
