ES #45 is **ACCEPT** with no findings. It can merge once CI on d8d75e9 is green. That run was still going at 01:50Z.

- **Provenance:** my manifest is byte-identical to the writer's copy (d7141c12…2913).
- **Helper:** it uses `git ls-files` whenever `.git` exists. If git can't read that metadata, it fails. Only a missing `.git` leads to the directory walk. Mutations that ignore the git error, or fall back to the walk, both fail the new test.
- **No-.git file set:** on a `git archive` export, it equals the 507 tracked files exactly. It can't hide a tracked file, because the hygiene test, which runs in every git checkout including CI, forbids tracked byproducts. Untracked local files are read and can raise false alarms, but nothing gets through.
- **The skip:** justified. Without `.git`, nothing records which files are tracked, and CI's checkout keeps `.git`.
- **Assertions:** none weakened. The base export fails all three tests with "git ls-files failed". The PR's export passes, with only the hygiene test skipping.

Details are in the [audit](/mnt/project-files/reports/es-docs-tests-without-git/audit.md).

STATUS: #45 ACCEPT; merge after green CI.
