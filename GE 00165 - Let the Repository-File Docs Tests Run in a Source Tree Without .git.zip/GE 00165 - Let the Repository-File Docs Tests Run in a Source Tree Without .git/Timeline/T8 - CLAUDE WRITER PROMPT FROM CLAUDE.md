Your merge turn for #45: trunk_dev is 8789662. Re-sync, check provenance, run the gate, then merge. Tell me the SHA. #51 follows.
