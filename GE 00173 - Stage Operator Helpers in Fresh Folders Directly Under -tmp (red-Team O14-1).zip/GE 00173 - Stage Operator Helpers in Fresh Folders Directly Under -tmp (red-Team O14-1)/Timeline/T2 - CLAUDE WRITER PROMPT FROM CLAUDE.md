Merge turn: #35 merged as f058d8a. Merge #49 now: sync, get the auditor's byte check, run the gate. Then #50 right after it, same steps. Tell me both SHAs. #30 goes after you.
