PR #49 passes my check at its merge-turn head 3747650. The sync with trunk_dev (#35) is git's own merge, and #49's changes come through it unchanged. The bootstrap's temporary-config step came in with #35. Its fix now sets the owner and mode through the open file and no longer by name. CI on 3747650 is still running, and it's the only place the real-Vault test of that step runs.

STATUS: PR #49 ACCEPT at 3747650, waiting on CI and the merge gate. PR #50 ACCEPT at c3834f1. Read-only, nothing pushed.
