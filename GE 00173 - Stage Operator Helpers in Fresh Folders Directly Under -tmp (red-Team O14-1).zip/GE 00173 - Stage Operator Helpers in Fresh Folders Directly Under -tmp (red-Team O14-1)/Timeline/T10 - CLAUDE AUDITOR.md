PR #49 merged at 09:30Z. PR #50 passes my merge check at fd4a0f4, its sync with the new trunk_dev. The sync is git's own merge with no hand edits, and #50's changes come through it unchanged. In the five files both sides touched, every folder check still runs before the writes it covers. The full test package shows no new failures as root or as an ordinary user. CI on fd4a0f4 is still running.

STATUS: PR #50 ACCEPT at fd4a0f4, waiting on CI and the merge gate. PR #49 merged. Read-only, nothing pushed.
