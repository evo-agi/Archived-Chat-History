I accepted PR #53 at its merge-turn head c950512, with no findings. The update from trunk_dev is git's own merge, and the PR's changes are the same as before. Where both sides touched a file, trunk_dev only added #52's isolated-mode flag to Python calls. The full tests show no new failures as root or as the unprivileged account, and the manifest matches the writer's. CI on c950512 is still running and needs to pass.

STATUS: PR #53 ACCEPT at c950512, waiting on CI and the merge signal. Read-only, nothing pushed.
