#!/usr/bin/env bash
# Verify PR #53 closes O14-1: the operator's /tmp staging folders cannot be
# taken over by a second account. Exercises the operator's own prepare, run-step
# and cleanup text, extracted from scripts/remote_alpha_operator.sh at the PR
# head, with a real SSH-user account (op) and a real attacker account (att).
# Private mount namespace: sticky tmpfs on /tmp, overlay on /etc, so nothing
# outlives the run:
#   unshare --mount --propagation private bash probe.sh <repo>
set -uo pipefail
REPO=${1:?repo}; OP=/home/user  # placeholder
[[ $(id -u) == 0 ]] || { echo "run as root inside unshare --mount" >&2; exit 2; }
ET=$(mktemp -d); mkdir -p "$ET"/u "$ET"/w
mount -t overlay overlay -o "lowerdir=/etc,upperdir=$ET/u,workdir=$ET/w" /etc
mount -t tmpfs tmpfs /tmp && chmod 1777 /tmp
groupadd --system op; useradd --system --gid op --home-dir /tmp --no-create-home --shell /bin/bash op
groupadd --system att; useradd --system --gid att --home-dir /tmp --no-create-home --shell /bin/bash att
as_op()  { setpriv --reuid op  --regid op  --clear-groups -- "$@"; }
as_att() { setpriv --reuid att --regid att --clear-groups -- "$@"; }
OPSH="$REPO/scripts/remote_alpha_operator.sh"

# The exact run-step private-folder predicate, lifted from the operator.
RUNCHECK='[[ -d "${stage_dir}" && ! -L "${stage_dir}" && -O "${stage_dir}" && -n "$(find "${stage_dir}" -maxdepth 0 -perm 0700 -print)" ]]'
runcheck_as() { # $1 user-fn, $2 stage_dir -> prints PASS/REFUSE
  local fn=$1 sd=$2
  "$fn" bash -c "stage_dir=$(printf %q "$sd"); if $RUNCHECK; then echo would-run; else echo refused; fi"
}
# The exact cleanup predicate body.
cleanup_body='stage_dir="$1"; if [[ -d "${stage_dir}" && ! -L "${stage_dir}" && -O "${stage_dir}" ]]; then rm -rf -- "${stage_dir}" || true; fi'

pass=0; fail=0
ok()   { echo "PASS  $1"; pass=$((pass+1)); }
bad()  { echo "FAIL  $1"; fail=$((fail+1)); }

echo "#### PREPARE: mkdir -m 0700 with no -p, on a name a second account planted"
for layout in plant-dir plant-link plant-dir-with-internal; do
  SD=/tmp/execution-substrate-remote-alpha-vault-unseal-existing-$RANDOM
  VIC=/tmp/attacker-dir-$RANDOM; as_att mkdir -m 0777 "$VIC"; as_att sh -c "echo pwned >$VIC/evil"
  case $layout in
    plant-dir)           as_att mkdir -m 0777 "$SD" ;;
    plant-link)          as_att ln -s "$VIC" "$SD" ;;
    plant-dir-with-internal) as_att mkdir -m 0777 "$SD"; as_att mkdir -p "$SD/scripts/internal" ;;
  esac
  # the operator's prepare step, run as op:
  out=$(as_op bash -c "set -euo pipefail; stage_dir=$(printf %q "$SD"); mkdir -m 0700 -- \"\${stage_dir}\"; mkdir -m 0700 -- \"\${stage_dir}/scripts\" \"\${stage_dir}/scripts/internal\"" 2>&1); rc=$?
  owner=$(stat -c '%U %a' "$SD" 2>/dev/null || echo '?')
  if [[ $rc -ne 0 && "$owner" != "op 700" ]]; then ok "$layout: prepare failed (rc=$rc), name still $owner -> route aborts, nothing staged"; else bad "$layout: prepare rc=$rc owner=$owner"; fi
done

echo
echo "#### PREPARE clean, then a second account tries to take over the 0700 leaf under sticky /tmp"
SD=/tmp/execution-substrate-remote-alpha-vault-workload-auth-bootstrap-$RANDOM
as_op bash -c "mkdir -m 0700 -- '$SD'; mkdir -m 0700 -- '$SD/scripts' '$SD/scripts/internal'; echo real-helper >'$SD/scripts/internal/remote_alpha_vault_workload_auth_bootstrap.sh'"
as_att bash -c "echo pwned >'$SD/scripts/internal/remote_alpha_vault_workload_auth_bootstrap.sh'" 2>/dev/null && bad "att wrote inside the 0700 leaf" || ok "att cannot write inside the 0700 leaf"
as_att bash -c "mv '$SD' '$SD.taken'" 2>/dev/null && bad "att renamed the leaf (sticky /tmp failed)" || ok "att cannot rename the leaf (sticky /tmp)"
as_att bash -c "rm -rf '$SD'" 2>/dev/null; [[ -d "$SD" && "$(cat "$SD/scripts/internal/remote_alpha_vault_workload_auth_bootstrap.sh")" == real-helper ]] && ok "att cannot remove the leaf or swap the helper; real helper intact" || bad "the leaf or helper changed"

echo
echo "#### RUN-STEP private-folder check (the exact operator predicate)"
R=/tmp/rc-$RANDOM
as_op mkdir -m 0700 "$R.ok";            [[ $(runcheck_as as_op "$R.ok") == would-run ]] && ok "op-owned 0700 -> would run" || bad "0700 refused"
as_op mkdir -m 0755 "$R.loose";         [[ $(runcheck_as as_op "$R.loose") == refused ]] && ok "op-owned 0755 -> refused" || bad "0755 accepted"
as_att mkdir -m 0700 "$R.att";          [[ $(runcheck_as as_op "$R.att") == refused ]] && ok "att-owned 0700 -> refused (not -O)" || bad "att folder accepted"
as_att mkdir -m 0777 "$R.tgt"; as_op ln -s "$R.tgt" "$R.link"; [[ $(runcheck_as as_op "$R.link") == refused ]] && ok "symlink -> refused" || bad "symlink accepted"

echo
echo "#### CLEANUP removes only a real folder the user owns"
C=/tmp/cl-$RANDOM; as_att mkdir -m 0777 "$C"; as_att sh -c "echo keep >$C/keep"
as_op bash -c "$cleanup_body" _ "$C" 2>/dev/null
[[ -e "$C/keep" ]] && ok "cleanup left the attacker's folder alone (not -O)" || bad "cleanup removed an attacker folder"
C2=/tmp/cl2-$RANDOM; as_op mkdir -m 0700 "$C2"; as_op sh -c "echo mine >$C2/f"; as_op bash -c "$cleanup_body" _ "$C2"
[[ ! -e "$C2" ]] && ok "cleanup removed the op's own folder" || bad "cleanup left the op's own folder"

echo
echo "result: $pass passed, $fail failed"
