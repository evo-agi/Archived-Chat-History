# ES PR #53: sync check of the merge with trunk_dev ed94a6b (report 27)

```
Target:    evo-agi/Execution-Substrate PR #53, head c950512740ab51e2d015dbd2981e94bb2c6d22a0:
           6c74583 (delta check 24 ACCEPT, red-team 25 no bypass) merged with trunk_dev
           ed94a6b (#30, #51, #52).
Asked by:  the PR's writer thread, 2026-11-24 15:06Z (report 26-o14-sync-ed94a6b.md).
Posture:   independent auditor thread. Read-only: nothing pushed, no PR comment, nothing on
           the Linux box. Real root, and the unprivileged account ci with two groups. Every
           test run used a private, empty /var/tmp. Kept to what the merge gate needs.
Verdict:   ACCEPT. The merge is git's own, with no hand edits, and the PR's changed lines are
           the same as at 6c74583. In the two files both sides changed, trunk_dev only added
           #52's `-I` to `python3` calls; #53's returns and the operator's staging code are as
           delta check 24 accepted them. No new test failures as root or as ci. CI on c950512
           must still pass.
```

Labels: **Ran** (I executed it and saw the result), **Read**, **Inference**.

## 1. The merge (Ran)

- c950512 has parents 6c74583 and ed94a6b. Its tree `b48380d2…a2eab5b2` is the same as
  `git merge-tree --write-tree 6c74583 ed94a6b`.
- trunk_dev moved 230954d → ed94a6b by three squash commits: #30 (2c6847a), #51 (30b241d),
  #52 (ed94a6b).
- The PR touches the same 7 paths as at 6c74583. For each one, the changed lines (`git diff
  -U0`, `+` and `-` only) of ed94a6b..c950512 equal those of 230954d..6c74583. For the whole
  PR that hash is `3187af45…` both times.
- Two of the 7 files also changed on trunk_dev: the overview doc and the ES binary deployment
  script. The operator script and the four test files did not.

## 2. The two files both sides changed (Read)

- **ES binary deployment script.** trunk_dev's only change is #52's `python3 -` → `python3 -I -`
  on eight lines. One of them is the provenance step at the end of
  `…_make_local_payload_tree`. In the merged file both tree functions read as at 6c74583, with
  every step but the last ending in `|| return 1`, and the last step (the payload call, the
  provenance `python3 -I` heredoc) still giving the function its status.
- **Doc.** trunk_dev added 175 lines and removed 7 elsewhere in the file. #53's paragraph is
  unchanged (same changed lines as above).

Also (Ran):
- No line trunk_dev added between 230954d and ed94a6b names `/tmp`.
- trunk_dev changed three operator-side internal helpers (`operator_failures.sh`, the
  healthcheck TLS renew helper, the ES config TLS prep stage). Every changed line there only adds
  #52's `-I` to a `python3` call (checked line by line). None changes a path or a staging step,
  and the operator script, which holds the staging, run-step and cleanup code, is byte-identical
  to 6c74583.

## 3. Manifest (Ran; `manifest/`)

v2 tool c08597e2…a3ca, branch `claude/operator-tmp-staging`, upstream `origin/trunk_dev` =
ed94a6b, `git reset --mixed ed94a6b`, two runs byte-identical:
**a96e905102f9baf83b1404fc0726fe9a1c33cd679ad3e7d8005503e44ef62ca8**, textual dcb7ab6d…78c8,
7 files. Byte-identical to the writer's `26-evidence/manifest-c950512.json`.

Against report 24's manifest the paths are the same. Only the two files of section 2 have
different entries; the other five are identical.

## 4. Tests (Ran; `tests/`)

Full `scripts` package and the root package, on exported trees of c950512 and ed94a6b. Counts
include subtests.

| Run | c950512 | ed94a6b | New failures |
|---|---|---|---|
| `scripts`, root | 1960 pass, 260 fail, 12 skip | 1926 pass, 260 fail, 12 skip | none |
| `scripts`, ci with two groups | 1955 pass, 250 fail, 20 skip | 1925 pass, 250 fail, 16 skip | none |
| root package, root | 607 pass, 0 fail, 1 skip | 607 pass, 0 fail, 1 skip | none |
| root package, ci | 607 pass, 0 fail, 1 skip | 607 pass, 0 fail, 1 skip | none |

- The failing tests are the same on both sides, and the same set (by name) as report 24's run
  on 6c74583: this container's usual set.
- The 4 extra skips as ci are #53's four foreign-folder cleanup subtests, which need root or
  `sudo -n`, as in report 24. As root all four run and pass. CI has passwordless sudo.
- #53's stage, route, upload-tree and guard tests pass as root and as ci, apart from
  `…ESTLSStatusPreCollectorStageCleanup`, which fails on ed94a6b as well (TLS status set).
- #52's three isolated-mode tests (`TestScriptsStartPythonInIsolatedMode`, `…CheckFindsEachForm`,
  `…Docs`) pass on c950512 as root and as ci, so no `python3` line in the PR's files escapes
  that guard.
- #52 also changed tests in `es/app`. #53 touches nothing there, so I did not run it.

## 5. CI (Read)

- The run on 6c74583 (45381803647) passed, 11:10:58Z to 12:02:05Z.
- The run on c950512 (45421546411) started at 15:06:02Z and was still running when this report
  was written. The gate needs it green.

## 6. Evidence

`27-evidence-auditor/` (hashes in `SHA256SUMS`):
- `manifest/`: both runs.
- `tests/`: full-package JSON for head and base, root and ci, both packages; the comparison and
  the runner.
