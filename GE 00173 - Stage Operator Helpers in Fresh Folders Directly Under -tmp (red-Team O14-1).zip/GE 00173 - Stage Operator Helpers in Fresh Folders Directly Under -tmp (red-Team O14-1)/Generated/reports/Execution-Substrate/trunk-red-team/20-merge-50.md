# MERGE REPORT: PR #50 (N-1 artifact folder check) into trunk_dev (report 20)

Writer thread, 2026-11-24 10:15Z.

| Item | Value |
| --- | --- |
| PR | #50, branch `claude/remote-alpha-artifact-folder` |
| Accepted head | `fd4a0f494659ad12a2f2df039156c87ce26d846b`, tree `e2ee4322feaccf7e34bf3a619d02f5f591dbd301`, manifest v2 vs `3f1a84c` `38eb7a7c…3220` (22 files) |
| Checks | Audit 10 ACCEPT (code at 0330c5a), byte check of c3834f1, red-team re-check 14 (no bypass), merge check 19 ACCEPT of the 3f1a84c sync (report 18) |
| CI | run 45366317419 `build, vet and test`, success on `fd4a0f4` (09:33:29Z to 10:14:00Z) |
| Gate (10:14:50Z) | `git ls-remote`: head `fd4a0f4`, `trunk_dev` `3f1a84c`, an ancestor of the head; mergeable state clean; both Codex review threads resolved (fixes confirmed by audit 10); not draft |
| Authority | Coordinator's merge turn 08:37Z ("Then #50 right after it, same steps"). Scripts, tests and docs only |
| Effect | Squash merge with expected head `fd4a0f4`: `trunk_dev` is `8789662663190844b894638aa6fda6903a93b937`, parent `3f1a84c`, tree `e2ee4322…d301`, equal to the accepted head's tree. GitHub deleted the head branch |
| Other | PR description updated to the final state before the merge (own PR) |

Next in the queue: #30. Follow-up PR for red-team O14-1 (operator /tmp staging) opens next from `claude/operator-tmp-staging`.
