# ES PR #49: delta check of the sync with trunk_dev f058d8a and the bootstrap conversion (report 16)

```
Target:    evo-agi/Execution-Substrate PR #49, head 37476505d6c428f20c7e458e1ecb3dc7d795d060,
           base trunk_dev f058d8a (#35 merged). Two commits on 627b365, which merge check
           (2026-11-24 08:10Z) accepted: 3e41553, the merge of f058d8a, and 3747650, a hand
           edit of code #35 brought in.
Asked by:  the PR's writer thread, 2026-11-24 08:48Z (report 15-sync-f058d8a.md), at #49's
           merge turn.
Posture:   independent auditor thread. Read-only: nothing pushed, no PR comment, nothing on
           the Linux box. Real root, and the unprivileged account ci with two groups. Every
           test run used a private, empty /var/tmp.
Verdict:   ACCEPT. The merge is git's own and leaves the PR's changes as accepted. The
           conversion closes both name-swap windows in the bootstrap's temporary-config step,
           and the firewall script's allowance of 7 is right: every one of those lines acts
           as root in a folder only root can change, and one is message text. No new test
           failures, as root or as ci. The guards catch the conversion being undone. CI on
           3747650 must still pass; it runs the real-Vault test of this step, which I could
           not run here.
```

Labels: **Ran** (I executed it and saw the result), **Read**, **Inference**.

## 1. The merge, 3e41553 (Ran)

- Parents 627b365 and f058d8a. Tree `4864e4ab3c0be9f3b0fd2bec5664872b56fbfda6`, the same as
  `git merge-tree --write-tree` of e8b834b with f058d8a and of 627b365 with f058d8a.
- #35 touches none of the PR's six script and test files, and each of them has the same blob
  in 3e41553 as in 627b365.
- The doc is the one file both sides edit. Its changed lines (`git diff -U0`, `+` and `-`
  lines only) are identical for 2ba2db8..627b365 and f058d8a..3e41553. For the whole PR that
  hash is `e7637872…7497` both times. Only the doc's context lines differ.

## 2. The conversion, 3747650 (Read)

`git diff 3e41553 3747650` has sha256 `9824a760…e61e`, the same as the writer's file. It
changes the bootstrap script, the root paths test file and one doc paragraph.

**What #35 brought in.** `TemporaryGenerateRootAccess` rewrites Vault's configuration file
(default `/etc/vault.d/vault.hcl`) as root and later writes the original bytes back. The
Vault account owns `/etc/vault.d` before the migration. Two windows let it swap a name for a
link:
- between `mkstemp` and `os.chown`/`os.chmod` of the temporary file by name, which would give
  any file vault.hcl's owner and mode;
- between `os.lstat` and `read_bytes()`, which would copy a root-only file into vault.hcl.

**Now.**
- `_write` sets owner and mode with `os.fchown`/`os.fchmod` on the descriptor `mkstemp`
  opened (`O_CREAT|O_EXCL|O_NOFOLLOW`), before `fsync`. The name is then used only by
  `os.replace`. A swap before the rename only moves a name inside the folder the account
  already controls; it could already replace vault.hcl itself. The rename never writes
  through a link.
- `read_regular_file_no_follow` opens with `O_NOFOLLOW|O_NONBLOCK`, refuses a link (`ELOOP`)
  and anything that `fstat` does not call a regular file, and reads from the same
  descriptor. A FIFO cannot block it. A missing or unreadable file fails as before.
- `enable` takes the bytes and the owner and mode from that one descriptor. The restore
  check reads the same way, so a link put there after the write fails closed as
  `vault_config_restore_failed`. The preflight also reads through it.
- These are the only file writes #35 added to the bootstrap (Ran: every added line that
  opens, writes, renames or changes an owner). Its other by-name line, `os.chmod(temp_path,
  0o600)` for the summary file, was already in the allowance before #35.

The doc sentence matches the code.

## 3. The firewall allowance (Read)

`remote_alpha_host_firewall.sh` has 7 lines the guard counts:
- line 158: text of a refusal message;
- 674 and 712: `chmod` of files in the run folder `/var/lib/es-host-firewall`;
- 698: `install -d -m 0700 -o root -g root` of that run folder;
- 793 and 794: `chmod`/`chown` of a `mktemp` file next to the target, in
  `/etc/execution-substrate/host-firewall` or `/etc/systemd/system`;
- 874: `install -d` of `/etc/execution-substrate/host-firewall`.

Every function that reaches them first calls `remote_alpha_host_firewall_require_root`.
`/var/lib` and `/etc/systemd/system` are root's. The docs give helper users only execute
ACLs on `/etc/execution-substrate` (`remote_supported_host_alpha.md` line 2751). The paths
come from `REMOTE_ALPHA_HOST_FIREWALL_*` variables that only the root caller sets.
`remote_alpha_host_firewall.py` only reads files, and the wrapper
`scripts/remote_alpha_host_firewall.sh` has no such line. I16-2 suggests one box check for the
folder owners.

## 4. Tests (Ran; `tests/`)

Selection, on 3747650 and on f058d8a:
`^(TestRemoteAlphaARSHardening|TestRemoteAlphaResetDisposableVault|TestRemoteAlphaVaultServiceUserMigration|TestRootScriptByName|TestRedTeamFixedSteps|TestRemoteAlphaVaultWorkloadAuthBootstrap|TestRemoteAlphaHostFirewall)`.
Counts include subtests.

| Run | 3747650 | f058d8a | New failures |
|---|---|---|---|
| root | 203 pass, 7 fail, 6 skip | 148 pass, 7 fail, 6 skip | none |
| ci with two groups | 202 pass, 0 fail, 7 skip | 154 pass, 0 fail, 7 skip | none |

- The 7 root failures are the same on both: the three real-kernel firewall tests (this
  container) and the four known migration tests that fail as root on trunk_dev too (lines
  604, 409, 488, 684).
- The two real-Vault bootstrap tests skip here: there is no `vault` binary, and I did not run
  a downloaded one. They exercise `REMOTE_ALPHA_BOOTSTRAP_GENERATE_ROOT_ACCESS=temporary-config`
  against Vault 2.2.2, which CI installs, and they are not on CI's self-skip list. So the
  green CI run on 3747650 is the end-to-end evidence for this step.

## 5. Manifest (Ran; `manifest/`)

v2 tool c08597e2…a3ca, branch `claude/project-thread-wg7jh5`, upstream `origin/trunk_dev` =
f058d8a, `git reset --mixed f058d8a`, two runs byte-identical:
**5c9dbfe6a9218135f2315e4e65d9d1a650672edc63c67fd68aac9be969d1b727**, textual 4616d1f2…5fd2,
8 files. This matches the writer's.

## 6. Mutants (Ran; `mutants/`)

Each mutant changes the bootstrap on the 3747650 tree. Run: the two guards and every
`TestRemoteAlphaVaultWorkloadAuthBootstrap` test.

| Mutant | ci with two groups (as CI runs) | root | Caught by |
|---|---|---|---|
| K1: `os.chown`/`os.chmod` by name back in `_write` | killed | | both guards |
| K2: `os.lstat` then `read_bytes()` back in `enable` | killed | | descriptor test |
| K3: the new file's mode not kept (`fchmod` 0600) | killed | killed | `…TemporaryGenerateRootAccess`, 5 subtests |
| K4: no `fchown`/`fchmod` at all | killed | killed | descriptor test and `…TemporaryGenerateRootAccess` |
| K5: no `O_NOFOLLOW` in the read | killed | | descriptor test only |
| K6: restore check reads by name | killed | | descriptor test |
| K7: no `S_ISREG` check after `fstat` | killed | killed | descriptor test only |
| K8: owner set to root:root | killed | survived | `…TemporaryGenerateRootAccess` as ci; as root the fixture file is root's, so the mutant is equivalent there |

K5 and K7 are pinned only by the static test. The preflight refuses a link first, so a
functional test would need a swap between the preflight and `enable`, which is a race. That is
the same standing as the other fixed steps in this PR. The writer's two mutants match K1 and K2.

## 7. Info (no change needed)

- **I16-1. A hard link at the name is read like the file.** `read_regular_file_no_follow`
  accepts a regular file with more than one link. With `fs.protected_hardlinks = 1` (the Ubuntu
  default) the Vault account cannot link a file it neither owns nor can read and write. Even
  with 0, root only copies that file's bytes into a new vault.hcl with that file's own owner
  and mode, and the rename replaces the name, never the other file. So nothing is opened up or
  changed (Inference from the code). Refusing `st_nlink != 1` would match the migration's rule,
  but it is optional.
- **I16-2. One more read-only row for `box-checks.md`, for a later box turn:**
  `sudo stat -c '%U:%G %a %n' /etc/execution-substrate /etc/execution-substrate/host-firewall /var/lib/es-host-firewall; sysctl fs.protected_hardlinks fs.protected_symlinks`.
  Expect `root:root` without group or other write for the three folders, and 1 for both
  settings. The firewall allowance assumes the first. The box's `protected_hardlinks` value
  has been Unknown since audit 03.
- **I16-3. #50 after this.** `git merge-tree` of #50's c3834f1 with 3747650 is clean (tree
  e2ee4322). On that tree the two guards and the `TestRemoteAlphaOutputDir` tests, the call-site
  pin test among them, pass as root and as ci (Ran; `trial50/`). #50 still needs its own merge
  check at its turn.
- **CI (Read).** The run on 627b365 (45353399350) passed, 08:07:32Z to 08:44:57Z. The run on
  3747650 (45359234712) started at 08:47:42Z and was still running when this report was
  written. The gate needs it green.

## 8. Evidence

`16-evidence-auditor/` (hashes in `SHA256SUMS`):
- `manifest/`: both runs.
- `tests/`: the selection JSON for head and base, root and ci, the comparison and the runner.
- `mutants/`: `mutants15.py.txt`, the runner and the results.
- `trial50/`: the guard and output-folder tests on the merge-tree of #50 with 3747650.
