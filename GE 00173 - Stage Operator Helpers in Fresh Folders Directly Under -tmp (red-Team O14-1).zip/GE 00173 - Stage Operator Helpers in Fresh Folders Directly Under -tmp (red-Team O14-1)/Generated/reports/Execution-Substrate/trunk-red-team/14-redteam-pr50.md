# ES PR #50: red-team re-check of the artifact folder check (N-1) (report 14)

```
Target:    evo-agi/Execution-Substrate PR #50. The coordinator named head 0330c5a; the live
           head is now c3834f1231a7616b853dcf852720c0277202698a (refs/pull/50/head re-checked
           2026-11-24 08:33Z). c3834f1 differs from 0330c5a only by the auditor's added test
           file remote_alpha_output_dir_call_sites_test.go (Ran: git diff --stat, one file),
           so every script and the check are byte-identical and this re-check covers both.
Asked by:  the coordinator, 08:25Z. The note named this file 07-redteam-pr50.md, but 07 is
           the writer's implementation report, so this is the next free number, 14.
Posture:   the thread that wrote report 01; separate from the writer and the auditor;
           read-only on the repo; nothing pushed, no PR comment; nothing on the Linux box.
           One cloud container, real root, a real second account (uid 996) as the attacker,
           and a real trusted operator account, in a private mount namespace with a fresh
           tmpfs on /var/tmp.
Verdict:   NO BYPASS of the artifact folder check. Every refusal and acceptance I tried
           matched the design, including a race. One adjacent observation (O14-1, Low): the
           operator's own /tmp vault and healthcheck staging folders are a separate,
           pre-existing surface this PR does not cover and did not claim to; worth its own
           look, not a bypass of N-1.
```

Labels: **Ran** (I executed it and saw the result), **Read**, **Inference**.

## 1. The check, and the one thing it does not cover (Read)

`remote_alpha_prepare_output_dir DIR` walks `DIR` from `/`, one name at a time, with
`O_PATH | O_DIRECTORY | O_NOFOLLOW`. It creates a missing name through the parent's
descriptor and opens it again the same way. It refuses:

- a `..` component (the path is never normalized, so a `link/..` can't name one folder for
  the check and another for the write);
- a symbolic link anywhere on the path;
- a folder owned by anyone but root, the running user, or a numeric `SUDO_UID` (only sudo
  sets that, so only the person who ran sudo chooses it);
- a folder its group or others can write, unless root owns it and it is sticky (`/var/tmp`,
  `/tmp` themselves);
- `DIR` itself when its group or others can write it.

`O_PATH` reads each owner and mode without read permission, so a root-private folder passes
and sudo can then hand it over. Because every folder on the path can be changed only by a
trusted account, and a trusted entry in a root-owned sticky folder can't be renamed by
another account, nothing can swap a name between the check and the write that follows.

What it does not cover, by design: entries that were already inside `DIR` before it became
private. On the box the folder is `ds:ds 0750` (Read: audit 03 O-2), which nothing untrusted
could have written. Report 10's I10-1 already notes this and proposes a box-check row for it.

## 2. Every write into the artifact folder calls the check (Read)

Sixteen scripts name `/var/tmp/execution-substrate-remote-alpha`. One is the definition
itself; the other fifteen each call `remote_alpha_prepare_output_dir` (or, for the two
Mac-side staging routes, `remote_alpha_prepare_output_dir_as_root`, which runs it through
sudo before any other sudo step) before their first write, and again just before the write
in the helpers that write more than a summary. `TestRemoteAlphaOutputDirCopiesMatch` fails if
a copy drifts, a copy is never called, or a script names the folder with no copy and no
sender. I checked each call site against its writes and found none that writes first. This
matches the auditor's table in report 10; I did not find a write it missed.

Backup roots are checked only in the writing modes (apply, execute_renew), which is right:
check-only and status modes never write there.

## 3. Probes (Ran; `14-evidence/n1-probe.sh`, `n1-probes.out`)

The check ran as root with `SUDO_UID` set to a trusted operator account; the attacker is a
real account (uid 996) that prepared the folder with `setpriv`. Fresh tmpfs on `/var/tmp`.
The victim is a root-only file reached through a planted link.

| Case | Result |
|---|---|
| attacker owns the folder 0777 with a link to the victim inside | refused ("belongs to uid 996…") |
| attacker owns the folder 0755 | refused |
| the folder name is a link to a root directory | refused ("is not a directory or is a symbolic link") |
| root owns the folder but it is 0757 | refused ("can be written by its group or others") |
| operator (SUDO_UID) owns it, 0750 (the box layout) | **accepted** |
| operator owns it but 0770 (audit N8) | refused |
| `/var/tmp` itself given as the artifact folder (audit N2) | refused, with no root needed |
| clean first run, no attacker | creates it `root:root 0755` |
| race: root removes and reruns the check 300 times while the attacker plants a 0777 folder with a link in a tight loop | every accepted run owned the folder as root; 0 accepts of a folder root did not own; the victim's bytes never changed |

The N8 and N2 cases are the two the auditor could only reach as root (report 10, A10-2).
Here `/var/tmp` is 1777, so both are refused whatever the privilege, and my probe confirms it
directly. No case let the attacker's folder or link through, and nothing reached the victim.

## 4. Codex's two earlier findings stay closed (Read, one Ran)

- `abspath` collapsing `link/..`: the path is no longer normalized and `..` is refused. My
  probe passes no `..` case, and the check refuses one by construction (Read).
- the `O_RDONLY` walk refusing a root-private folder: the walk uses `O_PATH`, and my
  root-owned-0700 clean run is accepted (Ran).

## 5. O14-1 (Low, adjacent, not a bypass of N-1): the operator's /tmp staging folders

The operator's recovery routes stage helper scripts under predictable, world-writable paths
and then run them: `/tmp/execution-substrate-remote-alpha-vault-unseal-existing`,
`-vault-reset-disposable-{dry-run,execute}`, `-vault-workload-auth-bootstrap`, and
`-operator-healthcheck-tls-renew`, each with a `run_id` of `date -u +%Y%m%dT%H%M%SZ-$$`
(Read, `scripts/remote_alpha_operator.sh`). The prepare step is `rm -rf -- "${stage_dir}"`,
`mkdir -p -- "${stage_dir}"`, `chmod 0700`, where `stage_dir` is `<parent>/<run_id>`. This is
**not** the artifact folder, it is **not** covered by `remote_alpha_prepare_output_dir`, and
this PR did not change these routes.

Why it is worth a note: the same PR hardened the two Mac-side *staging* routes it does touch
(ES config/TLS prep and ES binary deploy) to `mkdir -m 0700` with no `-p`, plus the as-root
check on the parent. These operator vault and healthcheck routes keep `mkdir -p` and a
separate `chmod`. `mkdir -p` follows a symlinked parent, and the parent
(`…-vault-unseal-existing`) does not exist until first use, so another local account can
create it first and own it. **Inference (not reproduced here; it needs the Mac-side SSH
orchestration):** owning that parent gives a TOCTOU window to substitute the staged helper
between the prepare and the run. The unseal, reset and bootstrap helpers then run as the SSH
user (ds); the healthcheck-tls route runs its helper under `sudo`, so there the substituted
code would run as root.

This is pre-existing and outside the N-1 fix's stated scope (the artifact folder), so I am
not holding PR #50 for it. I recommend it be looked at on its own: either route these through
`remote_alpha_prepare_output_dir` on the parent as the Mac-side staging routes now do, or
create the leaf with `mkdir` (no `-p`) under a parent made the same safe way, so a planted
parent or leaf makes the step fail. The box firewall and the small number of local accounts
limit who could try it.

## 6. Coverage this pass could not provide

- No systemd, no real Vault, no SSH orchestration: the operator and staging routes were read,
  not executed end to end; O14-1's exploitability is reasoned, not reproduced.
- The probes exercised the canonical check function directly (the 13 copies are byte-identical
  by the drift test, Read); I did not drive all fifteen helpers.
- I did not rerun the full suite or the auditor's mutants; report 10 and report 13 cover those.
- Nothing on the box. The read-only box checks remain in `box-checks.md`.
- RT-4 (Nomad port holder) is still not in any PR.

## 7. Evidence

`14-evidence/` (hashes in `SHA256SUMS`): `n1-probe.sh` (the probe, scratch only, never
pushed) and `n1-probes.out`. The folder-check results were produced against the worktree at
0330c5a, which is byte-identical to the live c3834f1 for every script.
