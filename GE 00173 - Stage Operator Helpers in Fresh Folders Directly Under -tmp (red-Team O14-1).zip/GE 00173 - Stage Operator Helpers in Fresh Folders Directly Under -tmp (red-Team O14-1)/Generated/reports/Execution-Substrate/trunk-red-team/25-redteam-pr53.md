# ES PR #53: red-team re-check of the operator /tmp staging fix (O14-1) (report 25)

```
Target:    evo-agi/Execution-Substrate PR #53, head 6c7458382f83c5ef381acf3628a2eed1d0a813a5
           (refs/pull/53/head re-checked 2026-11-24 11:28Z, unchanged since the ask). Base/
           sync: trunk_dev 230954d. 6c74583 = 4a1197e (audit-22 follow-ups on 943abbb) merged
           with trunk_dev 230954d (#45).
Asked by:  the coordinator, 11:25Z, as the fix for my own observation O14-1 (report
           14-redteam-pr50.md section 5). The note named this file 24-redteam-pr53.md, but 24
           is the auditor's delta check, so this is the next free number, 25.
Posture:   the thread that wrote reports 01, 06, 14; separate from the writer and the auditor;
           read-only on the repo; nothing pushed, no PR comment; nothing on the Linux box. One
           cloud container, real root, a real SSH-user account (op) and a real attacker account
           (att), in a private mount namespace with a sticky tmpfs on /tmp.
Verdict:   FIXED, no bypass. O14-1 is closed and the Codex P1 behind it is closed. With a real
           second account I could not pre-plant, swap, race or link my way into any of the five
           staging routes, and the run-step and cleanup guards refuse every unsafe folder I
           built. No new finding. One Info note carried from the audit.
```

Labels: **Ran** (I executed it and saw the result), **Read**, **Inference**.

## 1. What O14-1 was, and what the fix does (Read)

O14-1: the operator's Vault unseal, Vault reset (dry run and execute), workload-auth bootstrap
and healthcheck TLS routes staged helpers in `<fixed /tmp parent>/<run id>`, where the parent
was made with `mkdir -p` and the leaf got a separate `chmod`. Another local account could own
the fixed parent first and swap the staged helper before the run. The healthcheck route runs
its helper under `sudo`, so swapped code would run as root. Codex confirmed the takeover.

The fix in PR #53 (Read, `git diff 230954d 6c74583 -- scripts/remote_alpha_operator.sh`):

- **One leaf directly under /tmp.** The stage dir is now `<prefix>-<run id>` (for example
  `/tmp/execution-substrate-remote-alpha-vault-unseal-existing-<run id>`), a single name
  directly under `/tmp`. There is no longer a fixed parent that another account can own. All
  five routes do this (Ran: `grep` shows `${…STAGE_ROOT}-${run_id}`, no slash).
- **`mkdir -m 0700 --`, no `-p`.** A folder or link already at the name makes `mkdir` fail.
  The bootstrap and healthcheck routes make `scripts/` and `scripts/internal/` the same way.
- **Stop at the first failure.** Each prepare SSH and each `scp` ends in `|| return 1`, so a
  failed `mkdir` aborts the route before any copy or run.
- **Run-step private-folder check.** Before running the helper, each of the five run commands
  requires `[[ -d && ! -L && -O && -n "$(find … -maxdepth 0 -perm 0700 -print)" ]]`, and
  refuses otherwise, before the cleanup trap is set.
- **Owner-guarded cleanup.** The four cleanup heredocs `rm -rf` only a real folder the SSH
  user owns (`-d && ! -L && -O`).

No `mkdir -p` staging remains in the operator (Ran: `grep`). The one route that stages into
`/tmp` by another mechanism, ES TLS status, uses `/tmp/.es-tls-status-<32 hex uuid>` with an
unpredictable name and its own descriptor-based stage check, and the PR does not touch it
(Read; audit 22 section 2 says the same).

## 2. Probes with two real accounts (Ran; `25-evidence/pr53-probe.sh`, `pr53-probes.out`)

Sticky tmpfs on `/tmp`, overlay on `/etc`. `op` is the SSH user; `att` is another local
account. The probe runs the operator's own prepare body, its exact run-step predicate and its
exact cleanup predicate (lifted from `scripts/remote_alpha_operator.sh` at 6c74583). 12 of 12
passed.

| Group | Case | Result |
|---|---|---|
| Prepare | att pre-plants the stage name as a 0777 folder | `mkdir -m 0700` fails, the name stays att's, the route aborts, nothing is staged |
| Prepare | att pre-plants it as a symlink to an att folder | `mkdir` fails, the link is not followed, nothing staged |
| Prepare | att pre-plants a 0777 folder with `scripts/internal` inside (the old takeover shape) | `mkdir` fails, nothing staged |
| After clean prepare | att tries to write inside op's 0700 leaf | refused |
| After clean prepare | att tries to rename the leaf (sticky /tmp) | refused |
| After clean prepare | att tries to remove the leaf or swap the helper | refused; the real helper is intact |
| Run-step | op's own 0700 folder | would run |
| Run-step | op's own 0755 folder | refused |
| Run-step | att's 0700 folder | refused (not `-O`) |
| Run-step | a symlink to an att folder | refused |
| Cleanup | an att-owned 0777 folder with a `keep` file | left alone; `keep` survives |
| Cleanup | op's own folder | removed |

The old takeover (swap the internal helper that the public helper sources) is closed two ways:
the leaf is created fresh with `mkdir` so a planted name aborts the route, and once it exists it
is a 0700 op-owned folder under sticky `/tmp`, so att cannot enter it to place or swap
`scripts/internal/…`. The run-step check is a second line that only matters if `/tmp` is not
sticky or if op or root changed the folder (Inference, consistent with audit 22).

## 3. The healthcheck route specifically (Read)

The healthcheck TLS run command still ends in `if id -u == 0; then helper; else sudo helper`,
so its helper runs as root on the box. The same run-step private-folder check now sits in front
of that `sudo`, and its stage dir is a 0700 leaf made with `mkdir` under sticky `/tmp`. So the
one route where a swap would have reached root is covered by both the no-`-p` `mkdir` and the
run-step check. I built the takeover shape (0777 folder with `scripts/internal`) in the probe
and the prepare step refused it.

## 4. Every /tmp staging site (Read)

- The five vault and healthcheck routes: fixed, section 1.
- ES TLS status (`/tmp/.es-tls-status-<uuid>`): separate, descriptor-based, unpredictable name,
  unchanged by this PR.
- The Mac-side ES config/TLS and ES binary staging routes: already hardened in #50
  (`mkdir -m 0700`, no `-p`, plus the as-root artifact-folder check). PR #53 also added
  `|| return 1` to the ES binary upload-tree builder (audit I22-5), which only stops early on a
  failed local build; the validation step already refused an incomplete tree.
- No other operator route stages under a fixed `/tmp` name (Ran: `grep` of the stage roots).

## 5. Known or Info, not re-reported

- I22-1 / I10-4: a stage name is a route prefix plus the UTC second and the Mac-side PID, so
  another account can take a name and make that one run fail. That is a refusal, not a
  takeover, and it is the accepted behaviour.
- I22-4: the design rests on `/tmp` being sticky. The read-only box check
  `stat -c '%U:%G %a' /tmp` (expect `root:root 1777`) is row 6 of `box-checks.md`.
- RT-4 (Nomad port holder) is still in no PR.

## 6. Coverage this pass could not provide

- No systemd, no SSH, no real Vault: I exercised the operator's prepare, run-step and cleanup
  text directly as the two accounts, not the full Mac-to-box SSH orchestration. The healthcheck
  route's `sudo` to root is read, not run.
- I did not rerun the suite or the auditor's mutants; reports 22, 23 and 24 cover those, and CI
  on 6c74583 (per report 24) was still finishing when those were written, so the gate still
  needs it green.
- Nothing on the box.

## 7. Evidence

`25-evidence/` (hashes in `SHA256SUMS`): `pr53-probe.sh` (the probe, scratch only, never
pushed) and `pr53-probes.out`.
