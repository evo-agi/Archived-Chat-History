# PR #53: audit 22 follow-ups and sync with trunk_dev 230954d (report 23)

STATUS: pushed, ready for a delta check. Head `6c74583` = `4a1197e` (audit
follow-ups on the accepted `943abbb`) merged with trunk_dev `230954d` (#45).
CI on `943abbb` passed (job 138379007479); CI on `6c74583` started on push.
Codex thread resolved after audit 22 confirmed the fix.

## 1. Delta `943abbb` -> `4a1197e` (`23-evidence/delta-943abbb-4a1197e.diff`)

| Audit item | Change |
| --- | --- |
| I22-5 | `scripts/internal/remote_alpha_deploy_es_binaries.sh`: in `remote_alpha_deploy_es_binaries_stage_make_local_upload_tree` (called as `if ! …`) and `…_make_local_payload_tree` (called from it), every step but the last ends in `\|\| return 1`: the two `mkdir -p`, both `cp`, the toolchain check and both `go build`. The last step of each (the payload call, the provenance `python3` heredoc) already gives the function its status, so the `python3 -` line is untouched and does not collide with #52's `python3 -I` change. |
| I22-5 tests | New `scripts/remote_alpha_stage_es_binaries_upload_tree_test.go`. Behaviour: a failed copy (empty `REPO_ROOT`) stops the upload tree before the payload step; a failed toolchain check, first build or second build stops the payload tree (fake `go` logs each build target; no build after the failing one, no `build-provenance.json`). Static: the tree is still built as `if ! …`, and each of the 3 + 4 steps before the last ends in `\|\| return 1`. |
| I22-3 | `TestRemoteAlphaOperatorStageCleanupRemovesOnlyItsOwnFolder`: the foreign-folder case is now a subtest per cleanup tag that gives the folder to uid 65534 through `remoteAlphaOutputDirGive` (root directly, others through `sudo -n`, skip without either, give-back on cleanup), as #50's owner test does. The foreign folder is now `0777` with an empty `0755` `keep` inside, so only the `-O` check stops a non-root cleanup from removing it. |
| I22-4 | `box-checks.md` row 6: `stat -c '%U:%G %a' /tmp`, expect `root:root 1777`. |
| I22-1, I22-2 | Info only; no change. |

## 2. Sync with trunk_dev `230954d`

Git's own merge, no conflicts, no hand edits. #45 changed only
`artifact_hygiene_test.go`, `runbook_paths_docs_contract_test.go` and
`.docs/system_overview/artifact_hygiene.md`; none overlaps the PR. Merged tree
`9e4b5b6d…46cd` = `git merge-tree --write-tree 4a1197e 230954d`. No by-name
owner or mode line comes in from trunk_dev.

## 3. Runs on `6c74583`

| Run | Result |
| --- | --- |
| `ci`: operator stage/route tests, ES binary staging and deploy tests, output-dir tests, by-name and descriptor guards (213 pass lines) | all pass; the 4 foreign subtests skip (no sudo for `ci` here) |
| root, same selection, artifact folder absent | all pass, 4 foreign subtests run; 2 fail that also fail on `8789662` and earlier as root here (the bootstrap prepare-summary-path tests) |

## 4. Mutants (`23-evidence/mutants.log`)

| Mutant | Caught by |
| --- | --- |
| no return after the two `cp` | failed-copy case (one `cp` alone is caught only by the static test, as in I22-2) |
| no return after the toolchain check | failed-toolchain case |
| no return after the two builds | failed first and second build cases |
| no return after the payload `mkdir -p` | static step test |
| cleanup without `-O` (root run) | all 4 foreign subtests |

Non-root semantics of the I22-3 case, checked without sudo: as root I made a
`ci`-owned folder holding `foreign` (65534, 0777) with `keep` (65534, 0755),
then ran the unseal cleanup heredoc as `ci`. The real cleanup leaves `keep`
(owner 65534); the cleanup without `-O` removes it. So CI, which runs the
subtest through `sudo -n`, catches that mutant.

## 5. Manifest v2 against `230954d`

Tool sha `c08597e2…a3ca` checked before each run; two runs byte-identical.

- manifest_sha256 `e4e25eafcdd4ef9efc54c446dc83872d182ee0524a17ae75916d188d6b7ccfe9`
- textual_diff_sha256 `2233cb54985c7026ab73877be6d737fb8e3cf98156dc9f757000399a01571be6`
- 7 files. Against report 21's manifest: added
  `scripts/internal/remote_alpha_deploy_es_binaries.sh` and
  `scripts/remote_alpha_stage_es_binaries_upload_tree_test.go`; changed
  `scripts/remote_alpha_operator_stage_folders_test.go`; the other four
  entries are byte-identical.

Evidence: `23-evidence/` (delta diff, manifest json/out, mutants, test logs,
SHA256SUMS). Merge only on the coordinator's turn and the gate.
