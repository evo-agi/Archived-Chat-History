# PR #49: merge-turn sync with trunk_dev f058d8a, and #35's by-name lines (report 15)

STATUS: pushed, ready for a delta check. Head `3747650`. The coordinator
gave #49 its merge turn at 08:37Z after #35 merged as `f058d8a`. Merge only
after this check, green CI on `3747650` and the gate.

## Commits since the merge-checked 627b365

1. `3e41553`: merge of trunk_dev `f058d8a` (#35). Git's own clean merge
   (`.docs/system_overview/remote_supported_host_alpha.md` auto-merged; #35
   and #49 both edit it, in different places). Tree `4864e4ab…a6` =
   `git merge-tree --write-tree e8b834b f058d8a`. The PR's changed lines are
   the same file by file as at `627b365` (the doc's diff context differs,
   because #35 edited nearby).
2. `3747650`: the conversion below. Diff sha256
   `9824a760be3d5c82ad34d36188f8b070f1c7c3a607caa893ef720841de0be61e`
   (`15-evidence/conversion-3747650.diff`). This is a hand edit of code #35
   brought in, so it needs your delta check, not a byte check.

## Coordinator rule (c) applied to #35

On the merged tree the by-name guard failed: #35 added by-name owner or mode
lines to two scripts.

**`scripts/internal/remote_alpha_vault_workload_auth_bootstrap.sh`, 2 new
lines, not safe, converted.** The temporary-config step
(`TemporaryGenerateRootAccess`) rewrites Vault's configuration file (default
`/etc/vault.d/vault.hcl`) and later writes the original bytes back. It made a
temporary file with `mkstemp` in the file's folder, then called
`os.chown(temp_path, …)` and `os.chmod(temp_path, …)` by name, and it read the
file by name (`read_bytes()`) after an `lstat` check. The step must run as root
to write that file and reload Vault. The Vault account owns `/etc/vault.d` on
the box (box check 3 expects everything there except `vault.hcl` and
`vault.hcl.package-default` to be Vault's), so it can rename root's temporary
file and put a link in its place between `mkstemp` and the `chown`. Root would
then give any file, for example `/etc/shadow`, the owner and mode of
`vault.hcl` (`root:vault 0640` after the migration). The same swap between the
`lstat` and the read would make root copy a root-only file into `vault.hcl`,
which Vault can read.

Now:

- `_write` sets owner and mode with `os.fchown`/`os.fchmod` on the descriptor
  `mkstemp` returned, before `fsync` and `os.replace`. The rename stays by
  name; a swap there only puts the Vault account's own bytes in a file it
  already controls through the folder.
- A new `read_regular_file_no_follow(path)` opens with
  `O_RDONLY | O_NOFOLLOW | O_NONBLOCK | O_CLOEXEC`, refuses anything but a
  regular file by `fstat`, and reads from the descriptor. The preflight, the
  enable step (which now takes owner and mode from that `fstat`) and the
  restore check use it. A link or non-regular file still fails as
  `config_invalid` / `vault_config_not_a_regular_file`. A missing or
  unreadable file behaves as before.
- Docs: one sentence in the generate-root access bullets.

**`scripts/internal/remote_alpha_host_firewall.sh`, 7 lines, safe, allowance
added.** It runs as root only (`remote_alpha_host_firewall_require_root`). Its
`chmod`, `chown` and `install -d` lines act in `/etc/execution-substrate/host-firewall`
(`/etc/execution-substrate` is root's; the docs give the helper user only
execute ACLs on it), `/var/lib/es-host-firewall` and `/etc/systemd/system`,
and on `mktemp` files in those folders. One of the seven is the text of a
refusal ("sudo chown root:root and chmod 0644 it"). The reason is in the
comment above `byPathOwnershipChangeAllowance`. `remote_alpha_host_firewall.py`
changes no owner or mode.

## Tests

- `TestRootScriptByNameOwnershipChangesStayCounted`: the bootstrap stays at 1
  allowed line (the summary file, in the artifact folder #50 checks).
- `TestRedTeamFixedStepsChangeOwnersOnlyThroughDescriptors` gains a #35
  block: no by-name line in `TemporaryGenerateRootAccess`, `fchown`/`fchmod`
  on `handle.fileno()`, the no-follow read in enable, restore and preflight,
  and no `read_bytes(`, `os.lstat(` or `os.stat(` in the class.
- Mutants: chown/chmod by name back in `_write` fails both guards; `lstat` then
  `read_bytes()` back in enable fails the descriptor test. Neither is caught
  by the functional temporary-config tests, as expected for a race.

| Run on `3747650` | Result |
| --- | --- |
| `ci`: guards, all `VaultWorkloadAuthBootstrap` and `RemoteAlphaHostFirewall` tests | pass (64); real-Vault and real-kernel tests skip here and run in CI |
| root: temporary-config, guards, reset, ARS hardening | pass |

## Manifest v2

Tool sha `c08597e2…a3ca` checked before each run. HEAD reset `--mixed` to
`f058d8a`, two runs byte-identical:

- manifest_sha256 `5c9dbfe6a9218135f2315e4e65d9d1a650672edc63c67fd68aac9be969d1b727`
- textual_diff_sha256 `4616d1f26f2caabe6fd3757a6f9b840764f7ae22d39baad1294757c769d25fd2`
- file_count 8 (the 7 PR files plus the bootstrap script)
