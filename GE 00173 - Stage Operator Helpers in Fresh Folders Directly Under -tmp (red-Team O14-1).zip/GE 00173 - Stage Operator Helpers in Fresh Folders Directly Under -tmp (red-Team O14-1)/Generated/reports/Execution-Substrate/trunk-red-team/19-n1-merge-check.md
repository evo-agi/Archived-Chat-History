# ES PR #50: merge check of the sync with trunk_dev 3f1a84c (report 19)

```
Target:    evo-agi/Execution-Substrate PR #50, head fd4a0f494659ad12a2f2df039156c87ce26d846b,
           a merge of trunk_dev 3f1a84c (#49 squashed; also PR 12, #48, #35) into c3834f1,
           which byte check (2026-11-24 08:31Z) accepted on top of audit 10.
Asked by:  the PR's writer thread, 2026-11-24 09:33Z (report 18-n1-sync-3f1a84c.md).
Posture:   independent auditor thread. Read-only: nothing pushed, no PR comment, nothing on
           the Linux box. Real root, and the unprivileged account ci with two groups. Every
           test run used a private, empty /var/tmp.
Verdict:   ACCEPT. The merge is git's own, with no hand edits, and the PR's changed lines are
           the same as at c3834f1. In the five files both sides changed, every check still runs
           before the writes it covers, and trunk_dev added no new write into the artifact
           folder. The full scripts package shows no new failures as root or as ci. CI on
           fd4a0f4 must still pass.
```

Labels: **Ran** (I executed it and saw the result), **Read**, **Inference**.

## 1. The merge (Ran)

- Parents c3834f1 and 3f1a84c. Tree `e2ee4322feaccf7e34bf3a619d02f5f591dbd301`, the same as
  `git merge-tree --write-tree c3834f1 3f1a84c`.
- trunk_dev 3f1a84c has tree `f67e58e7…`, the tree of #49's head 3747650 that delta check 16
  accepted.
- The PR touches the same 22 paths. For each one, the changed lines (`git diff -U0`, `+` and
  `-` lines only) of 3f1a84c..fd4a0f4 equal those of a60c216..c3834f1. For the whole PR that
  hash is `d465ee35…` both times.
- Five of the 22 files also changed on trunk_dev: the overview doc, ARS hardening, the Vault
  migration, the Vault bootstrap and the Vault reset.

## 2. The five files both sides changed (Read)

The question for each is whether trunk_dev added a write into the artifact folder, or moved one
ahead of #50's check.

- **Bootstrap.** The check runs in `…_main` before `…_execute`, so before every summary write,
  including the one on #35's new signal path. #35 added no other write there; its
  temporary-config step writes in Vault's config folder, which delta check 16 covers.
- **Reset.** The check stays inside `summary_field`, just before the read of the workload-auth
  summary. #49's changes (moving the raft directory through descriptors, arguments parsed in
  `main()`) touch Vault's raft folder, not the artifact folder.
- **Migration.** The checks stay in `…_main` (summary folder; in apply, the preflight folder and
  the backup root) and before the final `mv`. Every write into the summary folder, including the
  drop-in's temporary file, runs inside the Python step that `…_main` starts after them. #49's
  additions are path refusals and owner changes in Vault's own folders.
- **ARS hardening.** #49's new state step works in the ARS state folder through descriptors.
  The summary checks are unchanged.
- **Doc.** Both sides' paragraphs are present; only context moved.

Also (Ran):
- The set of scripts under `scripts/` that name `/var/tmp` is the same 16 as at c3834f1.
- The new trunk scripts (host firewall) do not name it.

## 3. Manifest (Ran; `manifest/`)

v2 tool c08597e2…a3ca, branch `claude/remote-alpha-artifact-folder`, upstream
`origin/trunk_dev` = 3f1a84c, `git reset --mixed 3f1a84c`, two runs byte-identical:
**38eb7a7c3cffbfebbf404764bf7691353f7d5dca58de297267fbdeb3486a3220**, textual 031cf77e…f670,
22 files. This matches the writer's. Against the c3834f1 manifest the paths are the same, and
only the five files above have different entries.

## 4. Tests (Ran; `tests/`)

Full `scripts` package on exported trees of fd4a0f4 and 3f1a84c. Counts include subtests.

| Run | fd4a0f4 | 3f1a84c | New failures |
|---|---|---|---|
| root | 1895 pass, 260 fail, 11 skip | 1879 pass, 260 fail, 11 skip | none |
| ci with two groups | 1898 pass, 250 fail, 11 skip | 1884 pass, 250 fail, 9 skip | none |

- The failing tests are the same on both sides, as at 0330c5a: mostly ES service TLS status and
  P0t harness tests that fail in this container on trunk_dev too, plus the three tests that fail
  on any tree without `.git`.
- The 2 extra skips as ci are #50's two tests that need root or `sudo -n`, as in audit 10. CI has
  sudo, and as root both pass.
- On fd4a0f4, #50's tests, the call-site pin test, the copies test and #49's two guards all pass
  as root. As ci they pass too, apart from the two skips above.
- The real-Vault and real-SPIRE tests skip here on both sides. CI runs them.

## 5. CI (Read)

- The run on c3834f1 (45356269524) passed, 08:27:26Z to 09:04:32Z.
- The run on fd4a0f4 (45366317419) started at 09:33:25Z and was still running when this report
  was written. The gate needs it green.

## 6. Evidence

`19-evidence-auditor/` (hashes in `SHA256SUMS`):
- `manifest/`: both runs.
- `tests/`: full-package JSON for head and base, root and ci, the comparison and the runner.
