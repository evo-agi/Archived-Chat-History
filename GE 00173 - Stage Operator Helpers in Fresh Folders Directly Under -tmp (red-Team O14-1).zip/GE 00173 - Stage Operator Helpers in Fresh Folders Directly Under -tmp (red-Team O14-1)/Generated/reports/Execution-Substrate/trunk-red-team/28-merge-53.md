# PR #53 merged (report 28)

STATUS: merged. trunk_dev = `cacf5c127075ba22f5db4ff8ff5de9e2ca0db672`
(squash of #53, parent `ed94a6b`), 2026-11-24 ~15:50Z, on the coordinator's
merge turn (15:04Z).

| Gate item | Result |
| --- | --- |
| Head | `c950512` = the head sync check 27 accepted |
| CI "build, vet and test" on `c950512` | success (run 45421546411, job 138542097229), including "Listed tests pass as root" |
| trunk_dev before merge | `ed94a6b`, an ancestor of `c950512` |
| Mergeable | clean, not draft |
| Review threads | 1 (Codex P1), resolved after audit 22 confirmed the fix |
| Reviews | audit 22 ACCEPT (`943abbb`), delta check 24 ACCEPT (`6c74583`), red-team re-check 25 no bypass (`6c74583`), sync check 27 ACCEPT (`c950512`) |
| Merge | squash with expectedHeadSha `c950512` |
| After | tree of `cacf5c1` = tree of `c950512` = `b48380d2f43e1ae315fd4a6e70661954a2eab5b2` |

Box: row 6 of `box-checks.md` (`stat -c '%U:%G %a' /tmp`, expect
`root:root 1777`) waits for a box turn with the other read-only checks.
