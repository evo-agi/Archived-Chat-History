#!/usr/bin/env bash
# Verify the PR #50 artifact-folder check (remote_alpha_prepare_output_dir)
# refuses a folder a second account prepared, and accepts the box layout.
# The function under test is the PR's own unmodified canonical copy. A real
# second account (attacker, uid from useradd) prepares the folder; root runs
# the check with SUDO_UID set to a trusted operator. Private mount namespace
# with a fresh tmpfs on /var/tmp, so nothing outlives the run:
#   unshare --mount --propagation private bash probe.sh <repo>
set -euo pipefail
REPO=${1:?repo}
TMPDIR_ETC=$(mktemp -d)
[[ $(id -u) == 0 ]] || { echo "run as root inside unshare --mount" >&2; exit 2; }
mount -t tmpfs tmpfs /var/tmp && chmod 1777 /var/tmp
# Overlay /etc so the throwaway accounts never touch the host's /etc.
mkdir -p "$TMPDIR_ETC"/u "$TMPDIR_ETC"/w
mount -t overlay overlay -o "lowerdir=/etc,upperdir=$TMPDIR_ETC/u,workdir=$TMPDIR_ETC/w" /etc
groupadd --system att; useradd --system --gid att --home-dir /nonexistent --no-create-home --shell /usr/sbin/nologin att
groupadd --system op;  useradd --system --gid op  --home-dir /nonexistent --no-create-home --shell /usr/sbin/nologin op
AUID=$(id -u att); OUID=$(id -u op)
as_att() { setpriv --reuid att --regid att --clear-groups -- "$@"; }
DIR=/var/tmp/execution-substrate-remote-alpha
set +e
# A root-only victim the attacker tries to reach through a planted link.
install -d -o root -g root -m 0755 /etc/execution-substrate
( umask 077; printf 'SECRET\n' >/etc/execution-substrate/victim )

check() { # runs the check as root with SUDO_UID=OUID (a trusted operator)
  env -i PATH=/usr/bin:/bin SUDO_UID="$OUID" bash -c "source '$REPO/scripts/internal/remote_alpha_output_dir.sh'; remote_alpha_prepare_output_dir '$DIR'"
}
reset() { rm -rf "$DIR" "$DIR".* 2>/dev/null || true; }
verdict() { # $1 label ; $2 expect(refuse|pass)
  local out rc; out="$(check 2>&1)"; rc=$?
  if [[ $2 == refuse ]]; then
    if [[ $rc -ne 0 ]]; then echo "PASS  $1 -> refused: ${out#remote alpha output folder: }"; else echo "FAIL  $1 -> ACCEPTED (expected refusal)"; fi
  else
    if [[ $rc -eq 0 ]]; then echo "PASS  $1 -> accepted"; else echo "FAIL  $1 -> refused: ${out}"; fi
  fi
}

echo "== attacker owns the folder, 0777, with a link to a root file inside"
reset; as_att mkdir -m 0777 "$DIR"; as_att ln -s /etc/execution-substrate/victim "$DIR/summary.json"; verdict "attacker 0777 + planted link" refuse

echo "== attacker owns the folder, 0755"
reset; as_att mkdir -m 0755 "$DIR"; verdict "attacker-owned 0755" refuse

echo "== folder name is a link to a root directory"
reset; install -d -o root -g root -m 0755 /root/realdir 2>/dev/null || true; as_att ln -s /root/realdir "$DIR" 2>/dev/null || ln -s /root/realdir "$DIR"; verdict "folder name is a link" refuse

echo "== folder is root-owned but group/other writable (0757)"
reset; install -d -o root -g root -m 0757 "$DIR"; verdict "root-owned 0757 DIR" refuse

echo "== box layout: owned by the operator (SUDO_UID), 0750"
reset; install -d -o op -g op -m 0750 "$DIR"; verdict "operator-owned 0750 (box layout)" pass

echo "== box layout but group-writable (0770) -- audit N8"
reset; install -d -o op -g op -m 0770 "$DIR"; verdict "operator-owned 0770" refuse

echo "== the shared sticky folder itself given as the artifact folder (audit N2)"
out="$(env -i PATH=/usr/bin:/bin SUDO_UID="$OUID" bash -c "source '$REPO/scripts/internal/remote_alpha_output_dir.sh'; remote_alpha_prepare_output_dir /var/tmp" 2>&1)" && echo "FAIL  DIR=/var/tmp -> ACCEPTED" || echo "PASS  DIR=/var/tmp -> refused: ${out#remote alpha output folder: }"

echo "== clean first run: no attacker"
reset; check >/dev/null 2>&1 && stat -c 'PASS  clean run -> %U:%G %a %n' "$DIR" || echo "FAIL  clean run refused"

echo "== race: root removes and re-runs the check while the attacker plants a 0777 folder with a link"
reset
( for _ in $(seq 1 4000); do as_att mkdir -m 0777 "$DIR" 2>/dev/null && as_att ln -sf /etc/execution-substrate/victim "$DIR/summary.json" 2>/dev/null; done ) &
pl=$!
acc=0; ref=0; own_other=0
for _ in $(seq 1 300); do
  rm -rf "$DIR" 2>/dev/null || true
  if out="$(check 2>&1)"; then
    acc=$((acc+1)); o=$(stat -c '%u' "$DIR" 2>/dev/null || echo -1); [[ "$o" != 0 && "$o" != -1 ]] && own_other=$((own_other+1))
  else ref=$((ref+1)); fi
done
kill $pl 2>/dev/null || true; wait $pl 2>/dev/null || true
v=$(stat -c '%s' /etc/execution-substrate/victim); vb=$(cat /etc/execution-substrate/victim)
echo "race over 300 rounds: accepted=$acc refused=$ref; folders root did not own among accepts=$own_other; victim still: '$vb'"
