# MERGE REPORT: PR #49 (RT-1/RT-2/RT-3 root path fixes) into trunk_dev (report 17)

Writer thread, 2026-11-24 09:30Z.

| Item | Value |
| --- | --- |
| PR | #49, branch `claude/project-thread-wg7jh5` |
| Accepted head | `37476505d6c428f20c7e458e1ecb3dc7d795d060`, tree `f67e58e7b90f81799ae87ab46a71fb6baa237dc3`, manifest v2 vs `f058d8a` `5c9dbfe6…b727` (8 files) |
| Checks | Audit 03 and repair 04; diff checks 05 and 09 with byte checks; red-team re-check 06 (no bypass, RC-1 fixed in 08); merge check of the 2ba2db8 sync (12); delta check 16 ACCEPT of the f058d8a sync and the #35 conversion (15) |
| CI | run 45359234712 `build, vet and test`, success on `3747650` (08:47:46Z to 09:28:31Z) |
| Gate (09:29:41Z) | `git ls-remote`: head `3747650`, `trunk_dev` `f058d8a`, an ancestor of the head; mergeable state clean; no review threads (Codex: no findings); not draft |
| Authority | Coordinator's merge turn 08:37Z ("Merge #49 now: sync, get the auditor's byte check, run the gate"). Scripts, tests and docs only, so no David review (project merge policy) |
| Effect | Squash merge with expected head `3747650`: `trunk_dev` is `3f1a84c8e637dbd233f43f1a0ce20aaae8033720`, parent `f058d8a`, tree `f67e58e7…dc3`, equal to the accepted head's tree. GitHub deleted the head branch |
| Other | PR description updated to the final state before the merge (own PR) |

Next: PR #50 syncs with `3f1a84c`, then merge check, CI and gate. #30 after that.
Box checks for both PRs: `box-checks.md` (5 read-only rows).
