# ES PR #53: audit of the operator's /tmp staging folders (O14-1) at 943abbb (report 22)

```
Target:    evo-agi/Execution-Substrate PR #53, head 943abbb016717bf2aefef9a9032901e2b3792f3e,
           branch claude/operator-tmp-staging, base trunk_dev 8789662 (#50 merged; its tree
           e2ee4322 is the tree merge check 19 accepted).
Asked by:  the PR's writer thread, 2026-11-24 10:47Z (report 21-o14-operator-staging.md).
Posture:   independent auditor thread. Read-only: nothing pushed, no PR comment, Codex thread
           left for the writer, nothing on the Linux box. Real root; ci (uid 1500) as the SSH
           user; a real second account (uid 65534) as the other account on the host. Every run
           used a private, fresh /tmp or /var/tmp.
Verdict:   ACCEPT. The fix closes O14-1 and the Codex P1. On the base commit and on the PR's
           first fix, I took over the two routes whose public helper sources an internal
           helper, with a real second account; at 943abbb the same attack makes staging fail
           and nothing runs. Probes on all four staging routes found no way in. No new test
           failures as root or as ci. No findings; five Info notes, one of them a box check.
           CI on 943abbb must still pass.
```

Labels: **Ran** (I executed it and saw the result), **Read**, **Inference**.

## 1. What was wrong (Ran; `probes/exploit.out`)

On base 8789662 every route staged into `<fixed /tmp parent>/<run id>`, made with `mkdir -p`.
On 7217973, the PR's first fix, the parent was gone, but a failed `mkdir` did not stop the
route: the staging functions run inside `if ! f`, where Bash ignores `set -e` (Codex P1).

The two routes whose public helper sources an internal helper next to it (workload-auth
bootstrap, operator healthcheck TLS) can be taken over on both commits. The other account
leaves the SSH user's public helper in place, so the run step's `chmod 0700` of it still works,
and swaps only the internal helper. The run step's `chmod 0600` of that file fails, but it ends
in `|| true`. The public helper finds the internal one with `cd "$(dirname "${BASH_SOURCE[0]}")"
&& pwd`, which does not resolve links.

| Commit | What the other account did | Result |
|---|---|---|
| 8789662 | made the fixed parent 0777 first; after staging, moved the SSH user's private leaf aside and put a new leaf in its place, linking to the user's own public helper and holding its own internal helper | its internal helper ran, both routes |
| 7217973 | made the stage folder (and `scripts/internal`) 0777 first; staging "succeeded"; it replaced the internal helper | its internal helper ran, both routes |
| 943abbb | the same as for 7217973 | staging failed at `mkdir`; nothing was copied or run |

In the probe a fake `sudo` runs the helper as ci. On the box the healthcheck route runs it
through `sudo`, so the other account's code would run as root (Inference from the code).

## 2. The change (Read)

- **Stage folder.** `<prefix>-<run id>` directly under `/tmp`, made with `mkdir -m 0700 --` and
  no `-p`; `scripts/` and `scripts/internal/` the same way inside it. A planted folder or link
  at the name makes `mkdir` fail.
- **Stopping.** Each of the 4 staging functions ends every SSH and copy step in `|| return 1`.
  The callers run the cleanup and return 1.
- **Run step.** Each of the 5 run commands first requires a real folder (`-d`, `! -L`) that the
  SSH user owns (`-O`) with mode exactly 0700 (`find -maxdepth 0 -perm 0700`), and refuses
  otherwise. The check comes before the cleanup trap, so a refused folder is left alone.
- **Cleanup.** The 4 cleanup heredocs remove the folder only when it is a real folder the SSH
  user owns.

**Why it holds (Inference from the rules above).**
- `/tmp` is sticky. Once the SSH user's `mkdir` succeeds, only that user or root can rename or
  remove the folder.
- Mode 0700 keeps everyone else out of what is inside.
- So between staging and the run no other account can change what runs. The run-step check is
  a second line that matters only if `/tmp` is not sticky, or if the SSH user or root changed
  the folder.

Other places I checked:
- The ES TLS status route (`/tmp/.es-tls-status-<32 hex>`) already works through descriptors
  and is unchanged.
- No other operator route stages under a fixed `/tmp` name.
- The doc paragraph matches the code.
- The by-name count for the operator falls from 14 to 10: four staging `chmod` lines are gone.

## 3. Probes at 943abbb (Ran; `probes/probes.out`)

All four staging routes (bootstrap, unseal, reset, healthcheck), each in a fresh mount
namespace with a sticky tmpfs on `/tmp`. Fake `ssh` and `scp` run the route's own functions
locally, extracted from the operator unchanged.

| Case | Result, all 4 routes |
|---|---|
| C1: nobody interferes | staged, the helper ran, the folder was removed |
| C2: the other account made the stage folder (0777, with `scripts/internal`) first | `mkdir` failed ("File exists"); nothing copied, nothing ran; the planted folder kept |
| C3: after staging, the other account tries to replace a helper, rename, chmod, write into or remove the folder | every attempt refused; the SSH user's helper ran |
| C4: a link at the stage name | `mkdir` failed; the link and its target untouched |

## 4. Manifest (Ran; `manifest/`)

v2 tool c08597e2…a3ca, branch `claude/operator-tmp-staging`, upstream `origin/trunk_dev` =
8789662, `git reset --mixed 8789662`, two runs byte-identical:
**59dc8d0598be842a044ff993ef56a4632b98a7d01fbaf19e963bc6f16a6f3145**, textual f536dd3c…5129,
5 files. Byte-identical to the writer's JSON. `21-evidence/SHA256SUMS` verifies.

## 5. Tests (Ran; `tests/`)

Full `scripts` package and the root package, on exported trees of 943abbb and 8789662. Counts
include subtests.

| Run | 943abbb | 8789662 | New failures |
|---|---|---|---|
| `scripts`, root | 1919 pass, 260 fail, 11 skip | 1895 pass, 260 fail, 11 skip | none |
| `scripts`, ci with two groups | 1922 pass, 250 fail, 11 skip | 1898 pass, 250 fail, 11 skip | none |
| root package, root | 601 pass, 3 fail | 601 pass, 3 fail | none |
| root package, ci | 601 pass, 3 fail | 601 pass, 3 fail | none |

- The failing tests are the same on both sides: this container's usual set, plus the three
  that fail on any tree without `.git`.
- The 6 new tests and the two guards pass, as root and as ci (18 subtests).
- The root package holds the docs contract tests, so the new doc paragraph breaks no pinned
  sentence.

## 6. Mutants (Ran; `mutants/`)

Each mutant changes the operator on the 943abbb tree, at every place the rule appears. Run: every
`TestRemoteAlphaOperator…` test and the two guards.

Kills are counted against an unmutated run of the same tests. 22 operator tests fail in this
container without any mutant: the TLS status routes, the P0v facade and the byte-stable matrices. As root, two
bootstrap prepare tests also fail on base and head.

| Mutant | ci with two groups (as CI runs) | root | Caught by |
|---|---|---|---|
| M1: `mkdir -p -m 0700` for the stage folder | killed | | name-taken route test, planted-folder test, layout pin |
| M2: run-step mode test `-perm -0700` (at least 0700) | killed | | not-private route test ("open" cases), static test |
| M3: run step without `-O` | static only | static only | static test; see I22-2 |
| M4: cleanup without `-O` | survived | killed | cleanup test, root-only subtest; see I22-3 |
| M5: healthcheck internal copy without `\|\| return 1` | static only | | static test; see I22-2 |
| M6: run-step check after the cleanup trap | static only | | static test; see I22-2 |
| M7: run step without `! -L` | static only | | static test; the `find` mode test refuses a link too |

The writer's mutants (`21-evidence/mutants.log`) cover the `|| return 1` on the preparation
steps, the run-step check, its mode test, the link test and the pre-fix operator. I did not rerun
them.

## 7. Codex thread (Read, Ran)

The P1 ("Propagate staging SSH failures before copying helpers") is real: section 1 shows the
takeover on 7217973. It is fixed at 943abbb: `|| return 1` on every step, plus the run-step
check. The thread is still open on GitHub; the writer can resolve it. I do not write to GitHub.

## 8. Info (no change needed)

- **I22-1. Stage names can be guessed.** A name is the route prefix plus the UTC second and
  the Mac-side process id. Another account can take a name and make that run fail. That is a
  refusal, not a takeover, as with I10-4 for #50.
- **I22-2. Some rules are pinned only by the static test:** the run step's `-O` and `! -L`, the
  check's place before the trap, and `|| return 1` on each copy. With `/tmp` sticky, and staging
  stopping at a failed `mkdir`, no other account can reach the run step with a folder that
  would get past them (Inference). So the static pin fits.
- **I22-3. The cleanup's owner test is exercised only as root.** CI runs unprivileged, so CI
  would not see it dropped. Without it, cleanup would empty a planted folder the SSH user can
  write into. Such a folder holds only the other account's own files, and the sticky bit keeps
  the folder itself. Optional: run that subtest through `sudo -n`, as #50's owner test does.
- **I22-4. One more read-only row for `box-checks.md`, for a later box turn:**
  `stat -c '%U:%G %a' /tmp`. Expect `root:root 1777`. The design rests on `/tmp` being sticky.
- **I22-5. The same `if ! f` pattern, outside this PR.** In ES binary staging,
  `remote_alpha_deploy_es_binaries_stage_make_local_upload_tree` (Mac side, in a fresh
  `mktemp -d`) does not stop at a failed `mkdir`, `cp` or `go build`. The step right after it,
  `…_validate_local_upload_tree`, refuses a tree with a missing file, so this has no effect
  (Read). It could get the same `|| return 1` in a later tidy-up.
- **CI (Read).** The run on 943abbb (45375034505) started at 10:28:15Z and was still running
  when this report was written. The gate needs it green.

## 9. Evidence

`22-evidence-auditor/` (hashes in `SHA256SUMS`):
- `manifest/`: both runs.
- `probes/`: the extracted functions for 943abbb, 7217973 and 8789662, the fake commands and
  helpers, the probe scripts and their output.
- `tests/`: full-package JSON for head and base, root and ci, both packages; the comparison and
  the runner.
- `mutants/`: `mutants53.py.txt`, the runner and the results.
