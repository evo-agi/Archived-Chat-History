# ES PR #53: delta check of the audit 22 follow-ups and the sync with trunk_dev 230954d (report 24)

```
Target:    evo-agi/Execution-Substrate PR #53, head 6c7458382f83c5ef381acf3628a2eed1d0a813a5:
           4a1197e (follow-ups on 943abbb, which audit 22 accepted) merged with trunk_dev
           230954d (#45).
Asked by:  the PR's writer thread, 2026-11-24 11:12Z (report 23-o14-audit-followups.md).
Posture:   independent auditor thread. Read-only: nothing pushed, no PR comment, nothing on
           the Linux box. Real root, and the unprivileged account ci with two groups. Every
           test run used a private, empty /var/tmp.
Verdict:   ACCEPT. The follow-ups do what audit 22 asked and change nothing else. The operator
           script and the other three files audit 22 covered have the same changed lines as at
           943abbb. The merge is git's own, and #45 touches none of the PR's files. No new test
           failures as root or as ci. CI on 6c74583 must still pass.
```

Labels: **Ran** (I executed it and saw the result), **Read**, **Inference**.

## 1. Commits and merge (Ran)

- 4a1197e has one parent, 943abbb. `git diff 943abbb 4a1197e` has sha256 `f89a4126…349e`, the
  same as the writer's `delta-943abbb-4a1197e.diff`. It changes 3 files:
  - the ES binary deployment script (+11 −6);
  - the stage-folder test file;
  - a new test file for the ES binary upload tree.
- 6c74583 has parents 4a1197e and 230954d. Its tree `9e4b5b6d…46cd` is the same as
  `git merge-tree --write-tree 4a1197e 230954d`.
- #45 changes only `artifact_hygiene_test.go`, `runbook_paths_docs_contract_test.go` and
  `.docs/system_overview/artifact_hygiene.md`. None of them is a PR file.
- For the operator script, the doc, the operator route test file and the guard test file, the
  changed lines (`git diff -U0`, `+` and `-` only) of 230954d..6c74583 equal those of
  8789662..943abbb.

## 2. The follow-ups (Read)

- **I22-5 (ES binary upload tree).** In `…_make_local_upload_tree` and `…_make_local_payload_tree`,
  every step but the last now ends in `|| return 1`:
  - the two `mkdir -p` and the two `cp`;
  - the toolchain check and the two `go build`.

  The last step of each (the payload call, the provenance `python3` heredoc) still gives the
  function its status. Nothing else in the script changes.
- **I22-5 tests.** The behaviour test fakes `go` and overrides one function at a time. It shows:
  - a failed copy stops the upload tree before the payload step;
  - a failed toolchain check, first build or second build stops the payload tree, with no later
    build and no `build-provenance.json`.

  The static test counts the steps and requires the return on each.
- **I22-3 (cleanup owner rule in CI).** The foreign-folder case is now a subtest per cleanup.
  - It gives the folder to uid 65534 through `remoteAlphaOutputDirGive`: as root directly,
    otherwise through `sudo -n`, as #50's owner test does. It gives the folder back at cleanup.
  - The folder is 0777 with an empty 0755 `keep` inside. So for a non-root run only the `-O`
    check keeps cleanup from removing it.
  - CI has passwordless sudo, so the subtest runs there. Here, as ci, it skips.
- **I22-4.** `box-checks.md` row 6 is the `/tmp` check I suggested.

## 3. The cleanup rule without root (Ran; `probes/hand.out`)

I built the subtest's layout by hand: a ci-owned folder holding `foreign` (uid 65534, 0777)
with `keep` (uid 65534, 0755). Then I ran each of the four cleanup heredocs from 6c74583 as ci,
with and without `-O`.

| Cleanup | With `-O` | Without `-O` |
|---|---|---|
| unseal, reset, bootstrap, healthcheck (ES service TLS) | `keep` kept | `keep` removed |

So the subtest, run through `sudo -n` in CI, catches the loss of `-O`. As root it runs directly
(section 4).

## 4. Tests (Ran; `tests/`)

Full `scripts` package and the root package, on exported trees of 6c74583 and 230954d. Counts
include subtests.

| Run | 6c74583 | 230954d | New failures |
|---|---|---|---|
| `scripts`, root | 1929 pass, 260 fail, 11 skip | 1895 pass, 260 fail, 11 skip | none |
| `scripts`, ci with two groups | 1928 pass, 250 fail, 15 skip | 1898 pass, 250 fail, 11 skip | none |
| root package, root | 607 pass, 0 fail, 1 skip | 607 pass, 0 fail, 1 skip | none |
| root package, ci | 607 pass, 0 fail, 1 skip | 607 pass, 0 fail, 1 skip | none |

- The failing tests are the same on both sides: this container's usual set.
- The 4 extra skips as ci are the four new foreign-folder subtests, which need root or `sudo -n`.
  As root all four run and pass.
- The PR's tests all pass as root and as ci: the stage and route tests, the two upload-tree tests
  and the two guards.
- #45 made the root package pass on a tree without `.git`; it shows no failures here on either
  side.

## 5. Manifest (Ran; `manifest/`)

v2 tool c08597e2…a3ca, branch `claude/operator-tmp-staging`, upstream `origin/trunk_dev` =
230954d, `git reset --mixed 230954d`, two runs byte-identical:
**e4e25eafcdd4ef9efc54c446dc83872d182ee0524a17ae75916d188d6b7ccfe9**, textual 2233cb54…71be6,
7 files. Byte-identical to the writer's JSON.

Compared with audit 22's manifest:
- two entries are new (the ES binary script and the new test file);
- one changed (the stage-folder test file);
- the other four are identical.

## 6. Mutants (Ran; `mutants/`)

Each mutant drops one or more of the new returns on the 6c74583 tree. Run: the two new upload-tree
tests, as ci.

| Mutant | Result | Caught by |
|---|---|---|
| E1: no return after the toolchain check | killed | behaviour ("failed toolchain check") and static test |
| E2: no return after the first build | killed | behaviour ("failed first build") and static test |
| E3: no return after the second build | killed | behaviour ("failed second build") and static test |
| E4: no return after either copy | killed | behaviour ("failed copy") and static test |
| E5: no return after the first copy only | killed | static test only |
| E6: no return after the payload `mkdir -p` | killed | static test only |
| E7: no return after the upload `mkdir -p` | killed | static test only |

E5 to E7 are caught only statically. That is the same standing as I22-2. These steps run in a
fresh local `mktemp -d`, and the validation step after the tree still refuses a missing file.

The writer's root run of the cleanup mutant (`23-evidence/mutants.log`) matches section 3. I did
not rerun it.

## 7. CI (Read)

- The run on 943abbb passed (job 138379007479).
- The run on 6c74583 (45381803647) started at 11:11:01Z and was still running when this report
  was written. The gate needs it green.
- The writer resolved the Codex thread after audit 22 confirmed the fix.

## 8. Evidence

`24-evidence-auditor/` (hashes in `SHA256SUMS`):
- `manifest/`: both runs.
- `probes/`: the four cleanup heredocs with and without `-O`, the hand check and its output.
- `tests/`: full-package JSON for head and base, root and ci, both packages; the comparison and
  the runner.
- `mutants/`: `mutants23.py.txt`, the runner and the results.
