# PR #53: operator /tmp staging folders (red-team O14-1), with the Codex fix (report 21)

STATUS: ready for audit. Head `943abbb`, base trunk_dev `8789662`. Branch
`claude/operator-tmp-staging`. Scripts, tests and docs only; no box run. CI
"build, vet and test" was running on `943abbb` when this was written.

PR: https://github.com/evo-agi/Execution-Substrate/pull/53

## 1. What it fixes

Red-team re-check 14 (`14-redteam-pr50.md`, section 5), observation O14-1:
the operator's Vault unseal, Vault reset (dry run and execute), workload-auth
bootstrap and operator healthcheck TLS routes staged their helpers in
`<fixed /tmp parent>/<run id>`. The parent was made with `mkdir -p`, the leaf
got a separate `chmod`. Another account could make the fixed parent first,
own it, and swap the staged helper before the run. The healthcheck route runs
its helper through `sudo`. Pre-existing; #50 did not touch these routes.

## 2. Change (`scripts/remote_alpha_operator.sh`)

| Part | Before | After |
| --- | --- | --- |
| Stage folder | `<root>/<run id>` with `mkdir -p` + `chmod` | `<root>-<run id>` directly under `/tmp`, `mkdir -m 0700 --` and no `-p` (and `scripts/`, `scripts/internal/` the same way for bootstrap and healthcheck) |
| Staging functions (4) | prepare SSH and copies ran in `if ! f` context, where Bash ignores `set -e` | each SSH and copy step ends in `\|\| return 1` |
| Run commands (5) | ran the helper from whatever was at the path | first `[[ -d && ! -L && -O && -n "$(find … -maxdepth 0 -perm 0700 -print)" ]]`, else refuse with "the staged helper folder is not a private folder of this user; not running it"; the check sits before the cleanup trap, so a refused folder is not removed |
| Cleanup heredocs (4) | `rm -rf` of the path | `rm -rf` only when `-d && ! -L && -O` |

The run-step check uses Bash tests and `find -perm`, not GNU `stat -c`, so it
reads the same with GNU and BSD tools.

`scripts/remote_alpha_root_service_paths_test.go`: the operator's by-name
owner/mode count falls 14 -> 10 (the four staging `chmod` lines are gone; the
run-step check sits on lines that already held a `chmod`, so the count does
not move).

Doc: one paragraph in `.docs/system_overview/remote_supported_host_alpha.md`
after the artifact folder invariant.

## 3. Codex finding (P1, comment 4678515865) and the fix in `943abbb`

Codex: the staging functions are called inside `if ! …`, so a failed
preparation SSH was followed by both copies, and a successful last copy made
staging succeed; the healthcheck route would then run a helper through sudo
from a tree someone else made. The tests only ran the heredocs on their own.

Confirmed. It was also hiding in the route tests: the fake hosts had no
`/tmp`, so with no `-p` the preparation step failed in every route test, and
the fake `scp` made the parent with `mkdir -p`, so the routes still passed.
Fixed by the `|| return 1` steps and the run-step check above. The fake hosts
now get a `/tmp` (sticky, 0777) through `mkdirFakeRemoteAlphaHostTmp`.

Reply posted on the thread; the thread is left unresolved for the audit.

## 4. Tests (`scripts/remote_alpha_operator_stage_folders_test.go`)

- `TestRemoteAlphaOperatorStageFoldersSitDirectlyUnderTmp`: layout pin.
- `TestRemoteAlphaOperatorStagingRefusesAPlantedStageFolder`: each prepare
  heredoc fails on a planted link or folder, leaves both as they were, makes
  0700 folders on a free name.
- `TestRemoteAlphaOperatorStageCleanupRemovesOnlyItsOwnFolder`: own folder
  removed, link and its target kept, foreign-owned folder kept (root only).
- `TestRemoteAlphaOperatorStagingStopsAtTheFirstFailedStep` (new): each of the
  4 staging functions is called as `if ! f`, has 1 SSH and 1 or 2 copy steps,
  each ending in `|| return 1`; each of the 5 run commands has the exact check
  before `trap cleanup EXIT` and before `"${helper_path}"`.
- `TestRemoteAlphaOperatorRoutesStopWhenTheStageNameIsTaken` (new, 6 routes:
  unseal, reset dry run, reset execute, bootstrap, healthcheck status,
  healthcheck renew): a wrapper plants a 0777 folder at the stage name just
  before the preparation SSH. The route fails, no copy happens, no helper
  runs, no run step reaches SSH.
- `TestRemoteAlphaOperatorRoutesRefuseAStageFolderThatIsNoLongerPrivate` (new,
  same 6 routes x 2): after the copy, a wrapper opens the stage folder (0755)
  or replaces it by a link to the moved folder. The route fails with the
  refusal message and no helper runs.
- `remote_alpha_operator_test.go`: the four fake harnesses call
  `mkdirFakeRemoteAlphaHostTmp`; the five route tests check for leftover
  stage folders by the new names.

## 5. Mutants (evidence `21-evidence/mutants.log`, script `mutants.sh`)

Run as `ci` on the working tree that became `943abbb` (only a test-file
header comment and the doc sentence changed after the runs).

| Mutant | Caught by |
| --- | --- |
| no `\|\| return 1` on the 4 prepare SSH steps | name-taken (6/6 routes), static test |
| no `\|\| return 1` on the 6 copies | static test |
| no run-step check | not-private (12/12), static test |
| run-step check without the mode test | not-private "open" (6/6), static test |
| no `! -L` in run-step check and cleanup | cleanup test, static test (the `find` mode test also refuses a link, so the "linked" route cases still pass) |
| operator from `7217973` (before the Codex fix) | name-taken 6/6, not-private 12/12, static test |

The four mutants from the first round (old staging step, old parent layout,
cleanup without ownership check, cleanup removing nothing) were caught before
this fix and the tests that catch them are unchanged.

## 6. Full suites, head `943abbb` vs base `8789662` (`21-evidence/suite-compare.txt`)

| Run | Head fail / pass | Base fail / pass | Fail only at head |
| --- | --- | --- | --- |
| `ci` (uid 1500) | 244 / 2540 | 253 / 2507 | none |
| root, artifact folder moved aside | 251 / 2540 | 263 / 2504 | none |

All failures at head also fail at base (this container's usual set: no
Docker/Nomad, the ES TLS status collector tests, the 4 fake-GID migration
tests and 2 bootstrap prepare tests as root). The base-only failures come
from the base copy's 0664 file modes (for example "local runtime mode=0664,
want 0644"), not from this change. All new tests, the route tests, the
by-name count guard and the descriptor guard pass at head as `ci` and as
root.

## 7. Manifest v2 against `8789662`

Tool sha `c08597e2…a3ca` checked before each run; two runs byte-identical.
Upstream pinned to `origin/trunk_dev` for the run.

- manifest_sha256 `59dc8d0598be842a044ff993ef56a4632b98a7d01fbaf19e963bc6f16a6f3145`
- textual_diff_sha256 `f536dd3c3f32904b66ee88f552912a3ee427f48f5d007ab415dd06ff1e285129`
- 5 files: the overview doc, `scripts/remote_alpha_operator.sh`,
  `scripts/remote_alpha_operator_stage_folders_test.go` (new),
  `scripts/remote_alpha_operator_test.go`,
  `scripts/remote_alpha_root_service_paths_test.go`

Evidence: `21-evidence/` (manifest json/out, mutants, suite script, suite
comparison, SHA256SUMS).

## 8. For the auditor

- Is the run-step check enough as a second line, given `/tmp` is sticky and
  only the owner (or root) can rename the stage folder after `mkdir`?
- The run-step check covers only the top folder; `scripts/` and
  `scripts/internal/` sit inside a 0700 folder of the SSH user, so only that
  user or root can touch them.
- Merge only on the coordinator's turn and the gate.
