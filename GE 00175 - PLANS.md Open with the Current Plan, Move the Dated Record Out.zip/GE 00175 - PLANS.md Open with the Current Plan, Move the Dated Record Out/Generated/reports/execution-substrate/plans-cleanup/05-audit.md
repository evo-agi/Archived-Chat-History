# ES PR #55 (PLANS.md cleanup): fresh independent re-audit 05

Written 2026-11-24 by a fresh, read-only audit thread that wrote no part of the patch and no earlier audit of it. Nothing was pushed, committed, commented on or merged.

**Verdict: ACCEPT.** At d0dd883 the moved text is the original text, unchanged except for the 16 link prefixes. Everything that moved is dated status or selection history, or a superseded route record, and no current rule depends on it alone. The coordinator's A02-5 rule (the record is historical evidence with no current authority, and `PLANS.md` or the owning contract wins) is stated with one meaning in four places, and tests pin each statement. All 26 mutants that break a stated guard rule fail the intended test. The R6J exception matches one whole line exactly once. Base and head give identical per-test results in every package whose tests read the changed files, and CI on d0dd883 is green. There are no blocking or low findings, only four observations (A05-1 to A05-4). One of them is new: a fence-tracking flaw in the heading guard.

## INDEPENDENT AUDIT REPORT

**Repository / audit target**

- `evo-agi/Execution-Substrate`, draft PR #55, branch `claude/project-thread-kumrhu`.
- Topic commit `d0dd8836de2a5023d0ab6100485666647fd2d120`, tree `b22036c42c1fd29659cdbb380899594e9380c906`. Commits since the base: `bf4f5d6` and `d0dd883`.
- Base `trunk_dev` `16cbf739eea8c6a673aef8048aefb69cebd5121b`. At closeout `origin/trunk_dev` was still 16cbf73 and the PR branch was still d0dd883.
- Recipe `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified on the shared file and on the copy that ran).
- Canonical manifest SHA-256 `aa926a4174209e432a1f64515762a5796e6c45e2afc0b7ecc49ead58c6f361bd`, textual diff SHA-256 `0fb5067648b530531cb7f9ab3e0e9f1ebc69f4ab31eb43d0fe8bdeb2ebaf69d7`, 8 paths (6 modified, 2 added).

**Audit posture.** Read-only. Parent only, no subagents. Fresh clones and worktrees under `/opt/audit` in a cloud container. Tests ran as an unprivileged `ci` user with Go 1.26.5 (the go.mod toolchain), `GOTOOLCHAIN=local`, `GOFLAGS=-mod=readonly`, and no ignored signals. Shared-folder writes: this report, `05-audit-manifest.json`, `05-audit-mutants.py` and `05-audit-check-preserve.py`.

I formed the view below from the code, the split script and the writer's reports (01, 03) before I read audit 02's findings or re-audit 04. Where I differ from 04, I say so under "Comparison with re-audit 04".

**Provenance reproduction.** I followed provenance §5.3 in a fresh clone: tip check, ancestry check, clean status, `reset --mixed` to the base, upstream `origin/trunk_dev`, then v2 twice into a fresh 0700 directory. `cmp` showed the two runs identical, and `cmp` showed them byte-identical to the writer's `03-expected-manifest.json`. A closing run, repeating the whole sequence (status clean including ignored files), equals the opening one. There were no mode-bit differences.

**Coverage**

- The full diff 16cbf73..d0dd883 of all 8 files, and `split_plans.py` (SHA-256 `ddfcb2e3…64d5`, matches report 03), read before running it.
- Docs: AGENTS.md §3 and "After changes", README "Supporting references", the claim ledger's changed rows, the record's header, `PLANS.md`'s note and its new headings, and the owning contracts for the record's current-sounding sentences.
- Tests: `plans_docs_contract_test.go` in full, and the changes to `docs_contract_test.go` and `caller_authentication_docs_contract_test.go`.
- Not inspected: product code (none changed) and the content of the 23 Status entries beyond spot checks. Audit 02 checked the writer's 7 flagged entries and the Nomad entry against their owners, and 04 searched all record sections for identifiers found nowhere else.

## What I checked, and the result

### 1. Content preserved verbatim

- **The script reproduces the PR exactly.** Run with `python3 -I` on 16cbf73's `PLANS.md` (SHA-256 `1e4cd2d2…0fde`), `split_plans.py` writes a `PLANS.md` and a record that are byte-identical (`cmp`) to the PR's files at d0dd883 (SHA-256 `937817d4…4dbc` and `0b135667…0561`). It reports 16 rebased link targets.
- **An independent check agrees.** I did not rely on the script's own assertions. I wrote `05-audit-check-preserve.py`, which reads the three files straight from git and checks:
  - 0 original non-blank lines are missing from the two outputs.
  - The 48 added non-blank lines are all declared new text: the record header (19 lines), its P0 parent section (6), the `PLANS.md` note (19) and the 4 new headings.
  - Every record line that differs from the original differs only by `](` becoming `](../../`. There are 16 such lines.
  - Order is kept. Consecutive original lines stay adjacent in the outputs except at exactly 12 cut points, and each cut point is one of the script's planned range boundaries.

### 2. Only self-declared history moved

What moved, from 16cbf73's `PLANS.md`:

- lines 3–663, the `## Status` log of 23 dated entries;
- lines 664–799, five dated selection sections (2026-11-17 and 2026-11-18);
- lines 2299–2371 (P0n) and 2786–2852 (P0r). Both open "The following records the former … rationale only. It grants no current operator route…".

Checks on the sections next to the cuts:

- The preamble (800–865) stays, under a new heading. It is current text that PR #54 last edited.
- P0g (2079–2098) stays. Its section also states the current P0h retirement, and an existing test reads it.
- The three new route headings match their content. The P0 labels found in each range are only P0i–P0m, P0o–P0q and P0s–P0v. Range 2853–3838 also holds one P0q mention in passing.

Current-sounding sentences in the moved selections, each traced to a current owner:

| Sentence in the record | Current owner |
|---|---|
| "Paired-root proof is an active Bounded slice rule pending integrated review" | PLANS.md:2152; `.docs/execution_lifecycle/contracts.md:16` |
| "Archived v1 claims are a Temporary compatibility edge" | PLANS.md:928 and following |
| the six existing-host helper routes are "fixed effect-free tombstones" | PLANS.md:180 |
| the execution/placement snapshot rule, and "Artifact, capability, target, and profile errors precede placement errors" | `.docs/execution_lifecycle/contracts.md:14` |
| "Reliable submit remains unavailable and runtime-unwired" | PLANS.md:1378 |
| private codec-3 custody as a bounded slice rule, limited to `synthetic_nonoperational_v1` (found only in the moved lines 680–751) | `.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:5` and following |
| the A1 original-key read cleanup owner rule | `reliable_submit_persistence_and_concurrency.md:350` |

One section's self-description is weaker than the PR says (A05-1).

### 3. Link rebasing is the only change to the record

- **The record's body.** Apart from its header and the P0 parent section, the record's lines equal the original lines, except for the 16 rebased lines.
- **The 16 links.** They go to two targets: `.docs/execution_lifecycle/contracts.md` (2 links) and `.docs/execution_lifecycle/reliable_submit_operational_handoff.md` (14 links). Both files exist.
- **No other relative links.** The moved text has no in-page `](#…)` anchors (which would now point inside the record), no link titles, no angle-bracket targets and no reference definitions. The only `<…>` text is placeholders in inline code.

Other changed files:

- The claim ledger's citations change from line ranges to two section links. At 16cbf73, its `PLANS.md:329-421` citation pointed into a PR #12 Status entry. The two named sections contain what each row cites: the Milestone 0 claim freeze, the stable semantic contracts including ES admission composition, and the temporary compatibility edges including `control-plane-normal-shell/v1`.

### 4. The A02-5 decision, stated consistently

The rule is that the record is historical evidence and holds no current authority, and that where it differs, `PLANS.md` or an owning contract wins.

- **Record header:** "It is historical evidence and holds no current authority. Where it differs from `PLANS.md` or from an owning `.docs/` contract, they win."
- **`PLANS.md` note:** "historical evidence only: it holds no current authority, and where it differs from this file or from an owning `.docs/` contract, they win."
- **AGENTS.md §3, "Additional rules":** the same rule, plus "It is not part of the read-first path". The numbered hierarchy lines 1–5 are unchanged.
- **README:** "historical evidence with no current authority". It does not repeat the "they win" clause, but its meaning is the same, and AGENTS.md says README is not design authority.

Each statement is pinned by a test: mutants M13 (the note), M14 (AGENTS.md) and M15 (README) fail, and the record is pinned by its SHA-256. No text in the tree contradicts the rule. `.docs/history/` falls under neither hierarchy rank 3 nor rank 4, so the move gives the record no rank by accident.

### 5. The guards fail on violations (mutation test)

`05-audit-mutants.py` ran in a clean ci-owned clone at d0dd883. For each mutant it edited files, ran `git add -A` (the repo-wide guards list files through git), ran the 7 `TestPlans*` tests plus `TestMarkdownRelativeLinksResolve` and `TestCallerAllowlistPrefixRuleIsDocumentedOnce`, then reset and cleaned.

**All 26 intended violations fail the intended test:**

| Mutant | Fails |
|---|---|
| M01 `## Status`, M06 `## Status Update`, M25 `## Status ##`, M26 3-space `## Status`, M05 setext "Recent status" | NoDatedStatusEntries |
| M02 heading with an ISO date | NoDatedStatusEntries |
| M03 line opening with an ISO date, M04 `- **2026-11-25**` list item | NoDatedStatusEntries |
| M07 R6J line duplicated, M23 indented copy, M24 copy with trailing text, M08 R6J line reworded, M22 R6J line removed | NoDatedStatusEntries |
| M09 +8,000 bytes | StaysWithinItsSizeCap (the control M10, +7,000 bytes, passes) |
| M11 one byte of the record changed | RecordIsClosed |
| M12 a new top-level section before the objective | OpensWithTheCurrentPlan |
| M13 the note's authority sentence reworded | OpensWithTheCurrentPlan |
| M14 AGENTS.md rule reworded, M15 README reference removed | RecordIsNamedWhereAgentsStart |
| M16 the undated P0n heading put back in `PLANS.md` | RecordIsClosed (heading in both files) |
| M17 `PLANS.md:120` in a `.docs` file, M18 "line 40" in a new git-added file, M19 `#L12` in a shell script, M20 range cell in the claim ledger | IsCitedBySectionNotLine |
| M21 one record link un-rebased | MarkdownRelativeLinksResolve and RecordIsClosed |

After the last mutant, the clean tree passed again.

**Limit probes, which pass as the writer said such forms would:**

- L1 "On 2026-11-25, PR #56 …";
- L2 `## Progress log`;
- L3 `## Changes in November 2026`;
- L5 `11/25/2026: …`;
- L4, a fence-toggle construction that hides a real `## Status` heading. This one is a flaw in how the guard tracks fences, not a scope choice (A05-2).

### 6. The pinned R6J exception is narrow

- `plansDatedLineExceptions` holds one entry: `**2026-11-13 Review-22 development-source disposition:**`.
- It is at PLANS.md:1525 at d0dd883, and it was already in 16cbf73's `PLANS.md` once, inside the current ADR pointer's R6J text. `docs_contract_test.go:13364` uses it as a section boundary, so rewording it is out of this PR's scope.
- It matches only the whole trimmed line, exactly once. A reworded copy (M08), a copy with trailing text (M24), a duplicate (M07), an indented duplicate (M23) and removal (M22) all fail. So the exception cannot hide a new dated line, and it cannot go stale silently.

### 7. Tests on the exact head

Run on clean checkouts (`git status` empty) of 16cbf73 and d0dd883, as user `ci`, with `go test -count=1 -timeout 45m -json . ./internal/testutil ./scripts`. These are the three packages whose tests read the changed files. A grep of every `_test.go` shows no other package reads `PLANS.md`, AGENTS.md, the root README.md, the claim ledger or the record.

| Package | Base 16cbf73 (top-level tests) | Head d0dd883 (top-level tests) |
|---|---|---|
| `.` (root) | ok: 166 pass | ok: 173 pass. The extra tests are exactly the 7 `TestPlans*` tests |
| `./internal/testutil` | ok: 6 pass | ok: 6 pass |
| `./scripts` | FAIL: 415 pass, 15 skip, 30 fail | FAIL: 415 pass, 15 skip, 30 fail |

- **Per-test comparison.** Over all 2,910 base results, including subtests, the head has 0 verdict changes, 0 tests missing and exactly 7 added tests.
- **`./scripts` failures are the environment, not the patch.** The 30 failing tests are the same set on base and head. They are Remote Alpha TLS-status, operator facade, P0t grammar-diagnostic and upgrade-script tests. None is on CI's environment-only list, so CI's green "Test" step ran them on this head. Inference: they fail here because of container limits, since they fail identically without the patch. All 10 `./scripts` docs tests that read `PLANS.md` pass on both. `TestRemoteAlphaHostFirewallRealKernelApplyConfirmRollback` skips itself on both, since it was not run as root.
- **Build and vet.** `go build ./...`, `go vet ./...` and `GOOS=darwin GOARCH=arm64 go vet ./...` on the head: clean. `gofmt -l` on the 3 changed Go files: no output.
- **CI on the exact head.** Run 45481975034 ([link](https://github.com/evo-agi/Execution-Substrate/actions/runs/45481975034)), event `pull_request`, `head_sha` `d0dd8836de2a5023d0ab6100485666647fd2d120`, conclusion `success`, completed 21:15:23Z, read through the GitHub API. That run covers every package, including the root-only step. Base and trunk_dev are the same commit, so the merge commit CI tested has the head's tree.

## Findings

No patch defect blocks this PR. There are no low or higher findings, only four observations.

```text
AUDIT FINDING
ID / Type / Severity: A05-1 / report-only uncertainty (description accuracy) / observation
Current contract or strategic target: "Moved ... only text that calls itself history" (PR #55 description; report 01 item 1: "the others say 'At selection' or 'Historical'")
Path and line / Evidence: 16cbf73 PLANS.md:715-743, "## Post-PR #9 source publication and A1 read cleanup selection (2026-11-18)". It opens "PR #8 completed development acceptance…". It has a dated heading and status-shaped content, but no "Historical" or "At selection" marker.
Impact: none on the bytes. Its current statements have owners: A1 cleanup at reliable_submit_persistence_and_concurrency.md:350, codec-3 custody at the same document's :5, and refusal of structural reliable requests at PLANS.md:1386. Under A02-5 those owners win. Only the description overstates.
Required correction: none to the code. Optional: describe the moved set as "dated status and selection history, and superseded route records".
Uncertainty: low.
Patch defect or pre-existing issue: description wording of this patch. Not raised in audit 02 or re-audit 04.
```

```text
AUDIT FINDING
ID / Type / Severity: A05-2 / test gap (guard implementation) / observation
Current contract or strategic target: TestPlansHoldsNoDatedStatusEntries reads "CommonMark headings ... outside fences" (report 03)
Path and line / Evidence: plans_docs_contract_test.go, markdownHeadingTitles. fenceLine (^ {0,3}(```|~~~)) toggles inFence on any fence-like line, whatever opened the fence. In CommonMark, a fence closes only on the same character, at least as long as the opener, with no info string. Probe L4, "```" / "~~~" / "```" followed by "## Status", passes the guard, although CommonMark renders the heading. L1, L2, L3 and L5 (see section 5) are scope limits, as report 03 says.
Impact: a deliberate construction can hide a status or dated heading. An honest edit would not hit this. The AGENTS.md rule and the 320,000-byte cap (7,408 bytes of headroom) remain the backstop. The guard is a heuristic against regrowth, not a security boundary.
Required correction: none for this PR. If the coordinator wants it, a small follow-up can track the opening fence's character and length, and close only on a matching bare fence.
Uncertainty: low (reproduced).
Patch defect or pre-existing issue: patch (new test code). Not found in audit 02 or re-audit 04.
```

```text
AUDIT FINDING
ID / Type / Severity: A05-3 / test gap / observation
Current contract or strategic target: TestRemoteAlphaOperatorP0oDocsVaultWorkloadAuthBootstrapPlanningBoundary (the current P0o planning boundary)
Path and line / Evidence: the test asserted "not ES Vault token brokerage" in PLANS.md. At 16cbf73 that phrase stood only at PLANS.md:2351, inside P0n's superseded record, not in P0o's current text. At d0dd883, docs_contract_test.go:9131-9136 reads it from the record, whose SHA-256 is pinned. The added comment says so plainly.
Impact: the assertion is now frozen-true and checks no current P0o text. That was already true in substance before the move. The move only made it visible.
Required correction: none for this PR. Optional, as a separate decision: state the boundary in the current P0o section or its owning doc and point the assertion there, or drop it on purpose.
Uncertainty: low.
Patch defect or pre-existing issue: pre-existing.
```

```text
AUDIT FINDING
ID / Type / Severity: A05-4 / doc gap / observation
Current contract or strategic target: the new AGENTS.md rule, "update PLANS.md ... by editing the section that states them; do not add a dated status entry"
Path and line / Evidence: .docs/execution_lifecycle/reliable_submit_operational_handoff.md:1652 ("Owner precedence and source status") and reliable_submit_persistence_and_concurrency.md:1938 ("Report verified source phase"). Both are implementation-plan tables that list PLANS.md for source status.
Impact: compatible with editing in place, but a reader could take them as an invitation to add status entries. No guard catches status prose inside a section (A05-2 limits).
Required correction: none for this PR. These could be aligned in the planned follow-up on where the P0i–P0v and R6J text should live.
Uncertainty: medium (a reading question).
Patch defect or pre-existing issue: pre-existing.
```

**Merge-gate note (same as A04-2):** branches `claude/project-thread-9slgp8` and `claude/project-thread-qhn13c` will conflict on `PLANS.md`. The PR description gives the resolution for each.

## Comparison with re-audit 04

I read 04 (SHA-256 `07c38623…8a75`) only after forming the view above.

- **Agreed:** provenance, verbatim preservation, the A02-1 to A02-5 repairs, the R6J exception, the heading rename, ACCEPT.
- **Added:**
  - A05-1. 04 relied on audit 02's classification, which named Post-PR #10 and the 2026-11-17 sections but not Post-PR #9.
  - A05-2, the fence-tracking flaw, which is distinct from 04's scope limits (A04-1).
  - A05-3 and A05-4, both pre-existing.
  - My test comparison covers the whole `./scripts` package on base and head as an unprivileged user. 04 ran the root package as root, plus the 10 `./scripts` tests that read `PLANS.md`.
- **Protocol:** 04 was not a fresh thread, as it said itself. This audit is the fresh one that operating protocol §14 asks for.

## Validation assessment

- **Re-run:** the provenance (opening and closing), the split script, my own preservation check, 31 mutants, and the package runs in section 7. Also `go build ./...`, `go vet ./...`, `GOOS=darwin GOARCH=arm64 go vet ./...` and `gofmt -l` on the 3 changed Go files (results in section 7).
- **Not re-run locally:** the other packages' tests (es/app integration with Nomad, Docker, Vault and SPIRE; es/admission bindfs tests), and the root-only `./scripts` tests. No file they read changed: the only test-file hits in es/admission and es/app write their own fixture README.md files. CI covers them all on d0dd883.

## Sensitive-material handling

None read or written.

## Remaining uncertainty and stop conditions

- Prose that appears only in the record was not checked exhaustively. 04's identifier search and my sentence-level trace of the selection sections found no current rule that lives only in the record. Inference: none exists. A full sentence-by-sentence owner map of the 23 Status entries would confirm it.
- No stop condition was hit.

## Confidence

- Provenance: high.
- Validation: high, from identical base and head results locally, plus green CI on the exact head.
- Implementation: high. Guard completeness: medium-high (A05-2).

## Effect status

No repair, commit, push, PR comment or merge was performed.

## Report delivery

`/mnt/project-files/reports/execution-substrate/plans-cleanup/05-audit.md`. Its SHA-256 is given in the thread reply.

**Final verdict: ACCEPT**
