# ES PR #55 (PLANS.md cleanup): re-audit 04 of the audit-02 repair

Written 2026-11-24 by the audit thread that wrote audit 02. Read-only: nothing was pushed, committed, commented on or merged.

**Verdict: ACCEPT.** A02-1 through A02-5 are all fixed at d0dd883, and the fixes are correct. The pinned guard exception and the heading rename are sound. The root package passes in full on the exact head, and every intended guard violation is caught. No finding is blocking. CI on d0dd883 passed: run 45481975034, check "build, vet and test", conclusion success at 21:15:23Z.

## INDEPENDENT AUDIT REPORT

**Repository / audit target**

- `evo-agi/Execution-Substrate`, draft PR #55, branch `claude/project-thread-kumrhu`
- Topic commit `d0dd8836de2a5023d0ab6100485666647fd2d120`, tree `b22036c42c1fd29659cdbb380899594e9380c906`
- Commits since the base: `bf4f5d6` (audited in 02) and `d0dd883` (the repair)
- Base `trunk_dev` `16cbf739eea8c6a673aef8048aefb69cebd5121b`. At closeout, `git ls-remote` showed neither trunk_dev nor the PR branch had moved.
- Recipe `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified)
- Canonical manifest SHA-256 `aa926a4174209e432a1f64515762a5796e6c45e2afc0b7ecc49ead58c6f361bd`, textual diff SHA-256 `0fb5067648b530531cb7f9ab3e0e9f1ebc69f4ab31eb43d0fe8bdeb2ebaf69d7`. 8 paths: 6 modified and 2 added, the same paths as in audit 02. Saved as `04-audit-manifest.json`.

**Audit posture.** Read-only. Parent only, no subagents. I worked in fresh clones under `/opt/audit`. Shared-folder writes: this report, `04-audit-manifest.json` and `04-audit-mutants.py`.

Observation, protocol: operating protocol §14 asks for a fresh audit thread after a repair. The coordinator sent this re-audit to the thread that wrote audit 02. Independence from the writer holds, since this thread never wrote any of the patch. The difference is only that the auditor is not fresh, so I re-checked everything that could have changed, not only the 02 findings.

**Provenance reproduction.** I followed §5.3 in a fresh clone: tip check, ancestry check, clean status, `reset --mixed` to the base, upstream `origin/trunk_dev`, then v2 run twice. `cmp` showed the two runs identical. The output is byte-identical (`cmp`) to the writer's `03-expected-manifest.json`. A closing run equals the opening one. No mode-bit differences.

**Coverage.**

- The full `bf4f5d6..d0dd883` repair diff (5 files).
- The record re-derived through a chain:
  - audit 02 proved bf4f5d6's record body verbatim;
  - at d0dd883, the 944 body lines differ from bf4f5d6's in exactly 16 lines;
  - each of the 16 differs only by `](` becoming `](../../`;
  - no unprefixed relative link remains.
- The updated `split_plans.py` (SHA-256 `ddfcb2e3…64d5`, matches report 03). Run with `python3 -I` on 16cbf73's PLANS.md, it reproduces the tip's PLANS.md and record byte for byte. It reports 16 rebased link targets.
- PLANS.md versus bf4f5d6: 13 changed lines. They are the rewrapped note and the one heading rename, nothing else.
- Not re-inspected: content that is unchanged since audit 02 (the moved and kept classification, the 13 repointed tests, the claim ledger). Audit 02's conclusions on those still apply.

## Findings from audit 02

| Finding | Status at d0dd883 | Evidence |
|---|---|---|
| A02-1 broken record links (high) | **Fixed** | `TestMarkdownRelativeLinksResolve` passes on the committed tree. Mutant N11 (one prefix removed) makes it fail again, and `TestPlansRecordIsClosed` fails too. The record is not exempted from the link test. The header says the link prefix is the only change. |
| A02-2 guard gaps (low) | **Fixed** | All 8 audit-02 probes (S1–S8) now fail the intended guard. A new self-test, `TestPlansGuardsFindEachKindOfProblem`, pins the refused and allowed forms. |
| A02-3 byte counts (nit) | **Fixed** | Comment says 312,592; `wc -c` gives 312,592 for PLANS.md and 62,826 for the record; the script prints bytes. |
| A02-4 "newest first" (nit) | **Fixed** | Header says "in the order they stood at the top of `PLANS.md`", pinned by a test. |
| A02-5 authority (coordinator's decision) | **Implemented as decided** | See below. |

**A02-5 implementation.** The coordinator decided that the record is historical evidence only, and that PLANS.md or an owning contract wins on conflict. That rule is now stated, with the same meaning, in four places:

- AGENTS.md §3 "Additional rules", line 37;
- the record header;
- the PLANS.md note;
- the README reference.

Tests pin each statement (mutants N7–N10). The numbered hierarchy lines 1–5 are unchanged, and 11 docs copy them under test. Putting the rule in "Additional rules" fits the hierarchy: it ranks the record below everything, which needs no new numbered line.

Search for wording that now contradicts the rule: `keeps the standing`, `moved verbatim`, `newest first` and `Current Bounded Implementation Status` each have 0 hits in the tree.

Because "no current authority" would demote any rule that lives only in the record, I widened audit 02's owner check to all 31 record sections. It looked for backticked identifiers that appear nowhere else in the repo's docs, code, scripts or CI. Only historical commit and digest values are unique to the record. The three other hits come from line wraps in identifiers that exist elsewhere. Inference: no named surface depends on the record alone. Prose-level uniqueness was not checked exhaustively; audit 02 spot-checked the 7 flagged entries and the Nomad entry against their owners.

## Pinned guard exception (R6J dated line)

- `plansDatedLineExceptions` holds exactly one line: `**2026-11-13 Review-22 development-source disposition:**` (PLANS.md:1525 at d0dd883).
- The line was already in 16cbf73's PLANS.md, exactly once, inside the R6J text of the "Cross-Repo Hybrid Integration ADR Pointer", which stays current. Nearby text points at it ("the 2026-11-13 development-source disposition below").
- Moving or rewording it would change current content, which is outside this PR's scope.
- The exception matches only the whole trimmed line, exactly once. Rewording it (N1) or duplicating it (N2) both fail the guard. So the exception cannot hide a new dated line, and it will not go stale silently.
- Verdict: sound.

## Heading rename

- "Document Scope And Current Bounded Implementation Status" became "Document Scope And Current Implementation".
- Reason: the new status-heading rule refuses any title ending in "status". The heading is new in this PR (audit 02 named it as a new name), so nothing outside the PR used it. The old name has 0 hits in the tree.
- The self-test pins the new name as allowed, along with the domain heading "Remote Alpha TLS status, renewal and diagnostic routes (P0s to P0v)".
- The section still opens with the authoritative-planning sentence. Its content is unchanged.
- Verdict: sound.

## New findings

No patch defects. Observations only, with no correction required:

- **A04-1, guard scope (observation).** Beyond the stated intent, these forms still pass:
  - N3, a blockquote line opening with a date;
  - N4, an undated `### PR #56 …` heading;
  - N5, a table row opening with a date;
  - N6, a date mid-sentence (allowed by design, since current text uses dates in prose);
  - N13, a table cell with a single line number (allowed by design, to avoid matching years).

  The AGENTS.md rule and the 320,000-byte cap (7,408 bytes of headroom) are the backstop, and report 03 states that limit plainly. If wanted later, one cheap tightening is available: no current PLANS.md heading names a PR, so `PR #N` in a heading could be refused. That is optional and does not block this PR.
- **A04-2, merge-gate note.** Branches `claude/project-thread-9slgp8` and `claude/project-thread-qhn13c` will conflict on PLANS.md, as reported in 01 and 03. The PR description carries the resolution.

## Mutation results (`04-audit-mutants.py`, clean clone, reset between mutants, clean at the end)

Each run covers the 7 `TestPlans*` tests plus `TestMarkdownRelativeLinksResolve`.

| Mutant | Result |
|---|---|
| Audit-02 set M1–M9 (status heading, dated heading, over cap, record edit/append, `:N` and `#LN` citations, plan order, AGENTS/README rule, moved heading back, intro rule) | each fails the intended guard. M3b (exactly 320,000 bytes) passes, which is the correct boundary |
| S1–S8 (the audit-02 survivors) | each fails the intended guard |
| N1 pinned line reworded / N2 duplicated | NoDatedStatusEntries |
| N7 AGENTS authority / N8 README authority | RecordIsNamedWhereAgentsStart |
| N9 record authority | RecordIsClosed |
| N10 PLANS note authority | OpensWithTheCurrentPlan |
| N11 one record link unprefixed | MarkdownRelativeLinksResolve + RecordIsClosed |
| N12 `PLANS.md (lines 12-20)` in a Go comment | IsCitedBySectionNotLine |
| N14 numbered list item opening with a date | NoDatedStatusEntries |
| N3, N4, N5, N6, N13 | pass (A04-1) |

Unmutated: all 8 pass.

## Validation assessment

Run on a clean checkout of d0dd883 (`git status` empty), as root, `umask 022`, `LANG=en_US.UTF-8`, go1.26.5 from go.mod, signals reset:

- `go test -count=1 -json .`: package pass, 615 of 615 tests pass.
  - Against base 16cbf73 (608 of 608 pass in audit 02), the head adds exactly the 7 `TestPlans*` tests.
  - No test disappeared.
  - `TestMarkdownRelativeLinksResolve` passes.
- `./scripts`, the 10 tests that read PLANS.md: 9 pass. `TestRemoteAlphaHostFirewallRealKernelApplyConfirmRollback` fails, exactly as on base. It needs `ip` netns as root and is listed as skips-itself.
- `./internal/testutil`: ok.
- `go vet .` and `GOOS=darwin GOARCH=arm64 go vet .`: ok.
- `gofmt -l` on the 3 changed Go files: clean.
- Not run locally: the other packages. No Go file outside the root package changed, and audit 02 showed by grep that no other package's tests read the changed docs.

## CI

- bf4f5d6, run 45478624802: **cancelled** at 20:33:19Z during "Test", when d0dd883 was pushed. Every earlier step passed, including build, vet, vet for macOS and the test-gate check. A02-1 never reached a CI result.
- d0dd883, run 45481975034, job 138757392113, check "build, vet and test": **success**. Started 20:33:25Z and completed 21:15:23Z, with head_sha `d0dd8836de2a5023d0ab6100485666647fd2d120` (read through the GitHub API). Every step succeeded:
  - build;
  - vet, and vet for macOS;
  - the test-gate check;
  - "Test" (the full suite), 20:36:59Z to 21:01:30Z;
  - "Listed tests still fail";
  - "Listed tests pass as root".

## Sensitive-material handling

None read or written.

## Remaining uncertainty

- Prose-only uniqueness in the record was not checked exhaustively (see A02-5).

## Confidence

- Provenance: high.
- Validation: high, local and CI.
- Implementation: high. Guard completeness: medium-high (A04-1).

## Effect status

No repair, commit, push, PR comment or merge was performed.

**Final verdict: ACCEPT**
