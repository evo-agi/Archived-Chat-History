# ES PLANS.md cleanup: merge note 06

Status: merged. Written 2026-11-24 by the writer thread.

## Merge

- PR: https://github.com/evo-agi/Execution-Substrate/pull/55, squash-merged into `trunk_dev`.
- Merge commit: `8129b82d79b5700049621b6d4e95b6bf37ada7ac`, parent `16cbf739eea8c6a673aef8048aefb69cebd5121b`.
- Merged tree `b22036c42c1fd29659cdbb380899594e9380c906` equals the audited head `d0dd8836de2a5023d0ab6100485666647fd2d120`'s tree. The diff from 16cbf73 touches exactly the 8 manifest paths.
- `trunk_dev` is now `8129b82`.

## Merge gate (provenance §5.4)

- Audit: re-audit 05, ACCEPT at `d0dd883` (`05-audit.md`), v2 manifest canonical `aa926a4174209e432a1f64515762a5796e6c45e2afc0b7ecc49ead58c6f361bd`.
- Head unchanged: `origin/claude/project-thread-kumrhu` = `d0dd883`, checked just before the merge, and the merge call pinned `expectedHeadSha`.
- Base unchanged: `origin/trunk_dev` = `16cbf73`, checked just before the merge.
- CI: "build, vet and test" green on `d0dd883` (run 45481975034).
- Policy: docs/tests-only PR, which merges without David after audit and gate.
- Post-merge bytes: tree identity confirmed above.

## Observations from audit 05 (recorded in the merge commit message)

- **A05-1**: the Post-PR #9 entry has no "Historical" marker, so "moved only text that calls itself history" overstates that entry. It is a dated status entry and belongs in the record.
- **A05-2**: the fence guard toggles on any fence line without matching the opening fence's character and length, so a mixed fence can hide a heading. Deferred to the follow-up PLANS.md step.
- **A05-3**: the P0o "not ES Vault token brokerage" assertion reads the closed record and is frozen true. Pre-existing weakness.
- **A05-4**: the plan tables in `reliable_submit_operational_handoff.md` and `reliable_submit_persistence_and_concurrency.md` still list `PLANS.md` as a source for status. Pre-existing.

## Follow-ups (for the coordinator)

- The follow-up PLANS.md step: where the P0i–P0v route rules (about 100 KB) and the R6J review history (about 60 KB) should live, plus the A05-2 fence fix.
- Branches `claude/project-thread-9slgp8` (part 2b) and `claude/project-thread-qhn13c` will conflict on `PLANS.md`. Resolve by editing the current section in place and putting dated text in the PR description.

## Codex review

Marking the PR ready started a Codex code review on `d0dd883`. It finished at 21:39:42Z with no findings, before the merge at about 21:40Z.
