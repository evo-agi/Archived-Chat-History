import subprocess, sys, json, os, re
MUT = '/opt/audit/mut2'
GUARDS = ['TestPlansGuardsFindEachKindOfProblem','TestMarkdownRelativeLinksResolve','TestPlansOpensWithTheCurrentPlan','TestPlansHoldsNoDatedStatusEntries','TestPlansStaysWithinItsSizeCap','TestPlansRecordIsClosed','TestPlansRecordIsNamedWhereAgentsStart','TestPlansIsCitedBySectionNotLine']
def sh(*a, **k): return subprocess.run(a, cwd=MUT, capture_output=True, text=True, **k)
def rd(p): return open(os.path.join(MUT,p), encoding='utf-8').read()
def wr(p,s): open(os.path.join(MUT,p),'w',encoding='utf-8').write(s)
def app(p,s): wr(p, rd(p)+s)
def pad_to(n):
    s = rd('PLANS.md'); add = n - len(s.encode())
    wr('PLANS.md', s + 'x'*(add-1) + '\n')
def sub(p,a,b):
    s = rd(p); assert a in s, (p,a); wr(p, s.replace(a,b,1))
M = {
 'M1_status_heading': lambda: app('PLANS.md','\n## Status\n\nPR #56 did a thing.\n'),
 'M2_dated_heading': lambda: app('PLANS.md','\n### PR #56 follow-up (2026-11-25)\n\nText.\n'),
 'M3_over_cap_320001': lambda: pad_to(320001),
 'M3b_at_cap_320000': lambda: pad_to(320000),
 'M4_record_edit': lambda: sub('.docs/history/plans-record.md','Nothing in it was reworded.','Nothing in it was reworded!'),
 'M4b_record_append': lambda: app('.docs/history/plans-record.md','\n### New entry\n'),
 'M5_colon_citation': lambda: app('README.md','\nSee PLANS.md:12 for details.\n'),
 'M5b_anchor_citation': lambda: app('.docs/mvp.md','\nSee PLANS.md#L12.\n'),
 'M6_section_before_objective': lambda: sub('PLANS.md','## Current Planning Objective','## Recent Changes\n\nx\n\n## Current Planning Objective'),
 'M6b_rename_decision_rules': lambda: sub('PLANS.md','## Current Decision Rules','## Decision Rules'),
 'M7_agents_rule_removed': lambda: sub('AGENTS.md',"- `.docs/history/plans-record.md`, the closed dated record",'- The closed dated record'),
 'M7b_readme_link_removed': lambda: sub('README.md','- [.docs/history/plans-record.md](.docs/history/plans-record.md) for','- the record for'),
 'M8_moved_heading_back': lambda: app('PLANS.md','\n## Superseded Remote Alpha Operator Facade Routes\n\nx\n'),
 'M9_intro_rule_removed': lambda: sub('PLANS.md','Do not add dated status','Avoid adding status'),
 'S1_body_dated_entry': lambda: app('PLANS.md','\n**2026-11-25 status:** PR #56 changed the submit path.\n'),
 'S2_current_status_heading': lambda: app('PLANS.md','\n## Current Status\n\nPR #56 did a thing.\n'),
 'S3_setext_status_heading': lambda: app('PLANS.md','\nStatus\n------\n\nPR #56 did a thing.\n'),
 'S4_indented_status_heading': lambda: app('PLANS.md','\n  ## Status\n\nPR #56 did a thing.\n'),
 'S5_nonISO_dated_heading': lambda: app('PLANS.md','\n### PR #56 follow-up (25 Nov 2026)\n\nText.\n'),
 'S6_table_line_citation': lambda: app('README.md','\n| `PLANS.md` | `329-421` |\n'),
 'S7_lines_word_citation': lambda: app('README.md','\nSee `PLANS.md` lines 12-20.\n'),
 'S8_go_comment_citation': lambda: app('docs_contract_test.go','\n// see PLANS.md:12\n'),
 'N1_pinned_line_reworded': lambda: sub('PLANS.md','**2026-11-13 Review-22 development-source disposition:**','**2026-11-13 Review-22 development source disposition:**'),
 'N2_pinned_line_duplicated': lambda: app('PLANS.md','\n**2026-11-13 Review-22 development-source disposition:**\n'),
 'N3_blockquote_dated': lambda: app('PLANS.md','\n> 2026-11-25 PR #56 changed submit.\n'),
 'N4_undated_pr_heading': lambda: app('PLANS.md','\n### PR #56 durable admission repair\n\nPR #56 changed submit.\n'),
 'N5_table_dated_row': lambda: app('PLANS.md','\n| 2026-11-25 | PR #56 changed submit |\n'),
 'N6_mid_sentence_date': lambda: app('PLANS.md','\nOn 2026-11-25 PR #56 changed submit.\n'),
 'N7_agents_authority_changed': lambda: sub('AGENTS.md','they win.','PLANS.md wins.'),
 'N8_readme_authority_removed': lambda: sub('README.md','it is historical evidence with no current authority, so ',''),
 'N9_record_authority_changed': lambda: sub('.docs/history/plans-record.md','holds no current authority','holds current authority'),
 'N10_plans_note_authority_changed': lambda: sub('PLANS.md','it holds no current authority','it holds current authority'),
 'N11_record_link_unprefixed': lambda: sub('.docs/history/plans-record.md','](../../.docs/execution_lifecycle/contracts.md)','](.docs/execution_lifecycle/contracts.md)'),
 'N12_go_comment_lines_citation': lambda: app('docs_contract_test.go','\n// see PLANS.md (lines 12-20)\n'),
 'N13_table_single_number': lambda: app('README.md','\n| `PLANS.md` | `329` |\n'),
 'N14_dated_numbered_item': lambda: app('PLANS.md','\n1. 2026-11-25 PR #56 changed submit.\n'),
}
names = sys.argv[1:] or list(M)
results = {}
for name in names:
    assert sh('git','checkout','-q','--','.').returncode == 0
    assert sh('git','status','--porcelain').stdout == ''
    M[name]()
    r = sh('go','test','-count=1','-json','-run','^('+'|'.join(GUARDS)+')$','.', env={**os.environ,'LANG':'en_US.UTF-8'})
    res = {}
    for l in r.stdout.splitlines():
        try: e = json.loads(l)
        except Exception: continue
        if e.get('Test') in GUARDS and e.get('Action') in ('pass','fail','skip'): res[e['Test']] = e['Action']
    failed = sorted(k for k,v in res.items() if v=='fail')
    results[name] = {'failed': failed, 'ran': len(res)}
    print(name, 'ran', len(res), 'FAILED:', failed or 'none (survived)', flush=True)
sh('git','checkout','-q','--','.')
print('clean' if sh('git','status','--porcelain').stdout=='' else 'DIRTY')
json.dump(results, open('/opt/audit/mutants/results2.json','w'), indent=1)
