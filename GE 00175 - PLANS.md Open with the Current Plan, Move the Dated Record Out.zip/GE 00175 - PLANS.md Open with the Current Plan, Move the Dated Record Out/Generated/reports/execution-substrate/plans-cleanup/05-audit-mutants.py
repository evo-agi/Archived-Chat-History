"""Audit 05 mutants for ES PR #55 guards. Run as ci in a clean worktree at d0dd883.
Each mutant edits files, git-adds, runs the guard tests, records the result, resets."""
import subprocess, sys, json, os
WT = sys.argv[1]
RUN = r'^(TestPlans.*|TestMarkdownRelativeLinksResolve|TestCallerAllowlistPrefixRuleIsDocumentedOnce)$'
def sh(*a, **k): return subprocess.run(a, cwd=WT, capture_output=True, text=True, **k)
def rd(p): return open(os.path.join(WT,p), encoding="utf-8").read()
def wr(p,s): open(os.path.join(WT,p),"w",encoding="utf-8").write(s)
def rep(p, old, new):
    s = rd(p); assert s.count(old)==1, (p, old[:60], s.count(old)); wr(p, s.replace(old,new))
def ins_before(p, anchor, text): rep(p, anchor, text + anchor)
def append(p, text): wr(p, rd(p)+text)
PPO = "## Primary Program Orientation\n"
R6J = "**2026-11-13 Review-22 development-source disposition:**\n"
M = [
 ("M01 status heading", "fail", lambda: ins_before("PLANS.md", PPO, "## Status\n\nPR #56 did X.\n\n")),
 ("M02 dated heading", "fail", lambda: ins_before("PLANS.md", PPO, "### PR #56 follow-up (2026-11-25)\n\nText.\n\n")),
 ("M03 line opens with ISO date", "fail", lambda: ins_before("PLANS.md", PPO, "2026-11-25: PR #56 changed submit.\n\n")),
 ("M04 list item bold date", "fail", lambda: ins_before("PLANS.md", PPO, "- **2026-11-25** PR #56 changed submit.\n\n")),
 ("M05 setext status heading", "fail", lambda: ins_before("PLANS.md", PPO, "Recent status\n-------------\n\n")),
 ("M06 'Status Update' heading", "fail", lambda: ins_before("PLANS.md", PPO, "## Status Update\n\n")),
 ("M07 R6J exception duplicated", "fail", lambda: ins_before("PLANS.md", PPO, R6J+"\n")),
 ("M08 R6J line reworded", "fail", lambda: rep("PLANS.md", R6J, "**2026-11-13 Review-22 development-source disposition (updated):**\n")),
 ("M09 +8000 bytes", "fail", lambda: append("PLANS.md", ("x"*79+"\n")*100)),
 ("M10 +7000 bytes (control, under cap)", "pass", lambda: append("PLANS.md", ("x"*69+"\n")*100)),
 ("M11 record one byte", "fail", lambda: rep(".docs/history/plans-record.md", "# Execution Substrate Plan Record\n", "# Execution Substrate Plan Record \n")),
 ("M12 new section before the objective", "fail", lambda: ins_before("PLANS.md", "## Current Planning Objective\n", "## Notes\n\nText.\n\n")),
 ("M13 PLANS note authority sentence reworded", "fail", lambda: rep("PLANS.md", "they\n  win.", "it\n  wins.")),
 ("M14 AGENTS rule reworded", "fail", lambda: rep("AGENTS.md", "is historical evidence and holds no current authority:", "is historical evidence:")),
 ("M15 README reference removed", "fail", lambda: rep("README.md", [l for l in rd("README.md").splitlines(True) if "plans-record.md" in l][0], "")),
 ("M16 moved P0n heading back in PLANS", "fail", lambda: ins_before("PLANS.md", PPO, "### Historical P0n workload-auth facade route — superseded and non-authoritative\n\nText.\n\n")),
 ("M17 .docs colon line citation", "fail", lambda: append(".docs/mvp.md", "\nSee PLANS.md:120 for details.\n")),
 ("M18 new git-added file with 'line N'", "fail", lambda: wr(".docs/audit-probe-notes.md", "See `PLANS.md` line 40.\n")),
 ("M19 shell script #L citation", "fail", lambda: append("scripts/01_bringup.sh", "# see PLANS.md#L12\n")),
 ("M20 claim-ledger range table cell", "fail", lambda: rep(".docs/commercialization/claim-ledger.md", "| `.docs/mvp.md` | `1-229` |", "| `PLANS.md` | `329-421` | x |\n| `.docs/mvp.md` | `1-229` |")),
 ("M21 record link un-rebased", "fail", lambda: wr(".docs/history/plans-record.md", rd(".docs/history/plans-record.md").replace("](../../.docs/execution_lifecycle/contracts.md)", "](.docs/execution_lifecycle/contracts.md)", 1))),
 ("M22 R6J line removed", "fail", lambda: rep("PLANS.md", R6J, "")),
 ("M23 R6J indented copy added", "fail", lambda: ins_before("PLANS.md", PPO, "   "+R6J+"\n")),
 ("M24 R6J line with trailing text added", "fail", lambda: ins_before("PLANS.md", PPO, R6J.rstrip("\n")+" extra\n\n")),
 ("M25 closing-hash status heading", "fail", lambda: ins_before("PLANS.md", PPO, "## Status ##\n\n")),
 ("M26 3-space status heading", "fail", lambda: ins_before("PLANS.md", PPO, "   ## Status\n\n")),
 ("L1 limit: 'On <date>,' entry", "limit", lambda: ins_before("PLANS.md", PPO, "On 2026-11-25, PR #56 changed submit.\n\n")),
 ("L2 limit: 'Progress log' heading", "limit", lambda: ins_before("PLANS.md", PPO, "## Progress log\n\n")),
 ("L3 limit: month-year heading", "limit", lambda: ins_before("PLANS.md", PPO, "## Changes in November 2026\n\n")),
 ("L4 limit: fence-toggle hides heading", "limit", lambda: ins_before("PLANS.md", PPO, "```\n~~~\n```\n## Status\n\n")),
 ("L5 limit: slash date line", "limit", lambda: ins_before("PLANS.md", PPO, "11/25/2026: PR #56 changed submit.\n\n")),
]
assert sh("git","status","--porcelain").stdout == "", "worktree not clean"
results = []
for name, want, fn in M[int(os.environ.get("FROM","0")):]:
    fn(); sh("git","add","-A")
    r = sh("go","test","-count=1","-run",RUN,".")
    failed = sorted({l.split()[2] for l in r.stdout.splitlines() if l.startswith("--- FAIL")})
    got = "pass" if r.returncode == 0 else "fail"
    ok = (got == want) if want != "limit" else True
    results.append((name, want, got, failed))
    print(f"{'OK ' if ok else 'BAD'} {name}: want {want}, got {got} {failed}", flush=True)
    sh("git","reset","-q","--hard","HEAD"); sh("git","clean","-qfdx")
    assert sh("git","status","--porcelain").stdout == ""
r = sh("go","test","-count=1","-run",RUN,".")
print("clean rerun:", "pass" if r.returncode==0 else "FAIL")
