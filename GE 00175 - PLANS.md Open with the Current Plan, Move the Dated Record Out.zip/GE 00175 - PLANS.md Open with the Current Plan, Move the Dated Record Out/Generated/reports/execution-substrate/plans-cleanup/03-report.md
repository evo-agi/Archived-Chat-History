# ES PLANS.md cleanup: thread report 03 (repair of audit 02)

Status: repaired and pushed. Waiting on a fresh audit. Written 2026-11-24 by the writer thread. This report replaces report 01 as the current report.

## Target

- Repo: `evo-agi/Execution-Substrate`, draft PR #55, branch `claude/project-thread-kumrhu`.
- Base: `trunk_dev` `16cbf739eea8c6a673aef8048aefb69cebd5121b`.
- Tip: `d0dd8836de2a5023d0ab6100485666647fd2d120`, tree `b22036c42c1fd29659cdbb380899594e9380c906`. Two commits: `bf4f5d6` (the audited patch) and `d0dd883` (this repair).
- Expected v2 manifest (`03-expected-manifest.json`, beside this report):
  - canonical SHA-256 `aa926a4174209e432a1f64515762a5796e6c45e2afc0b7ecc49ead58c6f361bd`;
  - textual diff SHA-256 `0fb5067648b530531cb7f9ab3e0e9f1ebc69f4ab31eb43d0fe8bdeb2ebaf69d7`;
  - 8 files.

  It was taken in a fresh clone exactly as provenance §5.3 describes: recipe hash verified, `reset --mixed` to the base, upstream `origin/trunk_dev`, two runs, `cmp` identical.
- Split script: `split_plans.py` (beside this report, SHA-256 `ddfcb2e3f0adc5100e913a3ccd6f4e09f59e8511a81c1dcf9bba1ed78f8364d5`). Run on 16cbf73's `PLANS.md`, it reproduces the tip's `PLANS.md` and record byte for byte (checked with `cmp`).

## Repairs

| Finding | Repair |
|---|---|
| **A02-1** (blocking): 16 relative links in the record broke | Each relative inline link target in the moved text gained a `../../` prefix. `split_plans.py` applies only that change. It asserts that each changed line equals its original once `](../../` is put back to `](`, that exactly 16 lines changed, and that the moved text has no reference definitions or HTML links. The multiset check undoes only that change before comparing. The record header now says that the link targets are the one change. The record was not exempted from `TestMarkdownRelativeLinksResolve`, which now passes with the record committed. |
| **A02-5** (coordinator's decision) | The record is historical evidence and holds no current authority. Where it differs from `PLANS.md` or from an owning `.docs/` contract, they win. This is now stated in four places: the record's header, AGENTS.md section 3 ("Authority hierarchy"), the note at the top of `PLANS.md`, and the README reference. The rule went into section 3's "Additional rules" list, not into the numbered lines 1 to 5, because 11 docs copy those lines verbatim and a test enforces the copies. Tests pin each statement. |
| **A02-2** (low) | Each of the 8 audit probes S1–S8 now fails the intended test. Checked on the committed tree, reset after each probe. The guards now: |
| | read CommonMark headings (ATX with up to 3 leading spaces and optional closing `#`s, and setext), outside fences; |
| | refuse status-log headings: a title that starts or ends with "status", "current/recent/latest/project/plan/work status", or "status update/log/entries/report/notes". The domain heading "Remote Alpha TLS status, renewal and diagnostic routes" stays allowed; |
| | refuse dates in headings in ISO, "25 Nov 2026" and "November 25, 2026" forms; |
| | refuse lines that open with a date, optionally bold or in a list item. The one existing such line in a current section, "**2026-11-13 Review-22 development-source disposition:**" in the ADR pointer's R6J text, is pinned as an exception. The test fails if that line disappears without the exception being removed; |
| | find line citations of `PLANS.md` in every text file the repo lists, through `repositoryTextFiles`, not only Markdown. The forms found are `:N`, `` `:N ``, `#LN`, "line(s) N" within 40 characters, and a table row whose later cell holds only numbers and ranges, at least one a range. |
| | A new `TestPlansGuardsFindEachKindOfProblem` self-test shows each refused form is found and ordinary text is not. Its refused examples build the file name at run time, so the test file does not trip the repo-wide check. |
| | My own new heading "Document Scope And Current Bounded Implementation Status" would be refused, so it is renamed "Document Scope And Current Implementation". I also rewrapped the `PLANS.md` note so that no line of it opens with a date. |
| **A02-3** (low) | Counts are now bytes: `PLANS.md` 312,592 bytes (4,170 lines), record 62,826 bytes (968 lines). The cap comment says 312,592. The script now prints byte counts. The 320,000-byte cap leaves 7,408 bytes of headroom. |
| **A02-4** (low) | The record header now says "in the order they stood at the top of `PLANS.md`". |

Pinned record SHA-256: `0b13566795d1233f91c293f4b5ea79134af73013d75fea2e7f74f7df57ed0561`. `PLANS.md` SHA-256: `937817d4271bb20694f52a08c1cbc6950e58f93406fcd7bfd60dcd65419b4dbc`.

## Validation

All runs were on the committed tree at `d0dd883`, with `git status` clean, in the cloud container with Go 1.26.5.

- `go test -count=1 .`: ok, 0 failures. That includes `TestMarkdownRelativeLinksResolve` and the 7 `TestPlans*` tests, which were run with `-v` and seen to pass.
- `go test -count=1 ./internal/testutil`: ok.
- `go test -count=1 ./scripts -run '<the 9 docs tests that read PLANS.md>'`: ok.
- `go vet .` and `GOOS=darwin GOARCH=arm64 go vet .`: clean. `gofmt -l` on the 3 changed Go files: clean.

Mutants, each run against the guards and reset afterwards. Every one failed the intended test:

- S1–S8 from audit 02;
- +8,000 bytes on `PLANS.md`;
- a one-byte change to the record;
- the plan sections swapped;
- the pinned dated line reworded (the stale-exception check fired);
- the AGENTS.md rule reworded.

Not run here:

- the rest of `./scripts` and the other packages, which CI runs on the branch;
- `TestRemoteAlphaHostFirewallRealKernelApplyConfirmRollback`, which needs `ip` as root. It fails here on base and head alike and is listed as skips-itself.

Lesson recorded: report 01 ran the root tests while the record was untracked. The link test lists files through git, so it never saw the record. From now on I run tests on committed (or at least git-added) bytes.

## Unchanged from report 01

- What moved, and the evidence that everything moved is history.
- The headings added to current text that had been filed under "Historical".
- The 13 repointed tests.
- The claim-ledger citations.

The audit-02 sections "Nothing lost or altered" and "Nothing current moved" still hold for this content. The only differences in the moved text are the 16 link prefixes.

## Open items

- Branches 9slgp8 and qhn13c will conflict on `PLANS.md`. The PR description says how to resolve each, using the new heading name.
- The coordinator will decide after the audit where the P0i–P0v rules and the R6J review history should live. Out of scope here.
- Naming: the record path and the four new headings (one renamed in this repair) are new names and easy to change.

Confidence: provenance high (manifest double run plus byte-for-byte script reproduction). Validation high for the packages run; CI is pending. Guard completeness is now medium-high: forms beyond those listed would still pass, and the size cap backstops them.
