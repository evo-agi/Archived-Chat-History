# ES PR #55 (PLANS.md cleanup): independent audit 02

Written 2026-11-24 by a fresh, read-only audit thread (did not write the patch). Nothing was pushed, committed, commented or merged.

**Verdict: BLOCK.** One blocking finding (A02-1): moving the record verbatim from the repository root into `.docs/history/` breaks 16 relative links in it, and the repository's own `TestMarkdownRelativeLinksResolve` fails on the exact head. Everything else checked out: nothing was lost or reworded, nothing current moved into the record, the authority meaning is unchanged, and every new guard fails on its intended violation.

## INDEPENDENT AUDIT REPORT

**Repository / audit target**

- `evo-agi/Execution-Substrate`, draft PR #55, https://github.com/evo-agi/Execution-Substrate/pull/55
- Branch `claude/project-thread-kumrhu`, topic commit `bf4f5d648be5de75454a4ab3c68b5de7ce709d19`, tree `cc93d9105e516a26de4a017659a080e4073bffd6`
- Base `trunk_dev` `16cbf739eea8c6a673aef8048aefb69cebd5121b`. Re-checked with `git ls-remote` at closeout: trunk_dev and the PR branch had not moved.
- Recipe `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified with `sha256sum -c` before running it)
- Canonical manifest SHA-256 `b693e9bc818fabd510a3bd31b81c60c02e030c04165a4d1d4462837d1bc547dd`, textual diff SHA-256 `a440b92339755187bf7fd768f10862b75c940638128d1d5c366dd8623e009899`. 8 paths: 6 modified (`.docs/commercialization/claim-ledger.md`, `AGENTS.md`, `PLANS.md`, `README.md`, `caller_authentication_docs_contract_test.go`, `docs_contract_test.go`) and 2 added (`.docs/history/plans-record.md`, `plans_docs_contract_test.go`). The manifest is saved beside this report as `02-audit-manifest.json`.

**Audit posture.** Read-only. Parent only, no subagents. Work was done in scratch clones under `/opt/audit` in the cloud container. The only shared-folder writes are this report, `02-audit-manifest.json` and `02-audit-mutants.py`.

**Provenance reproduction.** I followed provenance §5.3 exactly: fetch, check that the tip matches, check that the base is an ancestor, check out the tip, confirm a clean status, `reset --mixed` to the base, set upstream `origin/trunk_dev`, then run v2 twice into a fresh 0700 directory. `cmp` showed the two outputs identical. At closeout I ran it a third time on the same working tree, and the result was byte-equal to the opening manifest. No mode-bit differences. Observation: report 01 carries no expected manifest, so there was nothing to compare against. This manifest is the first one bound to the chain.

**Coverage.** I read the whole diff of all 8 paths. I re-ran the writer's split script, did an independent line-multiset check, and checked every section of the record against its owner. I checked the headings and the reordering, the effects of the test edits, the claim-ledger citations, the AGENTS.md and README wording, and every other doc or test that references the moved headings or cites PLANS.md. I mutation-tested all 6 new guards. Not inspected: other repositories (the writer's cross-repo check was not repeated), the remaining ~100 KB of P0i–P0v text, and the R6J history inside PLANS.md (unchanged bytes).

## Findings

### Patch defects

```text
AUDIT FINDING
ID / Type / Severity: A02-1 / bug + test/doc gap / high (blocking)
Current contract: TestMarkdownRelativeLinksResolve (runbook_paths_docs_contract_test.go:97) requires every
  relative link in every tracked Markdown file to resolve; CI check "build, vet and test" is required on ES.
Path and line: .docs/history/plans-record.md, 16 links, e.g. "[the operational handoff contract]
  (.docs/execution_lifecycle/reliable_submit_operational_handoff.md)" (13x), "[the execution lifecycle
  contracts](.docs/execution_lifecycle/contracts.md)" (2x), "[operational handoff owner contract](...)" (1x).
Evidence: go test -count=1 . on a clean checkout of bf4f5d6: 613 pass, 1 FAIL, TestMarkdownRelativeLinksResolve:
  ".docs/history/plans-record.md: .docs/execution_lifecycle/... (no .docs/history/.docs/execution_lifecycle/...)".
  The same test passes on base 16cbf73 (608/608 pass). It also passes in the manifest working state, where the
  record is untracked: the test lists files through git, so an uncommitted record is invisible to it.
  Inference: that is how report 01's "go test -count=1 .: ok" came about, so that claim did not hold for the
  committed tree.
Impact: the required CI check will fail (Inference from the local reproduction: CI was still running when this
  report was written), and the record's links point nowhere for readers.
Required correction (pick one; do not exempt the record from the link test, which would weaken a guard):
  (a) Preferred: rebase the 16 link targets by prefixing "../../". Make split_plans.py apply exactly that
      transform and assert that the transformed lines differ from the originals only by that prefix inside link
      targets. Change the record header's "moved here verbatim ... Nothing in it was reworded" to say that only
      relative link targets were rebased. Re-pin plansRecordSHA256, and update the TestPlansRecordIsClosed header
      phrase if its wording changes.
  (b) Or keep the record byte-verbatim by moving it to the repository root (links then resolve as they did in
      PLANS.md), and update AGENTS.md, README.md, the PLANS.md note and plansRecordPath.
  Either way, run go test -count=1 . with the record committed (or at least git-added) before reporting.
Uncertainty: none on the failure. Which fix is better is a naming/location choice for the writer.
Patch defect.
```

```text
AUDIT FINDING
ID / Type / Severity: A02-2 / test gap / low
Current contract: the PR claims guards for "no status entries" and "line citations"; plans_docs_contract_test.go.
Evidence: 14 intended-violation mutants were all killed (table below). These 8 probes survived:
  S1 a body paragraph "**2026-11-25 status:** PR #56 changed the submit path."; S2 "## Current Status";
  S3 a setext heading "Status\n------"; S4 "  ## Status" (indented up to 3 spaces is still a CommonMark heading);
  S5 "### PR #56 follow-up (25 Nov 2026)"; S6 a table row "| `PLANS.md` | `329-421` |", which is the exact form
  this patch fixed by hand in claim-ledger.md:30; S7 "See `PLANS.md` lines 12-20."; S8 "// see PLANS.md:12"
  in a .go file (the walk reads only .md).
Impact: a status log could come back as dated body paragraphs or under a heading other than "Status". The size
  cap is the only backstop, with 7,509 bytes of headroom. The citation guard would not have caught the
  table-form citation that motivated it. No live violation exists today: grep shows no PLANS.md line citations
  in any form left in the tree.
Required correction (fix in the same repair, per the low-nits-in-PR rule): match CommonMark headings (0-3
  leading spaces, setext); refuse any heading whose title contains the word "status" as a whole word (check
  first that no current heading needs it); refuse lines that begin with a date (optionally bold); widen the
  citation pattern to PLANS.md followed within the same line by a line number or range (":N", "#LN", "line(s) N",
  or a table cell holding "N-M"); or narrow the test comments and PR text so they claim only what is checked.
Patch defect (guard scope).
```

```text
AUDIT FINDING
ID / Type / Severity: A02-3 / doc gap / low (nit)
Path and line: plans_docs_contract_test.go comment on plansMaxBytes ("312,475 bytes"); report 01 Result section.
Evidence: wc -c gives PLANS.md 312,491 bytes and the record 62,614 bytes. The figures 312,475 and 62,603 are
  character counts: split_plans.py sums len(line)+1 over str, and the new text has non-ASCII em dashes. The
  pinned SHA-256 values match the committed bytes.
Required correction: state byte counts in the comment and in the replacement report.
Patch defect.
```

```text
AUDIT FINDING
ID / Type / Severity: A02-4 / doc gap / low (nit)
Path and line: .docs/history/plans-record.md header ("the `Status` entries up to 2026-11-24, newest first").
Evidence: the original order is not chronological. Record lines 572-651 hold three 2026-11-23 entries after
  2026-11-19 entries, and two more 2026-11-19 entries follow them.
Required correction: say "in the order they stood at the top of PLANS.md". Fold this into the A02-1 re-pin.
Patch defect.
```

### Observations (no correction required by this audit)

- **A02-5, authority (report-only, decision for the coordinator).** The new AGENTS.md rule (AGENTS.md:37 at bf4f5d6) says the record "keeps the standing its entries had in PLANS.md" and takes it off the read-first path. It does not say which text wins when a record entry conflicts with a current PLANS.md section. For example, record lines 556–557 say "Current production source is schema 4" inside a 2026-11-19 entry. This gap is not a regression: the same conflict existed when both texts sat in one file. The hierarchy lines are unchanged, and `.docs/history/` matches neither rank-3 nor rank-4 glob, so the move gives the record no accidental rank. The real change is to read obligation only, as the writer flagged. If the project wants "where the record and PLANS.md's current sections differ, PLANS.md wins", that is an authority-meaning change and needs the coordinator's call.
- **A02-6, merge-gate note.** The cap leaves 7,509 bytes of headroom. Branches `claude/project-thread-9slgp8` (Nomad part 2b) and `claude/project-thread-qhn13c` edit PLANS.md and will conflict. The writer's advice holds: edit the current section in place.

### Checked and found correct

- **Nothing lost or altered.** `split_plans.py` (SHA-256 `d12beebb…a6`, matches report 01) run with `python3 -I` on 16cbf73's PLANS.md (SHA-256 `1e4cd2d2…0fde`) reproduces the PR's `PLANS.md` and record byte for byte (`cmp`). Its 14 ranges partition original lines 1–5077 exactly (checked by program). Every range is copied contiguously. An independent multiset check over non-blank lines found 0 original lines missing and exactly 45 added lines, all of them the two notes, the record's P0 parent section and the four new headings.
- **Nothing current moved.** Every moved section declares itself history:
  - the 23 `Status` entries are dated;
  - Post-PR #10 opens "Historical selection state before PR #11 publication";
  - the 2026-11-17 sections are titled "Historical";
  - P0n and P0r open "The following records the former … rationale only. It grants no current operator route…".

  I spot-checked the writer's 7 flagged entries plus the Nomad lock entry. Each rule lives in a current owner:
  - Nomad lock: PLANS.md "Current-State Facts To Preserve During Redesign" line 261;
  - its limits, including "The lock governs Nomad's API, not Docker": `.docs/system_overview/configuration.md:727-749`;
  - pre-stage `OperationalNoChange`/`OperationalReasonNone`: `.docs/execution_lifecycle/reliable_submit_operational_handoff.md`;
  - caller authentication and allowlist: their tests read the current PLANS.md text.

  Across those entries, the only backticked identifiers found nowhere else in the repo are historical commit, tree and manifest digests. The H/C/T paragraph's current facts are owned by `.docs/execution_lifecycle/contracts.md` ("H/C/T integration candidate status and exact boundary"), which a test reads.
- **New headings match the owner.** `.docs/system_overview/remote_supported_host_alpha.md` treats P0i–P0m (lines 1474–2116), P0o–P0q (2315–3225) and P0s–P0v (3364 on) as current sections, and only P0g, P0n and P0r as historical. The three new `###` headings make PLANS.md agree with that owner and correct the old nesting under "Historical … superseded" headings. P0g stays in PLANS.md: it is conservative, and its section also holds the current P0h retirement.
- **Reordering.** The first four `##` sections are Objective, Ordered Execution Plan, Decision Rules and Exit Criteria. I checked all 12 above/below references in the new PLANS.md. Each points inside its own contiguous block, so the reordering breaks none.
- **Test edits.** No assertion was removed. Two mixed checks were split per file. `TestIntegratedCandidateStatusSeparatesCAndT`'s H/C/T section used to run through the preamble (original lines 800–865) and now ends at the record's next `##`. All six required strings are still found, and that test has no must-not-contain checks, so nothing weakened. The `historicalStatus` span covers the same three sections as before.
- **References.** The claim-ledger section citations are accurate: "Primary Program Orientation" holds the Milestone 0 claim freeze, "Stable semantic contracts", "Temporary compatibility edges" and `control-plane-normal-shell/v1`, and the GitHub anchors are well formed. The old `PLANS.md:329-…` citations already pointed into the Status log at 16cbf73, so they were stale before this PR (pre-existing). The AGENTS.md and README additions agree with the PLANS.md note. No other doc names a moved heading. The four PLANS.md references in `.docs` (capability_probing.md:244, the testdata README, and two handoff/persistence plan tables) still resolve to content in PLANS.md, or are generic "update PLANS.md" instructions.

### Mutation results (`02-audit-mutants.py`, run in a clean clone, reset between mutants, clean at the end)

| Mutant | Guard that failed |
|---|---|
| M1 `## Status` heading added | NoDatedStatusEntries (+ RecordIsClosed, since the heading is in both files) |
| M2 `### … (2026-11-25)` heading | NoDatedStatusEntries |
| M3 PLANS.md at 320,001 bytes | StaysWithinItsSizeCap |
| M3b PLANS.md at exactly 320,000 bytes | none (correct boundary) |
| M4 one byte changed in record / M4b entry appended | RecordIsClosed |
| M5 `PLANS.md:12` in README / M5b `PLANS.md#L12` in .docs/mvp.md | IsCitedBySectionNotLine |
| M6 section inserted before the objective / M6b decision-rules heading renamed | OpensWithTheCurrentPlan |
| M7 AGENTS.md rule reworded / M7b README link removed | RecordIsNamedWhereAgentsStart |
| M8 a moved heading added back to PLANS.md | RecordIsClosed |
| M9 "Do not add dated status entries" reworded | OpensWithTheCurrentPlan |
| S1–S8 (see A02-2) | none (survived) |

Unmutated baseline: all 6 guards pass.

## Validation assessment

Run on clean checkouts of the exact commits in a cloud container, as root, `umask 022`, `LANG=en_US.UTF-8`, with the go.mod toolchain go1.26.5 (auto-downloaded) and signals reset to defaults:

- `go test -count=1 -json .`:
  - head bf4f5d6: 613 pass, 1 fail (A02-1).
  - base 16cbf73: 608 pass, 0 fail.
  - The head adds exactly the 6 new `TestPlans*` tests. No test disappeared.
- `./scripts`, the 10 tests that read PLANS.md:
  - head and base give the same result: 9 pass, and `TestRemoteAlphaHostFirewallRealKernelApplyConfirmRollback` fails on both.
  - That failure comes from the environment: it needs `ip` netns as root, and report 01 lists it as skips-itself.
- `go test -count=1 ./internal/testutil`: ok.
- `go vet .` and `GOOS=darwin GOARCH=arm64 go vet .`: clean.
- `gofmt -l` on the 3 changed Go files: clean.
- Not re-run locally: the other packages. The PR changes no Go file outside the root package, and grep shows no other package's tests read the changed docs; their README.md hits are synthetic fixtures.
- CI: check "build, vet and test" (run 45478624802) was still in progress on bf4f5d6 when this report was written. Inference: it will fail on A02-1.

## Sensitive-material handling

No secrets, keys or tokens were read or written. The repo is public. Commit SHAs and digests appear in the report as identifiers only.

## Remaining uncertainty and stop conditions

- The CI outcome was not observed (still running).
- Which A02-1 fix to use is the writer's choice. Both options are proper fixes, not compromises.

## Confidence

- Provenance: high.
- Validation: high for the root package, scripts docs tests and testutil; CI pending.
- Implementation: high that the move is lossless and correctly classified; medium for guard completeness (A02-2).

## Effect status

No repair, commit, push, PR comment or merge was performed.

## Repair scope for the writer

Fix A02-1 through A02-4 in one commit. Then re-run `split_plans.py` (updated) and `go test -count=1 .` with the record committed, and run `./internal/testutil` and the scripts docs tests. Take a new v2 manifest and write a replacement report. A fresh audit follows; this audit does not bind changed bytes.

**Final verdict: BLOCK**
