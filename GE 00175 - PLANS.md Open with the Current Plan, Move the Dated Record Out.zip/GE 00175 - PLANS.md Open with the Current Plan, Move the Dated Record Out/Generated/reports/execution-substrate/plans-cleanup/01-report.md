# ES PLANS.md cleanup: thread report 01

Status: PR open as draft, waiting for an independent audit. Written 2026-11-24 by the PLANS.md cleanup thread.

## Brief (as received)

- Objective: make `PLANS.md` short and current, with the objective, ordered plan and decision rules near the top. Move history out of the read path. Update AGENTS.md and the README. Add a guard against regrowth and status entries. Check the other repos.
- Constraints: move, don't delete. Flag any change of authority meaning. Opus, no Fable, no broad re-reads.
- Base: `evo-agi/Execution-Substrate` `trunk_dev` `16cbf739eea8c6a673aef8048aefb69cebd5121b` (repo-validated).
- Seam classification: docs/tests only. Merges under the docs/tests policy once audit and merge gate pass.

## Result

- PR: https://github.com/evo-agi/Execution-Substrate/pull/55 (draft), branch `claude/project-thread-kumrhu`, head `bf4f5d648be5de75454a4ab3c68b5de7ce709d19`, one commit on top of 16cbf73.
- `PLANS.md`: 372,264 → 312,475 bytes (5,077 → 4,169 lines). SHA-256 `dbea6e1a8cce1991b56511a2023e5de5441102ed7b61d440c198c02ad7082521`.
- New `.docs/history/plans-record.md`: 62,603 bytes. SHA-256 `33ecb75bb5f197dd44d30fef1a4255dcde30220fcedde8929d9f60ee02a08e1c`, pinned in a test.
- Touched files: `PLANS.md`, `.docs/history/plans-record.md` (new), `AGENTS.md`, `README.md`, `.docs/commercialization/claim-ledger.md`, `docs_contract_test.go`, `caller_authentication_docs_contract_test.go`, `plans_docs_contract_test.go` (new).
- Other repos: only Governed-Execution-Bridge-Core has a `PLANS.md` on `trunk_dev` (39 lines, 1,660 bytes), and it needs nothing. Coordinator, MA, IM, OpenAI-Bridge, Archived-Runbooks and Archived-Chat-History have none. ES `main` has an old `PLANS.md`, which changes only through a milestone merge (David's go).

## Reproducing the split

`split_plans.py` (this folder, SHA-256 `d12beebb62cbde323274bee8283c345e77420eaa6ee65feec33a955c8dd824a6`) refuses any `PLANS.md` other than 16cbf73's (SHA-256 `1e4cd2d2…0fde`). It asserts every boundary line, writes both files, and checks that every non-blank original line lands exactly once. To reproduce:

    git checkout 16cbf73 -- PLANS.md && python3 -I split_plans.py .

The output is byte-identical to the PR's `PLANS.md` and record. A separate multiset check over the PR files showed 0 original lines missing and 45 new lines: the two notes, the record's P0 parent section and four headings.

## Classification decisions (for the auditor)

1. **Moved** only text that calls itself history:
   - the `## Status` entries, original lines 3–663;
   - the dated selections, 664–799 (Post-PR #10 says "Historical selection state"; the others say "At selection" or "Historical");
   - P0n 2299–2371 and P0r 2786–2852, which say "records the former … rationale only. It grants no current …".
2. **Found and fixed by structure, not wording:**
   - The original preamble (800–865) sat under "## Historical current-remote-base H/C/T foundation selection (2026-11-17)". It is current: PR #54 added a line to it today. It now has the heading "Document Scope And Current Bounded Implementation Status".
   - The current route rules P0i–P0m (2099–2298), P0o–P0q (2372–2785) and P0s–P0v (2853–3838) followed the "Historical … superseded and non-authoritative" headings with no heading of their own. They get three new `###` headings.
3. **Kept** P0g (2079–2098). Its section also states the current P0h retirement, and a test reads that text as a PLANS boundary.
4. The H/C/T selection paragraph (now in the record) states two current-sounding facts:
   - The execution/placement snapshot rule is owned by `.docs/execution_lifecycle/contracts.md:14`.
   - "The operator-facade evidence-compatibility cutoff … does not retire underlying owner-local producer scripts" is covered in `PLANS.md`'s "Current Remote Alpha operator evidence-compatibility cutoff": "The three underlying producer families remain optional owner-local proof emitters…".
5. **Authority:** the AGENTS.md hierarchy lines are unchanged (11 docs copy them, and a test enforces the copies). One new rule says the record keeps the standing its entries had but is not on the read-first path. The change is to read obligation only. Flagged.
6. **Status entries without an owning-contract pointer** (moved anyway, as they are dated status entries):
   - PR #12 v2 field-access guard completion;
   - PR #12 v2 authority and evidence repair;
   - Pre-stage continuation…;
   - Consolidated private operational handoff audit repair;
   - Nomad access control lock;
   - the two private replay-progress entries.

   Worth an auditor spot-check that each one's rule lives in a `.docs/` contract.

## Tests

- Run on the exact committed tree (cloud container, Go 1.26.5):
  - `go test -count=1 .`: ok.
  - `go test -count=1 ./internal/testutil`: ok.
  - `go test -count=1 ./scripts -run '<the 9 docs tests that read PLANS.md>'`: ok.
  - `go vet .` and `GOOS=darwin GOARCH=arm64 go vet .`: clean.
- Skipped: `TestRemoteAlphaHostFirewallRealKernelApplyConfirmRollback` fails before and after this change because it needs `ip` as root (listed as skips-itself). The rest of `./scripts` and the other packages were not run here; CI on the branch runs everything.
- Test edits: 13 tests repointed to the record, or given the new neighbour heading as end marker. Two mixed checks were split into one assertion per file. No assertion was removed.
- Each guard was shown to fail on its intended violation (see PR).

## Open items and risks

- **Inference:** branches that edit `PLANS.md` will conflict after the merge. Two of them matter:
  - `claude/project-thread-9slgp8` (Nomad part 2b, paused at 3ef8a75, +13/−6 in `PLANS.md`);
  - `claude/project-thread-qhn13c` (+1).

  Fix: edit the current section in place, and put the dated text in the PR description.
- **Not done:** `PLANS.md` is still 312 KB of mostly current rules. The next step is a decision for the coordinator: about 100 KB of P0i–P0v route rules, plus about 60 KB of ADR-pointer review history (R6J) that is interleaved with current invariants.
- Naming: the record's path and the four new headings are new names, easy to change.

Confidence: provenance high (script plus multiset check). Validation high for the packages run, pending CI for the rest. Classification medium-high: items 2, 4 and 6 are judgement calls for the auditor.
