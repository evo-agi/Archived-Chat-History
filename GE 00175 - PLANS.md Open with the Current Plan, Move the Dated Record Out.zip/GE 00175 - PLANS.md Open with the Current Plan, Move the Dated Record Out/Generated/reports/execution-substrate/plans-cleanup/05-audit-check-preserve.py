import sys, re, subprocess
from collections import Counter
def show(rev, path):
    return subprocess.run(["git","-C","/opt/audit/es","show",f"{rev}:{path}"],capture_output=True,check=True).stdout.decode()
base = show("16cbf73","PLANS.md").split("\n")[:-1]
plans = show("d0dd883","PLANS.md").split("\n")[:-1]
rec = show("d0dd883",".docs/history/plans-record.md").split("\n")[:-1]
# 1. record: find lines that differ from any base line; classify
bset = Counter(base)
rebased=[]; recnew=[]
for i,l in enumerate(rec,1):
    if l in bset: continue
    if "](../../" in l and l.replace("](../../","](") in bset:
        rebased.append(i)
    else:
        recnew.append((i,l))
print("record lines rebased:",len(rebased)); 
print("record lines not in base (non-blank):",sum(1 for i,l in recnew if l.strip()))
for i,l in recnew:
    if l.strip(): print("  R%d: %s"%(i,l[:110]))
pnew=[(i,l) for i,l in enumerate(plans,1) if l not in bset and l.strip()]
print("PLANS lines not in base (non-blank):",len(pnew))
for i,l in pnew: print("  P%d: %s"%(i,l[:110]))
# 2. multiset: every non-blank base line exactly as many times in outputs (after un-rebase)
out = Counter(l for l in plans if l.strip()) + Counter((l.replace("](../../","](") if i in set(rebased) else l) for i,l in enumerate(rec,1) if l.strip())
orig = Counter(l for l in base if l.strip())
missing = orig - out; extra = out - orig
print("missing base lines:",sum(missing.values()), "extra lines:",sum(extra.values()))
# 3. adjacency: consecutive non-blank base lines that are no longer consecutive (ignoring blanks) in the outputs
def nb(seq): return [l for l in seq if l.strip()]
outseq = nb(plans) + ["\x00SEP"] + nb([(l.replace("](../../","](") if i in set(rebased) else l) for i,l in enumerate(rec,1)])
pairs = Counter(zip(outseq, outseq[1:]))
bnb = [(i,l) for i,l in enumerate(base,1) if l.strip()]
breaks=[]
for (i,a),(j,b) in zip(bnb,bnb[1:]):
    if pairs[(a,b)]==0: breaks.append((i,j))
print("broken adjacencies (base line -> next base line):",len(breaks))
for i,j in breaks: print("  after base line %d (next %d): %s | %s"%(i,j,base[i-1][:60],base[j-1][:60]))
