Please add to the backlog that we need to clean up PLANS.md's in the repos.

Here is what your other self said:


```
What the oversized PLANS.md costs you now**

AGENTS.md ranks PLANS.md second in authority and says to "ALWAYS consult" it before any change. The README tells newcomers to read it second. So every agent task is supposed to start with it.

- **It uses up context and usage.** At 371 KB (about 49k words), it's roughly 70–95k tokens. That's before an agent opens `.docs/`, where `contracts.md` alone is 140 KB. Every task that follows AGENTS.md either pays that against your weekly limit or skims.
- **Skimming agents get misled.** The "Status" section is the first 660 lines: a diary in which 17 of 23 entries are about PR #12. The actual plan is near the bottom:
  - "Current Planning Objective" starts at line 4,245 of 5,076 (84% of the way down).
  - "Ordered Execution Plan" is at line 5,003 and "Current Decision Rules" at 5,042.

  Agents read big files from the top in chunks. One that stops early concludes the current work is PR #12 audit repairs and never reaches the decision rules it's meant to follow. A section titled "ADR Pointer" runs 1,132 lines, and the "Highest-Priority Backlog Entry" section runs 1,946.
- **It's growing fast.** It went from 4,229 lines on Nov 23 to 5,076 today, about 20% in two days. 8 of the last 25 commits touched it.
- **Parallel branches collide.** Every PR adds its status entry at the top, so any two branches in flight edit the same lines. Several `claude/project-thread-*` branches are open now.
- **Line-number references have broken.** `claim-ledger.md` cites PLANS.md lines 329–421 for the Milestone 0 freeze and the ES core boundary. Line 329 is now "PR #12 durable admission: corrections after the second audit." The Milestone 0 text has moved to about line 4,269, and every new entry at the top pushes it further down.
- **Tests make it hard to shrink.** I trimmed it two ways and ran the doc tests in the repo's root and `internal/testutil` packages (0 failures before trimming):
  - Removing only the dated history (old PR #12 entries and the "Historical…" sections, about 800 lines) broke 11 tests.
  - Keeping only the current-plan sections (836 lines) broke 78 tests.

  I didn't run the 13 or so script tests that also read PLANS.md. Four section headings are also used by tests as markers, so renaming one breaks tests too. The tests treat the history itself as a contract, which is why this append-only file can't be pruned.

So shrinking it means moving the text and updating the tests that check it in the same change. A clean way to do it:

- Move the history into `.docs/history/` and point those 11 tests at the new file.
- Put the current-plan sections at the top.
- Replace line-number citations with heading links, which don't drift.
- Stop adding status entries at the top. Put them in the history file or the PR description instead.

Doing this before Thursday would also make Claude's first run as a user cheaper.

Want me to prepare the history-only step as a patch you can apply (the PLANS.md split plus the 11 updated tests)? I can't push to the repo from here.
```
