The PLANS.md cleanup passed its re-audit. Our protocol wants a re-audit done by a fresh auditor, though, so a short independent check runs before it merges.
