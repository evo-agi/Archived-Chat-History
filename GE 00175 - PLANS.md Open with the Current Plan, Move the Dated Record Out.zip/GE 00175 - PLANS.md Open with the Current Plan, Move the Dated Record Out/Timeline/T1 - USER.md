> The box now runs the latest ES, and Nomad is locked so only ES can submit. Every service is up, and Nomad refuses reques…


We have ~40% of weekly quota and ~80% of Fable left. So, please re-plan accordingly.
