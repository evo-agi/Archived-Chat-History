The first PLANS.md cleanup is up for an independent audit. The current plan now sits at the top, but the file only shrank from 372 KB to 312 KB, so a second step will follow.
