I've opened ES draft PR #55, which slims down PLANS.md: https://github.com/evo-agi/Execution-Substrate/pull/55. It's docs and tests only, and the coordinator is lining up an independent audit before it merges.

**What changed**
- The objective, ordered plan, decision rules and exit criteria now open the file. They were 84% of the way down.
- Only text that calls itself history moved out, word for word: the status log, the dated selection notes, and two superseded route records. They now live in `.docs/history/plans-record.md`. That file is closed, and a test fails if anyone edits it.
- New tests stop status entries and dated headings from coming back, cap the file at 320,000 bytes, and refuse citations by line number. I checked that each one fails when it should.
- The claim ledger's line citations had drifted, so they now point at section headings.

**What I found**
The file is still 312 KB, down from 372 KB. That's because about 100 KB of current rules, and the plan's own introduction, sat under headings marked "Historical, superseded". An agent skimming the headings would have skipped them. I gave them proper headings and kept them in the file.

Shrinking it further means moving current rules somewhere else, which changes where they get their authority. I've raised that as a decision for the coordinator.

The root and docs tests pass locally. GitHub CI runs the full suite on the PR. Report: [01-report.md](/mnt/project-files/reports/execution-substrate/plans-cleanup/01-report.md)

STATUS: WAITING (independent audit and CI on PR #55; nothing needed from you)
