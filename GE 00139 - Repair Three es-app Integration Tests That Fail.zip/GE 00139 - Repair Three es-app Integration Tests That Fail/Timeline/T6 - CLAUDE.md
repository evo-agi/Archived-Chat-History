The three stale tests are repaired in [PR 17](https://github.com/evo-agi/Execution-Substrate/pull/17), so I'm starting its fresh audit. The bring-up script will now run ES as your user rather than root, which matches ES's own startup check. I made that call because it's the safer option, so nothing waits for you.

STATUS: WORKING (PR 17 audit, bring-up fix, CI small fix, PR 13 repair, MA fix)
