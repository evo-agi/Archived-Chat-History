Got it. PR 17 is being merged now, and I'll post the merge link when it lands. I updated the project instructions to match. Test-only PRs merge without asking you. Your first-three review covers code changes only. You can still review any PR you like, before or after it merges, and I'll treat anything you raise afterward as new work.

My reading: the next two non-test PRs still come to you for review, so PR 18 (bring-up script) will be one of them. Tell me if you meant to drop that rule entirely.

STATUS: WORKING (PR 17 merge, PR 18 audit, PR 13 repair, CI and MA small fixes)
