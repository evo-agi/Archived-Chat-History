[PR 17](https://github.com/evo-agi/Execution-Substrate/pull/17) is ready for your review. It's one of your first three merges into trunk_dev. It repairs three Nomad/Vault tests that have been out of date since an earlier PR changed ES behaviour on purpose. It changes test code only, and the tests now check the current behaviour at least as strictly as before. The fresh audit says ACCEPT with nothing open, and the tests passed three times in a row on GitHub. I skipped a red-team because no product code changes, and that saves Fable. Say the word if you want one anyway.

Reply "merge 17" to approve, or tell me what to change.

STATUS: NEEDS DAVID (review and approve the PR 17 merge)
