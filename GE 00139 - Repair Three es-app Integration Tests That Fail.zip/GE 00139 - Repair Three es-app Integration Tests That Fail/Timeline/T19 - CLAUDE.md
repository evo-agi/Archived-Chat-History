[PR 17](https://github.com/evo-agi/Execution-Substrate/pull/17) is merged into trunk_dev as b8d6bc3. The merged code is exactly what the audit accepted, and no branches were deleted.

STATUS: WORKING (PR 18 audit, PR 13 repair, CI and MA small fixes)
