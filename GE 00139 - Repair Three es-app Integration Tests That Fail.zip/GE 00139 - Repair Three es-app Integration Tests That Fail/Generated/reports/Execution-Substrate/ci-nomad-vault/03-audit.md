# ES PR #17: independent correctness audit of the stale test repairs

Report 03 of the CI Nomad/Vault track. Fresh audit thread, 2026-11-22, 19:05Z to 19:40Z. Read-only: nothing was pushed, commented, edited or merged.

**Verdict: `ACCEPT`** for head `dac9736ba13d191064d1f129ca40be86d345fb1f`.

Each of the three repaired tests asserts the current contract at least as strictly as before, each behaviour change is intentional and comes from `2478a24` (#8), and the patch changes no product code. One low finding is open (a wrong document path in a new test comment, NV3-F1). It is not a weakening. I recommend fixing it with the next commit on this branch.

**Head audited:** the PR head was `dac9736` when I recorded it at 19:05Z and still `dac9736` at 19:37Z (`git ls-remote origin refs/pull/17/head`). This audit binds those bytes only. If the writer adds the bring-up script fix to PR #17, the new head needs its own audit.

## 1. Audit target

| Field | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate`, draft [PR #17](https://github.com/evo-agi/Execution-Substrate/pull/17) into `trunk_dev` |
| Base | `trunk_dev` at `ae326b0ddc30ec6b35883ee32945c622405b68b6` (also `origin/trunk_dev` at 19:32Z) |
| Topic branch and commit | `claude/project-thread-a9tcoa` at `dac9736ba13d191064d1f129ca40be86d345fb1f` |
| Tree | `e045cfcb5f794c5a36278e6df10d01980b04c22c` |
| Commits | `01cd1b1` (four test files) and `dac9736` (restores `es/app/operator_scripts_integration_test.go` to the base, checked with `git diff --quiet ae326b0 dac9736`) |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked with `sha256sum -c` before each run |
| Canonical manifest | `cde984e741eeaf58931ffc16f90ac056afb4d8ce1464db7cae6e229ef8db0735` (890 bytes), textual diff `cf675a30dad238ad8516384b413a794e44da7a5ba54bc947e8e92cbf4aeb3a7b` |
| Changed paths | 3, all `tracked_modified`, mode `0644`: `es/app/staging_cleanup_integration_test.go` (+64 −5), `es/app/submit_integration_test.go` (+68 −14), `es/app/supported_local_proof_validation_test.go` (+50 −2) |
| Writer report | `02-repair-tests.md`, SHA-256 `da226fa8be77c9287bcb58bcad1c15b8a9736985c6f22e9f18764e0bc9aa5570` (computed from the file) |

## 2. Audit posture

- Read-only. The provenance clone (`/opt/audit/prov`) was never edited. Tests and mutants ran in separate copies owned by an unprivileged user.
- One parent session, no subagents. The patch is three test files, so I read all of it myself. The protocol's audit subagents (§13.2 step 3) were not used; nothing was delegated.
- Effects outside the container: none. The audit did not use the GitHub runner, David's Mac or the Linux box.

## 3. Provenance reproduction

Done before reading code, in a fresh clone from GitHub with `umask 022`, following `provenance-and-audit-evidence.md` §5.3:

```bash
git fetch -q origin trunk_dev claude/project-thread-a9tcoa
test "$(git rev-parse origin/claude/project-thread-a9tcoa)" = dac9736ba13d191064d1f129ca40be86d345fb1f
git merge-base --is-ancestor ae326b0ddc30ec6b35883ee32945c622405b68b6 dac9736ba13d191064d1f129ca40be86d345fb1f
git checkout -q -f -B claude/project-thread-a9tcoa dac9736ba13d191064d1f129ca40be86d345fb1f
test -z "$(git status --porcelain)"
git reset -q --mixed ae326b0ddc30ec6b35883ee32945c622405b68b6
git branch -q --set-upstream-to=origin/trunk_dev
python3 -I v2.py OUT/1.json && python3 -I v2.py OUT/2.json && cmp OUT/1.json OUT/2.json
```

- Both runs are byte-identical, and equal to the writer's `02-evidence/manifest-v2-repair-dac9736.json` (`cmp`, exit 0). No mode-bit difference to tolerate.
- Closing manifest at 19:32Z, after all work: byte-identical to the opening one (`03-audit-evidence/manifest-open.json`, `manifest-close.json`).
- The three files in the test copies have the manifest's hashes (`sha256sum`).

## 4. Coverage

| Area | What I inspected |
| --- | --- |
| Patch | Every line of the diff `ae326b0..dac9736`; both commit messages; the PR description |
| Contract documents | `.docs/system_overview/capability_probing.md:130-152, 215-228, 306-326`; `.docs/execution_lifecycle/contracts.md:545-575, 1500-1532`; `.docs/execution_lifecycle/implementation.md:1036-1044`; `PLANS.md:218`; `AGENTS.md:20-40, 84-96, 120-135` |
| Product code | `es/admission/execution_roots.go:449-580`; `es/admission/policy_payload.go` (whole file) and its diff in `2478a24`; `es/admission/policy.go:81-276`; `es/internal/staticarchive/archive.go` (whole file); `es/admission/submit.go:36-113`; `es/admission/service.go:362-420`; `es/admission/resolved_execution_plan.go:436-450`; `es/admission/executionlocator.go:20-26`; `es/admission/staging_custody.go:451-480, 1237-1243`; `scripts/72_supported_local_setup.sh:16-21, 150-200, 330-375, 842`; `scripts/internal/supported_local_execution_roots.py:1-260` |
| Tests | The three changed tests and their helpers; `es/admission/policy_a2_test.go:1-135`; `es/runtimehelper/supervisor_a2_test.go:1-46`; `es/internal/staticarchive/testcorpus/corpus.go:60-90`; `scripts/internal/test_supported_local_execution_roots.py:177-193`; `es/app/supported_local_execution_roots_test.go:15-30, 73` |
| History | `git blame` at `ae326b0` for every cited range; `git show 2478a24` for `policy_payload.go` and for the supported-local test |
| Writer evidence | `02-evidence/SHA256SUMS.txt` (all 19 files check); the runner log of run 45055948469; the scratch helper test |
| Not inspected | Sections 4 and 5 of the writer's report (bring-up test and CI branch) are outside PR #17 and outside this audit. The root package's tests were run, not read. |

## 5. The three tests

Product lines below are at `ae326b0`; the patch does not change them. Test lines are at `dac9736`.

### 5.1 TestExecutionLoopScriptSuccessRetainsDistinctStageRootsAcrossRepeatedRuns

**Behaviour change, intentional (repo-validated).** ES creates one probe directory and one symlink in the staging root at configured-Submit startup and does not delete them: `es/admission/execution_roots.go:457-502` (`stagingName` at :457, `Mkdirat` at :461, `Symlinkat` at :491; no unlink follows). The contract says so three times: `.docs/system_overview/capability_probing.md:224-228` ("The isolated candidate retains its small exclusively created startup probe fixtures under the configured roots … the probe does not delete those names"), `:314-315`, `:324-326`. `git blame` gives every one of these lines to `2478a24`. The same commit added the same inventory check to `TestFailedAndAmbiguousSubmitRetainCreatedStageRoot` (`es/app/staging_cleanup_integration_test.go:158-204`, all 47 lines from `2478a24`), so the author's own test expects the pair.

| | Old (`ae326b0`, lines 247-256) | New (`dac9736`, lines 233-262 and helper 264-316) |
| --- | --- | --- |
| Both runs succeed, both run roots exist | yes | yes, unchanged |
| The two run roots differ | yes | yes, unchanged |
| Nothing else in the staging root | exactly 2 entries of any type | exactly 2 run roots named `^run-[0-9a-f]{16}$`, real directories, equal to the two run IDs of the summaries; exactly one probe directory `^\.execution-substrate-staging-probe-[0-9a-f]{32}$`; exactly one `<probe>-symlink` whose target is the bare probe name; any other name fails; any name containing `quarantine` fails |

The only thing the new test admits that the old one refused is the probe pair the contract keeps. Everything else is equal or stricter (names, types, link target, identity of the run roots). The name patterns match the product: run IDs are `"run-"` + 8 random bytes in hex (`executionlocator.go:20-26`), probe tokens are 16 random bytes in hex (`staging_custody.go:1237-1243`).

### 5.2 TestSubmitFlowRejectsWorkloadArchiveWithSymlinkEntry

**Behaviour change, intentional (repo-validated).** `.docs/execution_lifecycle/contracts.md:562-570` (`2478a24`): "The entire archive must have no … traversal, link, special entry … An ambiguous or malformed archive fails with `admission_policy_input_unavailable` before policy allow, Submit run assignment, materialization, or provider registration." The code: `es/internal/staticarchive/archive.go:56-58` refuses every entry type except directory and regular file; `es/admission/policy_payload.go:118-171` now reads the whole archive; `policy.go:270-276` returns 403 with the fixed code and message (message text from `contracts.md:559-561`, `308ae8e`). The diff of `2478a24` shows the old extractor returned at the entrypoint (`return string(textBytes), nil`), so a link placed after it was never seen at admission. The policy that needs the script text is always on for `static-script` artifacts (`policy.go:89-99, 123-132`), and Submit accepts no other artifact type (`resolved_execution_plan.go:444-450`). The order in the code matches the contract: policy (`service.go:413`) runs before the run ID (`submit.go:41`), the staging claim (`:68`), materialization (`:85`) and Nomad (`:99`). `2478a24` also added a service-level test of exactly this case: `es/admission/policy_a2_test.go:58-120` runs the corpus item "late unsupported link" (`testcorpus/corpus.go:78`) through `Submit` and requires the refusal, no Nomad call and empty roots.

| | Old (`ae326b0`, lines 945-961) | New (`dac9736`, lines 950-993) |
| --- | --- | --- |
| Response to the link archive | 202 | 403; body decoded with unknown fields refused; `success=false`, code `admission_policy_input_unavailable`, error `admission policy input unavailable` |
| The workload never starts | failed allocation, log lacks `WORKLOAD-STARTED` | the test's own Nomad agent lists no job at all; the staging root has no `run-` entry |
| The refusal is due to the link | not checked | control: same stack, same entrypoint, no link entry: 202 and the allocation log contains `WORKLOAD-STARTED` |

The old security intent holds more strongly: nothing reaches Nomad. The old end-to-end check of the second layer (runtime extraction refuses the link) has no reachable equivalent since #8, because no archive with a link can be admitted. That layer keeps its unit test, `es/runtimehelper/supervisor_a2_test.go:15-46`, over the same corpus (see NV3-O3).

### 5.3 TestSupportedLocalSetupScriptBootstrapsRealSPIREAndVaultDevTarget

**Behaviour change, intentional (repo-validated in code and its unit test; no document sentence states it).** `scripts/internal/supported_local_execution_roots.py:40-52` (`clean_proof_path`, all 13 lines from `2478a24`) refuses a proof path equal to, inside, or containing the source root. Its unit test from the same commit asserts both directions on purpose: `scripts/internal/test_supported_local_execution_roots.py:189-193`. `scripts/72_supported_local_setup.sh:174-177` stops at that preflight. The script's own default proof directory is under `/tmp` (`:16`), and `2478a24` itself uses a short `/tmp` directory for sockets (`es/app/supported_local_execution_roots_test.go:73`). `2478a24` edited this very test (the result-key lines) without moving its workspace. Inference: it was not run then, because it needs `vault`. The writer cites `contracts.md:1512-1515` as related text; I agree it is only related (it is about key and scope containment), and I found no document sentence for the source-tree rule (NV3-O2).

**Second defect, not a behaviour change (confirmed on the base bytes).** The old test set `SUPPORTED_LOCAL_RUNTIME_SUPPORT_BINARY` to `<proof>/bin/es-runtime-support`, which is where `build_runtime_support_binary` builds before it installs (`scripts/72_supported_local_setup.sh:331, 343-347`). `git blame`: the test's value is from the import `8a5e166`; of script lines 325-350, 22 are from `8a5e166` and 4 (the Go toolchain lines) from `31b4faf`. I ran the unrepaired test on the base with only the source-tree refusal taken out of the Python helper: it fails with `install: '…/proof/bin/es-runtime-support' and '…/proof/bin/es-runtime-support' are the same file` (`base-second-defect.log`). Inference from that run and the blame: with GNU `install` this test could not pass before #8 either, which is what the writer states.

| | Old | New |
| --- | --- | --- |
| Workspace | `<repo>/.out/supported-local-setup-*` | `/tmp/esls-*` (`os.MkdirTemp`, mode 0700, removed at cleanup, same keep-switch as before) |
| Install path | equal to the build output | `<workspace>/runtime-support/es-runtime-support`, directory made by the test |
| Assertions | base lines 81-229 | all kept (now lines 89-254), plus three: `PROOF_RUNTIME_SUPPORT_BINARY` names the install path; installed bytes equal the built binary and are not empty; installed mode is `0755` |

Nothing else in the test depended on the install path being inside the proof directory (`:752-753` already compares the generated ES config with the same managed value).

## 6. Findings

Patch defects first, then pre-existing or report-only items.

```text
AUDIT FINDING
ID / Type / Severity: NV3-F1 / test and doc gap / low
Current contract or strategic target: current contract; the probe-retention text is in
  .docs/system_overview/capability_probing.md (224-228, 314-315, 324-326)
Path and line: es/app/staging_cleanup_integration_test.go:249
Evidence: the new comment cites ".docs/execution_lifecycle/capability_probing.md". That file
  does not exist (ls .docs/execution_lifecycle/). No other place in the repo uses that path;
  PLANS.md, README.md and docs_contract_test.go all use .docs/system_overview/capability_probing.md.
Impact: a reader who follows the comment finds nothing. No effect on what the test checks.
Required correction: change the path in the comment to .docs/system_overview/capability_probing.md.
Uncertainty: none.
Patch defect or pre-existing issue: patch defect.
```

```text
AUDIT FINDING
ID / Type / Severity: NV3-O1 / test adequacy / observation
Current contract or strategic target: contracts.md:562-570 (refusal before run assignment,
  materialization and provider registration)
Path and line: es/app/submit_integration_test.go:968-976 and 990-993
Evidence: (a) the "no run root" check looks only for names that start with "run-"; the helper
  this PR adds (retainedStageRunRoots) would also refuse any other stray name. (b) the results
  root is not looked at; the service-level test of #8 requires both roots empty
  (policy_a2_test.go:106-107). (c) the control requires 202 and the log line, not a "complete"
  allocation.
Impact: none against the old test, which checked none of these. Mutants B6, B7 and B8 show the
  three checks that exist do fire.
Required correction: none. Optional tightening if the file is touched again.
Uncertainty: none.
Patch defect or pre-existing issue: patch, not a defect.
```

```text
AUDIT FINDING
ID / Type / Severity: NV3-O2 / doc gap / observation
Current contract or strategic target: current contract by code and unit test
  (supported_local_execution_roots.py:40-52, test_…:189-193)
Path and line: .docs (no sentence); .docs/execution_lifecycle/implementation.md:1040
Evidence: I searched contracts.md, implementation.md, capability_probing.md, PLANS.md and
  .docs/supported_local_cp_consumer_runbook.md for the rule that a proof directory may not lie
  in, or contain, the source tree. Not stated. implementation.md:1040 describes the ".out"
  convention for workspaces made by newExecutionWorkspaceTempDir; it stays true as written, but
  this test is now an exception explained only in its helper comment (lines 257-262).
Impact: the rule is enforced and tested, only undocumented. AGENTS.md §3 says code and tests
  win for current behaviour.
Required correction: none in this PR (it must not change product or docs). Coordinator's call
  whether a doc sentence is wanted.
Uncertainty: a sentence may exist under wording I did not search for.
Patch defect or pre-existing issue: pre-existing (since 2478a24).
```

```text
AUDIT FINDING
ID / Type / Severity: NV3-O3 / test coverage / observation
Current contract or strategic target: contracts.md:573-575 ("Runtime extraction independently
  enforces the same canonical destination and stream-tail integrity before launch")
Path and line: es/runtimehelper/supervisor_a2_test.go:15-46
Evidence: since 2478a24 no archive with a link entry can be admitted, so no public Submit can
  reach the runtime extractor's own refusal. The old integration test was the only end-to-end
  check of that layer; it now has unit coverage only (corpus items "late unsupported link" and
  "late hard link").
Impact: none from this PR. The change is a consequence of #8.
Required correction: none.
Uncertainty: none.
Patch defect or pre-existing issue: pre-existing.
```

```text
AUDIT FINDING
ID / Type / Severity: NV3-O4 / bug (script), report-only / observation
Current contract or strategic target: none found; usage text at scripts/72_supported_local_setup.sh:90
Path and line: scripts/72_supported_local_setup.sh:330-348
Evidence: when SUPPORTED_LOCAL_RUNTIME_SUPPORT_BINARY equals <proof>/bin/es-runtime-support and
  no prebuilt binary is given, setup builds the binary and then fails to install it onto
  itself (base-second-defect.log). It fails closed, with the coreutils message.
Impact: low. The canonical proof flow gives a prebuilt binary and the default install path
  /usr/local/bin (scripts/73_supported_local_proof.sh:571, 72…:19). Only this test hit it.
Required correction: none in this PR. The writer fixed the test input, which is the right
  scope for a test-only repair.
Uncertainty: Unknown whether an operator is meant to be able to choose that path.
Patch defect or pre-existing issue: pre-existing (since the import 8a5e166).
```

```text
AUDIT FINDING
ID / Type / Severity: NV3-O5 / merge-gate note / observation
Path and line: commit messages of 01cd1b1 and dac9736
Evidence: 01cd1b1's message says "repair four es/app integration tests" and describes the
  bring-up test that dac9736 takes out again. Both messages end with a model-name trailer and
  a session link.
Impact: none on the bytes. A squash merge writes its own message.
Required correction: at the merge gate, squash with the PR title and a message that matches
  the three files. Unknown whether ES history should carry a model name (project memory
  records "no model name" for the Maintenance Agent merge only).
Patch defect or pre-existing issue: not a byte defect.
```

No contract or authority drift, no security risk, no product change, no weakened assertion found.

## 7. Validation assessment

All runs: cloud container (Ubuntu 24.04.5, kernel 6.18.44, 4 CPUs, Docker 29.10.0 on cgroup v1), Go 1.26.5 (`go.mod:3`), Nomad 2.1.1, Vault 2.2.2 and the SPIRE 1.14.4 musl tarball, each checked with `sha256sum --check --strict` against the hashes in `01-implementation.md` §6.1; images `alpine:3.20` and `python:3.13-alpine` pulled by the digests of §6.1. Tests ran as an unprivileged user in group `docker` with passwordless `sudo`, `env -i`, no proxy variables, `AWS_EC2_METADATA_DISABLED=true`, `umask 022`. One test command at a time.

| Command (see `03-audit-evidence/`) | Bytes | Result |
| --- | --- | --- |
| `go test ./es/app -run '^(the three)$' -count=1 -v` | head | 3 of 3 pass (20.7 s, 4.9 s, 6.8 s) |
| same with `-count=3` | head | 9 of 9 pass |
| same, `-count=1` | base | 3 of 3 fail: "found 4"; "expected 202, got 403 … admission_policy_input_unavailable"; "supported-local execution-root scope is invalid". These are the writer's reported failures. |
| `go test ./es/app -count=1 -v` | head | 158 pass, 2 fail, 0 skip, 351.7 s. The 2 are `TestBringupScriptUpCheckDownFullProfile` (not in this PR; here it stops at "control-plane image build failed": I did not pull the build image, and the writer reports that a container started inside a cloud container has no network egress) and `TestSubmitFlowMountsGovernedArtifactAndLifecycleWithInstalledSourceIdentity` (needs operator values by design). The three repaired tests pass in this run too, so each passed 5 times in total. |
| `go test . -count=1` | head and base | The same 9 tests fail on both trees (tests that need macOS paths such as `/private/tmp`). Identical failing sets, so none comes from this PR. |
| `gofmt -l es/app`; `go vet ./es/app`; `go test -c ./es/app` for linux/amd64 and darwin/arm64; `git diff --check ae326b0 dac9736` | head | all clean, exit 0 |

**Mutants of product code (23; `mut.py.txt`, `mutants-summary.log`).** Each changes Go, shell or Python product code in a scratch copy, never a test file, and runs the matching repaired test.

| Mutant | Outcome |
| --- | --- |
| A1 probe deletes both fixtures; A2 symlink only; A3 directory only | caught: "staging root lacks exactly one matching startup probe pair" |
| A4 probe symlink points elsewhere | caught: "staging probe symlink target" |
| A5 probe renamed; A6 stray extra directory | caught: "unexpected staging root entry" |
| A7 second probe pair; A10 probe directory replaced by a file | caught: "invalid retained staging probe directory" |
| A8 third run root | caught: "expected two successful stage roots to remain, found 3" |
| A9 quarantine name | caught: "unexpected quarantine name" |
| B1 archive package accepts symlink entries; B2 the pre-#8 early return at the entrypoint | caught: "expected 403 …, got 202" |
| B3 refusal status 400 | caught: "expected 403 …, got 400" |
| B4 refusal code changed; B5 message changed | caught: "unexpected refusal" |
| B6 refusal returned only after materialization | caught: "was materialized into run root" |
| B7 refusal returned only after Nomad registration | caught: "reached Nomad registration: jobs=[exec-run-…]" (this also shows the job listing is not vacuous) |
| B8 every archive refused | caught by the control: "expected 202 for the archive without the link entry, got 403" |
| C1 install mode 0700 | caught: "installed es-runtime-support mode" |
| C2 a different file is installed | caught: "differs from the built binary" |
| C3 managed config names the build path | caught: "expected PROOF_RUNTIME_SUPPORT_BINARY" |
| C4 install step skipped | caught: "read installed es-runtime-support" |
| C5 source-tree refusal removed | not seen by this Go test, by design: the test no longer puts anything in the tree. The existing Python unit test fails on it (`test_bad_paths_and_parent_symlink_refuse`), and `TestSupportedLocalExecutionRootSyntheticFixtures` runs that unit test (`es/app/supported_local_execution_roots_test.go:15-30`). The old test did not assert the refusal either. |

**Synthetic inventories (33; `inventory-helper-cases.log`).** The new helper accepts the good inventory, returns 3, 1 and 0 run roots to the caller when that is what is there (the caller's `len != 2` check then fails), and refuses 29 bad ones: stray file, hidden file or directory; run root with upper-case hex, 15 or 17 digits, a suffix, a regular file, a symlink; quarantine names; a missing, dangling, duplicated, mistyped or mismatched probe pair; a link target that is absolute, `./`-prefixed or another entry; a results-probe name. This repeats and extends the writer's 7 cases.

**Cleanup.** After 5 passing runs and the failing mutants C1 to C4, no `/tmp/esls-*` directory was left (the root-owned roots are empty directories inside a directory the test user owns).

**Runner evidence, read but not re-run.** The writer's log of run 45055948469 shows the three tests passing in three passes on `ubuntu-24.04` with the pinned tools (lines 346-348, 451-453, 455-457) at probe commit `7a486b4`, and I checked that the three files are byte-identical between `7a486b4`, `01cd1b1` and `dac9736` (`git diff --quiet`). I did not start a runner job: the audit pushes nothing.

**Not run:** the GitHub runner; macOS execution (compile only; the supported-local test is `//go:build linux`); `-race`; the Linux box.

## 8. Sensitive-material handling

The supported-local test creates a Vault dev token, TLS keys and SPIRE material under `/tmp/esls-*` and removes them at cleanup. None was opened, printed or copied. Evidence logs have service log lines removed; a scan of the evidence folder for token-like strings, private keys, e-mail addresses and phone numbers found one false positive (a Python class name). No secret, env file or database was read.

## 9. Remaining uncertainty and stop conditions

- This container is not the runner (cgroup v1 here; Docker 29.10.0 here against 28.0.4 on the runner, per the writer's 01 report). The runner result rests on the writer's log for identical bytes.
- PR #17 has no CI check of its own until PR #14 merges.
- Stop condition for the merge gate: the PR head must still be `dac9736`. Any new commit (the NV3-F1 comment fix, or a bring-up script fix) makes a new head. For a one-line comment fix, a provenance check plus a look at that one line is enough, in my judgment; a script change needs a full audit.
- Red-team scope is the coordinator's decision. This patch changes tests only.

## 10. Confidence

- **Provenance: high.** Manifest reproduced byte for byte from GitHub, twice, and again at closeout; PR head checked at the start and at the end.
- **Validation: high in the container, medium-high for the runner.** I ran every claimed result myself in the container (pass on the head, fail on the base, whole package). The runner passes are the writer's, read from the log.
- **Implementation: high.** Every assertion was compared old against new, every cited contract line and blame was checked, and 22 of 23 product mutants are caught by the repaired tests, the last by an existing unit test.

## 11. Effect status

No repair, commit, push, comment, PR change or merge was performed. `REPAIR_NOT_PERFORMED`, `PUSH_NOT_PERFORMED`, `MERGE_NOT_PERFORMED`.

## 12. Report delivery

`/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/03-audit.md` (SHA-256 in the thread reply) and `03-audit-evidence/` (`README.md`, `SHA256SUMS.txt`).

## 13. Final verdict

**`ACCEPT`** for `dac9736ba13d191064d1f129ca40be86d345fb1f`, manifest `cde984e741eeaf58931ffc16f90ac056afb4d8ce1464db7cae6e229ef8db0735`. One low finding open (NV3-F1); five observations, none requiring a change in this PR.

STATUS: READY (audit of PR #17 done, verdict ACCEPT for dac9736; nothing running)
