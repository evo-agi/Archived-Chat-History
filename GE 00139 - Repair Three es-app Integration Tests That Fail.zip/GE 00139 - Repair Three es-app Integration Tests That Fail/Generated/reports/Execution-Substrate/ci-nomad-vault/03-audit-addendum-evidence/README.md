# Evidence for 03-audit-addendum.md (ES PR #17, head 962bc89)

Produced by the audit thread on 2026-11-22 between 19:39Z and 19:46Z, in the same cloud container as `03-audit-evidence/` (Ubuntu 24.04.5, Go 1.26.5, Nomad 2.1.1, Vault 2.2.2, SPIRE 1.14.4 musl tarball). `SHA256SUMS.txt` lists every file. `03-audit.md` and `03-audit-evidence/` were not changed.

| File | What it is |
| --- | --- |
| `manifest-open-962bc89.json` | v2 manifest taken before reading the new commit, in a fresh clone (`/opt/audit/prov2`), HEAD at `ae326b0`, upstream `origin/trunk_dev`, working tree at `962bc89`. SHA-256 `a205eb8d…708d`, byte-identical to the writer's `04-evidence/manifest-v2-repair-962bc89.json`. |
| `manifest-close-962bc89.json` | The same manifest taken again at closeout (19:42Z, and once more at 19:45Z after the last read with the same bytes). Byte-identical to the opening one. |
| `diff-dac9736-962bc89.diff.txt` | `git diff dac9736 962bc89`, the whole difference between the head audited in `03-audit.md` and the new head. |
| `diff-dac9736-962bc89.stat.txt` | `git diff --stat` of the same range and the exit status of `git diff --check`. |
| `refs-and-hashes.txt` | The one commit in the range with its parent and tree, the remote refs at closeout, the SHA-256 of the three PR files at both heads, the SHA-256 of the cited document, and the check that `.docs` is unchanged since the base. |
| `test-tree-962bc89.txt` | Identity of the separate tree the checks below ran on (commit, tree, clean status, file hashes). |
| `head-962bc89-fmt-vet.log` | `gofmt -l es/app` (empty) and `go vet ./es/app` for linux/amd64 and darwin/arm64 on `962bc89`. All exit 0. |
| `head-962bc89-three-tests.log` | One run of the three repaired tests on `962bc89`, as user `ci` with the environment of `03-audit-evidence/container-env.sh.txt`. All pass. Structured service lines removed (`grep -v '"event":"'`, 189 lines), nothing else edited. |

A scan of this folder for token-like strings, private keys, e-mail addresses and phone numbers found nothing (one false positive, a timestamp).
