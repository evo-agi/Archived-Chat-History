# ES PR #17: audit addendum for the new head 962bc89

Addendum to `03-audit.md` (SHA-256 `b8a203ef0fb9c77619c487b335a9ffa1feb3df38c7b85579b4a15860cc518c61`, verdict `ACCEPT` for `dac9736`). Same audit thread, 2026-11-22, 19:39Z to 19:45Z. Read-only: nothing was pushed, commented, edited or merged. `03-audit.md` and `03-audit-evidence/` are unchanged.

**Verdict: `ACCEPT`** for head `962bc8956b4a38e18a7443a66ede2a60254a1ca3`.

The new commit changes one comment line and nothing else. It closes finding NV3-F1. The cited document exists and states the retention the comment refers to. The writer's manifest reproduces byte for byte. No finding is open on this head. The five observations of `03-audit.md` stand unchanged and none requires a change in this PR.

**Head audited:** the PR head was `962bc89` when I recorded it at 19:39Z and still `962bc89` at 19:42Z and 19:45Z (`git ls-remote origin refs/pull/17/head`) and at 19:44Z (GitHub's PR record). This addendum binds those bytes only. A later commit (for example a bring-up script fix) needs its own audit.

## 1. Audit target

| Field | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate`, draft [PR #17](https://github.com/evo-agi/Execution-Substrate/pull/17) into `trunk_dev` |
| Base | `trunk_dev` at `ae326b0ddc30ec6b35883ee32945c622405b68b6` (also `origin/trunk_dev` at 19:42Z) |
| Topic branch and commit | `claude/project-thread-a9tcoa` at `962bc8956b4a38e18a7443a66ede2a60254a1ca3` |
| Tree | `df89aa0c5a13a52598bf12c08d6fab0303156c0d` |
| New commit | `962bc89`, the only commit in `dac9736..962bc89`; its parent is `dac9736ba13d191064d1f129ca40be86d345fb1f`, the head audited in `03-audit.md` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked before each run |
| Canonical manifest | `a205eb8df3bef52dde5069ef193ac56dd03753c9fcadb3daf9783c936052708d` (890 bytes), textual diff `d1b2011935025ee3dfc14b8b048bc3b62314e24c51e72c72acc83df3254e3dd5` |
| Changed paths against the base | 3, all `tracked_modified`, mode `0644`, the same three test files as before |
| Writer manifest | `04-evidence/manifest-v2-repair-962bc89.json`, SHA-256 `a205eb8d…708d` (computed from the file) |

## 2. Provenance reproduction

Done before reading the new commit, in a second fresh clone from GitHub (`/opt/audit/prov2`), with the same steps as `03-audit.md` section 3 and the new commit id.

- `origin/claude/project-thread-a9tcoa` and `refs/pull/17/head` both give `962bc89`. The base `ae326b0` is an ancestor. The checkout was clean before the reset.
- Two manifest runs are byte-identical and equal to the writer's `04-evidence/manifest-v2-repair-962bc89.json` (`cmp`, exit 0).
- Closing manifest at 19:42Z, and once more at 19:45Z after the last read: byte-identical to the opening one (`03-audit-addendum-evidence/manifest-open-962bc89.json`, `manifest-close-962bc89.json`).

## 3. The difference between the two heads

`git diff dac9736 962bc89` is one file, one line removed and one line added (`diff-dac9736-962bc89.diff.txt`); `git diff --check` exits 0.

```diff
@@ -246,7 +246,7 @@
 	// The staging root holds exactly the two successful run roots plus the one
 	// exclusive startup probe directory/symlink pair that ES retains by
-	// contract (.docs/execution_lifecycle/capability_probing.md); nothing else.
+	// contract (.docs/system_overview/capability_probing.md); nothing else.
 	runNames := retainedStageRunRoots(t, filepath.Join(stack.rootDir, "es-stage"))
```

- The changed line is `es/app/staging_cleanup_integration_test.go:249`, inside a `//` comment. No statement, assertion, helper, build tag or import changed, and the line count is the same.
- File hashes at both heads (`refs-and-hashes.txt`): the staging test file goes from `125f3daf…0cac` (13023 bytes) to `ce49d5bc…f7eb` (13019 bytes), which is the four characters by which the new path is shorter. `es/app/submit_integration_test.go` (`91a8f650…cd1b`) and `es/app/supported_local_proof_validation_test.go` (`f645c58f…31b2`) are byte-identical at both heads.
- No product code, script, workflow or document is in the range.

## 4. The cited document

- `.docs/system_overview/capability_probing.md` exists at `962bc89` (blob `817274dc`, SHA-256 `f066dfc0…3074`). `.docs` has no difference between the base `ae326b0` and `962bc89`, so these are the lines I verified in `03-audit.md`.
- The old path `.docs/execution_lifecycle/capability_probing.md` appears nowhere in the tree at `962bc89` any more (`git grep`, exit 1).
- What the document says, read again at `962bc89`:
  - lines 224-228: "The isolated candidate retains its small exclusively created startup probe fixtures under the configured roots. […] the probe does not delete those names. This is a bounded capacity cost, not a reclamation policy or a runtime read probe."
  - lines 314-315: "retain the exclusive startup probe fixtures when exact effect-time deletion identity cannot be proved; no pathname cleanup or recursion is selected."
  - lines 324-326: "the exclusive startup fixtures remain under the configured roots until a separately governed reclamation rule exists."
- So the document supports the comment's claim that ES retains the startup probe fixtures by contract. The document does not name the fixtures. Their exact shape on staging, one directory `.execution-substrate-staging-probe-<token>` plus one link `<that name>-symlink`, comes from the code at `es/admission/execution_roots.go:457-491`, unchanged in this range. The comment words this correctly ("probe directory/symlink pair that ES retains by contract"): the retention is the contract, the pair is what the code creates. I do not count this as a finding.

## 5. Findings

- **NV3-F1 (low, patch defect): closed** by `962bc89`. The correction is exactly the one `03-audit.md` required.
- **Open findings on `962bc89`: none.**
- **Observations NV3-O1 to NV3-O4:** unchanged. None requires a change in this PR.
- **Observation NV3-O5 (merge-gate note):** now covers three commits. The message of `962bc89` also carries a model-name trailer and a session link, like `01cd1b1` and `dac9736`. Squash with the PR title, as before.

## 6. Validation

Ran myself on a separate tree at `962bc89` (`test-tree-962bc89.txt`: commit, tree and the three file hashes match the manifest, status clean), as user `ci` with the environment recorded in `03-audit-evidence/container-env.sh.txt`:

| Check | Result |
| --- | --- |
| `gofmt -l es/app` | empty, exit 0 |
| `go vet ./es/app`, linux/amd64 and darwin/arm64 | exit 0 for both |
| The three repaired tests, one run | all pass: stage roots 15.85 s, symlink archive 4.85 s, supported-local 7.84 s; `ok execution-substrate/es/app 28.557s`, exit 0 |
| Leftover `/tmp/esls-*` after the run | none |

**Not run on `962bc89`:** the whole `es/app` package, the 23 mutants, the 33 synthetic inventory cases, the base comparison, the GitHub runner, macOS execution, `-race`.

**Why the results of `03-audit.md` carry over.** The only bytes that differ from `dac9736` lie inside one Go comment in a test file, and the line count is unchanged. Inference: every test result, mutant verdict and contract comparison in `03-audit.md` therefore applies to `962bc89` as well. This rests on the Go rule that a comment changes what is built or tested only when it is a directive (`//go:…`, `//line`, a build constraint, a cgo preamble) or an `// Output:` line of an example function. The changed line is none of these: it is the third line of an ordinary comment inside the body of a test function. The one run of the three tests above is a direct check on the new bytes in addition.

**PR description.** Read at 19:44Z: it says the third commit fixes a document path in a test comment and changes nothing else, and it gives the manifest `a205eb8d…708d` for `962bc89`. Both statements match what I found. GitHub reports the PR as an open draft with head `962bc89`, base `ae326b0`, 3 commits, 3 changed files, +182 −21.

## 7. Sensitive-material handling

The supported-local test creates a Vault dev token, TLS keys and SPIRE material under `/tmp/esls-*` and removes them at cleanup. None was opened, printed or copied. The test log has service log lines removed. A scan of the new evidence folder found nothing sensitive.

## 8. Remaining uncertainty and stop conditions

- GitHub lists no check run for the PR head `962bc89` (read at 19:44Z). Unknown: whether a probe branch ran these bytes on the runner; I did not look. For a comment-only change I do not consider a runner run necessary.
- PR #17 has no CI check of its own until PR #14 merges.
- Stop condition for the merge gate: the PR head must still be `962bc89`. A script or test-logic change needs a full audit of the new head.
- Red-team scope is the coordinator's decision. This patch changes tests only.

## 9. Confidence

- **Provenance: high.** Manifest reproduced byte for byte from GitHub, twice, and again at closeout; PR head checked at the start and at the end.
- **Validation: high in the container, medium-high for the runner**, as in `03-audit.md`. The runner passes are the writer's and are for `dac9736`.
- **Implementation: high.** The whole difference is one comment line, read in full, and the cited document was read again at the new head.

## 10. Effect status

No repair, commit, push, comment, PR change or merge was performed. `REPAIR_NOT_PERFORMED`, `PUSH_NOT_PERFORMED`, `MERGE_NOT_PERFORMED`.

## 11. Report delivery

`/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/03-audit-addendum.md` (SHA-256 in the thread reply) and `03-audit-addendum-evidence/` (`README.md`, `SHA256SUMS.txt`).

## 12. Final verdict

**`ACCEPT`** for `962bc8956b4a38e18a7443a66ede2a60254a1ca3`, manifest `a205eb8df3bef52dde5069ef193ac56dd03753c9fcadb3daf9783c936052708d`. No finding open; NV3-F1 closed; five observations carried over from `03-audit.md`, none requiring a change in this PR.

STATUS: READY (follow-up audit of PR #17 done, verdict ACCEPT for 962bc89; nothing running)
