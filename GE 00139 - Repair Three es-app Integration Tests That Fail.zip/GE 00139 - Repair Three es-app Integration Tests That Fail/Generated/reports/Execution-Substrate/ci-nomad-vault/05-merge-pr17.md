# ES PR #17: merge report

Report 05 of the CI Nomad/Vault track. Merge gate per `claude-conversion/claude-operating-protocol.md` §15 and `claude-conversion/provenance-and-audit-evidence.md` §5.4. Date: 2026-11-22, 20:2xZ.

```text
MERGE REPORT
Repository: evo-agi/Execution-Substrate
Accepted audit target: claude/project-thread-a9tcoa at 962bc8956b4a38e18a7443a66ede2a60254a1ca3,
  base trunk_dev at ae326b0ddc30ec6b35883ee32945c622405b68b6,
  manifest v2 a205eb8df3bef52dde5069ef193ac56dd03753c9fcadb3daf9783c936052708d
Audit reports: ci-nomad-vault/03-audit.md (ACCEPT for dac9736),
  SHA-256 b8a203ef0fb9c77619c487b335a9ffa1feb3df38c7b85579b4a15860cc518c61;
  ci-nomad-vault/03-audit-addendum.md (ACCEPT for 962bc89, NV3-F1 closed),
  SHA-256 410ad46105a10ed967aa1129dd2606c28c792d6d0295ce1760ff2f1ac7fdfec8
Implementation reports: ci-nomad-vault/02-repair-tests.md; 962bc89 and its manifest in
  ci-nomad-vault/04-bringup.md section 2
PR: https://github.com/evo-agi/Execution-Substrate/pull/17
PR head before the merge: 962bc8956b4a38e18a7443a66ede2a60254a1ca3 (git ls-remote
  refs/pull/17/head and GitHub's PR record); equal to the audited commit: yes.
  The merge call carried expectedHeadSha = that SHA.
Branch update performed: no. trunk_dev was still ae326b0, the audit base; GitHub
  mergeable_state "clean". No range-diff or re-audit needed.
David's go: project chat 2026-11-22 20:18:51Z (cmsg_01Un4xQgjBAczV8DABQvcLrxA82vvW23RqvPsL8HWgMcY6),
  relayed by the coordinator at 20:19Z: "I won't be reviewing test-only changes. Please
  merge without asking." PR #17 changes three _test.go files only.
Merge: squash (the repository's usual style), title "Repair three es/app integration tests
  that fail since #8 (#17)", no model name in the message.
Merge commit and resulting trunk_dev: b8d6bc3abb8c8c38481c7835824bd79ba26e467b,
  parent ae326b0ddc30ec6b35883ee32945c622405b68b6.
Post-merge byte check: for each of the 3 manifest paths, the blob in origin/trunk_dev has
  the manifest's SHA-256, size and mode 100644 (staging_cleanup_integration_test.go
  ce49d5bc…, 13019 B; submit_integration_test.go 91a8f650…, 121751 B;
  supported_local_proof_validation_test.go f645c58f…, 27523 B). The merged tree
  df89aa0c5a13a52598bf12c08d6fab0303156c0d equals the audited head's tree.
Unauthorized effects: none. The PR was marked ready, then squash-merged. No branch was
  deleted (claude/project-thread-a9tcoa still at 962bc89); no other repository, branch
  or service touched.
Remaining limitations: trunk_dev has no CI workflow until PR #14 lands, so no check ran
  on the merge; the runner evidence is the probe runs in 02-repair-tests.md. PR #18
  (bring-up) is based on ae326b0 and touches none of these files; when its audit is
  done, updating it with trunk_dev needs a new manifest and a provenance-only re-check.
Report delivery: ci-nomad-vault/05-merge-pr17.md (this file; SHA-256 in the thread reply).
```
