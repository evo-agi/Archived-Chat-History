# Evidence for 03-audit.md (ES PR #17, head dac9736)

Everything here was produced by the audit thread on 2026-11-22 between 19:05Z and 19:35Z in a cloud container (Ubuntu 24.04.5, kernel 6.18.44, 4 CPUs, Docker 29.10.0 on cgroup v1, Go 1.26.5, Nomad 2.1.1, Vault 2.2.2, SPIRE 1.14.4 musl tarball). `SHA256SUMS.txt` lists every file.

Log files have the structured service lines removed (`grep -v '"event":"'`), as in the writer's evidence. Nothing else was edited. A scan of this folder for token-like strings, private keys, e-mail addresses and phone numbers found one match, a Python class name in `mutant-C5-python-unit-test.log` (false positive).

## Provenance

| File | What it is |
| --- | --- |
| `manifest-open.json` | v2 manifest taken before reading code, in a fresh clone, HEAD at `ae326b0`, upstream `origin/trunk_dev`. SHA-256 `cde984e7…0735`, byte-identical to the writer's `02-evidence/manifest-v2-repair-dac9736.json`. |
| `manifest-close.json` | The same manifest taken again at closeout. Byte-identical to `manifest-open.json`. |

## Environment

| File | What it is |
| --- | --- |
| `container-env.sh.txt` | Environment of every test run (user `ci`, `env -i`, no proxy variables, `AWS_EC2_METADATA_DISABLED=true`, `umask 022`). |
| `t.sh.txt` | The wrapper that runs `go test` as `ci` and appends the exit status to the log. |
| `tip-fmt-vet-tools.log` | `gofmt -l es/app` (empty), `go vet ./es/app` (clean), tool versions. |
| `tip-compile-checks.log` | `go vet` and `go test -c` of `es/app` for darwin/arm64 and linux/amd64, `gofmt`, `git diff --check`. All exit 0. |

## Test runs

| File | Tree | Result |
| --- | --- | --- |
| `tip-three-pass1.log` | head `dac9736` | The three repaired tests pass. |
| `tip-three-count3.log` | head | `-count=3`: all nine runs pass. |
| `base-three.log` | base `ae326b0` | All three fail with the messages the writer reported. |
| `tip-es-app-whole-package.log` | head | Whole `es/app`: 158 pass, 2 fail (`TestBringupScriptUpCheckDownFullProfile`, `TestSubmitFlowMountsGovernedArtifactAndLifecycleWithInstalledSourceIdentity`), 0 skip, 351.7 s. |
| `root-package-failing-tests-tip.txt`, `root-package-failing-tests-base.txt` | head, base | `go test .` fails the same 9 tests on both trees (tests that need macOS paths; PR #14's list covers that class). The two files are identical. |

## Mutants and synthetic cases

| File | What it is |
| --- | --- |
| `mut.py.txt` | The mutant runner and the 23 mutant definitions. Mutants change product code only (Go under `es/`, `scripts/72_supported_local_setup.sh`, the Python roots helper), never a test file. |
| `mutants-summary.log` | One line per mutant: exit status, time, verdict, first failing assertion. |
| `mutants/<name>.diff.txt`, `mutants/<name>.log` | The exact product diff of each mutant and the test output. |
| `mutant-C5-python-unit-test.log` | Mutant C5 (source-tree refusal removed) is not seen by the Go test by design; this shows the existing Python unit test fails on it. |
| `base-second-defect.diff.txt`, `base-second-defect.log`, `base-second-defect-summary.log` | Base tree with only the source-tree refusal removed: the unrepaired test then fails with `install: … are the same file`. This confirms the second defect on the base bytes. |
| `zz_audit_inventory_test.go.txt`, `inventory-helper-cases.log` | 33 synthetic staging-root inventories run against the new helper `retainedStageRunRoots`. The scratch test was placed in the scratch tree only and removed afterwards. |

## Not here

The GitHub runner was not used by the audit (the audit pushes nothing). The writer's runner log `02-evidence/runner-repair-probe1-run-45055948469-job-137311079534.log` was read and checked against its claims.
