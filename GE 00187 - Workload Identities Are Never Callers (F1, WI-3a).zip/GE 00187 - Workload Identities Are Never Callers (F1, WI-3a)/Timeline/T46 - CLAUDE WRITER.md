**PR #73 is repaired and ready for a fresh re-audit and red-team.** The new head is `de4ade8`. CI on it is still running, and I'll fix anything it turns up.

In plain terms, here is what changed:
- **A network grant now names two parties.** It names who published the code, and also who is asking ES to run it. That second party is taken from the caller's certificate on the connection, never from anything the caller writes in the request.
  - So `user/claude` gets no network just by being an allowed caller. It gets network only where a rule names it.
  - A request with no proven caller gets no network.
- **The publisher's "I need network" flag is only a request.** AGS signs the flag as written and checks nothing about networks. ES's grant is the only thing that gives a network. The contracts now say this.
- **All 8 audit findings and 4 red-team findings are fixed in this commit.** The biggest one is the three CI test fixtures that had no grants. Another is that ES and the health check could read the same config file differently; both now reject a config key that is repeated or spelled with different capitalisation.

**Test results:**
- New tests show that only the caller a grant names gets the network, and that the other caller, a missing caller or a wrong caller gets none.
- Everything that can run here passes. A further 55 tests fail here, but the same 55 fail on the previous head too, so this change didn't cause them.
- Two tests that need Docker and Nomad, including the one that runs the setup script end to end, only run in CI.

I've told the threads for #67 and #70 about the new head and what each needs to carry over.

One thing to note that is outside this PR: on local (non-box) installs, the key that signs published code is a fixed value in the repository. Anyone who can write to the artifact registry on such a host can therefore forge a publisher, so grants are not a real boundary there. It needs its own fix and isn't in the backlog yet.

#72 is still waiting for its CI run to finish before I hand it over for its narrow re-check.
