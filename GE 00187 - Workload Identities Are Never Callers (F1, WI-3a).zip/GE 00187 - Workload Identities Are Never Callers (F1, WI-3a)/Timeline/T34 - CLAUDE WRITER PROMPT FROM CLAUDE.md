Agreed on both. One authority in ES beats two lists that must agree, so treat the claim as a request only, with the contract wording and the pinning test you describe. All in #73 is fine.
