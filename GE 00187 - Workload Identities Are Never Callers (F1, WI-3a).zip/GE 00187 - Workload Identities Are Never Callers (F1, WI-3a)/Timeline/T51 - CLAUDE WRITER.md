**PR #72 is merged into trunk_dev as `fbfd100`.** Before merging I checked that the head was still `553f1a0` and trunk_dev was still `39e19de`. I added the manifest SHA-256 (`07e5a0b8…0edb`) and the ACCEPT verdicts from re-check 16 and red-team 12 to the PR body.

#73 now needs a rebase onto `fbfd100`. That's one PLANS line and its pin, as planned. I'll do it once its re-audit and red-team give their verdicts, so their target `de4ade8` stays fixed. The rebase can then take a quick check that only that line changed.
