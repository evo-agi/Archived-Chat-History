# Writer report 13: ES PR #72 (WI-3a), re-audit and red-team nits

Date: 2026-11-26 (about 7:35 PM Eastern). Writer: the "Design per-workload identity and network approval" thread.

## Target

| Item | Value |
| --- | --- |
| PR | evo-agi/Execution-Substrate #72, base `trunk_dev` |
| Base | `39e19defb0ea6c0bda30a14f88452b24f9bd9cdf` |
| Previous head (re-audit 12, red-team 12) | `c68cd50f0a5a5117cfae28f315c9a5c0816d933a` |
| New head | `553f1a0bc636ce9bd8d63b202b6671cf1481672d` (one commit on top) |
| New head tree | `a8a95252fe41c393d165ac1e661f99d7f96513cc` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified) |
| Canonical manifest SHA-256 (base `39e19de`, upstream `origin/trunk_dev`, two runs, `cmp` identical) | `07e5a0b8f5d5c9aa452d4ecd6ec322cce7847bb4a19635907792dfdfea900edb` |
| `git diff 39e19de 553f1a0 \| sha256sum` | `c91dae8b03729361eb0f2680bab23cec29c0792a8c796c3153f0f204e12a4f01` (13 files, +209 / -42) |
| `git diff c68cd50 553f1a0 \| sha256sum` (this repair only) | `0300cb8ee81c2ab1faf17e93b1a3a9923977ad6aebae8b469067072abcf32328` (4 files) |

Full manifest: `13-pr72-nits/pr72-553f1a0-manifest-v2.json`. Steps as in report 09: clean tip, `reset --mixed` to the base with upstream `origin/trunk_dev`, two runs into a fresh `0700` directory outside the repo, `cmp`, `reset --mixed` back to the tip, clean status again.

## Fixes

| Finding | Fix | Pinned by |
| --- | --- | --- |
| Re-audit 12 R1: `PLANS.md:305` restated the prefix rule without the workload exclusion | "a prefix must be a canonical SPIFFE ID path of at least two segments whose first segment is not `workload` in any letter case, and a prefix that fails the rule matches nothing." | new sentence in the "PLANS restates the workload exclusion" assertion |
| Red-team 12 RT-N1: section 3A and the `callerauth.go` comment claimed "no near-miss" | 3A: "... so no configuration can name a workload identity in another letter case. It closes letter-case variants only: a different word, such as `workloads/x` or `work-load/x`, is a different SPIFFE ID and stays a valid path." The comment says the same. | new sentence in the 3A assertion |

No code path changed: the only Go product change is the comment in `internal/callerauth/callerauth.go`.

## Validation

- `go vet` passes for `.` and `./internal/callerauth`; gofmt is clean.
- `go test -count=1 . ./internal/callerauth/...` passes.
- Deletion probes, each run against `TestWorkstreamFF1IsPlannedAndPointedTo` and restored afterwards: removing the PLANS clause fails it; removing the new 3A sentence fails it.
- PLANS.md is 149,264 bytes.
- CI on 553f1a0: see the delivering message.

## Notes

- The PR body is updated: head, review history, red-team run separately.
- RT-O3 (the private submit handoff takes its peer as a go-spiffe `spiffeid.ID`) goes to the brief of the PR that gives that handoff a listener. The peer should be a `callerauth.SPIFFEID`, with a test that a workload ID is refused there.
