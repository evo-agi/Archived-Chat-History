# Independent re-audit 12: ES PR #72 at c68cd50, workload identities are never callers (F1, WI-3a)

Date: 2026-11-26, about 7:30 PM Eastern (00:30Z on 11-27). Auditor: the fresh thread "Re-check the workload caller PR 72". It has not written, repaired or audited this PR before (protocol section 14). Brief: the coordinator's spawn note (23:58Z).

**Final verdict: BLOCK** on one nit (R1). Nothing Critical, High, Medium or Low.

- The code is accepted. It is token-identical to the audited 5dfcc1c; the only product-file change is a comment reflow.
- 12 of 12 code mutants are killed.
- A1 and N1 to N4 are fixed, and the new pins hold: 11 of 13 docs probes are killed, and the 2 survivors are observations.
- The whole suite shows the same 14 failing top-level tests on head and base, all of them environment-only.

R1 is one clause: `PLANS.md:305` restates the allowlist-prefix rule without the workload exclusion, and the repair's new test comment says every restatement carries it. Under the standing rule "Low nits fixed in-PR", the head as it stands should not merge.

A narrow re-check is enough after the fix: that line and its pin, provenance, and the root package. The red-team target is not affected, because no code changes.

Effect status: no repair, no commit, no push, no PR comment, no merge. Nothing posted on GitHub.

## 1. Audit target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| PR | #72, branch `claude/wi-3a-workload-caller-refusal`, base `trunk_dev` |
| **Verdict target (head)** | `c68cd50f0a5a5117cfae28f315c9a5c0816d933a` (one repair commit on `5dfcc1c`) |
| Head tree | `6d9caa87ec0dcef00e63e875b2f89e68e4af8cbf` |
| Base | `trunk_dev` = `39e19defb0ea6c0bda30a14f88452b24f9bd9cdf`, tree `178defa90f883644497e6fc97573ffdf35d3f39c` (unchanged at 00:22Z) |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (checked before the opening and the closing runs) |
| Canonical manifest SHA-256 | `856536535e1e2b9acef94d3d3f235243221d24a7dff7d78664d836182c213892` |
| Recipe textual-diff SHA-256 | `95c356d13367af18710a51687612ced6cc196a602834768981a9396afd08f105` |
| `git diff 39e19de c68cd50 \| sha256sum` | `d7b428276cbb79682f976ecd65cbd4713234f07d34bb49e4202e406be75ad302` |
| `git diff 5dfcc1c c68cd50 \| sha256sum` (repair only) | `60d83d10c002af7afe45845087e7aa687d49e40359093f9795be0f3f0b9f88d0`, 7 files, +44 / -20 |
| Changed paths | 13, all `tracked_modified`, mode 0644: 4 product Go files, 4 test Go files, 4 docs, `PLANS.md` |
| Inputs | audit 08 (SHA-256 `f1ca3acf…6516`), writer report 09 (`daeb6424…1334`), writer manifest `09-pr72-repair/pr72-c68cd50-manifest-v2.json` (file SHA-256 `85653653…3892`) |

## 2. Provenance reproduction

- Steps: provenance guide section 5.3 in a fresh clone under `umask 022`, fetched from GitHub. The checks were `test "$(git rev-parse origin/$TOPIC)" = "$TIP"`, `git merge-base --is-ancestor`, `git checkout -f -B`, a clean status, `git reset --mixed 39e19de` and the upstream pinned to `origin/trunk_dev`. Then v2 ran twice into a fresh `0700` directory outside the repo.
- Run 1 equals run 2 (`cmp`). Both equal the writer's manifest byte for byte, so the canonical SHA-256 is `85653653…3892`, with 13 file records.
- At closeout I deleted the three local branch refs I had created for bundling and ran v2 again: closing = opening (`cmp`). No tolerated mode-bit differences.
- The PR head is still `c68cd50` and `trunk_dev` is still `39e19de` (`git ls-remote` at 00:22Z).
- **Code unchanged since 5dfcc1c.** I compared the `go/scanner` token streams (comments skipped) of 5dfcc1c and c68cd50 for every Go file the repair changed:
  - `internal/callerauth/callerauth.go`: equal (1,128 tokens). This is the only product file the repair touched.
  - `internal/callerauth/callerauth_test.go`: equal.
  - `callerallowlist_test.go` and `workload_grants_docs_contract_test.go`: not equal. These hold the intended test edits, read in full below.
  - The other three product files (`cgs/policy/idfile.go`, `internal/callerallowlist/callerallowlist.go`, `callerauthtest.go`) are untouched by the repair.
  - So the product code is the code audit 08 inspected, mutated and accepted.

## 3. Posture and coverage

- Read-only. No subagents. The provenance clone was left as found. Tests, probes, mutants and trial merges ran in separate clones owned by an unprivileged local user `ci` (uid 1500, gid 1600). They ran under `env -i` with no proxy or tokens, `umask 022`, `GOPROXY=off`, Go 1.26.5 (the `go.mod` toolchain), and HUP/INT/QUIT/TERM/PIPE reset to default.
- Read:
  - the project instructions, `INDEX.md`, `procedures.md`, the operating protocol (sections 12 to 15) and the provenance guide (sections 5 and 8);
  - audit 08, writer report 09, the PR body and comments.
- Inspected:
  - the whole PR diff `39e19de..c68cd50` and the repair diff in full;
  - the only constructors of `callerauth.SPIFFEID` and `callerauth.Caller` (for N3's structural claim);
  - every doc and script in the tree that restates the caller identity or the allowlist-prefix rule. I searched for "URI SAN", "conforming SPIFFE", "identifies a caller", "path segments", "two segments", "single-segment", "allowlist-prefix", "exact-or-subpath", "caller identity", `allowed_spiffe_path_prefixes` and `callerauth`, with `.docs/history` excluded;
  - CI runs on every head of this PR;
  - the open PR heads, for trial merges.
- Not re-inspected: the five services' authentication paths, the shipped allowlists and `id.conf`. Audit 08 covered those at 5dfcc1c, and they cannot differ, because the code is token-identical and the repair touches no config, script or example. The live box is out of scope (audit 08's O4 still applies). macOS beyond CI, which was running at the time of this report.

## 4. The repair, finding by finding

| Audit 08 item | At c68cd50 | Verified by |
| --- | --- | --- |
| A1: lifecycle `contracts.md` caller identity definition | `.docs/execution_lifecycle/contracts.md:261-270` now reads "whose first segment is not `workload` in any letter case", and lists `spiffe://execution.internal/workload/codex-agent` among the `401` cases. Accurate against `callerauth.go:105-107`. | probes P04 and P05 killed |
| A1: lifecycle ES prefix rule | `:275-280` adds "no first segment `workload` in any letter case". Accurate against `callerallowlist.go:44-49`. | P06 killed |
| A1: system `contracts.md` section 7 | `:819-826` adds the exclusion, with `workload/codex-agent` as an invalid example. | P07 and P08 killed |
| A1 (optional part): `PLANS.md:304` | "... `execution.internal` and not a workload identity, identifies a caller". | P09 killed |
| A1 (optional part): `PLANS.md:305` | **not changed**, see R1 | — |
| N1: stale comment | deleted; `referenceAccepts` has one doc paragraph | diff |
| N2: package doc wrap | reflowed; the token stream is unchanged | token comparison |
| N3: assertion that cannot fail | dropped, with a comment saying the guarantee is structural. The claim holds: `ParseSPIFFEID` (`callerauth.go:108`) is the only place a non-zero `SPIFFEID` is built, after the workload check, and `CallerFromConnectionState` builds a `Caller` only from its result (`:183-187`). Mutant C08 shows the test still kills a dropped allowlist branch without that assertion. | C08 killed by `TestValidatePrefixRefusesWorkloadIdentities` |
| N4: three unpinned sentences | pinned: the configuration bullet (P01), the 11.2 "implemented" sentence (P02) and the 3A near-miss sentence (P03) | P01, P02 and P03 killed |

The writer report's other claims hold:
- PLANS.md is 149,207 bytes.
- There are 13 files.
- The manifest, textual-diff and diff hashes are as stated.
- gofmt is clean and `go vet` passes. I reran both on the head tree for `.`, `./internal/callerauth/...`, `./internal/callerallowlist/...`, `./cgs/...`, `./ags/...`, `./ars/...`, `./egs/...`, `./es/api/...` and `./es/config/...`.

## 5. Findings

### R1 (nit, test/doc gap; patch defect introduced by the repair): one restatement of the prefix rule still omits the workload exclusion, and a new test comment says none does

Current contract: `.docs/system_overview/contracts.md` section 3A. Project rule: a behaviour change updates every doc that restates the changed rule (`procedures.md`, Docs and READMEs), and Low findings and nits are fixed in-PR.

- `PLANS.md:305` (unchanged by the PR): "ARS, AGS, and ES check their configured path-prefix allowlists at startup ... (same section 3A): a prefix must be a canonical SPIFFE ID path of at least two segments, and a prefix that fails the rule matches nothing." The prefix `workload/codex-agent` meets that description and is refused at startup. This is the same class as the `PLANS.md:304` line the repair fixed. Audit 08's A1 correction named "`PLANS.md:304-305`" (optional).
- `workload_grants_docs_contract_test.go:202-203` (new in the repair): "Every page that restates the caller identity or the allowlist-prefix rule restates the workload exclusion too." `PLANS.md:305` is such a restatement, and the test does not check it. The writer's grep in report 09 searched for "two non-empty path segments", which `PLANS.md:305` does not contain ("at least two segments").
- The line survives #69: after a trial merge with #69's head `1160f28` it is `PLANS.md:303`.
- Checked and not affected:
  - `.docs/system_overview/boundaries.md:972` and `architecture.md:96` point to section 3A instead of restating the rule;
  - `configuration.md:284-298` lists the workload refusal as its own bullet in the same list;
  - the noninteractive healthcheck doc compares one expected identity.

Impact: documentation only, behaviour pinned by Go tests. A reader of `PLANS.md` alone would think a `workload/...` prefix is valid. The test comment overstates what the pins guarantee.

Required correction (one of):
- add the exclusion to `PLANS.md:305`, for example "a prefix must be a canonical SPIFFE ID path of at least two segments whose first segment is not `workload` in any letter case", and pin it next to the `PLANS.md:304` pin (about +60 bytes, so PLANS.md stays near 149,270);
- or narrow the comment to the pages the test checks.

The first matches the repair's own intent.

Uncertainty: none about the fact. Whether a nit blocks is the standing rule's call, applied here as in audit 08.

### Observations (not blocking; route as noted)

- **O1 (docs pins, informational):** two explanatory 3A sentences from 5dfcc1c are free to drift.
  - P10 deletes "The comparison ignores letter case on purpose, so no configuration can name a near-miss of a workload identity."
  - P11 deletes "That covers the shared workload ID ..., the named workload identities ..., and the per-run identities reserved below them (... section 11.2)."
  - Both survive the root package.
  - Their content follows from the pinned rule sentence "A caller whose path starts with the segment `workload`, in any letter case, has no caller identity, at every service", and Go tests pin the behaviour.
  - Not raised as a finding: sentence pins cannot cover every sentence, and these add no rule of their own. If the writer touches the pin list for R1 anyway, pinning them costs two lines.
- **O2 (flaky fixture, pre-existing, unrelated):** in the whole-suite run on head, one subtest failed that passed on base: `scripts TestRemoteAlphaESServiceTLSStatusFailureWitnessBootstrapOwnedTerminal/artifact-registry/fixture_read_fault`.
  - Its parent test fails on both trees here, as an environment-only failure.
  - The output was `FIXTURE_CLEANUP child_reaped=true terminated=false`: the child had already exited when the fixture's cleanup checked it, so it was not "terminated".
  - It did not reproduce. Each of the two subtests ran 30 times alone and 30 times under six busy loops, on head and on base. That is 240 runs, all passing.
  - The fixture is a Python probe in a test file the PR does not touch.
  - Inference: a timing race in the fixture under whole-suite load, when the child exits on its own before cleanup runs.
  - Route: test-robustness backlog, if it recurs in CI.
- **O3 (merge gate, CI):** "build, vet and test" has **never completed on any head of this PR**. The runs on 5e0916f, a55d8bb, a3710c0 and 5dfcc1c were all cancelled by the next push. Run 336 on c68cd50 (job 140228695618) and "test on macOS" run 83 (job 140228716034) were still in progress at the time of this report (see section 7). "test on macOS" passed only on a3710c0, a different tree. The gate needs a green Linux run on the final head.
- **O4 (PR body):** the body is stale:
  - it says "the head is 5dfcc1c";
  - it says "per the design its red-team is folded into WI-3's", but the coordinator has since decided on a separate red-team;
  - it says "the full `es/admission` and `es/app` suites are left to CI", and CI has not completed on any head.
  - Update it before merge, in particular if the squash message is taken from the body.
- **O5 (11.10 row):** `runtime_identity_handoff.md:411` lists WI-3a's gate as "Audit and the merge gate". The writer calls it a minimum. That reading is fair, and it is the coordinator's call whether the row should name the red-team.
- **O6 (merge order, pre-existing; audit 08 O6 confirmed at current heads):** `PLANS.md` size cap 150,000.
  - `trunk_dev` + #70 (`77027f8`) is 150,155 bytes without #72 and 150,237 with it.
  - `trunk_dev` + #67 is 150,133 bytes without #72 and 150,215 with it.
  - #69 brings PLANS.md to 130,607 and should land first.
- **O7:** #73 (`affefc6`) still conflicts in `PLANS.md` and `workload_grants_docs_contract_test.go`, as both writers expect (audit 08 O7).
- Audit 08's O2, O3 and O4 stay routed as report 09 says (WI-3 brief and box upgrade brief). Nothing in the repair changes them.

## 6. Validation

All runs as `ci` on the exact trees (head `6d9caa87`, base `178defa9`). Scripts are in the evidence folder.

| Run | Result |
| --- | --- |
| `go test -count=1 -timeout 40m -json ./...`, head | exit 1, 430 s. 49 packages (28 pass, 18 no tests, 3 fail). 10,295 entries: 10,114 pass, 46 fail, 135 skip |
| same, base | exit 1, 371 s. 10,176 entries: 9,996 pass, 45 fail, 135 skip |
| head vs base | The same 14 failing top-level tests (listed below; identical to audit 08's list). Failing entries 46 vs 45: the one extra is the O2 subtest (pass → fail, not reproduced in 240 reruns). 162 entries only at head, all pass: the four refused workload cases in every service's route test, the callerauth and callerallowlist cases and fuzz seeds, the two new tests, plus 43 randomly named PR 12 red-team subtests in `es/admission` that also appear, with other names, only at base. No other test changed status. |
| root package `.` | pass on head (623 tests, includes the F1 status tests, the new pins and the PLANS cap) |
| `gofmt -l` on the 8 changed Go files, `go vet` (9 package patterns, section 4) | clean |

The 14 failing top-level tests, identical on head and base. They are environment-only in this container: no Nomad, Vault, SPIRE or Docker daemon, no older binaries, not the box account.
- `es/admission/internal/reliablesubmit`: `TestOperationalHandoffSchema4BinaryRefusesSchema5`, `TestSQLiteV3OldBinaryRefusesWithoutMutation`, `TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation`.
- `es/app`: `TestLinuxSetupBootstrapFinishesWithItsSavedSecret`, `TestNomadACLToolRetriesABootstrapThatNeverTookEffect`.
- `scripts`: `TestRemoteAlphaESServiceTLSStatusFailureWitnessBootstrapOwnedTerminal`, `TestRemoteAlphaESServiceTLSStatusRootLoadedStageCustody`, `TestRemoteAlphaESServiceTLSStatusStageFIFOSubstitution`, `TestRemoteAlphaOperatorRecoverySessionESTLSStatusRemoteWrapperTrap`, `TestRemoteAlphaOperatorRecoverySessionESTLSStatusStageFIFORefusal`, `TestRemoteAlphaP0tGrammarDiagnosticBootstrapLifecycleComposition`, `TestRemoteAlphaP0tGrammarDiagnosticPriorReaderCloseSuppression`, `TestRemoteAlphaP0tGrammarDiagnosticV2VersionedBootstrap`, `TestRemoteAlphaUpgradeESCheckRefusesWhatItWasNotWrittenFor`.

All failing entries are in `head-failing-entries.txt` and `base-failing-entries.txt`.

### Docs probes (13, each against the whole root package in a clean copy of the head tree)

| ID | Probe | Result (killing test) |
| --- | --- | --- |
| P01 | delete the configuration.md workload prefix bullet (N4) | killed (`TestWorkstreamFF1IsPlannedAndPointedTo`) |
| P02 | delete the 11.2 "This part is implemented" sentence (N4) | killed (`TestWorkstreamFF1NamedWorkloadIdentityDecisionIsDocumented`) |
| P03 | delete the 3A near-miss sentence (N4) | killed (`TestWorkstreamFF1IsPlannedAndPointedTo`) |
| P04 | lifecycle caller identity without the exclusion (A1) | killed (same) |
| P05 | lifecycle `401` list without the workload example (A1) | killed (same) |
| P06 | lifecycle prefix rule without the exclusion (A1) | killed (same) |
| P07 | section 7 prefix rule without the exclusion (A1) | killed (same) |
| P08 | section 7 without "and so is a workload prefix" (A1) | killed (same) |
| P09 | `PLANS.md:304` without "and not a workload identity" (A1) | killed (same) |
| P10 | delete the 3A "comparison ignores letter case on purpose" sentence | **survived** (O1) |
| P11 | delete the 3A "That covers the shared ..." sentence | **survived** (O1) |
| P12 | PLANS F1 status back to "not yet implemented" | killed (`TestF1StatusSentencesAreAllClassified`, `TestWorkstreamFF1IsPlannedAndPointedTo`) |
| P13 | 11.2 says "is not yet implemented: WI-3a lands it" | killed (`TestF1StatusSentencesAreAllClassified`, `TestWorkstreamFF1NamedWorkloadIdentityDecisionIsDocumented`) |

### Code mutants (12, one at a time in a clean copy of the head tree)

They ran against `./internal/callerauth/... ./internal/callerallowlist/... ./cgs/... ./ags/api/... ./ars/api/... ./egs/api/... ./es/api/...`. Every mutant compiled (C11 was rewritten once, because its first form left an unused import).

| ID | Mutant | Result (a killing test) |
| --- | --- | --- |
| C01 | drop the refusal | killed (every service's route test, `TestLoadRefusesWorkloadIdentityPrincipals`) |
| C02 | case-sensitive compare | killed (same) |
| C03 | refuse only the exact path `workload` | killed (same) |
| C04 | no segment boundary (`workloads/…` refused) | killed (`TestParseSPIFFEIDAcceptsConformingIDsInTheTrustDomain`, callerallowlist accepted-prefix tests, the fuzz seeds) |
| C05 | also refuse `workload` as a later segment | killed |
| C06 | refuse only with a second segment | killed |
| C07 | report `ErrMalformedSPIFFEID` | killed (`TestParseSPIFFEIDRefusesEverythingElse`, callerallowlist, cgs) |
| C08 | allowlist: drop the `ErrWorkloadPrefix` branch | killed (`TestValidatePrefixRefusesWorkloadIdentities`) |
| C09 | allowlist: every parse error becomes `ErrWorkloadPrefix` | killed (3 callerallowlist tests) |
| C10 | CGS: workload message on the foreign-domain branch | killed (2 cgs/policy tests) |
| C11 | CGS: workload message for every parse error | killed (`TestLoadRefusesPrincipalsThatNoAuthenticatedCallerCanPresent`) |
| C12 | the segment constant becomes `workloads` | killed |

### Trial merges with the open PRs (`git merge-tree --write-tree c68cd50 <head>`, heads at 00:22Z)

| PR | Head | Merge | Tests on the merged tree (root + the auth, service API and `es/config` packages) |
| --- | --- | --- | --- |
| #73 | `affefc6` | conflict: `PLANS.md`, `workload_grants_docs_contract_test.go` (O7) | not run (writer resolves) |
| #70 | `77027f8` | clean | 2,513 pass; only `TestPlansStaysWithinItsSizeCap` fails (pre-existing, O6) |
| #69 | `1160f28` (moved from `e83f2ba` during this audit; both merged clean) | clean | 2,518 pass, 0 fail (and 2,517 / 0 on `e83f2ba`) |
| #68 | `e760c67` | clean | 2,579 pass, 0 fail |
| #67 | `69d53de` | clean | not run (scripts; PLANS 150,215, O6) |
| #66 | `08143bd` | clean | not run (scripts) |
| #63 | `59f1f56` | clean | not run (scripts) |

## 7. CI

At the time of this report:
- "build, vet and test" run 336 on `c68cd50` was in progress (started 23:58Z).
- "test on macOS" run 83 was in progress (started 00:07Z after queueing).

Earlier heads: every Linux run was cancelled, and macOS passed on `a3710c0` only (O3). The coordinator should confirm both are green on the final head before the gate. This thread will add a short CI note (`12a-pr72-reaudit-ci.md`) when both runs finish.

## 8. Sensitive material

None read or copied. Manifests hold only paths, modes, sizes and hashes. The evidence diffs are the PR's own public diff. Test runs used no tokens or proxy variables (`env -i`).

## 9. Confidence

- Provenance: 0.99. The manifest was reproduced byte for byte, it equals the writer's, closing = opening, and the product code is token-identical to 5dfcc1c.
- Validation: 0.9. The whole suite ran on the exact trees, with environment-only failures identical to base apart from one unreproduced flake. CI was not finished, and the live box was not exercised.
- Implementation: 0.95 for the code (unchanged, 12 of 12 mutants killed here and 13 of 13 in audit 08). The docs repair is correct where it was made; R1 is the one place it missed.

## 10. Remaining uncertainty and stop conditions

- Unknown: the CI results on `c68cd50` (O3); whether any live box allowlist names a `workload` prefix (audit 08's O4).
- Guess: O2 is a load-only fixture race. What would confirm it: a recurrence with the same `terminated=false` line on base.
- No stop condition hit.

## 11. Evidence

Folder `12-pr72-reaudit-evidence/`, with `SHA256SUMS`:
- manifests: `manifest-c68cd50-open.json`, `manifest-c68cd50-close.json`;
- diffs and the token check: `pr72-c68cd50.diff`, `repair-5dfcc1c-c68cd50.diff`, `repair-token-compare.txt`;
- whole-suite results: `full-head-summary.txt`, `full-base-summary.txt`, `full-run-exits.txt`, `head-vs-base-compare.txt`, `head-failing-entries.txt`, `base-failing-entries.txt`, `flaky-subtest-reruns.txt`;
- probes and mutants: `docs-probes.txt`, `code-mutants.txt`, `code-mutant-C11-rerun.txt`;
- trial merges: `trial-merges.txt`, `trial-t70-summary.txt`, `trial-t69-summary.txt`, `trial-t69b-summary.txt`, `trial-t68-summary.txt`;
- scripts (`*.txt`): `gotest.sh`, `sigreset.py`, `probes.py`, `runprobes.sh`, `mutants.py`, `runmutants.sh`, `runone.sh`, `flaky.sh`, `compare.py`, `summarize.py`, `tokcmp.go`.

## 12. Verdict

**BLOCK** on R1 (nit). The repair scope is one clause in `PLANS.md:305` plus its pin, or a narrower test comment. A narrow re-check covers that line, the pin, provenance and the root package. The code needs no further audit or mutants, and the parallel red-team's target is unaffected. Before the gate: green Linux and macOS CI on the final head (O3) and a refreshed PR body (O4).
