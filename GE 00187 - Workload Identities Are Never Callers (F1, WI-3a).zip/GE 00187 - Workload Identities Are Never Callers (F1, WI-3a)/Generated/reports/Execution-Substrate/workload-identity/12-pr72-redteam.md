# Red-team 12: ES PR #72, workload identities are never callers (F1, WI-3a)

Date: 2026-11-26, about 7:25 PM Eastern (2026-11-27 00:25Z). Red-team thread: "Red-team the workload caller PR 72" (fresh; it has not written, repaired or audited this PR). Brief: the coordinator's spawn note of 2026-11-26 23:58Z.

**Result: no bypass found.** At head `c68cd50` I found no way for a workload SPIFFE ID, or a certificate that carries one, to be accepted as a caller by ES, AGS, ARS, EGS or CGS. No Critical, High, Medium or Low finding. One nit in the PR's own wording (RT-N1) and three observations that need no change in this PR.

**Red-team verdict: ACCEPT** (no finding blocks on security grounds). RT-N1 is a wording nit in a sentence this PR adds; the standing rule "Low nits fixed in-PR" applies to it, so I recommend fixing it with the next push (three lines of docs and one comment; no code path changes, so it needs no new red-team).

Effect status: read-only on the repository. No commit, no push, no PR comment, no review, nothing posted on GitHub. No Linux box, no live service. All probes ran inside this thread's cloud container.

Labels used below: **[repo]** = read by me in the repository at `c68cd50` (path:line given); **[run]** = output of a command I ran on that tree; **[report]** = stated by another thread's report, not re-derived; **Inference:** and **Unknown:** as the project rules define them.

## 1. Target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| PR | #72, branch `claude/wi-3a-workload-caller-refusal`, base `trunk_dev` |
| Head (fixed for this pass) | `c68cd50f0a5a5117cfae28f315c9a5c0816d933a`, two commits on the base (`5dfcc1c`, `c68cd50`) |
| Head tree | `6d9caa87ec0dcef00e63e875b2f89e68e4af8cbf` |
| Base | `trunk_dev` = `39e19defb0ea6c0bda30a14f88452b24f9bd9cdf` |
| `git diff 39e19de c68cd50 \| sha256sum` | `d7b428276cbb79682f976ecd65cbd4713234f07d34bb49e4202e406be75ad302` [run]; equal to writer report 09 [report] |
| Head still at `c68cd50` when this report was written | yes: `git ls-remote origin refs/pull/72/head` at 00:24Z [run] |

I did not run the v2 manifest recipe. Provenance belongs to the correctness re-audit that runs in parallel; this pass binds its target by commit SHA, tree SHA and the diff hash above.

## 2. Posture and coverage

- Read-only, no subagents. Work happened in two detached scratch worktrees of `c68cd50` in the container's scratch folder (one kept clean for the existing tests, one for the probe files) and in the throwaway worktree the probe script makes for itself. The clone's own checkout was never changed (`git status` empty at the end) [run].
- Read first: project instructions, `project-context/INDEX.md`, `procedures.md` (red-team scope and method), audit 08, writer report 09, the approved design's threat T10 and section 6.2.
- Inspected in the tree: the whole product diff; `internal/callerauth/callerauth.go` and `internal/callerallowlist/callerallowlist.go` in full; the route handlers and TLS setup of all five services (`*/api/server.go`, `*/app/app.go`); the three config loaders; `cgs/policy/idfile.go`; every production use of `callerauth.` and `callerallowlist.`; every non-test place under `scripts`, `cmd` and `es` that names a `spiffe://` ID; how the supported-local and Remote Alpha scripts issue caller certificates and which CA the services trust; the typed guard test that keeps identity reading inside `callerauth`.
- Tools: Go 1.26.5 (the `go.mod` toolchain), Go's own `crypto/x509`, `crypto/tls` and native fuzzing. Client certificates were built in-process with raw SAN bytes and real keys.

**Coverage this environment could not provide:**

- No SPIRE, Vault, Nomad or Docker here, and no Linux box (excluded by the brief). No real SPIRE-issued SVID was used. Certificates were signed by a test CA with Ed25519 keys. Inference: this does not weaken the result, because the rule reads only the parsed URI SAN, and Go's parser is the parser the services use.
- Unknown: the live box's allowlists, `id.conf`, client CA bundles and SPIRE registration entries. Nothing here says a box file names a workload prefix or that a box service trusts the SPIRE CA (audit 08, O4, stays open).
- macOS not run. The whole repository suite was not rerun (the re-audit does that); I ran the existing tests of the packages this change touches (section 7).
- Fuzzing ran for 75 s and 30 s, not for hours.

## 3. Attack map

A request is accepted as a caller only if it passes three layers. I attacked each.

1. **TLS handshake.** All five services build the same server TLS configuration: TLS 1.2 minimum, `ClientCAs` from `tls.client_ca_file`, `RequireAndVerifyClientCert`. The five `loadTLSConfig` functions are byte-identical (same SHA-256 of the function text) [run]; for example `es/app/app.go:111-133` [repo].
2. **Authentication.** Every route that checks a caller calls `callerauth.Authenticator.Authenticate` (`callerauth.go:218-237`), which calls `CallerFromConnectionState` (`:149-188`), which calls `ParseSPIFFEID` (`:85-109`). The workload refusal is `:105-107`, after the ASCII-only segment check (`:93-97`) and the trust-domain check (`:98-100`) [repo]. Call sites: `es/api/server.go:267-277`, `ars/api/server.go:542-568`, `ags/api/server.go:75-87`, `egs/api/server.go:75-83`, `cgs/api/server.go:35-40` [repo]. No other production code reads a peer identity: the typed guard `internal/callerauth/caller_authentication_typed_guard_test.go` enforces that, and it passed on the clean head [run].
3. **Authorization.** ARS, AGS and ES match path prefixes through `callerallowlist.Matches`, which re-validates the prefix on every match (`callerallowlist.go:78-84`); EGS matches two exact paths (`egs/api/server.go:103-110`); ARS writes need the exact prefix `service/artifact-governance` (`ars/api/server.go:24`, `:562`); CGS requires the caller to equal the principal it asks about and to be `service/<x>` or `script/<x>` (`cgs/api/server.go:71-79`) [repo]. These differences are authorization and are documented in section 3A; authentication is one shared function for all five.

## 4. Probes and results

Every probe is a Go test in the evidence folder (`probes/`), and `run-probes.sh.txt` reruns all of them (section 12). Results below are from `run-1/` [run]. "Certificate" always means real DER bytes that went through `x509.ParseCertificate`, the way a TLS server receives them.

| ID | What was tried | Result |
| --- | --- | --- |
| P1 | All 256 letter cases of `workload` as first segment, in 5 shapes (shared ID, named, per-run, with `operator/local` or `service/execution` below it): 1,280 IDs, as text and as certificates | all 1,280 refused with `ErrWorkloadIdentity` |
| P2 | 50,889 raw URI SANs near four workload IDs: every single-byte insertion, substitution and deletion over the 128 IA5 values at every position; percent-encoding and double-encoding of every byte; 43 structural insertions (`/`, `//`, `/.`, `/..`, `%2F`, `%2e%2e`, `%00`, `;`, `\`, `@`, `:`, `#`, `?`, and more) at every position; 66 hand-written tricks (user information, ports, trailing dot and upper case in the trust domain, opaque and host-less forms, NUL, new line, Unicode look-alikes of `k`, `w`, `/` and `.`, zero-width space) | 16,525 refused by the certificate parser, 29,645 refused by `callerauth` (18,441 malformed, 6,045 foreign trust domain, 5,159 workload), 4,719 accepted. Every accepted SAN authenticated as exactly the ID it spells (after the two documented parser normalizations), and none with first segment `workload` in any case. The accepted ones are different words, such as `workloa`, `workloadX`, `work` (section 5, RT-N1) |
| P3 | 15 SAN structure tricks: workload URI next to an allowed URI in either order, the same twice, an empty second URI; the allowed ID carried as DNS name, e-mail, `otherName`, `registeredID`, in `issuerAltName`, or in a second SAN extension | all refused (multiple URI SANs, no URI SAN, workload identity, or the parser's "duplicate extension") |
| P4 | Real mutual-TLS listener configured like the services, TLS 1.2 and TLS 1.3: 9 workload certificates (including `SPIFFE://…/workload/…` and a trailing `#`); a child certificate that names `operator/local`, signed with a workload certificate's own key, presented alone, with the workload certificate, and with the CA; the operator ID from a CA outside the client bundle; no certificate | workload certificates: 401. Child certificates: handshake refused ("parent certificate cannot sign this kind of certificate"). Outside CA and no certificate: handshake refused |
| P5 | Real mutual TLS in front of each service's real handler; 11 workload certificates against every authenticated route (ES 11 request shapes, ARS 8, AGS 1, EGS 2, CGS 12 bodies that name each workload form as the principal) | 374 answers, all `401 Authenticated caller identity required`; no request reached a service. Routes that check no caller are in RT-O1 |
| P6a | 1,280 workload prefixes in every letter case, alone and behind a valid entry | all `ErrWorkloadPrefix` |
| P6b | 41 smuggled prefix spellings (white space, NUL, slashes, dot segments, percent-encoding, Unicode look-alikes, wildcards, full URI) | all refused |
| P6d | The real config loaders of ES, ARS and AGS on the shipped example configs with a workload entry written 10 ways (plain, upper case, one segment, JSON `\u` escapes for a letter and for the slash, `\/`, Kelvin sign, a repeated key, the key in another letter case) | 30 of 30 refused at load with the allowlist error. A repeated key whose last value is valid loads with the valid list only (Go keeps the last value), so no workload entry is in effect |
| P6e | CGS `id.conf` with 12 workload principals | all refused at load |
| P7 | ES, ARS and AGS servers built directly with 19 workload-naming prefixes on the allowlist, as if the startup check had been skipped; 11 workload certificates over real TLS | 44 answers, all 401 |
| Fuzz 1 | Arbitrary bytes as the one URI SAN of a certificate; fails if an accepted caller is not the literal ID or has first segment `workload` | 863,071 executions in 75 s, no failure |
| Fuzz 2 | Two URI SANs of arbitrary bytes; fails if anything authenticates | 190,409 executions in 30 s, no failure |
| Power check | The same probes against three deliberately broken copies of `callerauth.go` | refusal removed: 14 probe tests fail in all 8 packages; case-sensitive compare: 13 fail in all 8; "read the last of several URI SANs": P3 fails. So the probes do detect a bypass (`probe-power-check.txt`) |

Why the text rule holds, beyond the counts: the first segment reaches the comparison only after every byte of it was checked to be one of `A-Za-z0-9._-` [repo `callerauth.go:281-294`], so `strings.EqualFold` can only ever see ASCII and the 256 case forms are the whole set. The only rewriting between the certificate and the rule is `url.URL.String()`, and the fuzz and P2 confirm it changes nothing but the scheme's case and one empty fragment, both already documented and tested in the tree (`internal/callerauth/callerauth_test.go:302-314`, contracts 3A `:195-198`) [repo, run].

## 5. Findings

### RT-N1 (nit; test/doc gap; patch defect): "no near-miss" is wider than the rule

- Path: `.docs/system_overview/contracts.md:192-194` (added by this PR): "The comparison ignores letter case on purpose, so no configuration can name a near-miss of a workload identity." Same thought in the code comment `internal/callerauth/callerauth.go:101-104`: "refusing it leaves no near-miss for a configuration to confuse with a workload identity."
- Evidence [run]: the rule closes letter-case variants only. These prefixes validate and the matching IDs authenticate: `workloads/x`, `workload-x/y`, `workload_x/y`, `workload.x/y`, `workload./x`, `workload-/x`, `workload_/x`, `.workload/x`, `-workload/x`, `_workload/x`, `work.load/x`, `work-load/x`, `work_load/x`, `workload0/x`, `w0rkload/x`, `work/load`, `service/workload`, `operator/workload/x`, `execution.internal/workload/x` (P6c). P2 accepted 4,719 SANs that spell 1,240 distinct first segments one edit away from `workload`.
- Impact: none on security. A near-miss path is a different SPIFFE ID, not a workload identity, and the sentence just before it in section 3A says a longer first segment such as `workloads` is not affected. The claim as written is simply false, in a contract section.
- Correction (my recommendation): say what the rule does. Docs: "…so no configuration can name a workload identity in another letter case." Comment: "…and refusing it leaves no letter-case variant for a configuration to confuse with a workload identity." No test pins either sentence today (`grep -rn near-miss` finds only these two places) [run].
- Not recommended: widening the refusal to look-alikes. Any list of look-alikes is arbitrary. The guarantee that a workload can only ever hold an ID under `/workload/` belongs to SPIRE registration, which is WI-3's job (audit 08, O3). The P6c list is the reason that readiness check should compare the exact layout, not a pattern.

### RT-O1 (observation; pre-existing; matches the contract): `/health` answers a workload certificate

- Evidence [run, P5]: with a workload certificate that verifies against the client CA bundle, `GET /health` answers 200 with the readiness JSON at ES, ARS, AGS and EGS (CGS has no `/health`, 404). A certificate with no URI SAN at all gets the same answers, so `/health` reads no identity. Unknown routes and wrong methods answer 404, 405 or 307 before any caller check, with nothing but the standard text.
- Contract [repo]: `contracts.md:129-134` says each listener "requires a client certificate that verifies against that service's configured client CA bundle, including on `/health`", and that the services authenticate "every route that checks a caller". So this is the documented behaviour, and #72's new sentence ("has no caller identity, at every service") is true as written.
- What a holder of such a certificate gets: the readiness labels, and one outbound ARS readiness call per request at ES and AGS (`es/admission/service.go:372-397`, `ags/publish/service.go:83-88`) [repo].
- Why it is only an observation: a workload cannot get such a certificate today (RT-O2). No change needed in #72. If a later design makes the SPIRE CA a client CA of a service, "never callers" will not cover `/health` unless that design says so; that decision belongs to that design's brief.

### RT-O2 (observation; context): today the refusal is a second wall

- Facts [repo]: in the supported-local setup the services' client CA is an OpenSSL "Runtime Root CA" (`scripts/72_supported_local_setup.sh:1599-1603`), every caller leaf (execution, artifact-governance, operator, control-plane) is signed by it (`:1605-1613`), and all four service configs name it as `client_ca_file` (`:1347`, `:1358`, `:1378`, `:1404`). The SPIRE server there has its own CA, with no `UpstreamAuthority` (`:691-722`), and its bundle is only exported for JWT validation (`:846`). The Remote Alpha renewal script also signs the service client leaves with a runtime CA it generates and then deletes (`scripts/internal/remote_alpha_es_service_tls_renew.sh:1031`, `:1044-1059`, `:1062`).
- Consequence: an X.509-SVID that SPIRE issues to a workload (the only workload entry is `spiffe://execution.internal/workload`, `:827-832`) does not chain to the services' client CA, so the handshake fails before `callerauth` runs. P4 shows that mechanism ("operator ID from a CA outside the client bundle: handshake refused") [run]. The same holds for SPIRE's own identities (`spire-agent`, `spire/agent/…`), which are well-formed caller IDs by syntax but come from the SPIRE CA and match no shipped allowlist.
- So #72 is defence in depth today, and becomes the first wall on the day a client bundle includes the SPIRE CA. The 403 text "use a SPIRE-issued identity" suggests that direction; the scripts do not do it. Unknown: the box's actual bundles.

### RT-O3 (observation; pre-existing; outside the diff): two identity types outside `callerauth` can hold a workload ID, both unreachable today

- `es/admission/reliable_submit_operational_handoff.go:113`, `:149-161`: the private submit handoff takes its peer and its configured caller as go-spiffe `spiffeid.ID`, which accepts `spiffe://execution.internal/workload/...`. `es/admission/reliable_submit_identity.go:57-62`: `validReliableSubmitCallerURI` accepts any trimmed string that starts with `spiffe://` [repo].
- Not reachable: `handoffOperational`, `recoverOperational` and `newOperationalDomain` have no production caller at `c68cd50` (`grep` over non-test Go files finds only their definitions) [run], and the peer must equal the configured caller exactly.
- The typed guard allows `spiffeid` outside `callerauth` on purpose (`internal/callerauth/caller_authentication_typed_guard_test.go:49-62`), so nothing machine-enforced ties that peer to `callerauth` when the handoff gets a listener. Route to the brief of the PR that wires the handoff: take the peer as `callerauth.SPIFFEID` (or pass it through `ParseSPIFFEID`), with a test that a workload ID is refused there.

### Probe corrections (my own errors, for the record)

- My first P6b list expected `execution.internal/workload/x` to be refused as a prefix. It validates, correctly: its first segment is `execution.internal`, so it is the `service/workload` class, not a workload prefix. I moved it to the near-miss list (P6c). No finding.
- My first P4 run did not really present the "child alone" and "outside CA" certificates: Go's client withholds a certificate whose issuer the server did not ask for. The probe now forces the client to send it (`GetClientCertificate`), and the results above are from that version.
- One container-only failure before any probe: `TestCallerIdentityIsReadOnlyByCallerauthByType` failed until `go mod download` had filled the module cache (the test runs `go list` with `GOPROXY=off`). After the download the package passes.

## 6. The brief's list, item by item

| Trick | Result | Probe |
| --- | --- | --- |
| Letter case of `workload` | refused, all 256 forms | P1, P6a, P4, P5 |
| Trailing slash, empty segments, leading `//` | refused as malformed | P2, P6b |
| Dot segments (`.`, `..`, `x/../workload`, `workload/../operator/local`) | refused as malformed; nothing normalizes a path | P2, P6b, P6e |
| Percent-encoding (one letter, all letters, the slash, double encoding, `%00`, `%2e%2e`) | refused: `%` is not a segment character | P2, P6b, P6e |
| Unicode (Kelvin sign for `k`, full-width `w`, Cyrillic `o`, division slash, zero-width space; raw and percent-encoded) | raw: the certificate parser refuses non-IA5 bytes; encoded: refused as malformed; in config: refused as not canonical | P2, P6b, P6d |
| Trust-domain confusion (upper case, trailing dot, suffix and prefix names, port, user information, bracketed host, `@` tricks) | refused (foreign trust domain or malformed) | P2 |
| Scheme case and trailing `#` (the two things Go's parser normalizes) | normalized, then refused as workload | P2, P4, P5 |
| Multiple URI SANs, other SAN types, second SAN extension, `issuerAltName` | refused | P3, Fuzz 2 |
| A workload certificate signing itself a caller certificate | handshake refused | P4 |
| Allowlist entries that shadow the workload prefix | refused at load by all three loaders; match nothing even when a server is built with them directly | P6a, P6b, P6d, P7 |
| `id.conf` principals | refused at load | P6e |
| A service whose check differs | none: one shared authenticator, identical TLS setup, typed guard; every authenticated route of all five answers 401 | section 3, P5 |

## 7. Validation

| Run | Result |
| --- | --- |
| `go test -count=1 ./internal/callerauth/... ./internal/callerallowlist/... ./cgs/... ./ags/... ./ars/... ./egs/... ./es/api/... ./es/config/... .` on a clean worktree of `c68cd50` | exit 0, every package `ok` (`existing-tests-clean-head.txt`) |
| `bash run-probes.sh.txt <clone> <out>` (all probes, 75 s and 30 s fuzz) | exit 0; 0 lines marked `BYPASS` or `LAUNDERING` (`run-1/`) |
| The same script again with 5 s fuzz times, after a cosmetic fix to its cleanup | exit 0 |
| Power check (three mutants) | probes fail as expected (`probe-power-check.txt`) |

Not rerun: the whole repository suite, the docs deletion probes, the audit's mutants (the correctness re-audit owns those). `run-1/` was produced by the script before the cosmetic cleanup fix (`cd /` before removing the temporary folder, and one silenced git message); the probes and commands are identical.

Noticed outside scope: `gofmt -l` lists `internal/observability/observability.go` at `c68cd50` (indentation of a `switch`). The file is not in this PR.

## 8. Regression tests

The procedure says findings that hold become permanent regression tests. No finding holds as a bypass, so none is required. What I attacked is already pinned in the tree: the four workload cases in the shared refusal list run against every authenticated route of every service (`callerauthtest.go:258-263`), the reference comparison with go-spiffe, the prefix rule's tests and fuzz seeds, and the CGS principal test. The probe files stay in the evidence folder if someone later wants the real-TLS cases (P4, P5) in the tree; I do not recommend adding them, because the workload rule does not depend on the TLS layer.

## 9. Sensitive material

None read or copied. Probe keys and certificates were generated in memory by the tests and never written to disk. The evidence holds test sources, test logs and a script. No tokens, no box data.

## 10. Confidence

- No bypass through the text rule or the certificate path: 0.95 (ten lines of rule, exhaustive over letter case, 50,889 structured mutations, about 1.05 million fuzz executions, and the probes are shown to fail when the rule is broken).
- No service differs in authentication: 0.95 (static read of all five, identical TLS setup by hash, 374 real-TLS answers, typed guard passes).
- Deployment level (what a real workload can obtain on the box): not assessed here; see section 2.

## 11. Remaining uncertainty and stop conditions

- Unknown: box allowlists, `id.conf`, client CA bundles, SPIRE entries (audit 08 O3 and O4 carry these to WI-3 and to the box upgrade pre-check).
- RT-N1 is the only item that asks for a change in this PR. RT-O1 to RT-O3 need none.
- No stop condition hit. The head did not move during the pass.

## 12. Evidence and how to rerun

Folder `12-pr72-redteam-evidence/` with `SHA256SUMS`:

- `probes/`: the probe sources, at the paths they are copied to, each with `.txt` appended.
- `run-probes.sh.txt`: reruns everything in a throwaway worktree and removes it afterwards. `bash run-probes.sh.txt /path/to/Execution-Substrate /path/for/logs`. The clone must hold `c68cd50` (fetch the PR branch first). It needs Go and network access for `go mod download`. Tested twice here.
- `run-1/`: `probes.log`, `fuzz-one-uri-san.log`, `fuzz-two-uri-sans.log`, `target.txt`; `run-1-console.txt`.
- `existing-tests-clean-head.txt`, `probe-power-check.txt`.

## 13. Verdict

**ACCEPT from the red-team.** No way found for a workload SPIFFE ID or certificate to be accepted as a caller at `c68cd50`. One wording nit (RT-N1) to fix in the PR under the standing nit rule; it changes no behaviour.

STATUS: READY (red-team of PR #72 at c68cd50 is done; nothing is running)
