# Re-audit 12 addendum: CI on ES PR #72 head c68cd50

Date: 2026-11-26, 7:47 PM Eastern (00:47Z on 11-27). Thread: "Re-check the workload caller PR 72". Read through the GitHub API; nothing posted.

**Result: no CI result exists for c68cd50.** The writer pushed `553f1a0` at 00:27Z, and that push cancelled both runs on `c68cd50`:

| Workflow | Run | Job | Head | Conclusion |
| --- | --- | --- | --- | --- |
| go ("build, vet and test") | 336 (45913959468) | 140228695618 | `c68cd50` | cancelled at 00:27Z, after about 29 minutes |
| go-macos ("test on macOS") | 83 (45913959485) | 140228716034 | `c68cd50` | cancelled at 00:27Z |

The Linux job has therefore still not finished on any head of #72: 5e0916f, a55d8bb, a3710c0, 5dfcc1c and c68cd50 were all cancelled by the next push. The runs on the new head `553f1a0`, run 340 (go) and run 87 (go-macos), were in progress at 00:47Z.

The new head is not covered by re-audit 12. Its commit message says it fixes re-audit 12 R1 and red-team 12 RT-N1. It needs its own fresh narrow re-check (protocol section 14), and the merge gate needs green Linux and macOS runs on it.

Note: the red-team report also uses number 12 (`12-pr72-redteam.md`). The file names differ, so nothing was overwritten.
