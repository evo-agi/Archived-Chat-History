# Independent narrow re-check 16: ES PR #72 at 553f1a0 (R1 and RT-N1 fixes)

Date: 2026-11-26, about 8:20 PM Eastern (01:20Z on 11-27). Auditor: the fresh thread "Narrow re-check of workload caller PR 72". It has not written, repaired or audited this PR before (protocol section 14). Brief: the coordinator's spawn note (00:47Z).

**Final verdict: ACCEPT** (verdict vocabulary of protocol section 13.4; PASS in the coordinator's brief). No finding of any severity.**

- Provenance: the manifest reproduces byte for byte and equals the writer's; closing = opening. Since `c68cd50` exactly four files changed, the ones the writer named, and the only Go product change is a comment (token-identical code).
- R1 is fixed: `PLANS.md:305` now carries the workload exclusion, and the new pin kills two probes.
- RT-N1 is fixed: section 3A and the `callerauth.go` comment now say the rule closes letter-case variants only, which a direct test confirms. The new 3A pin kills four probes.
- A fresh search finds no remaining restatement of the caller identity or the prefix rule without the exclusion.
- The root package passes on head, base and `c68cd50` (623 of 623 each, identical names), and the auth packages pass on head.
- **CI is green on the final head, for the first time on any head of this PR:** "build, vet and test" (run 45916784480, job 140237895120) and "test on macOS" (run 45916784416, job 140237905778), both `success`.
- The refreshed PR body is accurate. Two observations do not block (sections 5 and 7).

Effect status: no repair, no commit, no push, no PR comment, no review, no merge. Nothing posted on GitHub.

Labels: **[repo]** = read by me in the tree at the stated SHA (path:line); **[run]** = output of a command I ran; **[report]** = stated by another thread's report or by GitHub, not re-derived; **Inference:** and **Unknown:** as the project rules define them.

## 1. Audit target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| PR | #72, branch `claude/wi-3a-workload-caller-refusal`, base `trunk_dev` |
| **Verdict target (head)** | `553f1a0bc636ce9bd8d63b202b6671cf1481672d` (one commit on `c68cd50`) [run: `git ls-remote` at 00:48Z and 01:15Z] |
| Head tree | `a8a95252fe41c393d165ac1e661f99d7f96513cc` [run] |
| Previous head (re-audit 12, red-team 12) | `c68cd50f0a5a5117cfae28f315c9a5c0816d933a`, tree `6d9caa87ec0dcef00e63e875b2f89e68e4af8cbf` |
| Base | `trunk_dev` = `39e19defb0ea6c0bda30a14f88452b24f9bd9cdf`, tree `178defa90f883644497e6fc97573ffdf35d3f39c` (unchanged at 00:48Z and 01:15Z) |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (checked before the opening and the closing runs) |
| Canonical manifest SHA-256 | `07e5a0b8f5d5c9aa452d4ecd6ec322cce7847bb4a19635907792dfdfea900edb` (13 file records) |
| Recipe textual-diff SHA-256 | `04699d5fb5ee9a599fe0f207e16afd7d37d1a9b1bef1f12b8ce3cb30f8b87629` |
| `git diff 39e19de 553f1a0 \| sha256sum` | `c91dae8b03729361eb0f2680bab23cec29c0792a8c796c3153f0f204e12a4f01`, 13 files, +209 / -42 |
| `git diff c68cd50 553f1a0 \| sha256sum` (delta) | `0300cb8ee81c2ab1faf17e93b1a3a9923977ad6aebae8b469067072abcf32328`, 4 files, +10 / -5 |
| Inputs | re-audit 12 (`12-pr72-reaudit.md`), red-team 12 (`12-pr72-redteam.md`, RT-N1), CI addendum `12a-pr72-reaudit-ci.md`, writer report 13 (`13-pr72-nits.md`) and its manifest `13-pr72-nits/pr72-553f1a0-manifest-v2.json` |

## 2. Provenance reproduction

- Steps: provenance guide section 5.3 in a fresh clone from GitHub under `umask 022`: `test "$(git rev-parse origin/$TOPIC)" = "$TIP"`, `git merge-base --is-ancestor` for the base (and for `c68cd50`), `git checkout -q -f -B`, clean status, `git reset --mixed 39e19de`, upstream pinned to `origin/trunk_dev`, then v2 twice into a fresh `0700` directory outside the repo. [run]
- Run 1 = run 2 (`cmp`), and both equal the writer's manifest file byte for byte (`cmp`; SHA-256 `07e5a0b8…0edb`). No tolerated mode-bit differences. All 13 paths are `tracked_modified`, mode `0644`. [run]
- Closing run after all work: after all work, v2 ran once more on the same clone in the same reset state: closing = opening (`cmp`). The recipe source still hashed `c08597e2…a3ca`. The clone was then reset back to the tip with a clean status. [run]
- History: `39e19de..553f1a0` holds exactly three commits, `5dfcc1c` → `c68cd50` → `553f1a0`, each with one parent; `553f1a0`'s parent is the `c68cd50` that re-audit 12 and red-team 12 judged. [run]
- **Only the claimed changes since c68cd50.** I compared the per-file records of the c68cd50 manifest from re-audit 12 (`12-pr72-reaudit-evidence/manifest-c68cd50-open.json`) with this one: the same 13 paths, and only four records differ, the same four files `git diff --stat c68cd50 553f1a0` lists [run]:

| File | Size at c68cd50 → 553f1a0 | Change |
| --- | --- | --- |
| `.docs/system_overview/contracts.md` | 89,690 → 89,846 | 3A: the "near-miss" sentence replaced (RT-N1) |
| `PLANS.md` | 149,207 → 149,264 | line 305: the workload clause added (R1) |
| `internal/callerauth/callerauth.go` | 11,567 → 11,664 | comment only (RT-N1) |
| `workload_grants_docs_contract_test.go` | 30,033 → 30,484 | two pin strings added |

- Code unchanged: the `go/scanner` token streams (comments skipped) of `internal/callerauth/callerauth.go` at c68cd50 and 553f1a0 are equal (1,128 tokens each). The test file differs by 4 tokens: two string literals and their commas. [run, `token-compare.txt`]
- So the product code is the code re-audit 12 and red-team 12 accepted at c68cd50, which was token-identical to audit 08's 5dfcc1c [report].

## 3. Posture and coverage

- Read-only. No subagents. The provenance clone was left as found. Tests, probes and trial merges ran in separate clones owned by an unprivileged local user `ci` (uid 1500, gid 1600), under `env -i` with no proxy or tokens, `umask 022`, `GOPROXY=off`, `GOFLAGS=-mod=readonly`, `GOTOOLCHAIN=local` with Go 1.26.5 (the `go.mod` toolchain), and HUP/INT/QUIT/TERM/PIPE reset to default.
- Read: the project instructions, `INDEX.md`, `procedures.md` (briefs and reports, labeling facts, audits, docs), the operating protocol sections 12 to 15, the provenance guide sections 5.3 to 5.5 and 13, re-audit 12, red-team 12 (RT-N1 and its context), the CI addendum 12a, writer report 13, the PR body and its one comment (Codex summary for `5e0916f`, no findings).
- Inspected: the delta diff in full; section 3A of `.docs/system_overview/contracts.md` around the change; the two pin blocks in `TestWorkstreamFF1IsPlannedAndPointedTo`; every non-history doc, runbook, example config and script line that names the allowlist-prefix rule or the caller identity (search terms in section 4.3); the config fields that can name a caller identity (`allowed_spiffe_path_prefixes` in ARS, AGS and ES; CGS `id.conf`); CI on 553f1a0.
- Not re-inspected (scope): the code, the five services' authentication paths, the code mutants, the shipped allowlists. Re-audit 12 and red-team 12 accepted those at c68cd50, and the code is token-identical. The live box (audit 08 O4 still applies).

## 4. The fixes

### 4.1 R1 (re-audit 12): `PLANS.md:305`

- At 553f1a0 [repo `PLANS.md:305`]: "... (same section 3A): a prefix must be a canonical SPIFFE ID path of at least two segments whose first segment is not `workload` in any letter case, and a prefix that fails the rule matches nothing." This is the correction re-audit 12 proposed, word for word.
- Accurate against the code: `callerallowlist.ValidatePrefix` refuses `Workload/x`, `WORKLOAD/x`, `wOrKlOaD/x` and `workload/x` with `ErrWorkloadPrefix` [run, `claimcheck.txt`].
- Pinned: `workload_grants_docs_contract_test.go:218`, in the "PLANS restates the workload exclusion" assertion next to the `PLANS.md:304` pin, matched against the whole compacted `PLANS.md`. Probes Q1 (clause removed) and Q7 (`workload` → `workloads` in the clause) both fail `TestWorkstreamFF1IsPlannedAndPointedTo` [run].
- PLANS.md is 149,264 bytes, under the 150,000 cap; `TestPlansStaysWithinItsSizeCap` passes on head [run].
- The test comment at `workload_grants_docs_contract_test.go:203-204` ("Every page that restates the caller identity or the allowlist-prefix rule restates the workload exclusion too") is now true as far as my search reaches (4.3).

### 4.2 RT-N1 (red-team 12): "no near-miss"

- 3A at 553f1a0 [repo `.docs/system_overview/contracts.md:192-196`]: "The comparison ignores letter case on purpose, so no configuration can name a workload identity in another letter case. It closes letter-case variants only: a different word, such as `workloads/x` or `work-load/x`, is a different SPIFFE ID and stays a valid path."
- Comment [repo `internal/callerauth/callerauth.go:101-105`]: "... refusing it leaves no letter-case variant for a configuration to confuse with a workload identity. A different word, such as "workloads", is a different identity and is not refused."
- Both now say what the rule does, as red-team 12 recommended. Checked against the code [run, `claimcheck.txt`]: `workloads/x` and `work-load/x` pass `ValidatePrefix`, `ParseSPIFFEID` accepts the matching IDs, and `Matches` matches them; the four letter-case variants are refused by both functions.
- "No configuration" holds in its scope: the configurations that can name a caller identity are the three `allowed_spiffe_path_prefixes` lists (ARS, AGS, ES, validated by `callerallowlist`) and CGS `id.conf` (validated through `ParseSPIFFEID`) [repo `ars/config/config.go:41`, `ags/config/config.go:45`, `es/config/config.go:57`; red-team 12 P6d/P6e report]. No other config field in the tree names a caller SPIFFE ID [run: field search over non-test config Go files].
- `near-miss` no longer appears anywhere in the tree outside an unrelated commercialization doc [run: `grep -rn "near-miss\|near miss"`].
- Pinned: `workload_grants_docs_contract_test.go:201`, in the 3A assertion. Probes Q2 (old sentence back), Q3 (second sentence deleted), Q4 (`work-load/x` → `workload/x`, a false example) and Q5 (first sentence deleted) all fail `TestWorkstreamFF1IsPlannedAndPointedTo` [run]. The comment is not pinned (Q8 survives), which is normal for code comments.

### 4.3 Restatement search (fresh, not limited to the writer's terms)

Searched all `.md`, `.txt`, `.sh`, `.json`, `.hcl` and YAML files outside `.docs/history` and `.git` for: "two segments", "two non-empty segments", "two path segments", "at least two", "single-segment", "one-segment", "canonical SPIFFE ID path", "exactly one URI SAN", "identifies a caller", "conforming SPIFFE", "prefix allowlist", "path-prefix", `allowed_spiffe_path_prefixes`, `callerallowlist`, `internal/callerauth`; and Go non-test files for "two segments", "at least two", "near-miss", "letter case" [run]. Each hit is one of:

- a pinned restatement that carries the exclusion: 3A (`contracts.md:183-196`, `:222-225`), system section 7 (`:818-826`), lifecycle section 4 (`execution_lifecycle/contracts.md:261-281`), `PLANS.md:304-305`, `configuration.md:284-298`;
- a pointer to 3A without its own rule: `contracts.md:373`, `boundaries.md:971-972` ("checks each configured prefix against the canonical SPIFFE ID path of `contracts.md` section 3A, with at least two segments"; I read "the path of section 3A" as including 3A's workload bullet, as re-audit 12 did), `architecture.md:95-96`;
- a config value or field name (`operator/local` in examples, setup script, runbook), a historical status line (`contracts.md:722`, `boundaries.md:414`), a troubleshooting row (`supported_local_cp_consumer_runbook.md:792`), EGS's fixed two-identity list (`configuration.md:231-234`), or the healthcheck's one expected identity (`remote_alpha_operator_healthcheck_noninteractive_status.md:361`).

No restatement without the exclusion remains.

## 5. Findings

None. No Critical, High, Medium, Low or nit finding against the delta.

### Observations (not blocking)

- **O1 (re-audit 12 O1, now half closed):** the 3A sentence "The comparison ignores letter case on purpose, ..." is now pinned (Q5 killed; it survived as re-audit 12's P10). The sentence "That covers the shared workload ID ..., the named workload identities ..., and the per-run identities reserved below them (... section 11.2)." is still unpinned (Q6 survives, as P11 did). It adds no rule of its own; no change needed.
- **O2 (PR body, provenance guide section 13):** the refreshed body is accurate (section 7), but it does not carry the manifest SHA-256 or an audit verdict ("The v2 provenance manifests are with the project's audit reports"). The guide says PR descriptions *should* carry base SHA, audited commit SHA, manifest SHA-256 and verdict so the gate can be checked from GitHub. Route: the coordinator may add them at the gate; not blocking.
- **O3 (merge order, pre-existing, re-audit 12 O6/O7 updated to current heads):** `PLANS.md` size cap 150,000. Merged with 553f1a0: #70 (`77027f8`) gives 150,294 bytes and #67 (`69d53de`) 150,272 (both over the cap, as before, now 57 bytes more); #69 (`1160f28`) gives 130,664 and should land first. #73 (`affefc6`) conflicts in `PLANS.md` (one line, the F1 status) and `workload_grants_docs_contract_test.go` (that line's pin and the status-classification table), as both writers expect. The body's "rebases one line of PLANS and its pin" understates the test-file side slightly (the classification table block also conflicts).

## 6. Validation

All runs as `ci` on the exact trees (head `a8a95252`, base `178defa9`, c68cd50 `6d9caa87`). Scripts are in the evidence folder.

| Run | Result |
| --- | --- |
| `go test -count=1 -json -timeout 30m .` (root package), head | exit 0, 623 entries, 623 pass, 0 fail, 0 skip (181 top-level) |
| same, base `39e19de` | exit 0, 623 pass, 0 fail |
| same, c68cd50 | exit 0, 623 pass, 0 fail |
| head vs base, head vs c68cd50 | identical test names and statuses; no failing test on any tree |
| `go test -count=1 ./internal/callerauth/... ./internal/callerallowlist/... ./cgs/policy/...`, head | exit 0, 258 pass, 0 fail |
| `gofmt -l` on the two changed Go files; `go vet . ./internal/callerauth/... ./internal/callerallowlist/...`, head | clean; exit 0 |
| Claim check (scratch test in a throwaway copy, removed after) | section 4.2; `claimcheck.txt` |

Not run by me: the whole suite (out of scope for this narrow re-check; CI covers it, section 8). Re-audit 12 ran it at c68cd50, and the delta changes no code.

### Docs probes (8, each against the whole root package in a clean copy of the head tree; Q8 also against `./internal/callerauth/...`)

| ID | Probe | Result (killing test) |
| --- | --- | --- |
| Q1 | `PLANS.md:305` without the new clause (R1 reverted) | killed (`TestWorkstreamFF1IsPlannedAndPointedTo`) |
| Q2 | 3A back to the c68cd50 "near-miss" sentence (RT-N1 reverted) | killed (same) |
| Q3 | 3A without "It closes letter-case variants only: ..." | killed (same) |
| Q4 | 3A example `work-load/x` → `workload/x` | killed (same) |
| Q5 | 3A without "The comparison ignores letter case on purpose, ..." (re-audit 12 P10) | killed (same) |
| Q6 | 3A without "That covers the shared workload ID ..." (re-audit 12 P11) | survived (O1) |
| Q7 | `PLANS.md:305` clause says `workloads` | killed (same) |
| Q8 | `callerauth.go` comment back to "near-miss" | survived (comments are not pinned) |

### Trial merges (`git merge-tree --write-tree 553f1a0 <head>`, open PR heads at 00:52Z)

| PR | Head | Merge | Tests on the merged tree (root + `./internal/callerauth/... ./internal/callerallowlist/... ./cgs/... ./ags/api/... ./ars/api/... ./egs/api/... ./es/api/... ./es/config/...`) |
| --- | --- | --- | --- |
| #73 | `affefc6` | conflict (O3) | not run (writer resolves) |
| #70 | `77027f8` | clean, PLANS 150,294 | not run (cap, O3; pre-existing) |
| #69 | `1160f28` | clean, PLANS 130,664; the new clause is `PLANS.md:303` there | exit 0, 2,394 pass, 0 fail |
| #68 | `8e056aa` (moved from `e760c67` since re-audit 12) | clean | exit 0, 2,455 pass, 0 fail |
| #67 | `69d53de` | clean, PLANS 150,272 | not run (scripts; cap, O3) |
| #66 | `08143bd` | clean | not run (scripts) |
| #63 | `59f1f56` | clean | not run (scripts) |

## 7. PR body

Read at 00:50Z (updated 00:27:54Z) [report: GitHub]. It now says: head 553f1a0 with its three commits; audit 08 fixed in c68cd50; re-audit 12 R1 fixed and pinned in 553f1a0; red-team 12 run separately, ACCEPT, RT-N1 fixed and pinned, RT-O3 routed; gate "audit, red-team and the merge gate"; the rule closes letter-case variants only. Each of these matches the tree and the reports. Re-audit 12's O4 (stale head, "red-team folded into WI-3's") is resolved. The body's test claims for 553f1a0 (`.` and `./internal/callerauth/...` pass; the two deletion probes fail the docs test) match my runs. Its wider test list is the writer's [report], and "the full `es/admission` and `es/app` suites run in CI" is settled by section 8. See O2 and O3 for two small gaps.

## 8. CI on 553f1a0

Read through the GitHub API at 01:16Z [report: GitHub]; nothing posted.

| Check | Workflow run | Job | Head | Started | Completed | Conclusion |
| --- | --- | --- | --- | --- | --- | --- |
| build, vet and test | `go` run 340 (45916784480) | 140237895120 | `553f1a0` | 00:27:27Z | 01:13:29Z | **success** |
| test on macOS | `go-macos` run 87 (45916784416) | 140237905778 | `553f1a0` | 00:27:30Z | 00:59:32Z | **success** |

- Linux steps, all `success`: Build, Vet, Vet for macOS, Check the test gate, **Test** (00:31:19Z to 00:58:13Z), **Listed tests still fail** (00:58:13Z to 01:12:29Z), **Listed tests pass as root** (to 01:13:26Z).
- The "Listed tests still fail" step is the repository's known-failure list: its log ends "all 17 listed tests still fail on this host, each in a run of its own and in the run of its package", and the root step reports "tests as root passed: 9 of execution-substrate/scripts". The listed tests are in `scripts`, `es/app` and `es/admission/internal/reliablesubmit`; the PR touches none of them. The **Test** step passing means every test not on that list passed, including the `es/admission` and `es/app` suites the PR body leaves to CI.
- macOS steps, all `success`: Check the test gate, Test (00:32:40Z to 00:46:45Z), Listed tests still fail.
- This settles re-audit 12's O3: before this run, the Linux job had not completed on any head of #72 (5e0916f, a55d8bb, a3710c0, 5dfcc1c and c68cd50 were all cancelled by the next push).
- The PR's `mergeable_state` was `blocked` at 00:50Z, while the checks were still running (review or check requirements); the gate should read it again.

## 9. Sensitive material

None read or copied. Manifests hold only paths, modes, sizes and hashes. The evidence diff is the PR's own public diff. Test runs used no tokens or proxy variables (`env -i`).

## 10. Confidence

- Provenance: 0.99. Manifest reproduced twice, equal to the writer's byte for byte, closing = opening; only the four claimed files changed since c68cd50; code token-identical.
- Validation: 0.95. The root package and the auth packages ran on the exact trees, with no failure on any tree; 6 of the 8 docs probes are killed, and the two survivors are expected; CI ran the whole suite green on the exact head on Linux and macOS. I did not rerun the whole suite myself (re-audit 12 did at c68cd50, and the delta changes no code); the live box was not exercised.
- Implementation: 0.97 for the delta. The two fixes say what the code does (checked by a direct test), both are pinned, and the restatement search found no remaining gap.

## 11. Remaining uncertainty and stop conditions

- Unknown: whether any live box allowlist names a `workload` prefix (audit 08 O4, unchanged).
- CI: none left for this head. Both required checks are green on `553f1a0`.
- No stop condition hit. The head did not move during the re-check (`git ls-remote` at 00:48Z and 01:15Z).

## 12. Evidence

Folder `16-pr72-narrow-recheck-evidence/`, with `SHA256SUMS`:
- manifests: `manifest-553f1a0-open.json`, `manifest-553f1a0-close.json`;
- diffs and the token check: `delta-c68cd50-553f1a0.diff`, `token-compare.txt`;
- root package and auth package results: `root-head.json`, `root-base.json`, `root-prev.json`, `callerauth-head.json`, `root-compare.txt`, `exits.txt`;
- probes and claim check: `probes-summary.txt`, `claimcheck.txt`;
- trial merges: `trial-merges.txt`, `trial-exits.txt`, `trial-summary.txt`;
- CI: `ci.txt` (job steps and the result lines of the Linux log tail);
- scripts (`*.txt`): `gotest.sh`, `sigreset.py`, `run-root.sh`, `probes.py`, `runprobes.sh`, `run-trials.sh`, `summarize.py`, `tokcmp.go`, `claimcheck_test.go`.

## 13. Verdict

**ACCEPT.** R1 and RT-N1 are fixed and pinned, provenance shows only those changes since `c68cd50`, the root package passes on exact bytes with no failure against base, and both required CI checks are green on `553f1a0`.

For the merge gate (coordinator): the PR head must still be `553f1a0` and `trunk_dev` still `39e19de` at merge time; the prior re-audit 12 and red-team 12 cover everything outside this delta at `c68cd50`; O2 (manifest SHA-256 and verdict in the PR body) and O3 (land #69 before #70 or #67; #73 rebases after) are for the gate and the merge order, not for this PR's bytes.
