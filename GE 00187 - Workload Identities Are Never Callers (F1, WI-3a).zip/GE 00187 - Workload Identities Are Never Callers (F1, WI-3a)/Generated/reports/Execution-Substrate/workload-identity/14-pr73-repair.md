# Writer report 14: ES PR #73 (WI-2), repair of audit 10 and red-team 11, and grants keyed on the ES caller

Date: 2026-11-26, about 8:00 PM Eastern (01:00Z on 11-27). Writer: the "Design per-workload identity and network approval" thread.

## Target

| Item | Value |
| --- | --- |
| PR | evo-agi/Execution-Substrate #73, base `trunk_dev` |
| Base | `39e19defb0ea6c0bda30a14f88452b24f9bd9cdf` |
| Previous head (audit 10, red-team 11) | `affefc62dda80dd2c48e44a8abc9f26b31ce67a6` |
| New head | `de4ade8b0b614c50c83cf1d2a80a7d6656e3c3c7` (one repair commit on top) |
| New head tree | `89590f680d84a0fd5e3085d1a008e4f1419561eb` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified) |
| Canonical manifest SHA-256 (base `39e19de`, upstream `origin/trunk_dev`, two runs, `cmp` identical) | `460930c2c45c1144a7aad48960122ead497c6ec9609ad9f8c5a44a1f6003ecb7 (57 paths)` |
| `git diff 39e19de de4ade8 \| sha256sum` | `a96bc1e28236f6887cf5fd7b73590dc67d2fd8b4383d86889ebd246576c1e097` (57 files, +3246 / -266) |
| `git diff affefc6 de4ade8 \| sha256sum` (this repair only) | `b231af1df2401a3a02150c9c4e8a66728233842bf0d1f751ed7abf4884baf447` (54 files, +1526 / -327) |

Full manifest: `14-pr73-repair/pr73-de4ade8-manifest-v2.json`. Steps as in report 09.

## The decision this carries (David, 11-27 00:19Z, RT73-4)

- A grant now matches on five facts. The new one is `caller_principal`: the ES caller, as ES authenticated it over mTLS for the request. It comes from the connection only (`es/api` puts `caller.ID()` in the context with `admission.WithAuthenticatedCaller`), never from the body, the evidence or a header.
- A context with no authenticated caller matches no rule. A private reliable submit delivery (no public listener yet) matches on the caller its claim is bound to: the operational handoff's authenticated peer, or a synthetic replay's caller fact (`withDeliveryCaller`, which replaces any caller the context carried). The operational path admits only network-false runs today, so this changes nothing there now; it keeps WI-3's identity grants keyed the same way.
- Startup refuses a `caller_principal` that ES's own allowlist does not admit, and any principal with fewer than two path segments (also closes red-team 11 OBS-5).
- Signed `network_access` is the publisher's request and only a request. AGS checks nothing about networks (it copies the publish request's flag, `ags/publish/service.go:248`); the ES grant is the one authority. Contract text says so in lifecycle 5B, system contracts section 5 (AGS) and 7, runtime identity handoff 11.1 and 11.3, the admission model, configuration and PLANS. No AGS code change.
- Today's grants (setup, the three examples, the upgrade) name each allowlist prefix as both publisher and caller. The upgrade writes no grant for a `user/...` prefix in any letter case; the setup and examples have none.

## Fixes

| Finding | Fix | Pinned by |
| --- | --- | --- |
| Audit F1 (high): es/app fixtures without grants fail in CI | Every `esconfig.Config` literal in es/app tests names its admission policy, through `todaysWorkloadGrants` (new `es/app/workload_grants_fixture_test.go`) | `TestEveryESConfigFixtureNamesItsAdmissionPolicy` (AST scan, at least 4 literals); CI runs the three tests audit 10 named |
| Audit F2 (medium): the box's `es.json` (start + Nomad TLS keys, no grants) | The shape check names it: "https without workload grants (where an upgrade before workload grants left it; this upgrade starts from locked-http, and the upgrade between https commits moves it)". This script's "https" end state requires grants, so it never reports a grantless https document as done. #67 carries the https-to-https move and writes the grants; whichever lands second ports | host subtest "es.json as an upgrade before workload grants left the box"; the #67 thread is told |
| Audit F3 / RT73-3 (medium): the lane trigger misses a lane with an extra field | The trigger pins the lane struct's fields and JSON names by reflection, then tries 11 names x both `reaches` values in Go and JSON, with 5 extra-key variants | `TestUnrestrictedLaneIsRefusedOnceAnotherLaneIsAccepted` |
| Audit F4 / RT73-1 (medium): ES and the readiness line read `es.json` differently | ES's loader refuses a key repeated in one object and a key that matches a field only by case folding, anywhere in the file (`es/config/exact_keys.go`). The readiness line refuses the same (`object_pairs_hook`, casefold check) | `TestLoadRefusesRepeatedKeysAndKeysNotSpelledExactly` (14 cases); `TestReadinessLineAndESReadTheSameConfigurationTheSameWay` (13 documents, both readers) |
| Audit F5 / RT73-2: grant code kept its own profile list | The grant decision takes the profile from `resolveExecutionRuntimeProfile` itself; if the gate refuses, there is no grant decision and the gate's 400 follows | `TestEveryRuntimeProfileTheGateResolvesHasAGrantDecision`, `TestARequestTheRuntimeProfileGateRefusesGetsItsRefusalNotAGrantDenial` |
| Audit F6 / RT73-5: Workstream A guard compared names | The guard compares the read's root by AST object, refuses shadowing; the DTO forbidden list adds `publisher` and `publisher_principal` | two new refused cases (closure local, closure parameter); `TestPublisherPrincipalReachesNoOutputOfARun` |
| Audit F7 (low): trim mutants M06, M07 survived | Padded principal and seal key in the fixture evidence, admitted by a grant for the trimmed values | `TestPaddedPublisherPrincipalAndSealKeyMatchTheGrantForTheTrimmedValues` |
| Audit F8 (low): comments in setup and upgrade | Rewritten: one rule per allowlist prefix, publisher = caller | n/a (comment) |
| Red-team OBS-1: `"admission_policy": null` | The upgrade inserts only when the key is absent; `null` is refused | upgrade refusal subcase "null" |
| Red-team OBS-5: one-segment principal | Refused at startup (both principals) | config cases |

## New tests for caller keying

- `TestPrepareGivesTheNetworkOnlyToTheCallerItsGrantNames` (es/app, real mTLS): two allowed callers ask to prepare the same network-requesting artifact; the one grant names one of them; only that one gets 200, the other gets 403 `network_access_not_granted`. Runs both ways round.
- `TestNetworkRunWithoutAGrantIsRefusedOnPrepareAndSubmitBeforeAnyEffect` (es/admission): a validly signed `network_access=true` run is refused on `:prepare` and `:submit`, before any payload read or effect, with: no grants; a rule without a lane; a rule for another publisher; a rule for another ES caller; a caller below the rule's caller; no authenticated caller; a zero caller; a caller value of another type.
- `TestPrivateDeliveryMatchesGrantsOnTheCallerItIsBoundTo`: the bound caller replaces the context's; a foreign, padded, upper-case-scheme, path-less or empty bound caller leaves none; end to end, a synthetic replay bound to another caller is refused though its context names the granted one.
- `TestWorkloadGrantRulesNameTheirCallerExactly`, byte-for-byte cases for caller, caller sub-path, caller case and no caller, and config refusals for a missing, path-only, padded, one-segment, foreign, not-admitted, and above-a-prefix caller.

## Other changes in this commit

- `es/config/exact_keys.go` imports `reflect` (types only, no `reflect.Value`). The module's reviewed import inventory (`TestOperationalGuardImportInventoryIsExact`) now lists it with its hash; the inventory's mutation subtests read each listed file's imports from the list instead of assuming `unsafe`.
- Private replay and operational handoff test fixtures bind their claims to `spiffe://execution.internal/operator/local` (was `spiffe://synthetic.test/ns/admission`), the caller the test grants name. The redaction canary now checks that no `spiffe://` string appears at all.
- The guard texts that pin the submit handler (`docs_contract_test.go`, `reliable_submit_guardrails_test.go`) follow the handler's new `ctx, request, ok := ...` and `s.service.Submit(ctx, request)`.
- `internal/callerallowlist`'s cross-service test drops the ES example's grants when it swaps the allowlist, since the grants name the example's own callers.

## Validation

- `go vet` passes for `.`, `./es/...`, `./scripts/...` and `./internal/...`; gofmt is clean for every changed file. `py_compile` and `bash -n` pass for the changed scripts.
- Pass in full: `.` (docs contracts), `./es/config`, `./es/api`, `./es/admission` (311 s), `./es/admission/internal/admissionstate`, `./internal/callerallowlist`, `./internal/callerauth`.
- `./es/admission/internal/reliablesubmit`: 3 tests fail ("authenticated schema-4 opener is required" and two like it: probes that need an authenticated old binary). They fail the same way on the previous head affefc6; this commit changes nothing in that package.
- `./es/app` and `./scripts`: every grant, readiness and upgrade test passes (`TestPrepareGivesTheNetworkOnlyToTheCallerItsGrantNames`, `TestEveryESConfigFixtureNamesItsAdmissionPolicy`, `TestReadinessLineAndESReadTheSameConfigurationTheSameWay`, `TestReadinessReportsWorkloadEgressUnrestricted`, the 16 `TestRemoteAlphaUpgradeES*` tests that run here (the real-Nomad one skips)). In this container 14 `es/app` and 38 `scripts` tests fail; the same 52 names fail on affefc6 when re-run there (compared name by name): Remote Alpha TLS and recovery harnesses, real-kernel firewall tests, curl connection resets through the container's proxy, root-owned fixtures. The Docker/Nomad tests audit 10 F1 named run only in CI.
- CI on de4ade8: see the delivering message.
- PLANS.md is 149,288 bytes.

## Notes

- Red-team 11 OBS-3 (supported-local hosts sign evidence with a key that is a constant in the repository) is not addressed here: on such a host grants are not a boundary against someone who can write to ARS. It needs its own change (per-host key generation in setup); not in this PR's scope.
- Red-team 11 OBS-2 (the upgrade refuses any admission_policy it did not write, including narrowed grants) stays as is: it fails safe.
