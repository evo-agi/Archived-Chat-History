# Independent audit 08: ES PR #72, workload identities are never callers (F1, WI-3a)

Date: 2026-11-26, about 6:55 PM Eastern (23:55Z). Auditor: the fresh thread "Audit the workload identity PR 72" (has not audited, written or repaired this PR). Brief: the coordinator's spawn note (23:14Z) and its re-target note (23:45Z, "Your verdict should be on this head").

**Final verdict: BLOCK** (one Low doc finding, four nits; no Critical, High or Medium). The code is correct, refusal-only, and well tested: 13 of 13 code mutants killed. The block is the project rule that a behaviour change updates every doc that restates the changed rule, plus "Low nits fixed in-PR".

**Red-team:** in my reading the red-team scope in `project-context/procedures.md` **does** apply (section 6 below). The approved design's "folded into WI-3" is not an exception the procedure allows. The coordinator decides.

Effect status: no repair, no commit, no push, no PR comment, no merge. Nothing posted on GitHub.

## 1. Audit target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| PR | #72, branch `claude/wi-3a-workload-caller-refusal`, base `trunk_dev` |
| **Verdict target (head)** | `5dfcc1c5de444df8106840b66f729e43ddcd60d9`, one commit on `39e19de` |
| Head tree | `1f92adc2049fd3b7c2cb01e5617abf7628380c5f` |
| Base | `trunk_dev` = `39e19defb0ea6c0bda30a14f88452b24f9bd9cdf` (squash of #71), tree `178defa90f883644497e6fc97573ffdf35d3f39c` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified before every run) |
| Canonical manifest SHA-256 | `32ce09a5eb58fdf0330e41c164005b85a0b1f8937d49945d887540420cf1b520` |
| Recipe textual-diff SHA-256 | `2cf7deb6dd3b564a746b68db4a5a79caf824bd6baffc9db88aeb3228bc508ca2` |
| `git diff 39e19de 5dfcc1c \| sha256sum` | `74b73091e10444cd19b98c21b8c59f2f57a887c49515a6e3cbf0520950cae118` |
| Changed paths | 12 (all `tracked_modified`, mode 0644): 4 product Go files, 4 test Go files, 3 docs, `PLANS.md` |

Earlier target (audit started here, same bytes): head `a3710c0a89f16523aba227fddaa8cf45e0feba6a` on `26cbd653…` (#71 tip), tree `1f92adc2…`, manifest `190b46511a6366add592246d53325e0f90ca59cbfc5d7bc4c0cd34a09bbffe37`. The rebase changed only the base: `39e19de` has the tree of `26cbd65`, `5dfcc1c` has the tree of `a3710c0`, and the 12 file records of the two manifests are identical (checked by script). Every test, mutant and trial below ran on trees `1f92adc2` (head) and `178defa9` (base), so they bind to the verdict target.

## 2. Provenance reproduction

Commands: provenance guide section 5.3 in a fresh clone under `umask 022`, with `test "$(git rev-parse origin/$TOPIC)" = "$TIP"`, `git merge-base --is-ancestor`, `git reset --mixed "$BASE"`, upstream pinned (`origin/trunk_dev` for the verdict target; `origin/claude/project-thread-4rhifh` for the earlier one), then v2 twice into a fresh `0700` directory.

| Target | Run 1 = run 2 | Equal to writer's | Closing run = opening |
| --- | --- | --- | --- |
| `5dfcc1c` on `39e19de` | yes (`cmp`) | yes: byte-equal to `07-rebased-heads/pr72-5dfcc1c-manifest-v2.json` | yes |
| `a3710c0` on `26cbd65` | yes | no writer manifest existed for this target (O8) | yes |

No tolerated mode-bit differences. Manifests: evidence `manifest-*.json`.

## 3. Posture and coverage

- Read-only. No subagents (the parent did all reading; nothing needed parallel search). No repo bytes changed in the provenance clone; tests, mutants and trial merges ran in separate clones owned by an unprivileged local user `ci` (uid 1500, gid 1600), under `env -i`, `umask 022`, no proxy, `GOPROXY=off`, Go 1.26.5 (the `go.mod` toolchain), HUP/INT/QUIT/TERM reset to default.
- Read: project instructions, `INDEX.md`, `procedures.md`, `state.md`, operating protocol, provenance guide, the approved design (`workload-identity-network-design.md` sections 2, 6.2, 7, 9, 14, 15), writer reports 02, 04, 05, 07, re-audit 03 (for #72 context), the PR body.
- Inspected: the whole diff; every production caller of `callerauth.ParseSPIFFEID`, `callerallowlist.*` and `policy.SubjectFromSPIFFEID`; the five services' authentication paths (`ars/api`, `ags/api`, `egs/api`, `cgs/api`, `es/api`); every file in the tree that names `execution.internal/workload` or a `workload/` path; every shipped allowlist (`.examples/config/*.json`, `scripts/72_supported_local_setup.sh`) and `cgs/policy/id.conf`; the status collectors' SPIFFE checks; every doc that restates the section 3A rule; the F1 status-sentence machinery in `workload_grants_docs_contract_test.go`.
- Not inspected: the live box's `ars.json`, `ags.json`, `es.json` and `id.conf` (no box access in this audit; see O4). macOS behaviour beyond CI's result. The Linux CI run on `5dfcc1c` was still running when this report was written.

## 4. What the PR does (verified)

- `internal/callerauth/callerauth.go:102-108`: after the segment check (`:94-98`) and the trust-domain check (`:99-101`), `ParseSPIFFEID` returns the new `ErrWorkloadIdentity` when the first path segment equals `workload` under `strings.EqualFold`. Segments are already restricted to ASCII `A-Za-z0-9._-` by then, so Unicode case folding (for example the Kelvin sign) cannot reach the comparison. Every service authenticates through `CallerFromConnectionState`, which calls `ParseSPIFFEID` (`:184`), so the refusal is a 401 at ARS, AGS, EGS, CGS and ES alike.
- `internal/callerallowlist/callerallowlist.go:45-50`: a prefix under `workload` returns `ErrWorkloadPrefix` at startup (ARS, AGS, ES configs call `ValidatePrefixes`). `Matches` re-validates, so such a prefix matches nothing.
- `cgs/policy/idfile.go:324-329`: a specific message for a workload principal. Note (O5): CGS already refused these principals before the PR, because `SubjectFromSPIFFEID` accepts only `service/<x>` and `script/<x>`; only the message is new.
- Docs: section 3A states the rule as current; 11.2 records that WI-3a landed; `PLANS.md` F1 status line and its pin updated; configuration reference lists the prefix refusal.

**Strictly narrowing.** The head's accepted set of `ParseSPIFFEID` and `ValidatePrefix` is the base's minus IDs and prefixes whose first segment is `workload` in any case; CGS `id.conf` accepts exactly the same set as before. No new acceptance path exists. No shipped config, example, setup script or upgrade path writes a `workload` prefix or principal (shipped prefixes: `operator/local`, `service/control-plane`, `service/execution`, `service/artifact-governance`; `id.conf`: `service/execution`, `script/bot_test_privileged`). All other uses of `spiffe://execution.internal/workload` in the tree are JWT-SVID subjects and Vault `bound_subject` values, which never pass through `callerauth`.

**Design conformance.** Matches design T10, section 6.2 and the WI-3a row of 15.2, and contract 11.2 (`runtime_identity_handoff.md:265-270`): refuses `workload`, `workload/<name>` and the reserved `workload/<name>/run/<id>`, at every service, with tests. Case-insensitivity is a stricter, documented choice. #73 (WI-2) validates `publisher_principal` with the same parser (`es/config/workload_grants.go:147` on #73), so once both land a workload publisher principal is refused at ES startup too, which agrees with 5B.

**No widening** of supported-local or Remote Alpha behaviour: refusal-only, and nothing either path writes is refused.

## 5. Findings

### A1 (Low, test/doc gap; patch defect): two current-contract restatements now describe a set the code no longer accepts

Current contract: `.docs/system_overview/contracts.md` section 3A (as changed by this PR). Project rule: a PR that changes behaviour updates the affected docs in the same PR (`procedures.md`, Docs and READMEs).

- `.docs/execution_lifecycle/contracts.md:261-267` defines the authenticated caller identity: "the verified client certificate carries exactly one URI SAN, and that URI is a conforming SPIFFE ID with a path in the trust domain `execution.internal`. Anything else ... is `401` before allowlist matching." `spiffe://execution.internal/workload/codex-agent` meets that definition and is now `401`.
- `.docs/system_overview/contracts.md:819-824` (section 7, ES): "Accepted prefixes are relative SPIFFE path prefixes with at least two non-empty path segments, no leading or trailing slash, and no `.` or `..` segment, and every segment uses only ...". `workload/codex-agent` meets that and is now refused at startup. This file is one the PR edited.
- Less sharp, same fix: `PLANS.md:304` ("Only a verified client certificate ... with exactly one URI SAN that is a conforming SPIFFE ID in the trust domain `execution.internal`, identifies a caller") and `.docs/execution_lifecycle/contracts.md:271-276` list necessary conditions only. Not false, but they read as the whole rule and omit the new one.

Impact: a reader of the lifecycle contract or section 7 would conclude a workload SVID authenticates. The authoritative section 3A is right, so this is doc drift, not a behaviour risk.
Required correction: add the workload exclusion to the two definitions (or point them at section 3A instead of restating it); optionally the same clause in `PLANS.md:304-305` (PLANS.md is 149,179 bytes, cap 150,000).

### N1 (nit, test code): stale doc comment kept above the new one

`internal/callerauth/callerauth_test.go:153-158`: the old comment ("plus this package's two additions") still precedes the new comment for `referenceAccepts`, so the function's doc reads as two contradictory paragraphs. Delete lines 153-155.

### N2 (nit): package doc wraps mid-sentence

`internal/callerauth/callerauth.go:4-6`: "... or a workload\n// identity, when the\n// verified chain ..." leaves a short line in the package doc. Reflow.

### N3 (nit, test): one assertion cannot fail

`internal/callerallowlist/callerallowlist_test.go:108-110` checks that a workload prefix does not match the caller `operator/local`. That caller never matches such a prefix with or without the rule. The property holds by construction (no `callerauth.SPIFFEID` with a workload path can exist), so either drop the assertion or say in a comment that the guarantee is structural.

### N4 (nit, docs pins): three new sentences are unpinned

Deletion probes survived the whole root package: D1 (the `configuration.md:296-298` prefix bullet), D2 (11.2 "This part is implemented: WI-3a landed it, and the refusal ignores letter case."), D5 (section 3A "A path that only contains the word later, such as `service/workload`, or whose first segment is longer, such as `workloads`, is not affected."). The behaviour behind each is pinned by Go tests; only the doc text is free to drift. Add them to `TestWorkstreamFF1IsPlannedAndPointedTo` or the F1 decision test if the repair touches that file anyway.

### Observations (not blocking; route as noted)

- **O1 (red-team scope):** section 6.
- **O2 (WI-3 brief):** `ParseSPIFFEID` now carries caller policy, and its comment says it is for caller identities only (`callerauth.go:83-85`). WI-3's helper expected-ID check and readiness checks parse workload IDs and must use a separate parser. Misuse fails closed (it refuses every workload ID), so tests would catch it at once.
- **O3 (WI-3 brief):** T10's closure rests on the layout: every SPIRE entry that a workload can obtain lives under `/workload/`. Design section 7's readiness checks cover `/workload` entries' selectors and names, but not "no entry carrying a workload selector (Docker label) has a path outside `/workload/`". Worth adding in WI-3.
- **O4 (box, before upgrading the box to a tree with #72):** extend the PR #38 pre-deploy check of live `ars.json`, `ags.json`, `es.json` prefixes to also refuse a first segment `workload` in any case. Unknown whether the box has one; repo writers never wrote one. If it does, ES/ARS/AGS refuse to start with `ErrWorkloadPrefix` (fails closed, clear message).
- **O5:** CGS `id.conf` already refused workload principals before this PR (section 4). The PR body's "CGS id.conf refuses a workload principal with a message that says why" is accurate; the behaviour is not new.
- **O6 (merge order, pre-existing):** `PLANS.md` cap. `trunk_dev` + #70 = 150,155 bytes and #71-tip + #67 = 150,133, both already over 150,000 without #72. With #72 (+54 bytes): 150,209 and 150,187. #69 (130,579 with #72) must land first. Re-audit 03 named only #70; #67 is new here.
- **O7:** #73 (head `affefc6`) conflicts with #72 in `PLANS.md` and `workload_grants_docs_contract_test.go` (the F1 status line and its pin), as both writers expect. After both land the line must say WI-2 and WI-3a are implemented; the status test forces that (the #72 line lists the WI-2 part).
- **O8 (process):** no implementation report for #72 was delivered to the shared folder; the PR body served as the report and carried no manifest until report 07. The `a3710c0` target was therefore bound by my own manifest only.
- **O9:** the two `f1StatusSentences` entries for the removed section 3A sentences stay in the table (`workload_grants_docs_contract_test.go:278-281`). They are skipped while absent and would fire if the sentences came back. Fine as a re-introduction guard.
- **O10 (merge gate):** CI on `5dfcc1c` was in progress at 23:55Z. "test on macOS" passed on `a3710c0` (same tree); "build, vet and test" on `a3710c0` was cancelled by the rebase.

## 6. Red-team scope (asked by the coordinator)

Facts:
- `procedures.md`, Red-team scope: "reserved for major PRs, meaning non-trivial PRs into `trunk_dev` or `main`, first and foremost in ES." The only deferral it allows is "A fix PR into the branch of such a PR is covered by red-teaming the combined change before it merges into `trunk_dev`." Everything else gets no red-team unless the coordinator judges it security-critical.
- #72 now targets `trunk_dev` directly. It is ES product code that changes the authentication rule all five services share. It is small (about 30 product lines) and refusal-only.
- The approved design is inconsistent: section 15's opening says "Each gets a fresh audit, a separate red-team and the full provenance and merge gate", while the WI-3a row says "audit; red-team folded into WI-3's". The repo contract written by #71 (`runtime_identity_handoff.md` 11.10, now on `trunk_dev`) lists WI-3a's gate as "Audit and the merge gate".

My reading: #72 is a non-trivial ES PR into `trunk_dev` (a security boundary of every service), so the procedure requires a red-team. "Folded into WI-3's" is a deferral the procedure does not list, has no machine-enforced trigger, and WI-3 itself waits on P1, P2 and a box turn, so the change would sit on `trunk_dev` unred-teamed for an open period. Inference: a red-team here is cheap, because the surface is one comparison plus its configuration paths.

Recommendation: a short, separate red-team on `5dfcc1c` (or its repaired successor) before merge. Targets: near-miss caller URIs (case, Unicode look-alikes, percent encoding, trailing dot, `workload.`/`workload-`/`workload_` first segments, empty segments, scheme case), multiple SANs, bootstrap-issuer ordering, allowlist and `id.conf` forms, and that every route of every service answers 401. If the coordinator instead keeps the deferral, it should record that judgment and make 11.10 say the WI-3a red-team happens in WI-3's.

## 7. Validation

All runs as `ci` on the exact trees (head `1f92adc2`, base `178defa9`); scripts in evidence.

| Run | Result |
| --- | --- |
| `go test -count=1 -timeout 40m -json ./...`, head | exit 1, 511 s. 49 packages (28 pass, 18 no tests, 3 fail). 10,295 test entries: 10,115 pass, 45 fail, 135 skip |
| same, base | exit 1, 424 s. 10,176 entries: 9,996 pass, 45 fail, 135 skip |
| head vs base | failing sets identical (45 = 45); no test changed status; 119 new entries at head, all pass (the four new refused cases in every service's route test: es/api 56, ars/api 24, egs/api 8, ags/api 4, cgs/api 4; callerauth 8; new fuzz seeds 13; the two new tests). The other 44 only-head / 44 only-base names are randomly named subtests of the PR 12 red-team tests in `es/admission` |
| root package `.` | pass on head and base (includes the F1 status tests and the PLANS cap) |
| `gofmt -l` on changed Go | clean |
| `go vet ./internal/callerauth/... ./internal/callerallowlist/... ./cgs/... .` | clean |
| Fuzz `FuzzParseSPIFFEIDAgreesWithTheSPIFFEReferenceParser` 90 s, `FuzzPrefixRule` 60 s | pass (2.8 M and 4.1 M execs) |

The 14 failing top-level tests, identical on head and base (environment-only in this container: no Nomad, Vault, SPIRE or Docker daemon, no older binaries to build):
`es/admission/internal/reliablesubmit`: `TestOperationalHandoffSchema4BinaryRefusesSchema5`, `TestSQLiteV3OldBinaryRefusesWithoutMutation`, `TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation`.
`es/app`: `TestLinuxSetupBootstrapFinishesWithItsSavedSecret`, `TestNomadACLToolRetriesABootstrapThatNeverTookEffect`.
`scripts`: `TestRemoteAlphaESServiceTLSStatusFailureWitnessBootstrapOwnedTerminal`, `TestRemoteAlphaESServiceTLSStatusRootLoadedStageCustody`, `TestRemoteAlphaESServiceTLSStatusStageFIFOSubstitution`, `TestRemoteAlphaOperatorRecoverySessionESTLSStatusRemoteWrapperTrap`, `TestRemoteAlphaOperatorRecoverySessionESTLSStatusStageFIFORefusal`, `TestRemoteAlphaP0tGrammarDiagnosticBootstrapLifecycleComposition`, `TestRemoteAlphaP0tGrammarDiagnosticPriorReaderCloseSuppression`, `TestRemoteAlphaP0tGrammarDiagnosticV2VersionedBootstrap`, `TestRemoteAlphaUpgradeESCheckRefusesWhatItWasNotWrittenFor`.
All 45 failing entries: `head-failing-entries.txt` (byte-equal content to `base-failing-entries.txt`).

### Mutants (19, one at a time in a clean copy of the head tree)

Code mutants ran against `./internal/callerauth/... ./internal/callerallowlist/... ./cgs/... ./ags/... ./ars/... ./egs/... ./es/api/... ./es/config/...`; doc probes against the root package.

| ID | Mutant | Result (a killing test) |
| --- | --- | --- |
| M01 | drop the refusal | killed (every service's route tests) |
| M02 | case-sensitive compare | killed (`workload_identity_upper_case` route cases) |
| M03 | refuse only the exact path `workload` | killed |
| M04 | prefix without segment boundary (`workloads/…` refused) | killed (callerallowlist accepted-prefix tests, fuzz seeds) |
| M05 | refuse `workload` in any segment | killed |
| M06 | check before trust-domain check | killed (`TestParseSPIFFEIDRefusesEverythingElse`: foreign-domain workload ID) |
| M07 | check before segment validation | killed (`TestParseSPIFFEIDRefusesEverythingElse`) |
| M08 | report `ErrMalformedSPIFFEID` | killed (callerauth, callerallowlist, cgs tests) |
| M09 | allowlist: drop the `ErrWorkloadPrefix` branch | killed |
| M10 | allowlist: every parse error becomes `ErrWorkloadPrefix` | killed |
| M11 | CGS: drop the workload message | killed |
| M12 | CGS: workload message for every parse error | killed |
| M13 | refuse only paths with a second segment | killed (`workload_identity_shared` route cases) |
| D1 | delete the configuration.md prefix bullet | **survived** (N4) |
| D2 | delete the 11.2 "This part is implemented" sentence | **survived** (N4) |
| D3 | drop "in any letter case" from the 3A rule | killed |
| D4 | PLANS F1 back to "not yet implemented" | killed |
| D5 | delete the 3A near-miss sentence | **survived** (N4) |
| D6 | 11.10 WI-3a row says "not yet implemented" | killed |

Each mutant's diff and failing tests: `mutants.json`.

### Trial merges with the other open PRs (`git merge-tree --write-tree 5dfcc1c <head>`)

| PR | Head | Merge | Tests on the merged tree |
| --- | --- | --- | --- |
| #73 | `affefc6` | conflict: `PLANS.md`, `workload_grants_docs_contract_test.go` (O7) | not run (writer resolves) |
| #70 | `a0e86ea` | clean | root + the eight auth packages: only `TestPlansStaysWithinItsSizeCap` fails (pre-existing, O6) |
| #69 | `8246cb2` | clean | not run (PLANS-only; 130,579 bytes) |
| #68 | `e760c67` | clean | root + the eight auth packages (it moves EGS files): 2,579 pass, 0 fail |
| #67 | `69d53de` | clean | not run (scripts; PLANS 150,187, O6) |
| #66 | `84da2da` | clean | not run (scripts) |
| #63 | `59f1f56` | clean | not run (scripts) |

## 8. Sensitive material

None read or copied. Manifests hold only paths, modes, sizes and hashes. The evidence diff is the PR's own public diff. Test runs used no tokens or proxy variables (`env -i`).

## 9. Confidence

- Provenance: 0.99 (manifest reproduced byte-for-byte, equal to the writer's, opening = closing, trees identical across the rebase).
- Validation: 0.9 (whole suite on exact trees with identical environment-only failures; the CI Linux run on `5dfcc1c` was not finished; live box not exercised).
- Implementation: 0.9 for the code (simple, ordered after existing checks, all 13 code mutants killed); the Low is documentation only.

## 10. Remaining uncertainty and stop conditions

- Unknown: whether any live box allowlist names a `workload` prefix (O4).
- Red-team requirement is a judgment the coordinator owns (section 6).
- No stop condition hit.

## 11. Evidence

Folder `08-pr72-audit-evidence/` with `SHA256SUMS`. Main files: `manifest-5dfcc1c-open.json`, `manifest-5dfcc1c-close.json`, `manifest-a3710c0-open.json`, `manifest-a3710c0-close.json`, `full-head-summary.txt`, `full-base-summary.txt`, `head-vs-base-compare.txt`, `head-failing-entries.txt`, `base-failing-entries.txt`, `mutants.json`, `trial-merges.txt`, `trial-t68-summary.txt`, `trial-t70-summary.txt`, `pr72-5dfcc1c.diff`, and the scripts (`gotest.sh.txt`, `sigreset.py.txt`, `mutants.py.txt`, `compare.py.txt`, `summarize.py.txt`).

## 12. Verdict

**BLOCK.** Repair scope: A1, plus N1 to N4 in the same round. A narrow re-audit can check those docs and test lines plus provenance. Red-team: required in my reading of the procedure (section 6); coordinator's call.
