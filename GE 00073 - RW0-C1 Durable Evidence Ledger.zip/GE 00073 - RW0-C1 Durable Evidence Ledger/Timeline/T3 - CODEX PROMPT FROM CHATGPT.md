PROMPT_ID

RW0_B2_EXACT_CURRENT_EFFECT_CANCELLATION_RECONCILIATION_V1

TITLE

Coordinator RW0-B2 — read-only reconciliation of exact-current-effect
cancellation semantics before RW0-C

ENGAGEMENT TYPE

Read-only architecture and semantic-owner reconciliation.

Do not modify repository files.
Do not run tests, migrations, mutation probes, node collection, or validation.
Do not stage, commit, push, create a PR, merge, release, or deploy.
Do not contact a verifier, custodian, worker, provider, host, Execution
Substrate, Bridge, or supporting repository.
Do not issue an implementation prompt.

Print the complete substantive response inline in chat. Evidence paths may be
supplementary only.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

EXPECTED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
dd12b23762dc761736e55a1abfde12dd3ec23551

parent:
deec37bf08fb903d8846aa2c3232aec52fa9866e

subject:
feat: implement RW0-B2 Capability semantics (#5)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktree:
clean

No fetch or remote contact is authorized. Report any mismatch against the
locally recorded baseline.

BACKGROUND DECISION

The RW0-C C1/C2 decomposition remains accepted in principle:

C1:
- durable no-contact phase instance;
- immutable typed supplied-evidence membership;
- exact bindings;
- replay/conflict;
- private readback;
- commit-uncertainty recovery;
- no completeness, decision, terminal outcome, latch, external contact, or
  public caller.

C2:
- immutable decision-basis closure;
- unchanged C2B decision persistence;
- productive-direct-local accept plus latch mutation in one transaction;
- immutable terminal-basis closure;
- separate terminal-outcome persistence;
- active-cancel reconciliation;
- exact recovery;
- no external contact or successor launch.

RW0-C is not authorized for implementation until the cancellation-owner seam is
reconciled.

CONFIRMED CONTRADICTION TO RECONCILE

The accepted RW0 phase target permits cancellation of the exact current:

- author_candidate;
- validate_candidate;
- review_candidate.

C2A already supports cancel_effect targeting all three classes, including the
capsule-bound validation/review graphs.

Current RW0-B2-Wire v1 is author-only:

- the fixed profile states request target author_candidate;
- request relation requires target.effect_class == author_candidate;
- process relation requires target.effect_class == author_candidate;
- the classifier substitutes the author fence as the cancellation target.

C must not duplicate, reinterpret, or bypass Wire-owned relations.

PRIMARY OBJECTIVE

Freeze the smallest additive B2 owner change that supports supplied fake
cancellation-control facts for the exact current author, validation, or review
effect while preserving every existing v1 identity and behavior.

Do not broaden this into persistence, process control, transport, or runtime
implementation.

STRATEGIC PREFERENCE TO TEST

Evaluate this target hypothesis:

1. Preserve the complete current `rw0-wire-nwpf-v1` profile, ref, digest,
   values, functions, tests, and Capability binding byte-for-byte.

2. Add a separate versioned B2 cancellation-control evidence contract/profile
   rather than replacing the worker command/result profile.

3. Reuse the existing generic source-claim value schemas where their field
   meanings already suffice:
   - RW0WireCancellationRequestObservationV1;
   - RW0WireProcessObservationV1.

4. Add exact-current-target relations that accept target effect classes:
   - author_candidate;
   - validate_candidate;
   - review_candidate.

5. Require the exact target delivery and:
   - no capsule manifest for author;
   - exact CandidateCapsuleManifestV1 for validation/review.

6. Validate the cancel effect/delivery against that exact target.

7. Add a cancellation-control classification contract that classifies only the
   supplied request/acknowledgement/rejection/signal/process/exit/control graph.
   It must not claim:
   - target semantic success;
   - worker-result success;
   - teardown completion;
   - terminal outcome;
   - durable truth;
   - permission or acceptance.

8. Let RW0-C2 combine this cancellation-control classification with C2A
   target-specific observations and later reconciliation facts.

9. Avoid changing RW0-B2-Capability unless repository evidence proves the
   cancellation-control profile is inseparable from the worker-protocol pair.

This hypothesis is not preapproved. Reconcile it against current owner
contracts.

REQUIRED INSPECTION

Read completely or in every relevant owning section:

- AGENTS.md
- README.md

- .docs/rw0-remote-worker-contact-phase-entry.md
- .docs/rw0-b2-wire-protocol.md
- .docs/rw0-b2-capability.md
- .docs/rw0-b1-pure-phase-values.md
- .docs/c2a-first-slice-semantic-protocol-contract.md
- .docs/worker-execution-boundary.md
- .docs/authority-boundaries.md
- .docs/autonomous-software-development-operating-model.md

- src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
- src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
- src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
- src/ge_nwp_coordinator/_worker_execution_semantic_values.py
- src/ge_nwp_coordinator/__init__.py
- pyproject.toml

Inspect all direct tests for:

- Wire values;
- Wire relations;
- Wire boundaries;
- Wire codec;
- C2A effect/delivery/observation/cancellation relations;
- Capability values/relations/boundaries;
- RW0 phase/status;
- architecture and runtime non-authority.

Inspect additional Coordinator files only for a concrete dependency and state
why.

QUESTIONS TO ANSWER

A. Exact owner contradiction

- Reproduce the exact current target and exact Wire-v1 restriction.
- Identify every source, doc, profile, function, and test that pins author-only
  behavior.
- Identify every C2A value/relation/test that already supports validation/review
  cancellation.
- State whether the contradiction blocks:
  - C1 schema generally;
  - only target-complete C1 evidence admission;
  - C2 active-cancel closure;
  - or all of the above.

B. Value reuse

For each current Wire value, decide:

- reusable unchanged;
- reusable only under a new relation/profile;
- must remain v1-only;
- new value required.

At minimum cover:

- RW0WireCancellationRequestObservationV1;
- RW0WireProcessObservationV1;
- RW0WireWorkerResultV1;
- RW0WireProcessResultClassificationV1.

Do not change an existing schema ID, ordered field tuple, digest domain, enum,
or meaning unless the only defensible outcome is an explicit owner-version
change.

C. Relation freeze

Define the exact additive relation signatures and semantics needed for:

- exact-current-target cancellation request;
- exact-current-target process observation;
- acknowledgement/rejection relation;
- cancellation-control classification.

For author, validation, and review targets, identify exact required operands:

- author command;
- attempt fence;
- author fence;
- target fence;
- target delivery;
- capsule manifest where applicable;
- cancellation fence;
- cancellation delivery;
- request;
- acknowledgement/rejection observations;
- process observations;
- process-exit/deadline facts.

State exact relation precedence and content-free failure boundaries.

D. Classification boundary

Decide whether the current process/result classifier can be safely generalized,
versioned, or must remain v1-only.

The target classifier must distinguish:

- invalid graph;
- unrelated/conflicting facts;
- request pending;
- request acknowledged/rejected;
- signal delivered;
- deadline elapsed;
- process exit/control evidence incomplete;
- finite cancellation-control usability.

It must not classify validation/review semantic results or terminal outcomes.

State whether a new classification value is required or whether the current
classification value can be reused without semantic ambiguity.

E. Profile and identity decision

Explicitly compare:

Option 1:
new combined `rw0-wire-nwpf-v2` profile.

Option 2:
new separate cancellation-control evidence profile under the Wire owner while
keeping `rw0-wire-nwpf-v1` as the worker protocol pair.

Option 3:
another finite owner split justified by repository evidence.

For each option evaluate:

- identity churn;
- Capability impact;
- B1 readiness/host-qualification impact;
- current profile preservation;
- direct-local and ES neutrality;
- C1 evidence binding;
- C2 closure;
- test and audit complexity.

Recommend one.

F. Capability impact

Determine whether current Capability declaration, observation, qualification,
and fixed Wire pair can remain unchanged.

If Capability must change, specify:

- why a separate cancellation profile is insufficient;
- whether new Capability identities are required;
- whether current values remain valid;
- whether this becomes a second B2 owner tranche.

Do not hide Capability churn inside Wire implementation.

G. RW0-C unblock contract

State exactly what the reconciled B2 contract would let C1 durably record and
what C2 could close.

Provide the revised C1 evidence-member inventory and identify:

- full safe projections;
- ref/digest-only dependencies;
- profile pairs;
- relation proofs.

Confirm whether C1 can then freeze migration 0004 independently of C2.

H. Authority and nonclaims

The reconciliation must add no:

- transport;
- process launch/control;
- signal delivery;
- source authentication;
- external contact;
- provider/session behavior;
- credential handling;
- persistence;
- public export;
- production caller;
- semantic acceptance;
- terminal outcome;
- runtime or ES authority.

Preserve RW0-D/E and ES ownership.

I. Acceptance evidence architecture

For every permanent test, map it to a finite product claim:

- v1 preservation;
- new identity/profile;
- value compatibility;
- author/validation/review target relations;
- capsule requirements;
- cancellation graph orientation;
- classifier precedence;
- privacy/error boundary;
- no-I/O/private/no-caller boundary;
- Capability non-churn or explicit versioned churn.

Independent audit owns external mutants and exact patch provenance. Do not
introduce a self-protecting test framework.

J. Scope and sequencing

Return:

- exact governing docs likely touched;
- exact source modules likely touched;
- exact tests likely touched;
- protected files;
- maximum touched-file ceiling;
- whether work can be one tranche;
- contract-first, implementation, audit, commit, merge order;
- whether RW0-C1 remains blocked until merge.

Do not implement.

FORECASTS

Record two or three falsifiable forecasts, including:

- whether current request/process values are reusable unchanged;
- whether a separate cancellation profile avoids Capability churn;
- whether the current classifier must remain v1-only;
- likely audit finding classes.

STOP CONDITIONS

Return `B2_CANCELLATION_ARCHITECTURAL_REPLAN_REQUIRED` if any of these are
established:

- existing v1 identity or meaning must be rewritten;
- C2A identity/relation churn is required;
- B1 identity/relation churn is required;
- Capability must be silently reinterpreted;
- target semantic result classification must move into Wire;
- persistence or physical process mechanics are needed;
- exact author/validation/review graphs cannot share a finite additive owner
  contract;
- a public or production caller is required.

OUTPUT

Print inline:

# Baseline and inspection boundary
# Exact contradiction
# Current v1 preservation
# Value reuse decision
# Exact-current-target relation contract
# Cancellation-control classification contract
# Profile and identity decision
# Capability impact
# RW0-C unblock ledger
# Authority and privacy
# Acceptance evidence architecture
# Exact touched-file ceiling
# Forecasts and stop conditions
# Recommendation
# Next implementation boundary

End with exactly one:

RW0_B2_CANCELLATION_OWNER_RECONCILIATION_READY

or

B2_CANCELLATION_ARCHITECTURAL_REPLAN_REQUIRED

Required final statements:

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
