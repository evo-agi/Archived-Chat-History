PROMPT_ID

RW0_C1_FINAL_HANDOFF_AND_PRECOMMIT_CLEANUP_REPAIR_V1

TITLE

Coordinator RW0-C1 — repair the final response-handoff uncertainty boundary,
preserve primary precommit errors, and seal exact test-only provenance for the
last findings repair

ENGAGEMENT TYPE

Final bounded parent-only workspace-write findings repair in the original
RW0-C1 implementation conversation.

Do not delegate to subagents.

This is not an architecture, schema, DNC, privacy, or evidence-kind redesign.
Preserve every accepted RW0-C1 decision and every unaffected candidate byte.

Do not stage, commit, push, create a PR, merge, tag, release, deploy, fetch,
contact a remote/live system, install dependencies, invoke a product
worker/model, modify a supporting repository, or migrate an operator database.

Print the complete substantive result inline. Evidence paths may be
supplementary only.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED OPENING IDENTITY

Require exactly:

branch:
codex/rw0-c1-durable-evidence-v1

HEAD:
047563de5a443b0f8323401c92979ae2e444d2ed

HEAD tree:
4ff9ee4a710af13447e3ed8699339a51255ff720

sole parent:
dd12b23762dc761736e55a1abfde12dd3ec23551

subject:
feat: add RW0-B2 cancellation-control evidence (#6)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

staged/unmerged:
0/0

candidate:
exactly 81 changed/untracked paths, all regular physical mode 0644

opening canonical manifest SHA-256:
d8c535c68e4096b5e00998d57f504e6139402c4207a0d0a0749fbf2b4c42d936

opening full-candidate textual diff SHA-256:
c21ac61476e8369746b8420ac0f0d2d54a73599b304005575409e0e3641e537e

opening complete recipe output SHA-256:
d8574b02c42e7f23b0eddca5ae04bf864345d0b5448e5d88e2b18a9fcc82fb24

opening nodes:
5200

opening ordered node SHA-256:
1337267bfd05f4b5d99db5f987d8c9fcecf85deedc95530ab9c4fa30b2526cc1

No fetch is authorized.

RETAINED EVIDENCE ROOTS

Verify all predecessor roots read-only and preserve them unchanged.

Original implementation:
/private/tmp/ge-coordinator-rw0-c1-implementation.Zcopmg
index:
cd1ad5ea72ef20a774fd470e38f14882a25f99af94db970c4506c62d4a4cc2b4

Mode repair:
/private/tmp/ge-coordinator-rw0-c1-mode-repair.k6Pxw5
index:
5b30767c439a982e209c765f93c775547709555f5305697817a1b335e1bf2cc8

First provenance-stop audit:
/private/tmp/ge-coordinator-rw0-c1-independent-audit.6Cd8VB
index:
3929be307c05a532c491f5f520bad4d76cde702d7e0b41460cf0c8ab90373b25

First substantive audit:
/private/tmp/ge-coordinator-rw0-c1-independent-audit.bYt6vjqX
index:
c276c664922dc4ef87e7418c6657aaf9d61ddb05c643666019ff85c86796168e

First findings repair:
/private/tmp/ge-coordinator-rw0-c1-audit-findings-repair.li1vJX
index:
a62fb4458f838ad23bc23b47bcfbd6527906c94724ea1a1b3044e3bf871c9bc2

Fresh re-audit:
/private/tmp/ge-coordinator-rw0-c1-fresh-reaudit.tWw8xz
index:
424c482738213c716dadaa636dde7f7a838f10472b63b0e9dabd8b226d8d0e5d

Residual findings repair:
/private/tmp/ge-coordinator-rw0-c1-reaudit-findings-repair.iBwPRM
index:
e0a1b61edbf51373c99a4eb155c8c9c05c7c3c8f7239ac9d74db5997165ac52c

Final independent re-audit:
/private/tmp/ge-coordinator-rw0-c1-final-independent-audit.azvkGE
index:
0b3e2d19214b1d934e970dd34539837479d11e9c8f3c4e3da1eb5eccebbab461

Do not alter, clean, re-index, normalize, or “repair” any predecessor root.

FINDINGS TO REPAIR

RW0-C1-FINAL-001 — High candidate defect

After the current final helper publishes `close_proof_complete`, an ordinary
failure at the final writer-result handoff can still escape raw. This affects:

- a mutation whose underlying COMMIT succeeded;
- a recovery whose disposition was already computed.

A real committed mutation remains recoverable as `committed_exact`.

RW0-C1-FINAL-002 — Medium candidate defect

Primary pre-result safe-error precedence is not retained through operation
retirement:

- invalid recovery input establishes `mutation_failed`;
- a later operation-lease cleanup failure replaces it with raw RuntimeError.

A standalone ordinary cleanup failure on an exact replay path also escapes raw
despite no additional COMMIT.

RW0-C1-FINAL-003 — Medium report/evidence defect

The historical residual-repair red gate did not seal exact before/after test
hashes or a test-only patch. The old history cannot be rewritten.

The present repair must create complete prospective test-only provenance before
production source changes. Do not claim that this repairs the historical
record; it supplies acceptance-bearing causal evidence for this final repair.

ARCHITECTURAL DISPOSITION

Do not change or reopen:

- migration 0004 SQL, checksum, or catalog;
- 23/46/4 C1 schema delta or 62/110/5 cumulative totals;
- C1/C2 decomposition;
- 15 evidence kinds;
- membership, DNC, relation, reader, temporal, snapshot, rank-13/rank-14, and
  privacy contracts;
- caller-constructible recovery selector;
- current-state CAS ordering;
- owner-reader error propagation;
- one controller, one connection path, and one COMMIT attempt;
- package exports, StateStore, or public WriterSession protocol;
- B1, Wire, Capability, C2A, C2B, or Section 41 owners;
- no C2, D/E, ES, Bridge, worker, process, provider, runtime, or external
  contact behavior.

The final audit passed DNC, schema, privacy, authority, node reconciliation, and
the previously closed findings. Do not repair those surfaces speculatively.

PRIMARY ENGINEERING DECISIONS

A. KEEP NORMALIZATION ACTIVE THROUGH THE ACTUAL RETURN BOUNDARY

The current defect exists because publishing `close_proof_complete` disables
normalization while the writer frame can still execute fallible response-
handoff code.

Repair the private commit-close and recovery-close witnesses so that:

1. `close_proof_complete` means internal cleanup has completed, not that the
   caller has already received the result.
2. The outermost writer-session C1 apply/recovery frame encloses the final
   result handoff and `return` in the same ordinary-exception normalization
   boundary.
3. The witness is not cleared, disabled, reset, or detached before that frame
   exits successfully.
4. An ordinary exception raised:
   - after `close_proof_complete`;
   - during the final helper result publication;
   - on the controller/module/writer return path;
   - or on the final return line before frame exit
   is still normalized according to operation posture.
5. No additional durable witness state or public handoff marker is introduced.
   A successfully returned frame naturally ends the private witness lifetime.

Commit posture:

- If the sole COMMIT attempt has begun, every ordinary exception before the
  outer writer frame successfully exits is exact content-free
  `commit_outcome_unknown`.
- This remains true when the witness state is `close_proof_complete`.
- Selector-based recovery must return `committed_exact` after a real COMMIT.

Recovery posture:

- After a recovery disposition has been computed, every ordinary exception
  before the outer recovery writer frame successfully exits is exact
  `unresolved`.
- This remains true when the recovery witness state is
  `close_proof_complete`.
- Recovery never uses `commit_outcome_unknown`.

Implementation requirement:

- The final `return result` or equivalent response handoff must be inside an
  outer try/except capable of applying the witness rule.
- Do not leave any ordinary fallible code after disabling normalization.
- Do not attempt to persist a `handoff_complete` state; successful frame return
  is the handoff.

B. PRIMARY SAFE ERROR PRECEDENCE

Preserve an already established primary safe error through operation retirement.

Required precedence:

1. Governing `KeyboardInterrupt`, `SystemExit`, `GeneratorExit`, and existing
   process-control precedence remain unchanged.
2. If a primary safe `WriterSessionError`, `SQLiteMutationStoreError`, or
   private C1 safe error was established before cleanup, a secondary ordinary
   cleanup failure must not replace it.
3. Re-raise or return the original primary safe error without exposing the
   secondary private cleanup exception, content, or traceback.
4. Do not convert a primary precommit safe error into
   `commit_outcome_unknown`.

Standalone cleanup failure with no primary error:

- Fresh apply or exact replay/conflict path with no COMMIT attempt:
  return/raise the existing content-free `mutation_failed` classification.
- Recovery after a computed disposition:
  return exact `unresolved`.
- Mutation after COMMIT attempt started:
  return/raise exact `commit_outcome_unknown`.

Exact replay does not attempt another COMMIT. If its final operation retirement
fails ordinarily and no earlier safe error exists, it must produce
`mutation_failed`, never raw RuntimeError and never commit uncertainty.

Freeze this precedence in one private helper or one explicit outer control-flow
block. Do not duplicate divergent precedence logic across controller, module,
and writer layers.

C. WITNESS PREDICATES AND STATES

Preserve the existing state inventory unless a rename is needed solely for
clarity:

- precommit
- commit_attempt_started
- commit_returned_success
- close_proof_complete

Required predicates:

- commit-uncertainty normalization is active for:
  commit_attempt_started,
  commit_returned_success,
  close_proof_complete,
  until successful outer-frame exit.
- recovery-result normalization is active from computed disposition through
  close_proof_complete and final outer-frame exit.
- precommit replay/conflict/error paths remain outside commit uncertainty.

Keep witnesses private, slotted/final/one-operation/monotonic/non-reusable and
non-durable. No schema, SQL, or public value change.

D. CAUSAL PERMANENT TESTS

Add ordinary product tests for each exact boundary.

1. Committed apply final handoff

- perform a real underlying COMMIT;
- complete internal cleanup and publish `close_proof_complete`;
- inject one ordinary failure on the final writer-result handoff/return;
- require exact `commit_outcome_unknown`;
- recover with the pre-retained selector as `committed_exact`;
- require one membership and one receipt.

2. Recovery final handoff

- compute `committed_exact`;
- complete internal cleanup and publish recovery close proof;
- inject one ordinary failure on final writer recovery handoff/return;
- require exact `unresolved`;
- no raw or narrower error.

3. Primary safe error plus cleanup failure

At minimum:

- invalid recovery input establishes `mutation_failed`;
- operation-lease cleanup then fails ordinarily;
- caller still receives exact `mutation_failed`;
- raw cleanup error is not exposed.

Add equivalent coverage for one relevant WriterSessionError or private C1 safe
error if the current control flow has such a reachable primary branch.

4. Exact replay standalone cleanup failure

- establish one committed family;
- invoke exact replay;
- do not invoke COMMIT;
- fail operation retirement ordinarily;
- require exact `mutation_failed`;
- retain exactly one membership and receipt;
- no raw error and no `commit_outcome_unknown`.

5. Witness-close state

- prove commit normalization remains active in `close_proof_complete`;
- prove recovery unresolved normalization remains active in
  `close_proof_complete`;
- preserve monotonicity, one-shot, and no-reuse tests.

No line-trace-only test is sufficient by itself. Use explicit injectable private
hooks/helpers where possible, with one external line-trace probe reserved for
independent audit. Do not add production testing hooks to a public surface.

E. TEST-FIRST PROVENANCE REPAIR

Before any production source change:

1. Create a new private evidence root.
2. Copy every test file in the bounded repair allowlist into an immutable
   opening snapshot.
3. Record for every file:
   - relative path;
   - type;
   - mode;
   - size;
   - SHA-256.
4. Copy every production file in the bounded repair allowlist into a separate
   immutable opening snapshot and record the same inventory.
5. Modify tests only.
6. Before running the red gate, create:
   - a complete red-test file snapshot;
   - a before/after test hash ledger;
   - an exact unified or binary test-only patch generated from the immutable
     opening and red snapshots;
   - aggregate SHA-256 values.
7. Verify every production file is byte-identical to its opening snapshot.
8. Run the selected red gate.
9. Retain exact argv, environment, stdout/stderr, JUnit, node IDs, timestamps,
   return code, and candidate fingerprint.
10. Require deterministic expected failures for:
    - committed final handoff;
    - recovery final handoff;
    - primary-safe-error precedence;
    - replay standalone cleanup.
11. Require no import, collection, syntax, fixture, path, or environment
    failure.

Because many C1 test files are untracked relative to HEAD, `git status` is not
accepted as test-content provenance. The immutable snapshots, hash ledgers, and
test-only patch are mandatory.

Preserve FINAL-003 as historical. Report that the new repair evidence is
prospectively complete rather than claiming the old evidence changed.

BOUNDED REPAIR ALLOWLIST

Only these repository paths may change.

Documentation — maximum 3:

.docs/rw0-c1-durable-evidence.md
.docs/sqlite-operations-and-recovery.md
.docs/writer-session-authority.md

Production — maximum 4:

src/ge_nwp_coordinator/_rw0_c1_mutation_contracts.py
src/ge_nwp_coordinator/_sqlite_rw0_c1.py
src/ge_nwp_coordinator/sqlite_transition_transaction.py
src/ge_nwp_coordinator/sqlite_writer_session.py

Tests — maximum 7:

tests/test_rw0_c1_mutation_contracts.py
tests/test_rw0_c1_private_atomic_persistence.py
tests/test_rw0_c1_recovery.py
tests/test_rw0_c1_writer_session_delegation.py
tests/test_b3c4c_prerequisite_contract.py
tests/test_b2a_writer_session_contract.py
tests/test_sqlite_b2c_writer_session.py

Maximum repository paths:
14

A listed path may remain byte-identical. No path outside this set may change.

If another repository path is required, stop before modifying it:

RW0_C1_FINAL_HANDOFF_REPAIR_SCOPE_CONFLICT

Protected:

- migration 0004 SQL and sqlite_migration.py;
- reader contracts and readers;
- DNC logic unless a direct regression from this repair is demonstrated;
- row/value/schema modules;
- semantic owner modules;
- migrations 0001–0003;
- package exports;
- StateStore;
- public WriterSession protocol;
- every other candidate path;
- supporting repositories.

VALIDATION

Create one new external evidence root:

/private/tmp/ge-coordinator-rw0-c1-final-handoff-repair.XXXXXX

Use:

umask 0022
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
unique evidence-root PYTHONPYCACHEPREFIX per Python process
distinct evidence-root TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
GIT_OPTIONAL_LOCKS=0
python3 -B
-p no:cacheprovider
-W error

Run serially with external basetemp, stdout, stderr, and JUnit.

After the causal red and production repair:

1. Selected final-handoff and precedence tests.
2. Every changed C1 test file.
3. All nine C1 test modules.
4. Writer/controller/cleanup compatibility.
5. Existing transition/global-stop/C2B transaction and cleanup regressions.
6. DNC, selector, CAS-order, reader-fault, and temporal regression groups.
7. Migration/schema/fixture compatibility.
8. Semantic-owner compatibility.
9. Architecture/status/privacy/non-authority.
10. External explicit probes:
    - committed final return;
    - recovery final return;
    - primary safe error plus cleanup;
    - exact replay cleanup.
11. Final collection.
12. One official complete-suite attempt.

Every credited run requires:

- return code 0;
- all collected cases passed;
- zero failures/errors/skips/xfails/xpasses/warnings;
- empty stderr;
- parseable JUnit;
- zero duplicate/unmapped cases;
- caller/child umask 0022;
- unchanged candidate fingerprint.

If complete-suite attempt 001 fails:

- retain it;
- classify candidate versus harness/environment;
- repair only within the 14-path scope;
- rerun affected focused groups and recollect;
- permit at most one attempt 002;
- no third attempt.

NODE RECONCILIATION

Opening nodes:

5200

Opening ordered SHA-256:

1337267bfd05f4b5d99db5f987d8c9fcecf85deedc95530ab9c4fa30b2526cc1

At final collection require:

- all 5200 opening nodes retained in exact relative order;
- zero removals or renames;
- zero added skip/xfail;
- all additions explicitly listed and attributable to allowed tests;
- no duplicate/volume-only parametrization;
- clean and live collections identical if a clean copy is produced.

PROVENANCE AND CLOSEOUT

Use the exact recipe:

recipe ID:
governed-execution.audit-patch-manifest.v1

source size:
3945 bytes

source SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

Use the already verified safe sink-redirection wrapper. Do not modify the
historical sink.

At closeout:

- verify exact branch/HEAD/upstream/worktree/topology;
- exactly 81 candidate paths, all regular mode 0644;
- only bounded repair paths differ from the opening candidate;
- no staged/unmerged/lock/operation/residue;
- `git diff --check`;
- migrations 0001–0004 and all protected owner bytes unchanged;
- no public/package/StateStore/WriterSession protocol widening;
- exact recipe twice with byte-identical manifests and complete outputs;
- report final manifest, textual diff, complete output, file count, and exact
  opening-to-final repair delta;
- verify every predecessor evidence root unchanged;
- remove only repair-created transient external paths;
- create a self-excluding evidence index last and independently reverify it.

HISTORICAL EVIDENCE

Do not rewrite earlier reports.

Preserve:

- FINAL-003 as a historical evidence limitation;
- all earlier audit findings and repairs as recorded;
- the final audit root as authoritative evidence of FINAL-001/002/003.

The new test-only snapshots and patch become the acceptance-bearing causality
evidence for this final repair.

SUCCESS TOKEN

Return exactly:

COORDINATOR_RW0_C1_FINAL_HANDOFF_REPAIRED_READY_FOR_FRESH_REAUDIT

only if:

- FINAL-001 and FINAL-002 are repaired;
- prospective test-only provenance is complete;
- no DNC/schema/privacy/authority/public regression occurs;
- all validation is green;
- provenance and cleanup are complete;
- no independent re-audit is claimed.

FINAL INLINE REPORT

Use:

# Outcome
# Opening identity and retained evidence
# FINAL-001 final handoff repair
# FINAL-002 primary-error and precommit cleanup precedence
# FINAL-003 prospective test-only provenance
# Test-first repair chronology
# Exact touched-path delta
# Focused validation
# Node reconciliation
# Complete-suite validation
# Provenance and cleanup
# Authority and nonclaims
# Remaining seams
# Confidence

Required final statements:

INDEPENDENT_REAUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
MIGRATION_SCHEMA_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
STATESTORE_PUBLIC_SURFACE_NOT_WIDENED
WRITERSESSION_PUBLIC_PROTOCOL_NOT_WIDENED
RW0_C2_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
