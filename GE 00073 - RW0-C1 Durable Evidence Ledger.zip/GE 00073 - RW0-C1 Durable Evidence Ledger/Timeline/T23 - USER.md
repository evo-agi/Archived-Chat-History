Here is Codex's response:



# Baseline and inspection boundary

Baseline matched exactly:

- Branch: `trunk_dev`
- HEAD: `047563de5a443b0f8323401c92979ae2e444d2ed`
- Tree: `4ff9ee4a710af13447e3ed8699339a51255ff720`
- Sole parent: `dd12b23762dc761736e55a1abfde12dd3ec23551`
- Subject: `feat: add RW0-B2 cancellation-control evidence (#6)`
- Upstream: `origin/trunk_dev`
- Ahead/behind: `0/0`
- Worktrees: exactly one
- Worktree/index/untracked/unmerged: clean

No fetch or remote operation was performed.

The required B1, Capability, Wire, C2A, Section 41, SQLite migration, transaction, writer-session, private-reader, recovery, status, architecture, source-inventory, and test-inventory surfaces were inspected. Historical references to migration 0003 were distinguished from live current-tip assertions.

# Accepted C1 architecture

C1 is one private, non-executable capability with two mutation families:

1. `establish_rw0_phase`
2. `admit_rw0_evidence`

It owns:

- one immutable phase instance per K8;
- a global typed evidence identity registry;
- immutable phase memberships;
- versioned relation bindings and ordered operands;
- exact replay, collision classification, CAS, fencing, and recovery;
- fifteen member kinds;
- no-contact supplied-fake-evidence admission.

It does not own completeness, a C2B decision, terminal outcome, acceptance latch, external contact, process execution, public API, or production caller.

No grouped-admission operation is needed. A single admission inserts one member. Every relation dependency is one of:

- an already admitted same-phase member;
- an immutable owner row read inside the transaction;
- a named transient admission operand, digest-bound by the command and intentionally unavailable after admission;
- a value embedded in the member being admitted.

The cancellation-control classification remains outside the member inventory. C2 recomputes it.

# Admission dependency DAG

The lookup order below follows receipt-first and exact phase/CAS lookup, which precede the listed kind-specific prerequisites.

| RankKindAdmission classExact prerequisite order |                                            |                                       |                                                                                                                                                                                                                                                  |
| ----------------------------------------------- | ------------------------------------------ | ------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| 1                                               | authority verification observation         | `requires_transient_private_operands` | phase; AttemptFence; author EffectFence; current EffectFence; WorkerCommand; optional target capsule manifest; optional cancellation-target EffectFence                                                                                          |
| 2                                               | subordinate authorization proposal         | `requires_same_phase_members`         | phase; exact rank-1 authority member; AttemptFence; current EffectFence                                                                                                                                                                          |
| 3                                               | custody availability observation           | `requires_transient_private_operands` | phase; either transient WorkSpec or immutable selected-artifact owner row                                                                                                                                                                        |
| 4                                               | retrieval capability event observation     | `requires_same_phase_members`         | phase; rank-1 authority; rank-2 subordinate proposal; rank-3 custody; prior rank-4 prefix members in sequence order; AttemptFence; current EffectFence                                                                                           |
| 5                                               | remote-host readiness observation          | `standalone_value`                    | phase only; readiness does not imply qualification                                                                                                                                                                                               |
| 6                                               | effect-host qualification                  | `requires_same_phase_members`         | phase; rank-1 authority; rank-5 readiness; current EffectFence                                                                                                                                                                                   |
| 7                                               | Capability declaration                     | `standalone_value`                    | phase only                                                                                                                                                                                                                                       |
| 8                                               | Capability observation                     | `requires_same_phase_members`         | phase; exact rank-7 declaration                                                                                                                                                                                                                  |
| 9                                               | Capability qualification                   | `requires_same_phase_members`         | phase; rank-7 declaration; rank-8 observation; rank-1 authority; rank-5 readiness; rank-6 host qualification; current EffectFence                                                                                                                |
| 10                                              | Wire cancellation-request observation      | `requires_transient_private_operands` | phase; command; attempt fence; author/target/cancellation effect fences; target/cancellation deliveries; target manifest when target is validation/review                                                                                        |
| 11                                              | Wire process observation                   | `requires_transient_private_operands` | phase; command; attempt fence; author/target effect fences; target delivery; target manifest when required                                                                                                                                       |
| 12                                              | C2A WorkerObservation                      | `requires_transient_private_operands` | phase; delivery; command; attempt/author/current fences; optional cancellation target; manifest and before/after blob sets when the owner relation requires them; cancellation responses additionally require the exact admitted rank-10 request |
| 13                                              | Wire worker-result binding                 | `wrapper_over_same_phase_members`     | phase; exact rank-12 `worker_started`; optional `candidate_captured`; exact `worker_completed`; command; delivery; attempt fence; author EffectFence                                                                                             |
| 14                                              | Wire process-result classification binding | `wrapper_over_same_phase_members`     | phase; optional rank-13 result; optional rank-10 request; rank-12 adapter facts in role order; rank-11 process facts in role order; command/delivery/fence owner rows; embedded target manifest                                                  |
| 15                                              | Section 41 post-execution family wrapper   | `wrapper_over_existing_owner_rows`    | phase; exact post-execution source invocation; artifact binding; proposal; then zero or exactly nine evidence rows in owner rank order                                                                                                           |

The rank-4 retrieval grammar admits only:

- `issued`
- `issued → redeemed`
- `issued → redeemed → consumed`
- either of the first two prefixes followed by one terminal `expired`, `revoked`, `failed`, or `unknown`
- singleton `failed`
- singleton `unknown`

Sequence numbers are `0..2`; sequence zero has no predecessor; later entries bind the immediately preceding admitted member. A terminal sequence cannot be extended. `(phase_basis_ref, safe_correlation_ref, sequence_number)` is unique, preventing branches.

Topological admission order is:

1. Phase establishment.
2. Roots: ranks 1, 3, 5, 7, 10, 11, non-response rank 12, and rank 15.
3. Ranks 2, 6, 8, and cancellation-response rank 12.
4. Rank-4 prefixes, rank 9, and rank 13.
5. Rank 14.

Every downward-closed subset is legal. A phase with no members is legal. C1 does not require all ranks, a complete retrieval sequence, a result, a classification, or nine Section 41 evidence rows.

Section 41’s existing owner algebra remains `0 or 9`, not “always 9.” Zero is valid C1 evidence of the owner family’s current empty evidence set; C2, not C1, decides whether that is complete enough for a decision.

# Relation-proof modes

The closed vocabulary is:
```
value_reconstructed
relation_recomputable
relation_attested_at_admission
derived_wrapper_recomputable
existing_owner_row_reconstructed
```

Every relation has `relation_version = 1`. An old version remains immutable and is never interpreted using a newer implementation.

| SubjectModeRelation IDProfileOrdered operandsCount |                                       |                                                                |                      |                                                                                                                                                                                                                   |   |
| -------------------------------------------------- | ------------------------------------- | -------------------------------------------------------------- | -------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | - |
| Phase                                              | `relation_attested_at_admission`      | `rw0.phase_entry_basis.owner_relation`                         | none                 | lineage, selection result, selection head, selected proposal, selected artifact, transient WorkSpec, attempt fence, author effect fence, author command, author delivery, effect head, delivery head, global stop | 1 |
| 1                                                  | `relation_attested_at_admission`      | `rw0.authority_observation.owner_relation`                     | none                 | phase, attempt fence, author/current effect fences, command, optional transient manifest, optional cancellation target                                                                                            | 1 |
| 2                                                  | `relation_recomputable`               | `rw0.subordinate_narrowing.owner_relation`                     | none                 | phase, authority member, attempt fence, current effect fence                                                                                                                                                      | 1 |
| 3                                                  | `relation_attested_at_admission`      | `rw0.custody_binding.owner_relation`                           | none                 | phase, transient WorkSpec or selected-artifact owner row                                                                                                                                                          | 1 |
| 4                                                  | `relation_recomputable`               | `rw0.retrieval_event_sequence.owner_relation`                  | none                 | phase, custody, authority, proposal, ordered prior events, attempt/current fences                                                                                                                                 | 1 |
| 5                                                  | `value_reconstructed`                 | none                                                           | none                 | none                                                                                                                                                                                                              | 0 |
| 6                                                  | `relation_recomputable`               | `rw0.host_qualification.owner_relation`                        | none                 | phase, authority, readiness, current effect fence                                                                                                                                                                 | 1 |
| 7                                                  | `value_reconstructed`                 | none                                                           | none                 | none                                                                                                                                                                                                              | 0 |
| 8                                                  | `relation_recomputable`               | `rw0.capability_observation.declaration_binding`               | NWPF                 | declaration member                                                                                                                                                                                                | 1 |
| 9                                                  | `relation_recomputable`               | `rw0.worker_mechanism_capability_qualification.owner_relation` | NWPF                 | phase, declaration, observation, authority, readiness, host qualification, current effect fence                                                                                                                   | 1 |
| 10                                                 | `relation_attested_at_admission`      | `rw0.wire.exact_current_cancellation_request`                  | cancellation-control | command, attempt/author/target/cancellation fences, target/cancellation deliveries, optional transient manifest                                                                                                   | 1 |
| 11                                                 | `relation_attested_at_admission`      | `rw0.wire.exact_current_process_observation`                   | cancellation-control | command, attempt/author/target fences, target delivery, optional transient manifest                                                                                                                               | 1 |
| 12                                                 | `relation_attested_at_admission`      | `c2a.worker_observation.owner_relation`                        | none                 | delivery, command, attempt/author/current fences, optional manifest/blob sets/cancellation target                                                                                                                 | 1 |
| 12 response                                        | same, plus attested response relation | `rw0.wire.exact_current_cancellation_response`                 | cancellation-control | exact rank-10 request and the exact cancellation graph                                                                                                                                                            | 2 |
| 13                                                 | `derived_wrapper_recomputable`        | `rw0.wire.worker_result.owner_relation`                        | NWPF                 | started, optional captured, completed, command, delivery, attempt fence, author fence                                                                                                                             | 1 |
| 14                                                 | `derived_wrapper_recomputable`        | `rw0.wire.process_result_classifier.owner_relation`            | NWPF                 | command, delivery, attempt/author fences, optional result or failure, four ordered adapter roles, optional request, two ordered process roles, optional cancellation fence/delivery                               | 1 |
| 15                                                 | `existing_owner_row_reconstructed`    | `rw0.section41.post_execution_proposal_family.owner_relation`  | none                 | source invocation, artifact, proposal, then zero or nine ordered evidence rows                                                                                                                                    | 1 |

Exact profiles:
```
rw0-wire-nwpf-v1
470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454

rw0-wire-cancellation-control-v1
4d6f84552b852a4c4073b4238591afd271072f648424eca9e744def436165288
```

Zero relations are legal only for ranks 5 and 7. Rank 12 has one or two; every other member has exactly one. Relation-set ordering is `(relation_rank, relation_ref)`. The maximum relation count is two.

Relation-set digest domain:
```
governed-execution.nwp-rw0-c1-relation-set.v1.identity
```

Its identity fields are:
```
schema_id
phase_basis_ref
subject_kind
subject_ref
relations[
  relation_rank
  relation_ref
  relation_digest
]
```

Duplicate relation rank, ID, ref, or digest is rejected. A missing prerequisite causes `missing_prerequisite_member` before relation evaluation and writes nothing.

No relation stores a truth Boolean. It stores the relation identity/version, proof mode, optional profile pair, exact ordered operand closure, evaluation time, and digests.

# Exact kind ranks and scope

| RankKindSemantic scope |                                            |                                                                               |
| ---------------------- | ------------------------------------------ | ----------------------------------------------------------------------------- |
| 1                      | authority verification observation         | intrinsically phase-bound                                                     |
| 2                      | subordinate authorization proposal         | intrinsically phase-bound                                                     |
| 3                      | custody availability observation           | intrinsically phase-bound                                                     |
| 4                      | retrieval capability event observation     | intrinsically phase-bound                                                     |
| 5                      | remote-host readiness observation          | globally reusable                                                             |
| 6                      | effect-host qualification                  | intrinsically phase-bound                                                     |
| 7                      | Capability declaration                     | globally reusable                                                             |
| 8                      | Capability observation                     | globally reusable, but each membership requires the declaration in that phase |
| 9                      | Capability qualification                   | intrinsically phase-bound                                                     |
| 10                     | Wire cancellation request                  | K8-bound                                                                      |
| 11                     | Wire process observation                   | K8-bound                                                                      |
| 12                     | C2A WorkerObservation                      | K8-bound                                                                      |
| 13                     | Wire worker-result binding                 | K8-bound                                                                      |
| 14                     | Wire process-result classification binding | K8-bound                                                                      |
| 15                     | Section 41 wrapper                         | existing-owner-row-bound                                                      |

The global registry has unique `value_ref` and unique `value_digest`. The same exact reusable value may therefore preexist and gain a new phase membership; no second payload row is written. A ref/digest alias or cross-kind reuse is a semantic collision.

Membership uniqueness is `(phase_basis_ref, value_ref)`. K8-bound and phase-bound values must have the exact registry phase pair; globally reusable values have a null registry phase pair.

# C1-owned value grammars

All C1 identities use:
```
SHA256(domain UTF-8 || 0x00 || canonical JSON UTF-8)
```

Canonical JSON is closed-world, exact built-in values only, sorted object keys, compact separators, `ensure_ascii=false`, `allow_nan=false`, no Unicode normalization, no BOM, and no trailing newline.

Every schema below uses `schema_id + ".identity"` as its digest domain unless a separate domain is named. Each self-digest excludes only itself.

C1-owned schemas:
```
governed-execution.nwp-rw0-c1-phase-instance-row.v1
governed-execution.nwp-rw0-c1-evidence-value-row.v1
governed-execution.nwp-rw0-c1-evidence-membership-row.v1
governed-execution.nwp-rw0-c1-relation-binding-row.v1
governed-execution.nwp-rw0-c1-relation-operand-row.v1
governed-execution.nwp-rw0-c1-mutation-receipt.v1
governed-execution.nwp-rw0-c1-establish-phase-command.v1
governed-execution.nwp-rw0-c1-admit-evidence-command.v1
governed-execution.nwp-rw0-c1-establish-phase-result.v1
governed-execution.nwp-rw0-c1-admit-evidence-result.v1
governed-execution.nwp-rw0-c1-recovery-result.v1
governed-execution.nwp-rw0-c1-wire-worker-result-binding.v1
governed-execution.nwp-rw0-c1-wire-process-result-classification-binding.v1
governed-execution.nwp-rw0-c1-section41-post-execution-proposal-family-member.v1
governed-execution.nwp-rw0-c1-member-locator.v1
governed-execution.nwp-rw0-c1-owner-row-locator.v1
governed-execution.nwp-rw0-c1-transient-operand.v1
```

Additional digest domains:
```
governed-execution.nwp-rw0-c1-k8.v1.identity
governed-execution.nwp-rw0-c1-relation-reference.v1.identity
governed-execution.nwp-rw0-c1-relation-set.v1.identity
governed-execution.nwp-rw0-c1-relation-operand-set.v1.identity
governed-execution.nwp-rw0-c1-phase-graph.v1.identity
governed-execution.nwp-rw0-c1-evidence-admission-graph.v1.identity
```

Command field order:
```
EstablishPhaseCommand:
schema_id
mutation_ref
phase_basis
work_spec
expected_program_head_revision
expected_program_head_digest
expected_work_item_head_revision
expected_work_item_head_digest
command_digest

AdmitEvidenceCommand:
schema_id
mutation_ref
phase_basis_ref
phase_basis_digest
expected_program_head_revision
expected_program_head_digest
expected_work_item_head_revision
expected_work_item_head_digest
preassigned_membership_ref
kind_rank
evidence_value
prerequisite_member_locators
owner_row_locators
transient_operands
command_digest
```

Member locators are ordered exact tuples:
```
role
kind_rank
membership_ref
membership_digest
value_ref
value_digest
```

Owner-row locators are:
```
role
table_name
row_ref
row_digest
```

Transient operands are:
```
role
schema_id
semantic_ref
semantic_digest
availability = admission_only
```

The command digest binds all transient semantic digests. WorkSpec and manifest identities bind their complete canonical mappings. Raw before/after blob dictionaries are admitted only through named three-entry blob-set projections containing exact path, SHA-256, and byte length; the live bytes must match that projection before owner validation and are cleared before writes.

Bounds are:

- member locators: `0..8`
- owner locators: `0..8`
- transient operands: `0..3`
- total relation operands: at most 16

Result field order:
```
EstablishPhaseResult:
schema_id, mutation_ref, command_digest, disposition,
phase_basis_ref, phase_basis_digest, k8_digest,
phase_graph_digest, receipt_digest, committed_at, result_digest

AdmitEvidenceResult:
schema_id, mutation_ref, command_digest, disposition,
phase_basis_ref, phase_basis_digest,
membership_ref, membership_digest,
value_ref, value_digest, kind_rank,
relation_set_digest, admission_graph_digest,
receipt_digest, committed_at, result_digest
```

`disposition` is exactly `fresh_committed` or `exact_replay`.

Receipt field order:
```
schema_id
mutation_ref
mutation_family
command_schema_id
command_digest
phase_basis_ref
phase_basis_digest
membership_ref
membership_digest
value_ref
value_digest
kind_rank
result_class
result_projection_digest
operation_graph_digest
outcome
committed_at
receipt_digest
```

`mutation_family` is `establish_rw0_phase` or `admit_rw0_evidence`; `result_class` is `rw0_phase_established` or `rw0_evidence_admitted`; `outcome` is only `committed`. Membership/value/kind are all null for phase establishment and all non-null for admission.

Recovery field order:
```
schema_id
mutation_family
mutation_ref
command_digest
disposition
receipt_digest
result_projection_digest
operation_graph_digest
recovery_digest
```

Disposition is:
```
committed_exact
definitely_not_committed
unresolved
```

The three digest fields are all present only for `committed_exact`.

Private values are final, slotted, immutable, non-subclassable, non-pickleable, and reject `copy`/`deepcopy`. `repr` and errors contain no refs, digests, paths, blobs, SQL, or supplied data. Only results, conflicts, and recovery dispositions have safe outward projections. There is no public export.

# Error and disposition algebra

Existing types reused:

- `WriterSessionError` for `writer_session_closed`, `writer_session_process_mismatch`, `writer_session_close_during_operation`, and `writer_session_mutation_in_progress`.
- `SQLiteMutationStoreError` for `database_integrity_failure`, `mutation_failed`, and `commit_outcome_unknown`.

New private types:
```
_RW0C1PreflightError:
  rw0_c1_invalid_command
  rw0_c1_invalid_value

RW0C1ConflictReasonV1:
  stale_writer
  mutation_ref_reuse
  phase_identity_collision
  k8_collision
  current_state_conflict
  member_identity_collision
  member_already_admitted
  missing_prerequisite_member
  relation_failure
  relation_identity_collision
  owner_row_missing
```

Classification:

- Invalid command/value before transaction: private preflight error.
- Owner relation rejects supplied evidence: `relation_failure`, rollback, no rows.
- Stale writer: `stale_writer`, with no receipt/key disclosure.
- Existing mutation ref plus different digest: `mutation_ref_reuse`.
- Same phase ref/digest axis with incompatible identity: `phase_identity_collision`.
- Competing phase for the K8: `k8_collision`.
- Program/work head mismatch: `current_state_conflict`.
- Global ref/digest/schema/kind alias: `member_identity_collision`.
- Exact value already a member of the phase under another mutation: `member_already_admitted`.
- Missing exact dependency: `missing_prerequisite_member`.
- Derived relation ref/digest alias: `relation_identity_collision`.
- Required owner row absent: `owner_row_missing`.
- Duplicate, malformed, digest-divergent, or impossible owner/database rows: `database_integrity_failure`.
- Operational SQLite/cleanup failure before commit: `mutation_failed`.
- Any exception after COMMIT begins: `commit_outcome_unknown`.

Errors remain content-free.

# Exact migration 0004 schema

Migration definition:
```
migration_id: 0004_rw0_phase_and_evidence_state
sequence: 4
resource: 0004_rw0_phase_and_evidence_state.sql
min_app_schema: 2
max_app_schema: 2
destructive: false
seed_rows: none
```

The literal checksum is the mechanical SHA-256 of the final immutable UTF-8/LF SQL resource and must be pinned in `_PACKAGED_MIGRATION_SPECS`; it is not an implementation-choice field.

Migration 0004 adds exactly 23 STRICT tables:
```
rw0_phase_instances
rw0_evidence_values
rw0_evidence_memberships
rw0_relation_bindings
rw0_relation_operands
rw0_c1_mutation_receipts
rw0_authority_verification_observations
rw0_subordinate_authorization_proposals
rw0_custody_availability_observations
rw0_retrieval_capability_event_observations
rw0_remote_host_readiness_observations
rw0_effect_host_qualifications
rw0_worker_mechanism_capability_declarations
rw0_worker_mechanism_capability_observations
rw0_worker_mechanism_capability_qualifications
rw0_wire_cancellation_request_observations
rw0_wire_process_observations
rw0_c2a_worker_observations
rw0_wire_worker_result_bindings
rw0_wire_process_result_classification_bindings
rw0_section41_post_execution_proposal_family_members
rw0_authority_observation_effect_classes
rw0_c2a_worker_observation_evidence_refs
```

Every column is declared `ANY`.

Normative SQL-check notation used below:

- `S(literal)`: non-null exact text literal.
- `R`: non-null ASCII safe ref, 1–96 bytes, first byte alphanumeric, remaining bytes `[0-9A-Za-z.-]`, forbidden case-insensitive prefixes `connector-`, `tunnel-`, `workspace-`, `org-`, `organization-`, `user-`, and not IPv4-shaped.
- `H`: non-null 64-byte lowercase hex.
- `O40`: non-null 40-byte lowercase hex.
- `T`: non-null exact valid `YYYY-MM-DDTHH:MM:SSZ`.
- `U`: exact integer, not Boolean, `0..9223372036854775807`.
- `P`: exact integer, `1..9223372036854775807`.
- `B`: exact integer `0|1`.
- `E{...}`: exact text member of the listed finite set.
- `Q`: 1–96 ASCII bytes `[a-z][a-z0-9_.-]*`.
- A `?` suffix means either SQL NULL or the exact non-null grammar.
- `PAIR(R,H)` means both null or both non-null.
- All foreign keys use `ON UPDATE RESTRICT ON DELETE RESTRICT`.

These predicates are expanded literally in SQL; they are not runtime-only aliases.

Four explicit indexes are added, with no predicates:
```
CREATE UNIQUE INDEX uq_rw0_phase_instances_k8
ON rw0_phase_instances(
  program_ref, semantic_attempt_ref, candidate_ref, effect_intent_ref,
  author_command_ref, attempt_fence_ref, effect_fence_ref,
  delivery_attempt_ref
);

CREATE INDEX idx_rw0_evidence_memberships_phase_page
ON rw0_evidence_memberships(phase_basis_ref, kind_rank, value_ref);

CREATE UNIQUE INDEX uq_rw0_retrieval_events_phase_correlation_sequence
ON rw0_retrieval_capability_event_observations(
  phase_basis_ref, safe_correlation_ref, sequence_number
);

CREATE INDEX idx_rw0_c1_mutation_receipts_phase_family
ON rw0_c1_mutation_receipts(
  phase_basis_ref, mutation_family, mutation_ref
);
```

Each of the 23 tables has exactly:
```
<table>_no_update
<table>_no_delete
```

Each is a `BEFORE UPDATE` or `BEFORE DELETE` trigger that unconditionally raises `SQLITE_CONSTRAINT_TRIGGER`. There are 46 new triggers. No table is mutable.

The source SQL baseline is 39 user tables, 64 triggers, and one explicit index. Therefore the exact cumulative generation-2 tip is:
```
62 user tables
110 triggers
5 explicit indexes
```

The earlier 39/62/2 counts appearing in superseded planning passages are not the current source truth.

SQL alone enforces “at most one” typed payload per registry identity through shared primary keys and composite FKs. Transaction construction, receipt-last publication, and guarded readback enforce “exactly one” in every committed family. An orphan registry row, missing typed row, missing child row, non-dense ordinal set, or count/digest mismatch is database corruption.

# Exact phase and typed table schemas

## Core table columns

`rw0_phase_instances`, in order:
```
row_schema_id:S(governed-execution.nwp-rw0-c1-phase-instance-row.v1)
phase_basis_schema_id:S(governed-execution.nwp-rw0-phase-entry-basis.v1)
phase_basis_ref:R
program_ref:R
program_version_ref:R
program_version_number:P
accepted_intent_revision_ref:R
work_item_ref:R
work_item_revision_ref:R
semantic_attempt_ref:R
semantic_attempt_digest:H
attempt_number:P
candidate_ref:R
basis_decision_ref:R
basis_decision_digest:H
work_spec_ref:R
work_spec_digest:H
work_spec_safe_projection_digest:H
effect_intent_ref:R
effect_intent_digest:H
author_command_ref:R
author_command_digest:H
standing_grant_ref:R
standing_grant_digest:H
attempt_authorization_ref:R
attempt_authorization_digest:H
effect_authorization_ref:R
effect_authorization_digest:H
attempt_fence_ref:R
attempt_fence_digest:H
effect_fence_ref:R
effect_fence_digest:H
delivery_attempt_ref:R
delivery_envelope_digest:H
delivery_attempt_digest:H
authority_evaluation_ref:R
authority_evaluation_digest:H
selected_proposal_ref:R
selected_proposal_digest:H
selected_artifact_ref:R
selected_artifact_digest:H
selected_artifact_binding_digest:H
selected_plan_safe_projection_digest:H
disposition_ref:R
disposition_digest:H
disposition:E{selected_for_dispatch_gates}
selection_head_revision:U
selection_head_digest:H
current_effect_head_revision:U
current_effect_head_state:E{ready_for_delivery,delivery_pending,delivery_outcome_unknown,observed,cancellation_effect_established,terminal}
current_effect_head_digest:H
current_delivery_head_revision:U
current_delivery_head_state:E{planned,submitted,outcome_unknown,acknowledged,rejected,completed}
current_delivery_head_digest:H
global_stop_ref:R
global_stop_version:U
global_stop_state:E{clear,active}
path_scope_digest:H
phase_basis_digest:H
k8_digest:H
expected_program_head_revision:U
expected_program_head_digest:H
expected_work_item_head_revision:U
expected_work_item_head_digest:H
establishment_mutation_ref:R
established_at:T
relation_count:U CHECK relation_count=1
relation_set_digest:H
phase_graph_digest:H
phase_row_digest:H
```

The nested `c2b3d_lineage` reconstructs from the 34 fields beginning at `program_ref`; `selection_key` reconstructs in K8 order:
```
program_ref
semantic_attempt_ref
candidate_ref
effect_intent_ref
author_command_ref
attempt_fence_ref
effect_fence_ref
delivery_attempt_ref
```

Primary key: `phase_basis_ref`. Unique: `phase_basis_digest`, `k8_digest`, `establishment_mutation_ref`, and the explicit K8 index.

Immutable owner rows receive restrictive FKs. Mutable selection/program/work/effect/delivery heads and `global_stop_current` are copied immutable observations and intentionally receive no digest FK that could reinterpret the historical phase after a head update.

`rw0_evidence_values`:
```
row_schema_id
value_schema_id
value_ref
value_digest
kind_rank
scope_class
intrinsic_phase_basis_ref?
intrinsic_phase_basis_digest?
created_by_mutation_ref
registered_at
registry_row_digest
```

`scope_class` is `globally_reusable`, `intrinsic_phase`, `k8_bound`, or `existing_owner_row_bound`. The phase pair is null only for ranks 5, 7, and 8. PK `value_ref`; unique `value_digest`; unique `(value_ref,value_digest,kind_rank,value_schema_id)`.

`rw0_evidence_memberships`:
```
row_schema_id
membership_ref
phase_basis_ref
phase_basis_digest
value_schema_id
value_ref
value_digest
kind_rank
relation_count
relation_set_digest
admitted_by_mutation_ref
admitted_at
admission_graph_digest
membership_digest
```

PK `membership_ref`; unique `(phase_basis_ref,value_ref)`; unique `(phase_basis_ref,membership_ref,membership_digest)`; relation count is `0`, `1`, or `2` according to rank.

`rw0_relation_bindings`:
```
row_schema_id
relation_ref
relation_digest
phase_basis_ref
phase_basis_digest
subject_kind
subject_ref
subject_digest
relation_rank
relation_id
relation_version
proof_mode
profile_ref?
profile_digest?
operand_count
operand_set_digest
evaluated_at
relation_row_digest
```

`subject_kind` is `phase_establishment` or `evidence_membership`. `relation_version=1`; `relation_rank=0|1`; `operand_count=0..16`; the profile pair obeys pair algebra. PK `relation_ref`; unique `relation_digest`; unique `(phase_basis_ref,subject_kind,subject_ref,relation_rank)`.

Relation refs are internally derived from:
```
phase_basis_ref, subject_kind, subject_ref, relation_rank
```

under `governed-execution.nwp-rw0-c1-relation-reference.v1.identity`; callers do not supply relation requests.

`rw0_relation_operands`:
```
row_schema_id
relation_ref
relation_digest
operand_ordinal
operand_role
source_kind
operand_schema_id
operand_ref
operand_digest
source_membership_ref?
source_membership_digest?
owner_table?
recomputable
operand_row_digest
```

`source_kind` is `phase_value`, `same_phase_member`, `existing_owner_row`, `transient_private_value`, or `subject_embedded_value`. Its nullable columns follow an exact branch CHECK. PK `(relation_ref,operand_ordinal)`. Ordinals must be dense `0..operand_count-1`; density is verified before commit and on every readback.

`rw0_c1_mutation_receipts` use the receipt grammar above. PK `mutation_ref`; unique `receipt_digest`. The family branch CHECK controls membership/value/kind nullability. Receipt is written last.

## Typed projection convention

Every typed table starts with:
```
projection_schema_id
value_schema_id
value_ref
value_digest
kind_rank
```

and ends with `projection_row_digest`.

`value_ref` is the owner’s semantic ref and `value_digest` its owner digest; those named fields are not redundantly repeated. Each table has PK `value_ref`, unique `value_digest`, and composite FK `(value_ref,value_digest,kind_rank,value_schema_id)` to `rw0_evidence_values`.

## Typed tables

1. `rw0_authority_verification_observations`

Owner schema: `governed-execution.nwp-rw0-authority-verification-observation.v1`.

Middle columns, in owner order:
```
source_ref, evidence_ref, evidence_digest,
phase_basis_ref, phase_basis_digest,
parent_grant_ref, parent_grant_digest,
grant_family_ref, grant_family_digest,
attempt_basis_ref, attempt_basis_digest,
effect_basis_ref, effect_basis_digest,
attempt_fence_ref, attempt_fence_digest,
effect_fence_ref, effect_fence_digest,
audience_ref, repository_ref, base_git_object_format, base_git_oid,
path_scope_digest, allowed_effect_class_count,
max_active_invocations, max_candidate_bytes, max_changed_files,
max_cost_microusd, max_cpu_seconds, max_deliveries, max_deployments,
max_local_commits, max_memory_bytes, max_merges,
max_model_input_tokens, max_model_output_tokens, max_pull_requests,
max_pushes, max_wall_seconds,
effect_class, status, family_status, revocation_status,
grant_expires_at, observed_at, observation_expires_at,
current_effect_head_digest, current_delivery_head_digest,
global_stop_ref, global_stop_version, global_stop_state
```

Effect class is one of `author_candidate`, `cancel_effect`, `review_candidate`, `validate_candidate`; status is `verified|denied|unknown`; family is `compatible|incompatible|unknown`; revocation is `unrevoked|revoked|unknown`. Base format is `sha1`, OID is `O40`. The child count is `1..4`.

2. `rw0_subordinate_authorization_proposals`
```
phase_basis_ref, phase_basis_digest,
verification_ref, verification_digest,
parent_grant_ref, parent_grant_digest,
grant_family_ref, grant_family_digest,
attempt_basis_ref, attempt_basis_digest,
effect_basis_ref, effect_basis_digest,
attempt_fence_ref, attempt_fence_digest,
effect_fence_ref, effect_fence_digest,
audience_ref, repository_ref, base_git_object_format, base_git_oid,
path_scope_digest, effect_class,
[the same fifteen ordered ceiling columns],
expires_at, global_stop_ref, global_stop_version
```

3. `rw0_custody_availability_observations`
```
source_ref, evidence_ref, evidence_digest,
phase_basis_ref, phase_basis_digest,
subject_kind, subject_ref, subject_semantic_digest,
content_sha256, byte_length, availability, observed_at, expires_at
```

Subject is `work_spec|selected_plan`; availability is `available|unavailable|unknown`.

4. `rw0_retrieval_capability_event_observations`
```
source_ref, evidence_ref, evidence_digest,
phase_basis_ref, phase_basis_digest, safe_correlation_ref,
subject_kind, subject_ref, subject_semantic_digest,
content_sha256, byte_length, semantic_attempt_ref,
attempt_fence_ref, attempt_fence_digest,
effect_intent_ref, effect_fence_ref, effect_fence_digest,
audience_ref, repository_ref, base_git_object_format, base_git_oid,
path_scope_digest,
authority_observation_ref, authority_observation_digest,
subordinate_proposal_ref, subordinate_proposal_digest,
custody_observation_ref, custody_observation_digest,
event_kind, predecessor_event_ref?, predecessor_event_digest?,
sequence_number, occurred_at, expires_at
```

Event kind is `issued|redeemed|consumed|expired|revoked|failed|unknown`. Sequence zero requires a null predecessor pair; sequence one or two requires a non-null pair.

5. `rw0_remote_host_readiness_observations`
```
source_ref, evidence_ref, evidence_digest, safe_host_correlation_ref,
status, platform,
platform_profile_ref, platform_profile_digest,
architecture_profile_ref, architecture_profile_digest,
worker_artifact_ref, worker_artifact_digest,
worker_protocol_ref, worker_protocol_digest,
execution_identity_profile_ref, execution_identity_profile_digest,
process_profile_ref, process_profile_digest,
isolation_profile_ref, isolation_profile_digest,
resource_profile_ref, resource_profile_digest,
cancellation_profile_ref, cancellation_profile_digest,
credential_handoff_profile_ref, credential_handoff_profile_digest,
capsule_store_profile_ref, capsule_store_profile_digest,
validation_tool_profile_ref, validation_tool_profile_digest,
review_tool_profile_ref, review_tool_profile_digest,
cleanup_profile_ref, cleanup_profile_digest,
observed_at, expires_at
```

Status is `ready|unready|unknown`; platform is exactly `linux`.

6. `rw0_effect_host_qualifications`
```
phase_basis_ref, phase_basis_digest,
effect_intent_ref, effect_fence_ref, effect_fence_digest,
verification_ref, verification_digest,
readiness_ref, readiness_digest,
required_scenario_profile_ref, required_scenario_profile_digest,
required_platform_profile_ref, required_platform_profile_digest,
required_architecture_profile_ref, required_architecture_profile_digest,
required_worker_artifact_ref, required_worker_artifact_digest,
required_worker_protocol_ref, required_worker_protocol_digest,
required_execution_identity_profile_ref, required_execution_identity_profile_digest,
required_process_profile_ref, required_process_profile_digest,
required_isolation_profile_ref, required_isolation_profile_digest,
required_resource_profile_ref, required_resource_profile_digest,
required_cancellation_profile_ref, required_cancellation_profile_digest,
required_credential_handoff_profile_ref, required_credential_handoff_profile_digest,
required_capsule_store_profile_ref, required_capsule_store_profile_digest,
required_validation_tool_profile_ref, required_validation_tool_profile_digest,
required_review_tool_profile_ref, required_review_tool_profile_digest,
required_cleanup_profile_ref, required_cleanup_profile_digest,
result, reason, evaluated_at
```

Result is `qualified|blocked|unknown`; reasons are exactly:
```
qualified
readiness_unready
readiness_unknown
readiness_expired
authority_not_verified
authority_denied_or_revoked
authority_expired
phase_or_effect_mismatch
worker_artifact_mismatch
worker_protocol_mismatch
platform_or_architecture_mismatch
profile_mismatch
global_stop_active
unknown
```

7. `rw0_worker_mechanism_capability_declarations`
```
declaration_source_kind, declaration_source_ref,
worker_artifact_ref, worker_artifact_digest,
wire_profile_ref, wire_profile_digest,
noninteractive_operation,
wire_command_input_only,
wire_result_output_only,
protocol_stdout_only,
private_bounded_diagnostic_stderr,
external_cancellation_control_supported,
external_deadline_control_supported,
invocation_bound_logical_context,
private_history_non_authority,
isolated_credential_use,
private_interaction_material,
zero_git_effects,
restricted_network_access,
external_session_non_authority
```

Source kind is `worker_artifact_owner`; every dimension is `supported|unsupported|unknown`.

8. `rw0_worker_mechanism_capability_observations`
```
observation_source_kind, observation_source_ref,
observation_source_invocation_ref,
evidence_ref, evidence_digest,
capability_declaration_ref, capability_declaration_digest,
worker_artifact_ref, worker_artifact_digest,
wire_profile_ref, wire_profile_digest,
[the same fourteen dimensions],
observed_at, expires_at
```

Source kind is `independent_worker_mechanism_observer`; dimensions are `confirmed|contradicted|unknown`.

9. `rw0_worker_mechanism_capability_qualifications`
```
capability_declaration_ref, capability_declaration_digest,
capability_observation_ref, capability_observation_digest,
worker_artifact_ref, worker_artifact_digest,
wire_profile_ref, wire_profile_digest,
phase_basis_ref, phase_basis_digest,
authority_observation_ref, authority_observation_digest,
readiness_observation_ref, readiness_observation_digest,
host_qualification_ref, host_qualification_digest,
effect_intent_ref, effect_fence_ref, effect_fence_digest,
result, reason, evaluated_at
```

Results are `qualified|blocked|unknown`. Reasons are:
```
qualified
b1_host_qualification_unknown
capability_unknown
b1_binding_mismatch
b1_host_qualification_blocked
declaration_observation_mismatch
self_observation
observation_expired
worker_artifact_mismatch
wire_profile_mismatch
declaration_unsupported
observation_nonconformant
```

10. `rw0_wire_cancellation_request_observations`
```
source_kind, source_ref, source_invocation_ref,
evidence_ref, evidence_digest,
program_ref, program_version_ref, accepted_intent_revision_ref,
work_item_ref, work_item_revision_ref, semantic_attempt_ref, candidate_ref,
command_ref, command_digest,
attempt_fence_ref, attempt_fence_digest,
cancellation_effect_intent_ref,
cancellation_effect_fence_ref, cancellation_effect_fence_digest,
cancellation_delivery_attempt_ref, cancellation_delivery_envelope_digest,
target_effect_intent_ref, target_effect_fence_ref, target_effect_fence_digest,
target_delivery_attempt_ref, target_delivery_envelope_digest,
observed_at
```

Source kind is `supervisor|execution_substrate`.

11. `rw0_wire_process_observations`
```
source_kind, source_ref, source_invocation_ref,
evidence_ref, evidence_digest, event_kind,
program_ref, program_version_ref, accepted_intent_revision_ref,
work_item_ref, work_item_revision_ref, semantic_attempt_ref, candidate_ref,
command_ref, command_digest, attempt_fence_ref, attempt_fence_digest,
effect_intent_ref, effect_fence_ref, effect_fence_digest,
delivery_attempt_ref, delivery_envelope_digest, observed_at
```

Source is `supervisor|operating_system`; event is `resource_limit_exceeded|signal_delivered`.

12. `rw0_c2a_worker_observations`
```
source_kind, source_ref, source_invocation_ref, delivery_attempt_ref,
program_ref, program_version_ref, accepted_intent_revision_ref,
work_item_ref, work_item_revision_ref, semantic_attempt_ref,
effect_intent_ref, command_ref, command_digest,
attempt_fence_ref, attempt_fence_digest,
effect_fence_ref, effect_fence_digest,
observation_kind, outcome, reason_code,
evidence_ref_count, observed_at,
candidate_ref?, capsule_manifest_ref?, portable_capsule_digest?,
process_exit_code?
```

The owner’s exact kind/source/outcome matrix is retained. Conditional fields are:

- `candidate_captured` and `capsule_seal_failed`: candidate only.
- Capsule observations: candidate, manifest ref, portable digest.
- `process_exited`: exit code `-255..255`.
- All others: none.

Evidence ref count is `0..32`.

13. `rw0_wire_worker_result_bindings`
```
phase_basis_ref, phase_basis_digest,
wire_profile_ref, wire_profile_digest,
effect_intent_ref, effect_fence_ref, effect_fence_digest,
delivery_attempt_ref, delivery_envelope_digest,
observation_count,
worker_started_membership_ref, worker_started_membership_digest,
candidate_captured_membership_ref?, candidate_captured_membership_digest?,
worker_completed_membership_ref, worker_completed_membership_digest
```

Count is two iff the captured pair is null and three iff it is non-null.

14. `rw0_wire_process_result_classification_bindings`
```
phase_basis_ref, phase_basis_digest,
wire_profile_ref, wire_profile_digest,
cancellation_control_profile_ref, cancellation_control_profile_digest,
target_effect_class,
target_effect_intent_ref, target_effect_fence_ref, target_effect_fence_digest,
target_delivery_attempt_ref, target_delivery_envelope_digest,
cancellation_effect_intent_ref?, cancellation_effect_fence_ref?,
cancellation_effect_fence_digest?, cancellation_delivery_attempt_ref?,
cancellation_delivery_envelope_digest?,
result_state,
result_membership_ref?, result_membership_digest?,
result_failure_reason?,
request_membership_ref?, request_membership_digest?,
cancellation_ack_membership_ref?, cancellation_ack_membership_digest?,
cancellation_reject_membership_ref?, cancellation_reject_membership_digest?,
deadline_elapsed_membership_ref?, deadline_elapsed_membership_digest?,
process_exited_membership_ref?, process_exited_membership_digest?,
resource_limit_membership_ref?, resource_limit_membership_digest?,
signal_delivered_membership_ref?, signal_delivered_membership_digest?,
process_classification, process_reason,
capsule_present,
capsule_schema_id?,
capsule_canonicalization_profile?,
capsule_digest_domain?,
capsule_candidate_ref?,
capsule_manifest_ref?,
capsule_program_ref?,
capsule_program_version_ref?,
capsule_accepted_intent_revision_ref?,
capsule_work_item_ref?,
capsule_work_item_revision_ref?,
capsule_semantic_attempt_ref?,
capsule_effect_intent_ref?,
capsule_command_ref?,
capsule_command_digest?,
capsule_attempt_fence_ref?,
capsule_attempt_fence_digest?,
capsule_effect_fence_ref?,
capsule_effect_fence_digest?,
capsule_repository_ref?,
capsule_base_git_object_format?,
capsule_base_git_oid?,
capsule_authorized_path_scope_digest?,
entry_0_path?, entry_0_operation?, entry_0_mode?,
entry_0_before_blob_sha256?, entry_0_before_byte_length?,
entry_0_after_blob_sha256?, entry_0_after_byte_length?,
entry_1_path?, entry_1_operation?, entry_1_mode?,
entry_1_before_blob_sha256?, entry_1_before_byte_length?,
entry_1_after_blob_sha256?, entry_1_after_byte_length?,
entry_2_path?, entry_2_operation?, entry_2_mode?,
entry_2_before_blob_sha256?, entry_2_before_byte_length?,
entry_2_after_blob_sha256?, entry_2_after_byte_length?,
capsule_portable_capsule_digest?
```

`result_state` is `present|decode_failed|absent` and controls its pair/error fields. The classification/reason matrix is the owner NWPF matrix:

- `usable`: `usable`
- `invalid`: `invalid_input`, `unrelated_fact`, `duplicate_fact`, `conflicting_fact`, `cancellation_graph_mismatch`
- `unusable`: all other owner reasons

The manifest group is wholly null when `capsule_present=0`; it is wholly present and reconstructs the exact three-entry `CandidateCapsuleManifestV1` when `capsule_present=1`. It must be absent for `author_candidate` and present for `validate_candidate|review_candidate`.

The cancellation-control classification is deliberately absent.

15. `rw0_section41_post_execution_proposal_family_members`
```
phase_basis_ref, phase_basis_digest,
source_invocation_ref, source_invocation_digest,
artifact_ref, artifact_digest, artifact_binding_digest,
proposal_ref, proposal_digest,
model_contract_ref, model_contract_digest,
model_configuration_ref, model_configuration_digest,
context_schema_id, context_ref, context_digest,
safe_projection_schema_id, safe_projection_digest,
evidence_set_ref, evidence_set_digest,
evidence_binding_count,
recommendation, reason_code, proposal_created_at,
owner_family_graph_digest
```

The phase is fixed to `post_execution_semantic_review`. Evidence count is `0|9`. Recommendations are `accept_candidate|repair_candidate|replan|terminal_reject|block`.

The nine-row order is:
```
candidate_capsule                    rank 5  ordinal 0 required 1
worker_result                        rank 6  ordinal 0 required 1
validation_result                    rank 7  ordinal 0 required 1
independent_review                   rank 8  ordinal 0 required 1
standing_policy                      rank 9  ordinal 0 required 1
risk_lane                            rank 10 ordinal 0 required 1
authority_currentness_attestation    rank 11 ordinal 0 required 1
global_stop                          rank 12 ordinal 0 required 1
effect_ceiling                       rank 13 ordinal 0 required 1
```

Child tables:
```
rw0_authority_observation_effect_classes:
row_schema_id, value_ref, value_digest, ordinal, effect_class, child_row_digest
ordinal 0..3; PK(value_ref,ordinal); UNIQUE(value_ref,effect_class)

rw0_c2a_worker_observation_evidence_refs:
row_schema_id, value_ref, value_digest, ordinal, evidence_ref, child_row_digest
ordinal 0..31; PK(value_ref,ordinal); UNIQUE(value_ref,evidence_ref)
```

Both have restrictive composite FKs to their typed parent.

The tables cannot be combined without losing a required property:

- registry: cross-kind collision detection and reusable identity;
- membership: phase-local presence without payload duplication;
- relation/operands: versioned proof plus bounded variable arity;
- receipt: receipt-first replay and exact uncertainty recovery;
- typed projections: closed schemas without JSON/BLOB payloads;
- child tables: exact bounded ordered arrays;
- phase table: immutable K8 and CAS snapshot independent of membership;
- wrappers: identities for owner tuple/classification/family values that otherwise have no durable semantic identity.

# Transaction, replay, and recovery closure

Both mutations use the existing operation guard, mutation slot, bound database, `BEGIN IMMEDIATE`, post-begin binding validation, managed-schema validation, writer fencing, one nominal capability epoch, one commit attempt, and existing cleanup precedence.

Fresh operation order:

1. Command-local exact-type preflight.
2. Operation lease and mutation slot.
3. Bound connection and `BEGIN IMMEDIATE`.
4. Binding/schema validation.
5. Writer fence.
6. Receipt lookup by mutation ref.
7. Exact phase lookup or phase collision probes.
8. Program/work CAS reads.
9. Same-phase prerequisites in frozen operand order.
10. Existing owner rows in frozen operand order.
11. Transient operand validation.
12. Value/member/relation collision probes.
13. Capture one whole-second UTC transaction timestamp.
14. Reconstruct owner values and evaluate relations.
15. Build all row, relation-set, operand-set, and graph digests.
16. Writes.
17. Receipt last.
18. Full in-transaction readback.
19. Permanently invalidate capability.
20. Exactly one COMMIT.

Admission write order is:
```
registry row if absent
typed projection if registry newly inserted
typed child rows
membership
relation bindings
relation operands
receipt
```

An exact reusable global value may already have registry/payload rows. Those rows are completely verified; only the new membership, relations, operands, and receipt are written.

Replay:

- Same mutation ref and different command digest: conflict.
- Same digest: verify the complete phase/member/payload/children/relation/operand/receipt graph and every dependency locator.
- Recomputable relations are rerun using their persisted evaluation time.
- Admission-time attestations are not rerun; their immutable relation version, operand identities, transient digests, command digest, and relation digest are verified.
- Persisted timestamps are reused. Replay calls no clock and writes nothing.

Commit-attempt exceptions return only `commit_outcome_unknown`. There is no automatic retry.

Explicit recovery under a newly acquired and fenced writer returns exactly:

- `committed_exact`: exact receipt exists and the complete family, DAG, typed rows, child rows, relation closure, result projection, graph digest, and dependency locators verify.
- `definitely_not_committed`: receipt and every operation-owned preassigned identity are absent, with no partial family or collision, and immutable prerequisite locators remain coherent.
- `unresolved`: every other state, including partial rows, wrong receipt digest, dependency loss/corruption, collision, inability to prove absence, read failure, cleanup uncertainty, or fencing failure.

Mutable program/work head advancement after a definitely absent operation affects a future retry through CAS; it does not by itself manufacture a committed result.

# C2 recomputation guarantee

C2 receives no opaque truth Boolean.

For cancellation-control recomputation, kind 14 supplies:

- exact cancellation-control profile pair;
- exact target class;
- target and cancellation effect/delivery identities;
- exact rank-10 request locator, if present;
- exact rank-12 adapter locators in the four owner roles;
- exact rank-11 process locators in the two owner roles;
- the complete target capsule manifest for validation/review targets;
- the phase’s exact command, attempt fence, and author fence owner identities.

C2 reconstructs all members from typed tables and all command/fence/delivery values from existing owner rows, then calls `classify_wire_exact_current_cancellation_control(...)`. The returned classification is not persisted as a C1 member.

For decision-basis closure, C2 can reconstruct:

- phase and K8;
- every admitted value;
- every membership and relation set;
- authority/narrowing/custody/retrieval evidence;
- readiness and both qualification families;
- declaration/observation/qualification Capability evidence;
- Wire request/process/worker/result/classification evidence;
- the complete post-execution Section 41 owner family.

For terminal-basis closure, C2 uses the same immutable C1 graph plus C2-owned decision, latch, cancellation reconciliation, and terminal records. C1 contains none of those C2 records.

Intentionally non-recomputable admission proofs are:

- phase establishment, because raw WorkSpec is not stored;
- rank 1 when its exact owner relation used a transient manifest;
- rank 3’s WorkSpec branch;
- rank 10/11 exact-current relations when a transient manifest was required;
- rank 12 owner relations requiring private before/after blobs.

C2 does not need those raw inputs to rerun their historical admission relation. For cancellation semantics specifically, the manifest and all cancellation facts needed by C2 are separately durable in kind 14 and the referenced members.

# Private reader contracts

All readers are private, capability-only, execute literal parameterized SELECTs, borrow one cursor, call `fetchmany(limit)`, reject non-built-in tuples or wrong shapes, close the cursor, and never own the connection.

Exact readers:

| ReaderPredicate/orderLimit      |                                                                         |     |
| ------------------------------- | ----------------------------------------------------------------------- | --- |
| receipt                         | `WHERE mutation_ref=?`                                                  | 2   |
| phase by ref                    | `WHERE phase_basis_ref=?`                                               | 2   |
| phase by pair                   | `WHERE phase_basis_ref=? AND phase_basis_digest=?`                      | 2   |
| phase by digest                 | `WHERE phase_basis_digest=?`                                            | 2   |
| phase by K8                     | all eight K8 equality predicates                                        | 2   |
| evidence by ref                 | `WHERE value_ref=?`                                                     | 2   |
| evidence by digest              | `WHERE value_digest=?`                                                  | 2   |
| typed payload                   | `WHERE value_ref=?` using the exact table column tuple                  | 2   |
| authority effect classes        | `WHERE value_ref=? ORDER BY ordinal,effect_class`                       | 5   |
| WorkerObservation evidence refs | `WHERE value_ref=? ORDER BY ordinal,evidence_ref`                       | 33  |
| membership by ref               | `WHERE membership_ref=?`                                                | 2   |
| membership by phase/value       | `WHERE phase_basis_ref=? AND value_ref=?`                               | 2   |
| exact dependency                | phase, membership, value ref/digest, and kind predicates                | 2   |
| relation set                    | subject key, ordered by `relation_rank,relation_ref`                    | 3   |
| operands                        | relation pair, ordered by `operand_ordinal`                             | 17  |
| retrieval prefix                | phase and correlation, ordered by `sequence_number,value_ref`           | 4   |
| member page                     | phase, cursor-after `(kind_rank,value_ref)`, ordered by those fields    | 257 |
| Section 41 source               | phase=`post_execution_semantic_review`, source ref                      | 2   |
| Section 41 artifact             | phase plus artifact ref                                                 | 2   |
| Section 41 proposal             | phase plus proposal ref                                                 | 2   |
| Section 41 evidence             | proposal ref, ordered by `role_rank,ordinal,evidence_role,evidence_ref` | 10  |

A page returns at most 256 members plus one overflow row.

Recovery and replay compose these exact readers; they do not use an unbounded join or a second read authority. Sixteen operands is sufficient for the largest frozen relation, and `LIMIT 17` detects overflow.

# Causal touched-file ledger

The exact must-change set contains 76 paths: 60 existing tracked paths and 16 new paths. The previous count of 75 is rejected; this is a different, path-derived set.

The conditional set is empty. Any need to touch a path outside this set is a reconciliation stop.

## Documentation and status paths

| PathClassExact stale contractIntended change / owner / omission failure |                   |                                                                 |                                                                                                         |
| ----------------------------------------------------------------------- | ----------------- | --------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------- |
| `AGENTS.md`                                                             | must\_change      | terminal-0003 fixture/current ownership registry lacks C1       | Record 0004/C1 boundaries; owner is repository governance; architecture tests would retain false status |
| `README.md`                                                             | must\_change      | terminal 0003 and RW0-C future status                           | Describe private C1 only; README contract assertions would drift                                        |
| `.docs/architecture.md`                                                 | must\_change      | catalog terminates at 0003; three reader consumers              | Tip 0004 and C1 private composition; architecture tests fail                                            |
| `.docs/authority-boundaries.md`                                         | must\_change      | RW0-C entirely future                                           | Split current C1 from future C2; status boundary test fails                                             |
| `.docs/autonomous-software-development-operating-model.md`              | must\_change      | current tip 0003 and RW0-C/D/E future                           | Update composition record; operating-model tests fail                                                   |
| `.docs/b3-tests-only-coherent-fixtures.md`                              | must\_change      | fixture current terminal 0003 and empty-table inventory         | Terminal 0004; new 23 tables empty; fixture tests fail                                                  |
| `.docs/b3-transition-persistence-contract.md`                           | must\_change      | current fixture terminal 0003                                   | Status-only fixture update; B3 contract tests fail                                                      |
| `.docs/b3c0a-transition-authority-and-order.md`                         | must\_change      | current fixture terminal 0003                                   | Status-only fixture update; B3c0a test fails                                                            |
| `.docs/b4c-public-global-stop-delegation.md`                            | must\_change      | current terminal-0003 fixture                                   | Status-only fixture update; new C1 boundary test rejects drift                                          |
| `.docs/c2a-first-slice-semantic-protocol-contract.md`                   | must\_change      | live current-tip assertion is 0003                              | Status-only 0004 update; C2A semantics remain byte/identity unchanged                                   |
| `.docs/c2b-durable-development-state.md`                                | must\_change      | live 39/64/1 tip and no C1 schema                               | Add exact 0004/C1 owner cross-reference; C2B0 contract test fails                                       |
| `.docs/c2b2-migration-0002.md`                                          | must\_change      | current catalog list terminates at 0003                         | Status-only catalog update; migration tests fail                                                        |
| `.docs/c2b2-private-readers.md`                                         | must\_change      | current tip 0003 and exactly three development-reader importers | Add C1 importer and tip 0004 without widening the frozen 24 queries; reader contract test fails         |
| `.docs/durable-state-model.md`                                          | must\_change      | current terminal/counts and fixture inventory                   | Add C1 durable family and exact totals; durable-state tests fail                                        |
| `.docs/rw0-b1-pure-phase-values.md`                                     | must\_change      | all RW0-C persistence/completeness is future                    | Record C1 consumption while leaving B1 identities untouched; new boundary test fails                    |
| `.docs/rw0-b2-capability.md`                                            | must\_change      | RW0-C wholly future/no durable consumer                         | Record C1 typed persistence; Capability semantics unchanged                                             |
| `.docs/rw0-b2-wire-protocol.md`                                         | must\_change      | RW0-C wholly future/no durable consumer                         | Record C1 ranks 10–14 and non-member classifier; Wire boundary tests fail                               |
| `.docs/rw0-remote-worker-contact-phase-entry.md`                        | must\_change      | RW0-C row is future/not implemented                             | Split C1 current from C2 future; phase-entry contract test fails                                        |
| `.docs/software-development-progression-boundary.md`                    | must\_change      | current terminal 0003/RW0-C future                              | Update private C1 boundary; progression test fails                                                      |
| `.docs/sqlite-bootstrap-and-migrations.md`                              | must\_change      | catalog/count/resource terminal 0003                            | Add 0004 definition and 62/110/5 totals; migration tests fail                                           |
| `.docs/sqlite-operations-and-recovery.md`                               | must\_change      | operation/recovery inventory omits C1                           | Add two private operations and three-way recovery; recovery tests fail                                  |
| `.docs/sqlite-schema-v1.md`                                             | must\_change      | current schema tip 0003                                         | Add exact 0004 inventory reference; schema tests fail                                                   |
| `.docs/sqlite-state-backend-adr.md`                                     | must\_change      | terminal 0003/current durable capability                        | Add 0004/C1 without changing backend decision; architecture tests fail                                  |
| `.docs/sqlite-threat-model.md`                                          | must\_change      | threat inventory stops at 0003                                  | Add C1 collision/transient/recovery threats; boundary tests fail                                        |
| `.docs/worker-execution-boundary.md`                                    | must\_change      | RW0-C durable state wholly future                               | Record C1 as evidence only, not worker/runtime authority                                                |
| `.docs/writer-session-authority.md`                                     | must\_change      | private operation inventory omits C1                            | Add two guarded private entries/recovery; writer-session tests fail                                     |
| `.docs/rw0-c1-durable-phase-and-evidence.md`                            | must\_change, new | absent owner                                                    | Add sole detailed C1 contract; all new C1 contract tests depend on it                                   |

## Production and migration paths

| PathClassStale/absent surfaceIntended change / owner / omission failure          |                   |                                           |                                                                            |
| -------------------------------------------------------------------------------- | ----------------- | ----------------------------------------- | -------------------------------------------------------------------------- |
| `src/ge_nwp_coordinator/sqlite_migrations/0004_rw0_phase_and_evidence_state.sql` | must\_change, new | absent schema                             | Exact 23/46/4 additive migration; migration test fails                     |
| `src/ge_nwp_coordinator/sqlite_migration.py`                                     | must\_change      | three-entry catalog and 39-table manifest | Add spec/checksum/tables/empty sets; initialization rejects 0004           |
| `src/ge_nwp_coordinator/_rw0_c1_row_values.py`                                   | must\_change, new | absent C1 rows/wrappers                   | Own immutable C1 row/value reconstruction                                  |
| `src/ge_nwp_coordinator/_rw0_c1_mutation_contracts.py`                           | must\_change, new | absent commands/results/DAG/relations     | Sole semantic-composition importer for B1/Capability/Wire/C2A/Section 41   |
| `src/ge_nwp_coordinator/_rw0_c1_reader_contracts.py`                             | must\_change, new | absent query/column contracts             | Own literal C1 SELECT specifications                                       |
| `src/ge_nwp_coordinator/_rw0_c1_readers.py`                                      | must\_change, new | absent capability readers                 | Execute bounded private reads                                              |
| `src/ge_nwp_coordinator/_sqlite_rw0_c1_phase_and_evidence.py`                    | must\_change, new | absent apply/replay/recovery resolver     | Own receipt-first resolution, relation evaluation, plans, recovery         |
| `src/ge_nwp_coordinator/sqlite_transition_transaction.py`                        | must\_change      | controller lacks C1 commit methods        | Add two controller operations and two recovery paths; no second controller |
| `src/ge_nwp_coordinator/sqlite_writer_session.py`                                | must\_change      | no private guarded C1 delegates           | Add private wrappers only; public protocol remains unchanged               |

## New tests

| PathClassPurpose                             |                   |                                                                |
| -------------------------------------------- | ----------------- | -------------------------------------------------------------- |
| `tests/test_sqlite_rw0_c1_migration_0004.py` | must\_change, new | exact SQL objects, counts, zero seed, 0003→0004                |
| `tests/test_rw0_c1_row_values.py`            | must\_change, new | schemas, fields, digests, immutability, privacy                |
| `tests/test_rw0_c1_mutation_contracts.py`    | must\_change, new | DAG, ranks, relation modes, command/result algebra             |
| `tests/test_rw0_c1_private_readers.py`       | must\_change, new | columns, limits, cardinality, capability-only access           |
| `tests/test_rw0_c1_phase_establishment.py`   | must\_change, new | phase CAS, K8, attested relation, atomic persistence           |
| `tests/test_rw0_c1_evidence_admission.py`    | must\_change, new | all 15 kinds and every legal dependency branch                 |
| `tests/test_rw0_c1_replay_conflicts.py`      | must\_change, new | replay, collisions, prerequisite failures, stale writer        |
| `tests/test_rw0_c1_commit_recovery.py`       | must\_change, new | committed/absent/unresolved DAG-aware recovery                 |
| `tests/test_rw0_c1_boundaries.py`            | must\_change, new | no public/contact/C2 widening; source/importer/doc inventories |

## Existing tests requiring causal updates

The following 21 contain an exact migration-resource/current-tip inventory ending in `0003_cognitive_proposal_and_selection_state.sql`; each must add 0004 while preserving its historical tranche assertions:
```
tests/test_autonomous_software_development_operating_model.py
tests/test_b2a_writer_session_contract.py
tests/test_b3_coherent_transition_fixture.py
tests/test_b3a_persistence_contracts.py
tests/test_b3b1_pure_row_contracts.py
tests/test_b3b2b_select_readers.py
tests/test_b3b_reader_prerequisite_contracts.py
tests/test_b3c0a_transition_authority_contract.py
tests/test_b3c0b_transition_event_replay_contracts.py
tests/test_b3c1_prerequisite_contract.py
tests/test_b3c1b_rollback_only_writer_fencing.py
tests/test_b3c3_prerequisite_contract.py
tests/test_c2a_nonimplementation.py
tests/test_runtime_non_authority.py
tests/test_sqlite_b1_migrations.py
tests/test_sqlite_b2c_writer_session.py
tests/test_sqlite_backend_b0_contract.py
tests/test_sqlite_c2b1_migration_framework.py
tests/test_sqlite_c2b2_migration_0002.py
tests/test_sqlite_section41_migration_0003.py
tests/test_worker_execution_semantic_boundaries.py
```

Their owning contracts are the migration catalog, runtime-source inventory, or protected earlier tranche. Omission causes an immediate resource-list, current-sequence, production-path, or schema-total failure.

Ten additional existing tests must change:

| PathExact stale contractIntended change / omission failure  |                                                           |                                                                       |
| ----------------------------------------------------------- | --------------------------------------------------------- | --------------------------------------------------------------------- |
| `tests/b3_coherent_transition_fixture.py`                   | `_CURRENT_PHYSICAL_MIGRATION_ID=0003` and empty inventory | use 0004 and assert 23 C1 tables empty                                |
| `tests/test_architecture_contracts.py`                      | terminal 0003/status literals                             | assert C1 private/current and 0004                                    |
| `tests/test_c2b0_durable_state_contract.py`                 | current 39/64/1 durable-schema record                     | add exact 0004 section and totals without rewriting history           |
| `tests/test_software_development_progression_boundary.py`   | terminal 0003/RW0-C future                                | assert C1/C2 split                                                    |
| `tests/test_rw0_b1_boundaries.py`                           | B1 importer allowlist admits only Capability              | admit the sole C1 semantic-composition importer                       |
| `tests/test_rw0_b2_capability_boundaries.py`                | no production Capability importer                         | admit the sole C1 semantic-composition importer                       |
| `tests/test_rw0_b2_wire_boundaries.py`                      | no production Wire importer and C entirely future         | admit C1 importer/status while retaining ownership                    |
| `tests/test_rw0_b2_wire_cancellation_control_boundaries.py` | C entirely future                                         | assert classifier still non-member and C1 operands durable            |
| `tests/test_rw0_remote_contact_phase_entry_contract.py`     | exact RW0-C future row                                    | split current C1/future C2                                            |
| `tests/test_c2b2_development_reader_contracts.py`           | exactly three private importers                           | add `_sqlite_rw0_c1_phase_and_evidence.py` with its exact role subset |

## Conditional and protected sets

Conditional ceiling: empty.

Protected set, exactly:
```
(all 209 baseline tracked paths)
minus
(the 60 existing must-change paths listed above)
```

plus the entire supporting repository remains protected.

Highlighted protected paths include:
```
src/ge_nwp_coordinator/sqlite_migrations/0001_initial.sql
src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql
src/ge_nwp_coordinator/sqlite_migrations/0003_cognitive_proposal_and_selection_state.sql
schemas/sqlite/coordinator-state-v1.sql
src/ge_nwp_coordinator/__init__.py
src/ge_nwp_coordinator/state_store.py
src/ge_nwp_coordinator/sqlite_errors.py
src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
src/ge_nwp_coordinator/_worker_execution_semantic_values.py
src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py
src/ge_nwp_coordinator/_cognitive_proposal_row_values.py
src/ge_nwp_coordinator/_cognitive_proposal_semantic_values.py
src/ge_nwp_coordinator/_sqlite_development_reader_contracts.py
src/ge_nwp_coordinator/_sqlite_development_readers.py
pyproject.toml
.docs/c2b2-pure-durable-row-values.md
.docs/c2b3-program-initialization.md
```

`.docs/c2b2-pure-durable-row-values.md` contains no live terminal/source-consumer inventory requiring alteration. `.docs/c2b3-program-initialization.md` is a frozen, explicitly superseded VS1A projection; its `0002`/“0003 absent” statements are historical, not current-tip claims. Touching either merely to replace a migration number is forbidden.

# Implementation decomposition

Use one branch and one workspace-write tranche with two internal passes:

1. Schema/value pass:
   - owner document;
   - C1 values, query contracts, readers;
   - migration 0004;
   - migration and pure-contract tests.
2. Atomic-runtime pass:
   - phase establishment;
   - evidence admission;
   - replay/conflicts;
   - commit and recovery;
   - writer/controller private integration;
   - status, inventory, and boundary updates.

The first pass is not an independently acceptable product milestone. Audit and acceptance apply only to the complete C1 candidate. This avoids creating a strategic “C1a” with schema but no safe mutation/recovery capability.

# Findings and contradictions

Resolved findings:

- The dependency gap is closed without grouped admission.
- Readiness and declarations carry no qualification truth.
- Capability observations depend on declarations structurally; qualification remains rank 9.
- Retrieval admission validates the complete admitted prefix and prevents branches.
- Cancellation responses require the exact admitted request.
- Result and classification wrappers depend only on admitted facts and owner rows.
- The target capsule manifest is durably embedded in rank 14, so C2 is not left with a ref/digest to an unpersisted claim.
- Section 41 preserves its owner-valid `0 or 9` grammar; C1 does not turn nine rows into admission completeness.
- Fifteen member kinds remain sufficient.
- The 23-table / 46-trigger / 4-index design is confirmed.
- The actual current physical baseline is 39/64/1, producing 62/110/5 after 0004.
- The former category-level 75-file estimate is replaced by an exact 76-path ledger.
- No owner, privacy, transaction, decomposition, or recovery contradiction was found.

# Forecasts and stop conditions

Falsifiable forecasts:

1. Migration verification will observe exactly 23 new tables, 46 new triggers, four new explicit indexes, no seed rows, sequence 4, and application generation 2.
2. Exhaustive finite-product tests will show that every committed membership is downward-closed over its frozen DAG and that every missing prerequisite produces zero C1 writes.
3. Commit fault injection will classify every run as exact committed, definitely absent, or unresolved, with no duplicate family and no automatic retry.

Implementation must stop and return for reconciliation if:

- an owner schema or field order differs from this inventory;
- a sixteenth member kind or third child table is required;
- a grouped admission becomes necessary;
- a C2 decision/latch/terminal column is proposed in 0004;
- any C2-required operand would remain only an unpersisted ref/digest;
- a second controller, connection path, writer authority, or public method is needed;
- migration totals differ from 23/46/4 or cumulative 62/110/5;
- an implementation change is required outside the exact must-change set;
- recovery cannot prove the complete dependency graph under the existing fenced transaction authority.

# Recommendation

Freeze this as the implementation contract for RW0-C1.

It closes the admission DAG, proof modes, exact ranks, row/value grammars, SQL topology, transaction ordering, replay, recovery, C2 operand reconstruction, reader limits, and touched paths without widening current owner contracts or introducing C2 behavior.

# Next implementation boundary

The next authorized boundary is the complete private RW0-C1 implementation described here: migration 0004, immutable phase establishment, single-member evidence admission, exact replay/conflict behavior, and explicit three-way recovery.

It does not authorize RW0-C2, completeness, decisions, terminal outcomes, latch mutation, external contact, worker/process execution, public API widening, or supporting-repository work.

REPOSITORY\_MUTATION\_NOT\_PERFORMED\
TESTS\_NOT\_RUN\
STAGING\_NOT\_PERFORMED\
COMMIT\_NOT\_PERFORMED\
PUSH\_NOT\_PERFORMED\
PR\_NOT\_CREATED\
REMOTE\_CONTACT\_NOT\_PERFORMED\
WORKER\_OR\_MODEL\_NOT\_INVOKED\
SUPPORTING\_REPOSITORIES\_NOT\_MODIFIED\
IMPLEMENTATION\_NOT\_PERFORMED

RW0\_C1\_FINAL\_IMPLEMENTATION\_CONTRACT\_READY
