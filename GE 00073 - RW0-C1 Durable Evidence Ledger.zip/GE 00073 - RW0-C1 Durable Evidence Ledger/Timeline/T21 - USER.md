Here is Codex's response:

# Baseline and inspection boundary

The local baseline matches every required identity:

| ItemObserved                      |                                                       |
| --------------------------------- | ----------------------------------------------------- |
| Branch                            | `trunk_dev`                                           |
| HEAD                              | `047563de5a443b0f8323401c92979ae2e444d2ed`            |
| Tree                              | `4ff9ee4a710af13447e3ed8699339a51255ff720`            |
| Sole parent                       | `dd12b23762dc761736e55a1abfde12dd3ec23551`            |
| Subject                           | `feat: add RW0-B2 cancellation-control evidence (#6)` |
| Upstream                          | `origin/trunk_dev`                                    |
| Ahead/behind                      | `0/0`                                                 |
| Worktrees                         | `1`                                                   |
| Worktree/index/untracked/unmerged | clean                                                 |
| Git operation/lock                | none                                                  |

Inspection was local and read-only. No fetch, database command, migration execution, test collection, or supporting-repository access occurred. The required owners, migrations, mutation paths, readers, and direct tests were inspected. Additional concrete dependencies inspected were `_cognitive_proposal_row_values.py`, `sqlite_errors.py`, the shared transaction controller, and current boundary-oracle inventories.

No `BASELINE_MISMATCH` exists.

# Owner reconciliation after cancellation-control merge

The owner seam is closed.

- `rw0-wire-cancellation-control-v1` with digest `4d6f84552b852a4c4073b4238591afd271072f648424eca9e744def436165288` covers exact-current request, process, and response relations for `author_candidate`, `validate_candidate`, and `review_candidate`.
- Author targets require the capsule operand to be omitted. Validation and review targets require an exact `CandidateCapsuleManifestV1`; only its safe identity projection may be durable.
- The cancellation-control profile remains separate from:
  - NWPF v1: `rw0-wire-nwpf-v1` / `470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454`;
  - B1 physical host `cancellation_profile_ref/digest`.
- Capability remains bound only to NWPF v1.
- C1 can admit the exact supplied request/process/C2A response facts and their relation operands without reproducing Wire semantics.
- The cancellation-control classifier has no schema, ref, digest, or durable identity. C1 must not persist its result. C2 can later recompute it from the profile pair plus exact immutable operands.
- No B1, B2, C2A, or C2B semantic identity, relation, budget, or version change is required.

The B1/Wire/Capability consumer registries and current-status projections will need synchronized updates when C1 exists. That is status-oracle churn, not semantic owner churn.

# Observable C1 capability

At C1 completion, a fresh fenced private reader can establish, for one phase basis:

- the exact immutable phase identity and K8/L34 lineage;
- the establishment command digest, committed result, receipt, graph digest, and timestamp;
- every admitted evidence value and its phase membership;
- its exact kind, owner schema, ref/digest, typed projection or C1 wrapper;
- the named owner relation/version, applicable profile pair, target class, capsule mode, and ordered operand closure;
- exact replay versus mutation-ref conflict versus semantic collision;
- whether an uncertain phase or member mutation is `committed_exact`, `definitely_not_committed`, or `unresolved`.

Required private operations are:

- `_establish_rw0_phase(...)`
- `_admit_rw0_evidence_member(...)`
- `_resolve_rw0_phase_establishment_commit_outcome(...)`
- `_resolve_rw0_evidence_member_admission_commit_outcome(...)`
- guarded receipt, phase, value, membership, relation, operand, graph, result, and ordered-page readers.

These remain private concrete-writer operations. C1 makes no assertion of completeness, authenticity, permission, acceptance, terminality, latch state, or external contact.

# Phase identity and graph

The durable phase identity is the B1 basis identity, not a new alias:

- primary address: `phase_basis_ref`;
- semantic identity: `(phase_basis_ref, phase_basis_digest)`;
- one phase per basis identity and one phase per exact K8;
- no separate mutable phase head.

K8 is exactly:

1. `program_ref`
2. `semantic_attempt_ref`
3. `candidate_ref`
4. `effect_intent_ref`
5. `author_command_ref`
6. `attempt_fence_ref`
7. `effect_fence_ref`
8. `delivery_attempt_ref`

L34 is exactly:

`program_ref`, `program_version_ref`, `program_version_number`, `accepted_intent_revision_ref`, `work_item_ref`, `work_item_revision_ref`, `semantic_attempt_ref`, `semantic_attempt_digest`, `attempt_number`, `candidate_ref`, `basis_decision_ref`, `basis_decision_digest`, `work_spec_ref`, `work_spec_digest`, `work_spec_safe_projection_digest`, `effect_intent_ref`, `effect_intent_digest`, `author_command_ref`, `author_command_digest`, `standing_grant_ref`, `standing_grant_digest`, `attempt_authorization_ref`, `attempt_authorization_digest`, `effect_authorization_ref`, `effect_authorization_digest`, `attempt_fence_ref`, `attempt_fence_digest`, `effect_fence_ref`, `effect_fence_digest`, `delivery_attempt_ref`, `delivery_envelope_digest`, `delivery_attempt_digest`, `authority_evaluation_ref`, `authority_evaluation_digest`.

The remaining copied B1 basis fields are:

`selected_proposal_ref/digest`, `selected_artifact_ref/digest`, `selected_artifact_binding_digest`, `selected_plan_safe_projection_digest`, `disposition_ref/digest`, `disposition`, selection-head revision/digest, current effect-head revision/state/digest, current delivery-head revision/state/digest, global-stop ref/version/state, path-scope digest, and basis digest.

C1 adds its own captured CAS coordinates without altering the B1 identity:

- program-head revision and digest; current version ref/number must equal L34 and state must be `active`;
- work-item-head revision and digest; current revision must equal L34 and state must be `planned`;
- selection/effect/delivery/global-stop coordinates remain the exact B1 basis coordinates.

Uniqueness is:

- primary `phase_basis_ref`;
- unique `phase_basis_digest`;
- unique exact K8;
- exact pair reconstruction must succeed.

Same basis ref with another digest, same digest with another ref, or the same K8 under another basis is a semantic collision. There is no mutable membership/completeness counter. Membership enumeration is deterministic by `(kind_rank, member_ref, member_digest)`.

The phase graph digest covers the immutable phase row, its relation binding, and dense ordered operand rows. The mutation receipt is excluded from that graph and instead binds the graph and result digests.

The B1 phase basis and kinds 1–9 are entry-current-effect gate evidence. A later validate/review/cancel effect binds back to stable K8 through its own C2A/Wire operands; it must not be represented as a changed B1 phase snapshot.

# Exact 15-kind evidence inventory

Common rules:

- Kinds 1–12 store full, explicit, typed, privacy-safe owner projections.
- Kinds 13–15 are C1 wrappers because the underlying owner does not supply the required standalone durable identity.
- `rw0_evidence_values` records only typed identity; payload remains in the kind-specific table.
- Global semantic keys are `(member_kind, member_ref)` and `(member_kind, member_digest)`.
- Phase membership is unique by `(phase_basis_ref, member_kind, member_ref)` and `(phase_basis_ref, member_kind, member_digest)`.
- Every reader reconstructs the exact owner value or C1 wrapper and its relation envelope. Every kind is testable using supplied fake values; those tests prove mechanics, not authenticity.

1. `authority_verification_observation`

   Full fields: `schema_id`, `observation_ref`, `source_ref`, `evidence_ref`, `evidence_digest`, `phase_basis_ref/digest`, parent grant and family pairs, attempt/effect basis pairs, attempt/effect fence pairs, `audience_ref`, `repository_ref`, base Git format/OID, `path_scope_digest`, `allowed_effect_classes`, `effect_class`, `parent_ceilings`, status/family/revocation states, grant/observation times, current effect/delivery head digests, global-stop coordinates, `observation_digest`.

   Identity is `observation_ref/digest`. Source binding is the supplied `source_ref` and evidence pair; no source kind or invocation is invented. It requires `validate_authority_observation`.
2. `subordinate_authorization_proposal`

   Full fields: `schema_id`, `proposal_ref`, phase/verification/parent-grant/grant-family/attempt-basis/effect-basis/attempt-fence/effect-fence pairs, audience/repository/base Git coordinates, `path_scope_digest`, `effect_class`, fifteen ceilings, `expires_at`, global-stop ref/version, `proposal_digest`.

   Identity is `proposal_ref/digest`. It requires `validate_per_fence_basis`, `validate_external_common_family_claim`, and `validate_subordinate_narrowing`. It remains an inert narrower proposal, never external authority.
3. `custody_availability_observation`

   Full fields: `schema_id`, `observation_ref`, `source_ref`, evidence pair, phase pair, `subject_kind`, subject ref/semantic digest, `content_sha256`, `byte_length`, `availability`, `observed_at`, `expires_at`, `observation_digest`.

   Identity is `observation_ref/digest`. It requires `validate_custody_binding`. No bearer, credential, location, or retrieval mechanism is stored.
4. `retrieval_capability_event_observation`

   Full fields: `schema_id`, `event_ref`, `source_ref`, evidence pair, phase pair, `safe_correlation_ref`, subject kind/ref/digest, content hash/length, semantic attempt, attempt/effect fence identities, audience/repository/base Git/path scope, authority/proposal/custody pairs, event kind, nullable predecessor pair, sequence number, occurrence/expiry times, `event_digest`.

   Identity is `event_ref/digest`; `(phase_basis_ref, safe_correlation_ref, sequence_number)` is additionally unique. The entire supplied prefix ending in this event must pass `validate_retrieval_event_sequence`.
5. `remote_host_readiness_observation`

   Full 39-field projection: schema/ref/source/evidence; safe host correlation; status/platform; platform, architecture, worker artifact/protocol, execution identity, process, isolation, resource, cancellation mechanism, credential handoff, capsule store, validation tool, review tool, and cleanup profile pairs; observation/expiry times; digest.

   Identity is `observation_ref/digest`. It is reconstructed exactly and participates in `validate_host_qualification`. Its cancellation profile is physical-mechanism evidence, not the Wire cancellation-control profile.
6. `effect_host_qualification`

   Full 45-field projection: schema/ref/phase pair; effect intent/fence pair; verification and readiness pairs; every required scenario/platform/architecture/worker/protocol/identity/process/isolation/resource/cancellation/credential/capsule/validation/review/cleanup profile pair; result/reason/evaluation time; digest.

   Identity is `qualification_ref/digest`. It requires `validate_host_qualification`.
7. `worker_mechanism_capability_declaration`

   Full 23-field projection: schema/ref; declaration source kind/ref; worker artifact and NWPF pairs; fourteen capability dimensions; declaration digest.

   Identity is `capability_declaration_ref/digest`. It has no invocation or evidence field. The only profile is NWPF v1.
8. `worker_mechanism_capability_observation`

   Full 30-field projection: schema/ref; observation source kind/ref/invocation; evidence pair; declaration pair; worker artifact and NWPF pairs; fourteen observed dimensions; observation/expiry times; digest.

   Identity is `capability_observation_ref/digest`.
9. `worker_mechanism_capability_qualification`

   Full 25-field projection: schema/ref; declaration, observation, worker artifact, NWPF, phase, authority, readiness, and host-qualification pairs; effect intent/fence identity; result/reason/evaluation time; digest.

   Identity is `capability_qualification_ref/digest`. Kinds 5–9 participate in `validate_worker_mechanism_capability_qualification`.
10. `wire_cancellation_request_observation`

&#x20;  Full fields: schema/ref; source kind/ref/invocation/evidence; program/version/accepted-intent/work/revision/attempt/candidate; command and attempt fence pairs; cancellation intent/fence/delivery identities; target intent/fence/delivery identities; observation time; digest.

&#x20;  Identity is `request_observation_ref/digest`. It requires the exact-current cancellation-request relation and cancellation-control profile.

11. `wire_process_observation`

&#x20;  Full fields: schema/ref; source kind/ref/invocation/evidence; event kind; program/version/accepted-intent/work/revision/attempt/candidate; command and attempt fence pairs; effect/fence/delivery identities; observation time; digest.

&#x20;  Identity is `process_observation_ref/digest`. It requires the exact-current process relation and cancellation-control profile.

12. `c2a_worker_observation`

&#x20;  Required fields: `schema_id`, `observation_ref`, `source_kind/ref/invocation`, `delivery_attempt_ref`, program/version/accepted-intent/work/revision/attempt/effect identity, command and attempt/effect fence pairs, `observation_kind`, `outcome`, `reason_code`, `evidence_refs`, `observed_at`, `observation_digest`.

&#x20;  Conditional fields are `candidate_ref`, `capsule_manifest_ref`, `portable_capsule_digest`, and `process_exit_code`.

&#x20;  Identity is `observation_ref/digest`. It requires `validate_observation_relation`; cancellation acknowledgement/rejection facts additionally require the exact-current Wire response relation.

13. `wire_worker_result_binding`

&#x20;  C1 wrapper fields: `schema_id`, `binding_ref`, NWPF pair, command pair, delivery pair, attempt-fence pair, author-effect-fence pair, observation count `2|3`, ordered observation-set digest, `binding_digest`.

&#x20;  Ordered observations are relation operands, not duplicated payloads. Identity is C1 `binding_ref/digest`. It requires `validate_wire_result_relation`.

14. `wire_process_result_classification_binding`

&#x20;  C1 wrapper fields: `schema_id`, `binding_ref`, NWPF pair, command/delivery/attempt-fence/author-fence pairs, result state `present|absent|protocol_error`, nullable kind-13 pair, nullable finite Wire failure reason, ordered adapter-observation-set digest, nullable request pair, process-observation-set digest, nullable cancellation fence/delivery pairs, NWPF `classification`, `reason`, classifier-operand-set digest, `binding_digest`.

&#x20;  Identity is C1 `binding_ref/digest`. Admission invokes `classify_wire_process_result` and requires exact output equality. This is the NWPF process/result classifier—not the cancellation-control classifier.

15. `section41_post_execution_proposal_family_member`

&#x20;  This is a ref/digest-only C1 wrapper over an already-persisted migration-0003 owner row. It always stores `schema_id`, C1 wrapper ref/digest, `proposal_phase=post_execution_semantic_review`, subtype, owning proposal pair, owner schema/table/key/self-digest.

&#x20;  Closed subtypes are:

- `source_invocation`: `source_invocation_ref/source_invocation_digest`;
- `private_artifact_binding`: `artifact_ref/artifact_binding_digest`;
- `model_proposal`: `proposal_ref/proposal_digest`;
- `evidence_binding`: proposal/evidence-set identities, role, rank, `ordinal=0`, evidence pair, binding digest.

&#x20;  The existing owner family must preexist and cohere. C1 does not insert or duplicate Section 41 rows and does not infer completeness from a subset of wrappers.

The phase basis is not a member. Terminal outcome is not a member. The cancellation-control classification is not a member and is never persisted. No sixteenth kind is needed.

# Relation and profile proof bindings

`rw0_relation_bindings` stores:

`schema_id`, `relation_binding_ref`, subject kind, phase pair, nullable member kind/ref/digest, literal relation ID, semantic version, nullable profile pair, nullable target effect class, capsule mode `omitted|bound`, nullable manifest ref/portable digest, nullable evaluation time, operand count, operand graph digest, and relation-binding digest.

`rw0_relation_operands` stores:

`schema_id`, relation-binding ref, dense zero-based ordinal, semantic role, owner schema ID, operand ref/digest, and operand-binding digest.

There is no `relation_valid`, permission, authenticity, or acceptance Boolean. The receipt-owned immutable row family demonstrates only that the named local pure relation returned successfully.

The closed version-1 relation ledger is:

- phase: `rw0-b1.validate-phase-entry-basis`;
- kind 1: `rw0-b1.validate-authority-observation`;
- kind 2: `rw0-b1.validate-per-fence-basis`, `rw0-b1.validate-external-common-family-claim`, `rw0-b1.validate-subordinate-narrowing`;
- kind 3: `rw0-b1.validate-custody-binding`;
- kind 4: `rw0-b1.validate-retrieval-event-sequence`;
- kinds 5–6: `rw0-b1.validate-host-qualification`;
- kinds 7–9: `rw0-b2-capability.validate-worker-mechanism-capability-qualification`, with NWPF;
- kind 10: `rw0-b2-wire.validate-exact-current-cancellation-request`;
- kind 11: `rw0-b2-wire.validate-exact-current-process-observation`;
- kind 12: `c2a.validate-observation-relation`, plus the response relation where applicable;
- kind 13: `rw0-b2-wire.validate-result-relation`, with NWPF;
- kind 14: `rw0-b2-wire.classify-process-result`, with NWPF;
- kind 15: `section41.reconstruct-post-execution-common-envelope-member`.

Cancellation-control ordered operands are exactly:

- request: request, author command, attempt fence, author fence, target fence, target delivery, cancellation fence, cancellation delivery, optional target manifest;
- process: process observation, author command, attempt fence, author fence, target fence, target delivery, optional target manifest;
- response: response, request, author command, attempt fence, author fence, target fence, target delivery, cancellation fence, cancellation delivery, optional target manifest.

Author targets encode capsule mode `omitted`; validation/review encode `bound` and the safe manifest pair. Capsule entries remain transient.

Replay/readback reconstructs the immutable proof and typed operands but does not rerun relations requiring unavailable raw WorkSpec or capsule entries. A fresh mutation invokes each owning relation exactly once. A later semantic owner change requires a new relation version; old bindings are never rewritten or reinterpreted.

# Commands, results, receipts, and replay

Two mutation families are frozen.

## Phase establishment

Command schema: `governed-execution.nwp-rw0-c1-establish-phase-command.v1`.

Ordered fields:

`schema_id`, `mutation_ref`, `phase_basis`, expected program-head revision/digest, expected work-head revision/digest, `preassigned_relation_binding_ref`, exact lineage, selection result/head, selected proposal/artifact, transient full WorkSpec, attempt fence, author effect fence, author command, author delivery, effect head, delivery head, global stop, `mutation_command_digest`.

The command digest uses the schema’s `.identity` domain and every preceding field, including transient relation operands. Raw inputs are never persisted.

Result fields:

`schema_id`, disposition `committed|exact_replay`, mutation ref, command digest, phase basis pair, program/work/attempt/candidate/effect identities, phase digest, mutation-graph digest, transaction timestamp, result-projection digest.

## Evidence-member admission

Command schema: `governed-execution.nwp-rw0-c1-admit-evidence-member-command.v1`.

Ordered fields:

`schema_id`, `mutation_ref`, phase pair, expected phase digest, member kind, exact typed owner value or C1 wrapper, one-to-three preassigned relation-binding requests with exact transient operands, `mutation_command_digest`.

Result fields:

`schema_id`, disposition, mutation ref, command digest, phase pair, member kind/ref/digest, relation-set digest, mutation-graph digest, transaction timestamp, result-projection digest.

## Receipt

Receipt schema: `governed-execution.nwp-rw0-c1-mutation-receipt.v1`.

Ordered fields:

`schema_id`, `mutation_ref`, mutation family, command schema/digest, phase pair, nullable member kind/ref/digest, relation-set digest, result class, result-projection digest, mutation-graph digest, outcome `committed`, committed timestamp, receipt digest.

The result-projection digest normalizes the durable disposition to `committed`; a replay returns `exact_replay` without changing the receipt.

Exact replay requires:

- valid active writer;
- same mutation family/schema/key;
- same command digest;
- complete exact row family;
- exact result, graph, relation-set, and receipt digests;
- exact agreement on every unique/collision route.

Same mutation key with another command is `mutation_ref_reuse_conflict`. A duplicate phase/member under a new mutation key is a semantic conflict, not replay and not an alias receipt.

Closed content-free conflicts are:

- `mutation_ref_reuse_conflict`
- `phase_identity_conflict`
- `phase_lineage_conflict`
- `current_state_conflict`
- `member_identity_conflict`
- `member_already_admitted`
- `relation_identity_conflict`

They expose no competing refs, digests, or existence details. There is no upsert behavior.

# Migration 0004 schema

Migration ID and resource:

`0004_rw0_phase_and_evidence_state`

Application compatibility remains `[2,2]`; sequence is `4`; `destructive=false`; all C1 tables are zero-seed.

Exactly 23 new `STRICT` tables are recommended:

1. `rw0_phase_instances`
2. `rw0_evidence_values`
3. `rw0_evidence_memberships`
4. `rw0_relation_bindings`
5. `rw0_relation_operands`
6. `rw0_c1_mutation_receipts`
7. `rw0_authority_verification_observations`
8. `rw0_subordinate_authorization_proposals`
9. `rw0_custody_availability_observations`
10. `rw0_retrieval_capability_event_observations`
11. `rw0_remote_host_readiness_observations`
12. `rw0_effect_host_qualifications`
13. `rw0_worker_mechanism_capability_declarations`
14. `rw0_worker_mechanism_capability_observations`
15. `rw0_worker_mechanism_capability_qualifications`
16. `rw0_wire_cancellation_request_observations`
17. `rw0_wire_process_observations`
18. `rw0_c2a_worker_observations`
19. `rw0_wire_worker_result_bindings`
20. `rw0_wire_process_result_classification_bindings`
21. `rw0_section41_post_execution_proposal_family_members`
22. `rw0_authority_observation_effect_classes`
23. `rw0_c2a_worker_observation_evidence_refs`

All columns use `ANY` with exact `typeof` and value checks, matching migration 0003 and preventing SQLite affinity coercion.

Core columns and keys are:

- `rw0_phase_instances`: exact flattened B1 phase projection and L34, captured program/work CAS coordinates, establishment time, and row digest. PK `phase_basis_ref`; unique basis digest and K8. FKs bind immutable C2B/Section 41 identities, never mutable heads/global stop.
- `rw0_evidence_values`: kind/rank, owner schema, member ref/digest, projection class, record digest. PK `(member_kind, member_ref)`; unique `(member_kind, member_digest)`.
- `rw0_evidence_memberships`: phase pair, kind/rank, member pair, relation-set digest, admitted time, membership digest. PK `(phase_basis_ref, kind_rank, member_ref)` with unique ref and digest membership routes.
- `rw0_relation_bindings`: the exact proof columns frozen above; PK `relation_binding_ref`.
- `rw0_relation_operands`: binding ref, dense ordinal, typed role/ref/digest; PK `(relation_binding_ref, operand_ordinal)`.
- `rw0_c1_mutation_receipts`: the closed two-family receipt algebra; PK `mutation_ref`.
- Tables 7–18 contain exact owner fields. Fifteen ceiling fields are flattened. Allowed effect classes and C2A evidence refs use normalized ordinal child tables. Only the retrieval predecessor pair and the four C2A owner-optional fields are nullable.
- Tables 19–21 contain the exact C1 wrapper fields defined above.

Every FK is `ON UPDATE RESTRICT ON DELETE RESTRICT NOT DEFERRABLE INITIALLY IMMEDIATE`.

Four new explicit partial unique indexes are required:

- phase relation route `(phase_basis_ref, relation_id, relation_version)` where subject is a phase;
- member relation route `(phase_basis_ref, member_kind, member_ref, relation_id, relation_version)` where subject is a member;
- one phase-establishment receipt per phase;
- one member-admission receipt per `(phase_basis_ref, member_kind, member_ref)`.

All other reads use PK/UNIQUE autoindexes.

Exactly 46 immutability guards are added: one no-update and one no-delete trigger per new table. There are no mutable C1 tables.

The cumulative forecast is 62 tables, 110 triggers, and 5 explicit indexes. Existing 0001/0002/0003 bytes remain immutable. Fresh initialization applies `[0001,0002,0003,0004]`; explicit migration accepts exact supported prefixes ending at 0001, 0002, or 0003 and applies the complete suffix atomically. Ordinary inspection, writer acquisition, and mutation accept only exact terminal 0004.

There is no downgrade. An older terminal-0003 binary rejects 0004 as newer. `schemas/sqlite/coordinator-state-v1.sql` remains the protected historical schema; cumulative expected-schema authority is the packaged SQL catalog, not a rewritten snapshot.

No C2 closure, latch, decision, terminal, or completeness table appears in 0004.

# Transaction sequencing

Both mutations use the existing WriterSession operation guard, resource-owned mutation slot, resource-bound connection, `BEGIN IMMEDIATE`, managed-schema validation, writer fence, nominal capability, capability invalidation, one commit attempt, and cleanup controller.

## Phase establishment

1. Reconstruct and digest the command before slot acquisition.
2. Enter the operation guard and sole mutation slot.
3. Open the resource-bound database, begin immediate, revalidate binding/schema, and fence the writer.
4. Read the receipt by mutation ref.
5. On a receipt hit, reconstruct the complete phase/relation/operand/result graph and collision routes; exact equality returns replay, otherwise conflict or integrity failure.
6. On a miss, probe phase basis ref, basis digest, K8, and preassigned relation identities.
7. Read, in fixed order:
   - program head/current version;
   - accepted-intent and work head/revision;
   - WorkSpec safe binding;
   - Section 41 selected proposal/artifact/disposition/selection head;
   - attempt-fence/command/effect/authority aggregate;
   - effect head;
   - delivery head;
   - global stop.
8. Compare program/work CAS coordinates.
9. Reconstruct L34/K8 and invoke `validate_phase_entry_basis` exactly once using the transient full WorkSpec.
10. Capture one whole-second UTC transaction timestamp.
11. Insert phase row, relation binding, dense operands, then receipt.
12. Invalidate the nominal capability.
13. Attempt exactly one commit.
14. Complete controller and operation cleanup.

## Member admission

1. Local command/type/digest preflight.
2. Enter the same guard/controller/fence sequence.
3. Receipt-first read and complete replay verification.
4. Read the exact phase.
5. Probe registry ref/digest, typed-payload, membership, and relation-route collisions.
6. Read relation-specific C2B/C1 operands in frozen order.
7. Capture one transaction timestamp where the relation consumes `now_utc`.
8. Invoke the owning pure relation or NWPF classifier exactly once.
9. If the global evidence value is new, insert registry, typed payload, and normalized children; an exact preexisting value may be reused.
10. Insert membership, relation bindings, operands, and receipt last.
11. Invalidate capability, attempt one commit, and clean up.

No external I/O occurs. The neutral commit-resolution state machine and bounded SELECT support remain unchanged; `sqlite_transition_transaction.py` gains only C1-specific entry integration.

# Commit-uncertainty recovery

Recovery requires a newly issued, fenced writer. The same writer session must not retry after `commit_outcome_unknown`.

## Phase establishment

`committed_exact` requires:

- exact receipt;
- exact phase row;
- exact relation binding and every operand;
- exact result, phase, graph, and receipt digests;
- exact basis-ref, basis-digest, K8, and relation unique routes.

`definitely_not_committed` requires simultaneous absence of:

- receipt by mutation ref;
- phase by basis ref;
- phase by basis digest;
- phase by K8;
- every preassigned relation-binding ref/digest and operand family.

Any receipt-only, phase-only, relation-only, partial operand family, alternate collision, malformed row, digest mismatch, cardinality violation, or unreadable database is `unresolved`.

## Evidence-member admission

`committed_exact` requires:

- the prerequisite phase to be exact;
- exact receipt;
- exact evidence registry and typed projection;
- exact phase membership;
- exact relation bindings/operands;
- exact result/graph/receipt digests and all unique routes.

An exact registry/payload may preexist because the same immutable evidence value can participate in another phase. It is not operation-owned.

`definitely_not_committed` requires:

- exact prerequisite phase;
- absent receipt;
- absent target membership;
- absent operation-owned relation bindings/operands;
- no colliding membership under the member ref or digest.

A missing, drifted, or corrupt phase; target partial family; receipt without membership; membership without receipt; wrong typed extension; alternate semantic collision; malformed relation/profile/operand; or unreadable state is `unresolved`.

This prevents duplicate phases/members and forbids speculative retry from ambiguous evidence.

# Private readers

All readers accept only `_MutationReadCapability`, use explicit-column parameterized `SELECT`, bounded fetches, exact tuples, owner row adapters, and content-free errors.

| ReaderInputOutput and cardinalityConsumer |                                              |                                                                    |                         |
| ----------------------------------------- | -------------------------------------------- | ------------------------------------------------------------------ | ----------------------- |
| Receipt                                   | mutation ref                                 | `None` or exact receipt; second row/corruption → integrity failure | replay/recovery         |
| Phase by ref/pair                         | basis ref and optional digest                | `None` or exact phase aggregate                                    | mutation/C2             |
| Phase by digest                           | digest                                       | collision locator, \`0                                             | 1\`                     |
| Phase by K8                               | eight refs                                   | collision locator, \`0                                             | 1\`                     |
| Evidence registry                         | kind+ref or kind+digest                      | `None` or typed identity                                           | mutation/recovery       |
| Typed value aggregate                     | kind+identity                                | exact owner value/wrapper                                          | replay/C2               |
| Membership                                | phase+kind+ref/digest                        | `None` or exact membership                                         | replay/recovery         |
| Relation aggregate                        | relation ref or member key                   | bounded ordered bindings and operands                              | replay/C2               |
| Member page                               | phase, after-cursor, limit `1..256`          | ordered `(kind_rank,member_ref,member_digest)`, query `LIMIT 257`  | diagnostics/C2          |
| Graph/result locator                      | receipt/result/graph digest                  | exact family or integrity failure                                  | recovery                |
| Section 41 post member                    | closed subtype locator                       | safe wrapper plus exact existing owner row                         | kind 15                 |
| Existing progression readers              | exact program/work/head/selection/fence refs | unchanged private aggregates                                       | phase/relation assembly |

Singletons use `LIMIT 2`. Relation operand aggregates use the closed maximum and `LIMIT 16`. No-row is `None` only for optional locators; a missing required row becomes conflict or integrity failure at the family assembler. Multiple or malformed rows are always database-integrity failure.

The current `_read_proposal_family_rows` is pre-execution/disposition-specific and cannot serve kind 15 unchanged. C1 needs a new private post-common-envelope reader. The existing 24-query C2B reader inventory remains unchanged.

There is no public reader.

# C2 compatibility seam

C1 preserves exactly the forward seam C2 needs:

- stable phase basis identity;
- stable typed evidence identity;
- deterministic ordered membership enumeration;
- immutable relation/profile versions and ordered operands;
- exact cancellation request/process/response operands;
- exact Section 41 member wrappers;
- immutable result/graph/receipt digests.

C2 can later create two separate immutable closures:

- decision-basis closure;
- terminal-basis closure.

It can recompute cancellation control from the fixed profile and selected immutable operands. C1 does not store a classifier output, completeness flag, generic evidence closure, decision, latch, or terminal outcome.

The C2 decisions that must be fixed now are only stable identity, ordering, and relation/profile operand interpretation. Latch postimage, productive direct-local accept integration, decision result shapes, terminal reconciliation, and terminal recovery remain C2-owned and deferred.

# Authority and privacy

C1 stores no:

- raw WorkSpec or selected-plan content;
- capsule entries, blob bytes, or private artifact;
- bearer, credential, signature, or trust root;
- endpoint, hostname, workspace, account, or provider secret;
- prompt, transcript, reasoning, response, private session, stdout/stderr, or provider logs;
- PID, process handle, or runtime control object;
- external-authentication conclusion;
- permission, acceptance, terminality, or executable authority.

The durable fact is only: Coordinator committed a supplied privacy-safe typed claim, membership, and exact local relation/profile binding.

All C1 source modules have empty `__all__`; there is no package-root export, public reader, `StateStore` change, or public `WriterSession` protocol widening. Concrete writer methods remain private and have no production caller before the separately governed D/E boundary. Bridge, Execution Substrate, and supporting repositories remain unchanged.

# Permanent-test architecture

Nine new permanent suites map one-to-one to finite claims:

1. `test_sqlite_rw0_c1_migration_0004.py`: resource bytes/checksum, catalog sequence/generation, exact schema, prefixes, zero seeds, cumulative inventory.
2. `test_rw0_c1_durable_row_values.py`: exact typed rows, self-digests, nested normalization, privacy, and 15-kind exclusivity.
3. `test_rw0_c1_persistence_contracts.py`: commands/results/receipts, K8/L34, graph ordering, membership-not-completeness, no sixteenth kind.
4. `test_rw0_c1_private_readers.py`: literal queries, cardinality, corruption, bounded pages, expired capability.
5. `test_rw0_c1_private_atomic_phase_establishment.py`: guard/fence/order, B1 relation invocation, writes, commit, cleanup, no I/O.
6. `test_rw0_c1_phase_establishment_recovery.py`: exact three-way recovery and every phase collision route.
7. `test_rw0_c1_private_atomic_evidence_member_admission.py`: all 15 kinds, owner relation invocation, profiles/targets/operands, replay/conflicts/collisions, every write boundary.
8. `test_rw0_c1_evidence_member_admission_recovery.py`: prerequisite phase, reusable value versus operation-owned family, partial/corrupt/collision outcomes.
9. `test_rw0_c1_private_writer_delegation.py`: private delegation only, content-free errors, no public/API/authority widening.

Fault tests must cover every insert, capability invalidation, precommit rollback, commit-before-underlying, commit-after-underlying-success, cursor/connection close, and operation cleanup boundary.

Tests must causally exercise product behavior. Source-string scans and broad hashes may protect literal migration/status provenance but must not substitute for semantic tests or defend the candidate against equal-authority mutation.

# Independent-audit architecture

A separate clean audit harness should:

1. Record base/candidate commits, trees, exact patch, modes, touched paths, and SHA-256.
2. Independently execute fresh 0001–0004 and upgrades from 0001, 0002, and 0003.
3. Inspect `sqlite_schema`, `table_xinfo`, foreign keys, indexes, triggers, and seeds.
4. Compare fresh and upgraded cumulative schemas, then perform clean and live validation.
5. Inject failures externally around every read/write/commit/rollback/cleanup boundary.
6. Generate receipt-only, row-only, missing-child, wrong-digest, collision, relation-version/profile/operand-order, target-class, forbidden-classification, and privacy mutants.
7. Verify the three-way recovery classification independently.
8. Inspect every durable cell for forbidden material.
9. Inspect exports/imports and public signatures.
10. Trace every test to one frozen claim.

Defect classes are:

- candidate defect: code violates a sound frozen contract;
- contract defect: the freeze is inconsistent, incomplete, or unsafe;
- test/oracle defect: a checked-in test is stale, non-causal, or wrong;
- audit-harness defect: independent parsing, injection, or mutation is wrong;
- report defect: evidence is misstated or omitted;
- environment defect: unsupported SQLite/filesystem/tooling prevents a conclusion.

# Exact touched-file ceiling

The maximum implementation allowlist is 75 files.

Documentation/status, 24:

`AGENTS.md`, `README.md`, `.docs/architecture.md`, `.docs/authority-boundaries.md`, `.docs/autonomous-software-development-operating-model.md`, `.docs/b3-tests-only-coherent-fixtures.md`, `.docs/b3-transition-persistence-contract.md`, `.docs/b3c0a-transition-authority-and-order.md`, `.docs/b4c-public-global-stop-delegation.md`, `.docs/c2a-first-slice-semantic-protocol-contract.md`, `.docs/c2b2-migration-0002.md`, `.docs/c2b2-private-readers.md`, `.docs/durable-state-model.md`, `.docs/rw0-b1-pure-phase-values.md`, `.docs/rw0-b2-capability.md`, `.docs/rw0-b2-wire-protocol.md`, `.docs/rw0-remote-worker-contact-phase-entry.md`, `.docs/software-development-progression-boundary.md`, `.docs/sqlite-bootstrap-and-migrations.md`, `.docs/sqlite-operations-and-recovery.md`, `.docs/sqlite-schema-v1.md`, `.docs/sqlite-state-backend-adr.md`, `.docs/sqlite-threat-model.md`, `.docs/worker-execution-boundary.md`.

Production, 10:

- `src/ge_nwp_coordinator/sqlite_migrations/0004_rw0_phase_and_evidence_state.sql`
- `src/ge_nwp_coordinator/sqlite_migration.py`
- `src/ge_nwp_coordinator/_rw0_c1_durable_row_values.py`
- `src/ge_nwp_coordinator/_rw0_c1_persistence_contracts.py`
- `src/ge_nwp_coordinator/_sqlite_rw0_c1_reader_contracts.py`
- `src/ge_nwp_coordinator/_sqlite_rw0_c1_readers.py`
- `src/ge_nwp_coordinator/_sqlite_rw0_c1_phase_establishment.py`
- `src/ge_nwp_coordinator/_sqlite_rw0_c1_evidence_member_admission.py`
- `src/ge_nwp_coordinator/sqlite_transition_transaction.py`
- `src/ge_nwp_coordinator/sqlite_writer_session.py`

New tests, 9: the nine permanent suites listed above.

Existing status/catalog/oracle synchronization, 32:

`tests/b3_coherent_transition_fixture.py`, `test_architecture_contracts.py`, `test_autonomous_software_development_operating_model.py`, `test_b2a_writer_session_contract.py`, `test_b3_coherent_transition_fixture.py`, `test_b3a_persistence_contracts.py`, `test_b3b1_pure_row_contracts.py`, `test_b3b2b_select_readers.py`, `test_b3b_reader_prerequisite_contracts.py`, `test_b3c0a_transition_authority_contract.py`, `test_b3c0b_transition_event_replay_contracts.py`, `test_b3c1_prerequisite_contract.py`, `test_b3c1b_rollback_only_writer_fencing.py`, `test_b3c3_prerequisite_contract.py`, `test_b4c_public_global_stop_delegation.py`, `test_c2a_nonimplementation.py`, `test_c2b2_development_reader_contracts.py`, `test_c2b3c_author_effect_contract.py`, `test_runtime_non_authority.py`, `test_rw0_b1_boundaries.py`, `test_rw0_b2_capability_boundaries.py`, `test_rw0_b2_wire_boundaries.py`, `test_rw0_b2_wire_cancellation_control_boundaries.py`, `test_rw0_remote_contact_phase_entry_contract.py`, `test_software_development_progression_boundary.py`, `test_sqlite_b1_migrations.py`, `test_sqlite_b2c_writer_session.py`, `test_sqlite_backend_b0_contract.py`, `test_sqlite_c2b1_migration_framework.py`, `test_sqlite_c2b2_migration_0002.py`, `test_sqlite_section41_migration_0003.py`, `test_worker_execution_semantic_boundaries.py`.

Protected paths include:

- B1/B2/C2A/worker/Section 41 semantic source modules;
- existing development row values/readers/mutation families;
- `state_store.py`, package `__init__.py`, `sqlite_mutation_transaction_contracts.py`, and `sqlite_transition_select_support.py`;
- `pyproject.toml`;
- `schemas/sqlite/coordinator-state-v1.sql`;
- migrations 0001–0003;
- `tests/c2a_contract_support.py`;
- `tests/test_c2b2_development_row_value_boundaries.py`;
- `tests/test_codex_agent_config.py`;
- every supporting repository.

Existing status/hash oracles may change only where the new current tip or private consumer inventory makes their old assertion false. They must not acquire C1 semantic ownership.

# Findings and contradictions

No architectural stop is presently established. The following seams are resolved by this freeze:

1. Full WorkSpec is transient and forbidden from SQLite. Phase establishment invokes the B1 relation once; durable replay verifies its versioned relation receipt and cannot claim to rerun it from SQLite alone.
2. B1 basis lacks program/work-head CAS. C1 adds captured expected revision/digest coordinates without changing the B1 identity.
3. The existing Section 41 proposal-family reader is pre-execution-only. C1 requires a new post-common-envelope locator and remains a non-writer of those rows.
4. B1 entry-current-effect evidence cannot be reused as though it represented an advanced later effect head. Later facts use C2A/Wire relations to stable K8.
5. Relation-failing negative B1 claims are not admitted as successfully bound membership. Retaining such failed claims would require a separately frozen ingest-disposition contract.
6. Current consumer/status tests describe C as wholly future and terminal migration 0003. Those assertions must be synchronized; this is not owner-semantic churn.
7. Generic JSON/BLOB payloads and a universal evidence body are rejected because they would weaken typed closure, privacy inspection, collision probes, and recovery.

# Forecasts and stop conditions

Falsifiable forecasts:

- The earliest candidate failures will be stale terminal-0003 inventories, migration-directory glob assertions, consumer allowlists, and the coherent fixture—not C1 semantic logic.
- The highest-risk implementation area is total-absence recovery across typed value, membership, relation, operand, and receipt collision routes. An omitted route will incorrectly permit retry.
- A conforming candidate will remain generation 2 with one additive 0004, 23 new immutable STRICT tables, 46 guards, four new explicit indexes, six new private source modules, and no public/API change.

Architectural replan is required if evidence establishes any of:

- owner identity/relation/budget change;
- a sixteenth member kind;
- mutable phase/completeness head;
- persisted cancellation-control classification;
- raw/private material requirement;
- inability to prove three-way recovery;
- external I/O in a transaction;
- public or production caller before D/E;
- C2 closure/latch/terminal state in 0004;
- C1 authorship of Section 41 rows;
- a second mutation controller or authoritative writer.

# Recommendation

RW0-C1 is ready to freeze for implementation under the contract above. It is independently useful as durable, receipt-backed, typed membership and relation evidence without implying completeness or authority.

# Next implementation boundary

The next boundary is only the private C1 candidate within the exact allowlist: one additive generation-2 migration, typed row/contract/read/runtime modules, private concrete-writer delegation, recovery, permanent tests, and synchronized documentation/status oracles. C2 closure, decision integration, latch mutation, terminal outcome, D/E contact mechanics, Bridge, Execution Substrate, and supporting repositories remain out of scope.

REPOSITORY\_MUTATION\_NOT\_PERFORMED\
TESTS\_NOT\_RUN\
STAGING\_NOT\_PERFORMED\
COMMIT\_NOT\_PERFORMED\
PUSH\_NOT\_PERFORMED\
PR\_NOT\_CREATED\
REMOTE\_CONTACT\_NOT\_PERFORMED\
WORKER\_OR\_MODEL\_NOT\_INVOKED\
SUPPORTING\_REPOSITORIES\_NOT\_MODIFIED\
IMPLEMENTATION\_NOT\_PERFORMED

RW0\_C1\_CONTRACT\_FREEZE\_READY
