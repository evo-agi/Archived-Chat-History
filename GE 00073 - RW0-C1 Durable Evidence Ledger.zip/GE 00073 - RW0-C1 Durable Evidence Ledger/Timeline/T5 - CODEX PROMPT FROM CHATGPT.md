PROMPT_ID

RW0_B2_CANCELLATION_CONTROL_FINAL_CONTRACT_FREEZE_V1

TITLE

Coordinator RW0-B2 — final read-only contract freeze for additive exact-current-
effect cancellation-control evidence semantics before implementation

ENGAGEMENT TYPE

Parent-only read-only contract and implementation-surface freeze.

Do not modify repository files.
Do not run pytest, node collection, migrations, mutation probes, staging,
commit, push, PR, merge, release, deployment, remote contact, provider/live
contact, product worker/model execution, database work, dependency installation,
or supporting-repository inspection.

Read-only deterministic Python calculations outside the repository are
authorized only to compute canonical profile bytes, SHA-256 identities, exact
field/work arithmetic, and proposed test vectors. They must not modify the
repository.

Print the complete substantive result inline in chat. Evidence paths may be
supplementary only.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

EXPECTED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
dd12b23762dc761736e55a1abfde12dd3ec23551

parent:
deec37bf08fb903d8846aa2c3232aec52fa9866e

subject:
feat: implement RW0-B2 Capability semantics (#5)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktree:
clean

No fetch or remote contact is authorized.

ACCEPTED STRATEGIC DECISIONS

Preserve these decisions unless repository evidence proves a concrete
contradiction:

1. Preserve all current `rw0-wire-nwpf-v1` schemas, profile ref/digest, values,
   frames, codecs, relations, classifier, golden vectors, and Capability/B1
   binding semantics unchanged.

2. Add a separate private Wire-owned cancellation-control evidence profile.

3. Reuse unchanged:
   - RW0WireCancellationRequestObservationV1;
   - RW0WireProcessObservationV1.

4. Keep v1-only:
   - RW0WireWorkerResultV1;
   - RW0WireProcessResultClassificationV1;
   - classify_wire_process_result(...).

5. Add exact-current-target relations for:
   - author_candidate;
   - validate_candidate;
   - review_candidate.

6. Require omitted capsule manifest for author and the exact
   CandidateCapsuleManifestV1 for validation/review.

7. Add a separate cancellation-control classification value. It classifies
   only supplied request/response/process/exit/control evidence. It does not
   classify worker, validation, review, teardown, reconciliation, terminal
   outcome, permission, or acceptance.

8. Keep the new profile distinct from:
   - `rw0-wire-nwpf-v1`;
   - B1’s physical host cancellation-mechanism profile.

9. Capability remains unchanged and continues to bind only the existing worker
   protocol pair.

10. C1 durable evidence membership remains 15 kinds. The new cancellation
    classification is recomputed and bound by C2 closure; it is not a C1
    evidence member.

11. No persistence, I/O, process control, transport, source authentication,
    public export, production caller, runtime authority, or external contact is
    implemented.

PRIMARY OBJECTIVE

Close the remaining contract gaps so the next response can be one exact
parent-only implementation prompt.

The result must freeze:

- the exact profile manifest and digest;
- exact value/classification grammar;
- exact relation signatures and precedence;
- exact safe-reconstruction strategy;
- exact cardinality/work bounds;
- exact status/document treatment;
- exact touched-file ceiling;
- exact permanent-test plan;
- exact independent-audit plan.

Do not implement.

MANDATORY CORRECTION TO THE PRIOR RECONCILIATION

The prior 10-file ceiling is incorrect.

The merged Capability boundary test contains the exact protected-content row:

```text
P01
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
77003
6bf39f634b619829fcc4cc7ada5cf019b40b3c5a2258947ebee8fdfe2a13031e
```

Therefore any intentional Wire source edit requires an explicit compatibility
update to:

```text
tests/test_rw0_b2_capability_boundaries.py
```

The final touched-file ceiling must include that path. The only authorized
change in it should be the final P01 byte size and SHA-256, unless inspection
proves another exact contract must change. Classify this as an intentional
protected-owner compatibility update, not Capability semantic churn.

Inspect every other source-hash, size, literal path inventory, status marker,
or import consumer that might similarly force a touched-file addition.

REQUIRED INSPECTION

Read completely or in every relevant section:

- AGENTS.md
- README.md

- .docs/rw0-b2-wire-protocol.md
- .docs/rw0-remote-worker-contact-phase-entry.md
- .docs/authority-boundaries.md
- .docs/autonomous-software-development-operating-model.md
- .docs/durable-state-model.md
- .docs/worker-execution-boundary.md
- .docs/rw0-b2-capability.md
- .docs/rw0-b1-pure-phase-values.md
- .docs/c2a-first-slice-semantic-protocol-contract.md

- src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
- src/ge_nwp_coordinator/_worker_execution_semantic_values.py
- src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
- src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
- src/ge_nwp_coordinator/__init__.py
- pyproject.toml

- tests/test_rw0_b2_wire_values.py
- tests/test_rw0_b2_wire_relations.py
- tests/test_rw0_b2_wire_codec.py
- tests/test_rw0_b2_wire_boundaries.py
- tests/test_rw0_b2_capability_values.py
- tests/test_rw0_b2_capability_vectors.py
- tests/test_rw0_b2_capability_relations.py
- tests/test_rw0_b2_capability_boundaries.py
- tests/test_rw0_b1_phase_values.py
- tests/test_rw0_b1_vectors.py
- tests/test_rw0_b1_relations.py
- tests/test_rw0_b1_boundaries.py
- tests/test_worker_execution_semantic_values.py
- tests/test_worker_execution_semantic_vectors.py
- tests/test_worker_execution_semantic_relations.py
- tests/test_worker_execution_semantic_boundaries.py
- tests/test_c2a_relations.py
- tests/test_c2a_effects_and_recovery.py
- tests/test_rw0_remote_contact_phase_entry_contract.py
- tests/test_architecture_contracts.py
- tests/test_software_development_progression_boundary.py
- tests/test_runtime_non_authority.py
- tests/test_c2a_nonimplementation.py

Inspect additional Coordinator files only for a concrete dependency and state
why.

A. EXACT PROFILE LITERAL

Freeze one exact literal manifest for:

```text
schema_id:
governed-execution.nwp-rw0-wire-cancellation-control-profile.v1

profile_ref:
rw0-wire-cancellation-control-v1

digest_domain:
governed-execution.nwp-rw0-wire-cancellation-control-profile.v1.identity
```

Freeze:

- exact mapping key order:
  `schema_id`, `profile_ref`, `manifest`, `profile_digest`;
- exact manifest key inventory and order;
- exact scalar/container types;
- exact target classes;
- exact relation names;
- exact operand roles;
- exact capsule rule;
- exact fact grammar/cardinalities;
- exact classification values;
- exact reason inventory;
- exact result/reason matrix;
- exact precedence;
- exact route/source mapping;
- exact nonclaims;
- exact work/cardinality limits;
- exact identity canonicalization:
  UTF-8, NUL-separated domain, compact sorted-key JSON, no Unicode
  normalization, SHA-256;
- exact canonical manifest bytes, byte length, and profile digest.

Use a deterministic read-only calculation and print the complete canonical
manifest JSON inline.

The profile mapping must return a fresh exact built-in dict and a fresh exact
manifest dict. It may retain owner-controlled literal constants because Wire is
the semantic owner. It must not enter NWPF frames.

B. CLASSIFICATION VOCABULARY

Reconsider the prior `invalid / unusable / usable` vocabulary.

The new contract has no compatibility requirement to overload worker-result
“usable.” Prefer semantically explicit values unless repository evidence shows
otherwise.

Evaluate and choose exactly one matrix:

Option A:
```text
invalid
incomplete
finite
```

Option B:
```text
invalid
unusable
usable
```

If Option B is retained, defend why `cancellation_rejected` as `usable` cannot
be confused with successful cancellation or semantic acceptance.

Recommended target unless contradicted:

```text
classification:
invalid | incomplete | finite

invalid reasons:
invalid_input
duplicate_fact
unrelated_fact
conflicting_fact
cancellation_graph_mismatch

incomplete reasons:
process_evidence_incomplete
resource_limit_exceeded
deadline_elapsed
signal_delivered
cancellation_acknowledged
cancellation_request_pending

finite reasons:
cancellation_rejected
target_process_exited
```

Freeze the exact precedence. State the result for every coexistence case,
including:

- rejection plus exit;
- acknowledgement plus exit;
- signal plus exit;
- resource limit plus exit;
- deadline plus exit;
- process facts without request;
- response without request;
- request only;
- no facts.

`finite` must mean only that the supplied control graph has a finite
control-plane result suitable for later C2 reasoning. It must not mean semantic
cancellation, target success/failure, teardown, terminality, permission, or
acceptance.

C. CLASS API

Freeze exact new class behavior for:

```text
RW0WireCancellationControlClassificationV1
```

Specify:

- exact ordered fields;
- slots;
- construction boundary;
- finite values/reasons;
- result/reason coherence;
- immutability;
- copy/deepcopy behavior if applicable;
- pickling behavior;
- repr/str;
- `to_mapping`;
- whether it has no schema/ref/digest identity;
- why the profile plus exact operand closure, rather than the value itself,
  owns identity.

No nullable or hidden payload fields.

D. EXACT RELATION SIGNATURES

Freeze exact signatures for:

```text
validate_wire_exact_current_cancellation_request_relation
validate_wire_exact_current_process_observation_relation
validate_wire_exact_current_cancellation_response_relation
classify_wire_exact_current_cancellation_control
cancellation_control_profile_mapping
```

Use the existing imported C2A sentinel name:

```text
_C2A_MISSING
```

unless a distinct Wire-owned omitted sentinel is proven necessary.

For each relation, specify:

- exact parameter order;
- exact accepted types;
- exact optional/omitted semantics;
- author versus validation/review capsule branch;
- exact C2A owner relations invoked;
- exact target/cancellation orientation;
- exact route/source mapping;
- exact relation failure precedence;
- exact content-free public boundary;
- exact process-control exception propagation;
- no timestamp ordering or authenticity claim.

Resolve whether target delivery validation requires any additional operand
beyond the prior reconciliation’s signature. Do not infer it; trace the exact
C2A relation signatures.

E. SAFE RECONSTRUCTION AND OWNER REUSE

Do not widen the existing v1 `_C2A_FIELD_INVENTORIES` or alter its current
behavior merely to admit CandidateCapsuleManifestV1.

Evaluate and freeze the preferred additive strategy:

- import CandidateCapsuleManifestV1 through a separate additive private import;
- reuse C2A’s existing private exact owner reconstruction helper
  `_reconstruct_exact_worker_execution_value` for the manifest and nested
  CapsuleEntryV1 graph;
- sanitize WorkerExecutionValueError through the Wire boundary;
- retain current v1 extraction helpers unchanged.

If that private helper is not suitable, specify an additive Wire helper with
exactly equivalent raw-slot, cycle, alias, type, cardinality, and work
semantics. Do not duplicate owner semantics casually.

Freeze the exact import direction and prove no C2A source/test change is needed.

F. WORK, CARDINALITY, AND HOSTILE INPUT BOUNDS

Derive exact maxima rather than prose-only “bounded” claims.

At minimum freeze:

- maximum request count;
- maximum adapter-observation count;
- maximum process-observation count;
- maximum total supplied facts;
- maximum singleton role counts;
- maximum manifest entries inherited from the C2A owner;
- exact work tariff for each reconstructed operand class;
- exact relation-local work maximum;
- exact classifier-local work maximum;
- exact maximum-valid and one-under controls;
- tuple/list/mapping outer-type behavior;
- duplicate object/ref/digest accounting;
- cycle and alias behavior;
- integer preconversion behavior;
- foreign-exception sanitization.

Keep these limits separate from NWPF v1 frame caps and hostile-work profile
identities. Existing v1 caps/digests must remain unchanged.

G. CLASSIFIER INPUT AND PRECEDENCE

Freeze exact fact roles:

```text
request:
0 or 1

adapter observations:
0 to 4
roles:
cancellation_acknowledged
cancellation_rejected
deadline_elapsed
process_exited

process observations:
0 to 2
roles:
resource_limit_exceeded
signal_delivered

total facts:
0 to 7
```

Freeze:

- duplicate identity/ref/digest precedence;
- singleton conflict precedence;
- acknowledgement/rejection mutual exclusion;
- unrelated fact handling;
- graph mismatch handling;
- request/response dependence;
- target process facts without request;
- all exact classification rows.

State how process exit codes `-255`, `0`, and `255` are treated and prove zero
has no special cancellation meaning.

H. STATUS AND DOCUMENT CONTRACT

Freeze exact new owner/status prose and markers.

Requirements:

- Wire owner explains both existing NWPF v1 and the new cancellation-control
  profile without implying one replaces the other.
- Five synchronized status projections remain normalized-identical.
- Existing exact phrases required by current tests remain present unless an
  existing test is explicitly added to the touched-file ceiling.
- RW0 current-contract registry need not gain a new component row unless a
  separate owner is actually created.
- C remains future and blocked pending this merge.
- D/E/ES ownership remains unchanged.
- No document implies persistence, transport, process control, authentication,
  or terminality.

Prove whether the six proposed document paths are sufficient without changing
existing status tests.

I. TOUCHED-FILE CEILING

Recompute the exact ceiling.

The minimum expected set is 11 files:

Documents:
1. .docs/rw0-b2-wire-protocol.md
2. .docs/rw0-remote-worker-contact-phase-entry.md
3. .docs/authority-boundaries.md
4. .docs/autonomous-software-development-operating-model.md
5. .docs/durable-state-model.md
6. .docs/worker-execution-boundary.md

Source:
7. src/ge_nwp_coordinator/_rw0_wire_protocol_values.py

New tests:
8. tests/test_rw0_b2_wire_cancellation_control_values.py
9. tests/test_rw0_b2_wire_cancellation_control_relations.py
10. tests/test_rw0_b2_wire_cancellation_control_boundaries.py

Intentional compatibility update:
11. tests/test_rw0_b2_capability_boundaries.py
    - update only P01 expected size and SHA-256 after final Wire source bytes
      are frozen;
    - no Capability semantic assertion may change.

Search every exact source identity, size, digest, path inventory, import
inventory, status marker, and protected-content consumer. If another file is
required, identify the exact causal reason.

Do not expand the ceiling for convenience.

J. SOURCE LAYOUT AND V1 PRESERVATION

Freeze additive placement in the Wire module.

Requirements:

- current v1 profile literal/ref/digest unchanged;
- current request/process definitions unchanged;
- current author-only relation definitions unchanged;
- current worker result and process/result classification unchanged;
- current frame/codec code unchanged;
- current `wire_profile_mapping()` unchanged;
- current old test files unchanged;
- additive import(s), constants, class, mapping, reconstruction, relations, and
  classifier only;
- no package export or production caller.

Specify exact protected source regions or symbol identities that independent
audit must compare before/after.

K. PERMANENT TEST PLAN

For each of the three new test modules, freeze exact node purposes.

Values:
- exact profile literal and independently computed digest;
- fresh mapping;
- classification value grammar and immutability;
- current request/process value compatibility;
- v1 profile non-churn;
- work/cardinality vectors.

Relations:
- complete author/validation/review request matrix;
- complete process matrix;
- response matrix;
- exact capsule branch;
- route/source matrix;
- target/cancellation swaps;
- cross-attempt and sibling manifest rejection;
- process-control propagation;
- relation work maxima.

Boundaries:
- complete classifier precedence/coexistence matrix;
- duplicate/conflict/unrelated/graph mismatch;
- every cardinality boundary;
- exit-code controls;
- hostile reconstruction, cycles, aliases, foreign exceptions;
- private/no-export/no-caller/no-I/O;
- synchronized status;
- Capability and B1 non-churn;
- P01 compatibility update exactness.

Do not use self-protecting tests or production-derived expected profile
digests.

L. INDEPENDENT AUDIT PLAN

Freeze finite external audit responsibilities:

- exact patch manifest and 11-file ceiling;
- independent profile digest recomputation;
- proof every old v1 protected symbol and old test file is unchanged;
- literal target/cancel/capsule mutants;
- classifier precedence mutants;
- relation operand omission/alias/cycle mutants;
- status projection and authority review;
- package/import/no-caller/no-I/O review;
- exact P01 update;
- live and clean complete-suite validation.

M. FORECASTS AND STOP CONDITIONS

Record two or three falsifiable forecasts and likely finding classes.

Return `B2_CANCELLATION_FINAL_FREEZE_BLOCKED` if:

- exact profile literal cannot be frozen;
- current value fields are insufficient;
- current v1 helper behavior must change;
- C2A/B1/Capability source must change;
- status tests force a wider unexplained surface;
- bounded reconstruction/work cannot be proven;
- classification semantics remain ambiguous;
- the additive profile cannot remain private/no-I/O/no-caller.

OUTPUT

Print inline:

# Baseline and inspection boundary
# Accepted strategic decisions
# Corrections to prior reconnaissance
# Exact profile manifest and digest
# Classification value contract
# Exact relation signatures
# Safe reconstruction and work bounds
# Classifier matrix and precedence
# Status and authority contract
# Exact touched-file ceiling
# V1 protected surface
# Permanent test plan
# Independent audit plan
# Forecasts and stop conditions
# Recommendation
# Next implementation boundary

End with exactly one:

RW0_B2_CANCELLATION_FINAL_CONTRACT_FREEZE_READY

or

B2_CANCELLATION_FINAL_FREEZE_BLOCKED

Required final statements:

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
