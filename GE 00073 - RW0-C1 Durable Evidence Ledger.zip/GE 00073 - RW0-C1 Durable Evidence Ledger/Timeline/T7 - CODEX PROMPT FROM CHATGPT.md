PROMPT_ID

RW0_B2_CANCELLATION_CONTROL_IMPLEMENTATION_V1

TITLE

Coordinator RW0-B2 — implement the frozen additive exact-current-effect
cancellation-control evidence profile, relations, and classifier

ENGAGEMENT TYPE

Parent-only workspace-write implementation.

You are the sole writer. Do not create subagents.

This prompt continues directly from the immediately preceding accepted
read-only report:

```text
RW0_B2_CANCELLATION_FINAL_CONTRACT_FREEZE_READY
```

That report, including its complete 12,014-byte canonical manifest JSON,
12,154-byte outer identity, profile digest, relation signatures, work tariffs,
classification matrix, exact status line, test plan, protected symbols, and
11-file ceiling, is the governing implementation contract.

Do not reinterpret, regenerate, simplify, or expand that freeze. Any
contradiction discovered during implementation is a stop condition, not
permission to improvise.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED BASELINE

Before any write, require exactly:

```text
branch:
trunk_dev

HEAD:
dd12b23762dc761736e55a1abfde12dd3ec23551

parent:
deec37bf08fb903d8846aa2c3232aec52fa9866e

subject:
feat: implement RW0-B2 Capability semantics (#5)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

worktree/index/untracked/unmerged:
clean

Git operation/lock:
none
```

No fetch or remote contact is authorized.

After baseline verification, create and switch to exactly:

```text
codex/rw0-b2-cancellation-control-v1
```

The branch must start at the required HEAD. If it already exists locally or
remotely in a conflicting state, stop. Do not create another worktree.

OBJECTIVE

Implement one additive, private, pure, no-I/O Wire-owned cancellation-control
evidence contract that supports the exact current:

```text
author_candidate
validate_candidate
review_candidate
```

Preserve the complete current `rw0-wire-nwpf-v1` surface and all current
Capability, B1, C2A, persistence, runtime, package, and authority contracts.

This tranche unblocks later RW0-C design. It does not implement RW0-C.

AUTHORITATIVE FROZEN IDENTITIES

Existing NWPF v1, unchanged:

```text
schema:
governed-execution.nwp-rw0-wire-protocol-profile.v1

ref:
rw0-wire-nwpf-v1

digest:
470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454
```

New additive profile:

```text
schema:
governed-execution.nwp-rw0-wire-cancellation-control-profile.v1

ref:
rw0-wire-cancellation-control-v1

digest domain:
governed-execution.nwp-rw0-wire-cancellation-control-profile.v1.identity

canonical manifest bytes:
12014

canonical outer identity bytes:
12154

profile digest:
4d6f84552b852a4c4073b4238591afd271072f648424eca9e744def436165288
```

The complete canonical manifest JSON printed in the preceding freeze is an
exact test-owned and production-owned literal. Copy it exactly. Do not derive
the expected profile from production during testing.

CLASSIFICATION CONTRACT

Implement exactly:

```text
RW0WireCancellationControlClassificationV1

fields:
classification
reason

classification:
invalid | incomplete | finite
```

Exact coherence:

```text
invalid:
invalid_input
duplicate_fact
unrelated_fact
conflicting_fact
cancellation_graph_mismatch

incomplete:
process_evidence_incomplete
resource_limit_exceeded
deadline_elapsed
signal_delivered
cancellation_acknowledged
cancellation_request_pending

finite:
cancellation_rejected
target_process_exited
```

Required behavior:

- subclass the existing private Wire immutable-value base;
- exact ordered fields;
- exact built-in strings;
- private `_create`;
- ordinary construction disabled;
- final and slotted;
- immutable;
- noncopyable, non-deepcopyable, non-pickleable;
- exact class-name `repr` and `str`;
- fresh exact built-in mapping from `to_mapping`;
- no `from_mapping`;
- no schema/ref/digest/canonical identity/equality override;
- no hidden or nullable payload.

`finite` is only a supplied cancellation-control evidence state suitable for
later C2 reasoning. It is not semantic cancellation, success, teardown,
terminality, permission, or acceptance.

EXACT PUBLIC/PRIVATE FUNCTIONS

Implement exactly:

```text
cancellation_control_profile_mapping

validate_wire_exact_current_cancellation_request_relation

validate_wire_exact_current_process_observation_relation

validate_wire_exact_current_cancellation_response_relation

classify_wire_exact_current_cancellation_control
```

Use the exact signatures and parameter order from the accepted freeze.

Use `_C2A_MISSING` for the omitted capsule operand.

Reuse unchanged:

```text
RW0WireCancellationRequestObservationV1
RW0WireProcessObservationV1
```

Keep v1-only and unchanged:

```text
RW0WireWorkerResultV1
RW0WireProcessResultClassificationV1
classify_wire_process_result
```

TARGET/CAPSULE CONTRACT

For every relation and classifier:

```text
author_candidate:
target_capsule_manifest must be the exact omitted sentinel
target portable capsule digest is null
cancel portable capsule digest is null

validate_candidate:
exact safely reconstructed CandidateCapsuleManifestV1 required
target and cancellation portable capsule digests equal the manifest

review_candidate:
exact safely reconstructed CandidateCapsuleManifestV1 required
target and cancellation portable capsule digests equal the manifest
```

Explicit `None` is invalid when omission is required.

RELATION ORIENTATION

Freeze and implement exactly:

- Request:
  - validate target delivery against the target fence;
  - validate cancellation delivery against the cancellation fence and exact
    target;
  - bind request target coordinates to target fence/delivery;
  - bind request cancellation coordinates to cancellation fence/delivery;
  - direct-local cancellation delivery requires source `supervisor`;
  - ES cancellation delivery requires source `execution_substrate`.

- Process observation:
  - validate target delivery against the target fence;
  - bind the process observation to target fence/delivery;
  - source is exactly `supervisor | operating_system`;
  - event is exactly `resource_limit_exceeded | signal_delivered`.

- Acknowledgement/rejection:
  - first prove the complete request graph;
  - validate the WorkerObservation against cancellation fence/delivery and
    exact target;
  - direct-local cancellation delivery requires source
    `direct_local_adapter`;
  - ES cancellation delivery requires source `es_adapter`.

No request/response source ref or invocation-ref equality is inferred.
No timestamp ordering or source authenticity is inferred.

CLASSIFIER FACT GRAMMAR

Implement exactly:

```text
request:
0 or 1

adapter observations:
exact built-in tuple
0 to 4
roles:
cancellation_acknowledged
cancellation_rejected
deadline_elapsed
process_exited

process observations:
exact built-in tuple
0 to 2
roles:
resource_limit_exceeded
signal_delivered

total supplied facts:
0 to 7

every role:
singleton

acknowledgement + rejection:
conflict
```

Exact precedence:

1. malformed shape/cardinality/tampering/reconstruction/graph operand/work
   exhaustion → `invalid / invalid_input`
2. repeated original object identity, safe ref, or safe digest →
   `invalid / duplicate_fact`
3. admitted exact type but unrelated role or target →
   `invalid / unrelated_fact`
4. two distinct facts for one singleton role or acknowledgement plus rejection
   → `invalid / conflicting_fact`
5. request/response/target/cancellation/capsule orientation mismatch, including
   response without request →
   `invalid / cancellation_graph_mismatch`
6. no request →
   `incomplete / process_evidence_incomplete`
7. rejection →
   `finite / cancellation_rejected`
8. exact target process exit →
   `finite / target_process_exited`
9. resource limit →
   `incomplete / resource_limit_exceeded`
10. deadline →
    `incomplete / deadline_elapsed`
11. signal →
    `incomplete / signal_delivered`
12. acknowledgement →
    `incomplete / cancellation_acknowledged`
13. otherwise →
    `incomplete / cancellation_request_pending`

Required coexistence:

```text
rejection + exit:
finite / cancellation_rejected

acknowledgement + exit:
finite / target_process_exited

signal + exit:
finite / target_process_exited

resource limit + exit:
finite / target_process_exited

deadline + exit:
finite / target_process_exited

target process facts without request:
incomplete / process_evidence_incomplete

acknowledgement or rejection without request:
invalid / cancellation_graph_mismatch

request only:
incomplete / cancellation_request_pending

no facts:
incomplete / process_evidence_incomplete
```

Exit codes `-255`, `0`, and `255` are equally:

```text
finite / target_process_exited
```

Zero has no cancellation-success meaning.

SAFE RECONSTRUCTION

Modify the existing single relative C2A import statement only by adding:

```text
CandidateCapsuleManifestV1
_reconstruct_exact_worker_execution_value
```

Do not add a second relative import.

Do not change:

```text
_C2A_FIELD_INVENTORIES
_worker_execution_semantic_values.py
any C2A test
```

Use `_reconstruct_exact_worker_execution_value` only for the manifest and its
nested owner graph. Sanitize `WorkerExecutionValueError` at the Wire boundary.

Continue using the current Wire reconstruction paths for current Wire/C2A
values. Add one local cancellation-control work budget that charges the exact
fixed tariff before each supplied occurrence is reconstructed.

Each supplied occurrence is charged and reconstructed, including repeated
aliases. Duplicate classification happens after reconstruction.

Do not call the new public relation functions from the classifier or from one
another in a way that reconstructs common operands twice. Create private
validated-input helpers so that:

- each supplied occurrence is reconstructed exactly once;
- common target/cancellation graph validation is performed exactly once per
  public operation;
- the response relation proves the complete request graph without duplicate
  reconstruction;
- the classifier validates common graph operands once and performs only
  role-specific owner checks afterward.

WORK TARIFFS

Use exactly:

```text
RW0WireCancellationRequestObservationV1: 62
RW0WireProcessObservationV1:             54
WorkerCommandV1:                        116
AttemptFenceV1:                          92
EffectFenceV1:                          102
DeliveryEnvelopeV1:                      32
WorkerObservationV1:                    124
CandidateCapsuleManifestV1:              98
```

Exact operation limits:

```text
request:
author 640
validate/review 738

process:
author 498
validate/review 596

response:
author 764
validate/review 862

classifier:
author 1244
validate/review 1342
```

Maximum-valid evaluates normally.

Maximum-minus-one:

```text
relation:
content-free work_limit_exceeded

classifier:
invalid / invalid_input
```

Existing NWPF work caps, frame caps, profiles, identities, and tests remain
unchanged.

FAILURE BOUNDARY

Public relation precedence:

1. exact outer/type/omission preflight;
2. local work budget;
3. exact safe reconstruction and digest validation;
4. target class and capsule branch;
5. C2A owner relations;
6. Wire coordinate/source bindings.

Use existing content-free `RW0WireProtocolError` reasons:

```text
invalid_field_type
invalid_length_or_cardinality
invalid_field_value
work_limit_exceeded
relation_mismatch
```

Ordinary foreign exceptions are sanitized with no supplied payload, cause, or
context. `KeyboardInterrupt`, `SystemExit`, and `GeneratorExit` propagate.

PROFILE MAPPING

Implement the exact frozen profile literal and mapping behavior:

- fresh exact built-in outer dict;
- fresh complete manifest graph;
- exact outer key order:
  `schema_id`, `profile_ref`, `manifest`, `profile_digest`;
- exact profile digest;
- no profile bytes in NWPF frames;
- no public export;
- no production caller.

SOURCE LAYOUT AND V1 FREEZE

In:

```text
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
```

only these changes are allowed:

1. add the two frozen names to the existing C2A import statement;
2. append one self-contained cancellation-control block after the current
   `classify_wire_process_result`.

Every pre-existing v1 constant, class, function, relation, parser, codec,
profile literal, profile mapping, classifier, and source segment must remain
byte-for-byte unchanged.

Before editing, capture exact source segments for every protected symbol listed
in the preceding freeze. At closeout, compare those segments byte-for-byte.

All four existing Wire test files must remain byte-for-byte unchanged:

```text
tests/test_rw0_b2_wire_values.py
tests/test_rw0_b2_wire_relations.py
tests/test_rw0_b2_wire_codec.py
tests/test_rw0_b2_wire_boundaries.py
```

No existing B1, C2A, or Capability semantic test may change.

STATUS/DOCUMENT CONTRACT

Update the six authorized documents with the exact owner/status treatment from
the freeze.

The five synchronized status projections must each contain the exact single
physical status line printed in the preceding freeze, byte-identically.

Retain:

- marker uniqueness and adjacency;
- Capability status immediately after Wire where currently required;
- existing current-registry row structure;
- every existing phrase pinned by current tests;
- current v1 profile identity;
- C future/blocked posture;
- D/E/ES ownership;
- all no-I/O/no-authority/no-persistence/nonimplementation claims.

Do not add a new registry component row.

TOUCHED-FILE CEILING

Exactly these 11 files may change:

```text
.docs/rw0-b2-wire-protocol.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/worker-execution-boundary.md
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
tests/test_rw0_b2_wire_cancellation_control_values.py
tests/test_rw0_b2_wire_cancellation_control_relations.py
tests/test_rw0_b2_wire_cancellation_control_boundaries.py
tests/test_rw0_b2_capability_boundaries.py
```

Expected final topology:

```text
11 dirty paths
8 tracked modifications
3 untracked additions
0 staged
0 unmerged
all regular mode 0644
```

The Capability boundary file may change only the P01 expected byte size and
SHA-256 after final Wire source bytes are frozen.

Do not change P01 ID, path, order, contract classes, purpose, or any Capability
semantic assertion.

No twelfth path is authorized.

TEST-FIRST SEQUENCE

Use a fresh external evidence root:

```text
/private/tmp/rw0-b2-cancellation-control-implementation.XXXXXX
```

mode `0700`.

1. Record opening repository identity.
2. Run the exact provenance recipe twice against the clean baseline.
3. Collect opening nodes and require:
   - 5,059 unique nodes;
   - ordered SHA-256
     `72ca14d20ff8e95384a8fa06b595227fb45bb7884aac295bbe4ae06ac761a0aa`.
4. Create the six doc edits and three new test modules first, without production
   source changes.
5. The new tests must import the existing Wire module alias and access new
   symbols at test execution, so test-first evidence consists of collected
   causal failures—not collection/import errors.
6. Run one selected red gate across the new modules.
7. Require only missing-contract failures attributable to the absent additive
   implementation. No fixture, path, environment, or unrelated failure is
   creditable.
8. Implement the Wire source.
9. When source bytes are final, update exactly the P01 size and SHA-256.
10. Do not weaken a test to obtain green.

PERMANENT TEST PLAN

Implement exactly the named test purposes from the freeze.

New values module:

```text
test_profile_literal_canonical_bytes_length_and_digest_are_exact
test_profile_mapping_has_exact_order_and_returns_fresh_builtin_dicts
test_classification_value_has_exact_fields_and_result_reason_matrix
test_classification_value_is_final_slotted_immutable_noncopyable_and_nonpickleable
test_existing_request_and_process_values_remain_golden_compatible
test_existing_nwpf_profile_and_frame_vectors_are_unchanged
test_profile_declares_exact_fact_cardinality_and_work_tariffs
```

New relations module:

```text
test_request_relation_accepts_complete_target_and_route_matrix
test_process_relation_accepts_complete_target_event_source_matrix
test_response_relation_accepts_acknowledgement_and_rejection_matrix
test_capsule_branch_is_exact
test_request_source_is_bound_only_to_cancellation_delivery_route
test_target_cancel_swaps_cross_attempts_and_sibling_graphs_fail
test_timestamp_order_is_not_semantics
test_relation_failures_are_content_free_and_process_control_propagates
test_relation_work_maxima_and_one_under_controls_are_exact
```

New boundaries module:

```text
test_classifier_complete_precedence_and_coexistence_matrix
test_duplicates_precede_unrelated_conflict_and_graph_mismatch
test_singleton_conflicts_and_ack_reject_exclusion_are_exact
test_request_response_and_target_process_dependence_is_exact
test_every_outer_and_cardinality_boundary_is_exact
test_exit_codes_minus_255_zero_and_255_are_equally_finite
test_hostile_manifest_reconstruction_cycles_aliases_and_large_integers_fail_bounded
test_classifier_privacy_and_foreign_exception_sanitization_are_exact
test_module_remains_private_no_export_no_caller_and_no_io
test_five_status_projections_and_owner_contract_are_synchronized
test_capability_b1_and_c2a_identifiers_do_not_churn
test_capability_p01_row_matches_final_wire_identity
```

Parameterize where it strengthens finite matrix coverage, but do not add
placeholder volume.

Expected profile JSON, byte lengths, digest, relation matrices, work tariffs,
and precedence must be independent test-owned literals, never imported from
production as the expected oracle.

Add ordinary causal controls proving:

- exact target class/capsule branch is reached;
- every supplied occurrence is reconstructed;
- common operands are not silently read from originals after reconstruction;
- selected and class-wide reconstruction bypass mutants fail;
- owner C2A relations are actually invoked;
- work maxima are operation-level and mutant-sensitive.

Do not create self-protecting source/AST/code/evidence tests.

VALIDATION

Use serial pytest with:

```text
umask 022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
unique external PYTHONPYCACHEPREFIX
unique external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
GIT_OPTIONAL_LOCKS=0
python3 -B -m pytest -p no:cacheprovider -W error
unique external --basetemp
unique external --junitxml
```

Retain stdout, stderr, JUnit, exact command, environment, return code, test
counts, and repository pre/post fingerprints for credited final runs.

Run final validation in this order:

1. new values module;
2. new relations module;
3. new boundaries module;
4. all three new modules;
5. unchanged existing Wire v1 modules:
   - values;
   - relations;
   - codec;
   - boundaries;
6. C2A compatibility:
   - worker-execution semantic values;
   - vectors;
   - relations;
   - boundaries;
   - C2A relations;
   - C2A effects and recovery;
7. B1 compatibility:
   - phase values;
   - vectors;
   - relations;
   - boundaries;
8. Capability compatibility:
   - values;
   - vectors;
   - relations;
   - boundaries;
9. status/architecture/runtime compatibility:
   - remote-contact phase entry;
   - architecture contracts;
   - software-development progression boundary;
   - runtime non-authority;
   - C2A nonimplementation;
10. `git diff --check`;
11. exact path/type/mode/protected-symbol guards;
12. final node collection;
13. complete suite exactly once.

NODE IDENTITY

Require:

- every opening 5,059 node remains in identical relative order;
- no opening node is removed or renamed;
- all additions belong only to the three new test modules;
- no existing test file adds, removes, or renames a node;
- no skips or xfails are introduced.

Do not predeclare the final node count. Derive and report it exactly.

FULL SUITE

After every focused gate is green, run the complete suite exactly once.

Require:

```text
return code 0
all collected tests passed
0 failures
0 errors
0 skipped
0 xfailed
0 xpassed
0 warnings
empty stderr
parseable JUnit
zero duplicate or unmapped cases
candidate fingerprint unchanged
```

No second official complete-suite attempt is authorized. If an environment or
wrapper issue prevents a valid attempt before pytest runs, preserve it and stop
rather than creating an evidence-harness cycle.

PROVENANCE

Use the supplied exact recipe file:

```text
governed_execution_audit_patch_manifest_v1.py

size:
3945 bytes

SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

Copy it to the external evidence root as mode `0400`.

At closeout:

1. remove only implementation-created transients;
2. require exact 11-path topology;
3. require every path outside the ceiling equals HEAD;
4. require old Wire test files and protected semantic-owner files unchanged;
5. require protected v1 source segments unchanged;
6. run the exact recipe twice with safe sink redirection;
7. require byte-identical manifests and complete outputs;
8. retain the complete canonical manifest JSON;
9. retain final node list and validation summary;
10. keep evidence simple:
    - directories mode `0700`;
    - regular evidence files mode `0400`;
    - no symlink/special entry;
    - one self-excluding index.

Do not attempt to record or recursively validate every exploratory shell
command. Validation and provenance evidence are projections, not product
authority.

NON-GOALS

Do not implement or modify:

- SQLite or any durable state;
- RW0-C, RW0-D, or RW0-E;
- transport or frame format;
- process launch/control;
- signal delivery;
- source authentication;
- provider/session behavior;
- credentials;
- public exports;
- production callers;
- Capability identities or semantics;
- B1 identities or semantics;
- C2A identities or semantics;
- NWPF v1 identities or semantics;
- package dependencies;
- schemas or migrations;
- StateStore or WriterSession;
- Bridge or Execution Substrate.

STOP CONDITIONS

Stop without ordinary repair and report `ARCHITECTURAL_REPLAN_REQUIRED` if:

- the frozen profile literal/digest cannot be reproduced;
- request/process fields are insufficient;
- any existing v1 symbol or test must change;
- C2A, B1, Capability, package, dependency, schema, migration, store, or runtime
  source must change;
- a twelfth path is required;
- the exact status contract cannot pass without changing an existing status
  test;
- bounded reconstruction/work cannot be implemented as frozen;
- classification meaning becomes ambiguous;
- a production caller, public export, I/O, persistence, transport, process
  control, or runtime authority is needed.

Stop with `BASELINE_MISMATCH` if the opening repository identity differs.

Do not stage, commit, push, create a PR, merge, tag, release, or deploy.

FINAL INLINE REPORT

Print the complete operative report inline. Do not put the core response only in
an evidence file.

Use:

```text
# Outcome
# Opening and closing identity
# Frozen contract implemented
# Exact 11-path delta
# V1 preservation
# Profile identity
# Relations and classifier
# Reconstruction and work bounds
# Test-first evidence
# Focused validation
# Node identity
# Complete-suite validation
# Provenance and canonical manifest
# Authority and remaining seams
# Confidence
```

Report:

- exact touched files;
- exact source size/hash and final P01 values;
- exact profile bytes/digest;
- test commands/results;
- all failed/superseded attempts;
- final node count/hash and additions;
- complete-suite result;
- recipe/manifests/diff hashes;
- assumptions and skipped validation;
- any authority/security widening, expected to be none.

Required success token:

```text
COORDINATOR_RW0_B2_CANCELLATION_CONTROL_IMPLEMENTED_READY_FOR_INDEPENDENT_AUDIT
```

Required final statements:

```text
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
PERSISTENCE_NOT_IMPLEMENTED
TRANSPORT_NOT_IMPLEMENTED
PROCESS_CONTROL_NOT_IMPLEMENTED
RW0_C_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
```
