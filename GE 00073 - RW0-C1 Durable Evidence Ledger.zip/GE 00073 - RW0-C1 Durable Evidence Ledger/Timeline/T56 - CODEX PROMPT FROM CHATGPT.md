PROMPT_ID

RW0_C1_PR7_SQUASH_MERGE_AND_CLOSEOUT_GATE_V1

TITLE

Coordinator RW0-C1 — squash-merge accepted PR #7 exactly once, verify the
published tree and policy transition, synchronize local trunk_dev, and run one
bounded post-merge validation

ENGAGEMENT TYPE

Authorized merge and closeout gate in the existing RW0-C1 implementation
conversation.

This prompt authorizes only:

1. exact retained-evidence, local, remote, PR, and policy preflight;
2. one squash-merge attempt for PR #7 with exact head matching;
3. mechanical verification of the resulting GitHub squash commit and all 81
   accepted blobs/modes;
4. one narrow fetch of base and feature refs;
5. local switch to `trunk_dev` and fast-forward-only synchronization;
6. one bounded post-merge focused pytest invocation;
7. final closeout and evidence sealing.

This prompt does NOT authorize:

- implementation repair or any repository-content edit;
- a direct push to `trunk_dev`;
- a second merge attempt;
- merge commit or rebase merge;
- force push, amend, reset, rebase, cherry-pick, or local feature merge;
- review, approval, comment, requested reviewer, or thread-resolution actions;
- auto-merge;
- feature-branch deletion;
- tag, release, deployment, or publication;
- RW0-C2, RW0-D, RW0-E, Execution Substrate, Bridge, worker, provider,
  process, runtime, or supporting-repository work.

Do not delegate to subagents.

Print the complete substantive result inline. Evidence paths may be
supplementary only.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

GITHUB REPOSITORY

evo-agi/Governed-Execution-Coordinator

PULL REQUEST

7

REQUIRED OPENING LOCAL IDENTITY

physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-c1-durable-evidence-v1

HEAD:
8f2a1be42b2e50f0cad16a334d333b7f2a87e47f

tree:
d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0

sole parent:
047563de5a443b0f8323401c92979ae2e444d2ed

subject:
feat: implement RW0-C1 durable evidence

body:
empty

upstream:
origin/codex/rw0-c1-durable-evidence-v1

ahead/behind:
0/0

worktrees:
1

worktree/index:
clean

Git operations/locks/residue:
none

If the opening local identity differs, stop before any merge effect:

RW0_C1_MERGE_GATE_LOCAL_BASELINE_MISMATCH

ACCEPTED FEATURE IDENTITY

feature branch:
codex/rw0-c1-durable-evidence-v1

feature commit:
8f2a1be42b2e50f0cad16a334d333b7f2a87e47f

feature tree:
d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0

feature sole parent:
047563de5a443b0f8323401c92979ae2e444d2ed

feature commit subject:
feat: implement RW0-C1 durable evidence

feature commit body:
empty

feature commit signature:
unsigned

feature shape:
64 modifications
17 additions
81 files
0 deletions
0 renames
0 copies
0 mode changes
all modes 100644

Unsigned feature-commit posture is accepted: the active target policy does not
require signed feature commits. The GitHub squash commit must be verified by
GitHub after merge.

ACCEPTED VALIDATION

Independent acceptance token:

COORDINATOR_RW0_C1_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE

Commit/PR gate token:

COORDINATOR_RW0_C1_COMMITTED_PUSHED_AND_PR_OPENED

Accepted nodes:

5205

Accepted ordered node SHA-256:

c54742289bcb5e569cef4f7ce5df88197f60c020226fa0dc9cefb1bfd7ac7218

Accepted validation:

- final independent live complete suite: 5205 passed;
- final independent external clean complete suite: 5205 passed;
- staged commit-gate collection: 5205 nodes;
- staged commit-gate complete suite: 5205 passed;
- exact staged tree equals the feature tree.

RETAINED ACCEPTANCE EVIDENCE

Final independent audit root:

/private/tmp/ge-coordinator-rw0-c1-final-acceptance-reaudit.LA8igO

Final independent audit index SHA-256:

ca5c9c41c71685472e6f8d71971137173df7576077f910191ab94c6578cad640

Final repair root:

/private/tmp/ge-coordinator-rw0-c1-final-handoff-repair.nYKeMi

Final repair index SHA-256:

cf35d96176726094dd0b04d33edcb74cc6fea4de9525def4c800bbe66806e07f

Commit/PR gate root:

/private/tmp/ge-coordinator-rw0-c1-commit-gate.HjA7Fu

Commit/PR gate index SHA-256:

b21dddc902d2f5980235d2cc91449021c0c94e710984b4ff13bece823cabe184

Verify all three roots and indexes read-only before merge and again at closeout.
Do not modify, clean, re-index, normalize, or write into them.

LIVE STATE ALREADY OBSERVED BY THE COGNITIVE LEAD

Treat these as expectations to reverify immediately before merge, not as a
substitute for your own live preflight.

PR #7:

- open;
- non-draft;
- unmerged;
- mergeable;
- title exactly `feat: implement RW0-C1 durable evidence`;
- body byte-identical to the accepted commit-gate body;
- base `trunk_dev`;
- base OID `047563de5a443b0f8323401c92979ae2e444d2ed`;
- head `codex/rw0-c1-durable-evidence-v1`;
- head OID `8f2a1be42b2e50f0cad16a334d333b7f2a87e47f`;
- one commit;
- 81 changed files;
- requested reviewers and teams: none;
- reviews: none;
- review threads: none;
- issue/review comments: none;
- workflow runs: none;
- check runs: none;
- commit status contexts: none;
- combined status may report synthetic `pending` with total count zero.

Remote `trunk_dev`:

047563de5a443b0f8323401c92979ae2e444d2ed

Active ruleset:

id:
18957283

name:
trunk_dev

target:
refs/heads/trunk_dev

enforcement:
active

requirements:

- pull-request flow;
- allowed merge method: squash only;
- required approvals: 0;
- required status checks: 0;
- review-thread resolution required;
- extra approval for unattributed changes required;
- bypass actors: none;
- current user bypass: never.

Repository settings:

- squash merge enabled;
- auto-merge disabled;
- automatic branch deletion disabled.

REMOTE AND POLICY PREFLIGHT

Remote contact is authorized only for this merge/closeout gate.

1. Verify authenticated GitHub identity and exact origin:

```text
git@github.com:evo-agi/Governed-Execution-Coordinator.git
```

2. Narrowly fetch or query only:

- `refs/heads/trunk_dev`;
- `refs/heads/codex/rw0-c1-durable-evidence-v1`.

Use `--no-tags` and do not alter local branch state during preflight.

3. Require:

```text
remote trunk_dev:
047563de5a443b0f8323401c92979ae2e444d2ed

remote feature:
8f2a1be42b2e50f0cad16a334d333b7f2a87e47f
```

4. Fetch and verify the live PR, timeline, comments, reviews, review requests,
review threads, check runs, workflow runs, status contexts, repository settings,
and applicable ruleset.

Require all expected values above and no new review, requested change, comment,
thread, check, workflow, status context, auto-merge, or head/base movement.

5. Verify the feature commit mechanically:

- exact OID/tree/parent/subject/body;
- one commit from accepted base;
- exact 81-file shape;
- all modes 100644;
- no unexpected blob or path.

6. Reverify all three retained evidence indexes and the accepted candidate
manifest/tree identities.

If any base/head/PR/policy/evidence/feature identity differs, stop without
merging:

RW0_C1_MERGE_GATE_PREFLIGHT_MISMATCH

MATERIALITY RULE

Keep merge-gate evidence proportionate.

A harmless read-only parser, reporting, temp-path, or diagnostic correction
that changes no repository byte, GitHub effect, merge result, validation
result, or retained evidence identity is an Observation, not a reason to repeat
an irreversible action.

Never repeat the merge, fetch/sync mutation, or focused pytest merely to repair
reporting metadata. Inspect resulting state first and treat the exact resulting
state as authoritative.

IMMEDIATE PRE-MERGE SNAPSHOT

Immediately before the merge command, repeat the state-sensitive checks:

- PR open/non-draft/unmerged/mergeable;
- exact base/head OIDs;
- exact title/body;
- one commit and 81 files;
- no reviews/review requests/requested changes;
- no review threads/comments;
- no workflows/checks/status contexts;
- no auto-merge;
- remote base and feature unchanged;
- local feature exact and clean;
- evidence indexes unchanged.

If any state changed, stop:

RW0_C1_IMMEDIATE_PREMERGE_MISMATCH

MERGE

Execute exactly one merge command:

```text
gh pr merge 7 \
  --repo evo-agi/Governed-Execution-Coordinator \
  --squash \
  --match-head-commit 8f2a1be42b2e50f0cad16a334d333b7f2a87e47f \
  --subject "feat: implement RW0-C1 durable evidence (#7)" \
  --body ""
```

Do not use the GitHub connector merge action in addition to the CLI command.
Do not issue a second merge attempt.

Record:

- exact argv;
- cwd;
- environment and umask;
- start/end timestamps;
- return code;
- stdout/stderr;
- source repository and remote pre/post observations.

If the command returns nonzero or uncertain, inspect PR state, timeline, remote
base, and merge commit before any action.

- If PR #7 is already merged exactly once to a squash commit satisfying every
  requirement below, treat the merge as completed and do not retry.
- Otherwise stop:

RW0_C1_MERGE_COMMAND_FAILED

VERIFY THE SQUASH COMMIT

Require the resulting GitHub squash commit to have:

```text
tree:
d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0

sole parent:
047563de5a443b0f8323401c92979ae2e444d2ed

subject:
feat: implement RW0-C1 durable evidence (#7)

body:
empty
```

Require:

- GitHub signature verified;
- verification reason `valid`;
- feature commit is not a parent;
- exactly one PR merge event references the squash OID;
- PR state closed and merged;
- PR merge commit equals the squash OID;
- base advanced by exactly one commit;
- comparison from accepted base is ahead 1 / behind 0 / one commit;
- exactly 81 changed paths;
- exactly 64 modifications and 17 additions;
- no deletions, renames, copies, or mode changes;
- all modes 100644;
- every squash-commit blob equals the accepted feature-tree blob at the same
  path;
- every unchanged path equals the accepted base.

Retain the exact per-path status, mode, blob OID, size, and SHA-256 comparison.

If the merge exists but any mechanical identity differs, do not attempt to
repair or repeat it. Stop:

RW0_C1_MERGED_TREE_MISMATCH

REMOTE TRANSITION

Require:

```text
remote trunk_dev:
047563de5a443b0f8323401c92979ae2e444d2ed
→ <exact squash OID>

remote feature:
8f2a1be42b2e50f0cad16a334d333b7f2a87e47f
→ 8f2a1be42b2e50f0cad16a334d333b7f2a87e47f
```

The feature branch must remain present.

LOCAL SYNCHRONIZATION

Only after the squash commit and remote transition are fully verified:

1. Run exactly one narrow no-tags fetch of the base and feature refs:

```text
git fetch --no-tags --no-write-fetch-head origin \
  +refs/heads/trunk_dev:refs/remotes/origin/trunk_dev \
  +refs/heads/codex/rw0-c1-durable-evidence-v1:refs/remotes/origin/codex/rw0-c1-durable-evidence-v1
```

2. Switch locally:

```text
git switch trunk_dev
```

3. Fast-forward only:

```text
git merge --ff-only origin/trunk_dev
```

Do not reset, rebase, cherry-pick, or merge the local feature branch.

Require final local state:

- branch `trunk_dev`;
- local HEAD equals exact squash OID;
- upstream `origin/trunk_dev`;
- divergence `0/0`;
- local and remote-tracking feature refs remain at the accepted feature OID;
- worktree/index clean;
- one worktree;
- no Git operation or lock.

If local fast-forward fails, preserve the already completed remote merge and
stop without destructive repair:

RW0_C1_LOCAL_SYNC_FAILED

POST-MERGE FOCUSED VALIDATION

Run exactly one pytest invocation after local synchronization.

Use one new private evidence root:

/private/tmp/ge-coordinator-rw0-c1-merge-gate.XXXXXX

Use:

umask 0022
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
unique evidence-root PYTHONPYCACHEPREFIX
distinct evidence-root TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
GIT_OPTIONAL_LOCKS=0
python3 -B
-p no:cacheprovider
-W error

Use external basetemp, JUnit, stdout, stderr, cache, and temp paths.

Run these exact 42 test files in one serial invocation:

```text
tests/test_architecture_contracts.py
tests/test_autonomous_software_development_operating_model.py
tests/test_b2a_writer_session_contract.py
tests/test_b3_coherent_transition_fixture.py
tests/test_b3a_persistence_contracts.py
tests/test_b3b1_pure_row_contracts.py
tests/test_b3b2b_select_readers.py
tests/test_b3b_reader_prerequisite_contracts.py
tests/test_b3c0a_transition_authority_contract.py
tests/test_b3c0b_transition_event_replay_contracts.py
tests/test_b3c1_prerequisite_contract.py
tests/test_b3c1b_rollback_only_writer_fencing.py
tests/test_b3c3_prerequisite_contract.py
tests/test_b3c4c_prerequisite_contract.py
tests/test_b4c_public_global_stop_delegation.py
tests/test_c2a_nonimplementation.py
tests/test_c2b0_durable_state_contract.py
tests/test_c2b2_development_reader_contracts.py
tests/test_c2b3c_author_effect_contract.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_runtime_non_authority.py
tests/test_rw0_b1_boundaries.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_rw0_c1_mutation_contracts.py
tests/test_rw0_c1_private_atomic_persistence.py
tests/test_rw0_c1_private_readers.py
tests/test_rw0_c1_reader_contracts.py
tests/test_rw0_c1_recovery.py
tests/test_rw0_c1_row_values.py
tests/test_rw0_c1_semantic_values.py
tests/test_rw0_c1_writer_session_delegation.py
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_software_development_progression_boundary.py
tests/test_sqlite_b1_migrations.py
tests/test_sqlite_b2c_writer_session.py
tests/test_sqlite_backend_b0_contract.py
tests/test_sqlite_c2b1_migration_framework.py
tests/test_sqlite_c2b2_migration_0002.py
tests/test_sqlite_rw0_c1_migration_0004.py
tests/test_sqlite_section41_migration_0003.py
tests/test_worker_execution_semantic_boundaries.py
```

Require:

- return code 0;
- every collected case passed;
- zero failures/errors/skips/xfails/xpasses/warnings;
- empty stderr;
- parseable JUnit;
- zero duplicate or unmapped cases;
- caller/child umask 0022;
- local HEAD/ref/index/tree/filesystem inventory unchanged before/after;
- all pytest-visible absolute temporary paths pass repository privacy/path
  screening.

Do not rerun the full 5205-test suite. It already passed at the independently
accepted live and clean states and again at the exact staged commit gate. This
merge gate verifies publication/synchronization plus bounded integration, not a
fourth full-suite authority layer.

No second focused pytest invocation is authorized.

If the focused run fails:

- preserve evidence;
- do not repair source;
- do not retry;
- report the already completed remote/local merge truth;
- return:

RW0_C1_POST_MERGE_FOCUSED_VALIDATION_FAILED

FINAL GUARDS

After validation, reverify:

- PR #7 merged exactly once;
- exact squash OID/tree/parent/subject/body/signature;
- exact 81-path blob/mode manifest;
- remote and local `trunk_dev` equal the squash OID;
- local and remote feature refs retained at
  `8f2a1be42b2e50f0cad16a334d333b7f2a87e47f`;
- feature divergence `0/0`;
- worktree/index clean;
- one worktree;
- no locks or Git operations;
- no repository cache, bytecode, database, journal, archive, build output,
  generated manifest, recorder residue, or transient validation path;
- no reviews, approvals, comments, requested reviewers, or thread-resolution
  effects created by this gate;
- no check/workflow/status context appeared unexpectedly;
- no auto-merge;
- no feature-branch deletion;
- no tag, release, deployment, or other publication;
- all retained acceptance, repair, and commit-gate evidence indexes unchanged;
- merge command executed at most once;
- focused pytest invoked exactly once.

MATERIALITY AT CLOSEOUT

If a read-only verifier, parser, or report generator is corrected after the
irreversible merge:

- do not repeat the merge, fetch/sync, or pytest;
- preserve the superseded attempt;
- prove candidate, remote, local, PR, and retained evidence identities are
  unchanged;
- classify it as an audit-harness/report Observation unless it materially
  affects the conclusion.

EVIDENCE AND CLEANUP

Retain proportionate merge-gate evidence:

- opening local identity;
- retained-index verification;
- live PR/policy preflight;
- immediate pre-merge snapshot;
- merge command envelope;
- PR timeline and merge event;
- exact squash-commit verification;
- per-path blob/mode comparison;
- remote transition;
- local synchronization;
- focused pytest stdout/stderr/JUnit/summary;
- final guards;
- cleanup;
- final inline report.

Remove only merge-gate-created external basetemp, tmp, cache, pycache, and any
disposable verification checkout/object database.

Do not move transient paths to macOS Trash; delete only the exact gate-owned
transient paths after inventorying them.

Seal the merge-gate evidence root:

- root/directories mode 0700;
- retained files mode 0400;
- no symlink or special entry;
- self-excluding evidence index created last;
- independently reverify exact path/type/UID/mode/size/SHA equality.

SUCCESS TOKEN

Return exactly:

COORDINATOR_RW0_C1_MERGED_VERIFIED_SYNCHRONIZED_AND_FOCUSED_VALIDATED

only when:

- PR #7 was squash-merged exactly once;
- the squash commit exactly equals the accepted feature tree over the accepted
  base;
- remote and local `trunk_dev` are synchronized;
- feature refs remain present;
- the one focused validation invocation passed;
- final guards and evidence sealing are complete.

FINAL INLINE REPORT

Use:

# Outcome
# Accepted identities and retained evidence
# Opening local identity
# Live PR and policy preflight
# Merge command
# Verified squash commit
# Per-path blob and mode verification
# Remote transition
# Local synchronization
# Focused validation
# Final guards
# Evidence index
# Limitations and confidence

Required final statements:

IMPLEMENTATION_REPAIR_NOT_PERFORMED
DIRECT_TRUNK_PUSH_NOT_PERFORMED
BYPASS_NOT_USED
FORCE_PUSH_NOT_PERFORMED
AMEND_NOT_PERFORMED
REBASE_NOT_PERFORMED
SECOND_MERGE_ATTEMPT_NOT_PERFORMED
AUTO_MERGE_NOT_ENABLED
REVIEW_NOT_SUBMITTED
THREAD_NOT_RESOLVED
FEATURE_BRANCH_NOT_DELETED
TAG_NOT_CREATED
RELEASE_NOT_CREATED
DEPLOYMENT_NOT_PERFORMED
RW0_C2_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
FOCUSED_VALIDATION_RUN_EXACTLY_ONCE
