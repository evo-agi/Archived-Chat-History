# Disposition

**Do not begin RW0-C1 implementation yet.**

The latest response successfully closes the five issues from the prior pass:

- membership has a stable phase-specific `membership_ref` and digest;
- C1-evidence relation operands bind exact same-phase memberships;
- rank 14 covers `present`, `finite_failure`, and `absent`;
- member relations are capped at two, with `LIMIT 3`;
- the existing `_CoordinatorMutationTransactionController` remains the sole transaction authority;
- the causal allowlist was revised to 81 paths.

Those decisions are accepted. The overall C1/C2 architecture remains sound.

However, two connected proof-model gaps remain. The correct terminal classification is still:

```text
RW0_C1_FREEZE_RECONCILIATION_REQUIRED
```

—not architectural replan.

## 1. Phase establishment has no inspectable durable relation proof

The intended C1 result must let a fresh reader establish not merely that a phase row exists, but that its exact B1 owner relation was checked against:

- lineage;
- selected proposal and artifact;
- selection result and head;
- transient full WorkSpec;
- attempt and author-effect fences;
- author command and delivery;
- effect and delivery heads;
- global stop.

The latest contract says that phase establishment is **not** represented in `rw0_relation_bindings`, while the phase row carries only relation/graph digests. That leaves no durable row containing:

```text
relation schema and version
proof mode
ordered operand closure
transient WorkSpec binding
```

A `relation_set_digest` alone is opaque—it cannot support guarded readback, exact replay-family verification, or `committed_exact` recovery.

The clean correction is to reuse the existing relation tables with a closed subject branch:

```text
subject_type:
phase_establishment | evidence_membership
```

For `phase_establishment`, the membership/value columns are null, the phase pair is the subject, `relation_rank=0`, and the row has an exact FK to `rw0_phase_instances`.

For `evidence_membership`, the full membership/value identity and same-phase composite FK remain mandatory.

This preserves the 23-table design while making phase establishment an inspectable immutable proof rather than a digest-only assertion.

## 2. The operand vocabulary cannot represent all accepted transient inputs

The latest operand branches cover:

```text
c1_evidence
existing_owner_row
transient_safe_manifest_binding
```

But accepted owner relations also require:

- **phase establishment:** full transient `WorkSpecV1`;
- **rank 1:** optional full capsule manifest;
- **rank 3:** transient WorkSpec branch;
- **rank 12 capsule observations:** full manifest plus `before_blobs` and `after_blobs`;
- **rank 14 finite failure:** an actual sealed `RW0WireProtocolError`.

These raw objects must remain outside SQLite, but their admission-time use must still be represented by an ordered, privacy-safe semantic binding. The command digest alone is not a substitute for an inspectable relation operand closure.

The final model needs one closed general branch:

```text
operand_source = transient_private_binding
```

with exact binding kinds:

```text
work_spec
candidate_capsule_manifest
before_blob_set
after_blob_set
wire_protocol_error
```

The durable shape should contain only:

```text
binding schema
semantic ref
aggregate semantic digest
optional safe scope digest
```

It must not store:

- WorkSpec requirements, exclusions, or path lists;
- capsule entries or file metadata;
- blob-map keys, per-file digests, lengths, or bytes;
- exception objects, traceback, cause, context, or arbitrary messages.

This also requires proof-mode branches to be precise:

```text
phase establishment:
relation_attested_at_admission

rank 1:
recomputable without a transient manifest;
attested when a manifest is required

rank 3:
existing_owner_row_reconstructed or attested with transient WorkSpec

rank 12:
recomputable only when no transient manifest/blob map is needed;
otherwise attested

rank 14:
present/absent recomputable;
finite_failure attested
```

## What remains frozen

Do not reopen:

```text
C1/C2 decomposition
15 evidence kinds
single-member admission
stable membership identity
same-phase relation FKs
rank-14 present/failure/absence algebra
maximum two member relations
phase_basis_ref / phase_basis_digest naming
one transaction controller
kind-scoped evidence identity
safe capsule binding only
C2 transient manifest recomputation
no C2 state in migration 0004
```

The likely final physical totals remain:

```text
migration 0004:
23 tables
46 immutability triggers
4 explicit indexes

cumulative:
62 tables
110 triggers
5 explicit indexes
```

The current 81-path allowlist should also remain sufficient unless the final repository search identifies a direct causal consumer of the phase-subject or transient-binding vocabulary.

# Final closure handoff

Send this prompt to the same read-only Coordinator conversation:

:chatgpt-content-reference{index="1"}

```text
Filename:
Coordinator_RW0_C1_Phase_Proof_and_Transient_Operand_Closure_Prompt.txt

Size:
14,646 bytes

SHA-256:
be256b02e87deec8fbd44918172f5311c4cf46fc3e1a5166d9ca1b19a33bbad8
```

The successful result remains:

```text
RW0_C1_IMPLEMENTATION_CONTRACT_READY
```

Only after that response should we issue the workspace-write implementation prompt.

### Sources

- Current merged Coordinator snapshot, uploaded as the repository baseline. 
- Codex’s latest C1 durable-identity and transaction-authority response supplied inline.
- `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`, especially `validate_phase_entry_basis` and `validate_authority_observation`.
- `src/ge_nwp_coordinator/_worker_execution_semantic_values.py`, especially `validate_observation_relation`.
- `src/ge_nwp_coordinator/_rw0_wire_protocol_values.py`, especially `classify_wire_process_result`.
- `src/ge_nwp_coordinator/sqlite_transition_transaction.py` and `sqlite_transition_select_support.py`.

**Confidence:** High that the C1 architecture is sound; high that these two gaps are implementation-blocking proof-representation defects rather than architectural contradictions; high that one final narrow reconciliation can close them without expanding the table family or product scope.

Some older Project uploads have expired. The current merged Coordinator snapshot is sufficient for this decision; an older artifact only needs re-uploading if a later task specifically depends on it.
