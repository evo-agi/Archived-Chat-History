# Decision

**Do not issue the RW0-C1 implementation prompt yet.**

The phase architecture is accepted, but the response does not yet constitute an implementation-ready contract freeze. I would reclassify its terminal result as:

```text
RW0_C1_FREEZE_RECONCILIATION_REQUIRED
```

—not `RW0_C_ARCHITECTURAL_REPLAN_REQUIRED`.

The C1/C2 decomposition remains sound. The unresolved issues are narrower: evidence-admission dependency closure, exact C1-owned schemas, and a causal touched-file boundary.

## What is accepted

The following decisions should carry forward unchanged:

- C1 is independently useful as a private, durable, no-contact phase and evidence-membership capability.
- C1 has no completeness, decision, terminal, latch, permission, or authenticity authority.
- The phase basis—not a new mutable head—is the phase identity.
- Membership is typed and immutable.
- Decision-basis and terminal-basis closures remain C2-owned and distinct.
- The cancellation-control classifier is recomputed by C2 and is not a sixteenth C1 member.
- Migration `0004` must be additive, generation 2, non-destructive, and contain no C2 state.
- A typed common registry plus kind-specific payloads is preferable to generic JSON/BLOB evidence.
- Receipt-first replay, one commit attempt, and three-way recovery remain the correct transaction model.
- No B1, B2, C2A, C2B, Section 41, package, public, or runtime owner change is needed.

The proposed 23-table direction is plausible. Six common tables, fifteen typed payload tables, and two normalized child tables can be justified by typed privacy, generic membership, variable relation operands, and precise recovery. It should not be reduced merely to lower the table count.

## What still blocks implementation

### 1. The admission dependency graph is not frozen

The response assigns multi-value relations to individual evidence kinds without requiring the other evidence operands to exist durably.

That produces several ambiguous or misleading states.

#### Host readiness and host qualification

`validate_host_qualification(...)` consumes the phase basis, authority observation, readiness observation, host qualification, current effect fence, and time. Readiness by itself is not a host qualification. (`src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py:1977-2162`)

The current freeze says kinds 5 and 6 participate in `validate_host_qualification`, but it does not state whether:

- readiness admission is standalone structural evidence;
- qualification admission requires an already admitted readiness member;
- the authority observation must already be admitted under the same phase;
- a transient, unadmitted qualification may be used to “prove” readiness.

The last interpretation would be incorrect.

#### Capability declaration, observation, and qualification

`validate_worker_mechanism_capability_qualification(...)` consumes:

- declaration;
- observation;
- qualification;
- phase basis;
- authority observation;
- readiness observation;
- host qualification;
- current effect fence;
- evaluation time.

It does not separately qualify a declaration or observation. (`src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py:884-1007`)

Kinds 7 and 8 should therefore not acquire a durable “Capability qualification passed” binding merely because transient qualification operands were supplied during their admission. The likely dependency is:

```text
declaration:
standalone supplied claim

observation:
standalone supplied claim that names the declaration

qualification:
requires admitted declaration + observation
and admitted B1 authority/readiness/host-qualification evidence
```

That must be explicit.

#### Retrieval sequences

`validate_retrieval_event_sequence(...)` validates one to three ordered events as a complete prefix, together with custody, authority, proposal, fences, and time. (`src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py:1819-1855`; `.docs/rw0-b1-pure-phase-values.md:198,287`)

Admission of event 2 or 3 must require the prior prefix to be durably admitted in the same phase and must bind that exact ordered prefix. A relation receipt that points only to transient event refs/digests is not sufficient.

#### Cancellation responses and Wire wrappers

The exact-current response relation requires the request and response plus the complete target/cancellation graph. (`src/ge_nwp_coordinator/_rw0_wire_protocol_values.py:2581-2640`)

Accordingly:

- an acknowledgement/rejection member must require the exact request member;
- a worker-result binding must require its observation members;
- a process-result classification binding must require its result/request/adapter/process operands;
- all operands that C2 later needs must be durably reconstructible, not merely named by a relation-operand ref/digest.

The final contract needs a topological admission DAG and legal partial-state inventory.

### 2. Relation-proof semantics are incomplete

The response correctly avoids a free-standing `relation_valid=true` Boolean, but it treats all relation proofs too uniformly.

At minimum, the contract needs distinct proof modes such as:

```text
value_reconstructed
relation_recomputable
relation_attested_at_admission
derived_wrapper_recomputable
existing_owner_row_reconstructed
```

This distinction matters because:

- phase establishment cannot rerun `validate_phase_entry_basis` from SQLite alone—the full WorkSpec is deliberately not persisted;
- cancellation-control classification must be recomputable by C2 from admitted operands;
- Capability qualification should be recomputable if every required member is durable;
- a Section 41 wrapper reconstructs an existing owner row rather than proving a new semantic relation.

The durable relation record must say which mode applies and which operands are:

- same-phase members;
- immutable existing owner rows;
- safe transient private operands;
- profiles or relation versions.

Otherwise a later reader cannot distinguish “recomputable durable graph” from “admission-time attestation whose private operand was intentionally discarded.”

### 3. Zero-relation admission is unresolved

The evidence-admission command currently proposes “one-to-three” relation-binding requests.

That cannot be correct for all kinds.

Likely examples:

- Capability declaration: structurally valid value, no qualification relation yet.
- Capability observation: structurally valid supplied claim; qualification relation belongs to the qualification member.
- Host readiness: structurally valid supplied observation; host-qualification relation belongs to the qualification member.

The freeze must define the exact relation count per kind, including whether zero is legal, and the exact ordering/digest of each relation set.

### 4. The C1-owned values are not actually frozen

The report names the rows and describes their contents, but leaves substantial design work for implementation:

- schema IDs;
- digest domains;
- exact ordered field tuples;
- exact result/reason vocabularies;
- exact optional-pair algebra;
- exact canonicalization rules;
- exact kind ranks;
- relation-set digest;
- graph digest;
- row digest;
- result-projection digest;
- wrapper identities for kinds 13–15;
- recovery-result representation;
- precise content-free error algebra.

Similarly, “flattened B1 phase projection and L34” is not an exact SQL contract. The phase table needs every column, constraint, FK, uniqueness rule, and copied-versus-referenced fact frozen before writing a 0004 migration.

### 5. The SQL design is a forecast, not an exact migration freeze

The response proposes:

```text
23 tables
46 immutability triggers
4 explicit indexes
```

That may be the correct final design, but exact implementation details remain open:

- one-to-one enforcement between registry and typed payload;
- composite FK shape;
- whether typed payloads repeat member kind/ref/digest;
- receipt-to-operation-family constraints;
- dense operand constraints;
- per-kind global-reuse versus phase-bound uniqueness;
- exact trigger and index names;
- exact `CHECK` clauses;
- exact nullable columns;
- exact foreign-key targets.

Those choices directly determine replay, collision, and corruption behavior. They cannot be delegated to an implementation pass.

### 6. The 75-file ceiling is not yet a causal ceiling

The report provides category totals, not a path-by-path proof.

There are signs of both over-inclusion and omission:

- `AGENTS.md` and `README.md` are included without an exact stale assertion or owning-contract reason.
- The central `.docs/c2b-durable-development-state.md` is omitted despite containing application-generation, terminal-migration, and schema-inventory claims. In the uploaded snapshot it discusses generation 2 and terminal migration sequencing at lines 678–734 and carries a separate migration-0003 model at lines 848–917.
- Other current-tip consumers exist outside the listed synchronization set, including tests and documents that mention terminal migration `0003`.
- Conversely, many historical mentions of `0003` should not be edited merely because `0004` is added.

A proper implementation allowlist needs a row for every path:

```text
path
must_change | conditional | protected
exact stale assertion or inventory
exact intended change
owning contract
test or source that fails if omitted
```

A speculative maximum of 75 files would give the implementation too much room and make the subsequent audit unnecessarily diffuse.

# Recommended final closure

Run one narrow, read-only reconciliation. It should not reopen the C1/C2 phase decision or the 15-kind strategic inventory. It should close only:

1. the member-admission dependency DAG;
2. relation-proof modes and durable operand closure;
3. per-kind relation counts;
4. exact kind ranks and reuse scope;
5. exact C1 schema IDs, domains, fields, and error algebra;
6. exact SQL tables, constraints, triggers, and indexes;
7. exact replay/recovery dependency checks;
8. the path-by-path implementation allowlist.

After that, the next response can be the implementation prompt without another phase-level design round.

## Codex handoff

Send this prompt to the existing read-only Coordinator conversation:

:chatgpt-content-reference{index="1"}

```text
Filename:
Coordinator_RW0_C1_Final_Durable_Schema_and_Admission_Closure_Prompt.txt

Size:
18,330 bytes

SHA-256:
5a3bd6608edc35038e7c013fd5dfe575c4fe7a2f9360df28d09500fa3d893afc
```

The desired result is:

```text
RW0_C1_FINAL_IMPLEMENTATION_CONTRACT_READY
```

The other legitimate results are:

```text
RW0_C1_FREEZE_RECONCILIATION_REQUIRED
```

for remaining implementation-contract gaps, or:

```text
RW0_C_ARCHITECTURAL_REPLAN_REQUIRED
```

only for a genuine owner, privacy, transaction, recovery, or decomposition contradiction.

Do not issue an implementation prompt from the current response.

## Provisional admission direction

The final reconciliation should test this dependency shape rather than treating every member alike:

```text
standalone:
- capability declaration
- capability observation as a supplied claim
- remote-host readiness as a supplied claim

requires same-phase members:
- host qualification:
  authority + readiness
- Capability qualification:
  declaration + observation + authority + readiness + host qualification
- retrieval event n:
  custody + authority + subordinate proposal + prior event prefix
- cancellation response:
  cancellation request
- worker-result binding:
  ordered admitted WorkerObservation members
- process-result classification binding:
  admitted result/request/adapter/process operands

requires existing immutable owner rows:
- Section 41 wrapper
```

That is provisional until Codex traces every exact owner relation and freezes the full DAG.

### Sources

- Current merged Coordinator snapshot: `Governed Execution Coordinator - Snapshot - 2026-09-27.zip`. 
- Codex’s RW0-C1 contract-freeze response supplied inline.
- `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py:1819-1855,1977-2162`
- `src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py:884-1007`
- `src/ge_nwp_coordinator/_rw0_wire_protocol_values.py:2472-2640`
- `.docs/rw0-b1-pure-phase-values.md:198,287,314`
- `src/ge_nwp_coordinator/sqlite_migration.py:31-39,69-110,336-367`
- `.docs/c2b-durable-development-state.md:678-734,848-917`

**Confidence:** High in the accepted C1 architecture and in the identified admission-closure gap; high that the remaining work is a bounded contract reconciliation rather than an architectural replan; medium-high that the final typed schema remains close to the proposed 23-table design.

Some older Project uploads have expired. This review used the current merged Coordinator snapshot; an older artifact only needs re-uploading if a later decision specifically depends on it.
