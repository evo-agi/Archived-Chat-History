# Decision

**Proceed with one final, tightly bounded repair. Do not stage or commit RW0-C1.**

The audit passed provenance, schema, privacy, DNC completeness, clean reconstruction, node reconciliation, and the previously closed selector/CAS/reader/temporal findings. The remaining implementation work is confined to `sqlite_writer_session` handoff and cleanup precedence, plus the private witness semantics and causal tests.

No C1 architecture, migration, evidence model, or authority decision should be reopened.

## What remains broken

### 1. The uncertainty window closes before the response is actually handed to the caller

The implementation marks `close_proof_complete`, then allows ordinary code to execute before the writer frame has returned. An exception at that final handoff can therefore escape as raw `RuntimeError`.

That is wrong in both cases:

```text
Committed apply:
ordinary failure before successful outer-frame exit
→ commit_outcome_unknown

Computed recovery:
ordinary failure before successful outer-frame exit
→ unresolved
```

The key correction is not another durable state. The private witness must remain active through the outermost writer function’s actual return boundary. `close_proof_complete` may mean internal cleanup succeeded, but it must not disable normalization while the frame can still raise.

The final `return result` must be inside the normalization `try` block. The witness naturally dies only after a successful frame return.

### 2. A secondary cleanup failure can replace an established primary safe error

The audit reproduced:

```text
primary:
mutation_failed

secondary:
operation-lease cleanup RuntimeError

observed:
raw RuntimeError
```

The primary safe classification must win.

The final precedence should be:

```text
COMMIT attempt started:
  ordinary later failure → commit_outcome_unknown

Recovery disposition computed:
  ordinary later failure → unresolved

No COMMIT, no primary error:
  standalone apply/replay cleanup failure → mutation_failed

Primary safe error already established:
  preserve that exact primary error

Governing process-control exception:
  preserve repository-defined process-control precedence
```

An exact replay does not perform another COMMIT. A standalone retirement failure on replay is therefore `mutation_failed`, not commit uncertainty and never a raw exception.

### 3. The historical red-gate provenance remains incomplete

This is not a current product defect and cannot be repaired retrospectively. The next repair must instead create complete prospective evidence:

- immutable snapshots of all relevant test files before edits;
- immutable red-test snapshots;
- exact before/after hashes;
- an exact test-only patch;
- proof that production files remained byte-identical through the red gate.

Because the C1 tests are untracked relative to HEAD, `git status` alone is not acceptable evidence of what changed.

## Repair scope

The repair is capped at **14 paths**:

```text
3 documentation paths
4 private production paths
7 test paths
```

Protected from change:

- migration `0004` and `sqlite_migration.py`;
- DNC readers and identity-route logic;
- all table and row schemas;
- B1, Wire, Capability, C2A, C2B, and Section 41 owners;
- migrations `0001`–`0003`;
- package exports and `StateStore`;
- the public `WriterSession` protocol;
- every other candidate path.

The repair must start test-first against the current source and produce deterministic red failures for:

1. committed final response handoff;
2. recovery final response handoff;
3. primary safe error plus cleanup failure;
4. exact-replay standalone cleanup failure.

## Codex handoff

Send this to the **original workspace-write RW0-C1 implementation conversation**:

:chatgpt-content-reference{index="0"}[Download the final handoff and precommit-cleanup repair prompt](sandbox:/mnt/data/Coordinator_RW0_C1_Final_Handoff_and_Precommit_Cleanup_Repair_Prompt.txt)

```text
Filename:
Coordinator_RW0_C1_Final_Handoff_and_Precommit_Cleanup_Repair_Prompt.txt

Size:
19,122 bytes

SHA-256:
08232000498cc64b051a1dabc50a30e63068018c4f727a44bbb99ce08270a125
```

The required success result is:

```text
COORDINATOR_RW0_C1_FINAL_HANDOFF_REPAIRED_READY_FOR_FRESH_REAUDIT
```

After that result, run a fresh independent re-audit. Do not resume the existing audit root, and do not stage or commit before an audit returns:

```text
ACCEPT

COORDINATOR_RW0_C1_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

## Current status

```text
RW0-C1:
implemented, repeatedly audited, still blocked on final handoff/cleanup control flow

Migration/schema/privacy architecture:
accepted and not reopened

DNC identity-route completeness:
passed

Commit/push/PR gate:
closed

RW0-C2:
not implemented

RW0-D:
not implemented

RW0-E:
not implemented
```

### Source

Codex’s final independent re-audit response supplied in this turn.

**Confidence:** High that FINAL-001 and FINAL-002 are real, narrow control-flow defects; high that FINAL-003 is historical evidence incompleteness rather than a candidate semantic defect; high that the 14-path ceiling is sufficient unless opening inspection reveals another direct source-hash oracle.
