Here is Codex's response:

# Baseline and inspection boundary

The required baseline is present exactly:

- Branch: `trunk_dev`
- HEAD: `047563de5a443b0f8323401c92979ae2e444d2ed`
- Tree: `4ff9ee4a710af13447e3ed8699339a51255ff720`
- Sole parent: `dd12b23762dc761736e55a1abfde12dd3ec23551`
- Subject: `feat: add RW0-B2 cancellation-control evidence (#6)`
- Upstream: `origin/trunk_dev`
- Ahead/behind: `0/0`
- Worktree/index/untracked/unmerged: clean
- Worktrees: one

Inspection was confined to this repository and the supplied prompt. No fetch, tests, database operation, worker, model, or supporting-repository inspection occurred.

The actual cumulative physical baseline is:

| MigrationTables addedTriggers addedExplicit indexes added |    |    |   |
| --------------------------------------------------------- | -- | -- | - |
| `0001_initial`                                            | 11 | 16 | 0 |
| `0002_development_program_and_effect_state`               | 19 | 30 | 1 |
| `0003_cognitive_proposal_and_selection_state`             | 9  | 18 | 0 |
| Current total                                             | 39 | 64 | 1 |

Application generation remains 2.

# Preserved C1 architecture

The C1/C2 split remains valid and is not reopened.

C1 remains an independently useful, private, no-contact durable capability providing:

- immutable phase establishment;
- exactly 15 typed evidence kinds;
- single-member admission;
- typed membership and relation/profile binding;
- exact replay and collision handling;
- guarded readback;
- one-attempt commit with three-way recovery.

It does not gain completeness, decision, terminal, latch, executable, public, external-contact, or production-orchestration authority.

The preserved rank and scope matrix is:

| RankKindSchema IDScope |                                            |                                                                                    |                          |
| ---------------------- | ------------------------------------------ | ---------------------------------------------------------------------------------- | ------------------------ |
| 1                      | authority verification observation         | `governed-execution.nwp-rw0-authority-verification-observation.v1`                 | phase-bound              |
| 2                      | subordinate authorization proposal         | `governed-execution.nwp-rw0-subordinate-authorization-proposal.v1`                 | phase-bound              |
| 3                      | custody availability observation           | `governed-execution.nwp-rw0-custody-availability-observation.v1`                   | phase-bound              |
| 4                      | retrieval capability event                 | `governed-execution.nwp-rw0-retrieval-capability-event-observation.v1`             | phase-bound              |
| 5                      | remote host readiness                      | `governed-execution.nwp-rw0-remote-host-readiness-observation.v1`                  | globally reusable        |
| 6                      | effect-host qualification                  | `governed-execution.nwp-rw0-effect-host-qualification.v1`                          | phase-bound              |
| 7                      | mechanism capability declaration           | `governed-execution.nwp-rw0-worker-mechanism-capability-declaration.v1`            | globally reusable        |
| 8                      | mechanism capability observation           | `governed-execution.nwp-rw0-worker-mechanism-capability-observation.v1`            | globally reusable        |
| 9                      | mechanism capability qualification         | `governed-execution.nwp-rw0-worker-mechanism-capability-qualification.v1`          | phase-bound              |
| 10                     | Wire cancellation-request observation      | `governed-execution.nwp-rw0-wire-cancellation-request-observation.v1`              | K8-bound                 |
| 11                     | Wire process observation                   | `governed-execution.nwp-rw0-wire-process-observation.v1`                           | K8-bound                 |
| 12                     | C2A worker observation                     | `governed-execution.nwp-worker-observation.v1`                                     | K8-bound                 |
| 13                     | Wire worker-result binding                 | `governed-execution.nwp-rw0-c1-wire-worker-result-binding.v1`                      | K8-bound                 |
| 14                     | Wire process-result classification binding | `governed-execution.nwp-rw0-c1-wire-process-result-classification-binding.v1`      | K8-bound                 |
| 15                     | Section 41 proposal-family wrapper         | `governed-execution.nwp-rw0-c1-section41-post-execution-proposal-family-member.v1` | existing-owner-row-bound |

The preserved dependency order is:

1. Phase establishment.
2. Ranks 1, 3, 5, and 7 may establish their independent roots subject to their transient or owner-row proofs.
3. Rank 2 follows rank 1.
4. Rank 4 follows rank 3 and its admitted retrieval-event prefix.
5. Rank 6 follows ranks 1 and 5.
6. Rank 8 follows rank 7.
7. Rank 9 follows ranks 1, 5, 6, 7, and 8.
8. Ranks 10–12 bind the exact K8 and owner rows; cancellation responses at rank 12 additionally require the admitted rank-10 request.
9. Rank 13 follows the exact admitted rank-12 result-observation sequence.
10. Rank 14 follows rank 13 and any admitted rank-10/11/12 facts supplied to NWPF.
11. Rank 15 wraps the exact existing Section 41 owner-row family.

Legal partial states remain precisely the downward-closed subsets of this DAG. Membership remains evidence presence, not completeness.

# Capsule privacy reconciliation

C1 must not persist any of the following:

- capsule entries;
- paths or operations;
- modes;
- before/after blob digests;
- before/after byte lengths;
- raw capsule bytes;
- candidate workspace material;
- the complete `CandidateCapsuleManifestV1`.

The exact durable safe-manifest binding is:
```
candidate_ref
manifest_schema_id =
  governed-execution.nwp-candidate-capsule-manifest.v1
capsule_manifest_ref
portable_capsule_digest
authorized_path_scope_digest
```

`candidate_ref` comes from the phase K8. The remaining four values occupy one `transient_safe_manifest_binding` relation operand. The schema ID implies:
```
canonicalization_profile = canonical-json.sorted-keys.utf8.v1
digest_domain =
  governed-execution.nwp-candidate-capsule-manifest.v1.identity
```

No canonicalization/profile string needs to be duplicated in SQLite.

For ranks 10–12:

1. The admission command may contain the exact full manifest as a private transient operand.
2. C1 reconstructs it and executes the existing owner relation before writing.
3. The admission-command digest binds the full canonical command, including that transient manifest.
4. The manifest’s existing `portable_capsule_digest` binds the complete owner mapping, including entries.
5. SQLite receives only the safe binding above and the relation/profile/operand closure.
6. The full object is discarded and cannot be reconstructed from C1 rows.

For an `author_candidate` target, the manifest operand is absent. For `validate_candidate` or `review_candidate`, all safe-manifest fields are present and the transient argument must be an exact `CandidateCapsuleManifestV1`. Partial branches are invalid.

This satisfies the current durable-state privacy owner without changing B2, C2A, or the manifest’s owner identity.

# Revised kind-14 contract

Rank 14 is exclusively `wire_process_result_classification_binding` under NWPF v1:
```
wire_profile_ref    = rw0-wire-nwpf-v1
wire_profile_digest = 470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454
```

Its exact ordered typed-table fields are:
```
kind_rank
value_ref
value_digest
value_schema_id
phase_ref
phase_digest
program_ref
semantic_attempt_ref
candidate_ref
effect_intent_ref
author_command_ref
author_command_digest
author_delivery_attempt_ref
author_delivery_envelope_digest
attempt_fence_ref
attempt_fence_digest
author_effect_fence_ref
author_effect_fence_digest
wire_profile_ref
wire_profile_digest
worker_result_kind
worker_result_member_ref
worker_result_member_digest
adapter_observation_count
adapter_observation_set_digest
request_member_ref
request_member_digest
process_observation_count
process_observation_set_digest
cancellation_effect_fence_ref
cancellation_effect_fence_digest
cancellation_delivery_attempt_ref
cancellation_delivery_envelope_digest
classification
reason
relation_ref
relation_digest
payload_row_digest
```

Closed constraints:

- `kind_rank = 14`.
- `value_schema_id` is the rank-14 schema ID above.
- `worker_result_kind` is exactly `worker_result` or `finite_result_failure`.
- `worker_result_member_ref/digest` identifies one admitted rank-13 member.
- Rank 13, rather than rank 14, carries the exact bounded failure reason for `finite_result_failure`.
- `adapter_observation_count` is `0..4`.
- `process_observation_count` is `0..2`.
- Both set digests exist even for the empty tuple.
- The request ref/digest pair is either wholly absent or wholly present and, when present, resolves to rank 10.
- The cancellation-fence pair and cancellation-delivery pair form one all-absent/all-present four-field branch.
- Optional request and optional cancellation-owner branches record the exact classifier input; they are not truth flags.
- `classification/reason` is exactly the existing NWPF matrix:
  - `usable / usable`;
  - `invalid / {invalid_input, unrelated_fact, duplicate_fact, conflicting_fact, cancellation_graph_mismatch}`;
  - `unusable / {resource_limit_exceeded, deadline_elapsed, signal_delivered, cancellation_request_pending, cancellation_acknowledged, cancellation_rejected, process_result_contradiction, process_failed, result_missing, result_invalid, process_evidence_incomplete}`.

The one rank-14 relation has these ordered operands, with absent optional groups skipped and ordinals kept dense:
```
author_command
author_delivery
attempt_fence
author_effect_fence
worker_result_binding
adapter_observation:000 .. adapter_observation:003
cancellation_request
process_observation:000 .. process_observation:001
cancellation_effect_fence
cancellation_delivery
```

Maximum cardinality is 14 operands.

The relation reconstructs the exact rank-13 result or failure, admitted adapter observations, request, process observations, and existing owner rows, then invokes `classify_wire_process_result(...)` exactly once. The stored pair must equal the returned pair.

Rank 14 has no capsule column. Safe capsule identities already contained in admitted rank-10/11/12 members or their relation operands are transitively bound by their immutable member digests and the rank-14 operand closure.

Rank 14 must not contain:

- the cancellation-control profile;
- a cancellation-control classification or reason;
- a target manifest or manifest entry;
- a decision or terminal closure;
- a completeness assertion.

# Composite evidence identity

The exact evidence identity is kind-scoped.

## `rw0_evidence_values`

Ordered columns:
```
kind_rank
value_ref
value_digest
value_schema_id
scope_class
value_row_digest
```

Key constraints:
```
PRIMARY KEY (kind_rank, value_ref)
UNIQUE (kind_rank, value_digest)
UNIQUE (kind_rank, value_ref, value_digest, value_schema_id)
```

`scope_class` is exactly:
```
ranks 5,7,8       global_reusable
ranks 1,2,3,4,6,9 phase_bound
ranks 10..14      k8_bound
rank 15           existing_owner_row_bound
```

A closed `CHECK` binds each `kind_rank` to the one schema ID and scope class in the rank table above.

Consequences:

- The same textual ref may legally appear under different ranks.
- The same digest text may legally appear under different ranks.
- No query, FK, collision check, replay locator, or recovery locator may treat either as a cross-kind collision.
- Same-rank, same-ref with different digest or schema is `member_identity_collision`.
- Same-rank, same-digest with different ref or schema is `member_identity_collision`.
- An exact existing registry row can be reused only when its scope relation also validates.

## Typed tables

Every one of the 15 typed tables begins with:
```
kind_rank
value_ref
value_digest
value_schema_id
```

and has:
```
PRIMARY KEY (kind_rank, value_ref)
UNIQUE (kind_rank, value_digest)
FOREIGN KEY (
  kind_rank, value_ref, value_digest, value_schema_id
) REFERENCES rw0_evidence_values (
  kind_rank, value_ref, value_digest, value_schema_id
) ON UPDATE RESTRICT ON DELETE RESTRICT NOT DEFERRABLE INITIALLY IMMEDIATE
```

Each table has a literal rank/schema `CHECK`. There is no global `value_ref` or `value_digest` uniqueness.

## `rw0_evidence_memberships`

Revised ordered columns:
```
phase_ref
phase_digest
kind_rank
value_ref
value_digest
value_schema_id
scope_binding_digest
relation_set_digest
admitted_at
membership_digest
```

Constraints:
```
PRIMARY KEY (phase_ref, kind_rank, value_ref)
UNIQUE (phase_ref, kind_rank, value_digest)
UNIQUE (
  phase_ref, kind_rank, value_ref, value_digest, value_schema_id
)
UNIQUE (phase_ref, membership_digest)
FOREIGN KEY (phase_ref, phase_digest)
  REFERENCES rw0_phase_instances (phase_ref, phase_digest)
  ON UPDATE RESTRICT ON DELETE RESTRICT NOT DEFERRABLE INITIALLY IMMEDIATE
FOREIGN KEY (kind_rank, value_ref, value_digest, value_schema_id)
  REFERENCES rw0_evidence_values
    (kind_rank, value_ref, value_digest, value_schema_id)
  ON UPDATE RESTRICT ON DELETE RESTRICT NOT DEFERRABLE INITIALLY IMMEDIATE
```

`scope_binding_digest` is not a Boolean:

- Globally reusable: SHA-256 under domain\
  `governed-execution.nwp-rw0-c1-global-evidence-scope.v1.identity` over the exact kind-rank/schema pair.
- Phase-bound: exact `phase_digest`.
- K8-bound: exact phase `k8_digest`.
- Rank 15: exact Section 41 owner-family binding digest.

The private reader recomputes and verifies this value.

## Relation operands

Revised ordered columns:
```
phase_ref
relation_ref
relation_digest
operand_ordinal
operand_role
operand_source
evidence_kind_rank
operand_schema_id
operand_ref
operand_digest
operand_scope_digest
operand_row_digest
```

`operand_source` is closed to:
```
c1_evidence
existing_owner_row
transient_safe_manifest_binding
```

Branches:

- `c1_evidence`: `evidence_kind_rank` non-null; `operand_scope_digest` null; composite FK to the kind-scoped evidence registry.
- `existing_owner_row`: `evidence_kind_rank` and `operand_scope_digest` null.
- `transient_safe_manifest_binding`: `evidence_kind_rank` null; `operand_scope_digest` non-null; schema/ref/digest are the safe manifest binding.

The composite evidence FK is:
```
FOREIGN KEY (
  evidence_kind_rank, operand_ref, operand_digest, operand_schema_id
) REFERENCES rw0_evidence_values (
  kind_rank, value_ref, value_digest, value_schema_id
) ON UPDATE RESTRICT ON DELETE RESTRICT NOT DEFERRABLE INITIALLY IMMEDIATE
```

SQLite’s null-FK behavior leaves the two non-evidence branches outside this FK; the branch `CHECK` prevents a malformed hybrid.

# Revised migration 0004 schema

The migration remains:
```
ID:          0004_rw0_phase_and_evidence_state
sequence:    4
min schema:  2
max schema:  2
destructive: false
seed rows:   zero
```

The literal checksum is mechanically calculated from the final immutable SQL resource and pinned in `sqlite_migration.py` in the same candidate. It is not an open semantic choice.

The migration still creates exactly 23 STRICT tables:

Core six:
```
rw0_phase_instances
rw0_evidence_values
rw0_evidence_memberships
rw0_relation_bindings
rw0_relation_operands
rw0_c1_mutation_receipts
```

Typed fifteen:
```
rw0_authority_verification_observations
rw0_subordinate_authorization_proposals
rw0_custody_availability_observations
rw0_retrieval_capability_event_observations
rw0_remote_host_readiness_observations
rw0_effect_host_qualifications
rw0_worker_mechanism_capability_declarations
rw0_worker_mechanism_capability_observations
rw0_worker_mechanism_capability_qualifications
rw0_wire_cancellation_request_observations
rw0_wire_process_observations
rw0_c2a_worker_observations
rw0_wire_worker_result_bindings
rw0_wire_process_result_classification_bindings
rw0_section41_post_execution_proposal_family_members
```

Normalized children:
```
rw0_authority_observation_effect_classes
rw0_c2a_worker_observation_evidence_refs
```

A capsule-entry or capsule-manifest child table is prohibited.

The evidence-registry, membership, relation-operand, and rank-14 definitions are the revised definitions above. All other frozen columns retain their preceding C1 contract. All columns use `ANY` with explicit built-in-type and value `CHECK`s.

Every table receives exactly two immutable triggers:
```
<table>_immutable_update
<table>_immutable_delete
```

Each raises `ABORT`; therefore migration 0004 adds exactly 46 triggers.

The four explicit indexes remain:
```
CREATE INDEX rw0_phase_instances_k8_lookup_idx
ON rw0_phase_instances (
  program_ref,
  semantic_attempt_ref,
  candidate_ref,
  effect_intent_ref,
  author_command_ref,
  attempt_fence_ref,
  effect_fence_ref,
  delivery_attempt_ref
);

CREATE INDEX rw0_evidence_memberships_phase_page_idx
ON rw0_evidence_memberships (
  phase_ref, kind_rank, value_ref, value_digest
);

CREATE INDEX rw0_relation_operands_evidence_lookup_idx
ON rw0_relation_operands (
  evidence_kind_rank,
  operand_ref,
  operand_digest,
  operand_schema_id,
  phase_ref,
  relation_ref,
  operand_ordinal
)
WHERE operand_source='c1_evidence';

CREATE INDEX rw0_c1_mutation_receipts_phase_family_idx
ON rw0_c1_mutation_receipts (
  phase_ref, mutation_family, mutation_ref, command_digest
);
```

Implicit indexes created by PK/UNIQUE constraints are not counted as explicit indexes.

The cumulative result is therefore:

| StateTablesTriggersExplicit indexes |     |     |    |
| ----------------------------------- | --- | --- | -- |
| Existing through 0003               | 39  | 64  | 1  |
| Migration 0004                      | +23 | +46 | +4 |
| New cumulative total                | 62  | 110 | 5  |

`EXPECTED_TABLES` gains exactly the 23 names. A fourth empty-table group is verified after migration 0004. Migrations 0001–0003 remain byte-exact.

# C2 operation-time recomputation seam

The three moments are distinct.

## 1. C1 admission

For ranks 10–12, C1 receives the full manifest only as a transient command operand when the target is validation or review. It validates:

- exact owner reconstruction;
- candidate/K8 equality;
- manifest ref and portable digest;
- authorized path-scope digest;
- command/fence/delivery lineage;
- the corresponding existing Wire/C2A relation.

C1 persists only:
```
candidate_ref
manifest_schema_id
capsule_manifest_ref
portable_capsule_digest
authorized_path_scope_digest
relation schema/version
profile pair
ordered exact ref/digest operands
admission command digest
```

## 2. C2 operation-time recomputation

The exact C2 classifier operands are:
```
author_command                   existing owner row
attempt_fence                    existing owner row
author_effect_fence              existing owner row
target_effect_fence              existing owner row
target_delivery                  existing owner row
cancellation_effect_fence        existing owner row
cancellation_delivery            existing owner row
request                          admitted rank 10 or absent
adapter_observations             ordered admitted rank-12 tuple
process_observations             ordered admitted rank-11 tuple
target_capsule_manifest          transient exact manifest or omitted sentinel
```

For `author_candidate`, `target_capsule_manifest` is omitted, not `None`. For validation or review, it is an exact `CandidateCapsuleManifestV1`.

Before invoking `classify_wire_exact_current_cancellation_control(...)`, C2 reconstructs all immutable C1 and owner rows and proves that the transient manifest matches the C1 safe binding and owner lineage.

## 3. C2 durable attestation and recovery

The future C2 cancellation-control attestation requires this ordered semantic projection:
```
schema_id
attestation_ref
c2_command_schema_id
c2_command_ref
c2_command_digest
c1_phase_ref
c1_phase_digest
target_class
cancellation_profile_ref
cancellation_profile_digest
operand_closure_digest
target_candidate_ref
target_manifest_schema_id
target_capsule_manifest_ref
target_portable_capsule_digest
target_authorized_path_scope_digest
classification
reason
classification_result_digest
attested_at
attestation_digest
```

The five target-manifest fields are all null for `author_candidate` and all non-null for validation/review.

The cancellation profile is exactly:
```
rw0-wire-cancellation-control-v1
4d6f84552b852a4c4073b4238591afd271072f648424eca9e744def436165288
```

The C2 decision-basis closure binds the attestation ref/digest and classification-result digest. The terminal closure binds the committed decision closure, not the private manifest. This is sufficient because the committed command digest and attestation digest already bind the operation-time proof.

No D/E custody fact is created. No manifest retrieval, capsule-store access, worker contact, process action, or other I/O occurs in C1 or in the pure C2 classifier call.

# Replay and recovery consequences

C1 replay and recovery use the composite evidence identity everywhere:
```
(kind_rank, value_ref)
(kind_rank, value_digest)
(kind_rank, value_ref, value_digest, value_schema_id)
```

Replay rules:

- Same mutation ref and same canonical command digest: exact replay after writer fencing.
- Same mutation ref and different command digest: `mutation_ref_reused`.
- Exact member already in the same phase: `member_already_admitted`.
- Same-kind ref/digest alias: `member_identity_collision`.
- Cross-kind textual reuse: irrelevant and legal.
- Missing prerequisite member: `missing_prerequisite_member`.
- Corrupt or non-unique owner row: `database_integrity_failure`.

For an admission-time manifest relation, ordinary readback verifies:

- the receipt;
- command digest;
- safe manifest binding;
- relation/profile pair;
- ordered operand closure;
- relation and membership digests.

It does not claim to rerun the owner relation without the private manifest. A retry of an uncommitted command must resupply the manifest.

C1 commit resolution remains:
```
committed_exact
definitely_not_committed
unresolved
```

Committed-exact recovery verifies the complete kind-qualified immutable graph. Definitely-not-committed permits an explicit retry. Unresolved forbids automatic retry.

After C2 has committed its closure, recovery verifies the stored command, profile, operand closure, safe manifest binding, classification attestation, decision/terminal closure, receipt, and result digests. It does not invoke the cancellation classifier or reconstruct capsule entries. If no committed C2 closure exists, a fresh C2 attempt needs the transient manifest again.

# Exact reader changes

All SQL uses explicit ordered columns and `LIMIT`; no `SELECT *`, global-ref lookup, or global-digest lookup is allowed.

Evidence collision probes become:
```
SELECT value_ref, value_digest, value_schema_id, scope_class, value_row_digest
FROM rw0_evidence_values
WHERE kind_rank=? AND value_ref=?
LIMIT 2;

SELECT value_ref, value_digest, value_schema_id, scope_class, value_row_digest
FROM rw0_evidence_values
WHERE kind_rank=? AND value_digest=?
LIMIT 2;
```

Typed-payload lookup is:
```
... FROM <literal typed table>
WHERE kind_rank=<literal rank>
  AND value_ref=?
  AND value_digest=?
  AND value_schema_id=<literal schema>
LIMIT 2;
```

Membership lookup and collision probes are:
```
... FROM rw0_evidence_memberships
WHERE phase_ref=? AND kind_rank=? AND value_ref=?
LIMIT 2;

... FROM rw0_evidence_memberships
WHERE phase_ref=? AND kind_rank=? AND value_digest=?
LIMIT 2;
```

The bounded membership page is:
```
... FROM rw0_evidence_memberships
WHERE phase_ref=?
  AND (kind_rank>? OR (kind_rank=? AND value_ref>?))
ORDER BY kind_rank, value_ref
LIMIT 257;
```

The maximum accepted page is 256 rows; row 257 is the overflow sentinel.

Relation reads use:
```
... FROM rw0_relation_bindings
WHERE phase_ref=? AND kind_rank=? AND value_ref=?
ORDER BY relation_rank
LIMIT 4;
```

The maximum is three relations; row 4 is overflow.

Operand reads use:
```
... FROM rw0_relation_operands
WHERE phase_ref=? AND relation_ref=? AND relation_digest=?
ORDER BY operand_ordinal
LIMIT 15;
```

The maximum is 14 operands; row 15 is overflow.

Section 41 remains:

- proposal lookup: `LIMIT 2`;
- evidence rows ordered by `role_rank, ordinal, evidence_role, evidence_ref`: `LIMIT 10`;
- valid cardinality: exactly 0 or exactly 9.

Reader classification is closed:

- zero rows: absent, missing prerequisite, or definitely-not-committed according to the caller role;
- one exact row: reconstruct and verify;
- two rows where one was permitted: `database_integrity_failure`;
- capability/epoch failure: existing safe capability error;
- operational SQLite failure: `mutation_failed`;
- malformed row, FK closure, scope binding, digest, or schema mismatch: `database_integrity_failure`.

The existing 24-query C2B2 Slice-3 inventory remains unchanged. C1 is added as a private consumer of its applicable roles; C1-specific membership, relation, and recovery queries are family-local and do not enlarge the C2B2 inventory.

# Exhaustive causal touched-file ledger

There are exactly 78 `must_change` paths:
```
27 documentation/root
 9 production/migration
42 tests
78 total
```

There are no conditional paths.

## `must_change`: documentation/root — 27

| PathExact current item → intended change; owner; omission failure |                                                                                                                                                                                                                                                             |
| ----------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `.docs/rw0-c1-durable-phase-and-evidence.md`                      | Absent → add sole detailed C1 owner including privacy, composite identity, rank 14, SQL, replay, and recovery; C1; omission leaves no owner contract.                                                                                                       |
| `.docs/architecture.md`                                           | Current catalog ends at 0003 and RW0-C is future → append current C1/0004 composition while preserving historical tranche text; architecture; omission makes architecture status false.                                                                     |
| `.docs/authority-boundaries.md`                                   | Current durable boundary ends at Section 41 → add C1’s bounded durable authority and retain C2/ES exclusions; authority composition; omission misstates authority.                                                                                          |
| `.docs/autonomous-software-development-operating-model.md`        | `[0001,0002,0003]`, tip 0003, RW0-C future → `[0001..0004]`, C1 current/C2 future; composition owner; omission breaks authoritative topology.                                                                                                               |
| `.docs/b3-tests-only-coherent-fixtures.md`                        | Current physical fixture is terminal 0003 → fixture uses terminal 0004 while historical schema-0001 rows retain meaning; B3 fixture owner; omission makes fixture validation stale.                                                                         |
| `.docs/b3-transition-persistence-contract.md`                     | Current-generation fixture references terminal 0003 → terminal 0004 physical host, unchanged B3 semantics; B3 owner; omission makes contract tests stale.                                                                                                   |
| `.docs/b3c0a-transition-authority-and-order.md`                   | Current databases described as terminal 0003 → terminal 0004, B3c0a still owns neither; B3c0a owner; omission creates current-tip drift.                                                                                                                    |
| `.docs/b4c-public-global-stop-delegation.md`                      | Lines 88/99 say terminal 0003/current terminal → terminal 0004 while preserving B4c ownership; B4c; omission fails its direct contract test.                                                                                                                |
| `.docs/c2a-first-slice-semantic-protocol-contract.md`             | Current physical terminal is 0003 → 0004, with C2A still not its owner; C2A status projection; omission fails nonimplementation assertions.                                                                                                                 |
| `.docs/c2b-durable-development-state.md`                          | Lines 24294–24302 pin sequence 3 and 39/64/1; line 24803 says current terminates at 0003 → sequence 4 and 62/110/5, C1 privacy-safe state added; durable-state owner; omission leaves authoritative counts false.                                           |
| `.docs/c2b2-migration-0002.md`                                    | Current catalog and suffixes terminate at 0003 → include 0004 while preserving C2B2 nonownership; migration-0002 owner; omission misstates supported prefixes.                                                                                              |
| `.docs/c2b2-private-readers.md`                                   | Exactly three importers and current tip 0003 → add the C1 private consumer and tip 0004 without changing 24 queries; reader status owner; omission fails importer inventory.                                                                                |
| `.docs/durable-state-model.md`                                    | Tip 0003 plus privacy rule at lines 465–472 → tip 0004 and explicit C1 safe-manifest projection conforming to that rule; durable-state owner; omission leaves the central privacy reconciliation undocumented.                                              |
| `.docs/rw0-b1-pure-phase-values.md`                               | Sole consumer is Capability and durable C is future → add C1 private consumer/current persistence while preserving B1 semantics; B1 owner; omission fails importer/status tests.                                                                            |
| `.docs/rw0-b2-capability.md`                                      | C1 durable projection described as future → current private C1 consumer, D/E still future; Capability owner; omission fails status/importer assertions.                                                                                                     |
| `.docs/rw0-b2-wire-protocol.md`                                   | RW0-C is future and no persistence exists → append a C1 status successor; preserve the frozen B2 delivery-status block and both classifiers unchanged; Wire owner; omission misstates current composition.                                                  |
| `.docs/rw0-remote-worker-contact-phase-entry.md`                  | C remains target-only → C1 durable membership current, C2/D/E future; RW0 composition; omission leaves roadmap current/future status false.                                                                                                                 |
| `.docs/software-development-progression-boundary.md`              | Terminal 0003/current pre-execution boundary → terminal 0004 with non-executable C1; progression boundary; omission fails boundary assertions.                                                                                                              |
| `.docs/sqlite-bootstrap-and-migrations.md`                        | Top-level current tip/resource set is exactly 0001–0003 → add 0004, supported suffixes, zero-seed checks, and 62/110/5; migration owner; omission breaks operational migration guidance. Historical superseded C2B0 migration-0003 tables remain untouched. |
| `.docs/sqlite-operations-and-recovery.md`                         | Current terminal/resources exactly 0003 → add 0004 and its recovery behavior; operations owner; omission gives unsafe operator instructions.                                                                                                                |
| `.docs/sqlite-schema-v1.md`                                       | Current terminal extension is 0003 → append 0004 schema inventory; schema owner; omission makes schema documentation incomplete.                                                                                                                            |
| `.docs/sqlite-state-backend-adr.md`                               | Current packaged tip is 0003 → 0004, generation remains 2; ADR; omission causes backend-policy drift.                                                                                                                                                       |
| `.docs/sqlite-threat-model.md`                                    | Current terminal is 0003 → 0004 plus composite-identity and privacy threats; threat model; omission leaves reviewed threats incomplete.                                                                                                                     |
| `.docs/worker-execution-boundary.md`                              | RW0-C durable boundary remains future → C1 current, C2/D/E/runtime still future; worker boundary; omission misstates ownership.                                                                                                                             |
| `.docs/writer-session-authority.md`                               | No guarded C1 mutation family → document private concrete-session C1 guard/delegation without public protocol widening; writer authority; omission leaves mutation authority unexplained.                                                                   |
| `AGENTS.md`                                                       | Current catalog/status terminates at 0003 and RW0-C remains future → append exact C1/0004 rules; repository governance; omission directs later agents incorrectly.                                                                                          |
| `README.md`                                                       | Current fixture/catalog lists `[0001,0002,0003]` and terminal 0003 → add 0004/C1 summary; repository overview; omission exposes false current behavior.                                                                                                     |

## `must_change`: production/migration — 9

| PathExact current item → intended change; owner; omission failure                |                                                                                                                                                                                                                              |
| -------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `src/ge_nwp_coordinator/_rw0_c1_semantic_values.py`                              | Absent → add private C1 commands, results, ranks, relations, safe-manifest projection, and finite algebra; C1; no semantic boundary otherwise.                                                                               |
| `src/ge_nwp_coordinator/_rw0_c1_row_values.py`                                   | Absent → add exact immutable rows/digests for the 23-table family; C1; SQL rows could not be reconstructed safely.                                                                                                           |
| `src/ge_nwp_coordinator/_sqlite_rw0_c1_reader_contracts.py`                      | Absent → add literal private SELECT specifications and bounds; C1 reader contract; queries would be left to implementation judgment.                                                                                         |
| `src/ge_nwp_coordinator/_sqlite_rw0_c1_readers.py`                               | Absent → add private capability-only readers, composite locators, and corruption classification; C1; no guarded readback/recovery.                                                                                           |
| `src/ge_nwp_coordinator/_rw0_c1_mutation_contracts.py`                           | Absent → add write plans, result/conflict/recovery types, replay and graph rules; C1; transaction outcomes remain undefined.                                                                                                 |
| `src/ge_nwp_coordinator/_sqlite_rw0_c1.py`                                       | Absent → add private atomic C1 persistence and three-way recovery using the existing operation-lease authority primitives; C1; no durable implementation. It must not import `sqlite3` directly.                             |
| `src/ge_nwp_coordinator/sqlite_writer_session.py`                                | No private C1 guarded delegation → add concrete-only, unexported C1 entry/recovery delegation; writer authority; omission prevents use of the operation guard. Public `WriterSession` remains unchanged.                     |
| `src/ge_nwp_coordinator/sqlite_migration.py`                                     | Sequence ends at 3, 39 expected tables, three specs and empty groups → add literal 0004 metadata, 23 tables, empty verification, and terminal sequence 4; migration owner; initialization/validation rejects the new schema. |
| `src/ge_nwp_coordinator/sqlite_migrations/0004_rw0_phase_and_evidence_state.sql` | Absent → add the exact 23-table/46-trigger/4-index zero-seed schema; migration owner; no durable representation.                                                                                                             |

## `must_change`: existing tests — 33

For the migration-resource tests below, the exact current assertion is an ordered/globbed resource inventory ending in `0003_cognitive_proposal_and_selection_state.sql`, or a current tip/sequence of 3. The intended change is to add 0004 while continuing to pin the bytes and checksums of 0001–0003.

| PathAdditional causal change; owner; omission failure           |                                                                                                                                                                                                          |
| --------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `tests/b3_coherent_transition_fixture.py`                       | Fixture currently builds terminal 0003 → build terminal 0004 and leave all C1 tables empty; coherent fixture; fixture consumers fail.                                                                    |
| `tests/test_architecture_contracts.py`                          | Pins current topology/status → assert C1 current/C2 future and no widened authority; architecture; stale prose passes or current prose fails.                                                            |
| `tests/test_autonomous_software_development_operating_model.py` | Pins tip/resource/status strings → sequence 4/C1 current; composition owner; exact contract failure.                                                                                                     |
| `tests/test_b2a_writer_session_contract.py`                     | Exact migration glob ends at 0003 → include 0004 while preserving 0001 and public protocol; B2a; glob assertion fails.                                                                                   |
| `tests/test_b3_coherent_transition_fixture.py`                  | Asserts fixture tip 0003 and resource list → 0004 and empty C1 family; fixture owner; direct failure.                                                                                                    |
| `tests/test_b3a_persistence_contracts.py`                       | Exact migration glob ends at 0003 → include 0004; B3a remains nonowner; direct failure.                                                                                                                  |
| `tests/test_b3b1_pure_row_contracts.py`                         | Exact migration glob ends at 0003 → include 0004; B3b1 unchanged; direct failure.                                                                                                                        |
| `tests/test_b3b2b_select_readers.py`                            | Exact migration glob ends at 0003 → include 0004; reader behavior unchanged; direct failure.                                                                                                             |
| `tests/test_b3b_reader_prerequisite_contracts.py`               | Exact migration glob ends at 0003 → include 0004; prerequisite semantics unchanged; direct failure.                                                                                                      |
| `tests/test_b3c0a_transition_authority_contract.py`             | Pins terminal 0003/resource list → terminal 0004 and retained nonownership; B3c0a; direct failure.                                                                                                       |
| `tests/test_b3c0b_transition_event_replay_contracts.py`         | Exact migration glob ends at 0003 → include 0004; transition replay unchanged; direct failure.                                                                                                           |
| `tests/test_b3c1_prerequisite_contract.py`                      | Exact migration glob ends at 0003 → include 0004; existing controller authority unchanged; direct failure.                                                                                               |
| `tests/test_b3c1b_rollback_only_writer_fencing.py`              | Exact migration glob ends at 0003 → include 0004; fencing unchanged; direct failure.                                                                                                                     |
| `tests/test_b3c3_prerequisite_contract.py`                      | Exact migration glob ends at 0003 → include 0004; transition dry-run unchanged; direct failure.                                                                                                          |
| `tests/test_b4c_public_global_stop_delegation.py`               | Lines 1456–1464 assert terminal-0003/current-terminal phrases → terminal 0004 while preserving B4c behavior; B4c; this is the first previously omitted path.                                             |
| `tests/test_c2a_nonimplementation.py`                           | Pins physical terminal and exact source/resource set → add 0004 and C1 private consumers while retaining C2A nonownership; C2A; direct failure.                                                          |
| `tests/test_c2b0_durable_state_contract.py`                     | Embeds current catalog/count/status projections → add successor current 0004/C1 projections without rewriting historical C2B target blocks; C2B composition; direct failure.                             |
| `tests/test_c2b2_development_reader_contracts.py`               | Exact three-module importer inventory → add `_sqlite_rw0_c1.py` as the fourth bounded private consumer; C2B2 readers; importer assertion fails.                                                          |
| `tests/test_c2b3c_author_effect_contract.py`                    | Lines 202–220 pin “terminates at migration 0003” → migration 0004/current C1 sentence; C2B3C projection; second previously omitted path.                                                                 |
| `tests/test_remote_worker_pre_execution_planning_contract.py`   | Pins RW0-C future/current cross-reference → C1 current, C2/D/E future; remote-contact planning; status assertion fails.                                                                                  |
| `tests/test_runtime_non_authority.py`                           | Exact production source/resource and SQLite-importer surfaces → add approved C1 modules/resource while keeping `_sqlite_rw0_c1.py` out of direct `sqlite3` importers; runtime boundary; inventory fails. |
| `tests/test_rw0_b1_boundaries.py`                               | Sole B1 importer is Capability → permit exact C1 semantic consumer without changing B1 exports; B1; importer assertion fails.                                                                            |
| `tests/test_rw0_b2_capability_boundaries.py`                    | Exact Capability importer/caller/status inventory → add C1 private consumer; Capability; importer assertion fails.                                                                                       |
| `tests/test_rw0_b2_wire_boundaries.py`                          | Production Wire importer list contains only Capability → add exact C1 semantic consumer and preserve Wire source; Wire; importer assertion fails.                                                        |
| `tests/test_rw0_remote_contact_phase_entry_contract.py`         | Pins RW0-C target/current text and B1 consumer row → C1 current and exact consumer update; phase-entry owner; direct failure.                                                                            |
| `tests/test_software_development_progression_boundary.py`       | Pins terminal 0003/RW0-C future phrases → 0004/C1 current; progression boundary; direct failure.                                                                                                         |
| `tests/test_sqlite_b1_migrations.py`                            | Catalog tuple ends at sequence 3 → add exact sequence-4 definition and totals; migration framework; direct failure.                                                                                      |
| `tests/test_sqlite_b2c_writer_session.py`                       | Exact migration glob ends at 0003 → add 0004 and private C1 guarded path assertions; writer session; direct failure.                                                                                     |
| `tests/test_sqlite_backend_b0_contract.py`                      | Pins current tip/resources and SQLite importers → 0004, with no new direct sqlite importer; backend owner; direct failure.                                                                               |
| `tests/test_sqlite_c2b1_migration_framework.py`                 | Fixtures synthesize a three-resource package/current tip 3 → synthesize/validate sequence 4 and supported prefixes; migration framework; direct failure.                                                 |
| `tests/test_sqlite_c2b2_migration_0002.py`                      | `CURRENT_SEQUENCE=3`, current ID/resource/checksum=0003 → sequence 4/0004 while retaining exact 0002/0003 bytes; migration-0002 owner; direct failure.                                                   |
| `tests/test_sqlite_section41_migration_0003.py`                 | Exact resource inventory terminates at 0003 and treats it as current → include 0004 while continuing to test 0003 independently; Section 41 migration; direct failure.                                   |
| `tests/test_worker_execution_semantic_boundaries.py`            | Exact schema-resource/source-consumer inventory → add 0004/C1 consumer and assert capsule privacy; C2A owner; direct failure.                                                                            |

## `must_change`: new permanent tests — 9

Each is currently absent. Omitting it leaves the named finite C1 product claim untested.
```
tests/test_rw0_c1_semantic_values.py
tests/test_rw0_c1_row_values.py
tests/test_rw0_c1_reader_contracts.py
tests/test_rw0_c1_private_readers.py
tests/test_rw0_c1_mutation_contracts.py
tests/test_rw0_c1_private_atomic_persistence.py
tests/test_rw0_c1_recovery.py
tests/test_rw0_c1_writer_session_delegation.py
tests/test_sqlite_rw0_c1_migration_0004.py
```

They respectively own semantic grammar/privacy, row identity, literal query contracts, reader behavior, write/replay algebra, atomic persistence, three-way recovery, guarded private delegation, and exact migration/catalog/schema invariants.

## `protected`

The following relevant grep or inventory hits remain intentionally unchanged:

- `.docs/c2b3-program-initialization.md`: migration-0003 references are tranche history and C2B3 ownership statements.
- `.docs/c2b2-pure-durable-row-values.md`: Slice-2’s four-module boundary and no-I/O semantics remain exact.
- `.docs/c2a1-pure-semantic-values.md`: C2A1’s six-validator and consumer boundary remains unchanged.
- B3b/B3c historical prerequisite documents not in `must_change`: their “did not add migration 0003” statements remain true.
- `tests/test_c2b2_field_level_contract.py`: its Slice-2/Slice-3 module globs and historical migration statements remain unchanged; new C1 modules do not match those globs.
- `tests/test_rw0_b2_wire_cancellation_control_boundaries.py`: the exact B2 current-at-delivery status block stays byte-for-byte as tranche-local history. A separate C1 successor status is added outside that frozen block.
- `tests/test_c2b3_private_atomic_program_initialization.py` and `tests/test_c2b3_program_initialization_contract.py`: their 0003 references are historical or family-local, not current-tip assertions.
- `tests/test_b3b2a_read_scope_and_query_contracts.py`: the direct-`sqlite3` importer set remains unchanged; `_sqlite_rw0_c1.py` must use existing guarded primitives and safe classifiers.
- `tests/test_c2b2_development_row_value_boundaries.py`: C1 consumes owner rows through B1 and the existing reader layer, not through new direct imports of the three owner row modules.
- `tests/test_b3c2_transition_event_readers.py` and `tests/test_b4a_global_stop_readers.py`: their reader inventories are unrelated.
- `tests/test_state_store_contract.py`: no public `StateStore` or `WriterSession` protocol method is added.
- `_worker_execution_semantic_values.py`, `_rw0_wire_protocol_values.py`, `_rw0_worker_mechanism_capability_values.py`, `_rw0_phase_entry_semantic_values.py`, and `_development_decision_row_values.py`: owner semantics remain byte-exact.
- `_sqlite_development_reader_contracts.py` and `_sqlite_development_readers.py`: their 24 queries remain byte-exact; only their external consumer inventory documentation/test changes.
- `sqlite_transition_transaction.py`: transition/global-stop and existing C2B transaction behavior remains unchanged.
- Migrations 0001, 0002, and 0003: SQL bytes and checksums remain unchanged.
- `__init__.py`, `state_store.py`, and public protocols: no export or widening.

# Findings and contradictions

The three reported conflicts are real:

1. The prior kind-14 payload violated the durable privacy owner.
2. The prior registry keys contradicted the claimed kind-scoped identity.
3. The 76-path ledger omitted two direct contract tests.

All three are resolved without changing the accepted C1/C2 decomposition.

No genuine owner contradiction was found:

- `portable_capsule_digest` already binds the complete manifest.
- C1 can attest an admission-time private relation without persisting its private operand.
- C2 can recompute cancellation control at operation time when the manifest is available.
- A committed C2 closure can later be verified by immutable digests without pretending to recompute the classifier.
- Kind-scoped keys match the actual absence of a global cross-kind ref namespace.
- Rank 14 can remain a pure NWPF classification binding.

The corrected exact implementation scope is 78 paths, not 76.

# Forecasts and stop conditions

Falsifiable forecasts:

- The most likely implementation defect is one unqualified `value_ref` or `value_digest` query/FK reintroducing a false cross-kind collision.
- The most likely privacy defect is a manifest-entry field appearing in a row builder, SQL parameter tuple, recovery probe, or database fixture.
- The most likely integration defect is stale current-tip or source/importer inventory outside the two newly recognized tests.

Freeze reconciliation is required if implementation discovers:

- a need for global cross-kind ref or digest uniqueness;
- a need to persist any capsule entry field;
- a need to change an existing owner semantic value or classifier;
- a touched path outside the exact 78 without a demonstrated causal inventory;
- inability to prove all three commit outcomes;
- a public protocol or production caller requirement.

Architectural replan is required only if C2 cannot perform the operation-time classification with a transient manifest or cannot bind the committed result without persistent capsule entries. Current evidence establishes neither contradiction.

# Recommendation

Accept the reconciled C1 contract as implementation-ready.

The implementation must use kind-qualified identities throughout, keep rank 14 NWPF-only, retain only the safe manifest projection, preserve the existing owner modules and migrations 0001–0003, and remain within the exact 78-path allowlist.

# Next implementation boundary

The next separately authorized boundary is one complete C1 implementation candidate, internally staged but accepted only as a whole:

1. Owner document and pure value/row contracts.
2. Literal migration 0004 and catalog integration.
3. Private readers and atomic persistence/recovery.
4. Private concrete-session delegation.
5. Exact status/inventory synchronization.
6. Permanent tests and an independent final audit.

No partial schema-only or persistence-only state should be accepted as a product milestone.

REPOSITORY\_MUTATION\_NOT\_PERFORMED\
TESTS\_NOT\_RUN\
STAGING\_NOT\_PERFORMED\
COMMIT\_NOT\_PERFORMED\
PUSH\_NOT\_PERFORMED\
PR\_NOT\_CREATED\
REMOTE\_CONTACT\_NOT\_PERFORMED\
WORKER\_OR\_MODEL\_NOT\_INVOKED\
SUPPORTING\_REPOSITORIES\_NOT\_MODIFIED\
IMPLEMENTATION\_NOT\_PERFORMED

RW0\_C1\_FINAL\_IMPLEMENTATION\_CONTRACT\_READY
