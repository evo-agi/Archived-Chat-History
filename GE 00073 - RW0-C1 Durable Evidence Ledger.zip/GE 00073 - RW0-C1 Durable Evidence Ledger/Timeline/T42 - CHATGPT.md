# Decision

**Proceed with a bounded findings-repair tranche. Do not reopen the RW0-C1 architecture, migration schema, or privacy model.**

This audit is materially different from the earlier provenance-only stop. It reached correctness inspection and reproduced five implementation defects:

- recovery after uncertain commit is not usable by a legitimate caller;
- `definitely_not_committed` can be returned when retry is unsafe;
- post-commit cleanup failures escape the commit-resolution algebra;
- current program/work CAS is checked too late;
- owner-reader corruption or operational failures can be mislabeled as an absent owner row. :chatgpt-content-reference{index="0"}

It also identified two genuine permanent-test gaps and one historical evidence limitation. :chatgpt-content-reference{index="1"}

No architectural replan is indicated. The independent audit passed the following major controls:

- exact provenance and the repaired 81-path candidate;
- migration `0004` at 23 tables, 46 triggers, and four indexes, with cumulative totals of 62/110/5;
- durable privacy inspection across all C1 tables with no controlled private-value leakage;
- public/API/authority non-widening;
- all five fresh focused groups;
- matching live and clean 5,157-node collections. :chatgpt-content-reference{index="2"}

The live and clean complete suites were withheld appropriately after deterministic High and Medium blockers were established. A broad passing suite would not cure these transaction and recovery failures.

## Engineering treatment

### 1. Make recovery caller-constructible

The caller must be able to retain a recovery selector **before** invoking evidence admission. It must not require a `membership_digest`, admission timestamp, receipt digest, or a direct SQLite query.

The selector should contain stable pre-apply identities:

```text
mutation_ref
command_digest
phase_basis_ref / phase_basis_digest
preassigned_membership_ref
kind_rank
value_ref / value_digest / value_schema_id
immutable prerequisite membership locators
```

On a committed recovery, the fenced recovery owner obtains the timestamp-dependent membership digest and related graph identities from the committed receipt and row family.

### 2. Tighten `definitely_not_committed`

DNC is safe only when:

- the prerequisite phase is exact;
- every immutable prerequisite membership is exact;
- the receipt and every operation-owned membership/relation identity are absent;
- the evidence registry/payload is either absent or an exact reusable value;
- there is no alias, partial payload, malformed child family, collision, or unreadable state.

Missing phase, missing prerequisite, registry aliases, partial families, or inability to prove absence must return:

```text
unresolved
```

### 3. Normalize all post-commit cleanup failures

After the underlying commit attempt begins, an ordinary exception before the complete controller/writer close proof finishes must become:

```text
commit_outcome_unknown
```

It must not become `database_integrity_failure`, `mutation_failed`, or a raw cleanup exception.

This includes failures during mutation-slot, operation-lease, controller, connection, or writer-session cleanup after a real commit.

### 4. Restore authority-check ordering

On a receipt miss, evidence admission must validate the **actual current** program/work CAS before registry, membership, prerequisite, or semantic-collision probes.

A stale caller must receive:

```text
current_state_conflict
```

before learning that a member or identity already exists.

### 5. Preserve reader failures accurately

Only a real `None` reader result maps to:

```text
owner_row_missing
```

Already-sanitized `database_integrity_failure`, `mutation_failed`, and other safe store errors must propagate unchanged.

### 6. Repair the permanent tests

The new tests must cover:

- recovery using only a pre-retained selector;
- exact reusable registry versus conflicting alias behavior;
- missing prerequisites and partial row families;
- post-commit slot/lease/cleanup failures;
- current-CAS-before-collision ordering;
- owner-reader fault propagation;
- exact temporal equality for ranks 6 and 9.

The original missing-resource red gate remains historical and non-creditable. The repair tranche must produce a genuinely causal new red gate rather than rewriting prior evidence.

## Scope

The repair is bounded to at most 17 existing candidate paths: four documents, five production files, and eight test files. Migration `0004`, `sqlite_migration.py`, the durable table schema, semantic-owner modules, and all public surfaces remain protected.

The expected successful implementation result is:

```text
COORDINATOR_RW0_C1_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

After that, commission a fresh independent audit. Do not stage or commit before it returns `ACCEPT`.

## Codex handoff

Send this prompt to the **original workspace-write RW0-C1 implementation conversation**:

:chatgpt-content-reference{index="4"}[Download the RW0-C1 independent-audit findings-repair prompt](sandbox:/mnt/data/Coordinator_RW0_C1_Independent_Audit_Findings_Repair_Prompt.txt)

```text
Filename:
Coordinator_RW0_C1_Independent_Audit_Findings_Repair_Prompt.txt

Size:
20,435 bytes

SHA-256:
14997fb3fc12307dd06a9a78795e888fe0ff4d8155a1e1c28058ab2d6a3de302
```

The independent-audit evidence root must remain read-only:

```text
/private/tmp/ge-coordinator-rw0-c1-independent-audit.bYt6vjqX

Index SHA-256:
c276c664922dc4ef87e7418c6657aaf9d61ddb05c643666019ff85c86796168e
```

### Source

- Codex’s substantive independent-audit report. :chatgpt-content-reference{index="3"}

**Confidence:** High that the five implementation findings and two test gaps are real; high that they can be repaired without schema or architectural churn; medium-high on the exact 17-path ceiling until Codex verifies all source-hash and writer-session inventory consumers at opening.
