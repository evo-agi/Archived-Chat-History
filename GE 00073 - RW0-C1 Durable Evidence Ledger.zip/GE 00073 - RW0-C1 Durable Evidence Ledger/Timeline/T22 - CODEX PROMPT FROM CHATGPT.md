PROMPT_ID

RW0_C1_FINAL_DURABLE_SCHEMA_AND_ADMISSION_CLOSURE_V1

TITLE

Coordinator RW0-C1 — final read-only reconciliation of durable schema,
evidence-admission dependencies, relation-proof semantics, and exact
implementation surface

ENGAGEMENT TYPE

Parent-only read-only contract reconciliation.

Do not modify repository files.
Do not run pytest, node collection, migrations, database commands, mutation
probes, staging, commit, push, PR, merge, release, deployment, remote contact,
product worker/model execution, dependency installation, or supporting-
repository inspection.

Print the complete substantive result inline. Evidence files may be
supplementary only.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
047563de5a443b0f8323401c92979ae2e444d2ed

tree:
4ff9ee4a710af13447e3ed8699339a51255ff720

sole parent:
dd12b23762dc761736e55a1abfde12dd3ec23551

subject:
feat: add RW0-B2 cancellation-control evidence (#6)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktree/index/untracked/unmerged:
clean

No fetch is authorized.

ACCEPTED PHASE-LEVEL DECISIONS

Preserve unless this reconciliation proves a concrete contradiction:

1. RW0-C has two non-disposable tranches:
   - C1 durable phase instance and immutable supplied-evidence membership;
   - C2 decision/terminal closure and one-way accept latch.

2. C1 is private, no-contact, supplied-fake-evidence only.

3. C1 owns:
   - exact phase establishment;
   - typed evidence membership;
   - relation/profile bindings;
   - idempotency, replay, conflict, semantic collision;
   - guarded readback;
   - exact commit-uncertainty recovery.

4. C1 owns no:
   - completeness;
   - C2B decision;
   - terminal outcome;
   - latch mutation;
   - external contact;
   - public or production caller.

5. C1 has exactly 15 evidence-member kinds unless a concrete owner
   contradiction proves otherwise.

6. The cancellation-control classifier is not a C1 member and is recomputed by
   C2 from immutable durable operands.

7. Migration 0004 is additive, generation 2, non-destructive, zero-seed, and
   contains no C2 closure/latch/decision/terminal state.

8. Existing B1, B2, C2A, C2B, Section 41, migration 0001-0003, package, public,
   and authority contracts remain unchanged.

9. The proposed typed schema direction is:
   - phase;
   - generic evidence identity;
   - phase membership;
   - relation binding;
   - ordered relation operands;
   - mutation receipts;
   - 15 kind-specific typed projections;
   - two normalized child tables.

10. Permanent tests prove finite product behavior. Independent audit owns
    external mutation, provenance, and patch identity. No self-protecting test
    architecture is permitted.

WHY THIS RECONCILIATION IS REQUIRED

The preceding report returned `RW0_C1_CONTRACT_FREEZE_READY`, but four
implementation-critical points remain unresolved:

A. A single-member admission operation is paired with multi-value relations,
   but the contract does not require every evidence operand to exist durably in
   the same phase.

B. Several member kinds do not own the relation assigned to them:
   - readiness is an operand to host qualification;
   - Capability declaration and observation are operands to qualification;
   - retrieval events are validated as an ordered prefix;
   - a cancellation response requires an admitted request;
   - result/classification wrappers depend on admitted observations.

C. Exact C1-owned schemas, digest domains, ordered fields, SQL columns,
   constraints, trigger names, error algebra, and kind ranks were not frozen.

D. The proposed 75-file ceiling is a category-level forecast, not a
   path-by-path causal ledger. It may contain speculative paths and omit
   authoritative current-tip/durable-state consumers.

PRIMARY OBJECTIVE

Return one implementation-ready C1 contract or a concrete architectural stop.

This pass must freeze:

1. evidence-admission dependency DAG;
2. exact relation-proof modes and durable operand closure;
3. exact C1-owned row/value/command/result/receipt grammars;
4. exact migration 0004 schema;
5. exact mutation/replay/recovery error algebra;
6. exact private-reader contracts;
7. exact path-by-path touched-file ceiling.

Do not implement.

REQUIRED INSPECTION

Re-read the prior required C1 reconnaissance surface, with special attention
to:

- `.docs/rw0-b1-pure-phase-values.md`
- `.docs/rw0-b2-wire-protocol.md`
- `.docs/rw0-b2-capability.md`
- `.docs/rw0-remote-worker-contact-phase-entry.md`
- `.docs/durable-state-model.md`
- `.docs/c2b-durable-development-state.md`
- `.docs/c2b2-private-readers.md`
- `.docs/sqlite-bootstrap-and-migrations.md`
- `.docs/sqlite-operations-and-recovery.md`
- `.docs/sqlite-schema-v1.md`
- `.docs/sqlite-state-backend-adr.md`

- `_rw0_phase_entry_semantic_values.py`
- `_rw0_wire_protocol_values.py`
- `_rw0_worker_mechanism_capability_values.py`
- `_worker_execution_semantic_values.py`
- `_development_pre_execution_plan_disposition_contracts.py`
- `_cognitive_proposal_row_values.py`

- `sqlite_migration.py`
- `sqlite_transition_transaction.py`
- `sqlite_writer_session.py`
- `_sqlite_development_reader_contracts.py`
- `_sqlite_development_readers.py`
- migration 0002 and 0003 resources
- direct migration, reader, transaction, recovery, status, architecture, and
  source-inventory tests.

Inspect every file containing a literal terminal migration, expected table/
trigger/index/source inventory, RW0-C status, private-consumer inventory, or
production-source allowlist before freezing the touched-file ceiling.

A. ADMISSION DEPENDENCY DAG

For each of the 15 member kinds, classify admission as exactly one:

```text
standalone_value
requires_same_phase_members
requires_existing_owner_rows
requires_transient_private_operands
wrapper_over_same_phase_members
wrapper_over_existing_owner_rows
```

Freeze the exact prerequisites and their transaction-time lookup order.

At minimum resolve:

1. authority observation;
2. subordinate proposal;
3. custody observation;
4. retrieval event:
   - exact admitted prefix requirements;
   - predecessor and sequence constraints;
5. remote host readiness:
   - whether it is standalone structural evidence;
   - do not claim host qualification merely because readiness is admitted;
6. host qualification:
   - exact required admitted authority/readiness members;
7. Capability declaration:
   - standalone supplied claim;
8. Capability observation:
   - exact declaration dependency, if any;
9. Capability qualification:
   - exact admitted declaration, observation, authority, readiness, and host-
     qualification dependencies;
10. Wire cancellation request;
11. Wire process observation;
12. C2A WorkerObservation:
    - cancellation acknowledgement/rejection must require the exact admitted
      request;
13. Wire worker-result binding:
    - exact admitted observation sequence prerequisites;
14. Wire process-result classification binding:
    - exact admitted result/request/adapter/process/cancellation prerequisites;
15. Section 41 wrapper:
    - exact existing owner-row prerequisite.

No relation binding may reference a C1 evidence operand that is neither:

- already admitted under the same phase; nor
- inserted atomically by the same mutation under an explicitly frozen grouped
  admission operation; nor
- an immutable existing owner row resolved by an exact private reader; nor
- a named transient private operand permitted only for admission-time proof and
  explicitly unavailable for later recomputation.

The default operation remains single-member admission. Add a grouped admission
operation only if an owning relation makes it unavoidable; justify it as a
non-disposable capability rather than convenience.

Return the exact topological admission order and all legal partial states.

B. RELATION-PROOF MODES

Freeze a closed proof-mode vocabulary. Evaluate at least:

```text
value_reconstructed
relation_recomputable
relation_attested_at_admission
derived_wrapper_recomputable
existing_owner_row_reconstructed
```

For every member kind and phase establishment, specify:

- proof mode;
- exact relation ID and version;
- profile pair, if any;
- exact ordered operand roles;
- which operands are same-phase members;
- which are existing owner rows;
- which are transient private values;
- whether replay/readback can rerun the relation;
- whether C2 can recompute the relation/classifier;
- exact durable fields that prevent a free-standing truth Boolean.

Clarify:

- phase establishment may retain an admission-time proof because raw WorkSpec
  is not persisted;
- cancellation-control classification must remain recomputable from admitted
  immutable operands;
- host and Capability qualification proofs must not be attached to declaration
  or readiness members in a way that implies qualification;
- an old relation version is immutable evidence and is never silently
  reinterpreted.

C. RELATION COUNT AND SET DIGEST

The prior command allowed one-to-three relation requests, which is incompatible
with standalone values and some wrappers.

Freeze:

- exact minimum/maximum relation count per member kind;
- whether zero relations is legal;
- relation-set ordering;
- relation-set digest domain;
- duplicate relation rejection;
- relation-ref/digest uniqueness;
- exact membership binding to the relation set;
- exact behavior when one prerequisite relation is missing.

D. EXACT KIND RANKS AND SCOPE

Freeze exact numeric `kind_rank` values 1-15 and the ordered kind inventory.

For each kind state whether the semantic identity is:

- globally reusable across phases;
- intrinsically phase-bound because the owner value contains the phase pair;
- K8-bound;
- existing-owner-row-bound.

Freeze global registry uniqueness and phase-membership uniqueness accordingly.
Do not assume every value is safely reusable across phases merely because a
generic registry exists.

E. EXACT C1-OWNED VALUE GRAMMARS

Freeze exact schema IDs, digest domains, ordered fields, and finite enums for:

- C1 phase durable row value/projection;
- evidence identity registry row;
- phase membership row;
- relation binding row;
- relation operand row;
- phase-establishment command;
- evidence-admission command;
- phase-establishment result;
- evidence-admission result;
- mutation receipt;
- kind 13 worker-result binding;
- kind 14 process-result classification binding;
- kind 15 Section 41 wrapper;
- recovery result/disposition, if represented as a private value.

For each define:

- exact built-in field types;
- optional-pair algebra;
- identity/self-digest exclusion;
- canonical JSON rules;
- immutability/copy/pickle/repr/error boundary consistent with current private
  row-value contracts;
- safe outward projection;
- no hidden payload.

Do not leave schema names, domains, field order, or result/reason vocabulary to
implementation judgment.

F. EXACT ERROR AND DISPOSITION ALGEBRA

Freeze finite outward/private reasons for:

- invalid command/value;
- relation failure;
- writer/session/fence failure;
- mutation-ref reuse;
- phase identity collision;
- K8 collision;
- current-state CAS conflict;
- member identity collision;
- member already admitted;
- missing prerequisite member;
- relation identity collision;
- owner-row missing/corrupt;
- database integrity;
- mutation failed;
- commit outcome unknown;
- recovery committed exact;
- recovery definitely not committed;
- recovery unresolved.

State which existing error type is reused and which C1-private error/value is
needed. Keep errors content-free.

G. EXACT SQL SCHEMA

For every proposed table freeze:

- exact table name;
- exact ordered columns;
- exact SQL type (`ANY`);
- nullability;
- every CHECK;
- primary key;
- UNIQUE constraints;
- every FK and action;
- trigger names and exact invariant;
- explicit indexes and exact columns/predicates;
- seed rows;
- authoritative writer.

Prove or revise the 23-table / 46-trigger / 4-index design.

At minimum specify exact one-to-one constraints between:

- evidence registry and kind-specific payload;
- membership and evidence identity;
- relation binding and dense operands;
- receipt and operation-owned family.

State why each table cannot be combined with another without losing typed
privacy, collision detection, or recovery precision.

No generic JSON/BLOB payload is allowed.

H. EXACT PHASE SCHEMA

The phase table is the largest row. Freeze every ordered column rather than
referring to “flattened B1 projection and L34.”

Specify:

- all B1 basis fields;
- all L34 fields;
- K8 derivation;
- program/work CAS fields;
- establishment fields;
- relation binding;
- graph/row digests;
- all CHECK/UNIQUE/FK rules;
- which current-head/global-stop values are copied as immutable observations
  versus referenced owner rows.

I. EXACT TYPED TABLE SCHEMAS

For each of the 15 typed projections, freeze every column and normalized child
table mapping.

Resolve:

- whether schema_id/member ref/member digest are repeated in payload tables;
- composite FK to registry;
- one-to-one enforcement;
- exact nullable fields;
- exact enum/check constraints;
- child-table ordinal/rank constraints;
- global reuse versus phase-bound data.

J. COMMAND, REPLAY, AND RECOVERY PREREQUISITES

Freeze admission prerequisites within the transaction:

- receipt-first lookup;
- phase lookup;
- prerequisite member/owner-row lookup;
- collision probes;
- relation evaluation;
- writes;
- receipt last;
- capability invalidation;
- one commit.

For exact replay:

- command digest includes all transient operands;
- same command may replay without rerunning non-recomputable relation proofs;
- replay must still verify the complete durable row family and all prerequisite
  dependency locators.

For recovery, add dependency-DAG checks to committed/absent/unresolved.

State how an exact reusable global evidence value can preexist without making a
new phase membership ambiguous.

K. C2 RECOMPUTATION GUARANTEE

List the exact C1 durable operands C2 will later use to recompute:

- cancellation-control classification;
- decision-basis closure;
- terminal-basis closure.

Prove that every required C1 evidence operand is durably reconstructible. A
relation operand row containing only a ref/digest to an unpersisted supplied
claim is insufficient.

State which admission-time proofs are intentionally not recomputable and why
C2 does not need to rerun them.

L. PRIVATE READERS

Freeze exact SQL statements or exact column/order/cardinality contracts for:

- receipt;
- phase by ref/pair/digest/K8;
- evidence by ref/digest;
- typed payload;
- membership;
- relation set and operands;
- dependency/precondition lookup;
- bounded ordered member page;
- graph/result recovery;
- Section 41 owner lookup.

State exact maximum rows and `LIMIT` values. Confirm the operand limit covers
every frozen relation.

M. CAUSAL TOUCHED-FILE LEDGER

Replace the category-level 75-file forecast with a path-by-path ledger.

For every proposed touched path include:

```text
path
must_change | conditional | protected
exact stale literal/inventory/contract
exact intended change
owning contract
test or source that would fail if omitted
```

Requirements:

1. Search all current references to:
   - terminal migration 0003;
   - application generation;
   - expected table/trigger/index inventory;
   - production source inventory;
   - private consumer/importer inventory;
   - RW0-C future status;
   - migration-resource glob/count/checksum;
   - coherent fixture schema.

2. Explain inclusion of `AGENTS.md` and `README.md`, or remove them.

3. Explicitly classify central inspected documents omitted from the prior
   ceiling, including:
   - `.docs/c2b-durable-development-state.md`;
   - `.docs/c2b2-pure-durable-row-values.md`;
   - `.docs/c2b3-program-initialization.md`;
   - any current-tip test outside the prior 32-file list.

4. Do not touch historical/planned prose merely because it mentions “0003.”
   Distinguish current authority from historical or superseded target text.

5. Return:
   - exact must-change set;
   - exact conditional ceiling, with the predicate that activates each path;
   - exact protected set.

The implementation prompt must use the must-change set plus only activated
conditional paths, not a speculative 75-file allowance.

N. IMPLEMENTATION DECOMPOSITION

Recommend how to execute C1 without turning partial schema work into an
accepted product milestone.

Evaluate:

- one workspace-write tranche with internal stages and one final candidate;
- two implementation passes on one branch, still audited/accepted only as the
  complete C1 capability;
- any safer integration order.

Do not create a new strategic C1a product tranche unless it has an independently
useful durable capability.

O. FORECASTS AND STOP CONDITIONS

Record two or three falsifiable forecasts.

Return `RW0_C1_FREEZE_RECONCILIATION_REQUIRED` if any remains unresolved:

- member dependency DAG;
- relation-proof mode;
- exact schemas/digest domains;
- exact SQL constraints;
- recovery dependency closure;
- C2 recomputation operands;
- path-by-path touched-file ledger.

Return `RW0_C_ARCHITECTURAL_REPLAN_REQUIRED` only for a genuine owner,
decomposition, privacy, transaction, or recovery contradiction.

OUTPUT

Print inline:

# Baseline and inspection boundary
# Accepted C1 architecture
# Admission dependency DAG
# Relation-proof modes
# Exact kind ranks and scope
# C1-owned value grammars
# Error and disposition algebra
# Exact migration 0004 schema
# Exact phase and typed table schemas
# Transaction, replay, and recovery closure
# C2 recomputation guarantee
# Private reader contracts
# Causal touched-file ledger
# Implementation decomposition
# Findings and contradictions
# Forecasts and stop conditions
# Recommendation
# Next implementation boundary

End with exactly one:

RW0_C1_FINAL_IMPLEMENTATION_CONTRACT_READY

RW0_C1_FREEZE_RECONCILIATION_REQUIRED

or

RW0_C_ARCHITECTURAL_REPLAN_REQUIRED

Do not issue an implementation prompt.

Required final statements:

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
