# Engineering disposition

**Accept the strategic reconciliation, but do not authorize implementation yet.**

The core architecture is now sound:

- preserve the complete existing `rw0-wire-nwpf-v1` contract;
- add a separate private Wire-owned cancellation-control evidence profile;
- reuse the existing request and process observation values;
- keep worker-result and process-result classification v1-only;
- support the exact current author, validation, or review target;
- require the exact capsule manifest only for validation/review;
- derive the cancellation-control classification in C2 rather than persist it as a sixteenth C1 member;
- leave Capability, B1, C2A, RW0-D/E, and ES ownership unchanged.

That is the right pre-C repair. The proposal is additive rather than a reinterpretation of merged semantics.

## Why the contract is not implementation-ready

### 1. The proposed 10-file ceiling is mechanically wrong

The merged Capability boundary test freezes the Wire source as protected content:

```text
tests/test_rw0_b2_capability_boundaries.py:118

P01
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
77003 bytes
6bf39f634b619829fcc4cc7ada5cf019b40b3c5a2258947ebee8fdfe2a13031e
```

Any legitimate change to `_rw0_wire_protocol_values.py` will fail that permanent test unless P01’s size and digest are updated.

The minimum expected ceiling is therefore **11 files**, not 10:

```text
6 governing/status documents
1 Wire source module
3 new dedicated test modules
1 bounded Capability-boundary compatibility update
```

The Capability test change should be restricted to the final P01 size and SHA-256. That is an intentional protected-owner compatibility update, not Capability semantic churn.

### 2. The exact profile identity is not frozen

The response chose the schema, profile ref, and digest domain, but did not provide:

- the complete ordered manifest literal;
- exact key inventory;
- exact scalar/container types;
- canonical manifest bytes;
- byte length;
- final profile digest.

Those must be frozen before implementation so tests do not merely canonize whatever structure the implementation happens to produce.

### 3. The classification vocabulary remains unnecessarily ambiguous

The proposed:

```text
invalid
unusable
usable
```

would classify `cancellation_rejected` as `usable`. That can be defined consistently, but it overloads “usable” from the existing worker-result classifier and invites downstream confusion with successful cancellation.

Because this is a new value with no compatibility burden, the cleaner target is:

```text
invalid
incomplete
finite
```

with:

```text
invalid:
invalid_input
duplicate_fact
unrelated_fact
conflicting_fact
cancellation_graph_mismatch

incomplete:
process_evidence_incomplete
resource_limit_exceeded
deadline_elapsed
signal_delivered
cancellation_acknowledged
cancellation_request_pending

finite:
cancellation_rejected
target_process_exited
```

`finite` would mean only that the supplied control graph has reached a bounded result suitable for later C2 reasoning. It would not mean semantic cancellation, teardown, terminality, permission, or acceptance.

The final freeze should either adopt that vocabulary or provide a stronger source-grounded reason to retain `usable/unusable`.

### 4. Safe reconstruction and work bounds remain underspecified

The current Wire module imports C2A’s omitted sentinel as `_C2A_MISSING`. The final contract should use that exact sentinel unless a distinct one is demonstrably required. (`src/ge_nwp_coordinator/_rw0_wire_protocol_values.py:12-21`)

More importantly, C2A already owns exact raw-slot, bounded reconstruction for `CandidateCapsuleManifestV1` and its nested `CapsuleEntryV1` graph:

```text
src/ge_nwp_coordinator/_worker_execution_semantic_values.py:2230-2447
```

That owner helper already assigns the manifest an exact graph-work tariff and handles raw slots, tuple cardinality, cycle detection, aliases, nested entry reconstruction, and fresh validated projection. Reusing it through a new additive private import is preferable to:

- widening the existing v1 `_C2A_FIELD_INVENTORIES`;
- duplicating capsule reconstruction inside Wire;
- or invoking supplied public behavior on an untrusted object.

The final freeze still needs exact:

- relation-local work limits;
- classifier-local work limits;
- maximum-valid and one-under controls;
- tuple and fact cardinalities;
- alias/cycle treatment;
- foreign-exception sanitization;
- integer preconversion guarantees.

### 5. Status integration must be proven against current literal tests

Existing tests pin current Wire status phrases and require five synchronized document projections. For example:

```text
tests/test_rw0_b2_wire_boundaries.py:499-532
tests/test_architecture_contracts.py:1071-1087
tests/test_software_development_progression_boundary.py:603-619
tests/test_rw0_remote_contact_phase_entry_contract.py:947-955
```

The new profile can probably be added while preserving those exact phrases and extending all five synchronized bodies identically. That needs to be shown explicitly before fixing the touched-file ceiling. A hidden requirement to edit an existing status test should not surface during implementation.

# Next step

Run one final **read-only implementation-contract freeze**. It is not another architecture replan and does not reopen the accepted additive profile decision. Its purpose is to freeze the exact profile bytes, APIs, bounds, test surface, and corrected file ceiling.

Send this prompt to the current Coordinator conversation:

:chatgpt-content-reference{index="1"}

```text
Filename:
Coordinator_RW0_B2_Cancellation_Control_Final_Contract_Freeze_Prompt.txt

Size:
18,630 bytes

SHA-256:
61610430fcdffce58ff738556c194ba6c842ded5006564a986d00f18265a28d0
```

The required successful result is:

```text
RW0_B2_CANCELLATION_FINAL_CONTRACT_FREEZE_READY
```

Only after that result should we issue the parent-only implementation prompt.

## Current decision ledger

```text
Additive separate cancellation-control profile:
accepted

Existing NWPF v1 preservation:
required

Existing request/process values reused unchanged:
accepted, pending exact relation freeze

Existing worker result and classifier remain v1-only:
required

Capability changes:
not allowed

B1/C2A changes:
not allowed

C1 evidence-member count:
remains 15

Cancellation classification persistence:
C2-derived closure projection, not a C1 member

Current touched-file ceiling:
not 10; minimum expected 11

RW0-C implementation:
still blocked until this B2 tranche is implemented, audited, and merged
```

### Sources

- Codex’s read-only cancellation-owner reconciliation supplied in this turn.
- Merged Coordinator snapshot: `Governed Execution Coordinator - Snapshot - 2026-09-26.zip`. 
- `tests/test_rw0_b2_capability_boundaries.py:118, 145-174`
- `src/ge_nwp_coordinator/_rw0_wire_protocol_values.py:12-21, 477-574, 955-1115, 1680-1905`
- `src/ge_nwp_coordinator/_worker_execution_semantic_values.py:638-724, 1935-2205, 2230-2447, 3748-4085, 4240-4365`
- `tests/test_rw0_b2_wire_boundaries.py:499-532`
- `tests/test_architecture_contracts.py:1071-1087`
- `tests/test_software_development_progression_boundary.py:603-619`

**Confidence:** High in the additive profile and ownership decision; high that the touched-file ceiling must include the Capability boundary test; medium-high that the remaining exact profile, work-budget, and status questions can be closed in one bounded read-only pass.

Some older uploaded project artifacts have expired from the accessible file surface. The current merged Coordinator snapshot was available and inspected; an older artifact only needs re-uploading if a later decision specifically depends on it.
