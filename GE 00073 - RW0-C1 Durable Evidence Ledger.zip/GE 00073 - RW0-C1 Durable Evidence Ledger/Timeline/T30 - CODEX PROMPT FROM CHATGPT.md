PROMPT_ID

RW0_C1_TEMPORAL_AND_MUTABLE_SNAPSHOT_CLOSURE_V1

TITLE

Coordinator RW0-C1 — close relation evaluation-time semantics and immutable
attestation of mutable current-row snapshots

ENGAGEMENT TYPE

Final narrow parent-only, read-only contract reconciliation.

Do not implement, edit, format, stage, commit, push, create a PR, merge, run
tests, collect nodes, execute migrations, open a database, fetch, contact a
remote/live system, install dependencies, invoke a product worker/model, or
inspect another repository.

Print the complete substantive result inline. Evidence files may be
supplementary only.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
047563de5a443b0f8323401c92979ae2e444d2ed

tree:
4ff9ee4a710af13447e3ed8699339a51255ff720

sole parent:
dd12b23762dc761736e55a1abfde12dd3ec23551

subject:
feat: add RW0-B2 cancellation-control evidence (#6)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktree/index/untracked/unmerged:
clean

No fetch is authorized.

ACCEPTED CONTRACT THAT IS NOT REOPENED

Preserve the complete latest RW0-C1 contract except where this prompt identifies
two missing durable semantics.

Frozen:

1. C1/C2 decomposition.
2. C1 private no-contact durable phase and evidence capability.
3. Exactly 15 evidence kinds and the frozen dependency DAG.
4. Single-member admission.
5. Stable membership_ref/membership_digest identity.
6. Same-phase membership FK for C1-evidence operands.
7. Rank 13 actual worker-result binding only.
8. Rank 14 present | finite_failure | absent.
9. Maximum two member relations; relation_rank 0|1; reader LIMIT 3.
10. phase_basis_ref/phase_basis_digest vocabulary.
11. Existing _CoordinatorMutationTransactionController as the sole transaction
    authority.
12. Kind-scoped evidence identity.
13. Safe capsule binding only; no capsule entries or complete manifest in
    SQLite.
14. C2 operation-time transient manifest and later durable classification
    attestation.
15. Phase establishment represented in the common relation tables.
16. Closed transient_private_binding kinds:
    work_spec, candidate_capsule_manifest, before_blob_set, after_blob_set,
    wire_protocol_error.
17. Additive generation-2 migration 0004, zero seed, no C2 state.
18. 23 new tables, 46 immutable triggers, 4 new explicit indexes and cumulative
    62/110/5, unless this closure proves a count change.
19. Exact 81-path implementation allowlist, unless this closure finds one
    direct causal consumer.
20. Existing owner semantics, migrations 0001–0003, public APIs, package
    exports, and supporting repositories remain unchanged.

WHY THIS CLOSURE IS REQUIRED

A. TIME-SENSITIVE RELATIONS HAVE NO DURABLE EVALUATION INSTANT

The current owner functions require `now_utc` for:

- validate_authority_observation;
- validate_subordinate_narrowing;
- validate_custody_binding;
- validate_retrieval_event_sequence;
- validate_host_qualification;
- validate_worker_mechanism_capability_qualification.

The latest `rw0_relation_bindings` schema has no `evaluated_at` and the response
does not freeze which timestamp is passed to those functions.

Without an exact persisted evaluation instant:

- a recomputable relation cannot be rerun deterministically;
- replay may use a later clock and convert a formerly valid observation into an
  expired one;
- relation digests do not bind the temporal predicate that was actually
  evaluated;
- recovery cannot distinguish the historical attestation from a fresh
  reevaluation.

B. PHASE RELATION OPERANDS INCLUDE MUTABLE CURRENT ROWS

The phase owner relation consumes:

- DevelopmentPreExecutionSelectionHeadRowValue;
- DevelopmentEffectHeadRowValue;
- DevelopmentDeliveryHeadRowValue;
- GlobalStopCurrentRecordEnvelope.

Those are current-state snapshots, not durable immutable owner rows:

- `development_pre_execution_selection_heads` is updated in place by the
  current disposition mutation;
- `development_effect_heads` and `development_delivery_heads` are head tables
  without immutable no-update guards and are intended progression heads;
- `global_stop_current` is a mutable singleton.

The latest phase relation classifies them as `existing_owner_row` and requires
recovery to resolve the same rows later. Normal progression or a global-stop
update would then make an already committed phase appear corrupt or
unrecoverable.

The phase row already copies the semantically relevant revisions, states and
digests. C1 needs an immutable admission-time snapshot binding, not a permanent
claim that the mutable current row remains unchanged.

C. `operand_scope_digest` IS UNDEFINED FOR ORDINARY IMMUTABLE OWNER ROWS

The latest operand branch requires a non-null `operand_scope_digest` for
`existing_owner_row`, but most immutable owner rows have no generic owner-
defined scope digest. The contract must define the field by source branch
rather than leaving implementation to invent one.

PRIMARY OBJECTIVE

Return one exact correction that closes:

1. temporal evaluation semantics;
2. immutable binding of mutable current-row snapshots;
3. operand scope-digest branch rules;
4. resulting phase relation, replay, recovery, DDL, reader and touched-path
   consequences.

Do not reopen any other C1 decision.

REQUIRED INSPECTION

Inspect completely or in every relevant owning section:

- `_rw0_phase_entry_semantic_values.py`, especially:
  - validate_phase_entry_basis;
  - validate_authority_observation;
  - validate_subordinate_narrowing;
  - validate_custody_binding;
  - validate_retrieval_event_sequence;
  - validate_host_qualification.
- `_rw0_worker_mechanism_capability_values.py`, especially
  validate_worker_mechanism_capability_qualification.
- migration 0001 global_stop_current/global_stop_events.
- migration 0002 program/work/effect/delivery heads.
- migration 0003 selection head and disposition/receipt tables.
- `_sqlite_development_pre_execution_plan_disposition.py`, especially the
  selection-head update.
- current head/global-stop readers.
- the latest accepted C1 phase row, relation row, operand row, transaction,
  replay and recovery contracts.
- every existing test or document that pins current-head/history behavior,
  relation fields, or C1 source inventories.

A. FREEZE ONE RELATION EVALUATION INSTANT

Preferred contract unless repository evidence disproves it:

1. Capture one canonical whole-second UTC `operation_timestamp` after all
   prerequisite reads and immediately before the first owner relation
   invocation.

2. For evidence admission:
   - `membership.admitted_at = operation_timestamp`;
   - every relation belonging to that membership uses that same timestamp;
   - every owner `now_utc` parameter receives exactly that timestamp.

3. Add to `rw0_relation_bindings`:

```text
evaluated_at
```

as an exact canonical UTC timestamp or NULL.

4. `evaluated_at` is non-null exactly for relation IDs that consume `now_utc`,
   including:
   - authority observation;
   - subordinate narrowing;
   - custody binding;
   - retrieval event sequence;
   - host qualification;
   - worker-mechanism capability qualification.

5. It is NULL for:
   - phase establishment;
   - structural declaration/observation binding;
   - Wire request/process/response relations;
   - C2A observation relations;
   - worker-result and process-result classifiers;
   - Section 41 owner reconstruction;
   - every relation that has no time parameter.

6. Freeze the exact relation-ID-to-temporal-posture mapping. Do not infer it
   from a substring.

7. Include `evaluated_at` in:
   - relation semantic digest;
   - relation row digest;
   - relation-set/readback verification;
   - replay and recovery.

8. Recomputable/derived relations rerun with the persisted `evaluated_at`,
   never the current clock.

9. Admission-time attestations that used a time parameter retain the timestamp
   but are not rerun without their private operand.

10. Phase establishment has `evaluated_at = NULL`; `established_at` remains the
    phase transaction timestamp, not a fabricated owner `now_utc`.

If instead membership `admitted_at` alone is the relation evaluation instant,
prove that every relation digest and reader binds it unambiguously and that no
relation row can be detached from that membership. Do not leave the mapping
implicit.

B. FREEZE MUTABLE SNAPSHOT OPERAND SEMANTICS

Do not treat mutable current rows as durable `existing_owner_row` operands.

Add one exact operand source, preferred name:

```text
admission_snapshot_binding
```

or provide an equally explicit closed alternative.

It must have a closed binding-kind inventory:

```text
selection_head_snapshot
effect_head_snapshot
delivery_head_snapshot
global_stop_snapshot
```

For each freeze:

- schema ID;
- semantic ref rule;
- digest domain;
- exact safe fields included in the digest;
- exact scope digest;
- relation operand role;
- how admission compares it to the live current row before writes;
- how the same binding is reconstructed from the immutable C1 phase row later;
- why normal progression does not invalidate it.

Expected semantic content:

1. selection_head_snapshot

Bind only fields used by validate_phase_entry_basis and exact row identity:
- program/effect identity or exact composite owner key;
- current proposal ref;
- current disposition ref and value;
- head revision;
- head digest;
- any owner timestamp only if required by the owner row digest contract.

The phase row already stores or can deterministically reconstruct these safe
facts from its frozen lineage/selection fields. Do not require the live
selection-head row after admission.

2. effect_head_snapshot

Bind:
- program ref;
- effect-intent ref;
- current effect-fence ref if needed for exact owner-row identity;
- head revision;
- effect state;
- nullable cancellation-effect-intent ref where applicable;
- head digest.

The phase basis already freezes revision/state/digest and lineage identity.

3. delivery_head_snapshot

Bind:
- program ref;
- effect-intent ref;
- current delivery-attempt ref;
- head revision;
- delivery state;
- head digest.

The phase basis/L34 already freezes the required identity and revision/state/
digest.

4. global_stop_snapshot

Bind only the B1 relation’s safe semantics:
- schema ID;
- stop ref;
- version;
- active/clear state;
- a C1 snapshot digest.

Do not persist operator reason, issuer, authorization body, or any private
material not consumed by validate_phase_entry_basis.

The phase row must contain every field needed to reconstruct these four
bindings. If one field is currently absent from the frozen phase schema, add
that exact safe field and recompute the phase-row contract. Do not read a
mutable current row during replay or committed recovery.

C. REVISE THE 14 PHASE OPERANDS

Keep `operand_count = 14` unless exact owner arguments require otherwise.

Classify the phase operands exactly:

Immutable existing owner rows:
- selection disposition;
- cognitive mutation receipt;
- selected proposal;
- selected artifact;
- WorkSpec safe binding;
- attempt fence;
- author effect fence;
- author command;
- author delivery.

Transient private binding:
- full WorkSpec.

Admission snapshot binding:
- selection head;
- effect head;
- delivery head;
- global stop current.

Verify that these 14 bindings reconstruct all arguments of
`validate_phase_entry_basis(...)`, including L34 lineage and selection result.

Freeze each operand role, source, schema, ref, digest and scope posture.

D. FREEZE OPERAND-SCOPE RULES

The final `rw0_relation_operands` branch rules must state:

```text
c1_evidence:
  operand_scope_digest = exact membership scope_binding_digest

existing_owner_row:
  operand_scope_digest IS NULL
  immutable owner role/schema/ref/digest/locator are sufficient

transient_private_binding:
  operand_scope_digest is non-null and defined by the closed transient kind

admission_snapshot_binding:
  operand_scope_digest is non-null and defined by the closed snapshot kind
```

Do not invent a generic scope digest for immutable owner rows.

Update the branch CHECKs, nullable columns, digest preimages, reader shapes and
same-phase FKs accordingly.

E. REPLAY AND RECOVERY

Freeze:

1. Committed phase recovery verifies:
   - phase row;
   - deterministic phase relation;
   - all 14 operands;
   - nine immutable owner-row bindings;
   - one transient WorkSpec binding;
   - four admission snapshot bindings reconstructed from the phase row;
   - relation/operand-set/relation-set/phase-graph/result/receipt digests.

2. It does not require:
   - the mutable selection/effect/delivery head rows to retain their old
     values;
   - global_stop_current to retain its old version/state;
   - program/work heads to remain at their original CAS preimages.

3. `definitely_not_committed` proves absence of operation-owned identities.
   Later progression of mutable heads affects a future retry’s CAS outcome but
   does not manufacture a committed phase or prevent proving absence.

4. Member relation replay/recovery:
   - uses persisted evaluated_at for every recomputable time-sensitive
     relation;
   - verifies attested timestamps without rerunning missing private inputs;
   - never uses the current wall clock.

F. SQL, COUNTS, READERS AND PATHS

Return the exact revised ordered columns and CHECK/FK branches for:

- `rw0_relation_bindings`;
- `rw0_relation_operands`;
- any phase-row fields added for snapshot reconstruction.

State whether the frozen counts remain:

```text
23 new tables
46 new triggers
4 new explicit indexes
62 cumulative tables
110 cumulative triggers
5 cumulative explicit indexes
```

State whether the exact 81-path ledger remains sufficient.

Search for any direct test/document that pins:
- relation binding columns;
- operand-source enum;
- phase-row fields;
- temporal relation behavior;
- head/global-stop historical recovery;
- source inventories affected by this closure.

Add a path only for a direct causal failure; otherwise preserve the 81-path
allowlist.

G. IMPLEMENTATION READINESS

Return `RW0_C1_IMPLEMENTATION_CONTRACT_READY` only if:

- every time-sensitive relation has an exact persisted evaluation instant;
- historical relation verification never uses the current clock;
- mutable current rows are represented as immutable admission snapshots;
- committed recovery survives legitimate head/global-stop progression;
- ordinary immutable owner-row operands have no undefined scope digest;
- SQL, digest, reader, replay, recovery, counts and paths are exact.

Return `RW0_C1_FREEZE_RECONCILIATION_REQUIRED` if any exact timestamp,
snapshot, digest, DDL, recovery or path detail remains open.

Return `RW0_C_ARCHITECTURAL_REPLAN_REQUIRED` only for a genuine accepted-
architecture contradiction.

OUTPUT

Print inline:

# Baseline and inspection boundary
# Preserved C1 architecture
# Relation evaluation-time contract
# Mutable current-row snapshot bindings
# Revised phase operand closure
# Final operand-source and scope algebra
# SQL and digest consequences
# Replay and recovery under later progression
# Table/count/path consequences
# Findings and contradictions
# Forecasts and stop conditions
# Recommendation
# Next implementation boundary

End with exactly one:

RW0_C1_IMPLEMENTATION_CONTRACT_READY

RW0_C1_FREEZE_RECONCILIATION_REQUIRED

or

RW0_C_ARCHITECTURAL_REPLAN_REQUIRED

Do not issue an implementation prompt.

Required final statements:

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
