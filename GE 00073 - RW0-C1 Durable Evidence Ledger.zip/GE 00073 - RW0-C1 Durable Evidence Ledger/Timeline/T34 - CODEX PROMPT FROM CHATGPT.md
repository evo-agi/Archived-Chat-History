PROMPT_ID

RW0_C1_DURABLE_EVIDENCE_IMPLEMENTATION_V1

TITLE

Coordinator RW0-C1 — implement private durable phase establishment and typed
supplied-evidence membership with replay, guarded readback, and exact
commit-uncertainty recovery

ENGAGEMENT TYPE

Authorized parent-only workspace-write implementation in the same Codex
conversation that produced the complete RW0-C1 read-only contract.

You are the sole writer. Do not create or delegate to subagents.

Implement the complete C1 capability. Do not stop after schema, pure values,
readers, or transaction scaffolding. No intermediate pass is an accepted
product milestone. The final candidate must contain the complete migration,
private semantics, readers, atomic persistence, replay/conflict handling,
three-way recovery, writer-session delegation, documentation/status
synchronization, permanent tests, validation, cleanup, and exact provenance.

Do not stage, commit, push, create a PR, merge, tag, release, or deploy.
Do not fetch or contact a remote.
Do not contact Bridge, Execution Substrate, a worker, provider, host, verifier,
custodian, or supporting repository.
Do not install dependencies.
Do not invoke a product worker/model.
Do not modify or migrate an operator database; all database validation must use
new disposable external database files under the evidence root.
Do not expose secrets or private SQLite contents.

Print the complete substantive implementation report inline. Evidence paths may
be supplementary only. Do not put the operative result only in a file.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED OPENING BASELINE

Before editing require exactly:

branch:
trunk_dev

HEAD:
047563de5a443b0f8323401c92979ae2e444d2ed

tree:
4ff9ee4a710af13447e3ed8699339a51255ff720

sole parent:
dd12b23762dc761736e55a1abfde12dd3ec23551

subject:
feat: add RW0-B2 cancellation-control evidence (#6)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

worktree/index/untracked/unmerged:
clean

Git operation/lock:
none

repository cache/bytecode/database/journal/archive/build/recorder residue:
none

No fetch is authorized. Compare only local Git metadata.

OPENING NODE BASELINE

Before edits run one isolated collection and require exactly:

unique nodes:
5087

ordered SHA-256:
fe756529f88a3c44c31a402d2266b00b14993f420b76fa2af15595103599580c

No duplicate or unmapped nodes, no warnings, empty stderr.

If repository identity or opening node identity differs, stop before editing
with:

RW0_C1_IMPLEMENTATION_BASELINE_MISMATCH

BRANCH

Create and work only on:

codex/rw0-c1-durable-evidence-v1

from the exact baseline above.

If that branch already exists, another worktree exists, or the branch cannot be
created without absorbing unrelated work, stop.

OBJECTIVE

Implement the smallest non-disposable RW0-C1 durable capability:

1. Establish one immutable no-contact RW0 phase instance from an exact
   RW0PhaseEntryBasisV1 and current durable owner state.
2. Admit exactly one typed supplied-evidence member per mutation under the
   frozen 15-kind inventory.
3. Persist exact phase-specific membership, relation/profile proof, ordered
   operand closure, result, and receipt identities.
4. Provide exact idempotency, replay, conflict, semantic-collision, guarded
   private readback, and commit-uncertainty recovery.
5. Preserve privacy and authority boundaries.
6. Make no claim of evidence completeness, source authenticity, permission,
   acceptance, terminality, current execution authority, or external contact.

C1 is accepted only as the full capability. It is not a schema-only or
persistence-only milestone.

CONTRACT PRECEDENCE

All reconciled read-only decisions in the preceding conversation are binding.
Where an older turn conflicts with a newer turn, use this precedence:

1. This implementation prompt and the final two-clock correction.
2. Temporal and mutable-snapshot closure.
3. Phase-proof and transient-private-operand closure.
4. Durable-identity and transaction-authority closure.
5. Privacy, kind-scoped identity, and touched-scope closure.
6. Earlier C1 phase-level and schema reconnaissance.

The following superseded proposals are forbidden:

- full capsule entries or complete CandidateCapsuleManifestV1 in SQLite;
- global cross-kind uniqueness of value_ref or value_digest;
- memberships without membership_ref/membership_digest;
- relation operands that bind only a global evidence value rather than an exact
  same-phase membership;
- rank 14 requiring a rank-13 result in every branch;
- more than two member relations or LIMIT 4 relation reads;
- phase_ref/phase_digest as unexplained semantic names;
- a second transaction controller or connection authority;
- mutable current-head rows as historical recovery dependencies;
- a generic scope digest on immutable owner rows;
- universal equality of relation.evaluated_at and membership.admitted_at;
- C2 classification, decision, latch, completeness, or terminal state in C1.

CURRENT AND FUTURE OWNERSHIP

Current implemented pure private owners remain unchanged:

- RW0-B1 semantic values and relations.
- RW0-B2 NWPF v1.
- RW0-B2 cancellation-control evidence profile.
- RW0-B2 worker-mechanism Capability.
- C2A semantic values and relations.
- existing C2B/Section 41 durable owners.

C1 owns only private durable phase/evidence mechanics.

Future and out of scope:

- RW0-C2 decision-basis and terminal-basis closure;
- C2B decision integration;
- productive direct-local accept and one-way acceptance latch;
- terminal outcome and cancellation reconciliation;
- RW0-D custody, bearer/retrieval mechanics, transport, worker, supervisor,
  process, signal/cancellation delivery, capsule, provider, credentials, and
  offline proof;
- RW0-E live qualified-host proof;
- Execution Substrate admission/runtime integration.

FROZEN C1 PRODUCT BOUNDARY

C1 owns exactly two mutation families:

- establish_rw0_phase
- admit_rw0_evidence

C1 owns:

- one immutable phase instance per exact K8 and B1 basis identity;
- one global kind-scoped typed evidence registry;
- immutable phase-specific memberships with stable membership_ref/digest;
- versioned phase/member relations and dense ordered operands;
- receipt-first exact replay;
- content-free conflicts and integrity failures;
- guarded private readers;
- one commit attempt;
- committed_exact / definitely_not_committed / unresolved recovery.

C1 does not own:

- evidence completeness;
- a mutable phase/progression head;
- a C2B decision;
- an acceptance latch;
- a terminal outcome;
- source authentication;
- external permission;
- process or runtime authority;
- public StateStore/WriterSession/package API;
- a production caller before later governed work.

EXACT 15-KIND INVENTORY

The kind ranks are fixed:

1  authority_verification_observation
2  subordinate_authorization_proposal
3  custody_availability_observation
4  retrieval_capability_event_observation
5  remote_host_readiness_observation
6  effect_host_qualification
7  worker_mechanism_capability_declaration
8  worker_mechanism_capability_observation
9  worker_mechanism_capability_qualification
10 wire_cancellation_request_observation
11 wire_process_observation
12 c2a_worker_observation
13 wire_worker_result_binding
14 wire_process_result_classification_binding
15 section41_post_execution_proposal_family_member

Do not add a sixteenth kind.

The cancellation-control classification is not a C1 member. C2 later computes
it using a transient full manifest and persists its own closure attestation.

ADMISSION DEPENDENCY DAG

Preserve the frozen dependency graph:

- Rank 1 uses existing owner rows and any accepted transient private operands.
- Rank 2 requires admitted rank 1 plus owner rows.
- Rank 3 uses an immutable selected-artifact owner row or transient WorkSpec.
- Rank 4 requires admitted ranks 1, 2, 3 and the complete earlier admitted
  rank-4 prefix.
- Rank 5 is a standalone structural value.
- Rank 6 requires admitted ranks 1 and 5 plus the current owner fence.
- Rank 7 is a standalone structural value.
- Rank 8 requires admitted rank 7.
- Rank 9 requires admitted ranks 1, 5, 6, 7, and 8 plus the current owner
  fence.
- Rank 10 uses current owner rows and an optional transient full manifest.
- Rank 11 uses current owner rows and an optional transient full manifest.
- Rank 12 uses owner rows; cancellation acknowledgement/rejection additionally
  requires the exact admitted rank-10 request; private manifest/blob operands
  are transient only.
- Rank 13 requires exactly the admitted rank-12 worker observation sequence.
- Rank 14 uses result_state present | finite_failure | absent, admitted
  rank-10/11/12 facts where supplied, admitted rank 13 only for present, and
  current immutable owner rows.
- Rank 15 wraps the exact existing Section 41 post-execution family.

Admission is single-member only. Every C1-evidence relation operand must bind an
already admitted same-phase membership. Legal partial phases are precisely
dependency-closed subsets and imply no completeness.

MIGRATION 0004

Create exactly:

src/ge_nwp_coordinator/sqlite_migrations/0004_rw0_c1_durable_evidence.sql

Migration identity:

migration ID:
0004_rw0_c1_durable_evidence

sequence:
4

application generation:
2

min/max app schema:
2 / 2

destructive:
false

seed rows:
zero

Existing migrations 0001–0003 remain byte-for-byte unchanged.

Migration 0004 creates exactly 23 STRICT tables.

Common tables:

1. rw0_phase_instances
2. rw0_evidence_values
3. rw0_evidence_memberships
4. rw0_relation_bindings
5. rw0_relation_operands
6. rw0_c1_mutation_receipts

Typed payload tables:

7.  rw0_authority_verification_observations
8.  rw0_subordinate_authorization_proposals
9.  rw0_custody_availability_observations
10. rw0_retrieval_capability_event_observations
11. rw0_remote_host_readiness_observations
12. rw0_effect_host_qualifications
13. rw0_worker_mechanism_capability_declarations
14. rw0_worker_mechanism_capability_observations
15. rw0_worker_mechanism_capability_qualifications
16. rw0_wire_cancellation_request_observations
17. rw0_wire_process_observations
18. rw0_c2a_worker_observations
19. rw0_wire_worker_result_bindings
20. rw0_wire_process_result_classification_bindings
21. rw0_section41_post_execution_proposal_family_members

Normalized child tables:

22. rw0_authority_observation_effect_classes
23. rw0_c2a_worker_observation_evidence_refs

No JSON/BLOB universal evidence payload and no capsule-entry child table.

Every table is immutable and receives exactly:

<table>_no_update
<table>_no_delete

for 46 new immutability triggers.

Create exactly four new explicit indexes:

- idx_rw0_phase_instances_k8_lookup
- idx_rw0_evidence_memberships_phase_kind_page
- idx_rw0_relation_operands_c1_membership_lookup
- idx_rw0_c1_mutation_receipts_phase_family_lookup

The exact columns and predicates are those frozen in the preceding contract.

Cumulative schema after 0004 must be exactly:

62 user tables
110 triggers
5 explicit indexes

All scalar SQL columns use the repository’s STRICT/ANY plus exact typeof,
safe-ref, digest, timestamp, integer, enum, and optional-pair checks. Use the
exact ordered columns, keys, UNIQUE constraints, FKs, CHECKs, and branch
algebras frozen in the preceding contract. Do not improvise or simplify them.

EVIDENCE AND MEMBERSHIP IDENTITY

Evidence registry identity is kind-scoped:

PRIMARY KEY (kind_rank, value_ref)
UNIQUE (kind_rank, value_digest)
UNIQUE (kind_rank, value_ref, value_digest, value_schema_id)

Cross-kind reuse of the same textual ref or digest is legal.

Membership has a stable first-class identity:

schema:
governed-execution.nwp-rw0-c1-evidence-membership.v1

PRIMARY KEY:
membership_ref

UNIQUE:
membership_digest

and the exact phase/kind/value uniqueness constraints and composite FKs frozen
in the preceding contract.

A globally reusable value may have memberships in multiple phases. A C2 closure
binds the exact membership pair, not merely the reusable value pair.

RELATION SUBJECTS AND OPERANDS

rw0_relation_bindings uses:

subject_type:
phase_establishment | evidence_membership

Phase-establishment branch:

- exact phase FK;
- membership/value subject fields null;
- relation_rank = 0;
- one relation;
- proof mode relation_attested_at_admission.

Membership branch:

- exact same-phase membership/value identity;
- full composite membership FK;
- relation_rank 0 or 1.

Member relation cardinality:

- rank 5: zero
- rank 7: zero
- ordinary rank 12: one
- cancellation-response rank 12: two
- every other member rank: one
- maximum: two
- relation reader overflow: LIMIT 3

Operand maximum is 14; operand overflow: LIMIT 15.

Operand sources are exactly:

- c1_evidence
- existing_owner_row
- transient_private_binding
- admission_snapshot_binding

c1_evidence must have the complete same-phase membership FK.

existing_owner_row has exact closed owner role/schema/ref/digest and a NULL
scope digest. Do not accept arbitrary caller-supplied table names.

transient_private_binding kinds:

- work_spec
- candidate_capsule_manifest
- before_blob_set
- after_blob_set
- wire_protocol_error

Persist only the privacy-safe aggregate bindings frozen in the contract. Never
persist WorkSpec body, capsule entries, paths, modes, file digests/lengths,
blob-map keys/values, exception object/traceback/cause/context, or raw private
material.

admission_snapshot_binding kinds:

- selection_head_snapshot
- effect_head_snapshot
- delivery_head_snapshot
- global_stop_snapshot

These bind admission-time safe snapshots of mutable current rows and are
reconstructed from the immutable phase row. Committed recovery must not require
later current heads or global_stop_current to retain historical values.

PHASE IDENTITY

Use phase_basis_ref and phase_basis_digest consistently.

K8 order:

program_ref
semantic_attempt_ref
candidate_ref
effect_intent_ref
author_command_ref
attempt_fence_ref
effect_fence_ref
delivery_attempt_ref

No mutable C1 phase or completeness head.

The phase row contains the exact flattened B1/L34 fields, program/work CAS
preimages, phase relation-set and graph identities, and the six snapshot
extension fields frozen in the prior contract:

- selection_head_updated_at
- current_effect_head_fence_ref
- current_effect_head_cancellation_effect_intent_ref
- current_effect_head_updated_at
- current_delivery_head_attempt_ref
- current_delivery_head_updated_at

No FK to mutable current head/global-stop rows.

TEMPORAL CONTRACT

Keep durable admission time and owner semantic evaluation time separate.

operation_timestamp:

- controller-owned canonical whole-second UTC;
- captured after prerequisite reads and immediately before relation evaluation;
- membership.admitted_at;
- result/receipt committed_at;
- actual durable admission time.

relation_evaluated_at:

- exact timestamp passed to owner now_utc;
- persisted as relation.evaluated_at;
- included in relation semantic digest, row digest, relation set, graph, result,
  receipt, replay, and recovery;
- never replaced by current wall time.

Closed temporal-source registry:

Operation-time relation IDs, where:

relation.evaluated_at = membership.admitted_at = operation_timestamp

- authority-verification-observation relation
- subordinate-narrowing relation
- custody-binding relation
- retrieval-event-sequence relation

Subject-time rank 6:

relation.evaluated_at =
  RW0EffectHostQualificationV1.evaluated_at

owner now_utc = relation.evaluated_at

relation.evaluated_at <= membership.admitted_at

Subject-time rank 9:

relation.evaluated_at =
  RW0WorkerMechanismCapabilityQualificationV1.evaluated_at
  =
  exact prerequisite rank-6 qualification evaluated_at

owner now_utc = relation.evaluated_at

relation.evaluated_at <= membership.admitted_at

Future-dated or mismatched values fail before writes with relation_failure.

All non-temporal relation IDs have NULL evaluated_at.

Rank-6/rank-9 membership proves owner validity at the subject’s historical
semantic instant. It does not prove currentness at admission or at a later C2
decision. C2 must obtain closure-time currentness evidence.

RANK 13 AND RANK 14

Rank 13 is actual RW0WireWorkerResultV1 binding only.

Rank 14 result_state is exactly:

- present
- finite_failure
- absent

present:
- exact rank-13 membership pair present;
- finite failure reason null.

finite_failure:
- rank-13 pair null;
- one exact finite sealed Wire reason present;
- proof mode relation_attested_at_admission;
- never recreate RW0WireProtocolError during replay.

absent:
- rank-13 pair null;
- failure reason null.

present and absent are recomputable.

Rank 14 persists only NWPF v1 classification/reason and its exact inputs. It
does not store cancellation-control classification or a complete capsule
manifest.

TRANSACTION AUTHORITY

Extend the existing _CoordinatorMutationTransactionController in:

src/ge_nwp_coordinator/sqlite_transition_transaction.py

with the exact C1 controller entries, transaction methods, and module-level
wrappers frozen in the contract for:

- atomic phase establishment
- phase-establishment recovery
- atomic evidence admission
- evidence-admission recovery

The existing controller remains the sole owner of:

- operation lease and mutation slot;
- connection open;
- BEGIN IMMEDIATE;
- binding/schema validation;
- writer fencing;
- nominal read capability;
- rollback;
- one commit attempt;
- commit-outcome state;
- process-control stabilization;
- cleanup.

src/ge_nwp_coordinator/_sqlite_rw0_c1.py owns C1 pure resolution, row
reconstruction, family readback, write plans, and recovery classification only.
It must not import sqlite3, open/close a connection, begin/commit/rollback,
construct a second controller/capability, or reach into controller state ad hoc.

sqlite_writer_session.py gains only private concrete-session delegation. Public
WriterSession, StateStore, package exports, and public protocols remain
unchanged.

Update sqlite_transition_select_support.py only to admit the exact accepted
bounded limits:

2, 3, 15, 16, 257, 258

COMMANDS, RECEIPTS, ERRORS, REPLAY, RECOVERY

Implement the exact schemas, field orders, digest domains, canonicalization,
result/receipt projections, branch checks, and content-free errors frozen in
the preceding contract.

Use the exact conflict vocabulary:

- stale_writer_token
- mutation_ref_reuse
- phase_identity_collision
- k8_collision
- current_state_conflict
- member_identity_collision
- member_already_admitted
- missing_prerequisite_member
- relation_failure
- relation_identity_collision
- owner_row_missing

Preflight reasons:

- invalid_command
- invalid_value
- invalid_recovery_probe

Operational errors reuse:

- database_integrity_failure
- mutation_failed
- commit_outcome_unknown

No spelling variants.

Replay is receipt-first after writer fencing. Same mutation ref plus another
command digest is mutation_ref_reuse. Exact replay writes nothing and captures
no clock.

After a commit-attempt exception, do not automatically retry. A fresh fenced
writer performs explicit recovery and returns exactly:

- committed_exact
- definitely_not_committed
- unresolved

Committed phase recovery requires phase row, phase relation, all 14 operands,
nine immutable owner rows, one transient WorkSpec binding, four snapshot
bindings reconstructed from the phase row, exact digests, K8, result, and
receipt.

Committed member recovery requires exact registry/typed payload/children,
membership, relation set, operands, dependencies, graph, result, and receipt.

Current head/global-stop progression after admission must not invalidate
committed recovery. Historical verification never consults the current clock.

EXACT 81-PATH ALLOWLIST

Only these paths may change.

Documentation/root — 27:

AGENTS.md
README.md
.docs/architecture.md
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/b3-tests-only-coherent-fixtures.md
.docs/b3-transition-persistence-contract.md
.docs/b3c0a-transition-authority-and-order.md
.docs/b4c-public-global-stop-delegation.md
.docs/c2a-first-slice-semantic-protocol-contract.md
.docs/c2b-durable-development-state.md
.docs/c2b2-migration-0002.md
.docs/c2b2-private-readers.md
.docs/durable-state-model.md
.docs/rw0-b1-pure-phase-values.md
.docs/rw0-b2-capability.md
.docs/rw0-b2-wire-protocol.md
.docs/rw0-c1-durable-evidence.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/software-development-progression-boundary.md
.docs/sqlite-bootstrap-and-migrations.md
.docs/sqlite-operations-and-recovery.md
.docs/sqlite-schema-v1.md
.docs/sqlite-state-backend-adr.md
.docs/sqlite-threat-model.md
.docs/worker-execution-boundary.md
.docs/writer-session-authority.md

Production/migration — 11:

src/ge_nwp_coordinator/_rw0_c1_semantic_values.py
src/ge_nwp_coordinator/_rw0_c1_row_values.py
src/ge_nwp_coordinator/_rw0_c1_mutation_contracts.py
src/ge_nwp_coordinator/_sqlite_rw0_c1_reader_contracts.py
src/ge_nwp_coordinator/_sqlite_rw0_c1_readers.py
src/ge_nwp_coordinator/_sqlite_rw0_c1.py
src/ge_nwp_coordinator/sqlite_transition_select_support.py
src/ge_nwp_coordinator/sqlite_transition_transaction.py
src/ge_nwp_coordinator/sqlite_writer_session.py
src/ge_nwp_coordinator/sqlite_migration.py
src/ge_nwp_coordinator/sqlite_migrations/0004_rw0_c1_durable_evidence.sql

Tests — 43:

tests/b3_coherent_transition_fixture.py
tests/test_architecture_contracts.py
tests/test_autonomous_software_development_operating_model.py
tests/test_b2a_writer_session_contract.py
tests/test_b3_coherent_transition_fixture.py
tests/test_b3a_persistence_contracts.py
tests/test_b3b1_pure_row_contracts.py
tests/test_b3b2b_select_readers.py
tests/test_b3b_reader_prerequisite_contracts.py
tests/test_b3c0a_transition_authority_contract.py
tests/test_b3c0b_transition_event_replay_contracts.py
tests/test_b3c1_prerequisite_contract.py
tests/test_b3c1b_rollback_only_writer_fencing.py
tests/test_b3c3_prerequisite_contract.py
tests/test_b3c4c_prerequisite_contract.py
tests/test_b4c_public_global_stop_delegation.py
tests/test_c2a_nonimplementation.py
tests/test_c2b0_durable_state_contract.py
tests/test_c2b2_development_reader_contracts.py
tests/test_c2b3c_author_effect_contract.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_runtime_non_authority.py
tests/test_rw0_b1_boundaries.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_software_development_progression_boundary.py
tests/test_sqlite_b1_migrations.py
tests/test_sqlite_b2c_writer_session.py
tests/test_sqlite_backend_b0_contract.py
tests/test_sqlite_c2b1_migration_framework.py
tests/test_sqlite_c2b2_migration_0002.py
tests/test_sqlite_section41_migration_0003.py
tests/test_worker_execution_semantic_boundaries.py
tests/test_rw0_c1_semantic_values.py
tests/test_rw0_c1_row_values.py
tests/test_rw0_c1_reader_contracts.py
tests/test_rw0_c1_private_readers.py
tests/test_rw0_c1_mutation_contracts.py
tests/test_rw0_c1_private_atomic_persistence.py
tests/test_rw0_c1_recovery.py
tests/test_rw0_c1_writer_session_delegation.py
tests/test_sqlite_rw0_c1_migration_0004.py

All other repository paths are protected.

In particular do not modify:

- migrations 0001–0003;
- schemas/sqlite/coordinator-state-v1.sql;
- pyproject.toml;
- __init__.py;
- state_store.py;
- sqlite_errors.py;
- sqlite_mutation_transaction_contracts.py;
- existing B1/Wire/Capability/C2A/C2B/Section 41 semantic source modules;
- existing development reader modules and query inventory;
- supporting repositories.

If any implementation need arises outside the 81 paths, stop with:

RW0_C1_IMPLEMENTATION_SCOPE_CONFLICT

IMPLEMENTATION STRATEGY

Proceed as one workspace-write tranche with internal stages. Do not treat an
internal stage as accepted.

Stage 1 — opening evidence and test-first contract:

- Record exact identity, opening node list, and 81-path allowlist.
- Create the owner document and the nine new permanent test modules.
- Add the minimum test-side contract needed for a causal red gate.
- Before production implementation, run a selected red gate that fails only
  because the new migration/modules/controller methods do not yet exist.
- Reject and correct test harness or over-specific failures before source work.
- Do not weaken pre-existing tests.

Stage 2 — pure semantics, rows, query contracts, migration:

- Implement private C1 semantic values, row values, mutation contracts, reader
  contracts, and migration 0004.
- Update sqlite_migration.py.
- Implement exact schema, checks, triggers, indexes, zero seed, supported
  prefixes, and cumulative inventory.
- Run pure and migration focused tests.

Stage 3 — private readers and controller integration:

- Implement bounded private readers.
- Implement C1 pure planning/readback/recovery.
- Extend the sole transaction controller and select limits.
- Add private writer-session delegation.
- Exercise phase establishment, all 15 kinds, replay/conflict, every dependency
  branch, commit uncertainty, cleanup, temporal replay, and mutable-snapshot
  progression.

Stage 4 — status and compatibility synchronization:

- Update only the exact current-tip/status/importer/source inventories in the
  81-path set.
- Preserve historical tranche statements that remain true.
- Preserve owner identities and current B1/B2/C2A/C2B semantics.
- Run compatibility and architecture groups.

Stage 5 — freeze, final validation, cleanup, provenance:

- Freeze final candidate.
- Collect nodes.
- Run focused groups.
- Run one official complete suite.
- Remove only artifacts created by this implementation.
- Run exact provenance twice and require byte-identical outputs.
- Return the complete report inline.

PERMANENT TEST CLAIMS

The nine new tests must cover, causally:

1. test_sqlite_rw0_c1_migration_0004.py
   - exact resource/checksum/catalog sequence;
   - application generation 2;
   - all 23 tables, 46 triggers, 4 indexes;
   - zero seeds;
   - fresh initialization and exact upgrades from supported prefixes;
   - cumulative 62/110/5.

2. test_rw0_c1_semantic_values.py
   - exact 15 kinds/ranks;
   - schemas, commands, results, receipts, conflicts, recovery values;
   - privacy;
   - temporal-source registry;
   - safe transient/snapshot bindings;
   - no completeness or authority.

3. test_rw0_c1_row_values.py
   - exact ordered columns;
   - kind-scoped registry;
   - membership identity;
   - typed tables/children;
   - rank-13/rank-14 branches;
   - immutable digests and content-free representation.

4. test_rw0_c1_reader_contracts.py
   - exact literal SELECT columns/predicates/order/LIMIT;
   - no SELECT *;
   - exact 2/3/15/16/257/258 bounded limits.

5. test_rw0_c1_private_readers.py
   - capability lifecycle;
   - no/multiple/malformed row behavior;
   - same-phase dependency reads;
   - pages, relation sets, operands, Section 41 0-or-9 family.

6. test_rw0_c1_mutation_contracts.py
   - K8/L34/phase identity;
   - dependency DAG;
   - proof modes;
   - relation/operand sets;
   - transaction plans;
   - conflicts and exact replay.

7. test_rw0_c1_private_atomic_persistence.py
   - operation guard/fence/controller order;
   - phase establishment;
   - all 15 admission kinds;
   - owner relation actually invoked;
   - receipt last;
   - readback before commit;
   - one commit;
   - no external I/O.

8. test_rw0_c1_recovery.py
   - faults at every read/write/capability/commit/rollback/cleanup boundary;
   - committed_exact / definitely_not_committed / unresolved;
   - no automatic retry;
   - progression-safe phase snapshot recovery;
   - persisted temporal replay without current clock.

9. test_rw0_c1_writer_session_delegation.py
   - private concrete delegation only;
   - one controller;
   - no public protocol/package/StateStore widening;
   - content-free errors and process-control stabilization.

Permanent tests must not defend themselves against equal-authority mutation or
become an audit framework.

VALIDATION

Use external temporary paths only. Set:

umask 022
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct evidence-root PYTHONPYCACHEPREFIX for every Python process
distinct evidence-root TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
GIT_OPTIONAL_LOCKS=0
python3 -B
-p no:cacheprovider
-W error

Run serially.

Focused validation groups, after the relevant implementation stage:

A. New C1 contract and migration:
- all nine new C1 test modules.

B. Existing migration/schema/fixture:
- test_sqlite_b1_migrations.py
- test_sqlite_c2b1_migration_framework.py
- test_sqlite_c2b2_migration_0002.py
- test_sqlite_section41_migration_0003.py
- test_sqlite_backend_b0_contract.py
- test_b3_coherent_transition_fixture.py
- test_c2b0_durable_state_contract.py
- every touched B3 migration/resource prerequisite test.

C. Reader, transaction, writer, recovery:
- test_b2a_writer_session_contract.py
- test_sqlite_b2c_writer_session.py
- test_b3b2b_select_readers.py
- test_c2b2_development_reader_contracts.py
- test_b3c0a_transition_authority_contract.py
- test_b3c0b_transition_event_replay_contracts.py
- test_b3c1_prerequisite_contract.py
- test_b3c1b_rollback_only_writer_fencing.py
- test_b3c3_prerequisite_contract.py
- test_b3c4c_prerequisite_contract.py
- related existing private atomic/recovery tests needed to protect the sole
  controller, even when those files are protected and remain byte-identical.

D. Semantic-owner compatibility:
- all RW0-B1 tests;
- all existing and cancellation-control Wire tests;
- all Capability tests;
- C2A values/vectors/relations/boundaries/effects-and-recovery;
- Section 41 and development-row owner tests.

E. Status, architecture, privacy, nonauthority:
- every touched existing test in the 81-path list;
- architecture, runtime-non-authority, progression, remote-contact planning,
  public global-stop delegation, and worker-semantic boundaries.

Every credited run requires:

- return code 0;
- all collected cases passed;
- zero failures/errors/skips/xfails/xpasses/warnings;
- empty stderr;
- parseable JUnit;
- zero duplicate/unmapped cases;
- caller/child umask 0022;
- unchanged candidate fingerprint before/after.

FINAL NODE RECONCILIATION

After final candidate freeze, collect once.

Require:

- every 5,087 opening node remains with identical identity and relative order;
- zero removals or renames;
- no skip or xfail introduced;
- all additions explicitly listed and attributable to the nine new C1 files,
  unless a pre-existing touched test gains a genuinely necessary parameterized
  case, which must be separately justified;
- final live and any clean candidate collection lists are identical.

COMPLETE SUITE

Do not run the complete suite until all focused groups and final guards are
green.

Run one official complete suite attempt over tests.

If attempt 001 fails:

- preserve its complete record;
- classify candidate defect versus tooling/environment failure;
- if repairable within the 81-path scope, repair, rerun affected focused groups,
  recollect nodes, refreeze candidate, and permit exactly one attempt 002;
- no third complete-suite attempt;
- do not misclassify a test failure as an environment failure.

Official final suite requires all tests pass with zero skips/warnings and exact
JUnit/node mapping.

PROVENANCE AND EVIDENCE

Create one private external evidence root:

/private/tmp/ge-coordinator-rw0-c1-implementation.XXXXXX

Requirements:

- root/directories mode 0700;
- retained files mode 0400;
- no retained symlink or special entry;
- material attempt records for opening, red, focused, final collection, complete
  suite, guards, cleanup, and provenance;
- keep evidence proportionate; do not create a recursive self-protecting
  evidence framework;
- no candidate authority is assigned to reports or evidence.

Use the exact project provenance recipe:

recipe ID:
governed-execution.audit-patch-manifest.v1

exact source size:
3945 bytes

exact source SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

The exact source is supplied separately with this prompt. Verify its bytes
before use. Do not edit it.

Do not mutate a pre-existing historical fixed output sink. Use the established
safe redirection procedure that changes only the recipe’s external output
destination while preserving exact recipe behavior; retain the wrapper source
and prove it does not affect Git queries, canonical JSON, stdout, or stderr.

At closeout:

- `git diff --check`;
- exact branch/HEAD/upstream/topology;
- exact changed-path set within the 81-path ceiling;
- all paths regular expected modes;
- no staged/unmerged state;
- no operation/lock/residue;
- package/public/StateStore/WriterSession protocol unchanged;
- migrations 0001–0003 byte-identical;
- all protected owner source identities unchanged;
- run the exact recipe twice;
- require byte-identical manifests and complete output;
- report recipe source hash, tracked textual diff hash, canonical manifest hash,
  complete output hash, file count, and complete canonical manifest inline or
  in a clearly named supplementary artifact after the inline substantive
  report;
- create a self-excluding evidence index last and externally verify it.

STOP CONDITIONS

Stop without broad repair if any occurs:

- baseline or opening-node mismatch;
- need to touch a path outside the 81-path allowlist;
- need for a sixteenth evidence kind;
- need for grouped admission;
- need for more than two member relations or more than 14 operands;
- need to persist capsule entries, raw WorkSpec, blob-map contents, or exception
  objects;
- need to modify B1/Wire/Capability/C2A/C2B/Section 41 owner semantics;
- need to modify migrations 0001–0003;
- need for C2 closure/latch/decision/terminal state in 0004;
- need for a second controller, connection path, commit path, writer authority,
  or public method;
- need for external I/O in a transaction;
- inability to prove exact three-way recovery;
- schema totals differ from 23/46/4 and cumulative 62/110/5 for a semantic
  reason rather than an implementation error;
- historical verification would require the current clock or mutable current
  heads.

Use:

RW0_C1_IMPLEMENTATION_SCOPE_CONFLICT

for an allowlist or authority conflict, or:

RW0_C1_IMPLEMENTATION_CONTRACT_CONFLICT

for a genuine frozen-contract contradiction.

SUCCESS TOKEN

Return exactly:

COORDINATOR_RW0_C1_IMPLEMENTED_READY_FOR_INDEPENDENT_AUDIT

only if the complete C1 capability is implemented, all required validation is
green, cleanup and provenance are complete, and no independent audit is
claimed.

FINAL INLINE REPORT

Use:

# Outcome
# Opening identity and branch
# Implementation decision and preserved boundaries
# Exact touched-path ledger
# Migration 0004 and cumulative schema
# C1 semantic/value/reader contracts
# Phase establishment
# Evidence admission across all 15 kinds
# Transaction-controller and writer-session integration
# Replay, conflicts, and recovery
# Temporal and mutable-snapshot behavior
# Test-first chronology
# Focused validation
# Node reconciliation
# Complete-suite validation
# Provenance and cleanup
# Authority, privacy, and nonclaims
# Remaining seams
# Confidence

Required final statements:

INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
STATESTORE_PUBLIC_SURFACE_NOT_WIDENED
WRITERSESSION_PUBLIC_PROTOCOL_NOT_WIDENED
RW0_C2_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
