Begin the RW0-C discussion from the current merged Coordinator baseline.

Do not issue an implementation prompt yet. First make the phase-level
engineering decision about the smallest non-disposable durable capability and
the appropriate RW0-C decomposition.

Current facts to preserve:

- RW0-B1, RW0-B2-Wire, and RW0-B2-Capability are current private pure no-I/O
  contracts.
- RW0-C is future durable phase-entry and observation state using supplied fake
  observations only, with no external contact.
- RW0-D owns later physical custody, transport, process, provider, supervisor,
  cancellation-delivery, capsule, and offline proof mechanics.
- RW0-E owns the separately authorized live qualified-host proof.
- The existing C2B decision grammar remains unchanged.
- The RW0 terminal-outcome fact is distinct from a development\_decision,
  executable authority, source observation, and effect basis.
- Only the productive direct-local accept decision consumes the one-way
  acceptance latch; the terminal fact binds its postimage but does not mutate
  the latch.

Make and defend the following decisions.

1. Observable RW0-C result

State what durable ability should exist at the end of RW0-C, its contribution
to remote worker contact through semantic decision, and what remains blocked
until D and E.

Do not define success merely as “migration 0004 exists” or “all target rows are
representable.”

2. Decomposition

Determine whether RW0-C should be one tranche or should be decomposed.

Explicitly evaluate this provisional split:

- RW0-C1:
  durable phase-entry and source-observation ingest, exact evidence bindings,
  receipt/idempotency, replay/conflict, guarded readback, and commit-uncertainty
  recovery using supplied fake observations only;

- RW0-C2:
  evidence-set closure, C2B-decision binding, separate RW0 terminal-outcome
  persistence, active-cancel reconciliation, acceptance-latch atomicity, and
  terminal recovery.

Recommend the smallest non-disposable decomposition. Reject or revise the split
where owning-contract dependencies require it. Do not split merely to multiply
gates, and do not combine the work merely because all of it uses SQLite.

3. Action-specific prerequisites

For each material prerequisite, identify:

- the exact action it blocks;
- whether it is established by an owning contract, depends on missing evidence,
  or is a proposed engineering precaution;
- whether it must be settled before C1, before C2, or only before D/E.

Pay particular attention to:

- external verifier authenticity versus durable recording of a supplied claim;
- custody availability and retrieval events versus physical bearer mechanics;
- B2 Wire/Capability observations versus source authentication;
- evidence membership versus evidence completeness;
- current C2B decisions versus the distinct RW0 terminal fact;
- acceptance-latch mutation versus terminal-outcome binding;
- cancellation decision, request, reconciliation, and terminal closure;
- commit uncertainty and exact recovery without duplicate decisions or latch
  mutation.

4. B1/B2 reuse

Identify every B1, Wire, and Capability value/relation that C is expected to
reuse.

Any required change to a merged B1/B2 identity, field meaning, relation,
protocol profile, or ownership rule must be reported as downstream semantic
churn, not hidden as an ordinary C compatibility repair.

5. Assurance architecture

Design finite acceptance evidence for the actual durable capability.

Permanent repository tests should enforce finite product, schema, transaction,
replay, recovery, privacy, and authority contracts. They must not attempt to
defend themselves against arbitrary equal-authority mutation or become a
self-protecting audit framework.

Independent audit owns adversarial integrity, provenance, and patch-identity
checking.

For each proposed check, state which product claim it supports. Keep candidate
defects, contract defects, test/oracle defects, audit-harness defects, report
defects, and environment defects distinguishable.

Do not import the RW0-B2 G5–G18 evidence-harness architecture into RW0-C.

6. Forecasts and stop conditions

Record two or three falsifiable forecasts concerning:

- likely schema or transaction contradictions;
- likely post-freeze semantic churn;
- expected touched-file or migration scope;
- likely audit-finding classes;
- evidence that would require architectural replanning rather than an ordinary
  implementation repair.

Do not use unsupported numerical confidence percentages.

7. Next step

Return:

- your engineering recommendation;
- the proposed RW0-C decomposition and acceptance boundary;
- unresolved owner seams;
- and one complete self-contained read-only Codex reconnaissance prompt if
  repository grounding is still needed.

Do not issue an implementation prompt in this response.
Do not ask me to select tables, file boundaries, transaction mechanics, tests,
or ordinary risk treatment.
