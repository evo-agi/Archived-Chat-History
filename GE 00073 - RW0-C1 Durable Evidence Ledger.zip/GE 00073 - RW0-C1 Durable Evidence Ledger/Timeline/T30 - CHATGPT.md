# Disposition

**Do not begin RW0-C1 implementation yet.**

The response closes the previously identified phase-proof and transient-private-operand gaps. These decisions are now accepted:

- phase establishment is represented in the common relation tables;
- every accepted private transient input has a privacy-safe durable binding;
- membership and relation digests are acyclic;
- committed phase recovery requires the phase relation and all 14 operands;
- the existing transaction controller remains the sole transaction authority;
- the physical design remains 23 tables, 46 immutability triggers, and four new explicit indexes;
- the 81-path implementation boundary remains plausible.

But two source-grounded contradictions and one undefined SQL field remain. The correct terminal disposition is still:

```text
RW0_C1_FREEZE_RECONCILIATION_REQUIRED
```

—not architectural replan.

## 1. Time-sensitive relations have no persisted evaluation instant

Several merged owner relations accept `now_utc` and use it materially:

- authority verification: `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py:1410-1418`;
- subordinate narrowing: `:1749-1779`;
- custody binding: `:1782-1816`;
- retrieval sequence: `:1819-1825`;
- host qualification: `:2140-2152`;
- Capability qualification: `src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py:984-1007`.

The proposed `rw0_relation_bindings` row has no `evaluated_at`, and the response never freezes which timestamp is passed as `now_utc`.

That is implementation-blocking. Recomputing one of these relations with the current clock could turn an originally valid observation into an expired one. A reader also cannot prove which temporal predicate the stored relation digest represents.

The final contract should freeze one transaction timestamp:

```text
operation_timestamp
```

captured immediately before relation evaluation, with:

```text
membership.admitted_at = operation_timestamp
relation.evaluated_at = operation_timestamp
```

for relations that consume `now_utc`.

`evaluated_at` should be null for non-temporal relations and phase establishment. It must participate in the relation semantic digest and row digest. Recomputable relations must always rerun with the persisted timestamp, never the current clock.

A design using `membership.admitted_at` directly instead of an additional relation column is also possible, but it must be explicitly bound into every applicable relation digest and reader. The current response does neither.

## 2. Mutable current rows are still treated as immutable owner rows

`validate_phase_entry_basis(...)` consumes a selection head, effect head, delivery head, and global-stop current envelope. :chatgpt-content-reference{index="0"}

Those are snapshots of mutable current state:

- the selection head is updated in place by `_sqlite_development_pre_execution_plan_disposition.py:1574-1584`;
- `global_stop_current` is a mutable singleton at `sqlite_migrations/0001_initial.sql:333-350`;
- `development_effect_heads` and `development_delivery_heads` are mutable head tables, defined at `sqlite_migrations/0002_development_program_and_effect_state.sql:406-473`, without append-only immutability triggers.

The response classifies all four as:

```text
existing_owner_row
```

and says committed recovery must resolve each exact owner locator later.

That would make a valid historical phase become unrecoverable after ordinary progression:

- a later selection changes the current selection-head row;
- effect or delivery progression changes a current head;
- a global-stop update changes the singleton.

C1 must bind their **admission-time snapshots**, not claim their current rows remain unchanged forever.

The clean correction is another closed operand source:

```text
admission_snapshot_binding
```

with exactly:

```text
selection_head_snapshot
effect_head_snapshot
delivery_head_snapshot
global_stop_snapshot
```

The snapshot bindings should be reconstructible from the immutable C1 phase row. Recovery must compare the relation operands to that phase snapshot, not reread current heads or `global_stop_current`.

Program/work-head CAS preimages need the same historical treatment: later head advancement must not invalidate an already committed phase. Those heads are CAS inputs copied into the phase row, not historical owner rows that recovery requires to remain current.

## 3. `operand_scope_digest` is undefined for immutable owner rows

The response says the `existing_owner_row` branch requires:

```text
operand_schema_id
operand_ref
operand_digest
operand_scope_digest
```

all non-null.

But most immutable owner rows have no generic owner-defined “scope digest.” Selection dispositions, mutation receipts, attempt fences, commands, deliveries, proposals, and artifacts expose different semantic identities; there is no shared scope field.

The branch algebra should instead be explicit:

```text
c1_evidence:
  operand_scope_digest = source membership scope_binding_digest

existing_owner_row:
  operand_scope_digest = NULL

transient_private_binding:
  operand_scope_digest = the closed transient binding’s exact scope digest

admission_snapshot_binding:
  operand_scope_digest = the closed snapshot binding’s exact scope digest
```

The owner locator plus exact owner schema/ref/digest is sufficient for immutable owner rows.

## What remains frozen

Do not reopen:

```text
C1/C2 decomposition
15 evidence kinds
single-member admission
stable membership identity
same-phase membership FKs
rank-14 present/finite_failure/absent algebra
maximum two member relations
phase_basis_ref / phase_basis_digest naming
one transaction controller
kind-scoped evidence identity
safe capsule binding only
C2 transient-manifest recomputation
phase relation in the common relation tables
five transient-private binding kinds
no C2 state in migration 0004
```

The following physical totals are still expected to remain unchanged after the correction:

```text
migration 0004:
23 tables
46 immutability triggers
4 explicit indexes

cumulative:
62 tables
110 triggers
5 explicit indexes
```

No new table is required. The relation and operand rows need additional columns/branches only.

# Final closure handoff

Send this prompt to the same read-only Coordinator Codex conversation:

:chatgpt-content-reference{index="3"}[Download the temporal and mutable-snapshot closure prompt](sandbox:/mnt/data/Coordinator_RW0_C1_Temporal_and_Mutable_Snapshot_Closure_Prompt.txt)

```text
Filename:
Coordinator_RW0_C1_Temporal_and_Mutable_Snapshot_Closure_Prompt.txt

Size:
15,719 bytes

SHA-256:
8d513343933c5390d0666d01cf14e6d41dd4e8c39e5438c20990f71612de24f6
```

It is constrained to these final issues only:

1. persist the exact evaluation instant for every time-sensitive relation;
2. represent mutable current rows as immutable admission snapshots;
3. remove the undefined owner-row scope digest;
4. close the resulting SQL, digest, reader, replay, recovery, count, and path consequences.

The desired result remains:

```text
RW0_C1_IMPLEMENTATION_CONTRACT_READY
```

Only after that result should the workspace-write implementation prompt be issued.

### Sources

- :chatgpt-content-reference{index="4"}[Attached Codex response](sandbox:/mnt/data/Pasted%20text.txt)
- Current merged Coordinator snapshot: `Governed Execution Coordinator - Snapshot - 2026-09-27.zip`. :chatgpt-content-reference{index="1"}
- `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py:1294-1407,1410-1418,1749-1825,2140-2152`
- `src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py:984-1007`
- `src/ge_nwp_coordinator/_sqlite_development_pre_execution_plan_disposition.py:1574-1584`
- `src/ge_nwp_coordinator/sqlite_migrations/0001_initial.sql:333-350`
- `src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql:406-473`

**Confidence:** High that the accepted C1 architecture is sound; high that these are real implementation-contract gaps; high that this single narrow closure can resolve them without changing the table family, tranche decomposition, or authority split.
