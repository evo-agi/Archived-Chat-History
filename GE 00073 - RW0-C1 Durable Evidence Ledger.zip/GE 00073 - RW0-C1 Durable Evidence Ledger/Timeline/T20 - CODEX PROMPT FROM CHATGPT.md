PROMPT_ID

RW0_C_POST_CANCELLATION_CONTROL_RECONNAISSANCE_V2

TITLE

Coordinator RW0-C — post-merge read-only reconciliation and exact C1 contract
freeze after RW0-B2 cancellation-control evidence

ENGAGEMENT TYPE

Read-only repository reconnaissance and contract freeze.

Do not modify repository files.
Do not run pytest, node collection, migrations, mutation probes, database
commands, staging, commit, push, PR, merge, tag, release, or deployment.
Do not fetch or otherwise contact a remote.
Do not contact a verifier, custodian, worker, provider, host, Execution
Substrate, Bridge, or supporting repository.
Do not issue an implementation prompt.

Print the complete substantive response inline in chat. Evidence files may be
supplementary only.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED MERGED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
047563de5a443b0f8323401c92979ae2e444d2ed

tree:
4ff9ee4a710af13447e3ed8699339a51255ff720

sole parent:
dd12b23762dc761736e55a1abfde12dd3ec23551

subject:
feat: add RW0-B2 cancellation-control evidence (#6)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

worktree/index/untracked/unmerged:
clean

Git operation/lock:
none

No fetch is authorized. Compare against local Git metadata only. Stop with
BASELINE_MISMATCH if any required identity differs.

CURRENT CONTRACTS TO PRESERVE

Current implemented private pure no-I/O contracts:

1. RW0-B1 phase-entry semantic values and relations.
2. RW0-B2 NWPF v1 Wire representation and process/result classification.
3. RW0-B2 worker-mechanism Capability declaration/observation/qualification.
4. RW0-B2 exact-current-effect cancellation-control evidence profile:
   - ref `rw0-wire-cancellation-control-v1`;
   - digest
     `4d6f84552b852a4c4073b4238591afd271072f648424eca9e744def436165288`;
   - exact current author, validation, and review targets;
   - pure invalid/incomplete/finite control-evidence classification.

Current durable SQLite catalog:

- application generation 2;
- migration tip 0003;
- no RW0-C durable rows yet.

Future ownership:

- RW0-C owns durable phase-entry/evidence state, decision closure, latch, and
  terminal outcome using supplied fake observations only.
- RW0-D owns physical custody, bearer/retrieval mechanics, transport, worker,
  provider, supervisor, process, signal/cancellation delivery, capsule, and
  offline proof.
- RW0-E owns separately authorized live qualified-host proof.
- Execution Substrate owns admission and runtime facts.
- No external contact occurs in C.

FROZEN PHASE-LEVEL ENGINEERING DECISION

RW0-C is decomposed into two non-disposable tranches.

RW0-C1:

- one receipt-backed no-contact RW0 phase instance;
- immutable typed supplied-evidence membership;
- exact phase/evidence/relation/profile bindings;
- idempotency, replay, conflict, and semantic collision handling;
- guarded private readback;
- exact commit-uncertainty recovery;
- no evidence completeness;
- no C2B decision;
- no terminal outcome;
- no acceptance-latch mutation;
- no external contact or public/production caller.

RW0-C2:

- immutable decision-basis evidence closure;
- unchanged existing C2B decision persistence;
- productive direct-local accept plus one-way latch mutation atomically in the
  decision transaction;
- immutable terminal-basis evidence closure;
- separate RW0 terminal-outcome persistence;
- active-cancel semantic reconciliation using supplied fake facts;
- exact decision and terminal recovery;
- terminal fact binds the accept latch postimage but never mutates the latch;
- no external contact, Git/publication effect, or successor launch.

Decision-basis and terminal-basis closures are distinct causal facts.

Only the productive direct-local accept decision consumes the latch.

The existing C2B decision grammar and meanings remain unchanged.

PRIMARY OBJECTIVE

Re-ground on the exact merged baseline and determine whether RW0-C1 can now be
frozen for implementation.

Return:

1. an exact C1 durable contract;
2. exact migration 0004 recommendation;
3. exact C1 transaction/receipt/recovery contract;
4. exact private reader contract;
5. exact 15-kind evidence-membership contract;
6. exact C2 compatibility seam without precreating C2 state;
7. exact permanent-test and independent-audit architecture;
8. exact touched-file ceiling and protected files;
9. unresolved seams and stop conditions.

Do not implement.

REQUIRED INSPECTION

Read completely or in every relevant owning section:

Repository guidance and packaging:

- AGENTS.md
- README.md
- pyproject.toml

RW0/B1/B2/C2A owners:

- .docs/rw0-remote-worker-contact-phase-entry.md
- .docs/rw0-b1-pure-phase-values.md
- .docs/rw0-b2-wire-protocol.md
- .docs/rw0-b2-capability.md
- .docs/c2a-first-slice-semantic-protocol-contract.md
- .docs/worker-execution-boundary.md
- .docs/authority-boundaries.md
- .docs/autonomous-software-development-operating-model.md

Durable model and progression:

- .docs/durable-state-model.md
- .docs/c2b-durable-development-state.md
- .docs/c2b2-pure-durable-row-values.md
- .docs/c2b2-private-readers.md
- .docs/c2b3-program-initialization.md
- .docs/sqlite-bootstrap-and-migrations.md
- .docs/sqlite-operations-and-recovery.md
- .docs/software-development-progression-boundary.md
- .docs/software-development-progression-boundary.md
- .docs/software-development-progression-boundary.md

Semantic values and relations:

- src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
- src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
- src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
- src/ge_nwp_coordinator/_worker_execution_semantic_values.py
- src/ge_nwp_coordinator/_development_decision_row_values.py
- src/ge_nwp_coordinator/_development_effect_row_values.py
- src/ge_nwp_coordinator/_development_program_row_values.py
- src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py

Durable readers and mutation paths:

- src/ge_nwp_coordinator/_sqlite_development_reader_contracts.py
- src/ge_nwp_coordinator/_sqlite_development_readers.py
- src/ge_nwp_coordinator/_sqlite_development_program_initialization.py
- src/ge_nwp_coordinator/_sqlite_development_author_effect_establishment.py
- src/ge_nwp_coordinator/_sqlite_development_pre_execution_plan_disposition.py
- src/ge_nwp_coordinator/sqlite_migration.py
- src/ge_nwp_coordinator/sqlite_mutation_transaction_contracts.py
- src/ge_nwp_coordinator/sqlite_transition_select_support.py
- src/ge_nwp_coordinator/sqlite_transition_transaction.py
- src/ge_nwp_coordinator/sqlite_writer_session.py
- src/ge_nwp_coordinator/state_store.py

Schema and migrations:

- schemas/sqlite/coordinator-state-v1.sql
- every packaged SQLite migration resource
- migration tests and cumulative-schema tests

Direct tests:

- all RW0-B1 tests
- all existing and new RW0-B2 Wire tests
- all Capability tests
- C2A values/vectors/relations/boundaries/effects-and-recovery tests
- C2B durable-row and private-reader tests
- program-initialization tests
- author-effect-establishment tests
- Section 41 disposition mutation/recovery tests
- mutation transaction, transition transaction, writer-session, migration,
  state-store, architecture, runtime-non-authority, and progression tests
- RW0 phase/status tests

Inspect additional Coordinator files only for a concrete dependency and state
why.

A. BASELINE AND OWNER RECONCILIATION

Confirm:

1. the cancellation-control owner seam is now closed for author, validation,
   and review targets;
2. the new profile remains distinct from:
   - NWPF v1;
   - B1 physical host cancellation-mechanism evidence;
3. Capability remains bound only to NWPF v1;
4. C1 may admit target-complete supplied cancellation evidence without
   duplicating Wire semantics;
5. C2 may later recompute and bind the pure cancellation-control
   classification;
6. no B1/B2/C2A/C2B identity or relation change is now required.

Any owner churn is a stop condition.

B. C1 OBSERVABLE DURABLE CAPABILITY

Define the end-of-C1 observable result in operational terms, not migration
representability.

A fresh guarded reader must be able to establish for one phase:

- exact phase identity and lineage;
- establishment command and receipt;
- every admitted immutable evidence member;
- member type and owner relation/profile binding;
- replay/conflict/collision disposition;
- graph/result identities;
- whether an uncertain mutation is exact committed, definitely absent, or
  unresolved.

C1 must make no claim of:

- completeness;
- authenticity;
- permission;
- decision;
- acceptance;
- terminality;
- latch state;
- external contact.

State the exact private APIs/commands/results/readers required to make this
observable.

C. PHASE IDENTITY AND GRAPH

Freeze exact C1 phase identity.

Evaluate and decide:

- primary key/ref;
- `(basis_ref, basis_digest)` role;
- exact K8 and L34 lineage bindings;
- uniqueness constraints;
- program/work/head CAS coordinates;
- global-stop/path-scope/selection/effect/delivery bindings;
- collision conditions;
- whether one phase exists per basis pair, per K8 lineage, or both;
- whether any mutable phase head is needed.

Prefer no competing mutable progression head.

List every owning value/ref/digest copied, projected, or referenced.

D. EXACT 15-KIND EVIDENCE MEMBERSHIP

Freeze the exact kind inventory. Reconcile the prior provisional list against
the merged cancellation-control profile.

Expected inventory to validate:

1. authority_verification_observation
2. subordinate_authorization_proposal
3. custody_availability_observation
4. retrieval_capability_event_observation
5. remote_host_readiness_observation
6. effect_host_qualification
7. worker_mechanism_capability_declaration
8. worker_mechanism_capability_observation
9. worker_mechanism_capability_qualification
10. wire_cancellation_request_observation
11. wire_process_observation
12. c2a_worker_observation
13. wire_worker_result_binding
14. wire_process_result_classification_binding
15. section41_post_execution_proposal_family_member

Confirm:

- the phase basis is not a member;
- terminal outcome is not a member;
- the new cancellation-control classification is not a member;
- C2 recomputes it from exact immutable closure operands;
- no sixteenth kind is needed.

For every kind specify:

- owner;
- exact stored fields;
- full safe projection versus ref/digest-only wrapper;
- semantic identity;
- required relation/profile proof;
- source kind/invocation/evidence binding;
- privacy classification;
- uniqueness/replay/collision key;
- required reader shape;
- whether a fake supplied value is sufficient for C1 tests.

E. RELATION-PROOF BINDING

Decide how C1 records that an owning pure relation was successfully checked
without creating a free-standing truth/authority boolean.

Freeze:

- relation identifier/version;
- profile pair where applicable;
- exact ordered operand refs/digests;
- result/receipt binding;
- reconstruction policy on replay/readback;
- treatment of owner relation changes in later versions.

For cancellation control, bind:

- new profile pair;
- exact request/process/response relation proof operands;
- author/validation/review target class;
- capsule-binding projection for validation/review;
- no persisted classifier result.

F. COMMAND, RESULT, RECEIPT, AND REPLAY CONTRACT

Freeze exact C1 mutation families. At minimum evaluate:

1. phase establishment;
2. evidence-member admission.

For each freeze:

- command schema/fields/order;
- mutation ref;
- command digest domain;
- result fields/order;
- result digest;
- receipt fields/order;
- graph digest;
- committed timestamp semantics;
- idempotency key;
- exact replay predicate;
- same-key/different-command conflict;
- semantic collision cases;
- duplicate member under a new mutation ref;
- content-free outward errors;
- safe projections.

Do not add generic “upsert” semantics.

G. SCHEMA AND MIGRATION 0004

Recommend exact additive migration 0004.

Return:

- migration ID/name;
- application generation treatment;
- exact table inventory;
- exact columns, types, nullability, primary/unique/foreign keys;
- exact triggers/guards;
- exact indexes and why each exists;
- seed rows, expected to be zero;
- exact compatibility with prefixes 0001/0002/0003;
- exact cumulative-schema impact;
- downgrade/non-destructive posture;
- table ownership and authoritative-writer rules.

At minimum consider whether C1 needs separate physical tables for:

- phase instance;
- evidence member;
- relation/profile operand binding;
- mutation receipt;
- or whether a smaller normalized design safely combines any of them.

Reject generic JSON blobs or a universal evidence table if they weaken typed
closure, privacy, uniqueness, or recovery.

Do not create C2 closure, latch, decision, or terminal tables in 0004.

H. TRANSACTION SEQUENCING

Map each C1 mutation onto the existing:

- WriterSession operation guard;
- resource-owned mutation slot;
- transition transaction controller;
- writer fencing;
- nominal capability;
- receipt-first replay;
- capability invalidation;
- one commit attempt;
- cleanup;
- fresh-writer recovery.

Freeze exact SELECT and write order for each mutation.

Require no external I/O inside a transaction.

State which neutral helpers are reusable unchanged and which C1-specific
helpers/modules are required.

I. COMMIT-UNCERTAINTY RECOVERY

Freeze exact three-way recovery for each mutation:

```text
committed_exact
definitely_not_committed
unresolved
```

For phase establishment and member admission, define:

- required receipt evidence;
- required row family;
- graph/result digest checks;
- absence probes;
- collision probes;
- allowed pre-existing phase state during member recovery;
- partial-family outcomes;
- corrupt/unreadable outcomes;
- why no duplicate phase/member or speculative retry can occur.

A same-writer retry after commit uncertainty is forbidden.

J. PRIVATE READERS

Freeze exact private reader contracts.

At minimum evaluate:

- receipt by mutation ref;
- phase by basis pair/ref;
- phase by K8 collision key;
- member by phase/kind/member identity;
- relation/profile operand bindings;
- ordered bounded member page;
- graph/result locator;
- existing Section 41 proposal-family reader;
- existing program/work/head/selection/fence readers.

For each specify:

- input/output schema;
- ordering;
- cardinality;
- no-row/multi-row/corrupt-row behavior;
- nominal read capability;
- privacy-safe projection;
- whether it is used by recovery, diagnostics, or later C2.

No public reader is authorized.

K. C2 COMPATIBILITY SEAM

C1 must not precreate C2 state, but it must not make C2 impossible.

Freeze only the forward compatibility seam:

- stable phase identity;
- stable member identity;
- stable ordered membership enumeration;
- exact profile/relation operand bindings;
- ability for C2 to form distinct decision-basis and terminal-basis closures;
- ability for C2 to recompute cancellation-control classification;
- no mutable completeness flag;
- no single evidence closure;
- no latch/decision/terminal state.

List any C2 decision needed now that would otherwise force C1 churn. If a C2
detail is not required for C1 compatibility, defer it.

L. AUTHORITY AND PRIVACY

Confirm C1 stores no:

- raw WorkSpec;
- selected-plan content;
- capsule entries or blob bytes;
- bearer/credential/signature/trust root;
- endpoint/host/workspace secret;
- prompt/transcript/reasoning/response;
- raw stdout/stderr/provider logs;
- process identifiers or handles;
- external-authentication conclusion;
- permission, acceptance, or terminal authority.

Persistence proves only that Coordinator committed a privacy-safe supplied
claim and its owner-relation binding.

Confirm:

- private module(s);
- no package export;
- no public caller;
- no production caller before D/E;
- no StateStore or WriterSession public widening;
- no Bridge/ES/supporting-repository change.

M. PERMANENT TEST ARCHITECTURE

Map every proposed permanent test to one finite C1 product claim.

Required categories:

- migration resource identity;
- catalog sequence/application generation;
- exact schema/tables/columns/constraints/triggers/indexes;
- every typed row/value identity;
- privacy and forbidden material;
- phase establishment transaction order;
- member-admission transaction order;
- owner relation actually invoked;
- idempotency and exact replay;
- mutation-ref conflict;
- semantic collision;
- commit uncertainty at every write/commit/cleanup boundary;
- exact three-way recovery;
- reader cardinality/corruption behavior;
- membership-not-completeness;
- cancellation-control target/profile bindings;
- no persistence of classification;
- no I/O/public caller/authority widening;
- migration from all supported prefixes;
- cumulative schema;
- exact node/provenance compatibility.

Tests must not defend themselves against equal-authority mutation or become an
audit framework.

N. INDEPENDENT AUDIT ARCHITECTURE

Freeze bounded independent-audit responsibilities:

- exact patch and migration bytes;
- source/migration/touched-file provenance;
- independent schema inventory;
- external fault injection around every write and commit boundary;
- receipt/collision/partial-family mutants;
- privacy database inspection;
- relation/profile binding mutants;
- clean database from every supported migration prefix;
- live and clean validation;
- authority/public/import review;
- exact test causality.

Distinguish:

- candidate defects;
- contract defects;
- test/oracle defects;
- audit-harness defects;
- report defects;
- environment defects.

O. EXACT TOUCHED-FILE CEILING

Return the maximum C1 implementation allowlist.

Classify each touched path by reason:

- governing C1 owner document;
- synchronized status/authority projection;
- migration catalog/resource/cumulative schema;
- row/value/source module;
- transaction integration;
- reader integration;
- tests.

List protected paths explicitly.

Do not add files merely for organizational preference.

If the exact ceiling cannot be frozen, explain the unresolved causal dependency
rather than providing a loose range.

P. FORECASTS

Record two or three falsifiable forecasts:

- likely schema/transaction contradiction;
- likely implementation or audit finding;
- likely touched-file/migration scope;
- evidence that would force architectural replan.

Do not use unsupported percentages.

STOP CONDITIONS

Return `RW0_C_ARCHITECTURAL_REPLAN_REQUIRED` if any is established:

- B1/B2/C2A/C2B owner identity or relation change is required;
- the 15-kind inventory is insufficient;
- C1 is not independently useful;
- membership cannot remain distinct from completeness;
- a mutable phase/progression head is required;
- exact three-way recovery cannot be proven;
- privacy requires storing forbidden raw material;
- external I/O is required inside a transaction;
- a public or production caller is required before D/E;
- 0004 must precreate C2 closure/latch/terminal state;
- one authoritative writer per mutable fact cannot be preserved.

OUTPUT

Print inline:

# Baseline and inspection boundary
# Owner reconciliation after cancellation-control merge
# Observable C1 capability
# Phase identity and graph
# Exact 15-kind evidence inventory
# Relation and profile proof bindings
# Commands, results, receipts, and replay
# Migration 0004 schema
# Transaction sequencing
# Commit-uncertainty recovery
# Private readers
# C2 compatibility seam
# Authority and privacy
# Permanent-test architecture
# Independent-audit architecture
# Exact touched-file ceiling
# Findings and contradictions
# Forecasts and stop conditions
# Recommendation
# Next implementation boundary

End with exactly one:

RW0_C1_CONTRACT_FREEZE_READY

or

RW0_C_ARCHITECTURAL_REPLAN_REQUIRED

Do not issue an implementation prompt.

Required final statements:

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
