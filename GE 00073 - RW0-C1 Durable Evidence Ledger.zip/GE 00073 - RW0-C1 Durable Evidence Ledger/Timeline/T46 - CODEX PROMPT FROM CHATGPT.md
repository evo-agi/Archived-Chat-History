PROMPT_ID

RW0_C1_FRESH_REAUDIT_FINDINGS_REPAIR_V1

TITLE

Coordinator RW0-C1 — repair residual post-COMMIT close uncertainty, complete
definitely-not-committed identity routes, normalize recovery cleanup, and add
the missing permanent regression oracles

ENGAGEMENT TYPE

Second bounded parent-only workspace-write findings repair in the original
RW0-C1 implementation conversation.

Do not delegate to subagents.

This is not an architecture reset, migration change, or broad implementation
pass. Preserve the accepted C1/C2 decomposition, migration 0004, 15-kind
inventory, privacy model, transaction-controller ownership, public boundary,
and every unaffected candidate byte.

Do not stage, commit, push, create a PR, merge, tag, release, deploy, fetch,
contact a remote/live system, install dependencies, invoke a product
worker/model, modify a supporting repository, or migrate an operator database.

Print the complete substantive result inline. Evidence paths may be
supplementary only.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED OPENING IDENTITY

Require exactly:

branch:
codex/rw0-c1-durable-evidence-v1

HEAD:
047563de5a443b0f8323401c92979ae2e444d2ed

HEAD tree:
4ff9ee4a710af13447e3ed8699339a51255ff720

sole parent:
dd12b23762dc761736e55a1abfde12dd3ec23551

subject:
feat: add RW0-B2 cancellation-control evidence (#6)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

staged/unmerged:
0/0

candidate:
exactly 81 changed/untracked paths, all regular physical mode 0644

opening canonical manifest SHA-256:
7935bc7ba9162f07d47807eeefa50d794ff3381937c167bd77656c39c15f95bf

opening full-candidate textual diff SHA-256:
80dfa216c15b832afc980b26b0626afbc06058be912de64d898e3b90f998ad97

opening complete recipe output SHA-256:
811485f466891459b775dda4035ea1258478b93245347d89e6a141f80f41735d

opening nodes:
5177

opening ordered node SHA-256:
1718dbbab1ce2a906389607d2cae304c9dce3dfaffe2f40bff42b37b0d5b36b8

No fetch is authorized.

RETAINED EVIDENCE ROOTS

Verify read-only before mutation and preserve unchanged.

Original implementation:
/private/tmp/ge-coordinator-rw0-c1-implementation.Zcopmg
index:
cd1ad5ea72ef20a774fd470e38f14882a25f99af94db970c4506c62d4a4cc2b4

Mode repair:
/private/tmp/ge-coordinator-rw0-c1-mode-repair.k6Pxw5
index:
5b30767c439a982e209c765f93c775547709555f5305697817a1b335e1bf2cc8

First provenance-stop audit:
/private/tmp/ge-coordinator-rw0-c1-independent-audit.6Cd8VB
index:
3929be307c05a532c491f5f520bad4d76cde702d7e0b41460cf0c8ab90373b25

First substantive audit:
/private/tmp/ge-coordinator-rw0-c1-independent-audit.bYt6vjqX
index:
c276c664922dc4ef87e7418c6657aaf9d61ddb05c643666019ff85c86796168e

First findings repair:
/private/tmp/ge-coordinator-rw0-c1-audit-findings-repair.li1vJX
index:
a62fb4458f838ad23bc23b47bcfbd6527906c94724ea1a1b3044e3bf871c9bc2

Fresh re-audit:
/private/tmp/ge-coordinator-rw0-c1-fresh-reaudit.tWw8xz
index:
424c482738213c716dadaa636dde7f7a838f10472b63b0e9dabd8b226d8d0e5d

Do not alter, clean, re-index, or “repair” any retained root.

RE-AUDIT VERDICT TO REPAIR

The fresh re-audit returned BLOCK with:

Candidate defects:

1. RW0-C1-REAUD-001 — High
   Ordinary failures after a real successful COMMIT still escape during:
   - committed-result publication;
   - controller return;
   - module-delegate return;
   - operation retirement / outer writer cleanup.
   They escape as mutation_failed, database_integrity_failure, or raw
   RuntimeError even though selector recovery proves committed_exact.

2. RW0-C1-REAUD-002 — High
   definitely_not_committed remains unsound for hidden durable identity routes:
   - typed payload under another value_ref but selector value_digest;
   - rank-1 child-only fragment with parent rows absent;
   - corresponding rank-12 child-family blind spot;
   - relation operand using the deterministic operation relation_ref under a
     foreign phase.
   The current implementation lacks independent payload-digest, child-only,
   and global relation-identity probes.

3. RW0-C1-REAUD-003 — Medium
   Explicit recovery cleanup faults at mutation-lease and operation-lease close
   can escape as database_integrity_failure or raw RuntimeError instead of one
   of the three permitted recovery dispositions.

Permanent-test defect:

4. RW0-C1-REAUD-004 — Medium
   Permanent tests omit the above controller/module/outer-close boundaries,
   safe cleanup variants, payload-digest alias, child-only fragments,
   wrong-phase global operands, and recovery lease cleanup faults.

FIRST-AUDIT CLOSURE STATUS

Preserve this exact disposition:

- AUD-001 caller-constructible selector: closed.
- AUD-002 DNC soundness: not fully closed; superseded by REAUD-002.
- AUD-003 post-COMMIT cleanup: not fully closed; superseded by REAUD-001 and
  REAUD-003.
- AUD-004 CAS ordering: closed.
- AUD-005 owner-reader propagation: closed.
- AUD-006 permanent-oracle completeness: not fully closed; superseded by
  REAUD-004.
- AUD-007 strict temporal equality: closed.
- AUD-008 original red gate: historical and non-creditable; correctly
  preserved.

Do not reopen closed findings except to prevent regression.

ARCHITECTURAL DISPOSITION

Do not change:

- migration 0004 SQL, checksum, or catalog;
- 23/46/4 C1 schema delta or 62/110/5 cumulative totals;
- table/column/key/FK/trigger/index design;
- 15 evidence kinds;
- C1/C2 decomposition;
- privacy-safe transient bindings;
- membership identity;
- kind-scoped evidence identity;
- same-phase relation integrity;
- temporal and mutable-snapshot semantics;
- rank-13/rank-14 algebra;
- public/package/StateStore/WriterSession protocol surfaces;
- B1/Wire/Capability/C2A/C2B/Section 41 owner semantics;
- one-controller, one-connection, one-commit-attempt authority;
- no C2, D/E, ES, Bridge, worker, provider, process, runtime, or external
  contact behavior.

The re-audit found no defect in those areas.

PRIMARY ENGINEERING DECISIONS

A. CROSS-LAYER COMMIT-CLOSE WITNESS

The repair must retain uncertainty from the exact commit-attempt boundary until
the complete outer close proof succeeds.

Add one private in-memory C1 commit-close witness shared by:

- writer-session C1 fresh-apply wrapper;
- module-level C1 transaction wrapper;
- `_CoordinatorMutationTransactionController` C1 apply path.

It is not persisted, exported, or authoritative.

Closed states:

```text
precommit
commit_attempt_started
commit_returned_success
close_proof_complete
```

Required transitions:

1. Writer-session C1 fresh apply creates the witness before entering the
   transaction wrapper.
2. Controller marks `commit_attempt_started` immediately before the sole
   underlying COMMIT invocation.
3. Controller marks `commit_returned_success` only after COMMIT returns
   normally.
4. Writer-session layer marks `close_proof_complete` only after all of:
   - committed-result publication;
   - controller method return;
   - module-level delegate return;
   - nominal-capability finalization;
   - controller/connection cleanup;
   - mutation-slot close;
   - operation-lease close;
   - process-control stabilization;
   - writer-session post-operation cleanup.
5. No result reaches the caller before `close_proof_complete`.

Ordinary-exception normalization:

- If state is `precommit`, preserve the existing pre-commit semantic,
  integrity, and operational classification.
- If state is `commit_attempt_started` or `commit_returned_success` and close
  proof is incomplete, every ordinary exception at any controller, module, or
  writer layer becomes exact content-free `commit_outcome_unknown`.
- An already sanitized `commit_outcome_unknown` propagates unchanged.
- Preserve governing `KeyboardInterrupt`, `SystemExit`, `GeneratorExit`, and
  existing process-control precedence.
- Do not convert exact replay or conflict paths that never attempt COMMIT into
  commit uncertainty.
- The witness cannot be reset to precommit and cannot be reused across
  operations.

Use the existing private transaction/result vocabulary where possible. If a
new private helper type is needed, keep it inside the bounded private C1
transaction contract and do not create a public value or schema.

The repair must close, with real COMMIT:

- result publication fault;
- controller-return fault;
- module-delegate-return fault;
- controller/connection cleanup fault;
- mutation-slot close fault;
- operation-lease close fault;
- process-stabilization fault;
- writer-session post-operation cleanup fault.

For every case:

- caller sees `commit_outcome_unknown`;
- no raw exception or narrower failure escapes;
- retained pre-apply selector recovers `committed_exact`;
- rows/receipt are exact and no duplicate is created.

B. COMPLETE DNC IDENTITY-ROUTE PROBES

The DNC proof must inspect every durable route by which the attempted operation
or a conflicting identity can exist.

1. Typed payload probes

For the selector’s exact kind:

- probe typed payload by `(kind_rank, value_ref)`;
- independently probe typed payload by `(kind_rank, value_digest)`;
- verify exact schema/ref/digest/row identity;
- an exact reusable typed family is permitted only with its exact registry;
- another ref with the selector digest is an alias -> unresolved;
- another digest with the selector ref is an alias -> unresolved;
- payload without registry or registry without payload -> unresolved.

Add exact literal reader-contract queries. Do not use SELECT * or caller-
supplied table names. Use the closed kind-to-table map.

2. Normalized child probes independent of parents

For rank 1 and rank 12:

- inspect child rows by the selector value ref route;
- inspect child rows by the selector value digest route;
- perform these checks even when both registry and typed parent are absent;
- any child-only or mismatched child family -> unresolved;
- exact children are permitted only as part of an exact reusable
  registry/payload/child family.

Use bounded explicit-column reads and existing child maxima.

3. Operation relation identities

The operation’s deterministic relation refs are durable global identities.
Before DNC:

- probe relation binding by each deterministic relation_ref without filtering
  by phase;
- probe relation operands by each deterministic relation_ref without filtering
  by phase;
- any binding or operand row under another phase or malformed subject ->
  unresolved;
- only complete global absence permits DNC.

Do not rely on phase-filtered operand absence.

4. Existing DNC requirements remain mandatory

- exact prerequisite phase;
- exact immutable prerequisite memberships;
- exact immutable owner prerequisites;
- receipt absent;
- preassigned membership absent;
- phase/kind/value ref and digest membership routes absent;
- no relation/receipt/membership fragment;
- no unreadable or malformed state.

Return only:

```text
committed_exact
definitely_not_committed
unresolved
```

C. RECOVERY CLEANUP ALGEBRA

Recovery has no COMMIT, so do not use `commit_outcome_unknown`.

At both recovery lease layers:

- mutation-slot / mutation-lease retirement;
- operation-lease retirement and outer writer cleanup;

apply the existing primary-failure and process-control precedence, then:

- if an ordinary cleanup failure occurs after a recovery disposition has been
  computed but before close proof completes, return exact content-free
  `unresolved`;
- do not raise database_integrity_failure, mutation_failed, or raw RuntimeError
  solely because recovery cleanup became uncertain;
- no `committed_exact` or `definitely_not_committed` result reaches the caller
  before the recovery close proof succeeds;
- preserve a primary governing process-control exception;
- preserve a primary pre-result safe error according to existing repository
  precedence, but do not let a secondary cleanup error masquerade as semantic
  absence.

Use a private in-memory recovery-close witness or an equally exact private
mechanism. It must not become durable state or public API.

D. PERMANENT REGRESSION ORACLES

Add ordinary product tests, not a self-protecting audit framework.

Required real-commit matrix:

1. post-COMMIT result publication;
2. controller return;
3. module-delegate return;
4. controller/connection cleanup;
5. mutation-slot close;
6. operation-lease close;
7. process stabilization;
8. writer-session post-operation cleanup.

Each test must:

- use a disposable external database;
- produce a real successful underlying COMMIT;
- observe exact `commit_outcome_unknown`;
- recover using only the selector retained before apply;
- obtain `committed_exact`;
- prove no duplicate family/receipt.

Required DNC malformed-state matrix:

- typed payload digest alias under another ref;
- typed payload ref alias under another digest;
- rank-1 child-only by ref;
- rank-1 child-only by digest;
- rank-12 child-only by ref;
- rank-12 child-only by digest;
- global relation binding under foreign phase;
- global relation operand under foreign phase;
- exact reusable registry/payload/children -> DNC;
- each partial or alias state -> unresolved.

Required recovery-cleanup matrix:

- recovery mutation-lease close fault after real close;
- recovery operation-lease close fault after real close;
- outer writer cleanup fault after a computed recovery disposition;
- each returns `unresolved`;
- no raw/narrower error.

Keep the closed CAS-order, owner-reader, selector, and temporal tests green.

E. TEST-FIRST REPAIR CHRONOLOGY

Before production repair:

1. Modify only allowed test files.
2. Keep production bytes equal to the opening repaired candidate.
3. Run one selected red gate.
4. Require deterministic expected failures covering REAUD-001, REAUD-002, and
   REAUD-003.
5. Require no harness, fixture, syntax, import, path, or environment failure.
6. Preserve exact node list, stdout/stderr, JUnit, and candidate fingerprint.

Tests that already pass against current code are green boundary controls and
must not be misrepresented as red evidence.

F. BOUNDED REPAIR ALLOWLIST

Only these repository paths may change.

Documentation — 4:

.docs/rw0-c1-durable-evidence.md
.docs/sqlite-operations-and-recovery.md
.docs/sqlite-threat-model.md
.docs/writer-session-authority.md

Production — 6:

src/ge_nwp_coordinator/_rw0_c1_mutation_contracts.py
src/ge_nwp_coordinator/_sqlite_rw0_c1_reader_contracts.py
src/ge_nwp_coordinator/_sqlite_rw0_c1_readers.py
src/ge_nwp_coordinator/_sqlite_rw0_c1.py
src/ge_nwp_coordinator/sqlite_transition_transaction.py
src/ge_nwp_coordinator/sqlite_writer_session.py

Tests — 9:

tests/test_rw0_c1_mutation_contracts.py
tests/test_rw0_c1_reader_contracts.py
tests/test_rw0_c1_private_readers.py
tests/test_rw0_c1_private_atomic_persistence.py
tests/test_rw0_c1_recovery.py
tests/test_rw0_c1_writer_session_delegation.py
tests/test_b3c4c_prerequisite_contract.py
tests/test_b2a_writer_session_contract.py
tests/test_sqlite_b2c_writer_session.py

Maximum:
19 repository paths

A listed path may remain byte-identical. No path outside this set may change.

If another path is required, stop:

RW0_C1_REAUDIT_FINDINGS_REPAIR_SCOPE_CONFLICT

Protected:

- migration 0004 SQL;
- sqlite_migration.py;
- row-value schema/table modules unless this prompt explicitly lists them;
- semantic owner modules;
- migrations 0001–0003;
- package exports;
- StateStore;
- public WriterSession protocol;
- every other candidate path;
- supporting repositories.

G. VALIDATION

Create one new private external evidence root:

/private/tmp/ge-coordinator-rw0-c1-reaudit-findings-repair.XXXXXX

Use:

umask 0022
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
unique evidence-root PYTHONPYCACHEPREFIX per Python process
distinct evidence-root TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
GIT_OPTIONAL_LOCKS=0
python3 -B
-p no:cacheprovider
-W error

Run serially with external basetemp, stdout, stderr and JUnit.

After the causal red and source repair:

1. Selected residual-finding tests.
2. Every changed C1 test file.
3. All nine C1 modules.
4. Reader/controller/writer compatibility.
5. Existing transition/global-stop/C2B cleanup and transaction regressions.
6. Migration/schema/fixture compatibility.
7. Owner compatibility.
8. Architecture/status/privacy/non-authority.
9. External isolated probes for every repaired route.
10. Final collection.
11. One official complete-suite attempt.

Every credited run requires:

- return code 0;
- all cases passed;
- zero failures/errors/skips/xfails/xpasses/warnings;
- empty stderr;
- parseable JUnit;
- zero duplicate/unmapped cases;
- umask 0022;
- unchanged candidate fingerprint.

If complete-suite attempt 001 fails:

- retain it;
- classify candidate versus harness/environment;
- repair only within the 19-path scope;
- rerun affected focused groups and recollect;
- permit at most one attempt 002;
- no third attempt.

H. NODE RECONCILIATION

Opening nodes:

5177

Opening ordered SHA-256:

1718dbbab1ce2a906389607d2cae304c9dce3dfaffe2f40bff42b37b0d5b36b8

At final collection require:

- all 5177 opening nodes retained in exact relative order;
- zero removals/renames;
- zero added skip/xfail;
- all additions listed and attributable to allowed tests;
- no duplicate/volume-only parametrization;
- clean and live collections identical if a clean copy is built.

I. PROVENANCE AND CLOSEOUT

Use the exact recipe:

recipe ID:
governed-execution.audit-patch-manifest.v1

source size:
3945 bytes

source SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

Use the already verified safe sink-redirection wrapper. Do not mutate the
historical sink.

At closeout:

- verify exact branch/HEAD/upstream/worktree/topology;
- exactly 81 candidate paths, all mode 0644;
- only allowed repair paths differ from opening candidate;
- no staged/unmerged/lock/operation/residue;
- `git diff --check`;
- migrations 0001–0004 and all protected owner bytes unchanged;
- no public/package/StateStore/WriterSession protocol widening;
- exact recipe twice with byte-identical manifests and complete output;
- report final manifest, textual diff, complete output, file count and exact
  repair delta;
- verify all retained predecessor/audit evidence roots unchanged;
- remove only repair-created transient external paths;
- create a self-excluding evidence index last and independently reverify it.

HISTORICAL EVIDENCE

Do not rewrite earlier reports.

Preserve:

- original implementation red as historical non-creditable;
- first repair red as evidence for its actual covered routes;
- first re-audit as authoritative defect evidence;
- second repair red and permanent tests as the new causal evidence for the
  residual routes.

SUCCESS TOKEN

Return exactly:

COORDINATOR_RW0_C1_REAUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT

only if:

- REAUD-001, REAUD-002 and REAUD-003 are repaired;
- REAUD-004 is closed with causal permanent tests;
- no schema, privacy, architecture, authority or public surface changes;
- validation and provenance are complete;
- no independent re-audit is claimed.

FINAL INLINE REPORT

Use:

# Outcome
# Opening identity and retained evidence
# REAUD-001 cross-layer commit-close repair
# REAUD-002 complete DNC identity-route repair
# REAUD-003 recovery cleanup repair
# REAUD-004 permanent-test closure
# Test-first repair chronology
# Exact touched-path delta
# Focused validation
# Node reconciliation
# Complete-suite validation
# Provenance and cleanup
# Authority and nonclaims
# Remaining seams
# Confidence

Required final statements:

INDEPENDENT_REAUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
MIGRATION_SCHEMA_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
STATESTORE_PUBLIC_SURFACE_NOT_WIDENED
WRITERSESSION_PUBLIC_PROTOCOL_NOT_WIDENED
RW0_C2_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
