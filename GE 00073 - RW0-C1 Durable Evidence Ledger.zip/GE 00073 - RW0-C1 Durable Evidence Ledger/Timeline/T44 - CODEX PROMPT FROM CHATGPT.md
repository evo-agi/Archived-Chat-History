PROMPT_ID

RW0_C1_FRESH_INDEPENDENT_REAUDIT_AFTER_FINDINGS_REPAIR_V1

TITLE

Coordinator RW0-C1 — fresh independent re-audit after repair of recovery,
post-commit cleanup, CAS-ordering, reader-fault, and permanent-test findings

ENGAGEMENT TYPE

Fresh independent read-only audit.

Do not repair, edit, format, generate repository files, stage, commit, push,
create a PR, merge, tag, release, deploy, fetch, contact a remote/live system,
install dependencies, invoke a product worker/model, modify a supporting
repository, or migrate an operator database.

Do not resume or modify any earlier audit root. Create one new private audit
root.

Print the complete substantive report inline. Evidence files may be
supplementary only; the verdict and finding ledger must not exist only in a
file.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED LIVE REPOSITORY IDENTITY

physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-c1-durable-evidence-v1

HEAD:
047563de5a443b0f8323401c92979ae2e444d2ed

HEAD tree:
4ff9ee4a710af13447e3ed8699339a51255ff720

sole parent:
dd12b23762dc761736e55a1abfde12dd3ec23551

subject:
feat: add RW0-B2 cancellation-control evidence (#6)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

staged/unmerged:
0/0

candidate:
exactly 81 changed/untracked paths, all regular physical mode 0644, no 82nd
path, no repository residue.

No fetch is authorized. Use local Git metadata only.

CURRENT REPAIRED CANDIDATE IDENTITIES

Final canonical manifest SHA-256:
7935bc7ba9162f07d47807eeefa50d794ff3381937c167bd77656c39c15f95bf

Final full-candidate tracked textual diff SHA-256:
80dfa216c15b832afc980b26b0626afbc06058be912de64d898e3b90f998ad97

Final complete recipe output SHA-256:
811485f466891459b775dda4035ea1258478b93245347d89e6a141f80f41735d

Candidate file count:
81

Final collected nodes:
5177

Final ordered node SHA-256:
1718dbbab1ce2a906389607d2cae304c9dce3dfaffe2f40bff42b37b0d5b36b8

Opening repaired-candidate nodes before findings repair:
5157

Opening repaired-candidate ordered node SHA-256:
efd65837c5c0e05bcd720dc52be6bfd32aa1f861392496864900fb083e0971df

Node additions:
20

Removals/renames:
0/0

REPAIR EVIDENCE ROOT

/private/tmp/ge-coordinator-rw0-c1-audit-findings-repair.li1vJX

Self-excluding index:
/private/tmp/ge-coordinator-rw0-c1-audit-findings-repair.li1vJX/evidence-index.txt

Index SHA-256:
a62fb4458f838ad23bc23b47bcfbd6527906c94724ea1a1b3044e3bf871c9bc2

Indexed files:
386

Indexed subdirectories:
49

RETAINED PREDECESSOR EVIDENCE ROOTS

Verify all read-only and preserve unchanged.

Original implementation:
/private/tmp/ge-coordinator-rw0-c1-implementation.Zcopmg
index SHA-256:
cd1ad5ea72ef20a774fd470e38f14882a25f99af94db970c4506c62d4a4cc2b4

Mode repair / validation reset:
/private/tmp/ge-coordinator-rw0-c1-mode-repair.k6Pxw5
index SHA-256:
5b30767c439a982e209c765f93c775547709555f5305697817a1b335e1bf2cc8

First provenance-stop audit:
/private/tmp/ge-coordinator-rw0-c1-independent-audit.6Cd8VB
index SHA-256:
3929be307c05a532c491f5f520bad4d76cde702d7e0b41460cf0c8ab90373b25

First substantive audit:
/private/tmp/ge-coordinator-rw0-c1-independent-audit.bYt6vjqX
index SHA-256:
c276c664922dc4ef87e7418c6657aaf9d61ddb05c643666019ff85c86796168e

Do not alter, clean, re-index, or reinterpret these roots in place.

EXACT PROVENANCE RECIPE

recipe ID:
governed-execution.audit-patch-manifest.v1

source size:
3945 bytes

source SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

Verify the indexed exact source and safe historical-sink redirection wrapper.
The wrapper may redirect only the output sink and must not alter Git queries,
canonical JSON, stdout, stderr, path classification, or manifest fields.

FIRST-AUDIT FINDINGS THAT MUST BE CLOSED

Candidate defects:

RW0-C1-AUD-001 — High
Commit-uncertainty recovery input was not caller-constructible.

RW0-C1-AUD-002 — High
definitely_not_committed was unsound for missing prerequisites, registry
aliases, reusable registry posture, and partial families.

RW0-C1-AUD-003 — High
ordinary post-commit cleanup failures escaped the commit-resolution algebra.

RW0-C1-AUD-004 — Medium
actual-current program/work CAS occurred after collision and prerequisite
probes.

RW0-C1-AUD-005 — Medium
owner-reader integrity and operational failures collapsed to owner_row_missing.

Test/oracle defects:

RW0-C1-AUD-006 — Medium
recovery/cleanup/ordering/reader-fault tests omitted material boundaries and
used direct SQLite inspection to obtain recovery-only data.

RW0-C1-AUD-007 — Low
rank-6/rank-9 temporal equality was not protected from `>` to `>=` weakening.

Historical report defect:

RW0-C1-AUD-008 — Low
the original implementation red gate was missing-resource scaffolding rather
than substantive semantic evidence.

AUD-008 is historical and cannot be retroactively repaired. Verify that the
repair report preserves it as non-creditable and that the repair tranche
contains its own substantive causal red gate.

CLAIMED REPAIR DELTA

The repair report claims exactly 13 opening-to-final changed paths, all within
the authorized 17-path ceiling.

Documentation:

.docs/rw0-c1-durable-evidence.md
.docs/sqlite-operations-and-recovery.md
.docs/sqlite-threat-model.md
.docs/writer-session-authority.md

Production:

src/ge_nwp_coordinator/_rw0_c1_semantic_values.py
src/ge_nwp_coordinator/_sqlite_rw0_c1.py
src/ge_nwp_coordinator/sqlite_transition_transaction.py
src/ge_nwp_coordinator/sqlite_writer_session.py

Tests:

tests/test_b3c4c_prerequisite_contract.py
tests/test_rw0_c1_private_atomic_persistence.py
tests/test_rw0_c1_recovery.py
tests/test_rw0_c1_semantic_values.py
tests/test_rw0_c1_writer_session_delegation.py

Require no other opening-to-final byte change.

Migration 0004, sqlite_migration.py, row schemas, package exports, StateStore,
public WriterSession protocol, semantic owner modules, and the other candidate
paths must remain byte-identical to the mode-repaired opening candidate unless
the repaired manifest itself proves otherwise. Any unexplained extra delta is a
provenance failure.

AUDIT POSTURE

Use one new private audit root under `/private/tmp`.

Use:

umask 0022
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
unique audit-root PYTHONPYCACHEPREFIX for every Python process
distinct audit-root TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
GIT_OPTIONAL_LOCKS=0
python3 -B
-p no:cacheprovider
-W error

Keep evidence proportionate. Do not build a recursive self-protecting audit
framework. Do not require permanent tests to detect equal-authority mutation.

After provenance passes, conduct exactly four bounded, non-nesting read-only
perspectives; the parent reconciles them:

1. recovery selector and definitely-not-committed semantics;
2. transaction close/commit algebra and authority ordering;
3. reader fault propagation, temporal behavior, and durable-state regressions;
4. permanent-test causality, provenance, validation, public/authority surface.

No child perspective may delegate further or modify repository files.

PROVENANCE GATE

Before correctness inspection:

1. Verify exact branch/HEAD/tree/parent/upstream/divergence/worktree count.
2. Verify exactly 81 candidate paths, all regular mode 0644.
3. Verify no staged/unmerged path and no 82nd path.
4. Verify the repair evidence root index exactly:
   path set, type, owner, mode, size, hash, no unsafe or unindexed entry.
5. Verify every predecessor evidence index exactly.
6. Verify exact recipe source and wrapper.
7. Run the recipe twice with safe sink redirection.
8. Require byte-identical manifests and complete output matching:
   - manifest 7935bc7b...
   - textual diff 80dfa216...
   - complete output 811485f4...
   - 81 files.
9. Verify every live candidate entry against the manifest.
10. Require every path outside the candidate to equal HEAD.
11. Verify exact 13-path repair delta against the repaired opening candidate.
12. Verify migrations 0001–0004, sqlite_migration.py, public surfaces, and all
    protected owner modules against the expected opening/final posture.
13. Record opening repository and evidence inventories for closeout.

Stop before correctness on any mismatch:

AUDIT_PROVENANCE_MISMATCH

RE-AUDIT HYPOTHESES

A. Caller-constructible recovery selector

Independently verify:

- exact private selector schema, fields, canonicalization and digest;
- pure construction from a validated admission command before transaction
  entry;
- no SQLite read, clock read, I/O, authority action, membership digest,
  admitted_at, relation/result/receipt digest, or mutable-head snapshot needed;
- legitimate caller can retain it before apply;
- forced commit_outcome_unknown after a real commit resolves committed_exact
  using only the retained selector and the recovery API;
- selector mismatch cannot select or disclose another mutation/member;
- phase-establishment recovery remains caller-constructible.

Externally probe malformed selector, wrong command digest, wrong phase,
membership, kind, value, prerequisite and owner locator posture.

B. definitely_not_committed proof

Independently exercise the complete matrix.

DNC is allowed only when:

- phase exists and is exact;
- immutable prerequisite memberships are exact;
- immutable required owner rows are exact;
- receipt absent;
- preassigned membership ref absent;
- phase/kind/value ref and digest membership routes absent;
- operation-owned relation/operand identities absent;
- registry/payload wholly absent or exact reusable family;
- no alias, malformed registry, missing payload, partial child family, receipt,
  membership or relation fragment.

Require unresolved for:

- missing phase;
- missing prerequisite membership;
- missing/corrupt immutable owner prerequisite;
- ref alias;
- digest alias;
- registry-only;
- payload-only;
- partial children;
- receipt-only;
- membership-only;
- relation/operand fragment;
- malformed/unreadable state;
- inability to prove absence.

Verify a future retry re-evaluates mutable current program/work CAS rather than
freezing it into DNC.

C. Post-commit cleanup algebra

Independently inject ordinary failures after an actual underlying commit at
each material boundary:

- committed-result publication;
- nominal-capability finalization;
- controller/connection cleanup;
- mutation-slot close;
- operation-lease close;
- process-control stabilization;
- writer-session post-operation cleanup.

Require:

- no database_integrity_failure;
- no mutation_failed;
- no raw RuntimeError or arbitrary exception;
- commit_outcome_unknown until full close proof succeeds;
- committed rows remain exact and selector-based recovery returns
  committed_exact.

Verify the repair is scoped to RW0-C1 and did not regress existing transition,
global-stop, C2B, or writer-session cleanup semantics.

D. Current-state CAS precedence

On a receipt miss, inject:

- stale actual program/work state;
- plus an already-admitted membership or registry/member collision.

Require:

- actual current program/work read and CAS check occur before registry,
  membership, prerequisite, relation or semantic-collision probes;
- result is current_state_conflict;
- later probes are not invoked;
- no collision details leak.

Verify exact receipt replay remains receipt-first and independent of later head
progression.

E. Owner-reader error propagation

Independently probe owner readers used by C1.

Require:

- actual None -> owner_row_missing;
- sanitized database_integrity_failure propagates unchanged;
- sanitized mutation_failed propagates unchanged;
- sanitized commit_outcome_unknown propagates where applicable;
- cursor, SELECT, tuple-shape, duplicate-row, and cleanup failures never become
  owner_row_missing;
- process-control exceptions retain governing behavior;
- no unsanitized private content leaks.

F. Permanent test causality and oracle quality

Review the 20 added nodes and every changed existing test.

Require causal coverage of:

- selector preconstruction and no membership-digest dependence;
- ambiguous real commit recovered by selector;
- missing phase/prerequisite and registry aliases -> unresolved;
- exact reusable registry family -> DNC;
- partial registry/payload/children and row fragments -> unresolved;
- post-commit slot/controller/lease failures -> unknown then committed recovery;
- CAS-before-collision ordering;
- None versus safe owner-reader faults;
- rank-6/rank-9 exact temporal equality and later admission with earlier equal
  semantic time.

Re-run external one-predicate mutants. Do not accept the implementation
report’s aggregate `2/4` or `3/4` summaries as proof. For each mutant state:

- exact source hunk;
- exact intended predicate;
- exact selected node(s);
- expected and actual outcome;
- finite diagnostic;
- restoration proof.

Specifically verify the `evaluated_at > operation_timestamp` to `>=` mutant is
killed by both pure and persistence/readback equality coverage.

Verify the new repair red gate:

- ran against opening source bytes;
- had intended product failures for AUD-001 through AUD-005;
- contained no harness failures;
- is not merely a missing resource/symbol gate.

Preserve AUD-008 as historical non-creditable evidence; do not pretend to
rewrite it.

G. Schema, privacy and architecture regression

The first audit passed schema/privacy/authority. Reverify no repair regression:

- migration 0004 bytes and checksum unchanged;
- 23/46/4 delta and 62/110/5 totals unchanged;
- all 15 kinds unchanged;
- no capsule/private material in SQLite;
- no public/package/StateStore/WriterSession protocol widening;
- no production caller;
- no C2/D/E/ES/Bridge/runtime/external-contact behavior;
- B1/Wire/Capability/C2A/C2B/Section 41 owners unchanged;
- one transaction controller and one connection/commit authority.

H. Replay, transaction and recovery regression

Re-run bounded probes for:

- exact replay with no writes/no clock;
- mutation_ref_reuse;
- phase and K8 collisions;
- member identity/already admitted;
- missing prerequisite;
- relation identity/failure;
- stale writer;
- database integrity;
- one commit attempt;
- no same-writer automatic retry;
- committed_exact / definitely_not_committed / unresolved;
- progression-safe mutable snapshots;
- persisted temporal replay without current wall clock.

Ensure the selector addition did not create a new durable authority or alternate
read path.

I. Reader and controller regression

Verify:

- exact limits 2,3,15,16,257,258;
- no SELECT *;
- same-phase membership integrity;
- relation/operand overflow checks;
- private capability-only readers;
- no direct sqlite3 import in _sqlite_rw0_c1.py;
- sole controller and private concrete writer-session delegation;
- cleanup normalization does not weaken process-control or existing operation
  families.

INDEPENDENT VALIDATION ORDER

1. Provenance gate.
2. Static inspection of repaired paths and protected-byte comparison.
3. External recovery-selector/DNC/cleanup/CAS/reader probes.
4. External temporal mutant and one-predicate repair mutants.
5. Fresh focused runs:
   - repair regression focus;
   - all nine C1 modules;
   - reader/controller/writer compatibility;
   - migration/schema/fixture compatibility;
   - owner compatibility boundaries;
   - architecture/status/privacy/non-authority.
6. Fresh live collection.
7. Build an independent clean candidate:
   - exact HEAD archive;
   - overlay exactly 81 final manifest paths;
   - fully external Git repository/object database;
   - no alternates and no shared source-object inodes;
   - diagnostic commit of exact candidate tree.
8. Clean collection and focused repair/C1 validation.
9. If no Critical, High, Medium or Low blocker remains:
   - run one live complete suite;
   - run one external clean-commit complete suite.
10. Closeout and exact provenance reproduction.

Do not substitute retained repair validation for independent validation.
If deterministic material blockers are found before the complete-suite gate,
withhold complete suites and state so.

FINDING CLASSIFICATION

For each finding report:

- ID;
- type;
- severity: Critical / High / Medium / Low / Observation;
- current contract or target;
- exact path/line;
- evidence and reproduction;
- impact;
- required correction;
- uncertainty;
- classification:
  candidate defect, contract defect, test/oracle defect, audit-harness defect,
  report defect, or environment defect.

Do not allow an audit-harness issue to masquerade as a candidate defect, and do
not allow passing broad tests to override deterministic transaction/recovery
failure.

CLOSEOUT

At closeout:

- reproduce the final manifest twice;
- verify opening/closing repository identity, status, path set, modes, diff and
  candidate fingerprint;
- verify all predecessor and repair evidence roots unchanged;
- remove only audit-created disposable paths;
- retain material commands, probes, stdout/stderr, JUnit, node lists, manifests,
  schema inventories and report;
- root/directories mode 0700, retained files mode 0400;
- no retained symlink or special entry;
- create a self-excluding evidence index last and independently reverify it.

VERDICT

Return:

ACCEPT

and exactly:

COORDINATOR_RW0_C1_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE

only if provenance, every repaired finding, regression behavior, schema,
privacy, authority, tests, independent validation, and evidence all pass with
no Critical, High, Medium, or Low finding.

Otherwise return:

BLOCK

with a severity-ranked ledger and no repair.

REQUIRED FINAL STATEMENTS

REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
MIGRATION_SCHEMA_NOT_MODIFIED
PUBLIC_API_NOT_WIDENED
RW0_C2_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
