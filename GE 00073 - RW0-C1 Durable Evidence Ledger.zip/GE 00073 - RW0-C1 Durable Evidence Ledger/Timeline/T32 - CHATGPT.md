# Disposition

**The mutable-snapshot and historical-recovery design is now sound, but RW0-C1 is still not implementation-ready.**

The correct terminal classification remains:

```text
RW0_C1_FREEZE_RECONCILIATION_REQUIRED
```

The attached response closes the prior issues well:

- phase establishment now has an inspectable relation and 14-operand closure;
- mutable selection/effect/delivery/global-stop rows are converted into immutable phase-local snapshot bindings;
- committed recovery no longer depends on those current rows retaining their old values;
- ordinary immutable owner rows no longer receive an invented scope digest;
- table, trigger, index, and path counts remain unchanged.

In particular, committed recovery reconstructs the four mutable snapshots from the immutable phase row instead of rereading current heads. :chatgpt-content-reference{index="0"}

## Remaining blocker: evaluation time is incorrectly tied to admission time

The report freezes:

```text
membership.admitted_at
=
relation.evaluated_at
=
operation_timestamp
```

for all six time-sensitive relations. :chatgpt-content-reference{index="1"}

It then explicitly requires rank 9 to be admitted in the same whole-second window as its already admitted rank-6 prerequisite. :chatgpt-content-reference{index="2"}

That is not required by the merged owner contracts and creates a brittle race between two separate single-member transactions.

The owner semantics are:

```text
validate_host_qualification:
host_qualification.evaluated_at == now_utc
```

at:

```text
src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py:2128-2130
```

and:

```text
validate_worker_mechanism_capability_qualification:
capability_qualification.evaluated_at
==
host_qualification.evaluated_at
==
now_utc
```

at:

```text
src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py:783-807
```

Neither owner says that this semantic evaluation instant must equal the later SQLite membership-admission timestamp.

## Required temporal contract

C1 needs two distinct timestamps.

### Durable admission time

```text
operation_timestamp
```

- captured by the transaction controller;
- stored as `membership.admitted_at`;
- used for result and receipt commit timestamps;
- records when Coordinator persisted the member.

### Owner semantic evaluation time

```text
relation.evaluated_at
```

- passed to the owner’s `now_utc`;
- stored in the relation;
- included in relation, relation-set, graph, result, and receipt verification;
- reused during replay and recovery;
- never replaced with the current clock.

The exact mapping should be:

```text
Ranks 1, 2, 3, 4:
  relation.evaluated_at = operation_timestamp

Rank 6:
  relation.evaluated_at =
    RW0EffectHostQualificationV1.evaluated_at

Rank 9:
  relation.evaluated_at =
    RW0WorkerMechanismCapabilityQualificationV1.evaluated_at
  =
    prerequisite rank-6 host qualification evaluated_at
```

For ranks 6 and 9:

```text
relation.evaluated_at <= membership.admitted_at
```

Future-dated evidence fails before writing.

This preserves all owner semantics while allowing rank 9 to be admitted minutes or days after rank 6. It also preserves single-member admission and avoids inventing a grouped transaction.

The resulting nonclaim must be explicit:

> Rank-6 and rank-9 membership proves that the supplied qualification was owner-valid at its stated evaluation instant. It does not prove that the qualification remains current at admission time or at a later C2 decision.

C2 remains responsible for closure-time currentness.

## What does not change

This correction requires no additional:

- table;
- column;
- trigger;
- index;
- touched path;
- transaction controller;
- member kind;
- grouped-admission operation.

The expected identities remain:

```text
Migration 0004:
23 tables
46 triggers
4 explicit indexes

Cumulative:
62 tables
110 triggers
5 explicit indexes

Implementation allowlist:
81 paths
```

The latest report’s assertion that the contract is implementation-ready is therefore premature only on this temporal point. :chatgpt-content-reference{index="3"}

# Final read-only closure prompt

Send this to the same Coordinator Codex conversation:

:chatgpt-content-reference{index="5"}[Download the semantic-evaluation versus admission-time closure prompt](sandbox:/mnt/data/Coordinator_RW0_C1_Semantic_Evaluation_vs_Admission_Time_Closure_Prompt.txt)

```text
Filename:
Coordinator_RW0_C1_Semantic_Evaluation_vs_Admission_Time_Closure_Prompt.txt

Size:
8,752 bytes

SHA-256:
6b374f3428735d93f5761352a805dbc3d5a3deece140dc8e438aec16a3ef4af8
```

The successful result is:

```text
RW0_C1_IMPLEMENTATION_CONTRACT_READY
```

After that result, the contract should be sufficiently closed to issue the workspace-write implementation prompt without another architectural round.

### Sources

- Codex response attached in this turn. :chatgpt-content-reference{index="4"}
- Current merged Coordinator snapshot: `Governed Execution Coordinator - Snapshot - 2026-09-27.zip`.
- `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py:1977-2152`
- `src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py:768-884`

**Confidence:** High that the snapshot/recovery design is now correct; high that the same-second admission dependency is a real contract defect; high that the narrow temporal decoupling above resolves it without changing C1’s architecture, schema topology, or authority boundary.
