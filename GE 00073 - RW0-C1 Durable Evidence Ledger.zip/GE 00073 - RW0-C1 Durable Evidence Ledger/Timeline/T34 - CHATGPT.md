# Decision

**RW0-C1 is now ready for implementation.**

The final temporal correction closes the last material contract defect:

- `operation_timestamp` is the real durable-admission time.
- `relation.evaluated_at` is the owner-semantic evaluation time.
- Ranks 1–4 evaluate at admission time.
- Rank 6 evaluates at the host qualification’s embedded timestamp.
- Rank 9 evaluates at its embedded timestamp, which must equal the admitted rank-6 qualification timestamp.
- Rank-6/rank-9 semantic time may precede admission but may not follow it.

That removes the artificial same-whole-second race while preserving the exact owner relations. Replay and recovery use the persisted semantic time rather than the current clock. :chatgpt-content-reference{index="0"}

The surrounding C1 contract is also closed:

- committed phase recovery no longer depends on mutable current heads or `global_stop_current` retaining historical values; :chatgpt-content-reference{index="1"}
- the final topology remains 23 new tables, 46 new immutability triggers, four new explicit indexes, and cumulative totals of 62/110/5;
- the exact 81-path implementation ceiling remains sufficient. :chatgpt-content-reference{index="2"}

Codex’s final read-only disposition is therefore credible:

```text
RW0_C1_IMPLEMENTATION_CONTRACT_READY
```

:chatgpt-content-reference{index="3"}

This is the point to stop designing and begin the complete workspace-write tranche.

## Implementation handoff

Use the **same Codex conversation** that produced the read-only contract. Change its permission posture to workspace-write, then send this prompt:

:chatgpt-content-reference{index="9"}[Download the RW0-C1 implementation prompt](sandbox:/mnt/data/Coordinator_RW0_C1_Durable_Evidence_Implementation_Prompt.txt)

```text
Filename:
Coordinator_RW0_C1_Durable_Evidence_Implementation_Prompt.txt

Size:
35,725 bytes

SHA-256:
258d150ae7c1e86a91b5c84c953accc358d18440182278d0c3a7d77f5be88615
```

Attach the exact provenance recipe alongside it:

:chatgpt-content-reference{index="10"}[Download the exact provenance recipe](sandbox:/mnt/data/governed_execution_audit_patch_manifest_v1.py)

```text
Filename:
governed_execution_audit_patch_manifest_v1.py

Size:
3,945 bytes

SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

The two-turn protocol supports this transition: after read-only reconciliation, the same parent becomes the sole workspace writer, verifies the exact baseline, stays within the frozen touched-file scope, validates, cleans its artifacts, and produces provenance without claiming an independent audit. :chatgpt-content-reference{index="4"}

## What the prompt authorizes

The implementation is one complete C1 tranche on:

```text
codex/rw0-c1-durable-evidence-v1
```

It authorizes exactly the frozen 81 paths:

```text
27 documentation/root paths
11 production/migration paths
43 test paths
```

It requires the full capability:

- migration `0004_rw0_c1_durable_evidence`;
- immutable phase establishment;
- kind-scoped evidence registry;
- stable phase-membership identity;
- fifteen typed evidence kinds;
- exact same-phase relation operands;
- admission-time private operand bindings;
- immutable snapshots of mutable current rows;
- separate admission and semantic evaluation timestamps;
- exact replay/conflict behavior;
- guarded private readers;
- one-controller atomic persistence;
- explicit three-way commit recovery;
- synchronized current-status and inventory contracts.

It explicitly excludes:

- RW0-C2;
- decision or terminal closures;
- acceptance-latch mutation;
- evidence completeness;
- public API or `StateStore` widening;
- public `WriterSession` protocol widening;
- D/E mechanisms;
- Execution Substrate work;
- supporting-repository changes;
- staging, commit, push, or PR creation.

The implementation is not allowed to stop at a schema-only intermediate state. Internal stages are permitted, but acceptance applies only to the complete durable capability.

## Required implementation result

The only success token is:

```text
COORDINATOR_RW0_C1_IMPLEMENTED_READY_FOR_INDEPENDENT_AUDIT
```

After that response, the next authority step will be a fresh independent audit bound to the exact final manifest. Schema, transaction ownership, commit uncertainty, replay, and durable-state semantics require the complete implementation → independent audit → staged-blob → committed-blob provenance chain. :chatgpt-content-reference{index="5"}

### Sources

- Attached final Codex temporal reconciliation. :chatgpt-content-reference{index="6"}
- Current merged Coordinator snapshot.
- Governed Execution Codex Subagent Operating Protocol. :chatgpt-content-reference{index="7"}
- Governed Execution Provenance Guidance. :chatgpt-content-reference{index="8"}

**Confidence:** High in the architectural and semantic freeze; high that the temporal correction resolves the final known blocker; medium-high in implementation risk because this is a broad, transaction-sensitive, 81-path durable-state tranche whose correctness must still be established by implementation evidence and independent audit.

Some older Project uploads have expired. They were not needed for this decision; re-upload them only if a later audit specifically depends on their contents.
