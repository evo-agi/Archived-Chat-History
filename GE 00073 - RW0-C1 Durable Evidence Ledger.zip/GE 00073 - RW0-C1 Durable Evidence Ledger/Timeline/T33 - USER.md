Here is Codex's response:

# Baseline and inspection boundary

The required baseline is satisfied:

- Branch: `trunk_dev`
- HEAD: `047563de5a443b0f8323401c92979ae2e444d2ed`
- Tree: `4ff9ee4a710af13447e3ed8699339a51255ff720`
- Sole parent: `dd12b23762dc761736e55a1abfde12dd3ec23551`
- Subject: `feat: add RW0-B2 cancellation-control evidence (#6)`
- Upstream: `origin/trunk_dev`
- Ahead/behind: `0/0`
- Worktree, index, untracked, and unmerged state: clean

Inspection remained parent-only and read-only. No fetch, database open, migration, test execution, remote contact, or supporting-repository inspection occurred.

# Preserved C1 contract

This correction does not reopen or alter the accepted RW0-C1 contract:

- C1/C2 decomposition remains unchanged.
- The 15 evidence kinds and dependency DAG remain unchanged.
- Admission remains single-member.
- Membership identity remains stable.
- Same-phase relation operand integrity remains required.
- Rank-13/rank-14 algebra remains unchanged.
- A member retains at most two member relations.
- One transaction controller owns the admission transaction.
- Evidence identity remains kind-scoped.
- Capsule binding remains limited to the accepted safe projection.
- Phase relations remain in the common relation tables.
- Transient-private bindings and admission snapshots for mutable current rows remain required.
- `evaluated_at` remains part of relation bindings.
- Migration `0004` remains the additive generation-2 migration.
- The accepted schema counts and exact 81-path allowlist remain unchanged.
- No C2 state, public API, production caller, external contact, or supporting-repository change is introduced.
- C1 evidence remains non-authoritative and does not itself grant execution permission.

The only withdrawn rule is the previous universal equality between owner semantic evaluation time and durable admission time.

# Durable admission time

`operation_timestamp` is the Coordinator-controlled durable-operation clock.

It is:

- A canonical whole-second UTC timestamp.
- Captured after prerequisite reads and immediately before relation evaluation.
- The actual time of the C1 admission operation.
- Persisted as `membership.admitted_at`.
- Used for result or receipt `committed_at` and the other transaction timestamps governed by the accepted C1 contract.
- Never replaced by a historical subject timestamp.

No membership or admission is backdated. Even when a rank-6 or rank-9 relation describes a historical semantic evaluation, its membership records the actual later admission time.

# Owner semantic evaluation time

`relation_evaluated_at` is a separate semantic clock.

It is:

- The exact timestamp supplied to the owner validator as `now_utc`.
- Persisted as `relation.evaluated_at`.
- Canonical whole-second UTC.
- Bound into the relation semantic digest and relation row digest.
- Transitively bound into relation-set and admission-family verification.
- Reused unchanged for replay, readback, and recovery.
- Never substituted with current wall time after admission.

For subject-time relations, `relation_evaluated_at` may equal `operation_timestamp`, but equality is not required. It may precede the admission operation; it may never follow it.

# Closed temporal-source registry

The source is selected only by exact relation ID. Substring, prefix, rank-only, or inferred classification is not permitted.

| Relation | Temporal source | Required relationship |
|---|---|---|
| `governed-execution.nwp-rw0-c1-authority-verification-observation-relation.v1` | `operation_timestamp` | `relation_evaluated_at = operation_timestamp` |
| `governed-execution.nwp-rw0-c1-subordinate-narrowing-relation.v1` | `operation_timestamp` | `relation_evaluated_at = operation_timestamp` |
| `governed-execution.nwp-rw0-c1-custody-binding-relation.v1` | `operation_timestamp` | `relation_evaluated_at = operation_timestamp` |
| `governed-execution.nwp-rw0-c1-retrieval-event-sequence-relation.v1` | `operation_timestamp` | `relation_evaluated_at = operation_timestamp` |
| `governed-execution.nwp-rw0-c1-host-qualification-relation.v1` | `RW0EffectHostQualificationV1.evaluated_at` | `relation_evaluated_at <= operation_timestamp` |
| `governed-execution.nwp-rw0-c1-worker-mechanism-capability-qualification-relation.v1` | `RW0WorkerMechanismCapabilityQualificationV1.evaluated_at`, exactly equal to the prerequisite host qualification timestamp | `relation_evaluated_at <= operation_timestamp` |

For the first four relations:

```text
owner now_utc
= relation_evaluated_at
= operation_timestamp
= membership.admitted_at
```

For rank 6:

```text
relation_evaluated_at
= RW0EffectHostQualificationV1.evaluated_at

owner now_utc
= relation_evaluated_at

relation_evaluated_at
<= membership.admitted_at
```

For rank 9:

```text
relation_evaluated_at
= RW0WorkerMechanismCapabilityQualificationV1.evaluated_at
= prerequisite rank-6 RW0EffectHostQualificationV1.evaluated_at

owner now_utc
= relation_evaluated_at

relation_evaluated_at
<= membership.admitted_at
```

Both operands must first be validated as exact canonical whole-second UTC values. A subject-time value later than `operation_timestamp` is a pre-write `relation_failure`.

All relation IDs outside this six-member registry retain `NULL` `evaluated_at`.

# Rank-6 and rank-9 dependency semantics

Rank 6 proves only that the host qualification owner relation held at the timestamp embedded in the exact `RW0EffectHostQualificationV1` value.

Rank 9 requires:

- The exact already-admitted rank-6 membership.
- The exact admitted rank-6 typed host-qualification value.
- The rank-9 capability-qualification timestamp.
- Exact equality between the capability-qualification timestamp and the prerequisite host-qualification timestamp.
- Owner evaluation using that shared timestamp as `now_utc`.
- That shared timestamp not being later than the rank-9 admission operation.

Rank 9 can therefore be admitted in a later transaction and a later whole second than rank 6. There is no grouped admission, shared transaction, or same-second admission requirement.

These admissions do not establish:

- That the qualification remains current at admission time.
- That it remains current after admission.
- That it is current for a later C2 decision.
- That C1 admission authorizes execution.

Any later C2 decision must obtain and evaluate its own closure-time currentness evidence under C2 policy.

# SQL, digest, replay, and recovery consequences

The existing `evaluated_at` column remains sufficient:

- It is non-null for exactly the six registered time-sensitive relation IDs.
- It is null for every other relation ID.
- SQL does not assert equality between `relation.evaluated_at` and `membership.admitted_at`.
- Cross-row and typed-value temporal coherence remains an application-level full-family reconstruction and verification responsibility.

Required family checks are:

```text
ranks 1, 2, 3, 4:
  relation.evaluated_at == membership.admitted_at

rank 6:
  relation.evaluated_at == host_qualification.evaluated_at
  relation.evaluated_at <= membership.admitted_at

rank 9:
  relation.evaluated_at == capability_qualification.evaluated_at
  relation.evaluated_at == prerequisite_host_qualification.evaluated_at
  relation.evaluated_at <= membership.admitted_at
```

The two clocks remain independently digest-bound:

- `membership.admitted_at` remains in the membership digest closure.
- `relation.evaluated_at` remains in the relation semantic and row digest closures.
- Relation-set and admission-family verification transitively bind the persisted relation timestamp.

Replay and recovery rules are closed:

- Exact receipt replay captures no new clock value.
- Recomputable owner relations rerun using persisted `relation.evaluated_at`.
- Recovery never uses current wall time as a substitute.
- Committed-exact verification for ranks 6 and 9 accepts an admission timestamp later than the semantic timestamp.
- Equality remains valid but is not required for ranks 6 and 9.
- Missing, noncanonical, future-dated, or mismatched timestamps produce `relation_failure` when detected before writes.
- The same defects in persisted or uncertain-commit evidence produce unresolved integrity failure rather than reinterpretation or repair with the current clock.

No temporal rule changes phase snapshots, mutable-row bindings, retry identity, commit-resolution authority, or transaction ownership.

# Counts and touched-path consequences

The correction changes no schema or allowlist count:

```text
23 new tables
46 new immutability triggers
4 new explicit indexes
62 cumulative tables
110 cumulative triggers
5 cumulative explicit indexes
81 must-change paths
```

No new table, column, trigger, index, migration, or source file is authorized.

Any later implementation of this correction remains confined to the existing 81-path ledger. It affects the already-authorized temporal-source selection, semantic evaluation, family reconstruction, readback, replay, recovery, and permanent-test expectations. It does not authorize changes to owner repositories or expansion into C2, public APIs, production integration, workers, models, services, or external systems.

# Findings and contradictions

The prior universal equation:

```text
membership.admitted_at
= relation.evaluated_at
= owner now_utc
```

was stricter than the owner contracts for ranks 6 and 9. It created an unnecessary same-whole-second dependency between separately admitted rank-6 and rank-9 members.

The owner-compatible closure is instead:

```text
ranks 1–4:
  relation_evaluated_at = membership.admitted_at

ranks 6 and 9:
  relation_evaluated_at <= membership.admitted_at
```

with rank 9 additionally requiring exact equality between its capability-qualification semantic timestamp and the exact admitted rank-6 host-qualification timestamp.

There is no accepted-architecture contradiction. The durable column, digest closure, one-controller transaction model, single-member admission, and existing migration remain sufficient. This correction supersedes only the earlier equality rule; it does not remove or weaken durable temporal evidence.

# Recommendation

Freeze the two-clock contract exactly as stated:

- `operation_timestamp` is the actual Coordinator admission time.
- `relation_evaluated_at` is the exact owner semantic evaluation time.
- Ranks 1–4 use operation time.
- Rank 6 uses the host qualification’s embedded evaluation time.
- Rank 9 uses the capability qualification’s embedded time, exactly equal to its admitted rank-6 prerequisite’s embedded time.
- Subject-time evaluation may precede admission but never follow it.
- Historical admission carries no implicit currentness claim.
- Replay and recovery use persisted time, never a new clock reading.

This removes the rank-9 same-second race while preserving exact owner semantics and every accepted C1 authority boundary.

# Next implementation boundary

A separately authorized implementation remains bounded to the existing C1 files and transaction authority:

1. Read and verify all prerequisites.
2. Capture one `operation_timestamp`.
3. Select `relation_evaluated_at` through the exact closed relation-ID registry.
4. Validate canonical form, source equality, prerequisite equality, and the no-future rule.
5. Invoke the owner with `relation_evaluated_at` as `now_utc`.
6. Persist actual admission time and semantic evaluation time in their separate existing fields.
7. Verify both timestamps through exact readback, replay, and recovery without consulting current wall time.

That boundary introduces no new authority, path, schema object, currentness guarantee, or implementation scope.

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
RW0_C1_IMPLEMENTATION_CONTRACT_READY
