PROMPT_ID

RW0_C1_PRIVACY_IDENTITY_AND_SCOPE_RECONCILIATION_V1

TITLE

Coordinator RW0-C1 — reconcile capsule privacy, evidence identity scope,
kind-14 semantics, and the exact implementation path ledger

ENGAGEMENT TYPE

Narrow parent-only, read-only contract reconciliation.

Do not implement, edit, format, stage, commit, push, create a PR, migrate a
database, run tests, collect nodes, contact a remote or live system, invoke a
product worker/model, install dependencies, or inspect another repository.

Print the complete substantive answer inline. Evidence files may be
supplementary only.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
047563de5a443b0f8323401c92979ae2e444d2ed

tree:
4ff9ee4a710af13447e3ed8699339a51255ff720

sole parent:
dd12b23762dc761736e55a1abfde12dd3ec23551

subject:
feat: add RW0-B2 cancellation-control evidence (#6)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktree/index/untracked/unmerged:
clean

No fetch is authorized.

ACCEPTED ARCHITECTURE THAT IS NOT REOPENED

Preserve:

1. RW0-C is decomposed into non-disposable C1 and C2.
2. C1 owns private no-contact phase establishment, exactly 15 typed supplied-
   evidence member kinds, relation/profile binding, replay/conflict, guarded
   readback, and three-way commit recovery.
3. C1 owns no completeness, decision, terminal outcome, latch mutation,
   executable authority, public API, production caller, or external contact.
4. C2 later owns distinct decision-basis and terminal-basis closures, unchanged
   C2B decision persistence, the one-way acceptance latch, terminal outcome,
   cancellation reconciliation, and terminal recovery.
5. Migration 0004 is additive, application generation 2, non-destructive,
   zero-seed, and contains no C2 tables or mutable completeness head.
6. Existing B1, Wire, Capability, C2A, C2B, Section 41, migrations 0001–0003,
   package, public, and authority contracts remain unchanged.
7. The 15-kind rank order and the admission dependency DAG from the preceding
   report remain the working target unless this reconciliation proves a
   concrete contradiction.
8. No self-protecting permanent-test or audit-harness architecture is allowed.

WHY THE PRECEDING “READY” RESULT IS NOT YET IMPLEMENTATION-READY

The merged baseline and the supplied freeze contain three concrete conflicts.

A. CURRENT DURABLE PRIVACY CONTRACT VERSUS KIND 14

Current repository contract:

`.docs/durable-state-model.md:465-472`

states that WorkSpec and candidate-capsule manifests receive only privacy-safe
projections, and that capsule entries, paths, modes, file digests, lengths,
candidate/capsule bytes, and workspace material remain outside SQLite.

The preceding freeze instead placed into
`rw0_wire_process_result_classification_bindings`:

- all three capsule entry paths;
- operations;
- modes;
- before/after blob SHA-256 values;
- before/after byte lengths;
- enough fields to reconstruct the complete CandidateCapsuleManifestV1.

That is current-contract drift and must not be hidden as an implementation
detail.

B. EVIDENCE REGISTRY IDENTITY SCOPE

The preceding freeze says semantic evidence keys are kind-scoped, but then
defines:

- primary key `value_ref`;
- globally unique `value_digest`.

No B1, Wire, Capability, C2A, or Section 41 owner contract establishes global
cross-kind uniqueness of arbitrary safe refs. Safe-ref grammar is not a global
namespace contract.

The registry and all dependent FKs/readers/collision rules must use an exact
owner-supported composite identity.

C. THE CLAIMED EXACT 76-PATH LEDGER IS INCOMPLETE

At minimum, these current tests directly pin documents that the proposed
implementation changes, yet they were absent from the 76-path must-change set:

- `tests/test_b4c_public_global_stop_delegation.py:1456-1464`
  pins the B4c document’s terminal-0003/current-terminal claims.

- `tests/test_c2b3c_author_effect_contract.py:202-220`
  pins the durable-state summary sentence:
  “Current state remains generation 2 and terminates at migration 0003…”

If the owning documents change to current migration 0004, these tests must be
updated or the document change must be rejected. Therefore the prior
path-by-path ceiling is not exact.

PRIMARY OBJECTIVE

Return one corrected implementation-ready contract by closing only these
issues:

1. capsule privacy and C2 classification recomputation;
2. kind-scoped evidence identity and SQL keys;
3. exact kind-14 semantics;
4. exact SQL consequences;
5. exhaustive must-change/protected path ledger.

Do not reopen the C1/C2 decomposition merely because these corrections alter
columns or the touched-file count.

REQUIRED INSPECTION

Inspect completely or in every relevant owning section:

- `.docs/durable-state-model.md`
- `.docs/c2a-first-slice-semantic-protocol-contract.md`
- `.docs/rw0-b2-wire-protocol.md`
- `.docs/rw0-remote-worker-contact-phase-entry.md`
- `.docs/c2b-durable-development-state.md`
- `.docs/c2b2-private-readers.md`
- `.docs/sqlite-bootstrap-and-migrations.md`
- `.docs/sqlite-operations-and-recovery.md`

- `src/ge_nwp_coordinator/_worker_execution_semantic_values.py`
- `src/ge_nwp_coordinator/_rw0_wire_protocol_values.py`
- `src/ge_nwp_coordinator/_development_decision_row_values.py`
- `src/ge_nwp_coordinator/sqlite_migration.py`
- migrations 0002 and 0003
- the reader/transaction/writer modules already inspected

- `tests/test_b4c_public_global_stop_delegation.py`
- `tests/test_c2b3c_author_effect_contract.py`
- every file containing a live current-tip, table/trigger/index count,
  migration-resource list, source/importer inventory, RW0-C current/future
  status, or document phrase that the C1 patch would change.

A. CAPSULE PRIVACY DECISION

Freeze the following unless repository evidence proves it impossible:

1. C1 does not persist capsule entries, entry paths, modes, before/after file
   digests, byte lengths, raw capsule bytes, or a complete
   CandidateCapsuleManifestV1.

2. C1 durable state may retain only the currently permitted safe capsule
   binding:
   - candidate ref where owned;
   - capsule-manifest ref;
   - portable-capsule digest;
   - any already-owner-approved safe scope/profile identity;
   - relation/profile version and exact ref/digest operands.

3. Rank 10/11/12 relation bindings may attest at admission that a transient
   full manifest was supplied and validated. The complete manifest is bound by
   command digest and relation-operand semantic digest but is not copied into
   SQLite.

4. C2 later receives the full manifest as a transient private command operand,
   verifies it against C1’s durable safe binding and exact immutable members,
   invokes
   `classify_wire_exact_current_cancellation_control(...)`,
   and persists the classification only inside the C2 closure.

5. C2 replay/recovery does not pretend to recompute the classifier without the
   private manifest. It verifies the committed C2 relation/classification
   attestation, command digest, profile pair, safe manifest binding, closure,
   and result digest.

If this design is incompatible with accepted C2 or recovery contracts, state
the exact contradiction and return architectural replan. Do not solve it by
persisting capsule entries or changing B2.

B. KIND-14 CORRECTION

Restore rank 14 to one closed C1 responsibility:

`wire_process_result_classification_binding`

It may bind:

- NWPF v1 profile pair;
- exact admitted worker-result member or finite result failure;
- admitted adapter observations;
- admitted request;
- admitted process observations;
- cancellation fence/delivery owner rows as required by the existing NWPF
  classifier;
- exact existing NWPF classification and reason;
- safe capsule ref/digest bindings already present in admitted facts or
  relation operands.

It must not:

- persist cancellation-control classification;
- embed the complete target capsule manifest;
- become an implicit decision- or terminal-basis closure;
- merge NWPF process/result classification with the separate
  cancellation-control classification.

Specify the exact revised ordered fields for rank 14 and the exact C2 operands
that are recovered from ranks 10–12 plus owner rows and transient C2 input.

C. EVIDENCE REGISTRY KEY

Freeze one exact composite identity supported by the owner contracts.

Preferred starting point:

```text
PRIMARY KEY (kind_rank, value_ref)
UNIQUE (kind_rank, value_digest)
UNIQUE (kind_rank, value_ref, value_digest, value_schema_id)
```

or an exact schema-scoped equivalent.

Require:

- cross-kind reuse of the same textual safe ref is legal unless an owning
  contract forbids it;
- cross-kind equality of digest text is not treated as an owner-semantic
  collision;
- same-kind ref/digest aliases remain fail-closed;
- typed payload FKs, membership FKs, readers, replay, and recovery use the
  composite key consistently;
- global reusable values remain reusable across phases;
- phase-bound and K8-bound values retain exact phase constraints.

Return the exact revised columns, PKs, UNIQUE constraints, FKs, collision
queries, reader predicates, and result/error classification.

D. SQL CONSEQUENCES

Recompute the exact migration contract after the two corrections.

State explicitly:

- whether table count remains 23;
- whether trigger count remains 46;
- whether explicit-index count remains 4;
- revised `rw0_evidence_values`;
- revised `rw0_evidence_memberships`;
- revised relation operands, if needed;
- revised rank-14 typed table;
- whether any capsule child table is prohibited;
- cumulative totals from the actual 39/64/1 baseline;
- every changed CHECK, FK, UNIQUE, reader, replay, and recovery rule.

The result must not leave owner matrices, nullability branches, or identity
scope to implementation judgment.

E. C2 RECOMPUTATION AND RECOVERY SEAM

Distinguish three moments:

1. C1 admission-time relation validation with transient private operands.
2. C2 operation-time cancellation-control recomputation with a transient full
   manifest.
3. C2 durable replay/recovery of the already committed closure without storing
   or re-reading capsule entries.

Freeze:

- exact safe C1 manifest binding;
- exact transient C2 command operand;
- exact C2 classification/attestation fields needed later;
- why terminal closure can bind the decision result without full manifest
  persistence;
- why no D/E physical-custody fact or external I/O is introduced.

This is a forward compatibility decision only; do not design all C2 tables.

F. EXHAUSTIVE PATH LEDGER

Re-run the repository-wide path analysis.

For every file containing any of these, classify it:

- live terminal migration 0003;
- live generation-2 schema totals;
- current migration-resource list;
- current table/trigger/index inventory;
- current coherent-fixture tip;
- current production-source list;
- private importer/consumer list;
- RW0-C future/current status;
- exact document sentence that must change;
- SHA or source-inventory pin affected by a changed production file.

Return:

```text
must_change
protected
```

Do not use a conditional set unless the activating predicate is mechanical and
tested.

For every must-change path provide:

- exact current line/assertion/inventory;
- exact intended change;
- owner;
- direct failure if omitted.

At minimum reconcile:

- `tests/test_b4c_public_global_stop_delegation.py`
- `tests/test_c2b3c_author_effect_contract.py`

Also explain every grep hit excluded as historical, tranche-specific, or
otherwise intentionally unchanged.

Return a corrected exact path count. A loose maximum is not acceptable.

G. IMPLEMENTATION READINESS

Return `RW0_C1_FINAL_IMPLEMENTATION_CONTRACT_READY` only if all are true:

- privacy conflict resolved without B2 churn;
- kind 14 no longer stores full capsule entries;
- C2 operation-time/transient recomputation seam is exact;
- composite evidence identity is exact;
- migration tables/constraints/counts are recomputed;
- touched-file ledger is exhaustive and causal;
- no owner, public, or authority seam remains unresolved.

Return `RW0_C1_FREEZE_RECONCILIATION_REQUIRED` if any exact SQL, identity,
privacy, recovery, or path-scope detail remains open.

Return `RW0_C_ARCHITECTURAL_REPLAN_REQUIRED` only for a genuine accepted-
architecture contradiction.

OUTPUT

Print inline:

# Baseline and inspection boundary
# Preserved C1 architecture
# Capsule privacy reconciliation
# Revised kind-14 contract
# Composite evidence identity
# Revised migration 0004 schema
# C2 operation-time recomputation seam
# Replay and recovery consequences
# Exact reader changes
# Exhaustive causal touched-file ledger
# Findings and contradictions
# Forecasts and stop conditions
# Recommendation
# Next implementation boundary

End with exactly one:

RW0_C1_FINAL_IMPLEMENTATION_CONTRACT_READY

RW0_C1_FREEZE_RECONCILIATION_REQUIRED

or

RW0_C_ARCHITECTURAL_REPLAN_REQUIRED

Do not issue an implementation prompt.

Required final statements:

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
