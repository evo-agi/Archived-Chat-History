PROMPT_ID

RW0_B2_CANCELLATION_CONTROL_PR6_SQUASH_MERGE_GATE_V1

TITLE

Coordinator RW0-B2 cancellation-control — squash-merge PR #6, verify the exact
merge commit and remote transition, synchronize local trunk_dev, and run one
bounded post-merge validation

ENGAGEMENT TYPE

Authorized one-attempt squash-merge and local synchronization gate in the
existing cancellation-control implementation conversation.

No implementation repair is authorized.

Do not:
- push directly to trunk_dev;
- force-push;
- amend;
- rebase;
- create a second commit;
- create a second push;
- create a second PR;
- make a second merge attempt;
- enable auto-merge;
- submit or self-approve a review;
- resolve threads;
- delete the feature branch;
- tag, release, or deploy;
- contact a provider or live host;
- invoke a product worker/model;
- mutate a database;
- install dependencies;
- run migrations;
- modify a supporting repository.

The parent performs the gate. Do not create subagents.

Print the complete operative result inline. Evidence paths may be supplementary
only after all material identities, policy observations, the exact merge
command, merge result, local synchronization, post-merge validation, final
guards, limitations, and confidence have appeared inline.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Squash-merge the exact accepted PR #6 candidate into trunk_dev, verify the
result mechanically, synchronize local trunk_dev by fast-forward only, and run
one bounded post-merge validation over the affected semantic and boundary
surfaces.

ACCEPTED PR AND FEATURE IDENTITY

```text
PR:
6

title:
feat: add RW0-B2 cancellation-control evidence

base:
trunk_dev

accepted base OID:
dd12b23762dc761736e55a1abfde12dd3ec23551

head:
codex/rw0-b2-cancellation-control-v1

feature commit:
b0e7806bbf23776ffedf0ee331c284c68d6f0c8d

feature tree:
4ff9ee4a710af13447e3ed8699339a51255ff720

feature sole parent:
dd12b23762dc761736e55a1abfde12dd3ec23551

feature subject:
feat: add RW0-B2 cancellation-control evidence

feature body:
empty

feature signature:
unsigned

feature shape:
8 modifications
3 additions
0 deletions
0 renames
0 copies
0 mode changes
11 files
all mode 100644
```

ACCEPTED SEMANTIC IDENTITIES

```text
NWPF v1:
rw0-wire-nwpf-v1
470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454

cancellation-control:
rw0-wire-cancellation-control-v1
4d6f84552b852a4c4073b4238591afd271072f648424eca9e744def436165288
```

ACCEPTED VALIDATION

```text
collection:
5087 unique nodes

ordered SHA-256:
fe756529f88a3c44c31a402d2266b00b14993f420b76fa2af15595103599580c

complete suite:
5087 collected
5087 passed
0 failures
0 errors
0 skipped
0 xfailed
0 xpassed
0 warnings
empty stderr

accepted tree:
4ff9ee4a710af13447e3ed8699339a51255ff720
```

COMMIT-GATE EVIDENCE

```text
root:
/private/tmp/rw0-b2-cancellation-control-commit-gate.j5wIw7

self-excluding index:
152 entries

index size:
16201 bytes

index SHA-256:
c4d2995ecd8b2b771d267862b6458008ee98ab0c161874687148d04144555526
```

Read-only verify this evidence root and preserve it unchanged.

LIVE EXPECTED PR STATE

Re-read every live fact immediately before merge. Do not rely only on this
prompt.

Expected PR state:

```text
open
non-draft
unmerged
mergeable true
base OID dd12b23762dc761736e55a1abfde12dd3ec23551
head OID b0e7806bbf23776ffedf0ee331c284c68d6f0c8d
one commit
11 changed files
exact title
exact body
no auto-merge
```

Expected interaction state:

```text
requested reviewers:
0

reviews:
0

requested changes:
0

review threads:
0

issue comments:
0

review comments:
0

workflow runs:
0

check runs:
0

commit status contexts:
0
```

A combined status of `pending` with total count `0` is synthetic and is not a
blocker only while the active rules require no status checks.

EXPECTED ACTIVE POLICY

Applicable ruleset:

```text
ID:
18957283

name:
trunk_dev

enforcement:
active

target:
refs/heads/trunk_dev

allowed merge methods:
squash only

required approving reviews:
0

required status checks:
none

required review-thread resolution:
true

extra approval for unattributed changes:
true

bypass actors:
none

current user can bypass:
never
```

Repository settings:

```text
allow squash merge:
true

auto-merge:
disabled

delete branch on merge:
disabled
```

The repository may expose merge-commit and rebase settings globally, but the
active trunk_dev ruleset permits squash only. Follow the effective ruleset.

OPENING LOCAL IDENTITY

Require exactly:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-cancellation-control-v1

HEAD:
b0e7806bbf23776ffedf0ee331c284c68d6f0c8d

tree:
4ff9ee4a710af13447e3ed8699339a51255ff720

sole parent:
dd12b23762dc761736e55a1abfde12dd3ec23551

upstream:
origin/codex/rw0-b2-cancellation-control-v1

ahead/behind:
0/0

worktrees:
1

worktree/index:
clean

Git operation/lock:
none

repository residue:
none
```

Do not fetch tags.

NEW MERGE-GATE EVIDENCE ROOT

Create one short neutral root:

```text
/private/tmp/rw0-b2-cancellation-control-merge-gate.XXXXXX
```

Requirements:

- operator-owned;
- non-symlink;
- mode 0700;
- all temporary paths beneath this root;
- every Python process uses:
  - python3 -B;
  - PYTHONDONTWRITEBYTECODE=1;
  - a distinct audit-root PYTHONPYCACHEPREFIX;
- every pytest-visible path is privacy/path screened;
- retained files mode 0400;
- retained directories mode 0700;
- no retained symlink or special entry;
- one self-excluding index created last.

Keep evidence proportionate. Record:
- opening local identity;
- live PR and policy preflight;
- accepted commit/tree/blob verification;
- exact merge command and result;
- squash commit and event/ref verification;
- remote transition;
- local synchronization;
- focused validation;
- final guards;
- cleanup;
- final report.

LIVE PREFLIGHT

Before merge:

1. verify authenticated GitHub identity;

2. verify origin URL;

3. fetch exactly and only:
   - refs/heads/trunk_dev;
   - refs/heads/codex/rw0-b2-cancellation-control-v1;
   without tags;

4. require remote refs:

   ```text
   trunk_dev:
   dd12b23762dc761736e55a1abfde12dd3ec23551

   feature:
   b0e7806bbf23776ffedf0ee331c284c68d6f0c8d
   ```

5. verify local opening identity remains exact;

6. fetch and retain complete live PR metadata;

7. require exact PR base/head/title/body, one commit, and 11 files;

8. inspect:
   - reviews;
   - requested reviewers;
   - issue comments;
   - review comments;
   - review threads;
   - check runs;
   - workflow runs;
   - commit statuses;

9. inspect the active ruleset and repository merge settings;

10. stop before merge if:
    - base or head changed;
    - PR is draft, closed, merged, or unmergeable;
    - merge state is not clean;
    - a review requests changes;
    - a material unresolved comment or thread exists;
    - a required check or approval is missing;
    - the ruleset no longer permits squash;
    - another commit or file exists;
    - remote/local identity differs.

No bypass may be used.

ACCEPTED EVIDENCE RECHECK

Read-only verify:

```text
commit-gate evidence index:
c4d2995ecd8b2b771d267862b6458008ee98ab0c161874687148d04144555526

feature commit:
b0e7806bbf23776ffedf0ee331c284c68d6f0c8d

feature tree:
4ff9ee4a710af13447e3ed8699339a51255ff720

feature parent:
dd12b23762dc761736e55a1abfde12dd3ec23551

11 paths and committed blobs/modes:
exact
```

Do not rerun the complete 5,087-test suite before merge. The commit gate already
executed staged collection and the full suite exactly once.

MERGE COMMAND

Execute exactly once:

```text
gh pr merge 6 \
  --repo evo-agi/Governed-Execution-Coordinator \
  --squash \
  --match-head-commit b0e7806bbf23776ffedf0ee331c284c68d6f0c8d \
  --subject "feat: add RW0-B2 cancellation-control evidence (#6)" \
  --body ""
```

No second merge attempt is authorized.

If the command fails:
- do not retry;
- preserve exact stdout, stderr, return code, and time;
- inspect live PR/ref state read-only;
- stop.

VERIFIED SQUASH COMMIT

After a successful command, obtain the squash OID from live PR, event, and ref
state.

Require:

```text
tree:
4ff9ee4a710af13447e3ed8699339a51255ff720

sole parent:
dd12b23762dc761736e55a1abfde12dd3ec23551

subject:
feat: add RW0-B2 cancellation-control evidence (#6)

body:
empty

GitHub signature:
verified

verification reason:
valid
```

Require:

- exactly one PR merge event;
- the event references the squash commit;
- the feature commit is not a merge parent;
- all 11 squash-commit blobs and modes equal the accepted feature tree;
- shape remains 8 modifications and 3 additions.

REMOTE TRANSITION

Require:

```text
remote trunk_dev:
dd12b23762dc761736e55a1abfde12dd3ec23551
→ <squash OID>

remote feature:
b0e7806bbf23776ffedf0ee331c284c68d6f0c8d
→ b0e7806bbf23776ffedf0ee331c284c68d6f0c8d
```

Require PR #6:

```text
closed
merged
merge commit == squash OID
base == trunk_dev
head == codex/rw0-b2-cancellation-control-v1
```

Do not delete the feature ref.

LOCAL SYNCHRONIZATION

Execute exactly:

1. one no-tags fetch of remote trunk_dev and the feature ref;

2. switch to the existing local trunk_dev;

3. run:

   ```text
   git merge --ff-only origin/trunk_dev
   ```

Do not reset, rebase, or locally merge the feature branch.

Require:

```text
local trunk_dev == remote trunk_dev == squash OID

local trunk_dev upstream:
origin/trunk_dev

divergence:
0/0

local and remote feature refs:
b0e7806bbf23776ffedf0ee331c284c68d6f0c8d

worktree/index:
clean

worktrees:
1
```

POST-MERGE FOCUSED VALIDATION

Run exactly one focused pytest invocation on synchronized local trunk_dev.

Files:

```text
tests/test_rw0_b2_wire_cancellation_control_values.py
tests/test_rw0_b2_wire_cancellation_control_relations.py
tests/test_rw0_b2_wire_cancellation_control_boundaries.py

tests/test_rw0_b2_wire_values.py
tests/test_rw0_b2_wire_relations.py
tests/test_rw0_b2_wire_codec.py
tests/test_rw0_b2_wire_boundaries.py

tests/test_worker_execution_semantic_values.py
tests/test_worker_execution_semantic_vectors.py
tests/test_worker_execution_semantic_relations.py
tests/test_worker_execution_semantic_boundaries.py
tests/test_c2a_relations.py
tests/test_c2a_effects_and_recovery.py

tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_vectors.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b1_boundaries.py

tests/test_rw0_b2_capability_values.py
tests/test_rw0_b2_capability_vectors.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b2_capability_boundaries.py

tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py
tests/test_runtime_non_authority.py
tests/test_c2a_nonimplementation.py
```

Environment:

```text
umask 022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct audit-root PYTHONPYCACHEPREFIX
distinct audit-root TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
GIT_OPTIONAL_LOCKS=0
python3 -B -m pytest -p no:cacheprovider -W error -q
distinct audit-root --basetemp
distinct audit-root --junitxml
serial execution
```

Do not predeclare the exact count. Report collected and passed count.

Require:

```text
return code 0
all collected tests passed
0 failures
0 errors
0 skips
0 xfails
0 xpasses
0 warnings
empty stderr
parseable JUnit
zero duplicate cases
zero unmapped cases
caller and child umask 0022
repository/ref/index/tree unchanged before/after
```

Do not run the complete 5,087-test suite again.

FINAL GUARDS

Require:

- PR #6 merged exactly once;
- squash commit parent/tree/subject/body/signature exact;
- remote and local trunk_dev synchronized;
- remote base advanced only by the squash commit;
- feature refs retained;
- worktree/index clean;
- one worktree;
- no Git operation, lock, cache, bytecode, database, journal, archive, build
  output, recorder, or generated-manifest residue;
- no auto-merge, review, thread-resolution, branch deletion, tag, release, or
  deployment effect;
- commit-gate and prior accepted evidence roots unchanged;
- focused validation ran exactly once.

CLOSEOUT

Retain:

```text
opening local identity
live PR preflight
ruleset/repository policy
reviews/comments/threads/checks/workflows/statuses
accepted commit/tree/blob verification
exact merge command and result
squash commit/event/ref verification
remote transition
local synchronization
focused validation
final guards
cleanup
complete inline report
```

Remove only merge-gate-created transient validation paths after retaining
material records.

Seal the merge-gate root:

```text
directories mode 0700
files mode 0400
no special entries
self-excluding canonical index
external read-only index verification
```

SUCCESS TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_CANCELLATION_CONTROL_SQUASH_MERGED_AND_VERIFIED
```

only if merge, squash verification, local synchronization, focused validation,
and closeout all succeed.

FAILURE TOKENS

Use one exact primary token:

```text
MERGE_GATE_OPENING_IDENTITY_MISMATCH
MERGE_GATE_LIVE_PR_CHANGED
MERGE_GATE_POLICY_BLOCKED
MERGE_GATE_EVIDENCE_MISMATCH
MERGE_GATE_MERGE_FAILED
MERGE_GATE_SQUASH_VERIFICATION_FAILED
MERGE_GATE_REMOTE_TRANSITION_FAILED
MERGE_GATE_LOCAL_SYNC_FAILED
MERGE_GATE_FOCUSED_VALIDATION_FAILED
MERGE_GATE_CLOSEOUT_FAILED
```

For failure, print the complete diagnosis inline and state exact local, remote,
and PR state. Do not retry the merge.

FINAL INLINE REPORT

Use:

```text
# Outcome
# Accepted identities
# Opening local identity
# Live PR and policy preflight
# Merge command
# Verified squash commit
# Per-path blob and mode verification
# Remote transition
# Local synchronization
# Focused validation
# Final guards
# Evidence index
# Limitations and confidence
```

Required final statements:

```text
IMPLEMENTATION_REPAIR_NOT_PERFORMED
DIRECT_TRUNK_PUSH_NOT_PERFORMED
BYPASS_NOT_USED
FORCE_PUSH_NOT_PERFORMED
SECOND_COMMIT_NOT_PERFORMED
AMEND_NOT_PERFORMED
REBASE_NOT_PERFORMED
SECOND_MERGE_ATTEMPT_NOT_PERFORMED
AUTO_MERGE_NOT_ENABLED
REVIEW_NOT_SUBMITTED
THREAD_NOT_RESOLVED
FEATURE_BRANCH_NOT_DELETED
TAG_NOT_CREATED
RELEASE_NOT_CREATED
DEPLOYMENT_NOT_PERFORMED
PERSISTENCE_NOT_IMPLEMENTED
TRANSPORT_NOT_IMPLEMENTED
PROCESS_CONTROL_NOT_IMPLEMENTED
RW0_C_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
```
