PROMPT_ID

RW0_C1_FILESYSTEM_MODE_REPAIR_AND_VALIDATION_RESET_V1

TITLE

Coordinator RW0-C1 — repair eight candidate-local filesystem modes, rebind
validation and provenance, and return the exact candidate for fresh independent
audit

ENGAGEMENT TYPE

Bounded workspace-write metadata repair in the original RW0-C1 implementation
conversation.

This is not a semantic implementation pass. Do not edit file contents, change
the 81-path inventory, alter tests, change migrations, or broaden scope.

Do not stage, commit, push, create a PR, merge, fetch, contact a remote/live
system, install dependencies, invoke a product worker/model, modify a supporting
repository, or open/migrate an operator database.

Print the complete substantive result inline. Evidence files may be
supplementary only.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED OPENING IDENTITY

Require exactly:

branch:
codex/rw0-c1-durable-evidence-v1

HEAD:
047563de5a443b0f8323401c92979ae2e444d2ed

HEAD tree:
4ff9ee4a710af13447e3ed8699339a51255ff720

sole parent:
dd12b23762dc761736e55a1abfde12dd3ec23551

subject:
feat: add RW0-B2 cancellation-control evidence (#6)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

staged/unmerged:
0/0

candidate paths:
exactly 81, matching the frozen implementation allowlist and the opening
canonical manifest

opening canonical manifest SHA-256:
5cd3d1046660b59378f4c1ae24f40a5d6d5dc5850377f14780cc510568eb5456

opening tracked textual diff SHA-256:
c9e81fe9e3e82a39a5a239277d5187f67ea4795e285773b60f9b9afd4d858f54

opening implementation evidence index SHA-256:
cd1ad5ea72ef20a774fd470e38f14882a25f99af94db970c4506c62d4a4cc2b4

opening final nodes:
5157

opening final ordered-node SHA-256:
efd65837c5c0e05bcd720dc52be6bfd32aa1f861392496864900fb083e0971df

No fetch is authorized.

BACKGROUND AND CLASSIFICATION

The first independent audit stopped before correctness because eight candidate
paths are physical mode 0600 while the remaining 73 candidate paths are 0644.

The audit report incorrectly attributed an explicit “all 81 paths must be
0644” sentence to the audit brief. The operative audit prompt did not contain
that sentence. Preserve this as an audit-report citation defect.

However, do not accept 0600 merely because the opening implementation manifest
recorded it. These eight paths are tracked, non-executable repository text
files. Their Git mode is 100644, and a clean external materialization under
umask 0022 must yield physical mode 0644. A future staged/committed candidate
therefore cannot remain byte-for-byte provenance-equivalent to a manifest that
freezes physical mode 0600.

The correct engineering treatment is a bounded candidate filesystem-mode
repair followed by a validation/provenance reset.

EXACT EIGHT-PATH REPAIR SET

Only these paths may have their physical permission bits changed:

.docs/architecture.md
.docs/software-development-progression-boundary.md
.docs/sqlite-bootstrap-and-migrations.md
.docs/sqlite-operations-and-recovery.md
.docs/sqlite-threat-model.md
AGENTS.md
README.md
tests/test_c2b0_durable_state_contract.py

Required opening condition:

- each is a regular file;
- each is physical mode 0600;
- each matches the opening manifest’s exact size and SHA-256;
- each is tracked in HEAD with Git mode 100644;
- the remaining 73 candidate paths are regular physical mode 0644;
- no path outside the 81-path candidate differs from HEAD;
- no staged, unmerged, lock, operation, cache, bytecode, database, journal,
  archive, build, recorder, or generated-manifest residue exists.

If the opening condition differs, stop without mutation:

RW0_C1_MODE_REPAIR_BASELINE_MISMATCH

READ-ONLY INTENT VERIFICATION

Before chmod:

1. Reverify the implementation evidence index and opening manifest.
2. Materialize a fully external clean checkout or archive of the exact HEAD
   under umask 0022, without alternates or shared source-object inodes.
3. Verify the eight corresponding tracked files materialize as regular 0644
   and Git mode 100644.
4. Verify no repository contract or file classification requires those eight
   paths to remain 0600.
5. Record that the mode repair changes no Git blob, tracked textual diff,
   candidate content hash, semantic source, or Git executable bit.

If clean Git materialization does not establish 0644, stop:

RW0_C1_MODE_INTENT_UNRESOLVED

AUTHORIZED MUTATION

Perform exactly one bounded chmod operation over the eight listed paths,
setting each to:

0644

Equivalent required posture:

owner: read/write
group: read
other: read
no execute bits

Do not rewrite, copy, replace, normalize, touch, or otherwise change file
contents or timestamps beyond unavoidable chmod metadata.

Do not chmod any other path.

POST-REPAIR BYTE AND TOPOLOGY GUARDS

Require:

- all 81 candidate paths are regular physical mode 0644;
- the exact 81-path inventory is unchanged;
- no 82nd path;
- all eight repaired files have byte-for-byte identical content, size, and
  SHA-256 to the opening manifest;
- all other 73 candidate entries are byte/type/mode/size/hash identical to the
  opening candidate;
- every path outside the candidate equals HEAD;
- tracked textual diff SHA-256 remains exactly:
  c9e81fe9e3e82a39a5a239277d5187f67ea4795e285773b60f9b9afd4d858f54
- the candidate Git tree computed from the exact overlay remains unchanged
  before versus after chmod;
- Git status path set/classification is unchanged;
- cached diff remains empty;
- `git diff --check` passes;
- no source, test, SQL, document, migration, public, or authority byte changed.

If any byte or path changes, stop:

RW0_C1_MODE_REPAIR_BYTE_DRIFT

VALIDATION-BINDING RESET

The old complete suite is semantically informative but is bound to the opening
mode-bearing candidate fingerprint. Create a fresh external evidence root and
bind validation to the repaired exact candidate.

Evidence root:

/private/tmp/ge-coordinator-rw0-c1-mode-repair.XXXXXX

Use:

umask 0022
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
a unique evidence-root PYTHONPYCACHEPREFIX for every Python process
distinct evidence-root TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
GIT_OPTIONAL_LOCKS=0
python3 -B
-p no:cacheprovider
-W error

Keep the original implementation evidence root and the failed independent-audit
root read-only and inventory-exact.

1. Mode-causality guard

Before repair evidence must show exactly the eight mode mismatches.
After repair the same guard must pass all 81 candidate modes.
No content mutation is permitted.

2. Final collection

Run one final collection after repair.

Require:

unique nodes:
5157

ordered SHA-256:
efd65837c5c0e05bcd720dc52be6bfd32aa1f861392496864900fb083e0971df

duplicates/unmapped/warnings:
0

stderr:
empty

3. Complete suite

Run one official complete-suite attempt over `tests`.

Require:

- 5157 collected and passed;
- zero failures, errors, skips, xfails, xpasses, warnings;
- empty stderr;
- parseable JUnit;
- exact ordered mapping to the retained 5157-node list;
- repaired candidate fingerprint identical before and after.

If attempt 001 fails, preserve it and classify the failure. Do not repair source
or tests in this tranche. Return:

RW0_C1_MODE_REPAIR_VALIDATION_FAILED

No second complete-suite attempt is authorized here.

PROVENANCE RESET

Use the exact indexed recipe source:

recipe ID:
governed-execution.audit-patch-manifest.v1

source size:
3945 bytes

source SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

Use the established safe output-redirection wrapper, verified byte-for-byte
against the implementation evidence. Do not modify the historical sink.

After validation:

1. Run the exact recipe twice.
2. Require byte-identical manifests and complete stdout.
3. Require empty stderr and return code zero.
4. Require exactly 81 files.
5. Require all 81 manifest modes to be 0644.
6. Require tracked textual diff hash unchanged.
7. Freeze and report:
   - new canonical manifest SHA-256;
   - complete output SHA-256;
   - file count;
   - exact eight-path mode delta from the opening manifest;
   - unchanged size/SHA-256 for every candidate file.
8. Verify all source/product bytes remain identical to the opening candidate.

CLEANUP AND EVIDENCE

Retain proportionate material evidence:

- opening identity;
- old manifest verification;
- clean-materialization mode proof;
- exact before/after mode ledger;
- byte-equality proof;
- collection result and ordered nodes;
- complete-suite stdout/stderr/JUnit/summary;
- final guards;
- both provenance runs;
- exact old-versus-new manifest comparison;
- final report.

Remove only mode-repair-created transient checkout, basetemp, cache, tmp, and
pycache paths.

Seal:

- directories mode 0700;
- retained files mode 0400;
- no retained symlink or special entry;
- self-excluding evidence index created last and independently reverified.

Do not modify or re-index the old implementation or failed-audit evidence roots.

SUCCESS TOKEN

Return exactly:

COORDINATOR_RW0_C1_MODE_REPAIRED_VALIDATION_RESET_READY_FOR_FRESH_INDEPENDENT_AUDIT

only if:

- exactly the eight modes changed from 0600 to 0644;
- no repository byte changed;
- all 81 candidate modes are 0644;
- collection and the sole complete suite passed;
- exact provenance was regenerated and sealed;
- no staging, commit, push, or PR action occurred.

FINAL INLINE REPORT

Use:

# Outcome
# Opening identity and provenance
# Mode-intent verification
# Exact eight-path repair
# Byte and topology preservation
# Collection and complete-suite validation
# New provenance manifest
# Prior-evidence preservation
# Cleanup and evidence index
# Authority and nonclaims
# Confidence

Required final statements:

IMPLEMENTATION_SOURCE_NOT_MODIFIED
IMPLEMENTATION_TESTS_NOT_MODIFIED
IMPLEMENTATION_DOCUMENT_CONTENT_NOT_MODIFIED
MIGRATION_BYTES_NOT_MODIFIED
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
PUBLIC_API_NOT_WIDENED
RW0_C2_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
