PROMPT_ID

RW0_B2_CANCELLATION_CONTROL_FRESH_INDEPENDENT_AUDIT_V1

TITLE

Coordinator RW0-B2 — fresh independent audit of the additive exact-current-
effect cancellation-control evidence profile

ENGAGEMENT TYPE

Fresh, read-only, provenance-gated independent audit in a new Codex
conversation.

Do not use the implementation conversation that produced the candidate.

No repository mutation, formatting, cleanup of candidate bytes, staging,
commit, push, pull request, merge, tag, release, deployment, remote contact,
provider/live-host contact, product worker/model invocation, database mutation,
migration, dependency installation, or supporting-repository inspection is
authorized.

Audit-created probes, disposable external repositories, pytest output, and
evidence may be written only below one new operator-owned, non-symlink,
mode-0700 root:

```text
/private/tmp/rw0-b2-cancellation-control-audit.XXXXXX
```

Use proportionate evidence. Do not create a recursive or self-protecting audit
framework. Permanent tests are trusted repository code; independent audit owns
external mutants, patch provenance, and causal review.

Print the complete operative report inline in chat. Do not respond only with a
verdict token or inaccessible evidence links.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Determine whether the exact 11-path additive cancellation-control candidate is
ready for the commit/push/pull-request gate.

The audit must establish:

1. complete preservation of every existing NWPF v1 semantic and test surface;
2. exact new profile bytes, identity, mapping behavior, and nonclaims;
3. exact-current author/validation/review relation behavior;
4. correct capsule, route/source, and target/cancellation orientation;
5. complete classifier precedence and coexistence behavior;
6. bounded safe reconstruction and exact work arithmetic;
7. privacy-safe and content-free failure behavior;
8. exact status and authority projections;
9. exact 11-path provenance, including the bounded Capability P01 update;
10. focused and complete-suite regression health.

EXPECTED OPENING IDENTITY

Require exactly:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-cancellation-control-v1

HEAD:
dd12b23762dc761736e55a1abfde12dd3ec23551

HEAD subject:
feat: implement RW0-B2 Capability semantics (#5)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
11 paths
8 tracked modifications
3 untracked additions
0 staged
0 unmerged

candidate paths:
all regular mode 0644

Git operation/lock:
none
```

The implementation report says the feature branch was locally associated with
`origin/trunk_dev` after an initial missing-upstream observation. Record this as
repository-local metadata history. It is not a candidate-byte defect unless
live identity or provenance is inconsistent.

Require:

```text
git diff --check:
clean

cached diff:
empty

candidate symlink/special path:
none

twelfth changed path:
absent

repository cache/bytecode/database/journal/archive/build/generated-manifest/
recorder residue:
none
```

Do not fetch or contact a remote.

IMPLEMENTATION EVIDENCE TARGET

Evidence root:

```text
/private/tmp/rw0-b2-cancellation-control-implementation.PxLuO0
```

Required self-excluding index:

```text
/private/tmp/rw0-b2-cancellation-control-implementation.PxLuO0/evidence-index.tsv

entries:
295

SHA-256:
185cdf69863cee3a8390a7f7e3c0412275376fd2029e8a863585c4b176d09443
```

Required final manifest:

```text
/private/tmp/rw0-b2-cancellation-control-implementation.PxLuO0/closing/final-manifest-run1.json

size:
2540 bytes

SHA-256:
4ee166ef60e38e5adb0fc6f4489ec1813c4d2898e49541652b1e9688305b42a3

files:
11
```

Required diff identities:

```text
tracked textual diff SHA-256:
ba20077fabfda4470d41453751ac60f4c15488ab5859bb207c36a4ac9731fbcc

standard binary diff SHA-256:
b847e01ecad7669704a208113bdd409dd382e68c0b98d182731e182a071b32a8
```

Required node evidence:

```text
opening:
5059
72ca14d20ff8e95384a8fa06b595227fb45bb7884aac295bbe4ae06ac761a0aa

final:
5087
fe756529f88a3c44c31a402d2266b00b14993f420b76fa2af15595103599580c

additions:
28

removed:
0

renamed:
0
```

Required complete suite:

```text
5087 passed
single official attempt
0 failures/errors/skips/xfails/xpasses/warnings
empty stderr
```

PROVENANCE RECIPE

Use the exact supplied recipe source:

```text
governed_execution_audit_patch_manifest_v1.py

size:
3945 bytes

SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

If it is not attached in the new conversation, locate the indexed copy in the
implementation evidence root. Verify exact bytes before use.

Copy it to the new audit root as mode `0400`.

Run it twice at opening and twice at closeout, redirecting only the fixed
historical sink. Require byte-identical manifests and complete output.

PROVENANCE GATE

Before correctness inspection:

1. safely `lstat` every evidence-root path component;
2. verify the evidence index against the current evidence inventory;
3. require retained directories mode `0700`, regular evidence files mode
   `0400`, and no symlink/special entry;
4. verify the final manifest and both retained recipe runs;
5. verify the exact live 11-path set, classification, type, mode, size, and
   SHA-256;
6. verify every path outside the 11-path set equals HEAD;
7. verify no twelfth path;
8. verify opening/final node lists and validation records;
9. verify the exact recipe source and run two fresh opening reproductions;
10. require exact equality to the indexed final manifest and complete output.

On any mandatory identity mismatch, stop before correctness judgment and
return:

```text
AUDIT_PROVENANCE_MISMATCH
```

Do not regenerate missing implementation evidence.

EXACT EXPECTED 11-PATH SET

Tracked modifications:

```text
.docs/rw0-b2-wire-protocol.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/worker-execution-boundary.md
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
tests/test_rw0_b2_capability_boundaries.py
```

Untracked additions:

```text
tests/test_rw0_b2_wire_cancellation_control_values.py
tests/test_rw0_b2_wire_cancellation_control_relations.py
tests/test_rw0_b2_wire_cancellation_control_boundaries.py
```

AUDIT PERSPECTIVES

After the provenance gate, use exactly four bounded, non-nesting, read-only
perspectives when available. Children do not run tests or modify files.

1. V1 preservation and patch-boundary reviewer
2. Profile/value/identity reviewer
3. Relation/classifier/reconstruction/work reviewer
4. Documentation/status/public-authority/evidence reviewer

The parent reconciles, runs independent probes and pytest, and closes out.
Preserve disagreements.

Every finding must include:

```text
ID
type
severity:
critical | high | medium | low | observation
contract or strategic target
path and line
evidence
impact
required correction
uncertainty
patch defect, pre-existing issue, report defect, environment defect, or
audit-process defect
```

REQUIRED INSPECTION

Inspect completely:

```text
.docs/rw0-b2-wire-protocol.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/worker-execution-boundary.md
.docs/rw0-b2-capability.md
.docs/rw0-b1-pure-phase-values.md
.docs/c2a-first-slice-semantic-protocol-contract.md

src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
src/ge_nwp_coordinator/_worker_execution_semantic_values.py
src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
src/ge_nwp_coordinator/__init__.py
pyproject.toml

tests/test_rw0_b2_wire_values.py
tests/test_rw0_b2_wire_relations.py
tests/test_rw0_b2_wire_codec.py
tests/test_rw0_b2_wire_boundaries.py

tests/test_rw0_b2_wire_cancellation_control_values.py
tests/test_rw0_b2_wire_cancellation_control_relations.py
tests/test_rw0_b2_wire_cancellation_control_boundaries.py

tests/test_rw0_b2_capability_values.py
tests/test_rw0_b2_capability_vectors.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b2_capability_boundaries.py

tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_vectors.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b1_boundaries.py

tests/test_worker_execution_semantic_values.py
tests/test_worker_execution_semantic_vectors.py
tests/test_worker_execution_semantic_relations.py
tests/test_worker_execution_semantic_boundaries.py
tests/test_c2a_relations.py
tests/test_c2a_effects_and_recovery.py

tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py
tests/test_runtime_non_authority.py
tests/test_c2a_nonimplementation.py
```

Inspect an additional Coordinator file only for a concrete dependency and state
why. Do not inspect another repository.

HYPOTHESIS A — COMPLETE V1 PRESERVATION

Compare HEAD and candidate mechanically.

Require:

1. existing NWPF schema/ref/digest unchanged:
   ```text
   rw0-wire-nwpf-v1
   470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454
   ```

2. existing command/result frame vectors unchanged:
   ```text
   command:
   3512 bytes
   cd75e668cc06fa67f39e3670d1867c134606491887112d10de8bd28c9d8e481e

   result:
   2450 bytes
   f8b8e3af49a88351607c85ab3e74bfc55e8f32c6ff0499edca6920bf6526dee1
   ```

3. all four existing Wire test files byte-identical to HEAD;

4. every existing B1 and C2A test byte-identical to HEAD;

5. Capability values/vectors/relations byte-identical to HEAD;

6. Capability boundaries differ only in P01 expected Wire source size and
   SHA-256;

7. in the Wire source, permit only:
   - adding `CandidateCapsuleManifestV1` and
     `_reconstruct_exact_worker_execution_value` to the existing C2A import;
   - appending the additive cancellation-control block after the prior EOF /
     current `classify_wire_process_result` definition.

8. independently verify every pre-existing Wire source byte/segment is
   unchanged after accounting for that one import-list addition and appended
   block.

A change to an existing v1 identity, field, meaning, relation, parser, codec,
profile, classifier, or test is a blocker.

HYPOTHESIS B — PROFILE IDENTITY AND MAPPING

Require exactly:

```text
schema:
governed-execution.nwp-rw0-wire-cancellation-control-profile.v1

ref:
rw0-wire-cancellation-control-v1

digest domain:
governed-execution.nwp-rw0-wire-cancellation-control-profile.v1.identity

canonical manifest:
12014 bytes

outer identity:
12154 bytes

digest:
4d6f84552b852a4c4073b4238591afd271072f648424eca9e744def436165288
```

Independently recover and compare:

1. production literal;
2. test-owned expected literal;
3. retained accepted-freeze literal in implementation evidence.

Recompute compact sorted-key JSON and digest independently.

Require exact manifest key order and nested scalar/container types.

Call `cancellation_control_profile_mapping()` repeatedly and prove:

- exact built-in outer dict;
- exact outer key order;
- deep fresh manifest graph;
- mutation of one returned graph cannot alter another call or owner constants;
- profile is absent from NWPF frames.

HYPOTHESIS C — CLASSIFICATION VALUE

Verify exact:

```text
RW0WireCancellationControlClassificationV1

fields:
classification
reason

classification:
invalid | incomplete | finite
```

Verify the complete result/reason matrix, private `_create`, disabled ordinary
construction, slots/finality, immutability, copy/deepcopy/pickle rejection,
class-name `repr`/`str`, fresh exact mapping, and absence of schema/ref/digest/
canonical identity/equality override/hidden payload.

Do not impose same-interpreter self-protection beyond the declared ordinary
class contract.

HYPOTHESIS D — REQUEST RELATION

Independently exercise the full Cartesian matrix:

```text
target:
author | validation | review

route:
direct_local_bootstrap | execution_substrate
```

Require:

- exact capsule omission for author;
- exact safely reconstructed manifest for validation/review;
- target delivery validated against target fence;
- cancellation delivery validated against cancellation fence and exact target;
- exact request coordinate binding;
- route/source:
  direct-local → supervisor
  ES → execution_substrate;
- no timestamp ordering/authenticity claim.

Use external one-predicate mutants for:

- wrong target class;
- explicit `None` for author;
- missing/wrong/sibling manifest;
- target/cancel swap;
- wrong target delivery;
- wrong cancellation delivery;
- cross-attempt/cross-command lineage;
- wrong request source for route;
- stale/tampered operand;
- duplicate alias where relevant.

HYPOTHESIS E — PROCESS RELATION

Exercise:

```text
target:
author | validation | review

event:
resource_limit_exceeded | signal_delivered

source:
supervisor | operating_system
```

Require exact target/capsule branch, target delivery relation, observation
coordinate binding, and no false route-authenticity inference.

Mutate target, delivery, manifest, event, source, attempt, fence, and digest
independently.

HYPOTHESIS F — RESPONSE RELATION

Exercise:

```text
target:
author | validation | review

response:
cancellation_acknowledged | cancellation_rejected

route:
direct local | ES
```

Require:

- complete request prerequisite;
- response validated against cancellation delivery/fence and exact target;
- route/source:
  direct local → direct_local_adapter
  ES → es_adapter;
- source ref and invocation ref need not equal request;
- timestamp order is not semantic.

Mutate request absence, request/response cross-orientation, target/cancel swap,
wrong route source, sibling manifest, and cross-attempt coordinates.

HYPOTHESIS G — CLASSIFIER MATRIX AND PRECEDENCE

Independently build a test-owned expected-result oracle.

Require exact precedence:

```text
invalid_input
duplicate_fact
unrelated_fact
conflicting_fact
cancellation_graph_mismatch
request absent
cancellation rejected
target process exited
resource limit
deadline
signal
acknowledgement
request pending
```

Require coexistence:

```text
rejection + exit → finite/cancellation_rejected
acknowledgement + exit → finite/target_process_exited
signal + exit → finite/target_process_exited
resource limit + exit → finite/target_process_exited
deadline + exit → finite/target_process_exited
process facts without request → incomplete/process_evidence_incomplete
response without request → invalid/cancellation_graph_mismatch
request only → incomplete/cancellation_request_pending
no facts → incomplete/process_evidence_incomplete
```

Require:

```text
-255 → finite/target_process_exited
0    → finite/target_process_exited
255  → finite/target_process_exited
```

Zero has no special success meaning.

Independently challenge:

- exact tuple outer types;
- tuple subclasses;
- lists/mappings;
- `None` observation elements;
- cardinalities 4/5, 2/3, 7/8;
- duplicate original object;
- duplicate safe ref;
- duplicate safe digest;
- two distinct singleton-role facts;
- acknowledgement plus rejection;
- admitted exact-type unrelated facts;
- malformed/tampered facts;
- response without request;
- target facts without request;
- wrong capsule/graph orientation.

HYPOTHESIS H — SAFE RECONSTRUCTION AND CAUSAL OWNER USE

Inspect the actual call graph and run external spies/probes.

Require:

1. every supplied occurrence is charged before semantic inspection;
2. every supplied occurrence is safely reconstructed exactly once;
3. repeated aliases are reconstructed and charged per occurrence before
   duplicate classification;
4. CandidateCapsuleManifestV1 uses the C2A owner reconstruction helper;
5. common graph operands are not reconstructed twice through public-relation
   recursion;
6. request, response, and classifier use validated-input helpers correctly;
7. C2A owner relations are actually invoked;
8. semantic reads use reconstructed locals, not original caller objects;
9. poisoning originals after reconstruction cannot alter the result;
10. selected and class-wide reconstruction bypass mutants are killed;
11. ordinary foreign exceptions are sanitized;
12. KeyboardInterrupt/SystemExit/GeneratorExit propagate.

Do not accept ledger-only proof; use bounded executable probes in disposable
external copies or monkeypatched isolated module loads.

HYPOTHESIS I — WORK ARITHMETIC

Independently derive:

```text
request:
author 640
validation/review 738

process:
author 498
validation/review 596

response:
author 764
validation/review 862

classifier:
author 1244
validation/review 1342
```

Require exact tariffs:

```text
request observation 62
process observation 54
worker command 116
attempt fence 92
effect fence 102
delivery 32
worker observation 124
capsule manifest 98
```

For every operation/target class:

- maximum-valid succeeds/evaluates normally;
- maximum-minus-one relation raises `work_limit_exceeded`;
- maximum-minus-one classifier returns `invalid/invalid_input`;
- mutant bypass of one tariff is detected;
- class-wide bypass is detected;
- fixed bounded scans do not hide unmetered attacker-controlled traversal.

HYPOTHESIS J — PRIVACY AND ERROR BOUNDARY

Require:

- exact finite public error reasons;
- content-free `str`, `repr`, and args behavior consistent with existing Wire
  error contract;
- no supplied refs, digests, paths, manifest entries, exit codes, payloads,
  cause, context, or hostile object retained through the public boundary;
- malformed input becomes finite invalid classification where specified;
- relation failures remain sealed errors;
- no raw capsule contents enter output or durable-looking projections.

HYPOTHESIS K — STATUS, AUTHORITY, AND PUBLIC BOUNDARY

Require:

1. exact single physical status line in all five projections;
2. normalized-identical bodies;
3. existing marker adjacency and Capability status order;
4. unchanged current registry row;
5. detailed Wire owner distinguishes:
   - NWPF v1;
   - cancellation-control profile;
   - B1 physical cancellation mechanism;
6. C remains future/blocked pending merge;
7. D/E/ES ownership unchanged;
8. no persistence, transport, process control, source authentication,
   provider/session behavior, credential handling, public export, production
   caller, terminality, permission, acceptance, or runtime authority;
9. `__all__ == ()`;
10. no package-root export or production importer.

HYPOTHESIS L — P01 COMPATIBILITY UPDATE

Require final Wire source:

```text
size:
126092 bytes

SHA-256:
fdb97043f4f93620ecf5be43e78ebda0553e2792a219ab846789ad586790c776
```

Require Capability boundary P01 to contain exactly that size and digest.

Require no other byte in the Capability boundary test to differ from HEAD.

IMPLEMENTATION-EVIDENCE ASSESSMENT

Inspect and classify all reported failed/superseded attempts:

- two non-creditable red gates;
- creditable three-symbol red gate;
- missing-PYTHONPATH vector calculation;
- development values failure;
- development relations failures;
- stale-P01 development boundary failures;
- zsh `path` wrapper failure;
- wrong digest-domain guard;
- rejected cleanup-bearing guard.

Require that none is hidden, credited improperly, or associated with an
unreported candidate mutation.

Verify final focused records, final node list, complete-suite JUnit, repository
fingerprints, and both provenance runs.

INDEPENDENT VALIDATION

Only after source inspection and targeted probes are green enough, run serial
pytest beneath neutral audit paths.

Environment:

```text
umask 022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
GIT_OPTIONAL_LOCKS=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
distinct external --basetemp
distinct external --junitxml
```

Run:

1. all three new test modules;
2. existing Wire v1 modules;
3. C2A compatibility;
4. B1 compatibility;
5. Capability compatibility;
6. status/architecture/runtime compatibility.

Require zero failures/errors/skips/xfails/warnings, empty stderr, parseable
JUnit, no duplicate/unmapped cases, and unchanged candidate fingerprint.

If all inspection, probes, and focused validation remain green, run one fresh
complete suite.

Require:

```text
5087 collected
5087 passed
0 failures/errors/skips/xfails/xpasses/warnings
empty stderr
exact JUnit/node mapping
unchanged candidate fingerprint
```

Only one complete-suite attempt is authorized. If a deterministic material
blocker is found first, withhold it and say so.

NODE RECONCILIATION

Independently collect candidate and clean `git archive HEAD` nodes.

Require:

```text
candidate:
5087
fe756529f88a3c44c31a402d2266b00b14993f420b76fa2af15595103599580c

opening retained:
5059
72ca14d20ff8e95384a8fa06b595227fb45bb7884aac295bbe4ae06ac761a0aa

candidate additions:
28

distribution:
7 values
9 relations
12 boundaries

opening removals:
0

opening renames:
0

outside-new-files order:
exact
```

Report candidate-vs-HEAD intersection, candidate-only, and HEAD-only sets.

CLOSEOUT

After removing only audit-created transient material:

1. rerun the exact recipe twice;
2. require exact equality to opening audit target and implementation manifest;
3. verify source identity, topology, and all 11 paths unchanged;
4. verify implementation evidence root unchanged;
5. verify no repository residue;
6. retain complete audit evidence;
7. retained directories mode `0700`, files mode `0400`;
8. no symlink/special entry;
9. create a self-excluding evidence index;
10. print the complete report inline.

VERDICT

Return exactly one:

```text
ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH
```

Use:

- `ACCEPT` only if no Critical, High, Medium, or Low candidate defect remains;
- `BLOCK` for a repairable candidate, contract, test/oracle, evidence, report,
  environment, privacy, public-boundary, or authority defect;
- `REJECT` only for a fundamental accepted-architecture contradiction;
- `AUDIT_PROVENANCE_MISMATCH` only for target identity failure before
  correctness judgment.

If `ACCEPT`, also return exactly:

```text
COORDINATOR_RW0_B2_CANCELLATION_CONTROL_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Do not stage, commit, push, or create a PR.

FINAL INLINE REPORT

Use:

```text
# Verdict
# Opening and closing identity
# Provenance and exact 11-path candidate
# V1 preservation
# Profile identity and mapping
# Classification value
# Relation matrices
# Classifier precedence
# Reconstruction and work accounting
# Privacy and error boundary
# Status, public, and authority boundary
# P01 compatibility update
# Implementation-evidence assessment
# Node reconciliation
# Independent validation
# Severity-ranked finding ledger
# Closeout and evidence index
# Confidence
```

Required final statements:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
PRODUCTION_PERSISTENCE_NOT_MODIFIED
GOVERNING_V1_SEMANTICS_NOT_MODIFIED
CAPABILITY_NOT_MODIFIED_EXCEPT_P01_IDENTITY
B1_NOT_MODIFIED
C2A_NOT_MODIFIED
RW0_C_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
```
