PROMPT_ID

RW0_C1_PHASE_PROOF_AND_TRANSIENT_OPERAND_CLOSURE_V1

TITLE

Coordinator RW0-C1 — close phase-establishment proof persistence and every
admission-time transient private operand without changing the accepted C1
architecture

ENGAGEMENT TYPE

Final narrow parent-only, read-only contract reconciliation.

Do not implement, edit, format, stage, commit, push, create a PR, merge, run
tests, collect nodes, execute migrations, open a database, fetch, contact a
remote or live system, install dependencies, invoke a product worker/model, or
inspect another repository.

Print the complete substantive result inline. Evidence files are supplementary
only.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
047563de5a443b0f8323401c92979ae2e444d2ed

tree:
4ff9ee4a710af13447e3ed8699339a51255ff720

sole parent:
dd12b23762dc761736e55a1abfde12dd3ec23551

subject:
feat: add RW0-B2 cancellation-control evidence (#6)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktree/index/untracked/unmerged:
clean

No fetch is authorized.

ACCEPTED DECISIONS THAT ARE NOT REOPENED

Preserve the complete latest C1 contract except where this prompt explicitly
identifies a missing representation.

Accepted and frozen:

1. C1/C2 split.
2. C1 private no-contact durable phase/evidence capability.
3. Exactly 15 evidence kinds and the latest dependency DAG.
4. Single-member admission only.
5. Stable membership_ref/membership_digest identity.
6. Same-phase membership FK for C1-evidence relation operands.
7. Rank 13 actual worker-result binding only.
8. Rank 14 result_state = present | finite_failure | absent.
9. Maximum two member relations; relation_rank 0|1; reader LIMIT 3.
10. phase_basis_ref/phase_basis_digest vocabulary.
11. Existing _CoordinatorMutationTransactionController remains the sole
    transaction authority and is extended with C1 operations.
12. Kind-scoped evidence identity.
13. Safe capsule binding only; no capsule entries or complete manifest in
    SQLite.
14. C2 operation-time transient manifest and later durable classification
    attestation.
15. Additive generation-2 migration 0004, zero seed, no C2 state.
16. 23 table / 46 trigger / 4 explicit index direction unless this closure
    proves a count change.
17. Exact 81-path implementation allowlist unless this closure proves one
    additional causal path.
18. Existing owner semantics, migrations 0001–0003, public APIs, package
    exports, and supporting repositories remain unchanged.

WHY THIS FINAL CLOSURE IS REQUIRED

The latest “implementation ready” result still leaves two connected gaps.

A. PHASE-ESTABLISHMENT RELATION ATTESTATION HAS NO DURABLE ROW FAMILY

The accepted observable capability requires the established phase to expose:

- the exact owner relation/version;
- proof mode;
- exact durable owner-row operands;
- the transient full WorkSpec binding;
- relation-set and phase-graph digests.

The latest contract says phase establishment is not inserted into the member
relation tables, while the phase row previously carried only relation count/set
digests and not an exact relation row or ordered operand closure.

A relation-set digest without durable relation identity/version/operands is not
an inspectable phase-establishment proof.

B. THE CLOSED OPERAND-SOURCE VOCABULARY CANNOT REPRESENT ALL ACCEPTED
ADMISSION-TIME PRIVATE OPERANDS

The current accepted relation-operand branches cover:

- same-phase C1 evidence;
- existing owner rows;
- safe capsule-manifest binding.

But accepted owner relations also require private transient inputs that are
intentionally not durable in raw form:

- phase establishment: full WorkSpec;
- rank 1: optional full CandidateCapsuleManifestV1;
- rank 3: transient WorkSpec branch;
- rank 12 capsule observations: full manifest plus before_blobs and after_blobs;
- rank 14 finite_failure: actual sealed RW0WireProtocolError.

The command digest alone binds the whole command, but the durable relation
attestation still needs an exact, privacy-safe, ordered semantic operand
closure. It must not persist raw WorkSpec, blob maps, capsule entries, or an
exception object.

PRIMARY OBJECTIVE

Return one exact representation that closes both gaps while preserving:

- 23 tables;
- 46 immutability triggers;
- 4 new explicit indexes;
- 62/110/5 cumulative totals;
- the exact 81-path allowlist, unless a concrete current assertion forces one
  additional path.

Do not reopen any other C1 decision.

REQUIRED INSPECTION

Re-read:

- the latest C1 contract responses supplied in this conversation;
- `.docs/durable-state-model.md`;
- `.docs/rw0-b1-pure-phase-values.md`;
- `.docs/rw0-b2-wire-protocol.md`;
- `.docs/c2a-first-slice-semantic-protocol-contract.md`;
- `_rw0_phase_entry_semantic_values.py`;
- `_worker_execution_semantic_values.py`;
- `_rw0_wire_protocol_values.py`;
- the current migration-0002/0003 row/receipt/graph patterns;
- the proposed relation/membership/receipt schemas;
- transaction-controller, reader, replay, and recovery contracts.

A. PHASE RELATION REPRESENTATION

Use the existing two relation tables unless repository evidence proves they
cannot represent the phase without weakening member integrity.

Preferred exact model:

`rw0_relation_bindings` has:

```text
subject_type:
phase_establishment | evidence_membership
```

Common fields:

```text
schema_id
phase_basis_ref
phase_basis_digest
relation_ref
relation_digest
relation_rank
relation_schema_id
relation_version
proof_mode
profile_ref
profile_digest
operand_count
operand_set_digest
relation_row_digest
```

Phase branch:

```text
subject_type = phase_establishment
subject_membership_ref/digest null
subject_kind_rank null
subject_value_ref/digest/schema null
relation_rank = 0
exact FK to rw0_phase_instances
```

Membership branch:

```text
subject_type = evidence_membership
full membership and value identity non-null
full same-phase composite FK to rw0_evidence_memberships
relation_rank = 0 | 1
```

Freeze the exact branch CHECK, PK/UNIQUE constraints, and FK shapes.

Freeze phase relation identity:

```text
relation_schema_id:
governed-execution.nwp-rw0-c1-phase-entry-basis-relation.v1

relation_version:
1

proof_mode:
relation_attested_at_admission

profile:
null
```

Freeze phase relation-set digest and relation-ref derivation/preassignment.

The phase row must identify the exact relation set without creating a digest
cycle. Explain the digest order.

If a separate phase-relation table is selected instead, prove why the common
relation tables cannot support the branch and recompute table/trigger/index
counts. Do not leave phase proof implicit in command_digest alone.

B. CLOSED TRANSIENT PRIVATE BINDING VOCABULARY

Freeze one general privacy-safe relation-operand branch:

```text
operand_source = transient_private_binding
```

It replaces any manifest-only special case and supports a closed binding-kind
inventory.

Required binding kinds:

```text
work_spec
candidate_capsule_manifest
before_blob_set
after_blob_set
wire_protocol_error
```

For every kind specify:

- binding schema ID;
- exact semantic ref rule;
- digest domain;
- exact durable fields;
- scope digest fields;
- how the admission command binds the raw private object;
- how owner reconstruction/validation occurs before writes;
- why the durable row leaks no prohibited material;
- whether replay can rerun the relation;
- whether C2 needs the raw operand later.

Minimum expected durable shape:

```text
operand_schema_id
operand_ref
operand_digest
operand_scope_digest
```

with exact branch-specific interpretation.

Do not store:

- WorkSpec body, requirements, exclusions, or path list;
- capsule entries, paths, modes, per-file digests/lengths, or bytes;
- before/after map keys, values, file digests, lengths, or paths;
- exception object, traceback, cause, context, or arbitrary message.

C. TRANSIENT BINDING DEFINITIONS

Freeze these exact contracts or provide a safer exact alternative.

1. `work_spec`

Durable safe binding should use owner-approved identities already present in
the phase:

```text
schema:
governed-execution.nwp-rw0-c1-transient-work-spec-binding.v1

ref:
work_spec_ref

digest:
work_spec_digest

scope:
work_spec_safe_projection_digest
```

Clarify phase-establishment and rank-3 usage.

2. `candidate_capsule_manifest`

Durable safe binding should be exactly:

```text
schema:
governed-execution.nwp-candidate-capsule-manifest.v1

ref:
capsule_manifest_ref

digest:
portable_capsule_digest

scope:
authorized_path_scope_digest
```

Candidate ref is already bound by the phase/member graph and must not be
encoded as an entry.

3. `before_blob_set` and `after_blob_set`

Define a C1-owned opaque aggregate binding that:

- is computed over the exact canonical private blob map used for owner
  validation;
- stores only an aggregate semantic digest and deterministic private-binding
  ref;
- exposes no map key/path, per-file digest, length, or bytes;
- distinguishes before from after;
- is included in command and relation digests;
- is never treated as evidence identity or a retrievable capsule body.

Freeze:

```text
schema IDs
ref derivation
digest domains
canonicalization of the private map
maximum cardinality inherited from the owner
```

4. `wire_protocol_error`

Define a C1-owned finite-error binding that:

- accepts only an actual sealed RW0WireProtocolError at admission;
- stores only one exact finite reason from the frozen owner inventory;
- binds that reason into command/relation/result/receipt digests;
- stores no exception identity, args beyond the sealed invariant, traceback,
  cause, context, or object;
- is not an evidence member;
- cannot be reconstructed into an RW0WireProtocolError on replay.

Freeze its schema/ref/digest rule.

D. PROOF-MODE BRANCHES

Correct the proof-mode ledger where transient private inputs exist.

At minimum decide exactly:

- phase establishment: attested at admission;
- rank 1:
  - recomputable when no transient manifest is required;
  - attested at admission when a transient manifest is required;
  or one intentionally conservative mode for all rank-1 cases;
- rank 3:
  - existing owner row reconstructed;
  - or attested at admission for transient WorkSpec;
- rank 10/11: attested at admission;
- rank 12:
  - recomputable only if every owner operand is durable and no private blob map
    or transient manifest is required;
  - attested at admission otherwise;
- rank 14:
  - present and absent branches recomputable;
  - finite_failure attested at admission.

Freeze how proof mode is stored, replayed, and recovered.

E. RELATION OPERAND SQL BRANCHES

Return the exact final `rw0_relation_operands` columns and branch CHECKs for:

```text
c1_evidence
existing_owner_row
transient_private_binding
```

For `c1_evidence`, retain the full same-phase membership FK.

For `existing_owner_row`, freeze the exact locator fields and prevent arbitrary
table-name authority. Prefer a closed owner-role/schema inventory, not a raw
table-name string supplied by callers.

For `transient_private_binding`, require the exact schema/ref/digest/scope
branch and prohibit membership fields.

Freeze:

- PK/UNIQUE;
- relation FK;
- dense ordinal rule;
- maximum 14;
- exact reader columns and LIMIT 15;
- collision behavior;
- digest fields.

F. PHASE WRITE/REPLAY/RECOVERY ORDER

Freeze phase-establishment digest and insertion order with the phase relation:

1. validate command and raw transient WorkSpec;
2. compute relation semantic digest and operand-set digest;
3. compute relation-set digest;
4. compute phase graph/row digest without a cycle;
5. insert phase;
6. insert phase relation binding;
7. insert relation operands;
8. insert receipt last;
9. full readback;
10. invalidate capability;
11. one commit attempt.

Freeze exact committed/absent/unresolved probes for:

- phase row;
- phase relation row;
- every operand;
- receipt;
- K8 and phase collisions.

No phase can be `committed_exact` without its relation/operand closure.

G. MEMBER WRITE/REPLAY/RECOVERY ORDER

Confirm the accepted acyclic membership/relation digest sequence and add
transient bindings.

Committed exact must verify:

- typed value;
- membership;
- relation set;
- every c1-evidence membership operand;
- every owner-row operand;
- every transient-private binding;
- receipt/result/graph digests.

Definitely absent must prove absence of all operation-owned identities while
allowing exact reusable registry/payload rows to preexist.

H. TABLE/COUNT/PATH CONSEQUENCES

State whether:

```text
23 tables
46 triggers
4 explicit indexes
62 cumulative tables
110 cumulative triggers
5 cumulative explicit indexes
```

remain exact.

State whether the exact 81-path ledger remains sufficient.

Search for any current test/document that pins:

- relation subject enum;
- operand-source enum;
- phase relation storage;
- relation table column set;
- source inventory impacted by this closure.

Add a path only if omission has a direct causal failure. Otherwise preserve the
81-path ceiling.

I. IMPLEMENTATION READINESS

Return `RW0_C1_IMPLEMENTATION_CONTRACT_READY` only if:

- phase relation is durably represented;
- every transient private owner operand has an exact privacy-safe binding;
- proof modes are exact by branch;
- replay/recovery semantics are closed;
- table/count/path identities are exact;
- no raw private material or second transaction authority is introduced.

Return `RW0_C1_FREEZE_RECONCILIATION_REQUIRED` if any exact schema, digest,
branch, recovery, or path detail remains open.

Return `RW0_C_ARCHITECTURAL_REPLAN_REQUIRED` only for a genuine accepted-
architecture contradiction.

OUTPUT

Print inline:

# Baseline and inspection boundary
# Preserved C1 architecture
# Phase-establishment relation representation
# Transient private binding vocabulary
# Exact binding schemas and digest domains
# Proof-mode branches
# Final relation-binding and operand SQL
# Phase write, replay, and recovery
# Member write, replay, and recovery
# Table/count/path consequences
# Findings and contradictions
# Forecasts and stop conditions
# Recommendation
# Next implementation boundary

End with exactly one:

RW0_C1_IMPLEMENTATION_CONTRACT_READY

RW0_C1_FREEZE_RECONCILIATION_REQUIRED

or

RW0_C_ARCHITECTURAL_REPLAN_REQUIRED

Do not issue an implementation prompt.

Required final statements:

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
