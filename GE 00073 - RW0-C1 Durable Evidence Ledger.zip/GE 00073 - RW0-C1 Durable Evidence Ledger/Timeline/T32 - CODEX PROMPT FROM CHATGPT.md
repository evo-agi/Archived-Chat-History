PROMPT_ID

RW0_C1_SEMANTIC_EVALUATION_VS_ADMISSION_TIME_CLOSURE_V1

TITLE

Coordinator RW0-C1 — decouple owner semantic evaluation time from durable
admission time for host and Capability qualifications

ENGAGEMENT TYPE

Final narrow parent-only read-only correction.

Do not implement, edit, format, stage, commit, push, create a PR, merge, run
tests, collect nodes, execute migrations, open a database, fetch, contact a
remote/live system, install dependencies, invoke a product worker/model, or
inspect another repository.

Print the complete substantive result inline.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
047563de5a443b0f8323401c92979ae2e444d2ed

tree:
4ff9ee4a710af13447e3ed8699339a51255ff720

sole parent:
dd12b23762dc761736e55a1abfde12dd3ec23551

subject:
feat: add RW0-B2 cancellation-control evidence (#6)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktree/index/untracked/unmerged:
clean

No fetch is authorized.

ACCEPTED CONTRACT THAT IS NOT REOPENED

Preserve the complete latest RW0-C1 implementation contract, including:

- C1/C2 decomposition;
- 15 evidence kinds and dependency DAG;
- single-member admission;
- stable membership identity;
- same-phase relation operand integrity;
- rank-13/rank-14 algebra;
- maximum two member relations;
- one transaction controller;
- kind-scoped evidence identity;
- safe capsule binding only;
- phase relation in common relation tables;
- transient-private binding vocabulary;
- admission snapshot bindings for mutable current rows;
- evaluated_at column in relation bindings;
- additive generation-2 migration 0004;
- 23 tables, 46 new immutability triggers, 4 new explicit indexes;
- cumulative 62 tables, 110 triggers, 5 explicit indexes;
- exact 81-path implementation allowlist;
- no C2 state, public API, production caller, external contact, or supporting-
  repository change.

THE REMAINING DEFECT

The previous response froze:

```text
membership.admitted_at = operation_timestamp
relation.evaluated_at = operation_timestamp
owner now_utc = operation_timestamp
```

for all six time-sensitive relation IDs, and then required rank 9 to be admitted
within the same whole second as its already admitted rank-6 prerequisite.

That is not required by the merged owners and makes single-member admission
operationally brittle.

Source facts:

1. `validate_host_qualification(...)` requires:

```text
RW0EffectHostQualificationV1.evaluated_at == now_utc
```

2. `validate_worker_mechanism_capability_qualification(...)` requires:

```text
capability_qualification.evaluated_at
==
host_qualification.evaluated_at
==
now_utc
```

3. Neither owner requires the durable membership-admission timestamp to equal
that semantic evaluation timestamp.

The durable operation timestamp and owner semantic evaluation timestamp must be
distinct concepts.

PRIMARY OBJECTIVE

Freeze one exact temporal contract that:

- preserves single-member admission;
- allows rank 9 to be admitted after rank 6 without a same-second race;
- preserves exact owner semantics;
- never reevaluates historical relations using the current clock;
- does not permit future-dated evidence;
- requires no new table, column, trigger, index, path, or transaction authority.

A. TWO TIMESTAMPS

Freeze:

```text
operation_timestamp
```

- controller-owned whole-second UTC;
- captured after prerequisite reads and immediately before relation evaluation;
- persisted as membership.admitted_at, result/receipt committed_at, and other
  transaction timestamps;
- represents when Coordinator durably admitted the member.

Freeze separately:

```text
relation_evaluated_at
```

- the exact semantic instant supplied to the owner’s `now_utc`;
- persisted as relation.evaluated_at;
- included in relation semantic digest, row digest, relation-set verification,
  replay, and recovery;
- never replaced with the current clock.

B. CLOSED TEMPORAL-SOURCE REGISTRY

Freeze the exact source of `relation_evaluated_at` by relation ID.

Operation-time relations:

```text
governed-execution.nwp-rw0-c1-authority-verification-observation-relation.v1
governed-execution.nwp-rw0-c1-subordinate-narrowing-relation.v1
governed-execution.nwp-rw0-c1-custody-binding-relation.v1
governed-execution.nwp-rw0-c1-retrieval-event-sequence-relation.v1
```

For those four:

```text
relation_evaluated_at = operation_timestamp
owner now_utc = operation_timestamp
```

Subject-time relations:

```text
governed-execution.nwp-rw0-c1-host-qualification-relation.v1
governed-execution.nwp-rw0-c1-worker-mechanism-capability-qualification-relation.v1
```

For rank 6:

```text
relation_evaluated_at =
  RW0EffectHostQualificationV1.evaluated_at

owner now_utc = relation_evaluated_at

relation_evaluated_at <= operation_timestamp
```

For rank 9:

```text
relation_evaluated_at =
  RW0WorkerMechanismCapabilityQualificationV1.evaluated_at
  =
  prerequisite rank-6 RW0EffectHostQualificationV1.evaluated_at

owner now_utc = relation_evaluated_at

relation_evaluated_at <= operation_timestamp
```

All comparisons use exact canonical whole-second UTC strings.

A future-dated semantic evaluation instant is `relation_failure`.

C. ADMISSION SEMANTICS

Freeze these nonclaims:

- rank-6/rank-9 admission proves the owner relation at the subject’s stated
  historical evaluation instant;
- it does not prove the qualification is current at admission time;
- it does not prove currentness for a later C2 decision;
- C2 must use its own closure-time currentness evidence and policy;
- no membership or relation is backdated: admitted_at remains the actual C1
  operation timestamp.

The rank-9 dependency remains:

```text
exact admitted rank-6 membership
exact rank-6 typed value
exact equal evaluated_at
```

There is no grouped admission and no same-second transaction requirement.

D. SQL AND READBACK

Keep the existing `evaluated_at` column.

Freeze the SQL posture:

- evaluated_at non-null for the same six relation IDs;
- evaluated_at null for every other relation;
- SQL does not claim evaluated_at equals membership.admitted_at;
- cross-row temporal equalities are verified by exact family reconstruction,
  readback, replay, recovery, and permanent tests.

Freeze application/readback checks:

```text
ranks 1,2,3,4:
  relation.evaluated_at == membership.admitted_at

rank 6:
  relation.evaluated_at == host qualification evaluated_at
  relation.evaluated_at <= membership.admitted_at

rank 9:
  relation.evaluated_at == capability qualification evaluated_at
  relation.evaluated_at == prerequisite host qualification evaluated_at
  relation.evaluated_at <= membership.admitted_at
```

`membership.admitted_at` and `relation.evaluated_at` both remain in their
respective digest closures.

E. REPLAY AND RECOVERY

Freeze:

- recomputable relations rerun with persisted relation.evaluated_at;
- replay never captures a new clock value;
- recovery never uses current wall time;
- rank-6/rank-9 committed-exact verification permits later admission timestamps;
- missing, future, noncanonical, or mismatched evaluated_at yields unresolved
  integrity failure or pre-write relation failure as appropriate.

F. COUNTS AND PATHS

Confirm no change to:

```text
23 new tables
46 new triggers
4 new explicit indexes
62 cumulative tables
110 cumulative triggers
5 cumulative explicit indexes
81 must-change paths
```

No new file is authorized.

G. IMPLEMENTATION READINESS

Return `RW0_C1_IMPLEMENTATION_CONTRACT_READY` only if the temporal contract is
closed exactly as above or with an equally precise owner-compatible alternative
that removes the same-second transaction dependency.

Return `RW0_C1_FREEZE_RECONCILIATION_REQUIRED` if any timestamp, SQL, digest,
replay, recovery, or currentness detail remains open.

Return `RW0_C_ARCHITECTURAL_REPLAN_REQUIRED` only for a genuine accepted-
architecture contradiction.

OUTPUT

Print inline:

# Baseline and inspection boundary
# Preserved C1 contract
# Durable admission time
# Owner semantic evaluation time
# Closed temporal-source registry
# Rank-6 and rank-9 dependency semantics
# SQL, digest, replay, and recovery consequences
# Counts and touched-path consequences
# Findings and contradictions
# Recommendation
# Next implementation boundary

End with exactly one:

RW0_C1_IMPLEMENTATION_CONTRACT_READY

RW0_C1_FREEZE_RECONCILIATION_REQUIRED

or

RW0_C_ARCHITECTURAL_REPLAN_REQUIRED

Do not issue an implementation prompt.

Required final statements:

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
