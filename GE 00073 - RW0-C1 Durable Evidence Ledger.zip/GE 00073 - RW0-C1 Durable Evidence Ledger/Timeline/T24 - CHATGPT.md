# Disposition

**Do not start RW0-C1 implementation yet.**

The C1/C2 decomposition remains valid, and the admission DAG is substantially improved. But the claimed final implementation contract still contains three material contradictions. I would reclassify its result as:

```text
RW0_C1_FREEZE_RECONCILIATION_REQUIRED
```

—not `RW0_C_ARCHITECTURAL_REPLAN_REQUIRED`.

## 1. Kind 14 violates the current durable privacy contract

The merged durable-state owner is explicit:

> WorkSpec and candidate-capsule manifests receive only privacy-safe projections; capsule entries, paths, modes, file digests, lengths, candidate/capsule bytes, and workspace material remain outside SQLite.

That contract is at:

```text
.docs/durable-state-model.md:465-472
```

The proposed `rw0_wire_process_result_classification_bindings` row instead persists the complete three-entry capsule projection:

- entry paths;
- operations;
- modes;
- before/after blob hashes;
- before/after byte lengths;
- enough metadata to reconstruct `CandidateCapsuleManifestV1`.

That is not an ordinary C1 implementation choice. It is direct durable-state and privacy-contract churn.

The correct boundary is:

```text
C1:
persist only the privacy-safe capsule binding
  candidate_ref where applicable
  capsule_manifest_ref
  portable_capsule_digest
  owner-approved safe profile/scope identities
  relation/profile version and ref/digest operand bindings

C2 operation:
receive the full manifest transiently
verify it against the durable safe binding
recompute cancellation-control classification
persist only the C2 classification/closure attestation

C2 recovery:
verify the committed attestation, command digest, profile pair,
safe capsule binding, closure, and result digest
do not pretend to reconstruct the full manifest from C1 SQLite
```

This preserves all of the intended boundaries:

- the cancellation-control classifier is still not a C1 member;
- C2 still computes it;
- no B2 relation needs to change;
- no D custody or bearer mechanics enter C;
- capsule entries remain outside SQLite.

Rank 14 should return to being an **NWPF process/result-classification binding**, not a hybrid NWPF classification plus cancellation-control operand closure.

## 2. The evidence registry key is scoped incorrectly

The response first treats evidence identity as kind-scoped, but then freezes:

```text
PRIMARY KEY value_ref
UNIQUE value_digest
```

That silently creates a repository-wide namespace across unrelated B1, Wire, Capability, C2A, Section 41, and C1 wrapper values.

The existing safe-ref contract only validates syntax and reserved prefixes; it does not establish cross-schema global uniqueness. See:

```text
src/ge_nwp_coordinator/_development_row_value_support.py:22-33
src/ge_nwp_coordinator/_development_row_value_support.py:88-96
```

The registry needs an owner-supported composite identity, most likely:

```text
PRIMARY KEY (kind_rank, value_ref)
UNIQUE (kind_rank, value_digest)
UNIQUE (kind_rank, value_ref, value_digest, value_schema_id)
```

or an exact schema-scoped equivalent.

This changes:

- registry PK and uniqueness;
- typed-payload composite FKs;
- membership FKs;
- ref/digest collision probes;
- read predicates;
- replay verification;
- recovery absence checks;
- the definition of `member_identity_collision`.

Cross-kind reuse of the same textual ref must remain legal unless the owning value contracts explicitly forbid it.

## 3. The 76-path allowlist is demonstrably incomplete

Two omitted tests directly pin documents the implementation says it will change.

`tests/test_b4c_public_global_stop_delegation.py` requires the B4c owner document to say migration `0003` is the current terminal:

```text
tests/test_b4c_public_global_stop_delegation.py:1456-1464
```

Specifically, lines 1462–1463 assert both `terminal-0003` and that migration `0003` is current terminal.

`tests/test_c2b3c_author_effect_contract.py` pins the durable-state summary sentence:

```text
tests/test_c2b3c_author_effect_contract.py:202-220
```

Line 219 requires:

```text
Current state remains generation 2 and terminates at migration 0003
```

Both owning documents are in the proposed must-change set. These tests must therefore change as well, or the document updates must be abandoned.

So the claimed exact split:

```text
60 existing paths
16 new paths
76 total
```

is not exact.

There may be further omissions. A fresh repository-wide pass must classify every live occurrence of:

- current terminal migration `0003`;
- current generation-2 schema totals;
- migration-resource inventories;
- coherent-fixture current tip;
- source/importer inventories;
- RW0-C future/current status;
- exact document phrases being rewritten.

Historical tranche assertions must remain protected, but live current-tip assertions must be included causally.

## Consequence for the SQL freeze

Because the capsule and registry corrections affect table columns, keys, readers, collision queries, and recovery, these identities are not yet frozen:

```text
23 tables
46 triggers
4 explicit indexes
62 cumulative tables
110 cumulative triggers
5 cumulative explicit indexes
```

Those counts may remain correct, but they must be recomputed after:

- removing capsule-entry columns from rank 14;
- restoring rank 14 to NWPF-only semantics;
- changing the evidence registry to composite owner-scoped keys;
- updating all dependent FKs and readers.

No implementation prompt should claim those counts as accepted until that reconciliation is complete.

# What remains accepted

These parts should not be reopened:

- C1 and C2 remain separate tranches.
- C1 remains independently useful.
- There are still exactly 15 evidence kinds.
- No grouped-admission operation is currently needed.
- Readiness and declaration admission do not imply qualification.
- Qualification members depend on already admitted prerequisite members.
- Retrieval admission validates an admitted prefix.
- Cancellation responses depend on an admitted request.
- C1 does not persist the cancellation-control classification.
- Migration `0004` contains no C2 decision, latch, closure, or terminal state.
- Receipt-first replay, one commit attempt, and three-way recovery remain the correct transaction model.
- Typed tables remain preferable to a universal JSON/BLOB evidence table.

# Next reconciliation prompt

Send this prompt to the same read-only Coordinator Codex conversation:

:chatgpt-content-reference{index="1"}

```text
Filename:
Coordinator_RW0_C1_Privacy_Identity_and_Scope_Reconciliation_Prompt.txt

Size:
13,265 bytes

SHA-256:
618afa5953a2e9ded5f99febb3c1c8169146645a32cbf67dafe594edd2b8f371
```

The prompt is deliberately narrow. It does not reopen the phase decomposition or ask Codex to redesign C1 broadly. It requires closure of exactly:

1. capsule privacy and transient C2 manifest use;
2. rank-14 semantics;
3. composite evidence identity;
4. resulting SQL/FK/recovery changes;
5. the exhaustive path-by-path allowlist.

The successful terminal result remains:

```text
RW0_C1_FINAL_IMPLEMENTATION_CONTRACT_READY
```

Only after that result should we issue the workspace-write implementation prompt.

### Sources

- Current merged Coordinator snapshot: `Governed Execution Coordinator - Snapshot - 2026-09-27.zip`. 
- Codex’s final C1 contract response supplied in this turn.
- `.docs/durable-state-model.md:465-479`
- `src/ge_nwp_coordinator/_development_row_value_support.py:22-33,88-96`
- `tests/test_b4c_public_global_stop_delegation.py:1456-1464`
- `tests/test_c2b3c_author_effect_contract.py:202-220`

**Confidence:** High that the C1/C2 architecture remains sound; high that the current “ready” contract is not implementation-ready because of the capsule privacy violation and incomplete touched-file ledger; high that one bounded reconciliation can close the remaining issues without architectural replan.
