# Decision

**The second residual-repair tranche has crossed the repair gate. Proceed to a completely fresh independent re-audit. Do not stage or commit RW0-C1 yet.**

The report credibly claims closure of all four fresh re-audit findings while preserving the C1 architecture, migration schema, privacy model, and public boundaries. :chatgpt-content-reference{index="0"}

## Why this is ready for re-audit

The repaired candidate now claims a cross-layer commit-close witness spanning the writer wrapper, module delegate, and transaction controller. Its uncertainty window starts immediately before COMMIT and remains open until outer cleanup completes; ordinary failures inside that window become `commit_outcome_unknown`. Real-COMMIT tests reportedly cover the affected close boundaries and recover the committed state using only the pre-retained selector. :chatgpt-content-reference{index="1"}

The DNC repair also addresses the durable routes missed by the prior audit:

- registry lookup by kind/ref and kind/digest;
- typed payload lookup by both routes for all 15 kinds;
- rank-1 and rank-12 child rows even when parents are absent;
- relation bindings and operands by global `relation_ref`, without a phase-filter shortcut.

Aliases, child-only fragments, malformed families, and foreign-phase relation identities now reportedly produce `unresolved`. :chatgpt-content-reference{index="2"}

Recovery has a separate close witness and no longer misuses commit uncertainty. Cleanup failure after a computed recovery result is reported as `unresolved`, while primary errors and process-control precedence are preserved. :chatgpt-content-reference{index="3"}

The permanent suite gained 23 distinct cases for the witness, real-COMMIT boundaries, aliases, child-only fragments, global relation identities, and recovery cleanup. :chatgpt-content-reference{index="4"} The test-first gate ran against unchanged production bytes and produced the three expected product failures without harness noise. :chatgpt-content-reference{index="5"}

## Final candidate identities

The repair changed 16 of the authorized 19 paths. Every non-allowlisted candidate path and the three unused allowlisted test paths remained byte-identical. :chatgpt-content-reference{index="6"}

```text
Canonical manifest SHA-256:
d8c535c68e4096b5e00998d57f504e6139402c4207a0d0a0749fbf2b4c42d936

Tracked textual diff SHA-256:
c21ac61476e8369746b8420ac0f0d2d54a73599b304005575409e0e3641e537e

Complete recipe output SHA-256:
d8574b02c42e7f23b0eddca5ae04bf864345d0b5448e5d88e2b18a9fcc82fb24

Candidate file count:
81

Final candidate fingerprint:
52b27985f25c7a4537f9654180bd9d2ed6fb184398b3a09cf26b567a85f6c60c

Final nodes:
5,200

Ordered node SHA-256:
1337267bfd05f4b5d99db5f987d8c9fcecf85deedc95530ab9c4fa30b2526cc1

Residual-repair evidence-index SHA-256:
e0a1b61edbf51373c99a4eb155c8c9c05c7c3c8f7239ac9d74db5997165ac52c
```

The final collection added 23 nodes, removed or renamed none, and retained every prior node in exact relative order. :chatgpt-content-reference{index="7"} The single official complete-suite attempt passed all 5,200 tests with exact JUnit mapping and no failures, skips, or warnings. :chatgpt-content-reference{index="8"}

## What remains unproven

This report is implementation-side evidence, not independent acceptance. In particular:

- no clean independent candidate was built during the repair; :chatgpt-content-reference{index="9"}
- the complete suite ran only against the live candidate;
- the cross-layer witness and DNC reader expansion have not yet been independently inspected or fault-injected;
- the permanent tests have not yet been externally mutation-tested against the final source;
- existing transition, global-stop, and C2B cleanup semantics need independent regression confirmation.

The next audit should distinguish every effective post-COMMIT boundary rather than crediting an aggregate “eight cases” claim. It should independently exercise result publication, controller return, module return, capability cleanup, connection/controller cleanup, mutation-slot close, operation-lease close, process stabilization, and writer-session cleanup.

## Fresh independent re-audit handoff

Start a **new read-only Codex audit conversation**. Do not resume either prior audit root.

:chatgpt-content-reference{index="11"}[Download the final fresh independent re-audit prompt](sandbox:/mnt/data/Coordinator_RW0_C1_Final_Fresh_Independent_Reaudit_After_Residual_Repair_Prompt.txt)

```text
Filename:
Coordinator_RW0_C1_Final_Fresh_Independent_Reaudit_After_Residual_Repair_Prompt.txt

Size:
19,290 bytes

SHA-256:
3ceb72a93fd97cd32a399d697b764ece2661ff38e6c038712c4afadb7bed9f4a
```

The prompt requires:

- exact provenance and 16-path repair-delta verification;
- independent real-COMMIT fault injection across every close boundary;
- malformed physical-state probes for payload aliases, child-only fragments, and foreign-phase relation identities;
- recovery-cleanup fault injection;
- external one-predicate mutants against all 23 new tests;
- regression of the previously closed selector, CAS-order, owner-reader, and temporal findings;
- an independent clean candidate with a separate object database;
- matching live and clean 5,200-node collections;
- one live and one clean complete suite if no material blocker is found.

The only acceptance result remains:

```text
ACCEPT

COORDINATOR_RW0_C1_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Until then:

```text
RW0-C1:
implemented and twice repaired, independently unaccepted

commit/push/PR gate:
closed

RW0-C2:
not implemented

RW0-D:
not implemented

RW0-E:
not implemented
```

### Source

- Codex’s residual findings-repair report. :chatgpt-content-reference{index="10"}

**Confidence:** High that the report warrants a fresh independent re-audit; high that no migration-schema or architectural replan is currently indicated; acceptance remains uncertain until the cross-layer close witness, complete DNC route coverage, recovery cleanup algebra, and permanent tests are independently reproduced.

The current attachment was readable. Some older Project uploads have expired; they only need to be re-uploaded if a later audit specifically depends on them.
