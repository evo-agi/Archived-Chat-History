PROMPT_ID

RW0_C1_FINAL_FRESH_INDEPENDENT_REAUDIT_AFTER_RESIDUAL_REPAIR_V1

TITLE

Coordinator RW0-C1 — final fresh independent re-audit after residual
commit-close, DNC-route, recovery-cleanup, and permanent-oracle repairs

ENGAGEMENT TYPE

Fresh independent read-only audit.

Do not repair, edit, format, generate repository files, stage, commit, push,
create a PR, merge, tag, release, deploy, fetch, contact a remote/live system,
install dependencies, invoke a product worker/model, modify a supporting
repository, or migrate an operator database.

Do not resume, amend, or write into any predecessor implementation, repair, or
audit root. Create one new private audit root.

Print the complete substantive report inline. Evidence files may be
supplementary only. The operative verdict and finding ledger must not exist only
in a file.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED LIVE REPOSITORY IDENTITY

physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-c1-durable-evidence-v1

HEAD:
047563de5a443b0f8323401c92979ae2e444d2ed

HEAD tree:
4ff9ee4a710af13447e3ed8699339a51255ff720

sole parent:
dd12b23762dc761736e55a1abfde12dd3ec23551

subject:
feat: add RW0-B2 cancellation-control evidence (#6)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

staged/unmerged:
0/0

candidate:
exactly 81 changed/untracked paths, all regular physical mode 0644, no 82nd
path, and no repository residue.

No fetch is authorized. Use local Git metadata only.

CURRENT FINAL CANDIDATE IDENTITIES

Canonical manifest SHA-256:
d8c535c68e4096b5e00998d57f504e6139402c4207a0d0a0749fbf2b4c42d936

Full-candidate tracked textual diff SHA-256:
c21ac61476e8369746b8420ac0f0d2d54a73599b304005575409e0e3641e537e

Complete provenance-recipe output SHA-256:
d8574b02c42e7f23b0eddca5ae04bf864345d0b5448e5d88e2b18a9fcc82fb24

Candidate file count:
81

Final collected nodes:
5200

Final ordered node SHA-256:
1337267bfd05f4b5d99db5f987d8c9fcecf85deedc95530ab9c4fa30b2526cc1

Opening nodes before this residual repair:
5177

Opening ordered node SHA-256:
1718dbbab1ce2a906389607d2cae304c9dce3dfaffe2f40bff42b37b0d5b36b8

Node additions:
23

Removals/renames:
0/0

Final internal 81-file candidate fingerprint:
52b27985f25c7a4537f9654180bd9d2ed6fb184398b3a09cf26b567a85f6c60c

RESIDUAL-REPAIR EVIDENCE ROOT

/private/tmp/ge-coordinator-rw0-c1-reaudit-findings-repair.iBwPRM

Self-excluding index:
/private/tmp/ge-coordinator-rw0-c1-reaudit-findings-repair.iBwPRM/evidence-index.txt

Index SHA-256:
e0a1b61edbf51373c99a4eb155c8c9c05c7c3c8f7239ac9d74db5997165ac52c

Indexed files:
282

Indexed subdirectories:
34

PREDECESSOR EVIDENCE ROOTS

Verify all read-only and preserve unchanged.

Original implementation:
/private/tmp/ge-coordinator-rw0-c1-implementation.Zcopmg
index:
cd1ad5ea72ef20a774fd470e38f14882a25f99af94db970c4506c62d4a4cc2b4

Mode repair:
/private/tmp/ge-coordinator-rw0-c1-mode-repair.k6Pxw5
index:
5b30767c439a982e209c765f93c775547709555f5305697817a1b335e1bf2cc8

First provenance-stop audit:
/private/tmp/ge-coordinator-rw0-c1-independent-audit.6Cd8VB
index:
3929be307c05a532c491f5f520bad4d76cde702d7e0b41460cf0c8ab90373b25

First substantive audit:
/private/tmp/ge-coordinator-rw0-c1-independent-audit.bYt6vjqX
index:
c276c664922dc4ef87e7418c6657aaf9d61ddb05c643666019ff85c86796168e

First findings repair:
/private/tmp/ge-coordinator-rw0-c1-audit-findings-repair.li1vJX
index:
a62fb4458f838ad23bc23b47bcfbd6527906c94724ea1a1b3044e3bf871c9bc2

Fresh re-audit:
/private/tmp/ge-coordinator-rw0-c1-fresh-reaudit.tWw8xz
index:
424c482738213c716dadaa636dde7f7a838f10472b63b0e9dabd8b226d8d0e5d

Do not alter, clean, re-index, normalize, or reinterpret these roots in place.

EXACT PROVENANCE RECIPE

recipe ID:
governed-execution.audit-patch-manifest.v1

source size:
3945 bytes

source SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

Verify the indexed exact source and safe historical-sink redirection wrapper.
The wrapper may redirect only the output sink and must not alter Git queries,
canonical JSON, stdout, stderr, path classification, or manifest fields.

CLAIMED RESIDUAL REPAIR DELTA

Exactly 16 opening-to-final paths are claimed to differ, all inside the
authorized 19-path repair ceiling.

Documentation:

.docs/rw0-c1-durable-evidence.md
.docs/sqlite-operations-and-recovery.md
.docs/sqlite-threat-model.md
.docs/writer-session-authority.md

Production:

src/ge_nwp_coordinator/_rw0_c1_mutation_contracts.py
src/ge_nwp_coordinator/_sqlite_rw0_c1.py
src/ge_nwp_coordinator/_sqlite_rw0_c1_reader_contracts.py
src/ge_nwp_coordinator/_sqlite_rw0_c1_readers.py
src/ge_nwp_coordinator/sqlite_transition_transaction.py
src/ge_nwp_coordinator/sqlite_writer_session.py

Tests:

tests/test_b3c4c_prerequisite_contract.py
tests/test_rw0_c1_mutation_contracts.py
tests/test_rw0_c1_private_readers.py
tests/test_rw0_c1_reader_contracts.py
tests/test_rw0_c1_recovery.py
tests/test_rw0_c1_writer_session_delegation.py

Require every other candidate path to be byte-identical to the opening candidate
identified by manifest
`7935bc7ba9162f07d47807eeefa50d794ff3381937c167bd77656c39c15f95bf`.

The three unused allowlisted test paths must remain byte-identical.

RE-AUDIT FINDINGS CLAIMED REPAIRED

RW0-C1-REAUD-001 — High
Cross-layer post-COMMIT uncertainty now spans controller, module, and writer
close proof using a private monotonic `_RW0C1CommitCloseWitness`.

RW0-C1-REAUD-002 — High
DNC now probes every payload ref/digest route, rank-1/rank-12 child-only route,
and global relation binding/operand identity before returning
definitely_not_committed.

RW0-C1-REAUD-003 — Medium
Recovery cleanup uncertainty at mutation-lease, operation-lease, and outer
writer cleanup now returns exact `unresolved`.

RW0-C1-REAUD-004 — Medium
Permanent tests now cover the omitted commit-close, identity-route, child-only,
foreign-phase relation, and recovery-cleanup boundaries.

FIRST-AUDIT FINDING STATUS TO PRESERVE

- AUD-001 caller-constructible selector: closed.
- AUD-002 DNC soundness: superseded by REAUD-002; must now be fully closed.
- AUD-003 post-COMMIT cleanup: superseded by REAUD-001 and REAUD-003; must now
  be fully closed.
- AUD-004 current-state CAS ordering: closed.
- AUD-005 owner-reader fault propagation: closed.
- AUD-006 permanent-oracle completeness: superseded by REAUD-004; must now be
  fully closed.
- AUD-007 temporal equality: closed.
- AUD-008 original red gate: historical, preserved, and non-creditable.

AUDIT POSTURE

Use one new private audit root under `/private/tmp`.

Use:

umask 0022
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
unique audit-root PYTHONPYCACHEPREFIX for every Python process
distinct audit-root TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
GIT_OPTIONAL_LOCKS=0
python3 -B
-p no:cacheprovider
-W error

Keep evidence proportionate. Do not build a recursive self-protecting audit
framework. Do not require permanent tests to defend themselves against
equal-authority mutation.

After provenance passes, conduct exactly four bounded, non-nesting read-only
perspectives. The parent reconciles them:

1. cross-layer commit-close and recovery-cleanup algebra;
2. DNC identity-route completeness and malformed durable-state handling;
3. permanent-test causality and regression against previously closed findings;
4. provenance, schema/privacy/public boundary, clean reconstruction, and
   validation.

No perspective may delegate further or modify repository files.

PROVENANCE GATE

Before correctness inspection:

1. Verify exact repository identity and one-worktree topology.
2. Verify exactly 81 candidate paths, all regular physical mode 0644.
3. Verify no staged/unmerged path, lock, operation, residue, or 82nd path.
4. Verify the residual-repair evidence index exactly:
   path set, type, owner, mode, size, digest, no unsafe or unindexed entry.
5. Verify every predecessor evidence index exactly.
6. Verify exact recipe source and wrapper.
7. Run the recipe twice with safe output redirection.
8. Require byte-identical manifests and complete outputs matching:
   - manifest `d8c535c6...`;
   - textual diff `c21ac614...`;
   - complete output `d8574b02...`;
   - 81 files.
9. Verify every live candidate entry against the manifest.
10. Require every path outside the candidate to equal HEAD.
11. Verify exact 16-path residual-repair delta and all protected candidate
    bytes.
12. Verify migrations 0001–0004 and `sqlite_migration.py` against expected
    protected identities.
13. Verify package exports, StateStore, public WriterSession protocol, and all
    semantic-owner modules are unchanged.
14. Record opening repository/evidence inventories for closeout.

Stop before correctness on any mismatch:

AUDIT_PROVENANCE_MISMATCH

AUDIT HYPOTHESES

A. Cross-layer commit-close witness

Independently inspect and execute the witness design.

Require:

- one private witness per fresh C1 mutation;
- exact monotonic states:
  precommit,
  commit_attempt_started,
  commit_returned_success,
  close_proof_complete;
- no backward transition, reset, reuse, or cross-operation sharing;
- witness created before entry into the module/controller path;
- commit_attempt_started immediately before the sole underlying COMMIT;
- commit_returned_success only after COMMIT returns normally;
- close_proof_complete only after the full outer writer-session close proof;
- replay/conflict paths that never attempt COMMIT remain precommit and retain
  their narrower safe classification;
- no public, durable, serialized, or authoritative witness surface.

With real successful COMMIT, independently inject ordinary failures at:

1. committed-result publication;
2. controller method return;
3. module-delegate return;
4. nominal-capability finalization;
5. controller/connection cleanup;
6. mutation-slot close;
7. operation-lease close;
8. process-control stabilization;
9. writer-session post-operation cleanup.

The repair report groups some boundaries into eight permanent cases; the audit
must exercise every distinct effective boundary above.

For each:

- caller receives exact content-free `commit_outcome_unknown`;
- no raw RuntimeError, database_integrity_failure, or mutation_failed escapes;
- committed rows and one receipt exist;
- the selector retained before apply resolves `committed_exact`;
- no duplicate membership/relation/receipt appears;
- candidate bytes are unchanged.

Preserve governing process-control exception precedence.

B. Complete DNC durable-identity closure

Independently create physical malformed states in disposable external
databases.

For each of all 15 typed tables, verify exact literal reader support for:

- `(kind_rank, value_ref)`;
- `(kind_rank, value_digest)`.

At minimum execute:

- payload digest alias under another ref;
- payload ref alias under another digest;
- registry-only;
- payload-only;
- exact reusable registry+payload;
- malformed payload schema/digest.

For rank 1 child rows:

- child-only by selector value ref;
- child-only by selector value digest;
- partial/mismatched child family;
- exact reusable parent+children.

For rank 12 child rows:

- child-only by selector value ref;
- child-only by selector value digest;
- partial/mismatched child family;
- exact reusable parent+children.

For each deterministic operation relation ref:

- foreign-phase relation binding;
- foreign-phase relation operand without matching binding where physically
  constructible;
- operand fragment under the global relation identity;
- malformed relation subject;
- exact global absence.

Require:

- aliases, child-only rows, malformed/partial families, foreign-phase relation
  rows, or unreadable state -> `unresolved`;
- exact reusable registry/payload/children plus absence of all operation-owned
  rows -> `definitely_not_committed`;
- no phase-filtered shortcut can hide a global relation identity;
- no retry is authorized from an unresolved state.

Verify the 52-query inventory is exact, explicit-column, closed, bounded, and
contains no caller-supplied table name or SELECT *.

C. Recovery close witness and three-result algebra

Independently inspect and execute `_RW0C1RecoveryCloseWitness`.

Require:

- private, one-shot, non-durable, non-exported;
- no use of commit uncertainty;
- no recovery disposition reaches the caller before close proof;
- ordinary cleanup uncertainty after a computed result becomes exact
  `unresolved`.

Inject faults after a valid computed disposition at:

- mutation-lease close;
- operation-lease close;
- controller/connection cleanup if applicable;
- outer writer-session post-operation cleanup;
- process stabilization.

Verify:

- exact `unresolved`;
- no raw RuntimeError;
- no mutation_failed or database_integrity_failure solely from secondary
  cleanup uncertainty;
- primary pre-result safe error precedence remains intact;
- governing process-control exceptions retain repository-defined precedence.

D. Permanent test causality

Review all 23 new nodes and every changed test.

Require no volume-only duplication.

For every residual route, map at least one permanent test to one finite product
claim:

- witness monotonicity/one-shot behavior;
- each effective real-COMMIT close boundary;
- safe cleanup-error variants;
- payload ref and digest aliases;
- rank-1 child ref/digest-only fragments;
- rank-12 child ref/digest-only fragments;
- global relation binding/operand foreign-phase routes;
- recovery mutation/operation/outer cleanup faults.

Run external one-predicate mutants against the final tests. For each retain:

- exact source hunk;
- intended predicate;
- selected node set;
- expected and actual outcome;
- finite diagnostic;
- restoration proof.

Verify the test-first red gate:

- only the claimed test file changed before source repair;
- the six opening production files matched the reported hashes;
- exactly the three claimed product failures occurred;
- no import, syntax, fixture, path, or environment failure;
- later safe-retirement fixture corrections did not weaken the intended
  assertions.

E. Previously closed finding regression

Re-exercise:

- pre-apply caller-constructible recovery selector;
- selector-only committed recovery;
- actual-current CAS before collision probes;
- owner-reader `None` versus safe fault propagation;
- strict rank-6/rank-9 temporal equality and `>` to `>=` mutant kill;
- exact replay without a new clock or writes;
- no same-writer automatic retry.

F. Schema/privacy/authority regression

Verify no residual-repair regression:

- migration 0004 bytes/checksum unchanged;
- 23/46/4 C1 delta and 62/110/5 cumulative totals unchanged;
- zero C1 seeds;
- 15 kinds unchanged;
- no capsule entries, WorkSpec bodies, blob-map contents, exception graphs, or
  private runtime material in SQLite;
- no public/package/StateStore/WriterSession protocol widening;
- no production caller;
- no C2/D/E/ES/Bridge/runtime/external-contact behavior;
- B1/Wire/Capability/C2A/C2B/Section 41 owners unchanged;
- one transaction controller and one connection/commit authority.

G. Controller, reader, and cleanup regression

Verify:

- `_sqlite_rw0_c1.py` has no direct sqlite3 authority;
- sole controller still owns BEGIN/COMMIT/ROLLBACK/fencing/capability/cleanup;
- reader limits remain exactly 2,3,15,16,257,258;
- no SELECT *;
- same-phase membership integrity;
- relation and operand overflow checks;
- transition/global-stop/C2B cleanup semantics are not weakened by the new
  witness normalization;
- no ordinary precommit failure is incorrectly widened to
  commit_outcome_unknown.

INDEPENDENT VALIDATION ORDER

1. Provenance gate.
2. Static inspection of final repair and protected-byte comparison.
3. External cross-layer commit-close probes.
4. External DNC malformed-state probes.
5. External recovery-cleanup probes.
6. External permanent-test mutants.
7. Fresh focused runs:
   - residual repair focus;
   - all nine C1 modules;
   - reader/controller/writer compatibility;
   - transition/global-stop/C2B cleanup and transaction regressions;
   - migration/schema/fixture compatibility;
   - semantic-owner compatibility;
   - architecture/status/privacy/non-authority.
8. Fresh live collection.
9. Build an independent clean candidate:
   - exact HEAD archive;
   - overlay exactly the 81 final manifest paths;
   - fully external Git repository/object database;
   - no alternates and no shared source-object inodes;
   - diagnostic commit of the exact candidate tree.
10. Clean collection and focused residual/C1 validation.
11. If no Critical, High, Medium, or Low blocker remains:
    - one live complete suite;
    - one external clean-commit complete suite.
12. Closeout and exact provenance reproduction.

Do not substitute retained repair validation for independent validation.
If deterministic material blockers are found before the complete-suite gate,
withhold complete suites and state so.

NODE RECONCILIATION

Independently require:

- final live collection exactly 5200 nodes;
- ordered SHA-256
  `1337267bfd05f4b5d99db5f987d8c9fcecf85deedc95530ab9c4fa30b2526cc1`;
- all 5177 opening nodes retained in exact relative order;
- exactly 23 additions;
- zero removals, renames, duplicates, skips, or xfails;
- additions only in the two reported test files;
- clean and live collections identical.

FINDING CLASSIFICATION

For every finding report:

- ID;
- type;
- severity: Critical / High / Medium / Low / Observation;
- current contract or target;
- exact path/line;
- evidence and reproduction;
- impact;
- required correction;
- uncertainty;
- classification:
  candidate defect, contract defect, test/oracle defect, audit-harness defect,
  report defect, or environment defect.

Do not allow an audit-harness issue to masquerade as a candidate defect, and do
not allow passing broad tests to override deterministic transaction/recovery
failure.

CLOSEOUT

At closeout:

- reproduce the final manifest twice;
- verify opening/closing repository identity, status, path set, modes, diff,
  and candidate fingerprint;
- verify all predecessor and residual-repair evidence roots unchanged;
- remove only audit-created disposable paths;
- retain material commands, probes, stdout/stderr, JUnit, node lists,
  manifests, schema inventories, and report;
- root/directories mode 0700;
- retained files mode 0400;
- no retained symlink or special entry;
- create a self-excluding evidence index last and independently reverify it.

VERDICT

Return:

ACCEPT

and exactly:

COORDINATOR_RW0_C1_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE

only if provenance, all residual findings, all previously closed findings,
schema, privacy, authority, permanent-test causality, independent validation,
and evidence pass with no Critical, High, Medium, or Low finding.

Otherwise return:

BLOCK

with a severity-ranked ledger and no repair.

REQUIRED FINAL STATEMENTS

REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
MIGRATION_SCHEMA_NOT_MODIFIED
PUBLIC_API_NOT_WIDENED
RW0_C2_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
