Here is Codex's response:

# Baseline and inspection boundary

Baseline matched exactly:

- Branch: `trunk_dev`
- HEAD: `047563de5a443b0f8323401c92979ae2e444d2ed`
- Tree: `4ff9ee4a710af13447e3ed8699339a51255ff720`
- Sole parent: `dd12b23762dc761736e55a1abfde12dd3ec23551`
- Subject: `feat: add RW0-B2 cancellation-control evidence (#6)`
- Upstream: `origin/trunk_dev`
- Ahead/behind: `0/0`
- Worktree/index/untracked/unmerged: clean
- Worktrees: exactly one

Inspection was parent-only and read-only. No fetch, database open, migration execution, tests, other repository inspection, external contact, or sub-agent delegation occurred.

The five reported inconsistencies are real. None requires architectural replanning; all can be closed within C1.

# Preserved C1 architecture

C1 remains a private, no-contact, independently useful durable-evidence tranche. It owns one immutable phase, 15 evidence kinds, phase-specific membership, relation/profile binding, replay/conflict, guarded readback, and three-way recovery. C2 remains separate and later owns completeness, decisions, closure, terminal outcomes, and the accept latch.

The kind ledger remains:

| RankKindRequired dependency shapeProof mode |                                            |                                                                  |                                                                        |
| ------------------------------------------- | ------------------------------------------ | ---------------------------------------------------------------- | ---------------------------------------------------------------------- |
| 1                                           | authority verification observation         | existing owner rows                                              | `relation_recomputable`                                                |
| 2                                           | subordinate authorization proposal         | rank 1 plus owner rows                                           | `relation_recomputable`                                                |
| 3                                           | custody availability observation           | exact owner subject or transient WorkSpec                        | `existing_owner_row_reconstructed` or `relation_attested_at_admission` |
| 4                                           | retrieval capability event                 | ranks 1–3, all earlier rank-4 prefix members, owner rows         | `relation_recomputable`                                                |
| 5                                           | remote-host readiness observation          | standalone structural value                                      | `value_reconstructed`                                                  |
| 6                                           | effect-host qualification                  | ranks 1 and 5 plus current owner fence                           | `relation_recomputable`                                                |
| 7                                           | capability declaration                     | standalone structural value                                      | `value_reconstructed`                                                  |
| 8                                           | capability observation                     | exact rank-7 declaration                                         | `derived_wrapper_recomputable`                                         |
| 9                                           | capability qualification                   | ranks 1, 5, 6, 7, 8 plus owner fence                             | `relation_recomputable`                                                |
| 10                                          | Wire cancellation request                  | owner rows plus transient safe-manifest binding                  | `relation_attested_at_admission`                                       |
| 11                                          | Wire process observation                   | owner rows plus transient safe-manifest binding                  | `relation_attested_at_admission`                                       |
| 12                                          | C2A WorkerObservation                      | owner rows; cancellation response additionally requires rank 10  | `relation_attested_at_admission`                                       |
| 13                                          | Wire worker-result binding                 | exactly 2 or 3 rank-12 memberships                               | `derived_wrapper_recomputable`                                         |
| 14                                          | Wire process/result classification binding | result/failure/absence plus admitted observations and owner rows | branch-dependent, specified below                                      |
| 15                                          | Section 41 wrapper                         | exact existing proposal/disposition/head row                     | `existing_owner_row_reconstructed`                                     |

Admission remains single-member. Every C1 membership operand must already exist in the same phase. No grouped admission is added.

The legal topological order is ranks 1–15, with multiple rank-4 events admitted in sequence order and multiple rank-12 observations admitted individually before ranks 13 and 14. Legal partial phases are immutable prefixes or dependency-closed subsets; they imply neither completeness nor C2 eligibility.

# Stable membership identity

The stable membership model is retained and made consistent.

Schema ID:
```
governed-execution.nwp-rw0-c1-evidence-membership.v1
```

Digest domain:
```
governed-execution.nwp-rw0-c1-evidence-membership.v1.identity
```

`membership_ref` is an exact caller-preassigned safe ref supplied as `preassigned_membership_ref`. The Coordinator validates and persists it but does not derive, mint authority from, or reinterpret it. It is included in the command digest.

The ordered membership identity fields are:
```
schema_id
membership_ref
phase_basis_ref
phase_basis_digest
kind_rank
value_ref
value_digest
value_schema_id
scope_binding_digest
relation_set_digest
admitted_by_mutation_ref
admitted_at
admission_graph_digest
```

`membership_digest` is excluded from its own preimage.

The exact result and receipt projection for evidence admission carries:
```
phase_basis_ref
phase_basis_digest
membership_ref
membership_digest
kind_rank
value_ref
value_digest
value_schema_id
```

C2 must identify a member by that complete membership pair and kind/value identity. A bare reusable value ref/digest is insufficient.

Collision algebra:

- Existing `membership_ref` with a different digest or identity: `member_identity_collision`.
- Existing `membership_digest` under another ref: `member_identity_collision`.
- Same phase/kind/value already admitted under another membership ref: `member_already_admitted`.
- Identical membership owned by another mutation: `member_already_admitted`.
- Same reusable value admitted to another phase under a distinct membership: legal.
- Same textual ref or digest in a different evidence kind: legal at the registry layer.
- Same-kind registry ref/digest aliasing: `member_identity_collision`.

Digest construction is acyclic:

1. Compute each relation semantic digest using `membership_ref` and the exact phase/kind/value subject, but not the final `membership_digest`.
2. Compute `relation_set_digest` over `membership_ref` and the ordered `(relation_ref, relation_digest)` sequence.
3. Compute `admission_graph_digest` from the command digest, membership ref, phase/kind/value identity, typed-payload row digest, relation-set digest, mutation ref, and admission timestamp.
4. Compute `membership_digest`.
5. Attach the final membership digest to relation rows and compute their separate row digests.
6. Compute result and receipt digests last.

The relation-set domain is:
```
governed-execution.nwp-rw0-c1-relation-set.v1.identity
```

For ranks 5 and 7 its relation sequence is the exact empty sequence.

# Relation subject and operand integrity

A member relation’s subject is the exact membership, not the reusable registry value.

`rw0_relation_bindings` therefore carries:
```
schema_id
relation_ref
phase_basis_ref
phase_basis_digest
subject_membership_ref
subject_membership_digest
subject_kind_rank
subject_value_ref
subject_value_digest
subject_value_schema_id
relation_rank
relation_schema_id
proof_mode
profile_ref
profile_digest
operand_count
operand_set_digest
relation_digest
relation_row_digest
```

Its subject FK uses all of:
```
phase_basis_ref
phase_basis_digest
subject_membership_ref
subject_membership_digest
subject_kind_rank
subject_value_ref
subject_value_digest
subject_value_schema_id
```

`relation_digest` is the semantic relation identity. `relation_row_digest` additionally binds the final membership digest and is not included in `relation_set_digest`, preventing a digest cycle.

`rw0_relation_operands` carries:
```
schema_id
phase_basis_ref
phase_basis_digest
relation_ref
relation_digest
operand_ordinal
operand_role
operand_source
source_membership_ref
source_membership_digest
evidence_kind_rank
operand_schema_id
operand_ref
operand_digest
operand_scope_digest
operand_row_digest
```

The branch algebra is exact:

- `c1_evidence`:
  - source membership ref/digest and kind rank are non-null;
  - operand schema/ref/digest are non-null;
  - scope digest is null;
  - the composite FK targets an exact membership with the same phase pair, membership pair, kind, value ref, value digest, and value schema.
- `existing_owner_row`:
  - source membership ref/digest and evidence kind are null;
  - operand schema/ref/digest are non-null;
  - scope digest is null;
  - reconstruction uses the named existing private owner reader.
- `transient_safe_manifest_binding`:
  - source membership ref/digest and evidence kind are null;
  - manifest schema ID, manifest ref, portable-capsule digest, and authorized scope digest are non-null;
  - no manifest entries, paths, modes, blob digests, byte lengths, or raw manifest are persisted.

The registry FK alone is explicitly insufficient and is not used as the C1-evidence operand proof.

Phase establishment has no membership subject. Its phase-basis relation/attestation remains owned by the immutable `rw0_phase_instances` row and is not inserted into the member relation tables.

# Rank-13 and rank-14 result-state algebra

Rank 13 is only an actual `RW0WireWorkerResultV1` binding. It represents exactly the owner’s legal two- or three-observation sequence:
```
worker_started, worker_completed
```

or:
```
worker_started, candidate_captured, worker_completed
```

Its relation operands are exact pre-existing rank-12 memberships in sequence order. Rank 13 proves wrapper construction and observation ordering. It does not claim that the result is valid against the command/delivery/fence graph; rank 14 owns that classification.

Rank 14 has:
```
result_state = present | finite_failure | absent
```

with exact branches:
```
present:
  result_membership_ref non-null
  result_membership_digest non-null
  result_failure_reason null

finite_failure:
  result_membership_ref null
  result_membership_digest null
  result_failure_reason one exact finite Wire reason

absent:
  result_membership_ref null
  result_membership_digest null
  result_failure_reason null
```

The exact finite reason set, deduplicating the current decoder and construction inventories while preserving first occurrence order, is:
```
invalid_outer_type
short_header
bad_magic
unsupported_version
unsupported_kind
declared_length_over_cap
truncated_payload
trailing_data
invalid_utf8
bom_forbidden
json_token_invalid
duplicate_key
invalid_root_or_scalar
unknown_field
missing_field
nested_record_invalid
noncanonical_payload
relation_mismatch
work_limit_exceeded
invalid_field_type
invalid_field_value
invalid_length_or_cardinality
digest_mismatch
privacy_forbidden_material
```

The existing owner seals `RW0WireProtocolError` behind `_ERROR_TOKEN`. C1 must not import that token or fabricate an exception during readback.

Consequently:

- `present`: `relation_recomputable`;
- `absent`: `relation_recomputable` using `result=None, result_failure=None`;
- `finite_failure`: `relation_attested_at_admission`.

For `finite_failure`, admission must receive and validate the actual sealed error, invoke the classifier once, persist only its exact finite reason, and bind it into the command, relation, result, and receipt digests. Replay and recovery verify that attestation; they do not recreate the error.

This represents all owner branches, including `result_missing`, `result_invalid`, and `process_evidence_incomplete`. A present rank-13 result may still yield `result_invalid` if it is structurally valid but not related to the supplied command/delivery/fences.

# Exact relation cardinality

The closed relation-count contract is:
```
rank 5: exactly 0
rank 7: exactly 0
rank 12 ordinary observation: exactly 1
rank 12 cancellation acknowledgement/rejection: exactly 2
all other member ranks: exactly 1
maximum per member: 2
relation_rank: 0 or 1
relation overflow query: ORDER BY relation_rank LIMIT 3
```

For a cancellation response:

- `relation_rank=0` is the ordinary C2A observation relation.
- `relation_rank=1` is the exact-current Wire cancellation-response relation and includes the exact rank-10 request membership.

Relation requests are ordered by `relation_rank`. Duplicate ranks, refs, digests, roles, missing ranks, extra relations, or a missing prerequisite yield `relation_failure` or `missing_prerequisite_member` as applicable.

Operand count remains independently bounded at 14, matching the largest rank-14 classifier invocation. Operand ranks are dense `0..operand_count-1`, and the overflow query is `ORDER BY operand_ordinal LIMIT 15`.

The shared bounded-SELECT helper’s exact allowed limits become:
```
2, 3, 15, 16, 257, 258
```

No `LIMIT 4` or maximum-three relation claim remains.

# Normalized phase identity

Every C1 semantic value, SQL column, command, result, receipt, membership, relation, reader, recovery probe, and C2 forward seam uses:
```
phase_basis_ref
phase_basis_digest
```

The adapter mapping is exact:
```
RW0PhaseEntryBasisV1.basis_ref    -> phase_basis_ref
RW0PhaseEntryBasisV1.basis_digest -> phase_basis_digest
```

The owner’s shorter `basis_ref` and `basis_digest` names occur only while extracting the B1 value. No C1 schema or query uses unexplained `phase_ref` or `phase_digest`.

The K8 order remains:
```
program_ref
semantic_attempt_ref
candidate_ref
effect_intent_ref
author_command_ref
attempt_fence_ref
effect_fence_ref
delivery_attempt_ref
```

# Transaction-controller ownership

There is no current generic extension hook. C1 must extend the existing controller.

`sqlite_transition_transaction.py` gains exactly these controller entries:
```
run_atomic_rw0_c1_phase_establishment
run_rw0_c1_phase_establishment_recovery
run_atomic_rw0_c1_evidence_admission
run_rw0_c1_evidence_admission_recovery
```

and their four operation-specific transaction methods:
```
_run_atomic_rw0_c1_phase_establishment_transaction
_run_rw0_c1_phase_establishment_recovery_transaction
_run_atomic_rw0_c1_evidence_admission_transaction
_run_rw0_c1_evidence_admission_recovery_transaction
```

The module-level entries are:
```
_run_atomic_rw0_c1_phase_establishment
_run_rw0_c1_phase_establishment_recovery
_run_atomic_rw0_c1_evidence_admission
_run_rw0_c1_evidence_admission_recovery
```

The existing `_CoordinatorMutationTransactionController` remains the sole owner of:

- operation-lease and mutation-slot acquisition;
- resource-bound connection opening;
- `BEGIN IMMEDIATE`;
- binding and managed-schema validation;
- durable writer fencing;
- nominal capability construction and invalidation;
- SQLite write execution and error classification;
- rollback;
- exactly one commit attempt;
- commit-resolution state;
- connection custody, process-control stabilization, and cleanup.

`_sqlite_rw0_c1.py` owns only C1 resolution, exact row reconstruction, family readback, pure planning, literal SQL specifications, and closed write plans. It does not import `sqlite3`, open or close a connection, begin/commit/rollback, acquire a lease, construct a capability, or access controller fields.

The controller executes the closed C1 write plan on its retained connection. This preserves the existing eight-file direct-`sqlite3` importer inventory.

Import direction is one-way:
```
sqlite_writer_session
  -> function-local imports of transaction wrappers

sqlite_transition_transaction
  -> C1 contracts, C1 resolver/readback/plans, existing controller machinery

_sqlite_rw0_c1
  -> C1 values/rows/readers and pure owner modules
  -/-> sqlite_transition_transaction
  -/-> sqlite_writer_session
```

`sqlite_writer_session.py` gains private concrete-session methods for phase establishment, evidence admission, and their recovery calls. They enter the existing operation guard and delegate once. `WriterSession`, `StateStore`, package exports, and public protocols remain unchanged.

`sqlite_mutation_transaction_contracts.py` requires no change: its existing state graph already covers replay/conflict rollback, planned outcomes, writes, capability invalidation, one commit attempt, successful commit, unknown commit outcome, and close.

# Revised SQL and reader contracts

All migration-0004 tables are `STRICT`; scalar columns use the repository’s `ANY` plus exact `typeof`, safe-ref, digest, timestamp, integer, enum, and optional-pair checks.

## `rw0_evidence_memberships`

Ordered columns:
```
schema_id
membership_ref
membership_digest
phase_basis_ref
phase_basis_digest
kind_rank
value_ref
value_digest
value_schema_id
scope_binding_digest
relation_set_digest
admitted_by_mutation_ref
admitted_at
admission_graph_digest
```

Constraints:
```
PRIMARY KEY (membership_ref)
UNIQUE (membership_digest)
UNIQUE (phase_basis_ref, kind_rank, value_ref)
UNIQUE (phase_basis_ref, kind_rank, value_digest)
UNIQUE (phase_basis_ref, kind_rank, value_ref, value_digest, value_schema_id)
UNIQUE (phase_basis_ref, phase_basis_digest, membership_ref, membership_digest)
UNIQUE (
  phase_basis_ref, phase_basis_digest,
  membership_ref, membership_digest,
  kind_rank, value_ref, value_digest, value_schema_id
)
```

Restrictive immediate FKs:
```
(phase_basis_ref, phase_basis_digest)
  -> rw0_phase_instances

(kind_rank, value_ref, value_digest, value_schema_id)
  -> rw0_evidence_values
```

`admitted_by_mutation_ref` intentionally has no immediate receipt FK, avoiding an insertion cycle. Receipt/readback graph verification supplies that reverse binding.

## `rw0_relation_bindings`

Ordered columns are the exact subject fields listed earlier.

Constraints:
```
PRIMARY KEY (relation_ref)
UNIQUE (relation_digest)
UNIQUE (relation_row_digest)
UNIQUE (phase_basis_ref, phase_basis_digest, relation_ref, relation_digest)
UNIQUE (
  phase_basis_ref, phase_basis_digest,
  subject_membership_ref, relation_rank
)
CHECK (relation_rank IN (0,1))
CHECK (operand_count BETWEEN 0 AND 14)
```

The full subject composite FK targets `rw0_evidence_memberships`. `profile_ref` and `profile_digest` are both null or both non-null.

Proof mode is exactly one of:
```
value_reconstructed
relation_recomputable
relation_attested_at_admission
derived_wrapper_recomputable
existing_owner_row_reconstructed
```

## `rw0_relation_operands`

Constraints:
```
PRIMARY KEY (relation_ref, operand_ordinal)
UNIQUE (relation_ref, operand_role)
UNIQUE (operand_row_digest)
```

The relation FK is:
```
(phase_basis_ref, phase_basis_digest, relation_ref, relation_digest)
  -> rw0_relation_bindings
```

The `c1_evidence` branch’s full composite FK targets `rw0_evidence_memberships`, proving exact same-phase admission. Branch nullability is exactly as frozen above.

## `rw0_wire_worker_result_bindings`

Ordered columns:
```
schema_id
kind_rank
value_ref
value_digest
value_schema_id
phase_basis_ref
phase_basis_digest
program_ref
semantic_attempt_ref
candidate_ref
effect_intent_ref
author_command_ref
attempt_fence_ref
effect_fence_ref
delivery_attempt_ref
wire_profile_ref
wire_profile_digest
observation_count
observation_membership_set_digest
relation_ref
relation_digest
payload_row_digest
```

Checks and keys:
```
kind_rank = 13
observation_count IN (2,3)
PRIMARY KEY (kind_rank, value_ref)
UNIQUE (kind_rank, value_digest)
UNIQUE (payload_row_digest)
```

It has the exact registry and phase FKs. The relation locator is verified by family readback rather than an immediate FK, avoiding a typed-payload/membership/relation insertion cycle.

## `rw0_wire_process_result_classification_bindings`

Ordered columns:
```
schema_id
kind_rank
value_ref
value_digest
value_schema_id
phase_basis_ref
phase_basis_digest
program_ref
semantic_attempt_ref
candidate_ref
effect_intent_ref
author_command_ref
attempt_fence_ref
effect_fence_ref
delivery_attempt_ref
wire_profile_ref
wire_profile_digest
result_state
result_membership_ref
result_membership_digest
result_failure_reason
adapter_observation_count
adapter_observation_membership_set_digest
request_membership_ref
request_membership_digest
process_observation_count
process_observation_membership_set_digest
cancellation_effect_fence_ref
cancellation_effect_fence_digest
cancellation_delivery_attempt_ref
cancellation_delivery_envelope_digest
classification
reason
relation_ref
relation_digest
payload_row_digest
```

Checks and keys:
```
kind_rank = 14
adapter_observation_count BETWEEN 0 AND 4
process_observation_count BETWEEN 0 AND 2
result-state branch CHECK exactly as frozen above
request membership pair both null or both non-null
all four cancellation owner fields null or all four non-null
classification/reason obey the current Wire matrix
PRIMARY KEY (kind_rank, value_ref)
UNIQUE (kind_rank, value_digest)
UNIQUE (payload_row_digest)
```

Present result membership and optional request membership have restrictive same-phase membership FKs. The relation operands additionally enforce the expected ranks.

No cancellation-control classification or complete capsule manifest appears in this table.

## `rw0_c1_mutation_receipts`

Ordered columns:
```
schema_id
mutation_ref
mutation_family
command_schema_id
command_digest
phase_basis_ref
phase_basis_digest
membership_ref
membership_digest
kind_rank
value_ref
value_digest
value_schema_id
result_class
result_projection_digest
admission_graph_digest
outcome
committed_at
receipt_digest
```

Branch algebra:
```
establish_phase:
  command schema = phase-establishment command v1
  result_class = phase_established
  membership/kind/value columns all null

admit_evidence:
  command schema = evidence-admission command v1
  result_class = evidence_admitted
  membership/kind/value columns all non-null
```

Constraints:
```
PRIMARY KEY (mutation_ref)
UNIQUE (receipt_digest)
UNIQUE (membership_ref)
outcome = committed
```

Every receipt has the phase FK. The evidence branch has the full membership composite FK.

## Triggers, indexes, and totals

The table family remains exactly:
```
6 common tables
15 typed payload tables
2 normalized child tables
= 23 tables
```

The two child tables remain the rank-1 allowed-effect-class rows and rank-12 evidence-ref rows. No capsule-entry child table is permitted.

Every table is immutable and receives exactly:
```
<table>_no_update
<table>_no_delete
```

Therefore migration 0004 adds 46 triggers.

The four explicit indexes are:
```
idx_rw0_phase_instances_k8_lookup
  ON rw0_phase_instances(
    program_ref, semantic_attempt_ref, candidate_ref, effect_intent_ref,
    author_command_ref, attempt_fence_ref, effect_fence_ref,
    delivery_attempt_ref
  )

idx_rw0_evidence_memberships_phase_kind_page
  ON rw0_evidence_memberships(
    phase_basis_ref, kind_rank, membership_ref
  )

idx_rw0_relation_operands_c1_membership_lookup
  ON rw0_relation_operands(
    phase_basis_ref, phase_basis_digest,
    source_membership_ref, source_membership_digest,
    evidence_kind_rank, operand_ref, operand_digest, operand_schema_id,
    relation_ref, operand_ordinal
  )
  WHERE operand_source='c1_evidence'

idx_rw0_c1_mutation_receipts_phase_family_lookup
  ON rw0_c1_mutation_receipts(
    phase_basis_ref, mutation_family, mutation_ref
  )
```

Static cumulative arithmetic is:
```
current: 39 tables, 64 triggers, 1 explicit index
0004:   +23 tables, +46 triggers, +4 explicit indexes
total:   62 tables, 110 triggers, 5 explicit indexes
```

No count changes arise from the membership, relation, or result-state corrections because they change columns and constraints, not table families.

All point/collision readers use explicit columns, parameters, `LIMIT 2`, and `fetchmany(2)`. This covers receipt, phase-ref, phase-digest, K8, registry kind/ref, registry kind/digest, membership ref, membership digest, phase/kind/value-ref, phase/kind/value-digest, relation ref, relation digest, and each typed payload.

Aggregate readers are exactly:
```
relations for membership:
  ORDER BY relation_rank
  LIMIT 3
  fetchmany(3)

operands for relation:
  ORDER BY operand_ordinal
  LIMIT 15
  fetchmany(15)
```

No `SELECT *`, raw connection reader authority, public reader, or alternate connection path is added.

# Replay and recovery consequences

Apply ordering after writer fencing is:

1. receipt lookup by `mutation_ref`;
2. exact command-digest replay or `mutation_ref_reuse`;
3. phase/current-owner observation;
4. registry and membership collision probes;
5. prerequisite same-phase membership reads;
6. existing-owner reads in frozen operand order;
7. owner reconstruction and relation/classifier invocation;
8. one whole-second UTC transaction timestamp;
9. graph, membership, result, and receipt planning;
10. ordered inserts;
11. capability invalidation;
12. exactly one commit attempt.

Evidence-admission writes are:
```
registry row if not already exact
typed payload and normalized children if not already exact
membership
relation bindings in relation_rank order
relation operands in operand_ordinal order
receipt last
```

Replay requires a fresh valid writer session, exact `mutation_ref`, exact `command_digest`, and exact committed family reconstruction. It returns the original timestamp and projection and reruns no transient or attested relation.

After commit uncertainty, automatic retry is forbidden. A fresh valid writer session invokes the appropriate recovery wrapper.

Recovery classifications are exactly:
```
committed_exact
definitely_not_committed
unresolved
```

For evidence admission:

- `committed_exact` requires exact receipt, membership, registry/typed payload, relation set, operands, graph digest, result projection, and receipt digest.
- `definitely_not_committed` requires absence of both the receipt and all operation-owned rows keyed by the preassigned membership/relation identities.
- A reusable registry or typed value may pre-exist and does not by itself defeat absence.
- Any receipt mismatch, partial membership family, relation fragment, alias, or unprovable cleanup yields `unresolved`.

For phase establishment, the equivalent proof uses the receipt, phase identity, K8 locator, phase relation attestation, and result graph.

Finite-failure recovery verifies the admitted reason and attestation graph. It never synthesizes `RW0WireProtocolError`.

# Error and conflict algebra

Semantic/idempotency/CAS outcomes are returned as the private `RW0C1ConflictV1`. Its closed reasons are:
```
stale_writer_token
mutation_ref_reuse
phase_identity_collision
k8_collision
current_state_conflict
member_identity_collision
member_already_admitted
missing_prerequisite_member
relation_failure
relation_identity_collision
owner_row_missing
```

The required spellings are exact. No `_reused` or `_reuse_conflict` variants are permitted.

Preflight uses private content-free reasons:
```
invalid_command
invalid_value
invalid_recovery_probe
```

Operational failures are raised as the existing safe `SQLiteMutationStoreError` classes:
```
database_integrity_failure
mutation_failed
commit_outcome_unknown
```

Closed/process-mismatched/concurrent writer-session failures retain the existing `WriterSessionError` vocabulary and occur before C1 SQL. A stale durable writer is disclosed only as `stale_writer_token`; it carries no receipt, key-existence, collision, or replay detail.

# Exact causal touched-file ledger

The exact `must_change` count is **81**:
```
27 documentation/root paths
11 production/migration paths
43 test paths
```

There is no conditional set.

Documentation/root paths:
```
AGENTS.md
README.md
.docs/architecture.md
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/b3-tests-only-coherent-fixtures.md
.docs/b3-transition-persistence-contract.md
.docs/b3c0a-transition-authority-and-order.md
.docs/b4c-public-global-stop-delegation.md
.docs/c2a-first-slice-semantic-protocol-contract.md
.docs/c2b-durable-development-state.md
.docs/c2b2-migration-0002.md
.docs/c2b2-private-readers.md
.docs/durable-state-model.md
.docs/rw0-b1-pure-phase-values.md
.docs/rw0-b2-capability.md
.docs/rw0-b2-wire-protocol.md
.docs/rw0-c1-durable-evidence.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/software-development-progression-boundary.md
.docs/sqlite-bootstrap-and-migrations.md
.docs/sqlite-operations-and-recovery.md
.docs/sqlite-schema-v1.md
.docs/sqlite-state-backend-adr.md
.docs/sqlite-threat-model.md
.docs/worker-execution-boundary.md
.docs/writer-session-authority.md
```

Production/migration paths:
```
src/ge_nwp_coordinator/_rw0_c1_semantic_values.py
src/ge_nwp_coordinator/_rw0_c1_row_values.py
src/ge_nwp_coordinator/_rw0_c1_mutation_contracts.py
src/ge_nwp_coordinator/_sqlite_rw0_c1_reader_contracts.py
src/ge_nwp_coordinator/_sqlite_rw0_c1_readers.py
src/ge_nwp_coordinator/_sqlite_rw0_c1.py
src/ge_nwp_coordinator/sqlite_transition_select_support.py
src/ge_nwp_coordinator/sqlite_transition_transaction.py
src/ge_nwp_coordinator/sqlite_writer_session.py
src/ge_nwp_coordinator/sqlite_migration.py
src/ge_nwp_coordinator/sqlite_migrations/0004_rw0_c1_durable_evidence.sql
```

Test paths:
```
tests/b3_coherent_transition_fixture.py
tests/test_architecture_contracts.py
tests/test_autonomous_software_development_operating_model.py
tests/test_b2a_writer_session_contract.py
tests/test_b3_coherent_transition_fixture.py
tests/test_b3a_persistence_contracts.py
tests/test_b3b1_pure_row_contracts.py
tests/test_b3b2b_select_readers.py
tests/test_b3b_reader_prerequisite_contracts.py
tests/test_b3c0a_transition_authority_contract.py
tests/test_b3c0b_transition_event_replay_contracts.py
tests/test_b3c1_prerequisite_contract.py
tests/test_b3c1b_rollback_only_writer_fencing.py
tests/test_b3c3_prerequisite_contract.py
tests/test_b3c4c_prerequisite_contract.py
tests/test_b4c_public_global_stop_delegation.py
tests/test_c2a_nonimplementation.py
tests/test_c2b0_durable_state_contract.py
tests/test_c2b2_development_reader_contracts.py
tests/test_c2b3c_author_effect_contract.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_runtime_non_authority.py
tests/test_rw0_b1_boundaries.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_software_development_progression_boundary.py
tests/test_sqlite_b1_migrations.py
tests/test_sqlite_b2c_writer_session.py
tests/test_sqlite_backend_b0_contract.py
tests/test_sqlite_c2b1_migration_framework.py
tests/test_sqlite_c2b2_migration_0002.py
tests/test_sqlite_section41_migration_0003.py
tests/test_worker_execution_semantic_boundaries.py
tests/test_rw0_c1_semantic_values.py
tests/test_rw0_c1_row_values.py
tests/test_rw0_c1_reader_contracts.py
tests/test_rw0_c1_private_readers.py
tests/test_rw0_c1_mutation_contracts.py
tests/test_rw0_c1_private_atomic_persistence.py
tests/test_rw0_c1_recovery.py
tests/test_rw0_c1_writer_session_delegation.py
tests/test_sqlite_rw0_c1_migration_0004.py
```

The three paths newly added relative to the prior 78-path ledger are causally required:

- `sqlite_transition_transaction.py`
  - Current assertion: it contains no C1 methods or wrappers and is the only controller/lifecycle owner.
  - Intended change: add the four C1 operation methods, four transaction methods, four wrappers, and controller-owned C1 plan execution.
  - Owner: Coordinator mutation transaction authority.
  - Omission failure: C1 has no legal connection/transaction/commit/recovery path.
- `sqlite_transition_select_support.py`
  - Current assertion: `_perform_select_fetch_bounded` admits only `(2, 16, 257, 258)`.
  - Intended change: admit exactly `(2, 3, 15, 16, 257, 258)`.
  - Owner: common nominal-capability SELECT lifecycle.
  - Omission failure: exact relation and operand overflow readers fail before borrowing the capability.
- `tests/test_b3c4c_prerequisite_contract.py`
  - Current assertion: it pins `sqlite_transition_transaction.py` to SHA-256 `287ac95a139ae8a1438dc71fc9e5ae91ca4282cd0287c44d5bc8344b20fec9ae`.
  - Intended change: pin the implemented source and prove one controller with the four C1 operation/wrapper pairs and no second authority.
  - Owner: existing controller-source freeze contract.
  - Omission failure: the source-hash assertion fails immediately.

`tests/test_c2b2_development_reader_contracts.py` was already in the 78-path set. Its development-query-spec limits remain `(2,257)`, but its shared-helper invalid matrix must stop treating exact integer `3` as invalid; the new C1 tests positively prove `3` and `15`.

All tracked repository paths outside the 81-path `must_change` set are `protected`. The directly inspected sensitive protected subset includes:
```
src/ge_nwp_coordinator/__init__.py
src/ge_nwp_coordinator/state_store.py
src/ge_nwp_coordinator/sqlite_errors.py
src/ge_nwp_coordinator/sqlite_mutation_transaction_contracts.py
src/ge_nwp_coordinator/sqlite_connection.py
src/ge_nwp_coordinator/sqlite_security.py
src/ge_nwp_coordinator/state_authority_lock.py
src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
src/ge_nwp_coordinator/_worker_execution_semantic_values.py
src/ge_nwp_coordinator/_sqlite_development_program_initialization.py
src/ge_nwp_coordinator/_sqlite_development_author_effect_establishment.py
src/ge_nwp_coordinator/_sqlite_development_pre_execution_plan_disposition.py
src/ge_nwp_coordinator/sqlite_migrations/0001_initial.sql
src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql
src/ge_nwp_coordinator/sqlite_migrations/0003_cognitive_proposal_and_selection_state.sql
tests/test_b3b2a_read_scope_and_query_contracts.py
tests/test_b3c1a_writer_session_authority.py
tests/test_b3c2_transition_event_readers.py
tests/test_b3c3_rollback_only_transition_dry_run.py
tests/test_b3c4a_transition_write_contracts.py
tests/test_b3c4b_private_atomic_transition_persistence.py
tests/test_b3c4c_public_transition_delegation.py
tests/test_b4a_global_stop_readers.py
tests/test_b4b_private_atomic_global_stop_persistence.py
tests/test_c2b2_private_development_readers.py
tests/test_c2b3_private_atomic_program_initialization.py
tests/test_c2b3d_private_atomic_author_effect_establishment.py
tests/test_section41_private_atomic_pre_execution_plan_disposition.py
```

Their assertions remain scoped to their existing families, one-controller existence, public transition/global-stop delegation, or the unchanged eight-file direct-`sqlite3` importer inventory. Adding C1-specific names does not require widening those assertions.

# Findings and contradictions

The reconciliation closes all five contradictions:

1. Membership has an independent stable ref/digest in SQL and every command/result/receipt/recovery/C2 seam.
2. C1 operands reference an exact same-phase membership, not only the global registry.
3. Rank 14 represents present result, finite failure, and absence; rank 13 contains no undefined failure variant.
4. Member relation count is at most two, with `LIMIT 3`.
5. The existing controller is explicitly changed and remains the sole transaction authority.

The sealed Wire error creates a deliberate admission-attestation branch, not an owner contradiction. No owner API, privacy boundary, decomposition decision, table count, or C2 responsibility must change.

# Forecasts and stop conditions

Implementation must stop and reopen the freeze if any of these becomes necessary:

- a second connection, controller, capability constructor, or commit path;
- importing `_ERROR_TOKEN` or fabricating `RW0WireProtocolError`;
- persisting a complete capsule manifest or capsule-entry material;
- admitting a C1 dependency not already present in the same phase;
- grouped admission;
- more than two member relations or more than 14 operands;
- public `WriterSession`, `StateStore`, or package widening;
- a C2 decision, completeness row, terminal result, or latch mutation;
- modification of migrations 0001–0003;
- a migration generation increase or non-zero migration-0004 seed;
- an implementation change outside the exact 81-path set;
- baseline drift from the verified commit/tree.

A commit-attempt exception remains `commit_outcome_unknown`; only explicit recovery under a fresh valid writer may classify it.

# Recommendation

The corrected contract is internally consistent and implementable without violating owner, privacy, transaction, or decomposition boundaries.

Proceed only as a separately authorized C1 implementation tranche using the exact 81-path allowlist. Do not combine it with C2 or any external-contact capability.

# Next implementation boundary

The next boundary is migration-0004 C1 only:

- private values and rows;
- 23 additive immutable tables;
- membership and same-phase relation integrity;
- private readers;
- one-controller phase/evidence persistence and recovery;
- private concrete writer-session delegation;
- documentation and finite product tests.

C2 completeness, cancellation-control recomputation, decisions, closure, terminal outcomes, latch mutation, public APIs, worker/runtime behavior, and external contact remain outside that boundary.

REPOSITORY\_MUTATION\_NOT\_PERFORMED\
TESTS\_NOT\_RUN\
STAGING\_NOT\_PERFORMED\
COMMIT\_NOT\_PERFORMED\
PUSH\_NOT\_PERFORMED\
PR\_NOT\_CREATED\
REMOTE\_CONTACT\_NOT\_PERFORMED\
WORKER\_OR\_MODEL\_NOT\_INVOKED\
SUPPORTING\_REPOSITORIES\_NOT\_MODIFIED\
IMPLEMENTATION\_NOT\_PERFORMED

RW0\_C1\_IMPLEMENTATION\_CONTRACT\_READY
