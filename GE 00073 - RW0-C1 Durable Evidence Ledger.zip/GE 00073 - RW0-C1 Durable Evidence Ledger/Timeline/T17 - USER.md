Uploaded snapshot to project sources.
