# Decision

**Proceed with a second bounded findings-repair tranche. Do not stage or commit RW0-C1 yet.**

The fresh re-audit passed provenance and reconfirmed the repaired candidate’s exact 81-path identity, mode posture, migration schema, focused validation, clean reconstruction, and authority boundaries. It then reproduced three remaining candidate defects and one permanent-test defect. :chatgpt-content-reference{index="0"}

This is **not** another C1 architecture or schema reset. Migration `0004`, the 15-kind model, privacy boundary, temporal model, public surface, and C1/C2 decomposition remain intact.

## Residual defects

### 1. Commit uncertainty still ends too early

After a real successful commit, failures can still escape during:

- committed-result publication;
- controller return;
- module-wrapper return;
- outer operation retirement and writer cleanup.

Those paths returned `mutation_failed`, `database_integrity_failure`, or raw `RuntimeError`, even though selector-based recovery proved that the mutation had committed. :chatgpt-content-reference{index="1"}

The repair needs one private cross-layer **commit-close witness**. The uncertainty window must begin immediately before the sole commit attempt and remain open until the outer writer-session close proof has completed. Any ordinary failure within that window must become:

```text
commit_outcome_unknown
```

This is an in-memory private control mechanism, not durable state or public API.

### 2. `definitely_not_committed` still misses durable identity routes

The re-audit produced false DNC results for:

- a typed payload using another ref but the selector’s unique value digest;
- a rank-1 child-only fragment with both parent rows absent;
- a relation operand using the deterministic operation relation ref under a foreign phase.

The same early-return structure also affects rank-12 child rows. :chatgpt-content-reference{index="2"}

The recovery owner must independently probe:

```text
typed payload by ref
typed payload by digest
rank-1 children by ref and digest
rank-12 children by ref and digest
relation binding by global relation_ref
relation operands by global relation_ref
```

A phase-filtered operand lookup is insufficient because the operation relation ref is itself the durable global identity.

Only complete absence—or an exact reusable registry, payload, and child family—may support DNC. Aliases, child-only rows, partial families, or foreign-phase relation fragments must return:

```text
unresolved
```

### 3. Recovery cleanup can escape its three-result algebra

Recovery has no commit attempt, so its cleanup failure should not become `commit_outcome_unknown`. But a cleanup failure after a recovery result is computed also cannot escape as a raw exception or unrelated store error.

The re-audit reproduced mutation-lease and operation-lease cleanup faults escaping as `database_integrity_failure` and `RuntimeError`. :chatgpt-content-reference{index="3"}

Once a recovery disposition has been computed, an ordinary cleanup failure before the full close proof succeeds must yield:

```text
unresolved
```

Primary process-control and pre-result failure precedence must remain unchanged.

### 4. Permanent tests omit all three blind spots

The repository suite currently lacks causal coverage for:

- controller and module return failures after commit;
- outer safe-cleanup variants;
- payload digest aliases;
- child-only rank-1/rank-12 fragments;
- wrong-phase global relation operands;
- recovery mutation/operation-lease cleanup faults. :chatgpt-content-reference{index="4"}

That explains why the 5,177-node suite remained green despite the defects. The fresh re-audit correctly withheld complete-suite execution after establishing deterministic High and Medium blockers. :chatgpt-content-reference{index="5"}

## Scope

The repair remains bounded to a maximum of **19 paths**:

```text
4 documentation paths
6 private production paths
9 test paths
```

Protected from change:

- migration `0004` SQL and catalog metadata;
- all row/table schemas;
- B1, Wire, Capability, C2A, C2B, and Section 41 owners;
- migrations `0001`–`0003`;
- package exports and `StateStore`;
- public `WriterSession` protocol;
- every other candidate path.

The repair must begin with tests against the current source, producing deterministic red failures for the residual routes before production changes.

## Codex handoff

Send this prompt to the **original workspace-write RW0-C1 implementation conversation**:

:chatgpt-content-reference{index="7"}[Download the fresh re-audit findings-repair prompt](sandbox:/mnt/data/Coordinator_RW0_C1_Fresh_Reaudit_Findings_Repair_Prompt.txt)

```text
Filename:
Coordinator_RW0_C1_Fresh_Reaudit_Findings_Repair_Prompt.txt

Size:
19,940 bytes

SHA-256:
aff6af4d624275ab10a73e6c5a9e8f395ea8c4678168e2fb4db1b905022b4c81
```

The required result is:

```text
COORDINATOR_RW0_C1_REAUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

After that result, start another **fresh read-only independent audit**. Do not resume the current re-audit root, and do not stage or commit before acceptance.

## Current status

```text
RW0-C1:
implemented, twice repaired, still independently blocked

Migration/schema/privacy architecture:
not reopened

Commit/push/PR gate:
closed

RW0-C2:
not implemented

RW0-D:
not implemented

RW0-E:
not implemented
```

### Source

- Fresh independent re-audit report. :chatgpt-content-reference{index="6"}

**Confidence:** High that all four findings are real and bounded; high that no schema or architecture replan is required; medium-high that the 19-path repair ceiling is sufficient, subject to the opening source-hash and controller-inventory checks required by the prompt.
