# Engineering recommendation

**Decompose RW0-C into two durable tranches: C1 and C2.**

- **RW0-C1 — durable phase/evidence ledger:** establish one receipt-backed no-contact RW0 phase instance, ingest immutable privacy-safe supplied claims and observations, bind them exactly to the current phase lineage, and provide exact replay, conflict, readback, and commit-uncertainty recovery.
- **RW0-C2 — durable semantic closure:** close branch-specific evidence snapshots, commit the unchanged C2B progression decision, atomically consume the one-way latch only with a productive direct-local `accept` decision, then commit a separate RW0 terminal-outcome fact with exact recovery.

This is the smallest non-disposable decomposition. C1 is independently useful to D and E; C2 turns that durable evidence substrate into Coordinator-owned semantic progression and terminal closure. A single C tranche would combine two materially different authority and transaction problems. More than two top-level tranches would create intermediate gates without an independently useful product capability.

The uploaded merged Coordinator snapshot is the baseline for this decision. 

---

## 1. Observable RW0-C result

At the end of RW0-C, the following durable ability should exist:

> Given the already-selected VS1B/C2B3D/Section 41 lineage and a finite set of supplied fake observations, a freshly acquired guarded Coordinator writer can survive restart and deterministically converge to either:
>
> - one durable RW0 terminal outcome bound to one exact C2B decision and one exact closed evidence snapshot; or
> - a durable blocked/unresolved state that permits no new RW0 effect or successor.
>
> It does so without contacting a verifier, custodian, worker, host, provider, or Execution Substrate.

The observable result is not merely that rows exist. A private reader should be able to show, for one RW0 phase instance:

1. the exact phase-entry claim and current lineage it bound;
2. every immutable supplied evidence member accepted into that phase;
3. replay/conflict disposition for every mutation;
4. the exact evidence snapshot used by a C2B decision;
5. the decision and, for `accept`, the latch postimage committed atomically with it;
6. the separate terminal evidence snapshot and terminal outcome;
7. whether recovery concluded `committed_exact`, `definitely_not_committed`, or `unresolved`.

This creates the first durable bridge from current pre-execution selection to semantic decision and RW0 terminal closure. The target already distinguishes these facts: a C2B decision is not the terminal outcome, and only the productive direct-local accept decision mutates the latch; the later terminal fact merely binds its postimage. (`.docs/rw0-remote-worker-contact-phase-entry.md:124-143`, `381-403`)

### Still blocked until RW0-D

RW0-C must not implement:

- custody storage or bearer issuance;
- physical retrieval or consumption;
- transport or delivery;
- process launch, process groups, deadlines, signals, reap, or teardown;
- actual worker observations;
- capsule building or storage;
- actual validation/review/model invocation;
- cancellation-request delivery;
- direct-local supervisor or adapter behavior.

D may later produce those source facts and submit their safe values through C’s durable ingest contracts. D remains the physical-mechanics owner. (`.docs/rw0-remote-worker-contact-phase-entry.md:180-245`, `274-306`)

### Still blocked until RW0-E

RW0-C must not claim:

- authenticated external verifier identity;
- live grant authenticity;
- real host qualification;
- credential or account suitability;
- live provider/mechanism proof;
- authorization for one actual qualified-host contact.

E owns the separately authorized live proof. Capability and B1 values remain supplied claims until then. (`.docs/rw0-b2-capability.md:7-20`, `264-269`, `329-332`)

---

# 2. Decomposition

## RW0-C1 — Durable phase entry and evidence membership

C1 should deliver a complete private durable mutation/read/recovery capability for:

- one immutable RW0 phase-entry instance bound to the exact `RW0PhaseEntryBasisV1`;
- receipt-backed creation before any external contact;
- immutable typed evidence-member ingest;
- exact phase/evidence bindings;
- source kind, invocation, evidence ref/digest, schema identity, semantic ref/digest, and freshness coordinates;
- exact idempotency, replay, and same-key/different-digest conflict;
- collision rejection;
- guarded private readback;
- commit-uncertainty recovery;
- privacy-safe canonical projections only;
- no evidence completeness claim;
- no C2B decision;
- no terminal outcome;
- no latch mutation.

### C1 must own evidence membership, not completeness

C1 should answer:

```text
Which exact evidence members were durably admitted for this RW0 phase?
```

It should not answer:

```text
Is the evidence complete enough for a decision or terminal outcome?
```

An evidence member is a durable claim with a source and identity. Membership does not make the claim authentic, current enough for every branch, mutually complete, or semantically sufficient.

This boundary is already implied by Capability: RW0-C owns collection, conflict, durable membership, and completeness, while the pure Capability relation qualifies one supplied observation at a time. (`.docs/rw0-b2-capability.md:94-99`, `264-269`)

### C1’s non-disposable value

C1 is not a temporary schema scaffold. D and E will later write the same kinds of safe observations through the same receipt, idempotency, replay, readback, and recovery boundary. Only their source provenance and physical production will change.

### Migration recommendation

The target should be:

```text
migration 0004:
C1 only
```

It should not pre-create C2 terminal, decision-closure, or latch representation merely because those tables are known to be future work. That would make C1 partly a representability milestone rather than a durable capability.

---

## RW0-C2 — Durable decision and terminal closure

C2 should consume C1’s durable evidence members and implement two distinct guarded mutation families inside one phase-level tranche.

### C2 operation A — decision-basis closure and decision commit

Atomically:

1. reconstruct the current phase and heads;
2. select and close the exact evidence members used for the progression decision;
3. validate the branch-specific completeness profile;
4. commit one unchanged C2B decision;
5. for productive direct-local `accept`, consume the one-way latch in the same transaction;
6. commit a receipt and deterministic result projection.

For every non-accept decision, the latch remains unchanged.

### C2 operation B — terminal evidence closure and outcome commit

Separately:

1. read back the committed decision;
2. close the terminal evidence snapshot;
3. validate `RW0TerminalOutcomeV1` through its owning B1 relation;
4. commit one separate durable terminal-outcome fact;
5. for terminal `accept`, bind the already-committed latch postimage;
6. never mutate the latch;
7. commit a separate receipt and result projection.

This operation must remain separately recoverable because a decision may commit while the terminal-outcome commit remains uncertain.

### Revision to the provisional “one evidence-set closure” model

C2 should **not** use one evidence closure for the entire phase.

It needs at least two immutable closure roles:

```text
decision_basis
terminal_basis
```

They may share many members, but they are causally different:

- the decision basis is closed at decision time;
- the terminal basis includes later branch-specific terminal facts;
- active cancellation necessarily has evidence that does not exist when the pre-effect cancel decision commits.

For a normal branch, the decision and terminal snapshots may be nearly identical, but their identities and causal moments remain distinct.

### Active-cancel handling

C2 owns the durable semantic sequence, using supplied fake source facts:

```text
pre-effect C2B cancel decision
→ current-basis recheck
→ durable cancel-effect intent/fence/delivery facts if still valid
→ supplied request/ack/signal/exit/teardown/reconciliation facts
→ terminal cancel or terminal block
```

C2 does not deliver the request or control a process. Those are D actions.

The required branch rules remain:

- unusable pre-effect cancel basis → terminal `block`, no replacement decision;
- complete and unambiguous post-teardown reconciliation → terminal `cancel`;
- incomplete, contradictory, stale, or ambiguous reconciliation → terminal `block`;
- no second cancel decision;
- no C2B block decision on the unresolved post-teardown branch.

These rules are already frozen in the RW0 owner. (`.docs/rw0-remote-worker-contact-phase-entry.md:124-139`, `296-306`, `325-330`)

### Why C2 is one tranche, not C2a/C2b

Decision and terminal persistence are separate transactions and mutation families, but they should remain one top-level tranche because the non-disposable capability is restart-safe semantic closure. Shipping only decision persistence without terminal recovery would leave a deliberately incomplete RW0 product boundary.

### Migration recommendation

The target should be:

```text
migration 0005:
C2 decision evidence closure
C2 terminal evidence closure
acceptance latch
terminal outcome
their receipts and recovery support
```

Both 0004 and 0005 should remain non-destructive. The current migration framework already supports multiple migrations at application generation 2, but the exact application-generation treatment must be revalidated during reconnaissance. Current production stops at migration 0003. (`src/ge_nwp_coordinator/sqlite_migration.py:31-39`, `336-367`)

---

# 3. Action-specific prerequisites

| Prerequisite | Exact action blocked | Status | Must be settled |
|---|---|---|---|
| Exact reconstruction of VS1B, C2B3D, Section 41 K8/L34, current effect/delivery heads, path scope, and global stop | Creating the C1 phase-entry claim | **Owning contracts established** in current B1 and current durable readers | Before C1 |
| C-owned phase-instance identity, command, receipt, replay/conflict grammar | Any phase-entry persistence or recovery | **Missing C durable design** | Before C1 |
| Closed inventory of evidence-member kinds and their safe durable projections | Typed C1 ingest | B1/B2 semantic values exist, but **durable inventory is missing** | Before C1 |
| Private readers for phase, member, receipt, and recovery probes | Observable C1 result and exact readback recovery | **Missing implementation contract** | Before C1 |
| External verifier authenticity | Treating an authority claim as real executable permission or making live contact | **Missing external evidence/infrastructure**; not required to record a supplied claim | Before E; not before C1 |
| Custody availability relation | Admitting a custody claim as semantically coherent | **B1 contract established** | Before C1 ingest |
| Physical custody store and bearer issuance | Actual retrieval/redemption/consumption | **Missing physical mechanism** | Before D |
| Retrieval event sequence semantics | Admitting supplied fake issued/redeemed/consumed facts | **B1 contract established** | Before C1 |
| Physical bearer movement and revocation enforcement | Actual one-use retrieval | **Missing D mechanism** | Before D |
| B2 Capability declaration/observation/qualification | Recording and evaluating a mechanism claim | **Merged owner contract established** | Before C1 |
| Authentication of Capability observer or declaration author | Treating Capability qualification as physical proof | **Explicitly absent by contract** | Before D/E |
| B2 Wire request/process/result values and relations | Recording coherent supplied process/cancellation facts | **Merged owner contract established** | Before C1 for fake ingest |
| Physical frame transport, process attribution, supervisor truth | Treating Wire facts as real runtime observations | **Missing D/ES evidence** | Before D/ES |
| Evidence membership | Selecting durable members for a phase | **C1 responsibility** | Before C2 |
| Branch-specific completeness grammar | Closing a decision or terminal evidence snapshot | **Missing C2 owner contract** | Before C2 |
| Existing C2B decision grammar | Committing progression decisions | **Established and unchanged**; kinds remain `initialize`, `accept`, `repair`, `replan`, `terminal_reject`, `block`, `redeliver`, `cancel` | Before C2; no owner change |
| Private C2B decision mutation runtime for post-execution branches | Committing the decision | Schema/value grammar exists; **runtime is missing** | Before C2 |
| Durable terminal-outcome row/value/receipt representation | Terminal closure | B1 value/relation exists; **durable representation is missing** | Before C2 |
| One-way acceptance-latch representation | Productive direct-local `accept` | Semantics established; **schema and transaction are missing** | Before C2 |
| Decision+latch atomicity | Accept decision | **Hard invariant from owner contract** | Before C2 |
| Terminal-outcome binding without latch mutation | Terminal accept | **Hard invariant from owner contract** | Before C2 |
| Pre-effect cancel decision and basis recheck | Establishing a cancel effect or closing unusable-basis branch | Decision grammar and target semantics established; runtime missing | Before C2 |
| Request/ack/signal/exit/teardown authenticity | Real cancellation terminal truth | Missing physical D facts | Before D; C2 uses supplied fake facts only |
| Receipt-first exact replay | Any C1/C2 mutation retry | Current transaction pattern established, new family probes missing | Before each tranche |
| Three-way recovery: exact committed / definitely absent / unresolved | Retrying after commit uncertainty | Current pattern established, new family completeness predicates missing | Before each tranche |
| No duplicate decision, terminal fact, or latch mutation | Recovery after uncertain commit | C2-specific invariant | Before C2 |
| No public C1/C2 caller before D/E | Preventing supplied fake claims from becoming an accidental production runtime | **Proposed engineering precaution**, consistent with current private boundaries | Before C1 and C2 |
| One migration per independently useful durable tranche | Avoiding disposable precreated C2 schema in C1 | **Proposed engineering decision** | Freeze before C1 |

### Authenticity versus recording

A C1 row may safely mean:

```text
source X supplied claim Y with semantic digest Z
```

It may not mean:

```text
claim Y is authentic or grants permission
```

C2 may exercise its full durable logic in private tests using coherent supplied fake values. Until D/E provide authenticated source facts and a production caller, that result remains a durable semantic proof, not authority to contact, execute, publish, or perform Git effects.

---

# 4. B1/B2 reuse

No merged B1 or B2 identity change is currently required.

## B1 values C1 must reuse

1. `RW0PhaseEntryBasisV1`
2. `RW0AuthorityVerificationObservationV1`
3. `RW0SubordinateAuthorizationProposalV1`
4. `RW0CustodyAvailabilityObservationV1`
5. `RW0RetrievalCapabilityEventObservationV1`
6. `RW0RemoteHostReadinessObservationV1`
7. `RW0EffectHostQualificationV1`

The exact ordered fields and identity rules are already frozen. (`.docs/rw0-b1-pure-phase-values.md:65-147`)

## B1 relations C1 must reuse

- `validate_phase_entry_basis`
- `validate_authority_observation`
- `validate_per_fence_basis`
- `validate_external_common_family_claim`
- `validate_subordinate_narrowing`
- `validate_custody_binding`
- `validate_retrieval_event_sequence`
- `validate_host_qualification`

The relation inventory and budgets are already owned by B1. (`.docs/rw0-b1-pure-phase-values.md:184-200`, `235-349`)

C must call the owning relations; it must not duplicate their logic in SQL triggers or durable writers.

## B1 value/relation C2 must reuse

- `RW0TerminalOutcomeV1`
- `validate_terminal_outcome_binding`
- the owning branch-shape validators:
  - normal;
  - active-cancel reconciled;
  - active-cancel unresolved;
  - pre-effect cancel basis unusable.

The terminal binding already requires the exact decision, current program/work/selection/effect/delivery heads, global stop, evidence-set pair, optional latch postimage, reconciliation pair, and mismatch pair. (`src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py:2155-2241`)

## Capability values and relation

C1 should persist safe identities/projections for:

- `RW0WorkerMechanismCapabilityDeclarationV1`
- `RW0WorkerMechanismCapabilityObservationV1`
- `RW0WorkerMechanismCapabilityQualificationV1`

and invoke:

- `validate_worker_mechanism_capability_qualification`

C must retain the existing fixed Wire profile ref/digest. It must not store or reproduce the Wire profile manifest as C authority. (`.docs/rw0-b2-capability.md:22-148`, `150-229`)

## Wire values and relations

C1 is expected to reuse, where the branch reaches them:

- `RW0WireCancellationRequestObservationV1`
- `RW0WireProcessObservationV1`
- `RW0WireWorkerResultV1`
- `RW0WireProcessResultClassificationV1`
- `validate_wire_cancellation_request_relation`
- `validate_wire_process_observation_relation`
- `validate_wire_result_relation`
- `classify_wire_process_result`

C may use the owning frame decoder at an ingest boundary, but raw Wire frames must not become durable progression truth. Durable state should bind reconstructed semantic values and their identities. Physical framing, streams, and transport remain D/ES-owned.

## Downstream semantic churn rule

Any implementation need that would change one of the following is **not** an ordinary C compatibility repair:

- a B1 or B2 schema ID;
- ordered fields;
- canonical bytes or digest domain;
- finite enum meaning;
- relation signature or precedence;
- fixed Wire profile ref/digest;
- B1/B2 authority ownership;
- C2B decision kind or variant meaning.

Such a need must stop implementation and reopen the owning B1/B2/C2B contract.

New C-owned facts—phase instance, evidence membership, evidence closure, latch row, terminal row, receipts, recovery probes—should be added alongside the merged values, not pushed into them.

---

# 5. Assurance architecture

## Permanent repository tests

Permanent tests should prove finite product claims.

| Product claim | Permanent evidence |
|---|---|
| C1 schema is closed, non-destructive, and contains no raw private material | Literal migration/schema manifest; forbidden-column and trigger tests |
| Phase-entry is committed before any observation ingest | Transaction-order and foreign-key/graph tests |
| Evidence membership is immutable and typed | Row-value tests, append-only triggers, exact member-kind inventory |
| A supplied claim is not elevated to authenticity | Relation/status tests and no-public-caller/import tests |
| Same command replays exactly | Receipt-first replay fixtures |
| Same idempotency key with different digest conflicts | Explicit conflict tests |
| Partial or contradictory family cannot be “recovered” as committed | Recovery matrices |
| C1 readback is sufficient to reconstruct exact durable state | Private reader round-trip tests |
| Decision evidence closure is immutable | Exact ordered membership/digest tests |
| C2B decision grammar is unchanged | Existing row-value compatibility tests plus new writer tests |
| Accept decision and latch consumption are atomic | Transaction fault injection before/after each write and commit |
| Non-accept decisions do not change the latch | Complete decision-kind matrix |
| Terminal outcome is separate from decision | Separate tables, receipts, commands, and mutation families |
| Terminal outcome never mutates the latch | Before/after latch assertions across every branch |
| Active cancel creates no second cancel or block decision | Branch-specific graph and receipt tests |
| Commit uncertainty produces no duplicate decision/outcome/latch mutation | Fresh-writer three-way recovery tests |
| C performs no external I/O | Static import/effect boundary tests |
| C remains private | Package export and production-caller inventories |
| Privacy-safe state only | Hostile-value and database-row scans |

Tests should be ordinary, finite contract tests. They should not authenticate their own code, AST, fixtures, globals, or mutation framework.

## Independent audit

Independent audit should own:

- exact patch and migration byte identity;
- migration from every supported prefix;
- schema-object and trigger diff;
- external one-predicate fault/mutation testing;
- transaction interruption around every write and COMMIT boundary;
- database corruption and partial-family probes;
- exact candidate and protected-path provenance;
- live/clean state validation;
- verification that permanent tests are causally meaningful.

Do not import the B2 G5–G18 self-protecting evidence architecture.

## Finding taxonomy

The next tranche should report findings distinctly:

| Class | Meaning |
|---|---|
| Candidate defect | Implemented C behavior violates an accepted contract |
| Contract defect | Owning docs or contracts are contradictory, incomplete, or assign authority incorrectly |
| Test/oracle defect | Checked tests do not causally prove their stated product claim |
| Audit-harness defect | External audit tooling or evidence handling failed |
| Report defect | The report misstates otherwise valid source/evidence |
| Environment defect | SQLite/Python/filesystem/umask/runtime posture invalidates a run without proving a candidate flaw |

A finding in one class must not silently be promoted into another.

---

# 6. Forecasts and stop conditions

## Forecast 1 — one evidence closure will be insufficient

The first semantic contradiction is likely to be an attempted single “complete evidence set” for both the C2B decision and terminal outcome.

**Falsifier:** reconnaissance finds one immutable evidence snapshot that can correctly represent both the pre-effect cancel decision and the later post-teardown cancel/block outcome without adding facts after closure.

Otherwise, C2 needs separate `decision_basis` and `terminal_basis` closures.

## Forecast 2 — latch atomicity will force a C2-specific transaction family

The existing generic decision row grammar should remain sufficient, but productive accept will require a C2 writer that inserts the decision, consumes the latch, records its postimage, and commits one receipt atomically.

**Falsifier:** an existing implemented writer already provides that exact multi-row atomic and recovery contract without changing decision meaning.

If implementation proposes:

- latch mutation before or after the decision transaction;
- terminal-outcome-driven latch mutation;
- recovery that may repeat latch consumption;

stop and replan.

## Forecast 3 — two migration suffixes will be smaller than one monolith

Expect:

```text
0004:
C1 phase/evidence membership and recovery

0005:
C2 evidence closure, latch, decision runtime support, terminal outcome, recovery
```

Both are likely to remain application generation 2.

**Falsifier:** reconnaissance proves that C1 cannot be independently installed and operated without C2 schema, while still delivering a non-disposable durable capability.

Likely audit findings are:

- raw/private evidence accidentally stored;
- receipt replay that checks only a digest, not the complete family;
- “complete” evidence sets with missing branch members;
- accept/latch writes separated across transactions;
- terminal recovery that fabricates another decision;
- active-cancel block represented as a C2B block decision;
- commit-uncertainty recovery that treats partial rows as absence.

## Architectural replanning stop conditions

Stop rather than ordinary-repair if:

1. C requires a B1/B2 identity, field, relation, or profile change.
2. C requires a new C2B decision kind or reinterpretation.
3. C cannot separate evidence membership from completeness.
4. Accept and latch consumption cannot be one atomic transaction.
5. Terminal outcome cannot remain a separate fact and transaction.
6. Terminal persistence needs to mutate or repair the latch.
7. Active-cancel closure requires a second cancel decision or a C2B block decision.
8. Commit recovery cannot distinguish exact committed, definitely absent, and unresolved without speculative retry.
9. Any transaction requires external I/O.
10. A public/production caller is needed before D/E authenticity and physical proof exist.
11. C1 cannot remain independently useful without precreating most of C2.

---

# 7. Next step

## Acceptance boundary to carry forward

### C1 is complete when

A private, guarded, restart-safe API can:

- create one no-contact phase claim;
- ingest typed supplied fake evidence members;
- replay exactly;
- conflict deterministically;
- read back the exact phase and membership graph;
- resolve commit uncertainty without duplicate rows;
- expose no public/runtime caller;
- make no completeness, permission, decision, terminal, or latch claim.

### C2 is complete when

Using only C1 members and supplied fake facts, a private guarded writer can:

- atomically close decision evidence and commit one unchanged C2B decision;
- atomically consume the latch only with productive direct-local accept;
- separately close terminal evidence and commit one terminal outcome;
- model all normal and active-cancel branches;
- recover each uncertain transaction exactly;
- create no duplicate decision, terminal fact, or latch mutation;
- make no external contact, Git effect, publication, or successor launch.

## Unresolved owner seams

These remain open and need reconnaissance before an implementation freeze:

1. exact durable evidence-member kind inventory;
2. exact C1 phase identity and mutation-command grammar;
3. whether canonical safe mappings or only owner ref/digest projections are stored per kind;
4. branch-specific decision and terminal completeness profiles;
5. durable evidence-closure identity and ordered-membership algorithm;
6. latch row/postimage identity;
7. terminal-outcome row and receipt representation;
8. exact C2 writer operations that use the existing decision table;
9. whether current private readers can be extended or require new role-specific readers;
10. exact 0004/0005 schema, index, trigger, and application-generation treatment;
11. exact recovery-probe contents for each mutation family;
12. which cancellation/process observations can be persisted in C before D defines their physical source contracts.

Static snapshot inspection is enough for the phase decision, but a fresh read-only repository reconnaissance is still needed before freezing schemas, transaction commands, files, and tests.

---

# Read-only Codex reconnaissance prompt

```text
PROMPT_ID

RW0_C_PHASE_ARCHITECTURE_RECONNAISSANCE_V1

TITLE

Coordinator RW0-C — read-only reconnaissance for durable phase/evidence ingest
and semantic terminal closure

ENGAGEMENT TYPE

Read-only repository reconnaissance and architecture reconciliation.

Do not modify repository files.
Do not stage, commit, push, create a PR, merge, tag, release, or deploy.
Do not run migrations against a persistent database.
Do not contact a verifier, custodian, worker, provider, host, Execution
Substrate, Bridge, or supporting repository.
Do not issue an implementation prompt.

Print the complete substantive result inline in chat. Evidence files may be
supplementary only.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

EXPECTED BASELINE

Require current merged trunk_dev at the RW0-B2 Capability squash commit reported
by the parent conversation. Reconcile the exact live branch/HEAD/tree/upstream
before inspection and report any mismatch.

FROZEN PHASE DECISION

Treat these decisions as the strategic target to validate against repository
evidence:

1. RW0-C is decomposed into two non-disposable tranches.

2. RW0-C1 owns:
   - one receipt-backed no-contact RW0 phase instance;
   - immutable typed supplied-evidence membership;
   - exact phase/evidence bindings;
   - idempotency, replay, conflict;
   - guarded private readback;
   - commit-uncertainty recovery;
   - no completeness, C2B decision, terminal outcome, latch mutation, external
     contact, or public caller.

3. RW0-C2 owns:
   - immutable decision-basis evidence closure;
   - unchanged C2B decision persistence;
   - accept-decision/latch atomicity;
   - immutable terminal-basis evidence closure;
   - separate RW0 terminal-outcome persistence;
   - active-cancel semantic reconciliation using supplied fake facts;
   - exact replay and commit-uncertainty recovery;
   - no external contact, Git effect, publication, or successor launch.

4. Decision-basis closure and terminal-basis closure are distinct causal facts.

5. Only the productive direct-local accept decision mutates the latch, atomically
   in the decision transaction. Terminal accept binds the committed postimage
   and never mutates the latch.

6. Existing B1, RW0-B2-Wire, RW0-B2-Capability, C2A, Section 41, and C2B decision
   identities and meanings remain unchanged.

7. RW0-D owns physical custody, retrieval bearer mechanics, transport, worker,
   provider, supervisor, process, cancellation delivery, capsule, and offline
   proof.

8. RW0-E owns the separately authorized live qualified-host proof.

PRIMARY OBJECTIVE

Determine whether the frozen C1/C2 split is compatible with the current merged
repository, and produce the exact contract freeze needed before implementation.

Do not accept a milestone defined only by schema representability.

REQUIRED INSPECTION

Read completely or in the relevant owning sections:

- AGENTS.md
- README.md
- pyproject.toml

- .docs/rw0-remote-worker-contact-phase-entry.md
- .docs/rw0-b1-pure-phase-values.md
- .docs/rw0-b2-wire-protocol.md
- .docs/rw0-b2-capability.md
- .docs/durable-state-model.md
- .docs/c2b-durable-development-state.md
- .docs/c2b2-pure-durable-row-values.md
- .docs/c2b2-private-readers.md
- .docs/c2b3-program-initialization.md
- .docs/sqlite-bootstrap-and-migrations.md
- .docs/sqlite-operations-and-recovery.md
- .docs/software-development-progression-boundary.md
- .docs/authority-boundaries.md
- .docs/worker-execution-boundary.md

- src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
- src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
- src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
- src/ge_nwp_coordinator/_worker_execution_semantic_values.py
- src/ge_nwp_coordinator/_development_decision_row_values.py
- src/ge_nwp_coordinator/_development_effect_row_values.py
- src/ge_nwp_coordinator/_development_program_row_values.py
- src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py
- src/ge_nwp_coordinator/_sqlite_development_reader_contracts.py
- src/ge_nwp_coordinator/_sqlite_development_readers.py
- src/ge_nwp_coordinator/_sqlite_development_program_initialization.py
- src/ge_nwp_coordinator/_sqlite_development_author_effect_establishment.py
- src/ge_nwp_coordinator/_sqlite_development_pre_execution_plan_disposition.py
- src/ge_nwp_coordinator/sqlite_migration.py
- src/ge_nwp_coordinator/sqlite_mutation_transaction_contracts.py
- src/ge_nwp_coordinator/sqlite_transition_transaction.py
- src/ge_nwp_coordinator/sqlite_writer_session.py
- src/ge_nwp_coordinator/state_store.py
- all packaged SQLite migration resources
- schemas/sqlite/coordinator-state-v1.sql

Inspect the direct tests for those owners, migration 0002/0003, private readers,
program initialization, author-effect establishment, Section 41 mutation,
commit recovery, B1, Wire, Capability, architecture, runtime non-authority, and
RW0 status.

QUESTIONS TO ANSWER

A. C1 durable contract

- What exact phase identity can be derived without changing B1?
- Which exact existing heads, refs, digests, and stop coordinates are required?
- What is the smallest closed evidence-member kind inventory?
- Which B1/B2 values have a durable safe projection suitable for C1?
- Which values must remain only referenced by ref/digest?
- What command, result, receipt, graph, and recovery-probe shapes are required?
- What exact replay and conflict keys are safe?
- Which private readers are required for observable readback and recovery?
- Can C1 be independently installed and useful without C2 tables?

B. C2 durable contract

- What exact evidence is required for each normal decision kind?
- What exact evidence is required for:
  - pre-effect cancel decision;
  - pre-effect cancel basis unusable;
  - active-cancel reconciled;
  - active-cancel unresolved?
- Confirm whether decision-basis and terminal-basis closures must be distinct.
- Can the unchanged development_decisions table/row grammar represent every
  required C2B decision?
- What new C-owned rows are needed for closure, latch, terminal outcome,
  receipts, and recovery?
- What exact transaction must contain accept decision plus latch mutation?
- What exact terminal transaction must exclude latch mutation?
- What exact three-way recovery predicates prove committed, absent, or
  unresolved without duplicate decisions or latch mutation?

C. Schema and migration

- Recommend exact 0004 and 0005 ownership, or report a concrete reason the split
  is impossible.
- Identify table, trigger, index, seed-row, application-generation, migration
  compatibility, and zero-seed implications.
- Do not select columns casually; classify each proposed durable fact by owner
  and privacy status.
- State whether any current schema/table can be reused without semantic
  overload.
- State where one authoritative mutable head or singleton is required.

D. Transaction and authority

- Map C1 and C2 onto the existing WriterSession, operation guard, mutation slot,
  transaction controller, receipt-first replay, and fresh-writer recovery
  contracts.
- Identify exact existing helpers that are reusable versus family-specific.
- Confirm no external I/O inside transactions.
- Confirm no public API or production caller before D/E.
- Confirm source authenticity is not inferred by persistence.

E. B1/B2 compatibility

Produce a complete reuse ledger for:

- all eight B1 values;
- all B1 relations;
- Capability declaration, observation, qualification, and relation;
- Wire cancellation request, process observation, worker result,
  classification, and owning relations;
- C2A values reached through those owners.

For every proposed need, state whether:
- current owner already supports it;
- a new C-owned durable fact suffices; or
- it would require downstream semantic churn in a merged owner.

Any owner churn is a stop condition, not an ordinary compatibility repair.

F. Acceptance evidence

For C1 and C2, map every permanent test to one finite product claim:

- schema;
- row/value identity;
- privacy;
- transaction ordering;
- idempotency;
- replay/conflict;
- commit uncertainty;
- recovery;
- completeness;
- decision binding;
- latch atomicity;
- terminal separation;
- cancellation branch;
- authority/nonimplementation.

Define the bounded independent-audit responsibilities. Do not introduce a
self-protecting test or evidence framework.

G. Scope

Return:

- recommended docs;
- migration resources;
- source modules;
- tests;
- protected files;
- maximum touched-file ceiling for C1;
- maximum touched-file ceiling for C2;
- likely integration/audit order.

Do not implement.

STOP CONDITIONS

Return ARCHITECTURAL_REPLAN_REQUIRED if inspection establishes any of:

- B1/B2/C2A identity or relation change is required;
- a new C2B decision kind or changed variant meaning is required;
- one evidence closure must serve incompatible decision and terminal moments;
- accept and latch cannot be one transaction;
- terminal outcome must mutate the latch;
- active-cancel closure requires a second cancel decision or C2B block decision;
- exact three-way recovery cannot be proven;
- external I/O is required inside a transaction;
- C1 is not independently useful;
- more authority would move into Coordinator, D, or E than the frozen split
  permits.

OUTPUT

Print inline:

# Baseline and inspection boundary
# Contract versus target
# C1 contract freeze
# C2 contract freeze
# Evidence membership and closure model
# Schema and migration recommendation
# Transaction and recovery model
# B1/B2/C2A reuse ledger
# Authority and privacy
# Acceptance evidence architecture
# Exact touched-file forecasts
# Findings and contradictions
# Forecasts and stop conditions
# Recommendation
# Next implementation boundary

End with exactly one:

RW0_C_PHASE_ARCHITECTURE_RECONCILED_READY

or

ARCHITECTURAL_REPLAN_REQUIRED

Required final statements:

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
```

---

## Inspection boundary

This decision is grounded in the merged snapshot’s docs and source. I inspected the RW0 owner, B1/B2 owners, current migration catalog, durable-state model, C2B decision grammar, and current transaction/recovery contracts. I did **not** run tests, execute migrations, or validate a live repository checkout. The reconnaissance prompt should re-ground against the live merged tree before any implementation freeze.

### Sources

- Uploaded merged Coordinator snapshot. 
- `.docs/rw0-remote-worker-contact-phase-entry.md:13-21, 94-147, 247-310, 313-353, 381-467`
- `.docs/rw0-b1-pure-phase-values.md:65-147, 184-200, 235-349`
- `.docs/rw0-b2-capability.md:7-20, 94-148, 178-269, 329-332`
- `.docs/durable-state-model.md:440-483, 539-558`
- `.docs/sqlite-operations-and-recovery.md:510-577`
- `src/ge_nwp_coordinator/sqlite_migration.py:31-39, 69-110, 336-367`
- `src/ge_nwp_coordinator/_development_decision_row_values.py:35-105, 620-735`
- `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py:2140-2241`

**Confidence:** High in the C1/C2 decomposition and authority split. Medium-high in the proposed 0004/0005 migration allocation pending exact live-schema and transaction-surface reconnaissance.
