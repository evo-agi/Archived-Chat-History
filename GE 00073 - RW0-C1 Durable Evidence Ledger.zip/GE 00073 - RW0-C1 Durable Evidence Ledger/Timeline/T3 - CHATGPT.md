## Engineering disposition

**Accept `ARCHITECTURAL_REPLAN_REQUIRED`. Do not begin RW0-C implementation.**

The C1/C2 decomposition still stands. The blocker is a **merged semantic-owner contradiction upstream of C**, not a flaw in the durable decomposition:

- The RW0 target permits cancellation of the exact current author, validation, or review effect, each with its own current effect, fence, and delivery. It also requires active-cancel terminal closure against that exact target. (`.docs/rw0-remote-worker-contact-phase-entry.md:118-138`)
- C2A already models a `cancel_effect` whose immutable target may be `author_candidate`, `validate_candidate`, or `review_candidate`, including capsule-bound validation/review targets. (`.docs/c2a-first-slice-semantic-protocol-contract.md:813-832`)
- Wire v1’s profile says the cancellation-request target is `author_candidate`; its request and process relations reject any other target class; its classifier repeatedly supplies the author fence as the cancellation target. (`src/ge_nwp_coordinator/_rw0_wire_protocol_values.py:893`, `955-984`, `1045-1071`, `1808-1845`)
- The current fixed Wire profile identity is directly pinned by tests. (`tests/test_rw0_b2_wire_values.py:464-479`)

C cannot reproduce or reinterpret those relations in persistence without stealing Wire ownership.

## What remains decided

The phase-level recommendation remains:

```text
RW0-C1:
durable phase establishment and immutable supplied-evidence membership,
with replay, conflict, private readback, and exact commit recovery

RW0-C2:
decision-basis closure, unchanged C2B decision persistence,
accept+latch atomicity, terminal-basis closure, separate terminal outcome,
active-cancel reconciliation, and exact terminal recovery
```

Decision and terminal evidence closures remain separate. Only the productive direct-local accept decision consumes the latch; the terminal fact binds its committed postimage without mutating it.

The existing C2B grammar remains adequate. No new decision kind is indicated.

## Scope of the block

**C2 is definitively blocked** because it cannot validate target-complete cancellation evidence for validation or review.

C1 is not conceptually impossible, but I recommend **deferring its implementation** until the B2 owner seam is frozen and merged. Starting C1 now would force one of two poor choices:

- encode a provisional closed evidence inventory that must immediately change; or
- make evidence admission overly generic and weaken the exact owner-validation boundary.

So the correct sequence is:

```text
B2 cancellation-owner reconciliation
→ independent audit and merge
→ rerun RW0-C reconnaissance
→ freeze C1
→ implement and merge C1
→ freeze and implement C2
```

This is strategic deferral, not abandonment of C1.

## Recommended pre-C target

The smallest likely repair is **additive**, preserving all current Wire v1 identities and behavior.

The preferred hypothesis for reconnaissance is:

- retain `rw0-wire-nwpf-v1`, its digest, values, relations, frames, classifier, tests, and Capability binding unchanged;
- add a separate versioned **cancellation-control evidence profile** under the Wire owner;
- reuse the existing cancellation-request and process-observation value schemas if their current field meanings suffice;
- add exact-current-target relations for author, validation, and review;
- require the exact capsule manifest when validation or review is the target;
- add a cancellation-control classifier concerned only with request, response, signal, process, exit, and control evidence;
- leave validation/review semantic result interpretation to C2A and eventual C2 closure;
- make no persistence, transport, process-control, authentication, or runtime claim.

A separate cancellation profile is preferable to replacing the full worker-protocol profile because Capability currently binds the fixed Wire owner pair through B1 readiness and host qualification. (`.docs/rw0-b2-capability.md:180-213`; `src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py:201-211`, `884-915`)

That preference still needs repository reconciliation. It is not yet an implementation decision.

## Next step

Send this **read-only architecture prompt** to the current Coordinator conversation:

:chatgpt-content-reference{index="1"}

```text
Filename:
Coordinator_RW0_B2_Exact_Current_Effect_Cancellation_Reconciliation_Prompt.txt

Size:
12,192 bytes

SHA-256:
6854b915fcdd4475864d1d911731faeb06ee1c12c98144cf131998cb1d58fe6e
```

It requires Codex to decide, before implementation:

- whether the current request/process values can be reused unchanged;
- whether the current classifier must remain v1-only;
- whether a separate cancellation profile avoids Capability churn;
- exact new relation operands and capsule requirements;
- the exact C1/C2 unblock ledger;
- the finite test and audit architecture;
- a bounded touched-file ceiling.

The successful result should be:

```text
RW0_B2_CANCELLATION_OWNER_RECONCILIATION_READY
```

No implementation prompt should be issued until that result is reviewed.

### Sources

- Current merged Coordinator snapshot. 
- `.docs/rw0-remote-worker-contact-phase-entry.md:118-138`
- `.docs/c2a-first-slice-semantic-protocol-contract.md:813-840`
- `.docs/rw0-b2-wire-protocol.md:25-59, 92-104`
- `src/ge_nwp_coordinator/_rw0_wire_protocol_values.py:893-898, 955-984, 1045-1092, 1808-1853`
- `tests/test_rw0_b2_wire_values.py:464-479`
- `.docs/rw0-b2-capability.md:180-213`
- `src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py:201-211, 884-915`

**Confidence:** High that the contradiction is real and owned by B2 Wire; high that C2 must stop; medium-high that a separate additive cancellation-control profile can resolve it without changing Capability, pending the read-only reconciliation.

Some older project uploads are no longer accessible. Re-upload a specific older artifact only if a later decision depends on it.
