PROMPT_ID

RW0_C1_COMMIT_PUSH_AND_PR_GATE_V1

TITLE

Coordinator RW0-C1 — stage the independently accepted 81-file candidate,
validate the exact staged tree once, commit once, push the feature branch, and
open one pull request

ENGAGEMENT TYPE

Authorized commit/push/PR gate in the existing RW0-C1 implementation
conversation.

This prompt authorizes only:

1. exact preflight and retained-evidence verification;
2. staging the independently accepted 81-file manifest;
3. one staged-candidate collection;
4. one staged-candidate complete suite;
5. one exact commit;
6. one non-force push of the feature branch;
7. one non-draft pull request.

This prompt does NOT authorize:

- implementation repair;
- source, test, documentation, SQL, or mode changes;
- amend, rebase, reset, cherry-pick, or force push;
- direct push to `trunk_dev`;
- PR review, approval, comment, thread resolution, merge, auto-merge, branch
  deletion, tag, release, or deployment;
- RW0-C2, RW0-D, RW0-E, Execution Substrate, Bridge, worker, provider,
  process, runtime, or supporting-repository work.

Do not delegate to subagents.

Print the complete substantive result inline. Evidence paths may be
supplementary only.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

EXPECTED OPENING LOCAL IDENTITY

physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-c1-durable-evidence-v1

HEAD:
047563de5a443b0f8323401c92979ae2e444d2ed

HEAD tree:
4ff9ee4a710af13447e3ed8699339a51255ff720

sole parent:
dd12b23762dc761736e55a1abfde12dd3ec23551

subject:
feat: add RW0-B2 cancellation-control evidence (#6)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

staged/unmerged:
0/0

candidate:
exactly 81 changed/untracked paths, all regular physical mode 0644, no 82nd
path, no repository residue.

If local identity, candidate bytes, candidate modes, or path inventory differ,
stop before staging:

RW0_C1_COMMIT_GATE_BASELINE_MISMATCH

INDEPENDENT ACCEPTANCE

The final independent audit returned:

ACCEPT

COORDINATOR_RW0_C1_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE

Final audit evidence root:

/private/tmp/ge-coordinator-rw0-c1-final-acceptance-reaudit.LA8igO

Final audit self-excluding index:

/private/tmp/ge-coordinator-rw0-c1-final-acceptance-reaudit.LA8igO/evidence-index.txt

Final audit index SHA-256:

ca5c9c41c71685472e6f8d71971137173df7576077f910191ab94c6578cad640

Final repair evidence root:

/private/tmp/ge-coordinator-rw0-c1-final-handoff-repair.nYKeMi

Final repair self-excluding index:

/private/tmp/ge-coordinator-rw0-c1-final-handoff-repair.nYKeMi/evidence-index.txt

Final repair index SHA-256:

cf35d96176726094dd0b04d33edcb74cc6fea4de9525def4c800bbe66806e07f

Verify both roots and indexes read-only before staging. Do not modify, clean,
re-index, normalize, or copy files into either retained root.

ACCEPTED CANDIDATE IDENTITIES

Canonical manifest SHA-256:

c1274e99cc717daf0fc280581f019f8b85eeadfb7d6d211e5a76d5a1ef385bb4

Full-candidate tracked textual diff SHA-256:

5991bfbb4c5b2bbe0f3d0c535a29c5425bb4dacb7c51b62225774686108a715b

Complete provenance-recipe output SHA-256:

14807b0045b2a02d444674883e610caf79b4025bf868237acf39829dab55b22e

Candidate file count:

81

Candidate paths:

64 tracked modifications
17 untracked additions
0 deletions
0 renames
0 copies
0 executable-mode changes

Every candidate file must be physical mode 0644 and become Git mode 100644.

Accepted final nodes:

5205

Accepted ordered node SHA-256:

c54742289bcb5e569cef4f7ce5df88197f60c020226fa0dc9cefb1bfd7ac7218

FINAL AUDIT RESULTS TO PRESERVE

- No Critical, High, Medium, or Low finding remains.
- FINAL-001 and FINAL-002 are closed.
- FINAL-003 remains a non-blocking historical Observation, with exact
  prospective test-only causality evidence.
- Schema remains 23/46/4 for C1 and 62/110/5 cumulatively.
- Exactly 15 evidence kinds remain.
- No private runtime material entered SQLite.
- No package, public `StateStore`, or public `WriterSession` widening occurred.
- One transaction controller remains the sole C1 connection/COMMIT owner.
- Live complete suite passed 5205/5205.
- External clean-commit complete suite passed 5205/5205.
- Live and clean executed-test order matched exactly.

EXACT PROVENANCE RECIPE

recipe ID:
governed-execution.audit-patch-manifest.v1

source size:
3945 bytes

source SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

Use the exact indexed recipe source and the already accepted safe
historical-sink redirection wrapper. Do not alter the historical sink.

MATERIALITY RULE

Keep the gate evidence proportionate.

A harmless audit-harness, parser, temporary-path, or diagnostic correction that
does not change candidate bytes, staged tree, validation result, Git effect,
remote effect, or retained evidence identity is an Observation, not a reason to
repeat or invalidate an irreversible effect.

Never repeat commit, push, or PR creation merely to repair reporting or harness
metadata. Inspect resulting state first and treat exact resulting state as
authoritative.

REMOTE AND POLICY PREFLIGHT

Remote contact is authorized only for this gate.

1. Verify:

```text
origin:
git@github.com:evo-agi/Governed-Execution-Coordinator.git

GitHub repository:
evo-agi/Governed-Execution-Coordinator
```

2. Verify authenticated GitHub identity and record it.

3. Query the remote refs narrowly without tags.

Require:

```text
remote trunk_dev:
047563de5a443b0f8323401c92979ae2e444d2ed
```

The remote feature ref:

```text
refs/heads/codex/rw0-c1-durable-evidence-v1
```

must be absent.

If the remote base advanced, the feature ref exists, or origin identity differs,
stop without staging or remote mutation:

RW0_C1_REMOTE_PREFLIGHT_MISMATCH

4. Search all open and closed PRs for:

```text
head:
codex/rw0-c1-durable-evidence-v1
```

Require none.

If a matching PR exists, stop to avoid duplication:

RW0_C1_EXISTING_PR_OR_REMOTE_BRANCH

5. Inspect current rulesets/branch protection and repository settings for
`trunk_dev`. Record:

- PR-flow requirement;
- allowed merge methods;
- required approvals/status checks;
- thread-resolution policy;
- bypass actors;
- auto-merge setting;
- branch-deletion setting.

This gate uses no bypass and performs no merge regardless of policy.

6. Reverify the final audit and final repair evidence indexes after remote
preflight and before staging.

CANONICAL MANIFEST RESOLUTION

Locate the canonical 81-file JSON manifest referenced by the accepted final
audit/final repair evidence.

Requirements:

- regular retained evidence file;
- bytes SHA-256 exactly
  `c1274e99cc717daf0fc280581f019f8b85eeadfb7d6d211e5a76d5a1ef385bb4`;
- canonical JSON;
- exactly 81 entries;
- exact branch/HEAD/upstream identity;
- every file path unique;
- classifications exactly 64 tracked modifications and 17 untracked additions;
- all file types regular and modes 0644;
- live path/type/mode/size/SHA agreement;
- no path outside the manifest differs from HEAD.

Multiple byte-identical retained copies are permitted. Record every exact copy
used; do not reject merely because the same canonical bytes were retained in
more than one accepted evidence root.

Run the exact recipe twice immediately before staging and require:

- byte-identical manifests equal to the accepted manifest;
- complete output SHA-256
  `14807b0045b2a02d444674883e610caf79b4025bf868237acf39829dab55b22e`;
- tracked textual diff SHA-256
  `5991bfbb4c5b2bbe0f3d0c535a29c5425bb4dacb7c51b62225774686108a715b`;
- empty stderr;
- return code zero;
- historical sink unchanged.

STAGING

Stage exactly the 81 manifest paths with one bounded `git add -- <paths...>`
operation generated from the verified manifest.

Do not use:

- `git add -A`
- `git add .`
- a wildcard
- an inferred directory
- any path absent from the manifest.

After staging require:

- exactly 81 staged paths;
- 64 modifications and 17 additions;
- no deletion, rename, copy, or mode change;
- all staged modes 100644;
- no unstaged or untracked candidate content;
- no staged path outside the manifest;
- no unmerged path;
- `git diff --cached --check` passes;
- working-tree bytes equal staged blobs for all 81 paths;
- every path outside the manifest still equals HEAD.

Freeze and retain:

- staged path/status list;
- staged blob/mode/size/SHA manifest;
- staged binary and textual diffs;
- staged tree OID from `git write-tree`;
- source repository and real-index fingerprint.

Independently reconstruct the candidate tree from exact HEAD plus the canonical
manifest in a fully external object database, with no alternates and no shared
source-object inodes. Require that reconstructed tree equals the staged tree.

If staging or tree identity fails:

1. unstage exactly the 81 paths while preserving working bytes;
2. prove the real index returned to its opening identity;
3. stop:

RW0_C1_STAGING_GATE_FAILED

VALIDATION ENVIRONMENT

Create one new private evidence root:

/private/tmp/ge-coordinator-rw0-c1-commit-gate.XXXXXX

Use:

umask 0022
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
external evidence-root PYTHONPYCACHEPREFIX
external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
GIT_OPTIONAL_LOCKS=0
python3 -B
-p no:cacheprovider
-W error

Use distinct external basetemp, JUnit, stdout, stderr, cache, and temp paths for
collection and complete suite.

Hygiene records support the gate but are not an independent authority. A
correctable parser or reporting issue may be reconciled by rereading retained
stdout/JUnit without rerunning pytest.

STAGED-CANDIDATE COLLECTION

Run exactly one collection invocation over `tests` after staging.

Require:

- 5205 unique nodes;
- ordered SHA-256
  `c54742289bcb5e569cef4f7ce5df88197f60c020226fa0dc9cefb1bfd7ac7218`;
- zero duplicate or unmapped nodes;
- zero warnings;
- empty stderr;
- return code zero;
- staged tree, candidate bytes, index, and repository status unchanged
  before/after.

If collection fails or differs:

1. preserve complete evidence;
2. unstage exactly the 81 paths;
3. prove the working candidate bytes remain unchanged and index returns to
   opening identity;
4. stop:

RW0_C1_COMMIT_GATE_COLLECTION_FAILED

STAGED-CANDIDATE COMPLETE SUITE

Run exactly one complete-suite invocation over `tests`.

Require:

- 5205 collected;
- 5205 passed;
- zero failures;
- zero errors;
- zero skips;
- zero xfails;
- zero xpasses;
- zero warnings;
- empty stderr;
- parseable JUnit;
- 5205 unique JUnit cases;
- exact ordered mapping to the accepted node list;
- return code zero;
- staged tree, candidate bytes, index, and repository status unchanged
  before/after.

No second complete-suite attempt is authorized by this prompt.

If the complete suite fails:

1. preserve complete evidence;
2. classify candidate versus environment/tooling;
3. do not repair source or tests;
4. unstage exactly the 81 paths;
5. prove candidate bytes remain unchanged and index returns to opening identity;
6. stop:

RW0_C1_COMMIT_GATE_FULL_SUITE_FAILED

FINAL PRECOMMIT GUARD

After validation, reverify:

- remote `trunk_dev` remains the accepted base;
- remote feature ref remains absent;
- no matching PR now exists;
- local HEAD remains the accepted base;
- staged tree equals the frozen staged tree;
- real index equals the frozen staged index;
- no unstaged/untracked/staged-extra content;
- final audit and repair evidence roots remain exact;
- recipe reproduces the accepted manifest one final time;
- no locks, operations, repository residue, databases, journals, caches,
  bytecode, build output, or generated manifests exist.

If any guard fails, unstage exactly the 81 paths and stop:

RW0_C1_PRECOMMIT_GUARD_FAILED

COMMIT

Execute exactly one commit command:

```text
git commit -m "feat: implement RW0-C1 durable evidence"
```

Required commit:

- one commit;
- sole parent
  `047563de5a443b0f8323401c92979ae2e444d2ed`;
- tree exactly equal to the frozen staged tree;
- subject exactly:
  `feat: implement RW0-C1 durable evidence`;
- empty body;
- exactly 81 changed files;
- exactly 64 modifications and 17 additions;
- no deletions, renames, copies, or mode changes;
- every mode 100644;
- local index and worktree clean after commit.

Record author/committer identities, timestamps, signature state, OID, parent,
tree, subject, body, and per-path blobs/modes/sizes/SHA-256.

Do not amend.

If the commit command returns uncertain or nonzero, inspect `HEAD`, reflog,
index, and worktree before any further action.

- If the exact commit exists with the exact tree and parent, treat the commit as
  completed and do not run a second commit.
- Otherwise stop without push:

RW0_C1_COMMIT_FAILED

PUSH

Before pushing, reverify:

- local commit exact;
- remote `trunk_dev` still equals accepted base;
- remote feature ref absent;
- no matching PR;
- origin exact.

Execute exactly one non-force push:

```text
git push -u origin HEAD:refs/heads/codex/rw0-c1-durable-evidence-v1
```

Require:

- remote feature ref equals the exact local commit;
- remote `trunk_dev` remains unchanged;
- local upstream becomes
  `origin/codex/rw0-c1-durable-evidence-v1`;
- local/remote feature divergence `0/0`;
- worktree/index clean;
- no force push.

If push returns uncertain/nonzero, inspect the remote feature ref before any
retry. Do not issue a second push under this prompt.

- If remote feature already equals the exact commit, treat push as completed.
- Otherwise stop:

RW0_C1_PUSH_FAILED

PULL REQUEST

After exact push:

1. Search again for any PR with the exact head branch or head commit.
2. If one exact PR already exists because the create result was uncertain, use
   it and do not create another.
3. Otherwise execute exactly one PR creation command.

Required PR:

```text
repository:
evo-agi/Governed-Execution-Coordinator

base:
trunk_dev

head:
codex/rw0-c1-durable-evidence-v1

title:
feat: implement RW0-C1 durable evidence

draft:
false
```

Use this exact body:

```markdown
## Summary

- add migration `0004_rw0_c1_durable_evidence`
- persist private RW0-C1 phase instances and 15 typed supplied-evidence kinds
- add exact membership, relation/profile binding, replay, conflict, guarded readback, and three-way commit recovery
- preserve C2/D/E, Execution Substrate, public API, runtime, and external-contact boundaries

## Validation

- independent audit: `COORDINATOR_RW0_C1_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE`
- staged collection: 5,205 nodes
- staged complete suite: 5,205 passed
- live and external clean acceptance suites: 5,205 passed each

## Authority boundary

RW0-C1 is private durable evidence mechanics only. This PR does not implement evidence completeness, C2B decisions, acceptance-latch mutation, terminal outcomes, workers, providers, transport, process control, external contact, RW0-D/E, or Execution Substrate integration.
```

After creation require:

- PR open;
- non-draft;
- unmerged;
- exact base branch and accepted base OID;
- exact head branch and commit OID;
- exactly one commit;
- exactly 81 changed files;
- exact title and byte-identical body;
- no auto-merge;
- no reviews, approvals, comments, requested reviewers, or thread resolutions
  created by this gate.

Do not merge.

If the create command is uncertain/nonzero, search by exact head branch and
commit before any further action. Never create a second PR.

If no exact PR exists, stop:

RW0_C1_PR_CREATION_FAILED

FINAL GUARDS

Require:

- local branch remains `codex/rw0-c1-durable-evidence-v1`;
- local HEAD is the exact new commit;
- upstream is the exact remote feature branch;
- local/remote feature divergence `0/0`;
- remote `trunk_dev` remains the accepted base;
- worktree/index clean;
- one worktree;
- no Git operation or lock;
- no repository residue;
- exact remote feature commit/tree/parent/shape;
- exact open PR;
- no merge, auto-merge, review, branch deletion, tag, release, or deployment;
- all accepted evidence roots unchanged;
- collection invoked exactly once;
- complete suite invoked exactly once;
- commit executed at most once;
- push executed at most once;
- PR created at most once.

EVIDENCE AND CLOSEOUT

Retain proportionate gate evidence:

- opening identity;
- evidence-index verification;
- remote/policy preflight;
- canonical manifest and recipe reproductions;
- exact stage manifest and staged tree;
- external reconstructed tree comparison;
- collection/JUnit/node records;
- complete-suite/JUnit records;
- final precommit guard;
- commit record;
- push record;
- PR record;
- final guards;
- cleanup record;
- final report.

Remove only commit-gate-created transient external checkout, basetemp, tmp,
cache, and pycache paths.

Seal the gate root:

- root/directories mode 0700;
- retained files mode 0400;
- no symlink or special entry;
- self-excluding evidence index created last and independently reverified.

SUCCESS TOKEN

Return exactly:

COORDINATOR_RW0_C1_COMMITTED_PUSHED_AND_PR_OPENED

only when the exact accepted candidate has been committed, pushed, and opened
as one non-draft PR, with all final guards green.

FINAL INLINE REPORT

Use:

# Outcome
# Accepted provenance and audit
# Opening identity
# Remote and policy preflight
# Exact staging and frozen tree
# Collection and complete-suite validation
# Commit
# Push
# Pull request
# Final guards
# Evidence index
# Limitations and confidence

Required final statements:

IMPLEMENTATION_REPAIR_NOT_PERFORMED
INDEPENDENT_AUDIT_NOT_REPEATED
DIRECT_TRUNK_PUSH_NOT_PERFORMED
BYPASS_NOT_USED
FORCE_PUSH_NOT_PERFORMED
AMEND_NOT_PERFORMED
REBASE_NOT_PERFORMED
SECOND_COMMIT_NOT_PERFORMED
SECOND_PUSH_NOT_PERFORMED
SECOND_PR_NOT_CREATED
PR_MERGE_NOT_PERFORMED
AUTO_MERGE_NOT_ENABLED
REVIEW_NOT_SUBMITTED
THREAD_NOT_RESOLVED
FEATURE_BRANCH_NOT_DELETED
TAG_NOT_CREATED
RELEASE_NOT_CREATED
DEPLOYMENT_NOT_PERFORMED
RW0_C2_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
COLLECTION_RUN_EXACTLY_ONCE
FULL_SUITE_RUN_EXACTLY_ONCE
