PROMPT_ID

RW0_C1_DURABLE_IDENTITY_AND_TRANSACTION_AUTHORITY_CLOSURE_V1

TITLE

Coordinator RW0-C1 — close membership identity, result-state representation,
relation dependency integrity, transaction-controller ownership, and the final
causal implementation allowlist

ENGAGEMENT TYPE

Narrow parent-only read-only contract reconciliation.

Do not implement, edit, format, stage, commit, push, create a PR, merge, run
tests, collect nodes, execute migrations, open a database, fetch, contact a
remote/live system, install dependencies, invoke a product worker/model, or
inspect another repository.

Print the complete substantive result inline. Evidence files are supplementary
only.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
047563de5a443b0f8323401c92979ae2e444d2ed

tree:
4ff9ee4a710af13447e3ed8699339a51255ff720

sole parent:
dd12b23762dc761736e55a1abfde12dd3ec23551

subject:
feat: add RW0-B2 cancellation-control evidence (#6)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktree/index/untracked/unmerged:
clean

No fetch is authorized.

ACCEPTED DECISIONS THAT ARE NOT REOPENED

Preserve:

1. C1/C2 remain separate non-disposable tranches.
2. C1 is private, no-contact, and independently useful.
3. C1 owns one immutable phase instance, exactly 15 typed supplied-evidence
   kinds, single-member admission, relation/profile binding, replay/conflict,
   guarded readback, and three-way commit recovery.
4. C1 owns no completeness, C2B decision, terminal outcome, latch mutation,
   public API, production caller, executable authority, or external contact.
5. Migration 0004 is additive, generation 2, non-destructive, zero-seed, and
   contains no C2 closure/latch/decision/terminal state.
6. Existing B1, Wire, Capability, C2A, C2B, Section 41, migrations 0001–0003,
   package, public, and authority semantics remain unchanged.
7. Capsule entries, paths, operations, modes, blob digests, byte lengths, raw
   capsule bytes, and complete CandidateCapsuleManifestV1 values remain outside
   SQLite.
8. C1 retains only the safe manifest binding:
   candidate ref, manifest schema ID, manifest ref, portable capsule digest,
   and authorized path-scope digest.
9. C2 later receives the full manifest transiently, verifies it against the
   C1 safe binding, computes cancellation-control classification, and persists
   only a C2 closure/attestation.
10. Evidence identity is kind-scoped, not globally ref/digest-scoped.
11. Rank 14 is NWPF process/result classification only and never stores the
    cancellation-control classification or a complete manifest.
12. The table-family direction remains six common tables, fifteen typed
    payloads, and two normalized child tables unless an exact correction below
    proves a count change.
13. Permanent tests prove finite product behavior; independent audit owns
    external mutation/provenance. No self-protecting test architecture.

WHY ANOTHER CLOSURE IS REQUIRED

The previous response returned
`RW0_C1_FINAL_IMPLEMENTATION_CONTRACT_READY`, but its own exact contracts are
internally inconsistent in five implementation-blocking ways.

A. MEMBERSHIP IDENTITY WAS REMOVED FROM SQL BUT REMAINS REQUIRED ELSEWHERE

The previous command/result/receipt/recovery contracts use:

- `preassigned_membership_ref`;
- `membership_ref`;
- `membership_digest`;
- reader-by-membership-ref;
- wrapper fields named `*_membership_ref/digest`;
- relation subjects that must identify one phase-specific membership.

The revised `rw0_evidence_memberships` table then omitted `membership_ref` and
made `(phase_ref, kind_rank, value_ref)` the primary key.

A globally reusable evidence value may be admitted to several phases. C2
closures and relation proofs need a stable phase-membership identity distinct
from the reusable underlying value identity.

B. SAME-PHASE RELATION OPERANDS REFERENCE THE GLOBAL REGISTRY, NOT MEMBERSHIP

The revised `rw0_relation_operands` C1-evidence branch has an FK only to
`rw0_evidence_values`.

That does not prove the operand is admitted under the same phase. It permits a
relation row to point to a globally registered value that has no membership in
the relation’s phase, contradicting the dependency DAG and recovery model.

C. RANK 13/RANK 14 CANNOT REPRESENT THE OWNER CLASSIFIER’S FULL INPUT SPACE

The existing owner API:

`classify_wire_process_result(...)`

accepts:

- a real `RW0WireWorkerResultV1`;
- or a finite `RW0WireProtocolError` result failure;
- or neither result nor failure.

The previous response instead requires rank 14 always to identify one rank-13
member and defines only:

- `worker_result`;
- `finite_result_failure`.

It does not define exact rank-13 failure fields, and it cannot represent the
owner’s no-result branch that yields `result_missing` or
`process_evidence_incomplete`.

D. RELATION CARDINALITY IS CONTRADICTORY

The frozen relation ledger establishes:

- ranks 5 and 7: zero relations;
- rank 12 response: two relations;
- every other member: one relation.

The maximum is therefore two.

The previous reader contract instead says maximum three and uses `LIMIT 4`.

E. THE PROPOSED PRODUCTION MODULE SET HAS NO LEGAL TRANSACTION-CONTROLLER PATH

Current source centralizes connection open, `BEGIN IMMEDIATE`, managed-schema
validation, writer fencing, nominal capability, rollback, one commit attempt,
commit-resolution state, process-control stabilization, and cleanup in
`sqlite_transition_transaction.py` and
`_CoordinatorMutationTransactionController`.

The previous exact allowlist protects that file while asking new
`_sqlite_rw0_c1.py` to perform atomic persistence and recovery without direct
`sqlite3` import and without a second controller.

There is no current generic extension hook for a new mutation family. The
contract must either:

- add C1 methods/wrappers to the existing transaction controller; or
- identify a concrete existing extension point that allows the same controller
  to own C1 without duplicating its lifecycle.

Duplicating controller logic in `_sqlite_rw0_c1.py`, reaching through private
state ad hoc, or creating a second transaction authority is forbidden.

PRIMARY OBJECTIVE

Return one self-consistent implementation contract by closing exactly:

1. stable phase-membership identity;
2. same-phase relation-operand integrity;
3. complete NWPF result/failure/absence representation;
4. exact relation count;
5. exact phase naming;
6. exact transaction-controller integration;
7. resulting DDL, reader, replay, recovery, and touched-path changes.

Do not reopen the phase decomposition, 15-kind inventory, capsule privacy, or
kind-scoped evidence identity.

REQUIRED INSPECTION

Inspect completely or in every relevant owning section:

- `src/ge_nwp_coordinator/_rw0_wire_protocol_values.py`
- `src/ge_nwp_coordinator/sqlite_transition_transaction.py`
- `src/ge_nwp_coordinator/sqlite_writer_session.py`
- `src/ge_nwp_coordinator/sqlite_transition_select_support.py`
- `src/ge_nwp_coordinator/sqlite_mutation_transaction_contracts.py`
- current development mutation implementations and recovery implementations
- current writer-session private delegation implementations
- every test that pins:
  - `_CoordinatorMutationTransactionController`;
  - operation-specific transaction methods/wrappers;
  - private writer-session methods;
  - direct sqlite3 importer inventory;
  - transaction source/importer inventory;
  - mutation-controller source allowlists.

Re-read the accepted C1 contract responses for all exact row, command, result,
receipt, relation, reader, recovery, privacy, and path-ledger details.

A. FREEZE STABLE MEMBERSHIP IDENTITY

Use one model consistently.

Preferred required model unless repository evidence disproves it:

`rw0_evidence_memberships` includes:

```text
membership_ref
membership_digest
phase_basis_ref
phase_basis_digest
kind_rank
value_ref
value_digest
value_schema_id
scope_binding_digest
relation_set_digest
admitted_by_mutation_ref
admitted_at
admission_graph_digest
```

Recommended constraints:

```text
PRIMARY KEY (membership_ref)

UNIQUE (membership_digest)

UNIQUE (
  phase_basis_ref,
  kind_rank,
  value_ref
)

UNIQUE (
  phase_basis_ref,
  kind_rank,
  value_digest
)

UNIQUE (
  phase_basis_ref,
  kind_rank,
  value_ref,
  value_digest,
  value_schema_id
)

UNIQUE (
  phase_basis_ref,
  membership_ref,
  membership_digest
)
```

with exact restrictive composite FKs to:

- `rw0_phase_instances`;
- kind-scoped `rw0_evidence_values`.

Freeze:

- membership schema ID;
- membership-ref derivation or preassignment rule;
- membership-digest domain and exact ordered fields;
- command/result/receipt/recovery fields;
- collision classes;
- reader predicates;
- C2 closure identity.

If a design without `membership_ref` is selected, remove it coherently from
every command, result, receipt, wrapper, relation subject, reader, replay,
recovery, and C2 closure contract and prove that the composite identity is
equally stable and unambiguous. Do not leave mixed models.

B. FREEZE RELATION SUBJECT AND SAME-PHASE OPERAND INTEGRITY

For a member relation:

- subject identity must be the exact phase membership, not merely the globally
  registered evidence value;
- relation-set digest must bind the membership;
- each `c1_evidence` operand must identify an exact admitted membership in the
  same phase.

Preferred operand fields:

```text
phase_basis_ref
relation_ref
relation_digest
operand_ordinal
operand_role
operand_source
source_membership_ref
source_membership_digest
evidence_kind_rank
operand_schema_id
operand_ref
operand_digest
operand_scope_digest
operand_row_digest
```

For `operand_source = c1_evidence`, require a composite FK to
`rw0_evidence_memberships` proving:

```text
same phase
same membership
same kind
same value ref
same value digest
same value schema
```

The registry FK alone is insufficient.

For:

```text
existing_owner_row
transient_safe_manifest_binding
```

freeze exact branch nullability and identity fields without a membership FK.

Freeze phase-establishment subject identity separately.

C. FREEZE RANK 13 AND RANK 14 RESULT-STATE ALGEBRA

Trace the exact current owner classifier and freeze all legal branches.

Recommended target:

Rank 13 remains an actual `RW0WireWorkerResultV1` binding only.

Rank 14 contains:

```text
result_state:
present
finite_failure
absent
```

Branch algebra:

```text
present:
  exact rank-13 membership ref/digest present
  result_failure_reason null

finite_failure:
  rank-13 membership pair null
  exact finite Wire failure reason present

absent:
  rank-13 membership pair null
  result_failure_reason null
```

Freeze the exact finite failure-reason inventory from the current Wire owner’s
decoder and construction reason sets.

Rank 14 must represent all current owner outputs, including:

```text
result_missing
result_invalid
process_evidence_incomplete
```

Update:

- dependency DAG;
- legal partial states;
- exact fields;
- SQL branch CHECK;
- relation operands;
- readers;
- replay;
- recovery;
- tests.

If rank 13 instead becomes a variant wrapper for result or failure, freeze its
complete variant schema and prove the no-result classifier branch remains
representable. Do not leave the branch implicit.

D. FREEZE EXACT RELATION COUNT

Resolve to one exact contract.

Given the accepted relation ledger, expected:

```text
rank 5:
0

rank 7:
0

rank 12 ordinary:
1

rank 12 cancellation response:
2

all other member ranks:
1

maximum:
2

relation_rank:
0 | 1

relation reader overflow probe:
LIMIT 3
```

If any rank genuinely requires three relations, identify the exact third
relation and operands. Otherwise remove every stale `0..3`, maximum-three, or
`LIMIT 4` claim.

Freeze command bounds, relation-set digest, SQL checks, reader limits, replay,
and tests consistently.

E. NORMALIZE PHASE IDENTITY NAMING

Use the owning B1 identity names consistently:

```text
phase_basis_ref
phase_basis_digest
```

Do not mix them with unexplained:

```text
phase_ref
phase_digest
```

Apply the decision to:

- every C1-owned schema;
- SQL columns;
- commands/results/receipts;
- membership and relation rows;
- readers;
- recovery;
- C2 forward seam;
- tests and documents.

If a shorter physical SQL name is retained, explicitly map it to the owner
field and use one vocabulary in every semantic value.

F. FREEZE TRANSACTION-CONTROLLER OWNERSHIP

Inspect current implementation and choose one exact integration.

Preferred architecture:

1. Add C1 operation methods and private module-level wrappers to
   `sqlite_transition_transaction.py`.
2. The existing `_CoordinatorMutationTransactionController` remains the sole
   transaction controller and owns:
   - operation lease;
   - connection;
   - `BEGIN IMMEDIATE`;
   - schema/binding validation;
   - writer fence;
   - nominal read capability;
   - rollback;
   - one commit attempt;
   - commit-outcome state;
   - process-control stabilization;
   - cleanup.
3. A C1-specific private module owns:
   - pure command/row/relation planning;
   - C1 literal SQL write helpers;
   - family readback verification;
   - committed/absent/unresolved evaluation;
   but does not create a second connection/controller or duplicate controller
   lifecycle.
4. `sqlite_writer_session.py` exposes only private concrete-session delegation
   and imports the new controller wrappers.
5. Public `WriterSession`, `StateStore`, and package exports remain unchanged.

Alternatively, identify and prove an existing generic controller extension
point. Include exact source lines and show that no controller lifecycle is
duplicated.

Forbidden:

- second controller;
- direct `sqlite3` import in the C1 module if that would create a second
  authority path;
- ad hoc calls into controller private state from outside;
- duplicated rollback/commit/cleanup logic;
- a new connection path.

Freeze exact production module responsibilities and import direction.

G. RECOMPUTE SQL AND READER CONSEQUENCES

After A–F, return exact revised definitions for:

```text
rw0_evidence_memberships
rw0_relation_bindings
rw0_relation_operands
rw0_wire_worker_result_bindings
rw0_wire_process_result_classification_bindings
rw0_c1_mutation_receipts
```

State:

- exact ordered columns;
- PKs;
- UNIQUE constraints;
- FKs;
- branch CHECKs;
- trigger names;
- explicit indexes;
- table/trigger/index counts;
- cumulative totals;
- exact readers and LIMITs;
- collision probes;
- replay family;
- recovery absence/completeness probes.

Confirm whether the total remains:

```text
23 new tables
46 new triggers
4 new explicit indexes
62 cumulative tables
110 cumulative triggers
5 cumulative explicit indexes
```

A count may remain unchanged, but must be mechanically explained.

H. FREEZE ERROR VOCABULARY

Normalize exact spellings everywhere, including at least:

```text
mutation_ref_reuse
phase_identity_collision
k8_collision
current_state_conflict
member_identity_collision
member_already_admitted
missing_prerequisite_member
relation_failure
relation_identity_collision
owner_row_missing
database_integrity_failure
mutation_failed
commit_outcome_unknown
```

Do not alternate between `mutation_ref_reuse`,
`mutation_ref_reused`, and `mutation_ref_reuse_conflict`.

State whether conflicts are returned as a private conflict value or raised as a
safe error. Freeze exact result types.

I. RECOMPUTE THE CAUSAL TOUCHED-PATH LEDGER

The previous 78-path ledger cannot remain exact unless the transaction
controller is proven unchanged.

Search every direct contract test and source inventory affected by the selected
controller integration.

Return:

```text
must_change
protected
```

For every newly added path state:

- exact current assertion;
- exact intended change;
- owning contract;
- direct failure if omitted.

At minimum evaluate:

```text
src/ge_nwp_coordinator/sqlite_transition_transaction.py

tests pinning:
_CoordinatorMutationTransactionController
operation-specific run_* methods
module-level _run_* wrappers
controller source/import inventories
writer-session private method inventories
transaction authority and cleanup ordering
```

Do not provide a loose maximum. Return one exact path count.

J. IMPLEMENTATION READINESS

Return `RW0_C1_IMPLEMENTATION_CONTRACT_READY` only if all are exact and
self-consistent:

- stable membership identity;
- same-phase relation operand FK;
- full result/failure/absence representation;
- max relation count;
- phase naming;
- controller ownership;
- SQL and reader contracts;
- error algebra;
- path ledger.

Return `RW0_C1_FREEZE_RECONCILIATION_REQUIRED` if any exact identity, branch,
DDL, authority, recovery, or path detail remains open.

Return `RW0_C_ARCHITECTURAL_REPLAN_REQUIRED` only for a genuine owner,
privacy, transaction, decomposition, or recovery contradiction.

OUTPUT

Print inline:

# Baseline and inspection boundary
# Preserved C1 architecture
# Stable membership identity
# Relation subject and operand integrity
# Rank-13 and rank-14 result-state algebra
# Exact relation cardinality
# Normalized phase identity
# Transaction-controller ownership
# Revised SQL and reader contracts
# Replay and recovery consequences
# Error and conflict algebra
# Exact causal touched-file ledger
# Findings and contradictions
# Forecasts and stop conditions
# Recommendation
# Next implementation boundary

End with exactly one:

RW0_C1_IMPLEMENTATION_CONTRACT_READY

RW0_C1_FREEZE_RECONCILIATION_REQUIRED

or

RW0_C_ARCHITECTURAL_REPLAN_REQUIRED

Do not issue an implementation prompt.

Required final statements:

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
