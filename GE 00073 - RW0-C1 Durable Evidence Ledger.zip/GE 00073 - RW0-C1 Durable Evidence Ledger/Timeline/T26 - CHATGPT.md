# Disposition

**Do not begin RW0-C1 implementation yet.**

The latest reconciliation fixes the two most important architectural issues:

- capsule entries and full manifests remain outside SQLite;
- evidence identity is correctly kind-scoped rather than globally ref-scoped.

Those corrections are accepted. The C1/C2 decomposition, fifteen-kind inventory, admission DAG, and typed-migration direction also remain accepted.

However, the result is still not internally implementable as written. Its correct classification is:

```text
RW0_C1_FREEZE_RECONCILIATION_REQUIRED
```

not `RW0_C_ARCHITECTURAL_REPLAN_REQUIRED`.

## Remaining blockers

### 1. Membership identity is defined two incompatible ways

The earlier frozen commands, results, receipts, wrapper rows, readers, and recovery rules all depend on:

```text
preassigned_membership_ref
membership_ref
membership_digest
```

The latest SQL definition removes `membership_ref` and instead makes this the primary key:

```text
(phase_ref, kind_rank, value_ref)
```

Both models cannot govern implementation simultaneously.

A phase membership is not the same fact as the underlying evidence value:

- one globally reusable value can belong to multiple phases;
- each phase admission has its own relation set, admission graph, receipt, and timestamp;
- C2 closures need to bind the exact admitted membership, not merely the reusable value.

The stronger design is to retain a first-class immutable `membership_ref` and `membership_digest`, with phase-and-value uniqueness alongside it. Every command, result, receipt, relation subject, reader, replay path, recovery path, and later C2 closure must then use that identity consistently.

### 2. Relation operands do not prove same-phase admission

The proposed `c1_evidence` operand branch has a foreign key only to:

```text
rw0_evidence_values
```

That proves the value exists globally. It does **not** prove that the value is admitted into the relation’s phase.

This violates the now-frozen admission DAG. A relation could otherwise reference a globally registered Capability declaration, readiness claim, authority observation, or WorkerObservation that is absent from that phase.

A C1-evidence operand must bind the exact same-phase membership, including:

```text
phase_basis_ref
membership_ref
membership_digest
kind_rank
value_ref
value_digest
value_schema_id
```

and have a composite FK to `rw0_evidence_memberships`, not merely to the global registry.

### 3. Rank 14 cannot represent the Wire classifier’s no-result branch

The existing Wire owner permits:

```text
result present
finite result failure
neither result nor failure
```

The third case is necessary for outcomes such as:

```text
result_missing
process_evidence_incomplete
```

The proposed rank-14 contract instead requires a rank-13 member and allows only:

```text
worker_result
finite_result_failure
```

It therefore cannot represent every valid input and output of the merged owner classifier.

It also says rank 13 carries the finite failure reason, but the frozen rank-13 schema has only the actual worker-result observation binding and defines no failure variant.

The cleanest correction is:

```text
rank 13:
actual RW0WireWorkerResultV1 binding only

rank 14 result_state:
present
finite_failure
absent
```

with branch algebra:

```text
present:
rank-13 membership pair present
failure reason absent

finite_failure:
rank-13 pair absent
one exact finite Wire error reason present

absent:
rank-13 pair absent
failure reason absent
```

Rank 14 must therefore not always depend on rank 13.

### 4. Relation cardinality is contradictory

The frozen relation ledger establishes:

```text
ranks 5 and 7:
0 relations

ordinary rank 12:
1 relation

cancellation-response rank 12:
2 relations

all other members:
1 relation
```

The maximum is **two**.

The latest reader contract instead claims maximum three and uses:

```text
LIMIT 4
```

The final contract should use:

```text
relation_rank:
0 | 1

maximum:
2

overflow probe:
LIMIT 3
```

unless Codex identifies a concrete third relation for a named member kind.

### 5. Phase identity naming is inconsistent

The B1-owned identity is:

```text
phase_basis_ref
phase_basis_digest
```

The latest SQL and reader sections switch to:

```text
phase_ref
phase_digest
```

without freezing an explicit semantic-to-physical mapping.

One vocabulary must be used consistently across:

- SQL;
- commands;
- results;
- receipts;
- memberships;
- relation rows;
- readers;
- recovery;
- C2 closure inputs.

The safer choice is to retain the owning B1 names.

### 6. The proposed production-module boundary cannot use the current transaction authority

The current repository centralizes connection opening, `BEGIN IMMEDIATE`, schema validation, writer fencing, nominal read capability, rollback, commit-attempt resolution, process-control stabilization, and cleanup in:

```text
src/ge_nwp_coordinator/sqlite_transition_transaction.py
```

Its `_CoordinatorMutationTransactionController` exposes operation-specific methods and wrappers; it has no generic external extension hook.

The latest 78-path contract protects that file while asking a new:

```text
_sqlite_rw0_c1.py
```

to perform atomic persistence and recovery without importing `sqlite3`, creating a second controller, or duplicating controller lifecycle logic.

That is not presently achievable.

The implementation must either:

- add C1 operation methods and module-level wrappers to the existing transaction controller; or
- identify a concrete existing generic extension point and prove that it preserves the same controller authority.

Ad hoc access to private controller state or a duplicate connection/commit controller is not acceptable.

This will also change the supposedly exact 78-path allowlist and likely activate existing controller-authority tests.

## Accepted direction

The following remains frozen:

```text
C1:
private durable phase + typed membership + replay/recovery

C2:
decision closure + latch + terminal closure

member kinds:
exactly 15

capsule persistence:
safe binding only

cancellation-control classification:
not a C1 member

evidence registry:
kind-scoped identity

migration:
additive 0004, generation 2, zero seed

no:
public API
production caller
external contact
C2 state in 0004
```

# Final closure prompt

Send this prompt to the same read-only Coordinator conversation:

:chatgpt-content-reference{index="1"}

```text
Filename:
Coordinator_RW0_C1_Durable_Identity_and_Transaction_Authority_Closure_Prompt.txt

Size:
17,854 bytes

SHA-256:
c939b6610c964464224f9fdca5eb582fa55c03c26378f2ec5e9a244fd1748fb9
```

It requires closure of only:

1. stable membership identity;
2. same-phase relation-operand FKs;
3. complete result/failure/absence representation;
4. exact relation cardinality;
5. consistent phase naming;
6. existing transaction-controller ownership;
7. resulting SQL/readers/recovery definitions;
8. the corrected exact touched-file ledger.

The successful result is:

```text
RW0_C1_IMPLEMENTATION_CONTRACT_READY
```

Only after that result should an implementation prompt be issued.

### Sources

- Current merged Coordinator snapshot: `Governed Execution Coordinator - Snapshot - 2026-09-27.zip`. 
- Codex’s latest RW0-C1 reconciliation response supplied in this turn.
- `src/ge_nwp_coordinator/_rw0_wire_protocol_values.py:1618-1914`
- `src/ge_nwp_coordinator/sqlite_transition_transaction.py:742-942,2180-2538`
- `src/ge_nwp_coordinator/sqlite_writer_session.py:5600-6380`

**Confidence:** High that the phase architecture is sound; high that these are implementation-blocking contract inconsistencies rather than ordinary coding details; high that one narrow closure pass can resolve them without architectural replan.
