PROMPT_ID

RW0_C1_DURABLE_EVIDENCE_FRESH_INDEPENDENT_AUDIT_V2_MODE_REPAIRED

TITLE

Coordinator RW0-C1 — fresh independent audit of the mode-repaired complete
private durable phase/evidence implementation

ENGAGEMENT TYPE

Independent read-only audit.

Do not repair, edit, format, generate repository files, stage, commit, push,
create a PR, merge, tag, release, deploy, install dependencies, migrate an
operator database, contact a remote/live system, invoke a product worker/model,
or modify a supporting repository.

Do not trust the implementation report as correctness proof.
Verify exact provenance before correctness inspection.
Stop with `AUDIT_PROVENANCE_MISMATCH` on any candidate-byte, manifest, recipe,
evidence-index, branch/HEAD, or required-topology mismatch.

Print the complete substantive audit report inline in chat. Evidence paths may
be supplementary only. Do not collapse the operative report into a hyperlink.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

EXPECTED REPOSITORY IDENTITY

physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-c1-durable-evidence-v1

HEAD:
047563de5a443b0f8323401c92979ae2e444d2ed

HEAD tree:
4ff9ee4a710af13447e3ed8699339a51255ff720

sole parent:
dd12b23762dc761736e55a1abfde12dd3ec23551

subject:
feat: add RW0-B2 cancellation-control evidence (#6)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

staged/unmerged:
0/0

candidate:
exactly the repaired canonical manifest’s 81 changed/untracked paths, all within
the frozen allowlist, with no 82nd path and no repository residue.

candidate path modes:
all 81 regular physical mode 0644

No fetch is authorized. Use local Git metadata only.

SUPPLIED IMPLEMENTATION AND MODE-REPAIR CLAIMS

The implementation report claims:

COORDINATOR_RW0_C1_IMPLEMENTED_READY_FOR_INDEPENDENT_AUDIT

The subsequent bounded metadata-repair report claims:

COORDINATOR_RW0_C1_MODE_REPAIRED_VALIDATION_RESET_READY_FOR_FRESH_INDEPENDENT_AUDIT

Claimed product:

- additive migration 0004;
- one immutable C1 phase instance;
- exactly 15 typed supplied-evidence kinds;
- stable phase-specific membership;
- versioned relation/profile proof and dense operands;
- private bounded readers;
- atomic phase establishment and evidence admission;
- exact replay/conflict behavior;
- one-commit-attempt semantics;
- explicit committed_exact / definitely_not_committed / unresolved recovery;
- private concrete writer-session delegation;
- no public API, C2, D/E, ES, worker, runtime, or external-contact widening.

IMPLEMENTATION EVIDENCE ROOT

/private/tmp/ge-coordinator-rw0-c1-implementation.Zcopmg

Required evidence identity:

self-excluding index:
/private/tmp/ge-coordinator-rw0-c1-implementation.Zcopmg/evidence-index.txt

index SHA-256:
cd1ad5ea72ef20a774fd470e38f14882a25f99af94db970c4506c62d4a4cc2b4

indexed files excluding index:
183

indexed directories excluding root:
22

opening implementation manifest:
/private/tmp/ge-coordinator-rw0-c1-implementation.Zcopmg/provenance-v7/manifest-run-1.json

opening implementation manifest SHA-256:
5cd3d1046660b59378f4c1ae24f40a5d6d5dc5850377f14780cc510568eb5456

opening tracked textual diff SHA-256:
c9e81fe9e3e82a39a5a239277d5187f67ea4795e285773b60f9b9afd4d858f54

opening complete recipe output SHA-256:
e4f2d8f0f318edd9701ec8da2afb429d1803c45578ed77456fe17e26d8016c20

opening file count:
81

The opening implementation manifest is historical evidence for the exact
semantic candidate before the metadata-only mode repair. It is not the final
audit target.

EXACT PROVENANCE RECIPE

recipe ID:
governed-execution.audit-patch-manifest.v1

source size:
3945 bytes

source SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

The indexed evidence contains the exact source and the 645-byte output-
redirection wrapper. Verify both. The wrapper may redirect only the historical
fixed output sink and must not alter Git queries, canonical JSON, stdout, or
stderr.


MODE-REPAIR VALIDATION EVIDENCE ROOT

/private/tmp/ge-coordinator-rw0-c1-mode-repair.k6Pxw5

Required evidence identity:

self-excluding index:
/private/tmp/ge-coordinator-rw0-c1-mode-repair.k6Pxw5/evidence-index.txt

index SHA-256:
5b30767c439a982e209c765f93c775547709555f5305697817a1b335e1bf2cc8

indexed files excluding index:
80

indexed directories excluding root:
4

final repaired canonical manifest SHA-256:
a1a9dbeb6c2d014c385bf3214011c8e5a7ea7e95273153f44293af9ff94e9a42

final repaired tracked textual diff SHA-256:
c9e81fe9e3e82a39a5a239277d5187f67ea4795e285773b60f9b9afd4d858f54

final repaired complete recipe output SHA-256:
800ab8949d209ac97ba4e7402af9b67f000d625c1643fd706fad8f4284b42ac9

file count:
81

mode inventory:
81 regular files at physical mode 0644

The mode-repair evidence must prove:

- the old and new manifests have the same 81 paths, classifications, sizes, and
  content SHA-256 values;
- exactly these eight mode fields changed from 0600 to 0644 and no other field
  changed:

  .docs/architecture.md
  .docs/software-development-progression-boundary.md
  .docs/sqlite-bootstrap-and-migrations.md
  .docs/sqlite-operations-and-recovery.md
  .docs/sqlite-threat-model.md
  AGENTS.md
  README.md
  tests/test_c2b0_durable_state_contract.py

- all remaining 73 candidate entries are identical;
- the tracked textual diff and candidate Git overlay tree are unchanged;
- no source, test, document, SQL, migration, public, or authority byte changed;
- the mode-repair collection retained the exact 5,157-node list;
- the sole mode-repair complete-suite attempt passed 5,157/5,157;
- both old evidence roots remained inventory-exact.

Locate the indexed repaired manifest and both repaired provenance outputs by
their indexed identities; do not infer a path that the evidence does not
contain.

PRIOR FAILED AUDIT ROOT

/private/tmp/ge-coordinator-rw0-c1-independent-audit.6Cd8VB

Required historical index SHA-256:
3929be307c05a532c491f5f520bad4d76cde702d7e0b41460cf0c8ab90373b25

This is provenance-stop history only. Verify it remains unchanged if inspected.
Do not resume it, amend it, or credit it as a correctness audit.

NODE AND VALIDATION CLAIMS

Opening nodes:
5087

Opening ordered SHA-256:
fe756529f88a3c44c31a402d2266b00b14993f420b76fa2af15595103599580c

Final nodes:
5157

Final ordered SHA-256:
efd65837c5c0e05bcd720dc52be6bfd32aa1f861392496864900fb083e0971df

Additions:
70

Opening removals/renames:
0

Implementation complete suite:
attempt 001 only
5157 passed
0 failures/errors/skips/xfails/xpasses/warnings
empty stderr
exact JUnit/node mapping

Mode-repair final collection:
5157 unique nodes
ordered SHA-256:
efd65837c5c0e05bcd720dc52be6bfd32aa1f861392496864900fb083e0971df

Mode-repair complete suite:
one authorized attempt only
5157 passed
0 failures/errors/skips/xfails/xpasses/warnings
empty stderr
exact JUnit/node mapping
candidate fingerprint equal before/after

Do not use a pre-repair topology fingerprint as the final identity. Derive the
live repaired candidate fingerprint from the repaired manifest and repository
state, retain it at opening and closeout, and require exact equality.

AUDIT POSTURE AND PROPORTIONALITY

Use one new private audit root under `/private/tmp`.

Keep evidence proportionate:

- exact commands, results, stdout/stderr, JUnit, node lists, schema inventories,
  probes, manifests, and final report;
- no recursive self-protecting evidence framework;
- no requirement that permanent tests defend themselves against equal-authority
  mutation;
- no reconstruction of historical metadata that was not retained;
- no mutation of the implementation evidence root.

All audit-created databases, repositories, basetemps, pycache prefixes, and
temporary directories must be external to the source repository.

Use `python3 -B`, `PYTHONDONTWRITEBYTECODE=1`, external
`PYTHONPYCACHEPREFIX`, external `TMPDIR`, disabled pytest plugin autoload and
cache provider, warning-as-error posture, deterministic hashing, and umask
0022. These are hygiene requirements; do not turn irrelevant path-history
details into product defects when source/evidence integrity is unaffected.

REVIEW WORKFLOW

After provenance passes, conduct exactly four bounded, non-nesting read-only
perspectives. The parent reconciles them.

1. Contract/schema/privacy/authority
2. Transaction/replay/recovery
3. Evidence DAG/readers/temporal/snapshot semantics
4. Tests/validation/provenance/public surface

A reviewer may inspect and run bounded probes in an external disposable copy.
No reviewer may repair files, delegate further, or contact a network.

If the environment cannot supply a required perspective, return:

RW0_C1_AUDIT_REVIEW_CAPABILITY_UNAVAILABLE

Do not silently substitute a missing required perspective.

CURRENT CONTRACTS

Preserve and audit against these accepted boundaries.

C1 owns:

- private no-contact phase establishment;
- exactly 15 typed evidence kinds;
- one-member admission;
- phase-specific membership;
- relation/profile bindings;
- replay/conflict;
- private guarded readback;
- three-way commit recovery.

C1 owns no:

- evidence completeness;
- C2B decision;
- terminal outcome;
- acceptance latch;
- external source authenticity;
- external permission;
- public API;
- production caller;
- worker/runtime/process authority;
- external contact.

C2, D/E, and Execution Substrate remain unimplemented and externally owned as
documented.

Migration 0004 must be:

- additive;
- sequence 4;
- application generation 2;
- min/max app schema 2/2;
- non-destructive;
- zero seed;
- exact 23 new tables;
- exact 46 new immutability triggers;
- exact four new explicit indexes;
- cumulative 62 user tables, 110 triggers, five explicit indexes.

Migrations 0001–0003 must remain byte-identical.

Exactly 15 kinds are permitted. The cancellation-control classification is not
a C1 member.

Capsule entries, paths, operations, modes, before/after blob digests and
lengths, raw capsule bytes, raw WorkSpec material, blob-map contents, exception
graphs, credentials, and private runtime material must remain outside SQLite.

PROVENANCE GATE

Before source correctness inspection:

1. Verify repository branch/HEAD/tree/parent/upstream/worktree count and clean
   staged/unmerged state.
2. Verify the implementation, mode-repair, and prior-failed-audit evidence
   roots safely, without following symlinks.
3. Verify the implementation and mode-repair self-excluding indexes byte-for-
   byte:
   - row/path set;
   - owner;
   - type;
   - mode;
   - regular-file size and SHA-256;
   - no unsafe or unindexed retained entry.
4. Verify exact recipe source and wrapper identities.
5. Verify the old/new manifest comparison and require that exactly the eight
   authorized physical mode fields changed from 0600 to 0644, with all path,
   classification, size, and content identities unchanged.
6. Run the exact recipe twice with safe output redirection.
7. Require both manifests and complete outputs to be byte-identical and equal
   to the repaired target:
   manifest SHA-256
   a1a9dbeb6c2d014c385bf3214011c8e5a7ea7e95273153f44293af9ff94e9a42;
   complete output SHA-256
   800ab8949d209ac97ba4e7402af9b67f000d625c1643fd706fad8f4284b42ac9.
8. Verify every live candidate entry against the repaired canonical manifest:
   classification, regular type, physical mode 0644, size, SHA-256.
9. Require no path outside the manifest to differ from HEAD.
10. Verify the exact 81-path allowlist and no 82nd path.
11. Verify migrations 0001–0003 against HEAD.
12. Preserve opening and closeout repository and all retained evidence-root
    inventories.

Stop before correctness inspection on any mismatch.

MODE-REPAIR DISPOSITION

The previous audit stopped on the pre-repair mode distribution and performed no
correctness review. The metadata repair supersedes that provenance target. Once
the repaired provenance gate passes, proceed to a complete fresh correctness
audit. Do not reopen the resolved mode issue as a semantic candidate finding.
Any discrepancy in the repaired manifest/evidence remains a provenance or
metadata finding and still blocks correctness.

AUDIT HYPOTHESES

A. Migration/schema integrity

Independently verify:

- resource bytes/checksum/catalog metadata;
- exact sequence and generation;
- every table, ordered column, declared type, nullability, PK, UNIQUE, CHECK,
  FK/action, trigger, and explicit index;
- exact 23/46/4 delta and 62/110/5 cumulative totals;
- zero seed rows;
- fresh generation-2 initialization;
- exact upgrades from every supported prefix ending at 0001, 0002, or 0003;
- fresh versus upgraded `sqlite_schema`, table_xinfo, FK, index, trigger, and
  invariant equivalence;
- older-terminal rejection of newer 0004 where current framework requires it;
- byte identity of 0001–0003.

Do not accept production-derived expected schema as the sole oracle. Build an
independent literal inventory from the frozen owner contract and SQL.

B. Phase identity and establishment

Verify:

- phase_basis_ref/digest and exact K8;
- one phase per basis and per K8;
- no mutable C1 phase/completeness head;
- program/work CAS preimages;
- exact B1 owner relation invocation once;
- one phase relation;
- exactly 14 dense operands;
- nine immutable owner-row bindings;
- one privacy-safe WorkSpec binding;
- four admission snapshots;
- no FK/recovery dependency on mutable current heads or global_stop_current;
- relation/operand/set/phase/result/receipt digest closure;
- receipt written last;
- full in-transaction readback before commit.

Advance selection/effect/delivery/global-stop current state in an external
fixture after phase establishment and prove historical replay/recovery remains
exact.

C. Evidence identity and membership

Verify:

- kind-scoped registry keys;
- legal cross-kind textual ref/digest reuse;
- same-kind alias conflicts;
- stable membership_ref/digest;
- same reusable value admitted into different phases with distinct memberships;
- exact same-phase membership FKs for every C1-evidence relation operand;
- no global-registry-only dependency bypass;
- membership scope binding for global, phase-bound, K8-bound, and existing-
  owner-row-bound values;
- no grouped admission.

D. Complete 15-kind dependency DAG

Exercise all 15 kinds and every branch.

At minimum:

- rank 2 missing/exact rank 1;
- retrieval prefix grammar, predecessor order, terminal non-extension, branch
  rejection, and same-phase dependencies;
- rank 6 dependencies and historical semantic time;
- rank 8 exact declaration dependency;
- rank 9 full rank 1/5/6/7/8 dependency and timestamp equality;
- cancellation response requires exact admitted rank-10 request;
- rank 13 exact two/three rank-12 sequence;
- rank 14 present / finite_failure / absent;
- rank 15 exact Section 41 0-or-9 family;
- missing prerequisite causes zero C1 writes.

Verify legal dependency-closed partial phases do not imply completeness.

E. Relation and operand integrity

Verify:

- phase_establishment versus evidence_membership subject branches;
- relation ranks 0|1;
- ranks 5/7 zero relations;
- ordinary rank 12 one;
- cancellation response rank 12 two;
- every other kind one;
- maximum two; relation overflow at third row;
- maximum 14 operands; overflow at fifteenth row;
- dense ordinals;
- closed proof modes;
- closed operand sources:
  c1_evidence, existing_owner_row, transient_private_binding,
  admission_snapshot_binding;
- immutable owner-row branch has null scope digest;
- exact transient binding kinds:
  work_spec, candidate_capsule_manifest, before_blob_set, after_blob_set,
  wire_protocol_error;
- exact snapshot kinds:
  selection, effect, delivery, global stop;
- no raw private material in any operand row.

Externally mutate operand order, relation version, profile pair, subject
membership, phase pair, proof mode, temporal posture, or binding kind and
require fail-closed behavior.

F. Rank 13 and rank 14

Verify rank 13 is an actual worker-result binding only.

Verify rank 14 exact result-state algebra:

- present: exact rank-13 membership; no failure reason;
- finite_failure: no rank-13 pair; one frozen finite sealed Wire reason;
- absent: neither result nor reason.

Verify all current NWPF classifier outputs are representable, including
result_missing, result_invalid, and process_evidence_incomplete.

Verify finite_failure admission accepts only a real sealed owner error, persists
no exception object/traceback/cause/context, and replay/recovery does not
fabricate a new RW0WireProtocolError.

Verify rank 14 remains NWPF-only and does not persist the cancellation-control
classification or a complete manifest.

G. Temporal semantics

Verify two clocks:

- operation_timestamp as durable admission/commit time;
- relation.evaluated_at as owner semantic time.

Closed temporal registry:

Operation-time relations:
- authority verification;
- subordinate narrowing;
- custody binding;
- retrieval sequence.

For these:
relation.evaluated_at == membership.admitted_at == operation_timestamp.

Subject-time relations:
- rank 6 host qualification;
- rank 9 Capability qualification.

For rank 6:
relation.evaluated_at equals the host qualification value timestamp and is not
later than membership.admitted_at.

For rank 9:
relation.evaluated_at equals both the Capability qualification timestamp and
the exact prerequisite rank-6 host timestamp, and is not later than admission.

Prove rank 9 can be admitted in a later second/transaction than rank 6.
Reject future, noncanonical, missing, or mismatched temporal values before
writes.

Replay and recovery must use persisted time, never the current clock.

H. Privacy and forbidden material

Create controlled distinctive private test values in external disposable
databases, then inspect every table/cell safely.

Require absence of:

- raw WorkSpec body, requirements, exclusions, and path lists;
- capsule entries, paths, modes, per-file digests/lengths, and bytes;
- before/after map keys or per-file content;
- exception object identity, message, args beyond sealed finite reason,
  traceback, cause, context;
- credentials, secrets, endpoints, host/workspace material;
- prompt, response, transcript, model/provider logs;
- process IDs/handles;
- source-authentication, permission, acceptance, or terminal-authority flags.

Require only the frozen safe aggregate bindings.

Do not print controlled private sentinel values in the final report.

I. Transaction authority and ordering

Verify the existing `_CoordinatorMutationTransactionController` is the sole
authority for both C1 mutation and recovery families.

Require:

- no direct sqlite3 import or connection authority in `_sqlite_rw0_c1.py`;
- no second controller;
- no alternate BEGIN/commit/rollback path;
- private concrete writer-session delegation only;
- public WriterSession/StateStore/package protocols unchanged;
- operation guard and mutation slot;
- bound connection and BEGIN IMMEDIATE;
- schema/binding validation;
- writer fencing before receipt disclosure;
- receipt-first replay;
- deterministic reads;
- relation evaluation;
- ordered writes;
- receipt last;
- full readback;
- capability invalidation;
- one commit attempt;
- cleanup and process-control stabilization.

Trace source and use runtime probes/fault injection; do not rely only on source
strings.

J. Replay, conflict, and recovery

Independently exercise:

- exact replay with no writes and no new clock;
- mutation_ref_reuse;
- phase identity collision;
- K8 collision;
- current-state CAS conflict;
- kind-scoped member collision;
- member already admitted;
- missing prerequisite;
- relation failure;
- relation identity collision;
- owner row missing;
- stale writer;
- database integrity failure.

Inject faults at every material read, write, capability invalidation,
precommit, underlying commit, post-underlying-commit, rollback, cursor close,
connection close, operation cleanup, and process-control boundary.

Require exactly:

- committed_exact;
- definitely_not_committed;
- unresolved.

Require no same-writer automatic retry, duplicate phase/member, or duplicate
receipt.

Definitely-not-committed must permit an exact reusable registry/payload to
preexist while proving absence of operation-owned membership/relation/receipt
rows.

K. Readers

Verify exact explicit columns, predicates, order, and limits:

- point/collision reads: LIMIT 2;
- member relations: LIMIT 3;
- relation operands: LIMIT 15;
- bounded helper allowed limits exactly 2,3,15,16,257,258;
- member page: 256 plus overflow row;
- Section 41: exact 0 or 9 with bounded overflow;
- no SELECT *;
- exact tuple/type/cardinality checking;
- capability expiry and process mismatch;
- no public reader and no second read authority.

L. Documentation/status/authority

Inspect all 81 changed paths together.

Require:

- current 0004/C1 status synchronized without rewriting historical tranche
  claims that remain true;
- B1, Wire, Capability, C2A, C2B, Section 41 owners remain unchanged;
- no public/package/StateStore/WriterSession-protocol widening;
- no production caller;
- no C2 closure/latch/decision/terminal state;
- no D/E/ES/Bridge/supporting-repository behavior;
- no external I/O, worker, process, provider, credential, Git, publication, or
  runtime authority.

M. Test and oracle adequacy

Review all nine new test modules and every modified pre-existing test.

Require:

- permanent tests map to finite product claims;
- no test weakens a protected pre-existing invariant merely to pass;
- opening 5087 nodes retained in exact order;
- 70 additions fully explained;
- the three additions in a pre-existing test are causal and non-redundant;
- selected red gate is genuinely causal rather than merely missing the SQL
  file;
- schema, transaction, dependency, temporal, privacy, replay, and recovery
  tests fail under one-predicate external mutants;
- no self-protecting audit framework or coordinated test/oracle mutation threat
  model.

Classify any test gap separately from a candidate semantic defect.

INDEPENDENT VALIDATION ORDER

1. Provenance gate.
2. Static contract/schema/authority inspection.
3. Independent schema and migration-prefix verification.
4. Bounded semantic, transaction, fault, privacy, and reader probes.
5. Fresh focused groups:
   - new C1;
   - migration/schema/fixture;
   - readers/controller/writer/recovery;
   - semantic-owner compatibility;
   - status/architecture/privacy/nonauthority.
6. Fresh candidate collection.
7. Independent clean candidate reconstruction:
   - start from exact HEAD archive;
   - overlay exactly the 81 manifest files;
   - create a fully external Git repository/object database;
   - no alternates and no shared source-object inodes;
   - diagnostic commit of the exact candidate tree.
8. Clean collection and focused checks.
9. If no Critical, High, Medium, or Low candidate/contract blocker remains, run:
   - one live complete suite;
   - one external clean-commit complete suite.
10. Closeout and exact recipe reproduction.

If deterministic material blockers are established before complete validation,
the complete suites may be withheld. State that clearly. Do not substitute the
retained implementation suite for an independent run.

FINDING CLASSIFICATION

For every finding report:

- ID;
- type;
- severity: Critical / High / Medium / Low / Observation;
- current contract or strategic target;
- exact path and line;
- evidence and reproduction;
- impact;
- required correction;
- uncertainty;
- classification:
  candidate defect, contract defect, test/oracle defect, audit-harness defect,
  report defect, or environment defect.

Do not allow an audit-harness or environment issue to masquerade as a candidate
defect, and do not let broad passing tests override a deterministic contract or
transaction failure.

CLOSEOUT

At closeout:

- reproduce the exact manifest twice;
- compare repository opening/closing branch/HEAD/upstream/topology/status/diff;
- compare implementation, mode-repair, and prior-failed-audit evidence
  opening/closing inventories;
- verify no source index mutation, locks, operations, repository residue,
  database, journal, pycache, archive, build output, or generated manifest;
- remove only audit-created transient external paths;
- retain material evidence;
- use mode 0700 directories and 0400 retained files;
- create a self-excluding audit index last and verify it independently.

Do not modify the implementation, mode-repair, or prior failed-audit evidence
roots.

VERDICT

Return:

ACCEPT

and exactly:

COORDINATOR_RW0_C1_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE

only when provenance, contract, implementation, validation, privacy, recovery,
authority, and evidence all pass with no Critical, High, Medium, or Low
finding.

Otherwise return:

BLOCK

with a severity-ranked ledger and no repair.

REQUIRED FINAL STATEMENTS

REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
PUBLIC_API_NOT_WIDENED
RW0_C2_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
