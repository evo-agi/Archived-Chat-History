PROMPT_ID

RW0_C1_INDEPENDENT_AUDIT_FINDINGS_REPAIR_V1

TITLE

Coordinator RW0-C1 — repair commit-uncertainty recovery, post-commit cleanup
normalization, CAS ordering, owner-reader fault propagation, and missing causal
tests after the first substantive independent audit

ENGAGEMENT TYPE

Bounded parent-only workspace-write findings repair in the original RW0-C1
implementation conversation.

Do not delegate to subagents.

This is not an architecture reset and not a broad implementation pass. Preserve
the accepted C1/C2 decomposition, migration 0004, 15-kind evidence inventory,
privacy model, schema topology, transaction-controller ownership, and all
unaffected implementation bytes.

Do not stage, commit, push, create a PR, merge, tag, release, deploy, fetch,
contact a remote/live system, install dependencies, invoke a product
worker/model, modify a supporting repository, or migrate an operator database.

Print the complete substantive report inline. Evidence paths may be
supplementary only.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED OPENING IDENTITY

Require exactly:

branch:
codex/rw0-c1-durable-evidence-v1

HEAD:
047563de5a443b0f8323401c92979ae2e444d2ed

HEAD tree:
4ff9ee4a710af13447e3ed8699339a51255ff720

sole parent:
dd12b23762dc761736e55a1abfde12dd3ec23551

subject:
feat: add RW0-B2 cancellation-control evidence (#6)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

staged/unmerged:
0/0

candidate paths:
exactly 81, all regular physical mode 0644

current repaired canonical manifest SHA-256:
a1a9dbeb6c2d014c385bf3214011c8e5a7ea7e95273153f44293af9ff94e9a42

tracked textual diff SHA-256:
c9e81fe9e3e82a39a5a239277d5187f67ea4795e285773b60f9b9afd4d858f54

current complete recipe output SHA-256:
800ab8949d209ac97ba4e7402af9b67f000d625c1643fd706fad8f4284b42ac9

current nodes:
5157

current ordered node SHA-256:
efd65837c5c0e05bcd720dc52be6bfd32aa1f861392496864900fb083e0971df

No fetch is authorized.

RETAINED EVIDENCE ROOTS

Verify read-only before mutation and preserve unchanged:

Original implementation:
/private/tmp/ge-coordinator-rw0-c1-implementation.Zcopmg
index SHA-256:
cd1ad5ea72ef20a774fd470e38f14882a25f99af94db970c4506c62d4a4cc2b4

Mode repair / validation reset:
/private/tmp/ge-coordinator-rw0-c1-mode-repair.k6Pxw5
index SHA-256:
5b30767c439a982e209c765f93c775547709555f5305697817a1b335e1bf2cc8

First provenance-stop audit:
/private/tmp/ge-coordinator-rw0-c1-independent-audit.6Cd8VB
index SHA-256:
3929be307c05a532c491f5f520bad4d76cde702d7e0b41460cf0c8ab90373b25

Substantive independent audit:
/private/tmp/ge-coordinator-rw0-c1-independent-audit.bYt6vjqX
index SHA-256:
c276c664922dc4ef87e7418c6657aaf9d61ddb05c643666019ff85c86796168e

Do not modify, clean, re-index, or “repair” any retained root.

AUDIT VERDICT TO REPAIR

The substantive audit returned BLOCK with:

Candidate defects:

1. RW0-C1-AUD-001 — High
   Commit-uncertainty recovery input is not caller-constructible.

2. RW0-C1-AUD-002 — High
   definitely_not_committed is unsound for prerequisite loss and registry
   aliases.

3. RW0-C1-AUD-003 — High
   post-commit cleanup failures escape the commit-resolution algebra.

4. RW0-C1-AUD-004 — Medium
   actual current program/work CAS occurs after registry/member/dependency
   collision probes.

5. RW0-C1-AUD-005 — Medium
   owner-reader integrity and operational failures collapse to semantic
   owner_row_missing.

Test/oracle defects:

6. RW0-C1-AUD-006 — Medium
   permanent recovery/cleanup/ordering/reader-fault tests omit those material
   boundaries and use direct SQLite inspection to obtain a recovery-only
   membership digest.

7. RW0-C1-AUD-007 — Low
   exact equality for rank-6/rank-9 semantic evaluation time is not causally
   protected.

Historical report defect:

8. RW0-C1-AUD-008 — Low
   the original implementation red gate proved only a missing migration
   resource.

AUD-008 cannot be rewritten historically. Preserve it as historical,
non-creditable implementation evidence. This repair must retain a genuinely
causal test-first red gate and make that new repair evidence acceptance-bearing.

ARCHITECTURAL DISPOSITION

Do not reopen:

- C1/C2 decomposition;
- migration 0004 identity or schema family;
- 23 new tables / 46 triggers / 4 explicit indexes;
- cumulative 62 / 110 / 5;
- exactly 15 evidence kinds;
- stable membership_ref/membership_digest;
- kind-scoped evidence identity;
- same-phase relation operands;
- rank-13/rank-14 semantics;
- temporal and mutable-snapshot contracts;
- capsule privacy;
- one existing transaction controller;
- no public API or production caller;
- no C2, D/E, ES, Bridge, worker, provider, process, or external-contact work.

The audit found no contract/schema/privacy/authority defect in those areas.

PRIMARY ENGINEERING DECISIONS

A. CALLER-CONSTRUCTIBLE RECOVERY SELECTOR

Add or revise one private evidence-admission recovery selector so it is
constructible before apply without reading SQLite.

Use a private immutable value with an exact schema, for example:

governed-execution.nwp-rw0-c1-evidence-admission-recovery-selector.v1

Its exact ordered semantic fields must include:

- schema_id
- mutation_ref
- command_digest
- phase_basis_ref
- phase_basis_digest
- preassigned_membership_ref
- kind_rank
- value_ref
- value_digest
- value_schema_id
- prerequisite_member_locators
- owner_row_locators only where they are immutable recovery prerequisites
- selector_digest

It must not include or require:

- membership_digest;
- admitted_at;
- relation-set digest;
- result digest;
- receipt digest;
- direct database observations;
- current mutable-head snapshots;
- raw private transient operands.

Provide a pure private constructor from the already validated admission command
before transaction entry. It must perform no database read, clock read, I/O, or
authority action.

The original command or selector must be retainable by the legitimate caller
when apply raises commit_outcome_unknown.

For committed recovery:

1. Read receipt by mutation_ref.
2. Verify mutation family and command digest.
3. Verify receipt phase, preassigned membership ref, kind and value identity
   against the selector.
4. Obtain membership_digest, admitted_at, relation/result/graph identities from
   committed durable rows and verify the complete family.
5. Return committed_exact only on exact agreement.

Do not require the caller to guess or directly query membership_digest.

Ensure phase-establishment recovery is likewise caller-constructible from
stable pre-apply command/locator evidence. Do not regress the existing phase
family.

B. SOUND DEFINITELY-NOT-COMMITTED

Evidence-admission recovery may return definitely_not_committed only when all
of the following are proved:

1. The prerequisite phase exists, is exact, and is readable.
2. Every immutable prerequisite membership locator in the selector exists and
   is exact.
3. Every immutable owner-row prerequisite required for a safe retry is exact.
   Do not require mutable current program/work/head/global-stop snapshots to
   remain unchanged; future retry will re-evaluate current CAS separately.
4. Receipt by mutation_ref is absent.
5. The preassigned membership_ref is absent.
6. No membership exists for the exact phase/kind/value ref route.
7. No membership exists for the exact phase/kind/value digest route.
8. All operation-owned relation refs/operands derived from the selector are
   absent.
9. Registry/payload posture is one of:
   - both absent; or
   - exact reusable registry plus exact typed payload/children.
10. There is no same-kind ref alias, digest alias, malformed registry row,
    missing typed payload, partial child family, or other identity collision.

Return unresolved for:

- missing prerequisite phase;
- missing/corrupt prerequisite membership;
- conflicting registry alias;
- partial registry/payload/child family;
- any membership/relation/receipt fragment;
- malformed or unreadable state;
- inability to prove absence.

An exact reusable registry/payload may preexist and does not by itself defeat
definitely_not_committed.

Update recovery probes, readers, collision queries, family reconstruction, and
content-free results consistently.

C. POST-COMMIT CLEANUP ALGEBRA

Preserve one commit attempt and the existing sole controller.

Once the underlying commit attempt has begun, every ordinary exception before
the complete close-proof finishes must be normalized to:

commit_outcome_unknown

This includes failures during or after:

- committed-result publication inside the controller;
- nominal-capability finalization;
- mutation-slot close;
- operation-lease close;
- connection/controller cleanup;
- process-control stabilization;
- writer-session post-operation cleanup.

Do not emit:

- database_integrity_failure for a post-commit close failure;
- mutation_failed for a post-commit close failure;
- raw RuntimeError or another arbitrary cleanup exception.

A proved committed result may be returned only after the complete controller
and writer-session close proof succeeds.

Before commit begins, retain the existing safe distinction among semantic
conflict, database_integrity_failure, and mutation_failed.

Preserve governing process-control behavior according to existing repository
contracts; ordinary cleanup failures must never escape unsanitized.

D. CURRENT-STATE CAS ORDER

On a receipt miss for fresh evidence admission, use this semantic order:

1. exact prerequisite phase lookup and integrity;
2. actual current program/work owner reads;
3. validate the command’s expected program/work CAS;
4. only after current-state CAS succeeds:
   - registry probes;
   - membership probes;
   - prerequisite member reads;
   - semantic collision probes;
   - relation/owner reads and evaluation.

Exact replay through an existing receipt remains receipt-first and does not
require current heads to retain historical values.

A stale current-state request must return:

current_state_conflict

before disclosing:

- member_already_admitted;
- member_identity_collision;
- missing_prerequisite_member;
- relation identity/collision details.

Add an explicit call-order test proving the CAS hook executes and collision
probes do not execute after CAS failure.

E. OWNER-READER ERROR PROPAGATION

Only an actual reader result of None maps to:

owner_row_missing

If an owner reader raises an already sanitized SQLiteMutationStoreError, preserve
it unchanged, including:

- database_integrity_failure;
- mutation_failed;
- commit_outcome_unknown where applicable.

Preserve process-control exceptions under existing repository rules.

Do not catch broad reader failures and turn them into semantic absence.

F. PERMANENT TEST REPAIR

Strengthen ordinary product tests. Do not create self-protecting tests or an
audit framework.

Required causal tests:

1. Recovery selector:
   - pure, caller-constructible before apply;
   - no DB read;
   - no membership digest needed;
   - forced ambiguous commit resolves committed_exact from the selector.

2. definitely_not_committed matrix:
   - exact phase + all operation rows absent + registry absent -> DNC;
   - exact phase + exact reusable registry/payload + operation rows absent ->
     DNC;
   - missing phase -> unresolved;
   - missing prerequisite member -> unresolved;
   - same-kind ref alias -> unresolved;
   - same-kind digest alias -> unresolved;
   - registry-only or payload-only partial family -> unresolved;
   - membership/relation/receipt fragment -> unresolved.

3. Post-commit cleanup:
   - underlying commit succeeds, then mutation-slot close fails;
   - underlying commit succeeds, then operation-lease close fails;
   - relevant controller/connection/writer cleanup failure after commit;
   - every case yields commit_outcome_unknown;
   - committed rows are recoverable with the pre-retained selector;
   - no raw exception leaks.

4. CAS precedence:
   - stale actual current program/work state plus an existing membership or
     registry collision;
   - result is current_state_conflict;
   - CAS is invoked before collision probes;
   - collision details are not disclosed.

5. Owner-reader faults:
   - None -> owner_row_missing;
   - database_integrity_failure propagates;
   - mutation_failed propagates;
   - cursor/SELECT cleanup fault cannot become owner_row_missing.

6. Temporal equality:
   - rank 6 evaluated_at exactly equals admitted_at and succeeds through
     persistence/readback;
   - rank 9 semantic evaluated_at exactly equals admitted_at and succeeds,
     while still equal to prerequisite rank-6 semantic time;
   - later rank-9 admission with earlier equal rank-6/rank-9 semantic time also
     remains covered;
   - change from `>` to `>=` in the future-boundary predicate must fail an
     external one-predicate mutant.

7. Remove direct-database recovery-oracle dependence from acceptance-bearing
   tests. Tests may inspect an external disposable database for independent
   assertions, but the caller path to recovery must use only the pre-retained
   selector and public-to-the-private-subsystem recovery contract.

G. TEST-FIRST REPAIR CHRONOLOGY

Before source repair:

1. Add the new/strengthened tests only.
2. Preserve candidate source bytes.
3. Run one selected repair red gate.
4. Require deterministic expected failures covering AUD-001 through AUD-005.
5. Separate test-fixture/harness failures from intended product failures.
6. Repair any invalid tests before production changes.
7. Freeze the credited red node list, stdout/stderr, JUnit, and candidate
   fingerprint.

AUD-007 equality tests may already pass on the current code; record them as
green boundary additions and retain a separate external mutant demonstrating
that the strictness mutation survives before the test repair and is killed
after it.

Do not rewrite or delete historical implementation/audit evidence.

BOUNDED REPAIR ALLOWLIST

Only these repository paths may change:

Documentation:

.docs/rw0-c1-durable-evidence.md
.docs/sqlite-operations-and-recovery.md
.docs/sqlite-threat-model.md
.docs/writer-session-authority.md

Production:

src/ge_nwp_coordinator/_rw0_c1_semantic_values.py
src/ge_nwp_coordinator/_rw0_c1_mutation_contracts.py
src/ge_nwp_coordinator/_sqlite_rw0_c1.py
src/ge_nwp_coordinator/sqlite_transition_transaction.py
src/ge_nwp_coordinator/sqlite_writer_session.py

Tests:

tests/test_rw0_c1_semantic_values.py
tests/test_rw0_c1_mutation_contracts.py
tests/test_rw0_c1_private_atomic_persistence.py
tests/test_rw0_c1_recovery.py
tests/test_rw0_c1_writer_session_delegation.py
tests/test_b3c4c_prerequisite_contract.py
tests/test_b2a_writer_session_contract.py
tests/test_sqlite_b2c_writer_session.py

Maximum:
17 repository paths

A listed path may remain byte-identical if no causal change is needed. No path
outside this allowlist may change.

If a required correction needs another path, stop with:

RW0_C1_AUDIT_FINDINGS_REPAIR_SCOPE_CONFLICT

Do not modify:

- migration 0004 SQL or sqlite_migration.py;
- row/table schema modules unless an exact schema contradiction is established;
- B1, Wire, Capability, C2A, C2B, or Section 41 owner modules;
- migrations 0001–0003;
- package exports, StateStore, public WriterSession protocol;
- any of the other 81 candidate paths;
- supporting repositories.

VALIDATION ORDER

Use one new external evidence root:

/private/tmp/ge-coordinator-rw0-c1-audit-findings-repair.XXXXXX

Use:

umask 0022
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
unique evidence-root PYTHONPYCACHEPREFIX for every Python process
distinct evidence-root TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
GIT_OPTIONAL_LOCKS=0
python3 -B
-p no:cacheprovider
-W error

Run serially with external basetemp/JUnit/stdout/stderr.

After test-first red and source repair:

1. Selected causal repair tests.
2. Complete changed C1 test files.
3. All nine C1 test modules.
4. Reader/controller/writer/recovery compatibility:
   - test_b2a_writer_session_contract.py
   - test_sqlite_b2c_writer_session.py
   - test_b3c4c_prerequisite_contract.py
   - all relevant existing transaction/controller/cleanup tests, without
     modifying protected tests.
5. Migration/schema/fixture compatibility.
6. B1/Wire/Capability/C2A/C2B/Section 41 owner compatibility.
7. Architecture/status/privacy/nonauthority compatibility.
8. External one-predicate probes for each repaired finding.
9. Final collection.
10. One official complete-suite attempt over tests.

Every credited run requires:

- return code 0;
- all collected cases passed;
- zero failures/errors/skips/xfails/xpasses/warnings;
- empty stderr;
- parseable JUnit;
- zero duplicate/unmapped cases;
- caller/child umask 0022;
- unchanged candidate fingerprint before/after.

If complete-suite attempt 001 fails:

- preserve it;
- classify candidate versus tooling/environment;
- if repairable within the 17-path scope, repair and rerun affected focused
  groups, refreeze/recollect, and permit exactly one attempt 002;
- no third attempt.

NODE RECONCILIATION

Opening candidate node list is 5157 nodes at:

efd65837c5c0e05bcd720dc52be6bfd32aa1f861392496864900fb083e0971df

At final collection require:

- all 5157 opening nodes retained in identical relative order;
- zero removals or renames;
- zero new skip/xfail;
- every addition belongs to the allowed touched test files and is explicitly
  listed;
- no volume-only duplicate parametrizations;
- live and clean collection, if a clean copy is produced, are identical.

PROVENANCE AND CLOSEOUT

Use the exact recipe:

recipe ID:
governed-execution.audit-patch-manifest.v1

source size:
3945 bytes

source SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

Use the exact safe redirection wrapper already verified in the retained
implementation/mode-repair evidence. Do not modify the historical sink.

At closeout:

- verify branch/HEAD/upstream/worktree/topology;
- verify exact final candidate path set remains 81 and every path mode 0644;
- verify only the bounded repair subset differs from the repaired opening
  candidate;
- verify no staged/unmerged/lock/operation/residue;
- `git diff --check`;
- verify migrations 0001–0004 and all protected owner bytes as required;
- verify public/package/StateStore/WriterSession protocol unchanged;
- run the exact recipe twice;
- require byte-identical manifests and complete output;
- report new manifest, textual-diff, complete-output, file count, and exact
  opening-to-final repair delta;
- preserve all prior evidence roots unchanged;
- remove only repair-created transient external paths;
- create a self-excluding evidence index last and independently reverify it.

HISTORICAL EVIDENCE TREATMENT

The old implementation red gate remains historical and non-creditable for
substantive causality. Do not claim it was repaired.

The new findings-repair red gate and external probes become the acceptance-
bearing causal evidence for this repair.

The prior independent audit remains valid evidence of the defects and must not
be altered.

SUCCESS TOKEN

Return exactly:

COORDINATOR_RW0_C1_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT

only if:

- all five candidate defects are repaired;
- both test/oracle defects are repaired;
- no architecture/schema/privacy/authority scope widened;
- all validation is green;
- final provenance and cleanup are complete;
- no independent re-audit is claimed.

FINAL INLINE REPORT

Use:

# Outcome
# Opening identity and retained evidence
# Finding-by-finding repair
# Caller-constructible recovery selector
# Sound definitely-not-committed proof
# Post-commit cleanup algebra
# Current-state CAS ordering
# Owner-reader fault propagation
# Permanent-test and mutant closure
# Test-first repair chronology
# Exact touched-path delta
# Focused validation
# Node reconciliation
# Complete-suite validation
# Provenance and cleanup
# Authority and nonclaims
# Remaining seams
# Confidence

Required final statements:

INDEPENDENT_REAUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
MIGRATION_SCHEMA_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
STATESTORE_PUBLIC_SURFACE_NOT_WIDENED
WRITERSESSION_PUBLIC_PROTOCOL_NOT_WIDENED
RW0_C2_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
