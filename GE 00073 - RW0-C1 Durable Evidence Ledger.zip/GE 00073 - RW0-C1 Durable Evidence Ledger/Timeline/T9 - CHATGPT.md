# Disposition

**Proceed to a fresh, read-only independent audit. Do not repair, stage, or commit this candidate yet.**

The implementation report is internally consistent with the frozen contract:

- exactly **11 changed paths**: eight tracked modifications and three additions;
- the final Wire source is **126,092 bytes** with SHA-256  
  `fdb97043f4f93620ecf5be43e78ebda0553e2792a219ab846789ad586790c776`;
- the Capability boundary changed only the expected P01 size and digest;
- all four existing Wire test modules reportedly remained byte-identical;
- the existing NWPF v1 identity and command/result vectors remained unchanged;
- the new profile reproduces the frozen **12,014-byte manifest**, **12,154-byte identity**, and digest  
  `4d6f84552b852a4c4073b4238591afd271072f648424eca9e744def436165288`;
- the 28 added nodes match the frozen test plan exactly:
  ```text
  values:      7
  relations:   9
  boundaries: 12
  ```
- all 5,059 opening nodes were retained in order;
- the final collection is **5,087 nodes** with SHA-256  
  `fe756529f88a3c44c31a402d2266b00b14993f420b76fa2af15595103599580c`;
- the complete suite passed **5,087/5,087** on its single authorized run;
- no persistence, transport, process control, public API, production caller, or RW0-C/D/E capability was introduced.

The early failed and superseded runs appear transparently disclosed rather than hidden. The local upstream-metadata adjustment before the recorded baseline is a provenance observation, not presently a candidate-byte defect, but the independent audit should confirm the resulting branch and worktree identity.

# Principal independent-audit risks

The audit should concentrate on semantic causality rather than simply repeating the green suite.

The highest-value checks are:

1. **V1 preservation**  
   Mechanically prove that all pre-existing Wire code is unchanged except for the two names added to the existing C2A import and the appended cancellation-control block. Confirm the four old Wire tests and all B1/C2A semantic tests are byte-identical.

2. **Independent profile identity**  
   Compare the production manifest, the test-owned literal, and the retained freeze literal; independently recompute the canonical bytes and digest. Verify returned mapping graphs are deeply fresh.

3. **Relation orientation**  
   Independently exercise all author/validation/review and direct-local/ES combinations, especially target-versus-cancellation fence swaps, sibling manifests, cross-attempt coordinates, and route/source mismatches.

4. **Classifier precedence**  
   Reconstruct a test-owned oracle for every coexistence case. Particular attention should go to:
   - acknowledgement or rejection without a request;
   - acknowledgement plus rejection;
   - rejection plus exit;
   - duplicate versus unrelated/conflicting evidence;
   - no request with target process evidence;
   - exit codes `-255`, `0`, and `255`.

5. **Reconstruction and work accounting**  
   Establish that every occurrence is charged and reconstructed exactly once, that common operands are not double-reconstructed by nested public calls, and that semantic reads use reconstructed locals. Independently derive and test all maximum and one-under budgets.

6. **Privacy and foreign exceptions**  
   Probe malformed manifests, aliases, cycles, hostile equality, foreign exceptions, and process-control exceptions without allowing caller material into public errors or classifications.

7. **P01 and the 11-path ceiling**  
   Verify the Capability test changed only the two P01 literal fields and that no twelfth repository path changed.

# Audit handoff

Start a **new Codex conversation** and send this prompt:

:chatgpt-content-reference{index="0"}

```text
Filename:
Coordinator_RW0_B2_Cancellation_Control_Fresh_Independent_Audit_Prompt.txt

Size:
23,488 bytes

SHA-256:
fe9d89fbe0885ab83e0b13c7171a236f040913ce90f6e5da1c03c0fd9c3e3e7a
```

Also attach the exact provenance recipe already used for implementation:

:chatgpt-content-reference{index="1"}

```text
Size:
3,945 bytes

SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

The audit prompt is bound to:

```text
Branch:
codex/rw0-b2-cancellation-control-v1

HEAD:
dd12b23762dc761736e55a1abfde12dd3ec23551

Expected topology:
11 dirty paths
8 tracked modifications
3 untracked additions
0 staged
0 unmerged

Final Wire source:
126,092 bytes
fdb97043f4f93620ecf5be43e78ebda0553e2792a219ab846789ad586790c776

Profile digest:
4d6f84552b852a4c4073b4238591afd271072f648424eca9e744def436165288

Final nodes:
5,087
fe756529f88a3c44c31a402d2266b00b14993f420b76fa2af15595103599580c

Implementation evidence root:
/private/tmp/rw0-b2-cancellation-control-implementation.PxLuO0

Evidence-index SHA-256:
185cdf69863cee3a8390a7f7e3c0412275376fd2029e8a863585c4b176d09443
```

The only accepting result is:

```text
ACCEPT

COORDINATOR_RW0_B2_CANCELLATION_CONTROL_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Only that result should open the commit/push/PR gate. RW0-C remains blocked until this B2 tranche is independently accepted and merged.

**Source:** Codex’s implementation report supplied in this turn.  
**Confidence:** High that the implementation is ready for independent audit; acceptance remains unresolved until v1 preservation, relation/classifier causality, reconstruction/work accounting, P01 provenance, and the 11-path boundary are independently verified.
