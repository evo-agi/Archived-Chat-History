# Baseline and inspection boundary

The required baseline is exact:

| Field | Observed value |
|---|---|
| Branch | `trunk_dev` |
| HEAD | `047563de5a443b0f8323401c92979ae2e444d2ed` |
| Tree | `4ff9ee4a710af13447e3ed8699339a51255ff720` |
| Sole parent | `dd12b23762dc761736e55a1abfde12dd3ec23551` |
| Subject | `feat: add RW0-B2 cancellation-control evidence (#6)` |
| Upstream | `origin/trunk_dev` |
| Ahead/behind | `0/0` |
| Worktree/index/untracked/unmerged | clean |
| Worktrees | one |

Inspection was parent-only and read-only. I re-read the requested C1/B1/B2/C2A contracts, semantic owners, migration patterns, transaction controller, readers, replay/recovery surfaces, and current boundary tests. No fetch, database open, migration, test run, node collection, remote contact, or supporting-repository inspection occurred.

# Preserved C1 architecture

This closure preserves all frozen C1 decisions:

- The C1/C2 split remains unchanged.
- C1 remains private, no-contact durable phase/evidence authority.
- Exactly 15 evidence kinds and the accepted dependency DAG remain unchanged.
- Admission remains single-member.
- `membership_ref` and `membership_digest` remain stable identity.
- C1-evidence operands retain a full same-phase membership foreign key.
- Rank 13 remains an actual worker-result binding only.
- Rank 14 remains `present | finite_failure | absent`.
- Member relations remain bounded to two, with `relation_rank IN (0,1)` and reader `LIMIT 3`.
- `phase_basis_ref` and `phase_basis_digest` remain the canonical vocabulary.
- `_CoordinatorMutationTransactionController` remains the sole transaction authority.
- Evidence identity remains kind-scoped.
- SQLite receives no capsule entries, WorkSpec body, blob map, file metadata, exception object, or other raw private operand.
- Migration `0004` remains additive, generation 2, zero-seed, and contains no C2 state.
- Existing owner semantics, migrations `0001`–`0003`, public APIs, package exports, and supporting repositories remain unchanged.

The accepted member relation counts remain:

- Ranks 5 and 7: zero relations.
- Rank 12 ordinary observation: one relation.
- Rank 12 cancellation acknowledged/rejected: two relations.
- Every other rank: one relation.

The phase identity continues to bind the exact K8:

1. `program_ref`
2. `semantic_attempt_ref`
3. `candidate_ref`
4. `effect_intent_ref`
5. `author_command_ref`
6. `attempt_fence_ref`
7. `effect_fence_ref`
8. `delivery_attempt_ref`

# Phase-establishment relation representation

The existing common relation tables can represent phase establishment without weakening member integrity. No separate phase-relation table is needed.

`rw0_relation_bindings.subject_type` is closed to:

```text
phase_establishment
evidence_membership
```

The phase relation has:

```text
relation_schema_id:
governed-execution.nwp-rw0-c1-phase-entry-basis-relation.v1

relation_version:
1

proof_mode:
relation_attested_at_admission

profile_ref:
null

profile_digest:
null

relation_rank:
0

operand_count:
14
```

Its deterministic reference is:

```text
rw0-c1-phase-relation.<phase_basis_digest>
```

The reference is not caller-selected. Its prefix plus the 64-character digest remains within the existing safe-reference ceiling.

The exact ordered phase operands are:

| Ordinal | Operand role | Source |
|---:|---|---|
| 0 | `selection_disposition` | existing owner row |
| 1 | `selection_receipt` | existing owner row |
| 2 | `selection_head` | existing owner row |
| 3 | `selected_proposal` | existing owner row |
| 4 | `selected_artifact` | existing owner row |
| 5 | `work_spec_binding` | existing owner row |
| 6 | `transient_work_spec` | transient private binding |
| 7 | `attempt_fence` | existing owner row |
| 8 | `author_effect_fence` | existing owner row |
| 9 | `author_command` | existing owner row |
| 10 | `author_delivery` | existing owner row |
| 11 | `effect_head` | existing owner row |
| 12 | `delivery_head` | existing owner row |
| 13 | `global_stop_current` | existing owner row |

Those operands reconstruct the exact arguments of `validate_phase_entry_basis(...)`: the disposition and receipt reconstruct the selection result; the selection head reconstructs the L34 lineage; the persisted WorkSpec binding supplies the safe projection; the transient WorkSpec supplies the full owner value; the remaining rows reconstruct the fences, command, delivery, heads, and global stop.

The digest order is acyclic:

1. Validate and bind all 14 semantic operands.
2. Compute the operand-set digest without `relation_digest` or any operand row digest.
3. Compute the phase relation semantic digest.
4. Compute the phase relation-set digest from the single rank-0 relation pair.
5. Compute the phase graph digest.
6. Compute the phase row digest.
7. Compute the relation row digest.
8. Compute the operand row digests.
9. Compute the result and receipt digests.

The common relation-set contract is:

```text
schema:
governed-execution.nwp-rw0-c1-relation-set.v1

domain:
governed-execution.nwp-rw0-c1-relation-set.v1.identity
```

Its semantic payload is:

```text
schema_id
phase_basis_ref
subject_type
subject_ref
relations:
  ordered tuples of
    relation_rank
    relation_ref
    relation_digest
```

For phase establishment, `subject_ref = phase_basis_ref` and the relation list contains exactly the rank-0 phase relation. For membership, `subject_ref = membership_ref`. `membership_digest` is deliberately excluded so member construction remains acyclic.

The operand-set contract is:

```text
schema:
governed-execution.nwp-rw0-c1-relation-operand-set.v1

domain:
governed-execution.nwp-rw0-c1-relation-operand-set.v1.identity
```

It binds `phase_basis_ref`, `relation_ref`, `operand_count`, and the ordered semantic operand fields. It excludes `relation_digest` and `operand_row_digest`.

The phase relation digest uses:

```text
domain:
governed-execution.nwp-rw0-c1-phase-entry-basis-relation.v1.identity
```

and binds:

```text
relation_ref
phase_basis_ref
phase_basis_digest
subject_type
relation_rank
relation_version
proof_mode
profile_ref
profile_digest
operand_count
operand_set_digest
```

It does not bind the phase row digest, phase graph digest, relation-set digest, or relation row digest.

The phase graph uses:

```text
domain:
governed-execution.nwp-rw0-c1-phase-graph.v1.identity
```

and binds the phase pair, ordered K8, `relation_count = 1`, relation-set digest, establishment mutation reference, and establishment timestamp.

The phase row carries `relation_count = 1`, the exact relation-set digest, graph digest, and row digest. It does not foreign-key back to the relation row. The relation row instead foreign-keys to the phase row, permitting phase-first insertion without a cyclic FK.

# Transient private binding vocabulary

The manifest-only operand source is removed. The closed source vocabulary is:

```text
c1_evidence
existing_owner_row
transient_private_binding
```

`transient_private_binding` has exactly five binding kinds:

```text
work_spec
candidate_capsule_manifest
before_blob_set
after_blob_set
wire_protocol_error
```

Every transient branch persists only:

```text
transient_binding_kind
transient_error_reason
operand_schema_id
operand_ref
operand_digest
operand_scope_digest
```

`transient_error_reason` is non-null only for `wire_protocol_error`.

The canonical command binds the corresponding schema/ref/digest/scope tuple and, when applicable, the finite reason. The raw private object is a hidden, noncanonical operation operand. Before any write, the private runtime must:

1. require its exact owner type;
2. reconstruct or recompute its semantic identity;
3. compare that identity with the canonical command binding;
4. invoke the relevant owner relation with the actual object;
5. reject any mismatch before constructing a write plan.

No transient row is evidence identity, custody, a retrievable body, or an authorization record.

# Exact binding schemas and digest domains

All canonical JSON digests use:

```text
SHA-256(
  UTF-8(domain)
  || 0x00
  || UTF-8(canonical JSON payload)
)
```

Canonical JSON uses sorted keys, compact separators, UTF-8, `ensure_ascii=False`, `allow_nan=False`, exact built-in scalar types, preserved list order, and no Unicode normalization.

The bindings are:

| Kind | `operand_schema_id` | `operand_ref` | `operand_digest` | `operand_scope_digest` |
|---|---|---|---|---|
| `work_spec` | `governed-execution.nwp-rw0-c1-transient-work-spec-binding.v1` | exact owner `work_spec_ref` | exact owner `work_spec_digest` | exact `work_spec_safe_projection_digest` |
| `candidate_capsule_manifest` | `governed-execution.nwp-candidate-capsule-manifest.v1` | exact `capsule_manifest_ref` | exact `portable_capsule_digest` | exact `authorized_path_scope_digest` |
| `before_blob_set` | `governed-execution.nwp-rw0-c1-transient-before-blob-set-binding.v1` | `rw0-c1-before-blob-set.<digest>` | opaque aggregate digest | `authorized_path_scope_digest` |
| `after_blob_set` | `governed-execution.nwp-rw0-c1-transient-after-blob-set-binding.v1` | `rw0-c1-after-blob-set.<digest>` | opaque aggregate digest | `authorized_path_scope_digest` |
| `wire_protocol_error` | `governed-execution.nwp-rw0-c1-transient-wire-protocol-error-binding.v1` | `rw0-c1-wire-error.<digest>` | finite-error binding digest | fixed wire-profile digest |

`work_spec`

- The semantic value remains governed by:
  `governed-execution.nwp-work-spec.v1.identity`.
- The raw `WorkSpecV1` must recompute to the exact command-bound owner ref and digest.
- Its safe projection must equal the existing durable `work_spec_safe_projection_digest`.
- Phase establishment and rank-3 transient WorkSpec use this same binding.
- No objective, requirement, exclusion, or path list is persisted.
- C2 does not obtain the raw WorkSpec from C1; its durable author command and phase evidence remain the operational boundary.

`candidate_capsule_manifest`

- The semantic digest domain remains:
  `governed-execution.nwp-candidate-capsule-manifest.v1.identity`.
- The actual `CandidateCapsuleManifestV1` must validate and match the command tuple before writes.
- `candidate_ref` remains bound by the phase/member graph and is not encoded as a manifest entry.
- No capsule entry, path, mode, per-file digest, length, or bytes are persisted.
- Where C2 later requires a full manifest, it must receive the transient manifest through the separately governed operation/custody path and verify this binding. The C1 row is not custody.

`before_blob_set` and `after_blob_set`

Their digest domains are respectively:

```text
governed-execution.nwp-rw0-c1-transient-before-blob-set-binding.v1.identity
governed-execution.nwp-rw0-c1-transient-after-blob-set-binding.v1.identity
```

After the owner has accepted the exact built-in `dict[str, bytes]`, the private binary preimage is:

```text
UTF-8(authorized_path_scope_digest)
|| 0x00
|| u32be(entry_count)
|| for each key in ascending UTF-8 byte order:
     u32be(key_byte_length)
     || UTF-8(key)
     || u64be(blob_byte_length)
     || raw_blob_bytes
```

The final digest is the domain UTF-8 bytes, `0x00`, and that private preimage under SHA-256.

The current owner requires exactly the three fixed authorized paths, so the C1-v1 maximum—and current valid cardinality—is three. Keys are not normalized. Before and after are separated by distinct schema/domain/ref prefixes.

Only the aggregate digest, deterministic ref, and authorized-path scope digest persist. No count, key, path, per-file digest, per-file length, or bytes persist. C1 cannot retrieve the map. Any later component needing the raw maps must obtain them from separately governed capsule custody and verify the aggregate; C1 does not provide them to C2.

`wire_protocol_error`

Its semantic payload is exactly:

```text
schema_id
wire_profile_ref
wire_profile_digest
reason
```

with:

```text
wire_profile_ref:
rw0-wire-nwpf-v1

wire_profile_digest:
470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454
```

The digest domain is:

```text
governed-execution.nwp-rw0-c1-transient-wire-protocol-error-binding.v1.identity
```

Admission requires an actual sealed `RW0WireProtocolError`, the existing sealed invariant, and the same object passed to the owner classifier. Only its exact reason is extracted.

The closed reason inventory is:

```text
invalid_outer_type
short_header
bad_magic
unsupported_version
unsupported_kind
declared_length_over_cap
truncated_payload
trailing_data
invalid_utf8
bom_forbidden
json_token_invalid
duplicate_key
invalid_root_or_scalar
unknown_field
missing_field
nested_record_invalid
noncanonical_payload
relation_mismatch
work_limit_exceeded
invalid_field_type
invalid_field_value
invalid_length_or_cardinality
digest_mismatch
privacy_forbidden_material
```

No exception object, class identity beyond the sealed admission check, arbitrary args, arbitrary message, traceback, cause, or context persists. Replay must never manufacture an `RW0WireProtocolError`.

For rank 14:

- `present`: binds the rank-13 membership pair; finite-error fields are null.
- `finite_failure`: rank-13 membership fields are null; the exact finite-error binding is present.
- `absent`: both are absent.

# Proof-mode branches

The semantic proof vocabulary is:

```text
value_reconstructed
relation_recomputable
relation_attested_at_admission
derived_wrapper_recomputable
existing_owner_row_reconstructed
```

Only the latter four appear in `rw0_relation_bindings`; `value_reconstructed` creates no relation row.

| Rank | Evidence | Relations | Proof mode |
|---:|---|---:|---|
| Phase | Phase establishment | 1 | `relation_attested_at_admission` |
| 1 | Authority verification | 1 | `relation_recomputable` without a manifest; `relation_attested_at_admission` when a transient manifest is required |
| 2 | Subordinate authorization | 1 | `relation_recomputable` |
| 3 | Custody | 1 | `existing_owner_row_reconstructed` for the selected-artifact branch; `relation_attested_at_admission` for transient WorkSpec |
| 4 | Retrieval event | 1 | `relation_recomputable` |
| 5 | Readiness | 0 | `value_reconstructed` |
| 6 | Host qualification | 1 | `derived_wrapper_recomputable` |
| 7 | Capability declaration | 0 | `value_reconstructed` |
| 8 | Capability observation | 1 | `relation_recomputable` |
| 9 | Capability qualification | 1 | `derived_wrapper_recomputable` |
| 10 | Wire cancellation request | 1 | `relation_attested_at_admission` |
| 11 | Wire process observation | 1 | `relation_attested_at_admission` |
| 12 | C2A worker observation | 1 normally; 2 for cancellation acknowledgment/rejection | Per relation: recomputable only when every owner operand is durable and no transient manifest/blob map is required; otherwise attested |
| 13 | Wire worker-result binding | 1 | `derived_wrapper_recomputable` |
| 14 | Process/result classification | 1 | `derived_wrapper_recomputable` for `present` and `absent`; `relation_attested_at_admission` for `finite_failure` |
| 15 | Section 41 wrapper | 1 | `existing_owner_row_reconstructed` |

Proof mode is covered by the relation semantic digest, relation-set digest, admission/phase graph, result projection, and receipt.

Receipt-first exact replay normally returns the original committed projection without rerunning any owner relation. A verification path may rerun only `relation_recomputable`, `derived_wrapper_recomputable`, or `existing_owner_row_reconstructed` branches from exact durable operands. It must never rerun an attested relation without the original private operand. Attested replay and recovery verify the durable binding and original attestation only.

# Final relation-binding and operand SQL

All new tables remain `STRICT`. Columns use the repository’s `ANY` plus exact `typeof(...)` CHECK style. Safe refs reuse the frozen ASCII, 1–96-byte, allowed-character and forbidden-prefix grammar. Digests are exact lowercase 64-character hexadecimal values.

The final ordered `rw0_relation_bindings` columns are:

```text
schema_id
phase_basis_ref
phase_basis_digest
relation_ref
relation_digest
subject_type
subject_membership_ref
subject_membership_digest
subject_kind_rank
subject_value_ref
subject_value_digest
subject_value_schema_id
relation_rank
relation_schema_id
relation_version
proof_mode
profile_ref
profile_digest
operand_count
operand_set_digest
relation_row_digest
```

`schema_id` is exactly:

```text
governed-execution.nwp-rw0-c1-relation-binding.v1
```

The common checks require:

```text
subject_type IN ('phase_establishment','evidence_membership')
relation_rank IN (0,1)
relation_version = 1
proof_mode IN (
  'relation_recomputable',
  'relation_attested_at_admission',
  'derived_wrapper_recomputable',
  'existing_owner_row_reconstructed'
)
1 <= operand_count <= 14
(profile_ref IS NULL AND profile_digest IS NULL)
OR
(profile_ref IS NOT NULL AND profile_digest IS NOT NULL)
```

The exact branch CHECK is logically:

```sql
(
  subject_type = 'phase_establishment'
  AND subject_membership_ref IS NULL
  AND subject_membership_digest IS NULL
  AND subject_kind_rank IS NULL
  AND subject_value_ref IS NULL
  AND subject_value_digest IS NULL
  AND subject_value_schema_id IS NULL
  AND relation_rank = 0
  AND relation_schema_id =
      'governed-execution.nwp-rw0-c1-phase-entry-basis-relation.v1'
  AND relation_version = 1
  AND proof_mode = 'relation_attested_at_admission'
  AND profile_ref IS NULL
  AND profile_digest IS NULL
  AND operand_count = 14
  AND relation_ref = 'rw0-c1-phase-relation.' || phase_basis_digest
)
OR
(
  subject_type = 'evidence_membership'
  AND subject_membership_ref IS NOT NULL
  AND subject_membership_digest IS NOT NULL
  AND subject_kind_rank BETWEEN 1 AND 15
  AND subject_value_ref IS NOT NULL
  AND subject_value_digest IS NOT NULL
  AND subject_value_schema_id IS NOT NULL
  AND relation_rank IN (0,1)
  AND relation_schema_id !=
      'governed-execution.nwp-rw0-c1-phase-entry-basis-relation.v1'
)
```

Keys and foreign keys are:

```text
PRIMARY KEY (relation_ref)
UNIQUE (relation_digest)
UNIQUE (phase_basis_ref, relation_ref, relation_digest)
UNIQUE (phase_basis_ref, subject_membership_ref, relation_rank)

FOREIGN KEY (phase_basis_ref, phase_basis_digest)
  REFERENCES rw0_phase_instances
    (phase_basis_ref, phase_basis_digest)
  ON UPDATE RESTRICT ON DELETE RESTRICT

FOREIGN KEY (
  phase_basis_ref,
  subject_membership_ref,
  subject_membership_digest,
  subject_kind_rank,
  subject_value_ref,
  subject_value_digest,
  subject_value_schema_id
)
  REFERENCES rw0_evidence_memberships (
    phase_basis_ref,
    membership_ref,
    membership_digest,
    kind_rank,
    value_ref,
    value_digest,
    value_schema_id
  )
  ON UPDATE RESTRICT ON DELETE RESTRICT
```

The membership parent therefore retains the corresponding seven-field composite `UNIQUE`. It also has the eight-field parent `UNIQUE` including `scope_binding_digest` for operand FKs.

`relation_row_digest` uses:

```text
governed-execution.nwp-rw0-c1-relation-binding.v1.identity
```

over every row field except itself. For membership relations, the semantic `relation_digest` excludes the not-yet-derived `subject_membership_digest`; the later row digest includes it.

The final ordered `rw0_relation_operands` columns are:

```text
schema_id
phase_basis_ref
relation_ref
relation_digest
operand_ordinal
operand_role
operand_source
source_membership_ref
source_membership_digest
source_kind_rank
owner_role
owner_locator_ref
owner_locator_revision
owner_locator_subrole
owner_locator_ordinal
transient_binding_kind
transient_error_reason
operand_schema_id
operand_ref
operand_digest
operand_scope_digest
operand_row_digest
```

`schema_id` is exactly:

```text
governed-execution.nwp-rw0-c1-relation-operand.v1
```

Common checks require:

```text
operand_source IN (
  'c1_evidence',
  'existing_owner_row',
  'transient_private_binding'
)

0 <= operand_ordinal <= 13
```

The exact source-branch rules are:

```text
c1_evidence:
  source_membership_ref/digest/kind_rank non-null
  owner_role and all owner locator fields null
  transient_binding_kind and transient_error_reason null
  operand schema/ref/digest/scope non-null
  full same-phase membership FK applies

existing_owner_row:
  source membership fields null
  owner_role and owner_locator_ref non-null
  transient fields null
  operand schema/ref/digest/scope non-null
  owner-role registry fixes the reader and schema
  no table-name field exists

transient_private_binding:
  source membership fields null
  owner_role and every owner locator field null
  transient_binding_kind is one of the five closed kinds
  transient_error_reason non-null iff kind = wire_protocol_error
  operand schema/ref/digest/scope non-null
  exact kind/schema/ref-shape CHECK applies
```

The transient kind/schema/ref checks are:

```text
work_spec:
  schema = governed-execution.nwp-rw0-c1-transient-work-spec-binding.v1
  reason null

candidate_capsule_manifest:
  schema = governed-execution.nwp-candidate-capsule-manifest.v1
  reason null

before_blob_set:
  schema = governed-execution.nwp-rw0-c1-transient-before-blob-set-binding.v1
  ref = rw0-c1-before-blob-set.<operand_digest>
  reason null

after_blob_set:
  schema = governed-execution.nwp-rw0-c1-transient-after-blob-set-binding.v1
  ref = rw0-c1-after-blob-set.<operand_digest>
  reason null

wire_protocol_error:
  schema = governed-execution.nwp-rw0-c1-transient-wire-protocol-error-binding.v1
  ref = rw0-c1-wire-error.<operand_digest>
  reason in the exact 24-value inventory
```

The closed owner-role/schema registry is:

| Owner role | Required `operand_schema_id` |
|---|---|
| `development_work_spec_binding` | `governed-execution.nwp-development-work-spec-binding.v1` |
| `development_attempt_fence` | `governed-execution.nwp-attempt-fence.v1` |
| `development_effect_fence` | `governed-execution.nwp-effect-fence.v1` |
| `development_author_command` | `governed-execution.nwp-worker-command.v1` |
| `development_effect_head` | `governed-execution.nwp-development-effect-head.v1` |
| `development_delivery_attempt` | `governed-execution.nwp-development-delivery-attempt.v1` |
| `development_delivery_head` | `governed-execution.nwp-development-delivery-head.v1` |
| `global_stop_current` | `governed-execution.nwp-global-stop.v1` |
| `development_model_source_invocation` | `governed-execution.nwp-model-source-invocation.v1` |
| `development_pre_execution_planning_context` | `governed-execution.nwp-pre-execution-planning-context.v1` |
| `development_private_proposal_artifact_binding` | `governed-execution.nwp-private-proposal-artifact-binding.v1` |
| `development_model_proposal` | `governed-execution.nwp-model-proposal-envelope.v1` |
| `development_pre_execution_plan_projection` | `governed-execution.nwp-pre-execution-plan-safe-projection.v1` |
| `development_model_proposal_evidence_binding` | `governed-execution.nwp-model-proposal-evidence-binding.v1` |
| `development_pre_execution_disposition` | `governed-execution.nwp-pre-execution-coordinator-disposition.v1` |
| `development_pre_execution_selection_head` | `governed-execution.nwp-pre-execution-selection-head.v1` |
| `development_cognitive_mutation_receipt` | `governed-execution.nwp-cognitive-mutation-receipt.v1` |

Locator shape is closed:

- Selection, effect, delivery heads and global-stop current require a non-negative `owner_locator_revision`; subrole and ordinal are null.
- `development_model_proposal_evidence_binding` requires an evidence subrole from the owner’s closed evidence-role inventory and `owner_locator_ordinal = 0`; revision is null.
- All other roles require revision, subrole, and ordinal to be null.
- `owner_locator_ref` is interpreted only by the statically registered private reader for that role.
- Callers cannot provide a table name, SQL fragment, reader name, or arbitrary schema.

Operand keys and FKs are:

```text
PRIMARY KEY (relation_ref, operand_ordinal)
UNIQUE (relation_ref, operand_role)
UNIQUE (operand_row_digest)

FOREIGN KEY (phase_basis_ref, relation_ref, relation_digest)
  REFERENCES rw0_relation_bindings
    (phase_basis_ref, relation_ref, relation_digest)
  ON UPDATE RESTRICT ON DELETE RESTRICT

FOREIGN KEY (
  phase_basis_ref,
  source_membership_ref,
  source_membership_digest,
  source_kind_rank,
  operand_ref,
  operand_digest,
  operand_schema_id,
  operand_scope_digest
)
  REFERENCES rw0_evidence_memberships (
    phase_basis_ref,
    membership_ref,
    membership_digest,
    kind_rank,
    value_ref,
    value_digest,
    value_schema_id,
    scope_binding_digest
  )
  ON UPDATE RESTRICT ON DELETE RESTRICT
```

The operand row digest domain is:

```text
governed-execution.nwp-rw0-c1-relation-operand.v1.identity
```

and covers every row field except `operand_row_digest`.

SQL rejects duplicate ordinals and roles. Dense completeness is enforced by the controller and reader: select the exact 22 columns in table order, `ORDER BY operand_ordinal ASC LIMIT 15`, require the returned count to equal `operand_count`, and require every returned ordinal to equal its zero-based tuple position. A fifteenth row, gap, mismatch, wrong role/schema pairing, or unexpected branch field is integrity failure. A ref/digest collision or an exact identity occupied by different content is a closed identity conflict; commit recovery treats any mixed or contradictory family as unresolved.

# Phase write, replay, and recovery

The exact phase-establishment transaction is:

1. Validate the closed command and actual transient `WorkSpecV1`.
2. Acquire the existing operation lease and sole mutation slot.
3. Open one resource-bound connection through the existing controller, `BEGIN IMMEDIATE`, revalidate binding, validate managed state, and fence the writer.
4. Read the mutation receipt first. Resolve exact replay, idempotency conflict, or fresh execution before disclosing phase state.
5. Read the exact durable owner rows and collision probes.
6. Reconstruct the selection result, L34 lineage, safe WorkSpec binding, fences, command, delivery, heads, and global stop.
7. Require the actual WorkSpec to match its owner digest and safe projection, then invoke `validate_phase_entry_basis(...)` exactly once.
8. Construct the 14 semantic operands.
9. Compute operand-set digest, phase relation semantic digest, relation-set digest, phase graph digest, phase row digest, relation row digest, operand row digests, result digest, and receipt digest in the acyclic order above.
10. Insert the phase row.
11. Insert the phase relation binding.
12. Insert all 14 relation operands in ordinal order.
13. Insert the mutation receipt last.
14. Perform full in-transaction readback of the complete family and collision probes.
15. Permanently invalidate the read capability.
16. Attempt exactly one commit.
17. Close and release the mutation slot under existing cleanup precedence.

Exact replay is receipt-first and requires the same mutation reference and canonical command digest, including the transient WorkSpec binding. It verifies the full stored phase/relation/operand family and returns the original timestamp and result projection. It does not rerun the attested phase relation.

After a commit-attempt exception, retained-lock readback classifies:

`committed_exact`

- Exact receipt exists.
- Exact phase row exists.
- The deterministic phase relation exists.
- Exactly 14 dense operands exist.
- Relation, operand-set, relation-set, phase graph, phase row, result, and receipt digests all recompute.
- Every owner locator resolves to the exact bound row.
- The K8 and phase identity probes have no collision.
- No raw WorkSpec is required or reconstructed.

`definitely_not_committed`

- No receipt exists for the operation.
- No phase row exists under its phase ref, phase digest, or K8 identities.
- No deterministic phase relation exists under its ref or digest.
- No operand exists for that derived relation.
- No operation-owned result or receipt identity exists.
- Pre-existing owner rows do not defeat absence.

`unresolved`

- Any partial family exists.
- Any digest, row, ordinal, owner binding, K8, phase, relation, result, or receipt mismatch exists.
- A collision exists under a different identity.
- Readback cannot prove either exact commitment or complete absence.

An unresolved result forbids automatic retry or suffix-style repair. No phase can be reported as committed without the relation and all 14 operands.

# Member write, replay, and recovery

The accepted member digest sequence remains acyclic:

1. Validate the command and all supplied private operands.
2. Read and validate the phase and durable prerequisites.
3. Invoke the applicable owner relation using exact durable and transient operands.
4. Form semantic operand bindings.
5. Compute each relation semantic digest without final `membership_digest`.
6. Compute the relation-set digest from `membership_ref` and ordered relation ref/digest pairs.
7. Compute the admission graph digest.
8. Compute the stable membership digest.
9. Compute relation row digests with the final membership digest.
10. Compute operand row digests.
11. Compute result and receipt digests.

The membership identity remains based on the accepted fields:

```text
schema_id
membership_ref
phase_basis_ref
phase_basis_digest
kind_rank
value_ref
value_digest
value_schema_id
scope_binding_digest
relation_set_digest
admitted_by_mutation_ref
admitted_at
admission_graph_digest
```

with `membership_digest` excluded from its own preimage.

The transaction sequence is:

1. Command-local and transient-object validation.
2. Existing controller begin/binding/managed-state/writer-fence prefix.
3. Receipt-first idempotency resolution.
4. Phase, prerequisite, C1-evidence, and owner-row reads.
5. Exact owner relation invocation.
6. Typed registry/payload exact-reuse decision.
7. Relation, relation-set, admission graph, membership, row, result, and receipt planning.
8. Insert or exactly reuse permitted registry/payload rows.
9. Insert membership.
10. Insert relation bindings.
11. Insert ordered relation operands, including transient bindings.
12. Insert receipt last.
13. Full readback.
14. Capability invalidation.
15. Exactly one commit attempt.

Committed-exact replay and recovery verify:

- the typed value;
- stable membership;
- relation count and set;
- every same-phase C1 membership operand;
- every closed owner-row locator and digest;
- every transient-private tuple;
- dense operand order;
- result projection;
- admission graph;
- membership, row, and receipt digests.

For attested relations, recovery verifies the persisted attestation and binding; it does not recreate the private operand or rerun the relation.

Definitely absent requires no operation-owned receipt, membership identity, relation ref/digest, operand family, result identity, or conflicting graph. Exact reusable registry/payload rows may preexist and do not defeat absence. Any partial operation-owned family, mismatch, collision, or unprovable state is unresolved.

# Table/count/path consequences

The representation adds columns and CHECK branches to the already planned relation tables. It adds no table, trigger, or index.

| Measure | Current | Migration 0004 | Cumulative |
|---|---:|---:|---:|
| Tables | 39 | 23 | 62 |
| Immutability triggers | 64 | 46 | 110 |
| Explicit indexes | 1 | 4 | 5 |

The 23 new tables retain exactly two immutable triggers each: one no-update trigger and one no-delete trigger.

The four new explicit indexes remain:

```text
idx_rw0_phase_instances_k8_lookup
idx_rw0_evidence_memberships_phase_kind_page
idx_rw0_relation_operands_c1_membership_lookup
idx_rw0_c1_mutation_receipts_phase_family_lookup
```

SQLite autoindexes created by primary and unique constraints are not counted as explicit indexes.

The exact 81-path implementation ledger remains sufficient.

The 27 documentation/root paths are:

```text
AGENTS.md
README.md
.docs/architecture.md
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/b3-tests-only-coherent-fixtures.md
.docs/b3-transition-persistence-contract.md
.docs/b3c0a-transition-authority-and-order.md
.docs/b4c-public-global-stop-delegation.md
.docs/c2a-first-slice-semantic-protocol-contract.md
.docs/c2b-durable-development-state.md
.docs/c2b2-migration-0002.md
.docs/c2b2-private-readers.md
.docs/durable-state-model.md
.docs/rw0-b1-pure-phase-values.md
.docs/rw0-b2-capability.md
.docs/rw0-b2-wire-protocol.md
.docs/rw0-c1-durable-evidence.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/software-development-progression-boundary.md
.docs/sqlite-bootstrap-and-migrations.md
.docs/sqlite-operations-and-recovery.md
.docs/sqlite-schema-v1.md
.docs/sqlite-state-backend-adr.md
.docs/sqlite-threat-model.md
.docs/worker-execution-boundary.md
.docs/writer-session-authority.md
```

The 11 production/migration paths are:

```text
src/ge_nwp_coordinator/_rw0_c1_semantic_values.py
src/ge_nwp_coordinator/_rw0_c1_row_values.py
src/ge_nwp_coordinator/_rw0_c1_mutation_contracts.py
src/ge_nwp_coordinator/_sqlite_rw0_c1_reader_contracts.py
src/ge_nwp_coordinator/_sqlite_rw0_c1_readers.py
src/ge_nwp_coordinator/_sqlite_rw0_c1.py
src/ge_nwp_coordinator/sqlite_transition_select_support.py
src/ge_nwp_coordinator/sqlite_transition_transaction.py
src/ge_nwp_coordinator/sqlite_writer_session.py
src/ge_nwp_coordinator/sqlite_migration.py
src/ge_nwp_coordinator/sqlite_migrations/0004_rw0_c1_durable_evidence.sql
```

The 43 test/support paths are:

```text
tests/b3_coherent_transition_fixture.py
tests/test_architecture_contracts.py
tests/test_autonomous_software_development_operating_model.py
tests/test_b2a_writer_session_contract.py
tests/test_b3_coherent_transition_fixture.py
tests/test_b3a_persistence_contracts.py
tests/test_b3b1_pure_row_contracts.py
tests/test_b3b2b_select_readers.py
tests/test_b3b_reader_prerequisite_contracts.py
tests/test_b3c0a_transition_authority_contract.py
tests/test_b3c0b_transition_event_replay_contracts.py
tests/test_b3c1_prerequisite_contract.py
tests/test_b3c1b_rollback_only_writer_fencing.py
tests/test_b3c3_prerequisite_contract.py
tests/test_b3c4c_prerequisite_contract.py
tests/test_b4c_public_global_stop_delegation.py
tests/test_c2a_nonimplementation.py
tests/test_c2b0_durable_state_contract.py
tests/test_c2b2_development_reader_contracts.py
tests/test_c2b3c_author_effect_contract.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_runtime_non_authority.py
tests/test_rw0_b1_boundaries.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_software_development_progression_boundary.py
tests/test_sqlite_b1_migrations.py
tests/test_sqlite_b2c_writer_session.py
tests/test_sqlite_backend_b0_contract.py
tests/test_sqlite_c2b1_migration_framework.py
tests/test_sqlite_c2b2_migration_0002.py
tests/test_sqlite_section41_migration_0003.py
tests/test_worker_execution_semantic_boundaries.py
tests/test_rw0_c1_semantic_values.py
tests/test_rw0_c1_row_values.py
tests/test_rw0_c1_reader_contracts.py
tests/test_rw0_c1_private_readers.py
tests/test_rw0_c1_mutation_contracts.py
tests/test_rw0_c1_private_atomic_persistence.py
tests/test_rw0_c1_recovery.py
tests/test_rw0_c1_writer_session_delegation.py
tests/test_sqlite_rw0_c1_migration_0004.py
```

No current source or test pins a pre-existing `rw0_relation_bindings` subject enum, `rw0_relation_operands` source enum, phase relation storage shape, or C1 relation column set because migration `0004` does not yet exist.

Existing boundary tests already cover the affected controller, select helper, B1 imports, B2 imports, and non-authority posture. No additional path is causally required. In particular, the implementation must obtain the WorkSpec safe projection through the already validated C1/phase lineage seam and must not add a direct C1 import of `_development_program_row_values`; therefore `tests/test_c2b2_development_row_value_boundaries.py` remains an untouched external tripwire rather than an added path.

# Findings and contradictions

No accepted-architecture contradiction was found.

The common relation tables safely support both phase and membership subjects because:

- the phase branch nulls all membership fields;
- the membership branch requires the full value identity;
- the relation row always has an exact phase FK;
- the membership branch additionally has an exact same-phase membership FK;
- deterministic phase relation identity gives one phase relation despite SQLite’s NULL uniqueness behavior;
- phase-first insertion avoids an FK cycle;
- graph and relation-set digests close the family without making either row authoritative over owner semantics.

Every accepted transient private operand now has an exact durable aggregate binding. None requires a 24th table or a new custody surface.

The only deliberately non-SQL invariant is cross-row dense operand completeness. Enforcing it with extra triggers would change the 46-trigger count and add unnecessary mutation logic. The existing bounded-reader pattern is sufficient: PK/UNIQUE constraints reject local duplicates, while `LIMIT 15`, count equality, dense ordinal verification, receipt-last insertion, and full transactional readback prove the aggregate.

No second transaction controller, raw SQLite connection authority, C2 state, public reader, public package export, owner semantic change, or supporting-repository change is needed.

# Forecasts and stop conditions

The highest-risk implementation mistakes are:

- including `membership_digest` in a member relation semantic digest and creating a cycle;
- including `relation_digest` or operand row digests in `operand_set_digest`;
- including phase graph or phase row digest in the phase relation digest;
- storing manifest entries, paths, blob-map keys, per-file metadata, WorkSpec fields, or exception material;
- fabricating an error object during replay;
- treating an attested relation as recomputable;
- admitting a member relation without the same-phase composite FK;
- accepting an owner table name or reader selector from a caller;
- reporting committed state without every relation operand;
- treating partial readback as definitely absent;
- invoking a second transaction authority.

Freeze reconciliation is required if implementation needs any of:

- a 24th migration-0004 table;
- a 47th immutability trigger;
- a fifth new explicit index;
- an 82nd path;
- a modification to an owner semantic source;
- a direct `sqlite3` import in `_sqlite_rw0_c1.py`;
- a second transaction controller;
- a raw-private-material column;
- a public API or package export;
- C2 runtime, capsule custody, worker, process, transport, or contact behavior.

The select helper’s frozen allowed limits become exactly:

```text
(2, 3, 15, 16, 257, 258)
```

Any wider limit inventory is a stop condition.

# Recommendation

The closure is internally consistent and implementation-ready.

It durably represents phase establishment, closes every accepted transient private operand, preserves proof-mode distinctions, keeps replay and commit recovery fail-closed, retains stable membership identity and same-phase integrity, and preserves the exact table/trigger/index/path ceilings.

No freeze reconciliation or architectural replan is required.

# Next implementation boundary

The next separately authorized boundary remains the existing 81-path migration-0004/private-runtime tranche. Its transaction surface remains limited to extensions of `_CoordinatorMutationTransactionController` and the previously frozen private entries:

```text
run_atomic_rw0_c1_phase_establishment
run_rw0_c1_phase_establishment_recovery
run_atomic_rw0_c1_evidence_admission
run_rw0_c1_evidence_admission_recovery
```

with the corresponding private transaction methods and module wrappers:

```text
_run_atomic_rw0_c1_phase_establishment
_run_rw0_c1_phase_establishment_recovery
_run_atomic_rw0_c1_evidence_admission
_run_rw0_c1_evidence_admission_recovery
```

`_sqlite_rw0_c1.py` remains the owner of C1 planning, readback, literal C1 SQL, and closed write plans; it must not import `sqlite3`. `sqlite_mutation_transaction_contracts.py` remains unchanged. There is no implementation authority in this reconciliation itself.

REPOSITORY_MUTATION_NOT_PERFORMED  
TESTS_NOT_RUN  
STAGING_NOT_PERFORMED  
COMMIT_NOT_PERFORMED  
PUSH_NOT_PERFORMED  
PR_NOT_CREATED  
REMOTE_CONTACT_NOT_PERFORMED  
WORKER_OR_MODEL_NOT_INVOKED  
SUPPORTING_REPOSITORIES_NOT_MODIFIED  
IMPLEMENTATION_NOT_PERFORMED  
RW0_C1_IMPLEMENTATION_CONTRACT_READY
