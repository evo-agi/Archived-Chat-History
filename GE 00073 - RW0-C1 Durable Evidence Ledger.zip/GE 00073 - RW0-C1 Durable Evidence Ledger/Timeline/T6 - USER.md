Here is Codex's response:

# Baseline and inspection boundary

The required baseline is exact:

- Branch: `trunk_dev`
- HEAD: `dd12b23762dc761736e55a1abfde12dd3ec23551`
- Parent: `deec37bf08fb903d8846aa2c3232aec52fa9866e`
- Subject: `feat: implement RW0-B2 Capability semantics (#5)`
- Upstream: `origin/trunk_dev`
- Ahead/behind: `0/0`
- Worktree, staged index, and unstaged index: clean

All required Coordinator files and concrete dependency consumers were inspected read-only. No fetch, remote contact, supporting-repository inspection, test execution, or repository mutation occurred.

# Accepted strategic decisions

1. Preserve the complete `rw0-wire-nwpf-v1` contract unchanged, including its profile digest `470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454`.
2. Add one separate private Wire cancellation-control profile.
3. Reuse `RW0WireCancellationRequestObservationV1` and `RW0WireProcessObservationV1` unchanged.
4. Keep `RW0WireWorkerResultV1`, `RW0WireProcessResultClassificationV1`, and `classify_wire_process_result(...)` v1-only.
5. Admit exact current targets `author_candidate`, `validate_candidate`, and `review_candidate`.
6. Author requires capsule omission via `_C2A_MISSING`; validation/review require the exact `CandidateCapsuleManifestV1`.
7. Add a distinct control-only classification value.
8. Keep the profile distinct from NWPF v1 and B1’s physical cancellation-mechanism profile.
9. Capability continues binding only the existing worker protocol pair.
10. C1 remains exactly 15 evidence kinds. The new classification is recomputed and bound through C2 closure.
11. Add no persistence, I/O, transport, process control, authentication, public export, production caller, runtime authority, or external contact.

# Corrections to prior reconnaissance

The touched-file ceiling is 11, not 10. Editing the Wire source requires updating the P01 protected-content size and SHA-256 in `tests/test_rw0_b2_capability_boundaries.py`.

The current protected identity is:
```
P01
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
77003
6bf39f634b619829fcc4cc7ada5cf019b40b3c5a2258947ebee8fdfe2a13031e
```

No other content-sensitive consumer requires a twelfth file.

The reconstruction tariffs also require correction: they are not merely existing raw-slot inspection counts. Each fixed tariff is twice the maximum occurrence graph, including its root, reserving both raw projection and owner revalidation.

Finally:

- The two additive C2A names must enter the existing single relative import statement; a second relative import would violate an existing boundary test.
- Target delivery needs no additional author-delivery or blob operand.
- The definitive profile digest is the independently verified `4d6f8455…` value below. All provisional digests are superseded.

# Exact profile manifest and digest

Profile identity:
```
schema_id: governed-execution.nwp-rw0-wire-cancellation-control-profile.v1
profile_ref: rw0-wire-cancellation-control-v1
digest_domain: governed-execution.nwp-rw0-wire-cancellation-control-profile.v1.identity
```

Returned mapping order:
```
schema_id
profile_ref
manifest
profile_digest
```

Manifest mapping order:
```
authority
capsule
classifier
facts
identity
relations
routes
targets
values
work
```

Every nested mapping uses the canonical key order printed below; every sequence preserves its printed order. Containers are exact built-in `dict` and `list`; scalars are exact built-in `str`, `int`, and `bool`. Semantic `"None"`, `"null"`, and `"omitted"` tokens are strings defining the corresponding operand rule.

`cancellation_control_profile_mapping()` returns a fresh exact built-in outer dictionary and fresh complete manifest graph on every call. The profile never enters NWPF frames.

Identity calculation:
```
canonical_identity = compact sorted-key JSON({
  "schema_id": schema_id,
  "profile_ref": profile_ref,
  "manifest": manifest
})
digest = SHA256(
  UTF8("governed-execution.nwp-rw0-wire-cancellation-control-profile.v1.identity")
  + NUL
  + UTF8(canonical_identity)
)
```

Canonicalization uses UTF-8, `ensure_ascii=False`, `allow_nan=False`, separators `(",", ":")`, sorted keys, and no Unicode normalization.

- Canonical manifest length: `12,014` bytes
- Canonical outer identity length: `12,154` bytes
- Profile digest: `4d6f84552b852a4c4073b4238591afd271072f648424eca9e744def436165288`

The following single line is the complete canonical manifest byte sequence when UTF-8 encoded:
```
{"authority":{"acceptance":false,"authentication":false,"c1_evidence_member":false,"current_selection":false,"durable":false,"durable_truth":false,"effect_authority":false,"external_contact":false,"io":false,"mechanism_neutral":true,"permission":false,"persistence":false,"process_control":false,"production_caller":false,"profile_in_frame":false,"provider_neutral":true,"public_export":false,"reconciliation":false,"review_result":false,"runtime":false,"semantic_cancellation":false,"source_authenticity":false,"target_result":false,"teardown":false,"terminality":false,"transport":false,"validation_result":false,"worker_result":false},"capsule":{"author_candidate":{"argument":"omitted","cancellation_portable_capsule_digest":"null","target_portable_capsule_digest":"null"},"entries":{"maximum":3,"minimum":3},"review_candidate":{"argument":"exact_CandidateCapsuleManifestV1","cancellation_portable_capsule_digest":"manifest","target_portable_capsule_digest":"manifest"},"validate_candidate":{"argument":"exact_CandidateCapsuleManifestV1","cancellation_portable_capsule_digest":"manifest","target_portable_capsule_digest":"manifest"}},"classifier":{"acknowledgement_rejection_exclusive":true,"classifications":["invalid","incomplete","finite"],"decision_order":[["invalid_input","invalid","invalid_input"],["duplicate_fact","invalid","duplicate_fact"],["unrelated_fact","invalid","unrelated_fact"],["conflicting_fact","invalid","conflicting_fact"],["cancellation_graph_mismatch","invalid","cancellation_graph_mismatch"],["request_absent","incomplete","process_evidence_incomplete"],["cancellation_rejected","finite","cancellation_rejected"],["target_process_exited","finite","target_process_exited"],["resource_limit_exceeded","incomplete","resource_limit_exceeded"],["deadline_elapsed","incomplete","deadline_elapsed"],["signal_delivered","incomplete","signal_delivered"],["cancellation_acknowledged","incomplete","cancellation_acknowledged"],["request_present","incomplete","cancellation_request_pending"]],"exit_code":{"maximum":255,"minimum":-255,"zero_special":false},"matrix":{"finite":["cancellation_rejected","target_process_exited"],"incomplete":["process_evidence_incomplete","resource_limit_exceeded","deadline_elapsed","signal_delivered","cancellation_acknowledged","cancellation_request_pending"],"invalid":["invalid_input","duplicate_fact","unrelated_fact","conflicting_fact","cancellation_graph_mismatch"]},"reasons":["invalid_input","duplicate_fact","unrelated_fact","conflicting_fact","cancellation_graph_mismatch","process_evidence_incomplete","resource_limit_exceeded","deadline_elapsed","signal_delivered","cancellation_acknowledged","cancellation_request_pending","cancellation_rejected","target_process_exited"],"response_requires_request":true,"return_type":"exact_RW0WireCancellationControlClassificationV1","timestamp_ordering":false},"facts":{"absence":"None","adapter_observations":{"maximum":4,"minimum":0,"roles":["cancellation_acknowledged","cancellation_rejected","deadline_elapsed","process_exited"]},"duplicate_detection":{"after_reconstruction":true,"keys":["original_object_identity","safe_fact_ref","safe_fact_digest"],"scope":"all_supplied_facts"},"item_types":{"adapter_observations":"exact_WorkerObservationV1","process_observations":"exact_RW0WireProcessObservationV1"},"observation_items_nullable":false,"outer_types":{"adapter_observations":"exact_builtin_tuple","process_observations":"exact_builtin_tuple","request":"exact_RW0WireCancellationRequestObservationV1_or_None"},"process_observations":{"maximum":2,"minimum":0,"roles":["resource_limit_exceeded","signal_delivered"]},"request":{"maximum":1,"minimum":0},"request_absence":"None","request_bindings":["target_effect_fence","target_delivery","cancellation_effect_fence","cancellation_delivery"],"role_bindings":{"cancellation_acknowledged":["cancellation_effect_fence","cancellation_delivery"],"cancellation_rejected":["cancellation_effect_fence","cancellation_delivery"],"deadline_elapsed":["target_effect_fence","target_delivery"],"process_exited":["target_effect_fence","target_delivery"],"resource_limit_exceeded":["target_effect_fence","target_delivery"],"signal_delivered":["target_effect_fence","target_delivery"]},"role_validation":{"cancellation_acknowledged":["cancellation_response"],"cancellation_rejected":["cancellation_response"],"deadline_elapsed":["target_observation"],"process_exited":["target_observation"],"request":["target_delivery","cancellation_delivery"],"resource_limit_exceeded":["target_delivery"],"signal_delivered":["target_delivery"]},"singleton_maximum":1,"singleton_roles":["request","cancellation_acknowledged","cancellation_rejected","deadline_elapsed","process_exited","resource_limit_exceeded","signal_delivered"],"total_maximum":7},"identity":{"canonical_json":{"allow_nan":false,"ensure_ascii":false,"normalization":"none","separators":[",",":"],"sort_keys":true},"digest":"sha256","domain_separator":"NUL","encoding":"UTF-8"},"relations":{"c2a_call_profiles":{"cancellation_delivery":{"arguments":[["delivery","cancellation_delivery"],["author_command","author_command"],["attempt_fence","attempt_fence"],["author_effect_fence","author_effect_fence"],["effect_fence","cancellation_effect_fence"],["capsule_manifest","target_capsule_manifest_by_target_class"],["cancellation_target","target_effect_fence"]],"call":"validate_delivery_relation"},"cancellation_response":{"arguments":[["observation","response"],["delivery","cancellation_delivery"],["author_command","author_command"],["attempt_fence","attempt_fence"],["author_effect_fence","author_effect_fence"],["effect_fence","cancellation_effect_fence"],["capsule_manifest","target_capsule_manifest_by_target_class"],["before_blobs","omitted"],["after_blobs","omitted"],["cancellation_target","target_effect_fence"]],"call":"validate_observation_relation"},"target_delivery":{"arguments":[["delivery","target_delivery"],["author_command","author_command"],["attempt_fence","attempt_fence"],["author_effect_fence","author_effect_fence"],["effect_fence","target_effect_fence"],["capsule_manifest","target_capsule_manifest_by_target_class"],["cancellation_target","omitted"]],"call":"validate_delivery_relation"},"target_observation":{"arguments":[["observation","adapter_observation"],["delivery","target_delivery"],["author_command","author_command"],["attempt_fence","attempt_fence"],["author_effect_fence","author_effect_fence"],["effect_fence","target_effect_fence"],["capsule_manifest","target_capsule_manifest_by_target_class"],["before_blobs","omitted"],["after_blobs","omitted"],["cancellation_target","omitted"]],"call":"validate_observation_relation"}},"c2a_owner_relations":["validate_delivery_relation","validate_observation_relation"],"classifier":{"name":"classify_wire_exact_current_cancellation_control","operands":["author_command","attempt_fence","author_effect_fence","target_effect_fence","target_delivery","cancellation_effect_fence","cancellation_delivery","request","adapter_observations","process_observations","target_capsule_manifest"],"return_type":"exact_RW0WireCancellationControlClassificationV1"},"ordered_direct_c2a_calls":{"classifier_base":["target_delivery","cancellation_delivery"],"process":["target_delivery"],"request":["target_delivery","cancellation_delivery"],"response":["target_delivery","cancellation_delivery","cancellation_response"]},"process":{"name":"validate_wire_exact_current_process_observation_relation","operands":["observation","author_command","attempt_fence","author_effect_fence","target_effect_fence","target_delivery","target_capsule_manifest"],"return_type":"None"},"request":{"name":"validate_wire_exact_current_cancellation_request_relation","operands":["request","author_command","attempt_fence","author_effect_fence","target_effect_fence","target_delivery","cancellation_effect_fence","cancellation_delivery","target_capsule_manifest"],"return_type":"None"},"response":{"name":"validate_wire_exact_current_cancellation_response_relation","operands":["response","request","author_command","attempt_fence","author_effect_fence","target_effect_fence","target_delivery","cancellation_effect_fence","cancellation_delivery","target_capsule_manifest"],"return_type":"None"},"response_prerequisite":"validate_wire_exact_current_cancellation_request_relation"},"routes":{"adapter_observation_orientation":{"cancellation_acknowledged":{"cancellation_target":"target_effect_fence","delivery":"cancellation_delivery","effect":"cancellation_effect_fence","source_basis":"bound_delivery.adapter_kind"},"cancellation_rejected":{"cancellation_target":"target_effect_fence","delivery":"cancellation_delivery","effect":"cancellation_effect_fence","source_basis":"bound_delivery.adapter_kind"},"deadline_elapsed":{"cancellation_target":"omitted","delivery":"target_delivery","effect":"target_effect_fence","source_basis":"bound_delivery.adapter_kind"},"process_exited":{"cancellation_target":"omitted","delivery":"target_delivery","effect":"target_effect_fence","source_basis":"bound_delivery.adapter_kind"}},"adapter_observation_sources":{"direct_local_bootstrap":"direct_local_adapter","execution_substrate":"es_adapter"},"process_observation_orientation":{"resource_limit_exceeded":{"delivery":"target_delivery","effect":"target_effect_fence","source_basis":"closed_process_source_kind"},"signal_delivered":{"delivery":"target_delivery","effect":"target_effect_fence","source_basis":"closed_process_source_kind"}},"process_sources":["supervisor","operating_system"],"request_orientation":{"cancellation_delivery":"cancellation_delivery","cancellation_effect":"cancellation_effect_fence","source_basis":"cancellation_delivery.adapter_kind","target_delivery":"target_delivery","target_effect":"target_effect_fence"},"request_sources":{"direct_local_bootstrap":"supervisor","execution_substrate":"execution_substrate"}},"targets":["author_candidate","validate_candidate","review_candidate"],"values":{"classification":{"c1_evidence_member":false,"c2_binding":"profile_pair_plus_exact_operand_closure","durable_identity":false,"fields":["classification","reason"],"identity":false,"name":"RW0WireCancellationControlClassificationV1"},"process":{"digest_domain":"governed-execution.nwp-rw0-wire-process-observation.v1.identity","name":"RW0WireProcessObservationV1","schema_id":"governed-execution.nwp-rw0-wire-process-observation.v1"},"request":{"digest_domain":"governed-execution.nwp-rw0-wire-cancellation-request-observation.v1.identity","name":"RW0WireCancellationRequestObservationV1","schema_id":"governed-execution.nwp-rw0-wire-cancellation-request-observation.v1"}},"work":{"alias_accounting":"per_occurrence","duplicate_detection_after_reconstruction":true,"fixed_closed_relations":"unmetered","limit_outcomes":{"maximum":"evaluate_normally","one_under_classifier":["invalid","invalid_input"],"one_under_relation_error":"work_limit_exceeded"},"maximum_local_work_units":{"classifier":{"author_candidate":1244,"review_candidate":1342,"validate_candidate":1342},"process_relation":{"author_candidate":498,"review_candidate":596,"validate_candidate":596},"request_relation":{"author_candidate":640,"review_candidate":738,"validate_candidate":738},"response_relation":{"author_candidate":764,"review_candidate":862,"validate_candidate":862}},"one_under_local_work_units":{"classifier":{"author_candidate":1243,"review_candidate":1341,"validate_candidate":1341},"process_relation":{"author_candidate":497,"review_candidate":595,"validate_candidate":595},"request_relation":{"author_candidate":639,"review_candidate":737,"validate_candidate":737},"response_relation":{"author_candidate":763,"review_candidate":861,"validate_candidate":861}},"operand_reconstruction_units":{"AttemptFenceV1":92,"CandidateCapsuleManifestV1":98,"DeliveryEnvelopeV1":32,"EffectFenceV1":102,"RW0WireCancellationRequestObservationV1":62,"RW0WireProcessObservationV1":54,"WorkerCommandV1":116,"WorkerObservationV1":124},"tariff":"two_pass_occurrence_work_including_root_and_owner_revalidation"}}
```

# Classification value contract

`RW0WireCancellationControlClassificationV1` is frozen as follows:

- `_FIELDS = ("classification", "reason")`
- `__slots__ = ("_classification", "_reason")`
- Both fields require exact built-in `str`.
- Construction is available only through private `_create(classification, reason)`.
- Ordinary construction is disabled.
- Subclassing is disabled.
- Setting or deleting attributes raises `AttributeError("immutable")`.
- `copy.copy`, `copy.deepcopy`, and pickling fail with `TypeError("non-pickleable")`.
- `repr(value)` and `str(value)` are exactly `RW0WireCancellationControlClassificationV1`.
- `to_mapping()` returns a fresh exact built-in dictionary ordered `classification`, then `reason`.
- There is no `from_mapping`, schema, ref, digest, canonical identity, equality override, nullable field, or hidden payload.

Coherence is closed:

| ClassificationAllowed reasons |                                                                                                                                                               |
| ----------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `invalid`                     | `invalid_input`, `duplicate_fact`, `unrelated_fact`, `conflicting_fact`, `cancellation_graph_mismatch`                                                        |
| `incomplete`                  | `process_evidence_incomplete`, `resource_limit_exceeded`, `deadline_elapsed`, `signal_delivered`, `cancellation_acknowledged`, `cancellation_request_pending` |
| `finite`                      | `cancellation_rejected`, `target_process_exited`                                                                                                              |

The value has no independent identity. C2 owns the binding through the profile pair and exact ordered operand closure. `finite` means only that the supplied control graph has a finite result for later C2 reasoning.

# Exact relation signatures
```
def cancellation_control_profile_mapping() -> dict[str, object]: ...

def validate_wire_exact_current_cancellation_request_relation(
    *,
    request: RW0WireCancellationRequestObservationV1,
    author_command: WorkerCommandV1,
    attempt_fence: AttemptFenceV1,
    author_effect_fence: EffectFenceV1,
    target_effect_fence: EffectFenceV1,
    target_delivery: DeliveryEnvelopeV1,
    cancellation_effect_fence: EffectFenceV1,
    cancellation_delivery: DeliveryEnvelopeV1,
    target_capsule_manifest: object = _C2A_MISSING,
) -> None: ...

def validate_wire_exact_current_process_observation_relation(
    *,
    observation: RW0WireProcessObservationV1,
    author_command: WorkerCommandV1,
    attempt_fence: AttemptFenceV1,
    author_effect_fence: EffectFenceV1,
    target_effect_fence: EffectFenceV1,
    target_delivery: DeliveryEnvelopeV1,
    target_capsule_manifest: object = _C2A_MISSING,
) -> None: ...

def validate_wire_exact_current_cancellation_response_relation(
    *,
    response: WorkerObservationV1,
    request: RW0WireCancellationRequestObservationV1,
    author_command: WorkerCommandV1,
    attempt_fence: AttemptFenceV1,
    author_effect_fence: EffectFenceV1,
    target_effect_fence: EffectFenceV1,
    target_delivery: DeliveryEnvelopeV1,
    cancellation_effect_fence: EffectFenceV1,
    cancellation_delivery: DeliveryEnvelopeV1,
    target_capsule_manifest: object = _C2A_MISSING,
) -> None: ...

def classify_wire_exact_current_cancellation_control(
    *,
    author_command: WorkerCommandV1,
    attempt_fence: AttemptFenceV1,
    author_effect_fence: EffectFenceV1,
    target_effect_fence: EffectFenceV1,
    target_delivery: DeliveryEnvelopeV1,
    cancellation_effect_fence: EffectFenceV1,
    cancellation_delivery: DeliveryEnvelopeV1,
    request: RW0WireCancellationRequestObservationV1 | None,
    adapter_observations: tuple[WorkerObservationV1, ...],
    process_observations: tuple[RW0WireProcessObservationV1, ...],
    target_capsule_manifest: object = _C2A_MISSING,
) -> RW0WireCancellationControlClassificationV1: ...
```

The target class must be exactly one of the three frozen classes. Author requires the exact sentinel; explicit `None` or a manifest is invalid. Validation/review require one exact safely reconstructed manifest.

Direct C2A calls are:

- Request: target `validate_delivery_relation`, then cancellation `validate_delivery_relation` with `cancellation_target=target_effect_fence`.
- Process: target `validate_delivery_relation`; Wire then binds every observation coordinate to that graph.
- Response: the complete request prerequisite, then `validate_observation_relation` over the cancellation delivery/fence and exact target.
- Classifier: target and cancellation delivery relations once over the common safe graph, then role-specific target or cancellation observation validation without reconstructing common operands again.

No before/after blob map is needed for deadline, exit, acknowledgement, or rejection.

Route bindings are exact:

- Request: direct-local → `supervisor`; ES → `execution_substrate`, based on `cancellation_delivery.adapter_kind`.
- Adapter observation: direct-local → `direct_local_adapter`; ES → `es_adapter`, based on its bound delivery.
- Deadline/exit bind target delivery and target fence.
- Acknowledgement/rejection bind cancellation delivery/fence and exact target.
- Process claims remain `supervisor | operating_system`; no route authenticity is inferred.

Request and response source refs or invocation refs need not match. No timestamp ordering, source authentication, or causality claim is made.

Standalone failure precedence is:

1. Exact outer/type/omission preflight.
2. Local work budget.
3. Exact safe reconstruction and self-digest validation.
4. Target class and capsule branch.
5. C2A owner relations.
6. Wire coordinate and source bindings.

Type failures are content-free `invalid_field_type` or cardinality errors; tampered reconstruction is `invalid_field_value`; budget exhaustion is `work_limit_exceeded`; graph/coherence failure is `relation_mismatch`. Ordinary foreign exceptions are sanitized. `KeyboardInterrupt`, `SystemExit`, and `GeneratorExit` propagate unchanged.

# Safe reconstruction and work bounds

Add `CandidateCapsuleManifestV1` and `_reconstruct_exact_worker_execution_value` to the existing C2A import statement. Do not modify `_C2A_FIELD_INVENTORIES`, C2A source, or C2A tests.

Use a new local `_CancellationControlWorkBudget`. Charge each occurrence’s fixed maximum before touching its reconstruction helper. Do not import C2A’s private budget class.

| OperandExact tariff                       |     |
| ----------------------------------------- | --- |
| `RW0WireCancellationRequestObservationV1` | 62  |
| `RW0WireProcessObservationV1`             | 54  |
| `WorkerCommandV1`                         | 116 |
| `AttemptFenceV1`                          | 92  |
| `EffectFenceV1`                           | 102 |
| `DeliveryEnvelopeV1`                      | 32  |
| `WorkerObservationV1`                     | 124 |
| `CandidateCapsuleManifestV1`              | 98  |

The rule is `2 × (root + maximum bounded raw graph)`.

| OperationAuthor max / one-underValidate or review max / one-under |               |               |
| ----------------------------------------------------------------- | ------------- | ------------- |
| Request relation                                                  | `640 / 639`   | `738 / 737`   |
| Process relation                                                  | `498 / 497`   | `596 / 595`   |
| Response relation                                                 | `764 / 763`   | `862 / 861`   |
| Classifier                                                        | `1244 / 1243` | `1342 / 1341` |

An exact maximum-valid graph evaluates normally. A forced maximum-minus-one relation raises content-free `work_limit_exceeded`; the classifier returns `invalid / invalid_input`. Fixed closed comparisons and the scan of at most seven facts are unmetered but cardinality-bounded.

Cardinality and hostile-input rules:

- Request: exact value or `None`, maximum one.
- Adapter observations: exact built-in tuple, 0–4 exact final `WorkerObservationV1` values.
- Process observations: exact built-in tuple, 0–2 exact final `RW0WireProcessObservationV1` values.
- Total facts: 0–7.
- Every role is singleton; acknowledgement and rejection are mutually exclusive.
- Lists, mappings, tuple subclasses, nullable observation elements, and foreign classes yield `invalid_input`.
- Candidate manifest is the exact three-entry first-slice owner value; owner reconstruction caps traversal at three entries.
- Every supplied occurrence is charged and reconstructed, including repeated aliases. Duplicate object/ref/digest classification happens afterward.
- Active nested cycles fail. A non-active sibling alias is traversed and charged again, then owner path/order rules apply.
- Existing Wire integer extraction requires exact built-in `int`, rejects boolean/subclasses and positive values above `2^63−1` before owner conversion, and leaves field-specific lower bounds to the owner. C2A constrains exit codes to `[-255, 255]`.
- Candidate-manifest byte-length integers retain C2A’s exact nonnegative semantics. Occurrence work is not an integer-bit-length, serialized-byte, or wall-clock bound.
- The owner helper propagates process-control exceptions and converts ordinary failures to cause/context-free `WorkerExecutionValueError`; Wire converts reconstruction failures to `invalid_field_value`.

Existing NWPF caps, hostile-work identities, and digests remain unchanged.

# Classifier matrix and precedence

Exact order:

1. Malformed outer shape, cardinality breach, tampering, reconstruction failure, invalid graph operand, or work exhaustion → `invalid / invalid_input`.
2. Repeated original object identity, safe fact ref, or safe fact digest → `invalid / duplicate_fact`.
3. Closed-shape fact outside admitted roles, or target fact unrelated to the supplied exact target → `invalid / unrelated_fact`.
4. Two distinct facts for one singleton role, or acknowledgement plus rejection → `invalid / conflicting_fact`.
5. Request/response/cancellation/capsule orientation mismatch, including response without request → `invalid / cancellation_graph_mismatch`.
6. No request → `incomplete / process_evidence_incomplete`.
7. Rejection → `finite / cancellation_rejected`.
8. Exact target exit → `finite / target_process_exited`.
9. Resource limit → `incomplete / resource_limit_exceeded`.
10. Deadline → `incomplete / deadline_elapsed`.
11. Signal → `incomplete / signal_delivered`.
12. Acknowledgement → `incomplete / cancellation_acknowledged`.
13. Otherwise → `incomplete / cancellation_request_pending`.

Required coexistence results:

| Supplied coherent factsResult                |                                             |
| -------------------------------------------- | ------------------------------------------- |
| rejection + exit                             | `finite / cancellation_rejected`            |
| acknowledgement + exit                       | `finite / target_process_exited`            |
| signal + exit                                | `finite / target_process_exited`            |
| resource limit + exit                        | `finite / target_process_exited`            |
| deadline + exit                              | `finite / target_process_exited`            |
| target process facts without request         | `incomplete / process_evidence_incomplete`  |
| acknowledgement or rejection without request | `invalid / cancellation_graph_mismatch`     |
| request only                                 | `incomplete / cancellation_request_pending` |
| no facts                                     | `incomplete / process_evidence_incomplete`  |

Exit codes `-255`, `0`, and `255` are equally `finite / target_process_exited`. Zero carries no cancellation-success meaning.

# Status and authority contract

The five synchronized projections are:

- `.docs/rw0-remote-worker-contact-phase-entry.md`
- `.docs/authority-boundaries.md`
- `.docs/autonomous-software-development-operating-model.md`
- `.docs/durable-state-model.md`
- `.docs/worker-execution-boundary.md`

Each retains exactly:
```
<!-- RW0_B2_WIRE_CURRENT_STATUS_BEGIN -->
<one physical nonempty line>
<!-- RW0_B2_WIRE_CURRENT_STATUS_END -->
```

The one physical body line must be identical in all five files and exactly:
```
RW0-B2-Wire now implements private, pure, no-I/O NWPF v1 representational framing, canonical command/result codecs, closed worker-result grammar, safe supplied cancellation-request and process source-claim values, and pure process/result classification. It also implements the separate private, pure, no-I/O cancellation-control evidence profile `rw0-wire-cancellation-control-v1` with digest `4d6f84552b852a4c4073b4238591afd271072f648424eca9e744def436165288`, exact-current author/validation/review cancellation-control relations, and pure `invalid`/`incomplete`/`finite` supplied-control-evidence classification. The additive cancellation-control profile does not replace or enter the fixed NWPF v1 frames, Capability continues to bind only `rw0-wire-nwpf-v1`, and the profile remains distinct from B1 physical host cancellation-mechanism evidence. Physical transport framing and stream/process plumbing remain deferred, as do pre-read allocation, supervisor/worker implementation, cancellation delivery, concrete direct-local or ES wrapper/correlation mechanics, persistence, source authentication, process proof, CLI/App Server integration, credentials, provider/session behavior, and live execution. The fixed protocol profile is `rw0-wire-nwpf-v1` with digest `470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454`; `.docs/rw0-b2-wire-protocol.md` is the detailed owner. RW0-B2-Wire does not own or alter RW0-B1 or C2A schema, canonical-identity, semantic-outcome, or authority contracts; their protected owner reconstruction and occurrence-work accounting are hardened separately for fail-closed Capability composition. No worker, process, contact, persistence, authority, acceptance, or Codex mechanism is implemented. Capability is implemented separately as private, pure, no-I/O semantics owned by `.docs/rw0-b2-capability.md` and does not widen Wire ownership. RW0-B1, RW0-B2-Wire, and RW0-B2-Capability private semantics are current implemented contracts; RW0-C/D/E durable, transport, process, provider, credential, live-proof, and runtime mechanics remain future, and Execution Substrate retains admission and runtime ownership.
```

The Capability marker remains immediately after the Wire block. The existing RW0-B2-Wire registry row remains the sole row; the additive profile does not create a new component.

The detailed Wire owner retains every existing test-pinned phrase and gains separate sections for the value, exact-current relations, classifier, profile identity, reconstruction/work bounds, and nonclaims. C remains future and blocked pending merge. D/E and ES ownership remain unchanged.

# Exact touched-file ceiling

Exactly these 11 files may change:

1. `.docs/rw0-b2-wire-protocol.md`
2. `.docs/rw0-remote-worker-contact-phase-entry.md`
3. `.docs/authority-boundaries.md`
4. `.docs/autonomous-software-development-operating-model.md`
5. `.docs/durable-state-model.md`
6. `.docs/worker-execution-boundary.md`
7. `src/ge_nwp_coordinator/_rw0_wire_protocol_values.py`
8. `tests/test_rw0_b2_wire_cancellation_control_values.py`
9. `tests/test_rw0_b2_wire_cancellation_control_relations.py`
10. `tests/test_rw0_b2_wire_cancellation_control_boundaries.py`
11. `tests/test_rw0_b2_capability_boundaries.py`

File 11 may change only the P01 byte-size integer and SHA-256 after final Wire source bytes are frozen. Its identifier, path, row order, contract class, purpose, and every Capability assertion remain unchanged.

There is no hidden twelfth consumer. `pyproject.toml` already collects the new tests; package exports remain unchanged; all other inventories are path/name or existing-profile checks.

# V1 protected surface

Only two changes may occur above the current Wire EOF:

- Add `CandidateCapsuleManifestV1` and `_reconstruct_exact_worker_execution_value` to the existing C2A import statement.
- Append one self-contained cancellation-control block after the current `classify_wire_process_result`.

Keep `__all__ = ()`; add no standard import, package export, production importer, or caller.

Protected constants:
```
_REQUEST_SCHEMA _PROCESS_SCHEMA _PROFILE_SCHEMA _PROFILE_REF _PROFILE_DIGEST
_MAGIC _VERSION _COMMAND_KIND _RESULT_KIND _MAX_INT _CAPS
_PRIVATE_FRAGMENTS _REF_PREFIXES
_REQUEST_FIELDS _PROCESS_FIELDS _REQUEST_SOURCES _PROCESS_SOURCES _PROCESS_EVENTS
_RESULT_SEQUENCES _ADAPTER_FACTS _CLASSIFICATIONS _REASONS _MATRIX
_DECODER_REASONS _CONSTRUCTION_REASONS _ERROR_TOKEN
_WORK_TEST_EXTRA_UNITS _MAX_SOURCE_MAPPING_KEY_CHARS _MAX_FRAME_KEY_CHARS
_C2A_FIELD_INVENTORIES _PROFILE_IDENTITY_JSON
```

Protected classes:
```
RW0WireProtocolError _WireFailure _BoundaryFailure _ImmutableValue
RW0WireCancellationRequestObservationV1
RW0WireProcessObservationV1
RW0WireWorkerResultV1
RW0WireProcessResultClassificationV1
_SafeC2AExtraction
_JSONTokenFailure _JSONObjectPairs _JSONParseAccounting
_ShapeFrame _ShapeWorkResult
```

Protected function families:
```
_fail _capture _raise_public _unwrap _relation
_closed_mapping _safe_ref _digest _timestamp _canonical _self_digest
_construct _raw_slots
_request_from_mapping_impl _process_from_mapping_impl
_safe_c2a_integer _safe_c2a_extract _rebuild_safe_c2a _rebuild_c2a
_validated_request _validated_process
_worker_result_create_impl _validated_result
_classification_create_impl _validated_classification
_wire_value_mapping_impl
_request_identity_impl _request_canonical_impl _request_digest_impl
_process_identity_impl _process_canonical_impl _process_digest_impl
wire_profile_mapping
_c2a_relation _author_delivery_impl
_validate_wire_cancellation_request_relation_impl
validate_wire_cancellation_request_relation
_validate_wire_process_observation_relation_impl
validate_wire_process_observation_relation
_validate_wire_result_relation_impl validate_wire_result_relation
all current parsing, shape-work, frame, encoder, and decoder functions
_classified _raw_result_observations _valid_result_failure
_classify_wire_process_result_impl classify_wire_process_result
```

The new classification class overrides `to_mapping()` through an additive helper; `_wire_value_mapping_impl` remains unchanged.

The four existing Wire test modules remain byte-for-byte unchanged. All existing B1 and C2A tests remain unchanged. Capability values/vectors/relations tests remain unchanged; only P01’s two literal fields change in the Capability boundary test.

# Permanent test plan

`tests/test_rw0_b2_wire_cancellation_control_values.py`:

1. `test_profile_literal_canonical_bytes_length_and_digest_are_exact`
2. `test_profile_mapping_has_exact_order_and_returns_fresh_builtin_dicts`
3. `test_classification_value_has_exact_fields_and_result_reason_matrix`
4. `test_classification_value_is_final_slotted_immutable_noncopyable_and_nonpickleable`
5. `test_existing_request_and_process_values_remain_golden_compatible`
6. `test_existing_nwpf_profile_and_frame_vectors_are_unchanged`
7. `test_profile_declares_exact_fact_cardinality_and_work_tariffs`

`tests/test_rw0_b2_wire_cancellation_control_relations.py`:

1. `test_request_relation_accepts_complete_target_and_route_matrix`
2. `test_process_relation_accepts_complete_target_event_source_matrix`
3. `test_response_relation_accepts_acknowledgement_and_rejection_matrix`
4. `test_capsule_branch_is_exact`
5. `test_request_source_is_bound_only_to_cancellation_delivery_route`
6. `test_target_cancel_swaps_cross_attempts_and_sibling_graphs_fail`
7. `test_timestamp_order_is_not_semantics`
8. `test_relation_failures_are_content_free_and_process_control_propagates`
9. `test_relation_work_maxima_and_one_under_controls_are_exact`

`tests/test_rw0_b2_wire_cancellation_control_boundaries.py`:

1. `test_classifier_complete_precedence_and_coexistence_matrix`
2. `test_duplicates_precede_unrelated_conflict_and_graph_mismatch`
3. `test_singleton_conflicts_and_ack_reject_exclusion_are_exact`
4. `test_request_response_and_target_process_dependence_is_exact`
5. `test_every_outer_and_cardinality_boundary_is_exact`
6. `test_exit_codes_minus_255_zero_and_255_are_equally_finite`
7. `test_hostile_manifest_reconstruction_cycles_aliases_and_large_integers_fail_bounded`
8. `test_classifier_privacy_and_foreign_exception_sanitization_are_exact`
9. `test_module_remains_private_no_export_no_caller_and_no_io`
10. `test_five_status_projections_and_owner_contract_are_synchronized`
11. `test_capability_b1_and_c2a_identifiers_do_not_churn`
12. `test_capability_p01_row_matches_final_wire_identity`

Expected profile JSON, byte lengths, and digest must be test-owned literals independently computed from the frozen contract—not derived from production. No test may hash or protect its own source.

# Independent audit plan

1. Require the final changed-path set to equal the 11-file manifest exactly.
2. Independently recompute the 12,014-byte manifest, 12,154-byte identity, and `4d6f8455…` digest.
3. Compare every protected pre-existing Wire declaration before/after; permit only the two import names and appended block.
4. Prove all existing Wire tests are byte-identical.
5. Prove every B1/C2A/Capability test is byte-identical except P01’s two fields.
6. Independently recompute final Wire size/hash and compare P01.
7. Apply target/cancel swap, cross-attempt, sibling-manifest, route/source, and response-without-request mutants.
8. Apply every classifier precedence and coexistence mutant.
9. Apply omitted-sentinel, alias, cycle, duplicate identity/ref/digest, and integer-preconversion mutants.
10. Inspect synchronized status lines, marker adjacency, retained phrases, unchanged registry row, and unchanged Capability status.
11. Inspect package exports, production importers/callers, frames, and filesystem/database/network/process APIs.
12. Run focused and complete suites only after implementation, from the clean candidate commit, then repeat the path/P01/worktree checks.

# Forecasts and stop conditions

Falsifiable forecasts:

1. Independent canonicalization will continue to produce exactly `12,014`, `12,154`, and `4d6f84552b852a4c4073b4238591afd271072f648424eca9e744def436165288`. Any difference falsifies the literal freeze.
2. The reused value fields and C2A helper will cover all three targets without C2A, B1, Capability, or v1 helper changes. A required new field or owner change falsifies this.
3. The implementation will fit exactly 11 files. Discovery of another exact content/status/import consumer falsifies the ceiling.

Likely audit findings are tariff off-by-one errors, route/delivery orientation drift, wrong precedence for response-without-request, sibling-manifest acceptance, accidental v1 symbol edits, malformed one-line status projections, or an incorrect final P01 hash.

Stop and replan if any of these occurs:

- The literal or digest cannot be reproduced.
- Existing reusable fields prove insufficient.
- Any existing v1 helper or protected declaration must change.
- C2A, B1, Capability source, package root, dependency metadata, schema, migration, store, or runtime source must change.
- A twelfth path or existing status-test edit becomes necessary.
- Bounded reconstruction cannot be proven.
- Classification meaning becomes ambiguous.
- A production caller, public export, I/O, persistence, transport, process control, or runtime authority is introduced.

# Recommendation

Freeze Option A, the exact `4d6f8455…` profile, the exact relations, and the 11-file ceiling. No stop condition is currently present.

# Next implementation boundary

The next prompt may authorize one parent implementation limited to the 11 files above. It must append the private Wire implementation, add the three permanent test modules, update the six owner/status documents, calculate P01 only after source bytes are final, and then run focused and complete local validation.

RW0-C remains blocked until that implementation is merged and independently audited. No C, D/E, ES, persistence, transport, process, provider, or runtime work enters the implementation tranche.

REPOSITORY\_MUTATION\_NOT\_PERFORMED\
TESTS\_NOT\_RUN\
STAGING\_NOT\_PERFORMED\
COMMIT\_NOT\_PERFORMED\
PUSH\_NOT\_PERFORMED\
PR\_NOT\_CREATED\
REMOTE\_CONTACT\_NOT\_PERFORMED\
WORKER\_OR\_MODEL\_NOT\_INVOKED\
SUPPORTING\_REPOSITORIES\_NOT\_MODIFIED\
IMPLEMENTATION\_NOT\_PERFORMED

RW0\_B2\_CANCELLATION\_FINAL\_CONTRACT\_FREEZE\_READY
