PROMPT_ID

RW0_C1_FINAL_ACCEPTANCE_REAUDIT_V1

TITLE

Coordinator RW0-C1 — final fresh independent acceptance re-audit after final
response-handoff and precommit-cleanup repair

ENGAGEMENT TYPE

Fresh independent read-only audit.

Do not repair, edit, format, generate repository files, stage, commit, push,
create a PR, merge, tag, release, deploy, fetch, contact a remote/live system,
install dependencies, invoke a product worker/model, modify a supporting
repository, or migrate an operator database.

Do not resume, amend, clean, re-index, or write into any predecessor
implementation, repair, or audit root. Create one new private audit root.

Print the complete substantive report inline. Evidence paths may be
supplementary only. Do not place the operative verdict or finding ledger only
in a file.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED LIVE REPOSITORY IDENTITY

physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-c1-durable-evidence-v1

HEAD:
047563de5a443b0f8323401c92979ae2e444d2ed

HEAD tree:
4ff9ee4a710af13447e3ed8699339a51255ff720

sole parent:
dd12b23762dc761736e55a1abfde12dd3ec23551

subject:
feat: add RW0-B2 cancellation-control evidence (#6)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

staged/unmerged:
0/0

candidate:
exactly 81 changed/untracked paths, all regular physical mode 0644, no 82nd
path, no repository residue.

No fetch is authorized. Use local Git metadata only.

FINAL CANDIDATE IDENTITIES

Canonical manifest SHA-256:
c1274e99cc717daf0fc280581f019f8b85eeadfb7d6d211e5a76d5a1ef385bb4

Full-candidate tracked textual diff SHA-256:
5991bfbb4c5b2bbe0f3d0c535a29c5425bb4dacb7c51b62225774686108a715b

Complete provenance-recipe output SHA-256:
14807b0045b2a02d444674883e610caf79b4025bf868237acf39829dab55b22e

Candidate file count:
81

Final collected nodes:
5205

Final ordered node SHA-256:
c54742289bcb5e569cef4f7ce5df88197f60c020226fa0dc9cefb1bfd7ac7218

Opening nodes before the final handoff repair:
5200

Opening ordered node SHA-256:
1337267bfd05f4b5d99db5f987d8c9fcecf85deedc95530ab9c4fa30b2526cc1

Node additions:
5

Removals/renames:
0/0

Final internal candidate fingerprint:
75c350b5e78850d0834c99984f71712b4ffdd93ea6c56cdbe89032b582cfc6c9

FINAL-HANDOFF REPAIR EVIDENCE ROOT

/private/tmp/ge-coordinator-rw0-c1-final-handoff-repair.nYKeMi

Self-excluding index:
/private/tmp/ge-coordinator-rw0-c1-final-handoff-repair.nYKeMi/evidence-index.txt

Index SHA-256:
cf35d96176726094dd0b04d33edcb74cc6fea4de9525def4c800bbe66806e07f

Indexed files:
474

Indexed subdirectories:
35

PREDECESSOR EVIDENCE ROOTS

Verify each read-only and preserve unchanged.

Original implementation:
/private/tmp/ge-coordinator-rw0-c1-implementation.Zcopmg
index:
cd1ad5ea72ef20a774fd470e38f14882a25f99af94db970c4506c62d4a4cc2b4

Mode repair:
/private/tmp/ge-coordinator-rw0-c1-mode-repair.k6Pxw5
index:
5b30767c439a982e209c765f93c775547709555f5305697817a1b335e1bf2cc8

First provenance-stop audit:
/private/tmp/ge-coordinator-rw0-c1-independent-audit.6Cd8VB
index:
3929be307c05a532c491f5f520bad4d76cde702d7e0b41460cf0c8ab90373b25

First substantive audit:
/private/tmp/ge-coordinator-rw0-c1-independent-audit.bYt6vjqX
index:
c276c664922dc4ef87e7418c6657aaf9d61ddb05c643666019ff85c86796168e

First findings repair:
/private/tmp/ge-coordinator-rw0-c1-audit-findings-repair.li1vJX
index:
a62fb4458f838ad23bc23b47bcfbd6527906c94724ea1a1b3044e3bf871c9bc2

Fresh re-audit:
/private/tmp/ge-coordinator-rw0-c1-fresh-reaudit.tWw8xz
index:
424c482738213c716dadaa636dde7f7a838f10472b63b0e9dabd8b226d8d0e5d

Residual findings repair:
/private/tmp/ge-coordinator-rw0-c1-reaudit-findings-repair.iBwPRM
index:
e0a1b61edbf51373c99a4eb155c8c9c05c7c3c8f7239ac9d74db5997165ac52c

Final independent re-audit:
/private/tmp/ge-coordinator-rw0-c1-final-independent-audit.azvkGE
index:
0b3e2d19214b1d934e970dd34539837479d11e9c8f3c4e3da1eb5eccebbab461

Do not alter, clean, re-index, normalize, or reinterpret these roots in place.

EXACT PROVENANCE RECIPE

recipe ID:
governed-execution.audit-patch-manifest.v1

source size:
3945 bytes

source SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

Verify the indexed exact source and the previously accepted safe historical-sink
redirection wrapper. The wrapper may redirect only the output sink and must not
alter Git queries, canonical JSON, stdout, stderr, path classification, or
manifest fields.

CLAIMED FINAL REPAIR DELTA

Exactly seven opening-to-final repository paths changed.

Documentation:

.docs/rw0-c1-durable-evidence.md
.docs/sqlite-operations-and-recovery.md
.docs/writer-session-authority.md

Production:

src/ge_nwp_coordinator/_rw0_c1_mutation_contracts.py
src/ge_nwp_coordinator/sqlite_writer_session.py

Tests:

tests/test_rw0_c1_mutation_contracts.py
tests/test_rw0_c1_recovery.py

Require every other candidate path to be byte-identical to the opening
candidate manifest
`d8c535c68e4096b5e00998d57f504e6139402c4207a0d0a0749fbf2b4c42d936`.

The seven unused allowlisted paths must remain byte-identical.

FINAL FINDINGS CLAIMED REPAIRED

RW0-C1-FINAL-001 — High candidate defect

The private commit/recovery close witnesses now remain normalization-active
through the actual outer writer-frame return boundary, including state
`close_proof_complete`.

Claimed behavior:

- after a real COMMIT, every ordinary failure before successful writer-frame
  exit -> exact content-free `commit_outcome_unknown`;
- after a computed recovery disposition, every ordinary failure before
  successful writer-frame exit -> exact `unresolved`;
- selector-only recovery after a committed final-handoff failure ->
  `committed_exact`;
- no public/durable handoff marker.

RW0-C1-FINAL-002 — Medium candidate defect

An established primary safe error is preserved through operation retirement.

Claimed precedence:

1. governing process-control precedence;
2. existing primary safe WriterSession/SQLite/C1 error;
3. recovery result computed -> `unresolved`;
4. COMMIT attempted -> `commit_outcome_unknown`;
5. standalone precommit/replay cleanup with no primary -> `mutation_failed`.

Exact replay does not attempt another COMMIT and remains one membership/receipt.

RW0-C1-FINAL-003 — Medium historical report/evidence defect

The old historical red-gate provenance remains unchanged and limited.

The final repair claims new prospective acceptance evidence:

- immutable opening test, production, and documentation snapshots;
- exact per-file type/mode/size/SHA inventories;
- immutable red-test snapshot;
- before/after test hash ledger;
- exact test-only patch;
- production-opening equality proof;
- four-case causal red gate with only intended product failures.

Treat FINAL-003 as historically preserved. It is non-blocking only if the new
prospective evidence independently verifies exactly.

PREVIOUS FINDINGS THAT MUST REMAIN CLOSED

- caller-constructible recovery selector;
- sound DNC identity-route closure;
- post-COMMIT cleanup at controller/module/slot/lease boundaries;
- current program/work CAS before collision probes;
- owner-reader error propagation;
- strict rank-6/rank-9 temporal equality;
- recovery cleanup -> unresolved;
- schema/privacy/authority/public boundaries;
- one controller and one connection/COMMIT authority;
- migration 0004 and 15-kind inventory.

AUDIT POSTURE

Create one new private audit root under `/private/tmp`.

Use:

umask 0022
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
unique audit-root PYTHONPYCACHEPREFIX for every Python process
distinct audit-root TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
GIT_OPTIONAL_LOCKS=0
python3 -B
-p no:cacheprovider
-W error

Keep evidence proportionate. Do not build a recursive self-protecting audit
framework. Do not require permanent tests to detect coordinated equal-authority
mutation.

Audit-harness/environment deviations are blocking only when they materially
prevent candidate, provenance, validation, or evidence conclusions. Record
harmless corrected harness incidents as observations rather than inventing
candidate defects.

After provenance passes, conduct exactly four bounded, non-nesting read-only
perspectives. The parent reconciles them:

1. final writer handoff and witness lifetime;
2. primary-error and precommit cleanup precedence;
3. permanent-test causality and prospective test-only provenance;
4. full-candidate provenance, regression, clean reconstruction, schema/privacy/
   authority, and validation.

No perspective may delegate further or modify repository files.

PROVENANCE GATE

Before correctness inspection:

1. Verify exact repository identity, one-worktree topology, and local-only
   upstream/divergence.
2. Verify exactly 81 candidate paths, all regular physical mode 0644.
3. Verify no staged/unmerged path, lock, operation, residue, or 82nd path.
4. Verify the final-repair evidence index exactly:
   path set, type, owner, mode, size, digest, no unsafe or unindexed entry.
5. Verify every predecessor evidence index exactly.
6. Verify exact recipe source and wrapper.
7. Run the recipe twice with safe sink redirection.
8. Require byte-identical manifests and complete outputs matching:
   - manifest `c1274e99...`;
   - textual diff `5991bfbb...`;
   - complete output `14807b00...`;
   - 81 files.
9. Verify every live candidate entry against the manifest.
10. Require every path outside the candidate to equal HEAD.
11. Verify exactly the seven-path final repair delta and all protected bytes.
12. Verify migrations 0001–0004, sqlite_migration.py, DNC readers, semantic
    owners, package exports, StateStore, and public WriterSession protocol
    against their expected protected identities.
13. Record opening repository and evidence inventories for closeout.

Stop before correctness on any mismatch:

AUDIT_PROVENANCE_MISMATCH

AUDIT HYPOTHESES

A. Final writer-frame handoff

Independently inspect the witness predicates and outer writer control flow.

Require:

- commit uncertainty remains active in states:
  commit_attempt_started,
  commit_returned_success,
  close_proof_complete,
  until successful outer writer-frame exit;
- recovery unresolved normalization remains active after disposition computation
  through close_proof_complete and successful writer-frame exit;
- witness is private, one-operation, monotonic, non-durable, non-exported and
  not reusable;
- no fallible ordinary code remains outside the outer normalization boundary
  before the result reaches the caller;
- no durable/public handoff marker exists.

Use an independent external disposable candidate and a real underlying COMMIT.
Do not rely only on candidate-provided testing hooks.

Inject an ordinary failure with an external trace or equivalent independent
mechanism at the actual final writer return/handoff after
`close_proof_complete`.

Committed apply requirements:

- caller receives exact `commit_outcome_unknown`;
- one exact membership and receipt committed;
- no raw RuntimeError, mutation_failed, or database_integrity_failure;
- selector retained before apply recovers `committed_exact`;
- no duplicate rows/receipt.

Recovery requirements:

- compute `committed_exact`;
- inject at actual final recovery return/handoff after close proof;
- caller receives exact `unresolved`;
- no raw or narrower error.

Also independently probe:

- result-publication handoff;
- controller return;
- module-delegate return;
- nominal-capability finalization;
- controller/connection cleanup;
- mutation-slot close;
- operation-lease close;
- process stabilization;
- writer-session post-operation cleanup.

The final-return case is mandatory even if earlier boundaries pass.

B. Primary safe-error and replay cleanup precedence

Independently create:

1. invalid recovery input establishing exact safe `mutation_failed`, followed by
   an operation-lease cleanup failure;
2. one reachable safe WriterSessionError or private C1 safe error followed by a
   secondary ordinary cleanup failure;
3. exact replay, no second COMMIT, followed by standalone ordinary operation
   retirement failure;
4. a precommit fresh-apply path with no primary safe error and a standalone
   cleanup failure.

Require:

- established primary safe error preserved exactly;
- secondary private cleanup exception not exposed;
- exact replay standalone cleanup -> `mutation_failed`;
- precommit standalone cleanup -> `mutation_failed`;
- no `commit_outcome_unknown` where COMMIT never began;
- exactly one existing membership and receipt on replay;
- governing process-control precedence unchanged.

Inspect whether one private precedence helper/control block owns this behavior;
reject divergent duplicated rules across layers.

C. Prospective test-only provenance

Independently verify the final repair’s prospective chronology.

Require:

- immutable opening snapshots for all seven allowed test files, all four
  allowed production files, and all three allowed documentation files;
- exact path/type/mode/size/SHA inventory;
- immutable red-test snapshot;
- exact before/after test ledger;
- exact test-only patch generated from opening and red snapshots;
- aggregate identities equal the report;
- all production files byte-identical through the red gate;
- red candidate differs only in the test files allowed by the repair;
- exact selected four red nodes;
- exactly four intended product failures;
- zero import, collection, syntax, fixture, path, or environment failures;
- candidate fingerprint unchanged except test bytes.

Historical FINAL-003 remains historical and must not be rewritten. The new
evidence may close the prospective causal-evidence requirement only.

Review the five final added tests:

- witness normalization through close;
- committed final handoff;
- recovery final handoff;
- primary safe error plus cleanup;
- exact replay cleanup.

Require each test to map to one finite product claim and reject volume-only
duplication.

Apply isolated external one-predicate mutants:

- remove `close_proof_complete` from commit-normalization predicate;
- remove `close_proof_complete` from recovery-normalization predicate;
- allow cleanup error to replace a primary safe error;
- map replay cleanup to raw error;
- map replay cleanup to commit_outcome_unknown.

For each retain exact hunk, selected node(s), expected/actual outcome,
diagnostic, and restoration proof.

D. Previously closed finding regression

Re-exercise, at minimum:

- caller-constructible pre-apply recovery selector;
- selector-only `committed_exact`;
- DNC exact reusable family versus aliases/child-only/global relation fragments;
- post-COMMIT controller/module/slot/lease cleanup normalization;
- recovery mutation/operation/outer cleanup -> unresolved;
- current CAS before collision probes;
- owner-reader `None` versus safe fault propagation;
- strict rank-6/rank-9 temporal equality and `>` to `>=` mutant kill;
- exact replay with no clock/write;
- no same-writer automatic retry.

E. Schema, privacy and authority regression

Verify no final-repair regression:

- migration 0004 bytes/checksum unchanged;
- 23/46/4 C1 delta and 62/110/5 cumulative totals unchanged;
- zero C1 seeds;
- exactly 15 kinds;
- no capsule entries, WorkSpec bodies, blob-map contents, exception graphs, or
  private runtime material in SQLite;
- no public/package/StateStore/WriterSession protocol widening;
- no production caller;
- no C2/D/E/ES/Bridge/runtime/external-contact behavior;
- B1/Wire/Capability/C2A/C2B/Section 41 owners unchanged;
- one transaction controller and one connection/COMMIT authority;
- DNC reader/query inventory unchanged except protected expected posture.

F. Controller and transaction regression

Verify:

- `_sqlite_rw0_c1.py` has no direct sqlite3 authority;
- sole controller owns BEGIN/COMMIT/ROLLBACK/fencing/capability/cleanup;
- replay/conflict paths never attempt COMMIT;
- one commit attempt on fresh apply;
- no ordinary precommit error is widened to commit uncertainty;
- no result reaches the caller before outer close proof;
- transition, global-stop, C2B and non-C1 WriterSession cleanup semantics remain
  unchanged;
- process-control precedence remains repository-correct.

INDEPENDENT VALIDATION ORDER

1. Provenance gate.
2. Static inspection of seven-path repair and protected-byte comparison.
3. Independent final-return/handoff probes.
4. Independent primary-error/replay-cleanup probes.
5. Prospective test-only provenance verification.
6. External isolated test mutants.
7. Previously closed finding regression probes.
8. Fresh focused runs:
   - final-handoff/precedence focus;
   - all nine C1 modules;
   - writer/controller/cleanup compatibility;
   - transition/global-stop/C2B regressions;
   - DNC/selector/CAS/reader/temporal groups;
   - migration/schema/fixture compatibility;
   - semantic-owner compatibility;
   - architecture/status/privacy/non-authority.
9. Fresh live collection.
10. Build an independent clean candidate:
    - exact HEAD archive;
    - overlay exactly 81 final manifest paths;
    - fully external Git repository/object database;
    - no alternates and no shared source-object inodes;
    - diagnostic commit of exact candidate tree.
11. Clean collection and focused final-handoff/C1 validation.
12. If no Critical, High, Medium, or Low blocker remains:
    - one live complete suite;
    - one external clean-commit complete suite.
13. Closeout and exact provenance reproduction.

Do not substitute retained final-repair validation for independent validation.
If deterministic material blockers are found before the complete-suite gate,
withhold complete suites and state so.

NODE RECONCILIATION

Independently require:

- final live collection exactly 5205 nodes;
- ordered SHA-256
  `c54742289bcb5e569cef4f7ce5df88197f60c020226fa0dc9cefb1bfd7ac7218`;
- all 5200 opening nodes retained in exact relative order;
- exactly five additions;
- zero removals, renames, duplicates, skips, or xfails;
- additions only in the two reported test files;
- clean and live collections identical.

FINDING CLASSIFICATION

For every finding report:

- ID;
- type;
- severity: Critical / High / Medium / Low / Observation;
- current contract or target;
- exact path/line;
- evidence and reproduction;
- impact;
- required correction;
- uncertainty;
- classification:
  candidate defect, contract defect, test/oracle defect, audit-harness defect,
  report defect, or environment defect.

Do not allow harmless corrected audit-harness incidents to masquerade as
candidate defects. Do not allow broad passing tests to override a deterministic
handoff, precedence, transaction, recovery, privacy, or authority failure.

CLOSEOUT

At closeout:

- reproduce the final manifest twice;
- verify opening/closing repository identity, status, path set, modes, diff,
  and candidate fingerprint;
- verify all predecessor and final-repair evidence roots unchanged;
- remove only audit-created disposable paths;
- retain material commands, probes, stdout/stderr, JUnit, node lists,
  manifests, inventories, patches, and report;
- root/directories mode 0700;
- retained files mode 0400;
- no retained symlink or special entry;
- create a self-excluding evidence index last and independently reverify it.

VERDICT

Return:

ACCEPT

and exactly:

COORDINATOR_RW0_C1_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE

only if provenance, FINAL-001/002 closure, prospective test causality,
previously closed findings, schema, privacy, authority, independent validation,
and evidence all pass with no Critical, High, Medium, or Low finding.

Historical FINAL-003 may remain as an Observation when the new prospective
evidence is exact. It must not by itself block acceptance.

Otherwise return:

BLOCK

with a severity-ranked ledger and no repair.

REQUIRED FINAL STATEMENTS

REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
MIGRATION_SCHEMA_NOT_MODIFIED
PUBLIC_API_NOT_WIDENED
RW0_C2_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
