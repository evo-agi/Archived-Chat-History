PROMPT_ID

RW0_C1_DURABLE_EVIDENCE_FRESH_INDEPENDENT_AUDIT_V1

TITLE

Coordinator RW0-C1 — fresh independent audit of durable phase establishment,
typed evidence membership, transaction atomicity, replay, privacy, and
commit-uncertainty recovery

ENGAGEMENT TYPE

Fresh independent read-only audit.

Do not repair, edit, format, create, delete, rename, chmod, stage, commit, push,
open or modify a PR, merge, tag, release, deploy, fetch, contact a remote or
live system, install dependencies, or inspect/modify another repository.

You may:

- inspect all Coordinator repository files;
- run collection and tests;
- create disposable external repository copies and SQLite databases;
- apply audit-only mutants and fault injection only in disposable external
  copies or in-memory test harnesses;
- create one new private audit evidence root under `/private/tmp`;
- remove only audit-created disposable basetemps, pycache roots, temporary
  databases, extracted archives, and external candidate copies after retaining
  material results.

Never alter the source repository or any pre-existing implementation-evidence
root.

Print the complete substantive audit report inline in chat. Evidence files are
supplementary only; do not put findings, verdict, or required correction solely
in a file.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

EXPECTED LIVE CANDIDATE IDENTITY

Require exactly:

branch:
codex/rw0-c1-durable-evidence-v1

HEAD:
047563de5a443b0f8323401c92979ae2e444d2ed

HEAD tree:
4ff9ee4a710af13447e3ed8699339a51255ff720

sole parent:
dd12b23762dc761736e55a1abfde12dd3ec23551

subject:
feat: add RW0-B2 cancellation-control evidence (#6)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

candidate topology:
exactly 81 unstaged tracked modifications/untracked additions
0 staged
0 unmerged
no path outside the accepted manifest
no unused allowlist path
all candidate paths regular mode 0644

Git operation/lock:
none

No fetch is authorized.

IMPLEMENTATION EVIDENCE TARGET

Implementation evidence root:

/private/tmp/ge-coordinator-rw0-c1-implementation.Zcopmg

Expected self-excluding evidence index:

path:
`/private/tmp/ge-coordinator-rw0-c1-implementation.Zcopmg/evidence-index.txt`

SHA-256:
`cd1ad5ea72ef20a774fd470e38f14882a25f99af94db970c4506c62d4a4cc2b4`

Expected indexed inventory excluding the index:

- regular files: 183
- directories excluding root: 22
- retained directories mode 0700
- retained files mode 0400
- no symlink or special entry
- no unindexed retained entry

Expected exact provenance recipe:

recipe ID:
`governed-execution.audit-patch-manifest.v1`

size:
3945 bytes

SHA-256:
`db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc`

Expected wrapper:

size:
645 bytes

SHA-256:
`d95858c5d3bae74b12db30d1c7806f6d25b471fe40d90adb393c0d24cb932270`

Expected accepted implementation manifest:

path:
`/private/tmp/ge-coordinator-rw0-c1-implementation.Zcopmg/provenance-v7/manifest-run-1.json`

file count:
81

canonical manifest SHA-256:
`5cd3d1046660b59378f4c1ae24f40a5d6d5dc5850377f14780cc510568eb5456`

tracked textual diff SHA-256:
`c9e81fe9e3e82a39a5a239277d5187f67ea4795e285773b60f9b9afd4d858f54`

complete recipe output SHA-256:
`e4f2d8f0f318edd9701ec8da2afb429d1803c45578ed77456fe17e26d8016c20`

Expected opening node identity:

count:
5087

ordered SHA-256:
`fe756529f88a3c44c31a402d2266b00b14993f420b76fa2af15595103599580c`

Expected final node identity:

count:
5157

ordered SHA-256:
`efd65837c5c0e05bcd720dc52be6bfd32aa1f861392496864900fb083e0971df`

Expected migration 0004 identity:

path:
`src/ge_nwp_coordinator/sqlite_migrations/0004_rw0_c1_durable_evidence.sql`

size:
289058 bytes

SHA-256:
`967b9c2deb43da625f9ce82d43c9538bfd2fa27c02f3abdfcb12eb3a2aef8cec`

Expected implementation complete-suite result:

- one credited official attempt only;
- 5157 collected and passed;
- zero failures, errors, skips, xfails, xpasses, warnings;
- empty stderr;
- exact JUnit/node mapping.

IMPORTANT VALIDATION-BINDING NOTE

The implementation report says credited pytest ran while the new feature branch
had no upstream, then the branch-local upstream was set to `origin/trunk_dev`
without network contact. Repository bytes and textual diff reportedly remained
unchanged, but a topology fingerprint changed because upstream is included in
that fingerprint.

Do not treat this metadata-only change as a candidate defect by itself.
Independently determine:

- whether credited validation is bound to the exact candidate file bytes;
- whether the implementation manifest was generated after final branch
  metadata;
- whether any substantive file/index/tree change occurred;
- whether fresh audit validation reproduces the candidate.

If the bytes or manifest differ, stop at provenance. If only upstream metadata
differs and exact bytes are proven, record it accurately and proceed.

CURRENT PRODUCT CONTRACT

RW0-C1 is intended to be a private no-contact durable capability with exactly:

- immutable phase establishment;
- one kind-scoped typed evidence registry;
- stable phase-specific memberships;
- exactly 15 member kinds;
- versioned phase/member relation bindings and dense ordered operands;
- receipt-first idempotency and exact replay;
- content-free conflicts;
- private bounded readback;
- one commit attempt;
- explicit committed_exact / definitely_not_committed / unresolved recovery.

C1 does not own:

- evidence completeness;
- source authenticity;
- external permission;
- current execution authority;
- C2B decision;
- acceptance latch;
- terminal outcome;
- worker/runtime/transport behavior;
- external contact;
- public API or production caller.

RW0-C2, RW0-D, RW0-E, and Execution Substrate integration remain future or
externally owned.

The existing B1, NWPF Wire, cancellation-control Wire, Capability, C2A, C2B,
Section 41, migrations 0001–0003, package exports, StateStore, and public
WriterSession contracts must not change semantically.

ASSURANCE BOUNDARY

Permanent repository tests own finite product, schema, transaction, replay,
recovery, privacy, and authority claims.

This audit owns adversarial integrity, independent schema inspection, external
fault/mutation checks, provenance, and patch identity.

Do not require permanent tests to defend themselves against arbitrary
equal-authority mutation. Do not construct a recursive self-protecting audit
framework. Record material commands and evidence proportionately.

AUDIT ROOT AND HYGIENE

Create one new root:

`/private/tmp/ge-coordinator-rw0-c1-independent-audit.XXXXXX`

Requirements:

- root/directories mode 0700;
- retained regular files mode 0400;
- no retained symlink, FIFO, socket, device, or other special entry;
- use `python3 -B`;
- set `PYTHONDONTWRITEBYTECODE=1`;
- use audit-root-local pycache, TMPDIR, HOME, basetemp, JUnit, stdout, and
  stderr paths;
- never import or execute a Python module directly from the retained
  implementation evidence root;
- if an implementation-evidence script must execute, first verify and copy it
  into the new audit root;
- do not write to the source repository or prior evidence roots.

A nonmaterial audit-hygiene deviation is an audit observation, not a candidate
defect, unless it changes or undermines candidate/evidence bytes. Do not let
irrelevant process-history formalism replace the correctness audit.

PHASE 1 — PROVENANCE GATE

Before correctness inspection:

1. Verify exact repository identity and topology.
2. Verify the implementation evidence index independently:
   - canonical path inventory;
   - exact modes, sizes, and hashes;
   - no extra or missing retained entry;
   - index excludes itself.
3. Verify exact recipe source and wrapper bytes.
4. Run two fresh recipe reproductions through a safe output redirection in the
   new audit root.
5. Require:
   - byte-identical manifests;
   - byte-identical complete stdout;
   - empty stderr;
   - exact manifest hash, textual-diff hash, and file count above.
6. Verify every live candidate path against the manifest:
   - path;
   - tracked/untracked classification;
   - type;
   - mode;
   - size;
   - SHA-256.
7. Verify every repository path outside the manifest equals HEAD by Git object
   identity/type/executable bit.
8. Verify no staged/unmerged path, operation, lock, cache, bytecode, database,
   journal, archive, build output, or generated repository manifest exists.
9. Independently collect candidate nodes and require the final node identity
   above.
10. Compare candidate nodes to clean `git archive HEAD` and to the retained
    opening/final lists:
    - all 5087 opening nodes retained in identical relative order;
    - exactly 70 additions;
    - no removal or rename;
    - additions confined to the reported new/touched test surfaces.

On any provenance or identity mismatch, stop before correctness with exactly:

AUDIT_PROVENANCE_MISMATCH

Do not repair.

PHASE 2 — FOUR BOUNDED AUDIT PERSPECTIVES

Use exactly four bounded, non-nesting read-only perspectives. A parent-only
sequential implementation is acceptable if subagents are unavailable; record
that fact without blocking.

Perspective 1 — migration and durable schema

Independently verify:

- migration identity, checksum, sequence, generation, destructive flag, and
  zero seed;
- migrations 0001–0003 byte-identical;
- exactly 23 new STRICT tables;
- exactly 46 new immutable triggers;
- exactly four new explicit indexes;
- cumulative 62 tables, 110 triggers, five explicit indexes;
- exact table columns/order/types/nullability/CHECKs;
- exact PK, UNIQUE, FK, FK actions, and index predicates;
- kind-scoped evidence identity;
- stable membership identity;
- same-phase relation-operand FK;
- phase-establishment and member relation branches;
- two-relation and 14-operand ceilings;
- rank-13/rank-14 branches;
- no generic JSON/BLOB evidence body;
- no capsule-entry or full-manifest durable table/columns;
- no C2 decision, completeness, latch, closure, or terminal table;
- no seed row.

Apply and inspect:

- fresh initialization through 0004;
- upgrade from exact supported prefixes ending in 0001, 0002, and 0003;
- exact schema equivalence across fresh/upgraded databases;
- older terminal-0003 rejection of newer schema where applicable;
- immutability trigger behavior;
- zero-row initial state for every C1 table.

Use only audit-created external databases.

Perspective 2 — semantic values, readers, privacy, and authority

Inspect and independently probe:

- exact 15-kind rank/schema/scope registry;
- no sixteenth kind;
- cross-kind ref/digest reuse allowed;
- same-kind aliases rejected;
- stable membership ref/digest;
- all typed payload and child mappings;
- exact relation proof modes and relation-count rules;
- exact temporal-source registry;
- operation time versus semantic evaluation time;
- future-dated and rank-6/rank-9 mismatch rejection;
- admission snapshots for selection/effect/delivery/global-stop;
- historical readback does not consult mutable current heads or current clock;
- reader query columns, predicates, order, and exact bounded limits;
- no `SELECT *`;
- no public reader;
- no package export;
- no StateStore/public WriterSession widening;
- no production caller;
- no second SQLite importer/connection authority.

Privacy inspection:

After representative valid writes for all 15 kinds, inspect every durable C1
cell and assert absence of:

- raw WorkSpec body, requirements, exclusions, or path list;
- capsule entries, paths, modes, per-file digests/lengths, bytes, or full
  manifest;
- before/after blob-map keys or values;
- exception object, traceback, cause, context, or arbitrary message;
- credential, bearer, signature, trust root, endpoint, host/workspace secret;
- prompt, response, transcript, reasoning, provider/session log;
- process handle/PID;
- permission, acceptance, terminal, or completeness authority.

Perspective 3 — transaction, replay, conflict, and recovery correctness

Verify the existing `_CoordinatorMutationTransactionController` remains the
sole lifecycle authority.

Inspect and externally exercise:

- operation guard and mutation slot;
- connection open and `BEGIN IMMEDIATE`;
- managed-schema/binding validation;
- writer fencing before receipt disclosure;
- receipt-first replay;
- prerequisite reads and collision probes;
- owner relation invocation exactly once for a fresh operation;
- whole-second transaction timestamp capture;
- typed/child/membership/relation/operand writes;
- receipt written last;
- full in-transaction readback;
- capability invalidation;
- exactly one commit attempt;
- rollback/cleanup and process-control stabilization.

Externally inject faults at every material boundary for both mutation families:

- each operation-owned insert;
- child-row insertion;
- membership;
- relation binding;
- relation operand;
- receipt;
- readback;
- capability invalidation;
- rollback;
- immediately before commit;
- commit before underlying commit effect;
- commit after underlying commit succeeds but before outcome returns;
- cursor close;
- connection close;
- operation cleanup.

For each, independently classify:

- committed_exact;
- definitely_not_committed;
- unresolved.

Verify:

- no automatic retry after commit_outcome_unknown;
- fresh writer required for recovery;
- no duplicate phase/member/receipt;
- reusable global evidence may preexist without confusing operation absence;
- missing/partial/colliding families are unresolved;
- exact replay captures no clock and writes nothing;
- same mutation ref/different command is mutation_ref_reuse;
- content-free outward conflict/error results.

Progression checks:

- establish a phase;
- legitimately advance selection/effect/delivery/global-stop current rows;
- prove committed phase recovery remains exact from immutable snapshots;
- prove a definitely absent operation remains absent while a later retry is
  governed by fresh CAS.

Temporal checks:

- rank 1–4 use operation timestamp;
- rank 6 uses subject qualification time;
- rank 9 uses equal rank-6/qualification time;
- later admission is legal;
- future-dated evidence fails before writes;
- replay/recovery use persisted time, never the current clock.

Perspective 4 — tests, docs, patch scope, and nonauthority

Audit every changed document/test/source for:

- current-versus-future status accuracy;
- no stale “C1 future” claims in current owner regions;
- no claim that C2/D/E/ES is implemented;
- no hidden semantic churn in B1, Wire, Capability, C2A, C2B, or Section 41;
- no modified migrations 0001–0003;
- no public/package/runtime widening;
- exact 81-path causal scope;
- no gratuitous rewrite of historical tranche records.

The implementation report says the causal red gate failed only because migration
0004 was absent. Treat that as weak implementation-process evidence, not as
proof of test adequacy.

Build an independent claim-to-test matrix and identify:

- untested product branches;
- test/oracle defects;
- non-causal tests;
- production-derived expected values;
- stale source/hash/inventory assertions;
- tests that pass without exercising the named contract.

Use external one-predicate mutants in disposable copies for at least:

- each schema count and migration identity;
- kind-scoped versus global identity;
- membership ref/digest corruption;
- same-phase operand FK weakening;
- relation count 0/1/2 and overflow;
- rank-14 present/finite_failure/absent;
- temporal source registry and future timestamp;
- snapshot/current-row confusion;
- receipt-last ordering;
- mutation-ref replay conflict;
- partial-family recovery;
- forbidden private-material persistence;
- public/export/importer widening;
- accidental C2 table/state addition.

Each mutant must change one predicate and be restored/discarded in its external
copy. Do not mutate both checker and oracle and call it a candidate threat.

PHASE 3 — INDEPENDENT VALIDATION

If a deterministic Critical, High, Medium, or Low blocker is established before
validation, focused and complete suites may be withheld. State exactly what was
run and why later validation was not credited.

If no blocker is established:

Environment:

- `umask 022`
- `LC_ALL=C`
- `LANG=C`
- `PYTHONDONTWRITEBYTECODE=1`
- distinct audit-root pycache/TMPDIR/HOME/basetemp/JUnit paths per run
- `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`
- `PYTEST_ADDOPTS=''`
- `PYTHONHASHSEED=0`
- `GIT_OPTIONAL_LOCKS=0`
- `python3 -B`
- `-p no:cacheprovider`
- `-W error`
- serial execution

Run focused groups independently:

1. all nine C1 test modules;
2. migration/schema/fixture compatibility;
3. readers/controller/writer/recovery;
4. all B1/Wire/Capability/C2A/C2B/Section 41 owner compatibility;
5. status/architecture/privacy/runtime-non-authority.

Run selected C1 tests against three representations:

A. live unstaged candidate;
B. fully external independent staged candidate;
C. the same external candidate after one diagnostic commit.

Require:

- equal candidate tree for B/C;
- equal C1 projections/results;
- no dirty-status dependency;
- no shared source/external object inode;
- no alternates;
- no source repository mutation.

Then run exactly:

- one live complete suite;
- one external clean-commit complete suite.

Do not retry a complete suite merely because it fails. Classify the failure.
No third complete-suite attempt is authorized.

Every credited pytest run requires:

- return code 0;
- every collected case passed;
- zero failure/error/skip/xfail/xpass/warning;
- empty stderr;
- parseable JUnit;
- zero duplicate/unmapped identities;
- exact node mapping;
- caller/child umask 0022;
- unchanged pre/post candidate file fingerprint.

PHASE 4 — DEFECT CLASSIFICATION

Classify every finding as one of:

- candidate implementation defect;
- contract/authority defect;
- test/oracle defect;
- audit-harness defect;
- report/evidence defect;
- environment/tooling defect;
- observation.

Severity:

- Critical
- High
- Medium
- Low
- Observation

Do not block the candidate solely for a nonmaterial audit-hygiene observation.
Block when candidate correctness, contract soundness, test adequacy, or evidence
binding is materially insufficient.

For each finding include:

- stable ID;
- type;
- severity;
- current contract or strategic target;
- exact path and line;
- exact evidence;
- impact;
- required correction;
- uncertainty;
- patch-specific or pre-existing classification.

PHASE 5 — CLOSEOUT

Before final verdict:

- re-run the exact recipe twice through safe audit-root redirection;
- require candidate bytes, manifest, and textual diff equal opening;
- verify source status/index/topology unchanged;
- verify implementation evidence root unchanged;
- remove only audit-created transient material;
- seal the new audit root with a self-excluding canonical index;
- externally re-read and verify it;
- retain no special entry.

Do not alter the candidate to fix audit findings.

FINAL VERDICTS

On exact provenance mismatch:

AUDIT_PROVENANCE_MISMATCH

On audit-harness failure that prevents a correctness conclusion but does not
establish a candidate defect:

AUDIT_HARNESS_FAILURE

On material candidate, contract, test, or validation defect:

BLOCK

On no Critical, High, Medium, or Low defect:

ACCEPT

When accepting, include exactly:

COORDINATOR_RW0_C1_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE

No staging, commit, push, or PR action is authorized by this audit.

REQUIRED INLINE REPORT

# Verdict
# Opening and closing repository identity
# Provenance and exact 81-path candidate
# Implementation-evidence assessment
# Four audit perspectives and disagreements
# Severity-ranked finding ledger
# Migration 0004 and cumulative schema
# Semantic values, membership, and relation integrity
# Privacy inspection
# Phase establishment
# All 15 evidence-admission kinds
# Transaction ordering and authority
# Replay, conflicts, and idempotency
# Commit-uncertainty recovery
# Temporal and mutable-snapshot behavior
# Permanent-test and external-mutant adequacy
# A/B/C state result
# Node identity and migration
# Retained validation assessment
# Independent validation
# Public, privacy, and authority boundary
# Closeout and audit evidence index
# Confidence

Required final statements:

REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
PRODUCTION_OWNER_SEMANTICS_NOT_MODIFIED
PUBLIC_API_NOT_WIDENED
STATESTORE_PUBLIC_SURFACE_NOT_WIDENED
WRITERSESSION_PUBLIC_PROTOCOL_NOT_WIDENED
RW0_C2_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
