PROMPT_ID

RW0_B2_CANCELLATION_CONTROL_COMMIT_PUSH_PR_GATE_V1

TITLE

Coordinator RW0-B2 — stage, validate, commit, push, and open one PR for the
accepted additive cancellation-control evidence tranche

ENGAGEMENT TYPE

Authorized commit/push/pull-request gate in the existing write-enabled
Coordinator conversation.

No implementation repair is authorized.

Do not merge the PR.
Do not enable auto-merge.
Do not push directly to trunk_dev.
Do not force-push, amend, rebase, create a second commit, create a second PR,
delete the feature branch, tag, release, deploy, contact a provider/live host,
invoke a product worker/model, mutate a database, install a dependency, run a
migration, or modify a supporting repository.

The parent performs the gate. Do not create subagents.

Print the complete operative result inline. Evidence paths may be supplementary
only after every material identity, command, validation result, Git effect, PR
result, limitation, and final guard is stated inline.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

ACCEPTED AUDIT VERDICT

The fresh independent audit returned:

```text
ACCEPT

COORDINATOR_RW0_B2_CANCELLATION_CONTROL_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

No Critical, High, Medium, or Low candidate defect remains.

The sole audit observation was:

```text
RW0B2-RC-O01
```

It concerns causal isolation of one permanent cross-attempt assertion while an
audit-owned isolated cross-attempt probe independently killed the mutation.
It is non-blocking and does not authorize a repository repair in this gate.

REQUIRED OPENING IDENTITY

Require exactly:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-cancellation-control-v1

HEAD:
dd12b23762dc761736e55a1abfde12dd3ec23551

HEAD subject:
feat: implement RW0-B2 Capability semantics (#5)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
11 paths
8 tracked modifications
3 untracked additions
0 staged
0 unmerged

all candidate paths:
regular mode 0644

Git operation/lock:
none
```

The local branch’s upstream was associated with `origin/trunk_dev` after an
initial missing-upstream observation and without remote contact. This is
accepted repository-local metadata history. Require the current identity above.

Require before staging:

```text
git diff --check:
clean

cached diff:
empty

candidate symlink/special path:
none

twelfth changed path:
absent

repository cache, bytecode, database, journal, archive, build output,
generated manifest, or recorder residue:
none
```

If any identity differs, stop before staging.

ACCEPTED CANDIDATE EVIDENCE

Implementation evidence root:

```text
/private/tmp/rw0-b2-cancellation-control-implementation.PxLuO0
```

Implementation evidence index:

```text
entries:
295

SHA-256:
185cdf69863cee3a8390a7f7e3c0412275376fd2029e8a863585c4b176d09443
```

Accepted implementation manifest:

```text
/private/tmp/rw0-b2-cancellation-control-implementation.PxLuO0/closing/final-manifest-run1.json

size:
2540 bytes

SHA-256:
4ee166ef60e38e5adb0fc6f4489ec1813c4d2898e49541652b1e9688305b42a3

file count:
11
```

Accepted implementation diff identities:

```text
tracked textual diff SHA-256:
ba20077fabfda4470d41453751ac60f4c15488ab5859bb207c36a4ac9731fbcc

standard binary diff SHA-256:
b847e01ecad7669704a208113bdd409dd382e68c0b98d182731e182a071b32a8
```

Independent audit evidence root:

```text
/private/tmp/rw0-b2-cancellation-control-audit.KqiMBv
```

Independent audit index:

```text
entries:
145

size:
16511 bytes

SHA-256:
580f5f1d191dfeb58ccbe68423d510f1368c9f1df2033791bab4ad59db0cfe78
```

Read-only verify both evidence roots and preserve them unchanged.

ACCEPTED SEMANTIC IDENTITIES

Existing NWPF v1 remains:

```text
profile:
rw0-wire-nwpf-v1

digest:
470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454
```

New cancellation-control profile:

```text
schema:
governed-execution.nwp-rw0-wire-cancellation-control-profile.v1

ref:
rw0-wire-cancellation-control-v1

manifest:
12014 bytes

outer identity:
12154 bytes

digest:
4d6f84552b852a4c4073b4238591afd271072f648424eca9e744def436165288
```

Final Wire source:

```text
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py

size:
126092 bytes

SHA-256:
fdb97043f4f93620ecf5be43e78ebda0553e2792a219ab846789ad586790c776
```

Accepted nodes:

```text
count:
5087

ordered SHA-256:
fe756529f88a3c44c31a402d2266b00b14993f420b76fa2af15595103599580c
```

Accepted complete suite:

```text
5087 collected
5087 passed
0 failures
0 errors
0 skipped
0 xfailed
0 xpassed
0 warnings
empty stderr
```

EXACT 11-PATH STAGING ALLOWLIST

Tracked modifications:

```text
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/rw0-b2-wire-protocol.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/worker-execution-boundary.md
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
tests/test_rw0_b2_capability_boundaries.py
```

Untracked additions:

```text
tests/test_rw0_b2_wire_cancellation_control_boundaries.py
tests/test_rw0_b2_wire_cancellation_control_relations.py
tests/test_rw0_b2_wire_cancellation_control_values.py
```

Expected shape:

```text
8 modifications
3 additions
0 deletions
0 renames
0 copies
0 mode changes
all committed mode 100644
```

Do not stage any other path.

NEW GATE EVIDENCE ROOT

Create one short neutral root:

```text
/private/tmp/rw0-b2-cancellation-control-commit-gate.XXXXXX
```

Requirements:

- operator-owned;
- non-symlink;
- mode `0700`;
- all pytest-visible temporary paths below this root;
- `python3 -B`;
- `PYTHONDONTWRITEBYTECODE=1`;
- distinct external `PYTHONPYCACHEPREFIX`, `TMPDIR`, `--basetemp`, and JUnit
  paths for collection and suite;
- retained files mode `0400`;
- retained directories mode `0700`;
- no symlink or special retained entry;
- one self-excluding index created last.

Keep evidence proportionate. Retain opening identity, remote/policy preflight,
accepted-manifest verification, staged manifest/tree, collection, complete
suite, commit, push, PR, final guards, cleanup, and final report. Do not build a
recursive self-protecting evidence system.

REMOTE AND POLICY PREFLIGHT

Before staging:

1. verify authenticated GitHub identity;

2. verify `origin`;

3. fetch only:
   - `refs/heads/trunk_dev`;
   - `refs/heads/codex/rw0-b2-cancellation-control-v1`;
   without tags;

4. require remote `trunk_dev` still equals:

   ```text
   dd12b23762dc761736e55a1abfde12dd3ec23551
   ```

5. require local HEAD/base identity remains exact after fetch;

6. inspect whether the remote feature branch already exists;

7. inspect whether any open or closed PR already uses this head branch;

8. inspect applicable `trunk_dev` rules and repository settings:
   - allowed merge methods;
   - required approvals;
   - required status checks;
   - thread-resolution policy;
   - bypass actors;
   - auto-merge;
   - delete-branch-on-merge;

9. stop before staging on:
   - remote base drift;
   - a conflicting remote feature ref;
   - a conflicting PR;
   - local identity drift.

No bypass may be used.

PROVENANCE REPRODUCTION

Verify the exact recipe:

```text
size:
3945 bytes

SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

Copy exact bytes into the new evidence root as mode `0400`.

Run it twice before staging, redirecting only the fixed historical sink.

Require:

```text
both manifests byte-identical
both equal the accepted 11-file manifest
both complete outputs byte-identical
empty stderr
source repository unchanged
```

STAGING

Stage exactly the 11 allowlisted paths in one bounded staging action.

After staging require:

```text
11 staged paths
8 M
3 A
0 D
0 R
0 C
0 unmerged
0 unstaged candidate change
0 untracked candidate path
0 extra staged path
all modes 100644
```

For each staged path require:

- staged blob equals the accepted manifest;
- working file equals the staged blob;
- type and mode equal the accepted manifest.

Compute and freeze the staged tree OID. This OID becomes the exact commit tree.

Print all 11 staged paths with status, mode, blob OID, byte size, and SHA-256 in
the final report.

If any staging predicate fails:

- unstage exactly these 11 paths;
- require restoration to opening topology;
- stop without repair, commit, push, or PR.

VALIDATION ENVIRONMENT

For collection and complete suite:

```text
umask 022
child numerical umask 0022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
GIT_OPTIONAL_LOCKS=0
python3 -B -m pytest -p no:cacheprovider -W error
serial execution
```

Use distinct evidence-root paths for:

```text
PYTHONPYCACHEPREFIX
TMPDIR
--basetemp
--junitxml
stdout
stderr
```

Do not expose secrets. Do not write pytest artifacts into the repository.

COLLECTION

Run exactly once against the staged candidate.

Require:

```text
5087 unique nodes

ordered SHA-256:
fe756529f88a3c44c31a402d2266b00b14993f420b76fa2af15595103599580c

return code 0
zero warnings
empty stderr
parseable JUnit
zero duplicate identities
zero unmapped cases
staged tree unchanged before/after
working bytes unchanged before/after
```

No second collection is authorized.

COMPLETE SUITE

Run exactly once against the staged candidate.

Require:

```text
5087 collected
5087 passed
0 failures
0 errors
0 skipped
0 xfailed
0 xpassed
0 warnings
empty stderr
parseable JUnit
exact ordered mapping to the accepted node list
staged tree unchanged before/after
working bytes unchanged before/after
```

No retry is authorized.

If collection or suite fails:

- preserve complete evidence;
- unstage exactly the 11 paths;
- restore opening topology;
- stop with no commit, push, or PR;
- do not repair.

PRE-COMMIT GUARDS

Require:

```text
staged tree:
the frozen staged-tree OID from this gate

parent:
dd12b23762dc761736e55a1abfde12dd3ec23551

exact 11 staged paths
all staged/working blobs equal accepted manifest
no unstaged or untracked path
no Git operation or lock
no repository residue
remote base unchanged
implementation evidence unchanged
audit evidence unchanged
```

COMMIT

Create exactly one commit.

Required subject:

```text
feat: add RW0-B2 cancellation-control evidence
```

Required body:

```text
empty
```

Do not amend.

Require:

```text
tree:
exact frozen staged tree

sole parent:
dd12b23762dc761736e55a1abfde12dd3ec23551

shape:
8 modifications
3 additions
0 deletions
0 renames
0 copies
0 mode changes
```

Record:

```text
commit OID
tree
parent
author
committer
timestamp
signature status
exact path/blob/mode verification
```

After commit require clean index/worktree.

PUSH

Execute exactly once:

```text
git push -u origin HEAD:refs/heads/codex/rw0-b2-cancellation-control-v1
```

No force push.

Require:

```text
remote feature ref == new commit
remote trunk_dev remains dd12b23762dc761736e55a1abfde12dd3ec23551
upstream == origin/codex/rw0-b2-cancellation-control-v1
local/remote feature divergence 0/0
```

If push fails, do not retry. Preserve the local commit and report exact state.

PULL REQUEST

Only after successful push, create exactly one non-draft PR if no matching PR
already exists.

Required base:

```text
trunk_dev
```

Required head:

```text
codex/rw0-b2-cancellation-control-v1
```

Required title:

```text
feat: add RW0-B2 cancellation-control evidence
```

Required body:

```markdown
## Summary

- add a private Wire-owned cancellation-control evidence profile for exact
  current author, validation, and review targets
- reuse the existing cancellation-request and process-observation values while
  preserving the complete `rw0-wire-nwpf-v1` contract
- add exact-current request, process, and acknowledgement/rejection relations
  plus a pure `invalid` / `incomplete` / `finite` control-evidence classifier
- preserve Capability, B1, C2A, persistence, transport, process-control, and
  runtime authority boundaries
- keep RW0-C blocked until this profile is independently merged and the C1
  contract is re-frozen

## Validation

- 5,087 unique tests collected
- 5,087 tests passed
- profile digest:
  `4d6f84552b852a4c4073b4238591afd271072f648424eca9e744def436165288`
- existing NWPF v1 identity and golden vectors unchanged
```

Do not enable auto-merge.

Do not submit a review or self-approval.

Do not resolve threads.

Do not delete the feature branch.

If a matching PR already exists, verify exact base/head/title/state and do not
create a duplicate.

FINAL GUARDS

Require:

```text
PR open
non-draft
unmerged
base == trunk_dev
head == codex/rw0-b2-cancellation-control-v1
one feature-branch commit
11 changed files
local worktree/index clean
remote trunk_dev unchanged
local and remote feature refs retained
no operation/lock/residue
no tag/release/deployment
no merge/auto-merge/review effect
implementation and audit evidence unchanged
collection exactly once
complete suite exactly once
```

CLOSEOUT

Remove only gate-created transient pytest paths after retaining material
records.

Seal the evidence root:

```text
directories mode 0700
files mode 0400
no symlink/special entry
self-excluding index
external read-only index verification
```

Print the complete report inline.

SUCCESS TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_CANCELLATION_CONTROL_COMMITTED_PUSHED_AND_PR_OPENED
```

only if commit, push, and PR creation/verification all succeed.

FAILURE TOKENS

Use one exact primary token:

```text
COMMIT_GATE_OPENING_IDENTITY_MISMATCH
COMMIT_GATE_REMOTE_BASE_DRIFT
COMMIT_GATE_REMOTE_CONFLICT
COMMIT_GATE_PROVENANCE_MISMATCH
COMMIT_GATE_STAGING_FAILED
COMMIT_GATE_COLLECTION_FAILED
COMMIT_GATE_FULL_SUITE_FAILED
COMMIT_GATE_COMMIT_FAILED
COMMIT_GATE_PUSH_FAILED
COMMIT_GATE_PR_FAILED
COMMIT_GATE_CLOSEOUT_FAILED
```

For failure, print the complete diagnosis inline and state whether the source
repository was restored to opening topology or retains a local commit.

FINAL INLINE REPORT

Use:

```text
# Outcome
# Accepted provenance
# Opening identity
# Remote and policy preflight
# Staging
# Collection and complete-suite validation
# Commit
# Push
# Pull request
# Final guards
# Evidence index
# Limitations and confidence
```

Required final statements:

```text
IMPLEMENTATION_REPAIR_NOT_PERFORMED
INDEPENDENT_AUDIT_NOT_REPEATED
DIRECT_TRUNK_PUSH_NOT_PERFORMED
BYPASS_NOT_USED
FORCE_PUSH_NOT_PERFORMED
AMEND_NOT_PERFORMED
SECOND_COMMIT_NOT_PERFORMED
SECOND_PUSH_NOT_PERFORMED
SECOND_PR_NOT_CREATED
PR_MERGE_NOT_PERFORMED
AUTO_MERGE_NOT_ENABLED
REVIEW_NOT_SELF_APPROVED
FEATURE_BRANCH_NOT_DELETED
TAG_NOT_CREATED
RELEASE_NOT_CREATED
DEPLOYMENT_NOT_PERFORMED
PERSISTENCE_NOT_IMPLEMENTED
TRANSPORT_NOT_IMPLEMENTED
PROCESS_CONTROL_NOT_IMPLEMENTED
RW0_C_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
COLLECTION_RUN_EXACTLY_ONCE
FULL_SUITE_RUN_EXACTLY_ONCE
```
