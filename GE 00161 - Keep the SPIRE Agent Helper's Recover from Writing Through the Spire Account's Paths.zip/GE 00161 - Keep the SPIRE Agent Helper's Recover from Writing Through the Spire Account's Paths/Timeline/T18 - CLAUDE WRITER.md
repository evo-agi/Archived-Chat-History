Handed the machine session instructions

Run a check and one change on the Remote Alpha box (ssh alias [test box name withheld]), and report the complete output. Execution-Substrate PRs 34 and 46 added a helper that pins the box's SPIRE agent to the real SPIRE server's CA bundle. You copy that helper from the merged trunk_dev to the box and run it there. The Wi-Fi between the Mac and the box may drop; the rules below say what to do.

Rules on the Mac:
- Create exactly one new folder: T=$(mktemp -d /Users/ds/Repositories/Playground/es-spire-pin.XXXXXX) and print it.
- Keep /Users/ds/Repositories/Playground as your working directory for the whole run. Never cd into "$T" or below it. Use git -C "$T/es".
- Do not change, stage, commit or delete anything in any existing folder, and run no command inside the existing Execution Substrate clone.
- Do not run sudo on the Mac. No git push. No installs and no downloads other than the git clone.
- Shell variables may not survive from one of your commands to the next. After you print T (and later D), use their literal values wherever the steps say "$T" or "$D".

Rules on the box:
- Reach it only with: ssh -T -o BatchMode=yes -o ConnectTimeout=15 -o ServerAliveInterval=15 -o ServerAliveCountMax=4 [test box name withheld] '<command>'. Below this is written BOX '<command>'. BOX is shorthand, so type the full ssh command each time. Do not open an interactive shell.
- Use sudo on the box only in the exact commands below. Do not start, stop, restart or reconfigure any service yourself, except in the fallback of step B7. Do not install anything or reboot. Do not touch Vault, Nomad or Docker.
- Never print /etc/spire/agent/agent.conf in full, /var/lib/spire/agent/agent-data.json or any join token. The helper redacts these itself. Report its output as it is.
- Never kill -9 the helper, and never run B7 a second time once its output file exists. The helper runs on the box by itself and finishes within its own time limits. The only abort is the one in step B7.
- Do not use --evict-old-agent and do not run recover.
- If an ssh command fails with exit status 255, "No route to host", "Broken pipe" or a timeout, run: route -n get [home network address withheld]; ping -c 2 [home network address withheld]; nc -vz -w 5 [home network address withheld] 22. Then wait five minutes and try once more: the same command, except that after B7 has been sent you use B7r instead of B7. If it still fails, stop. If the box folder exists and the link allows it, do step B10, but only if B7 was not sent or B7r has printed an "exit" line. Do part C, and report the last step that finished and the diagnostics. Do not force anything.

Part A, on the Mac:
A1. git clone https://github.com/evo-agi/Execution-Substrate.git "$T/es"   (the public repository; the checkout in A2 and the sums in A3 prove what was fetched)
A2. git -C "$T/es" checkout --detach 5d6ad513add57a3bd69e8956c32090e343d4f82d
    Print git -C "$T/es" rev-parse HEAD and git -C "$T/es" log -1 --format=%s (expected 5d6ad513add57a3bd69e8956c32090e343d4f82d and "Keep the SPIRE agent helper's recover from writing through the spire account's paths (#46)"). If the checkout fails or either differs, stop, do part C and report.
A3. shasum -a 256 "$T/es/scripts/remote_alpha_spire_agent.sh" "$T/es/scripts/internal/remote_alpha_spire_agent.py"
    Expected 3da361743428cdab50cd2352aa38074e1b0424ace2afbd7ddfb2d56bd669531c and 8ddd5d91f1c4e8090a43327514a9ff5fbefcaf41da4834f6271306211e0b81fa. If either differs, stop, do part C and report.

Part B, on the box:
B1. Baseline, read only:
      BOX 'hostname; uname -r; /usr/bin/python3 --version; command -v setsid; id -un; sudo -n true && echo "sudo -n: ok"; systemctl is-active spire-server spire-agent es; systemctl show -p ActiveEnterTimestamp spire-agent.service es.service; date -u'
    "command -v setsid" must print a path. If it prints nothing, stop part B before B4 and report.
B2. The agent unit's flags, read only (red-team O-RT1 and O-RT2):
      BOX 'for f in -trustBundle -expandEnv -joinToken; do printf "%s lines in the spire-agent unit: %s\n" "$f" "$(systemctl cat spire-agent.service | grep -c -- "$f")"; done; systemctl cat spire-agent.service | grep -E "^ExecStart=" | sed -E "s/(-joinToken(File)?)([ =]+)[^ ]+/\1\3<redacted>/g"'
B3. The bootstrap lines of agent.conf and the files around it, and who owns the SPIRE directories (audit 17, O17-1: puts the box's layout on record), read only:
      BOX 'sudo -n grep -n -E "^[[:space:]]*(insecure_bootstrap|trust_bundle_path|trust_bundle_url|trust_bundle_format)[[:space:]]*=" /etc/spire/agent/agent.conf; sudo -n sha256sum /etc/spire/agent/agent.conf; sudo -n ls -ln /etc/spire/agent/; ls -ln /etc/tmpfiles.d/ | grep -i spire || echo "no spire file in /etc/tmpfiles.d"; sudo -n stat -c "%U:%G %a %n" /var/lib/spire /var/lib/spire/agent /etc/spire /etc/spire/agent'
B4. Stage the helper. Create the box folder and print it:
      D=$(ssh -T -o BatchMode=yes -o ConnectTimeout=15 -o ServerAliveInterval=15 -o ServerAliveCountMax=4 [test box name withheld] 'mktemp -d /tmp/spire-pin.XXXXXX'); printf '%s\n' "$D"
    It must match ^/tmp/spire-pin\.[A-Za-z0-9]{6}$. If not, stop part B and report.
      BOX "mkdir '$D/internal'"
      ssh -T -o BatchMode=yes -o ConnectTimeout=15 -o ServerAliveInterval=15 -o ServerAliveCountMax=4 [test box name withheld] "cat > '$D/remote_alpha_spire_agent.sh'" < "$T/es/scripts/remote_alpha_spire_agent.sh"
      ssh -T -o BatchMode=yes -o ConnectTimeout=15 -o ServerAliveInterval=15 -o ServerAliveCountMax=4 [test box name withheld] "cat > '$D/internal/remote_alpha_spire_agent.py'" < "$T/es/scripts/internal/remote_alpha_spire_agent.py"
      BOX "chmod 0755 '$D/remote_alpha_spire_agent.sh' && sudo -n chown -R root:root '$D' && sudo -n sha256sum '$D/remote_alpha_spire_agent.sh' '$D/internal/remote_alpha_spire_agent.py'"
    Expected the two sums from A3. If either differs (a copy cut short by a drop shows up here), go to B10.
B5. Status before, read only:
      BOX "sudo -n '$D/remote_alpha_spire_agent.sh' status"; echo "exit $?"
    Expected: exit 1, result "attention". The three units are active, "agent identity" is ok with hours left, "bootstrap" is attention (insecure_bootstrap = true), and "bundle file" is info. "reboot readiness" may be attention. If "agent identity" is a failure or the server is not active, stop here, go to B10 and report (stop condition).
B6. Pin plan, changes nothing:
      BOX "sudo -n '$D/remote_alpha_spire_agent.sh' pin"; echo "exit $?"
    Expected: exit 0, result "planned", "no changes made; rerun with --apply". The plan writes the bundle file, edits agent.conf, restarts the agent and perhaps writes /etc/tmpfiles.d/spire.conf. If it refuses (exit 1), go to B10 and report.
B7. Pin, the one change of this run (about 1 to 2 minutes; ES restarts once). Note the time (date -u on the Mac), then run this once, with a command timeout of 10 minutes:
      BOX "sudo -n setsid -w sh -c 'd=\$1; \"\$d/remote_alpha_spire_agent.sh\" pin --apply > \"\$d/pin-apply.out\" 2>&1 < /dev/null; echo \"exit \$?\" >> \"\$d/pin-apply.out\"' sh '$D'; sudo -n cat '$D/pin-apply.out'"
    The helper runs in its own session and writes its report to pin-apply.out on the box; the last line of that file is "exit <status>". Expected: "exit 0" and result "ok". The checks report the same agent ID as before, a live server record, a workload SVID and es.service active.
    If the ssh command ends without printing an "exit" line (a timeout, exit status 255, a dropped link), do not run B7 again. Use B7r, after the link checks in the rules if needed.
    B7r, read only, repeat until it prints an "exit" line:
      BOX "if ! sudo -n test -e '$D/pin-apply.out'; then echo 'no pin-apply.out: B7 did not start'; pgrep -a -f '$D/internal/[r]emote_alpha_spire_agent[.]py' || echo 'no helper running'; else for i in \$(seq 1 50); do sudo -n grep -q '^exit ' '$D/pin-apply.out' && break; sleep 10; done; sudo -n cat '$D/pin-apply.out'; fi"
    Only if B7r prints both "B7 did not start" and "no helper running" did B7 never reach the box. Then, and only then, run B7 once more.
    B7 abort, only if pin-apply.out still has no "exit" line 25 minutes after the time you noted: list the helper with BOX "pgrep -a -f '$D/internal/[r]emote_alpha_spire_agent[.]py'". If it prints one line, send that process one SIGTERM with BOX 'sudo -n kill -TERM <the number at the start of that line>', exactly once. The helper then rolls back. Run B7r until it prints an "exit" line, then B8, and report. Never send a second signal and never use kill -9.
    If the "exit" line is not "exit 0", the helper has already restored the original agent.conf: go to B8. Only if its message says "rollback failed", run this fallback, then go to B8:
      BOX 'b=$(sudo -n sh -c "ls -1t /etc/spire/agent/agent.conf.bak-* | head -1"); printf "restoring from %s\n" "$b"; sudo -n cp --preserve=mode,ownership "$b" /etc/spire/agent/agent.conf && sudo -n systemctl restart spire-agent.service && sudo -n systemctl start es.service; systemctl is-active spire-agent es'
B8. Status after, read only:
      BOX "sudo -n '$D/remote_alpha_spire_agent.sh' status"; echo "exit $?"
    Expected after a successful B7: exit 0, result "ok". "bootstrap" is pinned and confirmed by SPIRE, "bundle file" matches the server bundle, "reboot readiness" is ok, and the agent fingerprint is the same as in B5.
    If B7 did not end with "exit 0", skip B9 and go to B10.
B9. Second pin, and the state after (red-team O-RT2):
      BOX 'systemctl show -p ActiveEnterTimestamp spire-agent.service es.service'
      BOX "sudo -n '$D/remote_alpha_spire_agent.sh' pin --apply"; echo "exit $?"
      BOX 'systemctl show -p ActiveEnterTimestamp spire-agent.service es.service; systemctl is-active spire-server spire-agent es; sudo -n grep -n -E "^[[:space:]]*(insecure_bootstrap|trust_bundle_path|trust_bundle_url|trust_bundle_format)[[:space:]]*=" /etc/spire/agent/agent.conf; sudo -n sha256sum /etc/spire/agent/agent.conf /etc/spire/agent/bootstrap-bundle.pem; sudo -n ls -ln /etc/spire/agent/; if [ -e /etc/tmpfiles.d/spire.conf ]; then ls -ln /etc/tmpfiles.d/spire.conf; cat /etc/tmpfiles.d/spire.conf; else echo "no /etc/tmpfiles.d/spire.conf"; fi'
    Expected: the second pin gives exit 0 and "nothing to change". Both ActiveEnterTimestamp values are unchanged by it. The only bootstrap line is: trust_bundle_path = "/etc/spire/agent/bootstrap-bundle.pem" (no "$" in it). If the second pin's connection drops, run that one command once more: on a pinned box it changes nothing.
B10. Remove the box folder (pin-apply.out goes with it, so B7's output must be in your report first):
      BOX "case '$D' in /tmp/spire-pin.??????) sudo -n rm -rf -- '$D' && echo removed;; *) echo refusing;; esac; ls -d /tmp/spire-pin.* 2>/dev/null || echo 'no spire-pin folder left'"

Part C, on the Mac:
C1. Remove "$T": rm -rf "$T" (only that folder). Then: ls -d "$T" 2>/dev/null || echo "removed"; ls -d /Users/ds/Repositories/Playground

Report, for every step: the command, its complete output and its exit status. At the end list which expectations did not hold, and, if you stopped early, the last step that finished.

When you have finished (or stopped), post the complete report in this thread. Do not summarize the helper output; quote it as printed.
