PR #46 is merged into trunk_dev as `5d6ad51` (CI green, merged files match the audited head byte for byte; [merge report](/mnt/project-files/reports/Execution-Substrate/spire-bundle/19-merge-report.md)). The SPIRE box run has started on your Mac under your approval: status, pin plan, pin, status, then a second pin that should change nothing. ES restarts once, for a few seconds, during the pin. I'll report when the box is back in a working state.

STATUS: #46 merged; SPIRE box run in progress.
