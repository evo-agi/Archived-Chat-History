The fix for the Codex finding is up for audit as [PR #46](https://github.com/evo-agi/Execution-Substrate/pull/46), head `62d865a`. It touches only `recover`; `status` and `pin` are unchanged.

- The token folder now stays root's own, so spire can read its token file but can't add or replace anything there.
- The helper creates the log as a new file and reads it back from the file it opened, never by name.
- The new data folder gets its owner and mode through the folder it actually created, so a symlink swapped in is refused.

All helper tests pass, all 11 deliberately broken versions of the fix are caught by the tests, and the unprivileged package run shows no new failures. I didn't make `recover` refuse when spire can write `/var/lib/spire`, as report 15 suggested, because that could block recovery on the box itself. I also marked the PR ready early, so Codex reviews it before the audit rather than after a merge. Report: [16-repair.md](/mnt/project-files/reports/Execution-Substrate/spire-bundle/16-repair.md).

STATUS: #46 waiting for audit, CI and Codex. `recover` shouldn't run until #46 merges and reaches the box.
