Yes, I can pause any of them. Five threads are working right now:

- [Red-team merged ES trunk as a whole](#cmsg_01Un4xQgjBAczV8DABQvcLrxJdWSRKMfFFZV6p2J9Nzyj7) (Fable): just started.
- [Audit SPIRE agent recovery helper](#cmsg_01Un4xQgjBAczV8DABQvcLrxR5usAdofkjf27YsvZjFXtq): the last re-check of the root-overwrite fix (#46). It's short.
- [Lock Nomad so only ES can submit](#cmsg_01Un4xQgjBAczV8DABQvcLrx7qaBgesL513RdQXm7D49pW): splitting out the small fix for the two Nomad setup bugs.
- [Finish PR 13 post-red-team repair](#cmsg_01Un4xQgjBAczV8DABQvcLrxGjHtm1L9q2m2a7VFUutNNt): reliable submit taking the Nomad token change. This is the top priority.
- [Finish maintenance agent fifth repair](#cmsg_01Un4xQgjBAczV8DABQvcLrxXXZRTbEtdbvV8c4236YR2V): small test fixes, then a long real-install run.

I'd pause the maintenance agent. It isn't ES, its install run is long, and it can resume after Thursday. The other four are short or top priority. Should I pause it?

STATUS: NEEDS DAVID (pause the maintenance agent?)
