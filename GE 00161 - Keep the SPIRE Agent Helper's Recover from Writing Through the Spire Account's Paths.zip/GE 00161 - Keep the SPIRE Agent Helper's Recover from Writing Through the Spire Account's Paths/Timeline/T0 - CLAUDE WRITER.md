Codex found a real security bug in PR #34's `recover` command, posted three minutes after the merge. During a recovery, a process running as the spire account can make the helper, running as root, overwrite any file it chooses. The cause is that the helper writes its log through a path in a folder that spire owns. I found a second, conditional case of the same kind in how it sets up the new data folder. `status` and `pin` aren't affected, so the bundled box run is fine, but `recover` shouldn't be used until this is fixed. Details: [15-codex-finding.md](/mnt/project-files/reports/Execution-Substrate/spire-bundle/15-codex-finding.md).

I'm starting a scripts-only fix PR now unless you'd rather hold it.

STATUS: follow-up fix starting. The box run is unaffected.
