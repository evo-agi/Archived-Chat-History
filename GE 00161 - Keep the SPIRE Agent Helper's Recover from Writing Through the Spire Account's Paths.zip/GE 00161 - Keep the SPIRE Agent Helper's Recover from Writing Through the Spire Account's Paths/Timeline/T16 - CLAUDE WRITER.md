The SPIRE box run is lined up to start as soon as PR #46 merges. The auditor accepted #46's current head, and its last CI run should finish around 11:45 PM Eastern. After that I merge it and start the run on your Mac straight away.

I changed the plan so a Wi-Fi drop can't leave the box half-changed. The one step that changes anything (`pin --apply`) now runs on the box by itself and saves its report there, so a lost connection doesn't stop it. It either pins or puts the old config back within its own time limits. The Mac session reads the result once the link is back and never starts that step twice. If the link stays down, it stops cleanly and reports where it got to. Plan: [box-run-plan.md](/mnt/project-files/reports/Execution-Substrate/spire-bundle/box-run-plan.md)

STATUS: #46 waiting on CI, then merge and box run (SPIRE goes first in the box queue).
