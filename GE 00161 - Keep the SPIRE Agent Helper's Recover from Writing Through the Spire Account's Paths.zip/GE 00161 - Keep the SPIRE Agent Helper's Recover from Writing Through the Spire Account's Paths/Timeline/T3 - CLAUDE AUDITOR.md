**PR #46 audit 17: REPAIR NEEDED, tests only.**

The fix for Codex's finding is correct. With real SPIRE and a separate account, I confirmed `spire` can no longer plant files in the token directory, and the agent still attests. No other root path in the helper has the same pattern. I agree with not refusing when `spire` can write `/var/lib/spire`.

One Low gap: tests can't see ownership changes, so deleting the owner-setting line would pass every test and break `recover` on the box. A tested test-only diff is attached in the evidence.

STATUS: 17 BLOCK (1 Low) published. Read-only.
