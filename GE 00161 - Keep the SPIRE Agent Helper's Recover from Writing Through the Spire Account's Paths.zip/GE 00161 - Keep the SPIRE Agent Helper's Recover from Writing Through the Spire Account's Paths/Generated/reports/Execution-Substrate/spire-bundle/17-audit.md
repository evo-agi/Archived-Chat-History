# Independent audit of the fix for recover's root file overwrite (INF-14 follow-up, PR #46)

**Verdict: REPAIR NEEDED (protocol verdict `BLOCK`), tests only.**
- **The fix is correct and complete for both findings.** The token directory stays root's, the log is created as a new file and read back through its descriptor, and the new data directory is handed over through a descriptor.
- **No other root path in #34's merged helper has the pattern.**
- **I agree with not refusing when `spire` can write `/var/lib/spire`.**
- **One Low test gap:** no test can see an ownership change, because the test user plays every account. A tested 39-line test diff is attached; it kills the two mutants that show the gap.

```text
INDEPENDENT AUDIT REPORT
Repository:        evo-agi/Execution-Substrate
Audit target:      base trunk_dev 5b82a6eea55e66faddadf7ebcf59393bfa129ba2 (#34 merged)
                   topic claude/project-thread-wg7jh5 at 62d865abb80a20edd1e14ab53e36b958774006b7 (PR #46, one commit)
                   tree 58c2a3f687897d74fa9bfab6fad464656800d733
                   recipe governed-execution.audit-patch-manifest.v2, source sha256
                   c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (verified)
                   manifest_sha256 cd4379dbfa4013e305be418adf8308e001bcd2cae3727f75072424c890ca79de, 3 paths
Inputs:            15-codex-finding.md sha256 cacc74d1…8cac; 16-repair.md sha256 1b92c6ba…5e2b
Audit posture:     read-only on the repo; no subagents; nothing pushed; no PR comment; nothing run on the
                   Linux box. Tests, mutants and probes ran on copies outside the audit clone, as root in
                   this container, with a separate local account standing in for spire in the probes.
Provenance:        REPRODUCED. Two v2 runs into a fresh 0700 directory, byte-identical, and byte-equal to
                   16-evidence/manifest-v2-62d865a.json. Closing run equal to the opening one (section 9).
Final verdict:     BLOCK (repair needed: 1 low finding, tests only; test diff tested)
```

## 0. In plain words

Codex was right. I reproduced the old behaviour with a separate local account standing in for `spire`: it could make root overwrite a root-owned file.

**The fix**
- The token directory now stays root's, and `spire` can only pass through it to read its token.
- The log is created only as a new file, and read back through the helper's own handle.
- The new data directory gets its owner through a handle, never by name.

I checked the token directory with real SPIRE 1.14.4 and a separate account. That account cannot put anything in the directory, but the real agent, running as it, still attests. With the directory one step tighter, the agent cannot read its token, so the new setting is exactly what is needed.

**The rest of the helper.** I went through every file operation in it. Nowhere else does root write through, or hand over, a path that `spire` controls. `status` writes nothing. `pin` writes only under `/etc`, and only with exclusive creates and renames, which stay safe even if `spire` could write there.

**Not refusing when `spire` can write `/var/lib/spire`.** I agree with the writer. In that directory root now only renames, creates and hands over by handle. None of those can be redirected, so a refusal would add no protection, and it could make `recover` useless on the box. What the box actually has is not on record, and a one-line read-only check in the box-run plan would settle it (O17-1).

**What needs fixing (Low, tests only).** All the tests run the helper and "spire" as the same user, so they cannot see an owner change. If the line that sets the new directories' owner were deleted, every test would still pass. Then on the box `recover` would fail at attestation and roll back. That fails safe, but `recover` is the one tool for an expired agent, and nobody can try it before it is needed. The attached test change gives a directory to a different owner (as root) or to a second group (as an ordinary user), and it pins the token directory's owner argument. It kills both mutants and passes in all three ways I ran it.

## 1. Provenance reproduction

```bash
cd /opt/audit/es3   # the audit clone from earlier rounds
git fetch -q origin "+refs/heads/trunk_dev:refs/remotes/origin/trunk_dev" \
  "+refs/heads/claude/project-thread-wg7jh5:refs/remotes/origin/claude/project-thread-wg7jh5"
git rev-parse origin/claude/project-thread-wg7jh5            # 62d865ab… (= refs/pull/46/head)
git log --format='%h %p' 5b82a6e..62d865a                     # one commit, parent 5b82a6e
git checkout -q -f -B claude/project-thread-wg7jh5 62d865ab…; test -z "$(git status --porcelain)"
git rev-parse HEAD^{tree}                                      # 58c2a3f6…
git reset -q --mixed 5b82a6ee…; git branch -q --set-upstream-to=origin/trunk_dev
python3 -I "$V2" /opt/audit/manifest17/1.json; python3 -I "$V2" /opt/audit/manifest17/2.json   # 0700 dir, umask 022
cmp 1.json 2.json; cmp 1.json …/16-evidence/manifest-v2-62d865a.json                         # identical
```

Result: `manifest_sha256 cd4379db…79de`, `textual_diff_sha256 e1a37fa9…a659`, 3 files (the docs, the `.py` `8ddd5d91…`, the test file `d8c6972d…`). The `.sh` and `PLANS.md` are unchanged from `5b82a6e`. Copies: `17-audit-evidence/manifest/open-{1,2}.json`.

## 2. The finding, confirmed

F15-1 is real. I reduced the old code to its two steps and ran them with a separate local account standing in for `spire` (`probes/probe-pre-fix.out`):
- root makes the token directory the account's own (`chown`, `0700`), as `attest_once` did on `5b82a6e`;
- the account puts `attest.log` there as a symlink to a root-owned `0600` file;
- root opens `attest.log` by name with `"wb"`, as the old code did.

The root-owned file was truncated and overwritten. F15-2 holds by reading: `os.chown` and `os.chmod` by path follow a symlink that a writer of `/var/lib/spire` could put in place between `mkdir` and `chown`.

## 3. The fix

| Change (`scripts/internal/remote_alpha_spire_agent.py` at `62d865a`) | Judgment |
|---|---|
| `take_new_dir` (line 372): opens the name with `O_DIRECTORY \| O_NOFOLLOW`, requires the directory to be owned by the helper, have no group or other bits and be empty, then `fchown`/`fchmod` | Correct. A symlink fails the open. A directory someone else put in place fails the owner check, since only root can make a root-owned directory and a directory cannot be hard-linked. The mode check also catches a directory that was widened. |
| token directory (line 1370): stays root's, `0710` group `spire` | Correct, and it removes F15-1's precondition. My probe with real SPIRE 1.14.4 and a separate account: the account **cannot** create or remove entries there ("Permission denied" for both), and the real agent, run as that account through `setpriv --init-groups`, **attests** from its `0600` token file. With the same directory at `0700`, the agent fails with "unable to read join token file … permission denied", so group search is what makes it work (`probes/probe-token-dir.out`). |
| log (line 1387): `O_RDWR \| O_CREAT \| O_EXCL \| O_NOFOLLOW \| O_CLOEXEC`, passed to the agent by descriptor; tail read with `os.pread` from that descriptor (line 1419) | Correct, and independent of the directory: even in a directory `spire` could write, a planted name makes the open fail, and a swapped name cannot change what the tail reads. `pread` leaves the offset the agent shares untouched. The read window (first 1 MiB, redact before cut) is the same as before. |
| new data directory (lines 1331–1332): `mkdir 0700`, then `take_new_dir` | Correct. A symlink or another directory in its place raises, and the existing handler rolls the swap back (sections 4 and 6). |

The docs change matches the code: root-owned `0710` token directory with group `spire`, log created as a new file and read back through its own descriptor, data directory set through a descriptor.

## 4. Not refusing when `spire` can write `/var/lib/spire`

**I agree with the writer's choice.** Here is what root still does in that parent during `recover` (lines 1326–1332 and `rollback_data_dir`): `lstat`, `rename` (two to four times), `mkdir` and the descriptor handover. None of them follows a symlink in the last part of a path:
- `rename` moves the name itself;
- `mkdir` fails on any existing name;
- `take_new_dir` refuses anything but the empty, root-owned directory it just made.

A writer of `/var/lib/spire` can therefore only move names it could already move, or make `recover` fail and roll back. A refusal would add no protection on top of that. It would also make `recover` unusable on a box where `/var/lib/spire` belongs to `spire`, which is common on hand-made SPIRE installs. Whether that applies here is unknown: the box's SPIRE layout has no repo source (infra audit, "[F] … have no repo source"), and the box-run plan does not record it. See O17-1.

What makes this safe is a property of the code: every root operation in that parent stays name-only or goes through a descriptor. The new static check (`os.chown`, `os.chmod` or `os.lchown` anywhere in the helper fails a test) protects the most likely way to break that property again. A new by-name `open` for writing in that parent would not be caught, so a future edit there needs the same review.

## 5. The same pattern elsewhere in #34's merged code

I listed every filesystem call in the helper (`grep` over `os.*`, `open(`, `shutil.*`, `tempfile.*`) and every command it runs. The wrapper `scripts/remote_alpha_spire_agent.sh` only `exec`s Python with `-I -B`. Root writes through, or hands over, a path that `spire` controls **only in the two places #46 fixes**. Everything else:

| Where (owner on a usual install) | Root's operations | Verdict |
|---|---|---|
| `/run` (root): lock file, token directory, tmpfiles sandbox | lock `O_CREAT \| O_NOFOLLOW` plus an `fstat` owner and type check; `mkdtemp` directories stay root's (the sandbox `0700`); `shutil.rmtree`, which works through descriptors | safe |
| tmpfiles sandbox contents | `systemd-tmpfiles --root=<sandbox>` creates the rule's `spire`-owned directories inside the root `0700` sandbox, which `spire` cannot enter | safe |
| `/etc/spire/agent` (root): bundle, `agent.conf`, backup | `mkstemp` (`O_EXCL \| O_NOFOLLOW`) plus `fchown`/`fchmod`, then `rename`; `create_exclusive` (`O_EXCL \| O_NOFOLLOW`); reads with `read_regular_file` (`O_NOFOLLOW`, regular file only, size cap) | safe even if `spire` could write the directory: renames move only names |
| `/etc/tmpfiles.d` (root) | `create_exclusive`, `unlink` | safe |
| `/var/lib/spire/agent` (`spire`) | reads `agent-data.json` with `read_regular_file` (`status`, `recover`'s poll, the check after start) | read-only; only parsed fields (agent ID fingerprint, expiry) reach the output. A swapped parent can point the read elsewhere only if `spire` can write `/var/lib/spire`, and still only a file named `agent-data.json` is read |
| `/run/spire/...` (`spire`) | `lstat` checks; `healthcheck` runs as `spire`; `api fetch x509` runs as root and connects to the agent socket | no file write. A hostile `spire` already controls the agent's answers |
| `spire-server` calls | always as `spire` (`setpriv`) over the admin socket; root parses the JSON output | no path handed to root |

Related to this, though not the same pattern (O17-2): root runs `openssl x509` on the SVID bytes from `agent-data.json`, which `spire` writes. So a hostile `spire` controls the input to a root process's X.509 parser.

## 6. Findings

**A17-1 (Low, tests only): no test can see an owner change.**

*Why the tests are blind.* Every test runs the helper and the account playing `spire` as one user. Every owner and group that `take_new_dir` sets is therefore the one the directory already has. Two mutants show it:
- **A14** deletes `os.fchown` from `take_new_dir`. It survives both its own test and the recover test.
- **A5** makes the token directory `spire`'s again. It survives too.

*What A14 would do on the box.* The new data directory would stay `root` `0750`, and the token directory would keep group `root`. My probe's `0700` control shows the result: the agent cannot read its token ("permission denied"). So `recover` would fail and roll back on the box, while every test passes. That fails safe, so it is not a security regression. But `recover` is the box's only tool for an expired agent, and it cannot be tried before it is needed.

*Why A5 matters less.* It is defence in depth. Even with a `spire`-owned token directory, the tested `O_EXCL | O_NOFOLLOW` open and the `pread` tail still stop F15-1 (A1 and A4 are killed).

*Fix (attached as `17-audit-evidence/proposed-fix/proposed-test-fix.diff`).* 39 added lines in `TestRemoteAlphaSPIREAgentTakeNewDirRefusesSwaps`:
1. Hand a fresh directory to a different owner, then check its owner, group and mode. As root the owner is `65534:65534`. Otherwise it is the test user with one of its other groups, which any user may set. If neither is possible, the test logs that and skips the step.
2. Next to the existing static check, require `take_new_dir(scratch, os.geteuid(), spire_gid, 0o710)` in `attest_once`.

*Results of the fix.* Applied to `git archive 62d865a`, the diff rebuilds the tested test file `2208074e…cecbe`.
- It passes as root, as `ci` with two groups, and as `ci` with one group (logging the skip).
- It kills A14 as root ("is 0:0 750, want 65534:65534 750") and as `ci` ("is 1500:1600 750, want 1500:995 750").
- It kills A5 with the static check.

Inference, not checked on the runner: GitHub's runner account normally has supplementary groups, so CI would run the owner check too.

No other finding. Status of the two input findings:
- **F15-1:** fixed; the probe and mutants A1, A4, A6 and A7 cover it.
- **F15-2:** fixed; the unit test and A8 to A12 cover it.

## 7. Tests and CI

| Command | Bytes | Result |
|---|---|---|
| `go test -count=1 -v -run '^TestRemoteAlphaSPIREAgent' ./scripts` as root, `env -i`, Go 1.26.5, pinned SPIRE tarball | 62d865a (tree `58c2a3f6…`) | 9/9 PASS, 69.2 s (`tests/helper-tests-root-62d865a.log`) |
| writer's unprivileged run (uid 1500), root, `scripts` and `internal/testutil` packages, head vs base | writer's JSON | 0 failing only on head, 0 skips, 1 new test passing (`16-evidence/pkgs-compare-ci.txt`); I did not repeat it, since the new test's root-only case is the one that matters here |
| real-SPIRE probes with a separate local account | helper's own `take_new_dir` and open flags | section 3 (`probes/`) |
| GitHub Actions "build, vet and test" | 62d865a | in progress at 03:31Z (run 45316912396; Test step running). Not needed for this verdict; the repaired head needs its own green run |

## 8. Mutants

Each mutant ran on a fresh copy of the exact `62d865a` bytes, as root, against the test that should catch it (`mutants/`). I wrote these mutants myself; the writer's own definitions are not in 16-evidence, only its summary.

| Mutant | Change | Result |
|---|---|---|
| A1 | log opened with `O_TRUNC`, no `O_EXCL`, no `O_NOFOLLOW` | killed (planted-log step) |
| A2 | log without `O_EXCL`, keeps `O_NOFOLLOW` | survives: equivalent for the planted symlink, which `O_NOFOLLOW` alone refuses |
| A3 | log without `O_NOFOLLOW`, keeps `O_EXCL` | survives: equivalent, since `O_CREAT \| O_EXCL` fails on any existing name, symlink or not |
| A4 | failure tail reopened by name | killed (swap-log step) |
| A5 | token directory owned by `spire` (mode 0710) | **survives**; killed by the proposed fix (static check) |
| A6 / A7 | token directory 0700 / 0770 | killed (directory mode check) |
| A8 / A9 / A10 | `take_new_dir` without `O_NOFOLLOW` / empty check / mode check | killed |
| A11 | `take_new_dir` without the owner check | killed as root |
| A12 | new data directory not handed over | killed ("new data directory mode 700, want the old 0750") |
| A13 | new data directory made with `mkdir(…, 0o750)` | survives: equivalent, since `main` sets `umask 0o077` (line 1500) |
| A14 | `take_new_dir` without `fchown` (its own test; the recover test) | **survives both**; killed by the proposed fix as root and as `ci` |
| A15 | no rollback after a failed handover or attestation | killed |

That is 10 killed and 6 surviving. Three survivors are equivalent (A2, A3, A13). The other three (A5 and A14 in two tests) are A17-1, and the attached test kills them. Taken together, A2 and A3 show the two open flags back each other up. With both, the open also refuses a planted hard link or regular file, though the root-owned directory already rules out planting.

## 9. Closing provenance

At 03:30Z, after all tests, mutants and probes, and after removing the scratch trees and the probe account:

```text
git ls-remote origin: claude/project-thread-wg7jh5 = 62d865ab…  (unchanged)
                      trunk_dev = 08429836…  (moved by #31, the Nomad lock)
audit clone:          HEAD 5b82a6ee…, upstream name origin/trunk_dev, branch claude/project-thread-wg7jh5
recipe sha256         c08597e2…a3ca (unchanged)
python3 -I v2 /opt/audit/manifest17-close/1.json   (fresh 0700 directory, umask 022)
manifest_sha256       cd4379dbfa4013e305be418adf8308e001bcd2cae3727f75072424c890ca79de
textual_diff_sha256   e1a37fa9f3dbfdd3440ee919cd2b977341be5ceb35cda33e73b0c63c993ea659, 3 files
cmp close-1.json open-1.json: byte-identical
```

Copy: `17-audit-evidence/manifest/close-1.json`.

**trunk_dev moved to `0842983` (#31).** A trial merge with `62d865a` is clean (tree `44de83a2…`), and no path is changed on both sides. Among #31's tests, only `docs_contract_test.go` touches anything shared, and that is a one-line change. The repair round has to bring `0842983` in anyway, and its re-check covers that merge.

## 10. Observations

- **O17-1 (box posture, read-only).** Add a read-only `stat -c '%U:%G %a %n' /var/lib/spire /var/lib/spire/agent /etc/spire /etc/spire/agent` to the box-run plan's preflight, so the box's actual layout is on record. Optionally, `status` could report who can write the data directory's parent as `info`. Neither is needed for the fix to be safe (section 4).
- **O17-2 (defense in depth, pre-existing).** `openssl x509 -inform DER` parses `spire`-written bytes as root (`openssl_cert_fields`, from `read_local_agent`). OpenSSL's X.509 parser is heavily fuzzed, so this is not a finding. But `openssl` only needs stdin and stdout, so it could run as `spire` (or `nobody`) through `setpriv`, like the `spire-server` calls.
- **O17-3 (threat model).** Red-team 07 scoped its attacker as "not already root or the `spire` account". F15-1 is exactly a `spire` to root escalation. `spire-server` runs as `spire` and listens on the network, so for this root helper a hostile `spire` account belongs in the threat model. The docs section could say so in one line, as a guide for later edits.

## 11. My earlier miss

Audits 02 and 04 and re-audit 06 all read `attest_once`. I checked its log open for token leakage and signal handling, and the token file's flags, but I never asked who owns the directory those names live in. The red-team, checks 09 and 12, and the writer missed it too. Codex found it. I have saved a method lesson to project memory: in root code, list every directory a less-privileged account can write, and check each path operation in it for following symlinks and for handing over ownership.

## 12. Effect status

Audit only. This thread made no repair commit, push, PR comment, merge or box action. In this container it created a local account (`spireprobe`) for the probes, and later removed it; for one test run it also added `ci` to that account's group, then took it out again. Evidence is under `17-audit-evidence/` (`SHA256SUMS.txt`). Scratch trees were removed before the closing manifest.
