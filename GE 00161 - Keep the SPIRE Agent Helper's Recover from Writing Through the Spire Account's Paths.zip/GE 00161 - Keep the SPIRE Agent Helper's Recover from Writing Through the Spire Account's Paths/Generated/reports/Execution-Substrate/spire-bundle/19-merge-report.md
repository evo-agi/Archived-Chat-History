# MERGE REPORT: PR #46 (SPIRE helper `recover` fix, INF-14 follow-up)

Writer, 2026-11-24 05:22Z. Scripts-only PR: audit plus merge gate, no product review.

| Gate item | Result |
|---|---|
| Accepting audit | 18-recheck.md ACCEPT for 6f15ec0 and 73dba43 (after audit 17 and repair 18) |
| Head = audited | 06731ca = 73dba43 + git's clean merge of trunk_dev c610e1d (#44); PR patch identical (sha256 adfbadae…d6c8); writer's own check 18b-sync-c610e1d.md under the coordinator's 02:00Z rule |
| Manifest v2 | e74886f79722f637855f159bcd52bd83b5b6222f15501cf62d4d5fb976c95c85 (base c610e1d), entries identical to 24299fec and 6f687ce4 |
| CI "build, vet and test" | run 45328902088 on 06731ca: success, 04:48Z to 05:21Z |
| Up to date with trunk_dev | yes (trunk_dev c610e1d is an ancestor of 06731ca) |
| Merge | squash with expectedHeadSha 06731ca40d4051a187602866d3bbd4f9e3647a5f |

**Merged as 5d6ad513add57a3bd69e8956c32090e343d4f82d** (parent c610e1d).

Post-merge byte check: tree of 5d6ad51 = tree of 06731ca (85c518e063a6cbcd3eb7ab276feb25ce64a31833). The three manifest paths and the unchanged wrapper have the same blobs as the head:

```
scripts/internal/remote_alpha_spire_agent.py        0782123b…  sha256 8ddd5d91f1c4e8090a43327514a9ff5fbefcaf41da4834f6271306211e0b81fa
scripts/remote_alpha_spire_agent_test.go            845d58d8…
.docs/system_overview/remote_supported_host_alpha.md 49444499…
scripts/remote_alpha_spire_agent.sh (not in the PR) ebdb454c…  sha256 3da361743428cdab50cd2352aa38074e1b0424ace2afbd7ddfb2d56bd669531c
```

Next: the box run (box-run-plan.md, A2 now checks out 5d6ad51), approved by David at 04:23Z, first in the coordinator's box queue. `recover` stays off the box unless a real expiry needs it.
