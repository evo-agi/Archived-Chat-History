# INF-14 follow-up: repair of F15-1 and F15-2 in the SPIRE agent helper's `recover` (report 16)

Writer, 2026-11-24 ~03:25Z. Draft PR #46 (https://github.com/evo-agi/Execution-Substrate/pull/46), scripts-only. Nothing run on the box.

| | |
|---|---|
| Base | trunk_dev 5b82a6eea55e66faddadf7ebcf59393bfa129ba2 (#34) |
| Head | 62d865abb80a20edd1e14ab53e36b958774006b7, tree 58c2a3f687897d74fa9bfab6fad464656800d733, one commit |
| Manifest v2 | cd4379dbfa4013e305be418adf8308e001bcd2cae3727f75072424c890ca79de, textual_diff e1a37fa9…a659, 3 files (two runs identical; tool sha c08597e2…a3ca checked before each) |
| Files | `scripts/internal/remote_alpha_spire_agent.py` (8ddd5d91…), `scripts/remote_alpha_spire_agent_test.go` (d8c6972d…), `.docs/system_overview/remote_supported_host_alpha.md` (95ccea97…). `scripts/remote_alpha_spire_agent.sh` and `PLANS.md` unchanged. |
| Finding | 15-codex-finding.md (F15-1 Codex P1, F15-2 writer) |

## 1. Changes (helper)

1. **Token directory (F15-1 root cause).** `attest_once` no longer hands the
   directory to spire. After `mkdtemp` (root, 0700, under `/run`) it calls
   `take_new_dir(scratch, euid, spire_gid, 0o710)`: root keeps ownership,
   group spire gets search only. spire (the attesting agent, via
   `setpriv --regid=spire --init-groups`) can still open its `0600` token
   file, which root creates with `O_EXCL | O_NOFOLLOW` and `fchown`s to spire
   as before, but cannot create, rename or delete entries.
2. **Attestation log (F15-1).** Created with
   `os.open(..., O_RDWR | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC, 0o600)`
   and passed as the agent's stdout by descriptor. The failure tail is read
   with `os.pread(log_fd, 1 MiB, 0)` from that descriptor (same window and
   redact-before-cut order as before), never by reopening the name. The
   descriptor is closed in the existing signal-deferred cleanup.
3. **New data directory (F15-2).** `os.mkdir(..., 0o700)` is followed by
   `take_new_dir(path, new_uid, new_gid, new_mode)` instead of `os.chown` and
   `os.chmod` by path. `take_new_dir` opens the name with
   `O_DIRECTORY | O_NOFOLLOW`, requires the directory to be owned by the
   helper's euid, to have no group or other bits and to be empty, and then
   uses `fchown`/`fchmod`. A symlink fails the open (`ELOOP`/`ENOTDIR`, an
   `OSError`), anything else is a `Failure`; both land in the existing
   `except (CommandError, Failure, OSError)` that rolls the swap back.
4. Planned-step wording: the token is "in a 0600 file of spire inside a
   directory under /run that only this helper can change".

`status` and `pin` code is untouched (the diff touches only `take_new_dir`,
`mode_recover`'s data-directory lines and planned text, and `attest_once`).

### Deviation from the fix proposed in report 15

Report 15 proposed refusing `recover` when `/var/lib/spire` is writable by
anyone but root. I did not do that: on a usual SPIRE install that directory
may well be spire's, and a recovery tool that refuses on the box it exists
for is worse than one that is safe there. `take_new_dir` makes the handover
safe whoever can write the parent, and the remaining operations in that
parent are `rename`s, which never follow symlinks and only move names spire
could move anyway.

## 2. Tests

- Shims gained two markers playing a hostile spire account (in tests the
  same user as the helper, so they exercise the second layer, the
  descriptor rules, directly):
  - `PLANT_LOG`: `token generate` plants `attest.log` as a symlink to a
    victim file in the token directory. New step in the recover test: recover
    fails ("attestation failed", names attest.log), the victim keeps its
    bytes and mode 0600, the old data directory is back (`.failed-*` count 3),
    no scratch entries left. Token generations as spire now 5 (attesting
    runs stay 4).
  - `SWAP_LOG`: the failing attesting agent replaces its own log, by name,
    with a symlink to a secret file before exiting. Added to the existing
    crash step: the report contains the agent's output ("agent crashed:
    injected by the test", redacted token as before) and not the secret.
- New `TestRemoteAlphaSPIREAgentTakeNewDirRefusesSwaps` (driver mode
  `--take-new-dir`): a fresh 0700 directory is handed over (mode 0750); a
  symlink to an empty 0700 directory is refused and the target keeps 0700; a
  directory with an entry and a 0755 directory are refused unchanged; as
  root, a directory owned by 65534 is refused unchanged. A static check
  fails if the helper calls `os.chown`, `os.chmod` or `os.lchown` at all.
- The token-directory assertion is now mode 0710 (was 0700).

## 3. Results

- Helper tests as root (`go test -run TestRemoteAlphaSPIREAgent ./scripts/`):
  all 9 pass (`16-evidence/helper-tests-root-62d865a.log`).
- Unprivileged (ci, uid 1500 gid 1600; root, scripts and internal/testutil
  packages, trees equal to the commits): head 2318 verdicts, base 2317; the
  same 244 host-only failures on both, none only on head, no skips; the one
  new test passes (`16-evidence/pkgs-compare-ci.txt`). The owner-refusal
  case of the new test is skipped there (needs root).
- Mutants, as root, each against the test that should catch it: 11 of 11
  killed (`16-evidence/mutants-summary.txt`): log open with `O_TRUNC` and no
  `O_EXCL | O_NOFOLLOW`; tail read by name; `take_new_dir` without
  `O_NOFOLLOW`, without the empty check, without the mode check, without the
  owner check (killed only as root); token directory spire-owned 0700 (the
  old code) and 0770; data directory set by path (static check) and not set
  at all (mode check); token directory not handed over.
- CI on 62d865a: pending at writing.

## 4. Box impact

- The bundled box run (status, pin, status) is unaffected: pin's code is
  the same. `box-run-plan.md` pins the helper at 5b82a6e and its sums; if
  #46 merges before the run, the plan should move to the new merge commit
  and the new helper sum (8ddd5d91… for the .py; the .sh is unchanged), so
  the box carries the fixed `recover` too. I will update it at merge.
- Until #46 is merged and on the box, `recover` should not be run.

## 5. Evidence

`16-evidence/`: manifest-v2-62d865a.json, manifest-v2-checks.txt,
fix-62d865a.diff, helper-tests-root-62d865a.log, mutants-summary.txt,
pkgs-compare-ci.txt, pkgs-{head,base}-ci.env, pkgs-{head,base}-ci.json.gz,
SHA256SUMS.txt.
