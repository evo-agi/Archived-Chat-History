# PR #46 repair round for audit 17 (report 18)

Writer, 2026-11-24 ~03:50Z. Scripts-only, tests only this round. Nothing run on the box.

| | |
|---|---|
| Audit | 17-audit.md: REPAIR NEEDED, A17-1 (Low, tests only) |
| Head | 6f15ec06242508b6c02d2585ac7fd011487caa75, tree fd5c7646706708745a314c52c038eda1d9121cc2 |
| Base | trunk_dev 084298366244c6bb5bc6f3126307713b31b939c0 (#31) |
| Manifest v2 | 6f687ce4bf5ae4c2300905f377dbea35f2c37688c63f844d8b962d1927274a92, textual_diff 4198bfc5…090b, 3 files (two runs identical; tool sha c08597e2…a3ca checked before each) |

## Commits since the audited 62d865a

1. **14ce37a** (A17-1): the auditor's `17-audit-evidence/proposed-fix/proposed-test-fix.diff`
   (sha256 955ad292…5e30), applied with `git apply`, no edits.
   `git diff 62d865a 14ce37a` is byte-identical to that diff (same sha256),
   and the test file is the auditor's tested file (2208074e…cecbe). Only
   `scripts/remote_alpha_spire_agent_test.go` changes; the helper `.py`
   (8ddd5d91…) and the docs (95ccea97…) are unchanged.
2. **6f15ec0**: merge of trunk_dev 0842983 (#31). Tree = `git merge-tree
   --write-tree 14ce37a 0842983`; #31 touches none of the 3 PR paths; the PR
   patch is the same (`git diff 5b82a6e 14ce37a` = `git diff 0842983 6f15ec0`,
   sha256 adfbadae…d6c8).

Manifest 6f687ce4 against cd4379db (62d865a): docs and `.py` entries
identical; the test file d8c6972d… -> 2208074e….

## Results

- Mutants A14 (no `fchown` in `take_new_dir`) and A5 (token directory
  spire-owned again) against the new test, as root: both killed
  ("handed-over directory is 0:0 750, want 65534:65534 750"; the static
  check). `18-evidence/mutants-A14-A5.txt`.
- Helper tests on 6f15ec0, root: all 9 pass. As ci (uid 1500, one group):
  all 9 pass, and the new step logs that it is not checked there ("not root
  and no second group"), as designed. `18-evidence/helper-tests-*.log`.
- CI on 62d865a and on 6f15ec0: see PR #46 checks (6f15ec0 run started at
  push).

## Evidence

`18-evidence/`: checks.txt, manifest-v2-6f15ec0.json, test-fix-14ce37a.diff,
helper-tests-root-6f15ec0.log, helper-tests-ci-6f15ec0.log,
mutants-A14-A5.txt, SHA256SUMS.txt.
