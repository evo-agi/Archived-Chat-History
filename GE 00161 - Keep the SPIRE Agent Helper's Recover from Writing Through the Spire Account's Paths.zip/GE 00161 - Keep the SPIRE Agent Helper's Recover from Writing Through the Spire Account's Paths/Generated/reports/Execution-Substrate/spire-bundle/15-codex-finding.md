# INF-14 / ES PR #34: post-merge Codex finding (report 15)

Writer, 2026-11-24 ~02:55Z. Code read on trunk_dev 5b82a6e
(`scripts/internal/remote_alpha_spire_agent.py`). Nothing run on the box.

Codex reviewed 7e6afde when the PR was marked ready (02:30Z), seconds before
the merge, and posted one P1 at 02:33Z:
https://github.com/evo-agi/Execution-Substrate/pull/34#discussion_r4674805585

## F15-1 (Codex P1): `recover` opens its attestation log through a path the spire account controls. REAL.

`attest_once` (lines 1343-1364): the scratch directory under `/run` is created
by root, then `os.chown(scratch, spire_uid, spire_gid)` and mode 0700, so the
spire account owns it and can create, rename and delete entries in it. Then,
after the `token generate` round trip, root runs `open(log_path, "wb")` on
`<scratch>/attest.log`: no `O_EXCL`, no `O_NOFOLLOW`. A process running as
spire (for example a compromised spire-server, which runs as that account) can
place `attest.log` as a symlink to any root-writable file first. Root then
truncates that file and hands the descriptor to the attesting agent, whose log
output is written into it: spire to root-file write. Line 1395 reopens the
log by path for the failure tail, so a swapped symlink also puts up to 1,500
redacted characters of a root-only file into the helper's output.

The join-token file in the same directory is safe (`O_EXCL | O_NOFOLLOW`,
`fchown`); the log open is the inconsistency.

## F15-2 (writer, same class): the new data directory is chowned by path. CONDITIONAL.

Lines 1311-1313: `os.mkdir(L.agent_data_dir)`, then `os.chown` and `os.chmod`
on the path, which follow symlinks. If `/var/lib/spire` is writable by the
spire account, a spire process can swap the new `/var/lib/spire/agent` for a
symlink between the mkdir and the chown, and root then gives spire ownership of
the symlink's target. The helper does not check who can write
`/var/lib/spire` (it does check the admin socket's directories), and the box
run plan does not record it, so whether this applies on the box is unknown.

## Scope

- Only `recover --apply` has these paths. `status` and `pin` do not: `pin`
  writes through `mkstemp` or `O_EXCL | O_NOFOLLOW` and sets owners with
  `fchown`, and its tmpfiles sandbox stays root-owned. The bundled box run
  (status, pin, status) is unaffected.
- `recover` is only for an expired agent SVID and is not in the box-run plan.
  Until a fix lands, it should not be run.
- Re-audit 06, red-team 07 and checks 09 and 12 did not catch this.

## Proposed fix (scripts-only follow-up PR)

1. Keep the scratch directory root-owned: `root:spire 0750` (spire can read the
   token, cannot create or replace entries); token file `spire 0400` or
   `root:spire 0440`.
2. Create the log with `O_CREAT | O_EXCL | O_NOFOLLOW` and read the tail
   through the retained descriptor, never by reopening the path.
3. Set the new data directory's owner and mode through a descriptor opened with
   `O_DIRECTORY | O_NOFOLLOW` (`fchown`, `fchmod`), and refuse to run `recover`
   when `/var/lib/spire` (and each parent) is writable by anyone but root, as
   the socket-directory check does.
4. Tests: a spire-owned process that plants `attest.log` as a symlink (must
   fail with the target untouched), a swapped data directory, a spire-writable
   `/var/lib/spire` refused; docs contract updated for the new modes.
