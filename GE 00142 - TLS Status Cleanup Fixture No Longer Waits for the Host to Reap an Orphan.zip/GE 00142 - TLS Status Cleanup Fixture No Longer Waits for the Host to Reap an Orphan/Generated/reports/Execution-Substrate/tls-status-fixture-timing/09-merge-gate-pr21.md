# MERGE GATE REPORT: Execution-Substrate PR #21, the TLS status cleanup fixture

**Outcome: MERGED.** `trunk_dev` is now `110d377a459471e94aa14cc83877f554ae62f893` and holds the audited bytes.

Written 2026-11-23 by the writer thread of PR #21, after the re-audit `07-reaudit-pr21.md` (verdict ACCEPT, no findings, SHA-256 `10de83911a89bdd9b1dcc69d68861c0ea1c0b7310e06905db641cf229a527abe`) and the provenance re-check `07a-merge-gate-pr21.md` (result PASS, SHA-256 `e97545ede1b4e25676aac2548bc88522c5bf86312356ae64fa17a1536c2a0036`). It follows section 5.4 of the provenance procedure. No subagents were used.

## 1. Identity

| Field | Value |
|---|---|
| Repository | `evo-agi/Execution-Substrate` |
| Pull request | [#21](https://github.com/evo-agi/Execution-Substrate/pull/21) |
| Topic branch | `claude/project-thread-k69qcw-tls-status-fixture` |
| Audited commit | `50bb328128b20aa82edb3ab1f886490bccb8b070`, tree `fb6bea9798b2d64ac724c5d4f05c3f8813457745`, manifest `8f245eddd8f3a7b5a6bbb35554b225927bbbeec60d3583dea0514f14b26ca499` on the base `f9537a8680c24bf2108b95ed20ac3724e8939d3a` |
| `trunk_dev` at the gate | `f62d0245e95e2b411be16511fc1bf9e1da727ce5` (one commit ahead of the audit base: PR #16, one file, `es/admission/internal/reliablesubmit/sqlite_physical_test.go`) |
| Accepted head | `143167d9f04a03c9f7ea30e95482babdeec1271c`, a merge commit with the parents `50bb328` and `f62d024`. No conflict. Fast-forward push at 02:42:53Z, no force |
| Tree of the accepted head | `a6816483cd1c9fcdc17af0c93756780cbe19b62e` |
| New manifest (v2), new base to accepted head | SHA-256 `af7476a4453deda69e3f8e9d87bc4f4233568b6c3d62d9991183864c9f2be651`, 503 bytes, 1 path |
| Files touched by the pull request | `remote_alpha_es_service_tls_status_test.go` only (+84/−7), a test file |
| Merge | squash, `110d377a459471e94aa14cc83877f554ae62f893`, 2026-11-23 03:00:45Z, only parent `f62d024`, pinned to the head `143167d` |

## 2. The gate, item by item

| Item of section 5.4 | Result |
|---|---|
| 1. The head equals the audited commit | The audited commit is the first parent of the head. `trunk_dev` had moved, so item 2 applies |
| 2. New bytes after taking `trunk_dev`: new manifest, no conflict, patch unchanged | **Holds.** The merge had no conflict. `git range-diff f9537a8..50bb328 f62d024..143167d` shows both commits as equal. `git diff f62d024 143167d` is byte-identical to `git diff f9537a8 50bb328`. The test file has the blob `c6652a34cd500c1f2945084c45a6c33e30fb6cb6` at the audited commit and at the head. What the merge added to the branch is byte-identical to what `trunk_dev` gained. The new manifest was taken twice with the upstream pinned to `origin/trunk_dev`, both runs identical, and reproduced from a fresh clone. It differs from the audited manifest only in the field `head`. `files`, `textual_diff_sha256` (`78a14ba7fdc288e723d97bd24a59e38efe08caae4754d32ccda5be01138bba8f`), `upstream` and `branch` are the same |
| CI on the accepted head | **Green.** Run [45101781531](https://github.com/evo-agi/Execution-Substrate/actions/runs/45101781531), job 137454048729 "build, vet and test", success, 02:43:02Z to 02:55:25Z, on GitHub's merge `1a5e73c` of `143167d` into `f62d024`. Go 1.26.5 linux/amd64. The gate's self-check ran 121 tests. The root package passed in 111.6 s. The gate's own line: "test gate passed: 41 packages, 3 of them with skipped entries (15 entries); 39 tests skipped themselves, all of them listed" |
| Provenance re-check by a fresh reader | **PASS.** `07a-merge-gate-pr21.md`, arranged by the coordinator, read-only. It reproduced the manifest `af7476a4…e651`, the tree through `git merge-tree`, both byte comparisons and the range-diff, and it read the CI result. It re-ran no test, because the audited bytes are unchanged |
| 3. Who allows the merge | A change of tests only. David's standing words of 2026-11-22 20:18Z ("I won't be reviewing test-only changes. Please merge without asking.") and 20:22Z cover it; the coordinator attached both messages to its request. Merge style: squash, pinned to the head, as for PR #14 and PR #16 |
| 4. After the merge, `trunk_dev` holds the audited bytes | **Holds** (checked at 03:02:58Z). `origin/trunk_dev` is `110d377`, and its only parent is `f62d024`. Its tree is `a6816483cd1c9fcdc17af0c93756780cbe19b62e`, the tree of the accepted head, so every path is byte-identical to the accepted head. The one manifest path has the blob `c6652a34cd500c1f2945084c45a6c33e30fb6cb6`, SHA-256 `237355441edf8e7e533492113111538e697359a34b0597aac704dd755566b0f6` and 178,685 bytes, as at the audited commit and as in both manifests. `git diff f62d024 110d377` is byte-identical to `git diff f9537a8 50bb328` (SHA-256 `d162c292e59f24fdb6728a72f8566993660fd48c3a93f20f13bed70f229f5522`) |

## 3. The new manifest, complete

```json
{"branch":"claude/project-thread-k69qcw-tls-status-fixture","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"remote_alpha_es_service_tls_status_test.go","sha256":"237355441edf8e7e533492113111538e697359a34b0597aac704dd755566b0f6","size":178685}],"head":"f62d0245e95e2b411be16511fc1bf9e1da727ce5","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"78a14ba7fdc288e723d97bd24a59e38efe08caae4754d32ccda5be01138bba8f","upstream":"origin/trunk_dev"}
```

Recipe `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified before each run.

## 4. One open line of report 06, closed here

`06-repair-pr21.md` says that the temporary folder of the Mac run was not removed. David removed it on 2026-11-23 at about 02:15Z and posted the listing of the Playground folder, which no longer shows it. Report 06 was left byte-identical because its audit was running.

## 5. After the merge

- GitHub removed the topic branch after the merge (the repository setting deletes merged head branches). `git ls-remote` no longer lists it.
- The pull request's description was updated before the merge: the audit result, the merge with `trunk_dev`, the new head and the new manifest.
- PR #22 has taken the new `trunk_dev` by a merge (`7806170`). Its own gate is a separate report.
- Not re-run: no test was run on `110d377` itself. Its tree is the tree that run 45101781531 tested (GitHub's merge `1a5e73c` of `143167d` into `f62d024` has that tree as well, because `f62d024` is an ancestor of `143167d`), and the push to `trunk_dev` starts the workflow again by itself. That run is not part of this gate.

## 6. Evidence

`/mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/09-evidence/`, with a `SHA256SUMS.txt`. Scripts are stored as `.txt` so that they are read, not run, from there.

- `merge-manifest.sh.txt`, `merge-manifest.log`: the checks of item 2 and the two manifest runs in the writer's worktree.
- `fresh-clone-merge.sh.txt`, `fresh-clone-merge.log`: the reproduction from a fresh clone.
- `manifest-base-f62d024-tip-143167d.json`: the canonical manifest.
- `whole-range-f62d024-to-143167d.diff`: the patch.
- `ci-job-137454048729.log`: the log of the CI job on the accepted head.
- `post-merge-check.sh.txt`, `post-merge-check.log`: the check of item 4.
- `squash-commit-message.txt`: the message of `110d377`.

## 7. Effect status

- This file: `/mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/09-merge-gate-pr21.md`. Its SHA-256 is in the reply that delivers it.
- Authority, security or protocol widening: none. One test file, no product code.
- Sensitive material: none read or written. This report and its evidence were scanned with the project's leak scanner before delivery; the result is in the delivery message.
- Effect status: `TOPIC_BRANCH_PUSHED` (fast-forward, `143167d`) | `PR_MARKED_READY_AND_DESCRIPTION_UPDATED` | `MERGED_TO_TRUNK_DEV` (`110d377`, squash) | `POST_MERGE_BYTES_CONFIRMED` | `TOPIC_BRANCH_REMOVED_BY_GITHUB` | `MERGE_TO_MAIN_NOT_PERFORMED` | `CHAT_ARCHIVE_TRANCHE_NOT_PERFORMED`
