# Evidence for 07-reaudit-pr21.md (ES draft PR #21, repair head 50bb328)

Everything here was produced on the audit's cloud container (kernel 6.18.44, 4 CPUs, Go 1.26.5, Python 3.13.18). Tests ran as the unprivileged user `ci` through `scripts/run-as-ci.sh.txt`. Scripts are stored as `.txt` so that they are read, not run, from here.

Scratch trees (never pushed): `/opt/audit/fix2` is a `git archive` export of `50bb328`, `/opt/audit/fix` one of `30e38d0`. Every other tree is a copy of one of them with one audit-only change. `variants/variant-diffs.txt` shows each change, and `variants/trees-and-binaries.sha256` gives the SHA-256 of each tree's test file, collector and test binary.

## Provenance

- `scripts/provenance-r21.sh.txt`: the recipe run at opening and closing.
- `provenance/provenance-open.log`, `provenance/provenance-close.log` (the closing log ends with `git ls-remote` of the topic branch and `trunk_dev`).
- `provenance/manifest-{open,close}-{1,2}.json` and `.stdout.txt`: all four byte-identical, SHA-256 `8f245edd…a499`.

## Mutants (`mutants/`)

- `scripts/mutants.py.txt` is the runner of the first audit, byte-identical to `02-audit-evidence/mutants.py.txt`. It applies each mutant to the collector in the tree its binary was built in, and verifies the collector's SHA-256 (`10a0d13e…`) before the run and after each restore.
- `mutants-fix2-count3-idle.log`: all 11 mutants, `-count=3`.
- `mutants-fix2-M05-count30-idle.log`, `mutants-fix2-M05-count10-cpu8.log`, `mutants-fix2-M05-count5-heavy.log`: M05 idle and under load.
- `partial-mutants-fix2-count10-idle-M01-only.log`: a first `-count=10` run that I stopped because it was far too slow. Its one completed line (M01) agrees with the `-count=3` result. Not counted.
- `invalid-mutants-fix2-M05-count30-interrupted.log`: the M05 run chained after it. It had already applied M05 when I stopped it, so it produced no result and left the collector mutated. I restored the collector from `git show 50bb328:scripts/internal/remote_alpha_es_tls_status.py` and checked its SHA-256 before any further run. Not counted.
- `scripts/apply_mutant.py.txt` made the M05 tree `fix2m05` (used by the separate-run sweeps) and the M05 copy of the macOS emulation.

## Load battery (`battery/`)

- `scripts/battery21r.sh.txt` ran idle, then with 8 CPU burners, then heavy (16 CPU, 4 switch, 2 iomix), checking `stress-ng` at the start and stop of each loaded phase (`load-verification.log`) and leftovers after each phase (`leakcheck.log`, `scripts/leakcheck.sh.txt`).
- `reps-fix2-{idle-n40,cpu8-n40,heavy-n20}.summary.txt` and `.json.gz` (`scripts/reps.sh.txt`): 520, 520 and 260 subtest runs, 0 failed.
- `sweep-gotest-fix2-{idle,cpu8}.log`: separate runs of the first subtest with the unchanged collector, 100 and 80, all pass. `sweep-gotest-fix2m05-{idle,cpu8}.log`: the same with M05, 40 and 40, all fail with `descendant_gone` and `no_return_while_member_visible` (`scripts/sweep_gotest.sh.txt`).
- The first variant run (below) ran from 02:13:10Z to 02:14:03Z, beside the first minute of the idle repetitions. That adds load to the "idle" part, it removes none.

## Handshake variants (`variants/`)

- `scripts/make_variants21.py.txt`, `scripts/runvariants.sh.txt`, `variants.log`: aborts after the fixture has seen "waiting" (`abort_raise`, `abort_kill`, `abort_hang`), the FIFO-holder check (`fdcheck`, with the 13 `fifo-holders-*.json`), and the macOS emulation (`macos_emul`, with and without M05).
- `scripts/make_variants21b.py.txt`, `scripts/runvariants2.sh.txt`, `variants2.log`: `early_kill` on the repair head and on `30e38d0`, and mutant M18.
- `scripts/runvariants3.sh.txt`, `variants3.log`: mutant M18b.

## Leak scan

The chat-archive scanner (`ge_chat_archive.py scan` with the known-numbers list) was run over the report and every file here. Its result is recorded in the delivery message. `SHA256SUMS.txt` covers every file except itself.
