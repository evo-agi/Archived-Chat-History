# Evidence for `02-audit.md` (independent audit of Execution-Substrate PR #21)

Target: commit `30e38d0d901f6510e6fc4b2750e02437a24019cc` on `trunk_dev` `f9537a8680c24bf2108b95ed20ac3724e8939d3a`, tree `3d27934ea022a998684b277ebb8f8e4f725fb9da`, manifest `eeb9fada97f6f60e0c71701cd4abf7e0d67d431627495bb60d67013331abb4de`. Everything ran in a cloud container (Linux, 4 CPUs, PID 1 `/process_api`) as user `ci`, through `run-as-ci.sh.txt`. Files ending in `.sh.txt` or `.py.txt` are scripts kept as text. Do not run them from here.

| File | What it is |
|---|---|
| `provenance.sh.txt`, `manifest-open-1.json`, `manifest-open-2.json`, `manifest-close-1.json`, `manifest-close-2.json` | Provenance reproduction. The opening run used the same commands typed directly, and the closing run used the script |
| `reaper_probe.py.txt`, `reaper-probe.log` | How long a SIGKILLed orphan stays visible here (12 trials) |
| `sweep_gotest.sh.txt`, `sweep-gotest-{base,fix}-idle.log`, `sweep-gotest-{base,fix}-cpu8.log` | One new `go test` process per trial, first subtest `term` only, random start phase |
| `extract_probe.py.txt`, `probe_base.py.txt`, `probe_fix.py.txt` | The fixture's Python probe taken byte for byte from each test file |
| `tree_probe_wrapper.py.txt`, `cleanup-start-process-tree.log` | Processes and groups at the moment the collector's cleanup starts |
| `mutants.py.txt`, `mutants-fix.log`, `mutants-base.log` | 11 mutants of the collector's cleanup against the three tests |
| `mutants-M05-repeat-base.log`, `mutants-M05-repeat-fix.log` | M05 repeated: base 5 runs, fix 20 runs |
| `mutants-M05-all-tlsstatus-tests-fix.log`, `control_tlsstatus.sh.txt`, `control-all-tlsstatus-failing.txt`, `control-all-tlsstatus-tests-fix.out.gz` | M05 against every `TLSStatus` test at the fix, and the unmutated control |
| `reps.sh.txt`, `reps-fix-*.summary.txt`, `reps-fix-*.json.gz` | `-test.count` repetitions of the three tests at the fix, idle and under load (raw `go test -json` events) |
| `battery.sh.txt`, `battery2.sh.txt`, `load-verification.log` | The batteries. `battery2` is the valid load run, with the load checked and the load average logged |
| `leakcheck.sh.txt`, `leakcheck.log` | Leftover-process checks after each block |
| `rootpkg.sh.txt`, `rootpkg-base.summary.txt`, `rootpkg-fix.summary.txt` | Whole root package once at base and at fix, in fresh clones |
| `format-vet-build.log` | `gofmt -l`, `go vet .` for Linux and darwin/arm64, `go build ./...` at the fix |
| `make_sketch.py.txt`, `sketch-zombie-hold.diff`, `sketch-mutants.log`, `sketch-reps-*.summary.txt` | Feasibility sketch of a repair for A2-1 (scratch copy only, not the audited bytes) |
| `invalid-load-attempt/` | The first battery, in which `stress-ng` stopped at once (`battery.out`). Its sweeps are runs with no load. Its other summaries do not count |

`SHA256SUMS.txt` has the SHA-256 of every other file in this folder and its subfolder.
