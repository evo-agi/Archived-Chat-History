# INDEPENDENT AUDIT REPORT: Execution-Substrate PR #21, the TLS status cleanup fixture that no longer waits for the host to reap an orphan

**Verdict: BLOCK.** The root cause is real and the fix removes it: at the base, 15 of 310 separate `go test` runs of the first subtest failed in this container, and with the fix 0 of 310 failed, plus 1,560 of 1,560 repeated subtest runs passed, idle and under verified load. The change is test-only, changes no bound and no assertion, and leaves no process behind. But it also removes the only case in which these tests ever saw a killed member of the group stay visible after a successful SIGKILL. As a result one broken cleanup that the tests caught every time at the base now passes every time: a cleanup that takes a delivered SIGKILL as proof and returns without seeing the group empty (finding A2-1, low). The repair is small and test-only. A sketch of it is tested in section 7.

Written 2026-11-23 by a fresh, read-only audit thread started by the coordinator. No subagents were used (section 2).

## 1. Audit target

| Field | Value |
|---|---|
| Repository | `evo-agi/Execution-Substrate` |
| Pull request | [#21](https://github.com/evo-agi/Execution-Substrate/pull/21), draft, head `30e38d0d901f6510e6fc4b2750e02437a24019cc` (GitHub API and `git ls-remote`, 00:18:50Z) |
| Base | `trunk_dev` at `f9537a8680c24bf2108b95ed20ac3724e8939d3a` |
| Topic branch | `claude/project-thread-k69qcw-tls-status-fixture` |
| Tree | `3d27934ea022a998684b277ebb8f8e4f725fb9da` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified before each run |
| Canonical manifest | SHA-256 `eeb9fada97f6f60e0c71701cd4abf7e0d67d431627495bb60d67013331abb4de`, 1 path, upstream `origin/trunk_dev` |
| Textual diff | SHA-256 `3e2d2c14df46996a0804cad01ad578c0aed3bf77c5061f23f90531ea7830d30a` |
| Changed path | `remote_alpha_es_service_tls_status_test.go`, blob `b1120bfc…` to `60275220…`, +17/−4 |
| Collector (unchanged) | `scripts/internal/remote_alpha_es_tls_status.py`, blob `6d44f131…`, SHA-256 `10a0d13e…b008` on both sides |
| Implementation report | `01-implementation.md`, SHA-256 `0554a98144f553956f75463861af044ee706c71e6c447b8e2bc3c60167487e35`, verified. Its `01-evidence/SHA256SUMS.txt`: 51 of 51 entries match, no file missing or extra |

`trunk_dev` has moved since the base, to `f62d0245e95e2b411be16511fc1bf9e1da727ce5` (PR #16). That commit changes only `es/admission/internal/reliablesubmit/sqlite_physical_test.go`, so it does not touch this change or the collector. GitHub reports the PR as `behind` (observation O2-2).

## 2. Audit posture

- Read-only toward the repository and GitHub. No edit, commit, push, comment, review or merge.
- All runs used scratch copies outside the audited clone: `git archive` exports of the base and the tip, copies of those for mutants, and two fresh clones for the whole root package. The audited clone itself was used only for the manifest.
- Tests ran as an unprivileged user `ci` (uid 1500), `umask 022`, emptied environment, default signal dispositions (`run-as-ci.sh.txt`), Go 1.26.5, Python 3.13.18 at `/usr/bin/python3`, 4 CPUs. PID 1 of this container is `/process_api --firecracker-init`.
- **No subagents.** The audit protocol (section 13.2, step 3) asks for read-only audit subagents. I did the four perspectives myself: contract (section 5), correctness and state (sections 4 and 5), test adequacy (section 6) and process and artifact behaviour (sections 4 and 6). The change is one string constant and a comment in one fixture. Standing session rules also limit subagents to when they are asked for.

## 3. Provenance reproduction

Commands: `provenance.sh.txt` (section 5.3 of the provenance guide). The opening run used the same commands typed directly at about 23:08Z, and the closing run used the script at 00:18Z.

| Step | Result |
|---|---|
| Recipe bytes | `c08597e2…a1ca`, OK, opening and closing |
| Pushed tip equals reported tip | yes, `30e38d0` |
| Base is an ancestor of the tip | yes |
| Tip tree | `3d27934e…` |
| Opening manifest, two runs | identical, `eeb9fada…b4de` (`manifest-open-1.json`, `manifest-open-2.json`) |
| Closing manifest, two runs | identical, `eeb9fada…b4de` (`manifest-close-1.json`, `manifest-close-2.json`) |
| Opening equals closing | byte-identical |
| Mode differences | none |
| `git diff f9537a8 30e38d0` | equals the writer's `change.diff` (SHA-256 `ac825c52…b212`) |

**Result: provenance reproduced, no mismatch.**

## 4. Is the root cause real? Yes, reproduced

### 4.1 The host's reaper

`reaper_probe.py.txt`, `reaper-probe.log`: 12 orphans, each killed with SIGKILL at a random moment. All 12 were adopted by PID 1 (the probe is not a subreaper, `PR_GET_CHILD_SUBREAPER` = 0). Each stayed visible in `/proc` for 1.580 to 1.996 s after the kill. Every disappearance fell at the same fraction of a second (0.730 to 0.739), so PID 1 reaps on a one-second grid, and only zombies about a second old. This matches the writer's `orphan-stagger.log`. A first run of 24 trials gave 1.264 to 1.989 s. I replaced its log because one diagnostic line in it was mislabeled.

### 4.2 The flake in real `go test` runs

The writer showed the flake with a hand-run sweep. I used real `go test` binaries instead: each trial is one new process that runs only `TestRemoteAlphaESServiceTLSStatusCombinedGroupSignalFailureLiveDescendant/term`, after a random delay, so the subtest starts at a random phase of the reaper's tick (`sweep_gotest.sh.txt`).

| Batch | Base `f9537a8` | Fix `30e38d0` |
|---|---|---|
| Idle (`sweep-gotest-*-idle.log`) | **6 of 150 fail**, 1.20 to 2.12 s | 0 of 150 fail, 0.14 to 0.23 s |
| No load verified (`invalid-load-attempt/`, see O2-4) | **6 of 80 fail**, 1.24 to 2.12 s | 0 of 80 fail, 0.14 to 0.19 s |
| Beside 8 CPU burners, load average 8.3 to 8.5 (`sweep-gotest-*-cpu8.log`) | **3 of 80 fail**, 1.38 to 2.32 s | 0 of 80 fail, 0.19 to 0.40 s |
| **Total** | **15 of 310 fail** | **0 of 310 fail** |

Every failure has the writer's signature: `leader_reaped failed` and `returned failed`, in 9 of the 15 also `descendant_gone failed`. Each failing run took 2.10 to 2.35 s, which is the fixture's `thread.join(2)` running out.

### 4.3 The fix does what the report says

`tree_probe_wrapper.py.txt` runs the fixture's own probe, taken byte for byte from each test file (`extract_probe.py.txt`, `probe_base.py.txt`, `probe_fix.py.txt`), and records the processes at the moment the collector's cleanup starts (`cleanup-start-process-tree.log`, modes `term`, `hold` and `scan_plain_once`):

- **Fix:** the leader is a zombie that the collector keeps with `WNOWAIT`, in group L. The descendant is in group L, ignores SIGTERM, and its parent is the keeper. The keeper is in a group of its own (its process group id is its own pid), so it is not in group L.
- **Base:** the descendant's parent is PID 1.

I also checked the ordering in the code. `run_fixed` starts the cleanup only after both output pipes report end of file and the leader has ended (`scripts/internal/remote_alpha_es_tls_status.py:1106`, `while selector.get_map() or not leader_terminal(proc)`). The keeper calls `setpgid(0,0)` and writes the pid file before it closes its copies of the pipes. The descendant ignores SIGTERM before it closes its copies. So the keeper cannot be in group L when the cleanup begins, the pid file is complete by then, and the cleanup always has to go on to SIGKILL. The only other way into the cleanup is the 2.5 s child timeout, and that cannot give a false pass, because the fixture first fails with "descendant did not spawn" after 2 s.

## 5. Test-only, assertions unchanged, contract

- **One path changes, a test file.** The diff touches only the text of the Python stand-in child inside `runRemoteAlphaESStatusGroupFailureCase` and adds a comment above it. Product code, docs, CI files and the environment-only test list are unchanged. The three tests have no line in `.github/ci/environment-only-tests.txt`, so the CI gate requires them to pass.
- **No weakened assertion.** The modes, the ten result labels, `thread.join(2)`, the 2 s wait for the pid file, `CHILD_TIMEOUT=2.5`, `CHILD_GRACE=.15`, the 8 s context and the cleanup in `finally` are byte-identical (`change.diff`).
- **One check got stronger.** The descendant now ignores SIGTERM before it closes its pipes. Before, a cleanup SIGTERM could in principle land first and end the descendant without reaching the SIGKILL step.
- **The contract stays as written.** "No outer retry may return until group absence and exactly one direct-child reap are proved" (`.docs/system_overview/remote_supported_host_alpha.md:3533-3534`, the same rule at `.docs/system_overview/remote_alpha_access_contract.md:194-196`). The writer's citations are correct. Section 6.2 shows that the tests now pin this rule less well than before.

## 6. Does the fix hide a broken cleanup?

### 6.1 My own mutants

I wrote 11 mutants of the collector's cleanup, independent of the writer's P1 to P10 (`mutants.py.txt`). Each ran against the three tests: 3 times at the fix and once at the base, the same binaries, the collector restored and its hash checked after each (`mutants-fix.log`, `mutants-base.log`).

| Mutant | Base | Fix |
|---|---|---|
| M01 a failed `killpg` skips the member fallback | caught, 11 subtests | caught, the same 11 |
| M02 no SIGKILL in the bounded escalation step | survives | survives |
| M03 the hold loop sends SIGTERM, not SIGKILL | caught, `hold`, `scan_hold` | caught, the same |
| **M05 trust a delivered SIGKILL**: the hold loop stops after one SIGKILL that raised no error, and the proof after the reap scans once without waiting for absence | **caught**, `term`, `scan_plain_once`, `post_reap_scan_once`, label `descendant_gone` | **survives** |
| M06 only the second half of M05 | survives | survives |
| M07 only the first half of M05 | survives | survives |
| M08 the leader is reaped right after the first SIGTERM | caught, 13 | caught, 13 |
| M10 `own_child_until_proved` gives up on the first exception | caught, `poll_hold` | caught, `poll_hold` |
| M12 the cleanup starts when the leader ends, without waiting for end of file on the pipes | survives | survives |
| M16 member signal failures are swallowed | survives | survives |
| M17 the bounded waits take a terminal leader as a resolved group | caught, 13 | caught, 13 |

Ten of the eleven behave the same on both sides, each caught by the same subtests. M05 is the exception.

### 6.2 M05 is caught every time at the base and never at the fix

- **Base, repeated:** 5 runs, 15 of 15 runs of `term`, `scan_plain_once` and `post_reap_scan_once` fail, each with `descendant_gone` (`mutants-M05-repeat-base.log`).
- **Fix, repeated:** 20 runs, 260 of 260 subtest runs pass (`mutants-M05-repeat-fix.log`).
- **No other test in the file catches it at the fix.** With M05 applied, every test that matches `TLSStatus` gives exactly the same 30 failing subtests as the unchanged collector, and those 30 are environment failures of this container (`mutants-M05-all-tlsstatus-tests-fix.log`, `control-all-tlsstatus-failing.txt`, `control-all-tlsstatus-tests-fix.out.gz`).

**Why.** In the three modes that let the real SIGKILL through, M05 returns right after the kill. At the base the killed descendant stays a zombie for 1 to 2 s, and the fixture's stand-in for the process read (`os.getpgid`) still sees it in the group, so `descendant_gone` fails. At the fix the keeper reaps the descendant within microseconds, before the fixture looks, so a cleanup that never checked passes.

What that means, in finding A2-1 (section 8).

### 6.3 Repetitions of the fix, idle and under load

`reps.sh.txt` runs the three tests with `-test.count=N` and reads the JSON events. Load was started from `/tmp`, checked to be running, and the load average was logged at start and stop (`load-verification.log`, `battery2.sh.txt`).

| Run | Subtest runs | Failures | Time per subtest | Log |
|---|---|---|---|---|
| Idle, N=60 | 780 | 0 | 0.14 to 0.59 s | `reps-fix-idle-n60.summary.txt` |
| 8 CPU burners, load average 8.49 at the end, N=40 | 520 | 0 | 0.18 to 0.83 s | `reps-fix-cpu8-n40.summary.txt` |
| 16 CPU burners + 4 context-switch + 2 I/O workers, load average 26.64 at the end, N=20 | 260 | 0 | 0.22 to 1.63 s | `reps-fix-heavy-n20.summary.txt` |
| **Total** | **1,560** | **0** | | |

Plus the 310 separate runs of section 4.2.

### 6.4 Leftover processes

`leakcheck.sh.txt` lists every `fixed-openssl` process (the stand-in child, the keeper and the descendant all run under that name), every probe interpreter, the fixture's "unrelated" sleeper, and every zombie. It ran 3 s after each block of runs, 8 times in all (`leakcheck.log`). Every time it found nothing.

The keeper is orphaned when the stand-in child exits. After it has reaped the descendant and exited, its own zombie waits for PID 1, at most about 2 s here. It is outside group L, so the collector never looks at it. On failure paths the descendant ends by itself after 3 s (or by the fixture's SIGKILL in `finally`), and then the keeper exits too. Nothing outlives a subtest by more than about 3 s. The collector starts the child with `close_fds=True`, so neither process holds the Go test's output pipe.

### 6.5 Whole root package

Fresh clones at the base and the tip, `go test -count=1 -json .` (`rootpkg.sh.txt`):

| | Base | Fix |
|---|---|---|
| Results | 2,235 (2,075 pass, 160 fail) | 2,235 (2,075 pass, 160 fail) |
| Failing top-level tests | 10 environment tests | **the same 10** |
| The three tests | pass, about 2 s per subtest | pass, 0.14 to 0.56 s per subtest |

(`rootpkg-base.summary.txt`, `rootpkg-fix.summary.txt`.) The writer counted nine environment failures. The difference is this container's setup (I did not generate the `en_US.UTF-8` locale). It does not depend on the change, since base and fix fail the same set.

### 6.6 Format, vet, build, portability

- `gofmt -l` on the file: no output. `go vet .` exit 0. `GOOS=darwin GOARCH=arm64 go vet .` exit 0. `go build ./...` exit 0 (`format-vet-build.log`).
- The child script uses only `fork`, `setpgid`, `waitpid`, `signal`, `os.close` and `time.sleep`, with no branch on the operating system.
- **macOS: not run by me.** I read the writer's `mac-run-report-2.txt`: at `30e38d0`, tree confirmed, one verbose run and 30 repetitions pass (390 subtest runs), and no `fixed-openssl` process was left after the runs. On the Mac the base passes at the same speed, as expected for a first process that reaps at once.

### 6.7 The GitHub runner

- Check run 137384041304 (`build, vet and test`) on the PR head: `completed`, `success`.
- The job log fetched from GitHub is byte-identical to the writer's `runner-run-45079441043-job-137384041304.log` (SHA-256 `a5b3e6a2…3c2b`).
- The runner checked out merge commit `2142f7d794c82f8faff6758d50e9435100d5bfbe`. I fetched that commit: its tree is `3d27934e…`, the tree of the tip.
- The writer's inference that the three tests ran and passed there follows from the gate's rules. I agree, and it stays an inference: the log does not name passing tests.

## 7. A repair that keeps the coverage (feasibility sketch, not a repair)

`make_sketch.py.txt` writes a scratch copy of the fixed test file (`sketch-zombie-hold.diff`, two lines of the child script). The keeper blocks SIGCHLD before it forks the descendant. After its setup it waits for SIGCHLD with `signal.sigwait`, which tells it the descendant has died but does not reap it, sleeps 0.3 s, and only then reaps it. So after any successful kill the member stays visible for a fixed 0.3 s on every host. Everything else, including the 2 s bounds, is unchanged.

| Check on the sketch (this container only) | Result |
|---|---|
| All 11 mutants, 3 runs each (`sketch-mutants.log`) | same as the fix, **except M05: caught**, `term`, `scan_plain_once`, `post_reap_scan_once`, 3 of 3 runs |
| Idle, N=20 (`sketch-reps-idle-n20.summary.txt`) | 260 of 260 pass, 0.44 to 0.84 s per subtest |
| 8 CPU burners, load average 8.3, N=10 (`sketch-reps-cpu8-n10.summary.txt`) | 130 of 130 pass, 0.54 to 1.00 s per subtest |
| Leftover processes | none |

The two-second bound keeps more than a second to spare. **Unknown:** whether `os.getpgid` sees a zombie on macOS, and so whether the hold delays absence there. The writer should check that, or pick another host-independent way to keep the killed member visible for a fixed time, for example in the fixture's own stand-in for the process read.

## 8. Findings

### A2-1: the fixture no longer shows any killed member that stays visible, so a cleanup that trusts a delivered SIGKILL passes

```text
ID / Type / Severity: A2-1 / test-validation gap (coverage removed by the patch) / low
Current contract: "No outer retry may return until group absence and exactly one direct-child
  reap are proved" (.docs/system_overview/remote_supported_host_alpha.md:3533-3534;
  remote_alpha_access_contract.md:194-196)
Path and line: remote_alpha_es_service_tls_status_test.go, runRemoteAlphaESStatusGroupFailureCase,
  the child script (lines 2817-2823 at 30e38d0)
Evidence: mutant M05 (section 6.2): base 15 of 15 failing runs in term, scan_plain_once and
  post_reap_scan_once; fix 260 of 260 passing; no other TLSStatus test catches it at the fix
Impact: after this change, no test in the container, on the runner or on the Mac fails if the
  collector's cleanup stops waiting to see the group empty after a SIGKILL that raised no error.
  Such a regression would release the status lock and return while a killed member is still
  visible (a zombie not yet reaped, or a process stuck in the kernel), which is the window the
  contract forbids.
Patch defect or pre-existing: both, in part. The patch removes the only case where these tests
  saw a member stay visible after a successful kill. Before it, only this container's slow reaper
  produced that case, and only by accident. Inference: on hosts that reap at once (the Mac, very
  likely the runner) the base did not catch M05 either. The Mac's base subtests take 0.34 to
  0.76 s, so no zombie lingered there.
Required correction: see repair scope below.
Uncertainty: the macOS behaviour of any hold mechanism (section 7).
```

**Why BLOCK and not ACCEPT with a follow-up.** The brief asked that the tests still catch a broken cleanup. In the container where the flake happened, this change turns a mutant that was caught every time into one that is never caught. The project rules ask for the proper fix now rather than a later revisit. That fix is about two lines in the same fixture, test-only, and it makes the coverage independent of the host, which is better than the base anywhere.

**Repair scope (test-only, same file):**

- **R1.** Keep the keeper. Make it keep the killed descendant visible for a fixed time before it reaps it, the same on every host (the sketch uses `sigwait` and 0.3 s). Leave every bound and assertion as it is, and update the comment above the fixture.
- **R2.** Show M05 caught on the new head deterministically (at least 5 runs), the other mutants unchanged (mine and the writer's P1 to P10), and the flake still gone: a separate-run sweep (at least 150) and `-count` runs, idle and under load whose presence is checked.
- **R3.** One macOS run of the three tests on the new head, with no leftover process. Say whether the hold keeps the member visible there. If it does not, use a mechanism that does, or state that the extra coverage is Linux-only.

**Re-audit, decided now:** a narrow audit of the repair delta plus provenance. ACCEPT if R1 to R3 hold and nothing else changed.

### Observations (not caused by the patch, no action required by this audit)

- **O2-1. Mutants that survive on both sides.** M02 is equivalent, because the hold loop delivers the SIGKILL anyway. M06 and M07 are each half of M05, and the other half covers for each one: defence in depth, as designed. M12 shows that no test pins "cleanup starts only after end of file on the pipes". The keeper's design relies on that order. **Inference:** if the product changed to M12's behaviour, the keeper could be killed while still in the group, and the fixture would fall back to the host's reaper. That would show up as flakiness, not as a false pass. M12 survived 39 of 39 at the fix because the keeper leaves the group well within the collector's 50 ms poll. In M16, swallowed member-signal failures are hidden because the failed `killpg` already marks the cleanup uncertain in every mode where member signals fail. These are pre-existing gaps. Whether to close them is the coordinator's call.
- **O2-2. Merge gate.** `trunk_dev` is at `f62d024` and the PR is `behind`. Updating the branch makes new bytes, so the gate follows provenance section 5.4 (new manifest, range-diff, re-check).
- **O2-3. Margins under heavy load.** At load average 26.6, whole subtests took up to 1.63 s, including the interpreter's start. The fixture's 2 s wait for the pid file and its 2 s join are unchanged by this patch. No run failed.
- **O2-4. My first load battery was invalid.** `stress-ng` stopped at once ("temp-path '.' must be readable and writeable", `invalid-load-attempt/battery.out`), so those "load" runs ran without load. I redid all of them with checked load (section 6.3). I kept the first attempt's files. Its two sweeps count as runs with no load in section 4.2, and its other summaries count for nothing.
- **O2-5. One environment artefact.** `TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveRuntimeSourceMode` failed in my mutant copy because `git archive` writes files as 0664. It fails the same way in the control and passes in the git clones. It is not a finding.
- **O2-6.** The writer's section 9 (a zombie holds the collector's cleanup for as long as nobody reaps it) matches the code. It is covered by the writer's `02-cleanup-hold-investigation.md` and is outside this audit.

## 9. Validation assessment

| Writer's claim | Re-checked here? | Result |
|---|---|---|
| Root cause: orphan, PID 1 reaps on a one-second tick, 2 s join | yes, independently | confirmed (sections 4.1, 4.2) |
| 7 of 80 hand-run start phases fail at the base | not re-run | replaced by real `go test` runs: 15 of 310 fail at the base |
| The keeper leaves the group before the cleanup | yes | confirmed by a process snapshot and by the code (section 4.3) |
| 2,340 subtest runs pass after the fix | not re-run as such | my own 1,560 + 310, all pass |
| 8 of 8 product mutants caught before and after | not re-run | my own 11: 10 behave the same, M05 does not (A2-1) |
| Runner run green on the tip's tree | yes | log identical, merge tree = tip tree, check `success` |
| macOS: passes, no leftovers | read only | consistent; not run by me |
| gofmt, vet for Linux and darwin, build | yes | clean |
| Doc citations | yes | correct |
| 4 leak-scanner hits are false matches | yes | confirmed: the module-cache path `toolchain@v0.0.1-go1.26.5…` three times, the SSH form of the repository URL once (`mac-run-report-1.txt:12,25`, `mac-run-report-2.txt:7,8`) |

Not run: macOS, the race detector (no Go statement changed), the full CI gate.

## 10. Sensitive material

None read or written. The fetched merge commit's metadata holds an e-mail address of the account owner. It is not copied into this report or its evidence. I scanned this report and `02-audit-evidence/` with the project's leak scanner before delivery (result in the delivering reply).

## 11. Confidence

- **Provenance: 0.99.** Reproduced twice at opening and closing, byte-identical.
- **Validation: 0.9.** Linux only. Many runs, idle and under checked load, independent mutants. No macOS run of my own.
- **Implementation (as a flake fix): 0.9.** The mechanism is measured from both ends.
- **A2-1: 0.95.** Deterministic on both sides. The only open point is how the repair behaves on macOS.

## 12. Effect status and delivery

- Effect status: `REPAIR_NOT_PERFORMED` | `COMMIT_NOT_PERFORMED` | `PUSH_NOT_PERFORMED` | `PR_NOT_COMMENTED` | `MERGE_NOT_PERFORMED`.
- This file: `/mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/02-audit.md`, SHA-256 in the delivering reply.
- Evidence: `/mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/02-audit-evidence/`, with `README.md` and `SHA256SUMS.txt`.

**Final verdict: BLOCK** (A2-1, low, test-only repair R1 to R3).
