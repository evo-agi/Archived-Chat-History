# REPAIR REPORT: Execution-Substrate PR #21, the cleanup fixture holds its killed descendant until it has seen the cleanup wait for it

**Outcome: finding A2-1 is repaired with a handshake, not with a fixed delay. The keeper now reaps the killed descendant only when the fixture lets it, and the fixture lets go only after it has seen the cleanup wait for that process. The auditor's mutant M05 (a cleanup that trusts a delivered SIGKILL) fails again in every run: 30 of 30 subtest runs in the mutant runner and 270 of 270 separate test runs, idle and under load. Every other mutant keeps exactly its verdict and its failing subtests. The repaired tests passed 1,560 of 1,560 repeated subtest runs and 270 of 270 separate runs, idle and under checked load, and the CI run on the new head is green. The three tests also passed on David's Mac, once verbose and 30 times in a row, and the Mac answered the open question of R3 (section 7).**

**Revised 2026-11-23 at about 02:20Z:** the Mac run is done. Section 7 is new, and the R3 row of section 2, sections 8, 11, 12 and 13 follow it. Nothing else changed. The first delivery of this file had the SHA-256 `07d3a49fec4c24d0c4131c7859412a5d1abf0b6cc7d056b7eaaec86bb70d9a76`.

Written 2026-11-23 by the writer thread of PR #21, in answer to `02-audit.md` (verdict BLOCK on A2-1, low). No subagents were used. Independent audit of the new head: not performed. Under provenance section 5.5 the new head needs a fresh audit of the whole range from the base to the tip.

## 1. Identity

| Field | Value |
|---|---|
| Objective | Repair A2-1: the fixture must again show a killed member that stays visible, so that a cleanup that trusts a delivered SIGKILL fails, without bringing back the dependence on the host's reaper |
| Repository | `evo-agi/Execution-Substrate` |
| Base | `trunk_dev` at `f9537a8680c24bf2108b95ed20ac3724e8939d3a` (the base of the audited commit) |
| Topic branch | `claude/project-thread-k69qcw-tls-status-fixture` |
| Audited commit | `30e38d0d901f6510e6fc4b2750e02437a24019cc` (tree `3d27934ea022a998684b277ebb8f8e4f725fb9da`) |
| Repair commit, new head | `50bb328128b20aa82edb3ab1f886490bccb8b070`, parent `30e38d0`, fast-forward push, no force |
| Tree | `fb6bea9798b2d64ac724c5d4f05c3f8813457745` |
| Pull request | [#21](https://github.com/evo-agi/Execution-Substrate/pull/21) (draft) |
| Manifest (v2), base to tip | SHA-256 `8f245eddd8f3a7b5a6bbb35554b225927bbbeec60d3583dea0514f14b26ca499`, 1 file |
| Files touched | `remote_alpha_es_service_tls_status_test.go` only. Repair commit: 71 lines added, 7 removed. Whole range: 84 added, 7 removed |
| Final working-tree status | clean after the commit; the branch is pushed and equals its remote |
| `trunk_dev` today | `f62d0245e95e2b411be16511fc1bf9e1da727ce5`. The PR is `behind`. The merge gate (provenance section 5.4) comes after the audit |

## 2. What the audit asked and what was done

| Audit item | Done |
|---|---|
| **A2-1.** Because the keeper reaps at once, a cleanup that trusts a delivered SIGKILL passes | Repaired. The keeper holds the dead process until the fixture has seen the cleanup wait for it (section 3) |
| **R1.** Keep the keeper, keep the killed descendant visible for a fixed time (sketch: 0.3 s), leave every bound and assertion, update the comment | The keeper stays. In place of the fixed time there is a handshake, as the coordinator preferred, so no result depends on a duration. No bound and no existing assertion changed. Two result keys were added. The comment above the fixture is rewritten |
| **R2.** M05 caught on the new head in at least 5 runs, the other mutants unchanged, sweep of at least 150 and `-count` runs, idle and under checked load | Sections 5 and 6. M05: caught in 30 of 30 and in 270 of 270 separate runs. Other mutants: identical on both sides, subtest by subtest. Repetitions: 1,560 of 1,560. Sweeps: 270 of 270 |
| **R3.** One macOS run of the three tests on the new head with no leftover process, and say whether the hold keeps the member visible there | **Done.** The three tests pass on David's Mac at `50bb328`, once verbose and 30 times in a row, and no process is left. The hold keeps the killed process unreaped there too, but macOS does not show such a process to `getpgid`, so the extra coverage against M05 is Linux-only (section 7) |

## 3. The repair

### 3.1 Mechanism

Before the repair the keeper called `waitpid` right away, so the killed descendant left the group the moment it died. Now:

1. **The keeper waits for the fixture before it reaps.** The fixture creates a FIFO next to the pid file and keeps its write end open. The keeper opens the read end before it writes the pid file, then blocks in a read. The read ends when the fixture closes its end. Only then does the keeper call `waitpid`. Until then the killed descendant stays in the fixed child's group as a dead process that nobody has reaped, which is what the collector's cleanup must wait for.
2. **The fixture lets go only after it has seen the cleanup wait.** It sees this through the stand-ins it already had for the signal calls and for the identity read. Three things must have happened, in this order:
   - a SIGKILL was delivered to the descendant (the group signal succeeded, or the member signal did);
   - the cleanup left the bounded wait that follows that SIGKILL. This shows when the cleanup delivers one more signal, or when it has reaped the fixed child (the fixture reads the collector's own mark on the child for that);
   - after that, the cleanup read the descendant's identity twice and found it in the group both times.
3. **When the fixture lets go, it checks the state.** The cleanup must not have returned and must still hold its lock. This is the new result key `no_return_while_member_visible`.
4. **A cleanup that returns sooner is caught without a clock.** When `run_fixed` returns and the fixture has not let go yet, the fixture looks whether the descendant is still in the group. If it is, the same key fails. The descendant cannot have left by itself, because the keeper is still blocked.
5. **The fixture checks its own hold.** At the moment it lets go it asks whether the descendant still exists unreaped. This is the second new key, `keeper_held_descendant`. It fails if the keeper ever reaps early, on any host.

The fixture's last step and its error path both close the FIFO, and a fixture that dies closes it too, so the keeper cannot be left blocked.

### 3.2 Why the three steps, and not something simpler

- **The reads inside the bounded wait must not count.** A cleanup that trusts the SIGKILL also reads the descendant's identity inside the bounded wait, and stops right after. A fixture that counted those reads would let go too early and the mutant would pass. I checked this: fixture mutant F2 counts them, and with it M05 survives 65 of 65 runs (section 5.3).
- **Two reads, not one.** A cleanup that trusts the SIGKILL does one more scan after the reap. With one read as the rule, that single scan can let the fixture go just in time. Fixture mutant F3 shows it: M05 is then caught in only 13 of 15 runs.
- **Why not "two SIGKILLs".** My first rule waited for a second SIGKILL. That asks more of the cleanup than the documented contract does (the documents require that the cleanup does not return before the group is proved empty, not that it signals again), and it would have changed the failing subtests of two other mutants (M03 and P2). The rule above keeps every other mutant exactly as it was.

### 3.3 Does any result still depend on a duration?

No new sleep and no new pause decides a result. One new wait has a bound: after the cleanup starts, the fixture waits up to 2 seconds to see either "the cleanup is waiting" or "the cleanup returned". This bound sits beside the two bounds that were there before (2 s for the pid file, 2 s for the cleanup thread to end) and works the same way: on a host too slow for it, a run can fail, but a broken cleanup cannot pass because of it. An early return is judged at the moment of the return, not by the clock.

The fixture saw the cleanup waiting in all 13 subtests, 65 of 65 runs, in a scratch copy with one more result key (`06-evidence/waiting-probe.log`). So on Linux the new check is active in every subtest, not only in the three where M05 differs.

### 3.4 What the handshake does not show

- A cleanup that waits correctly for at least two rounds and then gives up while the member is still visible. Any finite test has such a limit, and the fixed delay of the sketch had it too (0.3 s). The three `hold` subtests keep their own check that an unresolved cleanup does not return.
- On a host that does not show a dead, unreaped process to `getpgid`, the cleanup has nothing to wait for, and the three steps never complete. There the case runs as it did at `30e38d0`. `keeper_held_descendant` is still checked there. See section 7.

## 4. Files touched

One file, `remote_alpha_es_service_tls_status_test.go`, inside `runRemoteAlphaESStatusGroupFailureCase`: the Go comment above the fixture, the text of the keeper script, and the text of the probe script. No Go statement changed. No product file, no document, no script, no CI file.

## 5. Do the tests catch a broken cleanup again?

All runs in the cloud container, account `ci`, emptied environment, Go 1.26.5. `head` is tree `fb6bea97…` (the repair), `old` is tree `3d27934e…` (the audited commit). The test binary reads the collector of the tree it was built in, so each mutant was applied in that tree and the tree was restored after it (`collector-after.sha256`, `tree-dirty.txt`).

### 5.1 The auditor's mutants, with the auditor's unchanged runner

| Mutant | `old` (30e38d0) | `head` (50bb328) |
|---|---|---|
| **M05** trust a delivered SIGKILL, `-count=10` | **survives**, 0 of 130 subtest runs fail | **caught**, 30 of 130 fail: all 10 runs of `term`, `scan_plain_once` and `post_reap_scan_once` |
| M05, `-count=3` | survives, 0 of 39 | caught, 9 of 39 |
| M01 | caught, 33 of 39 | caught, 33 of 39 |
| M02 | survives | survives |
| M03 | caught, 6 of 39 | caught, 6 of 39 |
| M06, M07 (each half of M05) | survive | survive |
| M08 | caught, 39 of 39 | caught, 39 of 39 |
| M10 | caught, 3 of 39 | caught, 3 of 39 |
| M12, M16 | survive | survive |
| M17 | caught, 39 of 39 | caught, 39 of 39 |

M05 fails with the labels `descendant_gone` and `no_return_while_member_visible`. M05 differs from the product only where the group SIGKILL succeeds, and those are the three subtests that fail. M02, M06, M07, M12 and M16 survive on both sides, as the audit's observation O2-1 describes. M10 fails in the same subtest as before and now also shows the new label.

### 5.2 The writer's eight mutants

All eight are killed on both sides, and each one fails in the same subtests on both sides (`mutants-head/product.log`, `mutants-old/product.log`). The control passes all 13 subtests.

### 5.3 Mutants of the fixture itself

Each line is 5 runs of the 13 subtests with the unchanged collector, and 5 runs with M05.

| Fixture | Unchanged collector | Collector with M05 |
|---|---|---|
| F0, as committed | 65 of 65 pass | fails 15 of 15 in the three subtests |
| F1, the keeper does not wait and reaps at once | 65 of 65 **fail** on `keeper_held_descendant` | same |
| F2, reads inside the bounded wait count too | 65 of 65 pass | **M05 survives**, 65 of 65 pass |
| F3, one read is enough | 65 of 65 pass | M05 caught in only 13 of 15 |
| F4, the fixture lets go before it starts the cleanup | 65 of 65 **fail** on `keeper_held_descendant` | same |

F1 and F4 show that a fixture that falls back to the behaviour of the audited commit fails by itself. F2 and F3 show that both parts of the rule are needed.

## 6. Is the flake still gone?

### 6.1 Repetitions (`go test -count`, the three tests, 13 subtests)

| Condition | Subtest runs | Failed | Duration of a subtest |
|---|---|---|---|
| Idle, `-count=60` | 780 | 0 | 0.31 to 0.74 s |
| 8 CPU burners, `-count=40` (load average 9.4 at the end) | 520 | 0 | 0.36 to 1.13 s |
| 16 CPU burners, 4 pairs passing a byte, 2 writers, `-count=20` (load average 23.7 at the end) | 260 | 0 | 0.38 to 2.04 s |
| **Total** | **1,560** | **0** | |

The load was checked at the start and at the end of every loaded part (`battery/load-verification.log`).

### 6.2 Separate runs (one test process per trial, random start phase)

| Subtest | Condition | Repaired head | Head tree with M05 |
|---|---|---|---|
| `term` | idle | 150 of 150 pass | 150 of 150 fail |
| `term` | 8 CPU burners | 80 of 80 pass | 40 of 40 fail |
| `term` | heavy load | not run | 40 of 40 fail |
| `scan_plain_once` | 8 CPU burners | 20 of 20 pass | 20 of 20 fail |
| `post_reap_scan_once` | 8 CPU burners | 20 of 20 pass | 20 of 20 fail |
| **Total** | | **270 of 270 pass** | **270 of 270 fail** |

Every M05 failure shows the two labels `descendant_gone` and `no_return_while_member_visible`.

### 6.3 Two attempts were invalid and are not counted

Both are kept in `06-evidence/battery/` under names that start with `invalid-`.

- **The first "M05" sweep ran the unchanged collector.** It used the test binary built in the head tree, and that binary reads the head tree's collector. All 150 runs passed, which was the sign. I built a second binary in the tree that holds the mutant and repeated it.
- **One sweep ran no test.** The sweep script always named the first of the three tests, and `scan_plain_once` belongs to another one. Every trial ended in 0.03 s with status 0 and no verdict. I repeated it with a script that takes the test name and counts a trial without a verdict as not run (`sweep2.sh.txt`).

The mutant runs of section 5 were not affected by either mistake: they mutate the tree their binary was built in, and they name all three tests.

### 6.4 Leftover processes

With nothing else running on the machine, three runs of the three tests left no process: no fixture process, no probe, no zombie, checked 3 seconds after the end (`battery/leakcheck-quiet.log`).

The checks during the battery need a note. Other work of mine ran on the machine during the second part (the test runs of the PR #22 repair). Four checks listed a process. Each listed process was a live process of that other work, not a leftover of the fixture. In three checks the script text that the list shows is in the test file of PR #22, which the battery never ran. In the fourth it is the probe of another test of the TLS status file; the battery had just run only the `term` subtest, and the PR #22 run of all TLS status tests was under way at that moment (01:26:47Z to 01:29:19Z). One earlier "quiet" check overlapped with the probe of section 3.3 and listed that probe's processes, so I repeated it with the machine quiet. Both are kept.

One thing a reader will see in those lists: the keeper ends as an orphan, so the host's first process reaps it. In this container that takes one to two seconds, and for that time the keeper shows as a zombie in its own group. Nothing waits for it and the collector never sees it, because it left the fixed child's group at its start. It was the same at `30e38d0`.

### 6.5 Format, vet, the three tests, the whole root package

- `gofmt -l`: no output. `go vet .`: exit 0. `GOOS=darwin GOARCH=arm64 go vet .`: exit 0.
- The three tests, verbose, once: pass, 5.5 s.
- Whole root package, `head` against `old`: 2,235 tests with a verdict on both sides, 38 fail on both, the same set (the 8 known tests that need another environment, with their subtests), 0 skips, 0 tests whose verdict differs.

### 6.6 The GitHub runner

Run [45093838877](https://github.com/evo-agi/Execution-Substrate/actions/runs/45093838877), job "build, vet and test", on the merge of `50bb328` into `trunk_dev` at `f62d024`: **success**, 01:18:43Z to 01:31:22Z. Root package `ok` in 109.6 s. Gate: "test gate passed: 41 packages, 3 of them with skipped entries (15 entries); 39 tests skipped themselves, all of them listed". The complete log is in `06-evidence/runner/`.

## 7. macOS (R3): run on David's Mac, passed

David approved the run at 02:04Z. It ran once, from the brief `06-evidence/mac-instructions-3.txt`, and its full result is `06-evidence/mac-run-report-3.txt`.

| Point | Result |
|---|---|
| Host | macOS 26.6.2 (25G83), arm64, first process `launchd`, Go 1.26.5 from the module cache with `GOPROXY=off` |
| Target | a new clone in a new temporary folder, commit `50bb328128b20aa82edb3ab1f886490bccb8b070`, tree `fb6bea9798b2d64ac724c5d4f05c3f8813457745`. Both equal the target of this report |
| The three tests once, verbose | pass, 13 of 13 subtests, no skip, 6.06 s |
| The three tests 30 times in a row | pass, 390 subtest runs, 175.6 s |
| `gofmt -l` on the test file | no output |
| Processes left after the runs | none (`fixed-openssl`, the test binary and the name of the temporary folder were searched) |
| A killed child that nobody has collected yet | `getpgid(pid)` fails with ESRCH. `kill(pid, 0)` succeeds. `killpg(pgid, 0)` fails with EPERM |

**The answer to R3, now measured.** Both statements that the first delivery of this report marked as inference hold on this Mac:

- **The hold works on macOS.** The killed process stays there until the fixture lets the keeper collect it, because `kill(pid, 0)` still finds it. Every subtest with a descendant asserts this under the key `keeper_held_descendant`, and all of them passed in all 31 runs.
- **macOS does not show that process to the identity read.** `getpgid` answers ESRCH for it, and the fixture's stand-in for the identity read uses `getpgid`. So on macOS the cleanup sees no member and has nothing to wait for, the fixture never sees "waiting", and the cases run as they did at `30e38d0`.

So **the extra coverage against M05 is Linux-only.** This last step is inference from the measured answer of `getpgid`: M05 itself did not run on the Mac. The collector runs only on the Linux target host, and both the cloud container and the GitHub runner are Linux, so the place where M05 must be caught is covered. I do not know a mechanism that would make macOS show the process, short of a different stand-in for the identity read on macOS, and that would test the stand-in, not the cleanup.

Two things differed from the brief:

- **The clone's address.** The brief let the run take the address from David's existing clone, and that address names another owner than `evo-agi`. The commit and the tree equal the target, and a commit hash covers the whole content, so the tested bytes are the right ones. **Unknown:** why the address differs. **Inference:** it is the repository's address before it moved to `evo-agi`, which GitHub forwards.
- **The temporary folder is still there.** The tool on the Mac refused to remove it, because the folder had been its working directory, and the brief said not to retry. The folder is `/Users/ds/Repositories/Playground/es-mac-run.ZAVaqe`, about 17 MB, and holds only the clone with nothing changed in it. David removes it with one line. Nothing else on the Mac was changed.

## 8. Failed or skipped validation

- **macOS:** only the three tests, `gofmt`, the search for leftover processes and the question to the system ran there (section 7).
- **Not run on macOS or on the runner:** the mutants, repetitions and sweeps. The runner ran the CI once, green.
- **Not run anywhere: the race detector.** No Go statement changed.
- **Two invalid sweep attempts** (section 6.3), both repeated correctly.
- **Leak checks during the second battery part listed processes of other work** (section 6.4). The quiet check lists none.
- No test of the repaired fixture failed in any valid run with the unchanged collector.

## 9. Other envelope fields

- **Reconnaissance:** I read the audit and its evidence (runner, sketch, sweep script), the fixture, and the collector's `terminate_child`, `signal_group_or_members`, `prove_group_absent`, `own_child_until_proved` and the two document passages on the cleanup hold. No subagents.
- **Implementation decision:** a handshake in the fixture. The product, every bound and every existing assertion stay as they are (section 3).
- **Dependencies changed:** none.
- **Artifact hygiene:** nothing was created in the repository. The FIFO lives in the test's temporary directory beside the pid file. All copies, binaries and logs were outside the repository.
- **Authority, security or protocol widening:** none. No product file changes.
- **Cross-repo impact:** none.
- **Sensitive material:** none read or written. This report and its evidence were scanned with the project's leak scanner before delivery; the result is in the delivery message.

## 10. Provenance

- Recipe `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified before each run.
- Repair flow of section 5.5: the tip `30e38d0` recorded, `git reset --mixed` to the base `f9537a8`, upstream pinned to `origin/trunk_dev`, nothing staged, two runs, identical. Then `git reset --mixed` back to the tip, `git add`, the staged set was the manifest's one path, one commit, clean status, fast-forward push of the topic branch only.
- Reproduced in a fresh clone from GitHub after the push (section 5.3 of the provenance document): identical bytes.
- Textual diff SHA-256 `78a14ba7fdc288e723d97bd24a59e38efe08caae4754d32ccda5be01138bba8f`.
- Canonical manifest SHA-256 `8f245eddd8f3a7b5a6bbb35554b225927bbbeec60d3583dea0514f14b26ca499`, 503 bytes, 1 file. Complete canonical manifest:

```json
{"branch":"claude/project-thread-k69qcw-tls-status-fixture","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"remote_alpha_es_service_tls_status_test.go","sha256":"237355441edf8e7e533492113111538e697359a34b0597aac704dd755566b0f6","size":178685}],"head":"f9537a8680c24bf2108b95ed20ac3724e8939d3a","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"78a14ba7fdc288e723d97bd24a59e38efe08caae4754d32ccda5be01138bba8f","upstream":"origin/trunk_dev"}
```

## 11. Assumptions and unresolved points

- The two statements about macOS were inference in the first delivery. The Mac run confirmed both (section 7). That M05 is not caught on macOS is still inference, from the measured answer of `getpgid`.
- The branch is behind `trunk_dev`. `f62d024` changes only `es/admission/internal/reliablesubmit/sqlite_physical_test.go`, and the runner tested the merge of both. After the audit the branch takes `trunk_dev` by a merge, which makes new bytes, a new manifest and a provenance re-check (section 5.4).
- The mutant and battery runs shared the machine with other work of mine during the loaded parts. That adds load, it does not remove any.

## 12. Confidence

- **Provenance: 0.99.** One file, manifest reproduced in a fresh clone.
- **Validation on Linux: 0.93.** M05 fails in every run on three kinds of evidence, every other mutant is unchanged, the fixture's own mutants show that each part of the rule is needed, and the repetitions cover idle and two load levels.
- **Implementation: 0.9.** The rule follows what the collector does today. A later change of the cleanup's order of steps (for example reaping the fixed child before any second signal is possible) stays covered by the second half of the middle step, but a cleanup with a new shape could need the rule looked at again. The key `no_return_while_member_visible` would then pass without the fixture having seen the wait. That is the reason the probe of section 3.3 is worth repeating when the cleanup changes.
- **macOS: 0.95.** The three tests passed there 31 times. It is one machine with one version of macOS.

## 13. Delivery and effect status

- This file: `/mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/06-repair-pr21.md`. Its SHA-256 is in the reply that delivers it.
- Evidence: `/mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/06-evidence/`, with a `README.md` and a `SHA256SUMS.txt`.
- Effect status: `TOPIC_BRANCH_PUSHED` (fast-forward, `50bb328`) | `DRAFT_PR_UPDATED` https://github.com/evo-agi/Execution-Substrate/pull/21 | `MERGE_NOT_PERFORMED` | `MAC_RUN_PERFORMED` (passed) | `MAC_TEMP_FOLDER_NOT_REMOVED` (needs David, one line) | `INDEPENDENT_AUDIT_OF_NEW_HEAD_NOT_PERFORMED`
