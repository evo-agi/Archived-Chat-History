# IMPLEMENTATION REPORT: Execution-Substrate, the TLS status cleanup fixture no longer waits for the host to reap an orphan

**Outcome: the root cause is found and fixed in the test fixture alone. Three tests of the root package (13 subtests) depended on how fast the host's first process reaps orphaned processes. With the fix a subtest takes 0.2 to 0.6 seconds in place of 2 seconds, and 2,340 subtest runs in the cloud container had no failure. No bound was raised and no assertion changed. The first run of the CI on the pull request is green, and the three tests pass on macOS.**

Written 2026-11-22 by the writer thread of PR #14. The coordinator asked for it after `09-repair.md`, section 7.8, reported the failure. No subagents were used. Independent audit: not performed.

## 1. Identity

| Field | Value |
|---|---|
| Objective | Find the root cause of the timing-dependent failure of `TestRemoteAlphaESServiceTLSStatusCombinedGroupSignalFailureLiveDescendant/term` and fix it properly, as its own test-only change |
| Repository | `evo-agi/Execution-Substrate` |
| Base | `trunk_dev` at `f9537a8680c24bf2108b95ed20ac3724e8939d3a` |
| Topic branch | `claude/project-thread-k69qcw-tls-status-fixture` |
| Topic commit | `30e38d0d901f6510e6fc4b2750e02437a24019cc` |
| Tree | `3d27934ea022a998684b277ebb8f8e4f725fb9da` |
| Pull request | [#21](https://github.com/evo-agi/Execution-Substrate/pull/21) (draft) |
| Manifest (v2) | SHA-256 `eeb9fada97f6f60e0c71701cd4abf7e0d67d431627495bb60d67013331abb4de`, 1 file |
| Final working-tree status | clean after the commit; the branch is pushed and equals its remote |

## 2. The failure

In the fifth repair of PR #14, one of 15 gate runs in the cloud container failed in the step "Test" on this subtest, with `descendant_gone failed`, `leader_reaped failed` and `returned failed`. The test file was the same on both sides of that change, so the failure was not caused by it.

Three tests share the fixture `runRemoteAlphaESStatusGroupFailureCase` in `remote_alpha_es_service_tls_status_test.go`:

- `TestRemoteAlphaESServiceTLSStatusCombinedGroupSignalFailureLiveDescendant` (4 subtests),
- `TestRemoteAlphaESServiceTLSStatusUnresolvedCleanupHold` (3 subtests),
- `TestRemoteAlphaESServiceTLSStatusCleanupRuntimeExceptionHold` (6 subtests).

## 3. Root cause

1. **The fixture left an orphan.** Its stand-in for the collector's fixed child forked one descendant and exited at once. The descendant stayed in the child's process group, with no living parent.
2. **The collector holds its cleanup until the group is empty, and a zombie counts.** `terminate_child` in `scripts/internal/remote_alpha_es_tls_status.py` signals the group and then loops until the only process left in the group is the reserved leader. `read_proc_identity` reads the group and the start time from `/proc/<pid>/stat` and does not look at the state field, so a killed process that nobody has reaped yet still counts as a member. This is the documented design: no retry returns "until group absence and exactly one direct-child reap are proved" (`.docs/system_overview/remote_supported_host_alpha.md`, line 3533, and `remote_alpha_access_contract.md`, line 194). The fixture's stand-in for that read uses `os.getpgid`, which also sees a zombie, so the fixture is as strict as the product here.
3. **Only the adoptive parent can make a killed orphan disappear.** That is the first process of the host, or a subreaper above the test.
4. **In the cloud container that process reaps on a timer.** Process 1 there is `/process_api --firecracker-init`. Measured with 24 orphans that ended 0.1 s apart (`orphan-stagger.log`): they disappeared only at three moments exactly one second apart, and each had stayed between 1.005 s and 1.915 s. So it reaps once a second, and only zombies that are about a second old.
5. **The fixture gives the collector two seconds.** After the pid file appears it waits `thread.join(2)` for the collector's call to return. The cleanup kills the descendant a moment into that window, so the call returns in time only if the zombie then stays less than about 1.9 s.

Result: the test passes or fails by the moment it starts relative to the container's one-second tick. Run by hand at 80 start times spread over two seconds (`sweep-base-term.log`), the unchanged fixture failed at 7 of them: 0.850 to 0.925 s and 1.900 to 1.950 s. The 73 passing cases took 1.21 to 2.11 s, nearly all of it waiting for process 1.

**Inference:** inside one `go test` run the subtests lock themselves to the tick. Each one ends when process 1 reaps, so the next one starts just after a tick, at a start time that passes. Only the first subtest, `term`, starts at an arbitrary moment. This fits the data: `term` took 1.27 to 1.98 s across the runs and is the one that failed, and the twelve others took 1.95 to 2.08 s each.

**Inference:** on a host whose first process reaps when a child ends (systemd, launchd), the zombie is gone within milliseconds and the fixture passes at once. That would explain why the failure was never seen on the GitHub runner or on the project owner's Mac. The run on the Mac fits it (section 6): the first process there is `launchd`, and the unchanged fixture takes 0.34 to 0.76 s per subtest, the same as the fixed one. I did not measure the runner.

## 4. The fix

The descendant keeps a parent of its own. The stand-in child now forks a keeper, and the keeper forks the descendant:

```python
if os.fork()==0:                     # the keeper
    pid=os.fork()
    if pid==0:                       # the descendant, still in the child's group
        signal.signal(signal.SIGTERM,signal.SIG_IGN);close_std();time.sleep(3);os._exit(0)
    os.setpgid(0,0);open(sys.argv[1],'w').write(str(pid));close_std()
    try:os.waitpid(pid,0)
    except OSError:pass
    os._exit(0)
```

- **The keeper reaps the descendant the moment it dies,** with a blocking `waitpid`. The host's first process is no longer involved.
- **The keeper is never a member of the group that the collector cleans up.** It leaves the group with `os.setpgid(0,0)` before it closes its copies of the child's output pipes. The collector starts its cleanup only after both pipes report end of file (`run_fixed`, the loop `while selector.get_map() or not leader_terminal(proc)`), so the cleanup cannot begin while the keeper is still in the group. This matters because several subtests let the real `killpg` through, which would otherwise kill the keeper.
- **The descendant ignores SIGTERM before it closes its pipes.** It closed them first. In that order the cleanup could, in principle, send SIGTERM before the descendant ignored it, and the test would then not reach the SIGKILL step it is about. I never saw that happen.
- **Nothing else changes:** `thread.join(2)`, the wait for the pid file, `CHILD_TIMEOUT`, `CHILD_GRACE` and every assertion are as before. The two-second bound now has more than a second to spare, even in the slowest run measured under load.
- The calls are plain POSIX (`fork`, `setpgid`, `waitpid`). There is no branch on the operating system.

A comment above the fixture says why the keeper exists.

### Options I rejected

| Option | Why not |
|---|---|
| Raise `thread.join(2)` | The coordinator ruled it out, and rightly: the result would still be decided by the host's reaper, only with other numbers |
| Make the probe a subreaper (`PR_SET_CHILD_SUBREAPER`) | Linux only. The tests also run on macOS, so it would need a branch on the operating system |
| Let the fixture's process read count a zombie as gone | The product counts it. The fixture would then be laxer than the code it tests |
| Change the collector to ignore zombies | A product change with its own design question (section 9), outside a test-only change |

## 5. Files touched

| Path | Classification | Summary |
|---|---|---|
| `remote_alpha_es_service_tls_status_test.go` | test | +17/−4: the stand-in child script of one fixture, and a comment above the fixture |

## 6. Validation

### In the cloud container

All runs here: cloud container, user `ci` with an emptied environment, Go 1.26.5, 4 CPUs. "Before" is the unchanged fixture, "after" the fixed one.

`trunk_dev` moved twice while this work ran, so the runs are on three bases. The test file and the collector have the same blobs on all three: test file `b1120bfc…` before and `60275220…` after, collector `6d44f131…`.

| Base | Tree before | Tree after | What ran there |
|---|---|---|---|
| `b8d6bc3` | `df89aa0c…` | `43010f38…` | the hand-run sweeps, N=60 idle and N=40 under load, the "before" runs, two whole root-package runs after and one before |
| `3a5f257` | `9be50458…` | `06312dd6…` | N=30 idle and N=20 under load, one whole root-package run, the mutants of section 7 |
| `f9537a8` (the base of the commit) | | `3d27934e…`, **the tree of the commit** | `gofmt`, build, vet for Linux and macOS, the docs contract test, N=20 idle and N=10 under load |

| Check | Before | After |
|---|---|---|
| Fixture run by hand, mode `term`, 80 start times over 2 s | **7 of 80 fail**, slowest 2.16 s | 80 of 80 pass, slowest 0.22 s |
| The same, mode `hold`, 40 start times | not run | 40 of 40 pass, slowest 0.59 s |
| `go test -count=N` of the three tests, machine otherwise idle | 78 of 78 subtest runs pass (N=6), 1.30 to 2.05 s each | **1,430 of 1,430** pass (N=60, 30 and 20), 0.16 to 0.60 s each |
| The same beside 8 busy processes on 4 CPUs | 78 of 78 pass (N=6), 1.60 to 2.08 s each | **910 of 910** pass (N=40, 20 and 10), 0.21 to 0.87 s each |
| Whole root package, `go test -count=1 .` | 1 run: the three tests pass, 2.0 s per subtest | 3 runs: the three tests pass, 0.17 to 0.56 s per subtest |
| `gofmt -l` on the file, `go build ./...`, `go vet .`, `GOOS=darwin GOARCH=arm64 go vet .`, the docs contract test | | clean, exit 0 each, ok |

The whole root package ends with exit 1 in this container before and after, with the same nine failing tests. They are environment tests (eight are in the CI list of PR #14, and the ninth is fixed by PR #14). Outside them 2,196 test results are `pass` in each run.

"Before" passes in the `go test` rows for the reason given as the first inference in section 3. The hand-run row is the one that shows the defect.

### On the GitHub runner

Run [45079441043](https://github.com/evo-agi/Execution-Substrate/actions/runs/45079441043), job 137384041304, `ubuntu-24.04`, Go 1.26.5, started 22:45:03 UTC, green in 12 m 47 s. It is the first run of the CI on this pull request. The runner checked out the merge of `30e38d0` into `f9537a8`, which has the tree of `30e38d0`. From the job log (`runner-run-45079441043-job-137384041304.log`):

| Step | Result |
|---|---|
| Build, Vet, Vet for macOS | success |
| Check the test gate | `Ran 121 tests in 115.416s`, `OK` |
| Test | `test gate passed: 41 packages, 3 of them with skipped entries (15 entries); 39 tests skipped themselves, all of them listed`. The root package: `ok  execution-substrate 101.702s` |
| Listed tests still fail | `all 15 listed tests still fail on this host, each in a run of its own and in the run of its package` |

The 15 lines `still fails: …` are the same as in run 45075800893 of PR #14. The log has no error or warning annotation.

The three tests have no line in the list. The gate fails when a test fails, when a test that `go test -list` names reports no verdict, and when a test skips itself without a line. **Inference:** the three tests ran and passed on the runner. The log does not print the names of passing tests, so it has no duration for them.

### On macOS

David's Mac (macOS 26.6.2, arm64, first process `/sbin/launchd`), from 22:57:53 to 23:01:35 UTC, in a fresh clone in a temporary folder under `Playground`. David allowed the session on the card at 22:47 and wrote "go ahead" for the second attempt at 22:56. Go 1.26.5 came from the Mac's module cache, forced with `GOTOOLCHAIN=go1.26.5 GOPROXY=off GOFLAGS=-mod=readonly`. Nothing was downloaded, and the build cache was kept inside the temporary folder. `$R` is the pattern for the three tests. (`mac-instructions-2.txt`, `mac-run-report-2.txt`.)

| Step | Command | Result |
|---|---|---|
| a | at `30e38d0`, tree `3d27934e…` confirmed: `go test -count=1 -v -run "$R" .` | exit 0, `PASS`. 13 subtests, 0.34 to 0.74 s each |
| b | `go test -count=30 -run "$R" .` | exit 0, `ok` in 175.1 s. That is 390 subtest runs |
| c | `gofmt -l remote_alpha_es_service_tls_status_test.go` | no output |
| d | `ps` for a leftover `fixed-openssl` process, after b and again after f | no output |
| e | at the base `f9537a8`: `go test -count=1 -v -run "$R" .` | exit 0, `PASS`. 0.34 to 0.76 s each |
| f | `go test -count=5 -run "$R" .` | exit 0, `ok` in 29.4 s |

On the Mac the tests pass with and without the change, at the same speed. That is what the second inference of section 3 expects of a host whose first process reaps at once: the change neither helps nor hurts there. So this run shows that the keeper works on macOS (`fork`, `setpgid`, `waitpid`) and leaves no process behind. It does not show the defect.

A first attempt at 22:47 UTC stopped before any test, as it was told to, because the `go` on the Mac's `PATH` is go1.26.1 (`mac-instructions-1.txt`, `mac-run-report-1.txt`). The temporary folder was removed at the end of the second attempt, and the folder `Playground` still exists. I ended the session on the Mac after its result arrived.

## 7. Do the tests still catch a broken cleanup?

A fixture change can make a test pass for the wrong reason. So I broke the collector's cleanup in eight ways, one at a time, and ran the three tests against each, before and after the fix (`product_mutants.py.txt`, `mutants-base.log`, `mutants-fix.log`).

| Broken version of the collector | Before | After |
|---|---|---|
| P1: after a failed group signal no member is signalled | caught, 11 subtests fail | caught, the same 11 |
| P2: the cleanup does not go on signalling until the group is resolved | caught, 2 | caught, the same 2 |
| P3: a terminal leader counts as a resolved group whatever its members | caught, 13 | caught, the same 13 |
| P4: the member scan takes every process, not only the group's | caught, 13 | caught, the same 13 |
| P5: after the reap a retry signals the numeric group again | caught, 1 | caught, the same 1 |
| P6: a failed scan after the reap is not reported as uncertain | caught, 1 | caught, the same 1 |
| P8: the cleanup reports itself as certain whatever happened | caught, 11 | caught, the same 11 |
| P10: one member whose signal fails ends the member loop | caught, 1 | caught, the same 1 |

Eight of eight are caught on both sides, each by the same subtests. The scratch copies were restored after every mutant and had their trees unchanged at the end.

## 8. Failed or skipped validation

- **The first attempt on the Mac stopped before any test** (Go 1.26.1 on the `PATH`). The second attempt ran everything and passed (section 6).
- **Not run on macOS:** the whole root package, the hand-run sweeps and the mutants. They need the scripts of this work, and the Mac run was kept to the tests themselves.
- **Not run on the runner:** repetitions, sweeps and mutants. It ran the CI once, green.
- **Not run anywhere:** the race detector. The changed lines are a Go comment and the text of a Python script that the test writes. No Go statement changed.
- No test failed in any run of the fixed fixture.

## 9. Observations outside the patch

- **A zombie holds the collector's cleanup, by design, for as long as nobody reaps it.** The loop in `terminate_child` has no end while another member of the group is visible. On the documented target host the first process is systemd, which reaps at once, and the fixed command is `openssl`, which starts no descendants. So I see no defect on the supported host. **Unknown:** whether the collector is ever meant to run where the first process does not reap orphans, for example in a container whose first process is the service itself. There a descendant that the cleanup killed would hold the status lock for good. Whether a zombie should count as absent is a product question for the owner of that contract. This change does not touch it.
- **The other fixture in this file that leaves an orphan** (about line 3253) does not have this problem. Its stand-in for the process read asks `ps` for the state and counts a zombie as gone, and it has no time bound of this kind.
- **The description of PR #14,** which merged today, names this test under "Not included". This change is that follow-up.

## 10. Other envelope fields

- **Reconnaissance:** I read the fixture, the three tests, the collector's `run_fixed`, `terminate_child`, `own_child_until_proved`, `prove_group_absent`, `read_proc_identity` and `scan_group_members`, and the two doc passages named above. No subagents.
- **Implementation decision:** fix the fixture, leave the product and every bound alone (section 4).
- **Dependencies changed:** none.
- **Artifact hygiene:** nothing was created in the repository. All probes, copies and logs were outside it.
- **Authority, security or protocol widening:** none. No product file changes.
- **Cross-repo impact:** none.
- **Sensitive material:** none read or written. This report and its evidence were scanned with the project's leak scanner before delivery. It has 4 findings, all in the two Mac result files and all false matches of its pattern for e-mail addresses: the path of the Go toolchain in the module cache, which has an `@` in it, three times, and the SSH form of the repository URL once. No address, key or number is in them.

## 11. Provenance

- Recipe `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified before each run.
- Taken with HEAD at the base `f9537a8`, nothing staged and the upstream pinned to `origin/trunk_dev`: two runs, identical. Then `git add -A`, the staged set was the manifest's one path, one commit, clean status, push of the topic branch only.
- Reproduced in a fresh clone from GitHub after the push (provenance §5.3): identical bytes.
- Textual diff SHA-256 `3e2d2c14df46996a0804cad01ad578c0aed3bf77c5061f23f90531ea7830d30a`.
- Canonical manifest SHA-256 `eeb9fada97f6f60e0c71701cd4abf7e0d67d431627495bb60d67013331abb4de`, 1 file. Complete canonical manifest:

```json
{"branch":"claude/project-thread-k69qcw-tls-status-fixture","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"remote_alpha_es_service_tls_status_test.go","sha256":"5ccb77ba169afdf466e5f67e655324259efd00854e5a724f5b474a5511cf42b2","size":175283}],"head":"f9537a8680c24bf2108b95ed20ac3724e8939d3a","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"3e2d2c14df46996a0804cad01ad578c0aed3bf77c5061f23f90531ea7830d30a","upstream":"origin/trunk_dev"}
```

## 12. Assumptions and unresolved points

- The two inferences of section 3 are marked there. The first is supported by the durations. The second is supported on macOS by the run there and is not measured on the runner.
- The 1 failure in 15 gate runs is the only failure of this test that I saw in a real `go test` run. The hand-run sweep reproduces the mechanism on demand.
- I did not look for other tests that depend on the host's reaper beyond this file. A search of the root package's test files for `os.fork()` finds only the two fixtures named here.

## 13. Confidence

- **Provenance: 0.99.** One file, manifest reproduced in a fresh clone.
- **Validation: 0.9.** Many repetitions on the host that showed the failure, the mutants, one green run on the runner, and 30 repetitions on macOS.
- **Implementation: 0.9.** The mechanism is measured from both ends: the host's reaper and the fixture's start time.

## 14. Delivery and effect status

- This file: `/mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/01-implementation.md`. Its SHA-256 is in the reply that delivers it.
- Evidence: `/mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/01-evidence/`, with a `README.md` and a `SHA256SUMS.txt`.
- Effect status: `TOPIC_BRANCH_PUSHED` | `DRAFT_PR_OPENED` https://github.com/evo-agi/Execution-Substrate/pull/21 | `MERGE_NOT_PERFORMED` | `INDEPENDENT_AUDIT_NOT_PERFORMED`
