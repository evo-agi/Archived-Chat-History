# MERGE-GATE PROVENANCE RE-CHECK: Execution-Substrate PR #21 after the trunk_dev merge (143167d)

**Result: PASS.** The new head `143167d` is a conflict-free merge of the audited head `50bb328` and `trunk_dev` at `f62d024`. Its change against the new base is byte-identical to the audited change, the writer's new manifest is reproduced, and CI is green on it. The ACCEPT of `07-reaudit-pr21.md` carries over to `143167d`.

Written 2026-11-23 at 02:58Z by the audit thread that wrote `07-reaudit-pr21.md`. Read-only: no edit, commit, push, comment or merge. Evidence: `07a-merge-gate-pr21-evidence/`.

| Check | Result |
|---|---|
| Recipe bytes | `governed_execution_audit_patch_manifest_v2.py` SHA-256 `c08597e2…a1ca`, OK |
| Remote state at 02:53Z | topic branch `claude/project-thread-k69qcw-tls-status-fixture` at `143167d9f04a03c9f7ea30e95482babdeec1271c`; `trunk_dev` at `f62d0245e95e2b411be16511fc1bf9e1da727ce5`; the PR reports head `143167d` and base `f62d024` |
| Shape of the new head | merge commit, parents `50bb328` (audited) and `f62d024`; both are ancestors of the tip |
| Tree | `a6816483cd1c9fcdc17af0c93756780cbe19b62e`, equal to `git merge-tree --write-tree 50bb328 f62d0245`, so the merge added nothing of its own |
| Test file blob | `c6652a34…` at `50bb328` and at `143167d` |
| Textual diff | `git diff f62d0245 143167d` is byte-identical to `git diff f9537a8 50bb328` (SHA-256 `d162c292…5522`, one file, +84/−7) |
| Other direction | `git diff 50bb328 143167d` is byte-identical to `git diff f9537a8 f62d0245` (only `es/admission/internal/reliablesubmit/sqlite_physical_test.go`, trunk_dev's own change) |
| Range-diff | `git range-diff f9537a8..50bb328 f62d0245..143167d`: `30e38d0 = 30e38d0` and `50bb328 = 50bb328`, both equal |
| Manifest | tip checked out, `git reset --mixed f62d0245`, upstream re-pinned to `origin/trunk_dev`, two runs byte-identical: SHA-256 `af7476a4453deda69e3f8e9d87bc4f4233568b6c3d62d9991183864c9f2be651`, 1 path, textual diff SHA-256 `78a14ba7…ba8f`. It equals the writer's new manifest. Against the audited manifest `8f245edd…a499` only the field `head` differs (`f9537a8…` to `f62d0245…`) |
| CI | run [45101781531](https://github.com/evo-agi/Execution-Substrate/actions/runs/45101781531), job 137454048729 "build, vet and test": **success**, 02:43:02Z to 02:55:25Z, on GitHub's merge `1a5e73c` of `143167d` into `f62d024` (its tree is the tip's, because the base is an ancestor of the tip). Root package `ok` in 111.6 s; "test gate passed: 41 packages, 3 of them with skipped entries (15 entries); 39 tests skipped themselves, all of them listed". All 50 TLS status FAIL lines come after the gate line, in the step that expects the listed tests to fail, and belong only to the three tests that need another environment |

**What this does not re-check:** no test was re-run here. The audited bytes are unchanged, so the runs of `07-reaudit-pr21.md` stand. `f62d024` was already part of the merge that CI tested for `50bb328` (run 45093838877).
