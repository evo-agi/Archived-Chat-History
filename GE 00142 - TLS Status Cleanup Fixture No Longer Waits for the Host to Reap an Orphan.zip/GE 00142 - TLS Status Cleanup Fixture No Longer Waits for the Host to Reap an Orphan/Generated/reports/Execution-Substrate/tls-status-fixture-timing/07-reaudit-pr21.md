# NARROW RE-AUDIT REPORT: Execution-Substrate PR #21, repair of A2-1 (the keeper holds the killed descendant until the fixture has seen the cleanup wait)

**Verdict: ACCEPT.** The repair at `50bb328` restores what A2-1 asked for and does it without a clock. Mutant M05 (a cleanup that trusts a delivered SIGKILL) is caught in every run I made: 144 of 144 runs of the three affected subtests in four `-count` batches and 80 of 80 separate test processes, idle and under checked load, always in the three subtests where the group SIGKILL succeeds, with the labels `descendant_gone` and `no_return_while_member_visible`. Every other mutant of mine keeps exactly its verdict and its failing subtests from the audit of `30e38d0`. The unchanged collector passed 1,300 of 1,300 repeated subtest runs and 180 of 180 separate runs, idle and under checked load. I found no new hang or leak: the FIFO is held only by the fixture and the keeper, every abort path I forced (exception, SIGKILL, hang until the Go timeout, and a SIGKILL before the cleanup started) left no live process behind, and every wait in the fixture is bounded. The writer's judgement that the extra coverage is Linux-only is right, and it is enough: the collector runs only on Linux, and the GitHub runner is Linux. No finding. Observations O7-1 to O7-6 need no action from this audit.

Written 2026-11-23 by the audit thread that wrote `02-audit.md`, as the narrow re-audit that report pre-committed. No subagents were used (section 2).

## 1. Audit target

| Field | Value |
|---|---|
| Repository | `evo-agi/Execution-Substrate` |
| Pull request | [#21](https://github.com/evo-agi/Execution-Substrate/pull/21), draft, head `50bb328128b20aa82edb3ab1f886490bccb8b070`, parent `30e38d0` (the audited head), fast-forward |
| Base | `trunk_dev` at `f9537a8680c24bf2108b95ed20ac3724e8939d3a` |
| Topic branch | `claude/project-thread-k69qcw-tls-status-fixture` |
| Tree | `fb6bea9798b2d64ac724c5d4f05c3f8813457745` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified before each run |
| Canonical manifest | SHA-256 `8f245eddd8f3a7b5a6bbb35554b225927bbbeec60d3583dea0514f14b26ca499`, 1 path, upstream `origin/trunk_dev` |
| Textual diff | SHA-256 `78a14ba7fdc288e723d97bd24a59e38efe08caae4754d32ccda5be01138bba8f` |
| Changed path | `remote_alpha_es_service_tls_status_test.go`, blob `60275220…` (at `30e38d0`) to `c6652a34…`, +71/−7. Whole range from the base: +84/−7, the same single file |
| Collector (unchanged) | `scripts/internal/remote_alpha_es_tls_status.py`, SHA-256 `10a0d13e…b008`, the same bytes as at the base and at `30e38d0` |
| Repair report | `06-repair-pr21.md`, revised in place (section 7 only), SHA-256 `0a993f9db0b6ab07fb7cd35ab8c1e5abd36cde569250f44cda2dd4f2a8fa13c9`, verified. The first delivery (`07d3a49f…9a76`) is superseded. `06-evidence/SHA256SUMS.txt` (SHA-256 `0cce4ac4…ec45`): 80 of 80 entries match |
| CI | run [45093838877](https://github.com/evo-agi/Execution-Substrate/actions/runs/45093838877), job "build, vet and test", success, on the merge of `50bb328` into `trunk_dev` at `f62d024` |

## 2. Audit posture

- Read-only toward the repository and GitHub. No edit, commit, push, comment, review or merge.
- All runs used scratch exports outside the audited clone: the tip (`/opt/audit/fix2`), the audited head `30e38d0` (`/opt/audit/fix`), copies of the tip for mutants and for audit-only variants of the fixture. The audited clone was used only for the manifest and for `git show`.
- Tests ran as the unprivileged user `ci`, `umask 022`, emptied environment, default signal dispositions (`run-as-ci.sh.txt`), Go 1.26.5, Python 3.13.18, 4 CPUs, kernel 6.18.44. PID 1 of this container reaps orphans on a one-second tick, which is the condition that made the original flake.
- A test binary reads the collector of the tree it was built in, so each mutant was applied in that tree and the tree was restored and hash-checked after each one (the runner asserts `10a0d13e…` after every restore).
- **No subagents.** The audit protocol (section 13.2, step 3) asks for read-only audit subagents. I covered the perspectives myself: contract and test adequacy (section 4), concurrency and process behaviour (section 5), portability (section 4.3). The delta is one fixture in one test file, and standing session rules limit subagents to when they are asked for.

## 3. Provenance reproduction

`provenance-r21.sh.txt` (section 5.3 of the provenance guide), run at opening (about 01:52Z) and closing (02:36Z).

| Step | Result |
|---|---|
| Recipe bytes | `c08597e2…a1ca`, OK at opening and closing |
| Pushed tip equals reported tip | yes, `50bb328` |
| Base is an ancestor of the tip | yes |
| Tip tree | `fb6bea97…` |
| Manifest, two runs at opening | identical, `8f245edd…a499` |
| Manifest, two runs at closing | identical, `8f245edd…a499`, byte-identical to the opening run. The remote tip was still `50bb328` and `trunk_dev` still `f62d024` at 02:36:33Z (`git ls-remote`) |
| Writer's manifest file and diffs | `06-evidence/provenance/manifest-head-f9537a8-tip-50bb328.json` has the same SHA-256. `repair-30e38d0-to-50bb328.diff` and `whole-range-f9537a8-to-50bb328.diff` are byte-identical to `git diff` of the same ranges |
| Runner log | `06-evidence/runner/…137429137639.log` has 1,150 lines, equal to the job log's original length from the GitHub API, and its tail matches |

**Result: provenance reproduced, no mismatch.**

## 4. The repair against R1 to R3 of `02-audit.md`

### 4.1 R1: the keeper keeps the killed descendant visible

R1 asked for a fixed time. The writer built a handshake instead: the keeper blocks on a FIFO and reaps only when the fixture closes its end, and the fixture closes it only after three observed events in order (a SIGKILL delivered to the descendant, the cleanup past the bounded wait behind it, then two identity reads that find the descendant in the group). A cleanup that returns before the fixture lets go is caught at the moment of return, under the fixture's lock, by checking whether the descendant is still in the group. That check needs no clock, because the descendant cannot leave while the keeper is blocked.

**I accept this deviation from the letter of R1.** It meets the intent (the killed member stays visible until the cleanup has been seen waiting for it) and removes the one weakness of the fixed time (a result that depends on how long a step takes). The price is a shorter hold past the bounded wait than the 0.3 s of my sketch, which section 5.5 measures. It adds two result keys (`keeper_held_descendant`, `no_return_while_member_visible`) and one bounded wait (section 5.6), changes no existing bound or assertion, and touches only the fixture text and the comment above it. I read the comment against the code: it describes the order of events, the reads that do not count, and the macOS case correctly.

### 4.2 R2: M05 caught, the other mutants unchanged, the flake still gone

**My mutants, with my unchanged runner** (`mutants.py.txt`, the same file as in `02-audit-evidence`):

| Mutant | `30e38d0` (from `02-audit.md`) | `50bb328`, idle, `-count=3` |
|---|---|---|
| M01 | caught, 33 of 39 | caught, 33 of 39, same subtests |
| M02 | survives | survives |
| M03 | caught, 6 of 39 (`hold`, `scan_hold`) | caught, 6 of 39, same |
| **M05** | **survives, 0 of 39** | **caught, 9 of 39**: all runs of `term`, `scan_plain_once`, `post_reap_scan_once` |
| M06, M07 | survive | survive |
| M08 | caught, 39 of 39 | caught, 39 of 39 |
| M10 | caught, 3 of 39 (`poll_hold`) | caught, 3 of 39, same subtest; the new label is added |
| M12, M16 | survive | survive |
| M17 | caught, 39 of 39 | caught, 39 of 39 |

**M05 in more runs:**

| Condition | Subtest runs failing | Where |
|---|---|---|
| idle, `-count=3` | 9 of 39 | the three subtests, every run |
| idle, `-count=30` | 90 of 390 | the three subtests, every run |
| 8 CPU burners, `-count=10` | 30 of 130 | the three subtests, every run |
| heavy load, `-count=5` | 15 of 65 | the three subtests, every run |
| separate runs of `term`, idle | 40 of 40 runs fail | |
| separate runs of `term`, 8 CPU burners | 40 of 40 runs fail | |

Every M05 failure carries exactly the labels `descendant_gone` and `no_return_while_member_visible`. These numbers agree with the writer's section 5.1 and 6.2 (30 of 130, 9 of 39, 270 of 270 separate runs).

**The unchanged collector, repeated** (`reps.sh`, the three tests, 13 subtests):

| Condition | Subtest runs | Failed | Slowest subtest |
|---|---|---|---|
| idle, `-count=40` | 520 | 0 | 0.72 s |
| 8 CPU burners, `-count=40` | 520 | 0 | 0.92 s |
| heavy (16 CPU, 4 switch, 2 iomix), `-count=20` | 260 | 0 | 2.35 s (`scan_hold`) |

**Separate runs of the first subtest** (`sweep_gotest.sh.txt`, one test process per trial, random start phase against PID 1's reap tick): idle 100 of 100 pass, 8 CPU burners 80 of 80 pass. At the base this sweep failed 15 of 310 (`02-audit.md` section 4.2), so the flake fix of `30e38d0` still holds.

Load was checked at the start and stop of each loaded phase (`load-verification.log`): 8 CPU burners: 9 `stress-ng` processes at start and stop, load average 0.81 at the start and 8.58 at the stop; heavy: 65 processes at start and stop, load average 9.27 at the start and 25.78 at the stop. A leak check after each phase found no fixture process and no zombie (`leakcheck.log`).

### 4.3 R3: macOS, and the Linux-only judgement

The Mac run (`06-evidence/mac-run-report-3.txt`, which I read) passed 13 of 13 subtests once and 390 subtest runs in 30 repeats, with no leftover process, and measured that a killed, unreaped child answers `getpgid` with ESRCH, `kill(pid, 0)` with success and `killpg(pgid, 0)` with EPERM. The commit and tree there equal the target. That agrees with how I understand the XNU process lookup (a zombie is not found by the lookup behind `getpgid`, while `kill` falls back to zombies), which is inference from memory, not checked against source here.

I checked the consequence on Linux with an audit-only variant of the fixture (`make_variants21.py.txt`, variant `macos_emul`) whose stand-in for `getpgid` answers ESRCH for a process in state `Z`, in both places the fixture uses it:

| Variant | Unchanged collector | M05 |
|---|---|---|
| `macos_emul`, `-count=3` | 39 of 39 pass | **39 of 39 pass (M05 not caught)** |

So on a host that hides a dead, unreaped process from `getpgid`, the cleanup has nothing to wait for, the fixture never sees "waiting", and the case runs as at `30e38d0`, with `keeper_held_descendant` still checked. **The writer's judgement is right: the extra coverage is Linux-only.** It is sufficient: the collector runs only on the Linux target host, CI runs on Linux, and the Mac is a developer machine. I do not see a proper way to make macOS show the process to the stand-in without testing the stand-in instead of the cleanup, which is the writer's point too.

## 5. New hangs, leaks or races from the handshake

### 5.1 Who holds the FIFO

Audit-only variant `fdcheck`: at the moment the fixture has seen "waiting", it lists every open descriptor on the host that points to the FIFO, with its flags. In all 13 subtests (`fifo-holders-*.json`) there are exactly two: the fixture's write end (flags `02100001`, close-on-exec, write) and the keeper's read end (`02100000`, close-on-exec, read, blocking). `waiting` was true in all 13. The descendant is forked before the keeper opens the FIFO, the unrelated sleeper is started before the FIFO exists, and both descriptors are close-on-exec, so no third process can hold the write end. The keeper's read therefore ends exactly when the fixture closes its end or dies.

### 5.2 Fixture abort paths

Audit-only variants that abort the fixture. The first three abort where the keeper is blocked and the killed descendant is held; `early_kill` aborts before any cleanup signal, while the descendant is alive. Each ran the `term` subtest in its own temporary directory, and I listed every process whose command line carries that directory after the test ended (`runvariants.sh.txt`, `variants.log` at +0.5 s and +4 s; `runvariants2.sh.txt`, `variants2.log` at +0.3 s, +1.5 s and +4 s, also listing every zombie on the host):

| Variant | Go test result | Wall time | Left soon after (+0.5 s; +0.3 s and +1.5 s for `early_kill`) | Left at +4 s |
|---|---|---|---|---|
| `abort_raise`: the fixture raises after `seen.wait` | FAIL, `exit status 1` | 0.30 s | none | none |
| `abort_kill`: the fixture SIGKILLs itself there | FAIL, `signal: killed` | 3.09 s | none | none |
| `abort_hang`: the fixture sleeps 100 s there | FAIL, `context deadline exceeded` | 8.01 s | none | none |
| `early_kill`: the fixture SIGKILLs itself right after the pid file appears, before any cleanup signal (head) | FAIL, `signal: killed` | 3.08 s | none alive; two orphan zombies (the unrelated sleeper and the keeper) wait for PID 1's reap tick | none |
| `early_kill` on `30e38d0` (comparison) | FAIL, `signal: killed` | 3.08 s | none alive; the same two orphan zombies | none (gone by +1.5 s) |

The 3.09 s of `abort_kill` is the unrelated 3-second sleeper, which holds the probe's output pipe after the probe dies, so Go's `CombinedOutput` waits for it. That is the same at `30e38d0` (observation O7-3). In `early_kill` the descendant, which nobody killed, ends on its own 3 s after it starts, at about the moment the Go test returns, so nothing is alive at +0.3 s on either side; the keeper and the sleeper end as orphans that PID 1 reaps on its tick. Head and `30e38d0` behave the same on this path.

### 5.3 Why the keeper cannot block for ever

- The keeper opens the read end with `O_NONBLOCK` and then makes it blocking. Opening never waits for a writer, and a read on a FIFO with no writer returns end-of-file at once. So a fixture that closed or lost its end before the keeper opened the FIFO cannot strand the keeper either.
- After end-of-file the keeper calls `waitpid` on the descendant. The descendant ends by itself 3 s after it starts, so that wait is bounded even when no cleanup ever killed it (`early_kill`).
- `release()` runs under a lock and closes the write end once. It is called after "waiting", after the join, and in `finally`; a fixture that dies has it closed by the kernel.
- Every wait in the fixture is bounded: 2 s for the pid file, 2 s for `seen`, 2 s for the join, 2 s for the sleeper. The collector thread is a daemon thread, so it cannot keep the interpreter alive. Inside the Go test the 8 s context bounds the whole probe.

### 5.4 Races in the stage machine

- `stage`, `looks` and `waiting` change only on the collector's thread (the stand-ins for `killpg`, the member signal and the identity read all run there). The main thread reads them only after `seen` is set.
- `early` is judged when `run_fixed` returns, under the same lock as `release()`. A cleanup that returns before the fixture lets go is caught by `early` (the descendant is still in the group, because the keeper is still blocked). A cleanup that returns between `seen.set()` and the main thread's check is caught by `still`. Both checks are on the same key, so neither ordering can make a broken cleanup pass.
- A correct cleanup cannot return in that gap, because the descendant stays in the group until the fixture lets go. Under load no run of the unchanged collector failed (section 4.2), which is the measured side of this.
- The reads inside the bounded wait do not count. Section 3.2 of the writer's report shows with fixture mutant F2 that counting them would let M05 pass, and with F3 that one read is not enough. I did not re-run F0 to F4; the logic matches the code.

### 5.5 A cleanup that waits a little and then trusts the SIGKILL (the writer's section 3.4)

The handshake measures rounds, not time: it lets go after two reads of the descendant in the group past the bounded wait, and the keeper reaps at once. A cleanup that waits at least that long and then gives up while the member is still visible passes. I measured two such mutants (`make_variants21b.py.txt`, `runvariants2.sh.txt`, `runvariants3.sh.txt`, `variants2.log`, `variants3.log`):

| Mutant | What it does | Result at `50bb328` |
|---|---|---|
| M18 | the hold loop gives up after 3 rounds, whatever the signals did, and the post-reap proof gives up after 3 scans | **caught**: 6 of 39 (`-count=3`) and 20 of 130 (`-count=10`), all runs of `hold` and `scan_hold`, labels `descendant_gone`, `member_fallback`, `no_return_while_member_visible` |
| M18b | M05's hold loop (stops after one SIGKILL that raised no error), with a post-reap proof that gives up after 3 scans instead of 1 | **survives**: 39 of 39 and 130 of 130 pass |

M18 is caught by the older `hold` subtests: while the signals fail, it gives up before the fixture opens the gate. M18b is the exact class the writer names in section 3.4 of the repair report: it trusts a delivered SIGKILL, but waits two more reads first. The handshake lets go after two reads past the bounded wait, the keeper reaps at once, and M18b's third scan finds the group empty. Inference: it survived at `30e38d0` too, because there the keeper reaped at once, and the fixed 0.3 s of my sketch would have caught it.

Two things keep this from being a finding. First, M18b needs two regressions at once: the hold loop and the proof must both stop waiting. Each half alone leaves the other half waiting, which is why M06 and M07 survive harmlessly (O2-1), and a single plausible regression such as a deadline added only to the post-reap proof leaves the hold loop doing the waiting. Second, any finite test has a limit of this kind; a longer fixed hold only moves it.

The writer states this limit in section 3.4, and M18b confirms it. Observation O7-1.

### 5.6 The new 2-second bound

After the cleanup starts, the fixture waits up to 2 s to see either "waiting" or a return. On a host too slow for it, a correct cleanup would not be let go, the join would time out and the run would fail on `descendant_gone` and `returned`: a false failure, never a false pass. The slowest whole subtest in my runs took 2.35 s including the interpreter's start and the 0.35 s hold before the gate (`scan_hold` under heavy load, load average up to 25.8), and it passed, so the part that the 2 s bound covers finished inside it; the writer's heaviest load gave 2.04 s for a whole subtest. The bound sits beside two older 2-second bounds that behave the same way. Observation O7-2.

## 6. Other checks

- The repaired three tests and the root package ran on the GitHub runner: the root package is not on the gate's skip list, it passed, and the gate line reports 41 packages with every self-skip listed (`06-evidence/runner/`, checked against the API).
- `gofmt` and `vet` were not re-run by me: no Go statement changed, and the runner ran both. I checked the line range of every hunk of the repair diff: all fall inside the comment above the fixture (head lines 2797 to 2826) or inside the probe's raw string constant (2828 to 3006), which also holds the keeper's script.
- The pid file is written by the keeper in two steps (create, then write), so a reader could see it empty for a moment. This is unchanged from `30e38d0`, and a reader that hit it would raise in the collector's thread and fail the run, not pass it. It never happened in any of my runs.

## 7. Findings

None.

### Observations (no action required by this audit)

- **O7-1. Rounds, not time.** A cleanup whose hold loop trusts a delivered SIGKILL and whose proof gives up after a few scans passes (section 5.5, M18b, 169 of 169). It needs both halves to regress at once, and it is the documented limit of section 3.4 of the repair report. If the coordinator wants that class covered, the cheapest proper way is to let go only after more reads past the bounded wait (a correct cleanup never returns while the member is held, so a longer hold cannot cause a false failure within the 2 s bound). That is a choice about test strength, not a defect of this repair.
- **O7-2. Margin of the 2-second bounds.** No run failed. The slowest whole subtest under heavy load took 2.35 s (`scan_hold`, load average up to 25.8). A much slower host would fail, not pass.
- **O7-3. The unrelated sleeper holds the probe's output pipe for up to 3 s after a probe that dies.** Pre-existing, harmless, and only visible on an abort.
- **O7-4. Merge gate.** `trunk_dev` is at `f62d024` and the PR is behind. Updating the branch makes new bytes, so the gate follows provenance section 5.4: new manifest, range-diff, re-check. `f62d024` touches only `es/admission/internal/reliablesubmit/sqlite_physical_test.go`. PR #22's base root-package run hit this very flake (its report, section 6), which is one more reason to merge this fix first.
- **O7-5. The Mac's temporary folder** `/Users/ds/Repositories/Playground/es-mac-run.ZAVaqe` is still there (repair report section 7). It holds only an unchanged clone.
- **O7-6. My own invalid runs, kept and not counted.** I stopped a first `-count=10` mutant run because it was far too slow (M01 alone took 431 s; its one completed line is kept as `partial-mutants-fix2-count10-idle-M01-only.log`, and it agrees with the `-count=3` result). The M05 run chained after it had already applied M05 when I stopped it, so it produced nothing and left the tree's collector mutated; I restored the collector from `git show 50bb328:…` and checked its SHA-256 (`10a0d13e…`) before any further run (`invalid-mutants-fix2-M05-count30-interrupted.log`). All counted runs started from the verified collector, and the runner verifies it before and after each mutant.

## 8. Validation assessment

| Writer's claim | Re-checked here? | Result |
|---|---|---|
| M05 caught 30 of 130 and 9 of 39 in the auditor's runner | yes | identical, plus 90 of 390 idle and runs under load |
| Every other mutant keeps verdict and failing subtests | yes, my 11 | confirmed |
| Writer's 8 product mutants killed on both sides | not re-run | read only |
| Fixture mutants F0 to F4 | not re-run | the logic matches the code (section 5.4) |
| 1,560 of 1,560 repetitions, 270 of 270 separate runs | not re-run as such | my own 1,300 of 1,300 and 180 of 180, all pass |
| "Waiting" seen in all 13 subtests | yes, independently (`fdcheck`) | confirmed, 13 of 13 |
| The FIFO cannot strand the keeper | yes | confirmed by holders, abort variants and code (section 5) |
| Linux-only coverage (macOS `getpgid`) | yes, by emulation; Mac report read | confirmed |
| Runner green on the merge with `f62d024` | yes | log identical, success |
| Provenance, one file | yes | reproduced |

Not run by me: macOS, the race detector (no Go statement changed), the full CI gate, the whole root package (the runner ran it on the merge, and the change is one fixture).

## 9. Sensitive material

None read or written. I scanned this report and `07-reaudit-pr21-evidence/` with the project's leak scanner before delivery (result in the delivering reply).

## 10. Confidence

- **Provenance: 0.99.** Reproduced at opening and closing; the writer's files are byte-identical.
- **A2-1 repaired on Linux: 0.95.** M05 fails in every run, idle and under two load levels, by a check that needs no clock.
- **No new hang or leak: 0.93.** Four forced abort paths, the FIFO holders, and the bounded waits. A failure of the Go process itself (killed from outside) leaves the probe to finish on its own bounded waits, which I reasoned but did not force.
- **Linux-only judgement: 0.95.** Measured on the Mac by the writer's run and emulated here.

## 11. Effect status and delivery

- Effect status: `REPAIR_NOT_PERFORMED` | `COMMIT_NOT_PERFORMED` | `PUSH_NOT_PERFORMED` | `PR_NOT_COMMENTED` | `MERGE_NOT_PERFORMED`.
- This file: `/mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/07-reaudit-pr21.md`, SHA-256 in the delivering reply.
- Evidence: `/mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/07-reaudit-pr21-evidence/`, with `README.md` and `SHA256SUMS.txt`.

**Final verdict: ACCEPT** (no finding; merge gate per O7-4).
