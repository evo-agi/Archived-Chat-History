PR 21: the Mac run of 50bb328 is done and passed, so the fresh audit of 50bb328 can start. Nothing in the branch changed.

Result (David's Mac, macOS 26.6.2, arm64, Go 1.26.5): commit 50bb328128b20aa82edb3ab1f886490bccb8b070 and tree fb6bea9798b2d64ac724c5d4f05c3f8813457745 confirmed. The three tests pass once verbose (13 of 13 subtests, no skip) and 30 times in a row (390 subtest runs, 175.6 s). gofmt is clean and no process was left.

Answer to R3, now measured: for a killed child that nobody has collected yet, kill(pid,0) succeeds, getpgid gives ESRCH and killpg(pgid,0) gives EPERM. So the keeper's hold works on macOS, but the cleanup sees no member there, and the extra coverage against M05 is Linux-only. That last step is inference from the getpgid answer, because M05 did not run on the Mac.

Report revised in place: /mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/06-repair-pr21.md, new sha256 0a993f9db0b6ab07fb7cd35ab8c1e5abd36cde569250f44cda2dd4f2a8fa13c9 (was 07d3a49f…9a76). Only section 7 and the lines that refer to it changed. The result is 06-evidence/mac-run-report-3.txt, and SHA256SUMS.txt now lists 80 files (sha256 0cce4ac486c76d4b67b33a2d0bafd7ab3d99b523cf24ea8bf0c78b10f2d3ec45). Leak scan: 3 false matches in the Mac file (the SSH address of the clone and two toolchain paths). The PR 21 description is updated.

Two side notes. The temp folder on the Mac was not removed, because the tool there refused it. I'm asking David to run one line, and Remote Control is stopped. And David's existing clone on the Mac has an origin address under another owner than evo-agi. The hashes match, so the tested bytes are right. Unknown why. Inference: it is the address before the repository moved, which GitHub forwards.

PR 22: pushed as 39a016cca06dfb10f8b4b64c9b614c8f20aaa1de. Its CI run is still going. Report 05 follows when it ends.
