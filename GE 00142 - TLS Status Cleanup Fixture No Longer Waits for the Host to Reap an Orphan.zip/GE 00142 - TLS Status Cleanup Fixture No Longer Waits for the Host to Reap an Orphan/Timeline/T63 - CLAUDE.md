[PR 21](https://github.com/evo-agi/Execution-Substrate/pull/21) is merged into trunk_dev as 110d377. The flaky TLS status test now waits for real evidence instead of a timer, and the merged code matches what the audit accepted. The collector fix (PR 22) also passed its re-audit and merges next.

STATUS: WORKING (PR 22 merge, PR 20 small repair, PR 19, PR 13 split, MA alert; nothing needed from you)
