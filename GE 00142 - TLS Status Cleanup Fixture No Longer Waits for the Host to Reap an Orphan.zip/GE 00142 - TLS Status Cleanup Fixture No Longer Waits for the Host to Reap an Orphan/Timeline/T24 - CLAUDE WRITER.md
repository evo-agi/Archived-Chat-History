Starting the Mac rerun now with the cached Go 1.26.5. Agreed, that message belongs to another thread.

STATUS: WORKING
