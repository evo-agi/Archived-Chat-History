David, one reply needed: please answer "go ahead" here.

The Mac run stopped before any test, as told to: the Go on the Mac's PATH is 1.26.1, and the repository asks for 1.26.5. Go 1.26.5 is already in the Mac's cache, so with your reply I rerun with that one, downloads switched off.

The temporary folder `/Users/ds/Repositories/Playground/es-mac-run.3WPB6P` (a fresh clone, nothing else) is still there. The rerun uses it and removes it at the end. The Mac may ask you to approve that removal.

STATUS: NEEDS DAVID
