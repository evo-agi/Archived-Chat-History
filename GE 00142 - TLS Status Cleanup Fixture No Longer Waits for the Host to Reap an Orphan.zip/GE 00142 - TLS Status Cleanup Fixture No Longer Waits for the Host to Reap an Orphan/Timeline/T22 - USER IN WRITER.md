Coordinator may have forwarded one/two too many messages, especially this:


```
Deleted.

Please verify.

One thing you may want to keep in mind is that I'm not a careful person, nor do I pretend to be. I can only try to be careful and not mess things up, so, for things you can do deterministically, you should just do it. 
```


Unless I forgot something, it doesn't belong to this thread.

And, back to what you are doing right now, Coordinator wants me to say "go ahead."
