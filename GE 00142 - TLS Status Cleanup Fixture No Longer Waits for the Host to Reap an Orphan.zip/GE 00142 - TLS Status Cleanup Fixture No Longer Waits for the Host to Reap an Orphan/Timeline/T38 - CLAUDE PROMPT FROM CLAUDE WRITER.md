PR 21 repair is pushed and ready for the Mac run and a fresh audit.

Head 50bb328128b20aa82edb3ab1f886490bccb8b070 (parent 30e38d0, fast-forward), tree fb6bea9798b2d64ac724c5d4f05c3f8813457745, base f9537a8. Manifest v2 8f245eddd8f3a7b5a6bbb35554b225927bbbeec60d3583dea0514f14b26ca499 (1 file), reproduced from a fresh clone. CI run 45093838877 is green on the merge with f62d024.

Report: /mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/06-repair-pr21.md, sha256 07d3a49fec4c24d0c4131c7859412a5d1abf0b6cc7d056b7eaaec86bb70d9a76. Evidence in 06-evidence/ (79 files, SHA256SUMS.txt sha256 7e75399a…1425). Leak scan: 0 findings. I named it 06 because 05 is reserved for the PR 22 repair.

Design: a handshake, no fixed delay. The keeper blocks on a FIFO and reaps only when the fixture closes it. The fixture lets go after a delivered SIGKILL, then a further signal or the fixed child's reap, then two identity reads that find the descendant in the group. The cleanup must then not have returned and must hold its lock.

Results: M05 fails 30 of 30 in the mutant runner and 270 of 270 separate runs, idle and loaded. All other mutants (the auditor's ten and my eight) keep their verdicts and failing subtests. 1,560 of 1,560 repetitions and 270 of 270 separate runs pass. Two sweep attempts were invalid, are kept and were redone (report section 6.3).

Mac run (R3): the brief for David's Mac is 06-evidence/mac-instructions-3.txt. It needs the usual temp folder under Playground, Go 1.26.5 from the module cache, about 2 minutes. Inference until it runs: the extra coverage is Linux-only, because macOS does not show a killed, unreaped process to getpgid.

PR 22: reader, documents and tests are done, 39 of 39 mutants caught. The auditor's stress probes are running now. Then provenance, push and 05-repair-pr22.md. The containment PR follows.
