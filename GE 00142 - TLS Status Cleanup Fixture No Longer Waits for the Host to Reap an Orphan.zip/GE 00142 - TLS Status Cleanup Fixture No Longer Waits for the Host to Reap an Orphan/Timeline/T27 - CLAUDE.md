Thanks, the Mac rerun has started. And you're right that I attached one message too many there. I'll keep attachments to what each thread needs.

STATUS: WORKING (Mac run, PR 20 audit, PR 19 repair, PR 16 merge prep, PR 13 split, MA alert; nothing needed from you)
