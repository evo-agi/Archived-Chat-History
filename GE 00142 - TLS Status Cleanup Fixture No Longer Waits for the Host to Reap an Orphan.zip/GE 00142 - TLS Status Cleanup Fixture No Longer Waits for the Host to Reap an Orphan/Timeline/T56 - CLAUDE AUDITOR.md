**PR 21 re-audit: ACCEPT, no finding.** The repair at `50bb328` fixes A2-1 without relying on a timer. [07-reaudit-pr21.md](/mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/07-reaudit-pr21.md) has sha256 `10de83911a89bdd9b1dcc69d68861c0ea1c0b7310e06905db641cf229a527abe`. Its evidence folder has 60 files, and the SHA256SUMS file's own sha256 is `24aee247…37c5`. I audited against the revised writer report (`0a993f9d…`).

- **Same bytes as reviewed:** the manifest `8f245edd…a499` matched at the start and at the end of the audit. The writer's diffs and manifest are byte-identical to mine.
- **M05 is caught every time:**
  - 144 of 144 runs of the three affected subtests, idle, with 8 CPU burners, and at load average 25.8.
  - 80 of 80 runs, each in its own test process.
  - All other mutants keep their old verdicts.
- **No false failures:** the unchanged collector passed 1,300 of 1,300 repeated runs and 180 of 180 separate runs.
- **No new hang or leak:** only the fixture and the keeper hold the FIFO. I forced four abort paths, and none left a live process behind.
- **Linux-only coverage is correct and enough:** my macOS emulation confirms the writer's claim, and the collector and CI both run on Linux.

There are six observations, and none needs action. The main one is O7-1: a cleanup that trusts the SIGKILL and gives up after three scans still passes. That is the limit the writer documented, and it would take two regressions at once to reach it.

Next for PR 21 is the merge gate: merge `trunk_dev` into the branch, then a new manifest and a provenance re-check. Leak scan: 0 findings. No subagents were used.

I've started the PR 22 re-audit. Provenance matches, and the pidfd_open fallback cases all fail closed. The root stress probes are running now.

STATUS: WORKING
