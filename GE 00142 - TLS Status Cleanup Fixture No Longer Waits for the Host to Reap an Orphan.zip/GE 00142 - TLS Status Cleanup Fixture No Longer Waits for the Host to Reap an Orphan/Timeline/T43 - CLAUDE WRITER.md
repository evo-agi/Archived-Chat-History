Thank you. I'm starting the short test run of PR 21's new head on your Mac now.

STATUS: WORKING
