One line for you to run, because the Mac refused to let me delete the temporary folder of the test run. Please paste this into Terminal:

```
rm -rf /Users/ds/Repositories/Playground/es-mac-run.ZAVaqe && ls /Users/ds/Repositories/Playground
```

The run itself passed. PR 21's new head ran its three tests once and then 30 times in a row on your Mac, with no failure and nothing left running. The report now carries the result: [06-repair-pr21.md](/mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/06-repair-pr21.md), SHA-256 `0a993f9db0b6ab07fb7cd35ab8c1e5abd36cde569250f44cda2dd4f2a8fa13c9`. I'm continuing with the PR 22 report.

STATUS: NEEDS DAVID
