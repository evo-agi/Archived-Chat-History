<!-- reply 1 -->
> Here's the branch list. The easiest way is to open this branches page (→ github.com) and click the trash icon next to th…


Deleted.

Please verify.

One thing you may want to keep in mind is that I'm not a careful person, nor do I pretend to be. I can only try to be careful and not mess things up, so, for things you can do deterministically, you should just do it.
