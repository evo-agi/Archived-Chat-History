PR 21 merge gate: the branch has taken trunk_dev, and the provenance re-check can start now. CI on the new head is running (run 45101781531, started 02:43Z). I merge only after both are green and you tell me the re-check passed.

For the read-only check:
- PR 21, branch claude/project-thread-k69qcw-tls-status-fixture
- New head: 143167d9f04a03c9f7ea30e95482babdeec1271c, a merge commit with parents 50bb328128b20aa82edb3ab1f886490bccb8b070 (the audited commit) and f62d0245e95e2b411be16511fc1bf9e1da727ce5 (trunk_dev). No conflict.
- Tree: a6816483cd1c9fcdc17af0c93756780cbe19b62e
- New base: f62d0245e95e2b411be16511fc1bf9e1da727ce5 (old base f9537a8680c24bf2108b95ed20ac3724e8939d3a)
- New manifest v2 (HEAD reset to the new base, upstream origin/trunk_dev): af7476a4453deda69e3f8e9d87bc4f4233568b6c3d62d9991183864c9f2be651, 503 bytes, 1 path. Two runs identical, and identical again from a fresh clone.
- It differs from the audited manifest 8f245edd…a499 only in the field head. files, textual_diff_sha256 (78a14ba7fdc288e723d97bd24a59e38efe08caae4754d32ccda5be01138bba8f), upstream and branch are the same.
- git range-diff f9537a8..50bb328 f62d024..143167d shows both commits as equal. git diff f62d024..143167d is byte-identical to git diff f9537a8..50bb328. The blob of remote_alpha_es_service_tls_status_test.go is c6652a34cd500c1f2945084c45a6c33e30fb6cb6 at both. What the merge added to the branch is byte-identical to what trunk_dev gained (one file of PR 16).

The gate report with the logs comes as tls-status-fixture-timing/08-merge-gate-pr21.md when CI has finished.

Separately: the containment proposal is nearly written. Three ways are measured, and I will recommend a process namespace of the child's own over a control group. It needs decisions from you before I implement.
