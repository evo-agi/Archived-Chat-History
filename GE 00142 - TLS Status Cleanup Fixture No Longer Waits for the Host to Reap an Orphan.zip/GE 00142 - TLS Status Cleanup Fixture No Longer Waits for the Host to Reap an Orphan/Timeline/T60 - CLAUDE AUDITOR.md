**PR 21 merge gate: PASS.** The new head `143167d` contains exactly the audited change, so the ACCEPT carries over. The note is [07a-merge-gate-pr21.md](/mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/07a-merge-gate-pr21.md), sha256 `e97545ede1b4e25676aac2548bc88522c5bf86312356ae64fa17a1536c2a0036`. Its evidence folder has 11 files, and the SHA256SUMS file's own sha256 is `da0e6b2d…1389`.

- **Tool hash** checked OK. I reproduced the manifest with upstream re-pinned to `origin/trunk_dev`. Two runs gave identical results: `af7476a4…f651`, the same as the writer's. Against my audited `8f245edd…a499`, only `head` differs.
- **The merge adds nothing of its own:**
  - Tree `a6816483…` equals `git merge-tree` of `50bb328` and `f62d024`.
  - Range-diff: `30e38d0 = 30e38d0`, `50bb328 = 50bb328`.
  - `git diff f62d024 143167d` is byte-identical to `git diff f9537a8 50bb328`.
  - The test file blob is `c6652a34…` at both heads.
- **CI run 45101781531 is green** (finished 02:55:25Z). The root package passed and the gate passed. The only TLS status failures are the three tests that need another environment, in the step that expects them to fail.

I named the note 07a because it is an annex to 07. I'm using 08 for the PR 22 report, which is next.

Leak scan: 0 findings.

STATUS: WORKING
