Audit the timing test fix
