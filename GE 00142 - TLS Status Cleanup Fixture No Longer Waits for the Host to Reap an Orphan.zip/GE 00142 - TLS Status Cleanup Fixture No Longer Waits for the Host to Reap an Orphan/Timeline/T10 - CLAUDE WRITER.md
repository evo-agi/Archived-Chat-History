One tap, David: please allow the card above. It runs the three changed tests once on your Mac, read-only, in a temporary folder under Playground. Nothing else waits on it.

The timing-dependent test is fixed in draft [PR 21](https://github.com/evo-agi/Execution-Substrate/pull/21). The test left an orphaned process, and the cloud machine clears those only once a second. The test now cleans up its own process. 2,340 runs passed, none failed. The report follows when its run on GitHub is done.

STATUS: NEEDS DAVID
