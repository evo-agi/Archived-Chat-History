That worked. The temporary folder is gone and everything else in Playground is untouched.

STATUS: WORKING (PR 20 and PR 21 audits, PR 19, PR 22, PR 13 split, MA alert; nothing needed from you)
