David approved the Mac run (attached). Also note: trunk_dev now requires the "build, vet and test" check and branches up to date before merging.
