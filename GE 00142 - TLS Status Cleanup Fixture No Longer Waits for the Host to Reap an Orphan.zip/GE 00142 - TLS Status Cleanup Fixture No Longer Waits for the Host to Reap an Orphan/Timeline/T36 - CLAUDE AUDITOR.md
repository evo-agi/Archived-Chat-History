**PR #21 audit: BLOCK** on one low finding. The repair is test-only and about two lines. Report: [02-audit.md](/mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/02-audit.md) (sha256 `bbe80882d472e855349321259b556c4a865f7dab21c3b31056518680e6f2f75f`). Evidence is in `02-audit-evidence/` (SHA256SUMS sha256 `2de26c65…1c06`, leak scan 0 findings).

**What holds:**
- Provenance of `30e38d0` reproduced byte-identical (manifest `eeb9fada…b4de`), at opening and at closing.
- The root cause is real. At the base, 15 of 310 separate `go test` runs fail. With the fix, 0 of 310 fail, and 1,560 of 1,560 repeated subtest runs pass, idle and under checked load (load average up to 26.6).
- The change is test-only, changes no bound or assertion, and leaves no process behind.
- The 4 leak-scanner hits in the Mac files are false matches.

**A2-1 (low):** the keeper reaps a killed process instantly, so these tests never see a killed process stay visible any more. As a result, a cleanup that trusts a delivered SIGKILL and returns without checking the group is empty now passes. That breaks the documented rule. It was caught 15 of 15 times at the base and survives 260 of 260 runs at the fix, and no other TLS status test catches it.

**Repair:** the keeper keeps the dead process visible for a fixed 0.3 s before reaping it. My sketch of that catches the mutant again and passes 390 of 390 runs. The repair also needs one Mac run.

Effects: nothing pushed, commented or merged. Starting the PR #22 audit now.

STATUS: WORKING (PR #22 audit; next update when it has a verdict, likely within about 90 minutes)
