Thanks, the rerun on your Mac has started.

STATUS: WORKING (Mac run, PR 20 and PR 21 audits, PR 19, PR 22, PR 13 split, MA alert; nothing needed from you)
