<!-- reply 1 -->
> One more Mac approval, when you have a moment. The fix for the flaky timing test is up as PR 21 (→ github.com), and it n…


Approved.
