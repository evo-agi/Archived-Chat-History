Thanks, that matters. From now until the reset, Fable is reserved for the reliable-submit core: PR 13's next audit and the red-team of PR 12, plus the PR 20 audit already running. Every other audit, check and fix runs on Opus.

One thing while you're here: the flaky-test fix (PR 21) is repaired and needs a 2-minute rerun on your Mac. Please write "go ahead" in the [CI fix thread](#cmsg_01Un4xQgjBAczV8DABQvcLrxUKRNzSrmXnB75DgsbjDwit).

STATUS: NEEDS DAVID (write "go ahead" in the CI fix thread)
