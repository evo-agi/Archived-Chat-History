Sorry, I was wrong a moment ago. The Mac connection only accepts the next step when you write in that thread yourself. Please open the [CI fix thread](#cmsg_01Un4xQgjBAczV8DABQvcLrxUKRNzSrmXnB75DgsbjDwit) and reply "go ahead". It reruns the three tests with the Go version already on your Mac, nothing downloaded, and removes its temporary folder afterwards.

STATUS: NEEDS DAVID (write "go ahead" in the CI fix thread)
