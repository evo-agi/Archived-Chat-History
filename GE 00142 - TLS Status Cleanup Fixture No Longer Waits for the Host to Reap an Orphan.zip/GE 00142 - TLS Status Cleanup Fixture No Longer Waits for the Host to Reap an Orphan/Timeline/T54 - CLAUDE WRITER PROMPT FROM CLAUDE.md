David ran the cleanup line; the listing shows es-mac-run.ZAVaqe is gone and Playground remains with its other contents. Record it as done.
