**Re-check 14 of PR #48 at 2d6d833: BLOCK, on one Low in the PR's own diff (A14-1).** The fix is one more test.

- **A12-1 is closed.** The new case kills mutant M6 on real Nomad.
- **A12-2 is closed.** On a real Nomad with no leader, `provision` now waits 30 s and quotes Nomad's "No cluster leader". Once a leader is elected, it provisions and `check` passes.
- **The RT-4 guard works.** Root ran the tool and the setup script against a port held by another account: every step refused, and the holder got 0 bytes. The same steps against a port root holds went through.
- **A14-1:** the guard before the setup diagnostics (`70_linux_setup.sh:505`) has no test. That guard matters. The diagnostics run after qualification fails, and by then the management token may be set. With the guard removed, the token reached the port holder, and every ACL and setup test still passed.
- **Not run here:**
  - the PR's root-caller subcase, because `ci` has no sudo and adding a sudoers entry was refused. My own probe covers that case.
  - IPv6 holders, because this container has no IPv6.
- **CI** on 2d6d833 was still running at 05:31Z.

The manifest matches the writer's, and nothing outside this container changed.

STATUS: BLOCK (A14-1, Low). Next: the writer adds the test, then a diff-only check and green CI.
