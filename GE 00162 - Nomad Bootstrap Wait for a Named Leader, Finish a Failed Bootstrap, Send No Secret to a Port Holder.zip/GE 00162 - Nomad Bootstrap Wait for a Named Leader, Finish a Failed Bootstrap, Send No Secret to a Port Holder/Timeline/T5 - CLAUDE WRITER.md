The two bootstrap fixes are on their own draft PR, [#48](https://github.com/evo-agi/Execution-Substrate/pull/48), and are ready for audit. I'm watching its CI.

- **What it fixes:**
  - the setup script's leader wait no longer takes `""` for a leader;
  - the ACL tool can now finish a bootstrap that never took effect, where before every rerun refused.
- **Tests:** the new tests pass on Nomad 2.1.1 and 2.0.0, and 6 of 6 mutants were killed.
- **Size:** one commit, 4 files, on trunk_dev `6dbeaeb`. The manifest is `f8442290…5086`.

Part 2b stays paused.

STATUS: WAITING (audit of #48)
