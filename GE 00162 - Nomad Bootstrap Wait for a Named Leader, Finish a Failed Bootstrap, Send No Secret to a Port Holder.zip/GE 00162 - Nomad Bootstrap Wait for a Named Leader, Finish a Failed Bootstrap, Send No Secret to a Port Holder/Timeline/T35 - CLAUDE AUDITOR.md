**PR #48 passes its merge check at c4aa6b8 (ACCEPT).** It can be squash-merged once CI on c4aa6b8 is green.

- **Merging in trunk_dev was clean.** It brought in #44, #46 and #12, and none of the PR's 11 files changed. The manifest matches the writer's.
- **Commit 1127ba0 fixes the two minor notes from round 16 and changes nothing else.**
- **The tests pass on Nomad 2.1.1 and 2.0.0.** That covers the guard tests, the ACL and setup tests, #12's package and the root package. My 7 attempts to break the guard are all still caught.
- **The installer test passed this time too,** because I started the batch with `setsid` instead of `nohup`. That confirms round 16's explanation.
- **CI:** the run on c4aa6b8 was still going at 07:08Z (UTC). The run on fbee014 passed at 06:26Z.

STATUS: ACCEPT at c4aa6b8. The merge gate needs green CI on c4aa6b8, then a squash merge.
