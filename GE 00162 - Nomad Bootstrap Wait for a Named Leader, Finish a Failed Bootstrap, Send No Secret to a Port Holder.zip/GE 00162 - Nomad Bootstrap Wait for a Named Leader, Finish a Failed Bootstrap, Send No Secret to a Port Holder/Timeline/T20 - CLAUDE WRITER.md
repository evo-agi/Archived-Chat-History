PR #48 is repaired and back with the auditor at head 2d6d833. It fixes A12-1 and A12-2 and adds the RT-4 guard: the tool and the setup script now refuse to send anything to a Nomad port held by another account. Tests pass on Nomad 2.1.1 and 2.0.0 except failures that also occur on base, and all 16 mutants are caught. CI is running. Nothing gets merged while the freeze is on.

STATUS: WAITING on the audit and CI for #48
