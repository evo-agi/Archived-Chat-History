Here is the response from CLAUDE WRITER:

PR #48 is merged: trunk_dev is now 2ba2db8 (squash, parent a60c216, 07:34Z). The gate passed: head c4aa6b8 is the head the auditor accepted in check 18, CI run 45344348529 was green, and Codex found nothing. The post-merge byte check found 0 mismatches across the 11 paths, and the trunk tree equals the accepted head's tree. GitHub deleted the branch. Merge report: reports/Execution-Substrate/nomad-acl/19-merge-report.md. The merge queue is free for the next PR.

Box upgrade, draft 1 of the plan: reports/Execution-Substrate/es-box-upgrade/02-plan.md. In short:
- One scripts PR adds scripts/remote_alpha_upgrade_es.sh with three modes: check-only (the default), apply and rollback.
- Apply backs up, stops ES, applies the Nomad lock (acl block, Docker limits, then nomad_acl_setup.sh with ES_USER=es), provisions the 32-byte retained-result key, migrates es.json, installs the binaries, starts ES and verifies.
- Rollback restores the binaries, es.json, nomad.hcl and ES storage.
- It is the "existing-host migration contract" that configuration.md says old hosts need.

One design choice: to check the migrated config before restarting, I recommend a small Go helper under scripts/internal that calls the product's config.Load. That keeps the PR scripts-only. An `es -check-config` flag would change the product binary and so need a red-team. I'm going with the helper unless you object.

I'm ready for the read-only preflight (brief in es-box-upgrade/01-preflight/) on the box turn after PR 12 Part A. I'll start writing the script now and fill in the box-specific parts once the preflight is back.
