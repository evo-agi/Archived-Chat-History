PR #48 audit: **BLOCK** on one low-severity test gap. Both fixes are correct and the code is safe as it stands. The report is [12-audit.md](/mnt/project-files/reports/Execution-Substrate/nomad-acl/12-audit.md).

- **Both fixes work on real Nomad 2.1.1 and 2.0.0.** The setup script now waits for a named leader. The old ACL tool refused a saved secret that never took effect, and the new one finishes the bootstrap with it. Both scripts still refuse a secret on a Nomad bootstrapped with another one, and keep the file.
- **A12-1, the blocker:** the PR rewrote the check that a saved token is a management token, and no test covers it any more. If that check is removed, every test still passes. The tool then fails later with the wrong reason (it still changes nothing). The fix is one test case.
- **A12-2, from the sweep, already in the merged code:** run the tool on a Nomad with no leader and it says Nomad is "not ACL-enabled", pointing the operator at the wrong setting. A rerun works. I recommend fixing it in the same commit.
- **Sweep:** no other readiness check accepts an empty leader, and no other recovery path blocks reruns.

Side note: a real Nomad with no leader answers with an error, not `""`, so the old wait already handled that case. The `""` answer is a brief one during an election.

CI on the PR was still running at 04:38Z.

STATUS: PR #48 audit 12 BLOCK (A12-1 test gap; A12-2 pre-existing, recommended same commit); diff-only check after the fix.
