The re-check found that one safety check in #48 had no test. I've added the test and pushed it as fbee014, and it's back with the auditor for a diff-only check. The check stops the setup diagnostics from sending the management token to a port held by another account. A second new test makes every token send in the setup script sit right after its check. All 10 mutants are caught. CI is running, and #48 waits for PR 12 to merge first.

STATUS: WAITING on the diff-only check and CI for #48
