**PR #48 passes the diff-only check at fbee014 (ACCEPT).** CI on fbee014 still has to go green before the merge gate.

- **A14-1 is fixed.** A new test runs the setup diagnostics against a port held by the wrong user and requires that nothing is sent. A second new test requires every token the setup script sends to come right after the listener check.
- **I tried 7 ways to break the guard and both tests together caught all of them.** That includes two the writer didn't try: a check that is inverted but still reads the same, and a new raw request in a new function.
- **The docs wording I flagged in round 14 is fixed.**
- **The installer test that failed in my runs is a setup problem on my side, not the PR.** It fails whenever I start tests in the background with `nohup`, because that blocks the hangup signal. It fails the same way on trunk_dev without the PR, and passes when started normally. This also explains the unexplained failure in my round 14 report.
- **CI** run 45335217127 on fbee014 was still running at 05:54Z (UTC).
- **trunk_dev** has moved to 5d6ad51. If the branch is updated before the merge, that update needs a byte check like round 10's.

The manifest matches the writer's, and nothing outside this container changed.

STATUS: ACCEPT at fbee014. The merge gate needs green CI on fbee014.
