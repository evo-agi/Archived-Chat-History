Merge freeze: merge nothing into trunk_dev until PR #46 lands (CI on 06731ca, about 05:26Z). Fixing #48 is fine, just don't merge. I'll lift it.
