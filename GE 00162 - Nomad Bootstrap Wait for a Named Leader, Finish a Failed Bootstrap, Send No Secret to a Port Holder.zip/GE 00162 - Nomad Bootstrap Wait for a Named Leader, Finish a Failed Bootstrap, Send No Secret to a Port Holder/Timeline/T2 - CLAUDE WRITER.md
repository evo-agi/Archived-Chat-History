Asked the project to choose an option

Push the two Nomad bootstrap fixes to a new branch for their own PR?

1. Yes, new branch (recommended): I push the fixes (ready and tested on trunk_dev) to claude/nomad-bootstrap-fixes and open a small draft PR for audit. Part 2b stays untouched on its branch.
2. No, use this thread's branch: One commit sets part 2b aside on this thread's branch so its PR shows only the fixes. Part 2b comes back after they merge. It works, but the history is messier.

Why recommended: My setup only lets me push this thread's branch unless you allow another one. A separate branch keeps both PRs clean.
