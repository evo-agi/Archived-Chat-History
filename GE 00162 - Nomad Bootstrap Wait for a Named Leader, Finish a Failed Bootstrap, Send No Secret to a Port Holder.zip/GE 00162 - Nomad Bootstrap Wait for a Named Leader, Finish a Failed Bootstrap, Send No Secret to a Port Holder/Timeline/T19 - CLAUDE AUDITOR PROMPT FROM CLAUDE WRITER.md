Here is the response from CLAUDE WRITER:

PR #48 has a new head, 2d6d833 (one commit on a79c355, base 6dbeaeb). Please check A12-1, A12-2 and the RT-4 interim guard.

A12-1: new case in TestNomadACLToolRetriesABootstrapThatNeverTookEffect. A saved client token now gets token_self, then a bootstrap retry with that secret. On "already done" the tool refuses and keeps the file. M6 is killed.

A12-2: provision runs wait_for_leader (default 30 s, --leader-wait-seconds). Only a nonempty JSON string counts as a leader. require_acl_enabled quotes the status and body. TestNomadACLToolWaitsForANamedLeader covers 500, "" twice then a leader, and a token/self 500.

RT-4: the tool checks its connected socket in /proc/net/tcp{,6} before sending anything. The row local=peer, remote=ours must belong to --nomad-uid, so the tool has no TOCTOU window. 70_linux_setup.sh checks LISTEN rows before each request and before the bootstrap POST. That leaves a TOCTOU window, which is documented. Plumbing: nomad_acl_setup.sh NOMAD_USER, 72 SUPPORTED_LOCAL_NOMAD_USER, 01_bringup --nomad-uid $(id -u). Part 2b replaces the guard. configuration.md states the limits.

Mutants: 16/16 killed. G3 is killed only by the root-via-sudo case.

Validation at 2d6d833:
- Bring-up passes on Nomad 2.1.1 and 2.0.0, and so does the Nomad/ACL/setup set.
- Full es/app shows only the 2 known failures.
- root, admission and vet (linux, darwin) pass.
- scripts has 28 failures. The 28th is #38's TLS-status test, which fails the same way on base.
- A manual root run against a ci-owned listener was refused (uid 1500).

CI on a79c355 was green; CI on 2d6d833 is pending. trunk_dev c610e1d is not merged in, because of the freeze.

Manifest v2: c0c250e1b1f64250e9b31ee98bc3db6945510e59d9780865842872a8fd99a294 (11 files). Reproduce it on a branch named claude/nomad-bootstrap-fixes.

Report: /mnt/project-files/reports/Execution-Substrate/nomad-acl/13-repair.md (sha256 74c01a1a8ef72f732396eca747a1529e35f6c666f60f1b5e874e7391c78983bc). Evidence is in 13-evidence/.
