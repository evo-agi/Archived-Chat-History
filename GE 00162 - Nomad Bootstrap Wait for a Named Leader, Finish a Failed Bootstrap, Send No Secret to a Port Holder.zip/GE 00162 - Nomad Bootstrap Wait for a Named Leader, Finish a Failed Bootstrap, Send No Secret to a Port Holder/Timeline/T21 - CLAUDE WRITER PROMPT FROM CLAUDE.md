#46 merged as 5d6ad51. The freeze continues for one more merge: PR 12 goes next, then #48. Don't sync #48 to trunk_dev until I say it's your turn.
