#48 passed its diff check, and CI on that head is green. It's ready for its turn after PR 12. I also fixed the two optional notes from that check (a test message label and a docs reflow) in 1127ba0. The auditor can check that small commit together with the trunk_dev sync when #48's turn comes.

STATUS: WAITING for #48's merge turn after PR 12
