Here is the response from CLAUDE WRITER:

A14-1 is fixed in PR #48 at head fbee014, one commit on 2d6d833 (base 6dbeaeb, trunk_dev not merged in because of the hold). Please do the diff-only check.

Delta (4 files, +124/-4): /mnt/project-files/reports/Execution-Substrate/nomad-acl/15-evidence/delta-2d6d833-fbee014.diff

Changes:
- 70_linux_setup.sh: the only change is BEGIN/END nomad_cpu_visibility_diagnostics comment markers around the diagnostics function. The harness evals that region too.
- TestLinuxSetupBootstrapSendsNoSecretToAPortHolder: new diagnostics case. NOMAD_QUALIFY_TOKEN comes from a 0600 file. It runs "report_nomad_cpu_visibility_diagnostics || true" as the script does. With a uid that isn't the owner, it requires the refusal and 0 requests. In the control, the first request must be GET /v1/nodes with that token.
- New TestLinuxSetupChecksNomadsListenerBeforeEveryTokenSend: every command that sends NOMAD_TOKEN=, X-Nomad-Token or BootstrapSecret (heredocs and comments skipped) must directly follow a check, either on the same line, as "require_nomad_listener || return 1", or as an "if ! require_nomad_listener; then … return 1 fi" block. It must find sends in 4 named functions. This also pins S4 and S5.
- Docs: I14-1 wording.

Mutants: 10/10 killed: S3 (by the behavioural test alone and by the static test alone), S4, S5, S6 (guard block no longer returns), S7 (check after the send), S8 (a new raw X-Nomad-Token curl), S9 (marker dropped), G6.

Validation: the ACL/setup set passes on 2.1.1 and 2.0.0, and so do the root package, gofmt and vet (linux, darwin). The new tests pass as root. git archive matches the tested copy. CI on fbee014 is running.

Manifest v2: d956c5aafbcd737c6fd110bc56eada79dbbcb7dcbb903b4919497661693bcc24 (11 files, on claude/nomad-bootstrap-fixes).

Report: nomad-acl/15-repair.md (sha256 db4567b8f5d36fb2495168426a0c1ffeb20b8ca57d6caf5e1411f87412af31e6). Evidence SHA256SUMS: 39f785813397dfef35a27e8af0cd8de609501ba231a1b73eff55d8a312f0d3a5.
