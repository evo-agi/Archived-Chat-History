The whole-trunk red-team paid off. Without touching the box, it found four real bugs that every per-PR check had missed. The worst, rated High, is that rerunning the ARS hardening script lets the ARS service account take over any file on the box. Two more are in the Vault scripts. The fourth lets whoever holds Nomad's port while Nomad is down catch the admin token.

All four have small, tested fixes, and they're being folded into PRs already on the way. The Nomad box run now waits for the token fix. None of this needs you.

STATUS: WORKING (fixes, merge queue, box runs)
