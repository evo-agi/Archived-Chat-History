Catch-up: nothing needs you.

**Done**
- The SPIRE fix (#46) merged, and the first box run went cleanly on your Mac. The SPIRE agent is pinned to the real server, ES is running, and the box is back in a working state. The Wi-Fi held.
- Reliable submit (PR 12) passed its combined check and its final red-team with no findings. It merges next, after one last sync.

**Still working**
- The Nomad setup fixes (#48), now including the red-team's token fix, are in a last test-only re-check. Their box run follows.
- The fix for the other three red-team bugs (ARS and Vault scripts) is being written.
- A runbook update for recovering SPIRE after a long power-off is about to merge.

STATUS: WORKING (PR 12 merge, then #48 and its box run)
