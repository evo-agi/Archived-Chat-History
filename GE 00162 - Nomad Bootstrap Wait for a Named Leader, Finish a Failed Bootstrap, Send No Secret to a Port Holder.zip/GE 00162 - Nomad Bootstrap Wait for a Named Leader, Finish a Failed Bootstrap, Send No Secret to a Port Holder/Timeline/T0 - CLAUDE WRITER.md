Part 2b is paused at a clean point. Everything is pushed to the branch at `3ef8a75`. There's no PR yet.

**Done before the pause:**
- Part 2b is carried onto trunk_dev and fully revalidated. 25 of 25 mutants were killed.
- The automated review of #31 posted two findings after the merge. Both were real:
  - the setup script's leader wait accepted `""`, Nomad's answer while it is still electing a leader;
  - after a bootstrap that never took effect, the ACL tool refused every rerun.
- Both are fixed, with tests on Nomad 2.1.1 and 2.0.0. 6 of 6 mutants were killed.
- I merged trunk_dev's PR #38 cleanly.

**Still to do:** the full test suites after that merge, then the report and the draft PR. The steps are in [CONTINUE.md](/mnt/project-files/reports/Execution-Substrate/nomad-acl/11-wip/CONTINUE.md).

STATUS: WAITING (paused until the merge queue drains)
