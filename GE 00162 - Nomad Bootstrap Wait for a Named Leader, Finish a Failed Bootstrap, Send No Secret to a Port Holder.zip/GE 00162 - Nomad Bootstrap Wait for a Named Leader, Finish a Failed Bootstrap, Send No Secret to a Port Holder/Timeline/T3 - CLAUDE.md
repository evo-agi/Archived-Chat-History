Decision in Governed Execution: Push the two Nomad bootstrap fixes to a new branch for their own PR? (Sent: Yes, new branch)
