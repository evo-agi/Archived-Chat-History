# Execution-Substrate trunk_dev as merged: whole-trunk red-team (report 01)

```
Target:    evo-agi/Execution-Substrate, origin/trunk_dev
Tested:    6dbeaebdce52b85e85abc8ea3aa2473a45abfcb4 (PR #38 merge). Re-checked at
           2026-11-24 04:37Z: trunk_dev still points there.
Posture:   separate thread from every writer and auditor; read-only on the repo; nothing
           pushed, no PR, no comment; nothing run on the Linux box or against any live
           service; David's computer not used. Everything ran in one cloud container.
How:       code reading across the root and service-account surface, then reproductions
           as real root with real separate Unix accounts, inside private mount (and for
           RT-4 network) namespaces with throwaway overlays on /etc, /var/lib, /opt and
           /usr/local, so nothing outlived a run.
Verdict:   4 findings. 1 High (reproduced end to end with the unmodified script),
           3 Medium (two reproduced, one by reading). None needs anything deployed.
           Three of the four sit in scripts written in April and May 2026, before the
           per-PR audit and red-team pipeline existed, so no per-PR check ever saw them.
```

Labels used below: **Ran** (I executed it and saw the result), **Read** (from the code or a
report), **Inference**, **Guess**, **Unknown**.

## 1. Findings at a glance

| ID | Severity | Where | What happens | Evidence |
|---|---|---|---|---|
| RT-1 | **High** | `scripts/internal/remote_alpha_harden_ars_service.sh` 674-688 | A rerun of the ARS hardening step as root follows a link the `ars` account planted and gives that account any file on the host. `ars` to root. | Ran, unmodified script; fix diff tested |
| RT-2 | Medium | `scripts/remote_alpha_reset_disposable_vault.sh` 611-615 | The Vault reset recreates the raft directory with `install -d -o vault` by path inside a vault-owned directory. A surviving vault process wins the gap and receives any directory. `vault` to root. | Ran, the script's own five lines, 20 of 20; replacement lines tested, 0 of 20 |
| RT-3 | Medium | `scripts/internal/remote_alpha_migrate_vault_service_user.sh` 1366-1404 | The Vault migration checks paths without following links, then changes owner and mode by path, in directories the vault account owns on the box today. It also hands a log file's whole parent directory to vault with no guard. | Read, not run |
| RT-4 | Medium | `scripts/internal/nomad_acl.py`, `scripts/70_linux_setup.sh`, ES's Nomad client | Whoever holds 127.0.0.1:4646 while Nomad is down receives the management token, or the fresh bootstrap secret, from the root tools. Known class (INF-10); new here is the working demonstration and a small interim guard. | Ran, unmodified tool against a stand-in listener |

Why the earlier checks missed RT-1 to RT-3: those scripts were added on 2026-04-25,
2026-05-23 and 2026-04-28 (Ran: `git log`). Per-PR audits and red-teams only read what a PR
changes. The script tests replace `chown`, `id` and `stat` with stand-ins that
always succeed or print a fixed answer (Read: `scripts/remote_alpha_harden_ars_service_test.go`
25, 61 and 156; `chmod` is real but runs on the test's own files), so no test could ever see
a link being followed.

## 2. RT-1 (High): ARS hardening rerun hands the `ars` account any file

**Type:** root acts by path on a tree a less-privileged account owns; links are followed.

**Code (Read).** `remote_alpha_ars_hardening_apply_state_permissions`:

```bash
mkdir -p "${state_root_dir}" "${blob_root}" "$(dirname "${index_file}")"
chown -R "${REMOTE_ALPHA_SERVICE_USER}:${REMOTE_ALPHA_SERVICE_GROUP}" "${state_root_dir}"
chmod 0750 "${state_root_dir}"
chmod 0750 "${blob_root}"
chown "${REMOTE_ALPHA_SERVICE_USER}:${REMOTE_ALPHA_SERVICE_GROUP}" "${index_file}"
chmod 0600 "${index_file}"
```

After the first run, `/var/lib/execution-substrate/ars` belongs to `ars`. The last two
lines are plain `chown` and `chmod`, which follow a symbolic link. The preflight
(lines 508-556) only tests `[[ -e path ]]`, which also follows links. Nothing checks
whether the step already landed, and the runbook treats reruns as normal
(`.docs/system_overview/remote_supported_host_alpha.md` 4832, 4839).

**Attack.** A process running as `ars` replaces its own `index.json` with a link to any
file. The next time the operator runs `sudo scripts/remote_alpha_harden_ars_service.sh`,
root makes that file `ars:ars 0600`. The owner can then read it, rewrite it and change
its mode, so a program or unit file that root runs becomes `ars`-controlled.

**Who can do it.** Anyone who gets code running as `ars`. ARS is a network service and
its unit has no sandboxing on the box (Read: box inventory, systemd score 9.2).
Inference: the box is already in the vulnerable state, because its ARS tree is `ars`-owned.

**Reproduction (Ran).** `01-redteam-evidence/rt1-ars-hardening-symlink.sh`, with a real
`ars` account, real root, the unmodified public script, and a stand-in only for
`systemctl`. Victim: a root-only Nomad management token file (fake value).

```
before: root:root 600 /etc/execution-substrate/nomad-acl/management-token   (ars: Permission denied)
after:  ars:ars 600 /etc/execution-substrate/nomad-acl/management-token
        ars reads 11111111-2222-3333-4444-555555555555
```

The script exits 1 in the rig, from later probes that need services, after the damage.
Variant (Ran, `rt1-base-blobs-symlink.out`): linking `blobs` at a directory makes root set
that directory to mode 0750. In the run a root-only 0700 directory became 0750. Inference:
the same link pointed at `/etc` would lock every non-root user out of it. A link deeper in the tree is not followed
(Ran, `rt1-base-nested-symlink.out`): `chown -R` leaves links alone.

**Suggested fix (tested diff, `rt1-fix.diff`, 100 lines added, 6 removed).** Replace the
six lines with one descriptor-based step: open the state root from its root-owned parent
without following links, walk the tree by descriptor, set owner and mode with `fchown`
and `fchmod`, and refuse anything that is not a directory or a regular file with one
link. Ran: with the diff, all three link cases are refused before any change and the
token stays `root:root 600`; a first run on a root-owned tree and a clean rerun give the
same owners and modes as trunk (`rt1-fix-*.out`).

**Honest limit of the diff.** One existing test fails with it
(`TestRemoteAlphaARSHardeningPassWritesSummaryAndDropIn`: "the ARS service account does
not exist"), because that test relies on the stand-in `chown` (`rt1-existing-tests.txt`).
The writer has to rework that test. The regression test for this finding needs real
accounts and real root, as in the reproduction script, since stand-ins cannot show it.

## 3. RT-2 (Medium): Vault reset gives a surviving vault process any directory

**Type:** root creates by path in a directory a service account owns; time-of-check gap.

**Code (Read).** `run_execute_reset`, lines 611-615:

```bash
sudo systemctl stop "$(unit_name)"
sudo mv -- "${VAULT_RAFT_PATH}" "${backup_path}"
sudo install -d -o "${vault_user}" -g "${vault_group}" -m 0700 -- "${VAULT_RAFT_PATH}"
```

On the box `/opt/vault` is `vault:vault 755` (Read: inventory). Between the `mv` and the
`install -d`, the name `/opt/vault/raft` is free. `install -d` on a name that is a link
to a directory changes the owner and mode of the link's target (Ran).

**Attack.** A process still running as `vault` creates `/opt/vault/raft` as a link to,
say, the directory holding the service programs. Root hands that directory to `vault`.

**Precondition.** A vault-uid process must outlive `systemctl stop vault`. Inference: the
packaged HashiCorp unit sets `KillMode=process`, which stops only the main process, so
anything a compromised Vault started survives. Unknown on the box; `systemctl show vault
-p KillMode` answers it (read-only, for a later box session). The reset is also a rare,
interactive, operator-only step. Those two conditions are why this is Medium, not High.

**Reproduction (Ran).** `rt2-vault-reset-symlink-race.sh` cuts lines 611-615 out of the
unmodified script and runs them as root against a real `vault` account that keeps trying
to create the link. Root handed the victim directory over in **20 of 20** trials, and the
vault account then swapped a program that root ran. The rig's `sudo` is a pass-through, so
the real gap is wider than the one tested. The whole script was not run (it needs a
terminal, a real Vault and systemd).

**Suggested fix (Ran, `rt2-fix.out`, 0 of 20).** Replace the `install -d` line with
`sudo mkdir -m 0700 -- "${VAULT_RAFT_PATH}" && sudo chown -h -- "${vault_user}:${vault_group}" "${VAULT_RAFT_PATH}"`.
`mkdir` refuses a name that exists and `chown -h` never follows a link. Also refuse to
continue while any process still runs as the vault user after the stop
(`pgrep -u "${vault_user}"`), which removes the precondition whatever the unit says.

**Related, Read only.** The same script reads the raft path from the Vault config file,
and `/etc/vault.d` is `vault:vault 755` on the box, so the vault account can replace
`vault.hcl` and choose the path root will move and recreate. The only guard is the
operator reading one line before confirming, plus a short list of refused paths
(lines 325-338). Fix together with RT-3: make `/etc/vault.d` `root:vault 0750`.

## 4. RT-3 (Medium, read not run): Vault service-user migration applies by path

**Type:** check without following links, then act by path; no bound on which directory.

**Code (Read).** The plan step uses `os.lstat` (line 397), so a link is a blocker at plan
time. `apply_path_changes` (1366-1404) then runs plain `chown` and `chmod` on the same
names:

- the Vault config file and its parent, and each TLS file and its parent, become
  `root:vault` 0640 and 0750;
- for a configured log or audit file, **the parent directory** becomes `vault:vault 0750`
  (lines 1400-1401), with no check of which directory that is.

**Why it matters on the box.** `/etc/vault.d` is `vault:vault 755` (Read: inventory), so the
plan would mark the config for adjustment, and the vault account owns the directory where
root is about to act by name. The same holds for the listener's TLS files if they live in
vault-owned `/opt/vault/tls` (Unknown: the config is not in the inventory). Vault keeps running
during the apply (the restart comes after, line 1516). A vault process that swaps
`vault.hcl` for a link after the plan step makes root set any file to `root:vault 0640`,
which lets the vault group read it: the Nomad management token or `/etc/shadow`, for
example. Separately, a Vault config with `log_file = "/var/log/vault.log"` would make the
script give `/var/log` to vault. Unknown: whether the box's `vault.hcl` sets `log_file`.

**Not reproduced.** It needs systemd and a real Vault. The mechanism (plain `chown`
following a link in a directory the service owns) is the one RT-1 demonstrates.

**Suggested fix.** Take the parent directory to root first, then set files through
descriptors opened without following links (the RT-1 helper fits), and refuse a log or
audit parent that is not a directory dedicated to Vault.

## 5. RT-4 (Medium): the root tools send the Nomad management token to whoever holds port 4646

**Type:** secret sent to an unauthenticated local endpoint. **Known class:** INF-10
(Nomad on plain HTTP; port squatting). Part 2b (HTTPS with a pinned key) is the proper
fix and is paused for quota. What this adds is a working demonstration and a small guard.

**Code (Read).** `nomad_acl.py provision` asks the listener one anonymous question
(`require_acl_enabled`), then sends the management token (`require_management`) or, on a
first run, the fresh `BootstrapSecret`. `70_linux_setup.sh` line 383 does the same.

**Reproduction (Ran).** `rt4-nomad-port-holder.sh`: an unprivileged account runs a
30-line stand-in on 127.0.0.1:4646 in a private network namespace; root runs the
unmodified tool.

```
case A (token file exists): holder recorded X-Nomad-Token: 11111111-2222-3333-4444-555555555555
case B (first run):         holder recorded {"BootstrapSecret": "85b613a5-…"}
                            root kept that same value as the future management token
```

Case B is the quiet one. The tool keeps the secret "so a rerun can finish", so the holder
can bootstrap the real Nomad with it once Nomad is back, and the operator's rerun then
succeeds with nothing looking wrong.

**When the port is free.** Whenever Nomad is stopped or restarting, and enabling ACLs
needs a Nomad restart, with every service account already running on the box. Any local
account can bind the port. Related and already noted in passing in
`nomad-acl/12-bootstrap-fixes.md`: until bootstrap completes, any local account can call
the real `/v1/acl/bootstrap` first; that case fails loudly.

**Suggested fix.** Land part 2b before the ACL lock is run on the box. If the box run
must come first, add an interim guard: before sending any secret, require that the
listening socket on 127.0.0.1:4646 belongs to uid 0. The kernel's `/proc/net/tcp` gives
that; Ran: it reported the stand-in's uid (996). ES can make the same check before
sending its own token.

## 6. Attacked and held

- **Runtime helper cleanup after the workload exits** (`es/runtimehelper/supervisor.go`):
  I tried to make the root supervisor follow a workload-planted name. It locks top-down
  and only ever gives ownership to the ES account, never to the workload. Read.
- **Nomad ACL tool address and token files** (`nomad_acl.py`): only
  `http://127.0.0.1:<port>` or `[::1]`, no proxy, no redirects; `#` and `?` tricks fail
  closed; token files are opened without following links, with a safe-parent check. Read.
- **ES Nomad token loading and the ES token file owner** (`es/admission/nomad_access.go`). Read.
- **ARS blob store paths** (`ars/store/filesystem.go`): digest pattern, temp file, rename. Read.
- **ES API**: every route goes through `authorizeExecutionCaller` (`es/api/server.go`). Read.
- **AGS and EGS hardening, TLS renew, config prep and binary deploy helpers**: they act
  only in root-owned `/etc/execution-substrate` folders or in the operator's own staging
  folder. Read, at search level for the last three.
- **`chown -R` on a tree with links, or on a link given as its argument**: links are not
  followed. Ran.
- **Vault reset backup name**: a planted name there only moves Vault's own data. Read.
- **Retired ES migration routes**: refusal-only. Read.

Observation, no boundary crossed: `remote_alpha_reset_disposable_vault.sh` line 349 picks
the alphabetically first `remote_alpha_vault_workload_auth_check.sh` anywhere under
`/home/ds` and runs it with `sudo`. The operator owns that folder, so this crosses no
boundary, but a fixed path would be safer than a search.

## 7. Known or in flight, not re-reported

Codex R31-1 (leader wait accepts `""`) and R31-2 (ACL tool rerun after failed bootstrap),
both fixed on the writer's branch; F15-1 and F15-2 in the SPIRE `recover` path (fix PR
#46); INF-01 to INF-24, in particular INF-02, INF-04, INF-10 and INF-16; trust model read
only at startup; ARS writer-prefix drift; the A2-5 discovery record; staging never
reclaimed; the single-tenant ES API. Open PRs #30, #35, #44, #45 and #46 were out of scope.

## 8. Coverage this environment could not provide

- No real Nomad, Vault, SPIRE or Docker ran in this pass (not installed; the Docker
  daemon was not running). RT-4 used a stand-in listener, clearly not Nomad.
- No systemd: `KillMode`, unit ordering and service restarts are read or inferred.
- Nothing on the box: every box fact comes from the 2026-11-23 18:03Z inventory.
- Not examined beyond a search: the TLS status collectors, the supported-local scripts
  (`72_`, `73_`), AGS publish and static archive code, EGS, and the SPIRE helper's
  `status` and `pin` (covered by earlier audits).
- RT-3 was read, not run.

## 9. Regression tests to make permanent

1. RT-1: the reproduction script's five cases as a CI job that runs as root with a real
   second account (a container or a private namespace), asserting refusal and unchanged
   owner for the three link cases and the expected owners and modes for the two clean ones.
2. RT-2: the 20-trial race against the reset lines, asserting zero handovers.
3. RT-3: the same shape once the apply step is descriptor-based.
4. RT-4: the stand-in listener test, asserting the tool sends no secret to a listener
   that is not Nomad's (owner check now; certificate pin once part 2b lands).
5. A source guard: fail CI when a script that runs as root uses plain `chown`, `chmod` or
   `install -d` on a path under a service-owned directory.

## 10. Evidence

`01-redteam-evidence/` (hashes in `SHA256SUMS`): the three reproduction scripts,
`rt1-base-*.out` and `rt1-fix-*.out` (five cases each), `rt1-fix.diff`,
`rt1-existing-tests.txt`, `rt2-vault-reset-symlink-race.out`, `rt2-fix.out`,
`rt4-nomad-port-holder.out`. Token values in the outputs are made up for the rig.
