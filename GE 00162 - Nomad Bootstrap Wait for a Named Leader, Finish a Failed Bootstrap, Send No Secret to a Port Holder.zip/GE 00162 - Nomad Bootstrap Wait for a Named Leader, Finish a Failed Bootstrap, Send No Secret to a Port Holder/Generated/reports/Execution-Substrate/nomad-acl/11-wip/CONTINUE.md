# Part 2b: where to pick up (paused 2026-11-24 ~04:15Z for quota)

Branch `claude/project-thread-9slgp8`, pushed at `3ef8a75`. Working tree clean. No PR yet.

- `6f23f9a` part 2b on trunk_dev `0842983` (fully revalidated: `../11-evidence/run-p2b-main.out`; 25/25 mutants; A4 set 8/9, A1c equivalent).
- `9545fc2` fixes for the two automated-review findings on #31 (R31-1 leader wait accepted `""`; R31-2 the tool refused its saved bootstrap secret after a failed bootstrap). New tests in `es/app/nomad_acl_bootstrap_test.go` pass on Nomad 2.1.1 and 2.0.0; 6/6 mutants (`../11-evidence/mutants-cx.txt`).
- `3ef8a75` merge of trunk_dev `6dbeaeb` (PR #38). Clean; this PR's `^[-+]` lines are unchanged.

Stopped mid-way: the post-merge revalidation (`run-p2bx.sh`). Bring-up passed on Nomad 2.1.1 and 2.0.0 at `3ef8a75`; the full es/app run was interrupted.

Next:
1. Fetch trunk_dev. If it moved, merge it (check that the PR's `^[-+]` lines stay the same).
2. Run `run-p2bx.sh` again (it syncs the tree, rebuilds the offline image, then runs bring-up, full es/app, the other packages, real Nomad 2.0.0, root+scripts against `root-m39-fails.txt`, race, vet).
3. Finish the report: `11-draft.md` becomes `../11-part2b-nomad-https.md`. Fill in the placeholders: PRNUM, REVIEW_SECTION (the text is in `review-section.md`), VALIDATION_SECTION (6f23f9a results plus the post-merge run; the Vault flake: `TestSupportedLocalSetupScriptBootstrapsRealSPIREAndVaultDevTarget` failed once under full-suite load and left stray spire processes; after killing them it passed 3 of 3, and a full rerun had only the 2 known failures) and IDENTITY_SECTION (v2 manifest, base = trunk_dev).
4. Open a draft PR into trunk_dev with `prbody-2b.md` (fill in VALIDATION_LINE). Subscribe to it. Ask for the audit, then the red-team.
