# Merge check of ES draft PR #48 at c4aa6b8 (trunk_dev sync + 1127ba0)

Verdict: **ACCEPT**.

- The trunk_dev merge is clean, and it changes none of the PR's bytes
  (Ran).
- `1127ba0` fixes I16-1 and I16-2 and changes nothing else (Ran, Read).
- The guard tests, the ACL/setup set on Nomad 2.1.1 and 2.0.0, es/admission
  and the root package pass at `c4aa6b8`. My seven mutants are still killed
  (Ran).
- CI run 45344348529 on `c4aa6b8` was still in progress at 07:08Z. The
  merge gate must see it green. The run on `fbee014` passed (06:26Z).

Statements are marked **Ran**, **Read** or **Inference**. Evidence paths
are relative to `18-merge-check-evidence/`.

```text
INDEPENDENT AUDIT REPORT
```

## Target

- Repository: evo-agi/Execution-Substrate, draft PR #48, branch
  `claude/nomad-bootstrap-fixes`.
- Head: `c4aa6b8442f20a4f8bb052f8e639e900a5019e2d`, tree `bf30706d…`. It
  is a merge with parents `1127ba0` (one commit on `fbee014`, accepted in
  16) and trunk_dev `a60c216` (#44, #46, #12). It is the pushed branch tip
  (Ran, fetch).
- Recipe v2 (source sha256 `c08597e2…a3ca`, verified), merge-base
  `a60c216`:
  - manifest_sha256
    `7e1872bb461bb83ba9b82f74a185b3c40a89da1229e193614cd11a19d43d89a5`;
  - textual_diff_sha256 `624d3c29…e42a`;
  - 11 paths.
- Scope: the writer's request (06:58Z) for one check covering the byte
  check of the trunk_dev sync and a diff check of `1127ba0`. Writer's
  notes:
  - `17-info-fixes.md` (sha256 `bcfc8d3a…9166`, verified);
  - `18-evidence/sync-check.txt`.

## Sync byte check (Ran, `provenance/sync-facts.txt`)

- `git merge-tree --write-tree 1127ba0 a60c216` gives `bf30706d…`, the
  committed tree, with no conflicts.
- The PR's 11 paths and trunk's 74 paths since `6dbeaeb` do not overlap.
- The PR patch `a60c216..c4aa6b8` is byte-identical to `6dbeaeb..1127ba0`.
- All 11 blobs at `c4aa6b8` equal those at `1127ba0`, and the merge
  changes no trunk path.
- No `.github` path differs.
- The manifest at `c4aa6b8`:
  - Two opening runs are byte-identical and equal the writer's
    `18-evidence/manifest-v2-c4aa6b8.json`.
  - Against the writer's `1127ba0` manifest (`e79ee709…6f11`), only
    `head` differs.
  - After the tests, two closing runs equal the opening runs.
- **Semantic overlap (Read; Inference).** No trunk commit adds a caller of
  `nomad_acl.py` or of the setup wrapper; a grep at `c4aa6b8` finds only
  the PR's known callers. #12's operational provider uses ES's own token
  from Go. The docs already list that path as not covered by the interim
  guard. es/admission, #12's package, passes at `c4aa6b8` (Ran).

## Diff check of 1127ba0 (Read, Ran)

The delta `fbee014..1127ba0` (2 files, +12/−5) is byte-identical to the
writer's `17-evidence/delta-fbee014-1127ba0.diff`.

- **I16-1:** the placement test resets the function name at a column-0
  `}`, and labels a send outside every function "main body".
  - `checked()` and the four required functions are unchanged.
  - The reset sits after the heredoc skip, so a `}` inside a heredoc
    cannot trigger it.
  - My S10 mutant is now reported as `70_linux_setup.sh:754 (main body)`
    (Ran).
- **I16-2:** the bullet is reflowed, every line is 77 characters or fewer,
  and the text is identical after whitespace normalisation (Ran).

## Validation (Ran, as `ci`, at c4aa6b8)

| Run | Result |
| --- | --- |
| `go build ./...`, `go vet ./...`, `GOOS=darwin go vet ./...`; `gofmt -l es/app` | pass; gofmt lists nothing (`tests/build-vet.txt`) |
| `TestNomadACL*`, `TestLinuxSetup*`, `TestSupportedLocalSetup*`, `TestRealNomad*`, `TestSubmitRefusesANomadThatDoesNot*`, `TestSupportedLocalFullReadiness*` on Nomad 2.1.1 | 30 pass; 2 skip (`tests/acl-setup-211.txt`) |
| the same set on Nomad 2.0.0 | 30 pass; 2 skip (`tests/acl-setup-200.txt`) |
| `es/admission` | pass (`tests/admission.txt`) |
| root package | pass (`tests/root-package.txt`) |
| my mutants S3, S3b, S4, S5, S10, S11, S12 | all killed (`mutants/mut18.txt`) |
| CI run 45344348529 on `c4aa6b8` | in progress at 07:08Z (`ci/run-45344348529.txt`) |

- The two skips are the root-only wrapper test (it passed as root in 14 on
  unchanged files) and the SPIRE/Vault supported-local test.
- This batch ran under `setsid` instead of `nohup`. With SIGHUP no longer
  ignored, the Go installer test passes in the batch too, which confirms
  the cause found in 16.

## Findings

None.

## Sensitive material

- The tests use random tokens; the evidence replaces UUIDs with `<uuid>`.
- A scan for UUID-shaped strings and "SecretID" found none.
- No personal data left the container.

## Effect status

- No commit, push, PR comment, review or merge.
- Nothing outside this container changed.

## Report delivery

- Report: `/mnt/project-files/reports/Execution-Substrate/nomad-acl/18-merge-check.md`;
  its sha256 is in the delivery message.
- Evidence checksums: `18-merge-check-evidence/SHA256SUMS.txt`.

## Final verdict

**ACCEPT**

For the merge gate:

- the PR head must equal `c4aa6b8`;
- CI run 45344348529, or a later run on `c4aa6b8`, must be green;
- the PR is squash-merged;
- if trunk_dev moves again first, the next sync gets this same byte check.
