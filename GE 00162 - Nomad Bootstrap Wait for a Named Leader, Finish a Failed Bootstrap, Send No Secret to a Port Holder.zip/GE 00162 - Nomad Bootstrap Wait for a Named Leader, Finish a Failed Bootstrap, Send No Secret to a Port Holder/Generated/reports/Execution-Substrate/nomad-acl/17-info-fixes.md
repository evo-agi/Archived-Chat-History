# Nomad bootstrap fixes (PR #48): the two Info notes of diff check 16

Draft PR #48, branch `claude/nomad-bootstrap-fixes`, head `1127ba0` (one new
commit on `fbee014`, which diff check 16 accepted), base trunk_dev `6dbeaeb`.
trunk_dev is not merged in yet: the coordinator holds #48 until PR 12 has
merged. At #48's turn, the check of this commit can go together with the
byte check of the trunk_dev merge.

Every statement is marked **Ran**, **Read** or **Inference**.

## Changes (delta `17-evidence/delta-fbee014-1127ba0.diff`, 2 files, +12/-5)

- **I16-1.** `TestLinuxSetupChecksNomadsListenerBeforeEveryTokenSend` kept
  the last function's name after that function ended. The name now resets
  at each `}` in column 0. A send outside every function is reported as
  "main body". The script has 19 function headers and 19 such braces
  outside heredocs (Ran, a count). `checked()` and the four required
  functions are unchanged.
- **I16-2.** The port holder guard bullet in
  `.docs/system_overview/configuration.md` is reflowed to under 80
  characters. Its text is unchanged.

## Validation (Ran, in the CI copy as `ci`)

- The two changed tests pass, and so does the root package
  (`logs/run-i16.log`, `logs/run-i16-root.log`).
- A main-body send added after "Qualifying supported substrate baseline"
  is now reported as `70_linux_setup.sh:754 (main body)`
  (`logs/run-i16-mut.log`).
- The 10 mutants of 15 were rerun and are all killed
  (`mutants-48a14-i16.txt`).
- `gofmt` and `go vet ./es/app` are clean.
- `git archive 1127ba0` matches the tested copy.
- CI run 45335217127 on `fbee014` passed (completed 06:26Z). CI on
  `1127ba0` was started by the push.

## Identity

- v2 manifest of `1127ba0` (same recipe and branch name as 15, merge-base
  `6dbeaeb`; two runs byte-identical):
  - manifest_sha256
    `e79ee709ee071bccb633ced241ce003c88100a6de54dd426d92901931e7d6f11`
  - textual_diff_sha256
    `624d3c29a534a0229b774ea3eeaa33fa0074e202014b91e1c962352f8509e42a`
  - 11 files
  - copy: `17-evidence/manifest-v2-1127ba0.json`

## Effects

- Commit `1127ba0` was pushed to `claude/nomad-bootstrap-fixes`.
- Nothing was merged, and trunk_dev was not synced.
