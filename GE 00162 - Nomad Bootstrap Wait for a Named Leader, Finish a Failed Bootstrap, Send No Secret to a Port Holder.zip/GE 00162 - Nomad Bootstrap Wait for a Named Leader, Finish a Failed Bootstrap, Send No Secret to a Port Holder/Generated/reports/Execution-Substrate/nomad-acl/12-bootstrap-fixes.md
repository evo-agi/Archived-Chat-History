# Nomad lock: two bootstrap fixes from the automated review of #31

Draft PR #48, branch `claude/nomad-bootstrap-fixes`, one commit `a79c355` on trunk_dev `6dbeaeb`.
Split out of part 2b (paused) because both affect the box run of the lock.
For audit.

Every statement is **Ran** (executed, output seen), **Read** or
**Inference**.

## 1. Findings and verification

Marking #31 ready started an automated review of `d6fa837` that posted two
P2 comments after the merge. I checked both against the code (Read). Both
are real. Neither weakens the lock; both can leave setup stuck.

**R31-1: the setup script's leader wait accepted an empty leader**
(`scripts/70_linux_setup.sh`, `bootstrap_nomad_acl`).

- Before: `curl … /v1/status/leader | grep -q '"'`. Any quoted answer
  passed, including `""`, which Nomad returns while raft knows no leader
  (Inference: from the review; bring-up's `wait_for_nomad_leader` already
  requires a nonempty leader). A bootstrap sent then fails ("no cluster
  leader") and setup stops. A rerun recovers, because the script resubmits
  its saved secret.
- I did not see `""` on a single-node Nomad 2.1.1. Polling every 20 ms
  from start, and again after a restart, the first answer was already the
  leader (Ran). Inference: it shows on multi-server clusters and after
  leader loss.
- Now: the answer must match `^"[^"]+"$`, the same check as bring-up's.

**R31-2: a bootstrap that never took effect blocked every rerun of the
tool** (`scripts/internal/nomad_acl.py`, `bootstrap_or_load_management`).

- Before: the tool writes its secret to the management token file, then
  calls bootstrap. If that call failed before Nomad installed the secret
  (no leader yet, a lost response), the file stayed. Every later
  `provision` read it, found no management token and refused. Its own
  error said "a rerun can finish or reuse it", which was not true: only
  deleting the file by hand recovered. On the box, that is
  `sudo scripts/nomad_acl_setup.sh` on a Nomad whose ACLs were just
  enabled.
- Now: when the saved secret is not a working management token, the tool
  offers it to `/v1/acl/bootstrap` again. Nomad accepts a bootstrap secret
  only while its ACLs are not bootstrapped (Ran: a bootstrapped Nomad
  answers "bootstrap already done"). An operator's reset procedure also
  re-allows it (Inference: Nomad's documented procedure). In either state
  anyone on loopback could bootstrap anyway, so resubmitting a secret that
  never left the 0600 file opens nothing.
- If Nomad answers "bootstrap already done", the tool refuses and keeps the
  file, because it belongs to the operator. It still removes the file in the
  one case where it wrote a fresh secret in this run, as before. The setup
  script already behaved this way.
- Docs: the management token bullet in
  `.docs/system_overview/configuration.md` now says:
  - both scripts bootstrap only once Nomad names a leader;
  - a rerun finishes a bootstrap that never took effect;
  - a refusal leaves an existing file alone.

## 2. Tests

New file `es/app/nomad_acl_bootstrap_test.go`. In the setup script,
`nomad_token_curl` and `bootstrap_nomad_acl` now sit between
`# BEGIN nomad_acl_bootstrap` and `# END nomad_acl_bootstrap`, so a test
can run them on their own. Until now no test ran that bootstrap.

| Test | Shows |
|---|---|
| `TestLinuxSetupBootstrapsNomadACLOnlyOnceNomadNamesALeader` | Against an HTTP stand-in. While Nomad answers `""`, the bounded wait gives up with "no leader within 2s", sends only leader requests and saves no secret. When the third answer names a leader, the requests are exactly leader, leader, leader, token/self, bootstrap, and the bootstrap carries the saved secret. |
| `TestLinuxSetupBootstrapFinishesWithItsSavedSecret` | Real Nomad with ACLs on, not bootstrapped, and a saved secret Nomad never saw. Setup bootstraps with it, Nomad then reports it as management, and a rerun keeps it. With a different saved secret on that now-bootstrapped Nomad, setup refuses and leaves the file unchanged. |
| `TestNomadACLToolRetriesABootstrapThatNeverTookEffect` | The same two cases for the tool's `provision`. |

Results:

| Run | Result |
|---|---|
| the three new tests, Nomad 2.1.1 and 2.0.0 | pass (Ran) |
| `TestNomadACL*`, `TestSupportedLocalSetupLocks*`, `TestRealNomadRefuses*`, `TestSubmitRefusesANomadThatDoesNot*`, `TestLinuxSetup*` (es/app; they cover the tool's normal bootstrap and the setup script's text checks) | pass (Ran) |
| es/admission static guard and Nomad tests | pass (Ran) |
| root package (docs contract) | pass, no failures (Ran) |
| `go build ./...`, `go vet` for es/app, scripts and root (linux), es/app (darwin) | pass (Ran) |

The full suites were not run locally. Only these two scripts, one docs
paragraph and one new test file changed. CI runs the full "build, vet and
test" check.

**Mutants: 6 of 6 killed** (Ran; `12-evidence/mutantsCXt.py`,
`mutants-cxt.txt`, logs).

| Mutant | Change | Killed by |
|---|---|---|
| CX1 | leader wait back to `grep -q '"'` | `TestLinuxSetupBootstrapsNomadACLOnlyOnceNomadNamesALeader` |
| CX2 | leader pattern `[^"]*` (empty allowed) | same |
| CX3 | setup removes a loaded file on "already done" | `TestLinuxSetupBootstrapFinishesWithItsSavedSecret` |
| CX4 | tool refuses a saved secret without retrying (the old code) | `TestNomadACLToolRetriesABootstrapThatNeverTookEffect` |
| CX5 | tool removes a loaded file on "already done" | same |
| CX6 | tool retries with a new secret, replacing the file | same |

The same fixes also sit on the paused part 2b branch (`9545fc2`), ported
there to Nomad over HTTPS. When part 2b resumes, it takes this PR from
trunk_dev and keeps its own HTTPS versions of these lines.

## 3. Identity

- Base: `6dbeaebdce52b85e85abc8ea3aa2473a45abfcb4` (origin/trunk_dev).
- Head: `a79c3555860d0db1264cb308b4ad811df37d518b` on
  `claude/nomad-bootstrap-fixes`.
- Recipe `governed-execution.audit-patch-manifest.v2`, tool sha256
  `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`
  (verified).
- textual_diff_sha256
  `5c5238840e99edb30823cb17fd4395ad9d4fd2c4724ed04b4c55d73fc0d62c5a`.
- manifest_sha256
  `f8442290ae14ceb1abb89174f919bf737f522c09780f4afedbd6513b285c5086`;
  4 files.
- Two runs byte-identical. The path set equals
  `git diff --name-only base HEAD` (4 = 4), with 0 blob mismatches, and the
  tree was clean afterwards (Ran). Manifest:
  `12-evidence/manifest-v2-a79c355.json`. PR diff: `12-evidence/pr.diff`.
- Before the push: `git archive HEAD` equals the tested copy (Ran).
- CI on `a79c355`: pending at the time of writing.
