# Nomad bootstrap fixes (PR #48): repair of re-check 14 (A14-1)

Draft PR #48, branch `claude/nomad-bootstrap-fixes`, head `fbee014` (one new
commit on `2d6d833`), base trunk_dev `6dbeaeb`. This head is for a diff-only
check of A14-1 (`14-recheck.md`), as the coordinator asked. trunk_dev
(`5d6ad51`, with #44 and #46) is not merged in: the coordinator holds #48
until PR 12 has merged.

Every statement is marked **Ran** (executed, output seen), **Read** or
**Inference**.

## 1. A14-1: the check before the diagnostics is pinned

**Behaviour (Ran).** `report_nomad_cpu_visibility_diagnostics` in
`scripts/70_linux_setup.sh` now sits between its own markers:

- `# BEGIN nomad_cpu_visibility_diagnostics (the tests run this function on its own)`
- `# END nomad_cpu_visibility_diagnostics`

Those two comment lines are the only script change. The test harness
(`runSetupNomadACLSnippet`) now evals that region as well as the bootstrap
region.

`TestLinuxSetupBootstrapSendsNoSecretToAPortHolder` gains a case. It sets
`NOMAD_QUALIFY_TOKEN` to a random token (read from a 0600 file, not from
argv) and runs `report_nomad_cpu_visibility_diagnostics || true`, the same
call the script makes at line 754.

- With a uid that is not the listener's owner, the case requires the
  refusal "not owned by Nomad's user (uid N)" and requires that the holder
  received nothing.
- In the control, with the owner's uid, the holder's first request must be
  `GET /v1/nodes` carrying that token. This proves that the refusal above
  comes from the check.

**Placement (Ran).** The new `TestLinuxSetupChecksNomadsListenerBeforeEveryTokenSend`
(in `es/app/nomad_acl_script_guards_test.go`) scans the script.

- A send is a command that hands `NOMAD_TOKEN` to a program, names
  `X-Nomad-Token`, or carries `BootstrapSecret`. Heredoc bodies and comments
  are skipped. A command continued with `\` counts from its first line.
- Each send must directly follow a check, in one of three forms:
  - `require_nomad_listener ||` earlier in the same command;
  - the statement just before it, `require_nomad_listener || return 1`;
  - the block just before it: `if ! require_nomad_listener; then`, a body
    ending in `return 1`, then `fi`.
- The scan must find sends in `nomad_token_curl`, `bootstrap_nomad_acl`,
  `report_nomad_cpu_visibility_diagnostics` and
  `qualify_supported_substrate`, so it cannot pass by finding none.
- This also pins S4 and S5, the two checks that an earlier check covers
  today. It also catches a new raw token request that bypasses
  `nomad_token_curl` (S8 below).

It finds four sends, and each one passes:

- line 388, in `nomad_token_curl`, after `require_nomad_listener || return 1`;
- lines 447-448, the bootstrap POST, after the check block at 443-446;
- line 506, the diagnostics, with the check earlier on the same line;
- line 636, qualification's Python, after the check block at 632-635.

Lines 522 and 652 name `X-Nomad-Token` inside the Python heredocs, so the
scan skips them. The command that starts each heredoc (506, 636) is the
send.

(Read: those are the only token sends in the script. The callers of
`nomad_token_curl` pass the token through its argument.)

## 2. Mutants (Ran, all in the CI copy as user `ci`)

The runner is `15-evidence/mutants48a14.py` and the results are in
`mutants-48a14.txt`. SETUP = `TestLinuxSetup|TestNomadACLSetup|TestNomadACLShell|TestNomadACLDir`.

| Mutant | Run | Result |
| --- | --- | --- |
| S3 drop the check before the diagnostics (re-check 14's S3) | port holder test only | killed: the holder got the token |
| S3s same mutant | static test only | killed |
| S4 drop the check before qualification's Python | SETUP | killed (static) |
| S5 drop the check before the bootstrap POST | SETUP | killed (static) |
| S6 the check block before qualification's Python no longer returns | SETUP | killed (static) |
| S7 the diagnostics check moved after the Python | SETUP | killed (both tests) |
| S8 qualification's agent/self request as a raw `curl -H "X-Nomad-Token: …"` | SETUP | killed (static) |
| S9 the diagnostics BEGIN marker dropped | SETUP | killed (port holder test) |
| G6 drop the check inside `nomad_token_curl` | static test only | killed |

Before this commit S3, S4 and S5 survived (re-check 14). The 16 mutants
from 13 are unaffected, because no code they touch changed (Read).

## 3. Docs (Info I14-1)

`.docs/system_overview/configuration.md` now says that the setup script
checks the listener "just before each request or batch of requests".

## 4. Validation of `fbee014` (Ran)

| Run | Result |
| --- | --- |
| `TestLinuxSetup\|TestNomadACL\|TestRealNomad\|TestSupportedLocalSetup\|TestSubmitRefuses\|TestSupportedNomad\|TestSupportedLocalFullReadiness\|TestSupportedLocalProof\|TestHealthCheck\|TestRemoteAlpha\|TestGo1265`, Nomad 2.1.1, as `ci` | ok (`logs/run-a14-set.log`) |
| the same set on Nomad 2.0.0 | ok (`logs/run-a14-set200.log`) |
| root package (`docs_contract_test.go` reads the setup script) | ok |
| `gofmt -l es/app`, `go vet ./...`, `GOOS=darwin go vet ./...` | clean |
| the two changed tests and the wrapper test as root | pass |
| `git archive fbee014` compared with the tested CI copy | identical |

The set covers every test that reads `70_linux_setup.sh`
(`operator_scripts_integration_test.go`, `nomad_supported_config_test.go`,
both ACL test files, and `docs_contract_test.go` in the root package; Read).
I did not rerun full es/app or scripts. The only non-test change is two
comment lines, and 13 recorded those runs at `2d6d833`.

CI: run 45331167600 on `2d6d833` was still in progress when `fbee014` was
pushed. The workflow's concurrency group replaces it with the run on
`fbee014`.

## 5. Identity

- Manifest, recipe `governed-execution.audit-patch-manifest.v2` (tool
  sha256 `c08597e2…a3ca`), taken on the branch named
  `claude/nomad-bootstrap-fixes` with upstream `origin/trunk_dev`. Two runs
  are byte-identical, and every blob matches.
  - merge-base: `6dbeaeb`
  - manifest_sha256:
    `d956c5aafbcd737c6fd110bc56eada79dbbcb7dcbb903b4919497661693bcc24`
  - textual_diff_sha256:
    `576ab46ae1521f1bca02b3f3ff75978c5ffa537f5b904abc5703fbf9d0053d18`
  - 11 files
  - copy: `15-evidence/manifest-v2-fbee014.json`
- Delta for the diff-only check: `15-evidence/delta-2d6d833-fbee014.diff`
  (4 files, +124/-4). Whole PR diff: `15-evidence/pr.diff`.
- Token-shaped strings in the saved logs (random test tokens) are replaced
  with `<uuid>`.

## 6. Effects

- Commit `fbee014` was pushed to `claude/nomad-bootstrap-fixes`.
- PR #48 is still a draft. Nothing was merged, and trunk_dev was not synced.
- Nothing outside this container and the branch changed.
