# Nomad bootstrap fixes (PR #48): repair of audit 12, and the RT-4 port holder guard

Draft PR #48, branch `claude/nomad-bootstrap-fixes`, head `2d6d833` (one new
commit on `a79c355`), base trunk_dev `6dbeaeb`. For a check covering A12-1,
A12-2 (audit 12, `12-audit.md`) and RT-4 (whole-trunk red-team,
`trunk-red-team/01-redteam.md` section 5, regression test item 4), as the
coordinator asked.

Every statement is **Ran** (executed, output seen), **Read** or
**Inference**.

## 1. A12-1: the management token's type check is pinned

`TestNomadACLToolRetriesABootstrapThatNeverTookEffect` gains the auditor's
case. On the bootstrapped Nomad, ES's own client token is put into the
management token file. `provision` must then refuse with "does not hold a
working Nomad management token and nomad ACLs were already bootstrapped" and
leave the file unchanged (Ran, real Nomad 2.1.1 and 2.0.0). The auditor's
mutant M6 (drop the `Type == "management"` clause) is killed by this case
(Ran).

## 2. A12-2: provision waits for a named leader and quotes Nomad

- New `wait_for_leader`: before anything else, `provision` asks
  `/v1/status/leader` once a second, for up to `--leader-wait-seconds`
  (default 30). Only a non-empty JSON string counts. `""`, which Nomad
  answers during an election, does not count, and neither does an error
  such as `500 No cluster leader` from a server that has no leader. On
  timeout it refuses: "nomad has no leader after 30s (GET /v1/status/leader
  returned HTTP 500: No cluster leader); rerun once Nomad has elected one".
  It refuses before it saves or sends any secret. Same rule as the setup
  script's wait and bring-up's `wait_for_nomad_leader`.
- `require_acl_enabled` now quotes Nomad's answer: "nomad did not answer as
  an ACL-enabled agent (GET /v1/acl/token/self returned HTTP 500: No
  cluster leader)". It used to give only the status, which pointed at the
  acl block.
- Thanks for the FYI on `500 No cluster leader`. Report 12's wording ("a
  server with no leader answers `""`") was too broad: `""` is the transient
  answer during an election. Both answers are now refused, and the new test
  covers both (section 4).

## 3. RT-4: no token or bootstrap secret to a port holder (interim guard)

While Nomad is down, any local account can listen on 127.0.0.1:4646. The
guard makes the root tools send nothing unless the kernel shows that
Nomad's user owns the socket.

**The ACL tool** (`scripts/internal/nomad_acl.py`):

- Every connection goes through `_NomadsConnection`, an
  `http.client.HTTPConnection` whose `connect()` checks, after the TCP
  handshake and before a single byte is sent, who owns the server side of
  this very connection. It finds the row in `/proc/net/tcp` (or `tcp6`)
  whose local endpoint is our peer and whose remote endpoint is our own
  socket, and reads its uid column. That row is either the pending request
  or the accepted socket. Both carry the listening socket's owner
  (Inference: the kernel's `/proc/net/tcp` code reports a pending request
  with its listener's uid, and an accepted socket is cloned from its
  listener; Ran: the tests see the stand-in's uid, and a root caller sees
  the holder's uid, not its own).
- Checking the connection itself, not the listener beforehand, leaves no
  window between the check and the send.
- It applies to every request, anonymous ones included, so `check` cannot
  be answered by a port holder either.
- Expected owner: new `--nomad-uid` on `provision` and `check`, default 0
  (`nomad.service` runs Nomad as root). On a mismatch: "the process
  listening on http://127.0.0.1:4646 runs as uid 996, not Nomad's uid 0:
  another local account may hold Nomad's port while Nomad is down; nothing
  was sent".
- Callers:
  - `scripts/nomad_acl_setup.sh` passes `NOMAD_USER` (default root);
  - `scripts/72_supported_local_setup.sh` passes
    `SUPPORTED_LOCAL_NOMAD_USER` (default root) to it;
  - `scripts/01_bringup.sh` passes its own uid, because the full profile
    starts Nomad itself as the current user.

**The setup script** (`scripts/70_linux_setup.sh`):

- New `require_nomad_listener`: every LISTEN row in `/proc/net/tcp{,6}` on
  the port of `NOMAD_HTTP_ADDR` must belong to `NOMAD_SERVICE_UID` (0, set
  in the script and not read from the environment). That covers rows bound
  to 127.0.0.1 or a wildcard address (`0.0.0.0`, `::`, or the v4-mapped
  127.0.0.1). At least one row must exist.
- It runs:
  - after the leader wait, before the secret is read or generated;
  - before the bootstrap POST;
  - inside `nomad_token_curl`, so every request that carries the
    management token checks first, qualification included;
  - before both Python blocks that send the management token.
- curl cannot be asked about its own connection, so this is a check just
  before each request, with a short window in which Nomad would have to
  stop and another account take the port. Recorded as a limit.
- The awk compares the kernel's hex addresses as little-endian words. The
  supported hosts (x86_64, aarch64) are little-endian; the script already
  supports only those two.

**Limits (Inference, from the code):**

- ES's own Nomad client (its client token) and the shell readiness helpers
  (`scripts/internal/nomad_acl.sh`, observer token) do not get the check. A
  holder would get ES's submit-only token or the read-only observer token.
  RT-4 is about the root tools and the management token. The red-team names
  ES as possible, and part 2b (HTTPS with a pinned server key) covers all of
  them.
- Both checks assume the tools run in Nomad's network namespace, the
  default on a host.
- Part 2b replaces this guard. When it resumes, the guard can stay as
  defence in depth or go; that is a decision for then.

## 4. Tests

New or changed in `es/app/nomad_acl_bootstrap_test.go`:

| Test | Shows |
|---|---|
| `TestNomadACLToolSendsNothingToAPortHolder` | A stand-in run by the test's user, with the tool told Nomad runs as another uid. The first run saves no secret and the holder gets no request. With a saved management token, `provision` and `check` send nothing. When root runs the tool with its default (uid 0) through passwordless sudo, against a port the test's user holds, it refuses with the holder's uid and sends nothing; this is the red-team's case. Control: with the real owner named, the same stand-in gets the requests and the saved token. |
| `TestLinuxSetupBootstrapSendsNoSecretToAPortHolder` | The setup script's bootstrap against a holder sends only anonymous leader questions and saves no secret. `nomad_token_curl` sends nothing to a holder, and reaches a listener whose owner is right (control). |
| `TestNomadACLToolWaitsForANamedLeader` | `500 No cluster leader`: refusal after the wait with Nomad's text, only leader questions, no secret saved. `""` twice, then a named leader: exactly three leader questions, then token/self. A 500 on token/self is quoted. |
| `TestNomadACLToolRetriesABootstrapThatNeverTookEffect` | A12-1 case added (section 1). |

The existing callers pass the test's uid: the harness's provision, the
`check` calls, the `runNomadACLTool` helper (adds `--nomad-uid` with the
test's uid to `provision` and `check` unless the call names one), and the
supported-local validation (`SUPPORTED_LOCAL_NOMAD_USER`). The wrapper test
now also requires `--nomad-uid 0` on every tool call, and the
supported-local lock test expects `NOMAD_USER=root` in the wrapper command.

**Mutants: 16 of 16 killed** (Ran; `13-evidence/mutants48r.py`,
`mutants-48r.txt`, logs). These are the 6 from report 12, run again on the
new tests, and 10 new:

| Mutant | Change | Killed by |
|---|---|---|
| G1 | tool skips the owner check | `TestNomadACLToolSendsNothingToAPortHolder` |
| G2 | tool accepts any owner | same |
| G3 | tool reads its own socket's row instead of the server's | same (root-caller case) |
| G4 | shell `require_nomad_listener` always passes | `TestLinuxSetupBootstrapSendsNoSecretToAPortHolder` |
| G5 | shell bootstrap without the check before the secret | same (a secret is saved) |
| G6 | `nomad_token_curl` without the check | same |
| L1 | provision does not wait for a leader | `TestNomadACLToolWaitsForANamedLeader` |
| L2 | `""` counts as a leader | same |
| R1 | ACL refusal without Nomad's text | same |
| M6 | management check without the Type clause (A12-1) | `TestNomadACLToolRetriesABootstrapThatNeverTookEffect` |

Not mutated:

- **The second shell check, before the bootstrap POST.** It narrows the
  window after the first check. A test cannot drive that race, so with the
  first check in place removing it changes nothing observable.
- **The awk's wildcard rows.** Without them a holder on a wildcard address
  is not "found", and the check refuses anyway as "missing or not owned".

## 5. Validation

All at `2d6d833` in this container (Go 1.26.5, user `ci`, Nomad 2.1.1
unless noted; `13-evidence/run-bf2.out`, logs in `13-evidence/logs/`).

| Run | Result |
|---|---|
| the six tests in `nomad_acl_bootstrap_test.go` | pass (Ran) |
| full-profile bring-up (passes `--nomad-uid $(id -u)`), offline image rebuilt from this tree, Nomad 2.1.1 and 2.0.0 | pass on both (Ran) |
| es/app `TestLinuxSetup*`, `TestNomadACL*`, `TestRealNomad*`, `TestSupportedLocalSetup*` (the real-sudo supported-local validation included), `TestSubmitRefuses*`, `TestSupportedNomad*`, `TestSupportedLocalFullReadiness*`, `TestSupportedLocalProof*`, `TestHealthCheck*`, `TestRemoteAlpha*`, on Nomad 2.1.1 and on 2.0.0 | pass on both (Ran) |
| full `go test ./es/app/` | only the 2 known environment failures (`TestBringupScriptUpCheckDownFullProfile` without the image recipe, `TestSubmitFlowMountsGovernedArtifactAndLifecycleWithInstalledSourceIdentity`) (Ran) |
| root package | pass (Ran) |
| `scripts/` | 28 failures: the known 27 plus `TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveRuntimeKeepsEachIdentityClassification`, a test PR #38 added. Its whole `TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractive*` family fails the same 9 tests on base `6dbeaeb` in this container ("local prerequisite failed") (Ran: `base-ra-fails.txt` equals `bf2-ra-fails.txt`) |
| es/admission (static guard included) | pass (Ran) |
| `go vet ./...`, `GOOS=darwin go vet ./...` | pass (Ran) |
| a manual run as root with the default uid 0 against a listener the `ci` account holds | refused with "runs as uid 1500, not Nomad's uid 0", nothing created, no request reached the listener; with `--nomad-uid` set to ci's uid, the request reached it (Ran) |

CI on the previous head `a79c355` was green (check suite completed, no
failure). trunk_dev has moved to `c610e1d` (PR #44, one reliablesubmit test
file, no overlap with this PR; a trial merge is clean). It is not merged
here, because trunk_dev is frozen until PR #46 lands and the branch must be
brought up to date at the gate anyway.

## 6. Identity

- Base: `6dbeaebdce52b85e85abc8ea3aa2473a45abfcb4` (the merge-base with
  origin/trunk_dev).
- Head: `2d6d8330d5a88c673e204bc56aa5112c4d509b83` on
  `claude/nomad-bootstrap-fixes`.
- Recipe `governed-execution.audit-patch-manifest.v2`, tool sha256
  `c08597e2…a3ca` (verified).
- textual_diff_sha256
  `30dc9f395a988944b6979e5d816cfc58b110e64812a17efa03414ebdb0a08c4e`.
- manifest_sha256
  `c0c250e1b1f64250e9b31ee98bc3db6945510e59d9780865842872a8fd99a294`;
  11 files.
- Two runs byte-identical. The path set equals `git diff --name-only base
  HEAD` (11 = 11), with 0 blob mismatches and a clean tree afterwards (Ran).
- `git archive HEAD` equals the tested copy (Ran).
- Files: `13-evidence/manifest-v2-2d6d833.json`. Delta from the audited
  head: `13-evidence/delta-a79c355-2d6d833.diff`. Whole PR:
  `13-evidence/pr.diff`.
