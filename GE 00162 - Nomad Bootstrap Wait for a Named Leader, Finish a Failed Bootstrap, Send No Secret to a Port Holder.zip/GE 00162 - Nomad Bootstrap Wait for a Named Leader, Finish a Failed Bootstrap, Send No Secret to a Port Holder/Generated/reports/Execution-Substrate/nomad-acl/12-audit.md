# Audit of ES draft PR #48 (Nomad lock bootstrap fixes) at a79c355

Verdict: **BLOCK** on one Low, a test gap in the PR's own diff (A12-1).
Both fixes are correct, and the code is safe as it stands.

- R31-1 (the setup script took `""` for a leader) is fixed. The wait now
  requires a named leader, the same check bring-up uses, and the tests
  catch it when the check is loosened or removed.
- R31-2 (the ACL tool refused every rerun after a bootstrap that never took
  effect) is fixed. On real Nomad 2.1.1 and 2.0.0, the base code refuses a
  saved secret that Nomad never installed, and the PR's code finishes the
  bootstrap with that same secret. Both scripts still refuse a secret on a
  Nomad bootstrapped with another one, and keep the file.
- A12-1 (Low): the PR rewrote the line that checks a saved token is a
  management token, and no test pins it any more. Accepting any token there
  survives every test; with a client token in the file, `provision` then
  refuses with a wrong reason (Ran). The fix is one test case.
- The sweep found no other readiness check that accepts an empty leader,
  and no other recovery path that blocks reruns. It found one pre-existing
  Low outside the diff, A12-2: on a Nomad with no leader, `provision`
  refuses with "did not answer as an ACL-enabled agent", which points the
  operator at the ACL config instead of the missing leader. It fails
  closed, and a rerun works. Recommend fixing it in the same commit.
- CI run 45325575891 on `a79c355` was still running at 04:38Z.

Every statement is marked **Ran** (I executed it and saw the output),
**Read** (I read code, docs or logs) or **Inference** (reasoned from cited
facts, not observed directly). Evidence paths are relative to
`12-audit-evidence/`.

```text
INDEPENDENT AUDIT REPORT
```

## Repository / audit target

- Repository: evo-agi/Execution-Substrate, draft PR #48, branch
  `claude/nomad-bootstrap-fixes`.
- Base: `6dbeaebdce52b85e85abc8ea3aa2473a45abfcb4` (trunk_dev, the
  merge-base; PR #31 merged as `0842983`, then PR #38).
- Topic: `a79c3555860d0db1264cb308b4ad811df37d518b`, tree
  `bee73d089613f5ca1e0df6104ac82084a3abd5aa`, one commit. It is the PR head
  (Ran, GitHub API).
- Recipe `governed-execution.audit-patch-manifest.v2`, source sha256
  `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`
  (verified). textual_diff_sha256
  `5c5238840e99edb30823cb17fd4395ad9d4fd2c4724ed04b4c55d73fc0d62c5a`;
  manifest_sha256
  `f8442290ae14ceb1abb89174f919bf737f522c09780f4afedbd6513b285c5086`;
  4 paths.
- Scope (coordinator, 04:20Z): a fresh read-only correctness audit of the
  4-file fix, including whether any other readiness check or recovery path
  in the merged Nomad lock has the same flaw; proportionate to the change.
- Writer's report: `12-bootstrap-fixes.md`, sha256
  `7bb83cd1146316dc6ab09d2054bc3b17dc9e3bf6cf231870088136a0a31dc59e`.

## Audit posture

Read-only: nothing committed, pushed or commented; no subagents; nothing
on the box or any live service. Everything ran in this container: local
clones, disposable Nomad servers on loopback (2.1.1 and 2.0.0) and the
PR's own test harness. Mutants ran one at a time in a scratch clone,
restored after each.

## Provenance reproduction (Ran)

- The pushed tip equals the reported tip; base `6dbeaeb` is the
  merge-base; no `.github` path changes.
- With the branch checked out under its own name, HEAD at base
  (`reset --mixed`) and upstream `origin/trunk_dev`, two recipe runs at
  `umask 022` are byte-identical and equal to the writer's
  `12-evidence/manifest-v2-a79c355.json`.
- Method note: my first two runs used a local branch with another name and
  gave a different manifest_sha256 (`e39a3146…`) with the same textual diff
  and file entries, because the manifest records the branch name. I deleted
  those outputs and reran under `claude/nomad-bootstrap-fixes`.

## Coverage

- Read: the whole diff; `bootstrap_nomad_acl` in `70_linux_setup.sh`;
  `bootstrap_or_load_management`, `_bootstrap`, `require_acl_enabled`,
  `require_management` and `ensure_client_token` in `nomad_acl.py`; the new
  test file; every `/v1/status/leader` use in the scripts; bring-up's
  readiness, the setup script's qualify step and `nomad_acl_state_check`;
  `nomad_acl_setup.sh` and how supported-local setup calls it; the
  supported-local proof's leader evidence; the writer's report and PR body.
- Ran: provenance; a real-Nomad probe of a server that has no leader, then
  the same data directory with a leader (both versions, base and head);
  the new tests on both versions; the ACL tool, setup, supported-local
  lock and readiness tests; root package; build and vet; six mutants.
- Read through the GitHub API: the PR and its CI run.

## Findings

### The two fixes

**R31-1: fixed.**

- Read: the loop now reads the answer into `leader` and requires
  `^"[^"]+"$`, exactly bring-up's `wait_for_nomad_leader`
  (`bringup.sh:441`). `curl --fail` still makes an HTTP error count as no
  leader.
- Ran, real Nomad (`probes/leaderless-*.txt`): a server that has never had
  a leader answers `/v1/status/leader` with HTTP 500 "No cluster leader",
  not `""`, on both versions. In that state base and head both wait and
  give up ("no leader within 3s") and save nothing, because `curl --fail`
  already rejected the 500. So the old pattern failed only on a 200 `""`
  answer. I could not produce one on a single server, nor could the
  writer. It is the transient answer the review describes (Inference: from
  how Nomad forwards the request to the leader). The PR's stand-in test
  models it, and the new pattern is right for both answers.
- Ran: mutants M1 (pattern allows `""`) and M2 (no wait) are both killed
  by `TestLinuxSetupBootstrapsNomadACLOnlyOnceNomadNamesALeader`.

**R31-2: fixed.**

- Read: when the saved secret is not a working management token, the tool
  now offers it to `/v1/acl/bootstrap` (`_bootstrap(..., created=False)`).
  On 200 it confirms the secret is management. On "bootstrap already done"
  it removes the file only if this run created it, and otherwise refuses
  with a message that the file does not hold the management token. Any
  other answer keeps the file and says a rerun can finish.
- Ran, real Nomad, both versions (`probes/leaderless-*.txt`): with a saved
  secret Nomad never installed (token/self 403) on an unbootstrapped Nomad,
  base refuses ("does not hold a working Nomad management token") and
  head bootstraps with that same secret, which then resolves as
  management; a rerun keeps it. With another saved secret on that
  bootstrapped Nomad, the tool and the setup script both refuse and leave
  the file unchanged. With no file on a bootstrapped Nomad, the tool
  refuses and leaves no file behind.
- Security (Inference): resubmitting the saved secret opens nothing. Nomad
  accepts a bootstrap only while ACLs are not bootstrapped, and in that
  state anyone on loopback could bootstrap anyway. The secret is the one
  already in the 0600 file. `check` never bootstraps: only `provision`
  calls this path (`nomad_acl.py:671`; `command_check` uses
  `require_management`) (Read).
- Ran: mutants M4 (pre-fix refusal) and M5 (tool removes the operator's
  file) are killed by `TestNomadACLToolRetriesABootstrapThatNeverTookEffect`;
  M3 (setup removes the operator's file) by
  `TestLinuxSetupBootstrapFinishesWithItsSavedSecret`. M6 survives: A12-1.
- Docs (Read): the `configuration.md` bullet matches the code. Its "It
  bootstraps only once Nomad names a leader" is about the setup script,
  which is right; the tool does not wait (A12-2).

**A12-1 (Low, in the diff): the management-type check on a saved token is
untested.**

- Before the PR, the load path called `require_management`, the same
  function `check` uses, and `check`'s "management token is not one" case
  pinned it. The PR replaced that call with an inline condition
  (`nomad_acl.py:337-339`), which no test reaches with a 200 answer: every
  new case gives Nomad a secret it does not know (403).
- Mutant M6 drops `document.get("Type") == "management"` and survives all
  three new tests (Ran, `mutants/mut12.txt`).
- What M6 does (Ran, Nomad 2.1.1, `probes/client-in-management-file-2.1.1.txt`):
  with ES's client token saved in the management file on a bootstrapped
  Nomad, the head refuses "the management token file does not hold a
  working Nomad management token and nomad ACLs were already
  bootstrapped". The mutant takes the client token as management and fails
  at the first write, "nomad POST /v1/namespace/es-submit-v1 returned HTTP
  403". It fails closed and changes nothing, so this is a coverage gap,
  not a hole; but the check the PR wrote is not pinned.
- Fix: one more case in `TestNomadACLToolRetriesABootstrapThatNeverTookEffect`
  (or the deviation table): a client token in the management file on a
  bootstrapped Nomad must be refused with the "does not hold a working
  Nomad management token" text and leave the file unchanged.

### Sweep: the same flaw elsewhere in the merged lock

Readiness checks that read the leader (Read):

| Check | Empty or failed leader |
| --- | --- |
| bring-up `wait_for_nomad_leader` (`bringup.sh:441`), before provision | needs `^"[^"]+"$`: waits |
| bring-up check and `10_health_check.sh` (`bringup.sh:294-329`) | `curl --fail-with-body`, then `not leader.strip()`: "nomad: leader missing" |
| setup's qualify step (`70_linux_setup.sh:566` and its Python) | `curl --fail-with-body`, then `not leader.strip()`: refuses |
| supported-local proof evidence (`73_supported_local_proof.sh:704`) | records `leader_present` true or false; evidence after readiness passed, not a gate |

None accepts an empty leader.

Recovery paths (Read; Ran where noted):

- Setup script bootstrap: reuses a saved secret; removes the file only when
  it created it and Nomad says "already done" (Ran, both versions).
- Tool management token: fixed by this PR (above).
- ES and observer tokens (`ensure_client_token`): Nomad creates the token,
  then the tool writes the file, then deletes every other live token with
  that name or policy. If the write fails, a rerun creates another and
  deletes the orphan. Rotation and a token with roles take the same path.
  No partial failure blocks a rerun.
- `check`: read-only apart from its short-lived probe tokens; no bootstrap.

**A12-2 (Low, pre-existing in #31): a leaderless Nomad gets the wrong
reason.** `provision` does not wait for a leader. On a Nomad with none,
`require_acl_enabled` gets HTTP 500 from `/v1/acl/token/self` and refuses
with "nomad did not answer as an ACL-enabled agent (GET
/v1/acl/token/self returned HTTP 500)" (Ran, both versions). That points at
the `acl` block, not the missing leader. Bring-up waits for a leader before
calling the tool, but the box wrapper `nomad_acl_setup.sh`, and
supported-local setup through it, call it directly (Read).

- It fails closed, before writing any file, and a rerun once Nomad has a
  leader succeeds, so nothing is stuck. On a single server the window is
  short: the writer saw a leader on the first answer.
- Fix (either): include Nomad's error text in that refusal (here "No
  cluster leader"), or have `provision` wait for a named leader as
  bring-up does. It is outside this PR's diff; the coordinator decides
  whether it rides in #48. I recommend it does, since #48 must change
  anyway for A12-1 and this is the same path.

### New findings in the PR's diff

A12-1 (above).

### Observations

- **O12-1, what R31-1's test models.** The stand-in answers 200 `""`. Real
  Nomad without a leader answers 500, which the old code already handled
  (above). The test still pins the right behaviour; it is not evidence that
  `""` was the box's failure.

## Validation assessment

All runs as user `ci` at `a79c355`, Go 1.26.5. Evidence: `tests/`,
`mutants/`, `probes/`, `ci/`.

| Run | Result |
| --- | --- |
| `go build ./...`, `go vet ./...`, `GOOS=darwin go vet ./...` | pass (`tests/build-vet.txt`) |
| the three new tests, Nomad 2.1.1 | pass (`tests/new-211.txt`) |
| the three new tests, Nomad 2.0.0 | pass (`tests/new-200.txt`) |
| `TestNomadACL*`, `TestLinuxSetup*`, `TestSupportedLocalSetupLocks*`, `TestRealNomadRefuses*`, `TestSubmitRefusesANomadThatDoesNot*`, `TestSupportedLocalFullReadiness*` (es/app, 2.1.1) | 22 pass; the root-only wrapper test skips as `ci` (`tests/acl-setup-211.txt`) |
| root package (docs contract) | pass (`tests/root-package.txt`) |
| leaderless probe, base and head, both versions | as above (Ran) |
| CI run 45325575891 | in progress at 04:38Z (Read, GitHub API; `ci/run-45325575891.txt`) |

Mutants (Ran, `mutants/mut12.txt`), each against the three new tests:

| Mutant | Result |
| --- | --- |
| M1 setup leader pattern allows `""` | killed |
| M2 setup leader wait removed | killed |
| M3 setup removes an existing file on "already done" | killed |
| M4 tool refuses a saved secret without retrying (pre-fix code) | killed |
| M5 tool removes an existing file on "already done" | killed |
| M6 tool takes any working saved token as management | **survived** (A12-1) |

Not run: the full es/app suite and the full-profile bring-up. The PR
changes two scripts' bootstrap paths, one docs bullet and adds one test
file; CI runs the full check.

Closing manifest (Ran): after the tests, probes and mutants, two more
runs with HEAD at `6dbeaeb` are byte-identical to the opening ones. Every
clone is clean and no probe directory is left (`provenance/`).

## Sensitive-material handling

The probe kept every secret in 0600 files under a temporary directory it
removed, and printed statuses, return codes and refusal texts only, with
accessor IDs replaced by `<uuid>`. Scan of the evidence for UUID-shaped
strings and "SecretID": none outside field names and mutant names. No personal data left the container.

## Remaining uncertainty

- No one has produced a 200 `""` from Nomad here; the fix covers it on the
  strength of the review's description and Nomad's forwarding (Inference).
- A multi-server cluster was not tested.

## Confidence

- Provenance: high.
- Fixes: high, on real Nomad of both versions, with base reproducing the
  bug; five of six mutants pinned by tests.
- Sweep: high for the scripts read; the sweep covered every leader read
  and every token-writing path in the lock.

## Effect status

No commit, push, PR comment, review or merge. Nothing outside this
container changed.

## Report delivery

`/mnt/project-files/reports/Execution-Substrate/nomad-acl/12-audit.md`;
sha256 in the delivery message. Evidence checksums in
`12-audit-evidence/SHA256SUMS.txt`.

## Final verdict

**BLOCK**

To close it:

- A12-1: add the test case above; M6 must then fail it.
- A12-2 (recommended in the same commit): name Nomad's error, or wait for a
  leader, in `provision`.
- Then a diff-only check of the new commit and green CI on it.
