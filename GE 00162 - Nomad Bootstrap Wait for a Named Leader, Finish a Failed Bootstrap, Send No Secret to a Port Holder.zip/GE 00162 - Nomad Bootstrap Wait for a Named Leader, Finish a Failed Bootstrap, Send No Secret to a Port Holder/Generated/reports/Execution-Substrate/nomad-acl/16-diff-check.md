# Diff-only check of ES draft PR #48 at fbee014 (A14-1 repair)

Verdict: **ACCEPT**.

- A14-1 is closed.
  - The new behaviour test runs the setup script's diagnostics against a
    port held by the wrong user and requires 0 requests.
  - The new placement test requires every token send in the script to
    follow a listener check.
  - My seven mutants are all killed, including two the writer did not try:
    an inverted guard that keeps the text, and a new raw curl in a new
    function (Ran).
- The I14-1 docs wording is fixed (Read).
- The manifest reproduces, equal to the writer's (Ran).
- CI run 45335217127 on `fbee014` was still in progress at 05:54Z. The
  merge gate must see it green.

Statements are marked **Ran**, **Read** or **Inference**. Evidence paths
are relative to `16-diff-check-evidence/`.

```text
INDEPENDENT AUDIT REPORT
```

## Target

- Repository: evo-agi/Execution-Substrate, draft PR #48, branch
  `claude/nomad-bootstrap-fixes`.
- Head: `fbee01454858aaeab5288777a95f0d4c6a0a58ea`, tree `dd7b68b5…`. It
  is one commit on `2d6d833`, re-checked in 14. Base `6dbeaeb`.
- Recipe v2 (source sha256 `c08597e2…a3ca`, verified):
  - manifest_sha256
    `d956c5aafbcd737c6fd110bc56eada79dbbcb7dcbb903b4919497661693bcc24`;
  - textual_diff_sha256 `576ab46a…0d18`;
  - 11 paths.
- Scope: the writer's request (05:45Z) for a diff-only check of the A14-1
  repair. Writer's report: `15-repair.md` (sha256 `db4567b8…31e6`,
  verified).

## Provenance (Ran)

- Two opening runs, on a local branch with the PR's name, are
  byte-identical and equal the writer's `15-evidence/manifest-v2-fbee014.json`.
- After the tests and mutants, two closing runs equal the opening runs.
- The delta `2d6d833..fbee014` (4 files, +124/−4) is byte-identical to the
  writer's `delta-2d6d833-fbee014.diff`.
- No `.github` path changed (`provenance/facts.txt`).

## The delta (Read)

- **`70_linux_setup.sh`:** only two comment lines,
  `# BEGIN/END nomad_cpu_visibility_diagnostics`, around the diagnostics
  function. The test harness now evals that region as well.
- **Behaviour case** in `TestLinuxSetupBootstrapSendsNoSecretToAPortHolder`:
  - It reads `NOMAD_QUALIFY_TOKEN` from a 0600 file and runs
    `report_nomad_cpu_visibility_diagnostics || true`, the script's own
    call.
  - With a uid that is not the owner, it requires the refusal text and 0
    requests.
  - In the control, the first request must be `GET /v1/nodes` carrying
    that token.
- **Placement test** `TestLinuxSetupChecksNomadsListenerBeforeEveryTokenSend`:
  - It finds each command, outside heredocs and comments, that carries
    `NOMAD_TOKEN=`, `X-Nomad-Token` or `BootstrapSecret`.
  - Each one must follow a check: `require_nomad_listener ||` earlier in
    the same command, `require_nomad_listener || return 1` just before it,
    or the exact `if ! require_nomad_listener; then … return 1 fi` block
    just before it.
  - It must find sends in four named functions, so it cannot pass by
    finding none.
- **Scan coverage.** I replicated the scan's heredoc tracking in Python
  (Ran). It opens and closes all three heredocs correctly (lines 283–336,
  506–544, 636–699). It reads the whole file to line 859. It reports
  exactly the four sends at 388, 448, 506 and 636. The here-string at 448
  (`<<<"{…`) does not start a false heredoc.
- **Docs:** "before each request or batch of requests" (I14-1).

## Mutants (Ran, as `ci`; `mutants/mut16.txt`)

All seven were run against the two guard tests.

| Mutant | Result |
| --- | --- |
| S3 guard before the diagnostics removed | killed by both tests (behaviour: the token reached the holder) |
| S3b that guard inverted, `if require_nomad_listener \|\| …`, so the text is still there | killed by the behaviour test (the placement test alone would accept it, as expected of a text check) |
| S4 check block before qualification's Python removed | killed (placement) |
| S5 check block before the bootstrap POST removed | killed (placement) |
| S10 new `NOMAD_TOKEN=… nomad node status` in the script's main body | killed (placement) |
| S11 `nomad_token_curl`'s check made `\|\| true` | killed by both |
| S12 new function with a raw `curl -H "X-Nomad-Token: …"` | killed (placement) |

The tree was clean after the batch. The writer's ten mutants
(`15-evidence/mutants-48a14.txt`) overlap with S3–S5 and add S6–S9 and G6
(Read).

## Validation (Ran, as `ci`)

| Run | Result |
| --- | --- |
| `go build ./...`, `go vet ./...`, `GOOS=darwin go vet ./...`; `gofmt -l` on the two changed Go files | pass; gofmt lists nothing (`tests/build-vet.txt`) |
| the two guard tests on Nomad 2.1.1 and 2.0.0 | pass (`tests/new-211.txt`, `tests/new-200.txt`) |
| `TestNomadACL*`, `TestLinuxSetup*`, `TestSupportedLocalSetup*`, `TestRealNomad*`, `TestSubmitRefusesANomadThatDoesNot*`, `TestSupportedLocalFullReadiness*`, interactively | pass |
| root package | pass (`tests/root-package.txt`) |
| CI run 45335217127 on `fbee014` | in progress at 05:54Z (`ci/run-45335217127.txt`); the run on `2d6d833` was cancelled by this push |

**The installer test failure is this container's, not the PR's.**
`TestLinuxSetupGoToolchainInstallerHermeticPreflightAndCleanup` fails
whenever my runner starts under `nohup`. That covers the batch files
`tests/acl-setup-211.txt`, `tests/acl-setup-200.txt` and
`tests/flake-probe-{1,2}.txt`, and the unexplained failure I noted in 14.

- `nohup` leaves SIGHUP ignored: `trap -p HUP` prints `trap -- '' SIGHUP`.
- The installer correctly refuses to run under a HUP trap it does not own
  ("pre-existing HUP trap prevents Go archive installation").
- Run alone under `nohup`, the test fails the same way on base `6dbeaeb`.
  Run without `nohup`, it passes on the head (Ran,
  `tests/nohup-installer.txt`).
- Every other test in those files passed.

## Findings in the delta

None.

## Observations (Info, no action required)

- I16-1: the placement test's function label never resets after a
  function ends, so a send in the main body is reported under the last
  function's name. S10's message names `qualify_supported_substrate`. This
  affects messages only.
- I16-2: the docs edit left one source line of about 95 characters
  (`configuration.md:636`). It renders the same.

## Sensitive material

- The tests and mutants use random tokens; the evidence replaces UUIDs with
  `<uuid>`.
- A scan of the evidence for UUID-shaped strings and "SecretID" found none.
- No personal data left the container.

## Effect status

- No commit, push, PR comment, review or merge.
- Nothing outside this container changed.

## Report delivery

- Report: `/mnt/project-files/reports/Execution-Substrate/nomad-acl/16-diff-check.md`;
  its sha256 is in the delivery message.
- Evidence checksums: `16-diff-check-evidence/SHA256SUMS.txt`.

## Final verdict

**ACCEPT**

For the merge gate:

- the PR head must equal `fbee014`, and CI must be green on it;
- trunk_dev is now `5d6ad51` (#44, #46). If the branch is brought up to
  date before the merge, that merge gets the same byte check as round 10.
