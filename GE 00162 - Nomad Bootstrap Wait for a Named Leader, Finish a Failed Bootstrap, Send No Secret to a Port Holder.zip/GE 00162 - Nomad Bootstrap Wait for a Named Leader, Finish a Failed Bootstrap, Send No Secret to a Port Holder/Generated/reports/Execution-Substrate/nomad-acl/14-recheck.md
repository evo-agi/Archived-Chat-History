# Re-check of ES draft PR #48 (Nomad bootstrap fixes) at 2d6d833

Verdict: **BLOCK** on one Low in the PR's own diff (A14-1), a test gap of
the same kind as A12-1.

- A12-1 is closed. The new case kills M6 on real Nomad (Ran).
- A12-2 is closed. On a real Nomad with no leader, `provision` now waits,
  then refuses with "nomad has no leader after 30s (GET /v1/status/leader
  returned HTTP 500: No cluster leader)", and saves nothing. Once the
  leader is elected, `provision` and `check` pass (Ran, 2.1.1).
- The RT-4 tool guard is correct. Root ran the tool with its default
  `--nomad-uid 0` against a port held by another account: it refused and
  the holder received 0 bytes. That held for a holder that answers, one that
  never accepts, and one that accepts and closes. Against a root-owned
  holder (the control), the tool sent its requests (Ran).
- The setup script's guard works on every path I drove (Ran).
- A14-1 (Low, in the diff): no test reaches the guard in
  `report_nomad_cpu_visibility_diagnostics` (`70_linux_setup.sh:505`).
  - That guard is load-bearing. Setup runs the diagnostics after
    qualification fails, and qualification can fail after the bootstrap set
    the management token, for example when Nomad stops.
  - With the guard removed, root's diagnostics sent the management token to
    a port held by `ci` (Ran). The mutant survives every ACL and setup test
    (Ran).
- CI run 45331167600 on `2d6d833` was still in progress at 05:31Z.

Statements are marked **Ran**, **Read** or **Inference**. Evidence paths
are relative to `14-recheck-evidence/`.

```text
INDEPENDENT AUDIT REPORT
```

## Target

- Repository: evo-agi/Execution-Substrate, draft PR #48, branch
  `claude/nomad-bootstrap-fixes`.
- Head: `2d6d8330d5a88c673e204bc56aa5112c4d509b83`, tree `dc138dc5…`. It
  is one commit on `a79c355`, the head audited in 12. Base:
  `6dbeaebdce52b85e85abc8ea3aa2473a45abfcb4`.
- Recipe `governed-execution.audit-patch-manifest.v2`, source sha256
  `c08597e2…a3ca` (verified).
  - manifest_sha256
    `c0c250e1b1f64250e9b31ee98bc3db6945510e59d9780865842872a8fd99a294`;
  - textual_diff_sha256
    `30dc9f395a988944b6979e5d816cfc58b110e64812a17efa03414ebdb0a08c4e`;
  - 11 paths.
- Scope: the writer's request (05:11Z) to check A12-1, A12-2 and the RT-4
  interim guard. Writer's report: `13-repair.md` (sha256 `74c01a1a…83bc`,
  verified).

## Provenance (Ran)

- Setup: a local branch with the PR's name, upstream `origin/trunk_dev`,
  HEAD reset `--mixed` to base, `umask 022`.
- Two opening runs are byte-identical, and they equal the writer's
  `13-evidence/manifest-v2-2d6d833.json`.
- After all tests, probes and mutants, two closing runs equal the opening
  runs.
- No `.github` path changed (`provenance/facts.txt`).

## A12-1: the saved token's type check (Read, Ran)

- `TestNomadACLToolRetriesABootstrapThatNeverTookEffect` (from
  `nomad_acl_bootstrap_test.go:235`) now puts ES's client token in the
  management file on the bootstrapped real Nomad. It requires the "does not
  hold a working Nomad management token and nomad ACLs were already
  bootstrapped" refusal and an unchanged file. That is the case 12 asked
  for (Read).
- Mutant M6 drops `document.get("Type") == "management"`
  (`nomad_acl.py:470`). The case kills it, and the test's failure quotes
  the mutant's 403 at the namespace write (Ran, `mutants/mut14.txt`).
- The test passes on Nomad 2.1.1 and 2.0.0 (Ran, `tests/new-211.txt`,
  `tests/new-200.txt`).

## A12-2: provision on a Nomad with no leader (Read, Ran)

- `wait_for_leader` (`nomad_acl.py:438`) runs before anything else in
  `provision` (`:802`). It counts only a non-empty JSON string, and on
  timeout it refuses with Nomad's status and text.
- `require_acl_enabled` (`:419`) now quotes Nomad's answer too.
- Real Nomad 2.1.1, run as root with ACLs on and `bootstrap_expect = 2` on
  one server, so it has no leader (Ran, `probes/leaderless14-2.1.1.txt`):
  - `/v1/status/leader` answers `500 No cluster leader`.
  - `provision --leader-wait-seconds 3` refuses after about 5 s.
  - With the default wait, it refuses after about 36 s with "nomad has no
    leader after 30s (GET /v1/status/leader returned HTTP 500: No cluster
    leader); rerun once Nomad has elected one".
  - Neither run saves a file.
- The same data directory with `bootstrap_expect = 1`: `provision`
  bootstraps and provisions, and `check` passes. Both used the default
  `--nomad-uid 0` against a root-run Nomad.
- Mutants:
  - L4 (provision carries on after the wait times out) is killed by
    `TestNomadACLToolWaitsForANamedLeader` (Ran).
  - The writer's L1, L2 and R1 cover the rest (writer's `mutants-48r.txt`;
    Read).

## RT-4: the port holder guard

**The tool (Read).**

- `_NomadsConnection.connect()` (`nomad_acl.py:159`) checks before anything
  is sent on the connection. It reads `/proc/net/tcp{,6}` for the row whose
  local endpoint is our peer and whose remote endpoint is us, then requires
  the set of owners to be exactly `{nomad_uid}`.
- A Refusal raised in `connect()` is not an `OSError`, so neither urllib
  nor `Nomad.request` turns it into a status. It propagates as a refusal.
- `_NomadsHTTPHandler` replaces urllib's default HTTP handler. The address
  is limited to loopback `http://`, and redirects and proxies are off. So
  every request goes through the check, anonymous ones included.
- Because the check is on the connection that carries the bytes, there is
  no window between the check and the send (Inference).

**Real listeners, root caller (Ran, kernel 6.18, `probes/rt4.txt`).** A
listener run as `ci` (uid 1500) answered like an ACL-enabled Nomad with a
leader. Root ran each step with the defaults its callers use:

| Step, against the `ci` holder | Result |
| --- | --- |
| tool `provision` with a saved management token | refused "runs as uid 1500, not Nomad's uid 0 … nothing was sent"; 0 bytes received |
| tool `check` | same refusal; 0 bytes |
| tool `provision`, holder never accepts | same refusal |
| tool `provision`, holder accepts and closes at once | same refusal; 0 bytes |
| setup `require_nomad_listener` (`NOMAD_SERVICE_UID=0`) | refused; 0 bytes |
| setup `nomad_token_curl` with the saved management token | refused; 0 bytes |
| setup `bootstrap_nomad_acl`, no saved secret | refused after the leader wait; 0 requests with a token, 0 bootstrap POSTs, no secret file |
| G3 mutant (the tool reads its own socket's row) | **sent**: the planted management token reached the holder |

The control is a root-owned holder. Against it, every step sent its
requests and the planted token arrived. So the refusals come from the owner
check.

**G3 in the PR's tests.** Only the PR's root-caller subcase kills G3, and
it needs passwordless sudo.

- As `ci` here it skips, and my G3 mutant (T3) survives (Ran).
- I asked for a temporary sudoers entry for `ci` so that subcase could run.
  The environment's safety check refused it, so I did not add one.
- The probe row above shows what G3 does and that the head prevents it.
- GitHub-hosted runners have passwordless sudo, so CI should run the
  subcase (Inference). Not a finding.

**IPv6 (Ran, partly).**

- This container's kernel has no IPv6, so I could not run the `[::]`
  dual-stack and `[::1]` holders.
- I checked the decoding on rows written as the kernel prints them
  (`probes/proc-net-decode.txt`):
  - The tool maps `::ffff:127.0.0.1` to `127.0.0.1` and reads `::1` and
    `::` correctly.
  - The shell's four awk constants equal the kernel's text for
    `127.0.0.1`, `0.0.0.0`, `::` and `::ffff:127.0.0.1`.
- A holder that the awk does not list (for example one bound to
  `::ffff:0.0.0.0`) makes it report "missing", so the shell refuses
  (Read).
- While Nomad holds `127.0.0.1:P`, a non-root account cannot also bind a
  wildcard on P (Inference, Linux bind rules).

**Plumbing (Read, Ran).**

- `nomad_acl_setup.sh` passes `NOMAD_USER`'s uid (default root) to all
  three tool calls.
- `72_supported_local_setup.sh` passes `SUPPORTED_LOCAL_NOMAD_USER`
  (default root).
- `01_bringup.sh` passes `$(id -u)`, because `06_start_nomad.sh` execs
  Nomad as the current user.
- The wrapper test requires `--nomad-uid 0`. As root it passes on the head
  and kills W1, a mutant that drops the flag from `provision` (Ran,
  `tests/root-wrapper.txt`).
- The writer's grep, which I repeated (Read): the management token is sent
  only by the setup script and the tool.

**Setup script coverage.** The guard runs before every management-token
send:

- line 412, after the leader wait;
- 443, before the bootstrap POST;
- 387, inside `nomad_token_curl`;
- 505, before the diagnostics' Python;
- 630, before qualification's Python.

That placement is right (Read). Mutants:

| Mutant | Result |
| --- | --- |
| S1 awk ignores the listener's owner | killed by `TestLinuxSetupBootstrapSendsNoSecretToAPortHolder` |
| S3 guard at 505 (diagnostics) removed | **survived** every `TestNomadACL*` and `TestLinuxSetup*` test: A14-1 |
| S4 guard at 630 (qualify's Python) removed | survived; the guarded `nomad_token_curl` at 624 runs just before, so this only narrows a window |
| S5 guard at 443 (before the POST) removed | survived; same, the guard at 412 runs first (the writer says so in 13) |

## Findings in the PR's diff

**A14-1 (Low): the diagnostics' guard is not pinned.**

- The PR added `require_nomad_listener ||` before the Python in
  `report_nomad_cpu_visibility_diagnostics` (`70_linux_setup.sh:505`). That
  Python sends `NOMAD_QUALIFY_TOKEN` to `/v1/nodes` and `/v1/node/<id>`.
- The setup script runs these diagnostics when `qualify_supported_substrate`
  fails (line 754). `bootstrap_nomad_acl` sets the token (lines 433 and
  451) before qualification's leader, agent and node requests. So if
  qualification fails after that, for example because Nomad stopped, the
  diagnostics send the management token.
- At that point the guard at 505 is the only check. No earlier guard
  covers it: Nomad's stopping is the reason for the failure (Read).
- What removing it does (Ran, `probes/rt4-diagnostics.txt`): root ran the
  function with a planted token, against a port held by `ci`.
  - The head sent 0 bytes.
  - Without the guard, the planted token reached the holder.
- No test reaches this function: S3 survives (Ran, `mutants/mut14.txt`).
- Fix (either way):
  - a case in `TestLinuxSetupBootstrapSendsNoSecretToAPortHolder` that runs
    `report_nomad_cpu_visibility_diagnostics` with `NOMAD_QUALIFY_TOKEN`
    set and a uid that is not Nomad's, and requires that the holder
    receives nothing. The function sits outside the
    `# BEGIN/END nomad_acl_bootstrap` block, so the test must extract it or
    the block must grow;
  - or a script test asserting that every token-bearing request in the
    script follows the guard.
- S3 must then fail. Pinning S4 the same way is optional.

## Observations (Info, no action required)

- I14-1: the docs bullet says the setup script "checks the listener just
  before each request". Both Python blocks check once, then make several
  requests (`/v1/nodes`, then one per node). The window has the same
  sub-second size, but "before each request or batch of requests" would be
  exact.
- Earlier rounds still apply: the ES client token and the observer
  readiness requests are not guarded, and the docs say so (Read).

## Validation (Ran, as user `ci` unless noted)

| Run | Result |
| --- | --- |
| `go build ./...`, `go vet ./...`, `GOOS=darwin go vet ./...` | pass (`tests/build-vet.txt`) |
| the six tests in `nomad_acl_bootstrap_test.go`, Nomad 2.1.1 and 2.0.0 | pass on both; the root-caller subcase skips (`tests/new-211.txt`, `tests/new-200.txt`) |
| `TestNomadACL*`, `TestLinuxSetup*`, `TestSupportedLocalSetup*`, `TestRealNomad*`, `TestSubmitRefusesANomadThatDoesNot*`, `TestSupportedLocalFullReadiness*` on 2.1.1 | 29 pass and 2 skip: the root-only wrapper test and the SPIRE/Vault supported-local test (`tests/acl-setup-211-rerun.txt`) |
| wrapper test as root, on a `git archive` copy of the head | pass (`tests/root-wrapper.txt`) |
| root package | pass (`tests/root-package.txt`) |
| mutants M6, T1, T5, L4, S1, W1 (W1 as root) | killed |
| mutants T3 (without sudo), S3, S4, S5 | survived; see above |
| CI run 45331167600 | in progress at 05:31Z (`ci/run-45331167600.txt`) |

- One transient failure: in the batch's first run of that set,
  `TestLinuxSetupGoToolchainInstallerHermeticPreflightAndCleanup` failed,
  and the first S3–S5 runs hit it too.
  - I did not capture its message.
  - It passed alone and in two reruns of the set.
  - The PR does not touch the Go installer.
  - The S3–S5 results above come from the clean rerun
    (`mutants/mut14-S-rerun.txt`); the first batch is
    `tests/acl-setup-211.txt` and `mutants/mut14.txt`.
- Not run:
  - the full es/app and scripts suites, and the full-profile bring-up (the
    writer ran them; CI runs them);
  - IPv6 holders (no IPv6 here).

## Sensitive material

- Every probe kept its planted secrets in 0600 files under temporary
  directories that it removed.
- The probes print return codes, byte counts, booleans and refusal texts,
  with UUIDs replaced by `<uuid>`.
- A scan of the evidence for UUID-shaped strings and "SecretID" found
  none outside code and field names.
- No personal data left the container.

## Remaining uncertainty

- IPv6 holders were not run here; that part rests on the decode check and
  a Read.
- The kernel behaviour the tool relies on was seen on 6.18 here: a pending
  or accepted server socket carries its listener's uid (Ran, the
  never-accepts and accept-and-close rows).
- TIME_WAIT rows show uid 0. An attacker cannot read from such a socket,
  and the exact-set check refuses a mixed set (Inference, kernel source).
- Kernels older than 4.10 reported pending sockets differently (Inference).
  The supported hosts run far newer kernels.

## Confidence

- Provenance: high.
- A12-1 and A12-2: high, on real Nomad.
- RT-4 tool guard: high, on real listeners with a root caller.
- RT-4 setup guard: high on the paths driven; A14-1 is a pinning gap, not a
  hole in the head.

## Effect status

- No commit, push, PR comment, review or merge.
- Nothing outside this container changed.
- The auditor's request for a temporary sudoers entry was refused, and none
  was made.

## Report delivery

- Report: `/mnt/project-files/reports/Execution-Substrate/nomad-acl/14-recheck.md`;
  its sha256 is in the delivery message.
- Evidence checksums: `14-recheck-evidence/SHA256SUMS.txt`.

## Final verdict

**BLOCK**

To close it:

- A14-1: add the test above; mutant S3 (remove `require_nomad_listener ||`
  at line 505) must then fail it.
- Then a diff-only check of the new commit, and green CI on it.
