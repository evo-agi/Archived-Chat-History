# Independent audit 14: ES PR #69 (PLANS.md step 3; claim ledger by section)

**Verdict: BLOCK.** Two patch defects, both in the claim-ledger half (commit `a0c844e`). The PLANS.md half (commit `4d4ae99`) is clean: both sections moved byte for byte, authority is unchanged, every repointed test reads the same text it read before, and a deletion sweep gives the same failing tests per paragraph on base and head.

- **A14-1 (medium): five ES line ranges are still in the claim ledger.** The ledger now says "References into this repository cite sections, not lines", but rows C7, C11, D1, D2 and H3 keep a second range as a bare code span after the new section link (for example `… § 5. Ownership and non-ownership](…), \`160-228\``). The new guard `TestClaimLedgerCitesThisRepositoryBySection` does not catch this shape (mutant L3 survives).
- **A14-2 (low): "each range covered whole sections" is not true.** Nine of the ES ranges cited at `6300b95` stopped inside a section, mostly just before a "Reopened seams" subsection. Linking the whole section makes those citations wider. The false sentence is in the ledger and is pinned by a test; the PR body says "no citation got wider or narrower".

Effect status: read-only audit. Nothing was committed, pushed, opened, commented on or merged.

## Target

| Item | Value |
|---|---|
| Repository | evo-agi/Execution-Substrate |
| PR | #69, branch `claude/project-thread-hfr05z` |
| Base | `923e9c3366775664c8a85f19273e3dd4fc04eb22` (= `origin/trunk_dev`, re-checked with `git ls-remote` at the end of the audit) |
| Head | `a0c844e6e0fb75b49da196225cb3a8939e4b0acd` (pushed branch tip = `refs/pull/69/head`, re-checked at the end) |
| Head tree | `44886ec43bc90a5d38769699e2af9fc57fd853f3` |
| Commits | `4d4ae99` (sections move, tests follow, cap lowered); `a0c844e` (ledger by section, heading-link guard) |
| Recipe | `governed_execution_audit_patch_manifest_v2.py`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified before the opening and closing runs) |
| Canonical manifest | SHA-256 `cc7770042f1f3352087a3f03ae0809c6808ceccd57e1a98602ac13102a15d43a`, 13 files |
| Textual diff | SHA-256 `9905ca443fc40e295bd014bf9d704bbf2644a7ebdc12e9ba18d37cc3feaf53db` |
| Implementation report | None in the shared folder; the PR body served as the report (see O-1) |

## Audit posture

Read-only parent thread. No subagents were used. All test runs happened in scratch clones under `/opt/audit` in this container, as an unprivileged user `ci`, with `umask 022`, go1.26.5 linux/amd64, and HUP/INT/QUIT/TERM/PIPE reset to default before `go test`. The audit clone used for the manifest was not modified.

## Provenance reproduction

Commands (§5.3 of the provenance guidance), in a fresh clone: fetch `trunk_dev` and the topic branch; check the pushed tip is `a0c844e` and `923e9c3` is its ancestor; `git checkout -f -B claude/project-thread-hfr05z a0c844e`; clean status; `git reset --mixed 923e9c3`; pin upstream to `origin/trunk_dev`; run v2 twice into a fresh `0700` directory.

- The two runs are byte-identical. Manifest `cc777004…d43a`, textual diff `9905ca44…53db`, 13 files.
- **Reconciled mismatch.** The PR body first gave manifest `98059f54…97c6`. The writer's thread then saved both of its JSON files: `12-original-manifest-temp-branch.json` (SHA-256 `98059f54…97c6`) and `12-expected-manifest.json` (SHA-256 `cc777004…d43a`). The second is byte-identical to my opening manifest (`cmp`). The first differs from mine only in its `branch` field (`manifest-923e9c3` instead of `claude/project-thread-hfr05z`). Every file record, `head`, `upstream` and the textual diff are equal. That is the `PROVENANCE_BASELINE_READY` case (§9): stable output, all per-file records match, only an aggregate hash was taken under the wrong branch name. The audit target is `cc777004…d43a`.
- No mode differences.
- The closing run (after all audit work, in the untouched audit clone) equals the opening run byte for byte.

## Coverage

Read: `AGENTS.md` §3 (authority order), `PLANS.md` (base and head), both `.docs/standing_rules/` files, the three cross-referenced docs, `README.md`, the claim ledger at base and head and the cited docs at the ledger's origin commit `6300b95`, the whole diff of the four test files and the helpers they call (`testutil` Section/CompactSection, `markedDocSection`, `markdownHeadingTitles`, `markdownLinkTargets`, `repositoryTextFiles`, `numericCell`/`lineRange`). Not inspected: the CP and IM line ranges (out of scope; CP is not attached), CI logs (CI was still running, see Validation).

### 1. The move is byte for byte, and authority is unchanged

`check_move.py` (evidence) compares the blob texts at `923e9c3` and `a0c844e`:

- "Current paired-root custody and acceptance scope": base `PLANS.md` from that heading to the first ADR paragraph equals the last section of `execution_admission_and_custody.md` (12,347 bytes plus the base's trailing blank line).
- "Remote Alpha access contract v1 — Tranche A": base `PLANS.md` from that heading to the end of the file (it was the last section, 6,481 bytes, including the four paragraphs after it) equals the last section of `remote_alpha_operator_routes.md`.
- In both rule files, everything from the first `###` heading up to the appended section is unchanged. Only the header paragraph changed (the "last section moved at `923e9c3`" sentence and, for the route file, its scope).
- The four ADR paragraphs (3,257 bytes) appear verbatim in head `PLANS.md`. Every other line removed from or added to `PLANS.md` is one of the documented pointer edits.
- **The reorder is justified by history.** The ADR paragraphs were written directly under "## Cross-Repo Hybrid Integration ADR Pointer" (`5da8c5a`, 2026-07-24). The Stage A heading and then PR #8 (`2478a24`) inserted headings in front of them. Head puts them back directly under the ADR pointer.
- **Position words still hold.** In the moved text, "earlier" (twice) is temporal and "classification below" still points to the route-eligibility paragraph that moved with it. In the ADR block, "reopened seam boundaries above" still points to the classification list.
- **Authority.** `AGENTS.md` §3 is unchanged except that the standing-rules bullet now names the access contract; the rank sentence ("They keep `PLANS.md`'s authority, second in the list above") is unchanged. So the text moved between two documents of the same rank. The access contract's `Reopened redesign seam` lines now live in the route rule file; head `PLANS.md` still names "its reopened access-profile and access-status seams" in the route pointer, so `AGENTS.md`'s "reopened in `PLANS.md`" checks still resolve through the pointer (inference from the AGENTS.md rule that the standing rule files keep PLANS.md's authority).
- **No product code changed.** The 13 paths are 9 Markdown files and 4 root `_test.go` files (`heading_links_docs_contract_test.go` is new).

### 2. The repointed tests still test what they did

- All 16 changed test functions were compared on base and head. Each positive check that read the whole of `PLANS.md` (or the ADR-pointer section, which at base contained the custody section) now reads the specific moved section through `standingRuleSection`, or the same start/end markers in the rule file. That is narrower than before, so stricter. The start markers used on the whole rule file occur only in the moved section.
- The only negative check on the moved text (`TestRemoteAlphaExternalTLSOneTimeIncidentClosureAndSunset`, "cross-reference overlay independence") reads the same marked paragraph in its new place. The other negative checks over `PLANS.md` already include the whole admission rules file. `TestStartupProbeUseAgreementDocsContract` was widened from `PLANS.md` to `PLANS.md` plus both rule files.
- `standingRuleSection` cuts at the next line starting with `#`. Neither moved section has such a line or a code fence, so it returns the whole section.
- **Deletion sweep** (`sweep.py`, root package plus the six scripts docs tests that read these files, on clean clones with every change staged): 26 paragraphs per side (12 custody, 9 access, 5 ADR blocks). For 25 of them the set of failing test names is identical on base and head. The one difference is intended: the Tranche B validator-gate paragraph fails nothing on base and fails `TestStandingRulesPinEachOtherwiseUncheckedRule` on head (the new pin). The ADR lead-in line "Classification for this ADR tranche:" fails nothing on either side; its list fails tests on both. Clean reruns after both sweeps pass.

### 3. Layout, opening and size-cap tests

Mutants (`mutants.py`, 25 mutants; every one killed except the ones listed in A14-1 and O-3 and the three controls that must pass):

| Mutant | Result |
|---|---|
| S1/S2 extra section after either moved section | killed by `TestStandingRulesKeepPlansAuthority` |
| S3 drop the "moved at `923e9c3`" header sentence | killed by `TestStandingRulesKeepPlansAuthority` |
| S4/S5 drop the new wording in either `PLANS.md` pointer | killed by `TestStandingRulesKeepPlansAuthority` |
| S6 restore the "Two standing-rule sections are still here" sentence | killed by `TestPlansOpensWithTheCurrentPlan` |
| S7 `PLANS.md` at 132,001 bytes / S8 at 132,000 (control) | killed by `TestPlansStaysWithinItsSizeCap` / passes |
| S9 alter the newly pinned Tranche B sentence | killed by `TestStandingRulesPinEachOtherwiseUncheckedRule` |
| S10 copy the access heading back into `PLANS.md` | killed by `TestStandingRulesKeepPlansAuthority` |

The cap comment's 127,250 bytes is the head size of `PLANS.md` (manifest).

### 4. The heading-link guard

- `TestMarkdownHeadingLinksResolve` uses the existing CommonMark-faithful `markdownHeadingTitles` (fences close only on the same character, at least as long, no info string; setext headings included) and the existing `markdownLinkTargets`.
- An independent Python check (`anchors_indep.py`, GitHub's html-pipeline rule: remove everything but `\p{Word}`, `-` and space; `\p{Word}` = letters, marks, decimal digits, connector punctuation) finds the same counts as the writer: **99 heading links on head, 0 broken; 23 on base, 0 broken.**
- Mutants A1 to A6 (broken ledger anchor, renamed heading, heading only inside a code fence, broken same-file anchor, missing `-9` duplicate, em dash written as one hyphen) are all killed. Controls A7 (correct em dash anchor) and A8 (percent-encoded path) pass.
- `githubHeadingSlug` keeps letters, decimal digits, `-` and `_`. It differs from GitHub for combining marks, for `_emphasis_` underscores and for HTML entities. No heading in the repository uses any of these today (scan of every tracked `.md` heading), so this is noted, not a finding.

### 5. The claim ledger mapping

`ledger_map2.py` pairs every base row with its head row (the rows align one to one), lists every ES line range in the base ledger, computes the sections that cover it at `6300b95`, and compares with the head links. Results:

- The base ledger cited ES by line **53** times: 48 primary citations (`ES \`path:a-b\``) and **5 continuation ranges** written as a further code span after a comma (`ES \`…:287-375\`, \`384-535\``). The PR body counts only the 48.
- All 48 primary citations became section links, the paths match, and the text around them is unchanged (any extra words are only the added "and [§ …]" links). Every link's anchor resolves (TestMarkdownHeadingLinksResolve and the independent check). The renamed heading "1. Purpose and authority" → "1. Purpose and scope" is linked by its current name.
- The 5 continuation ranges were not converted: A14-1.
- 9 of the distinct ranges did not cover whole sections: A14-2.
- The ES source-baseline table now lists sections. Its mapping matches the base ranges (contracts.md correctly leaves out section 4; capability_probing.md lists exactly the eight sections the three ranges covered), with the same widening as A14-2 for boundaries.md section 8 and the contracts.md "Reopened seams" subsections.

## Findings

### A14-1: Five ES line ranges remain in the claim ledger, and the new guard misses that form

- Type / severity: test/doc gap, patch defect. **Medium.**
- Contract: the ledger's new paragraph, "References into this repository cite sections, not lines, because lines move with every edit", and the PR's goal that "the claim ledger stops citing this repository's docs by line".
- Evidence, head `.docs/commercialization/claim-ledger.md`:
  - line 119, row C7: `…contracts.md` § 6. Submit contract](…), \`384-535\``
  - line 123, row C11: `…capability_probing.md` § Purpose](…) and [§ Core Principle](…), \`51-82\``
  - line 124, row D1: `…runtime_identity_handoff.md` § 1. Purpose and scope](…) and [§ 2. Decision summary](…), \`63-127\``
  - line 125, row D2: `…runtime_identity_handoff.md` § 5. Ownership and non-ownership](…), \`160-228\``
  - line 158, row H3: `…runtime_identity_handoff.md` § 2. Decision summary](…), \`97-127\``
- Impact: after a section link, these ranges read as lines of that section or of an unnamed file version; they are lines of the `6300b95` files and have moved since (for example, runtime_identity_handoff.md section 5 now starts at line 88, not 97). The ledger's new paragraph is false for these five citations. `claimLedgerLineCitation` only matches a code span directly after `ES `, so `TestClaimLedgerCitesThisRepositoryBySection` passes on head with all five, and mutant L3 (adding `, \`70-89\`` after an ES link) survives.
- Required correction:
  1. Link the five ranges by section, as mapped at `6300b95`: C7 `384-535` → § 7. Status contract; C11 `51-82` → § Placement Rules and § Failure Behavior; D1 `63-127` → § 3. Surface classes used here, § 4. Classified current runtime-identity surfaces and § 5. Ownership and non-ownership; D2 `160-228` → § 8. Required evidence exclusions, § 9. Workstream F stop lines and § 10. Remaining Workstream F seams; H3 `97-127` → § 5. Ownership and non-ownership. All these headings exist on head under those names.
  2. Make the guard refuse a code span that is only a line number or range when it follows an ES citation (up to the next `;`, cell end, or `CP `/`IM ` prefix), and add `ES [\`x.md\` § A](x.md#a), \`51-82\`` to its self-test of lines it must refuse.
  3. Correct the count in the PR body (53 ES line ranges, 48 primary plus 5 continuations).
- Uncertainty: none; all five are in the committed bytes.

### A14-2: The ledger says every cited range covered whole sections; nine did not

- Type / severity: doc gap (inaccurate statement), patch defect. **Low.**
- Contract: the new ledger paragraph says the links "were mapped from the line ranges this ledger cited when it was written, at commit `6300b95…`, where each range covered whole sections"; `TestClaimLedgerCitesThisRepositoryBySection` pins that phrase. The PR body says "Every range covered whole sections there, so no citation got wider or narrower."
- Evidence (sections and lines at `6300b95`; H1 titles that span a whole file ignored):

| ES range at `6300b95` | Rows | What it left out | Now linked as |
|---|---|---|---|
| contracts.md 77-278 | B1, H2 | §5's "### Reopened seams" (279-285) | § 4A and § 5 |
| contracts.md 160-278 | C3 | §5's "### Reopened seams" (279-285) | § 5 |
| contracts.md 287-375 | C4, C7 | §6's "### Reopened seams" (376-382) | § 6 |
| contracts.md 384-535 | B3, C5, C6, H4 (and C7, A14-1) | §7's "### Reopened seams" (536-542) | § 7 |
| contracts.md 689-738 | B4, C9, H5 | §10's "### Reopened seams" (739-744) | § 10 |
| contracts.md 1-35 | B7 | the closing paragraph of §3 (line 37) | § 1, § 2 and § 3 |
| supported_local_cp_consumer_runbook.md 315-441 | B2, C10 | the closing paragraph of §8 (line 443) | § 6, § 7 and § 8 |
| boundaries.md 350-424 | C1, C5 | §8 "ES boundary" runs 267-435; the range is its consumers, invariants and compatibility-edge bullets only | § 8 |
| runtime_identity_handoff.md 27-58 | D3, H3 | the last bullet of §2 (59-61) | § 2 |

- Impact: those citations got wider. Five consistently stopped before a "Reopened seams" subsection; for "can say now / stable contract" rows, the linked section now also contains text that says the surface is not settled. boundaries.md 350-424 grew from 75 lines to the whole 169-line section. The ledger and the PR body state the opposite. Low impact on the claims themselves, but the ledger now records a false fact about its own citations, and a test pins it.
- Required correction: either state the rule actually used (each range is linked to the section or sections that contain it; nine ranges got wider, five of them by a "Reopened seams" subsection, and boundaries.md 350-424 is part of § 8), changing the pinned phrase with it, or narrow those links. Correct the PR body sentence too.
- Uncertainty: the ranges are assumed to belong to `6300b95`, as the PR says. Supporting evidence: at `6300b95`, 51 of the 53 ranges start on a heading or the first line of the file (the other two are boundaries.md 350-424, cited twice), and 46 end on the last non-blank line before a heading (any level) or the end of the file.

### Observations (not blocking)

- **O-1 Process.** No implementation report was written to the shared folder; the PR body served as one and carried only manifest hashes, not the manifest itself (protocol §11 asks for the complete canonical manifest). The writer took the manifest on a temporary branch, which broke rule 1 of provenance §5 and produced the hash mismatch reconciled above.
- **O-2 Ordinary `PLANS.md` mentions now reach moved text only through `PLANS.md` pointers.** For example `.docs/system_overview/boundaries.md:816` ("the reliable-submit seam kept open in `PLANS.md`"): the replay-repair status and the reliable-dispatch block now live in the custody rule file, and head `PLANS.md` names reliable-submit only in that file's pointer. `.docs/mvp.md:198` cites `PLANS.md` for the maintenance-monitor boundary, which moved to the route rule file (the ADR classification bullet in `PLANS.md` still partly supports it). The PR leaves these alone on purpose, and they are the class of audit 05's A05-4. Worth covering in step 4.
- **O-3 Baseline-table guard gaps.** A single-line cell (`\`229\``, mutant L5) or text plus a range (`Lines \`1-229\``, L6) in the ES baseline table passes. No such cell exists today.
- **O-4 Size-cap headroom.** The cap leaves 4,750 bytes. Open PRs #70 (+1,030 bytes to `PLANS.md`) and #71 (+3,248) would bring it to 131,528 together (131,552 with #68), about 450 bytes under. Step 4 (the writer's follow-up) would resolve this; until then any further `PLANS.md` growth hits the cap.
- **O-5 Other open PRs.** `git merge-tree` merges #69 cleanly with each of #63, #66, #68, #70 and #71, and the root package (plus `internal/testutil` for #68) passes on each trial merge, so the new guards do not break them as they stand.

## Validation assessment

Re-run on the exact bytes (clean clones of `923e9c3` and `a0c844e`, full `go test -count=1 -json ./...`, as `ci`, 21:48-22:04Z):

- 49 packages on both sides; 28 pass on both. Top-level tests: 1,934 base, 1,937 head. Root package: 176 pass on base, 179 on head, none failing.
- The only verdict changes are the three new tests, which pass: `TestClaimLedgerCitesThisRepositoryBySection`, `TestGithubHeadingAnchorsFollowGithubRules`, `TestMarkdownHeadingLinksResolve`. The other differing names are randomized subtest names of `TestRedTeamPR12*` (timings in the name), which pass on both sides.
- The same 14 top-level tests fail on base and head, by name. They come from this container (no nomad binary or real host; the writer's container failed 75 because it lacked ssh, uuidgen and acl), not from the PR:
  - es/admission/internal/reliablesubmit: `TestOperationalHandoffSchema4BinaryRefusesSchema5`, `TestSQLiteV3OldBinaryRefusesWithoutMutation`, `TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation`
  - es/app: `TestLinuxSetupBootstrapFinishesWithItsSavedSecret`, `TestNomadACLToolRetriesABootstrapThatNeverTookEffect`
  - scripts: `TestRemoteAlphaESServiceTLSStatusFailureWitnessBootstrapOwnedTerminal`, `TestRemoteAlphaESServiceTLSStatusRootLoadedStageCustody`, `TestRemoteAlphaESServiceTLSStatusStageFIFOSubstitution`, `TestRemoteAlphaOperatorRecoverySessionESTLSStatusRemoteWrapperTrap`, `TestRemoteAlphaOperatorRecoverySessionESTLSStatusStageFIFORefusal`, `TestRemoteAlphaP0tGrammarDiagnosticBootstrapLifecycleComposition`, `TestRemoteAlphaP0tGrammarDiagnosticPriorReaderCloseSuppression`, `TestRemoteAlphaP0tGrammarDiagnosticV2VersionedBootstrap`, `TestRemoteAlphaUpgradeESCheckRefusesWhatItWasNotWrittenFor`
- Also run: the deletion sweep (both sides), 25 guard mutants, the independent anchor check, five trial merges.
- Not re-run: `go vet`, `gofmt`, `git diff --check` (the writer reports them clean; no Go code outside tests changed). CI: both required checks ("build, vet and test", "test on macOS") were still in progress on `a0c844e` at 22:10Z; the merge gate must confirm them.

## Sensitive-material handling

No secrets, env files, keys or databases were read or copied. The evidence holds only repository paths, hashes, test names and doc excerpts. A scan of the evidence for secret-like words matches only the test name `TestLinuxSetupBootstrapFinishesWithItsSavedSecret`.

## Confidence

- Provenance: high. Manifest reproduced and stable; opening equals closing; the reported hash difference is explained by the branch field alone, with both writer JSONs on file.
- Validation: high. Full suite on both sides on the exact bytes, compared by name; sweep and mutants run.
- Implementation: high for the PLANS.md move (byte-identical, tests follow the text); medium for the ledger half (A14-1, A14-2).

## Evidence

Folder `reports/execution-substrate/plans-cleanup/14-audit-evidence/`: opening and closing manifests; `check_move.out`; `ledger_map2.out`; `suite-compare.json` and `failing-tests.txt`; `sweep-base.jsonl`, `sweep-head.jsonl`; `mutants.jsonl`; `trials.jsonl`; `anchors-indep-{base,head}.out`; `scripts/` with every script used (`check_move.py`, `ledger_map2.py`, `anchors_indep.py`, `mutants.py`, `sweep.py`, `trials.py`, `neg_plans.py`, `summ.py`, `run_suite.sh`, `run_ci_py.sh`).

## Effect status

Repair, commit, push, PR change, comment and merge: not performed.

**Final verdict: BLOCK**
