# Independent re-audit 19: ES PR #69 at 8246cb2 (repair of re-audit 17)

**Verdict: BLOCK, on one low finding.** The repair does what audit 17 asked. R17-1(a) is closed: the baseline-cell rule is one function, `claimLedgerBaselineCellCitesLines`, called by both the check and the self-test, and every way of weakening it that I tried fails a test (G7, G8, dropping either other term, always false, always true, no trim). R17-1(b) is closed for the case it named: checking only the first `ES` citation of a line (G9) now fails the self-test. O17-3 is fixed: the PR body's sentence on the baseline table now matches the code. Nothing else changed since `4f4f597`. The full test suite gives the same results by name on base and head, apart from the three new tests, which pass.

During this audit `trunk_dev` moved to `39e19de` (#71) and the writer merged it in: the PR head is now `e83f2ba`. I checked that merge: it is git's own clean merge (its tree is the `git merge-tree` result of `8246cb2` and `39e19de`), the PR's patch is unchanged (same stable patch-id `b37db5cb…`), and I reproduced its manifest (`507e247b…e9d7`). The guard file is byte-identical there, so the findings apply to `e83f2ba` too, and the repair should be built on it. CI on `8246cb2`: macOS passed, Linux was cancelled by that push; CI on `e83f2ba` was still running when I published (see "Validation").

What blocks:

- **R19-1 (low, test gap, patch defect):** the mirror case of R17-1(b) is still unpinned. If `claimLedgerLineCitations` keeps only the spans of the **last** `ES` citation of a line (mutant E4: `found = …` instead of `found = append(found, …)`), every test still passes, even with `` , `384-535` `` added after the **first** `ES` citation of row C5 (E5). The real guard refuses that ledger edit (E6). Every must-refuse self-test line either has one `ES` citation or puts the bad span in the last one, so "a range in an earlier `ES` citation, with a clean later one" is never exercised. The fix is one more must-refuse line; I probed it (P1 to P6).

Effect status: read-only audit. Nothing was committed, pushed, opened, commented on or merged.

## Target

| Item | Value |
|---|---|
| Repository | evo-agi/Execution-Substrate |
| PR | #69, branch `claude/project-thread-hfr05z` |
| Base | `923e9c3366775664c8a85f19273e3dd4fc04eb22` (= `origin/trunk_dev` when the audit started; `trunk_dev` moved to `39e19de` at 23:58Z, see "Synced head") |
| Audited head | `8246cb274b4319164e5ff5954c35028ddde513f2` (pushed branch tip = `refs/pull/69/head` at the start; parent of the synced head at the end) |
| Head tree | `aa91743c293b7bdc54246b75297b6b54633a7973` |
| Commits | `4d4ae99`, `a0c844e`, `4f4f597` (audited by 17), `8246cb2` (this repair: `heading_links_docs_contract_test.go` only, +25/−3) |
| Recipe | `governed_execution_audit_patch_manifest_v2.py`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified in the project folder and on the copy I ran, before the opening and the closing runs) |
| Canonical manifest | SHA-256 `be88a750feeeae86785216bd0de8e6d721834ba15440bf6b6520a5286e67f4e5`, 13 files |
| Textual diff | SHA-256 `1acd80c26cde0cdc7e9135aa69624f75f3f7c5c434f7c1290683f7ca9acec3e9` |
| Implementation report | `18-report.md` (SHA-256 `77bb56ff9fe7f8a7d6644e822519c8fa21363b9ea2c90f876b120fa8cd761b73`), expected manifest `18-expected-manifest.json` (SHA-256 `be88a750…f4e5`) |
| Synced head (pushed during this audit) | `e83f2bac80ab370867118d479b12a4935f901d66`, merge of `39e19defb0ea6c0bda30a14f88452b24f9bd9cdf` (new `trunk_dev`, #71) into `8246cb2`; tree `56e48920682978da9231cc47f0ceda33433c706c`; manifest (reset onto `39e19de`) `507e247b09278cb4d3e0618b81d2bc6fe619dde3570b991fb40290315b85e9d7`, textual diff `932b3f3f0394e09a2a7b4262cc5cc1c0e8ae139fd37ac7005deaad6c5ab157bf` (`18b-expected-manifest-after-71-merge.json`, update at the end of `18-report.md`) |
| Prior audit | `17-audit.md` (SHA-256 `4c854c08fb3e1a98c8fb6c3a9f5c6a0f44d738478de8d1b87e582667647bc008`), by a different thread |

## Audit posture

Fresh, read-only parent thread that had not audited this PR before (protocol §14). No subagents. Test runs used clean clones under `/opt/audit/trees` as an unprivileged user `ci` (uid 1500, gid 1600), started with `runuser -u ci -- env -i`, `umask 022`, go1.26.5 linux/amd64, HUP/INT/QUIT/TERM/PIPE reset to default. Host packages acl, uuid-runtime, openssh-client, iproute2 and the en_US.UTF-8 locale were installed first. The clone used for the manifest was not modified. I wrote my own mutant, comparison and trial scripts (`19-audit-evidence/scripts/`); I read audit 17's scripts for their shape and reused none of them.

## Provenance reproduction

Commands from provenance §5.3, in a fresh clone: fetch `trunk_dev` and the topic branch; the pushed tip is `8246cb2` and `923e9c3` is its ancestor; `trunk_dev` is still `923e9c3`; `git checkout -f -B claude/project-thread-hfr05z 8246cb2`; clean status; `git reset --mixed 923e9c3`; upstream pinned to `origin/trunk_dev`; v2 run twice into a fresh `0700` directory.

- The two runs are byte-identical and equal `18-expected-manifest.json` byte for byte (`cmp`). Manifest `be88a750…f4e5`, 13 files. No mode differences.
- Against audit 17's opening manifest (`e94bda85…4381`, for `4f4f597`): path set, `head`, `branch`, `upstream`, `recipe_id` and textual diff are equal. The only changed record is `heading_links_docs_contract_test.go` (SHA-256 `53cdfa47…` → `3af827a8…`, 9,672 → 10,591 bytes). `git diff --stat 4f4f597 8246cb2` names only that file. So the other 12 files carry exactly the bytes audit 17 reviewed.
- The textual-diff hash is unchanged because the guard file is new, so it is untracked after the reset and appears only in its file record (provenance §8.4 caveat 1), as report 18 says.
- The closing run, after all audit work, equals the opening run byte for byte.

### The synced head `e83f2ba`

The writer merged the new `trunk_dev` (`39e19de`, #71) into the branch at about 23:59Z, while this audit ran, and told this thread. Checks, in a second fresh clone:

- `e83f2ba` has parents `8246cb2` and `39e19de`; `39e19de` is the current `trunk_dev` and an ancestor of the tip.
- Its tree `56e48920…` equals `git merge-tree --write-tree 8246cb2 39e19de`, so the merge is git's own, with no hand edits.
- `git diff 923e9c3 8246cb2` and `git diff 39e19de e83f2ba` have the same stable patch-id (`b37db5cbdd18e75e344d61412803b9cc0445f42c`) and the same changed lines (SHA-256 of the `+`/`-` lines `542fe750…a98a` on both).
- v2 (hash verified), `e83f2ba` reset onto `39e19de`, upstream `origin/trunk_dev`, run twice: identical, and equal byte for byte to `18b-expected-manifest-after-71-merge.json` (`507e247b…e9d7`). Against `be88a750…`: same path set; `head` and textual diff change with the base; only the records of `PLANS.md` (127,250 → 130,525), `.docs/execution_lifecycle/contracts.md` and `.docs/system_overview/remote_supported_host_alpha.md` change, which #71 also edited. The guard file's record is unchanged.

## Coverage

Read: audit 17 and its findings, report 18, the PR body, the whole `4f4f597..8246cb2` diff, the whole guard file at `8246cb2`, the shared helpers it calls (`numericCell`, `lineRange` at `plans_docs_contract_test.go:487-488`; `docSection`), and the ES source baseline table at head. Scope: the repair delta, R17-1, O17-3 and the PR's stated rule, as the brief asks. Not re-inspected: the moves, the range mapping and the deletion sweep (bytes unchanged since audit 17, which checked them), CP and IM ranges.

### 1. R17-1(a) is fixed: the self-test now exercises the real cell rule

`heading_links_docs_contract_test.go` at `8246cb2`: the check (line 195) calls `claimLedgerBaselineCellCitesLines(cell)`; the function (lines 174-177) trims the cell and returns `numericCell || lineRange || claimLedgerLineSpan`; the self-test (lines 239-254) calls the same function on 8 cells it must refuse and 5 it must accept.

Mutants of the function (`mutants19.jsonl`), each run in a clean clone with everything staged:

| Mutant | Result | Cell that kills it |
|---|---|---|
| C1 (= G7) back to `numericCell && lineRange` | killed | `` `229` ``, ` 229 `, ``Lines `1-229` `` … |
| C2 (= G8) drop `claimLedgerLineSpan` | killed | `` `README.md:12` ``, `` `.docs/mvp.md#L40` `` |
| C3 drop `lineRange` | killed | `Lines 1-229` |
| C4 drop `numericCell` | killed | ` 229 ` |
| C5 always false | killed | all 8 |
| C6 always true | killed | the real table's header row and accept-list cells |
| C7 no `TrimSpace` | killed | ` 229 ` |
| C8 = C1 plus a `` `229` `` cell in the ledger (audit 17's R3) | killed | |

So report 18's claim holds: each term of the rule is the only one that catches at least one must-refuse cell (C2, C3 and C4 are each killed by different cells). The accept list is the table's own shapes: the `AGENTS.md` cell verbatim, "The whole file", "Sections 1, 2, 3, 4 and 8", a `PLANS.md` section link and a plain path.

### 2. R17-1(b) is fixed for the case it named; the mirror case is not pinned (R19-1)

New must-refuse lines 219-220 put the line citation only in the second `ES` citation, once after `;` and once after a cell end.

| Mutant | Result |
|---|---|
| E1 (= G9) `claimLedgerESCitation.FindAllString(line, 1)` | killed by lines 219 and 220 |
| E2 = E1 plus `` , `350-424` `` after row C5's second ES citation (audit 17's R2) | killed |
| E3 the same ledger edit with the real guard (audit 17's R1) | killed |
| **E4** `found = claimLedgerLineSpan.FindAllString(citation, -1)` (assign instead of append: only the last ES citation of a line counts) | **survives** |
| **E5** = E4 plus `` , `384-535` `` after row C5's **first** ES citation | **survives** |
| E6 the E5 ledger edit with the real guard | killed: the guard reports `claim-ledger.md` line 117 |
| E7 only the first matching span per citation (`FindAllString(citation, 1)`) | survives; equivalent for detection (the test only asks whether any span is found) |

See R19-1 below.

### 3. Audit 17's guard and ledger mutants, rerun on `8246cb2`

All still killed: G1, G2, G3, G4, G5, G6; K1, K2, K3, K7, K9, K10, K13, K14; plus K3b (`Lines 1-229` cell) and K3c (`` `.docs/mvp.md#L40` `` cell), which the old self-test did not cover. A second batch (`mutants19b.jsonl`): G10 (citation must start the line), G11 (greedy citation body) and G13 (drop the range part of the bare alternative) are killed; G12 (drop the en dash from `claimLedgerLineSpan`) survives (O19-2). A clean rerun after every batch passes all four guard tests.

### 4. O17-3 is fixed

The PR body now says: "No ES baseline-table cell that holds only line numbers, holds a digit range, or holds a code span that cites by line; that rule is one function, which the self-test calls." That is what lines 174-177 and 239-254 do. It also says the self-test shows "that a range in the second ES citation of a line is refused" (true, lines 219-220), and lists the new commit `8246cb2`.

### 5. Nothing else changed; open PRs

- Only `heading_links_docs_contract_test.go` changed (manifest records and `git diff --stat`). `gofmt -l` lists none of the four changed test files; `go vet .` is clean on head.
- Open PR heads at the start: #63 `59f1f56`, #66 `84da2da`, #68 `e760c67` (moved since audit 17), #70 `a0e86ea`, #71 `26cbd65`, #72 `a3710c0`, #73 `5320ddc` (moved). `git merge-tree` merges `8246cb2` cleanly with each (`trials-heads.txt`). These trials used `8246cb2`, before `trunk_dev` moved. The four guard tests pass on every trial merge. On the two moved heads I ran the whole root package: 188 top-level pass on 69+#68 (with `internal/testutil`), 184 on 69+#73, none failing (`trials.jsonl`). #68 now edits `boundaries.md`, which the ledger links into; its links still resolve.
- After #71 landed, #66, #70, #72 and #73 moved too (to `08143bd`, `77027f8`, `c68cd50`, `affefc6`). I trial-merged the synced head `e83f2ba` with each: all clean, and the four guard tests and the whole root package pass on each (`trials-synced.txt`). Largest `PLANS.md` among them: 131,555 bytes with #70.
- Cap headroom is unchanged from audit 17's O17-1: with #68, #70, #73, #63 and #66 merged on top, `PLANS.md` is 131,687 bytes, 313 under the 132,000 cap.

## Findings

### R19-1: the self-test does not pin "every ES citation" when the bad citation comes first

- Type / severity: test gap, patch defect (the per-citation loop is new in this PR, at `4f4f597`; its self-test lines were set in `8246cb2`). **Low.**
- Contract: the PR body and the comment on `claimLedgerESCitation` say the guard refuses a line citation "anywhere in an `ES` citation"; audit 17 set the standard that the self-test must stop a later edit from weakening that rule.
- Evidence (`heading_links_docs_contract_test.go` at `8246cb2`): `claimLedgerLineCitations` (lines 162-168) appends the spans of every citation. The nine must-refuse lines (212-220) either hold one `ES` citation (212-218) or put the bad span in the last of two (219-220). Mutant E4 replaces line 165's append with an assignment, so only the last citation's spans survive the loop; all four guard tests pass. E5 adds `` , `384-535` `` after row C5's first `ES` citation (`contracts.md` § 7), with the second (`boundaries.md` § 8) clean: still passes under E4, while the real guard refuses it (E6). Rows with two or more `ES` citations are common in the ledger (B1, C5, C7, C10, H2, …).
- Impact: none on today's ledger; the production code is correct. But a one-token edit (dropping `append`) would let a line range back into the first citation of any multi-citation row without a test noticing, which is what R17-1(b) set out to prevent.
- Required correction: add a must-refuse self-test line where only the **first** `ES` citation cites by line and a later one on the same line is clean. I probed this line, inserted after line 220:

  ```go
  "ES [`x.md` § A](x.md#a), `51–82`; ES [`y.md` § B](y.md#b)",
  ```

  It passes on the real guard (P4), kills E4 (P5) and, because it uses an en dash, also kills G12 (P6). The hyphen form works for E4 alone (P1, P2), and with it E1 stays killed (P3).
- Optional, and the writer's call: moving both loops of the check into one function over the ledger text, and self-testing that function on a small synthetic ledger, would also close O19-1. Not required here.
- Uncertainty: none; E4, E5, E6 and P1 to P6 are in `mutants19.jsonl`, `mutants19b.jsonl` and `mutants19c.jsonl`.

### Observations (not blocking)

- **O19-1, glue between the helpers and the real ledger is not self-tested.** Three mutants survive: W1, the check stops calling the function and inlines the old `numericCell && lineRange` (the R17-1(a) shape, moved to the call site); W2, the ledger's lines are never scanned (`claimLedgerLineCitations(line[:0])`); W3, baseline table rows are skipped (`if strings.HasPrefix(line, "|")`). The self-test claims to pin the rule functions, not the loops, and the real-ledger checks can't fail on a clean ledger, so this is outside the PR's stated claim. It is the same pattern as the repository's other docs guards. Recorded, not asked for; the optional restructuring above would close it.
- **O19-2, the en dash inside `claimLedgerLineSpan` is not pinned** (G12 survives). It is a word inside a rule, the class audit 17's lessons put out of scope. The en-dash form of the R19-1 line pins it at no extra cost.
- **O19-3, carried from audit 17 unchanged:** O17-1 (cap headroom, 313 bytes with every open PR; numbers rechecked above), O17-2 (#68 and #70 together fail `TestServiceLayout`; not rechecked, not a #69 matter), O17-4 (the 53 mappings are held by review, not link by link) and O17-5 (audit 14's O-2, deferred to step 4).
- **PR body numbers are container-specific.** Its validation section says 26 packages pass on both sides; in this container (as in audit 17's) 28 pass, 18 skip and 3 fail on both sides. The body says the failures "come from this cloud container", so this is not a misstatement, only a reminder that counts differ by container; names are what match.

## Validation assessment

Full `go test -count=1 -timeout 40m -json ./...` as `ci` on clean clones of `923e9c3` (23:34:18-23:41:09Z) and `8246cb2` (23:41:11-23:47:13Z), run one after the other with nothing else on the machine (`suite-compare.txt`):

- 49 packages on both sides: 28 pass, 18 skip, 3 fail on both; no package verdict differs. Top-level tests: 1,934 base, 1,937 head. Root package: 176 pass on base, 179 on head, none failing.
- The only top-level differences are the three new tests, which pass on head: `TestClaimLedgerCitesThisRepositoryBySection`, `TestGithubHeadingAnchorsFollowGithubRules`, `TestMarkdownHeadingLinksResolve`. No verdict changes. Subtests: 8,237 on both; the 44 names that differ on each side are the randomized subtests of `TestRedTeamPR12HeadTwoSIGKILLsThenASurvivor`, `TestRedTeamPR12CombinedSIGKILLAtRandomInstants` and `TestRedTeamPR12HeadLiveProcessesRaceForOneClaim`, with no verdict changes.
- The same 14 top-level tests fail on base and head, by name, and they are the same 14 names audit 17 listed (`failing-tests-base.txt` = `failing-tests-head.txt` = audit 17's list):
  - es/admission/internal/reliablesubmit: `TestOperationalHandoffSchema4BinaryRefusesSchema5`, `TestSQLiteV3OldBinaryRefusesWithoutMutation`, `TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation`
  - es/app: `TestLinuxSetupBootstrapFinishesWithItsSavedSecret`, `TestNomadACLToolRetriesABootstrapThatNeverTookEffect`
  - scripts: `TestRemoteAlphaESServiceTLSStatusFailureWitnessBootstrapOwnedTerminal`, `TestRemoteAlphaESServiceTLSStatusRootLoadedStageCustody`, `TestRemoteAlphaESServiceTLSStatusStageFIFOSubstitution`, `TestRemoteAlphaOperatorRecoverySessionESTLSStatusRemoteWrapperTrap`, `TestRemoteAlphaOperatorRecoverySessionESTLSStatusStageFIFORefusal`, `TestRemoteAlphaP0tGrammarDiagnosticBootstrapLifecycleComposition`, `TestRemoteAlphaP0tGrammarDiagnosticPriorReaderCloseSuppression`, `TestRemoteAlphaP0tGrammarDiagnosticV2VersionedBootstrap`, `TestRemoteAlphaUpgradeESCheckRefusesWhatItWasNotWrittenFor`
- Mutant and trial runs started only after both suite runs had finished.
- On the new `trunk_dev`: the three packages whose tests read the docs this PR changes (root, `internal/testutil`, `scripts`) on a clean clone of `39e19de` and on the merge of `8246cb2` into it (tree `56e48920…`, the same tree as `e83f2ba`): 3 packages on both sides, root and `internal/testutil` pass, `scripts` fails on both. Top-level tests 649 on `39e19de`, 652 on the merge; root package 181 pass on `39e19de` and 184 on the merge, none failing. The only differences are the three new tests, which pass. The same 9 `scripts` tests fail on both sides, the same names as in the full-suite run above (`newtrunk/compare.txt`, `newtrunk/failing-tests-*.txt`). `PLANS.md` on the merge is 130,525 bytes, 1,475 under the cap.
- CI on `8246cb2` (GitHub API): "test on macOS" (job 140219618053) **success**, 23:28:45-23:55:57Z; "build, vet and test" (job 140219618352) **cancelled** at 23:59:20Z, when the sync push started a new run. CI on `e83f2ba`: "build, vet and test" (job 140229010476) started 23:59:24Z and "test on macOS" (job 140228939268) was queued; neither had finished when I published (about 00:03Z on 27 November). The repair will add a commit, so the next re-check should read CI on that head.
- Not run: the deletion sweep and the range mapping (those bytes did not change since audit 17).

## Sensitive-material handling

No secrets, env files, keys or databases were read or copied. The evidence holds only repository paths, hashes, test names, code excerpts and a local proxy port in `scripts/env.sh`.

## Confidence

- Provenance: high. Manifest reproduced, stable, equal to the expected manifest; opening equals closing. `trunk_dev` and the PR head moved during the audit; the synced head's manifest was reproduced too and its patch matches `8246cb2`'s.
- Validation: high. Full suite on both sides of the exact bytes, compared by name; 44 mutants and probes on the guard; trial merges with every open PR before and after `trunk_dev` moved; the doc-reading packages on the new `trunk_dev` and on the synced tree.
- Implementation: high for the R17-1 and O17-3 repairs. Medium-high for the guard's protection against later edits, because of R19-1.

## Evidence

Folder `19-audit-evidence/` (hashes in `19-audit-evidence/SHA256SUMS`): `opening-manifest.json`, `closing-manifest.json`, `synced-manifest.json` (for `e83f2ba`), `mutants19.jsonl`, `mutants19b.jsonl`, `mutants19c.jsonl`, `suite-compare.txt`, `failing-tests-base.txt`, `failing-tests-head.txt`, `trials.jsonl`, `trials-heads.txt`, `trials-synced.txt`, `newtrunk/` (`compare.txt`, `failing-tests-base.txt`, `failing-tests-head.txt`), and `scripts/` (`mutants19.py`, `mutants19b.py`, `mutants19c.py`, `compare19.py`, `trials19.sh`, `trials19b.sh`, `mkclone.sh`, `run_suite.sh`, `asci.sh`, `env.sh`). `trials19.sh` could not write its own summary file (owned by root), so `trials.jsonl` was assembled from its per-trial outputs afterwards.

## Effect status

Repair, commit, push, PR change, GitHub comment and merge: not performed.

**Final verdict: BLOCK** (R19-1, low), for `8246cb2` and equally for its sync merge `e83f2ba`
