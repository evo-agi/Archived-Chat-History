# Independent re-audit 22: ES PR #69 at 1160f28 (repair of re-audit 19)

**Verdict: BLOCK, on one low finding and one nit.** The repair closes R19-1 and the whole within-line part of the aggregation class: every way I built of collecting a line's ES citations or spans wrongly now fails the self-test, including R19-1's own mutant (last citation only). The restructured check finds exactly what the old one found on all four real ledgers the PR has carried. Provenance holds: only the guard test changed since `e83f2ba`, the manifest reproduces byte for byte, and the full suite gives the same results by name on base and head apart from the four new tests, which pass.

What blocks:

- **R22-1 (low, test gap, patch defect):** the self-test does not show the two "every" claims the new function makes about structure. A guard whose line scan skips every line that is not a table row (P4) passes all tests, and so does a guard that skips the first cell of each baseline row (B4). Under each, a real ledger edit the guard refuses today gets through (L2+P4, L1+B4). The cause is the dirty sample ledger: every line in it that carries an ES line citation is a table row, and none of its bad cells is in the first column. The fix is two lines in that ledger, which I probed: with them, 44 of my 46 code mutants die, and the two that survive are outside the claim.
- **R22-2 (low, nit, patch defect):** two wrong statements in the test file. The function comment says `TestClaimLedgerCitesThisRepositoryBySection` runs the check "on small synthetic ones" (another test does), and the failure message says the dirty ledger has "eight line citations" (it expects nine problems; report 20 also says "eight exact messages").

This is the third re-check of this guard. I tried to make it the last: the finding lists the structural positions I covered (line kind, line position, row position, cell position, citation and span position within a line), and the probe fix closes all of them.

Effect status: read-only audit. Nothing was committed, pushed, opened, commented on or merged.

## Target

| Item | Value |
|---|---|
| Repository | evo-agi/Execution-Substrate |
| PR | #69, branch `claude/project-thread-hfr05z` |
| Base | `39e19defb0ea6c0bda30a14f88452b24f9bd9cdf` (= `origin/trunk_dev` at the start and at the end) |
| Audited head | `1160f28bd47ca04e18195451dc4c64e8a87aee7c` (pushed branch tip = `refs/pull/69/head`, at the start and at the end) |
| Head tree | `c0a8420af76f058425c27769b5d8f9e191893c25` |
| Delta under review | `git diff e83f2ba 1160f28`: `heading_links_docs_contract_test.go` only, +146/−40 |
| Recipe | `governed_execution_audit_patch_manifest_v2.py`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (checked in the project folder and on the copy I ran, at the opening and closing runs) |
| Canonical manifest | SHA-256 `1da4f9990c93f2dfa8c67e1a89fb093b0cb21c32919671c843c0fa9c5d8e0817`, 13 files |
| Textual diff | SHA-256 `932b3f3f0394e09a2a7b4262cc5cc1c0e8ae139fd37ac7005deaad6c5ab157bf` |
| Implementation report | `20-report.md` (SHA-256 `8451c43402100fb4876c73950afd8b352426ed3619a62fffefafcb4cb357c8a9`), expected manifest `20-expected-manifest.json` (SHA-256 `1da4f999…0817`) |
| Prior audits | `19-audit.md` (SHA-256 `36e0df00adf5460d97a3416f8a3243841e1e77ecc7cafbb8126f398ff3083ee6`); 14 and 17 before it. All by other threads |

## Audit posture

Fresh, read-only thread that had not audited this PR (protocol §14). No subagents. Tests ran in fresh clones under `/opt/audit/trees` as an unprivileged user `ci` (uid 1500, gid 1600), started with `runuser -u ci -- env -i`, `umask 022`, go1.26.5 linux/amd64, HUP/INT/QUIT/TERM/PIPE reset to default. Host packages acl, uuid-runtime, openssh-client, iproute2 and the en_US.UTF-8 locale were installed first. The provenance clone was never modified. I wrote my own mutant, probe, comparison and trial scripts (`22-audit-evidence/scripts/`). I read audits 17 and 19 for their findings and their setup scripts' shape, and reused none of their mutant code.

## Provenance reproduction

Commands from provenance §5.3 in a fresh clone (`/opt/audit/prov`): fetch `trunk_dev` and the topic branch; pushed tip `1160f28` equals the reported tip and `refs/pull/69/head`; `39e19de` is its ancestor; `git checkout -f -B claude/project-thread-hfr05z 1160f28`; clean status; `git reset --mixed 39e19de`; upstream `origin/trunk_dev`; v2 run twice into a fresh `0700` directory.

- The two runs are byte-identical and equal `20-expected-manifest.json` byte for byte (`cmp`): `1da4f999…0817`, 13 files. No mode differences.
- Against `18b-expected-manifest-after-71-merge.json` (which equals audit 19's `synced-manifest.json`, the manifest of `e83f2ba`): same path set, same `head`, `branch`, `upstream`, `recipe_id` and textual diff. The only changed record is `heading_links_docs_contract_test.go` (`3af827a8…`, 10,591 bytes → `756e9980…`, 16,010 bytes). `git diff --name-status e83f2ba 1160f28` lists only that file, and `1160f28`'s only parent is `e83f2ba`. So the other 12 files are the bytes audits 17 and 19 reviewed (audit 19 also checked that `e83f2ba` is git's own clean merge of `#71`).
- The textual-diff hash cannot move: the guard file is new to the PR, so it is untracked after the reset (provenance §8.4 caveat 1), as report 20 says.
- The closing run, after all audit work, equals the opening run byte for byte. `trunk_dev` and the PR head had not moved at the closing run.

## Coverage

Read: audit 19 and its R19-1/O19-1/O19-2, report 20, the PR body, the whole delta, the whole guard file at `1160f28`, the shared helpers it calls (`numericCell`, `lineRange` at `plans_docs_contract_test.go:487-488`; `testutil.Section`, which the old code used), and the ledger's source baseline tables. Scope: the delta, R19-1, and the claims the new code and report make, as the brief asks. Not re-inspected: the moves, the range mapping and the deletion sweep (bytes unchanged since audit 17), CP and IM ranges.

### 1. R19-1 is closed, and so is the within-line part of the class

The check is now one function, `claimLedgerLineProblems` (`heading_links_docs_contract_test.go:194-225` at `1160f28`), and the self-test `TestClaimLedgerLineGuardFindsEachCitation` (lines 253-361) compares exact, ordered results for 21 lines that must yield spans and 8 that must yield none, then runs the whole function on a clean and a dirty small ledger.

My mutants, each run on the committed file in a clean clone against the four guard tests (`mutants20.jsonl`):

| Group | Mutants | Result |
|---|---|---|
| Collecting a line's citations and spans | M1 first citation only; **M2 last citation only (R19-1's E4)**; M3 one span per citation; M4 stop after the first citation that yields a span; M5 drop repeated spans; M6 skip the first citation when there are several; M7 skip the last; M8 skip the middle ones; M9 sort the spans; M10 reverse the citations; M11 keep at most three spans; M12 take spans from the whole line once any ES citation exists | all 12 killed |
| Where a citation ends (`claimLedgerESCitation`) | R1 `;` no longer ends one; R2 cell end no longer ends one; R3 a CP or IM citation no longer ends one; R4 greedy body; R5 must start the line; R6 no end-of-line terminator | all 6 killed |
| Which lines the scan visits | P1 skip the first line; P2 skip the last; P3 one problem per line; P5 skip table rows; P7 stop at the first problem line | killed |
| | **P4 skip every line that is not a table row** | **survives** (R22-1) |
| | P6 skip the lines between the two baseline headings | survives (R22-1; see there) |
| Which table rows and cells are checked | B1 never enter the table; B2 never leave it; B3 no missing-table problem; B5 skip the last cell; B6 only the first two cells; B7 one problem per row; B8 skip the first data row; B9 skip the last row; B11 start inside the table | killed |
| | **B4 skip the first cell of each row** | **survives** (R22-1) |
| | B10 the row test without `TrimSpace` (the `e83f2ba` shape) | survives (observation O22-1) |
| Cell rule | C1 drop `numericCell`; C3 drop `lineRange`; C4 drop `claimLedgerLineSpan` | all killed |
| Span pattern (earlier audits' pattern class, rerun) | S1 drop `#L`; S2 drop `:`; S3 drop the bare-number form; S4 drop its range part; S5 drop the en dash (O19-2); S6 drop `L?` | all killed |
| Real-ledger glue | X1 the real-ledger test ignores the function's result | survives (expected; O22-2) |
| Ledger edits under the real guard | L1 `` `.docs/mvp.md:40-68` `` in the Source column; L2 a prose line `` - See ES `PLANS.md:120`. … `` | both refused |
| Ledger edits under a mutant | L1 + B4; L2 + P4 | **both pass every test** (R22-1) |

A clean run before and after the batch passed all four guard tests. So report 20's mutant table holds for every mutant it names that I rebuilt (its A1 to A11, W1 to W9, G12 and C1 map onto my M, P, B, S and C rows), and O19-1 (W1 to W3) and O19-2 (G12) are closed.

### 2. The restructure finds what the old check found

A probe test (`scripts/zz_audit20_probe_test.go`, run in a scratch clone, not part of the PR) runs the `e83f2ba` form of the check (line loop plus `docSection` baseline rows) and `claimLedgerLineProblems` on each ledger the PR has carried (`oldnew.txt`):

| Ledger | Old: spans / cells | New: spans / cells | Same lines and spans, in order |
|---|---|---|---|
| `923e9c3` (original) | 53 / 6 | 53 / 6 | yes |
| `a0c844e` | 5 / 0 | 5 / 0 | yes |
| `4f4f597` | 0 / 0 | 0 / 0 | yes |
| `1160f28` | 0 / 0 | 0 / 0 | yes |

That confirms report 20's numbers and the PR body's "finds all 53 ranges and the 6 line-range baseline cells". On heading renames the new check fails closed (`headings-probe.txt`): renaming `### Control Plane` makes it run on through the CP and IM tables (63 problems); renaming `### Execution Substrate` to `### Execution Substrate (ES)` reports the missing table, where the old substring search would have matched the renamed heading and passed.

### 3. Report and PR body claims

Checked and true: one commit on `e83f2ba` touching only the guard file; 21 must-find and 8 must-find-nothing lines; the clean ledger with a CP range after the table yields nothing; the missing-table case; the real-ledger numbers; `trunk_dev` still `39e19de`; the manifest and textual-diff values. Not true: "expects eight exact messages" (report 20) for a `want` of nine (R22-2). The PR body says "every way of dropping a citation from a line that I tried fails it" and lists what was tried; P4 and B4 were not on that list, so the body is accurate as written, but the code comments claim more (R22-1).

### 4. Static checks and open PRs

- `gofmt -l heading_links_docs_contract_test.go` lists nothing; `go vet .` is clean; `git diff --check` is clean on `e83f2ba..1160f28` and on `39e19de..1160f28`.
- Open PR heads at about 00:30Z: #63 `59f1f56`, #66 `08143bd`, #68 `8e056aa` (moved since audit 19), #70 `77027f8`, #72 `553f1a0` (moved), #73 `affefc6`; #67 is stacked on another branch. `git merge-tree` merges `1160f28` cleanly with each; on each merged tree (checked to be the checked-out tree) the four guard tests pass. On the two moved heads I ran the whole root package and `internal/testutil`: 188 and 185 root tests pass, none fail (`trials20.txt`). None of the six touches the ledger or the guard file. (My first trial run was invalid: `git commit-tree` failed for lack of a git identity, so its tests ran on the unmerged head. I discarded it and reran with an identity set and a check that the checked-out tree is the merge tree; only the rerun is reported.)
- Cap headroom (audit 17's O17-1), rechecked: the largest `PLANS.md` I could build is 131,718 bytes, with #68, #70 and #72 merged on top (282 under the 132,000 cap). #72 and #73 conflict with each other, with or without #69, so they cannot both land as they are.

## Findings

### R22-1: the self-test does not show "every line" and "each cell"

- Type / severity: test gap, patch defect (the function and its sample ledgers are new in `1160f28`). **Low.**
- Contract: the comment on `claimLedgerLineProblems` (lines 188-193) says it reports "each line-citing code span of each ES citation, on every line, and each cell of the Execution Substrate source baseline table". The self-test's comment (lines 314-315) says the small ledgers show that "every line is scanned, every row of the baseline table and only that table". Audits 17 and 19 set the standard that the self-test must stop a later edit from weakening the rule; R19-1 was this same shape, one level up.
- Evidence (`mutants20.jsonl`):
  - P4 adds `if !strings.HasPrefix(strings.TrimSpace(line), "|") { continue }` to the line scan at line 197. All four guard tests pass. With the ledger edit L2 (`` - See ES `PLANS.md:120`. `` at the start of the "Control Plane is the current reference UI" bullet in section 5), they still pass, while the real guard refuses that edit.
  - B4 changes line 215's range to `strings.Split(…)[1:]`, skipping each row's first cell. All four pass. With L1 (`` `.docs/mvp.md:40-68` `` in the Source column of the ES baseline table) they still pass, while the real guard refuses L1. The Source column holds only a file path today, so a line number there is a plausible future edit.
  - Cause: the dirty ledger (lines 329-343) has ES line citations only on table rows (its lines 1, 2, 3 and 13), and its bad baseline cells are only in the second and third columns (its lines 7, 9 and 10). The earlier line and cell lists test the rule functions, not the loops.
  - P6 (skip the lines between the two baseline headings) also survives. For table rows it changes nothing, because the cell rule catches the same spans, but a prose line between the headings would escape. It costs nothing to kill with the same fix, so I include it.
- Impact: none on today's ledger, and the production code is correct. A one-line edit to the check would let an ES line citation back into any prose line, or into the Source column, without a test noticing.
- Required correction: put one ES line citation on a line that is not a table row, and one bad cell in the first column, in the dirty ledger, and extend `want`. The probe I ran (`proposed-fix-R22-1.diff`) adds `` "Sources: ES `x.md:5`." `` right after `claimLedgerBaselineStart` (kills P4 and P6 at once) and changes `` `y.md` `` to `` `y.md:3` `` in the Source column (kills B4), with the eleven expected messages. With it (`mutants20-probe.jsonl`) the real guard and the clean ledger still pass, all 44 other code mutants die, both ledger edits L1+B4 and L2+P4 fail the self-test, and only B10 and X1 survive. Any equivalent placement is the writer's call.
- Positions this closes: line kind (table row or not), line position (first, middle, last), row position (first and last data row), cell position (first, middle, last), citation position within a line (first, middle, last) and span position within a citation. I don't see another structural position the guard iterates over.
- Uncertainty: none; every claim above is a recorded run.

### R22-2: two wrong statements in the test file

- Type / severity: test/doc gap, patch defect. **Low (nit).** David's standing rule is that low nits are fixed in the PR, so it belongs in the same repair.
- (a) Lines 192-193: "`TestClaimLedgerCitesThisRepositoryBySection` runs it on the real ledger and on small synthetic ones." The synthetic ledgers are run by `TestClaimLedgerLineGuardFindsEachCitation` (lines 314-360).
- (b) Line 356: the failure message says "a ledger with eight line citations", but `want` holds nine problems (five spans and four cells), and report 20 says "eight exact messages". After R22-1's fix there would be eleven, so a message without a hard-coded count (or with `len(want)`) avoids the same slip next time.
- Uncertainty: none.

### Observations (not blocking)

- **O22-1, B10:** dropping the new `TrimSpace` from the row test (line 212) is not pinned. Only an indented table row would show it. That is a whitespace form, closer to the vocabulary class audit 17's lessons put out of scope, and the PR makes no claim about indented rows. Recorded, not asked for.
- **O22-2, X1:** the real-ledger test ignoring the function's result survives, as audit 19's O19-1 and report 20 say. No test can see it on a clean ledger, and the same is true of every real-document check in the repository.
- **O22-3, one subtest flipped between suite runs:** `scripts` `TestRemoteAlphaESServiceTLSStatusFailureWitnessBootstrapOwnedTerminal/execution-governance/fixture_read_fault` failed on base (a PTY fixture cleanup reported `terminated=false`) and passed on head. Its parent test fails on both sides, in this container as in audit 19's. I reran the parent three times on each side, alternating: the subtest passed all six times (`flake20.txt`). It is a container timing flake, not this PR, which changes no script code.
- **O22-4, carried from audit 19 unchanged:** O17-1 (cap headroom, now 282 bytes with the largest buildable combination, above), O17-2, O17-4 and O17-5 (not rechecked; not touched by the delta).

## Validation assessment

Full `go test -count=1 -timeout 40m -json ./...` as `ci` on clean clones of `39e19de` (00:13:21-00:21:58Z) and `1160f28` (00:21:58-00:29:23Z), one after the other with nothing else running (`suite-compare.txt`):

- 49 packages on both sides: 28 pass, 18 skip, 3 fail on both; no package verdict differs.
- Top-level tests: 1,939 on base, 1,943 on head. The only differences are the four tests in the PR's new file, which pass on head: `TestClaimLedgerCitesThisRepositoryBySection`, `TestClaimLedgerLineGuardFindsEachCitation`, `TestGithubHeadingAnchorsFollowGithubRules`, `TestMarkdownHeadingLinksResolve`. No top-level verdict changes. Root package: 181 pass on base, 185 on head, none failing.
- The same 14 top-level tests fail on base and head, by name, and the list is byte-identical to audit 19's (`failing-tests-base.txt` = `failing-tests-head.txt`):
  - es/admission/internal/reliablesubmit: `TestOperationalHandoffSchema4BinaryRefusesSchema5`, `TestSQLiteV3OldBinaryRefusesWithoutMutation`, `TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation`
  - es/app: `TestLinuxSetupBootstrapFinishesWithItsSavedSecret`, `TestNomadACLToolRetriesABootstrapThatNeverTookEffect`
  - scripts: `TestRemoteAlphaESServiceTLSStatusFailureWitnessBootstrapOwnedTerminal`, `TestRemoteAlphaESServiceTLSStatusRootLoadedStageCustody`, `TestRemoteAlphaESServiceTLSStatusStageFIFOSubstitution`, `TestRemoteAlphaOperatorRecoverySessionESTLSStatusRemoteWrapperTrap`, `TestRemoteAlphaOperatorRecoverySessionESTLSStatusStageFIFORefusal`, `TestRemoteAlphaP0tGrammarDiagnosticBootstrapLifecycleComposition`, `TestRemoteAlphaP0tGrammarDiagnosticPriorReaderCloseSuppression`, `TestRemoteAlphaP0tGrammarDiagnosticV2VersionedBootstrap`, `TestRemoteAlphaUpgradeESCheckRefusesWhatItWasNotWrittenFor`
- Subtests: 8,237 on both sides. One verdict change (O22-3, a flake). The 88 names on one side only are the randomized subtests of `TestRedTeamPR12HeadTwoSIGKILLsThenASurvivor`, `TestRedTeamPR12CombinedSIGKILLAtRandomInstants` and `TestRedTeamPR12HeadLiveProcessesRaceForOneClaim`.
- Mutant, probe and trial runs started only after both suite runs had finished.
- CI on `1160f28` (GitHub API): "build, vet and test" (job 140232048589) **success**, 00:08:58-01:03:00Z; "test on macOS" (job 140231965834) **success**, 00:11:48-00:43:47Z. The Linux log ends with the gate's expected-failure checks ("all 17 listed tests still fail on this host") and "tests as root passed: 9 of execution-substrate/scripts". These are the first green Linux and macOS runs on the current guard; CI on `8246cb2` (Linux) and `e83f2ba` (both) was cancelled by later pushes, and Linux last passed on `4f4f597`.
- Not run: the deletion sweep and the range mapping (their bytes have not changed since audit 17).

## Sensitive-material handling

No secrets, env files, keys or databases were read or copied. The evidence holds repository paths, hashes, test names, code excerpts, and a local proxy port in `scripts/env.sh`.

## Confidence

- Provenance: high. Manifest reproduced, stable, equal to the expected manifest; opening equals closing; head and base unchanged throughout.
- Validation: high. Full suite on both sides of the exact bytes, compared by name; 46 code mutants and 4 ledger edits, run twice (on the committed file and with the proposed fix); an old-versus-new comparison on four real ledgers; trial merges with every open PR.
- Implementation: high for R19-1 and the restructure. Medium-high for the self-test's protection against later edits, because of R22-1, which the two-line fix closes.

## Evidence

Folder `22-audit-evidence/` (hashes in `22-audit-evidence/SHA256SUMS`): `opening-manifest.json`, `closing-manifest.json`, `mutants20.jsonl`, `mutants20-probe.jsonl`, `proposed-fix-R22-1.diff`, `oldnew.txt`, `headings-probe.txt`, `suite-compare.txt`, `failing-tests-base.txt`, `failing-tests-head.txt`, `flake20.txt`, `trials20.txt`, and `scripts/` (`mutants20.py`, `zz_audit20_probe_test.go`, `compare20.py`, `trials20.sh`, `flake20.sh`, `mkclone.sh`, `run_suite.sh`, `asci.sh`, `env.sh`). The files and scripts carry "20" in their names because I named them before checking the next free report number; this report is number 22 (21 was taken by the writer's `21-step4-wip.bundle`).

## Effect status

Repair, commit, push, PR change, GitHub comment and merge: not performed.

**Final verdict: BLOCK** (R22-1, low; R22-2, low nit) for `1160f28`
