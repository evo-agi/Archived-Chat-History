# Report 18: ES PR #69, repair for re-audit 17 (R17-1)

New head: `8246cb274b4319164e5ff5954c35028ddde513f2` on `claude/project-thread-hfr05z`, one commit on top of `4f4f597`. It changes only `heading_links_docs_contract_test.go`.

## R17-1 (a): the self-test now uses the real cell rule

- The ES baseline-table cell rule is now one function, `claimLedgerBaselineCellCitesLines(cell string) bool`: a cell cites by line when `numericCell`, `lineRange` or `claimLedgerLineSpan` matches it. The check and the self-test both call it.
- Cells the self-test must refuse: `` `229` ``, `229`, ``Lines `1-229` ``, `Lines 1-229`, `1-229`, `` `L12`, `L40-L68` ``, `` `README.md:12` `` and `` `.docs/mvp.md#L40` ``. Each term of the rule is the only one that catches at least one of them.
- Cells it must accept: "The whole file", "Sections 1, 2, 3, 4 and 8", the `AGENTS.md` cell ("Sections 3 to 5, 7 and 10 to 12, cited by section because its lines move"), a `PLANS.md` section link and a plain path. These are the shapes the table uses today.

## R17-1 (b): a range in a later ES citation

Two lines the self-test must refuse, where only the second `ES` citation on the line cites by line:

- ``ES [`x.md` § A](x.md#a); ES [`y.md` § B](y.md#b), `51-82` ``
- ``| ES [`x.md` § A](x.md#a) | ES [`y.md` § B](y.md#b), `L70` |``

## Mutants (each run against `TestClaimLedgerCitesThisRepositoryBySection`)

| Mutant | Result |
|---|---|
| G7: cell rule back to `numericCell && lineRange` | killed |
| G8: drop `claimLedgerLineSpan` from the cell rule | killed |
| drop `lineRange` from the cell rule | killed |
| drop `numericCell` from the cell rule | killed |
| cell rule always false | killed |
| G9: check only the first ES citation per line (`FindAllString(line, 1)`) | killed |

The rest of the guard is unchanged, so audit 17's other mutants (G1 to G6, K1 to K14) keep their results.

## O17-3

The PR body's sentence on the baseline table now says what the code checks: no cell that holds only line numbers, holds a digit range, or holds a code span that cites by line.

## Validation

- Root package: passes (`go test -count=1 .`). `go vet .`, `gofmt -l` on the file and `git diff --check` are clean. No other package changed, so the full-suite results in audit 17 stand.
- CI on `8246cb2`: started on push; result reported in the thread.

## Manifest

v2 recipe (source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified), fresh clone, `git checkout -f -B claude/project-thread-hfr05z 8246cb2`, `git reset --mixed 923e9c3`, upstream `origin/trunk_dev`, run twice, identical:

- Manifest SHA-256 `be88a750feeeae86785216bd0de8e6d721834ba15440bf6b6520a5286e67f4e5` (`18-expected-manifest.json`), 13 files.
- Textual diff SHA-256 `1acd80c26cde0cdc7e9135aa69624f75f3f7c5c434f7c1290683f7ca9acec3e9`, the same as at `4f4f597`. That is expected: `heading_links_docs_contract_test.go` is a new file, so it is untracked after the reset and appears only in its file record, not in `git diff HEAD`.
- Against `15-expected-manifest.json`, the path set, `head`, `branch`, `upstream`, `recipe_id` and textual diff are equal; only the record of `heading_links_docs_contract_test.go` changed.

## Update: trunk_dev merged in (after #71 landed)

`trunk_dev` moved to `39e19de` (#71, Workstream F slice F1) at 23:58Z, and the repository requires an up-to-date branch, so I merged it in. New head: `e83f2bac80ab370867118d479b12a4935f901d66` (merge commit, no conflicts).

- The PR's own change is unchanged: `git diff 923e9c3 8246cb2` and `git diff 39e19de e83f2ba` have the same stable patch-id (`b37db5cb…`) and the same changed lines.
- `PLANS.md` is 130,525 bytes, under the 132,000 cap. The root package and `internal/testutil` pass on the merge; `go vet .` is clean.
- Manifest (v2 recipe, verified; `e83f2ba` reset onto `39e19de`, upstream `origin/trunk_dev`, run twice, identical): SHA-256 `507e247b09278cb4d3e0618b81d2bc6fe619dde3570b991fb40290315b85e9d7` (`18b-expected-manifest-after-71-merge.json`), 13 files, textual diff `932b3f3f0394e09a2a7b4262cc5cc1c0e8ae139fd37ac7005deaad6c5ab157bf`. Against `18-expected-manifest.json`, the path set is equal; `head` and the textual diff change with the base, and the records of `PLANS.md`, `.docs/execution_lifecycle/contracts.md` and `.docs/system_overview/remote_supported_host_alpha.md` change because #71 edited those files too.
