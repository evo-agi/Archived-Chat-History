# Implementation report 15: ES PR #69 repair of audit 14 (A14-1, A14-2)

- Repository: evo-agi/Execution-Substrate, PR #69, branch `claude/project-thread-hfr05z`
- Base: `923e9c3366775664c8a85f19273e3dd4fc04eb22` (origin/trunk_dev)
- Previous audited head: `a0c844e6e0fb75b49da196225cb3a8939e4b0acd`
- New head: `4f4f5979f183b46ca8dc80a7f85ec8527e7a2024` (one commit on top, no history rewrite)
- Files changed by the repair commit: `.docs/commercialization/claim-ledger.md`, `heading_links_docs_contract_test.go`

## A14-1 (five ES line ranges)

The five continuation ranges are section links now, mapped at `6300b95` (headings checked there, names checked on head):

| Row | Range at 6300b95 | Linked as | Coverage |
|---|---|---|---|
| C7 | contracts.md `384-535` | § 7. Status contract | wider: leaves out §7 "Reopened seams" (536-542), one of the nine below |
| C11 | capability_probing.md `51-82` | § Placement Rules, § Failure Behavior | exact (51-69, 70-82) |
| D1 | runtime_identity_handoff.md `63-127` | § 3, § 4, § 5 | exact (63-75, 76-96, 97-128) |
| D2 | runtime_identity_handoff.md `160-228` | § 8, § 9, § 10 | exact (160-177, 178-204, 205-end) |
| H3 | runtime_identity_handoff.md `97-127` | § 5. Ownership and non-ownership | exact |

Each row's existing links were joined into one list ("A, B, C and D"); no other text in the rows changed.

Guard: `claimLedgerLineCitations` takes each ES citation in a ledger line (from `ES` to the next `;`, cell end, `CP \`` or `IM \``, or line end) and refuses any code span in it that cites by line: a path ending in `:<n>` or `#L<n>`, or a code span that is only a line number or range. On the original ledger (`923e9c3`) it finds all 53 ranges; on `a0c844e` it finds exactly the five above; on the new head it finds none. Self-test: seven lines it must refuse (including `ES [\`x.md\` § A](x.md#a), \`51-82\`` and a range after a "(CP compatibility)" aside) and seven it must accept (CP and IM ranges, including after an ES citation in the same cell or line).

O-3 also fixed: the ES source-baseline table check now refuses a cell that is a line number, has a digit range, or holds a line code span (so `\`229\`` and `Lines \`1-229\`` fail).

Mutants run on the new head, each killed: bare range after an ES link (your L3); single-line cell `229` (L5); `Lines \`1-229\`` cell (L6); restoring "each range covered whole sections"; dropping the "rests only on the part the range covered" clause (pinned); a `path:1-5` code span inside an ES citation.

## A14-2 (nine wider links)

Not narrowed. The only finer targets are the `###` subsections of contracts.md sections 5, 6, 7 and 10 ("Purpose", "Request contract", ...), which repeat in every section, so their anchors carry GitHub's `-1`, `-2` suffixes. Those numbers shift when a section is added above, and a shifted anchor can still resolve, to the wrong section, so the heading-link guard would not catch it. The other four ranges leave out a closing paragraph, a last bullet, or unlabelled parts with no heading.

So the ledger now states the rule used, replacing "where each range covered whole sections":

> They were mapped from the 53 line ranges this ledger cited when it was written, at commit `6300b95...`: each range is linked to the whole sections that contain it, named by their current headings. Nine of the distinct ranges stopped inside a section, so their links are wider than the lines first cited, and a claim that cites one of them rests only on the part the range covered. Five ended just before the "Reopened seams" subsection of section 5, 6, 7 or 10 of contracts.md. Three left out the closing paragraph or last bullet of a section: section 3 of that file, section 8 of the CP consumer runbook and section 2 of runtime_identity_handoff.md. One covered only the "Current consumers / collaborators", "Boundary pressure points" and "Temporary compatibility edges" parts of section 8 of boundaries.md, leaving out its purpose, ownership, non-ownership and "Reopened seams" parts.

The boundaries.md description was checked at `6300b95`: lines 350-424 run from the first bullet under "**Current consumers / collaborators**" (348) through "**Boundary pressure points**" (357) and "**Temporary compatibility edges**" (407), ending before "**Reopened seams**" (426). So it is not "consumers, invariants and compatibility edges" as audit 14 put it. The test pins the first two sentences.

## Validation

- Root package `go test -count=1 .`: pass. `go vet .`, `gofmt -l` on the changed test file and `git diff --check`: clean.
- Only root-package files changed since the full-suite run on `a0c844e`, so that run's per-package results stand for every other package.
- `TestMarkdownHeadingLinksResolve` now checks 109 links (99 plus the ten new ones), none broken.
- CI on `4f4f597`: green. "test on macOS" passed at 22:49Z and "build, vet and test" at 23:02Z (2026-11-26). CI on `a0c844e` was also green.

## Manifest (v2 recipe, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified)

Taken per provenance §5.3: fresh clone, `git checkout -f -B claude/project-thread-hfr05z 4f4f597`, clean, `git reset --mixed 923e9c3`, upstream `origin/trunk_dev`. Two runs, byte-identical.

- manifest_sha256 `e94bda8571680d276d14a48d64255ade8e4803caa6b4e64ec103b54111e24381`
- textual_diff_sha256 `1acd80c26cde0cdc7e9135aa69624f75f3f7c5c434f7c1290683f7ca9acec3e9`
- 13 files. Canonical JSON, byte for byte: `15-expected-manifest.json` in this folder.

Compared with audit 14's manifest (`cc777004...d43a`), only two file records change: `.docs/commercialization/claim-ledger.md` and `heading_links_docs_contract_test.go`.

## Not changed

- O-2 (ordinary PLANS.md mentions that now reach moved text only through pointers): left for step 4, which moves more text and can repoint them in the same pass.
- O-4 (cap headroom): step 4 lowers PLANS.md to about 72 KB.
