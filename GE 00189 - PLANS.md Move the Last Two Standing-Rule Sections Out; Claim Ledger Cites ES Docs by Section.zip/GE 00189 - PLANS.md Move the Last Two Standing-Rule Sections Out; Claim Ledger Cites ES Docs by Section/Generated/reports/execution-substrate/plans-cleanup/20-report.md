# Report 20: ES PR #69, repair for re-audit 19 (R19-1, with O19-1 and O19-2)

New head: `1160f28bd47ca04e18195451dc4c64e8a87aee7c` on `claude/project-thread-hfr05z`, one commit on top of `e83f2ba` (the merge of `trunk_dev` `39e19de`, #71). It changes only `heading_links_docs_contract_test.go`. The delta to check is `git diff e83f2ba 1160f28`.

## What changed

The coordinator asked to close the whole class of aggregation mistakes at once, so the repair goes further than R19-1's single line.

1. **One check over the ledger.** `claimLedgerLineProblems(ledger string) []string` returns one message for each place a ledger cites this repository by line:
   - each line-citing code span of each ES citation, on every line;
   - each cell of the ES source baseline table that cites by line (the table runs from the `### Execution Substrate` line to the `### Control Plane` line);
   - a missing baseline table.
   
   `TestClaimLedgerCitesThisRepositoryBySection` now only calls it on the real ledger and keeps its pinned sentences and link count. The loops that audit 19's O19-1 found untested (W1 to W3) are inside the function now.
2. **A new self-test, `TestClaimLedgerLineGuardFindsEachCitation`**, with exact expected results, not "found something":
   - 21 lines with the exact spans `claimLedgerLineCitations` must return, in order and with repeats. They cover: one ES citation; a range in the first, a middle or the last of three ES citations, ended by `;`, by a cell end, or by a CP citation; ranges in two of the three; two spans in one citation; the same span in all three citations (expects three); and the en dash form (O19-2).
   - 8 lines that must return nothing, including three clean ES citations on one line and CP and IM ranges after an ES citation.
   - The baseline cell cases from the last repair, unchanged.
   - `claimLedgerLineProblems` on a clean small ledger (no problems, though a CP range follows the table) and on a dirty one. The dirty ledger has line citations on its first and last lines, two on one line, and a baseline row with two bad cells, so it expects eight exact messages in order. A ledger without the table must report the missing table.

## Probe on real ledgers

`claimLedgerLineProblems` finds 53 line citations and 6 baseline cells on the original ledger (`923e9c3`), 5 line citations on `a0c844e`, and none on `4f4f597` or the new head.

## Mutants

All run against the four guard tests (`TestClaimLedger*`, `TestMarkdownHeadingLinksResolve`, `TestGithubHeadingAnchorsFollowGithubRules`), each from the committed file, which was restored after each run.

| Mutant | Result |
|---|---|
| A1 first ES citation only (`FindAllString(line, 1)`; audit 17's G9) | killed |
| A2 last ES citation only (`found =` instead of append; audit 19's E4) | killed |
| A3 one span per citation (`FindAllString(citation, 1)`; audit 19's E7) | killed |
| A4 stop at the first citation that yields a span | killed |
| A5 drop repeated spans | killed |
| A6 keep only the first span of a line / A7 only the last | killed / killed |
| A8 skip the first ES citation / A9 skip the second | killed / killed |
| A10 reverse the order | killed |
| A11 one problem per line | killed |
| W1 the old `numericCell && lineRange` rule at the call site (audit 19) | killed |
| W2 never scan lines (audit 19) / W3 skip baseline rows (audit 19) | killed / killed |
| W4 never enter the table / W5 never leave it / W6 do not report a missing table | killed |
| W7 skip the last line / W8 skip the first line / W9 one problem per baseline row | killed |
| G12 drop the en dash from `claimLedgerLineSpan` (O19-2) | killed |
| C1 drop `numericCell` from the cell rule | killed |
| G1 to G6, G10, G11, G13 (audits 17 and 19's pattern mutants, rerun) | all killed |
| C2 the real-ledger test ignores what the function returns | survives |

C2 is the one line left outside the function: `for _, problem := range claimLedgerLineProblems(ledger) { t.Errorf(...) }`. On a clean ledger no test can tell it apart from a no-op. That is true of every real-document check in the repository, and audit 19 recorded it as outside the claim.

## Validation

- Root package passes; `go vet .`, `gofmt -l` on the file and `git diff --check` are clean. No other file changed, so audit 19's full-suite comparison stands.
- `trunk_dev` is still `39e19de`.
- CI on `1160f28`: green. "build, vet and test" and "test on macOS" both passed (finished 01:03Z). GitHub reports the PR mergeable (clean) against `trunk_dev` `39e19de`.

## Manifest

v2 recipe (source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified), fresh clone, `git checkout -f -B claude/project-thread-hfr05z 1160f28`, `git reset --mixed 39e19de`, upstream `origin/trunk_dev`, run twice, identical:

- Manifest SHA-256 `1da4f9990c93f2dfa8c67e1a89fb093b0cb21c32919671c843c0fa9c5d8e0817` (`20-expected-manifest.json`), 13 files.
- Textual diff SHA-256 `932b3f3f0394e09a2a7b4262cc5cc1c0e8ae139fd37ac7005deaad6c5ab157bf`, unchanged from `e83f2ba`, because the changed file is new to the PR and so untracked after the reset.
- Against `18b-expected-manifest-after-71-merge.json`, everything is equal except the record of `heading_links_docs_contract_test.go`.
