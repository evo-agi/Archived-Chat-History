# Report 23: ES PR #69, repair for re-audit 22 (R22-1, R22-2)

New head: `4bc228c5961a3875a67acff7d06e8c04c726c662` on `claude/project-thread-hfr05z`, one commit on top of `1160f28`. It changes only `heading_links_docs_contract_test.go` (+15/−8). The delta to check is `git diff 1160f28 4bc228c`.

## R22-1: a prose line and a first-column cell in the dirty ledger

I reviewed the auditor's `22-audit-evidence/proposed-fix-R22-1.diff` (SHA-256 `31bd061d…6159`, equal to its entry in that folder's `SHA256SUMS`) and applied it as given with `git apply`:

- `"Sources: ES `x.md:5`."` right after `claimLedgerBaselineStart`. It is not a table row and it sits between the two baseline headings, so a line scan that visits only table rows (P4) or skips the baseline section (P6) misses it.
- `` `y.md` `` becomes `` `y.md:3` `` in the Source column, so a cell loop that skips the first column (B4) misses it.
- `want` grows from nine to eleven messages, with the line numbers after the inserted line shifted by one.

I also rewrote the self-test's comment so it says what the small ledgers now show: table rows and other lines alike, the first and last line and the lines between the baseline headings; the first, a middle and the last cell of the baseline rows; only that table; and the missing table.

## R22-2: the two wrong statements

- The comment on `claimLedgerLineProblems` now says `TestClaimLedgerCitesThisRepositoryBySection` runs it on the real ledger and `TestClaimLedgerLineGuardFindsEachCitation` on small synthetic ones.
- The failure message no longer hard-codes a count: it prints `len(want)`.
- Report 20's "expects eight exact messages" was wrong: it expected nine. With this repair it expects eleven. I have left report 20 as written and record the correction here.

## Mutants

I ran the auditor's 46 code mutants and 4 ledger edits (their definitions taken as text from `22-audit-evidence/scripts/mutants20.py`, with my own runner), plus one of mine (N1, the cell rule always false), against the four guard tests on a clean clone of `4bc228c`, restoring the file after each. Results are in `23-repair-evidence/mutants23.jsonl`.

| Group | Result |
|---|---|
| M1 to M12 (collecting a line's citations and spans) | all killed |
| R1 to R6 (where a citation ends) | all killed |
| P1 to P7 (which lines the scan visits), **including P4 and P6** | all killed |
| B1 to B9 and B11 (which rows and cells are checked), **including B4** | all killed |
| C1, C3, C4 and N1 (the cell rule) | all killed |
| S1 to S6 (the span pattern) | all killed |
| L1 and L2 under the real guard | both refused |
| **L1 + B4 and L2 + P4** | both fail the self-test |
| B10 (row test without `TrimSpace`) | survives: audit 22's O22-1, not asked for |
| X1 (real-ledger test ignores the result) | survives: outside the claim (O22-2) |

The clean baseline passed before and after the batch. That is the same picture as the auditor's probe run (`mutants20-probe.jsonl`): 44 of their 46 code mutants killed, plus N1, and only B10 and X1 surviving.

## Validation

- Root package passes (`go test -count=1 .`). `go vet .` is clean, `gofmt -l` lists nothing for the file, and `git diff --check 1160f28 4bc228c` is clean. No other file changed, so audit 22's full-suite comparison stands.
- `trunk_dev` is still `39e19de`.
- CI on `4bc228c`: started on push.
- PR body updated: the sixth commit, the dirty ledger's new positions, the added mutants (only table rows, skipping the lines between the baseline headings, the first or last cell of a row), and two survivors named instead of one (X1, and B10 from audit 22's O22-1). The manifest line now gives `5d5c17ec…d14b`.

## Manifest

v2 recipe (source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked on the project copy and on the copy I ran), fresh clone, `git checkout -f -B claude/project-thread-hfr05z 4bc228c`, clean status, `git reset --mixed 39e19de`, upstream `origin/trunk_dev`, run twice, byte-identical:

- Manifest SHA-256 `5d5c17ec12a2c89df0035aa923f2bfa1ae6015808572beeadf105c6c2a92d14b` (`23-expected-manifest.json`), 13 files.
- Textual diff SHA-256 `932b3f3f0394e09a2a7b4262cc5cc1c0e8ae139fd37ac7005deaad6c5ab157bf`, unchanged, because the changed file is new to the PR and so untracked after the reset.
- Against `20-expected-manifest.json`: same path set, `head`, `branch`, `upstream`, `recipe_id` and textual diff. The only changed record is `heading_links_docs_contract_test.go` (`756e9980…`, 16,010 bytes → `939e0f39…`, 16,429 bytes).

## Update: CI green, then trunk_dev merged in (after #72 landed)

- CI on `4bc228c`: green. "build, vet and test" (job 140251063387) and "test on macOS" (job 140251063563) both passed, finished 02:06Z.
- `trunk_dev` moved to `fbfd100` (#72, F1 WI-3a) meanwhile, and the repository requires an up-to-date branch, so I merged it in. New head: `cb8260c0ad4c68dccd642d5f0e93d4d336d617d7` (merge commit, no conflicts).
- The PR's own change is unchanged: `git diff 39e19de 4bc228c` and `git diff fbfd100 cb8260c` have the same stable patch-id (`b6b19ee3…`). `git diff --check` is clean.
- `PLANS.md` is 130,664 bytes, under the 132,000 cap. The root package, `internal/testutil`, `internal/callerallowlist` and `cgs/policy` pass on the merge; `go vet .` is clean.
- CI on `cb8260c`: started on push.
- Manifest (v2 recipe, verified; `cb8260c` reset onto `fbfd100`, upstream `origin/trunk_dev`, run twice, identical): SHA-256 `d0ebda3386ce97a97e78f7fb6e28656815769933bee6ab241ff2a79280c3c7c8` (`23b-expected-manifest-after-72-merge.json`), 13 files, textual diff `694e0d33fc05bfb120fe1b907f432308b59b0abdabc8f30080549e735003405a`. Against `23-expected-manifest.json`, the path set is equal; `head` and the textual diff change with the base, and the records of `PLANS.md` and `.docs/execution_lifecycle/contracts.md` change because #72 edited those files too.

## Update: re-check 24 accepted `cb8260c`; trunk_dev merged in after #68

- Re-check 24 (`24-audit.md`, SHA-256 `02e1a912…3284`) accepted `cb8260c`.
- `trunk_dev` moved to `a5861b7` (#68, the service layout) meanwhile. I held the merge until the verdict, then pushed it as `446d8a865d5a4dfffb7124623360c0c7f28e376f`. Its parents are `cb8260c` and `a5861b7`, and its tree (`b3c6119…`) equals `git merge-tree --write-tree cb8260c a5861b7`, so it is git's own clean merge.
- The PR's own change is unchanged: `git diff fbfd100 cb8260c` and `git diff a5861b7 446d8a8` have the same stable patch-id (`b6b19ee3…`).
- `PLANS.md` is 130,688 bytes, under the 132,000 cap. The root package (including `service_layout_test.go` from #68) and `internal/testutil` pass on the merge; `go vet .` is clean.
- Manifest (v2 recipe, verified; `446d8a8` reset onto `a5861b7`, upstream `origin/trunk_dev`, run twice, identical): SHA-256 `93be9df457d35532eae7e671dd09de5c0e6d151f696fa56d9e160c6ad9788ccd` (`23c-expected-manifest-after-68-merge.json`), 13 files, textual diff `374ee844366a4aec2fddeb757ef51e8696f3eb8d7ca76e329363bd360bc48317`. Against `23b-expected-manifest-after-72-merge.json`, the path set is equal; `head` and the textual diff change with the base, and the records of `PLANS.md` and `README.md` change because #68 edited those files too.
- CI on `446d8a8`: started on push.
