# Independent re-audit 24: ES PR #69 at cb8260c (repair of re-audit 22, plus the #72 merge)

**Verdict: ACCEPT** for `cb8260c`. This is a PASS in the coordinator's terms. No finding blocks.

- **R22-1 is fixed.** Commit `4bc228c` holds the prior auditor's `proposed-fix-R22-1.diff` exactly as written. I applied that diff to `1160f28` with `git apply` and got the blob the diff names, `4004210…`. The only other changes in `4bc228c` are the three R22-2 comment and message hunks.
- **R22-2 is fixed.** Both wrong statements are corrected. Report 20's wrong count is corrected in report 23, as the writer says.
- **The merge leaves the PR's diff unchanged.** `cb8260c` is git's own clean merge of `4bc228c` and `fbfd100`: `git merge-tree` gives exactly the commit's tree. The PR's own diff has the same stable patch-id before and after the merge (`b6b19ee3…`), and the same text apart from hunk offsets. The merge brings in exactly #72's files, with #72's own patch-id.
- **The mutant claim holds: 45 of 47 killed.** I ran the 47 code mutants on the exact bytes of `cb8260c`. They are audit 22's 46, taken verbatim from its script with the script's hash checked, plus the writer's N1. 45 die, and only B10 and X1 survive. Both survivors are outside the guard's stated claim (O22-1, O22-2). All 4 ledger edits behave as stated.
- **Full suite:** I compared base `fbfd100` and head `cb8260c` by test name. No verdict changes. The same 14 top-level tests fail on both sides, and that list is byte-identical to audit 22's. The four new tests pass on head.
- **Provenance:** the manifest reproduces byte for byte: `d0ebda33…c7c8` (report 23b), and `5d5c17ec…d14b` for `4bc228c` on `39e19de`. The closing manifest equals the opening one.
- **CI on `cb8260c` is green:** "build, vet and test" and "test on macOS" both passed (finished 02:59:49Z and 02:36:34Z). Both also passed on `4bc228c`.

One thing to act on that is not a finding: `trunk_dev` moved to `a5861b7` (#68, merged 02:20:59Z) while I audited. The repository requires an up-to-date branch, so the PR needs one more `trunk_dev` merge before it can merge. A trial merge is clean (details in O24-3). Under the ES merge-queue rule, the writer's own sync-only check suffices if that merge is again git's own clean merge with the patch unchanged.

Effect status: read-only audit. Nothing was committed, pushed, opened, commented on or merged.

## Target

| Item | Value |
|---|---|
| Repository | evo-agi/Execution-Substrate |
| PR | #69, branch `claude/project-thread-hfr05z` |
| Audited head | `cb8260c0ad4c68dccd642d5f0e93d4d336d617d7` (= pushed branch tip = `refs/pull/69/head`, at the start and at the end) |
| Head tree | `7ba5f7338bdd8f298eb2ffc2359a462c207598e0` |
| Base | `fbfd100946d2cb8f25232bac182b94fb299c66da` (`trunk_dev` at the start; it moved to `a5861b7` at 02:20:59Z, see O24-3) |
| Delta under review | `git diff 1160f28 4bc228c` (`heading_links_docs_contract_test.go` only, +17/−10), plus the merge `cb8260c` = `4bc228c` + `fbfd100` (#72) |
| Recipe | `governed_execution_audit_patch_manifest_v2.py`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (checked on the project copy and on the copy I ran) |
| Canonical manifest | SHA-256 `d0ebda3386ce97a97e78f7fb6e28656815769933bee6ab241ff2a79280c3c7c8`, 13 files |
| Textual diff | SHA-256 `694e0d33fc05bfb120fe1b907f432308b59b0abdabc8f30080549e735003405a` |
| Implementation report | `23-report.md` (SHA-256 `3f25c48b614070e013b3c3bb01dfb1dbd7a6390801a5245b94b880c055b86bc3`), expected manifests `23-expected-manifest.json` (`5d5c17ec…d14b`) and `23b-expected-manifest-after-72-merge.json` (`d0ebda33…c7c8`) |
| Prior audit | `22-audit.md` (SHA-256 `438556c275cd8a0ce5bfb85365f7896c1d890900617ce8a41339c08948f313d6`); 14, 17 and 19 before it. All were written by other threads. |

## Audit posture

This is a fresh, read-only thread that had not audited this PR before (protocol §14). No subagents were used. Tests ran in fresh clones under `/opt/audit/trees`, made from the provenance clone's objects and checked out at exact SHAs. They ran as an unprivileged user `ci` (uid 1500, gid 1600), started with `runuser -u ci -- env -i`, with `umask 022` and HUP/INT/QUIT/TERM/PIPE reset to their defaults. The toolchain was go1.26.5 linux/amd64, fetched as the `golang.org/toolchain` module, which the Go checksum database verifies. go.dev and dl.google.com were blocked here. I installed the host packages acl, uuid-runtime, openssh-client, iproute2, locales and bindfs, plus the en_US.UTF-8 locale. I wrote my own runner, comparison and setup scripts (`24-audit-evidence/scripts/`). The mutant definitions are audit 22's, used as data: my runner executes only the definition block of `mutants20.py`, after checking that file's SHA-256 against `22-audit-evidence/SHA256SUMS`. I did not use the writer's runner. I took only the text of N1 from it.

## Provenance reproduction

I ran the commands from provenance §5.3 in a fresh clone (`/opt/audit/prov`): fetch `trunk_dev`, the topic branch and `refs/pull/69/head`; check the pushed tip `cb8260c` against the reported tip and the PR head; check that `fbfd100` is its ancestor; `git checkout -f -B claude/project-thread-hfr05z cb8260c`; clean status; `git reset --mixed fbfd100`; upstream `origin/trunk_dev`; run v2 twice into a fresh `0700` directory.

- The two runs are byte-identical, and they equal `23b-expected-manifest-after-72-merge.json` byte for byte (`cmp`): `d0ebda33…c7c8`, 13 files, textual diff `694e0d33…405a`. No mode differences.
- The same procedure in a second clone for `4bc228c` on `39e19de` reproduces `23-expected-manifest.json` byte for byte (`5d5c17ec…d14b`). `4bc228c` is in the branch, and its only parent is `1160f28`.
- `git diff --name-status 1160f28 4bc228c` lists only the guard file. So the other 12 files at `4bc228c` are the bytes audit 22 reviewed, and audit 22 reproduced `1160f28`'s manifest.
- Closing run: see the end of this report.

## Coverage

Read: audit 22 (R22-1, R22-2 and O22-1 to O22-4), report 23, the PR body, the whole repair delta, the whole guard function and self-test at `4bc228c`, the ES source baseline table of the real ledger, and #72's changes to the two files it shares with the PR. Scope, as the brief asks: commit `4bc228c`, the merge in `cb8260c`, and the mutant claim, within the guard's stated limits. I did not re-inspect the moves, the range mapping, the deletion sweep, or the CP and IM ranges. Their bytes have not changed since audit 17, apart from what #71 and #72 brought in through clean merges.

### 1. `4bc228c` is the proposed fix plus R22-2

The check is in `24-audit-evidence/fix-vs-head.diff`:

- `git show 1160f28:heading_links_docs_contract_test.go` (blob `7181286…`, which is the diff's `index` source) with `proposed-fix-R22-1.diff` applied (`git apply --check`, then `git apply`) gives blob `400421038d24…`. That is the diff's `index` target, `4004210`.
- `diff -u` of that file against `4bc228c`'s file shows exactly three hunks, all R22-2:
  - (a) Lines 192-194: the function comment now says `TestClaimLedgerCitesThisRepositoryBySection` runs it on the real ledger, and `TestClaimLedgerLineGuardFindsEachCitation` on small synthetic ones. Checked true: lines 232-235 and lines 320-367 at `4bc228c`.
  - (b) Line 363: the failure message prints `len(want)` instead of the hard-coded "eight". `want` holds 11 messages, one per span or cell, so "a ledger with 11 line citations" is accurate.
  - (c) Lines 315-319: the rewritten self-test comment. I checked each of its claims against the dirty ledger and the mutant results:
    - "table rows and other lines alike": P4 and P5 are killed, by line 5, `Sources: ES \`x.md:5\`.`.
    - "the first, the last": P1, P2 and P8 are killed, by lines 1 and 14.
    - "the lines between the baseline headings": P6 is killed, by line 5.
    - Cells "first, middle and last": B4 is killed by the first cell at line 9; middle cells are at lines 8, 10 and 11; B5 and B6 are killed by the last cell at line 11.
    - "every row": B8, B9 and my B12 (skip the data rows between the first and last) are killed.
    - "only that table": B2 is killed.
    - "a missing table is found": B3 is killed.
    - The one gap: "every row" also covers the header row, which the self-test cannot show. See O24-1.
- `gofmt -l` lists nothing for the file. `go vet .` is clean (go1.26.5, as `ci`). `git diff --check` is clean on `1160f28..4bc228c` and on `fbfd100..cb8260c`.

### 2. The merge `cb8260c` leaves the PR's diff unchanged

The check is in `24-audit-evidence/merge-check.txt`:

- `cb8260c`'s parents are `4bc228c` and `fbfd100`, and their merge base is `39e19de`, the base audit 22 used. `git merge-tree --write-tree 4bc228c fbfd100` gives `7ba5f733…`, which equals `cb8260c^{tree}`. So the merge is git's own clean merge, with no hand edit.
- The stable patch-id of the PR's diff is `b6b19ee3…` both before (`39e19de..4bc228c`) and after (`fbfd100..cb8260c`). The two diffs are also textually identical once `@@` and `index` lines are dropped.
- What the merge brings in (`4bc228c..cb8260c`) has #72's own patch-id (`81d9ea9f…`) and exactly #72's 13 files. #72's edits to the two shared files, `PLANS.md` (current-state facts and the F1 record) and `.docs/execution_lifecycle/contracts.md`, are outside the sections the PR moves. The guard file is identical in `4bc228c` and `cb8260c`.
- `PLANS.md` at `cb8260c` is 130,664 bytes, under the 132,000 cap, as report 23 says.

### 3. The mutant claim: 45 of 47

I ran `mutants24.jsonl` on a clean clone of `cb8260c`. It runs the four guard tests per mutant, restores the tree after each, and checks that the tree is clean. A clean baseline passed before and after the batch.

| Group | Result |
|---|---|
| M1 to M12 (collecting a line's citations and spans) | all 12 killed |
| R1 to R6 (where a citation ends) | all 6 killed |
| P1 to P7 (which lines the scan visits), **including P4 and P6** | all 7 killed |
| B1 to B9 and B11 (rows and cells), **including B4** | all 10 killed |
| B10 (row test without `TrimSpace`) | survives (O22-1) |
| C1, C3, C4 (cell rule) and N1 (writer's: cell rule always false) | all 4 killed |
| S1 to S6 (span pattern) | all 6 killed |
| X1 (real-ledger test ignores the result) | survives (O22-2) |
| L1, L2 under the real guard | both refused |
| L1 + B4, L2 + P4 | both fail the self-test |

That makes 45 of 47 code mutants killed, with B10 and X1 surviving: the same as report 23's `mutants23.jsonl` and audit 22's `mutants20-probe.jsonl`. Both survivors are outside the guard's stated claim. The PR body names both and claims nothing about indented rows. No test can see X1 on a clean ledger.

I added four probes of the new comment, which are not part of the 47:

- B12 (skip the data rows between the first and last) and P8 (skip the lines between the first and last) are killed.
- H1 (skip the header row) and H2 (skip the header and separator rows) survive. See O24-1.

## Findings

No blocking findings. No new patch defects.

### Observations (not blocking)

- **O24-1, header row (H1, H2):** a check that skips the baseline table's header row, or its header and separator rows, passes every test. That is because neither small ledger has a line citation in its header. The new comment's "every cell of every row of the baseline table" could be read to include the header row. I do not count this as a defect, for four reasons:
  - The header names the columns and holds no source. In the real ledger it is `| Source | Sections inspected | Why it matters |`.
  - The separator row must hold only dashes and colons, or the table does not render.
  - The phrase "every row of the baseline table" was already in the comment at `1160f28`. Audit 22 read it as data rows and listed the row positions it closed as "first and last data row".
  - The coordinator scoped this re-check to the guard's stated limits.

  No change is asked. If the coordinator reads "every row" more strictly, the fix is one header cell in the dirty ledger plus one more `want` line.
- **O24-2, B10 and X1:** they survive as stated. This is O22-1 and O22-2, carried over unchanged.
- **O24-3, `trunk_dev` moved during the audit:** #68 landed at `a5861b7` (02:20:59Z), after `cb8260c` was pushed (02:06:41Z). The repository requires up-to-date branches, so the PR needs one more `trunk_dev` merge before it can merge, and that merge makes new bytes. Audit 22 had flagged the #68 overlap: both PRs touch `PLANS.md` and `README.md`. I trial-merged `cb8260c` with `a5861b7` locally, in a commit that was never pushed (`24-audit-evidence/trial-68.txt`):
  - `git merge-tree` is clean.
  - `PLANS.md` is 130,688 bytes, 1,312 under the cap.
  - The root package passes 188 tests and `internal/testutil` passes 6, with none failing, on the checked-out merge tree (checked to be the merge tree).

  Under the ES merge-queue rule (procedures.md), a git-own clean merge with the PR's patch and manifest entries unchanged needs only the writer's sync-only check. Any conflict or hand edit needs an auditor delta check.
- **O24-4, report 23's line counts:** the report says the repair is "+15/−8". `git diff --numstat 1160f28 4bc228c` gives +17/−10. This is report-only, and no bytes depend on it.
- **O24-5, container setup:** my first full-suite run gave 8 extra `es/app` failures, on base and head alike. My `ci` environment's `no_proxy` lacked `.internal`, so the scripts' `curl --resolve …internal` calls to localhost went to the egress proxy and were reset. That was my setup, not the PR. With `.internal` added, I reran `es/app` on base and then head. Only the 2 known failures remain, on both sides. The combined lists below use that rerun. Its comparison is in `esapp-compare.txt`.
- **Carried, not rechecked:** O22-3 (a `scripts` PTY subtest flake), plus O17-2, O17-4 and O17-5. The delta does not touch them. O17-1's cap headroom is rechecked in O24-3.

## Validation assessment

- **Full `go test -count=1 -timeout 40m -json ./...`** as `ci`, on clean clones of `fbfd100` (02:12:34-02:20:40Z) and then `cb8260c` (02:20:40-02:27:52Z), one after the other with nothing else running (`suite-compare.txt`):
  - 49 packages on both sides: 28 pass, 18 skip, 3 fail on both. No package verdict differs.
  - Top-level tests: 1,941 on base and 1,945 on head. No verdict changes. The only differences are the four tests in the PR's new file, which pass on head: `TestClaimLedgerCitesThisRepositoryBySection`, `TestClaimLedgerLineGuardFindsEachCitation`, `TestGithubHeadingAnchorsFollowGithubRules` and `TestMarkdownHeadingLinksResolve`. In the root package, 181 pass on base and 185 on head, with none failing.
  - Subtests: 8,354 on both sides, with no verdict changes. The 43 names that appear on only one side are the randomized subtests of `TestRedTeamPR12CombinedSIGKILLAtRandomInstants`, `TestRedTeamPR12HeadTwoSIGKILLsThenASurvivor` and `TestRedTeamPR12HeadLiveProcessesRaceForOneClaim`.
- **`es/app` rerun** with the corrected proxy setting (02:28:25-02:33:12Z, base then head; O24-5): 222 top-level tests on each side, no verdict changes, and the same 2 failures.
- **Failing top-level tests, the same 14 on base and head** (`failing-tests-base.txt` = `failing-tests-head.txt`, byte-identical to audit 22's list):
  - es/admission/internal/reliablesubmit: `TestOperationalHandoffSchema4BinaryRefusesSchema5`, `TestSQLiteV3OldBinaryRefusesWithoutMutation`, `TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation`
  - es/app: `TestLinuxSetupBootstrapFinishesWithItsSavedSecret`, `TestNomadACLToolRetriesABootstrapThatNeverTookEffect`
  - scripts: `TestRemoteAlphaESServiceTLSStatusFailureWitnessBootstrapOwnedTerminal`, `TestRemoteAlphaESServiceTLSStatusRootLoadedStageCustody`, `TestRemoteAlphaESServiceTLSStatusStageFIFOSubstitution`, `TestRemoteAlphaOperatorRecoverySessionESTLSStatusRemoteWrapperTrap`, `TestRemoteAlphaOperatorRecoverySessionESTLSStatusStageFIFORefusal`, `TestRemoteAlphaP0tGrammarDiagnosticBootstrapLifecycleComposition`, `TestRemoteAlphaP0tGrammarDiagnosticPriorReaderCloseSuppression`, `TestRemoteAlphaP0tGrammarDiagnosticV2VersionedBootstrap`, `TestRemoteAlphaUpgradeESCheckRefusesWhatItWasNotWrittenFor`
- **Ordering:** the mutant runs and the trial merge started only after both suite runs and the `es/app` rerun had finished.
- **CI on `4bc228c`** (GitHub API): "build, vet and test" (job 140251063387, run 45920877811) **success**, 01:08:52-02:06:02Z; "test on macOS" (job 140251063563, run 45920877828) **success**, 01:08:52-01:41:10Z. Both runs' `head_sha` is `4bc228c`.
- **CI on `cb8260c`:** "build, vet and test" (job 140268724260, run 45926440441) **success**, 02:07:13-02:59:49Z; the log ends with "tests as root passed: 9 of execution-substrate/scripts". "test on macOS" (job 140268723239, run 45926440281) **success**, 02:07:13-02:36:34Z. Both runs' `head_sha` is `cb8260c`, and they are `pull_request` runs. Because `fbfd100` is an ancestor of `cb8260c`, the merge commit they test has `cb8260c`'s tree.
- **Not run:** the deletion sweep and the range mapping, whose bytes are unchanged since audit 17, and trial merges with open PRs other than #68, which are outside this scope.

## Sensitive-material handling

No secrets, env files, keys or databases were read or copied. The evidence holds repository paths, hashes, test names, code excerpts, and the container's local proxy port and `no_proxy` list in `scripts/env.sh`.

## Confidence

- **Provenance: high.** Both manifests reproduced, stable and equal to the expected ones. The merge equals git's own merge tree. Opening equals closing. The PR head did not move.
- **Validation: high.** Full suite on both sides of the exact bytes, compared by name. 47 code mutants and 4 ledger edits on `cb8260c`, plus 4 probes. A trial merge with the new `trunk_dev`.
- **Implementation: high.** The repair is the probed fix byte for byte, plus accurate comment and message changes.

## Evidence

Folder `24-audit-evidence/` (hashes in its `SHA256SUMS`): `opening-manifest.json`, `closing-manifest.json`, `manifest-4bc228c-on-39e19de.json`, `fix-vs-head.diff`, `merge-check.txt`, `mutants24.jsonl`, `suite-compare.txt`, `esapp-compare.txt`, `failing-tests-base.txt`, `failing-tests-head.txt`, `trial-68.txt`, and `scripts/` (`mutants24.py`, `compare24.py`, `env.sh`, `mkclone.sh`, `run_suite.sh`, `asci.sh`, `both_suites.sh`, `esapp_both.sh`). The `env.sh` saved there is the corrected one, with `.internal` in `no_proxy`. The first full-suite run used the same file without it (O24-5).

## Closing provenance

At 02:56:04Z I reran the §5.3 sequence in the provenance clone. The recipe hash checked again (project copy and the copy I ran). The pushed tip and `refs/pull/69/head` are still `cb8260c`. I checked out the tip, confirmed a clean status, reset to `fbfd100`, pinned the upstream to `origin/trunk_dev`, and ran v2 twice. The two runs are byte-identical and equal the opening manifest byte for byte (`d0ebda33…c7c8`, `closing-manifest.json`). `trunk_dev` was then `a5861b7` (O24-3), which the manifest does not depend on, because it is taken against the audited base `fbfd100`. Audit-created artifacts: scratch clones under `/opt/audit/trees`, run outputs under `/opt/audit/runs`, and one local trial commit object in the provenance clone, none of them pushed. After the closing run, the provenance clone was returned to the topic branch at `cb8260c` with a clean status.

## Effect status

Repair, commit, push, PR change, GitHub comment and merge: not performed. One local, never-pushed trial merge commit (`9d0ae9f`) exists only in this container's audit clone.

**Final verdict: ACCEPT** for `cb8260c`
