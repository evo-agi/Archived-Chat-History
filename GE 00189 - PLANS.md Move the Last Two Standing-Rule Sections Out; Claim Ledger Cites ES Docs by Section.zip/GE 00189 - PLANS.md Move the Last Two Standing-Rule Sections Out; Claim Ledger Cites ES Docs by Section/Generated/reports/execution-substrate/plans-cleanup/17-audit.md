# Independent re-audit 17: ES PR #69 at 4f4f597 (repair of audit 14)

**Verdict: BLOCK, on one low finding.** The repair fixes everything audit 14 asked for. A14-1 is closed: the five leftover ES line ranges are section links now, each mapped correctly at `6300b95`. A14-2 is closed: the ledger now describes the mapping rule it actually used, and its counts and descriptions are correct. O-3 is fixed. The PR body is corrected too. The two section moves into `.docs/standing_rules/` are still byte for byte. The full test suite gives the same results by name on base and head, apart from three new tests that pass. CI is green on `4f4f597`.

What blocks:

- **R17-1 (low, test gap, patch defect):** two parts of the new guard are not pinned by its self-test. (a) The self-test for baseline-table cells tests a copy of the condition, not the condition the check uses. Putting the check back to its pre-repair form, together with a `` `229` `` cell in the ledger, passes every test. (b) No self-test line has a line citation in a later `ES` citation on the same line. A guard that checks only the first `ES` citation per line passes every test, even with `` `350-424` `` added to row C5's second citation. The production code is correct today; what is missing is the protection against a later edit weakening it. The fix is small: one shared function for the cell rule, and one more line the self-test must refuse.

Effect status: read-only audit. Nothing was committed, pushed, opened, commented on or merged.

## Target

| Item | Value |
|---|---|
| Repository | evo-agi/Execution-Substrate |
| PR | #69, branch `claude/project-thread-hfr05z` |
| Base | `923e9c3366775664c8a85f19273e3dd4fc04eb22` (= `origin/trunk_dev`, checked again with `git ls-remote` at the end) |
| Head | `4f4f5979f183b46ca8dc80a7f85ec8527e7a2024` (pushed branch tip = `refs/pull/69/head`, checked again at the end) |
| Head tree | `e06be63b2462cd4f93b5c98c155aa1b2d6e395c5` |
| Commits | `4d4ae99` (sections move), `a0c844e` (ledger by section, heading-link guard), `4f4f597` (repair: ledger and `heading_links_docs_contract_test.go` only) |
| Recipe | `governed_execution_audit_patch_manifest_v2.py`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified before the opening and closing runs) |
| Canonical manifest | SHA-256 `e94bda8571680d276d14a48d64255ade8e4803caa6b4e64ec103b54111e24381`, 13 files |
| Textual diff | SHA-256 `1acd80c26cde0cdc7e9135aa69624f75f3f7c5c434f7c1290683f7ca9acec3e9` |
| Implementation report | `15-report.md` (SHA-256 `5f5d03365329a0cdead9ad7dac48f4902480fab511baa181feaeb048557af5ae`), expected manifest `15-expected-manifest.json` |
| Prior audit | `14-audit.md` (SHA-256 `03123e141fda9bd9236fde6c296581b0208cdabfaafcdb2cc18c92e237432589`), by a different thread |

## Audit posture

Fresh, read-only parent thread that had not audited this PR before (protocol §14). No subagents. Test runs used clean clones under `/opt/audit` as an unprivileged user `ci` (uid 1500, gid 1600), started with `runuser -u ci -- env -i`, `umask 022`, go1.26.5 linux/amd64, and HUP/INT/QUIT/TERM/PIPE reset to default. Host packages acl, uuid-runtime, openssh-client, iproute2 and the en_US.UTF-8 locale were installed first. The clone used for the manifest was not modified. I reused no audit-14 script except `anchors_indep.py` (read before running); the range mapping, move check, mutants and comparison are my own (`scripts/`).

## Provenance reproduction

Commands from provenance §5.3, in a fresh clone: fetch `trunk_dev` and the topic branch; check the pushed tip is `4f4f597` and `923e9c3` is its ancestor; `git checkout -f -B claude/project-thread-hfr05z 4f4f597`; clean status; `git reset --mixed 923e9c3`; upstream pinned to `origin/trunk_dev`; v2 run twice into a fresh `0700` directory.

- The two runs are byte-identical, and equal `15-expected-manifest.json` byte for byte (`cmp`). Manifest `e94bda85…4381`, 13 files. No mode differences.
- Against audit 14's opening manifest (`cc777004…d43a`), the path set, `head`, `branch`, `upstream` and `recipe_id` are equal; only the records of `.docs/commercialization/claim-ledger.md` and `heading_links_docs_contract_test.go` changed. `git diff --stat a0c844e 4f4f597` names the same two files.
- The closing run, after all audit work, equals the opening run byte for byte.

## Coverage

Read: audit 14 and its evidence, report 15, the PR body, the whole repair diff, the guard code and the helpers it calls (`numericCell`, `lineRange` in `plans_docs_contract_test.go:487-488`), the base, `a0c844e` and head ledgers, the cited docs at the ledger's origin commit `6300b95`, and the rest of the PR diff where the checks below needed it. Not inspected: CP and IM line ranges (out of scope; CP is not attached).

### 1. A14-1 is fixed

Independent mapping (`map_ranges.py`, output `map_ranges.out`): it takes every ES line range in the base ledger, finds the head row's links into the same file, resolves each linked heading at `6300b95`, and checks that the linked sections cover the range and that no linked section misses it.

- The base ledger has **53** ES ranges: 48 primary and 5 continuation spans, in 24 distinct ranges. Every range is covered by its head links, and every link overlaps a range. No narrowing and no unrelated link. The only uncovered line is line 1 (the file's H1 title) for ranges starting at line 1, which is correct.
- The five repaired rows:

| Row | Range at `6300b95` | Head links | Coverage (my check) |
|---|---|---|---|
| C7 | contracts.md `384-535` | § 7. Status contract | wider by §7's "### Reopened seams" (536-542); counted among the nine |
| C11 | capability_probing.md `51-82` | § Placement Rules, § Failure Behavior | exact |
| D1 | runtime_identity_handoff.md `63-127` | § 3, § 4, § 5 | exact |
| D2 | runtime_identity_handoff.md `160-228` | § 8, § 9, § 10 | exact |
| H3 | runtime_identity_handoff.md `97-127` | § 5. Ownership and non-ownership | exact |

- Every head anchor names a heading of the head file (my script, and the heading-link check below). The one renamed heading ("1. Purpose and authority" at `6300b95`, "1. Purpose and scope" now) is matched by number.
- Outside citations, nothing in the claim rows changed. A normalized diff of base and head ledgers (citations folded into one token) differs only in the new explanation paragraph and the baseline table.
- The ledger commit after `6300b95` (`5457f9b`, 14 minutes later) changed only five ledger lines and no cited doc, so mapping at `6300b95` is right.
- **The guard now refuses the A14-1 shape.** A probe test (`probe_test.go.txt`, a temporary file in a scratch clone) runs `claimLedgerLineCitations` over three ledgers: **53** findings on `923e9c3`, **5** on `a0c844e`, **0** on `4f4f597`, as report 15 says. Mutants K1 (audit 14's L3), K6-K10 and K12 are killed (table in section 4).
- PR body: it now says "All 53 ES line ranges … 48 that followed `ES ` directly, and 5 more" (A14-1 correction 3).

### 2. A14-2 is fixed

The ledger now says each range "is linked to the whole sections that contain it", that nine distinct ranges stopped inside a section, and that "a claim that cites one of them rests only on the part the range covered". The first two sentences are pinned.

My mapping agrees with every count and description:

- **Five** distinct ranges end just before a "### Reopened seams" subsection of contracts.md: `77-278` and `160-278` (section 5), `287-375` (section 6), `384-535` (section 7), `689-738` (section 10).
- **Three** leave out a closing paragraph or last bullet: contracts.md `1-35` (line 37 of section 3), supported_local_cp_consumer_runbook.md `315-441` (line 443 of section 8), runtime_identity_handoff.md `27-58` (lines 59-61, the last bullet of section 2).
- **One**, boundaries.md `350-424`: at `6300b95`, section 8 has the bold parts **Purpose** (269), **Current ownership** (278), **Explicit non-ownership** (313), **Current consumers / collaborators** (348), **Boundary pressure points** (357), **Temporary compatibility edges** (407) and **Reopened seams** (426). The range runs from 350 to 424. So the ledger's new description is right, and audit 14's wording ("consumers, invariants and compatibility-edge bullets") was loose, as report 15 says.
- My script finds one more range wider than its link only by the heading line: mvp.md `104-169` starts at "### Execution Substrate" under "## Surface classification" (102) and runs to the end of that section. The link adds only line 102, the heading itself. I agree it is not a widening, so "nine" stands.
- Not narrowing these links is a reasonable choice. The finer headings in contracts.md ("Purpose", "Request contract", …) repeat in every section, so they get GitHub's `-1`, `-2` suffixes. Those shift when a section is added above, and a shifted anchor can still resolve, to the wrong place. I checked that the repeated `###` headings exist as described.
- PR body: the "no citation got wider or narrower" sentence is gone; it now names the nine and the reason for not narrowing.

### 3. O-3 is fixed; the ES baseline table

The baseline check now refuses a cell that `numericCell` matches, that has a digit range (`lineRange`), or that holds a line code span. Mutants K2 (`` `229` ``, audit 14's L5) and K3 (``Lines `1-229` ``, L6) are killed. But see R17-1(a): the self-test does not exercise this condition.

The table itself is unchanged since `a0c844e`. Spot checks at `6300b95`: mvp.md is 229 lines and the runbook 476, so "The whole file" is right for both (the runbook's gaps at 56, 116, 236 and 282 are blank lines).

### 4. Guard mutants (`mutants.py`, `mutants2.py`; `mutants.jsonl`, `mutants2.jsonl`)

Each mutant ran in a clean clone of `4f4f597`, with everything staged (these tests list files through git), against `TestClaimLedgerCitesThisRepositoryBySection`, `TestMarkdownHeadingLinksResolve`, `TestGithubHeadingAnchorsFollowGithubRules` and `TestMarkdownRelativeLinksResolve`. The clone was reset after each one, and a clean rerun at the end passes.

| Mutant | Result |
|---|---|
| K1 `` , `70-89` `` after an ES link (audit 14 L3) | killed |
| K2 baseline cell `` `229` `` (L5) / K3 ``Lines `1-229` `` (L6) | killed / killed |
| K4 restore "each range covered whole sections" / K5 drop "rests only on the part the range covered" | killed / killed |
| K6 en dash range / K7 `` `L70` `` / K8 `` `70` `` after an ES link | killed |
| K9 `` `.docs/mvp.md:70-89` `` after a link / K10 range after a second link joined with "and" | killed / killed |
| K11 relative link with a `#L40-L68` anchor | killed by `TestMarkdownHeadingLinksResolve` |
| K12 row C11 put back to its base form / K13 "53" changed to "48" / K14 "Nine" changed to "Ten" | killed |
| G1 drop the CP/IM terminator / G2 drop `;` / G3 drop the cell-end terminator | killed (self-test) |
| G4 drop the bare-range alternative / G5 drop `L?` / G6 drop `#L` | killed (self-test) |
| **G7** baseline cell check back to `numericCell && lineRange` (the pre-repair form) | **survives**; R3 = G7 plus a `` `229` `` cell: **survives** |
| **G9** check only the first ES citation per line (`FindAllString(line, 1)`) | **survives**; R2 = G9 plus `` , `350-424` `` after row C5's second ES citation: **survives** (R1, the same ledger edit with the real guard, is killed) |
| G8 drop `claimLedgerLineSpan` from the cell check | survives alone; with ``Lines `1-229` `` or `` `L12` `` cells it is killed by the other two terms (R4, R5). Mostly redundant, so not part of the finding |

Outside the guard's stated limits, so recorded but not findings: X1 `` `lines 70-89` ``, X2 `` `70-89, 90-95` ``, X3 a range in plain text, X4 a `;` in prose before the range, X5 an absolute GitHub URL with `#L40-L68`, X6 an unprefixed `` `.docs/mvp.md:40-68` ``, X7 a baseline cell "line 229", and X8 dropping one mapped link (D2 losing section 10) all pass. X9 shows the check fails closed: a baseline cell "Sections 1-4" is refused, with a message that says "by line".

### 5. The moves and the rest of the diff

`move_check.py` (my own; output `move_check.out`) compares blobs at `923e9c3` and `4f4f597`:

- "Current paired-root custody and acceptance scope": the base `PLANS.md` text from that heading to the ADR paragraph equals the tail of `execution_admission_and_custody.md` (12,347 bytes plus the base's extra trailing newline). "Remote Alpha access contract v1 — Tranche A": the base text from that heading to the end of `PLANS.md` equals the tail of `remote_alpha_operator_routes.md` (6,481 bytes). Each heading occurs once in its rule file and no longer in `PLANS.md`.
- In both rule files, everything from the first `###` up to the appended section is unchanged. Only the header paragraph gained the "moved at `923e9c3`" sentence (and, for the route file, its scope).
- The four ADR paragraphs (3,255 bytes without trailing blank lines) appear verbatim in head `PLANS.md`. With the moved text and the ADR block taken out, the only other `PLANS.md` changes are the opening sentence, the two pointer sections and blank lines. 145,850 → 127,250 bytes.
- These 11 files have the same manifest records as at `a0c844e`, which audit 14 reviewed in full (repointed tests, deletion sweep, layout and cap mutants). I did not repeat the deletion sweep: those bytes did not change.
- Heading links: `anchors_indep.py` (audit 14's script, read first) finds **109** heading links on head and 0 broken (99 on `a0c844e`). This matches the PR body's 109 and the test's floor of 90.
- `gofmt -l` on the four changed test files: none listed.

### 6. Open PRs and cap headroom

`git merge-tree` merges `4f4f597` cleanly with each open PR head: #63 `59f1f56`, #66 `84da2da`, #68 `1e3ec7c`, #70 `a0e86ea`, #71 `26cbd65`, #72 `a3710c0`, #73 `6505f62` (`trials-heads.txt`). The heading-link check finds 109 links and 0 broken on every trial merge. The root package (plus `internal/testutil` for #68) passes on trial merges with #63, #66, #68, #70, #71 and #73 (`trials.jsonl`). So the ten new links into `runtime_identity_handoff.md`, `capability_probing.md` and `contracts.md` survive #71's and #73's edits to those files.

## Findings

### R17-1: The new guard's self-test does not pin the cell rule or "every ES citation in a line"

- Type / severity: test gap, patch defect (both parts are new in `4f4f597`). **Low.**
- Contract: report 15 and the PR body say the guard refuses a line citation "anywhere in an `ES` citation" and that the baseline table refuses a single line number or a ``Lines `a-b` `` cell, with self-tests showing it.
- Evidence (`heading_links_docs_contract_test.go` at `4f4f597`):
  - (a) The check at line 186 is `numericCell.MatchString(cell) || lineRange.MatchString(cell) || claimLedgerLineSpan.MatchString(cell)`. The self-test at lines 228-232 writes the same expression out again instead of calling the check. Mutant G7 puts line 186 back to the pre-repair `numericCell && lineRange` and passes every test. R3 (G7 plus a `` `229` `` cell in the ledger) also passes. So the O-3 fix can be undone without any test noticing.
  - (b) `claimLedgerLineCitations` (lines 162-168) loops over `claimLedgerESCitation.FindAllString(line, -1)`. No must-refuse line in the self-test (lines 202-214) has a line citation in a later `ES` citation of the same line. Mutant G9 (`FindAllString(line, 1)`) passes every test. R2 (G9 plus `` , `350-424` `` after row C5's second ES citation, the `boundaries.md` § 8 link) passes too, while the real guard refuses that edit (R1). Rows with two or more `ES` citations are common in the ledger (B1, C5, C7, C10, H2, …).
- Impact: none on today's ledger; the production code is right. But these self-tests exist to stop a later edit from weakening the guard, and for these two rules they would not. That is the same class of gap audit 14 recorded for L3, L5 and L6.
- Required correction:
  1. Move the cell rule into one function (for example `claimLedgerBaselineCellCitesLines(cell string) bool`). Call it from both the check and the self-test, so G7 and G8 get killed.
  2. Add a must-refuse self-test line where only a later `ES` citation cites by line, for example ``ES [`x.md` § A](x.md#a); ES [`y.md` § B](y.md#b), `51-82` ``, so G9 gets killed.
- Uncertainty: none; both mutants and both combined runs are in `mutants.jsonl` and `mutants2.jsonl`.

### Observations (not blocking)

- **O17-1, cap headroom (audit 14's O-4, still open).** After #69, `PLANS.md` is 127,250 bytes against the 132,000 cap. Trial merges: +#70 128,280; +#71 130,525. With #68, #70, #73 (which includes #71), #63 and #66 together: **131,687 bytes, 313 under the cap**. Adding #72 as well (it conflicts with #73, since both stack on #71) would leave about 260. Step 4 (to about 72 KB) resolves this; until then, merge order matters.
- **O17-2, a cross-PR break that is not in #69: #68 and #70 together fail `TestServiceLayout`.** #70's `scripts/remote_alpha_user_identity_test.go` imports `ags/api`, `ags/publish`, `es/admission` and `es/api`, which #68's layout rule refuses outside a contract, app or config package. A trial merge of #68 and #70 alone on trunk (`3893afc`) fails the same way. Whichever of the two lands second needs a change. This is for the coordinator's merge planning, not a #69 finding.
- **O17-3, the guard's limits.** X1-X7 show forms the guard does not see: words or two ranges inside one code span, plain-text ranges, a `;` in prose before a range, absolute GitHub `#L` URLs, unprefixed citations, and a "line 229" baseline cell. They are outside the rule as the PR states it (code spans and whole cells), and a vocabulary guard cannot be complete. The PR body's "No line number or range in the ES baseline table" is broader than the code; the code's own comment is accurate.
- **O17-4, the mapping is not pinned link by link** (X8). Dropping one mapped link passes every test, so the ledger's sentence "each range is linked to the whole sections that contain it" is held only by review. Pinning 53 mappings would be heavy for a commercialization doc, so I note it rather than ask for it.
- **O17-5, carried from audit 14.** O-2 (ordinary `PLANS.md` mentions that reach moved text only through pointers) is deferred to step 4, as report 15 says. Not re-judged here.

## Validation assessment

Full `go test -count=1 -timeout 40m -json ./...` on clean clones of `923e9c3` (23:09-23:16Z) and `4f4f597` (23:16-23:23Z), as `ci`:

- 49 packages on both sides; 28 pass on both. Top-level tests: 1,934 base, 1,937 head. Root package: 176 pass on base, 179 on head, none failing.
- The only top-level differences are the three new tests, which pass: `TestClaimLedgerCitesThisRepositoryBySection`, `TestGithubHeadingAnchorsFollowGithubRules`, `TestMarkdownHeadingLinksResolve`. No verdict changes. The subtest names that differ are the randomized names of `TestRedTeamPR12HeadTwoSIGKILLsThenASurvivor`, `TestRedTeamPR12CombinedSIGKILLAtRandomInstants` and `TestRedTeamPR12HeadLiveProcessesRaceForOneClaim` (same counts on both sides, all passing).
- The same 14 top-level tests fail on base and head, by name (`failing-tests-base.txt` and `failing-tests-head.txt` are identical). They are the same 14 names audit 14 listed, so they come from the container, not from this PR:
  - es/admission/internal/reliablesubmit: `TestOperationalHandoffSchema4BinaryRefusesSchema5`, `TestSQLiteV3OldBinaryRefusesWithoutMutation`, `TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation`
  - es/app: `TestLinuxSetupBootstrapFinishesWithItsSavedSecret`, `TestNomadACLToolRetriesABootstrapThatNeverTookEffect`
  - scripts: `TestRemoteAlphaESServiceTLSStatusFailureWitnessBootstrapOwnedTerminal`, `TestRemoteAlphaESServiceTLSStatusRootLoadedStageCustody`, `TestRemoteAlphaESServiceTLSStatusStageFIFOSubstitution`, `TestRemoteAlphaOperatorRecoverySessionESTLSStatusRemoteWrapperTrap`, `TestRemoteAlphaOperatorRecoverySessionESTLSStatusStageFIFORefusal`, `TestRemoteAlphaP0tGrammarDiagnosticBootstrapLifecycleComposition`, `TestRemoteAlphaP0tGrammarDiagnosticPriorReaderCloseSuppression`, `TestRemoteAlphaP0tGrammarDiagnosticV2VersionedBootstrap`, `TestRemoteAlphaUpgradeESCheckRefusesWhatItWasNotWrittenFor`
- Limitation: the mutant runs (root package only, `nice 19`) overlapped the last minute of the base run and the first minute of the head run. Both sides came out identical by name, so the overlap changed nothing.
- CI on `4f4f597` (checked through the GitHub API): "build, vet and test" (run 45903543065, job 140194895675, `head_sha` 4f4f597, success, 22:15-23:02Z) and "test on macOS" (run 45903543063, job 140194794360, `head_sha` 4f4f597, success, 22:22-22:49Z). Both required checks are green on the audited head.
- Not run: `go vet` locally (CI's Vet and "Vet for macOS" steps passed on this head), and the deletion sweep (those bytes did not change since audit 14).

## Sensitive-material handling

No secrets, env files, keys or databases were read or copied. The evidence holds only repository paths, hashes, test names, doc excerpts and a local proxy port in `scripts/env.sh`.

## Confidence

- Provenance: high. The manifest was reproduced, is stable, equals the expected manifest, and opening equals closing. Remote heads were unchanged at the end.
- Validation: high. Full suite on both sides of the exact bytes, compared by name; 32 guard mutants plus 5 combined runs; a direct probe of the guard; trial merges with every open PR.
- Implementation: high for the A14-1, A14-2 and O-3 repairs and the moves. Medium-high for the guard's future protection, because of R17-1.

## Evidence

Folder `17-audit-evidence/` (hashes in `17-audit-evidence/SHA256SUMS`): `opening-manifest.json`, `closing-manifest.json`, `map_ranges.out`, `move_check.out`, `probe.out`, `mutants.jsonl`, `mutants2.jsonl`, `suite-compare.txt`, `failing-tests-base.txt`, `failing-tests-head.txt`, `trials.jsonl`, `trials-heads.txt`, and `scripts/` (`map_ranges.py`, `move_check.py`, `mutants.py`, `mutants2.py`, `compare.py`, `probe_test.go.txt`, `trials.sh`, `env.sh`, `asci.sh`, `run_suite.sh`).

## Effect status

Repair, commit, push, PR change, GitHub comment and merge: not performed.

**Final verdict: BLOCK** (R17-1, low)
