Uh... Are those two threads blocking? If not, we can start more.
