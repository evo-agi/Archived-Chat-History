I opened [PR #69](https://github.com/evo-agi/Execution-Substrate/pull/69). It finishes the PLANS.md cleanup in Execution-Substrate. It's docs and tests only, so it can merge after a fresh audit and the gate, without you.

- **PLANS.md is now 127 KB, down from 146 KB.** The last two standing-rule sections moved word for word into `.docs/standing_rules/`. Every test that read them now reads them in their new place, and the size cap went down to 132,000 bytes.
- **The claim ledger now links to sections instead of line numbers.** That covers all 48 references into this repository. A new test checks that every Markdown heading link in the repo resolves (99 links today).
- **Tests:** on the full suite, base and head give the same result for every test, apart from the three new ones, which pass. It merges cleanly with the layout PR #68.
- **Other repos:** the only one with the same problem is Governed-Execution-Coordinator. It has no PLANS.md, but its AGENTS.md is 88 KB of status entries. Bridge-Core's PLANS.md is 1.6 KB, and the rest have none.

PLANS.md still holds about 56 KB of standing rules. I put a card below on whether to move those too.

STATUS: WAITING on a fresh audit of #69
