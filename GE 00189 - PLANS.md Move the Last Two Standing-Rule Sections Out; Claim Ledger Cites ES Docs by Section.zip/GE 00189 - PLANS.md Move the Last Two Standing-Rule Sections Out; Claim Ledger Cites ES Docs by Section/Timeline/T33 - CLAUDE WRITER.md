R17-1 is fixed on [PR #69](https://github.com/evo-agi/Execution-Substrate/pull/69). The new head is `8246cb2`, and it's ready for its fresh re-check.

The self-test now calls the same baseline-cell rule the check uses, instead of a copy. It also refuses a range that appears only in the second ES citation on a line. All six guard mutants now fail it, including the auditor's G7, G8 and G9.

I also corrected the PR body's description of the baseline-cell rule (O17-3). CI is running on the new head.

The new manifest is `be88a750…f4e5`, in [18-report.md](/mnt/project-files/reports/execution-substrate/plans-cleanup/18-report.md). Step 4 is rebased onto the new head.

STATUS: #69 waiting on re-check 18 and CI; step 4 prepared locally.
