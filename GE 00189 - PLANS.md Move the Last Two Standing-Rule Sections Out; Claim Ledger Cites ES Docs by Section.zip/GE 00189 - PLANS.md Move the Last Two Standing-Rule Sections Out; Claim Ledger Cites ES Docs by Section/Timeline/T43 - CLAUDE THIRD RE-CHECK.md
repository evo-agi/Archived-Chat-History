**BLOCK (low) on PR #69 at `1160f28`.** The repair does close R19-1. But two other ways of weakening the guard still pass every test. The fix is two lines in the test, and I've already tried them.

**What's good**
- Provenance holds. The manifest `1da4f999…0817` reproduced byte for byte, and only the guard test changed since `e83f2ba`.
- Every mutant I built that drops or misorders a line's ES citations now fails the self-test. That includes R19-1's own mutant, which kept only the last citation.
- On the four ledgers the PR has carried, the new check finds exactly what the old one found: 53 ranges and 6 table cells on the original ledger.
- The full suite gives the same results by name on base and head. The same 14 tests fail on both, and the 4 new tests pass.
- CI is green on Linux and macOS. The PR merges cleanly with each of the 6 open PRs.

**What blocks**
- **R22-1 (low):** the code says it checks every line and every table cell, but the test can't tell if it doesn't.
  - If the check skipped every line that isn't a table row, all tests would still pass.
  - The same goes for skipping the first column of the source table.
  - Under each of those weakenings, a ledger edit that today's guard refuses gets through.
  - The fix adds one prose line and one bad first-column cell to the test's sample ledger. With it, 44 of my 46 mutants fail. The two that survive are outside what the guard claims to do (an indented table row, and the real-ledger test ignoring the result). The fix is in `proposed-fix-R22-1.diff` in the evidence folder.
- **R22-2 (low nit):** two wrong statements in the test file. A comment names the wrong test, and a failure message says "eight" where the test expects nine problems.

I tried to make this the last round: the report lists every position the guard walks over (line kind, line position, row, cell, citation, span) and shows the fix covers all of them. Two side notes: the report is number 22 because the writer's bundle had already taken 21, and `PLANS.md` headroom is now 282 bytes with the largest combination of open PRs.

Report: [22-audit.md](/mnt/project-files/reports/execution-substrate/plans-cleanup/22-audit.md), SHA-256 `438556c2…13d6`. Evidence is in `22-audit-evidence/` with checksums. Nothing was pushed or posted on GitHub.

STATUS: READY (audit delivered; the repair goes back to the writer thread)
