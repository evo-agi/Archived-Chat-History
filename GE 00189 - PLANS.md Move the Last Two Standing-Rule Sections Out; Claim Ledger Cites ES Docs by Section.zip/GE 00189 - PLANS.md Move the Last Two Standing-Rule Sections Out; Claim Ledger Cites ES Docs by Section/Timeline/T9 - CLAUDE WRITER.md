Asked the project to choose an option

Shrink PLANS.md further, from 127 KB to about 71 KB?

1. Yes, move the rest (step 4) (recommended): I move about 56 KB of slice rules, Workstream A-F records and the Milestone 1 matrix into new standing-rule files, after we agree their names.
2. Stop at 127 KB: PLANS.md stays as #69 leaves it, and every agent keeps reading the 127 KB before a change.
3. Later, with the Coordinator cleanup: I note it in the backlog and pair it with the 88 KB Coordinator AGENTS.md when Coordinator work resumes.

Why recommended: Agents read PLANS.md before every change, so cutting it almost in half saves time on every task. The only decision for you is what to name the new files.
