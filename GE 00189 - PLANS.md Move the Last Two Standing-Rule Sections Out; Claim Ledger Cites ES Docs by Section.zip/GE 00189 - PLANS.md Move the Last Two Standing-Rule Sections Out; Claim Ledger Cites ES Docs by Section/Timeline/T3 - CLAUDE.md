Neither is blocking, so I'm starting the PLANS.md cleanup, which your backlog marked first after the reset.
