Two threads are working right now, and nothing needs you.
- [Lock Nomad so only ES can submit](#cmsg_01Un4xQgjBAczV8DABQvcLrx7qaBgesL513RdQXm7D49pW) is fixing small findings in both gossip encryption PRs. The box upgrade ([PR 67](https://github.com/evo-agi/Execution-Substrate/pull/67)) failed its fresh audit, and the setup ([PR 66](https://github.com/evo-agi/Execution-Substrate/pull/66)) failed its red-team, each on two Low issues. Fresh checks come after the fixes.
- [Make ES service layouts consistent](#cmsg_01Un4xQgjBAczV8DABQvcLrx2nwvgVojCHGFcJTWMDqCvF) is building the `egs/contract` and `ars/contract` PR.

STATUS: WAITING (on those two threads)
