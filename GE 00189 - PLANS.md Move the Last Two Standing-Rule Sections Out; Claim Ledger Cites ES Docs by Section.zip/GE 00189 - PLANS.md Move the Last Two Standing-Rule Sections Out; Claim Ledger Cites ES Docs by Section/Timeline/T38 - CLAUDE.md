Update while you were away: one design decision needs you, everything else is moving.

**Needs you**
- Network grants ([PR 73](https://github.com/evo-agi/Execution-Substrate/pull/73)) grant network to a *publisher*, but any caller ES admits can then run that publisher's artifact with its own arguments, environment and mounts. Once Claude becomes an ES user ([PR 70](https://github.com/evo-agi/Execution-Substrate/pull/70)), it would effectively inherit your network grants. Today it's worse: any caller can publish its own networked artifact. Options:
  - **Key grants on the caller too** (my recommendation): a user like Claude gets network only if a grant names it. It's a design change, so PR 70 waits for it.
  - **Accept and document**: PR 70 ships sooner, but Claude as a user can reach the network and the Codex credential path like you can.

**Done**
- [PR 71](https://github.com/evo-agi/Execution-Substrate/pull/71), the workload identity design docs, merged as `39e19de`.
- Chat archives GE 00171 to GE 00185 are public.

**Still working**
- Audit or red-team fixes are underway on PRs 66, 67, 68, 69, 70, 72 and 73. The audits keep finding real issues (one High on 73: CI fails), and none needs you.

STATUS: NEEDS DAVID (caller-keyed grants, or accept and document)
