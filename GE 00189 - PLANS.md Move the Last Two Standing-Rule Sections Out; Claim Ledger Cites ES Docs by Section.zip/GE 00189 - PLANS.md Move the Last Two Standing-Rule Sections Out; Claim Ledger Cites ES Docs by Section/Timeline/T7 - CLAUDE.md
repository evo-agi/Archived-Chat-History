A small correction to the backlog: most of the PLANS.md cleanup already happened in PRs 55 and 56 on Monday. They cut the file from about 371 KB to 146 KB and added a size guard. The thread is finishing what's left and will then check the other repos. I've updated the backlog to match.

STATUS: WORKING (four threads; next update when a PR opens)
