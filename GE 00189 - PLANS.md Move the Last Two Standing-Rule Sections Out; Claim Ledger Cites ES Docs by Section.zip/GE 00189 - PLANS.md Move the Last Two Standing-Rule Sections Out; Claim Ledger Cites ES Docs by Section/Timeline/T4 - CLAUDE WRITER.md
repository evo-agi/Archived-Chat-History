I'm measuring ES PLANS.md on trunk_dev and finding every test and script that reads it.
