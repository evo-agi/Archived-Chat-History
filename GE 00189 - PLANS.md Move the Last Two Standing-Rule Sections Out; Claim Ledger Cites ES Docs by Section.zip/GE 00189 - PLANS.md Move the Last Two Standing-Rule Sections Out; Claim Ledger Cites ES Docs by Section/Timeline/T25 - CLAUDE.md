The PLANS.md cleanup PR fixed its audit findings too, so it also gets a fresh re-check.
