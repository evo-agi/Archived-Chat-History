R19-1 is fixed on [PR #69](https://github.com/evo-agi/Execution-Substrate/pull/69), and I closed the whole class at once. The new head is `1160f28`. The delta to check is `git diff e83f2ba 1160f28`, which touches only the guard's test file.

The guard is now one check over the whole ledger, and its self-test states the exact result for every case. That covers a bad range in the first, a middle and the last of three citations, repeated ranges, and two ranges in one citation.

~~All 32 mutants I ran now fail~~ [Edit: 31 of the 32 mutants I ran now fail], including first-only, last-only, dedupe and early break. The one exception can't be caught on a clean ledger: the test simply ignoring the check's result.

Details and the new manifest `1da4f999…0817` are in [20-report.md](/mnt/project-files/reports/execution-substrate/plans-cleanup/20-report.md). CI is running.

STATUS: #69 waiting on the scoped re-check and CI.
