#69 is repaired for audit 22 and ready for the scoped re-check. New head `cb8260c`.

- `4bc228c` applies the auditor's fix for R22-1 as given and fixes both statements in R22-2. CI passed on it. Of 47 code mutants, 45 now fail, P4, P6 and B4 included. The two survivors are the ones the audit put outside the claim (B10 and X1).
- `trunk_dev` then moved (#72). I merged it in with no conflicts, and the PR's own diff is unchanged. CI is running on `cb8260c`.

Details and manifests are in [23-report.md](/mnt/project-files/reports/execution-substrate/plans-cleanup/23-report.md).

STATUS: #69 waiting on the scoped re-check and CI at `cb8260c`.
