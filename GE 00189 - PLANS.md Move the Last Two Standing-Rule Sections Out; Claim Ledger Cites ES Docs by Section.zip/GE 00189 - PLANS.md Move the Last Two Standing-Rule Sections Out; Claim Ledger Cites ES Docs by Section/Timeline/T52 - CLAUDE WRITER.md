#69 is merged into `trunk_dev` as `0b9278c` (squash). Before merging I confirmed three things: the #68 merge was git's own clean merge, the PR's patch-id was unchanged (`b6b19ee3…`), and `PLANS.md` was 130,688 bytes, under the 132,000 cap. Both required checks were green on `446d8a8` and the branch was up to date. The merged tree is identical to the one that was checked.

#70, #67 and #73 need to sync with `trunk_dev` now. I'm opening step 4 next. It's already rebuilt on #72 and #68, and all 186 moved paragraphs fail a test when deleted.

STATUS: #69 merged; step 4 PR next.
