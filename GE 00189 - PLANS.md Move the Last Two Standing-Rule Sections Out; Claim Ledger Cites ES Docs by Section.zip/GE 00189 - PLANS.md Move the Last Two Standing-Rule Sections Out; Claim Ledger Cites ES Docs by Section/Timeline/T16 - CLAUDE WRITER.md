Asked the project to choose an option

Rework the Coordinator's protected AGENTS.md to shrink it now, or later?

1. Later, when Coordinator work resumes (recommended): Nothing changes now. I add a backlog line so the next Coordinator PR picks it up.
2. Now, as a docs and tests PR: I move the status entries to a history file and rewrite the byte-chain checks in about 16 test files, then it goes to a fresh audit.

Why recommended: The Coordinator hasn't changed since Nov 4 and isn't the product focus, so only agents working there pay for the 88 KB. Changing its protected-file checks is governance work.
