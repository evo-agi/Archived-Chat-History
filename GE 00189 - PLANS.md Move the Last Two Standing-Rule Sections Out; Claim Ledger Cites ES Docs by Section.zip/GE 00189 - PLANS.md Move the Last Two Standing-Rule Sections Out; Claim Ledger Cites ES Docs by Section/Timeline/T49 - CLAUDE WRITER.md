CI passed on #69 at `cb8260c`. Since then #68 landed on `trunk_dev`, so the PR needs one more merge before it can land. I've done that merge locally: it has no conflicts, the PR's own diff is unchanged, `PLANS.md` is 130,688 bytes and the docs tests pass. I'll push it once the re-check of `cb8260c` gives its verdict, so the head doesn't move while the re-check is still running.

STATUS: #69 green at `cb8260c`, waiting on the re-check verdict.
