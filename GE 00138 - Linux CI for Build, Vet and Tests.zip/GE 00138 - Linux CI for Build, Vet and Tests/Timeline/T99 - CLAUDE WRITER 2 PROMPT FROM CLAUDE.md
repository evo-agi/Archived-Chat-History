David approved the second Mac run (attached). If the folder prompt still shows, he may need to press Allow there too.
