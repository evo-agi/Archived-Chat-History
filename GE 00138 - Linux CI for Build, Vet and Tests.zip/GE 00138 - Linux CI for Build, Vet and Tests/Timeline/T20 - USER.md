What are the operator-host tests? Oh, do you mean the code that has my Mac filepaths?
