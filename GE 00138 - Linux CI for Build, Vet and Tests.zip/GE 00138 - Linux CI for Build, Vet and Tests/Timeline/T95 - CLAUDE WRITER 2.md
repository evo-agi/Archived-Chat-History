A member's own session is running on their device.

```json
{"kind":"thread_session","phase":"connected","session_id":"cse_01BtwdQwEMkbHRLytsptCuXQ","owner_account_id":"user_[account id withheld]","machine_name":"Mac.lan","machine_folder":"~/Repositories/Playground","text":"A member's own session is running on their device."}
```
