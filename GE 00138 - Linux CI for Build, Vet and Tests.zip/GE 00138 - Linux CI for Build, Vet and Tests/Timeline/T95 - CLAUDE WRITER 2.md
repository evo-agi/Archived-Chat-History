Handed the machine session instructions

Run a short, read-only check of one Execution-Substrate commit on this Mac and report the complete output. It repeats the macOS run for ES pull request 14 at its new head, this time with a Go 1.26.5 that lies outside the Go module cache, because the earlier run showed that the gate's self-check needs that. Change nothing outside one new temporary folder.

Rules:
- Work only inside one new folder that you create under /Users/ds/Repositories/Playground, for example with: mktemp -d /Users/ds/Repositories/Playground/es-mac-run.XXXXXX
- The folder /Users/ds/Repositories/Playground itself must still exist when you are done. Remove only your temporary subfolder.
- Do not change, stage, commit or delete anything in any existing folder. You may read the origin URL of the existing clone at "/Users/ds/Repositories/Execution Substrate" (git -C "<that path>" remote get-url origin) and use that URL to clone. Do not run any other command in that folder.
- No sudo. No git push. No downloads and no installs, with one exception that David's approval of this request covers: the temporary copy of Go in step 2, inside your temporary folder. Do not touch any live service.
- If a command fails, do not try to fix the code. Record the full output and go on to the next command.

Steps:
1. Create the temporary folder TMP. Clone evo-agi/Execution-Substrate into TMP/es (origin URL as above). Print: sw_vers, uname -m, python3 --version, whoami.
2. A Go 1.26.5 outside the module cache. The earlier run found Go 1.26.5 in the module cache at /Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64. Copy that tree to TMP/go1.26.5 (cp -R), then chmod -R u+w TMP/go1.26.5 so that it can be removed later. If that tree does not exist, stop and report; do not download anything. For every command below use this environment: PATH="TMP/go1.26.5/bin:$PATH", GOTOOLCHAIN=local, GOCACHE=TMP/gocache, GOFLAGS=-mod=readonly. Print: command -v go, go version, go env GOVERSION GOROOT GOMODCACHE, and shasum -a 256 "$(go env GOROOT)/src/testing/match.go". Expected: go1.26.5, a GOROOT inside TMP, and the hash f28418759ed48c72821b5ecc3700041b74151108557618f50d355ea98a1bbebe. If go version is not go1.26.5, stop and report.
3. In TMP/es: git fetch origin claude/project-thread-sqldt7-ci, then check out exactly commit aaef28f36f393e78f832a9caa745edeb02565a6c (detached). Confirm with git rev-parse HEAD. If origin/claude/project-thread-sqldt7-ci is not that commit, say so and still test that commit. Then run, each with its complete output and exit status:
   a. go test -count=1 -v -run 'TestReplayExistingStateModeNotRepaired|TestRetainedResultAuthReaderNeedsVerifierEvenForExistingPair' ./es/admission/...
   b. go test -count=1 -v -run '^TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSpireBundleReadClassifiesTraversalAmbiguityWithSudoVisibleInspection$' .
   c. go test -count=1 -v -run '^TestGo1265ToolchainBaselineDocsAndBuildContract$' .
   d. python3 -I -B .github/ci/go_test_gate_selftest.py
      Note for d: the self-check has 117 checks and takes about five minutes. It builds throwaway test binaries with the go test flag -overlay, inside temporary folders that it removes. It reads one file of the copied Go (src/testing/match.go) and changes nothing in it. After d, print the shasum line of step 2 again.
4. git status --porcelain in the clone (expected: empty). Remove TMP (rm -rf; if that fails for read-only files, chmod -R u+w TMP first). Confirm it is gone. Then run ls -ld /Users/ds/Repositories/Playground and include its output. If Playground itself is missing, recreate it with mkdir -p /Users/ds/Repositories/Playground and say so.

Report back: the lines of steps 1 and 2, the commit hash as checked out, and for each of a to d the exact command, its exit status and its complete output (for d: the line "Ran N tests in ...", the final OK or FAILED line, every line that is not "... ok", the complete block of each failing check up to five blocks, and the two shasum lines). Say plainly which commands passed and which failed. Do not summarize a failure away.
