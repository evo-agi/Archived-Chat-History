Damn. Regardless, the runbook needs to be updated, or renamed with a disclaimer about the problem(s) you highlighted.

In terms of your access to the Linux box, as I said before, the box is disposable. I don't really care what you do with it, as long as you return it to a working state at the end.

For the CI workflow, can you push to trunk_dev or a branch for trunk_dev? Or, if you need it in main to be active, we can push to main with a PR and then rebase trunk_dev.
