<!-- reply 1 -->
> Welcome back! The CI fix passed its audit, but the red-team found that tests which skip themselves slip past the gate. T…


I have never used CI on GitHub before. How do we check?
