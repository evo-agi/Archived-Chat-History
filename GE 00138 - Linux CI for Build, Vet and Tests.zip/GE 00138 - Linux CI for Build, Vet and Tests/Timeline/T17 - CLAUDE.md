Decision in Governed Execution: How should CI treat 14 Mac/operator-host tests that fail on Linux? (Decided: Gate the rest, still run these 14)

```json
{"kind":"widget","family":"blocks","widget":"card","input":{"blocks":[{"type":"context","text":"Decision in Governed Execution"},{"type":"section","text":"How should CI treat 14 Mac/operator-host tests that fail on Linux?"},{"type":"context","text":"Decided: Gate the rest, still run these 14"}],"updated_at":"2026-11-22T02:49:35.019663733Z"},"text":"Decision in Governed Execution: How should CI treat 14 Mac/operator-host tests that fail on Linux? (Decided: Gate the rest, still run these 14)","by_channel_session":true,"answers_decision":{"channel":"e0f1a6a9-419d-4a5e-a01a-1ab448a16525","card":"490585ef-28e0-49e7-8088-81332a0e9ec1","thread_root":"476dfcbb-1de4-434c-8c46-8b5df30a3919"}}
```
