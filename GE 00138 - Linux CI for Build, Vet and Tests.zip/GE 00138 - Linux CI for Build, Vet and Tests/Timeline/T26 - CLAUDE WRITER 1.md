Will do. The CI gating step will skip only the named environment-only tests. A second, non-blocking step still runs exactly those tests on every run, so their results stay visible, and they keep running locally as before. Each one goes in the workflow and the report with its reason, and porting stays a TODO. I'm waiting for PR #14's first real GitHub run so the list matches what the actual runner sees, not just my simulation.

STATUS: WORKING
