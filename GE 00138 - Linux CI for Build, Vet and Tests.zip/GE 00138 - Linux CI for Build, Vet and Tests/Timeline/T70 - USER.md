<!-- reply 1 -->
> Here's the catch-up for when you wake. One thing will need you in the morning.


I'm back. Mac is awake now.
