**Please approve one more short Mac run on the card above.** PR 14's new head `aaef28f` is green on the runner. The run repeats the gate's self-check on your Mac, about ten minutes, in a temporary folder under Playground. One thing is new: it copies the Go 1.26.5 that is already in your Go cache into that folder, with no download, and removes it at the end. The repair report does not wait for it.

STATUS: NEEDS DAVID
