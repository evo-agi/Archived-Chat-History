Catch-up: nothing needs you right now.

**Done**
- [Audit PR 13 second repair](#cmsg_01Un4xQgjBAczV8DABQvcLrxSsMykociXYMumM9HkiFH3L): blocked on one medium gap. The production code holds, but the test guard can still be bypassed in one new way. This is the third such bypass, so the fix now aims to block every unlisted way by default, not only this one. A fresh audit follows.

**Still working**
- [Fix admission recheck in PR 12 handoff](#cmsg_01Un4xQgjBAczV8DABQvcLrx9pawwgUw9Vc2B1PM9yQzTS) is doing that third repair.
- [Audit the fifth CI repair](#cmsg_01Un4xQgjBAczV8DABQvcLrxFjQhiMQMY9tjsRe75KB9hj) is checking PR 14.
- [Run Nomad and Vault tests in CI](#cmsg_01Un4xQgjBAczV8DABQvcLrx9qA4pvEiFx8Pa7SN4JK3UU) is checking whether those tests can run on GitHub.
- [Make the maintenance agent useful](#cmsg_01Un4xQgjBAczV8DABQvcLrxYHYjwtXH2FnDUmT2o66EZk) is fixing the audit's two small findings.

STATUS: WORKING (four threads; next update when they report)
