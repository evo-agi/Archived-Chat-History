Asked the project to choose an option

Decide how the CI test list handles the one gap no run can show

1. Accept the stated limit (recommended): Lines for single subtests stay allowed. A written rule says to read the test before listing a subtest. Today's two such lines are not affected. Nothing in CI enforces the rule.
2. List whole tests only: The gap is gone. Six es/app subtests that pass on the runner leave the gate again, which the second audit blocked, until those two tests are ported. PR 14 needs another repair.
3. Port the two tests first: The gap is gone and nothing leaves the gate. Two es/app tests get changed first, with their own audit and Mac run. Guess: about a day. PR 14 waits for it.

Why recommended: Today's two subtest lines are outside the gap, the shape is rare here (1 of 587 t.Run calls uses its result, by grep), and the list file tells authors to check. Details: report section 8.
