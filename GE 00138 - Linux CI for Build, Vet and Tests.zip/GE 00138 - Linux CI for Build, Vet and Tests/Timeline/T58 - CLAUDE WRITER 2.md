Withdrew the card

```json
{"kind":"activity","tool":"decide","text":"Withdrew the card","decision_id":"cmsg_01Un4xQgjBAczV8DABQvcLrxSfKfn3deRkJTAfxJ1CBdAU","closed_by":"session","close":"withdrawn"}
```
