Hmm... Please port them, or suppress/disable the tests when CICD pipelines run them.
