Evidence scripts for the re-audit report, part 1 of 2: the red-team probes, the mutants, the advisory sketch for the "must still fail" step, and the two stall scripts that make the lock test fail.

STATUS: READY (re-audit delivered; these are attachments only)
