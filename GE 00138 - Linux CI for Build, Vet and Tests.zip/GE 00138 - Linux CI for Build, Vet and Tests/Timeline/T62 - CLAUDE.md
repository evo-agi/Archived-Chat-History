Here's the catch-up for when you wake. One thing will need you in the morning.

**Done**
- [Red-team maintenance agent repair](#cmsg_01Un4xQgjBAczV8DABQvcLrxXpnpdchi39exRd9PkyXuFg): it stopped early as asked and still found a blocker. If the box's state folder is restored from an old copy, the Mac can stay silent while critical incidents are open. The fix goes in together with the audit's findings.
- [Finish the ES CI workflow fix](#cmsg_01Un4xQgjBAczV8DABQvcLrxUKRNzSrmXnB75DgsbjDwit): the third repair is green on GitHub. The writer is now closing the last gap with an automatic CI check instead of a written rule.

**Still working**
- [Re-audit maintenance agent repair](#cmsg_01Un4xQgjBAczV8DABQvcLrxCxBn7szC4ZDXctJhRhajgs) and the new [Audit PR 13 admission fix repair](#cmsg_01Un4xQgjBAczV8DABQvcLrxDaS9vLTNegC3QgUxiA5ySE).

**Needs you (morning)**
- Approve the one Mac test run for the CI fix. It needs your Mac awake.

STATUS: WORKING (two audits and the CI gap check; the Mac run waits for you)
