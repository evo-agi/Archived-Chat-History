Mostly, yes. They're tests that assume they're running on your machine, or on the Remote Alpha host where you operate ES. That's what "operator host" means here. Twelve of them depend on macOS file paths, on a user named `ds` existing, or on files owned by root as they are on your setups. A clean Linux CI runner has none of that, so they fail there even though the code may be fine. The other 2 need older ES binaries that were built outside the repo and aren't in it.

The fix is to port them so they create their own fixtures, without weakening what they check. Until then, the card's first option keeps them running visibly on every PR without blocking CI.

STATUS: NEEDS DAVID (the CI card)
