One quick call from the CI work. 14 ES tests only pass on your Mac or the operator host: 12 depend on macOS paths, the `ds` user or root-owned files, and 2 need old binaries built outside the repo. Taking them out of the pass/fail gate counts as skipping tests, so it needs your word. I recommend the first option. Every other test then becomes a real gate, and these 14 still run visibly on every PR until they're ported.

STATUS: NEEDS DAVID (this card). Maintenance agent review is running.
