All three are handled.

- **Box:** It's treated as disposable. I can do anything on it, including its ES services, Vault and certs, as long as it's back in working order at the end. Each time, I'll record what changed and how it was restored. I've put that in the project instructions in place of the old Remote Alpha protection.
- **Runbooks:** They're being updated with a clear disclaimer that the box is the Remote Alpha host. They'll also note the script hardening.
- **CI:** It goes on its own Claude branch as a draft PR to `trunk_dev`. Nothing is needed in `main`. GitHub runs PR checks from the PR's own workflow file, so no rebasing either.

I also added a standing rule: when you need to run something, you get a complete, tested script.

STATUS: WORKING on the PR 12 fix, CI and runbooks
