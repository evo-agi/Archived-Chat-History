Decision in Governed Execution: How should CI treat 14 Mac/operator-host tests that fail on Linux? (Decided: Gate the rest, still run these 14)
