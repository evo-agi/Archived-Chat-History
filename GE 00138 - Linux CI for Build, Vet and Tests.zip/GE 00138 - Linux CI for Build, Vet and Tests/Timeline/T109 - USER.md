> PR 17 (→ github.com) is ready for your review. It's one of your first three merges into trunk_dev. It repairs three Noma…


I won't be reviewing test-only changes. Please merge without asking.

Also, I'm not stopping manual reviews after 3 PRs. It's really when I'm in the mood, and, when I see something that piques my interest, I'd let you know in advance or retroactively.
