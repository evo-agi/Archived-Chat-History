Withdrew the card
