Instructions for the machine session, handed over when they allow

Read-only check on macOS of two commits of evo-agi/Execution-Substrate that are already pushed. Purpose: the audit of the CI pull request (PR #14) requires one run on the Mac of the tests that the PR changed, and the lock-timing test fix (PR #16) should run once on its home platform.

Rules:
- Work only inside a new temporary folder that you create under /Users/ds/Repositories/Playground. Remove that folder at the end.
- Do not change, fetch into, check out, commit, push or delete anything in any existing folder, including "/Users/ds/Repositories/Execution Substrate". You may read its remote URL.
- Do not use sudo. Do not run the whole test suite. Do not fix anything: if a step fails, keep its complete output and continue with the next step.
- Do not push anything and do not post anything to GitHub.

Steps:
1. Record the output of: sw_vers; uname -m; which go; go version; go env GOTOOLCHAIN GOFLAGS; python3 --version. If "go version" is not go1.26.5, say so clearly and continue anyway.
2. Read the remote URL: git -C "/Users/ds/Repositories/Execution Substrate" remote get-url origin
3. mkdir /Users/ds/Repositories/Playground/es-ci-mac-check-20261122 and inside it: git clone --no-checkout <that URL> es ; cd es ; git fetch origin claude/project-thread-sqldt7-ci claude/project-thread-k69qcw
4. git checkout --detach c4a84f5695500cca2087abefb8027afd700f35e2 . Confirm that "git rev-parse HEAD^{tree}" prints a05a25a6db5fe1d51819f16a28a9f18132667ccf and that "git status --porcelain" prints nothing.
5. At that commit run each command below, and keep its complete output and exit status:
   a. go test -count=1 -v -run 'TestReplayExistingStateModeNotRepaired|TestRetainedResultAuthReaderNeedsVerifierEvenForExistingPair' ./es/admission/...
   b. go test -count=1 -v -run '^TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSpireBundleReadClassifiesTraversalAmbiguityWithSudoVisibleInspection$' .
   c. go test -count=1 -v -run '^TestGo1265ToolchainBaselineDocsAndBuildContract$' .
   d. python3 -I -B .github/ci/go_test_gate_selftest.py   (the self-check of the CI gate script; it builds small throwaway Go modules in temporary directories and takes one to three minutes; for this one, the last 15 lines of output are enough, plus every FAIL or ERROR block if there is one)
6. git checkout --detach 0a069ecbe53c842d33c932f63aed2af523e2eb0c . Confirm that "git rev-parse HEAD^{tree}" prints 0b327b54deb9b880a748851fc4248bf3e3531809. Then run and keep output and exit status:
   a. go test -count=20 -run '^TestSQLiteClaimStoreTwoHandlesBusyTimeoutAndHelperProcessContention$' ./es/admission/internal/reliablesubmit
   b. go test -count=1 -v -run 'TestSQLiteClaimStore' ./es/admission/internal/reliablesubmit
   c. pgrep -fl 'reliablesubmit.test' ; echo "pgrep exit $?"   (expected: no process listed)
7. Report back, in one message: the outputs of step 1, the two confirmed tree hashes, and for each command of steps 5 and 6 the exact command, its exit status and its output (verbatim for the "--- PASS/FAIL/SKIP" and "ok/FAIL" lines and for any failure text).
8. Remove the temporary folder: rm -rf /Users/ds/Repositories/Playground/es-ci-mac-check-20261122 . Confirm it is gone.
