Asked the project to choose an option

```json
{"kind":"activity","tool":"ask_decision","text":"Asked the project to choose an option","decision":{"version":1,"question":"How should CI treat 14 Mac/operator-host tests that fail on Linux?","options":[{"label":"Gate the rest, still run these 14","consequence":"One CI step gates on every other test; a second, non-blocking step runs exactly these 14 by name on every run so their results stay visible."},{"label":"Run everything; CI stays red","consequence":"CI runs the full suite and shows these 14 failures on every PR until a follow-up makes them Linux-portable."},{"label":"Port the 14 tests first","consequence":"A follow-up makes their fixtures work on Linux without weakening them; CI stays red or unmerged until then."}],"recommended":0,"reason":"CI becomes a real gate now and no test is turned off. 12 tests depend on macOS paths, the ds user or root-owned files; 2 need historical binaries built outside the repo."}}
```
