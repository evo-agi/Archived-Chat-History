The CI fix passed its earlier blockers, but the re-audit found three more gaps. I'm starting a dedicated thread to close them so this runs alongside the PR 13 work.
