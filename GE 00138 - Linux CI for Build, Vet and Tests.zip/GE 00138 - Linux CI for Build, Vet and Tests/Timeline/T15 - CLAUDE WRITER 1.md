Asked the project to choose an option

How should CI treat 14 Mac/operator-host tests that fail on Linux?

1. Gate the rest, still run these 14 (recommended): One CI step gates on every other test; a second, non-blocking step runs exactly these 14 by name on every run so their results stay visible.
2. Run everything; CI stays red: CI runs the full suite and shows these 14 failures on every PR until a follow-up makes them Linux-portable.
3. Port the 14 tests first: A follow-up makes their fixtures work on Linux without weakening them; CI stays red or unmerged until then.

Why recommended: CI becomes a real gate now and no test is turned off. 12 tests depend on macOS paths, the ds user or root-owned files; 2 need historical binaries built outside the repo.
