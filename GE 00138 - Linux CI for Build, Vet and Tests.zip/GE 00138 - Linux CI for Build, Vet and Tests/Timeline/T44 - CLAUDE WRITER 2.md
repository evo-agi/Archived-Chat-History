Claude asked to work in a folder on your device. This version of the app can't show the request yet. Allow or decline it on claude.ai or the desktop app.

```json
{"kind":"remote_control_session","phase":"proposed","session_id":"cse_01BtwdQuPqwzJmEXH2BfcStB","owner_account_id":"user_[account id withheld]","requester_account_id":"user_[account id withheld]","consent_mode":"direct","thread_id":"cmsg_01Un4xQgjBAczV8DABQvcLrxUKRNzSrmXnB75DgsbjDwit","machine_name":"Mac.lan","machine_folder":"~/Repositories/Playground","ask":{"seed_message_id":"","environment_named":true},"display":{"title":"Allow Claude to work in your folder","detail":"Claude may run commands in your folder without asking."},"text":"Claude asked to work in a folder on your device. This version of the app can't show the request yet. Allow or decline it on claude.ai or the desktop app."}
```
