The Mac run is done, thank you. **PR 16 passes on the Mac** (the lock test 20 times in a row, and the whole claim-store group). The Go tests that PR 14 changed pass there too. The temporary folder is removed and `Playground` itself is still there.

One thing did not pass: the gate's own self-check, 46 of 114 checks on the Mac. None of it touches CI on GitHub, which stays green. It has three causes, and I am fixing what is mine in a second small commit on PR 14:

- **My defect:** one new check tells two test names apart only by upper and lower case, and the Mac's file system does not. I am making the check's file names case-safe.
- **A limit worth writing down:** the gate needs a Go 1.26.5 that is installed normally. Your Mac has 1.26.1 and fetches 1.26.5 on demand, and Go refuses one step of the gate for a toolchain fetched that way. The gate fails safely there. The doc will say so, and a check will hold it.
- A mutant also showed one gap in the self-check, which the same commit closes.

After that commit is green I will ask once more for a Mac run of the self-check alone. The report moves to about 18:00Z.

STATUS: WORKING
