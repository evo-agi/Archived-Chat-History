The CI repair is pushed and passing. I'm starting a fresh audit and red-team of it.
