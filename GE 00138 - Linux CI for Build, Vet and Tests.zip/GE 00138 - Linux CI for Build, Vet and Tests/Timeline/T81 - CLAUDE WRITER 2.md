You allowed Claude to work on your computer.

```json
{"kind":"remote_control_session","phase":"active","session_id":"cse_01BtwdQuPqwzJmEXH2BfcStB","owner_account_id":"user_[account id withheld]","requester_account_id":"user_[account id withheld]","consent_mode":"direct","thread_id":"cmsg_01Un4xQgjBAczV8DABQvcLrxUKRNzSrmXnB75DgsbjDwit","machine_name":"Mac.lan","machine_folder":"~/Repositories/Playground","text":"You allowed Claude to work on your computer."}
```
