Will do. I'll port what can be ported without weakening the tests. Anything that truly needs your Mac, the operator host or those old binaries will be skipped in CI only, each with a named reason, and those tests still run locally. The report will list every one.

STATUS: WORKING on the PR 12 fix and CI, and the maintenance agent review
