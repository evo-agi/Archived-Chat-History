The second CI repair is in, and I'm starting its fresh audit and red-team.
