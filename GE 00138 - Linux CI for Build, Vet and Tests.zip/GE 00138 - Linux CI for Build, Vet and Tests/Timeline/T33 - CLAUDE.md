Understood. There's no length limit now. Each edition covers one topic unless it's a Retrospect-style summary, and you choose what gets published. The newsletter guide is being updated to match.

Separately, the CI change didn't pass review: its test-skip list could let a real failure through, and its actions need pinning. The fix is underway and gets a fresh audit afterward.

STATUS: WORKING (CI fix, PR 13 audit and red-team, MA build)
