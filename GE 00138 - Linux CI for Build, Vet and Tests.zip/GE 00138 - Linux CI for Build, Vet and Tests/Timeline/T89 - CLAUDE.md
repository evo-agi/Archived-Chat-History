The Mac run went well for the code itself. PR 16's lock test passed 20 times in a row, and the Go tests that PR 14 touches pass on your Mac too. The CI gate's own self-check tripped on macOS, partly because the Mac's file system ignores upper and lower case, so a small fix is underway. After that I'll need one more short Mac run.

STATUS: WORKING (CI self-check fix, MA audit, PR 13 repair; nothing needed from you now)
