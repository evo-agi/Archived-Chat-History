Then the answer is almost certainly no, and that's expected. PR 14 is the first CI ES has ever had, so nothing could require it yet. Inference: a quick look would confirm it. There's nothing to do now. Once PR 14 merges, I'll send you a short click-by-click guide to make the check required on trunk_dev, so no change can merge while it's red. It's about five clicks in the repo settings.

STATUS: WAITING (CI repair, PR 13 repair, MA repair; the Mac run request is coming soon)
