A short update, and nothing needs you.

**Found and being fixed**
- While checking the bring-up fix, the audit found a real ES gap. If the run folders inherit their group from the parent folder, ES says it's ready, but every submission then fails. The docs now describe this correctly. A separate fix will make ES refuse to report ready in that case. It changes product code, so it will come to you for review.

**Still working**
- PR 18 (bring-up) is in its last small check before it merges.
- PR 14 (CI) has its narrow audit running, and a separate fix for one flaky timing test is underway.
- PR 13's third repair is in its full audit.
- The maintenance agent is getting your new "investigate" alert, and its audit is running.
- The other three bring-up services now run as your user too, and that passed on GitHub.

STATUS: WORKING (nothing needed from you)
