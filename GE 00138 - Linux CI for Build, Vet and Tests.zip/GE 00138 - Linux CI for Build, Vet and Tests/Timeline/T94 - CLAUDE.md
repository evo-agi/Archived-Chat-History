One more short Mac run is ready for your approval. It takes about ten minutes. The newest CI fix is green on GitHub, and this run repeats the gate's self-check on your Mac in a temporary folder under Playground. One thing is new: it copies the Go 1.26.5 that is already on your Mac into that folder (nothing is downloaded) and removes it at the end. Please press Allow on the card in the thread.

STATUS: NEEDS DAVID (allow the second Mac run)
