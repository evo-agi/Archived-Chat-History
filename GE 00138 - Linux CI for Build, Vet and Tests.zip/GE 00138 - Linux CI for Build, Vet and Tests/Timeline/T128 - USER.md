<!-- reply 1 -->
> PR 14 (→ github.com) is merged into trunk_dev as f9537a8. ES now has its first CI. Every PR runs the build, vet and test…


Enabled status checks and checked `Require branches to be up to date before merging`.
