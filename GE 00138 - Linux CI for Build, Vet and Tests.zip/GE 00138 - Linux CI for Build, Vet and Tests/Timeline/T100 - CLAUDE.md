Thanks, the Mac run is starting. Separately, the maintenance agent's second repair passed its audit with two small findings, and those are being fixed now. Its live test on your Mac comes after that, so it runs on the final version.

STATUS: WORKING (Mac run, MA small fix, PR 13 audit; next update when the Mac run reports)
