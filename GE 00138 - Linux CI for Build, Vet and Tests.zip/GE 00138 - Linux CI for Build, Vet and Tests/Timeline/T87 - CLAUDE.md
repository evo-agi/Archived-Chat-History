Thanks! The run will leave Playground in place and recreate it if anything removes it. I've also saved Playground as my scratch area on your Mac for tests outside the known repos, always cleaned up afterward.

STATUS: WORKING (Mac run, MA audit, PR 13 repair; next update when the Mac run reports)
