PR 18 is merged: trunk_dev is now 3a5f25776274b3e9ada3e2d489c9bfe0e8bf8a28. Go ahead and update PR 14 as planned.
