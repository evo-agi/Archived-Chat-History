Claude asked to work in a folder on your device. This version of the app can't show the request yet. Allow or decline it on claude.ai or the desktop app.
