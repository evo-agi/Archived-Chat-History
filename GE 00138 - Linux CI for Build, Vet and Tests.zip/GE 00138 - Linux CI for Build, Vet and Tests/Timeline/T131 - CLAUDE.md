Thanks! One quick check: under that setting, is `build, vet and test` listed as a required check? If the list is empty, GitHub requires nothing, so the check has to be added by name. From now on, every PR must be up to date with trunk_dev and green before it can merge, and I'll make sure all the work follows that.

STATUS: NEEDS DAVID (confirm the check is listed; Mac run approval still open)
