The runbook norm is now in the project instructions. The thread that does the work writes or updates its runbook in the same tranche and pushes it to `main` without asking. While I was in there, I also recorded your "working state" meaning for the Linux box. Draft PR 13 now carries the PR 12 fix, and the CI PR is next.

STATUS: WORKING on the PR 12 fix and CI. Audit and red-team start after.
