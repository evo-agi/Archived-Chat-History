A quick one from the PR 12 fix: the thread needs your tap to push the new ES CI workflow as its own small PR. That keeps it separate from the admission fix under audit.

STATUS: NEEDS DAVID (this card, plus the Remote Alpha card above)
