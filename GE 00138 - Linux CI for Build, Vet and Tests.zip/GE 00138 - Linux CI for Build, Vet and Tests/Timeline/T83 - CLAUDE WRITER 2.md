You allowed Claude to work on your computer.
