**Please approve the Mac run card above.** It checks the new head of [PR 14](https://github.com/evo-agi/Execution-Substrate/pull/14) and the pending run of PR 16 in one session, in a temporary folder that it removes. The older request for `b39fa35` is withdrawn.

The skip fix is pushed as `76d9a91` and [green on the GitHub runner](https://github.com/evo-agi/Execution-Substrate/actions/runs/45039279766/job/137259866158). The runner count is now known: **39 tests skip themselves there**, 36 because the runner has no `nomad`, one because it has no `vault`, and two helper processes. All 39 are in the list with their reason, and a skip that is not listed now fails CI. The job takes 12 minutes instead of 8.

The report `08-repair.md` follows when the mutant run ends, at about 17:10Z.

STATUS: NEEDS DAVID
