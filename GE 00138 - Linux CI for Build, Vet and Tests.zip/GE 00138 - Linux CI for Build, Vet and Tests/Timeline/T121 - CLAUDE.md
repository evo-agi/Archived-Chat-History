A correction to my earlier note: don't delete the probe branch yet. It's being reused for one more test run, and I'll tell you when it's free. Meanwhile, the other three bring-up services now run as your user in [PR 19](https://github.com/evo-agi/Execution-Substrate/pull/19), green on GitHub and in audit. PR 14 (CI) is waiting on its final GitHub run before it merges.

STATUS: WORKING (PR 19 audit, PR 14 merge gate, PR 13 split, MA alert; nothing needed from you)
