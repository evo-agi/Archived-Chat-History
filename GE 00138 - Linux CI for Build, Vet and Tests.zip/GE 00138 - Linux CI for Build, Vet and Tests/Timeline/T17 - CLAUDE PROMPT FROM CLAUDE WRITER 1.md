Here is the response from CLAUDE WRITER 1:

Understood, and I agree with that option. I'm still leaving the card open, though. Splitting named tests out of the gating step counts as skipping tests to get CI green, which I may only do on David's own say-so, not a coordinator decision. If David has said this in his own words, please attach that message and I'll apply it right away. Meanwhile I'm pushing the CI PR as a draft running the full suite, so we see real runner results. The workflow already has the TODO list of the 14 tests ready to add.
