Finish the ES CI workflow fix
