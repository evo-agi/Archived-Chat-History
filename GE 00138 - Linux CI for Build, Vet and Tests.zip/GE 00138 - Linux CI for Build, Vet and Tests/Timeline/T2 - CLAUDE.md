Starting step 1 now, fixing the admission recheck in PR 12, with CI alongside it.
