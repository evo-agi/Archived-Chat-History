Both changes are done and ready for an independent audit and a red-team pass. Nothing is merged.

**The PR #12 fix is draft [PR #13](https://github.com/evo-agi/Execution-Substrate/pull/13).** A retried handoff now re-checks current admission at every step before it can take effect. I started from the recovered Codex candidate and fixed one gap I found: its field-access guard counted some writes as reads. I also added the retry-after-policy-change tests you asked for. They fail if the re-check is removed.

**The CI is draft [PR #14](https://github.com/evo-agi/Execution-Substrate/pull/14), and it is green on GitHub's runner.** It runs build, vet and the tests on every PR and on pushes to trunk_dev, so main isn't needed. As you asked, the 16 tests that only pass on the Remote Alpha host or need outside binaries are skipped in the gate. They still run in a separate step that can't block, and each one is listed as a TODO to port. A 17th name is already listed for a test PR #12 adds.

PR #12 and #13 get no CI until PR #12 is brought up to date with trunk_dev after #14 merges. That touches a branch Claude didn't create, so it will need your go.

Reports, with exact SHAs and manifests (SHA-256):
- [Fix report](/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/01-implementation.md): `36c2eca9…66b2`
- [CI report](/mnt/project-files/reports/Execution-Substrate/ci-go-workflow/01-implementation.md): `da05a131…9467`

STATUS: WAITING
