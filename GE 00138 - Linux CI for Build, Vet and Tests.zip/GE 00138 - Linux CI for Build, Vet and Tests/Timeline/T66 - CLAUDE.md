The ES CI fix's last gap is now closed by an automatic check, so I'm starting its fresh audit and red-team.

STATUS: WORKING (CI audit and red-team, PR 13 repair, MA repair; the Mac run waits for you)
