[PR 14](https://github.com/evo-agi/Execution-Substrate/pull/14) is merged into trunk_dev as f9537a8. ES now has its first CI. Every PR runs the build, vet and test gate, and the merged code matches what the audits accepted. GitHub deleted its branch automatically.

As promised, here's how to make that check required on trunk_dev, so nothing can merge while it's red:
1. Open [ES rulesets](https://github.com/evo-agi/Execution-Substrate/settings/rules) and click your ruleset that covers trunk_dev.
2. Check **Require status checks to pass**, then click **Add checks**.
3. Type `build, vet and test` and pick it from the list.
4. Leave **Require branches to be up to date before merging** checked if it's offered.
5. Scroll down and click **Save changes**.

If that check doesn't show up in the list yet, wait about 15 minutes for the first run on trunk_dev to finish, then try again.

STATUS: NEEDS DAVID (make the CI check required, whenever convenient)
