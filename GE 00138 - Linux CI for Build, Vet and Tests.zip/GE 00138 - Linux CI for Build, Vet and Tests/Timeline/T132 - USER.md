> Thanks! One quick check: under that setting, is build, vet and test listed as a required check? If the list is empty, Gi…


List is not empty, though the dropdown currently has "GitHub Actions" for both branches' rulesets.
