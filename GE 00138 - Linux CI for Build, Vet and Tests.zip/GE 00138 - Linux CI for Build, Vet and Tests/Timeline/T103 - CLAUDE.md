The CI fix's fourth repair passed your Mac run and is green on GitHub ([PR 14](https://github.com/evo-agi/Execution-Substrate/pull/14)), so I'm starting its focused audit. Every test that skips itself in CI now needs a listed reason. That made one gap visible: 37 submit-flow tests need Nomad and Vault, so they never run in CI.

One question for you: should I add Nomad and Vault to CI so those 37 tests run there? I recommend yes, because they cover the submit path we're making reliable next. It would make each CI run longer, by an amount I don't know yet. It would be a separate PR after PR 14.

STATUS: NEEDS DAVID (yes or no on running the Nomad/Vault tests in CI; the audit runs meanwhile)
