# IMPLEMENTATION REPORT: PR #12 current-admission re-check

**Verdict:** IMPLEMENTATION_COMPLETE, ready for an independent audit and a red-team pass.
**Effect status:** TOPIC_BRANCH_PUSHED · DRAFT_PR_OPENED https://github.com/evo-agi/Execution-Substrate/pull/13 · MERGE_NOT_PERFORMED · INDEPENDENT_AUDIT_NOT_PERFORMED · RED_TEAM_NOT_PERFORMED

## Target identity

| Field | Value |
|---|---|
| Objective | Fix PR #12's unresolved finding: a retried private operational handoff could stage and register without re-checking current admission policy |
| Repository | evo-agi/Execution-Substrate |
| Base ref and SHA | `codex/reliable-submit-operational-handoff-v1` (PR #12 head) at `8058561edc08356c46680c204586b3c7796c0ff3`, whose parent is trunk_dev `ae326b0ddc30ec6b35883ee32945c622405b68b6` |
| Topic branch | `claude/project-thread-sqldt7` |
| Topic commit | `e544e0fbe4220dfdd2c2068e3267dcfa454a0cf9` (single commit; parent is the base) |
| Tree | `7be20ba8a71f0f55490aaac2eb8aed5601386830` |
| Draft PR | #13, base `codex/reliable-submit-operational-handoff-v1`, so its diff is exactly the fix |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (`/mnt/project-files/claude-conversion/tools/governed_execution_audit_patch_manifest_v2.py`) |
| Manifest upstream | `origin/codex/reliable-submit-operational-handoff-v1` (the base ref; **not** origin/trunk_dev) |
| Canonical manifest SHA-256 | `21d19775bbe7c2d9aef0752d7a9f5b315734b7bf6f8f313197357dfc71cd7907` (4,334 bytes) |
| Textual diff SHA-256 | `84ca50e683502119b399077745f3480024a06bd3d5f16e329287fc93173f23aa` |
| File count | 19 (17 tracked_modified, 2 untracked new) |

**Auditor reproduction note:** to reproduce the manifest, follow provenance §5.3 with `BASE=8058561edc08356c46680c204586b3c7796c0ff3`, `TOPIC=claude/project-thread-sqldt7` and `TIP=e544e0fbe4220dfdd2c2068e3267dcfa454a0cf9`. Pin the upstream with `git branch --set-upstream-to=origin/codex/reliable-submit-operational-handoff-v1`, because the manifest records the upstream. I reproduced it this way in a fresh clone from the pushed commit, and the result was byte-identical to the implementation manifest.

Final working-tree status after commit: clean (`git status --porcelain` empty). It was still clean after the final validation run.

## Reconnaissance

- **Subagents:** none. Every finding here is my own reading and my own runs.
- **Prior art (adopted):** the coordinator directed this thread, following another thread's discovery, to start from the recovered Codex V2+G2 candidate in the GE 00136 chat archive. That packet is `GE 00136/Generated/ES-PR12-V2-G2-Parenthesized-Access-Repair-Review-Packet.zip` inside the uploaded archive, SHA-256 `aeb65b370020022aae6e9b7a3e6eea03b129146e2916e49a22109f5afbfdfeae`.
  - I extracted it with `python3 -I` into an empty directory, rejecting symlinks and traversal.
  - I overlaid its 19 `source/final/` payloads on `8058561` in a scratch worktree.
  - `git write-tree` gave `433b4891a0e413aff2b0eb6adf316a033a544a24`, the candidate's claimed tree.
- **Audit history of that candidate:** its own appendix A is the prior independent audit, which REJECTed the predecessor for finding V2-G2: a parenthesized field write counted as a read.
  - The audit judged earlier findings G1, V1 and D1 addressed, and the PR #12 omission source-level repaired.
  - It passed its gates 1 to 6 and skipped gates 7 to 12 because G2 already decided the verdict.
  - The G2 repair in `433b4891` was **never audited**. I treated the whole candidate as unaudited.
- **My own earlier draft (rejected):** before the candidate surfaced, I drafted a re-check that built an `AdmissionPolicyContext` by hand from frozen inputs. I dropped it because it could not re-evaluate signer revocation: the PR #12 retained original does not keep the evidence signer. The candidate closes that gap by retaining the full signed evidence in a v2 original. The draft diff is not part of this change.

## Implementation decision

**Adopted candidate design (unchanged production code from `433b4891`):**

- New originals use `operational_local_v2`. Leaf 5 of the TLV 8 provenance carries the complete signed `evidencev1.ArtifactEvidence`, both Claims and Seal, from the same single ordinary resolution. It is at most 256 KiB and must re-encode exactly.
- A one-shot Service-owned `operationalAdmissionSnapshot` is commissioned for a qualified installation and epoch. It deep-copies the loaded trust model, the provenance verifier and the supported built-in policy set.
  - `Service.Initialize` cannot replace trust after commissioning.
  - Only monotonic local withdrawal is mutable.
  - There is no production commissioning caller. The whole handoff is unwired in production at both PR #12 and this commit.
- `qualifyOperationalRetained` runs on every unmarked v2 first-effect cut: run/intent, pre-stage, stamp, first marker, post-COMMIT release and final sender entry. Each run:
  - decodes and binds the retained evidence to the plan and material;
  - verifies the signature with the snapshot verifier;
  - enforces the snapshot trust model, which covers revoked signers and revoked artifacts;
  - evaluates the built-in policy over the same `newAdmissionPolicyContext` that ordinary admission uses;
  - re-samples withdrawal and identity before returning positive.
- Outcomes:
  - Denial or unavailability returns value-free `OperationalUnavailable` and withholds the run and receipt.
  - Malformed or contradictory evidence returns `OperationalIntegrity`.
  - Earlier writes and their dispositions are preserved.
- v1 originals: accepted receipts and positive marked reconciliation stay readable without current admission. Unmarked v1 cannot gain a first effect. Receipt paths never call the qualifier.

**My changes on top of the candidate.** There are 5 files: +331/−17 against tree `433b4891`. Production Go is unchanged.

1. **Guard gap: writes counted as reads (finding W1, fixed).** I probed the candidate's `typedReferenceAccessKind` with synthetic packages. All of the following were classified as `read`, which lets a same-site write pass an exact read inventory, the same class of escape as V2-G2:
   - range-clause `=` key and value targets (`for s.f = range ...`);
   - explicit address-of (`*(&s.f) = v`, `p := &s.f`);
   - implicit address-of through a pointer-receiver method on an addressable value field, or through slicing an addressable array;
   - writes through a selector, index, slice or dereference chain rooted at the field (`s.v.k = x`, `s.v[0] = x`, `*s.p = x`);
   - the mutating builtins `clear`, `close`, `delete` and `copy` (as destination).

   The fix adds the kinds `address` and `write-through`. Range-clause `=` targets count as `assignment`. An unresolved selection in the chain becomes `unclassified` and fails the inventory.
   - Every existing production access inventory is unchanged under the new classifier.
   - The new maintained subtest has 31 same-site cases: 24 non-read and 7 read controls. Each checks the exact kind, refusal by an allowed-read inventory, and acceptance by the correct-kind inventory.
   - Negative control: the same 31 cases against the candidate's classifier fail 24 and pass the 7 read controls.
2. **Retry-after-policy-change tests (`TestPR12RetryAfterPolicyChange`).** Six cases: seeds after run assignment and after intent, each crossed with three changes (configured literal deny, artifact revocation, signer revocation). Each case:
   - commits the seed under the original authority;
   - retries under a newly commissioned authority with the change, and requires `operationalUnavailable` with reason `OperationalUnavailable`, no run, no receipt and an identical claim state;
   - retries again under the original allowing authority, and requires acceptance at revision 6, marked, with exactly one POST.

   Mutant check: forcing `qualifyOperationalRetained` to return success after the snapshot lookup makes all 6 fail. Retries from a stamped-but-unmarked state cannot reach the marker by design (no stage reattachment), so the marker cut is covered by the candidate's within-invocation withdrawal tests.
3. **Vet:** the candidate's intentional `copied := *precommission` (proving a copied Service cannot borrow authority) tripped vet's copylocks check. It now makes the identical struct copy through reflection and asserts the copy reproduces the source fields. The test's semantics are unchanged, and copylocks stays on for ordinary code.
4. **Docs and contract pins:**
   - Owner doc §3: access-kind rules for range, address and write-through, plus the retry-after-policy-change obligation.
   - Owner doc §9: reconciles the five paths the repair adds outside the 37-file map. These are `reliable_submit_operational_admission.go` and its test (both new), `service.go`, `resolved_execution_plan.go` and `.docs/system_overview/boundaries.md`, giving an aggregate of 42.
   - Owner doc status row: changed from "unstaged candidate" to "committed draft-PR candidate awaiting fresh independent audit and red-team review".
   - New PLANS.md entry dated 2026-11-22. The 2026-11-20 entries are left as history.
   - New `docs_contract_test.go` pins, plus deletion and downgrade mutants (`MissingRangeAssignmentRule`, `MissingAddressAccessRule`, `MissingWriteThroughRule`, `WriteThroughDowngrade`).

**Treatment summary:**
- Current contract: PR #12 schema 5, codec 5, scope 3, SQL migrations, receipts and public refusal are unchanged.
- Strategic target: the Bounded slice rule refinement on the Reopened redesign seam, as the candidate selected.
- Compatibility: v1 is a Temporary compatibility edge, as the candidate selected.

## Files touched (19, classification against base `8058561`)

| Path | Kind | Summary |
|---|---|---|
| es/admission/reliable_submit_operational_admission.go | new, production | Candidate: snapshot commissioning and withdrawal, evidence decode and bind, `qualifyOperationalRetained` |
| es/admission/reliable_submit_operational_handoff.go | production | Candidate: qualifier at every unmarked cut, sender final sample, owner Service link |
| es/admission/reliable_submit_operational_format.go | production | Candidate: v1/v2 variant, v2 evidence leaf encode and verify |
| es/admission/service.go | production | Candidate: snapshot fields, Initialize refuses after commission, full evidence carrier on `preparedArtifact` |
| es/admission/resolved_execution_plan.go | production | Candidate: `provenanceRecord` carrier on `resolvedExecution` |
| es/admission/internal/reliablesubmit/replay_custody_structure.go | production | Candidate: custody accepts the bounded opaque v2 leaf |
| es/admission/reliable_submit_operational_admission_test.go | new, test | Candidate tests, plus my `TestPR12RetryAfterPolicyChange` and the vet-clean copy |
| es/admission/workstream_c_guardrails_test.go | test | Candidate inventories, plus my classifier fix and 31-case subtest |
| es/admission/reliable_submit_operational_format_test.go, reliable_submit_operational_handoff_test.go, reliable_submit_guardrails_test.go, internal/reliablesubmit/operational_handoff_test.go | test | Candidate |
| docs_contract_test.go | test | Candidate pins, plus my pins and mutants |
| .docs/execution_lifecycle/reliable_submit_operational_handoff.md | doc (owner) | Candidate v2 sections, plus my access-kind, retry, §9 and status text |
| PLANS.md | doc | Candidate entries, plus my 2026-11-22 entry |
| .docs/execution_lifecycle/es_execution_admission_model.md, reliable_submit_persistence_and_concurrency.md, submit_idempotency_correlation_and_recovery.md, .docs/system_overview/boundaries.md | doc | Candidate |

## Validation (Linux container, Go 1.26.5, against the committed bytes `e544e0f` unless noted)

| Command | Result |
|---|---|
| `go version` | go1.26.5 linux/amd64 (module-cache toolchain; go.mod `go 1.26.5`) |
| `go build ./...` | exit 0 |
| `go vet ./...` | exit 1. Two pre-existing trunk_dev issues only: `es/admission/result_auth_test.go:395` copylocks, and the `reliablesubmit` test package not compiling on Linux (`Stat_t.Mode` uint16 vs uint32 at `replay_custody_file_test.go:1210,1214`). Both are fixed in CI PR #14. No vet finding in any file this commit changes. |
| `gofmt -l` on changed Go files; `git diff --check` | empty, exit 0 |
| `NO_PROXY=$NO_PROXY,.internal go test -json -count=1 ./...` (2m43s) | 4,802 pass, 170 fail (including subtests), 49 skip. See below. |
| `./es/admission` within that run | **1,382 pass, 0 fail, 3 skip.** The new tests all pass: `TestPR12RetryAfterPolicyChange` (7 results, including the parent), the 32-result write/address/write-through subtest, `TestPR12RetainedAdmissionCuts` (9), and `TestOperationalSubmitHandoffCurrentAdmissionV2*` docs pins (17). |
| `./es/admission/internal/reliablesubmit` with the CI PR's Linux compile fix overlaid in a scratch copy | 670 pass, 3 fail, 2 skip. The 3 are the historical-opener probes `TestOperationalHandoffSchema4BinaryRefusesSchema5`, `TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation` and `TestSQLiteV3OldBinaryRefusesWithoutMutation`, which require the `ES_REPLAY_*_PROBE` binaries. `go vet` on the package is clean. |
| Same run, root package | 17 top-level Remote Alpha operator-host failures: root-owned witnesses, the `ds` account, `/private/tmp`, Vault service-user migration as root, sudo-visible SPIRE paths. Environment-only; the same family fails at the PR #12 head baseline (34 there, before ssh/uuidgen were installed). |
| Same run, es/app | 3 `TestSupportedLocalExecutionRoot*` failures, because those tests refuse to run as root. Identical at baseline, and they pass as non-root (shown in the CI simulation). |
| Baseline comparison | Full suite at `8058561` (scratch/baseline). Every failure in this run is in the baseline's environment-only set. No new failing test. |
| Discrimination | Classifier: 24 of 31 new cases fail on the candidate classifier. Re-check: all 6 retry cases fail with the qualifier forced positive. |
| Race detector (`go test -race` on es, ags, ars, egs and internal on the CI branch tree) | 0 data races reported; remaining failures are the proxy, root and probe environment issues. |

Failed or skipped validation:
- The historical-opener probes were not run because their out-of-repo binaries are not available.
- The Remote Alpha operator-host tests cannot pass in this container.
- No Docker daemon or Nomad, so Docker and Nomad integration tests skipped.
- No native host qualification.

Dependencies changed: none. Artifact hygiene: scratch worktrees and clones live only in this thread's scratchpad; nothing was added to the repo.

## Authority, security and protocol widening

- No new production caller.
- No public API, DTO, config or HTTP status change.
- No SQL migration.
- The new access kinds only make an existing test guard stricter.
- The candidate's production changes (snapshot authority, Initialize refusal after commission, v2 evidence carrier) are what the audit must judge. Of these, only the carrier runs on the ordinary Submit path: one `json.Marshal` of already-decoded evidence, inert for ordinary Submit.

Cross-repo impact: none.

## Provenance

Recipe verified by SHA-256 before each run. Upstream pinned to the base ref. Run twice to two absent paths in a fresh mode-0700 directory outside the repo, and `cmp` identical. Staged set equals the manifest set (19 paths). One commit, clean status, topic branch pushed. Reproduced from the pushed commit in a fresh clone, byte-identical.

Complete canonical manifest (exact bytes, one line). The manifest file is this line followed by one newline (`\n`); that is what the SHA-256 covers:

```json
{"branch":"claude/project-thread-sqldt7","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/es_execution_admission_model.md","sha256":"5d13a6dfa0006fac5c84430828dbfcf2dd813addbc98b4dad5c57e9b43ae7aae","size":99440},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_operational_handoff.md","sha256":"832d306cd3d4abe4c13bee114193b67b137d08ff73aa9c4224be26fab2636e7b","size":83037},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md","sha256":"0a623188d5b4477fb6cb90ab75179571983709d7828ee72e07e169e589d9d5e2","size":165489},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md","sha256":"8a4ccf9f7e9cf078f3ab5b7bbd3a35b44b3d39694a5d8944bf8fde17dd148603","size":105411},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/system_overview/boundaries.md","sha256":"22649e9324c4ccf7fe4ce5afc477f4feee06081a59e0534ca57ba657ad835341","size":72460},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"c6b6aaa563c7c699590ac4a2976abd5e48177dcbc747cdd290b3f17278bde964","size":311161},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"a075dba717dbd93d60bf1cfda41c8bdb66c7e835bb1a6dee35321602edd52130","size":823807},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/operational_handoff_test.go","sha256":"1b5fbd6f88bdb71b5cc20d46db62d48331f5e95e5d93c6ba4455e942c805425e","size":52569},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_structure.go","sha256":"0019a3399c9ec4f8cb302be0ff09c718f51537dbc20942006af06baf13589579","size":19178},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_guardrails_test.go","sha256":"414261eff56b2864c4906393d08e7873d83ba1800e2c1c7daabc4ea918c71a63","size":66334},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/reliable_submit_operational_admission.go","sha256":"e07d993ef1f8775fd3f1194f2caaab2d213415881cd63361a2a1c6ec52c6f258","size":11917},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/reliable_submit_operational_admission_test.go","sha256":"9d9a8777cfe5754655b022bf79682fa0b270dc58dbe43b867cbd73b49ef90aa1","size":50989},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_format.go","sha256":"11862c6bbbe801499cb4f681f031f75843d9cbf33f4705fc76adf61405035a9b","size":10333},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_format_test.go","sha256":"ab0dd3e9fc3104a3ce881ddf46db4cd38af31bbf1321a1903b1767adef01d61e","size":31589},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_handoff.go","sha256":"d780f7869253dde3b7d87792d4e41b2b7c873eb9986401be3270155a690fd871","size":24839},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_handoff_test.go","sha256":"8eeb4b449d906dca16d1fbcecb3523a16efcdb6489b6e8b89047ca3030d9cd6c","size":57030},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/resolved_execution_plan.go","sha256":"449dedaaf284bb3798f897b93c42ef282dcebe2c553e7318ffaf7a72e75c7ef0","size":28834},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/service.go","sha256":"f51868a25ad76b210b76841c81a4983e67047164de3b633c1409ee293f832be2","size":35143},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/workstream_c_guardrails_test.go","sha256":"419f6eab442a25a04c497cf137677fd022b7acec79da94cf1eec4ceed231c37b","size":326148}],"head":"8058561edc08356c46680c204586b3c7796c0ff3","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"84ca50e683502119b399077745f3480024a06bd3d5f16e329287fc93173f23aa","upstream":"origin/codex/reliable-submit-operational-handoff-v1"}

```

## Assumptions, unresolved seams, uninspected areas

- **For the red team:**
  - The access-kind guard is syntactic. Aliasing through variables, ordinary function or method bodies, `append` into spare capacity, reflection and `unsafe` are outside its claim, as the owner doc states.
  - Implicit address-of is detected only for pointer-receiver methods and array slicing.
- **Production authority is unwired:** no production code commissions the snapshot, so nothing here shows installed or native behaviour. The "current admission" is the commissioned snapshot. A trust or policy change needs a new qualified epoch, meaning a new process and a recommission. This is the candidate's selected model and the owner doc records it.
- **Fail-closed divergence:** `completeOperationalPolicyInputs` refuses an empty payload whenever a payload input class is required. This is stricter than ordinary admission, not a bypass. Not changed.
- **Reason precedence:** if the context is canceled after a qualifier denial, the reported reason can be the denial rather than `OperationalCanceled`. Value-free either way. Not changed.
- **Not re-audited by me beyond source reading and my probes:** the candidate's G1, V1 and D1 areas that the prior audit judged addressed, including the independent v1/v2 wire oracles, custody v1 nonempty framing and commissioning equality checks.
- **Platform:** the gid-20 (macOS) suspicion is moot on Linux. All es/admission tests pass under gid 0 here. No macOS run was done.

## Confidence

- Provenance: high. Reproduced byte-identical from the pushed commit.
- Validation: high for es/admission and the guard, docs and retry tests. Medium overall, because environment-only suites (Remote Alpha, historical probes, Docker and Nomad) were not exercisable here.
- Implementation: medium-high. Strong local evidence, but an unaudited candidate plus my delta. An independent audit and red team are required.

## Report delivery

Path: `/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/01-implementation.md`. Its SHA-256 is given in the delivering thread reply.
