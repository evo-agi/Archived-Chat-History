# INDEPENDENT RE-AUDIT AND RED-TEAM REPORT: Execution-Substrate PR #14 (Linux CI), repaired tip `fada999`

**Final verdict: BLOCK**
**Effect status:** REPAIR_NOT_PERFORMED · COMMIT_NOT_PERFORMED · PUSH_NOT_PERFORMED · PR_NOT_MODIFIED · NO_COMMENT_POSTED · MERGE_NOT_PERFORMED · read-only on the target throughout

One fresh thread did both jobs the brief asked for: the correctness audit and the red-team pass. It wrote neither the patch nor the repair.

## 1. Verdict in short

The repair does what it set out to do. Both blockers from `02-audit-redteam.md` are fixed, and I confirmed each one myself:

1. **Skips now match one exact package plus one exact test name.** A failing test that reuses a listed name in another package now fails the gate. An entry that is a pattern is refused before any test runs.
2. **Both actions are pinned to full commit SHAs**, and those SHAs are the targets of the official release tags (my own lookup, not the writer's).

The gate also held up under attack. Of 38 hostile probes, 37 behaved correctly. Build, vet, the self-check and the complete gate pass on the exact audited bytes in my own container, and the green runner run tested exactly the audited tree.

It is still blocked, for three reasons. Only the first is a defect I found. The other two come from applying the project rule of 2026-11-22 (no "revisit later"; a temporary edge needs a machine-enforced trigger) to items the writer deferred.

1. **One entry can still skip two tests (RF-1, new, low).** Go lets a package define the same test name twice: once in its internal test package and once in its external one. One list line then skips both. I ran it: the gate printed `[no tests to run]` and exited 0 with a failing test present. The fix is a one-line count.
2. **Nothing forces a list entry to go away (RF-2, rule).** A listed test that starts passing stays skipped forever, and the "non-blocking" step fails on every run, so it cannot signal anything. The only removal mechanism is a TODO sentence. This is the missing machine-enforced trigger.
3. **Six real checks in `es/app` are outside the gate (RF-3, rule).** Each of the two listed `es/app` tests has four subtests. On the runner exactly one fails in each. The other six pass, and a regression in them would not turn CI red. No trigger can stand in for this one, so it is either fixed or David accepts the loss.

Nothing here makes a merge dangerous to the repository: there is still no write path and no secret. As in the first audit, the block is about what a green check means.

**The `reliablesubmit` intermittent failure:** I could not reproduce it, so the question is not settled. On the same scratch merge, 73 whole-package runs (60 plain, 5 from an empty build cache, 8 under disk write load) all passed, and two complete runs under the race detector reported no data race. I did find one test in that package whose result depends on real time, and I made it fail on purpose: `TestSQLiteClaimStoreTwoHandlesBusyTimeoutAndHelperProcessContention` fails when its process stalls for about 275 ms at one point (6 of 20 runs with forced stalls, 0 of 420 without). That test is already on `trunk_dev`. Inference: a flaky test is the likelier explanation, not a race in the product code. Section 9 has the detail and what would settle it.

## 2. Audit target

| Field | Value |
|---|---|
| Repository | evo-agi/Execution-Substrate |
| Base | `trunk_dev` at `ae326b0ddc30ec6b35883ee32945c622405b68b6` (the tip of `origin/trunk_dev` when I opened and when I closed) |
| Topic branch | `claude/project-thread-sqldt7-ci` |
| Commits | `d886bb80feb160b6775f0ac1866ce69f7bdbfe47`, `145ab62001e488fea0cd4c4a002661df86ef9f95`, then the repair `fada999c6da5ed157c74033e1e975415c179c49d` |
| Tip tree | `c369dfd178d566667d1465e9e626ed8abe2d1684` |
| PR | #14, draft, head `fada999…`, base `trunk_dev` at `ae326b0…`, 6 files, +660/−3, `mergeable_state: clean` (GitHub API, read during this audit on 2026-11-22) |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified with `sha256sum -c` before each run) |
| Canonical manifest SHA-256 | `7c1406bfde7df1063a2ed1a46f7b2c2853823b6877cfd18677c5d89136b9d82d`, 1,446 bytes, 6 files (4 untracked new, 2 tracked_modified) |
| Textual diff SHA-256 | `c65fdafd8c8445a7baf703527554fea0f6825e5fcead797845e048bad2025367` |
| Writer report | `03-repair.md`, SHA-256 `8cfc48c28d86e7b913197cbb4285fd6fb519cf9b3bd992414fc6d9ecdce187d2` (what I read) |
| Prior audit | `02-audit-redteam.md`, SHA-256 `44bac0250ab6502b18178b08032bfd28964892b63a6d9b9a760f3993339b92c9` (what I read) |
| CI run audited | 44984626477, job 137092378502, event `pull_request`, head `fada999…`, conclusion `success`, runner image `ubuntu-24.04` version `20261116.376.1` |

## 3. Audit posture

- Read-only on the target. No edits, formatting, commits, pushes, PR comments, reviews or re-runs of the workflow.
- **Deviation from protocol §13.2 step 3:** no audit subagents. The change is six files, and this session's default is to avoid subagents unless asked. I covered the four perspectives myself (contract and authority, correctness, test adequacy, security).
- Every experiment ran in this thread's cloud container, on separate clones under `/home/ci/work/`, never in the audit clone. Nothing ran on GitHub, on David's Mac or on the Linux box.
- **One slip, corrected.** While exporting the tree for experiments I ran `git --work-tree=… checkout fada999 -- .` from the audit clone. That staged the tip's paths in the audit clone's index. It changed no working-tree byte. I restored the index with `git reset --mixed ae326b0…` straight away and used separate clones from then on. The closing manifest equals the opening one (section 12).
- Side effects in my container only (it is discarded with the thread): local user `ci`; packages `uuid-runtime`, `openssh-client`, `acl`, `locales` with `en_US.UTF-8` generated; a Go 1.26.5 copy under `/opt/go1.26.5`; clones and logs under `/home/ci`; one local merge commit of `e544e0f` and `fada999` for section 9, never pushed.
- Outbound reads beyond the repository: `git ls-remote` against `github.com/actions/checkout` and `github.com/actions/setup-go` (public tag lists), the Go module proxy, and Ubuntu package mirrors.

## 4. Provenance reproduction

Procedure: provenance §5.3, in the fresh clone at `/home/user/Execution-Substrate`.

```text
sha256sum -c  (recipe v2)                                              OK
git fetch origin trunk_dev claude/project-thread-sqldt7-ci
origin/trunk_dev                        == ae326b0ddc30ec6b35883ee32945c622405b68b6
origin/claude/project-thread-sqldt7-ci  == fada999c6da5ed157c74033e1e975415c179c49d   (pushed tip is the reported tip)
git merge-base --is-ancestor ae326b0… fada999…                                           (true)
git checkout -f -B claude/project-thread-sqldt7-ci fada999… ; HEAD^{tree} == c369dfd1… ; status clean
git reset --mixed ae326b0… ; git branch --set-upstream-to=origin/trunk_dev
python3 -I governed_execution_audit_patch_manifest_v2.py OUT/1.json   (and OUT/2.json)
```

- Two opening runs: byte-identical (`cmp`), manifest SHA-256 `7c1406bf…d82d`, `file_count=6`, textual diff `c65fdafd…5367`.
- `cmp` of my manifest against the manifest line in `03-repair.md` (line 248): identical.
- Mode bits: all six entries `0644` on both sides. No tolerated difference was needed.
- PR #14's head on GitHub is `fada999…`. I fetched `refs/pull/14/merge`: it is `8e3370a791f950754a7ac4dc26178cf21f206ba2`, parents `ae326b0…` and `fada999…`, tree `c369dfd1…`. The runner log shows that run 44984626477 checked out exactly `8e3370a` ("Merge fada999… into ae326b0…"). So the green run tested the audited bytes.
- Closing run after all experiments: section 12.

**Result: provenance holds.** No `AUDIT_PROVENANCE_MISMATCH`.

## 5. The two prior blockers, re-checked

| Prior finding | Result now | How I know |
|---|---|---|
| **F1** a listed name was skipped in every package | **Fixed** | `go_test_gate.py:161-169`: each package with entries runs alone with `-skip '^(its own names)$'`; all other packages run in one command with no `-skip`. My probe A1 (a failing test with a listed name in an unlisted package): exit 1, and the marker file shows that test ran. The committed self-check holds the same case (`go_test_gate_selftest.py:141-147`), and my mutants N11 and N12 (skip names shared across packages) are both killed by it. |
| **F2** entries acted as regular expressions | **Fixed** | `go_test_gate.py:42` with `fullmatch` at `:70`: a line must be exactly `<package> <Test…>` with the test name made of ASCII letters, digits and underscores. The package must be one of the lines `go list ./...` prints (`:125-128`), and the test must be printed by `go test -list` for that package (`:131-141`). Of 19 text and path tricks of mine (byte-order mark, NUL, CR-only line ends, U+2028, look-alike letters, trailing slash, dot segments, `all`, `...`, a leading dash), 17 were refused with status 2. The other two (E3 and E7) turned out to be legal lines that skip nothing extra, and the real failure behind them still failed the gate. Two grammar mutants of mine survive the self-check (a name may also hold `.` or `*`), but the existence check still refuses such entries; see 8.2. |
| **F6** actions pinned by tag | **Fixed** | `go.yml:41` and `:46`. My own `git ls-remote` on 2026-11-22: in `actions/checkout`, `refs/tags/v4` and `refs/tags/v4.4.0` are `11d5960a326750d5838078e36cf38b85af677262`; in `actions/setup-go`, `refs/tags/v5` and `refs/tags/v5.6.0` are `40f1582b2485089dde7abd97c1529aa768e1baff`. The runner log shows both actions downloaded at exactly those SHAs. This closes the uncertainty the first audit recorded. |

Also re-checked and unchanged from the first audit: `pull_request` (not `pull_request_target`); `permissions: contents: read` (runner log: `Contents: read`, `Metadata: read`); `persist-credentials: false`; no `secrets.*`; no `${{ }}` inside any `run:` script; `GOTOOLCHAIN: local` with Go from `go.mod` (runner log: `go version go1.26.5 linux/amd64`).

The concurrency change (prior F8) is correct by reading: `go.yml:21-22` gives a pull request the group `go-refs/pull/<n>/merge` with cancellation, and gives each push the group `go-<sha>` without cancellation. Not observed: a push run cannot happen before merge.

## 6. Findings

Severity scale: critical, high, medium, low, observation. "Patch defect" means introduced or left open by PR #14. "Pre-existing" means present at `ae326b0`.

### Patch defects

**RF-1. One entry skips two tests when its package defines the name in both its internal and its external test package**
- Type / severity: bug in the gate (test gap) / **low**. Required repair. New in this audit.
- Path: `.github/ci/go_test_gate.py:137-141` (the existence check uses set membership, so two definitions look like one), `:162`.
- Evidence: probe B1. Package `synth/a` holds `TestListed` in `package a` (the host-bound one) and another `TestListed` in `package a_test` (a real failing regression). `go vet` exits 0 on that layout and `go test -list '^(TestListed)$' synth/a` prints the name twice. With the single entry `synth/a TestListed`, the gate printed `ok synth/a [no tests to run]` and `test gate passed`, exit 0. Neither test ran. Control B2 (empty list): both run and the gate exits 1.
- Reach in the real tree: none today. All 16 listed names are defined exactly once in the whole module. The layout exists, though: `es/admission/internal/reliablesubmit` has 15 internal and 2 external test files, and it holds two entries.
- Impact: the repair's stated guarantee ("one exact package plus one exact test name") has one remaining hole of the same kind as F1: a test moved or copied between the two test packages of a listed package can vanish from the gate without any change to the list.
- Required correction: refuse an entry unless `go test -list` prints its name exactly once, and add that case to the self-check.
- Uncertainty: none on the mechanism.

**RF-2. No machine-enforced trigger removes a list entry (prior F3 second half and F5)**
- Type / severity: test gap, and a conflict with the project rule on temporary edges / **medium**. Required repair.
- Path: `.github/ci/environment-only-tests.txt:16-17` (the TODO), `.github/workflows/go.yml:78-82`, `.github/ci/go_test_gate.py:182-191`.
- Evidence:
  - Probe G3: a listed test that passes stays skipped, and the gate is green.
  - Probe G2: `environment-only` mode with one passing and one failing listed test gives exit 1 and no per-entry verdict.
  - Runner log: the step ends every green run with `##[error]Process completed with exit code 1`. It always fails, so it cannot signal.
  - The list depends on the host more than its comments suggest. In my container 5 of the 16 listed tests pass (the 3 runtime-security-boundary tests and the 2 `es/app` tests), because it has no `systemctl`, no modprobe block and no `/usr/bin/go`. The runner image is replaced regularly (this run used `20261116.376.1`). When an image change makes a listed test pass, nothing notices.
- Impact: an entry can outlive its reason. A test that was ported or started passing stays out of the gate, and a later regression in it is invisible. The list file itself calls the entries temporary ("TODO: port each test … then delete its entry"), so by the project rule it needs a machine-enforced trigger, not a sentence.
- Required correction: a blocking step that fails when any entry does not fail on the runner (it passes, skips itself, or does not run), naming the entry. That step replaces the always-red one. Section 11 has acceptance checks and an advisory sketch I ran.
- Consequence to accept knowingly: when a runner image change makes a listed test pass, CI turns red on every branch until that line is deleted. That is the trigger doing its job.

**RF-3. Six `es/app` subtests that pass on the runner are outside the gate (prior F4)**
- Type / severity: test gap / **low to medium**. Required repair, or an explicit acceptance by David.
- Path: `.github/ci/environment-only-tests.txt:52-53`.
- Evidence: the runner log of the audited run shows exactly one failing subtest in each test, `local_build_path_rejects_missing_Go_before_mutation`. Each test has four subtests (`es/app/operator_scripts_integration_test.go:1720`, `:1733`, `:1747`, `:1763` and `:1795`, `:1808`, `:1822`, `:1838`). Inference: the other three in each test pass on the runner, because `go test` without `-v` prints only failures and a failing subtest does not stop its siblings.
- Impact: the six are real, portable checks that the supported-local setup and proof scripts refuse a wrong Go before changing anything, accept the exact Go, and do not open a "no local Go" bypass. They no longer gate.
- Why the rule bites here: no trigger can cover this. A whole-test entry keeps failing, so even the RF-2 check stays green while the six stay out.
- Required correction: narrow the two entries to the failing subtest. Go accepts a subtest path in `-skip`, and with RF-2 built on `go test -json` the per-subtest verdict is available. My sketch ran both (section 11).
- The other partly passing listed tests are different. `…FailureWitnessBootstrapOwnedTerminal` (18 of 22 subtests fail on the runner) and `…RootLoadedStageCustody` (4 of 15 fail) have passing subtests that pass for the wrong reason on a host without the `ds` account (first audit, P-A). Keeping those two as whole-test entries is defensible. Say so in the list file, so it is a recorded decision.

**RF-4. The two changed tests have still not been run on macOS**
- Type / severity: validation gap / **low**. No byte change needed. Required before merge.
- Evidence: the first audit recorded this as open. `03-repair.md` section 10 says nothing from the repair runs on macOS and reports no Mac run. I re-ran the cross-compiled check: `GOOS=darwin go vet ./es/admission/ ./es/admission/internal/reliablesubmit/` exits 0 for arm64 and amd64 at `fada999`.
- Impact: `TestReplayExistingStateModeNotRepaired` and `TestRetainedResultAuthReaderNeedsVerifierEvenForExistingPair` ran on the Mac before this PR and have not run there since they changed. Type-checking is evidence, not a run.
- Required correction: one run on David's Mac at the PR head: `go test -count=1 -run 'TestReplayExistingStateModeNotRepaired|TestRetainedResultAuthReaderNeedsVerifierEvenForExistingPair' ./es/admission/...`. If the SPIRE test is ported (section 7, item 4), add it to the same run.

**RF-5. The self-check misses three regressions worth pinning**
- Type / severity: test adequacy / **low**. Recommended in the same repair. The gate code is correct on all three today.
- Evidence: 35 mutants of the gate against the committed self-check (8.2). 23 are killed. Of the 12 survivors, 3 matter:
  - **N35, scoping by package name instead of import path.** Entries of two listed packages with the same last path element are merged, and the self-check passes. The real module has five packages named `app` (`ags/app`, `ars/app`, `cgs/app`, `egs/app`, `es/app`), and `es/app` has entries. A self-check case with two packages of the same name in different directories would pin this.
  - **N26, `-count=1` removed.** The self-check cannot see it. It matters because the workflow restores a Go build cache, which also holds cached test results. A case that runs the gate twice in one module and requires the markers both times would pin it.
  - **N24, a failed `go list` exits 0.** No self-check case makes `go list` fail. I checked the real gate by hand: no module, a broken `go.mod` and an empty module each exit 1, and a missing `go` binary exits 1.
- The other 9 survivors are harmless (8.2).

**RF-6. Build and vet are answered from a restored cache (prior F9, now with numbers)**
- Type / severity: assurance trade-off / **observation**, with a recommendation.
- Evidence: runner log of the audited run. `actions/setup-go` restored a 302 MB cache ("Cache hit"), then `go build ./...` took 2 seconds and `go vet ./...` took 1 second. In my container, without that cache, the same steps took 28 and 10 seconds. Inference: on a cache hit the Build and Vet steps mostly replay stored results. Those results are addressed by content, so a wrong answer needs a planted cache entry, and GitHub scopes caches so that one pull request cannot write a cache another restores. The cache can still be written by any earlier run in the same scope, and test code runs with write access to it.
- Recommendation: set `cache: false` on `actions/setup-go`. `go mod verify` then checks freshly downloaded modules and everything compiles from source on every run. Guess: this adds one to two minutes to a six-minute job; one run would measure it. The project's priority rule (take the more certain path when the cost is time) points this way. If the cache stays, the report should say why.

**RF-7. Governing documents still do not mention CI (prior F10)**
- Type / severity: documentation gap / **observation**, with a recommendation.
- Evidence: `AGENTS.md` section 3 lists where authority lives; `.github/` is not in it. `.docs/system_overview/go_toolchain_baseline.md:101` says "no CI system introduced" and `docs_contract_test.go:959` pins that sentence, in the root package the gate runs. The sentence is scoped to the Go baseline change, so it is not false. But after merge, an agent that follows the authority order learns nothing about CI except that line.
- The stated reason for skipping it does not hold. `03-repair.md` says a `PLANS.md` entry would conflict with PR #12 and PR #13. Neither PR touches `go_toolchain_baseline.md`, and their hunks in `docs_contract_test.go` start at line 4044, far from the Go baseline test `TestGo1265ToolchainBaselineDocsAndBuildContract` at lines 859 to 1209 (`git diff ae326b0...e544e0f`).
- Recommendation: a short section in `go_toolchain_baseline.md` (CI exists, what it gates, that the list file is the single statement of what it excludes, and what it does not claim: no macOS run, no race detector, no Remote Alpha proof), with the pinned sentence adjusted in the same change.

**RF-8. Nits**
- `go_test_gate_selftest.py:242` holds a raw U+00A0 (no-break space) inside a string. It looks identical to line 230 in a diff or an editor. Write it as the escape `\u00a0` so a reviewer can see what the case tests.
- Nothing in the repository pins the workflow's own properties (SHA pins, the Test step calling the gate, no `continue-on-error` on it). A few lines in the self-check that read `go.yml` and require every `uses:` to end in a 40-hex SHA would make the F6 repair durable. Optional.

### Pre-existing issues (not defects of PR #14)

**P-F. A lock test in `reliablesubmit` depends on real time (observation; the proper fix is small)**
- Path: `es/admission/internal/reliablesubmit/sqlite_physical_test.go:149-234`. These lines are identical at `fada999` (PR #14 does not touch the file, so also at `ae326b0`) and in the scratch merge with PR #13's head.
- Mechanism: a helper process takes the database write lock, prints `locked`, sleeps 300 ms and rolls back (`:229-231`). The test then expects a write through a second handle with a 25 ms busy timeout to fail as "busy" (`:201-205`). If the test process loses about 275 ms or more between reading `locked` and starting that write, the lock is already free, the write succeeds, and the test fails with `busy contention error = <nil>`.
- Evidence: I stalled only the test process (SIGSTOP for 600 ms, SIGCONT for 60 ms, repeated; the helper is a separate process and keeps real time). 6 of 20 runs failed, each with exactly that message at `:204`. The control without stalls, on the same loaded machine, passed 20 of 20. Without stalls the test also passed 200 of 200 on a quiet host and 200 of 200 with 12 busy loops on 4 CPUs.
- Impact: the test can turn a run red with no defect in the code. It takes a stall that an ordinary busy host did not produce in 420 runs of mine, so it is rare. It is one candidate for the writer's unexplained failure, not a proven cause (section 9).
- Proper fix (test only): the helper holds the lock until the test tells it to let go, for example until its standard input closes, in place of the fixed 300 ms sleep. Acceptance: `flake_stall.sh` in the evidence folder passes 20 of 20 with stalls.
- It is not a defect of PR #14 and does not enter the verdict: the code is on `trunk_dev` and PR #14 does not touch it. Once PR #14 merges, CI runs this test on every pull request and push, so I recommend assigning the fix now, as its own small test-only change.

The first audit's P-A to P-E stand as written. I did not re-examine them, except to confirm one environment note: with `uuid-runtime`, `openssh-client`, `acl` and the `en_US.UTF-8` locale installed, and run as a non-root user with umask 022 and no proxy variables, the whole root package passes in a cloud container (twice, 157 s and 152 s). The three root tests the writer saw failing in its container are therefore container effects, as both earlier reports assumed.

## 7. The six deferred items against the project rule

The rule, from the project instructions: do not defer a fix with "revisit later"; prefer the proper fix now; if a temporary edge must remain, it needs a machine-enforced trigger tied to a concrete condition, never a prose note.

| # | Deferred item (prior ID) | Judgement | Reason | What settles it |
|---|---|---|---|---|
| 1 | Check that listed tests still fail (F3, second half) | **Blocking** | The list is this PR's temporary edge, by its own header. Its only removal mechanism is a TODO sentence. This check is the trigger the rule asks for, and it is cheap. | RF-2 |
| 2 | Subtest-level skips (F4) | **Blocking** for the two `es/app` entries | No trigger can stand in for it: the whole test keeps failing, so item 1 stays green while six passing checks stay out. It is fixed now, or David accepts the loss in words. The two root custody entries may stay whole, with the reason written in the list. | RF-3 |
| 3 | A signal from the non-blocking step (F5) | **Blocking**, same change as item 1 | A step that always fails and is always forgiven signals nothing, and it puts a red error line on every green run. Item 1 turns it into a step that is green when the list is right and red when it is not. | RF-2 |
| 4 | Port the SPIRE test (F7) | **Needs an enforced trigger; item 1 is that trigger** | Porting edits a root-package test that also runs on the Mac, so leaving it out of a CI change is defensible. It is only acceptable once the entry cannot outlive the port, which item 1 guarantees. I still recommend doing it in this repair: it is one line (`remote_alpha_operator_test.go:4022`, try GNU `stat -c '%a'` before BSD `stat -f '%Lp'`), the first audit ran it on Linux, and by reading it is safe on macOS because BSD `stat` rejects `-c` with no output and falls through. It needs one Mac run (RF-4). | Item 1, plus the writer's stated choice |
| 5 | Verify or drop the build cache (F9) | **Outside the rule; decide it now** | Not a temporary edge. It is a standing trade-off between speed and certainty, and the priority rule decides it. | RF-6: `cache: false`, or a stated reason to keep it |
| 6 | Record CI in the governing docs (F10) | **Outside the rule; do it now because it is small** | Nothing temporary and nothing false. But the reason given for skipping it does not hold, and the gap costs every later agent that reads the authority chain. | RF-7 |

Two things this table does not decide, because they are David's:

- **Nothing forces the ports themselves to happen.** Item 1 guarantees that a ported test leaves the list. It does not make anyone port. David allowed suppression as an alternative to porting, so I do not treat "not yet ported" as a deferred fix. If he wants the list to shrink by a date, that needs its own trigger, for example an expiry date per entry that fails the gate.
- **Two groups of entries cost more than the rest.** The two `reliablesubmit` entries are the "an older binary refuses a newer schema and changes nothing" checks for the reliable-submit store, which is the next unit of work; CI never runs them. And eight root entries pass on Linux when the test process runs as an account named `ds` with a `/private/tmp` directory (first audit, section 7), which a workflow could arrange without touching a test, and which would also make the gated custody tests reach the checks they are named for (P-A). Neither is part of this verdict.

## 8. Red-team log

Scripts and raw output are in `04-reaudit-evidence/` beside this report. Everything ran against the committed `go_test_gate.py` (SHA-256 `f071acd4…03a9`), as user `ci`, Go 1.26.5.

### 8.1 Probes (`redteam.py`, 38 probes)

Each probe builds a throwaway module, runs the gate as the workflow does, and records the exit status and which test functions really executed (marker files).

| ID | Attack | Exit | Outcome |
|---|---|---|---|
| A1 | Failing test with a listed name in an unlisted package (the old F1) | 1 | Held |
| **B1** | Listed name defined in both the internal and the external test package of the listed package | **0** | **Bypass (RF-1)** |
| B2 | Control for B1, empty list | 1 | Both tests run and fail |
| C1 | Entry names no test; `TestMain` prints the name on standard output | 0 | The existence check is satisfied by a printed line. Harmless: the entry skips nothing. RF-2 would catch it, because the entry never runs |
| C2 | Listed test exists only under a build constraint that is off | 2 | Refused |
| C3 | Entry `TestMain` | 2 | Refused |
| D1 | Failing fuzz seed in a listed package | 1 | Held |
| D2 | `init` panic in a listed package whose only test is listed | 1 | Held |
| D3 | Listed test called as a subtest of an unlisted test | 1 | Held: it runs and fails |
| D4 | Vet error in a listed package's test file | 1 | Held |
| E1 to E18, E20 | 19 text and path tricks: byte-order mark, NUL, form feed, U+2028, CR-only line ends, look-alike letters, trailing or doubled slash, dot segment, upper-case path, `fmt`, `-run`, `all`, `...`, an entry for a package that lacks the test, a 70,000-character name | 2, or 1 where the trick is legal and a real failure remains (E3, E7) | Held |
| E19 | A second, legal entry that hides a real failing test | 0 | Works as designed. It is a visible edit of the list, which is a review matter |
| E21 | List file is a symlink to `/dev/null` | 1 | Fails safe: nothing is skipped |
| E22 | List path is a directory | 2 | Refused |
| F1 | Failing tests under `testdata/`, `_hidden/`, `.dot/` and a nested module | 0 | Not run, exactly as with `go test ./...`. The real tree has none of these (one `go.mod`, no `go.work`, no test file under such a directory) |
| F2 | Package with only an external test file, failing | 1 | Held |
| F3 | Syntax error in a non-test file | 1 | Held |
| G1 | `environment-only` with the B1 layout | 1 | Both tests run |
| G2 | `environment-only` with one passing and one failing listed test | 1 | No per-entry verdict (RF-2) |
| G3 | `gate` with a listed test that now passes | 0 | Stale entry is invisible (RF-2) |

By hand, outside the script: the gate exits 1 when run outside a module, with a broken `go.mod`, in a module with no package, and when `go` is not on `PATH` (Python traceback, exit 1).

The writer's red-team questions (`03-repair.md` section 11):

- *Can a list line skip a test outside the named package, or more than one test?* Outside the package: no. More than one: yes, in the B1 layout (RF-1).
- *Can the existence check be satisfied by something other than a real test?* Yes, by any line the test binary prints while listing (C1). It gains nothing.
- *Does a failure anywhere always produce a non-zero exit?* Yes in every case I tried: a failing package with or without entries, a compile error, a vet error, an `init` panic, a failed `go list`, a failed `go test -list`, a missing `go`.
- *Can the self-check pass while the gate is broken in a way the eight breakages did not cover?* Yes, in the three ways of RF-5.
- *Are the pinned SHAs the commits the comments say?* Yes (section 5).

### 8.2 Mutants (`mutants.py`, 35 mutants plus a control)

Each mutant is one deliberate breakage of the gate, run against the committed self-check. "Killed" means the self-check failed.

- **Killed, 23:** N1, N3, N5 to N16, N18, N21, N23, N25, N28 to N32. These cover prefix matching, `|` in a name, stripped lines, trailing comments, `splitlines`, repeated entries, lost anchors, skip names shared between listed packages, skip names applied to unlisted packages, unlisted or listed packages not run, ignored failures, package patterns, list errors or a failed gate exiting 0, invalid UTF-8, indented comments and blank-looking lines.
- **Survived, matter (RF-5):** N35 (scoping by package name), N26 (`-count=1` removed), N24 (a failed `go list` exits 0).
- **Survived, harmless:**
  - N2 and N4 (a test name may also hold `.` or `*`). I ran both mutants with the entries `TestListe.` and `TestListed*`: the existence check still refuses them with status 2, because no Go test name holds those characters. The two layers overlap.
  - N19, N20 and N22 weaken only the existence or package check (a prefix of a defined name is accepted, only the first listed package is checked, a prefix of a package path is accepted). None widens a skip. N22 is then stopped by the gate's own sum check.
  - N17 (only status 1 counts as failure for a listed package). `go test` exits 1 for test and build failures; the difference shows only if `go` is killed by a signal.
  - N33 and N34 are equivalent: a later check or run fails anyway.
  - N27 (`environment-only` loses its anchors) affects only the non-blocking step.

**Coverage the environment could not provide:** no run on a GitHub runner of my own (I may not push or re-run; I read the log of run 44984626477 instead); no macOS run; no systemd host; no fork pull request; no view of branch protection or Actions settings; no push-triggered run.

## 9. The `reliablesubmit` intermittent failure

**What the writer reported** (`03-repair.md` section 9). On a scratch merge of PR #13's head `e544e0f` with the repair bytes, the first run of the `reliablesubmit` package with three names skipped exited 1. The output had been cut to its last lines, so the failing test is not known. The next 21 runs of the same command passed.

**What I ran.** I rebuilt the same merge locally and never pushed it: parents `e544e0f` and `fada999`, tree `e9066a73093f8bf03aa67abd7e024b5502da6d53`, no conflict. Same package, same three names skipped, Go 1.26.5, 4 CPUs, non-root user. I kept the full output of every run.

| Runs | Conditions | Failures |
|---|---|---|
| 60 | Whole package, prebuilt test binary, three loops in parallel while my mutant script was also running | 0 |
| 5 | Whole package through `go test`, each time from an empty build cache (compile, link, run), while the disk-load and race-detector runs were also going. Each took 174 to 230 s, against 26 s for this package at `fada999` in my gate run on an otherwise idle container | 0 |
| 8 | Whole package while two processes kept rewriting and syncing 600 MB files on the same disk | 0 |
| 2 | Whole package built with the race detector, complete runs | 0, and no `DATA RACE` report |
| 1 | Whole package with the test process stalled for 600 ms out of every 660 ms (1,116 s in all) | 0 (120 tests passed, 2 helper tests skipped themselves) |
| 420 | The lock test of P-F alone: 200 quiet, 200 with 12 busy loops on 4 CPUs, 20 as the control for the next row | 0 |
| 20 | The lock test of P-F alone, with the test process stalled for 600 ms out of every 660 ms | **6**, all `busy contention error = <nil>` |

One more race-detector run did not finish: my own 10-minute limit stopped it while the other loads were running. It was not a hang. The test in progress had been running for 1 second and its goroutine was executing inside the SQLite parser. I repeated the run with a longer limit and it passed; it is the second of the two complete runs above.

**What this shows.**

- **Not reproduced.** 73 ordinary whole-package runs passed. If the code failed about once in 22 runs on any host, 73 clean runs would have had about a 3% chance (0.955 to the power 73). So either the real rate is well below what one observation suggests, or the failure needed something the writer's container had at that moment and mine did not. With no failure in 73 runs, the 95% upper bound for my conditions is about 4% per run (3 divided by 73).
- **No data race in the Go sense** on the paths these tests execute: two complete race-detector runs were clean. The race detector does not see races between processes or logic races that go through the database, and those are what this package is about. So this narrows the question and does not close it.
- **One test is time-dependent beyond doubt** (P-F). It fails with no defect in the code when its process stalls for about 275 ms at one point. Guess: it is the likeliest single candidate, because the writer's failing run was the first of a series, in a container that had probably just been building and testing, which is when a stall is most likely.
- **The other real-time windows in the package are much wider**, by reading: 2 s read deadlines (`replay_custody_file_test.go:549` and `:636`), 5 s (`replay_progress_test.go:1242-1295`), 8 s helper re-executions (`replay_custody_file_test.go:1249` and `:1400`) and 15 s (`:1560`). All of these are on `trunk_dev` too. The only timing test that exists only on the PR #12 side is `operational_handoff_test.go:626` (a context blocked for 80 ms), and by reading, slowness cannot fail its first assertion. None of them failed in the whole-package run with forced stalls.
- **Randomness is not a plausible cause.** The product code draws random values in `operational_handoff.go:270-276` and rejects only an all-zero 32-byte value (`:123-131`), which will not happen in practice.

**Answer to the question in the brief: Unknown.** Inference: a flaky, time-dependent test is more likely than a race in the product code. The reasons are the 73 clean runs, the clean race-detector runs, and one test that demonstrably fails from timing alone. Not excluded:

1. a logic race in the PR #12 or PR #13 code that shows up less often than once in about 70 runs;
2. a different time-dependent test that needs a longer or differently placed stall than the one I forced;
3. a failure that was not a test at all, for example a build or link step killed in a busy container. `go test` exits 1 for that as well, and the output was lost. This one is a guess.

**What would settle it.**

- **The next occurrence, with its output.** The CI gate prints the whole `go test` output and does not cut it. Once PR #12 carries this workflow, a recurrence on the runner names the test. For local runs: write the full output to a file, never only its last lines.
- **Fixing the lock test as in P-F.** If the writer's failure was that test, it cannot recur. If a failure recurs afterwards, it is something else, and the log will name it.
- **For the PR #13 audit and red team:** this hunt found nothing against the PR #12 and PR #13 code, and it does not clear that code either.

Scripts and raw results: `flake_*.sh.txt`, `flake-output.txt` and `flake-stall-sample-failure.txt` in the evidence folder.

## 10. Validation assessment

**Re-run by me on the exact audited bytes** (a clone at `fada999`, tree `c369dfd1…`, per-file SHA-256 equal to the manifest), in my container, linux/amd64, Go 1.26.5 with `GOTOOLCHAIN=local` and `GOFLAGS=-mod=readonly`, as non-root user `ci`, umask 022, no proxy variables during tests:

| Command | Result |
|---|---|
| `go mod download && go mod verify` | `all modules verified` |
| `go build ./...` | exit 0 (28 s) |
| `go vet ./...` | exit 0 (10 s) |
| `GOOS=darwin go vet ./es/admission/ ./es/admission/internal/reliablesubmit/` (arm64 and amd64) | exit 0 |
| `gofmt -l` on the two changed test files; `git diff --check ae326b0 fada999` | clean |
| `python3 -I -B .github/ci/go_test_gate_selftest.py` | exit 0, 20 checks (three runs: 15 s, 14 s, 17 s) |
| `python3 -I -B .github/ci/go_test_gate.py gate .github/ci/environment-only-tests.txt` | **exit 0**: `test gate passed: 41 packages, 3 of them with skipped entries (16 entries)`, 21 `ok` lines, 20 `[no test files]`, 310 s. The clone was clean afterwards |
| `… environment-only …` | exit 1, as designed. In my container 11 of the 16 fail (9 root, 2 `reliablesubmit`) and 5 pass |

An earlier run of the same gate exited 1 on one `es/app` test, `TestLinuxSetupGoToolchainInstallerHermeticPreflightAndCleanup`. That was my harness: I had started it under `nohup`, which leaves SIGHUP ignored, and the installer script under test refuses to run with a pre-existing HUP trap ("pre-existing HUP trap prevents Go archive installation"). With default signal handling the package passes (twice: 100 s and 96 s). I mention it so nobody else loses time to it.

**Not re-run:** the workflow on a GitHub runner. For that I rely on the log of run 44984626477, which I read myself rather than taking the summary in `03-repair.md`. It matches the writer's account: token `Contents: read`; both actions at the pinned SHAs; checkout of merge commit `8e3370a`; `go version go1.26.5 linux/amd64`; `Ran 20 tests in 10.935s`, `OK`; three existence checks; `ok` for the root package (133.1 s), `es/app` (98.8 s), `reliablesubmit` (24.4 s) and 18 more packages; `test gate passed: 41 packages, 3 of them with skipped entries (16 entries)`; then the non-blocking step failing on exactly the 16 entries. It is still one green run of this tip.

**The two test-file changes** are unchanged since the first audit (their SHA-256 values in the manifest equal the ones in the first audit's manifest, by the unchanged textual-diff hash). I re-read both. They are correct and neither weakens a test.

**The writer's validation claims I did not reproduce:** the eight deliberate breakages M1 to M8 (I ran my own 35 instead; N11, N12, N15, N16 and N18 overlap M1, M5 and M6), and the old-gate reproduction in 7.1.

## 11. What a repair has to show

Acceptance checks for the next audit:

1. **RF-1.** An entry whose name `go test -list` prints more than once is refused with status 2. The self-check holds that case. Probe B1 exits non-zero.
2. **RF-2.** A blocking step fails when any entry does not fail on the runner: it passes, it skips itself, or it never runs. The message names the entry. No step in a green run ends with an error annotation. The self-check holds a passing listed test, a self-skipping listed test and a failing listed test. Probes G2 and G3 exit non-zero.
3. **RF-3.** The six `es/app` subtests run in the gating step: the entries name the failing subtest, the self-check shows that a failing sibling of a listed subtest fails the gate, and the runner log shows the siblings ran.
4. **RF-5.** The self-check kills N35, N26 and N24, or the report says why not. `mutants.py` is in the evidence folder; its text substitutions will need adjusting to the new gate.
5. **RF-4.** One Mac run of the changed tests at the new PR head, with its output.
6. **Items 4 to 6 of section 7** each end in a change or a stated reason, with no "later".

**Advisory sketch (I ran it; it is not a patch).** `xfail_sketch.py` in the evidence folder extends the entry grammar to `<package> <TestName>[/<subtest>…]`, builds the skip pattern as `^Name$` or `^Name$/^subtest$` alternatives joined by `|`, and reads per-entry verdicts from `go test -json`. On a throwaway module with Go 1.26.5:

- with the entries `TestWholeEnvOnly` and `TestPreflight/rejects_missing_Go`, the gating run executed the three sibling subtests and exited 0, and both entries had the verdict `fail`;
- when a sibling subtest regressed, the gating run exited 1;
- with the whole `TestPreflight` listed (today's granularity), the same regression left the gating run at exit 0;
- a listed test that passes had the verdict `pass`, one that skips itself had `skip`, and a subtest that does not exist had no verdict. All three are entries the new step would reject.

Not established by the sketch: behaviour on the real tree or on a runner, and subtest names that hold characters outside letters, digits, `_` and `-`.

A repair changes the bytes, so it needs new provenance and a fresh audit of the whole base-to-tip range (provenance §5.5).

## 12. Closing state

- **Closing manifest, 2026-11-22 05:42Z, after every experiment had finished.** The recipe hash verified again. `git fetch` showed `origin/trunk_dev` still at `ae326b0…` and the topic branch still at `fada999…`. The audit clone had HEAD at `ae326b0…`, upstream `origin/trunk_dev`, nothing staged and no stash. Two closing runs were byte-identical to each other and to the opening manifest (`cmp`): SHA-256 `7c1406bfde7df1063a2ed1a46f7b2c2853823b6877cfd18677c5d89136b9d82d`, 1,446 bytes, 6 files.
- No experiment wrote to the audit clone's working tree. The one index slip is described in section 3.
- Nothing was pushed, commented, reviewed, re-run or merged. At close, PR #14 is open, draft, head `fada999…`, base `ae326b0…`, last updated 04:27:34Z (before this audit started), with one check run, `build, vet and test`, concluded `success`.
- Leftovers exist only inside this thread's container, which is discarded with the thread: the local user, the packages, the clones and logs, and a local merge commit `06867c8` that exists nowhere else. Under `/mnt/project-files` I wrote this report and its evidence folder, and nothing else.

## 13. Unknown, and what would settle it

- **Unknown: whether "build, vet and test" is a required status check on `trunk_dev`.** I cannot read branch protection. Unless it is required, the workflow informs and does not gate. David can see it in the repository's branch or ruleset settings. The coordinator's merge gate can also check the run's conclusion for the PR head directly.
- **Unknown: whether fork pull requests need approval before workflows run.** It is a repository Actions setting.
- **Not observed:** a push-triggered run, a second green run of this tip, any run from a fork, any run on macOS.
- **Guess:** the cost of `cache: false` (RF-6). One run would measure it.
- **Inference, not observation:** that the six `es/app` sibling subtests pass on the runner (RF-3). A run of those two tests with `-v` on the runner would confirm it.
- **Unknown: what failed in the writer's one bad `reliablesubmit` run, and so whether it was a flaky test or a real race.** Section 9. The next occurrence with full output settles it, and the lock-test fix in P-F removes the likeliest candidate.

## 14. Sensitive-material handling

No secrets, keys, tokens or environment files were read or copied. The runner log masks the token as `***`. Signed log-download URLs are not reproduced here. The evidence folder holds only my scripts, their output on throwaway modules, and test names, messages and timings from the flake hunt. This report contains no personal data.

## 15. Confidence

- **Provenance: high.** Reproduced twice at opening and twice at closing, byte-identical, equal to the report; the CI merge commit has the audited tree.
- **Validation: high.** I ran build, vet, the self-check and the complete gate on the exact bytes, and read the runner log. The runner result is still one run.
- **The intermittent `reliablesubmit` failure: low.** Not reproduced. The explanation in section 9 is an inference.
- **Implementation: high for what the repair covers** (package scoping, literal entries, pins, failure propagation). **Not acceptable yet** for RF-1, and for RF-2 and RF-3 under the project rule, which is why the verdict is BLOCK.

## 16. Report delivery

Path: `/mnt/project-files/reports/Execution-Substrate/ci-go-workflow/04-reaudit.md`. Its SHA-256 is given in the delivering thread reply. Evidence: `/mnt/project-files/reports/Execution-Substrate/ci-go-workflow/04-reaudit-evidence/`.

**Final verdict: BLOCK**
