# Evidence for `08-audit.md`

Fresh correctness audit of Execution-Substrate PR #14 at `b39fa35d444a4bd87a3901287bb6a346577c81b9`, 2026-11-22 (UTC). Everything here was produced by the audit thread in its own cloud container. Nothing in this folder was run against a live service, and nothing was pushed. Scripts carry the extra suffix `.txt` so that nothing here can be run by accident.

The report says which claim each file supports. Paths inside the logs (`/home/ci/...`, `/opt/go1.26.5`, `/home/user/audit8/...`) are paths in the audit container.

The folder was scanned before delivery for e-mail addresses, phone numbers and key material. It holds none. The runner log shows the checkout token only as `***`.

## Provenance

| File | What it is |
|---|---|
| `manifest-open.json`, `manifest-close.json` | v2 manifest of PR #14 at the start (13:06:53) and at the end (14:32:58) of the audit. Byte-identical, SHA-256 `a41367f9cd702a23d627ba1670fd64a54ce1f9b7e43bcda380b06d200ae0108e`, and equal to `07-repair-evidence/manifest-cumulative.json`. |
| `runner-run-45021679869-job-137205773120.log` | The runner log of the green run at `b39fa35`, downloaded by the audit thread through the GitHub API. Equal to the writer's copy in `07-repair-evidence/` except for the last line end. |
| `action-tags.log` | `git ls-remote --tags` of `actions/checkout` and `actions/setup-go` for the two pinned commits. |

## Container setup

| File | What it is |
|---|---|
| `container-env.sh.txt`, `container-run.py.txt`, `container-asci.sh.txt` | The environment of every run, and the wrapper that runs a command as the unprivileged user `ci` with an empty environment. |
| `container-fullgate.sh.txt` | Runs the step "Test" and the step "Listed tests still fail" on a tree, as the workflow does. |
| `jobA.sh.txt`, `jobA-status.txt` | The first batch of runs and its status lines with times. |
| `jobB.sh.txt`, `jobB-status.txt` | The second batch. **Two status lines are misleading:** the lines `self-check on the gate of c4a84f5 … exit 0` and `… af51f86 … exit 0` print the exit status of a hash command in the script, not of the self-check. The two logs end with `FAILED`. |

## The gate and the self-check on the exact bytes

| File | What it is |
|---|---|
| `validation.log` | `go mod verify`, build, vet, gofmt, the docs contract test, `git diff --check`. |
| `selfcheck.log` | The committed self-check: `Ran 90 tests`, `OK`. |
| `real1-status.txt`, `real1.gate.log`, `real1.still.log` | The whole gate (exit 0) and the still-failing step (exit 1 in a container, three entries pass there) on a clean clone at `b39fa35`. |
| `list-12.txt`, `real.still12.log` | The still-failing step with the 12 entries that fail in a container: exit 0. |
| `selfcheck-go1.24.7.log` | The committed self-check with Go 1.24.7 first on `PATH`: 43 failures in 33 checks, each with the gate's message. |
| `selfcheck-on-gate-c4a84f5.log`, `selfcheck-on-gate-af51f86.log` | The committed self-check against the two older gates: 39 failures in 34 checks, and 23 failures in 20 checks. |

## The planted fault and the workflow hold

| File | What it is |
|---|---|
| `plant-status.txt`, `plant.gate.log`, `plant.still.log`, `plant.still12.log` | The last audit's planted subtest P-d (`06-reaudit-evidence/plant-d.diff`, unchanged) on a scratch clone at `b39fa35`: the step "Test" exits 1 and names it, and so does the third step. |
| `wf7.log` | The writer's 21 workflow edits and one control (`07-repair-evidence/wf7.py.txt`, unchanged). |
| `aud8_hold.py.txt`, `aud8_hold.log` | Ten edits of my own: the gate's two constants, the workflow hash, the workflow text, `go.mod`. |

## Probes on throwaway modules

| File | What it is |
|---|---|
| `rt6.log`, `rt6b.log`, `rt6c.log` | The last audit's probe files (`06-reaudit-evidence/rt6.py.txt`, `rt6b.py.txt`, `rt6c.py.txt`, unchanged) against the gate of `b39fa35`. |
| `s12.log`, `cache-check.log` | The writer's S12 module and build cache experiment (`07-repair-evidence/s12.sh.txt`, `cachecheck.sh.txt`, unchanged). |
| `aud8_diff.py.txt`, `aud8_diff-seed8.log`, `aud8_diff-seed9.log` | The differential check: 40 and 160 random modules, the dropped tests found from marker files without the gate's recorder, then compared with what the gate reports. 0 mismatches. |
| `aud8_probes.sh.txt`, `aud8_probes.log` | Probes B (a real Go 1.24.7), K (a copied and a linked Go root), P (240 concurrent neighbours), E (example, benchmark, fuzz target), M (`TestMain` calls `m.Run` twice), G (`-overlay` in `GOFLAGS`). |
| `aud8_probes-first-run.log` | The first run of that script. Probe B2 had a list that failed for an unrelated reason, and it was corrected before the run above. Kept for the record. |
| `aud8_patchrelease.sh.txt`, `aud8_patchrelease.log` | Finding A8-F1: a go command that reports `go1.26.6`, against the committed gate and against mutants H1 and H2. |
| `aud8_m1list.sh.txt`, `aud8_m1list.log` | Observation A8-O5: `go test -list` prints a test name twice when `TestMain` calls `m.Run` twice. |
| `aud8_overlaydiff.sh.txt`, `aud8_overlaydiff.log` | What the gate adds to `src/testing/match.go`, as a diff. |
| `go-source-reading.log` | The lines of the Go 1.26.5 source that section 5 of the report cites. |

## Mutants

| File | What it is |
|---|---|
| `mutants4.log` | The writer's 139 mutants and one control (`07-repair-evidence/mutants4.py.txt`, unchanged) against the committed self-check: 134 killed, 5 survive. |
| `aud8_mutants.py.txt`, `aud8_mutants.log` | My own 37 mutants and one control: 34 killed, 3 survive (H1, H2, H4). |

## SHA-256 of every file

See `SHA256SUMS.txt`.
