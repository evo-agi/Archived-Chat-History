# REPAIR REPORT 5: Execution-Substrate Linux CI (PR #14), only a reported failure keeps a test in the list

**Verdict:** REPAIR_COMPLETE for the bytes. Ready for the narrow audit of `aaef28f..8eefe6d`. Nothing in this report waits for a decision by David. Two things outside the repair are for the coordinator (7.8): `trunk_dev` moved during the runner run, and one test of the root package failed once on timing.
**Effect status:** TOPIC_BRANCH_PUSHED (fast-forward, no force) · DRAFT_PR_UPDATED https://github.com/evo-agi/Execution-Substrate/pull/14 · CI_GREEN_ON_RUNNER (run 45064532285 at `8eefe6d`, the first run of these bytes) · PR_16_NOT_TOUCHED · MERGE_NOT_PERFORMED · INDEPENDENT_AUDIT_NOT_PERFORMED on the new bytes · RED_TEAM_NOT_PERFORMED on the new bytes · MAC_RUN_NOT_PERFORMED on the new bytes · BRANCH_NOT_UPDATED after `trunk_dev` moved to `b8d6bc3` during the runner run (7.8)

This report adds to `08-repair.md`, which stays the report for everything up to `aaef28f`. It answers the one finding of `09-audit.md` (ACCEPT with one low finding, SHA-256 `45ac805326f4106622feb1ca229e35500eedf21aa00b25c6f3dd43cc1eb10115`, which is the hash of the file I read). The repair is one commit on top of the audited `aaef28f`.

All times are UTC on 2026-11-22.

## 1. What was repaired, in short

**A9-F1 (low): a package run that something outside the list stopped was taken as the failure of the listed test that was running.** The step "Listed tests still fail" runs every listed package once with nothing skipped. At `aaef28f` a listed test that had started and had no verdict counted as failing whenever `go test` failed. So when a test that is not listed ended the process, or panicked, or when the time limit of `go test` hit, while one listed test was running, the step passed and said of that test that it fails in the run of its package. The run had not shown that. The test might have passed there.

**The new rule has two parts.**

1. **An entry fails in a run only if the testing package reported its failure.** That is a `t.Fatal`, a `t.Error` or a panic of the test itself. A test that was running when the test binary stopped has reported nothing, so it is not seen failing. This holds for the run of the package and for the `go test` of the entry alone.
2. **The run of a package has to come to its end.** A listed test that panics reports its failure and ends the process. The package then runs again without it, until a run comes to its end. A run that stops and that no listed test accounts for fails the step, whatever the entries reported before.

**What that closes.** All five cases of the audit now fail the step: R1, R1p, R7, R8, and also R3, which the audit expected to remain as a stated bound. I ran the audit's probe files unchanged against the new gate (7.2).

**What it costs.** A test that ends the process without reporting, for example with `os.Exit` or `log.Fatal`, can no longer be listed. None of the 15 entries is such a test: on the runner all 18 runs of the third step at `aaef28f` end with the testing package's own line `FAIL`, so every entry reported its failure (section 3). The audit's control R6 (the listed test itself ends the process) now fails the step. The audit named that as the safe side.

**One thing is stricter than the audit asked.** The audit's probe R5 expected exit 0: the only entry fails, and after it a test that is not listed ends the process. The step now fails there, because the run of the package was stopped. The coordinator's assignment asked for exactly that: "a killed/timed-out run must fail the step". The step "Test" fails on the same module in any case.

**Two things came up that are not part of the repair** (7.8). PR #17 was merged while the runner run was going, so the green run is of the merge with the old `trunk_dev`. The merge with the new one is clean, and both gate steps pass on it in the container. And one test of the root package, which neither pull request touches, failed once in the container on a two-second bound of its own.

**Also fixed:** the misplaced comment of A9-O4. **Not changed:** A9-O2 (the message for a skip that cannot be listed), which the assignment did not ask for (section 5).

## 2. Target identity

| Field | Value |
|---|---|
| Repository | evo-agi/Execution-Substrate |
| Base ref and SHA | `ae326b0ddc30ec6b35883ee32945c622405b68b6`. `trunk_dev` was there when the manifests were taken and after the push. **It moved at 20:20:05, while the runner run was going:** PR #17 was merged, and `trunk_dev` is now `b8d6bc3abb8c8c38481c7835824bd79ba26e467b`, one commit on `ae326b0`. `ae326b0` is still the merge base of the branch. The branch was not updated (7.8) |
| Topic branch | `claude/project-thread-sqldt7-ci` |
| Last audited tip | `aaef28f36f393e78f832a9caa745edeb02565a6c` (audit ACCEPT with A9-F1) |
| This repair | one commit: `8eefe6d309c64ec33295dce089e57927129f52e1` |
| Tip tree | `c3e784d20d3311650bfa91358d4113430dff4ca8` |
| Draft PR | #14, base `trunk_dev`, now 9 files, +5381/−9. This repair against `aaef28f`: 6 files, +623/−194 |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified with `sha256sum -c` before each run |
| Manifest upstream | `origin/trunk_dev` |
| **Repair-only manifest (the delta since the last audited tip; the narrow audit reads this one)** | `1cb462368c4427615108e2c27c852452a69bcd84c458ad585a51e00e0b838ccf` (1,448 bytes), HEAD `aaef28f`, 6 files, all tracked_modified; textual diff `4cf25bd3af4294bf2d4d02ffc5e9b11c707f5f4c2f2cd37e59107cd19c8135d4` |
| Cumulative manifest | `c16bda47d4a1cd7dee849bb6e0cc607bfac74be085ef434ba854d36f1f34b839` (2,035 bytes), HEAD `ae326b0`, 9 files: 4 untracked new, 5 tracked_modified; textual diff `35efc396dbeadf52c8b90040c9a43d5e0a36442881a291aabf1c3c89d978c03e` |

Each manifest was taken twice before the commit, and the two files were byte-identical (`cmp`).

**Auditor reproduction:** provenance §5.3 with `BASE=ae326b0ddc30ec6b35883ee32945c622405b68b6`, `TOPIC=claude/project-thread-sqldt7-ci`, `TIP=8eefe6d309c64ec33295dce089e57927129f52e1`, and the upstream pinned with `git branch --set-upstream-to=origin/trunk_dev`. I ran that in a fresh clone from GitHub after the push. With HEAD at `aaef28f` it gave the repair-only manifest and with HEAD at `ae326b0` the cumulative manifest, both byte-identical to mine (`cmp`). I ran it a second time in another fresh clone at 20:49, after `trunk_dev` had moved to `b8d6bc3`: both manifests are again byte-identical. A manifest holds the name of the upstream, not its commit, so the move does not change it. `BASE` has to be given as the SHA above, not as `origin/trunk_dev`.

Final working-tree status after the commit: clean (`git status --porcelain` empty). Before `git commit` a script checked that the staged set equalled the set of the repair-only manifest (6 paths) and that the bytes of the working tree equalled the hashes in it.

PR #16 (`claude/project-thread-k69qcw` at `0a069ecbe53c842d33c932f63aed2af523e2eb0c`) is unchanged.

## 3. Reconnaissance

Read before any edit: `09-audit.md` section 7.1 and its probe files, the functions `judged`, `in_the_run_of_its_package` and `still_failing` of the gate, the group `ListedTestsMustStillFail` of the self-check, section 10 of `.docs/system_overview/go_toolchain_baseline.md` with its hold in `docs_contract_test.go`, the header of the list and the comment of the third step in `go.yml`. `AGENTS.md` and `PLANS.md` have no rule for CI beyond what `07-repair.md` and `08-repair.md` recorded. The change touches no service contract and no reopened seam.

**What `go test -json` reports, on Go 1.26.5.** These are the facts that the rule rests on. Each is held by a check of the self-check that runs a real `go test`.

- A run that reaches its end has one line `PASS` or `FAIL` from the testing package that belongs to no test.
- A test that fails with `t.Fatal` or `t.Error` gets the verdict `fail`.
- A test that panics gets the verdict `fail`, and so does every test above it. The process ends, and the closing line is missing. No other test gets a verdict from that panic: not a test that runs beside it, not a sibling, not a subtest that waits.
- A test that ends the process (`os.Exit`) gets no verdict. No test does.
- When the time limit of `go test` hits, no test gets a verdict.
- With `-json` a subtest reports when it finishes, not when its parent does.

**No entry depends on the old rule today.** In the runner log of the run at `aaef28f` (job 137282573571) the third step makes 18 runs: one for each of the 3 listed packages and one for each of the 15 entries. Each of the 18 ends with the line `FAIL` of the testing package. The log has no `panic:`, no `test timed out` and no second run of a package. So every entry reported its failure, alone and in its package, and the new rule changes nothing for today's list. The run at the new head confirms it (7.6).

## 4. Implementation decisions

Order of work: doc and its hold, list header and workflow comment, self-check, gate. All land in the one commit.

### 4.1 Only a reported failure counts

`judged(path, result)` no longer takes the exit status of `go test`. It returns the verdict that the testing package reported. A test that started and has none is `waiting` (it had paused to run in parallel) or `unfinished` (it was running). Neither counts as failing. Before, `unfinished` did not exist: such a test counted as `fail` when `go test` failed.

**Why this rule and not the one the audit sketched.** The audit proposed to look at every test of the event stream, listed or not, to find out what stopped the run, and to state R3 as a bound because a leftover goroutine leaves no trace there. I considered that and chose the simpler rule for three reasons.

- It needs no theory about what stopped the binary. A test without a verdict has not shown a failure, whatever happened around it. That covers a cause that leaves no trace (R3) without a stated bound.
- It is the rule the coordinator's assignment states: "the listed test must be seen failing on its own assertion".
- Its cost is small and visible. A test that ends the process cannot be listed. The step names such a test and says why: `it reported no failure: the test binary stopped while it ran, and only a failure that the testing package reports counts`. The fix for such a test is in the test: fail through `t.Fatal`.

### 4.2 The run of a package has to come to its end

A run "comes to its end" when the testing package writes its closing line. A run that does not was stopped.

**Which listed test accounts for a stop.** A panic reports the test as failed and ends the process, so nothing starts or goes on after that report. A listed test accounts for the stop of a run if it has the verdict `fail` in that run and reported it after the last test had started or gone on. That is the rule of `aaef28f` for a panic, unchanged. What is gone is the second way to account for a stop: "it was running and has no verdict".

**The next run.** When listed tests account for the stop, the package runs again with `-skip` for them and for those of the earlier runs. That run judges the entries that have no verdict yet. This repeats until a run comes to its end. Each further run leaves out at least one more listed test, so it ends.

**Two things are new here.**

- The next run is made also when no entry is left to judge. At `aaef28f` the gate stopped there. Now only a run that comes to its end shows that nothing else stops the package. Example, held by a check: a listed subtest fails, and then its parent, which is not listed, panics with no test started in between. In the first run the subtest looks like the test that stopped the binary. The run without it stops again, and there no listed test accounts for it.
- A listed test that an earlier run judged can account for the stop of a later run. The gate looks at all listed tests of the run, not only at those it still has to judge.

**A run that stops with no listed test to account for it fails the step.** The step writes one error for the package:

```
::error::the run of <package> stopped before its end, and no listed test accounts for it: none reported a failure as the test binary stopped. A test that is not listed, a test that ended the process without reporting a failure, or the time limit of go test stopped it. The output of that run is above. The step passes only if the run of every listed package comes to its end. Listed tests that this run left without a verdict: <test> (<state>), ...
```

The state is `was running`, `waited to run in parallel` or `did not run`. Those tests are named in this one message and not with "listed test does not fail in the run of its package". That message tells the reader to delete the line, which would be the wrong advice when a test outside the list stopped the run. An entry that reported `pass` or `skip` before the stop is still named with that message, because its verdict is its own. The `go test` of each entry alone still runs after such a stop.

**What is gone.** The rule "more than one listed test was running when the binary stopped, each is named" and its text `RAN_BESIDE`. It was needed only because a running test without a verdict could count as failing. Now the one that panicked has a verdict and the others are judged in the next run.

**The message of the second run** now reads `Run of <package> without the N listed tests that reported a failure as its test binary stopped: it has to come to its end, and M listed tests have no verdict yet`.

### 4.3 What the gate cannot tell apart, stated

The gate does not tell a panic of a listed test from a stop that follows directly on its ordinary failure report, with no test starting or going on in between. In both the test reported its own failure, so its entry is judged rightly. The difference is only who stopped the run, and the next run answers that: without that listed test the package has to come to its end. If the cause was something else and it stops the run again, the step fails. If the cause was something else and it does not stop the run a second time, the step passes: that is a stop that does not repeat, which no single run can show. This is in the gate's docstring.

### 4.4 The self-check

121 checks in 9 groups, 4 more than at `aaef28f`. All changes are in the group `ListedTestsMustStillFail` (29 checks, 25 before), in the Go sources it uses, and in one new helper `cut_short`, which requires exactly the given packages to be named as stopped, each with exactly the given tests left without a verdict.

**New checks.**

| Check | What it holds | Audit's probe |
|---|---|---|
| `test_listed_test_that_ran_when_something_else_stopped_the_test_binary` | Four modules. In each the entry fails alone, and in the run of its package it is running and has not failed when something else stops the binary: a test beside it ends the process; a test beside it panics; a goroutine that an earlier test left behind ends the process; the sibling of a listed subtest panics. Each time the step fails, names the package as stopped with the entry as `was running`, and makes no second run | R1, R1p, R3, R8 |
| `test_run_of_the_package_that_the_time_limit_of_go_test_stops` | The entry fails alone and never ends in the run of its package. A stand-in for the `go` command adds `-timeout=5s` through `GOFLAGS`. The log shows `panic: test timed out after 5s`, and the step fails | R7 |
| `test_package_runs_again_until_a_run_comes_to_its_end` | Three cases: a listed test that panics and is the only test of its package (the second run has no test left and comes to its end, exit 0); a listed subtest that fails before its unlisted parent panics (the second run stops again, exit 1); the same with a subtest that passes (no second run, because only a test that reported a failure can account for a stop) | new |
| `test_listed_test_that_an_earlier_run_judged_accounts_for_a_later_stop` | A listed test fails in the first run and panics in the second. It accounts for that stop, and the third run leaves out both | new |

**Replaced.** `test_listed_test_without_a_verdict_fails_only_if_go_test_failed` held the old rule. In its place `test_listed_test_that_ends_the_process_is_not_seen_failing` holds the new one for a test that calls `os.Exit`, for a parallel test that does so after it has gone on, and for a listed subtest that does so after another listed subtest failed. The stand-in `ZERO_STATUS_GO` is gone with the old check: the exit status of `go test` no longer decides anything in this step.

**Changed.** Eight checks. Most of them used a test that ends the process as "the listed test that stops the binary". Those now use a panic for that, and where the old variant with `os.Exit` said something of its own it is kept with the new expectation:

- `test_listed_test_that_stops_the_test_binary_does_not_hide_the_next`, `test_only_the_listed_test_that_stopped_the_test_binary_is_left_out`: the panic variants stay, the `os.Exit` variants moved into the replaced check above.
- `test_two_listed_tests_that_stop_the_test_binary_one_after_the_other`: both panic.
- `test_listed_test_that_waited_when_the_test_binary_stopped_is_judged_in_the_next_run`, `test_listed_test_that_failed_before_another_went_on_did_not_stop_the_test_binary`: the stopping test panics. The second now also holds that the second run leaves out only that test.
- `test_two_listed_tests_that_ran_side_by_side`: when one panics while the other runs, the other is judged in a second run and the step passes. When one ends the process, neither has a verdict and the step fails with both named as `was running`.
- `test_test_binary_stopped_by_a_test_that_is_not_listed`: the step fails through the new message. A second case holds that it fails also when the only entry had reported its failure before the stop (the audit's R5).
- `test_whole_listed_test_reports_how_its_subtests_ended`: the count `unfinished` in the note on subtests is now shown by a parallel subtest that waited when a sibling panicked.

**How my checks differ from the audit's probes.** The probes use `time.Sleep` to put the listed test and the stopping test side by side, and their listed test would pass. My modules use a channel: the stopping test waits until the listed test has said that it runs, and the listed test then blocks. So the order does not depend on timing, and the listed test "has not failed and is still running", which is the same state for the gate. The probes themselves ran unchanged as well (7.2).

**A9-O4.** The comment "`go env GOVERSION GOROOT` names another Go version, and the real GOROOT" now sits above `OTHER_VERSION_GO`.

### 4.5 Docs, list header, workflow

- `.docs/system_overview/go_toolchain_baseline.md`, section 10: the paragraph on the second blocking step now says that an entry fails only if the testing package reported its failure, that a test that ends the process without reporting cannot be listed, that the run of a package has to come to its end, that the package runs again without a listed test that panics, and that the step fails when a run stops and no listed test reported a failure as it stopped.
- `docs_contract_test.go` holds those five sentences.
- `.github/ci/environment-only-tests.txt`: four comment lines in the header say what counts as a failure and that a test that ends the process cannot be listed. No entry and no `skips-itself` line changed.
- `.github/workflows/go.yml`: only the comment above the step "Listed tests still fail" changed. Because the file is held as a whole, `WORKFLOW_SHA256` in the self-check changed with it, from `0383a2f0…b8bf` to `d8578b0e6b5901d06ae82f0ec4acf81390d48ff8831a574a76d8d57d1c58bd18`. No step, command, trigger, permission or pin changed: `git diff aaef28f 8eefe6d -- .github/workflows/go.yml` shows 6 added and 4 removed lines, all of them comment lines.

## 5. Every finding and what happened to it

| ID | Severity | Status | Where |
|---|---|---|---|
| A9-F1 | low | **Fixed.** All five cases fail the step, and each has a check. R3 is closed too, with no stated bound | 4.1, 4.2, 4.4, 7.2 |
| A9-O1 `TestMain` calls `m.Run` twice | observation | Unchanged. Plain `go test` passes there too, and the tree has no `TestMain` | none |
| A9-O2 the message for a skip that cannot be listed proposes a line that the gate refuses | observation | **Not changed.** It is outside the assignment for this repair, it fails closed, and the tree has no such test. It stays as the audit states it | 8 |
| A9-O3 reasons held by review | observation | Unchanged, as stated in `08-repair.md` section 8 | none |
| A9-O4 comment above the wrong constant | cosmetic | **Fixed** | 4.4 |
| A9-O5 commit trailer names a model | observation | Unchanged. This commit carries the same two trailer lines as the eight before it, as the session's rules for commits require. Whoever merges decides the text of the merge | 9 |
| A9-O6 tests leave files in the temporary folder | pre-existing, outside the patch | Unchanged | none |

## 6. Files touched

| File | What changed | Lines |
|---|---|---|
| `.github/ci/go_test_gate.py` | `judged`, the two message tables, `in_the_run_of_its_package`, `still_failing`, and the docstring of the mode `still-failing` | +101/−60 |
| `.github/ci/go_test_gate_selftest.py` | the group `ListedTestsMustStillFail`, its Go sources, the helper `cut_short`, one stand-in for the `go` command, `WORKFLOW_SHA256`, one comment moved | +497/−128 |
| `.docs/system_overview/go_toolchain_baseline.md` | one paragraph of section 10 | +9/−2 |
| `docs_contract_test.go` | five held sentences of that paragraph | +5/−0 |
| `.github/ci/environment-only-tests.txt` | four comment lines in the header | +5/−0 |
| `.github/workflows/go.yml` | the comment above the third step | +6/−4 |

Together +623/−194. The gate is now 1,089 lines and the self-check 3,835. Nothing in the mode `gate` changed.

## 7. Validation

Every container run below used the scratch copy whose tree is `c3e784d20d3311650bfa91358d4113430dff4ca8`, the tree of the commit, as the unprivileged user `ci` with an emptied environment (`env -i`, then `container-env.sh`). Heavy runs ran one at a time. The files named in brackets are in `09-repair-evidence/`.

### 7.1 Build, vet, self-check, in the container

| Command | Result |
|---|---|
| `go mod verify` | `all modules verified`, exit 0 |
| `gofmt -l docs_contract_test.go` | no output, exit 0 |
| `go build ./...` | exit 0 |
| `go vet ./...` | exit 0 |
| `GOOS=darwin GOARCH=arm64 go vet ./...` | exit 0 |
| `go test -count=1 -run '^TestGo1265ToolchainBaselineDocsAndBuildContract$' .` | `ok`, exit 0 |
| `python3 -I -B .github/ci/go_test_gate_selftest.py` | `Ran 121 tests in 197.027s`, `OK`, exit 0 |

(`container-validation.log`, `container-selftest.log`, `container-selftest-status.txt`)

### 7.2 The audit's probes, unchanged, against the new gate

`aud9_probes.py`, `aud9_probes2.py` and `aud9_probes3.py` are byte copies of the files in `09-audit-evidence/` (`inputs-SHA256SUMS.txt`; the hashes equal those in the audit's `SHA256SUMS.txt`). Each ran whole, with the path of the new gate as its argument (`aud9_probes.log`, `aud9_probes2.log`, `aud9_probes3.log`).

| Probe | What stops the run of the package | At `aaef28f` (audit's log) | Now |
|---|---|---|---|
| R1 | a test that is not listed ends the process while the listed test runs | exit 0, wrong | **exit 1** |
| R1p | the same with a panic | exit 0, wrong | **exit 1** |
| R3 | a goroutine left by an earlier test ends the process | exit 0, wrong | **exit 1** |
| R7 | the time limit of `go test` (8 s in the probe) | exit 0, wrong | **exit 1** |
| R8 | an unlisted sibling of the listed parallel subtest panics | exit 0, wrong | **exit 1** |
| R2, control | nothing; the entry passes in its package | exit 1 | exit 1 |
| R4 | an unlisted test panics between two listed tests | exit 1 | exit 1 |
| R5 | an unlisted test ends the process after the only entry failed | exit 0 | **exit 1**, see below |
| R6, control | the listed test itself ends the process | exit 0 | **exit 1**, see below |

The probe files print `NOT AS EXPECTED (expected 0)` for R5 and R6, and for nothing else. Both are the new rule and are intended.

- **R6:** the listed test reported no failure, so it is not seen failing (4.1). The audit said of this case: "refusing it is the safe side".
- **R5:** the entry reported its failure, and it is not named. The step fails because the run of the package was stopped and no listed test accounts for it (4.2). The assignment asked for that.

The companion probes in the mode `gate` (`R1-gate`, `R1p-gate`, `R7-gate`, `R8-gate`, and the three of `aud9_probes3.py`) and all probes of the groups S, C and L give the results of the audit's logs. The audit's own correction for C4 applies here too: with the committed probe file it gives exit 0.

**On the runner the stricter result cannot add a second red step for one cause.** The workflow has no `if:` on its steps. The step "Listed tests still fail" runs only after the step "Test" passed. In R5 the step "Test" fails, so the third step would not run at all. The stricter rule decides only when "Test" is green and a package is stopped in the third step, which is the case the finding is about.

### 7.3 The two holds of the workflow file

In a copy of the tree I appended two spaces to one comment line of `go.yml` (`hold-plant.log`). The self-check's `test_the_workflow_file_is_the_text_that_was_reviewed` fails, and `TestGo1265ToolchainBaselineDocsAndBuildContract` fails with "the CI self-check does not hold .github/workflows/go.yml as it is". On the committed tree both pass (7.1).

### 7.4 Mutants: can the self-check tell a broken gate from a working one

`mutants7.py` is the mutant file of the fourth repair with the mutants of the third step written again for the new code (`mutants7.py.txt`, `mutants7-hints.json`). It holds the control and 204 mutants. Five of the old ones are gone with the rules they changed (F8, F9, F10, Z13, Z14). Fourteen are new: Z6b and N1 to N13. Each mutant asserts that the text it replaces occurs exactly once. A mutant is killed when a check of the committed self-check fails against it. The checks named for it run first, and a survivor has passed all 121.

**The new mutants, and what kills each** (`mutants7-first-part.log`):

| Mutant | The change | Result |
|---|---|---|
| N1 | a listed test that was running when the test binary stopped counts as failing | killed, `test_listed_test_that_ends_the_process_is_not_seen_failing` |
| N2 | the same, but only if `go test` failed: the rule of `aaef28f` | killed, the same check. `old-rule-each-case.log` shows that with this mutant every case of the finding fails its check: the four cases of R1, R1p, R3 and R8, the time limit, and the three cases of a test that ends the process |
| N3 | a run that stopped with no listed test to account for it is named and does not fail the step | killed, `test_listed_test_that_ran_when_something_else_stopped_the_test_binary` |
| N4 | such a run fails the step and is not named | killed, `test_listed_test_that_ends_the_process_is_not_seen_failing` |
| N5 | its message does not name the entries that it left without a verdict | killed, the same check |
| N6 | such a run is not recorded at all | killed, the same check |
| N7 | only an entry that the run still had to judge can account for its stop | killed, `test_listed_test_that_an_earlier_run_judged_accounts_for_a_later_stop` |
| N8 | a later run of a package in which no test starts counts as a package that did not start | killed, `test_package_runs_again_until_a_run_comes_to_its_end` |
| N9 | a listed test that passed or skipped itself can account for a stop | killed, the same check |
| N10 | when a run came to its end, the entries without a verdict are not named | killed, `test_listed_subtest_that_does_not_run_is_named` |
| N11 | the entries that a stopped run left without a verdict are all named as waiting | killed, `test_listed_test_that_ends_the_process_is_not_seen_failing` |
| N12 | a listed test that the next run leaves out can account for the stop of that run too | **survives**, see below |
| N13 | an entry that reported pass or skip before the run stopped is not named | killed, `test_listed_parallel_subtest_that_did_not_get_to_run_is_named` |
| Z6b | after a stop that a listed test accounts for, no second run is made and the stop counts as accounted for | killed, `test_listed_test_that_an_earlier_run_judged_accounts_for_a_later_stop` |
| Z11, written again | no further run is made when no entry is left for it: the behaviour of `aaef28f` | killed, `test_listed_test_that_failed_before_another_went_on_did_not_stop_the_test_binary` |

The check named for a mutant is the first one that failed in the order of the names, because each run stops at its first failure. It is not the only one that would fail.

**Result.** 198 of the 204 mutants are killed, and six survive. The control passes all 121 checks (`Ran 121 tests in 226.595s`, `OK`).

| Part | Mutants | Killed | Survive | Time |
|---|---|---|---|---|
| First: the groups F, W, T, Z and N, which change the third step | 63 | 61 | F20x, N12 | 1,344 s |
| Second: all others | 141 | 137 | E1, E2, E3, E4 | 1,068 s |

- **N12 is the one new survivor, and it is equivalent while `go test` honours `-skip`.** It removes the condition `path not in stopped` from the rule that says which listed test accounts for a stop. A test that a run leaves out gets no verdict in that run, so with a real `go test` the condition never decides anything. It is there so that the loop of runs ends whatever the `go` command does: a listed test can account for one stop only. Mutant Z15 shows it at work. With Z15 the next run skips nothing, the same listed test panics again, the condition refuses to count it a second time, and the step fails with exit 1. N12 ran all 121 checks.
- **The other five survivors are the five of `08-repair.md`,** for the reasons given there. F20x gives a name a new value inside a loop, which changes nothing. E1 and E2 differ from the gate only for an event stream that `go test -json` does not produce. E3 and E4 remove guards that no output of a real `go` command and no accepted list can reach. Each ran all 121 checks.
- **Z12 and Z16 are killed by the time limit of the script, not by an assertion.** With each of them the gate never ends: it runs the same package again and again. The checks that run first for them did not end within 600 seconds, and the script counts that as killed and says so in the log.
- **No mutant was killed by an error of the script.** Every other kill is a failed assertion of a check (`FAILED (failures=…)`), and the log has no `errors=` line.

**The run was complete before the push for the mutants of the third step** (the first part: the control and 63 mutants). The lesson of the fourth repair was to do it in that order. The second part, the 141 mutants of code that this repair did not touch, ran after the push (`mutants7-second-part.log`).

### 7.5 The earlier reviewers' files, unchanged, against the new tree

| File | Result |
|---|---|
| `go_test_gate_redteam8.py`, the red team's seven checks beside the self-check | `Ran 7 tests in 4.279s`, `OK` (`redteam8-checks.log`) |
| `rt8.py`, the red team's 15 probes of the gate | 12 as expected, 2 `BOUNDARY, as the report states` as before, and **F2 printed as `HOLE`**, see below (`rt8.log`) |
| `rt8_lists.py` | `unexpected: 0` (`rt8_lists.log`) |
| `aud8_patchrelease.sh` | the committed gate stops on go1.26.6 with exit 1 (`aud8_patchrelease.log`) |
| `aud8_mutants.py H1 H2` | both killed (`aud8_mutants-H1-H2.log`) |
| `aud9_mutants.py`, the ninth audit's 65 mutants | 52 of the 65 still find their text in the new gate, and those ran: **47 killed, 5 survive** (K16, V5, V6, V12, T22), and the control passes all 121 checks (`aud9_mutants.log`, 1,266 s). The five are five of the audit's own six survivors, judged in section 10 of `09-audit.md`. K16, V5, V6 and V12 are in code that this repair did not touch. T22 judges every entry again in each further run; Inference: in the new loop that is still equal to the gate or stricter, as the audit says of it. T7 is killed by the time limit of 600 s, because with it the gate never ends. **13 no longer apply:** T3, T4, T5, T6, T8, T12, T14, T15, T16, T17, T18, T19 and T21 replace text of the code that this repair rewrote (`aud9_applies.log`). The mutants of 7.4 cover that code as it is now |

**F2 of `rt8.py` is not a hole.** The probe: a listed subtest fails, and later a goroutine that an unlisted test left behind panics while another unlisted test runs. The script expects the pair (step "Test" exit 1, third step exit 0) and prints `HOLE` for any other pair. The new gate gives (1, 1). The step "Test" still fails on the broken test, which is what the probe is about. The third step now fails too, because the run of the package was stopped and no listed test accounts for it. It is the same change as R5 in 7.2, and on the runner the third step would not run after the failed step "Test".

### 7.6 The two gate steps on the real tree

**In the container,** with the list for this container (`list-container.txt`: the committed list without the three entries that pass in a container, and with one more `skips-itself` line for the test that needs Docker, as in `08-repair.md`):

- `go_test_gate.py gate`: exit 0 after 472 s. `test gate passed: 41 packages, 3 of them with skipped entries (12 entries); 40 tests skipped themselves, all of them listed` (`container-gate.log`).
- `go_test_gate.py still-failing`: exit 0 after 316 s. 12 lines `still fails:`, one run of each of the three listed packages and no second run of any, and `all 12 listed tests still fail on this host, each in a run of its own and in the run of its package` (`container-still-failing.log`, `container-gate-status.txt`).

**On the GitHub runner (authoritative).** Run [45064532285](https://github.com/evo-agi/Execution-Substrate/actions/runs/45064532285) at `8eefe6d`, job 137337607603, is **green**. It ran from 20:06:38 to 20:20:09, which is 13 m 31 s, on the image `ubuntu-24.04` version `20261116.133.1` with go1.26.5. It is one run, the first of these bytes. The complete log is `run-45064532285-job-137337607603.log`.

| Step | Time | Result in the log |
|---|---|---|
| Vet for macOS | 25 s | success |
| Check the test gate | 1 m 52 s | `Ran 121 tests in 112.362s`, `OK` |
| Test | 5 m 47 s | `test gate passed: 41 packages, 3 of them with skipped entries (15 entries); 39 tests skipped themselves, all of them listed`. The second run of `es/app`: `the observed run passed; go test skipped exactly the listed tests of this package (2), each once` |
| Listed tests still fail | 4 m 32 s | 15 lines `still fails:`, then `all 15 listed tests still fail on this host, each in a run of its own and in the run of its package` |

- **The new rule changed nothing for today's list.** The third step makes 18 runs: one for each of the 3 listed packages and one for each of the 15 entries. Each of the 18 ends with the line `FAIL` of the testing package. No package runs a second time. The log has no `panic:`, no `test timed out` and no `##[error]` line.
- **The 15 `still fails` lines and the 39 skip lines are the same as in the run at `aaef28f`** (`runner-skips.txt` is identical to the file of that name in `08-repair-evidence/`).
- **The job took 1 m 18 s longer than at `aaef28f`** (12 m 13 s there). The self-check is not the reason: it took 112 s here and 119 s there. The third step took 4 m 32 s here and 3 m 18 s there, and the difference is in the tests of the root package, not in the gate. The run of the root package took 133.097 s (100.155 s at `aaef28f`), and the `go test` of the entry `TestRemoteAlphaRuntimeSecurityBoundaryCheckMissingToolsStayHonest` alone took 45.54 s (4.71 s and 4.40 s in the two runs before). In the package run of the same job that test took 6.93 s, and its failure message is the same in all of them. **Unknown** why it was slow in that one run. The gate starts `go test` and reads its output; it does not influence how long a test runs. No package ran twice, so the repair added no run.

### 7.7 Failed or skipped validation

- **No run on David's Mac at this head.** The assignment did not ask for one, and the workflow runs on Linux only. The self-check last passed on macOS at `aaef28f` (117 checks). Its four new checks are **Not run** there.
- **No runner run on the merge with today's `trunk_dev`.** The green run is of the merge with `ae326b0` (7.8).
- **No full `go test ./...` outside the gate.** The step "Test" is that run, with the list.
- **Three results differ from what an earlier reviewer's file expects,** and all three are the intended new rule: R5 and R6 in 7.2, F2 in 7.5. No file was changed to make them agree.
- **`aud9_hold.py` of the audit: Not run.** It carries the workflow hash of `aaef28f` as a constant, so it cannot run unchanged on a tree whose workflow file changed. The narrow audit can set that constant to the new hash, as the ninth audit did with the file of the eighth. Section 7.3 is a plant of my own on the workflow file only. The holds of the Go version and of `match.go` were not planted again; this repair did not touch them.
- **13 of the audit's 65 mutants could not run:** the text they replace is in code that this repair rewrote (7.5).
- **The runner ran these bytes once.** One green run is not a statement about flakiness.
- **The second part of the mutants and the audit's own mutants ran after the push** (7.4, 7.5). Neither showed a gap.

### 7.8 `trunk_dev` moved while the runner run was going

**The fact.** PR #17 ("Repair three es/app integration tests that fail since #8") was merged at 20:20:05. `trunk_dev` went from `ae326b0` to `b8d6bc3abb8c8c38481c7835824bd79ba26e467b`. The runner run of 7.6 had started at 20:06:38 and checked out `Merge 8eefe6d… into ae326b0…`, so it does not cover the new commit. I saw the move at 20:46, when I fetched again before writing this report.

**What I did not do.** I did not merge `trunk_dev` into the branch. That would put a new head on the pull request, and the narrow audit is of `aaef28f..8eefe6d`. Provenance §5.4 step 2 gives this step to the merge gate: update the branch after the audit, take a new manifest, and show with `git range-diff` that the patch is unchanged. That push also starts the runner run on the new merge.

**What the new commit changes, read from `git diff ae326b0 b8d6bc3`.**

- Three files, all in `es/app` and all test files: `staging_cleanup_integration_test.go`, `submit_integration_test.go`, `supported_local_proof_validation_test.go`. This pull request touches none of them, and #17 touches none of the nine files of this pull request.
- It adds and removes no top-level test, no `t.Run` line and no line that skips. So the set of test names in `es/app` is the same, and so are the conditions under which a test skips itself.
- The three tests it changes are `TestExecutionLoopScriptSuccessRetainsDistinctStageRootsAcrossRepeatedRuns`, `TestSubmitFlowRejectsWorkloadArchiveWithSymlinkEntry` and `TestSupportedLocalSetupScriptBootstrapsRealSPIREAndVaultDevTarget`. Each has a `skips-itself` line in the list, because it needs Nomad or Vault, which the runner does not have. Neither of the two `es/app` entries is changed.

**The merge is clean.** `git merge-tree --write-tree 8eefe6d b8d6bc3` gives the tree `5f302414e1f86d48c37e43513efc87f1d55d8cd2` and reports no conflict.

**Shown in the container, on a scratch copy with exactly that tree** (same list as in 7.6):

- Build, `go vet ./...`, vet for macOS and the docs contract test: all exit 0 (`merged-validate.log`).
- `still-failing`: exit 0 after 323 s. Its 12 `still fails` lines are the same as in 7.6, with one run of each listed package and no second run.
- `gate`, first run: **exit 1** after 426 s (`merged-gate-run1.log`). `es/app`, the only package that #17 changes, passed in it and its observed run passed. One test of the root package failed: `TestRemoteAlphaESServiceTLSStatusCombinedGroupSignalFailureLiveDescendant/term`, with `descendant_gone failed`, `leader_reaped failed` and `returned failed`. See below.
- `gate`, second run: exit 0 after 458 s. `test gate passed: 41 packages, 3 of them with skipped entries (12 entries); 40 tests skipped themselves, all of them listed` (`merged-gate-run2.log`). The 40 skip lines are those of 7.6. Six of them carry another line number, in the files that #17 changed.

**The test that failed once is not about the merge and not about this pull request. It is a finding of its own.**

- The root package is the same in both trees: `git diff 8eefe6d 5f302414` shows the three `es/app` files and nothing else. The test is in `remote_alpha_es_service_tls_status_test.go`, which this pull request does not touch.
- Its fixture gives a worker thread two seconds to finish (`thread.join(2)`, line 2906). The subtest `term` took 2.14 s in the failed run and 1.19 s in an earlier run of which I kept the event stream. Inference: the result depends on timing, and the thread was late under the load of the package's parallel tests.
- It failed in 1 of the 15 runs of the mode `gate` whose logs this container still holds. On the runner it passed in both steps of the runs at `aaef28f` and at `8eefe6d`.
- **Risk:** the step "Test" can turn red at random on any pull request, on the runner too. I did not change the test: it is outside the assignment and outside this patch. It needs its own small change, as PR #16 is for the lock-timing test. The coordinator decides who writes it.

**A mistake of mine on the way.** My first scratch copy of the merged tree was made with a umask of 002, so its files were group-writable. Three tests of the root package that check file modes failed on it (`merged-wrong-modes-gate.log`). That says nothing about the merge. I made the copy again with a umask of 022, checked that every file and folder has the same mode as in the copy of the commit, and started the runs again. The results above are from the second copy.

**Not shown: a runner run on the new merge.** Inference from the points above: the gate will judge it as it judged the old merge, with the same 15 and 39 lines, because each of the three changed tests skips itself in its first statement on a host without Nomad or Vault (a check for the commands it needs, or the helper that starts the Nomad stack), and #17 did not change those checks. A `pull_request` run starts on a push to the branch. A re-run of the finished job would use the old merge commit again, so I did not start one.

## 8. Stated bounds

**A test that ends the process without reporting cannot be listed** (4.1). The step names it and says why. The cure is in the test.

**A stop that does not repeat** (4.3). If something outside the list stops a run directly after a listed test reported its failure, and does not stop the next run, the step passes. Every entry has then reported its own failure, and one run cannot show a cause that does not repeat.

**Each entry is judged in the first run of its package in which it has a verdict.** A later run of the same package does not judge it again. Unchanged from `aaef28f`.

**A9-O2 stands as the audit states it.** For a skip that the list cannot name (a fuzz target, a subtest with a name outside the list's alphabet) the step "Test" fails and proposes a line that the gate then refuses. It fails closed. The tree has no fuzz target.

**No defence against a test that forges the output of `go test`.** Unchanged, and stated since `07-repair.md`.

**Unchanged and still open with the coordinator and David:** whether the check is required on `trunk_dev` (O-1), Nomad and Vault on the runner, and the set of workflow files (O-3). See `08-repair.md` section 8.

## 9. Authority, security and protocol widening; dependencies; hygiene; cross-repo impact

- **Authority, security, protocol:** none widened. The workflow file changes in comment lines only. No permission, trigger, secret, action pin or command changed.
- **Dependencies:** none added or changed. `go.mod` and `go.sum` are untouched.
- **Artifact hygiene:** the commit holds six source files and nothing generated. The repository's `.gitignore` covers `__pycache__`. One thing I corrected on the way: my first scratch copy for the container runs carried two compiled Python files that a syntax check had left in the working tree, so its tree was not the tree of the commit. I deleted them, made the copy again and started the runs again. Every log in the evidence folder is from the copy whose tree is `c3e784d20d3311650bfa91358d4113430dff4ca8`, the tree of the commit.
- **Commit message:** the two trailer lines that every commit of this pull request carries (A9-O5).
- **Cross-repo impact:** none. No other repository reads the gate, the list or the workflow.
- **Secrets:** none read, none written. The leak scan of this report and its evidence is in section 15.

## 10. Rules this creates for PR #12, PR #13 and every later change

These add to the rules of `08-repair.md` section 10.

- **A listed test has to fail through the testing package:** `t.Fatal`, `t.Error` or a panic. A test that ends the process (`os.Exit`, `log.Fatal`, a fatal error of the runtime) cannot be an entry.
- **The run of every listed package has to come to its end in the step "Listed tests still fail",** apart from stops that listed tests account for by panicking. A test outside the list that stops its package, or a package that runs into the time limit of `go test`, turns that step red as well as the step "Test".
- **A listed test that panics costs one more run of its package in that step,** also when it is the last entry.

## 11. Assumptions, unresolved seams, uninspected areas

- **Assumption:** the facts of section 3 about `go test -json` hold for Go 1.26.5. The gate already refuses another Go version for its observed run, and the self-check holds each fact with a real `go test`, so a Go version that reports differently fails the self-check.
- **Assumption:** five seconds are enough for a test binary of the time-limit check to start and for its one test to fail in the `go test` of the entry alone. If a machine were slower than that, the check would fail; it could not pass wrongly.
- **Not run on macOS at this head.** The four new checks use only `os.Exit`, panics, channels and a three-line shell script as stand-in for the `go` command. Inference: they behave the same there. It is not shown.
- **Unresolved seam: the branch is one commit behind `trunk_dev`** (7.8). The merge is clean and the container shows both gate steps green on the merged tree, the step "Test" in the second of two runs. The runner has not run it. The merge gate has to update the branch and wait for that run (provenance §5.4 step 2).
- **Seen outside the patch: a test of the root package that depends on timing** (7.8). `TestRemoteAlphaESServiceTLSStatusCombinedGroupSignalFailureLiveDescendant/term` failed once in the container on a two-second bound. It can turn the step "Test" red at random. Not changed here; it needs its own change.
- **Not inspected:** nothing outside the six files, apart from the diff of PR #17 and that one test for 7.8.

## 12. For the narrow audit

The delta is `aaef28f..8eefe6d`, six files. Claims to try:

- (a) The step "Listed tests still fail" cannot exit 0 when an entry has no verdict `fail` from the testing package in the run of its package, or in the `go test` of its own.
- (b) It cannot exit 0 when the last run of a listed package did not come to its end.
- (c) The loop of runs ends: each further run leaves out at least one listed test that the run before it did not.
- (d) An entry is never named with the advice to delete its line because of a stop that something outside the list caused.
- (e) Nothing changed in the mode `gate`: `git diff aaef28f 8eefe6d -- .github/ci/go_test_gate.py` touches the docstring of the mode `still-failing`, `judged`, the two message tables, `in_the_run_of_its_package` and `still_failing`.
- (f) `go.yml` differs in comment lines only, and both holds notice an edit of it (7.3).

The audit's own mutant file `aud9_mutants.py` has 13 of its 65 mutants anchored in code that this repair rewrote. Section 7.5 names them and says how the other 52 ran here.

## 13. Confidence

- **High** that the five cases of the audit and the two controls behave as this report says: the audit's probes ran unchanged, and each case has a check that passes on the gate and fails on the mutant that restores the old rule.
- **High** that today's list is not affected: the runner run at the new head is green with the same 15 `still fails` lines and 39 skip lines.
- **High** that the merge with `b8d6bc3` is clean. **Medium to high** that the runner is green on it: both gate steps pass on the merged tree in the container, the runner itself has not run it, and one test of the root package that depends on timing can fail any run (7.8).
- **Medium to high** that no further path lets the step pass on a stopped run. The rule is short, and every branch of the loop has a mutant that a check kills, apart from the one named in 7.4.

## 14. Provenance detail

Both manifests are complete below and as files in the evidence folder.

**Repair-only manifest, complete** (SHA-256 `1cb462368c4427615108e2c27c852452a69bcd84c458ad585a51e00e0b838ccf`; also `09-repair-evidence/manifest-repair-only.json`):

```json
{"branch":"claude/project-thread-sqldt7-ci","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/system_overview/go_toolchain_baseline.md","sha256":"8b0d9b698f4e1c18904491a7f91c79b73fe626902bdb471cf2c76c3353648078","size":8431},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".github/ci/environment-only-tests.txt","sha256":"ba629bd9328e84fb811593ec3e28657511bd862b033f6147d7bbe8b89da53ece","size":11652},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".github/ci/go_test_gate.py","sha256":"a2a0399bf0dad043d5636d5cab23f361d02702a450f115f4852ed326b6fd08fa","size":45877},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".github/ci/go_test_gate_selftest.py","sha256":"24d7f2f1ed6d072da345e0d42d829c8abae030437a7ededc2a85626db51e8633","size":159090},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".github/workflows/go.yml","sha256":"d8578b0e6b5901d06ae82f0ec4acf81390d48ff8831a574a76d8d57d1c58bd18","size":4700},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"6310006087c3d0839ee37ce160973ff283a708a233295509290cc02487de14f3","size":806381}],"head":"aaef28f36f393e78f832a9caa745edeb02565a6c","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"4cf25bd3af4294bf2d4d02ffc5e9b11c707f5f4c2f2cd37e59107cd19c8135d4","upstream":"origin/trunk_dev"}
```

**Cumulative manifest, complete** (SHA-256 `c16bda47d4a1cd7dee849bb6e0cc607bfac74be085ef434ba854d36f1f34b839`; also `manifest-cumulative.json`):

```json
{"branch":"claude/project-thread-sqldt7-ci","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/system_overview/go_toolchain_baseline.md","sha256":"8b0d9b698f4e1c18904491a7f91c79b73fe626902bdb471cf2c76c3353648078","size":8431},{"file_type":"regular","kind":"untracked","mode":"0644","path":".github/ci/environment-only-tests.txt","sha256":"ba629bd9328e84fb811593ec3e28657511bd862b033f6147d7bbe8b89da53ece","size":11652},{"file_type":"regular","kind":"untracked","mode":"0644","path":".github/ci/go_test_gate.py","sha256":"a2a0399bf0dad043d5636d5cab23f361d02702a450f115f4852ed326b6fd08fa","size":45877},{"file_type":"regular","kind":"untracked","mode":"0644","path":".github/ci/go_test_gate_selftest.py","sha256":"24d7f2f1ed6d072da345e0d42d829c8abae030437a7ededc2a85626db51e8633","size":159090},{"file_type":"regular","kind":"untracked","mode":"0644","path":".github/workflows/go.yml","sha256":"d8578b0e6b5901d06ae82f0ec4acf81390d48ff8831a574a76d8d57d1c58bd18","size":4700},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"6310006087c3d0839ee37ce160973ff283a708a233295509290cc02487de14f3","size":806381},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_file_test.go","sha256":"0cec866cf2e659c58a90eeb46f3edf75d9743db21c0c87aaad65d72462c3a2d9","size":70129},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/result_auth_test.go","sha256":"adab4be23f1d1f74bbc6bccd3e49235d8e95e0b5c6e2c4121930578c0e72f87c","size":18293},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"remote_alpha_operator_test.go","sha256":"efa79af1ac61541a9ba92a20ea3ef1b7cff2bcfa7eb587cc723efe1eee15d59a","size":279122}],"head":"ae326b0ddc30ec6b35883ee32945c622405b68b6","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"35efc396dbeadf52c8b90040c9a43d5e0a36442881a291aabf1c3c89d978c03e","upstream":"origin/trunk_dev"}
```

## 15. Evidence folder and report delivery

- Report: `/mnt/project-files/reports/Execution-Substrate/ci-go-workflow/09-repair.md`. Its SHA-256 is in the reply that delivers it.
- Evidence: `/mnt/project-files/reports/Execution-Substrate/ci-go-workflow/09-repair-evidence/`, 56 files plus `README.md` and `SHA256SUMS.txt`. The README says what each file is.
- Leak scan: `ge_chat_archive.py scan` (tool v1.4.0) over the report and every evidence file. Exit 0 and `0 finding(s)` for the report and all 58 files of the folder (the 56 files, `README.md` and `SHA256SUMS.txt`). The complete runner log is among them.
- The pull request description is updated for the new head. It keeps the two attribution lines of the first writer thread and both session links.
