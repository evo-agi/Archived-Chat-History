# INDEPENDENT AUDIT AND RED-TEAM REPORT: Execution-Substrate PR #14 (Linux CI)

**Final verdict: BLOCK**
**Effect status:** REPAIR_NOT_PERFORMED · COMMIT_NOT_PERFORMED · PUSH_NOT_PERFORMED · PR_NOT_MODIFIED · MERGE_NOT_PERFORMED · read-only on the target throughout

One audit thread did both jobs the brief asked for: the correctness audit and the red-team pass. It did not write the patch.

## 1. Verdict in short

The workflow is sound in most respects: provenance reproduces, the gate really fails on test, vet and compile failures, the token is read-only, no secrets are used, and Go matches `go.mod`. All 17 skipped tests are genuinely bound to the host, not hiding a failing product behaviour on the runner.

It is blocked on two things the brief asked me to check, both in `.github/workflows/go.yml`:

1. **The skip list matches more than intended (F1, F2).** The skip pattern is applied to every package in the module. I added a failing test with a listed name to a *different* package and the gating step exited 0 without running it. Separately, each list entry is used as a regular expression, so one entry such as `TestFoo|TestBar` or `Test.*` silently widens the skip.
2. **The two actions are pinned by tag, not commit SHA (F6).** The brief lists pinned SHAs as a check, and the writer's report says they are not pinned.

Both repairs are small. Section 9 gives a repair sketch whose parts I ran on a synthetic module.

Nothing I found makes merging dangerous to the repository (no write path, no secret exposure). The block is about whether a green check can be trusted to mean what it says.

## 2. Audit target

| Field | Value |
|---|---|
| Repository | evo-agi/Execution-Substrate (public; `allow_forking: true`, from the GitHub search API) |
| Base | `trunk_dev` at `ae326b0ddc30ec6b35883ee32945c622405b68b6` (still the tip of `origin/trunk_dev` when I closed out) |
| Topic branch | `claude/project-thread-sqldt7-ci` |
| Commits | `d886bb80feb160b6775f0ac1866ce69f7bdbfe47`, then `145ab62001e488fea0cd4c4a002661df86ef9f95` |
| Tip tree | `b27b5c5138ed304c0d5e34d0dcfa342221e2fa88` |
| PR | #14, draft, head `145ab62…`, base `trunk_dev` at `ae326b0…`, 3 files, +136/−3, `mergeable_state: clean` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified with `sha256sum -c` before each run) |
| Canonical manifest SHA-256 | `d9f5fe14cf33e1e5af435208889b048f84866b3b03f00ee6d81a6f27a84b84b2`, 3 files |
| Textual diff SHA-256 | `c65fdafd8c8445a7baf703527554fea0f6825e5fcead797845e048bad2025367` |
| Writer report | `/mnt/project-files/reports/Execution-Substrate/ci-go-workflow/01-implementation.md`, SHA-256 `da05a13129a7ab5d65796635696d47b3248677e48dc4864695468e374b569467` (matches what I read) |
| CI run audited | 44978229993, job 137072799141, event `pull_request`, head `145ab62…`, conclusion `success` |

## 3. Audit posture

- Read-only on the target. No edits, formatting, commits, pushes, PR comments or re-runs of the workflow.
- **Deviation from protocol §13.2 step 3:** I used no audit subagents. The change is 3 files, and this session's default is to avoid subagents unless asked. I covered the four audit perspectives myself (contract and authority, correctness, test adequacy, security).
- All experiments ran in this thread's cloud container, on copies of the tree outside the audit clone. Nothing ran on GitHub, on David's Mac or on the Linux box.
- Side effects in my container only (it is discarded with the thread): local users `ds` and `ci`; packages `uuid-runtime`, `openssh-client`, `acl`; a Go 1.26.5 copy under `/opt`; an empty `/private/tmp` (mode 1777). I created and removed `/etc/modprobe.d/zz-audit-experiment.conf` and a `/usr/bin/go` symlink. The tooling refused my attempt to remove `/private`, so that empty directory stays until the container is reclaimed.

## 4. Provenance reproduction

Procedure: provenance §5.3, in the fresh clone at `/home/user/Execution-Substrate`.

```text
git fetch origin trunk_dev claude/project-thread-sqldt7-ci
origin/claude/project-thread-sqldt7-ci == 145ab62001e488fea0cd4c4a002661df86ef9f95    (pushed tip is the reported tip)
git merge-base --is-ancestor ae326b0… 145ab62…                                         (true)
git checkout -f -B claude/project-thread-sqldt7-ci 145ab62… ; HEAD^{tree} == b27b5c51… ; status clean
git reset --mixed ae326b0… ; git branch --set-upstream-to=origin/trunk_dev
python3 -I governed_execution_audit_patch_manifest_v2.py OUT/1.json   (and OUT/2.json)
```

- Two opening runs: byte-identical (`cmp`), manifest SHA-256 `d9f5fe14…84b2`, `file_count=3`, textual diff `c65fdafd…5367`.
- `cmp` of my manifest against the manifest line in the writer's report: identical.
- Mode bits: all three entries `0644` on both sides. No tolerated difference was needed.
- PR #14 head on GitHub is `145ab62…`. The CI run checked out merge commit `8e00f005ed6960291b4c5b1358e191bd6e9b4503`, whose tree is `b27b5c51…`, the same tree as the tip. So the green run tested exactly the audited bytes.
- Closing run after all experiments: see section 11.

**Result: provenance holds.** No `AUDIT_PROVENANCE_MISMATCH`.

## 5. The brief's checks, one by one

| Check | Result | Evidence |
|---|---|---|
| Each skip is genuinely environment-bound | **Yes, all 17**, with caveats F4, F7, P-B | Section 7 |
| The skip list cannot silently grow or match more than intended | **No** | F1 (confirmed bypass), F2, F3 |
| Gate fails on test failure | **Yes** | Section 8, R2 to R9; runner run 1 failed for real |
| Gate fails on vet errors | **Yes** | `go vet ./...` at base exits 1 with the copylocks finding; at tip exits 0 |
| Gate fails on build errors | **Yes** | Compile error in a test file fails vet and test (R8); `go build ./...` is a separate step under `bash -e` |
| `pull_request`, not `pull_request_target` | **Yes** | `go.yml:8-12` |
| Token permissions minimal | **Yes** | `go.yml:14-15`; runner log: `Contents: read`, `Metadata: read` |
| Action SHAs pinned | **No** | `go.yml:88`, `go.yml:93` use `@v4` and `@v5` (F6) |
| No secrets exposure | **Yes** | No `secrets.*` reference; `persist-credentials: false` (`go.yml:90`), and the log shows the auth header removed after checkout; no `${{ }}` inside any `run:` script |
| Fork PR behaviour | **Acceptable by design; not observed** | Under GitHub's documented rules for `pull_request`, fork runs get a read-only token and no secrets. A fork PR can edit the workflow it is checked by; that is inherent to `pull_request` and is a review matter |
| Go version matches `go.mod` | **Yes** | `go.mod`: `go 1.26.5`, no `toolchain` line; `go-version-file: go.mod` (`go.yml:95`); `GOTOOLCHAIN: local` (`go.yml:29`); runner log: `go version go1.26.5 linux/amd64` |
| Push to `trunk_dev` triggers | **Yes by reading; not observed** | `go.yml:10-12`. Both runs so far were `pull_request` events. Inference: push runs start once the file is on `trunk_dev` |

## 6. Findings

Severity scale: critical, high, medium, low, observation. "Patch defect" means introduced by PR #14. "Pre-existing" means present at `ae326b0` and only exposed by this work.

### Patch defects

**F1. A test with a listed name in any other package is silently skipped by the gate**
- Type / severity: bug in the gate (test gap) / **medium**. Required repair.
- Path: `.github/workflows/go.yml:117-118` at `145ab62`.
- Evidence: the pattern is passed to `go test -skip … ./...`, so it applies to every package. Go allows the same test name in different packages. Using the step's exact `run:` text and the exact list, on a synthetic module, a new failing `TestSQLiteV3OldBinaryRefusesWithoutMutation` in package `other` produced `ok synth/other [no tests to run]` and exit 0 (section 8, R1).
- Impact: a failing test passes the gate without any change to the workflow file, so the diff shows nothing about CI. The realistic paths are a listed test being copied or moved to another package during a refactor, or a deliberate reuse of a listed name.
- Required correction: scope each skip to the package the test lives in (run the three affected packages with their own lists, and all other packages with no skip), or add a blocking check that every listed name is defined only in its expected package.
- Uncertainty: none on the mechanism. I did not push a branch to demonstrate it on the real runner (not authorized, and not needed: the step text is the same).

**F2. List entries are regular-expression fragments and nothing validates them**
- Type / severity: bug in the gate / **low**. Required repair together with F1.
- Path: `go.yml:68-85`, `go.yml:117`.
- Evidence: with a real failing test `TestRealRegression` present, appending the entry `Test.*`, `TestReal.*` or `TestFoo|TestRealRegression` made the gate exit 0 (section 8, W1, W2, W8). The current 17 entries are clean: all match `^Test[A-Za-z0-9_]+$`, are unique, and the value the runner logged equals the parsed YAML value.
- Impact: one mistyped or pasted entry widens the skip without any visible signal. It does need an edit to the workflow, so review can catch it.
- Required correction: fail the step unless every entry matches `^Test[A-Za-z0-9_]+$`.

**F3. Nothing checks that a listed name exists or still fails**
- Type / severity: test gap / **low**.
- Evidence: `TestOperationalHandoffSchema4BinaryRefusesSchema5` is defined nowhere at `145ab62` (0 matches across all `_test.go` files). It exists on PR #12 at `8058561` (`es/admission/internal/reliablesubmit/operational_handoff_test.go:435`) and PR #13 at `e544e0f` (`:487`). So the list already holds a skip for a test this runner has never executed. In the other direction, once a listed test is ported or fixed it stays skipped until someone remembers to remove it.
- Impact: the list can go stale in both directions without a signal.
- Suggested correction: have the non-blocking step compare the set of failing top-level tests with the list and fail (blocking) when a listed test passes or does not exist, with an explicit allowance for the PR #12 name until that PR lands.

**F4. Skipping whole tests removes 21 subtests that pass on the runner**
- Type / severity: test gap / **low to medium**.
- Evidence (Inference from the runner log, which prints only failures, plus the subtest tables in source): on the runner, 4 of 22 subtests of `…FailureWitnessBootstrapOwnedTerminal` pass, 11 of 15 of `…RootLoadedStageCustody` pass, and 3 of 4 pass in each of the two `es/app` tests. In my container, adding a real `go` to `/usr/bin` reproduced the `es/app` picture exactly: only `local_build_path_rejects_missing_Go_before_mutation` failed; `rejects wrong Go before mutation`, `accepts exact Go at bounded sentinel` and the prebuilt-inputs subtest passed.
- Impact: the six `es/app` subtests are real, portable checks that the setup and proof scripts refuse a wrong Go before changing anything. They are no longer gating. (The 11 custody subtests are a different matter: see P-A.)
- Suggested correction: skip at subtest level for `es/app`. Go accepts `^TestName$/^subtest_name$` as an alternative in `-skip`; I ran that form on a synthetic module (section 9).

**F5. The non-blocking step cannot signal anything**
- Type / severity: design gap / **low**.
- Evidence: `go.yml:120-124`. The step always exits 1, so every green run carries a red `Process completed with exit code 1` annotation, and the API reports the step as `success` (run 44978229993, step 10). A new failure inside a listed test changes nothing visible. The writer's report states this exposure openly.
- Suggested correction: same as F3.

**F6. Actions are pinned by mutable tag**
- Type / severity: security hardening / **low to medium**. Required repair (the brief lists it as a check).
- Path: `go.yml:88` (`actions/checkout@v4`), `go.yml:93` (`actions/setup-go@v5`).
- Impact: whoever can move those tags can change what the gate runs. With a read-only token and no secrets, the exposure is the integrity of the check itself, not the repository.
- Required correction: pin both to full commit SHAs with the version in a comment. The runner log for run 44978229993 reports the SHAs it resolved: checkout `11d5960a326750d5838078e36cf38b85af677262`, setup-go `40f1582b2485089dde7abd97c1529aa768e1baff`.
- Uncertainty: I did not verify those SHAs against the action repositories, which are outside this session's GitHub scope. They are what GitHub's runner printed.

**F7. The stated reason for one skip is wrong, and that test is a one-line port**
- Type / severity: documentation gap / **low**.
- Path: `go.yml:49-50` says "sudo-visible SPIRE socket path on the operator host".
- Evidence: the failure comes from the test's own fake `sudo`, which runs BSD `stat -f '%Lp'` before GNU `stat -c '%a'` (`remote_alpha_operator_test.go:4022`). On GNU, `stat -f '%Lp' <dir>` prints filesystem information and exits non-zero, so the captured mode is multi-line garbage (I ran that line on its own). Inference: the fake's restoring `chmod` then fails, and the script reports `spire_socket_parent_missing`. As a non-root user in my container the test fails with the runner's exact classification. With the two `stat` calls swapped in a scratch copy, it passes.
- Suggested correction: port it in the repair (it then leaves the list), or correct the comment.

**F8. `cancel-in-progress` also cancels `trunk_dev` push runs**
- Type / severity: design gap / **low**.
- Path: `go.yml:17-19`. Two merges in quick succession leave the first commit with a cancelled run and no result.
- Suggested correction: `cancel-in-progress: ${{ github.event_name == 'pull_request' }}`.

**F9. The restored build cache is not verified (observation)**
- `actions/setup-go` restores both the module cache and the Go build cache (`cache: true` in the log). `go mod verify` covers the module cache: I altered one extracted source file in a throwaway module cache and `go mod verify` exited 1 with `dir has been modified`. Nothing verifies the build cache. GitHub scopes caches so that a pull request cannot write a cache that `trunk_dev` or another pull request restores, so I rate this an observation. `cache: false` would remove the question at the cost of build time.

**F10. Governing documents do not mention CI (observation)**
- `.docs/system_overview/go_toolchain_baseline.md:101` lists "no CI system introduced" among that document's non-claims, and `PLANS.md:89` says source publication is not "a CI-pass claim". Neither is contradicted, because both are scoped to their own tranche. No document records that CI now exists, what it gates, or that 17 tests are excluded. The root docs contract tests still pass in the gated run.

### Pre-existing issues exposed by this work (not defects of PR #14)

**P-A. Several custody tests pass on the runner without reaching the check they are named for**
- Type / severity: test gap / **medium**.
- Evidence: the TLS status bootstrap refuses any caller whose `SUDO_USER` account is not `ds` with matching uid and gid (`scripts/remote_alpha_operator.sh:2103-2113`). On a host where the test process is not `ds`, every "must refuse" case passes at that first check. Mutation test: I inserted one line before the collector digest comparison that makes it always succeed, leaving the pinned source text in place. Run as a non-`ds` user with the gate's exact skip pattern, the root package gave **identical results for all 2,178 test and subtest outcomes** against the unmodified tree. Run as user `ds`, the same mutant failed `…StageRegularScriptSubstitution/regular_swap` and `/same_size`, `…RootLoadedStageCustody/digest`, and `…FailureWitnessBootstrapOwnedTerminal/*/source_mismatch`. A cruder mutant that deleted the comparison was caught by two source-text tests, so the text is pinned but the behaviour is not.
- Impact: `TestRemoteAlphaESServiceTLSStatusStageRegularScriptSubstitution` is in the gate and green, yet on the runner it cannot detect a broken digest check. A green CI overstates coverage of the operator-host custody code.
- Limits of this evidence: my container is not the GitHub runner. There the `ds` account does not exist at all; in my container it existed and the tests ran as a different user. Both cases stop at the same identity check. Two root tests (`…ByteStableUnicodeDelimiterMatrix`, `…ByteStableFalsePositiveMatrix`) fail in my container in both runs because it lacks the `en_US.UTF-8` locale, so they could not vote; they concern token privacy refusals, not the bootstrap. Only root-package test files reference the operator script.
- Suggested correction: see the porting path in section 7.

**P-B. Inference: the runtime security boundary checker reports an absent systemd unit as an observed, root-managed service**
- Type / severity: bug in a diagnostic script / **low**.
- Path: `scripts/internal/remote_alpha_runtime_security_boundary_check.sh:207-236`. `service_show` treats exit 0 from `systemctl show <name>` as an observation and defaults an empty `User` to `root`.
- Evidence: on the runner, which has no Vault or Nomad service that I know of (Guess), `vault_service_account_posture` was not in `not_evaluated`, and the Nomad surfaces reported "one combined nomad.service observation". That is the failure of `TestRemoteAlphaRuntimeSecurityBoundaryCheckMissingToolsStayHonest` in the log.
- What would confirm it: on any systemd Linux host, `systemctl show no-such-unit --property=User,Group,UMask,FragmentPath,ExecStart --no-pager; echo $?` printing exit 0. I could not run this: my container has no systemd, and there the test passes.
- Impact: the skip is environment-bound (the test assumes `/usr/bin:/bin` has no working `systemctl`), but it also hides this behaviour on the platform the checker is written for. No effect on the Remote Alpha host as long as its Vault and Nomad units exist.

**P-C. `go vet` was already failing at `trunk_dev` on macOS (observation)**
- `GOOS=darwin GOARCH=arm64 go vet ./es/admission/` at `ae326b0` reports the same copylocks finding the patch fixes. Inference: `go vet ./...` has not been part of local validation.

**P-D. One timing-sensitive test failed once under load (observation)**
- `TestRemoteAlphaESServiceTLSStatusCombinedGroupSignalFailureLiveDescendant/term` failed once in my container while a build ran alongside it, then passed 10 of 10 on an idle host on both trees. It passed on the runner. The gate has been green on the runner exactly once, so its stability is not yet known.

**P-E. Some `es/admission` tests depend on the process umask (observation)**
- Details in section 10. Under umask 0002 they fail; under 022 they pass.

## 7. The 17 skipped tests

"Reproduced" means I made the test fail and pass in my container by changing only the named host condition.

| # | Test (package) | Host condition it needs | How I know | Port |
|---|---|---|---|---|
| 1 | `TestRemoteAlphaESServiceTLSStatusFailureWitnessBootstrapOwnedTerminal` (root) | Test process runs as an account named `ds` | Runner log: `reason=caller_identity_unproved`. Reproduced: fails as user `ci`, passes as user `ds` | Run as `ds` |
| 2 | `TestRemoteAlphaESServiceTLSStatusRootLoadedStageCustody` (root) | `ds`, plus `/private/tmp` for one subtest | Runner log. Reproduced: as `ds` only `private_tmp` fails; with `/private/tmp` all 15 pass | `ds` and `/private/tmp` |
| 3 | `TestRemoteAlphaESServiceTLSStatusStageFIFOSubstitution` (root) | `ds` | Reproduced | Run as `ds` |
| 4 | `TestRemoteAlphaOperatorRecoverySessionESTLSStatusStageFIFORefusal` (root) | `ds` | Reproduced | Run as `ds` |
| 5 | `TestRemoteAlphaOperatorRecoverySessionESTLSStatusRemoteWrapperTrap` (root) | `/private/tmp` (the test rewrites `/tmp` to the macOS path, `remote_alpha_operator_test.go:6571-6573`) | Runner log: `mkdir /private/tmp/…: no such file or directory`. Reproduced: passes for any user once `/private/tmp` exists | Use `/tmp` on Linux |
| 6 | `…PrepareSpireBundleReadClassifiesTraversalAmbiguityWithSudoVisibleInspection` (root) | BSD `stat` in the test's fake `sudo` (F7) | Reproduced, including the fix | One line |
| 7 | `TestRemoteAlphaP0tGrammarDiagnosticBootstrapLifecycleComposition` (root) | `ds` account (`remote_alpha_p0t_grammar_diagnostic_test.go:808`) and `/private/tmp` (`:832`) | Runner log: `getpwnam(): name not found: 'ds'`. Reproduced | `ds` and `/private/tmp` |
| 8 | `TestRemoteAlphaP0tGrammarDiagnosticPriorReaderCloseSuppression` (root) | Same as 7 | Reproduced | Same |
| 9 | `TestRemoteAlphaP0tGrammarDiagnosticV2VersionedBootstrap` (root) | Same as 7 | Reproduced | Same |
| 10 | `TestRemoteAlphaRuntimeSecurityBoundaryCVE31431UnprovedMitigationStaysVulnerable` (root) | Host has no `algif_aead` block in `/etc/modprobe.d`, `/lib/modprobe.d` or `/usr/lib/modprobe.d`; the checker reads those real directories (script lines 731-742) and the fixture cannot override them | Reproduced: adding a blacklist file gives the runner's exact message, `mitigated_not_fixed` | Make the policy directories injectable |
| 11 | `TestRemoteAlphaRuntimeSecurityBoundaryCVE31431VulnerableWithoutMitigationBlocks` (root) | Same as 10 | Reproduced | Same |
| 12 | `TestRemoteAlphaRuntimeSecurityBoundaryCheckMissingToolsStayHonest` (root) | No working `systemctl` in `/usr/bin:/bin` (test `PATH`, `remote_alpha_runtime_security_boundary_check_test.go:1026`) | Runner log plus source. **Not reproduced** (no systemd here). See P-B | Fake `systemctl` in the fixture |
| 13 | `TestSupportedLocalSetupExactGoPreflightBeforeMutation` (es/app) | No `go` in `/usr/bin:/bin:/usr/sbin:/sbin` (harness `PATH`, `operator_scripts_integration_test.go:3535`) | Runner log: `observed go1.26.11`. Reproduced with a `/usr/bin/go` symlink: 1 of 4 subtests fails | Skip one subtest, or use a `PATH` without system directories |
| 14 | `TestSupportedLocalProofExactGoPreflightBeforeMutation` (es/app) | Same as 13 | Reproduced | Same |
| 15 | `TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation` (reliablesubmit) | `ES_REPLAY_SCHEMA3_PROBE` pointing at a test binary built from an older tree with an out-of-repo overlay (`sqlite_replay_shape_test.go:18-21`, `:49`) | Source and runner log | Bring the probe source into the repo |
| 16 | `TestSQLiteV3OldBinaryRefusesWithoutMutation` (reliablesubmit) | `ES_REPLAY_PB1_PROBE` (`:119-122`) | Source and runner log | Same |
| 17 | `TestOperationalHandoffSchema4BinaryRefusesSchema5` (reliablesubmit, PR #12 only) | `ES_REPLAY_SCHEMA4_PROBE` | Source at `8058561` and `e544e0f`; see section 10 | Same |

None of the 17 fails on the runner because product code misbehaves there. The runner's first run (44977760492, at `d886bb8`) had 28 failing top-level tests: these 16, plus 12 source-guard tests that all reported `module lookup disabled by GOPROXY=off` and all pass at `145ab62`. In run 44978229993 the non-blocking step failed on exactly the 16 names that exist, and the gating step printed 21 `ok` package lines and no failure.

**Two things David should know about what the list costs:**

- Tests 15 to 17 are the "an older binary refuses a newer schema and changes nothing" checks for the reliable-submit store. That is durable-state safety for the work in PR #12. A green CI does not cover it. Those three still have to be run on the Mac with the probes for any reliable-submit tranche.
- **A porting path for 8 of the 17 exists and I ran it.** With a local account named `ds` and a `/private/tmp` directory of mode 1777, tests 1 to 5 and 7 to 9 all pass on Linux when the test process runs as `ds` (9 of 9 in the focused run, which included the gated `…StageRegularScriptSubstitution`). With test 6's one-line fix that makes 9 of the 12 root-package entries portable, and it also closes P-A for those tests, because as `ds` they reach the checks they are named for. Not established: whether the whole root package passes when run as `ds` on the GitHub runner.

## 8. Red-team log

All "gate" runs below execute the `run:` text of the workflow's Test step, extracted from `go.yml` at `145ab62` and run with `bash -e`, with the job's `GOFLAGS` and the exact `ENVIRONMENT_ONLY_TESTS` value, on a synthetic three-package module. Go 1.26.5.

| ID | Attack | Gate exit | Outcome |
|---|---|---|---|
| R1 | New failing test with a listed name in a different package | **0** | **Bypass (F1)** |
| R2 | Listed name plus suffix (`…MutationV2`) | 1 | Held |
| R3 | Listed name with a prefix (`TestX…`) | 1 | Held |
| R4 | Failing subtest whose name is a listed name, under an unlisted parent | 1 | Held |
| R5 | Case variant (`TestSqlite…`) | 1 | Held |
| R6 | Failing `Example` | 1 | Held |
| R7 | Failing fuzz seed | 1 | Held |
| R8 | Compile error in a test file | 1 | Held |
| R9 | `init` panic in a package whose only test is a listed name | 1 | Held |
| W1 | Append entry `Test.*` | **0** (every test skipped) | **Bypass (F2)** |
| W2 | Append entry `TestReal.*` | **0** | **Bypass (F2)** |
| W8 | Append entry `TestFoo\|TestRealRegression` | **0** | **Bypass (F2)** |
| W3 | Empty list | 1 | Fails safe: nothing is skipped |
| W4 | Leading and trailing spaces | 1 | Held |
| W5 | Newline-separated list (literal instead of folded YAML scalar) | 1 | Fails safe: nothing is skipped |
| W6 | Tab-separated list | 1 | Fails safe |
| W7 | Entry containing `/` | 1 | Held: it does not select a subtest or skip the parent |
| M1 | Delete the collector digest comparison in the root bootstrap | n/a | Caught: two gated source-text tests newly fail |
| M2 | Make that comparison always succeed, text unchanged | n/a | **Not detected on a non-`ds` host: all 2,178 outcomes unchanged (P-A)** |
| C1 | Tamper with one file in the module cache | n/a | Held: `go mod verify` exits 1 |

The writer's four red-team questions:

- *Can `-skip` skip more than the 17 names?* Yes, across packages (R1) and through regex entries (W1, W2, W8). Subtest paths and odd whitespace are safe.
- *Does `continue-on-error` hide a regression inside a listed test?* Yes, by design, and it also hides the 21 passing subtests of F4.
- *Are `-mod=readonly` and `go mod verify` enough against a dependency swap through the cache?* For the module cache, yes (C1). The build cache is unverified (F9).
- *Does the reflect copy equal `*service`?* Yes. `reflect.Value.Set` assigns the whole struct, unexported and lock fields included. A small stand-alone program confirmed pointer-identical fields and `DeepEqual`.

**Coverage the environment could not provide:** no run on a GitHub runner (I may not push or re-run); no macOS run; no systemd host; no fork pull request; no look at branch protection or Actions settings.

## 9. Repair sketch (for the implementation thread; advisory)

Status: I ran exactly the script below as the gating step of a two-package synthetic module. It failed the R1 collision, refused the W1 and W8 entries before running any test, and passed a clean tree. I did **not** run it on the real tree or on a runner, and the extension to three packages is untested.

```bash
set -f
check_names() {
  local n
  for n in $1; do
    if [[ ! "$n" =~ ^Test[A-Za-z0-9_]+$ ]]; then
      echo "::error::environment-only list entry is not a plain test name: $n"
      return 1
    fi
  done
}
pattern_of() { printf '^(%s)$' "$(printf '%s' "$1" | tr -s ' ' '|')"; }
check_names "$ENV_ONLY_ROOT"                      # one list per package
module="$(go list -m)"
go test -count=1 -skip "$(pattern_of "$ENV_ONLY_ROOT")" .
others="$(go list ./... | grep -vxF -e "$module")"   # every package without a list
go test -count=1 $others
```

For the real workflow, repeat the `check_names` and `go test -skip` pair for `./es/app/` and `./es/admission/internal/reliablesubmit/`, and exclude all three packages from `others`.

Two traps to avoid. Validating inside `$(…)` on the `go test` line does not stop the step, because `bash -e` ignores a failing command substitution in an argument; validate in its own statement, as above. And compute `others` in an assignment, not inline: if the list came back empty, `go test` with no package argument would test only the current directory and pass.

For F4, Go accepts a subtest path as one alternative, for example `-skip '^TestWholeEnvOnly$|^TestSetupPreflight$/^rejects_missing_Go$'`. On the synthetic module that skipped only the named subtest and ran its siblings. Spaces in subtest names become underscores.

A repair changes the workflow bytes, so it needs new provenance and a fresh audit of the whole base-to-tip range (provenance §5.5).

## 10. Validation assessment

**Re-run by me, on the exact audited bytes (tree `b27b5c51…`), in my container, linux/amd64, Go 1.26.5:**

| Command | Result |
|---|---|
| `go mod download && go mod verify` | `all modules verified` |
| `go build ./...` | exit 0 |
| `go vet ./...` | exit 0 |
| `go vet ./...` at base `ae326b0` | exit 1: the two `Stat_t.Mode` type errors (`replay_custody_file_test.go:1210`, `:1214`) and the copylocks finding (`result_auth_test.go:395`). This confirms both test-file changes were needed and that the vet step bites |
| `GOOS=darwin go vet ./es/admission/ ./es/admission/internal/reliablesubmit/` (arm64 and amd64) | exit 0 at tip. The two changed test files type-check for macOS |
| `git diff --check`; `gofmt -l` on the two changed files | clean |
| Gate skip pattern on the root package, as non-root user `ci`, real git checkout | 449 top-level tests ran (461 minus the 12 listed). 447 passed. The 2 failures are `…ByteStableUnicodeDelimiterMatrix` and `…ByteStableFalsePositiveMatrix`, whose failing leaves are the `en_US.UTF-8` cases; my container has only `C`, `C.utf8` and `POSIX` (Inference: locale-bound). Both pass on the runner |
| Gate skip pattern on every other package (`./es/... ./ags/... ./ars/... ./cgs/... ./egs/... ./internal/...`), as `ci`, umask 022, no proxy variables | exit 0; all 20 test-bearing packages `ok` |

So I reproduced the gate on the audited tree in my own environment for every package, except those two locale-bound root tests.

**The PR #12 entry (name 17), checked on a trial merge.** In a scratch clone I merged `145ab62` into PR #13's head `e544e0f` (local merge `f7083dd`, never pushed). It merged without conflict. `go build ./...` and `go vet ./...` exit 0. The gate pattern on `./es/...` exits 0 with all 10 packages `ok`, including `es/admission` and `reliablesubmit` with PR #12's tests. Running only the listed names in `reliablesubmit` fails on exactly tests 15, 16 and 17, each with its "probe is required" message. So the 17th entry is correct and sufficient for those packages. Not run on the merged tree: the root package.

**A Linux gotcha found on the way (pre-existing, observation P-E).** Under umask 0002, which my test accounts had by default, 3 `es/admission` tests fail at `145ab62` ("retained result authentication key parent is unsafe") and 23 fail on the merged tree (the PR #12 ones with "private replay: unavailable"). I isolated the cause by changing only the umask: with 022 they pass, with 0002 they fail. Inference: the product refuses group-writable directories, as designed, and the tests inherit the process umask. Guess: the GitHub runner uses umask 022, which fits its green run. Anyone running the suite on the Linux box should set `umask 022` first. Separately, 7 `es/app` script tests fail in a cloud container whenever proxy variables are set, which the writer had already noted; that is a property of these containers, not of the runner.

**Not re-run:** the workflow on a GitHub runner. For that I rely on the logs of runs 44977760492 and 44978229993, which I read in full for the steps that matter rather than taking the writer's summary. They match the writer's account: toolchain `go1.26.5`, `all modules verified`, 21 `ok` lines and no failure in the gating step, and exactly the 16 existing names failing in the non-blocking step.

**The two test-file changes:** both are correct and neither weakens a test. `probeMode` yields the same bits as the old expression on both platforms (on macOS it is `uint16(S_IFDIR | 0o700 | special)`, as before). The reflect copy is the same struct copy as `*service`.

## 11. Closing state

- Recipe hash re-verified. Closing manifest run twice after all experiments: byte-identical, and `cmp`-equal to the opening manifest (`d9f5fe14…84b2`, 3 files, textual diff `c65fdafd…5367`).
- Audit clone: HEAD `ae326b0…`, branch `claude/project-thread-sqldt7-ci`, upstream `origin/trunk_dev`, nothing staged, no stash. Every experiment ran on copies elsewhere, so there were no audit artifacts to remove from the clone.
- Re-fetched at closeout: `origin/trunk_dev` is still `ae326b0…` and the topic branch is still `145ab62…`.
- Nothing was pushed, commented, re-run or merged.

## 12. Unknown, and what would settle it

- **Unknown: whether this check is required for merging.** `trunk_dev` is a protected branch (GitHub branch list), but I cannot read its rules. Unless "build, vet and test" is a required status check, the workflow informs and does not gate. David can see this under the repository's branch protection or ruleset settings. If it is made required before PR #12 picks up `trunk_dev`, PR #12 and PR #13 will wait on a check that never reports, because their merge commits do not contain the workflow.
- **Unknown: whether fork pull requests need approval before workflows run.** It is a repository Actions setting.
- **Unknown: what `trunk_dev_secondary` (protected) is for.** It gets no push runs.
- **Not verified:** that the runner-printed action SHAs in F6 are the official tag targets.
- **Not observed:** a push-triggered run, a second green run, any run from a fork.
- **Not run on macOS:** `TestReplayExistingStateModeNotRepaired` and `TestRetainedResultAuthReaderNeedsVerifierEvenForExistingPair` after the change. Cross-compiled vet passes. To confirm on the Mac: `go test -count=1 -run 'TestReplayExistingStateModeNotRepaired|TestRetainedResultAuthReaderNeedsVerifierEvenForExistingPair' ./es/admission/...`.
- **Guess:** the runner image has Go 1.26.11 at `/usr/bin/go` and an `algif_aead` block in its modprobe configuration. Both are read off test output, not inspected.

## 13. Sensitive-material handling

No secrets, keys, tokens or environment files were read or copied. The runner logs mask the token as `***`. Signed log-download URLs returned by the GitHub tool are not reproduced here. This report contains no personal data.

## 14. Confidence

- **Provenance: high.** Reproduced twice, byte-identical, equal to the report, and the CI merge commit has the audited tree.
- **Validation: medium to high.** Build and vet re-run by me on the exact bytes. The runner result is read from GitHub's logs, one green run.
- **Implementation: high for the mechanics** (triggers, permissions, toolchain, failure propagation, the two test fixes); **not acceptable yet for the skip mechanism** (F1, F2), which is why the verdict is BLOCK.

## 15. Report delivery

Path: `/mnt/project-files/reports/Execution-Substrate/ci-go-workflow/02-audit-redteam.md`. Its SHA-256 is given in the delivering thread reply.

**Final verdict: BLOCK**
