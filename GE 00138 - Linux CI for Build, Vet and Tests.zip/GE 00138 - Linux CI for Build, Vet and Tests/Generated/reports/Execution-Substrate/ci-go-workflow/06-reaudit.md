# INDEPENDENT RE-AUDIT AND RED-TEAM REPORT: Execution-Substrate PR #14 (Linux CI) at `c4a84f5`, and PR #16 (lock-timing test) at `0a069ec`

**Final verdict, PR #14: BLOCK**
**Final verdict, PR #16: ACCEPT**
**Effect status:** REPAIR_NOT_PERFORMED · COMMIT_NOT_PERFORMED · PUSH_NOT_PERFORMED · PR_NOT_MODIFIED · NO_COMMENT_POSTED · MERGE_NOT_PERFORMED · read-only on both targets throughout

One fresh thread did both jobs the brief asked for, for both targets: the correctness audit and the red-team pass. It wrote none of the patches and none of the repairs. It used no subagents.

All times are UTC on 2026-11-22.

## 1. Verdict in short

### PR #14 (CI)

The second repair does what it set out to do. The three blockers of `04-reaudit.md` are fixed as they were filed. I confirmed each one on the real tree, by planting the fault in a scratch clone and running the real gate with the real list:

1. **RF-1, the same test name defined twice in one package.** Both steps refuse the list with status 2 before any test runs.
2. **RF-2, nothing forced a list line out.** The new third step is blocking. It fails and names the line when a listed test passes, skips itself or does not run.
3. **RF-3, the `es/app` subtests.** The two lines now name the one failing subtest. The three other subtests of each test run in the gate, and a failure planted in one of them turns the gate red.

Build, vet, the self-check (56 of 56) and the complete gate pass on the exact audited bytes in my own container. The green runner run tested exactly the audited tree.

**It is still blocked, for one reason that I found while trying to break it:**

**F-1. One list line can still take more than one subtest out of the gate, and both blocking steps stay green.** `go test` reads a skip pattern level by level and splits it at every `/`. A line for subtest `X` of a test therefore also skips every other subtest of that test whose own name starts with `X/`. The still-failing step looks only at `X` itself, so it sees nothing wrong.

- I ran it on the real tree with the real list, unchanged. I added one failing subtest to a real `es/app` test, named so that it falls under today's list line. The whole gate exited 0 and printed `test gate passed`. The still-failing step judged the line `still fails`.
- This repository names subtests that way all the time. Of the 3,867 subtests that ran in my container, at least 1,059 have a `/` inside their own name. One real test already has the exact shape today: `TestFiveEvidencePayloadsAndLocalRefusals` runs five subtests named after a kind and thirteen more named `<kind>/<key>`.
- **Today's 15 lines are not affected.** I checked each one. So the green check on `c4a84f5` means what it says. The hole opens with the next subtest line of that shape, or with the next subtest added under an existing line, and nothing would bring it to anyone's attention.

This is the same property as the first earlier blocker ("one line never skips two tests"). The gate's own text, the list header and the governing doc all promise it. The part that a run can see has a small fix. One corner cannot be seen by any run, and section 12 says which and why.

**Four smaller items belong in the same repair (all low):**

- **F-2.** A subtest whose own name holds a `/` cannot be listed at all. The gate step refuses the line with a wrong reason, and the still-failing step accepts the same line.
- **F-3.** The still-failing step judges all listed tests of a package in one process. A line whose test would pass on its own can hide behind another listed test that runs first.
- **F-4.** The self-check says the three steps "cannot be switched off". Twelve edits to the workflow file that switch a step off or weaken it pass the self-check and the docs test.
- **F-5.** Both pinned actions target Node.js 20, which the runner already overrides with a warning. Releases that target Node.js 24 exist today. The writer's report defers the pin update to "later", which the project rule does not allow.

Nothing here makes a merge dangerous to the repository. There is still no write path and no secret. As in both earlier audits, the block is about what a green check can be trusted to mean.

### PR #16 (lock-timing test)

**ACCEPT.** The change is test-only and does what the earlier re-audit asked for: the helper process holds the database lock until the test closes a pipe, so the lock can no longer end before the test gets to it. On a scratch merge with PR #14: 100 of 100 plain runs pass, 20 of 20 pass under forced stalls (the unchanged test fails 3 of 20 under the same stalls), and the helper exits within 50 ms when its parent is killed outright, in 10 of 10 rounds. Under the race detector the test passes 10 of 10 runs with no race reported.

### Not covered

**Nothing was run on macOS.** The Mac run (RF-4) is still open for PR #14 and has not been done for PR #16. Because PR #14 needs one more repair, I recommend that David runs the Mac check once, on the repaired head, and not on `c4a84f5`.

## 2. Audit targets

### PR #14

| Field | Value |
|---|---|
| Repository | `evo-agi/Execution-Substrate` |
| Pull request | #14, draft, branch `claude/project-thread-sqldt7-ci` into `trunk_dev` |
| Base SHA | `ae326b0ddc30ec6b35883ee32945c622405b68b6` (`origin/trunk_dev`) |
| Topic commit SHA | `c4a84f5695500cca2087abefb8027afd700f35e2` (4 commits: `d886bb8`, `145ab62`, `fada999`, `c4a84f5`) |
| Tree SHA | `a05a25a6db5fe1d51819f16a28a9f18132667ccf` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` |
| Canonical manifest SHA-256 | `cf8c159ff17baff1096fe7d8c41fa86ebd8ba97bd1e7e635fb057d64860908f7` (2,033 bytes) |
| Textual diff SHA-256 | `f384ac8faa1c2456a436da2ff3b79efc3a4d28f8db722815b5b7458074915a6a` |
| Changed paths | 9, all regular files with mode 0644 |
| Writer's report | `05-repair.md`, SHA-256 `1e123a5fcd0c8d3f3a21a256738a990eaeeb0548a88d6d72ed4211432962e4c8` (verified before reading) |

The nine paths: `.docs/system_overview/go_toolchain_baseline.md`, `.github/ci/environment-only-tests.txt`, `.github/ci/go_test_gate.py`, `.github/ci/go_test_gate_selftest.py`, `.github/workflows/go.yml`, `docs_contract_test.go`, `es/admission/internal/reliablesubmit/replay_custody_file_test.go`, `es/admission/result_auth_test.go`, `remote_alpha_operator_test.go`.

### PR #16

| Field | Value |
|---|---|
| Pull request | #16, draft, branch `claude/project-thread-k69qcw` into `trunk_dev` |
| Base SHA | `ae326b0ddc30ec6b35883ee32945c622405b68b6` |
| Topic commit SHA | `0a069ecbe53c842d33c932f63aed2af523e2eb0c` (1 commit) |
| Tree SHA | `0b327b54deb9b880a748851fc4248bf3e3531809` |
| Canonical manifest SHA-256 | `b14b8ac19ba92beb3a218df837cd8315ea959fc0544d57f170aa12fbe0c936a2` (501 bytes) |
| Textual diff SHA-256 | `2504375ef8b14da68ac600b1870a049fbb1eb0ff1c03dd3d67fd8cba23c6d467` |
| Changed paths | 1: `es/admission/internal/reliablesubmit/sqlite_physical_test.go` (+24, −3), mode 0644 |

## 3. Audit posture

- **Read-only.** I edited nothing in either target, formatted nothing, committed nothing, pushed nothing, posted no comment or review, re-ran no workflow and merged nothing.
- **One thread, no subagents.** The protocol's audit roles were done by this one thread. That is a deviation from §5.2: this thread uses subagents only when they are asked for, and the brief did not ask.
- **Where the work ran.** A cloud container, linux/amd64, 4 CPUs, Go 1.26.5 with `GOTOOLCHAIN=local` and `GOFLAGS=-mod=readonly`, an unprivileged user `ci`, umask 022, no proxy variables during tests, and `/usr/bin/go` pointing at another Go version, as on the runner image.
- **Side effects, all inside the container.** Two audit clones that I never modified (`/home/user/Execution-Substrate` for PR #14, `/root/audit/ES16` for PR #16). Scratch clones for runs, planted faults and local merges, none of them pushed. Throwaway Go modules for probes. One read-only fetch of `refs/pull/14/merge`. Read-only tag listings and shallow clones of `actions/checkout` and `actions/setup-go`.
- **Red-team scope.** Only David's repository and throwaway modules in my container. Nothing was sent to a live service or a third party.

## 4. Provenance reproduction

Recipe file hash checked before use: `c08597e2…a3ca`, as expected.

For each target: a fresh clone, the topic branch checked out under its own name, `HEAD` moved to the base with `git reset --mixed`, upstream pinned to `origin/trunk_dev`, nothing staged. Then the recipe was run twice and the two outputs compared with `cmp`.

| | PR #14 | PR #16 |
|---|---|---|
| Opening run | 07:42:06, two runs byte-identical | 07:42:24, two runs byte-identical |
| Manifest SHA-256 | `cf8c159f…08f7` | `b14b8ac1…36a2` |
| Equals the writer's evidence file | yes (`manifest-cumulative.json`) | yes (`manifest-lock-test-fix.json`) |
| Equals the SHA in `05-repair.md` | yes (line 467) | yes (line 479) |
| Closing run | 08:57:30, two runs byte-identical, equal to the opening manifest | 08:57:30, two runs byte-identical, equal to the opening manifest |
| Mode-bit differences tolerated | none | none |

`refs/pull/14/merge` is `9ead58f5c8f0e0a9bd481936cbdcb72ebb0fb5d7`, with parents `ae326b0` and `c4a84f5` and tree `a05a25a6…7ccf`. That is the tree of the topic commit, so the runner checked out exactly the audited bytes.

**No provenance mismatch on either target.**

## 5. The three earlier blockers, re-checked

Each row was confirmed four ways: by reading the code, by the self-check, by the runner log, and by planting the fault on the real tree (scratch clone at `c4a84f5`, real gate, real list).

| Blocker | What the repair does | My planted fault on the real tree | Result |
|---|---|---|---|
| **RF-1.** One line skipped two tests when a package defined the name in its internal and its external test package | `check_list` asks `go test -list '^Test'` and refuses a name that is printed more than once (`go_test_gate.py:258-270`) | P-b: a second `TestSQLiteV3OldBinaryRefusesWithoutMutation` in `package reliablesubmit_test` | Both modes exit 2 with `defined 2 times … one entry would skip all of them`. No test run started. |
| **RF-2.** Nothing forced a line out of the list | New mode `still-failing` and a third blocking step (`go.yml:84-85`). Exit 0 only if every entry fails | P-c: the listed `TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation` made to skip itself | Exit 1, the line is named with `(it skips itself)`. The three lines that pass in a container such as mine are named with `(it passes)`. |
| **RF-3.** Six passing `es/app` subtests were outside the gate | The two lines name the one failing subtest. The gate checks that the parent ran and prints which other subtests ran | P-a: `t.Fatal` planted in the sibling `local_build_path_rejects_wrong_Go_before_mutation` | Whole gate exits 1. Only `execution-substrate/es/app` fails. The 20 other test packages print `ok`. |

Runner log, run 44996283604, job 137127901877, image `ubuntu-24.04` 20261116.376.1. My own download is byte-identical to the writer's copy (SHA-256 `1aa40d493e6a0d8e92025e7ad9f6a1a727422cee9001c27655774c527e57d03e`, 651 lines). It shows: no error annotation; `Ran 56 tests in 45.195s`, `OK`; `test gate passed: 41 packages, 3 of them with skipped entries (15 entries)`; two lines `ran without its listed subtest`, each naming three other subtests that pass; 15 lines `still fails:` and `all 15 listed tests still fail on this host`.

**Subtests under whole-test lines, counted from the runner log.** Only the two custody tests that the list keeps whole on purpose have passing subtests on the runner: `…FailureWitnessBootstrapOwnedTerminal` (22 subtests, 4 pass) and `…RootLoadedStageCustody` (15 subtests, 11 pass). `…StageFIFORefusal` (2 of 2 fail) and `…RemoteWrapperTrap` (6 of 6 fail) have none. The other nine whole-test lines started no subtest on the runner. So the list is as narrow as its header says, with the two documented exceptions.

**The reason given for those two exceptions holds.** `scripts/remote_alpha_operator.sh:2096-2118` refuses a caller that is not the account `ds` at its first identity check, so a subtest that expects a refusal passes without reaching the custody check it is named for.

**But the first blocker's property is not fully there yet.** RF-1 as filed is fixed. The sentence the coordinator asked me to confirm, "one line never skips two tests", is still false in one layout. That is F-1.

## 6. Findings

### Patch defects

**F-1. One line for a subtest also skips every other subtest whose own name begins with that name and a `/`; no step notices**

- ID / Type / Severity: F-1 / gate bypass / **medium**. Blocking.
- Current contract: `go_test_gate.py:23-24` and `environment-only-tests.txt:10-11`: "An entry applies only to the package it names, and to exactly one test or subtest of it." `.docs/system_overview/go_toolchain_baseline.md:109-110`: the gate "skips exactly those entries".
- Path and line: `go_test_gate.py:135-147` (`exact_paths`), `:289-320` (the check of a gated run), `:386-394` (the still-failing verdict).
- Mechanism: `go test` splits a test name at every `/`, whether the `/` came from nesting or from the name passed to `t.Run`. A skip pattern with n levels matches every name whose first n levels match. So `-skip '^TestP$/^reg$'` skips the subtest `reg` and also the separate subtests `reg/custody` and `reg/identity` of `TestP`. In the gate step nothing shows it, because a skipped test prints nothing. The line `ran without its listed subtest … its other subtests: …` lists only what ran. In the still-failing step the hidden subtests do run, but the step reads only the verdict of `reg`.
- Evidence, throwaway modules (`rt6c.py`, output `rt6c.log`):
  - S9: `reg` fails for the host, `reg/custody` and `reg/identity` pass. Gate exit 0, still-failing exit 0.
  - S9r: the same, and `reg/custody` now holds a real regression. Gate exit 0, still-failing exit 0.
  - S11: the line names the real nested subtest `TestP/reg/custody`, and `TestP` also runs a subtest named `reg/custody/deep` with a regression. Gate exit 0, still-failing exit 0.
  - S10, control: `custody` and `identity` are real subtests of `reg`. Same output. From the names alone the two cases cannot be told apart.
- Evidence, the real tree (P-d, `plant-d-run.log`, 08:18:30 to 08:26:33): a scratch clone at `c4a84f5` with the gate (`5eb758fc…4154`) and the list (`dffba480…552b`) unchanged. I added one subtest to the real `TestSupportedLocalSetupExactGoPreflightBeforeMutation` in `es/app/operator_scripts_integration_test.go`, named `local build path rejects missing Go before mutation/planted second subtest`, which fails (`plant-d.diff`).
  - Gate: exit 0, `test gate passed: 41 packages, 3 of them with skipped entries (15 entries)`. The line about the other subtests names the same three as before.
  - Still-failing: `still fails: execution-substrate/es/app TestSupportedLocalSetupExactGoPreflightBeforeMutation/local_build_path_rejects_missing_Go_before_mutation`. The planted subtest ran and failed in that step's own output, and nothing was said. (The step's exit status was 1 in my container only because of the three lines that pass in a container such as mine and fail on the runner, exactly as in the unplanted baseline.)
  - Control: the planted subtest run alone, with nothing skipped, fails.
  - Inference: on the runner both steps would be green. I could not run it there.
- How reachable it is in this repository (`names6.py` over one run of every package with `-json`, `names6.log`):
  - 1,397 top-level tests and 3,867 subtests started. At least 1,059 of the subtests have a `/` inside a name passed to `t.Run`: 865 in the root package, 59 in `es/admission`, 59 in `reliablesubmit`, 76 in `es/internal/outsideobserverprotocol`. The count is of subtests whose path one level up never started as a test of its own, which only a `/` inside a name can cause. It is a lower bound: it leaves out the shape of the next bullet, and 12 top-level tests fail early in a container.
  - The exact shape exists today in `es/internal/outsideobserverprotocol/validate_test.go`: `TestFiveEvidencePayloadsAndLocalRefusals` calls `t.Run(kind, …)` for five kinds (`:259`) and `t.Run(tc.kind+"/"+tc.key, …)` on the same parent (`:310`). A line for `…/SupervisorStartedV1` would take five subtests out of the gate, not one.
  - `es/admission` `TestValidateReservedRuntimePathsRejectsRuntimeIdentityWorkspaceOverlap` has the shape too, but its names start with `/`, so no line can name them.
- Today's list: not affected. The two subtest lines are in parents with four subtests each, none with a `/` in its name (source, and the runner's `ran without its listed subtest` lines). The other 13 lines name top-level tests, where the pattern has one level and matches one name.
- Impact: a regression in a subtest that nobody listed can be out of CI with both steps green and no line in the log. The same class as RF-1.
- Required correction: section 12, check 1.
- Uncertainty: none about the mechanism. One corner cannot be machine-checked (section 12).
- Patch defect. It arrived with subtest lines in `c4a84f5`. The earlier re-audit's sketch named the gap: "Not established by the sketch: … subtest names that hold characters outside letters, digits, `_` and `-`."

**F-2. A subtest whose own name holds a `/` cannot be listed, the two steps disagree about it, and the message is wrong**

- ID / Type / Severity: F-2 / wrong refusal, fails closed / **low**.
- Current contract: `environment-only-tests.txt:3-6`: a test path is a top-level name "followed by `/` and a subtest name as go test prints it, any number of times". `:20-21`: "Name the narrowest thing that fails."
- Path and line: `go_test_gate.py:292-301`.
- Evidence: S1 (`rt6-STU.log`). The subtest is created with `t.Run("reg/custody", …)`, the line is `synth/a TestP/reg/custody`. `go test` skips exactly that subtest. The gate step then exits 1 with `TestP/reg did not run, so nothing shows that the subtests beside the listed TestP/reg/custody ran`. There is no test `TestP/reg`. The still-failing step accepts the same line with exit 0. S8 (`rt6c.log`): in a module where only `reg/custody` and `reg/identity` exist, the line `TestP/reg` passes the gate step, where it skips both, and is refused by the third step with `(it did not run)`.
- Impact: CI goes red, not green, so nothing is hidden. But for the 1,059 subtests counted under F-1 (865 of them in the root package, which holds 11 of the 15 lines) the only line that works is the whole top-level test. That is the opposite of the header's rule, and the header does not say so. The real `…FailureWitnessBootstrapOwnedTerminal` names all 22 of its subtests this way (`<scope>/<mode>`, counted in the runner log).
- Required correction: section 12, check 2.
- Uncertainty: none.
- Patch defect.

**F-3. The still-failing step judges all listed tests of a package in one process**

- ID / Type / Severity: F-3 / missed stale line / **low**.
- Current contract: `go_test_gate.py:39-43`: "Exits 0 only if every entry fails. An entry that passes … no longer belongs in the list."
- Path and line: `go_test_gate.py:386-394`. An entry is asked again on its own only when the common run gave it no verdict.
- Evidence: T1 (`rt6-STU.log`). Listed test B passes on its own, and it would pass in the gate step, where listed test A is skipped. In the common run B fails after A. The step prints `still fails` for both and exits 0. Control T1c: without its line, B runs in the gate and passes.
- On the real tree: I ran each of the 15 lines on its own with the gate's own function (`alone.log`). The verdicts are the same as in the common run: 12 fail, 3 pass, in a container. So I saw no such case here. On the runner: Unknown.
- Impact: a line can outlive its reason when the listed tests of one package disturb each other. Inference from the list's own comments: the root package's listed tests share an account check and fixed staging paths, so this is not far-fetched.
- Required correction: section 12, check 3. My mutant A17 makes the gate judge every entry alone, and the committed self-check passes unchanged with it.
- Patch defect.

**F-4. The self-check says the three steps "cannot be switched off"; twelve edits that switch a step off or weaken it pass**

- ID / Type / Severity: F-4 / check weaker than its name / **low**.
- Path and line: `go_test_gate_selftest.py:957-990` (`WorkflowKeepsWhatTheGateDependsOn`, in particular `test_the_three_gate_steps_run_in_order_and_cannot_be_switched_off`), and the workflow lines in `docs_contract_test.go` (`TestGo1265ToolchainBaselineDocsAndBuildContract`). Both look at single lines of `go.yml`.
- Evidence (`wf6.py`, `wf6.log`): 22 edits of `go.yml`, each run against the self-check's workflow group and the docs test. All 8 controls are caught (`|| true`, `continue-on-error: true`, a tag pin, a job-level `if: false`, swapped steps, the removed third step, `cache: true`, `pull_request_target`). These pass both:
  - Switch a step off: X1 a step-level `env` that points the third step at an empty list; X3 the Test step under `shell: 'true {0}'`; X7 `continue-on-error : true` with a space before the colon; X11 `"if": false` with a quoted key; X15 a step that empties the list before the third step; X21 job-level `defaults: run: shell: 'true {0}'`.
  - Weaken the run: X2 `GOFLAGS` that also carries `-skip=TestRegression` (probes V2 and V3 show the gate obeys it for packages without entries); X4 and X22 `paths-ignore` on the triggers; X9 checkout by tag in flow style; X18 `permissions: contents: write`; X19 `persist-credentials: false` removed.
- Impact: each of these is a visible edit of a short file, so a reader of the diff can catch it. The self-check cannot, although its name says it can.
- Required correction: section 12, check 4.
- Patch defect.

**F-5. Both action pins target Node.js 20; releases for Node.js 24 exist; the report defers the update**

- ID / Type / Severity: F-5 / deferred item against the project rule / **low**.
- Path and line: `go.yml:42` (`actions/checkout@11d5960a… # v4.4.0`) and `:49` (`actions/setup-go@40f1582b… # v5.6.0`). `05-repair.md:428`: "A later pin update will be needed when the actions publish releases for the newer runtime."
- Evidence: runner log line 651: `Node.js 20 is deprecated. The following actions target Node.js 20 but are being forced to run on Node.js 24`. My own tag listing and shallow clones: `checkout` v4.4.0 declares `using: node20` and v7.0.1 (`3d3c42e5aac5ba805825da76410c181273ba90b1`) declares `node24`; `setup-go` v5.6.0 declares `node20` and v7.1.0 (`d8cbb8045d7f43706b9177cceb36c1f91a6644d5`) declares `node24`. I did not test the newer releases.
- The pins themselves are right: both SHAs are what the tags `v4`/`v4.4.0` and `v5`/`v5.6.0` point at (my own lookup).
- Impact: none today. The actions run on a runtime their release was not built for, and the report's sentence about waiting for releases is wrong on the facts.
- Required correction: section 12, check 5.
- Patch defect (of the report and of the choice of pins).

### Pre-existing issues

None new. P-F of the earlier re-audit (the lock test that depends on real time) is what PR #16 fixes.

### Observations (no correction required for a verdict)

- **O-1. "Name the narrowest thing that fails" is a rule for people only.** A whole-test line whose test has passing subtests satisfies both steps (S5). Today that is true of the two custody lines, on purpose and with the reason written down. For a new line it would bring RF-3 back without a signal. The cheapest step is to let the still-failing step print, for every whole-test line, how many subtests passed and failed. Whether a passing subtest under a whole-test line should fail the run, with a marker for lines that are whole on purpose, is a choice for the coordinator or David.
- **O-2. The gate obeys whatever `GOFLAGS` it inherits** (V2, V3). Only an edit of `go.yml` or of the runner environment can use this. A fix of F-4 covers it.
- **O-3. Limits that only hostile test code reaches, or that fail closed.** A `TestMain` that exits 0 after a failure passes the gate, as it passes plain `go test` (T7; the repository has no `TestMain`). A `TestMain` that answers `-test.list` itself can hide a double definition (U2). A name printed on stdout from `init()` is refused with a misleading reason (U1). A subtest called twice with the same name gets `#01` from `go test` and cannot be listed (S4). A top-level test named exactly `Test` cannot be listed (W03).
- **O-4. `es/admission/result_auth_test.go`** copies a struct by reflection where it used to copy by assignment. That hides a lock copy from `go vet` and does not remove it. Both earlier audits accepted it for a test. Unchanged.
- **O-5. Eleven of my 39 mutants survive the self-check.** None of them opens the gate (section 8.4).

## 7. The project rule: no "revisit later", and a machine-enforced trigger for every temporary edge

| Item | Judgement |
|---|---|
| The list itself, this PR's temporary edge | **Has its trigger**: the third step. It holds for the three cases RF-2 named. F-1 and F-3 are the two ways around it that I found. |
| The Mac run (RF-4) | **Open, and a merge condition.** `05-repair.md` 7.6 says it was requested and not done. It is not a "later" item as long as the merge gate waits for it. It has to be run on the head that merges, so it should wait for the repair. |
| "A later pin update will be needed" (`05-repair.md:428`) | **A "later" item without a trigger.** F-5. |
| Subtest names that cannot be listed (`05-repair.md:429`) | **A stated limit that fails closed**, but the statement is incomplete. F-1 and F-2. |
| The follow-up for PR #12 (`05-repair.md` section 10) | **Machine-enforced.** Once that branch holds this workflow, a test that cannot pass on the runner turns the gate red until it is ported or listed, and a listed test must fail. |
| "Nothing forces the ports to happen", and "eight root lines would pass with an account `ds` and `/private/tmp` on the runner" (`05-repair.md:426-427`) | **David's, as both earlier reports said.** Not part of this verdict. Thirteen tests and two subtests run in no automatic check; they run only when someone runs them on the Mac or with the old binaries. |

## 8. Red-team log

### 8.1 The earlier scripts, re-run on the audited gate

| Script | Probes | Result |
|---|---|---|
| `redteam.py` of the earlier re-audit, unchanged (SHA-256 `7ad071a7…0208`) | 38 | Exit statuses identical to the writer's recorded run. Against the run at `fada999`, three differ: B1 0 → 2 (RF-1 is closed), G1 and G2 1 → 2 (they call the old mode `environment-only`, which no longer exists; the adapted script covers them). |
| The writer's `redteam_adapted.py` | 45 | Exit statuses identical to the writer's recorded run. G3 (gate step with a stale line) is 0 by design, G3′ (third step) is 1. |

### 8.2 My own probes (`rt6.py`, `rt6b.py`, `rt6c.py`: 64 runs on throwaway modules; S12 is in `sketch-notes.txt`)

| Probe | What it tries | Gate | Still-failing | Judgement |
|---|---|---|---|---|
| S9 | Line for subtest `reg`; two more subtests named `reg/…` pass | 0 | 0 | **Bypass (F-1)** |
| S9r | The same, with a regression in `reg/custody` | 0 | 0 | **Bypass (F-1)** |
| S11 | Line for nested `reg/custody`; a subtest named `reg/custody/deep` has a regression | 0 | 0 | **Bypass (F-1)** |
| S10 | Control: real subtests under `reg` | 0 | 0 | By design; indistinguishable from S9 |
| S12 | Line for `reg`; the parent stops when `reg` fails; `reg/custody`, declared after it, has a regression | 0 | 0 | **Bypass that no run can show (section 12)** |
| S1 | Line for a subtest whose own name is `reg/custody` | 1 | 0 | **Steps disagree, wrong message (F-2)** |
| S8 | Line `TestP/reg` where only `reg/custody` and `reg/identity` exist | 0 | 1 | Held by the third step |
| S9h | Route-style names (`GET /v1`, `GET /v1/jobs`) | 1 | 0 | Refused by the gate step (F-2) |
| S2, S3 | Renamed duplicate subtest; failing parallel sibling | 1 | | Held |
| S4a, S4b | The same subtest name twice; `go test` renames the second | 1, 0 | | The line binds to call order; nothing hidden |
| S5 | Whole-test line, 2 subtests pass and 1 fails | 0 | 0 | O-1 |
| S6, S7 | A hang, a panic in a listed package | 1 | | Held |
| T1 | Listed B fails only after listed A | | 0 | **Stale line missed (F-3)** |
| T2, T3, T4 | Text that looks like a verdict, with and without the marker byte | 0 | 1 | Held |
| T5, T6 | A list of comments only; error then skip; log only | | 0, 1 | Held |
| T7 | `TestMain` that swallows the exit status | 0 | 0 | O-3 |
| T8, T9, T10 | Parallel listed tests with a panic; a hanging listed test | | 1 | Held: each line gets its own verdict |
| U1, U2, U3 | Name printed from `init()`; hostile `TestMain`; external-only test | 2, 0, 0 | | O-3; U3 held |
| V1 to V5 | `GOFLAGS` carrying `-skip`, `-run`, `-list`, `-failfast -short` | 1, 0, 0, 1, 1 | | V2, V3: O-2 |
| W01 to W18, W90 to W92 | 21 text tricks in the list: control characters, Unicode line ends, BOM, NUL, tab, backslash, `..`, package spellings, case, a 70,000-character name, a leading `-`, CRLF, 4,999 undefined lines | 2 or 1 | 0 for W91 | All refused or harmless. Nothing extra is skipped, no flag is injected. |

### 8.3 Edits of the workflow file (`wf6.py`)

22 edits. 8 controls caught. 13 pass the self-check's workflow group and the docs test: the 12 of F-4, and X23 (`timeout-minutes: 1`), which fails closed.

### 8.4 Mutants: can the self-check tell a broken gate from a working one

**The writer's 75 mutants** (`mutants.py.txt` of `05-repair-evidence`, unchanged, against the committed self-check): **75 of 75 killed**, and the control passes all 56 checks (my run, 08:25:03 to 08:57:06, `mutants-writer.log`). This matches the writer's result.

**My own 39 mutants** (`mut6.py`, none repeats the writer's), plus a control that passes: **28 killed, 11 survive.** None of the survivors opens the gate:

| Survivor | Why it survives | Does it matter |
|---|---|---|
| A4 an unlisted test that skips itself counts as "did not run" | No self-check case has a self-skipping unlisted test in a listed package | A stricter gate, which the real tree would fail at once. Worth one case. |
| A5 the first verdict of a test wins | Only hostile output gives a test two verdicts (T3) | No |
| A6 a test counts as started only on its `run` event | Same behaviour for real output | No |
| A7 a line that is not JSON ends the reading | No case prints such a line | Fails closed: verdicts go missing |
| A13, A14, A15 three guards on `go list` output | Cannot be reached with a real `go` | No |
| A17 every entry is always judged alone | A design variant, and the fix for F-3 | Shows that the fix needs no change to existing cases |
| A26 the bare name `Test` is accepted | No case holds it | No |
| A51 extra arguments are accepted | No case holds it | No |
| A62 the log line lists subtests of every depth | The line's wording is not held at depth | No |

The self-check holds no subtest with a `/` in its own name, which is why F-1 and F-2 pass it.

### 8.5 Faults planted on the real tree

P-a, P-b, P-c: section 5. P-d: F-1. All in a scratch clone at `c4a84f5` with the gate and the list unchanged. The diffs are `plant-a-c.diff` and `plant-d.diff`.

## 9. PR #16 in detail

- **What changed.** `TestSQLiteClaimStoreTwoHandlesBusyTimeoutAndHelperProcessContention` now gives the helper process a stdin pipe. The helper prints `locked` and then reads its stdin to the end, where it used to sleep 300 ms. The test closes the pipe after its contended write was refused, then waits for the helper. A deferred function kills and reaps the helper on every failure path. The assertion itself (`errors.Is(err, errClaimStoreBusy)`) is unchanged.
- **By reading: correct.** The lock can only end when the test lets go or dies. `helperReaped` is set before `cmd.Wait()`, so the helper is never waited for twice. The pipe's write end is close-on-exec, so no other child of the test process can keep the lock alive. When the helper test is run without the environment variable it still skips itself.
- **By running** (scratch merge `7904f59` of `c4a84f5` and `0a069ec`, tree `e5fd3498…865f`; the test file there is the manifest's `fbf8f64c…c400`):

| Check | Result |
|---|---|
| `go vet` for linux, darwin/arm64 and darwin/amd64; `gofmt -l` | clean |
| The test alone, no stalls | 100 of 100 pass |
| The test process stopped for 600 ms and released for 60 ms, repeatedly | 20 of 20 pass |
| Control: the unchanged test at `c4a84f5` under the same stalls | 17 of 20 pass; 3 fail with `busy contention error = <nil>` at `sqlite_physical_test.go:204` |
| The parent killed with SIGKILL while the helper holds the lock | 10 of 10 rounds: the helper exits within 50 ms, none left running |
| Whole package, with the two listed tests skipped | `ok`, 25.9 s |
| `-run TestSQLiteClaimStore -v` | 18 pass, the helper skips itself |
| Race detector (08:26:53 to 08:28:40) | `go test -race -count=10` on the changed test: `ok`, no race reported. `-race -count=2` on every `TestSQLiteClaimStore…` test: `ok`, no race reported |

- **Merges.** In local merges that I never pushed, PR #16 merges cleanly with PR #14, with PR #12 (`8058561`) and with PR #13 (`1826cef`), and PR #14, PR #16 and PR #13 merge together. These are merges of the text only; I ran tests on the merge with PR #14 alone.
- **Not covered for PR #16.** No macOS run. No CI run exists for it, because its base has no workflow yet. My stall pattern is the earlier re-audit's (600 ms stop, 60 ms run) in my own harness, not its `flake_stall.sh` file.
- **Findings for PR #16:** none.

## 10. Validation assessment

**Re-run by me on the exact bytes of PR #14** (clone at `c4a84f5`, tree `a05a25a6…7ccf`, clean before and after; started 07:47:58):

| Command | Result |
|---|---|
| `go mod verify` | all modules verified |
| `go build ./...` | exit 0 (28.9 s) |
| `go vet ./...` | exit 0 (10.6 s) |
| `gofmt -l` on the four changed Go files | no file listed |
| `GOOS=darwin go vet` on the three changed packages, arm64 and amd64 | exit 0 |
| `python3 -I -B .github/ci/go_test_gate_selftest.py` | `Ran 56 tests in 58.377s`, `OK` |
| `python3 -I -B .github/ci/go_test_gate.py gate "$ENVIRONMENT_ONLY_TESTS"` | exit 0 in 408 s. `test gate passed: 41 packages, 3 of them with skipped entries (15 entries)`. 21 `ok` lines, 20 packages without test files |
| `python3 -I -B .github/ci/go_test_gate.py still-failing "$ENVIRONMENT_ONLY_TESTS"` | exit 1, as expected in a container: 12 lines `still fails`, and the three `TestRemoteAlphaRuntimeSecurityBoundary…` lines named as passing. They depend on the host's `modprobe` configuration and on whether it has a working `systemctl`, and a container differs from the runner in both. |

**Read, not re-run:** the runner run 44996283604 (section 5). I cannot start a run without pushing.

**Changed test code, by reading.** `replay_custody_file_test.go` (a generic conversion helper for mode values), `result_auth_test.go` (O-4), `remote_alpha_operator_test.go:4022` (the SPIRE port: GNU `stat -c '%a'` first, BSD `stat -f '%Lp'` as fallback) and `docs_contract_test.go` (13 doc phrases, one forbidden sentence, 15 workflow lines, three non-empty files). None weakens a test.

**Docs.** The new section 10 of `go_toolchain_baseline.md` is accurate except for the sentence F-1 contradicts. `PLANS.md` needed no change: its lines 89 and 319 are scoped statements that stay true. No other document denies that CI exists.

**Not re-run, and limits:**

- Nothing on macOS (section 13).
- No run of my own on a GitHub runner. P-d and the probes ran only in my container.
- The race detector on PR #14's packages. The earlier re-audit ran it on `reliablesubmit` at `fada999`.
- A push-triggered run on `trunk_dev`: none exists until the workflow is merged.

## 11. The questions in section 12 of the writer's report

- **Reproduce the manifest:** done, section 4.
- **Re-run both probe scripts and the mutants, add my own:** done, section 8.
- **Read the runner log:** done, section 5. All four things the report names are there.
- **The two-step design against acceptance check 2.** Accepted. The gate step alone exits 0 with a stale line (probe G3), and the next step exits 1 (G3′). Check 2 asked for "a blocking step", and both steps are unconditional in `go.yml:78-85`. A run is green only when both pass. F-1 and F-3 are about what the third step can see, not about the split.
- **Does the SPIRE port belong in this PR?** Yes. It is one line, it removes a list line, and the third step would force that removal anyway.
- **Is the Mac run needed before or after the verdict?** Before a merge, not before a verdict. With this verdict it should wait for the repaired head.
- **PR #16:** audited here, section 9.

## 12. What a repair has to show

Acceptance checks for the next audit:

1. **F-1.** A blocking step fails when a line for a subtest would also skip another subtest that a run can see. Probes S9, S9r and S11 and the planted fault P-d exit non-zero in a blocking step, and the self-check holds those cases. The gate's text, the list header and the doc sentence say what is true afterwards.
   - **An advisory sketch, which I ran. It is not a patch.** `leaf_sketch.py` in the evidence folder runs each line that names a subtest on its own, as the third step would, and reports every test that starts in that run besides the line's subtest and its parents. Results (`sketch-notes.txt`): on the real tree with the real list it reports nothing and exits 0; on the P-d clone it names the planted subtest and exits 1; on a throwaway module it names the separate subtests `reg/identity` and `par/slash`. It also names a real subtest of a listed subtest (the S10 layout), so under this rule a line would have to name the failing leaf.
   - **One corner no run can show (probe S12).** If the parent test stops when the listed subtest fails (`if !t.Run("reg", …) { return }`, or a panic), a subtest named `reg/…` that is declared after it never starts in the still-failing run, and the gate run skips it. I ran that layout with the real gate (`sketch-notes.txt`, part 4): gate exit 0, still-failing exit 0, and the sketch exits 0 too. The control shows that the hidden subtest fails when it is reached. I found no pattern for `go test` that skips `reg` and not `reg/…`. So the repair should state this limit in the gate's own text and in the list header, in plain words. If the writer cannot close it, it is a standing limit for David to accept in words, not a "later".
   - A warning for whoever writes the fix: the JSON output of `go test` does not indent result lines by nesting depth, although plain `-v` output does (`sketch-notes.txt`, part 5). Depth cannot be read from the JSON stream.
2. **F-2.** The two steps agree on a line for a subtest whose own name holds a `/`: both refuse it with the true reason, or both accept it and skip exactly it. The list header says which subtests cannot be listed. Probes S1 and S8 are in the self-check.
3. **F-3.** Every line's verdict comes from a run that holds no other listed test, or the report says why the common run is enough. Probe T1 exits 1.
4. **F-4.** Either the workflow file is held as a whole (for example its exact text or SHA-256 in the self-check or the docs test, so that every edit has to touch the pin), or the edits X1, X3, X7, X11, X15, X21 and X2, X4, X9, X18, X19, X22 are caught one by one, or the check's name and comment stop saying "cannot be switched off".
5. **F-5.** The pins move to releases that target Node.js 24, shown green on the runner with the same three steps, or the report gives a reason to stay and drops the "later".
6. **RF-4, unchanged.** One Mac run of the changed tests at the new PR head, with its output.

A repair changes the bytes, so it needs new provenance and a fresh audit of the whole base-to-tip range (provenance §5.5). PR #16 needs nothing further from an audit.

## 13. Not covered, and Unknown

**Not covered:**

- **macOS, entirely.** For PR #14: the SPIRE port, `docs_contract_test.go`, `result_auth_test.go` and `replay_custody_file_test.go` on the Mac (RF-4). For PR #16: the changed test on the Mac. Both are safe on macOS by reading and by `GOOS=darwin go vet`; that is an inference, not a run. The Mac run is pending separately with David.
- A runner run of my own, and P-d on the runner.
- The newer action releases named in F-5: I read their `action.yml`, I did not run them.
- The race detector on PR #14's own packages.
- The Remote Alpha scripts beyond the lines cited.

**Unknown, and what would settle it:**

- Whether the `go` check is a required status check on `trunk_dev`. I cannot read branch protection. A look at the repository settings settles it.
- Whether pull requests from forks need approval before workflows run. Same place.
- Whether listed tests disturb each other on the runner (F-3). One runner run with every line judged alone settles it.

## 14. Closing state

- **Remote, at 08:57:29** (`git ls-remote`): `trunk_dev` at `ae326b0`, PR #14's head at `c4a84f5`, PR #16's head at `0a069ec`, `refs/pull/14/merge` at `9ead58f5`. All as at opening.
- **Pull requests** (GitHub, read at 08:57): both open, both drafts, both reported as mergeable without conflict. PR #14 was last updated at 07:12:34 and PR #16 at 07:41:35, both before this audit began at 07:41.
- **Audit clones:** as at opening. `HEAD` at the base, upstream `origin/trunk_dev`, nothing staged. The closing manifests equal the opening manifests byte for byte.
- **Recipe file:** still `c08597e2…a3ca`.
- **Left behind:** nothing outside the container except this report and its evidence folder. Scratch clones, throwaway modules and logs go away with the container. Nothing was pushed.

## 15. Sensitive-material handling

The patch holds no secret, token or key. I read no environment file, no SQLite state, no TLS, SPIFFE or Vault material outside test fixtures that the tests create themselves. The evidence folder was scanned for e-mail addresses, phone numbers and key material before delivery: none found. The one pattern match is the Go toolchain's module path (`toolchain@v0.0.1-go1.26.5…`) in `setup.sh.txt`, which is not an address. The raw JSON output of the full test run (5 MB) stays in the container and is not in the shared folder; only the name counts derived from it are.

## 16. Confidence

- **Provenance: high.** Both manifests reproduced twice at opening and twice at closing, equal to the writer's files and to each other.
- **Validation: high for Linux** (my container and the runner log I downloaded myself). **None for macOS.**
- **Implementation: high that the three blockers as filed are fixed. Certain that F-1 exists**: three throwaway layouts and one run on the real tree with the real list. F-2 to F-5 each rest on a run or a download of mine.

## 17. Report delivery

- Path: `/mnt/project-files/reports/Execution-Substrate/ci-go-workflow/06-reaudit.md`. Its SHA-256 is in the reply that delivers it.
- Evidence: `/mnt/project-files/reports/Execution-Substrate/ci-go-workflow/06-reaudit-evidence/`, indexed by its `README.md`. Scripts carry the extra suffix `.txt`.

**Final verdict, PR #14: BLOCK**
**Final verdict, PR #16: ACCEPT**
