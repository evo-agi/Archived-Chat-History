# REPAIR REPORT (replacement implementation report): Execution-Substrate Linux CI

**Verdict:** REPAIR_COMPLETE, ready for a fresh independent audit and red-team pass of the whole base-to-tip range.
**Effect status:** TOPIC_BRANCH_PUSHED (fast-forward, no force) · DRAFT_PR_UPDATED https://github.com/evo-agi/Execution-Substrate/pull/14 · CI_GREEN_ON_RUNNER (run 44984626477, one run) · MERGE_NOT_PERFORMED · INDEPENDENT_AUDIT_NOT_PERFORMED on the new bytes · RED_TEAM_NOT_PERFORMED on the new bytes

This report replaces `01-implementation.md` as the implementation report for PR #14. It answers the BLOCK in `02-audit-redteam.md` (SHA-256 `44bac0250ab6502b18178b08032bfd28964892b63a6d9b9a760f3993339b92c9`, which is what I read).

## 1. What was repaired, in short

The audit blocked on two things. Both are fixed.

1. **Skips now match one exact package plus one exact test name (F1, F2).** Before, the workflow gave one `-skip` pattern to `go test ./...`, so a listed name was skipped in every package, and each entry was used as a regular expression. Now:
   - the list is a file of `<package import path> <TestName>` lines;
   - a small script refuses any entry that is not a plain package and test name, before it runs any Go command;
   - each package that has entries runs on its own with only its own entries skipped, and every other package runs with nothing skipped.
2. **Both actions are pinned to full commit SHAs (F6),** with the release tag in a comment. I checked the SHAs against the official action repositories, which the audit could not do.

A regression check runs in CI before the gate. Among other things, it shows that a failing test that reuses a listed name in another package now fails the gate. The same module passes the old gate.

## 2. Target identity

| Field | Value |
|---|---|
| Repository | evo-agi/Execution-Substrate |
| Base ref and SHA | `trunk_dev` at `ae326b0ddc30ec6b35883ee32945c622405b68b6` (re-fetched; unchanged) |
| Topic branch | `claude/project-thread-sqldt7-ci` |
| Commits | `d886bb80feb160b6775f0ac1866ce69f7bdbfe47`, `145ab62001e488fea0cd4c4a002661df86ef9f95` (the audited tip), then the repair `fada999c6da5ed157c74033e1e975415c179c49d` |
| Tip tree | `c369dfd178d566667d1465e9e626ed8abe2d1684` |
| Draft PR | #14, base `trunk_dev`, now 6 files, +660/−3 |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified with `sha256sum -c` before each run |
| Manifest upstream | `origin/trunk_dev` |
| **Cumulative manifest SHA-256 (audit this one)** | `7c1406bfde7df1063a2ed1a46f7b2c2853823b6877cfd18677c5d89136b9d82d` (1,446 bytes), HEAD `ae326b0`, 6 files: 4 untracked new, 2 tracked_modified |
| Cumulative textual diff SHA-256 | `c65fdafd8c8445a7baf703527554fea0f6825e5fcead797845e048bad2025367` |
| Repair-only manifest (the delta) | `e7a8b1112e5f1fec836d417060385d59921934f079cb7c0df704dc4682b4918e`, HEAD `145ab62`, 4 files, textual diff `6b814cd5ef116a2de898292c8381a6987c80fa19facf438b49348c76aa309199` |

**The cumulative textual diff is the same as before the repair, and that is expected.** The recipe's textual diff covers tracked files only. Against the base, the two test files are the only tracked changes, and the repair did not touch them. All four files under `.github/` are new relative to the base, so their bytes are pinned by the per-file SHA-256 entries in the manifest.

**Auditor reproduction:** provenance §5.3 with `BASE=ae326b0ddc30ec6b35883ee32945c622405b68b6`, `TOPIC=claude/project-thread-sqldt7-ci`, `TIP=fada999c6da5ed157c74033e1e975415c179c49d`, and the upstream pinned with `git branch --set-upstream-to=origin/trunk_dev`. I ran exactly that in a fresh clone from GitHub after the push. The result was byte-identical to the implementation manifest (`cmp`), twice.

Final working-tree status after the commit: clean (`git status --porcelain` empty).

## 3. Reconnaissance

- **Subagents:** none. All reading, edits and runs are my own.
- **Input:** the complete delivered audit report, and the coordinator's repair brief, which authorized two repairs: (1) match skips by exact package plus test name, anchor or escape entries so they are not regexes, and add a regression check that a same-named failing test in another package fails the gate; (2) pin both actions to full commit SHAs with the tag in a comment.
- **Adopted from the audit:** F1, F2 and F6 as required. The package-scoping design follows the audit's first suggested correction for F1 (run the affected packages with their own lists and all others with no skip). I also adopted the two traps it warned about, by not using shell at all for the gate logic.
- **Not adopted as written:** the audit's bash sketch. I wrote the gate in Python instead. Reasons: the repair needs the same logic in the gating step, the non-blocking step and the regression check, so it has to live in a file; and exact set arithmetic, strict line parsing and running commands without a shell are easier to get right and to test in Python. The root test package already needs `python3`, so this adds no new dependency.

## 4. Implementation decision

### 4.1 The list: `.github/ci/environment-only-tests.txt`

One entry per line: a package import path, one space, a top-level test name. Empty lines and lines whose first character is `#` are ignored. Anything else is an error. The file carries the reason for each group of entries and the porting TODO.

It holds 16 entries: 12 for `execution-substrate`, 2 for `execution-substrate/es/app` and 2 for `execution-substrate/es/admission/internal/reliablesubmit`. These are the same 16 tests the runner failed on at `145ab62`.

### 4.2 The gate: `.github/ci/go_test_gate.py`

`gate` mode, in order:

1. **Parse the list.** Every entry line must match `([A-Za-z0-9_][A-Za-z0-9_./-]*) (Test[A-Za-z0-9_]+)` in full. So a test name can contain no regular-expression metacharacter, and there is exactly one name per line. A repeated entry is an error. This happens before any Go command runs.
2. **Check packages.** Each listed package must be exactly one of the lines `go list ./...` prints. A package pattern such as `execution-substrate/...` is not one of those lines, so it is refused.
3. **Check that each listed test exists** in its package, using `go test -list`, which runs no test. A name that the package's test binary does not define is an error.
4. **Run.** For each package with entries: `go test -count=1 -skip '^(Name1|Name2)$' <that package>`. For all other packages together: `go test -count=1 <packages>` with no skip. A sanity check requires the two groups to add up to the full package list.
5. Exit 0 only if every run passed.

Errors in steps 1 to 3 exit with status 2, and no test has run at that point. A failing Go command exits with status 1. An unexpected Python error also exits non-zero, so the gate fails closed.

`environment-only` mode runs only the listed tests, each in the package its entry names. The workflow step that uses it keeps `continue-on-error: true`, as before.

**Cost:** the packages with entries now run one after another instead of alongside the rest, so the gating step takes longer on the runner (4m59s against 3m49s at `145ab62`; the whole job 5m47s against 5m13s). I chose the simple serial form on purpose: it is easier to verify, and the audit noted one timing-sensitive test that failed once under load.

### 4.3 The regression check: `.github/ci/go_test_gate_selftest.py`

A new blocking workflow step, "Check the test gate", runs it before the gate. It needs only `python3` and `go`. Each check writes a small throwaway module named `synth` into a temporary directory and runs the gate there with the same command line the workflow uses. Each generated test function creates a marker file when it runs, so "skipped" and "ran" are observed directly, not read from `go test` output.

20 checks in three groups:

- **Each entry stays in its package (11 checks).** The one the brief asked for is `test_same_name_failing_in_an_unlisted_package_fails_the_gate`. Others cover: two listed packages whose entries must not reach each other; the root package versus a subpackage, in both directions; an unlisted failure inside a listed package; names that only resemble an entry; a subtest named like an entry; a compile error; an empty list.
- **The gate refuses a list it cannot take literally (6 checks).** 23 malformed inputs, including the audit's W1, W2 and W8 entries (`Test.*`, a `Test….*` prefix pattern, `TestFoo|TestListed`), each refused with status 2 before any Go command runs. Also package patterns and unknown packages, tests that their package does not define, repeated entries, bad command lines and a missing list file.
- **Environment-only mode runs exactly the entries (3 checks).**

### 4.4 The workflow: `.github/workflows/go.yml`

- `actions/checkout@11d5960a326750d5838078e36cf38b85af677262 # v4.4.0` and `actions/setup-go@40f1582b2485089dde7abd97c1529aa768e1baff # v5.6.0`.
- The Test step and the non-blocking step call the gate script. The new "Check the test gate" step runs before them.
- Concurrency: see F8 in section 5.

### 4.5 SHA verification for the pins

`git ls-remote https://github.com/actions/checkout.git 'refs/tags/v4*'` and the same for `actions/setup-go` with `v5*`, run from this container on 2026-11-22:

- `actions/checkout`: `refs/tags/v4` and `refs/tags/v4.4.0` both point at `11d5960a326750d5838078e36cf38b85af677262`.
- `actions/setup-go`: `refs/tags/v5` and `refs/tags/v5.6.0` both point at `40f1582b2485089dde7abd97c1529aa768e1baff`.

These equal the SHAs the runner printed for the audited run, which the audit quoted in F6. No peeled (`^{}`) entries were listed, so these tags point straight at commits.

## 5. Every audit finding and what happened to it

| Finding | Audit's ask | Disposition |
|---|---|---|
| **F1** listed name skipped in every package | Required | **Fixed.** Skips are scoped to the entry's package (4.2). |
| **F2** entries act as regexes, nothing validates them | Required | **Fixed.** Strict entry grammar, refused before any Go command (4.2 step 1). |
| **F6** actions pinned by tag | Required | **Fixed**, and the SHAs are verified against the action repositories (4.5). |
| **F3** nothing checks that a listed name exists or still fails | Suggested | **Half done.** Existence is now checked and blocks (4.2 step 3). So I dropped the entry for `TestOperationalHandoffSchema4BinaryRefusesSchema5`, which exists only on PR #12; see section 9. "Still fails" is **not** checked: a listed test that starts passing stays skipped until someone removes its line. |
| **F8** `cancel-in-progress` also cancels `trunk_dev` push runs | Suggested | **Done, slightly differently.** `cancel-in-progress` is now true only for pull requests, as suggested. I also made the group per commit for pushes (`github.sha`). Reason: with one shared group, GitHub keeps only one pending run per group, so a third quick push would still cancel the second one's pending run. Not observed: no push run can happen before merge. |
| **F7** wrong reason for the SPIRE entry; one-line port | Suggested | **Comment corrected** to the cause the audit found: the test's fake `sudo` tries BSD `stat -f` before GNU `stat -c` (I confirmed at `remote_alpha_operator_test.go:4022`). The **port is not done**, because it edits a test file outside the repair scope. |
| **F4** whole-test skips drop subtests that pass on the runner | Suggested | **Not done.** Out of the repair scope. The entry grammar deliberately rejects `/`, so subtest-level entries would be a designed extension, not an accident. |
| **F5** the non-blocking step cannot signal anything | Suggested | **Not done.** Same step semantics as before. |
| **F9** restored build cache is not verified | Observation | Not changed. |
| **F10** governing documents do not mention CI | Observation | Not changed. A PLANS.md entry on this branch would conflict with PR #12's and PR #13's edits to the top of that file. |
| **P-A to P-E** | Pre-existing | Not in scope. Nothing here changes them. |

The three items I took beyond the two required repairs (existence check with the dropped entry, F8, and the F7 comment) are all inside `.github/`. The coordinator's notes list them as the audit's recommended items. If the fresh audit should cover only F1, F2 and F6, they are easy to back out.

## 6. Files touched (cumulative, against base `ae326b0`)

| Path | Kind | Summary |
|---|---|---|
| `.github/workflows/go.yml` | new | The workflow. Changed by the repair: action pins, concurrency, the gate self-check step, and the two test steps now call the gate script. |
| `.github/ci/go_test_gate.py` | new (repair) | The gate. |
| `.github/ci/go_test_gate_selftest.py` | new (repair) | The regression check. |
| `.github/ci/environment-only-tests.txt` | new (repair) | The list, 16 entries. |
| `es/admission/internal/reliablesubmit/replay_custody_file_test.go` | test | Unchanged by the repair. Linux compile fix from the first commit. |
| `es/admission/result_auth_test.go` | test | Unchanged by the repair. Vet copylocks fix from the first commit. |

No production file changes. No dependency changes. All four `.github/` files have mode 0644.

## 7. Validation

### 7.1 The regression the brief asked for, before and after

One synthetic module, two packages. `synth/listed` has a failing test named `TestSQLiteV3OldBinaryRefusesWithoutMutation` (a name from the real list). `synth/other` has a different failing test with the same name.

| Gate | Command | Result |
|---|---|---|
| Old (the Test step's exact `run:` text from `145ab62`, with that commit's list, under `bash -e`) | `go test -count=1 -skip "$pattern" ./...` | `ok synth/other [no tests to run]`, **exit 0**. This reproduces the audit's R1. |
| New | `python3 -I -B go_test_gate.py gate list` with the one entry `synth/listed TestSQLiteV3OldBinaryRefusesWithoutMutation` | `--- FAIL: TestSQLiteV3OldBinaryRefusesWithoutMutation` in `synth/other`, **exit 1** |

The audit's widening entries on the new gate: `Test.*`, `TestSQLite.*` and `TestFoo|TestSQLiteV3OldBinaryRefusesWithoutMutation` each exit 2 with `is not '<package> <TestName>'`, and nothing runs.

### 7.2 The self-check and whether it can tell a broken gate from a working one

`python3 -I -B .github/ci/go_test_gate_selftest.py`, Go 1.26.5: **20 checks, OK**, about 14 seconds in my container.

I then broke the gate on purpose in eight ways, one at a time, on a scratch copy, and ran the same self-check against each. Every one was caught.

| Deliberate breakage | Checks that fail |
|---|---|
| M1: one skip pattern for all of `./...` (the audited behaviour) | 5, including the same-name-in-another-package check |
| M2: accept any two words as an entry | 2 (11 cases) |
| M3: no check that a listed test exists | 1 (3 cases) |
| M4: no check that the package is in the module | 2 (6 cases) |
| M5: ignore failures in packages without entries | 5 |
| M6: ignore failures in packages with entries | 4 |
| M7: unanchored pattern | 1 (2 cases) |
| M8: environment-only mode runs every package | 2 |

### 7.3 On the GitHub runner (authoritative)

Run 44984626477, job 137092378502, event `pull_request`, head `fada999c6da5ed157c74033e1e975415c179c49d`: **success, 5m47s.** I read the job log from the end of the checkout step to the end of the job.

| Step | Result on the runner |
|---|---|
| Check out, Set up Go | success with the pinned SHAs. The log shows `Run actions/setup-go@40f1582b2485089dde7abd97c1529aa768e1baff` and `go version go1.26.5 linux/amd64`. |
| Download, verify, build, vet | success |
| Check the test gate | `Ran 20 tests in 10.935s`, `OK` |
| Test | success in 4m59s. The three existence checks passed. Then `ok execution-substrate 133.124s`, `ok execution-substrate/es/app 98.825s`, `ok execution-substrate/es/admission/internal/reliablesubmit 24.353s`, and one command for the other 38 packages: 18 `ok` and 20 `[no test files]`. Last line: `test gate passed: 41 packages, 3 of them with skipped entries (16 entries)`. |
| Environment-only tests (non-blocking) | exit 1, absorbed by `continue-on-error`, as designed. It failed on exactly the 16 entries (12 root, 2 `es/app`, 2 `reliablesubmit`) and ran nothing else. |

The gate covered the same 21 test-bearing packages as the audited run at `145ab62`, and the same 16 tests stayed out of it.

Caveats: this is one green run of this tip. The visibility caveat from report 01 still holds: the API shows the non-blocking step as `success` although it exited 1.

### 7.4 Local simulation of the whole job

As non-root user `ci` in my container (umask 022, no proxy variables, Go 1.26.5 with `GOTOOLCHAIN=local` and `GOFLAGS=-mod=readonly`), in a clone of the repair's working state. Three of the four `.github/` files are byte-identical to the commit. `go_test_gate.py` differs from the commit in one comment block only (4 comment lines became 5; I reworded it after this run, and `diff` shows no code line changed). The self-check and the eight breakages in 7.2 were run again on the committed bytes, and the runner in 7.3 ran the commit itself.

| Step | Result |
|---|---|
| `go version`, `go mod download`, `go mod verify`, `go build ./...`, `go vet ./...` | all exit 0 |
| Check the test gate | exit 0, 20 checks |
| Test (gate) | **exit 1 here, for a known container-only reason.** The existence checks passed. `execution-substrate/es/app`, `…/reliablesubmit` and the 18 other test-bearing packages were all `ok`. The root package failed on 3 tests: `TestRemoteAlphaOperatorByteStableUnicodeDelimiterMatrix`, `TestRemoteAlphaOperatorByteStableFalsePositiveMatrix` and `TestRemoteAlphaESConfigTLSPrepRecordsDSSecurityWarningsWithoutFailing`. |
| Environment-only | exit 1, as designed: 9 root tests and the 2 probes fail. The 3 runtime-security-boundary tests and the 2 `es/app` tests pass in my container, as they did before. |

Those 3 root failures are the same 3 that failed in my container at `145ab62` and passed on the runner (report 01, and the audit traced two of them to the missing `en_US.UTF-8` locale). The repair does not touch that package. The run does show the mechanics on the real tree: all 41 packages were handed to `go test`, 21 of them have tests, and one failing package made the gate exit 1.

## 8. Authority, security and protocol widening

- **Narrower, not wider.** The set of tests that can be skipped shrank from "17 names in any package" to "16 exact package and test pairs". Pinning removes the ability of a moved tag to change what the gate runs.
- Token permissions, triggers, secrets use (none) and `persist-credentials: false` are unchanged.
- The gate and its self-check run only `go list`, `go test` and Python's standard library. No network use beyond what `go test` already did. The self-check's modules have no dependencies.
- **Inference:** a pull request can still edit the list, the gate script or the workflow that checks it. That is inherent to `pull_request` workflows and is a review matter, as the audit said. The repair makes such an edit visible as a diff in `.github/`.

Cross-repo impact: none.

## 9. Follow-up this creates for PR #12

The old list pre-authorized skipping `TestOperationalHandoffSchema4BinaryRefusesSchema5`, a test that exists only on PR #12. The new gate requires every entry to exist, so that entry is gone.

Consequence: once PR #14 is merged and PR #12 picks up `trunk_dev`, CI on PR #12 will fail on that one test until this line is added to the list on PR #12's side:

```text
execution-substrate/es/admission/internal/reliablesubmit TestOperationalHandoffSchema4BinaryRefusesSchema5
```

I checked this on a scratch merge of PR #13's head `e544e0f` with the repair bytes (never pushed; it merged without conflict). Running the `reliablesubmit` package the way the gate would:

- with today's 2 names skipped: fails on exactly `TestOperationalHandoffSchema4BinaryRefusesSchema5` ("authenticated schema-4 opener is required");
- with the third name also skipped: `ok`.

**One thing I could not explain.** The first of my runs with all three names skipped exited 1. I had cut the output to its last lines, so I do not know which test failed. The next 21 runs of the same command all passed (22 runs, 1 failure). So there may be an intermittent test in `reliablesubmit` on the PR #12 and PR #13 code. It is not part of PR #14, but the PR #13 audit should know.

## 10. Assumptions, unresolved seams, uninspected areas

- **Not observed:** a push-triggered run on `trunk_dev`, and therefore the `github.sha` branch of the concurrency group. A run from a fork. A second green run of this tip.
- **Not run on macOS:** nothing in the repair runs there in CI. The self-check should work on a Mac with `python3` 3.8 or later and Go; I did not run it there.
- **Guess:** the gating step's longer duration is stable. It was measured once.
- **Python version:** the scripts use nothing newer than Python 3.8. I ran them on 3.13 here; the runner used its own `python3` (Inference: 3.12, the ubuntu-24.04 system Python; a traceback elsewhere in the same log shows `/usr/lib/python3.12`).
- **Still open from the audit and not addressed:** F3's "still fails" half, F4, F5, F7's port, F9, F10, and all pre-existing items.
- Whether "build, vet and test" is a required status check on `trunk_dev` is still unknown to me.

## 11. For the red team

- Can any line of the list file make the gate skip a test outside the named package, or more than one test? The grammar and the package check are in `read_entries` and `require_module_packages`.
- Can the existence check be satisfied by something other than a real test in that package? It trusts the lines `go test -list` prints for that package.
- Does a failure anywhere (a package run, `go list`, `go test -list`, a Python error) always produce a non-zero exit?
- Is the self-check able to pass while the gate is broken in a way my eight breakages did not cover?
- Are the pinned SHAs the commits the comments say they are?

## 12. Confidence

- **Provenance: high.** Reproduced byte-identical from the pushed commit in a fresh clone.
- **Validation: high for the gate mechanics.** The self-check catches all eight deliberate breakages, the before-and-after regression is reproduced, and I read the green runner run step by step. It is still only one green run of this tip.
- **Implementation: medium-high.** The mechanism is small, has a discriminating self-check, and fails closed. It has not been independently audited.

## 13. Provenance detail

- Recipe SHA-256 verified before each run.
- Per provenance §5.5: with the repair in the working tree and nothing staged, I took the repair-only manifest at HEAD `145ab62`, then `git reset --mixed ae326b0`, pinned the upstream to `origin/trunk_dev`, and took the cumulative manifest. Each was run twice to absent paths in a fresh mode-0700 directory outside the repository, and `cmp` showed identical bytes. Then `git reset --mixed 145ab62`, `git add -A`, one commit.
- Staged set equals the repair-only manifest's path set (4 paths).
- `git status --porcelain` empty after the commit. Fast-forward push `145ab62..fada999`, no force.
- No `__pycache__` or `.pyc` files were created in the repository (the scripts run with `-B`).

Complete cumulative canonical manifest. The manifest file is this line followed by one newline (`\n`); that is what the SHA-256 covers:

```json
{"branch":"claude/project-thread-sqldt7-ci","files":[{"file_type":"regular","kind":"untracked","mode":"0644","path":".github/ci/environment-only-tests.txt","sha256":"f25ac6565bded3901ca2599c7d350143ca9dfc58a26a6f3078e96a574acf5de1","size":3379},{"file_type":"regular","kind":"untracked","mode":"0644","path":".github/ci/go_test_gate.py","sha256":"f071acd417c7c84f5db4cea3a9dee19ab90b6613203daa2e0cd2fa55ed4d03a9","size":7164},{"file_type":"regular","kind":"untracked","mode":"0644","path":".github/ci/go_test_gate_selftest.py","sha256":"7441acc050d43c4a73a275f4f27a7a46e9e6081067474ca882e3cd4c8a0b3c6f","size":12056},{"file_type":"regular","kind":"untracked","mode":"0644","path":".github/workflows/go.yml","sha256":"63eb90f3ceb59cce00940683fb51de4a5c9570cfa3a5398b7dbe67a57d13381e","size":2937},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_file_test.go","sha256":"0cec866cf2e659c58a90eeb46f3edf75d9743db21c0c87aaad65d72462c3a2d9","size":70129},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/result_auth_test.go","sha256":"adab4be23f1d1f74bbc6bccd3e49235d8e95e0b5c6e2c4121930578c0e72f87c","size":18293}],"head":"ae326b0ddc30ec6b35883ee32945c622405b68b6","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"c65fdafd8c8445a7baf703527554fea0f6825e5fcead797845e048bad2025367","upstream":"origin/trunk_dev"}
```

## 14. Report delivery

Path: `/mnt/project-files/reports/Execution-Substrate/ci-go-workflow/03-repair.md`. Its SHA-256 is given in the delivering thread reply.
