# AUDIT ADDENDUM to `09-audit.md`: Execution-Substrate PR #14 (Linux CI) at `8eefe6d`, the repair of A9-F1

**Final verdict: ACCEPT** for `8eefe6d309c64ec33295dce089e57927129f52e1`, scope `aaef28f..8eefe6d`
**Effect status:** REPAIR_NOT_PERFORMED · COMMIT_NOT_PERFORMED · PUSH_NOT_PERFORMED · PR_NOT_MODIFIED · NO_COMMENT_POSTED · MERGE_NOT_PERFORMED · read-only on the target throughout

This is the narrow audit that section 12 of `09-audit.md` asked for. The thread that wrote `09-audit.md` did it. It wrote the finding and the probes, and it wrote none of the repair. It used no subagents. It is a correctness audit, not a red-team pass. Its scope is the one commit `8eefe6d` on top of `aaef28f`, which `09-audit.md` accepted with the low finding A9-F1. `09-audit.md` is unchanged (SHA-256 `45ac805326f4106622feb1ca229e35500eedf21aa00b25c6f3dd43cc1eb10115`).

All times are UTC on 2026-11-22.

## 1. Verdict in short

**ACCEPT. A9-F1 is closed, and I found no new defect.**

- **The rule the coordinator asked for is what the code does.** Only a failure that the testing package reported for the listed test counts, alone and in the run of its package. A run of a listed package that is killed or timed out fails the step unless a listed test accounts for the stop by a failure of its own, and then the package has to run to its end without that test (section 4).
- **All five cases of the finding now fail the step.** My probe files of `09-audit.md` ran unchanged against the new gate: R1, R1p, R3, R7 and R8 exit 1, each with the new message that the run of the package stopped before its end (section 5.1).
- **18 new plants agree, in 24 runs.** A test outside the list kills the test binary in six more ways (`log.Fatal`, SIGKILL, a panic in a goroutine, a fatal error of the runtime, `os.Exit(0)`, and with a whole test as the entry). The time limit of `go test` hits in six positions. Every one fails the step, and two lists that have to pass do pass (section 5.2).
- **`WORKFLOW_SHA256` is consistent.** `go.yml` changed in 10 comment lines and in no other line. The value in the self-check is the SHA-256 of the committed file, and both holds notice an edit of either (section 6).
- **Nothing else is weaker.** The mode `gate` is the same code, function by function. No line of the list that is not a comment changed. The other eight groups of the self-check are the same text. My probes of the skip rule, of what a package has to report and of malformed list lines give the results of `09-audit.md` (section 7).
- **My reruns on the exact bytes agree with the writer's report:** build, both vet steps, the docs contract test, the self-check (121 of 121, also on a file system that ignores case), both test steps on the real tree, the earlier reviewers' files. All 14 of my new mutants of the rewritten code are killed (section 8).
- **The runner result is confirmed from GitHub:** run 45064532285 at `8eefe6d` is green. Its third step makes 18 runs, each ends with the testing package's own `FAIL` line, and no package runs twice (section 8.3).

Two results are stricter than my probe files expected, and both are the rule the coordinator asked for: R5 and R6 now exit 1 (section 5.1).

What this verdict does not cover:

- **The branch is one commit behind `trunk_dev`.** PR #17 moved `trunk_dev` from `ae326b0` to `b8d6bc3` at 20:20:05, during the runner run. The green run is of the merge with `ae326b0`. Updating the branch makes a new head, which is the merge gate's step (provenance §5.4 step 2), not part of this audit (section 9).
- **A run on macOS at this head.** The four new checks of the self-check have not run on a Mac. They passed here on a Linux file system that ignores case.
- **A red-team pass of the new bytes.** The coordinator asked for a narrow correctness audit.

## 2. Audit target

| Field | Value |
|---|---|
| Repository | `evo-agi/Execution-Substrate` |
| Pull request | #14, draft, branch `claude/project-thread-sqldt7-ci` into `trunk_dev` |
| Merge base | `ae326b0ddc30ec6b35883ee32945c622405b68b6`. `origin/trunk_dev` was `b8d6bc3abb8c8c38481c7835824bd79ba26e467b` at opening and at closing |
| Last audited commit | `aaef28f36f393e78f832a9caa745edeb02565a6c`, tree `f00fdd4053565f0d199b3ba013d1388d3f5fa0fd` (`09-audit.md`, ACCEPT with A9-F1) |
| Audited commit | `8eefe6d309c64ec33295dce089e57927129f52e1` (20:06:22), one commit on `aaef28f`, 9 commits above the base |
| Tree | `c3e784d20d3311650bfa91358d4113430dff4ca8` |
| Delta | 6 files, +623/−194, all with mode 100644 |
| Writer's report | `09-repair.md`, SHA-256 `0433ac98cbedb94a1ead00a700f778d139e6726b0902c1dafbf6360aa5e0ac32`, verified. Its evidence folder: all 57 lines of `SHA256SUMS.txt` hold |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified before each run |

File hashes at `8eefe6d`, equal to the manifest:

| File | SHA-256 | Change |
|---|---|---|
| `.github/ci/go_test_gate.py` | `a2a0399bf0dad043d5636d5cab23f361d02702a450f115f4852ed326b6fd08fa` | +101/−60 |
| `.github/ci/go_test_gate_selftest.py` | `24d7f2f1ed6d072da345e0d42d829c8abae030437a7ededc2a85626db51e8633` | +497/−128 |
| `.github/workflows/go.yml` | `d8578b0e6b5901d06ae82f0ec4acf81390d48ff8831a574a76d8d57d1c58bd18` | +6/−4, comment lines |
| `.github/ci/environment-only-tests.txt` | `ba629bd9328e84fb811593ec3e28657511bd862b033f6147d7bbe8b89da53ece` | +5/−0, comment lines |
| `.docs/system_overview/go_toolchain_baseline.md` | `8b0d9b698f4e1c18904491a7f91c79b73fe626902bdb471cf2c76c3353648078` | +9/−2 |
| `docs_contract_test.go` | `6310006087c3d0839ee37ce160973ff283a708a233295509290cc02487de14f3` | +5/−0 |

## 3. Provenance reproduction

No mismatch. In my clone, fetched from GitHub at 21:27:05, `origin/claude/project-thread-sqldt7-ci` and `refs/pull/14/head` are `8eefe6d`, and `ae326b0` is an ancestor of it. Each manifest was taken twice per run, and the two files were byte-identical.

| Manifest | HEAD | SHA-256 | Opening 21:27:22 | Closing 21:54:42 |
|---|---|---|---|---|
| Repair-only, 6 files | `aaef28f` | `1cb462368c4427615108e2c27c852452a69bcd84c458ad585a51e00e0b838ccf` | equal to the writer's file | equal to the opening file and to the writer's file |
| Cumulative, 9 files | `ae326b0` | `c16bda47d4a1cd7dee849bb6e0cc607bfac74be085ef434ba854d36f1f34b839` | equal to the writer's file | equal to the opening file and to the writer's file |

The pull request at 21:33: open, draft, head `8eefe6d`, `mergeable_state` clean, one check run, success. `refs/pull/14/merge` was `92a1e7cec577caaac7c463268c967e7160550ef4`, "Merge 8eefe6d… into ae326b0…", which is the commit the runner checked out. At closing nothing had moved: at 21:54:40 the remote had the branch and `refs/pull/14/head` at `8eefe6d`, `trunk_dev` at `b8d6bc3` and `refs/pull/14/merge` at `92a1e7c`, and at 21:55 the pull request was open, draft, head `8eefe6d`, last updated at 21:25:47.

## 4. The repair, read

All line numbers are of `go_test_gate.py` at `8eefe6d`.

**Part one: only a reported failure counts.** `judged` (873-888) no longer takes the exit status of `go test`. It returns the verdict that the event stream holds for the test. A test that started and has none is `waiting` or `unfinished`, and neither counts as failing. At `aaef28f` such a test counted as failing whenever `go test` failed, which was the defect. The same function judges the `go test` of an entry alone (1016).

**Part two: the run of a package has to come to its end.** `in_the_run_of_its_package` (911-976) returns "came to its end" only when the testing package wrote its closing line (`result.finished`, 961-962). When a run stops, the listed tests that reported `fail` after the last test had started or gone on account for it (966-972). With none, the function returns the entries that the run left without a verdict (973-974), `still_failing` records the package (1001-1002), writes one error for it (1040-1052) and exits 1 (1063). With some, the package runs again without them (975-976, then 934-942).

**Why exit 0 now means that every entry reported its own failure.** I checked this by reading, and the probes agree.

- The step exits 0 only if no package is recorded as stopped and no entry is named. For a package that means: its last run came to its end, and every entry left the loop through `found == "fail"` in some run. An entry that passes, skips itself, does not run, waits or is still running is named or recorded instead (955-962, 973-974).
- `found == "fail"` comes only from an event of that package with that test path and the action `fail` (`go_test_json`, 405-479, unchanged).
- In Go 1.26.5 the time limit of `go test` panics from a timer and writes no verdict (`src/testing/testing.go:2790-2802`), and the converter of `go test -json` adds no verdict for a test when the binary stops (`src/cmd/internal/test2json/test2json.go:141-149` and `:381-396`). A panic of a test reports that test and the tests above it, and no other. Real runs show the same: R1p, R8 and K6 for a panic, R7 and T1 to T6 for the time limit.

**The loop ends.** Each further run needs at least one listed test that is not yet left out and that reported `fail` in the run before (968-972). So a package runs at most once more than it has entries.

**What the rule costs, as the writer states.** A test that ends the process without reporting (`os.Exit`, `log.Fatal`, a panic in a goroutine it started) cannot be listed. The step names it and says why (plants S1, S2, probe R6). None of the 15 entries is such a test: section 8.3.

## 5. Probes and plants

Each ran on a throwaway Go module with the committed gate of `8eefe6d`, as user `ci` with an empty environment. Tests leave marker files, so "ran" is observed and not read from the output of `go test`.

### 5.1 The probe files of `09-audit.md`, unchanged

`aud9_probes.py.txt`, `aud9_probes2.py.txt` and `aud9_probes3.py.txt` have the SHA-256 values of `09-audit-evidence/SHA256SUMS.txt`. Logs: `aud9_probes.log`, `aud9_probes2.log`, `aud9_probes3.log`.

| Probe | What stops the run of the package | At `aaef28f` | At `8eefe6d` |
|---|---|---|---|
| R1 | an unlisted parallel test ends the process while the listed test runs | exit 0, wrong | **exit 1** |
| R1p | the same with a panic | exit 0, wrong | **exit 1** |
| R3 | a goroutine left by an earlier unlisted test ends the process | exit 0, wrong | **exit 1** |
| R7 | the time limit of `go test` (8 s in the probe), because an unlisted test hangs | exit 0, wrong | **exit 1** |
| R8 | an unlisted sibling of the listed parallel subtest panics | exit 0, wrong | **exit 1** |
| R2, control | nothing. The entry passes in its package | exit 1 | exit 1, named as passing |
| R4 | an unlisted test panics between two listed tests | exit 1 | exit 1 |
| R5 | an unlisted test ends the process after the only entry failed | exit 0 | **exit 1**, stricter |
| R6 | the listed test itself ends the process | exit 0 | **exit 1**, stricter |

- **In all of R1, R1p, R3, R7, R8, R4 and R5 the step writes the new error** `the run of synth/a stopped before its end, and no listed test accounts for it`, makes one run of the package, and does not tell the reader to delete the entry's line.
- **R5 and R6 print `NOT AS EXPECTED (expected 0)`,** because I wrote those two expectations for the old rule. Both results are right under the new one. In R5 the run of the package was killed, which the coordinator's assignment says has to fail the step. In R6 the listed test reported nothing, and `09-audit.md` named refusing it as the safe side.
- **Every other probe gives the result of `09-audit.md`:** the companion probes in the mode `gate`, the 12 probes of the skip rule (S), the 5 of what a package has to report (C, with C4 as corrected there), the 46 runs with malformed list lines (L, `unexpected: 0 of 46`) and the 3 of `aud9_probes3.py`. Exit status and the output lines that the probes keep are the same, apart from run times in two lines.

### 5.2 New plants: `aud9b_plants.py.txt`, `aud9b_plants.log`

18 plants in 24 runs, all as expected. In each K and T plant the entry fails in a `go test` of its own, so only the run of the package can show the problem.

| Plant | What happens in the run of the package | Step "Listed tests still fail" |
|---|---|---|
| K1 | an unlisted parallel test calls `log.Fatal` while the listed test runs | exit 1, `TestListed (was running)`, 1 run |
| K2 | it kills the process with SIGKILL (`signal: killed`, no other output) | exit 1, the same |
| K3 | it panics in a goroutine that it started | exit 1, the same |
| K4 | it raises a fatal error of the runtime | exit 1, the same |
| K5 | it calls `os.Exit(0)` | exit 1, the same |
| K6 | the entry is a whole test whose subtest runs when an unlisted test panics | exit 1, `TestWhole (was running)` |
| T1 | the listed test never ends, and the time limit hits (6 s in the plants) | exit 1, `TestListed (was running)` |
| T2 | an unlisted test never ends, after the only entry reported its failure | exit 1, `none` left without a verdict |
| T3 | the time limit hits directly after the entry reported its failure, with no test started in between | exit 1 after 2 runs: the run without the entry times out again |
| T4 | an unlisted test never ends while the listed parallel test still waits | exit 1, `TestListed (waited to run in parallel)` |
| T5 | the entry fails in its package and never ends in the `go test` of its own | exit 1, named: `it reported no failure` |
| T6 | a listed test panics, and in the run without it an unlisted test never ends | exit 1 after 2 runs |
| B1 | an unlisted test ends the process directly after the entry reported its failure, in every run | exit 1 after 2 runs |
| B2 | the same, but only when the entry has run | **exit 0** after 2 runs: the stated bound, see below |
| S1 | the listed test fails by a panic in a goroutine that it started | exit 1, named: `it reported no failure` |
| S2 | the listed test fails by `log.Fatal` | exit 1, the same |
| OK1 | a listed test panics, a listed test after it fails, an unlisted test passes | exit 0 after 2 runs |
| OK2 | two listed tests fail by `t.Error` and `t.Fatal` beside passing tests | exit 0, 1 run |

The five K plants with a parallel test also ran in the mode `gate` with the same list, and B2 did too: exit 0 each, so the step "Test" does not catch these modules, as in the finding.

**B2 is the bound that the writer states in section 4.3 and 8 of the report, and it is sound.** The entry reported its own failure in the run of its package and alone. What stopped the first run did not stop the run without the entry. The step's last line, that every listed test still fails alone and in the run of its package, is true there. The gate's docstring says that it cannot tell this case from a panic of the listed test (106-109).

## 6. The holds

- **`WORKFLOW_SHA256`:** the self-check holds `d8578b0e6b5901d06ae82f0ec4acf81390d48ff8831a574a76d8d57d1c58bd18` (`go_test_gate_selftest.py:53`), which is the SHA-256 of `go.yml` at `8eefe6d`.
- **`go.yml` changed in comment lines only.** 10 changed lines (6 added, 4 removed), each a comment line of the step "Listed tests still fail". The 62 lines that are not comment lines are the same in both commits (`diff` of the two files without their comment lines is empty). No step, command, trigger, permission, pin or `if:` changed.
- **`OBSERVED_GO_VERSION = "go1.26.5"` and `MATCH_GO_SHA256 = "f2841875…bebe"`** are unchanged (`go_test_gate.py:184-185`), and `match.go` of the Go I used has that hash.
- **The holds notice an edit** (`aud9b_hold.log`, the hold file of `09-audit.md` with the new workflow hash as its one changed constant): all 10 cases as expected, a control and 9 edits. One digit of `WORKFLOW_SHA256`, one space in a comment line of the workflow, CR LF line ends and a new `env:` on the step "Test" each fail the self-check's workflow group and the docs contract test. A change of the Go version or of the `match.go` hash in the gate, a comment after the version constant and `go 1.26.6` in `go.mod` each fail the docs contract test. The one edit that passes both is the one that passed before: a second assignment below the held line (Y4, observation A8-O3 of `08-audit.md`).
- **The third audit's 21 workflow edits,** unchanged (`wf7.log`): all caught by the self-check and by the docs contract test, as at `aaef28f`.
- **The five new doc sentences are held** by `docs_contract_test.go:985-989`, and the test passes on the committed tree.

## 7. Nothing else weakened

- **The mode `gate` is the same code.** I compared the two versions of `go_test_gate.py` unit by unit (`aud9b_compare.log`). 47 of the 53 top-level units are byte-identical, the imports among them. The others are the module docstring, `judged`, `in_the_run_of_its_package`, `still_failing`, the table `NOT_FAILING`, the new table `NO_VERDICT` and the removed text `RAN_BESIDE`. `judged` is called from the third step only (lines 956 and 1016).
- **The list:** no line that is not a comment changed. The 15 entries and the 39 `skips-itself` lines are those of `aaef28f`.
- **The self-check:** 121 checks, 117 before. All of the change is in the group `ListedTestsMustStillFail` (29 checks, 25 before: 5 added, 1 removed, 8 changed), in the Go sources it uses, in one new helper and in `WORKFLOW_SHA256`. The other eight groups (92 checks) are the same text, method by method.
- **The removed check and the removed rule are not a loss.** `test_listed_test_without_a_verdict_fails_only_if_go_test_failed` held the old rule. The rule for two listed tests that ran side by side (`RAN_BESIDE`) is covered by the new one: with neither reporting, the run is recorded as stopped and both are named as `was running`; with one panicking, the other is judged in the next run. Both cases have checks, and both failed or passed as they should in my plants and probes.
- **The earlier reviewers' files, unchanged** (hashes in `prior-SHA256SUMS.txt`, equal to those run for `09-audit.md`): the red team's 7 checks pass. Its 15 probes give 12 as expected and the 2 stated boundaries, and F2 prints `HOLE` because it expects the third step to exit 0 where it now exits 1, on a package run that a leftover goroutine stopped. That is the stricter rule again, not a hole: the step "Test" fails on that module as before. `rt8_lists.py`: `unexpected: 0`. The committed gate stops on a real second toolchain that reports go1.26.6. The last audit's mutants H1 and H2 are killed.

## 8. Validation

### 8.1 Commands I re-ran on the exact bytes of `8eefe6d` (tree `c3e784d2…`), as user `ci` with an empty environment

Go 1.26.5 from `/opt/go1.26.5`, outside the module cache, `GOTOOLCHAIN=local`, `GOFLAGS=-mod=readonly`, 4 CPUs.

| Command | Result | Log |
|---|---|---|
| `go mod verify`, `go build ./...`, `go vet ./...` | exit 0 each | `validation.log` |
| `GOOS=darwin GOARCH=arm64 go vet ./...` | exit 0 | `validation.log` |
| `gofmt -l docs_contract_test.go` | no output | `validation.log` |
| `go test -count=1 -run '^TestGo1265ToolchainBaselineDocsAndBuildContract$' .` | `ok` | `validation.log` |
| `git diff --check` of the repair and of the whole pull request | exit 0 each | `validation.log` |
| `python3 -I -B .github/ci/go_test_gate_selftest.py` | `Ran 121 tests in 150.399s`, `OK` | `selfcheck.log` |
| The same with its temporary files on a file system that ignores case (`ciopfs`) | `Ran 121 tests in 251.027s`, `OK`, 21:38:13 to 21:42:24, nothing left in the temporary folder | `casefold-whole.log` |
| Step "Test" on the real tree, with the list for this container | exit 0 after 384 s, 21:41:31 to 21:47:55. `test gate passed: 41 packages, 3 of them with skipped entries (12 entries); 40 tests skipped themselves, all of them listed`. The observed run of `es/app` passed with its 2 listed tests. Its first 53 s ran beside the self-check of the row above | `real-tree-container-list.gate.log` |
| Step "Listed tests still fail" on the real tree, same list | exit 0 after 245 s, to 21:52:00. 12 lines `still fails:`, then `all 12 listed tests still fail on this host, each in a run of its own and in the run of its package`. 3 runs of whole packages (8, 2 and 2 listed tests) and 12 runs of single entries. Each of the 15 ends with the bare line `FAIL`. No run has `-skip`, no run stopped, no error line | `real-tree-container-list.still.log` |

The list for this container is the one of `09-audit.md` (`list-container-aud9.txt`): the committed list without the three entries that pass in a container, and with one `skips-itself` line for the test that needs a Docker daemon. Against the committed list of `8eefe6d` it differs in exactly those four lines.

### 8.2 Mutants of the rewritten code: `aud9b_mutants.py.txt`, `aud9b_mutants.log`

14 changes of the committed gate, one each, all in `judged`, `in_the_run_of_its_package` and `still_failing`. I wrote them from the diff, without reading the writer's mutant file. Each asserts that the text it replaces occurs exactly once. Each runs against the committed self-check: first the group `ListedTestsMustStillFail`, then, if that passes, all 121 checks.

| Mutant | The change | Killed by the check |
|---|---|---|
| G1 | a listed test that was running when the test binary stopped counts as failing | `test_listed_test_that_ends_the_process_is_not_seen_failing` |
| G2 | the same, in the run of the package only | the same check |
| G9 | the same, in the `go test` of an entry alone only | the same check |
| G3 | a stopped run counts as ended when it left no entry without a verdict (the early return of `aaef28f`) | `test_listed_test_that_failed_before_another_went_on_did_not_stop_the_test_binary` |
| G4 | a run that stopped with no listed test to account for it is not recorded | `test_listed_test_that_ends_the_process_is_not_seen_failing` |
| G6 | such a run is not recorded when it left no entry without a verdict | `test_package_runs_again_until_a_run_comes_to_its_end` |
| G7 | such a run is named and does not fail the step | `test_listed_test_that_ran_when_something_else_stopped_the_test_binary` |
| G5 | every listed test that failed in a stopped run accounts for the stop, whenever it reported | `test_listed_test_that_an_earlier_run_judged_accounts_for_a_later_stop` |
| G10 | only an entry that the run still had to judge can account for its stop | the same check |
| G8 | a later run in which no test starts counts as a package of which no test started | `test_package_runs_again_until_a_run_comes_to_its_end` |
| G11 | an entry that skips itself in the run of its package is not named | `test_listed_test_that_skips_itself_is_named` |
| G12 | an entry that passes in the run of its package is not named | `test_listed_parallel_subtest_that_did_not_get_to_run_is_named` |
| G15 | an entry without a verdict in a run that came to its end is not named | `test_listed_subtest_that_does_not_run_is_named` |
| G16 | the entries that a stopped run left without a verdict are named with the advice to delete their lines | `test_listed_test_that_ends_the_process_is_not_seen_failing` |

**All 14 are killed, each by a failed assertion,** by 8 different checks. The check named is the first that failed, because each run stops at its first failure. The control passes all 121 checks (213 s, with two other mutants and the run of section 8.1 on the case-ignoring file system on the same machine). G1, G2 and G9 bring back the old rule in three places, and G3, G4, G6 and G7 are the four ways to let a stopped run pass.

Not run by me: the writer's 204 mutants (`mutants7.py`), and the 52 of my 65 mutants of `09-audit.md` that still apply, which the writer ran (47 killed, 5 of my 6 earlier survivors). The code they change outside the third step is byte-identical, and the checks that killed them are unchanged.

### 8.3 The runner result, from GitHub

Read with the GitHub tools between 21:33 and 21:36.

- **Run 45064532285, job 137337607603:** success, head `8eefe6d`, attempt 1, 20:06:38 to 20:20:09. Every step succeeded. It is the pull request's one check run.
- **The job log** is byte-identical to the writer's copy in `09-repair-evidence/` (SHA-256 `e5293b151c697ea7aaa4e1bae401097519d67501090cd1ac65f96700ebf7c57b`; the tool returns it without its final newline). It checked out `92a1e7c`, the merge of `8eefe6d` into `ae326b0`, on the image `ubuntu-24.04` version `20261116.133.1` with go1.26.5.
- **Self-check:** `Ran 121 tests in 112.362s`, `OK`. **Test:** `test gate passed: 41 packages, 3 of them with skipped entries (15 entries); 39 tests skipped themselves, all of them listed`.
- **Listed tests still fail:** 3 runs of whole packages and 15 runs of single entries. Each of the 18 ends with the bare line `FAIL` of the testing package. No run has `-skip`, so no package ran twice. No `panic:`, no `test timed out`, no error line. 15 lines `still fails:`, the same 15 as in the run at `aaef28f`, and the 39 names that skipped themselves are the same 39.

So every entry of today's list reports its failure through the testing package, and the new rule changes nothing for it.

## 9. The six claims the writer asked the audit to try

| Claim (`09-repair.md` section 12) | Result |
|---|---|
| (a) The step cannot exit 0 when an entry has no verdict `fail` from the testing package in the run of its package or in the `go test` of its own | **Holds** (section 4, probes R1 to R8, plants K, T, S) |
| (b) It cannot exit 0 when the last run of a listed package did not come to its end | **Holds** (R5, T2, T3, T6, B1; mutants G3, G4, G6, G7) |
| (c) The loop of runs ends | **Holds** by reading (section 4). Not shown by a mutant of mine: such a mutant never ends |
| (d) An entry is never named with the advice to delete its line because of a stop that something outside the list caused | **Holds for the run of the package.** For the `go test` of an entry alone see A9b-O2 |
| (e) Nothing changed in the mode `gate` | **Holds** (section 7) |
| (f) `go.yml` differs in comment lines only, and both holds notice an edit of it | **Holds** (section 6) |

## 10. Findings

**None.** No critical, high, medium or low finding in `aaef28f..8eefe6d`.

Status of the items of `09-audit.md`:

| ID | Status at `8eefe6d` |
|---|---|
| A9-F1 (low) | **Closed.** R3 is closed too, without the stated bound that I had expected to remain |
| A9-O1 `TestMain` that calls `m.Run` twice | Unchanged. It now also means: the first closing line counts as the end of the run. The tree has 0 `TestMain` |
| A9-O2 the message for a skip that cannot be listed | Unchanged, fails closed. Not in the assignment of this repair |
| A9-O3 reasons held by review | Unchanged |
| A9-O4 comment above the wrong constant | **Fixed** |
| A9-O5 commit trailer names a model | Unchanged. The new commit carries the same trailer lines. Whoever merges decides the text of the merge |
| A9-O6 tests leave files in the temporary folder | Unchanged, pre-existing, outside the patch |

Observations of this addendum. None blocks, and none needs a change before the merge.

- **A9b-O1. "Or a panic" means a panic of the test's own goroutine.** The list header says "Only a failure that the testing package reports counts: t.Fatal, t.Error or a panic". A test that fails by a panic in a goroutine that it started gets no verdict, so it cannot be listed either (plant S1). The step fails and says `it reported no failure`. The next sentence of the header covers it in substance ("a test that ends the process without reporting"). Wording only.
- **A9b-O2. In the `go test` of an entry alone, a stop without a report still ends with the advice to delete the line.** When the entry never ends alone (T5) or ends the process (R6, S1, S2), the message is `listed test no longer fails on this host (it reported no failure: …). Delete its line …, or correct the line`. The reason in brackets is right. The advice fits only partly: with the line deleted the step "Test" would fail on that test. Inference: the same message comes for a subtest whose unlisted parent stops the binary in that run. It fails closed, and the cure is in the test.
- **A9b-O3. A listed test that panics is recognized only if no other test starts or goes on between its report and the end of the process.** Inference, not shown: in a package with busy parallel tests another test could start in that moment. The step would then fail with the new message, where at `aaef28f` it could pass. Red, not green. The rule itself is that of `aaef28f`. No entry panics today.

## 11. Not covered, and Unknown

- **The merge with `b8d6bc3`.** I checked only this: `git merge-tree --write-tree 8eefe6d b8d6bc3` reports no conflict and gives the tree `5f302414e1f86d48c37e43513efc87f1d55d8cd2`; PR #17 changes 3 test files in `es/app`, none of the 9 files of this pull request; its diff adds and removes no `func Test` line, no `t.Run` line and no `Skip` line. I did not run the merged tree. The writer did, in a container (`09-repair.md` 7.8). The runner has not run it.
- **The test of the root package that the writer saw fail once on timing** (`TestRemoteAlphaESServiceTLSStatusCombinedGroupSignalFailureLiveDescendant/term`). It is outside the patch. It did not fail in my run of the two steps on the real tree: the step "Test" exited 0, and the log of the third step, which prints every failed test of its package runs, does not hold its name. One run of each says nothing about how often it fails.
- **macOS.** Not run at this head by anyone. Inference: the four new checks behave the same there. They use `os.Exit`, panics, channels and a shell stand-in for the `go` command.
- **The writer's mutants and the full set of my earlier ones:** not re-run (section 8.2).
- **Red-team pass:** none on `8eefe6d`.
- **Unknown:** why one entry took 45 s alone in the runner run (`09-repair.md` 7.6). The gate does not influence how long a test runs, and the step passed.

**Stop conditions for the merge gate.** The verdict is for the bytes of `8eefe6d`. Updating the branch with `trunk_dev` makes a new head. Per provenance §5.4 step 2 that needs a new manifest and a `git range-diff` that shows the patch unchanged, and the runner has to be green on the new merge. A conflict, a changed patch or a red run sends it back.

## 12. Closing state

State at 21:55, after the last run.

- **The target:** untouched. Nothing was pushed, no branch was created, no comment or review was posted, and the pull request was not edited. The remote refs and the pull request are as at opening (section 3).
- **My clones:** the provenance clone has `HEAD` at `ae326b0` with the bytes of `8eefe6d` in its working tree, which is the state the cumulative manifest leaves. The two scratch clones that the runs used are at `8eefe6d`, tree `c3e784d2…`, with no line from `git status --porcelain --ignored`.
- **Processes and mounts:** no process of the test user is left, and the FUSE mount is gone.
- **The toolchain:** `match.go` of `/opt/go1.26.5` has the SHA-256 it had before (`f2841875…bebe`).
- **Left in the test user's temporary folder,** outside every repository tree: 36 entries, 784 KB. I emptied that folder before the first run of this addendum. It held 0 entries after the self-check, the probes and the plants (`jobA-status.txt`, `jobB-status.txt`). 35 entries are what the repository's own tests leave behind in the two step runs on the real tree (A9-O6): 18 files `remote-alpha-runtime-security-boundary.*.json`, 14 files and folders `tmp.*` and 3 folders of two `TestSupportedLocal…` tests. One is a folder of the red team's `rt8_lists.py`. I removed nothing there afterwards. The container goes away with the session.
- **Evidence:** in `09-audit-addendum-evidence/`, listed in its `README.md`.

## 13. Sensitive-material handling

No secret, token, key or credential was read or written. The runs used an unprivileged user with an emptied environment, so no session token reached a test. Before delivery I scanned this report and the 50 evidence files with the project's leak scanner (`ge_chat_archive.py scan`, version 1.4.0): 0 findings. My own search for token and key patterns and for e-mail addresses found none. The runner log shows its token only as `***`.

## 14. Confidence

- **Provenance: high.** Both manifests reproduced at opening and closing, the pull request head is the audited commit, and the runner ran a merge commit of it.
- **Validation: high** for what I ran on the exact bytes (section 8.1), the probes and the plants. The runner result is read from GitHub. Not validated by me: macOS, the merged tree.
- **Implementation: high** that A9-F1 is closed and that the step cannot pass on a stopped run of a package or on an entry without a reported failure, within what the gate reads: the event stream of a test binary that does not forge it. That limit is stated since `07-repair.md` and is unchanged.

## 15. Report delivery

- This file: `/mnt/project-files/reports/Execution-Substrate/ci-go-workflow/09-audit-addendum.md`. Its SHA-256 is in the reply that delivers it.
- Evidence: `/mnt/project-files/reports/Execution-Substrate/ci-go-workflow/09-audit-addendum-evidence/`, 50 files, with a `README.md` and a `SHA256SUMS.txt` that lists the 49 others.
- `09-audit.md` and `09-audit-evidence/` are unchanged.

STATUS: READY
