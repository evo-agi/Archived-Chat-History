# Evidence for `08-repair.md`

Fourth repair of Execution-Substrate PR #14, 2026-11-22 (UTC). Two commits: `76d9a91c012b20aaa3a00cec53e34665aca6a18b` (tree `f487873064932de4cd962d138ea6b8e687586bf1`) and the head `aaef28f36f393e78f832a9caa745edeb02565a6c` (tree `f00fdd4053565f0d199b3ba013d1388d3f5fa0fd`). Everything here was produced by the writer thread in its own cloud container, except the runner logs, which are GitHub's, and the Mac reports, which a session on David's Mac wrote.

Paths inside the logs (`/home/ci/...`) are paths in the writer's container. Scripts are stored with `.txt` appended to their names. The report says which section each file supports.

## Provenance (report sections 2 and 14)

| File | What it is |
|---|---|
| `manifest-repair-only.json` | v2 manifest of this repair (both commits), with HEAD at the last audited tip `b39fa35`. The focused audit reads this one. |
| `manifest-cumulative.json` | v2 manifest of PR #14 with HEAD at the base `ae326b0`. |
| `manifest-second-commit.json` | v2 manifest of the second commit alone, with HEAD at `76d9a91`. |

## On the GitHub runner (7.5)

| File | What it is |
|---|---|
| `runner-run-45046634281-job-137282573571.log` | Complete log of the runner job at `aaef28f`, the head. |
| `runner-run-45039279766-job-137259866158.log` | Complete log of the runner job at `76d9a91`, the first commit. |
| `runner-skips.txt` | The 39 lines `skips itself: ...` of the step "Test" in the log of the first commit, without their time stamps. |
| `runner-skips-head.txt` | The same 39 lines from the log of the head. |

## Container setup (7.1)

| File | What it is |
|---|---|
| `container-env.sh.txt` | Environment of every run as the unprivileged user `ci`. |
| `container-run.py.txt` | Wrapper that resets three signals and removes the proxy variables before a run. Every run here was started as `env -i python3 run.py bash <script>`. |
| `container-sync.sh.txt` | Makes the scratch copy of the tree that the runs use. |

## The second commit in the container (7.1, 7.2, 7.3)

| File | What it is |
|---|---|
| `container-after6.sh.txt` | Runs the light workflow steps on the tree of the second commit, then the red team's seven checks and the audit's two mutants against its self-check. |
| `container-validate5.sh.txt` | Module check, build, both vet commands, gofmt and the docs contract test. `after6.sh` runs it on the second scratch copy. |
| `container-validation.log` | Its output on the tree of the second commit. |
| `container-selftest.log` | The whole self-check on the tree of the second commit: 117 checks. |
| `container-selftest-status.txt` | Its exit status and seconds. |
| `redteam8-checks.log` | `go_test_gate_redteam8.py` beside the self-check of the second commit: 7 checks, all pass. |
| `aud8_mutants-H1-H2.log` | `aud8_mutants.py H1 H2` against the self-check of the second commit: both killed. |

## The first commit in the container (7.1, 7.2, 7.3)

| File | What it is |
|---|---|
| `container-after5.sh.txt` | Starts the validation and the two gate commands on the tree of the first commit. |
| `container-validation-first-commit.log` | Output of `validate5.sh` on the tree of the first commit. |
| `container-fullgate5.sh.txt` | Runs the two gate commands as the workflow does. |
| `list-container.txt` | The list for this container: the committed list without the three entries that pass here, and with one more `skips-itself` line for the test that needs Docker. |
| `container-gate.log` | Mode `gate` on the real tree with that list. |
| `container-still-failing.log` | Mode `still-failing` on the real tree with that list. |
| `container-gate-status.txt` | Exit statuses and seconds of both commands. |
| `adopt5.sh.txt` | How the red team's and the audit's files were run at the first commit (its last part started the first mutant run). |
| `inputs-SHA256SUMS.txt` | SHA-256 of the five files as run. They are byte copies of the files in `08-red-team-evidence/` and `08-audit-evidence/`. |
| `redteam8-checks-first-commit.log` | `go_test_gate_redteam8.py` beside the self-check of the first commit: 7 checks, all pass. |
| `rt8.log` | `rt8.py`: 15 probes, no hole. It reads only the gate, which both commits share. |
| `rt8_lists.log` | `rt8_lists.py`: `unexpected: 0`. It reads only the gate. |
| `darwin-plant.log` | A planted error in a file that builds only on macOS: "Vet" passes, "Vet for macOS" fails. |
| `aud8_patchrelease.log` | `aud8_patchrelease.sh`: the committed gate stops on go1.26.6. |
| `aud8_mutants-H1-H2-first-commit.log` | `aud8_mutants.py H1 H2` against the self-check of the first commit: both killed. |

## Mutants (7.4)

| File | What it is |
|---|---|
| `mutants5.py.txt` | The control and 195 deliberate changes of the gate. |
| `mutants5-hints.json` | For each mutant, the check or group of the self-check that runs first. |
| `mut6.sh.txt` | How the run against the self-check of the second commit was started. |
| `mutants6-groups-first.txt` | The mutants of its first part: the control, S7, S7b and the groups Y and Z. |
| `mutants6-groups-second.txt` | The mutants of its second part: all others. |
| `mutants6-first-part.log` | Result of the first part, on the tree of the second commit. |
| `mutants6-second-part.log` | Result of the second part, on the tree of the second commit. |
| `mutants6-tree.txt` | The git tree of the scratch copy that this run used. |
| `mutants5-first-run-first-part.log` | Earlier run against the self-check of the first commit: the control and the first 33 mutants, each with the whole self-check. |
| `mutants5-first-run-second-part-stopped.log` | Earlier run against the self-check of the first commit, with hints: 133 mutants up to Y2, then stopped by me. S7 survives here. |
| `mut5b.sh.txt` | How that second part was started. |
| `mutants-second-run-first-phase-summary.txt` | Summary of a run against a working state between the two commits, in which Y5, Y6 and Z16 survived. Its full log was deleted by mistake; this is what was kept. |
| `mutants6-S7.log` | S7 and S7b against a working state between the two commits: both killed. |
| `mutants6-three.log` | Y5, Y6 and Z16 against the bytes of the second commit: all killed. |

## The runs on David's Mac (7.6)

| File | What it is |
|---|---|
| `mac-instructions.txt` | The instructions of the first run, at `76d9a91` and at PR #16's `0a069ec`. |
| `mac-run-report.txt` | What the session on the Mac reported for the first run. |
| `mac-instructions-second-run.txt` | The instructions of the second run, at `aaef28f`, with a copy of Go 1.26.5 outside the module cache. |
| `mac-run-report-second-run.txt` | What the session on the Mac reported for the second run. |

The SHA-256 of every file is in `SHA256SUMS.txt` (the README itself is the last line there).
