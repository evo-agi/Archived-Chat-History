# REPAIR REPORT 4: Execution-Substrate Linux CI (PR #14), every skip is listed

**Verdict:** REPAIR_COMPLETE for the bytes. Ready for the focused fresh audit. Both runs on David's Mac are done: the Go tests that this PR changed pass on macOS, and at the new head the gate's self-check passes there too, with a Go 1.26.5 outside the module cache. Nothing in this report waits for a decision by David. Two things that are his are named in section 8 and are with the coordinator: whether the check is required on `trunk_dev`, and whether the runner should get Nomad and Vault so that the 37 integration tests run.
**Effect status:** TOPIC_BRANCH_PUSHED (fast-forward, no force) · DRAFT_PR_UPDATED https://github.com/evo-agi/Execution-Substrate/pull/14 · CI_GREEN_ON_RUNNER (run 45046634281 at `aaef28f`, and run 45039279766 at `76d9a91`; each the first run of its bytes) · PR_16_NOT_TOUCHED · MERGE_NOT_PERFORMED · INDEPENDENT_AUDIT_NOT_PERFORMED on the new bytes · RED_TEAM_NOT_PERFORMED on the new bytes

This report adds to `07-repair.md`, which stays the implementation report for everything up to `b39fa35`. It answers `08-red-team.md` (HOLDS WITH CAVEATS, SHA-256 `dd8e8205c8878fd9114a93a3a8b33db4cb6d91e018019760ec31d533092e2c4d`) and the one finding of `08-audit.md` (ACCEPT, SHA-256 `86c55c39f3a32b04100f30df8de637dad1dd4b7540869b4f66642f6875317ed7`). Those hashes are what I read. The repair is two commits on top of the audited `b39fa35`: `76d9a91` holds the fixes, and `aaef28f` is a small second commit that changes the self-check, one doc paragraph and its hold. The second commit came out of the run on David's Mac and out of the mutant run (section 4.7). The gate, the list and the workflow are the same in both.

All times are UTC on 2026-11-22.

## 1. What was repaired, in short

**RT8-1 (medium): a test that skips itself was outside the gate.** A broken test with one `t.Skip` line passed both steps, and nothing showed which tests skip on the runner. Now every skip needs a reviewed line. The list file has a second kind of line, `skips-itself <package> <test>`, with the reason in a comment. In every package, the tests that skipped themselves must be exactly the listed ones. A skip without a line fails the step "Test". So does a line whose test no longer skips. The log names every test that skipped itself and what it wrote.

**The runner count is no longer Unknown: 39 tests skip themselves on the runner** (run 45039279766):

| Count | Package | Why, as the tests wrote it on the runner |
|---|---|---|
| 36 | `es/app` | No `nomad` command: 35 times `nomad binary lookup failed: exec: "nomad": executable file not found in $PATH`, once `slice 0 bringup requires nomad: …` |
| 1 | `es/app` | No `vault` command: `supported-local setup validation requires vault: …` |
| 2 | `es/admission/internal/reliablesubmit` | Helper processes that only do work when another test starts them: `helper process only` and `allocator helper control, executed by TestPrivateReplaySharedObjectAllocation`. They skip on every host. |

The 39 lines I wrote from reading the code were exactly right. The first runner run of these bytes was green, and the list did not have to be corrected. The red team's census found 38 skips in `es/app` in a container without Docker. On the runner it is 37, because the runner has Docker and `TestWorkloadCanCreateAndUseLocalRuntimeIdentityEndpointFromTmpfsWorkspace` runs there.

**What that means in plain words:** the submit-flow integration tests do not run in CI. Before this repair nothing said so. Now the list says so line by line, and the day the runner gets Nomad and Vault, the step fails until the lines are deleted.

**The four low findings:**

- **RT8-2:** a package without entries that runs none of its tests passed. Now every package is judged by the rule that the 3 listed packages already had.
- **RT8-3:** an entry was judged only in a run of its own. Now every entry must also fail in a run of its whole package with nothing skipped.
- **RT8-4:** files that build only on macOS were never compiled on the runner. A new step runs `GOOS=darwin GOARCH=arm64 go vet ./...`.
- **A8-F1:** the self-check did not hold that the gate compares the Go version exactly. It does now, and the audit's two mutants fail.

**What the run on David's Mac added (second commit).** The Go tests that this PR changed pass on macOS. The gate's self-check did not run clean there at the first commit, for three reasons, none of which touches CI on the runner:

- **A defect of mine in one new check.** Two generated tests whose names differ only in the case of a letter shared one marker file on the Mac's file system. The marker files are now named in hexadecimal digits.
- **A limit of the gate that was not written down.** The observed run needs a Go installation outside the module cache. The `go` command refuses `-overlay` for a file beneath `GOMODCACHE`, and a toolchain that the `go` command downloaded itself lies there. The gate fails with that error. It does not pass. The doc says so now, and a check holds it.
- **The Mac's first `go` on `PATH` is 1.26.1.** That was known: the self-check needs go1.26.5 first on `PATH`.

At the second commit the self-check passes on the Mac, 117 of 117, with a copy of Go 1.26.5 outside the module cache (7.6).

The mutant run found four gaps in the self-check, not in the gate: four mutants passed all checks that should not have. The second commit adds the checks that fail them (4.7).

**What it costs.** The job took 12 m 15 s at `76d9a91` and 12 m 13 s at `aaef28f`. The run at `b39fa35` took 7 m 57 s. The 4 m 18 s more of the first are: 3 m 19 s for the package runs of the third step, 46 s for the larger self-check (114 checks then, 90 before, 117 now), 25 s for the macOS vet step, and 13 s less in the step "Test" (run to run noise). Section 7.5 has the times.

## 2. Target identity

| Field | Value |
|---|---|
| Repository | evo-agi/Execution-Substrate |
| Base ref and SHA | `trunk_dev` at `ae326b0ddc30ec6b35883ee32945c622405b68b6` (re-fetched before the manifests and after the push; unchanged) |
| Topic branch | `claude/project-thread-sqldt7-ci` |
| Last audited tip | `b39fa35d444a4bd87a3901287bb6a346577c81b9` (audit ACCEPT, red-team HOLDS WITH CAVEATS) |
| This repair | two commits: `76d9a91c012b20aaa3a00cec53e34665aca6a18b` (tree `f487873064932de4cd962d138ea6b8e687586bf1`), then `aaef28f36f393e78f832a9caa745edeb02565a6c` |
| Tip tree | `f00fdd4053565f0d199b3ba013d1388d3f5fa0fd` |
| Draft PR | #14, base `trunk_dev`, now 9 files, +4952/−9. This repair against `b39fa35`: 6 files, +1831/−164. The second commit alone: 3 files, +208/−17 |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified with `sha256sum -c` before each run |
| Manifest upstream | `origin/trunk_dev` |
| **Repair-only manifest (the delta since the last audited tip; the focused audit reads this one)** | `1ccacc66030fc16d1f21b3fb9ca0b4586967f515195b642050e120515e021a0f` (1,448 bytes), HEAD `b39fa35`, 6 files, all tracked_modified; textual diff `aff0544899a09f9e255955cd6dfed0f1ac2fe8623cafa87caecfde9dc6decd2a` |
| Cumulative manifest | `774fe3a67db1a0cba962bf9fefd80a12e5ee55f97c42654eb030e656d49020ee` (2,035 bytes), HEAD `ae326b0`, 9 files: 4 untracked new, 5 tracked_modified; textual diff `39ea9db3ac152ce8ded7bd1dac0af84bf04758e0702515ed3177304006242c37` |
| Manifest of the second commit alone | `8c620ad3365c758e1fa46f58b12f20a76f237b6f0343eabe52869c1fe37045fc` (873 bytes), HEAD `76d9a91`, 3 files, all tracked_modified; textual diff `b0d493befc6d5c6bb2e14b94b1815615967799b6b30bbd0c5a39bc61680b2a9f` |

Each manifest was taken twice before the second commit, and the two files were byte-identical (`cmp`). The manifests of the first commit alone (repair-only `bf9b8131…4562`, cumulative `36c67c23…3d94`, taken and reproduced at 15:36) are superseded by these.

**Auditor reproduction:** provenance §5.3 with `BASE=ae326b0ddc30ec6b35883ee32945c622405b68b6`, `TOPIC=claude/project-thread-sqldt7-ci`, `TIP=aaef28f36f393e78f832a9caa745edeb02565a6c`, and the upstream pinned with `git branch --set-upstream-to=origin/trunk_dev`. I ran that in a fresh clone from GitHub after the push. With HEAD at `b39fa35` it gave the repair-only manifest, with HEAD at `ae326b0` the cumulative manifest, and with HEAD at `76d9a91` the manifest of the second commit, all byte-identical to mine (`cmp`).

Final working-tree status after each commit: clean (`git status --porcelain` empty). Before each `git commit` a script checked that the staged set equalled the set of that commit's manifest (6 paths, then 3) and that the bytes of the working tree equalled the hashes in it.

PR #16 (`claude/project-thread-k69qcw` at `0a069ecbe53c842d33c932f63aed2af523e2eb0c`) is unchanged.

## 3. Reconnaissance

No subagents were used. I read `08-red-team.md` and its evidence folder (the seven checks, the probe files `rt8.py` and `rt8_lists.py`, the census of the real tree), and `08-audit.md` with its script for A8-F1. Everything they found was adopted. Nothing was rejected. Two points needed facts of my own before I could build on them.

**What `go test -json` shows of a run that does not end.** The repair of RT8-3 runs a whole package with nothing skipped, and two listed tests of the root package could stop a test binary. I measured the event stream on throwaway packages with Go 1.26.5:

- A run that reaches its end has one package-level output line, `PASS` or `FAIL`, that the testing package writes itself, before the line `ok` or `FAIL <package>` of the go command.
- A test that panics gets a `fail` verdict, and so do its ancestors. These verdicts come after the last `run` event of the stream, and the closing line is missing.
- A test that ends the process (`os.Exit`) gets no verdict, and the closing line is missing.
- A parallel test writes `pause` when it steps aside and `cont` when it goes on. A test that paused and never went on has no verdict.

The gate uses exactly these four facts. The self-check has a throwaway module for each.

**Which tests skip themselves on the runner.** Before the first runner run this was Unknown. I read every `t.Skip` site that the census of the red team reached, and wrote the list for a host with Docker and without `nomad` and `vault`. The runner then decided (section 7.5).

**No test of the tree reads `testing.Verbose()`** (searched). This matters because packages without entries now run through `go test -json`, which is a verbose run.

## 4. Implementation decisions

Classification under `AGENTS.md`: this change touches no service contract, no lifecycle rule and no reopened seam. It changes CI tooling and section 10 of `.docs/system_overview/go_toolchain_baseline.md`, which describes that tooling. The doc and the docs contract test were changed in the same commit as the code.

### 4.1 The list has a second kind of line (RT8-1)

`.github/ci/environment-only-tests.txt` keeps its entries, which name tests that fail on the runner. It gets lines of a second kind:

```text
skips-itself <package> <TestName>[/<subtest>...]
```

The file stays the one reviewed place. Each group of lines has a comment that gives the reason, as the entries have. The rules:

- A line stands for exactly the test or subtest it names. A subtest that skips itself needs a line of its own, also when its parent skips after it.
- The package must be one of the module, and `go test -list` must name the top-level test exactly once there. That is the rule for entries.
- A line must not name an entry, lie inside one or hold one. What lies inside an entry does not run in the gate, so such a line could never be checked. The gate refuses the file with status 2 before any test runs.
- A line that repeats, and a line that is neither kind, are refused with status 2.

**Why the reasons are comments and are not compared by machine.** The gate could hold the text that a test writes when it skips. I did not do that. The texts carry paths, version numbers and error messages of the host, so a held text would break on a runner image update without any change in the tree. The entries work the same way: the machine holds the fact (it fails, it skips) and review holds the reason. The log of the step prints what each test wrote, so a reviewer reads the real reason beside the line.

### 4.2 The step "Test" (mode `gate`): RT8-1 and RT8-2

For every package, with and without entries, the gate now reads the verdict of every test and subtest:

- **Skips.** The tests and subtests that ended with `skip` must be exactly the `skips-itself` lines of that package. A skip without a line fails the step and prints the line to add. A line whose test passes or does not run fails the step and says which. A line whose test fails is already a failed run.
- **Visibility.** For each package with skips the log has a group `<package>: N tests skipped themselves` with one line per test: its name and the first line it wrote. The closing line of the step gives the totals.
- **Every package is judged by the same rule (RT8-2).** The gate runs `go test -list '^Test'` for every package. Every top-level test that is listed and is not a whole-test entry must report a verdict. The testing package's `PASS` line must be there when the package passed. So a test binary that runs none of its tests, or only some, or a `TestMain` that never calls `m.Run`, fails the step in every package. Before, this held for the 3 packages with entries only.
- **The observed run** (the second run of `es/app`) is held to the same skip rule as the first.

Packages without entries now run as `go test -json -count=1 <packages>` in one command, as before in one command, so that the gate can read verdicts.

### 4.3 The step "Listed tests still fail" (mode `still-failing`): RT8-3

Every entry is now judged twice: in a run of its whole package with nothing skipped, and in a `go test` of its own, as before. An entry must fail in both. The step names an entry that passes, skips itself or does not run in the package run:

```text
::error::listed test does not fail in the run of its package (it passes): <package> <test>. The gate skips a test that would not fail there. Delete its line from <list>, or correct the line.
```

Three details:

- **A listed test that stops the test binary.** No test after it runs in that process. The gate sees that the run did not reach its closing line, takes the one listed test that failed last as the one that stopped it, and runs the package once more without that test, for the entries that the first run did not get to. This repeats until the run ends or nothing is left.
- **When the run does not show which test stopped it.** If more than one listed test was running when the binary stopped, the gate does not guess. Each is named with the reason "another listed test was running with it when the test binary stopped, and nothing shows which of them stopped it", and the step fails.
- **A parallel test that never went on (probe J2).** A listed test that paused and had no verdict when the run ended counted as failing before. It now counts as "it did not get to run" and is judged in the next run, or named.

The skip lines need no run in this step. The step "Test" already fails when a listed test no longer skips.

### 4.4 The workflow: RT8-4

One more step after "Vet":

```yaml
      - name: Vet for macOS
        run: GOOS=darwin GOARCH=arm64 go vet ./...
```

It type-checks and vets every package as built for macOS, and so compiles the files that no other step compiles on the runner. It runs no test. The workflow file changed, so `WORKFLOW_SHA256` in the self-check changed with it, and the docs contract test holds the new `run:` line.

### 4.5 The self-check: A8-F1 and the new rules

117 checks, 90 before. 114 came with the first commit and three with the second (4.7). The new ones of the first commit, by group:

| Group | New checks | What they hold |
|---|---|---|
| `GateHoldsEverySkipToTheList` (new) | 10 | A skip without a line fails in a package with entries, in one without, and beside a listed subtest. A line does not reach another package or a test whose name only resembles it. A subtest needs its own line. A line whose test no longer skips fails. A skip inside a whole-test entry needs no line, because it does not run in the gate. The log shows what the test wrote. The observed run holds its skips. The third step runs nothing for these lines. |
| `GateChecksWhatReallyRan` | 4 | A package without entries that runs nothing, runs only some tests, or never calls `m.Run` fails. A package with test files and no test passes. |
| `GateRefusesAListItCannotTakeLiterally` | 2 | Skip lines are read as literally as entries. Lines of both kinds that only look alike are accepted. |
| `GateScopesEachEntryToItsPackage` | 1 changed, 1 case | The old check `test_unlisted_test_that_skips_itself_has_run` held the opposite of RT8-1 and is replaced. |
| `ListedTestsMustStillFail` | 8 | A listed test that passes in the run of its package is named (J1). A parallel subtest that did not get to run is named (J2). A listed test that stops the binary does not hide the next entry, also when the stopper is a subtest, and only the stopper is left out of the next run. Two that ran side by side are both named. A test that is not listed and stops the binary fails the step. |
| `WorkflowKeepsWhatTheGateDependsOn` | 1 | The vet lines of the workflow are exactly `go vet ./...` and `GOOS=darwin GOARCH=arm64 go vet ./...`. |

**A8-F1.** `test_another_toolchain_is_refused_before_any_test_runs` now puts six go commands in front of the gate, each with the real Go root, so that only the reported version differs: `go1.0.0`, the next patch release, patch plus ten, the held version with a `0` appended, the Go line without a patch number, and the held version with `rc1` appended. Each must give status 1, the exact message, and no test run. The audit's mutants H1 and H2 now fail this check (section 7.3).

**The red team's seven checks.** What each of them asserts is now held by a check of the self-check, with the message texts filled in. Some share one check: the three cases of RT8-1 are one check with three modules, and the two cases of RT8-2 are one check with two lists. The red team's own file also runs unchanged against the new gate, and all seven pass (section 7.2).

**How the self-check tells the two kinds of runs apart.** A generated test writes a marker file when it runs. A test binary that was started with `-test.run` writes it into another folder. So a check can say which tests ran in the run of a whole package and which in a `go test` of one entry.

### 4.6 Docs

Section 10 of `.docs/system_overview/go_toolchain_baseline.md` says what the steps now do (first commit): the macOS vet step, the two kinds of lines, the skip rule, the rule for every package, and the entries judged twice. The sentence that RT8-1 found to be wider than the check now reads: the list is "the single statement of what the test step excludes and of which tests exclude themselves on that runner". The doc also says what a green run does not show: "It does not show that a test named in the list passes: on that runner those tests fail or skip themselves." `docs_contract_test.go` holds these sentences and the new workflow line.

### 4.7 The second commit: what the Mac run and the mutant run showed

Three files: the self-check, the doc and the docs contract test. The gate, the list and the workflow are byte-identical to `76d9a91`, so `WORKFLOW_SHA256` did not change.

**Marker files are named in hexadecimal digits.** A generated test records that it ran by creating a file. The file was named after the test, and the Mac's default file system does not tell `TestSkips` from `TestSKIPS`. So one case of my new check `test_names_that_only_resemble_a_line_are_not_covered` failed there, although the gate had done the right thing: it exited 1 and named `TestSKIPS` as not listed. The file name is now the import path and the test path in hexadecimal digits. That also removes an old ambiguity: `/` was written as `__`, so a name with `__` in it would have been read back wrong.

**The gate needs a Go installation outside the module cache, and that is now stated and held.** On the Mac, Go 1.26.5 exists only as a toolchain that the `go` command downloaded into the module cache. With it first on `PATH` the gate's observed run stops: `go: overlay contains a replacement for …/src/testing/match.go. Files beneath GOMODCACHE (…) must not be replaced.` The gate then fails with `::error::test gate failed: the observed run of <package>`. It fails closed. On the runner Go comes from `actions/setup-go` and lies outside the module cache, as the green runs show. This limit exists since `b39fa35`. Nobody had hit it, because every container so far had Go in a directory of its own. What changed:

- Section 10 of the doc has two sentences on it, and `docs_contract_test.go` holds them.
- The header of the self-check says what the go command on `PATH` has to be: the named version, because the throwaway modules declare `go 1.21` and the go command does not switch toolchains for them, and installed outside the module cache.
- A new check, `test_toolchain_beneath_the_module_cache_stops_the_gate`, puts a go command in front of the gate whose `GOMODCACHE` is the parent of its Go root. The first run of the package passes, the observed run is refused with that message, the gate exits 1, and the step for the listed failures, which makes no observed run, exits 0.

I did not make the gate work with such a toolchain. The only way is to copy the whole Go installation somewhere else for every run, for a case that does not occur on the runner.

**Four gaps in the self-check that mutants showed.** In each the gate was right, and no check would have noticed if it were not. The first mutant run, against the self-check of the first commit, let four mutants pass that should not (7.4):

- **S7, only status 1 counts as a failed run.** The gate fails a package when `go test` ends with a status other than 0. Since the first commit it also fails when `go test` does not report that the package passed, so the old check, in which a test failed, could no longer tell the two rules apart. `test_go_test_that_ends_with_a_status_other_than_1_fails_the_gate` now has two more cases in which every test passes and only the status of the go command, 3, shows the failure: one for a package with entries and one for the packages without. A new mutant S7b covers the second place.
- **Y5, the `FAIL` line counts as the `PASS` line.** New check `test_test_binary_that_hides_its_failing_tests_fails_the_gate`: a `TestMain` that ends with status 0 although a test failed. `go test` then prints `ok` for the package, and the failing test has its verdict like any other. The testing package closed the run with `FAIL`, and the gate goes by that. So this case was already caught by the gate of the first commit. Now it is held.
- **Y6, a line that starts with `PASS` counts.** One more case in `test_test_binary_that_never_runs_the_tests_fails_the_gate`: the test binary runs nothing and writes `PASS is the first word of this line`.
- **Z16, the next run leaves out only the last test that stopped the binary.** New check `test_two_listed_tests_that_stop_the_test_binary_one_after_the_other`: the third run of the package has to leave out both.

All five mutants are killed by the self-check of the second commit (7.4).

## 5. Every finding and what happened to it

| ID | Severity | What happened | Where to check |
|---|---|---|---|
| RT8-1 | medium | **Fixed.** Skip lines in the list; exact match in every package and in the observed run; unlisted skip and stale line both fail the step "Test"; the log names every skip. The old self-check that held the opposite is replaced. The doc sentence is now true. The runner count is 39. | 4.1, 4.2, 7.2, 7.5 |
| RT8-2 | low | **Fixed.** `go test -list` and the verdict rule for every package, plus the `PASS` line rule. | 4.2, 7.2 |
| RT8-3 | low | **Fixed** as the red team required: every entry must also fail in a run of its whole package with nothing skipped. Probe J2 (a parallel test that never ran its body) is fixed too. One bound of the check is stated in section 8. | 4.3, 7.2, 8 |
| RT8-4 | low | **Fixed.** Step "Vet for macOS". A planted error in a macOS-only file passes "Vet" and fails the new step. | 4.4, 7.2 |
| A8-F1 | low | **Fixed.** Six other versions with the real Go root must each stop the gate. The audit's mutants H1 and H2 are killed. | 4.5, 7.3 |
| A8-O6 | observation | **Fixed** in the pull request description: it now gives the number of checks once, 117, of which 5 read the workflow file. | PR #14 |
| M-1 (Mac run) | defect of the first commit, in the self-check | **Fixed** in the second commit. Marker files are named in hexadecimal digits, so two test names that differ only by case keep two files. The second Mac run passes. | 4.7, 7.6 |
| M-2 (Mac run) | limit of the gate since `b39fa35`, not written down | **Stated and held** in the second commit: the observed run needs a Go installation outside the module cache. With another the gate fails with the error of the `go` command. Doc, self-check header, one new check. | 4.7, 7.6, 8 |
| S7, Y5, Y6, Z16 (mutants) | gaps in the self-check of the first commit; the gate was right | **Fixed** in the second commit: two new checks and three new cases. | 4.7, 7.4 |
| O-1 (red team) | needs David | **Not mine to do.** Whether "build, vet and test" is a required status check on `trunk_dev` is a repository setting. The coordinator raises it with David. | 8 |
| O-2 | observation | **No machine check, as the red team proposed.** The rule for audits (treat every added list line as a finding until its host reason is shown) now covers both kinds of lines. For a `skips-itself` line the machine holds that the test really skips on the runner. | 8 |
| O-3 | observation | **Not done.** It was outside the findings I was asked to fix. Section 8 says what it would take and when it starts to matter. | 8 |
| O-4, O-5, O-7, A8-O1 to A8-O5 | observations | **No change.** None asks for one. O-5 (probe E1) and probe C1 still behave as their reports state. | 7.2 |
| O-6 | open with the coordinator | **No change.** 15 passing subtests still stand under two whole-test entries (`4 pass, 18 fail` and `11 pass, 4 fail` on the runner). The list header says why they are listed whole. | 7.5 |

## 6. Files touched

This repair, against `b39fa35` (6 files, all modified). The second commit touches three of them: the self-check, the doc and the docs contract test.

| Path | Classification | Summary |
|---|---|---|
| `.github/ci/go_test_gate.py` | CI tooling | Skip lines and the skip rule; listing and verdict rule for every package; package runs in the third step; docstring. 1,048 lines. |
| `.github/ci/go_test_gate_selftest.py` | CI tooling, test | 117 checks (90 before); new sources for throwaway modules; marker split; marker names in hexadecimal digits; new `WORKFLOW_SHA256`. 3,466 lines. |
| `.github/ci/environment-only-tests.txt` | CI data | Header for both kinds of lines; the 15 entries unchanged; 39 `skips-itself` lines in three groups with reasons. |
| `.github/workflows/go.yml` | CI workflow | Step "Vet for macOS"; comments of the two test steps. SHA-256 `0383a2f066da5490db36abb91f4896c076a7d5cc45410cec11f40b85201db8bf`. |
| `.docs/system_overview/go_toolchain_baseline.md` | doc | Section 10 says what the steps now do and do not show, and what Go installation the observed run needs. |
| `docs_contract_test.go` | test | Holds the new doc sentences and the new workflow line. |

Unchanged by the second commit, byte for byte: `go_test_gate.py` (SHA-256 `e2715daf181f297454bcfd25e54b64d7d533339f900f1aa1e0c0685c583b6c3b`), `environment-only-tests.txt` and `go.yml`. The manifest of the second commit shows it: it has three files.

Cumulative against the base `ae326b0`: 9 files. The three others (`es/admission/internal/reliablesubmit/replay_custody_file_test.go`, `es/admission/result_auth_test.go`, `remote_alpha_operator_test.go`) are unchanged since `b39fa35`.

Dependencies changed: none. `go.mod` and `go.sum` are untouched. No production code is touched.

## 7. Validation

Which bytes: each runner run (7.5) used its commit itself. The container runs used a scratch copy with the git tree of the commit they are named for: `f00fdd4053565f0d199b3ba013d1388d3f5fa0fd` for the second commit, `f487873064932de4cd962d138ea6b8e687586bf1` for the first. Where a run of the first commit is quoted for a claim about the gate, that is said: the gate, the list and the workflow are byte-identical in both commits. The container is a Linux cloud container with Go 1.26.5, 4 CPUs, tests run as the unprivileged user `ci`.

### 7.1 Build, vet, self-check, in the container

On the tree of the second commit (`container-validation.log`):

| Command | Result |
|---|---|
| `go mod verify` | `all modules verified` |
| `go build ./...` | exit 0 |
| `go vet ./...` | exit 0 |
| `GOOS=darwin GOARCH=arm64 go vet ./...` | exit 0 |
| `gofmt -l docs_contract_test.go` | no output |
| `go test -count=1 -run '^TestGo1265ToolchainBaselineDocsAndBuildContract$' .` | `ok` |
| `git diff --check b39fa35 aaef28f` (in the writer clone) | exit 0, no output |
| `python3 -I -B .github/ci/go_test_gate_selftest.py` | `Ran 117 tests in 226.533s`, `OK` (`container-selftest.log`; other runs shared the 4 CPUs). On the runner: `Ran 117 tests in 118.577s`, `OK` |

The commands of the first six rows gave the same results on the tree of the first commit (`container-validation-first-commit.log`). The self-check of the first commit, 114 checks, passed there as the control of the first mutant run (`mutants5-first-run-first-part.log`) and on the runner (7.5).

**The workflow's two test steps on the real tree, in the container,** ran on the tree of the first commit (`container-gate.log`, `container-still-failing.log`). This container is not the runner: three listed tests of the root package pass here, and it has no Docker, so one more test skips itself. So the steps ran with a list that differs from the committed one in those four lines (`list-container.txt`: 12 entries, 40 `skips-itself` lines). Both exit 0: `test gate passed: 41 packages, 3 of them with skipped entries (12 entries); 40 tests skipped themselves, all of them listed` in 525 s, and `all 12 listed tests still fail on this host, each in a run of its own and in the run of its package` in 341 s.

### 7.2 The red team's checks and probes, unchanged, against the new gate

The files are byte copies of `08-red-team-evidence/` (hashes in the evidence folder). The probes and the list files read only the gate, so their runs at `76d9a91` stand for both commits. The seven checks use the helpers of the self-check, so they ran again on the second commit.

| File | At `b39fa35` (the red team's logs) | Now |
|---|---|---|
| `go_test_gate_redteam8.py`, 7 checks, placed beside the self-check in a copy of `.github/` | 7 fail | 7 pass at both commits: `Ran 7 tests in 4.559s`, `OK` at the second and `Ran 7 tests in 4.545s`, `OK` at the first (`redteam8-checks.log`, and `redteam8-checks-first-commit.log`) |
| `rt8.py`, 15 probes | 6 holes (A1, A2, A3, B1, J1, J2), 2 stated boundaries (C1, E1), 7 as expected | 0 holes, 13 as expected, the same 2 boundaries (`rt8.log`) |
| `rt8_lists.py`, malformed list files | `unexpected: 0` | `unexpected: 0`, 100 cases ok (`rt8_lists.log`) |

The two boundaries are unchanged on purpose. C1 is a failing test in a file that builds only on macOS: the new step compiles it and no step runs it. E1 is a sibling that its test starts only after the listed subtest got past some point: the gate's docstring states it.

**The planted macOS error (RT8-4).** In a copy of the committed tree I appended `var plantedForTheMacOSStep int = "REGRESSION"` to `es/admission/execution_roots_darwin_test.go`. `go vet ./...` exits 0. `GOOS=darwin GOARCH=arm64 go vet ./...` exits 1 and names the file and line (`darwin-plant.log`).

### 7.3 The audit's script for A8-F1, unchanged

`aud8_patchrelease.sh` puts a go command that reports `go1.26.6` with the real Go root in front of the gate. The committed gate exits 1 with `the observed run is written against go1.26.5, and the go command is go1.26.6`, before any test. The script's two changed gates H1 and H2 exit 0 there, as at `b39fa35`: they are the mutants (`aud8_patchrelease.log`).

`aud8_mutants.py` with H1 and H2 against the self-check of the second commit: both **killed**, each by `test_another_toolchain_is_refused_before_any_test_runs` (`aud8_mutants-H1-H2.log`; the same at the first commit). At `b39fa35` both survived all 90 checks.

### 7.4 Mutants: can the self-check tell a broken gate from a working one

`mutants5.py` changes the gate in one place per mutant and runs the self-check against it. It has the control and 195 mutants: the 139 of `07-repair.md` re-anchored to the new code, 55 new ones for this repair (X1 to X29 for the skip rule, Y1 to Y6 for packages that run nothing, Z1 to Z20 for the package runs of the third step), and S7b, added with the second commit.

**How a mutant is judged.** A mutant is killed when a check of the committed self-check fails against it. To save time the script first runs, alone, the check that killed that mutant in the run of `07-repair.md`, or the group of checks written for it (`mutants5-hints.json`). If that fails, the mutant is killed. If it passes, the whole self-check runs, so a survivor has passed every check.

**Result on the bytes of the second commit: 190 of the 195 mutants are killed, and the five that survive are the five expected to** (`mutants6-first-part.log`, `mutants6-second-part.log`; the scratch copy had the tree of the commit, `mutants6-tree.txt`). The control passes all 117 checks (`Ran 117 tests in 207.670s`, `OK`).

| Group | Count | What it changes | Result |
|---|---|---|---|
| **X (new)** | 29 | **The skip rule:** the comparison in each direction and what it names, the packages it covers, subtests, how the lines are read and checked against the entries and the module, the observed run, the log group and the closing line | all killed |
| **Y (new)** | 6 | **Packages that run nothing:** the listing of every package, the verdict rule, the `PASS` line | all killed |
| **Z (new)** | 20 | **The package runs of the third step:** whether entries are judged there, the rounds after a test binary stopped, parallel tests, the ambiguity rule | all killed, Z12 by the time limit (below) |
| S7, S7b | 2 | Only status 1 of `go test` counts as a failed run, in each of the two places | both killed |
| R, P, S, C, O, G, J, F, W, V, T (from `07-repair.md`, without S7 and F20x) | 133 | Reading the list, the pattern, the gating runs, the checks, the log, the third step, the observed run | all killed |
| E, F20x | 5 | Expected to survive (below) | all survive |

- **Z12 is killed by the time limit, not by a failed assertion.** It makes the third step run a package again although no listed test stopped the test binary, so the step never ends. The checks written for it did not end within 600 seconds, and the script stopped them. On the runner the job's `timeout-minutes: 60` ends such a run as failed. Every other kill, 189 of them, is a failed assertion of a check: no mutant was killed by an error in the self-check itself.
- **The five survivors are the ones of `07-repair.md`.** F20x gives a name a new value inside a loop, which changes nothing. E1 and E2 differ from the gate only for an event stream that `go test -json` does not produce. E3 and E4 remove guards that no output of a real `go` command and no accepted list can reach. Each of the five ran all 117 checks.

**What the earlier runs showed, and why there is a second commit.** I pushed the first commit before its mutant run had ended. That run then showed gaps in the self-check, and closing them took the second commit:

1. **Against the self-check of the first commit** (`mutants5-first-run-first-part.log`, `mutants5-first-run-second-part-stopped.log`): 166 of the then 194 mutants were judged before I stopped the run. 164 were killed, F20x survived as expected, and **S7 survived**. The 28 not judged were Y3 to Y6, the Z group and the E group.
2. **Against a working state between the two commits** (self-check with 115 checks): the 28 mutants S7, S7b, Y1 to Y6 and Z1 to Z20. 25 were killed and **Y5, Y6 and Z16 survived**. Of this run only the summary is left (`mutants-second-run-first-phase-summary.txt`). I deleted its log by mistake when I started the next run.
3. **Against the bytes of the second commit:** first Y5, Y6 and Z16 alone (`mutants6-three.log`, all killed), then the whole set, which is the result above.

How the run was done. Every mutant asserts that the text it replaces is present exactly once, so none is a silent no-op by a missed anchor. Each mutant runs in a copy of `.github/`, two at a time, with `unittest -f`. For a mutant with a hint the log names the check that failed among the hinted ones, which need not be the first that a whole run would reach.

Limits: the mutants are mine, written against my own gate. A fresh auditor should add their own. The audit's two mutants for A8-F1 are in 7.3.

### 7.5 On the GitHub runner (authoritative)

Two runs, each the first and only run of its commit, both `pull_request` events on `ubuntu-24.04` with `go version go1.26.5 linux/amd64`, both with conclusion **success**. The job logs are `runner-run-45046634281-job-137282573571.log` and `runner-run-45039279766-job-137259866158.log`.

| Step | [45046634281](https://github.com/evo-agi/Execution-Substrate/actions/runs/45046634281) at `aaef28f` | [45039279766](https://github.com/evo-agi/Execution-Substrate/actions/runs/45039279766) at `76d9a91` | At `b39fa35` |
|---|---|---|---|
| Whole job | 12 m 13 s | 12 m 15 s | 7 m 57 s |
| Vet for macOS (new) | 29 s | 25 s | no such step |
| Check the test gate | 1 m 59 s, `Ran 117 tests in 118.577s`, `OK` | 1 m 41 s, `Ran 114 tests in 100.415s`, `OK` | 55 s, 90 checks |
| Test | 5 m 35 s | 5 m 48 s | 6 m 1 s |
| Listed tests still fail | 3 m 18 s | 3 m 32 s | 13 s |

Both runs end the step "Test" with `test gate passed: 41 packages, 3 of them with skipped entries (15 entries); 39 tests skipped themselves, all of them listed`, and the third step with `all 15 listed tests still fail on this host, each in a run of its own and in the run of its package`. The 39 lines `skips itself: …` of the two logs are identical (`cmp` of `runner-skips.txt` and `runner-skips-head.txt`). In the second run the package runs of the third step took 1 m 40 s (root), 1 m 3 s (`es/app`) and 22 s (`reliablesubmit`).

**The skips on the runner.** The step "Test" printed two groups: `execution-substrate/es/app: 37 tests skipped themselves` and `execution-substrate/es/admission/internal/reliablesubmit: 2 tests skipped themselves`. `runner-skips.txt` has the 39 lines as printed in the first run, each with the test's name and what it wrote. They are the 39 lines of the list, no more and no fewer: the step fails on either difference. The reasons in the list's comments match what the tests wrote (table in section 1).

**The Docker-only test runs on the runner.** `TestWorkloadCanCreateAndUseLocalRuntimeIdentityEndpointFromTmpfsWorkspace` has no line and the step passed. So it reported a verdict that is not `skip`, and its package passed. That is a consequence of the rules of the step, not a line I can quote: the gate prints only failures and skips.

**The observed run** of `es/app` ended with `the observed run passed; go test skipped exactly the listed tests of this package (2), each once`.

**The third step.** One run of each of the three listed packages with nothing skipped (in the first run: root 1 m 53 s for its 11 entries, `es/app` 1 m 5 s for 2, `reliablesubmit` 21 s for 2), then 15 runs of single entries, 15 lines `still fails: …`. No listed test stopped a test binary, so no package ran a second time. Neither log holds an `::error` line.

### 7.6 On David's Mac

Both sessions worked in a temporary folder of their own under `/Users/ds/Repositories/Playground`, changed nothing in an existing folder, pushed nothing and removed their folder at the end. The Mac is macOS 26.6.2 on arm64 with Python 3.13.4.

**First run, 16:00 to 16:12, at `76d9a91` and at PR #16's head `0a069ec`** (`mac-instructions.txt`, `mac-run-report.txt`). David allowed it on the card at 16:00 and wrote "Approved" in the project chat at 16:02, with the wish that the folder `Playground` itself stays. The first `go` on `PATH` there is go1.26.1. Inside a clone of this repository the `go` command switches to go1.26.5, which lies in the module cache (`/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64`). Nothing was downloaded.

| | Command | Result on the Mac |
|---|---|---|
| a | `go test -count=1 -v -run 'TestReplayExistingStateModeNotRepaired\|TestRetainedResultAuthReaderNeedsVerifierEvenForExistingPair' ./es/admission/...` | exit 0, both `PASS` |
| b | `go test -count=1 -v -run '^TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSpireBundleReadClassifiesTraversalAmbiguityWithSudoVisibleInspection$' .` | exit 0, `PASS` |
| c | `go test -count=1 -v -run '^TestGo1265ToolchainBaselineDocsAndBuildContract$' .` | exit 0, `PASS` |
| d | `python3 -I -B .github/ci/go_test_gate_selftest.py` | **exit 1:** `Ran 114 tests in 175.360s`, `FAILED (failures=46)` |
| d2 | the same, with the cached go1.26.5 first on `PATH` (the session added this run itself) | **exit 1:** `Ran 114 tests in 186.449s`, `FAILED (failures=30)` |
| e | PR #16: `go test -count=20 -run '^TestSQLiteClaimStoreTwoHandlesBusyTimeoutAndHelperProcessContention$' ./es/admission/internal/reliablesubmit` | exit 0, `ok` |
| f | PR #16: `go test -count=1 -v -run 'TestSQLiteClaimStore' ./es/admission/internal/reliablesubmit` | exit 0, `PASS` |

So a, b and c show what this pull request needed from a Mac: the three Go test files it changed pass on macOS. e and f are the Mac run that PR #16 was waiting for. This report does not judge PR #16 beyond that.

d and d2 failed for three causes, which the session named. The second I reproduced in the container: the new check of 4.7 makes it happen with the Linux Go. The first and the third I confirmed from the output the session sent and from the code:

1. **d, 45 of the 46 failures:** the self-check builds its throwaway modules outside the repository. They declare `go 1.21`, so the `go` command does not switch toolchains there, the gate sees go1.26.1 and refuses, as it is written to. The self-check needs go1.26.5 first on `PATH`. That was a known rule of the self-check, and the request should have said so. The header of the self-check says it now.
2. **d2, 29 of the 30 failures:** with go1.26.5 first on `PATH` the `go` command refuses the gate's `-overlay`, because that Go root lies beneath `GOMODCACHE` (M-2, section 4.7).
3. **d and d2, one failure each:** `test_names_that_only_resemble_a_line_are_not_covered` in the case `TestSKIPS` (M-1, section 4.7). The gate had done the right thing. The self-check's own bookkeeping was wrong on a file system that ignores case.

`src/testing/match.go` of that Go had the held SHA-256 `f284…bebe` before and after. `git status --porcelain` in the clone was empty. The session reported that its temporary folder is gone and that no entry of its own is left in `/Users/ds/Repositories/Playground`. It kept its seven complete logs in its own scratch folder on the Mac, which a restart clears.

One thing I learned from that report and did not know: the clone on the Mac has `git@github.com:SeritArbores/Execution-Substrate.git` as its origin. The session compared `git ls-remote` of that URL and of the `evo-agi` URL and found the same four refs. Inference (the session's, not verified by me): GitHub redirects the old URL to the moved repository.

**Second run, 17:21 to 17:27, at `aaef28f`** (`mac-instructions-second-run.txt`, `mac-run-report-second-run.txt`). David approved it at 17:21. The session copied the cached Go 1.26.5 into its temporary folder with `cp -R`, downloaded nothing, put the copy first on `PATH` and set `GOTOOLCHAIN=local`. `go env GOVERSION GOROOT GOMODCACHE` gave `go1.26.5`, a Go root inside the temporary folder and `/Users/ds/go/pkg/mod`, so this Go lay outside the module cache. `src/testing/match.go` of the copy had the held SHA-256 before and after d.

| | Command | Result on the Mac |
|---|---|---|
| a | as in the first run | exit 0, both `PASS` |
| b | as in the first run | exit 0, `PASS` |
| c | as in the first run | exit 0, `PASS` |
| d | `python3 -I -B .github/ci/go_test_gate_selftest.py` | **exit 0:** `Ran 117 tests in 217.668s`, `OK`. All 117 lines end in `... ok` |

So at the head the self-check passes on macOS, on a file system that ignores case. That confirms the fix of M-1 on the host where it failed. It also shows the observed run working with the macOS Go: the group `GateShowsEveryTestItSkipped` builds test binaries with `-overlay` there, which the first run never got to do.

`git status --porcelain` in the clone was empty. The temporary folder is removed, with the copy of Go in it. **The folder `Playground` itself is still there**, as David asked: `drwxr-xr-x  38 ds  staff  1216 Nov 22 12:26 /Users/ds/Repositories/Playground`.

What the Mac runs do not show: the workflow's two test steps on the real tree did not run there, because the list describes the runner. The session did not look for folders that the self-check might have left in the system's temporary folder. The self-check removes the folders it makes. The session's raw output files stay in its own scratch folder on the Mac until a restart.

### 7.7 Failed or skipped validation

- **One runner run per commit.** The two runs are two samples of the timings (12 m 15 s and 12 m 13 s). The verdicts do not depend on timing.
- **The runner's own skip set on a `push` to `trunk_dev`** is not shown, because nothing was merged. It is the same workflow file and the same image label.
- **The whole gate in this container needs another list than the runner** (7.1). That is expected: the list describes the runner. It also shows the rule at work on a second host.
- **The whole gate in the container ran on the first commit only** (7.1). The second commit changes no byte of the gate, the list or any Go test except `docs_contract_test.go`, which the runner ran.
- **Hygiene of my earlier container runs.** The container runs before the first commit (the self-check runs and a first whole-gate run) were started with the session's environment visible to the test processes. The tests were this repository's own and my throwaway modules. No output of those runs is in the evidence. Every container run in the evidence folder was started with an emptied environment (`env -i`).

## 8. Stated bounds, and what is with David

**Not run in CI, and now visible.** The 37 `es/app` integration tests need Nomad and Vault, which the runner image does not have. They are the tests of the submit flow, which the next unit of work touches. Giving the runner Nomad and Vault is a larger piece of work and the better end state. The list makes the gap visible and forces the lines out when it closes. Whether to close it, and when, is a decision for David with the coordinator.

**Whether the check is required (O-1).** A red or missing run blocks a merge only if "build, vet and test" is a required status check on `trunk_dev`. That is a repository setting. The coordinator raises it with David.

**O-3, the set of workflow files, is not held.** A second file under `.github/workflows/` is noticed by nothing. It cannot make this workflow's steps pass. It starts to matter with O-1: GitHub matches a required check by its name, and I have not tested what it does with two jobs of the same name. One check in the self-check ("the directory holds only `go.yml`") would hold it. I did not add it because it was not among the findings to fix and it adds a rule for every later workflow. I recommend deciding it together with O-1.

**The gate needs a Go installation outside the module cache** (4.7). With a toolchain that the `go` command downloaded itself, which is how a developer's machine usually gets the version that `go.mod` asks for, the step "Test" fails for a package with an entry for a subtest and shows the error of the `go` command. It fails closed, the doc says so, and a check holds it. The self-check also needs go1.26.5 as the first `go` on `PATH`. So neither runs on David's Mac as it is set up today without a Go 1.26.5 of its own. The second Mac run shows that a copy of the downloaded toolchain in another folder is enough (7.6). CI is not affected.

**The reasons are held by review, not by machine** (4.1). The machine holds that each listed test skips and that no other does.

**One bound of the twice-judged entries (RT8-3).** An entry is forced out when it passes alone or passes in the full run of its package. The gate skips all entries of a package together. So the exact question is whether an entry would fail in a run of its package without the other entries. The two runs answer it unless two things hold at once: the entry fails alone only for want of what an unlisted test leaves behind, and it fails in the full run only because of what another listed test leaves behind. The exact check is one run of the package per entry, 15 package runs, about 20 minutes more on the runner for the root package alone. I judged that cost out of proportion to a double coincidence with no instance today. If the coordinator sees it differently, it is one loop in `still_failing`.

**When the run does not show which listed test stopped the binary,** the step fails and names each (4.3). It does not guess.

**A skip that cannot be listed.** A subtest whose printed name has a character outside letters, digits, `_` and `-`, or that `go test` numbers with `#01`, cannot be named in the list. If such a subtest skips itself, the step fails and no line can fix it. The test has to change. None of the 39 is a subtest.

**Packages without entries now run in verbose mode,** because `go test -json` is one. No test of the tree reads `testing.Verbose()`.

**No defence against a test that forges the output of `go test`.** The gate takes the event stream as the testing package wrote it. This is unchanged and is in the gate's docstring.

**macOS-only tests are compiled on the runner, not run** (probe C1). A run on David's Mac stays the only macOS execution.

## 9. Authority, security and protocol widening; hygiene; cross-repo impact

- **Authority and security:** no widening. The workflow keeps `permissions: contents: read`, the pinned actions and `persist-credentials: false`. The new step runs `go vet` with two environment variables. No secret is used.
- **Protocol:** none touched. No service contract, lifecycle rule or reopened seam is involved.
- **Artifact hygiene:** no generated file is committed. The gate and the self-check work in temporary folders that they remove. `git status --porcelain` was empty after the runs in the scratch copy.
- **Cross-repo impact:** none.
- **Remote state touched by this repair:** two fast-forward pushes to `claude/project-thread-sqldt7-ci` (15:36 and 16:56) and the updates of the description of PR #14. No force-push, no branch or tag deleted, nothing merged. PR #16 and its branch were not touched: its head was read and tested on the Mac only. On David's Mac: two sessions (7.6), each confined to a temporary folder of its own under `/Users/ds/Repositories/Playground`. The first ran from 16:00 to 16:12 and the second from 17:21 to 17:27, each with David's approval. I ended both sessions afterwards.
- **Sensitive material:** none read or written. This report and the evidence folder were scanned for keys, tokens, e-mail addresses and phone numbers with the project's scan tool before delivery. Result: 23 matches of the tool's pattern for e-mail addresses and nothing else. I read each. None is an address: 18 are the Go module path of the downloaded toolchain, which has an at sign before its version, and 5 are the user part of an SSH clone URL of GitHub. No key, no token, no phone number.

## 10. Rules this creates for PR #12, PR #13 and every later change

1. **A test that skips itself on the runner needs a `skips-itself` line with its reason, in the change that adds the skip.** Without the line the step "Test" fails and prints the line to add.
2. **A change that makes a listed test run on the runner has to delete its line** in the same change. This holds for both kinds of lines.
3. **Every edit of `.github/workflows/go.yml` has to set `WORKFLOW_SHA256`** in the self-check (unchanged rule; the value changed in this commit).
4. **A Go version change has to set `OBSERVED_GO_VERSION` and `MATCH_GO_SHA256`** in `go_test_gate.py` and `docs_contract_test.go` (unchanged rule; now held exactly by the self-check).
5. **PR #12:** when it picks up `trunk_dev`, it adds the entry for `reliablesubmit TestOperationalHandoffSchema4BinaryRefusesSchema5`. That test must then fail on the runner alone and in the run of its package. If PR #12 or PR #13 add tests that skip on the runner, rule 1 applies to them.
6. **A new test file that builds only on macOS** is now type-checked on the runner. It still runs only on a Mac.

## 11. Assumptions, unresolved seams, uninspected areas

- **Assumption:** the runner image keeps Docker and keeps lacking `nomad` and `vault`. If that changes, the step "Test" fails and names the lines. That is the intended trigger, not a defect.
- **Assumption:** the four facts about the event stream (section 3) hold for Go 1.26.5. The gate stops on any other version.
- **Unknown:** how GitHub treats two jobs of the same name under a required check (section 8, O-3). Not tested.
- **Uninspected:** the skip sites of the tree that did not fire on the runner (for example checks for root, for a FIFO, for a loopback listener). They did not skip there, or the step would have failed. I did not read each of them.
- **Not shown:** that each of the 39 tests would pass with Nomad and Vault present. They do not run in CI.

## 12. For the next audit

- **Scope:** two commits, 6 files, the repair-only manifest in section 2. The gate and the self-check carry almost all of it. The second commit is small and touches no byte of the gate.
- **The claims to try to break:** (a) no test or subtest can end with `skip` in any package without a line; (b) a line cannot stay when its test passes, fails or is gone; (c) no package can pass while a listed top-level test has no verdict; (d) no entry can stay that passes alone or in the full run of its package; (e) the third step cannot be made to name the wrong test, or none, when a test binary stops.
- **Ready to run again:** the red team's three files and the audit's two scripts run unchanged (7.2, 7.3). `mutants5.py` is in the evidence folder with its logs. All of them need go1.26.5 first on `PATH`, installed outside the module cache.
- **Where I would look first:** `check_gated_run`, `in_the_run_of_its_package` and `judged` in the gate; the reading of `pause` and `cont`; the bound in section 8 that I chose not to close.
- **The Mac runs** are not part of the bytes. Both runs are in 7.6: the changed Go tests pass on macOS, and the self-check of the head passes there with a Go 1.26.5 outside the module cache.

## 13. Confidence

- **Provenance: high.** Manifests taken twice, staged set and bytes checked by script for each commit, reproduced in a fresh clone.
- **Validation: high for the runner, the self-check and the adopted checks.** The runner ran each commit once, green. The mutant run on the bytes of the second commit killed 190 of 195, and the five survivors are the expected ones. The first commit went out before its mutant run had ended, which is why there is a second commit (7.4).
- **Implementation: medium to high.** The skip rule is simple and is held from both sides. The rounds of the third step are the newest and most intricate part: they rest on four measured facts about the event stream, and they fail closed where the stream does not decide.

## 14. Provenance detail

- Recipe ID `governed-execution.audit-patch-manifest.v2`; source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked before every run of the recipe.
- Before the manifests of each commit: `git fetch`, `trunk_dev` still at the base, the pushed tip still at the commit below, HEAD there, nothing staged.
- Staged-set check for each commit: the staged paths equalled the paths of that commit's manifest (6, then 3). Clean status after each commit. `git diff --check` over each: exit 0.
- Pushes: fast-forward `b39fa35..76d9a91`, then `76d9a91..aaef28f`, no force.

**Repair-only manifest, complete** (SHA-256 `1ccacc66030fc16d1f21b3fb9ca0b4586967f515195b642050e120515e021a0f`; also `08-repair-evidence/manifest-repair-only.json`):

```json
{"branch":"claude/project-thread-sqldt7-ci","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/system_overview/go_toolchain_baseline.md","sha256":"8dafae5db5d9f4bfb700c10c780757f14bc5549f4792ac973fd902efe14dca81","size":7913},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".github/ci/environment-only-tests.txt","sha256":"59c920474a6e5e46631436747c22949e12f2fcd004bddfcb3d604313c1be12e8","size":11353},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".github/ci/go_test_gate.py","sha256":"e2715daf181f297454bcfd25e54b64d7d533339f900f1aa1e0c0685c583b6c3b","size":43665},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".github/ci/go_test_gate_selftest.py","sha256":"8031e92747cc220de08359908ee3b320bf70d765a7ec6b7cb2e48493af8709a1","size":145915},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".github/workflows/go.yml","sha256":"0383a2f066da5490db36abb91f4896c076a7d5cc45410cec11f40b85201db8bf","size":4529},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"462c01edc5f31bb40534413a9e714710f9caeff1f14d1fb9551ca14e608f8e65","size":805843}],"head":"b39fa35d444a4bd87a3901287bb6a346577c81b9","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"aff0544899a09f9e255955cd6dfed0f1ac2fe8623cafa87caecfde9dc6decd2a","upstream":"origin/trunk_dev"}
```

**Cumulative manifest, complete** (SHA-256 `774fe3a67db1a0cba962bf9fefd80a12e5ee55f97c42654eb030e656d49020ee`; also `manifest-cumulative.json`):

```json
{"branch":"claude/project-thread-sqldt7-ci","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/system_overview/go_toolchain_baseline.md","sha256":"8dafae5db5d9f4bfb700c10c780757f14bc5549f4792ac973fd902efe14dca81","size":7913},{"file_type":"regular","kind":"untracked","mode":"0644","path":".github/ci/environment-only-tests.txt","sha256":"59c920474a6e5e46631436747c22949e12f2fcd004bddfcb3d604313c1be12e8","size":11353},{"file_type":"regular","kind":"untracked","mode":"0644","path":".github/ci/go_test_gate.py","sha256":"e2715daf181f297454bcfd25e54b64d7d533339f900f1aa1e0c0685c583b6c3b","size":43665},{"file_type":"regular","kind":"untracked","mode":"0644","path":".github/ci/go_test_gate_selftest.py","sha256":"8031e92747cc220de08359908ee3b320bf70d765a7ec6b7cb2e48493af8709a1","size":145915},{"file_type":"regular","kind":"untracked","mode":"0644","path":".github/workflows/go.yml","sha256":"0383a2f066da5490db36abb91f4896c076a7d5cc45410cec11f40b85201db8bf","size":4529},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"462c01edc5f31bb40534413a9e714710f9caeff1f14d1fb9551ca14e608f8e65","size":805843},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_file_test.go","sha256":"0cec866cf2e659c58a90eeb46f3edf75d9743db21c0c87aaad65d72462c3a2d9","size":70129},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/result_auth_test.go","sha256":"adab4be23f1d1f74bbc6bccd3e49235d8e95e0b5c6e2c4121930578c0e72f87c","size":18293},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"remote_alpha_operator_test.go","sha256":"efa79af1ac61541a9ba92a20ea3ef1b7cff2bcfa7eb587cc723efe1eee15d59a","size":279122}],"head":"ae326b0ddc30ec6b35883ee32945c622405b68b6","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"39ea9db3ac152ce8ded7bd1dac0af84bf04758e0702515ed3177304006242c37","upstream":"origin/trunk_dev"}
```

**Manifest of the second commit alone, complete** (SHA-256 `8c620ad3365c758e1fa46f58b12f20a76f237b6f0343eabe52869c1fe37045fc`; also `manifest-second-commit.json`):

```json
{"branch":"claude/project-thread-sqldt7-ci","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/system_overview/go_toolchain_baseline.md","sha256":"8dafae5db5d9f4bfb700c10c780757f14bc5549f4792ac973fd902efe14dca81","size":7913},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".github/ci/go_test_gate_selftest.py","sha256":"8031e92747cc220de08359908ee3b320bf70d765a7ec6b7cb2e48493af8709a1","size":145915},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"462c01edc5f31bb40534413a9e714710f9caeff1f14d1fb9551ca14e608f8e65","size":805843}],"head":"76d9a91c012b20aaa3a00cec53e34665aca6a18b","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"b0d493befc6d5c6bb2e14b94b1815615967799b6b30bbd0c5a39bc61680b2a9f","upstream":"origin/trunk_dev"}
```

## 15. Evidence folder and report delivery

Evidence: `/mnt/project-files/reports/Execution-Substrate/ci-go-workflow/08-repair-evidence/`, with `README.md` (what each file is) and `SHA256SUMS.txt`.

Report: `/mnt/project-files/reports/Execution-Substrate/ci-go-workflow/08-repair.md`. Its SHA-256 is in the reply that delivers it, because a file cannot hold its own hash.
