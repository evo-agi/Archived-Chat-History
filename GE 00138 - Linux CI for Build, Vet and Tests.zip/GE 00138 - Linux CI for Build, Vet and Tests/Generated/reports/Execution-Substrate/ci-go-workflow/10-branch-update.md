# BRANCH UPDATE RECORD: Execution-Substrate PR #14 (Linux CI) merged with `trunk_dev` at `3a5f257`

**Outcome: the branch of PR #14 now contains today's `trunk_dev`. The new head is `8e4b43f6485055385e64f3f608fece002267dd73`. The merge had no conflict, the patch of the PR is byte for byte the audited one, and the run on GitHub for the new head is green.**

This record is the input for the merge gate (provenance document, section 5.4 step 2). It adds to `09-repair.md` and to the audit `09-audit-addendum.md` (ACCEPT for `8eefe6d`). It reports no change of content: the writer changed no file of the PR.

Written 2026-11-22, by the writer thread of PR #14. No subagents were used.

## 1. Identity

| Field | Value |
|---|---|
| Objective | Bring PR #14 onto the current `trunk_dev` after the audit, without changing the audited patch |
| Repository | `evo-agi/Execution-Substrate` |
| Pull request | #14, draft, `mergeable_state` clean |
| Base | `trunk_dev` at `3a5f25776274b3e9ada3e2d489c9bfe0e8bf8a28` (with PR #17, `b8d6bc3`, and PR #18, `3a5f257`) |
| Topic branch | `claude/project-thread-sqldt7-ci` |
| Audited commit | `8eefe6d309c64ec33295dce089e57927129f52e1`, tree `c3e784d20d3311650bfa91358d4113430dff4ca8`, base `ae326b0ddc30ec6b35883ee32945c622405b68b6` |
| New head | `8e4b43f6485055385e64f3f608fece002267dd73`, a merge commit with the parents `8eefe6d` and `3a5f257` |
| New tree | `88e6d89349b681dc5d469644fe1002850ec3ab75` |
| Manifest at the new base | SHA-256 `8a2d207400fdc1e58b5e6a234490ddd3517eb84e26e8bbab38c25effcb1b0353`, 2,035 bytes, 9 files |
| Final working-tree status | clean; local branch equals `origin/claude/project-thread-sqldt7-ci` |

## 2. What was done

1. `git merge --no-ff origin/trunk_dev` on the branch, at `8eefe6d`. No rebase and no force-push, so the nine audited commits keep their hashes.
2. The merge had no conflict. It brought in 11 files from `trunk_dev` (PR #17 and PR #18). None of them is one of the nine files of this PR.
3. The merge commit was pushed as a fast-forward at 22:06 UTC.
4. The pull request description was updated: new head, base, run and identity.

## 3. The patch is unchanged

All of this is in `10-branch-update-evidence/patch-unchanged.txt` and `manifest-compare.txt`.

- `git diff ae326b0 8eefe6d` and `git diff 3a5f257 8e4b43f` are the same bytes: SHA-256 `9d818c2193f4e10bb951cd50b68f3b754b5999a8ea05f30531d20c57349a6e5e` for both.
- `git range-diff ae326b0..8eefe6d 3a5f257..8e4b43f` shows all nine commits as equal (`=`).
- The new manifest has the same nine file records and the same `textual_diff_sha256` as the audited cumulative manifest `c16bda47d4a1cd7dee849bb6e0cc607bfac74be085ef434ba854d36f1f34b839`. Only the field `head` differs: `3a5f257` in place of `ae326b0`.

## 4. Provenance

- Recipe `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified before each run.
- Taken in a fresh clone from GitHub: pushed tip checked to be `8e4b43f`, `git reset --mixed 3a5f257`, upstream pinned to `origin/trunk_dev`, v2 run twice, both outputs identical (`fresh-clone.sh.txt`, `fresh-clone.log`).
- Textual diff SHA-256 `35efc396dbeadf52c8b90040c9a43d5e0a36442881a291aabf1c3c89d978c03e`.
- Canonical manifest SHA-256 `8a2d207400fdc1e58b5e6a234490ddd3517eb84e26e8bbab38c25effcb1b0353`, 9 files. Complete canonical manifest (also in the evidence folder as `manifest-head-3a5f257-tip-8e4b43f.json`):

```json
{"branch":"claude/project-thread-sqldt7-ci","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/system_overview/go_toolchain_baseline.md","sha256":"8b0d9b698f4e1c18904491a7f91c79b73fe626902bdb471cf2c76c3353648078","size":8431},{"file_type":"regular","kind":"untracked","mode":"0644","path":".github/ci/environment-only-tests.txt","sha256":"ba629bd9328e84fb811593ec3e28657511bd862b033f6147d7bbe8b89da53ece","size":11652},{"file_type":"regular","kind":"untracked","mode":"0644","path":".github/ci/go_test_gate.py","sha256":"a2a0399bf0dad043d5636d5cab23f361d02702a450f115f4852ed326b6fd08fa","size":45877},{"file_type":"regular","kind":"untracked","mode":"0644","path":".github/ci/go_test_gate_selftest.py","sha256":"24d7f2f1ed6d072da345e0d42d829c8abae030437a7ededc2a85626db51e8633","size":159090},{"file_type":"regular","kind":"untracked","mode":"0644","path":".github/workflows/go.yml","sha256":"d8578b0e6b5901d06ae82f0ec4acf81390d48ff8831a574a76d8d57d1c58bd18","size":4700},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"6310006087c3d0839ee37ce160973ff283a708a233295509290cc02487de14f3","size":806381},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_file_test.go","sha256":"0cec866cf2e659c58a90eeb46f3edf75d9743db21c0c87aaad65d72462c3a2d9","size":70129},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/result_auth_test.go","sha256":"adab4be23f1d1f74bbc6bccd3e49235d8e95e0b5c6e2c4121930578c0e72f87c","size":18293},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"remote_alpha_operator_test.go","sha256":"efa79af1ac61541a9ba92a20ea3ef1b7cff2bcfa7eb587cc723efe1eee15d59a","size":279122}],"head":"3a5f25776274b3e9ada3e2d489c9bfe0e8bf8a28","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"35efc396dbeadf52c8b90040c9a43d5e0a36442881a291aabf1c3c89d978c03e","upstream":"origin/trunk_dev"}
```

To reproduce it, follow section 5.3 of the provenance document with `TOPIC=claude/project-thread-sqldt7-ci`, `TIP=8e4b43f6485055385e64f3f608fece002267dd73` and `BASE=3a5f25776274b3e9ada3e2d489c9bfe0e8bf8a28`.

## 5. Validation

### 5.1 On GitHub

Run [45075800893](https://github.com/evo-agi/Execution-Substrate/actions/runs/45075800893), job 137372612918, `ubuntu-24.04`, started 22:06:20 UTC, green in 12 m 52 s. The runner checked out the merge of `8e4b43f` into `3a5f257`, which has the tree of `8e4b43f`. From the job log (`runner-run-45075800893-job-137372612918.log`):

| Step | Result |
|---|---|
| Build, Vet, Vet for macOS | success |
| Check the test gate | `Ran 121 tests in 111.058s`, `OK` |
| Test | `test gate passed: 41 packages, 3 of them with skipped entries (15 entries); 39 tests skipped themselves, all of them listed` |
| Listed tests still fail | `all 15 listed tests still fail on this host, each in a run of its own and in the run of its package`; 18 runs, each ending with the testing package's `FAIL` line |

The 15 lines `still fails: …` are the same as in run 45064532285 at `8eefe6d`. The log has no error or warning annotation.

PR #18 adds one test, `TestESLauncherContainerUser` in `es/app`, with nine subtests. It has no line in the list. The gate fails when a test fails, when a test that `go test -list` names reports no verdict, and when a test skips itself without a line. **Inference:** the test ran and passed on the runner. The log does not print the names of passing tests.

### 5.2 In the cloud container

User `ci`, emptied environment, Go 1.26.5, a scratch copy with the tree `88e6d893…` (`container-validate.log`, `container-gate.status` and the three logs beside it).

| Command | Result |
|---|---|
| `go mod verify`, `go build ./...`, `go vet ./...`, `GOOS=darwin GOARCH=arm64 go vet ./...` | exit 0 each |
| `go test -count=1 -run '^TestGo1265ToolchainBaselineDocsAndBuildContract$' .` | ok |
| `go test -count=1 -run '^TestESLauncherContainerUser$' -v ./es/app` | PASS, nine subtests ran |
| `python3 -I -B .github/ci/go_test_gate_selftest.py` | `Ran 121 tests in 199.053s`, `OK` |
| `go_test_gate.py gate` with the list for this container (12 entries, 40 skip lines) | exit 0 in 448 s |
| `go_test_gate.py still-failing` with the same list | exit 0 in 301 s, `all 12 listed tests still fail on this host` |

The container needs its own list because three of the 15 runner entries pass there and one more test skips itself. That list is not part of the PR.

## 6. Failed or skipped validation

- Nothing failed.
- Not run again: the mutants of the gate and the self-check, and the reviewers' probe files. The nine files of the PR are unchanged, so those results in `09-repair.md` and `09-audit-addendum.md` still describe these bytes.
- Not run: anything on macOS at this head.
- The gate run in the container passed this time. One test of the root package can fail there on a two-second bound of its own fixture (`09-repair.md`, section 7.8). Its fix is a separate test-only change and is not part of this PR.

## 7. For the merge gate

- The head of the PR has to be `8e4b43f6485055385e64f3f608fece002267dd73` at the merge.
- If `trunk_dev` moves again before the merge, this update has to be repeated: merge, run, manifest.
- After the merge, `trunk_dev` should hold the bytes of the nine manifest paths above.
- Draft PR #16 (test-only, ACCEPT) was planned to merge with this PR. It is untouched by this update.

## 8. Other envelope fields

- **Files touched:** none by the writer. The merge commit carries 11 files from `trunk_dev`.
- **Dependencies changed:** none.
- **Artifact hygiene:** no file was created in the repository. The scratch copy in the container and the fresh clone are outside it.
- **Authority, security or protocol widening:** none.
- **Cross-repo impact:** none.
- **Sensitive material:** none read or written. This record and its evidence files were scanned with the project's leak scanner before delivery: 0 findings.

## 9. Confidence

- **Provenance: 0.99.** The manifest was reproduced twice in a fresh clone and its file records equal the audited ones.
- **Validation: 0.95.** One green run on the runner and one in the container, both on the tree of the new head.
- **Implementation: unchanged** from `09-audit-addendum.md`, because no byte of the patch changed.

## 10. Delivery and effect status

- This file: `/mnt/project-files/reports/Execution-Substrate/ci-go-workflow/10-branch-update.md`. Its SHA-256 is in the reply that delivers it.
- Evidence: `/mnt/project-files/reports/Execution-Substrate/ci-go-workflow/10-branch-update-evidence/`, with a `README.md` and a `SHA256SUMS.txt`.
- Effect status: `TOPIC_BRANCH_PUSHED` | `DRAFT_PR_UPDATED` https://github.com/evo-agi/Execution-Substrate/pull/14 | `MERGE_NOT_PERFORMED` | audit ACCEPT at `8eefe6d`; the merge commit `8e4b43f` awaits the provenance re-check of the merge gate.
