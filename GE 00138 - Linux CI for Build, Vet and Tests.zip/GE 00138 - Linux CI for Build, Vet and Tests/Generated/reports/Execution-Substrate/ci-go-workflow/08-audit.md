# INDEPENDENT AUDIT REPORT: Execution-Substrate PR #14 (Linux CI) at `b39fa35`

**Final verdict: ACCEPT**
**Effect status:** REPAIR_NOT_PERFORMED · COMMIT_NOT_PERFORMED · PUSH_NOT_PERFORMED · PR_NOT_MODIFIED · NO_COMMENT_POSTED · MERGE_NOT_PERFORMED · read-only on the target throughout

A fresh thread did this correctness audit. It wrote none of the patch and none of its repairs, and it used no subagents. The red-team pass of the same bytes is the job of a separate thread and is not in this report. The Mac run and PR #16 are not in it either.

All times are UTC on 2026-11-22.

## 1. Verdict in short

**ACCEPT.** PR #14 at `b39fa35` does what the last audit required, and the new machine check is sound. I found no critical, high or medium defect. There is one low finding, a missing case in the self-check.

- **The six acceptance checks of the last audit:** five are met (section 6). The sixth is the one Mac run. It changes no bytes, it waits for David, and it stays a condition for the merge.
- **The new check, the four questions of the brief (section 5):**
  - **Sound:** yes. `go test` decides in one place whether `-skip` drops a test, and the check reads the decision there. Against ground truth that does not use the check's own recorder, the gate was right in 200 of 200 random modules.
  - **Tracks the Go version pinned in CI:** yes, by refusing every other version before any test runs.
  - **Silent drift:** I found no way into a green run.
  - **`WORKFLOW_SHA256`:** right. It is the SHA-256 of `go.yml` as committed.
- **Finding A8-F1 (low):** the self-check does not hold that the gate compares the Go version exactly. Two of my mutants that accept any `go1.26` release pass all 90 checks. The gate itself compares exactly today. One more case in an existing check closes it (section 7).
- **My reruns on the exact bytes agree with the writer's report:** the whole gate, the self-check (90 of 90), the earlier probe files, the planted fault, the 21 workflow edits and the writer's 139 mutants (134 killed, the same 5 survive). Of my own 37 mutants 34 are killed.
- **The runner result is confirmed from GitHub:** run 45021679869 at `b39fa35` is green, on a merge commit whose tree is the audited tree (section 9).

What this verdict does not cover:

- **The Mac run** (RF-4), open.
- **The red-team pass.** That thread delivered its own report while my runs were going (`08-red-team.md` in the same folder). I did not read it. From the summary in the project memory, its main finding is about tests that skip themselves with `t.Skip`. That is outside the six acceptance checks and outside the change in `b39fa35`, I did not examine it, and this verdict says nothing for or against it (section 5.1, last limit).
- **One open choice from the last audit** (its O-1): whether a passing subtest under a whole-test entry should fail the run (section 12).

## 2. Audit target

| Field | Value |
|---|---|
| Repository | `evo-agi/Execution-Substrate` |
| Pull request | #14, draft, branch `claude/project-thread-sqldt7-ci` into `trunk_dev` |
| Base SHA | `ae326b0ddc30ec6b35883ee32945c622405b68b6` (`origin/trunk_dev`, the same at opening and at closing) |
| Topic commit SHA | `b39fa35d444a4bd87a3901287bb6a346577c81b9` (6 commits: `d886bb8`, `145ab62`, `fada999`, `c4a84f5`, `af51f86`, `b39fa35`) |
| Tree SHA | `76d9bdc2643bbdce8f057ee2d455f94ec7bca6ae` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` |
| Canonical manifest SHA-256 | `a41367f9cd702a23d627ba1670fd64a54ce1f9b7e43bcda380b06d200ae0108e` (2,033 bytes) |
| Textual diff SHA-256 | `211aed80b98c8b2e686a27711437826a8d6160ff4ca9d9a1608cea605121d1c2` |
| Changed paths | 9, all regular files with mode 0644: 4 new, 5 modified. +3285/−9 against the base |
| Writer's report | `07-repair.md`, SHA-256 `690429e23ab83537aa2f4b83dc7551711113335db198e9d7bffb4a5cb8afa5e1` (verified before reading) |
| Last audit | `06-reaudit.md`, SHA-256 `66ee63c405859cecc6142ae184e0c2435b62dd2857248a89c47e5d804c4b6f7c` (verified before reading), BLOCK at `c4a84f5` |

The nine paths: `.docs/system_overview/go_toolchain_baseline.md`, `.github/ci/environment-only-tests.txt`, `.github/ci/go_test_gate.py`, `.github/ci/go_test_gate_selftest.py`, `.github/workflows/go.yml`, `docs_contract_test.go`, `es/admission/internal/reliablesubmit/replay_custody_file_test.go`, `es/admission/result_auth_test.go`, `remote_alpha_operator_test.go`.

The repair since the last audited tip `c4a84f5` touches the first six (+1776/−166). The three test files at the end are byte-identical to `c4a84f5`, where the last audit read them.

## 3. Audit posture

- **Read-only.** I edited nothing in the target, committed nothing, pushed nothing, posted no comment or review, re-ran no workflow and merged nothing.
- **One thread, no subagents.** That is a deviation from protocol §13.2 step 3. This thread uses subagents only when they are asked for, and the brief asked for efficiency.
- **Where the work ran.** A cloud container, linux/amd64, 4 CPUs. Go 1.26.5 from the Go module proxy (`golang.org/toolchain@v0.0.1-go1.26.5.linux-amd64`, fetched by the go command with its checksum database on), copied to `/opt/go1.26.5`, which the test user cannot write. `GOTOOLCHAIN=local`, `GOFLAGS=-mod=readonly`, an unprivileged user `ci`, umask 022, an empty environment without proxy variables or tokens during every run, and `/usr/bin/go` pointing at another Go version (1.24.7), as on the runner image.
- **Side effects, all inside the container.** One audit clone that I never modified (`/home/user/audit8/prov`). Scratch clones for the runs, the planted fault and the workflow edits, none of them pushed. Throwaway Go modules for probes. One read-only fetch of `refs/pull/14/merge`. One read-only tag listing each of `actions/checkout` and `actions/setup-go` (`git ls-remote --tags`), as the last audit did.
- **Not a red-team.** My own probes ask one question: is the record of the new check the truth, and does the check fail closed. I did not try to deceive the gate with hostile test code beyond what the writer's own checks already hold.
- **Independent of the red-team report.** The red-team thread delivered `08-red-team.md` at about 13:32, while my runs were going. I saw its summary in the project memory after my probes and mutants were written, and I did not read the report. No finding here comes from it.

## 4. Provenance reproduction

Recipe file hash checked before use: `c08597e2…a3ca`, as expected.

A fresh clone from GitHub, the topic branch checked out under its own name, `HEAD` moved to the base with `git reset --mixed`, upstream pinned to `origin/trunk_dev`, nothing staged. The recipe ran twice and the two outputs were compared with `cmp`.

| | PR #14 |
|---|---|
| Pushed tip equals the reported tip | yes, `b39fa35d…81b9` |
| Base is an ancestor of the tip | yes |
| Opening run | 13:06:53, two runs byte-identical |
| Manifest SHA-256 | `a41367f9…108e` |
| Equals the writer's evidence file | yes (`07-repair-evidence/manifest-cumulative.json`, `cmp`) |
| Equals the SHA in `07-repair.md` | yes (section 2) |
| Closing run | 14:32:58, two runs byte-identical, and equal to the opening manifest (`cmp`) |
| Mode-bit differences tolerated | none |

`refs/pull/14/merge` is `32ee8ebabab40a1c391d9155b0cda8d4328814be`, with parents `ae326b0` and `b39fa35` and tree `76d9bdc2…ca6ae`. That is the tree of the topic commit. The runner log shows the checkout of that merge commit (`HEAD is now at 32ee8eb Merge b39fa35… into ae326b0…`). So the runner tested exactly the audited bytes.

**No provenance mismatch.**

## 5. The new machine check, closely

The brief asked four questions about the change in `b39fa35`. This section answers them. The check is called the **observed run** in the gate: a package that has a list entry for a subtest runs a second time, in a test binary built with a changed copy of one Go standard library file, `src/testing/match.go`. The copy writes down the name of every test that `go test -skip` drops. The step fails unless those names are exactly the list entries of that package, each once.

### 5.1 Is it sound?

**Yes.** I found no way for `go test -skip` to drop a test without the record showing it, and no way for a run without a working record to pass.

What I read myself, in the Go 1.26.5 source (`08-audit-evidence/go-source-reading.log`):

- **The skip flag is read in one place.** In the non-test files of package `testing` the flag `-test.skip` is defined once (`testing.go:466`) and its value goes only into `newMatcher` (six call sites: `testing.go:2566`, `benchmark.go:704`, `example.go:32`, `fuzz.go:482`, `485`, `566`). The skip filter itself is consulted only at `match.go:108`, inside `fullName`, and the three lines that follow are the only place where a test is dropped for it. No other package under `src/testing` reads the flag.
- **Every test passes through that place.** `T.Run` calls `fullName` before it creates the subtest (`testing.go:2059`) and returns `true` when the filter excludes it (`:2060-2062`). Top-level tests are started with `t.Run` as well (`testing.go:2585-2589`).
- **The pattern argument in the writer's report holds.** `simpleMatch.matches` (`match.go:125-135`) compares part by part and stops when the pattern runs out. A name that is longer than the pattern is a full match, not a partial one. So the skip for `TestA/x` drops `TestA/x/…` too, and no pattern avoids that.
- **Entries cannot hide each other.** `alternationMatch.matches` returns at the first alternative that matches, even in part. For that to hide a full match of a later alternative, one entry would have to lie inside another. The gate refuses such a list (`go_test_gate.py:237-242`).

What the gate adds to the copy (my own diff, `aud8_overlaydiff.log`): one call inside those three lines, and one variable and one 15-line function at the end of the file. The function appends the name and a line end to the file named by `GO_TEST_GATE_SKIPPED_NAMES`. It reads the variable once, at start. It does not create the file. It ends the test binary when a name cannot be written.

Why a broken recording cannot pass: the gate requires every entry of the package to be in the record. A test binary built without the copy writes nothing, so every entry is reported as not skipped and the step exits 1.

What I ran to test the claim independently:

- **A differential check that does not use the recorder for its ground truth** (`aud8_diff.py`). It builds random modules whose subtest names collide in every way I could think of: `reg`, a neighbour `reg/custody`, a real subtest `custody` of `reg`, repeated names, names with a space, parallel subtests, and parents that stop when a subtest fails. It finds the dropped tests from marker files alone: a test that runs when nothing is skipped, does not run under the gate's pattern with the stock testing package, and whose parent did run, was started and dropped. Then it runs the gate and compares. **200 trials, 0 mismatches.** The gate exited 0 exactly when the dropped tests were the entries, and otherwise named exactly the difference in both directions.
- **240 neighbours started from 8 goroutines at once, as parallel subtests** (probe P1): 240 distinct names reported, none twice, no torn line.
- **A package with an example, a benchmark and a fuzz target beside the entry** (E1): exit 0, exactly one name.
- **A real second toolchain, a moved Go root, and a Go root behind a symbolic link** (B1, K1 to K3): section 5.2.
- The writer's S12 module, the last audit's probe files and the planted fault on the real tree: section 8.

Limits that the gate states itself, and that I agree are limits and not defects:

- **It records what `go test` dropped, not what a test chose not to start.** If a test starts subtest `y` only after the listed `x` got through, `y` does not start while `x` is skipped. An exact skip, if Go had one, would lose `y` the same way, and so does the runner without any list, where `x` fails. The gate's text says this (`go_test_gate.py:93-94`), and the self-check holds the case as it is.
- **It is no defence against test code that forges the record.** Stated at `go_test_gate.py:96-99`. Such code is in the diff of its pull request.
- **It observes a second run, not the run that was judged.** For a test that starts different subtests from run to run, the record is that of the second run. Both runs must pass. See observation A8-O2.
- **It is about `-skip`, not about a test that skips itself.** A test that calls `t.Skip` ends with the verdict `skip`, and the gate counts that as a test that ran (`go_test_gate.py:129`, `:337`). The self-check holds this on purpose (`go_test_gate_selftest.py:734-740`). It was so at `c4a84f5`, and the last audit knew it (its mutant A4). The repair did not change it and the acceptance checks do not ask about it. I did not examine which tests of the tree skip themselves on the runner. The red-team report takes this up.

### 5.2 Does it track the Go version pinned in CI?

**Yes, by refusing every other version.** CI installs the Go version of `go.mod` (`go 1.26.5`) through `actions/setup-go` with `go-version-file: go.mod`, and `GOTOOLCHAIN=local` keeps the go command from switching. Before any test runs, and only when the list has an entry for a subtest, the gate asks `go env GOVERSION GOROOT` and stops with status 1 unless the version is exactly `go1.26.5` and `GOROOT/src/testing/match.go` has SHA-256 `f28418759ed48c72821b5ecc3700041b74151108557618f50d355ea98a1bbebe` (`go_test_gate.py:458-484`).

- The file of my own Go 1.26.5 has that hash. The runner's Go 1.26.5 (GitHub's `actions/go-versions` build, under `/opt/hostedtoolcache/go/1.26.5/x64`) passed the same hold in run 45021679869, so it is the same file.
- **With a real Go 1.24.7 on `PATH` the gate exits 1 before any test runs** (probe B1): `the observed run is written against go1.26.5, and the go command is go1.24.7`. With whole-test entries only it does not ask and passes (B2).
- The overlay is keyed on the path that `go env GOROOT` prints. A copied Go root and a Go root reached through a symbolic link both work (K1 to K3). If the key ever missed, the record would be empty and the step would fail.
- `docs_contract_test.go:1016-1019` holds both constants literally, in the test that already holds the Go baseline. With `go 1.26.6` in `go.mod` that test fails at its line 861, and with either constant changed in the gate it fails at line 1016 (`aud8_hold.log`, Y9, Y1, Y2).

One fact worth knowing: **`match.go` has the same SHA-256 in Go 1.24.7 and in Go 1.26.5.** The file rarely changes. So at the next Go version the hash will probably still match, and it is the version comparison that stops the gate. See finding A8-F1.

### 5.3 Can it drift silently?

**Not into a green run.** Each way I could think of ends red or leaves a visible diff:

| Drift | What happens |
|---|---|
| `go.mod` moves to another Go version | The gate stops before any test (5.2). The self-check fails in every check that makes an observed run. The docs contract test fails until its own lines are changed. |
| Somebody sets the two constants for the new version without reading the file | The gate cannot know that. What it does hold: the copy is made only if the text of the drop place occurs exactly once (`go_test_gate.py:483`), and the self-check's 18 checks of `GateShowsEveryTestItSkipped` run with the real toolchain on every run. If the new version dropped ordinary subtests anywhere else, the neighbours in those checks would go unrecorded and the checks would fail. |
| The list loses its last entry for a subtest | The gate stops asking for the toolchain. The constants may then go stale without a red run. The day an entry for a subtest comes back, the gate stops before any test. |
| The changed `testing` package leaks into other builds | It does not. The go command keys each package build on the content of its input files, read through the overlay (`cmd/go/internal/work/buildid.go:389-395`, `exec.go:426`), so the build with the copy and the build without it are different cache entries. The writer left this as an untested belief. I read the source, and I re-ran the build experiment: two builds with the overlay hold the added function, two builds without it do not, `match.go` under the Go root is unchanged (`cache-check.log`). On the runner no cache is restored anyway. |
| The workflow is edited so that the step no longer does this | Section 5.4. |
| `GOFLAGS` carry an `-overlay` of their own | The flag on the command line wins (probe G1). If it did not, the record would be empty and the step would fail. |

### 5.4 Is `WORKFLOW_SHA256` right?

**Yes.** The SHA-256 of `.github/workflows/go.yml` at `b39fa35` is `1f8937e0ffef39ec7a30b02f75b4e43c981e50c8a89bcd0eceaca453261ee126` (my `sha256sum`, and the manifest). `go_test_gate_selftest.py:38` holds exactly that value. The self-check compares it with the hash of the raw file (`:2170-2184`), and `docs_contract_test.go:1009-1012` requires the self-check to hold the hash of the file as it is. Both pass on the committed tree, and on the runner.

What the hold does, as I ran it on a scratch copy (`wf7.log`, `aud8_hold.log`):

- **Every change of the workflow file turns two things red:** the self-check, which is the first step of the workflow itself, and the docs contract test, which runs in the step "Test" and on a workstation. That held for the writer's 21 edits (among them `|| true`, `continue-on-error`, `if: false`, a `-skip` in `GOFLAGS`, a removed step, swapped steps, a tag in place of a commit pin, wider permissions) and for three of my own: one space at the end of a comment line, CR LF line ends, and a step-level `GOFLAGS` with an `-overlay`.
- **A changed hash constant without a changed workflow is red too** (Y5).
- The message of the Go test prints the hash to set, after the words `review the whole workflow`. That is the right order.

The hold is a hash of the raw bytes, so it has no parser to disagree with GitHub's. What it cannot do is stop a pull request that changes the workflow and the constant together. That change is in the diff of that pull request. The docs page states the rule as it is: `every edit of the workflow has to change that value in the same change` (`go_toolchain_baseline.md`, section 10).

### 5.5 What the check costs and touches

- `es/app` runs twice in the step "Test": 63 s more on the runner, 97 s in my container.
- The installed toolchain is only read. `match.go` under the Go root had the same hash before and after every run of mine, and the test user cannot write there.
- The copy, the overlay file and the record live in a directory that the gate makes with `mkdtemp` and removes at its end. None was left behind in any probe run of mine.
- A flaky test in a package with an entry for a subtest now has two chances to turn a run red. That fails closed.

## 6. The acceptance checks of the last audit

`06-reaudit.md` section 12 set six checks. The four low findings F-2 to F-5 are checks 2 to 5.

| # | Check | Result | My evidence |
|---|---|---|---|
| 1 | **F-1.** A blocking step fails when an entry for a subtest also skips another subtest. S9, S9r, S11 and P-d exit non-zero, the self-check holds them, the texts say what is true | **Met, and the S12 corner is closed too** | S9, S9r, S11: both steps exit 1 (`rt6c.log`). S12: the step "Test" exits 1 and names `TestStop/reg/custody` (`s12.log`). P-d on the real tree: the step "Test" exits 1 and names the planted subtest, and so does the third step (`plant.gate.log`, `plant.still12.log`). Self-check groups `GateShowsEveryTestItSkipped` (18 checks) and `ListedSubtestStandsForItselfAlone` (8). Texts: section 7, no finding |
| 2 | **F-2.** The two steps agree on a subtest whose own name holds a `/`. The header says which subtests cannot be listed. S1 and S8 are in the self-check | **Met** | S1: both steps exit 0. S8: both exit 1 (`rt6.log`, `rt6c.log`). Header: `environment-only-tests.txt:25-49`. Self-check: S1 is `test_subtest_whose_own_name_holds_a_slash_can_be_listed` (`:959`) and `test_subtest_whose_own_name_holds_a_slash` (`:2063`), S8 is `test_entry_that_names_no_test_and_covers_two` (`:1081` and `:2048`) |
| 3 | **F-3.** Every entry is judged in a run that holds no other listed test. T1 exits 1 | **Met** | T1 exits 1 (`rt6.log`). 15 separate `go test -run` commands in my run and in the runner log. My mutant T3, which judges the entries of a package in one run again, is killed by the check `test_listed_test_is_judged_without_the_other_listed_tests` |
| 4 | **F-4.** The workflow file is held as a whole | **Met** | Section 5.4 |
| 5 | **F-5.** The pins target Node.js 24, green on the runner with the same three steps | **Met** | Tags: `3d3c42e5…` is `v7.0.1` and `v7` of `actions/checkout`, `d8cbb804…` is `v7.1.0` and `v7` of `actions/setup-go` (my `git ls-remote --tags`). The runner log shows both downloads by those SHAs, no warning line, and the word "deprecated" nowhere. That both releases declare `node24` is a fact of the last audit (`06-reaudit.md`, F-5), which read `action.yml` at exactly these two commits. I did not read it again |
| 6 | **RF-4.** One Mac run of the changed tests at the new head | **Open. Not in this audit.** | It changes no bytes. It stays a condition for the merge |

## 7. Findings

**No critical, high or medium finding.** One low finding, a patch defect. No new pre-existing issue. Six observations that need no correction.

### 7.1 Patch defects

**A8-F1. The self-check does not hold that the gate compares the Go version exactly.**

- ID / Type / Severity: A8-F1 / test gap in the self-check, the gate itself is right / **low**.
- Current contract or strategic target: `go_toolchain_baseline.md` section 10: `The gate makes the copy only from the file of the exact Go version that it names, so a change of the Go baseline has to review that file and change the gate in the same change.` This is the machine-enforced trigger for the one rule for people that the observed run leaves: read the testing package again at every Go version.
- Path and line: `go_test_gate_selftest.py:143-149` (the stand-in go command for "another version" reports `go1.0.0`) and `:1273-1282` (the only check of the comparison). The comparison itself is `go_test_gate.py:463`.
- Evidence:
  - Mutant H1 (`if not version.startswith("go1.26"):`) and mutant H2 (the version compared without its last number) pass all 90 checks (`aud8_mutants.log`).
  - With a go command that reports `go1.26.6` and has the real Go root, the committed gate exits 1 with the right message, and the gates of H1 and H2 exit 0 and print `the observed run passed` (`aud8_patchrelease.log`).
  - `src/testing/match.go` has the same SHA-256 in Go 1.24.7 and in Go 1.26.5 (`aud8_probes.log`, probe B). So the hash comparison does not fire at a Go version change that leaves this file alone, which is the common case. The version comparison is then the only thing that stops the gate.
- Impact: none today, because the gate at `b39fa35` compares exactly. A later edit that loosens line 463 would pass the self-check. From then on a new Go patch release would get its observed run without the review that the docs promise. Such an edit is in the diff of its own pull request.
- Required correction: one more case in `test_another_toolchain_is_refused_before_any_test_runs`: a go command that reports another patch release of the same Go line (the real version with its last number changed) and the real Go root. Expected: status 1, no test ran, the message of lines 464 to 469. It kills H1 and H2.
- Uncertainty: none about the facts. Whether the case has to go in before the merge is a reading of the project rule (section 12).
- Patch defect or pre-existing issue: patch defect, new with `b39fa35`.

### 7.2 Pre-existing issues

None new. Two items of the last audit are still open and are not defects of these bytes: the Mac run (RF-4) and the choice in its observation O-1 (section 12).

### 7.3 Observations

- **A8-O1. The hash of `match.go` holds less than it seems to, and that is fine.** The file is the same in Go 1.24.7 and in Go 1.26.5. Inference: it will often be the same at the next release too. The reading that `-skip` drops a test in one place also rests on other files of package `testing` (`testing.go:2059-2062`, and the six callers of `newMatcher`), and no hash holds those. For an official Go release the exact version fixes all of them. So the hash stops a toolchain whose `match.go` was changed, and the version comparison does the rest. This is why A8-F1 is worth its one case.
- **A8-O2. The observed run is a second run of the package.** The record shows what `go test` dropped in that run. If a test started a neighbour of a listed subtest in the first run and not in the second, the first run dropped it unseen. That needs a test whose subtest names change from run to run, by chance, by time or by state that the first run left behind. I did not search the tree for one. The second run is a complete gate run in itself: its tests pass, every test that is not listed ran in it (my mutant B8 is killed), and it dropped exactly the entries. The writer's report states this property (`07-repair.md`, line 191). No correction required.
- **A8-O3. A hold by text can be passed by a second assignment.** A line below the held line that sets `OBSERVED_GO_VERSION` again passes the docs contract test (`aud8_hold.log`, Y4). That test requires the held line to be present, not to be the only assignment. It is the same class as a pull request that changes the workflow and its hash together: the edit is in the diff. No correction required.
- **A8-O4. Mutant H4 survives and no reasonable case can kill it.** It compares only the first 8 hex digits of the hash. A case for it needs two files whose hashes share those digits. Not a gap.
- **A8-O5. A `TestMain` that calls `m.Run` twice is refused with a reason that is not the true one** (probe M1): `listed test TestP is defined 2 times in package synth/a (in its internal and its external test package)`. `go test -list` prints every name twice there (`aud8_m1list.log`). The gate exits 2 and no test runs, so it fails closed. The tree has no `TestMain` today. The refusal itself is older than this repair.
- **A8-O6. One sentence of the pull request description is off by four.** It says `90 checks on throwaway modules, plus checks of the workflow file itself`. The 90 include the 4 checks of the workflow file. This is not in the audited bytes. It matters only if the description becomes the text of the merge commit.

## 8. Validation assessment

Every run below used the bytes of `b39fa35`: a scratch clone checked out at that commit, tree `76d9bdc2…ca6ae`, clean status before and after.

### 8.1 Commands I re-ran

| Command or script | Result |
|---|---|
| `go mod verify`, `go build ./...`, `go vet ./...` | `all modules verified`, exit 0, exit 0 |
| `gofmt -l docs_contract_test.go` | no output |
| `go test -count=1 -run '^TestGo1265ToolchainBaselineDocsAndBuildContract$' .` | `ok` |
| `git diff --check ae326b0..b39fa35` | exit 0 |
| `python3 -I -B .github/ci/go_test_gate_selftest.py` | `Ran 90 tests in 98.116s`, `OK` (19 + 13 + 18 + 2 + 9 + 17 + 8 + 4 checks in eight groups) |
| `… go_test_gate.py gate "$ENVIRONMENT_ONLY_TESTS"`, whole module | **exit 0 in 544 s.** `test gate passed: 41 packages, 3 of them with skipped entries (15 entries)`. 22 `ok` lines: 21 packages with tests, `es/app` twice. Root package 156.2 s, `es/app` 101.6 s, its observed run 96.7 s, ending with `the observed run passed; go test skipped exactly the listed tests of this package (2), each once` |
| `… go_test_gate.py still-failing "$ENVIRONMENT_ONLY_TESTS"` | **exit 1 in 14 s, as expected in a container.** 15 runs, one per entry. 12 entries still fail. Exactly the three `TestRemoteAlphaRuntimeSecurityBoundary…` entries pass here. The writer's container showed the same, and its report names the host's modprobe and `systemctl` state as the reason. On the runner all 15 fail (section 9) |
| The same step with the 12 entries that fail in a container (`list-12.txt`) | **exit 0.** `all 12 listed tests still fail on this host, each in a run of its own` (`real.still12.log`) |
| The last audit's probe files, unchanged: `rt6.py` (47 runs), `rt6b.py` (5), `rt6c.py` (12) | Every run ends with the exit status in the writer's logs. Against the last audit's own log at `c4a84f5`, nine runs of `rt6c.py` differ, all from 0 to 1, as the writer's report says |
| The writer's S12 module (`s12.sh`) | step "Test" exit 1, third step exit 0, as reported |
| The writer's build cache experiment (`cachecheck.sh`) | as reported (5.3) |
| The planted fault P-d of the last audit on the real tree (`plant-d.diff`, gate and list unchanged), whole gate | **exit 1 in 429 s.** The first run of `es/app` passes (90.1 s), the observed run passes its tests (93.8 s) and then reports `the gate skipped a test that is not listed: … /local_build_path_rejects_missing_Go_before_mutation/planted_second_subtest`. Last line: `test gate failed: execution-substrate/es/app: the tests that go test skipped are not exactly the listed ones`. The third step on that tree with the 12 entries: exit 1, and its only error names the same subtest. At `c4a84f5` both steps were green with this plant (finding F-1 of the last audit) |
| The writer's workflow edits (`wf7.py`: 21 edits and one control) | The control passes both holds. All 21 edits fail the self-check and the docs contract test |
| The committed self-check against the gate of `c4a84f5` and of `af51f86` | `FAILED (failures=39)` in 34 of the 90 checks, and `FAILED (failures=23)` in 20 of them. The failing lines are the same as in the writer's two logs. So the self-check tells both older gates from the committed one. (The two lines for these runs in `jobB-status.txt` say `exit 0`. That is the exit status of a hash command in my script, not of the self-check. The logs are the evidence) |
| The writer's mutants (`mutants4.py`: 139 and one control) | **134 killed, 5 survive**, the same five as reported. Section 10 |

### 8.2 Probes and mutants of my own

| Script | What it asks | Result |
|---|---|---|
| `aud8_diff.py` | Is the record the truth? (5.1) | **200 trials, 0 mismatches** (seed 8: 40, seed 9: 160). In 133 trials the gate had to pass and in 67 it had to fail, and it did. It had to name 91 tests as skipped although not listed and 56 entries as not skipped, and it named exactly those. 84 trials had two entries, 111 had an entry that fails when it runs. No gate directory was left behind |
| `aud8_probes.sh` | Another real toolchain, a moved and a linked Go root, concurrent drops, other kinds of test functions, a `TestMain` that calls `m.Run` twice, an `-overlay` in `GOFLAGS` | B1: exit 1 before any test. B2: exit 0, and the gate does not ask for the toolchain. K0 to K3: exit 0, each with `the observed run passed`. P1: exit 1 with 240 distinct names, none twice, no torn line. E1: exit 0 with exactly one name. M1: exit 2, refused before any test (observation A8-O5). G1: exit 0, the `-overlay` of the command line wins. No gate directory left behind, `match.go` of the toolchain unchanged afterwards. One more probe for finding A8-F1 (`aud8_patchrelease.sh`): section 7 |
| `aud8_hold.py` | Do the holds notice a change of the constants, the workflow hash, the workflow text and `go.mod`? | 10 cases, all as expected. A changed version constant, a changed digit of the `match.go` hash and a trailing comment on the constant's line fail the docs contract test (Y1 to Y3). `go 1.26.6` in `go.mod` fails it (Y9). A changed digit of `WORKFLOW_SHA256` and three workflow edits fail both holds (Y5 to Y8). One case passes both, as I expected: a second assignment below the held line (Y4, observation A8-O3) |
| `aud8_mutants.py` | 37 changes of the gate of my own, most of them in the observed run, against the committed self-check | **34 killed, 3 survive** (H1, H2, H4). Section 10 |
| The committed self-check with Go 1.24.7 on `PATH` | What a workstation with another Go sees | exit 1: `FAILED (failures=43)` in 33 checks, each with the gate's own message that names `go1.24.7`. The header of the self-check says so (`go_test_gate_selftest.py:14-16`). A workstation needs Go 1.26.5 first on `PATH` for a green self-check |

### 8.3 Not run

- **macOS, entirely.** Nothing in this report is a macOS result (RF-4).
- **A runner run of my own.** A read-only audit pushes nothing. The runner evidence is the writer's one run, which I read from GitHub myself (section 9).
- **The race detector.**
- **The red-team pass.** A separate thread.
- **Which tests of the tree skip themselves on the runner.** Not examined (section 5.1, last limit).
- **PR #16.** Not in the brief.
- **The code of the two new action releases.** Not read by me or by the writer. Both are GitHub's own actions, pinned by commit, with a read-only token and no secrets.

## 9. The runner result, from GitHub

Run [45021679869](https://github.com/evo-agi/Execution-Substrate/actions/runs/45021679869), job 137205773120, event `pull_request`, head `b39fa35d444a4bd87a3901287bb6a346577c81b9`, attempt 1, started 12:19:33, completed 12:27:30, **conclusion success**. I read these from the GitHub API and downloaded the job log myself (777 lines; equal to the writer's copy except for the last line end).

| What the log must show | Found |
|---|---|
| The checkout of the audited bytes | `HEAD is now at 32ee8eb Merge b39fa35… into ae326b0…` (section 4) |
| Go 1.26.5 from `go.mod`, no cache | `Successfully set up Go version 1.26.5`, `go version go1.26.5 linux/amd64`, `cache: false`, no restore line, no `(cached)` |
| Both action pins | downloads of `actions/checkout@3d3c42e5…` and `actions/setup-go@d8cbb804…` by SHA |
| The self-check | `Ran 90 tests in 54.862s`, `OK`, 90 lines ending in `ok` |
| The toolchain hold, before the first test run | `+ go env GOVERSION GOROOT` at 12:21:20, once |
| The step "Test" | `test gate passed: 41 packages, 3 of them with skipped entries (15 entries)`, 22 `ok` lines, two lines `ran without the listed …` |
| The observed run | one command with `-overlay`, for `es/app`, and `the observed run passed; go test skipped exactly the listed tests of this package (2), each once` |
| The third step | 15 log groups, 15 commands `go test -json -count=1 -run …`, 15 lines `still fails: …`, then `all 15 listed tests still fail on this host, each in a run of its own` |
| No annotation | 0 lines with `##[warning]`, `##[error]` or `::error`; the word "deprecated" does not occur |
| The token | `persist-credentials: false`; the checkout step sets up its credentials file and removes the entries again in its own "Removing auth" group, before any other step |

Limit: this is one run on one runner image (`ubuntu-24.04`, version `20261116.133.1`).

## 10. Mutants

A mutant is one deliberate change of `go_test_gate.py`. It is killed when the committed self-check fails on it. Each run stops at its first failing check.

**The writer's 139 mutants** (`mutants4.py`, unchanged, 13:37:41 to 14:15:45, `mutants4.log`): **134 killed, 5 survive, and the control passes all 90 checks.** Every mutant has the same result as in the writer's log, and every killed mutant is killed by the same check. No mutant is killed by an error in the self-check. The five survivors are the five the writer names:

| Survivor | Why it survives | Does it matter |
|---|---|---|
| F20x | It gives a name a new value and changes nothing. Kept by the writer for the record | No |
| E1 the first verdict of a test wins, E2 a test counts as started only on its `run` event | The same behaviour for the output of a real `go test`. The last audit judged both (its A5, A6) | No |
| E3, E4 two guards on the output of `go list` | They cannot be reached with a real `go` command (the last audit's A14, A15) | No |

**My own 37 mutants** (`aud8_mutants.py`, none copied from the writer's file, 14:15:45 to 14:30:20, `aud8_mutants.log`): **34 killed, 3 survive, and the control passes all 90 checks.** Every kill is a failed assertion.

| Group | Mutants | Killed |
|---|---|---|
| The recorder in the test binary: never called, records only some names, ignores a name it cannot write, creates a missing record, reads the variable at every call, writes no line end | N1 to N7 | 7 of 7 |
| The toolchain hold: version, hash, a failing `go env`, two drop places, a wrong overlay key, the check made too late | H1 to H8 | 5 of 8. H1, H2 and H4 survive |
| Which packages are observed and with what: only the first package, only all-subtest packages, a narrower pattern, the test cache, the variable not passed, the record not emptied, a failing run still read, the run's own checks dropped | B1 to B8 | 8 of 8 |
| Reading the record: a name under an entry forgiven, whole-test names forgiven, a missing entry forgiven, a repeated name forgiven, a problem named but not failing, a torn last line, the record read as a set | C1 to C10 | 10 of 10 |
| The gate leaves its directory behind | D1 | 1 of 1 |
| The third step: looks one level deep only, names a covered test without failing, judges the entries of a package in one run again | T1 to T3 | 3 of 3 |

The survivors: H1 and H2 are finding A8-F1. H4 is observation A8-O4.

What the kills show about the new check: the self-check notices a recorder that is built in but silent (N1), a record that is not required to hold every entry (C3, C6), a neighbour that is forgiven because it lies under an entry (C1, C4), and an observed run that is replayed from the test cache (B4). Those are the ways the check could turn into a formality.

## 11. The questions the writer left for this audit

`07-repair.md` section 12 asked the auditor to judge three things.

- **The boundary "what a test does not start is not skipped".** Accepted (5.1). It is a property of listing a subtest at all, not of how it is skipped.
- **The leaf rule of the third step: a subtest with subtests of its own cannot be an entry.** Accepted. The gate passes such an entry and the third step refuses it (probe S10: 0 and 1), so the run is red and names the reason. The rule is stricter than the observed run needs. It keeps an entry as narrow as the thing that fails, and the list header states it (`environment-only-tests.txt:31-34`).
- **The surviving mutants.** Section 10.

## 12. The project rule: no "revisit later", and a machine-enforced trigger for every temporary edge

| Item | Judgement |
|---|---|
| The corner the first version of `07-repair.md` left to a rule for people (S12) | **Closed by a check.** The rule for people is gone from the list file. A search of the nine files for `accepted`, `for now`, `not yet`, `later`, `revisit`, `TODO` and `temporary` finds no sentence that states a limit as accepted or puts work off |
| The Go version that the observed run is written against | **Has its trigger:** the gate stops on any other version (5.2). The self-check does not hold that the trigger is exact (A8-F1) |
| Finding A8-F1 itself | **No trigger, and it should not become a "later" item.** It is one case in an existing check. My judgement is that it does not block: the gate is right today and the gap is in the net below it. If the coordinator reads the project rule as covering this, the case goes in before the merge, and the changed bytes need a new audit. If the red-team report leads to a repair of these files, the case belongs in that repair |
| The workflow file | **Has its trigger:** the hash, in two places (5.4) |
| The list itself | **Has its trigger:** the third step, now one run per entry |
| The Mac run (RF-4) | **Open, and a merge condition.** Not a "later" item as long as the merge gate waits for it |
| Whether a passing subtest under a whole-test entry should fail the run (O-1 of the last audit) | **Still a choice for the coordinator or David, as the last audit left it.** It is printed, not enforced. On the runner 15 subtests pass under two whole-test entries (`4 pass, 18 fail` and `11 pass, 4 fail`), on purpose and with the reason in the list file |
| "No `gofmt` step yet", "No `-race` step yet" (PR description) | Scope statements of the pull request, not edges of this change. Nothing triggers them. The coordinator may want them tracked |

## 13. Not covered, and Unknown

**Not covered:** section 8.3.

**Unknown, and what would settle it:**

- Whether the `go` check is a required status check on `trunk_dev`, and whether pull requests from forks need approval before workflows run. I cannot read the repository settings. A look at them settles both. This is the last line behind the workflow hold, as the writer says.
- Whether the self-check passes on David's Mac. Inference: it does if the Go there is exactly 1.26.5, because `match.go` is source and the same in every distribution of a release, and a Go root behind a symbolic link works on Linux (K2, K3). The Mac run settles it.

## 14. Closing state

- **The audit clone** (`/home/user/audit8/prov`): `HEAD` at the base, the same nine changed paths, no ignored and no extra file, nothing staged. The recipe hash was verified again, and the closing manifest at 14:32:58 is byte-identical to the opening one.
- **The remote at 14:32:58** (`git ls-remote`): `trunk_dev` is `ae326b0d…68b6`, the topic branch and `refs/pull/14/head` are `b39fa35d…81b9`, `refs/pull/14/merge` is `32ee8eba…14be`. All as at the opening.
- **PR #14** (GitHub API at closing): open, draft, head `b39fa35`, base `ae326b0`, `mergeable_state` clean, last updated 13:05:03, which is before my opening run. One check run, `build, vet and test`, success.
- **The scratch tree of the runs:** tree `76d9bdc2…ca6ae` and a clean status after the last run (`jobB-status.txt`). `match.go` of the toolchain has its hash after every run.
- **Pushed or posted:** nothing. Everything this audit created is in the container, outside the audit clone, and in the two delivery paths of section 17.

## 15. Sensitive-material handling

The patch holds no secret, token or key. I read no environment file, no SQLite state, and no TLS, SPIFFE or Vault material outside fixtures that the tests create themselves. Every run of mine used an empty environment, so no token of this session reached a test process. The runner log shows the checkout token only as `***`. The evidence folder was scanned for e-mail addresses, phone numbers and key material before delivery: none found (50 evidence files, the index and the list of hashes).

## 16. Confidence

- **Provenance: high.** The manifest was reproduced twice at opening and twice at closing, equal to the writer's file, and the runner's merge commit has the audited tree.
- **Validation: high for Linux.** I ran the gate, the self-check, the probes and the mutants myself on the exact bytes, and I read the runner result from GitHub. **None for macOS.**
- **Implementation: high.** The check reads the decision of `go test` at its source, compares for equality in both directions, and fails closed when the reading does not work. I read the Go source it rests on and tested it against ground truth that does not use the recorder. What remains is what any audit leaves: a way to drop a test that neither the writer nor I found, and hostile test code, which is the red-team's subject.

## 17. Report delivery

- Path: `/mnt/project-files/reports/Execution-Substrate/ci-go-workflow/08-audit.md`. Its SHA-256 is in the reply that delivers it.
- Evidence: `/mnt/project-files/reports/Execution-Substrate/ci-go-workflow/08-audit-evidence/`, indexed by its `README.md`. Scripts carry the extra suffix `.txt`.

**Final verdict: ACCEPT**
