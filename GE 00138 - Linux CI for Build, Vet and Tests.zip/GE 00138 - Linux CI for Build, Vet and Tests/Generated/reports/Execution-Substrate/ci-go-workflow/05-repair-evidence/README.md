# Evidence for 05-repair.md (Execution-Substrate, CI workflow, PR #14 and PR #16)

Written 2026-11-22 by the writer thread "Finish the ES CI workflow fix". The report `../05-repair.md`, section 15, says what each file is.
Files ending in `.txt` that are scripts are copies of the scripts as they ran. Nothing here is a secret. The folder was searched for tokens, keys, mail addresses and phone numbers.

PR #14 head `c4a84f5695500cca2087abefb8027afd700f35e2`, tree `a05a25a6db5fe1d51819f16a28a9f18132667ccf`. PR #16 head `0a069ecbe53c842d33c932f63aed2af523e2eb0c`.

SHA-256 of every file in this folder, except this one:

```text
1150045eb2435bc798412b8a78aef9bbbf3927b96d2d90051eb775b02c519095  container-env.sh.txt
126f4c7cffd3eb4e7a2b6b64922eab8d668d360a1ac65ab529de0c4bde08b8ef  container-fullgate.sh.txt
9b6a7fb99a616eda6751abd0851c7763325d3ef6d948a8379f147e5f072eefc2  container-gate-status.txt
25c6dcbc94248e92572973ac8eea1b61f5356bdaa1dfe6e802e65c978aef4562  container-gate.log
0eaa5ab7ffb151b77250e08beda6ffc548b6d3aa393f616e3fa489fb1746e1c5  container-run.py.txt
e5128fa94c68c98807e054f9265795e38e943bce738880ad01a74108ff10449e  container-still-failing.log
ed9143e95fc2544734b9d17c7a39219ca5e220dc983a0bb7e9e8c650494b3e62  container-sync.sh.txt
35b05f4a8df0879648b542711c00b1477fc93333caab3e916e83b733d0d6fe5e  lock-output.txt
caac896c167cec7d0aa459d9c1f64e4dc1585dc6c92f6132d6adf7a509ac1fdc  lock_orphan.sh.txt
d229843228a12692f33394da1d31ce3247278f3972c5d6add831851ae72eee0c  lock_run.sh.txt
ddb4f883325b5b8a8d82ce07a8ace3e6803e532b855c0d72078207da434c83a9  lock_setup.sh.txt
ff05879da57e36a1c2a2bc53d5fe85e8a2a5dc6c1823206cd3072d1402ddad74  lock_stall.sh.txt
cf8c159ff17baff1096fe7d8c41fa86ebd8ba97bd1e7e635fb057d64860908f7  manifest-cumulative.json
b14b8ac19ba92beb3a218df837cd8315ea959fc0544d57f170aa12fbe0c936a2  manifest-lock-test-fix.json
e33d929eb1b19208941b7fabd1966c9a813720013ddc79c77a0be41063ef381b  manifest-repair-only.json
34ab55b158c655404b4b91af30d890b973765a9de4e70b2a6559a3a22e3c8b98  mutants-first-run-output.txt
654bfe614ca9ecadf70b7d82c877203cca16a7a95f46db42805760b9691aaa57  mutants-first-run-survivors-rerun-output.txt
e20e735c69263a484b1da087e5a9d1abf15085e2d9640dbca328b0d84427775c  mutants-output.txt
e20823c6c18c0667a7bb070256d89025e9f68fd52fd76c4362e28bffdabe4d58  mutants.py.txt
dd2f3d01dab3059429b778643fc594de2f0876cda3f98a8cb3b6181dc00d6933  redteam-adapted-output.txt
6866e85522e61aca81d6171b6fb43addce940521d198f2cacda6a0e8de3b583b  redteam-original-output.txt
0044b38c37bd1df20f91b050412eab633b76083df2d67b74403f1c95baaa1444  redteam_adapted.py.txt
1806e7c27642c5e9019e1f83977333268d95883e05480adcf5f039f3b26bf0c0  run_all.sh.txt
1aa40d493e6a0d8e92025e7ad9f6a1a727422cee9001c27655774c527e57d03e  runner-run-44996283604-job-137127901877.log
```
