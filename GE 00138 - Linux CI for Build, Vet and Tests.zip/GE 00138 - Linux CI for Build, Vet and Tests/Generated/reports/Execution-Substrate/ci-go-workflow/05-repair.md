# REPAIR REPORT 2 (replacement implementation report): Execution-Substrate Linux CI

**Verdict:** REPAIR_COMPLETE for the bytes. Ready for a fresh independent audit and red-team pass of the whole base-to-tip range. One required pre-merge check is still open and changes no bytes: the run on David's Mac (RF-4). It is requested and waits for his approval on the Mac.
**Effect status:** TOPIC_BRANCH_PUSHED (fast-forward, no force) · DRAFT_PR_UPDATED https://github.com/evo-agi/Execution-Substrate/pull/14 · CI_GREEN_ON_RUNNER (run 44996283604 at `c4a84f5`, one run) · SECOND_DRAFT_PR_OPENED https://github.com/evo-agi/Execution-Substrate/pull/16 (lock-timing test) · MERGE_NOT_PERFORMED · INDEPENDENT_AUDIT_NOT_PERFORMED on the new bytes · RED_TEAM_NOT_PERFORMED on the new bytes

This report replaces `03-repair.md` as the implementation report for PR #14. It answers the BLOCK in `04-reaudit.md` (SHA-256 `8344813d39542bcff7ab5a04a6e6de2b4e901c40f3e535b4a6739322c25532e4`, which is what I read). The writer role for this branch moved to this thread ("Finish the ES CI workflow fix") by coordinator decision. The thread that wrote `01` and `03` no longer touches the branch.

All times are UTC on 2026-11-22.

## 1. What was repaired, in short

The re-audit blocked on three things. All three are fixed with the proper fix, not a narrower one.

1. **One list line can no longer skip two tests (RF-1).** A directory can define a test of the same name twice: once in its internal test package and once in its external one. One `-skip` pattern skips both. The gate now asks `go test -list` for the names and requires a listed name to appear exactly once. Otherwise it refuses the list with status 2 before any test runs.
2. **A blocking step now fails when a listed test no longer fails (RF-2).** The old step ran the listed tests, was allowed to fail, and failed on every run. The new step "Listed tests still fail" runs exactly the entries and is green only if every one of them fails. An entry that passes, skips itself or does not run is named, and the run is red. This is the machine-enforced trigger that removes entries from the list.
3. **Entries can name a subtest, so six passing `es/app` subtests are back in the gate (RF-3).** The two `es/app` entries now name the one subtest that fails on the runner. The other three subtests of each test run in the gating step. The gate also checks what really ran, so a subtest entry cannot quietly remove its whole test.

Settled in the same repair, as the re-audit recommended:

- **Build cache (RF-6):** the workflow restores no build or module cache (`cache: false`).
- **Docs (RF-7):** the governing toolchain doc now describes CI, and the docs contract test holds that text and the workflow's key lines.
- **Self-check gaps (RF-5):** the self-check grew from 20 to 56 checks. It kills the three mutants the re-audit named and every other mutant I could build (section 7.2).
- **SPIRE test (section 7, item 4):** ported with the one-line change the re-audit described. Its entry is deleted. 15 entries remain.
- **Nits (RF-8):** the raw non-breaking space in the self-check is now a `\u00a0` escape, and the self-check now reads the workflow file.

Done separately, as the brief allowed: the lock-timing test of `reliablesubmit` has its own branch and draft PR #16 (section 8).

Not done: the Mac run (RF-4). Section 7.6 says what is requested and what it will show.

## 2. Target identity

### PR #14 (CI)

| Field | Value |
|---|---|
| Repository | evo-agi/Execution-Substrate |
| Base ref and SHA | `trunk_dev` at `ae326b0ddc30ec6b35883ee32945c622405b68b6` (re-fetched before the manifests; unchanged) |
| Topic branch | `claude/project-thread-sqldt7-ci` |
| Commits | `d886bb80feb160b6775f0ac1866ce69f7bdbfe47`, `145ab62001e488fea0cd4c4a002661df86ef9f95`, `fada999c6da5ed157c74033e1e975415c179c49d` (the tip the re-audit blocked), then this repair `c4a84f5695500cca2087abefb8027afd700f35e2` |
| Tip tree | `a05a25a6db5fe1d51819f16a28a9f18132667ccf` |
| Draft PR | #14, base `trunk_dev`, now 9 files, +1675/−9. This repair alone: 7 files, +1207/−198 |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified with `sha256sum -c` before each run |
| Manifest upstream | `origin/trunk_dev` |
| **Cumulative manifest SHA-256 (audit this one)** | `cf8c159ff17baff1096fe7d8c41fa86ebd8ba97bd1e7e635fb057d64860908f7` (2,033 bytes), HEAD `ae326b0`, 9 files: 4 untracked new, 5 tracked_modified |
| Cumulative textual diff SHA-256 | `f384ac8faa1c2456a436da2ff3b79efc3a4d28f8db722815b5b7458074915a6a` |
| Repair-only manifest (the delta) | `e33d929eb1b19208941b7fabd1966c9a813720013ddc79c77a0be41063ef381b` (1,639 bytes), HEAD `fada999`, 7 files, textual diff `7f5180340a5d818d9ac4114b4fed9a1cc94bc31940d1697a307dcd9054a4968d` |

**Auditor reproduction:** provenance §5.3 with `BASE=ae326b0ddc30ec6b35883ee32945c622405b68b6`, `TOPIC=claude/project-thread-sqldt7-ci`, `TIP=c4a84f5695500cca2087abefb8027afd700f35e2`, and the upstream pinned with `git branch --set-upstream-to=origin/trunk_dev`. I ran exactly that in a fresh clone from GitHub after the push. The result was byte-identical to the cumulative manifest (`cmp`), twice.

Final working-tree status after the commit: clean (`git status --porcelain` empty).

### PR #16 (lock-timing test)

| Field | Value |
|---|---|
| Base ref and SHA | `trunk_dev` at `ae326b0ddc30ec6b35883ee32945c622405b68b6` |
| Topic branch | `claude/project-thread-k69qcw` |
| Commit | `0a069ecbe53c842d33c932f63aed2af523e2eb0c` |
| Tree | `0b327b54deb9b880a748851fc4248bf3e3531809` |
| Manifest SHA-256 | `b14b8ac19ba92beb3a218df837cd8315ea959fc0544d57f170aa12fbe0c936a2` (501 bytes), HEAD `ae326b0`, 1 file tracked_modified, upstream `origin/trunk_dev` |
| Textual diff SHA-256 | `2504375ef8b14da68ac600b1870a049fbb1eb0ff1c03dd3d67fd8cba23c6d467` |

Reproduced in the same fresh clone, byte-identical.

## 3. Reconnaissance

No subagents. I read `02-audit-redteam.md`, `03-repair.md`, `04-reaudit.md` with its evidence folder, the operating protocol and the provenance guidance. In the repository I read `AGENTS.md`, the parts of `PLANS.md` that mention CI (lines 89 and 319; both are scoped statements about earlier tranches and stay true), `.docs/system_overview/go_toolchain_baseline.md`, and the pinned sentences in `docs_contract_test.go`.

I read the log of runner run 44984626477 (at `fada999`) directly instead of relying on the reports. It shows exactly one failing subtest in each of the two `es/app` tests, with the message `expected missing Go diagnostic, got unsupported Go toolchain: expected go1.26.5, observed go1.26.11`.

Facts about `go test` that the design rests on. I established each by experiment with Go 1.26.5 on a throwaway module, not from memory:

- `go test -list '^Test' <package>` prints a top-level name once per definition. A name defined in both `package a` and `package a_test` is printed twice.
- A `-skip` or `-run` pattern is split at `|` into alternatives, and each alternative at `/` into one expression per level. `^A$/^b$` matches subtest `b` of test `A` only: `A` itself runs, and so do its other subtests.
- **go test stops at the first alternative that matches even partly.** With `-skip '^P$/^bad$|^P$'`, test `P` runs with all of its subtests skipped, where one would expect `P` to be skipped whole. This is why entries of one package must not overlap. The re-audit's sketch did not have this rule.
- A second subtest with the same name is called `name#01`. A space in a subtest name is printed as `_`.
- Under `go test -json`, a test that panics gets a `fail` event and the tests after it never start. A test that calls `os.Exit` gets a `run` event and no verdict.
- `go test` stores passing results and replays them. Only `-count=1` makes a test with no recorded file or environment access run again.

Findings adopted: the re-audit's required corrections for RF-1, RF-2, RF-3 and its recommendations for RF-5 to RF-8, in substance as its sketch describes them. Findings rejected: none. Preserved disagreement: one reading of acceptance check 2 (probe G3), explained in section 7.3.

## 4. Implementation decisions

Nothing here touches an Execution Substrate contract, boundary, DTO, lifecycle rule or seam. Current-contract treatment: unchanged. Strategic target: not affected. Reopened seams: none. Compatibility: no production code changes; the only non-CI files touched are tests and one doc. In the repository's own terms, the list of environment-only tests is a temporary edge of the CI tooling. Before this repair its removal condition was a sentence. Now it is enforced by a step of the workflow.

### 4.1 The list: `.github/ci/environment-only-tests.txt`

- An entry is still one line: a package import path, one space, and now a **test path**. A test path is a top-level test name, or that name followed by `/` and a subtest name as go test prints it, any number of times.
- 15 entries: 11 in the root package, 2 `es/app` subtests, 2 in `reliablesubmit`.
- The header no longer carries a TODO. It states the rule that the new step enforces: every entry must still fail on the runner, so a change that makes a listed test pass has to delete its line in the same change.
- The two `es/app` entries name the subtest `local_build_path_rejects_missing_Go_before_mutation`.
- The first two root custody tests stay listed whole, and the file says why. The TLS status bootstrap refuses a caller that is not `ds` at its first identity check (`scripts/remote_alpha_operator.sh`, lines 2104 to 2113, which I checked). A subtest that expects a refusal then passes without reaching the custody check it is named for. Keeping such subtests in the gate would claim a check that does not happen. This is the re-audit's point P-A, and it agreed these two may stay whole.
- The SPIRE entry is gone (section 4.7).

### 4.2 The gate: `.github/ci/go_test_gate.py`

Two modes, each one step of the workflow: `gate LIST` and `still-failing LIST`. The old mode `environment-only` is removed.

**Reading the list (both modes, before any Go command):**

- Strict grammar, matched against the whole line: `([A-Za-z0-9_][A-Za-z0-9_./-]*) (Test[A-Za-z0-9_]+(?:/[A-Za-z0-9_-]+)*)`. A test name holds only ASCII letters, digits and underscores. A subtest name may also hold `-`. So no element can act as a regular expression.
- A repeated entry is refused.
- An entry that lies inside another entry of the same package is refused, in either order (`TestA` with `TestA/sub`). This is the overlap rule from section 3.

**Checking the list against the module (both modes):**

- The package must be exactly one of the paths that `go list ./...` prints.
- `go test -list '^Test' <package>` must print the entry's top-level name **exactly once**. Zero times: "listed test is not defined in package". More than once: "listed test X is defined N times in package P (in its internal and its external test package); one entry would skip all of them". Both are status 2. This is RF-1.
- If `go list` fails, the gate stops with status 1, even if it printed packages. If `go test -list` fails for a listed package, the run is marked failed.

**Mode `gate`:**

- A package with entries runs alone: `go test -json -count=1 -skip <pattern> <package>`. The pattern is the package's own entries, each level anchored, joined by `|`. For example `^TestA$|^TestB$/^sub$`.
- All other packages run in one plain command with nothing skipped: `go test -count=1 <packages>`.
- The gate reads the JSON events and writes to the log what plain `go test` would write: the package lines, and the output of every test that fails or does not finish.
- **After a listed package passes, the gate checks what really ran there:**
  - every top-level test that `go test -list` named and that is not a whole-test entry must have reported a verdict. Otherwise: "tests that are not listed did not run";
  - the parent of every listed subtest, at every level, must have run;
  - for each listed subtest it writes one line that names the sibling subtests that ran and their verdicts. That line is the evidence the re-audit asked for in acceptance check 3.
- Any exit status of `go test` other than 0 is a failure.

**Mode `still-failing`:**

- For each package with entries: `go test -json -count=1 -run <pattern> <package>`, inside a log group named "Expected failures of the listed tests in P".
- Each entry is judged by **its own verdict**, not by its parent's. `fail`: the line `still fails: P T`. `pass`, `skip` or no verdict: an error line that names the entry and says "it passes", "it skips itself" or "it did not run", and what to do: delete its line from the list file, or correct it.
- A listed test that panics or exits stops the test binary, and the entries after it report nothing. Each entry without a verdict is therefore run again on its own before it is judged. An entry that starts, reports no verdict and takes the go command down with it counts as failing.
- A package in which no listed test starts (for example a build failure) fails the step without naming entries.
- Exit 0 only if every entry fails. The last line is then `all N listed tests still fail on this host`.

Exit statuses are unchanged: 0 success, 1 a Go command or a check failed, 2 the list or the command line is wrong, and no test has run when the status is 2.

**Why two modes and not one.** The gating run must not run the listed tests, and the trigger must run only them. They are different `go test` invocations in any design. As two steps, the Actions page shows which of the two is red. `gate` also stays meaningful on any host, while `still-failing` is about one host: the runner. In this cloud container three listed tests pass, because it has no `systemctl`, no modprobe block and other tools. The runner decides the list.

### 4.3 The self-check: `.github/ci/go_test_gate_selftest.py`

56 checks in six groups. It still builds throwaway modules and observes what ran through marker files, not through go test output.

| Group | Checks | What it holds |
|---|---|---|
| GateScopesEachEntryToItsPackage | 16 | An entry reaches only its package. Packages with the same last path element keep their own entries (N35). A failed `go list` and a failed `go test -list` fail the gate. Any exit status other than 0 fails. Every run executes the tests again (N26) |
| GateSkipsExactlyTheListedSubtest | 11 | Siblings of a listed subtest run. A failing sibling fails the gate. A whole-test entry would hide that failure (shown as contrast). Nested subtests, `#01` names, look-alike names, an entry for a subtest that does not exist |
| GateChecksWhatReallyRan | 2 | A listed package whose test binary runs nothing fails the gate. The top-level test of a listed subtest has to run |
| GateRefusesAListItCannotTakeLiterally | 9 | The grammar, including every printable ASCII character outside the plain sets in each of the three places of an entry. Unknown packages and package prefixes. Undefined tests. The internal-plus-external double definition (RF-1), in both modes and also when another package is listed first. Repeats and overlaps |
| ListedTestsMustStillFail | 15 | A passing, a self-skipping and a failing listed test (acceptance check 2). Subtests judged by their own verdict. A test that panics or exits does not hide the next entry. Nothing started. Every run really runs the tests |
| WorkflowKeepsWhatTheGateDependsOn | 3 | Reads `../workflows/go.yml`: every `uses:` is pinned to a 40-hex SHA with a version comment; the three gate commands are present, in order, with no `continue-on-error:` and no `if:` anywhere; the only `cache:` line is `cache: false` |

Every refusal is now checked for its **reason**, not only for status 2. Four checks use a stand-in `go` command that runs the real one and changes only an exit status. They hold defensive conditions that the real `go` command does not trigger in a sound module: a `go list` that prints packages and fails, a failing `go test -list`, a `go test` that ends with status 3, and a `go test` that reports success although a test stopped the binary.

Note for the auditor: the self-check needs the workflow file beside it. A mutant harness must copy the whole `.github/` tree, not only `.github/ci`.

### 4.4 The workflow: `.github/workflows/go.yml`

- `actions/setup-go` now has `cache: false`, and `cache-dependency-path` is gone. Every run downloads the modules that `go mod verify` then checks, and compiles everything from source.
- The last three steps are "Check the test gate" (the self-check), "Test" (`gate`), and "Listed tests still fail" (`still-failing`). All three are blocking. The step with `continue-on-error: true` is gone.
- Nothing else changed: triggers, permissions, concurrency, pins, `GOTOOLCHAIN=local`, `GOFLAGS=-mod=readonly`.

### 4.5 Docs: `.docs/system_overview/go_toolchain_baseline.md` and `docs_contract_test.go`

- New section "10. Continuous Integration", three short paragraphs: what the workflow runs; that the list file is the single statement of what the test step excludes and that a second blocking step keeps it honest; and what a green run is not (not design authority, not a macOS run, not a race-detector run, not a Linux runtime proof, a Remote Alpha proof or a supported-local proof).
- "Explicit Non-Claims" is now section 11. Its line "no CI system introduced" had become false with this PR. It now reads "no CI claim beyond section 10".
- `TestGo1265ToolchainBaselineDocsAndBuildContract` holds 13 phrases of the new section, forbids the old sentence, holds 15 lines of the workflow file (triggers, runner, toolchain variables, `cache: false`, the seven `run:` commands) and requires the three files under `.github/ci` to be non-empty. So the doc and the workflow cannot drift apart silently.
- `PLANS.md` is unchanged. CI changes no redesign scope, seam status or sequencing.

### 4.6 Build cache (RF-6)

Decided: no cache. The priority rule is correctness over speed, and nothing verified a restored build cache. Cost on the runner: the job took 8 m 24 s at `c4a84f5` without a cache, against 5 m 47 s at `fada999` with it.

### 4.7 The SPIRE test port (section 7, item 4)

The re-audit left this to the writer and recommended doing it now. I did, because the project rule prefers the proper fix now, the change is one line, and the Mac run that it needs is required anyway (RF-4).

- `remote_alpha_operator_test.go` line 4022, inside the test's own fake `sudo`: `stat -c '%a' … 2>/dev/null || stat -f '%Lp' …` instead of the reverse order. GNU `stat -f` means "file system status". It printed a block of file system details and failed, so the saved directory mode was garbage. BSD `stat` rejects `-c`, prints nothing on standard output and falls through to the form that it understands.
- `TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSpireBundleReadClassifiesTraversalAmbiguityWithSudoVisibleInspection` now passes on Linux, in this container and on the runner (7.5).
- Its entry and comment are deleted from the list, in the same change, as the new rule demands.
- No other branch touches this file (checked against the heads of PR #12 and PR #13).
- **Not yet shown:** that the test still passes on macOS. Inference from reading BSD `stat` behavior: it does. The Mac run in section 7.6 includes it. If it fails there, the port comes out again and the entry goes back in.

## 5. Every re-audit finding and what happened to it

| ID | Finding | Disposition | Where |
|---|---|---|---|
| RF-1 | One entry skips a name defined in the internal and the external test package | **Fixed.** Count must be exactly 1, else status 2. Self-check `test_name_defined_in_the_internal_and_the_external_test_package`. Probe B1 exits 2 | 4.2, 7.3 |
| RF-2 | No enforced trigger removes an entry; the non-blocking step is red on every run | **Fixed.** Blocking step "Listed tests still fail". The always-red step is gone | 4.2, 4.4, 7.5 |
| RF-3 | Six passing `es/app` subtests are outside the gate | **Fixed.** Subtest entries. Both entries narrowed. The gate log names the siblings that ran | 4.1, 4.2, 7.5 |
| RF-4 | The two changed tests have not run on macOS | **Open, no byte change.** Requested through a session on David's Mac. Waits for his approval. Required before merge | 7.6 |
| RF-5 | Self-check misses N35, N26, N24 | **Fixed.** All three are killed (my S9, S10 to S12, C9), with every other mutant I built | 7.2 |
| RF-6 | Unverified build cache | **Fixed.** `cache: false` | 4.4, 4.6 |
| RF-7 | CI is not in the governing docs | **Fixed.** Baseline doc section 10 and the docs contract test | 4.5 |
| RF-8 | Nits: raw U+00A0 in the self-check; workflow properties unchecked | **Fixed.** Escapes; the file is pure ASCII now. The self-check reads the workflow | 4.3 |

The six deferred items of section 7 of the re-audit:

| # | Item | Result |
|---|---|---|
| 1 | Check that listed tests still fail | Done (RF-2) |
| 2 | Subtest-level skips | Done (RF-3). The two root custody entries stay whole, with the reason written in the list |
| 3 | A signal from the non-blocking step | Done with item 1. No step in a green run ends with an error |
| 4 | Port the SPIRE test | Done in this repair (4.7). Mac confirmation pending with RF-4 |
| 5 | Verify or drop the build cache | Dropped (RF-6) |
| 6 | Record CI in the governing docs | Done (RF-7) |

Nothing is left as "later". What remains open is listed in section 11, and each item there is either David's decision or a check that needs his Mac.

## 6. Files touched (cumulative, against base `ae326b0`)

| Path | Kind | Changed by this repair | Summary |
|---|---|---|---|
| `.github/workflows/go.yml` | new | yes | `cache: false`; the blocking step "Listed tests still fail" replaces the non-blocking step |
| `.github/ci/environment-only-tests.txt` | new | yes | Test-path format; the rule instead of the TODO; two entries narrowed to a subtest; SPIRE entry deleted; 15 entries |
| `.github/ci/go_test_gate.py` | new | yes | Rewritten: count check, subtest entries, overlap rule, check of what ran, mode `still-failing` |
| `.github/ci/go_test_gate_selftest.py` | new | yes | Rewritten: 56 checks |
| `.docs/system_overview/go_toolchain_baseline.md` | modified | yes | Section 10 "Continuous Integration"; non-claims renumbered and corrected |
| `docs_contract_test.go` | modified | yes | Holds the new section and the workflow's key lines |
| `remote_alpha_operator_test.go` | modified | yes | One line: GNU `stat` before BSD `stat` in the SPIRE test's fake sudo |
| `es/admission/internal/reliablesubmit/replay_custody_file_test.go` | modified | no | As audited at `fada999` |
| `es/admission/result_auth_test.go` | modified | no | As audited at `fada999` |

Dependencies changed: none. `go.mod` and `go.sum` are untouched.

## 7. Validation

Where: a cloud container, linux/amd64, 4 CPUs, Go 1.26.5 with `GOTOOLCHAIN=local` and `GOFLAGS=-mod=readonly`, an unprivileged user, umask 022, the locale and tools that the root package needs, and `/usr/bin/go` pointing at another Go version, as on the runner image. The GitHub runner is the authority (7.5). The scripts that set this up are in the evidence folder (`container-*.txt`).

All runs in 7.1 to 7.4 used a scratch copy whose git tree is `a05a25a6db5fe1d51819f16a28a9f18132667ccf`, the committed tree. The scratch copy is never pushed.

### 7.1 Build, vet, self-check

| Command | Result |
|---|---|
| `go mod verify` | `all modules verified` |
| `go build ./...` | exit 0 |
| `go vet ./...` | exit 0 |
| `gofmt -l docs_contract_test.go remote_alpha_operator_test.go` | no output |
| `git diff --check ae326b0..c4a84f5` (and `ae326b0..0a069ec` for PR #16) | exit 0, no output |
| `python3 -I -B .github/ci/go_test_gate_selftest.py` | `Ran 56 tests`, `OK`. About 50 to 75 s here, 45 s on the runner |

### 7.2 Mutants: can the self-check tell a broken gate from a working one

`mutants.py` in the evidence folder holds 75 deliberate breakages of the gate and one control. Each runs the whole committed self-check in a copy of `.github/`. A mutant survives when the self-check still passes.

**First run, against the self-check as I had first written it (50 checks):** 58 of 72 killed, 14 survived. I did not argue any survivor away as "equivalent". Each one got a check that kills it:

| Survivor | What it breaks | Check that now kills it |
|---|---|---|
| R2, R4, R5 | `.` or `*` allowed in a test or subtest name | Every character outside the plain sets, in each place of an entry |
| S7 | Only exit status 1 of `go test` counts as failure | `test_go_test_that_ends_with_a_status_other_than_1_fails_the_gate` |
| C1 | The "not defined" refusal is dropped (the count rule still refused, with another reason) | Every refusal is checked for its reason |
| C5 | Definitions are checked for the first listed package only | The undefined and the double-defined case with another package listed first |
| C6, C7 | The package check accepts a pattern, or a prefix of a package path | Reasons checked; `synth`, `synth/`, `syn` added |
| C11 | A failed `go list` is not an error | Stand-in `go list` that prints the packages and fails |
| C12 | A failed `go test -list` is not recorded | Stand-in `go test -list` that fails |
| C17 | A subtest entry exempts its whole test from "did not run" | `test_parent_of_a_listed_subtest_is_a_test_that_has_to_run` |
| F10 | An entry that started counts as failing even if `go test` succeeded | `test_listed_test_without_a_verdict_fails_only_if_go_test_failed` |
| F12 | A package where nothing started is not a failure | `test_package_whose_listed_tests_do_not_start_fails_without_naming_entries` |
| F13 | `-count=1` removed from the still-failing runs | `test_every_run_executes_the_listed_tests_again` |

I had expected F13 to be equivalent, because failures are never stored. It is not: a stored *pass* would be replayed, and the entry would be called stale by a test that did not run.

**Final run, against the committed self-check (56 checks):** **75 of 75 killed.** The control (the unmodified gate) passes all 56 checks. The 75 are the 72 of the first run plus three that I added while closing the survivors: S13 (only exit status 1 counts as failure for the packages without entries), F15 (a failed `go test -list` is not recorded by the still-failing step) and F16 (the refusal of an undefined test gives another reason). By group: 21 in reading the list, 6 in building the skip pattern, 13 in the gating runs, 17 in the checks, 2 in the log output, 16 in `still-failing`. The run used the committed tree (`a05a25a6…`), four mutants at a time, from 07:06 to 07:38. Every mutant asserts that the text it replaces is present, so none can be a silent no-op. Output: `mutants-output.txt`. The first run and the rerun of its survivors are kept as `mutants-first-run-output.txt` and `mutants-first-run-survivors-rerun-output.txt`.

The three mutants the re-audit named:

| Re-audit | Mine | Result |
|---|---|---|
| N35 package basename scoping | S9 | killed by `test_packages_with_the_same_last_path_element_keep_their_own_entries` |
| N26 `-count=1` removed | S10, S11, S12, F13 | killed by `test_every_run_executes_the_tests_again` and `test_every_run_executes_the_listed_tests_again` |
| N24 failed `go list` exits 0 | C9, C11 | killed by `test_failed_go_list_fails_the_gate` |

Limits: the mutants are mine, written against my own gate. A fresh auditor should add their own.

### 7.3 Red-team probes

I ran the re-audit's `redteam.py` **unchanged** (byte-identical to `04-reaudit-evidence/redteam.py.txt`) against the new gate, and an adapted copy (`redteam_adapted.py.txt`) whose G group calls the new mode.

| Probe | At `fada999` | Now | Note |
|---|---|---|---|
| B1 internal plus external double definition | 0 | **2** | Refused with the "defined 2 times" reason. Nothing runs |
| G1 double definition, old mode | 1 | 2 with the unchanged script, because the mode `environment-only` no longer exists | Adapted G1′ in `still-failing`: **2**, refused, nothing runs |
| G2 listed test that passes, old mode | 1, with no entry named | 2 with the unchanged script, for the same reason | Adapted G2′ in `still-failing`: **1**, and it names only the passing entry |
| G3 gate with a listed test that now passes | 0 | **0 in mode `gate`, by design** | The same module and list in the blocking step (G3′): **1**, and it names the entry |
| C1 entry names no test; `TestMain` prints the name | 0 | 0 in mode `gate` (the entry skips nothing) | C1′ in `still-failing`: **1**, "it did not run" |
| G4′ listed test that skips itself; G5′ entry for a subtest that does not exist | not possible | **1** each | New, `still-failing` |
| G6′ every entry fails (a whole test and a subtest) | not possible | 0 | New, `still-failing` |
| H1′ regressed sibling of a listed subtest | not possible | **1** | New, `gate` |
| H2′ siblings run, gate passes | not possible | 0 | New, `gate` |
| A1, B2, C2, C3, D1 to D4, E1 to E22, F1 to F3 | as the re-audit recorded | same exit status, all 33 | Unchanged script |

Of the 38 probes of the unchanged script, 35 end with the same exit status as in the re-audit's own output. The three that differ are B1 (0, now 2) and G1 and G2 (1, now 2). I compared the two outputs probe by probe. Outputs: `redteam-original-output.txt` and `redteam-adapted-output.txt`. The unchanged script is `04-reaudit-evidence/redteam.py.txt`, SHA-256 `7ad071a7ef4968c1ea19077adb1a7686f0ecce1cd4e396b88bda4c4ec6400208`.

**About acceptance check 2 and probe G3.** The check says "probes G2 and G3 exit non-zero". G3 as written calls mode `gate`, and that mode alone still exits 0 when a listed test has started to pass. The job as a whole does not: the next step, which is blocking, exits 1 and names the entry. I kept two commands for the reasons in 4.2. If the auditor reads the check as "the command `gate` itself must fail", that is a design difference to judge, and the alternative is one command that does both runs. I see no gain in correctness from that, and the self-check and the docs test both hold that the workflow keeps all three steps blocking and in order.

### 7.4 The whole gate on the real tree, in the container

| Command | Result |
|---|---|
| `python3 -I -B .github/ci/go_test_gate.py gate "$ENVIRONMENT_ONLY_TESTS"` | exit 0 in 358 s. `test gate passed: 41 packages, 3 of them with skipped entries (15 entries)`. Root package 178 s, `es/app` 113 s, `reliablesubmit` 27 s |
| `… still-failing "$ENVIRONMENT_ONLY_TESTS"` | **exit 1 in 8 s, as expected in this container.** 12 entries "still fail". Exactly 3 are named as passing: the three `TestRemoteAlphaRuntimeSecurityBoundary…` tests |

The gate log holds these two lines (shortened here; complete in `container-gate.log`):

```text
execution-substrate/es/app: TestSupportedLocalSetupExactGoPreflightBeforeMutation ran without its listed subtest local_build_path_rejects_missing_Go_before_mutation; its other subtests: local_build_path_accepts_exact_Go_at_bounded_sentinel pass, local_build_path_rejects_wrong_Go_before_mutation pass, prebuilt_… pass
execution-substrate/es/app: TestSupportedLocalProofExactGoPreflightBeforeMutation ran without its listed subtest local_build_path_rejects_missing_Go_before_mutation; its other subtests: local_build_path_accepts_exact_Go_at_bounded_sentinel pass, local_build_path_rejects_wrong_Go_before_mutation pass, prebuilt_… pass
```

The three entries that pass here are the container's doing, not the list's: this container has no `systemctl` in `/usr/bin` or `/bin` and no modprobe configuration that blocks `algif_aead`. The run shows the step doing its job: it named exactly the entries that do not fail on that host, and nothing else.

An earlier run of the same two commands used a scratch copy whose throwaway commit lacked two tracked tarballs (`.gitignore` names their `dist/` directories). The files on disk were identical (`diff -r` clean), but the tree hash was not the committed one, so I corrected the copy and ran both commands again. The table shows the second run. The first gave the same results.

### 7.5 On the GitHub runner (authoritative)

Run [44996283604](https://github.com/evo-agi/Execution-Substrate/actions/runs/44996283604), job 137127901877, event `pull_request`, head `c4a84f5695500cca2087abefb8027afd700f35e2`. Runner image `ubuntu-24.04`, release `20261116.376`. Started 07:01:02, completed 07:09:26, conclusion **success**. The complete log (651 lines) is in the evidence folder as `runner-run-44996283604-job-137127901877.log`. I read it directly.

| Step | Result | Time |
|---|---|---|
| Set up Go from go.mod | success. `cache: false`. Go 1.26.5 installed | 8 s |
| Download modules | success | 3 s |
| Verify module downloads | success | 1 s |
| Build | success | 31 s |
| Vet | success | 12 s |
| Check the test gate | success. `Ran 56 tests in 45.195s`, `OK` | 45 s |
| Test | success. `test gate passed: 41 packages, 3 of them with skipped entries (15 entries)` | 6 m 26 s |
| Listed tests still fail | success. 15 lines `still fails: …`, then `all 15 listed tests still fail on this host` | 12 s |

Against the acceptance checks of the re-audit:

- **Check 2, no error annotation in a green run:** the log holds no `##[error]` line at all (`grep -c` gives 0). The run at `fada999` held one, from the step that was allowed to fail. The log holds one `##[warning]`: Node.js 20 is deprecated for both pinned actions, and the runner ran them on Node.js 24.
- **Check 2, every entry fails on the runner:** all 15 do, each with its own `still fails:` line, the two `es/app` subtests included.
- **Check 3, the siblings ran in the gating step:** the log of the step "Test" holds, at 07:06:40:

```text
execution-substrate/es/app: TestSupportedLocalSetupExactGoPreflightBeforeMutation ran without its listed subtest local_build_path_rejects_missing_Go_before_mutation; its other subtests: local_build_path_accepts_exact_Go_at_bounded_sentinel pass, local_build_path_rejects_wrong_Go_before_mutation pass, prebuilt_… pass
execution-substrate/es/app: TestSupportedLocalProofExactGoPreflightBeforeMutation ran without its listed subtest local_build_path_rejects_missing_Go_before_mutation; its other subtests: local_build_path_accepts_exact_Go_at_bounded_sentinel pass, local_build_path_rejects_wrong_Go_before_mutation pass, prebuilt_… pass
```

  (The third sibling's name is shortened here. It is complete in the log.)
- **All 21 packages that have tests report `ok`.** Root package 133 s, `es/app` 91 s, `reliablesubmit` 25 s, `es/admission` 109 s.
- **No cache was restored.** The setup step shows `cache: false`, and the log holds no cache restore line. The line "Successfully cached go to /opt/hostedtoolcache" is the action installing Go on the runner's disk.
- **The ported SPIRE test ran in the gating step,** because it is no longer an entry. The gate does not print passing tests. That it passed is an inference from four facts: the root package is `ok`; the gate requires a verdict from every test that is not an entry; the test's only self-skip is for a root user, and the runner user is not root; and in the run at `fada999` the same test failed there instead of skipping.

Limits: this is one run. The runner is green on these bytes once. Tests that depend on timing can differ from run to run (PR #16 removes one proven case; that test is still the old one on this branch).

### 7.6 On David's Mac (RF-4): requested, not done

A session on the Mac is requested with these instructions. It waits for David's approval on the Mac. It works in a temporary clone under `/Users/ds/Repositories/Playground`, touches no existing folder, pushes nothing and removes the clone at the end.

At PR #14's head `c4a84f5`:

```bash
go test -count=1 -v -run 'TestReplayExistingStateModeNotRepaired|TestRetainedResultAuthReaderNeedsVerifierEvenForExistingPair' ./es/admission/...
go test -count=1 -v -run '^TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSpireBundleReadClassifiesTraversalAmbiguityWithSudoVisibleInspection$' .
go test -count=1 -v -run '^TestGo1265ToolchainBaselineDocsAndBuildContract$' .
python3 -I -B .github/ci/go_test_gate_selftest.py
```

At PR #16's head `0a069ec`:

```bash
go test -count=20 -run '^TestSQLiteClaimStoreTwoHandlesBusyTimeoutAndHelperProcessContention$' ./es/admission/internal/reliablesubmit
go test -count=1 -v -run 'TestSQLiteClaimStore' ./es/admission/internal/reliablesubmit
```

The first command is the one the re-audit requires. The second covers the SPIRE port. When the output arrives I will add it to this folder as `06-mac-run.md`. It changes no bytes, so it does not move the audit target.

### 7.7 Failed or skipped validation

- **Skipped, needs David:** the Mac run (7.6). Nothing in this report is a macOS result.
- **Failed as expected, not a defect:** `still-failing` exits 1 in the cloud container, because three listed tests pass there (7.4). On the runner it exits 0.
- **Not run:** the race detector, and any second runner run of the same bytes. PR #16 has no runner run at all (section 8).
- **Failed and fixed during the work, all before the commit:** the 14 surviving mutants of the first run (7.2), the first SIGKILL check of the lock test (section 8), and the scratch copy with the wrong tree hash (7.4). No test was weakened, skipped or removed to get a pass. The one entry that left the list left it because its test was fixed.

## 8. The lock-timing test (PR #16)

**Choice:** its own branch `claude/project-thread-k69qcw` and its own draft PR to `trunk_dev`, https://github.com/evo-agi/Execution-Substrate/pull/16. It does not belong in PR #14: it is a different concern (a test of the reliable-submit store, not CI), the defect is on `trunk_dev` whether or not CI exists, and keeping it apart keeps PR #14's audit target small.

**The defect** (re-audit section 9): `TestSQLiteClaimStoreTwoHandlesBusyTimeoutAndHelperProcessContention` starts a helper process that takes the SQLite write lock for a fixed 300 ms. If the test process stalls for about that long after it reads `locked`, the lock is gone, the contended write succeeds and the test fails with `busy contention error = <nil>`.

**The fix** (`es/admission/internal/reliablesubmit/sqlite_physical_test.go`, +24/−3, test only):

- The helper holds the lock until its standard input closes (`io.Copy(io.Discard, os.Stdin)`). The test closes that pipe after its write was refused. The lock cannot end on its own.
- If the test process dies first, the pipe closes with it and the helper ends.
- The test reaps the helper on every failure path. Two of them killed it without waiting for it.
- What the test asserts is unchanged.

**Evidence** (`lock-output.txt`, scripts `lock_*.sh.txt`). `trunk_dev` does not compile this test package on Linux, so the runs used a scratch copy of `trunk_dev` plus the one compile fix from PR #14.

| Run | Changed test | Unchanged test |
|---|---|---|
| Test process stalled with SIGSTOP, 600 ms stopped and 60 ms running, 20 runs. This is the re-audit's acceptance check | **20 of 20 pass** | 4 of 20 pass; 16 fail with `busy contention error = <nil>` |
| Stalled 2000 ms and 30 ms, 10 runs | 10 of 10 pass | not run |
| No stalls | 100 of 100 pass | 20 of 20 pass |
| Test process killed with SIGKILL while the helper holds the lock, 10 rounds | the helper exits within 100 ms every time; none left running | not applicable |
| Whole package twice, the two historical-opener probes skipped as the gate skips them | `ok` | not run |

`gofmt -l` and `go vet` are clean for the package.

A first version of the SIGKILL check reported the helper as "still alive". That was the check's mistake: `kill -0` also succeeds for a process that has exited and waits to be reaped. The check now reads the process state. I rebuilt the output file with the corrected check.

**Limits:** PR #16 gets no CI run, because `trunk_dev` has no workflow until PR #14 merges. One Mac run is requested with the same session (7.6). This fix does not explain the one unexplained failure in 22 runs that the earlier writer saw. It removes the one proven cause. PR #12 and PR #13 touch the same file at other lines (around line 130); no conflict is expected.

## 9. Authority, security and protocol widening; hygiene

- **Authority, security, protocol:** no widening. The workflow keeps `permissions: contents: read`, no secrets, no credentials persisted, actions pinned to full SHAs. The new step runs repository tests that the old non-blocking step already ran. The gate passes list text to `go test` only after the strict grammar check, as arguments, never through a shell.
- **Cross-repo impact:** none.
- **Dependencies:** none changed.
- **Artifact hygiene:** the working tree was clean after the commit. All scratch copies, logs and manifests were outside the repository. Nothing in the repository was created by validation.
- **Remote state touched:** two fast-forward pushes to `claude/*` branches, one PR body update, one new draft PR. No force-push, no branch or tag deleted, nothing merged.

**A choice to state plainly:** I pushed the repair to `claude/project-thread-sqldt7-ci`, the branch another thread created for PR #14. The coordinator handed me the writer role for exactly that branch, the protocol says a repair stays on the same topic branch, and the earlier writer was told to stop touching it. The push was a fast-forward.

## 10. Follow-up this creates for PR #12 and PR #13

Unchanged in substance from `03-repair.md` section 9, with one addition. When PR #12 picks up `trunk_dev` after PR #14 merges, it adds this line to the list:

```text
execution-substrate/es/admission/internal/reliablesubmit TestOperationalHandoffSchema4BinaryRefusesSchema5
```

**New:** that test must then also *fail* on the runner, or the step "Listed tests still fail" turns red and names it. The re-audit's scratch merge suggests it does fail there, as the two other historical-opener probes do. Unknown until the first run.

## 11. Assumptions, unresolved seams, uninspected areas

- **Mac run (RF-4):** not done. Needs David's approval on the Mac.
- **The SPIRE port on macOS:** Inference, not yet a run.
- **Whether the check is a required status check on `trunk_dev`:** Unknown, as before. I cannot read branch protection.
- **Nothing forces the ports themselves to happen.** The new step forces a ported test out of the list. It does not make anyone port. This is David's, as the re-audit said.
- **Eight root entries pass on Linux with an account named `ds` and a `/private/tmp` directory**, which a workflow could arrange. Not done here: it is a design choice about what the runner pretends to be, and it is David's.
- **The runner image warned that Node.js 20 is deprecated** for both pinned actions and ran them on Node.js 24. Seen in both runner logs I read (44984626477 at `fada999` and 44996283604 at `c4a84f5`). Nothing fails today. A later pin update will be needed when the actions publish releases for the newer runtime.
- **Subtest names with characters outside letters, digits, `_` and `-`** cannot be listed. No current entry needs one. A test that needs it would have to rename the subtest or be listed whole.
- **`go test -list` can be fooled by a line that `TestMain` prints** (probe C1). In mode `gate` such an entry skips nothing. In mode `still-failing` it "did not run" and the step fails.
- **Uninspected:** the Remote Alpha scripts beyond the lines cited; macOS behavior of anything; the race detector.

## 12. For the next audit

- Target: section 2. Reproduce the cumulative manifest first.
- Re-run `redteam.py` from the re-audit (B1 must be 2) and `redteam_adapted.py.txt`.
- Re-run `mutants.py.txt` with the whole `.github/` tree copied per mutant. Add mutants of your own.
- Read the runner log of the run named in 7.5 for: the 56 self-check lines, the two "ran without its listed subtest" lines, 15 "still fails" lines, and the absence of error annotations.
- Judge the two-step design against acceptance check 2 (7.3).
- Judge whether the SPIRE port belongs in this PR, and whether its Mac run (pending) is needed before or after your verdict.
- PR #16 is a separate, small target. It could be audited with this one or on its own.

## 13. Confidence

| | Level | Why |
|---|---|---|
| Provenance | 0.97 | Manifests taken twice and reproduced from GitHub in a fresh clone. The staged set equals the manifest set. Clean status after one commit |
| Validation | 0.9 | The runner is green on the committed bytes, and its log holds every line the acceptance checks ask for. The self-check, all 75 mutants, both probe scripts and the whole gate ran in the container on the committed tree. Missing: any macOS run, and a second runner run of the same bytes |
| Implementation | 0.85 | The gate is small and every branch I could think of is held by a check that a mutant proves. Remaining risk: `go test` behavior I did not think to test, and the reading of acceptance check 2 |

## 14. Provenance detail

Recipe `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified before each run. Each manifest was written twice into a fresh mode-0700 directory outside the repository and compared with `cmp`.

Sequence for PR #14 (provenance §5.5):

1. HEAD at `fada999`, repair in the working tree, nothing staged, upstream pinned to `origin/trunk_dev`: repair-only manifest, twice, identical.
2. `git reset --mixed ae326b0…`, upstream pinned: cumulative manifest, twice, identical.
3. `git reset --mixed fada999…`, `git add -A`. The staged path set equals the path set of the repair-only manifest (7 paths, compared with `cmp`).
4. One commit, `c4a84f5…`. `git status --porcelain` empty. `git rev-parse HEAD^{tree}` is `a05a25a6…`, the tree that validation ran on.
5. `git push`: `fada999..c4a84f5`, fast-forward.
6. Fresh clone from GitHub, provenance §5.3: byte-identical to the cumulative manifest.

**Cumulative manifest, complete** (SHA-256 `cf8c159ff17baff1096fe7d8c41fa86ebd8ba97bd1e7e635fb057d64860908f7`; also `05-repair-evidence/manifest-cumulative.json`):

```json
{"branch":"claude/project-thread-sqldt7-ci","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/system_overview/go_toolchain_baseline.md","sha256":"1bb205157b5b5b0d2b538f7620f5fd9b9a2c64b092209ee0f1afb28580441189","size":5567},{"file_type":"regular","kind":"untracked","mode":"0644","path":".github/ci/environment-only-tests.txt","sha256":"dffba480e9ea4b79fb668779b6f00f180c3d73050dfb58a10871df97adec552b","size":4189},{"file_type":"regular","kind":"untracked","mode":"0644","path":".github/ci/go_test_gate.py","sha256":"5eb758fc628ed31af3964f7248839986318c4a3e5720657fe62d7f55332a4154","size":16124},{"file_type":"regular","kind":"untracked","mode":"0644","path":".github/ci/go_test_gate_selftest.py","sha256":"50fd43b951f92808c6e1185c819b1d1c1742b62d0ca1e152864167166763ce6f","size":42096},{"file_type":"regular","kind":"untracked","mode":"0644","path":".github/workflows/go.yml","sha256":"e6196683d2eb5899a3d6abd27894039b9f0fa09ddc7fbaaf39859238ca732b36","size":3149},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"b405b5c0c7be89390abcfd109406698edff23266dc94944955c5af924da136de","size":802262},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_file_test.go","sha256":"0cec866cf2e659c58a90eeb46f3edf75d9743db21c0c87aaad65d72462c3a2d9","size":70129},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/result_auth_test.go","sha256":"adab4be23f1d1f74bbc6bccd3e49235d8e95e0b5c6e2c4121930578c0e72f87c","size":18293},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"remote_alpha_operator_test.go","sha256":"efa79af1ac61541a9ba92a20ea3ef1b7cff2bcfa7eb587cc723efe1eee15d59a","size":279122}],"head":"ae326b0ddc30ec6b35883ee32945c622405b68b6","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"f384ac8faa1c2456a436da2ff3b79efc3a4d28f8db722815b5b7458074915a6a","upstream":"origin/trunk_dev"}
```

**Repair-only manifest, complete** (SHA-256 `e33d929eb1b19208941b7fabd1966c9a813720013ddc79c77a0be41063ef381b`; also `manifest-repair-only.json`):

```json
{"branch":"claude/project-thread-sqldt7-ci","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/system_overview/go_toolchain_baseline.md","sha256":"1bb205157b5b5b0d2b538f7620f5fd9b9a2c64b092209ee0f1afb28580441189","size":5567},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".github/ci/environment-only-tests.txt","sha256":"dffba480e9ea4b79fb668779b6f00f180c3d73050dfb58a10871df97adec552b","size":4189},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".github/ci/go_test_gate.py","sha256":"5eb758fc628ed31af3964f7248839986318c4a3e5720657fe62d7f55332a4154","size":16124},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".github/ci/go_test_gate_selftest.py","sha256":"50fd43b951f92808c6e1185c819b1d1c1742b62d0ca1e152864167166763ce6f","size":42096},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".github/workflows/go.yml","sha256":"e6196683d2eb5899a3d6abd27894039b9f0fa09ddc7fbaaf39859238ca732b36","size":3149},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"b405b5c0c7be89390abcfd109406698edff23266dc94944955c5af924da136de","size":802262},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"remote_alpha_operator_test.go","sha256":"efa79af1ac61541a9ba92a20ea3ef1b7cff2bcfa7eb587cc723efe1eee15d59a","size":279122}],"head":"fada999c6da5ed157c74033e1e975415c179c49d","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"7f5180340a5d818d9ac4114b4fed9a1cc94bc31940d1697a307dcd9054a4968d","upstream":"origin/trunk_dev"}
```

**PR #16 manifest, complete** (SHA-256 `b14b8ac19ba92beb3a218df837cd8315ea959fc0544d57f170aa12fbe0c936a2`; also `manifest-lock-test-fix.json`). Taken with HEAD at the base, the change in the working tree, nothing staged, upstream pinned; twice, identical; staged set equals the manifest set; one commit; clean status; reproduced in the fresh clone.

```json
{"branch":"claude/project-thread-k69qcw","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_physical_test.go","sha256":"fbf8f64c9f152e06680ca84d558531bb0d63048abaf12a336babc7df75e8c400","size":15193}],"head":"ae326b0ddc30ec6b35883ee32945c622405b68b6","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"2504375ef8b14da68ac600b1870a049fbb1eb0ff1c03dd3d67fd8cba23c6d467","upstream":"origin/trunk_dev"}
```

## 15. Evidence folder and report delivery

`/mnt/project-files/reports/Execution-Substrate/ci-go-workflow/05-repair-evidence/`:

| File | What it is |
|---|---|
| `README.md` | This list, with the SHA-256 of every file in the folder |
| `runner-run-44996283604-job-137127901877.log` | Complete log of the runner job at `c4a84f5` (7.5) |
| `container-env.sh.txt`, `container-run.py.txt`, `container-sync.sh.txt`, `container-fullgate.sh.txt` | How the container runs were set up and started. `run.py` resets the hang-up, interrupt and quit signals and removes the proxy variables before a run. Some `es/app` tests need both |
| `container-gate.log`, `container-gate-status.txt`, `container-still-failing.log` | The whole gate and the still-failing step on tree `a05a25a6…` in the container (7.4) |
| `mutants.py.txt`, `run_all.sh.txt` | The 75 mutants and the control, and the script that ran them and the probes |
| `mutants-output.txt` | Final mutation run on the committed bytes (7.2) |
| `mutants-first-run-output.txt`, `mutants-first-run-survivors-rerun-output.txt` | First run with its 14 survivors, and the rerun that kills them and the three added mutants |
| `redteam_adapted.py.txt`, `redteam-adapted-output.txt` | The probes adapted to the new mode, and their output (7.3) |
| `redteam-original-output.txt` | Output of the re-audit's unchanged `redteam.py` against the new gate (7.3) |
| `lock_setup.sh.txt`, `lock_stall.sh.txt`, `lock_orphan.sh.txt`, `lock_run.sh.txt`, `lock-output.txt` | Scripts and output for the lock-timing test (section 8) |
| `manifest-cumulative.json`, `manifest-repair-only.json`, `manifest-lock-test-fix.json` | The three manifests, byte for byte |

I searched the folder for tokens, keys, mail addresses and phone numbers before delivery. It holds none.

This report: `/mnt/project-files/reports/Execution-Substrate/ci-go-workflow/05-repair.md`. Its SHA-256 is in the thread reply that delivers it, because a file cannot hold its own hash.
