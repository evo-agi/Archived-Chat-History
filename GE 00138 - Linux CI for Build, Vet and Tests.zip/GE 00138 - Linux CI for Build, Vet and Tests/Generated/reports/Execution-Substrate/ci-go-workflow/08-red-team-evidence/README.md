# Evidence for 08-red-team.md

Red-team pass on Execution-Substrate PR #14 at `b39fa35d444a4bd87a3901287bb6a346577c81b9` (tree `76d9bdc2643bbdce8f057ee2d455f94ec7bca6ae`), 2026-11-22, about 13:06 to 13:45 UTC. Every log here is from a run on those bytes, in a cloud container (linux/amd64, 4 CPUs, Go 1.26.5 with `GOTOOLCHAIN=local` and `GOFLAGS=-mod=readonly`, an unprivileged user `ci` who cannot write to the Go installation).

| File | What it is |
|---|---|
| `manifest-cumulative-reproduced.json` | The cumulative manifest (recipe v2), reproduced from a fresh clone of GitHub. Byte-identical to `07-repair-evidence/manifest-cumulative.json` |
| `container-env.sh.txt`, `container-run.py.txt` | The environment of every run, and the wrapper that resets signals and removes the proxy variables |
| `steps.sh.txt`, `steps-status.txt` | The `run:` lines of the workflow in order, by hand, on the real tree, and their exit statuses and times |
| `real-tree-selfcheck.log`, `real-tree-gate.log`, `real-tree-still-failing.log` | Output of the steps "Check the test gate", "Test" and "Listed tests still fail" on the real tree |
| `census.py.txt`, `census.log` | How every test ended in one `go test -json -count=1 ./...` of the real tree with nothing skipped: counts, the 15 entries, and the 40 tests that skipped themselves with their reasons. The raw JSON (4.7 MB) is not kept here |
| `rt8.py.txt`, `rt8.log` | My 15 probe modules and their output against the committed gate |
| `rt8_lists.py.txt`, `rt8_lists.log` | 50 malformed and tricky list files, each in both modes |
| `go_test_gate_redteam8.py.txt`, `redteam8-checks.log` | The seven failing checks as pushed to `claude/project-thread-0tw2qq` (commit `d2117bb999fd875d16b4a093b30585b7246330b2`), and their run: 7 of 7 fail |
| `darwin-vet.log` | `GOOS=darwin GOARCH=arm64 go vet ./...` on the unchanged tree: exit 0 |
| `darwin-plant.log` | A compile error planted in a macOS-only test file: the Linux vet and test build pass, the macOS type check fails. The plant was removed afterwards (last line: 0 changed files) |

SHA-256 of every file:

```text
cabce141646d3b237cd5cba482f5edb0c4defed1a15dbcf2a715303c201b6de5  census.log
ffdc4a3f1292a25d0a941c1a0b15ddb16db5f6ecf343b04c50112867fffc6a9c  census.py.txt
1150045eb2435bc798412b8a78aef9bbbf3927b96d2d90051eb775b02c519095  container-env.sh.txt
c89d3bfb1b507edcbb50bb15b551698bb23ccd8b384e7a1731f612d28f29c823  container-run.py.txt
af7a78661ab782361c0ab77056901d846208cfbc0be440b03cdcb740ea1eed08  darwin-plant.log
fb524bcbfb5c1cb56ec4e55a99736ca31b4f227f07d85054ab6b5e756ce2bc0d  darwin-vet.log
3a97ba0d79f8a25bafd654d3a6630a5f7a637ec47fba76431748a1dc4f4d21b3  go_test_gate_redteam8.py.txt
a41367f9cd702a23d627ba1670fd64a54ce1f9b7e43bcda380b06d200ae0108e  manifest-cumulative-reproduced.json
0e57e99ccbe4d63cf651a1214095239bd54de9094630f8068704cd793d56d12e  real-tree-gate.log
f1322930beef0af0ea44ba5c1bd5c790638d4785e47c80cc6d36b4bd6e128755  real-tree-selfcheck.log
f5eed122cdde48120e78b092d753cd64f3aeabbadcb3a47d0bbb1d99164608f7  real-tree-still-failing.log
a9762398d79503b3f64c31fe27b0e5be90408d74a04af8e10ee1ed7d1f90bb4b  redteam8-checks.log
fefd4d65569b8b0ff1afe5aa788044c6a976eae68ee2f0851f12802420fa2fce  rt8.log
570c2d0635905ead47ec0f668c2c48851826e37f96787497b9caba58c4186cbe  rt8.py.txt
5756f7ef27479a156e8bd02a1448d583cad60caea973834653f2e05841837aa2  rt8_lists.log
4edb7f7ef92759d8554ab65b5aa4aa9b51377433657d4f03ef06366814dba1a4  rt8_lists.py.txt
3d334a21074ff8119d99967a177d4e8e000537fab1badd8ac5ad2c2ed255b718  steps-status.txt
da3c1f9f103cda546086c49e1edd08526ab46cbb3a8db296156e2b3a3f272286  steps.sh.txt
```
