# INDEPENDENT AUDIT REPORT: Execution-Substrate PR #14 (Linux CI) at `aaef28f`, the repair since `b39fa35`

**Final verdict: ACCEPT**
**Effect status:** REPAIR_NOT_PERFORMED · COMMIT_NOT_PERFORMED · PUSH_NOT_PERFORMED · PR_NOT_MODIFIED · NO_COMMENT_POSTED · MERGE_NOT_PERFORMED · read-only on the target throughout

A fresh thread did this correctness audit. It wrote none of the patch and none of its repairs, and it used no subagents. It is not a red-team pass. Its scope is the two repair commits `76d9a91` and `aaef28f` on top of `b39fa35`, which the fourth audit accepted (`08-audit.md`).

All times are UTC on 2026-11-22.

## 1. Verdict in short

**ACCEPT.** The repair does what the red team and the last audit required. Every earlier finding is closed, and I found no critical, high or medium defect. There is one low finding, in the third step, and it is new with this repair.

- **Every skip on the runner is held to the reviewed list.** The runner log of the head names 39 tests that skipped themselves, and they are exactly the 39 `skips-itself` lines of the list (`cmp` of the two name lists). A skip without a line fails the step, and so does a line whose test no longer skips. I saw both on the real tree in my container, where Docker does not run: the committed list fails the step "Test" and names the one Docker-only test, and with a line for it the step passes with 40 skips (section 5).
- **Each earlier finding, checked on the bytes:** RT8-1, RT8-2, RT8-4 and A8-F1 are closed. RT8-3 is closed as the red team required, with one corner that the fix leaves open, which is finding A9-F1 (section 6).
- **Finding A9-F1 (low, new):** when the run of a whole package is stopped by a test that is not in the list, or by the time limit of `go test`, and one listed test happens to be running at that moment, the third step takes the listed test as the one that stopped the run and counts it as failing there. The step passes, and its last line says that the entry fails in the run of its package, which the run did not show. Five probes reproduce it. It needs a coincidence that the tree does not have today. The doc sentence "so an entry cannot outlive its reason" is wider than the check by this corner (section 7).
- **The self-check on a file system that ignores case:** on such a file system on Linux the one check that failed on David's Mac fails at `76d9a91` and passes at `aaef28f`, and the whole self-check of `aaef28f` passes there (`Ran 117 tests in 316.597s`, `OK`). The limit "Go outside the module cache" is real, stated and held (section 5.3).
- **The four gaps that the writer's mutants showed:** each of the four mutants passes the self-check of `76d9a91` and is killed by the self-check of `aaef28f` (section 5.4).
- **The holds:** `WORKFLOW_SHA256` is the SHA-256 of `go.yml` as committed. `OBSERVED_GO_VERSION` and `MATCH_GO_SHA256` are unchanged in the gate, and the docs contract test still fails when either is changed alone (section 5.5).
- **My reruns on the exact bytes agree with the writer's report:** build, both vet steps, the self-check (117 of 117), both test steps on the real tree, the red team's files, the last audit's files. Of my own 65 mutants 59 are killed, and none of the 6 survivors lets a wrong state pass with a real `go test` (section 10).
- **The runner result is confirmed from GitHub:** run 45046634281 at `aaef28f` is green, on a merge commit whose tree is the audited tree (section 9).

What this verdict does not cover:

- **A run on macOS.** I have no Mac. The two Mac runs are the writer's, with David's approval. My check of the case rule ran on Linux (section 5.3).
- **A red-team pass of the new bytes.** The coordinator asked for a correctness audit only.
- **Three things that are David's to decide and that change no byte here:** whether the check becomes a required status check on `trunk_dev`, whether the runner gets Nomad and Vault, and the open choice about passing subtests under two whole-test entries (O-6 of the red team).

On the project rule against "accept now, revisit later": A9-F1 has no machine trigger. My judgement is that it does not block, and that it should be repaired in this pull request before the merge, with a narrow audit of that change (section 12).

## 2. Audit target

| Field | Value |
|---|---|
| Repository | `evo-agi/Execution-Substrate` |
| Pull request | #14, draft, branch `claude/project-thread-sqldt7-ci` into `trunk_dev` |
| Base SHA | `ae326b0ddc30ec6b35883ee32945c622405b68b6` (`origin/trunk_dev`, the same at opening and at closing) |
| Last audited commit | `b39fa35d444a4bd87a3901287bb6a346577c81b9`, tree `76d9bdc2643bbdce8f057ee2d455f94ec7bca6ae` (`08-audit.md`, ACCEPT) |
| Repair commits | `76d9a91c012b20aaa3a00cec53e34665aca6a18b` (15:36:35) and `aaef28f36f393e78f832a9caa745edeb02565a6c` (16:56:23) |
| Topic commit SHA | `aaef28f36f393e78f832a9caa745edeb02565a6c`, 8 commits above the base |
| Tree SHA | `f00fdd4053565f0d199b3ba013d1388d3f5fa0fd` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified before use) |
| Canonical manifest, repair only (`b39fa35` to `aaef28f`) | SHA-256 `1ccacc66030fc16d1f21b3fb9ca0b4586967f515195b642050e120515e021a0f` (1,448 bytes), 6 paths, textual diff SHA-256 `aff0544899a09f9e255955cd6dfed0f1ac2fe8623cafa87caecfde9dc6decd2a` |
| Canonical manifest, cumulative (base to `aaef28f`) | SHA-256 `774fe3a67db1a0cba962bf9fefd80a12e5ee55f97c42654eb030e656d49020ee` (2,035 bytes), 9 paths, textual diff SHA-256 `39ea9db3ac152ce8ded7bd1dac0af84bf04758e0702515ed3177304006242c37` |
| Canonical manifest, second commit alone (`76d9a91` to `aaef28f`) | SHA-256 `8c620ad3365c758e1fa46f58b12f20a76f237b6f0343eabe52869c1fe37045fc` (873 bytes), 3 paths |
| Changed paths in scope | 6, all modified regular files: +1831/−164 against `b39fa35` |
| Writer's report | `08-repair.md`, SHA-256 `14985c8d404067dd9b3e838d379d362cd8be1b3986e5b69378f8849471bcb9cf` (verified before reading; it is the value in the brief) |
| Red-team report | `08-red-team.md`, SHA-256 `dd8e8205c8878fd9114a93a3a8b33db4cb6d91e018019760ec31d533092e2c4d` |
| Last audit | `08-audit.md`, SHA-256 `86c55c39f3a32b04100f30df8de637dad1dd4b7540869b4f66642f6875317ed7` |

The six paths, with the SHA-256 of each at `aaef28f`:

| Path | SHA-256 | Changed in |
|---|---|---|
| `.github/ci/go_test_gate.py` (1,048 lines) | `e2715daf181f297454bcfd25e54b64d7d533339f900f1aa1e0c0685c583b6c3b` | first commit |
| `.github/ci/go_test_gate_selftest.py` (3,466 lines) | `8031e92747cc220de08359908ee3b320bf70d765a7ec6b7cb2e48493af8709a1` | both |
| `.github/ci/environment-only-tests.txt` (174 lines) | `59c920474a6e5e46631436747c22949e12f2fcd004bddfcb3d604313c1be12e8` | first commit |
| `.github/workflows/go.yml` (106 lines) | `0383a2f066da5490db36abb91f4896c076a7d5cc45410cec11f40b85201db8bf` | first commit |
| `.docs/system_overview/go_toolchain_baseline.md` | `8dafae5db5d9f4bfb700c10c780757f14bc5549f4792ac973fd902efe14dca81` | both |
| `docs_contract_test.go` | `462c01edc5f31bb40534413a9e714710f9caeff1f14d1fb9551ca14e608f8e65` | both |

The first commit is +1627/−151 in six files. The second is +208/−17 in three files: the self-check, the doc and the docs contract test. The gate, the list and the workflow are byte-identical in the two commits.

## 3. Audit posture

- **Read-only.** I edited nothing in the target, committed nothing, pushed nothing, posted no comment or review, re-ran no workflow and merged nothing.
- **One thread, no subagents.** That is a deviation from protocol §13.2 step 3. This thread uses subagents only when they are asked for.
- **Where the work ran.** A cloud container, linux/amd64, 4 CPUs. Go 1.26.5 is the toolchain module that the go command downloads (`golang.org/toolchain@v0.0.1-go1.26.5.linux-amd64`), copied to `/opt/go1.26.5`, which lies outside the module cache and which the test user cannot write. Its `src/testing/match.go` has the held SHA-256 `f284…bebe`: at set-up, after each long job and at closing. `GOTOOLCHAIN=local`, `GOFLAGS=-mod=readonly`, an unprivileged user `ci`, umask 022, and an empty environment without proxy variables or tokens during every run (`env -i`). `/usr/bin/go` is another Go version (1.24.7), as on the runner image.
- **Side effects, all inside the container.** One audit clone that I never modified (`/home/user/audit9/prov`). Scratch clones and copies for the runs, the planted fault, the workflow edits and the mutants, none of them pushed. Throwaway Go modules for probes. One read-only fetch of `refs/pull/14/merge`. One FUSE mount (`ciopfs`, installed with `apt`) for a file system that ignores case, unmounted at the end.
- **Not a red-team.** My probes ask whether the new rules hold and fail closed. I did not try to deceive the gate with hostile test code beyond what the gate's own docstring puts in scope.
- **What I read before forming a view.** The two protocol documents, `08-repair.md`, `08-red-team.md` and `08-audit.md`. My probes and my mutants were written from the code, without reading the writer's mutant file. I read that file afterwards to run parts of it.

## 4. Provenance reproduction

Recipe v2 from `provenance-and-audit-evidence.md`, copied to `/home/user/audit9/v2.py`. Its SHA-256 matched the brief before the first run.

- **Clone and identity.** A fresh clone of `evo-agi/Execution-Substrate`. `origin/trunk_dev` is `ae326b0`, `origin/claude/project-thread-sqldt7-ci` and `refs/pull/14/head` are `aaef28f`, and `aaef28f^{tree}` is `f00fdd40…`.
- **Three manifests, each run twice.** For each I set `HEAD` to the start commit with `git reset --mixed`, left the bytes of `aaef28f` in the working tree, pinned the upstream to `origin/trunk_dev`, ran the recipe twice and compared the outputs with `cmp`. Opening run at 17:31:52.
- **Result.** The two outputs of each manifest are identical. Each is byte-identical to the writer's file in `08-repair-evidence/` (`manifest-repair-only.json`, `manifest-cumulative.json`, `manifest-second-commit.json`).
- **Closing.** At 18:49:08, after the last run, I ran the three manifests again, each twice. Each is byte-identical to its opening output (`manifest-*.open.json`, `manifest-*.close.json`).
- **Mode bits.** All six paths are regular files with mode 0644 on both sides. No mode difference had to be tolerated.

**No provenance mismatch.**

## 5. What the brief asked to check

### 5.1 Every skip on the runner matches the reviewed list of 39

Facts from the job log of run 45046634281 at `aaef28f`, which I read from GitHub myself (section 9):

- The step "Test" printed two groups: `execution-substrate/es/app: 37 tests skipped themselves` and `execution-substrate/es/admission/internal/reliablesubmit: 2 tests skipped themselves`, with 39 lines `skips itself: <package> <test>: <what the test wrote>`.
- I cut the 39 names out of the log and the 39 names out of the `skips-itself` lines of the list at `aaef28f`, sorted both, and compared them with `cmp`: identical (`runner-skips-names.txt`, `list-skips-names.txt`).
- The step ended with `test gate passed: 41 packages, 3 of them with skipped entries (15 entries); 39 tests skipped themselves, all of them listed`.

**The host reason of each line.** The red team's rule O-2 says that every added list line is a finding until its host reason is shown. The repair adds 39 lines and no entry. For each of them the runner log shows the reason, and it matches the comment above the line in the list:

| Lines | Comment in the list | What the tests wrote on the runner | Skip site in the tree |
|---|---|---|---|
| 2, `reliablesubmit` | helper processes that another test starts with a variable set | `allocator helper control, executed by TestPrivateReplaySharedObjectAllocation` and `helper process only` | `replay_custody_file_test.go:1804`, `sqlite_physical_test.go:213`. Each skips unless its variable is set, so they skip on every host |
| 36, `es/app` | integration tests that need a Nomad client backed by Docker; the runner image has no `nomad` | 35 times `nomad binary lookup failed: exec: "nomad": executable file not found in $PATH`, once `slice 0 bringup requires nomad: …` | `submit_integration_test.go:1896-1897` through `requireHealthyDockerBackedNomadClient`, and `operator_scripts_integration_test.go:3803-3804` |
| 1, `es/app` | the test needs the `vault` command | `supported-local setup validation requires vault: exec: "vault": executable file not found in $PATH` | `supported_local_proof_validation_test.go:29` |

So the three groups of comments are true of the runner, line by line. One more fact from the same code: the Nomad helper asks for Docker first, and the messages name `nomad`. So Docker answered on the runner. In my container Docker does not answer, and the one test that needs Docker without Nomad skips here and not there (5.2).

What the 39 lines mean, as the writer says in plain words in section 8 of the report: the `es/app` integration tests of the submit flow do not run in CI. The list now shows it, and the lines have to go when the runner gets what the tests need.

### 5.2 A skip without a line fails, and a line that no longer holds fails

**On the real tree, in my container, on the exact bytes** (tree `f00fdd40…`, `git status --porcelain` empty before and after):

| Run | Step "Test" | Step "Listed tests still fail" |
|---|---|---|
| Committed list (`59c92047…12e8`), 17:41 to 17:53 | **exit 1** after 408 s. One error: `test skips itself and is not listed: execution-substrate/es/app TestWorkloadCanCreateAndUseLocalRuntimeIdentityEndpointFromTmpfsWorkspace (… integration test requires healthy Docker daemon …)`, then `the tests that skipped themselves are not exactly the listed ones` | **exit 1** after 304 s. The three `TestRemoteAlphaRuntimeSecurityBoundary…` entries pass in this container, and each is named twice: `no longer fails on this host (it passes)` and `does not fail in the run of its package (it passes)` |
| Container list (`2e5a80c2…c861`): the committed list without those three entries and with a line for the Docker test, 17:53 to 18:05 | **exit 0** after 422 s: `test gate passed: 41 packages, 3 of them with skipped entries (12 entries); 40 tests skipped themselves, all of them listed`, and `the observed run passed; go test skipped exactly the listed tests of this package (2), each once` | **exit 0** after 295 s: 12 lines `still fails: …` and `all 12 listed tests still fail on this host, each in a run of its own and in the run of its package`. Three package runs, none of them a second time |

I built the container list from what the first run named. It is byte-identical to the writer's `list-container.txt`. So the same rule that passes on the runner fails on a host with another set of skips, names the test and the line to add, and passes when the list says the truth about that host. That is the rule at work in both directions on real tests.

**On throwaway modules** (`aud9_probes.py`, all as expected unless a finding says otherwise):

- A parallel subtest that skips itself without a line fails the step, and passes with its line (S1, S1b).
- A test defined once in the internal and once in the external test package: the skip fails without a line, and a line for the name is refused, because one line would stand for both (S4, S4b).
- A line whose test fails is a failed run (S6).
- A `TestMain` that calls `m.Run` twice, with a skip in the first run only and no line: fails (S8).
- 23 malformed `skips-itself` lines, each in both modes: all 46 runs end with status 2 and with no test run. 44 end before any `go` command, and the two for a package pattern (`synth/...`) after `go list` alone. Among the 23: CR LF, a byte order mark, a no-break space, two spaces, a tab, upper case, a trailing comment, a repeated line, a line and an entry for one test, a line inside an entry, an entry inside a line.

**By mutants** (section 10): of my 17 mutants of the skip rule (K1 to K17) 16 are killed. The survivor, K16, changes only how much a failing run names.

**What the rule does not reach,** each of them outside what the repair claims:

- A test that returns early without `t.Skip` reports `pass` (S5). The rule is about the verdict `skip`.
- A test binary that forges the output of the testing package (C1). The gate's docstring says so.
- A skip that the list cannot name fails the step and cannot be listed: a fuzz target, or a subtest whose name holds a character outside letters, digits, `_` and `-` (S2, S3). The writer states the subtest case. See observation A9-O2 for the fuzz target and the wording of the message.

### 5.3 The self-check on a file system that ignores case, and Go beneath the module cache

**The case rule (M-1).** I cannot run on macOS. I mounted a file system that ignores case on Linux (`ciopfs` over FUSE; a file `CaseProbe` is found as `caseprobe` there) and pointed `TMPDIR` at it, so the self-check builds its throwaway modules and marker files there.

- The check that failed on David's Mac, `GateHoldsEverySkipToTheList.test_names_that_only_resemble_a_line_are_not_covered`, with the self-check of `76d9a91`: **fails**, in the case `TestSKIPS`: the self-check finds one marker file where it expects two (`Ran({'synth/a.TestSkips'})` against both names). The gate's own output in that case was right: it named `TestSKIPS` as not listed and exited 1. That is the failure the Mac run reported (`casefold-one-check.log`).
- The same check with the self-check of `aaef28f`: **passes**.
- The whole self-check of `aaef28f` with `TMPDIR` on that file system: **passes.** `Ran 117 tests in 316.597s`, `OK`, exit 0, from 18:22:39 to 18:27:56. All 117 lines end in `... ok`, and nothing is left in that folder afterwards (`casefold-whole.log`).

The fix is what the report says: `go_test_gate_selftest.py` names each marker file by the import path and the test path in hexadecimal digits, so two names that differ only by case keep two files. I read the change, and the whole self-check passing on that file system shows that no other check depends on the case of a file name. Limit: `ciopfs` is not APFS. It shows the case rule and nothing else about a Mac.

**Go beneath the module cache (M-2).** Probe M2 runs the committed gate with the real Go 1.26.5 and `GOMODCACHE=/opt`, so that the Go root `/opt/go1.26.5` lies beneath it, on a throwaway module with an entry for a subtest:

- Control, module cache elsewhere: exit 0, `the observed run passed`.
- With the Go root beneath the module cache: the first run passes, the observed run prints `go: overlay contains a replacement for /opt/go1.26.5/src/testing/match.go. Files beneath GOMODCACHE (/opt) must not be replaced.`, and the gate ends with `::error::test gate failed: the observed run of synth/a` and **exit 1**.
- The step for the listed failures on the same module: exit 0. It makes no observed run.

So the limit is real, it fails closed, and it is as the doc and the new check `test_toolchain_beneath_the_module_cache_stops_the_gate` (`go_test_gate_selftest.py:1699`) state it. The runner is not affected: its Go comes from `actions/setup-go`, and the green runs show the observed run working.

### 5.4 The four gaps that the writer's mutants showed

I ran the writer's `mutants5.py`, byte-identical to the file in `08-repair-evidence/`, for the four mutants and for S7b, against the gate with the self-check of each commit. The gate is the same in both.

| Mutant | What it changes in the gate | Self-check of `76d9a91` (114 checks) | Self-check of `aaef28f` (117 checks) |
|---|---|---|---|
| S7 | only status 1 of `go test` counts as a failed run, for a package with entries | **survives**, `Ran 114 tests`, `OK` | **killed** by `test_go_test_that_ends_with_a_status_other_than_1_fails_the_gate` |
| S7b | the same for the packages without entries | not run (the writer added it with the second commit) | **killed** by the same check |
| Y5 | the `FAIL` line of the testing package also counts as its `PASS` line | **survives**, `Ran 114 tests`, `OK` | **killed** by `test_test_binary_that_hides_its_failing_tests_fails_the_gate` |
| Y6 | any line that starts with `PASS` counts as the `PASS` line | **survives**, `Ran 114 tests`, `OK` | **killed** by `test_test_binary_that_never_runs_the_tests_fails_the_gate` |
| Z16 | the next run of a package leaves out only the last listed test that stopped the test binary | **survives**, `Ran 114 tests`, `OK` | **killed** by `test_two_listed_tests_that_stop_the_test_binary_one_after_the_other` |

So the four gaps were real at the first commit, and the second commit closes each with the check that the report names (`mutants5-gaps-76d9a91.log`, `mutants5-gaps-aaef28f.log`). Each kill is a failed assertion. My own mutants V2, V3 and T7 make the same three changes as Y6, Y5 and Z16 from my own reading of the code, and they are killed by the same three checks (section 10).

### 5.5 `WORKFLOW_SHA256`, `OBSERVED_GO_VERSION`, `MATCH_GO_SHA256`

- **`WORKFLOW_SHA256`** in `go_test_gate_selftest.py:53` is `0383a2f066da5490db36abb91f4896c076a7d5cc45410cec11f40b85201db8bf`. `sha256sum .github/workflows/go.yml` at `aaef28f` gives the same value. The workflow changed in the first commit by one step and three comments, and the value changed with it in the same commit. The second commit changes neither.
- **`OBSERVED_GO_VERSION = "go1.26.5"`** and **`MATCH_GO_SHA256 = "f284…bebe"`** in `go_test_gate.py:170-171` are unchanged since `b39fa35`. `go.mod` still says `go 1.26.5`, and the runner log shows `go version go1.26.5 linux/amd64`.
- **Do the holds still notice a change?** Yes. I ran the last audit's file of ten edits against the self-check's workflow group and the docs contract test, on a scratch clone, with one constant set to the new workflow hash (`aud9_hold.py`, `aud9_hold.log`): all ten behave as at `b39fa35`. A changed `OBSERVED_GO_VERSION`, one changed digit of `MATCH_GO_SHA256`, a comment after the version constant and `go 1.26.6` in `go.mod` each fail the docs contract test. One changed digit of `WORKFLOW_SHA256`, a space added to a workflow comment, CR LF line ends and a step-level `GOFLAGS` each fail both. One correction to my own first run of that file: its case Y5 wrote the digit `0` into the first place of the hash, and the new hash begins with `0`, so that run changed nothing and reported "pass, pass". I changed the case to write `1` and ran the file again. The first run is kept as `aud9_hold-first-run.log`. The third audit's 21 workflow edits (`wf7.py`, unchanged) are all caught by both, among them `|| true` after the gate command, `continue-on-error`, a checkout pinned by tag, a removed third step, a second `GOFLAGS` with `-skip`, widened permissions and `pull_request_target` (`wf7.log`).
- **Is the version compared exactly (A8-F1)?** The committed gate stops on a real second toolchain that reports `go1.26.6` with exit 1 and the exact message before any test (`aud8_patchrelease.log`, the last audit's script, unchanged). The last audit's mutants H1 and H2, unchanged, are now killed by `test_another_toolchain_is_refused_before_any_test_runs` (`aud8_mutants-H1-H2.log`), and so are four of mine: any patch release, no patch number, a longer version and a shorter one (H1, H2, H9, H10 in `aud9_mutants.log`).

## 6. Earlier findings: closed or not

| ID | Severity then | State at `aaef28f` | What I checked myself |
|---|---|---|---|
| RT8-1, tests that skip themselves are outside the gate | medium | **Closed** | `check_gated_run` (`go_test_gate.py:592-616`) compares the tests with the verdict `skip` with the lines of the package in both directions, for every package and for the observed run. Runner: 39 of 39. Real tree in my container (5.2). Probes S1, S4, S6, S8. The red team's own seven checks pass unchanged against the new gate (`Ran 7 tests`, `OK`), and its probes A1 to A3 now fail the gate. Of my 17 mutants of the rule 16 are killed, and the survivor changes only what a failing run prints. The doc sentence that RT8-1 found too wide now reads "what the test step excludes and of which tests exclude themselves", which is true of the runner |
| RT8-2, a package without entries that runs none of its tests passes | low | **Closed** | The gate lists every package with `go test -list '^Test'` and holds each to the verdict rule and to the `PASS` line of the testing package (`check_gated_run`, `go_test_gate.py:550-566`). Probes C2, C3, C5. Red team's probe B1 now fails the gate. Of my 12 mutants of this rule 9 are killed. The three survivors need an event stream that `go test` does not write itself, or a line that the list check refuses first (section 10). |
| RT8-3, an entry that fails only when it runs alone | low | **Closed as required, with one corner left: A9-F1** | Every entry is judged in a run of its whole package too (`in_the_run_of_its_package`, `go_test_gate.py:892-950`). On the real tree in my container three entries that pass are named in both ways (5.2). Probe R2. Of my 23 mutants of the package run 21 are killed, and the two survivors are equal to the gate or stricter (section 10). The corner: a package run that an unlisted test or the time limit stops (section 7) |
| RT8-4, macOS-only test files are never compiled on the runner | low | **Closed** | Step "Vet for macOS" runs `GOOS=darwin GOARCH=arm64 go vet ./...`. In my container it exits 0 in 31 s on the tree, and exits 1 on a planted type error in `es/admission/execution_roots_darwin_test.go` that `go vet ./...` does not see. The tree has four files with a `darwin` build line, all in `es/admission`, and no cgo, so darwin/arm64 covers every file that linux/amd64 does not compile. The self-check holds the two vet lines of the workflow |
| A8-F1, the self-check does not hold that the Go version is compared exactly | low | **Closed** | `test_another_toolchain_is_refused_before_any_test_runs` (`go_test_gate_selftest.py:1780`) now has six other versions. The last audit's mutants H1 and H2 survived all 90 checks at `b39fa35`. Now that check kills both, and two more of mine (5.5). |
| A8-O6, the pull request text gave two counts of checks | observation | **Closed** | The description, read from GitHub at 18:11, gives one count: "117 checks. 112 of them run the gate on throwaway modules or on list files, and 5 read the workflow file itself." The self-check has 117 checks, 5 of them in the group that reads the workflow |
| M-1, the self-check failed on a file system that ignores case | defect of the first commit | **Closed** in the second commit | 5.3 |
| M-2, the gate needs Go outside the module cache | unstated limit since `b39fa35` | **Stated and held** | 5.3 |
| S7, Y5, Y6, Z16, gaps in the self-check of the first commit | gaps, the gate was right | **Closed** in the second commit | 5.4 |

Not for this audit to close, and unchanged by the repair: O-1 (required status check, with David), O-3 (a second workflow file is noticed by nothing; the writer recommends deciding it with O-1), O-6 (passing subtests under two whole-test entries: `4 pass, 18 fail` and `11 pass, 4 fail`, the same counts in my container).

## 7. Findings

One patch defect, low. No pre-existing defect that the earlier reports do not already name. Six observations, one of them about pre-existing test hygiene.

### 7.1 Patch defects

```text
AUDIT FINDING
ID / Type / Severity: A9-F1 / bug in the third step, and a statement wider than the check / low
```

**A9-F1. A package run that something outside the list stops is taken as the failure of the listed test that was running.**

- Current contract: the step "Listed tests still fail" exits 0 only if every entry fails in a run of its own and in the run of its whole package. The doc says that the step "fails the run when an entry no longer fails on the runner in one of the two, so an entry cannot outlive its reason" (`go_toolchain_baseline.md:138-141`), and the pull request description says "So an entry cannot outlive its reason" as well. The gate's docstring says that a listed test that stops the test binary fails, and that when more than one listed test was running "the run does not show which of them fails there, and each is named" (`go_test_gate.py:90-95`). The writer's report asks the audit to try claim (e): "the third step cannot be made to name the wrong test, or none, when a test binary stops."
- Path and line: `go_test_gate.py:859-874` (`judged`) and `:936-949` (`in_the_run_of_its_package`). A listed test that started, was not waiting and has no verdict counts as `fail` whenever `go test` failed. The loop looks only at the listed tests. If exactly one of them is in that state, the gate takes it as the test that stopped the binary. It does not ask whether a test outside the list was running too, or whether a test outside the list reported the panic that ended the run.
- Evidence, each on a throwaway module with the committed gate. In each the listed test fails alone, for want of what another test prepares, and would pass in the run of its package. In each the same module passes the step "Test", where the listed test is skipped.

  | Probe | What stops the run of the package | Step "Listed tests still fail" |
  |---|---|---|
  | R1 | an unlisted parallel test ends the process while the listed parallel test is running | **exit 0**, `still fails: synth/a TestListed`, `all 1 listed tests still fail on this host, each in a run of its own and in the run of its package` |
  | R1p | the unlisted parallel test panics instead. The event stream holds its verdict `fail`, reported after the last test started | **exit 0**, the same lines |
  | R8 | the entry is a parallel subtest, and an unlisted sibling panics | **exit 0**, the same lines |
  | R7 | an unlisted parallel test hangs and the run hits the time limit of `go test` (8 s in the probe, 10 minutes by default). The log shows `panic: test timed out` with both tests under `running tests:` | **exit 0**, the same lines |
  | R3 | a goroutine that an earlier unlisted test left behind ends the process while the listed sequential test is running | **exit 0**, the same lines |
  | R2, control | the unlisted test does nothing | exit 1, the entry is named as passing in the run of its package |
  | R6, control | the listed test itself ends the process while an unlisted test is running | exit 0, and here that is right |

  Logs: `aud9_probes.log` (R1, R1p, R2, R3), `aud9_probes2.log` (R6, R7, R8). In the logs R1, R1p, R3, R7 and R8 are marked `NOT AS EXPECTED (expected 1)`: I wrote them expecting the step to fail.
- Impact: the step passes and says of an entry that it fails in the run of its package, although the run did not show that. An entry that would pass there can stay in the list, and the gate goes on skipping a test that would run and pass. That is the case RT8-3 was about, left open in one corner. It needs three things at once: the entry fails alone but not in its package, the run of the package is stopped by something outside the list while the entry is running, and the step "Test" is green, so the stop depends on the listed test running or does not happen every time. **No instance today:** on the runner and in my container each of the three package runs of the third step ends with the testing package's own line `FAIL` and without a panic, so each came to its end. What makes it more than a thought: three of the eleven entries of the root package are parallel tests (the three `TestRemoteAlphaRuntimeSecurityBoundary…` entries call `t.Parallel()`), that package has 94 `t.Parallel()` calls in 12 test files, and a package run that hits the time limit of `go test` is an ordinary way for a run to stop (R7). Today the root package takes 100 s of the 600 s on the runner.
- Required correction: the step must not count an entry as failing in the run of its package unless the run shows it. When the run of a package does not come to its end, the gate has to look at every test of the event stream, not only at the listed ones. (1) If a test outside the path of the entry (not the entry, not one of its subtests, not a test above it) reported its failure after the last test started or went on, that test stopped the run, not the listed one (R1p, R8). (2) If such a test was running without a verdict beside the listed one, the run does not show which of them stopped it. The gate already has the right rule for two listed tests: name the entry and fail (R1, R7). R6 then fails too unless the gate finds another way to tell the two apart; refusing it is the safe side. (3) R3 leaves no trace in the event stream. That bound has to be stated in the docstring and in the doc, or the doc sentence narrowed. The self-check needs a case for each of R1, R1p, R7 or its like, and R8. Inference: the change is local to `in_the_run_of_its_package` and to what `go_test_json` records for it.
- Uncertainty: none about the facts. Whether (2) should fail the step or make one more run is a design choice for the writer. The severity follows the red team's rating of RT8-3 itself, which was low without needing any coincidence.
- Patch defect or pre-existing issue: **patch defect.** The run of the whole package and the rule for a stopped test binary are new in `76d9a91`.

### 7.2 Pre-existing issues

None that the earlier reports do not already name.

### 7.3 Observations

- **A9-O1. A `TestMain` that calls `m.Run` twice can hide a failure of the first run from the gate.** If it exits with the status of the second run, a test that fails in the first and passes in the second ends with the verdict `pass` for the gate, and the testing package's last line is `PASS` (probe S7, exit 0). Plain `go test` passes on that module too, so the gate is no weaker than the tool it wraps. The tree has no `TestMain` at all (0 matches of `func TestMain`). A skip in the first run only is caught (S8).
- **A9-O2. For a skip that cannot be listed, the error message proposes a line that the gate then refuses.** A fuzz target that skips itself on its seed corpus, or a subtest with a name outside the list's alphabet, fails the step with "needs the line 'skips-itself <package> <name>'", and that line is refused as malformed with status 2 (S2, S2b, S3, S3b). It fails closed, and the cure is to change the test. The writer states the subtest case in section 8 of the report. The fuzz target is not stated, and the message does not say that such a line cannot be written. The tree has 0 fuzz targets and 0 examples. A sentence in the list header, or a message that tells the two cases apart, would save the next writer a wrong turn.
- **A9-O3. The reasons are held by review, the names by machine.** A listed test that begins to skip for another reason than the one in its comment stays green. The writer says so (section 8). The log line of each skip carries what the test wrote, so a review can see it. I add one fact: the two runner runs of the pull request, at `b39fa35` and at `aaef28f`, ran on two versions of the image `ubuntu-24.04` (`20261116.133.1` and `20261116.376.1`). The image can change under the same label. If a change adds or removes a tool that a test asks for, the step turns red and names the lines. That is the intended trigger and it is fail closed.
- **A9-O4. A comment in the self-check sits above the wrong constant.** `go_test_gate_selftest.py:257` ("`go env GOVERSION GOROOT` names another Go version, and the real GOROOT.") describes `OTHER_VERSION_GO` at line 267. The second commit put `TOOLCHAIN_IN_THE_MODULE_CACHE_GO` and its own comment between the two. Cosmetic.
- **A9-O5. The commit messages of the two commits end with a co-author line that names a model,** as all eight commits of the pull request do. It is not part of the audited bytes and no earlier report raised it. I name it because the project has asked for merge messages without a model name elsewhere. Whoever merges decides the text of the merge.
- **A9-O6. Pre-existing, outside the patch: tests of the tree leave entries in the temporary folder.** After the four step runs on the real tree, my test user's temporary folder held 36 files named `remote-alpha-runtime-security-boundary.*.json`, 28 folders made with `mktemp`, and 7 folders of the two listed `es/app` subtests, which appear only in the third step. The gate and the self-check remove their own folders. On a runner that is thrown away after the job this costs nothing. On a machine that is kept, such as David's Mac or the test box, it adds up with every run of those tests. I did not look for which tests leave them.

## 8. Validation assessment

### 8.1 Commands I re-ran, all on the exact bytes of `aaef28f` (tree `f00fdd40…`) as user `ci` with an empty environment

| Command | Result |
|---|---|
| `go version`; `go env GOVERSION GOROOT GOMODCACHE GOTOOLCHAIN GOFLAGS` | `go1.26.5 linux/amd64`; `/opt/go1.26.5`; `/home/ci/go/pkg/mod`; `local`; `-mod=readonly` |
| `go mod verify` | `all modules verified`, exit 0 |
| `go build ./...` | exit 0 |
| `go vet ./...` | exit 0 |
| `GOOS=darwin GOARCH=arm64 go vet ./...` | exit 0, 31 s |
| `gofmt -l docs_contract_test.go` | no output |
| `go test -count=1 -run '^TestGo1265ToolchainBaselineDocsAndBuildContract$' .` | `ok`, exit 0 |
| `git diff --check` for the repair and for the whole pull request | exit 0, both |
| `python3 -I -B .github/ci/go_test_gate_selftest.py` | `Ran 117 tests in 174.188s`, `OK`, exit 0 |
| Step "Test" and step "Listed tests still fail" with the committed list | exit 1 and exit 1, each for the reason that this host gives (5.2) |
| The same two steps with the container list | exit 0 and exit 0 (5.2) |
| The red team's `go_test_gate_redteam8.py`, unchanged, beside the new gate | `Ran 7 tests in 3.934s`, `OK` |
| The red team's `rt8.py` and `rt8_lists.py`, unchanged | 13 of the 15 probes give the safe result, J1 and J2 among them. C1 and E1 are the two boundaries that the red-team report states, and behave as it says. `rt8_lists.py`: `unexpected: 0` |
| The last audit's `aud8_patchrelease.sh`, unchanged | the committed gate exits 1 on `go1.26.6` with the exact message |
| The planted macOS-only error | `go vet ./...` exit 0, `GOOS=darwin GOARCH=arm64 go vet ./...` exit 1 at `execution_roots_darwin_test.go:91:34` |

Each adopted file is a byte copy of the file in the evidence folder of its report (`prior-SHA256SUMS.txt`).

### 8.2 Probes of my own

`aud9_probes.py` (the skip rule, what a package has to report, the run of the whole package, list lines), `aud9_probes2.py` (R6, R7, R8) and `aud9_probes3.py` (M2). 5.2, 5.3 and 7.1 give the results. One correction to a log: in `aud9_probes.log` probe C4 ends `NOT AS EXPECTED`. That was my mistake. The example function in my module was named `ExampleX`, which `go vet` refuses during `go test`. With `func Example()` the probe gives the expected exit 0 (`aud9_probes-C4.log`).

### 8.3 Not run

- **Nothing on macOS,** and nothing on a GitHub runner of my own. I read the runner result from GitHub (section 9).
- **The race detector.** The workflow does not use it, and the doc says so.
- **The writer's whole mutant set of 195.** I ran 57 of it: the 55 that are new with this repair, and S7 and S7b. The other 138 are carried over from `07-repair.md`. The last audit ran that set at `b39fa35`. The writer reports its result for `aaef28f`, and I did not re-run it (section 10).
- **The 37 `es/app` integration tests themselves.** They need Nomad and Vault and skip in my container as on the runner.
- **A stale `skips-itself` line on the real tree.** I showed the stale direction on the real tree for entries (5.2), and for skip lines on throwaway modules and by mutants.

## 9. The runner result, from GitHub

Read with the GitHub tools at the start of the audit and again at 18:11. Section 14 has the state at closing.

- Pull request #14: open, draft, head `aaef28f`, base `ae326b0`, `mergeable_state` `clean`.
- Run 45046634281: event `pull_request`, attempt 1, conclusion **success**. Job 137282573571 ran from 16:56:52 to 17:09:05 on `ubuntu-24.04`, image version `20261116.376.1`.
- The job checked out the merge commit `9cd7a754959c3be144898e31ed89d2c14e7f0356`, with parents `ae326b0` and `aaef28f`. I fetched `refs/pull/14/merge`: its tree is `f00fdd40…`, the audited tree. So the runner tested the audited bytes.
- Steps: "Vet for macOS" 29 s; "Check the test gate" `Ran 117 tests in 118.577s`, `OK`; "Test" 5 m 35 s; "Listed tests still fail" 3 m 18 s.
- The log has the closing line of each step as quoted in 5.1 and `all 15 listed tests still fail on this host, each in a run of its own and in the run of its package`, with 15 lines `still fails:`. It has no line with `::error`, and no warning or deprecation line.
- The log file I saved is byte-identical to the writer's copy in `08-repair-evidence/`.

## 10. Mutants

### 10.1 My own: `aud9_mutants.py`

65 changes of the committed gate, one each, written from the code before I read the writer's mutant file. Each asserts that the text it replaces occurs exactly once, so none is a silent no-op. Each runs in a copy of `.github/` against the committed self-check: first the groups of checks that should notice it, with `unittest -f`, and then, if none of them fails, the whole self-check. So a survivor has passed all 117 checks. Three ran at a time. The control passes all 117 (`aud9_mutants.log`).

| Group | Count | What it changes | Killed | Survive |
|---|---|---|---|---|
| K | 17 | The skip rule: each direction of the comparison, subtests, which packages it covers, the observed run, whether a difference fails the step | 16 | K16 |
| V | 12 | What a package has to report: the `PASS` line, the verdict rule, the listing of every package, the status of `go test` | 9 | V5, V6, V12 |
| T | 23 | The run of the whole package in the third step: whether it is used, tests that waited, the runs after a stopped test binary, two tests side by side | 21 | T21, T22 |
| P | 9 | How the `skips-itself` lines are read and checked against the entries and the module | 9 | none |
| H | 4 | The exact comparison of the Go version | 4 | none |
| Total | 65 | | 59 | 6 |

All 59 kills are failed assertions. None is a kill by the time limit or by an error in the self-check. 24 different checks made them.

The six survivors, each judged:

- **K16** (after the first package without entries that has a problem, the others are not compared) and **T21** (when two listed tests ran side by side, the entries that the run did not get to are not named). The step fails either way. Only the log of a failing run names less.
- **T22** (in the run after a stopped test binary every entry is judged again). Equal to the gate or stricter: an entry already counted as not failing stays so, and one that failed before has to fail again.
- **V12** (a package without test files is not checked for its lines). Not reachable: the list check refuses a line for a test that its package does not define, with status 2, before any run.
- **V5** (a top-level test that started counts as having reported) and **V6** (a package that `go test` did not report on is taken as passed). They differ from the gate only for an event stream in which a package passed with the testing package's `PASS` line while a started top-level test has no verdict, or in which `go test` exits 0 and says nothing about a package. Inference: `go test` does not write either by itself. A test would have to forge the lines of the testing package, which the gate's docstring puts out of scope. The writer's expected survivors E1 to E4 are of the same kind.

So no survivor shows a state that should fail and passes, and I raise none as a finding.

### 10.2 The writer's: `mutants5.py`, unchanged

The file I ran has the SHA-256 `78856cd5…8314`, the value in `08-repair-evidence/SHA256SUMS.txt`, and I used the writer's hint file.

- **The four gaps and S7b,** at both commits: 5.4.
- **The 55 mutants that are new with this repair,** against the self-check of `aaef28f`: X1 to X29 (the skip rule), Y1 to Y6 (packages that run nothing) and Z1 to Z20 (the package runs of the third step). **All 55 are killed** (`mutants5-XYZ-aaef28f.log`). 54 are failed assertions. Z12 is stopped by the time limit, 700 s here, as the writer reports: it makes the third step run a package again and again.
- **Not run by me:** the other 138, carried over from `07-repair.md`. The last audit ran that set at `b39fa35`.

### 10.3 The last audit's files

`aud8_mutants.py` H1 and H2, unchanged: both killed (5.5). The ten edits of `aud8_hold.py` and the 21 edits of `wf7.py`: 5.5.

## 11. The five claims the writer asked the audit to break

| Claim (`08-repair.md` section 12) | Result |
|---|---|
| (a) No test or subtest can end with `skip` in any package without a line | **Holds** in every case I tried, within what the gate reads: the event stream of a test binary that does not forge it. A skip that the list cannot name fails the step (A9-O2) |
| (b) A line cannot stay when its test passes, fails or is gone | **Holds.** Passes or does not run: named, exit 1. Fails: a failed run. Not defined in the package: the list is refused with status 2 |
| (c) No package can pass while a listed top-level test has no verdict | **Holds.** "Listed" here means listed by `go test -list '^Test'` |
| (d) No entry can stay that passes alone or in the full run of its package | **Holds when the run of the package comes to its end.** When it does not, see (e) |
| (e) The third step cannot be made to name the wrong test, or none, when a test binary stops | **Does not hold: A9-F1.** It holds among listed tests |

## 12. The project rule: no "revisit later", and a machine-enforced trigger for every temporary edge

- **The repair itself leaves nothing for later.** The limits it states are bounds of the design, each with its reason (`08-repair.md` section 8), and none is marked as temporary. A search of the six files for `for now`, `not yet`, `later`, `revisit`, `TODO` and `temporary` finds only names in code: a variable `later`, a generated test `TestLater`, the words "to run in parallel later" in three comments, and two test names. I searched the lines that the repair adds, also for `accepted`. No sentence puts work off or states a limit as accepted.
- **The 39 lines have their trigger.** A line cannot outlive its reason: when the runner gets Nomad or Vault, or a test is ported, the step "Test" fails until the line is gone.
- **The Go version has its trigger,** now held exactly by the self-check (A8-F1 closed).
- **A9-F1 has no trigger, and it should not become a "later" item.** My judgement is that it does not block: no state of today's tree passes wrongly, the step fails closed in every other case I found, and the corner is narrower than the low finding it comes from. The rule leaves two clean ways: repair it in this pull request before the merge, with a narrow audit of that change, or decide that the stated bound is the end state and say so in the doc, which is a change of bytes as well. I recommend the first. The coordinator decides the order with the other open items.
- **The writer's stated bound for RT8-3** (an entry that fails alone only for want of an unlisted test and fails in the full run only because of another listed test) is a choice of cost, stated with its price of about 20 more minutes per run. I agree that it needs a double coincidence. It is a different corner from A9-F1 and stays the coordinator's call, as the writer says.

## 13. Not covered, and Unknown

- **macOS.** Not run by me. Unknown to me: whether the self-check of `aaef28f` passes on David's Mac. The writer's second Mac run says it does (`08-repair.md` 7.6), and my Linux check of the case rule agrees with it.
- **Whether a push to `trunk_dev` gives the same skip set.** Nothing was merged. It is the same workflow file and the same image label.
- **Unknown:** how GitHub treats two jobs of one name under a required check (the writer's O-3 note). Not tested.
- **Not inspected:** the skip sites of the tree that did not fire on the runner, beyond listing them (20 `t.Skip` calls in the `es/app` test files, for root, FIFO, loopback, Python, Git and Docker). They did not skip there, or the step would have failed.
- **Not shown by anyone:** that each of the 39 tests would pass with Nomad and Vault present.
- **The three Go test files that the pull request changed before `b39fa35`** are byte-identical to what the earlier audits read. I did not read them again.

**Stop conditions.** This verdict binds the bytes of `aaef28f` with tree `f00fdd40…` and the base `ae326b0`, and nothing else. A new commit on the branch, a repair of A9-F1 or a moved base needs an audit of the changed bytes before a merge. The merge itself needs David's go.

## 14. Closing state

- **Remote,** `git ls-remote` at 18:49: `trunk_dev` is `ae326b0`, the topic branch and `refs/pull/14/head` are `aaef28f`, `refs/pull/14/merge` is `9cd7a75`. Unchanged since opening.
- **Pull request #14.** At 18:11: open, draft, head `aaef28f`, base `ae326b0`, `mergeable_state` `clean`, last update 17:29:35. At 18:49: one check run, "build, vet and test", conclusion success, and no comment. I posted nothing.
- **The audit clone:** `HEAD` at `b39fa35`, as the recipe needs it, and the working tree byte-identical to `aaef28f` (`git diff --quiet`). I never edited a file in it.
- **The scratch clones** `es` and `es-plant`: both at `aaef28f` with tree `f00fdd40…` and an empty `git status --porcelain`.
- **The toolchain:** `/opt/go1.26.5/src/testing/match.go` still has the SHA-256 `f284…bebe`.
- **Processes and mounts:** no process of the test user is left, and the FUSE mount is gone.
- **Left in the test user's temporary folder,** outside every repository tree: 75 entries. 71 are what the repository's own tests leave behind in the four step runs (A9-O6). One is a folder of the red team's `rt8_lists.py`, and one is my prebuilt root test binary. Two are what the time limit left when it stopped the writer's mutant Z12: a throwaway module of the self-check and a build folder of the go command. When the self-check ends by itself it leaves nothing (5.3). I removed nothing there. The container goes away with the session.

## 15. Sensitive-material handling

I read no secret and wrote none. The runs had an empty environment. The evidence folder holds logs of the repository's own tests and of my throwaway modules, the job log of the runner as GitHub serves it to a reader of the repository, scripts and manifests. I scanned this report and every file of the evidence folder with the project's scan tool (`ge_chat_archive.py scan`) for keys, tokens, e-mail addresses and phone numbers before delivery. The evidence folder: 0 findings. This report: one match of the tool's pattern for e-mail addresses, in section 3. I read it. It is the Go module path of the toolchain, which has an at sign before its version, and not an address. No key, no token, no phone number.

## 16. Confidence

- **Provenance: high.** Three manifests reproduced twice each, equal to the writer's, equal again at closing, and the runner's merge commit has the audited tree.
- **Validation: high for Linux, none of my own for macOS.** Every Linux command of the report that I re-ran gave the writer's result on the exact bytes. The whole gate ran on the real tree with two lists.
- **Implementation: high for the skip rule and the holds, medium for the third step.** The skip rule is a set comparison on verdicts that the testing package wrote, and I could not get past it within its stated scope. The third step reasons about a stopped test binary from an event stream, and A9-F1 shows that one of its inferences is not sound. I looked for more of that kind and found the five probes of 7.1, all of one root.

## 17. Report delivery

- Report: `/mnt/project-files/reports/Execution-Substrate/ci-go-workflow/09-audit.md`. Its SHA-256 is in the reply that delivers it, since a file cannot hold its own hash.
- Evidence: `/mnt/project-files/reports/Execution-Substrate/ci-go-workflow/09-audit-evidence/`, with `README.md` and `SHA256SUMS.txt`.

**Final verdict: ACCEPT**
