# REPAIR REPORT 3 (replacement implementation report): Execution-Substrate Linux CI

**Verdict:** REPAIR_COMPLETE for the bytes. Ready for a fresh independent audit and red-team pass of the whole base-to-tip range. One thing is open and changes no bytes: the run on David's Mac (RF-4), which is requested again for the new head. Nothing in this report waits for a decision by David. The limit that the first version of this report put before him is closed by a check (section 8).
**Effect status:** TOPIC_BRANCH_PUSHED (fast-forward, no force) · DRAFT_PR_UPDATED https://github.com/evo-agi/Execution-Substrate/pull/14 · CI_GREEN_ON_RUNNER (run 45021679869 at `b39fa35`, one run) · PR_16_NOT_TOUCHED · MERGE_NOT_PERFORMED · INDEPENDENT_AUDIT_NOT_PERFORMED on the new bytes · RED_TEAM_NOT_PERFORMED on the new bytes

This report replaces `05-repair.md` as the implementation report for PR #14. It answers the BLOCK in `06-reaudit.md` (SHA-256 `66ee63c405859cecc6142ae184e0c2435b62dd2857248a89c47e5d804c4b6f7c`, which is what I read). PR #16 was audited ACCEPT and is not touched.

**This is the second version of this report.** The first version (SHA-256 `d5573f8b2ba7558633ca071b2f54fa52e7607967880684f46c6934123263f552`, delivered at 10:35) described the head `af51f86`. It left one corner open as a "stated limit" and asked David to accept it or to refuse it. The coordinator answered that accepting it would be a rule in words only, which the project instructions do not allow, and asked whether a check in CI can close the corner. It can. The repair now has two commits, `af51f86` and `b39fa35`, and this version describes both together. I withdrew the decision card at 10:44. David had not answered it. Nobody had started an audit of `af51f86`.

All times are UTC on 2026-11-22.

## 1. What was repaired, in short

The third audit confirmed the three earlier blockers as fixed. It blocked on one new finding (F-1) and listed four lower ones (F-2 to F-5) and five observations.

1. **A list entry for a subtest can no longer take another test out of the gate (F-1).** `go test` reads a test path as the start of a path. The skip for `TestA/x` also covers every test whose path starts with `TestA/x/`: a subtest of `x`, and a subtest beside `x` whose own name is `x/...`. Both steps stayed green. `go test` has no narrower pattern. I checked that in its source, and section 3 has the argument. So an exact skip cannot come from the pattern. It now comes from two checks, one in each blocking step.
   - **The step "Test" shows what it skipped** (commit `b39fa35`, new in this version). A package that has an entry for a subtest runs a second time with the same skips, in a test binary that writes down the name of every test that `-skip` drops. The step fails unless those names are exactly the entries of the package, each once. It names a skipped test that is not listed, and it names an entry that skipped nothing.
   - **The step "Listed tests still fail" runs every entry in a `go test` of its own** (commit `af51f86`). It fails when the run of an entry for a subtest starts any other test under the path of that entry, and it names the entry and those tests.
2. **Every entry is judged in a run of its own (F-3).** A listed test that fails only after another listed test in the same process no longer looks as if it still fails.
3. **The two steps agree on a subtest whose own name holds a `/` (F-2).** Both accept such an entry, and it skips exactly that subtest. The list header says which subtests cannot be listed.
4. **The workflow file is held as a whole (F-4),** by its SHA-256, in the self-check and in the docs contract test. All 21 workflow edits of the audit are caught by both.
5. **Both actions moved to releases that target Node.js 24 (F-5).** The runner log holds no warning anymore.
6. **For a whole-test entry the step prints how its subtests ended (O-1).**

**The corner that the first version left open is closed.** It was the audit's probe S12: a subtest named `x/...` that its test starts only when the listed `x` did not fail, for example after `if !t.Run("x", ...) { return }`. No run of `x` can show that subtest, because `x` fails on the runner and the test stops. But in the step "Test" `x` is skipped, the test goes on and reaches `x/...`, and `go test` drops it together with `x`. The second run writes that name down, and the step fails and names it. The rule for people that covered this corner in the first version ("before listing a subtest, read its test") is gone from the list file, and so is every sentence that stated a limit.

**What the new check costs.** The package `es/app`, the only one with entries for subtests, runs twice in the step "Test". That is about a minute more on the runner (63 s in the run of section 7.6). For that second run only, `go test -overlay` builds the test binary with a changed copy of one file of the Go standard library, `src/testing/match.go`. The copy adds one call and one small function that appends a name to a file. The installed toolchain is not changed, nothing is downloaded, and no other run uses the copy (sections 4.3 and 9).

The self-check grew from 56 to 90 checks. 34 of them fail against the gate of `c4a84f5`, and 20 against the gate of `af51f86` (section 7.2).

Not done: the Mac run (RF-4). It is requested again for `b39fa35` (section 7.7).

## 2. Target identity

| Field | Value |
|---|---|
| Repository | evo-agi/Execution-Substrate |
| Base ref and SHA | `trunk_dev` at `ae326b0ddc30ec6b35883ee32945c622405b68b6` (re-fetched before the manifests and again after the push; unchanged) |
| Topic branch | `claude/project-thread-sqldt7-ci` |
| Commits | `d886bb80feb160b6775f0ac1866ce69f7bdbfe47`, `145ab62001e488fea0cd4c4a002661df86ef9f95`, `fada999c6da5ed157c74033e1e975415c179c49d`, `c4a84f5695500cca2087abefb8027afd700f35e2` (the tip the third audit blocked), then this repair in two commits: `af51f860b71cbecb3dc101c9c6fc5664f807066e` and `b39fa35d444a4bd87a3901287bb6a346577c81b9` |
| Tip tree | `76d9bdc2643bbdce8f057ee2d455f94ec7bca6ae` |
| Draft PR | #14, base `trunk_dev`, now 9 files, +3285/−9. This repair against `c4a84f5`: 6 files, +1776/−166. The second commit alone: 6 files, +1039/−129 |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified with `sha256sum -c` before each run |
| Manifest upstream | `origin/trunk_dev` |
| **Cumulative manifest SHA-256 (audit this one)** | `a41367f9cd702a23d627ba1670fd64a54ce1f9b7e43bcda380b06d200ae0108e` (2,033 bytes), HEAD `ae326b0`, 9 files: 4 untracked new, 5 tracked_modified |
| Cumulative textual diff SHA-256 | `211aed80b98c8b2e686a27711437826a8d6160ff4ca9d9a1608cea605121d1c2` |
| Repair-only manifest (the delta since the last audited tip) | `bc70bcdc52935d560c06950ee0c052907edf7efb957a10b48f3832aac70cf1ff` (1,446 bytes), HEAD `c4a84f5`, 6 files, textual diff `27e8dd6f3b6a145e34d50826c797289213ba093c3250547e9b65c0de66128767` |
| Manifest of the second commit alone | `c195fac8dc905f52ac4c0f950c8a42849a3bc3eeb181a7fd711413e40a1928c8` (1,446 bytes), HEAD `af51f86`, 6 files, textual diff `8a228f5654123a63e9a23e7b1d72434f27212e7f32c782b1e8b696a9ad82e944` |

**Auditor reproduction:** provenance §5.3 with `BASE=ae326b0ddc30ec6b35883ee32945c622405b68b6`, `TOPIC=claude/project-thread-sqldt7-ci`, `TIP=b39fa35d444a4bd87a3901287bb6a346577c81b9`, and the upstream pinned with `git branch --set-upstream-to=origin/trunk_dev`. I ran exactly that in a fresh clone from GitHub after the push. The result was byte-identical to the cumulative manifest (`cmp`), twice. The same clone with HEAD at `c4a84f5` gave the repair-only manifest, and with HEAD at `af51f86` the manifest of the second commit, both byte-identical.

Final working-tree status after the commit: clean (`git status --porcelain` empty).

The manifests of the first version of this report (cumulative `bd3c4910…cc6f`, repair-only `29e51346…0fd6`) described `af51f86`. They are superseded and are not in the evidence folder anymore.

PR #16 (`claude/project-thread-k69qcw` at `0a069ecbe53c842d33c932f63aed2af523e2eb0c`) is unchanged. Its identity is in `05-repair.md` section 2.

## 3. Reconnaissance

No subagents. I read `06-reaudit.md` whole and these files of its evidence folder: `README.md`, `sketch-notes.txt`, `leaf_sketch.py.txt`, `rt6.py.txt`, `rt6b.py.txt`, `rt6c.py.txt`, `mut6.py.txt`, `mut6.log`, `wf6.py.txt`, `wf6.log`, `alone.log`, `plant-d.diff` and `plant-d-run.sh.txt`. In the repository I re-read `AGENTS.md`, section 10 of `.docs/system_overview/go_toolchain_baseline.md` and the sentences that `docs_contract_test.go` holds. `PLANS.md` needs no change: this repair changes no redesign scope, seam status or sequencing.

**What `go test` can and cannot match.** I read the matcher in the toolchain this repository pins, Go 1.26.5, file `src/testing/match.go` (317 lines, SHA-256 `f28418759ed48c72821b5ecc3700041b74151108557618f50d355ea98a1bbebe`):

- `fullName` (lines 83 to 113) splits the full name of a test at every `/` (line 97) and gives the parts to the `-run` filter and to the `-skip` filter. A test is skipped when the skip filter matches and the match is not partial (lines 108 to 111).
- `simpleMatch.matches` (lines 125 to 135) compares part by part and stops when the pattern has no more parts. It reports a match as partial only when the name has fewer parts than the pattern.
- `alternationMatch.matches` (lines 150 to 157) returns at the first alternative that matches at all.
- `T.Run` (`src/testing/testing.go`, lines 2059 to 2062) returns `true` for a subtest that the filters exclude. A test therefore goes on after a skipped subtest as if it had passed.

From these four facts:

- A subtest named `reg/custody` by `t.Run` and a subtest `custody` of a subtest `reg` have the same full name, `TestP/reg/custody`, and the same parts. No pattern tells them apart.
- **No `-skip` pattern skips `TestA/x` and not `TestA/x/...`.** Take the first alternative that matches `TestA/x`. Because `TestA/x` is skipped, that match is not partial, so the alternative has at most as many parts as `TestA/x`. Every earlier alternative fails on one of the parts of `TestA/x`. A longer name `TestA/x/...` has the same first parts. So the earlier alternatives fail on it too, and the same alternative matches it, again not partially. It is skipped.
- **No `-run` pattern runs `TestA/x/...` and not `TestA/x`.** An alternative that matches the longer name matches the shorter one, which has the same first parts, at least partially. A partial match of the run filter still runs the test, so that its subtests can be reached.

So a skip of exactly one subtest does not exist in `go test`. The gate can only skip a path together with everything that `go test` finds below it, and then show that nothing else was there. The first commit of this repair shows it for what a run of the entry starts. The second commit shows it for what the gate really skipped.

The audit's warning holds: `go test -json` does not carry the nesting depth of a test, so the third step cannot tell a real subtest of `x` from a neighbour named `x/...`. It treats both as "another test under the path of the entry" (section 4.2, the leaf rule).

**Where `go test` drops a test, and that it is one place.** This is what the second commit rests on.

- In the testing package of Go 1.26.5 the skip filter is read in exactly one place: line 108 of `match.go`, inside `fullName`. The test is dropped by the three lines that follow (`if skip && !partialSkip { return name, false, false }`). The flag `-test.skip` itself is only handed to `newMatcher` (`testing.go:2566`, `benchmark.go:704`, `example.go:32`, `fuzz.go:482`, `485` and `566`). I searched the package for every use of the flag and of the filter.
- `fullName` is called for everything a test binary can run: tests and subtests through `T.Run` (`testing.go:2059`), top-level tests too, because `runTests` starts each of them with `t.Run` (`testing.go:2585`); benchmarks (`benchmark.go:709` and `817`); examples (`example.go:36`); fuzz targets and their seed entries (`fuzz.go:407`, `506`, `511` and `586`).
- So a call added to those three lines sees every test that `-skip` drops, whatever kind it is and however its name was built.

**`go test -overlay` reaches the standard library.** The build flag `-overlay` takes a JSON file that puts one file on disk in the place of another for that build. I tried it on a throwaway module before changing the gate: with an overlay for `GOROOT/src/testing/match.go`, `go test` rebuilds the testing package from the replacement and links the test binary with it. The file under `GOROOT` is only read. A later build without the flag does not get the changed package from the build cache: I built the same test binary with and without the overlay, in turn, twice, and only the builds with the flag hold the added function (`cache-check.log`).

**Why not a check of the source.** The coordinator's message named two possible guards as examples: a step that fails when the parent of a listed subtest uses the result of `t.Run`, or a static check that the parent of every listed subtest has to pass. I looked at both first. A test can change course after a subtest in many ways that have no fixed shape in the source: the result of `t.Run`, `t.Failed()`, a variable that the subtest sets, a panic, a helper that gets the `*testing.T`, a table of names built at run time. A check for the literal `if !t.Run` misses the others and would claim more than it holds. A check that is strict enough to be sound, for example "the test body is nothing but `t.Run` calls with fixed names", refuses tests that are fine and still has to be argued shape by shape. The run-time record needs no such argument. It asks the one place that decides.

**The action releases (F-5).** I read the tags of the two public action repositories with `git ls-remote --tags` and the file `action.yml` at the old and the new pinned commits. I fetched only those objects, into a directory of their own, and ran nothing from them.

| Action | Old pin | New pin | Runtime declared in `action.yml` |
|---|---|---|---|
| `actions/checkout` | `11d5960a326750d5838078e36cf38b85af677262`, tag `v4.4.0` | `3d3c42e5aac5ba805825da76410c181273ba90b1`, tags `v7.0.1` and `v7` | `node20`, now `node24` |
| `actions/setup-go` | `40f1582b2485089dde7abd97c1529aa768e1baff`, tag `v5.6.0` | `d8cbb8045d7f43706b9177cceb36c1f91a6644d5`, tags `v7.1.0` and `v7` | `node20`, now `node24` |

The inputs this workflow uses still exist under the same names at the new commits: `persist-credentials` for checkout, `go-version-file` and `cache` for setup-go. The runner run in section 7.6 is the proof that they behave as before: Go 1.26.5 is installed from `go.mod`, no cache is restored, and the same three gate steps pass.

Findings adopted: all five findings and observation O-1, in substance as the audit describes them. The third step follows the audit's advisory sketch (`leaf_sketch.py.txt`): judge by what starts in a run of the entry alone. Findings rejected: none. Not acted on: O-3 and O-4 (limits that the audit itself accepts and that only hostile test code reaches, and an unchanged test file) and four of the audit's surviving mutants that no output of a real `go` command can tell apart (section 7.3).

## 4. Implementation decisions

Nothing here touches an Execution Substrate contract, boundary, DTO, lifecycle rule or seam. Current-contract treatment: unchanged. Strategic target: not affected. Reopened seams: none. Compatibility: no production code changes. The only files touched are the CI files, one doc and the docs contract test.

### 4.1 The list: `.github/ci/environment-only-tests.txt`

The 15 entries are unchanged. Only the header changed.

- It says what an entry stands for. An entry for a whole test stands for that test with all of its subtests. An entry for a subtest stands for that subtest alone.
- It says that the step "Listed tests still fail" runs every entry in a `go test` of its own.
- Part "Subtests that cannot be listed. For each of them, list the whole test": a subtest whose printed path has a part that is empty or holds a character other than an ASCII letter, a digit, `_` or `-`; a subtest that `go test` numbers with `#01` because its name repeats; and a subtest that has subtests of its own, or a neighbour whose name starts with its name and a `/`.
- For that last kind the header now says that both steps check it, and how. The step "Test" runs the package a second time, has `go test` write down every test that it skips, and fails unless those are exactly the entries. The step "Listed tests still fail" fails when the run of an entry starts another test under the path of that entry.
- The part "What that step cannot see" of the first version is gone, with its example and its rule for people. In its place is one sentence about what is not a loss: "A subtest that a listed subtest x would start itself does not start while x is skipped. It is part of x, and nothing but x is lost with it."

### 4.2 The gate: `.github/ci/go_test_gate.py`

The brief asked for a fix "with exact matching". My reading: an entry must stand for exactly the test it names. `go test` cannot be given such a pattern (section 3), so the gate establishes it with checks.

Reading the list and checking it against the module are unchanged, and so are the exit statuses: 0 success, 1 a Go command or a check failed, 2 the list or the command line is wrong.

**Mode `gate` (the step "Test").**

- Unchanged: a package with entries runs alone with its own entries skipped, every other package runs with nothing skipped, and every top-level test that is not a whole-test entry must have reported a verdict.
- **New in the second commit: the observed run.** A package that has an entry for a subtest runs a second time once its first run and the check of that run have passed. Section 4.3 describes it. The step now exits 1 for an entry that covers another test (probes S9, S9r, S11, S9h, S12 and the planted fault P-d) and for an entry that skips nothing (probe S8).
- **Changed, F-2:** the gate no longer requires every part of a listed path to be a test that ran. A part need not be a test at all, because the name of a subtest may itself hold a `/`. That old check is what refused probe S1 with a wrong reason. What it protected is now held elsewhere: the top-level test of a listed subtest still has to run, the observed run requires the listed subtest itself to be reached, and the third step requires it to start and to fail.
- **Changed:** the evidence line for a listed subtest reads `P: T ran without the listed S; beside it ran: …`. `T` is the nearest test above the entry that really ran, and "beside it" are the tests that have the same nearest test above them. With plain names that is the parent and its other subtests, as before. With names that hold a `/` it stays correct, where the old rule, "no further `/` in the name", was not.

**Mode `still-failing` (the step "Listed tests still fail").** Unchanged since `af51f86`.

- It runs **one `go test` for each entry**: `go test -json -count=1 -run <anchored pattern of that entry> <package>`, each inside its own log group "Expected failure of the listed P T". The common run of all entries of a package is gone, and with it the second run that asked an entry again when it had no verdict.
- An entry is judged by **its own verdict in its own run**. `fail`: the line `still fails: P T`. `pass`, `skip` or no verdict: an error line that names the entry and says "it passes", "it skips itself" or "it did not run". An entry that starts, reports no verdict and takes the go command down with it still counts as failing.
- **F-1:** for an entry that names a subtest, every other test that starts inside its path in that run is a test that the gating step would skip together with the entry. Each such entry gets an error line, and the step exits 1:

```text
::error::listed subtest is not the only test under its path: P TestA/x also covers TestA/x/custody. The gate skips them with it. An entry for a subtest must be the only test whose path starts with its own. In LIST, name such a subtest, or list the whole test TestA.
```

- This is checked for every entry, also for one that passes or does not run.
- **The leaf rule.** This step does not distinguish a real subtest of `x` from a neighbour named `x/...`, because the output of `go test -json` does not. So a subtest that has subtests of its own cannot be an entry (probe S10, which the second repair accepted by design). The entry has to name the subtest that fails and has nothing below it, or the whole test. None of the 15 entries is affected. I kept this rule although the observed run now shows the neighbours on its own. The two checks look from different sides: the observed run sees what the gate skipped while the entry was skipped, and this step sees what the entry starts when it runs. The rule also keeps an entry as narrow as the thing that fails.
- **O-1:** for a whole-test entry the `still fails:` line ends with a note such as `(its subtests: 11 pass, 4 fail)`. It counts every subtest that started, at any depth. A subtest without a verdict is counted as `unfinished`. The note is information only. A passing subtest under a whole-test entry does not fail the run. Whether it should is a choice the audit leaves to the coordinator or David.
- A package in which no listed test starts (for example a build failure) fails the step once, without naming entries, and the later packages are still judged.
- The closing line of a green step is `all N listed tests still fail on this host, each in a run of its own`.

**The texts say what is true afterwards.** The module docstring, the docstring of `exact_paths` and the comments do not say that the pattern is exact. They say that the pattern is the narrowest one `go test` has, what else it covers, and which check shows that nothing else was skipped. The docstring part "What no run can show" of the first version is replaced by the part "The observed run".

### 4.3 The observed run

**What happens.** Once, before the first test run, and only when the list has an entry for a subtest, the gate does this:

1. It asks the go command for its version and its root directory (`go env GOVERSION GOROOT`).
2. It reads `src/testing/match.go` under that root and checks that the version is exactly `go1.26.5` and that the file has the SHA-256 given in section 3. Both values are constants in the gate (`OBSERVED_GO_VERSION` and `MATCH_GO_SHA256`). If either differs, the gate stops with status 1 and a message that says what to review. No test has run then.
3. It writes a copy of that file into a temporary directory of its own. The copy differs in two places. The three lines that drop a skipped test get one more line, a call `goTestGateRecordSkipped(name)`. And a comment, one variable and the function of that name, 15 lines long, are added at the end of the file. The function appends the name and a line end to the file named by the environment variable `GO_TEST_GATE_SKIPPED_NAMES`. With the variable unset it does nothing.
4. It writes an overlay file that puts the copy in the place of the file of the toolchain.

Then, for each package with an entry for a subtest, after its first run and the check of that run have passed:

5. The gate empties the record file and runs `go test -json -count=1 -overlay <overlay file> -skip <the same pattern> <package>` with the variable set to the record file. The log shows the whole command with the variable in front of it.
6. That run has to end with status 0, and every top-level test that is not a whole-test entry has to report a verdict in it, exactly as in the first run.
7. The gate reads the record. The names in it have to be exactly the entries of the package, each once.

**What the step prints when the record and the entries differ.** One error line for each name, then the closing error of the step:

```text
::error::the gate skipped a test that is not listed: P TestA/x/custody. The entry TestA/x covers it as well, because go test reads a test path as the start of a path. An entry for a subtest must be the only test whose path starts with its own. In LIST, name a narrower subtest, or list the whole test TestA.
::error::the gate did not skip the listed P TestA/x: the observed run did not reach a test of that name, so the line skipped nothing. Correct the line in LIST, or delete it.
::error::the observed run of P wrote down a skipped test more than once: TestA/x
::error::test gate failed: P: the tests that go test skipped are not exactly the listed ones
```

When they agree, the step prints `P: the observed run passed; go test skipped exactly the listed tests of this package (N), each once`.

**Why this closes the corner.** The gate cannot see a skipped test in the output of `go test`. But a test that `-skip` drops was started by its parent first: `T.Run` was called for it, and `T.Run` asked `fullName`. The record holds every such call that ended in a drop. A neighbour named `x/...` is dropped at the moment its test starts it. Whether the test starts it always, or only when `x` did not fail, makes no difference in the gate, where `x` is skipped and `T.Run` returns `true` for it. So the audit's S12 is now an ordinary case.

**Which packages get an observed run, and why the others need none.** Only a package with at least one entry for a subtest. Today that is `es/app`. An entry for a whole test is one anchored part, `^TestName$`. It can match only a test whose full name is that one part, which is a top-level test of that name. The gate already requires `go test -list` to name it exactly once. Everything below it belongs to the entry by definition. So a whole-test entry cannot take another test with it, and a list without entries for subtests does not need the toolchain hold at all. The self-check holds that (`test_only_a_package_with_an_entry_for_a_subtest_has_an_observed_run`).

**The first run still judges.** The first run of the package uses the stock testing package, as before, and has to pass. The observed run is one more judge, not a replacement. A test that passes in the first run and fails in the second fails the gate.

**How it fails closed.**

- *A recording that does not work cannot pass.* Every entry has to be in the record. If the test binary was built without the copy, or the variable did not reach it, the record is empty, every entry is named as "did not skip", and the step exits 1. The self-check holds this with a stand-in `go` command that drops the `-overlay` flag.
- *The record file has to exist.* The gate creates it. The test binary opens it without the right to create it, and a name that cannot be written ends the test binary with a panic, so the run fails.
- *The test binary reads the variable once,* when it starts. A test that clears or changes the variable later does not switch the recording off.
- *A record that ends inside a name, that cannot be read, or that holds a name twice* fails the gate.
- *A test binary that a test starts itself* inherits the variable. If the test also gives it a `-test.skip`, what that binary drops is written into the same record, and the gate fails, because it does not guess which names came from where. Without a `-test.skip` of its own such a binary writes nothing. The usual helper-process pattern, which starts the test binary with `-test.run` only, is not affected: `es/app` passes its observed run with exactly its two names.
- *Another toolchain* stops the gate before any test runs (step 2 above).
- *Every run of the gate observes again.* `-count=1` keeps `go test` from replaying a stored result, which would write nothing down.

**What the observed run does not claim.**

- It is not a defence against test code that sets out to deceive it. A test can write into the record file, or print lines that look like the output of `go test`. The gate takes both as the testing package wrote them, as it always took the output. The docstring says so. Code that does this is in the diff of its pull request.
- It shows what `go test` skipped. It does not show what a test decided not to start. A test may start a subtest only after a listed subtest got past some point. With the listed subtest skipped it does not start that subtest, whatever its name is. An exact skip, if `go test` had one, would lose it in the same way. Nothing is skipped there that the list does not name, and the line `beside it ran: …` in the log of the first run shows which subtests did run. The self-check holds this case as it is (`test_what_a_test_does_not_start_is_not_skipped`).
- It is the record of one run. A test that starts different subtests from one run to the next is seen as it ran that time.

**The toolchain hold is the trigger for the next Go version.** The copy is built by replacing an exact piece of text in a file with an exact hash. So it cannot be applied to a file that I did not read. When the Go baseline of this repository changes, the gate fails on the first run with the new version and says what to do: read how the testing package of that version skips tests, then set the two constants. `docs_contract_test.go` holds the two constants as well, so the change also has to come to the test that already holds every other statement of the Go baseline.

### 4.4 The self-check: `.github/ci/go_test_gate_selftest.py`

90 checks in eight groups.

| Group | Checks | New or changed in this repair |
|---|---|---|
| GateScopesEachEntryToItsPackage | 19 | New: an unlisted test that skips itself counts as run; a line that is not JSON does not end the reading of a run; a module without packages fails the gate. These three kill survivors of the audit (A4, A7, A13) |
| GateSkipsExactlyTheListedSubtest | 13 | New: the tests named beside a listed subtest are the nearest ones; a subtest whose own name holds a `/` can be listed (S1); an entry that skips nothing is named, and the gate fails. Changed: where a subtest entry passes the gate, the checks also require the observed run and its closing line |
| GateShowsEveryTestItSkipped | 18 | **New group, second commit.** See the table below |
| GateChecksWhatReallyRan | 2 | Unchanged |
| GateRefusesAListItCannotTakeLiterally | 9 | Changed: the bare name `Test` (A26) and extra arguments (A51) are refused with their reasons |
| ListedTestsMustStillFail | 17 | Changed: one `go test` per entry is asserted. New: a listed test is judged without the other listed tests (T1, in both list orders); a whole listed test reports how its subtests ended |
| ListedSubtestStandsForItselfAlone | 8 | **New group, first commit, F-1 in the third step.** Neighbours named like subtests of the listed subtest, with and without a regression in them (S9, S9r); the neighbour of a nested listed subtest (S11); a subtest added under an existing entry (the shape of planted fault P-d); a listed subtest with subtests of its own (S10, the leaf rule); an entry that names no test and covers two (S8); a subtest whose own name holds a `/`, accepted alone and refused with a neighbour that goes on from its name (S1, S9h); only the entries that cover other tests are named; subtests that a listed subtest does not reach are part of it |
| WorkflowKeepsWhatTheGateDependsOn | 4 | New: the workflow file is the text that was reviewed (SHA-256). Renamed: "the three gate commands are present in order". The name no longer says "cannot be switched off" |

The 18 checks of `GateShowsEveryTestItSkipped`. Each builds a throwaway module and runs the gate with the real `go` command, unless the table says otherwise.

| Check | What it holds |
|---|---|
| `test_neighbours_named_like_subtests_of_the_listed_subtest` | S9 and S9r. The gate exits 1 and names both neighbours, whether the hidden one passes or holds a regression |
| `test_neighbour_that_starts_only_when_the_listed_subtest_did_not_fail` | **S12, the corner.** The third step exits 0 for it, as before. The gate exits 1 and names `TestStop/reg/custody`. The check also shows that the hidden subtest is real: where `reg` passes and nothing is listed, it runs and fails |
| `test_subtest_added_under_an_existing_entry` | The shape of the planted fault P-d |
| `test_entry_that_names_no_test_and_covers_two` | S8. The two covered tests are named, and the entry is named as one that skipped nothing |
| `test_neighbour_of_a_subtest_whose_own_name_holds_a_slash` | S9h |
| `test_only_the_entries_that_cover_other_tests_are_named` | Four entries in two packages, one of them too wide. Only that one is named |
| `test_what_a_test_does_not_start_is_not_skipped` | The boundary of section 4.3: both steps pass |
| `test_subtests_of_a_listed_subtest_are_part_of_it` | S10 in the gate: real subtests of a skipped subtest do not start and are not written down. The third step is what refuses such an entry |
| `test_only_a_package_with_an_entry_for_a_subtest_has_an_observed_run` | Four packages, two with an entry for a subtest. Exactly those two get a second run. A list with whole-test entries only gets none |
| `test_observed_run_has_to_pass` | A test that passes once and fails the second time fails the gate |
| `test_observed_run_has_to_run_every_test_that_is_not_listed` | A test binary that leaves a test out in the second run fails the gate |
| `test_every_run_of_the_gate_observes_again` | Two gate runs in a row both observe; no result is marked `(cached)` |
| `test_test_binary_built_without_the_recording_fails_the_gate` | A stand-in `go` drops the `-overlay` flag. Every entry is named as not skipped, exit 1 |
| `test_another_toolchain_is_refused_before_any_test_runs` | Three stand-ins: another Go version, the same version with one more line in `match.go`, and a `go env` that fails. Each time exit 1 and no test ran. With whole-test entries only, the same three stand-ins pass |
| `test_held_file_has_to_drop_skipped_tests_in_exactly_one_place` | For the day the held hash is set for the file of another Go version. The check runs a copy of the gate that holds the hash of a changed `match.go`: with no place that drops a skipped test, and with two. Each time the gate stops before any test runs. With one place the same copy goes on, which shows that it is the count that stops it |
| `test_test_that_changes_its_environment_does_not_stop_the_recording` | A test clears the variable before it starts the neighbour. The neighbour is still named |
| `test_test_binary_started_by_a_test_writes_into_the_same_record` | A test starts its own test binary with a `-test.skip`: the gate fails, once for a name that no entry covers and once for a name written twice. Without a `-test.skip` the gate passes |
| `test_record_that_a_test_meddled_with_is_not_taken` | A test removes the record file between two names: the next name cannot be written and the run fails. A test ends the record inside a name: refused |

Two checks of the first version are gone, because what they asserted is no longer true: `test_this_step_cannot_see_what_else_an_entry_for_a_subtest_skips` and `test_limit_a_neighbour_that_starts_only_when_the_listed_subtest_passes`. Both asserted that the gate exits 0 for a case it now refuses. The second one had said in its comment that it would fail on the day a run can show that subtest. It did.

### 4.5 The workflow: `.github/workflows/go.yml`

- `actions/checkout` is pinned to `3d3c42e5aac5ba805825da76410c181273ba90b1` (`v7.0.1`) and `actions/setup-go` to `d8cbb8045d7f43706b9177cceb36c1f91a6644d5` (`v7.1.0`). The comment says that both releases target the Node.js 24 runtime.
- The comments of the last three steps say what the steps now do. The comment of the step "Test" says in plain words that a package with an entry for a subtest runs a second time, that only that test binary is built with a changed copy of one file of the Go standard library, and that the installed toolchain is not changed.
- No step name and no `run:` line changed, in either commit. Triggers, permissions, concurrency, `GOTOOLCHAIN=local`, `GOFLAGS=-mod=readonly` and `cache: false` are unchanged.
- The SHA-256 of the file is `1f8937e0ffef39ec7a30b02f75b4e43c981e50c8a89bcd0eceaca453261ee126`. The self-check holds that value in `WORKFLOW_SHA256`. (At `af51f86` it was `3bdcd062…67b5`. Only comments changed since.)

**How the file is held (F-4).** The audit offered three ways. I took the first: the file is held as a whole.

- The self-check compares the SHA-256 of the raw file with `WORKFLOW_SHA256`. Any edit fails the step "Check the test gate" until the value is changed in the same change. The message prints the new value.
- `docs_contract_test.go` requires the self-check to hold the hash of the workflow file as it is. So the same edit also fails `go test` in the root package, in the step "Test" and on any other host. An edit that switches off the step that runs the self-check is therefore still caught, and one value is kept, not two.
- The line checks stay. They give a readable reason for the common mistakes.
- This also covers O-2: `GOFLAGS` reaches the gate only through this file or the runner image.

A limit that belongs to every workflow, stated plainly: a workflow cannot guard itself against a change that switches off all of its own checks. Such a change still has to edit `go.yml`, so it shows in the diff of its pull request, and it still fails `go test` on any machine that runs the root package, the Mac included. What stops it in the end is review and whether this check is required on `trunk_dev`, which I cannot read (section 11).

### 4.6 Docs: `.docs/system_overview/go_toolchain_baseline.md` and `docs_contract_test.go`

- Section 10 of the doc no longer says that the gate "skips exactly those entries". It says that the gate skips the entries, each only in the package it names. A new paragraph says why that is not enough and what the test step does about it: the second run, `go test -overlay`, the copy of `src/testing/match.go`, that the installed toolchain is not changed and no other run uses the copy, and that a change of the Go baseline has to review that file and change the gate in the same change. A third paragraph describes the step that runs every entry alone. The sentences of the first version that stated a limit are gone.
- `TestGo1265ToolchainBaselineDocsAndBuildContract` holds 13 sentences of those paragraphs where it held three before this repair, forbids the old phrase "skips exactly those entries", has the hash requirement of 4.5, and now also requires the gate to hold `OBSERVED_GO_VERSION = "go1.26.5"` and the SHA-256 of `match.go`.

## 5. Every finding of the third audit and what happened to it

| ID | Finding | Disposition | Where |
|---|---|---|---|
| F-1 | An entry for a subtest also skips every test whose path starts with its path and `/`; both steps green | **Fixed, with no limit left.** The step "Test" writes down what it skipped and fails unless that is exactly the list. The third step runs each entry alone and fails when another test starts under its path | 4.2, 4.3, 7.4, 8 |
| F-2 | The steps disagree on a subtest whose own name holds a `/`; wrong message | **Fixed.** Both accept the entry and it skips exactly that subtest. The list header says which subtests cannot be listed | 4.1, 4.2, 7.4 |
| F-3 | A listed test is judged in a run that holds other listed tests | **Fixed.** One `go test` per entry | 4.2, 7.4 |
| F-4 | The check "gate steps cannot be switched off" misses 12 of 22 workflow edits | **Fixed.** The file is held as a whole in two places. The check is renamed | 4.5, 7.4 |
| F-5 | Both pins target Node.js 20; the report deferred the update to "later" | **Fixed.** Pins moved to `v7.0.1` and `v7.1.0`, green on the runner with the same three steps, no warning in the log | 3, 4.5, 7.6 |
| RF-4 | The changed tests have not run on macOS | **Open, no byte change.** Requested again for the new head. Required before merge | 7.7 |
| O-1 | "Name the narrowest thing that fails" is a rule for people only | **Done as far as the audit's cheapest step goes.** The step prints the subtest counts of every whole-test entry. Whether a passing subtest under a whole-test entry should fail the run stays open for the coordinator or David | 4.2, 7.5 |
| O-2 | The gate obeys the `GOFLAGS` it inherits | **Covered by F-4,** as the audit says | 4.5 |
| O-3 | Limits that only hostile test code reaches, or that fail closed | **Unchanged in kind.** The list header states the two that concern naming (`#01`, characters). The observed run adds one of the same kind: a test that forges the record (4.3) | 4.1, 4.3 |
| O-4 | `result_auth_test.go` copies a struct by reflection | **Unchanged,** as both earlier audits accepted | |
| O-5 | 11 of the audit's 39 mutants survive | **7 are now killed or are the design; 4 are left alone with the reason** | 7.3 |

The six acceptance checks of section 12 of the audit, one by one:

| # | Check | Result |
|---|---|---|
| 1 | A blocking step fails when an entry for a subtest would also skip another subtest that a run can see. S9, S9r, S11 and P-d exit non-zero in a blocking step, and the self-check holds those cases. The texts say what is true. The corner no run can show is stated in the gate's own text and in the list header | **Met, and the corner is closed and not only stated.** S9, S9r, S11 and P-d now exit 1 in both blocking steps, and S12 exits 1 in the step "Test" (7.4). Self-check groups `GateShowsEveryTestItSkipped` and `ListedSubtestStandsForItselfAlone`. Texts: 4.1, 4.2, 4.6 |
| 2 | The two steps agree on a subtest whose own name holds a `/`. The list header says which subtests cannot be listed. S1 and S8 are in the self-check | **Met.** Both accept S1 and skip exactly it. S8: both steps exit 1 now. The gate names the two covered tests and the entry that skipped nothing, and the third step names the entry twice. Both are in the self-check |
| 3 | Every entry's verdict comes from a run that holds no other listed test. T1 exits 1 | **Met.** T1 exits 1 and names the stale entry |
| 4 | The workflow file is held as a whole, or the edits are caught one by one, or the name stops saying "cannot be switched off" | **Met in the first way, and the name changed as well.** All 21 edits are caught by the self-check and by the docs test |
| 5 | The pins move to releases that target Node.js 24, green on the runner with the same three steps | **Met** (7.6) |
| 6 | RF-4 unchanged: one Mac run of the changed tests at the new PR head, with its output | **Open.** Requested for `b39fa35` (7.7) |

## 6. Files touched (cumulative, against base `ae326b0`)

| Path | Kind | Changed by this repair | Summary of this repair |
|---|---|---|---|
| `.github/workflows/go.yml` | new | yes, both commits | Two action pins; comments |
| `.github/ci/environment-only-tests.txt` | new | yes, both commits | Header only. The 15 entries are unchanged |
| `.github/ci/go_test_gate.py` | new | yes, both commits | One `go test` per entry; the check that an entry for a subtest stands for itself alone; the observed run; the evidence line by nearest test; the note on subtests; texts |
| `.github/ci/go_test_gate_selftest.py` | new | yes, both commits | 90 checks; the workflow hash |
| `.docs/system_overview/go_toolchain_baseline.md` | modified | yes, both commits | Section 10 |
| `docs_contract_test.go` | modified | yes, both commits | Holds the new paragraphs; requires the self-check to hold the hash of the workflow, and the gate to hold the Go version and the hash of `match.go` |
| `remote_alpha_operator_test.go` | modified | no | As audited at `c4a84f5` |
| `es/admission/internal/reliablesubmit/replay_custody_file_test.go` | modified | no | As audited at `fada999` |
| `es/admission/result_auth_test.go` | modified | no | As audited at `fada999` |

Dependencies changed: none in the Go module. `go.mod` and `go.sum` are untouched. The two GitHub Actions moved by three and by two major versions (section 9).

## 7. Validation

Where: the same cloud container as for the second repair, linux/amd64, 4 CPUs, Go 1.26.5 with `GOTOOLCHAIN=local` and `GOFLAGS=-mod=readonly`, an unprivileged user who cannot write to the Go installation. The GitHub runner is the authority (7.6). The scripts are in the evidence folder (`container-*.txt`).

Which bytes: every run in this section used the bytes of the commit `b39fa35`. The container runs used a scratch copy whose git tree is `76d9bdc2643bbdce8f057ee2d455f94ec7bca6ae`, the committed tree. They ran before the commit, on the working tree that the commit then took unchanged: the tree hash of the scratch copy equals that of the commit. The last run of the mutants (7.3) ran after the commit, on the same scratch copy. Before it started, the four files under `.github/` there were compared with those of the commit with `cmp`. One exception in time, not in bytes: the probes on throwaway modules in 7.4 (the audit's three files, S12, the two red-team scripts and the build cache check) ran before the last change of this repair. That change added one check to the self-check (7.3). Those probes read only the gate file, whose bytes were already the committed ones then (SHA-256 `0b776c8d…e1e5`, compared with `cmp`). Everything that the first version of this report showed for `af51f86` was run again. No result here is carried over.

### 7.1 Build, vet, self-check

| Command | Result |
|---|---|
| `go mod verify` | `all modules verified` |
| `go build ./...` | exit 0 |
| `go vet ./...` | exit 0 |
| `gofmt -l docs_contract_test.go` | no output |
| `go test -count=1 -run '^TestGo1265ToolchainBaselineDocsAndBuildContract$' .` | `ok` |
| `git diff --check c4a84f5..b39fa35` | exit 0, no output |
| `python3 -I -B .github/ci/go_test_gate_selftest.py` | `Ran 90 tests in 107.646s`, `OK`. `Ran 90 tests in 54.862s`, `OK` on the runner |

### 7.2 The regression tests fail on the behavior that was blocked

The brief asked for a regression test that fails on the current behavior. I ran the committed self-check against two older gates, each beside the committed workflow file.

**Against the gate of `c4a84f5`,** the tip that the third audit blocked (SHA-256 `5eb758fc…4154`, taken with `git show`): `Ran 90 tests`, `FAILED (failures=39)`, in 34 of the 90 checks. Output: `selfcheck-on-gate-c4a84f5.log`.

**Against the gate of `af51f86`,** the first commit of this repair (SHA-256 `f3d966db…7d78`): `Ran 90 tests`, `FAILED (failures=23)`, in 20 of the 90 checks. Output: `selfcheck-on-gate-af51f86.log`. These are the checks that the second commit added or changed:

- all 18 checks of the new group `GateShowsEveryTestItSkipped`;
- `test_entry_that_skips_nothing_is_named` (both of its lines) and `test_other_subtests_of_the_same_test_stay_in_the_gate` in the group `GateSkipsExactlyTheListedSubtest`.

Against the gate of `c4a84f5` the same 20 fail, and 14 more: all 8 checks of `ListedSubtestStandsForItselfAlone`, 3 more of `GateSkipsExactlyTheListedSubtest` and 3 of `ListedTestsMustStillFail`. Those 14 belong to the first commit: F-1 in the third step, F-2, F-3, O-1, and the new wording of the evidence line and of the closing line.

Among them is `test_neighbour_that_starts_only_when_the_listed_subtest_did_not_fail`, the S12 corner: the gate of `af51f86` passes that module, and the check requires exit 1.

### 7.3 Mutants: can the self-check tell a broken gate from a working one

`mutants4.py` in the evidence folder holds 139 deliberate changes of the gate and one control. The 107 mutants of the first commit are carried over. Five of them needed their anchors moved to the new text (S1, S2, S4, S7 and C13). 32 are new, the V group.

| Group | Count | What it changes |
|---|---|---|
| R, P, S, C, O | 21, 6, 13, 16, 2 | Reading the list, the pattern, the gating runs, the checks, the log output |
| F | 21 | The third step, with F20x (below) |
| G | 7 | The evidence line of the gating step, the old "every part must have run" rule, and the audit's A4 |
| J | 4 | The audit's A7, A13, A51 and A26 |
| W | 9 | F-1 in the third step: the check that an entry for a subtest stands for itself alone |
| **V (new)** | 32 | **The observed run:** whether it is made and for which packages; whether it has to pass; each of the three ways in which the record can differ from the entries; the messages; the emptying of the record; the recorder in the test binary (when it reads the variable, whether it creates the file, whether a failed write ends the binary, at which match it writes); the version and hash checks; the overlay; the skip pattern and `-count=1` of the second run; the clean-up |
| T | 4 | O-1: the note on subtests |
| E | 4 | The audit's A5, A6, A14 and A15, expected to survive |

**Result on the committed `.github/` bytes: 134 of the 139 mutants are killed, and the five that survive are the five expected to.** The control passes all 90 checks. None of the five survivors changes what the gate does with the output of a real `go` command (`mutants4-output.txt`). No mutant was killed by an error in the self-check itself: every kill is a failed assertion.

- **All 32 V mutants are killed,** by 14 different checks.
- **V32 survived the first run, and the self-check got one more check for it.** V32 removes the guard that the held file drops skipped tests in exactly one place. With the file of Go 1.26.5 that guard never fires, because the held hash already fixes the text of the file. So V32 passed all 89 checks that the self-check had then (`mutants4-first-run-output.txt`). The guard matters on the day somebody sets the held hash for another Go version without reading the file. I added `test_held_file_has_to_drop_skipped_tests_in_exactly_one_place` (4.4), which runs a copy of the gate that holds the hash of a changed file. Then I ran all 139 mutants again, on the committed bytes. That check kills V32. The verdict of every other mutant is the same in both runs.
- **F20x survives, as a change that does nothing must.** It is my first construction of F20 from the first commit, kept for the record. It gives the name `grouped` a new value inside the loop, which does not end a loop over the old value. F20 as rebuilt ("after a package that failed as a whole, the later packages are not judged") is killed by `test_package_whose_listed_tests_do_not_start_fails_without_naming_entries`.
- **The E group survives, and I left it alone.** E1 (the first verdict of a test wins, not the last) and E2 (a test counts as started only on its `run` event) differ from the gate only for an event stream that `go test -json` does not produce: it writes one `run` event first and one verdict per test. E3 (the guard against `go list` naming a package twice) and E4 (the guard that the packages with and without entries add up) are guards that no output of a real `go` command and no accepted list can reach. The audit lists all four among its survivors and says that none of them opens the gate. Killing them would take stand-in commands that print what the real one never prints. I did not add those.
- The audit's other survivors: A4, A7, A13, A26 and A51 are killed (G7, J1, J2, J4, J3). A62 (the evidence line lists subtests of every depth) is killed as G5. A17 (every entry is always judged alone) is the design since the first commit, and its opposite, F17, is killed.

How the run was done. Every mutant asserts that the text it replaces is present exactly once, so none can be a silent no-op by a missed anchor. Each mutant runs the whole self-check in a copy of `.github/`, four at a time. To save time each run stops at its first failing check (`unittest -f`). A mutant is killed by one failing check, so the verdict is the same as that of a run of all checks, and the output names the check that failed first. The control and every survivor ran all checks.

Limits: the mutants are mine, written against my own gate. A fresh auditor should add their own.

### 7.4 Probes

**The audit's own probe files, unchanged** (copies byte-identical to `06-reaudit-evidence/rt6.py.txt`, `rt6b.py.txt`, `rt6c.py.txt`; hashes in the evidence README), against the committed gate. Each cell gives the exit status of the step "Test" and of the step "Listed tests still fail".

| Probe | What it tries | At `c4a84f5` | At `af51f86` | Now |
|---|---|---|---|---|
| S9 | Entry for subtest `reg`; two more subtests named `reg/…` pass | 0, 0 | 0, 1 | **1**, 1: both steps name `TestP/reg/custody` and `TestP/reg/identity` |
| S9r | The same, with a regression in `reg/custody` | 0, 0 | 0, 1 | **1**, 1 |
| S11 | Entry for nested `reg/custody`; a subtest named `reg/custody/deep` has a regression | 0, 0 | 0, 1 | **1**, 1 |
| S9h | Route-style names (`GET /v1`, `GET /v1/jobs`) | 1, 0 | 0, 1 | **1**, 1: both name the two tests that go on from `GET_/v1` |
| **S12** | Entry for `reg`; the test stops when `reg` fails; `reg/custody`, started after it, has a regression | 0, 0 | 0, 0 | **1**, 0: the step "Test" names `TestStop/reg/custody` |
| S8 | Entry `TestP/reg` where only `reg/custody` and `reg/identity` exist | 0, 1 | 0, 1 | **1**, 1: the step "Test" names the two tests and the entry that skipped nothing |
| S10 | Entry for a subtest that has real subtests | 0, 0 | 0, 1 | 0, 1 (the leaf rule, 4.2). In the gate the subtests of a skipped subtest do not start |
| S1 | Entry for a subtest whose own name is `reg/custody` | 1, 0 | 0, 0 | 0, 0: both accept it, and the observed run confirms that it alone was skipped |
| T1 | Listed B fails only after listed A | third step 0 | third step 1 | third step 1: names B, "it passes" |
| S5 | Whole-test entry, 2 subtests pass and 1 fails | 0, 0 | 0, 0 | 0, 0, and the line ends with `(its subtests: 2 pass, 1 fail)`. No observed run: the entry is a whole test |

- `rt6.py`: 47 probe runs. All 47 end with the same exit status as at `af51f86`. That is 45 as in the audit's own logs and the two that the first commit changed on purpose (S1 in mode `gate`, 1 to 0, and T1, 0 to 1). No probe ends with a status the script calls unexpected.
- `rt6b.py`: 5 probe runs, all with the same exit status as in the audit's log (run with `GOFLAGS=-mod=readonly -timeout=3s`, as its titles say).
- `rt6c.py`: 12 probe runs. Against `af51f86`, five differ, all in mode `gate` and all from 0 to 1: S8, S9, S9r, S9h and S11. Against the audit's own log at `c4a84f5`, nine differ: both steps for S9, S9r and S11, the gate for S8, and the third step for S9h and S10. S9h in the gate exits 1 in both logs: at `c4a84f5` for a wrong reason (F-2), now because the step names the two tests that the entry would take with it. The comparisons are in `probe-comparison.txt`.
- **S12** is not in those three files. The audit ran it by hand (`sketch-notes.txt`, part 4). `s12.sh.txt` builds the same module with the same list line. `s12.log` is the run against the committed gate, and `s12-gate-af51f86.log` the run against the gate of the first commit.

**The planted fault P-d on the real tree** (`plant-d.diff` of the audit, unchanged, on a scratch clone of the committed tree; gate and list unchanged):

| Step | At `af51f86` | Now |
|---|---|---|
| `gate` | exit 0. The step could not see the planted subtest | **exit 1** in 464 s. The first run of `es/app` passes. Its observed run names the planted subtest: `::error::the gate skipped a test that is not listed: execution-substrate/es/app TestSupportedLocalSetupExactGoPreflightBeforeMutation/local_build_path_rejects_missing_Go_before_mutation/planted_second_subtest. The entry TestSupportedLocalSetupExactGoPreflightBeforeMutation/local_build_path_rejects_missing_Go_before_mutation covers it as well, …`. Every other package passes, and the step ends with `test gate failed: execution-substrate/es/app: the tests that go test skipped are not exactly the listed ones` |
| `still-failing` | exit 1, names the planted subtest | exit 1, with the same line as before: `listed subtest is not the only test under its path: execution-substrate/es/app TestSupportedLocalSetupExactGoPreflightBeforeMutation/local_build_path_rejects_missing_Go_before_mutation also covers …/planted_second_subtest` |

In this container the third step is red for another reason as well: three listed tests pass here (7.5). To show that the planted subtest alone turns it red, I ran the step with a copy of the list that lacks those three lines (`list-container.txt`): exit 0 on the committed tree (`all 12 listed tests still fail on this host, each in a run of its own`), exit 1 on the planted tree with the one error line above and no other. The step "Test" needs no such copy. It does not depend on whether a listed test fails.

**The workflow edits (F-4).** `wf7.py` is the audit's `wf6.py` with one line changed: the constant that holds the checkout pin. 21 edits and one control, each against the workflow group of the self-check and against the docs contract test, on the committed tree:

- Control: both pass.
- **All 21 edits fail both.** That includes the twelve that survived both at `c4a84f5` (X1, X2, X3, X4, X7, X9, X11, X15, X18, X19, X21, X22).

**The two earlier red-team scripts, unchanged.** `redteam.py` of the second audit (SHA-256 `7ad071a7…0208`, 38 probes) and my `redteam_adapted.py` of the second repair (SHA-256 `0044b38c…1444`, 45 probes): every probe ends with the same exit status as in the run at `af51f86`. All 41 expectations of the adapted script hold.

**The build cache.** `cachecheck.sh.txt` builds the test binary of a throwaway package four times, in turn with and without the overlay that the gate writes. Both builds with the overlay hold the added function, both builds without it do not, and `match.go` of the toolchain has the same hash before and after (`cache-check.log`).

### 7.5 The whole gate on the real tree, in the container

| Command | Result |
|---|---|
| `python3 -I -B .github/ci/go_test_gate.py gate "$ENVIRONMENT_ONLY_TESTS"` | exit 0 in 444 s. `test gate passed: 41 packages, 3 of them with skipped entries (15 entries)`. Root package 166.1 s, `es/app` 104.9 s, the observed run of `es/app` 107.1 s, `reliablesubmit` 26.6 s |
| `… still-failing "$ENVIRONMENT_ONLY_TESTS"` | **exit 1 in 16 s, as expected in this container.** 15 runs, one per entry. 12 entries "still fail". Exactly 3 are named as passing: the three `TestRemoteAlphaRuntimeSecurityBoundary…` tests. No entry is named as covering another test |

The three entries that pass here are the container's doing, as in the second repair: it has no `systemctl` in `/usr/bin` or `/bin` and no modprobe configuration that blocks `algif_aead`. On the runner all 15 fail (7.6).

The part of the gate log that is new (complete in `container-gate.log`; the two "ran without the listed" lines before it are as in the first version):

```text
execution-substrate/es/app: observed run, with every test that -skip drops written down
+ GO_TEST_GATE_SKIPPED_NAMES=/tmp/go-test-gate-dk7lgi4a/skipped-names.txt go test -json -count=1 -overlay /tmp/go-test-gate-dk7lgi4a/overlay.json -skip '^TestSupportedLocalSetupExactGoPreflightBeforeMutation$/^local_build_path_rejects_missing_Go_before_mutation$|^TestSupportedLocalProofExactGoPreflightBeforeMutation$/^local_build_path_rejects_missing_Go_before_mutation$' execution-substrate/es/app
PASS
ok  	execution-substrate/es/app	107.134s
execution-substrate/es/app: the observed run passed; go test skipped exactly the listed tests of this package (2), each once
```

The notes on whole-test entries are as in the first version: `(its subtests: 4 pass, 18 fail)`, `(its subtests: 11 pass, 4 fail)`, `(its subtests: 2 fail)` and `(its subtests: 6 fail)`.

An earlier run of both commands, on the tree before the last additions to the gate's docstring and to the self-check, gave the same results (gate exit 0 in 451 s, third step exit 1 in 14 s with the same three names).

### 7.6 On the GitHub runner (authoritative)

Run [45021679869](https://github.com/evo-agi/Execution-Substrate/actions/runs/45021679869), job 137205773120, event `pull_request`, head `b39fa35d444a4bd87a3901287bb6a346577c81b9`. Runner image `ubuntu-24.04`, version `20261116.133.1` (the run at `af51f86` had `20261116.376.1`). Started 12:19:33, completed 12:27:30, conclusion **success**. The complete log (778 lines, SHA-256 `44a91f56…88b4`) is in the evidence folder as `runner-run-45021679869-job-137205773120.log`. I read it directly.

| Step | Result | Time |
|---|---|---|
| Check out | success, `actions/checkout@3d3c42e5aac5ba805825da76410c181273ba90b1`, `persist-credentials: false` | 5 s |
| Set up Go from go.mod | success, `actions/setup-go@d8cbb8045d7f43706b9177cceb36c1f91a6644d5`, `cache: false`. Go 1.26.5 installed | 6 s |
| Download modules | success | 1 s |
| Verify module downloads | success, `all modules verified` | 1 s |
| Build | success | 21 s |
| Vet | success | 8 s |
| Check the test gate | success. `Ran 90 tests in 54.862s`, `OK`, and 90 lines that end with `ok` | 55 s |
| Test | success. `test gate passed: 41 packages, 3 of them with skipped entries (15 entries)` | 6 m 2 s |
| Listed tests still fail | success. 15 runs, 15 lines `still fails: …`, then `all 15 listed tests still fail on this host, each in a run of its own` | 13 s |

The step times are the start and end times that GitHub reports for each step, in whole seconds.

**The observed run on the runner.** These are the lines of the step "Test" for `es/app`, from 12:23:19 to 12:25:26, without their time stamps. The first command is the first run of the package, with the stock testing package. The second is the observed run.

```text
+ go test -json -count=1 -skip '^TestSupportedLocalSetupExactGoPreflightBeforeMutation$/^local_build_path_rejects_missing_Go_before_mutation$|^TestSupportedLocalProofExactGoPreflightBeforeMutation$/^local_build_path_rejects_missing_Go_before_mutation$' execution-substrate/es/app
PASS
ok  	execution-substrate/es/app	64.620s
execution-substrate/es/app: TestSupportedLocalSetupExactGoPreflightBeforeMutation ran without the listed local_build_path_rejects_missing_Go_before_mutation; beside it ran: local_build_path_accepts_exact_Go_at_bounded_sentinel pass, local_build_path_rejects_wrong_Go_before_mutation pass, prebuilt_inputs_do_not_create_a_false_no_local_Go_bypass pass
execution-substrate/es/app: TestSupportedLocalProofExactGoPreflightBeforeMutation ran without the listed local_build_path_rejects_missing_Go_before_mutation; beside it ran: local_build_path_accepts_exact_Go_at_bounded_sentinel pass, local_build_path_rejects_wrong_Go_before_mutation pass, prebuilt_spire_does_not_create_a_false_no_local_Go_bypass pass
execution-substrate/es/app: observed run, with every test that -skip drops written down
+ GO_TEST_GATE_SKIPPED_NAMES=/tmp/go-test-gate-mkv3u_x5/skipped-names.txt go test -json -count=1 -overlay /tmp/go-test-gate-mkv3u_x5/overlay.json -skip '^TestSupportedLocalSetupExactGoPreflightBeforeMutation$/^local_build_path_rejects_missing_Go_before_mutation$|^TestSupportedLocalProofExactGoPreflightBeforeMutation$/^local_build_path_rejects_missing_Go_before_mutation$' execution-substrate/es/app
PASS
ok  	execution-substrate/es/app	61.348s
execution-substrate/es/app: the observed run passed; go test skipped exactly the listed tests of this package (2), each once
```

What these lines show, and what else I checked in the log:

- **The gate skipped exactly the two listed subtests of `es/app` on the runner, each once.** That is the closing line above. No other package got a second run: the command with `-overlay` occurs once in the log.
- **The toolchain hold passed on the runner's own Go.** The gate ran `go env GOVERSION GOROOT` at 12:21:20, before the first test run. The setup step had installed Go 1.26.5 from GitHub's `actions/go-versions` build, under `/opt/hostedtoolcache/go/1.26.5/x64`. The gate went on, so `src/testing/match.go` of that build has the SHA-256 that the gate holds. It is the same file as in the container's Go.
- **Check 5, the new pins are green with the same three steps:** they are, and the log holds no `##[warning]` and no `##[error]` line at all (`grep -c` gives 0 for both). The word "deprecated" does not occur in it.
- **Check 1 and 3, every entry runs alone and stands for itself:** the step "Listed tests still fail" holds 15 log groups "Expected failure of the listed …" and 15 commands `go test -json -count=1 -run …`, one per entry. All 15 entries fail on the runner. No entry is named as covering another test, and the log holds no `::error` line.
- **O-1 on the runner:** the notes on the whole-test entries read as in the container: `(its subtests: 4 pass, 18 fail)`, `(its subtests: 11 pass, 4 fail)`, `(its subtests: 2 fail)` and `(its subtests: 6 fail)`.
- **All 21 packages that have tests report `ok`,** `es/app` twice, so the step "Test" holds 22 such lines. Root package 117.9 s, `es/admission` 75.8 s, `es/app` 64.6 s and 61.3 s, `reliablesubmit` 20.3 s.
- **No cache was restored.** The setup step shows `cache: false`, the log holds no cache restore line, and no test result is marked `(cached)`.

**What the new check cost in this run.** The job took 7 m 57 s. The run at `af51f86` took 5 m 48 s. Of the 2 m 9 s between them:

- 63 s are the observed run, from its command line at 12:24:24.14 to its closing line at 12:25:26.93.
- 16 s are the self-check, which has 16 more checks (54.9 s against 38.8 s).
- The rest is not from this change. Inference: it is the machine. The root package, which runs once with the same command as before, took 117.9 s against 83.5 s, and `es/admission` 75.8 s against 69.7 s. The header of this log says `Cloud: AWS` and `Region: us-east-1`, that of the earlier run `Cloud: Azure` and `Region: centralus`. The run at `c4a84f5` had taken 8 m 24 s without any of these changes, with 133 s for the root package.

Limits: this is one run. The runner is green on these bytes once. The lock-timing test that PR #16 fixes is still the old one on this branch.

### 7.7 On David's Mac (RF-4): requested for the new head, not done

No Mac session has run for this pull request yet. I made a request for `c4a84f5` at 07:01 and withdrew it at 09:48, and one for `af51f86` at 10:30 and withdrew it at 10:44, each time so that a session cannot start on a head that is no longer the target. Neither had been approved. The request for `b39fa35` was made at 13:03, after the runner was green and the last run of the mutants had ended. It waits for David's approval on the card in the thread. It works in a temporary clone under `/Users/ds/Repositories/Playground`, touches no existing folder, pushes nothing and removes the clone at the end. It stops without installing anything if the Go on the Mac is not 1.26.5.

At PR #14's head `b39fa35`:

```bash
go test -count=1 -v -run 'TestReplayExistingStateModeNotRepaired|TestRetainedResultAuthReaderNeedsVerifierEvenForExistingPair' ./es/admission/...
go test -count=1 -v -run '^TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSpireBundleReadClassifiesTraversalAmbiguityWithSudoVisibleInspection$' .
go test -count=1 -v -run '^TestGo1265ToolchainBaselineDocsAndBuildContract$' .
python3 -I -B .github/ci/go_test_gate_selftest.py
```

The last command is where the observed run meets macOS: the group `GateShowsEveryTestItSkipped` and several other checks make observed runs there with the Mac's own Go.

At PR #16's head `0a069ec` (unchanged):

```bash
go test -count=20 -run '^TestSQLiteClaimStoreTwoHandlesBusyTimeoutAndHelperProcessContention$' ./es/admission/internal/reliablesubmit
go test -count=1 -v -run 'TestSQLiteClaimStore' ./es/admission/internal/reliablesubmit
```

The output will be added to this folder as `08-mac-run.md`. It changes no bytes, so it does not move the audit target.

### 7.8 Failed or skipped validation

- **Skipped, needs David:** the Mac run (7.7). Nothing in this report is a macOS result.
- **Failed as expected, not a defect:** the third step exits 1 in the cloud container, because three listed tests pass there (7.5). On the runner it exits 0.
- **Not run:** the race detector, and any second runner run of the same bytes.
- **Failed and fixed during the work, all before the commit `b39fa35`:**
  - Three of my new self-checks were wrong as I first wrote them. In each case the fixture or the expectation was wrong, not the gate: a module that was put together wrongly, a helper process that would have failed for its own reasons, and an expected set of tests that forgot that the two runs of a package both leave their marks. I rebuilt them before the first whole run.
  - Four older mutants no longer applied to the new text of the gate and one used a variable that no longer exists. I moved their anchors (7.3).
  - The mutant V32 survived the first run of the mutants. I added a check that kills it and ran all mutants again (7.3).
  - From the first commit: the mutant F20 that I had built wrong, and a first run of `rt6b.py` without the audit's short timeout, which I stopped when it hung as that probe is meant to.
- No test was weakened, skipped or removed to get a pass. No entry was added to or removed from the list.

## 8. The corner that the first version left open, and how it is closed

**What it was.** A test `TestA` has a subtest `x` that fails on the runner for a host reason, so `x` is listed. `TestA` also has a subtest whose own name is `x/...`, and it starts that subtest only when `x` did not fail:

```go
if !t.Run("x", ...) { return }
t.Run("x/custody", ...)
```

In the step "Test" `x` is skipped. `t.Run` returns `true` for a skipped subtest, so `TestA` goes on and reaches `x/custody`. The skip pattern for `x` covers `x/custody` too, so it does not run, and nothing in the output of `go test` says so. In the third step `x` runs and fails, `TestA` stops, and `x/custody` never starts. At `af51f86` both steps were green, and a real test with its own verdict was outside the gate.

**What the first version said.** That no run can show it, and that a rule for people in the list header covers it. The first half was true only for runs of the entry. I had not asked what the gating run itself can be made to tell. The second half was the kind of rule that the project instructions rule out.

**How it is closed.** In the gating run the missing subtest is not invisible to `go test`. It is started and then dropped, at one place in the testing package. The observed run asks that place (section 4.3). On the audit's own S12 module the step "Test" now ends like this (`s12.log`):

```text
::error::the gate skipped a test that is not listed: synth/a TestStop/reg/custody. The entry TestStop/reg covers it as well, because go test reads a test path as the start of a path. An entry for a subtest must be the only test whose path starts with its own. In list.txt, name a narrower subtest, or list the whole test TestStop.
::error::test gate failed: synth/a: the tests that go test skipped are not exactly the listed ones
gate exit 1
```

The gate of `af51f86` exits 0 for the same module in both steps (`s12-gate-af51f86.log`).

**Why I hold it to be sound, in four steps.**

1. Every test that `-skip` drops goes through the three lines in `fullName` that the copy extends. There is no other place (section 3).
2. The record is complete or the run fails: the file has to exist, a name that cannot be written ends the test binary, and the variable is read once at the start.
3. The record is checked for equality with the entries of the package. A name too many, a name too few and a name twice each fail the step. Because every entry has to be in the record, a recording that does not work cannot pass for a clean run.
4. The copy can only be made from the one file that I read: the version and the hash are held, and both are held a second time in the docs contract test.

**What it does not claim** is in section 4.3: no defence against test code that forges the record, and no statement about subtests that a test decides not to start.

**The three options of the first version** (accept the limit, allow whole-test entries only, port the two `es/app` tests first) are no longer needed. Entries for subtests stay, the six `es/app` subtests that pass on the runner stay in the gate, and nothing has to be ported first.

## 9. Authority, security and protocol widening; hygiene

- **Authority, security, protocol:** no widening. The workflow keeps `permissions: contents: read`, no secrets, no credentials persisted, actions pinned to full SHAs.
- **The observed run is the one new thing to weigh, so here it is in plain words.** In every CI run one test binary, that of `es/app`, is built a second time with a changed copy of one file of the Go standard library, and the tests of that package run a second time in it.
  - The copy is made from the file of the installed toolchain, and only if that file has the hash that the gate holds. Nothing is downloaded.
  - The change is two additions that anyone can read in the gate's source: the constants `RECORDING_SKIP_BRANCH` and `RECORDER`. The added function does one thing: it appends the name of a test to the file that the gate names.
  - The copy, the overlay file and the record live in a directory that the gate creates with `mkdtemp` and removes at its end, also when it fails. Wherever the self-check looks at an observed run, it also requires that directory to be gone.
  - The installed toolchain is only read. In the container the test user cannot write to it, and the hash of `match.go` was the same before and after all runs.
  - A build without `-overlay` does not get the changed package from the build cache (`cache-check.log`). On the runner the workflow restores and saves no cache anyway.
  - The first run of the package, with the stock testing package, still has to pass. The second run can only add a failure.
- **The action updates are the one supply-chain change.** Both actions moved across major versions (checkout 4 to 7, setup-go 5 to 7). I did not read the code of the new releases. I read the tags and `action.yml` at the pinned commits (section 3). Both are GitHub's own actions, pinned by commit, running with a read-only token and no secrets. The auditor may want to read the release notes of the versions in between.
- **One visible difference in the new checkout release.** During the fetch it keeps the token in a file under the runner's temp directory and points the repository's git config at that file. The old release wrote the token into the git config itself. With `persist-credentials: false` the new release removes the file and the config entries inside the checkout step, before any other step runs. So the setting still means what the workflow relies on: no repository code runs with the token in reach.
- **Cross-repo impact:** none.
- **Dependencies:** none changed in the Go module.
- **Artifact hygiene:** the working tree was clean after the commit. All scratch copies, logs, manifests and the fetched action objects were outside the repository. Nothing in the repository was created by validation.
- **Remote state touched by this repair:** two fast-forward pushes to `claude/project-thread-sqldt7-ci` (`af51f86` at 10:20 and `b39fa35` at 12:19) and two PR body updates. No force-push, no branch or tag deleted, nothing merged. PR #16 and its branch were not touched. In the project thread: one decision card posted at 10:35 and withdrawn at 10:44, two requests for a Mac session withdrawn before anyone approved them, and the request of 13:03 that is open (section 7.7).

## 10. Follow-up this creates for PR #12, PR #13 and every later change

- **Every change of `.github/workflows/go.yml` has to set `WORKFLOW_SHA256` in `.github/ci/go_test_gate_selftest.py` in the same change.** Otherwise the self-check and the docs contract test fail, and the message prints the value to set.
- **Every change of the Go version has to set `OBSERVED_GO_VERSION` and `MATCH_GO_SHA256` in `.github/ci/go_test_gate.py`, and the same two values in `docs_contract_test.go`, in the same change.** Before that, somebody has to read `fullName` in `src/testing/match.go` of the new version and confirm that it is still the one place where `-skip` drops a test. If the text of that place changed, the constant `SKIP_BRANCH` has to follow. Until then the gate stops before any test runs and says this. That holds for as long as the list has an entry for a subtest.
- The entry that PR #12 adds is a whole-test entry. It is not affected by the rules for subtests, and its package gets no second run:

```text
execution-substrate/es/admission/internal/reliablesubmit TestOperationalHandoffSchema4BinaryRefusesSchema5
```

  It must fail on the runner, as before. It gets a run of its own in the third step.
- A new entry for a subtest needs no reading of its test by a person anymore. Both steps check it. Its package then runs twice in the step "Test". For `es/app` that is about a minute on the runner (63 s in the run of 7.6). For the root package it would be between one and a half and two minutes (its one run took 83.5 s and 117.9 s in the two runner runs of this repair).
- Porting the two `es/app` tests so that they pass on the runner removes the two entries for subtests, and with them the second run and the toolchain hold. That remains the way to shorten the list.

## 11. Assumptions, unresolved seams, uninspected areas

- **Mac run (RF-4):** not done. Needs David's approval on the Mac.
- **Whether the check is a required status check on `trunk_dev`:** Unknown, as before. I cannot read branch protection. It is the last line behind F-4 (4.5).
- **Whether a passing subtest under a whole-test entry should fail the run (O-1):** open for the coordinator or David, as the audit left it. Today it is printed, not enforced. Two entries are whole on purpose and would need a marker.
- **Nothing forces the ports themselves to happen,** and eight root entries would pass with an account `ds` and `/private/tmp` on the runner. Both are David's, as all three audits said. Unchanged.
- **That `fullName` is the only place where `-skip` drops a test** rests on my reading and my search of the testing package of Go 1.26.5 (section 3). The auditor should repeat both.
- **That a build without `-overlay` never gets the changed package from the build cache** rests on an experiment (`cache-check.log`) and on how I understand the build cache, which keys a package by the content of its files. I did not read the source of the go command for it. If it were wrong, later runs in the same job would use a testing package whose added function does nothing without the variable.
- **The code of the new action releases:** not read (section 9).
- **The self-check on macOS:** not yet run there. Inference: it runs, provided the Go on the Mac is 1.26.5. The file `match.go` is the same in every distribution of one Go release, because it is source. With another Go version the checks that make an observed run fail there and say why. The Mac run includes the self-check.
- **Uninspected:** the Remote Alpha scripts; macOS behavior of anything; the race detector; the source of the go command.

## 12. For the next audit

- Target: section 2. Reproduce the cumulative manifest first.
- Read `src/testing/match.go` of Go 1.26.5 against both arguments in section 3: what a pattern can match, and that one place drops a skipped test. The repair rests on them.
- Read `recording_overlay`, `observed_run` and `gated_runs` in the gate, and the constants above them. Together about 220 lines.
- **The red-team question for the second commit:** make the step "Test" pass while `go test` skips a test that is not listed, without forging the record. Section 4.4 lists what I tried.
- Re-run your own `rt6.py`, `rt6b.py` (with `-timeout=3s` in `GOFLAGS`) and `rt6c.py`, the S12 module (`s12.sh.txt`) and the planted fault P-d. Expected statuses are in 7.4.
- Re-run `wf7.py.txt`, or your `wf6.py` with the checkout constant changed.
- Re-run `mutants4.py.txt` with the whole `.github/` tree copied per mutant (the script does that). `MUTANT_WHOLE=1` runs every check for every mutant. Add mutants of your own.
- Judge the boundary "what a test does not start is not skipped" (4.3).
- Judge the leaf rule, which the third step keeps (4.2): a subtest with subtests of its own cannot be an entry.
- Judge the survivors among the mutants (7.3).
- Read the runner log of the run named in 7.6 for: the 90 self-check lines, the two "ran without the listed" lines, the command of the observed run and its closing line, 15 "still fails" lines, the closing line, and the absence of error and warning annotations.

## 13. Confidence

| | Level | Why |
|---|---|---|
| Provenance | 0.97 | Manifests taken twice and reproduced from GitHub in a fresh clone: cumulative, repair-only and the second commit alone. The staged set equals the manifest set. Clean status after one commit. The committed tree is the tree that validation ran on |
| Validation | 0.9 | The runner is green on the committed bytes, and its log holds every line the acceptance checks ask for. The self-check, the mutants, the audit's own probes and planted fault, the workflow edits and the whole gate ran in the container. Missing: any macOS run, and a second runner run of the same bytes |
| Implementation | 0.88 | The check for F-1 no longer rests on an argument about what a pattern cannot do alone. It reads the decision of `go test` itself, checks it for equality, and fails closed when the reading does not work. Remaining risk: a way to drop a test that I did not find in the testing package; behavior of `-overlay` or of the build cache that I did not think to test; the cost of a second run if entries for subtests spread to large packages; and the leaf rule may be stricter than a later entry wants |

## 14. Provenance detail

Recipe `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified before each run. Each manifest was written twice into a fresh mode-0700 directory outside the repository and compared with `cmp`.

Sequence for the second commit (provenance §5.5). The sequence for `af51f86` was the same and is in the first version of this report.

1. `origin/trunk_dev` re-fetched: `ae326b0…`, unchanged. HEAD at `af51f86`, the change in the working tree, nothing staged, upstream pinned to `origin/trunk_dev`: manifest of the second commit alone, twice, identical.
2. `git reset --mixed c4a84f5…`, upstream pinned: repair-only manifest, twice, identical.
3. `git reset --mixed ae326b0…`, upstream pinned: cumulative manifest, twice, identical.
4. `git reset --mixed af51f86…`, `git add -A`. The staged path set equals the path set of the manifest of the second commit (6 paths, compared with `cmp`). The bytes in the working tree still had the hashes of the manifest.
5. One commit, `b39fa35d444a4bd87a3901287bb6a346577c81b9`. `git status --porcelain` empty. `git rev-parse HEAD^{tree}` is `76d9bdc2643bbdce8f057ee2d455f94ec7bca6ae`, the tree that validation ran on.
6. `git push` at 12:19: `af51f86..b39fa35`, fast-forward.
7. Fresh clone from GitHub, provenance §5.3: byte-identical to the cumulative manifest, twice, to the repair-only manifest and to the manifest of the second commit.

**Cumulative manifest, complete** (SHA-256 `a41367f9cd702a23d627ba1670fd64a54ce1f9b7e43bcda380b06d200ae0108e`; also `07-repair-evidence/manifest-cumulative.json`):

```json
{"branch":"claude/project-thread-sqldt7-ci","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/system_overview/go_toolchain_baseline.md","sha256":"30de363a036c24024d30f1e94b740c24e0debbcf81fa52cd72d102781d8b4599","size":6711},{"file_type":"regular","kind":"untracked","mode":"0644","path":".github/ci/environment-only-tests.txt","sha256":"5c6c89061ffcf77c2137ef0858ff0761993b5acb103c27da079f472dcd90c74a","size":5705},{"file_type":"regular","kind":"untracked","mode":"0644","path":".github/ci/go_test_gate.py","sha256":"0b776c8db374f80fc1632387da75e06a4ca21a06b3bb146923088cf51a44e1e5","size":30144},{"file_type":"regular","kind":"untracked","mode":"0644","path":".github/ci/go_test_gate_selftest.py","sha256":"f388d970c2b95da93407bf34e11007f034a7c115e1c55110d26b8f6d7817e908","size":92269},{"file_type":"regular","kind":"untracked","mode":"0644","path":".github/workflows/go.yml","sha256":"1f8937e0ffef39ec7a30b02f75b4e43c981e50c8a89bcd0eceaca453261ee126","size":3824},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"59baf4de4de02b03c5b888d9e9d8f9af301919b48535d89a6dc591b26e06949b","size":804510},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_file_test.go","sha256":"0cec866cf2e659c58a90eeb46f3edf75d9743db21c0c87aaad65d72462c3a2d9","size":70129},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/result_auth_test.go","sha256":"adab4be23f1d1f74bbc6bccd3e49235d8e95e0b5c6e2c4121930578c0e72f87c","size":18293},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"remote_alpha_operator_test.go","sha256":"efa79af1ac61541a9ba92a20ea3ef1b7cff2bcfa7eb587cc723efe1eee15d59a","size":279122}],"head":"ae326b0ddc30ec6b35883ee32945c622405b68b6","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"211aed80b98c8b2e686a27711437826a8d6160ff4ca9d9a1608cea605121d1c2","upstream":"origin/trunk_dev"}
```

**Repair-only manifest, complete** (SHA-256 `bc70bcdc52935d560c06950ee0c052907edf7efb957a10b48f3832aac70cf1ff`; also `manifest-repair-only.json`):

```json
{"branch":"claude/project-thread-sqldt7-ci","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/system_overview/go_toolchain_baseline.md","sha256":"30de363a036c24024d30f1e94b740c24e0debbcf81fa52cd72d102781d8b4599","size":6711},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".github/ci/environment-only-tests.txt","sha256":"5c6c89061ffcf77c2137ef0858ff0761993b5acb103c27da079f472dcd90c74a","size":5705},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".github/ci/go_test_gate.py","sha256":"0b776c8db374f80fc1632387da75e06a4ca21a06b3bb146923088cf51a44e1e5","size":30144},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".github/ci/go_test_gate_selftest.py","sha256":"f388d970c2b95da93407bf34e11007f034a7c115e1c55110d26b8f6d7817e908","size":92269},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".github/workflows/go.yml","sha256":"1f8937e0ffef39ec7a30b02f75b4e43c981e50c8a89bcd0eceaca453261ee126","size":3824},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"59baf4de4de02b03c5b888d9e9d8f9af301919b48535d89a6dc591b26e06949b","size":804510}],"head":"c4a84f5695500cca2087abefb8027afd700f35e2","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"27e8dd6f3b6a145e34d50826c797289213ba093c3250547e9b65c0de66128767","upstream":"origin/trunk_dev"}
```

**Manifest of the second commit alone, complete** (SHA-256 `c195fac8dc905f52ac4c0f950c8a42849a3bc3eeb181a7fd711413e40a1928c8`; also `manifest-second-commit.json`):

```json
{"branch":"claude/project-thread-sqldt7-ci","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/system_overview/go_toolchain_baseline.md","sha256":"30de363a036c24024d30f1e94b740c24e0debbcf81fa52cd72d102781d8b4599","size":6711},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".github/ci/environment-only-tests.txt","sha256":"5c6c89061ffcf77c2137ef0858ff0761993b5acb103c27da079f472dcd90c74a","size":5705},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".github/ci/go_test_gate.py","sha256":"0b776c8db374f80fc1632387da75e06a4ca21a06b3bb146923088cf51a44e1e5","size":30144},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".github/ci/go_test_gate_selftest.py","sha256":"f388d970c2b95da93407bf34e11007f034a7c115e1c55110d26b8f6d7817e908","size":92269},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".github/workflows/go.yml","sha256":"1f8937e0ffef39ec7a30b02f75b4e43c981e50c8a89bcd0eceaca453261ee126","size":3824},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"59baf4de4de02b03c5b888d9e9d8f9af301919b48535d89a6dc591b26e06949b","size":804510}],"head":"af51f860b71cbecb3dc101c9c6fc5664f807066e","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"8a228f5654123a63e9a23e7b1d72434f27212e7f32c782b1e8b696a9ad82e944","upstream":"origin/trunk_dev"}
```

## 15. Evidence folder and report delivery

`/mnt/project-files/reports/Execution-Substrate/ci-go-workflow/07-repair-evidence/`. The README there lists every file with its SHA-256. The folder was rebuilt for this version. Every log in it is from a run on the bytes of `b39fa35`, except the one runner log that is named as the run at `af51f86`.

| File | What it is |
|---|---|
| `README.md` | The list of files with their hashes |
| `runner-run-45021679869-job-137205773120.log` | Complete log of the runner job at `b39fa35` (7.6) |
| `runner-run-45011955430-job-137175998809.log` | Complete log of the runner job at `af51f86`, kept for the comparison of the times in 7.6 |
| `container-env.sh.txt`, `container-run.py.txt`, `container-sync.sh.txt`, `container-fullgate.sh.txt`, `container-validate.sh.txt` | How the container runs were set up and started |
| `container-validation.log`, `container-selfcheck.log` | Build, vet, gofmt, the docs test and the self-check on the committed tree (7.1) |
| `container-gate.log`, `container-gate-status.txt`, `container-still-failing.log` | The whole gate and the third step on the committed tree (7.5) |
| `selfcheck-on-gate-c4a84f5.log`, `selfcheck-on-gate-af51f86.log` | The committed self-check against the two older gates (7.2) |
| `mutants4.py.txt`, `run_all4.sh.txt`, `mutants4-output.txt`, `mutants4-first-run-output.txt` | The mutants, the script that ran them, the output of the run on the committed bytes, and the output of the earlier run in which V32 survived (7.3) |
| `rt6.log`, `rt6b.log`, `rt6c.log`, `cmp_probes.py.txt`, `probe-comparison.txt` | Output of the audit's three probe files, unchanged, against the committed gate, and the comparison with the earlier logs (7.4) |
| `s12.sh.txt`, `s12.log`, `s12-gate-af51f86.log` | The audit's S12 module against the committed gate and against the gate of the first commit (7.4, 8) |
| `observed-run-match.go.diff` | What the gate changes in its copy of `src/testing/match.go`, as a diff against the file of Go 1.26.5 (4.3) |
| `cachecheck.sh.txt`, `cache-check.log` | The build cache keeps builds with and without the overlay apart (3, 7.4) |
| `plant-d-gate.log`, `plant-d-still-failing.log`, `plant-d-status.txt`, `list-container.txt`, `still-failing-12-entries-committed-tree.log`, `still-failing-12-entries-planted-tree.log` | The planted fault P-d (7.4) |
| `wf7.py.txt`, `wf7.log` | The workflow edits against the self-check and the docs test (7.4) |
| `run_probes4.sh.txt`, `redteam-original-output.txt`, `redteam-adapted-output.txt` | The two earlier red-team scripts, unchanged, against the committed gate (7.4) |
| `run_rest4.sh.txt` | The script that ran the whole gate, the planted fault, the two older gates and the workflow edits, one after the other |
| `manifest-cumulative.json`, `manifest-repair-only.json`, `manifest-second-commit.json` | The three manifests, byte for byte |

I searched the folder for tokens, keys, mail addresses and phone numbers before delivery. It holds none. The runner logs show the checkout token only as `***`.

This report: `/mnt/project-files/reports/Execution-Substrate/ci-go-workflow/07-repair.md`. Its SHA-256 is in the thread reply that delivers it, because a file cannot hold its own hash.
