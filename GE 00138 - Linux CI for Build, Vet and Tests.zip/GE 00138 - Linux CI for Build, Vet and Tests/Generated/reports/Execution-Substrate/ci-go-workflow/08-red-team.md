# Red-team report: Execution-Substrate PR #14 (Linux CI) at `b39fa35`

Stage 08 of workstream `ci-go-workflow`. Written by the red-team thread, which is separate from the writer and from the correctness audit. I did not read the fresh audit of `b39fa35` or coordinate with it. I read the writer's report `07-repair.md` (SHA-256 `690429e23ab83537aa2f4b83dc7551711113335db198e9d7bffb4a5cb8afa5e1`, verified) and searched the earlier audit reports for what they had already said about four topics.

Date of the work: 2026-11-22, 13:06 to about 13:45 UTC. All times are UTC.

## 1. Verdict

**HOLDS WITH CAVEATS.**

In plain words:

- **The fourth repair held.** I could not make the step "Test" pass while `go test -skip` dropped a test that is not in the list. I could not get a malformed or tricky list file accepted. The hold on `go.yml` and the hold on the Go version and on `src/testing/match.go` both fail closed. Section 5 lists every attack and its result.
- **Finding RT8-1 holds (medium).** A test that skips itself is outside the gate and outside the list. A broken test that is made to call `t.Skip` passes both blocking steps with no line in the list. This is not only theory: in my container 38 integration tests of `es/app` skip themselves because Docker, Nomad or Vault is missing, and a green log does not show a skip. Inference: most of them skip on the GitHub runner too (section 7 says why, and what would confirm it). The doc sentence that the list "is the single statement of what the test step excludes" is not true while that is so.
- **Three low findings (RT8-2 to RT8-4).** A package without list entries that runs none of its tests passes the gate. An entry is only judged alone, so a listed test that passes in the run of its package keeps its line for good. Nine macOS-only tests are never even compiled by CI, and a 7-second step would type-check them. None of the three has an instance on today's tree.
- **Seven observations (O-1 to O-7).** One needs David and is a repository setting: whether the check is required on `trunk_dev` (O-1).

My recommendation: repair RT8-1 before this PR merges, and RT8-2 with it, because the same change serves both. If RT8-1 is not repaired, it needs David's decision in words, the doc sentence has to change, and a green check must not be read as "the submit-flow integration tests ran". RT8-3 and RT8-4 are the coordinator's call on cost.

Seven failing checks for the four findings are on my own branch (section 8).

## 2. Target identity

| Item | Value | Source |
|---|---|---|
| Repository | `evo-agi/Execution-Substrate` | brief |
| PR under test | draft PR #14, base `trunk_dev` | brief |
| Topic branch | `claude/project-thread-sqldt7-ci` | 07-repair.md, re-read by me with `git ls-remote` at the end: still `b39fa35` |
| Commit | `b39fa35d444a4bd87a3901287bb6a346577c81b9` | brief, checked by me |
| Tree | `76d9bdc2643bbdce8f057ee2d455f94ec7bca6ae` | reproduced by me |
| Base | `trunk_dev` at `ae326b0ddc30ec6b35883ee32945c622405b68b6` | checked by me |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` | verified by me before each use |
| Cumulative manifest SHA-256 | `a41367f9cd702a23d627ba1670fd64a54ce1f9b7e43bcda380b06d200ae0108e` (2,033 bytes, 9 paths) | reproduced by me |

Provenance reproduction (repo-validated by me): fresh clone from GitHub, recipe hash checked, pushed tip equals the reported commit, `origin/trunk_dev` equals the base, the base is an ancestor of the tip, upstream pinned to `origin/trunk_dev`, recipe run twice with byte-identical output, and that output is byte-identical to the writer's `manifest-cumulative.json`. At the end I ran the recipe again in the same untouched clone: identical. So the attacks ran against the bytes the writer reported.

The three CI files I attacked, by SHA-256: `go_test_gate.py` `0b776c8d…e1e5`, `go_test_gate_selftest.py` `f388d970…e908`, `go.yml` `1f8937e0…e126`. They equal the manifest.

## 3. Posture and effects

- I changed nothing in PR #14. I pushed nothing to its branch, posted no comment and merged nothing.
- I pushed one branch of my own, `claude/project-thread-0tw2qq`, with one commit `d2117bb999fd875d16b4a093b30585b7246330b2` on top of `b39fa35`. It adds one file, `.github/ci/go_test_gate_redteam8.py`, and changes no file of PR #14. No pull request was opened. A push to that branch starts no workflow run.
- One read-only web fetch of the public list of software on GitHub's `ubuntu-24.04` runner image. No other subagent.
- No live service was contacted. The Linux box and David's Mac were not used.
- All probes ran on throwaway modules or on a clone of the tree in my container. Two plants on that clone (the seven-check file, and a compile error in a macOS-only test file) were removed afterwards, and `git status --porcelain` was empty.

## 4. What the change claims (repo-validated at `b39fa35`)

- The step "Test" skips the entries of `.github/ci/environment-only-tests.txt`, each only in its package, and runs everything else (`go_test_gate.py:41-56`).
- A package with an entry for a subtest runs a second time with a test binary that writes down every test that `-skip` drops, and the step fails unless those are exactly the entries (`go_test_gate.py:66-99`, `494-567`).
- The step "Listed tests still fail" runs every entry in a `go test` of its own and fails unless each fails and stands for itself alone (`go_test_gate.py:661-728`).
- The self-check holds `go.yml` by its SHA-256 (`go_test_gate_selftest.py:38`, `2170-2184`), and `docs_contract_test.go:1009-1012` requires that value to be the hash of the file as it is.
- The doc says the list "is the single statement of what the test step excludes" (`.docs/system_overview/go_toolchain_baseline.md:107`, held by `docs_contract_test.go:964`). It also says a green run "is not a macOS run, a race-detector run, a Linux runtime proof, a Remote Alpha proof, or a supported-local proof".

## 5. Attacks and results

"Probe" names refer to `rt8.py.txt` and its log in the evidence folder. Each probe gives the exit status of the step "Test" and of the step "Listed tests still fail".

| # | Attack | Result |
|---|---|---|
| 1 | Listed subtest `reg` and neighbours named `reg/...` all run in parallel, one neighbour broken (D1) | Held. Both steps exit 1 and name the neighbours |
| 2 | Neighbour whose name is the listed name and a trailing slash, `reg/` (D2) | Held. Both steps exit 1 |
| 3 | Neighbour started from a helper function that gets the `*testing.T`, only when `t.Failed()` is false (D3) | Held. The step "Test" exits 1 and names it |
| 4 | 17 names beside the listed `reg` that differ by case, regexp characters, spaces, a zero-width space, a Cyrillic letter, a NUL, a line end, an explicit `#01`, a repeated `reg` and an empty name (D4) | Held. All 17 ran, only `reg` was skipped, and the observed run confirmed exactly one skipped test |
| 5 | Whole-test entry `TestA` beside `TestA2`, `TestA_`, a subtest named `TestA` under another test, and a fuzz target `FuzzTestA` with a seed (D5) | Held. All of them ran |
| 6 | Failing `Example` and failing fuzz seed beside a listed subtest (F1) | Held. The step "Test" exits 1 |
| 7 | A goroutine of an earlier test panics while a later test runs (F2) | Held. The step "Test" exits 1 |
| 8 | A test that starts a sibling only after the listed subtest got past some point (E1) | Green in both steps. This is the limit that 07-repair.md section 4.3 states. See O-5 |
| 9 | **A broken test that skips itself:** top-level in a package with entries (A1), in a package without entries (A2), as a subtest beside a listed subtest (A3) | **Not held. Both steps exit 0. Finding RT8-1** |
| 10 | **A test binary that runs none of its tests, in a package without entries** (B1) | **Not held. Both steps exit 0, and the log line reads `ok synth/b`. Finding RT8-2** |
| 11 | **A listed test that fails only when it runs alone** (J1), and a listed parallel subtest whose body never runs because the test binary stops first (J2) | **Not held. The third step prints "still fails" and exits 0. Finding RT8-3** |
| 12 | **A failing test in a file that only builds on macOS** (C1), and a compile error planted in a real macOS-only test file | **Green.** The doc says a green run is not a macOS run, so no claim is broken. The plant shows that the file is not even compiled. **Finding RT8-4** |
| 13 | 50 malformed or tricky list files, each in both modes: CRLF, a lone CR, BOM, UTF-16, invalid UTF-8, NUL, tab and no-break space as separator, vertical tab, form feed, U+2028 and U+0085, indented and trailing comments, Cyrillic and fullwidth letters, a combining mark, a zero-width space, nine regexp shapes, empty parts, a trailing slash, `#01`, bare `Test`, package patterns, a package that looks like a flag, repeated and nested entries, a directory, a missing file, an empty file | Held. 100 of 100 runs ended as they should. Every malformed file is refused with status 2 before any `go` command runs. A vertical tab does not end a comment line, so no entry can hide behind one |
| 14 | Reading of `src/testing` of Go 1.26.5 for a second place where `-skip` drops a test | Held. I repeated the search. The skip filter is read only at `match.go:108`. The flag is handed to `newMatcher` at `testing.go:2566`, `benchmark.go:704`, `example.go:32`, `fuzz.go:482`, `485` and `566`, and nowhere else |
| 15 | Drift of the patched file: another Go version, another `match.go`, an overlay that is not applied | Held, by reading `recording_overlay` (`go_test_gate.py:450-491`) and by the self-check, which passes 90 of 90 here. My Go 1.26.5 came from Go's own toolchain module, a third source beside the runner's and the writer's copy, and its `match.go` has the held SHA-256 |
| 16 | Bypassing the hold on `go.yml` by accident | Held. Any byte change fails the self-check and the docs contract test. A checkout cannot differ from what GitHub runs in a way that keeps the hash: the repository has no `.gitattributes`, and Git's checkout conversions either change the hash or carry the blob's own hash. What the hold does not cover is in O-3 and O-4 |
| 17 | Test caching | Held, by reading. All four commands that run tests carry `-count=1` (`go_test_gate.py:505`, `599`, `621`, `678`) |
| 18 | The whole workflow on the real tree, each `run:` line by hand in order | The step "Check the test gate" passes 90 of 90 (79 s). The step "Test" exits 0 in 399 s with `test gate passed: 41 packages, 3 of them with skipped entries (15 entries)` and the observed run of `es/app` naming exactly its two entries. The step "Listed tests still fail" exits 1 here because five entries pass in this container (three need a host without `systemctl` or modprobe block, two need a `go` in the system directories). That is a property of the container, as 07-repair.md and project memory say |

## 6. What the census of the real tree shows

One run of `go test -json -count=1 ./...` on the tree, with nothing skipped, in my container (`census.log`):

- 1,397 top-level tests: 1,347 pass, 10 fail, 40 skip. 3,867 subtests: 3,837 pass, 30 fail, none skip.
- The 10 failures are the 10 entries that also fail alone here. The 5 entries that pass alone here pass in this run too. No test outside the entries fails. So today no entry is judged differently alone and in the run of its package (this matters for RT8-3).
- **40 tests skipped themselves.** Two are helper-process controls in `reliablesubmit` that skip by design. The other 38 are in `es/app`, and each names a missing host capability: 34 "docker daemon probe failed", 2 more for the Docker daemon or its socket, 1 "requires nomad", 1 "requires vault". They include the submit flow, execution status, logs, cancel, result bundle and lifecycle tests (`TestSubmitFlow…`, `TestExecutionStatus…`, `TestExecutionLogs…`, `TestExecutionCancel…`, `TestLifecycleScript…`).

## 7. Findings

### RT8-1: a test that skips itself is outside the gate and outside the list

- **Type / severity:** test and artifact gap, and a doc claim that is wider than the check. **Medium.**
- **Current contract:** the list "is the single statement of what the test step excludes" (`go_toolchain_baseline.md:107`, held by `docs_contract_test.go:964`). The list header: "an entry cannot outlive its reason".
- **Path and evidence:**
  - The gate counts `skip` as a verdict like `pass` (`go_test_gate.py:129`, `420-422`). The self-check holds that on purpose: `test_unlisted_test_that_skips_itself_has_run` (`go_test_gate_selftest.py:734`). Packages without entries are judged by the exit status of `go test` alone (`go_test_gate.py:621`).
  - Probes A1, A2 and A3: a test that calls `t.Skip` before a line that fails. Both steps exit 0, and nothing in the log names the test.
  - The real tree: 38 `es/app` tests skip themselves in my container (section 6).
  - **On the runner: Unknown how many skip.** A green log cannot say, because the gate prints only the output of failing tests. **Inference:** most of the 38 skip there too. Reasons: 36 of them need the `nomad` binary. 34 skip through `requireHealthyDockerBackedNomadClient`, whose probe looks `nomad` up right after the Docker daemon (`es/app/submit_integration_test.go:1870-1898`); one more reaches the same probe after a check of the Docker socket (`submit_integration_test.go:1146-1156`); and the slice 0 bringup test looks `nomad` up itself (`es/app/operator_scripts_integration_test.go:3803`). One test needs `vault` (`es/app/supported_local_proof_validation_test.go:27-31`). The last one needs only a healthy Docker daemon and would run on the runner. The published software list of the `ubuntu-24.04` runner image lists Docker client and server and neither Nomad nor Vault. I read that list for image version 20260823.283.1, not for the 20261116.133.1 of the runner run, whose page could not be fetched. Also, `es/app` took 64.6 s on the runner (thread-reported, runner log line 402) and 78.7 s here, where all 38 skip. Tests that start Nomad and containers would take far longer. **What would confirm it:** one runner run that prints skip verdicts, or `command -v nomad vault` in a step.
- **Impact:**
  - The cheapest way to get a broken test through CI is one line, `t.Skip(...)`, in the test. It needs no list entry, and neither step notices.
  - A test that skips for a host reason is excluded without a line. Nothing forces the skip out when its reason ends, and nothing shows it in a green log. That is the same defect that the second audit's RF-2 named for list entries.
  - If the inference holds, the check that will gate the next unit of work (reliable submit and its integration into the real submit path) does not run the submit-flow integration tests, and says nothing about it.
  - The doc sentence above is not true as written.
- **Required correction (my recommendation):** the gate reads the verdict of every test of every package and fails on a test or subtest that ends with `skip`, unless the list declares that skip in a second kind of line. The third step requires every declared skip to still skip on the runner. Then the list really is the single statement, and a skip cannot outlive its reason. The existing check at `go_test_gate_selftest.py:734` asserts the opposite and has to change with it. The exact set of lines comes from one runner run.
- **Other ways, each with its cost:** put Nomad and Vault on the runner so that the tests run (a larger piece of work, and the better end state). Or David decides in words that self-skips stay outside the gate. Then the doc sentence has to change, and the project instructions call such a rule prose-only.
- **Uncertainty:** the count on the runner (above).
- **Patch defect or pre-existing:** the skips are in the tests of `trunk_dev`. The claim, and the gate that does not check it, are in this PR. The third audit touched it in one line (06-reaudit.md line 268: a stricter gate is one "which the real tree would fail at once") and did not file it.

### RT8-2: a package without entries that runs none of its tests passes

- **Type / severity:** bug in the gate's own rule. **Low.**
- **Evidence:** the gate fails when a package WITH entries runs none of its tests (`go_test_gate.py:407-426`, self-check `test_listed_package_that_runs_none_of_its_tests_fails_the_gate`, line 1445). Probe B1 puts the same test binary into a package without entries: `go test` prints `ok synth/b`, the gate exits 0, and no test ran. The rule covers 3 of the 41 packages today.
- **Impact:** a `TestMain` that returns without calling `m.Run()` switches a whole package off silently. No instance today: no test file of the tree defines `TestMain` (searched at `b39fa35`).
- **Required correction:** judge every package by the rule that listed packages already have: every test that `go test -list` names reports a verdict. The repair of RT8-1 needs the verdicts of every package anyway.
- **Patch defect.**

### RT8-3: an entry is only judged alone

- **Type / severity:** test gap. **Low.**
- **Evidence:** the third step runs `go test -run <that entry>` (`go_test_gate.py:677-679`). Probe J1: a listed test that needs what an earlier test of its package leaves behind fails alone and passes in the run of its package. The step prints "still fails" and exits 0. Probe J2: a listed parallel subtest that has started and has no verdict counts as failing when `go test` fails (`go_test_gate.py:687-690`), although its body never ran.
- **Impact:** such an entry can never be forced out, so the gate keeps skipping a test that passes, and a later regression in it is invisible. It is the reverse of the third audit's F-3. No instance today (section 6).
- **Required correction:** also require every entry to fail in one run of its package with nothing skipped. Cost on the runner, from the times in 07-repair.md: about 118 s for the root package, 65 s for `es/app`, 20 s for `reliablesubmit`. If the coordinator judges that too much, the limit stays and needs David's word.
- **Patch defect** (introduced with the per-entry runs of `af51f86`).

### RT8-4: files that only build on macOS are never compiled

- **Type / severity:** test gap, hardening. **Low.**
- **Evidence:** `es/admission/execution_roots_darwin_test.go` and `es/admission/staging_custody_darwin_test.go` hold nine tests, and two more macOS-only source files stand beside them. I planted a type error in the first file: `go vet ./es/admission` and the build of the test binary pass on Linux, and `GOOS=darwin GOARCH=arm64 go vet ./es/admission` fails and names the line (`darwin-plant.log`). On the unchanged tree `GOOS=darwin GOARCH=arm64 go vet ./...` exits 0 in about 7 s (`darwin-vet.log`).
- **Impact:** a change that breaks the build of those files passes every step. Only a run on David's Mac shows it. The doc already says a green run is not a macOS run, so this breaks no claim.
- **Recommended correction:** one more step, `GOOS=darwin GOARCH=arm64 go vet ./...`. It type-checks. It does not run the tests. It is an edit of `go.yml`, so `WORKFLOW_SHA256` changes with it.
- **Pre-existing,** made visible by this PR.

### Observations

- **O-1, needs David, a repository setting. Unknown: whether "build, vet and test" is a required status check on `trunk_dev`.** `trunk_dev` and `main` are protected (GitHub branch list, read by me), and I cannot read the rules. If the check is not required, a red or missing run does not stop a merge. GitHub also documents commit-message markers such as `[skip ci]` that skip `pull_request` and `push` workflow runs. I did not test that here. With a required check a skipped run leaves the check pending and blocks the merge. One setting closes both. All three earlier audits named this as Unknown.
- **O-2. The list is, by design, the one-line way to turn a failing test green.** A change adds a line, and the third step then confirms that the test fails. Only review of the list diff stands against a newly broken test being listed. I propose no machine check. I propose a rule for the merge gate: an audit treats every added line as a finding until its host reason is shown.
- **O-3. Nothing holds the set of workflow files.** Only `go.yml` is held. A second file under `.github/workflows/` is noticed by neither the self-check nor the docs test. It cannot make the `go` check green. A cheap hold: the docs contract test requires that directory to contain only `go.yml`.
- **O-4. The toolchain hold pins one file.** The reading that `-skip` drops a test in one place covers `testing.go`, `benchmark.go`, `example.go` and `fuzz.go` as well. For an unmodified Go 1.26.5 that is the same thing, and I agree with the reading (section 5, row 14). No action needed.
- **O-5. The stated limit is real and is not hit today.** A sibling that a test starts only after the listed subtest got past some point never runs on the runner (probe E1). 07-repair.md section 4.3 and the gate's docstring say so. The list header speaks only of subtests of the listed subtest. The two tests with listed subtests start their four subtests unconditionally (`es/app/operator_scripts_integration_test.go:1716-1870`, read by me).
- **O-6. Unchanged from the third audit's O-1:** 15 passing subtests stand under two whole-test entries ("4 pass, 18 fail" and "11 pass, 4 fail"). The step prints the counts and does not enforce them. Still open for the coordinator or David.
- **O-7.** In this container the two `es/app` entries pass, because it has no `go` in the system directories. The third step is therefore red here for five entries, not three as in the writer's container.

## 8. Regression tests delivered

Branch `claude/project-thread-0tw2qq`, commit `d2117bb999fd875d16b4a093b30585b7246330b2`, one new file `.github/ci/go_test_gate_redteam8.py` (162 lines). It loads the helpers of the self-check and adds seven checks. No workflow step runs it, and no file of PR #14 is changed.

| Finding | Checks | Result at `b39fa35` |
|---|---|---|
| RT8-1 | 3: a broken test that skips itself in a package with entries, in one without, and as a subtest beside a listed subtest | 3 fail (`0 != 1`) |
| RT8-2 | 2: a package without entries that runs none of its tests, with and without a list entry elsewhere | 2 fail |
| RT8-3 | 1: a listed test that passes in the run of its package is named | 1 fails |
| RT8-4 | 1: the workflow has a step that type-checks the module for macOS | 1 fails |

Run: `python3 -I -B .github/ci/go_test_gate_redteam8.py`. Output: `Ran 7 tests`, `FAILED (failures=7)` (`redteam8-checks.log`). The committed self-check still passes 90 of 90 beside the new file. The checks assert exit statuses and test names. They do not fix the wording of a message or the form in which a repair lets a change declare a skip. They are meant to be moved into the self-check by the change that repairs each finding.

## 9. Validation: what I ran

All on the bytes of `b39fa35`, in a cloud container: linux/amd64, 4 CPUs, Go 1.26.5 with `GOTOOLCHAIN=local` and `GOFLAGS=-mod=readonly`, an unprivileged user who cannot write to the Go installation.

| Command | Result |
|---|---|
| `go mod verify`, `go build ./...`, `go vet ./...` | exit 0 each |
| `python3 -I -B .github/ci/go_test_gate_selftest.py` | `Ran 90 tests in 79.111s`, `OK` |
| `… go_test_gate.py gate "$ENVIRONMENT_ONLY_TESTS"` | exit 0 in 399 s |
| `… go_test_gate.py still-failing "$ENVIRONMENT_ONLY_TESTS"` | exit 1 in 11 s, five entries named as passing (O-7), none as covering another test |
| `go test -json -count=1 ./...` | exit 1 (the 10 entries that fail here); census in section 6 |
| `rt8.py` (15 probes) and `rt8_lists.py` (100 runs) | section 5 |
| `GOOS=darwin GOARCH=arm64 go vet ./...` | exit 0; with the plant, exit 1 |
| `go_test_gate_redteam8.py` | 7 of 7 fail |

Not re-run by me: the earlier audits' probe files (`rt6.py`, `rt6b.py`, `rt6c.py`), the S12 module, the planted fault P-d, the workflow edits (`wf7.py`) and the writer's 139 mutants. They belong to the fresh audit, and I spent the time on new ground. I wrote no mutants of my own.

## 10. Coverage the environment could not provide

- **No run on a GitHub runner.** I may not push to the PR, and my own branch starts no run. So the image, GitHub's own handling of triggers, concurrency and permissions, and the skip count on the runner are not observed by me.
- **No `act`.** The container has a Docker client and no Docker daemon. I ran each `run:` line of the workflow by hand, in order, with the workflow's environment.
- **No macOS run.** The cross type check in RT8-4 compiles for macOS. It runs nothing there.
- **No Docker daemon, Nomad or Vault** in the container, so the 38 integration tests of section 6 did not run for me either.
- **Branch protection and Actions settings:** not readable (O-1).
- **The race detector:** not run.

## 11. Sensitive material

None handled. The evidence folder holds logs of test runs on throwaway modules and on the tree. I searched it for tokens, keys, mail addresses and phone numbers before delivery and found none. The raw JSON of the census run (4.7 MB) is not in the folder.

## 12. Confidence

| | Level | Why |
|---|---|---|
| Provenance | 0.97 | Manifest reproduced from a fresh clone, twice, and again at the end. The PR branch was still at `b39fa35` when I finished |
| Validation | 0.85 | Every result in this report is from a run I made on those bytes. Missing: the runner, macOS, the earlier probe files, mutants |
| That the fourth repair holds | 0.85 | The record of skipped tests is compared for equality and fails closed. I found no honest test shape that gets past it, and I re-read the one place in the Go source that it rests on |
| RT8-1 as stated | 0.9 for the mechanism (shown), 0.75 for "most of the 38 skip on the runner" (inferred) | Section 7 |

## 13. How to reproduce

In a clone of `b39fa35` with Go 1.26.5, as a user that is not root:

```bash
python3 -I -B rt8.py .github/ci/go_test_gate.py          # the 15 probes
python3 -I -B rt8_lists.py .github/ci/go_test_gate.py    # the list files
go test -json -count=1 ./... > all.json; python3 -I census.py all.json .github/ci/environment-only-tests.txt
git fetch origin claude/project-thread-0tw2qq && git checkout FETCH_HEAD
python3 -I -B .github/ci/go_test_gate_redteam8.py        # 7 failing checks
```

The scripts are in the evidence folder with the suffix `.txt`.

## 14. Effect status

TOPIC_BRANCH_OF_PR_14_NOT_TOUCHED · OWN_BRANCH_PUSHED (`claude/project-thread-0tw2qq` at `d2117bb`) · NO_PR_OPENED · NO_COMMENT_POSTED · MERGE_NOT_PERFORMED · REPAIR_NOT_PERFORMED · LIVE_SERVICES_NOT_CONTACTED

## 15. Report delivery

This report: `/mnt/project-files/reports/Execution-Substrate/ci-go-workflow/08-red-team.md`. Its SHA-256 is in the thread reply that delivers it. Evidence: `/mnt/project-files/reports/Execution-Substrate/ci-go-workflow/08-red-team-evidence/`, whose `README.md` lists every file with its SHA-256.
