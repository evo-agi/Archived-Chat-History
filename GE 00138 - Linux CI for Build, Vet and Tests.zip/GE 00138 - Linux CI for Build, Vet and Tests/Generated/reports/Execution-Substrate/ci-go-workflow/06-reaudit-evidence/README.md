# Evidence for `06-reaudit.md`

Re-audit and red-team of Execution-Substrate PR #14 at `c4a84f5` and PR #16 at `0a069ec`, 2026-11-22 (UTC). Everything here was produced by the audit thread in its own cloud container. Nothing in this folder was run against a live service. Scripts carry the extra suffix `.txt` so that nothing here can be run by accident.

The report says which finding each file supports. Paths inside the logs (`/home/ci/...`, `/opt/audit/...`) are paths in the audit container.

## Provenance

| File | What it is |
|---|---|
| `manifest-pr14-open.json`, `manifest-pr14-close.json` | v2 manifest of PR #14, at the start and at the end of the audit. Byte-identical. |
| `manifest-pr16-open.json`, `manifest-pr16-close.json` | The same for PR #16. |
| `runner-run-44996283604-job-137127901877.log` | The runner log of the green run at `c4a84f5`, downloaded by the audit thread. Byte-identical to the writer's copy in `05-repair-evidence/`. |

## Container setup and the baseline on the exact bytes

| File | What it is |
|---|---|
| `setup.sh.txt`, `ci-env.sh.txt`, `asci.py.txt` | Container setup, the environment of every run, and the wrapper that runs a command as the unprivileged user `ci`. |
| `pr14-base-run.sh.txt`, `base-run.log` | Build, vet, gofmt, darwin vet, self-check, whole gate, still-failing on a clean clone at `c4a84f5`. |
| `selftest-1.log`, `gate-1.log`, `still-1.log` | Full output of the self-check, the gate and the still-failing step of that run. |
| `alone.py.txt`, `alone.log` | Each of the 15 list lines judged on its own with the gate's own function (finding F-3). |

## Faults planted on the real tree (scratch clone at `c4a84f5`, gate and list unchanged)

| File | What it is |
|---|---|
| `plant-run.sh.txt`, `plant-run.log` | P-b (RF-1), P-c (RF-2), P-a (RF-3). |
| `plant-dup-gate.log`, `plant-dup-still-failing.log`, `plant-still.log`, `plant-gate.log` | Full outputs of those three. |
| `plant-a-c.diff` | The planted changes for P-c and P-a. P-b was one added file with a second definition of a listed test name in `package reliablesubmit_test`; the script deletes it after the run. |
| `plant-d.diff`, `plant-d-run.sh.txt`, `plant-d-run.log`, `plant-d-gate.log`, `plant-d-still.log` | P-d: one subtest planted under today's `es/app` list line (finding F-1). |

## Probes on throwaway modules

| File | What it is |
|---|---|
| `rt6.py.txt`, `rt6-STU.log`, `rt6-VW.log` | Probes S1 to S5, T1 to T7, U1 to U3, V1 to V5, W01 to W92. |
| `rt6b.py.txt`, `rt6b.log` | Probes T8, T9, T10, S6, S7. |
| `rt6c.py.txt`, `rt6c.log` | Probes S8, S9, S9r, S9h, S10, S11: subtests whose own names hold a `/` (findings F-1 and F-2). |
| `leaf_sketch.py.txt`, `sketch6.sh.txt`, `sketch-notes.txt` | The advisory sketch for F-1 (not a patch), its runs on the real tree, on the P-d clone and on a throwaway module, probe S12 (the corner no run can show), and the check that JSON output carries no nesting depth. |
| `redteam-orig.log` | The earlier re-audit's `redteam.py` (`04-reaudit-evidence/redteam.py.txt`, unchanged) on the gate at `c4a84f5`. |
| `redteam-adapted.log` | The writer's `redteam_adapted.py` (`05-repair-evidence/redteam_adapted.py.txt`, unchanged) on the same gate. |

## The real tree's test names

| File | What it is |
|---|---|
| `alljson-run.sh.txt`, `names6.py.txt`, `names6.log` | One run of every package with `go test -json`, and the count of subtests whose own name holds a `/`. The raw JSON output (5 MB) is not in this folder. |

## Workflow edits and mutants

| File | What it is |
|---|---|
| `wf6.py.txt`, `wf6.log` | 22 edits of `go.yml` against the self-check's workflow group and the docs test (finding F-4). |
| `mut6.py.txt`, `mut6.log` | 39 mutants of the gate by the audit thread, plus a control, against the committed self-check. |
| `mut-run.sh.txt`, `mutants-writer.log` | The writer's 75 mutants (`05-repair-evidence/mutants.py.txt`, unchanged) re-run by the audit thread. |

## PR #16

| File | What it is |
|---|---|
| `lock16.sh.txt`, `lock16-pr16.log`, `lock16-old.log` | The changed test: plain runs, runs under forced stalls, and the orphan check; and the unchanged test at `c4a84f5` as the control. |
| `race16-run.sh.txt`, `race16.log` | The changed test under the race detector. |
