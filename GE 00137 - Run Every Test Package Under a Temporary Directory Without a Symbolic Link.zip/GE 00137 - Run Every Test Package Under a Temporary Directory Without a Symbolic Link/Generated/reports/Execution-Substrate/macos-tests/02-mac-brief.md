# Mac run brief: PR #23 at be06100, macOS temporary-directory fix

Prepared 2026-11-23 for the first macOS run of ES pull request #23 (tests, test support and docs only). Updated at 13:45 UTC to the PR head `be06100`: the audited commits `978fa68` and `98982a5` (audit repair) plus a merge of `trunk_dev` `df46164` (PR #19 and #24, no conflict; the PR's own changes are line for line the same as at `98982a5`). The comparison base is now `df46164`. The cloud thread could only simulate macOS on Linux. This run checks the fix on the real thing.

**How it runs:** when David writes "go ahead" in the thread "Fix ES tests failing on macOS", that thread starts a Remote Control session on his Mac with the text below as its instructions, in the folder `/Users/ds/Repositories/Playground`. Read-only, about 10 to 15 minutes, cleans up after itself. The brief already holds every fallback, because the session cannot take follow-up instructions unless David writes in the thread again.

**What it checks:**
- the new `internal/testtmpdir` tests, in full, under the Mac's real temporary directory;
- at the PR head `be06100`: `es/admission`, `es/admission/internal/reliablesubmit`, the TLS status and docs tests of the root package, and the two `es/app` tests that the Linux simulation found;
- `go vet ./...` and `gofmt` at the PR head;
- the same test commands at `trunk_dev` `df46164` (without the PR), so the run shows which failures the PR removes.

**Expected, from the Linux simulation (not yet seen on a Mac):**
- At `be06100`: every listed command passes, except skips that need passwordless sudo.
- At `df46164` (simulated at `bc9fe36`; PR #19 and #24 add docs tests to the root subset and change none of the tests listed here): `es/admission` fails the same 15 tests as the PR 20 Mac run; reliablesubmit fails about 25 tests with `reliable submit store: unsupported format`; the root subset fails the 17 TLS status tests of the simulation, including `TestRemoteAlphaESServiceTLSStatusReaderDocumentAcceptance`; the two `es/app` tests fail with `supported-local execution-root scope is invalid`.

**Left out on purpose:** three root tests that need the account `ds` and write below `/private/tmp` (`TestRemoteAlphaESServiceTLSStatusFailureWitnessBootstrapOwnedTerminal`, `…RootLoadedStageCustody`, `…StageFIFOSubstitution`), because they would write outside the temporary folder. The rest of the root package and of `es/app` are left out too; they are not affected by the temporary directory in the simulation, and some `es/app` tests drive Docker, Nomad or Vault when they are installed.

---

## Instructions for the Mac session (paste as is)

Run a read-only test check of two Execution-Substrate commits on this Mac and report the complete output. Pull request 23 makes every Go test package run under a temporary directory whose path has no symbolic link; on macOS the default temporary directory /var/folders/... lies behind the symbolic link /var -> private/var. Change nothing outside one new temporary folder.

Rules:
- Create exactly one new folder: T=$(mktemp -d /Users/ds/Repositories/Playground/es-pr23-mac.XXXXXX) and print it. Then create a marker file: touch "$T/start-marker".
- Keep /Users/ds/Repositories/Playground as your working directory for the whole run. Never cd into "$T" or anything below it, not even briefly: run every command with git -C "$T/es" or inside a subshell such as ( cd "$T/es" && … ). (If the temporary folder ever becomes the working directory, removing it at the end is refused.)
- Do not change, stage, commit or delete anything in any existing folder. You may read the origin URL of the existing clone with: git -C "/Users/ds/Repositories/Execution Substrate" remote get-url origin. Run no other command in that folder.
- Do not set or change TMPDIR. The point of the run is the Mac's own temporary directory.
- Do not run sudo yourself. Some tests call "sudo -n true" on their own to decide whether to run root-only cases; without passwordless sudo they skip, which is expected. If any test output contains "the same test as root", say so in the report.
- No git push. No installs and no downloads other than the git clone and fetch. Do not touch any live service (these tests use only local fakes).
- For every go and gofmt command, set these variables, so that nothing can be downloaded and a missing toolchain or module fails loudly, and the build cache stays in the temporary folder:
    export GOTOOLCHAIN=go1.26.5 GOPROXY=off GOFLAGS=-mod=readonly GOCACHE="$T/gocache"
  Outside the clone, go version may print the Mac's go1.26.1; that is expected and not a reason to stop. Inside the clone it must print go1.26.5 (from the module cache). If it does not, stop and report instead of installing anything. For gofmt use "$(go env GOROOT)/bin/gofmt" inside the clone.
- If a go command fails because a module is missing from the module cache, report the exact error and stop. Do not download.
- If a test command fails, do not try to fix any code. Record the output and go on with the next step. If a go test command ends with "panic: test timed out", record it, run the leftover check of step 6 at once, and go on.
- At the end remove the temporary folder and confirm it is gone. If the removal is refused, do not retry: say so and give David the one-line command. /Users/ds/Repositories/Playground itself must still exist.

Steps:
1. Print: sw_vers, uname -m, whoami, ps -p 1 -o comm=, /bin/bash --version | head -1, and the value of TMPDIR (printf '%s\n' "${TMPDIR-unset}"). Clone:
     git clone "$(git -C "/Users/ds/Repositories/Execution Substrate" remote get-url origin)" "$T/es"
2. git -C "$T/es" fetch origin trunk_dev claude/project-thread-qx9d46
   Print git -C "$T/es" rev-parse origin/claude/project-thread-qx9d46 origin/trunk_dev
   (expected be06100badc317ab74bef9834903d70f221c9620 and df461642d2f7c9481873ca74b7eaaba368feb12f; trunk_dev may have moved on; if either differs, say so and still test the two commits named below).
3. git -C "$T/es" checkout --detach be06100badc317ab74bef9834903d70f221c9620
   Confirm git -C "$T/es" rev-parse HEAD 'HEAD^{tree}' (expected tree bcf9da93ad71a954442168a04e9a3460f91f83b3).
   Inside the clone print: go version, and go env GOVERSION GOROOT GOTOOLCHAIN GOPROXY GOCACHE. Stop here if go version is not go1.26.5.
4. At be06100 (the pull request), each with its exit status. For every log below report: the exit status; the last 3 lines; the number of lines matching each of '^ *--- PASS', '^ *--- SKIP' and '^ *--- FAIL'; every '--- SKIP' line together with the two lines after it (grep -E -A2 '^ *--- SKIP'); every line containing 'panic:', 'testtmpdir:' or 'the same test as root'; and for each failed test its complete output, from its "=== RUN" line through its "--- FAIL" line and the indented lines after it.
   a. ( cd "$T/es" && go test -count=1 -v -timeout 10m ./internal/testtmpdir ) > "$T/head-testtmpdir.log" 2>&1; echo "exit $?"
      Also report this log in full (it is short).
   b. ( cd "$T/es" && go test -count=1 -v -timeout 30m ./es/admission ) > "$T/head-admission.log" 2>&1; echo "exit $?"
   c. ( cd "$T/es" && go test -count=1 -v -timeout 30m ./es/admission/internal/reliablesubmit ) > "$T/head-reliablesubmit.log" 2>&1; echo "exit $?"
   d. R='^(TestRemoteAlphaESServiceTLSStatus.*|.*Doc.*)$'
      K='^(TestRemoteAlphaESServiceTLSStatusFailureWitnessBootstrapOwnedTerminal|TestRemoteAlphaESServiceTLSStatusRootLoadedStageCustody|TestRemoteAlphaESServiceTLSStatusStageFIFOSubstitution)$'
      ( cd "$T/es" && go test -count=1 -v -timeout 20m -run "$R" -skip "$K" . ) > "$T/head-root.log" 2>&1; echo "exit $?"
   e. A='^(TestSupportedLocalExecutionRootFailedProvisionEmitsNoEvidence|TestSupportedLocalExecutionRootPrivilegeGateBeforeMutation)$'
      ( cd "$T/es" && go test -count=1 -v -timeout 10m -run "$A" ./es/app ) > "$T/head-app.log" 2>&1; echo "exit $?"
      Also report this log in full (it is short).
   f. ( cd "$T/es" && go vet ./... ); echo "exit $?"    (expected: no output, exit 0)
   g. ( cd "$T/es" && "$(go env GOROOT)/bin/gofmt" -l $(git diff --name-only df461642d2f7c9481873ca74b7eaaba368feb12f HEAD -- '*.go') ); echo "exit $?"    (expected: no output)
5. At trunk_dev without the pull request, for comparison:
   git -C "$T/es" checkout --detach df461642d2f7c9481873ca74b7eaaba368feb12f and confirm git -C "$T/es" rev-parse HEAD.
   Run b, c, d and e again with the same commands, writing to "$T/base-admission.log", "$T/base-reliablesubmit.log", "$T/base-root.log" and "$T/base-app.log". (There is no internal/testtmpdir at this commit; skip a, f and g.) Report the same items as in step 4, except that for failed tests at this commit the "=== RUN" line, the first indented line and the "--- FAIL" line of each failed test are enough.
6. Leftovers and cleanup:
   - ps -axo pid,ppid,stat,command | grep -E '\.test|remote_alpha_es_tls_status|es-pr23-mac' | grep -v grep    (expected: no output)
   - git -C "$T/es" status --porcelain    (expected: empty)
   - find /Users/ds/go/pkg/mod -newer "$T/start-marker" -print | head -5    (expected: no output, meaning nothing was downloaded)
   - rm -rf "$T", then confirm "$T" is gone and /Users/ds/Repositories/Playground still exists.

Report back: the environment lines and TMPDIR value of step 1, the commit hashes of steps 2 and 3, the go version and go env lines, and for each of a to g at be06100 and b to e at df46164 the exact command, its exit status and the items asked for above. Say plainly which commands passed and which failed. Do not summarize a failure away.
