# ES PR #23 (macOS test fix): independent audit

**Verdict: ACCEPT.** No patch defect found. One older test gap (A3-1, low, not caused by this PR) and three observations. Nothing was pushed, commented or merged.

```text
INDEPENDENT AUDIT REPORT
Repository:        evo-agi/Execution-Substrate
Audit target:      base origin/trunk_dev bc9fe3619823245faf550db4bf1bc3e782fbd5a5
                   topic claude/project-thread-qx9d46, commit 978fa6887aa73b719392014b6a8655056c4d9664
                   tree 0b0dde45d704d780fce63609c9145a88e32463ad
                   recipe governed-execution.audit-patch-manifest.v2,
                     source SHA-256 c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca
                   canonical-manifest SHA-256 0e8faf915f3a91123d3daa218fcbb095adf40baebfb1d43db0b7fb157bcca630
                   textual-diff SHA-256 4c2d6635b8e73efd57a8cd916ed0e79186b191b05571e54ae69cadd97e3edffb
                   changed paths 25
Writer report:     macos-tests/01-implementation.md, SHA-256 ec444b033b0a340518d2641d10c95c4b7197e05d94247db0f22f6444ebd97b70
Audit posture:     read-only, fresh thread, no subagents. Mutants and debug tests only in scratch copies
                   inside the container, reverted after each run. No push, no PR comment, no merge.
Effect status:     REPAIR_NOT_PERFORMED | COMMIT_NOT_PERFORMED | PUSH_NOT_PERFORMED | PR_COMMENT_NOT_POSTED | MERGE_NOT_PERFORMED
Final verdict:     ACCEPT
```

Everything called "simulation" or "chroot" below ran on Linux amd64 in a cloud container, not on a Mac. Times are UTC, 2026-11-23.

## 1. Provenance reproduction

- Recipe bytes: copied `claude-conversion/tools/governed_execution_audit_patch_manifest_v2.py`, `sha256sum -c` against `c08597e2…a1ca`: OK, before both the opening and the closing run.
- Fresh clone, `umask 022`. `origin/claude/project-thread-qx9d46` = `978fa68` (reported tip); `origin/trunk_dev` = `bc9fe36` (reported base, still current at 06:50Z per `git ls-remote`); base is an ancestor of the tip; checkout of the tip clean; tree `0b0dde45`; `git reset --mixed bc9fe36`; upstream pinned to `origin/trunk_dev`; v2 run twice to two absent paths in a fresh 0700 directory.
- Result: both runs byte-identical; canonical manifest SHA-256 `0e8faf91…a630`, 25 files, textual diff `4c2d6635…dffb`. The file is byte-identical (`cmp`) to the writer's `01-evidence/manifest-978fa68.json`. No mode-bit differences.
- Closing: the provenance clone was never used for tests; v2 re-run twice at close, identical to each other and to the opening manifest (`03-audit-evidence/manifest-open-978fa68.json`, `manifest-close-978fa68.json`).
- GitHub: PR #23 head `978fa68`, base `bc9fe36`, draft, 1 commit, 25 files; check run "build, vet and test" (run 45121907187, job 137517361733) completed **success** on that head (log tail read: "all 15 listed tests still fail on this host"). I read the CI result; I did not re-run CI.

Provenance verdict: matches. All test copies used below were checked out at `978fa68` (tree `0b0dde4`) or `bc9fe36` (tree `b3b240d`) and were clean (`git status --porcelain` empty) after every run.

## 2. Coverage

Inspected: the full diff (25 paths); `internal/testtmpdir/testtmpdir.go` and `testtmpdir_test.go` line by line; all 21 `testtmpdir_main_test.go` files (hashes in the manifest; 5 different contents, differing only in package name); the `capability_probing.md` insertion and the `docs_contract_test.go` change; `.github/workflows/go.yml` and `.github/ci/go_test_gate.py` (how CI runs tests and treats `TestMain`); the product code behind the 7 "wrong-reason" tests (`es/admission/result_auth.go`, `writablestate_preflight.go`, `reliablesubmit/replay_custody_file.go`, `sqlite_replay_shape.go`, `sqlite_store.go`); every test-binary re-exec site and every test that sets `TMPDIR` or hard-codes `/tmp`; the Darwin test files of `es/admission`.

Not inspected: product code unrelated to the 7 tests; the Python/shell bodies of the TLS status collector and supported-local scripts (only their behaviour through the test suite).

## 3. What was checked, and results

### 3.1 No product file changed

Changed paths: 23 `_test.go` files, `.docs/system_overview/capability_probing.md`, and one non-test Go file, `internal/testtmpdir/testtmpdir.go`.

- `go list -deps` of every package except `internal/testtmpdir`, for linux and darwin: neither `internal/testtmpdir` nor `testing` appears. No command or service links the new package. The only importers are the 22 test packages (`TestImports`/`XTestImports`).
- `go vet ./...` for linux/amd64, linux/arm64, darwin/arm64, darwin/amd64: exit 0. `GOOS=darwin GOARCH=arm64 go test -c ./internal/testtmpdir`: builds. Toolchain `gofmt -l` on the changed Go files: no output. `git diff --check bc9fe36 978fa68`: clean.
- Existing test code: the only change to a pre-existing test file is `docs_contract_test.go` (inventory count 33 → 34 and the new file name). No assertion of an existing test was edited.

### 3.2 No security assertion weakened

- On a host whose temporary directory is physical, `Resolve` returns before changing anything (`testtmpdir.go:73-75`). Whole-module result at base vs head with physical `TMPDIR`: **every pre-existing test and subtest has the same result**; the only 24 differences are the new package's 5 tests and 19 subtests (`03-audit-evidence/full-runs-comparison.txt`, "base-phys vs head-phys"). So on Linux, including CI, every symlink-refusal test runs exactly as before, which means each one that passes there already creates its own symbolic link.
- The Darwin tests in `es/admission` (`execution_roots_darwin_test.go:12`, `staging_custody_darwin_test.go:14,27,67,81`) already resolve their temp root and create their own link; none relied on `/var -> private/var`.
- No test sets `TMPDIR` to a path that would make the new `TestMain` refuse to run: the 11 `TMPDIR=` sites in tests all point at `t.TempDir()`-derived directories and feed scripts, not re-execs of the test binary. The test-binary re-exec sites (12, listed by `grep os.Args[0]|os.Executable()`) inherit the environment or set no `TMPDIR`; with `TMPDIR` unset `Resolve` is a no-op on Linux, and in the macOS-like chroot it sets `/private/tmp` without changing any result (3.4).

### 3.3 Linux reproduction of the macOS layout (writer's setup, independently rebuilt)

User `ci` (uid 1500, gid 1600, passwordless sudo), `env -i`, umask 022, Go 1.26.5, `GOTOOLCHAIN=local GOPROXY=off GOFLAGS=-mod=readonly`. Physical: `TMPDIR=/physim/T`. Symlinked: `TMPDIR=/macsim/var/folders/zz/abc123/T/` (with the trailing slash macOS uses; the writer used none) and `/macsim/var -> private/var`. `go test -count=1 -json ./...` (scripts `full4.sh.txt`, `ciexec.sh.txt`, comparison `cmp.py.txt`).

| Run | Pass | Fail | Skip | Result |
| --- | --- | --- | --- | --- |
| base, physical | 5213 | 40 | 48 | only the environment-only entries fail |
| base, symlinked | 4849 | 336 | 48 | **59 top-level tests fail** that pass physical: root 17, es/admission 15, reliablesubmit 25, es/app 2. The list is identical to the writer's (`diff` of the two sorted lists: none; `base-sym-59-failing.txt`) |
| head, physical | 5237 | 40 | 48 | same as base plus the new package |
| head, symlinked | 5237 | 40 | 48 | **0 differences** from head physical over every test and subtest |

The head failures are the 10 environment-only entries that fail in this container (8 root, 2 reliablesubmit) and their subtests. Of the 15 listed entries, the 3 `TestRemoteAlphaRuntimeSecurityBoundary*` entries and the 2 es/app subtests pass in a cloud container (known container difference, no systemd and no `/usr/bin/go`), identically at base and head.

### 3.4 A more faithful macOS layout (my own, not the writer's)

A chroot in a private mount namespace where `/tmp -> private/tmp` (tmpfs 1777), `/var -> private/var` and `/etc -> private/etc`, with `TMPDIR=/var/folders/zz/abc123/T/` exactly as macOS sets it (`macroot2.sh.txt`, `mac3.sh.txt`). The writer's chroot made only `/tmp` a link.

| Run | Pass | Fail | Skip | Result |
| --- | --- | --- | --- | --- |
| head | 5244 | 33 | 48 | vs plain Linux head: only `TestRemoteAlphaOperatorRecoverySessionESTLSStatusRemoteWrapperTrap` (+6 subtests) goes fail → pass, an environment-only entry that needs `/private/tmp` to exist |
| head, `TMPDIR` unset | 5244 | 33 | 48 | 0 differences from head with `TMPDIR` set (`/tmp` resolved to `/private/tmp`) |
| base | 4856 | 329 | 48 | the same 59 top-level tests fail |

So: with `/var`, `/tmp` and `/etc` all behind links, the PR gives plain-Linux results, and base fails exactly the 59.

### 3.5 Guard mutations (`guard_mut.sh.txt`, results `guard-mutation-results.txt`)

The guard's walk was first compared with the go command: `go list -f '{{if or .TestGoFiles .XTestGoFiles}}…' ./...` for linux/amd64, linux/arm64, darwin/arm64 and darwin/amd64 gives the same 22 directories as a `find` with the guard's skip rules. The repo has no symlinks, no vendor directory and no nested module.

| Case | Change | Guard |
| --- | --- | --- |
| G0 | none | passes |
| G1 / G2 / G3 | `TestMain` file deleted from es/app / reliablesubmit / root package | fails ("has 0 TestMain functions") |
| G4 | es/config `TestMain` runs `m.Run()` directly | fails |
| G5 | es/runtimehelper file gets `//go:build linux` | fails ("does not build for darwin/arm64") |
| G6 | es/api file renamed `_darwin_test.go` | fails ("does not build for linux/amd64") |
| G7 / G8 | new test package (internal/newpkg; deep external-test-only es/newdeep/a/b) without `TestMain` | fails |
| G9 | renamed import | fails |
| G10 | extra statement | fails |
| G11 | second `TestMain` | fails ("has 2") |
| G12 / G13 | test file under `testdata/` / `_scratch/` (the go command ignores both) | passes, correctly |
| G14 | `//go:build unix` | passes (see A3-2) |

Helper mutants (`helper_mut.sh.txt`, `helper-mutants-results.txt`), run under the symlinked `TMPDIR`: `Resolve` no-op, tests run after a failed resolve, `TMPDIR` rewritten when already physical, `EvalSymlinks` replaced by `filepath.Clean`, non-directory accepted: **5 of 5 killed** by the package's own behaviour tests.

### 3.6 The 7 tests that passed for the wrong reason

Method (independent of the writer's coverage diff): for each test, a product mutant that removes the very check the test is named for (`mutants.py.txt`, runner `run_mut.sh.txt`/`run7.sh.txt`). A test that passed for the wrong reason at base must let the mutant **survive** at base under the symlinked `TMPDIR` (it stops at the symlink refusal first) and must **kill** it at head in both modes. Unmutated controls pass in all four cells.

| Test | Mutant | base sym | head sym | head phys |
| --- | --- | --- | --- | --- |
| es/admission `TestPreflightOptionalOwnershipNormalizationMarkerBlocksMissingMarkerInNonRootRequiredMode` | MO1: missing marker accepted (`writablestate_preflight.go:42-46`) | survives | **killed** (`:573`) | killed |
| es/admission `…BlocksTargetOwnerMismatchInNonRootRequiredMode` | MO2: marker contents not validated (`:99-101`) | survives | **killed** (`:595`) | killed |
| es/admission `…RejectsWorldWritableMarkerAuthorityPath` | MO3: writable authority directory accepted (`:33`) | survives | **killed** (`:613`) | killed |
| reliablesubmit `TestReplayExistingStateModeNotRepaired` | MR1: `checkReplayDBFiles` repairs the mode to 0600 (`replay_custody_file.go:729`) | survives | **killed** ("existing state mode was repaired") | killed |
| reliablesubmit `TestPrivateReplayProgressFormatVectors` | MP: marker size and content not checked (`replay_custody_file.go:184,190`) | survives | **killed** (WrongRootMarker: "invalid marker opened a progress fixture") | killed |
| reliablesubmit `TestSQLiteLiteralInternalNamespaceQualification` | MS1: internal-name predicate as `name NOT LIKE 'sqlite_%'` (`sqlite_replay_shape.go:23`) | survives | **killed** ("extra object was not refused") | killed |
| es/admission `TestRetainedResultAuthRequiredStartupFailsWithoutKeyAndPrepareOnlySkipsIt` | MK1: absent key accepted (`result_auth.go:63-65`) | survives | survives | survives |

Six of seven now test what they are named for under the macOS layout. For the seventh, a probe mutant that gives the two "key is unavailable" branches distinct messages shows base under the symlink refuses at the key **parent** (`result_auth.go:50-53`), while head in both modes reaches the **absent key** branch (`:63-65`) (`absent-key-probe.txt`). So the PR does move it to the check it is named for, but the test cannot tell whether that check exists: see A3-1. (The first MP mutant did not compile; the corrected one was rerun. Both are recorded in `product-mutants-results.txt`.)

### 3.7 Tests that hard-code `/tmp`

Seven sites call `os.MkdirTemp("/tmp", …)` for short Unix-socket paths (es/runtimehelper ×2, es/app ×3, root ×2); the fix does not reach them, since it only resolves `TMPDIR`. In the chroot of 3.4 they all pass, and per-test Go coverage (`-coverpkg=./...`) of the six that run here equals plain Linux except inside `testtmpdir.go` (`tmp-literal-coverage.txt`, script `covtmp.sh.txt`). See A3-4 for what that cannot show.

## 4. Findings

```text
AUDIT FINDING A3-1
Type / Severity: test gap / low
Current contract: retained-result startup refuses a configured Submit without its key (result_auth.go:45-76, service.go:217-221)
Path and line: es/admission/service_direct_test.go:86-109
Evidence: mutant MK1 (an absent key is accepted, no authenticator) survives at base and head, physical and
  symlinked. NewService then fails anyway with "dual-missing execution roots share one unobserved lookup
  context", because the test leaves both roots uncreated, and the test asserts only err != nil and that no
  root was created. Probe: at head the test does reach the absent-key branch.
Impact: removing the absent-key refusal would not be caught by the test named for it, on Linux CI as well as
  on macOS. Other startup tests may cover the key check; not established here.
Required correction: make the key the only possible refusal (for example create the roots, or one of them, so
  startup would otherwise succeed) and/or assert the key-specific error. Test-only.
Uncertainty: whether another existing test kills MK1 was not checked (only this test was run per mutant).
Patch defect or pre-existing issue: PRE-EXISTING at bc9fe36; not caused or worsened by PR #23.
```

```text
AUDIT FINDING A3-2
Type / Severity: test/doc gap / observation
Path and line: .docs/system_overview/capability_probing.md (inserted paragraph 2: "in a file without a build
  constraint"); internal/testtmpdir/testtmpdir_test.go:346-354 (guard checks builds on four platforms)
Evidence: G14: a TestMain file with "//go:build unix" passes the guard.
Impact: none on behaviour (the file still builds on every platform ES is built or developed on); the doc
  states a stricter rule than the guard enforces.
Required correction (optional): say "in a file that builds on linux/amd64, linux/arm64, darwin/arm64 and
  darwin/amd64", or make the guard refuse any build constraint.
Patch defect or pre-existing issue: patch (wording).
```

```text
AUDIT FINDING A3-3
Type / Severity: report-only inaccuracy / observation
Path: macos-tests/01-implementation.md §6, row "New package, both modes"
Evidence: the report says "5 tests, 21 subtests"; go test -json shows 5 tests and 19 subtests (4 + 5 + 10).
Impact: none on any conclusion.
Patch defect or pre-existing issue: report only.
```

```text
AUDIT FINDING A3-4
Type / Severity: residual scope / observation
Path: tests calling os.MkdirTemp("/tmp", ...): es/runtimehelper/helper_test.go:128, supervisor_test.go:12;
  es/app/proof_codex_shim_test.go:253, supported_local_execution_roots_test.go:73,
  supported_local_proof_validation_test.go:266; remote_alpha_operator_test.go:3776;
  remote_alpha_runtime_security_boundary_check_test.go:81
Evidence: on macOS these paths go through /tmp -> private/tmp. In the macOS-like chroot they pass and their Go
  coverage equals plain Linux. Coverage cannot see the shell and Python those es/app and root tests drive, and
  TestSupportedLocalSetupScriptBootstrapsRealSPIREAndVaultDevTarget (esls-*, skips without vault; listed
  skips-itself) did not run here.
Impact: none observed. Unknown on a Mac that has vault installed.
Required correction: none for this PR (the rule it documents is about TMPDIR); the pending Mac run is the check.
Patch defect or pre-existing issue: pre-existing scope, outside the PR's claim.
```

No minority findings or disagreements (single auditor, no subagents).

## 5. Validation assessment

Re-run by this audit, on the exact commits: provenance (twice open, twice close); `go vet` ×4 platforms; gofmt; `git diff --check`; Darwin test-binary build; whole module ×4 (base/head × physical/symlinked) and ×3 in the macOS-like chroot; 14 guard cases; 5 helper mutants; 7+1 product mutants with controls; per-test coverage of 6 `/tmp`-literal tests. Runs took place 06:27Z to 06:50Z.

Not re-run: the writer's 11 mutants and per-test coverage comparison (replaced by my own mutants above); the writer's no-sudo chroot variant; CI (result read from GitHub, success on `978fa68`).

Not possible here: any run on macOS (Darwin syscalls, APFS, `F_GETPATH`, the real `/var/folders` layout); bindfs tests (bindfs not installed; they skip at base and head alike); Docker/Nomad/Vault `es/app` tests (skip here and on CI, listed `skips-itself`). The Mac run is pending with David separately (`02-mac-brief.md`).

## 6. Sensitive material

None read or produced. The proxy CA bundle was copied to a readable path only for `go mod download`; it is not in the evidence. Evidence holds scripts, result summaries and manifests (paths, sizes, hashes) only.

## 7. Remaining uncertainty and stop conditions

- Real-Mac behaviour beyond the path layout: Unknown until the Mac run.
- Whether another test covers the absent-key refusal (A3-1): not established.
- Stop conditions: none hit.

## 8. Confidence

- Provenance: very high (manifest reproduced byte for byte, open = close, PR head and trunk_dev unchanged at close).
- Validation: high on Linux and in two independent macOS-layout simulations; none on a real Mac.
- Implementation: high. The change touches no product code or link rule, leaves every Linux result unchanged, removes all 59 macOS-layout failures, makes 6 of the 7 wrong-reason passes catch the mutant they used to miss, and its guard caught every breakage tried.

## 9. Evidence

`macos-tests/03-audit-evidence/` (checksums in `SHA256SUMS.txt`, SHA-256 `530f79f12394782194e70a43bedc3e6d5dd5ec9c3ba1d9652097e1e44162b1e7`): `full-runs-comparison.txt`, `base-sym-59-failing.txt`, `guard-mutation-results.txt`, `helper-mutants-results.txt`, `product-mutants-results.txt`, `product-mutants-kill-lines.txt`, `absent-key-probe.txt`, `tmp-literal-coverage.txt`, `manifest-open-978fa68.json`, `manifest-close-978fa68.json`, and every script as `*.txt`.

## 10. For the merge gate

Tests/docs/test-support only, so under the merge policy no David review is needed. A3-1 is pre-existing and does not block. Before merge: the PR head must still be `978fa68`. If trunk_dev moves (for example PR #22 merging first), the branch needs updating, a new manifest and a provenance re-check (provenance §5.4). The pending Mac run remains a separate input.
