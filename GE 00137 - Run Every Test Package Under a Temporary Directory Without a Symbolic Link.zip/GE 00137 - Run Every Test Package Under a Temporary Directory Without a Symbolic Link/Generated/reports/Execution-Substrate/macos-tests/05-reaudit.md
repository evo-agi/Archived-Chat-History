# ES PR #23 repair (`98982a5`): narrow re-audit, with gate data

**Verdict: ACCEPT.** A3-1 and A3-2 are fixed, A3-3 is corrected in the repair report, and I found nothing new. CI is green on `98982a5`. Nothing was pushed, commented or merged.

```text
INDEPENDENT AUDIT REPORT (narrow re-audit)
Repository:        evo-agi/Execution-Substrate
Audit target:      base origin/trunk_dev bc9fe3619823245faf550db4bf1bc3e782fbd5a5
                   topic claude/project-thread-qx9d46, commit 98982a5ba595f41bc24be359d94f96811e8492e1
                   (parent 978fa6887aa73b719392014b6a8655056c4d9664, the commit accepted in 03-audit.md)
                   tree f88f9e0a837560967d550ce35b05cafa22739bcc
                   recipe governed-execution.audit-patch-manifest.v2,
                     source SHA-256 c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca
                   canonical-manifest SHA-256 11fc280522b81c813929c9129b3fb4761e8644fcd7642ed56c3b82eaaff01967
                   textual-diff SHA-256 4599a45b2b94d34e22f6a85aa94dbafa51a7a0996b8c7b5aa7515de8dd9ee1fe
                   changed paths 26 (base..tip)
Inputs:            macos-tests/03-audit.md  SHA-256 84f74aded822a58b821ff2886672c95d26ffcdcd9a99c2c460e6a274d04aa693
                   macos-tests/04-repair-a3-1.md  SHA-256 2b3199fa890acf2e80d06c27a78860a61cdd441afa0316eff6e15483713d78e1
Scope:             the delta 978fa68..98982a5 (2 test files), provenance of the full range bc9fe36..98982a5,
                   and whole-module regression runs on 98982a5
Audit posture:     read-only, same auditor as 03-audit.md, no subagents. Mutants only in scratch copies,
                   reverted after each run. No push, no PR comment, no merge.
Effect status:     REPAIR_NOT_PERFORMED | COMMIT_NOT_PERFORMED | PUSH_NOT_PERFORMED | PR_COMMENT_NOT_POSTED | MERGE_NOT_PERFORMED
Final verdict:     ACCEPT
```

Everything ran on Linux amd64 in a cloud container, not on a Mac. Times are UTC, 2026-11-23. Same setup as `03-audit.md`: user `ci` (uid 1500, gid 1600), `env -i`, umask 022, Go 1.26.5, `GOTOOLCHAIN=local GOPROXY=off GOFLAGS=-mod=readonly`. "phys" means `TMPDIR=/physim/T`. "sym" means `TMPDIR=/macsim/var/folders/zz/abc123/T/` behind `/macsim/var -> private/var`. "mac2" means a chroot where `/tmp`, `/var` and `/etc` are all links, with `TMPDIR=/var/folders/zz/abc123/T/`.

## 1. Gate data

| Item | Value |
| --- | --- |
| PR #23 head | `98982a5ba595f41bc24be359d94f96811e8492e1` (GitHub API and `git ls-remote`, 07:11Z); draft; 2 commits; 26 files |
| Base | `trunk_dev` = `bc9fe3619823245faf550db4bf1bc3e782fbd5a5`, unchanged at 07:11Z; base is an ancestor of the head; the audited `978fa68` is the head's parent (fast-forward, no rewrite) |
| Tree | `f88f9e0a837560967d550ce35b05cafa22739bcc` |
| Manifest | v2, canonical SHA-256 `11fc2805…1967`, textual diff `4599a45b…e1fe`, 26 files; reproduced byte for byte twice (open) and twice (close); byte-identical to the writer's `04-evidence/manifest-98982a5.json` |
| CI | "build, vet and test", run 45127835719, job 137536205169, event `pull_request`, head_sha `98982a5`, **success** (06:59:08Z to 07:12:47Z). Log ends "all 15 listed tests still fail on this host, each in a run of its own and in the run of its package". Inference: a `pull_request` run tests the merge ref, whose tree equals `98982a5`'s because the base is an ancestor of the head. I read the CI result; I did not re-run CI |
| Changed files outside tests | still only `.docs/system_overview/capability_probing.md` and `internal/testtmpdir/testtmpdir.go`, both unchanged since `978fa68` |
| Merge policy | tests/docs/test support only, so no David review |

## 2. Provenance reproduction

Recipe `sha256sum -c` OK before both runs. Fresh clone, umask 022. `origin/claude/project-thread-qx9d46` = `98982a5`, `origin/trunk_dev` = `bc9fe36`, checkout clean, tree `f88f9e0a`, `git reset --mixed bc9fe36`, upstream pinned to `origin/trunk_dev`, two runs into a fresh 0700 directory: identical. Compared with the `978fa68` manifest, exactly two entries differ: `es/admission/service_direct_test.go` (new entry, tracked_modified, `528320ec…`) and `internal/testtmpdir/testtmpdir_test.go` (`d31029f8…` to `f3552d0a…`). This matches the repair report. The provenance clone was not used for tests, and the closing manifest equals the opening one (`05-reaudit-evidence/manifest-open-98982a5.json`, `manifest-close-98982a5.json`). No mode-bit differences.

## 3. A3-1: the absent-key test

Diff read in full (`service_direct_test.go:86-139` at `98982a5`). The staging root is created (0755) and the results root is left missing. With the key removed, the test now asserts four things: startup fails, the error contains `retained result authentication key is unavailable`, the error does not contain the key path, and there are no effects (results root absent, staging root empty). As a control, the same key bytes are written back at 0600, and the same configuration must start with `resultAuth != nil` and provision the results root. The prepare-only part is unchanged. `NewService` closes its root handles itself (`service.go:222-243`), so the control leaves no open custody behind.

My own mutants (`mutants2.py.txt`, `run_a31.sh.txt`; results `absent-key-mutants-results.txt`). Each was applied alone to a scratch copy of the old commit and of the new one, then reverted. Both trees were clean after every run.

| Mutant | Change in product code | `978fa68` test, phys / sym | `98982a5` test, phys / sym |
| --- | --- | --- | --- |
| control | none | pass / pass | pass / pass |
| MK1 | absent key accepted, no authenticator (`result_auth.go:63`) | survives / survives | **killed** / **killed** (`:109`, service returned, err nil) |
| MKM | absent key refused as "startup refused" | survives / survives | **killed** / **killed** (`:109`, wrong error) |
| MKR | execution roots provisioned before the key is loaded (`service.go:218-225`) | survives / survives | **killed** / **killed** (`:112`, results root provisioned) |
| MKA | key loaded, but no authenticator returned (`result_auth.go:101-103`) | survives / survives | **killed** / **killed** (`:124`, control: service without authenticator) |
| MKL | key path put in the error | killed / killed | killed / killed (`:109`) |

The repaired test now catches all five. Four of them (MK1, MKM, MKR, MKA) got past the old test in both modes. MKA is not in the writer's set: it shows the control's `resultAuth != nil` check is load-bearing. MKR independently confirms the writer's point that the test now pins "key before roots".

Whole-module runs on `98982a5`: the repaired test passes phys, sym and mac2.

## 4. A3-2: the guard refuses build constraints

Diff read in full (`testtmpdir_test.go`). The file is now parsed with comments. Comment groups before the package clause are scanned with `go/build/constraint`'s `IsGoBuild`/`IsPlusBuild`, and any match is refused as "has a build constraint". The four-platform `MatchFile` check stays, so file-name suffixes are still caught. Three new self-test cases were added.

My guard cases on `98982a5` (`guard_mut2.sh.txt`; results `guard-mutation-results.txt`): G0 to G13 behave as at `978fa68` (11 breakages caught; `testdata/` and `_dir/` test files correctly ignored). On top of those:

| Case | Change | Guard |
| --- | --- | --- |
| G14 | `//go:build unix` on es/config's TestMain file (passed at `978fa68`) | **fails**, "has a build constraint" |
| G15 | `// +build !windows` | **fails**, "has a build constraint" |
| G16 | plain comment before the package clause that mentions `//go:build` in prose | passes, correctly |
| G17 | `//go:build linux` after the package clause (the go command ignores it) | passes, correctly |
| G18 | `//go:build linux` on another test file of the same package | passes, correctly |
| G19 | `//go:build linux` inside a `/* */` block comment (the go command ignores it) | passes, correctly |

The guard now enforces what the doc says. The doc text is unchanged and still accurate.

## 5. A3-3

The repair report gives the count at `978fa68` as 5 tests and 19 subtests, and at `98982a5` as 5 tests and 22 subtests. I observed exactly that: the `98982a5` run shows the 3 new guard subtests on top of the 19. `01-implementation.md` is left unchanged, which keeps the hash cited by `03-audit.md` valid. Closed.

## 6. Regression runs on `98982a5`

`go test -count=1 -json ./...` (`full3b.sh.txt`; comparisons `full-runs-comparison.txt`):

| Run | Pass | Fail | Skip | Compared with | Differences |
| --- | --- | --- | --- | --- | --- |
| phys | 5240 | 40 | 48 | `978fa68` phys | only the 3 new guard subtests (absent → pass) |
| sym | 5240 | 40 | 48 | `98982a5` phys | **0** |
| mac2 | 5247 | 33 | 48 | `978fa68` mac2 | only the 3 new guard subtests |

The failures are the same environment-only entries as in `03-audit.md` §3.3. In mac2, `TestRemoteAlphaOperatorRecoverySessionESTLSStatusRemoteWrapperTrap` passes because `/private/tmp` exists, as before.

Also: `go vet ./...` exits 0 on linux/amd64, linux/arm64, darwin/arm64 and darwin/amd64. Toolchain `gofmt -l` on the two files gives no output, and `git diff --check 978fa68 98982a5` is clean.

## 7. Findings

No new finding. A3-1 and A3-2 are resolved, A3-3 is corrected, and A3-4 is unchanged (observation; the Mac run is the check).

```text
OBSERVATION O5-1 (merge mechanics, not a code finding)
Both PR commits end with "Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>". If project policy wants no model
name in trunk_dev history (as noted for PR #22's squash message), the squash-merge message should leave that line out.
Severity: observation. Not a patch defect.
```

## 8. Validation assessment, uncertainty, confidence

- Re-run by this audit: provenance (open twice, close twice); absent-key cases (control + 5 mutants) × 2 trees × 2 modes = 24 runs; 20 guard cases; whole module phys, sym and mac2 on `98982a5`; vet on four platforms; gofmt; `git diff --check`. Runs took place 07:03Z to 07:11Z.
- Not re-run: the writer's MK2/MK3 and G15 (replaced by my own MKR, MKM and G14/G15); helper mutants and the 7-test product mutants of `03-audit.md` (`testtmpdir.go` and all product files are unchanged since `978fa68`); CI (result read).
- Not possible here: a run on a real Mac (pending with David, brief `02-mac-brief.md`, now at `98982a5`); bindfs and Docker/Nomad/Vault tests (skip, as before).
- Sensitive material: none.
- Confidence: provenance very high; validation high on Linux and both macOS-layout simulations; implementation high.

## 9. For the merge gate

Merge `98982a5` only if, at merge time, the PR head is still `98982a5` and `trunk_dev` is still `bc9fe36`. If PR #22 or anything else lands first, update the branch, take a new manifest and redo the provenance check (provenance §5.4). The Mac run remains a separate input.

## 10. Evidence

`macos-tests/05-reaudit-evidence/` (checksums in `SHA256SUMS.txt`): `manifest-open-98982a5.json`, `manifest-close-98982a5.json`, `absent-key-mutants-results.txt`, `guard-mutation-results.txt`, `full-runs-comparison.txt`, and the scripts as `*.txt`.
