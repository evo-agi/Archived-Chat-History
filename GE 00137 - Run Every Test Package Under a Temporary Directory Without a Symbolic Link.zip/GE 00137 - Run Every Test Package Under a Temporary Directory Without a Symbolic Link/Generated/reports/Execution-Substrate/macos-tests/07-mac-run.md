# ES PR #23 on David's Mac: run result

**Verdict: PASS. On a real Mac the PR head behaves as the Linux simulation predicted. Everything passes at `be06100` except two tests that need production-source probes and fail the same way without the PR. Without the PR, `trunk_dev` fails 61 top-level tests in the checked set. These are exactly the 59 tests the simulation predicted plus the same two probe tests.**

```text
MAC RUN REPORT
Brief:            macos-tests/02-mac-brief.md (version for be06100, SHA-256 c1c5b6718d64fc58a5e0a232862d451c4ef6161ed4682c9e643f967fc32ff7b8)
Approval:         David, in this thread, 2026-11-23 13:42Z ("Please go ahead with the Mac check.")
Device:           Mac.lan, folder /Users/ds/Repositories/Playground, Remote Control, read-only
PR head tested:   be06100badc317ab74bef9834903d70f221c9620, tree bcf9da93ad71a954442168a04e9a3460f91f83b3
                  (= audited 98982a5 + merge of trunk_dev df46164; PR lines identical to 98982a5)
Base tested:      trunk_dev df461642d2f7c9481873ca74b7eaaba368feb12f (PR #19, #24 since bc9fe36)
Run window:       13:47:52Z to 13:56:17Z; temporary folder removed; nothing downloaded
Effect status:    MAC_RUN_PERFORMED | NO_CHANGE_ON_MAC_REMAINS | REMOTE_CONTROL_STOPPED
```

## 1. Why the head is `be06100` and not `98982a5`

When David wrote "go ahead", `trunk_dev` had moved from `bc9fe36` to `df46164` (PR #19 and PR #24). I merged it into the PR branch with no conflict, made the merge commit `be06100`, and pushed it before the run. Checks on the merge:

- The PR's added and removed lines against the new base are line for line those of `98982a5` against `bc9fe36`.
- A new manifest v2: two identical runs, `manifest_sha256 1f5d5aae95ca3664c9207b66c4d6127525faa8796e2f786d18551fbe43ee6885`, `textual_diff_sha256 61fcef26faf9e6f4ec8d4d65d59ff3fc60dd8f8ae2b443eab0b4c57453afda7c`, 26 files. The only entry that differs from `manifest-98982a5.json` is `docs_contract_test.go`, as a whole-file hash, because `trunk_dev` changed other lines of that file.
- Linux, whole module, physical and symlinked: **0 differences**. Only the 10 environment-only entries fail.
- `go vet` (linux/amd64, darwin/arm64), gofmt and `git diff --check` are clean.

Evidence: `06-evidence/merged-head-be06100.txt` and `manifest-be06100.json`.

## 2. Environment (Mac)

The Mac runs macOS 26.6.2 (25G83) on arm64, as user `ds`. PID 1 is `/sbin/launchd`, and `/bin/bash` is GNU bash 3.2.57. `TMPDIR=/var/folders/ty/qlt5pcwx47l4tzkkwj3n4tyc0000gn/T/`, which is behind `/var -> private/var`, as the fix assumes.

Inside the clone, Go was go1.26.5 darwin/arm64 from the module cache. The run used `GOTOOLCHAIN=go1.26.5 GOPROXY=off GOFLAGS=-mod=readonly`, with `GOCACHE` inside the temporary folder. The fetched hashes were as expected: the head is `be06100`, its tree is `bcf9da93`, and `trunk_dev` is `df46164`.

## 3. Results

| Step | Command | `be06100` (PR) | `df46164` (no PR) |
| --- | --- | --- | --- |
| a | `go test -v ./internal/testtmpdir` | **pass** (5 tests, 22 subtests) | not present |
| b | `go test -v ./es/admission` | **pass**: 1072 PASS lines, 2 skips that need passwordless sudo | **fail**: 15 top-level tests, the same 15 as the PR 20 Mac run and the simulation |
| c | `go test -v ./es/admission/internal/reliablesubmit` | fails 2: `TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation` and `TestSQLiteV3OldBinaryRefusesWithoutMutation`, both "production-source probe is required" | **fail**: 27 top-level tests, which are the 25 of the simulation plus the same 2 probe tests |
| d | root `-run '^(TestRemoteAlphaESServiceTLSStatus.*\|.*Doc.*)$'`, minus 3 tests that write below `/private/tmp` | **pass** (942) | **fail**: 17 top-level TLS status tests, the 17 of the simulation |
| e | `go test -v -run` the two supported-local tests in `./es/app` | **pass** | **fail**: both ("supported-local execution-root scope is invalid") |
| f | `go vet ./...` | exit 0, no output | not run |
| g | gofmt on the PR's 25 Go files | no output | not run |

- The top-level failures at `df46164` on the Mac match the simulation exactly in every package, with nothing only on the Mac and nothing only in the simulation. The list is in `07-evidence/mac-base-df46164-toplevel-failures.txt`, compared with `full-mac.json`.
- The two probe tests are environment-only entries in `.github/ci/environment-only-tests.txt`. They read `ES_REPLAY_SCHEMA3_PROBE` and `ES_REPLAY_PB1_PROBE`, which nobody set here. They fail the same way with and without the PR, so they are not caused by it.
- No log at either commit contains "panic:", "testtmpdir:" or "the same test as root".
- The 7 tests that passed for the wrong reason before the fix now pass at the head on the Mac. They are part of steps b and c, which pass except for the two probe tests. That they now test what they are named for was shown by the mutants in `03-audit.md` and `04-repair-a3-1.md`; mutants were not run on the Mac.

## 4. Cleanup and side observations

- The clone stayed clean (`git status --porcelain` printed nothing). Nothing in the module cache was newer than the start marker, so nothing was downloaded. The temporary folder `es-pr23-mac.1Nqlqu` was removed at 13:56:17Z, and Playground still exists.
- The leftover-process check showed one test process. It did not come from this run: it was another session's Mac run, in `Playground/es-mac-run.illWqE`, started at 13:54:19Z. That overlapped the last seconds of base step d and all of base step e. All head steps had finished at 13:51:52Z, before it started. Inference: the overlap does not explain any base failure. Every base failure carries the symbolic-link messages and matches the simulation exactly.
- The existing clone's origin is the SSH URL under David's own GitHub login. It redirects to evo-agi, and the fetched hashes matched.

## 5. Merge

**Merged 2026-11-23 ~14:14Z** as squash commit `200fd6097b43981ffae86e69500d1ab41b49a94c` on `trunk_dev` (parent `df46164`). Its tree `bcf9da93ad71a954442168a04e9a3460f91f83b3` equals the tree of the gated head `be06100`. Gate at merge time: head `be06100` (merge called with that expected head), base `df46164`, CI "build, vet and test" run 45186846244 job 137734584406 **success** (13:44:11Z to 14:12:27Z), mergeable state clean, audit and re-audit ACCEPT, Mac run PASS, manifest `1f5d5aae…6885`. The commit message keeps the standard Co-Authored-By trailer (coordinator, 07:15Z). Tests/docs/test support only, so merged without David's review under the merge policy. The head branch was deleted automatically.

## 6. Gate notes written before the merge

- The Mac run passed.
- Before merging, check that the head is still `be06100`, that `trunk_dev` is still `df46164`, and that CI on `be06100` is green. The run was in progress when this report was written; the result goes in the thread.
- The audit (`03-audit.md`) and the re-audit (`05-reaudit.md`) accepted the PR's content, which is unchanged by the merge.
