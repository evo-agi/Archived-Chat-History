# ES tests on macOS: cause, classification and fix (PR #23)

**Verdict: IMPLEMENTED, tests/test-support/docs only. Draft PR [#23](https://github.com/evo-agi/Execution-Substrate/pull/23) at `978fa68`. Needs a fresh independent audit and a confirming Mac run (brief `02-mac-brief.md`; David writes "go ahead" in this thread).**

```text
IMPLEMENTATION REPORT
Objective:        find why ES tests fail on macOS, whether macOS is meant to be supported,
                  and fix it properly without weakening any product symlink rule
Repository:       evo-agi/Execution-Substrate
Base ref and SHA: origin/trunk_dev bc9fe3619823245faf550db4bf1bc3e782fbd5a5
Topic branch:     claude/project-thread-qx9d46
Topic commit SHA: 978fa6887aa73b719392014b6a8655056c4d9664 (parent bc9fe36)
Tree SHA:         0b0dde45d704d780fce63609c9145a88e32463ad
Final working-tree status: clean after commit (git status --porcelain empty)
Effect status:    TOPIC_BRANCH_PUSHED | DRAFT_PR_OPENED https://github.com/evo-agi/Execution-Substrate/pull/23 |
                  MERGE_NOT_PERFORMED | INDEPENDENT_AUDIT_NOT_PERFORMED | MAC_RUN_NOT_PERFORMED
```

Everything below that says "simulation" ran on Linux in a cloud container, not on a Mac.

## 1. Is macOS a supported platform? (step 1)

Repo-validated at `bc9fe36`:

- **Not a deployment platform.** Remote Alpha is Linux; the supported-local reference profile on the Apple Silicon Mac is a Lima `qemu` Ubuntu 24.04 arm64 guest (`PLANS.md:206`, `.docs/system_overview/architecture.md:83`). CI runs only on `ubuntu-24.04` (`.github/workflows/go.yml:27`) and is "not a macOS run" (`.docs/system_overview/go_toolchain_baseline.md:155`).
- **But a development platform whose test results count as evidence.** ES has build-selected Darwin implementations (`es/admission/execution_roots_darwin.go`, `staging_custody_darwin.go` and their tests); `PLANS.md:1110` says "Darwin uses no-follow-any opens, exclusive rename, and device verification"; `.docs/system_overview/capability_probing.md:365` says "Darwin syscall tests are current local runtime evidence"; CI vets every package for darwin/arm64 because "Some test files build only on macOS" (`go.yml:73-77`). `implementation.md:820` adds that Darwin tests are no substitute for Linux mount-crossing validation.

Conclusion: the tests are meant to run on macOS. A test that fails, or passes for the wrong reason, there is a test defect, not a platform gap. Nothing in the repo asks for the product to accept symlinked roots on macOS, so the product rules stay as they are.

## 2. Cause (reproduced)

macOS gives processes `TMPDIR=/var/folders/…/T/`, and `/var` is the symbolic link `/var -> private/var` (also `/tmp -> private/tmp`). ES refuses a symbolic link in any component of the paths it is configured with: Go no-follow opens component by component (`es/admission/staging_custody.go:384-420`, `openQualifiedDirectoryClean`), the reliable-submit store's `rejectSymlinkPath` (`es/admission/internal/reliablesubmit/sqlite_store.go:796-820`, called from `replay_custody_file.go:160-161`), the TLS status collector's no-follow walk, and the supported-local execution-root helper (`scripts/72_supported_local_setup.sh:174-175`). Tests that hand ES a path below `t.TempDir()` therefore test that refusal.

The repo already knew this in places: `physicalTestTempDir` (`es/admission/staging_custody_test.go:16`), `sqliteTestPath` (`reliablesubmit/sqlite_store_test.go:1045`) and the TLS harness's `pathlib.Path(root).resolve()` (`remote_alpha_es_service_tls_status_test.go:247`) resolve the path. The failing tests are the ones that do not.

**Simulation:** a temporary directory below `/macsim/var/folders/zz/abc123/T` with `/macsim/var -> private/var` (root-owned ancestors, `T` owned by the test user, mode 0700, as on macOS). Run as an unprivileged user `ci` (uid 1500, gid 1600), `env -i`, umask 022, Go 1.26.5 at `/opt/go1.26.5`, `GOTOOLCHAIN=local GOPROXY=off GOFLAGS=-mod=readonly`. Scripts: `01-evidence/run_as_ci.sh.txt`, `full_both.sh.txt`.

- It reproduces the PR 20 Mac run exactly: the same 15 `es/admission` tests with the same messages, and `TestRemoteAlphaESServiceTLSStatusReaderDocumentAcceptance` with `fresh pass refused: exit status 1: Incomplete`. With a physical `TMPDIR` the same commands pass (`01-evidence/repro-pr20-mac-run.txt`).
- Over the whole module (`01-evidence/sim-base-bc9fe36.txt`): **59 top-level tests fail** that pass with a physical `TMPDIR`. The Mac run had only covered two of these four packages.

## 3. Classification of every affected test

| Package | Tests | Message | Cause (path in the test fixture) | Type |
| --- | --- | --- | --- | --- |
| es/admission | 9 `TestPrivateReplay*` | `reliable submit store: unsupported format` | `privateReplayTestRoot`: `parent := t.TempDir()` (`reliable_submit_replay_private_test.go:31`) → `rejectSymlinkPath` | test/fixture gap |
| es/admission | `TestNewServiceRejectsDualMissingExecutionRootsBeforeMutation`, `TestRetainedResultReviewStartupNaturalDirectoryMask` (3 masks), `TestRetainedResultReviewFreshServiceReopensPersistedResultWithReloadedKey` | `retained result authentication key is unavailable` | key file in `newExecutionRootStartupTestConfig`: `configDir := t.TempDir()` (`service_direct_test.go:506`); key load opens component by component with no-follow | test/fixture gap |
| es/admission | `TestRetainedResultAuditF1RenderedConfigConstructsConfiguredService`, `…UsesExactKeyParentWithPaddedRoots`, `…PreservesSpaceBearingKeyAncestor` | `validate execution.runtime_support_binary: too many levels of symbolic links` | runtime support binary in the same `configDir` | test/fixture gap |
| root | `TestRemoteAlphaESServiceTLSStatusReaderDocumentAcceptance` | `fresh pass refused: … Incomplete` | fixture root `t.TempDir()` (`remote_alpha_es_service_tls_renew_test.go:54`); the run harness resolves it (`…status_test.go:247`), the document validator does not (`…status_test.go:553`). Inference: the validator's relocated paths then differ from the record's. Confirmed indirectly: it passes once the directory is physical | test/fixture gap |
| root | 16 more `TestRemoteAlphaESServiceTLSStatus*` (Collection ×2, FailureWitness ×4, LeafSwapToFIFORefusal, MaterialByteBinding, ReaderProtectedFile, ReaderSemanticConsistency, RelatedConfigHandling, SafeAbsenceUnsafeAncestry, SingleSelectedTrustAnchorCardinality, StrictJSON ×2, Target3013FailurePublicationSemantics) | e.g. `primitive origin misclassified … opens:[/ macsim]`, `collector-emitted record rejected: … Incomplete` | the collector's no-follow walk stops at the `var` link | test/fixture gap |
| reliablesubmit | 25 (`TestPrivateReplayProgress*`, `TestReplay*`, `TestSQLiteV4*`, `TestSQLiteMigration*`, …; full list in `sim-base-bc9fe36.txt`) | `reliable submit store: unsupported format` (and messages derived from it) | raw `t.TempDir()` roots → `rejectSymlinkPath` | test/fixture gap |
| es/app | `TestSupportedLocalExecutionRootFailedProvisionEmitsNoEvidence`, `TestSupportedLocalExecutionRootPrivilegeGateBeforeMutation` | `supported-local execution-root scope is invalid` | proof dir below `t.TempDir()`; the roots helper's preflight refuses it before the step the test is named for | test/fixture gap |

**Tests that pass on macOS for the wrong reason.** Each top-level test of the 11 packages that use temporary directories was run alone with a physical and a symlinked `TMPDIR`, recording Go coverage of the whole module (`01-evidence/covdiff.sh.txt`, `covcmp.py.txt`, results `coverage-base-bc9fe36.txt`). Seven tests pass both ways but, behind the symlink, end in the symlink refusal instead of the check they are named for:

- es/admission: `TestRetainedResultAuthRequiredStartupFailsWithoutKeyAndPrepareOnlySkipsIt`; `TestPreflightOptionalOwnershipNormalizationMarkerBlocksMissingMarkerInNonRootRequiredMode`, `…BlocksTargetOwnerMismatchInNonRootRequiredMode`, `…RejectsWorldWritableMarkerAuthorityPath` (they assert only `err != nil`; behind the symlink the error is `ownership-normalization authority directory is not readable`, `writablestate_preflight.go:86`).
- reliablesubmit: `TestReplayExistingStateModeNotRepaired`, `TestPrivateReplayProgressFormatVectors`, `TestSQLiteLiteralInternalNamespaceQualification` (mac-only coverage `sqlite_store.go:815-817`, the symlink refusal).

Coverage limits: it sees only Go code in the test process. Python and shell code (most of the root package) and re-executed child test processes are invisible, so more wrong-reason passes may exist there. Unknown at base; removed by construction by the fix below.

## 4. The fix and why this one

**Implementation decision.** Fixing each failing call site (the coordinator's example) would mend the 59 failures, but not the wrong-reason passes I could not see, and nothing would stop the next test from repeating it: CI runs on Linux with a physical `/tmp`, so it can never show this. Putting a symlinked `TMPDIR` into CI was rejected: it would turn refusal tests that use raw `t.TempDir()` into wrong-reason passes in CI as well. A macOS CI job would catch more (see §8) but is a larger decision.

So the rule is applied where every temporary path comes from, once per test binary:

- **`internal/testtmpdir`** (new, test support; no command or service imports it). `Main(m)` calls `Resolve()` and then `m.Run()`. `Resolve()` takes `os.TempDir()`, requires an absolute path to a directory, resolves it with `filepath.EvalSymlinks`, and **only when the result differs** checks that it is the same directory (`os.SameFile`) and resolves again to a fixed point, then sets `TMPDIR` to it. Where the path is already physical it changes nothing, an unset `TMPDIR` included, so the Linux CI runner runs exactly as before. If anything fails, the binary prints `testtmpdir: <reason>`, runs no test and exits 2.
- **`testtmpdir_main_test.go`** in each of the 21 existing test packages: `func TestMain(m *testing.M) { os.Exit(testtmpdir.Main(m)) }`. No package had a `TestMain` before.
- **Guard** `TestEveryTestPackageResolvesTheTemporaryDirectory`: walks the module with the go command's rules (skips `.`/`_` names, `testdata`, `vendor`, nested modules), requires at least 22 test packages and specific known ones, and for each requires exactly one `TestMain` whose only statement is `os.Exit(testtmpdir.Main(m))`, importing `os`, `testing` and `testtmpdir` under their own names, in a file that builds for linux/amd64, linux/arm64, darwin/arm64 and darwin/amd64 (`go/build` `MatchFile`). `TestGuardRefusesTestMainsThatDoNotResolve` checks the guard on 10 written cases.
- **Behaviour tests** `TestResolvedDirectoryReachesEveryTestAndChild` (re-runs the test binary with: macOS layout `…/var/folders/zz/T/` behind `var -> private/var`; last component a link; physical path with trailing slash, kept byte for byte; unset `TMPDIR`, expected unchanged where `/tmp` is physical and resolved where it is a link) and `TestUnresolvableDirectoryRunsNoTest` (missing, relative, regular file, dangling link, link to a file: exit 2, reason printed, no `=== RUN`).
- **Docs:** `.docs/system_overview/capability_probing.md`, section "Test Harness Use", three paragraphs; `TestTheRuleIsDocumented` holds nine phrases of it.
- **`docs_contract_test.go`:** the exact reliable-submit inventory goes from 33 to 34 files and names the new file.

**Current-contract treatment:** no product code, contract, startup validation, capability probe or symlink rule changes. The existing per-call helpers stay (now no-ops on an already physical path).
**Strategic-target treatment / reopened seams:** none touched.
**Compatibility treatment:** none.

## 5. Files touched (25, all tests, test support or docs)

| Path | Class | Summary |
| --- | --- | --- |
| `internal/testtmpdir/testtmpdir.go` | test support (new package) | `Main`, `Resolve`, `ExitResolveFailed = 2` |
| `internal/testtmpdir/testtmpdir_test.go` | test | behaviour tests, guard, guard self-test, doc test |
| `testtmpdir_main_test.go` and 20 more `<pkg>/testtmpdir_main_test.go` | test | the one-line `TestMain` in each test package |
| `.docs/system_overview/capability_probing.md` | doc | the rule, in "Test Harness Use" |
| `docs_contract_test.go` | test | reliable-submit inventory 33 → 34 |

## 6. Validation

All on Linux amd64 in the cloud container; user `ci` with passwordless sudo unless stated. "fix" runs used the working tree that was then committed (bytes verified identical with `cmp` for all 25 paths) or the commit itself where stated.

| What | Command | Result |
| --- | --- | --- |
| Build, vet | `go build ./...`; `go vet ./...`; `GOOS=darwin GOARCH=arm64 go vet ./...` | exit 0, no output |
| Format | toolchain `gofmt -l` on the 25 paths; `git diff --check` | no output |
| New package, both modes | `go test -count=1 -v ./internal/testtmpdir`, physical and symlinked `TMPDIR` | all pass (5 tests, 21 subtests) |
| Mutants | `01-evidence/mutants.py.txt` → `mutants.log` | **11 of 11 caught** (no-op `Resolve`, tests run after a failed resolve, `TMPDIR` set when already physical, `TMPDIR` set to the given path, `Abs` instead of `EvalSymlinks`, file accepted, guard accepts all, guard skips build constraints, `es/admission` without `TestMain`, `es/app` `TestMain` Linux-only, root `TestMain` bypasses `Main`) |
| Whole module, base, both modes | `go test -count=1 -json ./...` | physical: only the 10 environment-only entries fail (plus their parents); symlinked: 59 more (§2) |
| Whole module, fix, both modes | same | **identical results** physical vs symlinked (5256 pass, 68 skip, same failures). One docs-contract failure in that run came from the inventory count, fixed before the commit and passing in every later run |
| Wider simulation, no sudo | chroot with `/tmp -> private/tmp` plus symlinked `TMPDIR` (`macroot.sh.txt`), base and fix, vs plain Linux without sudo | fix: **no failure caused by the macOS paths**; the only difference is that an environment-only test passes because `/private/tmp` exists in the chroot. Base: the same 59 fail. Without sudo three `es/admission` tests skip, as on the Mac (`sim-wider-chroot.txt`) |
| Whole module on the commit `978fa68`, physical | `go test -count=1 -json ./...` | **identical to base** apart from the new package: 5237 tests and subtests pass and 48 skip (5257 and 68 counting package results); only the 10 environment-only entries fail (`final-978fa68.txt`) |
| Whole module on the commit, symlinked | same | **identical to the physical run on the commit**: 0 differences over every test and subtest; the 59 tests that fail at `bc9fe36` in this mode all pass (`final-978fa68.txt`) |
| Per-test coverage on the commit, both modes | `covdiff.sh` over the 12 packages (1351 top-level tests, each run alone) | **no test changes status, and no covered block differs outside `internal/testtmpdir/testtmpdir.go`** (which takes its other branch by design). The 7 wrong-reason passes now cover the same product code in both modes (`coverage-fix-978fa68.txt`) |
| CI on PR #23 | GitHub Actions "build, vet and test" (run 45121907187, job 137517361733) on `978fa68` | **success** (06:06Z to 06:19Z); PR mergeable state clean |

Skipped or not possible here: any run on macOS (Darwin syscalls, `F_GETPATH`, the real `/var/folders` layout, `/etc -> private/etc`); bindfs tests (bindfs not installed in the container; they skip; CI installs it); Docker/Nomad/Vault `es/app` tests (skip here and on CI, listed `skips-itself`).

## 7. Provenance

- Recipe `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified).
- HEAD at base `bc9fe36`, upstream pinned to `origin/trunk_dev`, branch `claude/project-thread-qx9d46`. Two runs, byte-identical (`cmp`).
- textual-diff SHA-256 `4c2d6635b8e73efd57a8cd916ed0e79186b191b05571e54ae69cadd97e3edffb`
- canonical-manifest SHA-256 `0e8faf915f3a91123d3daa218fcbb095adf40baebfb1d43db0b7fb157bcca630`
- file count 25; full manifest: `01-evidence/manifest-978fa68.json`.
- Staged-set check: `git diff --cached --name-only --no-renames -z` equals the manifest path set. One commit; `git status --porcelain` empty afterwards. Upstream re-pinned to `origin/trunk_dev` after the push.

## 8. Assumptions, open points, risks

- **Guess:** the Mac will show the same as the simulation. Confirm with the Mac run (`02-mac-brief.md`). Unknown until then: Darwin-only differences beyond the path layout.
- **Not run on the Mac by the brief:** the rest of the root package and of `es/app` (some `es/app` tests drive Docker/Nomad/Vault when installed; three root tests write below `/private/tmp`). The simulation found no temporary-directory effect there.
- **Merge interplay:** PR #12/#13 change reliablesubmit. The inventory count line in `docs_contract_test.go` will conflict textually; a new test package there must add the `TestMain` or the guard fails (intended). PR #22 appends to `capability_probing.md`; this PR inserts mid-section, so no textual overlap is expected.
- **Option for the coordinator (not done):** ES is a public repository, so GitHub-hosted macOS runners cost no money. A macOS job would turn "Darwin syscall tests are current local runtime evidence" into CI evidence and would also have caught PR #22's hang. It needs its own environment-only list and gate design, so it is a decision, not part of this fix.
- **Product observation (not changed):** the reliable-submit store reports a symlinked root as `unsupported format`, which reads like a file-format problem to an operator. Product wording; for the coordinator to judge.
- Authority/security/protocol widening: none. Dependencies changed: none. Cross-repo impact: none.
- Artifact hygiene: no generated files committed; scratch clones and logs stayed in the container.

## 9. Confidence

- Provenance: high (recipe verified, two identical runs, staged-set check).
- Validation: high for Linux and the simulated macOS layout; none yet on a real Mac.
- Implementation: high that the failures and wrong-reason passes in the simulation are gone and cannot silently return in Go test packages; medium that a real Mac shows nothing else, until the Mac run.
