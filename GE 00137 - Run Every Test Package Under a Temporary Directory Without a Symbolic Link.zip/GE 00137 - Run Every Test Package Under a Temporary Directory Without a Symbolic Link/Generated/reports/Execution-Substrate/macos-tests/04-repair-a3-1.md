# ES PR #23: repair of audit finding A3-1 (and A3-2)

**Verdict: REPAIRED, tests only. PR [#23](https://github.com/evo-agi/Execution-Substrate/pull/23) head is now `98982a5` (one commit on top of the audited `978fa68`). Needs the narrow re-audit by the same auditor; the Mac brief now points at `98982a5`.**

```text
REPAIR REPORT
Objective:        fix audit finding A3-1 inside PR #23 (absent-key startup test must fail if its check is
                  removed); also close A3-2 (guard vs documented "no build constraint")
Audit answered:   macos-tests/03-audit.md, SHA-256 84f74aded822a58b821ff2886672c95d26ffcdcd9a99c2c460e6a274d04aa693
Repository:       evo-agi/Execution-Substrate
Base ref and SHA: origin/trunk_dev bc9fe3619823245faf550db4bf1bc3e782fbd5a5 (unchanged at 07:00Z)
Topic branch:     claude/project-thread-qx9d46
Audited commit:   978fa6887aa73b719392014b6a8655056c4d9664 (tree 0b0dde45d704d780fce63609c9145a88e32463ad)
Repair commit:    98982a5ba595f41bc24be359d94f96811e8492e1 (parent 978fa68, fast-forward, no rewrite)
Tree SHA:         f88f9e0a837560967d550ce35b05cafa22739bcc
Final working-tree status: clean after commit
Effect status:    TOPIC_BRANCH_PUSHED (978fa68..98982a5) | PR_BODY_UPDATED | MERGE_NOT_PERFORMED |
                  RE_AUDIT_NOT_PERFORMED | MAC_RUN_NOT_PERFORMED
```

Everything below ran on Linux amd64 in the cloud container (user `ci`, Go 1.26.5), not on a Mac. Times are UTC, 2026-11-23.

## 1. A3-1: absent-key startup test

**Before** (`es/admission/service_direct_test.go:86-109` at `978fa68`): both execution roots were missing, so a startup that skipped the key check still failed, with "dual-missing execution roots share one unobserved lookup context". The test asserted only that startup failed, did not name the key path, and created no root.

**Now** (same test, `service_direct_test.go:86-139` at `98982a5`):

1. The staging root exists (0755) and the results root does not. A configured startup that gets past the key would start and provision the results root, so the absent key is the only refusal the fixture can reach.
2. With the key file removed, the test asserts: startup fails, no service is returned, the error contains `retained result authentication key is unavailable`, and the error does not contain the key path (kept from before).
3. No effects: the results root does not exist, and the staging root is empty.
4. Control: the same key bytes are written back to the same path with mode 0600, and the same configuration starts with an authenticator (`service.resultAuth != nil`) and provisions the results root. This proves that steps 2 and 3 are not satisfied by any other refusal, and that "results root not created" is a real check.
5. The key is removed again before the existing prepare-only part, which is unchanged: Submit not configured, the service starts without requiring the key.

Mutants (`04-evidence/mutants-a3-1.txt`; mutants in `a31_mutants.py.txt`, runner `a31_run.sh.txt`). Each was applied alone and the file restored afterwards; both trees were clean at the end. phys means `TMPDIR=/physim/T`; sym means `TMPDIR=/macsim/var/folders/zz/abc123/T/` behind `/macsim/var -> private/var`.

| Mutant | Change in product code | `978fa68` test (phys / sym) | `98982a5` test (phys / sym) |
| --- | --- | --- | --- |
| control | none | pass / pass | pass / pass |
| MK1 (the auditor's, byte for byte) | absent key accepted, startup goes on without an authenticator (`result_auth.go`) | survives / survives | **killed** / **killed** (`:109`, service returned, err nil) |
| MK2 | key loaded only after the execution roots are provisioned (`service.go`) | survives / survives | **killed** / **killed** (`:112`, results root provisioned) |
| MK3 | absent key refused with a non-key message (`result_auth.go`) | survives / survives | **killed** / **killed** (`:109`, wrong error) |

Inference: MK2 also shows that the new layout checks the order "key before roots", which the old layout (both roots missing, so refused before provisioning either way) could not check.

## 2. A3-2: the guard now refuses any build constraint line

The documented rule says the `TestMain` file has no build constraint. The guard checked only that the file builds on linux/amd64, linux/arm64, darwin/arm64 and darwin/amd64, so `//go:build unix` passed. Now `testMainProblem` also refuses a `//go:build` or `+build` comment before the package clause (`go/build/constraint`; the file is now parsed with comments). The four-platform check stays and still catches file-name suffixes such as `_linux_test.go`; the doc did not need changing.

Three new self-test cases: `//go:build unix` is refused ("has a build constraint"); `// +build !windows` is refused; a plain comment that only mentions `//go:build linux` is accepted. Guard mutant G15 (the new check disabled) is killed by the first case in both modes (`mutants-a3-1.txt`).

## 3. A3-3 (report correction)

`01-implementation.md` said the new package had "5 tests, 21 subtests" at `978fa68`. That was wrong: it had 5 tests and 19 subtests, as the auditor counted. At `98982a5` it has 5 tests and 22 subtests (4 + 5 + 13). This report corrects the count; `01-implementation.md` is left as it was, because the audit points to its hash.

A3-4 needs no change for this PR; the Mac run is the check.

## 4. Validation of the repair

| What | Result |
| --- | --- |
| The repaired test alone, phys and sym | pass |
| `go test -count=1 -json ./es/admission ./internal/testtmpdir`, phys and sym | exit 0 in both; 433 top-level tests pass, 8 skip (1130 with subtests), **0 differences** between the modes (`04-evidence/packages-98982a5.txt`) |
| `go vet ./es/admission ./internal/testtmpdir` for linux/amd64, linux/arm64, darwin/arm64, darwin/amd64 | exit 0 on all four |
| Toolchain `gofmt -l` on the two changed files; `git diff --check` | no output |
| Tested content equals the commit | `git hash-object` of both files in the test tree equals the blobs in `98982a5` |
| CI on `98982a5` | pending when this report was written; reported in the thread and on the PR checks |

Not re-run for this repair: the whole-module runs and the per-test coverage comparison. The repair changes only these two test files, and both packages were run in full in both modes. No other test or document refers to the changed test (`grep` over the repository).

## 5. Provenance

- Recipe `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (`sha256sum -c` OK).
- Fresh clone, umask 022. `origin/claude/project-thread-qx9d46` = `98982a5`, tree `f88f9e0a`, `origin/trunk_dev` = `bc9fe36`, base is an ancestor. `git reset --mixed bc9fe36`, upstream pinned to `origin/trunk_dev`, recipe run twice to two absent paths in a fresh 0700 directory: **byte-identical**.
- canonical-manifest SHA-256 `11fc280522b81c813929c9129b3fb4761e8644fcd7642ed56c3b82eaaff01967`
- textual-diff SHA-256 `4599a45b2b94d34e22f6a85aa94dbafa51a7a0996b8c7b5aa7515de8dd9ee1fe`
- file count 26 (the 25 of `978fa68` plus `es/admission/service_direct_test.go`). Compared with `manifest-978fa68.json`, only two entries differ: `es/admission/service_direct_test.go` is new (tracked_modified, sha256 `528320ec…`), and `internal/testtmpdir/testtmpdir_test.go` changed (`d31029f8…` to `f3552d0a…`). Full manifest: `04-evidence/manifest-98982a5.json`.
- The working clone's upstream was re-pinned to `origin/trunk_dev` after the push.

## 6. For the re-audit and the merge gate

- Narrow re-audit scope: the diff `978fa68..98982a5` (two test files), sections 1 to 3 above, and the provenance of section 5.
- Mac run: `02-mac-brief.md` now checks out `98982a5` (tree `f88f9e0a`). Its expectations are unchanged. The repaired test is part of step b (`es/admission`).
- Tests only, so under the merge policy David does not review it. Before merge, the head must still be `98982a5` and `trunk_dev` still `bc9fe36`; otherwise the branch needs updating and a new manifest.

## 7. Confidence

- Repair: high. Every mutant of the check survived the old test and is caught by the new one, in both modes. The control proves the fixture reaches no other refusal.
- Provenance: high (recipe verified, two identical runs).
- Real Mac: not run yet.
