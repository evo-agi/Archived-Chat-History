The macOS test fix is up as a test-only PR, so it's going to audit.

STATUS: WORKING (nothing new needed from you)
