**David, please write "go ahead" in this thread to start the Mac check of the fix.** It is read-only, takes about 10 to 15 minutes, and cleans up after itself. The steps are in [02-mac-brief.md](/mnt/project-files/reports/Execution-Substrate/macos-tests/02-mac-brief.md).

The fix is in draft [PR #23](https://github.com/evo-agi/Execution-Substrate/pull/23). It changes only tests and docs, and CI is green.

- **Cause:** macOS keeps its temporary folder behind the link `/var -> private/var`. ES rightly refuses paths that contain a link, so on a Mac these tests hit that refusal instead of what they are meant to test.
- **More than the Mac run showed:** 59 tests fail on that layout, and 7 more pass for the wrong reason.
- **The fix:** every test package now starts from the real, link-free path. A guard test fails if a package skips this. ES's own link rules are unchanged.
- **Checked on Linux:** with a copy of the macOS layout, the whole module now gives the same results as plain Linux.
- **Platform:** macOS is a development platform, not a deployment target.

The independent audit can start now, alongside the Mac check. Full report: [01-implementation.md](/mnt/project-files/reports/Execution-Substrate/macos-tests/01-implementation.md) (SHA-256 ec444b03…7b70).

STATUS: NEEDS DAVID
