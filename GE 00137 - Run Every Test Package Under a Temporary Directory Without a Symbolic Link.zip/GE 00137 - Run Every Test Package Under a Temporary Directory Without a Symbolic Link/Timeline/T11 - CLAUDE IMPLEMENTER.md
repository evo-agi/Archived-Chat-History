A3-1 is fixed inside PR #23, and the narrow re-audit can start. The new head is `98982a5`, one commit on top of the audited `978fa68`. CI on it is still running.

- **The test now depends on the key check.** The staging root exists and the results root is missing. So a startup that skipped the key check would succeed and create the results root. The test now checks the key refusal itself, that nothing was created, and, as a control, that the same setup starts once the key is back. All three ways of breaking the check slipped past the old test, and the new test catches all three, with a normal and a macOS-style temporary folder.
- **A3-2 is fixed in the same commit.** The guard now refuses any build-constraint line in the test startup file, as the doc says. The report also corrects the A3-3 count.
- **The Mac brief now targets `98982a5`.**

Report: [04-repair-a3-1.md](/mnt/project-files/reports/Execution-Substrate/macos-tests/04-repair-a3-1.md) (SHA-256 2b3199fa…78e1). Brief: [02-mac-brief.md](/mnt/project-files/reports/Execution-Substrate/macos-tests/02-mac-brief.md).

David, the Mac check still waits for you to write "go ahead" here.

STATUS: NEEDS DAVID
