I'm going to bed now. Do I need to keep the Mac awake?
