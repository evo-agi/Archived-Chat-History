The collector fix needs one more Mac check. The macOS test fix that just merged lets tests on your Mac reach the exact code PR 22 repairs, so the last run no longer covers it. Please write "go ahead" again in that thread. It's the same 10-minute run in Playground.

Also done: the macOS test fix ([PR 23](https://github.com/evo-agi/Execution-Substrate/pull/23)) is merged as 200fd60 after your Mac confirmed it.

STATUS: NEEDS DAVID ("go ahead" in the collector thread; words or bare text on the phone)
