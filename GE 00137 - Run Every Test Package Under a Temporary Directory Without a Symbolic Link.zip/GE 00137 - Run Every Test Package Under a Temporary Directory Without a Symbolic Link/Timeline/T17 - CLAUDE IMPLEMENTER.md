Checking the PR head hasn't moved, then starting the Mac check in Playground.
