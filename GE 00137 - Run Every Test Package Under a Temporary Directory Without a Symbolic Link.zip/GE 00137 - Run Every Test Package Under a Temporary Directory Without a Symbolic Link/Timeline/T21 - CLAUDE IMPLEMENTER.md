The Mac check is running in Playground now and should take 10 to 15 minutes. `trunk_dev` had moved on (PRs #19 and #24), so I merged it into the PR branch first. There was no conflict, and the PR's own changes are line for line the same as what was audited. The Mac run tests that merged head against the new `trunk_dev`. The [brief](/mnt/project-files/reports/Execution-Substrate/macos-tests/02-mac-brief.md) is updated to match.

STATUS: WORKING
