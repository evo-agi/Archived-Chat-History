Morning summary. Three small things need you when you're up, and everything else is moving.

**Done**
- PR 13, the core submit fix, passed its audit after the package split, and its red-team is running on Opus.
- The macOS test fix ([PR 23](https://github.com/evo-agi/Execution-Substrate/pull/23)) and the collector fix ([PR 22](https://github.com/evo-agi/Execution-Substrate/pull/22)) both passed their audits.

**Still working:** PR 19's repair and the maintenance agent's last two small fixes.

**Needs you**
- **Two Mac checks** that unblock the PR 22 and PR 23 merges. Write "go ahead" in [Fix TLS status collector hang](#cmsg_01Un4xQgjBAczV8DABQvcLrxUKRNzSrmXnB75DgsbjDwit) and in [Fix ES tests failing on macOS](#cmsg_01Un4xQgjBAczV8DABQvcLrx4gM6ahSVBGrEpVyG4cBnWL).
- **Maintenance agent, one choice:** if an alert can't be shown on your Mac (asleep, Focus blocking it), today it waits indefinitely and nothing reaches your phone. I recommend a short text to your phone that only says "the maintenance agent needs attention", with no details. Yes or no?
- **Maintenance agent, for your information:** under your rule, certificates, disks and Vault standby also raise the one-time "please investigate" notification when a warning persists. Each one is followed by an "OK now" when it clears. Tell me if any of those should stay summary-only.

STATUS: NEEDS DAVID (two "go ahead"s, one yes/no on the phone text)
