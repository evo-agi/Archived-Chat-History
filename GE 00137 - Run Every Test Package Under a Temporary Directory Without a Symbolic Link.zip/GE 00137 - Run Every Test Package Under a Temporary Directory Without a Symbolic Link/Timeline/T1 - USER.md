<!-- reply 1 -->
> The bring-up fix is up as PR 18 (→ github.com), green on GitHub, with ES running as your user instead of root. I'm start…


Similarly, for this one, I won't be reviewing doc changes or script changes. Also, we need to survey the available runbooks across all repos, namely what you can see, and consolidate them by creating/updating runbooks in the archived runbook repo. If the runbook repo already has the runbooks, please simply remove. Anyway, back to the PR, under the constraints, I'm not reviewing PR 18.

And, yes, please delete test branches. Also, after a PR is merged, unless you still need the underlying branch you push from, please delete after merge.
