I can't change another thread's model, and a thread changes its own only when you ask it there yourself. You don't need to do anything, though. The collector thread has already started your Mac check. If it hits the Fable limit, I'll carry the work on in an Opus thread from its saved state. Noted on the branches, there's no rush.

STATUS: WORKING (Mac checks for PR 22 and PR 23, PR 13 re-audit, PR 25 audit, MA repair; nothing needed from you)
