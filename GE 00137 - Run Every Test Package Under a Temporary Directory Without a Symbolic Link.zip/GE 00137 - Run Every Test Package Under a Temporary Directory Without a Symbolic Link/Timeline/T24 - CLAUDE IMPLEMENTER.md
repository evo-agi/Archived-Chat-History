PR [#23](https://github.com/evo-agi/Execution-Substrate/pull/23) is merged into `trunk_dev` as `200fd60`. Your Mac confirmed the fix.

- **With the fix:** everything passes except two tests that need production probes. Those two fail the same way without the fix.
- **Without it:** exactly the 59 failures the simulation predicted.

Nothing is left on your Mac. Details: [07-mac-run.md](/mnt/project-files/reports/Execution-Substrate/macos-tests/07-mac-run.md).

One note for later: any new test package, including ones from PR #12/#13, needs the one-line test startup file, or a guard test fails.

STATUS: READY
