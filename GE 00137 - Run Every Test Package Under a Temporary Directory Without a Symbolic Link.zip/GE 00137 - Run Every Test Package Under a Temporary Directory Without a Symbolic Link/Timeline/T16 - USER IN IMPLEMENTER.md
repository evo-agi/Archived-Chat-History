Please go ahead with the Mac check.
