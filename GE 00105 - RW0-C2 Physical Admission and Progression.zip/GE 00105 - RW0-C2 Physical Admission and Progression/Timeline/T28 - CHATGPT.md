## Disposition

```text
RW0_C2_P0_P1_COMMAND_DIGEST_V2_AND_PROTECTED_DISCLOSURE_REPAIR
REPORTED_COMPLETE_PENDING_ARTIFACT_INSPECTION
```

The implementation report supports advancing toward a fresh cumulative audit. It does **not** yet establish acceptance or commit eligibility.

The reported successor is:

```text
Branch:
codex/rw0-c2-p0-p1-physical-program-v1

Baseline HEAD:
4519630d0db967066beb21b4ace5004e76827716

Opening tree:
8e247b21320f90d2d2cb98d3d165f7fc35f117a8

Final tree:
58444e6a1c9526a524818e8729398ff0ab381837

Source paths:
315

Cumulative worktree:
56 modified
16 untracked
0 staged
```

The prospective authoritative-ref map reportedly remained fixed through cleanup, all 18 qualified diagnostic refs remained unchanged, and the historical complete-ref mismatch remains explicitly unresolved rather than backdated. Pasted text

## Repair assessment from the report

The reported F1 treatment matches the selected architecture:

- `expected_branch` is now bound by a **31-pair guarded-command-digest v2**.
- The historical 30-pair relation digest remains predecessor evidence.
- The six branch-neutral preassignments remain unchanged.
- Current durable planning, receipts, replan-derived identities, replay association, route checks, and competing-winner verification use the complete command-level digest.
- Commands differing only in `expected_branch` therefore retain the same family route but no longer qualify as exact replay. Pasted text

The reported F2 treatment also follows the governing disclosure contract:

- Receipt-present replay, read, and recovery require fresh `write=False` disclosure posture before command comparison or family reconstruction.
- Fresh receipt-miss recording continues to require recording posture.
- Denied, expired, malformed, or mismatched disclosure returns no committed result and makes recovery `unresolved`.
- Positive disclosure permits exact replay even when fresh recording permission is absent. Pasted text

These directly address the prior independent audit findings that changed `expected_branch` was not part of exact replay identity and that committed P1 results could be disclosed without current positive posture. Pasted text

The retained validation claims are:

| Gate | Reported result |
|---|---:|
| Direct F1/F2 | 131 passed |
| Connected five-branch path | 5 passed |
| Focused 49-module selection | 5,819 passed |
| Selector-free FULL | 9,461 passed |

The report says every gate had exact collection, execution, and JUnit order equality, with zero failures, errors, or skips. Migrations 0006 and 0007 reportedly remained byte-identical, and direct SQL application retained the 68/122/5 and 74/134/5 schema inventories. Pasted text

## What is still missing here

Only the response summary was attached. I have **not** authenticated or inspected:

```text
rw0-c2-p0-p1-command-digest-v2-protected-disclosure-uncommitted-review.zip
```

Reported identity:

```text
Bytes:
33,728,895

SHA-256:
aa7d22d6df888c0928917939957fc6746c5064c83b75c949360155ab151e39b8
```

Nor was the exact standalone implementation report attached:

```text
IMPLEMENTATION_REPORT.md

Bytes:
25,174

SHA-256:
ff2691d3c5e74959abbb6a4414af47e99bb045b50a0134d00a42a652487d710b
```

The ZIP reportedly contains 532 verified members and a byte-identical embedded copy of that report. Pasted text

Without those bytes, I cannot independently reconstruct tree `58444e6a…`, inspect the changed source, verify that every durable call site uses command-digest v2, reconcile the disclosure API ordering, or authenticate the 9,461-test records.

## Next action

**Do not send another prompt to Codex yet. Keep the implementation conversation idle.**

Attach the existing review ZIP and exact standalone implementation report here. Do not regenerate them. After authenticating and inspecting the cumulative package, the next gate should be a **fresh independent artifact-only audit** of the complete 315-file subject—not merely the latest F1/F2 delta.

That audit will need to reproduce the previous two material cases, inspect competing-winner reconstruction and disclosure ordering, complete the broader causal register that the prior audit stopped before running, and independently perform selector-free collection and the full 9,461-test execution.

No new Project-source snapshot is requested while the candidate remains uncommitted.

**Sources:** Codex’s attached implementation closeout and the preceding independent cumulative audit.

**Confidence:** report interpretation **0.99**; claimed repair design **0.96**; package provenance and runtime correctness **pending exact artifact inspection**.
