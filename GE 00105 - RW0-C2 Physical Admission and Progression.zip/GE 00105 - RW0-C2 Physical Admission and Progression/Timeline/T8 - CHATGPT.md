## Disposition

```text
RW0_C2_P1_REPLAN_PREASSIGNMENT_CYCLE_RESOLVED
CONTINUE_SAME_P0_TO_P1_IMPLEMENTATION_PROGRAM
```

Codex stopped correctly. The blocker is a **real dependency cycle**, but it is not a P0 defect and does not justify splitting P0 into a standalone tranche.

The cycle came from the prior requirement that the cognitive replan proposal contain a complete `WorkSpecV1` already naming the new program version, while that version ref was itself derived from a decision-basis digest containing the WorkSpec projection. The partial candidate therefore could not close either value first without a placeholder, a fixed-point construction, or changing existing 0002 semantics. rw0-c2-physical-p0-p1-implement…

Codex correctly preserved P0 and stopped before claiming a P1 writer, replay, recovery path, or connected five-branch implementation. Pasted text

I authenticated the supplied review ZIP:

```text
Bytes:   7,423,654
SHA-256:
f70510a1f0b9763a89f998ee51dd3d81a54a4d07433b7961f4ed650c9349677e
```

Its 312 source files reproduce the reported partial tree:

```text
77f7e29033fc76de03667b810bd456536797850a
```

The embedded P0 checkpoint ZIP also matches its recorded identity:

```text
Bytes:   4,007,435
SHA-256:
f17070d682e5304662e157da457a8e14018a1e81966f8a4c05436f3f77151ed0

P0 tree:
fd45f05ff909493ff8984671a02be66d3b48a791
```

## Frozen correction

The cognitive side must provide a **version-neutral private WorkSpec template**, not a final `WorkSpecV1`.

The corrected dependency order is:

```text
private replan template
    → template digest and safe projection
    → cognitive proposal projection
    → decision-basis digest
    → existing six branch-neutral preassignments
    → command digest
    → Coordinator-derived replan row refs
    → final WorkSpecV1 bound to preassigned version
    → existing 0002 rows and P1 supplemental rows
    → receipt and COMMIT
```

This preserves the critical authority split:

- The cognitive proposal supplies proposed source-intent and work content.
- It selects neither the branch nor any durable row identity.
- The Coordinator derives the new accepted-intent revision ref, work-item revision ref, and WorkSpec ref after the command digest exists.
- The Coordinator then constructs the unchanged existing `WorkSpecV1` using its already preassigned program-version ref.
- Existing `WorkSpecV1`, `DevelopmentWorkSpecSafeProjection`, migration-0002 row meanings, and the six accepted branch-neutral preassignments remain unchanged.

The final WorkSpec digest becomes a deterministic **dependent output**, not an input to its own version-ref derivation. This is the narrowest noncircular design and is more authority-correct than allowing the model-side proposal to choose future durable revision identities.

I reject the alternatives:

- no placeholder or “temporary” version ref;
- no fixed-point hash search;
- no removal of the replan proposal from the decision basis;
- no caller-supplied final `WorkSpecV1`;
- no change to existing 0002 WorkSpec semantics;
- no seventh supplemental table solely to escape the cycle;
- no standalone semantic-contract tranche.

The original reconnaissance selected one P0→P1 program precisely so the saved P0 checkpoint could be followed by the connected five-branch implementation without a user-mediated architectural gap. Pasted text

## Next Codex handoff

Send **only this prompt** to the **same workspace-write Codex implementation conversation**:

:chatgpt-content-reference{index="4"}[**Continue P1 with the noncircular replan identity design**](sandbox:/mnt/data/Coordinator_RW0_C2_P1_Replan_Cycle_Resolution_Continuation_Prompt.txt)

Do not send the preceding continuation prompt with it. No attachments are required.

The replacement prompt:

- reauthenticates the exact current partial tree rather than discarding it;
- preserves the P0 migration and private owners byte-for-byte;
- replaces the flawed partial cognitive-proposal shape;
- defines the exact version-neutral template and safe projection;
- makes all new durable revision and WorkSpec refs Coordinator-derived;
- requires an early reopened acyclic identity checkpoint before any writer work;
- then resumes the P1 writer, replay, readback, recovery, all five branches, connected proof, focused validation, and selector-free FULL validation;
- returns one cumulative uncommitted package for fresh independent audit.

It authorizes no staging, commit, push, PR, merge, publication, live supplier work, terminal persistence, or product effect.

```text
Prompt bytes: 20,216
Prompt SHA-256:
ca576fcc4826653b19c7c1eb0ce1e45b32a2f491335d3f5fa629469d64d4a1ab
```

:chatgpt-content-reference{index="5"}[Handoff identity record](sandbox:/mnt/data/Coordinator_RW0_C2_P1_Replan_Cycle_Resolution_Handoff_Check.json)

The 34 passing targeted tests remain evidence for the stopped partial source only. P1 persistence, complete replay/readback/recovery, the connected five-branch proof, selector-free collection, and FULL execution remain unperformed. Pasted text

**Sources:** Codex’s blocker report and the supplied physical-implementation status document, cited above. I performed data-only package authentication and source inspection; I did not execute repository code, migrations, SQLite state, or tests.

**Confidence:** package provenance **0.99**; cycle diagnosis **0.99**; corrected authority and identity design **0.96**. Physical implementation and runtime correctness remain unestablished.
