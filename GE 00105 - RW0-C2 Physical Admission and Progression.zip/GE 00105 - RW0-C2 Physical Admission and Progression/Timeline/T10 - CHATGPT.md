## Disposition

```text
RW0_C2_P1_REPLAN_WORK_HEAD_BOUNDARY_RESOLVED
CONTINUE_SAME_P0_TO_P1_IMPLEMENTATION_PROGRAM
```

Codex stopped at a real contract boundary. The earlier replan identity cycle is resolved, but the partial P1 family cannot prove the historical work-item-head CAS after a later replan advances that mutable head. The current immutable family retains the program-head postimage only; reconstructing an expected old work head from revision and membership rows would not establish that the earlier physical head update occurred. Weakening replay to trust that reconstruction—or the receipt alone—would violate the selected whole-family verification rule. review-report

The partial P1 writer remains unimplemented and unreachable. The 67- and 89-test results apply only to the pure identity/plan and migration/P0 surfaces; physical P1 persistence, replay, recovery, connected five-branch execution, and selector-free FULL validation remain unperformed. review-report

I authenticated the supplied review ZIP and its current partial source:

```text
Review ZIP:
4f035c3127a0b468554a79ced6b2e001684e23927120ed2e7aae382f6ed00e95

Current partial source tree:
2d1d7c4ae95202193692a974cdee33f7a954b6cc

P0 checkpoint tree:
fd45f05ff909493ff8984671a02be66d3b48a791
```

The reported source, P0, migration, and checkpoint identities are internally consistent. Migration 0006 and the frozen P0 production paths remain preserved. review-report

## Selected correction

Use a **versioned guarded-relation and receipt-profile successor**, without adding a seventh table and without weakening historical replay.

The current implementation target becomes:

```text
governed-execution.nwp-rw0-c2-guarded-family-relation.v2
governed-execution.nwp-rw0-c2-guarded-progression-result.v2
governed-execution.nwp-rw0-c2-receipt-graph-profile.v2
```

Relation v2 preserves all existing fields and adds four replan-only fields:

```text
historical_work_head_ref
historical_work_head_revision
historical_work_head_digest
historical_work_head_postimage
```

For `attempt_selecting_replan`, those fields must contain one complete, canonical, typed `DevelopmentWorkItemHeadRowValue` postimage. For every other branch they must all be null.

Receipt profile v2 retains the ten existing common roles and adds one exact replan-only role:

```text
historical_work_head_postimage
```

The acceptance branch still has its acceptance-only role. Consequently:

- acceptance has ten common roles plus `acceptance_fact`;
- replan has ten common roles plus `historical_work_head_postimage`;
- repair, terminal reject, and block retain exactly ten roles.

The work-head witness is bound both through the guarded relation digest and through the branch-specific receipt-graph role. Migration 0007 remains a **six-table** migration. Its table/trigger/index counts remain 74 / 134 / 5; only the relation columns, constraints, FK inventory, schema IDs, and checksum advance.

The fresh replan transaction must CAS both mutable heads, read both back inside the same transaction, compare them exactly with the planned postimages, and insert the receipt last. Replay and recovery later verify the immutable postimages and exact graph without requiring current mutable heads to remain at their historical values.

The existing noncircular identity vector remains fixed through the command digest, six preassignments, Coordinator-derived replan refs, and final `WorkSpecV1`. Only downstream relation, result, graph, and receipt digests may change.

:chatgpt-content-reference{index="3"}[Engineering decision](sandbox:/mnt/data/Coordinator_RW0_C2_P1_Work_Head_Witness_Decision.md)

## Next Codex handoff

Send **only this prompt** to the **same workspace-write Codex implementation conversation**:

:chatgpt-content-reference{index="4"}[**Continue P1 with the versioned replan work-head witness**](sandbox:/mnt/data/Coordinator_RW0_C2_P1_Work_Head_Witness_Continuation_Prompt.txt)

Do not send either preceding continuation prompt alongside it. No attachments are required.

The prompt directs Codex to:

1. authenticate the exact current partial source and preserved P0 checkpoint;
2. implement the relation/result/profile v2 successor inside the same source/schema tranche;
3. save and reopen an early pure identity/profile checkpoint before writer integration;
4. complete the private P1 writer, replay, checked readback, and three-way recovery;
5. prove a later second replan can advance the work head while the first replan still replays exactly;
6. exercise all five physical branches and the connected P0→D1/D2→Section 41/C1/V22→P1 path;
7. run focused and selector-free FULL validation on final bytes;
8. return one cumulative, uncommitted review package for fresh independent audit.

It explicitly prohibits a seventh table, migration-0002 semantic changes, WorkSpec changes, new preassignments, placeholders, fixed-point hashes, staging, commit, publication, live supplier work, terminal persistence, or product effects.

```text
Prompt bytes: 23,552
Prompt SHA-256:
a5839bc1b8ac5a613b6b6c31f88d65e519ddd3ec73ca70b8b28421b8ff93138f
```

**Project snapshot:** no new Project-source snapshot is requested while this architecture-defining P0/P1 program remains uncommitted. The next snapshot point remains after independent acceptance and integration.

**Sources:** Codex’s work-head boundary report and authenticated review package, cited above.

**Confidence:** package/source provenance **0.99**; blocker diagnosis **0.99**; selected relation/profile correction **0.96**. Physical P1 implementation and runtime correctness remain unestablished.
