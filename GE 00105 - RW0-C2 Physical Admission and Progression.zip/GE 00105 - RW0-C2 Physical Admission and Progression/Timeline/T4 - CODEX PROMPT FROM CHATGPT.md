Permission is now workspace-write.

Continue in this same Codex conversation. Do not start another reconnaissance turn and do not spawn subagents. You are the sole repository writer.

OBJECTIVE

Implement one bounded artificial-offline RW0-C2 physical program in the Governed Execution Coordinator repository:

1. P0: program-independent scope-admission provisioning as the first saved, reopened, source-bound checkpoint.
2. P1: the five-branch physical progression-decision family in the same uncommitted candidate, consuming checked P0 admission and fresh decision-time guard/currentness evidence.

This is one implementation program with two separately owned transactions, receipts, replay paths, and recovery classifiers. P0 must remain independently attributable after its checkpoint, but it is not a standalone integration tranche and there is no user-mediated handoff between P0 and P1.

The preceding read-only report returned RECONNAISSANCE_PARTIAL because three authority/physical decisions were not frozen. This prompt resolves those decisions. Treat the report's source mapping, disagreement record, validation map, and touched-surface inventory as reconnaissance evidence. The decisions below supersede only its unresolved/provisional points.

REPOSITORY AND BASELINE

Repository:
/Users/ds/Repositories/Governed Execution Coordinator/

The preceding tranche is merged and closed.

Require before any mutation:
- local trunk_dev commit: 4519630d0db967066beb21b4ace5004e76827716
- remote origin/trunk_dev: the same commit
- integrated tree: 15461a58da8df9ebd63fce734d39a07a50ab87ac
- 299 tracked source files
- clean worktree and index
- no active Git operation or other writer

The reconnaissance observed the old merged topic checked out at 6d867cb09af047dff0d66b4917fa29317c00de31 with the same tree. Do not implement on that already merged topic lineage.

If and only if the baseline above matches exactly, create and switch to this new local branch from local trunk_dev:

codex/rw0-c2-p0-p1-physical-program-v1

The branch must have no upstream. If it already exists, the base differs, or the checkout is not clean, stop before editing.

CURRENT CONTRACT AND EFFECT CEILING

Current implemented reality ends at:
- native Section 41 post-execution proposal recording;
- separate C1 rank-15 admission;
- checked readback;
- pure V22 projection.

This program may add only artificial-offline P0 and P1 physical persistence over task-owned disposable SQLite state. It must not add or claim:
- terminal-outcome persistence;
- live supplier/enrollment conformance;
- production provider or worker execution;
- ES or Bridge routing;
- product Git effects;
- service, queue consumer, scheduler, autonomous loop, deployment, or release;
- power-loss-safe durability or closure of F2;
- closure of qualified F3/F6/F7, cross-host clock ordering, or F03.

Migrations 0001 through 0005 and their meanings are immutable. Application generation remains 2 unless an actual compatibility contradiction is demonstrated and reported before changing it. Ordinary writer acquisition and product mutation must never auto-migrate.

PROGRAM SELECTION

The selected shape is SELECT_SINGLE_P0_TO_P1_PROGRAM.

Reject a standalone P0 integration. Save and reopen P0 as an internal source-bound checkpoint, freeze its exact source/path/schema identity, then continue to P1 in the same candidate. After the P0 checkpoint, P1 may not silently rewrite P0. If P1 reveals a true P0 contract defect, stop and report the conflict rather than changing the frozen checkpoint in place.

No intervening standalone semantic-contract tranche is permitted. Governing documents, schema, source, and tests move together during this implementation.

FROZEN AUTHORITY DECISIONS

A. P0 authority and uniqueness

1. External standing policy and enrollment remain the authors of the admission act, recording permission, and custody posture. The Coordinator provisioner records an already verified immutable act/fact; it does not issue or renew authority.
2. The P0 provisioner owns its immutable family, receipt-first replay, checked readback, and three-way recovery. It creates no program, decision, acceptance, or terminal row.
3. Physical uniqueness must enforce the semantic rule that changing a fact ref cannot create a second allowance for the same act, lineage, or scope:
   - one fact per act_ref;
   - one fact per lineage_ref;
   - one fact per scope_ref.
   Do not weaken these to a composite-only route.
4. enrollment_ref, incarnation_ref, authority_process_ref, and storage_custody_ref are historical source-bound evidence coordinates. Their exact equality is verified against the qualified source and retained in the basis, but they receive no independent SQL UNIQUE constraint. Their uniqueness/currentness belongs to the external enrollment/custody owner, not SQLite inference.
5. Select migration 0006 for P0 only.

B. Replan cognitive source and durable author

1. The D2 review model recommendation remains non-authoritative evidence. It does not author accepted intent or WorkSpec state.
2. The cognitive reasoning layer is the source of a private typed replan proposal. In this artificial proof, use a deterministic fixture-authored/fake cognitive proposal; do not add a live provider or production model route.
3. Introduce one closed private replan-proposal value. Its complete private WorkSpecV1 is transient and never persisted wholesale. Its safe projection and digests are command/basis evidence only.
4. The P1 Coordinator decision owner is the sole durable author. It independently recomputes the authoritative branch and may adopt the replan proposal only when the derived branch is attempt_selecting_replan and every currentness, matrix, admission, guard, collision, and relation check passes.
5. A replan proposal cannot force or veto the branch. The caller's expected branch remains a conflict assertion only.
6. Require the replan proposal to be absent for non-replan branches. Require it for attempt_selecting_replan. A missing, extra, malformed, foreign, or inconsistent proposal is no-write required_fact_invalid; do not convert it to block.
7. Reusing the old accepted-intent or work-revision refs is forbidden and does not constitute replan.

C. Exact attempt_selecting_replan row family

For attempt_selecting_replan, in the same P1 COMMIT:
- create a new accepted-intent revision at current revision number + 1, with prior_accepted_intent_revision_ref equal to the current accepted-intent revision;
- bind its source_intent_ref/source_intent_digest to the transient cognitive replan proposal;
- create a new revision of the selected existing work_item_ref at current work-item revision number + 1, with prior_work_item_revision_ref equal to the selected current revision and accepted_intent_revision_ref equal to the new accepted-intent revision;
- create the new WorkSpec safe binding for the new program version, accepted-intent revision, selected work item, and new work-item revision; persist no private objective, requirements, exclusions, prompt, or raw model response;
- create one accepted_intent_supersedes revision edge and one work_item_supersedes revision edge;
- copy the complete current program-version membership closure in ordinal order, replacing only the selected work item's revision with the new revision; preserve every other member exactly and preserve dense unique ordinals;
- update the selected work-item head to the new revision and increment its head revision exactly once;
- create the resulting replan program version and update the program head once;
- record selected current attempt/candidate/fence coordinates and Coordinator-derived prospective successor semantic-attempt/candidate refs in the existing 0002 decision row;
- do not create the prospective semantic-attempt or candidate row in this transaction.

For candidate_repair, derive prospective successor attempt/candidate refs but create no intent/work revision. For acceptance, terminal reject, and block, create no prospective attempt/candidate rows and no intent/work revisions.

D. Program-version membership for every P1 branch

Every version-advancing branch writes a complete new program-version membership closure:
- acceptance, repair, terminal reject, and block copy the current closure exactly;
- attempt_selecting_replan applies the one selected work-revision substitution above.

The new program-version row points to:
- the current accepted-intent revision for all non-replan branches;
- the new accepted-intent revision for attempt_selecting_replan.

Program-head state mapping is exact:
- candidate_acceptance -> accepted
- candidate_repair -> active
- attempt_selecting_replan -> active
- program_terminal_reject -> terminal_rejected
- post_execution_program_block -> blocked

E. Closed decision-basis grammar

Do not use an opaque or extensible decision_basis_bytes bag.

Define one exact private RW0-C2 decision-basis value with a closed top-level field map and canonical duplicate-key-free UTF-8 JSON. The exact top-level roles are:

1. schema_id
2. basis_ref
3. verified_admission_act
4. scope_admission_fact
5. decision_current_snapshot
6. proposal_family_projection
7. proposal_evidence_currentness
8. standing_policy_branch_matrix
9. risk_lane_branch_matrix
10. decision_time_authority_branch_matrix
11. decision_time_global_stop_branch_matrix
12. decision_time_source_effect_ceiling_branch_matrix
13. historical_continuity_basis_ref
14. historical_continuity_basis_digest
15. historical_sole_active_basis_ref
16. historical_sole_active_basis_digest
17. bootstrap_guard_evidence
18. recommendation_consistency_evaluation
19. replan_proposal_safe_projection
20. captured_at
21. basis_digest

Rules:
- every nested value is the exact existing typed safe value or a new closed typed value owned by this implementation;
- replan_proposal_safe_projection is exact null on four non-replan branches and an exact closed safe projection on attempt_selecting_replan;
- the complete membership entries are not duplicated in this BLOB. decision_current_snapshot binds the immutable membership_closure_ref/digest and selected membership coordinates; the writer and readback independently read the immutable closure rows and verify that digest;
- bootstrap_guard_evidence has a closed universal portion for every branch and a closed acceptance-only exhaustive-unclaimed portion that is exact null on nonaccept branches;
- basis_digest excludes itself and uses a new domain-separated digest;
- impose a finite byte ceiling and exact recursive type/depth/cardinality bounds; choose the smallest defensible ceiling after measuring the fixed artificial fixtures, with explicit headroom and tests;
- unknown fields, duplicate keys, bool-as-int, coercion, noncanonical encodings, detached donors, and inconsistent repeated coordinates fail before write.

Persist the exact canonical basis bytes and digest in a dedicated immutable P1 decision-basis table. Retain scalar lookup/binding columns needed for exact FKs, route probes, and bounded readback; do not make downstream code parse an unbounded extension bag.

F. P1 physical family and migration allocation

Select migration 0007 for P1. Migration 0006 is P0-only.

Reuse the existing migration-0002 decision, program-version, program-head, accepted-intent, work-revision, work-head, program-version-membership, revision-edge, WorkSpec-binding, generic result projection, and mutation-receipt meanings unchanged.

Add exactly the six supplemental immutable logical row families identified by reconnaissance, with exact closed row values and UPDATE/DELETE rejection:
- historical continuity basis;
- historical sole-active basis;
- decision basis;
- guarded family relation;
- guarded progression result;
- bootstrap acceptance fact.

The generic 0002 mutation receipt remains the one receipt. Do not create a second receipt or recovery owner.

The acceptance fact exists exactly on candidate_acceptance and is absent on the other four branches, while its prospective reserved identity is collision-probed on every branch. Enforce one acceptance per admitted scope/fact with immutable unique routes and no reset, renewal, deletion, recreation, or replenishment path.

G. Transaction, replay, and recovery

P0 and P1 use separate guarded writer transactions and separate recovery classifiers.

P1 must:
- fence before protected disclosure;
- check receipt first for replay;
- validate the complete historical family before command association;
- on a fresh command, read and verify checked P0 admission plus fresh continuity, sole-active, currentness, matrices, stop, and guard posture;
- derive the branch itself;
- probe all generic and supplemental routes before write;
- write one complete 0002 + supplemental family, generic receipt last, and attempt exactly one COMMIT;
- return success only after required cleanup;
- classify readback as committed_exact, definitely_not_committed, or unresolved from the whole family;
- never retry automatically, repair fragments, fabricate a block/rejection, or provision P0.

P0 committed with P1 absent is a truthful complete state and grants no decision or acceptance.

IMPLEMENTATION STRATEGY

Phase A — P0 checkpoint

1. Update the governing P0/SQLite/authority/status documents and exact contract tests together with implementation. Do not create a standalone docs-only freeze.
2. Add migration 0006 with the four P0 tables proposed in reconnaissance and the exact uniqueness treatment above.
3. Add private P0 value/row/writer/readback/recovery owners and integrate them only through the existing guarded session/controller. No public StateStore/package export.
4. Implement additive explicit migration behavior and all directly dependent catalog/schema/count/history/current-tip consumers while preserving historical assertions.
5. Run the P0 causal and migration checkpoint on an authenticated external copy.
6. Save and reopen a complete source-bound P0 checkpoint. Freeze:
   - exact P0 changed/created path set;
   - all P0 source bytes/modes;
   - migration 0006 bytes/checksum/catalog manifest;
   - P0 focused node inventory and results;
   - P0 source tree identity.
7. Reauthenticate the P0 checkpoint before beginning Phase B. No commit, stage, push, or user handoff.

Phase B — P1 continuation

1. Update the P1/private-value/guard/C2B/SQLite/current-status documents and exact contract tests with the authority and basis decisions above.
2. Add migration 0007 and the six supplemental families.
3. Add private P1 command, decision-basis, replan-proposal safe value, supplemental row values, writer/readback/recovery, and one bounded artificial offline caller.
4. Use existing 0002 rows/readers and current pure C2 input/reducer values without silently changing their v1 meanings.
5. If any required generic 0002 row/value/reader cannot represent the frozen branch family without changing its current meaning, stop with the exact contradiction. Do not patch around it or change 0002.
6. Preserve the P0 checkpoint bytes. If P1 needs a P0 change, stop and report instead of rewriting Phase A.

FIRST SUBSTANTIVE CHECKPOINTS

P0 checkpoint must use task-owned disposable state and independently fixed artificial act/enrollment/custody subjects. It must prove:
- P0 before program creation;
- exact fresh commit and exact replay;
- same operation/different command;
- same act/new operation;
- alternate fact ref for same act;
- duplicate lineage and duplicate scope;
- partial/orphan/malformed/unreadable family;
- precommit rollback;
- before/after underlying COMMIT uncertainty;
- cleanup uncertainty;
- committed_exact / definitely_not_committed / unresolved;
- zero program, P1 decision, acceptance, and terminal rows.

P1 connected checkpoint must use the actual integrated artificial path in disposable state:
- P0 records before program creation through a test-only bounded interposition on the existing initializer;
- unchanged D1 -> D2 -> Section 41 A -> C1 B -> V22;
- P1 consumes checked P0 + V22/current evidence;
- all five branches are exercised in independent controlled fixtures;
- attempt_selecting_replan uses the typed fake cognitive replan proposal and creates the exact new intent/work family above;
- acceptance creates exactly one immutable acceptance fact;
- the four nonaccept branches create none;
- P0 committed/P1 absent remains readable and nonaccepting;
- branch-specific currentness, matrix, guard, expected-branch, collision, replay, commit uncertainty, readback, and no-write/durable-block distinctions are causally exercised;
- terminal-outcome rows remain zero.

Do not claim that one D2 model recommendation fixture proves all five branches. Use controlled independent evidence inputs while preserving the same production reducer and writer path.

TOUCHED SURFACES

Use the reconnaissance report's complete mapped inventory as the starting map. The following classes are authorized:
- governing documents named in its section 9;
- new physical implementation document `.docs/rw0-c2-physical-p0-p1-implementation.md`;
- migrations 0006 and 0007;
- sqlite_migration.py, sqlite_writer_session.py, sqlite_transition_transaction.py only where required by the new owned operations;
- new private P0/P1 contract, row-value, SQLite owner, and bounded offline connected-caller modules;
- new P0/P1 migration, physical, recovery, and connected tests;
- directly dependent existing exact catalog, importer, source-nonimplementation, caller-inventory, P11/C2B, architecture, operating-model, coherent-fixture, migration-tip/count/history, and raw identity consumers identified by the reconnaissance.

Before editing each additional existing path not explicitly named in section 9 of the report, record the direct dependency and protected invariant. Do not relax broad allowlists, remove historical assertions, or refresh hashes until tests pass. Preserve predecessor reconstruction where current-file identities legitimately advance.

Protected untouched unless a concrete representation contradiction forces a stop:
- migrations 0001 through 0005;
- current D1/D2 and post-D2 continuation source;
- Section 41 writer/projection/resolution source;
- V27 current decision-input source semantics;
- generic 0002 row-value/readers and frozen query inventory;
- SQLite security/connection/read-scope behavior unrelated to the two new operations;
- package exports and public StateStore;
- terminal owner and first-live pure oracle.

VALIDATION

During development, run targeted tests as needed in isolated external copies.

P0 checkpoint gate:
- exact migration 0006 tests;
- exact P0 contract/value/writer/readback/recovery tests;
- directly affected migration/catalog/writer/controller/security guards;
- source-bound checkpoint with exact node inventory.

Final candidate gate on identical final bytes:
1. exact migration 0006 and 0007 tests;
2. complete P0 and P1 physical/recovery suites;
3. connected P0->D1/D2->Section41/C1/V22->P1 tests for all five branches;
4. focused P0/P1/guard/private-value/first-live/0002/B1/C2B/post-D2/Section41/nonauthority/architecture/assurance consumers;
5. one selector-free collection:
   python3 -B -m pytest -q -p no:cacheprovider --collect-only
6. one selector-free FULL execution:
   python3 -B -m pytest -q -p no:cacheprovider --junitxml=<owned-path>

Use an authenticated external source copy, task-owned HOME/TMPDIR/basetemp/JUnit, disabled bytecode, plugin autoload, and pytest cache. Do not predict a historical test count or warning count. Reconcile collected, reported, called, and JUnit IDs exactly. Record every failure, skip, warning, interruption, and source before/after identity. Credit a fault only when its intended seam is reached.

PROVENANCE AND ARTIFACTS

At opening and closeout record:
- repository, branch, HEAD, parent/tree, upstream, clean/dirty state;
- complete changed/created/deleted path set;
- path classification, type, OS/Git mode, byte count, SHA-256, and Git blob OID;
- deterministic full-index binary diff;
- exact P0 checkpoint manifest and reopen receipt;
- exact final canonical manifest generated twice from fresh reads;
- migrations 0001-0005 byte equality;
- validation commands, environment, IDs, JUnit, logs, warnings, and source bindings;
- protected index/config/ref observations under the current authoritative-versus-qualified-diagnostic policy;
- bounded cleanup of task-created artifacts only.

Write implementation evidence outside the repository. Produce one reopened review ZIP containing:
- complete final source;
- complete P0 checkpoint source and manifest;
- baseline bytes for every modified tracked path;
- migrations and schema inventories;
- exact diff/manifests;
- validation and causal-control records;
- implementation report;
- cleanup and preservation records.

No report or artifact becomes Coordinator authority.

STOP CONDITIONS

Stop without staging or partial acceptance if:
- the baseline or new branch cannot be established exactly;
- a required authority source remains ambiguous after applying the decisions above;
- P0 cannot be frozen without changing migrations 0001-0005;
- P1 requires rewriting frozen P0 checkpoint bytes;
- the existing 0002 representation cannot express the branch family without changing v1 meaning;
- replan would reuse old intent/work revisions, let model evidence author durable truth, omit revision/membership/WorkSpec rows, or move them to an unstated later transaction;
- the decision basis would remain opaque/extensible or omit a reducer/guard input;
- acceptance could be created outside the P1 COMMIT or on a nonaccept branch;
- required validation is unavailable, incomplete, interrupted, or mutates final bytes;
- a secret/sensitive artifact would need to be exposed;
- another repository writer or baseline drift appears.

A material P1 stop after a successful P0 checkpoint must return the P0 checkpoint and the exact unresolved P1 contradiction. It must not stage, commit, publish, or present P0 as an integrated tranche.

EFFECT AUTHORIZATION

Authorized:
- create/switch to the one new local topic branch from the exact integrated trunk;
- edit repository docs/source/tests/schema within the bounded scope;
- run offline tests in isolated copies;
- create task-owned external evidence packages.

Not authorized:
- staging or commit;
- push, upstream creation, PR, merge, auto-merge;
- network/provider/ES/Bridge/live service calls;
- user or production database migration;
- live enrollment/custody work;
- terminal persistence, product effects, deployment, or release;
- independent audit in this conversation.

EXPECTED INLINE RETURN

Return one complete implementation report inline and one actual downloadable/reopen-verified review ZIP path.

Primary successful disposition:
RW0_C2_P0_P1_PHYSICAL_PROGRAM_IMPLEMENTED_VALIDATED_PENDING_INDEPENDENT_AUDIT

Otherwise return one explicit BLOCKED or PARTIAL disposition naming:
- the last authenticated source identity;
- whether P0 checkpoint completed;
- exact completed/unperformed coverage;
- repository and artifact preservation state;
- whether any source edits remain.

The report must include:
- baseline and final branch/HEAD/tree/upstream;
- P0 and P1 architecture actually implemented;
- every touched path and classification;
- migration 0006/0007 schema manifests and preserved 0001-0005 identities;
- P0 checkpoint identity and reopen result;
- exact causal controls and validation commands/results;
- failed/interrupted/skipped work;
- assumptions and residual seams;
- authority/security/privacy widening, if any;
- cleanup and provenance identities;
- explicit nonclaims.

End with:
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
MERGE_NOT_PERFORMED
PUBLICATION_NOT_PERFORMED
DEPLOYMENT_NOT_PERFORMED
PRODUCT_EFFECT_NOT_PERFORMED

PROJECT SNAPSHOT

Do not request or create a new Project-source snapshot during this implementation. The next snapshot is requested only after this architecture-defining P0/P1 program is independently accepted and integrated.
