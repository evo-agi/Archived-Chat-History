# RW0-C2 P1 continuation — versioned replan work-head witness

## Recipient and current state

Continue in the same workspace-write Codex implementation conversation that
returned:

`RW0_C2_P0_P1_PHYSICAL_PROGRAM_PARTIAL_BLOCKED_REPLAN_WORK_HEAD_READBACK_CONTRACT`

Repository:

`/Users/ds/Repositories/Governed Execution Coordinator/`

This is the same single P0→P1 implementation program. Do not start another
reconnaissance, standalone semantic-contract tranche, independent audit, or new
branch.

The preceding integrated tranche is merged and closed. Current implementation
work is uncommitted on:

`codex/rw0-c2-p0-p1-physical-program-v1`

Expected repository baseline and current partial source:

- HEAD, local `trunk_dev`, and `origin/trunk_dev`:
  `4519630d0db967066beb21b4ace5004e76827716`
- HEAD tree: `15461a58da8df9ebd63fce734d39a07a50ab87ac`
- upstream: absent
- staged diff: empty
- current partial source: 312 paths
- current partial source tree:
  `2d1d7c4ae95202193692a974cdee33f7a954b6cc`
- current canonical manifest SHA-256:
  `912c0a1adf12a2efa3063c4b87f4fc902d722126345a7157d32993c882f71290`
- retained review ZIP:
  `/tmp/rw0-c2-physical-40tugs82/continuation2/rw0-c2-p0-p1-work-head-boundary-review.zip`
- retained review ZIP SHA-256:
  `4f035c3127a0b468554a79ced6b2e001684e23927120ed2e7aae382f6ed00e95`
- P0 checkpoint tree:
  `fd45f05ff909493ff8984671a02be66d3b48a791`
- P0 checkpoint canonical manifest SHA-256:
  `2fa63a923b3d296b59febd694020447a0dd1961bcb5fe1988593b1e340b32cfa`
- migration 0006 SHA-256:
  `58b2731d52e8e199c010b309a29aa831ffb16d4db4e755d20adb694ce0a7305f`
- current provisional migration 0007 SHA-256:
  `f50960f6689c4ed098357a109dd9d03117060f20ee0b11e82af2012fe302afac`

Before editing, authenticate the live checkout against those exact identities.
Also authenticate the retained review package if it remains available. Stop on a
source, branch, HEAD, staged-state, P0-production, or migration-0006 mismatch.
Do not reset, clean, restore, or normalize the checkout to make it match.

The P0 checkpoint remains a saved and reopened internal checkpoint, not a
standalone integrated tranche. The current 89-pass focused result and 67-pass
identity checkpoint are development evidence for the stopped partial source only.
They are not P1 implementation or final-validation credit.

## Objective

Resolve the historical replan work-item-head boundary with a versioned P1
relation/result/profile successor, then complete the same P1 implementation:

- private fenced SQLite writer;
- all five physical branches;
- exact replay and checked readback;
- three-way recovery;
- connected P0 → D1/D2 → Section 41/C1/V22 → P1 proof;
- focused and selector-free FULL validation;
- one complete uncommitted review package for fresh independent audit.

Do not weaken exact whole-family replay/recovery, omit replan, defer its work-head
update to another transaction, or add a new user-mediated checkpoint.

## Sole writer and effect ceiling

You are the sole repository writer. Spawn no subagents while workspace-write is
enabled.

Authorized:

- edit the current Coordinator checkout within the bounded cumulative P0/P1
  implementation scope;
- update governing docs and directly affected contract/assurance tests with the
  source/schema implementation;
- run tests only in authenticated external copies and task-owned disposable
  SQLite state;
- create evidence and review packages outside the repository;
- remove only task-owned temporary state after evidence is safely retained.

Not authorized:

- staging, commit, push, PR, merge, publication, deployment, or release;
- network/provider/Codex/ES/Bridge/CP/IM/MA calls;
- live enrollment, live custody, real worker/provider execution, product Git
  effects, terminal persistence, service, queue, scheduler, or autonomous loop;
- changes in another repository;
- dependency installation;
- automatic migration of user/product databases;
- modification of migrations 0001–0006;
- changes to P0's two private production owners or its migration 0006;
- changes to existing migration-0002 row meanings, WorkSpecV1, generic mutation
  receipt semantics, or the six branch-neutral preassignments.

## Engineering decision: versioned work-head witness

The prior stop found a real contract gap. A replan transaction mutates
`development_work_item_heads`, but the accepted guarded relation retains only the
program-head postimage. After a later replan, immutable rows can reconstruct an
expected old work head but cannot independently verify the earlier CAS. Do not
solve this by reconstruction-only replay or receipt-only credit.

Implement the following current successor inside this same source/schema tranche.
The v1 accepted-target definitions remain historical predecessors.

### 1. Current version IDs

Use these exact current IDs:

- guarded family relation:
  `governed-execution.nwp-rw0-c2-guarded-family-relation.v2`
- guarded progression result:
  `governed-execution.nwp-rw0-c2-guarded-progression-result.v2`
- receipt graph profile:
  `governed-execution.nwp-rw0-c2-receipt-graph-profile.v2`

Do not silently rewrite v1 as though it always had this meaning. Add a bounded
versioned successor in the owning documentation and tests while preserving the
v1 predecessor as historical contract evidence. This is part of implementation;
there is no intervening contract-only tranche.

### 2. Guarded relation v2

Preserve the exact v1 ordered fields and add these four ordered fields immediately
after `historical_head_postimage` and before the acceptance-fact fields:

1. `historical_work_head_ref`
2. `historical_work_head_revision`
3. `historical_work_head_digest`
4. `historical_work_head_postimage`

The v2 logical relation has exactly 30 fields in the digest preimage plus final
`relation_digest`.

For `attempt_selecting_replan`:

- all four fields are non-null;
- the postimage is the canonical duplicate-free JSON bytes of one exact existing
  `DevelopmentWorkItemHeadRowValue` mapping, including its stored `head_digest`;
- `historical_work_head_ref` equals `work_item_ref`;
- `historical_work_head_revision` equals the postimage `head_revision`;
- `historical_work_head_digest` equals the postimage `head_digest`;
- postimage `program_ref` equals the physical relation `program_ref`;
- postimage `work_item_ref` equals the decision-basis selected work item;
- postimage `current_work_item_revision_ref` equals the replan decision's new work
  revision and the resulting version membership for that work item;
- postimage revision number and head revision are the exact predecessor values
  plus one;
- postimage `work_state` is `active`;
- postimage `updated_at` is the one transaction decision timestamp;
- the new work revision, revision edge, membership, WorkSpec binding, decision,
  version, and program-head postimage all agree with it.

For every other branch, all four work-head fields are null. Mixed null/non-null
states, a witness on a non-replan branch, or a replan without the witness are
invalid before mutation and invalid on readback.

In migration 0007, retain the same six P1 supplemental tables. Add the four
nullable columns and exact branch-pair constraint to
`rw0_c2_guarded_family_relations`. A nullable composite FK from physical
`program_ref` plus `historical_work_head_ref` to the existing work-item-head
identity route is allowed and selected; do not FK the historical digest/postimage
to the mutable current row. Store the postimage in a bounded BLOB using the same
exact typed/canonical reconstruction discipline as the existing program-head
postimage.

No seventh table is authorized. The cumulative schema remains 74 tables,
134 triggers, and five explicit indexes. Update and freeze the exact column,
constraint, FK, checksum, and schema-manifest expectations.

### 3. Receipt graph profile v2

Keep the ten v1 common roles unchanged:

- `verified_admission_act`
- `scope_admission_fact`
- `historical_continuity_basis`
- `historical_sole_active_basis`
- `decision`
- `program_version`
- `historical_head_postimage`
- `generic_v1_result_projection`
- `guarded_family_relation`
- `guarded_result_composite`

Keep the acceptance-only role `acceptance_fact` and add the exact replan-only
role:

`historical_work_head_postimage`

Its entry is ordinal 0 and binds the fully reconstructed relation postimage's
`work_item_ref` and `head_digest`.

Exact branch role sets:

- `candidate_acceptance`: ten common roles plus `acceptance_fact`;
- `attempt_selecting_replan`: ten common roles plus
  `historical_work_head_postimage`;
- `candidate_repair`, `program_terminal_reject`, and
  `post_execution_program_block`: exactly the ten common roles.

The work-head witness is deliberately bound twice: by the guarded relation digest
and by the branch-specific graph role. Missing, extra, duplicate, wrong-branch, or
wrong-digest roles reject the family.

Guarded result v2 retains its current fields and requires profile v2. Update
collision/recovery schema expectations to relation/result v2. The existing generic
migration-0002 receipt remains the sole receipt and is not versioned or widened.

### 4. Preserve the noncircular identity vector

This correction is post-command. Preserve byte-for-byte the reopened corrected
identity vector through:

- version-neutral replan template and safe projection;
- cognitive proposal projection;
- 21-field decision basis;
- all six branch-neutral sibling preassignments;
- command digest;
- three Coordinator-derived replan refs;
- final unchanged WorkSpecV1 and safe projection.

The previously reported command digest must remain:

`88d6ee1672e0d4a0923886fbe7378a9e69607d5255a10e7ccfe983ecb76c3705`

The preassigned version ref and three derived refs must remain:

- `53f8f17eac34a03f6cec1138f51ac5de236b5cce12ee4b146e91589e73ad6ec4`
- `49cf0c5af5b05df13a37fc81a0af94575c58f5d23606318e54579f2dbbf4d60c`
- `ff8bbdee0ae64e981bf5240bee8053a69db0fb5d914b83779d56b2342d2357bf`
- `793eee9325f7d625be300078d2cf835cd6d40da8a3a3d8e25df307bc4c3671f8`

The final WorkSpec digest must remain:

`34bce79ca2a8c483f51c5c705699319ac90f4be9c0e9c5d4d0f68871209d2b45`

Only downstream relation, guarded-result, receipt-graph, and receipt digests may
change. Stop if the versioned witness requires a placeholder, fixed point, new
preassignment, command/basis change, or WorkSpec/0002 semantic change.

## Writer, replay, and recovery requirements

### Fresh transaction

Use the existing guarded writer session and transaction controller. For a fresh
replan, the one transaction must:

1. validate current P0 admission, current guard posture, decision basis, reducer,
   and all current 0002 preimages after fencing;
2. insert the exact immutable replan revision/edge/version/membership/WorkSpec and
   P1 supplemental rows;
3. CAS the program head;
4. CAS the work-item head;
5. SELECT and type-check the actual program head and actual work-item head in that
   same transaction, requiring exact equality with both planned postimages;
6. validate the exact v2 branch graph and all family rows;
7. insert the generic receipt last;
8. invalidate capability and make exactly one COMMIT attempt.

A failed, suppressed, zero-row, or conflicting work-head CAS; a wrong post-CAS
readback; or any mismatch before receipt insertion rolls back the complete family.
No receipt, partial immutable family, or claimed result may survive.

Non-replan branches perform no work-head CAS, carry no work-head witness, and have
no replan-only graph role.

### Replay and checked readback

Receipt-first exact replay must reconstruct and verify:

- generic decision and program version;
- complete resulting version membership;
- program-head historical postimage;
- for replan only, work-head historical postimage;
- new accepted-intent/work revision rows, both revision edges, and WorkSpec
  binding;
- all six P1 supplemental rows applicable to the branch;
- exact profile-v2 graph entries;
- generic receipt and result digests.

Replay must not compare current mutable heads with historical postimages and must
not rerun the reducer, model, D1/D2, or external guard source. A later valid replan
may advance both mutable heads without invalidating the earlier family.

### Recovery

The command-covered read-only recovery remains exactly three-way:

- `committed_exact` only from the full exact immutable family, both required
  historical postimages, branch-exact graph, and matching receipt;
- `definitely_not_committed` only from exhaustive absence at every original
  newly created route under the existing positive continuity/sole-active
  prerequisites;
- `unresolved` for any partial, malformed, foreign, unreadable, contradictory,
  or wrong-profile family.

Do not grant committed credit from receipt presence alone or from a reconstructed
expected work head without the retained witness. Do not repair fragments or retry
a command automatically.

## Internal checkpoint before writer completion

Before integrating or restoring a SQLite P1 writer, save and reopen a new
source-bound pure checkpoint that proves on the exact current source:

1. the earlier noncircular vector is byte-identical through final WorkSpec;
2. relation v2 has the exact ordered field set and branch-null algebra;
3. profile v2 has the exact role sets above;
4. replan plans contain the exact work-head postimage and graph role;
5. acceptance retains its acceptance fact and no work-head role;
6. the other three branches have neither branch-specific role;
7. relation/result/graph/receipt downstream digests are deterministic;
8. migration 0007 still has six supplemental tables and preserves every 0006
   schema object byte-for-byte/structurally unchanged.

Reopen and verify this checkpoint before proceeding to writer work. Return it in
the final review package.

## Required physical causal controls

Implement and retain exact causal evidence for at least the following:

1. **Replan fresh positive.** Actual guarded transaction writes the new intent,
   work revision, two edges, version membership closure, WorkSpec binding, decision,
   program version, both head CAS operations, P1 supplements, v2 graph, result,
   and receipt; same-transaction post-CAS reads match exactly.
2. **Second-replan historical replay.** A later valid replan advances the same
   work-item head again. Exact replay and `committed_exact` recovery of the first
   replan still reconstruct the first program/work-head postimages and all
   immutable rows without current-head equality or rerunning cognition.
3. **Work-head CAS omitted/no-op.** A test-only bounded fault suppresses or makes
   the work-head CAS affect zero rows. The transaction fails, receipt is absent,
   and all target rows/head changes roll back.
4. **Post-CAS work-head readback mismatch.** Fault the exact readback seam after
   the real CAS. No receipt or committed family survives.
5. **Witness mutants.** Missing/null replan witness, mixed null fields, foreign
   work item, wrong head revision, wrong current revision, wrong digest, malformed
   canonical bytes, detached WorkSpec/membership/revision relation, and a witness
   on a non-replan branch all reject.
6. **Graph mutants.** Missing, duplicate, extra, wrong-branch, wrong-ref, and
   wrong-digest replan work-head roles reject. Acceptance must still require only
   its acceptance role; the other branches remain ten-role families.
7. **Program-head preservation.** Existing program-head postimage verification,
   CAS, replay, and recovery remain exact for every branch.
8. **Five physical branches.** Complete fresh/replay/readback/recovery behavior for
   acceptance, repair, replan, terminal reject, and program block, with acceptance
   fact only on acceptance.
9. **P0 boundary.** A committed P0 family with P1 absent remains complete and
   truthful. P0's migration and two private production owners remain byte-exact.
10. **Commit uncertainty and collisions.** Before/after underlying COMMIT,
    cleanup uncertainty, mutation reuse, every preassigned identity/family route,
    partial families, and different complete winners retain the selected
    three-way semantics.
11. **Connected proof.** Actual artificial P0 → D1/D2 → Section 41 A → C1 B →
    V22 → P1 path reaches all five branches under controlled inputs. No product,
    live supplier, terminal persistence, or external effect is claimed.

Every fault test must prove its injection point was reached. Do not credit a case
that fails at an earlier predicate for a later control.

## Scope and directly affected surfaces

Continue from the exact partial source. Selectively reuse the retained unintegrated
SQLite draft only after inspecting it; do not restore it wholesale or treat it as
accepted.

Expected directly affected production/contract surfaces include, but are not
limited to:

- `.docs/rw0-c2-private-value-versioning.md`
- `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
- `.docs/rw0-c2-physical-p0-p1-implementation.md`
- `.docs/c2b-durable-development-state.md`
- `AGENTS.md` and other current status/authority owners only where this cumulative
  implementation requires a successor
- `src/ge_nwp_coordinator/_rw0_c2_progression_contracts.py`
- `src/ge_nwp_coordinator/_rw0_c2_progression_rows.py`
- `src/ge_nwp_coordinator/_rw0_c2_progression_plan.py`
- new/current private SQLite P1 writer/readback/recovery owner
- `src/ge_nwp_coordinator/sqlite_migrations/0007_rw0_c2_progression_decision.sql`
- `src/ge_nwp_coordinator/sqlite_migration.py`
- `src/ge_nwp_coordinator/sqlite_transition_transaction.py`
- `src/ge_nwp_coordinator/sqlite_writer_session.py`
- direct progression, migration, connected, current-catalog, private-value, C2B,
  runtime/non-authority, and exact-identity assurance tests.

The exact touched set must be source-derived. If another direct assertion, caller,
catalog/hash consumer, historical reconstruction guard, or documentation owner must
change, record its dependency and update it narrowly. Do not loosen broad
inventories or refresh a hash until the protected historical/current relationship
is understood.

Protected unchanged production:

- migrations 0001–0006;
- `src/ge_nwp_coordinator/_rw0_c2_scope_admission_contracts.py`;
- `src/ge_nwp_coordinator/_sqlite_rw0_c2_scope_admission.py`;
- existing migration-0002 row meanings and WorkSpecV1;
- D1/D2, post-D2 Section 41/C1/V22 production paths;
- public package exports, public StateStore/WriterSession APIs, and first-live
  supplier oracle;
- terminal-outcome owner and live/product routes.

Shared catalog/controller/session files may advance additively for 0007/P1 while
preserving P0 behavior and the historical 0006 checkpoint.

## Validation

Use task-owned authenticated external source copies. Do not import or run tests
from the live checkout. Disable bytecode, pytest cache, and plugin autoload; use
owned HOME/TMPDIR/basetemps and retain exact argv/environment/runtime facts.

Required sequence:

1. targeted pure v2 contract/plan tests and reopened identity checkpoint;
2. migration 0006 historical-prefix and current 0007 schema/upgrade tests;
3. P0 physical regression suite;
4. P1 writer/readback/replay/recovery and all causal controls above;
5. connected five-branch P0→P1 checkpoint, saved and reopened;
6. one deduplicated focused collection and execution covering every directly
   affected module and assurance consumer;
7. one selector-free collection on final bytes;
8. one selector-free FULL execution on the same final bytes;
9. exact collected/executed/JUnit ID reconciliation, failure/error/skip/warning
   inventory, and before/after source byte/mode equality.

No earlier 67-, 89-, or 417-pass result validates changed bytes. No partial,
interrupted, superseded, or rescued run receives final credit. If required FULL
execution cannot complete, return an incomplete implementation result with exact
unperformed coverage; do not weaken the gate.

## Provenance and package

Before editing, preserve a prospective opening over source, semantic index, raw
index, configuration, branch/HEAD/upstream, authoritative refs, and qualified
diagnostic refs under the already selected provenance treatment. Historical
index/ref gaps remain disclosed; do not reset or backdate them.

At final closeout:

- require no staged entries;
- run `git diff --check`;
- record every modified/created/deleted path, type, OS/Git mode, size, SHA-256,
  and Git blob where applicable;
- retain the complete tracked binary diff;
- produce two byte-identical fresh canonical manifests and one post-cleanup
  capture using an explicitly versioned external recipe if the created-path set
  has changed;
- preserve the exact P0 checkpoint, prior cycle-stop package, prior work-head
  boundary package, new identity checkpoint, schema manifests, causal register,
  validation/JUnit/ID records, and cleanup receipt;
- create one review ZIP containing the complete cumulative source and safe
  evidence;
- reopen and verify every package member and reconstruct the final Git-compatible
  source tree before reporting its outer size/SHA-256.

Do not place generated evidence, databases, journals, WAL/SHM files, caches,
bytecode, or helper programs in the repository.

## Stop conditions

Stop without claiming implementation success if any of the following occurs:

- the opening source or P0 production bytes do not match;
- the noncircular identity vector changes before relation/result/graph construction;
- the fix requires a seventh table, migration-0002 semantic change, WorkSpecV1
  change, new command preassignment, placeholder, or fixed-point hash;
- exact work-head CAS and same-transaction post-CAS readback cannot precede the
  receipt;
- replay or recovery would need current mutable-head equality;
- the branch-specific graph cannot be exact without weakening whole-family proof;
- P0 behavior or migration 0006 must change;
- a direct dependency requires authority widening outside this physical P0/P1
  program;
- selector-free FULL validation fails or remains incomplete on final bytes;
- provenance becomes unstable or source cannot be bound exactly.

A stop must preserve the current source and all completed evidence, state the
exact unresolved authority/contract issue, and identify unperformed coverage. Do
not stage, commit, publish, or silently revert useful partial work.

## Required inline final response

Return one complete implementation report inline, including:

- primary disposition;
- authenticated opening and final source identities;
- exact changed-path inventory and classifications;
- P0 checkpoint preservation;
- v1→v2 relation/result/profile treatment;
- unchanged identity vector through WorkSpec;
- exact migration 0007 schema/checksum/counts and preservation of 0006;
- writer/CAS/readback ordering;
- branch-exact graph roles;
- replay/recovery semantics;
- first identity checkpoint and connected checkpoint identities;
- causal-control register and reached predicates;
- exact validation commands/results and ID/JUnit reconciliation;
- failed/interrupted/superseded validation with no false credit;
- provenance recipe/source/diff/manifest identities;
- cleanup and retained artifacts;
- assumptions, unresolved seams, and explicit nonclaims;
- one actual downloadable review package path, size, and SHA-256.

End with:

`INDEPENDENT_AUDIT_NOT_PERFORMED`
`STAGING_NOT_PERFORMED`
`COMMIT_NOT_PERFORMED`
`PUSH_NOT_PERFORMED`
`PR_NOT_CREATED`
`MERGE_NOT_PERFORMED`
`PUBLICATION_NOT_PERFORMED`
`DEPLOYMENT_NOT_PERFORMED`
`PRODUCT_EFFECT_NOT_PERFORMED`
