OBJECTIVE

Perform the separately governed squash-integration gate for PR #17, preserving
the exact independently accepted RW0-C2 P0→P1 implementation and status tree
and producing a complete source checkpoint.

This is an integration-only continuation in the SAME write-enabled Codex
conversation that created and published PR #17.

It is not an implementation, repair, status-edit, deployment, release, or
product-effect engagement. Do not change any repository source byte, mode,
configuration value, PR content, or topic commit. Do not run tests unless a
source identity unexpectedly changes—in that event, stop rather than repair.

The only authorized effects are:

1. authenticate the exact open PR and applicable rules;
2. issue one head-pinned synchronous squash-merge request;
3. verify the resulting squash commit, PR state, refs, and source tree;
4. perform one scoped fetch/readback;
5. advance local `trunk_dev` by one compare-and-swap update;
6. create a complete source checkpoint and safe integration evidence.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

EXPECTED OPENING STATE

Local checkout:

- branch:
  `codex/rw0-c2-p0-p1-physical-program-v1`
- HEAD:
  `3263bc25e4a9f5558065fc7eb68125029d578bda`
- HEAD subject:
  `docs: record RW0-C2 P0-P1 physical program status`
- HEAD sole parent:
  `8704e6c7988250598809f3a0daf88c3e11493488`
- implementation commit sole parent:
  `4519630d0db967066beb21b4ace5004e76827716`
- HEAD tree:
  `44c7dee402d46b3e16dc389ae0824b4297dfec1f`
- upstream:
  `origin/codex/rw0-c2-p0-p1-physical-program-v1`
- worktree and index:
  clean
- source paths:
  `315`
- local `trunk_dev`:
  `4519630d0db967066beb21b4ace5004e76827716`
- local `origin/trunk_dev`:
  `4519630d0db967066beb21b4ace5004e76827716`
- local and remote topic:
  `3263bc25e4a9f5558065fc7eb68125029d578bda`.

Accepted exact source:

- source tree:
  `44c7dee402d46b3e16dc389ae0824b4297dfec1f`
- source-manifest SHA-256:
  `cef835b8ba4c154e52557e430e723a2b6ef3c1abaa05bdb6094b5b14c273f8b9`
- 315 committed blobs and Git modes equal the accepted manifest;
- classified checkout file
  `tests/test_c2b3_private_atomic_program_initialization.py`
  remains live POSIX mode `0600`, Git mode `100644`.

Published PR:

- repository:
  `evo-agi/Governed-Execution-Coordinator`
- PR:
  `#17`
- URL:
  `https://github.com/evo-agi/Governed-Execution-Coordinator/pull/17`
- title:
  `RW0-C2: physical admission and progression`
- state:
  open
- draft:
  false
- base branch:
  `trunk_dev`
- base SHA:
  `4519630d0db967066beb21b4ace5004e76827716`
- head branch:
  `codex/rw0-c2-p0-p1-physical-program-v1`
- head SHA:
  `3263bc25e4a9f5558065fc7eb68125029d578bda`
- commits, in order:
  1. `8704e6c7988250598809f3a0daf88c3e11493488`
  2. `3263bc25e4a9f5558065fc7eb68125029d578bda`
- reviews:
  zero at publication-gate close
- review threads:
  zero at publication-gate close
- check runs:
  zero at publication-gate close
- commit statuses:
  zero at publication-gate close
- auto-merge:
  off
- observed mergeability:
  clean.

Applicable ruleset at publication-gate close:

- `trunk_dev` requires a PR;
- squash is the only permitted merge method;
- unresolved review threads block;
- zero approving reviews are required;
- no required checks are configured;
- no bypass actor is listed.

Zero checks is not a CI pass.

RETAINED PUBLICATION-GATE INPUTS

Authenticate the retained gate root:

`/tmp/rw0-c2-status-publication-gate-_oe8_tum/`

Require exact identities:

1. `CLOSEOUT_REPORT.md`
   - bytes: `10,780`
   - SHA-256:
     `14a5b66b6f5ca54f99b8d2a80fec38f4670a8f11c9b61c00e08999465079bff4`

2. `RESULT.json`
   - bytes: `11,549`
   - SHA-256:
     `7ddfa6f418932c5b02358fb6bc509afda2a39c8b2d56996b38aca35746833b9c`

3. `rw0-c2-p0-p1-status-successor-publication-gate-evidence.zip`
   - bytes: `1,108,230`
   - SHA-256:
     `e5ddb254b593c00c98f18aa234e30fde6a46d2362c6fadf28b39a6e0a898d4df`

4. `RETAINED_ARTIFACT_MANIFEST.json`
   - bytes: `13,475`
   - SHA-256:
     `7b327662906c72d3910580fb1446bcb8a895db8d62bd5263f6b62a39c909f285`

5. `DELIVERY_RECEIPT.json`
   - bytes: `1,051`
   - SHA-256:
     `4cef0df7088761a9a8c3e4d620cb2c9b35cb88ee3913c5b9856bf9dff50fda4a`

6. `CLEANUP_RECEIPT.json`
   - bytes: `1,486`
   - SHA-256:
     `734caac96eaca123f7cd549190724ad82853296a65f4d60e0223dbba4ef1cd40`.

The retained evidence ZIP must reopen safely and prove the publication gate's
exact source, status commit, focused validation, push, PR creation, and final
readback. Do not substitute a same-named Downloads file.

OPENING EFFECT DISCIPLINE

Before the first ordinary Git command:

1. Copy `.git/index` byte-for-byte to a private task-owned external evidence
   root.
2. Record size, SHA-256, metadata, and filesystem identity.
3. Record the repository root and `.git` resolution.
4. Use:
   - `GIT_OPTIONAL_LOCKS=0`
   - `GIT_NO_REPLACE_OBJECTS=1`
   - deterministic locale.
5. Do not checkout, switch, reset, restore, clean, rebase, stash, amend,
   cherry-pick, or modify configuration.

Authenticate:

- exact branch, HEAD, parent chain, tree, upstream, clean worktree/index;
- all 315 live source bytes, Git blobs/modes, and numeric POSIX modes;
- local `trunk_dev`, local `origin/trunk_dev`, local topic, and remote-tracking
  topic;
- configuration and source-selection posture;
- no replace ref, graft, alternate object database, unexpected worktree, or
  symbolic source indirection.

Use the accepted authoritative-versus-diagnostic ref policy:

- qualified diagnostic refs are only direct refs under:
  - `refs/codex/turn-diffs/captures/`
  - `refs/codex/turn-diffs/checkpoints/`;
- every other ref is authoritative;
- retain complete opening maps;
- surviving diagnostic names may not retarget;
- diagnostic refs may not select source, validation, policy, package, or
  publication inputs.

Any source, branch, topic, base, upstream, configuration, authoritative-ref,
semantic-index, live-mode, or input mismatch blocks the gate. Do not normalize
or repair it.

REMOTE AND PR PREFLIGHT

Use bounded network access only for GitHub/API/remote observations and the one
merge request and one scoped fetch authorized below.

Immediately before the merge request, read back and require:

1. remote `trunk_dev` still equals
   `4519630d0db967066beb21b4ace5004e76827716`;
2. remote topic still equals
   `3263bc25e4a9f5558065fc7eb68125029d578bda`;
3. PR #17 remains open, non-draft, unmerged;
4. PR base/head names and SHAs match exactly;
5. its commit list is exactly the two fixed commits in order;
6. no unexpected file/tree delta exists;
7. no unresolved review thread;
8. no review requesting changes;
9. no failing or pending required check/status;
10. auto-merge remains disabled;
11. the active ruleset still permits squash only and has no newly applicable
    approval/check/bypass requirement.

If new non-required checks appeared:

- require every completed one to pass;
- block on failure or pending execution;
- record that zero checks is not a CI pass when none exist.

If the base, head, commit list, tree, rules, reviews, threads, or required-check
posture differs, stop before merge. Do not update the PR branch or issue another
push.

SQUASH COMMIT MESSAGE

Prepare the exact requested squash message outside the repository.

Subject:

`feat: add RW0-C2 physical admission and progression`

Body must record, without overclaiming:

- source commits:
  - `8704e6c7988250598809f3a0daf88c3e11493488`
  - `3263bc25e4a9f5558065fc7eb68125029d578bda`
- accepted source tree:
  `44c7dee402d46b3e16dc389ae0824b4297dfec1f`
- implementation tree:
  `161ed4b544baf970cc26428b9805a106ea0f3edf`
- implementation exact-byte gate:
  `9,473` passes;
- status validation supplement:
  selector-free `9,502` passes;
- publication gate staged-tree focused validation:
  `5,448` passes;
- three known Python 3.13 fork warnings occurred only in the selector-free FULL
  runs where recorded;
- zero checks on PR #17 is not a CI pass;
- P0 records admission history without current permission;
- P1 records one five-branch private decision and an acceptance fact only on
  acceptance;
- no terminal truth, executable permission, live custody, production
  provider/worker, ES/Bridge route, product Git effect, service, queue,
  scheduler, deployment, release, or autonomous loop;
- F03 and F05 remain nonblocking observations.

Retain the exact prepared message bytes and SHA-256.

MERGE

Issue exactly one synchronous GitHub squash-merge request for PR #17:

- merge method:
  squash
- head pin:
  `3263bc25e4a9f5558065fc7eb68125029d578bda`
- exact prepared subject/body.

Do not enable auto-merge. Do not delete the topic branch. Do not issue a second
merge request if the first returns an uncertain result; read back the PR and
remote refs instead.

The head pin does not atomically pin the base. Therefore, after the request,
require independent readback of the resulting commit's sole parent.

POST-MERGE VERIFICATION

Require:

1. PR #17 is closed and merged.
2. GitHub reports one actual squash commit SHA.
3. The squash commit has:
   - exactly one parent:
     `4519630d0db967066beb21b4ace5004e76827716`;
   - exact tree:
     `44c7dee402d46b3e16dc389ae0824b4297dfec1f`;
   - the exact requested subject;
   - body/source bindings and nonclaims materially preserved.
4. The remote `trunk_dev` points to the squash commit.
5. The remote topic remains at
   `3263bc25e4a9f5558065fc7eb68125029d578bda`.
6. PR head/base records and final merged state are internally consistent.
7. Record GitHub commit signature/verification fields if present; do not treat
   signature status as source or test evidence.
8. Read back reviews, threads, comments, checks, statuses, mergeability/final
   state, and auto-merge.
9. Do not claim CI success when zero checks exist.

If the resulting squash parent or tree differs, report an integration incident
and stop. Do not attempt a revert, repair, or second merge in this gate.

SCOPED FETCH AND LOCAL REF SYNCHRONIZATION

After successful remote verification:

1. Perform exactly one scoped fetch sufficient to obtain:
   - the new remote `trunk_dev`;
   - the squash commit object and its 315 blobs.
2. Do not fetch or update unrelated refs.
3. Verify the fetched commit independently by raw commit/tree/blob inspection.
4. Advance local `trunk_dev` exactly once by compare-and-swap:
   - old:
     `4519630d0db967066beb21b4ace5004e76827716`
   - new:
     the verified squash commit.
5. Require local `origin/trunk_dev` and local `trunk_dev` both equal the squash.
6. Keep HEAD on the topic branch at
   `3263bc25e4a9f5558065fc7eb68125029d578bda`.
7. Preserve the topic upstream and remote topic.
8. Do not checkout or reset the worktree.

Authorized ref movement is limited to:

- remote `trunk_dev` from the fixed base to the squash;
- local `origin/trunk_dev` to the squash through the scoped fetch;
- local `trunk_dev` to the squash through the single compare-and-swap.

The topic refs remain unchanged. All other authoritative refs must remain
unchanged. Diagnostic additions/removals are retained as evidence; no surviving
diagnostic name may retarget.

SOURCE CHECKPOINT

Create one complete source checkpoint outside the repository from the verified
squash Git blobs.

Requirements:

1. Include all 315 accepted source paths and raw blob bytes.
2. Record, for every path:
   - relative path;
   - Git blob OID;
   - Git mode;
   - byte count;
   - SHA-256.
3. Record the classified checkout-mode exception separately:
   `tests/test_c2b3_private_atomic_program_initialization.py`
   was live POSIX `0600`, Git `100644` before integration.
4. Store source ZIP wrapper modes according to Git mode, not as a claim about a
   future checkout's POSIX mode.
5. Include safe compact evidence:
   - PR and merge readbacks;
   - actual squash commit message and raw identity;
   - parent/tree verification;
   - ruleset/check/review summary;
   - ref synchronization record;
   - source manifest;
   - integration result and report;
   - cleanup and effect record.
6. Exclude `.git`, credentials, configuration contents, ignored caches, SQLite
   state/sidecars, bytecode, build artifacts, temporary test state, and
   unclassified logs.
7. Use a self-excluding package manifest.
8. Reopen the checkpoint ZIP and verify every member.
9. Independently reconstruct Git tree
   `44c7dee402d46b3e16dc389ae0824b4297dfec1f`
   from the archived source bytes and modes.
10. Record the final ZIP byte count and SHA-256 in an adjacent delivery receipt.

No tests are required in this integration gate. Carry forward, at their exact
historical scope only:

- implementation local gate:
  9,473 passes;
- accepted status validation supplement:
  9,502 selector-free FULL passes;
- publication gate staged-tree selector:
  5,448 passes.

Do not claim any of them ran during integration.

FINAL PRESERVATION READBACK

After checkpoint reopening and bounded cleanup, require:

- HEAD remains on the topic status commit;
- worktree and index remain clean;
- all 315 live source bytes and POSIX modes remain unchanged;
- classified file remains live `0600`;
- topic upstream/config remains unchanged;
- local/remote `trunk_dev` equal the squash;
- remote topic equals the status commit;
- all other authoritative refs unchanged;
- no surviving diagnostic ref retarget;
- no source, configuration, hook, credential, cache, or product state was
  changed.

RETAINED DELIVERABLES

Retain outside the repository:

- complete opening and closing source/index/mode/ref/config summaries;
- publication-gate input authentication;
- PR/ruleset preflight;
- prepared squash message and identity;
- merge request/response/readbacks;
- actual raw squash commit and verification;
- scoped-fetch record;
- local compare-and-swap record;
- complete 315-path source manifest;
- checkpoint reopen and tree-reconstruction verification;
- cleanup/effect record.

Create:

1. `FINAL_REPORT.md`
2. `RESULT.json`
3. a self-excluding retained-artifact manifest
4. the complete source checkpoint ZIP
5. an adjacent checkpoint delivery receipt.

Reopen and hash-verify every retained deliverable.

STOP CONDITIONS

Stop before the next effect if:

- any local or remote identity differs;
- the PR is changed, draft, closed, merged, or has a different base/head/commit
  list;
- a review, unresolved thread, required check, or ruleset change blocks merge;
- source bytes/modes or the accepted tree differ;
- retained publication-gate artifacts differ;
- the merge request returns a definite rejection;
- the actual squash parent or tree differs;
- a second merge request, force action, source edit, or branch update appears
  necessary;
- the scoped fetch would update unrelated refs;
- local `trunk_dev` cannot be advanced by the single compare-and-swap;
- checkpoint reconstruction fails;
- any security, authority, publication, or product boundary would widen.

Do not repair or revert during this gate.

EFFECT CEILING

Authorized:

- read-only local/remote/PR/ruleset authentication;
- one head-pinned synchronous squash-merge request;
- one scoped fetch/readback;
- one local `trunk_dev` compare-and-swap;
- source-checkpoint and integration evidence creation;
- bounded task-owned cleanup.

Not authorized:

- source/document/test/schema/migration/configuration edit;
- push, force push, second merge request, branch deletion, tag creation;
- checkout, reset, rebase, stash, cherry-pick, amend;
- PR content edit, auto-merge, non-squash merge;
- deployment, release, live provider/worker/ES/Bridge use;
- user/product database access;
- terminal persistence or product effect;
- next-tranche implementation.

REQUIRED FINAL RESPONSE

Return one of:

- `RW0_C2_P0_P1_PR17_SQUASH_MERGED_AND_SOURCE_CHECKPOINTED`
- `RW0_C2_P0_P1_PR17_INTEGRATION_BLOCKED_<PRECISE_REASON>`
- `RW0_C2_P0_P1_PR17_MERGED_WITH_INTEGRATION_INCIDENT_<PRECISE_REASON>`

Include:

- PR final state and URL;
- actual squash SHA, subject, complete message identity, parent, tree, signature
  observation;
- opening/final local and remote branch/ref state;
- exact ruleset/review/thread/check/status posture;
- merge request count and head pin;
- scoped fetch and local compare-and-swap effects;
- all 315 source-blob/mode verification;
- source checkpoint path, bytes, SHA-256;
- checkpoint tree-reconstruction result;
- report/result/manifest/delivery identities;
- assumptions, process errors, skipped/unavailable work;
- explicit:
  `TESTS_NOT_RUN_DURING_INTEGRATION`
  `AUTO_MERGE_NOT_ENABLED`
  `TOPIC_BRANCH_NOT_DELETED`
  `DEPLOYMENT_NOT_PERFORMED`
  `PRODUCT_EFFECT_NOT_PERFORMED`;
- nonclaims for live authority, terminal truth, production execution, release,
  and autonomy.

A successful result completes the P0→P1 architecture-defining program on
`trunk_dev`. The next recipient is ChatGPT for integration review and a request
for a new Coordinator Project-source snapshot. Do not begin another tranche.
