## Disposition

```text
RW0_C2_P0_P1_REPAIR_REQUIRED_F01
CANDIDATE_UNCHANGED_AND_NOT_COMMIT_ELIGIBLE
```

The corrected artifact gate succeeded. The independent auditor authenticated the exact 315-file candidate tree:

```text
f6801df592af049a6aaef658f721fc1afe27ad6e
```

It also authenticated the 54 modifications, 16 creations, migrations 0006/0007, all three retained checkpoints, and the 74-table / 134-trigger / 5-index cumulative schema. The earlier report-presence mismatch remains a truthful result under the superseded gate, but it no longer blocks source review. Pasted text

The audit then found a **material P1 replay and recovery defect**:

- Fresh stale-currentness handling correctly commits a complete `post_execution_program_block` family.
- The persisted decision has final reason `decision_basis_not_current` and a separate candidate reason such as `candidate_evidence_conclusively_accepted`.
- Historical reconstruction passes the final decision reason into **both** reason fields.
- The candidate-reason contract rejects that block reason.
- Exact replay fails, checked readback fails, and recovery returns `unresolved` instead of `committed_exact`.
- The valid `productive_branch_not_permitted` block has the same source defect. Pasted text

This is a replay reconstruction defect, not a failure of the P0/P1 physical architecture, migration split, noncircular replan design, or work-head witness.

## Bounded repair treatment

The next repair should cover three items together:

1. **F01 — blocking:** reconstruct the candidate reason from the existing persisted typed decision basis or equivalent immutable source. Do not infer it from `decision.reason_code`, change SQL, or version the durable family.
2. **F02 — concrete closed-input defect:** require optional `expected_branch` to be `None` or exact built-in `str`; reject equality-overriding subclasses before comparison.
3. **F04 — assurance correction:** update the two stale current-migration-tip passages and replace the weakened literal-schema-name negative with a semantic or AST-level assertion.

F03 and F05 remain disclosed but **out of repair scope**:

- F03 showed no authorization bypass; the private bounded successor is already distinguished from the earlier target-only grammar.
- F05 affects no-write error precedence, not durable correctness, and should not expand this blocking repair.

The audit stopped independent execution after F01. Its source review is useful, but the connected controls, remaining physical branches, focused suite, selector-free collection, and independent FULL run remain unperformed on the current candidate. Pasted text

## Next Codex handoff

Send **only this prompt** to the **same workspace-write Codex implementation conversation** that produced the P0→P1 candidate:

:chatgpt-content-reference{index="5"}[**RW0-C2 P0→P1 F01/F02/F04 repair prompt**](sandbox:/mnt/data/Coordinator_RW0_C2_P0_P1_F01_F02_F04_Repair_Prompt.txt)

Do not send it to the independent auditor, Opus, or a new ChatGPT conversation. No attachments are required.

The mandate:

- authenticates the exact current uncommitted tree before editing;
- preserves migrations 0006/0007, relation/result/profile v2, the P0 checkpoint, the six preassignments, `WorkSpecV1`, and all existing row meanings;
- exercises both affected durable-block reasons through real fresh commit, replay, checked readback, and `committed_exact` recovery;
- proves replay causes no new row, receipt, version, or head movement;
- adds the exact-type controls for `expected_branch`;
- repairs the documentation and assurance gaps;
- runs connected, focused, and selector-free FULL validation on final bytes;
- returns a newly identified cumulative review package for a fresh independent audit.

No staging, commit, push, PR, merge, publication, live service, or product effect is authorized.

```text
Prompt bytes:   15,505
Prompt SHA-256:
cc41d5ad78316516ee4110843653bce2087a123ade5c9096e7094f9129af8a6c
```

:chatgpt-content-reference{index="6"}[Prompt identity record](sandbox:/mnt/data/Coordinator_RW0_C2_P0_P1_F01_F02_F04_Repair_Prompt_Check.json)

**Sources:** Independent artifact audit cited above; implementation report confirming the authenticated subject, selected v2 architecture, and writer-reported 9,421-test result. The latter remains implementation evidence rather than independent execution credit. Pasted text Pasted text

**Confidence:** provenance diagnosis **0.99**; F01 root cause **0.99**; bounded repair scope **0.97**. Repair correctness and independent FULL validation remain unestablished.
