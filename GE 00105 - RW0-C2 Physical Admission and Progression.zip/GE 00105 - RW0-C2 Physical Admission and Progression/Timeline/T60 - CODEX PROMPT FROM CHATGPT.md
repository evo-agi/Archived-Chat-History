OBJECTIVE

Perform the live exact-byte status commit and publication gate for the
independently accepted RW0-C2 P0→P1 status successor.

This is a commit/publication gate in the SAME write-enabled implementation
Codex conversation that owns the uncommitted status successor.

It is not an implementation, repair, merge, deployment, or product-effect
engagement. The only authorized repository changes are:

1. stage the exact independently accepted status-successor bytes;
2. validate the exact staged tree from an isolated copy;
3. create one local status commit;
4. push the existing topic branch and establish its upstream;
5. open one non-draft PR against the fixed `trunk_dev` base.

Do not edit any source, document, test, migration, configuration, file mode, or
generated repository artifact. Any byte change returns the work to
implementation and fresh audit.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

ACCEPTED SUBJECT

Independent disposition:

`RW0_C2_P0_P1_STATUS_SUCCESSOR_ARCHITECTURE_MAP_PLACEMENT_REPAIR_ARTIFACT_REVIEW_ACCEPTED`

Acceptance applies only to:

- source paths:
  `315`
- exact Git-compatible tree:
  `44c7dee402d46b3e16dc389ae0824b4297dfec1f`
- exact source-manifest SHA-256:
  `cef835b8ba4c154e52557e430e723a2b6ef3c1abaa05bdb6094b5b14c273f8b9`
- local implementation parent commit:
  `8704e6c7988250598809f3a0daf88c3e11493488`
- local implementation parent tree:
  `161ed4b544baf970cc26428b9805a106ea0f3edf`
- implementation commit's sole parent / expected PR base:
  `4519630d0db967066beb21b4ace5004e76827716`.

Exact cumulative status delta from the implementation commit:

- 26 modified existing paths;
- 0 created;
- 0 deleted;
- 0 renamed;
- 0 Git-mode changes;
- 289 unchanged paths.

Exact source chain:

`161ed4b544baf970cc26428b9805a106ea0f3edf`
→ `a34d28a7371b87c0cb874076ad610fd650ad6e72`
→ `d078d1836336fef9f5c2e7b27dc0c55fa86e5858`
→ `44c7dee402d46b3e16dc389ae0824b4297dfec1f`.

The status acceptance does not widen P0/P1 authority, runtime behavior, schema,
migrations, public API, terminal truth, live custody, publication truth, or
product effects.

IMPLEMENTATION INPUTS RETAINED IN THIS CONVERSATION

Require the exact existing retained package and report created by this
implementation conversation:

1. Review ZIP:

`/tmp/rw0-c2-status-placement-mYaAjp/rw0-c2-p0-p1-status-successor-architecture-map-placement-repair-uncommitted-review.zip`

- bytes: `11,889,349`
- SHA-256:
  `e22b3ec42ad7ae1d1ec45c25da2cab845aa5b1cecea2e5d7b02d908302d1e741`

2. Implementation report:

`/tmp/rw0-c2-status-placement-mYaAjp/IMPLEMENTATION_REPORT.md`

- bytes: `10,769`
- SHA-256:
  `9f37a9075300769e21f1cc038f15b68199570cb8f4dcbef845fb44469d9fa98c`

3. Validation supplement ZIP and standalone completion report at the exact
task-owned paths retained by the successful validation-coverage continuation:

- supplement bytes: `2,629,952`
- supplement SHA-256:
  `24c9d043ea6b6213e3b3de358fb2a3ce8bc7e9a449ba435b60ecc7fc2364db20`
- completion report bytes: `7,569`
- completion report SHA-256:
  `5b166c40aaf251200deff91728e1fc7e0558af20a5bf4585184262b0add4e83d`.

Do not regenerate or substitute these inputs. If a retained path is absent,
stop and request the exact retained artifact rather than using a same-named
Downloads file.

AUDIT INPUTS ATTACHED TO THIS GATE MESSAGE

Require both:

1. `RW0_C2_P0_P1_STATUS_SUCCESSOR_ARCHITECTURE_MAP_PLACEMENT_REPAIR_AUDIT_ACCEPTANCE_RELAY.md`
   - use the exact attachment bytes exposed by this message;
   - require the exact accepted disposition and tree above.

2. `RW0_C2_P0_P1_STATUS_SUCCESSOR_VALIDATION_SUPPLEMENT_ARTIFACT_REVIEW_EVIDENCE.zip`
   - bytes: `21,662`
   - SHA-256:
     `132d0ab8addf909cb5f48c3bc30ab4be8b17213fa0ff34693d3dfd8143cc5e2e`
   - reported members: 12 regular files and 11 self-excluding manifest rows.

The audit evidence must authenticate the acceptance continuation and exact
validation supplement. Do not infer acceptance from the implementation report
or supplement alone.

If either audit attachment is absent or differs, stop with:

`RW0_C2_P0_P1_STATUS_PUBLICATION_GATE_BLOCKED_AUDIT_ARTIFACT_IDENTITY`

OPENING EFFECT DISCIPLINE

Before the first ordinary Git command:

1. Copy `.git/index` byte-for-byte to a private task-owned external evidence
   root.
2. Record its byte count, SHA-256, metadata, and filesystem identity.
3. Record repository-root and `.git` resolution without changing them.
4. Use deterministic locale and:
   - `GIT_OPTIONAL_LOCKS=0`
   - `GIT_NO_REPLACE_OBJECTS=1`.
5. Do not clean, reset, restore, checkout, switch, rebase, stash, fetch, pull, or
   modify configuration.

Then authenticate:

- branch:
  `codex/rw0-c2-p0-p1-physical-program-v1`
- HEAD:
  `8704e6c7988250598809f3a0daf88c3e11493488`
- HEAD sole parent:
  `4519630d0db967066beb21b4ace5004e76827716`
- HEAD tree:
  `161ed4b544baf970cc26428b9805a106ea0f3edf`
- upstream:
  absent
- local `trunk_dev`:
  `4519630d0db967066beb21b4ace5004e76827716`
- local `origin/trunk_dev`:
  `4519630d0db967066beb21b4ace5004e76827716`
- stage-zero index:
  exactly 315 entries equal to HEAD
- staged and unmerged entries:
  none
- working source:
  exactly the accepted 315 regular paths
- worktree classification:
  exactly 26 modified, 0 created, 0 deleted, 0 renamed, 289 unchanged
- reconstructed working tree:
  `44c7dee402d46b3e16dc389ae0824b4297dfec1f`
- source manifest:
  `cef835b8ba4c154e52557e430e723a2b6ef3c1abaa05bdb6094b5b14c273f8b9`
- no production Python, SQL, migration, configuration, API, mode, or path
  creation/deletion in the accepted delta.

Any source/path/mode/index/baseline mismatch is blocking. Do not normalize it.

REF AND LIVE-MODE POLICY

Use the already accepted authoritative-versus-diagnostic ref policy:

Qualified diagnostic refs are only direct refs under:

- `refs/codex/turn-diffs/captures/`
- `refs/codex/turn-diffs/checkpoints/`.

Every other ref is authoritative.

Require:

- no replace ref, graft, alternate object database, unexpected worktree, or
  source-selection indirection;
- all authoritative refs except the current topic remain unchanged through the
  gate;
- complete opening diagnostic inventory retained;
- any surviving diagnostic name must not retarget;
- each current diagnostic ref resolves directly to a commit or tree;
- no source, validation, package, publication, or policy input depends on a
  diagnostic ref.

Qualified diagnostic additions/removals are evidence, not automatic blockers.
Any authoritative delta, diagnostic retarget, invalid object type, or
source-selection dependency is blocking.

Authenticate all 315 live source paths against the accepted manifest by path,
type, bytes, SHA-256, Git blob, Git mode, and POSIX mode.

Require:

- 314 accepted ordinary files at live mode `0644`, Git `100644`;
- one classified file:
  `tests/test_c2b3_private_atomic_program_initialization.py`
  at exact accepted bytes, live mode `0600`, Git mode `100644`.

Do not chmod it into compliance.

SOURCE FREEZE

Before staging:

- run `git diff --check`;
- capture the complete source manifest twice from fresh reads;
- require byte-identical results;
- independently reconstruct the accepted Git tree;
- rehash the implementation package/report, supplement/report, audit relay, and
  audit evidence;
- verify the two relocated status blocks, frozen four-owner architecture body,
  and unchanged `tests/test_architecture_contracts.py` identities from the
  accepted package.

No source edit is authorized to fix a failed check.

REMOTE AND RULESET PREFLIGHT

Network access is authorized only for the bounded GitHub publication preflight,
push, and PR creation in this gate.

Before staging, observe:

- remote repository identity;
- remote `trunk_dev`;
- whether the topic branch exists remotely;
- whether an open or closed PR already targets this exact topic/base;
- applicable branch rules/rulesets for `trunk_dev`;
- allowed merge methods, approval/thread/check requirements, and bypass posture.

Require remote `trunk_dev` at:

`4519630d0db967066beb21b4ace5004e76827716`

Require the remote topic and open PR to be absent. If either exists, stop rather
than overwrite, force-push, duplicate, or repurpose it.

Zero configured checks is not a CI pass.

STAGING

Derive the exact accepted 26-path set from the authenticated baseline/final
manifests. Do not hand-maintain or broaden it.

Stage exactly those 26 existing paths once:

`git add -- <exact accepted paths>`

Requirements:

1. no other stage mutation;
2. staged inventory has exactly 315 stage-zero entries;
3. the 289 unchanged entries equal HEAD;
4. every staged blob and Git mode equals the accepted final manifest;
5. no creation, deletion, rename, submodule, symlink, executable mode, or other
   path;
6. `git diff --cached --check` passes;
7. one and only one successful `git write-tree` returns:

   `44c7dee402d46b3e16dc389ae0824b4297dfec1f`.

Any mismatch blocks. Do not unstage/restage or repair bytes.

STAGED-TREE VALIDATION

Build a fresh task-owned external copy solely from the staged Git tree's 315
blobs. Apply the accepted checkout-mode map: 314 files at `0644`, the classified
test at `0600`.

Do not import from the live checkout.

Use:

- Python 3.13.4;
- pytest 8.4.1;
- SQLite 3.49.1;
- `PYTHONDONTWRITEBYTECODE=1`;
- `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`;
- `-p no:cacheprovider`;
- restrictive umask;
- task-owned HOME, TMPDIR, basetemps, JUnit, and logs;
- deterministic locale/timezone;
- network-denial sandbox.

Run exactly one collection and one execution of the accepted expanded focused
selector:

- all 37 complete modules from the accepted validation supplement;
- no node selectors.

Require:

- 5,448 unique collected IDs;
- 5,448 executed call IDs;
- 5,448 JUnit IDs;
- exact identity and order across all three;
- ordered-ID SHA-256:
  `4cdc753dc5e28c0c548d3eeaffa92adc9f900bb5f3999a1d2a3015640277eaee`;
- 5,448 passes;
- zero failures, errors, skips, xfails, xpasses, or warnings;
- every source byte and numeric mode unchanged before and after collection and
  execution.

A selector-free FULL rerun is not required in this status publication gate. The
accepted supplement already binds a selector-free 9,502-pass FULL result to the
same exact tree, and the live staged-tree gate rechecks every identified
affected complete module.

Do not narrow the selector, rerun after a byte edit, refresh an expected count,
or exclude a failure.

LOCAL STATUS COMMIT

Only after all opening, stage, and validation gates pass:

1. Prepare the exact commit message outside the repository.
2. Create one local commit with exact subject:

   `docs: record RW0-C2 P0-P1 physical program status`

3. Require:
   - sole parent:
     `8704e6c7988250598809f3a0daf88c3e11493488`
   - tree:
     `44c7dee402d46b3e16dc389ae0824b4297dfec1f`
4. Verify the raw commit object, complete message bytes, parent, tree, and all
   315 committed blobs/modes.
5. Do not amend or create a second commit.
6. Require a clean worktree and index.
7. Reauthenticate the classified live file remains POSIX `0600`.
8. Require local `trunk_dev` and local `origin/trunk_dev` remain at the fixed
   base.
9. Require the topic commit and HEAD movement to be the only local authoritative
   ref change.

PUSH AND PR

After the local status commit passes:

1. Push once, plainly, with upstream creation:

   `git push -u origin codex/rw0-c2-p0-p1-physical-program-v1`

2. No force push, lease override, refspec broadening, tag push, or second push.
3. Require remote topic to equal the new local status commit.
4. Require remote `trunk_dev` to remain at the fixed base.
5. Require the only config additions to be the topic branch's ordinary
   `remote=origin` and `merge=refs/heads/...` entries.
6. Open one non-draft PR:
   - title:
     `RW0-C2: physical admission and progression`
   - base:
     `trunk_dev`
   - head:
     `codex/rw0-c2-p0-p1-physical-program-v1`
7. Require the PR to contain exactly:
   - implementation commit
     `8704e6c7988250598809f3a0daf88c3e11493488`;
   - the new status commit;
   - no other commit.
8. The PR body must record:
   - exact implementation and status trees;
   - independent audit dispositions;
   - local implementation FULL result: 9,473 passes;
   - accepted status supplement FULL result: 9,502 passes;
   - staged-tree expanded focused result: 5,448 passes;
   - no publication or product authority beyond the PR;
   - F03 and F05 remain nonblocking observations;
   - all live supplier/custody, terminal, provider/worker, ES/Bridge,
     product-Git, service, scheduler, deployment, and autonomy nonclaims.
9. Read back PR number, state, draft status, head/base SHAs, commit list, reviews,
   threads, checks/statuses, mergeability, and auto-merge state.
10. Do not merge or enable auto-merge.
11. Zero checks is not a CI pass.

CLOSEOUT

Retain outside the repository:

- all fixed input identities;
- pre-Git raw-index copy and semantic index;
- opening/final source and mode manifests;
- authoritative/diagnostic ref maps and deltas;
- remote/ruleset preflight and post-push/PR readbacks;
- exact stage path/blob/mode inventory;
- sole write-tree stdout;
- focused collection/execution argv, environment, IDs, JUnit, warnings, logs,
  and source before/after;
- prepared commit message and raw commit verification;
- push and PR request/readback records;
- final source/index/config/ref/mode readback;
- cleanup receipt.

Create:

- one closeout report;
- one machine-readable result;
- one self-excluding retained-artifact manifest;
- one reopened closeout ZIP containing only classified safe evidence.

Reopen and hash-verify every retained deliverable before removing only
task-owned validation/temp state.

Do not include credentials, raw sensitive Git configuration, environment dumps,
user databases, SQLite sidecars, `.pyc`, caches, or unclassified material.

STOP CONDITIONS

Stop before the next effect if:

- an input or source identity differs;
- the live mode map differs;
- branch, HEAD, base, upstream, index, configuration, or authoritative refs
  differ;
- remote base/topic/PR preconditions differ;
- accepted path set or write-tree differs;
- focused count/order/outcome/warnings differ;
- validation changes source bytes or modes;
- a source, status, test, migration, configuration, or mode edit appears needed;
- the commit object differs;
- push or PR readback differs;
- a security, authority, privacy, publication, or durable-state boundary would
  widen.

Do not repair during this gate.

EFFECT CEILING

Authorized:

- read-only live repository/artifact authentication;
- bounded GitHub remote/ruleset preflight;
- one exact staging operation;
- one successful `git write-tree`;
- one external expanded-focused validation pair;
- one local status commit;
- one plain push with upstream creation;
- one non-draft PR;
- task-owned evidence and cleanup.

Not authorized:

- source/document/test/schema/migration/configuration/mode edit;
- branch switch, rebase, reset, stash, clean, cherry-pick, amend, or force push;
- fetch or pull unless a narrow read-only fetch is explicitly required to
  authenticate the fixed base and is recorded before staging;
- merge, auto-merge, branch deletion, tag creation;
- deployment, release, live service/provider/worker/ES/Bridge use;
- user/product database access;
- terminal persistence or product effect.

REQUIRED FINAL RESPONSE

Return one of:

- `RW0_C2_P0_P1_STATUS_SUCCESSOR_COMMITTED_PUSHED_AND_PR_OPENED`
- `RW0_C2_P0_P1_STATUS_PUBLICATION_GATE_BLOCKED_<PRECISE_REASON>`

Include:

- exact opening/final branch, HEAD, tree, upstream;
- new status commit SHA, subject, parent, tree, raw-message identity;
- all implementation, supplement, and audit input identities;
- exact 26-path stage classification;
- sole write-tree result;
- expanded-focused collection/execution/JUnit reconciliation;
- complete committed blob/mode comparison;
- live `0600` mode readback;
- raw-index treatment;
- authoritative and diagnostic ref deltas;
- push result;
- PR URL/number, title, head/base, commit list, draft state, reviews, threads,
  checks/statuses, mergeability, and auto-merge state;
- ruleset summary;
- retained artifact paths, sizes, and SHA-256 values;
- assumptions, process errors, skipped/unavailable work;
- explicit:
  `MERGE_NOT_PERFORMED`
  `AUTO_MERGE_NOT_ENABLED`
  `DEPLOYMENT_NOT_PERFORMED`
  `PRODUCT_EFFECT_NOT_PERFORMED`;
- nonclaims for live authority, terminal truth, production execution, and
  autonomy.

A successful result authorizes no merge. The exact next recipient is ChatGPT for
review of the gate report and preparation of a separate squash-integration gate.
