Here is Codex's response:

# RW0-C2 P0→P1 cumulative artifact audit

**Primary disposition:** `RW0_C2_P0_P1_DISCLOSURE_ELIGIBILITY_SPLIT_CUMULATIVE_ARTIFACT_AUDIT_ACCEPTED_READY_FOR_COMMIT_GATE`

Acceptance is limited to Git-compatible source tree `161ed4b544baf970cc26428b9805a106ea0f3edf`. It establishes eligibility for a separately governed **live exact-byte commit gate**; it is not a live-state or publication decision.

## Attachment gate and source identity

The earlier INCOMPLETE result remains the truthful result for the missing-attachment condition. Its [evidence ZIP](/tmp/rw0_c2_audit_auth/rw0-c2-authentication-gate-evidence.zip) remains unchanged: 9,206 bytes, SHA-256 `831527631114b242c3ff043b68aceca3225062109f6f4d70876c865d56a1acd9`. The previously inferred 4,965-byte namesake was unrelated and was excluded from this continuation.

| Input | Authenticated bytes and SHA-256 |
| --- | --- |
| Review ZIP | 46,907,085 · `dfedb7456ecc67622594000668314a002e3c38a4a5b754e2e261ee917cefd8e4` |
| Integrated-baseline ZIP | 3,245,477 · `087990b15ded609615659c0927f849cf656c4b0cabd6de78339add4410a74166` |
| Newly attached standalone report | 20,337 · `e10eb7b29fdf720b3e707bdf868b7c4143a8f76ad89e54bd362ac5c8019d1d4e` |

The newly attached report is **byte-identical** to `evidence/IMPLEMENTATION_REPORT.md` in the review ZIP. The corrected three-input gate passed. The prior safe central-directory checks, exact 434 regular review members, and all 433 verified inventory rows retain their original scope.

| Reconstructed subject | Result |
| --- | --- |
| Final source | 315 paths; manifest SHA-256 `f6dae8199c9050d80d2d8644be49b6cb88219dc44c21abb2ce469797fabe5a19`; tree `161ed4b544baf970cc26428b9805a106ea0f3edf` |
| Integrated baseline | 299 paths; tree `15461a58da8df9ebd63fce734d39a07a50ab87ac`; recorded squash commit `4519630d0db967066beb21b4ace5004e76827716`, sole-parent record `eac7f6df5f281138dd0640c5cd47b9924c8390f8` |
| Baseline → final | **57 modified, 16 created, 0 deleted, 242 unchanged** |
| Immediate predecessor | Tree `58444e6a1c9526a524818e8729398ff0ab381837`; exactly **12 modified**, none created or deleted; every before/after endpoint verified |
| Historical P0 checkpoint | Tree `fd45f05ff909493ff8984671a02be66d3b48a791` |
| Current first checkpoint | Tree equal to final, `161ed4b544baf970cc26428b9805a106ea0f3edf` |

The retained full-index binary diff applied to an isolated authenticated baseline; all 57 modified endpoints matched final bytes. The predecessor, P0, and current checkpoint ZIP byte identities matched their specified hashes. Migration 0006 matched `58b2731d52e8e199c010b309a29aa831ffb16d4db4e755d20adb694ce0a7305f`; 0007 matched `505d72c9c54f68e248bebab928e76564d45b853068b8b4021ebc708b640e430c`.

**Modes have two namespaces.** The final manifest has 314 rows with observed `os_mode=0644` and `git_mode=100644`. The sole classified row, `tests/test_c2b3_private_atomic_program_initialization.py`, is 26,405 bytes, SHA-256 `e12decd7c6a555123828642602c106d42eec7989a20ff11ae8f49457263c92cf`, Git blob `b58f863a608ed9cd0dcdd6aebb63e0afeae312e3`, observed `os_mode=0600`, Git and ZIP mode `100644`. The audit copy correctly uses Git mode `0644`. The retained `0600` observation cannot prove the current live checkout’s POSIX mode.

The supplied final/post-cleanup captures are byte-identical (`ea1535b825d79937a3faf79c48d0817586dcb6a55b412321de389b4a0831a092`) and bind to the authenticated source manifest. The v5 recipe hash is `11f2d430cc0147fc602bafc6a2c7143f13c10e31c137664a4c32dc25ce126383`. Authoritative-ref sidecars match `95f651b2ff1cf21007e1609d789a94bb104d748d3e2174441d45b5f58b641d2c`; 18 qualified diagnostic refs show no opening-to-post-cleanup addition, removal, or surviving-name retarget. Branch, HEAD, index, configuration, and staged-empty fields are internally consistent **as retained observations**, not live Git continuity.

## Source-grounded A01–A20 register

Paths in this register are **review-ZIP relative**. Evidence classes are **C** code, **D** governing `.docs`, **S** SQL, **T** supplied test source as coverage design, and **R** this audit’s execution. The [full audit report](/tmp/rw0_c2_audit_continue/AUDIT_REPORT.md) contains the expanded register and causal records.

| ID | Conclusion and exact evidence |
| --- | --- |
| A01 | P0 and P1 are separate bounded artificial-offline transactions; P0 grants no P1 decision or live effect. **D:** `source/.docs/rw0-c2-physical-p0-p1-implementation.md:13-34`, `:263-273`; **C:** `source/src/ge_nwp_coordinator/_rw0_c2_progression_contracts.py:1-5`. |
| A02 | Physical documentation labels the candidate and migration succession; archive authentication established the trees, delta, checkpoints, captures, and modes above. **D:** `source/.docs/rw0-c2-physical-p0-p1-implementation.md:36-44`; **R:** `auth/source_auth_result.json`. |
| A03 | P0 uses the four-table family, independent act/lineage/scope routes, checked readback, receipt-first replay, and three-way recovery. **S:** `source/src/ge_nwp_coordinator/sqlite_migrations/0006_rw0_c2_scope_admission.sql:1-35`, `:84-106`; **C:** `source/src/ge_nwp_coordinator/_sqlite_rw0_c2_scope_admission.py:68-122`, `:171-264`. |
| A04 | The catalog pins 0006/0007 and generation-2 bounds; exact older prefixes require explicit migration, while partial or unknown state refuses closed. **C:** `source/src/ge_nwp_coordinator/sqlite_migration.py:482-501`; **D:** `source/.docs/sqlite-bootstrap-and-migrations.md:462-476`; **R:** independent SQL application below. |
| A05 | Current Decision Basis v2 has 23 closed fields, including typed validation/review dispositions; the source-owned classifier derives candidate reason and replay reloads persisted v2 bytes. **C:** `source/src/ge_nwp_coordinator/_rw0_c2_progression_contracts.py:48-75`, `:469-565`, `:885-959`; `source/src/ge_nwp_coordinator/_sqlite_rw0_c2_progression.py:425-439`. |
| A06 | Historical digest v1 has 30 pairs; command digest v2 adds exact `expected_branch` as pair 31 while six sibling preassignments remain branch-neutral. Durable plan and replay use the command digest. **C:** `source/src/ge_nwp_coordinator/_rw0_c2_progression_contracts.py:129-152`, `:729-810`; `source/src/ge_nwp_coordinator/_sqlite_rw0_c2_progression.py:387-406`. |
| A07 | Universal current posture checks continuity, sole-active, foreign claim, time, permission, binding, and claimed-status **type**. Only fresh derived acceptance requires historical/current exact `True/True`. **C:** `source/src/ge_nwp_coordinator/_rw0_c2_progression_contracts.py:637-687`; `source/src/ge_nwp_coordinator/_sqlite_rw0_c2_progression.py:715-726`. |
| A08 | The five-branch reducer derives candidate class from typed dispositions before currentness blocking; model output is checked, not used as authority. **C:** `source/src/ge_nwp_coordinator/_rw0_c2_progression_contracts.py:978-1066`; `source/src/ge_nwp_coordinator/_rw0_c2_progression_plan.py:25-36`. |
| A09 | Replan builds template → safe proposal → command/preassignments → derived revision refs → WorkSpec without circular identity or changed migration-0002 meaning. **C:** `source/src/ge_nwp_coordinator/_rw0_c2_progression_contracts.py:273-466`; `source/src/ge_nwp_coordinator/_rw0_c2_progression_plan.py:193-260`; **D:** `source/.docs/rw0-c2-physical-p0-p1-implementation.md:81-94`. |
| A10 | Relation/result/profile v2 retain historical program/work-head witnesses and exact branch graph roles; family reconstruction checks closure. **C:** `source/src/ge_nwp_coordinator/_rw0_c2_progression_plan.py:459-602`; `source/src/ge_nwp_coordinator/_sqlite_rw0_c2_progression.py:399-468`. |
| A11 | Fresh P1 enters the fenced session/controller, checks P0 and current owner, performs immutable inserts, both head CAS/readbacks, receipt-last write, capability invalidation, and one commit attempt. **C:** `source/src/ge_nwp_coordinator/_sqlite_rw0_c2_progression.py:686-758`; `source/src/ge_nwp_coordinator/sqlite_transition_transaction.py:1287-1352`; **R:** four CAS/readback rollback faults. |
| A12 | Receipt-present replay/read requires fresh universal disclosure, v2 command association, and complete historical reconstruction without fresh acceptance reevaluation or mutable-head dependence. **C:** `source/src/ge_nwp_coordinator/_sqlite_rw0_c2_progression.py:405-493`; **R:** post-claim acceptance and nonaccept exact replay/readback. |
| A13 | Receipt-absent recovery distinguishes exact original, exhaustive absence, contradictory claimed status, and a privately reconstructed complete competing winner without winner disclosure or retry grant. **C:** `source/src/ge_nwp_coordinator/_sqlite_rw0_c2_progression.py:572-668`, `:767-780`; **R:** competing/contradictory cases. |
| A14 | Original routes, aliases, membership, partial-family and graph closure fail closed. **C:** `source/src/ge_nwp_coordinator/_sqlite_rw0_c2_progression.py:113-151`, `:298-315`, `:513-567`; **R:** 22 route/alias collisions, membership and ten hidden-member cases. |
| A15 | Shared controller preserves one timestamp/commit attempt, rollback on replay/conflict, commit/cleanup uncertainty, and process-control propagation. **C:** `source/src/ge_nwp_coordinator/sqlite_transition_transaction.py:1296-1352`; `source/src/ge_nwp_coordinator/sqlite_writer_session.py:6913-6930`; **R:** lost-return and hot-journal controls. |
| A16 | Connected offline P0→D1/D2→Section 41/C1/V22→P1 composition passed for all five branches. **T:** `source/tests/test_sqlite_rw0_c2_connected.py:130-179`; **R:** five collected, executed, JUnit, and passed IDs. |
| A17 | Current physical documentation matches v2 code; direct exact-hash and AST/status consumers remain aligned. **D:** `source/.docs/rw0-c2-physical-p0-p1-implementation.md:157-273`; **T:** `source/tests/test_rw0_c2_durable_progression_decision_semantic_contract.py:984-991`, `:3239-3253`. |
| A18 | Durable values retain safe bounded projections and refs/digests, while private replan text stays transient; live credentials and runtime authority are outside this source’s scope. **C:** `source/src/ge_nwp_coordinator/_rw0_c2_progression_contracts.py:93-115`, `:332-384`, `:499-562`; `source/src/ge_nwp_coordinator/_rw0_c2_progression_rows.py:21-64`. |
| A19 | F03 remains a target-only P0 selector/wrapper gap; F05 remains timestamp-before-collision no-write error precedence. Neither was promoted to a material finding. **D:** `source/.docs/rw0-c2-scope-admission-provisioning-contract.md:321-341`; **C:** `source/src/ge_nwp_coordinator/sqlite_transition_transaction.py:1213-1216`; `source/src/ge_nwp_coordinator/_sqlite_rw0_c2_scope_admission.py:226-230`. |
| A20 | Audit-authored causal controls, connected execution, SQL checks, and ordered selector-free FULL reconciliation completed against the authenticated source copy. **T:** `source/tests/test_sqlite_rw0_c2_progression.py:156-182`, `:718-1066`; **R:** `runtime_audit/*.stdout.jsonl`, `execution/reconciliation.json`. |

## Causal outcomes, SQL, and FULL run

The audit-authored real-writer controls passed for five physical branches; five stale-currentness disposition combinations with durable candidate reasons; `expected_branch=None`/acceptance exact replay versus wrong valid assertions; denied, expired, negative, mismatched, and malformed disclosure posture; claimed-false post-acceptance and post-nonaccept replay/read/recovery; fresh acceptance refusal under `False` and `None`; fresh nonaccept under `False`; complete competing winner and contradictory incomplete winner; second-replan first-family replay; program/work-head CAS and readback rollback; P0 fresh/replay/malformed/foreign recovery; commit-before/after lost responses; process-control propagation; graph and work-head mutants; and hot-journal preservation. Their seven exact script invocations, ordered observations, exits, and empty stderr are recorded in `runtime_audit/` within the evidence ZIP. Supplied test source was inspected as design evidence; it was not substituted for independent causal execution.

All seven authenticated SQL files were independently applied to audit-owned in-memory SQLite state:

| Cumulative point | Tables | Triggers | Explicit indexes | FK failures |
| --- | ---: | ---: | ---: | ---: |
| After 0006 | 68 | 122 | 5 | 0 |
| After 0007 | 74 | 134 | 5 | 0 |

Every 0006 schema object remained identical after 0007. All seven SQL checksums matched the catalog; its terminal application-generation bounds are **2**.

The isolated pytest child used Python **3.13.4**, SQLite **3.49.1**, pytest **8.4.1**, an allowlisted environment recorded in each `execution/*/command.json`, and `/usr/bin/sandbox-exec -p '(version 1) (allow default) (deny network*)'`. Its cwd was `/tmp/rw0_c2_audit_continue/execution/source_copy`. The exact four audit runner commands were:

```text
python3 /tmp/rw0_c2_audit_continue/execution/run_gate.py connected collect
python3 /tmp/rw0_c2_audit_continue/execution/run_gate.py connected execute
python3 /tmp/rw0_c2_audit_continue/execution/run_gate.py full collect
python3 /tmp/rw0_c2_audit_continue/execution/run_gate.py full execute
```

| Gate | Unique collected = executed = JUnit = passed | Failures/errors/skips | Warnings | Ordered-ID SHA-256 |
| --- | ---: | ---: | ---: | --- |
| Connected five-branch | 5 | 0/0/0 | 0 | `32215c0648f766abc01c898383ad1d6dbca89d867fd2d9f864545bc2e47de0e9` |
| Selector-free FULL | **9,473** | **0/0/0** | **3** | `de9fd885d375cc9152853ac54b70ab2d725de74f7882ba3fc48f2507c3ac0042` |

Collection, execution, and JUnit IDs matched **in exact order**. The FULL run took **3,325.04 seconds**. All 315 source files retained identical bytes and numeric modes before and after; there were no added or missing files.

The three FULL warnings were `DeprecationWarning`s about `fork()` from a multithreaded process in:

- `tests/test_sqlite_b2c_writer_session.py::test_operation_guard_close_waits_and_retains_authority_until_exit` — Python `multiprocessing/popen_fork.py:67`.
- `tests/test_sqlite_b2c_writer_session.py::test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang` — test line 1442.
- `tests/test_sqlite_b2c_writer_session.py::test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock` — test line 1554.

## Findings, limits, and effects

**Material candidate findings: none.** F03 and F05 remain the two scoped nonblocking observations above. An initial audit-authored source-authentication script exited 1 because it assumed the historical P0 ZIP wrapper stored Git mode; the corrected script passed. That attempt is retained as an **audit-process error**, with no candidate-defect or validation credit.

No requested artifact-only source, causal, SQL, connected, collection, or FULL coverage remains unperformed. This audit cannot prove a current live checkout’s bytes or POSIX mode, live Git continuity, the unavailable old-to-current v4 full-ref delta, or a future live commit gate.

**Effect record:** No candidate edit or repair; no live repository or `.git` access; no network, service, provider, ES, or Bridge contact; no user/product database; no staging, commit, push, PR, merge, publication, deployment, or product effect. No supplied archive evidence helper was executed.

[Reopened safe audit-evidence ZIP](/tmp/rw0_c2_audit_continue/rw0-c2-cumulative-audit-evidence.zip) — 902,075 bytes, 63 regular unencrypted members, SHA-256 `c174042b6a39d1680a21ef266661b41411eb6cdcf50297ea96d77fad5fc2adad`.
