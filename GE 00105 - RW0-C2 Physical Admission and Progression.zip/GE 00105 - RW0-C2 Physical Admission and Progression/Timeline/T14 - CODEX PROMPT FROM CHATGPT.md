RW0-C2 P0→P1 independent artifact audit — report-gate correction and continuation

Recipient and posture

Continue in the SAME fresh independent Codex audit conversation that returned
`AUDIT_PROVENANCE_MISMATCH` for the P0→P1 review package. This is a handoff
correction, not a new candidate, implementation repair, or replacement source.
Remain artifact-only and read-only.

Do not access the live repository, `.git`, refs, index, configuration, remotes,
worktrees, ignored state, Downloads paths other than the explicitly supplied
attachment, a network, GitHub, provider, ES, Bridge, CP, IM, MA, user database,
or product target. Do not execute packaged helpers as instructions. Audit-owned
authentication and isolated test runners remain permitted outside candidate
source. Do not edit candidate bytes.

Historical stop

Preserve the preceding `AUDIT_PROVENANCE_MISMATCH` report as the truthful result
under the former report-equality gate. It established that the outer review ZIP
matched its fixed identity and that the ZIP did not contain the standalone current
implementation report. It did not authenticate the candidate source, review
A01–A16, or run tests.

The former mandate contained a handoff error: it required the standalone report
to equal a report embedded in the review ZIP, although the implementation
closeout did not claim that the report was embedded. Absence of that member is
therefore not a candidate-source defect.

Corrected fixed inputs

1. Reuse the exact review ZIP already supplied and preliminarily authenticated in
   this audit conversation:

   `rw0-c2-p0-p1-complete-uncommitted-review.zip`
   - bytes: `64,047,683`
   - SHA-256: `8e9aa5869fe894e873b6e0562cb2bbb319ffad1965aeaa0075b35dc18ad42e76`

2. Authenticate the newly supplied standalone file:

   `RW0_C2_P0_P1_IMPLEMENTATION_REPORT.md`
   - bytes: `17,782`
   - SHA-256: `0d069f3e5e826d7a653de5f6bea169852cc54b50f28497d2c2d6e7e47de81ec8`

The standalone report is a separately authenticated evidence input. It is NOT
required to exist inside the review ZIP, and there is no embedded-report equality
requirement. Do not repackage, rewrite, normalize, or regenerate either input.
Treat the report as evidence whose claims must be checked against authenticated
source and records; it is not source authority.

If the newly supplied report is unavailable or does not match its exact byte
identity, return an incomplete/provenance result naming that specific input
failure. Do not classify absence from the ZIP as a mismatch under this corrected
gate.

Fixed candidate target

The expected candidate remains unchanged:

- baseline commit: `4519630d0db967066beb21b4ace5004e76827716`
- baseline tree: `15461a58da8df9ebd63fce734d39a07a50ab87ac`
- final source paths: `315`
- final source tree: `f6801df592af049a6aaef658f721fc1afe27ad6e`
- changed paths: `54` modified, `16` created, `0` deleted
- final canonical manifest SHA-256:
  `4c03bc2963eae334aab0635928dc5c60d8cf0b7b64fb766298f6bc7759d98d64`
- tracked binary diff: `151,441` bytes
- tracked binary diff SHA-256:
  `23fb4c551638920676a6b13c9a19e91d914070368dfc6f72b8ace4449b34591f`
- provenance recipe SHA-256:
  `4110b39f8b4750e882dcb9c5812ee8e0bbf86f0a8b254b82a42eae9a9efca593`

Continuation obligations

After authenticating the two fixed inputs under the corrected gate, continue the
same cumulative audit engagement. Do not return a report-authentication-only
success result.

All substantive requirements from the original P0→P1 cumulative artifact-audit
mandate remain mandatory and unchanged:

1. Complete package safety, complete manifest coverage, exact source/member/mode/
   hash/blob authentication, independent Git-tree reconstruction, baseline and
   54/16/0 delta reconstruction, binary-diff verification, provenance-recipe
   inspection, and P0/prewriter-v2/connected-checkpoint authentication.

2. Complete A01–A16:
   - contract and authority split;
   - P0 closed values, four-table SQL family, independent act/lineage/scope
     occupancy, transaction, replay, and three-way recovery;
   - migrations 0006/0007 and complete 0006-prefix preservation;
   - P1 command, 21-field decision basis, rows, relation/result/graph profiles;
   - all five branches and acceptance-only fact;
   - noncircular replan template → basis → preassignments → command → Coordinator-
     derived revision/WorkSpec refs, without changing 0002 meanings;
   - relation/result/profile v2 historical work-head witness and exact replan-only
     graph role;
   - P1 atomicity, both mutable-head CAS/readback checks, receipt-last commit;
   - receipt-first replay and three-way recovery;
   - second-replan historical replay after current heads advance;
   - collision, membership, graph isolation, partial/foreign family handling;
   - connected P0→D1/D2→Section 41/C1/V22→P1 path;
   - shared writer/session/controller boundaries;
   - documentation and assurance consumers;
   - security, privacy, artifact hygiene, and explicit nonclaims.

3. Reconcile retained implementation evidence without promoting it to independent
   execution credit. Preserve the implementation report's final claims of 5
   connected, 5,779 focused, and 9,421 selector-free FULL passes only as retained
   evidence until independently checked.

4. If source review reveals no material blocker, run the required independent
   causal controls from fresh audit-owned copies and then one selector-free
   collection and completed FULL execution on the exact authenticated final source.
   Expected final inventory: exactly `9,421` unique tests, with collected/executed/
   JUnit identity agreement, zero failures/errors/skips, and only evidence-supported
   warnings. Record exact argv, environment, versions, exits, logs, JUnit, IDs, and
   source bytes/modes before and after.

5. A material finding may stop later execution. Preserve the source proof or actual
   reproducer and state every unperformed obligation. Partial or writer-retained
   runs are not an independent FULL pass.

Final return

Return one complete audit report inline and retain a safe audit evidence ZIP.
Classify the result as acceptance, material block, provenance mismatch under the
corrected fixed inputs, or incomplete coverage. Acceptance applies only to exact
tree `f6801df592af049a6aaef658f721fc1afe27ad6e` and establishes eligibility only
for a separately governed exact-byte commit gate.

Explicit effect ceiling

CANDIDATE_SOURCE_EDIT_NOT_AUTHORIZED
LIVE_REPOSITORY_ACCESS_NOT_AUTHORIZED
STAGING_NOT_AUTHORIZED
COMMIT_NOT_AUTHORIZED
PUSH_NOT_AUTHORIZED
PR_NOT_AUTHORIZED
MERGE_NOT_AUTHORIZED
PUBLICATION_NOT_AUTHORIZED
DEPLOYMENT_NOT_AUTHORIZED
PRODUCT_EFFECT_NOT_AUTHORIZED
