Here is Codex's response:

# RW0-C2 P0→P1 Decision Basis v2 cumulative audit

**Primary disposition: `AUDIT_PROVENANCE_MISMATCH`**

The audit stopped at Phase 1, before source correctness review or test execution. The required OS-mode check fails for `tests/test_c2b3_private_atomic_program_initialization.py`: the final `source/` ZIP member has Unix mode `0100644` (permissions `0644`), while [the final source manifest](/Users/ds/Downloads/rw0-c2-p0-p1-decision-basis-v2-uncommitted-review.zip) records `os_mode:"0600"` on line 1. The baseline and v2-first checkpoint have the same mismatch. The P0 checkpoint preserves `0600`.

The baseline README describes archiving Git mode while retaining an observed checkout mode. That explains the distinction but does not verify the source-member OS mode required by this audit. This is a **material provenance finding**, not a finding about the candidate’s code. The file’s bytes and Git mode match, so the mismatch does not change the reconstructed Git trees.

## Phase 1 results

| Input                   | Bytes      | SHA-256                                                            | Result  |
| ----------------------- | ---------- | ------------------------------------------------------------------ | ------- |
| Review ZIP              | 13,024,080 | `675748890d754e4cfefe634b78019cfbaa68cdbd6b653657b98dc39b1164ffa0` | Matched |
| Standalone report       | 20,614     | `a6f2eae980785736ee26276381519b5e45044bb1fbf38e87f41c61d9a33326ec` | Matched |
| Integrated baseline ZIP | 3,245,477  | `087990b15ded609615659c0927f849cf656c4b0cabd6de78339add4410a74166` | Matched |

Both supplied ZIP central directories and the two nested checkpoint ZIPs passed the pre-extraction path, duplicate and case-fold collision, type, encryption, mode, compression, and size checks. The review ZIP has exactly **422** members; `package-inventory.json` covers the other **421** by path, size, SHA-256, and numeric archive mode. The baseline inventory likewise covers its other **334 of 335** members. The standalone report is byte-identical to `evidence/IMPLEMENTATION_REPORT.md`.

Independent byte and Git-mode reconstruction passed despite the OS-mode failure:

| Source endpoint               | Paths | Reconstructed Git tree                     |
| ----------------------------- | ----- | ------------------------------------------ |
| Integrated baseline           | 299   | `15461a58da8df9ebd63fce734d39a07a50ab87ac` |
| P0 checkpoint                 | 305   | `fd45f05ff909493ff8984671a02be66d3b48a791` |
| V2-first checkpoint and final | 315   | `8e247b21320f90d2d2cb98d3d165f7fc35f117a8` |

The final source-manifest SHA-256 is `894f3a690cd5457415260f5a5a35650764b11ed3203c28672649835df705ba12`. Baseline-to-final comparison found **56 modified, 16 created, 0 deleted, 243 unchanged** paths. An audit-authored replayer applied all **56 sections and 150 hunks** of the retained tracked diff to authenticated baseline bytes and obtained the exact final bytes. The recorded v2 repair delta is **26 modified, 0 created, 0 deleted**. The two final captures and post-cleanup capture are byte-identical retained observations; they establish no live Git state.

Final migration checksums matched: 0006 is `58b2731d52e8e199c010b309a29aa831ffb16d4db4e755d20adb694ce0a7305f`, and 0007 is `505d72c9c54f68e248bebab928e76564d45b853068b8b4021ebc708b640e430c`. The claimed 74-table, 134-trigger, 5-index schema and application generation 2 were **not independently executed or verified**.

The precise failed evidence is the `source/tests/test_c2b3_private_atomic_program_initialization.py` central-directory record versus `evidence/current/canonical-final-1-source-manifest.json:1`; `source_manifest.json:1` in the baseline has the corresponding observed-mode claim. The final file’s SHA-256 is `e12decd7c6a555123828642602c106d42eec7989a20ff11ae8f49457263c92cf`. Across Phase 1, **62 of 65 checks passed**; the three failures are this same mode comparison at the final, baseline, and v2-first endpoints.

## A01–A18 register

The Phase 1 stop barred source judgment. For every unreviewed row below, there is **no source path:line evidence**, the evidence class is **limit**, and source-finding severity is **unassessed**. Phase 1 checksum or package observations do not establish the listed contract.

| Row | Required review                                       | Coverage                                                                            |
| --- | ----------------------------------------------------- | ----------------------------------------------------------------------------------- |
| A01 | Authority split and effect ceiling                    | Unperformed                                                                         |
| A02 | P0 grammar, SQL, uniqueness, replay, recovery         | Unperformed                                                                         |
| A03 | Migration 0006 preservation                           | Byte preservation checked; semantic and compatibility review unperformed            |
| A04 | Decision Basis v1/v2 versioning                       | Unperformed                                                                         |
| A05 | Typed disposition durability, privacy, evidence owner | Unperformed                                                                         |
| A06 | Candidate-classification owner and finite mapping     | Unperformed                                                                         |
| A07 | `expected_branch` exact type and nonauthority         | Unperformed                                                                         |
| A08 | Noncircular replan identity vector                    | Unperformed                                                                         |
| A09 | Migration 0007 and compatibility                      | Checksum checked; SQL and schema review unperformed                                 |
| A10 | Five-branch reducer and branch rows                   | Unperformed                                                                         |
| A11 | Fresh P1 transaction, CAS, readback                   | Unperformed                                                                         |
| A12 | Historical program/work-head witnesses                | Unperformed                                                                         |
| A13 | F01 durable replay, readback, recovery                | Unperformed                                                                         |
| A14 | Receipt graph, collisions, competing families         | Unperformed                                                                         |
| A15 | P1 recovery classifications                           | Unperformed                                                                         |
| A16 | Connected physical composition                        | Unperformed                                                                         |
| A17 | Shared writer/session/controller regressions          | Unperformed                                                                         |
| A18 | Documentation, assurance, artifacts                   | ZIP safety checked; documentation, secret-content, and assurance review unperformed |

**Findings by type and severity:** one material provenance blocker, the OS-mode/member mismatch above. No source or runtime finding is asserted because those phases were not reached.

## Execution and retained evidence

No causal test command was run, so there is no test environment, injection-point outcome, or source binding to credit. All eleven requested causal controls remain unperformed: the five-reason F01 matrix; productive and nonconclusive blocks; tamper, foreign-basis and detached-value cases; the exact `expected_branch` gate; five physical branches; CAS and readback rollback; second-replan historical replay; graph, collision, partial-family, winner and uncertainty cases; the P0 matrix and three recovery classes; connected composition; and disk migration and prefix refusal.

Selector-free collection and FULL execution were not run. Independent collected/executed/JUnit node identities, order, zero-failure conditions, warning inventory, and before/after isolated-copy mode checks are therefore unavailable. The writer-retained **108 direct, 5 connected, 5,796 focused, and 9,438 FULL** figures remain historical implementation evidence and receive no independent execution credit.

[Reopened audit-evidence ZIP](/tmp/rw0-c2-audit-provenance.aWlQQMma/phase1-audit-evidence.zip): **10,914 bytes**, SHA-256 `857e5d447bf1c94e1c367127c489d15da0e74821849b74134086f9c77210ad1f`. Its four regular-file members were reopened; ZIP integrity and its internal size, hash, and mode manifest checked.

This audit used only the three named inputs and audit-authored inspection code. It did not access a live repository or network, execute supplied helpers, extract or edit candidate source, stage, commit, publish, migrate a user database, or perform a product effect.
