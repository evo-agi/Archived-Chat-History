OBJECTIVE

Perform the separately governed live exact-byte commit gate for the independently
accepted RW0-C2 P0→P1 disclosure/eligibility-split candidate.

This is a commit gate in the SAME write-enabled implementation Codex conversation
that produced the current uncommitted candidate. It is not an implementation,
repair, status-normalization, publication, or merge engagement.

The only authorized repository mutation is:

1. stage the exact independently accepted source bytes;
2. validate the exact staged tree from an isolated copy;
3. create one local commit.

Do not edit any source, document, test, migration, manifest, mode, or generated
artifact. Any byte change returns the work to implementation and fresh audit.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

AUDITED SUBJECT

Independent artifact-audit disposition:

`RW0_C2_P0_P1_DISCLOSURE_ELIGIBILITY_SPLIT_CUMULATIVE_ARTIFACT_AUDIT_ACCEPTED_READY_FOR_COMMIT_GATE`

Acceptance applies only to:

- Git-compatible source tree:
  `161ed4b544baf970cc26428b9805a106ea0f3edf`
- source paths:
  `315`
- source-manifest SHA-256:
  `f6dae8199c9050d80d2d8644be49b6cb88219dc44c21abb2ce469797fabe5a19`
- integrated baseline tree:
  `15461a58da8df9ebd63fce734d39a07a50ab87ac`
- baseline recorded squash commit / expected HEAD:
  `4519630d0db967066beb21b4ace5004e76827716`
- baseline sole parent:
  `eac7f6df5f281138dd0640c5cd47b9924c8390f8`
- exact baseline-to-final source classification:
  `57 modified, 16 created, 0 deleted, 242 unchanged`.

The audit independently completed source review, real-writer controls, SQL
application, connected five-branch execution, selector-free collection, and a
9,473-test FULL run. It found no material candidate defect. F03 and F05 remain
explicit nonblocking observations.

FIXED IMPLEMENTATION INPUTS

The implementation conversation should already contain these exact deliverables
at its retained task-owned paths:

1. Cumulative review ZIP:
   `/tmp/rw0-c2-physical-40tugs82/disclosure-eligibility-split-repair/rw0-c2-p0-p1-disclosure-eligibility-split-uncommitted-review.zip`
   - bytes: `46,907,085`
   - SHA-256:
     `dfedb7456ecc67622594000668314a002e3c38a4a5b754e2e261ee917cefd8e4`

2. Standalone implementation report:
   `/tmp/rw0-c2-physical-40tugs82/disclosure-eligibility-split-repair/IMPLEMENTATION_REPORT.md`
   - bytes: `20,337`
   - SHA-256:
     `e10eb7b29fdf720b3e707bdf868b7c4143a8f76ad89e54bd362ac5c8019d1d4e`

3. Delivery receipt:
   `/tmp/rw0-c2-physical-40tugs82/disclosure-eligibility-split-repair/DELIVERY_RECEIPT.json`

Do not regenerate or repackage these inputs. If a required local input is absent,
stop. Do not substitute a Downloads namesake or another historical package.

NEW AUDIT INPUTS ATTACHED TO THIS GATE MESSAGE

Require both:

1. `RW0_C2_P0_P1_DISCLOSURE_ELIGIBILITY_SPLIT_AUDIT_ACCEPTANCE_REPORT.md`
   - bytes: `15,501`
   - SHA-256:
     `35908e522a97806f8902669aab450bfba04a665e0f9d4fd83c64587c486feeb3`

2. `rw0-c2-cumulative-audit-evidence.zip`
   - bytes: `902,075`
   - SHA-256:
     `c174042b6a39d1680a21ef266661b41411eb6cdcf50297ea96d77fad5fc2adad`
   - reported members: `63` regular unencrypted files.

The audit report must contain the exact primary disposition and accepted tree
above. The evidence ZIP must pass safe central-directory inspection and contain
the audit-authored authentication, A01–A20, causal, SQL, connected, collection,
FULL, reconciliation, and effect records referenced by the report.

If either audit attachment is unavailable or has a different identity, stop with:

`RW0_C2_P0_P1_COMMIT_GATE_BLOCKED_AUDIT_ARTIFACT_IDENTITY`

Do not infer acceptance from the implementation report alone.

OPENING EFFECT DISCIPLINE

Before any ordinary Git command:

1. Copy `.git/index` byte-for-byte to a private, task-owned external evidence
   directory and record size, SHA-256, metadata, and filesystem identity.
2. Record the repository root and `.git` resolution without modifying either.
3. Set read-only Git observation posture where supported:
   - `GIT_OPTIONAL_LOCKS=0`
   - `GIT_NO_REPLACE_OBJECTS=1`
   - deterministic locale.
4. Do not run cleanup, reset, checkout, switch, rebase, stash, fetch, pull, or
   configuration mutation.

Then authenticate:

- branch:
  `codex/rw0-c2-p0-p1-physical-program-v1`
- HEAD:
  `4519630d0db967066beb21b4ace5004e76827716`
- HEAD tree:
  `15461a58da8df9ebd63fce734d39a07a50ab87ac`
- local `trunk_dev`:
  `4519630d0db967066beb21b4ace5004e76827716`
- local `origin/trunk_dev`:
  `4519630d0db967066beb21b4ace5004e76827716`
- upstream:
  absent
- staged and unmerged entries:
  none
- stage-zero semantic index:
  exactly the 299 baseline entries, modes, and blob OIDs from HEAD
- working source:
  exactly 315 regular source paths
- worktree classification:
  exactly 57 tracked modifications, 16 untracked creations, zero deletions,
  zero renames, and 242 unchanged baseline paths
- complete working source tree:
  `161ed4b544baf970cc26428b9805a106ea0f3edf`
- complete source manifest:
  `f6dae8199c9050d80d2d8644be49b6cb88219dc44c21abb2ce469797fabe5a19`
- tracked full-index binary diff:
  `215,570` bytes
- tracked diff SHA-256:
  `80d5b98cb04e8ecd7a5f60bbd6274d8fac966a9d964ddfe29db941a90b78b17b`
- semantic index SHA-256 retained by implementation:
  `377904010960fb2b7fdaf5caf8eb6135880a1ba85f1e86be9841795430f76f21`
- configuration SHA-256:
  `8cec84aeea4df3bd9701b05835eb36cf4038c8c116f539f60b0df685f956beca`
- migration 0006:
  `58b2731d52e8e199c010b309a29aa831ffb16d4db4e755d20adb694ce0a7305f`
- migration 0007:
  `505d72c9c54f68e248bebab928e76564d45b853068b8b4021ebc708b640e430c`.

RAW INDEX TREATMENT

The implementation closeout observed raw-index SHA-256:

`ff0440db74511629c310a0b1a49000b56fddcaf7464334d892a4a252fa2221bb`

Compare the pre-Git opening copy with that value.

- If it matches, retain exact continuity for this field.
- If it differs but the complete semantic index is exactly the 299-entry HEAD
  index with no staged/unmerged entry, do not reset or rewrite it. Record the
  unexplained pre-gate metadata transition as a historical limit, freeze the
  actual opening raw index as the prospective gate anchor, and proceed only if
  every source, configuration, ref, branch, HEAD, path, mode, and artifact check
  passes.
- Any semantic index difference, staged entry, unmerged entry, or source
  selection ambiguity is blocking.

REF POLICY

Use the accepted v5 authoritative-versus-diagnostic policy.

Qualified diagnostic refs are only direct refs whose names begin with exactly:

- `refs/codex/turn-diffs/captures/`
- `refs/codex/turn-diffs/checkpoints/`

Everything else is authoritative.

Require:

- complete authoritative opening map SHA-256:
  `95f651b2ff1cf21007e1609d789a94bb104d748d3e2174441d45b5f58b641d2c`
- no replace ref, graft, alternate object database, extra worktree, unexpected
  symbolic ref, or source-selection dependency;
- each current diagnostic ref is direct and resolves to an existing commit or
  tree;
- no source, test, validation, migration, package, policy, or publication input
  depends on a diagnostic ref name or OID.

Retain the complete current diagnostic inventory. Qualified additions/removals
since implementation close are evidence and do not block by themselves.
A surviving diagnostic name may not retarget. Any authoritative delta,
diagnostic retarget, invalid object type, or source-selection dependency blocks.

LIVE SOURCE AND MODE CORRESPONDENCE

Authenticate all 315 live source paths against the accepted package by:

- repo-relative path;
- regular-file type;
- byte count;
- raw SHA-256;
- Git blob OID;
- Git mode;
- numeric POSIX mode.

Require exactly:

- 314 files with accepted `0644` checkout mode and Git `100644`;
- one classified file:
  `tests/test_c2b3_private_atomic_program_initialization.py`
  with:
  - bytes `26,405`;
  - SHA-256
    `e12decd7c6a555123828642602c106d42eec7989a20ff11ae8f49457263c92cf`;
  - Git blob
    `b58f863a608ed9cd0dcdd6aebb63e0afeae312e3`;
  - live checkout mode `0600`;
  - Git mode `100644`.

The artifact audit could not prove the live checkout mode. This gate must.
Stop if that live mode is not exactly 0600; do not chmod it into compliance.

SOURCE FREEZE

Before staging:

- run `git diff --check`;
- reconstruct the complete Git tree independently from all 315 accepted
  path/mode/blob entries;
- require tree `161ed4b544baf970cc26428b9805a106ea0f3edf`;
- capture a complete live source manifest twice from fresh reads and require
  byte-identical results;
- verify the implementation review ZIP, report, embedded report equality,
  audit report, and audit evidence ZIP remain unchanged.

No source edit is authorized to fix any failed check.

STAGING

Stage exactly the 73 accepted changed paths:

- 57 existing tracked modifications;
- 16 accepted additions;
- no deletion, rename, submodule, symlink, executable mode, or other path.

Derive the exact path list from the authenticated accepted source manifest and
baseline comparison. Do not hand-maintain or broaden it.

Requirements:

1. `git add -- <exact accepted paths>` once.
2. No other stage mutation.
3. Staged inventory has exactly 315 stage-zero entries.
4. The 242 unchanged entries equal HEAD.
5. Every staged blob and Git mode equals the accepted manifest.
6. `git diff --cached --check` passes.
7. One and only one successful `git write-tree` returns:

   `161ed4b544baf970cc26428b9805a106ea0f3edf`

Any mismatch blocks the gate. Do not unstage/restage to repair bytes. A failed
precondition before the one authorized write-tree must stop before write-tree.

STAGED-TREE VALIDATION

Create a fresh task-owned external source copy solely from the staged Git tree's
315 blobs.

Apply accepted checkout modes in that copy:

- 314 source files mode 0644;
- the classified test file mode 0600.

Do not import or run from the live checkout.

Record:

- exact tree/blob source construction;
- Python, pytest, and SQLite versions;
- cwd;
- complete argv;
- allowlisted environment;
- source manifest before collection;
- source manifest after collection;
- source manifest before execution;
- source manifest after execution;
- ordered collected IDs;
- ordered executed call IDs;
- ordered JUnit IDs;
- warning inventory;
- stdout, stderr, exits, durations, and cleanup.

Use:

- Python 3.13.4;
- pytest 8.4.1;
- SQLite 3.49.1;
- `PYTHONDONTWRITEBYTECODE=1`;
- `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`;
- no pytest cache provider;
- task-owned HOME, TMPDIR, basetemps, and JUnit path;
- restrictive umask;
- no network;
- no test selector for the final collection/FULL pair.

Run exactly:

1. one selector-free collection;
2. one selector-free FULL execution.

Require:

- 9,473 unique collected IDs;
- 9,473 executed call IDs;
- 9,473 JUnit IDs;
- exact collected/executed/JUnit identity and order;
- ordered-ID SHA-256:
  `de9fd885d375cc9152853ac54b70ab2d725de74f7882ba3fc48f2507c3ac0042`
- 9,473 passes;
- zero failures, errors, skips, xfails, or xpasses;
- exactly three warning records, all the known Python 3.13 multithreaded-fork
  `DeprecationWarning`s at:
  - `test_operation_guard_close_waits_and_retains_authority_until_exit`;
  - `test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang`;
  - `test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock`;
- no other warning;
- all 315 external-copy bytes and numeric modes unchanged.

Do not repair a failure, update an expected count, rerun with a narrower
selection, or omit a failing node. Any failed or interrupted final gate blocks
the commit.

LOCAL COMMIT

Only after every opening, stage, and validation requirement passes:

1. Prepare one exact commit message outside the repository.
2. Create one local commit with exact subject:

   `feat: add RW0-C2 physical admission and progression`

3. The commit must have:
   - sole parent:
     `4519630d0db967066beb21b4ace5004e76827716`
   - tree:
     `161ed4b544baf970cc26428b9805a106ea0f3edf`
4. Verify the raw commit object, complete message bytes, parent, tree, all 315
   blobs/modes, and signature/verification fields if locally available.
5. Do not amend, create a second commit, or move another branch.
6. Keep the topic branch without upstream.
7. Require clean worktree and index after commit.
8. Reauthenticate the classified checkout file remains POSIX mode 0600.
9. Require local and local-remote-tracking `trunk_dev` remain at
   `4519630d0db967066beb21b4ace5004e76827716`.
10. Require all non-topic authoritative refs unchanged from opening.
11. Retain exact authorized topic/HEAD movement as the only repository ref
    mutation.

NO STATUS EDIT IN THIS GATE

The accepted source deliberately contains candidate-era status wording such as
"uncommitted", "pending independent audit", or "unaudited". Changing any of it
would change the audited tree.

Do not edit status wording or its tests in this gate.

After the commit, produce a read-only `STATUS_SUCCESSOR_DEPENDENCY_INVENTORY.md`
outside the repository. It must:

1. identify every current, nonhistorical passage made stale by:
   - independent acceptance of tree `161ed4...`;
   - the new local implementation commit;
2. distinguish historical predecessor/blocked-candidate passages that must remain
   unchanged;
3. identify each direct exact-byte, literal, AST, hash, status, inventory, or
   predecessor-reconstruction consumer;
4. include at least a complete scan of:
   - `AGENTS.md`;
   - `README.md`;
   - `.docs/c2b-durable-development-state.md`;
   - `.docs/c2b2-migration-0002.md`;
   - `.docs/rw0-c2-physical-p0-p1-implementation.md`;
   - `.docs/rw0-c2-private-value-versioning.md`;
   - `.docs/rw0-c2-scope-admission-provisioning-contract.md`;
   - `.docs/sqlite-bootstrap-and-migrations.md`;
   - `.docs/sqlite-operations-and-recovery.md`;
   - `.docs/sqlite-schema-v1.md`;
   - all tests that consume those current passages or complete identities;
5. preserve all nonclaims concerning live custody, external evidence suppliers,
   terminal outcome, executable authority, provider/worker readiness, ES/Bridge,
   product Git effects, service, queue, scheduler, deployment, and autonomous
   operation.

This inventory is evidence for a separately authorized status-successor
implementation. It is not permission to edit.

CLOSEOUT AND RETAINED EVIDENCE

Retain outside the repository:

- exact input identities;
- opening raw and semantic index evidence;
- opening source and mode manifest;
- authoritative and diagnostic ref maps/deltas;
- staged path/blob/mode inventory;
- the sole write-tree stdout and identity;
- collection and FULL command/environment records;
- ordered IDs, JUnit, warnings, logs, source before/after records;
- commit message, raw commit object, parent/tree/blob/mode verification;
- final source/index/ref/config/mode readback;
- status-successor dependency inventory;
- cleanup receipt.

Create one closeout report, one machine-readable result, and one self-excluding
retained-artifact manifest. Reopen and hash-verify every retained deliverable
before removing only task-owned validation and temporary state.

Do not include credentials, raw Git config, private environment dumps, user
databases, caches, `.pyc`, SQLite sidecars, or other unclassified material.

STOP CONDITIONS

Stop without committing if:

- any input identity differs;
- live source or mode differs;
- branch, HEAD, baseline, upstream, configuration, authoritative refs, semantic
  index, or staged state differs;
- an unclassified ref/index transition appears;
- the accepted path set differs;
- write-tree differs;
- validation count/order/outcome/warnings differ;
- validation changes source bytes or modes;
- the classified 0600 mode cannot be proved and preserved;
- a source/status/test edit appears necessary;
- a security, authority, privacy, schema, migration, transaction, or public
  surface would change.

Do not repair during this gate.

EFFECT CEILING

Authorized:

- read-only repository and artifact authentication;
- one exact staging operation for the accepted path set;
- one successful `git write-tree`;
- isolated staged-tree validation;
- one local commit;
- task-owned external evidence and cleanup.

Not authorized:

- source, document, test, migration, mode, or configuration edit;
- branch creation, branch switch, rebase, reset, stash, clean, or cherry-pick;
- fetch, pull, push, upstream creation, PR, merge, auto-merge;
- network or service access;
- provider, worker, ES, Bridge, or product database use;
- deployment, release, terminal persistence, or product effect;
- status-successor implementation.

REQUIRED FINAL RESPONSE

Return one of:

- `RW0_C2_P0_P1_DISCLOSURE_ELIGIBILITY_SPLIT_COMMITTED_LOCALLY_NOT_PUBLISHED`
- `RW0_C2_P0_P1_COMMIT_GATE_BLOCKED_<PRECISE_REASON>`

Include:

- exact opening and final branch/HEAD/tree/upstream;
- new commit SHA, subject, parent, tree, raw-message identity;
- all input identities;
- exact 73-path stage classification;
- sole write-tree result;
- collection/FULL commands and environment;
- 9,473 ID/outcome/warning reconciliation;
- complete committed blob/mode comparison;
- live 0600 mode readback;
- raw-index treatment and limits;
- authoritative/diagnostic ref deltas;
- status-successor dependency inventory path and summary;
- retained artifact paths, sizes, SHA-256 values;
- assumptions, process errors, skipped/unavailable work;
- explicit:
  `PUSH_NOT_PERFORMED`
  `PR_NOT_CREATED`
  `MERGE_NOT_PERFORMED`
  `PUBLICATION_NOT_PERFORMED`
  `DEPLOYMENT_NOT_PERFORMED`
  `PRODUCT_EFFECT_NOT_PERFORMED`
- nonclaims for live authority, terminal truth, production execution, and
  autonomy.

A successful result authorizes no publication. The next step is a separately
reviewed status successor over the local implementation commit.
