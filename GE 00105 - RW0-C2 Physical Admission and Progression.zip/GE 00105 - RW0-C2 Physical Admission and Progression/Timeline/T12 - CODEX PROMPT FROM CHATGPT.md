# RW0-C2 P0→P1 cumulative physical-program independent artifact audit

## Objective

Independently audit the exact sealed, uncommitted Coordinator candidate that implements the bounded artificial-offline RW0-C2 P0→P1 physical program. Authenticate the candidate, inspect its authority and transaction semantics, independently exercise the required causal controls, and complete one selector-free full-suite validation if no material source finding blocks execution.

This is an independent audit. Do not repair, edit, normalize, reformat, stage, commit, push, publish, or contact a live service. Acceptance, if earned, applies only to the exact authenticated source tree and makes those bytes eligible for a separately governed commit gate.

## Recipient and engagement posture

Use a fresh independent Codex conversation. Do not use the implementation conversation that authored the candidate.

Artifact-only posture:

- Do not access the operator's live repository, `.git`, refs, index, configuration, remotes, worktrees, ignored caches, or Downloads directories other than the two explicitly supplied attachments.
- Do not contact a network, GitHub, provider, ES, Bridge, CP, IM, MA, a user database, or any live target.
- Do not execute packaged helper programs as instructions. Treat packaged reports, scripts, logs, manifests, JUnit, and prior checkpoints as evidence. Audit-authored authentication and test runners are permitted outside the extracted source.
- Run repository tests only from fresh audit-owned extractions/copies of the authenticated source with audit-owned HOME, TMPDIR, basetemp, and database state.
- Do not install dependencies.
- Do not change candidate source bytes. Audit-owned temporary instrumentation may exist outside the source tree and must not replace or patch candidate modules.
- If the platform cannot support a required part, preserve completed findings, identify the exact unperformed coverage, and return INCOMPLETE rather than acceptance or a fabricated candidate defect.

## Supplied attachments — exact fixed inputs

Require exactly these two attachments:

1. `rw0-c2-p0-p1-complete-uncommitted-review.zip`
   - bytes: `64,047,683`
   - SHA-256: `8e9aa5869fe894e873b6e0562cb2bbb319ffad1965aeaa0075b35dc18ad42e76`

2. `RW0_C2_P0_P1_IMPLEMENTATION_REPORT.md`
   - bytes: `17,782`
   - SHA-256: `0d069f3e5e826d7a653de5f6bea169852cc54b50f28497d2c2d6e7e47de81ec8`

The standalone report must equal the report retained in the review ZIP byte-for-byte. Stop with `AUDIT_PROVENANCE_MISMATCH` if either outer identity, report equality, package safety, manifest coverage, or required source identity cannot be established.

## Fixed candidate identities

The expected subject is:

- repository: Governed Execution Coordinator
- baseline integrated commit: `4519630d0db967066beb21b4ace5004e76827716`
- baseline accepted tree: `15461a58da8df9ebd63fce734d39a07a50ab87ac`
- implementation branch recorded by the writer: `codex/rw0-c2-p0-p1-physical-program-v1`
- final source path count: `315`
- final Git-compatible source tree: `f6801df592af049a6aaef658f721fc1afe27ad6e`
- changed scope against baseline: `54` modified, `16` created, `0` deleted
- final canonical manifest SHA-256: `4c03bc2963eae334aab0635928dc5c60d8cf0b7b64fb766298f6bc7759d98d64`
- tracked full-index binary diff: `151,441` bytes
- tracked full-index binary diff SHA-256: `23fb4c551638920676a6b13c9a19e91d914070368dfc6f72b8ace4449b34591f`
- provenance recipe SHA-256: `4110b39f8b4750e882dcb9c5812ee8e0bbf86f0a8b254b82a42eae9a9efca593`

Required embedded checkpoint identities:

- P0 checkpoint:
  - tree `fd45f05ff909493ff8984671a02be66d3b48a791`
  - ZIP bytes `4,007,435`
  - ZIP SHA-256 `f17070d682e5304662e157da457a8e14018a1e81966f8a4c05436f3f77151ed0`
- prewriter v2 identity checkpoint:
  - tree `c467361fc4a2bd01b5e67f464f8c8bbc88b4d17b`
  - ZIP bytes `3,289,337`
  - ZIP SHA-256 `cb509cff9c0d0e2673c571ccdf8c87c2d8141b73b737f11c221ef69ac1debe0b`
- connected five-branch checkpoint:
  - final tree `f6801df592af049a6aaef658f721fc1afe27ad6e`
  - ZIP bytes `3,261,074`
  - ZIP SHA-256 `53d48231933e1e62ab6657e38c368d43a4d2abe3a2ab9c5a238990c962544fed`

Required migration identities and cumulative schema claims:

- migration 0006 SHA-256: `58b2731d52e8e199c010b309a29aa831ffb16d4db4e755d20adb694ce0a7305f`
- migration 0007 SHA-256: `bd2b775787ab79f2ceb6970aa53ca4758781f393300a8f454fface2cc040aefa`
- cumulative schema: `74` user tables, `134` triggers, `5` explicit indexes
- every 0006 schema object must remain unchanged in the cumulative 0007 schema
- migration 0006 and the two P0 private production owners must be byte-identical to the reopened P0 checkpoint

Required final writer validation records to authenticate as retained evidence, not independent credit:

- connected: 5 collected / 5 JUnit / 5 passed
- focused: 5,779 collected / 5,779 JUnit / 5,779 passed
- selector-free FULL: 9,421 collected / 9,421 JUnit / 9,421 passed
- zero failures, errors, or skips in each
- three known Python 3.13 multithreaded-`fork()` deprecation warnings in focused/FULL only

## Authentication and scoped provenance

Before correctness review:

1. Inspect both ZIP central directories before extraction. Reject traversal, absolute or ambiguous names, duplicate names after normalization/case folding, links, special files, encryption, unsafe expansion, or manifest incompleteness.
2. Verify every package-manifest-covered member by size, SHA-256, and numeric mode. Reopen required nested ZIPs and verify their own safe-member and complete-manifest rules.
3. Verify standalone/embedded report equality.
4. Identify the candidate source root inside the package. Verify every source path, type, numeric mode, size, SHA-256, and Git blob identity against the supplied source manifest.
5. Independently reconstruct Git-compatible tree `f6801df592af049a6aaef658f721fc1afe27ad6e` from the authenticated source bytes and Git modes.
6. Reconstruct the baseline tree or authenticate the baseline endpoint material supplied in the package. Independently verify exactly 54 modifications, 16 creations, no deletions/renames, and the complete changed-path inventory.
7. Verify the tracked binary diff identity and, when package evidence permits, replay it plus the sixteen creations against authenticated baseline bytes to reproduce the final source.
8. Authenticate the exact provenance-recipe source. Reproduce its deterministic canonical output from inert source/material where possible without accessing a live repository. Distinguish package-internal source binding from historical live index/ref observations.
9. Verify the P0, prewriter-v2, and connected checkpoint identities above. Do not grant their tests current-tree execution credit unless the exact checkpoint source equals the final source where the claim requires it.
10. Preserve the report's disclosed historical provenance limits. Do not infer live-checkout continuity, current refs, or current index state from an artifact-only review.

Any source/package mismatch is `AUDIT_PROVENANCE_MISMATCH`. A missing nonessential historical record may limit a specific claim; it must not be silently reconstructed or generalized into a candidate defect.

## Governing interpretation

The candidate is an artificial offline proof. It may establish P0 physical scope-admission recording and P1 physical five-branch progression-decision behavior over disposable task-owned SQLite state. It does not establish:

- live enrollment or custody supplier conformance;
- production provider or worker readiness;
- ES/Bridge routing;
- executable or product Git authority;
- terminal-outcome persistence;
- deployment, release, service, queue consumer, scheduler, or autonomous operation;
- power-loss-safe durability or resolution of F2;
- resolution of qualified F3/F6/F7, cross-host clock ordering, F03, or historical provenance gaps.

P0 and P1 remain separate durable owners, writers, transactions, receipts, replay paths, and recovery classifiers. A complete P0 fact grants no current authority and implies no P1 decision or acceptance.

## Mandatory cumulative review register

Complete every row below. Use evidence classes such as source inspection, test-design inspection, independent execution, retained record, inference, and limit. Cite exact archive-relative paths and line ranges in the final report.

### A01 — Current contract and authority split

Verify that repository guidance and owning documents accurately distinguish current implementation, bounded artificial proof, later live target, and nonclaims. Confirm that external standing policy/enrollment supply admission evidence; P0 owns only its immutable admission-recording family; P1 owns the later five-branch progression decision; the model/replan proposal is evidence and not branch or durable-identity authority; the guarded SQLite controller supplies fenced mutation mechanics only.

### A02 — P0 closed values, SQL family, and uniqueness

Inspect P0 command, basis, row, result, receipt, selector, replay, and recovery grammars. Verify migration 0006 creates exactly the four intended immutable STRICT families and independently enforces one fact per admission act, lineage, and scope. Enrollment/incarnation/process/custody coordinates must remain checked historical evidence without accidental standalone SQL authority or uniqueness. Check exact replay, changed-command conflict, competing identities, malformed/partial family handling, and no program/P1/acceptance/terminal rows.

### A03 — P0 transaction and three-way recovery

Verify receipt-first replay, fencing before disclosure, global route probes, receipt-last insertion, one commit attempt, cleanup handling, and read-only `committed_exact` / `definitely_not_committed` / `unresolved` recovery. Confirm fragments are neither adopted nor repaired and commands are not automatically retried after uncertainty.

### A04 — Migration 0006/0007 prefix and compatibility

Independently inspect DDL, ordered columns, constraints, FKs, triggers, catalog entries, checksums, application generation, explicit migration behavior, old-binary/newer-history refusal, and fresh initialization. Verify all 0006 schema objects are byte/shape identical in the cumulative schema. Confirm 0007 adds exactly six supplemental tables and twelve immutable guards, no explicit index, with cumulative 74/134/5. Verify ordinary inspection/writer acquisition does not auto-migrate.

### A05 — P1 closed command, basis, row, and graph grammars

Inspect exact built-in-type checks, canonical encoding, bounds, duplicate/unknown-key rejection, bool-as-int rejection, digest preimage order, row self-digests, result projection, relation, graph, receipt, and selector semantics. The decision basis must be closed and typed rather than an opaque extension bag. Repeated coordinates and branch-dependent nullable fields must be exact.

### A06 — Five-branch authority and acceptance-only fact

Verify the finite branch mapping:

- `candidate_acceptance`
- `candidate_repair`
- `attempt_selecting_replan`
- `program_terminal_reject`
- `post_execution_program_block`

Confirm only acceptance creates the immutable acceptance fact. Every branch must use fresh checked P0 admission and guard/currentness evidence. No model recommendation or fixture chooses the branch. No no-write refusal may be represented as a durable block, and unresolved commit uncertainty must remain distinct from either.

### A07 — Noncircular replan identity and unchanged 0002 semantics

Verify the implemented order is acyclic:

version-neutral private template → template digest/safe projection → cognitive proposal projection → decision-basis digest → six branch-neutral preassignments → command digest → Coordinator-derived accepted-intent/work-revision/WorkSpec refs → final unchanged WorkSpecV1 → existing 0002 rows and P1 supplemental rows.

Authenticate the fixed identities retained in the report. Confirm no placeholder/fixed-point construction, caller/model-owned durable refs, change to existing WorkSpecV1 semantics, seventh preassignment, or changed migration-0002 row meaning.

### A08 — Versioned replan historical work-head witness

Inspect relation v2, result v2, and receipt-graph-profile v2. Verify v1 definitions remain historical predecessors. Replan must carry exactly the four historical work-head fields and one exact replan-only graph role; non-replan branches must have all-null/absent equivalents. Acceptance retains only its acceptance role; the three remaining branches retain exactly the ten common roles. Verify canonical typed postimage parsing, field ordering, digest binding, FK/constraint treatment, and no mutable-current-head dependency in historical replay.

### A09 — Fresh P1 writer atomicity and mutable-head CAS

Trace the real fenced writer. For replan, verify immutable rows, program-head CAS, work-item-head CAS, same-transaction readback/type-check of both actual postimages, whole-family and graph verification, receipt-last insertion, capability invalidation, and one commit attempt. Any suppressed/no-op CAS, wrong row count, or readback mismatch must roll back every P1 row and both heads. Inspect all five branch-specific write sets.

### A10 — P1 receipt-first replay, checked readback, and recovery

Verify replay reconstructs the complete immutable family without rerunning cognition and does not require current mutable heads to remain at historical values. `committed_exact` requires the complete exact family; `definitely_not_committed` requires exhaustive absence under exact positive prerequisites; partial, foreign, malformed, competing, or contradictory evidence is `unresolved`. Verify no fragment repair or automatic retry.

### A11 — Second replan and historical completeness

Independently verify the first replan can replay exactly after a later valid second replan advances the current program/work heads. Confirm the retained historical work-head postimage proves the first transaction's physical work-head CAS rather than merely reconstructing an expected value. Ensure first/second identities, memberships, edges, version closures, WorkSpecs, and heads cannot be cross-attached.

### A12 — Collisions, route occupancy, membership, and graph isolation

Inspect all global and family-local route probes, alias/creation checks, unique routes, receipt ownership, membership collision behavior, graph role/cardinality enforcement, and competing complete winner semantics. Verify mutation-ref reuse, changed command, partial family, and foreign route occupancy are classified truthfully and write nothing unless an exact replay exists.

### A13 — Connected P0→D1/D2→Section 41/C1/V22→P1 composition

Trace and independently exercise the complete artificial path. Verify P0 may exist with P1 absent as a complete truthful state. Verify each of the five P1 branches uses the intended checked upstream evidence, with acceptance fact only on acceptance. Confirm no physical terminal-outcome persistence is fabricated and no live/runtime authority is inferred.

### A14 — Shared writer/session/controller and public-surface containment

Review every modification to shared SQLite migration, writer-session, and transaction-controller code. Verify existing operations retain fencing, one-commit, cleanup, recovery, and caller boundaries. Confirm no new public `StateStore`, package export, generic gateway, live caller, network route, or unrelated authority widening. Inspect F1 hot-journal behavior and existing Section 41/C1 operations for regression risk.

### A15 — Documentation and assurance consumers

Inspect all modified guidance and all changed assurance tests. Verify current contract text is accurate, historical predecessor text is preserved where required, exact identity/import/caller/migration guards are succeeded rather than weakened, and former nonimplementation assertions are narrowed only as required by the now-implemented private physical P0/P1 slice. Search the complete final source for omitted direct status, exact-hash, migration-tip, table-count, trigger-count, caller-inventory, import-boundary, or source-inventory consumers.

### A16 — Security, privacy, artifacts, and nonclaims

Verify no secrets, credentials, private evidence values, raw prompts, runtime handles, database contents, or sensitive host material are retained. Classify caches, SQLite artifacts, bytecode, logs, and generated evidence. Confirm tests and implementation use only task-owned synthetic state. Ensure reports/manifests remain evidence, not durable authority.

## Required independent causal execution

After authentication and source review reveal no material blocker, run independent validation from fresh audit-owned copies of the exact authenticated final source. Use the installed compatible Python/pytest/SQLite environment without installation. At minimum:

1. Run an audit-frozen focused selection covering all new P0/P1 contracts, migrations, physical writers, connected tests, shared transaction/session consumers, and directly modified assurance modules.
2. Exercise or independently confirm causal coverage for:
   - P0 fresh commit, exact replay, competing act/lineage/scope identities, partial/foreign family, before/after commit uncertainty, and all three recovery classes;
   - all five P1 physical branches;
   - acceptance fact present only for acceptance;
   - P0 complete with P1 absent;
   - noncircular replan identity vector;
   - replan work-head and program-head CAS no-op/failure and post-CAS readback mismatch with full rollback;
   - second replan advancing current heads while first replay remains exact;
   - relation-v2 witness mutants and branch-nullability violations;
   - graph role omission/addition/swap/cross-attachment;
   - membership/route collision, mutation-ref reuse, partial family, foreign family, and competing complete winner;
   - commit-call failure before and after underlying commit, lost return, cleanup uncertainty, and no hidden retry;
   - connected five-branch P0→D1/D2→Section 41/C1/V22→P1 cases.
3. Do not credit a test merely because it raises. Record the injection seam, reached assertion, persisted row/head effects, and cleanup/recovery result. Credit overlapping controls only at the predicates they actually reach.
4. Then run exactly one selector-free collection and one selector-free FULL execution on a fresh exact source copy. Use:
   - `PYTHONDONTWRITEBYTECODE=1`
   - `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`
   - Python `-B`
   - pytest `-p no:cacheprovider`
   - audit-owned HOME, TMPDIR, basetemp, and JUnit path
5. Expected final inventory: exactly `9,421` unique collected node IDs. Require collection, executed call IDs, and JUnit IDs to match exactly in set and order, unless a precisely explained environment-only difference demonstrates why acceptance cannot be issued.
6. Expected result: `9,421` passes, zero failures/errors/skips. Preserve the three known Python 3.13 multithreaded-`fork()` deprecation warnings without suppressing or upgrading them to passes/failures.
7. Record exact argv, cwd, minimal environment allowlist, runtime versions, exits, stdout/stderr, JUnit, ordered IDs, warnings, and complete source byte/mode inventories before and after each phase.
8. Confirm the source copy remains byte- and mode-identical after validation.

A material source finding may stop later execution. If so, retain the actual reproducer or source proof and state exactly which validation obligations remain unperformed. Do not claim an independent FULL pass from writer records or partial audit execution.

## Audit artifacts and cleanup

Store audit-authored records outside the extracted candidate source. Before reporting:

- retain authentication, tree reconstruction, changed-path, migration/schema, source-review register, causal execution, validation reconciliation, and source-before/after records;
- remove only audit-owned disposable source copies, HOME/TMPDIR/basetemp, databases, journals, WAL/SHM, bytecode, and caches after required evidence is safely retained;
- reopen and hash-verify the final audit report and evidence archive;
- confirm the supplied attachments were not modified.

Do not include credentials, environment dumps, raw user databases, or sensitive private values.

## Required final report

Return one complete report inline and retain a safe audit evidence ZIP. Include:

1. Primary disposition.
2. Exact input/package/source identities and authentication result.
3. Changed-path and baseline reconstruction result.
4. P0/checkpoint/migration-prefix authentication.
5. A01–A16 register with exact source anchors, evidence classes, findings, and limits.
6. Independent causal controls and what each actually proves.
7. Focused and selector-free validation reconciliation.
8. Findings ordered by severity and classified as contract/authority drift, security risk, correctness bug, validation gap, documentation/assurance gap, provenance mismatch, or report-only uncertainty.
9. Exact unperformed coverage, if any.
10. Explicit nonclaims and effect record.

Allowed primary dispositions:

```text
RW0_C2_P0_P1_CUMULATIVE_ARTIFACT_AUDIT_ACCEPTED_READY_FOR_COMMIT_GATE
RW0_C2_P0_P1_CUMULATIVE_ARTIFACT_AUDIT_BLOCKED
RW0_C2_P0_P1_CUMULATIVE_ARTIFACT_AUDIT_INCOMPLETE
AUDIT_PROVENANCE_MISMATCH
```

Acceptance requires all of the following:

- exact package and source authentication;
- no material authority, transaction, migration, security, or correctness finding;
- complete A01–A16 review;
- required causal execution or independently justified equivalent evidence;
- completed independent selector-free 9,421-test FULL pass with exact ID reconciliation;
- unchanged exact source bytes/modes after audit;
- truthful limits and nonclaims.

Acceptance authorizes no repository mutation. It makes exact tree `f6801df592af049a6aaef658f721fc1afe27ad6e` eligible only for a separately governed live exact-byte commit gate.

Required effect record:

```text
CANDIDATE_SOURCE_EDIT_NOT_PERFORMED
LIVE_REPOSITORY_ACCESS_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
MERGE_NOT_PERFORMED
PUBLICATION_NOT_PERFORMED
DEPLOYMENT_NOT_PERFORMED
PRODUCT_EFFECT_NOT_PERFORMED
```
