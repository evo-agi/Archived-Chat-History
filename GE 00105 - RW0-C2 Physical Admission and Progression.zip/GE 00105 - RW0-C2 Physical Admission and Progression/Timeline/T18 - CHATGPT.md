## Disposition

```text
RW0_C2_P0_P1_DECISION_BASIS_V2_REPAIR_REQUIRED
CURRENT_CANDIDATE_UNCHANGED_AND_NOT_COMMIT_ELIGIBLE
```

Codex stopped correctly. The candidate has not changed, and F02/F04 were correctly left untouched after the F01 stop condition fired.

The independent audit had already authenticated exact tree:

```text
f6801df592af049a6aaef658f721fc1afe27ad6e
```

and demonstrated that a valid stale-currentness block can commit a complete family but then fail exact replay, checked readback, and `committed_exact` recovery. Pasted text The audit identified the immediate reconstruction defect—using the final decision reason in both reason positions—and independently exercised the resulting durable failure. Pasted text Pasted text

Codex’s latest diagnostic establishes the deeper cause: **the durable family does not contain enough information to recover `candidate_reason_code`.** Four valid typed candidate evaluations can share the same sealed basis and final stale-currentness block while producing four different candidate reasons. Selecting one during replay would be fabrication.

## Selected correction

I am **not** selecting a result-only `candidate_reason_code` column.

That would make replay possible, but it would leave the decision basis incomplete: the command and its preassignments could still be formed without binding the exact validation and independent-review facts consumed by the reducer.

The correct repair is a **versioned decision-basis successor**:

```text
decision-basis.v1
    historical blocked 21-field predecessor

decision-basis.v2
    same fields
    + exact typed validation_disposition
    + exact typed independent_review_disposition
```

Candidate reason remains derived, not separately caller-supplied or redundantly persisted. Fresh reduction and historical reconstruction must use one shared pure classifier over the two basis-owned dispositions.

This has several important consequences:

- Different valid validation/review outcomes produce different basis digests and therefore different command identities.
- Historical replay can reconstruct the exact candidate reason without caller input, current-state sampling, or rerunning cognition.
- A detached validation/review value that disagrees with the basis is rejected before route probing or writes.
- Migration 0007’s decision-basis schema ID and checksum change, but it remains the same six-table migration with **74 tables, 134 triggers, and five explicit indexes**.
- Migration 0006 and all P0 production bytes remain exact.
- Relation v2, guarded-result v2, receipt-profile v2, the work-head witness, migration-0002 meanings, `WorkSpecV1`, and the six preassignments retain their field shapes.
- The existing identity vector from the basis digest onward is superseded and must be regenerated.

The currently reported design already binds the command, six preassignments, replan-derived refs, result graph, and receipt downstream of the decision basis. It also preserves separate P0/P1 transactions and exact replay as an intended invariant. Pasted text Correcting the durable basis is therefore the owning fix.

## Next Codex handoff

Send **only this prompt** to the **same workspace-write Codex implementation conversation**:

:chatgpt-content-reference{index="5"}[**RW0-C2 P0→P1 Decision Basis V2 repair prompt**](sandbox:/mnt/data/Coordinator_RW0_C2_P0_P1_Decision_Basis_V2_Repair_Prompt.txt)

No attachments are required. Do not send the superseded F01/F02/F04 prompt alongside it.

The continuation requires:

1. Decision-basis v2 with the two exact typed dispositions.
2. A shared pure candidate-classification helper used by fresh reduction and historical readback.
3. Real durable-block fresh/replay/readback/recovery controls across multiple candidate reasons.
4. F02’s exact built-in `str` gate.
5. F04’s migration-tip documentation and semantic assurance correction.
6. A new basis-v2 identity checkpoint.
7. Connected, focused, and selector-free FULL validation on final bytes.
8. One cumulative review package with a standalone implementation report that is byte-identical to its embedded copy.

It explicitly forbids a new table, migration 0008, a redundant caller-supplied candidate reason, changes to P0/migration 0006, staging, commit, publication, network access, or product effects.

```text
Prompt bytes: 19,772
Prompt SHA-256:
840a185350437e403adf362ab728c114a5e6e833a71850dd0142026468a96e5a
```

:chatgpt-content-reference{index="6"}[Prompt identity record](sandbox:/mnt/data/Coordinator_RW0_C2_P0_P1_Decision_Basis_V2_Repair_Prompt_Check.json)

F03 and F05 remain disclosed nonblocking observations. The prior 9,421-pass implementation result remains evidence for the superseded tree only; the audit stopped before independently running the focused or FULL suites. Pasted text

**Sources:** Independent cumulative audit and current implementation report cited above.

**Confidence:** root-cause diagnosis **0.99**; decision-basis-v2 architecture **0.97**; handoff completeness **0.97**. Implementation correctness and independent validation remain unestablished.
