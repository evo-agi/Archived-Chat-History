## Disposition

```text
RW0_C2_P0_P1_COMMAND_IDENTITY_AND_PROTECTED_DISCLOSURE_REPAIR_REQUIRED
CANDIDATE_UNCHANGED_AND_NOT_COMMIT_ELIGIBLE
```

The corrected provenance gate passed for exact tree:

```text
8e247b21320f90d2d2cb98d3d165f7fc35f117a8
```

The earlier OS-mode mismatch remains a valid historical stop under its former rule, but the corrected audit properly distinguishes Git/ZIP mode `100644` from the retained checkout observation `0600`. It then reached substantive review and reproduced two material defects through the real private writer. Pasted text

### F1 — `expected_branch` is not part of exact command identity

The type and finite-vocabulary checks work, but changing only `expected_branch` leaves the command digest unchanged. A changed assertion can therefore receive the original committed result and `committed_exact` recovery instead of being treated as a changed command. Pasted text

The selected correction is a **guarded-command-digest v2**, not a new SQL command schema:

```text
guarded-command-digest.v1
    historical 30-pair predecessor

guarded-command-digest.v2
    same 30 ordered relation pairs
    + exact optional expected_branch
```

Key decisions:

- The migration-0002 command schema remains `...record-development-progression-decision-command.v1`.
- The six branch-neutral preassignments remain unchanged and continue to exclude `expected_branch`.
- The complete command digest includes `expected_branch` as JSON `null` or one exact branch string.
- Every durable P1 use moves from the relation-only digest to the complete command-level digest.
- Changing only the assertion preserves the preassigned routes but changes the command digest, producing changed-command conflict rather than replay.
- No Decision Basis, relation, result, receipt-graph, table, or migration shape changes.

An internal competing-winner verifier may reconstruct the original assertion only through exact finite digest matching. It must not guess or expose the competitor’s protected result.

### F2 — committed P1 results bypass fresh disclosure posture

The private contract requires fresh positive posture before protected replay or recovery. The implementation currently returns a committed read and `committed_exact` before checking the supplied disclosure source. Pasted text

The selected correction is:

```text
receipt lookup
    → fresh disclosure-posture check
    → exact command-digest association
    → complete immutable-family verification
    → protected result
```

For a fresh receipt miss, recording continues to require recording posture. For an existing receipt, exact replay requires disclosure posture—not renewed recording permission. Denied, expired, malformed, or mismatched disclosure posture must:

- disclose no committed result;
- make recovery return `unresolved`;
- cause no row, receipt, version, program-head, or work-head movement;
- trigger no retry or reconstructed replacement result.

Historical reconstruction still avoids rerunning cognition or resampling historical durable facts. The external source is used only as the current disclosure gate. That resolves the conflict between the stronger private-value contract and the physical document’s “without external source” wording.

## Next Codex handoff

Send **only this prompt** to the **same workspace-write Codex implementation conversation** that produced the Decision Basis v2 candidate:

:chatgpt-content-reference{index="5"}[**RW0-C2 P0→P1 command-digest-v2 and protected-disclosure repair prompt**](sandbox:/mnt/data/Coordinator_RW0_C2_P0_P1_Command_Digest_V2_and_Protected_Disclosure_Repair_Prompt.txt)

No attachments are required. Keep the independent audit conversation idle.

The mandate requires:

- exact opening authentication of tree `8e247b…`;
- command-digest-v2 identity and finite assertion controls;
- real-writer changed-assertion conflict, replay, readback, and recovery cases;
- positive, denied, expired, and mismatched disclosure cases;
- competing-winner reconstruction for both permitted original acceptance assertions;
- preservation of migrations 0006/0007 and the 74/134/5 schema;
- connected five-branch validation;
- focused validation and one selector-free FULL run;
- a newly identified cumulative package for a fresh independent audit.

It authorizes no staging, commit, push, PR, merge, publication, live supplier work, terminal persistence, or product effect.

```text
Prompt bytes: 22,202
SHA-256:
083cd60411b08a897bf5058facd105622dce525907ed96bc0a62cfd2cb686b1e
```

:chatgpt-content-reference{index="6"}[Prompt identity record](sandbox:/mnt/data/Coordinator_RW0_C2_P0_P1_Command_Digest_V2_and_Protected_Disclosure_Repair_Prompt_Check.json)

The audit stopped broad execution after the two findings. The five-branch causal matrix, connected composition, selector-free collection, and independent FULL run therefore remain outstanding; the writer’s earlier 9,438-pass record is still implementation evidence only. Pasted text

**Sources:** corrected cumulative artifact audit; authenticated Decision Basis v2 implementation report, which identifies the current tree, basis-v2 treatment, and retained implementation validation. Pasted text

**Confidence:** provenance and finding diagnosis **0.99**; repair architecture **0.97**; handoff completeness **0.97**. Runtime repair correctness and independent acceptance remain unestablished.
