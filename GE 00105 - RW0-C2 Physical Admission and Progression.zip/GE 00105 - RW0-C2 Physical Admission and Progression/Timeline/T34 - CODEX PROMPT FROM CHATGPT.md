OBJECTIVE

Perform a fresh, independent, artifact-only cumulative audit of the exact
uncommitted RW0-C2 P0→P1 disclosure/eligibility-split candidate.

This is a NEW read-only Codex audit conversation. It is not the implementation
conversation, not a repair engagement, and not a live-repository audit.

Authenticate the sealed inputs, reconstruct the exact source, review the whole
P0→P1 cumulative subject, reproduce the historically material defects and their
repairs, execute the required causal controls, and complete one independent
selector-free collection and FULL run if no material blocker is found.

ATTACH EXACTLY THREE FILES

1. `rw0-c2-p0-p1-disclosure-eligibility-split-uncommitted-review.zip`
   - bytes: `46,907,085`
   - SHA-256:
     `dfedb7456ecc67622594000668314a002e3c38a4a5b754e2e261ee917cefd8e4`

2. `IMPLEMENTATION_REPORT.md`
   - bytes: `20,337`
   - SHA-256:
     `e10eb7b29fdf720b3e707bdf868b7c4143a8f76ad89e54bd362ac5c8019d1d4e`

3. `Coordinator_PostD2_PR16_SquashSourceCheckpoint_20261024.zip`
   - bytes: `3,245,477`
   - SHA-256:
     `087990b15ded609615659c0927f849cf656c4b0cabd6de78339add4410a74166`

Do not request chat history, a Downloads lookup, a live checkout, or another
package. Do not execute any helper program supplied inside the archives.
Audit-authored inspection and isolated test scripts are permitted.

SUBJECT AND EXPECTED IDENTITIES

Current candidate:

- source paths: `315`
- source-manifest SHA-256:
  `f6dae8199c9050d80d2d8644be49b6cb88219dc44c21abb2ce469797fabe5a19`
- Git-compatible source tree:
  `161ed4b544baf970cc26428b9805a106ea0f3edf`

Integrated baseline:

- source paths: `299`
- Git-compatible tree:
  `15461a58da8df9ebd63fce734d39a07a50ab87ac`
- recorded squash commit:
  `4519630d0db967066beb21b4ace5004e76827716`
- sole parent:
  `eac7f6df5f281138dd0640c5cd47b9924c8390f8`

Expected baseline-to-final source comparison:

- 57 modified;
- 16 created;
- 0 deleted;
- 242 unchanged.

Immediate embedded predecessor:

- `evidence/historical/prior-f1f2-review.zip`
- bytes: `33,728,895`
- SHA-256:
  `aa7d22d6df888c0928917939957fc6746c5064c83b75c949360155ab151e39b8`
- predecessor report bytes: `25,174`
- predecessor report SHA-256:
  `ff2691d3c5e74959abbb6a4414af47e99bb045b50a0134d00a42a652487d710b`
- predecessor source tree:
  `58444e6a1c9526a524818e8729398ff0ab381837`
- final repair delta:
  12 modified, 0 created, 0 deleted.

Required historical P0 checkpoint:

- `evidence/historical/p0-checkpoint.zip`
- bytes: `4,007,435`
- SHA-256:
  `f17070d682e5304662e157da457a8e14018a1e81966f8a4c05436f3f77151ed0`
- tree:
  `fd45f05ff909493ff8984671a02be66d3b48a791`.

Required current first checkpoint:

- `evidence/current/rw0-c2-disclosure-eligibility-split-checkpoint.zip`
- bytes: `3,585,833`
- SHA-256:
  `b9c985ef60955791504c7823edf8b383c5c1f30f1b503411f422e5ff47b083e6`
- tree:
  `161ed4b544baf970cc26428b9805a106ea0f3edf`.

PACKAGE AUTHENTICATION

Before source judgment:

1. Verify all three supplied outer identities exactly.
2. Inspect each central directory before reading/extraction:
   - normalized unique relative names;
   - no traversal, links, special files, encryption, or case-fold collision;
   - bounded member and total expansion.
3. Require the current review ZIP to contain exactly 434 regular members.
4. Verify all 433 `package-inventory.json` rows by path, bytes, SHA-256, and
   numeric archive mode; the inventory excludes itself.
5. Require the standalone report to equal
   `evidence/IMPLEMENTATION_REPORT.md` byte-for-byte.
6. Authenticate every final source row by path, size, SHA-256, Git blob, and Git
   mode, then reconstruct the exact final Git tree.
7. Authenticate and reconstruct the integrated baseline tree.
8. Independently compare baseline to final and replay the retained full-index
   binary diff where feasible.
9. Authenticate the embedded predecessor and P0/current checkpoints before
   relying on them.
10. Verify exact 12-path immediate repair scope and every before/after endpoint.
11. Verify the two final and post-cleanup captures are byte-identical and their
    source entries equal the authenticated final source.
12. Verify migrations:
    - 0006 SHA-256
      `58b2731d52e8e199c010b309a29aa831ffb16d4db4e755d20adb694ce0a7305f`
    - 0007 SHA-256
      `505d72c9c54f68e248bebab928e76564d45b853068b8b4021ebc708b640e430c`.

MODE EVIDENCE — DO NOT REPEAT THE FORMER HANDOFF ERROR

ZIP source members intentionally use Git mode. Source manifests separately
retain observed checkout POSIX mode.

Require:

- 314 final source rows:
  `os_mode=0644`, `git_mode=100644`;
- exactly one classified row:
  `tests/test_c2b3_private_atomic_program_initialization.py`
  with:
  - bytes `26,405`;
  - SHA-256
    `e12decd7c6a555123828642602c106d42eec7989a20ff11ae8f49457263c92cf`;
  - Git blob
    `b58f863a608ed9cd0dcdd6aebb63e0afeae312e3`;
  - `os_mode=0600`;
  - `git_mode=100644`;
  - ZIP wrapper mode `100644`.

This is an intentional two-namespace record, not a mismatch. State that an
artifact-only audit authenticates bytes/Git mode and historical mode evidence,
but cannot prove the current live checkout's POSIX mode. A later live commit
gate must reauthenticate it.

PROVENANCE EVIDENCE TREATMENT

The review package records a prospective v5 interval. Treat its branch, index,
configuration, authoritative-ref, diagnostic-ref, and checkout observations as
retained implementation evidence, not live observations.

Require internal consistency of:

- v5 recipe SHA-256:
  `11f2d430cc0147fc602bafc6a2c7143f13c10e31c137664a4c32dc25ce126383`;
- byte-identical final/post-cleanup capture SHA-256:
  `ea1535b825d79937a3faf79c48d0817586dcb6a55b412321de389b4a0831a092`;
- authoritative-ref map SHA-256:
  `95f651b2ff1cf21007e1609d789a94bb104d748d3e2174441d45b5f58b641d2c`;
- 18 qualified diagnostic refs with no opening-to-close addition, removal, or
  surviving-name retarget.

Do not claim live Git continuity. Preserve the historical v4/full-ref and
checkout-mode limits.

CUMULATIVE REVIEW REGISTER

Complete one source-grounded A01–A20 register. Every material claim needs exact
archive-relative path:line evidence and an evidence class.

A01. Authority split, artificial-offline scope, effect ceiling, and nonclaims.

A02. Baseline/final provenance, exact delta, checkpoints, modes, and artifact
hygiene.

A03. P0 values, four-table SQL family, independent act/lineage/scope uniqueness,
writer, replay, checked readback, and three-way recovery.

A04. Migration 0006 preservation, historical 68-table/122-trigger/5-index
prefix, migration-only upgrade, old/partial/unknown-state refusal.

A05. Decision Basis v1/v2: exact 23-field current grammar, typed
validation/review dispositions, canonical encoding, privacy, bounds, and shared
candidate-classification owner.

A06. Guarded-command-digest v1/v2: exact 30/31-pair profiles,
`expected_branch` exact type/vocabulary, unchanged six sibling
preassignments, and complete durable call-site use.

A07. Universal current posture versus acceptance-only eligibility:
- continuity;
- sole-active authority;
- no foreign claim;
- time;
- recording/disclosure permission;
- claimed-status type handling;
- acceptance-only true/true check.

A08. Five branch reducer, matrix/currentness treatment, model
nonauthority, and acceptance-only fact.

A09. Noncircular replan template/proposal/basis/preassignment/command/derived
revision/WorkSpec identity chain and unchanged migration-0002 meanings.

A10. Relation/result/receipt-profile v2, historical program/work-head witnesses,
branch role counts, and exact graph closure.

A11. Fresh P1 writer fencing, P0/current-owner reads, route probes, immutable
inserts, program/work-head CAS and readback, receipt-last, capability
invalidation, and one commit attempt.

A12. Receipt-present exact replay/read:
- fresh universal disclosure first;
- command-digest-v2 association;
- complete historical reconstruction;
- no fresh acceptance reevaluation;
- no current mutable-head dependency.

A13. Receipt-absent recovery:
- `committed_exact`;
- exhaustive `definitely_not_committed`;
- partial/foreign/malformed/contradictory `unresolved`;
- complete competing acceptance winner;
- claimed false without a local complete winner;
- no retry permission or winner disclosure.

A14. Collisions, mutation-ref reuse, family routes, aliases, membership,
partial-family, graph mutants, and competing-family isolation.

A15. Shared writer/session/controller, transaction timestamp plumbing,
commit/cleanup uncertainty, process-control exceptions, and preservation of F1
hot-journal behavior.

A16. Connected P0→D1/D2→Section 41/C1/V22→P1 composition for all five branches.

A17. Documentation/code/test alignment and direct exact-hash/AST/status consumers.

A18. Security/privacy: no raw private replan text, source evidence, credentials,
paths, process data, or live authority in durable projections or artifacts.

A19. Retained nonblocking observations:
- F03 target-only P0 selector/wrapper gap;
- F05 P0 timestamp-before-collision error-precedence difference.
Confirm their scope or upgrade them only with source/runtime evidence.

A20. Validation completeness, warning classification, failed/superseded attempt
noncredit, and exact final-source binding.

HISTORICAL DEFECTS THAT MUST BE REPRODUCED OR EXPLICITLY CLOSED

Do not accept solely because writer tests exist. Independently exercise the real
private writer/session/controller path.

1. Candidate-reason durability:
   - multiple typed validation/review combinations under a stale-currentness
     block;
   - exact fresh result, replay/readback, and `committed_exact` recovery;
   - no durable movement on replay.

2. Command identity:
   - commit acceptance with `expected_branch=None`;
   - change only to `candidate_repair` and another wrong valid branch;
   - same sibling preassignments but different command digest;
   - record conflict, no protected read, unresolved recovery, no durable
     movement;
   - exact replay for the two valid committed-acceptance assertions.

3. Protected disclosure:
   - denied/expired/negative/mismatched/malformed universal posture returns no
     committed result and unresolved recovery;
   - process-control exceptions propagate.

4. Disclosure/eligibility split:
   - commit acceptance with current unclaimed true, then replay/read/recover
     under truthful current false, disclosure true, recording false;
   - repeat for one committed nonaccept family;
   - fresh acceptance with false and with none yields the existing guard
     conflict and zero writes;
   - fresh nonaccept under false reaches its derived branch;
   - complete competing winner under false proves the distinct original command
     definitely did not commit without winner disclosure;
   - false with no complete local winner is unresolved;
   - none with exhaustive local absence retains the ordinary absence class.

5. Replan and atomicity:
   - all five branches;
   - second-replan historical first-family replay;
   - both mutable-head CAS no-op/wrong-count and post-CAS readback mismatch;
   - complete rollback;
   - historical work-head witness and graph-role mutants.

6. P0 and recovery:
   - fresh, exact replay, collision, malformed/partial/foreign families;
   - commit-before/after/lost-return/cleanup uncertainty;
   - all three recovery classes;
   - P0 complete with P1 absent.

7. Connected composition:
   - actual bounded P0→D1/D2→Section 41 A→C1 B→V22→P1 for all five branches.

INDEPENDENT EXECUTION

After provenance and source review, run targeted audit-authored controls. If a
material finding is established, stop broad execution and report exact
unperformed coverage.

If no material blocker remains:

1. run the connected five-branch selection;
2. run one selector-free collection;
3. run one selector-free FULL execution from a fresh audit-owned copy of the
   exact authenticated source.

Expected final inventory:

- `9,473` unique collected IDs;
- `9,473` executed/JUnit IDs in exact order;
- `9,473` passes;
- zero failures, errors, or skips;
- exactly the independently observed warning inventory.

Also independently apply all seven authenticated SQL files to audit-owned
SQLite state and verify:

- after 0006: 68 tables, 122 triggers, 5 explicit indexes;
- after 0007: 74 tables, 134 triggers, 5 explicit indexes;
- application generation 2;
- no foreign-key failure;
- every 0006 schema object unchanged in the 0007 cumulative state.

Use a clean audit-owned environment, no network, no installation, no user
database, no live repository, and no supplied helper execution. Record exact
argv, cwd, allowlisted environment, runtime versions, exits, logs, ordered IDs,
JUnit, warnings, and before/after source bytes/modes.

FINAL DISPOSITION

Return exactly one primary disposition:

- `RW0_C2_P0_P1_DISCLOSURE_ELIGIBILITY_SPLIT_CUMULATIVE_ARTIFACT_AUDIT_ACCEPTED_READY_FOR_COMMIT_GATE`
- `RW0_C2_P0_P1_DISCLOSURE_ELIGIBILITY_SPLIT_CUMULATIVE_ARTIFACT_AUDIT_BLOCKED`
- `AUDIT_PROVENANCE_MISMATCH`
- `RW0_C2_P0_P1_DISCLOSURE_ELIGIBILITY_SPLIT_CUMULATIVE_ARTIFACT_AUDIT_INCOMPLETE`

Acceptance applies only to exact tree
`161ed4b544baf970cc26428b9805a106ea0f3edf` and grants eligibility only for a
separately governed live exact-byte commit gate.

EFFECT CEILING

Prohibited:

- candidate source edit or repair;
- live repository or `.git` access;
- network/service/provider/ES/Bridge contact;
- user or product database access;
- staging, commit, push, PR, merge, publication, deployment, or product effect;
- execution of supplied package helpers.

Allowed:

- inert archive inspection;
- audit-authored scripts;
- isolated repository test execution against extracted exact source;
- task-owned temporary SQLite state;
- safe audit evidence/report generation outside the supplied inputs.

REQUIRED RETURN

Return one complete inline report plus one reopened safe audit-evidence ZIP.
Include:

- all fixed identities and reconstructed trees;
- exact delta and mode treatment;
- A01–A20 register;
- findings by severity/type;
- exact independent commands and causal outcomes;
- selector-free collection/FULL reconciliation;
- SQL/schema results;
- artifact-only live-state limitations;
- unperformed coverage;
- explicit effect record.

Do not convert a platform refusal, unavailable execution capability, or audit
process error into a candidate defect or acceptance. Preserve completed
findings and return INCOMPLETE with exact missing coverage.
