Here is Codex's response:

# RW0-C2 P0→P1 independent artifact audit

**Primary disposition: `RW0_C2_P0_P1_CUMULATIVE_ARTIFACT_AUDIT_BLOCKED`**

The corrected two-input gate passed, and the exact candidate source tree authenticated. An independent isolated run then found a material P1 defect: a valid stale-currentness block commits a complete durable family, but the same command cannot replay it exactly. Readback fails, and recovery calls the committed family `unresolved`. This tree is **not eligible for the separately governed commit gate**.

The earlier [`AUDIT_PROVENANCE_MISMATCH` report](/private/tmp/rw0-c2-independent-auth-2xjzjifr/RW0_C2_P0_P1_INDEPENDENT_AUDIT_REPORT.md) remains the truthful result under the former embedded-report requirement. Under the corrected gate, the standalone report is a separate evidence input; its absence from the ZIP is not a mismatch.

The complete report is retained at [RW0_C2_P0_P1_CORRECTED_CUMULATIVE_AUDIT_REPORT.md](/private/tmp/rw0-c2-independent-auth-2xjzjifr/RW0_C2_P0_P1_CORRECTED_CUMULATIVE_AUDIT_REPORT.md), SHA-256 `1fa0039e9e649b169b8533f5f899bc6798632105e9a7883a9fc93e7f3b302533`. The reopened and member-verified [audit evidence ZIP](/private/tmp/rw0-c2-independent-auth-2xjzjifr/RW0_C2_P0_P1_CORRECTED_CUMULATIVE_AUDIT_EVIDENCE.zip) has SHA-256 `b985b64c336b72c8dbc901e4147093e90513f605d6b666bcc5533f128d290034`.

## Authentication and provenance

| Input or endpoint | Independent result |
| --- | --- |
| Review ZIP | Exact 64,047,683 bytes; SHA-256 `8e9aa5869fe894e873b6e0562cb2bbb319ffad1965aeaa0075b35dc18ad42e76`. |
| Standalone implementation report | Exact 17,782 bytes; SHA-256 `0d069f3e5e826d7a653de5f6bea169852cc54b50f28497d2c2d6e7e47de81ec8`. |
| Final source | 315 paths; canonical manifest SHA-256 `4c03bc2963eae334aab0635928dc5c60d8cf0b7b64fb766298f6bc7759d98d64`; independently reconstructed Git tree `f6801df592af049a6aaef658f721fc1afe27ad6e`. |
| Baseline endpoint | Reconstructed 299-path Git tree `15461a58da8df9ebd63fce734d39a07a50ab87ac`. |
| Change | Exactly 54 modified, 16 created, 0 deleted. The 151,441-byte tracked binary diff hashes to `23fb4c551638920676a6b13c9a19e91d914070368dfc6f72b8ace4449b34591f`; forward replay plus the 16 creations reproduced every final source byte and Git mode. |

The 452-member outer central directory passed name, duplicate, path, link, special-file, encryption, and expansion checks. All 451 package-manifest-covered members passed size and SHA-256 verification, with numeric ZIP modes checked. Every source member passed path, type, size, SHA-256, Git blob, and Git-mode checks. The three required nested checkpoints passed their safe-member and complete-manifest checks. The complete modified and created path lists and the member ledger are in the evidence ZIP.

One mode distinction is recorded: `source/tests/test_c2b3_private_atomic_program_initialization.py` has source-manifest OS mode `0600`, while its ZIP wrapper carries Git mode `100644`. The inert packaging recipe at `evidence/current/create_review_package_v1.py:89-93,102-108` specifies that wrapper behavior. The artifact authenticates its Git mode and bytes; the historical checkout’s OS mode remains a manifest claim.

| Required checkpoint | ZIP identity | Reconstructed tree |
| --- | --- | --- |
| `evidence/historical/p0-checkpoint.zip` | 4,007,435 bytes; `f17070d682e5304662e157da457a8e14018a1e81966f8a4c05436f3f77151ed0` | `fd45f05ff909493ff8984671a02be66d3b48a791` |
| `evidence/current/v2-work-head-identity-checkpoint.zip` | 3,289,337 bytes; `cb509cff9c0d0e2673c571ccdf8c87c2d8141b73b737f11c221ef69ac1debe0b` | `c467361fc4a2bd01b5e67f464f8c8bbc88b4d17b` |
| `evidence/current/connected-p0-d2-section41-c1-v22-p1-checkpoint.zip` | 3,261,074 bytes; `53d48231933e1e62ab6657e38c368d43a4d2abe3a2ab9c5a238990c962544fed` | `f6801df592af049a6aaef658f721fc1afe27ad6e` |

Migration 0006 hashes to `58b2731d52e8e199c010b309a29aa831ffb16d4db4e755d20adb694ce0a7305f`; 0007 hashes to `bd2b775787ab79f2ceb6970aa53ca4758781f393300a8f454fface2cc040aefa`. The 0006 SQL and both P0 private production modules are byte-identical to the P0 checkpoint. Independent in-memory application of authenticated SQL through 0007 produced **74 user tables, 134 triggers, and 5 explicit indexes**. Migration 0007 added six tables and twelve immutable guards, with no explicit index; every 0006 schema object retained its SQL and shape.

The provenance recipe source hashes to `4110b39f8b4750e882dcb9c5812ee8e0bbf86f0a8b254b82a42eae9a9efca593`. An audit-authored reconstruction repeated its deterministic canonical source-manifest output three times and matched the 80,986-byte manifest and its fixed SHA-256. The packaged recipe was inspected, not executed. The baseline commit label `4519630d0db967066beb21b4ace5004e76827716` and historical branch, ref, index, configuration, and checkout observations cannot be authenticated as live state from these attachments.

## A01–A16 review register

All paths and line ranges below are **relative to `source/` in the review ZIP**. SI means source inspection, TD test-design inspection, IE independent execution, and L a stated limit. Inspected tests receive no execution credit.

| Row | Evidence and finding |
| --- | --- |
| **A01 — authority split** | **SI:** `AGENTS.md:1087-1111`; `.docs/authority-boundaries.md:475-495`; `.docs/rw0-c2-physical-p0-p1-implementation.md:1-31,158-212`. The bounded artificial proof separates external policy/enrollment evidence, P0 recording, P1 decision, model proposal, and fenced SQLite mechanics. No live supplier authority is established. |
| **A02 — P0 grammar and SQL** | **SI/TD:** `src/ge_nwp_coordinator/_rw0_c2_scope_admission_contracts.py:15-132,176-243`; `src/ge_nwp_coordinator/sqlite_migrations/0006_rw0_c2_scope_admission.sql:1-106`; `tests/test_sqlite_rw0_c2_scope_admission.py:96-128`. Four immutable STRICT families and separate act, lineage, and scope uniqueness are present; historical enrollment/incarnation/process/custody coordinates have no standalone SQL uniqueness. The earlier target selector-digest and closed wrapper grammar at `.docs/rw0-c2-scope-admission-provisioning-contract.md:120-164` is not fully implemented by this private successor. That document labels the earlier machine target-only at `:3-9` and describes the bounded successor at `:321-341`. No authorization bypass was reproduced. |
| **A03 — P0 transaction and recovery** | **SI/TD:** `src/ge_nwp_coordinator/_sqlite_rw0_c2_scope_admission.py:33-65,125-264`; `src/ge_nwp_coordinator/sqlite_transition_transaction.py:1168-1271,3060-3145`; `tests/test_sqlite_rw0_c2_scope_admission.py:287-366`. Source uses receipt-first fenced replay, global route checks, receipt-last insertion, one commit attempt, and read-only exact/absent/unresolved recovery without fragment repair or hidden retry. Independent P0 injections remain unrun. The physical path chooses time at `sqlite_transition_transaction.py:1213` before the fresh collision probe, reversing the earlier target order at `.docs/rw0-c2-scope-admission-provisioning-contract.md:222-229`. |
| **A04 — migrations** | **SI/IE/TD:** `src/ge_nwp_coordinator/sqlite_migration.py:31-43,431-502,722-963,1441-1483,2401-2415`; `src/ge_nwp_coordinator/sqlite_migrations/0006_rw0_c2_scope_admission.sql:1-106`; `src/ge_nwp_coordinator/sqlite_migrations/0007_rw0_c2_progression_decision.sql:1-222`. Catalog, explicit administration, compatibility refusal, and zero seeds were inspected. Independent SQL execution verified the exact 0006 prefix and 74/134/5 cumulative count; disk migration and old-binary refusal were not independently run. |
| **A05 — P1 grammars** | **SI/TD/IE:** `src/ge_nwp_coordinator/_rw0_c2_progression_contracts.py:60-82,125-225,465-528,616-720`; `src/ge_nwp_coordinator/_rw0_c2_progression_rows.py:28-96,109-212`. The basis has 21 typed roles with canonical bounded encoding, ordered preassignments, and self-digested rows. A pure probe found that optional `expected_branch` accepts an equality-overriding `str` subclass instead of requiring exact built-in `str`; its mismatch comparison was bypassed. No durable call used that input. |
| **A06 — five branches** | **SI/TD/IE:** `src/ge_nwp_coordinator/_rw0_c2_progression_contracts.py:795-952`; `src/ge_nwp_coordinator/_rw0_c2_progression_plan.py:25-36,437-558`; `tests/test_sqlite_rw0_c2_progression.py:123-144`. Source derives the five branches from checked inputs, with an acceptance fact only on acceptance; the model proposal does not choose the branch. The independently run stale-currentness block committed without acceptance but later failed replay. The other physical branches were not independently run. |
| **A07 — replan identity** | **SI/TD/IE:** `src/ge_nwp_coordinator/_rw0_c2_progression_contracts.py:93-148,269-462,616-660`; `src/ge_nwp_coordinator/_rw0_c2_progression_plan.py:193-404`; `.docs/rw0-c2-physical-p0-p1-implementation.md:87-100`. The template → projection/proposal → basis → six preassignments → command → Coordinator-derived refs → WorkSpec construction is acyclic. An independent pure run matched all ten retained identity values. No 0002 SQL change or seventh preassignment was found. |
| **A08 — historical work-head witness** | **SI/TD:** `.docs/rw0-c2-private-value-versioning.md:5483-5529`; `src/ge_nwp_coordinator/_rw0_c2_progression_rows.py:38-54,147-199`; `src/ge_nwp_coordinator/sqlite_migrations/0007_rw0_c2_progression_decision.sql:101-125`; `src/ge_nwp_coordinator/_rw0_c2_progression_plan.py:344-358,459-687`. V2 retains the four historical work-head fields and exact replan-only graph role, with branch nullability and role counts checked; v1 remains a documented predecessor. Mutants were inspected, not run. |
| **A09 — fresh P1 writer** | **SI/TD:** `src/ge_nwp_coordinator/sqlite_writer_session.py:6860-6943`; `src/ge_nwp_coordinator/sqlite_transition_transaction.py:1273-1369,3060-3177`; `src/ge_nwp_coordinator/_sqlite_rw0_c2_progression.py:266-291,627-697`; `tests/test_sqlite_rw0_c2_progression.py:149-185`. The source path fences, inserts immutable rows, CAS-updates applicable program/work heads, checks actual postimages and family, inserts receipt last, and attempts one commit. CAS no-op and readback-mismatch rollback injections were not independently run. |
| **A10 — replay and recovery** | **SI/IE:** `src/ge_nwp_coordinator/_sqlite_rw0_c2_progression.py:395-466,700-721`; `src/ge_nwp_coordinator/_rw0_c2_progression_contracts.py:769-792,907-952`; `src/ge_nwp_coordinator/_rw0_c2_progression_plan.py:274-310`. **Material finding F01:** replay supplies the persisted block reason as the candidate reason, which the value contract rejects. A complete committed stale-currentness family could not replay or read, and recovery returned `unresolved`. |
| **A11 — second replan** | **SI/TD:** `src/ge_nwp_coordinator/_sqlite_rw0_c2_progression.py:294-380,395-453,678-695`; `tests/test_sqlite_rw0_c2_progression.py:188-362`. Historical replan reconstruction uses immutable rows and the retained v2 witness rather than current heads. The second-replan/first-replay test design was inspected; independent execution remains open. |
| **A12 — collisions and graph** | **SI/TD:** `src/ge_nwp_coordinator/_sqlite_rw0_c2_progression.py:456-625,700-721`; `src/ge_nwp_coordinator/_rw0_c2_progression_plan.py:561-687`; `tests/test_sqlite_rw0_c2_progression.py:447-533,557-627`. Source probes global and family routes, aliases, membership, and competing complete winners and checks graph roles and cross-links. The F01 reconstruction error limits valid block replay. Independent collision and graph mutation runs remain open. |
| **A13 — connected path** | **SI/TD:** `tests/test_sqlite_rw0_c2_connected.py:116-177`; `tests/test_sqlite_rw0_c2_progression.py:404-416`; `src/ge_nwp_coordinator/_rw0_c2_progression_plan.py:544-558`. Test design composes synthetic P0→D1/D2→Section 41/C1/V22→P1, including complete P0 with absent P1. No terminal-outcome row is planned. The connected five-branch cases were not independently run. |
| **A14 — shared boundaries** | **SI/TD:** `src/ge_nwp_coordinator/sqlite_writer_session.py:6837-7017,7370-7396,7510-7574`; `src/ge_nwp_coordinator/sqlite_transition_transaction.py:3074-3087`; `src/ge_nwp_coordinator/state_store.py:178-236`. Baseline comparison found additive private shared changes, unchanged earlier F1 hot-journal code, and no new public StateStore or package export. Shared and Section 41/C1 regression tests were not independently run. |
| **A15 — documentation and assurance** | **SI/TD:** `AGENTS.md:1087-1111`; `README.md:703-724`; `.docs/sqlite-bootstrap-and-migrations.md:667-694`; `.docs/sqlite-operations-and-recovery.md:229-234,690-692`; `.docs/sqlite-schema-v1.md:492-494`; `tests/test_sqlite_b1_migrations.py:93-173,656-660`. All 39 modified assurance-test diffs were reviewed. Two unchanged `.docs` pages retain local “current” 0004/0005 tip wording without a 0007 successor. A historical negative check at `tests/test_rw0_c2_private_value_versioning_contract.py:1773-1779` searches a literal schema name while the new implementation constructs it at `src/ge_nwp_coordinator/_rw0_c2_progression_rows.py:90`, weakening that check. |
| **A16 — security and artifacts** | **SI/L:** `src/ge_nwp_coordinator/_rw0_c2_scope_admission_contracts.py:1-6`; `src/ge_nwp_coordinator/_rw0_c2_progression_contracts.py:1-7,93-105,269-356`; `src/ge_nwp_coordinator/_rw0_c2_progression_plan.py:215-245,376-402`; `.docs/rw0-c2-physical-p0-p1-implementation.md:202-212`. New persistent projections omit raw private replan template text. Tests use synthetic task-owned state. Package filename and bounded token-pattern scans found no DB sidecars, caches, bytecode, key/.env files, or apparent credentials. A pattern scan cannot prove absence of arbitrary secrets or live data-handling conformance. |

## Independent causal result and validation

The audit-authored reproducer ran from a fresh, exact source copy with Python **3.13.4**, SQLite **3.49.1**, `env -i`, audit-owned HOME, TMPDIR, and database state, `PYTHONDONTWRITEBYTECODE=1`, `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`, and Python `-B`. Exact argv, cwd, allowlisted environment, exits, output hashes, and before/after file inventories are retained in the evidence ZIP.

The reproducer constructed a closed stale-currentness basis and reached the real private P1 writer. The reducer selected `post_execution_program_block` with final reason `decision_basis_not_current` and separate candidate reason `candidate_evidence_conclusively_accepted`. Fresh persistence changed program versions **1→2**, generic receipts **2→3**, P1 relation/result rows **0→1**, and program-head revision **0→1**. The work head stayed unchanged and acceptance facts stayed **0**. Exact same-command replay then raised `database_integrity_failure`, read raised `mutation_failed`, and recovery returned `unresolved`. Counts and both heads were unchanged after those failed read paths.

The fault is at `source/src/ge_nwp_coordinator/_sqlite_rw0_c2_progression.py:422-425`: historical reconstruction passes `decision.reason_code` into both reduction reason fields. The candidate-reason field rejects block reasons at `source/src/ge_nwp_coordinator/_rw0_c2_progression_contracts.py:769-792`. The valid `productive_branch_not_permitted` path has the same source defect but was not separately executed. The audit-owned source copy’s 315-file byte/mode inventory matched before and after all isolated probes; disposable copies and database state were then removed.

The standalone implementation report claims 5 connected, 5,779 focused, and 9,421 selector-free FULL passes, with zero reported failures/errors/skips and three Python 3.13 multithreaded-`fork()` deprecation warnings in focused/FULL. Audit parsing reconciled the **retained** collection and JUnit ID order and counts, but those records are **not independent execution credit**. Because the material finding stopped the run, this audit performed no focused suite, selector-free collection, or selector-free FULL execution and has no independent 9,421-test pass, call-ID reconciliation, warning outcome, or after-FULL source inventory.

## Findings and open coverage

1. **F01 — material correctness and receipt/recovery defect:** a complete valid durable block cannot replay or classify as `committed_exact`. The source path and persisted-row reproducer establish the block.
2. **F02 — P1 closed-input contract drift:** optional `expected_branch` lacks an exact built-in-type gate; an equality-overriding subclass bypassed its advisory mismatch check. No durable effect was tested with it.
3. **F03 — P0 target grammar gap:** the earlier selector digest and closed conflict/recovery wrappers are absent from the bounded private successor. No bypass was shown.
4. **F04 — documentation/assurance gap:** two local “current migration tip” passages lag 0007; one negative schema-string assertion no longer proves its stated absence.
5. **F05 — low-severity P0 order drift:** timestamp selection precedes fresh collision inspection, potentially changing error precedence without making a write.
6. **F06 — report-only historical provenance limit:** live commit/ref/index/checkout continuity is not observable from this artifact audit.

The following independent execution remains unperformed: P0 fresh/replay/collision/partial/foreign/uncertainty and all three recovery classes; the remaining P1 physical branches; both-head CAS no-op, wrong-count, and readback mismatch rollback; second-replan historical replay; v2 witness/nullability and graph mutants; route, membership, mutation-ref, foreign-family, and competing-winner controls; commit failure/lost-return/cleanup/no-hidden-retry controls; connected five-branch composition; shared regression and disk migration tests; focused selection; selector-free collection and FULL execution. Inspected test assertions are not counted as reached causal controls.

## Nonclaims and effect record

This audit establishes a source-authenticated **artificial offline** candidate and one material reproducer. It establishes no live enrollment or custody conformance, provider/worker readiness, ES or Bridge routing, executable or product Git authority, terminal-outcome persistence, deployment, service, queue, scheduler, autonomous operation, power-loss-safe durability or F2 resolution, qualified F3/F6/F7 resolution, cross-host clock ordering, F03 resolution, or live historical provenance. A P0 record grants no current authority and implies no P1 decision.

Both supplied inputs were rehashed unchanged. The final report and evidence ZIP were reopened and hash-verified. Audit-owned source copies, HOME/TMPDIR, database, and sidecars were removed; the historical stop report and evidence were preserved.

```text
CANDIDATE_SOURCE_EDIT_NOT_AUTHORIZED
LIVE_REPOSITORY_ACCESS_NOT_AUTHORIZED
STAGING_NOT_AUTHORIZED
COMMIT_NOT_AUTHORIZED
PUSH_NOT_AUTHORIZED
PR_NOT_AUTHORIZED
MERGE_NOT_AUTHORIZED
PUBLICATION_NOT_AUTHORIZED
DEPLOYMENT_NOT_AUTHORIZED
PRODUCT_EFFECT_NOT_AUTHORIZED
```

No candidate edit, live repository access, staging, commit, push, PR, merge, publication, deployment, product effect, network call, or live service contact was performed.
