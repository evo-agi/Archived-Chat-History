OBJECTIVE

Repair the independently audited cumulative RW0-C2 P0→P1 candidate without
changing its selected physical architecture.

This is a workspace-write continuation in the SAME implementation Codex
conversation that produced the uncommitted P0→P1 candidate. The parent is the
sole writer. Do not spawn subagents.

The repair has three bounded parts:

1. F01 — fix historical P1 replay/readback/recovery so a valid committed durable
   block reconstructs its distinct candidate reason and final decision reason
   exactly;
2. F02 — enforce the closed-input exact built-in-type rule for the optional
   `expected_branch`;
3. F04 — correct the two stale current-migration-tip passages and strengthen the
   weakened schema-name assurance test.

Do not implement F03 or F05 in this engagement. Preserve them as disclosed,
nonblocking observations.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

AUTHENTICATED STARTING SUBJECT

Before editing, authenticate the exact current uncommitted subject reported by
the completed implementation and independent audit:

- branch:
  `codex/rw0-c2-p0-p1-physical-program-v1`
- HEAD:
  `4519630d0db967066beb21b4ace5004e76827716`
- HEAD tree:
  `15461a58da8df9ebd63fce734d39a07a50ab87ac`
- upstream: absent
- source paths: 315
- current uncommitted Git-compatible source tree:
  `f6801df592af049a6aaef658f721fc1afe27ad6e`
- canonical source manifest SHA-256:
  `4c03bc2963eae334aab0635928dc5c60d8cf0b7b64fb766298f6bc7759d98d64`
- delta from HEAD:
  54 modified, 16 created, 0 deleted
- tracked binary diff:
  151,441 bytes
- tracked binary diff SHA-256:
  `23fb4c551638920676a6b13c9a19e91d914070368dfc6f72b8ace4449b34591f`
- migration 0006 SHA-256:
  `58b2731d52e8e199c010b309a29aa831ffb16d4db4e755d20adb694ce0a7305f`
- migration 0007 SHA-256:
  `bd2b775787ab79f2ceb6970aa53ca4758781f393300a8f454fface2cc040aefa`
- cumulative schema:
  74 user tables, 134 triggers, 5 explicit indexes
- P0 checkpoint tree:
  `fd45f05ff909493ff8984671a02be66d3b48a791`
- prewriter-v2 checkpoint tree:
  `c467361fc4a2bd01b5e67f464f8c8bbc88b4d17b`
- connected checkpoint tree:
  `f6801df592af049a6aaef658f721fc1afe27ad6e`

Require a clean staged index. Preserve the existing prospective provenance
interval and its historical limits. Do not reset, clean, rebase, restore, or
rewrite refs to make authentication pass. Stop on any source, branch, HEAD,
migration, schema, or changed-path mismatch.

INDEPENDENT AUDIT DISPOSITION

The corrected artifact gate authenticated the exact source tree above. The
audit verdict is:

`RW0_C2_P0_P1_CUMULATIVE_ARTIFACT_AUDIT_BLOCKED`

The blocking source defect is exact:

- a valid stale-currentness command freshly commits the complete
  `post_execution_program_block` family;
- the fresh result has final reason `decision_basis_not_current`;
- its distinct candidate reason is
  `candidate_evidence_conclusively_accepted`;
- exact same-command replay fails;
- checked readback fails;
- recovery reports `unresolved`, although the complete exact family committed.

The source defect is at the historical reconstruction path in:

`src/ge_nwp_coordinator/_sqlite_rw0_c2_progression.py`

The audited source passed `decision.reason_code` into both the final reduction
reason and candidate-reason positions. The candidate-reason contract rejects a
block reason. The valid `productive_branch_not_permitted` durable-block path has
the same source defect.

The audit also found:

- F02: optional `expected_branch` accepts an equality-overriding `str`
  subclass instead of requiring `None` or exact built-in `str`;
- F04: two local documentation passages still describe 0004/0005 as the
  current migration tip, and one historical negative test searches a literal
  schema name even though the current implementation constructs the schema ID,
  weakening the stated assurance;
- F03: the bounded private P0 successor does not implement every earlier
  target-only selector/wrapper field, but no authorization bypass was found;
- F05: P0 samples time before a fresh collision probe, potentially changing
  no-write error precedence.

F03 and F05 are explicitly NOT repair scope here. Record them in the closeout
as retained observations.

AUTHORITY AND ARCHITECTURE INVARIANTS

Preserve all of the following:

- one P0→P1 implementation program with a separately attributable P0 checkpoint;
- separate P0 and P1 writers, transactions, receipts, and recovery classifiers;
- migrations 0006 and 0007 as currently selected;
- all existing migration 0001–0007 row meanings and physical table families;
- relation/result/receipt-profile v2 and the historical work-head witness;
- the version-neutral cognitive replan template and noncircular identity order;
- the existing six branch-neutral preassignments;
- unchanged `WorkSpecV1` and migration-0002 semantics;
- acceptance fact only on `candidate_acceptance`;
- no terminal-outcome persistence;
- no public StateStore/package API;
- no live supplier, provider, worker, ES/Bridge route, product Git effect,
  service, scheduler, deployment, or autonomous loop.

No schema or migration change is authorized. No new repository path is
expected. If F01 cannot be repaired from already persisted immutable typed
values without changing SQL, row shape, receipt graph, digest grammar, or
migration bytes, STOP and report the exact missing durable fact.

PART 1 — F01 REPLAY/READBACK/RECOVERY REPAIR

Repair historical P1 reconstruction so it preserves two independent reason
coordinates:

- the final durable decision reason;
- the candidate evaluation reason.

The replay path must recover the candidate reason from the existing persisted,
typed immutable source that originally bound it—normally the checked decision
basis or its exact persisted projection. It must not:

- infer candidate reason from `decision.reason_code`;
- resample current state;
- rerun cognition;
- accept a caller-supplied replacement;
- change a persisted row, digest, graph, receipt, or preassignment;
- special-case one literal branch while leaving the same defect elsewhere.

Fresh persistence identities and bytes for an otherwise identical command must
remain unchanged by this repair. The change is historical reconstruction, not a
new durable-family version.

Required causal controls:

A. `decision_basis_not_current`

1. Construct a valid stale-currentness basis through the real private P1 path.
2. Require the reducer to select `post_execution_program_block`.
3. Require final reason `decision_basis_not_current`.
4. Require distinct candidate reason
   `candidate_evidence_conclusively_accepted` (or the exact valid candidate
   reason produced by the fixture).
5. Freshly commit the complete family.
6. Record complete rows, receipt, applicable mutable-head postimages and exact
   safe result.
7. Replay the exact same command.
8. Require exact replay/readback success and byte/value equality with the fresh
   committed result.
9. Require read-only recovery `committed_exact`.
10. Require no new row, receipt, version, or head movement during replay,
    readback, or recovery.

B. `productive_branch_not_permitted`

Repeat the same proof for a real valid basis that selects the corresponding
durable block. The candidate and final reason fields must remain distinct and
valid. Do not satisfy this control by directly constructing a result object
without reaching the real writer.

C. Negative discrimination

- A genuinely malformed persisted candidate reason remains an integrity failure
  or unresolved recovery according to the existing contract; do not normalize
  it into a valid reason.
- A changed command on an occupied mutation route remains conflict, not replay.
- Other four physical branches retain their existing replay behavior.
- The second-replan historical work-head witness remains exact.

PART 2 — F02 EXACT BUILT-IN TYPE GATE

Locate the owner of optional `expected_branch` in:

`src/ge_nwp_coordinator/_rw0_c2_progression_contracts.py`

Enforce the closed-input rule before advisory comparison or downstream identity
construction:

- accepted: `None` or exact built-in `str`;
- rejected: every subclass of `str`, including an equality-overriding subclass;
- rejected: bool, int, bytes, enum-like objects, and arbitrary equality objects;
- when a string is present, retain the existing finite branch vocabulary and
  mismatch behavior.

Use exact type checks consistent with the repository's closed private-value
contracts. Do not broaden coercion, stringify values, or change the advisory
field into durable authority.

Add direct pure controls proving:

- `None` remains valid;
- an exact matching built-in string remains valid;
- an exact mismatching built-in string is rejected by the existing mismatch
  rule;
- an equality-overriding `str` subclass is rejected before equality can run;
- representative non-string types are rejected;
- no durable writer effect is reached from an invalid value.

PART 3 — F04 DOCUMENTATION AND ASSURANCE SUCCESSOR

Inspect and correct only the affected current-status/current-tip claims in:

- `.docs/sqlite-operations-and-recovery.md`
- `.docs/sqlite-schema-v1.md`

Preserve historical 0004 and 0005 statements in their historical contexts.
Add or revise the current successor so it accurately records migration 0007 as
the current cumulative tip for this uncommitted candidate, while keeping
explicit migration-only upgrade, generation-2, and non-live/offline boundaries.

Inspect:

`tests/test_rw0_c2_private_value_versioning_contract.py`

The audited negative assertion near the existing historical schema-name check
must prove its intended semantic property even though the new implementation
constructs the schema ID in:

`src/ge_nwp_coordinator/_rw0_c2_progression_rows.py`

Do not merely refresh a hash, search a different incidental literal, or weaken
the negative. Prefer a bounded AST/owner-level assertion or exact constructor
relationship that detects the prohibited semantic condition regardless of
literal concatenation. Preserve all historical versioning and v1/v2 predecessor
checks.

AUTHORIZED FILE CEILING

Expected production paths:

- `src/ge_nwp_coordinator/_sqlite_rw0_c2_progression.py`
- `src/ge_nwp_coordinator/_rw0_c2_progression_contracts.py`

Expected direct tests:

- `tests/test_sqlite_rw0_c2_progression.py`
- `tests/test_rw0_c2_progression_contracts.py`
- `tests/test_rw0_c2_private_value_versioning_contract.py`

Expected documents:

- `.docs/sqlite-operations-and-recovery.md`
- `.docs/sqlite-schema-v1.md`
- `.docs/rw0-c2-physical-p0-p1-implementation.md` only if a current
  implementation-status sentence must record the repair/audit finding without
  changing governing semantics.

Direct existing assurance consumers may be changed only when inspection proves
they pin one of these exact bytes or claims. Record that dependency before
editing it. No migration SQL, migration catalog, writer-session/controller,
P0 owner, relation/result row grammar, WorkSpec, public API, package export, or
new file is authorized.

FIRST SUBSTANTIVE REPAIR CHECKPOINT

Before broad validation:

1. save the complete repaired source identity;
2. run the two real durable-block fresh/replay/read/recovery controls;
3. run the F02 exact-type controls;
4. run the strengthened F04 assurance control;
5. include one unchanged acceptance positive and one unchanged replan
   fresh/replay positive;
6. verify migrations 0006 and 0007 bytes and the 74/134/5 schema manifest are
   unchanged;
7. verify the P0 checkpoint production bytes remain exact;
8. save and reopen the checkpoint before continuing.

The checkpoint is implementation evidence, not independent audit.

FINAL VALIDATION

Run from fresh authenticated external copies of the FINAL source only.

Required gates:

1. direct repair controls;
2. the existing connected five-branch selection;
3. the existing final focused selection from the prior candidate, retaining all
   49 modules and adding any directly touched assurance module not already
   present;
4. one selector-free collection;
5. one selector-free FULL execution.

Do not assume the old count 9,421 after adding tests. Freeze the new collection
before execution and require:

- unique collected IDs;
- exact collected/executed/JUnit ID equality and order;
- zero failures, errors, or skips;
- exact warning inventory;
- source bytes and numeric modes unchanged before/after collection and
  execution.

Reconcile retained writer evidence separately from new final-source validation.
Superseded, interrupted, or failed attempts receive no final credit.

PROVENANCE AND PACKAGE

Use the existing versioned provenance approach already present in the current
implementation package. Do not invent a new general evidence framework.

At closeout:

- generate two byte-identical final canonical captures from fresh reads;
- generate a post-cleanup capture;
- retain exact source tree, changed-path inventory, tracked binary diff, recipe
  bytes/hash, schema manifests, commands, environments, IDs, JUnit, warnings,
  checkpoint, and cleanup evidence;
- preserve historical live-ref/index limits without claiming they were resolved;
- create one sealed cumulative review ZIP with the complete final source and all
  necessary safe evidence;
- reopen and verify every member;
- report its byte size and SHA-256;
- report the new Git-compatible source tree.

STOP CONDITIONS

Stop without staging or source normalization if:

- the opening source/tree/baseline does not match;
- F01 requires a schema, migration, receipt-profile, or persisted-row change;
- the original candidate reason is not recoverable from existing immutable
  committed evidence;
- migrations 0006/0007 or P0 frozen production bytes drift;
- any valid branch loses replay/readback/recovery behavior;
- a required final validation gate cannot complete;
- source changes outside the authorized ceiling are required and cannot be
  shown to be direct assertion/hash consumers;
- a security, authority, privacy, or durable-state boundary would widen.

EFFECT CEILING

Authorized:

- bounded repository source/document/test edits above;
- task-owned external source copies and synthetic SQLite state;
- local test execution;
- inert evidence and review-package creation outside the repository.

Not authorized:

- subagents;
- staging;
- commit;
- push;
- PR;
- merge;
- publication;
- deployment;
- network or service contact;
- live supplier/provider/worker/ES/Bridge use;
- user or product database access;
- terminal persistence or any product effect.

REQUIRED FINAL RESPONSE

Return one of:

- `RW0_C2_P0_P1_F01_F02_F04_REPAIR_IMPLEMENTED_VALIDATED_PENDING_AUDIT`
- `RW0_C2_P0_P1_REPAIR_BLOCKED_<PRECISE_REASON>`

Include:

- exact opening and final source identities;
- complete touched-file list and classifications;
- exact F01 root cause and repair;
- exact persisted source used for candidate-reason reconstruction;
- both durable-block causal results;
- F02 controls;
- F04 document/test treatment;
- checkpoint identity and reopen result;
- focused, connected, and selector-free collection/FULL commands and results;
- collected/executed/JUnit reconciliation;
- migration/P0 preservation;
- provenance identities;
- review ZIP path, bytes, SHA-256;
- assumptions, residual observations, skipped/unavailable validation;
- explicit confirmation of no staging, commit, publication, network, or product
  effect.

Retain F03 and F05 as disclosed nonblocking audit observations. Do not claim
they were fixed.
