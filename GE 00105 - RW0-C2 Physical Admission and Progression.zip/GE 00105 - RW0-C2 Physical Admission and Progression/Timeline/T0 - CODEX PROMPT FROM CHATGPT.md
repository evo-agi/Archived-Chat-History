# Coordinator RW0-C2 physical-admission sequencing reconnaissance

## Objective

Produce one implementation-defining, source-grounded design for the **next
bounded Coordinator tranche after integrated post-D2 native proposal admission**.

The leading engineering judgment is that the first physical C2-adjacent tranche
should be **program-independent scope-admission provisioning**, not the complete
five-branch C2 decision writer. Confirm or rebut that judgment from the current
integrated source. Freeze the exact transaction/ownership, migration, value,
reader/recovery, touched-file and validation design needed for the smallest
coherent implementation tranche.

Do not implement anything in this engagement.

## Repository

`/Users/ds/Repositories/Governed Execution Coordinator/`

## Fixed integrated baseline

Authoritative integrated source:

- PR: `#16`
- squash commit: `4519630d0db967066beb21b4ace5004e76827716`
- sole parent: `eac7f6df5f281138dd0640c5cd47b9924c8390f8`
- Git tree: `15461a58da8df9ebd63fce734d39a07a50ab87ac`
- tracked source count: `299`

Checkpoint archive:

`/Users/ds/Downloads/Coordinator_PostD2_PR16_Integration_20261024/Coordinator_PostD2_PR16_SquashSourceCheckpoint_20261024.zip`

Expected checkpoint identity:

- bytes: `3,245,477`
- SHA-256: `087990b15ded609615659c0927f849cf656c4b0cabd6de78339add4410a74166`

Expected topic preservation:

- topic: `codex/post-d2-native-proposal-admission-v1`
- topic tip: `6d867cb09af047dff0d66b4917fa29317c00de31`
- topic tree: `15461a58da8df9ebd63fce734d39a07a50ab87ac`

A live checkout on either the preserved topic or `trunk_dev` is acceptable only
when its complete source tree equals the fixed tree above. Do not switch
branches, fetch, reset, clean, update refs or alter the checkout. Stop on source
identity mismatch. Diagnostic turn-diff refs are not source authority; report
them separately rather than using total-ref equality as the source gate.

## Current implemented contract

Treat these as current integrated facts, not future intent:

1. The private post-D2 continuation invokes the original D2 run once.
2. Section 41 transaction A records one post-execution proposal/context/receipt
   family.
3. A fresh guarded read checks the persisted twelve owner rows.
4. A distinct C1 transaction B admits one rank-15 member.
5. Fresh A/B readbacks feed unchanged pure V22.
6. Migration `0005_section41_post_execution_proposal_family` belongs only to
   that Section 41 family and remains application generation 2.
7. No physical C2 decision, acceptance fact, terminal outcome, live supplier,
   production worker, ES/Bridge route, product Git effect, service, scheduler or
   autonomous loop exists.

## Accepted target and reopened seams

The accepted target documents define, but do not physically implement:

- one immutable externally admitted scope;
- program-independent scope-admission recording;
- one permanently non-replenishable productive-acceptance ceiling;
- five-branch C2 reduction;
- one atomic decision/version/head/result/receipt family;
- acceptance-fact membership only on the acceptance branch;
- exact replay and whole-family three-way recovery; and
- later, separate terminal-outcome persistence.

Physical representation, migration allocation, guard/source readsets,
transaction integration, production callers and runtime remain reopened seams.
Migration 0005 is consumed by Section 41; any C2 suffix is expected no earlier
than 0006 but is not yet selected.

## Provisional sequencing decision to test

Preferred critical path:

1. **P0 — bounded offline physical scope-admission provisioning**
   - one program-independent immutable admission family;
   - synthetic, explicitly artificial verified-act/enrollment/custody sources;
   - existing guarded SQLite owner/controller;
   - exact replay, no-write conflict classes and read-only three-way recovery;
   - no program, C2 decision, acceptance fact or terminal fact authored by P0.
2. **P1 — physical C2 decision/acceptance writer**
   - consumes the recorded admission fact and current guard posture;
   - reuses migration-0002 generic decision/version/head semantics where exact;
   - adds only necessary supplemental immutable relations/acceptance storage;
   - acceptance fact exists only on the acceptance branch.
3. **P2 — terminal-outcome owner**, separately.
4. **RW0-E live route**, only after supplier gate B and later explicit authority.

Confirm this split or identify the exact invariant that requires a different
split. Do not propose a cross-owner mega-transaction merely for convenience.

## Required source reading before synthesis

Read complete relevant sections, not isolated search hits:

### Governing and composition

- `AGENTS.md`
- `README.md`
- `.docs/autonomous-software-development-operating-model.md`
- `.docs/architecture.md`
- `.docs/authority-boundaries.md`
- `.docs/c2b-durable-development-state.md`

### Current post-D2 owner

- `.docs/rw0-d2-offline-evidence-and-review.md`
- `.docs/section41-post-execution-proposal-family.md`
- `src/ge_nwp_coordinator/_rw0_d2_post_execution_continuation.py`
- `src/ge_nwp_coordinator/_sqlite_section41_post_execution_proposal.py`
- `src/ge_nwp_coordinator/_section41_post_execution_proposal_family_projection.py`
- `src/ge_nwp_coordinator/_section41_post_execution_role_resolution.py`

### C2 target owners

- `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
- `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md`
- `.docs/rw0-c2-scope-admission-provisioning-contract.md`
- `.docs/rw0-c2-private-value-versioning.md`
- `.docs/rw0-c2-first-live-proof-posture.md`

### Existing physical and private-value foundations

- `src/ge_nwp_coordinator/_rw0_c_decision_input_values.py`
- `src/ge_nwp_coordinator/_development_decision_row_values.py`
- `src/ge_nwp_coordinator/_development_program_row_values.py`
- `src/ge_nwp_coordinator/_sqlite_development_readers.py`
- `src/ge_nwp_coordinator/_sqlite_development_reader_contracts.py`
- `src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql`
- `src/ge_nwp_coordinator/sqlite_migrations/0005_section41_post_execution_proposal_family.sql`
- `src/ge_nwp_coordinator/sqlite_migration.py`
- `src/ge_nwp_coordinator/sqlite_writer_session.py`
- `src/ge_nwp_coordinator/sqlite_transition_transaction.py`
- `src/ge_nwp_coordinator/sqlite_security.py`
- `src/ge_nwp_coordinator/sqlite_connection.py`

### Tests and assurance consumers

At minimum inspect:

- `tests/test_rw0_c2_scope_admission_provisioning_contract.py`
- `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py`
- `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`
- `tests/test_rw0_c2_private_value_versioning_contract.py`
- `tests/test_rw0_c2_first_live_proof_posture_contract.py`
- `tests/test_post_execution_pure_owner_boundaries.py`
- `tests/test_post_execution_pure_owner_relations.py`
- `tests/test_post_execution_pure_owner_values.py`
- `tests/test_post_execution_pure_owner_vectors.py`
- `tests/test_c2b0_durable_state_contract.py`
- `tests/test_runtime_non_authority.py`
- `tests/test_c2a_nonimplementation.py`
- `tests/test_sqlite_b1_migrations.py`
- `tests/test_sqlite_c2b1_migration_framework.py`
- `tests/test_sqlite_c2b2_migration_0002.py`
- `tests/test_architecture_contracts.py`
- `tests/test_autonomous_software_development_operating_model.py`

Inspect additional directly dependent docs/tests/source when discovered. State
every expansion and why it is directly required.

## Questions the reconnaissance must resolve

### A. Sequencing and ownership

1. Is program-independent scope-admission provisioning the smallest coherent
   first implementation tranche? If not, state the exact current invariant that
   blocks or makes it insufficient.
2. Which owner writes the admission family, and which owner later writes the C2
   decision/acceptance family?
3. Which facts are external-source observations, immutable local facts,
   transient results, receipts, readback projections or non-authoritative model
   evidence?
4. How does the offline proof use synthetic sources without claiming supplier
   gate B, real custody, standing-policy authenticity or live allowance use?

### B. Physical representation and migration allocation

5. What exact logical members must P0 retain or be able to reconstruct?
6. What physical tables, columns, keys, FKs, immutability guards and collision
   routes are minimally necessary for P0?
7. Should P0 consume migration 0006 alone? Must acceptance-fact storage be in a
   later suffix, or is there a source-grounded reason to share one additive
   suffix while preserving distinct transactions and authorities?
8. Which migration-0002 decision/version/head/result/receipt rows are reusable
   unchanged for P1, and which supplemental relations are genuinely required?
9. What schema counts, catalog/tip consumers and exact-migration guards would be
   affected? Preserve migrations 0001–0005 byte-for-byte.

Do not select schema by analogy alone. Cite the actual existing rows, fields,
constraints and callers.

### C. Values, command identity and recovery

10. Which accepted-target command/basis/result/receipt/readback values already
    exist only in documentation/test fixtures, which exist in private source,
    and which require new source?
11. Freeze the acyclic digest order and the exact command-covered recovery
    selector for P0.
12. Define exact fresh apply, receipt-first replay, collision, precommit
    no-write, commit uncertainty and `committed_exact` /
    `definitely_not_committed` / `unresolved` behavior.
13. Identify the exact current permission/custody source seam for an artificial
    offline fixture, while keeping it impossible to mistake for a production
    verifier or live supplier.

### D. Connected proof and later handoff

14. Define P0's first substantive checkpoint. It must record admission before a
    program exists, prove exact readback/replay/conflict/recovery, and prove that
    no program, decision, acceptance or terminal row is created.
15. Define the exact handoff from P0 to later P1. Do not implement P1 in P0.
16. Explain how the current post-D2 V22 projection will later become C2 decision
    input without making V22 or the model authoritative.
17. State what P0 does and does not resolve for F2 and the first-live gate.

### E. Exact implementation scope and assurance

18. Return the exact proposed touched-file set for P0, classified as docs,
    migration, private values, writer/reader/recovery, integration, tests and
    status/assurance successors.
19. Map every complete-file identity, migration-tip/count, absent-0006,
    nonimplementation, import/caller, public-surface and authority assertion that
    would need a deliberate successor.
20. Provide exact future validation commands and expected evidence, including a
    source-bound first checkpoint, targeted causal tests, migration tests,
    focused regression union and a selector-free FULL gate.
21. Define the independent-audit perspectives and the provenance inputs that a
    later implementation must return.

## F2 and other inherited findings

F2 power-loss durability remains unresolved. Treat it as follows:

- it blocks live/permanent durability claims and must remain explicit;
- it does not by itself block an artificial offline P0 proof with disposable
  state and no live allowance claim;
- do not change journal mode or synchronous posture in this reconnaissance;
- identify any P0 contract wording/test needed to avoid overclaiming.

Qualified F3/F6/F7, cross-host clock ordering, F03, historical raw-index/ref
limits and the low semantic-specimen causal-credit observation remain outside
P0 unless a direct source dependency proves otherwise.

## Read-only subagent workflow

Use exactly four read-only explorer agents in parallel, with self-contained
context and no nested delegation:

1. **Contract and authority explorer**
   - C2 decision, guard, scope-admission, first-live and operating-model owners;
   - exact current-versus-target ledger and sequencing constraints.
2. **Physical schema and transaction explorer**
   - migration 0002/0005, catalog, row values, readers, writer session,
     controller, recovery and candidate 0006 allocation.
3. **Source/test dependency mapper**
   - pure C2 source, no-production-caller boundaries, tests, complete-file/hash
     consumers, migration and status successors, exact touched-file proposal.
4. **Security, live-boundary and validation explorer**
   - synthetic-source boundary, supplier gate B, F2 limit, privacy/sensitive
     surfaces, causal validation and audit plan.

Each agent must cite exact repo-relative paths and line ranges, distinguish
contract/evidence/inference/uncertainty, name uninspected scope, and perform no
mutation or test execution. The parent must wait for all four, preserve
material disagreements and close every agent before finalizing.

## Effect ceiling

This engagement is read-only.

Do not:

- edit, create, delete or format repository files;
- run pytest, migrations, database fixtures, imported repository code or helper
  programs;
- install dependencies;
- switch branches, fetch, pull, reset, clean, update refs or change config;
- contact a provider, service, network, GitHub, ES, Bridge or user database;
- stage, commit, push, open/modify a PR, merge or publish;
- implement scope admission, C2, terminal, worker, scheduler or live-supplier
  behavior.

Ordinary read-only source and Git-object inspection is allowed. Preserve the
prospective source identity and report any read ordering/provenance limit
without turning it into a candidate defect.

## Required output

Return one consolidated report with exactly these sections:

1. **Verdict** — `RECONNAISSANCE_READY`, `RECONNAISSANCE_PARTIAL`, or
   `RECONNAISSANCE_BLOCKED`.
2. **Authenticated baseline and inspection boundary**.
3. **Current contract / accepted target / reopened seam ledger**.
4. **Selected next tranche and rejected alternatives**.
5. **Exact P0 authority, data-flow, transaction and recovery design**.
6. **Physical schema and migration decision**, including whether 0006 is P0-only
   and the reserved treatment for P1.
7. **Exact touched-file and assurance-consumer map**.
8. **First checkpoint, causal controls, validation and independent-audit plan**.
9. **F2/live-boundary treatment and explicit nonclaims**.
10. **Assumptions, unresolved conflicts and stop conditions**.

The report must make a clear recommendation rather than offering an
undifferentiated menu. Do not author an implementation patch or implementation
prompt. Save and reopen the report outside the repository and return its exact
path, byte count and SHA-256.
