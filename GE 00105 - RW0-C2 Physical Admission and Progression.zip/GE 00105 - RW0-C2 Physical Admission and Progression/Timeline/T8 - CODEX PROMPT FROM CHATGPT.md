Permission remains workspace-write.

Continue in the SAME Codex implementation conversation that produced:

RW0_C2_P0_P1_PHYSICAL_PROGRAM_PARTIAL_BLOCKED_REPLAN_PREASSIGNMENT_CYCLE

Do not start another reconnaissance turn. Do not spawn subagents. Do not involve
an independent auditor. You remain the sole repository writer.

PURPOSE AND DISPOSITION

The stop was correct. The current partial P1 contract contains a genuine identity
cycle:

complete WorkSpecV1 (including new program_version_ref)
  -> WorkSpec safe projection/digest
  -> cognitive replan proposal safe projection/digest
  -> decision-basis digest
  -> guarded-family preassignment basis
  -> preassigned resulting program-version ref
  -> complete WorkSpecV1

The preceding authority decision is corrected here. The cognitive proposal must
not author a final WorkSpecV1 containing a Coordinator-owned future program-version
coordinate. Replace that partial design with a version-neutral private replan
content proposal. The Coordinator derives all new durable replan row identities,
binds the proposal to the already preassigned resulting version, constructs the
UNCHANGED existing WorkSpecV1, and persists the resulting existing 0002 rows.

This is the explicit authority decision needed by the stop report. It is not a
new broad reconnaissance, a standalone semantic-contract tranche, a standalone
P0 integration, or permission to change existing 0002 WorkSpec meaning.

Continue the selected single P0-to-P1 implementation program directly.

REPOSITORY AND REQUIRED OPENING

Repository:
/Users/ds/Repositories/Governed Execution Coordinator/

Require before any edit:
- branch: codex/rw0-c2-p0-p1-physical-program-v1
- upstream: absent
- HEAD: 4519630d0db967066beb21b4ace5004e76827716
- HEAD tree: 15461a58da8df9ebd63fce734d39a07a50ab87ac
- local trunk_dev and origin/trunk_dev: the same HEAD
- staged diff: empty
- current uncommitted source: exactly 312 paths
- current source tree: 77f7e29033fc76de03667b810bd456536797850a
- 299 tracked source paths and 13 untracked additions
- exact P0 checkpoint tree: fd45f05ff909493ff8984671a02be66d3b48a791
- exact P0 checkpoint canonical-manifest SHA-256:
  2fa63a923b3d296b59febd694020447a0dd1961bcb5fe1988593b1e340b32cfa
- migration 0006 SHA-256:
  58b2731d52e8e199c010b309a29aa831ffb16d4db4e755d20adb694ce0a7305f
- current partial migration 0007 SHA-256, as evidence only:
  f50960f6689c4ed098357a109dd9d03117060f20ee0b11e82af2012fe302afac
- P0 frozen production paths byte-identical to the checkpoint:
  - src/ge_nwp_coordinator/sqlite_migrations/0006_rw0_c2_scope_admission.sql
  - src/ge_nwp_coordinator/_rw0_c2_scope_admission_contracts.py
  - src/ge_nwp_coordinator/_sqlite_rw0_c2_scope_admission.py

Authenticate the current source and exact P0 checkpoint before editing. The
partial P1 source is unaccepted implementation evidence and may be revised. Do
not restore an older provisional tree wholesale. Preserve the retained stop
package and its failed-cycle explanation unchanged as historical evidence.

Establish a fresh prospective source/index/config/authoritative-ref opening. The
staged semantic index must equal HEAD and the staged diff must remain empty.
Qualified platform diagnostic refs remain separate observations. Stop on source,
branch, HEAD, tree, upstream, staged-state, P0-checkpoint, migration-0006, frozen
P0-owner, configuration, or authoritative-ref mismatch.

CORRECTED REPLAN AUTHORITY AND NONCIRCULAR IDENTITY ORDER

1. Model/cognitive role

The artificial cognitive replan proposal supplies proposed CONTENT and source
intent evidence only. It does not select the final branch and does not author:
- a durable accepted-intent revision identity;
- a durable work-item revision identity;
- a durable WorkSpec identity;
- a program-version identity;
- a decision, version, head, result, receipt, acceptance fact, or recovery class.

The P1 Coordinator decision owner remains the sole durable author. It may adopt
the proposal only after the authoritative branch is independently derived as
attempt_selecting_replan and every admission, currentness, matrix, guard,
collision, relationship, and expected-branch check succeeds.

2. Version-neutral private template

Replace the partial CognitiveReplanProposalV1.work_spec: WorkSpecV1 field with a
new exact private transient CognitiveReplanWorkSpecTemplateV1 owned by the P1
physical contract. Do not modify WorkSpecV1 or its existing 0002 meaning.

The template has this exact closed field set:
- schema_id
- program_ref
- work_item_ref
- repository_ref
- base_git_object_format
- base_git_oid
- authorized_paths
- objective
- requirements
- exclusions
- validation_requirement_ref
- review_requirement_ref
- privacy_classification
- template_digest

Required semantics:
- program_ref and work_item_ref are existing current-owner coordinates.
- base_git_object_format remains the exact existing WorkSpec value.
- privacy_classification remains private_work_spec.
- objective, requirements, and exclusions remain private transient content.
- template_digest is the domain-separated self-digest of the complete template
  excluding only template_digest.
- program_version_ref, accepted_intent_revision_ref, work_item_revision_ref,
  work_spec_ref, work_spec_digest, and safe_projection_digest are deliberately
  absent.
- unknown/duplicate fields, coercion, bool-as-int, invalid paths/types/bounds,
  noncanonical bytes, and unsafe refs fail before decision-basis construction.

Add an exact safe projection for the template with this closed field set:
- schema_id
- program_ref
- work_item_ref
- repository_ref
- base_git_object_format
- base_git_oid
- authorized_paths
- validation_requirement_ref
- review_requirement_ref
- privacy_classification
- template_digest
- safe_projection_digest

The safe projection exposes no objective, requirement, or exclusion text. Its
safe_projection_digest commits to the exact safe projection excluding itself;
template_digest commits to the complete private template.

Use explicit private schema IDs and digest domains under the existing
`governed-execution.nwp-rw0-c2-...v1` namespace. Freeze those exact literals in
source, owning documentation, vectors, and tests. Because the current P1 source
is uncommitted and blocked, replace the flawed partial V1 shape rather than
creating a compatibility alias or carrying both forms.

3. Corrected cognitive replan proposal

CognitiveReplanProposalV1 contains exactly:
- source_intent_ref
- source_intent_digest
- work_spec_template

Its safe projection contains exactly:
- schema_id
- source_intent_ref
- source_intent_digest
- work_spec_template_safe_projection
- proposal_digest

The proposal carries no future durable row ref. The exact proposal safe
projection remains the nullable replan_proposal_safe_projection member of the
closed 21-field DecisionBasisV1. DecisionBasisV1 remains exactly 21 top-level
fields. Non-replan branches require that member and the transient proposal to be
absent. attempt_selecting_replan requires both, and the transient proposal must
recompute exactly to the basis projection.

4. Existing branch-neutral preassignment remains unchanged

Do not change the accepted six-sibling preassignment meaning in
`.docs/rw0-c2-private-value-versioning.md`.

The decision-basis digest now commits to the version-neutral proposal projection.
The existing 24-coordinate guarded-family preassignment transcript then derives
all six siblings, including preassigned_version_ref. The command digest is formed
only after all six sibling values validate, exactly as already frozen.

No placeholder version, fixed-point search, recursive digest, second basis, or
caller-supplied version is permitted.

5. Coordinator-owned branch-specific replan identities

After the authoritative branch is attempt_selecting_replan and after the existing
command digest is available, derive three new branch-specific durable refs as
siblings from one exact ordered replan-successor transcript:

- new accepted-intent revision ref;
- new work-item revision ref;
- new WorkSpec ref.

The ordered transcript must contain exactly:
- command_digest
- program_ref
- current_program_version_ref
- current_accepted_intent_revision_ref
- work_item_ref
- current_work_item_revision_ref
- source_intent_ref
- source_intent_digest
- work_spec_template_digest
- preassigned_version_ref

Use three distinct domain-separated v1 derivations. Each output is lowercase
SHA-256 hex and no derived sibling reads another sibling. These are dependent
branch outputs analogous to the existing successor attempt/candidate derivation;
they do not feed the decision basis, six branch-neutral preassignments, or command
digest.

The proposal therefore cannot choose durable revision or WorkSpec row identities.
Collision probes and checked current-owner relations remain mandatory.

6. Final WorkSpec binding

Add one Coordinator-owned pure binding function:

bind_replan_work_spec(template, *, work_spec_ref,
                      program_version_ref,
                      accepted_intent_revision_ref,
                      work_item_revision_ref) -> WorkSpecV1

It constructs the unchanged existing WorkSpecV1 with:
- work_spec_ref: Coordinator-derived replan WorkSpec ref;
- program_ref: template.program_ref;
- program_version_ref: relation.preassigned_version_ref;
- accepted_intent_revision_ref: Coordinator-derived new intent revision ref;
- work_item_ref: template.work_item_ref;
- work_item_revision_ref: Coordinator-derived new work revision ref;
- repository/base/path/objective/requirements/exclusions/validation/review fields:
  exact template values.

WorkSpecV1.create computes the existing work_spec_digest. The unchanged existing
DevelopmentWorkSpecSafeProjection is then derived from that final WorkSpecV1.
Require exact field equality back to the template and derived refs.

The identity order is therefore:

private template
  -> template digest and safe projection
  -> cognitive proposal safe projection/digest
  -> decision-basis digest
  -> existing six branch-neutral sibling preassignments
  -> command digest
  -> three Coordinator-owned branch-specific replan refs
  -> final unchanged WorkSpecV1 and safe projection
  -> existing 0002 replan rows and row digests
  -> guarded relation/result, graph, receipt, COMMIT

The final WorkSpec digest and safe-projection digest are dependent outputs. They
must never feed back into the decision basis or preassigned version ref.
Nevertheless, the command identity commits to them transitively through the
proposal/template digest plus the preassigned version and branch-specific ref
derivations.

7. Replan atomic family and recovery

In the SAME P1 transaction, attempt_selecting_replan must create and verify:
- new accepted-intent revision;
- new work-item revision;
- accepted-intent supersedes edge;
- work-item supersedes edge;
- final existing WorkSpec binding for the new version;
- updated work-item head;
- complete new program-version membership closure;
- canonical replan decision;
- resulting program version;
- program-head postimage;
- all six supplemental P1 families;
- generic result and generic 0002 receipt.

It may preassign the later semantic attempt/candidate under the already frozen
branch rules, but must not create those later rows.

Receipt-first replay, full checked readback, collision probes, uncertain-commit
recovery, and committed_exact classification must verify every branch-required
replan row above. A receipt plus missing, foreign, partial, or contradictory
replan rows is unresolved/family_unverifiable, never committed_exact and never
repaired in place. Keep the accepted ten-common-role/acceptance-only-eleventh
receipt-graph profile unchanged; branch-specific 0002 replan rows are still
mandatory whole-family readback/recovery obligations and must be verified through
their exact deterministic selectors and digests.

Do not add another migration or supplemental table solely to break this cycle.
Migration 0007 remains the P1 suffix and the six-table supplemental allocation,
subject to the final source/DDL/recovery audit. Migrations 0001-0006 remain
byte-for-byte fixed, including P0 migration 0006.

PARTIAL-SOURCE TREATMENT

The current seven added P1 paths and four P0/shared successors are partial source,
not an accepted checkpoint. Reinspect each and keep only correct work. In
particular:
- replace the flawed complete-WorkSpec proposal shape;
- regenerate fixed vectors and tests rather than preserving partial digests;
- do not preserve migration-0007 SHA-256 if final correct DDL or owner integration
  changes its bytes;
- retain the exact historical 0006/current-0007 successor treatment from the
  preceding continuation;
- preserve exact P0 migration and private owner bytes.

No existing WorkSpecV1, DevelopmentWorkSpecSafeProjection, 0002 row meaning,
0002 digest domain, six branch-neutral preassignment meaning, pure reducer branch
mapping, or P0 owner may be changed to obtain a pass.

EARLY SOURCE-BOUND CHECKPOINT

Before implementing the SQLite P1 writer, save and reopen a source-bound pure
identity checkpoint on the corrected contract. It must prove at minimum:

1. A version-neutral private template and proposal close without any future
   version or durable revision/WorkSpec ref.
2. The 21-field decision basis closes and validates.
3. The existing six preassignments derive, including preassigned_version_ref.
4. The command digest closes.
5. The three branch-specific replan refs derive afterward.
6. The final WorkSpecV1 binds exactly to the preassigned version and derived refs.
7. Repeating identical input reproduces every byte/ref/digest exactly.
8. Changing private objective/requirements/exclusions changes template digest,
   proposal digest, basis digest, preassigned version, command digest, derived
   replan refs, and final WorkSpec digest.
9. A caller-provided final WorkSpec, placeholder version, wrong version, donor
   template, changed final private content, changed derived ref, or detached
   safe projection is rejected.
10. Replan proposal/template is required only for attempt_selecting_replan and
    forbidden for all other branches.
11. Existing WorkSpecV1 and 0002 safe-projection golden behavior remains unchanged.
12. The dependency graph is acyclic and topologically ordered; no post-branch or
    final WorkSpec value feeds a preassignment.

Reopen this checkpoint before adding the writer. It is implementation evidence,
not independent acceptance.

COMPLETE P1 IMPLEMENTATION

After the checkpoint passes, continue directly to the physical P1 writer,
checked reader, receipt-first replay, full-family readback, commit-uncertainty
recovery, and connected caller. Do not stop for another user handoff unless an
actually new authority conflict or incompatible existing contract is found.

Complete all five branches and preserve:
- exact no-write conflict versus durable block distinctions;
- acceptance fact only for candidate_acceptance;
- P0 committed/P1 absent as a complete truthful state;
- no terminal-outcome persistence;
- no live supplier/custody, provider/worker, ES/Bridge, Git-product effect,
  service, queue, scheduler, deployment, or autonomous-loop widening.

DOCUMENTATION AND ASSURANCE

Update governing documentation, code, DDL/catalog consumers, and tests together.
The physical implementation document must replace the cycle stop with the exact
noncircular construction above while retaining the stop as historical development
evidence. Add narrow current-status successors where required; preserve byte-pinned
historical identities and hostile controls rather than weakening them.

The implementation report must clearly state that the earlier requirement for a
complete proposal-owned WorkSpecV1 was corrected because it assigned a future
Coordinator-owned coordinate before its derivation and created a cycle. Do not
claim the stopped partial source implemented P1.

VALIDATION

First rerun the exact pure identity checkpoint. Then complete:

1. migration 0006 historical-prefix and migration 0007 current-tip tests;
2. P0 physical/replay/recovery tests on the cumulative 0007 schema;
3. corrected P1 private contract, reducer, plan, row, writer, readback, replay,
   recovery, and all five branch tests;
4. exact replan branch tests for all new intent/work/edge/WorkSpec/membership/head
   rows and their negative/donor/collision/partial-family cases;
5. connected P0 -> D1/D2 -> Section 41/C1/V22 -> P1 proofs for all five branches;
6. the complete focused contract/migration/authority/assurance selection already
   required by the preceding mandate;
7. one selector-free collection and one selector-free FULL execution on identical
   final bytes.

Use fresh authenticated external source copies, no plugin autoload, no bytecode or
pytest cache, task-owned HOME/TMPDIR/basetemps, and exact collected/reported/called/
JUnit ID reconciliation. Do not predict the final test count. Retain all warnings,
failures, skips, interruptions, source identities, and superseded attempts without
crediting them to final bytes.

PROVENANCE AND REVIEW PACKAGE

Retain and authenticate:
- the exact P0 checkpoint package/tree/manifest and 417-node evidence;
- the replan-cycle stop package/report and current partial tree as historical
  evidence only;
- exact P0-to-final comparisons;
- frozen migration 0006 and final migration 0007 identities;
- historical 0006 and current 0007 schema manifests;
- the reopened noncircular identity checkpoint;
- complete final source;
- complete validation, causal-control, replay, readback, and recovery evidence;
- deterministic final manifests generated twice from fresh reads;
- prospective index/config/authoritative-ref observations;
- bounded cleanup and preservation records;
- one complete implementation report.

Return one reopened review package for a fresh independent audit. No artifact is
authority.

EFFECT CEILING

Authorized:
- repository source/schema/docs/test edits within the P0/P1 program;
- task-owned disposable SQLite state and external validation copies;
- implementation validation and provenance.

Not authorized:
- subagents during mutation;
- changes to another repository;
- live supplier, provider, worker, ES, Bridge, user database, or network effects;
- staging, commit, push, PR, merge, publication, deployment, or product execution;
- independent-audit claims.

STOP CONDITIONS

Stop without staging if:
- the current partial source or exact P0 checkpoint cannot be authenticated;
- migration 0006 or either frozen P0 private owner must change;
- existing WorkSpecV1 or 0002 row/digest semantics must change;
- the six accepted branch-neutral preassignments must change;
- the version-neutral template cannot deterministically produce one exact final
  WorkSpecV1 after version preassignment;
- the full replan family cannot be replayed/read back/recovered without a new
  unresolved authority or receipt-graph decision;
- a historical 0006 assertion cannot coexist with exact current 0007 truth;
- connected five-branch validation or selector-free FULL validation is unavailable,
  incomplete, interrupted, or changes final bytes;
- another writer or baseline drift appears.

REQUIRED DISPOSITION

On complete success, return:

RW0_C2_P0_P1_PHYSICAL_PROGRAM_IMPLEMENTED_VALIDATED_PENDING_INDEPENDENT_AUDIT

Otherwise return one precise BLOCKED or PARTIAL disposition naming the exact
remaining authority, correctness, validation, or provenance boundary. Do not
present partial P1 source as a durable decision implementation.

At closeout include:
- exact final source tree and changed-path inventory;
- exact P0 preservation results;
- final 0007 checksum and schema counts;
- exact noncircular identity vector and dependency order;
- all five branch row/family/recovery results;
- exact validation commands and outcomes;
- assumptions, unresolved seams, uninspected areas, and authority/security widening;
- complete artifact identities and cleanup result;
- explicit nonclaims.

INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
MERGE_NOT_PERFORMED
PUBLICATION_NOT_PERFORMED
DEPLOYMENT_NOT_PERFORMED
PRODUCT_EFFECT_NOT_PERFORMED
