Permission remains workspace-write.

Continue in this same Codex implementation conversation. Do not start another
reconnaissance turn, do not spawn subagents, and do not involve an independent
auditor. You remain the sole repository writer.

DISPOSITION AND PURPOSE

The preceding implementation turn ended with:

RW0_C2_P0_P1_PHYSICAL_PROGRAM_PARTIAL_FROZEN_P0_TEST_CONFLICT

P0 was implemented, saved, reopened, and restored as the current uncommitted
working source. P1 stopped because the prior mandate was read as freezing every
P0 checkpoint byte, including tests whose assertions intentionally described
migration 0006 as the complete current tip and the future acceptance table as
absent.

That interpretation is corrected here.

This is not a new architecture decision, reconnaissance tranche, standalone P0
integration, or semantic-contract-only tranche. Continue the selected single
P0-to-P1 implementation program directly. All authority, branch, decision-basis,
replan, transaction, recovery, validation, effect-ceiling, and nonclaim decisions
from the preceding implementation mandate remain operative except where this
continuation explicitly replaces the P0 freeze rule.

REPOSITORY AND REQUIRED OPENING

Repository:
/Users/ds/Repositories/Governed Execution Coordinator/

Require before any edit:
- branch: codex/rw0-c2-p0-p1-physical-program-v1
- upstream: absent
- HEAD: 4519630d0db967066beb21b4ace5004e76827716
- HEAD tree: 15461a58da8df9ebd63fce734d39a07a50ab87ac
- local trunk_dev and origin/trunk_dev: the same HEAD
- staged diff: empty
- working source: exactly the reopened P0 checkpoint
- P0 source-tree identity: fd45f05ff909493ff8984671a02be66d3b48a791
- P0 canonical manifest SHA-256:
  2fa63a923b3d296b59febd694020447a0dd1961bcb5fe1988593b1e340b32cfa
- 299 baseline tracked paths plus exactly six P0 additions
- 26 modified and six new paths, all unstaged
- migration 0006 SHA-256:
  58b2731d52e8e199c010b309a29aa831ffb16d4db4e755d20adb694ce0a7305f

Authenticate the current source against the reopened P0 checkpoint and retained
report/package before continuing. Do not reconstruct P0 from the provisional P1
copy.

The previous raw-index stat-cache transition remains a disclosed historical
observation. Establish a new prospective opening from the actual current raw
index and complete semantic index. Require the semantic index to remain equal to
HEAD and the staged diff to remain empty. Preserve the new opening interval; do
not reset the index or claim the earlier raw bytes were preserved.

Stop before editing on any source, branch, HEAD, tree, upstream, staged-state,
P0-tree, manifest, migration-0006, or authoritative-ref mismatch.

CORRECTED P0 FREEZE SEMANTICS

The P0 checkpoint remains an exact, immutable evidence artifact and attribution
boundary. The final P0-to-P1 candidate is not required to keep every repository
file byte-equal to that checkpoint.

Freeze these P0-owned semantics and bytes:

1. Migration 0006 remains byte-for-byte exact at the fixed SHA-256 above.
2. The P0 private admission contract and SQLite owner remain byte-for-byte exact
   unless a genuine P0 correctness defect is discovered:
   - src/ge_nwp_coordinator/_rw0_c2_scope_admission_contracts.py
   - src/ge_nwp_coordinator/_sqlite_rw0_c2_scope_admission.py
3. P0 retains its four immutable table families, one-fact-per-act, one-fact-per-
   lineage, and one-fact-per-scope uniqueness, separate receipt, exact replay,
   checked readback, and three-way recovery.
4. P0 remains usable before program creation and creates no P1 decision,
   acceptance fact, terminal row, program, or standing authority.
5. The reopened P0 checkpoint ZIP, exact tree, manifest, migration manifest,
   417-node validation evidence, and report remain unchanged historical evidence.

Do not change those frozen P0 production bytes merely to simplify P1. If P1
reveals a genuine defect in those P0-owned bytes or semantics, stop and report it.

The following are cumulative/shared successor surfaces and are NOT byte-frozen:

- sqlite_migration.py;
- sqlite_transition_transaction.py;
- sqlite_writer_session.py;
- shared/current-status documentation and guidance;
- migration catalog, current-tip, schema-count, importer, caller, and assurance
  consumers;
- P0 test files where a checkpoint-context assertion must be separated from the
  cumulative current-tip assertion;
- the physical P0/P1 implementation document, which may add P1 material while
  preserving the P0 checkpoint description.

Additive P1 changes to these shared surfaces are permitted only when P0 behavior,
migration 0006 bytes, exact 0006-prefix compatibility, and the P0 causal controls
remain intact.

REQUIRED TEST-SUCCESSOR TREATMENT

The conflict is not a P0 contract defect. It is a temporal test-scope conflict:
checkpoint tests currently conflate the historical migration-0006 checkpoint
with the later cumulative current catalog.

Explicitly authorize narrow successor edits to:

- tests/test_sqlite_rw0_c2_migration_0006.py
- tests/test_sqlite_rw0_c2_scope_admission.py

and to directly dependent exact current-tip/catalog/identity consumers already
authorized by the preceding mandate.

The successor must preserve both truths:

A. Historical exact-0006 checkpoint truth

- The exact 0006 migration resource and checksum remain fixed.
- A database explicitly at the complete 0006 prefix has exactly six migration
  entries and the exact verified 0006 schema manifest: 68 user tables,
  122 triggers, and five explicit indexes.
- The P1 supplemental and acceptance tables are absent from that exact 0006
  prefix.
- Historical 0006 migration, replay, recovery, compatibility, and older-binary
  assertions remain meaningful and separately testable.

B. Cumulative current-0007 truth

- Public fresh initialization after P1 creates the complete current catalog
  through migration 0007, not the historical 0006 tip.
- Explicit supported-prefix migration advances a complete 0006 database to the
  exact 0007 schema; ordinary writer acquisition and product mutation still do
  not migrate.
- The P1 supplemental tables, including the acceptance-fact table, exist in the
  0007 schema.
- Running P0 against a 0007 database inserts no P1 decision, guarded result,
  generic P1 receipt, acceptance-fact, terminal, or program rows.
- P0's nonaccepting property is proved by zero P1/acceptance row counts and by
  unchanged P0 behavior, not by pretending the later table does not exist.
- Older complete histories and old-binary refusal remain exact.

Do not delete or weaken the historical assertions. Do not replace exact counts
or identities with dynamic self-derived expectations merely to obtain a pass.
Use explicit historical-prefix fixtures and explicit current-tip fixtures. Pin
the final 0007 migration checksum and exact cumulative schema manifest from the
actual final DDL; do not blindly promote the provisional 0007 values if the final
bytes differ.

The previously retained provisional migration 0007 and its test are evidence
only. Reinspect and selectively reuse them if correct, but do not restore the
provisional tree wholesale or grant it implementation credit.

P1 CONTINUATION

Resume Phase B from the authenticated P0 checkpoint under every unchanged
requirement of the preceding implementation mandate, including:

- migration 0007 for P1;
- reuse of existing 0002 decision/version/head/intent/work/membership/edge/
  WorkSpec/result/receipt meanings without changing their v1 semantics;
- the six supplemental immutable P1 families;
- the closed 21-field decision-basis grammar;
- the private typed cognitive replan proposal and Coordinator-owned durable
  authorship;
- the complete attempt_selecting_replan intent/work/WorkSpec/edge/membership/
  version/head family in the same P1 COMMIT;
- all five branches and exact branch-specific state/acceptance behavior;
- checked P0 admission and fresh guard/currentness/matrix evidence for every P1
  command;
- receipt-first replay, full-family readback, one COMMIT attempt, and three-way
  recovery;
- no terminal-outcome persistence, live supplier/custody work, provider/worker,
  ES/Bridge route, Git product effect, service, scheduler, or autonomous loop.

Do not restart P0 implementation. Do not create an intervening contract-only
tranche. Governing docs, source, schema, tests, and assurance successors move
together with P1.

SHARED-SURFACE PRESERVATION

For every P0-checkpoint file changed during P1:

1. classify it as shared cumulative integration, documentation/status successor,
   or checkpoint-test successor;
2. identify the exact P1 dependency requiring the change;
3. show that the P0-owned behavior and exact 0006-prefix contract remain intact;
4. preserve historical predecessor assertions or exact reconstruction where the
   repository uses byte-pinned guards;
5. include an exact P0-checkpoint-to-final diff for that path in the review
   package.

A final candidate may therefore differ from P0 tree fd45f05f..., but the package
must retain and authenticate that checkpoint and prove that P1 did not silently
rewrite the P0-owned migration or private owner.

VALIDATION

The 417-pass P0 checkpoint remains implementation evidence for the exact P0
checkpoint only. It does not automatically validate the final cumulative source.

Before broad P1 validation, establish a source-bound successor checkpoint that
proves:

- exact 0006 historical-prefix schema and absence of P1 tables there;
- exact 0007 current schema and current public initialization tip;
- explicit 0006-to-0007 migration;
- P0 on the 0007 schema still commits/replays/recovers correctly;
- P0 leaves every P1/acceptance/terminal/program row count at zero;
- the frozen P0 migration and private owner bytes remain unchanged.

Then complete the previously required P1 connected checkpoint and causal controls,
followed on identical final bytes by:

1. exact migration 0006 and 0007 tests;
2. complete P0 and P1 physical/recovery tests;
3. connected P0 -> D1/D2 -> Section 41/C1/V22 -> P1 tests for all five
   branches;
4. the full focused contract/migration/authority/assurance selection from the
   preceding mandate;
5. one selector-free collection;
6. one selector-free FULL execution.

Use authenticated external source copies and the isolation rules already fixed.
Reconcile collected, reported, called, and JUnit IDs exactly. No historical count
is a predicted result. Record all failures, warnings, skips, interruptions, and
source before/after identities.

PROVENANCE AND RETURN

Retain the existing P0 checkpoint and report unchanged. Produce a new final
review package containing:

- complete final source;
- the exact reopened P0 checkpoint package/source/manifest;
- exact P0-to-final path comparisons;
- frozen migration 0006 identity and final migration 0007 identity;
- historical 0006 and current 0007 schema manifests;
- all validation and causal-control records;
- final deterministic manifests generated twice;
- prospective index/config/authoritative-ref observations;
- bounded cleanup and preservation records;
- one complete implementation report.

No artifact becomes authority.

STOP CONDITIONS

Stop without staging if:

- the authenticated P0 checkpoint cannot be reproduced exactly;
- migration 0006 or either frozen P0 private-production file must change;
- a historical 0006 assertion cannot be preserved while expressing current
  0007 truth;
- P1 requires changing an existing 0002 meaning;
- any unresolved authority/replan/decision-basis ambiguity remains;
- validation is unavailable, incomplete, interrupted, or mutates final bytes;
- another repository writer or baseline drift appears.

Do not stop merely because a shared current-tip file, current-status document, or
checkpoint-context test must receive a precise additive P1 successor under the
rules above.

EFFECT AUTHORIZATION

Authorized:
- continue editing on the existing local topic branch;
- make the bounded P1 and exact test-successor changes described above;
- run offline isolated validation;
- create task-owned external evidence packages.

Not authorized:
- staging, commit, push, upstream creation, PR, merge, auto-merge;
- independent audit in this conversation;
- network/provider/ES/Bridge/live-service calls;
- user or production database migration;
- live enrollment/custody work;
- terminal persistence, deployment, release, or product effect.

EXPECTED RETURN

On success, return:

RW0_C2_P0_P1_PHYSICAL_PROGRAM_IMPLEMENTED_VALIDATED_PENDING_INDEPENDENT_AUDIT

On a real blocker, return one explicit BLOCKED/PARTIAL disposition with the last
authenticated tree, completed and unperformed coverage, surviving source edits,
and reopened evidence paths.

Return the complete operative report inline and one actual reopened review ZIP
path. Do not create a standalone report-only handoff in place of the inline
report.

End with:
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
MERGE_NOT_PERFORMED
PUBLICATION_NOT_PERFORMED
DEPLOYMENT_NOT_PERFORMED
PRODUCT_EFFECT_NOT_PERFORMED

NEXT RECIPIENT AFTER RETURN

Return to the current Governed Execution ChatGPT project conversation for review
of the cumulative P0/P1 candidate and preparation of a fresh independent audit.
Do not begin audit, commit, or publication yourself.

PROJECT SNAPSHOT

Do not request or create a new Project-source snapshot during this continuation.
The next snapshot point remains after the architecture-defining P0/P1 program is
independently accepted and integrated.
