OBJECTIVE

Repair the exact uncommitted RW0-C2 P0→P1 local-commit status successor after
independent artifact review found six remaining current-status drift passages.

This is a workspace-write continuation in the SAME implementation Codex
conversation that produced the current status successor. The parent is the sole
writer. Do not spawn subagents.

This engagement is documentation-and-direct-assurance only. Preserve the
independently accepted and locally committed P0→P1 implementation unchanged.
Do not edit production Python, SQL, migrations, schemas, public APIs,
configuration, modes, or repository path inventory.

Do not stage, commit, push, open a PR, merge, publish, deploy, or perform a
product effect.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

AUTHENTICATED STARTING SUBJECT

Before editing, authenticate the current exact subject:

- branch:
  `codex/rw0-c2-p0-p1-physical-program-v1`
- HEAD:
  `8704e6c7988250598809f3a0daf88c3e11493488`
- HEAD sole parent:
  `4519630d0db967066beb21b4ace5004e76827716`
- committed HEAD tree:
  `161ed4b544baf970cc26428b9805a106ea0f3edf`
- upstream:
  absent
- committed source paths:
  `315`
- current uncommitted status-successor tree:
  `a34d28a7371b87c0cb874076ad610fd650ad6e72`
- current final source-manifest SHA-256:
  `5f2cf1be469ba4ed76cc426a9f82a5b139d0fbf369f680f57f53833fbd4f2594`
- current worktree delta from HEAD:
  `17 modified, 0 created, 0 deleted`
- current binary full-index patch:
  `46,457` bytes
- current patch SHA-256:
  `db561513e2f2ef4e46d27d95654c586911dc3ee5ec96f11f7fc93cad6bdf6a58`
- current deterministic patch manifest:
  `10,818` bytes
- current manifest SHA-256:
  `5d0c1216497ead0cdf71dd942be3739aa858d0ff2a655c7dff4084b4ff6bb14e`
- staged and unmerged entries:
  none
- live source:
  exact current status-successor bytes
- classified test:
  `tests/test_c2b3_private_atomic_program_initialization.py`
  retains POSIX mode `0600`, Git mode `100644`.

Retained implementation artifacts should remain at:

`/tmp/rw0-c2-status-successor-ZYECR6/`

Require exact identities:

1. `rw0-c2-p0-p1-status-successor-uncommitted-review.zip`
   - bytes: `5,870,499`
   - SHA-256:
     `8844f99b6b918581b5aa73511b9a6c329f594777d105494c3efa5a4f1f3fc95c`

2. `IMPLEMENTATION_REPORT.md`
   - bytes: `11,563`
   - SHA-256:
     `29bb44e089c87cc5be87fc3b877cb573a1872f5e46c8c96f48da38d329e53225`

3. `passage-classification.json`
   - bytes: `33,834`
   - SHA-256:
     `41fd8bdd42fc091c12b617ef7d218f6368a30be68e5e1b7d534cd5694077ad56`

4. frozen 36-module focused selector and 5,373-ID retained records as reported
   by the current implementation closeout.

Stop before editing if the live source, path set, HEAD, branch, upstream, index,
mode, or retained package identities differ. Do not reset, clean, restore,
rebase, switch branches, or rewrite refs to make the opening pass.

NEW INDEPENDENT-REVIEW INPUTS ATTACHED TO THIS MESSAGE

Require:

1. `RW0_C2_P0_P1_LOCAL_COMMIT_STATUS_SUCCESSOR_ARTIFACT_REVIEW_BLOCKED_REPORT.md`
   - bytes: `19,654`
   - SHA-256:
     `d9ea1f450654789accf073e0083feeba2813ff0a4dd0ed102c6f81fbdb587330`

2. `RW0_C2_P0_P1_STATUS_SUCCESSOR_ARTIFACT_REVIEW_EVIDENCE.zip`
   - bytes: `55,595`
   - SHA-256:
     `a8c474fd5d10f9d95d51dd85febd8119867c3aa4769fceac56e373a6e42e95e9`

The review disposition is:

`RW0_C2_P0_P1_LOCAL_COMMIT_STATUS_SUCCESSOR_ARTIFACT_REVIEW_BLOCKED`

The report and evidence ZIP must authenticate before source mutation. If the
evidence ZIP is not attached or has a different identity, stop. Do not infer
review details from the implementation report alone.

INDEPENDENT-REVIEW RESULT TO PRESERVE

The independent review established:

- package, report, baseline tree, successor tree, 17-path delta, modes, raw
  commit, patch, deterministic manifests, and retained focused evidence all
  authenticate;
- all 13 previously edited documents reconstruct their exact committed
  predecessors;
- the four changed assurance tests use fixed actual-file identities and do not
  weaken guards;
- the retained 36-module / 5,373-pass evidence reconciles exactly;
- absence of a selector-free FULL run on the documentation/test successor is
  nonblocking on dependency coverage;
- authority-boundaries and bootstrap-guard target/live passages may remain
  unchanged;
- the historical literal in `tests/test_sqlite_backend_b0_contract.py` may
  remain unchanged;
- six passage classifications are wrong and block acceptance;
- no production/runtime/schema candidate defect was found.

The old blocked verdict remains historical evidence for exact tree
`a34d28a7371b87c0cb874076ad610fd650ad6e72`. This repair creates a new status
successor and requires fresh independent review.

BLOCKING PASSAGES

Reclassify exactly these six rows from the old passage map as
`CURRENT_STATUS_REQUIRES_SUCCESSOR`:

1. `.docs/rw0-c2-scope-admission-provisioning-contract.md`
   - old row 16;
   - current final owner block at lines approximately 321–341 still calls
     `codex/rw0-c2-p0-p1-physical-program-v1` an uncommitted candidate.

2. `.docs/durable-state-model.md`
   - old row 33;
   - final B2/Capability current-status text still says RW0-C2 physical decision
     persistence remains future.

3. `.docs/worker-execution-boundary.md`
   - old row 34;
   - final B2/Capability current-status text repeats that false present-tense
     claim.

4. `.docs/rw0-remote-worker-contact-phase-entry.md`
   - old row 35;
   - current phase map and final D1 status still place C2 physical
     representation/integration in the future.

5. `.docs/rw0-b2-wire-protocol.md`
   - old row 37;
   - broad current/final status still says RW0-C durable facts or C2
     decision/persistence remain future without a later C2 correction.

6. `.docs/rw0-d1-offline-process-and-capsule-spine.md`
   - old row 38;
   - final cross-stage status still says RW0-C2 persistence remains later.

The review accepted all other 32 classification decisions. Do not reopen or
rewrite them without a newly discovered direct contradiction.

FROZEN REPAIR DECISION

Preserve all six stale passages byte-for-byte as historical stage snapshots.
Do not delete, rewrite, normalize, or silently reclassify their original text.

Add exactly one owner-local current successor to each of the six documents,
using the existing marker pair exactly once in each document:

`<!-- RW0_C2_P0_P1_LOCAL_COMMIT_STATUS_SUCCESSOR_BEGIN -->`
`<!-- RW0_C2_P0_P1_LOCAL_COMMIT_STATUS_SUCCESSOR_END -->`

The six new blocks must be independently tailored to their owner. They may
share exact fixed facts and nonclaims, but must not paste irrelevant ownership
language into a subordinate owner.

The current facts common to all six successors are:

- independently accepted implementation tree:
  `161ed4b544baf970cc26428b9805a106ea0f3edf`;
- local implementation commit:
  `8704e6c7988250598809f3a0daf88c3e11493488`;
- sole parent:
  `4519630d0db967066beb21b4ace5004e76827716`;
- local exact-byte commit gate:
  `9,473` collected/executed/JUnit/passed, zero failures/errors/skips and the
  three known Python 3.13 multithreaded-fork warnings;
- no push, upstream, PR, merge, publication, deployment, or product effect was
  performed by that gate;
- Git objects and refs remain commit/publication truth;
- audit, validation, provenance, reports, and status prose remain evidence only;
- the implementation is private, bounded, artificial, and offline;
- P0 records immutable admission history but never current permission;
- P1 records one five-branch durable decision and creates an acceptance fact
  only on `candidate_acceptance`;
- a P1 acceptance fact is not terminal truth, executable permission, live
  custody, runtime admission, or deployment authority;
- Decision Basis v2, guarded-command-digest v2, historical work-head witness,
  universal disclosure posture, and acceptance-only eligibility are the
  current private implementation;
- F03 and F05 remain open nonblocking observations;
- no live enrollment/custody supplier, terminal outcome, production
  provider/worker, ES/Bridge route, product Git effect, public service, queue,
  scheduler, deployment, or autonomous loop exists.

OWNER-SPECIFIC TREATMENT

A. P0 semantic owner

File:
`.docs/rw0-c2-scope-admission-provisioning-contract.md`

Insert the new successor immediately after
`RW0_C2_P0_PHYSICAL_CANDIDATE_SUCCESSOR_END`.

The new block must state:

- the preceding P0 candidate block is a preserved checkpoint-stage description;
- migration 0006 and the four-table P0 private family are now part of the
  independently accepted, locally committed P0→P1 source;
- P0 remains separately attributable and usable before a program;
- P0 creates no P1 decision, current permission, terminal fact, or live
  allowance;
- migration 0007/P1 is owned separately and does not rewrite P0 semantics;
- live supplier/custody gate B remains open.

Do not edit the accepted P0 machine contract or candidate block.

B. Durable-state model

File:
`.docs/durable-state-model.md`

Insert the new successor immediately before
`COORDINATOR_RW0_PHASE_ENTRY_CROSS_REFERENCE_END`.

The block must explicitly supersede only present-tense claims in the preceding
cross-stage status snapshots that RW0-C2 private physical decision persistence
is wholly future. It must preserve that:

- B1/Wire/Capability owners remain pure/private at their own scopes;
- the P0/P1 implementation is private and separate;
- terminal outcome, live provider/custody/runtime, and RW0-E remain future.

C. Worker-execution boundary

File:
`.docs/worker-execution-boundary.md`

Insert the new successor immediately before
`COORDINATOR_RW0_PHASE_ENTRY_CROSS_REFERENCE_END`.

Clarify that:

- this owner still does not own P0/P1 persistence or live runtime;
- the separate Coordinator C2 owner now has locally committed private P0/P1
  physical persistence;
- physical worker transport, live process control, terminal outcome, provider,
  credential, ES route, and runtime remain deferred.

D. Remote-worker phase entry

File:
`.docs/rw0-remote-worker-contact-phase-entry.md`

Insert the new successor immediately before
`COORDINATOR_RW0_PHASE_ENTRY_CONTRACT_END`.

Clarify that:

- earlier phase maps and D1 blocks are preserved stage snapshots;
- private artificial-offline P0/P1 representation, safe values, writers,
  replay/readback, and recovery are now implemented and locally committed;
- this does not make a live accept writer callable;
- terminal-outcome persistence, real supplier/custody, physical worker contact,
  RW0-E, provider, credentials, ES routing, and runtime remain future.

E. B2 Wire owner

File:
`.docs/rw0-b2-wire-protocol.md`

Append the new successor after `RW0_D2_CURRENT_STATUS_END`.

Clarify that:

- Wire remains pure representation/classification and owns no persistence,
  admission, decision, acceptance, or runtime;
- later separate C2 owners now implement the private artificial-offline P0/P1
  durable families;
- the old statements that all RW0-C durability or C2 persistence was future are
  preserved stage snapshots, not current repository status;
- physical transport, process plumbing, live source authentication, provider,
  credentials, ES route, terminal outcome, and RW0-E remain future.

F. D1 process/capsule owner

File:
`.docs/rw0-d1-offline-process-and-capsule-spine.md`

Append the new successor at EOF.

Clarify that:

- D1 still does not own or implement C2 persistence;
- a later separate C2 owner now implements and locally commits private
  artificial-offline P0/P1 persistence;
- D1 capsule/process authority does not widen;
- live supplier/provider/credential, ES route, terminal outcome, publication,
  service, queue, scheduler, and RW0-E remain absent.

PASSAGE CLASSIFICATION SUCCESSOR

Create a new external machine-readable classification successor. Do not alter
the retained blocked review or old 38-row map.

The new map must:

- retain all 38 original rows and their original classifications as historical
  input;
- record the independent review's six classification corrections;
- add one row for each of the six new status successors;
- state exact source location, rationale, treatment, direct consumers, and
  predecessor reconstruction;
- distinguish old stage text from new current text;
- record that rows 31, 32 and the historical B0 literal remain accepted
  unchanged.

ASSURANCE REPAIR

Do not merely refresh hashes.

Before editing tests, perform a fresh complete direct-consumer scan over all 315
current source paths, using the independent review's scan as a fixed comparison.
Record the dependency before changing any test.

At minimum, inspect and preserve or update as required:

- `tests/test_rw0_c2_scope_admission_provisioning_contract.py`
- `tests/test_architecture_contracts.py`
- `tests/test_autonomous_software_development_operating_model.py`
- `tests/test_c2b0_durable_state_contract.py`
- `tests/test_remote_worker_pre_execution_planning_contract.py`
- `tests/test_rw0_b2_capability_boundaries.py`
- `tests/test_rw0_b2_wire_boundaries.py`
- `tests/test_rw0_b2_wire_cancellation_control_boundaries.py`
- `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py`
- `tests/test_rw0_remote_contact_phase_entry_contract.py`
- `tests/test_software_development_progression_boundary.py`
- every additional exact literal, path, whole-file identity, marker,
  predecessor-reconstruction, AST, status-map, or inventory consumer proven by
  the scan.

`tests/c2a_contract_support.py` may remain unchanged when it is only an imported
support module and selected importers exercise it.

Required assurance behavior:

1. Pin the complete new current identities of all six documents with fixed
   values.
2. Remove exactly one newly added status block from each final document and
   reconstruct the exact tree-`a34d28...` predecessor bytes.
3. Preserve all prior predecessor chains and the existing thirteen-document
   successor assurance.
4. Preserve the old stale paragraphs as exact historical stage evidence.
5. No test may continue to present the old C2-future/uncommitted assertion as
   the current repository status.
6. Tests that retain old exact literals must explicitly classify them as
   historical and require the new current successor.
7. Add bounded negative controls for:
   - omitted successor;
   - duplicate successor;
   - reordered marker;
   - changed accepted tree or local commit;
   - false publication claim;
   - P0-current-permission overclaim;
   - terminal/live/ES/Bridge/product-Git/autonomy overclaim;
   - deletion or mutation of the protected historical block.
8. Use fixed expected hashes/bytes. Do not derive expected values from the file
   under test.
9. Do not skip, xfail, disable, broad-normalize, or weaken an existing guard.
10. Give separate causal credit only to predicates actually reached by each
    negative specimen.

EXPLICIT NON-GOALS

Do not edit:

- `.docs/authority-boundaries.md`;
- `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md`;
- `tests/test_sqlite_backend_b0_contract.py`;

unless a new exact source contradiction—absent from the accepted review—is
proved before mutation. The review expressly accepted those passages/tests
unchanged.

Do not change any existing thirteen status successors except direct fixed
identity/consumer updates required by the six appended blocks.

AUTHORIZED FILE CEILING

Authorized repository changes:

- the six documents named above;
- existing direct test/assurance consumers established by the fresh scan.

Not authorized:

- any `src/ge_nwp_coordinator/` path;
- SQL, migration, schema, configuration, public API, package export, mode, or
  repository path addition/deletion;
- any unrelated documentation owner;
- generated evidence inside the repository.

If a production or schema change appears necessary, stop.

FIRST SUBSTANTIVE CHECKPOINT

Before broad validation:

1. save the complete opening and repaired source identities;
2. save the corrected classification map and consumer scan;
3. prove all six old passages remain byte-exact;
4. prove each document contains exactly one new successor at the authorized
   location;
5. remove each new successor and require exact reconstruction of the
   `a34d28...` predecessor endpoint;
6. prove all prior thirteen document predecessor reconstructions still pass;
7. prove the six new current blocks agree on fixed tree/commit/gate facts and
   owner-specific nonclaims;
8. execute all directly changed status/assurance positives and negative
   specimens;
9. verify no production path, mode, migration, or schema byte changed;
10. save, reopen, and member-verify the checkpoint.

FINAL VALIDATION

Run only from a fresh authenticated external copy of the final repaired source.

Required:

1. `git diff --check`;
2. selector-free collection and execution of complete modules in:
   - the prior frozen 36-module selector;
   - every additional directly affected assurance module identified by the
     fresh consumer scan;
3. deduplicate and freeze the selector before execution;
4. exact collected/executed/JUnit identity and order;
5. zero failures, errors, skips, xfails, or xpasses;
6. complete warning inventory;
7. unchanged source bytes and numeric modes before/after collection and
   execution.

Do not assume the prior 5,373 count after adding tests. Freeze and report the new
inventory.

A repository-wide selector-free FULL run is not required unless:

- a production/runtime path changes;
- a direct consumer outside the complete focused selector is affected;
- the focused run reveals an unexplained shared-contract failure;
- source inspection shows an import/runtime dependency.

If any condition occurs, stop rather than silently widening the engagement.

PROVENANCE AND DELIVERY

Use a narrow successor of the existing status-patch provenance outside the
repository. Do not modify the local implementation commit or prior status
package.

At closeout:

- baseline is exact tree
  `a34d28a7371b87c0cb874076ad610fd650ad6e72`;
- record every changed path's before/after bytes, sizes, SHA-256, Git blobs, Git
  modes, and OS modes;
- retain a complete binary full-index patch;
- generate the deterministic repair manifest twice from fresh reads and require
  byte-identical output;
- record complete final source manifest and independently reconstruct the new
  Git-compatible tree;
- retain corrected classification, consumer scan, checkpoint, focused
  collection/execution, ordered IDs, JUnit, warnings, commands, environment,
  source before/after, and cleanup evidence;
- preserve the blocked audit report and evidence ZIP unchanged as historical
  inputs;
- write the implementation report before sealing;
- include a byte-identical copy at `evidence/IMPLEMENTATION_REPORT.md`;
- create one self-contained cumulative status-successor review ZIP containing:
  - complete final 315-file source;
  - exact before endpoints for all changed paths;
  - the prior status-review ZIP/report;
  - the blocked audit report/evidence;
  - old and corrected classification maps;
  - patch/manifests;
  - focused validation;
  - nonclaims;
  - implementation report;
- reopen and verify every member;
- provide an adjacent delivery receipt with ZIP/report bytes and SHA-256.

No report may claim independent acceptance.

STOP CONDITIONS

Stop without staging if:

- opening identity differs;
- the audit attachments do not authenticate;
- any old historical passage cannot remain exact;
- a new successor cannot make current status unambiguous without rewriting an
  accepted machine/semantic contract;
- production, SQL, migration, schema, API, mode, configuration, or new path
  change is required;
- a consumer would need weakening, dynamic expectations, a skip, xfail, or
  broad normalization;
- wording would overclaim publication, live authority, terminal truth,
  executable permission, product execution, or autonomy;
- validation fails or source bytes/modes change;
- the repair touches a path not justified by the six documents and exact
  consumer scan.

EFFECT CEILING

Authorized:

- bounded documentation and direct assurance edits above;
- task-owned external validation and evidence;
- cumulative review-package creation outside the repository.

Not authorized:

- production/source/schema/migration edits;
- subagents;
- staging;
- commit;
- push;
- upstream creation;
- PR;
- merge;
- publication;
- deployment;
- network/service contact;
- provider/worker/ES/Bridge/product database use;
- terminal persistence or product effect.

REQUIRED FINAL RESPONSE

Return one of:

- `RW0_C2_P0_P1_STATUS_SUCCESSOR_CURRENT_DRIFT_REPAIR_IMPLEMENTED_VALIDATED_PENDING_REVIEW`
- `RW0_C2_P0_P1_STATUS_SUCCESSOR_CURRENT_DRIFT_REPAIR_BLOCKED_<PRECISE_REASON>`

Include:

- exact opening commit/tree/branch/upstream and opening successor tree;
- exact final repaired tree;
- complete touched-path list and classifications;
- the six new owner-local successor locations and identities;
- old-passage preservation and predecessor reconstruction results;
- corrected classification summary;
- direct consumer/test treatment;
- first-checkpoint identity and reopen result;
- final focused selector and collected/executed/JUnit reconciliation;
- warnings and source preservation;
- patch/manifests/report/review ZIP identities;
- assumptions, residual observations, and unperformed validation;
- explicit:
  `INDEPENDENT_REVIEW_NOT_PERFORMED`
  `STAGING_NOT_PERFORMED`
  `COMMIT_NOT_PERFORMED`
  `PUSH_NOT_PERFORMED`
  `PR_NOT_CREATED`
  `MERGE_NOT_PERFORMED`
  `PUBLICATION_NOT_PERFORMED`
  `DEPLOYMENT_NOT_PERFORMED`
  `PRODUCT_EFFECT_NOT_PERFORMED`

The next recipient after a successful result is a fresh read-only Codex
artifact-review conversation. Do not start that review in this implementation
conversation.
