OPENING-TREE IDENTITY CORRECTION — CONTINUE THE SAME GATE

This message corrects one typographical error in the immediately preceding
RW0-C2 status-successor architecture-map placement repair mandate.

Do not restart the tranche, restore source, or discard the current candidate.
Continue in the SAME write-enabled implementation Codex conversation.

The prior blocked result remains truthful:

`RW0_C2_P0_P1_STATUS_SUCCESSOR_ARCHITECTURE_MAP_PLACEMENT_REPAIR_BLOCKED_OPENING_TREE_IDENTITY_MISMATCH`

It was caused solely by the incorrect tree literal in the handoff. Codex stopped
before editing, testing, staging, or any other repository effect.

WRONG TREE LITERAL IN THE PRIOR HANDOFF

`d078d1836336fef9f5e2e7b27dc0c55fa86e5858`

CORRECT CURRENT UNVALIDATED CANDIDATE TREE

`d078d1836336fef9f5c2e7b27dc0c55fa86e5858`

The corrected tree is the identity independently reconstructed by Codex and
recorded in the retained blocked report.

All other opening anchors remain unchanged, including:

- branch:
  `codex/rw0-c2-p0-p1-physical-program-v1`
- HEAD:
  `8704e6c7988250598809f3a0daf88c3e11493488`
- committed HEAD tree:
  `161ed4b544baf970cc26428b9805a106ea0f3edf`
- upstream:
  absent
- source paths:
  `315`
- opening status-successor tree:
  `a34d28a7371b87c0cb874076ad610fd650ad6e72`
- current source-manifest SHA-256:
  `d70b8f7761a4838fe7bea95e16bff0dbac1049747f8158ff195954ee641a4207`
- current repair patch:
  `45,263` bytes
- current repair patch SHA-256:
  `310e51ca273f2adfec2960f31cad4b1442976542b8b0b8645868745753f2d123`
- current deterministic repair manifests:
  `7,302` bytes each
- current repair-manifest SHA-256:
  `52f0e1e62fb04c861f1f26ebc54c17d55300d217916974545d5c343cff2b68e8`
- staged and unmerged entries:
  none
- classified source mode:
  `tests/test_c2b3_private_atomic_program_initialization.py`
  remains POSIX `0600`, Git `100644`.

Re-run the complete opening authentication using the CORRECT tree above. If all
other anchors match, continue the previously supplied architecture-map placement
repair without changing its strategy, scope, validation, provenance, effect
ceiling, stop conditions, or required final response.

The frozen engineering treatment remains:

1. Preserve the two new status blocks byte-for-byte.
2. Move each block in:
   - `.docs/durable-state-model.md`
   - `.docs/worker-execution-boundary.md`
   from immediately before to immediately after
   `COORDINATOR_RW0_PHASE_ENTRY_CROSS_REFERENCE_END`.
3. Restore exact byte equality of the four shared historical architecture-map
   bodies.
4. Leave `tests/test_architecture_contracts.py` byte-identical.
5. Update only direct fixed identity/location consumers.
6. Run the required checkpoint and complete focused validation from final bytes.
7. Return a cumulative uncommitted review package for fresh independent review.

Do not treat the prior stop as candidate drift, source damage, or a new audit
finding. Do not edit anything beyond the already authorized placement repair
and its exact direct assurance consumers.

Required final disposition remains one of:

- `RW0_C2_P0_P1_STATUS_SUCCESSOR_ARCHITECTURE_MAP_PLACEMENT_REPAIR_IMPLEMENTED_VALIDATED_PENDING_REVIEW`
- `RW0_C2_P0_P1_STATUS_SUCCESSOR_ARCHITECTURE_MAP_PLACEMENT_REPAIR_BLOCKED_<PRECISE_REASON>`

All no-stage/no-commit/no-push/no-publication/no-product-effect constraints from
the preceding mandate remain in force.
