OBJECTIVE

Continue the same independent, artifact-only cumulative audit of the exact
RW0-C2 P0→P1 Decision Basis v2 candidate after correcting one audit-handoff
error in the Phase 1 mode rule.

This is not a new implementation task and not a request to regenerate or
repackage the candidate. Do not edit the source. Continue in the SAME
independent Codex audit conversation that produced the Phase 1
`AUDIT_PROVENANCE_MISMATCH`.

HISTORICAL RESULT TO PRESERVE

Retain the prior provenance-stop report unchanged as the truthful result under
the former rule. It established:

- all three supplied outer identities matched;
- both ZIPs passed their central-directory safety checks;
- all package-inventory members matched;
- standalone and embedded implementation reports matched;
- source bytes, Git blobs, Git modes, retained diff replay, and reconstructed
  Git trees matched;
- 62 of 65 Phase 1 checks passed;
- the only three failed checks were the same OS-mode comparison at the final,
  integrated-baseline, and v2-first endpoints;
- no source review or test execution occurred.

Do not relabel that historical stop as acceptance.

FIXED INPUTS ALREADY PRESENT IN THIS AUDIT CONVERSATION

1. `rw0-c2-p0-p1-decision-basis-v2-uncommitted-review.zip`
   - 13,024,080 bytes
   - SHA-256
     `675748890d754e4cfefe634b78019cfbaa68cdbd6b653657b98dc39b1164ffa0`

2. `RW0_C2_P0_P1_DECISION_BASIS_V2_IMPLEMENTATION_REPORT.md`
   - 20,614 bytes
   - SHA-256
     `a6f2eae980785736ee26276381519b5e45044bb1fbf38e87f41c61d9a33326ec`

3. `Coordinator_PostD2_PR16_SquashSourceCheckpoint_20261024.zip`
   - 3,245,477 bytes
   - SHA-256
     `087990b15ded609615659c0927f849cf656c4b0cabd6de78339add4410a74166`

Do not request, regenerate, or reattach these inputs. Reuse the exact supplied
bytes already authenticated in this audit conversation.

CORRECTION — TWO DISTINCT MODE NAMESPACES

The former mandate incorrectly required one ZIP central-directory mode to prove
both:

1. the Git mode used to reconstruct the source tree; and
2. the observed checkout POSIX mode recorded in the source manifest.

The supplied package deliberately keeps those as separate evidence fields.

The inert package creator at:

`evidence/current/create_review_package_v2.py`

does the following:

- reads each source row's `git_mode`;
- assigns that Git mode to the `source/` ZIP member;
- records the same Git mode in `package-inventory.json`;
- retains `os_mode` separately in
  `evidence/current/canonical-final-1-source-manifest.json`.

Therefore the corrected audit rule is:

A. ZIP member mode authentication

For every `source/` member:

- compare the central-directory Unix mode with the source row's `git_mode`;
- compare it with the corresponding `package-inventory.json` `git_mode`;
- use that Git mode for Git blob/tree reconstruction.

B. Observed checkout-mode evidence

Treat source-manifest `os_mode` as a retained observation of the implementation
checkout, not as the wrapper mode of a package whose recipe explicitly archives
Git modes.

The exact classified exception is:

`tests/test_c2b3_private_atomic_program_initialization.py`

Required final-source row:

- bytes: `26405`
- SHA-256:
  `e12decd7c6a555123828642602c106d42eec7989a20ff11ae8f49457263c92cf`
- Git blob:
  `b58f863a608ed9cd0dcdd6aebb63e0afeae312e3`
- `git_mode`: `100644`
- retained observed `os_mode`: `0600`

Required review-ZIP member mode:

- `source/tests/test_c2b3_private_atomic_program_initialization.py`
- Unix/Git wrapper mode: `100644`

This pair is not contradictory. Git does not encode the checkout's owner-only
permission bit. The package intentionally authenticates the source's Git mode
and bytes while retaining the separately observed checkout mode as evidence.

The final source manifest must contain exactly:

- 314 rows with `os_mode=0644` and `git_mode=100644`;
- one row—the named file—with `os_mode=0600` and `git_mode=100644`.

The integrated-baseline package uses the same Git-mode wrapper convention and
records the same checkout exception. The retained P0 checkpoint stores the
named member with POSIX mode `0600`, which corroborates the historical
classified checkout mode. None of these artifact observations proves the
current live checkout's OS mode.

C. Required limitation

The final audit must state:

- bytes and Git mode of the classified file are independently authenticated;
- historical artifact evidence consistently records the 0600/100644
  distinction;
- an artifact-only audit cannot independently establish the current live
  checkout's POSIX mode;
- a later exact-byte live commit gate must reauthenticate and preserve that
  checkout-mode classification before staging or committing.

Do not classify this explicit packaging convention as a provenance mismatch.
Any different byte, Git blob, Git mode, path, unexpected second OS-mode
exception, or inconsistency in the stated pair remains a real provenance
mismatch.

CORRECTED PHASE 1

Re-run or complete Phase 1 under the corrected rule.

Require all of the following:

1. all three fixed input identities;
2. central-directory safety and bounded expansion;
3. exact 422-member review ZIP and complete 421-member package inventory;
4. standalone/embedded report byte equality;
5. all 315 final source bytes, sizes, hashes, Git blobs, and Git modes;
6. corrected Git-mode versus retained-checkout-mode treatment above;
7. independently reconstructed final tree:
   `8e247b21320f90d2d2cb98d3d165f7fc35f117a8`;
8. independently reconstructed integrated baseline tree:
   `15461a58da8df9ebd63fce734d39a07a50ab87ac`;
9. exact baseline-to-final delta:
   56 modified, 16 created, 0 deleted, 243 unchanged;
10. exact retained tracked-diff replay;
11. authenticated P0 checkpoint tree:
    `fd45f05ff909493ff8984671a02be66d3b48a791`;
12. authenticated Decision Basis v2 first-checkpoint tree:
    `8e247b21320f90d2d2cb98d3d165f7fc35f117a8`;
13. byte-identical final captures and post-cleanup capture;
14. migration identities:
    - 0006:
      `58b2731d52e8e199c010b309a29aa831ffb16d4db4e755d20adb694ce0a7305f`
    - 0007:
      `505d72c9c54f68e248bebab928e76564d45b853068b8b4021ebc708b640e430c`.

Stop with `AUDIT_PROVENANCE_MISMATCH` only for an actual failure under this
corrected evidence model. Preserve the prior failed mode-check record as
superseded audit-method evidence.

MANDATORY SUBSTANTIVE AUDIT

After corrected Phase 1 passes, continue the substantive audit in the same
engagement. Do not return a provenance-only success report.

All obligations from the previously supplied cumulative audit mandate remain
mandatory, including the complete A01–A18 register and exact archive-relative
path:line evidence.

At minimum, complete:

- authority split and artificial-offline effect ceiling;
- P0 grammar, SQL, independent act/lineage/scope uniqueness, replay and
  three-way recovery;
- exact migration-0006 preservation and historical 68/122/5 prefix;
- Decision Basis v1/v2 versioning and the exact 23-field v2 grammar;
- typed validation/review disposition durability, privacy, and decision-snapshot
  bindings;
- shared pure candidate-classification owner;
- exact built-in type gate for `expected_branch`;
- noncircular replan identity and Coordinator-derived refs;
- migration 0007 compatibility and cumulative 74/134/5 schema;
- all five P1 branches and acceptance-only fact;
- fresh writer fencing, immutable rows, both-head CAS/readback, receipt-last and
  one commit attempt;
- historical program-head and work-head witness replay;
- exact F01 stale-currentness and productive-block replay/readback/recovery;
- second-replan historical replay;
- graph roles, collision, partial-family, foreign-family and competing-winner
  handling;
- commit uncertainty, cleanup uncertainty and no hidden retry;
- connected P0→D1/D2→Section 41/C1/V22→P1 composition;
- shared writer/session/controller boundaries;
- F02 exact-type repair and F04 documentation/assurance repair;
- security/privacy/artifact hygiene and explicit nonclaims.

INDEPENDENT EXECUTION

If source review finds no material blocker, independently execute from a fresh
audit-owned copy of the exact authenticated source:

1. the required causal controls from the original mandate;
2. the connected five-branch selection;
3. one selector-free collection;
4. one selector-free FULL execution.

Expected complete inventory:

- 9,438 unique collected IDs.

Require:

- exact collected/executed/JUnit ID equality and order;
- 9,438 passes;
- zero failures, errors or skips;
- exact warning inventory;
- source bytes and numeric modes unchanged before/after;
- independent application of migrations through 0007 confirming
  74 tables, 134 triggers, 5 explicit indexes and generation 2.

The classified source file may be copied into the audit execution tree with
mode 0600 to preserve the retained operational classification. Record the mode
chosen by the audit copy. Do not claim that choice proves the historical or
live checkout mode. Test correctness credit must remain bound to exact source
bytes and the disclosed audit-copy mode.

FINDINGS AND FINAL DISPOSITION

Separate:

1. artifact/source provenance;
2. retained checkout-mode evidence and its artifact-only limit;
3. source correctness;
4. independently observed execution;
5. unperformed coverage.

Return exactly one primary disposition:

- `RW0_C2_P0_P1_DECISION_BASIS_V2_CUMULATIVE_ARTIFACT_AUDIT_ACCEPTED_READY_FOR_COMMIT_GATE`
- `RW0_C2_P0_P1_DECISION_BASIS_V2_CUMULATIVE_ARTIFACT_AUDIT_BLOCKED`
- `AUDIT_PROVENANCE_MISMATCH`
- `RW0_C2_P0_P1_DECISION_BASIS_V2_CUMULATIVE_ARTIFACT_AUDIT_INCOMPLETE`

Acceptance applies only to exact tree
`8e247b21320f90d2d2cb98d3d165f7fc35f117a8` and authorizes only a separately
governed live exact-byte commit gate.

EFFECT CEILING

Still prohibited:

- candidate source edits or repairs;
- live repository or `.git` access;
- network or service access;
- user/product database access;
- staging, commit, push, PR, merge or publication;
- deployment or product effects;
- execution of supplied helper programs.

Audit-authored inspection and isolated test scripts remain allowed.

REQUIRED RETURN

Return one complete inline report and retain one safe audit-evidence ZIP. Include:

- the old Phase 1 stop as historical;
- the corrected mode rule and result;
- exact package/tree/delta/checkpoint/migration identities;
- complete A01–A18 register;
- findings by severity/type;
- exact independently executed commands and causal results;
- collection/FULL reconciliation;
- mode evidence and limitation;
- skipped/unavailable coverage;
- explicit effect record.

Do not request a repackaged candidate merely because the wrapper stores Git
mode while the source manifest retains a separately observed checkout mode.
