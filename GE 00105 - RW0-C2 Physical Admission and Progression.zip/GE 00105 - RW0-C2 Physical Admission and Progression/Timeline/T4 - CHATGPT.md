## Disposition

```text
RECONNAISSANCE_PARTIAL_ACCEPTED
P0_P1_PHYSICAL_DECISIONS_FROZEN_FOR_IMPLEMENTATION
```

Codex made the correct selection: **P0 should be the first saved/reopened checkpoint inside one P0→P1 implementation program**, while P0 and P1 retain separate writers, transactions, receipts, and recovery classifiers. Pasted text

The `PARTIAL` verdict is also legitimate. The report did not merely leave ordinary implementation detail unresolved. It found two authority-bearing gaps:

- who supplies the new accepted intent and WorkSpec for `attempt_selecting_replan`;
- what exact immutable decision basis the P1 writer persists and recovers.

It also left the P0 enrollment/incarnation uniqueness treatment provisional. A READY verdict without resolving those points would have invented authority or hardened an opaque schema. Pasted text Pasted text

I have now made those decisions. No additional broad reconnaissance or standalone semantic-contract tranche is warranted.

## Frozen decisions

### P0

Migration **0006 is P0-only**.

The physical admission fact must enforce the existing semantic rule that changing a fact reference cannot create a second allowance for the same:

- admission act;
- lineage;
- scope.

Those are three independent uniqueness routes—not one composite-only route.

Enrollment, incarnation, authority-process, and storage-custody identities are historical source-bound evidence. They must match the independently verified source, but they do **not** receive standalone SQL uniqueness constraints. Their uniqueness and currentness remain externally owned rather than inferred from SQLite.

### P1 replan authority

The D2 review model remains non-authoritative evidence.

A separate private typed **cognitive replan proposal** supplies the proposed source intent and private `WorkSpecV1`. In this artificial proof it is deterministic fixture/fake cognitive input; no production model route is introduced.

The P1 Coordinator decision owner remains the sole durable author. It recomputes the branch and may adopt that proposal only when the authoritative branch is `attempt_selecting_replan` and every admission, currentness, matrix, guard, collision, and relationship check succeeds.

The replan proposal:

- cannot select or veto the branch;
- is required for `attempt_selecting_replan`;
- must be absent for all other branches;
- remains transient except for its closed safe projection and digests;
- cannot reuse the current accepted-intent or work-revision identities.

The replan transaction must create the new accepted-intent revision, selected work-item revision, WorkSpec safe binding, two revision edges, updated work head, complete new program-version membership closure, resulting program version, and program-head postimage **in the same P1 commit**. It preassigns the later semantic attempt and candidate but does not create them.

This is consistent with the existing 0002 model: replan advances accepted-intent/work state, while `attempt_selecting_replan` carries both resulting intent/work coordinates and prospective attempt/candidate coordinates. It does not permit simply reusing old revisions.

### P1 decision basis

The implementation may use a canonical BLOB, but it is **not an opaque JSON bag**.

The new private decision-basis value has a closed 21-field top-level grammar covering:

- exact P0 act and admission fact;
- exact current decision snapshot;
- V22 proposal-family projection and currentness;
- all five selected decision matrices;
- historical continuity and sole-active bases;
- bootstrap-guard evidence;
- model-recommendation consistency;
- an exact nullable replan safe projection;
- one captured time and self-excluding basis digest.

Every nested value must be an exact typed safe value. Unknown keys, duplicate keys, coercion, Boolean-as-integer, detached donors, and inconsistent repeated coordinates fail before mutation.

The complete membership entries are not duplicated in the BLOB. The basis binds the immutable closure ref/digest; the writer and readback verify the actual immutable membership rows.

### Migration and family split

- **0006:** P0 only, four immutable table families.
- **0007:** P1, reusing existing 0002 decision/version/head/intent/work/membership/edge/WorkSpec/result/receipt meanings unchanged.
- P1 adds the six supplemental immutable families identified by reconnaissance: continuity basis, sole-active basis, decision basis, guarded relation, guarded result, and acceptance fact.
- The generic 0002 receipt remains the only receipt.
- Acceptance fact membership occurs only on `candidate_acceptance`; all branches still reserve and collision-probe its prospective identity.
- P0 committed with P1 absent remains a truthful complete state and implies no decision or acceptance.

## Next Codex handoff

Send this **single prompt** to the **same Codex conversation that produced the reconnaissance report**, after changing that conversation to workspace-write:

:chatgpt-content-reference{index="6"}[**Coordinator RW0-C2 P0→P1 implementation continuation**](sandbox:/mnt/data/Coordinator_RW0_C2_P0_P1_Implementation_Continuation_Prompt.txt)

Do not start a new Codex conversation and do not attach files. The exact repository checkout remains the current source of truth.

The prompt directs Codex to:

1. create a fresh implementation branch from integrated `trunk_dev`;
2. implement and reopen a source-bound P0 checkpoint;
3. freeze P0 bytes internally;
4. continue directly to P1 in the same candidate;
5. implement all five branches, including the fully specified replan family;
6. run focused and selector-free FULL validation;
7. return one uncommitted review package for independent audit.

It authorizes no staging, commit, push, PR, live supplier work, terminal persistence, or product effect.

```text
Prompt size:   24,086 bytes
Prompt SHA-256:
7e58efa9eda7072804ca1c02ef5de835b610d5285cf7eb1a5e4964e49a4760f8
```

**Project snapshot:** no new Project-source snapshot is requested now. The next snapshot point remains after this architecture-defining P0/P1 program is independently accepted and integrated.

**Sources:** Codex’s reconnaissance selection, physical proposals, and explicit unresolved decisions. Pasted text Pasted text Pasted text Authenticated integrated source checkpoint: Coordinator_PostD2_PR16_SquashSourceCheckpoint_20261024.zip[PR #16 squash source checkpoint](sandbox:/mnt/data/Coordinator_PostD2_PR16_SquashSourceCheckpoint_20261024.zip).

**Confidence:** architecture and authority decisions **0.94**; implementation-handoff completeness **0.96**. The physical implementation, validation, and independent audit remain unestablished.
