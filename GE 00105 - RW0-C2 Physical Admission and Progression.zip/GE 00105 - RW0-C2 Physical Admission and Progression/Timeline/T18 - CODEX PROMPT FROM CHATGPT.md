OBJECTIVE

Repair the independently audited RW0-C2 P0→P1 cumulative candidate by replacing
the incomplete 21-field decision basis with a closed decision-basis v2 that
durably binds the exact typed validation and independent-review dispositions
consumed by the reducer.

This is a workspace-write continuation in the SAME implementation Codex
conversation that produced the current uncommitted P0→P1 candidate. The parent
is the sole writer. Do not spawn subagents.

Also complete the two bounded nonblocking audit corrections already selected:

- F02: exact built-in-type enforcement for optional `expected_branch`;
- F04: current migration-tip documentation and the weakened schema-name
  assurance check.

Do not implement F03 or F05 in this engagement. Preserve them as disclosed
nonblocking observations.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

STARTING SUBJECT

Before editing, authenticate the unchanged current subject:

- branch:
  `codex/rw0-c2-p0-p1-physical-program-v1`
- HEAD:
  `4519630d0db967066beb21b4ace5004e76827716`
- HEAD tree:
  `15461a58da8df9ebd63fce734d39a07a50ab87ac`
- upstream: absent
- source paths: 315
- current uncommitted source tree:
  `f6801df592af049a6aaef658f721fc1afe27ad6e`
- canonical source manifest SHA-256:
  `4c03bc2963eae334aab0635928dc5c60d8cf0b7b64fb766298f6bc7759d98d64`
- delta from HEAD:
  54 modified, 16 created, 0 deleted
- tracked binary diff:
  151,441 bytes
- tracked binary diff SHA-256:
  `23fb4c551638920676a6b13c9a19e91d914070368dfc6f72b8ace4449b34591f`
- migration 0006 SHA-256:
  `58b2731d52e8e199c010b309a29aa831ffb16d4db4e755d20adb694ce0a7305f`
- migration 0007 SHA-256:
  `bd2b775787ab79f2ceb6970aa53ca4758781f393300a8f454fface2cc040aefa`
- cumulative schema:
  74 user tables, 134 triggers, 5 explicit indexes
- P0 checkpoint tree:
  `fd45f05ff909493ff8984671a02be66d3b48a791`
- prewriter-v2 checkpoint tree:
  `c467361fc4a2bd01b5e67f464f8c8bbc88b4d17b`
- connected checkpoint tree:
  `f6801df592af049a6aaef658f721fc1afe27ad6e`

Require an empty staged diff. Preserve the prospective provenance interval and
its historical limits. Do not reset, clean, rebase, restore, rewrite refs, or
normalize source to force a match. Stop on any mismatch.

CURRENT AUDIT DISPOSITION

The exact candidate was independently authenticated and received:

`RW0_C2_P0_P1_CUMULATIVE_ARTIFACT_AUDIT_BLOCKED`

The blocking result is established:

- a valid stale-currentness command freshly commits a complete
  `post_execution_program_block` family;
- final durable reason is `decision_basis_not_current`;
- the distinct candidate reason may be
  `candidate_evidence_conclusively_accepted`,
  `candidate_evidence_requires_repair`,
  `candidate_evidence_requires_replan`,
  `candidate_evidence_terminally_rejected`, or
  `candidate_evidence_nonconclusive`;
- the current durable plan persists the final reason but discards
  `candidate_reason_code`;
- the committed 21-field basis contains source coordinates and advisory model
  evidence but not the exact typed validation/review dispositions that determine
  the candidate reason;
- exact replay cannot reconstruct the committed result without guessing;
- checked readback fails and recovery returns `unresolved`.

A read-only implementation diagnostic confirmed that the same sealed basis and
same validation source-observation digest can be paired with four valid typed
validation outcomes that all select the same stale-currentness block and final
reason while producing four different candidate reasons.

No repository file changed during that stop. F02 and F04 remain unmodified.
Earlier implementation validation receives no repair credit.

ARCHITECTURE DECISION — DECISION BASIS V2

Do NOT add a candidate-reason column to a result table and do NOT persist a
redundant derived candidate reason merely to patch replay.

The durable omission is in the decision basis. The accepted correction is:

1. Preserve the existing 21-field decision-basis v1 as the documented,
   uncommitted blocked predecessor.
2. Introduce current private decision-basis v2.
3. V2 adds exactly two closed typed top-level fields:
   - `validation_disposition`
   - `independent_review_disposition`
4. Each field is the exact canonical safe mapping of the existing typed value
   consumed by the P1 reducer. Reuse the existing value constructors and closed
   finite vocabularies. Do not persist raw checker output, narrative, prompt,
   path, process data, or private evidence payload.
5. Candidate reason remains a pure derived value. One shared pure helper must
   derive it from the two persisted typed dispositions. Fresh reduction and
   historical reconstruction must use that same helper.
6. The basis digest binds both dispositions. Therefore the command relation,
   six branch-neutral preassignments, command digest, replan-derived refs,
   WorkSpec digest, relation/result/graph digests, and receipt identities are
   recomputed from the corrected basis. The former identity vector is
   superseded and receives no current validation credit.
7. Historical replay/readback/recovery reconstructs the exact candidate reason
   from persisted basis v2. It does not use `decision.reason_code`, caller
   evidence, current state, or rerun cognition.
8. Fresh application must reject any detached validation/review arguments that
   are not exactly equal to the typed dispositions embedded in basis v2 before
   route probing or target writes. Prefer consuming the basis-owned values
   directly after construction.
9. A complete committed family must verify:
   - basis v2 typed dispositions;
   - derived candidate reason;
   - persisted final decision reason and branch;
   - their finite relationship;
   - complete relation/result/graph/receipt identities.

This is the final authority decision. Do not substitute a result-only field, an
opaque evidence bag, a caller-supplied candidate reason, a placeholder, or a
best-effort reconstruction.

VERSION AND PHYSICAL TREATMENT

- Change the private basis schema ID from:
  `governed-execution.nwp-rw0-c2-decision-basis.v1`
  to a v2 successor.
- Add a `DecisionBasisV2` or equivalently explicit versioned current owner.
  Preserve v1 only as historical contract/test evidence; current P1 mutation
  accepts v2 only.
- Update migration 0007's decision-basis `schema_id` constraint to the v2 ID.
- Keep the same six migration-0007 tables.
- Keep 74 tables, 134 triggers, and 5 explicit indexes.
- Do not add a column or table if the two dispositions are carried inside the
  existing canonical `basis_bytes` BLOB and its digest.
- Migration 0007's bytes and checksum must change. Migration 0006 and every P0
  production byte remain exact.
- Relation v2, historical work-head witness, guarded result v2, and receipt graph
  profile v2 remain unchanged in field shape and role count unless exact source
  inspection proves a schema-ID dependency that requires a narrowly versioned
  successor. Stop rather than silently widening them.
- Existing migration-0002 meanings, generic receipt, `WorkSpecV1`, six
  preassignments, branch meanings, and acceptance-only fact remain unchanged.

DECISION-BASIS V2 CLOSED GRAMMAR

Retain every v1 field in its existing order and semantics. Add the two typed
disposition fields at one explicitly frozen location before `captured_at` and
`basis_digest` (or another single documented location if the current canonical
grammar requires it). Freeze the exact final order in code, docs, and tests.

The v2 validator must require:

- exact built-in dict/list/string/int/bool/null types as applicable;
- exact nested typed constructors for both dispositions;
- no unknown or duplicate keys;
- no bool-as-int;
- exact source/program/version/intent/work/attempt/candidate coordinates against
  the decision snapshot;
- exact source observation ref/digest equality against the snapshot's validation
  and review source entries;
- finite role-specific outcome/reason vocabularies;
- canonical bytes within the existing size ceiling, unless measured final bytes
  demonstrate that a small explicit successor ceiling is required;
- self-excluding basis digest over the complete v2 mapping.

No detached typed disposition may be accepted solely because it shares a source
observation digest.

PURE REDUCER REFACTOR

Factor the candidate classification into one private pure helper, for example:

`derive_candidate_evidence_reason(validation, review)`

The helper must:

- accept only exact existing typed disposition values;
- preserve the current conflict/nonconclusive/severity rules;
- return either the exact five-value candidate-reason vocabulary or the existing
  finite conflict classification;
- be used by fresh branch reduction;
- be used by historical v2 readback;
- have direct finite tests for the complete current input vocabulary and key
  precedence relationships.

The final branch reducer then combines:

- persisted v2 candidate classification;
- persisted proposal currentness;
- the five decision matrices;
- bootstrap guard and replan presence;
- model-recommendation consistency;
- optional expected branch.

Do not change branch semantics.

F01 REQUIRED CAUSAL CONTROLS

A. `decision_basis_not_current`

Using the real private P1 writer and a task-owned database:

1. Construct at least four valid basis-v2 commands sharing the same safe source
   coordinates and stale currentness but containing different valid typed
   validation/review dispositions that derive distinct candidate reasons.
2. Use isolated databases or distinct valid mutation routes as needed.
3. For each:
   - require branch `post_execution_program_block`;
   - require final reason `decision_basis_not_current`;
   - require the exact independently derived candidate reason;
   - freshly commit the complete family;
   - replay the exact same command;
   - require exact checked readback;
   - require read-only recovery `committed_exact`;
   - require byte/value equality between fresh and replay results;
   - require no new row, receipt, version, or head movement on replay/readback/
     recovery.
4. Prove the basis digest and command digest differ when the embedded typed
   dispositions differ.

B. `productive_branch_not_permitted`

Reach the real private writer with a valid productive candidate classification
and matrices that cause the durable block. Require exact candidate reason,
fresh commit, exact replay/readback, and `committed_exact` recovery.

C. `candidate_evidence_nonconclusive`

Reach the real private writer with the nonconclusive candidate class. Require
that final and candidate reasons remain the exact finite nonconclusive value and
that replay/recovery are exact.

D. Tamper and donor controls

- Change either persisted disposition without recomputing the basis digest:
  integrity failure/unresolved, never normalization.
- Recompute a foreign but internally valid basis under an occupied mutation
  route: existing identity conflict, never replay.
- Supply detached transient validation/review values that differ from basis v2:
  reject before route probe/write.
- Other four branches, second-replan historical work-head replay, CAS rollback,
  graph roles, and acceptance-only fact behavior remain unchanged.

F02 — EXACT BUILT-IN TYPE GATE

In the owner of optional `expected_branch`, require before comparison:

- accepted: `None` or exact built-in `str`;
- rejected: every `str` subclass, including equality-overriding subclasses;
- rejected: bool, int, bytes, enums and arbitrary equality objects;
- exact strings retain the finite branch vocabulary and existing mismatch
  behavior.

Add direct pure tests proving the equality override is never invoked and no
durable writer effect is reachable from invalid input.

F04 — DOCUMENTATION AND ASSURANCE

Correct only the affected current-tip/current-status claims in:

- `.docs/sqlite-operations-and-recovery.md`
- `.docs/sqlite-schema-v1.md`

Preserve historical 0004/0005 statements in their actual historical context.
The current uncommitted candidate successor must state that 0007 is the
cumulative candidate tip, explicit administrative migration remains required,
application generation remains 2, and no live/product authority follows.

Strengthen the historical negative in:

`tests/test_rw0_c2_private_value_versioning_contract.py`

The assertion must prove its intended schema/versioning property even though the
current implementation constructs schema IDs. Use a bounded AST/owner-level or
constructor-relationship check. Do not replace it with another incidental
literal search, refresh a hash without semantics, or weaken predecessor/v1/v2
guards.

GOVERNING DOCUMENTATION SUCCESSORS

Update the exact owning documents required by the basis-v2 change, including at
least:

- `.docs/rw0-c2-private-value-versioning.md`
- `.docs/rw0-c2-physical-p0-p1-implementation.md`
- `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
- `.docs/c2b-durable-development-state.md`
- `AGENTS.md` or other direct status/authority owner only where inspection shows
  a current 21-field/v1 assertion.

Preserve decision-basis v1 as the blocked uncommitted predecessor and state why
v2 exists. Do not claim P0/P1 acceptance, commit, publication, live custody,
terminal outcome, or product execution.

AUTHORIZED FILE CEILING

Expected production changes:

- `src/ge_nwp_coordinator/_rw0_c2_progression_contracts.py`
- `src/ge_nwp_coordinator/_rw0_c2_progression_plan.py`
- `src/ge_nwp_coordinator/_rw0_c2_progression_rows.py` only if current row
  validation/schema constants directly depend on basis v1
- `src/ge_nwp_coordinator/_sqlite_rw0_c2_progression.py`
- `src/ge_nwp_coordinator/sqlite_migrations/0007_rw0_c2_progression_decision.sql`
- `src/ge_nwp_coordinator/sqlite_migration.py` only for the changed 0007 checksum
  or exact schema manifest

Expected direct tests:

- `tests/test_rw0_c2_progression_contracts.py`
- `tests/test_rw0_c2_progression_plan.py`
- `tests/test_sqlite_rw0_c2_progression.py`
- `tests/test_sqlite_rw0_c2_connected.py`
- `tests/test_sqlite_rw0_c2_migration_0007.py`
- `tests/test_rw0_c2_private_value_versioning_contract.py`

Expected documents are the five named above plus the two F04 SQLite documents.

Direct existing identity, inventory, migration, caller or assurance consumers may
change only after recording the exact dependency. No new repository path is
expected. No migration 0006/P0 production file, migration-0002 SQL or row owner,
WorkSpec owner, public StateStore/package export, terminal owner, provider/worker
route, ES/Bridge integration, or product Git path is authorized.

FIRST SUBSTANTIVE CHECKPOINT

Before writer-wide validation:

1. Save the complete repaired source identity.
2. Reopen a basis-v2 identity checkpoint proving:
   - exact 23-field grammar and order;
   - exact typed validation/review persistence;
   - four distinct candidate classifications create distinct basis/command
     identities under otherwise shared safe coordinates;
   - the complete noncircular replan identity chain closes from basis v2 through
     WorkSpec;
   - migration 0006/P0 bytes remain exact;
   - migration 0007 applies to 74/134/5 with only the intended basis-v2 schema
     successor and checksum change.
3. Run and save the real F01 durable-block fresh/replay/read/recovery controls.
4. Run F02 controls.
5. Run strengthened F04 assurance.
6. Include unchanged acceptance and replan fresh/replay positives.
7. Reopen and verify the checkpoint before broader validation.

FINAL VALIDATION

Run only from fresh authenticated external copies of FINAL source.

Required gates:

1. direct basis-v2/F01/F02/F04 controls;
2. connected five-branch P0→D1/D2→Section 41/C1/V22→P1 selection;
3. prior focused 49-module selection plus every directly touched assurance or
   migration module not already included;
4. one selector-free collection;
5. one selector-free FULL execution.

Do not assume 9,421 after adding tests. Freeze the final collection before
execution and require:

- unique collected IDs;
- exact collected/executed/JUnit ID equality and order;
- zero failures, errors or skips;
- exact warning inventory;
- source bytes and numeric modes unchanged before/after;
- exact migration 0006 preservation;
- exact final migration 0007 checksum and 74/134/5 schema manifest.

Superseded, interrupted or failed attempts receive no final credit.

PROVENANCE AND DELIVERY

Use the existing versioned provenance approach. Do not invent a new general
framework.

At closeout:

- produce two byte-identical final canonical captures from fresh reads and one
  post-cleanup capture;
- retain source tree, complete changed-path inventory, tracked binary diff,
  recipe bytes/hash, migrations, schema manifests, commands, environments,
  ordered IDs, JUnit, warnings, checkpoints and cleanup evidence;
- preserve historical live-index/ref limits without backdating them;
- write one implementation report BEFORE sealing the package;
- include an exact byte-identical copy of that report in the review ZIP at
  `evidence/IMPLEMENTATION_REPORT.md`;
- provide the same report as a standalone deliverable;
- seal one cumulative review ZIP with complete final source and necessary safe
  evidence;
- reopen and verify every member;
- provide an adjacent delivery receipt with final ZIP bytes and SHA-256;
- report the new Git-compatible source tree.

The report need not and must not contain the ZIP's self-hash. The adjacent
delivery receipt owns the outer ZIP identity.

STOP CONDITIONS

Stop without staging if:

- opening identity differs;
- the exact typed dispositions cannot be safely persisted in the existing basis
  BLOB;
- basis v2 requires a new table or migration 0008;
- migration 0006 or any P0 production byte changes;
- 0002 meanings, WorkSpec, six preassignments, relation/result/profile field
  shapes, or branch meanings would change;
- historical replay still depends on caller-supplied validation/review values;
- any branch loses replay/readback/recovery;
- required validation cannot complete;
- changes outside the authorized/direct-consumer scope are needed without a
  source-grounded dependency;
- authority, security, privacy or durable-state scope would widen.

EFFECT CEILING

Authorized:

- bounded repository source/document/test edits above;
- task-owned external source copies and synthetic SQLite state;
- local test execution;
- inert evidence and review-package creation outside the repository.

Not authorized:

- subagents;
- staging;
- commit;
- push;
- PR;
- merge;
- publication;
- deployment;
- network/service contact;
- live supplier/provider/worker/ES/Bridge use;
- user/product database access;
- terminal persistence or any product effect.

REQUIRED FINAL RESPONSE

Return one of:

- `RW0_C2_P0_P1_DECISION_BASIS_V2_REPAIR_IMPLEMENTED_VALIDATED_PENDING_AUDIT`
- `RW0_C2_P0_P1_DECISION_BASIS_V2_REPAIR_BLOCKED_<PRECISE_REASON>`

Include:

- exact opening/final source identities;
- complete touched-file list and classification;
- decision-basis v1→v2 grammar and version treatment;
- exact persisted validation/review fields;
- candidate-reason derivation owner;
- new noncircular identity vector;
- migration 0006 preservation, new 0007 hash and 74/134/5 manifest;
- F01 durable-block results;
- F02 and F04 treatment;
- checkpoint identity/reopen result;
- connected/focused/FULL commands and results;
- collected/executed/JUnit reconciliation;
- provenance identities;
- standalone/embedded report equality;
- review ZIP path, bytes, SHA-256;
- assumptions, retained F03/F05 observations, skipped/unavailable validation;
- explicit no-stage/no-commit/no-publication/no-network/no-product-effect record.

Retain F03 and F05 as disclosed nonblocking observations. Do not claim they were
fixed.
