ENGAGEMENT ENVELOPE

CURRENT STATE
- The preceding post-D2 native proposal-admission tranche is merged and closed.
- PR #16 was squash-merged into `trunk_dev` as commit
  `4519630d0db967066beb21b4ace5004e76827716`, with sole parent
  `eac7f6df5f281138dd0640c5cd47b9924c8390f8` and source tree
  `15461a58da8df9ebd63fce734d39a07a50ab87ac`.
- The integrated checkout contains 299 tracked source files and is the current
  implementation baseline. No post-D2 repair or publication work remains open.

RECIPIENT
- A fresh read-only Codex reconnaissance conversation for the repository:
  `/Users/ds/Repositories/Governed Execution Coordinator/`
- Do not use the preceding implementation/publication conversation or an
  independent-audit conversation.

ATTACHMENTS
- None.
- Do not request, inspect, or depend on any file in `/Users/ds/Downloads`, any
  checkpoint ZIP, any exported chat history, or any prior report artifact.
- Use only the exact matching repository checkout and its committed source as
  current truth.

AUTHORIZED EFFECTS
- Read-only inspection of repository guidance, docs, source, migrations, tests,
  configuration, and Git objects/refs.
- Bounded read-only explorer subagents as specified below.
- No tests, imports of repository code, database execution, migration execution,
  network access, repository mutation, Git mutation, or publication.

EXPECTED RETURN
- One complete operative reconnaissance report inline in the Codex response.
- No external report file, no Downloads artifact, no freeze package, no ZIP,
  and no generated repository file.
- A READY verdict must be implementation-defining and sufficient to lead
  directly to source/schema implementation.

PROJECT SNAPSHOT
- No new Project-source snapshot is requested before this reconnaissance.
- The exact merged checkout is sufficient for this read-only pass.
- A new Project-source snapshot should be requested only after the selected
  architecture-defining P0/P1 implementation program is integrated, or sooner
  if this reconnaissance finds that the checkout does not match the fixed
  merged baseline.

NEXT ACTION
- After Codex returns, the user will relay the complete inline report to the
  current Governed Execution ChatGPT project conversation.
- If the verdict is `RECONNAISSANCE_READY`, ChatGPT will review the report and
  issue one direct workspace-write source/schema implementation continuation to
  this same Codex conversation.
- There will be no intervening reconnaissance and no standalone
  semantic-contract-only tranche.


# Coordinator RW0-C2 final physical-architecture reconnaissance

## 1. Objective

Perform the **final broad physical-architecture mapping pass** for the next
Coordinator work after the merged post-D2 native proposal-admission tranche.

Compare and decide between exactly these two implementation shapes:

### Shape A — standalone P0

Implement program-independent physical scope-admission provisioning as its own
bounded candidate, with its own schema, writer/readback/replay/recovery,
validation, independent audit, commit, and integration before beginning the
physical C2 decision writer.

### Shape B — one P0→P1 implementation program

Implement one coherent candidate in which program-independent physical
scope-admission provisioning is the **first substantive checkpoint**, followed
in the same implementation program by the physical five-branch C2 decision and
acceptance family. P0 and P1 must retain distinct semantic owners and distinct
transactions even when they share one implementation program or migration
suffix. P0 completion is an internal source-bound checkpoint, not a user relay
or separate approval gate.

Choose one shape. Do not return an undifferentiated menu.

This is the final broad mapping pass. A `RECONNAISSANCE_READY` verdict must
freeze enough architecture, migration, source, test, validation, provenance,
and audit detail that the next action is direct source/schema implementation.
Do not recommend another broad reconnaissance, a preliminary physical-design
spike, or a standalone semantic-contract/documentation tranche.

Do not implement anything in this engagement.

## 2. Repository and baseline gate

Repository:

`/Users/ds/Repositories/Governed Execution Coordinator/`

The preceding tranche is merged and closed. The integrated authority baseline
is:

- `trunk_dev` integration commit:
  `4519630d0db967066beb21b4ace5004e76827716`
- sole parent:
  `eac7f6df5f281138dd0640c5cd47b9924c8390f8`
- complete source tree:
  `15461a58da8df9ebd63fce734d39a07a50ab87ac`
- tracked source count: `299`

Use the repository checkout as the sole current source of truth. Do not read any
checkpoint archive or prior report from Downloads.

Before semantic analysis:

1. Read the repository `AGENTS.md` completely and discover any nested guidance
   applicable to inspected paths.
2. Read `PLANS.md` if present and the governing architecture/authority/status
   documents named below.
3. Record the current branch, HEAD, upstream, worktree status, index status,
   complete Git tree, local `trunk_dev`, and locally available integration
   commit identity using read-only Git commands.
4. Require a clean source checkout whose complete tree is exactly
   `15461a58da8df9ebd63fce734d39a07a50ab87ac`.
5. Require local `trunk_dev` to resolve to
   `4519630d0db967066beb21b4ace5004e76827716`.

The checkout may remain on a clean preserved topic commit only if its complete
source tree is the exact integrated tree above and local `trunk_dev` has the
fixed squash identity. Do not switch branches, fetch, pull, reset, clean,
rebase, update refs, or change configuration.

If source identity, local integration identity, or worktree cleanliness does
not match, return `RECONNAISSANCE_BLOCKED`. Do not normalize drift into a new
baseline. Turn-diff capture/checkpoint refs are diagnostic observations, not
source authority; report them separately and do not use total-ref equality as
the source gate.

## 3. Current implemented boundary

Treat these as current integrated facts, not target behavior:

1. One original artificial D2 run is continued once.
2. Native Section 41 transaction A records one post-execution
   proposal/context/receipt family.
3. A fresh guarded read reconstructs and checks the persisted owner rows.
4. A separate C1 transaction B admits one rank-15 member.
5. Fresh A/B readbacks feed unchanged pure V22.
6. Migration `0005_section41_post_execution_proposal_family` belongs only to
   the Section 41 family and remains application generation 2.
7. No physical scope-admission provisioner, scope-admission fact, C2 decision,
   C2 acceptance fact, terminal outcome, live supplier, production worker,
   ES/Bridge route, product Git effect, service, queue consumer, scheduler, or
   autonomous loop exists.

Do not report target C2 behavior as implemented.

## 4. Target architecture to map

The accepted target documents define, but do not physically implement:

- one externally admitted authority lineage and bootstrap scope;
- one program-independent immutable scope-admission fact;
- one permanently non-replenishable productive-acceptance ceiling;
- one separate scope-admission recording operation;
- one later five-branch C2 progression decision;
- one immutable acceptance fact only on the acceptance branch;
- exact replay and whole-family three-way recovery;
- later terminal-outcome persistence; and
- live work only after independently satisfied supplier/custody prerequisites.

Physical representation, migration allocation, transaction integration,
readers/writers/recovery, production callers, and runtime remain reopened.
Migration 0005 is already consumed; any new physical suffix begins no earlier
than 0006.

## 5. Required decision: standalone P0 versus one P0→P1 program

Evaluate both shapes against the current source and select one.

### 5.1 Required comparison criteria

For each shape, analyze:

1. **Authority and ownership**
   - whether scope admission and C2 decision remain separately owned;
   - whether any proposed convenience transaction improperly merges owners;
   - whether one authoritative writer remains responsible for each mutable or
     immutable fact.
2. **Physical coupling**
   - whether P1 requires P0 tables, identities, FKs, readsets, or migration
     decisions that make a standalone P0 commit likely to harden temporary
     architecture by inertia;
   - whether P0 has stable, independently useful physical meaning without P1.
3. **Migration strategy**
   - P0-only 0006 followed by P1 0007;
   - one shared 0006 containing separately owned P0 and P1 families; or
   - another source-grounded additive allocation.
   Preserve migrations 0001–0005 byte-for-byte.
4. **Transaction and recovery design**
   - separate transaction ownership;
   - replay, collision, no-write conflict, commit uncertainty, and three-way
     recovery;
   - failure after P0 commits but before P1 commits.
5. **Checkpoint and validation quality**
   - whether P0 can serve as a meaningful first substantive checkpoint inside
     a larger candidate;
   - whether standalone P0 creates useful acceptance evidence or only defers
     the decisive connected proof;
   - whether one program can retain a reopened P0 checkpoint before expanding
     into P1 without obscuring fault attribution.
6. **Auditability and repair containment**
   - candidate size and sensitive surfaces;
   - independent audit perspectives;
   - whether a P1 finding would force unnecessary re-review of stable P0 bytes;
   - how exact provenance would preserve checkpoint lineage.
7. **Product and sequencing value**
   - whether the selected shape advances durable program progression rather
     than merely accumulating another isolated fact;
   - whether it preserves later terminal and live boundaries.

### 5.2 Mandatory conclusion

Return one of:

- `SELECT_STANDALONE_P0`, or
- `SELECT_SINGLE_P0_TO_P1_PROGRAM`.

A READY verdict must explain why the rejected shape is inferior under the
current contracts and source. Do not defer the choice to implementation.

If selecting the single P0→P1 program, freeze P0 as the first saved/reopened,
source-bound implementation checkpoint and define exactly how implementation
continues to P1 in the same candidate without a user-mediated handoff.

If selecting standalone P0, freeze enough of P1 now that no later broad
physical-architecture reconnaissance is required; identify only bounded
implementation-specific refinements that may remain.

## 6. Required source reading

Read complete relevant sections, not isolated search hits. Expand the list only
when a directly dependent surface is discovered, and state every expansion.

### 6.1 Governing and composition

- `AGENTS.md`
- `PLANS.md` if present
- `README.md`
- `.docs/autonomous-software-development-operating-model.md`
- `.docs/architecture.md`
- `.docs/authority-boundaries.md`
- `.docs/c2b-durable-development-state.md`

### 6.2 Integrated post-D2 owner

- `.docs/rw0-d2-offline-evidence-and-review.md`
- `.docs/section41-post-execution-proposal-family.md`
- `src/ge_nwp_coordinator/_rw0_d2_post_execution_continuation.py`
- `src/ge_nwp_coordinator/_sqlite_section41_post_execution_proposal.py`
- `src/ge_nwp_coordinator/_section41_post_execution_proposal_family_projection.py`
- `src/ge_nwp_coordinator/_section41_post_execution_role_resolution.py`

### 6.3 P0 and P1 semantic owners

- `.docs/rw0-c2-scope-admission-provisioning-contract.md`
- `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
- `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md`
- `.docs/rw0-c2-private-value-versioning.md`
- `.docs/rw0-c2-first-live-proof-posture.md`

### 6.4 Existing private and physical foundations

- `src/ge_nwp_coordinator/_rw0_c_decision_input_values.py`
- `src/ge_nwp_coordinator/_development_decision_row_values.py`
- `src/ge_nwp_coordinator/_development_program_row_values.py`
- `src/ge_nwp_coordinator/_sqlite_development_readers.py`
- `src/ge_nwp_coordinator/_sqlite_development_reader_contracts.py`
- `src/ge_nwp_coordinator/_development_program_initialization_contracts.py`
- `src/ge_nwp_coordinator/_sqlite_development_program_initialization.py`
- `src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql`
- `src/ge_nwp_coordinator/sqlite_migrations/0005_section41_post_execution_proposal_family.sql`
- `src/ge_nwp_coordinator/sqlite_migration.py`
- `src/ge_nwp_coordinator/sqlite_writer_session.py`
- `src/ge_nwp_coordinator/sqlite_transition_transaction.py`
- `src/ge_nwp_coordinator/sqlite_transition_read_scope.py`
- `src/ge_nwp_coordinator/sqlite_security.py`
- `src/ge_nwp_coordinator/sqlite_connection.py`

### 6.5 Tests and assurance consumers

At minimum inspect:

- `tests/test_rw0_c2_scope_admission_provisioning_contract.py`
- `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py`
- `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`
- `tests/test_rw0_c2_private_value_versioning_contract.py`
- `tests/test_rw0_c2_first_live_proof_posture_contract.py`
- `tests/test_c2b2_development_decision_row_values.py`
- `tests/test_sqlite_c2b2_migration_0002.py`
- `tests/test_post_execution_pure_owner_boundaries.py`
- `tests/test_post_execution_pure_owner_relations.py`
- `tests/test_post_execution_pure_owner_values.py`
- `tests/test_post_execution_pure_owner_vectors.py`
- `tests/test_c2b0_durable_state_contract.py`
- `tests/test_runtime_non_authority.py`
- `tests/test_c2a_nonimplementation.py`
- `tests/test_sqlite_b1_migrations.py`
- `tests/test_sqlite_c2b1_migration_framework.py`
- `tests/test_architecture_contracts.py`
- `tests/test_autonomous_software_development_operating_model.py`

Inspect all directly referenced caller inventories, complete-file identity pins,
migration-tip/count/schema manifests, no-0006/nonimplementation assertions,
status literals, public-surface guards, and import/AST boundaries.

## 7. Decisions the report must freeze

A READY report must settle all items below. An unresolved item that would change
physical schema, owner split, migration allocation, transaction semantics, or
acceptance evidence requires `RECONNAISSANCE_PARTIAL` or
`RECONNAISSANCE_BLOCKED`, not a READY verdict.

### 7.1 Owner and data-flow map

- exact P0 writer, reader, replay, recovery, and receipt owner;
- exact P1 decision/acceptance writer, reader, replay, recovery, and receipt
  owner;
- external-source observations versus immutable Coordinator facts;
- transient projections versus durable rows;
- model/V22 evidence versus authoritative decision inputs;
- the handoff from recorded admission to a later C2 command;
- the source of artificial offline permission/custody evidence without
  pretending to satisfy live supplier gate B.

### 7.2 Physical P0 design

Freeze:

- exact logical family members;
- command, basis, result, receipt, replay selector, and readback values;
- exact tables, columns, types, keys, unique routes, FKs, triggers, indexes, and
  row-digest/graph-digest order;
- collision and alias behavior;
- fresh apply, receipt-first exact replay, no-write conflict classes,
  one-commit uncertainty, and three-way read-only recovery;
- what is retained versus independently resolvable;
- proof that no program, C2 decision, acceptance fact, or terminal fact is
  created by P0.

### 7.3 Physical P1 design

Freeze:

- exact command/basis/currentness inputs and admitted-scope relation;
- exact five-branch physical family;
- which migration-0002 decision/version/head/result/receipt rows are reused
  unchanged;
- all supplemental tables or immutable relations genuinely required;
- acceptance-fact membership only on the acceptance branch;
- no-write rejection, durable block, terminal reject, repair/replan, and
  acceptance outcomes;
- replay, competing winner, commit uncertainty, and whole-family recovery;
- the failure state after P0 commit but before P1 commit;
- what remains deferred to terminal persistence.

### 7.4 Migration allocation

Select and justify the exact additive suffix strategy.

The report must state:

- whether 0006 is P0-only, P0+P1, or another exact allocation;
- whether P1 requires a later suffix;
- application-generation treatment;
- explicit migration-only upgrade behavior;
- exact catalog/tip/table/trigger/index/FK/count consumers affected;
- preservation of migrations 0001–0005 byte-for-byte;
- how an older binary refuses a newer complete catalog;
- why the selected split will not force a later physical redesign merely to
  connect P0 and P1.

### 7.5 Implementation file map

Return the exact proposed touched-file set for the selected implementation
shape. Classify every path as:

- governing documentation/current-status successor;
- migration/catalog;
- private values/row values;
- writer/reader/recovery;
- transaction/session integration;
- program-independent admission integration;
- C2 decision/acceptance integration;
- tests/fixtures/causal controls;
- assurance identity/import/nonimplementation successors.

Name proposed new files exactly. Identify existing files that should remain
semantically untouched and why.

There will be no standalone semantic-contract tranche. The implementation must
move governing docs, schema, source, and tests together. The reconnaissance
report itself is the architecture freeze used by the implementation prompt.

### 7.6 Checkpoints and validation

Define exact implementation evidence for the selected shape.

At minimum:

1. **P0 first substantive checkpoint**
   - actual artificial verified-act/enrollment/custody inputs;
   - program-independent admission record before any program exists;
   - exact checked readback;
   - exact replay, collision, precommit no-write, before/after-COMMIT
     uncertainty, and three-way recovery;
   - proof that no program/decision/acceptance/terminal row exists.
2. **P1 connected checkpoint**, if included in the selected program
   - consumes checked P0 admission and current guard posture;
   - exercises all five branches;
   - writes acceptance fact only on acceptance;
   - proves P0 committed/P1 not committed remains truthful;
   - proves checked replay/readback and later terminal absence.
3. **Compatibility and preservation**
   - migration 0001–0005 byte equality;
   - existing post-D2 Section 41/C1/V22 behavior;
   - no public API or production caller widening;
   - no live supplier, ES/Bridge, worker, service, scheduler, or Git effect.
4. **Validation plan**
   - exact targeted and focused selectors;
   - one selector-free FULL collection and execution on final bytes;
   - source-before/source-after inventories;
   - runtime and warning accounting;
   - causal-credit limits.
5. **Independent audit plan**
   - contract/authority;
   - durable-state/transaction/recovery;
   - migration/schema/compatibility;
   - security/privacy/live-boundary;
   - validation/provenance/artifact hygiene.

Do not execute any validation now.

### 7.7 Provenance and implementation handoff

Define the exact implementation provenance package needed later, including:

- baseline branch/HEAD/tree;
- complete changed and created path inventory;
- per-file bytes, modes, hashes, and Git blobs;
- deterministic binary diff and canonical manifest;
- migration preservation evidence;
- first checkpoint and final validation bindings;
- source-bound P0 checkpoint identity if the single P0→P1 program is selected;
- final candidate identity;
- cleanup and prospective protected-state observations.

Do not invent a new general evidence framework. Reuse the repository's current
provenance conventions and version only what the selected path inventory or
physical design requires.

## 8. F2 and other inherited limits

F2 power-loss durability remains unresolved.

- It blocks live/permanent durability and effect-safety claims.
- It does not by itself block an explicitly artificial offline P0/P1 proof over
  task-owned disposable state.
- Do not change journal mode or synchronous posture in this reconnaissance.
- Freeze exact documentation/test wording that prevents the implementation from
  being mistaken for live or power-loss-safe acceptance.

Qualified F3/F6/F7, cross-host clock ordering, F03, historical raw-index/ref
limits, and the low semantic-specimen causal-credit observation remain outside
the implementation unless a direct source dependency proves otherwise.

Terminal-outcome persistence and RW0-E live work remain later separately
governed tranches.

## 9. Read-only subagent workflow

Use exactly four read-only explorer agents in parallel. Give each a
self-contained context capsule. No nested delegation.

1. **Contract, authority, and sequencing explorer**
   - compare standalone P0 against the single P0→P1 program;
   - inspect semantic owners, accepted target order, nonclaims, and owner split;
   - return one recommended shape and exact reasons.
2. **Physical schema, migration, and transaction explorer**
   - map migration 0002 and 0005;
   - design P0 and P1 tables/relations/transaction/recovery boundaries;
   - select the additive suffix strategy and compatibility treatment.
3. **Source, caller, and assurance dependency explorer**
   - map exact source entry points, readers, writers, values, tests, complete-file
     pins, migration/status/import/nonimplementation consumers;
   - return the exact touched-file proposal and protected untouched surfaces.
4. **Validation, security, live-boundary, and audit explorer**
   - design P0 and P1 checkpoints, causal controls, focused/FULL validation,
     provenance, and independent audit;
   - preserve F2 and supplier/custody/live boundaries.

Each agent must:

- cite exact repository-relative paths and line ranges;
- distinguish current contract, accepted target, inference, and uncertainty;
- name uninspected scope;
- perform no mutation, imports, tests, database work, network calls, or artifact
  creation;
- return findings to the parent inline only.

The parent must wait for all four, preserve material disagreements, close every
agent, recheck source identity and worktree cleanliness, and then produce one
consolidated decision.

## 10. Effect ceiling

This engagement is read-only.

Do not:

- edit, create, delete, format, or chmod repository files;
- write a report file anywhere;
- create a ZIP, checkpoint, freeze package, manifest, or external artifact;
- inspect `/Users/ds/Downloads` or any checkpoint/archive/report there;
- execute pytest, repository imports, helper programs, migrations, SQLite
  fixtures, or database commands;
- install dependencies;
- switch branches, fetch, pull, reset, clean, rebase, update refs, stage,
  commit, push, open or modify a PR, merge, or publish;
- change Git configuration, hooks, worktrees, index, refs, or ignored state;
- contact a provider, network, GitHub, ES, Bridge, service, or user database;
- implement P0, P1, terminal, worker, scheduler, supplier, or live behavior.

Ordinary read-only source and Git-object inspection is allowed. Any unexpected
source or Git-state change is blocking.

## 11. Required inline return

Return the complete operative report **inline in the Codex response**. Do not
save it to a file and do not return a path, byte count, SHA-256, ZIP, package, or
freeze artifact.

Use exactly these sections:

1. **Verdict**
   - `RECONNAISSANCE_READY`, `RECONNAISSANCE_PARTIAL`, or
     `RECONNAISSANCE_BLOCKED`.
2. **Authenticated checkout and inspection boundary**
   - branch, HEAD, upstream, tree, clean state, local integration identity;
   - guidance read and scope not inspected.
3. **Current contract / accepted target / reopened seam ledger**.
4. **Standalone P0 versus single P0→P1 comparison**
   - one explicit selection;
   - rejected shape and exact reasons.
5. **Frozen owner and authority split**.
6. **Frozen P0 physical design**.
7. **Frozen P1 physical design and P0→P1 handoff**.
8. **Migration allocation and compatibility decision**.
9. **Exact touched-file and protected-untouched map**.
10. **First checkpoint, connected checkpoint, causal controls, validation,
    provenance, and independent-audit plan**.
11. **F2/live-boundary treatment and explicit nonclaims**.
12. **Assumptions, residual bounded implementation questions, and stop
    conditions**.
13. **Implementation transition**
    - `NEXT_RECIPIENT: current Governed Execution ChatGPT project conversation`
    - `NEXT_ACTION_IF_READY: direct workspace-write source/schema implementation
      continuation to this same Codex conversation`
    - `INTERVENING_SEMANTIC_CONTRACT_TRANCHE: prohibited`
    - `NEW_PROJECT_SNAPSHOT_REQUESTED_NOW: no`
    - `NEXT_PROJECT_SNAPSHOT_POINT: after the selected architecture-defining
      P0/P1 implementation program is integrated`

## 12. READY standard

Return `RECONNAISSANCE_READY` only when:

- one implementation shape is selected;
- owner and authority splits are frozen;
- P0 and P1 physical representations are frozen to implementation-level detail;
- migration allocation is selected;
- transaction, replay, conflict, uncertainty, and recovery behavior are fixed;
- exact touched files and assurance consumers are mapped;
- checkpoints, validation, provenance, and audit are executable without another
  broad design pass; and
- no unresolved question remains that could change schema, migration numbering,
  owner boundaries, acceptance semantics, or the candidate's effect ceiling.

A READY report leads directly to source/schema implementation. It must not
recommend an intervening contract freeze, documentation-only tranche, schema
spike, or additional reconnaissance.

If required evidence cannot settle a physical or authority decision, return
`RECONNAISSANCE_PARTIAL` or `RECONNAISSANCE_BLOCKED` with the exact missing
source fact and the implementation decision it prevents.
