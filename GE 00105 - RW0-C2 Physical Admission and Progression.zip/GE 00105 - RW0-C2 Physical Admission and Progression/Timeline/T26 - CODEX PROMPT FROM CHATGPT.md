OBJECTIVE

Repair the two material findings from the independent cumulative artifact audit
of the exact RW0-C2 P0→P1 Decision Basis v2 candidate:

F1. `expected_branch` is a validated optimistic assertion but is not covered by
the persisted exact command identity, so a changed assertion can replay the
original committed family.

F2. protected P1 read/replay/recovery can disclose a committed result without
fresh positive disclosure posture from `ArtificialDecisionGuardSourceV1`.

This is a workspace-write continuation in the SAME implementation Codex
conversation that produced the current uncommitted P0→P1 candidate. The parent
is the sole writer. Do not spawn subagents.

Do not change the P0/P1 physical architecture, SQL table families, migration
allocation, branch meanings, Decision Basis v2 grammar, WorkSpec semantics,
relation/result/receipt-profile v2 shapes, or terminal/live boundaries.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

AUTHENTICATED STARTING SUBJECT

Before editing, authenticate the exact unchanged candidate:

- branch:
  `codex/rw0-c2-p0-p1-physical-program-v1`
- HEAD:
  `4519630d0db967066beb21b4ace5004e76827716`
- HEAD tree:
  `15461a58da8df9ebd63fce734d39a07a50ab87ac`
- upstream: absent
- source paths: 315
- current uncommitted Git-compatible source tree:
  `8e247b21320f90d2d2cb98d3d165f7fc35f117a8`
- final source-manifest SHA-256:
  `894f3a690cd5457415260f5a5a35650764b11ed3203c28672649835df705ba12`
- cumulative delta from HEAD:
  56 modified, 16 created, 0 deleted, 243 unchanged
- tracked binary diff:
  175,268 bytes
- tracked binary diff SHA-256:
  `84c06bcf171be8c7bdf6a494ec3e6b9705c06ba34b729cd517789dd05f7b001c`
- final canonical-capture SHA-256:
  `3f577596d66581f5a992d0ce6eb519d49840b15e976c99dfe3f2e6870acf38c0`
- semantic index SHA-256:
  `377904010960fb2b7fdaf5caf8eb6135880a1ba85f1e86be9841795430f76f21`
- raw index SHA-256:
  `ff0440db74511629c310a0b1a49000b56fddcaf7464334d892a4a252fa2221bb`
- configuration SHA-256:
  `8cec84aeea4df3bd9701b05835eb36cf4038c8c116f539f60b0df685f956beca`
- historical complete `git show-ref -d` observation SHA-256:
  `ab5bc35302df7eb9385527c9b16fdc77dc182e391cdd0cb43a8405567a677ce9`
  This is retained historical evidence from the preceding implementation
  closeout. It is NOT the current opening acceptance target.
- migration 0006 SHA-256:
  `58b2731d52e8e199c010b309a29aa831ffb16d4db4e755d20adb694ce0a7305f`
- migration 0007 SHA-256:
  `505d72c9c54f68e248bebab928e76564d45b853068b8b4021ebc708b640e430c`
- cumulative schema:
  74 user tables, 134 triggers, 5 explicit indexes, application generation 2
- P0 checkpoint tree:
  `fd45f05ff909493ff8984671a02be66d3b48a791`
- Decision Basis v2 first-checkpoint/final tree:
  `8e247b21320f90d2d2cb98d3d165f7fc35f117a8`
- review ZIP:
  13,024,080 bytes
  SHA-256
  `675748890d754e4cfefe634b78019cfbaa68cdbd6b653657b98dc39b1164ffa0`
- standalone/embedded implementation report:
  20,614 bytes
  SHA-256
  `a6f2eae980785736ee26276381519b5e45044bb1fbf38e87f41c61d9a33326ec`

Require an empty staged diff. Preserve the established prospective provenance
interval and the historical index/ref limits. Do not reset, clean, rebase,
restore, rewrite refs, or normalize source to force a match.

REF-POLICY CORRECTION

The previous mandate incorrectly made the aggregate SHA-256 of every
`git show-ref -d` line an immutable opening gate across separate turns. That
aggregate includes platform-owned turn-diff capture/checkpoint refs whose
creation and removal are not candidate-source authority.

Preserve the former full-ref hash as a historical observation. Do not require
the current complete ref set to reproduce it, and do not describe the historical
transition as resolved.

At the corrected opening:

1. Capture the complete current sorted `git show-ref -d` inventory losslessly.
2. Classify as qualified diagnostic ONLY direct refs whose names begin with
   exactly one of:
   - `refs/codex/turn-diffs/captures/`
   - `refs/codex/turn-diffs/checkpoints/`
3. Every other ref is authoritative for this prospective interval. This
   includes every local branch, remote-tracking branch, tag, note, stash,
   replace ref, bisect ref, and any other namespace.
4. Require all named source-selection anchors from this mandate to match:
   current branch, HEAD, HEAD tree, `trunk_dev`, `origin/trunk_dev`, absent
   upstream, baseline commit, and the exact source tree/manifest/diff.
5. Require:
   - `git replace -l` empty;
   - no graft file;
   - no alternate object database;
   - one expected worktree only;
   - no unexpected symbolic-ref or source-selection mechanism;
   - configuration, raw index, semantic index, source and staged state at their
     fixed anchors.
6. For every current diagnostic ref:
   - retain its full name and OID;
   - require a direct ref;
   - require its target to resolve to an existing commit or tree object;
   - prove no source, test selection, configuration, migration, validation,
     package, publication or policy input depends on its name or OID.
7. If the exact old-to-current ref delta is recoverable from the visible tool
   record or retained stop record, report it. Do not invent a missing historical
   inventory and do not make continuation contingent on reconstructing one that
   was never retained.
8. Freeze the complete current authoritative-ref map as the prospective opening
   target. Require it byte-identical through both final captures and cleanup.
9. Qualified diagnostic additions/removals during the engagement are retained
   as sidecar evidence and do not block by themselves. A surviving diagnostic
   name may not retarget. Any ref outside the two exact diagnostic namespaces,
   any diagnostic retarget, any invalid object type, or any source-selection
   dependency is blocking.
10. Do not create, delete, restore, retarget or otherwise mutate any ref.

Version the existing external provenance recipe narrowly:

- preserve `provenance_recipe_v4.py` and every prior output unchanged;
- create `provenance_recipe_v5.py` outside the repository;
- replace the volatile all-refs canonical field with:
  - `authoritative_refs_sha256`, derived from the complete sorted authoritative
    map;
  - a fixed diagnostic-policy identifier/result;
- retain complete diagnostic inventories and opening/final deltas as separate
  sidecars, not canonical source identity;
- change no other source/diff/index/config/migration/schema field or encoding.

The historical full-ref mismatch remains a disclosed provenance limit. The
corrected rule establishes only the new prospective opening-to-close interval.
If the source/tree/baseline or any other fixed opening field differs, stop.

INDEPENDENT AUDIT DISPOSITION

The corrected artifact-only audit authenticated the exact final tree above and
returned:

`RW0_C2_P0_P1_DECISION_BASIS_V2_CUMULATIVE_ARTIFACT_AUDIT_BLOCKED`

The corrected Git-mode/checkout-mode provenance gate passed all 72 checks.
The historical mode-stop remains a truthful result under its former rule.

The audit reproduced both findings through the real private writer in an
isolated exact-source copy.

F1 reproduced result:

- commit a valid `candidate_acceptance` command;
- change only its valid `expected_branch` assertion to `candidate_repair`;
- the current command digest remains unchanged;
- record and read return the original committed result;
- recovery returns `committed_exact`;
- no durable rows change.

F2 reproduced result:

- commit a valid command with positive posture;
- change the source to `disclosure_permitted=False`;
- `source.checked_for(..., write=False)` rejects it;
- current P1 read still returns the committed result;
- current recovery still returns `committed_exact`.

The audit stopped broad causal and selector-free validation after these material
findings. Its source review found no additional material blocker. Writer-retained
108 direct, 5 connected, 5,796 focused, and 9,438 FULL passes remain historical
implementation evidence only.

ARCHITECTURE DECISIONS

PART A — GUARDED COMMAND DIGEST V2

The command schema remains:

`governed-execution.nwp-record-development-progression-decision-command.v1`

Do NOT modify migration 0002 or introduce a new command schema ID. The existing
0002 receipt CHECK and generic receipt meaning remain unchanged.

The private digest profile is versioned instead:

Historical blocked predecessor:

`governed-execution.nwp-rw0-c2-guarded-command-digest.v1.identity`

Current profile:

`governed-execution.nwp-rw0-c2-guarded-command-digest.v2.identity`

V1 remains exact historical contract/test evidence with its existing 30 ordered
relation fields and fixed vector. It is not the current P1 mutation digest.

V2 uses exactly 31 ordered pairs:

1. the same 30 ordered name/value pairs from guarded-command-digest v1, in the
   same order and with the same source fields; then
2. `expected_branch`, whose value is either JSON null or one exact finite branch
   string.

The six branch-neutral sibling preassignments remain derived from the existing
24 primitive relation coordinates. `expected_branch` remains excluded from
their preassignment basis. It is an optimistic conflict assertion, not a branch
selector and not authority.

Add one current command-level digest owner, preferably a property or pure helper
on `RecordProgressionDecisionCommandV1`, that computes guarded-command-digest
v2 from:

- the admitted relation's 30 exact command fields; and
- the command's exact optional `expected_branch`.

The relation's historical v1 digest may remain available only as predecessor or
relation-core evidence. Current durable code must not use it as the complete
command digest.

Replace every P1 durable identity use of:

`command.relation.command_digest`

with the command-level v2 digest, including:

- committed result projection;
- receipt command digest;
- decision/version/relation/result row planning;
- replan successor-ref derivation;
- revision-edge derivation;
- route/family coherence;
- exact replay comparison;
- competing-winner verification;
- recovery selector association.

Do not add `expected_branch` to Decision Basis v2 or any SQL row. Do not add a
column, table, migration 0008, result field, receipt role, relation field, or
preassignment.

Because `expected_branch` has the closed domain:

`None` plus the five exact branch strings,

an internal historical verifier that must reconstruct a complete competing
acceptance winner may recover the original assertion only by finite digest
matching against the persisted command digest. For an actually committed
acceptance family, only `None` or `candidate_acceptance` can be valid. Require
exactly one matching candidate; zero or multiple matches make the family
unverifiable. This helper is internal verification and must not expose the
competing result.

Fresh commands that differ only in `expected_branch` retain the same six sibling
preassignments and family routes but have different command digests. Reuse of
the same mutation/family route with a different assertion is therefore an exact
changed-command conflict, never replay.

Update the governing private-value machine block and prose:

- preserve guarded-command-digest v1 exactly as the blocked predecessor;
- define v2's domain, 31-pair order, canonical null/string treatment, fixed
  vector, and derivation order;
- retain the semantic contract statement that `expected_branch` is assertion
  only and command-digest covered;
- state explicitly that preassignments exclude it while exact replay identity
  includes it.

PART B — FRESH PROTECTED DISCLOSURE FOR P1

Preserve the stronger private-value contract:

- exact replay/readback requires fresh current positive posture for protected
  disclosure;
- commit-uncertainty recovery requires fresh current positive posture before it
  may return `committed_exact` or `definitely_not_committed`;
- denied, expired, malformed, mismatched, or unavailable disclosure posture
  cannot disclose a committed result and yields `unresolved` for recovery.

`ArtificialDecisionGuardSourceV1.checked_for(..., write=False)` remains the
owner of this gate. Do not weaken or bypass it.

Refactor the private P1 read path so it accepts:

- the exact command;
- the exact current source;
- one captured transaction/read timestamp.

Required order and behavior:

1. Look up the mutation receipt first.
2. If a receipt is present:
   - require `source.checked_for(command.basis, now=timestamp, write=False)`;
   - then compare the persisted v2 command digest to the caller's exact command
     digest;
   - then verify and reconstruct the complete immutable family;
   - return the committed result only after all three succeed.
3. If no receipt is present:
   - read mode still requires current disclosure posture before reporting the
     absence through its existing outer failure behavior;
   - record mode requires current recording posture before route probing or
     writes;
   - recovery requires current disclosure posture and the existing
     `old_execution_excluded` and route-absence proof before
     `definitely_not_committed`.
4. A historical exact replay from record mode requires disclosure permission,
   not renewed recording permission.
5. A genuinely fresh record with no receipt requires recording permission, not
   disclosure permission.
6. Recovery with a complete exact family but denied/expired/mismatched
   disclosure posture returns `unresolved` with no committed result.
7. Read with denied disclosure returns no committed result and preserves the
   existing safe outer error vocabulary.
8. No posture failure may trigger a write, retry, fragment repair, new timestamp,
   new row, or hidden family reconstruction from caller evidence.

The historical family still reconstructs branch and result without rerunning
cognition or resampling historical durable facts. Fresh external posture is
used only as the disclosure gate. Correct the physical implementation document's
statement that replay occurs “without external source” to this exact
distinction.

Internal competing-family completeness checks may verify immutable rows without
returning a protected result. They must not become a public/read API bypass and
must still use the exact persisted command digest and complete family.

NO PHYSICAL OR AUTHORITY WIDENING

Preserve all of the following:

- Decision Basis v1/v2 grammar and current 23-field v2 basis;
- typed validation/review dispositions and candidate-reason derivation;
- migrations 0006 and 0007 bytes and checksums;
- cumulative 74/134/5 schema and generation 2;
- four P0 tables and six P1 supplemental tables;
- relation/result/receipt-profile v2 field shapes and graph roles;
- historical program-head and work-head witnesses;
- existing six sibling preassignments;
- existing migration-0002 row and receipt meanings;
- unchanged `WorkSpecV1`;
- five branch semantics and acceptance-only fact;
- separate P0 and P1 transactions and receipts;
- no terminal-outcome persistence;
- no public StateStore/package API;
- no live supplier, provider, worker, ES/Bridge, product Git, service, scheduler,
  deployment, or autonomous-loop path.

Migrations 0006 and 0007 must remain byte-identical. If either finding cannot be
repaired without changing SQL, row shape, Decision Basis v2, relation/result/
receipt profile, WorkSpec, or migration-0002 semantics, STOP and report the
precise missing durable fact.

REQUIRED F1 CAUSAL CONTROLS

1. Digest profile

Using one exact admitted relation, prove:

- its six sibling preassignments are identical for all six allowed
  `expected_branch` values;
- guarded-command-digest v2 is distinct for `None` and each of the five branch
  strings;
- each value is exact built-in type checked;
- v1 predecessor vector remains byte/digest exact historical evidence;
- current mutation uses v2 only.

2. Changed assertion after commit

For a real committed acceptance command whose original assertion is `None`:

- replace only `expected_branch` with `candidate_repair`;
- require the same relation/preassignments but a different v2 command digest;
- record returns the existing changed-command/mutation-ref conflict;
- read does not return the original committed result;
- recovery returns `unresolved`;
- all durable row counts, receipts, versions, and heads remain unchanged.

Repeat with another valid but wrong branch assertion sufficient to establish the
finite rule. Do not satisfy this only through a pure constructor test.

3. Exact replay positives

Through the real writer:

- original `expected_branch=None` replays exactly under positive disclosure;
- original `expected_branch=candidate_acceptance` replays exactly;
- a fresh mismatching assertion still returns `expected_branch_mismatch` before
  writes;
- all five physical branches retain exact command association.

4. Competing complete winner

Exercise recovery where a different complete acceptance winner exists:

- once where the winner's original assertion was `None`;
- once where it was `candidate_acceptance`.

The internal finite reconstruction must prove the complete winner without
disclosing its result and preserve the original command's existing recovery
classification.

REQUIRED F2 CAUSAL CONTROLS

Use real writer/session/controller paths and task-owned databases.

1. Positive disclosure

After a committed family:

- `record` with `recording_permitted=False`,
  `disclosure_permitted=True` returns exact replay;
- `read` with positive current disclosure returns exact committed result;
- `recovery` with positive current disclosure returns `committed_exact`;
- no durable movement occurs.

2. Denied disclosure

After the same committed family, separately test:

- `disclosure_permitted=False`;
- expired current posture;
- continuity/sole-active/source mismatch.

Require:

- `source.checked_for(..., write=False)` is reached and rejects;
- record does not return the committed result;
- read does not return the committed result;
- recovery returns `unresolved` with `committed is None`;
- no row, receipt, version, program-head, or work-head movement;
- no retry or new timestamped family.

3. Fresh write distinction

With no receipt:

- recording positive / disclosure false may create one fresh family;
- recording false / disclosure positive must not create a family;
- read with disclosure false discloses no result/absence;
- recovery with disclosure false is `unresolved`.

4. Process-control and integrity

- `KeyboardInterrupt`, `SystemExit`, and `GeneratorExit` remain unsuppressed.
- Malformed or contradictory persisted families remain integrity failure or
  unresolved, never normalized by posture.
- The second-replan historical work-head replay and all five branch families
  retain their prior behavior.

FIRST SUBSTANTIVE REPAIR CHECKPOINT

Before broad validation:

1. save the complete repaired source identity;
2. reopen a command-digest-v2 identity checkpoint proving the six-value digest
   matrix, unchanged sibling preassignments, and exact v1 predecessor;
3. run real-writer F1 changed-assertion and exact-replay controls;
4. run real-writer F2 positive/denied/expired/mismatched disclosure controls;
5. include unchanged acceptance, repair, replan, terminal-reject, and block
   positives;
6. include second-replan historical replay and competing-winner recovery;
7. verify migration 0006 and 0007 bytes are unchanged;
8. independently apply the seven SQL files and preserve 68/122/5 after 0006 and
   74/134/5 after 0007;
9. verify P0 checkpoint production bytes remain exact;
10. save, reopen, and verify the checkpoint before broader validation.

AUTHORIZED FILE CEILING

Expected production paths:

- `src/ge_nwp_coordinator/_rw0_c2_progression_contracts.py`
- `src/ge_nwp_coordinator/_rw0_c2_progression_plan.py`
- `src/ge_nwp_coordinator/_sqlite_rw0_c2_progression.py`
- `src/ge_nwp_coordinator/sqlite_transition_transaction.py`
- `src/ge_nwp_coordinator/sqlite_writer_session.py` only if direct type/signature
  plumbing requires it

Expected direct tests:

- `tests/test_rw0_c2_progression_contracts.py`
- `tests/test_rw0_c2_progression_plan.py`
- `tests/test_sqlite_rw0_c2_progression.py`
- `tests/test_sqlite_rw0_c2_connected.py`
- `tests/test_rw0_c2_private_value_versioning_contract.py`
- `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`

Expected governing documents:

- `.docs/rw0-c2-private-value-versioning.md`
- `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
- `.docs/rw0-c2-physical-p0-p1-implementation.md`
- `.docs/c2b-durable-development-state.md`
- `AGENTS.md` only if its current implementation-status block directly names the
  superseded digest/disclosure behavior

Direct existing caller, source-hash, identity-vector, migration-tip, inventory,
AST, or assurance consumers may change only after recording the exact
dependency. No new repository path is expected.

Forbidden source changes include:

- migrations 0001–0007;
- P0 production owners;
- migration-0002 row/receipt owners or SQL;
- Decision Basis v2 field grammar;
- relation/result/profile row grammars;
- WorkSpec owners;
- public StateStore/package exports;
- terminal or live-route owners.

FINAL VALIDATION

Run only from fresh authenticated external copies of FINAL source.

Required gates:

1. direct F1/F2 repair controls;
2. connected five-branch P0→D1/D2→Section 41/C1/V22→P1 selection;
3. the prior focused 49-module selection plus every directly touched assurance
   module not already included;
4. one selector-free collection;
5. one selector-free FULL execution.

Do not assume the old count 9,438 after adding tests. Freeze the final collection
before execution and require:

- unique collected IDs;
- exact collected/executed/JUnit ID equality and order;
- zero failures, errors or skips;
- exact warning inventory;
- source bytes and numeric modes unchanged before and after;
- migrations 0006/0007 byte exact;
- exact 68/122/5 and 74/134/5 schema manifests.

Superseded, interrupted, or failed attempts receive no final validation credit.

PROVENANCE AND DELIVERY

Use the corrected narrow v5 successor of the existing versioned provenance
approach. This is not a new general framework.

At closeout:

- retain the former v4 recipe and full-ref-hash observations unchanged as
  historical evidence;
- retain the complete opening authoritative-ref map and all diagnostic-ref
  inventories/deltas;
- generate two byte-identical final v5 canonical captures from fresh reads and
  one post-cleanup capture;
- require the authoritative-ref map byte-identical from corrected opening
  through cleanup;
- allow only qualified diagnostic additions/removals with no surviving-name
  retarget and no source-selection dependency;
- retain the exact source tree, complete changed-path inventory, tracked binary
  diff, recipe bytes/hash, command-digest v1/v2 vectors, migrations, schema
  manifests, commands, environments, ordered IDs, JUnit, warnings, checkpoint,
  and cleanup evidence;
- preserve historical live-index/ref and POSIX-mode limits without backdating;
- write the implementation report before sealing the package;
- include a byte-identical report at `evidence/IMPLEMENTATION_REPORT.md`;
- provide the same report as a standalone deliverable;
- seal one cumulative review ZIP with complete final source and safe evidence;
- reopen and verify every member;
- provide an adjacent delivery receipt with ZIP bytes and SHA-256;
- report the new Git-compatible source tree.

The embedded report need not and must not contain the outer ZIP's self-hash.

STOP CONDITIONS

Stop without staging if:

- the opening source/tree/baseline differs;
- binding `expected_branch` requires changing migration 0002, migrations
  0006/0007, a SQL table/column, Decision Basis v2, relation/result/profile
  shapes, or a seventh preassignment;
- protected disclosure cannot be enforced through the existing source argument
  and current transaction/read API without durable schema change;
- migration 0006 or any P0 production byte changes;
- any branch loses replay/readback/recovery;
- competing-winner recovery cannot reconstruct the finite expected-branch
  assertion exactly from the persisted digest;
- required final validation cannot complete;
- source changes outside the authorized/direct-consumer scope are needed without
  a source-grounded dependency;
- authority, security, privacy, or durable-state scope would widen.

EFFECT CEILING

Authorized:

- bounded repository source/document/test edits above;
- task-owned external source copies and synthetic SQLite state;
- local test execution;
- inert evidence and review-package creation outside the repository.

Not authorized:

- subagents;
- staging;
- commit;
- push;
- PR;
- merge;
- publication;
- deployment;
- network/service contact;
- live supplier/provider/worker/ES/Bridge use;
- user/product database access;
- terminal persistence or any product effect.

REQUIRED FINAL RESPONSE

Return one of:

- `RW0_C2_P0_P1_COMMAND_DIGEST_V2_AND_PROTECTED_DISCLOSURE_REPAIR_IMPLEMENTED_VALIDATED_PENDING_AUDIT`
- `RW0_C2_P0_P1_REPAIR_BLOCKED_<PRECISE_REASON>`

Include:

- exact opening and final source identities;
- complete touched-file list and classifications;
- guarded-command-digest v1/v2 definitions and fixed vectors;
- exact current command-digest owner and every durable call-site changed;
- command identity and downstream identity vector;
- changed-assertion conflict/replay/recovery results;
- protected disclosure ordering and API treatment;
- positive, denied, expired, and mismatched disclosure results;
- competing-winner reconstruction results;
- checkpoint identity and reopen result;
- connected, focused, and selector-free collection/FULL commands and results;
- collected/executed/JUnit reconciliation;
- migration/P0 preservation and schema manifests;
- v4 historical full-ref observation, corrected opening authoritative-ref
  identity, and complete diagnostic-ref deltas;
- provenance-v5 recipe identity and final captures;
- standalone/embedded report equality;
- review ZIP path, bytes, SHA-256;
- assumptions, residual observations, skipped/unavailable validation;
- explicit no-stage/no-commit/no-publication/no-network/no-product-effect record.

Retain the audit's historical mode-stop, F03/F05 observations, and unperformed
coverage as disclosed history. Do not claim they were fixed.
