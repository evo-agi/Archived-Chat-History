OBJECTIVE

Continue the same uncommitted RW0-C2 P0→P1 status-successor current-drift
repair and correct the single focused architecture-consumer failure.

This is a workspace-write continuation in the SAME implementation Codex
conversation. The parent remains the sole writer. Do not spawn subagents.

Do not restart from the prior accepted status tree. Continue from the exact
current unvalidated candidate, preserving the six new owner-local status blocks
and all already completed direct-assurance work except where the two block
locations and their exact identity consumers must change.

This engagement is documentation and direct assurance only. Do not edit
production Python, SQL, migrations, schemas, configuration, public APIs, file
modes, or repository path inventory.

Do not stage, commit, push, open a PR, merge, publish, deploy, or perform a
product effect.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OPENING SUBJECT

Before editing, authenticate exactly:

- branch:
  `codex/rw0-c2-p0-p1-physical-program-v1`
- HEAD:
  `8704e6c7988250598809f3a0daf88c3e11493488`
- committed HEAD tree:
  `161ed4b544baf970cc26428b9805a106ea0f3edf`
- upstream:
  absent
- source paths:
  `315`
- opening status-successor tree before the six-document repair:
  `a34d28a7371b87c0cb874076ad610fd650ad6e72`
- current unvalidated candidate tree:
  `d078d1836336fef9f5e2e7b27dc0c55fa86e5858`
- current source-manifest SHA-256:
  `d70b8f7761a4838fe7bea95e16bff0dbac1049747f8158ff195954ee641a4207`
- staged and unmerged entries:
  none
- current repair patch:
  `45,263` bytes
- current repair patch SHA-256:
  `310e51ca273f2adfec2960f31cad4b1442976542b8b0b8645868745753f2d123`
- current deterministic repair manifests:
  `7,302` bytes each
- current repair-manifest SHA-256:
  `52f0e1e62fb04c861f1f26ebc54c17d55300d217916974545d5c343cff2b68e8`
- classified source:
  `tests/test_c2b3_private_atomic_program_initialization.py`
  remains POSIX mode `0600`, Git mode `100644`.

Retained blocked-repair evidence root:

`/tmp/rw0-c2-status-drift-repair-NTmGvz/`

Require:

- `BLOCKED_REPORT.md`
  - bytes: `8,921`
  - SHA-256:
    `7a77220cff4062b78b44222ea6fc7257765d712a5a2dd230c30d7e7e56a0e805`
- `repair-binary-full-index.patch`
  - bytes: `45,263`
  - SHA-256:
    `310e51ca273f2adfec2960f31cad4b1442976542b8b0b8645868745753f2d123`
- both retained repair manifests:
  - bytes: `7,302`
  - SHA-256:
    `52f0e1e62fb04c861f1f26ebc54c17d55300d217916974545d5c343cff2b68e8`
- `focused-failure-reconciliation.json`
- `corrected-passage-classification.json`
- `first-checkpoint.zip`
- `frozen-repair-focused-modules.json`
- `BLOCKED_RETAINED_ARTIFACT_MANIFEST.json`.

The current worktree must contain exactly the six new status-document changes
and five direct-assurance changes reported by the blocked closeout, layered on
the opening tree `a34d28...`. Stop if the current candidate differs. Do not
reset, restore, clean, rebase, or rewrite it into compliance.

HISTORICAL RESULT TO PRESERVE

Retain the blocked result:

`RW0_C2_P0_P1_STATUS_SUCCESSOR_CURRENT_DRIFT_REPAIR_BLOCKED_FOCUSED_ARCHITECTURE_CONSUMER_FAILURE`

The first checkpoint passed 1,380 tests in the five changed assurance modules.
The final frozen 36-module selector collected 5,388 unique IDs and produced:

- 5,387 passed;
- 1 failed;
- zero errors, skips, xfails, xpasses, or warnings;
- exact collected/executed/JUnit order;
- ordered-ID SHA-256:
  `2df7d0b2d723dca180137d8ee12399361880fe9e1f695dff0e48b7c0fc9f0f23`.

The sole failing node was:

`tests/test_architecture_contracts.py::test_docs_pin_authority_boundaries`

at the complete RW0 architecture-map comparison, reporting:

`rw0.architecture.map: body mismatch`

No repository edit or test rerun occurred after that failure.

ROOT CAUSE AND FROZEN ENGINEERING DECISION

The architecture test is correct and must remain unchanged.

The marker-bounded cross-reference body shared across:

- `.docs/autonomous-software-development-operating-model.md`
- `.docs/worker-execution-boundary.md`
- `.docs/authority-boundaries.md`
- `.docs/durable-state-model.md`

is a frozen historical architecture-map body. The current repair inserted the
new local-commit successor inside that shared marker body in only:

- `.docs/durable-state-model.md`
- `.docs/worker-execution-boundary.md`

That made the bodies differ. It is a document-placement error, not an assurance
defect.

Do NOT:

- edit `tests/test_architecture_contracts.py`;
- normalize or strip status blocks inside its helper;
- weaken the exact four-owner shared-body equality;
- copy the new successor into the other two shared historical owners;
- rewrite the old shared body;
- remove either new current status successor.

Correct treatment:

1. Preserve each of the two new successor blocks byte-for-byte.
2. Cut the complete marked block from immediately BEFORE:

   `<!-- COORDINATOR_RW0_PHASE_ENTRY_CROSS_REFERENCE_END -->`

3. Reinsert that exact block immediately AFTER that END marker, with one
   deterministic blank-line boundary.
4. Require the complete document prefix through and including the END marker to
   reconstruct the exact opening-tree `a34d28...` bytes.
5. Require the relocated successor to remain the owner-local current status
   following the frozen historical cross-reference.
6. Keep the other four newly added status blocks byte-identical and at their
   current authorized locations.

The two exact blocks use:

`<!-- RW0_C2_P0_P1_LOCAL_COMMIT_STATUS_SUCCESSOR_BEGIN -->`
`<!-- RW0_C2_P0_P1_LOCAL_COMMIT_STATUS_SUCCESSOR_END -->`

No wording change is authorized unless a direct location sentence inside the
block falsely says it is within the cross-reference marker. If such a sentence
exists, stop and report it rather than silently rewriting substantive status.

EXACT DOCUMENT TREATMENT

A. `.docs/durable-state-model.md`

Current candidate block:

- reported lines: approximately 604–636;
- current candidate SHA-256:
  `19464a305e28a7ac6ba7eb2fe422c0085eb73d859daedab8cb4461efc5f295eb`.

Move its exact successor block to immediately after
`COORDINATOR_RW0_PHASE_ENTRY_CROSS_REFERENCE_END`.

Require:

- the cross-reference prefix through END equals the opening `a34d28...`
  document bytes at that boundary;
- the old B2/Capability current-status text remains byte-exact historical
  evidence inside the shared body;
- the relocated successor remains the current correction.

B. `.docs/worker-execution-boundary.md`

Current candidate block:

- reported lines: approximately 522–554;
- current candidate SHA-256:
  `8296c34e9d0c23113b4276fae4a4b001f36f6e616b6fd5df0456d15f729c8b5d`.

Move its exact successor block to immediately after
`COORDINATOR_RW0_PHASE_ENTRY_CROSS_REFERENCE_END`.

Apply the same prefix, historical-preservation, and current-successor
requirements.

C. Preserve byte-for-byte

Do not alter the current candidate bytes of the four other new status owners:

- `.docs/rw0-c2-scope-admission-provisioning-contract.md`
- `.docs/rw0-remote-worker-contact-phase-entry.md`
- `.docs/rw0-b2-wire-protocol.md`
- `.docs/rw0-d1-offline-process-and-capsule-spine.md`

except for direct fixed-identity test expectations caused solely by the two
relocations.

ASSURANCE CONSUMERS

Perform a fresh complete 315-path consumer scan before editing tests.

The following five tests are already changed in the current candidate:

- `tests/test_remote_worker_pre_execution_planning_contract.py`
- `tests/test_rw0_b2_capability_boundaries.py`
- `tests/test_rw0_b2_wire_cancellation_control_boundaries.py`
- `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py`
- `tests/test_rw0_remote_contact_phase_entry_contract.py`

Update only fixed document identities, exact insertion-location assertions, and
predecessor-reconstruction logic directly affected by relocating the two
blocks.

Required assurance:

1. Pin complete final identities with fixed expected values.
2. Require exactly one new successor block in each relocated document.
3. Require the block to occur immediately after the cross-reference END marker,
   not before it or inside the shared body.
4. Removing the relocated block must reconstruct the exact opening-tree
   `a34d28...` document bytes.
5. The prefix through END must be byte-identical to the opening predecessor.
6. Preserve the six old passages byte-exact.
7. Preserve all prior thirteen-document predecessor chains.
8. Preserve all four other new status-block checks.
9. Add or retain bounded negatives for:
   - block before END;
   - block duplicated;
   - block omitted;
   - block inserted into only part of the historical shared body;
   - changed tree/commit facts;
   - publication/live/terminal/ES/Bridge/product-Git/autonomy overclaim.
10. Use fixed expected hashes and actual file bytes.
11. Do not derive expected values from the file under test.
12. Do not skip, xfail, disable, broad-normalize, or weaken any existing guard.

`tests/test_architecture_contracts.py` must remain byte-identical to HEAD/local
commit unless a newly discovered source contradiction unrelated to this
failure is proved. Its unchanged test must pass because the shared cross-body
has been restored, not because the test was relaxed.

PASSAGE CLASSIFICATION

Create a narrow successor to the current corrected classification record.

It must:

- preserve the original 38-row map;
- preserve the independent review's six corrections;
- preserve the six new current rows;
- record that the durable-state and worker-boundary successor treatments changed
  from `inside historical shared marker` to `immediately after historical
  shared marker`;
- retain every other classification and treatment;
- identify exact direct consumers and predecessor reconstruction.

FIRST SUBSTANTIVE CHECKPOINT

Before broad focused validation, run and save a reopened checkpoint containing:

1. exact opening and repaired source identities;
2. the two block-byte identities before and after relocation, proving bytes
   unchanged;
3. exact prefix-through-END equality for all four shared architecture-map
   owners;
4. unchanged `tests/test_architecture_contracts.py` bytes;
5. passing
   `tests/test_architecture_contracts.py::test_docs_pin_authority_boundaries`;
6. the five changed assurance modules;
7. all six document predecessor/current-status positives and bounded negatives;
8. prior thirteen-document predecessor reconstruction;
9. no production, SQL, migration, schema, configuration, path, or mode change;
10. checkpoint reopen and full member verification.

FINAL VALIDATION

Run from a fresh authenticated external copy of the FINAL source.

1. `git diff --check`.
2. Start with the prior frozen 36 complete modules.
3. Add any newly discovered directly affected complete assurance module from the
   fresh consumer scan.
4. Deduplicate and freeze the complete module selector before execution.
5. Run selector-free collection and execution over those complete modules.
6. Require:
   - unique collected IDs;
   - exact collected/executed/JUnit identity and order;
   - zero failures, errors, skips, xfails, or xpasses;
   - complete warning inventory;
   - unchanged source bytes and numeric modes before/after.
7. Do not assume 5,388 after edits; report the new frozen count and ordered-ID
   SHA-256.

A repository-wide selector-free FULL run is not required unless:

- a production/runtime path changes;
- a direct consumer outside the complete focused selector is affected;
- the focused run reveals an unexplained shared-contract failure;
- source inspection proves a runtime import dependency.

If any condition occurs, stop instead of silently widening scope.

PROVENANCE AND DELIVERY

Use a narrow successor of the current status-drift repair provenance outside
the repository.

At closeout:

- retain the blocked attempt and evidence unchanged as historical inputs;
- baseline the repair against exact current candidate tree
  `d078d1836336fef9f5e2e7b27dc0c55fa86e5858`;
- record every changed path's before/after bytes, sizes, SHA-256, Git blobs, Git
  modes, and OS modes;
- retain a complete binary full-index patch;
- generate the deterministic continuation manifest twice from fresh reads and
  require byte-identical output;
- independently reconstruct the final Git-compatible tree;
- retain the corrected classification successor, fresh consumer scan,
  checkpoint, focused collection/execution, ordered IDs, JUnit, warnings,
  commands, environment, source before/after, and cleanup evidence;
- write the implementation report before sealing;
- include a byte-identical copy at `evidence/IMPLEMENTATION_REPORT.md`;
- create one cumulative status-successor review ZIP containing:
  - complete final 315-file source;
  - exact before endpoints for all changed paths;
  - original status-successor package/report;
  - blocked independent review report/evidence;
  - blocked current-drift repair evidence;
  - old and new classification maps;
  - patch/manifests;
  - focused validation;
  - nonclaims;
  - implementation report;
- reopen and verify every member;
- provide an adjacent delivery receipt with ZIP/report bytes and SHA-256.

No report may claim independent acceptance.

STOP CONDITIONS

Stop without staging if:

- opening identity differs;
- the two block bytes cannot be preserved exactly;
- restoring the frozen shared body requires changing
  `test_architecture_contracts.py`;
- any old historical passage would need rewriting;
- production, SQL, migration, schema, public API, configuration, mode, or new
  path change is required;
- a consumer would need weakening, dynamic expectation, skip, xfail, or broad
  normalization;
- validation fails or source bytes/modes change;
- the touched path set exceeds the two documents and exact direct consumers.

EFFECT CEILING

Authorized:

- relocating the two exact status blocks;
- updating direct fixed assurance consumers;
- task-owned external validation and evidence;
- cumulative review-package creation outside the repository.

Not authorized:

- production/source/schema/migration edits;
- edits to `tests/test_architecture_contracts.py`;
- subagents;
- staging;
- commit;
- push;
- upstream creation;
- PR;
- merge;
- publication;
- deployment;
- network/service contact;
- provider/worker/ES/Bridge/product database use;
- terminal persistence or product effect.

REQUIRED FINAL RESPONSE

Return one of:

- `RW0_C2_P0_P1_STATUS_SUCCESSOR_ARCHITECTURE_MAP_PLACEMENT_REPAIR_IMPLEMENTED_VALIDATED_PENDING_REVIEW`
- `RW0_C2_P0_P1_STATUS_SUCCESSOR_ARCHITECTURE_MAP_PLACEMENT_REPAIR_BLOCKED_<PRECISE_REASON>`

Include:

- exact opening commit/branch/upstream and current candidate tree;
- exact final tree;
- complete touched-path list;
- proof that both successor blocks are byte-identical before/after relocation;
- proof that all four cross-reference bodies are byte-identical;
- unchanged architecture-test identity and passing node result;
- direct consumer/test updates;
- checkpoint identity and reopen result;
- final focused selector and collected/executed/JUnit reconciliation;
- warnings and source preservation;
- patch/manifests/report/review ZIP identities;
- assumptions, residual observations, and unperformed validation;
- explicit:
  `INDEPENDENT_REVIEW_NOT_PERFORMED`
  `STAGING_NOT_PERFORMED`
  `COMMIT_NOT_PERFORMED`
  `PUSH_NOT_PERFORMED`
  `PR_NOT_CREATED`
  `MERGE_NOT_PERFORMED`
  `PUBLICATION_NOT_PERFORMED`
  `DEPLOYMENT_NOT_PERFORMED`
  `PRODUCT_EFFECT_NOT_PERFORMED`

The next recipient after success is a fresh read-only Codex artifact-review
conversation. Do not start that review here.
