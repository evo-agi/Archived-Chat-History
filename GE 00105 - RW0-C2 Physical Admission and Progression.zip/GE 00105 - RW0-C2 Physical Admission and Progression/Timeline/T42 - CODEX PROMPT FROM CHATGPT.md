OBJECTIVE

Implement the separately reviewed status successor for the locally committed
RW0-C2 P0→P1 physical admission/progression program.

This is a workspace-write continuation in the SAME implementation Codex
conversation that created local commit:

`8704e6c7988250598809f3a0daf88c3e11493488`

The parent is the sole writer. Do not spawn subagents.

This engagement is documentation-and-assurance only. It records the completed
independent audit and exact local commit gate without changing production
Python, SQL, migrations, physical row meanings, runtime behavior, public APIs,
authority, or publication state.

Do not stage, commit, push, open a PR, merge, publish, deploy, or perform a
product effect.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

CURRENT STATE — PRECEDING TRANCHE IS COMPLETE LOCALLY

The architecture-defining P0→P1 source tranche has completed:

- independent artifact acceptance of exact tree:
  `161ed4b544baf970cc26428b9805a106ea0f3edf`
- exact local implementation commit:
  `8704e6c7988250598809f3a0daf88c3e11493488`
- sole parent:
  `4519630d0db967066beb21b4ace5004e76827716`
- exact commit subject:
  `feat: add RW0-C2 physical admission and progression`
- exact commit tree:
  `161ed4b544baf970cc26428b9805a106ea0f3edf`
- branch:
  `codex/rw0-c2-p0-p1-physical-program-v1`
- upstream:
  absent
- committed source paths:
  `315`
- local commit-gate selector-free result:
  `9,473 passed`, zero failures/errors/skips, exact ordered ID SHA-256
  `de9fd885d375cc9152853ac54b70ab2d725de74f7882ba3fc48f2507c3ac0042`
- classified checkout file:
  `tests/test_c2b3_private_atomic_program_initialization.py`
  remains OS mode `0600`, Git mode `100644`
- push/PR/merge/publication/deployment/product effect:
  not performed.

The implementation commit remains local and unpublished. This status successor
must not describe it as merged, integrated into `trunk_dev`, remotely published,
deployed, live, terminal, or product-authoritative.

AUTHENTICATED LOCAL-COMMIT EVIDENCE

Before editing, authenticate the current live state and these retained files:

- branch:
  `codex/rw0-c2-p0-p1-physical-program-v1`
- HEAD:
  `8704e6c7988250598809f3a0daf88c3e11493488`
- HEAD sole parent:
  `4519630d0db967066beb21b4ace5004e76827716`
- HEAD tree:
  `161ed4b544baf970cc26428b9805a106ea0f3edf`
- upstream:
  absent
- worktree and index:
  clean
- stage-zero entries:
  exactly 315, equal to HEAD
- local `trunk_dev` and local `origin/trunk_dev`:
  `4519630d0db967066beb21b4ace5004e76827716`
- configuration:
  unchanged from the commit gate
- classified source file:
  exact bytes and live mode `0600`.

Retained gate root:

`/tmp/rw0-c2-p0-p1-exact-byte-commit-gate-ld9fhxrx/`

Require exact identities:

1. `CLOSEOUT_REPORT.md`
   - bytes: `5,940`
   - SHA-256:
     `311335d6eb4b18a0ade10302ec3f3bbf9c79e9f23c94648a9dfdcf6136aa23f`

2. `RESULT.json`
   - bytes: `6,785`
   - SHA-256:
     `7004be022e591601921012473378d203653d1a5e0d6bab1eaa52a2a7380146b3`

3. `STATUS_SUCCESSOR_DEPENDENCY_INVENTORY.md`
   - bytes: `19,766`
   - SHA-256:
     `6c494ad03af7b8920a25806ac29eb6fc3800123c962d8ca9963d29203aca70b7`

4. `self-excluding-retained-artifact-manifest.json`
   - bytes: `12,730`
   - SHA-256:
     `6f0f497a9a44d6874318588018fec58d5939f62e538ce195cdf9d324e45b42f4`

5. commit message:
   - bytes: `52`
   - SHA-256:
     `3805d935aedf934d04cc5185ffc07bede4dcfacce0ffe979289456ad69959302`

6. raw commit object:
   - bytes: `280`
   - SHA-256:
     `b93616349054335d091e51dda478187aef188db4fbf064772c93032995491571`

The status dependency inventory is the mandatory path-and-consumer map for this
engagement. Read it completely before authoring. Do not replace it with a new
broad reconnaissance.

If any baseline or retained evidence identity differs, stop without editing.

PURPOSE OF THE STATUS SUCCESSOR

Repository guidance requires current `.docs` and status projections to describe
reality. The exact-byte commit gate intentionally left candidate-era wording in
the accepted tree because changing it would have changed the audited bytes.

The successor must now record, accurately and narrowly:

1. exact independent acceptance of tree
   `161ed4b544baf970cc26428b9805a106ea0f3edf`;
2. exact local commit
   `8704e6c7988250598809f3a0daf88c3e11493488`;
3. exact local commit-gate selector-free result:
   `9,473 collected/executed/JUnit/passed`, zero failures/errors/skips, with the
   three known Python 3.13 multithreaded-fork deprecation warnings;
4. no push, upstream, PR, merge, publication, deployment, or product effect;
5. Git objects and refs remain current commit/publication truth;
6. audit, validation, provenance, closeout reports, and status text remain
   evidence rather than Coordinator durable authority;
7. the implementation remains a bounded artificial-offline private Coordinator
   proof;
8. P0 and P1 remain separate physical transactions:
   - P0 records admission history but grants no current authority;
   - P1 records one five-branch decision and an acceptance fact only for the
     acceptance branch;
9. Decision Basis v2, guarded-command-digest v2, the historical work-head
   witness, universal disclosure posture, and acceptance-only eligibility are
   current implemented private contracts;
10. F03 and F05 remain nonblocking observations:
    - F03: the bounded private P0 successor does not implement every earlier
      target-only selector/wrapper field, with no observed authority bypass;
    - F05: P0 samples time before the fresh collision probe, affecting potential
      no-write error precedence only;
11. historical full-ref/raw-index limitations remain disclosed and are not
    backdated;
12. no live enrollment/custody supplier, terminal outcome, executable
    permission, production provider/worker, ES/Bridge route, product Git effect,
    service, queue, scheduler, deployment, or autonomous loop is established.

Do not imply that a P0 record is current permission, that a P1 acceptance fact
is terminal truth, or that the local Git commit is a product Git-effect handler.

STATUS-PASSAGE CLASSIFICATION

Using the retained inventory, classify every candidate-era or pending-audit
passage as exactly one of:

A. `CURRENT_STATUS_REQUIRES_SUCCESSOR`
   A currently operative statement made stale by independent acceptance or the
   local commit.

B. `HISTORICAL_PREDECESSOR_PRESERVE_EXACT`
   A truthful description of an earlier candidate, blocker, checkpoint,
   implementation, or audit state. Preserve its bytes exactly.

C. `OTHER_SCOPE_NO_CHANGE`
   A statement about another tranche, live boundary, terminal persistence,
   external authority, publication, or historical event.

D. `CURRENT_TOP_LEVEL_STATUS_REQUIRES_BOUNDED_REPLACEMENT`
   A top-level or owner-current status line that would remain actively false
   even after a later appended successor.

Default treatment is append-only successor. Use bounded in-place replacement
only for class D, and only when a later current-status block cannot make the
owner unambiguous. Any bounded replacement must receive exact predecessor
reconstruction assurance.

Create an external machine-readable classification mapping with:

- path;
- source line/range or exact marker;
- class;
- rationale;
- chosen treatment;
- direct consumer paths;
- whether predecessor reconstruction is required.

Do not edit until the classification is complete.

EXPECTED DOCUMENT SURFACES

The retained inventory covers at least:

- `AGENTS.md`
- `README.md`
- `.docs/c2b-durable-development-state.md`
- `.docs/c2b2-migration-0002.md`
- `.docs/rw0-c2-physical-p0-p1-implementation.md`
- `.docs/rw0-c2-private-value-versioning.md`
- `.docs/rw0-c2-scope-admission-provisioning-contract.md`
- `.docs/sqlite-bootstrap-and-migrations.md`
- `.docs/sqlite-operations-and-recovery.md`
- `.docs/sqlite-schema-v1.md`
- every direct exact-byte, literal, AST, hash, status, inventory, or
  predecessor-reconstruction consumer identified by the inventory.

These are inspection surfaces, not an instruction to edit every file.

Edit only documents with a class-A or class-D current passage and only tests
that directly consume those exact changed bytes or claims.

No production source path may change.

AUTHORING RULES

1. Preserve historical evidence.

Earlier uncommitted, pending-audit, blocked, checkpoint, or superseded passages
remain exact when they describe their historical subject.

2. Use one authoritative current status per owner.

Do not create contradictory "current" blocks. Later successors must explicitly
supersede earlier candidate-stage current status at their intended scope.

3. Keep authority language exact.

Git owns commit/ref truth. SQLite rows and receipts own only their selected
private durable facts. External source observations remain externally supplied.
Reports and docs are evidence/projection.

4. Preserve private/offline scope.

Do not promote artificial fixtures, fake processes, task-owned SQLite, current
guard source values, or connected tests into a live supplier or runtime claim.

5. Preserve publication distinction.

State that local commit `8704e6...` exists on the topic branch with no upstream.
Do not assert the current remote state beyond the gate's no-publication
observation.

6. Preserve migration and schema meaning.

Migration 0006 remains the P0-only four-table family. Migration 0007 remains the
six-table P1 supplement at application generation 2. No status text may imply a
migration 0008, terminal row, or live upgrade.

7. Preserve test causality.

Do not merely refresh whole-file hashes. Where a current whole-file identity
changes:

- pin the complete new current bytes;
- reconstruct the exact committed predecessor by removing or reversing only the
  named status successor;
- preserve older historical predecessor chains;
- retain semantic/AST/literal controls;
- do not use dynamic expected hashes derived from the file under test;
- do not disable, skip, xfail, weaken, or broaden unrelated guards.

Where a negative specimen currently rejects at an earlier exact-block/count
predicate, do not claim separate causal credit for a later semantic predicate
unless you add an isolated specimen that passes the earlier predicates and
reaches the later one.

8. No generated authority.

The status mapping, review ZIP, manifests, and reports are evidence only.

AUTHORIZED FILE CEILING

Authorized repository changes:

- existing documentation/status owners classified A or D by the retained
  inventory;
- existing direct test/assurance consumers classified by exact source
  dependency.

Not authorized:

- any file under `src/ge_nwp_coordinator/`;
- any SQL or migration;
- package exports or public API;
- any new repository path;
- configuration;
- source modes;
- generated files in the repository;
- staging, commit, push, PR, merge, publication.

If a production or schema file appears necessary, stop.

FIRST SUBSTANTIVE CHECKPOINT

Before broad validation:

1. save the complete baseline and successor source identities;
2. save the passage classification map;
3. prove every historical predecessor passage selected for preservation is
   byte-identical;
4. prove every class-D replacement reconstructs its exact local-commit
   predecessor;
5. prove every appended successor occurs at one exact owner-defined location;
6. prove complete current identities for every changed owner;
7. prove all direct literal/hash/AST/status consumers use fixed values and real
   file bytes;
8. exercise positive current-status checks and bounded negative specimens;
9. include an exact nonclaim check for:
   - no push/PR/merge/publication;
   - no live authority;
   - no terminal outcome;
   - no ES/Bridge/product Git effect;
   - F03/F05 still open;
10. save, reopen, and verify the checkpoint before broader validation.

VALIDATION

Run validation only from a fresh authenticated external copy of the final
successor source.

Required:

1. `git diff --check`;
2. selector-free collection/execution of the complete set of directly affected
   assurance modules identified by the dependency map;
3. every changed document consumer and all predecessor/current-identity chains;
4. source bytes and numeric modes unchanged before and after collection and
   execution;
5. exact collected/executed/JUnit identity and order;
6. zero failures, errors, skips, xfails, or xpasses;
7. complete warning inventory.

Freeze the final selector before execution. Deduplicate modules deterministically.

A selector-free repository FULL run is NOT required for this documentation/test-
only successor unless:

- a production path changes;
- a direct consumer outside the frozen selector fails;
- source inspection reveals a production import/runtime dependency;
- the focused run shows an unexplained shared-contract regression.

If any of those occurs, stop rather than silently widening validation.

PROVENANCE AND REVIEW DELIVERY

Use a narrow versioned status-successor provenance recipe outside the
repository. Do not modify the implementation commit or its retained gate
evidence.

At closeout:

- require exact baseline commit:
  `8704e6c7988250598809f3a0daf88c3e11493488`;
- record exact changed paths and before/after bytes, sizes, SHA-256 values, Git
  blobs, Git modes, and numeric OS modes;
- retain a complete binary full-index patch;
- generate the deterministic status patch manifest twice from fresh reads and
  require byte-identical output;
- record complete final source manifest and independently reconstruct the
  successor Git-compatible tree;
- retain checkpoint, collection, execution, ordered IDs, JUnit, warnings,
  commands, allowlisted environment, source before/after, and cleanup evidence;
- write one implementation report before package sealing;
- include a byte-identical copy at `evidence/IMPLEMENTATION_REPORT.md`;
- create one self-contained review ZIP containing:
  - complete final 315-file source;
  - exact touched before endpoints;
  - baseline and final manifests;
  - classification map;
  - patch and deterministic manifests;
  - status inventory;
  - focused validation records;
  - current/historical nonclaims;
  - implementation report;
- reopen and verify every member;
- issue an adjacent delivery receipt with ZIP bytes/SHA-256 and standalone
  report bytes/SHA-256.

No report may claim independent acceptance.

STOP CONDITIONS

Stop without staging if:

- baseline commit/tree, source, index, branch, upstream, configuration, modes, or
  retained inventory identity differs;
- a current passage cannot be classified from repository evidence;
- a historical passage would need deletion or semantic rewriting;
- production, SQL, migration, public API, or new path change is required;
- a direct consumer would need weakening, dynamic expectation, skip, or broad
  normalization;
- current wording would overclaim publication, live authority, terminal truth,
  product execution, or autonomy;
- validation fails or source bytes/modes change;
- the touched path set exceeds the source-grounded dependency map.

EFFECT CEILING

Authorized:

- bounded documentation/test edits described above;
- task-owned external validation and evidence;
- review-package creation outside the repository.

Not authorized:

- production/source/schema/migration edits;
- subagents;
- stage;
- commit;
- push;
- upstream creation;
- PR;
- merge;
- publication;
- deployment;
- network/service contact;
- provider/worker/ES/Bridge/product database use;
- terminal persistence or product effect.

REQUIRED FINAL RESPONSE

Return one of:

- `RW0_C2_P0_P1_LOCAL_COMMIT_STATUS_SUCCESSOR_IMPLEMENTED_VALIDATED_PENDING_REVIEW`
- `RW0_C2_P0_P1_STATUS_SUCCESSOR_BLOCKED_<PRECISE_REASON>`

Include:

- exact opening commit/tree/branch/upstream;
- exact successor source tree;
- complete touched-path list and classification;
- passage classification summary;
- current status wording and historical preservation treatment;
- complete assurance-consumer treatment;
- first-checkpoint identity and result;
- final focused selector, collection/execution/JUnit reconciliation;
- warnings;
- exact patch and manifest identities;
- review ZIP path, bytes, SHA-256;
- standalone/embedded report equality;
- assumptions, residual observations, and unperformed validation;
- explicit:
  `INDEPENDENT_REVIEW_NOT_PERFORMED`
  `STAGING_NOT_PERFORMED`
  `COMMIT_NOT_PERFORMED`
  `PUSH_NOT_PERFORMED`
  `PR_NOT_CREATED`
  `MERGE_NOT_PERFORMED`
  `PUBLICATION_NOT_PERFORMED`
  `DEPLOYMENT_NOT_PERFORMED`
  `PRODUCT_EFFECT_NOT_PERFORMED`

The next recipient after a successful return is a fresh read-only Codex
artifact-review conversation. Do not start that audit in this conversation.
