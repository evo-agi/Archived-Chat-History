OBJECTIVE

Repair the exact uncommitted RW0-C2 P0→P1 candidate by separating universal
current disclosure/recording posture from acceptance-only current
unclaimed-scope eligibility.

This is a workspace-write continuation in the SAME implementation Codex
conversation that produced the command-digest-v2 / protected-disclosure
candidate. The parent is the sole writer. Do not spawn subagents.

The command-digest-v2 repair is preserved. This engagement repairs only the
remaining protected-disclosure/acceptance-eligibility conflation and directly
dependent documentation/tests.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

AUTHENTICATED STARTING SUBJECT

Before editing, authenticate:

- branch:
  `codex/rw0-c2-p0-p1-physical-program-v1`
- HEAD, local `trunk_dev`, and local `origin/trunk_dev`:
  `4519630d0db967066beb21b4ace5004e76827716`
- HEAD tree:
  `15461a58da8df9ebd63fce734d39a07a50ab87ac`
- upstream: absent
- source paths: `315`
- current uncommitted Git-compatible tree:
  `58444e6a1c9526a524818e8729398ff0ab381837`
- source-manifest SHA-256:
  `de940048a5b16d438257ee690b98fdab870069555fe510ba3c293ba1dc1520df`
- cumulative checkout:
  `56 modified, 16 created, 0 deleted, 243 unchanged`
- tracked binary diff:
  `194,237` bytes
- tracked binary diff SHA-256:
  `5bbf0387146060d84bcc9bfac84023a14eb7ad146bad62460a8c3a63e301e522`
- semantic index SHA-256:
  `377904010960fb2b7fdaf5caf8eb6135880a1ba85f1e86be9841795430f76f21`
- raw index SHA-256:
  `ff0440db74511629c310a0b1a49000b56fddcaf7464334d892a4a252fa2221bb`
- configuration SHA-256:
  `8cec84aeea4df3bd9701b05835eb36cf4038c8c116f539f60b0df685f956beca`
- prospective authoritative-ref map SHA-256:
  `95f651b2ff1cf21007e1609d789a94bb104d748d3e2174441d45b5f58b641d2c`
- qualified diagnostic refs at the preceding close:
  `18`, with no opening-to-close additions, removals, or retargets
- migration 0006 SHA-256:
  `58b2731d52e8e199c010b309a29aa831ffb16d4db4e755d20adb694ce0a7305f`
- migration 0007 SHA-256:
  `505d72c9c54f68e248bebab928e76564d45b853068b8b4021ebc708b640e430c`
- schema after 0006:
  `68 tables / 122 triggers / 5 explicit indexes`
- schema after 0007:
  `74 tables / 134 triggers / 5 explicit indexes`
- application generation: `2`
- review ZIP:
  `33,728,895` bytes
  SHA-256
  `aa7d22d6df888c0928917939957fc6746c5064c83b75c949360155ab151e39b8`
- standalone/embedded implementation report:
  `25,174` bytes
  SHA-256
  `ff2691d3c5e74959abbb6a4414af47e99bb045b50a0134d00a42a652487d710b`

Require an empty staged diff and exact source correspondence. Preserve the v5
authoritative-versus-diagnostic-ref policy, prior v4 evidence, and all historical
provenance limits. Stop on a source, branch, HEAD, index, configuration,
authoritative-ref, migration, schema, or path-set mismatch. Do not reset, clean,
restore, rebase, or mutate refs to make the opening pass.

ENGINEERING FINDING

The current candidate repaired disclosure gating by calling:

`ArtificialDecisionGuardSourceV1.checked_for(..., write=False)`

before receipt-present read/replay/recovery. That method still combines two
different contracts:

1. universal current posture for protected disclosure/recording; and
2. acceptance-only exhaustive unclaimed-scope eligibility.

Exact source:

- `src/ge_nwp_coordinator/_rw0_c2_progression_contracts.py:637-678`
- `src/ge_nwp_coordinator/_sqlite_rw0_c2_progression.py:471-493`
- `tests/test_sqlite_rw0_c2_progression.py:785-884`

`checked_for` currently rejects
`acceptance_exhaustively_unclaimed=False` and requires that current field to
equal the historical basis field for both `write=True` and `write=False`.

This conflicts with the governing guard owner:

- `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md:65-85`
  makes unclaimed-scope proof acceptance-only and permits nonaccept branches
  without an unclaimed-scope assertion;
- `:102-120` says replay does not reevaluate fresh claimed status, receipt-first
  replay precedes fresh acceptance eligibility, and exact replay returns the
  original complete family without eligibility reevaluation;
- `.docs/rw0-c2-private-value-versioning.md:262-273,301-380,480-494`
  defines protected replay/recovery current posture through fresh continuity
  and sole-active posture, not current acceptance eligibility.

After an acceptance commits, truthful current state is no longer exhaustively
unclaimed. The current implementation can replay the accepted family only by
supplying stale `True`. Truthful `False` blocks replay/read/recovery. It also
globally blocks nonaccept work solely because scope is claimed.

No unsafe write is established; the current path fails closed. The defect is
material authority/replay classification.

FROZEN REPAIR DECISION

Keep the existing `ArtificialDecisionGuardSourceV1` field shape. Split its
validation responsibilities.

A. Universal current posture

Define a private pure/current-source owner—separate methods or an exact purpose
argument are acceptable—that validates:

- exact source and field types;
- current time window;
- continuity positive and exact basis/source binding;
- sole-active positive and exact basis/source binding;
- no foreign claim and exact historical binding;
- disclosure permission for protected read/replay/recovery;
- recording permission for a fresh receipt miss.

`acceptance_exhaustively_unclaimed` must be exact `bool` or `None`, but universal
posture must not:

- require it to be true;
- compare it with the historical basis;
- use it to disclose a committed result;
- use it as continuity or sole-active evidence.

B. Acceptance-only fresh eligibility

After receipt miss, universal recording posture, route/current checks, and
authoritative branch derivation:

- only `candidate_acceptance` requires:
  - historical basis
    `bootstrap_guard_evidence.acceptance_exhaustively_unclaimed is True`; and
  - current source
    `acceptance_exhaustively_unclaimed is True`.
- every nonaccept branch ignores current claimed status after exact type
  validation. It creates no acceptance fact and makes no unclaimed-scope
  assertion.
- current `False` or `None` cannot authorize acceptance.
- a current claimed status is evidence only for acceptance eligibility/recovery
  contradiction handling; it cannot select or veto a nonaccept branch.

C. Receipt-present protected replay/read

Required order:

1. receipt lookup;
2. fresh universal disclosure-posture validation;
3. exact command-digest-v2 association;
4. complete immutable-family reconstruction;
5. protected committed result.

Do not compare current acceptance status to the historical basis. Do not rerun
fresh acceptance eligibility.

D. Receipt-absent recovery

Recovery still requires fresh universal disclosure posture and
`old_execution_excluded`.

- A complete exact original family returns `committed_exact`, regardless of
  current claimed status.
- A complete competing acceptance winner may prove the original command
  `definitely_not_committed` without disclosing the winner and without granting
  retry.
- If current status is explicitly claimed (`False`) but no complete local winner
  proves that claim, treat the contradiction as `unresolved`; do not turn local
  absence into proof.
- Where no contradictory claimed-state evidence exists, preserve the current
  exhaustive-route absence classification.
- Recovery never grants fresh acceptance eligibility.

E. Historical basis

The persisted Decision Basis v2 guard field remains immutable evidence of what
the authoritative decision basis asserted at decision time. Do not rewrite it,
change its 23-field grammar, or make it a current source. Historical replay
verifies the basis and family; current universal posture only gates disclosure.

PRESERVATION REQUIREMENTS

Preserve byte-for-byte:

- migrations 0001–0007;
- migration catalog and schema counts;
- migration 0006 and both P0 production owners;
- Decision Basis v1/v2 field grammars;
- guarded-command-digest v1/v2 definitions and vectors;
- the six sibling preassignments;
- relation/result/receipt-profile v2 field shapes and graph roles;
- historical program/work-head witness;
- WorkSpecV1 and migration-0002 meanings;
- five branch meanings and acceptance-only fact;
- public StateStore/package exports;
- terminal/live boundaries.

No table, column, migration, digest-field shape, receipt role, preassignment, or
new repository path is authorized.

REQUIRED CAUSAL CONTROLS

Use real writer/session/controller paths and task-owned databases.

1. Truthful post-acceptance replay

- Commit one valid `candidate_acceptance` family using current unclaimed status
  `True`.
- Construct a fresh current source with:
  - exact positive continuity;
  - exact positive sole-active posture;
  - no foreign claim;
  - disclosure permitted;
  - recording denied;
  - `acceptance_exhaustively_unclaimed=False`.
- Require exact record replay, exact checked read, and recovery
  `committed_exact`.
- Require exact fresh/replay committed-result equality.
- Require no row, receipt, version, program-head, or work-head movement.

2. Truthful post-claim nonaccept replay

For at least one committed nonaccept branch, change current claimed status to
`False` while keeping universal disclosure posture positive. Require exact
replay/read/recovery and no durable movement.

3. Acceptance-only fresh refusal

With no receipt and current status `False` and again with `None`:

- a command that authoritatively derives `candidate_acceptance` must return the
  existing bootstrap-acceptance-guard conflict;
- no target row, receipt, version, program-head, or work-head may move;
- route probing/current-state reads may occur only in the existing authorized
  order.

4. Fresh nonaccept under claimed status

With exact universal recording posture and current status `False`, reach at
least one real nonaccept branch. Require that claimed status alone does not
produce a guard conflict. The branch's existing currentness, matrix, and
program-state rules remain authoritative.

5. Competing winner

Commit a complete competing acceptance winner. Recover a distinct original
command with current claimed status `False`. Require
`definitely_not_committed`, no winner disclosure, no retry permission, and no
durable movement.

6. Contradictory claimed status

For an original receipt-absent command, provide current claimed status `False`
but no complete local acceptance winner. Require `unresolved`, never
`definitely_not_committed`.

7. Universal disclosure negatives

Retain denied, expired, continuity-negative, sole-active-negative,
source-mismatched, malformed-source, and process-control controls. They must
still disclose no committed result; recovery is unresolved; no write or retry
occurs.

8. Regression preservation

Retain:

- guarded-command-digest-v2 changed-assertion conflict and exact replay;
- all five physical branches;
- second-replan historical work-head replay;
- program/work-head CAS no-op and readback rollback;
- graph, collision, partial-family, competing-winner and uncertainty controls;
- P0 replay/recovery;
- connected P0→D1/D2→Section 41/C1/V22→P1 composition.

DOCUMENTATION

Update the actual owners together:

- `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md`
- `.docs/rw0-c2-private-value-versioning.md`
- `.docs/rw0-c2-physical-p0-p1-implementation.md`
- `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
- `.docs/c2b-durable-development-state.md` only where it directly describes the
  current protected-disclosure implementation
- `AGENTS.md` only if its current P0/P1 status block directly embeds the
  superseded behavior

Required wording:

- universal current posture is continuity, sole-active authority, no foreign
  claim, time validity, and the relevant disclosure/recording permission;
- exhaustive unclaimed-scope proof is acceptance-only;
- protected exact replay does not reevaluate current claimed status;
- current claimed status false without a complete local winner is contradictory
  recovery evidence and remains unresolved;
- nonaccept branches make no unclaimed-scope assertion;
- no live/product authority is added.

Preserve all historical predecessor blocks and nonclaims.

AUTHORIZED FILE CEILING

Expected production:

- `src/ge_nwp_coordinator/_rw0_c2_progression_contracts.py`
- `src/ge_nwp_coordinator/_sqlite_rw0_c2_progression.py`
- `src/ge_nwp_coordinator/sqlite_transition_transaction.py` only if direct API
  plumbing requires it
- `src/ge_nwp_coordinator/sqlite_writer_session.py` only if direct private
  signature plumbing requires it

Expected tests:

- `tests/test_rw0_c2_progression_contracts.py`
- `tests/test_sqlite_rw0_c2_progression.py`
- `tests/test_sqlite_rw0_c2_connected.py`
- `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py`
- `tests/test_rw0_c2_private_value_versioning_contract.py`
- `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`
- directly dependent exact-hash/status consumers only after recording the source
  dependency

Expected documents are the owners above.

No new repository path is expected. No migration, SQL, P0 production owner,
Decision Basis field owner, command-digest profile, relation/result row owner,
WorkSpec owner, public API, terminal owner, provider/worker route, ES/Bridge
integration, or product-Git path may change.

FIRST SUBSTANTIVE CHECKPOINT

Before broad validation:

1. authenticate and save the complete repaired source identity;
2. run the truthful post-acceptance replay/read/recovery control;
3. run the post-claim nonaccept replay control;
4. run acceptance-only false/None fresh-refusal controls;
5. run fresh nonaccept under claimed status;
6. run competing-winner and contradictory-claimed-state recovery controls;
7. retain command-digest-v2 identity/replay controls;
8. verify migrations 0006/0007 and 68/122/5 plus 74/134/5 schema manifests
   unchanged;
9. verify P0 checkpoint production bytes exact;
10. save, reopen, and member-verify the checkpoint.

FINAL VALIDATION

Run only in fresh authenticated external copies of FINAL source:

1. direct repair controls;
2. connected five-branch selection;
3. prior focused 49-module selection plus every directly touched assurance module;
4. selector-free collection;
5. selector-free FULL execution.

Do not assume the old count `9,461`. Freeze final collection before execution.
Require:

- unique collected IDs;
- exact collected/executed/JUnit identity and order;
- zero failures, errors, or skips;
- exact warning inventory;
- source bytes and numeric modes unchanged before/after;
- migrations 0006/0007 byte-exact;
- exact 68/122/5 and 74/134/5 schema manifests.

Failed, interrupted, or superseded attempts receive no final credit.

PROVENANCE AND DELIVERY

Use the current v5 prospective provenance treatment. Preserve v4 and historical
full-ref observations unchanged.

At closeout:

- two byte-identical final v5 canonical captures and one post-cleanup capture;
- exact authoritative-ref map stable from opening through cleanup;
- complete diagnostic-ref inventories/deltas with no surviving-name retarget;
- source tree, full changed-path inventory, tracked binary diff, recipe bytes and
  hash, migrations, schema manifests, commands, environments, ordered IDs,
  JUnit, warnings, checkpoint, and cleanup evidence;
- standalone implementation report written before packaging;
- byte-identical report at `evidence/IMPLEMENTATION_REPORT.md`;
- one sealed cumulative review ZIP with complete source and safe evidence;
- full reopen/member verification;
- adjacent delivery receipt with outer ZIP bytes and SHA-256;
- new Git-compatible source tree.

The report must retain the earlier audit findings, historical mode/ref limits,
F03 and F05 as unrepaired observations, and the exact distinction between
implementation validation and independent audit.

STOP CONDITIONS

Stop without staging if:

- opening identity differs;
- the repair requires schema, migration, basis, command-digest, relation/result/
  profile, WorkSpec, preassignment, or branch-semantic change;
- universal posture cannot be separated from acceptance eligibility without a
  durable-shape change;
- truthful post-acceptance replay cannot return the original committed family;
- any branch loses exact replay/readback/recovery;
- migration 0006 or a P0 production byte changes;
- final validation cannot complete;
- a required path exceeds the authorized/direct-consumer ceiling without a
  source-grounded dependency;
- authority, security, privacy, or durable-state scope would widen.

EFFECT CEILING

Authorized:

- bounded repository source/document/test edits above;
- task-owned external source copies and synthetic SQLite state;
- local test execution;
- inert evidence and review-package creation outside the repository.

Not authorized:

- subagents;
- staging;
- commit;
- push;
- PR;
- merge;
- publication;
- deployment;
- network/service contact;
- live supplier/provider/worker/ES/Bridge use;
- user/product database access;
- terminal persistence or any product effect.

REQUIRED FINAL RESPONSE

Return one of:

- `RW0_C2_P0_P1_DISCLOSURE_ELIGIBILITY_SPLIT_REPAIR_IMPLEMENTED_VALIDATED_PENDING_AUDIT`
- `RW0_C2_P0_P1_DISCLOSURE_ELIGIBILITY_SPLIT_REPAIR_BLOCKED_<PRECISE_REASON>`

Include:

- opening/final source identities;
- complete touched-file list and classifications;
- exact universal-posture and acceptance-eligibility APIs;
- receipt-present replay/read/recovery order;
- fresh-acceptance eligibility order;
- truthful post-acceptance and post-claim replay results;
- competing-winner and contradictory-claim results;
- checkpoint identity and reopen result;
- connected/focused/FULL commands and results;
- collection/execution/JUnit reconciliation;
- migration/P0 preservation and schema manifests;
- provenance-v5 identities and ref deltas;
- standalone/embedded report equality;
- review ZIP path, bytes, SHA-256;
- assumptions, residual observations, skipped/unavailable validation;
- explicit no-stage/no-commit/no-publication/no-network/no-product-effect record.

Do not claim F03 or F05 was repaired.
