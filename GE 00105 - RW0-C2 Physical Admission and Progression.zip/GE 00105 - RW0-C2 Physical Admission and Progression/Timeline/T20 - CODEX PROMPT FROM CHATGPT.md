OBJECTIVE

Perform a fresh, cumulative, artifact-only independent audit of the repaired
RW0-C2 P0→P1 artificial-offline physical program.

The subject includes P0 scope-admission persistence, P1 five-branch physical
progression, the versioned replan historical work-head witness, and the
Decision Basis v2 repair that durably binds the exact typed validation and
independent-review dispositions consumed by the reducer.

This is an independent audit. Do not repair or modify the candidate.

RECIPIENT AND POSTURE

Use a FRESH Codex conversation, separate from every implementation or prior
audit conversation.

Artifact-only posture:

- do not access any live repository, `.git`, ref, index, config, cache,
  worktree, remote, Downloads path, or operator state;
- do not contact a network, GitHub, provider, ES, Bridge, service, or user
  database;
- do not execute archived helper programs;
- use only audit-authored inspection/extraction scripts and repository tests
  from isolated audit-owned copies of the authenticated source;
- no candidate edit, formatting, cleanup of supplied inputs, staging, commit,
  publication, migration of a user database, or product effect.

SUPPLIED INPUTS — EXACTLY THREE

1. `rw0-c2-p0-p1-decision-basis-v2-uncommitted-review.zip`
   - 13,024,080 bytes
   - SHA-256
     `675748890d754e4cfefe634b78019cfbaa68cdbd6b653657b98dc39b1164ffa0`

2. `RW0_C2_P0_P1_DECISION_BASIS_V2_IMPLEMENTATION_REPORT.md`
   - 20,614 bytes
   - SHA-256
     `a6f2eae980785736ee26276381519b5e45044bb1fbf38e87f41c61d9a33326ec`

3. `Coordinator_PostD2_PR16_SquashSourceCheckpoint_20261024.zip`
   - 3,245,477 bytes
   - SHA-256
     `087990b15ded609615659c0927f849cf656c4b0cabd6de78339add4410a74166`
   - integrated baseline commit
     `4519630d0db967066beb21b4ace5004e76827716`
   - integrated baseline tree
     `15461a58da8df9ebd63fce734d39a07a50ab87ac`
   - 299 tracked source files

The standalone report must be byte-identical to
`evidence/IMPLEMENTATION_REPORT.md` in the review ZIP. Unlike a previous
superseded audit gate, the report is in fact embedded in this package.

EXPECTED SUBJECT

- final source paths: 315
- final Git-compatible tree:
  `8e247b21320f90d2d2cb98d3d165f7fc35f117a8`
- final source-manifest SHA-256:
  `894f3a690cd5457415260f5a5a35650764b11ed3203c28672649835df705ba12`
- baseline-to-final delta:
  - 56 modified
  - 16 created
  - 0 deleted
  - 243 unchanged
- Decision Basis v2 repair from the previously audited opening:
  - 26 modified existing paths
  - 0 created
  - 0 deleted
- final migration 0006 SHA-256:
  `58b2731d52e8e199c010b309a29aa831ffb16d4db4e755d20adb694ce0a7305f`
- final migration 0007 SHA-256:
  `505d72c9c54f68e248bebab928e76564d45b853068b8b4021ebc708b640e430c`
- cumulative schema:
  - 74 user tables
  - 134 triggers
  - 5 explicit indexes
  - application generation 2

PREVIOUS AUDIT CONTEXT — EVIDENCE TO RECHECK, NOT CREDIT

The predecessor tree
`f6801df592af049a6aaef658f721fc1afe27ad6e`
was independently authenticated but blocked by a material defect:

- a valid stale-currentness P1 block committed a complete durable family;
- final reason was `decision_basis_not_current`;
- the distinct candidate evidence reason was not durably reconstructible;
- exact replay/readback failed and recovery returned `unresolved`.

A later implementation stop established the root cause: the 21-field basis and
persisted plan discarded the typed validation/review facts needed to derive the
candidate reason. Guessing from the final decision reason was invalid.

The repaired candidate claims:

- historical `DecisionBasisV1` remains parseable predecessor evidence;
- current mutation accepts only 23-field `DecisionBasisV2`;
- v2 adds exact typed `validation_disposition` and
  `independent_review_disposition` before `captured_at` and `basis_digest`;
- one pure `derive_candidate_evidence_reason` helper is used by fresh reduction
  and historical reconstruction;
- no candidate-reason result column was added;
- migration 0007 changes only the decision-basis schema-ID CHECK from v1 to v2;
- all downstream command/preassignment/replan/WorkSpec/relation/result/graph/
  receipt identities are regenerated from the v2 basis;
- optional `expected_branch` now accepts only `None` or exact built-in `str`;
- two stale current-tip documents and a weakened schema-name negative assurance
  were corrected;
- F03 (bounded P0 target-grammar difference) and F05 (P0 time-before-collision
  error precedence) remain disclosed nonblocking observations, not claimed
  repairs.

A successful audit must establish these facts independently.

PHASE 1 — AUTHENTICATION AND SAFE EXTRACTION

Before source judgment or test execution:

1. Hash all three supplied inputs and require the fixed identities above.
2. Inspect both ZIP central directories before extraction. Reject duplicate or
   case-fold-colliding names, absolute/traversal/ambiguous paths, links, special
   files, encryption, unsupported modes, or excessive member/expanded sizes.
3. Verify the review ZIP has exactly 422 members and that
   `package-inventory.json` covers the other 421 members completely by path,
   size, SHA-256, and numeric mode.
4. Require the standalone report to equal
   `evidence/IMPLEMENTATION_REPORT.md` byte-for-byte.
5. Verify every entry in
   `evidence/current/canonical-final-1-source-manifest.json` against the 315
   `source/` members by path, size, SHA-256, Git blob ID, OS mode, and Git mode.
6. Independently reconstruct final tree `8e247b...` from source bytes and Git
   modes.
7. Authenticate the complete 299-file integrated baseline checkpoint and
   independently reconstruct tree `15461a...`.
8. Compare baseline and final source endpoint-by-endpoint and require the exact
   56/16/0 delta. Replay or otherwise independently verify the retained tracked
   binary diff where feasible; do not rely on count equality alone.
9. Authenticate the P0 checkpoint and Decision Basis v2 first checkpoint inside
   the review ZIP, including their complete manifests and reported trees.
10. Verify the two final captures and post-cleanup capture are byte-identical,
    and distinguish those retained observations from any live Git claim.

Stop with `AUDIT_PROVENANCE_MISMATCH` before correctness review if any required
identity or complete coverage check fails.

PHASE 2 — CUMULATIVE SOURCE, CONTRACT, AND AUTHORITY REVIEW

Review the complete final source, not only the 26-file repair delta. Produce an
A01–A18 register with exact archive-relative path:line evidence, evidence class
(source inspection, test-design inspection, independent execution, retained
record, inference, limit), finding severity, and unperformed coverage.

A01 — authority split and effect ceiling

- external standing policy/enrollment evidence remains external;
- P0 records program-independent admission and grants no current authority;
- P1 is the sole durable five-branch decision author;
- model/replan proposal remains evidence, not branch authority;
- guarded SQLite mechanics do not become policy authority;
- no live supplier, worker/provider, ES/Bridge, Git-product, service, scheduler,
  terminal-outcome, deployment, or autonomous-loop authority is introduced.

A02 — P0 grammar, SQL, uniqueness, replay, recovery

- four immutable migration-0006 families;
- independent act, lineage, and scope uniqueness routes;
- receipt-first exact replay;
- conflict/foreign/partial/malformed handling;
- one commit attempt and three-way read-only recovery;
- P0-complete/P1-absent remains truthful and grants no P1 decision.

A03 — migration 0006 preservation

- exact SQL and P0 production-owner bytes equal the retained checkpoint;
- exact 68/122/5 historical schema prefix;
- explicit migration-only upgrade and old-binary/newer-prefix refusal;
- no seed, auto-migration, or generation change.

A04 — Decision Basis v1/v2 versioning

- v1 remains parseable historical blocked predecessor only;
- current mutation and physical row schema accept v2 only;
- exact 23-field closed grammar and documented location/order of both new
  disposition fields;
- canonical duplicate-free encoding, exact built-in types, bool-as-int refusal,
  unknown-key refusal, depth/node/list/string bounds, and 49,152-byte ceiling;
- basis self-digest excludes only itself.

A05 — typed validation/review durability and privacy

- v2 persists exact canonical safe V14/V15 mappings, not raw checker output,
  narrative, prompt, path, process state, environment, or private payload;
- each typed disposition is closed and field-valid;
- program/version/intent/work/attempt/candidate/fence and source-observation
  coordinates are bound to the decision snapshot;
- detached values cannot disagree with basis-owned values and reach route probes
  or writes;
- identify precisely which owner establishes that these dispositions are the
  evidence the reducer is permitted to consume in this bounded proof. Do not
  assume self-consistency alone is external authentication.

A06 — candidate classification owner

- one pure helper owns validation/review normalization, conflict handling,
  nonconclusive precedence, and conclusive severity;
- fresh reduction and historical reconstruction use exactly that helper;
- finite mapping agrees with the governing semantic contract;
- invalid or unknown tuples fail closed rather than receiving a candidate
  reason.

A07 — expected-branch exact type and nonauthority

- `None` or exact built-in `str` only;
- subclasses and equality-overriding objects rejected before equality;
- finite branch vocabulary retained;
- field remains conflict assertion only, not branch authority.

A08 — noncircular replan identity

- version-neutral cognitive template;
- proposal → basis v2 → six branch-neutral preassignments → command →
  Coordinator-derived intent/work/WorkSpec refs → unchanged WorkSpec semantics;
- no placeholder, fixed-point construction, seventh preassignment, or
  model-owned durable identity;
- exact current identity vector is independently reconstructed.

A09 — migrations 0007 and compatibility

- same six supplemental tables and twelve guards;
- only decision-basis schema-ID CHECK changes relative to the authenticated
  predecessor 0007;
- 74/134/5 cumulative schema, application generation 2;
- every 0006 object remains unchanged;
- no migration 0008 or hidden row/column/table change.

A10 — P1 five-branch reducer and branch rows

- all five branch meanings preserved;
- acceptance fact only on `candidate_acceptance`;
- replan proposal required only on replan;
- block reasons retain candidate reason separately;
- model recommendation consistency cannot choose or override the branch;
- no-write conflict, durable block, and unresolved recovery remain distinct.

A11 — fresh P1 transaction and CAS/readback

- fencing and current 0002 preimage verification;
- immutable rows before receipt;
- program-head CAS and replan work-head CAS;
- both actual postimages read and type-checked in the same transaction;
- complete family/graph verification;
- receipt last and one commit attempt;
- CAS no-op/wrong-count/readback mismatch roll back all target rows.

A12 — historical program/work-head witnesses

- relation/result/profile v2 shape and branch nullability;
- exact replan-only historical work-head postimage and graph role;
- later second replan can advance current heads while the first replan remains
  exactly replayable;
- no dependence on mutable current heads for historical verification.

A13 — F01 repaired durable replay/readback/recovery

Independently inspect and execute real-writer cases proving:

- at least five stale-currentness durable block families share final reason
  `decision_basis_not_current` while retaining the five distinct valid candidate
  reasons;
- basis and command identities differ when typed dispositions differ;
- each exact command replays and reads exactly;
- recovery returns `committed_exact`;
- replay/read/recovery create no row, receipt, version, or head movement;
- `productive_branch_not_permitted` and nonconclusive blocks retain exact
  candidate/final reason separation;
- unresealed disposition tamper is integrity failure/unresolved;
- a foreign resealed basis on an occupied mutation route conflicts rather than
  replays;
- malformed persisted dispositions are never normalized into valid evidence.

A14 — receipt graph, collisions, and competing families

- branch-specific graph roles and counts;
- acceptance alias uniqueness;
- global creation-route probes, memberships, revision edges, WorkSpec, mutation
  refs, family routes, and competing complete winner handling;
- exact receipt-first command association;
- no upsert/adoption/fragment repair/hidden retry.

A15 — P1 recovery

- `committed_exact` only for complete exact family;
- `definitely_not_committed` only after exhaustive original-route absence under
  positive prerequisites;
- partial/foreign/malformed/contradictory/inaccessible evidence is unresolved;
- no cognition rerun or caller replacement evidence during historical replay.

A16 — connected physical composition

- P0 → D1/D2 → Section 41 A → C1 rank-15 B → V22 → P1;
- all five P1 branches;
- P0 complete with P1 absent;
- no terminal-outcome row;
- artificial fixture/custody boundaries and product nonclaims remain explicit.

A17 — shared writer/session/controller and regressions

- changes are additive/private;
- earlier F1 hot-journal behavior remains unchanged;
- no public StateStore/package export or production caller;
- Section 41/C1 and existing migration/transaction boundaries remain intact;
- inspect the direct shared-file changes, not only new P0/P1 modules.

A18 — documentation, assurance, artifacts, and retained observations

- Decision Basis v1/v2 docs and current migration-tip successors are accurate;
- the strengthened schema/versioning assurance is semantic, not incidental
  literal matching;
- F03 and F05 remain accurately disclosed and are not silently claimed fixed;
- no secret, credential, database sidecar, cache, bytecode, or unsafe artifact is
  packaged;
- retained validation and provenance are evidence, not authority.

PHASE 3 — INDEPENDENT CAUSAL EXECUTION

After source review finds no blocker, execute in audit-owned isolated copies of
the exact final source. Use the installed Python environment only; install
nothing. Disable bytecode, plugin autoload, and pytest cache; use audit-owned
HOME/TMPDIR/basetemps/JUnit and no network.

Required causal controls before FULL:

1. Real-writer stale-currentness F01 matrix covering all five candidate reasons,
   exact replay/readback and committed recovery.
2. Real-writer `productive_branch_not_permitted` and nonconclusive block.
3. Persisted disposition tamper, resealed foreign basis, and detached transient
   mismatch.
4. Exact built-in `expected_branch` gate including equality-overriding subclass.
5. Acceptance, repair, replan, terminal-reject and block physical branches.
6. Replan program/work-head CAS no-op and readback mismatch rollback.
7. Second-replan historical replay of the first work-head witness.
8. Receipt graph/witness/nullability mutants, collisions, partial family,
   competing winner, commit uncertainty, cleanup uncertainty and no-hidden-retry.
9. P0 fresh/replay/collision/partial/foreign/uncertainty and all three recovery
   classes.
10. Connected five-branch P0→D1/D2→Section 41/C1/V22→P1 composition.
11. Disk migration and supported-prefix/old-binary refusal appropriate to the
    installed runtime.

Preserve exact injection-point evidence. A passing broad suite alone does not
supply causal credit for an unreached predicate.

PHASE 4 — INDEPENDENT SELECTOR-FREE FULL VALIDATION

If no material source or causal blocker exists:

1. run one selector-free collection on a fresh exact source copy;
2. require exactly 9,438 unique node IDs unless the authenticated source itself
   establishes a different legitimate collection before execution;
3. freeze the collection;
4. run one selector-free FULL execution on the same source bytes;
5. require exact collected/executed/JUnit identity and order;
6. require zero failures, errors, skips, xfails and xpasses;
7. report the exact warning inventory;
8. verify all 315 source bytes and numeric modes before and after both phases.

The writer-retained 108 direct, 5 connected, 5,796 focused and 9,438 FULL
records must be reconciled as historical implementation evidence, not promoted
to independent execution credit.

STOP AND COVERAGE RULES

- A material finding may stop further execution after a source-bound reproducer.
- Preserve completed authentication and review findings.
- Enumerate every unperformed A-row, causal control and validation gate.
- A platform refusal or unavailable required step yields an incomplete audit,
  not acceptance and not a candidate defect.
- Do not repair the source in this engagement.

REQUIRED DISPOSITION

Return exactly one primary disposition:

- `RW0_C2_P0_P1_DECISION_BASIS_V2_CUMULATIVE_AUDIT_ACCEPTED_READY_FOR_COMMIT_GATE`
- `RW0_C2_P0_P1_DECISION_BASIS_V2_CUMULATIVE_AUDIT_BLOCKED`
- `AUDIT_PROVENANCE_MISMATCH`
- `RW0_C2_P0_P1_DECISION_BASIS_V2_CUMULATIVE_AUDIT_INCOMPLETE`

Acceptance applies only to exact tree
`8e247b21320f90d2d2cb98d3d165f7fc35f117a8` and authorizes only a later,
separately governed exact-byte commit gate.

REQUIRED RETURN

Return one complete inline report and one reopened safe audit-evidence ZIP.
Include:

- exact input identities and package safety results;
- exact final and baseline tree reconstructions and delta;
- standalone/embedded report equality;
- A01–A18 register with path:line evidence and evidence classes;
- findings by severity and type;
- exact causal commands, environments, outcomes and source bindings;
- selector-free collection/FULL identities and warning inventory;
- retained writer-evidence reconciliation;
- unperformed coverage and limits;
- audit evidence ZIP size and SHA-256;
- explicit no-edit/no-live-repo/no-network/no-stage/no-commit/no-publication/
  no-product-effect record.
