The current P0 reconnaissance prompt remains unexecuted.

Before reissuing it, correct both its engineering scope and its operating
handoff.

Engineering:
- compare standalone P0 against P0 as the first checkpoint in one P0→P1
  implementation program;
- make this the final broad physical-architecture mapping pass;
- require READY to lead directly to source/schema implementation;
- permit no intervening standalone semantic-contract tranche.

Handoff:
- state explicitly that the preceding tranche is merged and closed;
- identify this as a fresh read-only Codex reconnaissance;
- require no attachments and no Downloads/checkpoint lookup;
- use only the exact matching repository checkout as current truth;
- return the complete operative report inline;
- generate no external report artifact or freeze package;
- state the exact expected next recipient and action after Codex returns;
- explicitly state whether a new Project-source snapshot is requested.

Also provide a compact engagement envelope before the replacement prompt with:
CURRENT STATE, RECIPIENT, ATTACHMENTS, AUTHORIZED EFFECTS, EXPECTED RETURN,
PROJECT SNAPSHOT, and NEXT ACTION.

Return one complete replacement prompt, not a delta.
Do not issue an implementation prompt.
