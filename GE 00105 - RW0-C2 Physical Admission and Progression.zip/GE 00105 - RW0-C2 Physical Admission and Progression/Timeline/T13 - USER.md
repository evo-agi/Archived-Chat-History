Here is Codex's response:

# RW0-C2 P0→P1 independent artifact audit

**Primary disposition: `AUDIT_PROVENANCE_MISMATCH`**

The supplied review ZIP matches the fixed outer identity: **64,047,683 bytes**, SHA-256 `8e9aa5869fe894e873b6e0562cb2bbb319ffad1965aeaa0075b35dc18ad42e76`. Authentication stops at the required report-equality gate. The ZIP contains no member named `RW0_C2_P0_P1_IMPLEMENTATION_REPORT.md` and no member of its stated **17,782-byte** size. Neither does any of its 11 nested ZIPs. A standalone report was not supplied at an accessible path. Historical reports in prior-cycle archives cannot establish equality with the required current report.

This is an **artifact provenance mismatch**, not a finding about the candidate source code. The absence is established from the whole central-directory inventory and `package-inventory.json`; it has no source line range. See the [stop-gate record](/private/tmp/rw0-c2-independent-auth-2xjzjifr/provenance-stop-gate.json), [report-presence check](/private/tmp/rw0-c2-independent-auth-2xjzjifr/report-presence-check.json), and [member-name inventory](/private/tmp/rw0-c2-independent-auth-2xjzjifr/outer-central-directory-names.txt).

## Authentication and review register

The outer directory has 452 names, distinct under the audit’s normalization and case-folding check. That preliminary check does **not** establish complete package safety, manifest coverage, source identity, or Git tree identity. Baseline reconstruction, the 54/16/0 changed-path claim, diff replay, provenance recipe, checkpoint identities, migration hashes, and cumulative schema claims remain unverified.

| Row | Review scope                                  | Evidence and result               |
| --- | --------------------------------------------- | --------------------------------- |
| A01 | Contract and authority split                  | Unperformed after provenance stop |
| A02 | P0 values, SQL family, uniqueness             | Unperformed after provenance stop |
| A03 | P0 transaction and recovery                   | Unperformed after provenance stop |
| A04 | Migrations 0006/0007 and compatibility        | Unperformed after provenance stop |
| A05 | P1 command, basis, row, graph grammars        | Unperformed after provenance stop |
| A06 | Five branches and acceptance fact             | Unperformed after provenance stop |
| A07 | Replan identity and 0002 semantics            | Unperformed after provenance stop |
| A08 | Historical work-head witness                  | Unperformed after provenance stop |
| A09 | P1 atomicity and head CAS                     | Unperformed after provenance stop |
| A10 | P1 replay and recovery                        | Unperformed after provenance stop |
| A11 | Second replan and historical completeness     | Unperformed after provenance stop |
| A12 | Collisions, membership, graph isolation       | Unperformed after provenance stop |
| A13 | Connected P0→D1/D2→Section 41/C1/V22→P1 path  | Unperformed after provenance stop |
| A14 | Shared writer, session, controller boundaries | Unperformed after provenance stop |
| A15 | Documentation and assurance consumers         | Unperformed after provenance stop |
| A16 | Security, privacy, artifacts, nonclaims       | Unperformed after provenance stop |

There are no source findings or source line anchors because correctness review stopped before examining the candidate source.

## Execution and findings

**No independent causal controls, focused tests, selector-free collection, or FULL suite were run.** The 9,421 ordered test IDs, JUnit results, warnings, and post-test source identity are unverified. Writer-retained test records receive no independent execution credit.

1. **Blocking — provenance mismatch:** the fixed ZIP lacks the required embedded current report, so the mandated byte-for-byte equality cannot be established.
2. **Consequent validation gap:** all source-review and execution obligations above remain unperformed. This is not classified as a candidate defect.

The exact source tree `f6801df592af049a6aaef658f721fc1afe27ad6e` is **not authenticated or accepted** by this audit. No commit-gate eligibility or live/runtime authority follows from this result. A corrected review ZIP containing the current report, together with the standalone report, is needed for a new audit.

The [complete audit report](/private/tmp/rw0-c2-independent-auth-2xjzjifr/RW0_C2_P0_P1_INDEPENDENT_AUDIT_REPORT.md) and [safe evidence ZIP](/private/tmp/rw0-c2-independent-auth-2xjzjifr/RW0_C2_P0_P1_INDEPENDENT_AUDIT_EVIDENCE.zip) were reopened and hash-verified. Evidence ZIP SHA-256: `290143812f695af29751bd89fdbee6b80ee7403ac98025c86f9099b2da2c64ff`. The supplied ZIP’s size and SHA-256 were unchanged after the audit.
```
CANDIDATE_SOURCE_EDIT_NOT_PERFORMED
LIVE_REPOSITORY_ACCESS_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
MERGE_NOT_PERFORMED
PUBLICATION_NOT_PERFORMED
DEPLOYMENT_NOT_PERFORMED
PRODUCT_EFFECT_NOT_PERFORMED
```
