## Disposition

```text
RW0_C2_P0_P1_REPAIR_OPENING_REF_POLICY_CORRECTION_REQUIRED
CANDIDATE_UNCHANGED
```

Codex stopped correctly under the literal previous mandate. **No repair ran, no file changed, and no test result was produced.** The candidate remains the exact uncommitted tree:

```text
8e247b21320f90d2d2cb98d3d165f7fc35f117a8
```

The opening source tree, source manifest, raw and semantic indexes, configuration, migrations, schema, branch, HEAD, and every other captured field matched. Only the aggregate hash of the complete `git show-ref -d` output changed:

```text
Historical observation:
ab5bc35302df7eb9385527c9b16fdc77dc182e391cdd0cb43a8405567a677ce9

Current observation:
9d971ed4c049a2d6578565aab87936aacb762f8df7487ca29beac8da40d834b3
```

The previous handoff was overbroad because it treated the full ref inventory—including platform-owned turn-diff capture/checkpoint refs—as immutable candidate identity across separate turns. That conflicts with the earlier project treatment of those namespaces as diagnostic evidence rather than source authority. Provenance recipes should also avoid volatile metadata in canonical identity. Governed Execution Provenance G…

I am **not** assuming the changed refs are harmless. The supplied summary does not identify their names. The corrected continuation requires Codex to classify the exact current inventory before editing:

- Any change outside the two exact turn-diff diagnostic namespaces still blocks.
- Any diagnostic ref retarget still blocks.
- Any replace ref, source-selection dependency, invalid object type, branch/HEAD mismatch, or source mismatch still blocks.
- Qualified diagnostic additions/removals are retained as evidence without becoming candidate identity.
- The unexplained historical full-ref transition remains unresolved.

The source itself was previously authenticated exactly, and the independent audit’s two material F1/F2 findings remain the operative repair requirements. Pasted text

## Next Codex handoff

Send **only this complete replacement prompt** to the **same workspace-write implementation Codex conversation**:

:chatgpt-content-reference{index="2"}[**RW0-C2 P0→P1 command-digest-v2 / protected-disclosure repair with corrected ref policy**](sandbox:/mnt/data/Coordinator_RW0_C2_P0_P1_Command_Digest_V2_Protected_Disclosure_Repair_Ref_Policy_Continuation.txt)

Do not send the prior repair prompt alongside it. No attachments are required.

The replacement retains the complete substantive repair mandate:

1. Bind `expected_branch` into guarded-command-digest v2 without changing the six branch-neutral preassignments or SQL schema.
2. Require fresh positive disclosure posture before protected replay, readback, or `committed_exact` recovery.
3. Run the real-writer causal controls, connected five-branch path, focused selection, selector-free collection, and FULL execution.
4. Return one new cumulative uncommitted review package for independent audit.

Only the opening ref policy and external provenance recipe treatment change.

The new prompt requires a narrowly versioned external provenance recipe:

```text
v4:
historical complete-ref aggregate retained unchanged

v5:
authoritative-ref map in canonical identity
qualified turn-diff refs in complete sidecars
```

The current non-diagnostic ref map becomes the prospective opening baseline and must remain exact through validation and cleanup. The exact diagnostic namespaces are:

```text
refs/codex/turn-diffs/captures/**
refs/codex/turn-diffs/checkpoints/**
```

Everything else remains authoritative by default.

```text
Prompt bytes: 26,404
Prompt SHA-256:
c4da29c71da30572b75ce8c5f74893e2958dd2b09f9b9c6f7649a638e40d9bb6
```

:chatgpt-content-reference{index="3"}[Prompt identity record](sandbox:/mnt/data/Coordinator_RW0_C2_P0_P1_Command_Digest_V2_Protected_Disclosure_Repair_Ref_Policy_Continuation_Check.json)

The candidate remains blocked and unaccepted. The independent audit’s F1/F2 findings, unperformed broad controls, and absent independent FULL pass remain unchanged. No staging, commit, publication, network action, or product effect is authorized.

**Confidence:** **0.99** that the previous stop was caused by an overbroad full-ref gate; **0.96** in the corrected policy. Whether the actual ref delta qualifies remains for the required opening classification—not assumption.
