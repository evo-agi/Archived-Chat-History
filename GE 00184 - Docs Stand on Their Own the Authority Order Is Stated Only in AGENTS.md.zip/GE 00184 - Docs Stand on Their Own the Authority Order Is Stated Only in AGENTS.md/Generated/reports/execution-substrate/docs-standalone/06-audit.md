# ES docs stand on their own: independent re-audit 06 of PR #64

Status: delivered. Written 2026-11-25 by the fresh, read-only audit thread "Check the second docs cleanup fixes" (this thread has not audited PR #64 before). Model: Opus.

**Verdict: BLOCK.** Three low findings, all patch defects and all small; no provenance problem. Both audit 04 findings are closed as named: the five "match reality" bullets are gone (A04-1), every one of the 14 listed cases is refused (also inside a document, wrapped, linked and as a bullet), the surviving vocabulary is closed or removed, the file scope is pinned and the limits are written down (A04-2). Provenance reproduces exactly, the root package passes at the tip with the same 618 tests as at `a0dc3c9`, and the writer's 83 vocabulary mutants and 84 own mutants are all caught again on my rerun. What blocks, by the coordinator's own block criteria:

- A06-1 (a rank sentence remains in the tree): `.docs/system_overview/evolution.md:35` still says "use code and tests as the factual source of current behavior when prose is stale". That is the code-and-tests precedence again, the same rule as the removed "Code and tests outrank stale prose." Audits 02 and 04 and the writer's sweep all missed it.
- A06-2 (a stated limit is wrong): the guard's comment says it refuses the rank wordings "that audits 02 and 04 probed", but 17 of audit 04's 35 rank probes pass, including "trumps", which the same comment lists as a gap. And the new `AGENTS.md` bullet says the test covers "other Markdown files", but it skips the closed record, which holds a "they win" sentence.
- A06-3 (a false positive on legitimate prose): the repair removed the line that cut `#anchor` off link targets, calling it dead code. It was not dead, only untested. Heading slugs now count as text, so a plain link to three existing headings in the tree (for example `reliable_submit_operational_handoff.md#1-status-and-precedence`) is refused. At `a0dc3c9` none was. Restoring the one line fixes it and keeps every test green.

Missed synonyms are recorded as non-blocking observations (O06-2), as the coordinator asked.

```text
INDEPENDENT AUDIT REPORT
Repository:        evo-agi/Execution-Substrate, PR #64 (draft)
Audit target:      base ae9aa65322954be16d5d3e354dd0aeec5d87723d (trunk_dev, unchanged at open and close)
                   topic claude/project-thread-8x4q85, commit 61db96c6d0612711a0a6ad25020e75d60e99cb74
                   tree c6bab39e672515f9ac08f18a011b4f36becdc6a1 (three commits: aecb180, a0dc3c9, 61db96c)
                   recipe governed-execution.audit-patch-manifest.v2,
                     source SHA-256 c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca
                   canonical manifest SHA-256 af7e85af30b8e26bc2fc2d4e6be6a11cd2a4b449da26d75fc73ae0208bc3e073
                   textual diff SHA-256 e17229ffdeee1ac97ad1a9830b83c6bb48c2f812435437d2d74a764685f1bc35
                   32 changed paths (31 tracked_modified, 1 untracked: authority_order_docs_contract_test.go)
Delta reviewed:    a0dc3c9..61db96c, 7 files (5 docs, AGENTS.md, the guard)
Audit posture:     read-only; parent only, no subagents; nothing pushed, no PR edit, no comment
Final verdict:     BLOCK
```

## Provenance reproduction

- Recipe bytes: `sha256sum` of `/mnt/project-files/operating-protocol/tools/governed_execution_audit_patch_manifest_v2.py` and of the copy that ran both gave `c08597e2…a1ca`, the pinned value (`sha256sum -c` OK). Checked again before the closing run.
- Provenance §5.3 in `/home/user/Execution-Substrate`, `umask 022`: fetched `trunk_dev` and the topic; `origin/claude/project-thread-8x4q85` = `61db96c…` (the reported tip); `ae9aa65` is an ancestor; `git checkout -q -f -B <topic> <tip>`; `git status --porcelain` empty; `git reset -q --mixed ae9aa65`; upstream pinned to `origin/trunk_dev`; v2 run twice into a fresh mode-0700 directory outside the repo.
- The two outputs were byte-identical (`cmp`) and equal to `05-expected-manifest.json` byte for byte (SHA-256 `af7e85af…e073`, 32 files). No mode-bit differences. `git rev-parse 61db96c^{tree}` = `c6bab39e…6a1`.
- PR facts from GitHub: head `61db96c`, base `trunk_dev` `ae9aa65`, 32 changed files, 3 commits, draft, mergeable_state "blocked" (required checks still running at that time).
- Report 05 (`05-report.md`) SHA-256 `9d85c87d734bb55ec1452426d9c33dea528d6adf273d5796d1a1b9fa97dfe107`, as the brief says. `05-alt-mutants.py` `58c7b447…2b93` and `05-mutants.py` `a168cc6f…e824` match the report.
- Closing manifest: the audit repo had no other worktree and no audit artifact (probes, mutants and test runs used separate clones in this thread's scratch directory). Recipe hash re-checked; `trunk_dev` still `ae9aa65`, topic still `61db96c`; upstream re-pinned; two v2 runs: byte-identical, equal to the opening output (SHA-256 `af7e85af…e073`). Then `git reset --mixed 61db96c`; `git status --porcelain` empty.

## Coverage

- Read in full: the delta `a0dc3c9..61db96c` (all 7 files, every hunk); `authority_order_docs_contract_test.go` at the tip; `AGENTS.md` §3 at the tip; audit 04 (`04-audit.md`, SHA-256 `cc930f44…cbf`, as recorded), report 05 and its evidence files (`05-alt-mutants.py`, `05-mutants.py`, `05-alt-mutant-map.tsv`, `05-probe-out.tsv`); the PR body.
- Spot-checked from the full PR `ae9aa65..61db96c`: `AGENTS.md`, `README.md`, both standing-rule headers, `remote_alpha_access_contract.md`, `remote_alpha_operator_healthcheck_tls_signing_custody.md`, `evolution.md` (whole file).
- Swept every git-listed Markdown file at the tip except `AGENTS.md` and the record (54 files) with the guard's own sentence splitter and a relation-word list much wider than the guard's and than audit 04's (adds "stale", "source of truth", "trust", "governs", "applies", "first", "before", "latter", "decides" and more), keeping sentences that name two parties (Method notes). Plus a direct grep for code-versus-prose wordings ("stale", "factual source", "match reality", "realign", "source of truth", "prefer code", "docs win").
- Checked which packages can see the delta: `./scripts` reads none of the five changed docs, `AGENTS.md` only as a cited name in comments, and does not compile the root package; `./internal/testutil` checks only that `AGENTS.md` exists. So the delta can change results only in the root package, and the `./scripts` result audit 04 recorded at `a0dc3c9` (identical to base, by name) still applies.
- Not inspected: the 97 ordinary `PLANS.md` mentions (out of scope by the approved reading); Go code outside the guard (the delta changes none); scripts and CI config (unchanged by the PR).

## A04 findings: closure

| Finding | What audit 04 asked | At `61db96c` | Closed? |
| --- | --- | --- | --- |
| A04-1 | Delete the five "If code and tests disagree with this file, update this file to match reality" bullets, or reword them without a precedence; make the guard refuse the form (R1) | All five deleted (`execution_lifecycle/contracts.md` §18, `design.md` §13, `implementation.md` §19, `system_overview/architecture.md` §12, `boundaries.md` §15; one-line hunks, nothing else in those lists changed). The guard refuses R1 and the `boundaries.md` form, as a bullet under its heading too (probes LC-R1-bullet, LC-R1-boundaries). Writer mutants R7-R11 restore each bullet in its own doc: each caught by `TestAuthorityOrderIsStatedOnlyInAgents` on my rerun | **Yes, as named.** A sixth sentence of the same kind remains elsewhere (A06-1, new) |
| A04-2(a) | Refuse N01, N02, N03, N04, N06, N07, N09, N10, N11, N21, N24, N30, N35 and R1, each as a self-test probe | All 14 are in the self-test ("Audit 04 cases"). My probes refuse all 14 and seven in-context variants (inside a paragraph, wrapped over two lines, with `[`AGENTS.md`](…)` links, "§3"). Writer mutants N01…R1 insert each into `shared_kernel.md`: 14 of 14 caught on my rerun | Yes |
| A04-2(b) | Every surviving alternative and switch gets an example that fails without it, or is removed as dead; pin the file scope | `05-alt-mutant-map.tsv` accounts for all 88 (28 still caught, 50 closed by examples, 2 changed form, 7 removed, 1 out of scope: "control the"). Rerun of the writer's adapted tool: 83 of 83 caught. File scope: a count check plus a README/PLANS check; my mutant M2 (skip one `.docs/` file) fails the guard test. I checked the three "dead" removals: the `\|` unit start (the `HasPrefix(trimmed, "|")` case runs first), the nbsp replacement (`strings.Fields` already splits on U+00A0) and the image `!?` (a left-over "!" before a label never makes a sentence break) are dead. **The fourth removal, the `#anchor` cut, was not dead (A06-3)** | Yes, except A06-3 |
| A04-2(c) | Keep the eight ordinary sentences and F13-F16 passing, and the tree | 17 ordinary sentences in the self-test (the eight, F13-F16, a one-sided conflict, and four that pin the new heading, numbered-item, "?" and "!" splits); tree passes; allowlist unchanged (one entry) | Yes |
| A04-2(d) | Name the residual limit in the guard's comment | Done (`authority_order_docs_contract_test.go:17-32`) and in `AGENTS.md:34`. Each listed gap is real (probes G-*: all pass, except that an "e.g." cut is caught when the file and the rank word land on the same side of the cut, which the comment does not deny). **But the comment's scope sentence and the `AGENTS.md` bullet each overstate what the test covers (A06-2)** | Partly: A06-2 |

## The delta, change by change

| Change | Assessment |
| --- | --- |
| Five "match reality" bullets deleted | Correct. `AGENTS.md:38` ("If docs and code disagree on factual behavior, code and tests win for current behavior, and the docs must be realigned.") still carries both the precedence and the realignment duty. For `design.md` and `architecture.md` the bullet was broader than `AGENTS.md:37` and `:39` allow, so dropping it removes a conflict, not a claim |
| `AGENTS.md:34` limit bullet, pinned by the guard test | Right in substance ("regression backstop … not a complete check: review is what keeps other documents to the rule above"); its scope "in other Markdown files" is wrong by one file (A06-2) |
| Guard comment: "what it is / is not / known gaps" | Gaps verified real; scope sentence overclaims (A06-2) |
| New rules: higher or lower authority, authoritative over, in authority, priority, subordinate, in favor of, conflict settled toward one side; "comes first"; `section 3 of agents.md` and `agents\.md\W{1,3}section 3` | Each refuses its listed case and has a sole example. They add false-positive exposure on ordinary prose (O06-1), small in this tree: at most one tree sentence per new rule matches the rule without naming a file of the order |
| `controls` now `control (?:this|that)` with no object word; "control the" dropped | Accepted trade (report 05 says the rule now refuses more). Recorded under O06-1 |
| Heading line is a unit of its own; `#` and `\|` dropped from the unit start | Correct; fixes the old false positive where a heading joined the paragraph under it (pinned) |
| `authorityMembers` / `authoritySelf` constants, `authorityDistinct` helper | Pure refactor of the old member matcher plus the new conflict-side matcher; behavior of the old "two members" rule unchanged (its alt mutants still caught) |
| File scope: count check, README.md and PLANS.md named | Works (M2 caught; writer F1/F2 caught) |
| nbsp replacement and image `!?` removed | Dead, as claimed |
| `#anchor` cut removed from link targets | Not dead: regression (A06-3) |
| Self-test reorganized into groups; 45 one-word examples added | Matches the claim "each word of the vocabulary is needed by some refused example" (83 of 83 alternative deletions caught) |

## No authority claim lost (delta, and full-PR spot-check)

- Delta: the only removed text is the five bullets; `AGENTS.md:38` states the same thing once. Nothing else in the five docs changed.
- Full-PR spot-check (agreeing with audits 02 and 04): the standing-rule headers' rank → `AGENTS.md:41`; README "the docs win" and "not in the README" → `AGENTS.md:36`; README and `PLANS.md` record clause → `AGENTS.md:40`; the TLS custody doc's inline order and route-record rank → `AGENTS.md:23-29` and `:35` (its "they do not create ES signing authority" kept); `remote_alpha_access_contract.md`'s drifted copy → `AGENTS.md:23-29`. No claim lost.
- `AGENTS.md` line numbers moved by one since audit 04 (the new bullet at :34); section numbering is unchanged, so the claim ledger's section citations still hold.

## Findings

```text
AUDIT FINDING
ID / Type / Severity: A06-1 / contract/authority drift / low
Current contract or strategic target: AGENTS.md:33 (new in this PR): "This section is the one place
  that states ... which source wins when two disagree." The coordinator's ruling (2026-11-25 21:21Z,
  quoted in report 03): "A doc says nothing about who outranks whom, so the 'code and tests win over
  this doc' sentences go too." The PR body: "AGENTS.md says it once."
Path and line / Evidence (tip 61db96c):
  .docs/system_overview/evolution.md:35, third bullet under "How to tell the difference":
    "- use code and tests as the factual source of current behavior when prose is stale"
  "When prose is stale" means when prose and code disagree; the bullet then names code and tests as
  the source to follow. That is AGENTS.md:38's precedence restated, in the same scope (factual
  current behavior). It is the same rule as "Code and tests outrank stale prose.", which this PR
  removed from system_overview/contracts.md §13 under the ruling above, and the same kind as A04-1's
  five bullets. The sentence is unchanged since base (git show ae9aa65:.docs/system_overview/
  evolution.md:35). No test pins it (mutant E2: deleting it passes the root package). The guard
  passes it (mutant E1: inserted into shared_kernel.md, the root package passes). Audit 02's and
  audit 04's sweeps keyed on rank and conflict words, and the writer's sweep on "disagree/differ/
  conflict", "realign", "match reality" and "source of truth"; none listed "stale".
  The two bullets above it ("use PLANS.md to determine whether a surface is explicitly reopened",
  "use the core docs to determine whether a rule is ...") say which document owns a question, which
  AGENTS.md:33 allows. Only the third adds a conflict clause.
Impact: the "stated once" goal is not met for the code-and-tests precedence, the same gap A04-1 was.
  Small in practice: its direction matches AGENTS.md:38.
Required correction: delete the bullet, or keep only the ownership part without the conflict clause
  (for example "- code and tests show current behavior"). Because the guard's comment says it
  refuses "the rank wordings this repository has used", add the removed wording to the self-test's
  "Forms this PR removed" (with whatever rule it needs), as was done for R1; if the coordinator
  prefers not to widen the vocabulary for it, say so in the comment instead.
Uncertainty: whether "use X as the factual source ... when prose is stale" states which source wins
  or only which source owns a question is a judgment. I read it as the precedence, by the ruling
  that removed "Code and tests outrank stale prose." If the coordinator rules it is ownership,
  A06-1 drops.
Patch defect or pre-existing issue: patch defect (the rule at AGENTS.md:33 and the "stated once"
  claim are new in this PR; the sentence pre-dates it), the same classification as A02-1 and A04-1.
```

```text
AUDIT FINDING
ID / Type / Severity: A06-2 / test/doc gap (a stated limit is wrong) / low
Current contract or strategic target: the coordinator's repair request (22:04Z, quoted in report 05):
  "state its limits honestly in its docstring and in the contract: it is a regression backstop for
  known wordings, and review remains the real check."
Path and line / Evidence (tip 61db96c):
  1. authority_order_docs_contract_test.go:17-20: "It refuses a sentence that names a file or source
     of the order beside one of the rank wordings this repository has used or that audits 02 and 04
     probed". Audit 04 probed 35 rank wordings (N01-N35). 17 of them pass the guard at this tip
     (05-probe-out.tsv: N08, N12-N19, N22, N23, N25-N28, N32, N33; my rerun of ten of them, probes
     O-*, agrees). The same comment's gap list then names "trumps" (N13), "beats" (N14), "yields to"
     (N12), "outweighs" (N23) and "has the final say" (N25) as not refused. The comment contradicts
     itself; report 05 itself calls those 17 "out-of-scope audit 04 probes".
  2. AGENTS.md:34 (new in the delta, pinned by the guard test): "A repository test refuses the known
     wordings of a rank in other Markdown files." The test reads every git-listed Markdown file
     except AGENTS.md and .docs/history/plans-record.md (its own comment says so). The record is a
     Markdown file and holds a rank sentence the guard would refuse: plans-record.md:11 "... from
     `PLANS.md` or from an owning `.docs/` contract, they win." So the contract's statement of the
     test's reach is wrong by that file. (Excluding the SHA-pinned record is right; audits 02 and 04
     accepted it. Only the statement is wrong.)
Impact: the two places that are meant to tell a reader exactly what the backstop covers overstate it.
  A reader of the comment cannot tell which audit wordings are covered; a reader of AGENTS.md would
  expect the record to be checked.
Required correction: (1) say "listed" (the 14 P-probes and the 14 A04-2(a) cases) instead of
  "probed", or name them; (2) in AGENTS.md:34 and its pinned copy in the test, name the exception,
  for example "in other Markdown files except the closed record". Optional: "the known wordings"
  reads as "every known wording"; "a list of known wordings" would match the comment.
Uncertainty: none on the facts; severity is low because the very next sentences in both places say
  the check is not complete.
Patch defect or pre-existing issue: patch defect (both sentences are new in 61db96c).
```

```text
AUDIT FINDING
ID / Type / Severity: A06-3 / test gap (false positive on legitimate prose, introduced by the repair) / low
Current contract or strategic target: the coordinator's block criterion "the guard has false
  positives on legitimate prose"; AGENTS.md:33 asks docs to say which document owns a topic, which
  in this repo is often a link to a heading (15 anchored .md links in the tree today).
Path and line / Evidence:
  authority_order_docs_contract_test.go:45 now reads `label, target := parts[1], parts[2]`; at
  a0dc3c9 it was `strings.SplitN(parts[2], "#", 2)[0]`, which dropped the #anchor before the target
  was appended to the checked text. Report 05: "Also removed: the "#" anchor cut from link targets,
  which the adapted tool showed to be dead." The tool showed only that no test pinned it.
  Anchor probe (06-evidence/zz_audit06_anchor_test.go.txt): the neutral sentence
  "See [the section](<file>#<slug>) for details." for each of the 1002 headings in the git-listed
  Markdown files. a0dc3c9: 0 refused. 61db96c: 3 refused, by the "precedence" rule, because the slug
  now counts as words:
    .docs/execution_lifecycle/reliable_submit_operational_handoff.md:3 "## 1. Status and precedence"
    .docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1380
      "### 15B.1 Pooled loadClaim prerequisite and exit precedence"
    .docs/system_overview/supported_linux_host_qualification.md:304
      "### Step 3: verify absence of override-based support"
  Made-up headings show the same: "#5-admission-controls", "#why-the-lease-wins" (probes F-anchor-*).
  The anchor carries no rank meaning: the comment already lists a link to the order's heading with
  no rank word as a gap.
  Fix check (06-evidence/extra-mutants.txt, FIX-A): restoring the cut keeps the whole root package
  passing and brings the anchor probe back to 0 of 1002.
Impact: a writer who links to one of those headings with a short label gets a refusal for a plain
  link; any future heading with "wins", "controls", "precedence", "overrides" and so on in its title
  joins the list. Loud, not silent, but it is a new false positive caused by this repair.
Required correction: restore the anchor cut, and pin it with an ordinary self-test example such as
  "See [the section](.docs/execution_lifecycle/reliable_submit_operational_handoff.md#1-status-and-precedence) for details."
Uncertainty: none on the facts. Whether a hypothetical link counts as "legitimate prose" under the
  coordinator's criterion is a judgment; I count it because the targets exist in the tree and the
  change has no coverage benefit.
Patch defect or pre-existing issue: patch defect (the removal is in 61db96c).
```

## Observations (not blocking)

- **O06-1, false-positive exposure of the new vocabulary.** These ordinary sentences are refused at the tip (probes F-*, 06-evidence/probe-out.tsv): "The v1 envelope was dropped in favor of v2; see `.docs/execution_lifecycle/contracts.md`.", "The lock check comes first; `.docs/execution_lifecycle/implementation.md` lists the steps.", "ES uses a Vault token with lower authority than the root token; see `.docs/system_overview/configuration.md`.", "ARS is authoritative over blob digests, as this document says.", "The worker process is subordinate to the ES supervisor (`.docs/system_overview/boundaries.md`).", "If the recorded SHA differs, update this file and `.docs/system_overview/configuration.md`.", and a heading "## How the newest lease wins (see `PLANS.md`)". In this tree the exposure is small: of the new rules, "subordinate" and "place in the order" each match one tree sentence that names no file of the order, and the others match none (06-evidence/nearmiss-tip-61db96c.tsv). The older rules have more ("precedence" 140, "controls" 30, "held authority" 11), as audit 04's O04-1 said. Report 05 states this risk as an inference; the tree has no such sentence and failures are loud. Suggestion as before: require an order file as the subject or object of the rank word.
- **O06-2, missed synonyms and variants (the coordinator said not to block on these).** Pass at the tip: "See section 3 in `AGENTS.md`", "See section 3 of [the agent rules](../../AGENTS.md)", "If the code disagrees with this file, update this file.", "... disagree with this file, realign this file.", "... change this file to match.", "If the docs and code and tests disagree, update the docs.", "If this document and `PLANS.md` conflict, use / apply `PLANS.md`.", "... the reader follows `PLANS.md`." ("follows" is not "follow"), "`PLANS.md` comes before this document.", "`PLANS.md` goes first, then this document.", "This document has less authority than `PLANS.md`.", "`PLANS.md` is authoritative for anything this document says about scope.", "Where code and tests differ from this file, this file is updated.", and audit 04's N12-N19, N22, N23, N25-N28, N32, N33.
- **O06-3, fenced code is read as prose** (pre-existing): "```sh\n# PLANS.md wins over local notes\n```" is refused. The tree has no such block today.
- **O06-4, sentences considered and not raised.** `evolution.md:120` "Code may confirm current behavior. It must not become the design source of truth for cross-service contracts or architectural boundaries." (says what code does not govern, no conflict clause; report 05 also reads it as change governance); `evolution.md:175` "realign the docs, tests, and code before continuing" (drift procedure); `remote_alpha_external_tls_one_time_incident_contract.md:20` "If explanatory prose is ambiguous, this record governs." (the doc's own JSON record over its own prose, not a source of the order); `remote_supported_host_alpha.md:1141` "the existing staged-helper tests remain the source of truth for helper staging, …" (topic ownership in a route target list); `execution_lifecycle/contracts.md:12` "design.md is the higher-level lifecycle design map" (level of detail, not authority). The coordinator may want `evolution.md:120` handled together with A06-1.
- **O06-5, rank wording outside Markdown.** `scripts/helpers_test.go:41` (Go comment, unchanged by the PR): "They keep PLANS.md's rank in the AGENTS.md authority hierarchy." `AGENTS.md:33` speaks of "other documents" and the guard of Markdown, so this is out of scope; it agrees with `AGENTS.md:41`.

## Validation assessment

Re-run by me on clean clones of the committed bytes (scratch clones, not the audit repo), as root, `umask 022`, go1.26.5 linux/amd64 (the module needs ≥ 1.26.5; downloaded through the proxy), `GOFLAGS=-mod=readonly`, `go test -count=1 -json`:

| Package | `a0dc3c9` | Head `61db96c` |
| --- | --- | --- |
| `.` (root) | 618 pass, 0 fail (176 top-level) | 618 pass, 0 fail (176 top-level), the same 618 names, no verdict change |
| `./internal/testutil` | not rerun (the delta cannot reach it) | 6 pass |
| `./scripts` | not rerun: the delta cannot change it (Coverage); audit 04 ran it at `a0dc3c9`, identical to base by name | CI only |

- `go vet .` clean; `gofmt -l` lists none of the three changed Go files; `git diff --check` clean for `ae9aa65..61db96c` and `a0dc3c9..61db96c`.
- Writer's adapted vocabulary mutants (`05-alt-mutants.py`, unchanged, on a clean clone of the tip, whole root package per mutant): **83 of 83 caught, 0 survived**; unmutated tree ok. My output equals `05-alt-mutants.out` line for line, including the failing test names, apart from the timing on the "unmutated" line (06-evidence/alt-mutants-rerun.out.txt).
- Writer's own mutants (`05-mutants.py`, unchanged, a fresh worktree of the tip, `git add -A` per mutant, whole root package): **84 of 84 caught**, each by the expected test; unmutated tree ok. Identical to `05-mutants.out` apart from the timing line (06-evidence/writer-mutants-rerun.out.txt).
- Audit 06's own mutants and fix checks (06-evidence/extra-mutants.txt): M2 skip one `.docs/` file → caught; M3 delete the count check → survives (only matters when a file is dropped, which M2 shows is caught); FIX-A restore the anchor cut → root passes, anchor probe 0 refused; E1 insert `evolution.md:35`'s bullet elsewhere → not refused; E2 delete it → no test fails.
- CI on the head: as of 22:55Z, "test on macOS" (run 45712906204, job 139551563586) **success**, 22:24:09-22:50:12Z. "build, vet and test" (run 45712906328, job 139551564105) still running: every step through "Check the test gate" succeeded (to 22:28:12Z); "Test" in progress since 22:28:12Z; "Listed tests still fail" and "Listed tests pass as root" pending. On `a0dc3c9` that job took 46 minutes. I will add its conclusion below as an addendum; it cannot change this verdict, and the repair will need fresh CI on its own tip.
- Not re-run: macOS (CI only); `./scripts` (reasoned above, plus CI).

## Method notes

- Probes (06-evidence/zz_audit06_probe_test.go.txt, output probe-out.tsv) call the guard's own `authorityStatements` on: the 14 listed cases and 7 in-context variants (L, LC: must be refused); every gap the comment names (G: must pass); ten of audit 04's unlisted probes (O); 17 variants of listed cases (V); 22 ordinary sentences using the new vocabulary, links to anchors, a heading and a code fence (F: should pass).
- Wide sweep (zz_audit06_sweep_test.go.txt, output sweep-wide-tip-61db96c.tsv): the guard's `authoritySentences` over the 54 files; a sentence is listed when it names two distinct parties from a list wider than the guard's gate ("the code", "tests", "prose", "the plan", "the record", "docs", any `.md` path, "this guide/note") and any of ~50 relation stems. 164 sentences, all read; A06-1 is the only rank sentence; the rest are ownership, procedure or topic statements (O06-4 lists the closest). A separate grep for code-versus-prose wordings found nothing more.
- Anchor probe and near-miss count: zz_audit06_anchor_test.go.txt (run on the tip, on `a0dc3c9` and on the tip with FIX-A) and zz_audit06_nearmiss_test.go.txt.
- All probe files were copied into a scratch clone, run, and deleted; `git status --porcelain` was empty afterwards each time. The audit repo was not touched beyond the provenance steps.

## Sensitive-material handling

No secrets read or written. The repo is public. The audit touched only the ES clone, scratch clones in this thread's scratch directory, and this report folder.

## Remaining uncertainty and stop conditions

- A06-1 rests on reading "use code and tests as the factual source of current behavior when prose is stale" as a statement of which source wins; the coordinator may rule it is ownership.
- A06-3 rests on counting a plain link to an existing heading as legitimate prose under the coordinator's criterion.
- go1.26.5 here versus the CI toolchain (`go-version-file: go.mod`, so also 1.26.5).

## Confidence

- Provenance: high (exact reproduction, double run, closing check, PR head equal).
- Validation: high for the root package and the guard (rerun on exact bytes; both mutant sets rerun); `./scripts` by reasoning and CI.
- Implementation: high that A04-1's five sentences are gone, that all 14 listed cases are refused, and that the vocabulary mutants are closed; high that A06-1's sentence remains, that the two scope statements in A06-2 are inaccurate, and that A06-3's three headings are refused at the tip and were not at `a0dc3c9`.

## Effect status

No repair, commit, push, PR edit, comment or merge by this thread. Evidence files are beside this report (`06-evidence/`).

## Report delivery

`/mnt/project-files/reports/execution-substrate/docs-standalone/06-audit.md`, SHA-256 in the reply that delivers it.

Final verdict: BLOCK

## Addendum: CI (2026-11-25 23:13Z)

Final state on the audited head `61db96c`, read from the GitHub Actions job records:

- "test on macOS" (run 45712906204, job 139551563586): **success**, 22:24:09-22:50:12Z.
- "build, vet and test" (run 45712906328, job 139551564105): **cancelled**, 22:24:09-23:00:34Z. Every step through Test succeeded: Check the test gate (to 22:28:12Z) and Test (22:28:12-22:56:16Z). "Listed tests still fail" was cancelled at 23:00:32Z and "Listed tests pass as root" was skipped. Nothing failed. Inference: the push of a new head at about 23:01Z cancelled the job (PR `updated_at` 23:01:37Z). So `61db96c` will never get a complete Linux result.

This does not change the verdict. By 23:13Z the PR head was `dd30aca7ff329452f3daf08cd187a9185723f13a` (5 commits: `6465e80` "Drop evolution.md's code-and-tests rank; state the guard's reach exactly (audit 06)", then `dd30aca`, a merge of `trunk_dev` #65), on base `trunk_dev` `389ecf66bd8828fafc9591111f14628cb86ce7fb`. This audit binds `61db96c` only. The new head needs its own fresh audit and CI (protocol §14). For that audit, going by the commit message only (I have not read the bytes): `6465e80` also removes `evolution.md:120` ("Code may confirm current behavior. It must not become the design source of truth …"). O06-4 above did not raise that sentence. Its removal should be checked to confirm no claim was lost; `AGENTS.md:37` and `evolution.md:7` are where the same content would still be stated.
