# ES docs stand on their own: writer report 05 (re-audit 04 repair)

Status: the repair is pushed to PR #64 (draft) and waiting for a fresh re-audit. Written 2026-11-25 by the writer thread "Make ES docs stand on their own". Reports 01 and 03 cover the earlier commits; this one covers the third commit and the new head.

## Brief

- **Re-audit 04** (`04-audit.md`, BLOCK) found two lows:
  - A04-1: five "update this file to match reality" sentences remain.
  - A04-2: the guard passes common rank wordings, and 60 of the 88 alternatives and switches in its vocabulary can be deleted without a test noticing.
- **Repair request (coordinator, 2026-11-25 22:04Z).**
  - A04-1: remove the five sentences; `AGENTS.md` §3 already covers them.
  - A04-2: "cover the exact cases the finding lists, including 'takes priority over' and 'section 3 of AGENTS.md'. Don't chase every synonym, though. A vocabulary guard can't be complete, so state its limits honestly in its docstring and in the contract: it is a regression backstop for known wordings, and review remains the real check. Close the surviving mutants that correspond to the listed cases, and record which of the auditor's 88 stay out of scope and why."
  - Then hand back the new head.

## Identity

| Item | Value |
| --- | --- |
| Repo | evo-agi/Execution-Substrate |
| PR | https://github.com/evo-agi/Execution-Substrate/pull/64 (draft) |
| Branch | `claude/project-thread-8x4q85` |
| Base | `trunk_dev` `ae9aa65322954be16d5d3e354dd0aeec5d87723d` (#62) |
| Tip | `61db96c6d0612711a0a6ad25020e75d60e99cb74` (three commits: `aecb180`, `a0dc3c9`, then this repair) |
| Tip tree | `c6bab39e672515f9ac08f18a011b4f36becdc6a1` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (checked before the run, on the project file and on the copy that ran) |
| Textual diff SHA-256 | `e17229ffdeee1ac97ad1a9830b83c6bb48c2f812435437d2d74a764685f1bc35` |
| Canonical manifest SHA-256 | `af7e85af30b8e26bc2fc2d4e6be6a11cd2a4b449da26d75fc73ae0208bc3e073` |
| File count | 32 (31 modified, 1 new: `authority_order_docs_contract_test.go`, recorded as `untracked`) |
| Full manifest | `05-expected-manifest.json`, beside this report. Its file SHA-256 equals the canonical hash. |

**How the manifest was taken.** This is provenance §5.3, as in reports 01 and 03:
1. On the branch, `git reset --mixed ae9aa65`.
2. Pin the upstream to `origin/trunk_dev`.
3. Run v2 twice, to two absent paths in a fresh mode-0700 directory. The outputs were byte-identical.
4. `git reset --mixed` back to the tip. `git status --porcelain` was empty.

The path set of `git diff --name-only --no-renames ae9aa65 <tip>` equals the manifest's path set. Compared with report 03, the manifest adds `.docs/execution_lifecycle/design.md`, `.docs/execution_lifecycle/implementation.md` and `.docs/system_overview/architecture.md`.

## What the repair changed (`a0dc3c9..61db96c`, 7 files)

### A04-1: the five sentences are gone

Each was a "Decision rules for future edits" bullet:
- `.docs/execution_lifecycle/contracts.md` §18
- `.docs/execution_lifecycle/design.md` §13
- `.docs/execution_lifecycle/implementation.md` §19
- `.docs/system_overview/architecture.md` §12
- `.docs/system_overview/boundaries.md` §15

The other bullets in those lists stay. `AGENTS.md` §3 ("If docs and code disagree on factual behavior, code and tests win for current behavior, and the docs must be realigned.") states this precedence once. A wider grep found no other sentence of this kind (Residual sweep below).

### A04-2: the listed cases

`authority_order_docs_contract_test.go` now refuses each of the cases A04-2(a) lists, which are also self-test probes:

| Case | Text | Refused by |
| --- | --- | --- |
| N01 | "`PLANS.md` has higher authority than this document." | higher or lower authority (new) |
| N02 | "This document has lower authority than `PLANS.md`." | higher or lower authority |
| N03 | "Code and tests take priority over this document." | priority (new: `takes? priority`, `priority over`) |
| N04 | "Where they differ, `PLANS.md` takes priority." | priority |
| N06 | "See section 3 of `AGENTS.md` for the order." | section 3 pointer (new alternative `section 3 of agents.md`) |
| N07 | "The order is in `AGENTS.md` (section 3)." | section 3 pointer (now `agents\.md\W{1,3}section 3`, which allows ", ", " (", ": " and a space) |
| N09 | "This document is subordinate to `PLANS.md`." | subordinate (new) |
| N10 | "Conflicts between this document and `PLANS.md` are resolved in favor of `PLANS.md`." | in favor of (new) |
| N11 | "`PLANS.md` is authoritative over this document." | authoritative over (new) |
| N21 | "If this document and `PLANS.md` conflict, follow `PLANS.md`." | conflict settled toward one side (new) |
| N24 | "The system overview docs come before this document in authority." | in authority (new) |
| N30 | "Code and tests are authoritative over this document for implemented behavior." | authoritative over |
| N35 | "`PLANS.md` comes first, then the system overview docs, then this document." | place in the order (new alternative `comes? first`) |
| R1 | "If code and tests disagree with this file, update this file to match reality." | conflict settled toward one side |

- **The conflict rule is narrow on purpose.** It refuses a sentence with a conflict word (conflict, differ, disagree), a resolution verb (follow, update), and two distinct sides, where a side is a member of the order or a document speaking of itself. An ordinary probe pins the two-sides requirement: "If the digests differ, follow the recovery steps in `.docs/system_overview/configuration.md`." must pass.
- **Each new rule has an example that only it refuses.** That is the same scheme as round 03, and deleting a rule still fails because its example names no rule.
- **End to end:** each of the 14 cases inserted into `shared_kernel.md` fails the whole root package (Validation).
- **The tree passes.** The new vocabulary refuses no sentence in the tree. The single allowlist entry is unchanged.

### A04-2: the 88 vocabulary mutants

I reran audit 04's tool on the new tip. It is `05-alt-mutants.py`, the auditor's `alt_mutants.py` adapted, and its output is `05-alt-mutants.out`. The changes to the tool:
- It also scans the two new pattern constants, `authorityMembers` and `authoritySelf`, and the tail literal of `authorityOrderFile`.
- Its fixed mutants follow the new code. The nbsp and image-link mutants were dropped along with their dead code.
- Five fixed mutants were added: heading unit, conflict sides, member count, link target, and only `.docs/`.

**Result: 83 of 83 caught, 0 survived** (Validation).

`05-alt-mutant-map.tsv` maps each of audit 04's 88 mutants to what happened to it:

| Disposition | Count | Which |
| --- | --- | --- |
| Caught in audit 04, still caught | 28 | |
| Closed by a new self-test example | 50 | Every surviving file-gate and member alternative; ranks "ed"/"ing"; "authority order"; "authority follows"; held authority "no", "its", "their", "keep(s)", "kept", "'s"; "control this", "control that", "controlled by"; "prevails", "overrides", "supersedes"; first/third/fourth/fifth/last in the order; `**` and `__` emphasis; the "?" and "!" sentence breaks; the numbered-item unit start; reading README.md and files outside `.docs/` |
| Changed form, pinned | 2 | The "#" unit start: a heading line is now a unit of its own, pinned by an ordinary example. "<ordinal> in authority" is now any "in authority", a rule of its own |
| Removed as dead code | 3 | The `\|` unit start (table rows are handled by the case before it); the non-breaking-space replacement (`compactText` already folds U+00A0); the image-link `!?` (a leading "!" changes nothing the checks read). Also removed: the "#" anchor cut from link targets, which the adapted tool showed to be dead |
| Removed as redundant or simplified | 4 | "<ordinal> in rank" (the ranks rule matches any "rank"); the object words file/document/doc after "control this/that" (the file gate already requires a file, so the rule now refuses more) |
| **Out of scope** | **1** | **"control the <file>"** is no longer refused. "control the" is ordinary prose ("operators control the route"), and next to any `.docs/` path it would refuse ordinary sentences. "control this" and "control that" stay |

### A04-2: limits stated

- **The guard's comment.** It now says that the guard "is a regression backstop for known wordings" and "not a complete check", that "review is what keeps documents to AGENTS.md section 3", and it lists the known gaps:
  - words outside the vocabulary ("trumps", "beats", "yields to", "outweighs", "has the final say");
  - a rank split across two sentences;
  - reference-style links, and a link to the order's heading anchor with no rank word;
  - a cut at "i.e." or "e.g.";
  - curly apostrophes.
- **The contract.** `AGENTS.md` §3 has a new bullet, pinned by the guard test: "A repository test refuses the known wordings of a rank in other Markdown files. It is a regression backstop for those wordings, not a complete check: review is what keeps other documents to the rule above."

### Out-of-scope audit 04 probes

These are the probes A04-2(a) did not list. I reran the auditor's probe file on the new tip; the output is `05-probe-out.tsv`.
- **Now refused:** N05, N20, N29, N31 and N34.
- **Still passing, out of scope:**
  - Words outside the vocabulary: N12 "yields to", N13 "trumps", N14 "beats", N19 "sits below … in the hierarchy", N22 "governs only where … is silent", N23 "outweighs", N25 "has the final say", N26 "source of truth over", N28 "binding on", N27 "Authority: see `AGENTS.md`", N32 "the contract applies", N33 "the system overview docs govern".
  - The gaps the comment names: N08 (link to the heading anchor), N15 ("i.e." cut), N16 (two sentences), N17 (reference link) and N18 (curly apostrophe).
- **False positives (O04-1):** F01 to F12, F17 and F18 are still refused. F13 to F16 pass, and they are now ordinary probes in the self-test. As audit 04 said, the tree has no such sentence today, and the failure message says how to reword.

### Other changes

- **The file scope is pinned.** The test fails unless it checks every git-listed Markdown file except `AGENTS.md` and the record (count check), and it names README.md and PLANS.md.
- **O04-2, a correction to report 03.** Report 03 said the route-records rule "names that file family", meaning the four `…_tls_*` docs. That was wrong. The rule's glob `remote_alpha_operator_healthcheck_*.md` covers five files, including `remote_alpha_operator_healthcheck_noninteractive_status.md`. That matches audit 02's suggested class, and the rule stays as written.

## Residual sweep

- A grep of every git-listed Markdown file outside `AGENTS.md` and the record found no other sentence that settles a doc-versus-code or doc-versus-doc conflict. It covered "disagree/differ/conflict with this file/document", "realign", "match reality" and "source of truth".
- What remains is change-governance procedure, which is not a rank between documents. For example, `evolution.md` §6 says "Code may confirm current behavior. It must not become the design source of truth for cross-service contracts …", and its drift procedure says "realign the docs, tests, and code before continuing".

## Validation

All runs used committed bytes in clean detached worktrees: base `ae9aa65` and head `61db96c`. The setup was `umask 022`, run as root, with SIGHUP/SIGINT/SIGQUIT reset to default, `go test -count=1 -json -timeout 40m <pkg>`, and go1.26.5 linux/amd64. Results are compared by test name.

| Package | Base `ae9aa65` | Head `61db96c` |
| --- | --- | --- |
| `.` (root) | 617 pass, 0 fail | 618 pass, 0 fail. Only in base: `TestSystemOverviewAuthorityHeadersFollowRepoHierarchy`. Only in head: `TestAuthorityOrderIsStatedOnlyInAgents`, `TestAuthorityOrderGuardFindsEachFormOfRank` |
| `./internal/testutil` | 6 pass | 6 pass |
| `./scripts` | 2079 pass, 251 fail (38 top-level), 13 skip | identical: the same 38 top-level failures by name |

- **No verdict changes.** No test common to both trees changed its result in any package. All three packages ran at the tip itself this time. Audit 04's non-root run, with the tools installed, saw 9 environment failures in `./scripts` on both trees; my root run sees 38. In both setups, base and head match.
- **Static checks.** `go vet .` is clean, `gofmt -l` lists none of the changed Go files, and `git diff --check ae9aa65 61db96c` is clean.
- **Vocabulary mutants.** `05-alt-mutants.py` (SHA-256 `58c7b447899c1eab9583ab9d538fed8dfec722157b0ee87998b3c0c6530c2b93`) is audit 04's tool, adapted as described above. It ran on a clean worktree of `61db96c` with a whole root package run per mutant.
  - **83 of 83 caught, 0 survived.** The unmutated tree passes. Output: `05-alt-mutants.out`.
  - Two of audit 04's caught mutants have no exact counterpart in the new code, and both are covered:
    - Removing `authoritySelf` from the file gate: I ran it by hand at the tip, and it fails `TestAuthorityOrderGuardFindsEachFormOfRank`.
    - Removing "the order": that is now fixed text inside the ordinal alternative, and removing that alternative is caught.
- **Writer mutants.** `05-mutants.py` (SHA-256 `a168cc6f05ae6e71e0aa4ad41419b405efd8f259c898fc546fb33c8dea59b05d`) ran with a hard reset, clean and `git add -A` per mutant, and a whole root package run each time. **84 of 84 were caught.** The unmutated tree passes. Output: `05-mutants.out`. The mutants:
  - Report 03's set, adapted to the new wording.
  - R7 to R11: each of the five "match reality" bullets restored in its own doc.
  - A3: the new `AGENTS.md` limits bullet deleted.
  - F1, F2: the guard skips README.md, or reads only `.docs/`.
  - Each of audit 04's 14 listed cases, inserted into `shared_kernel.md`.
  - Each of the 19 rules deleted.
- **Probe rerun.** Audit 04's probe file at the tip: `05-probe-out.tsv` (summary above).
- **CI** on `61db96c`: "build, vet and test" and "test on macOS" were in progress when this report was written.

## Assumptions, guesses and non-claims

- The guard is a regression backstop, as its comment and `AGENTS.md` now say. It is not a proof that no rank statement remains.
- **Inference:** "in favor of", "in authority", "comes first", "subordinate to" and the conflict rule may refuse ordinary sentences in future docs. None does today. When one does, the failure is loud and names the sentence.

## Follow-ups (for the coordinator)

These are unchanged from report 03:
1. Ordinary `PLANS.md` mentions in docs.
2. The two standing-rule sections still in `PLANS.md`.
3. Other line citations in the claim ledger. This round removes one line from each of five docs.
4. A possible conflict with "Restructure ES runbooks to house style".

## Confidence

- Provenance: high.
- Implementation: high that the five sentences are gone, that the 14 listed cases are refused end to end, and that every surviving vocabulary mutant is closed, removed or recorded. The guard is complete only for its vocabulary, by design.
