# ES docs stand on their own: writer report 01

Status: draft PR open, waiting for a fresh audit. Written 2026-11-25 by the writer thread "Make ES docs stand on their own".

## Brief and reading

- **Source of the task.** Backlog item "ES docs cleanup" (project-context/backlog.md). David at 2026-11-24 23:04Z, after reviewing PR #56: "I don't understand why they need to reference PLANS.md or AGENTS.md." He approved the coordinator's plan at 23:07Z.
- **Approved plan (coordinator's words, relayed 2026-11-25 20:35Z).** "Each doc stands on its own. A contract says what it governs and nothing about the read order. The authority order lives in one place, in AGENTS.md, which is the file agents read first anyway. The copies and their test go. PLANS.md holds only intent and order: what we're doing next and why, not rules." Plus A08-2.
- **Reading used (confirmed by the coordinator).** The narrow one. Remove the copied order and the rank sentences, keep `PLANS.md` in the `AGENTS.md` order, and leave ordinary content mentions such as "reopened in `PLANS.md`" for a possible follow-up.

## Identity

| Item | Value |
| --- | --- |
| Repo | evo-agi/Execution-Substrate |
| PR | https://github.com/evo-agi/Execution-Substrate/pull/64 (draft) |
| Branch | `claude/project-thread-8x4q85` |
| Base | `trunk_dev` `ae9aa65322954be16d5d3e354dd0aeec5d87723d` (#62) |
| Tip | `aecb1808fa9b166d00f304905654c2b4fe09698f` (one commit) |
| Tip tree | `e5539df2fa85ffa4a6164a7a359cbffb8bf59fcd` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified before the run) |
| Textual diff SHA-256 | `2020fea3cc23714b4b3224650822f29d298680e8a2b6f0bab423911d90cb6f5d` |
| Canonical manifest SHA-256 | `f893f1f62a2adaa89eb92b2dd3f377b4a76ba977bf7d69a6bef1031938039bb7` |
| File count | 27 (26 modified, 1 new: `authority_order_docs_contract_test.go`, recorded as `untracked`) |
| Full manifest | `01-expected-manifest.json`, beside this report. Its file SHA-256 equals the canonical hash. |

**How the manifest was taken** (provenance §5.3 form). On the branch, `git reset --mixed ae9aa65` (HEAD at base, tip bytes in the tree), upstream pinned to `origin/trunk_dev`, then v2 run twice to two absent paths in a fresh mode-0700 directory. The outputs were byte-identical. Then `git reset --mixed aecb180`, and `git status --porcelain` was empty. The path set of `git diff --name-only --no-renames ae9aa65 aecb180` equals the manifest's path set.

## What changed

1. **`AGENTS.md` section 3.** The five-line order is unchanged. A new first bullet under "Additional rules": "This section is the one place that states the authority order and the rank of a file in it. Other documents say what they govern; they do not restate the order, their own rank, or another file's rank."
2. **16 copies removed.**
   - Numbered copies, each with the preface "Authority for this document follows the repo-wide authority hierarchy:", were in `.docs/remote_alpha_operator_healthcheck_noninteractive_status.md`, `execution_lifecycle/workstream_c7_checkpoint.md`, `execution_lifecycle/es_execution_admission_model.md`, and `system_overview/` `artifact_hygiene.md`, `artifact_publication_storage.md`, `shared_kernel.md`, `hybrid_integration_architecture_adr.md`, `boundaries.md`, `runtime_identity_handoff.md`, `runtime_config_ownership.md` and `contracts.md`.
   - `remote_alpha_access_contract.md` had a variant ("Authority follows the repository order:") whose lines 2 to 4 had already drifted from `AGENTS.md`.
   - Inline copies ("Authority follows the repository hierarchy in `AGENTS.md`: …") were in the four `remote_alpha_operator_healthcheck_tls_*` docs (operator_authorized_replacement, signing_custody, signing_custody_decision, signing_custody_resolution). In three of them, the sentence that followed in the same paragraph stays, rewrapped: "Related IM, CP, Maintenance Agent, and Bridge docs are references for non-ES owner boundaries only; they do not create ES signing authority."
   - Kept: each doc's own statement that code and tests win on implemented behavior, and all section headings (tests use them as markers).
3. **Rank sentences removed.**
   - Both standing rule file headers: "They keep the authority they had in `PLANS.md`: `AGENTS.md` section 3 ranks …".
   - Both owning contracts: "… at `PLANS.md`'s rank are in …; `AGENTS.md` section 3 ranks that file with `PLANS.md`." These now read "The standing … rules are in `<file>`."
   - Both `PLANS.md` pointer sections: "They keep this file's authority (`AGENTS.md` section 3)."
   - `README.md` supporting references: "and keep its authority".
4. **`PLANS.md` opening (A08-2).**
   - It now reads "This file holds the current plan, its intent and order: …".
   - It drops "`AGENTS.md` ranks it second in authority, and every change starts by reading it", which `AGENTS.md` sections 3 and 5 already say.
   - A new bullet in "How this file is kept": "Put a standing rule in the file that owns it, not here." It names and links both standing rule files and what each holds.
   - Size: 145,786 bytes, under the 150,000 cap.
   - Departure from A08-2's suggested wording: A08-2 suggested naming the files "and their rank". The approved plan keeps rank only in `AGENTS.md`, so the note names the files without a rank.
5. **Claim ledger.** It cited `AGENTS.md` by line. I mapped the lines against `AGENTS.md` at 6300b95, the commit that wrote them: `21-36` was section 3, `38-65` sections 4 and 5, `79-100` section 7, `132-159` sections 10 to 12, and `153-159` section 12. They had drifted by 4 lines before this PR, and this PR adds 1 more. They now cite sections.

## Tests

- **Removed.** `assertDocIncludesAuthorityHierarchy` and `TestSystemOverviewAuthorityHeadersFollowRepoHierarchy`. Also removed: the copy and preface checks inside `TestWorkstreamASharedKernelDecisionIsDocumented`, the Workstream B artifact publication test, the Workstream C admission model test, the C7 checkpoint test, and the E0 and F0 ownership tests. That includes the old "conflicting authority order that omits AGENTS.md" check. No other assertion in those tests changed. `authorityHierarchyLines` stays, because two tests read it.
- **New.** `authority_order_docs_contract_test.go`:
  - `TestAuthorityOrderIsStatedOnlyInAgents` reads every git-listed Markdown file except `AGENTS.md` and the SHA-pinned closed record `.docs/history/plans-record.md`. It refuses 14 fixed phrases (each form a copy or rank sentence took) and the five order lines as `AGENTS.md` states them now. It pins the new `AGENTS.md` rule. It also fails if `AGENTS.md` stops holding three of the numbered phrases, so the refused list keeps tracking the live wording.
  - `TestAuthorityOrderGuardFindsEachFormOfCopy` is the self-test: 12 copy forms refused, 6 ordinary lines not.
- **Changed.**
  - `TestStandingRulesKeepPlansAuthority` now pins the new header and owner-pointer wording and no longer pins the rank sentences.
  - `TestPlansOpensWithTheCurrentPlan` pins "its intent and order", the standing-rule bullet and both links (A08-2).
  - The line-citation guard (`plansCitedFile`) now also covers `AGENTS.md`, with 3 refused and 2 allowed self-test examples. Its messages and comments now name `AGENTS.md`.
  - One existing failure message, "AGENTS.md authority line 2 is %q", tripped the widened guard as a false positive. It is reworded to "the second entry of the AGENTS.md authority order is %q".

## Validation

All runs were on committed bytes: clean detached worktrees at `ae9aa65` (base) and `aecb180` (head). The runs used `umask 022`, ran as root, reset SIGHUP/SIGINT/SIGQUIT to default, and used `go test -count=1 -json -timeout 40m <pkg>` with go1.26.5 linux/amd64.

| Package | Base | Head |
| --- | --- | --- |
| `.` (root) | 617 pass, 0 fail | 618 pass, 0 fail (1 test removed, 2 added) |
| `./internal/testutil` | 6 pass | 6 pass |
| `./scripts` | 2079 pass, 251 fail (38 top-level), 13 skip | identical; the same 38 top-level failures by name |

- **No verdict changes.** No test common to both trees changed its result in any package.
- **The 38 `./scripts` failures** are environment failures. They are Remote Alpha tests that need `ip`, `ssh`, `scp`, a fixed Python path or a non-root owner, and the same count as the PR #56 writer's root run. The names are in `01-scripts-failures.json`. Report 07 says a non-root run with ssh/uuidgen/acl installed fails fewer, so compare names, not counts.
- **`go vet .`** is clean. `gofmt -l` lists none of the changed files.
- **Mutation check.** `01-mutants.py` (SHA-256 `e187fa264ab4c3d909c0531038bc483708b72c612fc5c3c7e15e00bdd3009615`) ran on a clean worktree of the tip, with `git reset --hard` and `git clean -fd` before each mutant and `git add -A` after it. 12 of 12 mutants were caught, each by the intended test only:
  - M1: numbered copy back in boundaries.md → `TestAuthorityOrderIsStatedOnlyInAgents`
  - M2: inline copy back in signing_custody → same
  - M3: rank sentence back in a `PLANS.md` pointer → same
  - M4: rank sentence back in a standing rule header → same
  - M5: README rank clause back → same
  - M6: the `AGENTS.md` rule deleted → same
  - M7: the `PLANS.md` opening stops naming the route rule file → `TestPlansOpensWithTheCurrentPlan`
  - M8: an `AGENTS.md` line citation back in the ledger → `TestPlansIsCitedBySectionNotLine`
  - M9: the owner pointer removed from the lifecycle contract → `TestStandingRulesKeepPlansAuthority`
  - M10: one order line copied into shared_kernel.md → `TestAuthorityOrderIsStatedOnlyInAgents`
  - M11: a copy in a new Markdown file → same
  - M12: the old "conflicting order" form → same

  The unmutated tree passes. A first pass reset each mutant from the index after `git add -A`, so mutants accumulated. I discarded it and reran with a hard reset. The numbers above come from the rerun.
- **CI.** "build, vet and test" and "test on macOS" were in progress on `aecb180` when this report was written.

## Assumptions, guesses and non-claims

- The audit needs a red-team only if the coordinator says so. This is docs and tests only, and changes no product behavior.
- **Inference:** "Read these in order" in `README.md` (1. AGENTS.md, 2. PLANS.md, …) is a navigation path, not a restated authority order, so it stays. It uses different wording, and the guard does not refuse it. If the coordinator reads it as a copy, the fix is one line plus a guard phrase.
- `PLANS.md` still says of its closed record that it "holds no current authority". That describes the record's nature, not a rank in the order, and `TestPlansOpensWithTheCurrentPlan` pins it. I left it.
- Not claimed: that every doc is now free of `PLANS.md` or `AGENTS.md` mentions. 28 docs still mention `PLANS.md` in 97 lines (ordinary content: seam status, phase, source lists). `AGENTS.md` appears as a source in `.docs/mvp.md` (2 lines) and the claim ledger (3 rows), and the ADR names the Coordinator repo's own `AGENTS.md`.

## Follow-ups (for the coordinator)

1. **Ordinary `PLANS.md` mentions** (97 lines in 28 docs). Making seam status live in the owning contracts would let these go. That is a separate design change, not a text sweep.
2. **Two standing-rule sections still in `PLANS.md`**: "Current paired-root custody and acceptance scope" and "Remote Alpha access contract v1 — Tranche A" (noted at PR #56's merge). Moving them follows the verbatim-move method of PR #56.
3. **Other ledger line citations.** The claim ledger still cites other docs by line. This PR shortens boundaries.md, contracts.md, runtime_identity_handoff.md and some others by 4 to 8 lines inside the cited ranges.
4. **Possible conflict.** The parallel thread "Restructure ES runbooks to house style" also edits ES docs. It may touch `README.md` or `docs_contract_test.go`. Whichever merges second needs a base update.

## Confidence

- Provenance: high. The double manifest run matched, and the tree is clean.
- Validation: high for the root and testutil packages. For `./scripts`: identical failure sets as root, environment-limited.
- Implementation: high that the copies and rank sentences are gone and guarded. Medium on scope fit, because the narrow reading was confirmed by the coordinator, not by David directly.
