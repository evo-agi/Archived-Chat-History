# ES docs stand on their own: writer report 03 (audit 02 repair)

Status: the repair is pushed to PR #64 (draft), waiting for a fresh re-audit. Written 2026-11-25 by the writer thread "Make ES docs stand on their own". Report 01 covers the first commit; this report covers the repair commit and the new head.

## Brief

- **Audit 02** (`02-audit.md`, BLOCK): A02-1 medium, A02-2/3/4 low, plus observations O02-1 to O02-4.
- **Repair request (coordinator, 2026-11-25 21:21Z).** "Please fix all four findings in this PR." In short:
  - A02-1: remove the remaining rank sentences (evolution.md:71, the `PLANS.md` record sentence and the test that pins it, the two in README). "A doc says nothing about who outranks whom, so the 'code and tests win over this doc' sentences go too. Make sure AGENTS.md §3 covers that precedence once."
  - A02-2: move the rank of the route-specific `.docs/` records into `AGENTS.md` section 3; don't drop it.
  - A02-3: catch rank statements by meaning (for example "controls", "wins", "outranks", "authority", "§3" references outside `AGENTS.md`), with a narrow allowlist; prune dead phrases; add the auditor's 14 probes as mutants.
  - A02-4: correct the stated reason for keeping the headings, or rename headings that no longer talk about authority.
- **Departure from the auditor's suggestion, on the coordinator's instruction.** A02-1(c) suggested letting docs keep "code and tests win over this document". The coordinator's request removes those sentences too, and `AGENTS.md` section 3 states that precedence once. This report follows the coordinator.

## Identity

| Item | Value |
| --- | --- |
| Repo | evo-agi/Execution-Substrate |
| PR | https://github.com/evo-agi/Execution-Substrate/pull/64 (draft) |
| Branch | `claude/project-thread-8x4q85` |
| Base | `trunk_dev` `ae9aa65322954be16d5d3e354dd0aeec5d87723d` (#62), still the tip of `origin/trunk_dev` when the manifest was taken |
| Tip | `a0dc3c96234fb4081fe7b5da74883d3b3e5e50f6` (two commits: `aecb180` audited in 02, then the repair `a0dc3c9`) |
| Tip tree | `b405c53bcba3faf62a6e2abeefb9bfa5ac2d5727` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified before the run, on the project file and on the copy that ran) |
| Textual diff SHA-256 | `dbcea04afeba667d6e212f6a7465fee789af44da6785553a122ff15ec2cb3703` |
| Canonical manifest SHA-256 | `a28faa027803fe67f35da846d11105befc52cce89fd12cb637f39296c9d09ae4` |
| File count | 29 (28 modified, 1 new: `authority_order_docs_contract_test.go`, recorded as `untracked`) |
| Full manifest | `03-expected-manifest.json`, beside this report. Its file SHA-256 equals the canonical hash. |

**How the manifest was taken** (provenance §5.3 form, as in report 01). On the branch, `git reset --mixed ae9aa65` (HEAD at base, tip bytes in the tree), upstream pinned to `origin/trunk_dev`, then v2 run twice to two absent paths in a fresh mode-0700 directory. The outputs were byte-identical. Then `git reset --mixed a0dc3c9`, and `git status --porcelain` was empty. The path set of `git diff --name-only --no-renames ae9aa65 a0dc3c9` equals the manifest's path set. Compared with report 01, the manifest adds `.docs/commercialization/first-buyer-and-failure-mode.md` and `.docs/system_overview/evolution.md`.

## What the repair changed (`aecb180..a0dc3c9`, 21 files)

1. **A02-1: the remaining rank sentences are gone.**
   - `AGENTS.md` section 3, first "Additional rules" bullet, now reads: "This section is the one place that states the authority order, the rank of a file in it, and which source wins when two disagree. Other documents say what they govern and which document owns a topic; they do not restate the order or say that one file or source ranks above, controls, or wins over another."
   - The code-and-tests precedence is stated once, by the bullet that was already there: "If docs and code disagree on factual behavior, code and tests win for current behavior, and the docs must be realigned." The guard test now pins it.
   - "Code and tests win over this document" is removed from `es_execution_admission_model.md`, `remote_alpha_operator_healthcheck_noninteractive_status.md`, `artifact_hygiene.md`, `artifact_publication_storage.md`, `boundaries.md` ("When prose and code disagree, code and tests win."), `system_overview/contracts.md` (the intro sentence and the section 13 bullet "Code and tests outrank stale prose.") and `shared_kernel.md`.
   - `runtime_config_ownership.md` and `runtime_identity_handoff.md` kept a gate inside that sentence. They now say "Workstream E/F continues only once this document matches current code and tests on implemented behavior", so the gate stays and the rank goes.
   - `evolution.md`: ":9 `PLANS.md` is authoritative for:" is now "`PLANS.md` sets:"; ":71" is now "`PLANS.md` holds the redesign-phase list of reopened high-risk surfaces." The "`PLANS.md` controls" sentence is gone.
   - `PLANS.md` opening: the record "is closed and is historical evidence only. Read it when a change touches a surface one of its entries names." (The "holds no current authority … they win" clause is gone; `AGENTS.md` section 3 states it.) `TestPlansOpensWithTheCurrentPlan` pins the new sentence.
   - `README.md`: "For architecture, contracts, boundaries, lifecycle semantics, and redesign intent, read the docs below." ("defer to the authoritative docs" and "the docs win" are gone; `AGENTS.md` already says README is not design authority.) "Design intent lives in `PLANS.md` and `.docs/`." The record line says "it is historical evidence, so read it only when a change touches a surface it names", pinned by `TestPlansRecordIsNamedWhereAgentsStart`.
   - `first-buyer-and-failure-mode.md`: "… in that ledger control this document" is now "This document uses that ledger's allowed and forbidden wording, required qualifiers, evidence classes, and source gaps." The auditor said it could stay; the guard's "controls" rule refused it, and the new wording says the same thing without a precedence.
2. **A02-2: the route records' rank moved into `AGENTS.md`.** New bullet in section 3: "The Remote Alpha route design records directly under `.docs/` (the `remote_alpha_operator_healthcheck_*.md` files) rank after `.docs/system_overview/*`." The guard test pins it, so dropping it fails. Scope note: the four docs that stated it are `remote_alpha_operator_healthcheck_tls_*` files, so the rule names that file family rather than every file directly under `.docs/`.
3. **A02-3: the guard reads sentences by meaning.** `authority_order_docs_contract_test.go`, rewritten:
   - Normalization: a link becomes its text, plus its target when the text does not name the target's file; backticks and emphasis are dropped; "§" becomes "section"; case is folded; whitespace collapses.
   - Splitting: a blank line, heading, list item or table row starts a unit, each table cell is its own unit, and a unit is cut after ". ", "! " or "? ". A semicolon does not cut, so a rank after a semicolon is read with the file named before it (the old README record line had that shape).
   - A sentence is refused when it names a file or source of the order (`AGENTS.md`, `PLANS.md`, `standing_rules`, `system_overview`, `execution_lifecycle`, README, the record, any `.docs/` path, "this file/document/doc/record/contract/page", "code and tests", "code/tests", "Go code", "the/those/these docs") and matches one of ten rank rules: ranks/outranks; authority order/hierarchy; authority follows / authority for this; held authority (same, no, no current, its, their, keeps, kept, 's authority); wins; controls; precedence (precedence, prevails, defers to, overrides, supersedes, prefer code); place in the order (first … fifth/last in authority/rank/the order); `AGENTS.md` section 3; and "authority" beside two members of the order.
   - Copies: each of the five order lines as `AGENTS.md` states them now, plus two shorter wordings docs carried ("`PLANS.md` for allowed redesign work", "for factual implemented behavior"), are refused anywhere in a document.
   - Pruned: the 14 fixed phrases of report 01 are gone. Each is now caught by a rule (the self-test's probe list includes the removed forms).
   - Allowlist: one exact entry, `capability_probing.md`'s "… grants no startup or workload authority." (what a disposition grants, not a rank). An entry that no longer matches fails. I did not make plain "authority" beside one file a rule: 17 sentences in the tree have that shape, every one about signer, workload, submit or incident authority, so it would need a 17-entry allowlist instead of a narrow one.
   - Self-test `TestAuthorityOrderGuardFindsEachFormOfRank`: every rule has an example that only it refuses; an example whose rule was deleted fails ("names no rule"); each order line copy is refused; P1 to P14 and eight removed forms are refused; eight ordinary sentences pass.
4. **A02-4: headings renamed.** "## 1. Purpose and authority" became "## 1. Purpose and scope" in six docs, `system_overview/contracts.md` "Purpose And Authority" became "Purpose And Scope", and "## 0. Purpose, Authority, And Status" became "## 0. Purpose And Status" in the C7 checkpoint, the noninteractive status doc and the four TLS docs (each has status content). `remote_alpha_access_contract.md` keeps "## 1. Authority, scope, and status": a test uses it as a section marker, and the section is about the ownership split. Report 01's "tests use them as section markers" was wrong for the renamed ones; this corrects it.
5. **O02-2: `PLANS.md` names the standing-rule sections still in it.** The opening bullet adds: "Two standing-rule sections are still here and are to move the same way: "Current paired-root custody and acceptance scope" and "Remote Alpha access contract v1 — Tranche A"." `TestPlansOpensWithTheCurrentPlan` pins it and fails when either heading leaves `PLANS.md`, which is the machine trigger for that backlog item. `PLANS.md` is 145,850 bytes, under the 150,000 cap.
6. **O02-3 (line-citation guard matches any repo's `AGENTS.md`)** is unchanged: no such citation exists, and the same was already true of `PLANS.md`.

## Residual rank sweep

I reran the auditor's `rank-sweep.py` on the repaired docs (unchanged since `85011e3`; only the guard test changed after it). It lists 36 sentences, down from 51. None states which file or source wins, controls, outranks or ranks another; they are ownership and topic statements such as "records the authoritative decision", "the authoritative closure inventory is recorded in …", or claim-ledger table rows naming `AGENTS.md` as a source. The guard passes on the tip with its single allowlist entry.

## Validation

All runs were on committed bytes in clean detached worktrees: base `ae9aa65`, and the head. They used `umask 022`, ran as root with SIGHUP/SIGINT/SIGQUIT reset to default, and used `go test -count=1 -json -timeout 40m <pkg>` with go1.26.5 linux/amd64. Results are compared by test name, not count.

| Package | Base `ae9aa65` | Head |
| --- | --- | --- |
| `.` (root), at `a0dc3c9` | 617 pass, 0 fail | 618 pass, 0 fail. Only in base: `TestSystemOverviewAuthorityHeadersFollowRepoHierarchy`. Only in head: `TestAuthorityOrderIsStatedOnlyInAgents`, `TestAuthorityOrderGuardFindsEachFormOfRank` |
| `./internal/testutil`, at `a0dc3c9` | 6 pass | 6 pass |
| `./scripts`, at `85011e3` | 2079 pass, 251 fail (38 top-level), 13 skip | identical, the same 38 top-level failures by name |

- **No verdict changes.** No test common to both trees changed its result in any package.
- **Why `./scripts` ran at `85011e3`.** That was the repair commit before two test-only amendments. `git diff --name-only 85011e3 a0dc3c9` is `authority_order_docs_contract_test.go` alone, a root-package file that `./scripts` does not build. The root and testutil runs were repeated at `a0dc3c9`.
- **The 38 `./scripts` failures** are the environment failures of report 01 (`01-scripts-failures.json`): Remote Alpha tests that need `ip`, `ssh`, `scp`, a fixed Python path or a non-root owner.
- **`go vet .`** is clean. `gofmt -l` lists none of the changed files.
- **Mutation check.** `03-mutants.py` (SHA-256 `edb07f774238c9a9a0eb9aa575f8e98b5879f3e6cd6710169361b1862b6cc5aa`; output `03-mutants.out`) ran on a clean worktree of `a0dc3c9`. Each mutant had `git reset --hard` and `git clean -fd` before it, a clean-status check, `git add -A` after it, and a **full root package run** (`go test . -count=1`, no `-run` filter, answering O02-4). **55 of 55 were caught.** The unmutated tree passes.
  - W1 to W12: report 01's twelve, adapted to the new wording. Each was caught by its intended test.
  - A1, A2: deleting the route-records rank or the code-and-tests rule from `AGENTS.md` → `TestAuthorityOrderIsStatedOnlyInAgents`.
  - R1 to R6: restoring "code and tests win" (boundaries), "Code and tests outrank stale prose" (contracts), evolution's "`PLANS.md` controls", README's "the docs win", the `PLANS.md` record clause, and the TLS docs' route-records rank → `TestAuthorityOrderIsStatedOnlyInAgents` (R5 also fails `TestPlansOpensWithTheCurrentPlan`).
  - L1 to L3: editing the allowlist entry, removing the allowlisted sentence, or adding an entry for a file without it → `TestAuthorityOrderIsStatedOnlyInAgents`.
  - H1, H2: renaming the paired-root heading or moving the Tranche A heading down a level → `TestPlansOpensWithTheCurrentPlan`. H1 also fails two older tests that name that heading.
  - G1 to G4: weakening the guard without deleting a rule ("wins" made to match nothing, `agents.md` dropped from the file gate, semicolon cut restored, link targets no longer appended) → `TestAuthorityOrderGuardFindsEachFormOfRank`.
  - P1 to P14: each audit 02 probe inserted into `shared_kernel.md` → `TestAuthorityOrderIsStatedOnlyInAgents`. P12 also fails `TestMarkdownRelativeLinksResolve`, because the probe's link target does not resolve from that folder.
  - D × 12: deleting each of the ten rank rules and two copy variants → `TestAuthorityOrderGuardFindsEachFormOfRank`. Deleting the "authority beside two members" rule also makes the allowlist entry stale.
- **CI** on `a0dc3c9`: "build, vet and test" and "test on macOS" were in progress when this report was written.

## Assumptions, guesses and non-claims

- **Inference:** the guard is a meaning check by patterns, not an understanding of prose. A rank stated with none of its words (for example "`PLANS.md` beats this file") would pass. The rules cover the wordings found in the tree, in report 01, and in audit 02's probes.
- The README "Read these in order" list stays as navigation (O02-1 accepted it).
- Not claimed: that docs no longer mention `PLANS.md` or `AGENTS.md`. Ordinary mentions (seam status, phase, sources) remain, as in report 01.

## Follow-ups (for the coordinator)

1. Ordinary `PLANS.md` mentions in docs (report 01 follow-up 1).
2. The two standing-rule sections still in `PLANS.md`, now named in its opening and pinned (report 01 follow-up 2).
3. Other ledger line citations (report 01 follow-up 3).
4. Possible conflict with the parallel thread "Restructure ES runbooks to house style" on `README.md` or docs tests. Whichever merges second needs a base update.

## Confidence

- Provenance: high. The double manifest run matched, the path sets agree, and the tree is clean.
- Implementation: high that the sentences A02-1 names and the "code and tests win" sentences are gone, that the route-record rank lives in `AGENTS.md` and is pinned, and that the 14 probes are refused. Medium that no rank wording outside the rules' vocabulary remains, for the reason in the first bullet above.
