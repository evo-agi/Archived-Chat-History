# ES docs stand on their own: independent audit 02 of PR #64

Status: delivered. Written 2026-11-25 by the fresh, read-only audit thread "Audit the ES docs cleanup". Model: Opus.

**Verdict: BLOCK.** One medium and three low findings, all patch defects; none is a provenance problem. Provenance reproduces exactly, root tests go from 617 to 618 with no verdict change, and the removals lose only one authority claim (A02-2). The blocking points: the tree still holds rank sentences that the new `AGENTS.md` rule forbids, two of them pinned by tests, one of which this PR edits (A02-1); the guard catches only the historical wordings and passes a live rank sentence (A02-3); and a dropped rank and kept headings rest on claims that do not hold (A02-2, A02-4). Standing policy is that low findings are fixed in the PR.

```text
INDEPENDENT AUDIT REPORT
Repository:        evo-agi/Execution-Substrate, PR #64 (draft)
Audit target:      base ae9aa65322954be16d5d3e354dd0aeec5d87723d (trunk_dev, unchanged at audit time)
                   topic claude/project-thread-8x4q85, commit aecb1808fa9b166d00f304905654c2b4fe09698f
                   tree e5539df2fa85ffa4a6164a7a359cbffb8bf59fcd
                   recipe governed-execution.audit-patch-manifest.v2,
                     source SHA-256 c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca
                   canonical manifest SHA-256 f893f1f62a2adaa89eb92b2dd3f377b4a76ba977bf7d69a6bef1031938039bb7
                   textual diff SHA-256 2020fea3cc23714b4b3224650822f29d298680e8a2b6f0bab423911d90cb6f5d
                   27 changed paths (26 tracked_modified, 1 untracked: authority_order_docs_contract_test.go)
Audit posture:     read-only; parent only, no subagents; nothing pushed, no PR edit, no comment
Final verdict:     BLOCK
```

## Provenance reproduction

- Recipe bytes: `sha256sum` of `/mnt/project-files/operating-protocol/tools/governed_execution_audit_patch_manifest_v2.py` and of the copy that ran (`/opt/audit/v2.py`) both gave `c08597e2…a1ca`, the pinned value.
- Followed provenance §5.3 in `/home/user/Execution-Substrate`, `umask 022`: fetched `trunk_dev` and the topic; `origin/claude/project-thread-8x4q85` = `aecb180…`; `ae9aa65` is an ancestor; `git checkout -f -B <topic> <tip>`; `git status --porcelain` empty; `git reset --mixed ae9aa65`; upstream pinned to `origin/trunk_dev`; v2 run twice into a fresh mode-0700 directory.
- The two outputs were byte-identical (`cmp`). Both equal `01-expected-manifest.json` byte for byte (SHA-256 `f893f1f6…9bb7`). No mode-bit differences.
- `git rev-parse aecb180^{tree}` = `e5539df2…cbffb8bf59fcd`. One commit on the base. `trunk_dev` was still `ae9aa65` when I fetched it.
- Closing manifest: after removing my two worktrees (`git worktree remove`, `prune`), the same steps and two v2 runs gave byte-identical output, equal to the opening output (SHA-256 `f893f1f6…9bb7`). Then `git reset --mixed aecb180`; `git status --porcelain` empty.

## Coverage

- Read in full: the diff of all 27 paths; `authority_order_docs_contract_test.go`; the changed parts of `docs_contract_test.go` and `plans_docs_contract_test.go` and the helpers they call (`authorityHierarchyLines`, `compactText`/`testutil.Compact`, `repositoryTextFiles`, `repositoryFiles`); `AGENTS.md` sections 1 to 7 at the tip; the README agent index; `PLANS.md` opening; the writer's report, manifest, mutant script and failure list.
- Swept every git-listed Markdown file at the tip for statements of authority, rank or precedence that name a file of the order (scripts in Method, below).
- Checked the claim-ledger remap against `AGENTS.md` at `6300b95`.
- Not inspected: the 97 ordinary `PLANS.md` mentions (out of scope by the approved reading), Go code outside the three test files (unchanged), scripts and CI config (unchanged).

## Answers to the brief's four checks

1. **No authority claim lost or changed?** One is lost (A02-2): the rank of route-specific records directly under `.docs/`. Every other removed sentence restated something `AGENTS.md` section 3 or 5 still says (detail below). Separately, the "one place" goal is not met on the tip (A02-1).
2. **Is the new guard sound?** It is sound as a regression check for the exact forms that were removed: no false positive on the tip, and the writer's 12 mutants are caught (I reran them: 12 of 12). It is not sound for the rule it pins: 14 plausible restatements, two of them live sentences on the tip, pass it, and 8 of its 14 fixed phrases can be deleted without any test noticing (A02-3).
3. **README "Read these in order" acceptable as navigation?** Yes (O02-1).
4. **CI on the tip (`aecb180`), as of 21:20Z:** both required checks are still running, not failed. "build, vet and test" (run 45698164973, job 139500934286): Build, Vet, Vet for macOS, Check the test gate and **Test** passed (Test 20:50:09-21:18:30Z); "Listed tests still fail" was running, "Listed tests pass as root" pending. "test on macOS" (run 45698165550, job 139500935552): Check the test gate and **Test** passed (20:52:34-21:09:19Z); "Listed tests still fail" was running. Neither has a final conclusion yet; I will add it below as an addendum when they finish. It cannot change this verdict, and the repair will need fresh CI on its own tip anyway.

## What I checked for check 1, removal by removal

| Removed | Still stated at the tip by | Lost? |
| --- | --- | --- |
| 11 numbered copies, "Authority for this document follows the repo-wide authority hierarchy:" + the five lines (identical to `AGENTS.md` 25-29) | `AGENTS.md:23-29` | No |
| `remote_alpha_access_contract.md` variant, "Authority follows the repository order:" (shorter wording, same five ranks) | `AGENTS.md:23-29` | No |
| 4 TLS inline forms, "Authority follows the repository hierarchy in `AGENTS.md`: `PLANS.md`, `.docs/system_overview/*`, route-specific `.docs/` design records, and then current code/tests for factual implemented behavior" | Order and code/tests rule: `AGENTS.md:23-29, 36`. The "route-specific `.docs/` design records" level: **nowhere** | **Yes, A02-2** |
| Standing rule headers: "They keep the authority they had in `PLANS.md`: … only their location changed" | `AGENTS.md:39` ("They keep `PLANS.md`'s authority, second … only their location changed") | No |
| Owning contracts: "at `PLANS.md`'s rank … `AGENTS.md` section 3 ranks that file with `PLANS.md`" | `AGENTS.md:39` | No |
| `PLANS.md` pointers: "They keep this file's authority (`AGENTS.md` section 3)." | `AGENTS.md:39` | No |
| `README.md`: "and keep its authority" | `AGENTS.md:39` | No |
| `PLANS.md` opening: "`AGENTS.md` ranks it second in authority, and every change starts by reading it" | `AGENTS.md:26` (second) and section 5 ("consult `PLANS.md`", "Agents must consult `PLANS.md` before making structural changes") | No |
| Claim ledger `AGENTS.md` line citations | Remap checked at `6300b95`: `21-36` = §3 (heading at 21, §4 at 38), `38-65` = §4-§5 (§6 at 67), `79-100` = §7 (§8 at 102), `132-159` = §10-§12, `153-159` = §12. "Sections 3 to 5, 7 and 10 to 12" and "section 12" are right | No |

The tests the PR removed (`TestSystemOverviewAuthorityHeadersFollowRepoHierarchy`, `assertDocIncludesAuthorityHierarchy` and the preface checks in six Workstream tests) asserted only the copies. I read every removed hunk: no other assertion went with them.

## Findings

```text
AUDIT FINDING
ID / Type / Severity: A02-1 / contract/authority drift / medium
Current contract or strategic target: the approved plan (each doc says what it governs; the order
  and ranks are stated once, in AGENTS.md; the copies go; PLANS.md holds only intent and order),
  and the rule this PR adds at AGENTS.md:33: "This section is the one place that states the
  authority order and the rank of a file in it. Other documents say what they govern; they do not
  restate the order, their own rank, or another file's rank."
Path and line / Evidence (tip aecb180):
  - .docs/system_overview/evolution.md:71 "If this file and `PLANS.md` differ on scope,
    `PLANS.md` controls." A rank sentence naming PLANS.md, the class this PR set out to remove.
    Same file :9 "`PLANS.md` is authoritative for:" + a list that restates AGENTS.md order entry 2.
    Not pinned by any test.
  - PLANS.md:26-29 "The record is closed and is historical evidence only: it holds no current
    authority, and where it differs from this file or from an owning `.docs/` contract, they win."
    A copy of AGENTS.md:38 (another file's rank), in the file that should hold only intent and order.
    Pinned by TestPlansOpensWithTheCurrentPlan (plans_docs_contract_test.go:150-151).
  - README.md:210 "it is historical evidence with no current authority" (pinned by
    TestPlansRecordIsNamedWhereAgentsStart) and README.md:186 "Where this README and those docs
    disagree, the docs win." (README's own rank; AGENTS.md:34 already says README is not design
    authority).
  - Kept on purpose by the writer, and sensible: 9 docs say code and tests win over them on
    implemented behavior (es_execution_admission_model.md:24, noninteractive_status.md:23,
    artifact_hygiene.md:11, artifact_publication_storage.md:20, boundaries.md:9, contracts.md:11
    and :1478, runtime_config_ownership.md:15, runtime_identity_handoff.md:16, shared_kernel.md:15).
    Read literally, AGENTS.md:33 forbids these too: code and tests are entry 5 of the order, so
    "code and tests win over this document" states the document's own rank.
  - The guard passes on this tree (TestAuthorityOrderIsStatedOnlyInAgents PASS in my head run).
Impact: AGENTS.md is the top authority. On the tip its new rule is contradicted by the tree,
  including by two strings the test suite pins, while a test named "...IsStatedOnlyInAgents"
  passes. An agent that follows AGENTS.md either deletes sentences the writer meant to keep or
  files governance conflicts. David's question ("why do they need to reference PLANS.md") still
  applies to evolution.md.
Required correction:
  (a) Drop evolution.md:71's rank sentence; reword :9 as an ordinary pointer, with no
      "authoritative" (for example: which surfaces are reopened, what is in scope and in what
      order is set in `PLANS.md`).
  (b) Drop the rank clauses about the record from PLANS.md:26-29 and README.md:210 (keep "closed"
      and "historical" as a description), and update the two pinned strings.
  (c) Word the AGENTS.md rule to forbid exactly what the plan forbids: restating the order or the
      rank of a file in it. Say explicitly that a document may say what it governs, which document
      owns a topic, and that code and tests win over it on implemented behavior. Then decide
      README.md:186 under that wording (my recommendation: drop it; AGENTS.md:34 covers it).
  (d) Re-sweep the tree with the method below and make A02-3's guard hold the result.
Uncertainty: the line between "says what it governs" and "states a rank" is a judgment. The four
  sentences under (a) and (b) are rank statements under any reading I can construct.
Patch defect or pre-existing issue: patch defect (the rule at AGENTS.md:33 and the "one place"
  claim are new in this PR; the sentences pre-date it).
```

```text
AUDIT FINDING
ID / Type / Severity: A02-2 / contract/authority drift / low
Current contract or strategic target: brief check 1 ("no authority claim is lost or changed");
  the approved plan (the order lives in AGENTS.md, so a rank that moves out of a doc moves there).
Path and line / Evidence: at base ae9aa65 four docs ranked a level that AGENTS.md does not have:
  .docs/remote_alpha_operator_healthcheck_tls_operator_authorized_replacement.md:55-57,
  ..._tls_signing_custody.md:47-49, ..._tls_signing_custody_decision.md:49-51 and
  ..._tls_signing_custody_resolution.md:44-46: "`PLANS.md`, `.docs/system_overview/*`,
  route-specific `.docs/` design records, and then current code/tests". AGENTS.md:23-29 ranks only
  `.docs/system_overview/*` and `.docs/execution_lifecycle/*`; nothing ranks the seven records
  directly under `.docs/`. `git grep "route-specific \`.docs/\`"` finds the phrase at base in
  those four files only, and nowhere at the tip. The writer's report and PR body call these four
  "inline copies"; they were not pure copies.
Impact: a design conflict between one of these records and `.docs/system_overview/*` used to
  resolve for system_overview by the records' own statement; now no file ranks them, so AGENTS.md:37
  applies ("surface a design-governance conflict"). Small in practice, but it is a silent authority
  change in a PR whose brief allows none.
Required correction: move the rank into AGENTS.md section 3 (one rule, pinned, for example
  "Route-specific design records directly under `.docs/` rank after `.docs/system_overview/*`"),
  or have the coordinator decide to drop it and say so in the PR body and report. I recommend
  moving it: it keeps every claim and is the plan's own pattern (compare AGENTS.md:38-39).
Uncertainty: one can argue that a doc never had the authority to add a level to AGENTS.md's order,
  so nothing authoritative was lost. Either way the drop should be a stated decision.
Patch defect or pre-existing issue: patch defect (the drop); the gap in AGENTS.md is pre-existing.
```

```text
AUDIT FINDING
ID / Type / Severity: A02-3 / test gap / low
Current contract or strategic target: the guard's own claim (authority_order_docs_contract_test.go:56-60:
  "No other Markdown file of the repository may restate the order, its own rank or another file's
  rank"); David's standing rule that a temporary edge needs a machine-enforced trigger.
Path and line / Evidence:
  - The guard is a case-sensitive substring denylist of 14 fixed phrases plus the five order lines
    (lines 16-31, 35-42, 44-54). It matches after whitespace compaction only: no case folding, no
    removal of backticks or link syntax, no "§".
  - Probe (Go, 02-evidence/zz_audit_probe_test.go.txt, calling the real authorityOrderPhrases and
    authorityOrderCopies on the tip): all 14 forms PASS, none refused. P1 "The authority order is in
    `AGENTS.md` §3.", P2 "Authority follows AGENTS.md section 3.", P3 a linked "[`AGENTS.md`](..)
    section 3", P4 lower-case "authority for this document", P5 a numbered copy whose items are links,
    P6-P10 plain-word copies and own-rank sentences, P11 the route-record rank A02-2 asks to move,
    P12 the TLS form split by a link, P13 evolution.md:71 and P14 PLANS.md:26-29 (both live).
    End to end: inserting "The authority order is in `AGENTS.md` §3; this document ranks after
    `PLANS.md`." into shared_kernel.md, `git add -A`, then TestAuthorityOrder*, TestPlans*,
    TestStandingRules* and TestMarkdown*: ok.
  - List mutants (02-evidence/listmut.py.txt: each of the 14 fixed phrases deleted in turn, then
    `go test . -run ^TestAuthorityOrder`): 8 survive, 6 are killed by the self-test. Survivors:
    "Authority for this document", "repo-wide authority hierarchy", "repository hierarchy in
    `AGENTS.md`", "`AGENTS.md` for agent operating rules", "`PLANS.md` for allowed redesign work",
    "for factual implemented behavior", "`AGENTS.md` section 3", "ranks that file with". Three of
    them overlap a line derived from AGENTS.md, but the derived line is longer, so deleting e.g.
    "`PLANS.md` for allowed redesign work" lets the shorter access-contract variant back in.
Impact: the guard stops the removed wordings from coming back, but not a new wording of the same
  thing, such as "`AGENTS.md` §3", a numbered copy with links, or a lower-case preface. It already
  misses two live rank sentences (A02-1). Unpinned phrases can be deleted from the list unnoticed.
Required correction: check sentences, not fixed strings. Normalize first (case-fold, drop
  backticks, replace [text](target) with text, "§" with "section"), then refuse any sentence in a
  Markdown file other than AGENTS.md and the record that pairs a rank word (rank, ranks, authority
  order, authority hierarchy, controls, wins, outranks, precedence, same authority, no current
  authority, authoritative for) with a file of the order (AGENTS.md, PLANS.md, standing_rules,
  system_overview, execution_lifecycle, README, the record, "this file", "this document"), except
  for an exact allowlist of the ordinary sentences that remain and the code-and-tests form A02-1(c)
  allows. Acceptance: every probe P1-P14 in the evidence file is refused; the tip passes after
  A02-1; the self-test gives each refused phrase or pattern an example that only it refuses.
Uncertainty: the exact word list is a design choice for the writer; the acceptance cases are what
  matter.
Patch defect or pre-existing issue: patch defect (new guard).
```

```text
AUDIT FINDING
ID / Type / Severity: A02-4 / test/doc gap and report inaccuracy / low
Current contract or strategic target: procedures.md "Docs and READMEs" (stale docs are a doc gap);
  reports state facts that hold.
Path and line / Evidence: the PR body says the section headings "('Purpose and authority' and
  similar) are unchanged, because tests use them as section markers"; the report says the same.
  No test uses them: `grep -rn "## 0\. Purpose\|## 1\. Purpose\|Purpose, Authority\|urpose and authority"
  --include=*_test.go` finds only an unrelated "## 1. Purpose and status" marker
  (docs_contract_test.go:13119), and no Markdown file links to those anchors. 11 docs keep such a
  heading. In .docs/execution_lifecycle/workstream_c7_checkpoint.md:3 "## 0. Purpose, Authority,
  And Status" now heads a section with no authority content at all (lines 5-31).
Impact: a heading that announces content the section no longer has, kept for a reason that is not
  true.
Required correction: rename each such heading whose section no longer states authority (for
  example "Purpose and status"), or keep them and correct the stated reason in the PR body and
  report. Renaming is safe: nothing references them.
Patch defect or pre-existing issue: patch defect.
```

## Observations (not blocking)

- **O02-1, README "Read these in order" (check 3).** Acceptable as navigation. `AGENTS.md:34` says README is not design authority, and the README says it is a navigation entrypoint (README.md:186). The list names ten specific files in reading order; it is not the five ranked categories, and it sits in the agent index at the bottom of the README, which is where project procedure puts such an index. The README sentences around it that do state rank are covered by A02-1. Pre-existing, minor: the in-order list leaves out the two standing rule files, which `AGENTS.md` section 5 says to consult before changes; they are under "Supporting references".
- **O02-2, the new `PLANS.md` bullet** says "Put a standing rule in the file that owns it, not here. The standing rules that used to sit in this file moved, unreworded, to `.docs/standing_rules/`", while two standing-rule sections are still in `PLANS.md` ("Current paired-root custody and acceptance scope", line 1286, and "Remote Alpha access contract v1 — Tranche A", line 1627; the writer's follow-up 2). A reader may conclude `PLANS.md` holds no standing rule. Suggest naming the two sections in the bullet and pinning that list, which also gives the backlog item a machine trigger.
- **O02-3, line-citation guard.** `plansCitedFile` now matches any `AGENTS.md`, including another repository's (for example `Governed Execution Coordinator/AGENTS.md:12`). No such citation exists today; the same was already true of `PLANS.md`.
- **O02-4, writer's mutant run.** Its `-run Authority|Plans|StandingRules|Markdown` filter means "caught by the intended test only" holds within those tests, not across the package.

## Validation assessment

Re-run by me, on clean clones of base `ae9aa65` and head `aecb180` (`/opt/audit/ci-base`, `/opt/audit/ci-head`), as the unprivileged user `ci`, `umask 022`, go1.26.5 linux/amd64, `GOTOOLCHAIN=local GOPROXY=off`, proxy variables unset, HUP/INT/QUIT/TERM reset to default, uuid-runtime, openssh-client, acl, iproute2 and en_US.UTF-8 installed, `go test -count=1 -json -timeout 40m <pkg>`:

| Package | Base | Head |
| --- | --- | --- |
| `.` (root) | 175 top-level / 617 with subtests, all pass | 176 / 618, all pass |
| `./internal/testutil` | 6 pass | 6 pass |
| `./scripts` | 462 top-level: 437 pass, 16 skip, 9 fail (2,269 / 21 / 40 with subtests) | identical, the same 9 failures by name |

- Root: only in base `TestSystemOverviewAuthorityHeadersFollowRepoHierarchy`; only in head `TestAuthorityOrderGuardFindsEachFormOfCopy` and `TestAuthorityOrderIsStatedOnlyInAgents`. No common test changed its verdict. This matches the writer's 617 to 618, from a different setup (non-root, not the writer's root run).
- `./scripts`: no test changed its verdict, none only on one side. The 9 failures on both trees: `TestRemoteAlphaESServiceTLSStatusFailureWitnessBootstrapOwnedTerminal`, `TestRemoteAlphaESServiceTLSStatusRootLoadedStageCustody`, `TestRemoteAlphaESServiceTLSStatusStageFIFOSubstitution`, `TestRemoteAlphaOperatorRecoverySessionESTLSStatusRemoteWrapperTrap`, `TestRemoteAlphaOperatorRecoverySessionESTLSStatusStageFIFORefusal`, `TestRemoteAlphaP0tGrammarDiagnosticBootstrapLifecycleComposition`, `TestRemoteAlphaP0tGrammarDiagnosticPriorReaderCloseSuppression`, `TestRemoteAlphaP0tGrammarDiagnosticV2VersionedBootstrap`, `TestRemoteAlphaUpgradeESCheckRefusesWhatItWasNotWrittenFor`. Against the writer's 38 (root, without the tools): 8 of my 9 are in that list; 30 of theirs pass in my setup; `TestRemoteAlphaUpgradeESCheckRefusesWhatItWasNotWrittenFor` fails in mine and not in theirs (Inference: it depends on the account or the installed tools; it fails on base too, so it is not this PR). Both setups agree that base and head match. This PR changes no script or scripts test.
- `go vet .` clean on the head worktree; `gofmt -l .` lists none of the three changed Go files (it lists 6 untouched files: `ags/sign/signer.go`, `ars/index/index.go`, `egs/sign/signer.go`, `es/runtimehelper/main.go`, `es/runtimehelper/privilege_linux.go`, `internal/observability/observability.go`).
- Writer's 12 mutants (`01-mutants.py`, SHA-256 `e187fa26…9615` verified), rerun unchanged on a clean clone of the tip: 12 of 12 caught, each by the test the writer named; unmutated tree ok (02-evidence/writer-mutants-rerun.out.txt).
- Not re-run: macOS (CI only); the writer's root run as root.

## Method notes

- Residual-rank sweep (02-evidence/rank-sweep.py.txt, output rank-sweep-tip-aecb180.txt, 51 sentences): every git-listed `.md` at the tip except `AGENTS.md` and the record, split into sentences; a sentence is listed when it pairs a rank or precedence word with a file of the order, "this file/document" or "code and tests". Most hits are ordinary ("the authoritative Workstream B decision", CP file names in `mvp.md`); A02-1 names the ones that state which file wins or controls, or copy `AGENTS.md`. `.docs/commercialization/first-buyer-and-failure-mode.md:18-20` ("… in that ledger control this document") is a precedence between two docs that are not in the order; it can stay under the wording A02-1(c) asks for.

## Sensitive-material handling

No secrets read or written. The repo is public. The audit touched only the ES clone, scratch clones under `/opt/audit`, and this report folder.

## Remaining uncertainty and stop conditions

- A02-1's line between "what a doc governs" and "a rank" is a judgment; I named only sentences that state which file wins or controls, or that copy `AGENTS.md`.
- A02-2's fix (move or drop) is the coordinator's call.

## Confidence

- Provenance: high (exact reproduction, double run, closing check).
- Validation: high for root, testutil and scripts (per-test identical on both trees; 9 Remote Alpha scripts tests are environment-limited here).
- Implementation: high that every removed copy is gone and that only A02-2's claim was lost; high that A02-1's sentences remain and contradict the new rule.

## Effect status

No repair, commit, push, PR edit, comment or merge by this thread. Evidence files are beside this report (`02-evidence/`).

## Report delivery

`/mnt/project-files/reports/execution-substrate/docs-standalone/02-audit.md`, SHA-256 in the reply that delivers it.

Final verdict: BLOCK

## Addendum: CI (2026-11-25 21:38Z)

Final conclusions on the audited tip `aecb180`, read with the GitHub Actions job listing:

- "build, vet and test" (run 45698164973, job 139500934286): **success**, 20:46:38-21:34:24Z. Every step succeeded, including Test (20:50:09-21:18:30Z), Listed tests still fail (to 21:33:26Z) and Listed tests pass as root (to 21:34:22Z).
- "test on macOS" (run 45698165550, job 139500935552): **success**, 20:46:38-21:22:07Z. Every step succeeded, including Test (20:52:34-21:09:19Z) and Listed tests still fail (to 21:22:00Z).

This does not change the verdict. Note: at 21:34:27Z the PR head moved to `a0dc3c96234fb4081fe7b5da74883d3b3e5e50f6` (2 commits, 29 files). This audit binds `aecb180` only; the new head needs its own fresh audit (protocol §14).
