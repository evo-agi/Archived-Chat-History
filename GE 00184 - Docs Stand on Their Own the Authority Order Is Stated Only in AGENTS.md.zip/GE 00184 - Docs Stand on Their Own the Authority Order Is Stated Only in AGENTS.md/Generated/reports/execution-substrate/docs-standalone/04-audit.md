# ES docs stand on their own: independent re-audit 04 of PR #64

Status: delivered. Written 2026-11-25 by the fresh, read-only audit thread "Re-audit the ES docs cleanup" (this thread has not audited PR #64 before). Model: Opus.

**Verdict: BLOCK.** Two low findings, both patch defects; no provenance problem. Every item audit 02 named is fixed: the four sentences under A02-1, the route-record rank (A02-2), the guard now reads sentences (A02-3) and the headings are renamed (A02-4). Provenance reproduces exactly, tests match the writer's report by name, and the writer's 55 mutants are all caught again. What blocks: five docs still tell editors that code and tests win over them, in a wording the repair did not touch (A04-1); and the guard still lets through common rank wordings such as "takes priority over", "has higher authority than" and "section 3 of `AGENTS.md`", and 60 of the 88 words and switches in its own vocabulary can be deleted without any test noticing (A04-2). Standing policy is that low findings are fixed in the PR.

```text
INDEPENDENT AUDIT REPORT
Repository:        evo-agi/Execution-Substrate, PR #64 (draft)
Audit target:      base ae9aa65322954be16d5d3e354dd0aeec5d87723d (trunk_dev, unchanged at open and close)
                   topic claude/project-thread-8x4q85, commit a0dc3c96234fb4081fe7b5da74883d3b3e5e50f6
                   tree b405c53bcba3faf62a6e2abeefb9bfa5ac2d5727 (two commits: aecb180, a0dc3c9)
                   recipe governed-execution.audit-patch-manifest.v2,
                     source SHA-256 c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca
                   canonical manifest SHA-256 a28faa027803fe67f35da846d11105befc52cce89fd12cb637f39296c9d09ae4
                   textual diff SHA-256 dbcea04afeba667d6e212f6a7465fee789af44da6785553a122ff15ec2cb3703
                   29 changed paths (28 tracked_modified, 1 untracked: authority_order_docs_contract_test.go)
Audit posture:     read-only; parent only, no subagents; nothing pushed, no PR edit, no comment
Final verdict:     BLOCK
```

## Provenance reproduction

- Recipe bytes: `sha256sum` of `/mnt/project-files/operating-protocol/tools/governed_execution_audit_patch_manifest_v2.py` and of the copy that ran (`/opt/audit/v2.py`) both gave `c08597e2…a1ca`, the pinned value. Checked again before the closing run.
- Followed provenance §5.3 in `/home/user/Execution-Substrate`, `umask 022`: fetched `trunk_dev` and the topic; `origin/claude/project-thread-8x4q85` = `a0dc3c9…`; `ae9aa65` is an ancestor; `git checkout -f -B <topic> <tip>`; `git status --porcelain` empty; `git reset --mixed ae9aa65`; upstream pinned to `origin/trunk_dev`; v2 run twice into a fresh mode-0700 directory.
- The two outputs were byte-identical (`cmp`) and equal to `03-expected-manifest.json` byte for byte (SHA-256 `a28faa02…9ae4`, 29 files). No mode-bit differences. `git rev-parse a0dc3c9^{tree}` = `b405c53b…5727`.
- PR facts from GitHub: head `a0dc3c9`, base `trunk_dev` `ae9aa65`, 29 changed files, 2 commits, draft.
- Closing manifest: the audit repo had no other worktree and no audit artifact (all probes and mutants ran in separate clones under `/opt/audit`). Same steps, two v2 runs: byte-identical, equal to the opening output (SHA-256 `a28faa02…9ae4`). `trunk_dev` was still `ae9aa65`. Then `git reset --mixed a0dc3c9`; `git status --porcelain` empty.

## Coverage

- Read in full: the whole diff `ae9aa65..a0dc3c9` (29 paths); `authority_order_docs_contract_test.go`; the changed hunks of `docs_contract_test.go` and `plans_docs_contract_test.go`; `AGENTS.md` sections 1 to 6 at the tip and at base; audit 02 (`02-audit.md`), writer report 03 (`03-report.md`, SHA-256 `5904ee0e…d837` verified), `03-mutants.py` (SHA-256 `edb07f77…aa5f` verified) and `03-mutants.out`; the PR body; `.codex/agents/es-boundary-auditor.toml` (no rank statement).
- Swept every git-listed Markdown file at the tip (54 files, all but `AGENTS.md` and the record) with the guard's own sentence splitter and a wider word list than the guard's (Method notes).
- Checked which packages read the changed docs: only the root package, `./internal/testutil` and `./scripts` do; the `README.md` strings in `es/admission` and `es/app` tests are fixtures, not repository reads.
- Not inspected: the 97 ordinary `PLANS.md` mentions (out of scope by the approved reading); Go code outside the three test files (unchanged); scripts and CI config (unchanged).

## A02 findings: closure

| Finding | What audit 02 asked | At `a0dc3c9` | Closed? |
| --- | --- | --- | --- |
| A02-1 (medium) | (a) evolution.md:71 "`PLANS.md` controls" and :9 "is authoritative for" | :71 now "`PLANS.md` holds the redesign-phase list of reopened high-risk surfaces."; :9 now "`PLANS.md` sets:" | Yes |
| | (b) `PLANS.md` record clause and `README.md:210`, with the two pinned strings | Both clauses gone; `TestPlansOpensWithTheCurrentPlan` and `TestPlansRecordIsNamedWhereAgentsStart` pin the new wording | Yes |
| | (c) `AGENTS.md` rule wording; README:186 | `AGENTS.md:33` rewritten; the coordinator ruled (21:21Z) that docs drop "code and tests win over this doc" too and `AGENTS.md:37` states it once. README:186 "the docs win" gone | Yes, as ruled |
| | (d) re-sweep the tree, make the guard hold the result | Nine "code and tests win" sentences removed. **Five more sentences of the same kind remain**, untouched (A04-1) | **No** |
| A02-2 (low) | Move the route-record rank into `AGENTS.md` §3, or record the drop | `AGENTS.md:34`, pinned by `TestAuthorityOrderIsStatedOnlyInAgents` (writer mutant A1 caught) | Yes (scope note: O04-2) |
| A02-3 (low) | Check sentences, not fixed strings; refuse P1-P14; tip passes; each rule has an example only it refuses | Sentence guard with ten rules and two copy variants; P1-P14 refused (self-test, and writer mutants P1-P14 caught end to end); tip passes; each rule has a sole example | The stated acceptance cases: yes. The impact it addressed, new wordings passing: **still largely open** (A04-2) |
| A02-4 (low) | Rename headings or correct the reason | Thirteen headings renamed; `remote_alpha_access_contract.md` keeps "## 1. Authority, scope, and status", used as a marker by `docs_contract_test.go:9706` and `:9881`, and its section is about the ownership split | Yes |
| O02-2 | Name the two standing-rule sections still in `PLANS.md` | Named in the opening and pinned; a test fails when either heading leaves | Yes |

## No authority claim lost or changed (brief check)

Audit 02 checked every removal of the first commit `aecb180`; I re-read those hunks and agree. For the repair commit, removal by removal:

| Removed or reworded (repair) | Still stated at the tip by | Lost or changed? |
| --- | --- | --- |
| "code and tests win" in seven docs (`es_execution_admission_model`, `noninteractive_status`, `artifact_hygiene`, `artifact_publication_storage`, `boundaries` ("When prose and code disagree, code and tests win."), `system_overview/contracts` (intro, and §13 "Code and tests outrank stale prose."), `shared_kernel`) | `AGENTS.md:37` (factual behavior; docs realigned). The `boundaries` and `contracts` forms were broader than `AGENTS.md:36-37` allow (code is not design authority for cross-service behavior), so dropping them removes a conflict, not a claim | No |
| `runtime_config_ownership` and `runtime_identity_handoff`: "code and tests win … before Workstream E/F continues" | Gate kept: "Workstream E/F continues only once this document matches current code and tests on implemented behavior"; precedence at `AGENTS.md:37` | No |
| `evolution.md` "is authoritative for", "is the authoritative … list", "`PLANS.md` controls" | `AGENTS.md:26` (order entry 2: allowed redesign work, reopened seams) and §6 ("Re-derive a surface only when `PLANS.md` marks it as reopened") | No |
| `PLANS.md` record clause; `README.md` "no current authority" | `AGENTS.md:39` | No |
| `README.md` "defer to the authoritative docs", "the docs win", "not in the README" | `AGENTS.md:35` ("Do not use `README.md` as design authority") | No |
| `first-buyer-and-failure-mode.md` "… in that ledger control this document" | Reworded to ownership: the ledger stays "the primary guardrail" and the doc "uses that ledger's allowed and forbidden wording, required qualifiers, evidence classes, and source gaps". Inference: the same constraint, stated as which document owns the wording (O04-3) | No |
| TLS docs' route-record rank | `AGENTS.md:34`, for the five `remote_alpha_operator_healthcheck_*.md` files (O04-2) | Moved; scope widened by one file, as audit 02 suggested |

`AGENTS.md` section numbering is unchanged (the repair adds two bullets inside §3), so the claim ledger's "Sections 3 to 5, 7 and 10 to 12" and "section 12" still hold (§12 "Capability probing rules", line 159).

## Findings

```text
AUDIT FINDING
ID / Type / Severity: A04-1 / contract/authority drift / low
Current contract or strategic target: AGENTS.md:33 (new in this PR): "This section is the one place
  that states the authority order, the rank of a file in it, and which source wins when two
  disagree. Other documents ... do not ... say that one file or source ranks above, controls, or
  wins over another." The coordinator's repair ruling (21:21Z, quoted in report 03): "A doc says
  nothing about who outranks whom, so the 'code and tests win over this doc' sentences go too."
  The brief: "The authority order, including the precedence of code and tests, is stated once,
  in AGENTS.md §3."
Path and line / Evidence (tip a0dc3c9), each a bullet under "Decision rules for future edits":
  - .docs/execution_lifecycle/contracts.md:2082 "If code and tests disagree with this file, update
    this file to match reality."
  - .docs/execution_lifecycle/design.md:664 (same sentence)
  - .docs/execution_lifecycle/implementation.md:1192 (same sentence)
  - .docs/system_overview/architecture.md:337 (same sentence)
  - .docs/system_overview/boundaries.md:1013 "If code and tests disagree with this document, update
    the document to match reality."
  Each says which source wins when code and a doc disagree: the doc is the one that changes. That
  is the precedence AGENTS.md:37 states, restated per doc, which is exactly what the nine removed
  sentences did (boundaries.md lost its "code and tests win" at the top and keeps this one at
  :1013; system_overview/contracts.md lost the same rule from its own "future edits" list, §13).
  Two of them are broader than AGENTS.md: architecture.md and design.md are design documents, and
  read literally the bullet makes code the authority for their design content, which
  AGENTS.md:36 and :38 rule out (code is not design authority for cross-service behavior; a
  design disagreement code does not settle is surfaced as a conflict).
  No test pins these sentences (grep of *_test.go for "match reality" and "disagree with this":
  none). The guard passes them: it has no rule for "disagree ... update this file", and an
  end-to-end insert of the boundaries.md form into shared_kernel.md passes the whole root package
  (04-evidence/e2e-rank-sentences.txt). Audit 02 missed them too: its sweep keyed on rank words.
Impact: the "stated once" goal is not met for the code-and-tests precedence, which the brief names
  explicitly, and report 03 says the "code and tests win" sentences are gone. An agent following
  AGENTS.md:33 cannot tell whether these bullets are allowed. Small in practice: their direction
  matches AGENTS.md:37 for factual behavior.
Required correction: delete the five bullets (AGENTS.md:37 already says it), or, if the coordinator
  wants an editing reminder kept, reword it without a precedence, as the Workstream E/F gates were.
  Make the guard refuse this form (A04-2 acceptance case R1 below).
Uncertainty: whether an editing instruction "states which source wins" is a judgment; I read it as
  the same precedence, by the coordinator's ruling on the nine sentences.
Patch defect or pre-existing issue: patch defect (the rule at AGENTS.md:33 and the "stated once"
  claim are new in this PR; the sentences pre-date it), same classification as A02-1.
```

```text
AUDIT FINDING
ID / Type / Severity: A04-2 / test gap / low
Current contract or strategic target: the guard's own claim (authority_order_docs_contract_test.go:14-16:
  "the checks below keep such statements out by meaning, not only in the wordings that were
  removed"); A02-3's impact ("not a new wording of the same thing"); David's rule that an edge
  needs a machine-enforced trigger, which this guard is for AGENTS.md:33.
Path and line / Evidence:
  1. Probes (04-evidence/zz_audit04_probe_test.go.txt calls the guard's own authorityStatements on
     the tip; output probe-out.tsv): 32 of 35 rank wordings pass. Natural ones that pass:
       N01 "`PLANS.md` has higher authority than this document."
       N02 "This document has lower authority than `PLANS.md`."
       N03 "Code and tests take priority over this document."
       N04 "Where they differ, `PLANS.md` takes priority."
       N06 "See section 3 of `AGENTS.md` for the order."
       N07 "The order is in `AGENTS.md` (section 3)."
       N09 "This document is subordinate to `PLANS.md`."
       N10 "Conflicts between this document and `PLANS.md` are resolved in favor of `PLANS.md`."
       N11 "`PLANS.md` is authoritative over this document."
       N21 "If this document and `PLANS.md` conflict, follow `PLANS.md`."
       N24 "The system overview docs come before this document in authority."
       N30 "Code and tests are authoritative over this document for implemented behavior."
       N35 "`PLANS.md` comes first, then the system overview docs, then this document."
     plus A04-1's form. Refused: N05 (only through its "AGENTS.md section 3"), N29, N34.
     End to end: N03, N01, N06, N09 and A04-1's form inserted into shared_kernel.md, `git add -A`,
     `go test -count=1 .`: ok (04-evidence/e2e-rank-sentences.txt).
  2. Vocabulary mutants (04-evidence/alt_mutants.py.txt, output alt-mutants.out.txt): each
     alternative of every regex in the guard deleted in turn, plus ten normalization, splitting
     and file-selection switches; whole root package each time. 60 of 88 survive. The ones that
     matter: the file gate's `.docs/`, `readme`, `plans-record`, `standing_rules`,
     `system_overview`, `execution_lifecycle`, `code/tests`, `go code`, "this file/doc/record/
     contract/page"; "no", "its", "their", "keeps", "kept" and "'s" authority; "controlled by",
     "control this/that/the file"; "overrides", "supersedes", "prevails"; "first/third/fourth/
     fifth/last in authority/rank"; and the file selection itself: the guard can skip README.md,
     or read only .docs/, and every test still passes (the 40-file floor is met by .docs/ alone).
     The writer's D mutants delete whole rules; the self-test gives each rule one example, so it
     pins rules, not the words inside them. This is the same gap audit 02 found for fixed phrases
     (8 of 14 unpinned).
  3. Reproduced as claimed: the writer's 55 mutants, rerun unchanged as `ci` on a clean clone:
     55 of 55 caught, each by the named test (writer-mutants-rerun.out.txt).
Impact: the guard is the machine trigger for AGENTS.md:33, and it misses ordinary English for the
  very thing it forbids ("takes priority over" is as common as "takes precedence over", which it
  refuses). Large parts of its vocabulary, and its file scope, can be deleted silently.
Required correction (acceptance cases, so the next round can check a fixed list):
  (a) Refuse N01, N02, N03, N04, N06, N07, N09, N10, N11, N21, N24, N30, N35 and
      R1 "If code and tests disagree with this file, update this file to match reality.", each as
      a probe in the self-test.
  (b) Every surviving alternative and switch in alt-mutants.out.txt either gets a self-test example
      that fails without it, or is removed as dead (for example the non-breaking-space
      replacement, which compactText already covers). Pin the file scope: the test fails if
      README.md, PLANS.md or a Markdown file outside .docs/ is no longer read.
  (c) Keep the self-test's eight ordinary sentences and probe-out.tsv's F13 to F16 passing, and
      the tip passing.
  (d) Name the residual limit in the guard's comment as a non-claim: words outside the vocabulary
      ("trumps", "beats", N13/N14), a rank split across two sentences by a pronoun (N16),
      reference-style links (N17), an "i.e."/"e.g." cut (N15), curly apostrophes (N18). I do not
      ask for these: the tree has one curly apostrophe, one "e.g./i.e." and no reference-style link
      definitions in Markdown.
Uncertainty: the word list is the writer's design choice; the acceptance cases are what matter.
  A vocabulary guard cannot be complete; (d) records that, and AGENTS.md:33 stays the rule.
Patch defect or pre-existing issue: patch defect (new guard).
```

## Observations (not blocking)

- **O04-1, false positives.** 15 of 18 ordinary sentences I tried are refused (probe-out.tsv F01-F18), for example "This document controls the wire format of the status route." (it says what the doc governs, which `AGENTS.md:33` asks for), "ES controls admission for every submit (see `.docs/execution_lifecycle/contracts.md`).", "Vault has no authority over Nomad placement; see `.docs/system_overview/boundaries.md`.", "If a key appears twice in this file, the last one wins." and "Environment variables override values in this file." The tree has none today (one allowlist entry), the failure is loud and the message says how to reword, so this is friction, not a hole. It will grow if A04-2(a) adds words such as "authority over". Suggestion: refuse a rank word only when an order file is its subject or object (within a few words, or a "differ/disagree/conflict … wins/applies/follow" frame), so ownership sentences that cite a `.docs/` path pass.
- **O04-2, route-record rule scope.** `AGENTS.md:34` covers the five `remote_alpha_operator_healthcheck_*.md` files. Only the four `…_tls_*` docs stated the rank; `remote_alpha_operator_healthcheck_noninteractive_status.md` carried the plain numbered copy and placed itself nowhere. Report 03's note says the rule names "that file family" (the tls_* docs), which is narrower than the glob. Including the fifth file matches audit 02's suggested class ("route-specific design records directly under `.docs/`") and the TLS docs' own wording, so I do not raise it; the coordinator may want the report note corrected. As before the PR, nothing orders these records against `.docs/execution_lifecycle/*`.
- **O04-3, `first-buyer-and-failure-mode.md`.** "… in that ledger control this document" became "This document uses that ledger's allowed and forbidden wording, …", with "The primary guardrail is `claim-ledger.md`" kept. I read it as the same constraint stated as ownership, not a lost precedence. Audit 02 allowed the old sentence; the new `AGENTS.md:33` wording forbids it, so the change was needed.
- **O04-4, `TestStandingRulesKeepPlansAuthority`** keeps its name though the standing-rule files no longer state their rank; the comment explains that only `AGENTS.md` does. Fine.

## Validation assessment

Re-run by me, on clean clones of base `ae9aa65` and head `a0dc3c9` (`/opt/audit/ci-base`, `/opt/audit/ci-head`), as the unprivileged user `ci`, `umask 022`, go1.26.5 linux/amd64, `GOTOOLCHAIN=local GOPROXY=off GOFLAGS=-mod=readonly`, proxy variables unset, HUP/INT/QUIT/TERM reset to default, uuid-runtime, openssh-client, acl, iproute2 and en_US.UTF-8 installed, `go test -count=1 -json -timeout 40m <pkg>` (04-evidence/run-tests.sh.txt, suite-compare.txt):

| Package | Base `ae9aa65` | Head `a0dc3c9` |
| --- | --- | --- |
| `.` (root) | 175 top-level / 617 with subtests, all pass | 176 / 618, all pass |
| `./internal/testutil` | 6 pass | 6 pass |
| `./scripts` | 462 top-level: 437 pass, 16 skip, 9 fail (2,269 / 21 / 40 with subtests) | identical, the same 9 failures by name |

- Root: only in base `TestSystemOverviewAuthorityHeadersFollowRepoHierarchy`; only in head `TestAuthorityOrderGuardFindsEachFormOfRank` and `TestAuthorityOrderIsStatedOnlyInAgents`. No common test changed its verdict. This matches report 03.
- `./scripts`: no verdict change, nothing only on one side. The 9 failures on both trees, the same 9 audit 02 saw in the same setup: `TestRemoteAlphaESServiceTLSStatusFailureWitnessBootstrapOwnedTerminal`, `TestRemoteAlphaESServiceTLSStatusRootLoadedStageCustody`, `TestRemoteAlphaESServiceTLSStatusStageFIFOSubstitution`, `TestRemoteAlphaOperatorRecoverySessionESTLSStatusRemoteWrapperTrap`, `TestRemoteAlphaOperatorRecoverySessionESTLSStatusStageFIFORefusal`, `TestRemoteAlphaP0tGrammarDiagnosticBootstrapLifecycleComposition`, `TestRemoteAlphaP0tGrammarDiagnosticPriorReaderCloseSuppression`, `TestRemoteAlphaP0tGrammarDiagnosticV2VersionedBootstrap`, `TestRemoteAlphaUpgradeESCheckRefusesWhatItWasNotWrittenFor`. The writer's 38 come from a root run without the tools (report 01's list); both setups agree base and head match. I ran `./scripts` at `a0dc3c9` itself; the writer ran it at `85011e3` and argued the difference is one root-package file, which my run confirms in effect.
- `go vet .` clean at head; `gofmt -l` lists none of the three changed Go files; `git diff --check ae9aa65 a0dc3c9` clean.
- Writer's 55 mutants: 55 of 55 caught, unmutated tree ok (above).
- **CI on the head `a0dc3c9`, as of 21:58Z: both required checks still running, none failed.** "build, vet and test" (run 45705595640, job 139526627655): every step through "Check the test gate" succeeded (21:34:37-21:38:36Z); "Test" in progress since 21:38:36Z; "Listed tests still fail" and "Listed tests pass as root" pending. "test on macOS" (run 45705595490, job 139526627143): in progress since 21:34:37Z. On `aecb180` these took about 48 and 36 minutes. I will add the conclusions below as an addendum. They cannot change this verdict, and the repair will need fresh CI on its own tip.
- Not re-run: macOS (CI only); the writer's root-account run.

## Method notes

- Residual sweep (04-evidence/zz_audit04_sweep_test.go.txt, output sweep-tip-a0dc3c9.tsv): the guard's own `authoritySentences` over every git-listed `.md` but `AGENTS.md` and the record; a sentence is listed when it names a file of the order (the guard's `authorityOrderFile`) and any of a wider word list (priority, higher, lower, above, below, subordinate, favor, authoritative, supersede, prevail, defer, precede, binding, overrides, wins, control, rank, authority, order, hierarchy, section 3, conflict, disagree, differ, …). 92 sentences in 54 files; 62 are "Control Plane" mentions. Apart from A04-1's five, the rest are ownership or topic statements ("the authoritative route contract is …", "this file is authoritative for current endpoint … semantics", "higher-level lifecycle design map") or about a planning track ("remains the ES planning authority"), not a rank between files. A separate grep for doc-versus-doc conflict sentences ("differ/conflict/disagree" near "this file/document" or a `.md` name) found only A04-1's five.
- Probes and mutants ran in separate clones (`/opt/audit/probe`, `/opt/audit/mut-mine`, `/opt/audit/mut-writer`), each reset and checked clean after use; the audit repo was not touched.

## Sensitive-material handling

No secrets read or written. The repo is public. The audit touched only the ES clone, scratch clones under `/opt/audit`, and this report folder.

## Remaining uncertainty and stop conditions

- A04-1 rests on reading an editing instruction ("update this file to match reality") as a statement of which source wins. The coordinator may rule otherwise; then A04-1 reduces to the two design docs whose bullet is broader than `AGENTS.md:37`.
- CI on the head had not finished when this report was written.

## Confidence

- Provenance: high (exact reproduction, double run, closing check, PR head equal).
- Validation: high for root, testutil and scripts (per-test identical on both trees; 9 Remote Alpha scripts tests are environment-limited here); CI pending.
- Implementation: high that every item audit 02 named is fixed and that no authority claim was lost; high that A04-1's five sentences remain and that the guard passes the probes listed in A04-2.

## Effect status

No repair, commit, push, PR edit, comment or merge by this thread. Evidence files are beside this report (`04-evidence/`).

## Report delivery

`/mnt/project-files/reports/execution-substrate/docs-standalone/04-audit.md`, SHA-256 in the reply that delivers it.

Final verdict: BLOCK

## Addendum: CI (2026-11-25 22:31Z)

Final conclusions on the audited head `a0dc3c9`, read from the GitHub Actions job listings:

- "build, vet and test" (run 45705595640, job 139526627655): **success**, 21:34:36-22:20:41Z. Every step succeeded, including Check the test gate (to 21:38:36Z), Test (21:38:36-22:05:15Z), Listed tests still fail (to 22:19:43Z) and Listed tests pass as root (to 22:20:40Z).
- "test on macOS" (run 45705595490, job 139526627143): **success**, 21:34:37-22:05:40Z. Every step succeeded, including Check the test gate (to 21:39:20Z), Test (21:39:20-21:53:39Z) and Listed tests still fail (to 22:05:33Z).

This does not change the verdict. Note: by 22:24Z the PR head had moved to `61db96c6d0612711a0a6ad25020e75d60e99cb74` (3 commits, 32 files). This audit binds `a0dc3c9` only; the new head needs its own fresh audit (protocol §14).
