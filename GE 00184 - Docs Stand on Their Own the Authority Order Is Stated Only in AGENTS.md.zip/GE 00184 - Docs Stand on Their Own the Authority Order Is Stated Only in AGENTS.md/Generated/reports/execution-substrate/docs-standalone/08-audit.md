# ES docs stand on their own: independent re-audit 08 of PR #64

Status: delivered. Written 2026-11-25 by the fresh, read-only audit thread "Check the third docs cleanup fixes". This thread has not audited PR #64 before. Model: Opus.

**Verdict: ACCEPT.** No blocking finding and no provenance problem.

- **Provenance.** The manifest reproduces byte for byte (`b08d3f14…3d71`, 32 files). The closing run equals the opening run.
- **The merge of #65 changes nothing in the PR's own diff.** The merge commit `dd30aca` is exactly Git's automatic three-way merge: `git merge-tree` of `6465e80` and `389ecf6` gives tree `ce8e199a…`, the head's tree. The PR's diff against its base is byte-identical before and after the merge, once line numbers and blob ids are set aside (SHA-256 `c6fccbc6…a8e3` on both sides).
- **A06-1, A06-2 and A06-3 are closed.**
  - A06-1: the `evolution.md` "factual source" bullet is gone, and the guard now refuses it.
  - A06-2: every limit stated in the guard's comment and in `AGENTS.md:34` matches what the code does. I checked each with my own probes (52 of 52 as expected) and with reruns of audit 04's and audit 06's probe files.
  - A06-3: the anchor cut is back and pinned. A neutral link to each of the 1,025 headings is refused 0 times.
- **Deleting `evolution.md` §6's "Code may confirm current behavior. It must not become the design source of truth …" loses no claim.** Each part is still stated, in `AGENTS.md` §3 and in `evolution.md` itself (table below). Nothing has to stay.
- **Tests.**
  - Root package: 618 pass at the head, against 617 at the base. The only name changes are the one removed test and the two added ones. No verdict changes.
  - `./scripts`: identical to the base by name (the same 38 top-level environment failures).
  - Static checks are clean. My 8 mutants behave as predicted.
- **CI on the head.** Both required checks passed: "test on macOS" and "build, vet and test" (run 45718085856, 23:47:44Z).

Non-blocking observations follow the findings section. The main one (O08-1): `claim-ledger.md:87` restates `AGENTS.md:37` in the same way as the deleted §6 sentence. By my reading neither is a rank, so it does not block. But the coordinator may want the same rule applied to both.

```text
INDEPENDENT AUDIT REPORT
Repository:        evo-agi/Execution-Substrate, PR #64 (draft)
Audit target:      base 389ecf66bd8828fafc9591111f14628cb86ce7fb (trunk_dev after #65, unchanged at open and close)
                   topic claude/project-thread-8x4q85, commit dd30aca7ff329452f3daf08cd187a9185723f13a
                   tree ce8e199ab39cf259bdf62a9f5fe1d20976463ee5
                   (aecb180, a0dc3c9, 61db96c, 6465e80, then merge dd30aca of 389ecf6)
                   recipe governed-execution.audit-patch-manifest.v2,
                     source SHA-256 c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca
                   canonical manifest SHA-256 b08d3f14dd312d0e4a64bb6285662ea6821d17256a485b46ed2a34ca2d6b3d71
                   textual diff SHA-256 a1877e1257644e60ef9fb4b60273d12d272679be1c1814931428e1dc897b3cb3
                   32 changed paths (31 tracked_modified, 1 untracked: authority_order_docs_contract_test.go)
Delta reviewed:    61db96c..dd30aca = 6465e80 (3 files) + the merge of trunk_dev #65 (17 trunk paths)
Audit posture:     read-only; parent only, no subagents; nothing pushed, no PR edit, no comment
Final verdict:     ACCEPT
```

## Provenance reproduction

- **Recipe.** I verified the v2 recipe against the pinned SHA-256: on the project file, and on the copy that ran (`sha256sum -c`: OK, both before and after the runs).
- **Pushed state.**
  - `origin/claude/project-thread-8x4q85` = `dd30aca7…`.
  - `origin/trunk_dev` = `389ecf66…`, an ancestor of the tip.
  - PR #64 head = `dd30aca7…`, base = `389ecf66…`, 32 files, +666/−281 (read from GitHub at the start of the audit).
  - Tip tree `ce8e199a…` as reported.
- **Commands** (protocol §5.3, in a fresh local clone under `umask 022`): check out the tip, confirm `git status --porcelain` is empty, `git reset --mixed 389ecf6`, pin the upstream to `origin/trunk_dev`, then run v2 twice to two absent paths in a fresh mode-0700 directory.
- **Results.**
  - The two outputs are byte-identical.
  - Both equal the writer's `07-expected-manifest.json` byte for byte. That file's SHA-256 is `b08d3f14…3d71`, the canonical hash.
  - No mode-bit differences.
- **Closing.** At closeout, after all probes and mutants, which ran only in separate scratch clones, I ran v2 twice again in the audit clone. Both outputs are equal to each other and to the opening run (`b08d3f14…3d71`).

## Coverage

- **Read in full:**
  - the delta `6465e80` (`evolution.md`, `AGENTS.md`, the guard);
  - the guard file at the head;
  - `AGENTS.md` §1 to §6 and `evolution.md` at the head;
  - writer report 07 (SHA-256 `b8259dad…2410`, as given in the brief);
  - audit 06's findings, observations and addendum.
- **The #65 side of the merge:**
  - its paths and hunks (`git diff ae9aa65 389ecf6`);
  - its added Markdown lines, grepped for rank and authority wording;
  - audit 06's wide sweep, rerun at the head and diffed against its `61db96c` output.
- **Not inspected:**
  - the parts of the PR outside the delta. Audits 02, 04 and 06 covered them, and the PR's own diff is byte-identical to the one audit 06 read plus `6465e80` (Delta section).
  - macOS behaviour, which I did not run: CI only.
  - the writer's 88 and 84 mutant sets. I did not rerun them; my own 8 mutants cover the delta.

## The delta, change by change

**Merge of #65 (`dd30aca`).** Evidence: `08-evidence/delta-checks.txt`.

- `git merge-tree --write-tree 6465e80 389ecf6` = `ce8e199a…` = `dd30aca^{tree}`. The merge commit carries no hand edits, and its parents are `6465e80` and `389ecf6`.
- **The PR's path set is the same before and after.** Compare `ae9aa65..6465e80`, the pre-merge PR, with `389ecf6..dd30aca`: both have the same 32 paths with `--no-renames`, and +666/−281 on both sides.
- **The PR's changed lines are byte-identical.** I compared `git diff -U0` with index lines dropped and hunk headers reduced to `@@`. Both sides give SHA-256 `c6fccbc62cf126ed3e8a53299628e53a71d6aaecbdab4919fc5d6c581d36a8e3`.
- `dd30aca` differs from `6465e80` on exactly the 17 paths #65 changed.
- **Shared files.** #65 and the PR both edit `implementation.md` (line 1111), `README.md` (128, 138) and `docs_contract_test.go` (seven single lines). None of these overlap the PR's hunks.
- **#65's added text holds no rank between the order's sources.**
  - The "source of truth" uses are topic ownership: "Keep the bring-up check as the readiness source of truth", "the repo-owned proof source of truth".
  - The sweep rerun has 15 new hits. 3 of them replace the old `v1_bringup.md` hits under the renamed file. In every one, the relation words are "govern", from "Governed Execution" in the runbook file names, or ordinary step words ("first", "follow", "apply", "former"). I read all 15: none is a rank.
  - The guard passes on the merged tree, renamed runbooks included.

**Repair commit `6465e80`.**

- `evolution.md`: two deletions, the A06-1 bullet at old line 35 and the §6 sentence at old line 120. Nothing else changed.
- `AGENTS.md:34` is reworded (A06-2), and the guard pins the new text.
- The guard:
  - the comment is rewritten;
  - the anchor cut is restored (`strings.SplitN(parts[2], "#", 2)[0]`);
  - a new rule `factual source` (`\bfactual source\b`) with its sole example;
  - the A06-1 bullet is added under "Forms this PR removed";
  - one ordinary example (an anchored link) is added.
- `gofmt -l` lists none of the three changed Go files. `go vet .` is clean. `git diff --check` is clean for `389ecf6..dd30aca` and for `61db96c..dd30aca`.

## A06 findings: closure

**A06-1 (rank sentence at `evolution.md:35`): closed.**

- The bullet is gone. "How to tell the difference" now holds only the two ownership bullets (`evolution.md:33-34` at `dd30aca`).
- The guard refuses the sentence: as a bullet in its old context (probe C-A06-1-bullet), inside a paragraph (C-A06-1-para), and in another doc (mutant M7, `shared_kernel.md`: `TestAuthorityOrderIsStatedOnlyInAgents` fails).
- Restoring it in place fails the same test (M2).
- **No other rank sentence of this class is left.** My own sweep looked at sentences that name code or tests and a document or prose, keyed on truth, fact, staleness, matching and preference words that audit 06's sweep did not use. It listed 43 sentences, plus 21 that use "authoritative", "source of truth" or "design authority" beside a file of the order (`08-evidence/sweep08-tip.tsv`). I read all 64:
  - ownership: "this file is authoritative for current endpoint …", "the authoritative current matrix is in …";
  - topic: "where nomad becomes authoritative", "staged-helper tests remain the source of truth for helper staging";
  - procedure: "must update plans.md and the authoritative .docs/ contract … before behavior changes land";
  - the Workstream E and F gate, "continues only once this document matches current code and tests on implemented behavior". It says when work proceeds, not which side to change; audits 02 to 06 accepted it.
  - One sentence is close in kind to the deleted §6 sentence: O08-1.
- "factual source" appears in no Markdown file at the head. "stale" appears in no sentence that names both code or tests and a document.

**A06-2 (wrong stated limits): closed.** I checked each claim in the guard comment and in `AGENTS.md:34` against the code:

- **"It reads every git-listed Markdown file except AGENTS.md and the closed plan record."**
  - `repositoryTextFiles` lists `git ls-files -z` and skips only non-regular files and files with a NUL byte. The tree has 56 `.md` files, no symlinks, and no `.MD` or `.markdown` files.
  - The test skips exactly `AGENTS.md` and `plansRecordPath` (`.docs/history/plans-record.md`), and fails unless it read all but those two (54).
  - True.
- **"What the list covers is what the self-test refuses":** the removed forms, P1 to P14, audit 04's 14 listed cases (N01 to N04, N06, N07, N09 to N11, N21, N24, N30, N35 and R1), and one example per word. `TestAuthorityOrderGuardFindsEachFormOfRank` passes at the head, so each is refused. True.
- **"Of audit 04's other rank probes, N05, N20, N29, N31 and N34 are refused too."** True (probes C-N05 to C-N34, and audit 04's probe file rerun).
  - In that rerun, 18 of the 35 probes are refused: the 13 listed N cases plus these 5. The other 17 pass, and each of them is in the comment's gap list.
- **Every gap the comment names passes the guard.** I probed each with a fresh wording, different from audits 04 and 06 (34 G probes, all pass):
  - words outside the vocabulary (N12 to N14, N19, N22, N23, N25 to N28, N32, N33);
  - each near variant: "section 3 in", "section 3 of" a link, "less authority", "comes before", "goes first", "authoritative for anything …", and the conflict wordings "use", "apply", "realign", "change", "follows", a passive, "the code" or "the docs" as a side;
  - a split sentence and a pronoun;
  - reference-style and heading links;
  - the "i.e." cut;
  - the curly apostrophe;
  - the two deleted `evolution.md` sentences.
- **The abbreviation gap is stated conditionally:** "that leaves the file and the wording on different sides of the cut".
  - Audit 06's "e.g." probe keeps the file and the word on the same side, so it is refused. That is consistent with the condition.
- **The known false positives are refused, as the comment says** (probes FP-fence, FP-other-sense; audit 06's 20 F probes, unchanged).
- **`AGENTS.md:34`** now reads: "A repository test refuses a list of known wordings of a rank in the other Markdown files, except the closed record `.docs/history/plans-record.md`. …"
  - This is accurate, and pinned: mutant M4, the old text, and M5, the exception dropped, each fail `TestAuthorityOrderIsStatedOnlyInAgents`.
- My probe output is in `08-evidence/probe08-tip.tsv`. The reruns of audit 04's and audit 06's probe files at the head are byte-identical to the writer's `07-probe04-out.tsv` and `07-probe06-out.tsv`.

**A06-3 (false positive from the removed anchor cut): closed.**

- The cut is back.
- Audit 06's anchor probe at the head: 1,025 headings, **0 refused** (15 anchored `.md` links in the tree).
- My anchor probes all pass:
  - the two other headings audit 06 named;
  - a same-file `#anchor`;
  - a target with a title.
- A rank word in the link's *label* is still refused (A-anchor-label-wins). So the cut drops only the slug.
- Pinned: mutant M1 (cut removed) fails `TestAuthorityOrderGuardFindsEachFormOfRank`. M8 (the ordinary example deleted) fails nothing. So that example is the cut's only pin, which is what audit 06 asked for.

## The §6 deletion: no claim lost

The deleted text (old `evolution.md:120`, the end of "§6 Required order of operations"):

> Code may confirm current behavior. It must not become the design source of truth for cross-service contracts or architectural boundaries.

| Part of the deleted text | Where it is still stated at `dd30aca` |
| --- | --- |
| Code may confirm current behavior (code is a valid source for what the system does today) | `AGENTS.md:29` "current Go code and tests for factual implemented behavior"; `AGENTS.md:38` "If docs and code disagree on factual behavior, code and tests win for current behavior …" |
| Code is not the design source for cross-service contracts | `AGENTS.md:37` "Do not treat code as design authority for cross-service behavior." |
| … nor for architectural boundaries | `AGENTS.md:27` gives `.docs/system_overview/*` "architecture, contracts, boundaries, and change-governance rules", and `:29` limits code to factual behavior. In `evolution.md` itself: `:7` "code must not be the first place a system contract, boundary, lifecycle rule, or shared-kernel decision appears"; `:107` re-derivation "must not begin in code"; `:128` "Structural coupling must be documented before it is preserved." |
| "must not *become*": code must not drift into being the de facto design source over time | `evolution.md:117` (step 5, "implement code to match"); `:125` "`Current invariant` changes … must not drift silently"; `:130` "Do not let code comments or implementation shortcuts substitute for contract documentation."; `:172-174` (realign docs, tests and code; "Unresolved drift must not accumulate. Silent structural change is forbidden."); `AGENTS.md:39` (surface a design conflict instead of guessing) |

**Conclusion.** Each part is still stated, and the change-governance content stays in `evolution.md` itself, at lines 7, 117 and 130. Nothing has to stay.

- **Inference:** "architectural boundaries" is wider than `AGENTS.md:37`'s "cross-service behavior". I count it as covered through `AGENTS.md:27` together with `:29`, and through `evolution.md:7` and `:128`. That rests on reading those lines together, not on one sentence that says it.
- **Whether the sentence was a rank at all is a judgment.**
  - Audit 06 (O06-4) read it as saying "what code does not govern", which `AGENTS.md:33` allows. On that reading the deletion was optional.
  - Restoring it would be just as acceptable: the guard passes it (mutant M6: no test fails), and the comment lists it as a gap.
  - If it is restored, the comment's words "two sentences this PR removed from evolution.md" need updating.
  - Either way, nothing blocks.

## Findings

None blocking. No finding in §13.3 format is raised.

## Observations (not blocking)

**O08-1: `claim-ledger.md:87` is the same kind of sentence as the deleted §6 sentence.**
- The text: "- `implementation detail`: Current code shape exists but is not itself design authority for cross-service semantics."
- It restates `AGENTS.md:37` just as §6 did. It predates the PR and is unchanged by it.
- **By my reading it is not a rank:**
  - it defines a label in the ledger's vocabulary;
  - it names no second source;
  - the line above it ("`evidence/projection` … is not orchestration, lifecycle, security, scheduler, or run-control authority") is the same form.
- **But the writer's reason for deleting §6** ("restates an `AGENTS.md` §3 rule") would take this line too.
- The coordinator may want one rule applied to both:
  - keep §6 deleted and reword this definition (for example "… is not itself the design of cross-service semantics"); or
  - accept both as ownership statements.
- The guard passes it: no file of the order is named.

**O08-2: false-positive exposure of the new "factual source" rule.**
- It refuses an ownership sentence such as "This document is the factual source for the route's exit codes." (probes NF-*).
- No Markdown file at the head contains "factual source". The comment's false-positive clause ("an ordinary sentence that uses a rule word for something else beside a file of the order") names this class. A refusal is loud.
- The same class as O04-1 and O06-1.

**O08-3: carried over unchanged from audit 06.**
- O06-1: 20 ordinary sentences refused. All 20 F probes are still refused, and the comment names the class.
- O06-3: fenced code is read as prose.
- O06-5: a rank wording in a Go comment, `scripts/helpers_test.go:42-43`. Out of the Markdown scope; it agrees with `AGENTS.md:41`.

**O08-4: the PR body's vocabulary list is shorter than the guard's.**
- "What it refuses … The rank wordings are: …" omits three rules: `authority order` (authority order/hierarchy), `authority follows` (authority follows / for this) and `held authority` (same/no/its/their/keep authority, "'s authority").
- This understates coverage; it does not overstate it. The comment in the repo is accurate.
- The PR body is projection and can be fixed without new bytes.

## Validation assessment

All my runs used committed bytes in fresh local clones: base `389ecf6`, head `dd30aca`, and separate clones for probes and mutants.

- **Setup:** as root, `umask 022`, SIGHUP, SIGINT, SIGQUIT and SIGTERM reset to default, go1.26.5 linux/amd64 (downloaded through the module proxy, as `go.mod` requires), `GOFLAGS=-mod=readonly`, `go test -count=1 -json -timeout 60m`.
- Results are compared by test name: `08-evidence/compare.py`, `root-compare.txt`, `scripts-compare.txt`.

| Package | Base `389ecf6` | Head `dd30aca` |
| --- | --- | --- |
| `.` (root) | 617 pass, 0 fail (175 top-level) | 618 pass, 0 fail (176 top-level). Only in base: `TestSystemOverviewAuthorityHeadersFollowRepoHierarchy`. Only in head: `TestAuthorityOrderGuardFindsEachFormOfRank`, `TestAuthorityOrderIsStatedOnlyInAgents`. No verdict change. |
| `./internal/testutil` | not run (unchanged by the PR) | 6 pass |
| `./es/admission/...` guards that read every test file of the module | not run | `TestOperationalGuardReadsUnadjustedPositions` and `TestReliableSubmitPrivatePersistenceStaticGuardrails` pass (23 with subtests). They parse the new guard file and the changed `docs_contract_test.go`. |
| `./scripts` | 2079 pass, 251 fail (38 top-level), 13 skip | identical: the same 38 top-level failures by name, no verdict change |

- **The 38 `./scripts` failures are environment failures.** This container has no `ip` or `ssh`, and the run is as root. They are the same names on both trees, and the same counts as writer report 07 (2079/251/13).
- **Static checks:** `go vet .` clean; `gofmt -l` clean on the three changed Go files; `git diff --check` clean.
- **Probes** (`08-evidence/probe08-tip.tsv`, test source `zz_audit08_probe_test.go.txt`): 52 of 52 as expected.
- **Probe reruns.**
  - Audit 04's and audit 06's probe files at the head: byte-identical to the writer's 07 outputs.
  - Audit 06's anchor probe: 0 of 1,025 refused.
  - Audit 06's wide sweep: 173 sentences (164 at `61db96c`).
    - Gone: the A06-1 bullet; two hits whose only relation word came from an anchor slug (`#nomad-access-control`, `#nomad-https`), dropped by the restored cut; and three `v1_bringup.md` hits.
    - New: 15 hits from #65's runbook text and renamed files (Delta section).
- **Mutants** (`08-evidence/audit08_mutants.py`, output `mutants08.out`). Each is applied with a hard reset, a clean and `git add -A`, and the whole root package runs each time. Unmutated: 176 top-level pass.

| Mutant | Failing tests |
| --- | --- |
| M1 anchor cut removed | `TestAuthorityOrderGuardFindsEachFormOfRank` |
| M2 A06-1 bullet restored in place | `TestAuthorityOrderIsStatedOnlyInAgents` |
| M3 "factual source" rule deleted | `TestAuthorityOrderGuardFindsEachFormOfRank` |
| M4 `AGENTS.md:34` back to its `61db96c` text | `TestAuthorityOrderIsStatedOnlyInAgents` |
| M5 `AGENTS.md:34` loses only the closed-record exception | `TestAuthorityOrderIsStatedOnlyInAgents` |
| M6 §6 sentence restored (predicted: none, a stated gap) | none |
| M7 A06-1 bullet inserted in `shared_kernel.md` | `TestAuthorityOrderIsStatedOnlyInAgents` |
| M8 the ordinary anchor example deleted (predicted: none) | none |

- **Not re-run:** macOS (CI only); the writer's mutant sets (reasoned above).

## CI on the head

I read the final state on head `dd30aca` from the GitHub Actions job records and the Linux job log, at 2026-11-25 23:52Z. Both required checks passed on the audited head:

- **"test on macOS"** (run 45718085886, job 139569317331): **success**, 23:02:05-23:32:30Z.
- **"build, vet and test"** (run 45718085856, job 139569307369): **success**, 23:02:03-23:47:44Z.
  - Every step succeeded.
  - "Test": "test gate passed: 49 packages, 3 of them with skipped entries (17 entries); 14 tests skipped themselves, all of them listed".
  - es/app: "the observed run passed; go test skipped exactly the listed tests of this package (3), each once".
  - "Listed tests still fail": "all 17 listed tests still fail on this host, each in a run of its own and in the run of its package".
  - "Listed tests pass as root": "tests as root passed: 9 of execution-substrate/scripts".
- PR #64 at the time of that read: head `dd30aca7…`, base `389ecf66…`, `mergeable_state` "clean", still a draft.
- `git ls-remote` just before publication: trunk_dev `389ecf66…`, branch `dd30aca7…`. Neither has moved.

## Method notes

- **Probe and sweep files.** `zz_audit08_probe_test.go`, `zz_audit08_sweep_test.go`, and audit 04's and 06's probe, anchor and sweep files were copied into a scratch clone of the head, run, and left there. They were never placed in the audit clone, and that clone was not touched beyond the provenance steps.
- **Mutants** ran in their own clone. It was reset and cleaned after each mutant, and `git status --porcelain` was empty at the end.

## Sensitive-material handling

I read and wrote no secrets. The repo is public. The audit touched only local clones in this container and this report folder.

## Remaining uncertainty and stop conditions

- **The §6 judgment** rests on reading `AGENTS.md:27` and `:29` with `evolution.md:7` and `:128` for "architectural boundaries" (marked Inference above).
- **O08-1** is a consistency question for the coordinator, not a defect by the block criteria.
- **Toolchain:** go1.26.5 here; CI uses `go-version-file: go.mod`, so also 1.26.5.

## Confidence

- **Provenance:** high. The manifest reproduced exactly, the double run was stable, the closing run equals the opening, the PR head is equal, and the merge was shown to be automatic.
- **Validation:** high for the root package, the guard and `./scripts`: rerun on exact bytes, compared by name with the base. macOS by CI.
- **Implementation:** high on four points:
  - the A06-1 sentence is gone and refused;
  - every stated limit matches the code and the probes;
  - the anchor cut is restored and pinned;
  - the merge left the PR's diff unchanged.
  The §6 deletion loses no claim, with the one inference noted.

## Effect status

No repair, commit, push, PR edit, comment or merge by this thread. Evidence files are beside this report (`08-evidence/`).

## Report delivery

`/mnt/project-files/reports/execution-substrate/docs-standalone/08-audit.md`, SHA-256 in the reply that delivers it.

Final verdict: ACCEPT
