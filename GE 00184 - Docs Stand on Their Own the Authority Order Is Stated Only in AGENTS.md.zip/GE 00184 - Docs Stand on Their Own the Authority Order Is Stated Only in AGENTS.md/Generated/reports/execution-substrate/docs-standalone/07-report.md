# ES docs stand on their own: writer report 07 (audit 06 repair)

Status: the repair is pushed to PR #64 (draft) and is waiting for a fresh re-audit. Written 2026-11-25 by the writer thread "Make ES docs stand on their own". Reports 01, 03 and 05 cover the earlier commits. This report covers the audit 06 repair and a base update.

## Brief

- **Audit 06** (`06-audit.md`, BLOCK) raised three lows:
  - A06-1: a rank remains in `evolution.md:35`.
  - A06-2: the guard's comment and `AGENTS.md` overstate what the test covers.
  - A06-3: removing the "#" anchor cut caused false positives on plain heading links.
- **The coordinator's repair request (2026-11-25 22:55Z):**
  - "A06-1: remove the rank in evolution.md:35 ('use code and tests as the factual source … when prose is stale'). Also sweep for 'stale', 'source of truth', 'factual source' and similar."
  - "A06-2: make the stated limits exact. Don't claim coverage of audits 02 and 04's probes; list what is caught and what is a known gap. Fix AGENTS.md:34 to say the closed record is excluded."
  - "A06-3: restore the #anchor cut and add a test for neutral heading links. Push, then hand back."

## Base update

`trunk_dev` moved while this round ran, from `ae9aa65` to `389ecf6` ("Runbooks: follow the project's runbook layout; rename the bring-up runbook (#65)"). `trunk_dev` requires an up-to-date branch, so I merged `origin/trunk_dev` into the branch with a merge commit. I did no rebase and no force-push.

- **The merge had no conflicts.** #65 and this PR both edit `.docs/execution_lifecycle/implementation.md`, `README.md` and `docs_contract_test.go`, but in different places.
- **The PR's change is the same as before the merge.** `git diff 389ecf6 dd30aca` and `git diff ae9aa65 6465e80` touch the same 32 paths, with the same totals (666 insertions, 281 deletions). For the three files both sides edit, the added and removed lines hash the same.
- **The guard passes on #65's text.** It reads #65's rewritten and renamed runbooks (for example `.runbooks/system/Governed Execution ES System Bring-Up.md`) and refuses nothing in them.
- **Report 05's follow-up 4 is closed.** That was the possible conflict with the runbook restructure.

## Identity

| Item | Value |
| --- | --- |
| Repo | evo-agi/Execution-Substrate |
| PR | https://github.com/evo-agi/Execution-Substrate/pull/64 (draft) |
| Branch | `claude/project-thread-8x4q85` |
| Base | `trunk_dev` `389ecf66bd8828fafc9591111f14628cb86ce7fb` (#65), the tip of `origin/trunk_dev` when the manifest was taken |
| Tip | `dd30aca7ff329452f3daf08cd187a9185723f13a`. Commits on the branch: `aecb180`, `a0dc3c9`, `61db96c`, then `6465e80` (this repair) and `dd30aca` (merge of `trunk_dev`). |
| Tip tree | `ce8e199ab39cf259bdf62a9f5fe1d20976463ee5` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`. I checked it before the run, on the project file and on the copy that ran. |
| Textual diff SHA-256 | `a1877e1257644e60ef9fb4b60273d12d272679be1c1814931428e1dc897b3cb3` |
| Canonical manifest SHA-256 | `b08d3f14dd312d0e4a64bb6285662ea6821d17256a485b46ed2a34ca2d6b3d71` |
| File count | 32: 31 modified, plus 1 new file (`authority_order_docs_contract_test.go`), recorded as `untracked` |
| Full manifest | `07-expected-manifest.json`, beside this report. Its file SHA-256 equals the canonical hash. |

**How the manifest was taken.** This is the provenance §5.3 form, against the new base:
1. On the branch, `git reset --mixed 389ecf6`.
2. Pin the upstream to `origin/trunk_dev`.
3. Run v2 twice, to two absent paths in a fresh mode-0700 directory. The outputs were byte-identical.
4. `git reset --mixed dd30aca`. `git status --porcelain` was empty.

The path set of `git diff --name-only --no-renames 389ecf6 dd30aca` equals the manifest's path set. Before the merge I also took a manifest of `6465e80` against `ae9aa65`: 32 files, canonical SHA-256 `10ead03e2461c29b9aa3810a00c3d7ba1d46ddb65d6faf7254c887f30f469e20`. It is not the audit target.

## What the repair changed (`6465e80`, 3 files)

1. **A06-1: the evolution.md rank is gone.**
   - "- use code and tests as the factual source of current behavior when prose is stale" is deleted from "How to tell the difference". The two bullets above it stay. They say which document owns a question.
   - **The coordinator's sweep found one more of the same kind.** The sweep used the guard's own sentence splitter over every Markdown file the guard reads, looking for "stale", "source of truth", "factual source", "ground truth", "canonical source", "authoritative source", "prose", "out of date", "outdated" and "drift". It found `evolution.md` §6's "Code may confirm current behavior. It must not become the design source of truth for cross-service contracts or architectural boundaries." That restates `AGENTS.md` §3's "Do not treat code as design authority for cross-service behavior", and the doc-first rule at the top of `evolution.md` ("code must not be the first place a system contract, boundary, lifecycle rule, or shared-kernel decision appears"). It is deleted too. Audit 06 had listed it under O06-4 as a sentence the coordinator might want handled together with A06-1.
   - **The other sweep hits are not ranks.** They are 94 "stale" uses about revisions, cuts and handles, and topic or system facts: "Nomad is the source of truth for its lifecycle", "the readiness source of truth", "this runbook … is not the source of truth for ES core contracts" (what the doc does not govern), and "If explanatory prose is ambiguous, this record governs." (a record's own JSON over its own prose). No test pinned either deleted sentence.
   - **The guard now refuses the first form.** A new rule, "factual source", has its own sole example, and the removed bullet is listed under "Forms this PR removed". The second form has no file of the order in either of its sentences, so the guard cannot see it; the comment lists it as a gap.
2. **A06-2: the stated limits are exact.**
   - **The guard's comment.** It says the guard reads every git-listed Markdown file except `AGENTS.md` and the closed plan record. It says the list covers what the self-test refuses:
     - the removed forms it lists;
     - audit 02's P1 to P14;
     - audit 04's 14 listed cases;
     - one example per vocabulary word;
     - and, of audit 04's other probes, N05, N20, N29, N31 and N34.
   - **The comment then lists the known gaps by probe:**
     - N12, N13, N14, N19, N22, N23, N25, N26, N27, N28, N32 and N33 (words outside the vocabulary);
     - audit 06's O06-2 near variants;
     - N16 (two sentences or a pronoun);
     - N17 and N08 (links);
     - N15 (an abbreviation cut);
     - N18 (a curly apostrophe);
     - the two `evolution.md` sentences this PR removed that pass.
   - It also names the known false positives: fenced code, and rule words used for something else, as in O04-1 and O06-1.
   - **I checked every listed status.** I reran the probe files from audits 04 and 06 at the tip (`07-probe04-out.tsv`, `07-probe06-out.tsv`). Every probe the comment calls a gap passes. Every probe it calls covered is refused.
   - **`AGENTS.md` §3** now reads: "A repository test refuses a list of known wordings of a rank in the other Markdown files, except the closed record `.docs/history/plans-record.md`. It is a regression backstop for those wordings, not a complete check: review is what keeps other documents to the rule above." The guard test pins the new text.
3. **A06-3: the anchor cut is back.**
   - `normalizeAuthorityText` drops a link target's "#" anchor again before appending the target, and its comment says why: a heading slug is not prose.
   - An ordinary self-test example pins it: "See [the section](.docs/execution_lifecycle/reliable_submit_operational_handoff.md#1-status-and-precedence) for details." It must pass.
   - Audit 06's anchor probe, a neutral link to each heading in the git-listed Markdown files, now refuses 0, against 3 at `61db96c`. Its F-anchor probes pass.

## Validation

All runs used committed bytes in clean detached worktrees: base `389ecf6` (the new `trunk_dev`) and head `dd30aca`. The setup was `umask 022`, run as root, with SIGHUP/SIGINT/SIGQUIT reset to default, `go test -count=1 -json -timeout 40m <pkg>`, and go1.26.5 linux/amd64. Results are compared by test name.

| Package | Base `389ecf6` | Head `dd30aca` |
| --- | --- | --- |
| `.` (root) | 617 pass, 0 fail | 618 pass, 0 fail. Only in base: `TestSystemOverviewAuthorityHeadersFollowRepoHierarchy`. Only in head: `TestAuthorityOrderIsStatedOnlyInAgents`, `TestAuthorityOrderGuardFindsEachFormOfRank` |
| `./internal/testutil` | 6 pass | 6 pass |
| `./scripts` | 2079 pass, 251 fail (38 top-level), 13 skip | identical: the same 38 top-level failures by name |

- **No verdict changes.** No test common to both trees changed its result in any package. The 38 `./scripts` failures are the environment failures of the earlier reports. They come from a root run without `ip`, `ssh` and the rest; audits 04 and 06 saw 9 in their non-root setup.
- **Static checks.** `go vet .` is clean. `gofmt -l` lists none of the three changed Go files. `git diff --check 389ecf6 dd30aca` is clean.
- **Vocabulary mutants.** `07-alt-mutants.py` (SHA-256 `e434b1cb2ca6f6e8b9547c0bb695ed3d6a9fde31d9a80896c43bf14b4ee801b8`) is report 05's adaptation of audit 04's tool, with the anchor-cut mutant added back. It ran on a clean worktree of `dd30aca`, with the whole root package run for each mutant. **84 of 84 were caught, 0 survived.** The unmutated tree passes. Output: `07-alt-mutants.out`.
- **Writer mutants.** `07-mutants.py` (SHA-256 `787cd9f0cc75bd857cddc29b15211190a13020203e363968799073bbb5a590c0`) ran with a hard reset, clean and `git add -A` for each mutant, and the whole root package each time. **88 of 88 were caught.** The unmutated tree passes. Output: `07-mutants.out`. They are report 05's 84, adapted, plus four new ones:
  - A4: the `AGENTS.md` limit loses its closed-record exception.
  - R12: the `evolution.md` "factual source" bullet is restored.
  - G5: the anchor is kept in link targets.
  - The "factual source" rule is deleted.
- **Probe reruns at `dd30aca`.**
  - Audit 04's probe file: `07-probe04-out.tsv`. 18 rank probes refused: N01-N07, N09-N11, N20, N21, N24, N29-N31, N34, N35. 17 pass: N08, N12-N19, N22, N23, N25-N28, N32, N33. The comment lists each pass as a gap.
  - Audit 06's probe file: `07-probe06-out.tsv`. Every L and LC case is refused. The G and V probes match the comment's gap list; "e.g." and "have priority" happen to be refused. The four F-anchor probes now pass.
  - Audit 06's anchor probe: 1025 headings (#65 added some), **0 refused**.
- **CI** on `dd30aca`: "build, vet and test" and "test on macOS" were running when this report was written.

## Assumptions, guesses and non-claims

- **Deleting the §6 sentence was my call.** The coordinator asked for a sweep, not for that sentence by name. **Inference:** it restates a rule `AGENTS.md` §3 holds, which is the class A06-1 removes. If the coordinator reads it as change governance, restoring the one line is the whole revert.
- The guard is a regression backstop, as its comment and `AGENTS.md` say. Audit 06's observations O06-1 (false-positive exposure), O06-3 (fenced code) and O06-5 (rank wording in a Go comment, outside Markdown) are unchanged. The coordinator did not ask for them.

## Follow-ups (for the coordinator)

1. Ordinary `PLANS.md` mentions in docs.
2. The two standing-rule sections still in `PLANS.md`.
3. Other line citations in the claim ledger.

## Confidence

- Provenance: high.
- Implementation: high that the A06-1 sentence and the swept §6 sentence are gone, that the comment's caught and gap lists match the probe reruns, that `AGENTS.md` names the excluded record, and that the anchor cut is back and pinned.
