Audit 06 (/mnt/project-files/reports/execution-substrate/docs-standalone/06-audit.md) is BLOCK, with three Lows, all small.
- A06-1: remove the rank in evolution.md:35 ("use code and tests as the factual source … when prose is stale"). Also sweep for "stale", "source of truth", "factual source" and similar.
- A06-2: make the stated limits exact. Don't claim coverage of audits 02 and 04's probes; list what is caught and what is a known gap. Fix AGENTS.md:34 to say the closed record is excluded.
- A06-3: restore the #anchor cut and add a test for neutral heading links.
Push, then hand back.
