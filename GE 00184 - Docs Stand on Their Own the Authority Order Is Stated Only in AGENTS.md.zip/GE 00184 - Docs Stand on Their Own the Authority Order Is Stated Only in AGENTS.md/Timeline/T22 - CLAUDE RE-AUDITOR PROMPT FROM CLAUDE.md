You are a fresh, independent, read-only re-auditor (audit 04) of evo-agi/Execution-Substrate draft PR #64, which is docs and tests only. Do not edit it. Follow /mnt/project-files/operating-protocol/ (the protocol and provenance-and-audit-evidence.md). Read project-context/INDEX.md first. Verify the v2 recipe hash before you run it.

Intent: David's attached messages, plus the approved plan. Under that plan each doc stands alone and says nothing about who outranks whom. The authority order, including the precedence of code and tests, is stated once, in AGENTS.md §3. PLANS.md holds intent and order only, and its opening names the standing-rule files. Ordinary mentions of PLANS.md are out of scope.

Prior audit: /mnt/project-files/reports/execution-substrate/docs-standalone/02-audit.md. It found A02-1 (medium, rank sentences left in the tree), A02-2 (the route-records rank was lost), A02-3 (the guard was too narrow), and A02-4 (wrong heading rationale). Writer repair report: 03-report.md (sha 5904ee0e…d837), with 03-* evidence beside it.

PR facts to check yourself:
- head a0dc3c96234fb4081fe7b5da74883d3b3e5e50f6, tree b405c53b…, base ae9aa65;
- canonical manifest a28faa02…9ae4, 29 files;
- writer reports root 618/0, the same 38 script environment failures, and 55/55 mutants.

Review the full PR (base..head) and confirm each A02 finding is closed. Check that no authority claim was lost or changed. Probe the guard with your own wordings for both false negatives and false positives. Check CI on the head, including both required checks. Write 04-audit.md in that folder (ACCEPT, or findings with failing test names) and reply with the verdict. Use Opus.
