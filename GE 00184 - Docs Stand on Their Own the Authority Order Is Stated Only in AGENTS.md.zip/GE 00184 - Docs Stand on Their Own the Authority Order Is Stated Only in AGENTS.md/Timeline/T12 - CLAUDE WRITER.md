The docs cleanup is up as [draft PR #64](https://github.com/evo-agi/Execution-Substrate/pull/64). The authority order is now stated only in AGENTS.md, which also says that no other doc restates it. 16 docs lost their copy of the order, and 6 files lost sentences restating a file's rank. PLANS.md's opening now names the two standing rule files (A08-2).

The tests that required the copies are gone. A new guard refuses any copy that comes back. I tried 12 ways of breaking it, and the intended test caught each one.

Following the coordinator's reading of your plan, ordinary mentions like "reopened in PLANS.md" stay. The PR lists them as a possible follow-up. Full test runs on old and new trees are still going, then the audit.

STATUS: WORKING (full test runs and CI on PR #64; next update when they finish, in about 30 to 45 minutes)
