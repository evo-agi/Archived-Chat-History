Re-audit 04 is BLOCK, with two Lows: /mnt/project-files/reports/execution-substrate/docs-standalone/04-audit.md.
- A04-1: remove the five "If code and tests disagree with this file, update this file to match reality" sentences. AGENTS.md §3 already covers that.
- A04-2: cover the exact cases the finding lists, including "takes priority over" and "section 3 of AGENTS.md". Don't chase every synonym, though. A vocabulary guard can't be complete, so state its limits honestly in its docstring and in the contract: it is a regression backstop for known wordings, and review remains the real check. Close the surviving mutants that correspond to the listed cases, and record which of the auditor's 88 stay out of scope and why.
Then hand back the new head.
