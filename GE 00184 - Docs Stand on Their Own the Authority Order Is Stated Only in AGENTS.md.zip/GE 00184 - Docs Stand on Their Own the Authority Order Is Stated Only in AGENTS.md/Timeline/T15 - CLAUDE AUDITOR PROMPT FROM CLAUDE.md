You are an independent, read-only correctness auditor for evo-agi/Execution-Substrate draft PR #64 (docs and tests only). Do not edit the PR. Follow the operating protocol and provenance-and-audit-evidence.md in /mnt/project-files/operating-protocol/. Read project-context/INDEX.md first. Verify the v2 recipe hash before you run it.

Intent: David's attached messages. The approved plan said: each doc stands on its own, and a contract says what it governs and nothing about the read order. The authority order is stated once, in AGENTS.md, and the copies and their test go. PLANS.md holds only intent and order. Also A08-2: the PLANS.md opening names the .docs/standing_rules/ files. Ordinary mentions of PLANS.md stay; they are out of scope.

PR facts from the writer (check them yourself): branch claude/project-thread-8x4q85, base trunk_dev ae9aa65322954be16d5d3e354dd0aeec5d87723d, tip aecb1808fa9b166d00f304905654c2b4fe09698f, tree e5539df2…, v2 canonical f893f1f6…bb7, 27 files. Report and evidence: /mnt/project-files/reports/execution-substrate/docs-standalone/ (01-report.md, 01-expected-manifest.json, 01-mutants.py, 01-scripts-failures.json). The writer claims root tests go from 617 to 618, all passing; script tests show the same 38 failures by name on base and head; 12 of 12 mutants are caught.

Check:
- that no authority claim is lost or changed;
- that the new guard is sound;
- that the README "Read these in order" list is acceptable as navigation;
- CI on the tip, including the required checks "build, vet and test" and "test on macOS".

Write a verdict (ACCEPT, or blocking findings with failing test names) into that reports folder as 02-audit.md and reply with it. Use Opus.
