I mean, even if we don't use Fable for the remaining ~14%, are we moving too slow? I don't mind if we do more and burn through the rest by end of day.
