Yes, at about 1% an hour we're leaving quota unused before the reset. I'm starting two docs-only jobs on Opus beside PR 63, which turns into the gossip-encryption PR once it merges. Fable stays saved for Thursday's red-teams.

STATUS: WORKING (PR 63; two docs jobs starting; I'll check pace again around 6 PM)
