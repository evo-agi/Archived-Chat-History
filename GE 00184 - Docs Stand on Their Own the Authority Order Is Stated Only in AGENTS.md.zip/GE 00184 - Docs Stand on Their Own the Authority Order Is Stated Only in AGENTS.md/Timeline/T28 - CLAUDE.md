The docs cleanup ([PR 64](https://github.com/evo-agi/Execution-Substrate/pull/64)) has its second round of fixes in, and a fresh check is starting.
