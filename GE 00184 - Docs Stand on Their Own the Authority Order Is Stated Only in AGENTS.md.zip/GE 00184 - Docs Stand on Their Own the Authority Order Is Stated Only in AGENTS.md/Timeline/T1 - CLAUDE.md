Added to the backlog. Happy to talk it out. Here's my view.

Those references are left over from how Codex was set up. AGENTS.md lists an authority order, with PLANS.md ranked second. That order was then copied into about 11 docs, and a test checks that the copies match. So every doc points back at PLANS.md and AGENTS.md mostly to repeat who outranks whom, not because it needs either file.

I'd simplify it:
- **Each doc stands on its own.** A contract says what it governs and nothing about the read order.
- **The authority order lives in one place,** in AGENTS.md, which is the file agents read first anyway. The copies and their test go.
- **PLANS.md holds only intent and order:** what we're doing next and why, not rules.

PR 56 still helps, since it gets the rules out of PLANS.md, so I'd let it merge and do this cleanup after it. What part was confusing you most?

STATUS: WORKING (PR 56 audit; Wi-Fi scripts fix)
