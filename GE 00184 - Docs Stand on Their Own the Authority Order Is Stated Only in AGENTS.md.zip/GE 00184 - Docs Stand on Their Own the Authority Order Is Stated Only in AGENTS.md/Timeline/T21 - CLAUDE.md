The docs cleanup ([PR 64](https://github.com/evo-agi/Execution-Substrate/pull/64)) has its audit fixes in, and a fresh re-audit is starting.
