Audit 02 is BLOCK: /mnt/project-files/reports/execution-substrate/docs-standalone/02-audit.md. Please fix all four findings in this PR.
- A02-1: remove the remaining rank sentences, in evolution.md:71, the PLANS.md record sentence plus the test that pins it, and the two in README. Then make the rule and the tree agree. Following the approved plan, a doc says nothing about who outranks whom, so the "code and tests win over this doc" sentences go too. Make sure AGENTS.md §3 covers that precedence once.
- A02-2: move the rank that puts route-specific .docs/ records below system_overview into AGENTS.md §3. Don't drop it.
- A02-3: make the guard catch rank statements by meaning (for example "controls", "wins", "outranks", "authority", "§3" references outside AGENTS.md), with a narrow allowlist. Prune the dead phrases. Add the auditor's 14 probes as mutants.
- A02-4: correct the stated reason for keeping the headings, or rename headings that no longer talk about authority.
Then hand back the new head. The re-audit runs in a fresh thread.
