Two threads are actively working right now: [Make ES docs stand on their own](#cmsg_01Un4xQgjBAczV8DABQvcLrxRjWFPgxJKEeQ7Hae1ATneS) and [Restructure ES runbooks to house style](#cmsg_01Un4xQgjBAczV8DABQvcLrxB8QKE7xRMW8teBcjWYeN9K).

The upgrade-script guard, [PR 63](https://github.com/evo-agi/Execution-Substrate/pull/63), is pushed with its latest audit fixes. It's waiting on Linux and macOS CI, which takes about an hour, and then gets a fresh audit. Everything else is finished, paused for quota, or waiting on the reset.

STATUS: WORKING (two docs threads; PR 63 CI then audit)
