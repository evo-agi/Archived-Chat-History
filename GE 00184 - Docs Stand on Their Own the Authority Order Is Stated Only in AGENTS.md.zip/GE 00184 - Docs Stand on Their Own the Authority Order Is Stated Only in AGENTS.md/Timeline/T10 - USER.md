So what threads are actually doing work right now?
