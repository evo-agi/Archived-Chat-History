The docs cleanup is up as [PR 64](https://github.com/evo-agi/Execution-Substrate/pull/64), and its independent audit is starting.
