The docs cleanup ([PR 64](https://github.com/evo-agi/Execution-Substrate/pull/64)) has its third round of small fixes in, and a fresh check is starting.
