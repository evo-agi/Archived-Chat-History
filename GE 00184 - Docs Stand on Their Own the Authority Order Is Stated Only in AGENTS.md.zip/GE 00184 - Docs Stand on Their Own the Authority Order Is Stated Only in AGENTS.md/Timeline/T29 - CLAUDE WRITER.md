I fixed both audit 04 findings on [PR #64](https://github.com/evo-agi/Execution-Substrate/pull/64). The new head is waiting for a fresh re-audit.

- **A04-1:** the five "if code and tests disagree with this file, update it" lines are gone.
- **A04-2:** the guard now refuses all 14 wordings the auditor listed. Its comment and `AGENTS.md` now say it only catches known wordings and that review is the real check.

Of the auditor's 88 test breakages, one stays out of scope: "control the <file>", because it's too common in ordinary prose. Tests match the base. Details are in [05-report.md](/mnt/project-files/reports/execution-substrate/docs-standalone/05-report.md).

STATUS: WAITING (fresh re-audit, then the gate; nothing needed from you)
