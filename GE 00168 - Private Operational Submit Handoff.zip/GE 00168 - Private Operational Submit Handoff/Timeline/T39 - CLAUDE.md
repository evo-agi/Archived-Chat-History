The PR 13 audit found no hole in the fix itself. It's blocked because the tests miss two spots and one compatibility note lacks a removal condition, and those repairs come next.

One design choice needs you, for this unwired proof:
1. **What "current admission" means.** Recommended: the trust and policy snapshot taken when the process starts, plus a local off switch, documented plainly. The catch is that a revocation only takes effect after a restart. We revisit this once real wiring exists.
2. **The old v1 format.** Recommended: keep it read-only for now and remove it before the first real install. Deleting it now would widen the repair.

Reply "agree" to take both recommendations, or answer on the card in the audit thread.

STATUS: NEEDS DAVID (agree with both recommendations?)
