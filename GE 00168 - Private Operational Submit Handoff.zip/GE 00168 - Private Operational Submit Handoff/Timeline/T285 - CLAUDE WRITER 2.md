The audit check passed with nothing to fix, so I moved PR #12's branch forward to include all of PR #40's repairs, and GitHub has closed #40 as merged. The next PR #12 round starts after PR #31 lands: it takes in the newest trunk_dev and adds ES's Nomad token on the three private requests. After that comes a final red-team check.

STATUS: WAITING (PR #31)
