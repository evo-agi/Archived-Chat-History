Two repair threads (PR 13's post-red-team batch and the maintenance agent's fifth repair) hit the Fable limit, so they're continuing on Opus from their pushed work.

STATUS: WORKING (PR 13 and MA repairs on Opus, PR 19 re-audit; nothing needed from you)
