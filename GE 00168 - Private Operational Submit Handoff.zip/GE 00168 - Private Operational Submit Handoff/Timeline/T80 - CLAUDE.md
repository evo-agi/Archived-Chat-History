PR 13's second repair is in, closing the guard gap, so I'm starting its fresh audit.

STATUS: WORKING (PR 13 audit, MA audit, CI self-check fix)
