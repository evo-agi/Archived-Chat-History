FYI, we have burnt through ~60% of our Fables allowance, and the next reset is ~4 days away. You may want to budget it, though, if we really need Fables for the current task(s), then never mind.
