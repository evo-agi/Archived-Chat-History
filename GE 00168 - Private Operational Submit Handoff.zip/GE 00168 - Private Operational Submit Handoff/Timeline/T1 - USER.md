Hmm... Before we start, how comfortable are you, if you are allowed to, with performing pen test and adversarial testing, besides the audits?
