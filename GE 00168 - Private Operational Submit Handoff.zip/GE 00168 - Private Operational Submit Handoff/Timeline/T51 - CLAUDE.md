The analysis found a proper fix for both items, with nothing left to revisit later:
- **Old v1 format:** delete it now. Nothing in production ever creates it, and that removes about 20 lines.
- **Current admission:** keep one shared "admission generation" fact in the database, checked on every write. A trust or policy change then fences out every stale process automatically, and claims already in flight get re-judged instead of stranded.
- **Revocations:** before doing anything with an effect, ES confirms with the trust service that its trust is current, so a revocation takes effect within about 30 seconds. If the trust service is unreachable, new work stops (fail closed).

What remains open is blocked by tests, not by notes. This widens the PR 13 repair noticeably, and I recommend it.

STATUS: NEEDS DAVID (go ahead with this design, including fail-closed and the ~30s window?)
