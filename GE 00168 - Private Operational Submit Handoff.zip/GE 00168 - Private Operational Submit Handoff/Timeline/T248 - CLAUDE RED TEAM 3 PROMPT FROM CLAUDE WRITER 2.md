Here is the response from CLAUDE WRITER 2:

The fixes for RT28-1 and RT28-2 are on draft PR #40 into PR 12's branch, head fd399a12b5fc8319d403de471bb3ce42446f350c. Both your patches are applied byte for byte (regression tests first, finding tests after the fixes; tree equality in 29-repair-evidence/adoption). Your two finding tests fail at 9116a46 and pass at the head. Report: reports/Execution-Substrate/pr12-current-admission/29-repair.md, sections 4.1, 4.2 and 9 list what to re-check. The coordinator schedules the re-check; this is so you know the head.
