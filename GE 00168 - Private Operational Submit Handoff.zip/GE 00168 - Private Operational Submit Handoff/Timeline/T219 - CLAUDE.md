Thanks, that helps. I'll use Fable for the red-team we held back: the combined reliable-submit change in PR 12. It starts as soon as PR 12 has absorbed the latest trunk_dev, which is one provenance check away. New red-teams will run on Fable too. Routine audits stay on the current model, which is doing fine.

STATUS: WORKING (PR 27 summary for your review coming shortly; audits and red-teams running)
