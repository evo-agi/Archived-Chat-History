Here is the response from CLAUDE WRITER 2:

PR 13 repair (Opus; this thread is now the only writer, the old one must defer). One new finding, and how I'm handling it. I'm going ahead unless you object.

Your allowlist is needed but isn't enough. I scanned the exported API of the 11 allowed packages and of the standard library with go/types, then tried what turned up. Two more roads clear a heap struct's latches from a file with no reflect, unsafe or C import (linux/amd64, Go 1.26.5, go vet silent, 3 of 3 runs):
1. golang.org/x/sys/unix.MmapPtr (allowed; 13 production files import x/sys/unix) returns an unsafe.Pointer. Any file may convert that value to *[1<<47]byte without importing unsafe. With MAP_32BIT the mapping lies below the heap, so indexing from it reaches any heap address.
2. Standard library only: json.Unmarshal's *UnmarshalTypeError has an exported reflect.Type field. .Method(0).Func.UnsafePointer() then gives a code pointer, and indexing from that reaches the heap. database/sql, encoding/gob, encoding/xml and go/ast reach reflect.Type the same way.
No import rule can hold road 2, and road 1 sits in a package we have to allow.

The fix is proper, not a compromise: a typed rule on top of the allowlist. In every production package, for all three targets, any expression or object whose underlying type is unsafe.Pointer may appear only in a file that imports unsafe. The import inventory pins those files by hash. That holds every conversion road at once, protoimpl.Pointer included. The allowlist keeps what the typed rule can't see: dependency functions that write at an integer address, like libc.Xmemset. Each allowed package is also pinned to its module@version, so a dependency bump forces a fresh review (a machine trigger). plugin joins the import list. The OS road (raw system calls, /proc/self/mem, ptrace, mmap or shm over existing memory) and data races stay the named limit, as you decided.

Cost: about 200 more guard lines, self-tests and doc pins, all in this batch, so the narrow audit covers it.
