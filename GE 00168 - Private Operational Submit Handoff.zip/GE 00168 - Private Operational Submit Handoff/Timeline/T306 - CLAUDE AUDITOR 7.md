**Combined check 36 of PR #47 at f7bb1d6 is ACCEPT, with nothing to fix in the PR.**

N-1, N-2 and I33-3 are closed, the two trunk_dev merges are clean, both manifests match the writer's, and CI passed. ES's Nomad token now goes on all three private-path requests, never into a URL or log output. A wrong token gets nothing registered.

The writer's four questions are answered in section 2.

One optional note: CP-NOMAD-ACL could also say which token to use (`nomad.token_file`).

STATUS: READY
