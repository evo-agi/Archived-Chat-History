O7-1 is fixed in its own draft PR to trunk_dev, [PR #26](https://github.com/evo-agi/Execution-Substrate/pull/26), and it's ready for audit. I've also updated the PR #12 merge plan now that PR #22 has landed.

**PR #26 (one test file, commit `bcfb6da` on trunk_dev `792f17c`)**
- The two exceptions in the Workstream A guard were decided by the text of the line, so a comment could make anything pass. The Publication exception had the same problem as the PolicyDecision one.
- They now check the actual code:
  - PolicyDecision is allowed only in its three named identifiers in `es/admission/policy.go`.
  - Publication is allowed only in the name and tag of the one ignored field of `signedRuntimeTrustResponse` in `es/admission/service.go`.
- The new rule allows exactly the same 21 occurrences as the old one, both on trunk_dev and on PR #13's tip.
- Five planted probes pass the guard on trunk_dev and fail with the fix. All 13 mutants were caught.
- `es/admission` passes, with no shared result changed. Build and vet are clean for all three targets.
- The manifest is `49ff0a0d…0c15` (1 file). CI is running, and I'm watching the PR.

**PR #12's merge with trunk_dev at `792f17c`**
- PR #22's two `fset.Position` reads now go into the follow-up commit as `PositionFor(…, false)`.
- That makes 55 paths, so the patch reconciles both new paths in the owner document, with pins.
- On the trial merge:
  - Build and vet are clean.
  - `es/admission` passes all 2,463 tests.
  - The root package shows only the known environment failures.
  - PR #22's tests pass with the changed reads.
- If PR #26 lands first, PR #12's merge also has to resolve two small conflict blocks in the Workstream A file. I tested that too: 2,480 pass and no new path.

STATUS: WAITING (audit of PR #26 and CI; narrow re-audit of `e060449`)
