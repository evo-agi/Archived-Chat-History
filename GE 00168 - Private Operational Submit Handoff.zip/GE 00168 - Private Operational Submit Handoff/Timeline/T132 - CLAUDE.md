PR 13's post-red-team repair is pushed, including fixes for two new memory-safety bypasses it found, so it goes to a narrow fresh audit.

STATUS: WORKING (nothing needed from you)
