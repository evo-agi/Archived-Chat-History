One part of this red-team is blocked. A safety check on my side stopped the work on evading the raw-memory guard (the `//line` roads, aliases, build tags, generated code), and I will not retry it. That part of the brief stays uncovered by this thread, so it needs another route before PR 12's merge gate.

Head verified: commit `4416699`, tree `052d1024`, as in reports 26 and 27. I am continuing with the admission recheck, durable progress and replay, lock contention, fuzzing, and the three Nomad requests.

STATUS: WORKING (behavioural attacks on PR 12 at 4416699; next update with 28-redteam.md, by about 23:30 UTC)
