PR 12 is back in sync with trunk_dev, so I'm starting its Fable red-team of the combined reliable-submit change.
