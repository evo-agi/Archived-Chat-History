PR 13, the core submit fix, passed its audit, so its red-team starts now.

STATUS: WORKING (nothing needed tonight)
