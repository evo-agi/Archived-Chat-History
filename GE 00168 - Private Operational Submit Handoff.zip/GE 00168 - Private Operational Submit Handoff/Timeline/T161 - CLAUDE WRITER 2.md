PR 13 is merged into PR 12's branch as merge commit `6288b63`, with no squash and no force-push. The merge gate passed: the head was still the audited `e060449`, the base was unchanged, and all three manifests came out byte-identical to the audited ones. That branch has no CI workflow, so no CI ran on it.

The PR 12 merge with `trunk_dev` `036d507` is now built on a branch of this thread and open as draft [PR #28](https://github.com/evo-agi/Execution-Substrate/pull/28) into PR 12's branch, so CI runs on the merged tree. It has two commits: the merge, with only the two known resolutions, and the follow-up. Its tree is exactly the one I tested, and it has 56 paths. PR #28 is for the audit and CI only; it is not meant to be merged as a PR. PR 12's branch moves only by a fast-forward to it, after the audit and David's go.

M19-1 is fixed, and the plan and patch are updated:
- The follow-up now carries the two CI list lines itself.
- The reconciliation names all three paths and says 56 files, and new pins hold that.
- A check confirmed that the list check refuses each of the two lines on `trunk_dev` alone.

PR 26 round 2 is committed locally and still in validation; I'll report when it's done.

STATUS: WORKING
