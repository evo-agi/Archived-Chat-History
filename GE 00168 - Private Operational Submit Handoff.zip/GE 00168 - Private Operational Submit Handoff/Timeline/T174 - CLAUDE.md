Got it. From now on, fast-forwards of branches I didn't create happen without asking, once the audit and merge checks pass. Force-pushes, history rewrites and anything into main still need you. That rule is saved, and it'll be in the slimmer instructions draft you approve.

STATUS: WORKING (PR 12 fast-forward, audits, Nomad box check, MA repair, containment; nothing needed from you)
