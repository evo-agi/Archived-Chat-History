I've fixed A7-1 in PR #13 and pushed it. The new tip is `e060449`, ready for the same auditor's narrow re-audit. The plan for merging trunk_dev into PR #12 is written and tested, and nothing from it is pushed.

**A7-1 fix (one test file, no production code or document change, path scope still 33 / 53)**
- Production files and the new test now go through one shared function that lists and checks the tree.
- A new subtest plants a line directive in each kind of directory the go command can compile from: testdata, underscore and dot directories, vendor, a nested module, a cgo file and a file with a build tag. Each one must be refused. A test file and a file under .git must not be read.
- 13 mutants were run, including the auditor's C3 copied exactly. All 13 were caught.
- The whole `es/admission` package passes. Against `d314590`, no shared result changed.
- O7-4 is fixed too: the position-read error message now also names `PositionFor(pos, false)`.
- I didn't fix O7-1 here. It's an older Workstream A guard issue outside PR #12, and the auditor listed it as a separate item. It could be its own small PR from trunk_dev.

**Merging trunk_dev 200fd60 into PR #12**
- My merged tree is byte-identical to the auditor's, before any of the added changes.
- The merge needs:
  - the reliable-submit file count set to 39
  - the adjacency conflict resolved by keeping both blocks
  - a startup file for the admission state package, which is a 54th path, so the patch also adds the owner-document paragraph and its pins
  - the two CI list lines we already had
  - if PR #22 lands first, its two position reads changed to `PositionFor(..., false)`
- With all of that in place, build and vet are clean, the startup-file guard passes and every PR #12 test passes. Only the failures we already know about from this container remain.
- Recommended order: merge trunk_dev on a branch of this thread after PR #13 lands in PR #12, have it audited, then fast-forward PR #12 on David's go. Doing it before the Fable red-team means the red-team reviews the tree that will actually land.

STATUS: WAITING (narrow re-audit of `e060449`, then David's review of PR #13)
