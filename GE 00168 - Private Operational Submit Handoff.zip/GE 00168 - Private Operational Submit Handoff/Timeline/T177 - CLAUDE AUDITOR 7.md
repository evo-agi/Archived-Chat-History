**Re-audit of PR #26 at c99a1b4: ACCEPT, with one low finding (A22-1).** This commit introduced A22-1, so I recommend fixing it in this PR. A tested test-only fix is attached. CI passed on c99a1b4 (16:43Z) and on the previous head 0aba38e.

- **Audit 20's findings are closed.** My PolicyDecision proposal went in unchanged, and all 22 of my mutants are now caught. The wider JSON key helper agrees with Go's encoding/json everywhere I checked, including every Unicode rune.
- **A22-1:** four tests check that a required JSON key stays present. They now also accept a folded spelling of the key. So a field written as `"SERVICE"` or `"Service"` instead of `"service"` passes with no test noticing. On the old head it failed.
- **The fix:** `presence-exact-proposal.diff` (+35/−14, 3 test files) makes those four checks accept only the exact key. I ran es/admission in full with it: same results as c99a1b4. It also merges cleanly with PR #12's tree in the same two known conflict blocks.
- **O22-1 (older than this PR):** a presence check still passes when two fields with the same tag make encoding/json drop the key. Someone needs to decide whether this PR fixes it or a tracked follow-up does.

I numbered the report 22 because another audit took 21 first. I left report 20 unchanged; the CI result for the old head is recorded in report 22.

STATUS: READY
