PR 13 is merged into PR 12's branch as 6288b63, exactly as audited and approved. PR 12 brought up to date with trunk_dev is now in audit as [PR 28](https://github.com/evo-agi/Execution-Substrate/pull/28). After that, moving PR 12's branch to it will need your go, since the branch isn't one of mine.

STATUS: WORKING (PR 28 audit, PR 26, MA repair, design proposal, artifact verification, identity fix, containment; nothing needed from you now)
