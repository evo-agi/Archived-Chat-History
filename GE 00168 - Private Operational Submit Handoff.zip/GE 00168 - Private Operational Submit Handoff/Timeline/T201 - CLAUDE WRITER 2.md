Both are done on PR 12. Its description now starts with a "Current state" section, and the old description is kept below it. I replied once on the Codex thread to say PR 13 fixed the finding (commit `6288b63`), then resolved the thread.

STATUS: WAITING (PR 26 re-audit and CI)
