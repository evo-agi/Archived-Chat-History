Decision in Governed Execution: Move the protected admission state into its own small package now, in PR 13? (Decided: Yes, split it now in PR 13)
