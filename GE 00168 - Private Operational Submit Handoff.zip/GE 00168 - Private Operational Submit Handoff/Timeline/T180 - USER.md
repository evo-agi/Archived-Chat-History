> Got it. From now on, fast-forwards of branches I didn't create happen without asking, once the audit and merge checks pa…


Force pushes should already be blocked by rulesets. We only allow squash and merge from a PR, I think, especially in ES.
