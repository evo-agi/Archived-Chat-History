> On the rulesets: only main, trunk_dev and trunk_dev_secondary are protected. PR branches, including PR 12's, aren't, so …


Uh... Does it matter? Right now, it's just you and me.
