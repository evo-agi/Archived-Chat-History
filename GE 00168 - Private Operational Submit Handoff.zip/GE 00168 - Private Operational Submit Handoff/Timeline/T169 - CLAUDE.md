The audit accepted PR 12 brought up to date with trunk_dev ([PR 28](https://github.com/evo-agi/Execution-Substrate/pull/28)), with no findings. Moving PR 12's branch forward to it needs your go, because that branch isn't one of mine. It's a fast-forward only: no history rewritten and nothing lost. Should I go ahead?

STATUS: NEEDS DAVID (go for the PR 12 fast-forward; "go ahead" in the Nomad thread)
