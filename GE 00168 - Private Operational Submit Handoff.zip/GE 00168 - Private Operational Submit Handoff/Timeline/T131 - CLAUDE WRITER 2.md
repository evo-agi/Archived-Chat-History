The PR 13 repair batch is done and pushed: head `8e1f539` on [PR #13](https://github.com/evo-agi/Execution-Substrate/pull/13). The report is [14-repair.md](/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/14-repair.md).

- **RT2-1 is closed.** Dependencies must come from a reviewed list pinned to module@version, `plugin` joins the import inventory, and the red-team's test is now permanent.
- **Two new roads (R14-1, R14-2), as you asked.** `x/sys/unix.MmapPtr` and a standard-library-only route through `encoding/json` both reopened a withdrawn Service at `51d6d5f`, and the guard didn't see either. A new raw pointer rule refuses both, and their tests fail before the fix and pass after.
- **The rest of the batch is in:** raw syscalls are named in the OS limit, O5-1 is done, and all the red-team tests are adopted. That adds four test files, so the path ceiling goes from 48 to 52.
- **Validation:** 13 of 13 guard mutants caught. Full suite old against new: no result changed and 258 new results pass. Race is clean, and the v2 manifests are taken.
- **For whoever merges `trunk_dev` into PR #12:** PR #19 landed during my run. Merging it gives a conflict in `docs_contract_test.go`, but `51d6d5f` hits the same conflict, so it's not from this repair. Keeping both blocks resolves it and the tests pass.

Next is a narrow audit of `bff8dda..8e1f539`, then the Fable red-team (section 10).

STATUS: READY
