PR 13's third repair is in. It closes the guard gap by refusing any unlisted pattern by default, so I'm starting its fresh audit.

STATUS: WORKING (PR 13 audit, PR 18 small fix, CI and MA small fixes)
