Asked the project to choose an option

Move the protected admission state into its own small package now, in PR 13?

1. Yes, split it now in PR 13 (recommended): Production code and many tests change again. One more full audit follows, and the red-team then covers the final design. This is several times the work of a guard-only repair.
2. Guard repair only, split later: PR 13 closes the audit findings with test code only. A new commissioning gate row forces the split decision before the first production caller.

Why recommended: The coordinator asked for the split now. Integration is the next step, so it would be due then anyway, and doing it before the red-team avoids a second red-team. I am starting on it.
