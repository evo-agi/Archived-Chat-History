Right for trunk_dev and main: the rulesets protect those two. Inference from what's recorded: other branches, like PR 12's branch, aren't covered by a ruleset. That's why PR 13 could merge into it with a normal merge, and why "no force-push" still matters there as a rule we keep ourselves. I couldn't read the live settings from here, so I'll have the next ES thread confirm the exact ruleset and merge settings and report back.

STATUS: WORKING (nothing needed from you)
