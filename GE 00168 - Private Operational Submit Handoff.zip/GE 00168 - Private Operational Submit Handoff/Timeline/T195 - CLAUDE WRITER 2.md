I need your go to change PR 12 on GitHub. It's your pull request, so editing its description or replying on its review thread posts from your account. The tool refused to do it on the coordinator's say-so alone. The card above asks you; the draft of the new description is attached.

STATUS: NEEDS DAVID (PR 12 card). PR 26 is still waiting on its re-audit and CI.
