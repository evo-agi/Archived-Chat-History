> Not much, honestly. The risk isn't another person. It's one of my threads making a mistake, like a force-push that wipes…


Then please add it to the backlog. I'll look into it later, if I don't forget.
