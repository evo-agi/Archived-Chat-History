**There is a proper fix for both items, and neither needs a later revisit.** The full design is in [04-design-proper-admission.md](/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/04-design-proper-admission.md), verdict RECONNAISSANCE_READY. In plain words:

**1. The v1 branch: delete it now.** Nothing in production ever creates a v1 record (repo-validated at 8058561 and e544e0f), so the branch protects nothing. Deleting it is about 20 production lines (Guess). The audit's AF-5 then disappears instead of being documented, and a silent fallback in the encoder goes with it.

**2. Current admission: one durable fact in the database, not a private copy per process.** Today each ES process freezes its own copy of trust and policy, and stopping an old process is a manual step nothing checks. One existing test even lets the old process finish a claim after the "policy change". I propose a single "admission generation" row in the same SQLite store, checked under the writer lock at every step, the way key revocation is already checked there. Replacing trust or policy then fences every stale process automatically at its next write. No network call runs inside the writer.

**3. Stranded claims (AF-8): stop tying trust and policy changes to the epoch.** Inference, not probed: a new epoch makes every existing claim and receipt unreadable. With the generation, claims in flight are judged again. Those the new rules allow continue, and those they deny get a clear "denied" result.

**4. Promptness: a freshness check outside the writer.** Before any first-effect step the process confirms with EGS that its trust is still current, and every step checks a short deadline (30 seconds, a Guess). A published revocation stops new effects within that window. If EGS can't be reached, new effects stop.

What stays open is blocked by machines, not promises: a store trigger forbids changing the epoch, and an inventory test forbids any production caller of commissioning until a named prerequisite list is met.

**Cost** (Guess): 2 to 4 days including a fresh audit and red-team, against hours for the document-only path. It adds one table to schema 5, which is still unmerged, so this is the cheapest moment to do it.

**One finding outside this PR, on the live path.** On trunk_dev, ES reads the trust model from EGS only once, at startup (repo-validated, es/app/app.go:73 and es/admission/service.go:295-344 at ae326b0). A revocation published at EGS does nothing for ordinary Submit until ES restarts, and the signed trust data has no version or expiry. It needs its own decision, and section 13 of the report covers it.

Besides the choice on the card below, please confirm no reliable-submit test database was kept on the Mac or the Linux box, because amending schema 5 depends on that.

Effect status: reading only, nothing edited, pushed or run. Report SHA-256: `7ffda583d94909dfb3601068ea07289cf44cec40a8946a8b11a7e7793103398c`.

STATUS: NEEDS DAVID (pick the option on the card so the PR 13 repair can be briefed)
