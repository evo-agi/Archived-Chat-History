PR #28 passed CI. That is PR 12 plus PR 13 plus trunk_dev `036d507`, and this was the first full run of the merged tree on GitHub ([run](https://github.com/evo-agi/Execution-Substrate/actions/runs/45211082054)). It is ready for its narrow audit: the merge `f36911c`, the follow-up `2c8bf35` and the 56 paths. The plan's section 6 now records the result.

The ARS blob verification thread also trial-merged PR #29 into PR #28 cleanly, and nothing in PR #28 needs to change. Whichever of #29 and #12 lands second re-runs that thread's new guard. That is in the plan too.

After the audit, fast-forwarding PR 12's branch to PR #28's head still needs David's go.

STATUS: WAITING (narrow audit of PR #28; re-audit and CI of PR #26)
