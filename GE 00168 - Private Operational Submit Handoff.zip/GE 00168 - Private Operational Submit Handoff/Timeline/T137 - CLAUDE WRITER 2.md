The A6-1 correction is pushed and ready for the narrow re-audit by the same auditor. PR #13 is now at `d314590` (tree `d9ec2b9d…3b95`). The report is [16-repair.md](/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/16-repair.md) (sha256 `34dbdd4a…4f48`), with its evidence folder and archive alongside it.

**What changed (guard tests and documents only, no production code):**
- Every guard now reads the file's real position. That covers the raw pointer rule and 18 other position reads in three guard files.
- A test parses every test file in the repo and refuses any other way of reading a position.
- Every non-test Go file in the repo is now refused a `//line` or `/*line` directive. None had one.
- The auditor's three subtests are in, for both `es/admission` (darwin) and `es/runtimehelper` (linux). A further subtest kills the auditor's surviving B4 mutant.
- A new test puts a directive in every production file and shows that no raw pointer site and none of 227,655 typed references moves.
- I also added the two optional O6-1 subtests and the sentence for the documents.

**Found while fixing it:** a second guard could be fooled the same way. Workstream A's source-term guard passed a forbidden identifier at `8e1f539` with one `//line` comment, and fails it now. That guard predates PR #12, so this was an older gap. By reading the code, the binding-producer guard had the same gap (I did not probe it). The Workstream A fix touches one more test file, so PR #12's path ceiling goes from 52 to 53 files. I recorded that change in the owner document and pinned it there, the same way as the 48 to 52 change.

**Checks:**
- With the auditor's probes in place, the guard passes at `8e1f539` and refuses both at `d314590`.
- 16 of 16 mutants caught, including the auditor's A1 and B4.
- Full suite at `8e1f539` and at the new code: the same 131 failures, and no test changed its result. One `es/app` installer test now fails at both commits in this container; it passed in the earlier run of `8e1f539`, so I think something in the container changed (not investigated).
- Race detector clean.
- Trial merge with `trunk_dev` `df46164` gives only the known `docs_contract_test.go` conflict (keep both blocks).
- Manifests, against: the base, 33 files (`0e65b61e…`); `8e1f539`, 6 files (`015d2c6f…`); `bff8dda`, 11 files (`86dc961d…`); `trunk_dev`, 53 files (`ab665c18…`).

STATUS: READY
