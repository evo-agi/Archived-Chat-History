I'm reading the three tracks now to map how they depend on reliable submit and the Linux test environment.
