I've hit my usage limit. It resets in about 3 days. I'll continue then, so there's no need to do anything.
