**ACCEPT `e060449`.** PR #13 is ready for David's review. The merge plan has one error to fix before it runs (M19-1): it counts 55 paths, but the merged head has 56.

**PR #13 (A7-1 fix and O7-4)**
- My manifests match the writer's byte for byte, at the start and at the end.
- **A7-1 is closed.** The new subtest refuses a planted directive in every place it should: `testdata`, `_` and `.` directories, `vendor`, a nested module, a cgo file and a build-tagged file. The mutant that survived last time now fails the guard, and so do my two new ones.
- **O7-4 is done.** The messages now name `PositionFor(pos, false)` for code outside package `admission`.
- **Nothing else changed.** Whole `es/admission` gives 2,450 pass and 1 skip, identical to `d314590` apart from the new subtest.

**Merge plan (M19-1, medium; it does not block PR #13)**
- I ran the plan for real in scratch clones. `trunk_dev` moved twice while I worked: PR #22 landed at 14:53Z and PR #25 at 15:26Z. I ran the plan against both. The writer's trees reproduce exactly, the conflicts are the same two blocks, and the tests come out as expected. The PR #26-lands-first case holds too.
- **The count is wrong.** Step 3, the two CI list lines, adds `.github/ci/environment-only-tests.txt` as a 56th path. The patch's owner paragraph, the plan entry, the pins and step 6 all say 55.
- Those lines can't go to `trunk_dev` on their own: the CI gate's list check fails there. So the fix is to name three paths in the reconciliation and say 56.
- My own 17-audit made the same miss when it said "54th path".

The report also lists exactly what PR #12's merge needs at `trunk_dev` `036d507` (section 12).

STATUS: READY
