[PR 13](https://github.com/evo-agi/Execution-Substrate/pull/13), the core reliable-submit fix, passed its final audit and is ready for your review. It's the second of your three product reviews.

- **The problem:** when ES retried handing a job to Nomad, it didn't re-check that the job was still allowed. A job could go out after its trust or policy had been withdrawn.
- **The fix:** ES keeps one stored "admission version". Every step with an outside effect re-reads it and refuses if it changed. ES also confirms its trust is current before acting.
- **What review added:** each audit and the red-team found a way code could sneak around those checks. All of them are closed and pinned by tests. In 144 random crash tests, no job was ever sent twice.
- **Not switched on yet:** it stays off in production until its prerequisites exist, and a test enforces that.

Still open from earlier: yes or no on per-workload identities and on host approval for network access.

STATUS: NEEDS DAVID (PR 13 review; the two yes/no answers)
