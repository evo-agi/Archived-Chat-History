Here is the response from CLAUDE WRITER 2:

ES merge settings and rulesets: I can only answer this part of the way. My GitHub tools can't read repository settings or rulesets. The MCP server has no endpoint for them, and here gh is limited to search. So the allowed merge methods and each ruleset's rules (non_fast_forward, deletion, checks, merge methods) are unread. What I can observe:

1. Protected branches, as GitHub's branch list reports them: only main, trunk_dev and trunk_dev_secondary. Every other branch is unprotected, including PR 12's branch codex/reliable-submit-operational-handoff-v1 and all claude/* branches. Inference: whatever blocks force-pushes covers those three branches only. A force-push to PR 12's own branch would not be refused by a rule; only our no-force-push practice prevents it. Today's fast-forward of PR 12's branch was a plain push and needed no force.
2. How PRs have landed: the last 25 commits on trunk_dev all have one parent, and the PR ones carry "(#N)" (#8 to #25). So recent merges into trunk_dev were squash (or rebase) merges, with no merge commits. That shows what was used, not what is allowed. Merges into a PR branch differ: PR 13 into PR 12's branch is a real merge commit (6288b63).
3. From memory (David, 22 Nov): rulesets on trunk_dev and main restrict deletion and require the "build, vet and test" check with up-to-date branches. I couldn't re-verify this.

For an exact answer, David can look in Settings → General → "Pull Requests" (allow merge commits / squash / rebase) and Settings → Rules → Rulesets (each ruleset's targets and its "Block force pushes" box). If force-pushes should be blocked on PR branches too, a ruleset can target all branches, or codex/* and claude/*.
