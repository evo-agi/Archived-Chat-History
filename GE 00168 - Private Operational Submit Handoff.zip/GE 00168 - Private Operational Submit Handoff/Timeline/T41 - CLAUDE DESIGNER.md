First I'll read the PR 13 audit's section 5.5 and the retained admission check in ES to see what a durable fix for revocation freshness and v1 removal would take.
