Very comfortable, on your own systems. It fits the product, too: an admission layer has to hold up against an agent that tries to get around it.

What I can do well:
- **Adversarial tests in code.** Retry and replay attacks, races, forged or stale admission decisions, path and symlink tricks, malformed inputs, and fuzzing ES's parsers and handoff. These become permanent tests, so they keep protecting you.
- **Red-team audits.** A fresh thread whose only job is to break the change, separate from the correctness audit.
- **Live pen tests against a local ES stack in the container.** Nomad, Docker and the services, attacked from the outside.

Limits I'd keep:
- Only systems you own.
- Nothing against Remote Alpha or anything live without your explicit go each time.
- Nothing aimed at third-party services, GitHub or Anthropic included.

Some container setups may not support Docker or Nomad fully. If so, I'll say so instead of claiming coverage I don't have.

My suggestion is to make a red-team pass a standard step for anything touching admission or authority, starting with the PR 12 fix.

STATUS: NEEDS DAVID (go on the reliable submit plan, with or without red-team)
