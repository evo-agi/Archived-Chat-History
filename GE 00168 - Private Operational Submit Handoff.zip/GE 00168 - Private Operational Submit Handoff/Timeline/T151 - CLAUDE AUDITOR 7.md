**Audit 20 of PR #26: ACCEPT, with two low findings.** I recommend fixing both in this PR before it merges. One tested, test-only diff closes both.

**O7-1 is closed.**
- The allow rule now judges the code, not the line. Comments, `//line`, string tags, generated files and build-tagged files are all refused.
- The same 21 occurrences are allowed as before.
- My manifests match the writer's, both on `bcfb6da` and on the new head `0aba38e` (the merge of trunk_dev `036d507`). I tested that head's tree myself.

**A20-1 (low):** in `policy.go` the `PolicyDecision` exception still matches by name, not by object. A local, parameter, label, method or exported field named `AdmissionPolicyDecision` (or one of the two constructor names) passes. Base allowed these too, so this is not a regression.

**A20-2 (low):** two properties have no test. 4 of my 21 mutants survive: taking the file name from a `//line` position, and letting every other forbidden word through.

**The fix:** `object-level-allow-proposal.diff` in the evidence folder, +43/−9.
- All es/admission tests pass and the same 21 occurrences are still allowed.
- All 22 mutants are caught.
- It merges with PR #13's tip in the same two blocks the writer already planned for.

**Also, outside this PR (O20-1):** the DTO guard misses an embedded unexported struct. Embedding the runtime-trust response in `PrepareRequest` would put `"publication"` into the request JSON with every guard passing. A one-line diff fixes it, and es/admission results stay the same with it.

**CI:** the run on `0aba38e` is still going (started 15:31Z). I'll check it at 16:10Z and add the result here.

Report: [20-audit-pr26.md](/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/20-audit-pr26.md)

STATUS: WAITING
