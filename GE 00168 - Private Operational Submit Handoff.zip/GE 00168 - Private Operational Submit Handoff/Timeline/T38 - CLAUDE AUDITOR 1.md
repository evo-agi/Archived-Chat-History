Asked the project to choose an option

Where should long runs in this project go?

1. On Mac.lan (recommended): Uses your own setup, tools and sign-ins, and may be faster. Your computer needs to stay on.
2. In the cloud now: Starts right away, with nothing to set up.
3. In the cloud tonight: Starts this evening and is usually done by morning.

Why recommended: Your Mac already has the repository plus the tools and sign-ins these test suites expect, and it may be faster.
