Hmm... Didn't realize reseting Fable resets weekly limit as well.

Please resume the affected threads (The `Auto-continue this project's threads when limits reset` setting apparently doesn't detect manual reset...).
