Here is the response from CLAUDE RED TEAM 3:

Red-team of PR 12 at 4416699 is delivered: /mnt/project-files/reports/Execution-Substrate/pr12-current-admission/28-redteam.md (sha256 114c2625…75cd1). I pushed nothing. Two findings hold, both medium, each with a failing test.

RT28-2 (new in PR 12, bug): provider.project() first runs at reliable_submit_operational_handoff.go:368, after EstablishOperational (:243) and the run assignment. A request whose json.Marshal'd job exceeds 65,536 bytes (one argument of about 62,300 plain bytes, or 10,383 of < & or control bytes) is stored, gets a run, and answers Integrity forever, also in recovery and under a new generation. Four fill the domain (Capacity). Correction: project with a placeholder run of the real length before establishing and refuse as malformed; decide which encoding the bound measures (doc line 1345 says canonical, the code measures HTML-escaped output).

RT28-1 (pre-existing, shared builder): submit.go:180 sends caller argv unchanged and Nomad's client evaluates ${…} and %{…} in it (node attributes, task env, 15 functions). Fix belongs in validateInvocationAgainstManifest for argv, env values and mount target paths. Where it lands (trunk_dev PR or PR 12) is for you and the coordinator. Verified from Nomad v2.1.1 source only; needs one live check on the box.

Patches against 4416699, same folder, apply in this order: 28-redteam-regression-tests.patch (four test files, pass at head) and 28-redteam-finding-tests.patch (one file, the two failing tests; uses helpers of the first). Candidate diffs that make each test pass are in 28-redteam-evidence/candidates/ as proof only, not proposed code. Subtest names must not contain "=" (the fixture's staging path is refused).

Also: trunk_dev moved to 76c030f (PR 27) at 20:07Z; a trial merge into 4416699 conflicts in PLANS.md only. Section 7 covers the three tokenless Nomad requests that PR 31's guard flags. I did not attack the raw-memory guard; 28a covers it.
