The PR #12 fix is up as draft [PR #13](https://github.com/evo-agi/Execution-Substrate/pull/13), commit `e544e0f`. It targets PR #12's own branch, so its diff is only the fix, which keeps the audit and red-team scope tight. Merging it later still needs your go.

It builds on the earlier Codex candidate. I reproduced that tree exactly and reviewed it. Along the way I found and fixed a gap in its test guard: some writes to protected fields were being counted as reads. I also added the retry-after-policy-change tests, and they fail if the re-check is removed. Your approval for the CI branch arrived, so I've closed that card. The CI PR is next, then a report with the SHAs and manifest for the audit and red-team threads.

STATUS: WORKING
