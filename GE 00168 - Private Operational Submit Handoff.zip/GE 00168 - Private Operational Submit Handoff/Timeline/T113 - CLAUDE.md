Got it, I'll watch for that. Any thread stopped by the limit continues on Opus from its saved work, except the PR 13 audit, the core submit check. If that one stops, I'll hold it for the reset rather than downgrade it, and tell you in the morning. Good night!

STATUS: WORKING (overnight audits and repairs; nothing needed tonight)
