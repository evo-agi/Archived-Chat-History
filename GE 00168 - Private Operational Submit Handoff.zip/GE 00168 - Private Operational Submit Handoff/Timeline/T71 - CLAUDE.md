The PR 13 admission fix repair is in, so I'm starting its fresh audit. Under the new red-team rule, it gets red-teamed together with PR 12 before that merges into trunk_dev.

STATUS: WORKING (PR 13 audit, MA re-audit, PR 14 gap check)
