Pausing the maintenance agent now.

Reliable submit is close. It has taken in the Nomad lock and the Nomad token change, plus two smaller fixes, and is synced with the latest trunk_dev. Its draft is [PR 47](https://github.com/evo-agi/Execution-Substrate/pull/47). The full test suite, the planted-fault checks and CI are running now. After that it goes to one combined check and a last red-team re-check, then it can merge.

Separately, the small fix for the two Nomad setup bugs needs its own branch. Your rules already allow that, but the thread's setup only lets it push its own branch unless you approve one here:

STATUS: NEEDS DAVID (approve the new branch for the Nomad setup fixes)
