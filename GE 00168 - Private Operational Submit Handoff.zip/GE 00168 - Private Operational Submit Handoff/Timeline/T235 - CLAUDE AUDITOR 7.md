The guard misses one road (G28-1, Medium). I have a tested fix diff for it. Everything else on your list is either caught or one of the guard's named limits.

**G28-1.** A production file can make the es binary load a shared library at start. It takes one comment line and no import: `//go:cgo_import_dynamic _ _ "lib.so"`. The compiler accepts that line outside cgo files. The deploy builds use `CGO_ENABLED=0`, and with this line `cmd/es` stops being static: it gets a dynamic loader and a `NEEDED` entry for the library, so the library's own code runs inside the process before `main`. I measured this on 4416699's tree plus a three-line file in `es/app`, for linux/amd64 and arm64, and all ten guard tests still passed. The guard never reads `//go:` comments; the only directive it checks for is `//line`.

**The fix** is `guard-directive-allowlist-proposal.diff`, which applies with `git apply` to 4416699:
- A new test allows only the `//go:` directives on an exact list. Today that list is just `//go:build`, on 4416699 and on trunk_dev 76c030f alike.
- It checks the same files as the `//line` check, and it also fails if a directive on the list is no longer used anywhere.
- With the probe file added, only the new test fails, and it names the file. All 6 mutants of the new check fail the tests.

**G28-2 (Low).** The guard already catches dot imports, import paths written with an escape or as a raw string, and generated files, but no test names them. Three mutants that break exactly those forms pass every existing test. The same diff adds six cases, and with them all three mutants fail.

**Everything else is caught or a named limit:**
- `//line` (R14-1, R14-2, A6-1)
- import aliases
- build tags and files no target builds
- symlinked folders, which the guard already tests
- vendor and testdata folders
- cgo files and non-Go files
- reflection and `unsafe`

Each item has its code lines cited in the report.

**Tests on the fix tree:**
- gofmt and vet on all three targets are clean.
- The guard tests and the docs contract tests pass.
- es/admission in full: 2,596 pass, 8 skip, 0 fail. No existing test changed its result.

The report is [28a-guard-coverage.md](/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/28a-guard-coverage.md) (SHA-256 576ed5b8…2c4f), with 27 evidence files. PR #12 stayed at 4416699 the whole time. Next step is for the PR #12 writer to apply the diff.

STATUS: READY
