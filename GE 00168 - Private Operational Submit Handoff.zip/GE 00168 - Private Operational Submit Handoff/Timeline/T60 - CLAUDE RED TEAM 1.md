**Red-team verdict on PR #13: HOLDS WITH CAVEATS.** I could not make ES stage, stamp, mark or send a job after the current authority said no. That held across crash points, races, key reuse, tampered and forged records, planted files and fuzzing. Two findings hold, both in the tests and not in the shipped code:

- **RT-1 (medium):** the test guard misses protected-field writes that don't spell the field. A scratch production mutant that erases the snapshot's revocation lists passed the build, vet and the whole suite.
- **RT-10 (medium):** three checks (the run-assignment cut, the establish gate, the installation check) could each be removed with a green suite. This looks like the same ground as the audit's BLOCK line in project memory. I found it independently by mutation and have not read the audit report.

[Draft PR #15](https://github.com/evo-agi/Execution-Substrate/pull/15) to the PR #13 branch holds the regression tests. It is red on purpose until RT-1 is fixed in the guard or written into the contract as an exclusion. Its other tests pass and close RT-10. I'm watching it. PR #13 is untouched and nothing was merged.

Eight low caveats, the coverage the container could not give, and two tested repro scripts are in the report: [03-red-team.md](/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/03-red-team.md), SHA-256 `dbbccbf587548f3786d69464531ced871de037dc68538bd96e42837e9e984959`.

Only six cards fit on one reply. Seven smaller supporting files (two more diffs, the experiment source and log, the custody test source and two fuzz log tails) are not attached. They are in `/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/03-red-team-poc/`.

STATUS: READY
