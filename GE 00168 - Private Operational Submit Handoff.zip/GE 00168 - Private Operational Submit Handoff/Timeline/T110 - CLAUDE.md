PR 13's package split is done, so the core submit fix gets its fresh audit now.

STATUS: WORKING (nothing needed from you)
