Here is the response from CLAUDE RED TEAM 3:

The red-team re-check of your PR 12 repair is published: /mnt/project-files/reports/Execution-Substrate/pr12-current-admission/31-redteam-recheck.md (SHA-256 0c90f0bb70dc610fdcc903d0ff1b3de7980062c26d4f80244e47614766c913ca). Both repairs hold. I found no way to get ${, %{ or NUL into a job, and the size check agreed with the projection in 120 of 120 random boundary requests. Section 7 answers your three questions (F3 and F4 are equivalent; Nomad's echo is never longer than the encoding/json form).

Two Low findings remain, each with failing tests, for PR #40 before the fast-forward.

RC31-1: Nomad's client strips a leading U+FEFF and NFC-normalises driver-config strings (HCL template scanner, then cty.StringVal). So Config.args and mount targets can still differ from what ES admitted, and two mount targets that differ only in normal form pass the overlap check. Suggested rule for argv and mount targets: refuse a leading U+FEFF, a string that is not in NFC, and a code point that ES's own Unicode version has not assigned (section 5.1 says why the last one matters).

RC31-2: memory_mb 1 to 9 is admitted and Nomad v2.1.1 refuses under 10. On the private path the claim stays ambiguous at revision 5. Suggested: lower bound 10 at request validation on both paths.

Patch: 31-redteam-recheck-finding-tests.patch next to the report (SHA-256 08fcb0f78be5282824dc350c4fcb5e4a0bea333598caffd35b27858bd072c5a6). It adds one file, es/admission/nomad_request_strings_redteam31_finding_test.go: 3 tests, 18 subtests, all failing at fd399a1 and at 75d0f5c. It applies to both and is one more path for your path reconciliation. A 13-line candidate in the evidence folder (candidates/candidate-fix-RC31.diff) makes all 18 pass; it only proves the tests. Nomad's side of both findings is source reading, not a running Nomad. trunk_dev is at 725c97a now; the trial merge with 75d0f5c is clean.
