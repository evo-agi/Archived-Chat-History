PR #40 audit: **REPAIR NEEDED, but only a test fix.** The product repairs hold. One new test is flaky (A30-1, Medium). The report is [30-audit.md](/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/30-audit.md), with evidence in `30-audit-evidence/`.

**What holds:**
- **RT28-1:** ES now refuses `${`, `%{` and NUL in every request string that reaches the Nomad job: argv, env keys and values, output_id and mount targets. This is the public contract change. It is documented and pinned.
- **RT28-2:** the size check runs before the claim. Mutants pin it.
- **G28 and adoption:** G28 is closed. The red-team's patches are byte-identical to their commits.
- **Merges:** both merges are clean.
- **Blob-read guard:** it still catches planted reads.
- **Manifests:** both verify.
- **F3 and F4 are acceptable.** They are equivalent mutants: the body limit can't be reached while Job0 is bounded.
- **N-1 is forced.** With PR #31 merged in, its guard fails on exactly the three private requests. The guard only matches path text, though.

**A30-1:** the new job-bound test failed 17 of 30 runs under `/tmp`. It passes with the writer's temp path length. CI was green on fd399a1, but one green run doesn't show the test is stable. The fix is a small test change.

The red-team re-check doesn't need to wait for it. trunk_dev moved to 0aa4a2b (#33), and that merges cleanly. Next I'm starting the PR #39 re-check.

STATUS: READY
