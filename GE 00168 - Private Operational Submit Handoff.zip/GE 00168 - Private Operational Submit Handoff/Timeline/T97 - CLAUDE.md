Sure. Here it is in plain terms.

**What it is:** before ES hands a job to the runtime, PR 13 makes it re-check that the job is still allowed to run. That means its trust and policy are still current and its artifact hasn't been revoked. The "protected admission state" is the record ES keeps for that check, saying which admission decision is current. The rule is that only the checked code path may read or change it.

**The problem so far:** three times now, a review found a way for other code to reach that record without the check, by copying its structure or converting a pointer to it. In a test copy, that let a job with a revoked artifact be accepted. Today, a test scans the code for such shapes and fails if it finds one. The latest version blocks any pattern it doesn't know, but it's still a scanner whose completeness rests on reasoning.

**Moving it to a small package:** in Go, a package can hide its internals completely. If the record lives in its own small package with hidden fields, the compiler itself refuses any code that tries to touch it except through the checked functions. A bypass then can't be built at all. That's stronger than a scanner and doesn't depend on anyone remembering the rule.

**What we risk:**
- **Splitting now:** more work, one more full audit, and a small chance of a mistake while moving code. That chance is covered by running the same fault tests against the moved code, with no change in behaviour allowed.
- **Not splitting:** the next step wires this into real submissions, which adds new code near the record. Each addition is a fresh chance to slip past a scanner, and the consequence would be ES running work it should have refused.

My recommendation stays: split now, before the red-team, so it attacks the final design.

STATUS: WORKING (PR 13 split underway; the card stays open if you want to overrule)
