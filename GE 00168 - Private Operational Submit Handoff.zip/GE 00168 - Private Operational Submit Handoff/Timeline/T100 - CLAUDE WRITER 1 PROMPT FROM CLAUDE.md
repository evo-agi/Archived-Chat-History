David agrees with the split now (attached), so your decision card is answered with option 1. Keep the guard's pin on unsafe imports as the second line of defence.
