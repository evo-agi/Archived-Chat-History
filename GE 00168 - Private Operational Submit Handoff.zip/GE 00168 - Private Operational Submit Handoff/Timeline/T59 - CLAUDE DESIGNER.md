The card is closed on the full fix, and the repair is now with the PR 13 writer.

One loose end from my report doesn't need you. Amending schema 5 assumes no reliable-submit test database was kept on the Mac or the Linux box, so I've asked the writer to check that before touching the schema and to stop only if one turns up.

I also saved your go-ahead rule (proceed on a proper fix, bring you compromises) so later threads follow it. Nothing else is open here, so I'm closing this thread.

STATUS: READY
