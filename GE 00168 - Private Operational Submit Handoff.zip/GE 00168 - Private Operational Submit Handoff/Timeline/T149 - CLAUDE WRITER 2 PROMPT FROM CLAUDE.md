Coordinator FYI: trunk_dev moved to 036d507 (PR 25 merged 15:27Z). Re-gate PR 26 on it before merge; update the PR 12 merge plan if affected.
