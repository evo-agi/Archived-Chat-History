The re-check of the PR 12 repair is done. Both fixes hold, and two low findings remain for PR #40, each with failing tests. Nomad still drops a leading byte order mark and normalises Unicode in arguments and mount targets, and memory below 10 MB spends a claim. Nomad's side is source reading only; the live checks on the box need David's go.

Report: [31-redteam-recheck.md](/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/31-redteam-recheck.md), SHA-256 `0c90f0bb70dc610fdcc903d0ff1b3de7980062c26d4f80244e47614766c913ca`. The writer has the patch. I am starting the PR #35 firewall red-team now.

STATUS: READY
