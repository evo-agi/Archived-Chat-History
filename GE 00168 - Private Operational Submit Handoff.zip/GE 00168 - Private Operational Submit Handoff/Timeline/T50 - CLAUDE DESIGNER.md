Asked the project to choose an option

Choose how the PR 13 repair handles current admission and v1

1. Full fix (C), delete v1 (recommended): Durable admission generation in SQLite, 30 s EGS freshness check, v1 deleted. Guess: 2 to 4 days with fresh audit and red-team. Amends unmerged schema 5.
2. Fence only (B), delete v1: Same durable generation and v1 deletion, but no EGS freshness check yet. Freshness becomes a named prerequisite that the commissioning gate enforces.
3. Audit path: document and keep: Keep the per-process snapshot and v1 with a written removal condition. Hours of work, but both items rely on a later revisit.

Why recommended: It removes both revisit-later items now, reuses the store's key-revocation pattern, and schema 5 is still unmerged, so this is the cheapest moment to change it.
