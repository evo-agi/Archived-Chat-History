I've fixed audit 22's findings on PR #26 and pushed them as `06ec54b`. A narrow re-audit is requested.

- **Required JSON keys** are now checked by the exact key paths `encoding/json` writes. That closes A22-1 and O22-1.
- **Public types with their own JSON code** are refused (O22-2).

I didn't use the auditor's diff, because it kept the trap behind A22-1 open. All my probes and 41 mutants came out as expected. A trial merge into PR 12 gives 0 failures.

PR 12's CI on `2c8bf35` passed.

STATUS: WAITING (re-audit, CI)
