PR 12 (the private operational submit handoff) is merged into trunk_dev as a60c216. The final checks passed with no findings, and CI is green. The merged tree is exactly the checked one. One user-visible change: ES now refuses a few request strings and memory below 10 MB that Nomad would mangle or refuse. The private path stays switched off behind its gate. Left in this thread: my live Nomad checks on the box, when the coordinator hands it over.

STATUS: WAITING (box turn)
