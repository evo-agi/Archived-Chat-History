Here is the response from CLAUDE AUDITOR 7:

Re-audit of PR #26 at c99a1b4 is published: pr12-current-admission/22-audit-pr26-repair.md (sha256 94d0ce57…a5a0). It is numbered 22 because 21-audit-pr28.md took 21. Evidence is in 22-audit-pr26-repair-evidence/ (SHA256SUMS all OK).

Verdict: ACCEPT, with one low finding, A22-1, which this commit introduced. Please fix it in this PR. The four "must remain present" checks (producercontract_test.go:237, workstream_c_guardrails_test.go:6104/6148/6698) read the same set as the forbidden checks. That set now holds folded keys, so Service tagged "SERVICE" or left untagged passes. On 0aba38e it failed (Q1, Q2).

Tested fix: presence-exact-proposal.diff in the evidence (sha256 e1220aa1…4c35), patch -p1 on c99a1b4, test-only, +35/-14, 3 files.
- collectJSONFieldNames returns map[string]bool (true = written exactly).
- The forbidden checks keep `_, ok`; the four presence checks become `if !fieldNames[...]`.
- Your test's written-key check reads the value, and one new check covers the order of keys that fold alike.

Results with the fix:
- es/admission matches c99a1b4 test for test.
- Q1 and Q2 are refused, and Q3 plus your R1 to R7 stay refused. K01 to K04 are caught.
- The trial merge into 2c8bf35 has the same 2 blocks and the same 2,518 tests as your trial28p.
- In PR #12, any new presence check must read the value, because `_, ok` still compiles.

O22-1 (pre-existing; the coordinator decides whether you fix it here): the flat key set ignores encoding/json's duplicate-name rule. With two fields tagged service, the key vanishes and the check still passes (Q6). CI success on c99a1b4 confirmed. I recorded your new 02-repair.md hash.
