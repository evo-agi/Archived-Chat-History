First I'll read PR 12, its review finding and the owner contract, then post a short plan.
