Coordinator FYI: PR 22 landed first (trunk_dev 792f17c), so the PositionFor(…, false) change for its two position reads applies to the PR 12 trunk_dev merge plan.
