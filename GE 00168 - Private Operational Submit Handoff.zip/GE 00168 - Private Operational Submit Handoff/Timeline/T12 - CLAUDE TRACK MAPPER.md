First I'll unpack the three archives and find where each track stopped and what it was waiting on.
