**ACCEPT PR #28's head `2c8bf35`, with no finding.** PR #12's branch can now be fast-forwarded from `6288b63` to `2c8bf35`. That step needs David's go, and should happen only while `trunk_dev` is still `036d507`.

- **Bytes:** my manifests match the writer's byte for byte, at the start and at the end. The head has 56 paths against `trunk_dev`.
- **The merge commit holds only the two known resolutions.** Its tree is exactly what my own merge produced. Checked file by file:
  - every file only `trunk_dev` changed is `trunk_dev`'s bytes;
  - every file only PR #12 changed is PR #12's bytes.
  
  The one production file both sides changed, `staging_custody.go`, merged without a conflict. I read both changes and found no interaction.
- **The follow-up is exactly the corrected plan.** M19-1 is fixed: the documents name all three paths and say 56.
- **Nothing of `trunk_dev` changed.** I ran the full suite at both commits. All 5,478 `trunk_dev` results keep their verdict. Every new PR #12 result passes, except the two tests the new CI lines name.
- **The guards still work.** My earlier probes give the same results as before, and all 11 guard mutants are caught. The new pins refuse wrong documents.
- **CI is green** on `2c8bf35`.

For later: if PR #26 or PR #29 lands on `trunk_dev` first, that case needs a short re-check.

STATUS: READY
