The third repair of [PR #13](https://github.com/evo-agi/Execution-Substrate/pull/13) is pushed at `faacf16` and is ready for a fresh audit. It is not audited yet.

The guard now refuses a whole class of escapes by default instead of listing known forms. No production code changed. All 56 new guard mutants are caught, and no test went from pass to fail.

One design choice is yours and blocks nothing: moving the protected state into its own small package (section 4.4).

Report: [09-repair.md](/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/09-repair.md), SHA-256 `33f75a4cfd807574405772ea63ff804762b7bc47538d58a59e6bc3797ffc54c5`.

STATUS: READY
