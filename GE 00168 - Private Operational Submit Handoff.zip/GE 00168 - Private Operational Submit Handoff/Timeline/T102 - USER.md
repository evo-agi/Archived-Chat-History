> Yes, it's the proper fix. The protection comes from the language itself, so it holds without anyone remembering a rule. …


Yeah, it's a go.

In general, proper solutions win. Hacks are what we want to avoid as much as possible, even at the expense of a detour.
