The blocked-tracks review is done. Of your three tracks, only PR 12 is live, and its recovered fix is already in progress. Cancellation through ES is parked with Coordinator. One ES gap is worth keeping from it: a "lost" job counts as finished, so ES can't confirm a cancelled job actually stopped. The Linux restore track is closed, since you fixed Remote Alpha by hand on Nov 9.

This bears on the card above. ES's own docs say Remote Alpha can't be reused as a test box without a migration plan. That leans toward keeping it intact, or toward a separate box later for live red-team. Is it amd64 or arm64? PR 12's native target is arm64.

Proposed order: finish PR 12 with audit, red-team and your merge go. Then integrate reliable submit. Cancellation comes last.

STATUS: NEEDS DAVID (the Remote Alpha card). PR 12 fix and runbooks are running.
