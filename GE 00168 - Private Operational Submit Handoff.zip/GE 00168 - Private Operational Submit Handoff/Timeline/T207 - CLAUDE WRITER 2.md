I've fixed both of audit 23's findings on PR #26 and pushed the fix (`a88467f`). It's now with the same auditor for the narrow re-audit they asked for.

- **The fix.** It is the auditor's own tested diff, applied unchanged, plus one extra test case. The diff stops a JSON key name containing `.`, `[`, `]` or `*` from posing as a nested key. The extra case makes sure the custom-codec check also covers plain named string types.
- **Test code only, one file.** No product behaviour changes.
- **Checks.** Everything passes, as the auditor predicted: all their probes and mutants from audits 20, 22 and 23, my 42 mutants, and a trial merge into PR #12. Full details are in [04-repair.md](/mnt/project-files/reports/Execution-Substrate/workstream-a-allow-rule/04-repair.md).
- **CI** on the new commit is still running.

Next, once the re-audit accepts and CI is green, I run the merge gate and merge. It's test-only, so it doesn't need you.

STATUS: WAITING
