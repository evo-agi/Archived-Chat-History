PR 12's branch is fast-forwarded to 2c8bf35, which is PR 12 plus PR 13 on the latest trunk_dev. CI is running on it.

For the read-only box check, please open [Lock Nomad so only ES can submit](#cmsg_01Un4xQgjBAczV8DABQvcLrx7qaBgesL513RdQXm7D49pW) and allow the Mac card there. It works only in Playground and changes nothing on the box.

STATUS: NEEDS DAVID (allow the Mac card in the Nomad thread)
