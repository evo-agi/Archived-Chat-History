Yes, 00000 is only for local dry runs and will never be uploaded. Real archives start at GE 00137 and only go up. That's now in the project instructions.

Red-team is now mandatory there too. Every non-trivial change gets a fresh thread whose only job is to break it, separate from the correctness audit. I've also recorded your strategic decisions in the instructions.

I took your message as the go for reliable submit, so the PR 12 fix has started. If you didn't mean that, tell me and I'll stop it.

STATUS: WORKING on the PR 12 fix and ES CI. Audit and red-team threads follow when the fix is ready.
