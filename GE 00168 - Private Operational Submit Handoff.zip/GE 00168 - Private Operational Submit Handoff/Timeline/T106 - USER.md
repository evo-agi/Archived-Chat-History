> Thanks, that matters. From now until the reset, Fable is reserved for the reliable-submit core: PR 13's next audit and t…


Done.
