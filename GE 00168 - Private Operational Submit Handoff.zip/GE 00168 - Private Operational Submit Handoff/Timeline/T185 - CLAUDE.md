On the rulesets: only main, trunk_dev and trunk_dev_secondary are protected. PR branches, including PR 12's, aren't, so only our own rule keeps them from force-pushes. Recent merges into trunk_dev were all squashes. I couldn't read whether squash is the only method allowed.

If you want, add one ruleset that blocks force-pushes on every branch. Nothing we do needs a force-push. In ES on GitHub: Settings → Rules → Rulesets → New branch ruleset. Name it "No force push", set Enforcement to Active, add the target "All branches", tick only "Block force pushes", and save.

STATUS: READY for that whenever you like; nothing else needed from you
