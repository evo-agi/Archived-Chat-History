Here's my plan for reliable submit, ready when you say go:

1. **Fix the open PR 12 finding.** A retried handoff can stage and run work without rechecking current admission policy. One thread fixes it on the PR branch, then a fresh thread audits it under the full provenance gate.
2. **Add CI to ES first, alongside the fix.** This is a strong recommendation, not a detour. Right now "tests pass" is only ever someone's report. CI makes it something you can check, which is exactly your correctness bar.
3. **Integrate reliable submit into ES's real submit path**, planned from PR 12 once it merges.

Reading "its integration" as wiring into ES's real submit path. If you meant connecting callers to it, tell me and I'll adjust step 3.

STATUS: NEEDS DAVID (go on steps 1 and 2). The archive fixes are still running.
