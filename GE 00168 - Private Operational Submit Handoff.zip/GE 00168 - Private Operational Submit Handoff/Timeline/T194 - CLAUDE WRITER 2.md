Asked the project to choose an option

Update PR 12's GitHub description and close the old Codex review thread?

1. Yes, do both (recommended): I add the drafted 'Current state' section above the old description, reply once on the Codex thread citing commit 6288b63, and resolve it. Both post from your GitHub account.
2. Description only: I add the 'Current state' section and leave the Codex thread as it is.
3. Leave PR 12 as it is: Nothing changes on GitHub. The draft stays in the project folder.

Why recommended: The description still describes the first commit from 20 Nov. The Codex finding was fixed by PR 13's merge: every first-effect cut now re-checks current admission.
