> Sure. Here it is in plain terms.


From the sound of it, it feels like splitting is the right move because it seems to add language-specific protection? So it's a proper fix?
