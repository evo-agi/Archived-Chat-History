**Re-check 33 of PR #40 at 99a6625: ACCEPT, with nothing to fix.** Both fixes are right, and CI passed.

- **RC31-1:** I compared the rule against ES's Unicode 15 tables and Nomad's newer Unicode 17 tables, over about 24 million strings. ES keeps no string that either set would rewrite.
- **RC31-2:** memory below 10 MB is now refused before any claim.

The writer's five questions are answered in section 3.

Two things for merge order:
- **PR #40 must take trunk_dev 6ce0034 first.** It holds #43 and #42, and both trial merges are clean.
- **New merge-order item, N-2:** PR #31's guard test reads code positions three times in a way PR #12's position guard refuses. Whichever of the two merges second needs a three-line change.

STATUS: READY
