**Verdict: HOLDS WITH CAVEATS.** Nothing was pushed, commented on or merged, and the local checkout is clean at `bff8dda`.

[13-red-team.md](/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/13-red-team.md), sha256 `0d6793a52edfb6900be844766bf785ec18e7894566a7035c4cb32bc6d4dafd60`. The evidence folder has 54 files with SHA256SUMS.

- **The behaviour held under every attack I could build.** Revocation between steps, ABA generations, an 8-way advance race, raw SQL, an advance between COMMIT and release, 8 concurrent deliveries of one claim, 144 SIGKILLs at random instants and staging-root swaps: no job was ever sent twice, and no fenced or superseded process ever sent one.
- **One low finding, RT2-1.** `modernc.org/libc` is already in go.mod as an indirect dependency of the SQLite driver. A production file that imports it can reopen a stopped admission state using plain Go calls, and the whole suite gives the same results with that file in place. Unlike A5-1, the import line names it, so one predicate in the import inventory holds it. The fix and a test that fails today are in the report. The owner document's line "The import names which files can write storage…" is untrue until then. I recommend fixing it before PR #12's merge gate.
- **Documented limits, now shown with tests:** startup-only trust (a commissioned process can't reload, so ordinary Prepare keeps admitting a revoked artifact), rollback replay, and a new release joining the old generation.
- PR #13's head moved to `51d6d5f` while I worked. That commit changes docs only, so these results still apply. Section 6 of the report is the attack inventory for the Fable pass.

STATUS: READY
