Ignore David's message that was attached to my last note. It got attached by accident and is unrelated to PR 12 (a lowest-priority remark about cleaning up the box someday). No action from you on it.
