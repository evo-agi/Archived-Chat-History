> The last audit of PR 13 said the guard is safe for now but recommended moving the protected admission state into its own…


Do remind me again. What is this "protected admission state" ? And what do you mean by moving it to a small package? What are we risking here?
