The 50 MiB cut-off is in place, and the rebuilt dry run passes. The archive workflow is finished. The only thing still open is your go on reliable submit: fix PR 12, add ES CI, then integrate. Say whether you want red-team passes included.

STATUS: NEEDS DAVID (go on reliable submit)
