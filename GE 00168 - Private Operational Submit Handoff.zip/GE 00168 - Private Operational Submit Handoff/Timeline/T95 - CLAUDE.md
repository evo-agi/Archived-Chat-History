The last audit of PR 13 said the guard is safe for now but recommended moving the protected admission state into its own small package before real submissions use it. I asked for that now, because the integration is our next step and doing it before the red-team avoids running a second one. The work has already started on that basis. It costs one more full audit, so the card lets you overrule it if you'd rather save that effort.

STATUS: WORKING (PR 13 split, PR 18 final check, PR 14 audit, MA alert; the card is optional)
