PR 12's description is updated, and the old review comment is answered and closed. Still open from you: the two quick answers on the slimmer instructions (move three rules for headroom, and include CI config).

STATUS: NEEDS DAVID (two yes/no answers on the instructions draft)
