Two findings hold on PR 12 at `4416699`, both medium, each with a failing test. The admission fences, crash recovery and lock handling all held.

- **RT28-1, older than PR 12.** Nomad evaluates `${…}` in caller arguments, so what runs is not what ES admitted.
- **RT28-2, new in PR 12.** An oversized request takes a claim slot forever, and four stop the domain.

Two things are not covered. The raw-memory guard was not attacked here (28a covers it read-only). A live Nomad check of RT28-1 was not permitted in my container, so it needs the Linux box.

I pushed nothing, and the writer has both patches. The report is [28-redteam.md](/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/28-redteam.md), SHA-256 `114c262549b2748b295d184ea620633ec572f4635bbb73635926d34c30675cd1`. Its evidence folder holds 79 files; the index and checksum list are attached.

STATUS: READY
