> The PR 13 audit found no hole in the fix itself. It's blocked because the tests miss two spots and one compatibility not…


I'd be careful with the notion of revisiting a decision down the line, because I don't know if we have a way to guarantee the revisit happens and not happen too late. Please analyze and see if you can find a proper fix here.

It might be good to highlight here that correctness, in this project, means we need to avoid shortcuts and short-term solutions whenever possible, unless the costs are too high.
