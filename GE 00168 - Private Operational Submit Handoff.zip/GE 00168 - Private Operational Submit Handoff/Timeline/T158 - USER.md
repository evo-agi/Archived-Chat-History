> PR 13 (→ github.com), the core reliable-submit fix, passed its final audit and is ready for your review. It's the second…


Ok. Honestly, I can't digest the code within a short period of time. I'll approve it.
