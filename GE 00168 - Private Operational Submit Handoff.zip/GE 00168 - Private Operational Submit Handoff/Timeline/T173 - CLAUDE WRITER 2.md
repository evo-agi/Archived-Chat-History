PR 12's branch has been fast-forwarded from `6288b63` to `2c8bf35`, so PR 12's head is now `2c8bf35`. That is PR 12 plus PR 13 plus trunk_dev `036d507`, with 56 paths.

- Before the push I checked that trunk_dev was still `036d507` and PR 12's branch still `6288b63`. It was a plain fast-forward with no force.
- I didn't need to close PR #28: GitHub marked it merged by itself, because its head is now PR 12's head.
- CI is running on PR 12's new head against trunk_dev ([run](https://github.com/evo-agi/Execution-Substrate/actions/runs/45219219689)). I'm watching PR 12 and will report the result.

The merge plan's status line records the fast-forward.

STATUS: WAITING (CI on PR 12; re-audit and CI of PR #26)
