Early notice: the audit of PR 13 (tip b6d2f77) will end in **BLOCK**. The production code holds so far, but the guard fix for RT-1 is incomplete: a write through a pointer conversion still passes the guard and the whole admission test package. I reproduced it with two end-to-end mutants. The fix is small and test-side. The full report, 06-audit.md, follows once my mutant runs finish, around 13:15Z. Nothing was edited or pushed.

STATUS: WORKING
