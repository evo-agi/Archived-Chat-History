Forgot to mention, there were three tracks on OpenAI side that were blocked by reliable submission and Linux test env, speaking of which, do you want access to the disposal Linux box?
