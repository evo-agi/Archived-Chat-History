PR #26 now carries audit 20's fixes, pushed as `c99a1b4`, and the narrow re-audit is requested from the same auditor.

- **A20-1 and A20-2:** I applied the auditor's tested proposal unchanged. The `PolicyDecision` exception now allows only the real seam type and its two constructors. Something that just has the same name, like a local variable, a parameter, a label, a method or a field, is now refused. The auditor's 31 probes all came out as predicted, and all 22 of the auditor's mutants are caught.
- **O20-1 went wider than the auditor's one-line diff, because the gap was wider.** I tested the helper the DTO guards rely on against Go's JSON library itself. Five more kinds of field could put a forbidden key into ES's public request with every guard passing: an untagged field, a key that differs only in case, an invalid tag, an embedded named type, and a value inside a map. Seven planted fields in the real request type show it. Before the fix all seven passed the guards, the one-line diff stops one of them, and all seven are refused now. On the real tree nothing new is flagged and no test result changed.
- **PR 12:** merging this into PR #28 gives the same two small conflicts as before and adds no path. Every test in that package still passes, and the merge plan now records it.

Still test-only, so it merges without David once the re-audit says ACCEPT and CI is green. CI is running on PR #26 and on PR #28.

Report: [02-repair.md](/mnt/project-files/reports/Execution-Substrate/workstream-a-allow-rule/02-repair.md)

STATUS: WAITING (re-audit of PR #26; CI on PR #26 and PR #28)
