# 26-provenance-pr32-4416699 evidence (ES PR #32, merge `4416699`)

Written by the independent audit thread "Audit Execution-Substrate PRs" on 2026-11-23, from 19:22Z onwards. Every file here was made in the audit's cloud container or fetched read-only. `SHA256SUMS.txt` lists every file. My local names carry the tag `26e`.
Nothing in this folder is authority. It is evidence for `../26-provenance-pr32-4416699.md`.

## Setup

- Clone `/opt/audit/es`; v2 recipe `/opt/audit/v2.py` (SHA-256 `c08597e2…a3ca`), checked before the runs. Each manifest run checks out PR #32's branch at the tip, resets it to the base, and pins the upstream (`origin/trunk_dev` for the trunk-relative manifest, `origin/codex/reliable-submit-operational-handoff-v1` for the PR-relative one).
- The independent merge ran in a temporary worktree (`git worktree add --detach … 2c8bf35`, `git merge --no-commit 8ba1edb`), was written as a tree object only, and was aborted and removed. Nothing was committed or pushed.
- No test run: the merged tree is byte-identical to audit 24's trial tree `052d1024`, whose results are in `../24-audit-pr26-repair3-evidence/`.

## Files

| File | What |
| --- | --- |
| ls-remote-open.txt, ls-remote-close.txt | Remote refs at the start and at the end: PR #32's branch and `refs/pull/32/head` at `4416699`, PR #12's branch at `2c8bf35`, `trunk_dev` at `8ba1edb` |
| paths-and-trees.txt | Paths the merge changes against `2c8bf35`; paths `trunk_dev` brought since `036d507`; the 56 trunk-relative paths compared with PR #28's; `8ba1edb`'s tree and parent |
| plain-merge-output.txt, workstream_a_guardrails_test.go.conflicted.txt | My own merge of `8ba1edb` into `2c8bf35`: git's output, and the conflicted file before resolution (two blocks) |
| resolve26e.py.txt | The resolution script: resolves exactly the two known blocks and stops on anything else |
| remerge-diff-4416699.txt | `git show --remerge-diff 4416699`: the commit compared with git's automatic merge. Two hunks, both in the known blocks |
| merge-tree-conflicted-vs-4416699.diff | `git merge-tree` result (with conflict markers) compared with `4416699`'s tree: the same two hunks |
| manifest-v2-4416699-vs-2c8bf35-pr-relative-run1/2.json (+ .out.txt), manifest-v2-4416699-vs-8ba1edb-trunk-relative-run1/2.json (+ .out.txt) | Both manifests, twice each, byte-identical to the writer's |
| writer-evidence-check.txt | The writer's report and tar hashes, its `SHA256SUMS` check (25 of 25 OK), and the manifest comparison |
| ci-status.txt | CI run 45248038866 on `4416699`, read through the GitHub API |

## Sensitive material

No key, certificate body, token or config file is copied here. Commit-message trailers and author names are left out.
