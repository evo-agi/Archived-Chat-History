# INDEPENDENT AUDIT REPORT: draft PR #28, PR #12's branch taking up `trunk_dev` `036d507`

Fresh, read-only audit by the auditor of `15-audit.md`, `17-audit.md` and `19-audit.md`. Audit thread: "Audit PR 12 trunk_dev merge". Date: 2026-11-23, 16:00Z to 16:45Z (UTC). Model: Opus. I am not the writer of the audited bytes.

Verdict: **ACCEPT** head `2c8bf35` (tree `df3ff9dd…`) as the merge of `trunk_dev` `036d507` into PR #12's branch (section 11). No finding. PR #12's branch can be fast-forwarded to this head once David says go.

## 1. In plain words

1. **The bytes are the ones the writer reported.** I rebuilt the writer's three manifests of PR #28 at the start and at the end. All 15 files are identical byte for byte, both times. The head has 56 paths against `trunk_dev`, and they are the same 56 my trial run in `19-audit.md` produced.
2. **The merge commit holds only the two known resolutions.**
   - Its tree is exactly the tree my own strict resolver gave in `19-audit.md` (section 9.5). That resolver takes PR #12's side of the reliable-submit count with the counted 39, keeps both adjacency blocks, and stops on anything else.
   - File by file:
     - all 69 files that only `trunk_dev` changed are `trunk_dev`'s bytes;
     - all 46 files that only PR #12 changed are PR #12's bytes;
     - the 7 files both changed are combined. Six merged cleanly by git, and one is `docs_contract_test.go` with the two resolutions.
   - `6288b63`, PR #13's merge into PR #12, has exactly the tree of the `e060449` I accepted.
3. **The follow-up commit is the corrected plan, exactly.**
   - Applying the corrected `18-trunk-dev-merge-gate.patch` to the merge commit gives the head's tree.
   - Against my 19-audit trial run, only the three documents differ: the owner paragraph, the `PLANS.md` entry and the pins now name all three paths and say 56. M19-1 is fixed.
   - The startup file is PR #23's file with the package name changed. The two read changes are exactly `PositionFor(…, false)`. The CI lines are the content of `13-ci-list-two-lines.patch`.
4. **One production file merged without a conflict but needed reading: `es/admission/staging_custody.go`.**
   - `trunk_dev`'s PR #20 makes staging refuse modes that the startup probe has not checked, and refuse a directory it opened by name unless it already belongs to the roots' owner.
   - PR #12's additions in that file only measure staged entries; they create nothing.
   - PR #20's exact lists of who calls its new functions still pass, so PR #12 added no caller.
   - Every handoff test passes on the merged tree. I found no interaction.
5. **Nothing of `trunk_dev` changed.**
   - I ran the full module suite at the head and at `trunk_dev` `036d507`, in the same container.
   - All 5,478 results of `trunk_dev` appear at the head with the same verdict. None is missing.
   - The head adds 1,805 test names, all from PR #12. Every one passes, except exactly the two that the new CI lines name: one fails without its probe binary, and one skips itself.
   - The root package fails the same 27 tests at both commits, because this container lacks `ssh` and `uuidgen` (`19-audit.md` section 3).
6. **The guards still catch what they caught before.**
   - All seven probes of `17-audit.md` give the same result as there. The one probe that passes is the known O7-1 case, which draft PR #26 fixes and which is not on `trunk_dev` yet.
   - All 11 guard mutants I have used (C1 to C9, E1, E4) apply to the merged guard files and are caught.
   - The new pins refuse each of three wrong documents: "55" in the owner paragraph, the CI list unnamed, and "55" in `PLANS.md`.
7. **The merge commit alone trips exactly what the plan says.** Only two tests fail on it: PR #12's position-read test on PR #22's lines 108 and 153, and PR #23's startup-file test for `es/admission/internal/admissionstate`. The follow-up fixes both.
8. **CI is green.** The run of "build, vet and test" on head `2c8bf35` succeeded at 16:28Z. Its gate reports "all 17 listed tests still fail on this host, each in a run of its own and in the run of its package". This is the first run of the merged tree on the runner.
9. **Build, vet and the rest are clean on the exact bytes.**
   - Build and vet are clean for linux/amd64, linux/arm64 and darwin/arm64, and `gofmt` is clean.
   - The gate's self-test (121 tests) and its list check pass.
   - The race detector is clean on the six guard tests.

## 2. Audit target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Pull request | #28, draft, head branch `claude/project-thread-ne9cwa-pr12-trunk-dev`, base branch `codex/reliable-submit-operational-handoff-v1` (PR #12's branch) at `6288b632ee4c2c7a790d34a26248433fb68c2e27`. A vehicle for audit and CI only; PR #12's branch is to be fast-forwarded to its head |
| Audited head | `2c8bf35f30877bc3749b1799be686bf108a1cf8d`, tree `df3ff9dd042462534cb2eaece56295b78a6f018d`; remote head unchanged at the end (`git ls-remote`, 16:34Z) |
| Commits audited | merge `f36911c44ad899f93664f01e6a75f2065c17d9f5` (parents `6288b63`, `036d507`; tree `8c61971cba1e582ba85cd1ae91288a536cf59d7b`) and follow-up `2c8bf35` (6 files) |
| PR #12's head | `6288b63`, the merge of PR #13 (parents `8058561`, `e060449`), tree `24ab1e9b671a0f775f964d2310638f23fe02b336` = tree of `e060449` (`19-audit.md`, ACCEPT) |
| `trunk_dev` | `036d50724b499b020c5149c55ad902cfcb1482c0` (PR #25) at the start and at the end; it is the merge base of the head |
| Recipe | `governed-execution.audit-patch-manifest.v2`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked before every run |
| Base-relative manifest (vs `6288b63`) | `5e8504f83a4ca3b80f19c1245837ecc3562662624b55a7132d24b6a80af8fe31`, 78 paths, textual diff `2c5ba1da83179ed3ef42acbda69ac04702c06135ee1c4cc5e67e48499bd0673a` |
| Follow-up manifest (vs `f36911c`) | `dd821fbc4a9d7f257a07e36ea51bd10ddc3c64fd67bb165febde3b536220e009`, 6 paths, textual diff `3664d5cd630098427b1c0261f53ca535df9faa87e1c20dbac8ca3174eec658cd` |
| Trunk-relative manifest (vs `036d507`) | `7e9c3e19008c1029f7be709fa2694cc884f5e3bc16d825857f11bfa46f4d3999`, **56 paths**, textual diff `d5f62729cd2af91784a0ebfd7b5ef04c49f897883b7ceef116a77d1da73925a9` |
| Writer's material | PR #28's description; `18-trunk-dev-merge-plan.md` `b96af80f9509aba9a258a0b79dff48df55780af12b1ca263103a99c13f749659` (16:29Z; I first read the 15:58Z version `339a4cd4…8a8b`; the later one adds status, PR #26's new head and PR #29 notes, with no change to the steps); `18-trunk-dev-merge-gate.patch` `9a1761b35f9e1bf869352c86382fd338e3f4f335fcd676b5203a0b7502b3447a`; manifests in `18-repair-evidence/trunk-dev-merge/pr28-manifests/` |
| CI | workflow "go", run 45211082054 (run number 59, event `pull_request`), job "build, vet and test" 137819764518, head `2c8bf35`, success, 15:57:54Z to 16:28:48Z |

## 3. Audit posture

- Read-only. One thread, no subagents, no repository edits, no GitHub comments. The working copy was only fetched into.
- Manifests were taken in `/opt/audit/prov-repo`, with PR #28's branch checked out under `umask 022`. Everything else ran in throwaway clones under `/opt/ci/work/`.
- Each run was as the unprivileged user `ci` with an emptied environment: Go 1.26.5, `GOTOOLCHAIN=local`, `CGO_ENABLED=0` except the race run, linux/amd64, no Linux overlay.
- Tests started through `sigdfl.py` (HUP, INT, QUIT, TERM default; SIGPIPE and SIGXFSZ stay ignored).
- The two full suites ran one after the other, with nothing beside them. Probes and mutants ran after them.
- This container lacks `ssh`, `uuidgen` and `bindfs`. So the root package fails 27 Remote Alpha tests here at every commit. I compare root results only between my own runs.

## 4. Provenance reproduction

`prov21.sh` (evidence `scripts/`) checks the recipe hash before each of its six recipe runs. It also requires:

- a clean tree;
- the branch `claude/project-thread-ne9cwa-pr12-trunk-dev` at the remote head;
- the remote base at `6288b63`;
- `6288b63` and `f36911c` as ancestors.

It uses the writer's upstreams:

- base: `origin/codex/reliable-submit-operational-handoff-v1`, reset to `6288b63`;
- follow-up: the branch's own upstream, reset to `f36911c`;
- trunk: `origin/trunk_dev`, reset to the merge base `036d507`.

Each manifest runs twice, and HEAD and the upstream are restored after each pair.

| Run | Time | Result |
| --- | --- | --- |
| Opening | 16:00Z | All 15 files I compared byte-identical to `pr28-manifests/`: the six JSON files, three stdout files, three staged path lists and three staged trees. Each pair is identical; staged tree `df3ff9dd…` for all three; tree clean, HEAD and upstream restored |
| Closing | 16:34Z | The same 15 files byte-identical again |

The 56 trunk-relative paths are exactly the step-3 list of my trial run in `19-audit.md` section 9.5 (`trial-merge-036d507/tm19f-paths-step3.txt`). They are:

- PR #12's 53 paths;
- `es/admission/internal/admissionstate/testtmpdir_main_test.go`;
- `remote_alpha_es_service_tls_status_local_boundary_test.go`;
- `.github/ci/environment-only-tests.txt`.

## 5. The merge commit `f36911c`

| Check | Result |
| --- | --- |
| Tree against my own resolution | `8c61971c…`, identical to the tree of my strict resolver on `e060449` + `036d507` (`19-audit.md` 9.5). That resolver makes exactly two resolutions in `docs_contract_test.go` (count block: ours with the counted 39; adjacency block: both) and stops on any other block. So the merge holds those two and nothing else. `6288b63` has `e060449`'s tree, so merging from it gives the same result |
| Files changed against PR #12's head | 76, the same set of 76 that `trunk_dev` changed since the old merge base `ae326b0` (`runs/merge-file-check.txt`) |
| Changed only on `trunk_dev` (69) | each equals `036d507`'s blob |
| Changed only on PR #12 (46) | each equals `6288b63`'s blob |
| Changed on both sides (7) | combined: `docs_contract_test.go` (the two resolutions), and six merged cleanly by git: `.docs/execution_lifecycle/implementation.md`, `PLANS.md`, `reliablesubmit/replay_custody_file_test.go`, `reliablesubmit/sqlite_physical_test.go`, `es/admission/staging_custody.go`, `es/admission/workstream_c_guardrails_test.go` |
| `go.mod`, `go.sum` | unchanged by `trunk_dev`, so the reviewed dependency versions that PR #12's guard pins still hold (the guard passes) |

**`es/admission/staging_custody.go`, the one production file both sides changed.** I read `trunk_dev`'s change (PR #20, `bc9fe36`) and PR #12's additions.

- **PR #20:**
  - `ensureDirectory` and `writeFileWithHookAndParentMode` refuse any mode outside `stagedDirectoryModes` or `stagedFileModes`, the modes the startup probe proves.
  - `claimStagingCustodyFromQualifiedRoot` and `ensureDirectory` call `requireOpenedDirectoryOwnedByRootsUser` before `Fchown`.
- **PR #12:** it adds `qualifyOperationalStageParent`, `operationalStageParentIdentityMatches`, `measureOperationalStage`, `operationalStageEntry` and `appendOperationalStageIdentity`. They measure the staged tree (identity, mode, owner, digest). They create no entry and call neither restricted writer with a new mode.
- **Exact caller lists:** PR #20 added exact lists of callers for its new functions to `workstream_c_guardrails_test.go`. They pass on the merged tree, so PR #12 calls none of them from a new place.
- **Behaviour:** every operational handoff test passes on the merged tree, among them prestage recovery, stage residue and receipt recovery.

My conclusion is that the two changes do not interact. This rests on reading and tests, not on a proof.

## 6. The follow-up commit `2c8bf35`

| Check | Result |
| --- | --- |
| Against the corrected plan | `git apply --index 18-trunk-dev-merge-gate.patch` on `f36911c` gives tree `df3ff9dd…`, the head's tree. The patch now holds the CI lines itself, and the old separate CI list patch no longer applies on top (as the plan says: that step is gone) |
| Against my 19-audit trial run (`tm19f`, 55-path documents) | Only the owner document, `PLANS.md` and `docs_contract_test.go` differ (`runs/` diff of trees); the three code and CI files are byte-identical to what I tested there |
| Startup file | identical to `trunk_dev`'s `reliablesubmit/testtmpdir_main_test.go` apart from the package name |
| PR #22's file | exactly two lines: `fset.Position(e.Pos())` → `fset.PositionFor(e.Pos(), false)` and `fset.Position(expr.Pos()).Line` → `fset.PositionFor(expr.Pos(), false).Line` |
| CI list | the two lines and comments of `13-ci-list-two-lines.patch`; the gate's list check passes on the head (`runs/listcheck.log`); on `trunk_dev` alone it fails ("listed test is not defined", `19-audit.md` 6.2) |
| Owner paragraph | "It adds exactly three more paths, two test files and the CI's list: …, …, and .github/ci/environment-only-tests.txt, which gains two lines … With them the aggregate HEAD ceiling for PR #12 plus its repairs is 56 files." It matches the measured 56 |
| `PLANS.md` | the entry says three paths, 56 files, and that it "adds one test file, changes another, changes the CI's list of environment-only tests and changes documents" |
| Pins | owner statements each with a missing and a wrong-statement case (`MissingTrunkDevCIListPath`, `TrunkDevCIListPathUnnamed` and the renamed 56 cases); `PLANS.md` statements pinned |
| Pins against wrong documents (`scripts/pin21.sh`) | unchanged: both docs tests pass. Owner "is 56" → "is 55": both fail. Owner CI path unnamed: both fail. `PLANS.md` "is 56" → "is 55": the contract test fails |

## 7. Behaviour: full suite at the head against `trunk_dev`

The whole module (`go test -count=1 -json ./...`) ran at `2c8bf35` and then at `036d507` (`scripts/a21.sh`, `scripts/compare21.py`, `runs/compare.txt`).

| | `036d507` | `2c8bf35` |
| --- | --- | --- |
| All results | 5,478: 5,143 pass, 237 fail, 98 skip | 7,306: 6,969 pass, 238 fail, 99 skip |
| Root package | 2,021 pass, 235 fail | 2,236 pass, 235 fail |
| `es/admission` | 1,099 pass, 12 skip | 2,463 pass, 13 skip |
| `admissionstate` | none | 70 pass |
| `reliablesubmit` | 572 pass, 2 fail, 2 skip | 749 pass, 3 fail, 2 skip |
| Every other package | same | same (es/app 496 pass, 84 skip at both) |

- **Shared test names:** 5,478, which is every result of `trunk_dev`. The verdict differs on **0** of them, and **0** are missing at the head.
- **Names only at the head:** 1,805, giving 1,828 results (1,826 pass, 1 fail, 1 skip). They are 1,342 in `es/admission`, 215 in the root package, 178 in `reliablesubmit` and 70 in `admissionstate`. The two that do not pass are exactly the two the new CI lines name:
  - `TestOperationalHandoffSchema4BinaryRefusesSchema5` fails, because it needs its probe binary;
  - `TestOperationalHandoffChildProcess` skips itself.
- **Against my 19-audit trial run of the same packages:** exactly two entries differ, the two new pin subtests (`MissingTrunkDevCIListPath`, `TrunkDevCIListPathUnnamed`), both pass.
- **Root failures:** the 27 failing root tests (235 results) are the same at both commits. They come from this container (`ssh`, `uuidgen`). The writer's container shows 25 known environment tests, and the runner shows none.

**The merge commit alone** (`scripts/mo21.sh`; `es/admission` and `internal/testtmpdir`) fails exactly two top-level tests:

- `TestOperationalGuardReadsUnadjustedPositions`, on `remote_alpha_es_service_tls_status_local_boundary_test.go:108` and `:153`;
- `TestEveryTestPackageResolvesTheTemporaryDirectory`, "package es/admission/internal/admissionstate: has 0 TestMain functions".

Nothing else trips. That matches plan step 3: "only PR #22's two reads trip a guard", plus the startup file.

## 8. Guards: earlier probes and mutants on the head

**Probes of `17-audit.md`** (`scripts/p21.sh`, the same probe files; `runs/<probe>.log`), each in its own clone of `2c8bf35`:

| Probe | 17-audit at `d314590` | Here at `2c8bf35` |
| --- | --- | --- |
| `a6new` (A6-1 `//line` raw pointer files, linux and darwin) | raw pointer rule and directive check refuse | same; the refusals name the real files `es/runtimehelper/zz_line_linux.go:11:1` and `es/admission/zz_line_darwin.go:19:1` |
| `bpnew-dir` (binding producer helper under a directive) | binding guard and directive check refuse | same |
| `bpnew-ctl` (the helper without a directive) | binding guard refuses | same |
| `wsanew-dir` (Workstream A term under a directive) | Workstream A guard and directive check refuse | same |
| `wsanew-ctl` (the term without a directive) | Workstream A guard refuses | same |
| `wsanew-same` (the term with an allowed name in a comment on the same line) | passes (O7-1) | passes (O7-1; draft PR #26 fixes it, not on `trunk_dev`) |
| `cover` (directives in `testdata`, `_`, `.` dirs and a cgo file) | all four refused | all four refused |

**Mutants** (`scripts/m21.sh`, `mutate17.py`, `mutate19.py`; six guard tests, 78 results unmutated):

- base: 78 pass;
- C1 to C9 (17-audit) and E1, E4 (19-audit): every one applies to the merged guard files and is caught. One to eleven results fail each; the failing tests are listed in `runs/mut-*.log`.

## 9. CI

The single required check, "build, vet and test" (run 45211082054, job 137819764518), ran on the `pull_request` event for head `2c8bf35`. It concluded **success** at 16:28:48Z.

The job log's tail shows the gate's final run of the listed tests:

- the three `reliablesubmit` probe-binary tests, `TestOperationalHandoffSchema4BinaryRefusesSchema5` among them, "still fail";
- the three listed `es/app` tests "still fail";
- "all 17 listed tests still fail on this host, each in a run of its own and in the run of its package".

The run checked out the pull request's test merge. The base `6288b63` is an ancestor of the head, so that merge has the head's tree. This is inference from the history; I did not read the checkout step.

## 10. Notes for what comes next (not findings)

- **N21-1. PR #26 moved during this audit,** from `0aba38e` to `c99a1b4` ("Allow PolicyDecision only for the seam objects…"). It still touches only `workstream_a_guardrails_test.go`.
  - Against this head, `git merge-tree` shows the same two blocks the plan describes. Its added lines hold no other adjusted position read.
  - I read this; I did not run it. The plan's 16:29Z version reports that the writer ran this merge: the same two blocks, `es/admission` 2,505 pass, and still 56 paths. If PR #26 lands on `trunk_dev` before PR #12, re-check that case at that time.
- **N21-2. Merging into `trunk_dev`.** The required check needs an up-to-date branch. Any further move of `trunk_dev` before PR #12's own merge passes PR #12's guards for the first time and needs the same narrow re-check (plan step 3).
- **N21-3. Draft PR #29** (ARS blob byte verification, `f8c1a73` on `036d507`) adds a guard that reads all of ES's production code, so it will judge PR #12's code too. The plan reports that PR #29's writer trial-merged it on this head and the guard passes. I did not check that. Whichever of PR #29 and PR #12 lands second must re-run that guard after its merge.
- **O7-1 is still open on this head,** as the `wsanew-same` probe shows. It is unchanged from `17-audit.md` and is the subject of PR #26.

## 11. Final verdict

**ACCEPT** `2c8bf35` (tree `df3ff9dd042462534cb2eaece56295b78a6f018d`), the merge of `trunk_dev` `036d507` into PR #12's branch.

- The merge commit holds only the two known resolutions. The follow-up is exactly the corrected plan, and M19-1 is fixed.
- No `trunk_dev` result changes. Every new result passes, except the two the new CI lines name.
- The guards catch every earlier probe and mutant as before.
- CI is green.

No finding. The fast-forward of `codex/reliable-submit-operational-handoff-v1` from `6288b63` to `2c8bf35` needs David's go. It should land on exactly this head and tree, and only while `trunk_dev` is still `036d507`; otherwise re-check per plan step 3.

## 12. Evidence files

`21-audit-evidence/` (`SHA256SUMS` lists every file):

- `scripts/`: `prov21.sh`, `a21.sh`, `p21.sh`, `m21.sh`, `mo21.sh`, `pin21.sh`, `compare21.py`, `listcheck.py`, `mutate17.py`, `mutate19.py`, `sync.sh`, `cirun.sh`, `sigdfl.py`, `summ.py`.
- `manifests/open/`, `manifests/close/`: my manifests, stdout, staged lists and trees.
- `probes/`: the probe files of `17-audit.md`.
- `runs/`:
  - the step log `a21-steps.log`;
  - build, vet, gofmt, gate self-test, list check and race logs;
  - the full-suite summaries and TSVs at both commits;
  - `compare.txt` and `merge-file-check.txt`;
  - probe, mutant, merge-only and pin logs;
  - the follow-up diff;
  - `ci.txt`.
