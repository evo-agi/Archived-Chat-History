# PR #12 repair round (draft PR #40 at `fd399a1`): audit 30

Written 2026-11-23 from 22:22Z onwards by the independent audit thread "Audit Execution-Substrate PRs", after the coordinator's request. Read-only: nothing was pushed, commented, reviewed or merged. Evidence is in `30-audit-evidence/` next to this file. My local names carry the tag `40a`.

Subject: `29-repair.md` (the writer's report), on draft PR #40 into PR #12's branch. The report asked for: RT28-1 and RT28-2 from `28-redteam.md`, G28-1 and G28-2 from `28a-guard-coverage.md`, the red-team's tests adopted byte for byte, two `trunk_dev` merges, the blob-read guard, a judgement on the two surviving mutants, and whether N-1 is really forced.

## Verdict

**REPAIR NEEDED, test-only: the product repairs hold, and one new test is flaky (A30-1, Medium).**

- **RT28-1 holds.** Every request string that reaches the Nomad job is checked:
  - each `argv` element;
  - every `env` key and value;
  - `output_id`;
  - every mount target.

  These are refused on `${`, `%{` and NUL on both paths, before anything is staged or sent. Every other string in the job comes from ES constants, the operator's configuration, hex run names or digests.
- **RT28-2 holds.** The size check runs before the claim, measures with names of the real lengths, and is pinned by mutants:
  - removing the check is caught;
  - a shorter name shape is caught;
  - a host context with shorter paths is caught (my mutant X4);
  - the canonical measure, which the writer rejected, is caught.
- **G28-1 and G28-2 are closed.** The adopted fix is my own proposal, byte for byte. Audit 28a's `//go:cgo_import_dynamic` probe is now refused on the head.
- **The red-team's tests are adopted byte for byte.** Each patch applied to its commit's parent gives exactly that commit's tree, and none of the adopted files changed afterwards.
- **The merges are clean.**
  - The first merge differs from git's own merge only in the `PLANS.md` conflict, which is resolved as a plain union of both entries.
  - The second merge (#36) is exactly git's merge.
- **The blob-read guard still holds.**
  - It passes on the head.
  - It catches a second blob read planted in a PR 12 file (B1).
  - It catches one planted in PR 12's new package `internal/admissionstate` (B2).
- **The two surviving mutants (F3, F4) are acceptable.** They are equivalent under the current bounds: no input can reach the body bound while Job0 is bounded. My probe found the canonical form never longer than `encoding/json`'s for every single byte and 200,000 random strings.
- **N-1 is forced.** I trial-merged PR #31's head into `fd399a1`. Its guard `TestEveryNomadRequestPathGoesThroughTheTokenBuilder` then fails, naming exactly the three tokenless private requests.
- **Whole module against `trunk_dev` `400ff7f`:**
  - no test that exists on both sides changed its result;
  - the 238 shared failures have identical output;
  - 2,106 results are new.
- **A30-1 (Medium, test-only):** `TestOperationalJobBoundIsCheckedBeforeTheClaimAndAgreesWithTheProjection`, new in this round, fails at random.
  - With the default `/tmp`, which CI also uses, it failed 17 of 30 runs.
  - With the writer's 11-character temp path, it passed 20 of 20.
  - Its exact-equality assertion depends on the length of a random temporary path.

  It must be fixed before merge, or CI goes red at random on PR #12 and every PR after it. CI run 45278645109 on `fd399a1` passed (check run 138056957260, 22:20Z to 22:53Z). CI's gate fails when any unlisted test does not pass, so this test ran and passed there once. One green run fits a test that passed 13 of 30 times here. It does not show the test is stable.
- **Public contract change:** RT28-1 refuses requests that ES accepted before. It is stated in both contracts documents and pinned. Whether this needs David's eye under the merge policy is the coordinator's call.

## In plain words

The fixes do what the red-team and I asked:
- ES refuses the strings Nomad would rewrite.
- A request too large for a job no longer takes a claim.
- The compiler-directive hole is closed.
- The red-team's tests went in unchanged.
- The trunk merges add nothing hidden.
- The blob-read guard still works.
- The Nomad token fix can't be forgotten: whichever of PR 12 and PR #31 lands second fails CI until the private requests carry the token.

One problem: a new test of the size check compares two numbers that differ by one depending on the length of a random temporary folder name. It fails more often than not in this container, and CI uses the same `/tmp`. It's a small test fix, and the red-team re-check doesn't need to wait for it.

## Target

| Item | Value |
| --- | --- |
| PR | evo-agi/Execution-Substrate #40 (draft) into `codex/reliable-submit-operational-handoff-v1` (PR #12 at `44166998`) |
| Head | `fd399a12b5fc8319d403de471bb3ce42446f350c`, tree `dc6e1b6ea6ea34c4fb22020e06f27957a12a3754` |
| `trunk_dev` | `400ff7faa0f124b10dbb607fbad009e346bac4df` (the merge base of the head and `trunk_dev`) |
| Recipe | v2, source SHA-256 `c08597e2…a1a3ca`, verified before every run |
| Trunk-relative manifest | `20fd4ee4eebfdda5cf248c48ae91dafc9d7a2b47760d89e622221df0e759b93e`, 66 files, textual diff `42a26fd8…c1e1`, upstream `origin/trunk_dev` |
| PR-relative manifest | `35c3e1f79abdfe9033d5c9e5e858262ce4523a7f059f5cb5f947a213a4062b41`, 80 files, textual diff `b38b7ca6…ed43`, base `4416699`, upstream `origin/codex/reliable-submit-operational-handoff-v1` |
| Toolchain | Go 1.26.5, `GOTOOLCHAIN=local`, `env -i`, user `ci` (1500:1600) |

**Manifests.**
- Each was taken twice in `/opt/audit/es`, with the head bytes in the working tree, HEAD reset `--mixed` to the base, and the upstream pinned. The runs are byte-identical, and both match the writer's values.
- For each, `git add -A` staged exactly the manifest's paths, and `git write-tree` gave the head's tree.
- `git status --porcelain` was empty afterwards.

Refs were checked at the start (`ls-remote-open.txt`) and at the end (`ls-remote-close.txt`). PR #40's head and PR #12's head did not move.

**`trunk_dev` moved during the audit**, from `400ff7f` to `0aa4a2b` (PR #33, which changes only two test files in `es/config`). PR #40 changes no `es/config` file. `git merge-tree` merges `fd399a1` and `0aa4a2b` with no conflict, and on that tree `go vet ./es/config ./es/admission` is clean and `go test ./es/config` passes (`trunk0aa4a2b-trial40a.log`). So the next `trunk_dev` merge into PR #12 should be routine.

**The copy I tested** (`/home/ci/t40a`) was checked file by file against `fd399a1`, by blob hash and exact permission bits: 527 entries, 0 differences, 0 extra files (`tree-check.txt`).

## Adoption and merges

`adoption-check.txt` applies each patch with `git apply --cached` to the commit's parent and compares trees:

| Patch (SHA-256) | Onto | Gives the tree of |
| --- | --- | --- |
| `28-redteam-regression-tests.patch` (`1e520116…d708`) | `39f6872` | `9116a46`, identical |
| `28-redteam-finding-tests.patch` (`6e94a4f6…f648`) | `3ddbd2e` | `8e6105c`, identical |
| `guard-directive-allowlist-proposal.diff` (`242c7444…dae4`, audit 28a's file) | `8e6105c` | `e121e2b`, identical |

- **No later edits.** The five red-team test files and `workstream_c_guardrails_test.go` are unchanged from those commits to the head. Only the owner document changed afterwards, with the round's reconciliation in `d3af16a`.
- **Merges** (`merge-checks.txt`):
  - `39f6872` against `git merge-tree --write-tree 4416699 fdfa3bc`: the only difference is `PLANS.md`, where the three conflict markers are removed and one blank line separates the two entries. That is a union, with PR #12's entries first.
  - `fd399a1`'s tree is exactly `git merge-tree --write-tree d3af16a 400ff7f` (`dc6e1b6e…`).

## RT28-1: request strings Nomad would rewrite

I traced every string in `buildNomadJobSpec`.

**Caller strings, all checked:**
- `Config.args`: `newResolvedRuntimeCommand`'s fixed supervisor arguments, then the request's `argv`. Checked per element.
- `Env`: the request's `env`, then the runtime profile's environment, then ES-set keys. Request keys and values are checked.
- Task `Meta.output_id`: checked.
- `Config.mounts[].target` for governed mounts: `normalizeRuntimeMountTargetPath` checks the cleaned path, which is the value placed in the job. `path.Clean` cannot join a `$` and a `{` across a `/`, so it cannot create an opener.

**Strings ES builds itself:**
- Mount `source`s are `stage/…/mounts/NN/contents` by index.
- Job and run names are hex.
- Meta holds digests and the runtime profile name.

**Operator configuration:** the runtime profile's image and environment, the Vault values and the host paths are not checked. No caller can reach them.

**Checks:**
- `validateInvocationAgainstManifest` is shared by the ordinary and the private path. The writer's reflection test fails on any new unclassified string member of `PrepareRequest`.
- The writer's mutants R1 to R8 (removing each opener, NUL, and each field's check) are all caught in my re-run (`mut40a.log`).

## RT28-2: the size check before the claim

- **Where it runs.** `fits` runs right after composing the original, before `EstablishOperational`. It uses the same `resolved` value, so the same plan and host, that the projection uses after assignment. Only the stage, job name and correlation value differ, and `OperationalLocatorShape` and the 64-character correlation value give them their real lengths.
- **Mutants that change what it measures** are caught:
  - F5, a shorter shape;
  - my X4, an empty host context, which shortens every staging path: the largest request that "fits" then takes a claim and fails (`extra40a.log`);
  - F6, the canonical measure.
- **The two run-projection inventories** now name `operationalProvider.fits`, and the admission model sentence says it projects once more and sends nothing.
- **Inference, operator side only:** a claim recovered after a restart is projected with the host configuration of that time. A longer staging root configured between the claim and the recovery could then exceed the bound. That is an operator change, not a caller input.

**F3 and F4 survive, and that is acceptable.**
- Under the current bounds, both are equivalent mutants, not untested code.
- The POST body is the canonical form of the parsed Job0 plus the correlation entry and a fixed envelope.
- The canonical encoder (`appendOperationalJSONString`) writes:
  - two-byte escapes for `"`, `\`, `\b`, `\f`, `\n`, `\r` and `\t`;
  - six bytes for other control bytes;
  - every other byte as itself.
- `encoding/json` writes each byte at that length or longer.
- My probe (`jsonprobe40a.log`) compared the two for every single byte, ten edge runes and 200,000 random strings. The largest ratio was 1.000. So a Job0 within 65,536 bytes gives a body of about 65,800 bytes at most, far under 131,072, and no test can reach the body check.
- Optional nit: a one-line test that `operationalBodyLimit` exceeds `operationalJobLimit` plus the envelope would make a future change to either constant revisit this.

## G28-1 and G28-2

The guard file is my proposal, unchanged. On the head (`guard40a.log`):
- the ten raw-memory guard tests pass;
- with audit 28a's probe A (`//go:cgo_import_dynamic _ _ "libzz40a.so"` in `es/app`, no import), `TestOperationalGuardProductionFilesHoldOnlyReviewedCompilerDirectives` fails and names the file and verb.

This round's new production code adds no `//go:` directive.

## Blob-read guard (PR #29)

- `ars_blob_fetch_test.go` and `ars_blob_fetch.go` are unchanged from `fdfa3bc` to the head.
- The only `/v1/blobs/` read in `es/admission` production code is in `fetchVerifiedARSBlob`.
- The guard's three tests and the four ARS docs pins pass in the full run.
- Planted reads are caught (`extra40a.log`):
  - B1, `s.arsClient.get(ctx, "/v1/blobs/…")` in `reliable_submit_operational_provider.go`;
  - B2, a `/v1/blobs/` literal in `es/admission/internal/admissionstate/state.go`.

## N-1: the Nomad token is forced

- PR #31's head `c3a94ae` merges into `fd399a1` with a conflict only in `PLANS.md`. I resolved it for the trial as a union.
- On that tree (`n1guard40a.log`), `go vet ./es/admission` is clean, and `TestEveryNomadRequestPathGoesThroughTheTokenBuilder` fails, naming:
  - `reliable_submit_operational_handoff.go:672` (`/v1/jobs`);
  - `reliable_submit_operational_provider.go:650` (`/v1/job/`);
  - `reliable_submit_operational_provider.go:685` (`/v1/job/`).
- Those are the three private requests.
- ES requires the check "build, vet and test" and up-to-date branches. So whichever of PR 12 and PR #31 merges second cannot go green until these three go through a token-setting builder.
- Limit: the guard matches Nomad API path literals. A request whose path is built without those literals would not be named. None exists today.

## Whole module against `trunk_dev`

`full40a.sh` and `cmp40a-full.txt` compare against `400ff7f` (`f39c-base`, the same container and toolchain, on a copy with exact git modes):

- `trunk_dev`: 6,677 pass, 238 fail, 92 skip (7,007 results).
- Head: 8,780 pass, 240 fail, 93 skip (9,113 results).
- 0 results lost and 0 changed among tests on both sides. All 238 shared failures have identical normalised output: Remote Alpha host-only tests, two probe-binary store tests, and one `es/app` bring-up.
- The 2,106 new results:
  - 2,103 pass;
  - `TestOperationalHandoffChildProcess` skips, a helper on CI's list;
  - `TestOperationalHandoffSchema4BinaryRefusesSchema5` fails without its probe binary, which is on CI's list;
  - `TestOperationalJobBoundIsCheckedBeforeTheClaimAndAgreesWithTheProjection` fails: A30-1.
- This matches the writer's run, except for A30-1.
- Targeted passes on the head:
  - the three blob-read guard tests and the four ARS docs pins;
  - `TestNomadEvaluatedRequestStringsContract`;
  - the two run-projection inventories;
  - the reliable-submit 39-file pin;
  - every `TestRedTeamPR12…` and `TestOperationalGuard…` test.

**Owner reconciliation.** The trunk-relative path set has 66 entries. Against the 56 at `4416699`, ten are added and none is gone. They are exactly the ten the owner paragraph names: `mounts.go`, the two contracts documents, the two new test files, and the red-team's five files.

## Findings

### A30-1 (Medium, test-only): the new job-bound test fails at random

**What happens.**

`TestOperationalJobBoundIsCheckedBeforeTheClaimAndAgreesWithTheProjection` bisects the largest argument that fits for `a`, `<` and `\x01`, then requires `largest["html"] == largest["control"]`. Each subtest builds its own fixture. Results:
- `jobbound40a-repeat.log`, the same binary 30 times with `TMPDIR` unset (`/tmp`): 13 passes and 17 failures. In each failure, `html` and `control` differ by exactly one, either way round, for example `control:10367 html:10368`. Even `plain` moves between 62,207 and 62,209 from run to run.
- `jobbound40a.log`, `TMPDIR` of 10 to 16 characters: the length-13 run failed.
- `jobbound40a-len11.log`, an 11-character `TMPDIR` like the writer's `/opt/ci/tmp`: 20 of 20 pass, which is why the writer's runs were green.

**Cause.** Inference: the job holds paths under the fixture's temporary directory. `os.MkdirTemp` names it with a random decimal number whose digit count varies, so the job's fixed part differs by a few bytes between subtests and runs. With six bytes per `<` or `\x01`, that moves one subtest's bound by one character when it crosses a multiple of six, depending on the path length.

**Effect.**
- CI's workflow sets no `TMPDIR`, so CI's tests run under `/tmp`, the setting that failed 17 of 30 here.
- A required check that fails at random blocks PR #12's merge and every later PR that contains it.
- It also invites reruns until green, which hides real failures.
- The mutant verdicts that use this test are sound only where it is stable, which is why I ran the mutants under an 11-character `TMPDIR` (baseline 71 of 71 pass).

**Suggested fix:** make the comparison independent of the fixture's paths. Either of these works:
- bisect `<` and `\x01` on one fixture, the same staging root, before the completion submits;
- compare their bounds with a tolerance of one character, and say why.

Then run the test 30 times under `/tmp` and under a few `TMPDIR` lengths. The rest of the test, the completion at the bound and the refusal one byte over, is sound and should stay.

## What I did not cover

- RT28-1 against a live Nomad (writer's section 8). I read Nomad's behaviour only through the writer's and red-team's reports. The live check on the box needs David's go.
- The red-team re-check of RT28-1 and RT28-2 follows this verdict.
- I did not re-run `go vet` or the race detector for every target. CI runs vet.
- I trusted the writer's search of the six local repositories for callers that use `${`, `%{` or Nomad variables. I did not repeat it.

## Sensitive material

The probes and mutants are synthetic. No key, certificate body, token, env file or config file is copied into the evidence. Commit-message trailers and author names are left out. The report and evidence were scanned with the thread's pattern list and a positive control before delivery.
