# DOCUMENTS-ONLY CHANGE AFTER THE FIFTH AUDIT OF PR #13: the limit A5-1 is named, and two CI list lines are prepared

Status of this file: **IMPLEMENTATION REPORT, NOT AUDITED.** It covers one commit after the audited tip `bff8dda`, and a prepared patch that is committed nowhere. `11-repair.md` stays the report of everything up to `bff8dda`, and `12-audit.md` (verdict ACCEPT) is its audit.

Written by the PR #13 writer thread on 2026-11-23 (UTC). Readers: the coordinator, David, the audit thread that judges the delta, and the red-team thread.

---

## 1. In plain words

The audit of `bff8dda` accepted the pull request and left one low finding (A5-1). A program can write its own memory through the operating system. A function that does so cleared the withdrawal latch of a withdrawn Service in the auditor's probe, with no `reflect`, `unsafe` or cgo import and without naming a protected field. Neither the compiler nor the guard holds that road, and the documents did not name it.

The coordinator asked for two things, and for no code change while the red-team works on `bff8dda`.

**1. The limit is named now, in one commit, `51d6d5f`.** It changes three files: the owner document, `PLANS.md` and the docs contract test. No production file and no guard file changed, and section 4 shows how that is checked. The owner document now says that the package border is a border of the language and not of the process, that every production file of the module and every dependency is inside the trust boundary of the admission state, and that nothing may rely on the border against code of lower trust in the same process. No guard rule is added, because no source inventory can hold this road in general. The audit asked for none.

**2. The two CI list lines are prepared as a patch** (`13-ci-list-two-lines.patch`, section 6). They cannot be committed on this branch, because the list file exists only on `trunk_dev`. They belong to the change that brings `trunk_dev` into PR #12's branch. I tried them with the gate's own code on a trial merge.

**The reading I chose, and its consequence.** The audit offered two places for the sentence: the next change of PR #12's branch, or "a documents-only repair on this branch". I read the coordinator's note as the second. So **the head of PR #13 is no longer the audited `bff8dda`.** It is `51d6d5f`, one commit later. The audit's merge gate (its section 7.7, item 1) and its stop condition name `bff8dda`, so the delta of three files needs its own narrow audit, and the gate has to name the new head and tree. The red-team's target is not affected: `bff8dda` is still on the branch, and every file outside the three is byte-identical at both commits.

**Not done, on purpose:** the audit's optional O5-1 (a comment in `state.go`). That file is production code and the guard holds it by its hash, so changing it would change code during the red-team. Section 7 lists it with the other open points.

Nothing was merged. No branch other than `claude/project-thread-sqldt7` was pushed.

## 2. Identity

| Field | Value |
| --- | --- |
| Objective | Carry out correction C1 of `12-audit.md` (finding A5-1) and its optional O5-3 as a documents-only change, and prepare the two CI list lines of its section 7.7 |
| Repository | `evo-agi/Execution-Substrate` |
| Base ref and SHA | `codex/reliable-submit-operational-handoff-v1` at `8058561edc08356c46680c204586b3c7796c0ff3` (the PR #12 branch) |
| Audited tip this change starts from | `bff8dda37dbf5484afb3b264d4eca38cf6abf118`, tree `38269372c5bc21f291e1b73e93cf48d78180649d` |
| Topic branch | `claude/project-thread-sqldt7` (draft PR #13) |
| Topic commit SHA | `51d6d5fcb5d7e59e70fd53e1cd2801044a03e23a` |
| Tree SHA | `c133a2dfcd1a1eb03151b7d74987c75b7dc00604` |
| Commit after `bff8dda` | `51d6d5f` Name the limit of the admission state border: writes to the process's own memory |
| Final working-tree status | clean (`git status --porcelain` empty after the push and after the manifests) |
| Recipe | `governed_execution_audit_patch_manifest_v2.py`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified before every run |

## 3. What changed

| File | Added | Removed | What |
| --- | --- | --- | --- |
| `.docs/execution_lifecycle/reliable_submit_operational_handoff.md` (the owner document) | 29 | 3 | The limit, in two places; the wording on type-checking |
| `PLANS.md` | 29 | 0 | One new entry at the top of the status list |
| `docs_contract_test.go` | 32 | 3 | The pins for every new statement |

All three are among the 28 paths of the pull request, so the frozen path scope is unchanged: 28 paths against the base, 48 against the trunk merge base.

**The owner document, section on the admission state package.** After the paragraph on reflection and `unsafe`, a new paragraph:

> Neither the package boundary nor any inventory below holds against code that writes the memory of its own process without going through the language. The compiler and the inventories read Go source, and such code needs none of the forms they look for. The fifth audit showed it on linux/amd64 with one production function that opens `/proc/self/mem` and writes at the address of the state: the withdrawal latch of a withdrawn Service was cleared, and its check of current admission answered true again. The function imports neither `reflect`, `unsafe` nor `C`, names no protected field, and in its form with `syscall` changes the result of no test. No source inventory can hold that road in general, because the path can be put together at run time and the operating system offers other ways to the same memory. By reasoning, not by measurement, the same is true of a data race that breaks Go's memory safety and of code loaded at run time. Every production file of the module and every dependency is therefore inside the trust boundary of the admission state. The boundary is one of the language, not of the process: nothing may rely on it against code of lower trust in the same process. A control against such code would have to come from the operating system, and none is claimed here.

What is measurement and what is reasoning in that paragraph follows the audit: the write through `/proc/self/mem` was measured by the auditor on linux/amd64, in two forms. The data race and the code loaded at run time are the auditor's inference, and the paragraph says so. I ran none of it myself; the auditor's probe files are data to me.

**The owner document, list of limits.** One sentence group before the closing sentence on the maintained guarantee:

> One limit has no inventory at all: a write to the memory of the process that does not go through the language, which the section on the admission state package describes. It needs no `reflect`, `unsafe` or `C` import, so the import inventory does not see it, and no inventory reads what such code does.

**The owner document, the forms that must not compile (O5-3).** The document said a test holds them "by compiling each form". The test type-checks them with the standard library's type checker. The sentence now reads: "by type-checking each form against the real packages for all three build targets, beside controls that pass. It uses the type checker of the standard library (`go/types`), which follows the same language rules as the compiler; it does not run the compiler itself."

**`PLANS.md`.** A new entry, "PR #12 durable admission: a limit named after the fifth audit (2026-11-23)". It says what the audit found, that the road is older than the package, that no guard rule is added and why, and that the entry changes documents and the docs contract test only. It does not edit the entry below it, which follows how the earlier corrections were recorded.

**`docs_contract_test.go`.** The test holds a statement of the owner document in three ways, as for its neighbours:

- the owner rule requires the phrase (9 phrases: 7 for the limit, 2 for the type checker, one of the two replacing the old "compiling each form");
- a case removes the phrase and the rule must fail (9 cases, 8 new);
- a case replaces the phrase by the wrong statement and the rule must fail (9 cases, 8 new), for example "The package boundary and the inventories below hold against code that writes the memory of its own process", "is nevertheless outside the trust boundary", "The boundary is one of the process", "Every limit has an inventory", "it runs the compiler itself".

Five phrases of the new `PLANS.md` entry are required as well. That makes 16 new subtests.

## 4. Why this is no code change, and how that is checked

- `git diff --stat bff8dda 51d6d5f` lists exactly the three files above (`13-repair-evidence/delta.diff`).
- The Git tree of the directory `es` is `06a66f84283c29540c7eabe68165ce9416da5020` at both commits, and the tree of `cmd` is `057faac398f506b747930e69d26af69ad6e37c88` at both. So no production file, no guard test and no test of `es/admission` or of the store moved by a byte.
- `docs_contract_test.go` is a test file of the root package. It reads documents and compares text. I found no guard that reads it: the one test under `es/` that walks Go files of the repository for text skips this file by name, and no test of `es/` changed its result (section 5).
- The delta manifest of the recipe against `bff8dda` has 3 files (section 8).

A test file is Go, so "documents only" is true in the sense the audit used it for C1 ("hold the phrase in `docs_contract_test.go` like its neighbours"), and I say it in this narrower sense everywhere.

## 5. Validation (Linux, Go 1.26.5, no CI)

| Check | Command | On | Result |
| --- | --- | --- | --- |
| The pins fail first | `go test -count=1 -run '^TestOperationalSubmitHandoffCurrentAdmissionV2' .` | copy of the tree with the test change and the old documents | exit 1: both tests fail, with the 18 subtests that were added or changed (`red.out`) |
| The pins pass | the same | copy of the final tree | exit 0: both tests pass, 146 subtests (`green.out`) |
| Format, whitespace | `gofmt -l docs_contract_test.go`, `git diff --check` | working tree before the commit | no output |
| Every package of the module | `go test -count=1 -json`, in three runs: the root package, `./es/... ./cmd/...`, and all other packages | copy of the final tree (the diff of the working tree had the same SHA-256 as the diff that was committed) | 6,802 results: 6,595 pass, 166 fail, 41 skip. Packages: 20 pass, 2 fail, 20 without tests |
| Against `bff8dda`, by package and test name | `suite-compare.txt`, `suite-compare.tsv` | the full suite of `11-repair.md` against the three runs | no name gone; 16 new names, all pass, all in the root package; the same 166 known failures; the same 41 skips; one test changed its result (below) |

The one changed result is the known timing test `TestRemoteAlphaESServiceTLSStatusCombinedGroupSignalFailureLiveDescendant` with its subtest `term`. It failed in the one full suite of `11-repair.md` and passes in this run. Nothing of this change can touch it, and the audit saw it pass once and fail once (its O5-6).

The store package compiles on Linux only with the one-file overlay, as in every earlier run. The three runs were not made in one go: I first ran the root package and `./es/... ./cmd/...`, saw that this leaves out the packages `ags`, `ars`, `cgs`, `egs` and `internal`, and ran those before the push.

**Not run:** the race detector, the mutants and the probes of `11-repair.md`. No file they exercise changed (section 4). `go build ./...` and `go vet` were not run again for the same reason; the root test file compiled in the runs above. Nothing ran on macOS. No CI ran: this branch has no workflow file.

## 6. The two CI list lines

`trunk_dev` has a CI gate that fails on a test that fails or skips itself on the runner unless `.github/ci/environment-only-tests.txt` lists it. The file does not exist on PR #12's branch or on this one. When PR #12 picks up `trunk_dev`, two tests of the handoff need a line each, as the audit says (its section 7.7, item 7).

**The patch** is `13-ci-list-two-lines.patch`, against the file as of `trunk_dev` `bc9fe36` (Git blob `e6d72d801d6e63cff719834dc81fd1cbfd7bf5da`). It adds:

```text
execution-substrate/es/admission/internal/reliablesubmit TestOperationalHandoffSchema4BinaryRefusesSchema5
skips-itself execution-substrate/es/admission TestOperationalHandoffChildProcess
```

The first goes into the existing group of the store's historical-opener probes, whose comment I extended by one sentence. The second gets a group of its own in the part for tests that skip themselves, with its reason as a comment, as the file's rules ask.

**From the tests' own code.** `TestOperationalHandoffSchema4BinaryRefusesSchema5` calls `t.Fatal` at its first check when `ES_REPLAY_SCHEMA4_PROBE` is empty, so its failure is one the testing package reports, which the list requires of an entry. `TestOperationalHandoffChildProcess` calls `t.Skip` unless `ES_OPERATIONAL_CHILD_FIXTURE` is set; tests of the package start the test binary a second time with that variable.

**From my own measurements at `bff8dda`** (`11-repair-evidence/full-suite-compare.tsv`): outside `es/app` exactly three tests skip themselves, this one and the two store helpers that the list already names. In the store package exactly three top-level tests fail, this one and the two that the list already names.

**Tried with the gate's own code.** On a trial merge of `trunk_dev` `bc9fe36` into `bff8dda` in a scratch clone (never pushed; its tree is `eec14cb271a8986fd6e04a6910ee99ffc0b7c3d7`, the tree the audit reports for the same merge), with `GOFLAGS=-mod=readonly` and `GOTOOLCHAIN=local` as in the workflow:

| Step | What ran | Result |
| --- | --- | --- |
| The whole patched list is well formed | the gate's parser and its check of the list against every package of the module | 16 entries and 42 lines for tests that skip themselves; every named test is defined exactly once (`ci-lines/gate-check.out`) |
| Gate, store package, with the lines | the gate's function `gate`, limited to two packages | the package passes with the three entries skipped, and the tests that skip themselves are exactly the two listed |
| Gate, `es/admission`, with the lines | the same call | `go test` passes (256 s). `TestOperationalHandoffChildProcess` is among the listed skips and is not reported. **The gate still exits 1 here,** because six other tests skip themselves in this container: five need `bindfs`, which the workflow installs on the runner, and one needs a supplementary group that the user of my container does not have. All six came with `trunk_dev`, whose CI is green with them unlisted. |
| Listed tests still fail | the gate's function `still_failing`, same two packages | exit 0: "all 3 listed tests still fail on this host, each in a run of its own and in the run of its package" |
| Control without the new entry | `gate` on the store package with `trunk_dev`'s lines only | exit 1: `TestOperationalHandoffSchema4BinaryRefusesSchema5` fails and the gate fails the package |

I limited the gate to two packages with a small driver (`ci-lines/gate_two.py.txt`) that loads the gate script and replaces only its list of the module's packages. The lists I gave it hold the lines of those two packages only. My first control run failed for a reason of my own (its list still held lines of a package I had not selected); its output is kept as `gate-control-store.first-try.out`.

**What this does not show.** My container is not the runner. Whether these two lines are the only ones the merged branch needs is known only when CI runs there. I did not run a control for the skip line; that an unlisted skip fails the gate is the gate's own rule, and the six container skips above show it at work.

**The same patch applies to the new tip.** A trial merge of `trunk_dev` `bc9fe36` into `51d6d5f` is textually clean as well (tree `0567f1b68d078cfb3e188b310bfd703c527040db`). It differs from the first trial merge in exactly the three files of this change, and the handoff docs tests pass on it (`merge-docs-tests.out`).

**Nothing forgets these lines:** the required check "build, vet and test" fails on the merged branch without them, so the change that brings `trunk_dev` in cannot merge until they are there.

## 7. Not done, and open points

- **O5-1 is not done.** It asks for two words in a comment of `state.go` ("an untyped nil owner"), or a test of the pointer. `state.go` is production code and the guard pins its SHA-256, so the change moves a production file and a guard file. The coordinator asked for no code change during the red-team. It is a comment with no effect on behaviour, and it can ride with the next change of code on this branch, if the red-team asks for one. If none comes, it needs a decision: change it before the merge with a re-audit of two files, or leave the comment as it is.
- **The merge gate of `12-audit.md` names `bff8dda`.** Its item 1 and its stop condition must name `51d6d5f` and the tree `c133a2df…` once the delta is audited, and item 3 (the squash must give exactly the audited tree) the same tree.
- **Item 4 of that gate** (hand the road of A5-1 to the red-team as a known target) is the coordinator's step. The owner document at `51d6d5f` now describes the road.
- **Two sentences of mine in `11-repair.md` were imprecise,** as the audit notes. Its section 9 says of the known failures "None is in a file this pull request touches". One of them, `TestOperationalHandoffSchema4BinaryRefusesSchema5`, is in a file among the 28 paths; the fourth repair did not touch that file. And the report says a test "compiles each form"; it type-checks them (O5-3). I did not edit `11-repair.md`, because its hash is recorded. The pull request description had the second sentence too and is corrected.
- **O5-7** (the cost of the digest and of the per-evaluation copies) stays a point for the step that gives the handoff a production caller, as the audit says.

## 8. Provenance

| Field | Value |
| --- | --- |
| Base-relative manifest | SHA-256 `05b759f9c247f443d50314749df5dbad8eba0ac863df5ef527bb7c2fe2d87bab`, 28 files. Head `8058561edc08356c46680c204586b3c7796c0ff3`, upstream pinned to `origin/codex/reliable-submit-operational-handoff-v1` |
| Base-relative textual diff | SHA-256 `9dd2a9e6c0b4ad663272f00018930ae205a58553083b67fbb1f568127ea3a030` |
| Delta manifest, against the audited tip `bff8dda` | SHA-256 `d1b1c44ba90d5b3930fbe1d230b709469a205e0068d0fd7f45bff0d1f75b5483`, 3 files. Head `bff8dda37dbf5484afb3b264d4eca38cf6abf118`, upstream `origin/claude/project-thread-sqldt7` |
| Delta textual diff | SHA-256 `e6ab8b4b5b190dd0524273bf41b8d6eb9e93abdc84ef115c24f82a5627130183` |
| Taken twice | Each manifest was written twice into a fresh mode-0700 directory outside the repository, and the two files are byte-identical |
| Staged sets | With the index reset to the base, `git add -A` staged exactly the 28 paths of the base-relative manifest; with the index reset to `bff8dda`, exactly the 3 paths of the delta manifest. Both staged trees are `c133a2dfcd1a1eb03151b7d74987c75b7dc00604`, the tree of the commit |
| After the runs | head `51d6d5f`, status empty, upstream `origin/claude/project-thread-sqldt7` restored |
| Remote | `origin/claude/project-thread-sqldt7` is at `51d6d5fcb5d7e59e70fd53e1cd2801044a03e23a`, a fast-forward from `bff8dda`. Nothing was forced |

The manifests were taken after the push, by `scripts/prov5.sh.txt`, which is the script of `11-repair.md` with the audited tip changed.

## 9. Confidence

- **Provenance: high.** Manifests taken twice on the pushed commit; staged sets and trees agree; the remote is at the commit.
- **That no code changed: high.** It is a comparison of Git trees, not a judgement.
- **The wording of the limit: medium to high.** It follows the audit's finding and keeps its line between what was measured and what was inferred. I did not run the auditor's probe. Whether the sentence on the trust boundary says enough for a later design step is for the auditor and the red-team to judge.
- **The two CI lines: high that they are needed and well formed, unknown whether they are all.** Shown with the gate's own code in a container that is not the runner.

## 10. Report delivery

This file: `/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/13-repair.md`. Its SHA-256 is in the thread reply that attaches it. Beside it: `13-ci-list-two-lines.patch`, and the folder `13-repair-evidence/` (also as `13-repair-evidence.tar.gz`) with a `README.md` that names every file.

## 11. Effect status

`TOPIC_BRANCH_PUSHED` (`claude/project-thread-sqldt7` at `51d6d5fcb5d7e59e70fd53e1cd2801044a03e23a`) | `DRAFT_PR_OPENED` https://github.com/evo-agi/Execution-Substrate/pull/13 (existing draft, description updated) | `MERGE_NOT_PERFORMED` | `INDEPENDENT_AUDIT_NOT_PERFORMED` for the delta

No push to any other branch. No force-push. No comment or review posted. The CI list file was not changed anywhere. PR #12 and `trunk_dev` were not touched.

STATUS: READY
