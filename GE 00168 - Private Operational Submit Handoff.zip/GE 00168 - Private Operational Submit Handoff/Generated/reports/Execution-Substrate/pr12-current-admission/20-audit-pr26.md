# INDEPENDENT AUDIT REPORT: PR #26, Workstream A's publication allow rule (`bcfb6da`, head `0aba38e`)

Fresh, read-only audit, asked for by the coordinator at 15:11Z. Audit thread: "Audit Execution-Substrate PRs" (the auditor of reports 32 and 34 of the CI Nomad/Vault track). Date: 2026-11-23, 15:12Z to 15:40Z (UTC). I am not the writer of the audited bytes. No red-team: the PR changes one test file only.

Verdict: **ACCEPT**, with two low findings that I recommend fixing in this PR before it merges (A20-1, A20-2). One test-only diff closes both, and I tested it (section 9). One pre-existing gap outside this PR's change has its own tested one-line diff (O20-1).

## 1. In plain words

1. **The bytes are the ones the writer reported.**
   - At the start, my manifest of `bcfb6da` against `trunk_dev` `792f17c` matched the writer's byte for byte.
   - During the audit the writer merged the new `trunk_dev` into the branch (item 11). At the end, my manifest of the new head `0aba38e` against `036d507` is `3c7c3e1a…9c25`, the same as in the writer's updated report.
   - The changed file is byte-identical in both commits, so every result below holds for the head.
2. **O7-1 is closed.** The guard keeps AGS publication words out of ES's own code, with two exceptions. Both exceptions used to be decided by the text of the line, so a comment could allow anything. Now they are decided by the piece of code that holds the word.
   - My original probe from `17-audit.md`, `var zzProbePolicyDecision = 1 // AdmissionPolicyDecision`, now fails the guard. It passes on `trunk_dev`.
   - The `Publication` exception is exact: only the name and the tag of the one field `Publication json.RawMessage` of the top-level struct `signedRuntimeTrustResponse`, and only in `es/admission/service.go`. Any read of that field, the same field in any other struct, and a local struct of the same name are all refused.
3. **The same 21 occurrences are allowed as before.** I ran the old and the new rule side by side over every file the guard reads: 21 occurrences, the same 21 allowed by both. The guarded words sit on the same lines at PR #13's tip, so PR #12 adds none.
4. **The roads the coordinator named are closed, apart from A20-1 below.** I planted 30 probes and a control, each on `trunk_dev` and on the PR.
   - **Comments, `//line`, string tags, generated files and build tags are all refused on the PR.** The rule uses the file path the guard itself listed, not the position, so `//line` cannot move code into an allowed file. The Go parser ignores build constraints, so a windows-only or `//go:build ignore` file is read too.
   - **`//line` fooled the old rule.** On `trunk_dev`, a `//line service.go:147` comment made the old rule read the text of the real field's line and allow a new `Publication` variable. The PR closes that too.
5. **A20-1 (low): the `PolicyDecision` exception matches a name, not the object.** In `policy.go`, any identifier spelled `AdmissionPolicyDecision`, `AllowAdmissionPolicyDecision` or `DenyAdmissionPolicyDecision` passes, whatever it is: a local, a parameter, a label, a method on another type, or an exported field of a new exported type. The old rule allowed these too, so nothing got worse. But the coordinator asked for exceptions that match the actual objects, and for `PolicyDecision` they do not yet.
6. **A20-2 (low): two properties have no test.** Four of my 21 mutants survive the PR's tests.
   - Taking the file name from the `//line`-adjusted position is not caught. That is the road class of A6-1 in PR #13.
   - Allowing every other forbidden word is not caught. This gap is older than the PR.
   - Two minor ones: a field with two names, and a struct declared inside a function.
7. **One diff fixes both.** `object-level-allow-proposal.diff` is test-only (+43/−9).
   - It allows `PolicyDecision` only for the top-level type and the two top-level functions of `policy.go`, and for the identifiers the parser resolves to them.
   - It adds 12 refused cases.
   - With it, all es/admission tests pass, the same 21 occurrences are allowed, probes P03 to P07 are refused, every other probe gives the same result, and every mutant is caught (section 9).
   - It merges with PR #13's tip in the same two blocks the writer already planned for, and the Workstream A tests pass on that merge.
8. **O20-1 (pre-existing, outside this PR): the DTO guard misses an embedded struct.**
   - If `signedRuntimeTrustResponse` is embedded in the public `PrepareRequest`, the request's JSON gains `"publication"` (and `signature`, `key_id` and the rest). Both guards pass, on `trunk_dev` and on the PR.
   - The DTO guard skips every field whose type is unexported, so it never looks inside.
   - A one-line diff (`dto-embedded-proposal.diff`) makes it follow embedded fields. That refuses this probe, and every es/admission result stays the same.
9. **Behaviour is unchanged.**
   - I ran es/admission in full at both commits, as two identities: one with sudo, one without. On each identity the PR adds 17 results, all of them passing, and no shared result changes.
   - The run without sudo has 7 failures at both commits, from execution-root privilege, the same at base and head.
   - gofmt is clean, and vet is clean for linux/amd64, linux/arm64 and darwin/arm64.
10. **CI is still running.**
    - The run on `bcfb6da` was cancelled when the merge was pushed.
    - Run 45206017915 on `0aba38e` started at 15:30Z and had not finished when I published.
    - I will add its result as a note in this thread.
11. **`trunk_dev` moved during the audit**, to `036d507` (PR #25).
    - The writer took it with a merge commit, `0aba38e`, with no rebase or force-push.
    - I checked that head myself. Its tree `e2efd07c…` is exactly what `git merge-tree` of `036d507` and `bcfb6da` gives, and its only difference from `036d507` is this PR's file, byte-identical to `bcfb6da`'s.
    - PR #25 shares no file with this PR. On that tree, vet and the Workstream A tests pass.

## 2. Audit target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Pull request | #26, draft, branch `claude/project-thread-ne9cwa` into `trunk_dev` |
| Commit | `bcfb6dad5546661d0587489f7214f783c030af19`, tree `e90a6001456925eba62f47f161214c0fb6e20dde`, one commit on `792f17c` |
| Head at the end | `0aba38e28e9f529fad44b810a00c8d35446552d4` = merge of `bcfb6da` and `trunk_dev` `036d507`, tree `e2efd07c7c0311cbab16d36a556a655ae8db3368`; the changed file's blob `ea423337…` is the same in both commits |
| Base | `trunk_dev` `792f17c7c56ca4a9c00d34aeb59524d898aeb58c` (PR #22) at the start; `036d50724b499b020c5149c55ad902cfcb1482c0` (PR #25) at the end, which is also the head's merge base |
| Change | `es/admission/workstream_a_guardrails_test.go`, +156/−16, test code only (`delta-792f17c-bcfb6da.diff`) |
| Recipe | `governed-execution.audit-patch-manifest.v2`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked before every run |
| Trunk-relative manifests | `bcfb6da` against `792f17c`: `49ff0a0d5b24fe16493fc844fc9cba0464b0dc85893df32d0841f0d195a30c15`. `0aba38e` against `036d507`: `3c7c3e1aacdee39c951b1ff2c8c187db66245482bfb546b7ca4ba96f9e959c25`. Both have 1 file and textual diff `68c11ec0e4aae15f62fa973e8ed6a1092c07f821184df8f75e7292486c29e372`, upstream `origin/trunk_dev`; they differ only in the base commit they record |
| Writer report | `reports/Execution-Substrate/workstream-a-allow-rule/01-repair.md`: SHA-256 `702084d0651fbbfe82f4641e88c3a74cd73541305b98a5d4009c15ce2572e81a` at 15:12Z. The writer then updated it for the re-gate on `036d507`: `6870b9b80f07054236be808a85c0228b09ba2a82b962550b9fbd7f96e6fbd160` (15:33Z) when I published. Evidence `01-repair-evidence/`: its `SHA256SUMS` has 83 entries, all OK. The 56 files of the new `regate-036d507/` folder are not in it yet; I compared that folder's two manifests with mine byte for byte instead |
| Background | `17-audit.md` O7-1 (SHA-256 `413792a8…46f3`) |

## 3. Posture and setup

- Read-only on GitHub: no push, comment, review, merge or branch change. Local commits for the trial merges stayed in my clone (section 9.4).
- Clone `/opt/audit/es`. Test trees are `git archive` exports of the exact commits: head `bcfb6da`, base `792f17c`.
- Runs used Go 1.26.5 with `GOTOOLCHAIN=local` and an emptied environment, as two identities: `ci` (uid 1500, gid 1600, with sudo) and `ci2` (uid 1700, gid 1700, without sudo). Probes, mutants and proposals ran as `ci`.
- Every probe and mutant ran in a fresh copy of a pristine export, never in a tree another run was using.
- No downloaded binary was executed.

## 4. Provenance

| Run | Time | `trunk_dev` | Result |
| --- | --- | --- | --- |
| Opening, two runs | 15:12Z | `792f17c` | `49ff0a0d…0c15` both times; JSON byte-identical to each other and to the writer's `manifests/trunk-1.json` |
| Closing, two runs, head `0aba38e` | 15:32Z | `036d507` | `3c7c3e1a…9c25` both times, identical to each other. The file entry (path, mode, size, SHA-256 `668feb6e…5b6d`) and the textual diff are the same as at the opening. Only the recorded base changes, from `792f17c` to `036d507`. This equals the writer's re-gate manifest |

The ref check before each pair is explicit, and it passed: branch and `trunk_dev` were at the expected commits (`ls-remote-open.txt`, `ls-remote-close.txt`). Afterwards the clone was at `0aba38e` with a clean status.

## 5. The rule as written, and what I verified

The guard (`TestWorkstreamAESImplementationDoesNotExposeAGSPublicationGrammar`) lists the non-test `.go` files of `es/admission`, `es/api` and `es/app` with `filepath.Glob`. It parses each file and records every identifier and string literal that contains a guarded word. The new allow rule then judges each occurrence:

- **`PolicyDecision`**: allowed when the node is an identifier, the guard's path is exactly `policy.go` (that is, `es/admission/policy.go`; `es/app` files are listed as `../app/…`), and the identifier's name is one of the three seam names.
- **`Publication` or `publication`**: allowed when the guard's path is exactly `service.go` and the node is the name or the tag of the field the finder returns.
  - The finder looks only at top-level type declarations.
  - It needs a struct type named `signedRuntimeTrustResponse` with a field that has exactly one name, `Publication`, the tag `` `json:"publication,omitempty"` `` exactly, and the type `json.RawMessage`.
- **Every other word**: refused.

I checked:
- The file in an occurrence is the glob path. It is never the position's file name, so `//line` cannot change it.
- The line in an occurrence is the adjusted position. It is used only in the message and in the new test's expected strings.
- With node identity, two occurrences on the same line are judged apart.
- The rule allows a strict subset of what the old rule allowed for `PolicyDecision`. All three names contain `AdmissionPolicyDecision`, and an exact path is narrower than a base name.

### 5.1 The 21 allowed occurrences

A probe test in a copy of `bcfb6da` (`allowed-occurrences-bcfb6da.log`) runs both rules over every occurrence the guard sees. The old rule is copied verbatim from `792f17c`.

- `occurrences=21 allowed_new=21 allowed_old=21 allowed_both=21`.
- 19 of them are `PolicyDecision` identifiers in `policy.go`: lines 40, 56, 64 (twice), 65, 71 (twice), 72, 109, 118, 134, 139, 146, 153, 196, 201, 209, 217 and 256.
- The other two are the name and the tag of `service.go:147`.

At PR #13's tip `e060449`, the lines in the guard's files that hold any guarded word are the same as at `bcfb6da`, apart from line numbers (`term-lines-bcfb6da-vs-pr13-e060449.txt`, case-sensitive, comments included). This agrees with the writer's own count at that tip.

## 6. Probes

`probes20.py` plants each probe in a fresh copy of the head and of the base. For each one it checks that `es/admission`, `es/app` and `es/api` still build, then runs every `^TestWorkstreamA` test. Every probe built. All 62 results matched my prediction (`probes20-uid1500-gid1600.log`).

| Probe | What it plants | `792f17c` | `bcfb6da` |
| --- | --- | --- | --- |
| P00 | nothing (control) | pass | pass |
| P01 | `var zzProbePolicyDecision = 1 // AdmissionPolicyDecision` in `policy.go` (O7-1) | **pass** | refused |
| P02 | `var zzPolicyDecision AdmissionPolicyDecision` in `policy.go` | **pass** | refused |
| P03 | a local `AdmissionPolicyDecision := 1` that shadows the type, in `policy.go` | pass | **pass** (A20-1) |
| P04 | an exported type with an exported field `AdmissionPolicyDecision string`, in `policy.go` | pass | **pass** (A20-1) |
| P05 | a method `DenyAdmissionPolicyDecision` on another type, in `policy.go` | pass | **pass** (A20-1) |
| P06 | a parameter named `AllowAdmissionPolicyDecision`, in `policy.go` | pass | **pass** (A20-1) |
| P07 | a label named `AdmissionPolicyDecision`, in `policy.go` | pass | **pass** (A20-1) |
| P08 | `//line policy.go:56` in a new `es/admission` file that uses the type | refused | refused |
| P09 | `//line policy.go:56` in `es/app`, declaring `AdmissionPolicyDecision` | refused | refused |
| P10 | a new `es/app/policy.go` declaring `AdmissionPolicyDecision` | **pass** | refused |
| P11 | `//line service.go:147` above a new `var zzPublication json.RawMessage` in `service.go` | **pass** (the old rule read line 147's text) | refused |
| P12 | `//line policy.go:40` above a new `var zzPolicyDecisionLeak` in `policy.go` | **pass** | refused |
| P13 | the `publication` tag on another struct's field, in `service.go` | refused | refused |
| P14 | the same field on a new exported struct, in `service.go` | **pass** | refused |
| P15 | a function-local type `signedRuntimeTrustResponse` with the same field, in `service.go` | **pass** | refused |
| P16 | an exported method that returns `r.Publication`, with the field spelled in a comment | **pass** | refused |
| P17 | ``var zzPublication = 1 // Publication json.RawMessage `json:"publication,omitempty"` `` | **pass** | refused |
| P18 | a new `es/app/service.go` with the same struct and field | **pass** | refused |
| P19 | the allowed field written over two lines (`json.` then `RawMessage …`) | refused | pass (it is the same field, so this is right) |
| P20 | a second name on the allowed field | **pass** | refused |
| P21 | a `// Code generated … DO NOT EDIT.` file with `var zzPublished` | refused | refused |
| P22 | a `//go:build ignore` file with `var zzPublication` | refused | refused |
| P23 | a `//go:build windows` file, `zz_probe_windows.go` | refused | refused |
| P24 | `"publi" + "cation"` | pass | pass (substring guard; known) |
| P25 | `const zzDecisions = "policy_decisions"` in `policy.go` | refused | refused |
| P26 | `import publication "encoding/json"` | refused | refused |
| P27 | `type ZzDecision = AdmissionPolicyDecision` in another `es/admission` file | refused | refused |
| P28 | `type RuntimeTrustResponse = signedRuntimeTrustResponse`, an exported alias | pass | pass (O20-2) |
| P29 | `signedRuntimeTrustResponse` embedded in `PrepareRequest`, with a test that marshals it | pass, JSON has `"publication":{"probe":true}` | pass, same (O20-1) |
| P30 | `var ZzPublication` in a new `es/api` file | refused | refused |

The probe set is my own. It includes the writer's five failing-first probes in substance: P01, P02, P10, P14 and P17.

## 7. Mutants

`mutants20.py` changes the rule in a fresh copy and runs every `^TestWorkstreamA` test. A mutant is caught when a test fails or the package does not compile. A run with no results would count as an error, and there were none.

On `bcfb6da` (`mutants20-head-uid1500-gid1600.log`): the control passes, **17 of 21 are caught, and 4 survive**.

| Mutant | Change | Result on `bcfb6da` |
| --- | --- | --- |
| M01 to M06 | `PolicyDecision`: no file check; file by base name; any identifier containing the seam name; any identifier in `policy.go`; the old line-text rule; allow nothing | all caught |
| M07 to M11 | `Publication`: no file check; file by base name; anything once the field exists; the name only; the tag only | all caught |
| M12 to M15 | finder: any struct name; no tag check; no type check; no field-name check | all caught |
| **M16** | finder: no single-name check | **survives** |
| **M17** | finder: also searches declarations inside functions | **survives** |
| **M18** | scan: file taken from the `//line`-adjusted position | **survives** |
| M19, M20 | scan: no node; no parsed file | caught |
| **M21** | rule: every other forbidden word allowed | **survives** (the same gap exists on `792f17c`) |

The writer's 13 mutants overlap with M01 to M15 and M19. I did not re-run them; their log shows 13 of 13 caught.

## 8. Findings

| ID | Severity | Type | Summary |
| --- | --- | --- | --- |
| A20-1 | low | incomplete fix | The `PolicyDecision` exception is decided by the identifier's name, not by the object it names. P03 to P07 pass. Not a regression: `792f17c` passes all five. |
| A20-2 | low | test gap | M18 and M21 survive, so the tests do not hold that the file comes from the guard's own path, or that the other forbidden words stay refused. M16 and M17 also survive; those two are minor. |

**A20-1 in detail.**
- In `policy.go`, an exported field `AdmissionPolicyDecision` on a new exported type passes the guard (P04), with any JSON name its tag gives.
- A method on another type passes too (P05), and so do a shadowing local, a parameter and a label (P03, P06, P07).
- None of these is the ES seam type or one of its constructors.
- How far this reaches is limited: only the three exact names pass, only in that one file, and `PolicyDecisions`, a bare `PolicyDecision` or a longer name is refused.
- The fix (section 9) binds each identifier to its object. `go/parser` already resolves identifiers within one file. The rule then allows an identifier only when its object is the file-scope object of that name and of the right kind (`ast.Typ` for the type, `ast.Fun` for the two constructors). A local, a parameter, a label or a field gets its own object. A method name or a selector gets none.

**A20-2 in detail.**
- M18 is the A6-1 road class from PR #13. Nothing in this PR's tests fails if a later edit takes the file from the adjusted position.
- PR #12 will add a second layer, a refusal of line directives in production files. This guard's own tests should still hold the property.
- M21: the new test has no refused case for a word other than the two exceptions. The real-tree guard cannot catch it either, because no such word exists in the tree today.

### 8.1 Observations

| ID | Observation |
| --- | --- |
| O20-1 | Pre-existing, outside this change: `TestWorkstreamAAdmissionDTOsExcludePublicationARSSupportAndCPGrammar` skips every struct field with a non-empty `PkgPath`, and that includes an embedded unexported struct. `encoding/json` still promotes such a struct's exported fields. P29 puts `"publication"` into `PrepareRequest`'s JSON with both guards passing, at base and head. `dto-embedded-proposal.diff` (one condition, `&& !field.Anonymous`, SHA-256 `188f6102…27c0`) refuses P29 and passes all `^TestWorkstreamA` tests. es/admission in full with it gives 1,121 passing and 7 skipped, the same results as the head (`dto-embedded-proposal-uid1500-gid1600.log`). The same helper serves eight DTO tests in es/admission. |
| O20-2 | Known limits of a word guard, unchanged by this PR: concatenation (P24) and an exported alias (P28) pass. The writer's report says so under "Not claimed": the guard still judges words by substring. |
| O20-3 | On `bcfb6da` the refusal message still reads the adjusted line. Under a `//line` comment it quotes the wrong source line: P11 is refused with the text of `service.go:147`, the real field. The refusal holds; only the message misleads. PR #12's `guardPosition` will fix the message when it lands. |
| O20-4 | The writer's counts (1,099 to 1,116 passing, 12 skips) differ from mine (1,104 to 1,121, 7 skips, as `ci`) only in how many tests skip in each environment. The totals agree: 1,111 to 1,128 results. |

## 9. The proposal

`object-level-allow-proposal.diff` (SHA-256 `6edfc123295e50f45a147a3d94151f5787a5c6579cf8bef9fb459ca54d409cef`) applies with `patch -p1` to `bcfb6da`, and so to `0aba38e`, where the file is the same. It is test-only: +43/−9 in the one file.

- **Rule:** `workstreamAAdmissionPolicyDecisionNames` becomes `workstreamAAdmissionPolicyDecisionObjects` (name to `ast.ObjKind`). The `PolicyDecision` case becomes:
  ```go
  identifier, ok := occurrence.node.(*ast.Ident)
  if !ok || occurrence.file != "policy.go" || occurrence.syntax == nil || occurrence.syntax.Scope == nil {
  	return false
  }
  kind, named := workstreamAAdmissionPolicyDecisionObjects[identifier.Name]
  object := occurrence.syntax.Scope.Lookup(identifier.Name)
  return named && object != nil && object.Kind == kind && identifier.Obj == object
  ```
- **New refused cases (12):**
  - for A20-1: a shadowing local, a parameter, a field, a method and a label with a seam name, and a package variable with a constructor's name (for the kind check);
  - for M18: the seam type and the field each placed under a `//line` comment that names the allowed file;
  - for M21: another forbidden identifier, and another forbidden string;
  - for M16 and M17: a second name on the field, and the field in a function-local struct.
  - The `//line` cases put each directive on the line before the code and give that code's real line number, so the adjusted and the real line are the same. They pass now, and they will still pass once PR #12 moves the guard to real positions.
- **Its limits.** `go/parser` resolves within one file. A use of the seam type from another file is unresolved, and is refused anyway because only `policy.go` is allowed. A composite-literal key spelled like the type can resolve to the type, but its field would have to be declared somewhere, and that declaration is refused. `ast.Object` is marked deprecated in favour of `go/types`. `go vet` does not flag it, and CI runs vet only. Inference: a `go/types` version via the repository's typed loader would work too, at a much larger size.

### 9.1 Validation

On `bcfb6da` + the proposal, as `ci`:
- gofmt is clean, and vet is clean for linux/amd64, linux/arm64 and darwin/arm64.
- es/admission in full gives 1,133 passing, 7 skipped and 0 failing (`object-level-allow-proposal-uid1500-gid1600.log`).
- Against my head run, the only differences are the 12 new subtests, all passing.

The count probe gives the same 21 occurrences, all allowed.

### 9.2 Probes on the proposal

`probes20-fix-uid1500-gid1600.log`: all 31 as predicted.
- P03 to P07 are now refused.
- Every other probe gives the same result as on `bcfb6da`. P00, P19, P24, P28 and P29 pass; the rest are refused.

### 9.3 Mutants on the proposal

`mutants20-fix-uid1500-gid1600.log`: the control passes, and **all 22 mutants are caught**.
- M07 to M21 apply unchanged, and M16, M17, M18 and M21 are now caught.
- M01 to M06 target the line the proposal replaces, so I wrote the matching mutants of the new lines, F01 to F07:
  - the object identity dropped;
  - the kind check dropped;
  - the file check dropped;
  - any resolved identifier of that name;
  - the file by base name;
  - allow nothing;
  - the PR's name-only rule restored.

### 9.4 With PR #12

I made a local commit of `bcfb6da` + the proposal (never pushed) and ran `git merge-tree` with PR #13's tip `e060449` (`trial-merge-pr13-e060449-build.log`).

- The conflicts are the same as without the proposal: `docs_contract_test.go`, as known from `18-trunk-dev-merge-plan.md`, and the two blocks in the Workstream A file. The proposal adds no conflict.
- I resolved the two blocks as the writer's report says: keep PR #12's `source:` line and add this PR's `node:` and `syntax:` lines.
- On that tree, es/admission vets clean and every `^TestWorkstreamA` test passes, including the new test with its 28 subtests (`trial-merge-pr13-e060449-with-proposal-uid1500-gid1600.log`).

## 10. Tests per identity

`unit20.sh` ran es/admission in full at head and base, plus gofmt and vet for three targets (`unit-admission-bcfb6da-vs-792f17c-uid*.log`).

| Identity | `792f17c` | `bcfb6da` | Differences |
| --- | --- | --- | --- |
| `ci` 1500:1600, sudo | 1,104 pass, 7 skip | 1,121 pass, 7 skip | +17, all pass: the new test and its 16 subtests |
| `ci2` 1700:1700, no sudo | 1,093 pass, 11 skip, 7 fail | 1,110 pass, 11 skip, 7 fail | the same +17; the same 7 failures at both commits |

The 7 failures without sudo are execution-root and retained-result startup tests that need privilege: `TestNewServiceRejectsDualMissingExecutionRootsBeforeMutation`, `TestRetainedResultAuthRequiredStartupFailsWithoutKeyAndPrepareOnlySkipsIt`, `TestRetainedResultReviewFreshServiceReopensPersistedResultWithReloadedKey` and `TestRetainedResultReviewStartupNaturalDirectoryMask` with its three subtests. They fail identically at base and head.

gofmt and vet (linux/amd64, linux/arm64, darwin/arm64) are clean at both commits for both identities.

## 11. CI

| Run | Commit | Result |
| --- | --- | --- |
| [45201637978](https://github.com/evo-agi/Execution-Substrate/actions/runs/45201637978) | `bcfb6da` | started 15:07:23Z; **cancelled** at 15:30:52Z, when the merge commit was pushed |
| [45206017915](https://github.com/evo-agi/Execution-Substrate/actions/runs/45206017915) | `0aba38e` | started 15:30:56Z; **in progress** when this report was published. I will add the result in the thread |

Its job runs the repository's full gate ("build, vet and test"). My local runs cover es/admission in full and `^TestWorkstreamA` on the merged tree. They do not replace CI.

## 12. `trunk_dev` moved, and the new head

- PR #25 merged as `036d507`. It changes the supported-local scripts, the CI selftest and workflow, `docs_contract_test.go`, two documents and `es/app/spire_release_pin_test.go`. None of these is this PR's file, and the guard reads none of them, because it skips test files.
- Before the writer pushed, I ran `git merge-tree` of `036d507` and `bcfb6da`: clean, tree `e2efd07c7c0311cbab16d36a556a655ae8db3368`. On that tree, gofmt is clean, vet is clean for three targets on `es/admission`, `es/app` and `es/api`, and every `^TestWorkstreamA` test passes, with 16 of 16 subtests (`merge-onto-036d507-uid1500-gid1600.log`).
- The writer then pushed `0aba38e`, whose parents are `bcfb6da` and `036d507`. Its tree is `e2efd07c…`, the same tree I tested, so those results hold for the head. Its diff against `036d507` is the one file, the same blob as in `bcfb6da`.

## 13. The writer's evidence

- `01-repair.md` SHA-256 is `702084d0…e81a`. `01-repair-evidence/SHA256SUMS` has 83 entries, all OK.
- The writer's manifest `trunk-1.json` is byte-identical to mine.
- Mutants: `mutants/m71.log` shows 13 of 13 caught.
- My results agree with the writer's claims in section 4 of that report. The one exception is skip counts, which differ by environment (O20-4).

## 14. Not checked

- No macOS run.
- I did not re-run the writer's race-detector run.
- My PR #12 check is a trial merge with PR #13's tip `e060449`, running es/admission's `^TestWorkstreamA` tests and vet. I did not resolve `docs_contract_test.go` or run the root package there.
- O20-1's diff is outside this PR's scope. I tested it on `bcfb6da` only.

## 15. Recommendation

1. Apply `object-level-allow-proposal.diff` in this PR (test-only), closing A20-1 and A20-2. Then a narrow re-audit: the delta, the probes P03 to P07, the mutants, and a new manifest.
2. Merge gate on the head that then exists: CI green, and the branch up to date with `trunk_dev`. The branch already took `036d507` (`0aba38e`, checked in section 12).
3. O20-1: either take the one-line diff into this PR (it is the same file and also test-only) or open a follow-up; the choice is the coordinator's. Its whole-package result is in section 8.1.

## 16. Evidence

`20-audit-pr26-evidence/`, with `SHA256SUMS.txt` and a README listing every file.
