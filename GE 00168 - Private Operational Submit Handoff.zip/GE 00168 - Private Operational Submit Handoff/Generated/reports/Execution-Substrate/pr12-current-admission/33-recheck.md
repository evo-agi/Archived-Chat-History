# PR #12 repair after the red-team re-check (draft PR #40 at `99a6625`): re-check 33

Written 2026-11-24 from 01:20Z onwards by the independent audit thread "Audit Execution-Substrate PRs", after the coordinator asked for a diff-only check. Read-only: nothing was pushed, commented, reviewed or merged. Evidence is in `33-recheck-evidence/` next to this file. My local names carry the tag `40c`.

Subject: the writer's `32-repair.md`, which answers RC31-1 and RC31-2 of `31-redteam-recheck.md`.

## Verdict

**ACCEPT, with no findings to fix in PR #40.** Both repairs are right and as narrow as stated. Three Info notes follow; none needs a change here. One of them is a merge-order item for PR #31, of the same kind as N-1.

- **RC31-1 is closed.** `nomadKeepsDriverString` refuses a leading byte order mark, a string that is not in NFC, and any code point above ASCII that is not assigned in Unicode 15.0.0. It runs on each argument and each mount target.
  - I compared the rule with x/text's 15.0.0 tables and with the 17.0.0 tables of x/text v0.43.0. Across every code point alone, 20.2 million ordered pairs and 3 million random strings, it kept no string that either table set would change.
  - 23,268 of those pairs are in NFC under 15.0.0 but not under 17.0.0. The rule refuses all of them, because each holds a code point that 15.0.0 does not assign. With that clause removed, all of them are kept. So the assigned-set clause is needed, and it works.
- **RC31-2 is closed.** `memory_mb` below 10 is refused by the validation both paths share, before any claim. 9 and −1 are refused on the ordinary path, 10 is accepted, and the re-check's private-path cases pass.
- **The writer's five questions** have the answers in section 3. In short:
  - no other request string reaches the driver configuration;
  - refusing is right;
  - the reviewed-list claim holds;
  - the owner paragraph and its pins are right;
  - the three position reads are right.
- **The scope is as stated.**
  - Adoption: `085b19a` is exactly the red-team's patch applied to `75d0f5c`, and the adopted file is unchanged since.
  - The repair: `a8d5397` changes two production files (`service.go`, `mounts.go`), three test files and `go.mod`. `go.mod` moves `golang.org/x/text` v0.17.0 from indirect to direct, and `go.sum` is unchanged.
  - The trunk merge: `e2ea71f` is exactly git's merge of `a8d5397` and `4c991ba`.
  - `481556b` changes three lines in `internal/testutil/testutil_test.go`.
  - `99a6625` changes the documents and the pins only.
- **The manifests verify.** I took each twice, byte-identical, and each JSON file is identical to the writer's:
  - trunk-relative: `73ed8c3c…6664`, 69 files;
  - PR-relative: `82289c73…878e`, 165 files.

  For both, the staged set equals the manifest's paths and `write-tree` gives the head tree. Against re-check 32's trunk-relative manifest, the changes are exactly the ones the owner paragraph names (section 2).
- **Vet, format and tests pass as `ci`.**
  - `go vet ./...` passes, and so does the arm64 and darwin vet of the four touched packages. The changed Go files are gofmt-clean.
  - In `es/admission`, all 19 targeted tests pass: the rule, the re-check's three tests, the string tests and the guards (the dependency list and the position reads among them).
  - The root docs pins pass, and so do `internal/testutil` and the moved boundary test in `scripts/`.
- **`trunk_dev` moved twice during this check:** to `523648c` (#43, `README.md` only), then to `6ce0034` (#42, three `es/app` test files).
  - #43's trial merge is clean, and its diff over the head is byte-identical to #43's diff. On that merge, the root package passes 164 of 164.
  - #42's trial merge is clean too, and its diff over the head equals `trunk_dev`'s diff since `4c991ba`. No path is shared with PR #40, and no file of #42 reads an adjusted position. On that merge, `go vet` of `es/app` and `es/admission` passes, and so do the position guard, the dependency guard and the new string tests (`trial-merge-42.txt`).
  - ES requires up-to-date branches, so PR #40 must take `6ce0034` before it merges.
- **N-1 is still forced.** PR #31's head is now `0f596c0`. Its token guard still names the same three private requests on a trial merge.
- **CI:** run 45303337441 of `build, vet and test` on `99a6625` succeeded (check run 138141027978, 01:13Z to 01:47Z). It runs the whole module, so it also covers any test that asked for 1 to 9 MB.

## In plain words

Nomad quietly rewrites two kinds of text before a job runs: it drops an invisible mark at the start, and it changes some accented letters to a standard form. ES now refuses an argument or a mount path that Nomad would rewrite, instead of letting it change unseen. I checked that against Nomad's newer tables as well as ES's own, over about 24 million strings, and found no string that ES keeps and Nomad would change. ES also refuses less than 10 MB of memory now, which Nomad would refuse later. Nothing else in the product changed.

One thing to know for later: PR #31's new guard test reads code positions in a way PR #12's own guard refuses. Whichever of the two merges second needs a three-line change, like the one this round made to PR #39's test.

## 1. Target

| Item | Value |
| --- | --- |
| PR | evo-agi/Execution-Substrate #40 (draft) into `codex/reliable-submit-operational-handoff-v1` (PR #12 at `44166998`) |
| Head | `99a66256be1b238d5bd5487a9926abe044f03028`, tree `11da794471b628481c1972f3663bc9f84cd9cc2f` |
| Previous target | `75d0f5c` (`32-recheck.md`) |
| `trunk_dev` | `4c991ba1c43ac135d9d94853696d14a21523a690` (#39), the merge base. It moved to `523648c` (#43) and then `6ce0034` (#42) during the check. |
| Recipe | v2, source SHA-256 `c08597e2…a1a3ca`, verified before the run |
| Trunk-relative manifest | `73ed8c3c8f5cc4be29a93da92d68ffee15232141c4e211a33eb8ba67e1216664`, 69 files, textual diff `570f59b2…6fbc`, upstream `origin/trunk_dev` |
| PR-relative manifest | `82289c73b02f269dac43116a5ab58e713d083175ab7055a6c145618b4e06878e`, 165 files, textual diff `bea34f35…4296`, upstream `origin/codex/reliable-submit-operational-handoff-v1` |
| Toolchain | Go 1.26.5, `GOTOOLCHAIN=local`, `env -i`, user `ci` (1500:1600) |

The evidence files:
- refs at the start and the end: `ls-remote-open.txt`, `ls-remote-close.txt`;
- provenance: `provenance-40c.txt`;
- manifests: `manifests/`, with `cmp-vs-40b.txt`;
- the tree checks of both ci copies: `tree-check.txt`, 536 entries and 0 differences each.

## 2. What changed, and the path count

| Commit | What it holds |
| --- | --- |
| `085b19a` | the red-team's finding tests, adopted unchanged |
| `a8d5397` | the rule, the memory floor, two unit tests, the codec table's smallest memory (1 to 10), the reviewed list, `go.mod` |
| `e2ea71f` | git's merge of `trunk_dev` `4c991ba` (#37, #39) |
| `481556b` | three position reads in PR #39's `internal/testutil` test |
| `99a6625` | both contracts documents, the owner document, `PLANS.md` and the root pins |

Against re-check 32's trunk-relative manifest (66 files), the 69 files are:
- 54 unchanged entries;
- 11 changed entries: the 10 files this round edits, and `.github/ci/environment-only-tests.txt`. That file's own hunks are byte-identical to round 31's; only its context changed, through #39;
- three new paths: `go.mod`, `es/admission/nomad_request_strings_redteam31_finding_test.go` and `internal/testutil/testutil_test.go`;
- one move: the root `remote_alpha_es_service_tls_status_local_boundary_test.go` became `scripts/…`. Its two changed lines are the same as before the move.

That is 66 + 3 = 69, as the owner paragraph says. The PR-relative manifest adds #33's, #41's, #37's and #39's paths to round 31's 82, since PR #12's base predates them. Without rename detection, the staged set equals the 165 paths.

## 3. The writer's questions

### 3.1 Does any other request string reach the driver configuration?

No. `buildNomadJobSpec` (`submit.go:162`) fills the task's `Config` with these:

| Key | Where it comes from |
| --- | --- |
| `image` | the runtime profile's image, from operator configuration (`runtimeprofile.go:38`, `:64`) |
| `command` | the constant `executionRuntimeSupportPath` |
| `args` | ES's constant supervisor arguments, the timeout as a decimal integer, then the request's argv (`executionpackage.go:79-90`) |
| `privileged`, `security_opt` | the job envelope, from configuration |
| `mounts` | four fixed mounts, then one per request mount. Its source is an ES path made from the staging root, the run ID and the index (`mounts.go:232`). Its target is the request's target, checked. |
| `network_mode` | `none` or `bridge` |

The marker test `TestSubmitPlacesOnlyTheCheckedRequestStringsInTheNomadJob` passes. My probe Z5 confirms the rule's scope through `Submit`:
- an environment value in NFD, an environment value with a leading byte order mark, and an `output_id` in NFD are accepted and sent;
- the same strings as an argument or a mount target are refused with the documented message.

This matches the red-team's S5 and S6.

### 3.2 Refusing or normalizing?

I agree with refusing.
- The binding, the policy input and the record all hold the caller's string. A silent rewrite would make the record disagree with what the caller sent, which is the defect being fixed.
- The binding and replay paths require a mount target to equal its normalized form (`reliable_submit_binding.go:364-366`, `reliable_submit_replay_hydration.go:298-300`). A normalizing rule would need a second representation there.
- It is the same choice round 29 made for `${`.
- The refusal message says what to change, and a caller can normalize before sending.

### 3.3 Does the reviewed-list claim for `norm` and `rangetable` hold?

Yes (`deps40c.txt`). `go list` for linux/amd64, linux/arm64 and darwin/arm64 gives the same built files for each package:
- `norm`: it imports `encoding/binary`, `fmt`, `io`, `sync`, `unicode/utf8` and `golang.org/x/text/transform`;
- `rangetable`: it imports `sort` and `unicode`;
- `transform`: it imports `bytes`, `errors`, `io` and `unicode/utf8`.

No built file of the three imports `unsafe`, `reflect`, `syscall` or `C`, and none has cgo files. `rangetable/gen.go` carries `//go:build ignore`. So do `norm`'s `maketables.go` and `triegen.go`; the older tables are excluded by Go version. `TestOperationalGuardReviewedDependencyPackagesAreExact` passes.

### 3.4 Is the owner paragraph for 69 paths correct, with the right pins?

Yes.
- The paragraph names the three new paths and the moved file, and section 2 shows the manifest holds exactly those.
- "Is 66 files" became "was 66 files" in the owner document and "became 66 files" in `PLANS.md`, as earlier entries did.
- The pins add five "contains" lines to the owner rule. There are five new "missing" mutants (`MissingRedTeamRecheck…`) and five new "wrong statement" mutants: the ceiling not raised, and each of the three paths or the move left unnamed.
- A new `assertContainsNone` checks that the old resources sentence is gone.
- The documents say "today 15.0.0", which matches `norm.Version`. The refusal text takes its version from `norm.Version` itself.
- `TestNomadEvaluatedRequestStringsContract`, `TestOperationalSubmitHandoffCurrentAdmissionV2Contract` and `…RejectsUnsafeMutants` pass.

### 3.5 Are the three position reads in PR #39's test right?

Yes. `fset.PositionFor(pos, false)` gives the real file and line, without line directives, and is the form PR #12's guard asks of every test file outside `es/admission`. As a control, I ran `TestOperationalGuardReadsUnadjustedPositions` at `e2ea71f`, the merge before `481556b`. It fails naming exactly `testutil_test.go:828`, `:962` and `:1105` (`control40c.log`). At the head it passes, and `internal/testutil`'s tests pass, so the self-test's exact lines are unchanged. No file of `internal/testutil` holds a line directive.

## 4. Probes (`probes40c.log`, `probemut40c.log`)

The probes ran as `ci` on a copy of the head, with one probe test file (`zz_probe40c_test.go`, in the evidence). The copy also held a scratch package with `unicode/norm` from `golang.org/x/text` v0.43.0:
- the go command verified the module against the checksum database (`h1:1Qivrl…VXoWc=`);
- its Unicode 17.0.0 table file (SHA-256 `dade3c78…55fa`) was used with its `go1.27` build line removed;
- the writer's report names v0.43.0 as Nomad v2.1.1's version. Inference: I did not read Nomad's `go.mod` myself.

That copy of the module is not in the evidence.

| Probe | What | Result |
| --- | --- | --- |
| Z1 | every code point alone (1,112,064) | 285,598 kept, none changed by 15.0.0 or 17.0.0. The 826,466 refused are almost all unassigned code points and noncharacters: over-refusal by design. |
| Z2 | every ordered pair of a 4,489-code-point pool (marks, decomposable code points and their parts, Hangul jamo, a sample of syllables, the mark U+FEFF) | 10,524,566 kept, none changed by either table set. 23,268 pairs are in NFC under 15.0.0 but not under 17.0.0, and all are refused. |
| Z3 | 3,000,000 random strings of 2 to 6 pool code points, a third behind `/execution/mounts/` | 891,433 kept, none changed. 4,807 are in NFC under 15.0.0 only, and all are refused. |
| Z1–Z3 | `IsNormalString(s)` against `NFC.String(s) == s` | equal for every string |
| Z4 | named cases | Kept: a mark after the start, a Hangul syllable, a combining mark alone, private use (U+E000, U+F0000). Refused: NFD, jamo, syllable plus final jamo, the Kelvin, Ohm and Angstrom signs, U+0344, U+0958, U+F900, U+1FAE9, noncharacters U+FDD0 and U+10FFFF, two marks that compose. All as expected. |
| Z5 | through `Submit` on the ordinary path | argv and mount targets refused with the documented message. Environment values and `output_id` accepted. Memory 9 and −1 refused, 10 accepted with one POST. |
| M1 | the rule without the assigned-code-point clause | Z2 fails: the 23,268 pairs are kept |
| M2 | the rule without the leading-mark clause | Z1 and Z2 fail |

M1 and M2 ran on a scratch copy of `service.go`, which was restored and compared afterwards.

## 5. Info notes

### I33-1: PR #31's guard test reads adjusted positions, which PR #12's guard refuses

This is a merge-order note, like N-1. PR #31's `es/admission/nomad_request_guard_test.go` builds its messages with `fileSet.Position(…)` at lines 119, 218 and 230. On a trial merge of `0f596c0` into `99a6625`, PR #12's `TestOperationalGuardReadsUnadjustedPositions` fails naming exactly those three lines (`n2position40c.log`). The file already held the three reads at `b150657`; I did not run this guard in re-check 32.

Whichever of PR #31 and PR #12 merges second needs the same three-line change `481556b` made for PR #39: `PositionFor(pos, false)`. Neither PR is wrong alone. I found no such read in the changed test files of PRs #34, #35, #38, #42 or #44 (`position-reads-open-prs.txt`). PR #30 shows two, but they are `trunk_dev`'s own lines in the moved boundary test, which PR #12 already changes. Inference: git merges that file cleanly; I did not trial-merge PR #30.

### I33-2: the ES service binary links `x/text` for the first time

The report says `x/text` was "already compiled into every package that imports grpc". That is accurate, but `cmd/es` imports no grpc. At `4c991ba`, `cmd/es` linked no `x/text` package. At the head it links `transform`, `norm` and `rangetable` (`deps40c-b.txt`). `cmd/es-runtime-support` and `cmd/es-workload-api-mock` already linked `norm` through `x/net/idna`.

This changes nothing in the verdict: the reviewed-list claim covers what is new. It is worth knowing for anyone who keeps a list of what the ES binary contains.

### I33-3: the rule keeps invalid UTF-8, which nothing can send today

`nomadKeepsDriverString("a\xffb")` is true. `range` yields U+FFFD, which is assigned, and `norm` passes invalid bytes through. `json.Marshal` would then write U+FFFD into the job.

No caller can reach this:
- the public path decodes with `encoding/json` (`internal/httpx`), which replaces invalid bytes with U+FFFD;
- the private parser refuses invalid UTF-8 (the red-team's S3).

A `utf8.ValidString` check would make the function stand on its own. No change is needed for this PR.

## 6. What I did not cover

- I did not rerun the whole module. CI runs it, and the writer's whole-module comparisons found no changed result (their section 4.3). The new memory floor could fail any test that asks for 1 to 9 MB; CI and the writer's run both cover that.
- I did not rerun the writer's 17 mutants one by one. My probes test the same rule more widely, and M1 and M2 show that they catch a missing clause.
- I did not read Nomad's source. The rewriting behaviour, and Nomad's minimum of 10 MB, rest on the red-team's reading and box plan. The live box checks (`box-live-checks.md`) still need David's go.
- Nothing ran on macOS or against a real Nomad.

## 7. Sensitive material

The probes are synthetic. No key, certificate body, token, env file or config file is copied into the evidence. Commit-message trailers and author names are left out. The report and evidence were scanned with the thread's pattern list and a positive control before delivery.
