# INDEPENDENT AUDIT REPORT

Workstream `pr12-current-admission`, stage 10: fresh audit of the third repair of Execution Substrate draft PR #13.
Written 2026-11-22 (UTC) by a fresh audit thread. Read-only: nothing was edited, pushed, commented or merged.

**Final verdict: BLOCK**

## 1. In plain words

1. **The scope is what the writer says.** One commit, six files: two documents and four test files. No production file changed. The ten production files of the pull request are byte-identical to the previously audited tip `c41e177`, so the production code that three audits accepted is untouched.
2. **The blocking finding of the last audit (A3-1) is closed.** I re-ran the prior audit's twelve probes on the new bytes. All twelve fail the guard tests now, including the six that passed at `c41e177` (the generic function used from another package, in all its forms, and the whole-value overwrite from another package).
3. **The four low findings (R2 to R5) and the optional item are closed.** I broke each fix in a scratch copy: all 18 of my mutants are killed. R3 and R4 I confirmed by reading.
4. **The new rules hold against the type-level shapes I could think of.** 84 small cases against the guard's own functions (same-shape types, type parameters, instantiations, whole values, range clauses, built-ins) showed no form that compiles and is not listed. Seven more probes on the real packages (embedding, alias, method value, generated-code header, build constraint `cgo`, a vendor directory, a new package in an ordinary directory) are all caught.
5. **One gap remains, and that is why I block (finding A4-1, medium).** The repair says the guard now reads every production file of the module. It does not. It reads the packages that `go list ./...` matches, and it leaves out every directory named `testdata` or beginning with a dot or an underscore, on the stated ground that the go command builds nothing from those. That ground is false: the go command compiles such a package as soon as another package imports it. I built that in a scratch copy: a small package under `es/app/testdata` and one call from `es/app`. The build, `go vet`, the guard tests (481 of 481) and the whole suite stay exactly as green as before. Two probe tests then show the effect: a job whose artifact EGS has revoked is accepted and posted. The same holds for an underscore directory, a dot directory, a variant without `reflect` or `unsafe`, and a nested module reached through a `replace` line.
6. **This is a gap in the tests and in the contract text, not in shipped behaviour.** Nothing in production uses it, and the private handoff still has no production caller. It is the same impact, shown the same way, that the red team and two audits rated medium and blocking. It also makes three sentences that this repair added to the owner document untrue as written.
7. **The repair is small and touches no production code.** Read every package the go command compiles from the repository, whatever its directory is called, and correct one comment. Today no Go file lives in such a directory, so the stricter rule costs nothing (I checked with a mutant). Section 9 lists it.
8. **Two low items for the same repair.** A file that already imports `unsafe` is listed by its import only, so a change inside it passes the guard (A4-2). And the open design question of the writer's section 4.4 is held by prose only (A4-3).
9. **My answer on section 4.4.** Once A4-1 is repaired, the guard is sufficient for this pull request and for merging PR #12 while the handoff has no production caller. The type-level design is not needed for correctness now. I do recommend it as the lasting control, decided before the first production caller, and I recommend that the commissioning gate name that decision so it cannot be forgotten. It is David's choice. Section 7.4 gives the reasons.

What I did not do: red-teaming, macOS, the Linux box. Twelve tests cannot run in this container (nine Remote Alpha operator-script tests of the root package and three old-binary tests of the store package). They fail the same way at `c41e177` and at `faacf16`.

## 2. Audit target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Pull request | draft PR #13 (a fix PR into the PR #12 branch `codex/reliable-submit-operational-handoff-v1`) |
| Topic branch | `claude/project-thread-sqldt7` |
| Audited commit | `faacf16b9d5cd5ddc28b79da5c6c30f2bca6c124` (one commit on top of the previously blocked tip) |
| Tree | `a8d1aabeb9e8357a98313d5d137b84ca570fdd75` |
| Base | `8058561edc08356c46680c204586b3c7796c0ff3` |
| Previously blocked tip | `c41e177f0d264318de3d799d8b28e7f494b18c74` (audit `08-audit.md`), the single parent of the audited commit |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified before the opening runs and before the closing runs) |
| Manifest, base-relative (`8058561..faacf16`) | `4ae3653efe2625c419485a5adb6866a36c39d38a04b35995460e80b8b9d99e68`, 26 changed paths |
| Manifest, repair only (`c41e177..faacf16`) | `87b0aab1fb25b6acb39dfaed0ccd13116fd6ae45865ff3e76376106a19da9e23`, 6 changed paths |
| Implementation report | `09-repair.md`, SHA-256 `33f75a4cfd807574405772ea63ff804762b7bc47538d58a59e6bc3797ffc54c5` (verified) |
| Prior audit | `08-audit.md`, SHA-256 `3c63a4856ba49f7644b386ae0281b9edc63917ad0927dde6eb646719f6e9df57` (verified) |
| Approved design | `04-design-proper-admission.md`, SHA-256 `7ffda583d94909dfb3601068ea07289cf44cec40a8946a8b11a7e7793103398c` |

The repair commit changes six files and adds no path (`git diff --numstat`, mine, equal to the writer's):

| File | Added | Removed |
| --- | --- | --- |
| `.docs/execution_lifecycle/reliable_submit_operational_handoff.md` | 71 | 16 |
| `PLANS.md` | 40 | 3 |
| `docs_contract_test.go` | 83 | 12 |
| `es/admission/reliable_submit_guardrails_test.go` | 10 | 2 |
| `es/admission/reliable_submit_operational_admission_test.go` | 169 | 0 |
| `es/admission/workstream_c_guardrails_test.go` | 1,044 | 163 |

`go.mod` and `go.sum` are unchanged.

## 3. Audit posture

- Read-only. The provenance clone `/home/user/Execution-Substrate` was never modified in its working tree. Every test, mutant and probe ran in scratch copies under `/home/ci` (`tip`, `prev`, `probe`, `mut`, `syn`), as the unprivileged user `ci`, with a clean environment, `GOPROXY=off`, `GOFLAGS=-mod=readonly`, `GOTOOLCHAIN=local` and umask 022 (Go 1.26.5, linux/amd64, 4 cores).
- One auditor. No subagent was used.
- Mutation status: 19 mutants and 26 probes on the real packages were applied to scratch copies only and reverted after each run. The runner refuses to continue when a scratch copy is not back to its starting state. Nothing was committed anywhere.
- Side effects: none outside this container and the shared report folder. No push, no comment, no pull request change, no merge. GitHub was read through `git fetch` and `git ls-remote` only.
- The writer's evidence archive and the prior audit's probe file were read as data. From the prior audit's probe file I evaluated only its constant source strings, to re-run the same probes; none of its other statements ran.
- One probe direction was stopped early. A change inside a file that already imports `unsafe` was measured once (probe U1, finding A4-2). I did not build further variants of it, so that finding states only what that one run shows.

## 4. Provenance reproduction

1. Recipe bytes checked against the pinned SHA-256 before use: match.
2. `git ls-remote` showed `refs/heads/claude/project-thread-sqldt7` at `faacf16b…` at the start and again at the end of the audit (2026-11-22T21:39Z). `8058561` is an ancestor of `c41e177`, and `c41e177` is the single parent of `faacf16`.
3. Base-relative manifest: branch checked out under its own name at the tip (umask 022), `git reset --mixed 8058561…`, upstream pinned to `origin/codex/reliable-submit-operational-handoff-v1`, recipe run twice. Both runs gave `4ae3653e…9e68` (26 files), byte-equal to each other and to the writer's manifest file.
4. Repair-only manifest: `git reset --mixed c41e177…`, upstream pinned to `origin/claude/project-thread-sqldt7`, recipe run twice. Both runs gave `87b0aab1…9e23` (6 files), byte-equal in the same way.
5. No mode-bit difference occurred.
6. Closing: after the last run I verified the recipe hash again, confirmed the clone was clean (`git status --porcelain --ignored` empty) and at the tip, and re-ran both manifests twice. All four files are byte-equal to the opening ones. The clone is at the tip, clean, with its upstream set back to the topic branch.

Opening and closing manifests are in `10-audit-evidence/manifests/`.

## 5. Coverage

| Area | What I inspected |
| --- | --- |
| Governing documents | The operating protocol and the provenance guide (whole). `08-audit.md` findings and required corrections. `09-repair.md` (whole). The owner document `.docs/execution_lifecycle/reliable_submit_operational_handoff.md`: every changed hunk, the guard rules and limits (:556-645), the outcome table and cancellation paragraph (:675-721), the commissioning table (:1362-1367). `PLANS.md`: every changed hunk. |
| Guard (test code) | In `workstream_c_guardrails_test.go`: the directory listing and the import inventory (:3726-3862), the file-set check and its test (:3864-4034), the loader and its package selection (:4277-4621), the shape, mirror, holds, contains and reaches rules and the whole-value walk (:4686-5415), the foreign-package inventory (:4750-4790), the type parameter inventory. In `reliable_submit_guardrails_test.go`: the commissioning prerequisites. |
| Tests | Every changed hunk of the four changed test files. The new test `TestOperationalAdmissionDenialUnderAnEndedContextAnswersDenied` in full. |
| Production source (unchanged) | Read for the low findings only: `qualifyOperationalRetained`, the `qualify` closure of the handoff, `reconcileOperational`, `observe` and `operationalExchangeFailure`, the Service struct. |
| Validation evidence | My own runs (section 8). The writer's numbers were compared with mine; the writer's scripts were not executed. |
| Schemas, migrations, scripts, configuration | Not changed by this commit (verified from the path list). Not re-inspected. |
| Not inspected | The 20 base-relative paths this commit does not touch (audited at `c41e177` and byte-identical here). The writer's 56 guard mutants were not re-run; I ran 14 of my own design instead. macOS behaviour and red-teaming (non-goals of the brief). |

## 6. Findings

### 6.1 Summary

| ID | Severity | Type | In one line |
| --- | --- | --- | --- |
| A4-1 | **medium, blocking** | patch defect, test guard and documents (residual of RT-1, A2-1 and A3-1) | The guard reads only the packages `go list ./...` matches and skips `testdata`, dot and underscore directories. A package there is compiled when imported and is read by none of the lists. Shown end to end: a revoked artifact is admitted while the guard tests and the whole suite stay unchanged. |
| A4-2 | low | patch defect, test guard and documents | The import inventory lists which files import `unsafe`, not what they do with it. A change inside the one file of `es/admission` that already imports it passes the guard tests. |
| A4-3 | low | patch defect, documents and gate | The open design decision of `09-repair.md` section 4.4 is deferred to "the design of the integration step" in prose. No machine gate names it. |

No pre-existing issue is raised by this audit. Observations are in section 6.4.

### 6.2 Patch defects

```text
AUDIT FINDING
ID / Type / Severity: A4-1 / test guard (what the inventories read) and owner documents, residual of
  RT-1, A2-1 and A3-1 / medium, blocking
Current contract or strategic target: the owner document as changed by this commit,
  .docs/execution_lifecycle/reliable_submit_operational_handoff.md
  :608-609  "Each owning type is read in every production package of the module, not only in the
            package that declares it."
  :627-630  "an exact import inventory covers every non-test source file of the module, so a new
            reflect, unsafe or C import in any production package fails a test."
  :635-639  "A file-set check fails when ... so no production file of the module is outside the
            inventories."
  PLANS.md:23-27 repeats the three statements. 09-repair.md section 4.2 gives them as the closed
  lists that make the rule one of class.
Path and line: es/admission/workstream_c_guardrails_test.go
  :4450       the loader keeps a package of go list -deps only when it is not DepOnly and its import
              path begins with "execution-substrate/". A package that ./... does not match is
              dropped, although it is compiled into the binary.
  :3746       the directory walk skips every directory named testdata or beginning with "." or "_".
              The import inventory and the file-set check read only what the walk returns.
  :3729-3731  the comment that justifies it: "The go command builds nothing from a directory named
              testdata or from one whose name begins with a dot or an underscore". That holds for
              the pattern ./... only. An import of such a package compiles it
              (10-audit-evidence/probes/language-rules.txt, section 1, Go 1.26.5).
  :4759       the whole-value inventory of other packages loops over the loader's packages, so it
              misses the same packages.
  :4011-4032  the self-test "directories the go command does not build from" pins the exclusion.
Evidence: all at faacf16 in a scratch copy; sources and complete outputs in
  10-audit-evidence/probes/ (probe_hidden.py.txt, probe-hidden-1.txt to -3.txt, probe_rerun.py.txt,
  probe-rerun-1.txt).
  H1A. Added: one package in es/app/testdata/zzaudit that imports reflect and unsafe and changes
    protected fields of the Service and of its installed view, and one import with two calls in
    es/app/app.go behind a condition that is never true. gofmt clean; go build ./... exit 0; go vet
    reports only the lock copy already known at the unchanged tip (result_auth_test.go:395).
    Guard tests: 481 results, 481 pass. Whole suite: 6,529 results, the same 42 failing names as the
    unchanged tip, none new.
    Effect, two probe tests in es/admission that call the same package:
    (a) EGS publishes a revocation of the delivery's artifact. The Service latches supersession and
        refuses twice (reason Unavailable, nothing stored, no request sent). EGS is then made
        unreachable. After the call the same delivery completes: run and receipt returned,
        revision 6, one POST to the provider.
    (b) A retained claim; a restarted Service commissioned with content that revokes the claim's
        artifact refuses twice (reason Denied). After the call it completes: revision 6, one POST,
        with EGS reachable and confirming.
  H1B, H1C. The same package in es/app/_zzaudit and in es/app/.zzaudit: guard tests 481 of 481.
  H1D. A package in es/app/testdata/zzwhole without reflect or unsafe that saves and restores a
    whole Service value, instantiates a generic with it and constrains a type parameter to it:
    guard tests 481 of 481.
  H2A. The package of H1A as a nested module in es/app/testdata/zzmod, reached through a require
    and a replace line in go.mod: guard tests 481 of 481; whole suite 6,527 results, the same 42
    failing names. No test pins go.mod against a replace line.
  Controls. H1E: the whole-value forms of H1D written in es/app itself fail the guard. N1: the
    package of H1D in an ordinary directory (es/zzwhole) fails the guard. N2: reflect and unsafe in
    a file of es/app behind the build constraint cgo fail two guard tests. N3: a Go file under a
    vendor directory fails the file-set check. So the rules work where the guard reads; the gap is
    in what it reads.
Impact: a later change can alter the protected admission state from a package that no list reads,
  while every test described as preventing that stays green. The three document sentences above
  are untrue as written. No shipped behaviour is affected: nothing in production has this shape and
  the handoff has no production caller (the commissioning gate test passes).
Required correction: R1 in section 9.
Uncertainty: the effect probes use the package's own fixtures (a test EGS, a test provider). I ran
  no go.work variant and no symlinked directory; by reading, a go.work file has the same cause as
  H2A, and a symlinked package directory inside the repository adds nothing new unless its target
  is one of the skipped directories.
Patch defect or pre-existing issue: patch defect. The module-wide rules, the comment and the three
  document sentences are new in this commit.
```

```text
AUDIT FINDING
ID / Type / Severity: A4-2 / test guard (import inventory) and owner document / low
Current contract or strategic target: owner document :622-630: the limits that remain are named
  (reflection, unsafe, cgo), and "for the last three an exact import inventory covers every
  non-test source file of the module, so a new reflect, unsafe or C import ... fails a test".
Path and line: es/admission/workstream_c_guardrails_test.go:3807-3817. The inventory is a map from
  file to imported packages. Two files are listed today, each with unsafe:
  es/admission/execution_roots_darwin.go (built for darwin only, in the package that declares the
  Service) and es/runtimehelper/privilege_linux.go. Nothing constrains what a listed file does.
Evidence: probe U1 (probe_rerun.py.txt, probe-rerun-1.txt). A function added to
  execution_roots_darwin.go that names no field, a stub for the other systems and one call from the
  handoff: gofmt clean; go build exit 0 natively and for darwin/arm64; guard tests 481 of 481. The
  same statements in a test file on linux/amd64 reopen a superseded Service (one probe test, log
  line in probe-rerun-1.txt).
Impact: as A4-1 for the darwin build. A reader of the document would conclude that unsafe can only
  arrive through a new import.
Required correction: R2 in section 9.
Uncertainty: measured for the darwin file only, and the effect on Linux with the statements in a
  test file, not on a darwin host. I did not examine what the second listed file, which is built
  for Linux, could be made to do. The correction covers both files.
Patch defect or pre-existing issue: patch defect in the document sentence and the inventory's
  scope, both new in this commit. The two imports themselves are older.
```

```text
AUDIT FINDING
ID / Type / Severity: A4-3 / documents and commissioning gate / low
Current contract or strategic target: the project rule that nothing is accepted now to be revisited
  later unless a machine-enforced trigger holds it. Precedent: 08-audit.md A3-3, which put the open
  question of the public mapping into the commissioning gate as CP-PUBLIC-MAPPING.
Path and line: 09-repair.md section 4.4 and section 14 ("Open decision, not blocking"): whether the
  protected state moves behind a package border is left to "the design of the integration step".
  es/admission/reliable_submit_guardrails_test.go:1312 lists six prerequisites; none names it.
Evidence: reading.
Impact: the decision can be passed over when the first production caller is added.
Required correction: R3 in section 9.
Uncertainty: whether David wants the question in the gate is his call; the row forces only that it
  is answered, not how.
Patch defect or pre-existing issue: patch defect (the deferral is made in this repair's report).
```

### 6.3 Pre-existing issues

None raised.

### 6.4 Observations

| ID | Observation |
| --- | --- |
| O4-1 | R4, by reading only. The document now names four points where a cancelled call returns the stored run. The fourth, "during the observation of the job", has no test, as the writer says. One detail of it: when the call's deadline passes during that exchange, `operationalExchangeFailure` answers `OperationalTimeout` with the run, not `OperationalCanceled` (`reliable_submit_operational_provider.go:513-520`, `reliable_submit_operational_handoff.go:563-570`). A cancellation there answers `OperationalCanceled`, as the document says. Both results are the ambiguous one and keep the run. The outcome row "the context of the call has ended" does not mention the difference. Not run. |
| O4-2 | `es/admission/reliable_submit_operational_admission_test.go:3343-3347`: the comment of `TestOperationalAdmissionDigestFramesItsConstantParts` ("The audit's 7.5 ...") now sits on top of the comment of the new type `operationalRefusingFromPolicy`, and the test at :3517 has lost it. Cosmetic. |
| O4-3 | The writer reports 166 environment failures in a copy without `.git`; my git clones show 42, the same 42 as at `c41e177`. Not a defect. |
| O4-4 | What a source guard can hold. These inventories are tests in the same repository. They make a bypass a visible, reviewed change; they do not stop a change that edits an inventory together with the code. The outer control is review and a required check on the target branch. |

## 7. What the brief asked me to check

### 7.1 Remaining bypass shapes

| Shape | What I ran | Result |
| --- | --- | --- |
| Reflection | New import behind a build constraint (N2); mutant G10 | Caught where the guard reads. Not caught in a package it does not read: A4-1 |
| `unsafe` | New import (N2); change inside a file that already imports it (U1) | New import caught. Existing file: A4-2 |
| Embedding | EM1 on the real package; synthetic cases A10, F2, F21 | Caught |
| Aliases | AL1 on the real package; synthetic A1, D10b, F20 | Caught |
| Method values and expressions | MV1 | Caught |
| Interfaces | P1 re-run; synthetic F10, F11 | Caught. A pointer passed as an interface value to a called library is the named limit (synthetic W5, W6) |
| cgo | N2 (constraint `cgo`, the guard loads with cgo off) | Caught by two tests. An `import "C"` file is covered by the guard's own self-test; not probed end to end |
| `go:linkname` | Compiler rule only (`language-rules.txt`, section 2) | It needs an `unsafe` import in the same file, so a new one is caught by the import inventory. In a file that already imports `unsafe` it falls under A4-2. Not probed on the real packages |
| Build tags | P2 re-run; N2 | Caught |
| Test-only files | Reading | Not read by design: a `_test.go` file is never compiled into a production binary |
| Vendored code | N3 | Caught |
| Generated code | GC1 (a file with a generated-code header) | Caught: no exemption exists |
| New packages | N1 (ordinary directory); H1A to H1D, H2A (skipped directories, nested module) | N1 caught. The others pass: A4-1 |
| Same-shape types, type parameters, instantiations | E1, E1-DECLARED, E1V, E3 re-run; 84 synthetic cases | Caught, or refused by the type checker |
| Whole values | P3, E2 re-run; synthetic W1 to W21, F1 to F21 (assignments, range clauses, comma-ok forms, `copy`, `clear`, `append`, `make`, `new`) | Caught |
| Assembly, C and object files | Mutant G11 against the guard's self-test | Refused by the file-set check. Not probed end to end |

The 84 synthetic cases are in `10-audit-evidence/probes/synthetic-2.txt`, with their source in `zz_audit10_synthetic_test.go.txt`. I found no case that compiles and records nothing, apart from the named limits. I agree with the writer's argument in section 4.3 of `09-repair.md` as far as these cases reach. It remains reasoning, not a proof.

### 7.2 A3-1 and R1 to R5

| Item | How I checked | Result |
| --- | --- | --- |
| R1 (A3-1) | Re-ran the prior audit's 12 probes on `faacf16` (`probe-rerun-1.txt`). GM1, GM2, P1, P2, E1-CONTROL, E3-CONTROL were caught before and still are. P3, E1-DECLARED, E1, E1V, E2, E3 passed at `c41e177` and fail the guard tests now. Mutants G4 to G9 against the new rules are killed. | Closed. The two document sentences were rewritten; the new scope sentence is the one A4-1 contradicts. |
| R2 (A3-2) | Mutants B1 to B4: a look at the context placed before the policy refusal (the prior audit's M16), before the verifier refusal, before the trust refusal, and a handoff that turns a denial under an ended context into a cancellation. | Closed. All four are killed by the new test. |
| R3 (A3-3) | Reading: `CP-PUBLIC-MAPPING` is the sixth entry of `operationalCommissioningPrerequisites` (:1312) with its count (:1719), a row of the owner document's table (:1367), and named in `PLANS.md`; the docs contract test pins all of them with mutation cases. | Closed. |
| R4 (A3-4) | Reading of the cancellation paragraph (:714-721) against `reconcileOperational` and the provider. | Closed as text. See O4-1 for the untested fourth point and the deadline detail. |
| R5 (A3-5) | Mutants G1 to G3: only the first type argument is read (the prior audit's G04), only the last (G11), and the first and last but not a middle one. | Closed. All three are killed. |
| O3-1 | Reading: the inventory row for `OperationalCustody.admissionCommit` exists (`workstream_c_guardrails_test.go:2721`). | Done. |

### 7.3 No production file changed

Confirmed. `git diff --name-only c41e177 faacf16` lists the six files of section 2; none is a non-test Go file. For each of the ten production files among the pull request's 26 paths, the blob at `faacf16` is the blob at `c41e177`. The full suite shows no result that changed between the two commits.

### 7.4 Section 4.4: is the guard sufficient, or is the type-level design needed for correctness?

**My recommendation.** Do not hold PR #13 for the redesign. Repair A4-1, then the guard is sufficient for this pull request and for merging PR #12 while the handoff has no production caller. Adopt the type-level design as the lasting control, and decide it before the first production caller. Put that decision into the commissioning gate (R3). The choice is David's.

**Why the redesign is not needed for correctness now.**

- The production code is correct as audited, and this commit does not touch it. The guard protects against future changes, not against a defect that exists.
- No production caller of the handoff exists, and a machine gate fails on the first one. So no deployed path depends on the guard today.
- With A4-1 repaired, I know of no route that compiles and is not listed, other than the named limits. I tried the list in section 7.1.
- The redesign changes production code that three audits accepted. It needs its own design review, audit and red-team pass, and it does not fit the frozen 26 paths of this pull request.

**Why I still recommend it as the lasting control.**

- The track record. Four reviews in a row found a gap in this guard, each one step further out: a value conversion (red team), a pointer conversion (A2-1), a generic used from another package (A3-1), and now a package the guard does not read (A4-1). Each repair was correct for the form found. Completeness of a search over source forms cannot be shown by testing; it can only fail to be refuted.
- The size of what must be trusted. The protected state lives in a package of 40 production files and about 15,900 lines. Only two of those files use the protected fields of the Service. The guard that keeps the other 38 away from them is about 9,600 lines of test code and has now needed three repair rounds of its own.
- What the compiler would do instead. With the state in a small package of its own, with unexported fields behind a handle, the three type-level escapes do not compile anywhere outside that package. Naming a field, writing a same-shape type, and copying or overwriting a whole value all end at the package border. That holds for every later Go version without anyone re-deriving it.
- The small package can be pinned whole. A package of one or two files can be held by an exact file list or a content hash, so any change to the trusted code is a reviewed event. That is not practical for 40 files.

**What the redesign would not replace.** It would not have prevented A4-1 or A4-2. Reflection and `unsafe` do not respect package borders, so the module-wide import inventory and the file-set check stay necessary under either design, and R1 and R2 are needed in both. Inside the small package the same guard rules still apply, over far less code.

**On timing.** The writer proposes "the design of the integration step" and I agree with the time. I do not agree with holding it by prose. The first production caller is exactly when the choice stops being free, and the commissioning gate already fails at that moment, so a seventh row there costs one line.

## 8. Validation assessment

### 8.1 What I ran, on which bytes

| Run | Bytes | Result |
| --- | --- | --- |
| Full suite `go test -count=1 ./...` | `faacf16` | 6,527 results: 6,444 pass, 42 fail, 41 skip (280 s) |
| Full suite | `c41e177` | 6,358 results: 6,275 pass, 42 fail, 41 skip (193 s) |
| Comparison | both | 0 results changed. 18 names removed, 187 added, all 187 pass (166 in `es/admission`, 21 in the root package). One new top-level test. The failing sets are identical (42 names, 12 top-level tests); the skip sets are identical (41). |
| Race detector, `es/admission`, the new denial test, the cancellation test and eight guard tests | `faacf16` | 503 results, all pass, no data race warning (538 s) |
| Guard tests alone (11 tests) | `faacf16` | 481 results, all pass |
| Probes on the real packages | `faacf16` in a scratch copy | 26 probes: 5 pass the guard (H1A to H1D as a family of four, H2A) plus U1; 20 are caught (12 re-runs, H1E, N1, N2, N3, EM1, AL1, MV1, GC1). An earlier form of H1D was caught for a reason in my own probe and is kept in `probe-hidden-1.txt`. |
| Synthetic cases against the guard's functions | `faacf16` in a scratch copy | 84 cases, section 7.1 |
| Mutants | `faacf16` in a scratch copy | 18 of 18 killed (4 behaviour, 14 guard); 1 informational (W1, section 9) |

The race run selected `TestOperationalAdmissionDenialUnderAnEndedContextAnswersDenied`, `TestOperationalAdmissionCancelledCallAnswersCanceled` and the guard tests `TestExecutionSubstrateSynchronizedMutableStateReferenceInventoryIsExact`, `TestOperationalHandoffNoPublicStartupOrdinaryOrFixtureCaller`, `TestOperationalHandoffOpaqueAuthorityBoundaries`, `TestRedTeamPR13GuardAccessInventoryEscapes`, `TestOperationalGuardReflectUnsafeImportInventoryIsExact`, `TestTypedObjectReferenceInventoryRejectsEscapes`, `TestOperationalGuardLoadsEveryProductionFile` and `TestTypedMethodReferenceInventoryCountsDynamicDispatch`.

All tests ran as user `ci` in git clones with the store-test overlay applied (`store-test-linux-overlay.patch`, SHA-256 `1173ed062000267f4365ff40b0a7530da9e08d9e7a7a9a922992869143e19ad4`), which changes one test file so that the store tests run in this container.

### 8.2 What the comparison shows

Nothing went from pass to fail. The 18 removed names each have a successor among the added ones (the self-test cases now run once per directory or package). My result count at the tip equals the writer's (6,527).

### 8.3 What did not run

- Twelve tests cannot run in this container: nine `TestRemoteAlpha…` tests of the root package and three old-binary tests of the store package. They fail identically at both commits.
- The race detector ran on the selection above, not on the whole of `es/admission` or on other packages. No production file changed.
- macOS: nothing was run. The darwin target was cross-built for probe U1 only.
- The writer's 56 guard mutants and 5 behaviour mutants were not re-run.

### 8.4 Evidence files (`10-audit-evidence/`)

`README.md` lists them. In short: `manifests/` (opening and closing), `suite-summary.txt`, `full-suite-compare.tsv`, `race-summary.txt`, `runs.log.txt`, `probes/` (outputs, sources and the compiler rules), `mutants/` (specification and results), `scripts/`, the overlay patch and the numstat of the commit.

## 9. Required corrections (repair scope for the writer thread)

One repair tranche, by the writer thread, on the same branch. No production code needs to change.

**Blocking**

- **R1 (A4-1).** Make "what the go command compiles from this repository" the definition of what the guard reads.
  1. Loader (:4450): keep every package of `go list -deps` that is not in the standard library and whose directory lies inside the repository, whatever `DepOnly` says and whatever its import path is. Fail the test when a package of the closure has a directory that is neither in the Go root, nor in the module cache, nor inside the repository.
  2. Walk (:3746): read every directory except `.git`. If fixture Go files under `testdata` are wanted later, hold them in an exact list. Today the real tree passes with the three exclusions removed: my mutant W1 fails only the self-test that pins the exclusion.
  3. Refuse, with an exact test, a `replace` line in `go.mod` that names a local path and a `go.work` file in the repository. Neither exists today.
  4. Self-tests for each of the above, and the end-to-end forms in the maintained overlay probes: a package in a `testdata`, an underscore and a dot directory, with and without `reflect` and `unsafe`, and a nested module behind a `replace` line. Replace the self-test "directories the go command does not build from" (:4011-4032), which pins the gap.
  5. Correct the comment at :3729-3731. Then check the three sentences of the owner document (:608-609, :627-630, :635-639) and `PLANS.md:23-27` against the corrected guard; they become true with it.

**Low, same tranche**

- **R2 (A4-2).** Pin what a file that imports `reflect`, `unsafe` or `C` does. The simplest closed form is a content hash per listed file in the import inventory, so that any change to such a file is a reviewed inventory change. Say in the owner document's limit sentence that the listed files are held that way.
- **R3 (A4-3).** Add a seventh prerequisite to the commissioning gate, in the owner document's table and in `operationalCommissioningPrerequisites` with its count: the decision whether the protected admission state moves behind a package border or the source guard stays the lasting control. Suggested identifier: `CP-STATE-BOUNDARY`. This records the question only. If David prefers not to have it in the gate, the coordinator can drop R3.

**Optional, cheap**

- O4-1: say in the cancellation paragraph that a deadline passing during the observation exchange answers `OperationalTimeout` with the run, or add the test for that point.
- O4-2: move the stray comment back to its test.

**After the repair:** new provenance for the new tip, a replacement implementation report, then a fresh audit. Its brief can point at the delta: the loader's selection, the walk, the import inventory, their self-tests and the changed sentences. The red-team pass on the combined PR #12 comes after an accepted audit, as planned.

## 10. Sensitive-material handling

No secret, key, token, credential, personal contact detail or host address was read, written or copied. The evidence holds test names, counts, source lines of my own probes and manifest metadata (repository-relative paths, modes, sizes, SHA-256 values). The commit author's e-mail address is not reproduced. No model identifier appears in this report or its evidence.

## 11. Remaining uncertainty and stop conditions

- **The guard is a search over source forms, not a proof.** A4-1 is the route I found. Section 7.1 lists what I tried; it is not exhaustive.
- **A4-2 rests on one run.** I did not examine the second file that imports `unsafe`, and I built no further variant.
- **The effect probes** use the package's own fixtures. They show that the checks are bypassed in the code as written; they are not a test of a deployed system.
- **Not run:** a `go.work` variant, a symlinked package directory, an `import "C"` file end to end, an assembly file end to end, a deadline during the observation exchange (O4-1).
- **Stop conditions met:** none. Provenance reproduced at opening and closing; the report was delivered.

## 12. Confidence

| | Level | Why |
| --- | --- | --- |
| Provenance | 0.99 | Both manifests reproduced twice at the start and twice at the end, byte-equal to the writer's; remote tip unchanged at the end. |
| Validation | 0.9 | Full suite at both commits, 26 probes, 84 synthetic cases and 19 mutants, all run by me on the exact bytes. The race detector ran on a selection. Twelve tests cannot run here. Linux only. |
| Implementation | 0.9 for the four low items of the prior audit; 0.7 for the guard as a whole | Each low item is pinned by a test that my mutants could not get past, or was confirmed by reading. The guard has been found incomplete four times now, each time one step further out. |

## 13. Effect status

Repair, commit, push, pull-request change, comment and merge: **not performed**. The provenance clone is unchanged (closing manifests equal the opening ones). Scratch copies exist only in this thread's container.

## 14. Report delivery

`/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/10-audit.md`, with evidence in `10-audit-evidence/` beside it. The SHA-256 of this file is given in the thread reply that attaches it (a file cannot contain its own hash).

## 15. Final verdict

**BLOCK**

STATUS: READY
