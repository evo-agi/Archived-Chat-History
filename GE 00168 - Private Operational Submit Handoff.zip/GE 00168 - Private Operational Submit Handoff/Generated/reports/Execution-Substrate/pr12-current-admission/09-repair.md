# THIRD REPAIR OF PR #13: the guard refuses a class of escapes by default, and the four low findings

Status of this file: **IMPLEMENTATION REPORT, NOT AUDITED.** It is the replacement implementation report for draft PR #13 after the audit of `c41e177` (`08-audit.md`, verdict BLOCK). It describes the bytes of `faacf16b9d5cd5ddc28b79da5c6c30f2bca6c124`. A fresh audit thread must judge it. The red-team pass on the combined PR #12 comes after an accepted audit.

Written by the PR #13 writer thread on 2026-11-22. Readers: the coordinator, David, and the fresh audit thread.

**About the file name.** The request named `07-repair.md`. That file exists already: it is the report of the second repair, the one the audit `08-audit.md` judged. I did not overwrite it. This report is `09-repair.md`, the next number after `08-audit.md`.

The approved design (`04-design-proper-admission.md`) and the frozen plan (`05-repair.md`, sections 0 to 10) are unchanged and still describe what the pull request builds. This report covers only what changed after `c41e177`.

---

## 1. In plain words

The audit accepted the production code again and blocked on the guard again. This was the third escape of the same guard, each through a new form: first a whole-value conversion, then a pointer conversion, now a generic function that another package uses. The coordinator asked me to check, before patching this form, whether the guard can refuse unlisted forms by default instead of listing escapes one by one.

**It can, and this repair does that.** All three escapes needed the same thing: a second struct type with the same field names as the protected type. Go lets a pointer to one struct type be converted only to a pointer to such a type. So the guard no longer waits for a use it recognises. It lists the second type itself, wherever it is written. Today no such type exists anywhere in the module, so any new one fails a test, whatever is then done with it.

Three more rules close the neighbouring routes in the same way, each as a list that is exact today:

- every type parameter whose constraint leads to a protected type, at its declaration (none exists);
- every type parameter declared in a package that declares a protected type (one exists, `replayPresence[T any]`);
- every whole value of a protected type in every package of the module, not only in the package that declares it (the only ones today are the seal permits that `es/admission` receives from the store).

The checks that every production file is read, and that no production file imports `reflect`, `unsafe` or cgo unlisted, now cover the whole module instead of two packages.

**No production code changed.** The repair is one guard file, three other test files, the plan and the owner document.

The four low findings are repaired in the same commit: a test for a denial under an ended context, a sixth commissioning prerequisite (`CP-PUBLIC-MAPPING`), the document text on where a cancelled call still returns the run, and guard self-tests for a generic with several type arguments.

**The other option I looked at and did not take** is a type-level redesign: move the protected state into a small package of its own, so that the compiler refuses a write from anywhere else. Section 4.4 says what it would buy and why it is not part of this repair. It is a design choice for David, not a fix that is missing here.

**The evidence in short.** Everything ran on the committed bytes of `faacf16`, on Linux. The full suite has 6,527 results: 6,320 pass, 41 skip, and the same 166 environment failures as at `c41e177`. No test went from pass to fail. The race detector on `es/admission` is clean. The audit's twelve probes all fail the guard tests now, the six that passed at `c41e177` among them. All 56 mutants that weaken the new guard rules are caught, and all 5 mutants for the denial under an ended context are killed. A first run of the guard mutants before the commit had left 7 alive; each got a self-test (section 10.2). The 155 earlier mutants that a behaviour test kills were not run again; section 10.4 says why.

Nothing was merged. No branch other than `claude/project-thread-sqldt7` was pushed.

## 2. Identity

| Field | Value |
| --- | --- |
| Objective | Repair findings A3-1 to A3-5 of `08-audit.md` on draft PR #13 (section 9: R1 to R5), the optional O3-1, and answer the coordinator's question whether the guard can refuse unlisted forms by default |
| Repository | `evo-agi/Execution-Substrate` |
| Base ref and SHA | `codex/reliable-submit-operational-handoff-v1` at `8058561edc08356c46680c204586b3c7796c0ff3` (the PR #12 branch) |
| Audited tip this repair starts from | `c41e177f0d264318de3d799d8b28e7f494b18c74` |
| Topic branch | `claude/project-thread-sqldt7` (draft PR #13) |
| Topic commit SHA | `faacf16b9d5cd5ddc28b79da5c6c30f2bca6c124` |
| Tree SHA | `a8d1aabeb9e8357a98313d5d137b84ca570fdd75` |
| Commits after `c41e177` | One: `faacf16` "Refuse a class of guard escapes by default; four low audit findings". Fast-forward push `c41e177..faacf16`. |
| Final working-tree status | clean (`git status --porcelain` empty after the commit and after the push) |
| Recipe | `governed_execution_audit_patch_manifest_v2.py`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified before every run |

## 3. Reconnaissance

- I read `08-audit.md` in full and its evidence folder as data. I did not execute the auditor's scripts. My probe runner reads only string constants of the auditor's probe file with a syntax-tree parser and applies them to a scratch copy (section 10.3). I did not run the auditor's effect tests.
- Facts about today's code, measured with the new rules before any inventory was written:
  - No struct type with the field names of a protected type is written anywhere in the module.
  - No type parameter anywhere in the module has a constraint that leads to a protected type.
  - The module declares one generic type and no generic function: `replayPresence[T any]` in `es/admission/reliable_submit_replay_intent.go`.
  - Outside the package that declares it, a whole value of a protected type occurs in one file: `es/admission/reliable_submit_replay_private.go` receives the store's seal permits by value (six entries, section 5.1).
  - The module has 119 production Go files in 40 packages. The three guarded build targets load all 119. Two import `unsafe` (`es/admission/execution_roots_darwin.go` and `es/runtimehelper/privilege_linux.go`); none imports `reflect` or cgo. There is no assembly, C or object file.
  - Every protected field is unexported.
- The gated entries of the commissioning gate are unexported methods and functions of `es/admission`, so the gate's scope (`./es/...` and `./cmd/es/...`) needs no change: no other package can name them.
- The commissioning gate already applies to the two private handoff entries and to the domain and provider constructors (`reliable_submit_guardrails_test.go`, `TestOperationalHandoffNoPublicStartupOrdinaryOrFixtureCaller`). So the sixth prerequisite is printed for the first production caller of the handoff too, which is where the public mapping matters.
- For R4 I read every place where the handoff answers `OperationalCanceled` (section 5.4).
- The changed-file set against the base is still the 26 paths of `c41e177`. This repair touches six of them and adds no path.

## 4. The question behind this repair: can the guard refuse unlisted forms by default

### 4.1 What the three escapes had in common

| Audit | Escape | What it needed |
| --- | --- | --- |
| Red team, RT-1 | a value converted to a type of the same shape and back | a second struct type with the owner's field names |
| `06-audit.md`, A2-1 | a pointer converted to a pointer to such a type | the same |
| `08-audit.md`, A3-1 | the same conversion inside a generic function that another package instantiates | the same, plus a type parameter that stands for the owner |

Each repair so far added the form of use the audit had found. The guard was a list of known forms, so an unknown form passed.

### 4.2 The rule now: four closed lists

A protected field can be written in two ways. It is named, or it is not named.

**Named.** The exact site inventories list every occurrence of the field's own name with its access kind. They were already a closed list: an unlisted site or kind fails. Unchanged.

**Not named.** Without `reflect`, `unsafe` and cgo, Go offers these routes, and each now has a list that is exact today:

| Route | List | Today |
| --- | --- | --- |
| A whole value of the owning type is created, copied, overwritten or converted | every whole-value occurrence of each owning type, in **every production package of the module** | the declaring packages' existing entries, and six entries in one other file |
| The owner's storage is given a second set of field names | every written struct type with the owner's field names, in the same order and with the same embedding (`whole-mirror`) | none |
| The type is left open until an instantiation | every type parameter whose constraint leads to an owning type, at its declaration (`whole-constrain`); every instantiation with an owning type (`whole-instantiate`, since the second repair, now read in every package); and every type parameter declared in a package that declares an owning type | none; none; one |
| `reflect`, `unsafe`, cgo | every such import in every production file of the module | two `unsafe` imports |
| A file the type checker never reads | the file-set check over every production directory of the module | every file is read |

The second row is what makes the rule one of class and not of form. The three escapes were three ways to *use* a same-shape type. The rule lists the type. A fourth way to use one would fail the same test without the guard knowing that way.

### 4.3 Why the second row is complete (reasoning, not a proof)

The Go specification allows a non-constant value to be converted to another type in a short list of cases. Two of them can give struct storage another type: both types have identical underlying types, or both are pointer types whose base types have identical underlying types (struct tags ignored in both cases). For a struct, "identical underlying type" means the same field names in the same order, the same embedding and the same field types. An unexported field name of one package is never identical to the same spelling in another package.

So a conversion that reaches the storage of an owning type needs a struct type that has the owner's field names. A struct type comes into being in one way only: someone writes a struct type in a source file (named, anonymous, local, generic, in an alias or in a constraint). The guard reads every struct type written in every production package and compares names, order and embedding. It ignores the field types on purpose, so that a generic struct type whose fields are type parameters is listed as well.

For a type parameter the specification applies the same rules to every type of its type set. I checked the consequences with the pinned toolchain (Go 1.26.5), each as a small package that must not compile (`09-repair-evidence/language-rules.txt`):

- a field cannot be selected on a value of a type parameter's type, nor through a pointer to a type parameter;
- a value of an unconstrained type parameter converts to no pointer type;
- a pointer to a type parameter converts to no pointer to a struct type;
- a type parameter constrained to a pointer to the mirror does not accept a pointer to the owner.

What does compile is a type parameter whose constraint names the owner (the audit's form), and that is listed at its declaration. A constraint that names the mirror writes the mirror, and that is listed too.

Every owning type has at least one protected field, and every protected field is unexported, which a test now holds. So a same-shape type can only be written in the owner's own package, and the guard reads that package like every other.

This is an argument from the language rules. I am confident in it and I cannot prove that it has no gap. The auditor should try to break it.

### 4.4 The type-level redesign: what it is, and why it is not in this repair

The coordinator named a second possible shape: a design in which a bypass does not compile.

**What it would be.** Move the protected state (the installed view, the latches, the confirmation time, the owner links) out of `es/admission` into a small package of its own, with unexported fields and a handful of methods. `es/admission`, with its 40 production files, could then not name those fields at all. The compiler would refuse it.

**What it would buy.** The trusted code shrinks from one large package to a small one. Every route of section 4.2 that needs the owner's field names ends at the border of that small package.

**What it would not buy.** Inside the small package the same routes exist, so the same guard is still needed there. All three escapes were written in the package that declares the owner. The named limits of section 14 (aliases, called functions) stay as well.

**Why it is not here.**

- It changes production code that three audits accepted: the lock that protects these fields together with others, and every site that reads them. That is a re-derivation with its own audit and red-team pass, not a repair of a guard.
- It adds files. The frozen scope of this pull request is 26 paths, and the request for this repair was "guard and docs only".
- The guard rule of section 4.2 already answers the audit's finding and the coordinator's question on the code as it is.

**For David, through the coordinator.** This is a design choice with a cost, so it is his: keep the protected state in `es/admission` under the guard as it now is, or ask for a proposal that moves it behind a package border. Nothing in this pull request waits for that decision, and I do not recommend holding the pull request for it. If he wants it, the natural time is the design of the integration step, when commissioning gets its first production caller and the commissioning gate fires anyway.

## 5. What was done, finding by finding

### 5.1 R1, finding A3-1 (medium, blocking): a generic function used from another package

**What the audit asked for.** List a generic at its declaration: treat a type parameter as naming the owner when a term of its constraint is, holds, contains or points to the owning type, and record its declaration with a kind of its own. Add seven self-test forms and a negative control, three end-to-end overlay probes, and correct two sentences of the owner document.

**What was done.** That, as the kind `whole-constrain`, and the three further lists of section 4.2. All of it is in `es/admission/workstream_c_guardrails_test.go`.

| Rule | Where | What it lists |
| --- | --- | --- |
| `whole-constrain` (the audit's R1) | `wholeValueOccurrences`, function `reaches` | a type parameter whose constraint has a type term that is the owning type or leads to it through pointers, slices, arrays, channels, maps, struct fields, the type arguments of a named type, a union, a named or embedded constraint, or another type parameter. The methods of a constraint and the parameters of a function-type term are not followed: they name no storage. |
| `whole-mirror` | `wholeValueOccurrences`, case `*ast.StructType`; `owningStructShape.matches` | a written struct type with the owner's field names, order and embedding. An unexported name counts only when it belongs to the owner's package. Field types and tags are ignored. A struct without fields matches nothing. |
| Type parameter inventory | `typeParameterDeclarations`, `mergedTypeParameterDeclarations`, `genericInventories` | every type parameter declared in a package that declares an owning type: of a generic function, of a generic type (also a local one), and of the receiver of a method of a generic type. Each entry names file, declaration, parameter and constraint. |
| Whole values in other packages | `mergedForeignOwningStructReferences`, `foreignInventories` | every whole-value occurrence of each owning type in every other production package of the module, with the same kinds as in the declaring package. Another package reads the owner from export data, as another object, so there the owner is known by its shape. |
| Unexported protected fields | `validateProtectedFieldName` | fails when an inventoried field is exported. |
| An owner has a field | `validateOwningStructShape` | fails when an owning type has no field. No struct type is the mirror of such a type, so the list for the other packages would say nothing about it. Every owner today is named through a protected field, so this cannot fail today. |
| File set, whole module | `repositoryProductionListings`, `TestOperationalGuardLoadsEveryProductionFile` | a production Go file that none of the three targets compiles, a production Go file in a directory that holds no package, and an assembly, C or object file, in any production directory. The walk leaves out what the go command leaves out (`testdata`, names that begin with a dot or an underscore). A `vendor` directory or a nested module is not left out and fails. |
| Imports, whole module | `TestOperationalGuardReflectUnsafeImportInventoryIsExact` | every `reflect`, `unsafe` and `C` import of every production file. |

**Real inventories added.**

- Other packages (`foreignInventories`): `PrivateReplaySealPermit` has four entries and `ProgressSealPermit` two, all in `es/admission/reliable_submit_replay_private.go`. `Service.admitPrivateSyntheticReplay` and `Service.admitPrivateProgressReplay` each receive a permit from the store by value (`whole-declare`) and hand it to the store's publication call (`whole-read`). The progress permit holds a seal permit by value, so its occurrence counts for both. Every other owning type has no whole-value occurrence outside its package: the list for it is empty and exact.
- Type parameters (`genericInventories`): `es/admission/reliable_submit_replay_intent.go:<package> type replayPresence[T any]`. The store package declares none.
- Imports: `es/admission/execution_roots_darwin.go` and `es/runtimehelper/privilege_linux.go`, `unsafe` each. The second one is new in the inventory because the inventory now reads the whole module; the file itself is unchanged.

**Self-tests.** The guard selection, the eight guard and inventory tests of `es/admission`, has 473 results without a mutant. It had 331 at `c41e177`. The whole-value table has 148 cases (89 at `c41e177`), and the table for another package 31.

- The audit's seven forms are in the whole-value table: a generic function converting to a named twin, to an anonymous mirror, with a write through it, with a whole overwrite through it, with both sides type parameters, a generic type with a converting method, and a chain of two generics. Each is listed now. The audit's negative control (a constraint over an unrelated twin) is there with a twin of another shape; with a twin of the same shape it is no longer a negative control, because the twin itself is listed, and that case is kept as a positive one.
- Further type-parameter cases: the owner by value, `~*Service`, the implicit form `[S *Service]`, a union with the owner as its last, first and middle term, a named constraint, an embedded constraint, a generic constraint, the second parameter, one parameter constrained through another, a slice, a pointer to a pointer, an array, a channel, a map by its element and by its key, a struct that points to the owner, a holder, a generic type, a local generic type, an instance of a generic type that only names the owner as its type argument, an alias of such an instance, and a type that refers to itself and points to the owner. Negative controls: `any`, a constraint to another type, a type that refers to itself, an instance that names another type, a constraint whose method takes the owner, a function-type term.
- Mirror cases: on its own, two same-shape types, other field types, tags, a generic one, one reached from a type parameter, a local one, as a field type, as a parameter type, in a constraint, in an alias declaration. Negative controls: another order, one field more, one fewer, an embedded field of the same name, a struct without fields, an alias of the owner.
- Another package: 31 cases in a second synthetic package that imports the first, among them overwrite, save and restore, a holder, `new`, `make`, `clear`, a generic of either package, a constrained type parameter, a defined type over the owner, a pointer conversion to an instance of a generic same-shape type, and the negative controls (a pointer only, a slice of pointers, a holder through a pointer, another type, unexported names of another package).
- Instantiations: with several type arguments where only one names the owner (section 5.5), and a generic function taken as a value without a call, with a written and with an inferred type argument.
- The union over the three build targets, for both merged lists: an occurrence under the first, the middle or the last target only is listed, and one under every target is listed once.
- An owning struct without fields (it has no mirror, in its own package or in another); a struct type for which the type checker recorded no type (it is listed, because what cannot be compared is not known to differ); the walk under a checkout directory whose own name begins with a dot or an underscore, or is `testdata`.

**End to end on the real packages** (`TestExecutionSubstrateSynchronizedMutableStateReferenceInventoryIsExact`):

- "storage aliases added to the real packages" adds probe functions in memory to the file that declares each of the eleven owning types and requires the exact kinds for every protected field. New forms per owner: a type parameter constrained to the owner and nothing else, a same-shape type and nothing else, and the audit's form (a generic function that converts its type parameter, with no instantiation in the package). The audit's end-to-end forms are there for the types it used: a generic that clears the three Service latches, one that returns the installed view, one that rewrites the view's revocation lists, and one that clears the command latch of a store access. The same subtest requires the type parameter inventory of each declaring package to refuse the probes.
- "whole values of owning types added to other packages" adds probes to a package that imports the owner: `es/app` for the Service, `es/admission` for three store types. It requires an overwrite, a save and restore, a generic instantiation, a constrained type parameter, a conversion to a defined type and a holder field to be listed, each with its exact kind, and a control that only keeps the pointer to change nothing.

**The audit's probes on the new bytes.** Section 10.3. E1, E1V, E1-DECLARED, E2, E3 and P3, which passed the guard at `c41e177`, now fail it.

**Documents.** The owner document states the two new kinds, the type parameter inventory, the reading of every package, and the unexported rule. The two sentences the audit named are replaced: the limit "a generic one is listed only at an instantiation", and the scope sentence with its claim that a whole-value write from another package "yields a Service without a view, which admits nothing". The package-scope limit is gone as a limit, because such a write is now listed. `docs_contract_test.go` pins the new statements, each with a deletion mutant, and refuses a document that states one of the replaced sentences again.

**One thing I did not do as the audit worded it.** R1 asks the scope sentence to say that each owning type is read in the package that declares it, and what a whole-value write from another package yields. I made the guard read the other packages instead, so the sentence now says that. Reason: the fail-closed statement is true for a zeroed Service and for a copy of a commissioned one, but a saved whole value written back to the same Service restores what it held, the latches and the confirmation included. That last sentence is the language's assignment rule. What it would do to admission I did not probe. **Inference:** it would clear a supersession latch and bring back an older confirmation, bounded by the 30 second freshness limit. The document states the assignment rule and not this inference.

### 5.2 R2, finding A3-2 (low): a denial under an ended context

New test `TestOperationalAdmissionDenialUnderAnEndedContextAnswersDenied` in `es/admission/reliable_submit_operational_admission_test.go`, beside `TestOperationalAdmissionCancelledCallAnswersCanceled`.

- "an evaluation that refuses": a retained claim, started after run assignment and after intent. A test policy allows until its k-th evaluation and refuses from then on, and the `evaluated` hook of that refusing evaluation ends the context. For every k the answer must be `OperationalDenied`, with no run and no receipt, the stored state unchanged since the end of the context, and the same operation, write slot and state as a control call under a live context. The test also checks that it reached a refusal at a pre-check, one inside a cut, and one after an earlier cut of the same call had committed.
- "a refusal by the trust content" and "a refusal by the verifier": the two earlier refusals of the same function, which the audit named as unmutated. Here the context is ended from the freshness hook, after the function's own look at the context, and the answer must be `OperationalDenied`.
- A control: the same ending under rules that allow answers `OperationalCanceled`.

Mutants: the audit's M16 and one look at the context inside each of the three refusals, and one at the handoff (section 10.1).

No production code changed: the order was right at `c41e177`, as the audit said.

### 5.3 R3, finding A3-3 (low): the public mapping as a commissioning prerequisite

- Owner document, section 8: a sixth row, `CP-PUBLIC-MAPPING`: the public mapping of the handoff's results and reasons is selected, which includes what a first delivery that ordinary resolution refuses tells its caller. The row states the two facts behind the question: the private result answers `OperationalUnavailable` there, and ordinary Submit names a refusal by the rules (`signer_revoked`, `artifact_revoked`).
- The gate's list `operationalCommissioningPrerequisites` and its count (`es/admission/reliable_submit_guardrails_test.go`) carry the sixth identifier. The gate prints all six when a production reference to a gated entry appears.
- The sentence under the outcome table and the plan entry point to the prerequisite instead of "a later gate". `PLANS.md` lists six identifiers.
- The gate paragraph of the owner document now says what the gate test already did: it also fails on the first production caller of the two private handoff entries and of the domain and provider constructors.
- `docs_contract_test.go`: the six identifiers in the document, the gate and the plan must agree; two new mutation cases remove the sixth from either side.

This decides nothing about the answer itself. The integration step has to decide whether a refused first delivery tells its caller "denied" or "unavailable", and the gate now asks for it.

### 5.4 R4, finding A3-4 (low): where a cancelled call still returns the stored run

Text only. I read every place where the handoff answers `OperationalCanceled`:

| Point | Run in the result |
| --- | --- |
| Reconciliation entry (`reconcileOperational`, the look at the context at its entry) | returned, kind ambiguous |
| Final sender entry: its answer arrives at the reconciliation entry | returned |
| The exchange that observes the job (`operationalProvider.observe`): a cancelled exchange gives the cancellation as its reason | returned |
| Binding of a completed observation | returned |
| Every pre-check, cut and binding before the marker; the marker's own turn; the accept turn; verification of an accepted receipt | not returned |

The owner document now says this: the cancellation row's "Run disclosed" cell, the sentence under the table (the first five rows are value-free; the last one except at the named points), and three sentences in the cancellation paragraph. The document names the first four points as the only ones where a cancelled call returns the run, says that a cancelled answer before the marker is value-free, and says that the one at the verification of an accepted receipt is value-free although run and receipt are durable there.

The audit named three returning points. I added the fourth (the observation exchange) because the code does it, by reading: `observe` returns the exchange's reason, `operationalExchangeFailure` maps a cancelled context to `OperationalCanceled`, and `reconcileOperational` keeps the run for any reason of the observation. The first, second and fourth points and the receipt point are pinned by `TestOperationalAdmissionCancelledCallAnswersCanceled`. **The observation-exchange point is stated from reading; I added no test for it,** because the request was text only.

`docs_contract_test.go` pins the row and the sentences, with five mutation cases.

### 5.5 R5, finding A3-5 (low): instantiations with several type arguments

Three cases in the whole-value table: a generic with several type parameters where only the first type argument names the owner, only the second, and only the middle one of three. Mutants: only the first argument read (the audit's G04), only the last (G11), only the first and the last (section 10.2).

### 5.6 O3-1 (optional): the test seam `admissionCommit`

One exact inventory row for `OperationalCustody.admissionCommit`: left nil by the one function that makes a custody, read twice by the admission write, written nowhere. `OperationalCustody` was an owning type already, through its lock, so the rules of section 4.2 hold for it either way.

### 5.7 The other observations

- O3-2 (a helper function that takes the custody lock would not appear in the lock-holder list): not changed. The typed lock inventory lists every reference to the field, as the audit says.
- O3-4 (probe E2 passes the guard): closed by the reading of other packages. E2 is caught now (section 10.3).
- O3-3 and O3-5: nothing to do. O3-6 (the commit trailer names a model): the trailer is required by the session's rules and is on this commit too. A merge that must carry no model name needs a squash with a clean message.

## 6. Files touched

Six of the 26 paths of the pull request, against the audited tip `c41e177` (`git diff --numstat c41e177 faacf16`). No path is new.

| File | Added | Removed | What changed |
| --- | --- | --- | --- |
| `PLANS.md` | 40 | 3 | A new entry for the corrections after the third audit. Six prerequisite identifiers in two older entries. |
| `.docs/execution_lifecycle/reliable_submit_operational_handoff.md` | 71 | 16 | The guard paragraphs (the two new kinds, the type parameter inventory, every package, the limits). The cancellation row and its sentences. The sixth prerequisite and the gate paragraph. |
| `docs_contract_test.go` | 83 | 12 | Pins for the new and changed statements, their mutation cases, the six identifiers. |
| `es/admission/reliable_submit_guardrails_test.go` | 10 | 2 | The sixth prerequisite in the gate's list and count. `receiverTypeName` names a method of a generic type by its type. |
| `es/admission/reliable_submit_operational_admission_test.go` | 169 | 0 | The test of a denial under an ended context, and its test policy. |
| `es/admission/workstream_c_guardrails_test.go` | 1,044 | 163 | The guard: the rules of section 5.1, their real inventories, self-tests and end-to-end probes. |

Total: 1,417 lines added, 196 removed.

No production file is among them. `git diff --stat c41e177 faacf16 -- '*.go' ':!*_test.go'` is empty.

## 7. Deviations, and what the auditor should know

1. **The report is `09-repair.md`, not `07-repair.md`** (see the top of this file).
2. **More than section 9 of the audit asked for.** R1 asked for one rule. I added three lists and widened two checks to the whole module (section 5.1), because the coordinator asked for a guard that refuses unlisted forms by default. All of it is test code.
3. **The scope sentence of R1 is replaced, not corrected as worded** (section 5.1, last paragraph).
4. **The negative control of R1 is restated.** "A constraint over an unrelated twin" of the same shape is listed now, because the twin is. Three earlier negative controls that used a same-shape twin are restated with a type of another shape, and the same-shape forms are kept as positive cases. Seventeen earlier cases gained a `whole-mirror` count, because their fixture writes a same-shape type. This follows from the rule and weakens no case.
5. **Eighteen subtest names are gone and have successors** (section 9, the comparison by name). They are renamed, split or restated cases of the guard's self-tests and one docs mutation case; no test of behaviour is among them.
6. **A shared helper changed.** `receiverTypeName` (`es/admission/reliable_submit_guardrails_test.go`) now names a method of a generic type by its type. No generic receiver exists in production, so no real site name changes.
7. **A redundant comparison was removed while writing mutants.** `TestOperationalGuardLoadsEveryProductionFile` compared the number of listed and loaded files before the file-set check. The file-set check compares both sets in both directions, so the count could not fail alone. A floor on both numbers remains.
8. **R4 names four points, the audit three** (section 5.4), and one of the four is stated from reading.
9. **Mutants of earlier repairs were not all run again** (section 10.4 says which, and why).
10. **The construction inventory lists the two new kinds as well,** because it calls the same function. Its real inventories did not change.
11. **Self-tests were added because mutants survived.** A first run of the guard mutants on bytes before the commit left seven of 52 alive (section 10.2 names them). Each was a branch of the new rules that no self-test reached. I added a case for each before the commit and did not change a rule. One branch I removed instead: a stop at a function declaration in `typeParameterDeclarations` that changed nothing, because no type declaration encloses a function declaration.
12. **The commit was made and pushed before the final pass.** The session's environment asked for the uncommitted work to be committed and pushed when I stopped to wait for a run, and a cloud container can be reclaimed. So `faacf16` was pushed as a checkpoint after the manifests were taken and the guard tests had passed on its bytes. The build, the vet run, the full suite, the race detector, every mutant and the probes of sections 9 and 10 then ran on the committed tree. Had that pass found a gap, a second commit would have followed. It found none, so `faacf16` is the only commit of this repair.

## 8. Tests

### 8.1 Added

- **`es/admission/reliable_submit_operational_admission_test.go`.** One new top-level test, `TestOperationalAdmissionDenialUnderAnEndedContextAnswersDenied`, with the subtests "an evaluation that refuses" (started after run assignment and after intent), "a refusal by the trust content", "a refusal by the verifier" and "control: the same ending without a refusal is a cancellation". Its test policy `operationalRefusingFromPolicy` is new. Nothing else in the file changed: the diff is 169 added lines.
- **`es/admission/workstream_c_guardrails_test.go`.** No new top-level test. New in `TestExecutionSubstrateSynchronizedMutableStateReferenceInventoryIsExact`:
  - "whole values of owning types added to other packages", end to end on the real packages;
  - "a protected field is unexported" and "an owning type has a field";
  - 61 new cases in the table "whole-value occurrences of the owning struct" (89 cases at `c41e177`, 148 now);
  - "whole-value occurrences of an owning struct in another package", with 31 cases and four further subtests: "the declaring package knows the owner by identity", "an owning struct without fields", "a struct type without a recorded type", "an occurrence under one build target only";
  - "type parameter declarations".
- **The same file, the two module-wide tests.** `TestOperationalGuardLoadsEveryProductionFile` runs each of its eight earlier cases in four directories (the repository root, `es/admission`, a new directory below it, and `es/app`) and has two new subtests, "type-checked directory missing from the listing" and "directories the go command does not build from". `TestOperationalGuardReflectUnsafeImportInventoryIsExact` runs each of its six import cases in three packages (`cmd/es`, `es/admission`, `es/app`) and "removed known import" once for each of the two known files.
- **`docs_contract_test.go`.** Two new subtests, "PublicMappingRemovedFromOwner" and "PublicMappingRemovedFromGate". New mutation cases of the existing rule tests: six for the outcome table (a cancelled answer never or always returns the run, every row value-free, the observation binding withholds the run, the receipt replay returns the run, the public mapping left to a later gate), seven deletions of a new guard statement (`MissingEveryTypeArgumentRule`, `MissingMirrorRule`, `MissingMirrorFieldTypeRule`, `MissingConstrainRule`, `MissingConstrainAtDeclarationRule`, `MissingTypeParameterInventory`, `MissingUnexportedFieldRule`), and five that state a replaced sentence again.

The count of new names by package is in section 9.

### 8.2 Changed

- **"storage aliases added to the real packages"** has three more probe forms for each owning type and the audit's end-to-end forms (section 5.1), and requires the type parameter inventory to refuse the probes.
- **17 earlier cases of the whole-value table expect a `whole-mirror` entry now,** because their fixture writes a type of the owner's shape. Their other expectations are unchanged.
- **Three negative controls are restated,** because a same-shape type is no longer nothing (section 7, item 4). "unrelated same-shape type" and "pointer conversion between unrelated same-shape types" are now the positive cases "same-shape type on its own" and "pointer conversion between two same-shape types", and the negative controls "type of another shape" and "pointer conversion between two types of another shape" take their place. "generic function instantiated with another type" keeps its name and uses a type of another shape.
- **The cases of the two module-wide tests carry the directory or package in their name** (section 9, the names that are gone).
- **`TestOperationalHandoffNoPublicStartupOrdinaryOrFixtureCaller`** expects six prerequisites.
- **`docs_contract_test.go`:** the outcome rule and the guard rule pin the new sentences and refuse the replaced ones. The mutation case `MissingPackageScopeLimit` is replaced by `MissingModuleWideReading`, because the sentence it deleted is gone. `CancellationRowDropped`, `MissingFileSetRule` and `MissingImportInventory` are re-anchored to the new text. The two prerequisite subtests expect six identifiers.

No test was removed without a successor, and none was skipped or disabled.

## 9. Validation

Everything below ran on Linux (amd64, Go 1.26.5, the toolchain `go.mod` pins) in the writer's cloud container, as an unprivileged user, on a copy of the working tree without `.git`.

| What | Exact command | Bytes | Result |
| --- | --- | --- | --- |
| Format | `gofmt -l` on the four changed Go files | working tree with tree id `a8d1aabe`, before the commit | no output |
| Whitespace | `git diff --check c41e177` | same | no output |
| Build | `go build ./...` | copy of commit `faacf16` (tree `a8d1aabe`) | exit 0 |
| Vet | `go vet ./es/admission/ ./es/admission/internal/reliablesubmit/ .` | same copy | one report, `es/admission/result_auth_test.go:395:15` (copied lock). It is the audit's P-2: the same line at every audited tip, in a file this pull request does not change. |
| Full suite | `go test -count=1 -timeout 90m -json ./...`, alone on the machine | same copy | 6,527 results: 6,320 pass, 166 fail, 41 skip. Packages: 19 pass, 2 fail, 20 without tests. `go test` exit 1, as at `c41e177`, because of the 166 known failures. |
| Race detector, admission | `go test -race -count=1 -timeout 120m -json ./es/admission/`, alone | a second copy of the same tree | 2,074 pass, 0 fail, 1 skip. No data race reported. 1,128 s. Exit 0. |

The build, the vet run, the full suite and the race detector ran after the commit, on copies of the committed tree. The script recorded `git write-tree` before the first run and after the last one; both gave `a8d1aabeb9e8357a98313d5d137b84ca570fdd75`, the tree of the commit.

**The full suite against `c41e177`, by package and test name** (`09-repair-evidence/full-suite-compare.tsv`):

| | `c41e177` | `faacf16` |
| --- | --- | --- |
| Results | 6,358 | 6,527 |
| Pass | 6,151 | 6,320 |
| Fail | 166 | 166 |
| Skip | 41 | 41 |
| `es/admission` | 1,925 pass, 1 skip | 2,074 pass, 1 skip |
| Store package | 749 pass, 3 fail, 2 skip | 749 pass, 3 fail, 2 skip |
| Root package | 2,148 pass, 163 fail | 2,168 pass, 163 fail |

- No test went from pass to fail. No test changed its result at all.
- 187 names are new (166 in `es/admission`, 21 in the root package) and all pass. One is a new top-level test, `TestOperationalAdmissionDenialUnderAnEndedContextAnswersDenied`.
- 18 names are gone (17 in `es/admission`, 1 in the root package). Each has successors that pass; the table below lists them.
- The 166 failures are the same 166 names as at `c41e177`: 16 top-level tests with their subtests. None is in a file this pull request touches. Thirteen are in the root package (twelve Remote Alpha operator-script tests, and `TestTrackedGeneratedArtifactHygiene`, which needs `.git`). Three are in the store package and need a probe binary built from an older source tree. The audit lists the same environment failures.
- The 41 skips are the same 41 names.

**The names that are gone, and their successors.** `…/` stands for `TestExecutionSubstrateSynchronizedMutableStateReferenceInventoryIsExact/protected_admission_field_access_kinds/`.

| Name at `c41e177` | Successors now |
| --- | --- |
| `TestOperationalSubmitHandoffCurrentAdmissionV2RejectsUnsafeMutants/MissingPackageScopeLimit` | `TestOperationalSubmitHandoffCurrentAdmissionV2RejectsUnsafeMutants/MissingModuleWideReading` |
| `…/whole-value_occurrences_of_the_owning_struct/pointer_conversion_between_unrelated_same-shape_types` | `…/whole-value_occurrences_of_the_owning_struct/pointer_conversion_between_two_same-shape_types`, `…/whole-value_occurrences_of_the_owning_struct/pointer_conversion_between_two_types_of_another_shape` |
| `…/whole-value_occurrences_of_the_owning_struct/unrelated_same-shape_type` | `…/whole-value_occurrences_of_the_owning_struct/same-shape_type_on_its_own`, `…/whole-value_occurrences_of_the_owning_struct/type_of_another_shape` |
| `TestOperationalGuardLoadsEveryProductionFile/C_file` | 4 names: `TestOperationalGuardLoadsEveryProductionFile/C_file_in_` + `.`, `es/admission`, `es/admission/zzadded`, `es/app` |
| `TestOperationalGuardLoadsEveryProductionFile/assembly_file` | 4 names: `TestOperationalGuardLoadsEveryProductionFile/assembly_file_in_` + `.`, `es/admission`, `es/admission/zzadded`, `es/app` |
| `TestOperationalGuardLoadsEveryProductionFile/document` | 4 names: `TestOperationalGuardLoadsEveryProductionFile/document_in_` + `.`, `es/admission`, `es/admission/zzadded`, `es/app` |
| `TestOperationalGuardLoadsEveryProductionFile/file_behind_a_custom_build_tag` | 4 names: `TestOperationalGuardLoadsEveryProductionFile/file_behind_a_custom_build_tag_in_` + `.`, `es/admission`, `es/admission/zzadded`, `es/app` |
| `TestOperationalGuardLoadsEveryProductionFile/file_for_another_platform` | 4 names: `TestOperationalGuardLoadsEveryProductionFile/file_for_another_platform_in_` + `.`, `es/admission`, `es/admission/zzadded`, `es/app` |
| `TestOperationalGuardLoadsEveryProductionFile/object_file` | 4 names: `TestOperationalGuardLoadsEveryProductionFile/object_file_in_` + `.`, `es/admission`, `es/admission/zzadded`, `es/app` |
| `TestOperationalGuardLoadsEveryProductionFile/preprocessed_assembly_file` | 4 names: `TestOperationalGuardLoadsEveryProductionFile/preprocessed_assembly_file_in_` + `.`, `es/admission`, `es/admission/zzadded`, `es/app` |
| `TestOperationalGuardLoadsEveryProductionFile/test_file_behind_a_custom_build_tag` | 4 names: `TestOperationalGuardLoadsEveryProductionFile/test_file_behind_a_custom_build_tag_in_` + `.`, `es/admission`, `es/admission/zzadded`, `es/app` |
| `TestOperationalGuardReflectUnsafeImportInventoryIsExact/blank_unsafe` | 3 names: `TestOperationalGuardReflectUnsafeImportInventoryIsExact/blank_unsafe_in_` + `cmd/es`, `es/admission`, `es/app` |
| `TestOperationalGuardReflectUnsafeImportInventoryIsExact/cgo` | 3 names: `TestOperationalGuardReflectUnsafeImportInventoryIsExact/cgo_in_` + `cmd/es`, `es/admission`, `es/app` |
| `TestOperationalGuardReflectUnsafeImportInventoryIsExact/grouped_reflect` | 3 names: `TestOperationalGuardReflectUnsafeImportInventoryIsExact/grouped_reflect_in_` + `cmd/es`, `es/admission`, `es/app` |
| `TestOperationalGuardReflectUnsafeImportInventoryIsExact/reflect` | 3 names: `TestOperationalGuardReflectUnsafeImportInventoryIsExact/reflect_in_` + `cmd/es`, `es/admission`, `es/app` |
| `TestOperationalGuardReflectUnsafeImportInventoryIsExact/removed_known_import` | `TestOperationalGuardReflectUnsafeImportInventoryIsExact/removed_known_import_es/admission/execution_roots_darwin.go`, `TestOperationalGuardReflectUnsafeImportInventoryIsExact/removed_known_import_es/runtimehelper/privilege_linux.go` |
| `TestOperationalGuardReflectUnsafeImportInventoryIsExact/renamed_unsafe` | 3 names: `TestOperationalGuardReflectUnsafeImportInventoryIsExact/renamed_unsafe_in_` + `cmd/es`, `es/admission`, `es/app` |
| `TestOperationalGuardReflectUnsafeImportInventoryIsExact/unsafe` | 3 names: `TestOperationalGuardReflectUnsafeImportInventoryIsExact/unsafe_in_` + `cmd/es`, `es/admission`, `es/app` |

The first row is the docs mutation case whose sentence is gone. The next two are the restated negative controls (section 7, item 4): the first successor is the same fixture as a positive case, the second the negative control with a type of another shape. The other fifteen are the cases of the two module-wide tests, which now run once per directory, package or file.

**Focused runs while repairing.** After each change I ran only the tests the change touches, on scratch copies: the eight guard and inventory tests, the new behaviour test, the docs contract tests, and once the whole of `es/admission` with the root package. Those runs are superseded by the full suite above and are not listed one by one.

## 10. Mutants and probes

### 10.1 The denial under an ended context: 5 of 5 killed

The spec is `09-repair-evidence/r3-mutants-spec.py.txt`. The runner (`scripts/mutants-runner.py.txt`) applies one mutant to a scratch copy of the committed tree, runs the behavioural selection of `es/admission` (`-run 'Operational|PR12|RedTeam'`) and counts the leaf tests that fail with the mutant and pass without it. Failures of the guard tests are counted apart and never as a kill by behaviour.

| Mutant | What it changes | Result | First failing test |
| --- | --- | --- | --- |
| R3-M16 | the audit's M16: the look at the context moves before the policy refusal | killed by 2 tests | `TestOperationalAdmissionDenialUnderAnEndedContextAnswersDenied/an_evaluation_that_refuses/after_intent` |
| R3-POLICY | the policy refusal looks at the context first and answers Canceled | killed by 2 tests | `TestOperationalAdmissionDenialUnderAnEndedContextAnswersDenied/an_evaluation_that_refuses/after_intent` |
| R3-VERIFIER | the verifier refusal looks at the context first and answers Canceled | killed by 1 test | `TestOperationalAdmissionDenialUnderAnEndedContextAnswersDenied/a_refusal_by_the_verifier` |
| R3-TRUST | the trust-content refusal looks at the context first and answers Canceled | killed by 1 test | `TestOperationalAdmissionDenialUnderAnEndedContextAnswersDenied/a_refusal_by_the_trust_content` |
| R3-REFUSED-AT | the handoff looks at the context before it reports a refusal it was given | killed by 2 tests | `TestOperationalAdmissionDenialUnderAnEndedContextAnswersDenied/an_evaluation_that_refuses/after_intent` |

All five change production code in the scratch copy only. `R3-M16` is the mutant the audit showed alive at `c41e177`. Output: `09-repair-evidence/final-pass/r3-mutants.txt`.

### 10.2 The 56 mutants of the new guard rules

Each weakens the guard's own code in a scratch copy and runs the guard tests. A mutant counts as caught only when a guard test fails. The spec is `09-repair-evidence/g3-mutants-spec.py.txt`, the runner `scripts/guard-mutants-runner.py.txt`. The guard selection is the eight guard and inventory tests of `es/admission`. Without a mutant it passes (473 results; 331 at `c41e177`). The last column is the number of leaf tests that fail.

| Mutant | What it weakens in the guard | Result | Guard tests that fail |
| --- | --- | --- | --- |
| G3-MIRROR-OFF | a same-shape struct type is not listed | caught | 41 |
| G3-MIRROR-EMBEDDED | shape: the embedded flag is ignored | caught | 1 |
| G3-MIRROR-NAME | shape: the field names are ignored | caught | 2 |
| G3-MIRROR-COUNT | shape: a struct with more fields matches | caught | 1 |
| G3-MIRROR-PKG | shape: an unexported name of another package matches | caught | 1 |
| G3-MIRROR-EMPTY | shape: an owner without fields matches the empty struct | caught | 1 |
| G3-MIRROR-OWN | the owner's own declaration counts as a mirror | caught | 15 |
| G3-MIRROR-UNKNOWN | a struct type without a recorded type is not listed | caught | 1 |
| G3-MIRROR-TYPES | a mirror needs the owner's field types | caught | 8 |
| G3-IS-SHAPE | the declaring package knows the owner by shape, not identity | caught | 19 |
| G3-CONSTRAIN-OFF | a constrained type parameter is not listed | caught | 39 |
| G3-REACH-HOLDS | reach: a by-value term is not followed | caught | 39 |
| G3-REACH-NAMEDARGS | reach: the type arguments of a named type are not followed | caught | 2 |
| G3-REACH-UNALIAS | reach: the type arguments behind an alias are not followed | caught | 1 |
| G3-REACH-SEEN-TRUE | reach: a type met a second time counts as reaching the owner | caught | 7 |
| G3-REACH-SEEN-OFF | reach: a type that refers to itself is followed without end | caught: the test binary stops and `go test` fails |  |
| G3-REACH-POINTER | reach: a pointer is not followed | caught | 36 |
| G3-REACH-SLICE | reach: a slice is not followed | caught | 1 |
| G3-REACH-ARRAY | reach: an array is not followed | caught | 1 |
| G3-REACH-CHAN | reach: a channel is not followed | caught | 1 |
| G3-REACH-MAPKEY | reach: a map key is not followed | caught | 1 |
| G3-REACH-MAPELEM | reach: a map element is not followed | caught | 1 |
| G3-REACH-STRUCT | reach: struct fields are not followed | caught | 2 |
| G3-REACH-EMBEDDED | reach: an embedded or named constraint is not followed | caught | 38 |
| G3-REACH-UNION | reach: the terms of a union are not followed | caught | 9 |
| G3-REACH-UNION-FIRST | reach: only the first term of a union is followed | caught | 2 |
| G3-REACH-UNION-LAST | reach: only the last term of a union is followed | caught | 2 |
| G3-REACH-METHODS | reach: the parameters of a constraint's methods are followed too | caught | 1 |
| G3-INST-FIRST | instantiation: only the first type argument is read (the audit's G04) | caught | 2 |
| G3-INST-LAST | instantiation: only the last type argument is read (the audit's G11) | caught | 2 |
| G3-INST-ENDS | instantiation: only the first and the last type argument are read | caught | 1 |
| G3-FOREIGN-OFF | no other package is read | caught | 1 |
| G3-FOREIGN-SELF | the declaring package is read by shape as well | caught | 1 |
| G3-FOREIGN-IDENTITY | another package is asked for the owner by identity | caught | 1 |
| G3-FOREIGN-TWO | only the admission package and the store are read (the scope audited at c41e177) | caught | 2 |
| G3-FOREIGN-FIRSTVIEW | other packages are read under the first build target only | caught | 1 |
| G3-FOREIGN-LASTVIEW | other packages are read under the last build target only | caught | 1 |
| G3-FOREIGN-NODEDUP | an occurrence is counted once for each build target | caught | 1 |
| G3-TP-OFF | no type parameter is listed | caught | 1 |
| G3-TP-TYPES | the type parameters of a generic type are not listed | caught | 1 |
| G3-TP-CONSTRAINT | an entry does not name the constraint | caught | 1 |
| G3-TP-FIRSTVIEW | type parameters are read under the first build target only | caught | 1 |
| G3-TP-LASTVIEW | type parameters are read under the last build target only | caught | 1 |
| G3-EXPORTED | an exported protected field is accepted | caught | 1 |
| G3-OWNER-EMPTY | an owning type without fields is accepted | caught | 1 |
| G3-WALK-VENDOR | walk: a vendor directory is skipped | caught | 1 |
| G3-WALK-TESTDATA | walk: a testdata directory is read | caught | 1 |
| G3-WALK-DOT | walk: a dot directory is read | caught | 1 |
| G3-WALK-UNDERSCORE | walk: an underscore directory is read | caught | 1 |
| G3-WALK-ROOT | walk: the rule is applied to the root's own name | caught | 1 |
| G3-WALK-TESTGO | walk: test files are read as production sources | caught | 2 |
| G3-FILESET-TWO | file set: only the admission package and the store are checked (the scope audited at c41e177) | caught | 12 |
| G3-FILESET-ROOT | file set: the repository root is not checked | caught | 6 |
| G3-FILESET-DIRECTORY | file set: a type-checked file in an unlisted directory is accepted | caught | 1 |
| G3-IMPORTS-TWO | imports: only the admission package and the store are read (the scope audited at c41e177) | caught | 1 |
| G3-IMPORTS-ADMISSION | imports: the admission package is not read | caught | 6 |

56 of 56 are caught: 55 by a failing guard test, and one, `G3-REACH-SEEN-OFF`, because the test binary stops and `go test` fails. `G3-FILESET-TWO`, `G3-IMPORTS-TWO` and `G3-FOREIGN-TWO` restore the two-package scope audited at `c41e177`, and `G3-CONSTRAIN-OFF` and `G3-MIRROR-OFF` remove the two new kinds, so these rows also show that the new self-tests fail on the audited guard. Output: `09-repair-evidence/final-pass/g3-mutants.tsv`.

33 of the 56 are caught by one test. For most of them it is the one self-test case written for that branch of `reaches`, of the shape comparison or of the directory walk. For some it is a top-level test that stops where it compares a real inventory, which no longer matches, before its self-tests run. The next two paragraphs are about those.

**One extra check, on a scratch copy that differs from the commit.** Nine of the 56 are caught in the pass above by the top-level test alone, where it compares a real inventory: `G3-MIRROR-NAME`, `G3-MIRROR-PKG`, `G3-FOREIGN-OFF`, `G3-FOREIGN-SELF`, `G3-FOREIGN-IDENTITY`, `G3-FOREIGN-NODEDUP`, `G3-TP-OFF`, `G3-TP-TYPES` and `G3-TP-CONSTRAINT` (`G3-MIRROR-NAME` also fails `TestOperationalHandoffNoPublicStartupOrdinaryOrFixtureCaller`). That leaves open whether the self-tests would catch them if the real inventory did not. To answer it I took a scratch copy of the committed tree, made the four real-inventory comparisons of that test report without stopping, and ran the nine again. All nine are caught by self-tests alone, with 47, 1, 5, 5, 4, 1, 2, 2 and 2 failing tests in the order above. That copy is not the committed tree, so the run is not part of the pass above and no count in this report rests on it. Output and the four-line scratch patch: `09-repair-evidence/extra/`.

`G3-IMPORTS-TWO` is a tenth mutant caught by one top-level comparison: the real import inventory names `es/runtimehelper/privilege_linux.go`, which lies outside the two packages. The extra check did not change that test, so its line there shows the same single failure. Inference, from reading the test and not measured: without that entry, the cases that add an import in `es/app` and in `cmd/es` would fail under this mutant.

**History, stated because the first run was not clean.** The first run of the guard mutants was on the working tree before the commit, with 52 mutants. 43 were caught, 7 survived and 2 did not compile.

- **The seven survivors** were `G3-MIRROR-EMPTY`, `G3-MIRROR-UNKNOWN`, `G3-REACH-NAMEDARGS`, `G3-REACH-ARRAY`, `G3-REACH-CHAN`, `G3-REACH-MAPKEY` and `G3-REACH-UNION-LAST`. Each weakens a branch of the new rules that no self-test reached. No rule was wrong. I added a self-test for each before the commit: an owning struct without fields, a struct type without a recorded type, a constraint over an instance of a generic type that only names the owner, an array, a channel, a map keyed by pointers, and a union with the owner as its first and as its middle term.
- **The two that did not compile** were errors in my mutants (`G3-TP-OFF` and `G3-TP-CONSTRAINT` left a variable unused). I corrected the mutants, not the guard. Both are caught.
- **Four mutants were added** for checks that had none: `G3-REACH-UNALIAS`, `G3-REACH-SEEN-TRUE`, `G3-REACH-SEEN-OFF` and `G3-OWNER-EMPTY`, with their self-tests (an alias of an instance, a type that refers to itself with and without the owner, an owning type without a field). That makes 56.
- **The runner gained one verdict.** `G3-REACH-SEEN-OFF` removes the check that stops the walk at a type it has met. The walk then never ends on a type that refers to itself, and the test binary stops with a stack overflow. `go test` fails, but no single test reports a failure, and the runner printed "SURVIVED" for it. I ran the mutant by hand (`first-pass/g3-reach-seen-off.by-hand.txt`: `fatal error: stack overflow`, exit status 1) and gave the runner the verdict `CRASHED` for a run that fails without a failing test. None of the 18 earlier guard mutants is affected: all 18 are caught by failing tests.

The outputs of the first run and of the three reruns are in `09-repair-evidence/first-pass/`. The table above is one complete pass on the committed bytes.

### 10.3 The audit's probes on the new bytes

The runner (`scripts/r3-probes-runner.py.txt`) reads the string constants of the auditor's probe source (`08-audit-evidence/probes/run_real.py.txt`, SHA-256 `41398ddf4672bb12fd1a18a6ee69fd9d57db9f533cee3760cdbef1fbab5434d9`) with a syntax-tree parser, as data. Nothing in that file is executed. It applies each probe to a scratch copy of the tree, checks that the copy still builds, and runs the guard tests. The auditor's effect tests, which show what a probe does once it passes the guard, are not run: the question here is whether the guard tests fail.

| Probe | What it adds | Result at `c41e177` (`08-audit.md`) | Result now |
| --- | --- | --- | --- |
| Baseline | nothing | guard tests pass | guard tests pass (481 results) |
| GM1 | the installed view rewritten through a pointer conversion | caught | caught, 2 guard tests fail (`whole-convert`, `whole-mirror`) |
| GM2 | the Service latches cleared through a pointer conversion of the receiver | caught | caught (`whole-convert`, `whole-mirror`) |
| P1 | commissioning, advance and withdrawal called through an interface | caught | caught (`interface-method`) |
| P2 | a spelled latch write in a file behind a custom build tag | caught | caught (the file-set check) |
| P3 | `*a.service = admission.Service{}` in `es/app` | **not caught**: the named package-scope limit | **caught** (`whole-assign`) |
| E1-CONTROL | a generic latch write in `es/admission`, instantiated in `es/admission` | caught at the instantiation | caught, 2 guard tests fail (`whole-constrain`, `whole-instantiate`, `whole-mirror`) |
| E1-DECLARED | the same generic, instantiated nowhere | **passes** | **caught**, 2 guard tests fail (`whole-constrain`, `whole-mirror`) |
| E1 | the same generic, instantiated from `es/app` (finding A3-1) | **passes**; a revoked artifact is admitted | **caught**, 2 guard tests fail (`whole-constrain`, `whole-mirror`) |
| E1V | three such generics (latches, view, revocation lists), instantiated from `es/app` | **passes** | **caught**, 2 guard tests fail (`whole-constrain`, `whole-mirror`) |
| E2 | a store owning type declared, overwritten and copied in `es/admission` | **passes** (O3-4) | **caught** (`whole-declare`, `whole-assign`, `whole-read`) |
| E3-CONTROL | a generic latch write in the store package, instantiated there | caught | caught (`whole-constrain`) |
| E3 | the same generic, instantiated from `es/admission` (finding A3-1) | **passes** | **caught** (`whole-constrain`) |

Each probe built (`go build ./...` exit 0) before the guard tests ran. The runner uses the auditor's own selection of eleven guard tests, read from the auditor's file, so its baseline has 481 results where the mutant runner's eight tests have 473. The kinds in brackets are the ones the failing tests name. All twelve changes are caught, and the six that passed the guard at `c41e177` are among them. This is the run on the committed bytes; a first run before the commit gave the same thirteen results (`first-pass/r3-probes.first-run.txt`). Output: `09-repair-evidence/final-pass/r3-probes.txt`.

E3 and E3-CONTROL are caught by `whole-constrain` alone, without a mirror: the auditor's store probe writes the latch by name inside the generic body, which the constraint makes possible. That is the case the audit's R1 asked for. E1 is caught twice, by the constraint and by the same-shape type it converts to.

### 10.4 Mutants of the earlier repairs

The earlier repairs left 206 mutants in three specs (133 for `es/admission`, 40 for the store, 33 of the second repair) and 18 mutants of the guard rules of the second repair. At `c41e177` every one had exactly one result: of the 206, 155 were killed by a behaviour test, 43 were caught by guard tests only, and 8 survived, all explained and agreed or reported before.

**What ran again on the committed bytes, and what did not.**

| Group | Mutants | Ran again | Result now |
| --- | --- | --- | --- |
| Caught by guard tests only | 43 | all 43 | all 43 caught by guard tests, as at `c41e177` |
| The guard rules of the second repair | 18 | all 18 | all 18 caught by guard tests |
| Survivors | 8 | all 8 | the same 8 survive, none is killed |
| Killed by a behaviour test | 155 | **none** | carried over, see below |

**Why the 155 were not run again.** A kill by a behaviour test at `c41e177` needs two things to still hold: the production file the mutant changes, and the test that fails. This repair changes no production file (section 6). Of the test files it changes, one holds behaviour tests, `es/admission/reliable_submit_operational_admission_test.go`, and its diff against `c41e177` is 169 added lines and no removed or changed line. The other changed files are the two guard files and the docs contract test. So every test that killed one of the 155 is byte for byte the test it was, and it runs against the same production bytes. The full suite of section 9 shows that all of them still pass without a mutant. This is an argument, not a measurement, and I say so: the auditor may want to run them.

- **One mutant was re-anchored.** `G25-defined-type-over-owner-missed` changes a line of the guard that this repair rewrote (`result = u == owner` became `result = target.is(u)`). The weakening is the same: a defined type over the owner is not seen as holding it. The spec as it was at `c41e177` is `scripts/adm-mutants-spec.c41e177.py.txt`, the current one `scripts/adm-mutants-spec.py.txt`.
- All other anchors of the 206 and of the 18 match the committed bytes unchanged. I checked that before the run.
- **Two of the 18 are caught by fewer tests than at `c41e177`,** and the reason is the new rule. `G2-OPERAND` (the conversion rule ignores the operand side) fails 16 tests where it failed 18, and `G2-OPERAND-PTR` 14 where it failed 16. Four subtests of `TestTypedObjectReferenceInventoryRejectsEscapes` no longer fail under them: "pointer convert away to a same-shape type", "to an anonymous struct", "kept in a variable" and "whole overwrite through a converted pointer". Two new cases fail instead. Each of the four adds an escape that writes a same-shape type. With the conversion rule weakened, the mirror rule still refuses the escape, so the subtest passes. The other 16 of the 18 are caught by as many tests as before or by more.

The eight survivors are the same eight as at `c41e177`: `F2g-limit-inclusive`, `F2b-never-confirmed-accepted`, `C5-content-trust-validity-unchecked`, `C5b-digest-ignores-canonical-error`, `T1b-callback-returns-stored-token` and `GO-advance-where` (each disables one of two checks that refuse the same fault; `05-repair.md` section 11.8, agreed in `06-audit.md` section 7.3), and `R2-INTENT-ALWAYS` and `R2-STAGE-ALWAYS` (`07-repair.md` section 9.1, judged in `08-audit.md`). This repair was not asked to change them and does not.

Outputs: `09-repair-evidence/final-pass/`.

## 11. Failed or skipped validation

**Failed, and why it does not block.**

- Full suite: 166 failing results, the same 166 names as at `c41e177` (section 9). They are twelve Remote Alpha operator-script tests, one test that needs a `.git` directory in the tested copy, and three store tests that need a probe binary built from an older source tree, each with its subtests.
- `go vet`: one report in `es/admission/result_auth_test.go`, a file this pull request does not change.
- The race detector run has no failure.

**Skipped or not run.**

- macOS: nothing was run on a Mac. No production code changed. The guard loads the darwin/arm64 target on Linux, so its inventories cover the darwin file set.
- GitHub CI: none runs on this pull request. Its merge commit does not contain the workflow of PR #14.
- The 155 earlier mutants that a behaviour test kills were not run again (section 10.4).
- The auditor's effect tests were not run (section 10.3).
- The race detector ran on `es/admission`, the one package whose tests this repair changes besides the root package. It did not run on the store package, which is unchanged since `c41e177`, nor on the root package, whose one changed file is the docs contract test.
- 41 tests skip themselves in the full suite, the same 41 as at `c41e177`: 38 in `es/app` that need Docker, Nomad or Vault, and 3 helper-process tests that only run as a child of another test.
- The full suite ran once, after the commit. Before the commit I had run the whole of `es/admission` and the root package once, on earlier bytes of the working tree, and the guard tests after every later change (section 7, item 12).
- The observation-exchange point of section 5.4 is stated from reading and has no test.
- The extra check at the end of section 10.2 ran on a scratch copy with four lines of the guard test changed. It is not a validation of the committed bytes, and no count in this report rests on it.
- The inference of section 5.1 about a saved and restored Service was not probed.
- The store package's tests compile on Linux only with the one-file overlay (`09-repair-evidence/store-test-linux-overlay.patch`, the audit's P-3). The overlay is applied to every scratch copy and is not part of the commit.

## 12. Dependencies, hygiene, widening, cross-repo impact

- **Dependencies:** none changed. `go.mod` and `go.sum` are untouched.
- **Artifact hygiene:** no generated file, binary, database or log is in the commit. The staged set equals the manifest's path list (section 13).
- **Sensitive material:** none read, printed or copied. Tests use keys generated in their fixtures and temporary SQLite files. The evidence folder holds source paths, hashes, test names, test output and scripts. No personal contact detail appears in this report or its evidence.
- **Authority, security or protocol widening:** none. No production file changed: no new caller of any gated entry, no new exported symbol, no schema change, no change to the wire or to a public API. The commissioning gate asks for one more prerequisite, which narrows.
- **Model identifiers:** none in the commit body, in code comments or in the pull request text. The commit carries the required co-author trailer (the audit's O3-6).
- **Cross-repo impact:** none. Only `evo-agi/Execution-Substrate` was touched.
- **PR #14 and PR #12:** not touched. When PR #12 picks up `trunk_dev`, the list line for `TestOperationalHandoffSchema4BinaryRefusesSchema5` still has to be added there, as noted before.

## 13. Provenance

| Item | Value |
| --- | --- |
| Recipe | `governed-execution.audit-patch-manifest.v2` |
| Recipe source SHA-256 | `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked before every run. The recipe file was not edited. |
| Base-relative manifest | SHA-256 `4ae3653efe2625c419485a5adb6866a36c39d38a04b35995460e80b8b9d99e68`, 26 files. Head `8058561edc08356c46680c204586b3c7796c0ff3`, upstream pinned to `origin/codex/reliable-submit-operational-handoff-v1`. |
| Base-relative textual diff | SHA-256 `b503130f5f945dc3cdd5629976a0f4b725f8dc439d67a8d90e7717ac4fddd481` |
| Repair-only manifest, against the audited tip `c41e177` | SHA-256 `87b0aab1fb25b6acb39dfaed0ccd13116fd6ae45865ff3e76376106a19da9e23`, 6 files. Head `c41e177f0d264318de3d799d8b28e7f494b18c74`, upstream `origin/claude/project-thread-sqldt7`. |
| Repair-only textual diff | SHA-256 `02581bef905cf28f77d6756b23e5c701210d8875859b8b9e5f6c57b722a0204e` |
| Taken twice | Each manifest was written twice into a fresh mode-0700 directory outside the repository, and the two files are byte-identical. Both manifests were taken before the commit and again after the push, and those files are byte-identical too. |
| Staged-set check | Before the commit, `git add -A` staged exactly the 6 paths of the repair-only manifest, and `git write-tree` gave `a8d1aabeb9e8357a98313d5d137b84ca570fdd75`, the tree of the commit. After the push, with the index reset to the base, `git add -A` staged exactly the 26 paths of the base-relative manifest; with the index reset to `c41e177`, exactly the 6 paths of the repair-only manifest. |
| Clean status | `git status --porcelain` was empty after the commit and again after the manifests were taken. The local branch equals `origin/claude/project-thread-sqldt7` at `faacf16b9d5cd5ddc28b79da5c6c30f2bca6c124`. |
| Push | Fast-forward `c41e177..faacf16`, no force. |

How the manifests were taken (operating protocol 5.5): record the tip, `git reset --mixed` to the base, pin the upstream, run the recipe twice, `git reset --mixed` back to the tip. The working tree is never changed by this.

The 26 base-relative paths are the same 26 as at `c41e177`: this repair adds no path and removes none.

Complete canonical manifest, base-relative. The block is the file's exact content (one line and a final newline, 5,883 bytes):

```json
{"branch":"claude/project-thread-sqldt7","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/es_execution_admission_model.md","sha256":"a0e6356b08fad47734228a3984ad3f7f5f0dfaee58efb653c4242c66338ea4a3","size":101212},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/implementation.md","sha256":"24a09851c0c9e3c59228a87bfba849d4d349bb435c7b2510fd4ea9830bf3cf29","size":91503},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_operational_handoff.md","sha256":"0846d5927bc6981f80733ead0697b4afc5bff97ba60f691a2ece853a2bc58980","size":109813},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md","sha256":"fac1952edf4ed6d8a90445645851a49b6882ca6efb52182460bb63988147feed","size":166857},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md","sha256":"17d6ea3808063559ec9ae63d0c764d6db4c7a9d3bb0f2fe401d1f698daaff208","size":105872},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/system_overview/boundaries.md","sha256":"13ae36c014ffe3407f75a52a464d3988ed4880d00ea9e3a69e4da9626aeb97a8","size":73385},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"67bf60eb9d14a5101f97fde6c9c8b4f2f54b17ed0701e8a11a9704c2d72194d1","size":319870},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"1a45c056d36008cc3eea24be5e7ac71e80f9d00a91957add54c39573af422c55","size":850443},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/operational_admission.go","sha256":"713d629f0e24b65028096390ad04a0985fd4475d44a98937cc04333148d1c3de","size":13288},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/operational_admission_test.go","sha256":"6e3f33ee5234fbb35cfde4c4313c59dadb3330198544d9a492b1d70918a80bb5","size":78663},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/operational_handoff.go","sha256":"e38ecdcbe199a7423f93348d5ffe6206b32e414f1b75a8a6dbcc0c976fad9bb3","size":63434},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/operational_handoff_test.go","sha256":"0f666893e5f3164c54839eb9bc90d969f895623c7a4a187c779ac1f652538b8f","size":54589},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_structure.go","sha256":"4adcd21ae2396edddd4c552c9fdd5c53b5d61ab56c718573b0985089e5f16ed7","size":19440},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_operational_handoff_schema.go","sha256":"0414016c73ee268a4a14de340cf57fab132ac7d27737a3df8a606cfe8480e74f","size":38102},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_shape.go","sha256":"710668283d3d8075a43c445bda729f35798fa30ccaf88c6aabaffb5a8afb85e7","size":2878},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_guardrails_test.go","sha256":"e523cf9306eabe5481f1a1c1fffbc89d99597912311112e7f47a0175b7b96005","size":91263},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/reliable_submit_operational_admission.go","sha256":"7296d796923ca2b09b1632118a0c0bd302f7b1d199f318e4a123ab8d8d53dd67","size":20582},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/reliable_submit_operational_admission_redteam_test.go","sha256":"8e8bd35644759a06710ce50cc5b0619bbfd7bc5ce46ddfefe84e30f717486062","size":41265},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/reliable_submit_operational_admission_test.go","sha256":"87ec361c3db5967714f2b23362f549de3d05f47c236b2f7c53858232940025d5","size":166478},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_format.go","sha256":"7a0a2128c9412917a400a05eeae6d3650417584042b87e25f333ec108aa1d2dd","size":10157},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_format_test.go","sha256":"2813c540ca0639fbe873cfbb83f6626fd2307def62c737f149d959d5ae5aa8c7","size":31600},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_handoff.go","sha256":"81a23f367716bcd5e50165a1327d2466adf162944a380969fecbfce3b2be882f","size":27411},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_handoff_test.go","sha256":"30bfa1a2090285e74a4e20639b6d5a581d0363e41966e5a8d61b3d8b8b06103d","size":61862},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/resolved_execution_plan.go","sha256":"449dedaaf284bb3798f897b93c42ef282dcebe2c553e7318ffaf7a72e75c7ef0","size":28834},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/service.go","sha256":"317be6476f82f7214ed1d00282acd6779271ddd2d6f20922783800bbc3ef64a7","size":36030},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/workstream_c_guardrails_test.go","sha256":"ee8c1c5e83f18b17c79d72085cb6d7a5f4bc071382c27998b12845e8f634648a","size":445773}],"head":"8058561edc08356c46680c204586b3c7796c0ff3","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"b503130f5f945dc3cdd5629976a0f4b725f8dc439d67a8d90e7717ac4fddd481","upstream":"origin/codex/reliable-submit-operational-handoff-v1"}
```

Complete canonical manifest, repair-only against `c41e177` (1,522 bytes):

```json
{"branch":"claude/project-thread-sqldt7","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_operational_handoff.md","sha256":"0846d5927bc6981f80733ead0697b4afc5bff97ba60f691a2ece853a2bc58980","size":109813},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"67bf60eb9d14a5101f97fde6c9c8b4f2f54b17ed0701e8a11a9704c2d72194d1","size":319870},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"1a45c056d36008cc3eea24be5e7ac71e80f9d00a91957add54c39573af422c55","size":850443},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_guardrails_test.go","sha256":"e523cf9306eabe5481f1a1c1fffbc89d99597912311112e7f47a0175b7b96005","size":91263},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_admission_test.go","sha256":"87ec361c3db5967714f2b23362f549de3d05f47c236b2f7c53858232940025d5","size":166478},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/workstream_c_guardrails_test.go","sha256":"ee8c1c5e83f18b17c79d72085cb6d7a5f4bc071382c27998b12845e8f634648a","size":445773}],"head":"c41e177f0d264318de3d799d8b28e7f494b18c74","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"02581bef905cf28f77d6756b23e5c701210d8875859b8b9e5f6c57b722a0204e","upstream":"origin/claude/project-thread-sqldt7"}
```

## 14. Assumptions, unresolved seams, uninspected areas

**Named limits of the guard, as the owner document lists them.**

- An alias or pointer obtained at an inventoried site and used elsewhere. The site that takes it is listed; what is done through it afterwards is not followed.
- The bodies of called functions and methods. The guard lists a call; it does not follow data through it.
- Reflection inside a called library function on a pointer or container that is passed as an interface value. Such code cannot set an unexported field. It can move or overwrite a whole value. The imports of `reflect`, `unsafe` and cgo in the module's own production files are inventoried.
- The three build targets. A production Go file that none of them compiles fails the file-set check.
- SQL statements assembled at run time, for the table-writer inventory.
- Code outside the module: the standard library and the dependencies are not read.

The guard is a search over source forms with these limits, and not a proof. What changed is that the forms it lists now include the two declarations every escape so far needed, so a new way to use them is refused without being known. The completeness argument of section 4.3 is reasoning. The red-team pass on the combined PR #12 is the planned place to push further.

**Open decision, not blocking.** The type-level redesign of section 4.4 is a design choice for David.

**Open question for the integration step.** Whether a refused first delivery tells its caller "denied" or "unavailable". The commissioning gate now names it (`CP-PUBLIC-MAPPING`).

**Assumptions.**

- No generated or vendored Go code is meant to live in the module. The file-set check fails on a `vendor` directory and on a nested module on purpose; if one is wanted later, the check has to be told.
- Linux only. Nothing was run on macOS.
- `go/types` records an instantiation for every identifier that denotes a generic function or type with its type arguments, inferred ones included. The self-tests cover written and inferred type arguments, at a call and where the generic function is taken as a value. I know of no other place where an instantiation arises.

**Not done, and why.**

- No test for the observation-exchange point of R4, because the request was text only (section 5.4).
- No probe of the saved-and-restored Service (section 5.1). It is listed by the guard in every package now, and nothing in production does it.
- The new rules of the docs contract test are covered by their own mutation cases, which change the document text and require the rule to fail. I ran no further mutants against that test's code.
- The type parameter inventory covers the packages that declare an owning type. A type parameter declared elsewhere is listed only when its constraint leads to an owning type or when it is instantiated with one.

**Uninspected.** Nothing outside the 26 changed paths was read for this repair, except the two files that import `unsafe`, the module's directory listing, and the audit's evidence folder (as data).

## 15. Confidence

- **Provenance: high.** Manifests were taken twice before the commit and twice after the push, byte-identical each time; the staged set equalled the manifest's path list; the remote tip is the commit.
- **Validation: high on Linux, not established on macOS.** The full suite, the race detector on `es/admission`, 130 mutant runs (the 56 and the 5 of this repair, the 18 guard mutants of the second repair, the 43 earlier guard-only mutants and the 8 earlier survivors) and the thirteen probe runs (the baseline and the twelve changes) all ran on the committed bytes. 122 of the 130 are caught; the 8 others are the earlier survivors, which this repair does not touch. The 155 earlier behaviour kills are carried over by argument and not measured again.
- **Implementation: high for the four low items, medium to high for the guard.** Every escape found so far is caught end to end, by more than one rule, and the rule that lists a same-shape type does not depend on how the type is used. The completeness of the lists rests on my reading of the language rules (section 4.3). Three audits found a gap in this guard, each one step further out, so I do not claim there is none left; I claim that a gap now needs a route that uses neither a same-shape type, nor a constrained type parameter, nor a whole value, nor a listed import.

## 16. Report delivery

This file: `/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/09-repair.md`. Its SHA-256 is in the thread reply that attaches it. Evidence: `09-repair-evidence/` in the same folder:

- `README.md`: this list, and how to read the outputs.
- `language-rules.txt`: the language checks of section 4.3, each a small package with the compiler's answer.
- `g3-mutants-spec.py.txt`: the 56 guard mutants of this repair. `r3-mutants-spec.py.txt`: the five behaviour mutants.
- `final-pass/`: the pass on the committed bytes: `g3-mutants.tsv`, `guard18.tsv`, `guardonly.out`, `surv_adm.out`, `surv_store.out`, `surv_r2.out`, `r3-mutants.txt`, `r3-probes.txt`, `build.out`, `vet.out`, the exit files, and `summary.json`, from which the tables of this report are built.
- `first-pass/`: the runs before the commit: the first run of the guard mutants with its survivors, the reruns after each added self-test, the first probe run and the first behaviour-mutant run.
- `extra/`: the extra check of section 10.2 on a scratch copy that is not the committed tree: its output and the four-line scratch patch.
- `full-suite-compare.tsv`: every test result of the full suite at `c41e177` and at `faacf16`, by package and name.
- `race-summary.txt`: the race detector run.
- `manifests/`: the two canonical manifests (base-relative and repair-only), the recipe's output for each, and the staged path lists.
- `changed-files-c41e177-to-faacf16.numstat.txt`: added and removed lines per changed file.
- `store-test-linux-overlay.patch`: the one-file overlay the store tests need to compile on Linux (not part of the commit).
- `scripts/`: the runners and specs as text files: the guard mutant runner and its earlier extra spec, the mutant runner, the specs of the earlier mutants (current, and the admission spec as at `c41e177`), the probe runner, the launch scripts of the final pass, the report builder, the run comparison, and the two helper scripts that copy the tree and run a command as an unprivileged user.

## 17. Effect status

`TOPIC_BRANCH_PUSHED` (`claude/project-thread-sqldt7` at `faacf16b9d5cd5ddc28b79da5c6c30f2bca6c124`) | `DRAFT_PR_OPENED` https://github.com/evo-agi/Execution-Substrate/pull/13 (existing draft, description updated) | `MERGE_NOT_PERFORMED` | `INDEPENDENT_AUDIT_NOT_PERFORMED`

No push to any other branch. No force-push. No comment or review posted. PR #12, PR #14 and the closed PR #15 were not touched.

STATUS: READY
