# REPAIR OF PR #13: durable admission generation, freshness, v1 removal

Status of this file: **IMPLEMENTATION REPORT, NOT AUDITED.** Sections 0 to 10 are the frozen plan with the checkpoint result recorded in section 0; they are unchanged since then. Sections 11 and 12 are the replacement implementation report for draft PR #13 at `b6d2f77`. A fresh audit and a fresh red team must judge it.

Written by the PR #13 writer thread on 2026-11-22. Reader: the coordinator, David, and the fresh audit and red-team threads that follow.

---

## 0. What this plan asks of the coordinator

Nothing is blocked. I am asking for a go at the checkpoint because this is a full-gate tranche, and because six choices below go slightly beyond the letter of the approved design or of the PR #15 instruction. Each is marked **CHECKPOINT** in section 4. In short:

1. PR #15's test file cannot pass byte-for-byte, because the approved design changes what commissioning and withdrawal mean. I will bring an adapted copy into my branch and list every changed line (4.9).
2. The writer callback also receives the stored token, so a fenced process reports Unavailable, not Integrity. The store still does the authoritative comparison (4.2).
3. Establish gets one extra read of the admission row before it reserves capacity, so a stale process cannot burn the domain's 32 reservations (4.3).
4. Withdrawal latches the local process first and then writes the durable row (4.4).
5. One more prerequisite identifier, `CP-RELEASE`, is added to the commissioning gate (4.8).
6. "Zero references to the confirmation source" is implemented as an exact call-site inventory, because the confirmation is called from the private handoff path by design (4.8).

I could not check David's Mac or the Linux box for a kept schema-5 test database (section 3.1). The plan proceeds on the design's stated assumption that none exists.

**Checkpoint result (coordinator, 2026-11-22 05:09Z):** go, yes to all six. Conditions: keep every PR #15 test name, list every changed line here, and no assertion may get weaker. On schema 5: proceed on the design's assumption, since an old-shape database fails closed on open. The plan text below is unchanged from the checkpoint version (SHA-256 `920639e7770cd5c2fb82aecb992af2e5fc228fd0f4e9b89ff286c2ba05aad53f`) except for this paragraph.

---

## 1. Tranche identity

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Topic branch | `claude/project-thread-sqldt7` (draft PR #13) |
| Base | `8058561edc08356c46680c204586b3c7796c0ff3`, branch `codex/reliable-submit-operational-handoff-v1` (PR #12). Re-fetched 2026-11-22: unchanged. |
| Current tip | `e544e0fbe4220dfdd2c2068e3267dcfa454a0cf9`, working tree clean, local equals remote |
| Seam class | Re-derivation on the reliable-submit **Reopened redesign seam** |
| Provenance tier | Full gate. Plan checkpoint required. |
| Doc order | `AGENTS.md` section 7: `PLANS.md`, owning `.docs` pages, tests, code |

Inputs, with SHA-256:

| Input | SHA-256 |
| --- | --- |
| `04-design-proper-admission.md` (the approved design) | `7ffda583d94909dfb3601068ea07289cf44cec40a8946a8b11a7e7793103398c` |
| `02-audit.md` (BLOCK on `e544e0f`) | `ab3d898f96e7ec8685ee3fd6e7411f1e8b995a0abc08fd07856e3152667a8c0b` |
| `03-red-team.md` (HOLDS WITH CAVEATS), as it stands now, with RT-10 | `dbbccbf587548f3786d69464531ced871de037dc68538bd96e42837e9e984959` |
| PR #15 test file at `5ca4079` | `10e705ab457455c1dcf8405b208b5b1ffed339ed27aede7f3b86779b48ccca52` |

Approval: David's message relayed by the coordinator at 04:46Z ("Ok. Please go ahead."), given in reply to the design's decisions. I read that as **D-1 yes** (amend migration 5), **D-2 yes** (freshness in this repair, 30 seconds), **D-3 yes** (delete v1). Coordinator additions: fold in RT-1 with the guard fix, make PR #15's tests pass, and pin all three RT-10 checks.

---

## 2. Scope in one table

| Source | Items in this repair |
| --- | --- |
| Design section 9 | S0 to S5 in full |
| Audit section 7 | R1, R2, R3, R5, R7, R8 as written. R4 and R9 are met by deleting v1. R6 is replaced by the design's document changes plus the pins in 4.7. |
| Audit observations | O-3 (establish gets an in-writer check), O-4 (boundary labels), O-5 (scope of "does not poison"), O-6 (one shared 256 KiB constant). O-2, O-7, O-8, O-9 are not in scope. |
| Red team | RT-1 (guard fix), RT-10 (three checks pinned), RT-2 (reason for a rotated verifier), RT-3, RT-4, RT-5 (contract sentences and pins). RT-6 is resolved by the design. RT-7 to RT-9 need no change. |

Non-goals, unchanged from the design: no change to ordinary Submit, to what `Initialize` does, to EGS, to the original wire format, locator, receipts, staging, the sender or the provider exchange. No public route, DTO, status code or configuration key. No production caller for anything.

---

## 3. Reconnaissance results

### 3.1 Stop conditions of the design (section 9)

| # | Condition | Result |
| --- | --- | --- |
| 1 | A persistent schema-5 database exists | **Not found in what I can see.** No non-test code calls any store opener (`OpenPrivateReplayCustody`, `OpenPrivateReplayProgressCustody`, `OpenProvisionedOperationalCustody`, `openReplayCustody`, `openSQLiteClaimStore`, `openProvisionedOperationalSQLite`), and only `es/admission` imports the store package. **Not checked:** David's Mac and the Linux box. I have no device access in this thread and did not ask for it. If a test database was kept there, amending migration 5 makes it unreadable, which is the safe direction: opening fails closed (see 3.3). |
| 2 | New trigger clauses change codec 3 or 4 | Assessed by reading: migration 5 copies the old rows before it creates any trigger, and both new clauses are gated on codec 5. Verified first in implementation (step 3 of section 6). A failure there stops the repair. |
| 3 | A cut needs the admission package to touch the connection | Not triggered. The store reads the row and hands a value to the callback (4.2). |
| 4 | Confirmation inside a writer turn | Not triggered. The three call points are outside every turn (4.5). |
| 5 | Base drift, or a red-team finding that changes the design | Base unchanged. The red team's findings are consistent with the design; RT-1 and RT-10 are folded in. |

### 3.2 The design's four risks (section 14)

1. **Token in `OperationalOriginalMatch` versus the call-site inventories.** Workable. `MatchOperationalOriginal` keeps its two inventoried call sites for the plain retained read. A second constructor for an admitted match gets its own one-site inventory row.
2. **Trigger clauses versus row preservation.** See stop condition 2.
3. **A hook between COMMIT and release.** The existing commit-fault hook cannot be used: it forces the result to "unknown". One new nil-default hook is needed. It takes no argument that grants anything and returns nothing (4.2).
4. **Confirming before the pre-checks when EGS is slow or the context is cancelled.** No mapping changes. A cancelled context still returns Canceled, because the qualifier tests the context first. A failed or slow confirmation leaves the view stale, which returns Unavailable.

### 3.3 Old-shape refusal

A database carrying the published `8058561` schema-5 shape is refused on open after the amendment, by two independent checks: the pinned schema digest (`verifySQLiteSchemaShape`) and the per-migration source hash in the ledger (`verifySQLiteMigrations`). An existing test pins refusal of a mixed schema (`TestSQLiteV3ReopenRejectsMixedSchemaLedger`), but none uses the exact published shape. I will add one test that builds a database from the `8058561` migration-5 text and requires the opener to refuse it without changing a byte.

### 3.4 Facts that shape the plan

- `go test` for the store package does not compile on Linux at this base (`Stat_t.Mode` width in a test file). PR #14 fixes that on `trunk_dev`. As in the audit, store tests run in a scratch worktree with that one test file overlaid. The overlay is not part of PR #13.
- Baseline at `e544e0f`: `es/admission` 1,382 pass, 0 fail, 3 skip.
- The test Service has no EGS client today. Every fixture needs a small fake EGS that serves a signed trust model, with a request counter.
- Existing tests withdraw from hooks that run inside a writer turn. A durable withdrawal cannot run there (it needs the writer lock). Those tests move to the clock seam or to hooks that run between turns (4.4, 4.5).

---

## 4. Frozen design decisions

The approved design is the specification. This section fixes only what it left open. Names are final unless the compiler or an inventory forces a change, which I will report.

### 4.1 Durable fact (design 5.2)

Table `reliable_submit_operational_admission`, STRICT, created inside the amended migration 5, with the seven columns of design 5.2 and CHECK constraints for each rule. `epoch` and `generation` are stored as positive SQLite integers (so both are limited to 63 bits; the Go side refuses larger values).

Triggers:

- `reliable_submit_operational_admission_no_delete`
- `reliable_submit_operational_admission_guard_insert`: only into an empty table, generation 1, state 1.
- `reliable_submit_operational_admission_guard_update`: installation and epoch unchanged; time nondecreasing; and exactly one of withdraw (same generation, same digest, state 1 to 2) or advance (generation plus one, different digest, new state 1).

Two clauses added to existing triggers:

- `reliable_submit_claims_guard_insert_v5`: when `NEW.codec_version = 5`, abort unless an enabled admission row exists.
- `reliable_submit_claims_guard_operational_update`: when `NEW.latest_operation_kind IS NOT 8`, abort unless an enabled admission row exists. This is a fail-closed superset of "kinds 2, 3, 4, 5": the codec-5 table constraint already limits an update to kinds 2, 3, 4, 5 and 8.

`sqliteSchema5SHA256` is recomputed. Migrations 1 to 4 are untouched.

### 4.2 Store API and token transport (design 5.3, 5.4)

New file `es/admission/internal/reliablesubmit/operational_admission.go`:

- `OperationalAdmissionToken`: opaque comparable value (installation, epoch, generation, digest). The zero value means "none". Only the store mints a non-zero token.
- `OperationalCustody.CommissionOperationalAdmission(ctx, installation, epoch, digest)`, `AdvanceOperationalAdmission(ctx, installation, epoch, digest, expectedGeneration)`, `WithdrawOperationalAdmission(ctx, token)`. Each is one `BEGIN IMMEDIATE` transaction with the rules of design 5.3, modelled on the existing key-state writer. An unknown COMMIT outcome returns an error; the caller stays closed and calls again.
- Withdraw requires the token's installation and epoch to equal the row's. It does not require the generation to match, so a stale process can still stop the domain. This follows design 5.3 ("row at state 1: write state 2") and fails safe.

Token at the cuts:

- The qualify callback type becomes `func(current OperationalAdmissionToken) (OperationalOriginalMatch, error)`. Inside each turn the store reads the row through the turn's connection (zero token when the row is missing or withdrawn), calls the callback with it, and then requires the returned match to carry a token equal to that row. A match built by `MatchOperationalOriginal` carries no token and can never pass a first-effect cut.
- **CHECKPOINT.** The design says the token travels in the returned value and the store compares it. I keep that, and add the argument. Reason: `Apply` returns only a disposition, so without the argument a fenced process would be told "Integrity". With it, the admission package compares its own token to the stored one and reports Unavailable, as design 5.6 requires. The admission package still never sees the connection. Both comparisons are pinned separately: the store's by store-level tests with a wrong token (six operations), the admission package's by asserting the reason.
- `EstablishOperational` gains a token argument, compared inside the establish turn; a mismatch refuses with Unavailable and writes nothing.
- Release: `operationalReleaseQualified` re-reads the row on a pooled connection, beside the existing key re-read, and runs the same callback and comparison.
- Accept with receipt, receipt reads and marked reconciliation: no admission check, as today.
- One new nil-default hook, `ConfigureOperationalReleaseProofForProof(func(OperationalOperation))`, called after a directly acknowledged COMMIT and before the release re-read. It returns nothing. Zero non-test references, by inventory.

### 4.3 Establish capacity hint

**CHECKPOINT.** `EstablishOperational` publishes a sealed original and charges one of the domain's 32 non-refundable reservations before its writer turn. A process that has been fenced but does not know it (for example after a policy-configuration change, which EGS cannot tell it about) would burn one reservation per fresh delivery. I add one pooled read of the admission row at the start of `EstablishOperational`; a mismatch refuses before anything is reserved or published. It is a hint only. The in-turn comparison stays the authority. A change between the hint and the turn can still cost one reservation per race.

### 4.4 Service operations (design 5.3, 5.7)

- `commissionOperationalAdmission(ctx, d *operationalDomain)`: validates as today, builds the admission content, computes the digest, calls the store's Commission for the domain's installation and epoch, then installs the view with the returned token. The store call runs without `Service.mu`; the view is installed only after the transaction ends, and only if the Service is still unlatched and without a view.
- `advanceOperationalAdmission(ctx, d, expectedGeneration)`: the same for a fresh Service whose content differs from the row. A Service that already holds a view cannot advance; it must be restarted. This is design 5.3.
- `withdrawOperationalEffects(ctx, d) bool`: **CHECKPOINT.** It sets the local latch first, then attempts the durable write, and returns true only when the durable withdrawal is confirmed. The design's wording is "then set the local latch". Latching first is strictly more conservative: a failed or unknown durable write still stops this process, which is what design 5.3 means by "failing closed locally and calling again". `Service.mu` is never held across the store call.
- Rule kept from the design: none of the three may be called inside a writer turn. Tests call them only from hooks that run between turns.
- The view stores the **normalized** trust lists, and the digest is taken over exactly those lists, so what is hashed is what is enforced.
- Type and field names stay (`operationalAdmissionSnapshot`, `Service.operationalAdmission`), so PR #15's references keep compiling. The documents call it "the view".

Admission digest: SHA-256 over the label `ESOHADM1`, then length-framed: the trust model's canonical bytes; the verifier's algorithm, key id and public key; the number of built-in policies; and for each policy its identifier string and, for the configured literal-deny policy, every configured entry in order.

### 4.5 Freshness (design 5.5)

- `Service` gains `operationalConfirmed` (time of the last successful confirmation; zero means never) and `operationalSuperseded` (permanent latch), both under `Service.mu`.
- `fetchVerifiedTrustModel(ctx)` is extracted from `Initialize` without changing what `Initialize` does or returns. `Initialize` and the confirmation are its only two callers, by inventory.
- `confirmOperationalAdmission(ctx)`: does nothing without a view, or when a latch is set. Otherwise it samples the clock **before** sending the request, fetches and verifies, computes the digest with the fetched trust, and under a brief lock either records the sampled time (equal) or sets the superseded latch (different). A failure changes nothing.
- Called through one once-per-invocation closure created in `operatePrivateHandoff`, at exactly the three points of the design: before the first authority sample on the fresh-delivery path, and before each of the two pre-checks in `advanceOperational`. Recovery, accepted replay, stamped retries and marked reconciliation never reach those points.
- `currentOperationalAdmission(realm)` additionally requires: not superseded, a confirmation exists, and both the monotonic and the wall-clock elapsed time are non-negative and below the limit. Every existing sample point, including the start and end samples inside the qualifier and the final sender entry, inherits this.
- Limit: `operationalAdmissionConfirmationLimit = 30 * time.Second`, a compiled constant.
- Test seam: `operationalAdmissionProofHooks.skew func() time.Duration`. A non-negative value is added to the elapsed time. A negative value refuses. It cannot shorten the elapsed time, so it cannot lengthen the deadline.

### 4.6 Outcomes (design 5.6)

`OperationalDenied` is appended to the reason list (existing numeric values do not move). Mapping exactly as design 5.6: signer not allowed or revoked, artifact revoked, built-in policy denial, and retained evidence that does not verify under the current verifier return Denied; no view, token mismatch, withdrawn, superseded, deadline passed and unsupported input return Unavailable; malformed or contradictory authenticated evidence returns Integrity. None discloses a run. The handoff result kind stays `operationalUnavailable`.

### 4.7 Low audit items and red-team caveats: what is decided and pinned

| Item | Decision | Pin |
| --- | --- | --- |
| AF-6 | Keep the code order and state it: when a call is both cancelled and refused by the authority, the authority refusal is reported, because it withholds the run and Canceled alone does not. | One test at reconcile, one at the final sender entry |
| AF-7 | Correct the sentence. The durable write is never erased. The result has one write slot and reports the last writer attempted in that call, which is what owner doc section 4 already says. | The audit's same-call probe becomes a maintained test |
| AF-9, RT-3 | State the rule: a refused first-effect cut returns a value-free result. An entry that attempts no cut (recovery, a stamped retry, a marked retry) returns stored facts to the authenticated original caller. Withholding at a refused cut is a result-shape rule, not a confidentiality boundary. | Stamped retry and recovery under allowing, absent, denying and withdrawn authorities: same run, no write, no trust request |
| AF-10 (R7) | The evidence carrier can no longer fail an ordinary request. If the record cannot be marshalled the carrier stays empty and ordinary Prepare and Submit proceed; the private builder already refuses an empty carrier. The unreachable 403 branch is removed. The added marshal is noted in the owner doc. | Empty-carrier refusal test (also kills S10) |
| AF-11 (R8) | Replace the two assertions that cannot fail with a comparison against an independently resolved plan and material. | Same test, real assertions |
| O-5, RT-5 | Scope the sentence: a denial before staging does not poison the claim; after staging the claim keeps its residue and needs a new submit key. | Existing residue test plus one sentence pin |
| O-6 | One exported constant in the store for the 256 KiB evidence cap, used by both layers. | Existing cap vectors |
| RT-2 | Rotated verifier returns Denied (design 5.6). A realm mismatch on an existing original stays Integrity, and the contract says so. | Outcome mapping test |
| RT-4 | One sentence: a returned withdrawal means no later first-effect write commits on the domain; one sender already past its release re-read may still POST. | The design's hook tests at consume and entry |

### 4.8 Tripwires (design section 8) and the guard fix (RT-1, audit R3)

Gates:

- Zero non-test references to `commissionOperationalAdmission`, `advanceOperationalAdmission`, `withdrawOperationalEffects`, the three store operations and the new release hook, each with a positive control (a synthetic production caller must fail the test).
- **CHECKPOINT.** The design also lists "the confirmation source". The confirmation is called from the private handoff path by design, so zero references is not possible. I pin instead: `confirmOperationalAdmission` has exactly one reference (the once-closure in `operatePrivateHandoff`), the closure is invoked at exactly three sites, and `fetchVerifiedTrustModel` has exactly two callers.
- Prerequisite list as a constant beside the gate, printed on failure, and pinned in `docs_contract_test.go` against owner doc section 8: `CP-ROLLBACK`, `CP-EPOCH`, `CP-POLICY-CUSTODY`, `CP-NATIVE`.
- **CHECKPOINT.** I add `CP-RELEASE`: the admission digest covers trust, verifier and policy configuration, not the compiled behaviour of the built-in policies. Two different ES builds with the same configuration present the same digest. Today the owner doc covers that with the premise "one qualified release per domain". The gate now names it, so commissioning cannot be wired without answering it.
- Exactly three store functions contain a statement that writes the admission table, and no production statement names the `installation` or `epoch` column in an UPDATE.
- The clock seam is configured by no non-test source (existing proof-hook inventory, extended).

Guard fix, taking the red team's first option in full:

1. A conversion is a transparent step in the access chain. `(*alias)(s.value).n = 1` becomes a write-through.
2. A channel send on a protected field, and `append` whose first argument is rooted at a protected field, are write-through. (Audit R3; conservative for `append`, which may write into the field's backing array.)
3. Whole values. For a protected field, the reference list now also contains every whole-value occurrence of its owning struct type, each with its own access kind: a positional literal element, a keyed literal that omits the field, an assignment or range-assign whose target is or contains the type by value, a conversion to the type, a declared variable, parameter, result or field that is or contains the type by value, `new`, and `copy` or `clear` over a container of it. The exact field inventories treat these like any other access, so every real inventory gains its construction site explicitly.
4. `validateOperationalAuthorityConstruction` counts the same whole-value forms, so a zero-value declaration and a same-shape conversion are refused.
5. Same-site regressions for a type-assertion chain and for an unresolved selection (kills S7a and S7b).
6. Named limits that remain, in the owner doc: aliases, called functions and methods (generic ones included), reflection and `unsafe`. For the last two, an exact import inventory for `es/admission` and the store package (today: `unsafe` in one darwin-only file, `reflect` nowhere), so a new import trips a test.

### 4.9 PR #15

**CHECKPOINT.** The instruction is to make PR #15's tests pass. Its last test (`TestRedTeamPR13GuardAccessInventoryEscapes`, the RT-1 regression) will pass unchanged against the guard fix. The fuzz targets and the tamper, key-reuse and changed-evidence tests are unaffected in meaning. But the file cannot pass byte-for-byte, because it encodes the old model in four places:

| Old model in the file | New model | Change I will make |
| --- | --- | --- |
| `commissionOperationalAdmission(realm)` succeeds for another epoch or installation on the same store | The store refuses a second identity | The test asserts the refusal, then checks that the uncommissioned Service gains nothing |
| `withdrawOperationalEffects()` is local to one Service | Withdrawal is domain-wide and durable | New signature; later steps re-enable by advancing, as the design requires |
| After ten changed Services, the **original** Service completes the claim | The original Service is fenced once anyone advances | The final retry uses a fresh allowing Service at a new generation ("denial is not terminal") |
| A direct call to the qualifier needs no confirmation | A view with no confirmation admits nothing | One confirmation before the control call |

For the installation check (red-team mutant M3c), the old construction is impossible on one store, so I add the case that pins the same check in the new model: a fresh delivery through a domain qualified for another installation or epoch, using the correctly commissioned Service, must be refused with zero claims.

I will add the adapted file to my branch at the same path, keep every test name, and list every changed line in the final report. PR #15 will then conflict with my branch by design; the red-team thread or the coordinator can close it as taken. I will not push to its branch.

---

## 5. Frozen touched-file scope

`I/` is `es/admission/internal/reliablesubmit/`, `A/` is `es/admission/`.

| Group | Paths |
| --- | --- |
| Plan and contracts | `PLANS.md`; `.docs/execution_lifecycle/reliable_submit_operational_handoff.md`; `.docs/execution_lifecycle/es_execution_admission_model.md`; `.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md`; `.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md`; `.docs/system_overview/boundaries.md`; `.docs/execution_lifecycle/implementation.md`; `docs_contract_test.go` |
| Store | `I/sqlite_operational_handoff_schema.go`; `I/sqlite_replay_shape.go`; `I/operational_handoff.go`; `I/operational_admission.go` (new); `I/replay_custody_structure.go` |
| Store tests | `I/operational_admission_test.go` (new); `I/operational_handoff_test.go`; `I/sqlite_replay_shape_test.go`; `I/sqlite_replay_migration_test.go` |
| Admission | `A/reliable_submit_operational_admission.go`; `A/reliable_submit_operational_handoff.go`; `A/reliable_submit_operational_format.go`; `A/service.go` |
| Admission tests | `A/reliable_submit_operational_admission_test.go`; `A/reliable_submit_operational_handoff_test.go`; `A/reliable_submit_operational_format_test.go`; `A/reliable_submit_operational_admission_redteam_test.go` (new, from PR #15); `A/reliable_submit_guardrails_test.go`; `A/workstream_c_guardrails_test.go` |
| Conditional, only if an existing assertion or inventory in them names a changed object | `I/guardrails_test.go`; `I/sqlite_store_test.go`; `I/sqlite_physical_test.go`; `I/sqlite_replay_schema_test.go`; `I/replay_custody_file_test.go`; `A/reliable_submit_operational_provider_test.go`; `A/reliable_submit_replay_private_test.go`; `A/resolved_execution_plan.go` |

27 firm paths, 3 of them new files. 23 are already among the 42 files that PR #12 plus PR #13 change against `trunk_dev`; the other 4 (`implementation.md` and the 3 new files) bring that total to 46; the owner doc section 9 ceiling is raised to the final count. Any path outside this table stops the repair for a new checkpoint. Migrations 1 to 4, `egs/`, `es/app/`, `es/config/`, `internal/contracts/` and every public surface stay untouched.

---

## 6. Order of work

1. `PLANS.md`: new dated entry. Selects the admission generation, reverses "No SQL migration" for this purpose, removes v1, states the freshness rule, records D-1 to D-3. The 2026-11-20 and 2026-11-22 entries stay as history and are marked superseded where they select v1 or forbid a migration.
2. Owning documents and `docs_contract_test.go` (design S1, audit R5, the sentences of 4.7, the limits of 4.8).
3. Store: amended migration 5 and its shape digest, then the existing migration and shape tests, then the raw-SQL trigger tests. **Stop here if codec 3 or 4 behaviour changes.**
4. Store: row read, the three operations, the token at every cut and at release, the capacity hint, the release hook, scope-3 grammar for v2 only, with the store tests of design section 10.
5. Admission: digest, view, commission, advance, withdraw, confirmation, deadline, outcome mapping, v1 removal, encoder refusal.
6. Tests of design section 10 for admission, two Services, two processes, freshness, commissioning, v1 removal, outcomes; audit R1, R2, R8; the pins of 4.7.
7. Guard fix and inventories (4.8), then the adapted red-team file (4.9).
8. Validation, provenance, one commit, fast-forward push, PR body, final report.

Protocol section 16: I may push intermediate commits to the PR #13 branch when the tree builds and the touched suites pass, each labelled as an unaudited checkpoint. The final provenance covers the cumulative difference from the base.

---

## 7. Tests

All of design section 10, by its own headings: store admission row (lifecycle, triggers by raw SQL, store guard by raw SQL); token at each cut (six operations, four wrong-field cases each, and the advance between COMMIT and release); two Services on one domain (revisions 1, 2 and 3; five content changes; fence for A, Denied for B, completion for C); advance injected at each proof hook; two processes; freshness (six cases); commissioning (audit R2 and the other-database case); v1 removal (three cases); outcomes; gates.

Added by this plan:

- The published schema-5 shape is refused on open (3.3).
- The capacity hint: a stale token refuses a fresh delivery with zero reservations charged and zero sealed objects (4.3).
- The pins of 4.7.
- RT-10: no new claim after withdrawal, both samples (from PR #15); the run-assignment cut under every changed authority after an assign rollback (from PR #15, adapted); the installation check (new case in 4.9).
- The guard's own tests: each whole-value form with a positive and a negative control, conversion chains, channel send, append, type-assertion chain, unresolved selection, the two construction escapes, and the import inventory.

No test is skipped, disabled or weakened. Tests that are rewritten because the model changed (for example `TestOperationalAdmissionV1Compatibility`, replaced by refusals as design section 7 says) are listed one by one in the final report with the reason.

---

## 8. Validation and acceptance

Run as the unprivileged user, `umask 022`, proxy variables unset, after `go mod download`:

- `gofmt -l`, `git diff --check`, `go build ./...`, `go vet` on the two packages (compared with the baseline's known pre-existing report).
- `go test -count=1 ./es/admission/`, and the store package in the overlay worktree.
- `go test -race` for `es/admission` and the store package.
- Root documentation contract tests.
- The remaining packages once, to show nothing outside the scope moved (the three root tests known to fail only in this container are reported, not hidden).
- The audit's mutant script on the new bytes, re-anchored where code moved, plus the mutants named in design section 10 and the red team's C8, M3b, M3c and PAssign.

Acceptance: S1, S2, S3a, S3b, S4, S5, S6a, S7a, S7b, S10, C8, M3c and PAssign are each killed by a behavioural assertion; every mutant named in design section 10 is killed; PR #15's RT-1 test passes unchanged; the red team's end-to-end guard mutant (`mutant-anonymous-struct-conversion.diff`, re-anchored) is now rejected. Any survivor is reported with its reason; I will not call a survivor a redundant layer without showing which adjacent check catches it.

Provenance (procedure 5.5, recipe v2, SHA-256 `c08597e2…a3ca` verified before each run): base-relative manifest against `8058561` with the upstream pinned to `origin/codex/reliable-submit-operational-handoff-v1`, taken twice; plus a repair-only manifest against `e544e0f`. Fast-forward push, no force.

---

## 9. Stop conditions for this repair

The five of design section 9, plus:

6. A path outside section 5 is needed.
7. Any existing test outside the rewritten operational tests changes its result.
8. A design guarantee (design 5.8, items 1 to 5) cannot be pinned by a test that fails under its mutant.
9. The coordinator or David objects to a CHECKPOINT item.

---

## 10. Uncertainty at the checkpoint

- **Not run.** Nothing in this plan has been executed. Risks 2 and 3 of section 3.2 are judged from reading.
- **Not checked.** The Mac and the Linux box for a kept schema-5 database.
- **Guess.** Size: about 700 changed production lines, 2,500 to 3,500 test lines, 350 document lines. The guard fix and the test fixtures are the least certain parts.
- **Guess.** The inventories that the guard fix touches number about twenty entries; if the whole-value forms surface a real production occurrence I did not expect, I will report it as a finding, not edit around it.
- **Open to the audit.** Whether the admission digest's policy part (identifiers and configured entries) is the right canonical content. `CP-RELEASE` names what it does not cover.

---

## 11. Implementation report

IMPLEMENTATION REPORT, operating protocol section 11. Written by the PR #13 writer thread. Nothing in this report is an audit: I wrote the code and the tests, and a fresh audit and a fresh red team must judge them.

Sections 0 to 10 above are the frozen plan. They are unchanged since the checkpoint result was recorded in section 0. This section says what was built, where it differs from the plan, and what the evidence is.

### 11.1 Identity

| Item | Value |
| --- | --- |
| Objective | Repair draft PR #13 to the approved design (`04-design-proper-admission.md`), with the blocking and low items of `02-audit.md` and red-team findings RT-1 and RT-10 |
| Repository | `evo-agi/Execution-Substrate` |
| Base ref and SHA | `codex/reliable-submit-operational-handoff-v1` at `8058561edc08356c46680c204586b3c7796c0ff3` (PR #12). Re-fetched before each manifest run: unchanged. |
| Topic branch | `claude/project-thread-sqldt7` (draft PR #13) |
| Tip the audit blocked | `e544e0fbe4220dfdd2c2068e3267dcfa454a0cf9` |
| Topic commit (audit this) | `b6d2f7787ec8254134cb48fcae0da72bac0fd02c` |
| Tree | `b1d14b017665eb996a82568f229472b6996523f4` |
| Commits from the base to the tip | `e544e0f` Re-check current admission for retained operational handoffs; `1fa8d72` Replace the v1 admission edge with a durable admission generation; `ca902a6` Strengthen the admission tests after reading the mutant evidence; `1826cef` Pin the last freshness sample, the encoder's evidence check and the content checks; `af23316` Pin the admission digest's fields, an unconfirmed withdrawal and overlapping confirmations; `b6d2f77` Pin the writer turn of admission writes without relying on scheduling |
| Working tree after the push | Clean. Local branch equals `origin/claude/project-thread-sqldt7`. |
| `trunk_dev` at the time | `ae326b0ddc30ec6b35883ee32945c622405b68b6`, the merge-base. PR #14 (CI) is not merged, so no CI run covers this branch. |

Reconnaissance: no subagents were used. The reconnaissance results are in section 3.

### 11.2 What was built

The approved design is the specification. This is where each part of it lives.

**Durable fact (design 5.2).** Migration 5 is amended in place. It now creates the one-row table `reliable_submit_operational_admission` (installation, epoch, generation, admission digest, state 1 enabled or 2 withdrawn, update time) with three triggers: no delete; insert only into an empty table at generation 1 and state 1; update only as a withdrawal (same generation and digest, state 1 to 2) or an advance (generation plus one, a different digest, state 1), with installation, epoch and the singleton key immutable and the time never moving back. Two clauses were added to the existing claim triggers: a codec-5 insert, and any codec-5 update other than operation kind 8 (accept), abort unless an enabled admission row exists. The schema-5 shape digest is recomputed. Migrations 1 to 4 are untouched.

**The three operations (design 5.3).** `CommissionOperationalAdmission`, `AdvanceOperationalAdmission` and `WithdrawOperationalAdmission` in the new store file. Each is one `BEGIN IMMEDIATE` transaction that reads the row under the writer lock, decides, writes at most once, re-reads what it wrote and commits. An unknown COMMIT outcome is an error, and each operation is idempotent by content, so the caller stays closed and calls again.

**Token at every cut (design 5.4).** `OperationalAdmissionToken` is an opaque comparable value that only the store can build. Establish compares the presented token with the row inside its writer turn. Assign, intent, stamp and marker read the row through the turn's own connection, hand it to the qualification callback, and require the returned match to carry an equal token. Pre-stage does the same in its turn. The release re-read after COMMIT reads the row again on a pooled connection and runs the same callback and comparison. Accept with receipt, receipt reads and marked reconciliation have no admission check, as before.

**Service side (design 5.3, 5.7).** `Service.installOperationalAdmission` is the one place a view is created. `commissionOperationalAdmission` and `advanceOperationalAdmission` are its only callers. `withdrawOperationalEffects` latches the local process first and then writes the durable withdrawal. None holds `Service.mu` across a store call. The admission digest is SHA-256 over the label `ESOHADM1`, the canonical bytes of the normalized trust model, the verifier's algorithm, key id and public key, and each selected built-in policy with every configured entry.

**Freshness (design 5.5).** `confirmOperationalAdmission` fetches and verifies the signed trust model through `fetchVerifiedTrustModel`, the helper now shared with `Initialize`. Equal content records the time sampled before the request was sent. Different content sets a superseded latch for the life of the process. A failed request changes nothing. `currentOperationalAdmission` refuses when the view is absent, withdrawn, superseded, bound to another realm, never confirmed, or when 30 seconds or more have passed since the last confirmation on either the monotonic or the wall clock. The confirmation runs through one once-per-invocation closure in `operatePrivateHandoff`, at three points: before the first sample on the fresh-delivery path, and before each of the two pre-checks.

**Outcomes (design 5.6).** `OperationalDenied` is appended to the reason list. Denied means the current content refuses the claim. Unavailable means no usable view: absent, fenced, withdrawn, superseded, past the deadline, or an input the built-in set cannot evaluate. Integrity means evidence that contradicts the authenticated original.

**v1 removed (design section 7).** Scope-3 custody accepts only `operational_local_v2`. The encoder refuses a resolution with no evidence record. The reader refuses any other literal. The variant type, the two v1 branches in the handoff and the v1 compatibility test are gone. No Temporary compatibility edge remains in this PR.

**Tripwires (design section 8).** See 11.4, items 1 to 4, for exactly what the tests enforce.

### 11.3 Files touched

25 paths against `e544e0f`: 22 modified, 3 new. Against the base `8058561` the PR changes 26 paths (the one extra is `es/admission/resolved_execution_plan.go`, from `e544e0f`, which this repair does not touch). Against `trunk_dev`, PR #12 plus PR #13 change 46 paths, which is the ceiling the owner document now states in its section 9.

`I/` is `es/admission/internal/reliablesubmit/`, `A/` is `es/admission/`. Lines are added and removed against `e544e0f`.

| Path | Kind | Lines | Summary |
| --- | --- | --- | --- |
| `PLANS.md` | Plan | +58 / -0 | New dated entry: selects the admission generation, reverses "no SQL migration" for this purpose, removes v1, states the freshness rule, records D-1 to D-3. Earlier entries marked superseded where they select v1 or forbid a migration. |
| `.docs/execution_lifecycle/reliable_submit_operational_handoff.md` | Owner contract | +359 / -94 | Admission row, the three operations, the token at each cut, freshness, outcomes, v1 removal, the commissioning gate with its five prerequisite identifiers, the guard's claim and its named limits, the path ceiling. |
| `.docs/execution_lifecycle/es_execution_admission_model.md` | Contract | +45 / -27 | Current admission for the private path restated for the generation and the confirmation. |
| `.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md` | ADR | +38 / -20 | The admission table as part of schema 5; store package file inventory. |
| `.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md` | Contract | +16 / -8 | Outcome text for a denied retained claim. |
| `.docs/system_overview/boundaries.md` | Boundaries | +30 / -16 | PR #12 section relabelled per audit O-4; the admission row and the confirmation named as boundaries. |
| `.docs/execution_lifecycle/implementation.md` | Implementation notes | +1 / -0 | One sentence: the private path confirms trust before first effects, ordinary Submit does not. |
| `docs_contract_test.go` | Contract test | +242 / -43 | Phrase pins and document mutants for all of the above; the prerequisite identifiers in the owner document must equal those beside the gate; store file inventory 36 to 38. |
| `I/sqlite_operational_handoff_schema.go` | Store, schema | +48 / -1 | The table, its three triggers, the two claim-trigger clauses. |
| `I/sqlite_replay_shape.go` | Store, pin | +1 / -1 | New schema-5 shape digest. |
| `I/operational_admission.go` (new) | Store | +318 / -0 | Token type, row read, the three operations in one shared writer transaction, `AdmissionHint`, the release proof hook. |
| `I/operational_handoff.go` | Store | +98 / -21 | Token argument and in-turn comparison in `EstablishOperational`, with the pooled hint before capacity is charged; `OperationalQualification`; comparison in every first-effect turn, in pre-stage and at release; `MatchAdmittedOperationalOriginal`; `OperationalDenied`; `operationalUpdateArgs` split out of the row update. |
| `I/replay_custody_structure.go` | Store, grammar | +9 / -3 | Scope 3 accepts only the v2 literal; `OperationalEvidenceLimit` is the one 256 KiB constant (audit O-6). |
| `I/operational_admission_test.go` (new) | Store tests | +1,453 / -0 | Nine tests, section 11.5. |
| `I/operational_handoff_test.go` | Store tests | +58 / -21 | Fixture commissions its domain; v1 vectors become refusals; callback signature. |
| `A/reliable_submit_operational_admission.go` | Admission | +229 / -55 | Digest, content copy, install, commission, advance, withdraw, confirm, freshness arithmetic, outcome mapping. |
| `A/reliable_submit_operational_handoff.go` | Admission | +51 / -18 | Once-per-invocation confirmation; the fence-first qualification callback; the pre-check; token passed to establish; v1 branches removed. |
| `A/reliable_submit_operational_format.go` | Admission | +24 / -39 | One provenance variant; encoder and reader refuse anything else. |
| `A/service.go` | Admission | +41 / -26 | Two new `Service` fields; `fetchVerifiedTrustModel` extracted from `Initialize`; the evidence carrier can no longer fail an ordinary request (audit R7). |
| `A/reliable_submit_operational_admission_test.go` | Admission tests | +2,309 / -401 | Sixteen new tests, one removed, seven adapted. Section 11.5. |
| `A/reliable_submit_operational_handoff_test.go` | Admission tests | +146 / -7 | Synthetic EGS for every fixture, with a request counter and failing and forging modes; the child-process harness can commission and be held. |
| `A/reliable_submit_operational_format_test.go` | Admission tests | +3 / -2 | Token argument; one confirmation before a direct qualifier call. |
| `A/reliable_submit_operational_admission_redteam_test.go` (new) | Admission tests | +886 / -0 | The red team's file from draft PR #15, adapted. Section 11.6. |
| `A/reliable_submit_guardrails_test.go` | Guard tests | +301 / -32 | Commissioning gate, call-site inventories. Section 11.4. |
| `A/workstream_c_guardrails_test.go` | Guard tests | +819 / -71 | The guard fix for RT-1 and audit R3, the import inventory, updated field and object inventories. Section 11.4. |

Two planned paths were not needed and are untouched: `I/sqlite_replay_shape_test.go` and `I/sqlite_replay_migration_test.go`. Their existing assertions read the pinned constant and pass unchanged, and the published-shape refusal test lives in the new store test file. No conditional path of section 5 was touched. No path outside section 5 was touched.

Against `e544e0f`: production code 819 lines added and 164 removed in 9 files; tests 6,217 added and 577 removed in 9 files; documents 547 added and 165 removed in 7 files. Total 7,583 added, 906 removed.

### 11.4 Deviations from the frozen plan, and what the auditor should know

Each item says what differs and why. None changes the approved design's guarantees. Items 1 to 6 concern what the guard tests enforce.

1. **The three store operations have exactly one production reference each, not zero.** Plan 4.8 said "zero non-test references" to them. That was inexact: each is called by the Service method of the same purpose, and those three Service methods have zero references. The tests enforce exactly one reference per store operation, from that method (commission and advance inside the closure they pass to `installOperationalAdmission`, withdraw directly), and zero for the three Service methods, the two private handoff entries, the domain and provider constructors, `OpenProvisionedOperationalCustody` and the release proof hook. Both documents say the same.
2. **The commissioning gate prints its prerequisites.** `validateOperationalCommissioningGate` fails on any production reference to a commissioning entry and names `CP-ROLLBACK`, `CP-EPOCH`, `CP-POLICY-CUSTODY`, `CP-NATIVE` and `CP-RELEASE`. A test opens the gate with a synthetic caller and requires all five in the message. `docs_contract_test.go` reads the one-line list from the guard file and requires owner document section 8 to carry the same identifiers.
3. **More call-site inventories than planned.** Beyond the planned three (`confirmOperationalAdmission` once, the closure at three sites, `fetchVerifiedTrustModel` twice), the tests pin `installOperationalAdmission` (two callers), `operatePrivateHandoff`, `EstablishOperational`, `AdmissionHint`, `MatchOperationalOriginal` and `MatchAdmittedOperationalOriginal` (one caller each, by site), that `advanceOperational` is called once and receives the confirmation closure as its last argument, and that the local `precheck` is called twice.
4. **Guard fix, beyond the plan's list.** The plan listed conversions, channel send, `append` and whole-value forms. The implementation also classifies a read of the whole struct (`whole-read`), `make`, conversion to a pointer or a container of the type, a type-switch clause that binds the type, an unnamed parameter, result or receiver, and a defined type whose underlying type is the owner. The owner document's guard section lists the same forms. Limits that remain and are named there: aliases, called functions and methods, reflection, `unsafe` and cgo.
5. **Closure occurrences are a kind of their own.** Before, any protected-field access inside a function literal was an error. The qualification callback must read the view's token, so an access inside a function literal now gets the key `site|kind+closure` and must be listed like any other. Existing inventories list none, so they are exactly as strict as before. The only listed closure accesses are the two token reads in the callback.
6. **Object inventories carry whole-value entries.** `validateTypedObjectReferenceInventory` still counts identifier occurrences by site, so every earlier number keeps its meaning, and lists whole-value occurrences separately as `site|kind`. This surfaced existing by-value uses that the old guard could not see, all in unchanged production code: constructor literals of `Service`, the app, the runtime helper and the store types, and the two store permit wrappers that are passed by value by existing design. I changed no production code for these. Each new entry was checked against the source line before it was written.
7. **Import inventory covers cgo too.** `reflect`, `unsafe` and `C` over every non-test source file of `es/admission` and the store package. Today exactly one file imports `unsafe` (`execution_roots_darwin.go`) and none imports the others.
8. **Callback receives the stored token (checkpoint item 2), and compares it first.** The callback refuses before it evaluates any evidence when its view's token differs from the stored one. So a fenced process judges nothing and reports Unavailable. The store's own comparison of the returned token stays the authority and is tested separately with wrong tokens.
9. **Pre-check reads the row once outside a turn.** `OperationalAccess.AdmissionHint` and `OperationalAdmissionToken.Names` are small additions to the store API that the plan did not name. The pre-check uses the hint so that a fenced process does not ask for a writer turn at all. It grants nothing: each cut asks again inside its turn.
10. **Empty-record guard moved.** `composeOperationalOriginal` had its own check for an empty evidence record. With v1 gone the encoder refuses it, so the duplicate was removed and the audit's S10 mutant is anchored at the encoder.
11. **Layered checks I kept, and one copy I removed.** Kept: `confirmed.IsZero()` in the freshness check (a zero time is already further back than the limit), the `elapsed >= limit` clause next to the added-time clause that also refuses at exactly the limit, `trustModel.Validate()` in the content copy (the canonical encoding validates again), the `generation=?` predicate of the advance statement (the same transaction has just compared the generation, and the trigger requires generation plus one), and the store's comparison of the token the callback returns, after the callback has itself compared its view's token with the stored one. Each is cheap and states the intent at the place a reader looks for it. Removed: a second defensive copy of the trust model, since `Normalized()` already returns new lists. Section 11.8 shows for each kept layer which mutant survives and which adjacent check then catches the fault.
12. **A withdrawn domain is re-enabled only by new content.** This is the design (5.3, section 8), stated here because it surprises: commissioning again with the same digest after a withdrawal is refused, and so is an advance to the same digest.
13. **The table does not forbid an all-zero digest; the Go reader does.** A row with a zero digest is treated as corrupt on read. The CHECK constraint covers length only. I left the schema as the design wrote it.
14. **The admission-writer inventory reads statement literals.** `TestOperationalAdmissionTableWriters` finds writes by parsing SQL string literals in the store's sources. A statement assembled at run time from parts would escape it. None exists.
15. **Tests that reach inside.** One test forges a wall-clock step with `unsafe` to prove both clocks are checked. One reaches the "unsupported input" outcome by swapping the view's policy set in memory, because no configuration can select such a policy. The two-process test continues a retained claim, because the child process has no resolver. Proof Services copy `workloadZoneVaultConfigRef` from the fixture so they can also take a fresh delivery. One subtest name avoids a comma because the fixture derives a staging path from the name and scope-3 custody refuses a comma.
16. **`docs_contract_test.go` store inventory.** The persistence ADR's package inventory went from 36 to 38 files for the two new store files.
17. **Tests added after the first push, from reading the mutant results.** The first checkpoint (`1fa8d72`) was pushed before the mutant runs were read. Reading them found thin kills and survivors, and four later checkpoints (`ca902a6`, `1826cef`, `af23316`, `b6d2f77`) add tests only: identity and time rules of the admission triggers inside otherwise valid transitions; the red team's original attacker restored in the adapted file; stale holders and the install-time checks of commissioning; a sweep over every freshness sample of a delivery; a direct test of the qualifier's last sample; the encoder's evidence check; content checks before the store write; content that differs from the stored content in one field; a withdrawal the store does not confirm; two overlapping confirmations; the writer turn of the three admission operations, without relying on scheduling. Production code is unchanged since `1fa8d72`. Section 11.8 lists each gap with its mutant.
18. **The exact sample count.** `TestOperationalAdmissionDeadlineAtEverySample` requires that a complete fresh delivery samples the view exactly 48 times. The number has no meaning of its own. It is exact so that adding or dropping a sample is a deliberate change, because a dropped sample would otherwise only shorten the sweep.

### 11.5 Tests: added, removed, adapted

No test is skipped, disabled or quarantined. Test and fuzz functions by file, before and after:

| File | Before | After | Added | Removed |
| --- | --- | --- | --- | --- |
| `I/operational_admission_test.go` (new) | 0 | 9 | 9 | 0 |
| `I/operational_handoff_test.go` | 10 | 10 | 0 | 0 |
| `A/reliable_submit_operational_admission_test.go` | 9 | 24 | 16 | 1 |
| `A/reliable_submit_operational_admission_redteam_test.go` (new) | 0 | 11 | 11 | 0 |
| `A/reliable_submit_operational_handoff_test.go` | 8 | 8 | 0 | 0 |
| `A/reliable_submit_operational_format_test.go` | 2 | 2 | 0 | 0 |
| `A/reliable_submit_guardrails_test.go` | 11 | 11 | 0 | 0 |
| `A/workstream_c_guardrails_test.go` | 47 | 48 | 1 | 0 |
| `docs_contract_test.go` | 144 | 144 | 0 | 0 |

**Removed (one).** `TestOperationalAdmissionV1Compatibility`, with its two helpers that built and advanced v1 claims. Design section 7 replaces it: the independently built v1 bytes stay as negative vectors in `TestOperationalV1Removed` and in the store's `TestOperationalHandoffV2CustodyStructure`.

**New store tests (design section 10, "Store").**

| Test | What it pins |
| --- | --- |
| `TestOperationalAdmissionLifecycle` | Commission, adopt, refuse another digest or identity; advance with a wrong generation or the same digest refused, once and idempotent; withdraw idempotent and possible from a stale token; advance after withdraw; closed custody and cancelled context. |
| `TestOperationalAdmissionSerializedWriters` | Racing commissions and advances: exactly one winner per generation. Added in `b6d2f77`: while another process holds the writer lock with an uncommitted withdrawal, a commission, an advance and a withdrawal that would each write nothing end unavailable and do not answer from the committed row. This last subtest waits for the store's busy timeout, about five seconds. |
| `TestOperationalAdmissionTriggers` | Every trigger rule by raw SQL with the exact abort message and an unchanged row, with controls that the valid first row and the two valid transitions are accepted. Includes identity and time changes inside an otherwise valid transition, and `INSERT OR REPLACE` on a connection with recursive triggers off. |
| `TestOperationalAdmissionClaimGuardsByRawSQL` | The two claim-trigger clauses with the Go comparison left out: codec-5 insert refused when uncommissioned or withdrawn; assign, intent, stamp and mark refused on a withdrawn domain and accepted on an enabled one; accept succeeds on a withdrawn domain; codecs 3 and 4 unaffected. |
| `TestOperationalAdmissionTokenAtEveryCut` | Establish, assign, intent, pre-stage, stamp and mark, each with a zero token and a token wrong in installation, epoch, generation or digest: refused, no write, revision unchanged, nothing charged. |
| `TestOperationalAdmissionChangeBetweenCommitAndRelease` | An advance or a withdrawal between a write's COMMIT and its release re-read: the write stays, nothing is released, no sender callback. Uses the new release hook. |
| `TestOperationalAdmissionEstablishTurnIsTheAuthority` | A change between the capacity hint and the establish turn is caught in the turn. |
| `TestOperationalAdmissionTableWriters` | Exactly three functions write the admission table; no statement updates installation or epoch; seven synthetic violations are each detected. |
| `TestOperationalAdmissionPublishedSchema5ShapeRefused` | A database built from the migration-5 text published at `8058561` is refused by every opener, byte for byte unchanged (plan 3.3). |

**New admission tests (design section 10, "Admission" to "Outcomes"; audit R1, R2; plan 4.7).**

| Test | What it pins |
| --- | --- |
| `TestOperationalAdmissionGenerationsOnOneDomain` | Claims seeded at revisions 1, 2 and 3; Service B advances with five kinds of content change. A (old generation) is fenced: Unavailable, nothing changes. B returns Denied for the three denials and the changed verifier, and completes with one POST for the unrelated revocation. C advances with allowing content and completes: denial is not terminal. |
| `TestOperationalAdmissionRunAssignmentCutAndEstablishGate` | RT-10 and audit R1 (a), (b): the run-assignment cut after an assign rollback under each unusable authority, and the establish gate with both samples. |
| `TestOperationalAdmissionDenialInsideEachWriter` | Audit R1 (c), (d): a denial or a passed deadline inside the intent, pre-stage, stamp and marker turns refuses the write; at the release qualifier the write stays and its result is withheld. |
| `TestOperationalAdmissionChangeAtEachProofHook` | An advance or a withdrawal injected before pre-stage, before stamp and before marker is refused at the next cut with zero POSTs; at the consume and entry hooks one sender already past its release re-read may POST (RT-4). |
| `TestOperationalAdmissionFencesAnotherProcess` | Two real processes: a child commissioned at generation 1 is held between two turns, the parent advances or withdraws, the child is refused at its next cut and stages and sends nothing. |
| `TestOperationalAdmissionFreshness` | One trust request per effect-capable invocation and none for recovery, accepted replay and stamped retries; different trust latches supersession even after EGS reverts; a failed request or a bad signature extends nothing; a never-confirmed Service admits nothing; the confirmation never overlaps a writer turn (the synthetic EGS takes `BEGIN IMMEDIATE` on the same database while it answers). Added after the first push: a confirmation that started earlier and finishes later does not move the recorded time back. |
| `TestOperationalAdmissionDeadlineAtEverySample` | A complete fresh delivery samples the view 48 times. The sweep lets the deadline pass at each sample in turn. Whichever sample sees it first, nothing is written, staged or sent after it, the outcome is Unavailable, and no run or receipt is disclosed. The sweep must have stood at every state of the claim from absent to marked. Added after the first push. |
| `TestOperationalAdmissionChangeDuringEvaluation` | The qualifier's own sample after its evaluation, called directly: a passed deadline, a withdrawal or a supersession that arrives during the evaluation makes that judgment unusable, and asking again does not undo it. Added after the first push. |
| `TestOperationalAdmissionConfirmationDeadlineArithmetic` | The limit is exclusive, both clocks are checked, negative readings and a negative skew refuse, the skew cannot lengthen the deadline. |
| `TestOperationalAdmissionOutcomeMapping` | Each cause of design 5.6 at the run-assignment and pre-stage cuts and at establish gives its reason; none discloses a run or a receipt or changes the claim. |
| `TestOperationalAdmissionViewIsBoundToTheDomainRealm` | The installation and epoch check (red-team mutant M3c, plan 4.9): a correctly commissioned and confirmed Service handed a domain of another epoch or installation stores no claim and makes no dependency read, cannot withdraw through it, and no Service can be commissioned or advanced through it. |
| `TestOperationalV1Removed` | The published v1 layouts are refused by custody and by the reader; an empty evidence record cannot be composed; no production source names the removed literal. |
| `TestOperationalAdmissionRefusalPrecedesCancellation` | AF-6. |
| `TestOperationalAdmissionResultReportsLastAttemptedWriter` | AF-7. |
| `TestOperationalAdmissionEntriesWithoutACutReturnStoredFacts` | AF-9, RT-3. |
| `TestOperationalAdmissionDenialAfterStagingKeepsResidue` | O-5, RT-5. |

`TestOperationalGuardReflectUnsafeImportInventoryIsExact` is the one new guard test function. The other guard additions are subtests of existing functions.

**Adapted existing tests.** Each changed because the model changed, not to make it pass.

| Test | Change and reason |
| --- | --- |
| `TestOperationalAdmissionCommissioning` | Rewritten against the new commissioning (audit R2): an injected policy set that differs from configuration is refused; mutating the Service's trust lists and configured entries afterwards changes neither the view's decisions nor its digest; copied, oversized and unsupported Services gain nothing; a token from one database is refused by another; a trust load that races the store write leaves the Service closed; withdrawal is durable for the whole domain. Added after the first push: a Service that holds the view of an earlier generation is refused after an advance and after a withdrawal; each check made between the store write and the installation of a view is pinned (a second commission by another caller, lost ownership of the trust model, an unverified trust model, a token for other content); a copied Service and an unverified one, each with content of its own, do not reach the store; content that differs from the stored content in exactly one field (the literal or the id of a configured entry, one more entry, the verifier key or its key id, one more allowed signer, revoked signer or revoked artifact) carries another digest, cannot join the stored generation and can advance it, with a control that equal content joins; a withdrawal the store does not perform is reported as unconfirmed, leaves the process stopped and can be repeated; an unsupported verifier algorithm, a blank verifier key id and an invalid policy configuration are refused before the store write. |
| `TestOperationalAdmissionWithdrawalCuts` | Withdrawal is now a store write and cannot run inside a writer turn. The cases moved to hooks that run between turns and to the clock seam. Same cuts, same expected state. |
| `TestOperationalAdmissionCaptureIsSameResolution` | Audit R8 (AF-11): the two assertions that could not fail are replaced by a comparison with an independently resolved plan and material. |
| `TestPR12RetainedAdmissionCuts`, `TestPR12RetryAfterPolicyChange`, `TestOperationalRetainedAdmissionEvidenceV2`, `TestOperationalRetainedAdmissionInputs` | A second authority is now a later generation, not a second view. Where the old test let two Services act side by side, the new one states which is current, expects the fence for the other, and expects Denied where the old one expected Unavailable for a policy or trust refusal. |
| `TestOperationalRetainedAdmissionEvidenceV2`, added after the first push | The encoder must refuse each of the eleven contradictions between evidence, plan and material that the test already put to the qualifier and the reader, with controls that the mismatched record decodes and that the matching original encodes to its own bytes. The older assertion on the encoder was satisfied by a record that did not decode. |
| `TestOperationalHandoffChildProcess` and its harness | The child can commission itself and be held at a hook, for the two-process test. |
| `TestOperationalHandoffIndependentBindingVectors`, `TestOperationalOriginalBindingAndCustody` | Establish takes the token; one confirmation before a direct qualifier call. The independent expected bytes are unchanged. |
| Store `TestOperationalHandoffV2CustodyStructure` | The fixture payload is v2. The two assertions that a structurally valid v1 sequence is accepted and can be frozen are inverted into refusals, with two more v1 vectors and the fixture's own scope-2 literal added; every refused vector must now also fail to freeze. Evidence at exactly the shared cap is accepted. |
| Store `TestOperationalHandoffHeldWriterExcludesPrestage` and the store fixture | Callback signature. The fixture commissions its domain at generation 1. |
| `TestOperationalHandoffNoPublicStartupOrdinaryOrFixtureCaller`, `TestOperationalHandoffOpaqueAuthorityBoundaries`, `TestExecutionSubstrateSynchronizedMutableStateReferenceInventoryIsExact`, `TestTypedObjectReferenceInventoryRejectsEscapes` | Inventories updated for the new code and for the guard fix; new synthetic cases for each new guard rule (about 100 cases, each a source snippet that must be classified or rejected). |
| `docs_contract_test.go` (four functions) | Phrase pins follow the documents. The v1 attribution rule is replaced by a v1 removal rule. |

### 11.6 The red team's test file (draft PR #15)

The file `A/reliable_submit_operational_admission_redteam_test.go` is PR #15's file at `5ca4079` (SHA-256 `10e705ab457455c1dcf8405b208b5b1ffed339ed27aede7f3b86779b48ccca52`), adapted. All 11 test and fuzz names are kept. The complete line-by-line difference is the attached file `05-repair-redteam-test-changes.diff` (16 hunks, 150 lines added, 23 removed). I did not push to PR #15's branch. GitHub shows PR #15 closed without merging at 2026-11-22 07:11Z, with its branch still at `5ca4079`, so the original file stays available for comparison. The project memory records it as closed because this repair supersedes it. This thread did not close it.

Unchanged, byte for byte: `TestRedTeamPR13GuardAccessInventoryEscapes` (the RT-1 regression, which fails at `e544e0f` and passes now), both fuzz targets, `TestRedTeamPR13HoldsSealedOriginalTamperRefused`, and every helper except those named below.

Every change, by test:

| Test | Change | Why | Stronger or weaker |
| --- | --- | --- | --- |
| (file comment) | Five lines added. | Says the file is adapted. | Neutral |
| Denial matrix, "commissioned then withdrawn" | Withdrawal takes the context and the domain. | New signature. | Same |
| Denial matrix, "another epoch" and "another installation" | The precondition is inverted. Before: commissioning a Service for another realm succeeded, and the test attacked with that view. Now: the store must refuse that commissioning, and the test asserts the refusal. The Service continues without a view. | The store commissions only the realm its admission row names. | The assertion that such an authority gains nothing is unchanged. On its own this arm would now repeat "never commissioned", so three arms are added, next row. |
| Denial matrix, three added arms | "view rewritten to name another epoch", "view rewritten to name another installation": a commissioned and confirmed view with this domain's content and current token whose realm fields the test then rewrites in memory. "commissioned and confirmed on another database": a real view for another installation. | They keep the red team's original attacker (a current view that names another realm) under the new model. | Stronger: three more attackers through all six crash points and both entries |
| Denial matrix, final retry | The allowing retry is a restarted Service with the original content at the next generation, not the fixture's own Service. | The changed authorities advanced the domain, so the fixture's Service is fenced by design. | Same assertions (accepted, one POST, revision 6, or no further dispatch for a stamped or marked claim) |
| No new claim after withdrawal | Withdrawal signature only. | | Same |
| Cross-realm isolation, "matching authority" | Precondition inverted as above: the store must refuse to commission for the changed realm. A fourth Service is added, "view rewritten to the changed realm", with a control that this view is current for the changed realm before it is used. | As above. | The loop's assertions are unchanged. Stronger by one attacker |
| Submit-key reuse and caller substitution | The denying and the allowing Service are each commissioned when their turn comes, in a fixed order. A control is added: the allowing Service then completes the retained delivery. | Two contents cannot be current together; a fenced "allowing" Service would prove nothing. | Stronger: one control added |
| Concurrent denying authority | 28 iterations instead of 14. In the first 14 the allowing Service is current and the denying one is fenced; in the last 14 the order is reversed. The delay expression becomes `(iteration/7%2)*150` so both halves see the same two delays as before. For the last 14 an assertion is added: no POST, no writer by the fenced Service, and the denying Service reports Denied. | Only one content is current on a domain. | The original assertions run on all 28. Note for the auditor: in the first 14 the denying Service is refused by the fence and not by its own judgment; the last 14 exist so that its judgment is exercised under the race. |
| Planted stage name on retry | Each Service commissioned in turn. A control is added on the reason: Denied for the denying arm, Occupied for the allowing arm. | As above. | Stronger |
| Changed evidence never qualifies | One confirmation before the control call, one before each table case and one every 250 random mutations, each with a control that the unchanged record still qualifies. | A view admits nothing before its confirmation, and a confirmation lasts 30 seconds; without the controls a refusal could be an expired view's. | Stronger: the refusals are now distinguishable from an expired view |

Weakened assertions: none that I can find. The two inverted preconditions are the places to look first.

### 11.7 Validation

**How every run was made.** There is no CI on this branch (PR #14 is not merged). Every run below used a copy of the working tree without `.git`, owned by a separate unprivileged account, on Linux amd64 with Go 1.26.5 and no network. One test file of the store package does not compile on Linux at the base (`I/replay_custody_file_test.go`, a `uint16` and `uint32` mismatch in `unix.Stat_t.Mode`). To run the store tests at all, a three-line fix of that test file was applied to each copy and never committed (patch SHA-256 `1173ed062000267f4365ff40b0a7530da9e08d9e7a7a9a922992869143e19ad4`). It is not in scope for this PR. So the store package's results are for the committed bytes plus that one test-file patch.

**Bytes.** Every row is a run on the tree of the final tip `b6d2f7787ec8254134cb48fcae0da72bac0fd02c`, made after that commit was pushed. The one exception is the baseline row, which is the tip the audit blocked.

| Check | Command | Result |
| --- | --- | --- |
| Format | `gofmt -l` on the 19 Go files changed against the base | Clean |
| Whitespace | `git diff --check 8058561 HEAD` | Clean |
| Build | `go build ./...` | Exit 0 |
| Vet | `go vet ./es/admission/ ./es/admission/internal/reliablesubmit/` | One finding, `es/admission/result_auth_test.go:395:15` (an assignment copies a lock value). The file is not touched by this PR, and the same single finding is reported on a copy of `e544e0f`. |
| Full suite | `go test -count=1 -timeout 90m -json ./...`, with nothing else running on the machine | 6,204 results: 5,997 pass, 166 fail, 41 skip. 41 packages: 19 pass, 2 fail, 20 have no tests. Admission package: 1,810 pass, 0 fail, 1 skip. Store package: 727 pass, 3 fail, 2 skip. The 166 failures are 16 top-level tests and their subtests, all listed below as environment failures. |
| Same, on the tip the audit blocked | Same command on a copy of `e544e0f` | 5,699 results: 5,477 pass, 181 fail, 41 skip. 41 packages: 18 pass, 3 fail, 20 have no tests. |
| Race detector, store | `go test -race -count=1 -timeout 120m -json ./es/admission/internal/reliablesubmit/` | 727 pass, 3 fail, 2 skip, the same counts as without the detector. The 3 failures are the three environment failures of the store package listed below. No data race was reported. |
| Race detector, admission | `go test -race -count=1 -timeout 180m -json ./es/admission/` | 1,810 pass, 0 fail, 1 skip, the same counts as without the detector. No data race was reported. |
| Fuzz targets | Seed corpus only, as part of the full suite | Pass. No fuzzing time was spent. |

Counts are of results by package and test name, subtests included.

**Comparison with the blocked tip, by test name (stop condition 7).** 5,686 names are in both runs. 5,671 of them have the same result. No name went from pass to fail.

15 names differ, all from fail to pass, and I attribute none of them to this repair. 14 are `TestLinuxSetupGoToolchainInstallerHermeticPreflightAndCleanup` in `es/app` and its 13 subtests. One is the root-package subtest `TestRemoteAlphaESServiceTLSStatusFailureWitnessBootstrapOwnedTerminal/artifact-registry/fixture_read_fault`. Both test operator shell scripts and sit in files this PR does not touch. Run alone, the `es/app` test passes on the copy of `e544e0f` as well as on the repair, and the root subtest gave different results in two runs of the identical baseline bytes. Inference: both depend on machine load or timing. The baseline run shared the machine with other runs; the final run did not.

13 baseline names are absent from the final run:

- Five are `TestOperationalAdmissionV1Compatibility` and its four subtests, removed with v1 (11.5).
- Six are subtests of `TestOperationalAdmissionCommissioning` that now run one level deeper under `copied,_oversized_and_unsupported_Services_gain_nothing`, with their case names unchanged: `no_trust`, `unverified_trust`, `no_verifier`, `unsupported_evaluator`, `nested_evaluator` and `mismatched_built-in`. Each passes there.
- Two are document-mutant cases of `TestOperationalSubmitHandoffCurrentAdmissionV2RejectsUnsafeMutants` in `docs_contract_test.go`: `LegacyFirstEffect` and `FalseStorageEmptyV1Attribution`. They altered sentences about v1 that the documents no longer contain. Four cases about the removal replace them: `V1Retained`, `CustodyAcceptsV1`, `ReaderAcceptsV1` and `EncoderFallsBack`.

518 names are new: 437 in the admission package, 57 in the store package and 24 in the root package's document tests. All 518 pass.

**Environment failures.** These 16 top-level tests fail at `e544e0f` too, and none is in a file this PR touches.

- Root package, 13 tests: 12 `TestRemoteAlpha...` tests of the operator scripts, and `TestTrackedGeneratedArtifactHygiene`, which runs `git ls-files` and so needs the `.git` directory that the copies leave out.
- Store package, 3 tests that require a probe built from an older source tree, which this environment does not supply: `TestOperationalHandoffSchema4BinaryRefusesSchema5`, `TestSQLiteV3OldBinaryRefusesWithoutMutation`, `TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation`.

Inference: I call these environment failures because they fail on the unchanged tip `e544e0f` as well, and the messages I read point at this container (a macOS path under `/private/tmp`, a directory under `/var/tmp` the test account cannot create, `sudo`, a missing `.git`, a missing older binary). I did not diagnose each one and did not make any of them pass.

**A correction to my own baseline.** My first baseline run was made from a `git archive` extraction, which writes files as mode 0664. Nine results in three root-package tests that check file modes failed there for that reason only. I rebuilt the baseline copy with the checkout's modes (0644) and ran the whole suite again. The baseline numbers above are from the second run. The first run is not used.

### 11.8 Mutants

A mutant is one small change to production code, or to a guard, that removes or weakens one check. It is killed when a test fails because of it. The final pass ran 173 mutants, each against the tree of the final tip `b6d2f7787ec8254134cb48fcae0da72bac0fd02c`. Verdicts were read per mutant, with the failing leaf tests listed, and a kill by a source inventory alone is counted separately from a kill by behaviour.

| Group | Mutants | Killed by behaviour | Killed by the guard under test | Survived |
| --- | --- | --- | --- | --- |
| Store operations and cuts (`I/operational_admission.go`, `I/operational_handoff.go`, custody grammar) | 23 | 22 | 0 | 1 |
| Store schema text (triggers and claim-trigger clauses) | 17 | 17 | 0 | 0 |
| Admission (`A/` production code) | 90 | 85 | 0 | 5 |
| Guard classifier and inventories (mutating the guard itself) | 32 | n/a | 32 | 0 |
| Production escapes the guard must reject (mutating production code) | 11 | n/a | 11 | 0 |

The specifications, the runner scripts and the complete output of the final pass are in the attached archive (11.14), so the audit can read each verdict and run any mutant again.

**The schema pin, stated plainly.** The store refuses to open a database whose schema text does not hash to a pinned digest. So any change to the schema text makes every store test fail at open. That is a kill by the pin and says nothing about behaviour. For the 17 schema mutants I therefore recomputed the digest of the mutated schema and wrote it into the pin before running the tests. With the pin out of the way, all 17 are killed by raw-SQL tests that observe a row that should not have changed, or an abort that should have happened.

**Named mutants the plan required (section 8).** All are killed in the final pass. The last three change or attack the guard, so the tests that kill them are the guard's own.

| Mutant | What it removes | Killed by |
| --- | --- | --- |
| `S1-assign-cut-skips-admission` | The run-assignment cut skips the admission judgment (audit AF-1) | `TestOperationalAdmissionDeadlineAtEverySample` and 16 more |
| `S2a-establish-first-sample-removed` | Establish: the first sample of the view | `TestOperationalAdmissionRunAssignmentCutAndEstablishGate/establish_gate/never_commissioned` and 3 more |
| `S2b-establish-second-sample-unchecked` | Establish: the second sample is replaced by an unchecked read of the view | `TestOperationalAdmissionDeadlineAtEverySample` and 1 more |
| `C8-establish-both-samples-removed` | Establish: both samples | `TestOperationalAdmissionDeadlineAtEverySample` and 7 more |
| `S3a-PAssign-assign-writer-unguarded` | PAssign: the assign writer is given a callback that matches without judging (red-team RT-10) | `TestOperationalAdmissionDeadlineAtEverySample` and 4 more |
| `S3b-intent-writer-unguarded` | The intent writer is given the same callback | `TestOperationalAdmissionDeadlineAtEverySample` and 3 more |
| `S4-policy-entry-equality-ignored` | Configured policy entries are not compared with configuration | `TestOperationalAdmissionCommissioning/copied,_oversized_and_unsupported_Services_gain_nothing/injected_entries_differ_from_configuration` |
| `S5a-trust-shallow-copy` | The view shares the Service's trust lists | `TestOperationalAdmissionCommissioning/the_view_enforces_normalized_lists` and 1 more |
| `S5b-verifier-key-shallow-copy` | The view shares the verifier key | `TestOperationalAdmissionCommissioning/view_is_a_private_copy_bound_to_owner,_installation_and_epoch` |
| `S5c-policy-entries-shallow-copy` | The view shares the configured entries | `TestOperationalAdmissionCommissioning/configured_entries_are_private_copies` |
| `S6a-M3b-installation-comparison-removed` | The installation comparison of the view (audit S6a, red-team M3b) | `TestOperationalAdmissionCommissioning/view_is_a_private_copy_bound_to_owner,_installation_and_epoch` and 1 more |
| `S10-encoder-accepts-empty-record` | The encoder accepts an empty evidence record | `TestOperationalV1Removed/an_empty_evidence_record_cannot_be_composed` |
| `M3c-installation-comparison-disabled` | The same installation comparison, disabled in the red team's form (M3c) | `TestOperationalAdmissionCommissioning/view_is_a_private_copy_bound_to_owner,_installation_and_epoch` and 1 more |
| `M3c-epoch-comparison-disabled` | The epoch comparison, disabled in the red team's form (M3c) | `TestOperationalAdmissionCommissioning/view_is_a_private_copy_bound_to_owner,_installation_and_epoch` and 1 more |
| `S7a-classifier-typeassert-step-removed` | The guard's type-assertion step (audit R3) | Guard: `TestExecutionSubstrateSynchronizedMutableStateReferenceInventoryIsExact/protected_admission_field_access_kinds/write,_address_and_write-through_field_access/type_assertion_chain_assignment` and 1 more |
| `S7b-classifier-unclassified-as-read` | The guard classifies an unknown access as a read (audit R3) | Guard: `TestExecutionSubstrateSynchronizedMutableStateReferenceInventoryIsExact/protected_admission_field_access_kinds/unresolved_selection_is_unclassified` |
| `E1-redteam-anonymous-struct-conversion` | The red team's end-to-end mutant: production code rewrites the view through a conversion to an anonymous struct (RT-1) | Guard: `TestExecutionSubstrateSynchronizedMutableStateReferenceInventoryIsExact` and 1 more |

**The audit's script.** All 35 were read and ported to the new code. 33 still have a target. Where one audit mutant removed several checks at once, it was split so that each check has its own mutant, which makes 42 mutants here. All 42 are killed in the final pass: `S7a` and `S7b` by the guard under test, the other 40 by behaviour. Two have no target any more, `S12` and `S19`: both changed v1 branches that this repair deletes.

**Gaps found by reading the results, and what was done.** The first complete pass ran on the first checkpoint's tests. Reading it found seven places where no test observed a check. Each got a behavioural test in a later checkpoint, with no change to production code, and each mutant is killed in the final pass.

1. **The encoder's evidence check.** The older assertion on the encoder was satisfied by a record that did not decode, so removing the check that evidence matches the plan and the material went unseen. Added in `1826cef`: `TestOperationalRetainedAdmissionEvidenceV2` now puts eleven validly signed, mismatched records to the encoder. Final pass: `S10b-encoder-skips-evidence-binding` by `TestOperationalRetainedAdmissionEvidenceV2/artifact_digest` and 8 more.
2. **The last freshness sample of a qualification.** The qualifier and the callback each sample the view once more after the evaluation. Removing either one alone was caught by nothing, because the other one, or a later one, refused first in every existing test. Added in `1826cef`: `TestOperationalAdmissionChangeDuringEvaluation` calls the qualifier directly, and `TestOperationalAdmissionDeadlineAtEverySample` lets the deadline pass at each of the 48 samples of a delivery. Final pass: `S16-qualifier-final-resample-removed` by `TestOperationalAdmissionChangeDuringEvaluation/EGS_serves_other_trust` and 2 more; `S16b-callback-final-resample-removed` by `TestOperationalAdmissionDeadlineAtEverySample/sample_10_of_48` and 4 more.
3. **The ownership and verification checks before the store write.** The candidates in the tests held the stored content. A store write by them changed nothing, so a check made only after the write looked the same as one made before it. Added in `1826cef`: Candidates with content of their own: a copied Service and an unverified one must leave the row unchanged. Final pass: `S20-content-owner-check-removed` by `TestOperationalAdmissionCommissioning/copied,_oversized_and_unsupported_Services_gain_nothing`; `S20c-content-verified-check-removed` by `TestOperationalAdmissionCommissioning/copied,_oversized_and_unsupported_Services_gain_nothing/unverified_trust_with_content_of_its_own`.
4. **The checks between the store write and the installation of a view.** Nothing changed the Service from inside the store write. Added in `ca902a6`: Four cases under `what changes during the store write is seen before a view is installed`: a second commission by another caller, lost ownership, an unverified trust model, a token for other content. Final pass: `S20b-install-owner-recheck-removed` by `TestOperationalAdmissionCommissioning/what_changes_during_the_store_write_is_seen_before_a_view_is_installed/the_Service_no_longer_owns_its_trust_model`; `I1-install-token-not-checked` by `TestOperationalAdmissionCommissioning/what_changes_during_the_store_write_is_seen_before_a_view_is_installed/the_store_returns_a_token_for_other_content`; `I3-install-second-stop-check-removed` by `TestOperationalAdmissionCommissioning/what_changes_during_the_store_write_is_seen_before_a_view_is_installed/the_same_Service_is_commissioned_by_another_caller`.
5. **The configured literal in the admission digest.** The only configured-policy change in the tests added a whole policy, so the literal was never the one thing that distinguished two contents. A process whose content differs only in a denied literal could have joined a generation without fencing anyone. Added in `af23316`: `content that differs in one field is other content`, nine fields. Two more digest mutants written with it (`D4`, entry id; `D5`, verifier key id) are killed by it too. Final pass: `D1-digest-ignores-policy-literal` by `TestOperationalAdmissionCommissioning/content_that_differs_in_one_field_is_other_content/the_literal_of_a_configured_entry` and 1 more.
6. **The confirmation time never moves back.** No test let two confirmations overlap. Added in `af23316`: `a confirmation that started earlier and finishes later does not move the time back` holds the first request at the synthetic EGS while a second completes. Final pass: `F5-confirmation-time-moves-backwards` by `TestOperationalAdmissionFreshness/a_confirmation_that_started_earlier_and_finishes_later_does_not_move_the_time_back`.
7. **A withdrawal the store did not perform is reported as unconfirmed.** Every withdrawal in the tests succeeded. Added in `af23316`: `a withdrawal the store does not confirm is reported as unconfirmed`: under an ended context the call returns false, the row is unchanged, the process stays stopped, and a repeat succeeds. Final pass: `W4-withdraw-reports-unconfirmed-success` by `TestOperationalAdmissionCommissioning/a_withdrawal_the_store_does_not_confirm_is_reported_as_unconfirmed`.

Two mutant definitions of the first pass did not compile (`F1c`, `I4`). Both were corrected and are killed.

**Thin kills found by reading, and strengthened.** Three trigger mutants were first killed only because the abort message changed, while another rule still refused the statement. `TestOperationalAdmissionTriggers` now changes installation or epoch inside an otherwise valid advance and withdrawal, moves the time back inside a valid advance, and uses `INSERT OR REPLACE` on a connection with recursive triggers off. Under each of these mutants the row now really changes.

**A kill that depended on scheduling, found in the last reading.** A complete pass of all 173 mutants also ran on the previous tip, `af23316`. It ended with the same 6 survivors. Reading it against the first pass showed one mutant whose failing tests were not the same in two runs of the same test: `GO-write-no-lock`, which replaces the writer lock of commission, advance and withdrawal (`BEGIN IMMEDIATE`) by a deferred transaction. Its only killer was `TestOperationalAdmissionSerializedWriters`, which races six writers and needs the scheduler to overlap two of them. I ran that test 40 times under the mutant with nothing else running: it failed 37 times and passed 3 times. So the writer lock was pinned on most runs, not on every run. The fifth checkpoint `b6d2f77` adds the subtest `NoWriteOutcomeWaitsForTheWriterTurn`, which does not depend on timing (11.5). Under the mutant it failed 25 times out of 25, and in the final pass it is one of the tests that fail under the mutant.

Every other mutant has the same verdict in the pass on `af23316` and in the final pass, and the same failing tests, except that 5 other store mutants now fail the new subtest as well, because it also checks what each call answers once the writer has settled, and except `S8c`. That mutant had 9 failing tests in the pass on `af23316` and has 8 in the final pass, on identical admission bytes. I ran it five more times with nothing else running: the same 8 tests failed every time, and the ninth, `TestRedTeamPR13HoldsConcurrentDenyingAuthorityNeverWrites`, failed in 1 run of 5. That test is the red team's stress test, which races writers on purpose. It is the only killer of no mutant in either pass, so no verdict rests on it. Inference: no other kill depends on scheduling. The other tests that start a second goroutine hold it at a channel or a hook, so their order is fixed; I checked that by reading them, and two equal passes support it but do not prove it.

**Mutants that survive, and the adjacent check.** 6 mutants survive the final pass, one in the store and five in admission. Each disables one of two checks that refuse the same fault. For each I ran the neighbour and the pair, so the claim is shown and not assumed.

| Survivor | Why no test can see it | The neighbour alone | Both together |
| --- | --- | --- | --- |
| `GO-advance-where` (store): the `generation=?` predicate of the advance statement is dropped | The same transaction has just compared the generation in Go, and the update trigger requires generation plus one. | `GO-advance-generation` (the Go comparison) is killed by `TestOperationalAdmissionLifecycle/Advance` and 2 more; `TR-advance-skip` (the trigger rule) by `TestOperationalAdmissionTriggers/EnabledRow` | `GO-advance-generation+where` is killed by `TestOperationalAdmissionLifecycle/Advance` and 2 more |
| `T1b-callback-returns-stored-token`: the callback answers with the stored token instead of its view's, so the store's comparison of the returned token always succeeds | The callback has already refused when the two differ. | `T1a` (the callback's comparison) is killed by `TestOperationalAdmissionChangeAtEachProofHook/another_Service_advances/after_stage_create` and 36 more | `T1a+b` is killed by `TestOperationalAdmissionChangeAtEachProofHook/another_Service_advances/after_stage_create` and 37 more |
| `F2b-never-confirmed-accepted`: the explicit never-confirmed check is dropped | A zero confirmation time is further back than the limit, so the deadline check refuses. | `F2a` (the deadline check) is killed by `TestOperationalAdmissionChangeAtEachProofHook/the_confirmation_deadline_passes/after_marker_before_sender` and 79 more | `F2ab` is killed by `TestOperationalAdmissionChangeAtEachProofHook/the_confirmation_deadline_passes/after_marker_before_sender` and 82 more |
| `F2g-limit-inclusive`: exactly 30 seconds counts as fresh | At exactly the limit the added-time clause (`skew >= limit - elapsed`, here zero against zero) refuses. | `F2h` (that clause) is killed by `TestOperationalAdmissionChangeAtEachProofHook/the_confirmation_deadline_passes/after_marker_before_sender` and 73 more | `F2gh` is killed by `TestOperationalAdmissionChangeAtEachProofHook/the_confirmation_deadline_passes/after_marker_before_sender` and 76 more |
| `C5` and `C5b`: the trust model's validity is not checked in the content copy, or the canonical encoding's error is ignored in the digest | Each catches an invalid trust model that the other lets through. | Each is the other's neighbour; both survive alone | `C5ab` is killed by `TestOperationalAdmissionCommissioning/copied,_oversized_and_unsupported_Services_gain_nothing/invalid_trust` |

I kept all of these layers (11.4 item 11). None is a missing test: with the neighbouring check in place there is no input on which the mutant behaves differently, as far as I can construct one.

**What the mutant runs do not show.** They show that each listed check is observed by a test. They do not show that the list of checks is complete. The list grew twice from reading results: the per-check mutants for commissioning, and the digest and content mutants written for `af23316`. A single pass also does not show that a kill is reliable: the one that was not was found only by comparing passes. Inference: an auditor who writes mutants independently may still find a check that nothing observes.

### 11.9 Failed or skipped validation

- **No CI.** PR #14 is not merged, so no workflow ran on this branch.
- **Linux only.** Nothing was run on macOS. `A/execution_roots_darwin.go` and the other darwin files are untouched, but the new tests were never run there. Inference: the new code has no platform-specific part.
- **One uncommitted test-file patch**, described in 11.7.
- **16 tests fail for reasons of this environment**, listed in 11.7. They fail at `e544e0f` too. With their subtests they are the 166 failing results of the full suite.
- **Two tests changed result between the baseline run and the final run without a change of mine**, described in 11.7. I did not find the cause beyond showing that one passes alone on both copies and the other flips on identical bytes.
- **Three skipped tests in the two packages this PR changes**, all helpers that skip by design unless started as a child process: `TestOperationalHandoffChildProcess` in admission, and `TestPrivateReplayObjectAllocatorHelperProcess` and `TestSQLiteClaimStoreLockHelperProcess` in the store. The other 38 skips are in `es/app` and are the same at the base.
- **No fuzzing time.** The two fuzz targets ran their seed corpus only.
- **No real EGS, no real agent, no installed service.** Every trust request in these tests goes to a synthetic EGS inside the test. Nothing touched the Linux box, the Mac or any live service.
- **No kept schema-5 database was looked for.** The plan (3.3) proceeds on the design's assumption that none exists, and the coordinator confirmed that at the checkpoint. A database of the old shape is refused on open and left unchanged; `TestOperationalAdmissionPublishedSchema5ShapeRefused` pins that.
- **Mutants were run in parallel streams.** The final pass ran as three parallel streams, with the race detector as a fourth stream for its first part, on four processors. A loaded machine could make a test fail for a reason other than the mutant. Three things speak against that here. Each stream's baseline run under the same load had no failing test, apart from the one store test that fails in this environment at every tip. The 6 runs that ended as survivors had no failing test either. And every mutant has the verdict it had in the complete pass on the previous tip `af23316`, with the same failing tests apart from the subtest the last commit adds and one stress test that fails on some runs only (11.8). No mutant ended as a build failure, a missing anchor or an error.

### 11.10 Dependencies, hygiene, widening, cross-repo impact

**Dependencies changed.** None. `go.mod` and `go.sum` are untouched. No new import outside the standard library and the repository. The test file `A/reliable_submit_operational_admission_test.go` now also imports `unsafe` (for the one fixture named in 11.4 item 15) and `sync`. Production code imports neither `unsafe` nor `reflect` beyond the one darwin file that already did, and the new import inventory pins that.

**Artifact hygiene.** 26 text files, all Go or Markdown. No binary, database, key, certificate, environment file or generated artifact is added. No secret appears in code, tests, documents or this report. Test keys are generated at run time.

**Authority, security or protocol widening.**

- *New durable state.* One table with at most one row in the reliable-submit store, inside the amended migration 5. Schema 5 was published only on PR #12's branch and has never been merged or installed. An existing schema-5 database of the old shape is refused, not migrated.
- *New store API.* Three write operations and one read (`AdmissionHint`), plus a proof hook. The three writes have exactly one production reference each, from Service methods that have none. So no production path can commission, advance or withdraw. This is the edge that remains, and the guard fails with the five prerequisite identifiers when a production caller appears.
- *New outbound request.* One signed trust-model fetch to EGS per effect-capable private handoff. The private handoff has no production caller, so no installed process makes this request today.
- *New outcome.* `OperationalDenied` is appended to the reason list. It is value-free and discloses no run and no receipt. Existing reason numbers are unchanged.
- *Removed.* The v1 custody variant and every branch that accepted it.
- *Not widened.* No public API, no wire format of an existing endpoint, no configuration key, no file permission, no change to ordinary Submit.

**Cross-repo impact.** Not inspected: the Coordinator, the Infrastructure Manager, the Maintenance Agent and Bridge-Core were not opened for this repair. Inference: none, because the changed code is the admission package and an `internal` package of this module, and nothing here is wired into a running service.

### 11.11 Provenance

| Item | Value |
| --- | --- |
| Recipe | `governed-execution.audit-patch-manifest.v2` |
| Recipe source SHA-256 | `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked before every run. The recipe file was not edited. |
| Base-relative manifest | SHA-256 `8659b099098575e19b9bbcade2a9f63d513a0a389b732294a22a313c64dd3d74`, 26 files. Head `8058561edc08356c46680c204586b3c7796c0ff3`, upstream pinned to `origin/codex/reliable-submit-operational-handoff-v1`. |
| Base-relative textual diff | SHA-256 `7ee14eec903e1a50638b4cc0c998e60dbd3684b8e3e2d361efc0e7382de6a883` |
| Repair-only manifest, against the blocked tip | SHA-256 `2b6c6ee326b702b911066aa9573eb67b2ed7d69ce69e01fb12d964dcbd96ef63`, 25 files. Head `e544e0fbe4220dfdd2c2068e3267dcfa454a0cf9`, upstream `origin/claude/project-thread-sqldt7`. |
| Repair-only textual diff | SHA-256 `aae9785ac15b5281a9f7328d1cfc8541094d0dc51004330e5b0e4d86e4ababe0` |
| Taken twice | Each manifest was written twice into a fresh mode-0700 directory outside the repository, and the two files are byte-identical. The base-relative manifest was taken before the last commit and again after the push, and those files are byte-identical too. |
| Staged-set check | With the index reset to the base, `git add -A` staged exactly the 26 paths of the base-relative manifest. With the index reset to `e544e0f`, it staged exactly the 25 paths of the repair-only manifest. Before the last commit, the staged set was the one path of that checkpoint's incremental manifest. |
| Clean status | `git status --porcelain` was empty after the commit and again after the manifests were taken. The local branch equals `origin/claude/project-thread-sqldt7` at `b6d2f7787ec8254134cb48fcae0da72bac0fd02c`. |
| Push | Fast-forward `af23316..b6d2f77`, no force. The five commits of this repair were each pushed as a fast-forward. |

How the manifests were taken (operating protocol 5.5): record the tip, `git reset --mixed` to the base, pin the upstream, run the recipe twice, `git reset --mixed` back to the tip. The working tree is never changed by this.

The base-relative textual-diff hash is the same at all five checkpoints. That is expected and is not a stale value: the recipe hashes the diff of files that exist at the base, and the three test files changed after the first checkpoint are new relative to the base, so their changes enter the manifest through the files' own content hashes. The repair-only textual-diff hash is the same as at `af23316` for the same reason: the one file the last commit changes does not exist at `e544e0f`.

Checkpoints of this repair, each with its base-relative manifest:

| Commit | What | Base-relative manifest SHA-256 |
| --- | --- | --- |
| `1fa8d72` | The repair, 25 paths | `53122fb661bdaf47d8e8f3bbcce075f338fbd9796ea2df5fbf860c5db34a110e` |
| `ca902a6` | Tests only, 3 files | `b301370bc9fec398e544b95fbc629aad64770ca6c8f6b87f2c3d06fe89cd2024` |
| `1826cef` | Tests only, 1 file | `100537a0f4c13368299e689c2467174d820d0b67141310fbf5be43f4021c6e88` |
| `af23316` | Tests only, 1 file | `66131bec0502ba6000345fed53182064098f59d539c6d82ae9a0c3435cab43f0` |
| `b6d2f77` | Tests only, 1 file. Audit this one. | `8659b099098575e19b9bbcade2a9f63d513a0a389b732294a22a313c64dd3d74` |

Complete canonical manifest, base-relative. The block is the file's exact content (one line and a final newline, 5,883 bytes):

```json
{"branch":"claude/project-thread-sqldt7","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/es_execution_admission_model.md","sha256":"f61fb5b2080a48daa689f1baa92b2f83b2b8d800e26f60700e06975fc1bc35a7","size":100770},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/implementation.md","sha256":"8f42f45a320438de12ebfa9287f2b460d91013036982bc70c305c53188354b98","size":91498},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_operational_handoff.md","sha256":"93ff80aab819c51da5dda7e55e92dd4fb42330641e90b88816ddc54d22b79326","size":100230},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md","sha256":"e7ed12b1c6333c884538582044ad82fa59e3c3e902088dbf0b17d8ba7130659e","size":166615},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md","sha256":"17d6ea3808063559ec9ae63d0c764d6db4c7a9d3bb0f2fe401d1f698daaff208","size":105872},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/system_overview/boundaries.md","sha256":"13ae36c014ffe3407f75a52a464d3988ed4880d00ea9e3a69e4da9626aeb97a8","size":73385},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"0a3d491693475ec621a20a4b28f8c5998a2cdd64325b2fb86ca185625f96e7c4","size":315131},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"1f6d69b3a54c1ec7edbb0b7a93af5e44afb1bb01502ae2c112fdb8b4dc73a394","size":835005},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/operational_admission.go","sha256":"b82b263d39d45ffc98b3b243730d0125aacefc1eb554ad0168025ab2b7852e5d","size":13063},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/operational_admission_test.go","sha256":"56f319624632308f6c36b15cffc694b709a39c7b8f44ae529a341bddd8332924","size":60470},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/operational_handoff.go","sha256":"0785eee34faeb5c54f9ea577b9829df4ad0e58e48f5fa9baa82c4da4e2ba54a1","size":63202},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/operational_handoff_test.go","sha256":"225286ffc84e37bb55f4ab5a4fb9581bb565779533cb248c7512760b20a90b3b","size":54479},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_structure.go","sha256":"4adcd21ae2396edddd4c552c9fdd5c53b5d61ab56c718573b0985089e5f16ed7","size":19440},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_operational_handoff_schema.go","sha256":"0414016c73ee268a4a14de340cf57fab132ac7d27737a3df8a606cfe8480e74f","size":38102},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_shape.go","sha256":"710668283d3d8075a43c445bda729f35798fa30ccaf88c6aabaffb5a8afb85e7","size":2878},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_guardrails_test.go","sha256":"584cfd2f96d13fb65e16423e4c3e4fb8a493bfad9c303b5fe7fd4c4f7b889269","size":81870},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/reliable_submit_operational_admission.go","sha256":"4d7bc8c97733edc4b3d549deaa5c2f05121d130bd94fb56de06081cabfdadcd1","size":20473},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/reliable_submit_operational_admission_redteam_test.go","sha256":"c4efbbdc29f653a9829a36fc2df63258feda7823717c7b75956d45a82da37ed9","size":40997},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/reliable_submit_operational_admission_test.go","sha256":"8bd4ff8d965cb49927804194c88bb4aae60192e0148cae9d26e2b825c40826ae","size":142934},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_format.go","sha256":"7a0a2128c9412917a400a05eeae6d3650417584042b87e25f333ec108aa1d2dd","size":10157},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_format_test.go","sha256":"2813c540ca0639fbe873cfbb83f6626fd2307def62c737f149d959d5ae5aa8c7","size":31600},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_handoff.go","sha256":"9cab7611a03ca0ab9eb41109a54db6d89709b998a71477cb96099ce2a1a9d510","size":26270},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_handoff_test.go","sha256":"30bfa1a2090285e74a4e20639b6d5a581d0363e41966e5a8d61b3d8b8b06103d","size":61862},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/resolved_execution_plan.go","sha256":"449dedaaf284bb3798f897b93c42ef282dcebe2c553e7318ffaf7a72e75c7ef0","size":28834},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/service.go","sha256":"317be6476f82f7214ed1d00282acd6779271ddd2d6f20922783800bbc3ef64a7","size":36030},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/workstream_c_guardrails_test.go","sha256":"eadf4510636b44ade78297d332613bec4499cfd21a92d265dfac21af3c351769","size":365824}],"head":"8058561edc08356c46680c204586b3c7796c0ff3","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"7ee14eec903e1a50638b4cc0c998e60dbd3684b8e3e2d361efc0e7382de6a883","upstream":"origin/codex/reliable-submit-operational-handoff-v1"}
```

Complete canonical manifest, repair-only against `e544e0f` (5,679 bytes):

```json
{"branch":"claude/project-thread-sqldt7","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/es_execution_admission_model.md","sha256":"f61fb5b2080a48daa689f1baa92b2f83b2b8d800e26f60700e06975fc1bc35a7","size":100770},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/implementation.md","sha256":"8f42f45a320438de12ebfa9287f2b460d91013036982bc70c305c53188354b98","size":91498},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_operational_handoff.md","sha256":"93ff80aab819c51da5dda7e55e92dd4fb42330641e90b88816ddc54d22b79326","size":100230},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md","sha256":"e7ed12b1c6333c884538582044ad82fa59e3c3e902088dbf0b17d8ba7130659e","size":166615},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md","sha256":"17d6ea3808063559ec9ae63d0c764d6db4c7a9d3bb0f2fe401d1f698daaff208","size":105872},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/system_overview/boundaries.md","sha256":"13ae36c014ffe3407f75a52a464d3988ed4880d00ea9e3a69e4da9626aeb97a8","size":73385},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"0a3d491693475ec621a20a4b28f8c5998a2cdd64325b2fb86ca185625f96e7c4","size":315131},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"1f6d69b3a54c1ec7edbb0b7a93af5e44afb1bb01502ae2c112fdb8b4dc73a394","size":835005},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/operational_admission.go","sha256":"b82b263d39d45ffc98b3b243730d0125aacefc1eb554ad0168025ab2b7852e5d","size":13063},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/operational_admission_test.go","sha256":"56f319624632308f6c36b15cffc694b709a39c7b8f44ae529a341bddd8332924","size":60470},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/operational_handoff.go","sha256":"0785eee34faeb5c54f9ea577b9829df4ad0e58e48f5fa9baa82c4da4e2ba54a1","size":63202},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/operational_handoff_test.go","sha256":"225286ffc84e37bb55f4ab5a4fb9581bb565779533cb248c7512760b20a90b3b","size":54479},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_structure.go","sha256":"4adcd21ae2396edddd4c552c9fdd5c53b5d61ab56c718573b0985089e5f16ed7","size":19440},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_operational_handoff_schema.go","sha256":"0414016c73ee268a4a14de340cf57fab132ac7d27737a3df8a606cfe8480e74f","size":38102},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_shape.go","sha256":"710668283d3d8075a43c445bda729f35798fa30ccaf88c6aabaffb5a8afb85e7","size":2878},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_guardrails_test.go","sha256":"584cfd2f96d13fb65e16423e4c3e4fb8a493bfad9c303b5fe7fd4c4f7b889269","size":81870},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_admission.go","sha256":"4d7bc8c97733edc4b3d549deaa5c2f05121d130bd94fb56de06081cabfdadcd1","size":20473},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/reliable_submit_operational_admission_redteam_test.go","sha256":"c4efbbdc29f653a9829a36fc2df63258feda7823717c7b75956d45a82da37ed9","size":40997},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_admission_test.go","sha256":"8bd4ff8d965cb49927804194c88bb4aae60192e0148cae9d26e2b825c40826ae","size":142934},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_format.go","sha256":"7a0a2128c9412917a400a05eeae6d3650417584042b87e25f333ec108aa1d2dd","size":10157},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_format_test.go","sha256":"2813c540ca0639fbe873cfbb83f6626fd2307def62c737f149d959d5ae5aa8c7","size":31600},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_handoff.go","sha256":"9cab7611a03ca0ab9eb41109a54db6d89709b998a71477cb96099ce2a1a9d510","size":26270},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_handoff_test.go","sha256":"30bfa1a2090285e74a4e20639b6d5a581d0363e41966e5a8d61b3d8b8b06103d","size":61862},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/service.go","sha256":"317be6476f82f7214ed1d00282acd6779271ddd2d6f20922783800bbc3ef64a7","size":36030},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/workstream_c_guardrails_test.go","sha256":"eadf4510636b44ade78297d332613bec4499cfd21a92d265dfac21af3c351769","size":365824}],"head":"e544e0fbe4220dfdd2c2068e3267dcfa454a0cf9","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"aae9785ac15b5281a9f7328d1cfc8541094d0dc51004330e5b0e4d86e4ababe0","upstream":"origin/claude/project-thread-sqldt7"}
```

### 11.12 Assumptions, unresolved seams, uninspected areas

**Assumptions.**

- No schema-5 database of the old shape is kept anywhere that matters (plan 3.3).
- The admission digest's content is the right canonical content: the normalized trust model, the verifier's algorithm, key id and key, and each selected built-in policy with its configured entries. `CP-RELEASE` names what it does not cover (the binary and its built-in policy code).
- EGS's signed trust model is the authority for trust. A compromised or stale EGS is outside this design.

**Unresolved seams, each already named by the design.**

- *Commissioning has no production caller.* Until `CP-ROLLBACK`, `CP-EPOCH`, `CP-POLICY-CUSTODY`, `CP-NATIVE` and `CP-RELEASE` are met, the private path cannot be turned on. This PR enforces that; it does not meet them.
- *One sender past its release re-read may still POST* after an advance or a withdrawal by another process (design 5.4, red-team RT-4). Bounded to one request already being sent.
- *ES reads EGS trust only at startup for ordinary Submit.* That is the separate pre-existing finding in design section 13. This PR does not change ordinary Submit.
- *A process fenced by an advance stays fenced until restart.* By design: only a restart adopts new content.

**Not inspected.** The other repositories. The darwin build. The RemoteAlpha operator scripts and their tests. The Coordinator's use of ES, if any. I did not re-read production code outside the nine production files this repair changes, except where a test or a guard pointed at it.

### 11.13 Confidence

- **Provenance: high.** The manifests were taken twice and are byte-identical, the staged set equals the manifest's path set, the tree was clean after each commit, and every result that 11.7 and 11.8 give for the final tip comes from a run made after that tip was pushed.
- **Validation: medium to high.** The full suite, the race detector and 173 mutants ran on the final tip, and the mutant evidence was read line by line, which found real gaps that are now closed. It is not higher because there is no CI, no macOS run, and I am the author of both the code and its tests.
- **Implementation: medium.** The design is followed and each guarantee has a test that fails under its mutant. It is not higher because this is a large change (7,583 added lines) to security-relevant code that no independent reader has yet seen. The parts I am least sure of are the guard fix, because a source-level guard can always be evaded by a form nobody listed, and the admission digest's canonical content.

### 11.14 Report delivery

This file: `/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/05-repair.md`. Its SHA-256 is given in the thread reply that delivers it, because a file cannot contain its own hash.

Attached with it:

- `05-repair-redteam-test-changes.diff`, SHA-256 `c7436d559e57d20ecbadf5fb4eface61396fbf6fd4d842855168ee303f45f95c`: the complete difference between PR #15's test file and the adapted copy.
- `05-repair-mutant-evidence.tar.gz`, SHA-256 `d881d8962af2d79cbfba827499c04861bb2cbbb7e6d96cb96b2f0428f48518dc`: the mutant specifications, the runner scripts, the uncommitted three-line test-file patch, the complete output of the final mutant pass, of the complete pass on the previous tip `af23316` and of the earlier passes, the repeated runs of the writer-lock mutant, and the result of every test by name for the baseline run, the final run and the two race runs, plus the same three runs on the previous tip. It holds test names and verdicts, no test output.

## 12. Effect status

`TOPIC_BRANCH_PUSHED` `claude/project-thread-sqldt7` at `b6d2f7787ec8254134cb48fcae0da72bac0fd02c`, by fast-forward, no force.

`DRAFT_PR_OPENED` https://github.com/evo-agi/Execution-Substrate/pull/13 (already open as a draft; its description was updated).

`MERGE_NOT_PERFORMED`

`INDEPENDENT_AUDIT_NOT_PERFORMED`

Nothing else was changed by this repair: no push to PR #12's branch, to PR #14's branch or to PR #15's branch, no comment on GitHub, no contact with a live service, no change to the Linux box or the Mac. Files written in the project folder: this file, the attached diff and the attached archive.
