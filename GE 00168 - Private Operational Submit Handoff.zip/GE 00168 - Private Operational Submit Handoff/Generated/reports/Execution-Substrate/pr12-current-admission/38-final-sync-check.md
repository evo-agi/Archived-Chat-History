# PR #12 final sync (draft PR #47 at `7324b62`): check 38

Written 2026-11-24 from 05:27Z onwards by the independent audit thread "Audit Execution-Substrate PRs", after the PR 12 writer thread asked for a diff-only check of PR 12's final sync before PR 12 merges. Read-only: nothing was pushed, commented, reviewed or merged. Evidence is in `38-final-sync-check-evidence/` next to this file. My local names carry the tag `40e`.

Subject: the writer's `37-final-sync.md`. I began on SHA-256 `03a4fe38…24ff`; the writer then filled section 4 (whole-module comparison and CI), giving `b764b8bb…42ac`, which I read before publishing.

## Verdict

**ACCEPT, with no findings.** The three commits after `f7bb1d6` do what the writer says and nothing else.

- **I36-1 is applied, and the clause is true of the code.**
  - The first item of the `CP-NOMAD-ACL` row is now "the provider's token is the one ES loads from `nomad.token_file` at startup for the current submit client;". The clause appears once in the owner contract.
  - The code matches it. At startup, `service.go:246` builds the current submit client with `newNomadClient(cfg.Nomad)`. That function loads the token with `loadNomadToken(cfg.TokenFile)` (`submit.go:237`), and `TokenFile` is the config key `nomad.token_file` (`es/config/config.go:31` and `:116`).
  - The clause is pinned three ways: in `operationalV2AssuranceOwnerRule`, in the contract test's list, and as the new mutant `MissingNomadACLTokenCustody`. The mutant test passes, so the contract fails when the clause is removed.
- **The merge `ac0d11a` is git's own.** `git merge-tree --write-tree 26fb3a3 5d6ad51` gives `4429e6e9`, the commit's tree.
- **The trunk paths stay out of PR 12's scope.**
  - `trunk_dev` `6dbeaeb..5d6ad51` (#44 and #46) changes four paths: one reliablesubmit test file, the SPIRE agent helper and its test, and one system overview doc.
  - At the head, all four are byte-identical to `5d6ad51`.
  - PR #47's path set against `5d6ad51` is the same 70 paths as `f7bb1d6`'s against `6dbeaeb`.
- **The round's own diff is the 3 files, +15/−11, the writer names.** No production Go file changes. Word for word:
  - The owner contract gains the 17-word clause, and its reconciliation sentence gains "#44 and #46".
  - `PLANS.md` gains "#44 and #46" and rewraps; no other word changes.
  - `docs_contract_test.go` updates the three pins of those two sentences, and adds the clause to the rule, the list and the mutant table.
- **The PR list is right.** `trunk_dev`'s first-parent history, from PR 12's earlier trunk base `4c991ba` to `5d6ad51`, is exactly #43, #42, #34, #31, #38, #44 and #46, in the order the sentence names them.
- **The manifests verify.** I took each twice, byte-identical, and each JSON file is identical to the writer's (`trunk-1.json`, `base-1.json`):
  - trunk-relative: `1a56860c…bd3e`, 70 files;
  - PR-relative: `3f04d2bf…5eb0`, 92 files.

  For both, the staged set equals the paths, `write-tree` gives the head tree `ca8f4ca7`, and the status is clean afterwards. Against check 36:
  - trunk-relative: the round's three files changed, and 67 entries are identical;
  - PR-relative: six entries changed (the round's three files and three trunk paths), #44's test file is added, and 85 are identical. Inference: the PR-relative count rises from 91 to 92 because PR 12's branch (`99a6625`) predates #44, so #44's test file now differs from it.
- **Vet and tests pass as `ci`, apart from 33 tests that fail the same way without this round.**
  - `go vet ./...` passes, and `docs_contract_test.go` is gofmt-clean.
  - The root package passes 165 of 165, in a git checkout. That includes PR 12's docs pins and the mutant test with `MissingNomadACLTokenCustody`.
  - `es/admission` gives 581 passes, 8 skips and 0 failures, the same as check 36.
  - #44's reliablesubmit test and #46's SPIRE agent tests pass.
  - The whole module gives 1,686 passes, 58 skips and 33 failures (`whole40e.log`). The 33 are 3 in reliablesubmit, 2 in `es/app` and 28 in `scripts`. I reran exactly those tests on `f7bb1d6` (the head check 36 accepted, whose CI was green) and on `trunk_dev` `5d6ad51`. All 33 fail identically on `f7bb1d6`. On `5d6ad51`, the same 32 fail, and the 33rd is a PR 12 test that `trunk_dev` does not have (`fail-compare40e.log`).
  - They need things this sandbox lacks (`env-failures40e.txt`). Two reliablesubmit tests say an authenticated schema-4 opener and an old production-source probe "is required". The real-Nomad test cannot reach a Docker daemon. The 28 `scripts` tests are the Remote Alpha operator and TLS status scripts, which fail here on every commit I tried.
  - CI accounts for all 33 (`env-only-check40e.txt`). 11 of them, including the 3 reliablesubmit tests, are on CI's list of tests that cannot pass on its runner (`.github/ci/environment-only-tests.txt`). The other 22 are not listed. CI's gate (`.github/ci/go_test_gate.py`) runs every unlisted test and passes only if each package run passes, so its green run on `7324b62` means those 22 passed on the runner.
- **The writer's whole-module comparisons agree.** Their section 4 finds 0 changed results against `trunk_dev` `5d6ad51` (7,498 shared) and against `f7bb1d6` (9,627 shared). The one new failure they list is the same probe-binary test that fails here, and it is on CI's list of environment-only tests.
- **CI:** run 45333412400 of `build, vet and test` succeeded on `7324b62` (check run 138239674333, 05:27Z to 06:13Z), which I read on GitHub myself.

## In plain words

This round adds the one line I asked for last time: the private path must use the same Nomad password file that ES already reads at startup. It also takes in two small `trunk_dev` changes that do not touch PR 12's files, and updates two sentences that list those changes. Everything still matches what was checked before.

## 1. Target

| Item | Value |
| --- | --- |
| PR | evo-agi/Execution-Substrate #47 (draft) into `codex/reliable-submit-operational-handoff-v1` (PR #12 at `99a6625`) |
| Head | `7324b62968ee4c93b5d8e4fe71532c7d7c51f383`, tree `ca8f4ca71672959dd25c9573c2452309c75b0fcf` |
| Previous target | `f7bb1d6` (`36-combined-check.md`, ACCEPT) |
| `trunk_dev` | `5d6ad513add57a3bd69e8956c32090e343d4f82d` (#46), the merge base |
| Commits | `26fb3a3` (I36-1), `ac0d11a` (merge of `5d6ad51`), `7324b62` (names #44 and #46) |
| Recipe | v2, source SHA-256 `c08597e2…a1a3ca`, verified before the run |
| Trunk-relative manifest | `1a56860c8bf8f406ef347fa74b7abd6ebff085b534647f047ec49bdcbfe6bd3e`, 70 files, textual diff `f70c716d…8cc3`, upstream `origin/trunk_dev` |
| PR-relative manifest | `3f04d2bfc00f4f83537d558cdb964be99df762b95c7a4ee9a077348df9995eb0`, 92 files, textual diff `47dbb1e8…e4e5`, upstream `origin/codex/reliable-submit-operational-handoff-v1` |
| Toolchain | Go 1.26.5, `GOTOOLCHAIN=local`, `env -i`, user `ci` (1500:1600) |

## 2. Evidence

| File | What it shows |
| --- | --- |
| `ls-remote-open.txt`, `ls-remote-close.txt` | the refs at the start and the end |
| `provenance-40e.txt` | the three commits, the merge-tree check, the four trunk paths and their equality with `5d6ad51`, the round-only diffstat, the same 70 paths |
| `round-diff.txt` | the round's diff in its three files |
| `verify-40e.txt` | the clause count, where ES loads its token, the `trunk_dev` PR list, and the word-level changes of `PLANS.md` and the owner contract |
| `manifests/` | both manifests, twice each, with the log of the run, the staged sets, `cmp-vs-40d.txt` against check 36, and `manifest-match.txt` against the writer's |
| `tree-check.txt` | the `ci` copy against the head: 556 entries, 0 differences |
| `unit40e.log` | vet, gofmt, the root package, PR 12's docs pins with the new mutant, and the token, guard and gate tests |
| `whole40e.log` | the whole module's tests, per package |
| `fail-compare40e.log` | the 33 failed tests rerun on the head, on `f7bb1d6` and on `5d6ad51` |
| `env-failures40e.txt` | the first failure message of five of them |
| `env-only-check40e.txt` | which of the 33 are on CI's environment-only list |
| `scripts/` | the scripts that produced these |

## 3. What I did not cover

- I ran no probes or mutants of my own. Nothing executable in PR 12's own code changed this round. The mutant test of the owner contract runs all its mutants, including the new one.
- The 33 tests that need what this sandbox lacks did not pass here on any commit; for them I rely on CI. Nothing ran against a real Nomad, and the provider is still unwired.
- I did not trial-merge any open PR.

## 4. Sensitive material

No token, key, certificate body, env file or config file is copied into the evidence. The checks name where ES loads its token, not any token. Commit-message trailers and author names are left out. The report and evidence were scanned with the thread's pattern list and a positive control before delivery.
