# Red-team report: Execution-Substrate PR #12 with its fix PR #13, combined, at `bff8dda`

Status of this file: **RED-TEAM REPORT.** Written by the red-team thread of the combined change on 2026-11-23 between 06:58 and 07:55 UTC. Readers: the coordinator, David, the PR #13 writer, the audit thread of the delta `51d6d5f`, and the Fable re-red-team that follows after the reset (section 6 is written for it).

This pass ran on Opus by David's decision. It is separate from the writer and from the correctness auditor. It pushed nothing, commented nowhere and merged nothing.

---

## 1. Verdict

**HOLDS WITH CAVEATS.**

In plain words:

1. **The behaviour holds.** Under every behavioural attack I could build on a local stack, the combined change did what its documents say. A revoked or changed trust model stopped the private path within one confirmation and kept it stopped. A process holding an older generation never sent, even when the stored row came back to its own content (A, then B, then A). Of eight concurrent advances exactly one won. Raw SQL that skips the Go code was refused by the triggers. Nothing was sent twice: not under eight concurrent deliveries of the same claim, not across 144 SIGKILLs of a second process at random instants, not after an advance that lands between a writer's COMMIT and its release. Swapping the staging root was refused. Two parser fuzz targets ran 3 minutes each from valid seeds without a failure.
2. **One finding, RT2-1 (low, guard gap, holdable).** A production file can reopen a stopped admission state through a dependency that is already in the module graph: `modernc.org/libc`, an indirect requirement of the SQLite driver. It exports the C library's memory functions (`Xmemset`, `Xmemcpy`) as ordinary Go functions. My probe file imports no `reflect`, no `unsafe`, no `C`, opens no file and makes no system call. With it, a locally withdrawn Service sent a job, a Service whose EGS had been unreachable for 31 s kept sending, and a Service that EGS had superseded sent a revoked artifact once EGS became unreachable. With the file in place the whole repository suite gives exactly the same results as without it (6,703 pass, 42 fail, 41 skip, the same failing set). This differs from the audit's A5-1 in one way that matters: **here the import names the facility**, so the existing import inventory can hold it with a one-line predicate. The owner document's sentence "The import names which files can write storage past the typed inventories" (line 775 at `51d6d5f`) is untrue for this road, and the new limit text of `51d6d5f` does not cover it, because this code does go through the language. A regression test that fails today and passes with the predicate is delivered.
3. **Caveats that are documented limits, now shown concretely** (section 5): ES reads EGS trust only at startup, and in a process that commissioned the private path `Initialize` now refuses to reload, so ordinary `Prepare` keeps admitting an artifact that EGS revoked while the same process has already latched supersession on its private path. A recorded, correctly signed EGS response replayed later confirms old trust and lets a revoked artifact be POSTed (CP-ROLLBACK). A build with a stricter compiled policy joins the old generation and fences nobody (CP-RELEASE). A crash at a bad instant leaves a claim that needs a new submit key (34 of my 144 crash rounds, with kill windows chosen to land inside the handoff, so this is not a production rate).

Nothing here blocks the core behaviour. Under the project rule "no accept now, revisit later", I recommend closing RT2-1 before PR #12's merge gate: one predicate in the import inventory, one sentence in the owner document, and the delivered test. Where it goes (the documents delta on PR #13's branch, or the next change of PR #12's branch) is the writer's and coordinator's call.

## 2. Target identity

| Field | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Red-team target | PR #13 branch `claude/project-thread-sqldt7` at `bff8dda37dbf5484afb3b264d4eca38cf6abf118`, tree `38269372c5bc21f291e1b73e93cf48d78180649d` |
| Base | PR #12 branch `codex/reliable-submit-operational-handoff-v1` at `8058561edc08356c46680c204586b3c7796c0ff3` |
| `trunk_dev` | `bc9fe3619823245faf550db4bf1bc3e782fbd5a5`; merge base with the target `ae326b0ddc30ec6b35883ee32945c622405b68b6` |
| Recipe | `governed_execution_audit_patch_manifest_v2.py`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified before each run |
| Base-relative manifest | `4ccb1a24c05c0baec014b3f295975bb60ae7bae00437752b12f3865767bd1616`, 6,291 bytes, 28 files; opening equals closing, each run twice with identical output |
| Trunk-relative manifest | `2f770674b0095a814852b3a76499c77766228f897ccb7482f64e0477212cc788`, 10,578 bytes, 48 files; opening equals closing |
| Head moved during the pass | PR #13's remote head is now `51d6d5fcb5d7e59e70fd53e1cd2801044a03e23a` (committed 07:14 UTC, report `13-repair.md`). It changes three files only: the owner document, `PLANS.md` and `docs_contract_test.go` (`git diff --stat`). Every production, guard and other test file is byte-identical, so every behavioural result here carries over. RT2-1 bears on its new text (section 4). |
| Environment | Cloud container, linux/amd64, Go 1.26.5 (`GOTOOLCHAIN=local`), unprivileged user `ci` (uid 1500), emptied environment, umask 022. Each scratch clone had the one-file Linux store-test overlay from `11-repair-evidence` applied, as in the audits (fixed on `trunk_dev` by PR #14). |

## 3. Posture and effects

- Read-only toward every repository. After the opening, my only contact with GitHub was a read-only `git fetch` of PR #13's branch, to see that it had moved; it updated a remote-tracking ref in my container only.
- All attacks ran in scratch clones under `/opt/ci/work/` owned by the unprivileged user. My local checkout of the PR #13 branch is clean at `bff8dda` (`git status --porcelain` empty at the end).
- No live service, no third party, no Linux box. EGS, the artifact registry and Nomad are the synthetic test doubles of the suite.
- Hostile production files (the probes) existed only in scratch clones and are in the evidence folder as `.txt`.

## 4. Finding

```text
RED-TEAM FINDING
ID / Type / Severity: RT2-1 / guard gap (holdable) and an untrue document claim / low

Current contract or strategic target:
  Design goal of the admission state package: no code outside the package can
  change the admission state except through calls that the guard lists. The
  import inventory exists so that "a new reflect, unsafe or C import in any
  production package fails a test", because such a file can write storage past
  the typed inventories.

Path and line:
  es/admission/workstream_c_guardrails_test.go:4045-4064 at bff8dda
    operationalGuardImportInventory: the predicate at :4057 is
    path == "reflect" || path == "unsafe" || path == "C".
  es/admission/workstream_c_guardrails_test.go:4089
    TestOperationalGuardReflectUnsafeImportInventoryIsExact.
  go.mod:26  modernc.org/libc v1.74.1 // indirect   (also :28 modernc.org/memory)
  .docs/execution_lifecycle/reliable_submit_operational_handoff.md at 51d6d5f
    :763-775 "reflection; `unsafe`; and cgo. For the last three an exact import
             inventory covers ... The import names which files can write storage
             past the typed inventories"
    :578-595 the new limit: code that writes its own memory "without going through
             the language"; "No source inventory can hold that road in general".
    :805-808 "It needs no `reflect`, `unsafe` or `C` import, so the import
             inventory does not see it".

Evidence (measured at bff8dda, linux/amd64):
  1. Probe: one production file, es/admission/zz_rt_libc_reopen.go (evidence
     probes/zz_rt_libc_reopen.go.txt). Imports: fmt, strconv, strings, time,
     modernc.org/libc. It reads the address of the state from fmt's "%+v" text of
     the Service, then calls libc.Xmemset(nil, addr+48, 0, 2) to clear the
     withdrawal and supersession latches, or libc.Xmemcpy(nil, addr+56, &now, 24)
     to overwrite the time of the last confirmation. It names no protected field,
     no handle field and nothing of the state package.
  2. Effect (results/libc-effect.log), three tests, all pass:
     - a Service whose local withdrawal latch is set (its durable write failed)
       is reopened and sends a job: kind=5 operation=8 write=11 receipt=true;
     - with EGS failing for 31 s the view has expired; after the write the same
       Service sends a job;
     - a Service superseded by a revocation at EGS is reopened. While EGS still
       serves the revocation, the handoff's own confirmation latches it again and
       refuses (reason 1). Once EGS is unreachable, the cleared Service sends the
       revoked artifact.
  3. Guard: es/admission with only the probe file added: 2,207 pass, 1 skip, as
     the clean baseline (results/libc-admission.summary.txt,
     base-admission.summary.txt). Whole repository with only the probe file:
     6,703 pass, 42 fail, 41 skip, the same failing set as the clean tip
     (results/full-libc.summary.txt, full-tip.summary.txt; the 42 failures are
     environment-only, section 8). go vet reports only the known
     result_auth_test.go:395 copy-lock note, as at the clean tip. The file builds
     for darwin/arm64.
  4. Today no production file imports any modernc.org package except the blank
     import of modernc.org/sqlite in
     es/admission/internal/reliablesubmit/sqlite_store.go.
  5. By reading, not measured: modernc.org/sqlite/lib exports the transpiled
     SQLite C API with raw address arguments (for example
     Xsqlite3_randomness(tls, n, p uintptr) writes n bytes at p), and
     modernc.org/memory hands out raw addresses. Same class.

Impact:
  The in-process stops of the private path (local withdrawal, supersession, the
  30 s confirmation deadline) can be undone by a production file that passes
  every guard. The durable fences hold: a durably withdrawn or advanced row is
  still refused by the store comparison and the triggers, which this road does
  not touch. The precondition is the same as for A5-1: hostile or careless code
  in a reviewed production file of the module. What is different is that this
  road needs no operating-system facility and is named by one import line, so it
  can be held at no cost, and the owner document currently claims that the
  import inventory names every such file.

Required correction (wording and form are the writer's):
  a. Extend the import inventory to the modernc.org packages other than
     modernc.org/sqlite itself, for example
       || (strings.HasPrefix(path+"/", "modernc.org/") && path != "modernc.org/sqlite")
     (results/guard-candidate-fix.diff), or refuse those imports outright.
  b. Owner document: say that some dependencies export raw memory access as
     ordinary Go functions, that the import inventory holds them like unsafe, and
     keep the OS road of A5-1 as the limit that no inventory holds. Hold the
     sentence in docs_contract_test.go like its neighbours.
  c. Adopt tests/reliable_submit_operational_admission_redteam2_guard_test.go.txt
     (TestRedTeamPR12CombinedRawMemoryDependencyImportIsInventoried). At bff8dda
     it fails, 36 of 36 subtests (results/guard-test-at-tip.log). With the
     predicate of (a) it passes, and the existing inventory test still passes
     (results/guard-test-with-candidate-fix.log).

Uncertainty:
  The list of raw-memory packages is from reading the module graph (go.mod) and
  the module cache, not from a tool. I found no other dependency that exports
  arbitrary memory writes as plain functions (section 6, A-26). The struct
  offsets in the probe are those of 64-bit targets; that only matters for the
  probe, not for the guard rule.

Patch defect or pre-existing issue:
  Pre-existing road: modernc.org/libc entered go.mod with the SQLite store
  (c6766b6, 2026-07-26, already in the trunk merge base). The document claim it
  contradicts is not in PR #12's base 8058561; this repair added it.
```

## 5. Documented limits, shown concretely

These are not findings. They are named in the owner document or in earlier reports. The brief asked to show the startup-only trust concretely; the other two came out of the same work. The tests are report-only (`characterization/zz_rt_poc_characterization_test.go.txt`): each passes because the limit exists and fails with "GAP CLOSED?" when someone closes it. Output: `results/poc-characterization.log`.

**L1. Startup-only trust, in one process and in two** (`TestRTPoCStartupOnlyTrustOrdinaryPath`). In a process that commissioned the private path, EGS revokes the artifact `sha256:610d149e389852da358c03e15f12babbbcba5177558d3fac1bb87d79198fa770`. One confirmation later the private path has latched supersession and refuses. In the same process, ordinary `Prepare` of the same request still admits the revoked artifact. `Initialize` refuses to reload: "private operational authority is already commissioned or withdrawn". So a commissioned process can only learn the revocation for the ordinary path by restarting. In a process that never commissioned the private path, ordinary `Prepare` admits the revoked artifact until `Initialize` runs again, and production calls it only at startup (`es/app/app.go`); after a re-`Initialize` it answers `artifact_revoked`. The new part is the interaction: the process knows it is superseded and still admits on the ordinary path, and it cannot reload.

**L2. CP-ROLLBACK** (`TestRTPoCRollbackReplayConfirmsOldTrust`). The signed trust payload has no sequence number and no expiry. A response recorded while the commissioned trust was published keeps confirming after EGS has revoked the claim's artifact; the retained claim is staged and POSTed (kind=5, receipt=true). Reaching the ES to EGS channel needs the EGS mTLS identity (the config requires https with a client certificate), a stale EGS replica, or an EGS restarted from old configuration.

**L3. CP-RELEASE** (`TestRTPoCNewReleaseJoinsAndDoesNotFence`). A build whose compiled policy refuses what the old build allows presents the same digest, joins the same generation (the row is unchanged) and fences nobody. The new build denies (reason 17); the old build on the same generation sends the job.

**L4. Crash residue.** 144 SIGKILL rounds of a second process at random instants (section 7): 110 completed with exactly one POST, 27 left charged stage residue, 7 left a marker without its sender. None sent twice. Each of the 34 stopped claims needs a new submit key, as documented ("After staging the claim keeps its charged residue and cannot stage again"). The kill windows (0 to 70 ms after the start signal) were chosen to land inside the handoff; this is not a production estimate.

**L5. Withdrawal is undone by any advance with new content** (CP-POLICY-CUSTODY), and a withdrawal accepts a token of any generation. Both are documented; my withdrawn-domain test confirms that only new content re-enables, and that every Service holding the old token stays closed.

## 6. Attack inventory (for the Fable re-red-team)

Status: **Held** (measured, the change refused it), **Limit** (documented limit, shown), **Finding**, **Reading** (reasoned, not run). "Test" names my test in `tests/` unless marked writer. Ideas in the last column are where I would look next with more time or a stronger model.

| ID | Attack | How | Result | Evidence | For the next pass |
| --- | --- | --- | --- | --- | --- |
| A-1 | Revocation between the last confirmation and a fresh delivery (TOCTOU) | Confirm, then EGS revokes the artifact, then deliver | Held: refused before establishment; no claim row, no sealed original, no reservation, no POST | `TestRedTeamPR12CombinedRevokedAtEGSRefusesFreshDelivery`; mutant MU7 caught | Revocation landing inside the one confirmation's request (EGS answers old, then changes) is CP-ROLLBACK territory |
| A-2 | Any trust change for a retained claim | Added allowed signer, unrelated revocation, claim's artifact revoked, claim's signer revoked | Held: supersession latched for the life of the state, also after EGS serves the original again; fresh delivery refused, no grant | `TestRedTeamPR12CombinedConfirmationComparesContent`; writer's `TestOperationalAdmissionChangeAtEachProofHook` covers each proof hook | |
| A-3 | Respelled equal trust | Every entry padded with spaces and tabs, lists reversed | Held: confirms (normalization), job completes | same test, first subtest | Case differences (`SHA256:` vs `sha256:`) make a different digest: fail-safe, not tried at enforcement |
| A-4 | Overlapping confirmations, late equal answer | First request slow with old trust, second latches supersession, then the first returns | Held: stays superseded | `TestRedTeamPR12CombinedLateEqualConfirmationKeepsSupersession` (added after MU4 survived the first pass); MU4 caught | |
| A-5 | Slow EGS stretches the 30 s window | EGS sleeps 1.5 s | Held: the confirmation time is the instant before the request | `TestRedTeamPR12CombinedSlowConfirmationCountsFromTheRequest`; MU5 caught | |
| A-6 | ABA generation | Row g1 (A), g2 (B), g3 (A); the g1 Service holds the same digest | Held at retained claims (established, run assigned, intent bound) and at a fresh delivery; only g3 completes | `TestRedTeamPR12CombinedGenerationABAKeepsOldViewFenced`; MU1 and MU1b caught | |
| A-7 | Concurrent advances | 8 distinct contents plus a twin advance generation 1 at once | Held: exactly one winner; losers install no view, act on nothing, cannot advance a stale generation; the twin joins only if its content won | `TestRedTeamPR12CombinedConcurrentAdvanceHasOneWinner` | Same race across processes (child helper exists) |
| A-8 | Re-enable a withdrawn domain with the old content | Commission, or advance with the withdrawn digest | Held: both refused; new content enables (L5) | `TestRedTeamPR12CombinedWithdrawnDomainNeedsNewContent`; MU9 alone survived (the trigger repeats the store check), MU9b (both) caught | |
| A-9 | Raw SQL past the Go code | Every transition but withdraw and advance; identity change; time regression; delete; second row; claim progress and insert while withdrawn | Held, with controls passing | `TestRedTeamPR12CombinedAdmissionRowTriggersRefuseRawWrites`; MU8 caught. Note: my claim-progress raw writes also fail CHECK constraints when enabled, so for the claim clause MU2 was caught only through the message; the writer's `TestOperationalAdmissionClaimGuardsByRawSQL` tests that clause with well-formed writes and is the one that matters | |
| A-10 | Advance between a writer's COMMIT and its release re-read | Release proof hook advances at assign, intent, stamp and mark | Held: nothing released, no POST; before staging the new generation completes; after staging the claim stays stranded (documented) | `TestRedTeamPR12CombinedAdvanceBetweenCommitAndRelease`; MU3 caught | |
| A-11 | Replays and retries of the same submit | Same request again after every refusal and every crash | Held: one POST in total everywhere | all tests above, A-13 | |
| A-12 | Concurrent deliveries of the same claim, one process | 8 goroutines, 8 custody handles: fresh, established, run assigned | Held: at most one POST; a later delivery ends with exactly one POST and the receipt | `TestRedTeamPR12CombinedConcurrentSameClaimSendsOnce` (also under `-race`) | Cross-process version: writer's `testOperationalTwoProcesses` |
| A-13 | Crash at any instant | Second process continues a retained claim; SIGKILL after 0 to 70 ms; 144 rounds in three runs | Held: integrity check ok every round, at most one POST, survivor completes or leaves a documented stopped state | `TestRedTeamPR12CombinedSIGKILLAtRandomInstants`; L4 | Kill the survivor too (double crash); kill during WAL checkpoint; power loss is not reproducible here |
| A-14 | Staging root swap | Symlink to the moved root, new directory in place, symlink to another directory | Held: refused, nothing created; completes after restore | `TestRedTeamPR12CombinedStagingRootSwapRefused` | MU6 survived: the second identity check after reopening the root by path guards a window between two system calls that my test cannot reach. Needs a hook or a racing swapper |
| A-15 | Malformed inputs | Fuzz `decodeOperationalEvidence` and `parsePrivateReplayDelivery` (writer's targets) seeded with a valid signed record and a valid delivery | Held: 851,387 and 891,298 executions in 3 min each, no failure | `results/Fuzz*.log` | Longer runs; a target over the durable record codec |
| A-16 | Bypass the package: same-package second file | A second file in `internal/admissionstate` | Caught by 3 guard tests | `probes/zz_rt_state_extra.go.txt`, `results/probe-p5.summary.txt` | |
| A-17 | Bypass the package: method expressions at a new site | `admissionstate.State.Confirmable` and `.Confirm` as values, a confirmation that asks nobody | Caught ("indirect reference escape") | `probes/zz_rt_method_expr.go.txt`, `probe-p6` | Method values through an interface held in an `any` field |
| A-18 | Bypass the package: swap the trust source | New production function replaces `trustModelVerifier` and `egsClient` | Caught by the field access inventory | `probes/zz_rt_egs_swap.go.txt`, `probe-p4` | |
| A-19 | Bypass the package: vendoring a copy | `go mod vendor` | Caught by `TestOperationalGuardLoadsEveryProductionFile`: vendor files are "built for none of the guarded targets" | `results/vendor-probe.log` | A vendored package with build tags that match a guarded target |
| A-20 | `reflect`, `unsafe`, cgo, `go:linkname`, assembly, build constraints | | Reading: import inventory with hashes, file-set check over three targets with `CGO_ENABLED=0`; linkname needs an `unsafe` import | owner doc; audits 10 and 12 probed them | |
| A-21 | Write own memory through the OS | | Limit (A5-1), named in `51d6d5f` | `12-audit.md` | |
| A-22 | Write own memory through a dependency's Go API | `modernc.org/libc` | **Finding RT2-1** | section 4 | Check new dependencies whenever go.mod changes |
| A-23 | Test seams in production | `operationalProof` hooks and the `...ForProof` configurators | Reading: no production caller (guard lists them with zero sites); the skew can only add time, the stricter evaluator can only refuse | guard lists at `reliable_submit_guardrails_test.go:1346`, `workstream_c_guardrails_test.go:2551` | |
| A-24 | Forged or reused tokens | Token from another generation; token made outside the store | Held: the compiler refuses a token made outside the store (audit 12); a token of another generation is fenced (A-6, A-10) | | |
| A-25 | Digest collision or canonicalization | | Reading: length-framed canonical bytes under a label, SHA-256; a collision needs SHA-256 to break. Respelling is normalized (A-3) | `state.go` `Digest` | |
| A-26 | Other dependencies with raw memory or reflective calls | `golang.org/x/sys/unix`, `google.golang.org/protobuf`, `text/template`, `net/rpc`, `encoding/json` | Reading: `x/sys/unix` reaches memory only through system calls (A5-1 class). Protobuf's legacy wrapper reads only fields with protobuf tags. `text/template` and `net/rpc` call only methods of fitting shapes, need a handle value (its field is inventoried), and `Confirm` returns nothing, so a template cannot call it | | Worth a tool-based scan of exported functions with `uintptr` parameters across the module graph |
| A-27 | Startup-only trust | | Limit, shown (L1) | `TestRTPoCStartupOnlyTrustOrdinaryPath` | |
| A-28 | Rollback of the signed trust | Replay a recorded signed response | Limit, shown (L2) | `TestRTPoCRollbackReplayConfirmsOldTrust` | |
| A-29 | New release with stricter compiled policy | | Limit, shown (L3) | `TestRTPoCNewReleaseJoinsAndDoesNotFence` | |
| A-30 | In-place change of `*s.trustModel` | | Inference, not run: establishment reads `s.trustModel`, the cuts read the view; both are equal by the install invariant. Whether a write through that pointer at a new site is caught by an inventory was not checked | | Probe it |

## 7. Mutation runs (do my tests catch what they claim to)

Each mutant changes one production place in a scratch clone and runs only the test named for it. Schema mutants in the second pass also rehash the schema-5 shape constant, so that the store opens and the trigger itself is what is tested (the first pass failed at the shape check, which proves nothing). Logs: `results/mutants.log` (first pass), `results/mutants2.log` (second pass).

| Mutant | Change | Result |
| --- | --- | --- |
| MU1 | Service establish turn ignores the stored token | Caught (the store fence still refuses, with another reason) |
| MU1b | Store fence and establish turn compare only the digest | Caught: the g1 Service sent a job |
| MU2 | Claim triggers lose the admission clause (rehashed) | Caught, through the message only (see A-9) |
| MU3 | Release re-read drops the admission comparison | Caught (first marker) |
| MU4 | An equal answer clears supersession | First pass survived; caught by the race test added for it |
| MU5 | Confirmation time taken after the request | Caught |
| MU6 | Stage creation skips the second root identity check | Survived: guards a window my test cannot reach (A-14) |
| MU7 | No confirmation before establishment | Caught |
| MU8 | Admission row trigger loses its transition rule (rehashed) | Caught, four transitions accepted with no error |
| MU9 | Store allows a same-digest advance | Survived: the trigger refuses it too |
| MU9b | Store and trigger both allow it (rehashed) | Caught |

## 8. What I ran

All in clean scratch clones of `bff8dda` as the unprivileged user, with the store-test overlay.

| Run | Result |
| --- | --- |
| `go test ./es/admission/` clean | 2,207 pass, 1 skip, 0 fail |
| same plus the libc probe file | 2,207 pass, 1 skip, 0 fail |
| `go test ./...` clean | 6,703 pass, 42 fail, 41 skip |
| same plus the libc probe file | identical counts and failing set |
| The 42 failures | 3 in `reliablesubmit` that need an authenticated old-binary opener (known, `baseline-store-packages.log`); 39 in the root package's Remote Alpha script tests (9 top-level tests and their subtests), which need sudo or the box. 8 of the 9 are on `trunk_dev`'s environment-only list; the 9th (`...PrepareSpireBundleRead...SudoVisibleInspection`) fails on "sudo-visible inspection". The combined change touches no root-package test file |
| Probes p4, p5, p6 (`./es/admission/...`) | each caught by the guard tests named in A-16 to A-18, plus the 3 known failures |
| My 11 behaviour tests | pass, also under `-race` (`results/redteam2-tests.log`, `redteam2-race.log`) |
| `es/admission` with all my test files added (the guard test skipped, it fails by design until RT2-1 is fixed) | 2,273 pass, 1 skip, 0 fail: the existing tests are undisturbed (`results/rt-suite-with-tests.summary.txt`) |
| SIGKILL test | 24 rounds (0 to 70 ms): 23 completed, 1 residue (log not kept, numbers from the test's own outcome line); 24 rounds (0 to 60 ms): 20 completed, 4 residue; 4 x 24 rounds (15 to 60 ms): 67 completed, 22 residue, 7 marker without sender |
| Fuzz, 180 s each, 2 workers | no failure |
| `go vet ./es/admission/` | only the known `result_auth_test.go:395` copy-lock note, at the clean tip and with the probe |

## 9. Regression tests delivered

| File in `13-red-team-evidence/tests/` | Tests | Adopt? |
| --- | --- | --- |
| `reliable_submit_operational_admission_redteam2_test.go.txt` | 11 behaviour tests (A-1 to A-12, A-14), about 4 s, pass at `bff8dda` and under `-race` | Yes, as permanent tests in `es/admission`. The claim-progress subtest of the trigger test may be dropped (A-9) |
| `reliable_submit_operational_admission_redteam2_crash_test.go.txt` | SIGKILL test, 24 rounds (6 with `-short`), about 3 s; window via `ES_RT_KILL_WINDOW_MS="low span"` | Yes. It accepts every documented outcome, so it cannot flake on timing; it fails only on a second POST, a failed integrity check or an undocumented state |
| `reliable_submit_operational_admission_redteam2_guard_test.go.txt` | RT2-1 guard test | Yes, together with the fix (it fails until then) |
| `characterization/zz_rt_poc_characterization_test.go.txt` | L1 to L3 | No. Report-only; they pass because the limits exist |
| `probes/*.txt` | hostile production files | Never |

## 10. Coverage this environment could not provide

- No CI runner, no macOS run, no Linux box, no real EGS, Nomad, SPIRE or Vault. Everything ran against the suite's synthetic doubles.
- Crashes are SIGKILLs of a test child process. No power loss, no kernel crash, no disk full, no fsync failure injection.
- Root-package script tests that need sudo could not run (section 8).
- The guard probes are a sample of roads, not a proof. The dependency scan in A-26 is by reading.
- Fuzzing was time-boxed to 3 minutes per target.
- Concurrency across processes was covered by the writer's two-process tests and my crash test, not by a new cross-process race of my own.
- The delta `51d6d5f` was read, not tested; it changes documents and one docs test only.

## 11. Sensitive material

None. No secrets, keys, tokens, live state or personal data were read or written. The evidence holds synthetic test output, scratch scripts and probe sources; I scanned it for keys, passwords and addresses before delivery.

## 12. Confidence

- High that the behaviours in A-1 to A-14 hold at `bff8dda` on Linux: each has a test, most are mutation-checked.
- High that RT2-1 is real and holdable: measured end to end, the whole suite is blind to it, and the candidate predicate turns the delivered test green.
- Medium on completeness of the dependency scan (A-26) and of the bypass roads in general: reading, not tooling.

## 13. How to reproduce

Scripts are in `13-red-team-evidence/scripts/` (rename `.txt` away): `setup.sh` (user `ci`, toolchain), `sync.sh <name> <commit>` (clone plus overlay), `cirun.sh <dir> <cmd>` (unprivileged, emptied environment), `pkgjson.sh` and `summ.py` (suite runs and summaries), `prov.sh <label>` (manifests), `mutants.py` and `mutants2.py` (mutants), `fuzzseq.sh`, `evidence-runs.sh`. To run the tests: copy the three test files into `es/admission/` of a clean clone at `bff8dda` (or `51d6d5f`) and run `go test -run 'TestRedTeamPR12Combined' ./es/admission/`. The libc probe needs `probes/zz_rt_libc_reopen.go.txt` and `zz_rt_libc_reopen_test.go.txt` in `es/admission/`; never commit them.

Evidence folder: `13-red-team-evidence/` (54 files) with `SHA256SUMS`, whose own SHA-256 is `9e15aca8f96c7ca6d0195fb41b321660c503b9e765ce13c1a6071a29ce923ccb`.

## 14. Effect status

Nothing pushed, nothing committed, no comment, no review, no merge, no branch created or deleted, no live service touched. The local checkout is clean at `bff8dda`.

STATUS: READY
