# Evidence for `28-redteam.md`

Red-team of Execution-Substrate PR #12 at `44166998d4ef0d7b86152f3f66265b906f7d612a`, 2026-11-23. Everything here was produced in a cloud container by the unprivileged user `ci` with Go 1.26.5. Nothing here was committed or pushed anywhere. `SHA256SUMS` covers every file of this folder except itself.

The two patches for the writer are next to the report, not in this folder: `28-redteam-regression-tests.patch` and `28-redteam-finding-tests.patch`.

## head/

| File | What it shows |
| --- | --- |
| `head-check.txt` | Commit, tree, parents, clean status, and the file-by-file comparison with report 26's trunk-relative manifest (56 of 56 equal). |
| `ls-remote-2053Z.txt`, `ls-remote-close.txt` | PR #12's branch and `trunk_dev` on GitHub at 20:53 UTC and at the end of the pass. |
| `trunk-dev-moved.txt` | `trunk_dev` went from `8ba1edb` to `76c030f` during the pass; no change under `es/admission`; trial merge conflicts in `PLANS.md` only. |

## tests/

The five new test files as text (`.go.txt`), identical to what the two patches add.

## candidates/

Two candidate corrections that exist only to show that each finding test passes once the defect is gone. They are not proposed code.

| File | Clone | Effect |
| --- | --- | --- |
| `candidate-fix-RT28-1.diff` | `rt3fix` | The argv test passes 5 of 5. |
| `candidate-fix-RT28-2.diff` | `rt3fix2` | The size test passes 6 of 6. |

## mutants/

`RM1.diff`, `RM2.diff`, `RM3.diff`: the three mutants of section 9 of the report.

## logs/

| File | Run |
| --- | --- |
| `base-admission-all.json.gz`, `.exit` | Baseline, clean head, `go test -count=1 -json ./es/admission/...` |
| `rt3-final2-all.json.gz`, `.exit`, `rt3-final2-vet.*`, `rt3-final2-gofmt.*` | Head plus the five new test files as delivered, same command, with `go vet` and `gofmt -l` (both empty) |
| `rest-tip.json.gz`, `rest-rt3.json.gz`, `.exit` | Every package outside `es/admission`: clean head, then head plus the new files |
| `rest-compare.txt` | The comparison of those two runs |
| `findings-final-rt3.log` | The finding tests with the final test file at head: both fail |
| `findings-final-rt3fix.log`, `findings-final-rt3fix2.log` | The same under each candidate |
| `rt3-finding-head.log`, `rt3-finding-candidatefix.log`, `rt3-finding2-candidatefix.log` | Earlier runs of the same tests with an earlier version of the test file; kept for the record |
| `rt3-300.log` | Withdrawal and advance at random instants, 300 rounds each, at head |
| `rt3m1-300.log`, `rt3m2-300.log`, `rt3m3-200.log` | The same tests against the three mutants |
| `rt3-race60.log`, `.exit` | The same tests under the race detector, 60 rounds each |
| `rt3p-150.log`, `.exit` | The three process tests, 150 rounds each |
| `rt3-first.log`, `rt3p-first.log`, `rt3p-live.log` | First runs with the default round counts |
| `fuzz-*.log`, `.exit` | The five fuzz targets. `…-firstproperty.log` is the first, too strong property of the retained-original target (report, row C4) |
| `rt3-scratch-largejob-intentedits.log` | Size thresholds, permanence and the four-claim fill for RT28-2; the request-edit matrix for O-3 |
| `rt3-scratch-bitscan.log` | The single-bit scan of a retained original (O-3, O-4). It prints short windows of the synthetic fixture's bytes. |
| `pr31-guard-on-pr12-tip.log` | PR #31's guard test run against PR #12's head (section 7) |

## scratch/

The scratch tests behind the two `rt3-scratch-*` logs and behind O-5, as text, and `finding_test.size-edit.diff`, the change to the finding test file that I made after the full-suite run (report, section 10).

## scripts/

The helper scripts as text. `cirun.sh` runs a command as the unprivileged user with an emptied environment; `sync.sh` makes a scratch clone at a commit and checks its tree; `summ.py` counts results of a `go test -json` file; `fuzzall.sh`, `final.sh` and `rest.sh` are the batch runs (the full-suite part of `final.sh` was run once more by hand after the last test-file change, which gave the `rt3-final2-*` files); `scan.py` is the secret-shape scan of section 13 of the report.

## reference-sources.txt

URLs and SHA-256 values of the six public Nomad and HCL files read for RT28-1, with the lines cited.
