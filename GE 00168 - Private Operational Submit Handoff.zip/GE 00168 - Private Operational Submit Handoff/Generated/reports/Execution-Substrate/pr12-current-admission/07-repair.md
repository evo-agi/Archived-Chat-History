# SECOND REPAIR OF PR #13: the guard escape through a pointer conversion, and the low findings

Status of this file: **IMPLEMENTATION REPORT, NOT AUDITED.** It is the replacement implementation report for draft PR #13 after the audit of `b6d2f77` (`06-audit.md`, verdict BLOCK). It describes the bytes of `c41e177f0d264318de3d799d8b28e7f494b18c74`. A fresh audit thread must judge it. The red-team pass on the combined PR #12 comes after an accepted audit.

Written by the PR #13 writer thread on 2026-11-22. Readers: the coordinator, David, and the fresh audit thread.

The approved design (`04-design-proper-admission.md`) and the frozen plan (`05-repair.md`, sections 0 to 10) are unchanged and still describe what the pull request builds. This report covers only what changed after `b6d2f77`.

---

## 1. In plain words

The audit accepted the production code and blocked on the guard: a protected field could still be written through a pointer that had been converted to another type of the same shape, and no guard test noticed. That is fixed. The guard now records a conversion in either direction, and an instantiation of a generic function or type with a protected type. Both of the audit's end-to-end escapes, run again on the new bytes, now fail the guard tests.

The seven low findings and the pre-existing one are repaired in the same commit. Production code changes in three small places: a cancelled call now answers "cancelled" at six points where it answered "unavailable" or "integrity"; the store's admission write has the COMMIT fault seam the other writers have; and two test hooks were added. Everything else is tests and documents.

Two choices in this repair are judgments and not mechanical fixes. Both stay inside the approved design, and both are stated here so the auditor can disagree:

- **What a refused first delivery answers (A2-4).** The audit offered two ways: limit "Denied" to retained claims, or report "Denied" for a first delivery too. I limited it. Section 4.4 gives the reasons.
- **What a cancelled call answers (A2-8).** The rule is: the admission's own judgment in the call wins; otherwise a step that fails under an ended context answers "cancelled". Section 4.6 gives the rule point by point.

**The evidence in short.** On the pushed commit the full suite has no test that went from pass to fail against `b6d2f77`, and 154 new test results pass. The race detector reports no data race. The audit's four probes that escaped are caught. Of 224 mutant runs 216 are caught. The 8 that survive are the six duplicate checks the audit already agreed with, and two of mine that no reachable state can tell from the code (section 9.1).

Nothing was merged. No branch other than `claude/project-thread-sqldt7` was pushed.

## 2. Identity

| Field | Value |
| --- | --- |
| Objective | Repair findings A2-1 to A2-8 and P-1 of `06-audit.md` on draft PR #13, and the observations the audit calls cheap and worth doing |
| Repository | `evo-agi/Execution-Substrate` |
| Base ref and SHA | `codex/reliable-submit-operational-handoff-v1` at `8058561edc08356c46680c204586b3c7796c0ff3` (the PR #12 branch) |
| Audited tip this repair starts from | `b6d2f7787ec8254134cb48fcae0da72bac0fd02c` |
| Topic branch | `claude/project-thread-sqldt7` (draft PR #13) |
| Topic commit SHA | `c41e177f0d264318de3d799d8b28e7f494b18c74` |
| Tree SHA | `f8868837ed8f363d47d80f0a94622f0163efb2ff` |
| Commits after `b6d2f77` | One: `c41e177` "Repair the typed guard and the low findings of the second audit". Fast-forward push `b6d2f77..c41e177`. |
| Final working-tree status | clean (`git status --porcelain` empty after the commit and after the push) |
| Recipe | `governed_execution_audit_patch_manifest_v2.py`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified before every run |

## 3. Reconnaissance

- I read `06-audit.md` in full and its evidence folder as data. I did not execute the auditor's scripts. My probe runner reads only the string constants of the two probe sources with a syntax-tree parser and applies them to a scratch copy (section 9.3).
- The audit's own search found no pointer conversion in the production files of the two packages. Mine agrees, so the new guard rule changes no real inventory.
- `OperationalCustody.mu` is taken in read mode by `WithOperationalOriginal`, `EstablishOperational` and `operationalAdmissionWrite`, and in write mode by `Close` and the three `Configure...ForProof` functions. `sync.RWMutex` is not reentrant. This is the fact behind A2-3.
- The store refuses every read and binding of a borrow whose context has ended (`a.life.live()` reads the context of the borrow). This is the fact behind A2-8: at the six points of section 4.6 a failure under an ended context is the cancellation, whatever reason the step itself would give.
- Ordinary resolution reports a policy denial with the decision's free-form reason code, so the handoff cannot classify "the rules refuse this request" exactly without changing the ordinary path. This is one of the reasons for the A2-4 choice.
- The changed-file set against the base is still the 26 paths of `b6d2f77`. This repair touches 16 of them and adds no path.

## 4. What was done, finding by finding

### 4.1 R1, finding A2-1 (medium, blocking): a write through a pointer conversion

**Rule.** `wholeValueReferences` (`es/admission/workstream_c_guardrails_test.go`) now records a `whole-convert` occurrence for a conversion in either direction: when the result or the operand is the owning type, a pointer to it, a container of it, or a defined type over it, and the other side is a different type. A conversion to an interface that is not a type parameter is exempt, because it changes no field and its later uses go through methods, which have inventories of their own. A conversion to a type parameter is recorded.

**Close relative found while testing the rule.** A generic function can hide the conversion: inside `func away[S interface{ *Service }](s S) *twin { return (*twin)(s) }` the operand has the type parameter's type, so the conversion itself names no protected type. The guard therefore records a new kind, `whole-instantiate`: an instantiation of a generic function or generic type whose type argument is the owning type, a pointer to it or a container of it. It is recorded where the instantiation happens, also when the type argument is inferred and when the instantiated function is only assigned.

**Self-tests** (`TestTypedObjectReferenceInventoryRejectsEscapes` and the whole-value table at `workstream_c_guardrails_test.go:3052-3153`). Every case the audit's R1 asks for is there: named twin, anonymous twin, a named pointer type as the target, the converted pointer kept in a variable, a whole overwrite through the converted pointer, and the negative control (a pointer conversion between two unrelated types of the same shape). Beyond R1: a tagged struct as the target, a named pointer type as the source, a pointer to a defined type over the owner, the owner inside a holder, a pointer to the holder, a conversion at package level, a conversion to a type parameter, conversion away by value, eight instantiation forms, and three negative controls (conversion to an interface, an unrelated same-shape type, a generic function instantiated with another type).

**End to end on the real packages.** A new subtest, "storage aliases added to the real packages" (`:2738`), adds a probe file to the real `es/admission` package through the type checker's overlay and requires each form to appear in the inventory of every protected field of the `Service` and of the installed view: a mirror through a pointer conversion, a whole overwrite through a converted pointer, a generic instantiation, and a field write through the converted pointer. The overlay loader (`typeCheckWithOverlay`) type-checks the real package with the extra file for the three guarded targets, so the test proves the rule on the production types and not only on fixtures.

**The audit's two mutants.** Both run again on the new bytes and both are caught (section 9.3): GM1, the installed view rewritten through a pointer conversion, fails two guard tests; GM2, the three Service latches cleared through a pointer conversion of the receiver, fails one.

**Documents.** The owner document states the rule in both directions, the interface exemption and `whole-instantiate`. `docs_contract_test.go` pins six guard phrases of that section, each with a deletion mutant.

**Real inventories.** None changed for this rule. The production files contain no pointer conversion and no instantiation with a protected type.

### 4.2 R2, finding A2-2 (low): the commissioning gate and calls through an interface. Observation O-6

I closed it and did not name it as a limit. A method inventory now counts dynamic dispatch (`dynamicMethodReferences`, `:4159`): an interface or constraint in the package that declares a method of the gated name is an `interface-method` occurrence, and a selection of that method through an interface or type-parameter value is an `interface-selection` occurrence. Both are references for `validateOperationalCommissioningGate`, so a gated entry reached through an interface of the two packages fails the gate and prints the five prerequisites. The store's member inventories count the same two kinds.

- Self-test: `TestTypedMethodReferenceInventoryCountsDynamicDispatch` (`:3459`), with a control that a function without a receiver of the same name is not counted.
- End to end: "gated entries reached through an interface in the real packages" (`reliable_submit_guardrails_test.go:1582`) adds an interface and a caller to the real package through the overlay and requires the gate to fail for commissioning, advance and withdrawal.
- The audit's probe P1 (all three entries called through an interface) is caught on the new bytes (section 9.3).

**O-6 (a production file the guards do not load).** `validateGuardedProductionFileSet` and `TestOperationalGuardLoadsEveryProductionFile` (`:3348`, `:3378`) list every non-test source file of the two packages on disk (Go, assembly, C and object files, extension compared without case) and fail when one is compiled for none of the three guarded targets. A file behind a custom build tag is such a file. The audit's probe P2 is caught (section 9.3). The control subtest "type-checked file missing from the listing" keeps the check from passing on an empty listing.

### 4.3 R3, finding A2-3 (low): the lock statements

The statements now say what the code does, in four documents and two code comments:

- Each of the three admission operations runs under the custody handle's lock in read mode and then takes the SQLite writer. The lock is not reentrant, so the operations must be called outside every borrow of the same handle. (Tests call them inside a borrow through proof hooks, with no concurrent `Close`; that is the one case where it is safe, and the comment says so.)
- A confirmation runs outside every writer turn and every transaction and holds neither `Service.mu` nor the owner mutex. At the two pre-checks it runs inside the borrow of the original, so the custody read lock is held across the EGS request. The confirmation of a fresh delivery holds no lock.
- The lock inventory row for `OperationalCustody.mu` in the admission model document names every holder.

**Machine check, so the row cannot drift again.** `docs_contract_test.go` parses the store package's non-test files, collects every method of `*OperationalCustody` that calls `mu.Lock` or `mu.RLock`, and requires the lock row to name exactly that set (`operationalCustodyLockHolders`, compared in `TestOperationalSubmitHandoffCurrentAdmissionV2Contract`). A new rule requires the four lock statements in the owner document and refuses the three old phrases ("outside every lock", "takes no lock", "never custody"). Five mutation cases cover it.

### 4.4 R4, finding A2-4 (low): "Denied" and a first delivery

**Choice: `OperationalDenied` is the answer of the re-judgment of a retained original only. A first delivery that ordinary resolution refuses stores nothing and answers `OperationalUnavailable`, whatever the cause.** Code is unchanged; the outcome table, the `PLANS.md` sentence and the test now say it.

Reasons:

1. Design 5.6 introduces Denied for retained claims that the current rules deny, to end their stranding. Its text says "The public mapping stays a later gate".
2. A first delivery is judged by ordinary resolution. Its typed error carries a policy denial as the decision's free-form reason code, so the handoff cannot tell "the rules refuse" from "unsupported" or "dependency unavailable" exactly without changing the ordinary path, which this pull request must not touch.
3. The handoff has no production caller, and a guard test enforces that. What a first delivery tells its caller is decided with the public mapping, behind the commissioning gate.

The alternative, reporting Denied for a first delivery too, would need a classification of ordinary resolution's errors that does not exist today. I did not build one.

**Pin.** `TestPR12RetainedAdmissionCuts`, cases "fresh ordinary policy denial" and "fresh ordinary revocation denial", now require `OperationalUnavailable`, no run, no receipt, zero stored claims and zero POSTs. Mutant R2-FRESH-DENIED (answer Denied there) is killed by both.

**For the coordinator and David.** This is a reading of the approved design, not a compromise of it: the design never promised Denied for a first delivery. If David wants a refused first delivery to say "denied", that is a new decision for the public mapping, and it does not block this pull request.

### 4.5 R5, R6, R7, R9: the store findings

- **R5 (A2-5), the evidence cap.** `TestOperationalHandoffV2CustodyStructure` builds its "at cap" and "over cap" vectors with the literal lengths 262,144 and 262,145. The audit's S-CAP1 and S-CAP2 are killed by "over cap".
- **R6 (A2-6), the published schema-5 shape.** `TestOperationalAdmissionPublishedSchema5ShapeRefused` requires the specific refusal of each of the four openers (three say the format is unsupported; the operational opener, which reports one reason for every failed open, says unavailable), requires that no refused open changes any database file, and opens the amended shape with all four openers in the control.
- **R7 (A2-7), the admission write.** `OperationalCustody` has a field `admissionCommit` that replaces the COMMIT of an admission write. No function sets it; the store's own tests assign it. Four tests:
  - `TestOperationalAdmissionCommitAnswerLost`: for each of the three operations, with the row written and with the row not written, a lost COMMIT answer is the unknown-outcome error with no token; the same call again converges on the wanted row and does not write twice.
  - `TestOperationalAdmissionStoredTimeAheadOfTheClock`: a stored time ahead of the clock is kept.
  - `TestOperationalAdmissionWriteRequiresCurrentStore`: a database that no longer verifies as current is refused, for each operation.
  - `TestOperationalAdmissionWriteReadsBackBeforeCommit`: the row is read back and compared before COMMIT. The audit listed this mutant (S-WR1r) as a duplicate that cannot fail today; it is now killed by behaviour.
- **R9 (P-1), a match for another original.** `TestOperationalAdmissionTokenAtEveryCut` hands each first-effect cut a callback that returns a valid match for a different original, carrying the stored token, and requires a refusal with no write (`operationalForeignMatches`: another claim, another plan binding, another witness, another digest). The audit's S-Q3 is killed at all five cuts, and so is one mutant per clause of the comparison.

### 4.6 R8, finding A2-8 (low): the answer to a cancelled call

**Rule.** The admission's own judgment in the call comes first: a fence or a missing view answers Unavailable, a completed denial answers Denied, contradictory evidence answers Integrity, also when the context has ended meanwhile. Otherwise, a step that fails under an ended context answers `OperationalCanceled`. When a call is both cancelled and refused by the authority, the refusal is reported.

**The six points that changed.** Before, each answered Unavailable or Integrity when the context had ended:

| Point | Before | Now, context ended | Now, context live |
| --- | --- | --- | --- |
| Pre-check: read of the admission row (`AdmissionHint`) | Unavailable | Canceled | Unavailable |
| Binding of the intent | Integrity | Canceled | Integrity |
| Binding of the staged tree to the stamp | Integrity | Canceled | Integrity |
| Binding of the marker | Integrity | Canceled | Integrity |
| Verification of an accepted receipt | Integrity | Canceled | Integrity |
| Binding of a completed observation | Integrity, run withheld | Canceled, stored run kept | Integrity, run withheld |

At the last point the marker is durable and the request was sent. As at the entry of reconciliation and at the final sender entry, a cancellation alone keeps the stored run; before the marker a cancellation withholds it.

Production change: `withholdAt` and five edited sites in `es/admission/reliable_submit_operational_handoff.go`, and two hooks for tests (`beforeReceipt`, `beforeObservation`), nil in production like the existing ones.

**Test.** `TestOperationalAdmissionCancelledCallAnswersCanceled` (`es/admission/reliable_submit_operational_admission_test.go:3101`) ends the context:

- while EGS answers the confirmation, from four starting states (first delivery, after establishment, after run assignment, after intent), with a control that an unreadable row under a live context is Unavailable;
- at every freshness sample: the test ends the call at sample 1, 2, 3 and so on until the call takes fewer samples than that, which must then complete. That is 149 endings in total, and each answers Canceled with no claim write and no request after the end;
- during the evaluation, where the first evaluation of a retained start must leave the write slot empty (this kills the audit's A-Q8);
- before the staged tree is bound to the stamp (the stage stays as charged residue and a retry answers "occupied" with nothing changed, see O-2);
- before the marker is bound, before an accepted receipt is verified (a retry returns the same run and receipt), and before a completed observation is bound (the run is kept and a retry completes with the same run).

Three more controls run the same steps under a live context and require Integrity with no run and no receipt: a staged tree that drifts before the marker, an accepted receipt that does not verify (the provider answers for another region for that one call), and an observation whose witness does not bind. With the control at the row read, four of the six points have a control under a live context. The other two are in section 6, item 8.

**The writer turns.** The owner document says that every writer turn checks the context immediately before its COMMIT. That was true by reading and pinned by no test. Two store tests now pin it with a test context that reports its end through `Err` only (its `Done` channel is nil, so neither `database/sql` nor the driver watches it, and the looks of the store's own code are the only instants at which the end can be seen):

- `TestOperationalAdmissionWriteLooksAtTheContextBeforeCommit`: a call that finds the wanted row takes the same looks as a writing call up to its step. A writing call whose context ends after exactly that many looks is refused as unavailable, makes no COMMIT attempt and changes no row; with one live look more it commits. So exactly one look lies between the read-back and COMMIT. For commission, advance and withdrawal.
- `TestOperationalHandoffCutLooksAtTheContextBeforeCommit`: for the run assignment, intent, stamp and marker turns, the context ends one look later in each attempt until the cut commits. The last attempt that commits nothing must answer "definitely not applied", which only the turn's own check before COMMIT returns; an earlier end is a refusal of the step.

The cut turn's check is code of the PR #12 base that this pull request does not change. I pinned it because the sentence this repair adds to the owner document states it.

### 4.7 The observations and audit section 7.5

| Item | Disposition |
| --- | --- |
| O-1: withdrawal sets the local latch before the durable write, the design says the reverse | No code change; the code's order is the safer one and the owner document describes it. Added to the deviation list (section 6, item 1). |
| O-2: residue after any stop between staging and the stamp | One sentence in the owner document: it holds whatever stopped the call (a denial, a fence, a passed confirmation deadline, a cancelled call). The cancelled case and its retry are pinned by the subtest "before the staged tree is bound to the stamp". |
| O-3: an advance may return to earlier content | No change. It belongs to the open prerequisite `CP-POLICY-CUSTODY`. |
| O-4: the CHECK accepts an all-zero digest | No change. The Go layer refuses it before the write; already in the deviation list of `05-repair.md`. |
| O-5: stale comment in the red team's file | Corrected. See section 7.3. |
| O-6: a production file behind a custom build tag | Closed by a test (section 4.2). |
| O-7: the whole-value inventory covers two packages | Named as a limit in the owner document. The audit's probe P3 confirms the limit as stated (section 9.3). The result of that write is a Service without a view, which admits nothing. |
| O-8: the table-writer inventory reads statement literals | Named as a limit in the owner document. |
| O-9: four Service fields without an inventory | Inventories added for `egsClient`, `trustModelVerifier`, `provenanceVerifier` and `admissionPolicyEvaluator`: one initializer each, and their reads by site. |
| O-10: `PLANS.md` could be read as "every cut re-reads after COMMIT" | Reworded: the release of a run assignment, intent, stamp or first marker reads the row again; establishment releases nothing and the pre-stage turn is followed by the stamp turn, so those two have no re-read. |
| O-11: "older than 30 seconds" | Reworded to "refuses unless the last confirmation is less than 30 seconds old". |
| O-12: commit trailers name a model | Not a change to the tree. The harness requires the trailer on each commit. A merge that should carry no model name needs a squash with a clean message; that is a step for the merge, with David's go. |
| O-13: establishment samples just before its turn | Reworded in `PLANS.md`: less than 30 seconds before every first-effect cut after establishment, measured inside the cut's writer turn; establishment samples just before its turn. |
| 7.5: two digest frames are constant today | `TestOperationalAdmissionDigestFramesItsConstantParts` asks the digest function directly: two inputs that differ only in the verifier's algorithm, or only in the configured policy's id and entry count, must not share a digest. Kills the audit's A-DG6 and A-DG7. |

## 5. Files touched

All 16 are inside the frozen scope of `05-repair.md` section 5 and inside the 26 paths already changed at `b6d2f77`. No path was added or removed. `A` is `es/admission`, `I` is `es/admission/internal/reliablesubmit`, `D` is `.docs/execution_lifecycle`. Line counts are against `b6d2f77`.

| Path | Kind | Lines | What |
| --- | --- | --- | --- |
| `D/es_execution_admission_model.md` | Document | +1 / -1 | Lock inventory row of `OperationalCustody.mu` names every holder and the read and write modes (A2-3). |
| `D/implementation.md` | Document | +1 / -1 | The 30 second sentence (O-11). |
| `D/reliable_submit_operational_handoff.md` | Owner document | +88 / -12 | Guard rules and limits (A2-1, A2-2, O-6, O-7, O-8), lock statements (A2-3), outcome table and the cancellation paragraph (A2-4, A2-8), stage residue (O-2). |
| `D/reliable_submit_persistence_and_concurrency.md` | Document | +7 / -3 | Lock sentences (A2-3). |
| `PLANS.md` | Plan | +40 / -5 | New status entry for this repair; O-10, O-13 and the Denied sentence. |
| `docs_contract_test.go` | Docs test | +171 / -3 | Phrase pins, the lock rule, the lock-holder comparison against the code, seventeen mutation cases. |
| `I/operational_admission.go` | Production | +7 / -1 | The admission write calls the COMMIT seam when it is set; comment on the read lock (A2-7, A2-3). |
| `I/operational_admission_test.go` | Store tests | +401 / -7 | A2-6, A2-7, P-1 and the two tests of the look at the context before COMMIT. |
| `I/operational_handoff.go` | Production | +4 / -0 | The field `admissionCommit` (A2-7). |
| `I/operational_handoff_test.go` | Store tests | +4 / -2 | Literal cap lengths (A2-5). |
| `A/reliable_submit_guardrails_test.go` | Guard tests | +179 / -19 | The gate counts dynamic dispatch; end-to-end interface probe (A2-2). |
| `A/reliable_submit_operational_admission.go` | Production | +3 / -1 | Comment only: which locks a confirmation holds (A2-3). |
| `A/reliable_submit_operational_admission_redteam_test.go` | Red team's tests | +5 / -1 | Comment only (O-5). Section 7.3. |
| `A/reliable_submit_operational_admission_test.go` | Admission tests | +376 / -4 | A2-8 test with its controls, the digest test (7.5), the fresh-delivery pin (A2-4). |
| `A/reliable_submit_operational_handoff.go` | Production | +33 / -4 | `withholdAt`, five edited sites and two proof hooks (A2-8). |
| `A/workstream_c_guardrails_test.go` | Guard tests | +572 / -70 | Conversion rule in both directions, `whole-instantiate`, dynamic dispatch, file-set check, overlay loader, self-tests, four field inventories (A2-1, A2-2, O-6, O-9). |

Against `b6d2f77`: production code +47 / -6 in 4 files; tests +1,708 / -106 in 7 files; documents +137 / -22 in 5 files.

## 6. Deviations, and what the auditor should know

1. **Withdrawal order (audit O-1, missing from the list in `05-repair.md` 11.4).** Withdrawal sets the local latch first and then makes the durable write. Design 5.3 says the write comes first. A failed write then leaves the process stopped and the call reports "not confirmed", which is the safer order. The owner document describes the code.
2. **A2-4 was resolved by scoping, not by changing the answer** (section 4.4).
3. **A2-8 changes six answers and keeps the stored run at one of them** (section 4.6). The audit's R8 named two windows; the store refuses every read and binding of an ended borrow, so the same reasoning applies at the four other points and I changed all six.
4. **Three production additions exist only for tests**: the `admissionCommit` field of the store's custody handle, and the hooks `beforeReceipt` and `beforeObservation` of the handoff. Each is nil in production. No function sets the field. The hooks sit in the struct the existing hooks sit in, which the domain constructor never fills.
5. **The guard counts more than R1 and R2 asked**: `whole-instantiate`, the interface exemption, the file-set check and four new field inventories. Each is described in section 4. None relaxes an existing inventory.
6. **A test context that bends the `context.Context` contract.** `operationalEndingContext` returns an error from `Err` while its `Done` channel is nil. A real context closes `Done` first. The double is used only in the two store tests of section 4.6, to end a context at an instant no real cancellation can be placed at deterministically (between two adjacent statements).
7. **Three live-context controls reach inside.** One changes the permission bits of the staging directory before the marker, as the existing drift test does. One changes the region the test provider answers for, for one call, so that an accepted receipt does not verify; the region is restored before the retry. One flips a byte of the domain's copy of the witness key before the observation is bound, so that the store's own check of the witness fails.
8. **Sites where no test reaches a failed step under a live context.** I measured it. A probe (`07-repair-evidence/scripts/r2-live-reach.py.txt`) adds a marker line at each of the six points of section 4.6, printed when the step has failed and the context is live, and runs the behavioural selection of `es/admission` once on a scratch copy of the commit (640 results, none failing). The selection reaches the row read once, the marker binding twice, the receipt verification once and the observation binding once. Each of these four points has a control in section 4.6. It never reaches a failed intent binding or a failed stage binding under a live context.

   I read why. At those two points the store refuses for an ended borrow, for an access that another call is using, for a projection that is not the access's current one at the expected revision, for a zero locator or project digest, for an intent that does not match the locator, and for a stage measurement that breaks the layout rules. Apart from the ended borrow, the handoff has established each of these itself just before: the access is used by one goroutine inside the borrow, the projection comes from that same access, the locator and the project digest are SHA-256 values, the intent was compared with the locator a few lines earlier, and the measurement function enforces the same layout rules (modes, owner, device, single link, sizes) before it returns. So under a live context these two bindings fail only if the store and its caller disagree, and a test cannot arrange that without changing production code.

   Consequence: the mutants `R2-INTENT-ALWAYS` and `R2-STAGE-ALWAYS` survive (section 9.1). Inference: they are equivalent to the code in every state the handoff can reach today. This rests on my reading and on one probe run, not on a proof. The production code still answers Integrity there under a live context, which is the audited behaviour, so a later change that makes one of these states reachable gets the stricter answer.
9. **`operationalAdmissionWriteCases` takes a context.** The `run` function of the shared write cases gained a context parameter so the new tests can pass their own. The three existing callers pass `context.Background()` as before.

## 7. Tests

### 7.1 Added

| Test | Package | Pins |
| --- | --- | --- |
| `TestOperationalAdmissionCancelledCallAnswersCanceled` (seven groups of endings and four controls under a live context, section 4.6) | admission | A2-8 |
| `TestOperationalAdmissionDigestFramesItsConstantParts` | admission | audit 7.5 |
| `TestOperationalGuardLoadsEveryProductionFile` | admission | O-6 |
| `TestTypedMethodReferenceInventoryCountsDynamicDispatch` | admission | A2-2 |
| Subtest "storage aliases added to the real packages" | admission | A2-1, end to end |
| Subtest "gated entries reached through an interface in the real packages" | admission | A2-2, end to end |
| 26 new whole-value self-test cases for conversions and instantiations: 22 that must be recorded and 4 controls | admission | A2-1 |
| 9 self-test cases for dynamic dispatch in `TestTypedMethodReferenceInventoryCountsDynamicDispatch` | admission | A2-2 |
| Four field inventories (`egsClient`, `trustModelVerifier`, `provenanceVerifier`, `admissionPolicyEvaluator`) | admission | O-9 |
| `TestOperationalAdmissionCommitAnswerLost` | store | A2-7 |
| `TestOperationalAdmissionStoredTimeAheadOfTheClock` | store | A2-7 |
| `TestOperationalAdmissionWriteRequiresCurrentStore` | store | A2-7 |
| `TestOperationalAdmissionWriteReadsBackBeforeCommit` | store | A2-7 (S-WR1r) |
| `TestOperationalAdmissionWriteLooksAtTheContextBeforeCommit` | store | A2-8, writer turn |
| `TestOperationalHandoffCutLooksAtTheContextBeforeCommit` | store | A2-8, writer turn |
| Foreign-match cases in `TestOperationalAdmissionTokenAtEveryCut` | store | P-1 |
| `operationalAdmissionLockRule`, the lock-holder comparison and seventeen new mutation cases in `TestOperationalSubmitHandoffCurrentAdmissionV2Contract` (six for the outcome table and the cancellation text, four for the lock statements, one for the lock row, six for the guard phrases) | root | A2-3, A2-4, A2-1 text |

### 7.2 Changed

| Test | Change | Stronger or weaker |
| --- | --- | --- |
| `TestPR12RetainedAdmissionCuts`, two fresh-delivery cases | Now require the reason Unavailable, no run, no receipt, zero claims and zero POSTs | Stronger |
| `TestOperationalHandoffV2CustodyStructure` | The two cap vectors use literal lengths | Stronger (pins the value) |
| `TestOperationalAdmissionPublishedSchema5ShapeRefused` | Specific refusal per opener; control opens with all four | Stronger |
| `TestOperationalAdmissionTokenAtEveryCut` | Foreign matches added at every cut | Stronger |
| Guard inventories in `workstream_c_guardrails_test.go` and `reliable_submit_guardrails_test.go` | New occurrence kinds; every earlier entry keeps its count | Stronger |
| Phrase pins in `docs_contract_test.go` | Follow the corrected sentences | Same strength, new text |

No test was removed, skipped or weakened.

### 7.3 The red team's file (`es/admission/reliable_submit_operational_admission_redteam_test.go`)

One change since `b6d2f77`, and it is a comment (audit O-5). Complete diff:

```diff
-// samples and so pins the later one on its own.
+// samples. Withdrawal is durable since the admission row exists, so the
+// store's own comparison in the establish turn refuses that delivery too and
+// this case does not pin the later sample on its own. The subtest "establish
+// gate/deadline passes between the two samples", where the row stays
+// enabled, does.
```

| Lines at `b6d2f77` | Change | Why | Effect on what the test proves |
| --- | --- | --- | --- |
| 291, the last line of the comment above `TestRedTeamPR13HoldsNoNewClaimAfterWithdrawal` | Comment text only: one line replaced by five | The comment claimed the case pins the later sample on its own. Since the admission row exists a withdrawal is durable, so the store refuses that delivery as well. | None. No assertion, fixture or control changed. The later sample is pinned by the subtest "establish gate/deadline passes between the two samples" of `TestOperationalAdmissionRunAssignmentCutAndEstablishGate`. |

The full table of every change to this file since the red team's commit `5ca4079` is in `05-repair.md` section 11.6 and `05-repair-redteam-test-changes.diff`; it is unchanged except for this row.

## 8. Validation

All runs are on Linux in this thread's container, Go 1.26.5, as an unprivileged user, on a copy of the tree with the one-file Linux overlay the store tests need (the audit's P-3; PR #14 carries the fix). The copy is made from the bytes named in each row.

| What | Exact command | Bytes | Result |
| --- | --- | --- | --- |
| Format | `gofmt -l` on the 11 changed Go files | working tree before the commit, and again the checkout of commit `c41e177` | no output, exit 0, both times |
| Whitespace | `git diff --check b6d2f77 c41e177` | commit `c41e177` | no output, exit 0 |
| Build | `go build ./...` | copy of tree `f8868837` | exit 0 |
| Vet | `go vet ./es/admission/ ./es/admission/internal/reliablesubmit/ .` | same copy | one report, `es/admission/result_auth_test.go:395:15` (copied lock). It is the audit's P-2: the same line at `e544e0f` and at `b6d2f77`, in a file this pull request does not change. |
| Full suite | `go test -count=1 -timeout 90m -json ./...`, alone on the machine | same copy | exit 1. 6,358 results: 6,151 pass, 166 fail, 41 skip. Packages: 19 pass, 2 fail, 20 without tests. |
| Race detector, store | `go test -race -count=1 -timeout 120m -json ./es/admission/internal/reliablesubmit/`, alone | copy of commit `c41e177` (same tree) | exit 1. 749 pass, 3 fail, 2 skip. No data race reported. 346 s. |
| Race detector, admission | `go test -race -count=1 -timeout 120m -json ./es/admission/`, alone | same copy | exit 0. 1,925 pass, 0 fail, 1 skip. No data race reported. 1,044 s. |

The tree id of the working tree was recorded before the runs (`f8868837ed8f363d47d80f0a94622f0163efb2ff`) and is the tree of the commit, so the suite ran on the committed bytes.

**The full suite against `b6d2f77`, by package and test name** (`07-repair-evidence/full-suite-compare.tsv`):

| | `b6d2f77` | `c41e177` |
| --- | --- | --- |
| Results | 6,204 | 6,358 |
| Pass | 5,997 | 6,151 |
| Fail | 166 | 166 |
| Skip | 41 | 41 |
| `es/admission` | 1,810 pass, 1 skip | 1,925 pass, 1 skip |
| Store package | 727 pass, 3 fail, 2 skip | 749 pass, 3 fail, 2 skip |
| Root package | 2,131 pass, 163 fail | 2,148 pass, 163 fail |

- No test went from pass to fail. No test changed its result at all.
- No test name is gone.
- 154 names are new (115 in `es/admission`, 22 in the store package, 17 in the root package) and all pass. Ten are new top-level tests.
- The 166 failures are the same 166 names at both tips: 16 top-level tests with their subtests. All 16 fail at `e544e0f` too, and none is in a file this pull request touches. Thirteen are in the root package (twelve Remote Alpha operator-script tests, and `TestTrackedGeneratedArtifactHygiene`, which needs `.git`). Three are in the store package and need a probe binary built from an older source tree: `TestOperationalHandoffSchema4BinaryRefusesSchema5`, `TestSQLiteV3OldBinaryRefusesWithoutMutation`, `TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation`. The audit lists the same environment failures as P-4.

**Focused runs while repairing.** After each change I ran only the tests the change touches, on scratch copies: the 78 tests of the four guard-related files, the new tests, and the docs contract tests. Those runs are superseded by the full suite above and are not listed one by one.

## 9. Mutants and probes

### 9.1 The audit's survivors and one mutant per new check: 31 of 33 killed, 2 survive and are explained

The spec is `07-repair-evidence/r2-mutants-spec.py.txt`. It holds, in the auditor's own form, the seven mutants the audit calls real gaps (S-CAP1, S-CAP2, S-WR2, S-WR3, S-WR4, A-Q8, S-Q3) and three of the audit's duplicates that a test can now tell apart (S-WR1r, A-DG6, A-DG7). It also holds one mutant for each check this repair adds.

**How a result is counted.** The runner (`07-repair-evidence/scripts/mutants-runner.py.txt`) applies one mutant to a scratch copy of commit `c41e177`, runs the package's behavioural selection and counts the leaf tests that fail with the mutant and pass without it. The selections are `-run 'TestOperationalAdmission|TestOperationalHandoff'` for the store package and `-run 'Operational|PR12|RedTeam'` for `es/admission`. Failures of the source inventories and guard tests are counted apart and never as a kill by behaviour. The last column shows one failing test; the output files list up to six.

| Mutant | Package | What it changes | Result | First failing test |
| --- | --- | --- | --- | --- |
| S-WR1r | store | audit: the row read back after the write is not compared | killed by 1 test | `TestOperationalAdmissionWriteReadsBackBeforeCommit` |
| S-WR2 | store | audit: a failed COMMIT of the admission write answers success | killed by 6 tests | `TestOperationalAdmissionCommitAnswerLost/advance/row_not_written` |
| S-WR3 | store | audit: the time clamp of the admission write is removed | killed by 1 test | `TestOperationalAdmissionStoredTimeAheadOfTheClock` |
| S-WR4 | store | audit: the admission write does not verify the store as current | killed by 3 tests | `TestOperationalAdmissionWriteRequiresCurrentStore/advance` |
| S-CAP1 | store | audit: the evidence cap is one byte larger | killed by 1 test | `TestOperationalHandoffV2CustodyStructure/over_cap` |
| S-CAP2 | store | audit: the evidence cap is doubled | killed by 1 test | `TestOperationalHandoffV2CustodyStructure/over_cap` |
| S-Q3 | store | audit (P-1): the fence does not require the match to be for the borrowed original | killed by 5 tests | `TestOperationalAdmissionTokenAtEveryCut/Assign` |
| A-Q8 | admission | audit: the qualification does not report a cancellation that arrives during the evaluation | killed by 1 test | `TestOperationalAdmissionCancelledCallAnswersCanceled/during_the_evaluation/after_establishment` |
| A-DG6 | admission | audit: the digest does not frame the verifier's algorithm | killed by 1 test | `TestOperationalAdmissionDigestFramesItsConstantParts/verifier_algorithm` |
| A-DG7 | admission | audit: the digest does not frame the configured policy's id and entry count | killed by 1 test | `TestOperationalAdmissionDigestFramesItsConstantParts/configured_policy_id_and_entry_count` |
| R2-MATCH-CLAIM | store | the match comparison ignores the claim | killed by 5 tests | `TestOperationalAdmissionTokenAtEveryCut/Assign` |
| R2-MATCH-BINDING | store | the match comparison ignores the plan binding | killed by 5 tests | `TestOperationalAdmissionTokenAtEveryCut/Assign` |
| R2-MATCH-WITNESS | store | the match comparison ignores the witness | killed by 5 tests | `TestOperationalAdmissionTokenAtEveryCut/Assign` |
| R2-MATCH-DIGEST | store | the match comparison ignores the digest | killed by 5 tests | `TestOperationalAdmissionTokenAtEveryCut/Assign` |
| R2-SEAM-IGNORED | store | the COMMIT seam is never called | killed by 9 tests | `TestOperationalAdmissionCommitAnswerLost/advance/row_not_written` |
| R2-WR-CTX | store | the admission write does not look at the context before COMMIT | killed by 3 tests | `TestOperationalAdmissionWriteLooksAtTheContextBeforeCommit/advance` |
| R2-CUT-CTX | store | the cut's writer turn does not look at the context before COMMIT | killed by 4 tests | `TestOperationalHandoffCutLooksAtTheContextBeforeCommit/Assign` |
| R2-HINT-NOT-CANCELED | admission | pre-check: an ended context at the row read answers Unavailable (the audited behaviour) | killed by 3 tests | `TestOperationalAdmissionCancelledCallAnswersCanceled/while_EGS_answers_the_confirmation/after_establishment` |
| R2-HINT-ALWAYS-CANCELED | admission | pre-check: a failed row read always answers Canceled | killed by 1 test | `TestOperationalAdmissionCancelledCallAnswersCanceled/while_EGS_answers_the_confirmation/control:_an_unreada...` |
| R2-WITHHOLDAT-NEVER | admission | `withholdAt` never answers Canceled (the audited behaviour at three bindings) | killed by 5 tests | `TestOperationalAdmissionCancelledCallAnswersCanceled/at_every_freshness_sample/after_establishment` |
| R2-WITHHOLDAT-ALWAYS | admission | `withholdAt` always answers Canceled | killed by 1 test | `TestOperationalAdmissionCancelledCallAnswersCanceled/control:_a_staged_tree_that_drifted_before_the_marker_...` |
| R2-INTENT-SITE | admission | intent binding: an ended context answers Integrity | killed by 3 tests | `TestOperationalAdmissionCancelledCallAnswersCanceled/at_every_freshness_sample/after_establishment` |
| R2-STAGE-SITE | admission | stage binding: an ended context answers Integrity | killed by 1 test | `TestOperationalAdmissionCancelledCallAnswersCanceled/before_the_staged_tree_is_bound_to_the_stamp` |
| R2-MARKER-SITE | admission | marker binding: an ended context answers Integrity | killed by 1 test | `TestOperationalAdmissionCancelledCallAnswersCanceled/before_the_marker_is_bound` |
| R2-RECEIPT-SITE | admission | receipt verification: an ended context answers Integrity | killed by 1 test | `TestOperationalAdmissionCancelledCallAnswersCanceled/before_an_accepted_receipt_is_verified` |
| R2-INTENT-ALWAYS | admission | intent binding: a failure always answers Canceled | **survives** |  |
| R2-STAGE-ALWAYS | admission | stage binding: a failure always answers Canceled | **survives** |  |
| R2-MARKER-ALWAYS | admission | marker binding: a failure always answers Canceled | killed by 1 test | `TestOperationalAdmissionCancelledCallAnswersCanceled/control:_a_staged_tree_that_drifted_before_the_marker_...` |
| R2-RECEIPT-ALWAYS | admission | receipt verification: a failure always answers Canceled | killed by 1 test | `TestOperationalAdmissionCancelledCallAnswersCanceled/control:_an_accepted_receipt_that_does_not_verify_is_a...` |
| R2-OBS-NOT-CANCELED | admission | observation binding: an ended context answers Integrity and withholds the run (the audited behaviour) | killed by 1 test | `TestOperationalAdmissionCancelledCallAnswersCanceled/before_a_completed_observation_is_bound` |
| R2-OBS-ALWAYS-CANCELED | admission | observation binding: a failure always answers Canceled and keeps the run | killed by 1 test | `TestOperationalAdmissionCancelledCallAnswersCanceled/control:_an_observation_that_does_not_bind_is_an_integ...` |
| R2-OBS-WITHHOLDS-RUN | admission | observation binding: a cancellation withholds the stored run | killed by 1 test | `TestOperationalAdmissionCancelledCallAnswersCanceled/before_a_completed_observation_is_bound` |
| R2-FRESH-DENIED | admission | a refused first delivery answers Denied | killed by 2 tests | `TestPR12RetainedAdmissionCuts/fresh_ordinary_policy_denial` |

**The two that survive.** `R2-INTENT-ALWAYS` and `R2-STAGE-ALWAYS` make a failed intent binding or a failed stage binding answer "cancelled" under a live context too. No test reaches a failed binding at these two points while the context is live, and by my reading no state the handoff can reach does (section 6, item 8). The other half of each point is pinned: `R2-INTENT-SITE` (an ended context answers Integrity there) is killed by 3 tests and `R2-STAGE-SITE` by 1. The same "always cancelled" mutation at the four other points is killed, each by its control under a live context.

**History, stated because the first pass was not clean.** The first pass had 28 mutants, and 13 of its admission mutants ran against the new tests only and not against the whole behavioural selection. 25 were killed and 3 survived, each a check of mine with no test under a live context or between two statements: `R2-WR-CTX` (the admission write's look at the context before COMMIT), `R2-WITHHOLDAT-ALWAYS` and `R2-OBS-ALWAYS-CANCELED` (a failed binding answers "cancelled" under a live context too). I then added five tests: the two store tests of section 4.6 and the three live-context controls at the marker, the receipt and the observation. I also added five mutants: `R2-CUT-CTX` for the cut turn's look, and one "always cancelled" mutant for each of the intent, stage, marker and receipt points. That makes 33.

Two things went wrong on the way and are fixed. `R2-CUT-CTX` survived its first run because the name of my new test did not match the runner's selection for the store package; I renamed the test and it is killed by 4 tests. And the receipt point had no control under a live context until the probe of section 6, item 8 showed that no test reached it; the control was added before the commit.

The table above is one complete pass on the committed bytes with the behavioural selection of each package. The outputs of the first pass and of the reruns are in `07-repair-evidence/first-pass/`.

### 9.2 The 18 mutants of the new guard rules

Each weakens the guard's own code in a scratch copy and runs the guard tests. A mutant counts as caught only when a guard test fails.

The runner is `07-repair-evidence/scripts/guard-mutants-runner.py.txt` with `guard-mutants-extra.py.txt`. The guard selection is the eight guard and inventory tests of `es/admission`, the two new ones included. Without a mutant it passes (331 results). The last column is the number of leaf tests that fail.

| Mutant | What it weakens in the guard | Result | Guard tests that fail |
| --- | --- | --- | --- |
| G2-OPERAND | conversion: the operand side is ignored (the rule audited at b6d2f77) | caught | 18 |
| G2-OPERAND-PTR | conversion: a pointer operand is ignored, a by-value operand still counts | caught | 16 |
| G2-OPERAND-VAL | conversion: a by-value operand is ignored, a pointer operand still counts | caught | 2 |
| G2-TYPEPARAM | conversion: a type parameter result is treated as an interface | caught | 1 |
| G2-INTERFACE | conversion: a conversion to an interface is recorded too | caught | 2 |
| G2-INST | instantiation is not recorded | caught | 11 |
| G2-INST-HOLDS | instantiation: only a pointer or container argument counts | caught | 7 |
| G2-INST-CONTAINS | instantiation: only a by-value argument counts | caught | 3 |
| G-WC | whole values: a conversion is not recorded at all | caught | 25 |
| G2-DISPATCH | method inventories ignore dynamic dispatch (the rule audited at b6d2f77) | caught | 28 |
| G2-DISPATCH-DECL | dynamic dispatch: an interface that declares the method is not counted | caught | 12 |
| G2-DISPATCH-USE | dynamic dispatch: a selection through an interface is not counted | caught | 6 |
| G2-DISPATCH-ID | dynamic dispatch: any interface method counts, whatever its name | caught | 6 |
| G2-DISPATCH-CONCRETE | dynamic dispatch: a method of the same name on a concrete type counts | caught | 6 |
| G2-DISPATCH-STORE | store member inventories ignore dynamic dispatch | caught | 5 |
| G2-FILES-GO | file set: a Go file no target builds is accepted | caught | 2 |
| G2-FILES-OTHER | file set: assembly, C and object files are accepted | caught | 3 |
| G2-FILES-UPPER | file set: the extension is compared with its case | caught | 1 |

18 of 18 are caught. `G2-OPERAND` and `G2-DISPATCH` restore the rules as they were at `b6d2f77`, so these two rows also show that the new self-tests fail on the audited guard. Output: `07-repair-evidence/final-pass/guard_mutants.out`.

### 9.3 The audit's end-to-end probes on the new bytes

The runner (`07-repair-evidence/scripts/r2-probes-runner.py.txt`) reads the string constants of the auditor's two probe sources (`06-audit-evidence/guard-probe-sources/run2.py.txt` and `run3.py.txt`) as data, applies each to a scratch copy of the tree, checks that the copy still builds, and runs the guard tests.

| Probe | What it does | Result at `b6d2f77` (audit) | Result now |
| --- | --- | --- | --- |
| Baseline | no change | passes | passes |
| Control | the installed view rewritten by name | caught | caught |
| GM1 | the installed view rewritten through a pointer conversion | **not caught** (A2-1) | **caught**, 2 guard tests fail |
| GM2 | the Service latches cleared through a pointer conversion of the receiver | **not caught** (A2-1) | **caught**, 1 guard test fails |
| P1 control | commissioning called by name from the private handoff path | caught | caught |
| P1 | commissioning, advance and withdrawal called through an interface | **not caught** (A2-2) | **caught** |
| P2 control | a latch write in a new file without a build tag | caught | caught |
| P2 | the same file behind a custom build tag | **not caught** (O-6) | **caught** |
| P3 | `*a.service = admission.Service{}` written in `es/app` | not caught (O-7) | not caught: the named limit of the owner document (package scope) |

Each probe built (`go build ./...` exit 0) before the tests ran. This is the run on commit `c41e177`. Output: `07-repair-evidence/final-pass/r2_probes.out`. A first run before the commit gave the same nine results (`first-pass/r2_probes.out`).

### 9.4 The earlier 173 mutants on the new bytes

All 173 mutants of `05-repair.md` section 11.8 ran once more, on commit `c41e177`. Each has exactly one result.

| Group | Mutants | At `b6d2f77` | At `c41e177` |
| --- | --- | --- | --- |
| `es/admission`, production code | 90 | 85 killed by behaviour, 5 survive | the same |
| Store, production code | 23 | 22 killed by behaviour, 1 survives | the same |
| Schema and triggers | 17 | 17 killed by behaviour | the same |
| The guard weakened | 32 | 32 caught by guard tests | the same |
| Production changes the guard must refuse | 11 | 11 caught by guard tests | the same |

- **No verdict changed.** The six survivors are the same six: `F2g-limit-inclusive`, `F2b-never-confirmed-accepted`, `C5-content-trust-validity-unchecked`, `C5b-digest-ignores-canonical-error`, `T1b-callback-returns-stored-token` and `GO-advance-where`. Each disables one of two checks that refuse the same fault. `05-repair.md` section 11.8 gives the neighbour and the pair for each, and the audit agreed with all six (`06-audit.md` section 7.3).
- **Kills by behaviour.** The runner prints the number of failing tests. No mutant is killed by fewer tests than at `b6d2f77`. Ten are killed by more. For nine of them the names the runner lists show subtests of the new cancellation test; inference: those are the added failures. The tenth is `GO-write-no-lock` (2 before, 4 now): the two extra failures are racing subtests whose result depends on scheduling, as `05-repair.md` section 11.8 describes, and its timing-independent killer `NoWriteOutcomeWaitsForTheWriterTurn` fails in both passes.
- **Kills by guard tests.** For these the runner prints at most six failing names and no number. 35 of the 43 list fewer than six in at least one pass, and their names are the same in both passes with one exception, `G26` (next point). For the other 8 I can only say that at least six guard tests fail in both passes.
- **Two mutants were re-anchored.** `G7-whole-convert-not-listed` and `G26-pointer-conversion-not-listed` change lines of the guard that this repair rewrote, so their anchors no longer matched and the first launch reported both as "anchor found 0 times". I re-anchored both with the same weakening: `G7` still removes the recording of a conversion, and `G26` still makes the result side of the conversion rule ignore pointers and containers. Both are caught. `G26` is caught by 2 guard tests where it was caught by 3. The third case, a conversion of `[]Service` to a named slice type, is now recorded through its operand as well, so weakening the result side alone no longer hides it. The spec as it was at `b6d2f77` is kept beside the current one (`scripts/adm-mutants-spec.b6d2f77.py.txt`).
- **The pass ran in two launches.** A tool limit stopped the first launch after 30 minutes. The second launch ran exactly the mutants the first had not reported, on the same bytes. `scripts/build-tables.py.txt` fails if a mutant is missing or is reported in two files.

Outputs: `07-repair-evidence/final-pass/`. The account of the pass at `b6d2f77` is `07-repair-evidence/pass-b6d2f77/account.json`.

## 10. Failed or skipped validation

**Failed, and why it does not block.**

- Full suite: 166 failing results, the same 166 names as at `b6d2f77` (section 8). They are twelve Remote Alpha operator-script tests, one test that needs a `.git` directory in the tested copy, and three store tests that need a probe binary built from an older source tree, each with its subtests.
- Race detector, store package: the same three store tests fail for the same reason. No data race is reported.
- `go vet`: one report in `es/admission/result_auth_test.go`, a file this pull request does not change.

**Skipped or not run.**

- macOS: nothing was run on a Mac.
- GitHub CI: none runs on this pull request. Its merge commit does not contain the workflow of PR #14.
- 41 tests skip themselves in the full suite, the same 41 as at `b6d2f77`: 38 in `es/app` that need Docker, Nomad or Vault, and 3 helper-process tests that only run as a child of another test.
- The race detector ran on the two changed packages, not on the whole repository.
- The full suite ran once, on the working tree before the commit. I did not run it again after the commit, because `git write-tree` before the run gave the commit's tree id, so the bytes are the same.
- Two mutants survive without a test that tells them apart (section 9.1), and two earlier mutants had to be re-anchored (section 9.4).
- The store package's tests compile on Linux only with the one-file overlay (`07-repair-evidence/store-test-linux-overlay.patch`, the audit's P-3). The overlay is applied to every scratch copy and is not part of the commit.

## 11. Dependencies, hygiene, widening, cross-repo impact

- **Dependencies:** none changed. `go.mod` and `go.sum` are untouched.
- **Artifact hygiene:** no generated file, binary, database or log is in the commit. The staged set equals the manifest's path list (section 12).
- **Sensitive material:** none read, printed or copied. Tests use keys generated in their fixtures and temporary SQLite files. The evidence folder holds source paths, hashes, test names, test output and scripts. No personal contact detail appears in this report or its evidence.
- **Authority, security or protocol widening:** none. No new caller of any gated entry, no new exported symbol, no schema change, no change to the wire or to a public API. The six changed answers of section 4.6 replace one refusal reason by another; at one of them a cancellation now keeps a stored run that it withheld before, which is the rule the two neighbouring points already follow.
- **Model identifiers:** none in the commit body, in code comments or in the pull request text. The commit carries the required co-author trailer.
- **Cross-repo impact:** none. Only `evo-agi/Execution-Substrate` was touched.
- **PR #14 and PR #12:** not touched. When PR #12 picks up `trunk_dev`, the list line for `TestOperationalHandoffSchema4BinaryRefusesSchema5` still has to be added there, as noted before.

## 12. Provenance

| Item | Value |
| --- | --- |
| Recipe | `governed-execution.audit-patch-manifest.v2` |
| Recipe source SHA-256 | `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked before every run. The recipe file was not edited. |
| Base-relative manifest | SHA-256 `f198dedd7913a187eff6a2048fb315ae7961073dfef7831fc45b682133bc1cb5`, 26 files. Head `8058561edc08356c46680c204586b3c7796c0ff3`, upstream pinned to `origin/codex/reliable-submit-operational-handoff-v1`. |
| Base-relative textual diff | SHA-256 `eb989a9432c8077f7e36255c83c9e4b4c477dc5d68a677ef6b9b93b0f5d038da` |
| Repair-only manifest, against the audited tip `b6d2f77` | SHA-256 `468b34852d4a175cf04edcaead7dde4815c7a00d2c6adfe77855189e95d7057a`, 16 files. Head `b6d2f7787ec8254134cb48fcae0da72bac0fd02c`, upstream `origin/claude/project-thread-sqldt7`. |
| Repair-only textual diff | SHA-256 `304c6d751dd8633af081e778db3ba0780a6bcdd84e80d0f148998e161277cca7` |
| Taken twice | Each manifest was written twice into a fresh mode-0700 directory outside the repository, and the two files are byte-identical. Both manifests were taken before the commit and again after the push, and those files are byte-identical too. |
| Staged-set check | Before the commit, `git add -A` staged exactly the 16 paths of the repair-only manifest, and `git write-tree` gave `f8868837ed8f363d47d80f0a94622f0163efb2ff`, the tree the full suite had run on. After the push, with the index reset to the base, `git add -A` staged exactly the 26 paths of the base-relative manifest; with the index reset to `b6d2f77`, exactly the 16 paths of the repair-only manifest. |
| Clean status | `git status --porcelain` was empty after the commit and again after the manifests were taken. The local branch equals `origin/claude/project-thread-sqldt7` at `c41e177f0d264318de3d799d8b28e7f494b18c74`. |
| Push | Fast-forward `b6d2f77..c41e177`, no force. |

How the manifests were taken (operating protocol 5.5): record the tip, `git reset --mixed` to the base, pin the upstream, run the recipe twice, `git reset --mixed` back to the tip. The working tree is never changed by this.

The 26 base-relative paths are the same 26 as at `b6d2f77`: this repair adds no path and removes none.

Complete canonical manifest, base-relative. The block is the file's exact content (one line and a final newline, 5,883 bytes):

```json
{"branch":"claude/project-thread-sqldt7","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/es_execution_admission_model.md","sha256":"a0e6356b08fad47734228a3984ad3f7f5f0dfaee58efb653c4242c66338ea4a3","size":101212},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/implementation.md","sha256":"24a09851c0c9e3c59228a87bfba849d4d349bb435c7b2510fd4ea9830bf3cf29","size":91503},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_operational_handoff.md","sha256":"8696b80d20f46995e47a0291266d2c2c48d2a5f669ed1aae2b450e2019d76c6f","size":105687},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md","sha256":"fac1952edf4ed6d8a90445645851a49b6882ca6efb52182460bb63988147feed","size":166857},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md","sha256":"17d6ea3808063559ec9ae63d0c764d6db4c7a9d3bb0f2fe401d1f698daaff208","size":105872},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/system_overview/boundaries.md","sha256":"13ae36c014ffe3407f75a52a464d3988ed4880d00ea9e3a69e4da9626aeb97a8","size":73385},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"74dd6b8fd9ecddaa92db319a55753348cbb0defa7a8eddfb906fbdfbb0589e47","size":317483},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"d8d4edaab42d253f640cfba872ab9f80acb401bec357b65ef0c99cfecc1ba502","size":844228},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/operational_admission.go","sha256":"713d629f0e24b65028096390ad04a0985fd4475d44a98937cc04333148d1c3de","size":13288},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/operational_admission_test.go","sha256":"6e3f33ee5234fbb35cfde4c4313c59dadb3330198544d9a492b1d70918a80bb5","size":78663},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/operational_handoff.go","sha256":"e38ecdcbe199a7423f93348d5ffe6206b32e414f1b75a8a6dbcc0c976fad9bb3","size":63434},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/operational_handoff_test.go","sha256":"0f666893e5f3164c54839eb9bc90d969f895623c7a4a187c779ac1f652538b8f","size":54589},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_structure.go","sha256":"4adcd21ae2396edddd4c552c9fdd5c53b5d61ab56c718573b0985089e5f16ed7","size":19440},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_operational_handoff_schema.go","sha256":"0414016c73ee268a4a14de340cf57fab132ac7d27737a3df8a606cfe8480e74f","size":38102},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_shape.go","sha256":"710668283d3d8075a43c445bda729f35798fa30ccaf88c6aabaffb5a8afb85e7","size":2878},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_guardrails_test.go","sha256":"ff20adaead401ed460a03bccd81ae39c8b88fbec4c119259b33bc7dad35f1fa7","size":90967},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/reliable_submit_operational_admission.go","sha256":"7296d796923ca2b09b1632118a0c0bd302f7b1d199f318e4a123ab8d8d53dd67","size":20582},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/reliable_submit_operational_admission_redteam_test.go","sha256":"8e8bd35644759a06710ce50cc5b0619bbfd7bc5ce46ddfefe84e30f717486062","size":41265},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/reliable_submit_operational_admission_test.go","sha256":"9a72a268bc7cfe919a669abf41356f78c675db4c1a552b76e99f7bd44ce92eb1","size":158554},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_format.go","sha256":"7a0a2128c9412917a400a05eeae6d3650417584042b87e25f333ec108aa1d2dd","size":10157},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_format_test.go","sha256":"2813c540ca0639fbe873cfbb83f6626fd2307def62c737f149d959d5ae5aa8c7","size":31600},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_handoff.go","sha256":"81a23f367716bcd5e50165a1327d2466adf162944a380969fecbfce3b2be882f","size":27411},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_handoff_test.go","sha256":"30bfa1a2090285e74a4e20639b6d5a581d0363e41966e5a8d61b3d8b8b06103d","size":61862},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/resolved_execution_plan.go","sha256":"449dedaaf284bb3798f897b93c42ef282dcebe2c553e7318ffaf7a72e75c7ef0","size":28834},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/service.go","sha256":"317be6476f82f7214ed1d00282acd6779271ddd2d6f20922783800bbc3ef64a7","size":36030},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/workstream_c_guardrails_test.go","sha256":"966a1be837fe4cee370cb99b339ef3886f1686ec0ee5cc057cd4c9489d5d72d7","size":393050}],"head":"8058561edc08356c46680c204586b3c7796c0ff3","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"eb989a9432c8077f7e36255c83c9e4b4c477dc5d68a677ef6b9b93b0f5d038da","upstream":"origin/codex/reliable-submit-operational-handoff-v1"}
```

Complete canonical manifest, repair-only against `b6d2f77` (3,746 bytes):

```json
{"branch":"claude/project-thread-sqldt7","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/es_execution_admission_model.md","sha256":"a0e6356b08fad47734228a3984ad3f7f5f0dfaee58efb653c4242c66338ea4a3","size":101212},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/implementation.md","sha256":"24a09851c0c9e3c59228a87bfba849d4d349bb435c7b2510fd4ea9830bf3cf29","size":91503},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_operational_handoff.md","sha256":"8696b80d20f46995e47a0291266d2c2c48d2a5f669ed1aae2b450e2019d76c6f","size":105687},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md","sha256":"fac1952edf4ed6d8a90445645851a49b6882ca6efb52182460bb63988147feed","size":166857},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"74dd6b8fd9ecddaa92db319a55753348cbb0defa7a8eddfb906fbdfbb0589e47","size":317483},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"d8d4edaab42d253f640cfba872ab9f80acb401bec357b65ef0c99cfecc1ba502","size":844228},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/operational_admission.go","sha256":"713d629f0e24b65028096390ad04a0985fd4475d44a98937cc04333148d1c3de","size":13288},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/operational_admission_test.go","sha256":"6e3f33ee5234fbb35cfde4c4313c59dadb3330198544d9a492b1d70918a80bb5","size":78663},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/operational_handoff.go","sha256":"e38ecdcbe199a7423f93348d5ffe6206b32e414f1b75a8a6dbcc0c976fad9bb3","size":63434},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/operational_handoff_test.go","sha256":"0f666893e5f3164c54839eb9bc90d969f895623c7a4a187c779ac1f652538b8f","size":54589},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_guardrails_test.go","sha256":"ff20adaead401ed460a03bccd81ae39c8b88fbec4c119259b33bc7dad35f1fa7","size":90967},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_admission.go","sha256":"7296d796923ca2b09b1632118a0c0bd302f7b1d199f318e4a123ab8d8d53dd67","size":20582},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_admission_redteam_test.go","sha256":"8e8bd35644759a06710ce50cc5b0619bbfd7bc5ce46ddfefe84e30f717486062","size":41265},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_admission_test.go","sha256":"9a72a268bc7cfe919a669abf41356f78c675db4c1a552b76e99f7bd44ce92eb1","size":158554},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_handoff.go","sha256":"81a23f367716bcd5e50165a1327d2466adf162944a380969fecbfce3b2be882f","size":27411},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/workstream_c_guardrails_test.go","sha256":"966a1be837fe4cee370cb99b339ef3886f1686ec0ee5cc057cd4c9489d5d72d7","size":393050}],"head":"b6d2f7787ec8254134cb48fcae0da72bac0fd02c","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"304c6d751dd8633af081e778db3ba0780a6bcdd84e80d0f148998e161277cca7","upstream":"origin/claude/project-thread-sqldt7"}
```

## 13. Assumptions, unresolved seams, uninspected areas

**Named limits of the guard, as the owner document lists them.** Aliases; called functions and methods; reflection, `unsafe` and cgo (their imports are inventoried); the three build targets; the two packages (probe P3); SQL statements assembled at run time for the table-writer inventory. The typed guard is a search over source forms and not a proof. The red-team pass on the combined PR #12 is the planned place to push further.

**Assumptions.**

- No persistent schema-5 reliable-submit database of the old shape exists on David's Mac or on the Linux box. I did not look. If one exists it is refused unchanged on open, and the test of section 4.5 pins that for all four openers.
- Linux only. macOS behaviour of the changed code was not run. The typed guard loads the darwin/arm64 target, so the inventories cover the darwin file set.

**Not done, and why.**

- The cut turn's and the admission write's looks at the context are pinned with a test double, not with a real cancellation, because no real cancellation can be placed between two adjacent statements deterministically (section 6, item 6).
- No test reaches a failed intent binding or a failed stage binding under a live context (section 6, item 8). The Integrity answer of those two points under a live context is read, not tested.
- The new rules of the docs contract test are covered by their own 17 mutation cases, which change the document text and require the rule to fail. I ran no further mutants against that test's code.
- Nothing was run on macOS, and no GitHub CI runs on this pull request (section 10).

**Uninspected.** Nothing outside the 26 changed paths was read for this repair, except ordinary resolution's error types (for A2-4), the SQLite driver's handling of a context (for the two store tests), and the stage measurement in `es/admission/staging_custody.go` and the job projection in `es/admission/reliable_submit_operational_provider.go` (for section 6, item 8).

## 14. Confidence

- **Provenance: high.** Manifests were taken twice before the commit and twice after the push, byte-identical each time; the staged set equalled the manifest's path list; the remote tip is the commit.
- **Validation: high on Linux, not established on macOS.** The full suite, the race detector on the two changed packages, 224 mutant runs (the earlier 173, the 33 of this repair and the 18 guard mutants) and the nine probes all ran on the committed bytes. 216 of the 224 are caught. The 8 that survive are the six duplicate checks the audit agreed with and two of mine, which I explain by reading and not by a test.**
- **Implementation: high for the store tests and the cancellation rule, medium to high for the guard.** Both of the audit's escapes are caught end to end and 18 of 18 mutants of the new rules are caught. A guard of this kind can still have a form I did not think of.

## 15. Report delivery

This file: `/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/07-repair.md`. Its SHA-256 is in the thread reply that attaches it. Evidence: `07-repair-evidence/` in the same folder:

- `README.md`: this list.
- `r2-mutants-spec.py.txt`: the 33 mutants of this repair: the audit's survivors and one per new check.
- `final-pass/`: the complete mutant pass on commit `c41e177`: `r2_store.out`, `r2_adm.out` (33), `guard_mutants.out` (18), `fin_*.out` (the earlier 173), `r2_probes.out` (the audit's probes), `r2_live_reach.out`, the tables built from them, the comparison with the pass at `b6d2f77`, and the id lists of the two launches.
- `first-pass/`: the first pass of the 28 mutants and the reruns after each added test, with the first probe and live-reach runs, all before the commit.
- `pass-b6d2f77/account.json`: the account of the 173 mutants at `b6d2f77`, as delivered with `05-repair.md`.
- `full-suite-compare.tsv`: every test result of the full suite at `b6d2f77` and at `c41e177`, by package and name.
- `race-summary.txt`: the race detector runs on the two changed packages.
- `manifests/`: the two canonical manifests (base-relative and repair-only), the recipe's output for each, and the staged path lists.
- `redteam-file-b6d2f77-to-c41e177.diff`: the complete diff of the red team's test file since the audited tip (a comment).
- `store-test-linux-overlay.patch`: the one-file overlay the store tests need to compile on Linux (not part of the commit).
- `scripts/`: the runners and specs as text files: the mutant runner, the specs of the earlier 173 (current and as at `b6d2f77`), the schema mutant runner, the guard mutant runner, the probe runner, the live-reach probe, the two launch scripts of the final pass, the table builder, the run comparison, and the two helper scripts that copy the tree and run a command as an unprivileged user.

## 16. Effect status

`TOPIC_BRANCH_PUSHED` (`claude/project-thread-sqldt7` at `c41e177f0d264318de3d799d8b28e7f494b18c74`) | `DRAFT_PR_OPENED` https://github.com/evo-agi/Execution-Substrate/pull/13 (existing draft, description updated) | `MERGE_NOT_PERFORMED` | `INDEPENDENT_AUDIT_NOT_PERFORMED`

No push to any other branch. No force-push. No comment or review posted. PR #12, PR #14 and the closed PR #15 were not touched.

STATUS: READY
