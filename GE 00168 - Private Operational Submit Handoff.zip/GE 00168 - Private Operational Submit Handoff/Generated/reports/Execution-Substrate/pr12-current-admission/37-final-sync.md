# PR #12's final `trunk_dev` sync (`5d6ad51`) and check 36's note I36-1, on draft PR #47

Status of this file: **SYNC REPORT, NOT CHECKED.** It covers the three commits after `f7bb1d6`, the head that combined check 36 (`36-combined-check.md`) and the final red-team re-check (`36-redteam-recheck.md`) cleared. The coordinator asked for this at 05:08Z and 05:23Z: take up `trunk_dev` once PR #46 had landed, add check 36's Info note I36-1, get a diff-only check, then gate and merge.

Written by the PR #13 writer thread on 2026-11-24 (UTC).

---

## 1. In plain words

1. **I36-1.** The row of `CP-NOMAD-ACL` in the owner contract's commissioning table now also says where the provider's token comes from: the one ES loads from `nomad.token_file` at startup for the current submit client. A pin and a Missing mutant hold the clause. Until now only a prose paragraph said it.
2. **`trunk_dev` `5d6ad51`** (PR #44 and PR #46) is merged in, with no conflict. None of its four files is a path of PR #12, and PR #12's 70 paths against `trunk_dev` are unchanged.
3. **The owner reconciliation and the `PLANS.md` entry** now name PRs #44 and #46 among the `trunk_dev` PRs this round takes up. The `PLANS.md` sentence with the 70-file ceiling is rewrapped, and its pin follows.
4. Nothing else changes. No Go code outside `docs_contract_test.go` changes, and nothing under `es/` changes except what PR #44 brings.

## 2. Identity

| Item | Value |
| --- | --- |
| Head | `7324b62968ee4c93b5d8e4fe71532c7d7c51f383`, tree `ca8f4ca71672959dd25c9573c2452309c75b0fcf` |
| Previous head (checked) | `f7bb1d67a1ef1d2882a2f04e2d8aa62e8457cb04` |
| `trunk_dev` | `5d6ad513add57a3bd69e8956c32090e343d4f82d` (PR #46), the merge base |
| Base (PR #12's branch) | `99a66256be1b238d5bd5487a9926abe044f03028`, unchanged |
| Commits | `26fb3a3` I36-1; `ac0d11a` merge of `trunk_dev` `5d6ad51`; `7324b62` names PRs #44 and #46 |
| Scope | the same 70 paths against `trunk_dev` |

## 3. For the diff-only check

- `git diff f7bb1d6 7324b62`, leaving out the four files PRs #44 and #46 bring (`es/admission/internal/reliablesubmit/replay_key_use_sqlite_test.go`, `scripts/internal/remote_alpha_spire_agent.py`, `scripts/remote_alpha_spire_agent_test.go`, `.docs/system_overview/remote_supported_host_alpha.md`), is 3 files, +15/−11: the owner contract, `PLANS.md` and `docs_contract_test.go` (`commits/round-only.diff`).
- The merge `ac0d11a` is git's own: `git merge-tree --write-tree 26fb3a3 5d6ad51` gives `4429e6e9b0bfb7d12940d661baca0c1264243693`, the merge commit's tree (`commits/merge-check-ac0d11a.txt`).
- Between the `trunk_dev`-relative manifests at `f7bb1d6` and at `7324b62`, only those three files differ.

## 4. Validation

Linux, Go 1.26.5, clean clones run as user `ci` with an emptied environment (`scripts/val35.sh`). All **Ran**.

| Check | Result at `7324b62` |
| --- | --- |
| build and vet, linux/amd64, linux/arm64, darwin/arm64 | ok, all three |
| `gofmt -l` | `trunk_dev`'s own six files only |
| Blob-read guard | 3 pass, 0 fail |
| Root docs pins | 10 pass, 0 fail |
| `-race` on the Nomad, provider and driver-string tests of `es/admission`, and on `OperationalLocatorShape` | ok (68.6 s), ok |
| Whole module against `trunk_dev` `5d6ad51` | 7,498 results in both, **0 changed**. 2,175 new: 2,173 pass, the same 1 skip and 1 fail as at `f7bb1d6` (the child-process helper, and the probe-binary test on CI's environment-only list). 0 gone. Top-level failures 28 and 29, the extra one being that probe test |
| Whole module against the run at `f7bb1d6` | 9,627 results in both, **0 changed**. New: `MissingNomadACLTokenCustody` (the new mutant), PR #46's `TestRemoteAlphaSPIREAgentTakeNewDirRefusesSwaps`, and 44 randomly named subtests; 44 such subtests gone. Top-level failures identical |

CI on PR #47: run [45333412400](https://github.com/evo-agi/Execution-Substrate/actions/runs/45333412400) of `build, vet and test`, success on `7324b62` (05:27Z to 06:13Z).

## 5. Provenance manifests

Recipe v2 (source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked before each run), clean tree at the pushed tip, each run twice and byte-identical, path set equal to the staged set, staged tree equal to the tip's tree.

| Manifest | Reset target | Files | Textual diff SHA-256 | Manifest SHA-256 |
| --- | --- | --- | --- | --- |
| `trunk_dev`-relative | `5d6ad51`, `origin/trunk_dev` | 70 | `f70c716da37e3632f4a7d5fa2792d34a3f81b1cd4459237b1d786f92dad48cc3` | `1a56860c8bf8f406ef347fa74b7abd6ebff085b534647f047ec49bdcbfe6bd3e` |
| PR-relative | `99a6625`, `origin/codex/reliable-submit-operational-handoff-v1` | 92 | `47dbb1e8cf31b4b4c65a373d432530a66b64a099cf91ea5c7a1578671736e4e5` | `3f04d2bfc00f4f83537d558cdb964be99df762b95c7a4ee9a077348df9995eb0` |

Against the manifests at `f7bb1d6`: the `trunk_dev`-relative one changes in the three files above only; the PR-relative one gains `replay_key_use_sqlite_test.go` (PR #44) and changes in those three files and PR #46's three.

## 6. Evidence

`37-final-sync-evidence/` with `SHA256SUMS`: the two commits as patches, the merge's summary and merge-tree check, the round-only diff, both manifests twice, the runs, and the scripts.

## 7. Effects

- Pushed `26fb3a3`, `ac0d11a` and `7324b62` to `claude/project-thread-ne9cwa-pr12-trunk-dev` at 05:25:14Z, a fast-forward from `f7bb1d6`, no force. `26fb3a3`'s message was reworded once before that push; it had not been pushed.
- This report and its evidence.
- Not changed: PR #12's branch, `trunk_dev`, `main`.
