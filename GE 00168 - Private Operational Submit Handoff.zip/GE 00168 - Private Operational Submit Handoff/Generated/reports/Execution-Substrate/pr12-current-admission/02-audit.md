# INDEPENDENT AUDIT REPORT

**Execution-Substrate draft PR #13: PR #12 current-admission recheck fix**
Audit date 2026-11-22 (UTC). Auditor: Claude, fresh audit thread, not the writer of this patch.

**Final verdict: BLOCK**

---

## 0. Decision summary

Read this section first. Everything after it is the evidence.

1. **The bytes are the bytes.** The provenance manifest reproduced exactly, twice at the start and twice at the end. The PR head on GitHub is the audited commit.
2. **I found no hole in the production code.** On the exact bytes, a retried v2 handoff cannot reach a run assignment, an intent, a stage, a stamp, a marker or a provider POST without passing the retained admission check. I confirmed this three ways: by reading the code, by 9 scratch behaviour probes at every cut, and by 7 deliberate breakages of the check that the existing suite caught.
3. **The fix's own regression tests do not pin the property at two of the cuts it exists to protect.** I deleted the admission check for the run-assignment cut (the first durable write after a claim is established) and the whole `es/admission` test package still passed. The same is true for the establish gate. So a later refactor could silently reopen PR #12's finding at those cuts with a green suite. This is the main blocker (AF-1).
4. **One governing-document rule is broken.** The patch creates a new "Temporary compatibility edge" (v1 originals) without the reason and removal condition that `AGENTS.md:117` requires (AF-5).
5. **The rest is small.** Eleven low-severity items, mostly documentation that says slightly more than the code does, plus a few assertions that cannot fail. They should be fixed in the same repair.
6. **Why BLOCK and not REJECT or ACCEPT.** The approach is sound and I would not redo it, so not REJECT. The priority in this project is correctness over speed, the previous audit of this same candidate was stopped for a test-guard gap, and this gap is in the central property, so not ACCEPT. The repair is bounded: new tests (my probes show each one is feasible), documentation corrections, and two or three very small code touches. Then a fresh audit.
7. **One question is for the owner, not the writer.** "Current admission" in this fix means "the trust and policy snapshot this process took when it was commissioned, plus a local off switch". It never re-reads trust or evidence from the other services. The documents say this openly, so it is not a defect, but it is a design choice the owner should confirm (section 5.5).

Blocking findings: **AF-1** (medium), **AF-5** (medium). Everything else is low or an observation.

Risk context: this code path has no production caller. Nothing commissions the private authority outside tests, so nothing in this report describes a live exposure.

---

## 1. Repository and audit target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Pull request | #13, open, draft, 1 commit, 19 files, +3157 / -89 (read from GitHub at close) |
| Base ref | `codex/reliable-submit-operational-handoff-v1` (PR #12 branch) |
| Base SHA | `8058561edc08356c46680c204586b3c7796c0ff3` |
| Topic branch | `claude/project-thread-sqldt7` |
| Topic commit | `e544e0fbe4220dfdd2c2068e3267dcfa454a0cf9` |
| Tree | `7be20ba8a71f0f55490aaac2eb8aed5601386830` |
| Recipe | `governed_execution_audit_patch_manifest_v2.py`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (matches the pinned value) |
| Canonical manifest SHA-256 | `21d19775bbe7c2d9aef0752d7a9f5b315734b7bf6f8f313197357dfc71cd7907` (4,334 bytes) |
| Changed paths | 19 |
| Textual diff SHA-256 | `84ca50e683502119b399077745f3480024a06bd3d5f16e329287fc93173f23aa` |
| Writer report | `reports/Execution-Substrate/pr12-current-admission/01-implementation.md`, SHA-256 `36c2eca93ff8b47d1527cddaa3d95a3946e74ea50ca6b48fe5ef5a81a52466b2` (verified) |

Remote refs at close (2026-11-22T04:03Z): topic branch `e544e0f`, PR #12 branch `8058561`, `trunk_dev` `ae326b0`. PR #12's head is not an ancestor of `trunk_dev`.

## 2. Audit posture

- Strictly read-only. No edit to the target, no commit, no push, no PR comment, no repair, no formatting.
- Parent plus four read-only subagents, none forked from this thread: contract and authority, correctness and state semantics, test adequacy, security and filesystem and process. All four delivered. No subagent reported a critical or high finding.
- I did not coordinate with the parallel red-team thread and did not read its output.
- Mutation testing and behaviour probes ran only in separate scratch worktrees. The provenance clone was never modified. The probe file and the mutation script are audit artefacts, not part of the target.
- No live service was contacted. GitHub was read only (PR metadata, refs).

## 3. Provenance reproduction

Procedure (provenance rules §5.3): fresh clone, check out the topic commit, reset `HEAD` to the base while keeping the tip bytes in the working tree, pin upstream to `origin/codex/reliable-submit-operational-handoff-v1`, run the v2 recipe twice into a private 0700 directory.

| Check | Result |
| --- | --- |
| Recipe bytes | SHA-256 matches the pinned value |
| Upstream of the clone | `origin/codex/reliable-submit-operational-handoff-v1`, not `trunk_dev` |
| Status entries | 19 |
| Opening run 1 and run 2 | byte-identical, SHA-256 `21d19775…7907` |
| Against the writer's manifest line | byte-identical |
| Closing run 1 and run 2 (after all audit work) | byte-identical to opening, SHA-256 `21d19775…7907` |
| Tolerated mode-bit differences | none needed |
| PR head on GitHub | equals the audited commit |

Result: provenance holds. No `AUDIT_PROVENANCE_MISMATCH`.

Candidate lineage, checked because the brief mentions it: I rebuilt the Codex candidate from the recovered review packet (packet SHA-256 `aeb65b370020022aae6e9b7a3e6eea03b129146e2916e49a22109f5afbfdfeae`) and got tree `433b4891a0e413aff2b0eb6adf316a033a544a24`, as the writer states. Of the 19 files, 14 are byte-identical to the tip, including **every production Go file**. The writer's own changes are confined to 5 files: the owner document, `PLANS.md`, `docs_contract_test.go`, `reliable_submit_operational_admission_test.go` and `workstream_c_guardrails_test.go`. So the production logic audited here is the Codex candidate's, unchanged.

## 4. Coverage

**Governing documents read at the tip (by the parent, the contract pass, or both):** `AGENTS.md`, `PLANS.md` (2026-11-22 and 2026-11-20 entries), `.docs/execution_lifecycle/reliable_submit_operational_handoff.md` (owner document), `es_execution_admission_model.md`, `reliable_submit_persistence_and_concurrency.md`, `submit_idempotency_correlation_and_recovery.md`, `.docs/system_overview/boundaries.md`, each diffed against the base.

**Production source read in full at the tip:** `es/admission/reliable_submit_operational_admission.go` (new), `reliable_submit_operational_handoff.go`, `reliable_submit_operational_format.go`, `resolved_execution_plan.go`, `service.go` (changed regions and their callers), `internal/reliablesubmit/replay_custody_structure.go`, and the unchanged `internal/reliablesubmit/operational_handoff.go` writer and release logic that the fix relies on.

**Tests read (the test-adequacy pass in full, the parent for every test cited in a finding):** `reliable_submit_operational_admission_test.go`, `reliable_submit_operational_format_test.go`, `reliable_submit_operational_handoff_test.go`, `reliable_submit_guardrails_test.go`, `workstream_c_guardrails_test.go` (classifier and inventories), `internal/reliablesubmit/operational_handoff_test.go`, `docs_contract_test.go` (new v2 contract tests).

**Schemas and migrations:** none changed. Schema 5, codec 5 and scope 3 are unchanged; the only wire change is the new provenance variant literal `operational_local_v2` and its opaque evidence leaf.

**Scripts, configs, examples, binaries:** none among the 19 paths. No secret material or binary in the diff.

**Explicitly not inspected or not exercisable here:** macOS and the native Ubuntu arm64 target; Docker, Nomad and Remote Alpha operator-host paths; the historical probe binaries needed by three old-binary refusal tests; any live stack. The candidate-classifier negative control the writer reports ("24 of 31 fail on the candidate classifier") was not re-run; I replaced it with my own classifier mutants (section 6.3).

## 5. Findings

Line numbers refer to the tip `e544e0f`. "Handoff" means `es/admission/reliable_submit_operational_handoff.go`. "Admission" means `es/admission/reliable_submit_operational_admission.go`. "Owner doc" means `.docs/execution_lifecycle/reliable_submit_operational_handoff.md`.

### 5.1 Summary

| ID | Severity | Kind | One line |
| --- | --- | --- | --- |
| AF-1 | medium | patch defect, tests | Run-assignment cut, establish gate and two in-writer checks are not pinned by any behavioural test |
| AF-5 | medium | patch defect, contract | New v1 Temporary compatibility edge has no reason or removal condition (`AGENTS.md:117`) |
| AF-2 | low | patch defect, tests | Commissioning snapshot properties (policy equality, trust deep copy, installation binding) unpinned |
| AF-3 | low | patch defect, tests and docs | Classifier claims for type assertions and "unclassified" unpinned; three write forms are classified as reads and not named as limits |
| AF-4 | low | patch defect, contract | Owner doc promotes schema 5 to "Current invariant" and drops the reopened-seam row |
| AF-6 | low | patch defect, docs vs code | Cancellation loses to "unavailable" when both apply; the doc says cancellation returns Canceled |
| AF-7 | low | patch defect, docs vs code | Result reports only the last writer; an applied intent is not reported when the next writer is refused in the same call |
| AF-8 | low | patch defect, docs | "Policy changed, retry refused, then completes" contradicts the doc's own rule that a policy change needs a new epoch; stranding of old-epoch claims is not stated |
| AF-9 | low | patch defect, docs vs code | A stamped but unmarked v2 retry returns the run under a denying authority, while the doc says denial withholds it |
| AF-10 | low | patch defect, code | Unreachable 403 branch and a new per-request marshal on the ordinary public Prepare/Submit path |
| AF-11 | low | patch defect, tests | Assertions that cannot fail in `TestOperationalAdmissionCaptureIsSameResolution` |
| AF-12 | low | patch defect, code and tests | "Do not make a new v1" guard is unpinned; the encoder silently falls back to v1 on an empty record |
| O-1 to O-9 | observation | mixed | Listed in 5.3 |

### 5.2 Patch defects

```text
AUDIT FINDING
ID / Type / Severity: AF-1 / test adequacy for the property the patch exists to add / medium
Current contract or strategic target:
  Owner doc 345-348: "each run/intent writer, pre-stage checked writer, stamp writer and
  first-marker writer ... checks complete current admission on that same original."
  Owner doc 238-239: "First-effect authorization also requires ... current execution admission
  at each stage and marker boundary." Audit brief: the recheck is required at every
  first-effect cut.
Path and line:
  Handoff 205, 215 (establish presence checks); 267-276 (qualify closure); 291 (revision-1
  pre-check); 302 (assign writer); 343 (unmarked pre-check); 355 (intent writer).
  Tests: reliable_submit_operational_admission_test.go 85-185 and 1058-1115.
Evidence:
  - TestPR12RetryAfterPolicyChange seeds only revision 2 and revision 3 (lines 1065-1066).
    TestPR12RetainedAdmissionCuts seeds only at intent (operationalSeedIntent). No test seeds
    a retry at revision 1 (claim established, no run yet) under any denial.
  - All six TestPR12RetryAfterPolicyChange subtests are refused by the same statement
    (handoff 343), so they prove one check, not one check per cut.
  - Mutant S1 (skip the admission qualifier whenever the claim is at revision 1) SURVIVES the
    complete es/admission package: 1,379 passes, 0 failures, plus the 3 slow inventory tests.
  - Mutant S2 (both establish authority checks removed) SURVIVES the complete package.
  - Mutants S3a and S3b (assign and intent writers given a match-only callback with no
    admission) are caught by no behavioural test. They trip only a call-site inventory, and
    only because my mutant text adds a direct call. A mutant that weakens the closure itself
    (S1) is caught by nothing.
  - The behaviour on the tip is correct: my scratch probes pass on the unmodified tip and kill
    S1, S2, S3a and S3b (section 6.2 and 6.3).
Impact:
  No defect today. The regression guard is missing exactly where PR #12's finding lived: a
  later change can drop admission at the run-assignment cut or the establish gate and the
  suite stays green. Under S1 a denied retry writes a run assignment (revision 1 to 2) before
  the next cut stops it.
Required correction:
  Add maintained tests (R1 in section 7). Acceptance check: S1, S2, S3a and S3b must each be
  killed by a behavioural assertion, not only by an inventory.
Uncertainty:
  None about survival (I ran it). The mutants are single-site; combinations were not tried.
Patch defect or pre-existing issue: patch defect (the tests are new in this patch).
```

```text
AUDIT FINDING
ID / Type / Severity: AF-5 / contract and authority / medium
Current contract or strategic target:
  AGENTS.md:117: "If a change touches a Temporary compatibility edge, the reason, scope, and
  removal condition must remain documented."
Path and line:
  Owner doc 382-388; es_execution_admission_model.md 63-64 and the section 4C table at 532.
Evidence:
  The patch declares "An operational_local_v1 original remains a Temporary compatibility
  edge." Scope is documented (reads only, cannot advance). No reason and no removal condition
  are given anywhere, and the edge is absent from the section 4C "Temporary compatibility edge
  metadata" table, whose columns include Reason and Removal condition for every other edge.
  PR #12 is unmerged and has no commissioning caller, so no v1 original can exist outside
  test fixtures (Inference from: PR #12 head is not an ancestor of trunk_dev; zero non-test
  commissioning references are enforced by inventory).
Impact:
  A permanent compatibility path is being created for data that does not exist, without the
  exit condition the repository's top-authority document demands.
Required correction:
  Either document reason, scope and removal condition in the owner doc and add the row to
  section 4C, or remove v1 acceptance before PR #12 merges. Which one is an owner decision;
  my recommendation is in section 5.5.
Uncertainty: none on the text. Whether to keep v1 at all is a design choice.
Patch defect or pre-existing issue: patch defect.
```

```text
AUDIT FINDING
ID / Type / Severity: AF-2 / test adequacy / low
Current contract or strategic target:
  Owner doc 298-307: the authority "deep-copies trust lists, provenance verifier key bytes and
  validated built-in policy entries"; a non-nil evaluator "must be an exact supported
  admissionPolicySet"; commissioned for one installation identity and epoch.
Path and line: Admission 83 (policy entry equality), 144 (trust deep copy), 177-178
  (installation and epoch binding).
Evidence:
  S4 (entry equality ignored, so an injected literal-deny set that differs from configuration
  is accepted) SURVIVES. S5 (shallow trust copy) SURVIVES. S6a (installation ignored) is caught
  only by the syntactic reference inventory, by no behavioural test. S6b (epoch ignored) is
  caught behaviourally. A probe shows the tip behaves correctly for both realm mismatches.
Impact: three documented commissioning properties can regress unnoticed.
Required correction: R2 in section 7.
Uncertainty: verifier key copy and policy entry clone were not mutated by me.
Patch defect or pre-existing issue: patch defect.
```

```text
AUDIT FINDING
ID / Type / Severity: AF-3 / test adequacy and documented limits (the writer's own delta) / low
Current contract or strategic target:
  Owner doc 333-341: a write "applied through a selector, index, slice, type assertion or
  dereference chain rooted at the field is a write-through access. None of these is a read; an
  unresolved selection in such a chain is unclassified and fails the inventory. Called
  functions and methods are not analyzed beyond Go's implicit address-of."
Path and line: es/admission/workstream_c_guardrails_test.go 3422-3450 and 3522.
Evidence:
  S7a (type-assertion step removed from the classifier) SURVIVES. S7b ("unclassified" returned
  as "read") SURVIVES. So two sentences of the documented guarantee have no test.
  A probe of residual forms on the tip classifier gives "read" for: a channel send on the field
  (s.value <- 1), an append into a reslice of the field (append(s.value[:0], 1)), and an
  element write through a conversion (ints(s.value)[0] = 1). close() and a subfield write
  through a type assertion are correctly "write-through". Alias-then-write is "read", which
  the doc already excludes.
Impact:
  The guard is syntactic by design, so this is not a safety hole. The documented limit names
  only "called functions and methods"; append is a builtin like copy, clear and delete, which
  are handled, so a reader would expect it to be covered.
Required correction: R3 in section 7.
Uncertainty: I did not re-run the writer's "24 of 31" negative control.
Patch defect or pre-existing issue: patch defect.
```

```text
AUDIT FINDING
ID / Type / Severity: AF-4 / contract classification / low
Current contract or strategic target:
  AGENTS.md:50: "Do not treat a Reopened redesign seam as settled architecture."
  PLANS.md (2026-11-22 entry) still calls this work a "Bounded slice rule refinement on the
  reliable-submit Reopened redesign seam".
Path and line: Owner doc 7-8, compared with base lines 7-8.
Evidence:
  Base: "Current invariant | Published PR #11 is schema 4 ..." and "Selected target |
  Re-derivation of the reliable-submit Reopened redesign seam ... Independent source
  acceptance and native qualification are separate later gates."
  Tip: "Current invariant | Published PR #12 is schema 5 ..." and a "Bounded slice refinement"
  row. The "Selected target" row is deleted. The phrase "Reopened redesign seam" occurs 1 time
  in the base owner doc and 0 times at the tip. PR #12 is an open, unmerged pull request.
Impact:
  The owner doc now labels an unmerged schema as a Current invariant while the higher-authority
  plan still holds the seam open. Row 8 does keep the candidate status visible and lines
  1084-1085 still name the later gates, which is why I rate this low.
Required correction: R5 in section 7.
Uncertainty:
  "Published" is used in PLANS.md to mean pushed, not merged, so the row is arguably literal
  truth. The contract subagent rated this higher (see 5.4).
Patch defect or pre-existing issue: patch defect.
```

```text
AUDIT FINDING
ID / Type / Severity: AF-6 / outcome mapping, docs versus code / low
Current contract or strategic target: Owner doc 363-366: "... returns value-free
  OperationalUnavailable ...; cancellation returns OperationalCanceled."
Path and line: Handoff 500-507 (reconcile) and 624-630 (final sender entry).
Evidence:
  Reconcile returns Unavailable at 501-502 before the cancellation test at 505. Sender entry
  tests admission identity at 624-627 before the request context at 628. When a call is both
  cancelled and unavailable, the result is Unavailable. The owner doc's entry list (358-361)
  names context first. The writer disclosed this ordering.
Impact: fail-closed either way; only the reported reason differs from the document.
Required correction: state the precedence in the owner doc, or reorder; pin it with a test.
Uncertainty: none.
Patch defect or pre-existing issue: patch defect (new branches).
```

```text
AUDIT FINDING
ID / Type / Severity: AF-7 / outcome mapping, docs versus code / low
Current contract or strategic target: Owner doc 367-369: "Preserve the exact prior operation
  and write disposition: denial after an acknowledged intent, stamp or marker does not erase
  the write."
Path and line: Handoff 278-283 (refused wrapper) and the stamp writer at 418.
Evidence (probe TestAuditProbeSameCallWriteThenDenial, fresh submit, withdrawal injected):
  - before prestage: result operation=Intent, write=Applied, revision 3. Prior write reported.
  - at the stamp writer: result operation=Stamp, write=Refused, revision 3, one stage entry.
    The intent applied in the same call is not reported.
  - before marker: result operation=Stamp, write=Applied, revision 4. Prior write reported.
Impact: durable state is correct and nothing is erased. The returned (operation, write) pair
  is a single slot, so the middle case does not "preserve the prior operation".
Required correction: say in the doc that the result reports the last attempted writer, or
  carry the prior applied disposition; pin whichever is chosen.
Uncertainty: none.
Patch defect or pre-existing issue: patch defect in the new doc text; the single slot itself
  is pre-existing.
```

```text
AUDIT FINDING
ID / Type / Severity: AF-8 / contract premise / low
Current contract or strategic target:
  Owner doc 312-314: "Trust, verifier or policy replacement requires a new qualified epoch and
  withdrawal of old effect-enabled processes." Owner doc 50-51: "Older epochs cannot obtain
  new first-effect permission." Owner doc 376-380: "A retry after a changed configured literal
  policy, artifact revocation or signer revocation is refused at its first remaining cut ...
  a later retry under an allowing authority still completes, so a denial does not poison the
  claim."
Path and line: test helper operationalProofService, admission test 59-74.
Evidence:
  The helper builds a second Service with changed trust or policy and commissions it for the
  same installation and the same epoch (f.domain.realm). That is the replacement the doc says
  requires a new epoch. In a conformant deployment the scenario in lines 376-380 cannot occur.
  The epoch is bound into the original, and a probe shows an epoch mismatch gives Unavailable
  with no effect. Inference: after a conformant trust or policy change, every unmarked claim
  from the old epoch can never start. The exact result for a new-epoch domain was not probed.
Impact:
  The tests are still valid as defence in depth. But the document describes a recovery
  ("still completes") that the document's own rules forbid, and it does not state the real
  consequence: revocation by epoch change strands in-flight unmarked claims.
Required correction: R6 in section 7.
Uncertainty: the stranding statement is an inference from the doc and one probe.
Patch defect or pre-existing issue: patch defect (new text and new tests).
```

```text
AUDIT FINDING
ID / Type / Severity: AF-9 / disclosure, docs versus code / low
Current contract or strategic target: Owner doc 363-365: an unavailable or denied current
  authority "returns value-free OperationalUnavailable and withholds run/receipt".
Path and line: Handoff 340-342 (identical logic at base line 314).
Evidence (probe TestAuditProbeStampedUnmarkedRetry): a v2 claim at revision 4 (stamped, no
  marker) retried under an allowing, an absent, a literal-denying and a withdrawn authority
  returns Pending and discloses the same run in all four cases. State is unchanged and no
  admission check runs. The v1 branch at 337-339, by contrast, withholds.
Impact: no effect and no new write; the run id goes to the same authenticated caller that owns
  the claim. The new doc sentence is broader than the pre-existing branch.
Required correction: decide the policy (withhold, or document the exception) and pin it.
Uncertainty: none on behaviour.
Patch defect or pre-existing issue: pre-existing branch, patch defect in the new doc claim.
```

```text
AUDIT FINDING
ID / Type / Severity: AF-10 / dead code on a public path / low
Current contract or strategic target: ordinary unkeyed Prepare and Submit are a Current
  invariant (owner doc 7); the patch says the carrier "is inert for ordinary Submit".
Path and line: es/admission/service.go 463-470.
Evidence: the ordinary resolution path now marshals the full evidence record on every request
  and has a new 403 return if marshalling fails. Inference from reading the evidence v1 types
  (no raw JSON, floats, interfaces, channels, functions or custom marshalers): that marshal
  cannot fail, so the 403 branch is unreachable and untested.
Impact: a small per-request cost and an untestable error path on the public surface.
Required correction: remove or justify the branch; note the added marshal in the owner doc.
Uncertainty: the "cannot fail" claim is an inference from the types, not a proof.
Patch defect or pre-existing issue: patch defect.
```

```text
AUDIT FINDING
ID / Type / Severity: AF-11 / assertions that cannot fail / low
Path and line: es/admission/reliable_submit_operational_admission_test.go 1029-1043.
Evidence: "legacy := original.resolved; legacy.provenanceRecord = ''" then DeepEqual of
  original.resolved.plan against legacy.plan compares a value with its own copy. The next
  check converts a Go string to a byte slice, flips a byte, and asserts the string did not
  change; a string conversion always copies.
Impact: the test name promises isolation properties that these lines do not test.
Required correction: replace with assertions that can fail (for example compare against an
  independently resolved plan), or delete them.
Uncertainty: none.
Patch defect or pre-existing issue: patch defect.
```

```text
AUDIT FINDING
ID / Type / Severity: AF-12 / unpinned guard and silent fallback / low
Current contract or strategic target: Owner doc 296: "do not make a new v1."
Path and line: Handoff 21-22 (compose guard, resolved.provenanceRecord == "");
  es/admission/reliable_submit_operational_format.go 113-122.
Evidence: mutant S10 (compose guard for an empty record removed) SURVIVES the complete
  package. The encoder defaults to "operational_local_v1" and switches to v2 only when the
  record is non-empty, so without the guard a new v1 original would be written silently.
Impact: latent. The only thing between a missing record and a new v1 original is an untested
  guard.
Required correction: add a test that composing with an empty record refuses; preferably make
  the encoder refuse instead of falling back.
Uncertainty: none.
Patch defect or pre-existing issue: patch defect.
```

### 5.3 Observations and pre-existing issues

None of these is blocking. They are recorded so the next reader does not rediscover them.

| ID | Class | Statement |
| --- | --- | --- |
| O-1 | patch, by design | A retained record whose signature no longer verifies under the commissioned verifier returns `OperationalIntegrity`, not `OperationalUnavailable` (Admission 287-290). Consistent with the doc's "contradictory authenticated evidence", and verifier replacement needs a new epoch anyway. |
| O-2 | patch | `operationalAdmissionSnapshot` does not embed the `privateExecutionValue` redaction marker that `preparedArtifact`, `resolvedExecution` and `verifiedOperationalOriginal` carry. It holds trust lists and a public key, no secret. Redaction of the other three was verified by the security pass. |
| O-3 | patch | The establish writer has no in-writer admission callback, only presence checks at Handoff 205 and 215 after ordinary admission in the same call. The next writer re-qualifies, so a change in that window is caught before any second write. |
| O-4 | patch, docs | The new `boundaries.md` section "PR #12 private admission ownership" sits before the document's reading guide and carries none of the boundary labels that guide defines. |
| O-5 | patch, docs | "Denial does not poison the claim" (owner doc 380) is true for a pre-stage denial. After staging, a denial leaves charged stage residue and the claim can complete only if the same epoch's authority allows it again (pre-existing mechanism; the doc mentions residue at 370). Scope the sentence. |
| O-6 | patch | The 256 KiB evidence cap is written twice: a named constant at Admission 19 and a literal at `replay_custody_structure.go:469`. Both have over-cap test vectors (verified). A single shared constant would remove drift risk. |
| O-7 | patch | Redundant layers: mutants S8a and S8b (pre-checks), S9 (post-COMMIT release recheck for non-marker writers) and S15 (pre-marker presence check) survive because an adjacent check catches the same denial. These are defence in depth, not gaps. |
| O-8 | pre-existing | `internal/reliablesubmit` tests do not compile on Linux at base or tip (`Stat_t.Mode` width, `replay_custody_file_test.go:1210,1214`); PR #14 fixes it. `go vet` reports a copied lock at `result_auth_test.go:395`. Three old-binary refusal tests need probe binaries not present here. |
| O-9 | pre-existing | The qualify callback type is not sealed, so correctness depends on every caller passing the right closure (which is why AF-1 matters). Key id whitespace handling is not uniform: `evidencev1.Verify` and `service.go:736,936` trim, while the trust check at Admission 291 receives the seal key id untrimmed (subagent observation; impact not established). `Handoff 614` re-checks a key flag that construction at 107 already guarantees. |

Also noted, no action: the `PLANS.md` 2026-11-20 entry calls the repair "unstaged"; the 2026-11-22 entry above it supersedes that with "committed draft-PR candidate", which is accurate.

### 5.4 Subagent findings rejected, downgraded, or preserved as disagreement

| Claim | Disposition | Reason |
| --- | --- | --- |
| Contract pass: the status row is a medium-severity misstatement because "published" implies merged | Downgraded to low (AF-4). Disagreement preserved; it is interpretive. | `PLANS.md` uses "published at 8058561" to mean pushed. Row 8 and lines 1084-1085 keep the candidate status visible. |
| Security pass: negative vectors for the evidence cap are missing | Rejected | Over-cap vectors exist at both layers: admission test line 254 and `TestOperationalHandoffV2CustodyStructure` "over cap". I verified both. Kept only the duplicated constant (O-6). |
| Test pass: documentation tests are "presence only" | Not adopted as a defect | Phrase-presence plus doc-mutant tests are this repository's existing convention for `docs_contract_test.go`. |
| State pass: a denied claim after staging is "permanently stuck" | Narrowed (O-5, AF-8) | It is stuck only while the same epoch's authority keeps denying; the mechanism is pre-existing. |
| All passes: no route to a non-Accept durable write, stage creation or POST without qualification | Adopted | Matches my own reading, the probes and the positive-control mutants. |

### 5.5 Target-level question for the owner

This is a design choice, not a finding. I state it so it is decided on purpose.

**What "current admission" means in this fix.** The retained check verifies the stored signed evidence against a snapshot of trust lists, the verifier key and the built-in policy set that the process copied when it was commissioned, plus a local, one-way withdrawal switch. It deliberately does not re-read trust from EGS, evidence from ARS, vault configuration or runtime profiles; the documents say so (owner doc 348-354, admission model 59-64). Consequences:

- A revocation published after a process is commissioned takes effect in that process only when someone withdraws it and commissions a new epoch.
- There is no production caller for commissioning or withdrawal yet.
- By the doc's own rule, claims from the old epoch that had not reached their marker can then never start (AF-8).

For trust, verifier and policy the retained check is equivalent to what ordinary admission would decide with the same snapshot. The omissions are sanctioned by the current documents.

My recommendation: accept this meaning for the private, unwired proof, because running a network resolver inside a SQLite writer was excluded on purpose, and require the documents to say it in one plain sentence along with the stranding consequence. Revisit it when the path gets a real commissioning caller.

**Keep or delete v1 (AF-5).** No v1 original exists outside fixtures. My recommendation: keep the read-only v1 branch for now with a written removal condition ("remove before the first installed commissioning, or at the next schema change, whichever comes first"), because deleting v1 changes PR #12's custody grammar and widens this repair.

## 6. Validation assessment

Environment: Linux x86_64 cloud container, user root, Go 1.26.5. All runs on the exact tip bytes in a scratch worktree at `e544e0f` unless stated.

### 6.1 Commands re-run

| Command | Result |
| --- | --- |
| `go build ./...` | exit 0 |
| `gofmt -l` on the changed Go files | clean |
| `git diff --check 8058561 e544e0f` | clean |
| `go test -count=1 ./es/admission/` | 1,382 pass, 0 fail, 3 skip |
| `go test -count=1 ./...` at tip | 4,727 pass, 245 fail, 49 skip |
| `go test -count=1 ./...` at base | 4,559 pass, 247 fail, 49 skip |
| Tip failures that do not also fail at base | **0** |
| `internal/reliablesubmit` with only PR #14's Linux test-compile fix overlaid in a scratch worktree | tip 670 pass, 3 fail, 2 skip; base 663 pass, 3 fail, 2 skip; the same 3 failures |
| `go vet ./...` | only the 2 pre-existing issues in O-8 |
| `go test -race -count=1 ./es/admission/` | ok in 347.8 s, 0 data races |

The three skips in `es/admission` are a child-process sentinel and two fixtures that rely on unreadable files, which root can read.

Every tip failure is environment-only and identical in kind at base: 34 top-level `TestRemoteAlpha*` tests (this container has no `ssh` or `uuidgen`), 3 `es/app TestSupportedLocalExecutionRoot*` tests (they refuse to run as root), and the `internal/reliablesubmit` test build failure on Linux. All 115 non-Remote-Alpha root tests pass, including the four new `…CurrentAdmissionV2…` documentation tests.

Difference from the writer's report: the writer counts 170 failures, I count 245. The totals agree (5,021 results) and the difference is entirely the Remote Alpha tests, which fail in larger numbers here because of the missing tools.

### 6.2 Behaviour probes (audit-only, scratch)

Probe source: `02-audit-evidence/audit-probes_test.go.txt`, SHA-256 `889c68ecf6e47520f447107e5a11bcab4941f4cf05bb8b88c40a8d5c8e699904`. All pass on the unmodified tip.

| Probe | What it shows on the tip |
| --- | --- |
| Revision-1 retry under literal denial, artifact revocation, signer revocation, absent authority, withdrawal | Unavailable, no run disclosed, state unchanged at revision 1. A later allowed retry reaches revision 6 with exactly 1 POST. |
| Fresh submit on a withdrawn authority | No claim, no grant, no POST. |
| Assign writer and intent writer, denial at the in-transaction evaluation | Write refused, revision unchanged. |
| Assign writer and intent writer, denial at the post-COMMIT release evaluation | Write stays committed and is reported as applied with release failed; run withheld; no further effect. |
| Marker writer, denial in transaction | Revision stays 4, no marker, 0 POSTs. |
| Installation mismatch and epoch mismatch | Unavailable, no effect. |
| Same-call write then denial | See AF-7. |
| Stamped but unmarked retry | See AF-9. |
| Classifier residual forms | See AF-3. |

### 6.3 Mutation testing (audit-only, scratch)

35 single-site mutants, defined in `02-audit-evidence/mutants.py.txt` (SHA-256 `3b0921c75fb2e331d9258b00bf6e29d108754ebd3d346084f26eacac66b68102`). Pass 1 ran the whole `es/admission` package except three slow inventory tests (and `internal/reliablesubmit` for mutants in that package). Pass 2 ran those three tests on every pass-1 survivor. Pass 3 ran my probes on selected survivors. Raw output: `02-audit-evidence/probe-and-mutation-output.txt`.

**Positive controls, all killed (the suite does detect a broken check at the cuts it covers):**

| Mutant | Killed by |
| --- | --- |
| P1 qualifier forced positive | 16 failures including every `TestPR12RetryAfterPolicyChange` subtest |
| P2 policy decision ignored | `TestPR12RetainedAdmissionCuts`, `TestPR12RetryAfterPolicyChange` |
| P3 trust model skipped | same two |
| P4 signature verification skipped | `TestOperationalRetainedAdmissionEvidenceV2` |
| P5 refusal wrapper made a no-op | `TestPR12RetryAfterPolicyChange` |
| P6 final sender entry check removed | `TestOperationalAdmissionWithdrawalCuts` |
| P7 evidence binding always true | `TestOperationalRetainedAdmissionEvidenceV2` (12 subtests) |

**Other mutants killed by a behavioural test:** S3c prestage, S3d stamp writer, S3e marker writer (match-only callbacks); S6b epoch ignored; S11a and S11b `Initialize` guards (S11a by a nil-pointer panic in the test, not by an assertion); S12 v1 branches; S14 reconcile branch; S16 final re-sample in the qualifier; S17 exact re-encode; S18 custody v2 leaf checks; S19 v2-only check; S20 and S21 owner checks.

**Survivors that are real gaps:**

| Mutant | Meaning | Finding | Killed by my probes |
| --- | --- | --- | --- |
| S1 | Admission skipped at revision 1 | AF-1 | yes |
| S2 | Establish authority checks removed | AF-1 | yes |
| S3a, S3b | Assign and intent writers without admission (inventory only) | AF-1 | yes |
| S4 | Policy entry equality ignored | AF-2 | not probed |
| S5 | Trust model shallow copy | AF-2 | not probed |
| S6a | Installation ignored (inventory only) | AF-2 | yes |
| S7a, S7b | Classifier type-assertion step removed; "unclassified" reported as "read" | AF-3 | not probed |
| S10 | Empty-record compose guard removed | AF-12 | not probed |

**Survivors that are redundant layers (O-7):** S8a, S8b, S9, S15.

### 6.4 Limitations

- No macOS, native arm64, Docker, Nomad, Remote Alpha or live-stack coverage. No historical probe binaries.
- Tests ran as root, which skips two permission fixtures and fails three root-refusing `es/app` tests.
- The `internal/reliablesubmit` test results needed a one-file test-only overlay from PR #14 (patch SHA-256 `1173ed062000267f4365ff40b0a7530da9e08d9e7a7a9a922992869143e19ad4`), applied in separate scratch worktrees. Those results are therefore for "tip plus that test-file fix", not for the exact tip.
- Mutants are single-site and hand-chosen; they are evidence about the cuts I targeted, not a coverage measure.

## 7. Required corrections (repair scope for the writer thread)

Blocking:

- **R1 (AF-1).** Add maintained regressions. (a) Seed a claim at revision 1 and retry under configured literal denial, artifact revocation, signer revocation, no commissioned authority and withdrawal: expect Unavailable, no run, state unchanged; then an allowed retry completes with exactly one POST. (b) Fresh submit on a withdrawn and on a never-commissioned Service: no claim, no grant, no POST. (c) For the assign writer and the intent writer, inject denial at the in-transaction evaluation (write refused, revision unchanged) and at the post-COMMIT release evaluation (write kept, run withheld, no later effect). (d) Marker writer in-transaction denial: no marker, no POST. The existing proof hooks are enough to inject denial at the Nth evaluation; the audit probes show how. Acceptance: mutants S1, S2, S3a and S3b are each killed by a behavioural assertion.
- **R4 (AF-5).** Document reason, scope and removal condition for the v1 edge in the owner doc and add it to the admission model's section 4C table, or remove v1 per the owner's decision.

Same repair, non-blocking individually:

- **R2 (AF-2).** Tests: an injected policy set whose literal entries differ from configuration is refused at commissioning; mutating the Service's trust lists after commissioning does not change the snapshot's decision; a snapshot for installation A does not serve installation B, by behaviour.
- **R3 (AF-3).** Same-site classifier regressions for a type-assertion chain and for an unresolved selection. Either classify channel send, append into a reslice of the field, and conversion-wrapped write chains, or name them in the documented limits.
- **R5 (AF-4).** Reconcile the owner doc status table with `PLANS.md`: keep the reopened-seam statement, or record the owner's decision to promote schema 5.
- **R6 (AF-6 to AF-9, O-5).** Correct the outcome-mapping text: cancellation precedence; what the result reports when a later writer in the same call is refused; the scope of "does not poison"; one plain sentence defining "current admission" as the commissioned snapshot plus local withdrawal; the stranding of old-epoch unmarked claims; the chosen policy for stamped-unmarked disclosure. Pin each behavioural statement.
- **R7 (AF-10).** Remove or justify the unreachable 403 branch; note the added marshal.
- **R8 (AF-11).** Replace the assertions that cannot fail.
- **R9 (AF-12).** Pin the empty-record guard; preferably make the encoder refuse.

After repair: new provenance, a replacement implementation report, then a fresh audit thread. This audit does not bind changed bytes.

## 8. Sensitive-material handling

No secret, credential, key, token, environment file or production state was read, printed or copied. Tests use keys generated inside the fixtures and temporary SQLite files created and deleted by the tests. The evidence files contain only source paths, hashes, test output and fixture run identifiers derived from test data. No personal contact detail appears in this report or its evidence files.

## 9. Remaining uncertainty and stop conditions

- **Unknown:** behaviour on macOS and on the native target; behaviour of the environment-only suites at the tip (they fail identically at base for environmental reasons, so I can say only that nothing new fails).
- **Inference, not proof:** the unreachable 403 branch (AF-10); the stranding of old-epoch claims (AF-8); that no v1 original exists outside fixtures (AF-5).
- **Not done:** the writer's candidate-classifier negative control; combined or higher-order mutants; any adversarial testing beyond the probes (the red-team thread owns that).
- **Stop conditions:** none triggered. No provenance difference, no baseline drift, no sensitive-material risk.

## 10. Confidence

| Area | Confidence | Basis |
| --- | --- | --- |
| Provenance | high | Four identical manifests, equal to the writer's line; PR head equals the audited commit. |
| Validation | high for `es/admission` on Linux; medium overall | Full package, race run and build on exact bytes; environment-only suites could not run. |
| Implementation, production code | medium-high | Code reading by parent and three subagents, probes at every cut, 7 of 7 positive controls killed. |
| Implementation, regression protection | low at the establish and run-assignment cuts | Proven by surviving mutants S1 and S2. |

## 11. Effect status

Repair: not performed. Commit: none. Push: none. PR comment or review: none. Merge: none. Live-service contact: none. Repository edits: none (scratch worktrees only, outside the provenance clone). The only files written are this report and its three evidence files in the project's shared folder.

## 12. Report delivery

- Report: `/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/02-audit.md`. Its SHA-256 is given in the thread reply that delivers it (a file cannot contain its own hash).
- Evidence: `/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/02-audit-evidence/`
  - `audit-probes_test.go.txt` (SHA-256 `889c68ecf6e47520f447107e5a11bcab4941f4cf05bb8b88c40a8d5c8e699904`)
  - `mutants.py.txt` (SHA-256 `3b0921c75fb2e331d9258b00bf6e29d108754ebd3d346084f26eacac66b68102`)
  - `probe-and-mutation-output.txt` (hash in the thread reply)

## 13. Final verdict

**BLOCK**

Repair in the original implementation thread within the scope in section 7, then a fresh independent audit of the new bytes.
