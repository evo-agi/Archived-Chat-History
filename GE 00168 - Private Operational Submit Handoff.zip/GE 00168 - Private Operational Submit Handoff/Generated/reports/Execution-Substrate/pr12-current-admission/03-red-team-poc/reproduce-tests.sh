#!/usr/bin/env bash
# Red-team reproduction 1 of 2 for Execution-Substrate PR #13.
#
# Runs the candidate regression tests from draft PR #15 at commit 5ca4079
# in a throwaway copy of the repository. It changes nothing in your checkout
# and removes its own files when it ends.
#
# Use:   bash reproduce-tests.sh /path/to/Execution-Substrate
# Needs: git, Go, and network access to fetch the branch and Go modules.
# Time:  about 2 minutes.
set -euo pipefail

REPO="${1:-$PWD}"
BRANCH="claude/project-thread-uijb9o"
COMMIT="5ca407965a202c076e62d88ae79daa30ae97838b"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

git -C "$REPO" rev-parse --git-dir >/dev/null 2>&1 || { echo "Not a git repository: $REPO"; exit 2; }
WORK="$(mktemp -d)"
cleanup() {
  cd /
  git -C "$REPO" worktree remove --force "$WORK/wt" >/dev/null 2>&1 || true
  git -C "$REPO" worktree prune >/dev/null 2>&1 || true
  rm -rf "$WORK"
}
trap cleanup EXIT

git -C "$REPO" fetch -q origin "$BRANCH"
git -C "$REPO" cat-file -e "$COMMIT^{commit}" || { echo "Commit $COMMIT not found after fetch"; exit 2; }
git -C "$REPO" worktree add -q --detach "$WORK/wt" "$COMMIT"
cd "$WORK/wt"
go mod download

echo
echo "== 1/3 Attacks that did not break the change (expected: ok) =="
go test -count=1 -run 'TestRedTeamPR13Holds|FuzzRedTeamPR13' ./es/admission/

echo
echo "== 2/3 The finding that holds (expected: FAIL, 11 subtests) =="
if go test -count=1 -run 'TestRedTeamPR13GuardAccessInventoryEscapes' ./es/admission/ >"$WORK/guard.log" 2>&1; then
  echo "UNEXPECTED: the guard test passed. The finding did not reproduce at $COMMIT."
  STATUS=1
else
  grep -E '^\s*--- FAIL' "$WORK/guard.log" || true
  echo "EXPECTED: the guard test failed. Finding RT-1 reproduced."
  STATUS=0
fi

if [ -f "$HERE/experiments_test.go.txt" ]; then
  echo
  echo "== 3/3 Report-only observations (expected: ok; lines show what was observed) =="
  cp "$HERE/experiments_test.go.txt" es/admission/zz_rt_experiments_test.go
  go test -count=1 -v -run 'TestRTExp' ./es/admission/ | grep -vE '^(=== |\s+--- PASS)' | cut -c1-260
fi
exit "$STATUS"
