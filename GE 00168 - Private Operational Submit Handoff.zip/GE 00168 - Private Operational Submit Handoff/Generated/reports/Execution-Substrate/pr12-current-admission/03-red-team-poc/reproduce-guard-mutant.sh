#!/usr/bin/env bash
# Red-team reproduction 2 of 2 for Execution-Substrate PR #13 (finding RT-1).
#
# Shows end to end that the test guard misses a real production change.
# In a throwaway copy of the repository at the PR #13 commit e544e0f it
# applies a production mutant that erases the revocation lists of the
# installed admission snapshot, then runs the build, go vet and the whole
# es/admission test suite. Expected: everything passes with the mutant in.
# It then applies a control (the same change spelled through the field
# names) and expects the guard to reject it.
#
# Nothing is committed or pushed, your checkout is not touched, and the
# script removes its own files when it ends.
#
# Use:   bash reproduce-guard-mutant.sh /path/to/Execution-Substrate
# Needs: git, Go, and network access to fetch the branch and Go modules.
# Time:  about 5 minutes.
set -euo pipefail

REPO="${1:-$PWD}"
BRANCH="claude/project-thread-sqldt7"
COMMIT="e544e0fbe4220dfdd2c2068e3267dcfa454a0cf9"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET="es/admission/reliable_submit_operational_admission.go"

git -C "$REPO" rev-parse --git-dir >/dev/null 2>&1 || { echo "Not a git repository: $REPO"; exit 2; }
for f in mutant-anonymous-struct-conversion.diff mutant-named-field-control.diff; do
  [ -f "$HERE/$f" ] || { echo "Missing $f next to this script"; exit 2; }
done
WORK="$(mktemp -d)"
cleanup() {
  cd /
  git -C "$REPO" worktree remove --force "$WORK/wt" >/dev/null 2>&1 || true
  git -C "$REPO" worktree prune >/dev/null 2>&1 || true
  rm -rf "$WORK"
}
trap cleanup EXIT

git -C "$REPO" fetch -q origin "$BRANCH"
git -C "$REPO" cat-file -e "$COMMIT^{commit}" || { echo "Commit $COMMIT not found after fetch"; exit 2; }
git -C "$REPO" worktree add -q --detach "$WORK/wt" "$COMMIT"
cd "$WORK/wt"
go mod download
STATUS=0

echo
echo "== 1/2 Mutant: rewrite the installed snapshot through a same-shape struct conversion =="
git apply "$HERE/mutant-anonymous-struct-conversion.diff"
go build ./... && echo "build: ok"
if go vet ./es/admission/ >"$WORK/vet.log" 2>&1; then
  echo "go vet: ok"
elif grep -v 'result_auth_test.go' "$WORK/vet.log" | grep -q "reliable_submit_operational_admission.go"; then
  echo "go vet: flagged the mutant"; STATUS=1
else
  echo "go vet: nothing about the mutant (only findings that are already there without it)"
fi
if go test -count=1 ./es/admission/ >"$WORK/mutant.log" 2>&1; then
  echo "es/admission suite: ok WITH THE MUTANT IN. Finding RT-1 reproduced."
else
  grep -E '^--- FAIL' "$WORK/mutant.log" || true
  echo "UNEXPECTED: the suite rejected the mutant."; STATUS=1
fi
git checkout -q -- "$TARGET"

echo
echo "== 2/2 Control: the same rewrite spelled through the field names =="
git apply "$HERE/mutant-named-field-control.diff"
go build ./...
if go test -count=1 -run 'TestExecutionSubstrateSynchronizedMutableStateReferenceInventoryIsExact' ./es/admission/ >"$WORK/control.log" 2>&1; then
  echo "UNEXPECTED: the guard accepted the control."; STATUS=1
else
  grep -E '^--- FAIL' "$WORK/control.log" || true
  echo "EXPECTED: the guard rejected the control."
fi
git checkout -q -- "$TARGET"
exit "$STATUS"
