# INDEPENDENT AUDIT REPORT: PR #26, repair of audit 20's findings (`0aba38e` to `c99a1b4`)

This is a narrow, read-only re-audit. It is numbered 22 because another audit in this folder (`21-audit-pr28.md`) took 21 first; my scripts and probe test names still carry the working number 21. The coordinator asked for it at 15:38Z, and the writer handed it over at 16:12Z. Audit thread: "Audit Execution-Substrate PRs", the same auditor as `20-audit-pr26.md`. Date: 2026-11-23, 16:13Z to 16:47Z (UTC). I am not the writer of the audited bytes. There is no red-team, because the PR changes one test file only.

Verdict: **ACCEPT**, with one low finding, A22-1, that I recommend fixing in this PR before it merges. This commit introduced it. A test-only diff of 3 files fixes it, and I tested that diff (section 8). There are also two observations about older limits that this commit does not change (O22-1, O22-2).

## 1. In plain words

1. **The bytes are the ones the writer reported.**
   - My manifest of `c99a1b4` against `trunk_dev` `036d507` matched the writer's byte for byte, both at the start and at the end (`a36f06ef…9b30`).
   - `c99a1b4` is a fast-forward from `0aba38e`. It changes one file, +242/−14.
2. **A20-1 and A20-2 are closed. My proposal went in unchanged.**
   - I applied `object-level-allow-proposal.diff` to `0aba38e` and compared the result with `c99a1b4`. The only differences are the JSON helper and its test (`equivalence-proposal-vs-c99a1b4.diff`).
   - On `c99a1b4`, my probes P03 to P07 are now refused, and P29 (O20-1) is refused by the DTO guard. The other 25 of audit 20's probes give the same result as before.
   - All 22 of audit 20's mutants are caught. Before, 4 survived.
3. **O20-1 is closed, and the wider fix is right as far as I can test it.**
   - The writer found that the JSON key helper missed more than embedded unexported structs. It also missed untagged fields, keys in another case, invalid tag names and map values.
   - The helper now copies `encoding/json`'s rules for naming keys, and records each key also in the folded form that decoding matches. I checked those rules against Go 1.26.5's own code:
     - Folding: I checked all 1,112,064 runes. The helper never splits a group of runes that `encoding/json` treats as the same.
     - The only non-ASCII runes that fold to ASCII are `ſ` (U+017F) and `K` (U+212A, the Kelvin sign). Real decoding confirms both.
     - Tag names: 11,586 compared, 0 differ from `encoding/json`'s own check.
   - A new probe shows that the fold matters on the real tree. A `PrepareRequest` field tagged `checKpoint`, with the Kelvin sign, accepts `{"checkpoint":1}`. On `0aba38e` the DTO guard passes it; on `c99a1b4` it refuses it (Q3).
4. **A22-1 (low, new in this commit): a required JSON key can now change case or lose its tag, and no test notices.**
   - Four tests check that certain keys *stay present*: the producer contract's 24 keys, and three Workstream C compatibility lists.
   - They read the same set of keys that the "forbidden" checks read. That set now also holds each key's folded form.
   - So if `ProducerContractDeclaration.Service` is tagged `"SERVICE"`, or left untagged, ES writes `"SERVICE"` or `"Service"` on the wire. Yet the check for `"service"` still passes, because the lower-case fold is in the set.
   - On `0aba38e` both changes fail with `expected producer declaration compatibility field "service" to remain present`; on `c99a1b4` they pass (Q1, Q2).
   - Nothing in the product changes, and today every required key is written exactly. But a guard got looser, so it should be fixed before merge.
5. **The fix is small and tested.** `presence-exact-proposal.diff` makes the helper record a key as *written* (true) or *folded only* (false):
   - The forbidden checks are unchanged, so they still see both forms. Q3 and the writer's R1 to R7 stay refused.
   - The four presence checks now accept only a key that `encoding/json` writes exactly. Q1 and Q2 are refused again.
   - The writer's new test also checks that what `encoding/json` writes is recorded as written, and that a folded form alone is not.
   - es/admission in full gives the same results as `c99a1b4`. gofmt and vet are clean. 4 of the 5 mutants of the fix are caught by the tests, and a probe catches the fifth (O22-3).
   - It merges with PR #12's tree (PR #28's head `2c8bf35`) in the same two conflict blocks as before. PR #12's tree has the same four presence checks and no others. On that merged tree with the proposal, es/admission in full has the same 2,518 tests as the writer's trial merge, and every one passes or skips. Q1 and Q2 are refused there too.
6. **O22-1 (older, not changed by this commit): a presence check can still pass for a key that is no longer written.**
   - The key set is flat. It merges every nested type, and it does not apply `encoding/json`'s rule for duplicate names.
   - So a second field tagged `service` makes `encoding/json` drop both fields, and `"service"` vanishes from the wire. Yet the check passes on `0aba38e`, on `c99a1b4` and with my fix (Q6).
   - A key that moves to another nested object also still passes.
   - The writer's line "follows encoding/json's typeFields" is true for how keys are named, not for which fields survive a name clash.
7. **O22-2 (known limit, the writer lists it): a type's own `UnmarshalJSON` can read any key.** A `PrepareRequest` with its own `UnmarshalJSON` takes `"publication"`, and every guard passes (Q5). Today none of the 28 types the DTO guards walk has a custom JSON or text method, so a guard that refuses one would be cheap to add.
8. **Behaviour is unchanged.**
   - es/admission in full, two identities: `c99a1b4` adds the 25 new results (13 for the JSON test, 12 for the allow rule), all passing. No shared result changes.
   - The identity without sudo has the same 7 execution-root privilege failures at both heads.
   - gofmt is clean, and vet is clean for linux/amd64, linux/arm64 and darwin/arm64.
9. **CI passed on both heads.** Run 45206017915 on `0aba38e` and run 45212809103 on `c99a1b4` (16:06Z to 16:43Z) both ended in success.

## 2. Audit target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Pull request | #26, draft, branch `claude/project-thread-ne9cwa` into `trunk_dev` |
| Commit | `c99a1b46d4d8df2a63f97a13b5e437e3957f1ea9`, tree `59b90dce49969c177beec27f20b7f9c5101074b8`, parent `0aba38e` (fast-forward) |
| Previous head (audit 20) | `0aba38e28e9f529fad44b810a00c8d35446552d4`, tree `e2efd07c7c0311cbab16d36a556a655ae8db3368` |
| Base | `trunk_dev` `036d50724b499b020c5149c55ad902cfcb1482c0` (PR #25), unchanged |
| Change | `es/admission/workstream_a_guardrails_test.go`, +242/−14 against `0aba38e`, test code only (`delta-0aba38e-c99a1b4.diff`) |
| Recipe | `governed-execution.audit-patch-manifest.v2`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked before every run |
| Trunk-relative manifest | `a36f06efca041626b8a908ddc95d37f1c5a8a19685d7ecfd7a02d0be33679b30`: 1 file (SHA-256 `298945ae…8433`, 35,097 bytes), textual diff `5bdb7466c6b21a632f8abc7ab60b91e2625cf9ce0bc5c3776f0b3a0ceb07be77`, upstream `origin/trunk_dev` |
| Writer report | `reports/Execution-Substrate/workstream-a-allow-rule/02-repair.md`, SHA-256 `f0a79419d0acb1a74bd22d987e35634fcdaf7c1ddd5f01b893cae42c7831ae08` when I started. At 16:43Z the writer changed only its "Not claimed" line about CI, which gives `c1cf07d52b02e152ceb43ae4f35971c98a4c4fad6b7bb13ee0237286024266f5`; I checked that line. Evidence `02-repair-evidence/`: its `SHA256SUMS` has 81 entries, all OK (`writer-evidence-check.txt`) |
| Background | `20-audit-pr26.md` (SHA-256 `63c15bc0…5466`): A20-1, A20-2, O20-1 |

## 3. Posture and setup

- Read-only on GitHub: no push, comment, review, merge or branch change. One local commit for the trial merge (`c99a1b4` plus the proposal) stayed in my clone and was never pushed (section 8.3).
- Clone `/opt/audit/es`. Test trees are `git archive` exports of the exact commits: `c99a1b4`, `0aba38e`, `c99a1b4` with my proposal, and the trial merge.
- Runs used Go 1.26.5 with `GOTOOLCHAIN=local` and an emptied environment, as two identities: `ci` (uid 1500, gid 1600, with sudo) and `ci2` (uid 1700, gid 1700, without sudo). Probes, mutants and the proposal ran as `ci`.
- Every probe and mutant ran in a fresh copy of a pristine export.
- The first full es/admission runs (section 7) shared the machine with the `probes20.py` and `mutants20.py` runs. No shared result changed between the heads, so the load did not change any result. The proposal's full run and the trial merge's full run ran alone.
- I ran the writer's probe script `dto26b.py` (copied verbatim, SHA-256 `25b2f7dd…8906`) on my own trees, after reading it in full. No downloaded binary was executed.

## 4. Provenance

| Run | Time | `trunk_dev` | Result |
| --- | --- | --- | --- |
| Opening, two runs | 16:13Z | `036d507` | `a36f06ef…9b30` both times, identical to each other and to the writer's section 5 |
| Closing, two runs | 16:30Z | `036d507` | `a36f06ef…9b30` both times; JSON byte-identical to each other and to the opening |

The ref check before each pair is explicit, and it passed. The branch and `trunk_dev` were at the expected commits (`ls-remote-open.txt`, `ls-remote-close.txt`). Afterwards the clone was at `c99a1b4` with a clean status.

## 5. What changed, and what I verified

### 5.1 The allow rule (A20-1, A20-2)

`equivalence-proposal-vs-c99a1b4.diff` compares `0aba38e` plus `object-level-allow-proposal.diff` with `c99a1b4`. The only differences are:
- the imports `maps` and `unicode`;
- the new test `TestWorkstreamAJSONFieldNamesFollowEncodingJSON` with its helper types;
- the JSON helper.

The allow rule, its 12 refused cases and the `//line` cases are byte-identical to my proposal.

- `probes20.py` on `c99a1b4` (`probes20-c99a1b4-uid1500-gid1600.log`): all 31 probes as predicted.
  - P03 to P07 are refused.
  - P29 (`signedRuntimeTrustResponse` embedded in `PrepareRequest`) is now refused by the DTO guard: `must not expose upstream or CP-owned grammar field "publication"`.
  - P24 and P28 still pass. They are the known limits of a word guard (O20-2).
- `mutants20.py` on `c99a1b4` (`mutants20-c99a1b4-uid1500-gid1600.log`): the control passes. All 22 mutants are caught: M07 to M21 and F01 to F07, including M16, M17, M18 and M21, which survived on `bcfb6da`.

### 5.2 The JSON key helper (O20-1)

The helper is `collectJSONFieldNames` and `collectJSONFieldNamesFromType`, with `workstreamAJSONFieldKey`, `workstreamAValidJSONTagName` and `workstreamAJSONKeyFold`. I compared it line by line with `encoding/json` in Go 1.26.5 (`typeFields`, `isValidTag`, `foldName`, `foldRune`).

- **Which fields get a key.**
  - A field tagged `-` is skipped.
  - An unexported field is skipped, unless it embeds a struct or a pointer to one.
  - An embedded struct without a valid tag name promotes its fields.
  - Any other field is keyed by its valid tag name, or else by its Go name.
  - This is `typeFields`. The helper dereferences any pointer before the embedding test. `typeFields` does so only for unnamed pointer types, but an embedded field cannot have a named pointer type, so the two agree.
- **Tag names.** `workstreamAValidJSONTagName` is `isValidTag`. A probe test compared the two on 11,586 names: every ASCII printable character alone, between letters and at the start, plus every rune class. 0 differ.
- **Folding.** `encoding/json` matches a decoded key to a field first by exact name, then by `foldName`. `foldName` upper-cases ASCII letters and maps any other rune to the smallest rune of its `unicode.SimpleFold` orbit. The helper maps each rune to the lowest rune of its orbit and lower-cases it.
  - These give different strings, but the helper only needs to put the same runes together.
  - A probe test over every rune (`fold-and-custom-json-c99a1b4-uid1500-gid1600.log`): 1,112,064 runes in 1,110,610 `foldName` classes, and the helper splits none of them.
  - The only non-ASCII runes whose fold is ASCII are U+017F and U+212A. For both, decoding the ASCII key into a field tagged with the rune sets the field.
  - None of 1,402 sampled non-ASCII letters is matched by an ASCII key.
  - So every key that decoding matches to a guarded lower-case name is found by that name, and none that it does not match.
- **Maps.** Map values are followed. Map keys are data, not field names, so they are not recorded. That is right.
- **What `c99a1b4` records on the real tree.** The writer's `helper/keys-summary.txt` shows that seven of the eight guards record the same keys as on `0aba38e`. The eighth also records the untagged fields `MediaType`, `OutcomeEvidence` and `Payload`, with their folded forms. No guard forbids them. I re-ran es/admission in full, and every guard passes (section 7).

### 5.3 New probes on the real tree

`probes21.py` makes each change in a fresh copy of `0aba38e` and of `c99a1b4` (and, for section 8, of the proposal). It adds a probe test that shows what `encoding/json` really does, then runs the Workstream A tests, the producer-contract DTO test and the probe test. Every probe built, and all results matched my prediction (`probes21-uid1500-gid1600.log`, `probes21-with-fix-uid1500-gid1600.log`).

| Probe | Change | What `encoding/json` does | `0aba38e` | `c99a1b4` | with the proposal |
| --- | --- | --- | --- | --- | --- |
| Q0 | none (control) | | pass | pass | pass |
| Q1 | `ProducerContractDeclaration.Service` tagged `"SERVICE"` | writes `"SERVICE"` | refused: `"service"` must remain present | **pass** (A22-1) | refused |
| Q2 | the same field untagged | writes `"Service"` | refused | **pass** (A22-1) | refused |
| Q3 | a `PrepareRequest` field tagged `checKpoint`, with the Kelvin sign | `{"checkpoint":1}` sets it | **pass** | refused | refused |
| Q4 | a `PrepareRequest` field tagged `publıcation`, with the dotless ı | `{"publication":1}` does not set it | pass | pass (right: nothing is exposed) | pass |
| Q5 | `PrepareRequest` gets its own `UnmarshalJSON` that reads `"publi"+"cation"` | takes `{"publication":…}` | pass | pass (O22-2) | pass |
| Q6 | a second `ProducerContractDeclaration` field tagged `service` | drops both fields: no `"service"` key | pass | pass (O22-1) | pass |

I also ran the writer's own probes R0 to R7 (`dto26b.py`) on `c99a1b4` and on the proposal (`writer-rprobes-c99a1b4-and-proposal-uid1500-gid1600.log`). On both trees R0 passes, and R1 to R7 are refused by the DTO guard. The word guard passes, and the probe test shows that `encoding/json` accepts each forbidden key. That matches the writer's `helper/dto.log` for the commit, so the proposal loosens none of them.

## 6. Findings

| ID | Severity | Type | Summary |
| --- | --- | --- | --- |
| A22-1 | low | regression in a guard, new in `c99a1b4` | The four "must remain present" checks read the same key set as the forbidden checks, and that set now holds every key's folded form too. A required key can change case or lose its tag on the wire, and the check still passes. Q1 and Q2 are refused on `0aba38e` and pass on `c99a1b4`. |

**A22-1 in detail.**
- The four checks:
  - `producercontract_test.go:237`, 24 keys of the producer declaration;
  - `workstream_c_guardrails_test.go:6104`, the normal-shell credential-location fields;
  - `workstream_c_guardrails_test.go:6148`, the C4 compatibility metadata;
  - `workstream_c_guardrails_test.go:6698`, the C5 compatibility fields.
  
  All four ask `if _, ok := fieldNames[key]; !ok`.
- The folded form is right for the forbidden checks. Decoding matches a key in any case, so a forbidden name must be found in any case.
- For a presence check it is wrong. The check is there so that ES keeps writing the key that other parties read, and `encoding/json` writes a key exactly as tagged.
- Go clients would still decode `"SERVICE"` as `service`, because decoding ignores case. A case-sensitive reader would not, such as another language, a stored record read by a script, or the Python proof of concept.
- Severity is low:
  - the change is test-only;
  - today every required key is written exactly;
  - the gap opens only if a later change breaks a key.
- It is still a guard that this commit made looser. Under the project's rule of no "accept now, revisit later", I recommend fixing it in this PR.

### 6.1 Observations

| ID | Observation |
| --- | --- |
| O22-1 | Older than this commit, and not changed by it or by my proposal. The presence checks read one flat set of keys across every type they are given and every nested type. The set also ignores `encoding/json`'s rule for duplicate names: at the same depth, two fields with the same name both vanish, and a shallower field hides a deeper one. Q6 adds a second field tagged `service`. `encoding/json` then writes no `"service"` key at all, yet the check passes on `0aba38e`, on `c99a1b4` and with the proposal. A required key that moves into another nested type also passes. One cheap way to cover the name clash for top-level keys: decode `{"<key>":null}` into the type with `DisallowUnknownFields`, which fails when no field takes the key, next to the exact-key check from the proposal. I did not test this sketch. Covering moved keys needs keys recorded by object path. The writer's claim that the helper "follows `encoding/json`'s typeFields" holds for how keys are named. It does not hold for which fields survive a clash. That costs nothing for the forbidden checks, which may record too much, but it matters for presence. My recommendation: decide now whether it is fixed in this PR or tracked with a trigger. |
| O22-2 | Known limit, listed by the writer under "Not claimed": a type's own `MarshalJSON` or `UnmarshalJSON` can write or read any key, and the DTO guards cannot see it (Q5). A probe test walked the same 28 types the DTO guards walk, and none implements `json.Marshaler`, `json.Unmarshaler`, `encoding.TextMarshaler` or `encoding.TextUnmarshaler` (`fold-and-custom-json-c99a1b4-uid1500-gid1600.log`). So a guard that refuses those methods on public DTO types would cost nothing today and would close this road. |
| O22-3 | A test cannot catch which way a check reads the set, only a probe can. With the proposal, a mutant that turns a forbidden check into a value read (`if fieldNames[forbidden]`) survives the suite, because no DTO holds a forbidden key (K05). Probe Q3 catches it. The same is true of a presence check turned back into `_, ok` (probes Q1, Q2). This matches audit 20's approach: the probes are evidence, not part of the PR. |
| O22-4 | The writer's counts (1,116 to 1,141 passing, 12 skips) differ from mine (1,121 to 1,146 passing, 7 skips, as `ci`) only in how many tests skip in each environment. The totals agree: 1,128 to 1,153 results. |

## 7. Behaviour and tests

`unit21.sh` runs gofmt, vet for three targets and es/admission in full at `c99a1b4` and `0aba38e`, as both identities (`unit-admission-c99a1b4-vs-0aba38e-uid1500-gid1600.log`, `-uid1700-gid1700.log`).

| Identity | `0aba38e` | `c99a1b4` | Difference |
| --- | --- | --- | --- |
| `ci` (sudo) | 1,121 pass, 7 skip | 1,146 pass, 7 skip | +25 new, all pass: 13 for `TestWorkstreamAJSONFieldNamesFollowEncodingJSON` and its 12 cases, 12 for the new refused cases of the allow rule. 0 changed, none gone |
| `ci2` (no sudo) | 1,110 pass, 11 skip, 7 fail | 1,135 pass, 11 skip, 7 fail | the same +25. The 7 failures are the same at both heads, all from execution-root privilege (`TestNewServiceRejectsDualMissingExecutionRootsBeforeMutation`, `TestRetainedResultAuthRequiredStartupFailsWithoutKeyAndPrepareOnlySkipsIt`, `TestRetainedResultReviewFreshServiceReopensPersistedResultWithReloadedKey`, and `TestRetainedResultReviewStartupNaturalDirectoryMask` with its 3 cases) |

gofmt is clean, and vet is clean for linux/amd64, linux/arm64 and darwin/arm64, at both heads.

## 8. The proposal

`presence-exact-proposal.diff` (SHA-256 `e1220aa1380540146c3584f7aa125301d862a8251c0d93ddc24398ca0f474c35`) applies with `patch -p1` to `c99a1b4`. It is test-only, +35/−14 across three test files:

- **Helper:** `collectJSONFieldNames` returns `map[string]bool`. Each key is recorded as `true` (written), and its folded form as `false` unless some field writes that form exactly:
  ```go
  names[key] = true
  if fold := workstreamAJSONKeyFold(key); !names[fold] {
  	names[fold] = false
  }
  ```
- **Forbidden checks:** unchanged (`if _, ok := fieldNames[forbidden]; ok`), so they still find both forms.
- **Presence checks:** the four sites become `if !fieldNames[expected]` and `if !fieldNames[compatibilityField]`.
- **Test:** the writer's check that every key `encoding/json` writes is recorded now asks for it to be recorded *as written*. A new check covers a struct with `service` then `SERVICE`, `HOLD` then `hold`, and an untagged `Review`. Every written key must be `true` whichever comes first, and the folded-only `review` must be `false`.

### 8.1 Results on `c99a1b4` with the proposal

- gofmt clean; vet clean for linux/amd64, linux/arm64 and darwin/arm64 (`presence-exact-proposal-uid1500-gid1600.log`).
- es/admission in full: 1,146 pass, 7 skip, **the same results as `c99a1b4`, test for test**. The new checks sit inside the existing test function, so they add no new results.
- Probes (`probes21-with-fix-uid1500-gid1600.log`): Q1 and Q2 are refused again, Q3 stays refused, and Q0, Q4, Q5 and Q6 pass, all as predicted.
- The writer's R1 to R7 stay refused (section 5.3).

### 8.2 Mutants of the proposal

`mutants21.py` changes the proposal in a fresh copy and runs the Workstream A and producer-contract tests (`mutants21-fix-uid1500-gid1600.log`):

| Mutant | Change | Result |
| --- | --- | --- |
| K00 | none (control) | passes |
| K01 | the folded form is recorded as written | caught |
| K02 | the folded form overwrites a written key | caught (also by the real producer test) |
| K03 | the folded form is not recorded | caught |
| K04 | a written key is recorded as not written | caught |
| K05 | a forbidden check reads the value instead of the key | survives the suite, as expected; probe Q3 catches it (O22-3) |

### 8.3 With PR #12

PR #28's head `2c8bf35` is the tree that is to become PR #12's head. It changes `workstream_c_guardrails_test.go` heavily, but it has the same four presence checks and no others. Its DTO and presence sites use the same `_, ok` reads.

- `git merge-tree` of `2c8bf35` with `c99a1b4`, and with `c99a1b4` plus the proposal (a local commit, never pushed), gives the same two conflict blocks in `workstream_a_guardrails_test.go`.
  - These are the two blocks the writer's plan already resolves.
  - `workstream_c_guardrails_test.go` and `producercontract_test.go` merge cleanly.
  - The only differences between the two merged trees are the proposal's own lines.
- I resolved the two blocks as the plan says: keep PR #12's `source:` line and add `node:` and `syntax:`.
- On that tree (`trial-merge-pr28-2c8bf35-with-proposal-uid1500-gid1600.log`):
  - gofmt is clean, `go build ./...` passes, and vet is clean for three targets.
  - es/admission in full gives 2,510 pass, 8 skip and 0 fail. The writer's trial merge without the proposal gave 2,505 pass and 13 skip. Both runs have the same 2,518 tests, with the random SIGKILL rounds compared by round number. The only differences are 5 tests that skip without sudo and pass here (`trial-merge-results-vs-writer.txt`).
  - Probes on that tree (`probes21-trial-merge-uid1500-gid1600.log`): Q1, Q2 and Q3 are refused, and Q0 and Q6 pass, as predicted.

Note for whoever merges PR #26 into PR #12: if PR #12 or any later change adds another "must remain present" check, it must read the value (`if !fieldNames[…]`). A `_, ok` read still compiles against the new map type, and it would quietly bring A22-1 back.

## 9. CI

| Head | Run | Result |
| --- | --- | --- |
| `0aba38e` | 45206017915 | completed 15:58Z, success |
| `c99a1b4` | 45212809103 | completed 16:43Z, success (Test 16:11:38Z to 16:32:22Z; "Listed tests still fail" from 16:32:22Z) |

(`ci-status.txt`)

## 10. Sensitive material

The probes and fixtures are synthetic. No key, certificate body, token or config file is copied into the evidence. Commit-message trailers and author names are left out.

Before publishing, I scanned the report and every evidence file for private-key headers, certificates, Vault, JWT, GitHub, Anthropic and AWS token shapes, personal names, mail and phone shapes, and model names. The scan found nothing, and a positive control matched.
