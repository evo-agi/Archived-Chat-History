# Plan: merging `trunk_dev` into the combined PR #12

Date: 2026-11-23. Fourth version: measured at `trunk_dev` `036d507` (PR #25), and corrected for M19-1 of `19-audit.md` (56 paths, not 55). Writer of PR #13.

**Done at 16:40Z.** After audit 21 (ACCEPT, no findings) and David's go, PR #12's branch `codex/reliable-submit-operational-handoff-v1` was fast-forwarded from `6288b63` to `2c8bf35` (no force; `trunk_dev` was still `036d507`). GitHub marked PR #28 merged, since its head is now PR #12's head.

**Status at 16:05Z.** PR #13 merged into PR #12's branch as `6288b63` (David approved it after review). Steps 1 and 2 below are done on a branch of this thread, `claude/project-thread-ne9cwa-pr12-trunk-dev`, pushed as draft PR #28 into PR #12's branch so that CI runs on the merged tree: merge `f36911c` (tree `8c61971c…`) and follow-up `2c8bf35` (tree `df3ff9dd…`, the tree tested in section 4). PR #12's own branch is unchanged beyond PR #13. It moves only by a fast-forward to PR #28's head, after the audit and David's go. At 16:12Z PR #26's head moved to `c99a1b4` (audit 20's fixes); step 1's resolution for it is unchanged and tested (section 4).

Inputs: section 15 of `17-audit.md`; sections 6.2, 9 and 12 of `19-audit.md`; my trial merges of PR #13's tips `d314590` and `e060449` with `trunk_dev` `200fd60` (PR #23), `792f17c` (PR #22) and `036d507` (PR #25); the coordinator's notes that PR #23 requires a test startup file in every test package and that PRs #22 and #25 landed; and draft PR #26 (O7-1), which touches a file of PR #12.

**What changed in this version.**

- **M19-1 fixed.** The earlier versions counted 55 paths (54 in the first). The CI list file, `.github/ci/environment-only-tests.txt`, is a path too, so the merged head has **56**. The follow-up commit now holds the two CI list lines itself, and its reconciliation names all three paths and says 56. The earlier separate step for the CI list is gone.
- **PR #25 changes nothing else.** It changes `docs_contract_test.go` only in the toolchain baseline test, which merges without conflict. Its new test file `es/app/spire_release_pin_test.go` trips none of PR #12's guards. The merged tree at `036d507` differs from the tested tree at `792f17c` by exactly PR #25's diff.

## 1. In plain words

As of `trunk_dev` `036d507`, PR #12 can take `trunk_dev` with:

- **two conflict blocks** in `docs_contract_test.go`: the reliable-submit file count (39) and the known adjacency block (keep both);
- **one follow-up commit** (`18-trunk-dev-merge-gate.patch`), which:
  - adds the test startup file for the new admission state package;
  - changes PR #22's two `fset.Position(...)` reads to `fset.PositionFor(..., false)`, which PR #12's position-read test otherwise refuses;
  - adds the two CI list lines for tests of the handoff, which the list's check refuses on `trunk_dev` alone;
  - adds the owner-document paragraph, plan entry and pins for the three paths this adds. That makes **56 paths** against `trunk_dev`, up from 53.

I did the whole merge in a scratch clone and ran it:

- Build and vet are clean, the startup-file guard passes, and the CI's list check and the gate's self-test pass.
- Every PR #12 test passes, PR #22's tests pass with the changed reads, and the root package shows only the known environment failures.
- Without the follow-up commit, the startup-file guard fails, and so does the position-read test (on PR #22's two lines).

If PR #26 (O7-1) lands on `trunk_dev` first, `workstream_a_guardrails_test.go` also conflicts in two small blocks (section 3, step 1). That is tested too, and it adds no path.

## 2. When

Recommended order:

1. Done: David's review of PR #13 (the narrow re-audit, `19-audit.md`, accepted `e060449`), and PR #13's merge into PR #12 (`6288b63`).
2. **Then this merge**, on PR #12's head (done on PR #28's branch), before the Fable red-team of the combined change, so that the red-team and the final audit look at the tree that will land on `trunk_dev`.
3. A narrow audit of the merge commit's resolutions and the one follow-up commit.
4. The Fable red-team, the open product question (CP-PUBLIC-MAPPING), then PR #12's own merge gate into `trunk_dev`.

Writing to PR #12's branch needs David's go, as for PR #13. To keep that write a single fast-forward, I would build the merge on a branch of this thread from PR #12's head, have it audited there, and then fast-forward PR #12's branch to it once David says go.

## 3. Steps

Re-check every number against `trunk_dev` at the time; the steps below are measured at `036d507`.

1. **Merge `trunk_dev`** into PR #12's head and resolve:
   - `docs_contract_test.go`, **the reliable-submit file count**: PR #12 says 38, `trunk_dev` says 34. Take PR #12's side with the merged count, **39**. Count it in the merged tree; keeping both sides fails.
   - `docs_contract_test.go`, **the adjacency block** after `TestReview17ProofResultHandoffContract…`: keep both blocks, one blank line between them.
   - Only if PR #26 is on `trunk_dev`: `es/admission/workstream_a_guardrails_test.go`, **two blocks**, one per occurrence literal. Keep PR #12's `source:` line (it reads `guardPosition`) and add PR #26's `node:` and `syntax:` lines.
   - PR #22 changed neither file, and PR #25 changed `docs_contract_test.go` only in the toolchain baseline test, away from both blocks. So these resolutions are the same as at `200fd60`. Commit the merge with only these resolutions.
2. **One follow-up commit**: apply `18-trunk-dev-merge-gate.patch` (`git apply`). It:
   - adds `es/admission/internal/admissionstate/testtmpdir_main_test.go`, PR #23's canonical one-line `TestMain`;
   - changes `remote_alpha_es_service_tls_status_local_boundary_test.go` lines 108 and 153 to `fset.PositionFor(…, false)`;
   - adds to `.github/ci/environment-only-tests.txt` the line for `reliablesubmit` `TestOperationalHandoffSchema4BinaryRefusesSchema5` (fails without its probe binary) and the `skips-itself` line for `es/admission` `TestOperationalHandoffChildProcess`, with their comments (the content of `13-ci-list-two-lines.patch`);
   - adds the reconciliation for the 54th, 55th and 56th paths to section 9 of the owner document, and turns "is 53 files" into "was 53 files";
   - adds a `PLANS.md` entry (dated 2026-11-23: set it to the day of the merge), and turns the previous entry's "is 53 files" into "became 53 files";
   - adds pins for each new statement in `docs_contract_test.go`; each owner-document statement has a missing case and a wrong-statement case.
   If the documents have moved by then, make the same change by hand.
3. **Anything else that reached `trunk_dev` meanwhile** passes PR #12's guards for the first time at this merge, because those guards read the whole repository. Any of these fails a guard or a check:
   - a new dependency import;
   - a raw pointer value outside a file that imports `unsafe`;
   - a line directive in a production file;
   - an adjusted position read in any test file;
   - a new test package without the startup file;
   - a CI list line for a test that the merged tree does not define.

   At `036d507`, only PR #22's two reads trip a guard. PR #25's new test file trips none: it reads no positions, imports only the standard library, and its package already has the startup file. Whatever trips must be resolved in the follow-up commit, and the audit must judge each one.

   **PR #29 (ARS blob byte verification, draft, `f8c1a73` on `036d507`)** works the other way round: its new guard `TestFetchVerifiedARSBlobIsTheOnlyARSBlobReadInES` reads the whole of ES's production code, so it judges PR #12 too. Its writer trial-merged `f8c1a73` into PR #28's head `2c8bf35` (16:15Z): clean, no conflict; build and vet clean; the failing sets of `./internal/testtmpdir/ ./es/admission/... .` identical with and without it (environment failures only); PR #12 adds no ARS blob read, and the guard passes. Nothing to change in PR #28 (`artifact-verification/01-implementation.md`, sections 7 and 8). Not re-run by me. Whichever of PR #29 and PR #12 lands second must re-run that guard after its merge, and any new test that serves ARS bytes must serve digest-true bytes (`withPayload`).
4. **Run, as the CI's user would**: `go build ./...`; `go vet ./...`; `GOOS=darwin GOARCH=arm64 go vet ./...`; `go test ./internal/testtmpdir/ ./es/admission/... .`; the CI gate's self-test and list check; and the full suite with the CI's environment-only list (the push runs the CI).
5. **Manifests** of the merged head: the trunk-relative manifest has **56 paths**: the 53 of PR #12, the startup file, PR #22's test file and the CI list.

## 4. What was tested

Linux, Go 1.26.5, user `ci`, emptied environment; scratch clones. Logs: `18-repair-evidence/trunk-dev-merge/`. Names starting `200fd60-` are the earliest merge, of `d314590`; `792f17c-` the merge of `e060449` with PR #22's `trunk_dev`; `036d507-55-` the same with PR #25's `trunk_dev` and the 55-path patch; `036d507-56-` the corrected 56-path patch; `036d507-pr26-` PR #26 merged on top.

| What | Result |
| --- | --- |
| Merge of `e060449` and `036d507`, strict resolver (count block, adjacency block, anything else stops) | Only `docs_contract_test.go`, the same two blocks. Tree `8c61971c…`, the same as the auditor's (`19-audit.md` 9.5). The resolved file equals the resolved file at `792f17c` plus PR #25's own change to it, byte for byte |
| PR #28's merge `f36911c` (from PR #12's head `6288b63`, whose tree is `e060449`'s) | The same resolver, the same tree `8c61971c…` |
| The merge plus the corrected follow-up (tree `df3ff9dd…`, PR #28's head `2c8bf35`): build, vet, vet darwin | Clean |
| The same: the CI gate's self-test and its list check | 121 tests OK; list check OK (17 entries, 5 `skips-itself` lines) |
| The same: `internal/testtmpdir` | 27 pass (the startup-file guard included) |
| The same: `es/admission/...` | `es/admission` 2,463 pass, 13 skip, 0 fail; `admissionstate` 70 pass; `reliablesubmit` 749 pass, 2 skip, 3 fail (the known probe-binary tests the CI list names) |
| The same: root package | 2,358 pass, 113 fail: only the 25 known environment tests. Against the 55-path run, the only new results are the two new pin subtests, both passing; nothing else changed |
| The corrected pins against the merge-only documents | 10 subtests and their 2 parents fail: each new owner statement's missing and wrong-statement cases, and the sixth-audit pair whose wording moved to "was 53" |
| PR #22's original reads on the merged tree | `TestOperationalGuardReadsUnadjustedPositions` fails on `remote_alpha_es_service_tls_status_local_boundary_test.go:108` and `:153` |
| Each CI list line alone on `trunk_dev` `036d507` | The list check refuses each: "listed test is not defined" for `TestOperationalHandoffSchema4BinaryRefusesSchema5` and for `TestOperationalHandoffChildProcess` |
| Trunk-relative paths of `2c8bf35` | **56**, equal to the manifest's path list |
| The 55-path patch at `036d507` (before M19-1) | The same results as at `792f17c`; differs from the `792f17c` tree by exactly PR #25's diff |
| PR #26's head `0aba38e` merged on the 55-path tree, its two blocks resolved as in step 1 | Only `workstream_a_guardrails_test.go`, two blocks; the resolved file is byte-identical to the tested resolution at `792f17c`. `go vet ./es/admission/` and `gofmt` clean; `es/admission` 2,480 pass, 13 skip, 0 fail; no path added |
| PR #26's new head `c99a1b4` (audit 20's fixes) merged on PR #28's head `2c8bf35` | The same two blocks, resolved as in step 1, and nothing else. `go build ./...`, `go vet ./...` and `gofmt` clean; `es/admission` 2,505 pass, 13 skip, 0 fail; against `2c8bf35` none gone or changed, and the 42 new results pass; the same 56 paths (`workstream-a-allow-rule/02-repair-evidence/pr12-trial/`) |
| The startup file absent (on the `200fd60` merge) | The startup-file guard fails for `es/admission/internal/admissionstate` and no other package |
| My merge of `d314590` and `200fd60` | Tree `6839ec975a4a0aac6970364ccceba8a395ecdfe7`, identical to the auditor's (`17-audit.md` section 7.8) |


## 5. Files

- `18-trunk-dev-merge-gate.patch`: the follow-up commit of step 2 for `trunk_dev` `036d507`, corrected for M19-1 (56 paths, the CI list folded in), as `git diff` of the resolved merge and the follow-up; identical to `git diff f36911c 2c8bf35` of PR #28. SHA-256 `9a1761b35f9e1bf869352c86382fd338e3f4f335fcd676b5203a0b7502b3447a`.
- `18-trunk-dev-merge-gate-55.patch`: the version that `19-audit.md` checked (55 paths, CI list separate), kept for the record. SHA-256 `12cba9f294096429f999577b6e6e64803a212864c63528c098a292ba52883523`.
- `18-trunk-dev-merge-gate-200fd60.patch`: the first version, for `200fd60` (54 paths), kept for the record. SHA-256 `c4ea82e2b2ae23e958eb0f1a9628799523994144759f5b439c391899771b3aab`.
- `13-ci-list-two-lines.patch`: the two CI list lines; now part of the follow-up commit, kept as its source.
- PR #28's manifests (`18-repair-evidence/trunk-dev-merge/pr28-manifests/`), recipe `governed-execution.audit-patch-manifest.v2`, each written twice, byte-identical, staged trees equal the head's:

| Manifest | Base | Upstream pinned to | Files | Manifest SHA-256 | Textual diff SHA-256 |
| --- | --- | --- | --- | --- | --- |
| Trunk-relative | merge base `036d507` | `origin/trunk_dev` | 56 | `7e9c3e19008c1029f7be709fa2694cc884f5e3bc16d825857f11bfa46f4d3999` | `d5f62729cd2af91784a0ebfd7b5ef04c49f897883b7ceef116a77d1da73925a9` |
| Against PR #12's head | `6288b63` | `origin/codex/reliable-submit-operational-handoff-v1` | 78 | `5e8504f83a4ca3b80f19c1245837ecc3562662624b55a7132d24b6a80af8fe31` | `2c5ba1da83179ed3ef42acbda69ac04702c06135ee1c4cc5e67e48499bd0673a` |
| The follow-up only | merge `f36911c` | `origin/claude/project-thread-ne9cwa-pr12-trunk-dev` | 6 | `dd821fbc4a9d7f257a07e36ea51bd10ddc3c64fd67bb165febde3b536220e009` | `3664d5cd630098427b1c0261f53ca535df9faa87e1c20dbac8ca3174eec658cd` |

## 6. Not claimed

- CI on PR #28's head `2c8bf35`, the first run of the merged tree on the runner: "build, vet and test" **passed** (run 45211082054, 15:57:54Z to 16:28:48Z). Nothing ran on macOS.
- The full suite was not run on the merged tree, only the packages named in section 4.
- `trunk_dev` will move again; every step must be re-checked at merge time.
- The follow-up commit changes PR #12's scope (three paths) and goes through an audit like any other change.
