# PR #12 round 35 (draft PR #47 at `f7bb1d6`): combined check 36

Written 2026-11-24 from 04:47Z onwards by the independent audit thread "Audit Execution-Substrate PRs", after the coordinator asked for a combined diff check. Read-only: nothing was pushed, commented, reviewed or merged. Evidence is in `36-combined-check-evidence/` next to this file. My local names carry the tag `40d`.

Subject: the writer's `35-repair.md` (SHA-256 `f7dd806b…4323`).

## Verdict

**ACCEPT, with no findings to fix in PR #47.** N-1, N-2 and I33-3 are closed, the two `trunk_dev` merges are git's own apart from a union of `PLANS.md`, and the scope is as stated. Two Info notes follow; neither needs a change before the merge.

- **N-1 is closed.**
  - The provider cannot be built without ES's token in Nomad's canonical form.
  - Its one request builder, `prepareExchange`, sets the token in the `X-Nomad-Token` header of every request and never in the URL.
  - The registration now goes through a thin `prepareRegister` on the provider's own receiver, so PR #31's guard sees every Nomad path at a builder.
  - The fake Nomad refuses any request without the token, so every handoff test that passes through it shows the token was sent.
  - My probes confirm three things. No format verb prints the token, and neither does `json.Marshal`. A wrong token gets nothing registered. Three mutants of my own (an overwrite after the builder, the token on the registration only, the header deleted on GETs) are each caught.
- **PR #31's guarantees for `nomadClient` are kept exactly.** Every accepted, refused and lost-token case of PR #31's self-tests still runs. One refused case now names an unknown type, because the provider is a known client now. The rules for `nomadClient` read the same as before.
- **N-2 is closed.** The three position reads in PR #31's guard test now go through `guardPosition`, and PR #12's position guard passes.
- **I33-3 is closed.** `nomadKeepsDriverString` now first requires `utf8.ValidString`. Its unit test adds a stray byte, an encoded surrogate and an overlong encoding.
- **`CP-NOMAD-ACL` is right as a separate prerequisite.** It names items 2 to 6 of PR #31's change list. The one thing it leaves to the contract's prose is where the token comes from (I36-1).
- **`prepareRegister` changes nothing about timing.** `liveSender.consume` calls it at the same place, with the same arguments, before it takes the owner's lock, as before.
- **The provenance holds.**
  - Merges: `a619076` (with `0842983`: #43, #42, #34, #31) and `8d3a365` (with `6dbeaeb`: #38) each differ from git's own merge tree only in `PLANS.md`. That file equals a union of both sides, apart from blank lines.
  - The six commits change what the report says. Only three production files change: `reliable_submit_operational_provider.go`, `reliable_submit_operational_handoff.go` and `service.go`.
  - Nothing under `es/admission/` changes from `cd615c3` to the head.
- **The manifests verify.** I took each twice, byte-identical, and each JSON file is identical to the writer's:
  - trunk-relative: `41ac8bad…054b`, 70 files;
  - PR-relative: `6d6dd584…bea8`, 91 files.

  For both, the staged set equals the paths, and `write-tree` gives the head tree `8408ab09`. Against re-check 33's 69 files:
  - one path is added, `es/admission/nomad_request_guard_test.go`;
  - 17 entries changed;
  - 52 are identical.

  In the six files that changed only through `trunk_dev`, PR #12's own hunks are byte-identical to round 32's.
- **Vet and tests pass as `ci`.**
  - `go vet ./...` passes, and so does the arm64 and darwin vet of `es/admission` and the root. The changed Go files are gofmt-clean.
  - The whole `es/admission` package gives 581 passes, 8 skips and 0 failures. That is the writer's 589 top-level tests; six of their 14 skips run and pass here.
  - The root package passes 165 of 165, in a git checkout. `internal/testutil` passes.
  - The token guard, the provider's token tests, the position guard, the blob-read guard and the authority-boundary test all pass (`unit40d.log`).
- **CI:** run 45324371962 of `build, vet and test` on `f7bb1d6` succeeded (check run 138210398576, 04:09Z to 04:45Z).
- **`trunk_dev` is now `c610e1d` (#44, one reliablesubmit test file).** The trial merge is clean, and its diff over the head is byte-identical to #44's. It shares no path with PR #12's 70. On the trial tree, `go vet` of `es/admission` and `reliablesubmit` passes, and so do #44's test and the locator-shape tests (`trial-merge-44.txt`). PR #12 takes `c610e1d` at its last sync, as the writer says.

## In plain words

PR #12's private path now sends ES's Nomad password on every request, the way PR #31 made the ordinary path do. It sends it only in the header, and only to the one Nomad it has pinned. PR #31's checker now watches both paths, and the test Nomad turns away anything without the password. The two small leftovers from my last check are fixed too.

What wiring the private path still needs is written down as a seventh item on the list of things that must be done before anyone wires it. I'd add one line to that item: say which password it must use.

## 1. Target

| Item | Value |
| --- | --- |
| PR | evo-agi/Execution-Substrate #47 (draft) into `codex/reliable-submit-operational-handoff-v1` (PR #12 at `99a6625`) |
| Head | `f7bb1d67a1ef1d2882a2f04e2d8aa62e8457cb04`, tree `8408ab09c56ddaa41c9087c2105fff5c6ba6ae57` |
| Previous target | `99a6625` (`33-recheck.md`), now PR #12's branch |
| `trunk_dev` | `6dbeaebdce52b85e85abc8ea3aa2473a45abfcb4` (#38), the merge base. It moved to `c610e1d` (#44) before this check began. |
| Recipe | v2, source SHA-256 `c08597e2…a1a3ca`, verified before the run |
| Trunk-relative manifest | `41ac8bad47ed08df678f48d2004edecf3c6262de4bb01a704e2938e9ddb8054b`, 70 files, textual diff `36bf4a44…c517`, upstream `origin/trunk_dev` |
| PR-relative manifest | `6d6dd5845c2eed959b2a8f9c84dfec9b085d4bf6841ffaddbadcce2029b0bea8`, 91 files, textual diff `f0951aa2…3e57`, upstream `origin/codex/reliable-submit-operational-handoff-v1` |
| Toolchain | Go 1.26.5, `GOTOOLCHAIN=local`, `env -i`, user `ci` (1500:1600) |

The evidence files:
- refs at the start and the end: `ls-remote-open.txt`, `ls-remote-close.txt`;
- provenance: `provenance-40d.txt`;
- manifests: `manifests/`, with `cmp-vs-40c.txt` and `trunk-only-files.txt`;
- the tree checks of both ci copies: `tree-check.txt`, 556 entries and 0 differences each.

## 2. The writer's questions

### 2.1 Does the guard extension keep PR #31's guarantees for `nomadClient` exactly?

Yes (`guard-cases.txt`, and a reading of `git diff -w a619076 cd615c3`).

| Self-test table | PR #31 (`0842983`) | Head | Removed | Changed |
| --- | --- | --- | --- | --- |
| accepted | 4 | 7 | none | none |
| refused | 11 | 17 | none | one: "another client without the token" now names `otherProvider`, since `operationalProvider` is a known client |
| lost-token | 4 | 8 | none | none |

For `nomadClient`, the code reads the same as before:
- its builder table is unchanged: `newJobRequest` at index 2, `get` at index 1;
- the exemptions are unchanged: a hand-built request is allowed only in `newJobRequest` and `verifyAccessControl`, and the access-control path only in `verifyAccessControl`;
- the header setter must still set `nomadTokenHeader` from the receiver's `token`;
- the deletion check is unchanged.

The access-control exemption is now tied to the type `nomadClient`, so a provider method named `verifyAccessControl` gets no exemption. A self-test case shows this.

The guard stays lexical, as PR #31's always was. It does not see a value written over the token after the builder: my mutant M1 overwrites the token on the job read, and the static half passes. The runtime test catches it, because the fake Nomad refuses the request. Each of the three requests is in that test's handoff, so the runtime half covers what the static half cannot.

### 2.2 Does `prepareRegister` change when the POST is prepared relative to the owner's lock?

No. The one changed line in `liveSender.consume` swaps `s.issuer.provider.prepareExchange(owner.context, http.MethodPost, "/v1/jobs", s.prepared)` for `s.issuer.provider.prepareRegister(owner.context, s.prepared)`. `prepareRegister` is one line: the same call with the same arguments.

Nothing else in `consume` moved. The provider's method inventory now names `prepareRegister` (one reference, from `consume`), and `prepareExchange`'s references are `prepareRegister` once and `observe` twice.

### 2.3 Does `CP-NOMAD-ACL` name everything wiring needs, and should it be part of `CP-NATIVE`?

It covers items 2 to 6 of PR #31's change list (`nomad-acl/01-implementation.md`, section 8):

| PR #31 item | Where it is now |
| --- | --- |
| 1. token header from ES's custody, never in the query, never logged | done in this round. The header and the URL rule are in code and tests, and redaction holds (probe Y1). The custody is stated in the contract's prose only (I36-1). |
| 2. namespace and grants (`submit-job`, `read-job`) set up by the ACL tool | `CP-NOMAD-ACL` |
| 3. the access-control check before `POST /v1/jobs`, over the provider's own transport | `CP-NOMAD-ACL` |
| 4. what a 401 or 403 on registration means | `CP-NOMAD-ACL`, as a choice still to make. PR #31 suggested "definite non-acceptance". |
| 5. exclusive writer of the operational namespace | `CP-NOMAD-ACL` ("no other policy may write there") |
| 6. one Nomad TLS identity for both clients | `CP-NOMAD-ACL` |
| 7. the token guard covers the provider | done in this round |

PR #31's item 2 also says `read-logs` "if lifecycle reads follow". That is conditional, and the provider reads no logs today.

I would keep it separate from `CP-NATIVE`:
- `CP-NATIVE` is one line pointing at a long paragraph of native prerequisites. Its "exact provider build/pin and writer exclusivity" overlaps, but it does not name the Nomad ACL steps.
- A separate identifier traces one external change list item by item. It is pinned against the gate on both sides, with removal mutants for each, and can be answered on its own.

### 2.4 Does a real ACL Nomad answer as the fake does?

Yes, for the status code. PR #31's report (section 5, verified on Nomad 2.1.1 in CI) found 403 in each of these cases:
- anonymous requests;
- a well-formed but unknown token;
- writes outside a granted namespace.

So a token without a grant in the operational namespace gets 403, as the fake's wrong token does. Inference: the body differs ("Permission denied" or "ACL token not found"). The provider does not read that body for a 403.

What a 403 leaves behind today is in probe Y2:
- the result is not accepted;
- the claim, grant, stage entry and durable marker are stored;
- there is no receipt;
- the provider also sent one observation GET, which got 403 too.

That is the stranded claim the writer describes. `CP-NOMAD-ACL` makes choosing its meaning a prerequisite of wiring.

## 3. Probes (`probes40d.log`)

The probes ran as `ci` on a scratch copy of the head, with one probe file (`scripts/zz_probe40d_test.go`). The mutants edited a scratch copy of the provider, which was restored and compared afterwards. Each run used:
- the static guard and the builder check;
- the provider's three token tests;
- my two probes.

| Probe | What | Result |
| --- | --- | --- |
| baseline | | all pass |
| Y1 | `fmt` of the provider, `*provider` and the domain with `%v`, `%+v`, `%#v`, `%s`, `%q`, `%x`; `json.Marshal` of the provider | every verb prints `<private execution value redacted>`, and `json.Marshal` gives `{}`. The token appears nowhere. |
| Y2 | a registration with another canonical token | not accepted, 0 jobs registered. Claims 1, grants 1, marker stored, no receipt. Two requests reached the fake, each with one token header. |
| M1 | the job read sets another token after the builder | caught by the three-request runtime test only (section 2.1) |
| M2 | the token is set in `prepareRegister` instead of `prepareExchange` | caught by the builder check and the runtime test |
| M3 | `prepareExchange` deletes the token header on GETs | caught by the builder check (deletion) and the runtime test |

The writer's 13 mutants (T1 to T7, U1, G1 to G4, C1) cover the rest of the change. I did not rerun them.

## 4. Info notes

### I36-1: `CP-NOMAD-ACL` could also name the token's custody

The owner contract says the provider's token "comes from the same startup custody as the current submit client's (`nomad.token_file`)". That sentence is prose: neither the gate's list nor a pin holds it. The constructor checks the token's form, not its source.

When someone wires the provider, the gate prints its prerequisites. The token's source is the one item of PR #31's list that the printed list does not name. One clause in `CP-NOMAD-ACL`, such as "the provider's token is the one ES loads from `nomad.token_file` at startup", would close that. It can wait for the next edit of the owner table; nothing reads the token today.

### I36-2: the guard is lexical, and the runtime test carries the rest

Covered in section 2.1. This is not new: PR #31's guard has the same limit for `nomadClient`, and its own runtime test carries the rest there.

## 5. What I did not cover

- I did not rerun the whole module. CI ran it on the head. The writer's whole-module comparisons against `trunk_dev` `6dbeaeb` and against round 32's head found no changed result (their section 4). I ran the whole `es/admission` package and the root package.
- I did not rerun the writer's 13 mutants.
- Nothing ran against a real Nomad. The provider is unwired, so no live check applies to N-1 today.
- I did not trial-merge any open PR other than `trunk_dev`.

## 6. Sensitive material

The probes are synthetic. The two tokens in them are test values, and no real token, key, certificate body, env file or config file is copied into the evidence. Commit-message trailers and author names are left out. The report and evidence were scanned with the thread's pattern list and a positive control before delivery.
