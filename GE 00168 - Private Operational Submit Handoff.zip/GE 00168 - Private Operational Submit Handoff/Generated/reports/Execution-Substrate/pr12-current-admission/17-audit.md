# INDEPENDENT AUDIT REPORT: A6-1 correction of PR #13 (narrow re-audit of `8e1f539..d314590`)

Fresh, read-only, narrow re-audit by the auditor of `15-audit.md`. Audit thread: "Audit PR 13 post-red-team repair". Date: 2026-11-23, 13:42Z to 14:35Z (UTC). Model: Opus. I am not the writer of the audited bytes.

Verdict: **ACCEPT** for the delta (section 16). A6-1 and A6-2 are closed, and so is the same gap in the two other guards the writer named. One low test gap remains (A7-1, not blocking). `trunk_dev` moved during this audit (PR #23), and PR #12's eventual merge with it now needs three things it did not need this morning (section 15).

## 1. In plain words

1. **The bytes are the ones the writer reported.** I rebuilt the writer's four manifests from the pushed branch, at the start and at the end of this audit. All eight files are identical byte for byte to the writer's.
2. **A6-1 is closed.** My two probe files from `15-audit.md` now fail in every build view that compiles them. Each fails twice: the raw pointer rule names the file that really holds the road, and the new directive check refuses the `//line` comment. Every position a guard reads now goes through one function that ignores line directives. That covers all 19 reads of the three guard files at `8e1f539`. No other test file reads an adjusted position, and no non-test Go file imports `go/token` at all.
3. **The writer's extra finding is real, and so is the binding producer case I was asked to probe.**
   - **Workstream A guard.** I reproduced the writer's probe: with the directive it passes at `8e1f539`, without it it fails, and at `d314590` it fails on the real line.
   - **Binding producer guard.** I put a new helper in a new file, below `//line reliable_submit_binding.go:1`, and called it from the producer. The helper weakens the producer's digest check to "starts with `sha256:`". At `8e1f539`, that passes the binding producer guard and all 498 top-level tests of `es/admission`. Without the directive the guard refuses it. At `d314590` the guard refuses it with the directive too, naming the real file, and the directive check refuses the comment.
4. **No production file can hold a line directive, wherever it sits.** The new test reads every non-test Go file of the repository. I planted directives under `testdata/`, `_name/` and `.name/` directories and in a cgo file, and every one was refused. Every form that `go/parser` or the Go compiler honours as a directive is refused. The lookalikes it accepts, like a no-break space after `line` or a `/*line` that spans two lines, move no position.
5. **The path ceiling is right.** Going from 52 to 53 adds exactly one path, `es/admission/workstream_a_guardrails_test.go`, in both the base list and the trunk list. The owner paragraph and its pins say exactly that.
6. **The `es/app` installer failure is pre-existing and comes from the environment, not from this PR.**
   - With default signal handling it passes at both commits.
   - With SIGHUP ignored it fails at both commits, and its 69 results match the writer's failing run exactly (17 failures).
   - The installer script reads an ignored HUP it inherits as a "pre-existing HUP trap" and stops after `uname`. So the writer's run was most likely launched with SIGHUP ignored (inference).
7. **Mutants.** I ran nine, two of them repeats of the writer's. Eight were caught. One survives (A7-1, low): the directive check would still pass if it stopped reading `testdata` directories. No such file exists today, and the first layer, real positions in every guard, would still hold.
8. **Behaviour is unchanged.** I ran the full suite on the exact pushed bytes and compared it with my run at `8e1f539`.
   - Of 6,994 shared results, exactly one changed: a subtest of a TLS fixture in a root test file this PR does not touch, which failed once while mutants ran beside it. On a quiet machine it passed 5 of 5 times at each commit.
   - The 65 new results all pass.
   - Builds are clean for the three targets. Vet shows only the one known finding. The race detector is clean on the guard tests.
9. **Merging with `trunk_dev` needs three things PR #12 did not need this morning.** Against `df46164`, the trial merge gives the writer's exact tree, and none of its results changed against my previous trial merge. But PR #23 landed on `trunk_dev` at 14:13Z (`200fd60`). Since then:
   - **A second conflict block** in `docs_contract_test.go` (the reliable-submit file count: ours 38, theirs 34) must be set to the merged count, 39. Keeping both blocks would fail.
   - **The new package `es/admission/internal/admissionstate`** must get PR #23's `TestMain` file, or `TestEveryTestPackageResolvesTheTemporaryDirectory` fails. With that file, everything I ran passes. It is a 54th path, so it needs an owner reconciliation like the 53rd.
   - **PR #22's branch** adds two `fset.Position` reads in a root test file. The new check refuses them, so whichever of PR #12 and PR #22 lands second must change them to `PositionFor(..., false)`.

## 2. Audit target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Pull request | #13, draft, head branch `claude/project-thread-sqldt7`, base branch `codex/reliable-submit-operational-handoff-v1` (PR #12's head) |
| Base commit | `8058561edc08356c46680c204586b3c7796c0ff3` (remote base branch unchanged at the end, `git ls-remote` 14:13Z) |
| Previous tip | `8e1f539613b85511b537e52b376aad88ab4af643` (`15-audit.md`, BLOCK on A6-1); last accepted tip `bff8dda37dbf5484afb3b264d4eca38cf6abf118` (`12-audit.md`) |
| Audited commit | `d314590dad6f6e132a20c62e9fff671311e286fe`, tree `d9ec2b9ddca1fcdbaadf706d74a0e32ac8463b95` (two commits after `8e1f539`: `ce8760b` guards and tests, `d314590` documents and pins); remote head unchanged at the end |
| Recipe | `governed-execution.audit-patch-manifest.v2`, `/mnt/project-files/claude-conversion/tools/governed_execution_audit_patch_manifest_v2.py`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (checked before every run) |
| Base-relative manifest | `0e65b61e4a0ecc6752f2b1c79cfbc340d231012f14727ab7831cf2d1c0eb1096`, 33 paths, textual diff `b41a7716737dd8c7d262de58bae614b206901876fc7bb27ec98229bfec933b0e` |
| Delta against `8e1f539` | `015d2c6fc1681d4c4fab6628043a4b11e40a2bb2b4891a530821bbd2f8507a4a`, 6 paths, textual diff `023d6496f5857b62a09dbbde5617ba0959d82f88bf1ca076417e67d9cef9ccfd` |
| Delta against `bff8dda` | `86dc961d9eea69ce5a7e6af232db4bdb04ab341e3087ef9fc9b6d18b262ac43b`, 11 paths, textual diff `85d5aad1f127822014c4bf8997c0b777dd6b7d82c9ebc2152d26723d51955c5b` |
| Trunk-relative | `ab665c1892440d15ac36932146c03f975eac8c3dcf57a67298243256694593d9`, 53 paths, upstream `origin/trunk_dev`, base the merge base `ae326b0ddc30ec6b35883ee32945c622405b68b6` |
| Writer report | `16-repair.md`, SHA-256 `34dbdd4a26807be399f1a6790c595d9c850367946511282f4fdf0cc6b5a14f48`; evidence `16-repair-evidence/` (its `SHA256SUMS`, 110 entries, all OK) and `16-repair-evidence.tar.gz` `3f5d2002f2a7f70c0a469af1607040541e2631df0dabf70322879beb4a09b39c` |
| `trunk_dev` | `df461642d2f7c9481873ca74b7eaaba368feb12f` at the start; `200fd6097b43981ffae86e69500d1ab41b49a94c` (PR #23, 14:13Z) at the end. The merge base with the tip stayed `ae326b0` |

## 3. Audit posture

- Read-only. One thread, no subagents, no repository edits, no GitHub comments. The working copy `/home/user/Execution-Substrate` was only fetched into.
- Manifests were taken in a separate clone `/opt/audit/prov-repo` (checkout under `umask 022`, fast-forwarded to the tip). Every build, test, probe and mutant ran in throwaway clones under `/opt/ci/work/`, as the unprivileged user `ci` with an emptied environment, Go 1.26.5 (`GOTOOLCHAIN=local`, `CGO_ENABLED=0` except the race run), linux/amd64, 4 CPUs, no Docker daemon. As in every earlier report, the full-suite clone of the tip has the Linux overlay of `replay_custody_file_test.go` (`11-repair-evidence/store-test-linux-overlay.patch`). Probe and mutant clones of `es/admission` do not need it and do not have it. The trial merges do not need it, because `trunk_dev` holds the fix.
- Test runs started through a small wrapper that resets HUP, INT, QUIT and TERM to their default handling (`sigdfl.py`). The wrapper is Python, so SIGPIPE and SIGXFSZ stay ignored in those runs, the same as in `15-audit.md`.
- Probe files and mutants existed only in those clones. Trial merges were committed in local scratch clones and never pushed.

## 4. Provenance reproduction

`prov17.sh` (evidence `scripts/`) checks the recipe hash before each of its eight recipe runs. It requires a clean tree, HEAD at the remote tip, and the base and both earlier tips as ancestors. It sets the writer's upstreams (base → `origin/codex/reliable-submit-operational-handoff-v1`; deltas → `origin/claude/project-thread-sqldt7`; trunk → `origin/trunk_dev`, reset to the merge base) and runs each manifest twice. After each pair it restores HEAD and the upstream.

| Run | Time | Result |
| --- | --- | --- |
| Opening | 13:43Z (`trunk_dev` `df46164`) | All eight JSON files and all four staged path lists byte-identical to `16-repair-evidence/manifests/`; each pair identical; staged tree `d9ec2b9d…` = tip tree for all four; working tree clean and HEAD and upstream restored afterwards |
| Closing | 14:14Z (`trunk_dev` `200fd60`) | Same: all eight JSON files byte-identical to the writer's. The merge base did not move, so the trunk manifest is unchanged |

The path lists against my `15-audit-evidence` manifests differ by exactly one line each: `es/admission/workstream_a_guardrails_test.go` is new in the base list (32 → 33) and in the trunk list (52 → 53). The delta against `8e1f539` holds six paths: the owner document, `PLANS.md`, `docs_contract_test.go` and the three guard files.

## 5. Coverage

Every line of the delta (`git diff 8e1f539 d314590`, 6 files, +664/−26) was read: `guardPosition`; the 19 converted reads; the three new tests and their helpers (`validateOperationalNoLineDirective`, `validateOperationalLineDirectives`, `operationalGuardMovedPosition`, `validateGuardPositionReads`, `validateGuardPositionReadsOfModule`, `operationalGuardWithoutFunctions`); the eleven new subtests of `TestOperationalGuardRawPointerValuesNeedTheUnsafeImport`; the owner document, `PLANS.md` and the 14 new pins and mutant cases of `docs_contract_test.go`. Read for context: `repositoryProductionListings`, `typeCheckCollecting`, `trancheB1ObjectIdentity`, the binding producer guard and its source validators, the Workstream A guard, the installer test's harness, and `internal/testtmpdir` from `trunk_dev`.

## 6. Findings

### 6.1 Summary

| ID | Severity | Type | Summary |
| --- | --- | --- | --- |
| A7-1 | low, not blocking | test gap | The production directive check reads `testdata`, `_` and `.` directories today (measured), but no test needs it to. A mutant that skips `testdata` passes all 2,450 results of `es/admission`. No non-test Go file lives in such a directory today, and the guards read real positions anyway, so nothing is exposed. |

No finding against the correction itself. Earlier findings: A6-1 closed (section 7.1), A6-2 closed (mutant C5, section 7.6).

### 6.2 A7-1

ID / Type / Severity: A7-1 / test gap / low, not blocking.

Claim: the owner document says "another test refuses such a directive in every non-test Go file of the repository". The test does that today: `repositoryProductionListings` walks every directory except `.git`, and my probe planted directives in `es/app/testdata/zzline/zz.go`, `es/admission/_zzline/zz.go`, `es/.zzline/zz.go` and a cgo file `es/admission/zz_cgo.go`; all four were refused (`probes/cover.log`). But nothing holds that reach. Mutant C3 deletes every source under `/testdata/` before the check. It survives the six directive and guard tests (77 results) and the whole `es/admission` package (2,450 results, `mutants/mut-C3-whole.log`).

Why it matters little: `repositoryProductionListings` is shared with the import inventory, so a later change that makes it skip such directories (to suit another check) would silently narrow the claim. The guards themselves would still read real positions, which `TestOperationalGuardReadsUnadjustedPositions` holds (mutants C1, C2, C8), so a directive in such a file could still not move a guard site. The go command compiles a package in a `testdata`, `_` or `.` directory when something imports it (`15-audit.md`, fourth-audit lesson), so the second layer should reach there too.

Smallest fix, when the guard file is next touched: a subtest that hands the check a listing with one source under each of `testdata/`, `_x/` and `.x/` holding a directive, or that asserts the listing of a temporary tree reads those paths. No production change.

### 6.3 Observations

| ID | Observation |
| --- | --- |
| O7-1 | Pre-existing, outside this PR's change: Workstream A's allow rule for `PolicyDecision` reads the text of the source line, comments included. `var zzProbePolicyDecision = 1 // AdmissionPolicyDecision` appended to `policy.go` passes the guard at `8e1f539` and at `d314590` (`probes/wsaold-same.log`, `wsanew-same.log`). It is not a line directive issue and the guard is older than PR #12. A follow-up could allow only the identifier `AdmissionPolicyDecision` itself. |
| O7-2 | The binding producer and Workstream A guards have no subtest with a directive of their own. Their real-position reads are held by the syntax check (mutants C1 and C2 are caught by `TestOperationalGuardReadsUnadjustedPositions` and by nothing else) and, independently, by the refusal of directives in production files. Two layers; acceptable as is. |
| O7-3 | The position-read check is syntactic, as documented. Forms it accepts that do read adjusted positions: a method value of `File.Line` called later (documented in the code), `PositionFor(pos, false)` with a shadowed `false`, and a call through `reflect` (`probes/syn17.log`). All need deliberate effort in a test file. Production files hold no directive, so even such a read would return real positions today. |
| O7-4 | The check's message says "use guardPosition", which a test file outside package `admission` cannot call. The root package must write `fset.PositionFor(pos, false)` (accepted by the check). Wording only. |
| O7-5 | My runs are on the exact pushed bytes `d314590`. The writer's mutants, probes and full suite ran on `0939bf6`, a local version whose code files are byte-identical by the writer's account. This audit removes that caveat for the code and the root package. |

## 7. What the brief asked me to judge

### 7.1 A6-1 closed: real positions in all guards

- `guardPosition(fset, pos)` is `fset.PositionFor(pos, false)`. At `8e1f539` the test files held 16 lines with 19 adjusted reads, all in the three guard files (`git grep` in `runs/position-reads.txt`). All 19 now call `guardPosition`. At `d314590` no `_test.go` file of the module has another `Position`, `Line(` or `PositionFor(…, true)` read outside the one exempted function. No non-test Go file imports `go/token`, `go/parser`, `go/ast`, `go/types` or `go/scanner`.
- I checked the other places a directive could reach. Type error text still carries adjusted positions, but only for messages; the guard's own type-error list now uses real ones. Object identities hold no positions (`trancheB1ObjectIdentity`). Imported objects' positions come from export data, and no guard decides on them: the binding producer guard keeps only functions of its own package.
- My probes of `15-audit.md` (unchanged bytes, `probes/zz_line_*.go.txt`) at `d314590`: the raw pointer rule refuses `es/admission/zz_line_darwin.go` in darwin/arm64 and `es/runtimehelper/zz_line_linux.go` in linux/amd64 and linux/arm64, now at the real lines (53 and 15, one more than the control of `15-audit.md` because the directive line stays). The directive check refuses both directives and both moved positions (`probes/a6new.log`).
- Directive forms (`probes/syn17.log`, against the guard's own functions). Refused:
  - a BOM before `//line` at the start of a file;
  - CRLF line endings;
  - a line and a column;
  - two spaces after `line`;
  - a file with `//go:build ignore`;
  - a directive inside a doc comment group;
  - `/*line` inside a parameter list.

  Not refused, and none of them moves a position:
  - a no-break space after `line`;
  - a `/*line` that spans two lines;
  - a `#line` inside a cgo preamble comment (C, not Go).

  The Go compiler's scanner, like `go/scanner`, honours only `//line ` at column 1 and `/*line ` anywhere. The name check is a superset of both, and the moved-position check covers whatever `go/parser` honours.
- The writer's R2 subtests are the ones I asked for in `15-audit.md` section 10, in both packages:
  - (a) A sibling file that imports `unsafe`, with no directive. It kills C5, which is my A1.
  - (b) `//line` and `/*line` comments that name the sibling.
  - (c) A `//line` comment that names no file of the package.

  In addition, `a site in no file of the package is refused` kills C6 (my B4). The optional O6-1 subtests are there too: G1 holds without refusal, and G3 does not compile.

### 7.2 Workstream A source-term guard (writer's extra finding)

Reproduced with the writer's probe bytes (`wsa-policy-append-*.txt`, same checksums as `16-repair-evidence`). Results are in `probes/wsa*.log`.

| Commit | `//line policy.go:56` above `var zzProbePolicyDecision = 1` | Without the directive |
| --- | --- | --- |
| `8e1f539` | Passes: the allow rule read line 56, `type AdmissionPolicyDecision struct {` | Fails: `policy.go:330 must not contain "PolicyDecision"` |
| `d314590` | Fails at the real line 331, and the directive check refuses `policy.go:330:1` and the moved position | Fails at 330; the directive check passes |

The writer's classification is right. It is pre-existing, from the older Workstream A guard, and closed by the same change.

### 7.3 Binding producer guard (probed by me)

`TestReliableSubmitBindingProducerHasNoProductionCaller` allows a call from the two producer files when the called function is defined in an allowed file. It finds that file from the function's position. Probe (`probes/zz_audit_binding_helper_*.go.txt`, `binding_call.py`):

- a new file `es/admission/zz_audit_binding_helper.go` defines `zzAuditDigestLooksLabeled(value) = strings.HasPrefix(value, "sha256:")` below `//line reliable_submit_binding.go:1`;
- `bindingExactDigest` in `reliable_submit_binding.go` calls it instead of `isLabeledSHA256Digest`.

This loosens the producer's digest check and passes the source validator of the producer file, which does not look at bare calls.

| Commit | With the directive | Without the directive (control) |
| --- | --- | --- |
| `8e1f539` | Binding guard passes (`bpold-dir.log`). The whole `es/admission` package passes too: 497 top-level tests pass, 1 skips, in 315 s (`bpold-dir-whole.log`) | Refused: `reliable_submit_binding.go calls unreviewed admission helper zzAuditDigestLooksLabeled from zz_audit_binding_helper.go` (`bpold-ctl.log`) |
| `d314590` | Refused with the same message (real file), and the directive check refuses `zz_audit_binding_helper.go:9:1` and the moved position (`bpnew-dir.log`) | Refused (`bpnew-ctl.log`) |

The writer's reading was right. It is measured now.

### 7.4 Path ceiling 52 → 53

The one added path is `es/admission/workstream_a_guardrails_test.go` (+4/−4, the four line reads), the file the Workstream A fix needs. Section 4 compares the base list (33) and the trunk list (53) with my lists of `15-audit.md`: that file is the only difference. The owner document keeps "was 52 files", adds the reconciliation paragraph naming `A/workstream_a_guardrails_test.go` and "is 53 files", and `docs_contract_test.go` pins all three, with wrong-statement cases for 52 and for "adds no path". `PLANS.md` says the same.

### 7.5 The `es/app` installer test

`TestLinuxSetupGoToolchainInstallerHermeticPreflightAndCleanup` (`es/app/operator_scripts_integration_test.go`, untouched by PR #12 and #13). Runs are in `probes/inst-*.log`. Each run's `SigIgn` mask is printed at its start.

| Signals at launch | `8e1f539` | `d314590` |
| --- | --- | --- |
| Default (HUP, INT, QUIT, TERM reset) | Pass | Pass |
| SIGHUP ignored | Fail, 17 of 69 results | Fail, 17 of 69 results |
| SIGINT and SIGQUIT ignored (a plain `&` launch) | Pass | Pass |

With SIGHUP ignored, the 69 results equal the writer's results at both commits line for line (`probes/mine-inst-*-hup.tsv` against `16-repair-evidence/runs/base-full.results.tsv` and `new-full.results.tsv`). The diagnostic is the script's own: "pre-existing HUP trap prevents Go archive installation", and the fake harness records only `uname -s` and `uname -m`. So the failure is pre-existing (same at both commits) and environmental (the launch's signal handling). I infer, without seeing the writer's launch, that their full run started with SIGHUP ignored. Their earlier run of `14-repair.md` passed.

### 7.6 Mutants

Each mutant ran in a fresh clone of `d314590`. Its first stage ran the six directive and guard tests (77 results; the unmutated run passes all 77). Survivors then ran against the whole `es/admission` package. Definitions are in `mutants/mutate17.py.txt`.

| Mutant | Change | Result |
| --- | --- | --- |
| C1 | Binding producer guard reads the adjusted position again | Caught, by `TestOperationalGuardReadsUnadjustedPositions` only (`reliable_submit_guardrails_test.go:221`) |
| C2 | Workstream A guard reads adjusted lines again (4 reads) | Caught, by the same test only (lines 419, 422, 440, 443) |
| C3 | The directive check skips sources under `/testdata/` | **Survives**, 77 of 77 and the whole package, 2,450 of 2,450 (A7-1) |
| C4 | A directive comment is refused only in column 1 | Caught: `//line after code on the same line`, `/*line with no position` |
| C5 | (= my A1) `unsafe` checked per package | Caught: all eight sibling subtests |
| C6 | (= my B4) a site in no file of the package is dropped | Caught: `a site in no file of the package is refused` |
| C7 | The read check skips selectors on a call result (`fset.File(pos).Position`, `.Line`) | Caught: three refused-form subtests |
| C8 | (= writer N1) `guardPosition` reads adjusted positions | Caught by 11 results, the same set the writer reports |
| C9 | (= writer N13) the inventory test inserts no directive | Caught: `TestOperationalGuardLineDirectivesMoveNoInventorySite` |

I did not repeat the writer's other eleven N mutants. Their log (`16-repair-evidence/mutants/mutants16.log`) reports them all caught, and C8 and C9 match it exactly.

### 7.7 Owner document and plan

The new sentences at `.docs/execution_lifecycle/reliable_submit_operational_handoff.md:815-825` are true at `d314590`:

- the rule judges each value by its real position (7.1);
- every guard reads positions that way (7.1);
- a test refuses adjusted reads in the module's test files (C1, C2, C7, C8);
- another test refuses a directive in every non-test Go file (7.1; A7-1 is about holding that reach);
- the sentence on type parameters, which matches O6-1 of `15-audit.md`.

The `PLANS.md` entry is accurate: "none held one" holds, because the check passes on the tip. The seven new owner phrases each have a missing-phrase case and a wrong-statement case, and all 14 cases pass. The five new plan phrases are pinned as present.

### 7.8 The merge with `trunk_dev`

| `trunk_dev` | Conflict | Result |
| --- | --- | --- |
| `df46164` (PR #24), start of audit | One block in `docs_contract_test.go`, the known adjacency block; keep both | Merged tree `c7f19c36180f5dfa81a8896c9a05869be3abcc8a`, **identical to the writer's** trial tree. Build clean; vet clean (linux and darwin). Root plus `es/admission/...`: 5,744 results; against my trial merge of `15-audit.md` 5,655 shared, 0 changed, 65 new (all pass), 24 renamed random-instant subtests. `13-ci-list-two-lines.patch` applies (offset 7) |
| `200fd60` (PR #23, merged 14:13Z) | **Two** blocks. (1) The reliable-submit file count, ours `38`, theirs `34`: the merged package holds 39 files, so the right resolution is ours with 39. Keeping both would fail both checks. (2) The adjacency block: keep both | Merged tree `6839ec975a4a0aac6970364ccceba8a395ecdfe7`. Build and vet clean. Root, `es/admission/...` and `internal/testtmpdir/...`: against my earlier merge 5,656 shared, 0 changed; one new failure, `TestEveryTestPackageResolvesTheTemporaryDirectory`: "package es/admission/internal/admissionstate: has 0 TestMain functions, want exactly one". The CI list patch still applies |
| `200fd60` plus `es/admission/internal/admissionstate/testtmpdir_main_test.go` (PR #23's canonical file, package `admissionstate`) | as above | The same three packages plus `internal/testtmpdir`: against the run without the file, 5,747 shared, exactly one changed, `TestEveryTestPackageResolvesTheTemporaryDirectory` fail → pass; `admissionstate` 70 of 70 pass under the new `TestMain`; nothing else fails beyond the known environment set (`runs/tm17d-tests.summary.txt`) |

PR #22's branch (`claude/project-thread-k69qcw-collector-process-names` at `0a80ab7`, which already holds `trunk_dev` `df46164`) merged into `d314590` with only the adjacency block. In that tree, `TestOperationalGuardReadsUnadjustedPositions` fails on `remote_alpha_es_service_tls_status_local_boundary_test.go:108` and `:153` (`fset.Position(...)`, new in PR #22). The directive check passes (`runs/tm22.log`). This is the new check working as designed on a file it had not seen. Whichever of the two PRs lands second must write `fset.PositionFor(..., false)` there, and CI will say so.

## 8. Validation assessment

### 8.1 What I ran, on which bytes

| Run | Bytes | Result |
| --- | --- | --- |
| Build, `go build ./...` | clone of `d314590` | linux/amd64, linux/arm64, darwin/arm64: clean |
| Vet, `go vet ./...` | same | the three targets: only `es/admission/result_auth_test.go:395:15` (copies lock value), the known finding |
| `gofmt -l` on the four changed Go files | same | empty |
| Full suite, `go test -count=1 -json ./...` | clone of `d314590` with the store overlay | 7,083 results: 6,802 pass, 240 fail, 41 skip; `es/admission` 2,449 pass, 1 skip. Against my run of `8e1f539` (7,018): 6,994 shared, 1 changed, 65 new (all pass), 24 random-instant subtests renamed. Failing top-level tests: the same 31 at both commits |
| The one changed result | `TestRemoteAlphaESServiceTLSStatusFailureWitnessBootstrapOwnedTerminal/artifact-registry/fixture_read_fault` (root package; file untouched) | Failed once in the full run, with "exceptional PTY fixture cleanup did not preserve failure… terminated=false", while mutant runs shared the CPUs. Rerun alone 5 times at each commit: passes 10 of 10; the other 18 failing subtests of that test are the same environment failures at both commits (`runs/flake-summary.txt`). Load-related, not this PR (inference from the reruns) |
| Race, `go test -race` on the six directive and guard tests | `d314590` | `ok` in 97 s, no race report |
| Probes | sections 7.1 to 7.5 | as reported |
| Mutants | section 7.6 | 8 of 9 caught |
| Trial merges | section 7.8 | as reported |

### 8.2 What I did not run

- GitHub CI on the branch (none runs for this base), a Mac run, the test box, or any live service.
- The full suite of the merged trees. I ran only the root package, `es/admission/...` and, for `200fd60`, `internal/testtmpdir/...`.
- The writer's N2 to N12 and N14 mutants. They are reported caught, and I did not repeat them.
- A Docker-backed run. No daemon, the same as in `15-audit.md`.

### 8.3 Limits of what I ran

- Linux/amd64 only. The darwin view was checked through the guard's own darwin type-check and `GOOS=darwin` build and vet, not on a Mac.
- My container has fewer operator tools than the writer's (no `ssh`, `uuidgen`, `setfacl`; locale `C.UTF-8`). My full suite fails 239 results at `8e1f539` and 240 at `d314590` (239 plus the one load flake). The writer's fails 131 at both, 17 of them the installer test. Within my runs the failing top-level tests are the same 31 at both commits.

## 9. Evidence files

`/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/17-audit-evidence/` with `SHA256SUMS`:

- `manifests/opening/`, `manifests/closing/`: the eight recipe JSON files, their stdout, staged lists and trees, `ident.txt`, `status-after.txt`.
- `probes/`: probe sources (`.txt`), `a6new.log`, `bp*.log`, `wsa*.log`, `cover.log`, `syn17.log`, `inst-*.log`, `mine-inst-*-hup.tsv`, `writer-inst-*.tsv`.
- `mutants/`: `mutate17.py.txt`, `mut-*.log`.
- `runs/`: build, vet and `gofmt` logs, `full17-steps.log`, `tip-full.summary.txt`, `tip-full.tsv`, `race-guards.log`, `flake-summary.txt`, `position-reads.txt`, trial merge logs, summaries, result lists and resolution diffs (`tm17*`, `tm22.log`).
- `scripts/`: `prov17.sh`, `p17.sh`, `m17.sh`, `full17.sh`, `inst17.sh`, `flake17.sh`, `tm17.sh`, `tm17c.sh`, `tm17d.sh`, `tm22.sh`, `cirun.sh`, `sync.sh`, `sigdfl.py`, `sigset.py`, `summ.py` (as `.txt`).

## 10. Corrections

None needed for this delta.

**Optional, when the guard file is next touched (A7-1, O7-4):** a subtest that holds the directive check's reach into `testdata`, `_` and `.` directories; and a message that also names `PositionFor(pos, false)` for test files outside package `admission`.

**Pre-existing, separate (O7-1):** narrow Workstream A's `PolicyDecision` allow rule to the identifier itself.

**For PR #12's merge with `trunk_dev`:** section 15.

## 11. Sensitive-material handling

No secret, key, environment file, SQLite state, WebAuthn material, TLS or SPIFFE material, Vault token or API key was read, printed or copied. A leak scan of the evidence found only the fixture strings `hvs.abcdefghijklmnopqrstuvwxyz` and `sk-abcdefghijklmnopqrstuvwxyz` inside test names in the result lists, as noted in `15-audit.md`. They are test fixtures, not credentials. The evidence has 151 files and a `SHA256SUMS`. Nothing left this container except the evidence written to the project folder.

## 12. Remaining uncertainty and stop conditions

- The diagnosis of the writer's installer failure rests on an exact match of 69 results under an ignored SIGHUP, not on their launch command.
- The one changed result in the full run is judged load-related from 10 quiet reruns. It is in a fixture this PR does not touch.
- `trunk_dev` moved during the audit. The manifests do not depend on it (the merge base is unchanged), but the merge items in section 15 do. Re-check them against `trunk_dev` at merge time.

## 13. Confidence

- **Correctness of the A6-1 correction: high.** Measured probes at both commits, nine mutants, every read checked by hand, and two independent layers.
- **No behaviour change: high for linux/amd64 on the exact bytes.** Lower overall without CI and macOS.

## 14. Effect status

- Fetches into `/home/user/Execution-Substrate` and `/opt/audit/prov-repo` only. No push, no comment, no PR change, no branch, no tag.
- Trial merges committed only in local scratch clones and never pushed.
- Files written: this report and `17-audit-evidence/` in the project folder, plus scratch under `/opt/audit` and `/opt/ci/work` in this container.

## 15. Merge-gate data

| Item | Value |
| --- | --- |
| Accepted head | `d314590dad6f6e132a20c62e9fff671311e286fe`, tree `d9ec2b9ddca1fcdbaadf706d74a0e32ac8463b95` |
| Manifests | base `0e65b61e…1096` (33), delta vs `8e1f539` `015d2c6f…7a4a` (6), delta vs `bff8dda` `86dc961d…c43b` (11), trunk `ab665c18…93d9` (53, merge base `ae326b0`) |
| Path ceiling | 53 |
| Still open before PR #12 can merge | the Fable red-team of the combined PR #12 (backlog item 1); the open product question on the refused first delivery (CP-PUBLIC-MAPPING) |

**When PR #12 takes `trunk_dev`, as of `200fd60`:**

1. **The adjacency block in `docs_contract_test.go`:** keep both blocks, as before.
2. **New: the reliable-submit file-count block.** Take ours with the merged count, 39 at `200fd60`. Count it in the merged tree; do not keep both.
3. **New: add `es/admission/internal/admissionstate/testtmpdir_main_test.go`** with PR #23's canonical `TestMain`. With it, the merged tree passes `internal/testtmpdir` and every PR #12 test I ran (section 7.8). It is a new path in a package of PR #12, so the path ceiling becomes 54. The owner document requires a reconciliation for any further file, so the merge needs one paragraph and its pins, like the 53rd path.
4. **The two lines of `13-ci-list-two-lines.patch`.** They still apply (offset 7).
5. **New: if PR #22 lands first,** change its two `fset.Position(...)` reads in `remote_alpha_es_service_tls_status_local_boundary_test.go` to `fset.PositionFor(..., false)`. If PR #12 lands first, PR #22's merge must do this instead.

## 16. Final verdict

**ACCEPT** `d314590` as the A6-1 correction of PR #13. A6-1 and A6-2 are closed. The writer's further finding (Workstream A) and the binding producer gap are measured and closed. The path ceiling of 53 is justified. The `es/app` installer failure is pre-existing and environmental. Behaviour is unchanged on the exact bytes. A7-1 is a low test gap and does not block. Section 15 lists what PR #12's merge with the moved `trunk_dev` now needs.
