# PR #12 repair after the red-team re-check: driver strings Nomad would rewrite (RC31-1) and memory Nomad would refuse (RC31-2), with `trunk_dev` `4c991ba`

Status of this file: **REPAIR REPORT, NOT AUDITED.** It covers four commits and one merge after `75d0f5c` on draft PR [#40](https://github.com/evo-agi/Execution-Substrate/pull/40) into PR #12's branch. `31-redteam-recheck.md` is the report that asked for them. The coordinator asked for a diff-only check of this repair. Round 31's A30-1 repair (`31-repair.md`) already has its own: `32-recheck.md` accepts it at `75d0f5c`, so this check can start from `75d0f5c`.

Written by the PR #13 writer thread on 2026-11-24 (UTC).

---

## 1. In plain words

1. **RC31-1: an argument or a mount target now reaches the workload exactly as ES admitted it.** Nomad's client reads each string of a task's driver configuration with HCL. HCL drops a byte order mark (U+FEFF) at the start of the string and rewrites the string to Unicode Normalization Form C (NFC). So an argument with an invisible mark in front ran without it, a Greek question mark ran as `;`, and two mount targets that ES saw as different paths were one path for the container. ES now refuses, in each argument and each mount target, a leading U+FEFF, a string that is not in NFC, and a code point that is not assigned in the Unicode version of ES's own normalization tables (15.0.0). The last condition makes the rule hold for any later Nomad too: Unicode promises that a string of assigned code points in NFC stays in NFC under every later version. So nothing needs re-checking when Nomad is upgraded.
2. **RC31-2: a request with less than 10 MB of memory is refused before it takes a claim.** ES accepted `resources.memory_mb` from 1, Nomad refuses a task with less than 10, and on the private path such a request took a claim that then stayed ambiguous for good. The validation both paths share now refuses below 10: `400 invalid_request` on the ordinary path, no claim and nothing sent on the private path.
3. **The red-team's tests are adopted byte for byte.** All 18 of their subtests fail before the fix and pass after.
4. **17 mutants of the new rules, 17 caught.** Two of them first survived (NFKC instead of NFC, and the assigned set of an older Unicode version). Both made ES refuse strings Nomad keeps. I added one test case for each, and both are now caught.
5. **`trunk_dev` `4c991ba` is merged in.** The coordinator named `725c97a` (PR #41); PR #37 and PR #39 landed after it, so the head takes all three. The merge is git's own. PR #39 moved the root script tests to `scripts/`, including one file PR #12 changes, and added a test that reads positions PR #12's guard refuses. That test now reads the real position, as PR #22's root test did in an earlier round.
6. **The path ceiling of PR #12 plus its repairs goes from 66 to 69 files:** `go.mod` (where `golang.org/x/text` moves from indirect to direct at the version already selected), the red-team's new test file, and PR #39's `internal/testutil/testutil_test.go`. An owner reconciliation paragraph names all three and the moved file, pinned like the earlier ones.
7. **This changes behaviour and the public request contract.** Both contracts documents state the new refusals.
8. **The live checks for the box are now one list**, in [`box-live-checks.md`](box-live-checks.md): round 29's five RT28-1 inputs plus the red-team's seven new ones. It needs David's go.
9. **Separately, the reliablesubmit failure in PR #34's CI is a flaky test, now fixed in PR [#44](https://github.com/evo-agi/Execution-Substrate/pull/44) into `trunk_dev`** (section 9). It does not touch PR #12's files.

## 2. Identity

| Field | Value |
| --- | --- |
| Objective | Close RC31-1 and RC31-2 (`31-redteam-recheck.md`), adopt the re-check's tests, take up `trunk_dev`, gather the box checks |
| Repository | `evo-agi/Execution-Substrate` |
| Base | `codex/reliable-submit-operational-handoff-v1` (PR #12) at `44166998d4ef0d7b86152f3f66265b906f7d612a` |
| Topic branch | `claude/project-thread-ne9cwa-pr12-trunk-dev`, draft PR [#40](https://github.com/evo-agi/Execution-Substrate/pull/40) |
| Previous head | `75d0f5c1c858365bf1f68e7e3887405665f0e29f` (round 31) |
| Head | `99a66256be1b238d5bd5487a9926abe044f03028`, tree `11da794471b628481c1972f3663bc9f84cd9cc2f` |
| `trunk_dev` | `4c991ba1c43ac135d9d94853696d14a21523a690` (PR #39), fetched again before the push and before the manifests |
| Scope | 69 paths against `trunk_dev` (66 before) |
| Toolchain | Go 1.26.5 (`GOTOOLCHAIN=local`), linux/amd64 container, unprivileged user `ci`, emptied environment |
| Recipe | `governed_execution_audit_patch_manifest_v2.py`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked before every run |

Commits, oldest first:

| Commit | What |
| --- | --- |
| `085b19a` | The re-check's finding tests, unchanged (`31-redteam-recheck-finding-tests.patch`) |
| `a8d5397` | RC31-1 and RC31-2: refuse driver strings Nomad would rewrite and memory Nomad would refuse; the two `x/text` packages join the reviewed dependency list |
| `e2ea71f` | Merge `trunk_dev` `4c991ba` (PRs #41, #37, #39) |
| `481556b` | PR #39's `internal/testutil/testutil_test.go`: its three problem reports read the real position |
| `99a6625` | Contracts documents, owner reconciliation of 69 paths, `PLANS.md`, docs pins |

"Unchanged" is checked: the patch (SHA-256 `08fcb0f7…c5a6`) applied with `git apply --cached` to `75d0f5c` gives exactly `085b19a`'s tree, `35487151…` (`commits/adoption-check.txt`). `git merge-tree --write-tree a8d5397 4c991ba` gives exactly the merge commit's tree, `d7b38051…` (`commits/merge-check.txt`).

## 3. The change

### 3.1 RC31-1 (`es/admission/service.go`, `es/admission/mounts.go`)

`nomadKeepsDriverString(s)` returns false when:

- `s` begins with U+FEFF;
- `s` is not in NFC by `norm.NFC.IsNormalString`;
- `s` holds a code point above ASCII that is not in `rangetable.Assigned(norm.Version)`. If x/text had no such table, the function would refuse every string that is not ASCII, so it fails closed.

It runs right after round 29's template check, for each argument in `validateInvocationAgainstManifest` and for the cleaned target in `normalizeRuntimeMountTargetPath`. The refusal says `invocation.argv must be in Unicode Normalization Form C, use only code points assigned in Unicode 15.0.0 and not begin with a byte order mark, or Nomad would not pass it on as written`, and the same for `mount target_path`. (A first wording said "hold only"; ES's guard against Control Plane vocabulary refuses the word "hold" in an ES string, and the first full run caught it.)

Scope, from the red-team's reading of Nomad: only the arguments and the mount targets are driver configuration. Environment keys and values and `output_id` do not pass through HCL or cty, so they are not held to this rule. A mount target must begin with `/execution/mounts/`, so a leading mark can occur only in an argument; NFC and the assigned set apply to both.

Why refuse and not normalize: ES binds, records and shows the policy the caller's own string. Normalizing would change it without telling the caller, which round 29 already chose not to do for `${`.

Why the assigned set: the red-team showed that "is in NFC" depends on the Unicode version of the tables (their section 5.1). ES's `x/text` v0.17.0 with Go 1.26.5 uses 15.0.0. Nomad v2.1.1 names `x/text` v0.43.0, which uses 15.0.0 below Go 1.27 and 17.0.0 from Go 1.27 on. A string of code points assigned in 15.0.0 that is in NFC under 15.0.0 stays in NFC under every later version, by Unicode's normalization stability policy. A Nomad with newer tables then cannot rewrite it either.

### 3.2 RC31-2 (`es/admission/service.go`)

`validatePrepareRequest` now refuses `resources.memory_mb` below `nomadMinimumMemoryMB` (10, Nomad v2.1.1's `structs.MinResources`), with `resources.memory_mb must be at least 10, the least memory Nomad registers a task with`. It was `<= 0`. The reliable contract's own wire check (`reliable_submit_contract.go:82`, positive values) is unchanged; values 1 to 9 pass it and are then refused by the shared validation, before the claim. An omitted `resources` still resolves to the defaults, 128 MB.

### 3.3 Dependencies

- `golang.org/x/text` was already selected at v0.17.0, and already compiled into every package that imports grpc, through `golang.org/x/net/idna`, which imports `x/text/unicode/norm` (`go list -deps` at `75d0f5c`). `go.mod` now lists it as a direct requirement. Its version and `go.sum` are unchanged.
- The reviewed dependency list (`operationalGuardReviewedDependencyPackages` in `workstream_c_guardrails_test.go`) gains `golang.org/x/text/unicode/norm` and `golang.org/x/text/unicode/rangetable` at `golang.org/x/text@v0.17.0`. The list claims that the exported API of each listed package gives no raw access to memory. I checked: no file of `norm`, `rangetable` or `transform` (which `norm` imports) that builds imports `unsafe`, `reflect`, `syscall` or `C`. `rangetable/gen.go` imports `reflect`; it carries `//go:build ignore` and runs only through `go:generate`.

### 3.4 Tests

- **The re-check's file** `nomad_request_strings_redteam31_finding_test.go` (3 tests, 18 subtests): the six rewritten strings as arguments on both paths, mount targets that differ only in normal form, and `memory_mb` 1 and 9 on both paths.
- **`TestNomadKeepsDriverStringRefusesWhatNomadWouldRewrite`** (mine). It requires these to be kept: a composed letter, emoji of Unicode 6.0 and of 15.0, U+2028, U+FFFD, the ligature U+FB01, a mark after the start, and ASCII control bytes. It requires these to be refused: a mark alone, U+0378 (never assigned), U+FFFE (a noncharacter), U+1FAE9 (assigned in 16.0), and the red-team's six.
- **`TestValidatePrepareRequestRefusesMemoryBelowNomadMinimum`** (mine): 0 and 9 refused with the message, 10 accepted.
- **A round 28 red-team file changes by one value:** in `reliable_submit_operational_admission_redteam3_codec_test.go`, the table of extreme valid requests used `memory_mb` 1 as its smallest. It now uses 10, the smallest valid value. Nothing else in that file changed.

### 3.5 Taking up `trunk_dev` `4c991ba`

- PR #41 and PR #37 touch no file of PR #12.
- PR #39 moves the root tests of the scripts to `scripts/`. One of them, `remote_alpha_es_service_tls_status_local_boundary_test.go`, carries PR #12's change from round 13 (its two position reads ignore line directives); git's rename detection carried that change to `scripts/` without a conflict. It stays one counted path.
- PR #39 adds `internal/testutil/testutil_test.go`. Its three problem reports read `fset.Position(pos)`, which follows `//line` directives, and PR #12's `TestOperationalGuardReadsUnadjustedPositions` refuses that in every test file of the module. `481556b` changes the three reads to `fset.PositionFor(pos, false)`. No file of the repository holds a line directive, so every report names the same file and line as before.
- PR #39's change to `.github/ci/environment-only-tests.txt` (package-qualified names under `scripts`) merged cleanly with PR #12's lines, and the list's check passes.

### 3.6 Documents and the path ceiling

- `.docs/execution_lifecycle/contracts.md`: the resources rule now says `memory_mb` must be at least 10. A new rule states the NFC, assigned-code-point and byte-order-mark conditions for arguments and mount targets, why they exist, and that environment strings and `output_id` are not held to them.
- `.docs/system_overview/contracts.md`: the invocation shape says the same in short.
- The owner document gets a reconciliation paragraph for this round: three new paths (`go.mod`, the re-check's test file, `internal/testutil/testutil_test.go`) and the moved file, so the aggregate HEAD ceiling is 69 files. The previous paragraph's "is 66 files" becomes "was 66 files".
- `PLANS.md`: a new top entry. The previous entry's "is 66 files" becomes "became 66 files", as earlier entries say.
- `docs_contract_test.go`: pins for all of it, five more "missing" mutants and five more "wrong statement" mutants of the owner paragraph, and a check that the old resources sentence is gone.

## 4. Validation

Go 1.26.5, emptied environment, user `ci`, clean clones.

### 4.1 The re-check's tests

| Head | Result |
| --- | --- |
| `085b19a` (tests, no fix) | 18 of 18 subtests fail; all 3 tests fail |
| `538f98f` (a local head with the fix) | 18 of 18 pass |

Logs: `mutants/pre32-redteam31.txt`, `mutants/post32-redteam31.txt` (both with `TMPDIR` unset). They pass at the pushed head too (section 4.3).

### 4.2 Mutants (`mutants32.py`)

Each mutant changes one thing in the rule and runs the string, memory and composed-original tests of `es/admission` (89 results) with `TMPDIR` unset. B0 changes nothing.

| Mutant | Result | Caught by |
| --- | --- | --- |
| B0 no change | baseline passes | |
| N1 a leading byte order mark is passed on | caught | my unit test; the re-check's argument test |
| N2 a byte order mark is refused anywhere | caught | my unit test |
| N3 a string not in NFC is passed on | caught | my unit test; both re-check string tests |
| N4 NFKC instead of NFC | caught | my unit test (U+FB01, added this round) |
| N5 NFD instead of NFC | caught | my unit test; the re-check's argument test; `TestRedTeamPR12HeadEveryComposedOriginalReadsBack` |
| A1 unassigned code points are passed on | caught | my unit test |
| A2 no table of assigned code points (fails closed) | caught | my unit test; `TestRedTeamPR12HeadEveryComposedOriginalReadsBack` |
| A3 no table, and no table accepts everything | caught | my unit test |
| A4 the assigned set of Unicode 13.0.0 | caught | my unit test (U+1FAE8, added this round) |
| D1 arguments not held to the rule | caught | the re-check's argument test |
| D2 mount targets not held to the rule | caught | the re-check's mount test |
| R1 `memory_mb` from 1 | caught | the re-check's memory test; my memory test |
| R2 `memory_mb` from 9 | caught | the same two |
| R3 `memory_mb` from 11 | caught | my memory test; `TestRedTeamPR12HeadEveryComposedOriginalReadsBack` |
| S1, S5, S8 round 29's `${`, argument and mount template mutants | caught | round 29's tests, as before |

N4 and A4 survived the first run, at a local head that never left this container. Both make ES refuse strings Nomad keeps, so they are over-refusals, not holes. I added the two cases to my unit test and rebuilt the local commits before any push. The table is the rerun on the pushed head `99a6625` (`mutants33.log`): the baseline passes and all 17 mutants are caught. A mount target cannot begin with a mark, so a mutant that judges the target before trimming is equivalent; I did not run it.

### 4.3 Whole head (`val32.sh`, at `99a6625`)

- **CI:** run [45303337441](https://github.com/evo-agi/Execution-Substrate/actions/runs/45303337441) of `build, vet and test` on `99a6625` succeeded (01:13Z to 01:47Z). PR #44's run [45303252731](https://github.com/evo-agi/Execution-Substrate/actions/runs/45303252731) on `37ad684` succeeded too.

- **Build and vet** are clean for linux/amd64, linux/arm64 and darwin/arm64. `gofmt` lists the same 6 files as `trunk_dev`, none of them PR #12's.
- **Blob-read guard:** 3 pass. **Root docs pins** (now also the Nomad strings contract, the owner rule and its mutants, and PR #37's link tests): 10 pass. **Race:** clean on the es/admission subset (now with the re-check's tests) and the reliablesubmit subset.
- **Whole module against round 31's `75d0f5c`** (`compare-moved.py`, which matches a test PR #39 moved out of the root package by its name):
  - 9,146 results exist on both sides, and none changed;
  - 165 results are new, all passing: PR #41's and PR #39's tests, PR #37's three link tests, the re-check's and my tests, and the ten new docs mutants, plus 43 subtests named after random instants;
  - the 43 results gone are all subtests named after random instants, under the same three red-team tests as in round 31, each with the same number of subtests on both sides and all passing;
  - the 28 top-level failures are identical on both sides and are this container's known ones: 25 operator-host tests, which were in the root package and are now in `scripts`, and in reliablesubmit the 2 probe-binary tests and `TestOperationalHandoffSchema4BinaryRefusesSchema5`.
- **Whole module against `trunk_dev` `4c991ba` itself:** all 7,172 results of `trunk_dev` have the same result at the head. The head's only extra failure is PR #12's own `TestOperationalHandoffSchema4BinaryRefusesSchema5`, which needs a probe binary and is on the CI's list.
- **What the full runs caught on the way.** The first full run, at `538f98f`, failed one guard: ES's Control Plane vocabulary guard refused the word "hold" in the new refusal text. After the wording fix, a full run at `fb39e96` changed no result against `75d0f5c`. Then `trunk_dev` moved to `4c991ba`. A targeted run on a trial merge found PR #39's three position reads, and the run above is on the head with that fix. None of those intermediate heads was pushed.

## 5. Provenance manifests

v2 recipe, run twice per base on a clean tree at the pushed tip, byte-identical:

| Item | Trunk-relative | PR-relative |
| --- | --- | --- |
| Base | `trunk_dev` `4c991ba` (merge base) | PR #12 `4416699` |
| Manifest SHA-256 | `73ed8c3c8f5cc4be29a93da92d68ffee15232141c4e211a33eb8ba67e1216664` | `82289c73b02f269dac43116a5ab58e713d083175ab7055a6c145618b4e06878e` |
| Files | 69 | 165 |
| Textual diff SHA-256 | `570f59b2ad9e7ceddd32e48c678ea7c84b1a969e8c39673a1737bd0573ae6fbc` | `bea34f35ee33dc33a19218889986ff3ceb81ef4d6707e03e5e474c3228c04296` |

Against round 31's trunk-relative manifest (`7cbd8a16…`, 66 files), with each file entry compared:

- **added:** `go.mod`, `es/admission/nomad_request_strings_redteam31_finding_test.go`, `internal/testutil/testutil_test.go`, and `scripts/remote_alpha_es_service_tls_status_local_boundary_test.go`;
- **gone:** `remote_alpha_es_service_tls_status_local_boundary_test.go` at the root, the same file before PR #39 moved it;
- **changed:** 11 files. Ten are the files this round edits (both contracts documents, the owner document, `PLANS.md`, `docs_contract_test.go`, `mounts.go`, `service.go`, `nomad_request_strings_test.go`, the round 28 codec test and `workstream_c_guardrails_test.go`); `docs_contract_test.go` also carries PR #39's changes. The eleventh is `.github/ci/environment-only-tests.txt`, whose content changed through PR #39 alone;
- **unchanged:** the other 54.

The PR-relative manifest has 165 entries against 82 in round 31, because PR #12's own base predates PRs #33, #41, #37 and #39. It lists 49 modified, 80 new and 36 deleted paths; the 36 are the old names of the files PRs #37 and #39 renamed. The script's comparison with `git diff --cached --name-only` reports "not equal" for this base only because that command folds a rename into its new name. Without rename detection the two sets are equal, 165 paths. The staged tree equals the head's tree for both bases, and the working tree was clean before and after.

## 6. For the combined diff-only check

- `git diff 75d0f5c a8d5397` is the repair before the merge: the re-check's test file, the rule and its tests, `go.mod` and the reviewed list.
- `git diff e2ea71f 99a6625` is the rest: PR #39's three position reads, the documents and the pins.
- `git merge-tree --write-tree a8d5397 4c991ba` gives the merge commit's tree, so the merge itself is git's own.
- Round 31's repair, `git diff fd399a1 414a5e5` (one test file), is already accepted in `32-recheck.md`, at `75d0f5c`.
- Questions worth checking:
  - whether any other request string reaches the driver configuration (the red-team says no, S5 in their report);
  - whether refusing rather than normalizing is right;
  - whether the reviewed-list claim for `norm` and `rangetable` holds;
  - the owner paragraph for 69 paths and its pins;
  - the three position reads in PR #39's test.

## 7. The box checks

[`box-live-checks.md`](box-live-checks.md) is now the one list of live Nomad checks for PR #12. It holds round 29's five RT28-1 inputs and the red-team's seven RC31 checks:

- an argument with a leading mark;
- `e` with a combining accent;
- the Kelvin sign;
- `a`, carriage return, `b`;
- two mounts that differ only in normal form;
- a registration with 5 MB;
- `go version` of the box's Nomad binary.

Part B repeats the inputs through ES. It needs David's go. Guess: 20 to 30 minutes.

## 8. Evidence

`32-repair-evidence/` (and `32-repair-evidence.tar.gz`), with `SHA256SUMS`:

- `commits/`: the four commits as patches, the merge's summary, the repair's diff without `trunk_dev`'s changes, `adoption-check.txt`, `merge-check.txt`;
- `mutants/`: the mutant logs and the before and after runs of the re-check's tests;
- `runs/`: the whole-head run of section 4.3 and both comparisons, the `trunk_dev` run, and the earlier runs of section 4.3's last point;
- `manifests/`: both manifests, twice each;
- `scripts/`: `mutants32.py`, `val32.sh`, `compare.py`, `compare-moved.py`, `prov32.sh`.

## 9. The reliablesubmit failure in PR #34's CI (PR #44)

The coordinator asked me to look at a reliablesubmit failure in CI on PR #34's head `188a859` ([run 45293900583, job 138109315259](https://github.com/evo-agi/Execution-Substrate/actions/runs/45293900583/job/138109315259)). It is a flaky test on `trunk_dev`, not a product bug:

- `TestReplayOriginalKeyReadCleanup/commit_response_loss_model` failed with "uncertain driver connection reused".
- The reliablesubmit tests name a driver connection by its memory address and then require the next connection to have another address. They kept only the address. Once the pool discarded the connection, the garbage collector could free it, and Go could put the next connection at the same address.
- In the CI failure the pool held no connection just before (the test checks that), so the next connection really was new.
- A scratch probe (`../replay-conn-identity/zz_addr_reuse_probe_test.go.txt`) shows the mechanism: with a garbage collection between the discard and the next connection, the new connection had the old address in 2,999 of 3,000 rounds on `trunk_dev`, and in 0 of 3,000 with the fix.
- The fix keeps each recorded connection object reachable until the test ends, through `t.Cleanup`, in one test file that PR #12 does not touch. It is PR [#44](https://github.com/evo-agi/Execution-Substrate/pull/44) into `trunk_dev`, test-only.
- The same run's other failure, `TestExecuteLoopScriptFailureSummary` in `es/app`, is a Nomad bring-up test. I did not look into it; PR #42's thread works on the ports of those tests.

## 10. Not claimed and still open

- No audit of this repair yet. Round 31's A30-1 repair is accepted (`32-recheck.md`). Nothing ran on macOS. Nothing ran against a real Nomad.
- Unchanged: N-1 (the Nomad token on the three private requests) waits on PR #31.
- The red-team's observations O31-2 to O31-4 (the template rule is stricter than Nomad needs in three places; operator strings go through the same machinery; Nomad cleans five environment key prefixes) are not changed by this repair.
- I wrote the change and my tests.

## 11. Effects

- Pushed `claude/project-thread-ne9cwa-pr12-trunk-dev` `75d0f5c..99a6625`, a fast-forward. The local commits were rebuilt several times before the push (to add two test cases, to reword the refusal and to take the newer `trunk_dev`); nothing that was ever pushed was rewritten.
- Pushed the new branch `claude/project-thread-ne9cwa-replay-conn-identity` and opened PR #44 into `trunk_dev`.
- PR #40's description is updated. PR #12's own description is unchanged.
- Nothing ran outside this container: no Mac, no test box, no live service. Mutants and probes stayed in scratch clones.
- No secret, key, environment file or SQLite state from a real system was read or written.
