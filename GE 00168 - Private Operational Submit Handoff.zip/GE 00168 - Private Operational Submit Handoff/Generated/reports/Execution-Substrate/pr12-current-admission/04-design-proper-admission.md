# DESIGN REPORT: a proper "current admission" for retained handoffs

**Execution-Substrate draft PR #13 (PR #12 current-admission recheck fix)**
Design analysis, 2026-11-22 (UTC). Author: Claude, design thread "Design a proper current-admission fix", not the writer and not the auditor of PR #13.
Posture: read-only. No repository edit, commit, push, PR change, test run, probe, or live-service contact. No subagents were used.

**Reconnaissance verdict: RECONNAISSANCE_READY** (ready for the owner decisions in section 12; the writer must not start before they are made)

This report supersedes section 5.5 and repair items R4 and R6 of `02-audit.md`. Findings AF-5 and AF-8 and the BLOCK verdict stand. All other repair items of the audit (R1, R2, R3, R5, R7, R8, R9) remain in force and are folded into section 9.

---

## 0. Decision summary

Read this section first. Everything after it is the evidence and the detail.

1. **Both "accept now, revisit later" items can be replaced by fixes that need no revisit.** I recommend doing both in the PR #13 repair.
2. **v1: delete it now.** No v1 original can exist outside test temp folders, so the compatibility branch protects nothing. Deleting it is about 20 changed production lines, removes a silent fallback the audit flagged (AF-12), and makes AF-5 disappear instead of documenting it. Keeping it with an enforced removal guard is possible but is the weaker choice.
3. **Current admission: make it one durable fact in the SQLite store instead of a private copy in each process's memory.** Today each process holds its own frozen copy of trust and policy, and stopping an old process is a manual step that nothing checks. I propose a single-row "admission generation" in the same database, checked under the same writer lock as every claim write, exactly the way key revocation is already checked. Replacing trust or policy then fences every stale process automatically at its next write. No network call runs inside the writer.
4. **Stop tying trust and policy changes to the epoch.** The PR #13 documents say any trust, verifier or policy change needs a new epoch. Reading the code, a new epoch makes every existing claim unstartable, and (Inference, not probed) every existing receipt unreadable by the new-epoch domain. With the generation, a routine revocation no longer needs a new epoch: claims in flight are simply judged again under the new generation. Claims the new rules still allow continue. Claims they deny are refused. That is the proper answer to AF-8.
5. **Bound how stale a process's trust can be.** Before any first-effect step, and outside the writer, the process confirms with EGS that its trust is still what EGS publishes, and every cut then checks a short confirmation deadline. A revocation published at EGS stops keyed first effects within that deadline (I suggest 30 seconds). If EGS cannot be reached, keyed first effects stop.
6. **What stays open is gated by machines, not by promises.** The epoch cannot change (a store trigger forbids it), commissioning has no production caller (an existing inventory test forbids it), and I propose that this gate carry a named prerequisite list that the documents must match.
7. **One finding is outside this PR and affects the live path.** On `trunk_dev` today, ES fetches the trust model from EGS once, at startup. A revocation published at EGS does nothing for ordinary Submit until ES is restarted, and the signed trust payload has no version, time or expiry, so ES cannot detect a rolled-back publication. This predates PR #12. It needs its own decision (section 13).
8. **Cost.** Guess: roughly 550 to 700 changed production lines, 1,400 to 1,900 test lines and 300 to 450 documentation lines, against PR #13's current 3,157 added lines. It adds one table to the unmerged schema 5 and reverses the 2026-11-20 selection "No SQL migration". Guess: 2 to 4 days elapsed including a fresh audit, a red-team pass and at least one repair round. The audit's accept-and-document path is hours. Detail in section 11.

Risk context, unchanged from the audit: this path has no production caller. Nothing here describes a live exposure of the reliable-submit path. Item 7 is the exception, and it concerns ordinary Submit.

---

## 1. Baseline

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| `trunk_dev` | `ae326b0ddc30ec6b35883ee32945c622405b68b6` |
| PR #12 branch `codex/reliable-submit-operational-handoff-v1` | `8058561edc08356c46680c204586b3c7796c0ff3` |
| PR #13 head `claude/project-thread-sqldt7` | `e544e0fbe4220dfdd2c2068e3267dcfa454a0cf9`, tree `7be20ba8a71f0f55490aaac2eb8aed5601386830` |
| Remote heads re-read | 2026-11-22T04:29Z, all three as above |
| Audit report | `02-audit.md`, SHA-256 `ab3d898f96e7ec8685ee3fd6e7411f1e8b995a0abc08fd07856e3152667a8c0b` (thread-reported; I did not rehash it) |

Labels used below. **[R]** repo-validated, cited as `path:line` at `e544e0f` unless another SHA is given. **[T]** reported by another thread, not re-verified. **[C]** decided in chat. **Inference:** reasoned from cited facts, not observed. **Guess:** not derivable from the repositories.

Short names. "Admission" is `es/admission/reliable_submit_operational_admission.go`. "Handoff" is `es/admission/reliable_submit_operational_handoff.go`. "Format" is `es/admission/reliable_submit_operational_format.go`. "Store" is `es/admission/internal/reliablesubmit/operational_handoff.go`. "Owner doc" is `.docs/execution_lifecycle/reliable_submit_operational_handoff.md`.

---

## 2. What the code does today

These are the facts the design rests on.

### 2.1 How ES gets "current" trust at all

- **[R]** ES fetches `GET /v1/trust-model` in `Service.Initialize` (`es/admission/service.go:295-344`). Its only caller is startup (`es/app/app.go:73`). There is no refresh. `Service.Health` carries the TODO "fetches TrustModel only at startup" (`service.go:347`), and `.docs/execution_lifecycle/implementation.md:1087` lists "Runtime-trust loading is startup-time initialization rather than a live refresh path" as a current simplification.
- **[R]** Ordinary Submit reads that in-memory trust on every request (`service.go:406`, `474-482`).
- **[R]** EGS loads its trust model from its own configuration when EGS starts (`egs/app/app.go:38`) and signs the same static value on each request (`egs/api/server.go:91`).
- **[R]** The signed payload contains only `allowed_signers`, `revoked_signers` and `revoked_artifacts` (`egs/model/trustmodel.go:15-18`). `publication.version` and `publication.update_revision` are outside the signed payload by contract (`egs/model/trustmodel.go:20-25`; `.docs/system_overview/contracts.md:929-933`, a Current invariant). The same document says "Future EGS semantic expansion requires explicit wrapper/payload/versioning before implementation".
- **[R]** `egs/`, `es/app/`, `es/config/` and `internal/contracts/` are byte-identical between `ae326b0` and `e544e0f` (`git diff --stat` is empty). So all of 2.1 is true on `trunk_dev`.

Consequence: in this product today, "current trust" means "what EGS served when this ES process started". Nothing signed tells ES whether a publication is newer or older than the one it holds.

### 2.2 What PR #13's retained check uses

- **[R]** `Service.commissionOperationalAdmission(realm)` copies trust lists, the provenance verifier key and the built-in policy set into an `operationalAdmissionSnapshot` held in process memory, once (Admission 95-154). After that, `Initialize` refuses to replace trust (`service.go:296-301`, `334-337`).
- **[R]** `Service.withdrawOperationalEffects` sets a flag in the same process (Admission 157-168). The owner doc says it "is not cross-process revocation" (owner doc 311-312).
- **[R]** `currentOperationalAdmission(realm)` returns the snapshot only if it exists, is not withdrawn, and its installation and epoch equal the realm (Admission 170-182).
- **[R]** The check runs before establish (Handoff 205, 215), inside each writer turn through the `qualify` callback (Handoff 267-277; Store 1351, 1404), after COMMIT at release (Store 1470-1479), and at the final sender entry (Handoff 624-627).
- **[R]** The establish writer has no admission callback of its own (Store 991-1023). The audit recorded this as O-3.
- **[R]** The owner doc requires: "Trust, verifier or policy replacement requires a new qualified epoch and withdrawal of old effect-enabled processes" (owner doc 312-314).
- **[R]** The tests model a policy or trust change by commissioning a second `Service` for the same realm on the same files (`reliable_submit_operational_admission_test.go:59-74`), and then let the first, unchanged `Service` complete the claim (`:1107-1111`). In that test the old process keeps admitting after the change. Nothing in the code stops it.

### 2.3 What is already durable and serialized by the writer

- **[R]** Key state lives in SQLite (`reliable_submit_key_registry`, `sqlite_replay_schema.go:5-15`), with trigger-guarded one-way transitions (`:272-281`).
- **[R]** Every operational writer turn opens with `BEGIN IMMEDIATE` (Store 873), including the read-only pre-stage turn (Store 1345).
- **[R]** Inside the turn, `currentForTurn` re-reads key state through the same connection (Store 1044 calling 244-268). The store also enforces it in SQL: an operational update aborts unless the key pair is in an allowed state (`sqlite_operational_handoff_schema.go:416-426`). Key state is re-read once more after COMMIT (Store 1473).

This is the precedent the design follows: a durable authority fact, changed only by guarded transitions, compared under the writer lock at every cut, and re-read at release.

### 2.4 What the epoch is bound into

- **[R]** The epoch is inside every original (TLV 11 leaf 3, Format 65), inside the locator preimage (`reliable_submit_operational_provider.go:39`), and compared by the snapshot (Admission 178).
- **[R]** Every read of an original, including receipt recovery, re-encodes the stored bytes with the realm of the domain doing the reading and requires byte equality (Handoff 180; Format 212-215, with the realm written at Format 130).
- **[R]** The one test that changes the epoch gets `operationalUnavailable` and no effect (`reliable_submit_operational_handoff_test.go:1077-1094`).
- **Inference** (from the three facts above; not probed): a domain opened with a different epoch cannot read any existing codec-5 claim, including accepted receipts. Confirm with a probe that accepts a claim and then calls `recoverOperational` with `realm.epoch + 1`. The owner doc says earlier epochs stay readable "tied to the same unreplaced domain and retained manifests" (owner doc 48-51); I found no code that reads with a historical realm.

So under the PR #13 rule, a routine revocation would cost every unmarked claim, and probably every receipt, in the domain. The audit's AF-8 inference understated this.

### 2.5 Nothing is wired

- **[R]** The only non-test occurrences of `handoffOperational`, `recoverOperational`, `newOperationalDomain`, `OpenProvisionedOperationalCustody`, `commissionOperationalAdmission` and `withdrawOperationalEffects` are their own definitions, at `e544e0f` and at `8058561`. Key-state transitions (`transitionReplayKeyState`) are also called only from tests.
- **[R]** `trunk_dev` contains neither `handoffOperational` nor the literal `operational_local_v1`.
- **Inference:** no database at schema 5 and no v1 original exists outside test temp folders. What would confirm it: David stating that no test database was kept on the Mac or the Linux box.

### 2.6 Governing text the design must change

All of these are in unmerged PR #12 or PR #13 text, on the reliable-submit Reopened redesign seam.

| Text | Where |
| --- | --- |
| "No SQL migration, public/native wiring or policy platform is selected." | `PLANS.md:64` |
| "No provider or receipt-history mirror, new authority table or new stored column is selected." | Owner doc 146-147 |
| "No durable policy decision, permit, table, migration or new shared kernel is introduced." | `reliable_submit_persistence_and_concurrency.md:527-528` |
| "There is no background trust refresh, cross-process withdrawal registry, public commissioner or external policy service." | `es_execution_admission_model.md:60-62` |
| "Trust, verifier or policy replacement requires a new qualified epoch and withdrawal of old effect-enabled processes." | Owner doc 312-314 |
| "The Service withdrawal writer never takes SQLite or custody locks." | Owner doc 355-356; persistence ADR (same passage) |
| v1 as a Temporary compatibility edge | Owner doc 69, 167-168, 382-388; admission model 62-63; persistence ADR 516-527; `submit_idempotency_correlation_and_recovery.md:966-968`; `PLANS.md:61-64` |

`AGENTS.md:79-92` requires `PLANS.md` and the owning documents to change before the code.

---

## 3. The problem, restated

"Sees revocations and policy changes promptly and correctly" is three separate hops plus one consequence.

| Hop | From, to | Today | 
| --- | --- | --- |
| H1 | Operator to EGS publication | EGS configuration change and restart. Out of ES's control. |
| H2 | EGS publication to one ES process | Only when that ES process starts (2.1). |
| H3 | One ES process to every writer cut of every process on the domain | Nothing. Each process keeps its own copy until someone withdraws it by hand (2.2). |
| Stranding | What happens to claims in flight when the rules change | New epoch required, so every unmarked claim dies (2.4). |

H3 and stranding are created by the PR #13 design and belong in its repair. H2 predates PR #12 and applies to ordinary Submit too. The retained path can still bound its own H2 exposure without changing ordinary Submit or EGS.

---

## 4. Options for "current admission"

### Option A. Keep the snapshot, document it (the audit's recommendation)

Accept the commissioned snapshot plus local withdrawal, state it plainly, and revisit at first commissioning. Rejected by David's rule **[C]**: nothing guarantees the revisit.

### Option B. Durable admission generation (the fence)

Put the identity of the current admission content in one SQLite row and compare it under the writer lock at every cut. Decouple it from the epoch. Detail in section 5.

- Fixes H3 and stranding.
- Does not touch H2: a process still holds whatever EGS served when it started. A revocation takes effect when a restarted process advances the generation.
- No network call anywhere near the writer.

### Option C. Option B plus a confirmation deadline (recommended)

Add a pre-transaction confirmation against EGS and a short deadline that every cut verifies.

- Fixes H3 and stranding, and bounds H2 for the retained path.
- Costs one EGS request per effect-capable keyed invocation, and makes keyed first effects depend on EGS being reachable.
- Uses the existing EGS v1 route unchanged.

### Option D. Option C plus product-wide trust currency

Make ES adopt new trust while running, for ordinary Submit as well, and add a signed sequence and expiry to the EGS publication.

- The complete end state.
- Changes a Current invariant of the EGS contract (`contracts.md:929-941`), ordinary Submit behaviour, ES health semantics, and Remote Alpha configuration. Cross-service.
- It is not a prerequisite for a correct PR #13. It is a separate decision (section 13).

### Mechanisms considered and rejected

| Mechanism | Why not |
| --- | --- |
| Resolver or EGS read inside the writer | Excluded by the brief and by the owner doc (353-354). Holds the write lock across network I/O. |
| New epoch for every change (status quo) | Strands every unmarked claim; Inference: receipts unreadable (2.4). |
| Rotate the operational key pair to fence old processes | Already serialized, but originals are sealed under the old pair, so it strands exactly like an epoch change. |
| Generation in a side file in the custody folder | Not serialized with the SQLite writer without inventing a second locking rule. |
| Store a per-claim "admitted" decision or permit | A stored Allow goes stale. The owner doc already forbids a historical Allow bit conferring a sender. |
| Background refresh loop only | Gives no bound by itself. A deadline is still needed, and with a deadline the loop is unnecessary. |
| Processes reload trust content from the row while running | Larger, and makes the retained path disagree with ordinary Submit inside one process. Belongs with Option D. |
| ES-side rule "revocation lists may only grow" | An interim stand-in for a signed sequence from the publisher. It also creates a dead end when a revocation is withdrawn on purpose, because epoch change is not implemented. Not recommended; see 5.8 and section 8. |

---

## 5. Recommended design (Option C)

### 5.1 Terms

- **Admission content:** the trust model, the provenance verifier (algorithm, key id, public key) and the built-in policy set a process would use to admit.
- **Admission digest:** SHA-256 over a fixed canonical encoding of the admission content. The trust part is the existing `RuntimeTrustPolicy.CanonicalBytes()`.
- **Admission generation:** a counter in the store, starting at 1, that increases by exactly one each time the domain's admission content is replaced.
- **Admission row:** the single durable row holding installation, epoch, generation, admission digest and an enabled or withdrawn state.
- **Admission token:** the tuple (installation, epoch, generation, admission digest) a process presents at a cut.
- **Fence:** the rule that a cut proceeds only if the presented token equals the admission row, read under the writer lock.
- **Confirmation deadline:** the instant after which a process's last successful confirmation with EGS no longer counts.

### 5.2 The durable fact

One new table in schema 5, created by amending the unmerged migration 5 (section 12, D-1, covers the alternative of a migration 6).

| Column | Rule |
| --- | --- |
| `singleton` | Primary key, must equal 1. Exactly one row can exist. |
| `installation` | 32 bytes, nonzero. Immutable. |
| `epoch` | Greater than zero. Immutable. |
| `generation` | Greater than zero. |
| `admission_digest` | 32 bytes. |
| `state` | 1 enabled, 2 withdrawn. |
| `updated_at_unix_ns` | Positive, nondecreasing. |

Triggers, in the style of the key registry (`sqlite_replay_schema.go:250-281`):

- No delete.
- Insert only into an empty table, with generation 1 and state 1.
- Update only as one of: same generation and state 1 to 2 (withdraw); or generation plus one, a different digest, and state 1 (advance). Installation and epoch can never change.

Two clauses added to existing triggers, next to the key-state clauses:

- `reliable_submit_claims_guard_insert_v5`: a codec-5 insert aborts unless an enabled admission row exists.
- `reliable_submit_claims_guard_operational_update`: an update whose `latest_operation_kind` is 2, 3, 4 or 5 aborts unless an enabled admission row exists. Kind 8 (accept with receipt) is not affected.

The triggers make "no codec-5 first-effect progress on an uncommissioned or withdrawn domain" a property of the store. They do not check which process is writing; the Go comparison in 5.4 does that. This also answers the class of risk behind AF-1: a refactor that drops an admission callback can no longer write on a domain that is not enabled.

### 5.3 The three operations

All three are private, have no production caller, and each is one `BEGIN IMMEDIATE` transaction in the store. Each is idempotent by content, so an unknown COMMIT outcome is handled by failing closed locally and calling again.

| Operation | Rule |
| --- | --- |
| **Commission** | Empty table: insert generation 1 with this process's digest. Row present with the same installation, epoch and digest, state enabled: adopt its generation. Anything else: refuse. |
| **Advance** (expected generation g) | Row is (g, a different digest): write (g+1, this digest, enabled). Row is already (g+1, this digest, enabled): success. Anything else: refuse. |
| **Withdraw** | Row at state 1: write state 2. Already 2: success. Then set the local latch. |

The process keeps an immutable view holding its token and its admission content. `Initialize` still cannot replace trust after commissioning, and one `Service` still cannot commission twice. A process whose view no longer matches the row is finished for first effects until it is restarted and commissioned again.

Withdrawal becomes domain-wide. After a withdrawal, enabling again requires an advance to new content.

### 5.4 Where the token is checked

| Cut | Check | Serialized with the claim write |
| --- | --- | --- |
| Before establish (Handoff 205, 215) | Local view only. A hint, not the authority. | No |
| Establish turn (Store 991) | Token equals the row, read through the turn's connection. New: establish gets the same in-writer check as the others. | Yes |
| Assign, intent, pre-stage, stamp, first marker turns | Token equals the row, read through the turn's connection, beside `requireOperationalKeys` (Store 1044). Then the existing local evaluation of the retained evidence. | Yes |
| Post-COMMIT release (Store 1470) | Row re-read on a pooled connection, beside the existing key re-read (Store 1473). | No |
| Final sender entry (Handoff 624) | Local view only: latches and confirmation deadline, as today. | No |
| Accept with receipt, receipt reads, marked reconciliation | No admission check, as today. | n/a |

The token travels in the value the `qualify` callback already returns (`OperationalOriginalMatch`), so the store compares it; the admission package never sees the connection.

Correctness statement: an advance or a withdrawal is itself a writer transaction, so it is strictly ordered against every claim write. A claim write either committed before it, or sees it. This is the same rule the owner doc already states for keys: "Admission precedes revocation at a serialized cut" (owner doc 242-244).

The final sender entry deliberately does not re-read the row. A sender minted from a marker that committed before the advance was validly admitted; the window is the time from the release re-read to transport entry. This keeps a database read out of the one cut that turns a marker into a POST.

### 5.5 Freshness

- The process records the time of its last successful confirmation. Commissioning records none, so the first use must confirm.
- **Confirm** runs outside every lock and every transaction. It performs the same fetch and signature verification as `Initialize`, computes the admission digest with the fetched trust, and compares it with the view.
  - Equal: the confirmation time becomes now.
  - Different: set a permanent local "superseded" latch. This process admits nothing further.
  - Fetch or verification failure: nothing changes.
- Confirm is called at the three existing pre-transaction points and nowhere else: before establish (Handoff 205) and before the two pre-checks (Handoff 291, 343). At most once per invocation. Receipt reads and reconciliation never call it.
- Every use of the view requires: not withdrawn, not superseded, and less than the limit elapsed since the confirmation time. Because `qualify` runs inside the writer turn and samples the view at its start and end (Admission 276, 325), the deadline is verified inside the writer without any I/O.
- Elapsed time is measured on both the monotonic and the wall clock, and the cut refuses if either says the limit has passed or the wall clock moved backwards. Guess: this matters on hosts that suspend, where the monotonic clock can stand still.
- Suggested limit: 30 seconds, a compiled constant in this slice. Guess, sized to cover one invocation's bounded steps.

The process does not adopt new trust while running. It stops, and a restarted process advances the generation. Live adoption is Option D.

### 5.6 Outcomes

Add one value-free reason, `OperationalDenied`, separate from `OperationalUnavailable`.

| Cause | Reason | Run disclosed |
| --- | --- | --- |
| Signer not allowed or revoked, artifact revoked, built-in policy denies | Denied | No |
| Retained evidence does not verify under the current verifier | Denied (today Integrity; audit O-1). The original is already authenticated, so this now means the verifier was replaced. | No |
| No view, token mismatch, withdrawn, superseded, deadline passed, unsupported input | Unavailable | No |
| Malformed or contradictory authenticated evidence | Integrity | No |

Why: with stranding reduced to "claims the current rules deny", the caller must be able to tell "denied" from "try again later". Ordinary Submit already tells callers this (`signer_revoked`, `artifact_revoked`, `.docs/execution_lifecycle/contracts.md:618-619`). The public mapping stays a later gate.

A denial stays non-terminal: a later generation that allows the claim lets a retry complete. This matches the rest of codec 5, where claims never expire and only a caller's retry moves them.

### 5.7 Locks, and what never runs in the writer

- Order is unchanged: SQLite writer, then a brief `Service.mu` read. Commission, advance and withdraw take the SQLite writer and must not hold `Service.mu` while they do; they update the local view only after the transaction ends. They must never be called from inside a writer turn.
- Inside a writer turn: reads through the turn's connection, bounded local verification and policy evaluation, a clock comparison. Nothing else.
- Outside: the EGS confirmation, stage creation and materialization, provider I/O, as today.

### 5.8 What this guarantees, and what it does not

Guarantees, each pinned by a test in section 10:

1. No codec-5 first-effect write commits unless the writer's token equals the admission row at that write's serialized position.
2. After an advance or a withdrawal commits, no process holding the old token commits another first-effect write on that domain.
3. No first-effect cut passes more than the limit after the process last confirmed its trust with EGS.
4. Replacing trust, verifier or policy does not change the epoch and does not invalidate any original. A claim the new content allows completes with exactly one POST.
5. An uncommissioned or withdrawn domain accepts no codec-5 establish and no progress write, even if a caller omits the Go check.

Not solved here, stated so nobody assumes otherwise:

- **Rollback at the publisher.** If EGS serves an older, validly signed payload, ES cannot tell. This is true product-wide (2.1) and is properly solved by a signed sequence in the publication (Option D). Until then the retained path trusts EGS's TLS identity exactly as `Initialize` does. Within one domain, the generation counter still prevents a stale process from joining or silently replacing newer content.
- **A marker without a send.** A claim whose marker committed but whose sender was refused stays ambiguous forever. This is PR #12's at-most-once design (owner doc 903) and is unchanged.
- **Epoch change.** Still not implemented. Section 8 makes that a tripwire.
- **Ordinary Submit.** Unchanged (section 13).

---

## 6. AF-8, stranding: what remains and why

| Situation | Before (PR #13 as written) | After |
| --- | --- | --- |
| Trust, verifier or policy replaced, claim still allowed | New epoch; claim can never start | Same epoch, new generation; claim completes |
| Claim's artifact or signer revoked, or policy now denies it | New epoch; claim can never start; caller sees Unavailable | Refused as Denied at its first remaining cut; resumes only if a later generation allows it |
| Old process still running after the change | Keeps admitting until withdrawn by hand | Fenced at its next write |
| Deployment identity changes (a true epoch change) | Not implemented; Inference: all claims and receipts unreadable | Not implemented; impossible without new code (section 8) |
| Marker committed, sender refused | Ambiguous forever | Unchanged |

The owner doc sentence "a later retry under an allowing authority still completes, so a denial does not poison the claim" (376-380) becomes true in a conformant deployment, because the allowing authority is a later generation of the same epoch.

---

## 7. v1: delete it

**Recommendation: delete `operational_local_v1` in the PR #13 repair.**

- **[R]** v1 exists in production code at seven places: Format 20, 113, 177-178; Handoff 285-287, 337-339; `replay_custody_structure.go:459` and the fallback branch at `:472-485`.
- **[R]** No production caller could have created a v1 original (2.5). Inference: none exists.
- **[R]** `AGENTS.md:52`: "Do not preserve a `Temporary compatibility edge` by inertia." A branch for data that does not exist is inertia.
- **[R]** The encoder silently produces v1 when the evidence record is empty (Format 113-123; audit AF-12, mutant S10 survives). Deleting v1 turns that into a refusal, which is what R9 asked for.

What changes:

| Area | Change |
| --- | --- |
| Custody grammar, scope 3 | Provenance leaf 1 must be `operational_local_v2`; leaf 5 must be the bounded opaque evidence scalar. The inherited sequence grammar stays for scopes 1 and 2 only. |
| Encoder | Refuse an empty evidence record. No default literal. |
| Reader | `operational_local_v1` falls into the existing fail-closed default. The variant enum goes away or keeps one value. |
| Handoff | Remove the two v1 branches. |
| Literal name | Keep `operational_local_v2`. Reusing "v1" for the new layout would make it indistinguishable from bytes produced by tests at `8058561`. |
| Tests | Keep the independently built v1 bytes, as negative vectors: custody refuses them, the reader refuses them. `TestOperationalAdmissionV1Compatibility` (250 lines) is replaced by those refusals. |
| Documents | Remove the v1 row, the v1 literal and every "Temporary compatibility edge" statement listed in 2.6. |

Cost. Guess: about 20 changed production lines, a net reduction in test lines, about 10 document passages. All in files the repair touches anyway.

"Changes PR #12's custody grammar" is true, and cheap: PR #12 and PR #13 reach `trunk_dev` together, so `trunk_dev` never sees the v1 grammar.

**If David prefers to keep v1,** the enforced form is a guard test, not a note: fail when the v1 literal is present in production source and either a non-test reference to commissioning exists or the schema head is no longer 5. Cost: about 30 test lines plus the reason, scope and removal condition in the owner doc and section 4C. I do not recommend it, because the reason column would have to say the edge protects no data.

---

## 8. Machine-enforced tripwires

Applying the general rule **[C]**: anything temporary that remains must have a machine-enforced trigger.

After the recommended repair, PR #13 adds no Temporary compatibility edge. What remains unimplemented is gated as follows.

| What remains | Trigger | Enforcement |
| --- | --- | --- |
| Production commissioning (and everything the owner doc lists under "Before native use require", 969-978) | First non-test reference to commission, advance, withdraw, or to the confirmation source | The existing typed inventory `TestOperationalHandoffNoPublicStartupOrdinaryOrFixtureCaller` requires zero. Extend it to the new methods. Add a named prerequisite list as a constant beside it, print it on failure, and pin in `docs_contract_test.go` that owner doc section 8 lists the same identifiers, so the gate and the document cannot drift apart. |
| Epoch change | Any attempt to change the stored epoch or installation | The update trigger aborts. A typed inventory pins that no production statement writes those columns after insert. |
| A second writer of the admission row | Any new statement that inserts or updates the table | Call-site inventory: exactly the three store functions. |
| Re-enabling a withdrawn domain without new content | Update of state 2 to 1 at the same generation | The update trigger aborts. |
| Proof hooks gaining authority | A hook that returns a decision or lengthens the deadline | The clock seam for tests may only add a non-negative skew. Existing inventories pin that no non-test source configures a hook. |

Prerequisite identifiers I propose for the commissioning gate:

- `CP-ROLLBACK`: the trust publication carries a signed monotonic sequence, or an equivalent the owner accepts.
- `CP-EPOCH`: an epoch-change procedure exists, with drain or terminal rules for unmarked claims and receipt reads under a historical realm.
- `CP-POLICY-CUSTODY`: who may commission, advance and withdraw, and where the installation policy is stored.
- `CP-NATIVE`: the existing native prerequisites of owner doc section 8.

A gate test can be edited. The point is that the edit is forced, visible in the diff, and checkable by the next audit, whose brief can require that the list is unchanged or that each removal is justified.

---

## 9. Exact repair scope for the PR #13 writer

Seam classification: re-derivation on the reliable-submit Reopened redesign seam (`PLANS.md` keeps it open). Provenance tier: full gate. A plan checkpoint is required (operating protocol 3.3). Doc-first order per `AGENTS.md:87-92`.

**S0. Owner decisions recorded.** D-1 to D-3 (section 12), cited in the `PLANS.md` entry.

**S1. Documents first.**

- `PLANS.md`: new dated entry. Selects the admission generation, reverses "No SQL migration" for this purpose, removes v1, states the freshness rule.
- Owner doc: section 2 (table added to the physical state; line 146-147 revised; epoch rule kept for deployment identity only); the "PR #12 v2 retained evidence and current admission" section rewritten for 5.2 to 5.7; outcome text replaced per 5.6 and section 6; v1 statements removed; section 8 gains the prerequisite list; section 9 path ceiling raised.
- `es_execution_admission_model.md:33-63`, the persistence ADR passage at 516-540, `submit_idempotency_correlation_and_recovery.md` near 966, `.docs/system_overview/boundaries.md` (the PR #12 section; audit O-4), and one sentence in `.docs/execution_lifecycle/implementation.md` near 1087 saying the private path confirms trust before first effects while ordinary Submit does not.
- `docs_contract_test.go`: phrase pins and doc mutants for the above.

**S2. Store (`es/admission/internal/reliablesubmit`).**

- Migration 5 literal: the table, its triggers, the two added trigger clauses. New schema-5 shape digest (`sqlite_replay_shape.go:20`).
- Read, commission, advance and withdraw functions.
- Token carried by `OperationalOriginalMatch`; compared in the establish turn, in `currentForTurn` or `qualifiesOriginal` for every operation except accept, and at release.
- Scope-3 custody grammar: v2 only.

**S3. Admission (`es/admission`).**

- View gains generation and digest. Canonical admission digest.
- Commission and withdraw reworked to use the store; advance added. `Service` gains the superseded latch and the confirmation time.
- Confirm, sharing one fetch-and-verify helper with `Initialize`. Called at Handoff 205, 291, 343.
- `OperationalDenied` and the mapping in 5.6.
- v1 removed from Format and Handoff; encoder refuses an empty record.

**S4. Audit items carried over.** R1 (now partly satisfied structurally, still required as behaviour tests), R2 (against the new commissioning), R3, R5, R7, R8. R4 and R9 are satisfied by deleting v1. R6 is replaced by S1.

**S5. Inventories.** Field-access and call-site inventories for every new field, method and statement.

Non-goals: no change to ordinary Submit, to `Initialize` behaviour, to EGS, to the original wire format, the locator, receipts, staging, the sender or the provider exchange; no public route, DTO, status code or configuration key; no production caller for anything.

Expected new paths beyond PR #13's 19 files. Guess: `sqlite_operational_handoff_schema.go`, `sqlite_replay_shape.go`, Store, the shape and migration tests, `implementation.md`, and possibly one new store file with its test. The owner doc section 9 ceiling (42 files) must be raised to match.

Stop conditions for the writer:

1. Any persistent database at schema 5 is found. Amending migration 5 is then unsafe; stop and ask (the alternative is a migration 6).
2. The new trigger clauses change behaviour for codecs 3 or 4.
3. A cut cannot receive the token without the admission package touching the SQLite connection.
4. The confirmation cannot be kept out of every writer turn.
5. Base drift on PR #12's branch, or a red-team finding on `e544e0f` that changes this design.

---

## 10. Tests that pin it

Each line names the property and the single-site mutant it must kill by a behavioural assertion, in the audit's sense.

**Store, admission row**

- Lifecycle: commission on empty inserts generation 1; commission again with the same digest adopts it; a different digest is refused; advance with a wrong expected generation is refused; advance with the same digest is refused; advance succeeds once and is idempotent; withdraw is idempotent; advance after withdraw enables generation plus one.
- Triggers by raw SQL: delete, second row, generation minus one, generation plus two, installation change, epoch change, state 2 to 1 at the same generation. Each aborts. Mutants: each trigger clause removed.
- Store guard by raw SQL: codec-5 insert with no row and with a withdrawn row aborts; updates of kinds 2 to 5 abort; kind 8 succeeds on a withdrawn domain; codecs 3 and 4 are unaffected. Mutants: each added clause removed.

**Store, token at each cut**

- For establish, assign, intent, pre-stage, stamp and marker: a token with the wrong generation, the wrong digest, the wrong installation or the wrong epoch is refused with no write and an unchanged revision. Mutant: the comparison removed for one operation at a time (six mutants).
- An advance committed after a write's COMMIT and before its release re-read gives applied with release failed, no sender, no POST. Mutant: the release re-read removed. This may need one new nil-default proof hook between COMMIT and release.

**Admission, two Services on one domain**

- Seed a claim at revision 1, 2 and 3. Service B advances with: a configured literal denial; the claim's artifact revoked; the claim's signer revoked; an unrelated revocation; a changed verifier.
  - Service A, still on the old generation, retries: Unavailable, no run, state unchanged. This is the fence. Mutant: the token never leaves the view.
  - Service B retries: Denied for the three denials and for the changed verifier, with no run and state unchanged; for the unrelated revocation, accepted with exactly one POST. This is the AF-8 test.
  - Service C advances again with allowing content and retries: accepted, exactly one POST. Denial is not terminal.
- The audit's R1 cases (a) to (d), unchanged in intent: mutants S1, S2, S3a and S3b each killed by behaviour.
- Advance injected at each proof hook: before pre-stage, before stamp, before marker (refused at the next cut; revision, stage and marker as in the existing withdrawal table; zero POSTs); before consume and before the entry sample (the POST proceeds, by 5.4). Withdrawal by the same process at those two hooks is still refused, as today.

**Two processes**

- Using the existing child-process harness: a child commissioned at generation 1 is held at a hook, the parent advances, the child continues and is refused at its next cut with no effect.

**Freshness**

- EGS unchanged: exactly one trust request per effect-capable invocation; zero for recovery and for accepted replay.
- EGS serves different trust: refused before any cut; later invocations refused even after EGS reverts. Mutant: the latch removed.
- EGS unreachable, or a bad signature: no extension; once the skewed clock passes the limit, every cut refuses. Mutant: the deadline check removed.
- The clock skewed past the limit at each proof hook: the next cut refuses.
- The confirmation never overlaps a writer turn: the fake EGS handler opens `BEGIN IMMEDIATE` on the same database and must succeed.
- A fresh `Service` with no confirmation admits nothing.

**Commissioning**

- Audit R2, against the new operation: an injected policy set that differs from configuration is refused; mutating the Service's trust lists after commissioning changes neither the view's decisions nor its digest; a view for one installation does not serve another.
- A `Service` commissioned on one database presents a token another database refuses.

**v1 removal**

- The independently built published-layout v1 bytes are refused by scope-3 custody and by the reader.
- Composing with an empty evidence record refuses. Kills S10.
- No production source contains the literal `operational_local_v1`.

**Outcomes**

- Each cause in 5.6 maps to its reason; none discloses a run.

**Gates (section 8)**

- Zero non-test references to commission, advance, withdraw and the confirmation source, with a positive control that a synthetic production caller fails the test.
- The prerequisite identifiers in the test equal those in owner doc section 8.
- Exactly three functions write the admission table.

**Re-run from the audit:** the full mutant script, on the new bytes, plus the mutants named above.

---

## 11. Cost estimate

All sizes are Guesses from reading the code. They would be confirmed by the writer's frozen plan.

| | A: document it | B: fence, decouple, delete v1 | C: B plus freshness (recommended) | D: product-wide trust currency |
| --- | --- | --- | --- | --- |
| Production Go | 2 or 3 small touches | 450 to 550 changed lines | 550 to 700 | Separate tranches, cross-service |
| Tests | 300 to 500 lines | 1,100 to 1,500 | 1,400 to 1,900 | n/a |
| Documents | about 80 lines | 250 to 400 | 300 to 450 | n/a |
| Schema | none | one table in unmerged schema 5 | same | EGS wrapper version |
| Owner decisions | 2 (to accept) | D-1 | D-1, D-2 | Strategic |
| Revisit needed later | Yes, unguaranteed | H2 only, behind the commissioning gate | None for this path | None |
| Elapsed | hours | 2 to 3 days | 2 to 4 days | weeks |

Basis for the elapsed Guess: PR #13's writer pass and its audit each took a few hours today **[T]**; this repair is several times larger, is a full-gate tranche with a plan checkpoint, a fresh audit and a separate red-team pass, and PR #12's history shows repeated audit rejections on this seam (`PLANS.md` entries of 2026-11-19 and 2026-11-20). I expect at least one repair round.

What the extra cost buys: the two items the audit asked the owner to accept stop existing, and the PR #12 finding ("a retained original can proceed without consulting the current ES admission owner") is closed against a definition of "current" that holds across processes and over time.

---

## 12. Owner decisions

**D-1. Adopt the durable admission generation.** It adds one table and two trigger clauses to the unmerged schema 5, by amending migration 5, and reverses three statements listed in 2.6. Recommendation: yes. The alternative inside D-1, a new migration 6, leaves a schema 5 that never shipped as permanent history and renames "schema 5" across documents and tests; I recommend amending 5, on condition that no persistent schema-5 database exists.

**D-2. Freshness in this repair.** Confirm with EGS before every effect-capable keyed invocation, 30 second limit, keyed first effects stop when EGS cannot be reached. Recommendation: yes. The alternative is Option B, with freshness named as a prerequisite in the commissioning gate.

**D-3. Delete v1.** Recommendation: yes.

One confirmation requested with D-1 and D-3: that no reliable-submit test database was kept on the Mac or the Linux box.

---

## 13. Finding outside this PR

```text
FINDING (design reconnaissance, pre-existing, not a PR #13 defect)
Type / Severity: security risk and contract gap / owner to rate
Current contract:
  .docs/execution_lifecycle/implementation.md:1087 names startup-only trust loading as a
  current simplification. .docs/system_overview/contracts.md:929-941 keeps publication
  metadata outside the signed payload and requires explicit versioning for any expansion.
Path and line (trunk_dev ae326b0):
  es/app/app.go:73; es/admission/service.go:295-344, 347, 406; egs/api/server.go:91;
  egs/app/app.go:38; egs/model/trustmodel.go:15-25.
Evidence: section 2.1.
Impact:
  A signer or artifact revocation published at EGS has no effect on ordinary Submit until
  the ES process restarts. The signed payload has no sequence, issue time or expiry, so ES
  cannot detect an older publication being served again.
What I did not establish:
  Whether an operator procedure already restarts ES after an EGS change (no runbook read).
  Whether Remote Alpha runs EGS and ES such that this is reachable in practice.
Suggested treatment:
  A separate tranche, in two steps. First ES-only: refresh and adopt trust while running,
  with an explicit decision on health semantics (the TODO at service.go:347 asks for exactly
  that). Second, cross-service: a versioned EGS wrapper with a signed sequence and expiry.
  Until then, any revocation procedure should include restarting ES.
```

---

## 14. Uncertainty, and where inspection stopped

- **Not run.** No test, probe or build. Every behavioural statement is from reading code, or is the auditor's reported result. In particular the two inferences in 2.4 and 2.5 are unprobed.
- **Not read in full.** `reliable_submit_operational_provider.go`, `staging_custody.go`, `resolved_execution_plan.go`, the persistence ADR beyond the passages cited, `submit_idempotency_correlation_and_recovery.md` beyond line 966, `PLANS.md` beyond its first 140 lines, and most test files. The typed inventories were located, not read end to end, so the size of S5 is the least certain part of the estimate.
- **Not inspected.** macOS behaviour, the native target, Remote Alpha, IM and MA, the Coordinator, and the red-team thread's work on `e544e0f`.
- **Guesses.** The 30 second limit; all sizes and durations in section 11; the list of additional paths in section 9; the value of the dual-clock rule on suspending hosts.
- **Design risks the writer's reconnaissance should test first.**
  1. Whether the token can ride in `OperationalOriginalMatch` without widening that type's call-site inventories unacceptably.
  2. Whether the added trigger clauses disturb the migration-5 row-preservation assertions.
  3. Whether a hook exists, or can be added without granting authority, to inject an advance between COMMIT and release.
  4. Whether confirming at Handoff 291 and 343 changes any existing result mapping when EGS is slow and the context is cancelled.
- **A disagreement preserved.** The auditor recommended keeping v1 and accepting the snapshot. Per the coordinator's relay, the auditor now treats section 5.5, R4 and R6 as superseded by this report.

## 15. Effect status and delivery

Repository edits: none. Commits: none. Pushes: none. PR changes or comments: none. Tests or probes: none. Live-service contact: none (GitHub was read for refs only). The local clone was checked out at `e544e0f` for reading.

The only file written is this report: `/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/04-design-proper-admission.md`. Its SHA-256 is given in the thread reply that delivers it.

**Reconnaissance verdict: RECONNAISSANCE_READY**
