# Red-team report: Execution-Substrate PR #12 (reliable submit, with PR #13 inside it) at `4416699`

Status of this file: **RED-TEAM REPORT.** Written by the red-team thread "Red-team PR 12 reliable submit" on 2026-11-23 between 20:00 and 21:20 UTC. Readers: the coordinator, David, the PR #12 writer and the audit thread.

This thread is separate from the writer and from the auditors. It pushed nothing, opened nothing, commented nowhere and merged nothing.

Words used below. "Source: run" means I measured it in this container and the log is in the evidence folder. "Source: reading" means I read it in the code or in a document and did not run it. "Inference" and "Unknown" are marked as such.

---

## 1. Verdict

**TWO FINDINGS HOLD (both medium). Of the four areas the brief named, three held: the admission recheck in the handoff, durable progress and replay, and lock contention. The fourth, the raw-memory guard, I did not attack (section 12).**

In plain words:

1. **The handoff held under everything I threw at it.** A withdrawal or an advance of the admission at a random instant never let a running handoff write a first effect afterwards, in 300 rounds each, with changes landing at every durable step. Three mutants that weaken the fence are caught by these tests. Two SIGKILLs in a row followed by a survivor, 150 rounds: never two POSTs, never a POST without a durable marker. Four live processes racing for one claim, 150 rounds: every round without a kill completed with exactly one POST. A foreign writer holding the database lock 1,269 times across 150 deliveries never stranded a claim. 32 requests at the edges of what the parser accepts are written and read back identically. Five fuzz targets ran clean (11,729,771 executions in 27 minutes).
2. **RT28-1, medium, security risk and contract drift. Older than PR #12.** ES puts the caller's arguments into the Nomad job exactly as written. Nomad's client does not run them as written: it evaluates `${...}` and `%{...}` in every argument, with the node's attributes and metadata, the task's environment and 15 functions. So the arguments that run are not the arguments ES admitted, bound and recorded. The code is the shared job builder on `trunk_dev`; PR #12's private path inherits it. Verified from Nomad's source at the version ES pins, not against a running Nomad (section 12).
3. **RT28-2, medium, bug. New in PR #12.** A request whose Nomad job comes out larger than 65,536 bytes is admitted, takes a claim slot and a reservation, gets a run, and can then never go further. Four such requests fill the domain: every new request is refused for capacity. One argument of about 62,300 plain bytes, or about 10,400 bytes of `<`, is enough, and the request parser allows 65,536 bytes per argument.
4. **The three Nomad requests without ES's token** (section 7) fail closed once Nomad enforces ACLs: every private claim would strand after its marker. That is an availability problem with one security edge, the temptation to give anonymous callers rights. PR #31's guard already forces the fix on whichever of the two PRs lands second.
5. **The raw-memory guard**, including the `//line` roads, is not covered by this report. A safety check in my session stopped that part and I did not resume it. The audit thread's read-only review `28a-guard-coverage.md` covers the guard and has one finding of its own, G28-1 (medium).

Recommendation. Under the project rule "no accept now, revisit later", close RT28-2 in PR #12 before its merge gate: the correction is small (section 5.2) and its test is delivered. RT28-1 belongs at the shared request validation, so it needs a product decision on where it lands: a `trunk_dev` change that PR #12 then picks up, or PR #12 itself, which must take `trunk_dev` again anyway because `trunk_dev` moved during this pass (O-6). That call is the writer's and the coordinator's.

## 2. Target identity

| Field | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Red-team target | PR #12 branch `codex/reliable-submit-operational-handoff-v1` at `44166998d4ef0d7b86152f3f66265b906f7d612a`, tree `052d102465743ce673a34f3805100b29f2d142c5` |
| Parents | `2c8bf35f30877bc3749b1799be686bf108a1cf8d` (first), `8ba1edb8af52214ec1bfbb5b93e5a4dc4e51b1ce` (`trunk_dev` at the time of the merge) |
| Head bytes | Source: run, `head/head-check.txt`. My checkout is at that commit and tree with an empty `git status --porcelain`. The 56 paths that differ from `8ba1edb` are the same 56 paths as report 26's trunk-relative v2 manifest (`86ff064d4402ed9d1301c82c2bbe6d7f1aa51aa6bd96a9c838bd3f56334987b0`), and all 56 SHA-256 values and sizes are equal. I did not run the v2 recipe again; a tree id fixes every byte. |
| Branch at close | Unchanged: `ls-remote` at 21:13 UTC gives `4416699` for PR #12's branch and for `refs/pull/12/head`, and my checkout is still clean (`head/ls-remote-close.txt`). |
| `trunk_dev` | `8ba1edb` when I started. **It moved during the pass** to `76c030fa7872dd22dda731591878ef284c01bd9b` (PR #27, committed 20:07 UTC). See O-6. |
| Environment | Cloud container, linux/amd64, 4 CPUs, Go 1.26.5 (`GOTOOLCHAIN=local`), unprivileged user `ci` (uid 1500), emptied environment, umask 022. Scratch clones under `/opt/ci/work/`. |

## 3. Posture and effects

- Read-only toward every repository. My only contact with GitHub was reading: the clone, fetches of PR #12's branch and of `trunk_dev`, and `ls-remote`.
- All attacks ran in scratch clones owned by the unprivileged user. Mutants, candidate fixes and scratch measurements exist only there and in the evidence folder. Nothing was committed anywhere.
- No live service, no third party, no Linux box. EGS, the artifact registry and Nomad are the synthetic test doubles of the suite.
- I fetched six source files of Nomad and HCL from their public repositories to read them (section 5.1). I did not run Nomad: downloading and executing the binary was refused by this session's permission check, and I did not work around it.

## 4. Findings at a glance

| ID | Severity | Type | Origin | One line |
| --- | --- | --- | --- | --- |
| RT28-1 | medium | security risk; contract/authority drift | pre-existing on `trunk_dev`, inherited by PR #12's private path | Nomad's client evaluates template syntax in the caller's arguments, so the argv that runs is not the argv that was admitted. |
| RT28-2 | medium | bug (availability); with a doc/code drift sub-point | PR #12 | A request whose job exceeds 65,536 bytes takes a claim slot and a reservation and can never complete; four of them stop the domain. |
| N-1 | report-only until one of the two PRs merges | security consequence of a known item | PR #12 against PR #31 | The private path's three Nomad requests carry no token (section 7). |
| O-1 to O-6 | observation | see section 6 | | No action required today, except the tripwire test that O-3 delivers. |

Not mine, and not re-tested by me: G28-1 (medium) in `28a-guard-coverage.md`.

## 5. Findings

### 5.1 RT28-1: Nomad evaluates the caller's arguments

```text
RED-TEAM FINDING
ID / Type / Severity: RT28-1 / security risk; contract/authority drift / medium
Patch defect or pre-existing issue: pre-existing. The job builder (es/admission/submit.go) and
  validateInvocationAgainstManifest are byte-identical at PR #12's head, at trunk_dev 8ba1edb
  and at trunk_dev 76c030f. PR #12 adds a second road to the same builder and a document that
  promises the binding.
```

**Current contract.** The owner document `.docs/execution_lifecycle/reliable_submit_operational_handoff.md` at `4416699`, lines 343 to 346: "Bind evidence artifact/payload digests, derivation, output, signed artifact type, target and network claims, runtime capabilities, argv, selected default profile and full retained payload bytes to the original intent and plan." Lines 998 to 1000: "An eligible retained cut observes actual argv, artifact, profile, payload count and bounded text supplied to the selected built-in policy." The admitted argv is meant to be the argv of the workload.

**Path and line (source: reading).**

- `es/admission/submit.go:180`: `"args": copyStringSlice(projection.runtimeCommand.arguments)`. The arguments go into the task's driver configuration unchanged. Line 218 does the same for the environment: `"Env": copyStringMap(projection.environment)`.
- `es/admission/resolved_execution_plan.go:567`: the runtime command is built from `prepared.admittedRequest.Invocation.Argv`.
- `es/admission/service.go:844`: the only rule on argv in `validateInvocationAgainstManifest` is the count, at most 100. No rule looks at the content of an argument.
- `es/admission/reliable_submit_replay_intent.go:157`: the private parser accepts up to 100 arguments of up to 65,536 bytes each, any valid UTF-8.
- `es/admission/reliable_submit_operational_provider.go:367`: the private path builds its job with the same `buildNomadJobSpec`. `validateOperationalPlan` (`reliable_submit_operational_format.go:81`) compares the plan's arguments with the request's arguments byte for byte, which holds, and which is exactly why the template text reaches Nomad intact.

**What Nomad does with it (source: reading, Nomad v2.1.1, the version ES's CI pins in `.github/workflows/go.yml` line 113; file hashes in `reference-sources.txt`).**

- `client/allocrunner/taskrunner/task_runner.go`, `runDriver`, lines 923 and 943: `vars, errs, err := tr.envBuilder.Build().AllValues()` and then `hclutils.ParseHclInterface(tr.task.Config, tr.taskSchema, vars)`. Every task start decodes the driver configuration with variables.
- `helper/pluginutils/hclutils/util.go`, lines 28 to 63: `ParseHclInterface` encodes the configuration to JSON, parses it as HCL and decodes it with an evaluation context of those variables and `GetStdlibFuncs()`. Lines 193 to 211 list the functions: abs, coalesce, concat, hasindex, int, jsondecode, jsonencode, length, lower, max, min, reverse, strlen, substr, upper.
- `client/taskenv/env.go`, `AllValues`, lines 283 and following: the variables are the task's environment (also as the map `env`), the node's attributes and metadata (`node.*`, `attr.*`, `meta.*`) and task secrets.
- HCL `json/structure.go` at `v2.20.2-nomad-1` (the version in Nomad's `go.mod`), lines 384 to 410: a JSON string decoded with an evaluation context is parsed as an HCL template. `${` opens an interpolation and `%{` a directive; `$${` and `%%{` are the escapes.
- For the environment the road is different: `env.go` line 655 passes each value of the task's `Env` through `hargs.ReplaceEnv`, which replaces `${name}` when `name` is a node attribute or an environment variable (`helper/args/args.go`). It has no escape form.

**Evidence (source: run).** `TestRedTeamPR12HeadCallerArgvIsNotEvaluatedByNomad` sends five requests through the private handoff and reads the job that the synthetic Nomad received. At head it fails 5 of 5: ES answers accepted with a receipt, and the job's `Config.args` carries the argument as written (`logs/findings-final-rt3.log`):

| Argument | What Nomad's client would do with it (source: reading) |
| --- | --- |
| `${attr.unique.hostname}` | replace it with the node's host name |
| `${env["NOMAD_ALLOC_ID"]}` | replace it with a value from the task's environment |
| `${lower("DENIED-LITERAL")}` | replace it with `denied-literal`, a string the admitted argv never contained |
| `%{ if true }x%{ endif }` | replace it with `x` |
| `unterminated ${` | fail the task with "failed to parse config" after ES has answered accepted |

With a five-line candidate rule in the scratch clone `rt3fix` (refuse `${` and `%{` in an argument, `candidates/candidate-fix-RT28-1.diff`) the test passes 5 of 5 (`logs/findings-final-rt3fix.log`).

**Impact.**

1. The executed arguments differ from the admitted ones. Admission, the bound plan, the retained original and every record ES keeps hold one argv; the workload receives another. That breaks the core promise that ES owns admission truth for what runs.
2. A caller can have node facts written into the arguments of a governed artifact: host name, node id, addresses, kernel and driver versions, node class and operator-set node metadata. The same holds for values of the task's own environment. The caller does not need to know the names: `jsonencode` is among the functions, so `${jsonencode(meta)}` would write all node metadata into one argument (Inference from the function list and the variable shapes). Inference: whatever the artifact echoes or stores from its arguments then reaches the caller. There is no function that reads a file. ES's job has no Vault or identity block (`submit.go`, source: reading), so I see no token in reach today; that changes the day such a block or a Nomad `secret` block is added.
3. Any rule that looks at argument text can be evaded, because the text can be built at the node with `lower`, `upper`, `substr`, `concat` or `reverse`. Admission policy already names the input class `invocation_argv` (`policy.go:31`). No shipped policy judges argument text today: outside tests, `InvocationArgv` is only filled (`policy.go:222`) and copied to a test observer (source: `grep`). So this is a hazard for the next policy, not a present bypass.
4. An argument with unbalanced template syntax gives a job that ES accepts and Nomad can never start.

Who can do it: any caller that is allowed to submit, on the ordinary path of `trunk_dev` today (source: reading; I ran the private path only) and on the private path once it is wired. PR #12's handoff has no production caller yet (`handoffOperational` and `recoverOperational` are called only from tests, source: `grep`).

**Required correction.** One rule at the shared request validation, so that the ordinary and the private path agree: either refuse an argument that contains `${` or `%{`, or send it in the form Nomad passes on as written (`$${`, `%%{`). Refusing is simpler and also covers the environment, where no escape exists. The same decision is needed for every caller string that reaches the job: environment values, and mount target paths, which `normalizeRuntimeMountTargetPath` accepts with any characters under the mount root (source: reading; the private path refuses mounts altogether). Decide in the same change whether control bytes are allowed in an argument; today the composer accepts 0x01, 0x1f and 0x7f (source: run, the "argv control bytes" row of the codec test). I did not test NUL. The delivered test accepts either correction.

**Uncertainty.** Not measured against a running Nomad. The version on the Linux box is Unknown to me; ES's CI pins v2.1.1. The environment and mount roads are from reading only. One check on the Linux box would close this: submit one job whose argument is `${attr.kernel.name}` and read what the task received.

### 5.2 RT28-2: a request that is too large for a job takes a claim and can never complete

```text
RED-TEAM FINDING
ID / Type / Severity: RT28-2 / bug (availability); doc/code drift sub-point / medium
Patch defect or pre-existing issue: patch defect of PR #12 (all files involved are new in PR #12).
```

**Current contract.** Owner document, line 10: the proof domain has "Four operational claim slots, 32 object names, and 32 aggregate nonrefundable reservations." Lines 252 to 255: the request may be up to 262,144 bytes with strings up to 65,536. Lines 1345 to 1346: "Canonical Job0 ≤65536 bytes. Canonical complete POST body ≤131072 bytes." Lines 974 to 976: "A later generation that allows the claim lets a retry complete with exactly one POST, so before staging a denial does not poison the claim." Nothing says that a request can be admitted and then be impossible to send.

**Path and line (source: reading).**

- `es/admission/reliable_submit_operational_handoff.go:243`: `EstablishOperational` stores the claim. Nothing before it projects the job.
- Lines 341 to 361: the run is assigned (revision 2).
- Line 368: `d.provider.project(run, jobID)` runs for the first time. Lines 369 to 371: an error returns `OperationalIntegrity`.
- `es/admission/reliable_submit_operational_provider.go:369` and `373`: `raw, err := json.Marshal(job)` and then `parseOperationalJSON(raw, 65536)`, whose first check (line 59) is `len(raw) > limit`.

**Evidence (source: run).**

- `TestRedTeamPR12HeadRequestTooLargeForAJobTakesNoClaim` fails 6 of 6 at head. Each case ends as `kind=0 reason=8 operation=2 write=11` with `Claims:1 Revision:2 Grants:1 Posts:0` (`logs/findings-final-rt3.log`): reason 8 is Integrity, operation 2 is the run assignment, and the claim and the reservation are taken.
- Where the limit is, on the fixture (`logs/rt3-scratch-largejob-intentedits.log`): one argument of 62,293 bytes of `a` completes and 62,294 is stuck. For `<` and for the byte 0x01 the figures are 10,382 and 10,383. For `é` they are 31,146 and 31,147 characters. The figure moves by a few bytes with the length of the staging path; an earlier run gave 62,295 and 62,296.
- It is permanent. The same request delivered again and sent to recovery answers reason 8 both times. Under a new admission generation that allows the claim it still answers reason 8.
- Four of them stop the domain. After four such requests under four submit keys the store holds 4 claims at revision 2 and 4 grants, and an ordinary small request under a fifth key is refused with `reason=9 operation=1`, Capacity at establishment, with no POST.
- With a 15-line candidate in the scratch clone `rt3fix2` (project the job with a placeholder run of the real length before the claim is stored, `candidates/candidate-fix-RT28-2.diff`) the test passes 6 of 6, and the three large requests that fit still complete (`logs/findings-final-rt3fix2.log`).

**The doc/code drift sub-point.** The document limits the canonical job. The code measures the output of Go's `json.Marshal`, which writes each of `<`, `>` and `&` as six bytes, while the provider's own canonical renderer (`appendOperationalJSON`) writes them as one. So a job whose canonical form is about 13,000 bytes is refused as too large when it carries 10,383 of those characters.

**Impact.** The configured caller can use up claim slots and reservations for good, also by accident with an honest large argument, and four requests make the domain refuse everything. Slots and reservations are not refundable by design, so there is no way back short of a new domain. Reach today: the handoff has no production caller, so nothing outside the tests can do this at this head. It becomes reachable the day the handoff is wired.

**Required correction.** Before `EstablishOperational`, build the job with a placeholder run and job name of the real length and apply both bounds (the 65,536 job bound and the 131,072 body bound). Refuse a request that does not fit as malformed, with no claim and no reservation. Decide which encoding the 65,536 bound measures and make the code and the sentence at line 1345 agree. The delivered test passes once such a request either completes or is refused before it takes a claim.

**Uncertainty.** I tested arguments only. Environment values and other members that enlarge the job are covered by the same correction by construction (Inference). The bound itself may be intended to be smaller than what the parser admits; the defect is the order of the checks, not the number.

## 6. Observations (no finding)

**O-1. Documented crash limits, shown concretely.** In the double-SIGKILL run, 70 of 150 rounds ended with a claim that keeps its staged tree and cannot stage again, and 20 of 150 with a durable marker and no sender (`logs/rt3p-150.log`). Both are outcomes the owner document names: lines 976 to 977 for the residue ("After staging the claim keeps its charged residue and cannot stage again; it needs a new submit key"), and lines 1534 to 1539 for the marker ("Recovery, replay, no-op, losing CAS and restart allocate zero" senders, "with indefinite ambiguity, inert residue and zero delivery possible"). The kill windows were chosen to land inside the handoff, so these are not production rates. Each such claim keeps its slot and its reservation.

**O-2. The withdrawal fence is held twice, the advance fence once.** A mutant that makes the writer compare the admission read before the turn instead of inside it (RM1), and one that removes the comparison from the establishment turn (RM2), are both caught by the advance test and both survive the withdrawal test. The reason is the schema trigger `reliable_submit_claims_guard_operational_update`, which refuses a claim write when no admission row is in state 1, independently of the Go comparison. With the trigger line removed as well (RM3) the withdrawal test fails 28 of 200 rounds. So nothing is weak here; whoever changes that trigger should know that it is the second half of the withdrawal fence and that the advance fence has no second half.

**O-3. Three members of the retained request are not tied to the bound plan.** The retained original keeps the request (field 2) next to the plan (field 3). `validateOperationalPlan` ties argv, both digests, the output id, the timeout, the resources and the profile. It does not tie the request's environment values, its mode or its other annotations. Source: run, `logs/rt3-scratch-largejob-intentedits.log`: an original whose request has another environment value, no environment, mode `""` or `"async"`, or an extra annotation is accepted by the verifier and by the retained qualification; a changed argv, output id or timeout is refused by the encoder; an added environment key, mode `"sync"` or another profile is refused by the verifier. In the single-bit scan, 29 edits in field 2 pass both readers (`logs/rt3-scratch-bitscan.log`). This is harmless today for two reasons. Planting such an original needs the envelope key and the row digest. And nothing reads those members: the job is built from the plan, and the policy context takes from the request only the argv, the artifact digest and the profile. The delivered tripwire `TestRedTeamPR12HeadPolicyContextReadsOnlyTiedRequestMembers` fails the day the policy context gains a member, so the tie has to be added before a policy can read an untied one. That test is the machine-enforced trigger for this observation.

**O-4. One respelling of the evidence record passes, as already accepted.** Of 42,792 single-bit edits of the retained original, the verifier alone accepts 512 in field 1 (the claim identity, which the store ties by its own comparison and digest), 29 in field 2 (O-3) and 1,709 in field 8 (the evidence record). The retained qualification then refuses all but one of the 1,709: a change in the unused trailing bits of the base64 signature. `internal/contracts/evidence/v1/record.go:79` decodes the signature with the non-strict decoder after `TrimSpace`. The signed claims are unchanged, the file is unchanged by PR #12, and the adopted test `TestRedTeamPR13HoldsChangedEvidenceNeverQualifies` already says in its comment that a record carrying the same signed claims may qualify. No field among 3 to 7 and 9 to 11 accepts any edit.

**O-5. A private request that names the default profile is refused on the fixture.** With the annotation set to `static-script/default`, the resolver answers `unsupported runtime profile "static-script/default"` and the composer refuses before any claim; with the annotation empty or absent the plan gets that same profile (source: run, scratch probe, not kept as a test). So the clause `i.profile.value == p.runtimeProfile.name` in `validateOperationalPlan` (line 75) was not reached by any request I could build. Unknown: whether an existing test or a production configuration reaches it.

**O-6. `trunk_dev` moved during the pass.** At 20:07 UTC `trunk_dev` went from `8ba1edb` to `76c030f` (PR #27, caller authentication). Source: run, `head/trunk-dev-moved.txt`. No file under `es/admission` changed in that step, and `submit.go` and `validateInvocationAgainstManifest` are identical, so RT28-1 is present on the new `trunk_dev` too. A trial merge of `76c030f` into `4416699` conflicts in `PLANS.md` only. Inference: my behavioural results carry over to the merged tree, because every package I attacked is byte-identical in it. I did not test the merged tree.

## 7. N-1: the three Nomad requests without ES's token

**Facts (source: run and reading).** PR #31's guard test, run against PR #12's head in a scratch clone, lists eight request sites (`logs/pr31-guard-on-pr12-tip.log`). Five are the existing sites that PR #31 itself converts. Three are new in PR #12:

- `es/admission/reliable_submit_operational_handoff.go:666`: `POST /v1/jobs`
- `es/admission/reliable_submit_operational_provider.go:622`: `GET /v1/job/<name>`
- `es/admission/reliable_submit_operational_provider.go:657`: `GET /v1/job/<name>/evaluations`

All three are built by `operationalProvider.prepareExchange` (line 438), which sets `Accept-Encoding` and `Content-Type` and nothing else. The string `X-Nomad-Token` does not occur in any non-test file at PR #12's head. The requests go over TLS to the one host and port of the realm, with `region` and `namespace=es-operational-v1` in the query.

**Security consequence (Inference from reading; no ACL-enforcing Nomad was available).**

1. While Nomad does not enforce ACLs, the token makes no difference: every request is anonymous, and whoever can reach Nomad's API can register and stop jobs. For the private path the damage is bounded in one respect. The job name comes from 32 random bytes chosen at the run assignment, ES registers with `EnforceIndex` at index 0, and the later read requires version 0, an unchanged job index and ES's own correlation value in the job's metadata. So a job that someone else registered or re-registered under that name is never taken for ES's own: ES answers Continuity and gives no receipt. The foreign job still runs. That is the existing dependence on who can reach Nomad, which the Nomad lock exists to remove.
2. Once Nomad enforces ACLs and these three requests are still anonymous, they are refused. The POST comes after the marker is durable, so every private claim stops at "marker, no receipt", and the two reads that would reconcile it are refused as well. Each such claim keeps its slot and its reservation. This fails closed: nothing runs that should not.
3. The security edge is the workaround. If the anonymous policy were given job rights to make the private path work, the lock would be open again for everyone who can reach the API. The correct end state is that these three requests carry ES's own token, limited to submitting and reading jobs in the namespace `es-operational-v1`.

**Trigger.** PR #31's guard test fails on these three lines, so whichever of #12 and #31 lands second cannot merge without routing them. No further trigger is needed.

## 8. Attack inventory: what held

Every row is "source: run"; logs are in `logs/`.

| # | Attack | Result |
| --- | --- | --- |
| A1 | Withdraw the admission at a random instant while a handoff runs, 300 rounds | Held. The change landed at every durable step: revision 0 in 24 rounds, 1 in 18, 2 in 20, 3 in 119, 4 in 20, 5 without a POST in 7, and 92 rounds had already sent. No first-effect write after the change returned, and no POST without a marker that was durable before the change. `rt3-300.log` |
| A2 | Advance the admission to a new generation at a random instant, 300 rounds | Held. Revision 0 in 23 rounds, 1 in 16, 2 in 17, 3 in 118, 4 in 6, and 120 had already sent. `rt3-300.log` |
| A3 | A1 and A2 under the race detector, 60 rounds each | ok, no data race reported. `rt3-race60.log` |
| B1 | SIGKILL a child inside the handoff, SIGKILL a second child that picks the claim up, then let a survivor finish, 150 rounds | Held. Completed 60, marker without sender 20, stage residue 70 (O-1). Never two POSTs, never a POST without a durable marker. After the first kill the claim was at revision 1 in 31 rounds, 2 in 20, 3 in 44, 4 in 21, 5 in 28, 6 in 6. `rt3p-150.log` |
| B2 | Three child processes and the parent deliver the same claim at once; in every third round one child is killed, 150 rounds | Held. Without a kill 100 of 100 completed with exactly one POST. With a kill 48 completed and 2 ended as stage residue. `rt3p-150.log` |
| B3 | A foreign connection takes the writer lock for up to 8 ms again and again and truncates the WAL while a delivery runs, 150 rounds | Held. 1,269 foreign holds; every delivery was accepted with exactly one POST. `rt3p-150.log` |
| C1 | 32 requests at the edges of the parser (100 empty arguments, control bytes, 128 annotations, largest strings): compose, verify, store shape check, qualify | Held. What the composer writes, the verifier reads back, the store accepts, and the qualification judges identically. `rt3-final2-all.json.gz`, test `TestRedTeamPR12HeadEveryComposedOriginalReadsBack` |
| C2 | Three large requests that still fit, through the store and delivered twice | Held. Completed with one POST each. |
| C3 | Flip each of the 42,792 bits of a retained original | Held, with O-3 and O-4. |
| C4 | Fuzz edit scripts on the retained original against the verifier and the store's shape check, 8 minutes | Clean, 3,336,517 executions. Neither reader panics; an edited original that the verifier accepts re-encodes to itself and leaves fields 3 to 7 and 9 to 11 unchanged. My first property (only field 1 may differ) was too strong and failed in 0.35 s on the O-4 respelling; that log is kept as `fuzz-…-firstproperty.log`. |
| D1 | Fuzz the provider's JSON reader against `encoding/json`, 6 minutes | Clean, 2,197,267 executions. The reader accepts nothing the standard library refuses, both read the same value, and the canonical rendering is stable. |
| D2 | Fuzz the job template renderer, 3 minutes | Clean, 856,353 executions. A rendering that succeeds carries every member of the job unchanged. |
| D3 | The two adopted fuzz targets of the earlier round, 5 minutes each | Clean, 2,399,439 and 2,940,195 executions. |
| E | Requests at the size and content limits through the whole handoff | RT28-1 and RT28-2. |
| F | PR #31's guard against PR #12's head | Section 7. |

## 9. Mutation runs: do the new tests catch what they claim

| Mutant | Change (scratch clone only) | Result |
| --- | --- | --- |
| RM1 | `applyOperational` compares the admission read from the pool before the turn, not the row read on the turn's connection | Advance test fails 96 of 300 rounds. Withdrawal test passes (O-2). `rt3m1-300.log` |
| RM2 | `EstablishOperational` no longer compares the admission inside its turn | Advance test fails 28 of 300 rounds. Withdrawal test passes (O-2). `rt3m2-300.log` |
| RM3 | RM1, and the trigger's admission line removed, and the schema-5 digest comparison skipped so that the changed schema opens | Withdrawal test fails 28 of 200 rounds. `rt3m3-200.log` |

The diffs are in `mutants/`. The three mutant runs were not verbose, so their logs show only the failing test; for RM1 and RM2 the withdrawal test ran in the same command and passed, which the logs show only as the absence of a failure and a total run time of 80 and 86 seconds. The first form of RM3 failed every round with "reliable submit store: unsupported format": the schema digest pin refuses a store whose trigger text was changed, which is a second thing that held.

## 10. What I ran

| Run | Result |
| --- | --- |
| Baseline, clean head: `go test -count=1 -json ./es/admission/...` | 3,351 pass, 15 skip, 3 fail. The three are `TestOperationalHandoffSchema4BinaryRefusesSchema5`, `TestSQLiteV3OldBinaryRefusesWithoutMutation` and `TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation`, all on the repository's environment-only list. `base-admission-all.json.gz` |
| Head plus the five new test files as delivered, same command | 3,482 pass, 15 skip, 16 fail: the same three, and the two finding tests with their 11 subtests. No existing test changed its result. The five files add 144 results: 131 pass and those 13. `go vet` exit 0, `gofmt -l` empty. `rt3-final2-all.json.gz` |
| Every package outside `es/admission`, clean head against head plus the new files | Identical on both sides: 40 packages, 3,884 pass, 84 skip, 38 fail, and no test with a different result. The 38 are 8 top-level tests of the root package with their subtests, all on the environment-only list. So no repository-wide guard objects to the new files. `rest-compare.txt` |
| The finding tests alone, at head and under each candidate | Head: 5 of 5 and 6 of 6 fail. Candidate for RT28-1: the argv test passes, the size test still fails. Candidate for RT28-2: the size test passes, the argv test still fails. `findings-final-*.log` |

The adopted crash test names its subtests by random delays, so 24 of its subtest names differ between any two runs; they are not counted as new or missing.

During the pass I changed two cases of the size test from "just past the limit" (62,296 and 10,383 bytes) to sizes that do not depend on the length of the staging path (63,000 and 10,500 bytes). The diff is `scratch/finding_test.size-edit.diff`. Rows two to four were run after that change, with the files exactly as the patches deliver them.

## 11. Regression tests delivered

Two patches against `4416699`, next to this report. Both apply to the clean head with `git apply --check` (source: run).

| File | SHA-256 | Content |
| --- | --- | --- |
| `28-redteam-regression-tests.patch` | `1e520116bd8ab0e7b1a4c964e24b007056ae94b2e21c7bce85b73f9d67d9b708` | Four new files in `es/admission`, all passing at head: the two fence tests, the three process tests, three fuzz targets, the codec round trip, the large-request test and the O-3 tripwire. |
| `28-redteam-finding-tests.patch` | `6e94a4f69dbd8f186a4d080ccdf8801a43bab60b0cc81a7941584d62a179f648` | One new file with the two tests that **fail at head**: RT28-1 and RT28-2. It uses helpers of the first patch, so it goes second. It cannot merge before the corrections. |

Notes for the writer:

- Round counts default to 24, 16, 12 and 16 and take `ES_RT3_ROUNDS`; `ES_RT3_SEED` repeats a run. The three process tests start child processes through the existing `TestOperationalHandoffChildProcess` sentinel.
- Subtest names must not contain `=`. Go puts the test name into `t.TempDir()`, the fixture stages under it, and the custody rules refuse a path with `=`. My first version failed for exactly that reason.
- The patches carry no production change. The two candidate diffs in the evidence folder are there to show that the tests pass with a correction, not as proposed code.

## 12. Coverage this environment could not provide, and what I did not do

1. **The raw-memory guard, including the R14-1, R14-2 and A6-1 `//line` roads, aliases, build tags and generated code.** Not attacked. A safety check in my session stopped that part of the work and told me not to produce it again, and I did not resume it. The audit thread's `28a-guard-coverage.md` is a read-only completeness review of the guard, written at the coordinator's request, with finding G28-1. A hands-on evasion pass on the guard is still open.
2. **A running Nomad.** RT28-1 rests on Nomad's source at v2.1.1, not on a task that I saw start. Downloading and running the binary was refused by this session's permission check. One live check on the Linux box closes it.
3. **The Linux box**, and with it real EGS, SPIRE, Vault, Nomad with ACLs and Docker. Not reachable from here. Section 7 is from reading for that reason.
4. **macOS.** Nothing ran there.
5. **Power loss and torn writes.** SIGKILL of a process is not loss of power. No test here cuts a write in the middle of a page or drops an fsync.
6. **Path and symlink attacks beyond the earlier rounds.** I added none. In particular a race that swaps the staging root while a handoff stages was not run.
7. **More than one claim in flight at the synthetic Nomad.** The suite's receiver holds one job, so every race here is for one claim.
8. **The v2 provenance recipe.** Not re-run; I compared my checkout with report 26's manifest file by file instead (section 2).
9. **The merged tree with the new `trunk_dev`** (O-6). Not tested.

## 13. Sensitive material

The evidence holds logs of synthetic fixtures, test files, diffs, scripts and hashes of public source files. It holds no key, token, certificate body or configuration file of any real system. The Nomad and HCL source files themselves are not copied; `reference-sources.txt` gives their URLs and SHA-256 values. Before publishing I scanned this report, the two patches and every evidence file (82 files, compressed logs read decompressed) for private-key and certificate headers, key and token shapes of Vault, GitHub, Anthropic, OpenAI and AWS, JWTs, e-mail addresses, phone-number shapes and model names, with a positive control that matched every pattern it should. Result: no hit, with two explained exceptions. The Vault token shape matches 36 times in the two `rest-*.json.gz` logs; all 36 are the alphabet placeholders `hvs.abcdefghijklmnopqrstuvwxyz` and `hvb.abcdefghijklmnopqrstuvwxyz`, which are subtest names of the repository's own tests (for example `remote_alpha_operator_test.go:3728`). The same two placeholders are quoted in this paragraph. And the scanner's own pattern text in `scripts/scan.py.txt` matches two of its patterns.

## 14. Confidence

- RT28-2: high. Measured end to end, with thresholds, permanence, the four-claim fill and a candidate correction.
- RT28-1: high that ES sends the text unchanged (measured); high that Nomad v2.1.1 evaluates it (five source locations that agree); not measured live.
- "Held" results: high for the instants and interleavings my runs reached, which the outcome tables show cover every revision. They are random samples, not proofs.
- Section 7: medium. From reading only.

## 15. How to reproduce

```
git checkout 44166998d4ef0d7b86152f3f66265b906f7d612a
git apply 28-redteam-regression-tests.patch 28-redteam-finding-tests.patch
go test -count=1 -run 'TestRedTeamPR12Head' -v ./es/admission/
ES_RT3_ROUNDS=300 go test -count=1 -run 'TestRedTeamPR12Head(Withdrawal|Advance)' -v ./es/admission/
go test -count=1 -run '^$' -fuzz '^FuzzRedTeamPR12HeadVerifyOperationalOriginal$' -fuzztime 8m ./es/admission/
```

The first `go test` line ends with exactly two failing tests, `TestRedTeamPR12HeadCallerArgvIsNotEvaluatedByNomad` and `TestRedTeamPR12HeadRequestTooLargeForAJobTakesNoClaim`. Run it as an unprivileged user; the suite's custody rules refuse root-owned staging.

## 16. Effect status

| Effect | Status |
| --- | --- |
| Repository edits, commits, pushes, PRs, comments, merges | None performed. Not authorized by the brief ("Do not push to PR 12") and not needed. |
| Live-service contact | None. |
| Files written to the project folder | This report, the two patches and the folder `28-redteam-evidence/`. |
| Message to the writer's thread | Sent after this report was written, with the paths of the two patches. |
