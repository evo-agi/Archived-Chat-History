# 22-audit-pr26-repair evidence (ES PR #26, `0aba38e` to `c99a1b4`)

Written by the independent audit thread "Audit Execution-Substrate PRs" on 2026-11-23, from 16:13Z onwards. Every file here was made in the audit's cloud container or fetched read-only. `SHA256SUMS.txt` lists every file.
The report is numbered 22 because another audit took 21 first. File, script and test names here (`probes21.py`, `TestAudit21…`) and the script comments that say "A21-1" use the working number 21: A21-1 there is the report's A22-1.
Nothing in this folder is authority. It is evidence for `../22-audit-pr26-repair.md`.

## Setup

- **Clone and recipe.**
  - The repository clone is `/opt/audit/es`.
  - Manifests use the v2 recipe `/opt/audit/v2.py` (SHA-256 `c08597e2…a3ca`), checked before each run.
  - Each run checks out the topic branch at the tip, resets it to the base, and pins the upstream to `origin/trunk_dev`.
- **Test trees.** All are `git archive` exports in `/home/ci`:
  - `pr21h` and `es21`: head `c99a1b4`.
  - `pr21b` and `b21`: previous head `0aba38e`.
  - `/home/ci2` holds copies for the second identity.
  - `fix21`: `c99a1b4` + `presence-exact-proposal.diff`.
  - `m21`: the trial merge of PR #28's head `2c8bf35` with `fix21`'s commit. The two known conflict blocks are resolved by the PR #12 merge plan (see `trial-merge-provenance.txt`).
- **Identities.** Runs used `env -i` and Go 1.26.5 with `GOTOOLCHAIN=local`, as user `ci` (1500:1600, with sudo) and user `ci2` (1700:1700, without sudo).
- **Probes and mutants.** Each one ran in a fresh copy of a pristine tree.
- **Local commits.** The proposal commit used for the trial merge was made in a temporary index, author "audit", and never pushed.
- **No downloaded binary was executed.** `dto26b-writer.py.txt` is the writer's probe script from `02-repair-evidence/helper/dto26b.py.txt`, copied verbatim and read in full before it ran.

## Files

| File | What |
| --- | --- |
| ls-remote-open.txt, ls-remote-close.txt | Remote refs at the start (16:13Z) and at the end (16:30Z). Both times the branch was at `c99a1b4` and `trunk_dev` at `036d507` |
| manifest-v2-open-…-run1/2.json (+ .out.txt), manifest-v2-close-…-run1/2.json (+ .out.txt) | `c99a1b4` against `036d507`: `a36f06ef…9b30` all four times. The JSON is byte-identical across runs and to the writer's `manifests/c99a1b4-vs-036d507-trunk-1.json` and `-2.json` |
| delta-0aba38e-c99a1b4.diff | `git diff 0aba38e c99a1b4` |
| equivalence-proposal-vs-c99a1b4.diff | `0aba38e` + audit 20's `object-level-allow-proposal.diff` compared with `c99a1b4`. Only the JSON helper, its test and two imports differ |
| writer-evidence-check.txt | The writer's report hash, its `SHA256SUMS` check (81 of 81 OK), and the manifest comparison |
| unit21.sh.txt, run-unit21.sh.txt, unit-admission-c99a1b4-vs-0aba38e-uid1500-gid1600.log, -uid1700-gid1700.log | gofmt, vet (three targets) and es/admission in full at both heads, for both identities, with a diff of the results |
| probes20.py.txt, probes20-c99a1b4-uid1500-gid1600.log | Audit 20's probes P00 to P30 on `c99a1b4` (tree label `c99`): all 31 as predicted |
| mutants20.py.txt, mutants20-c99a1b4-uid1500-gid1600.log | Audit 20's 22 mutants (M07 to M21 and F01 to F07) on `c99a1b4`: all caught |
| zz_audit21_fold_test.go.txt, zz_audit21_custom_test.go.txt, fold-and-custom-json-c99a1b4-uid1500-gid1600.log | Probe tests, run in a copy of `c99a1b4` with `go test -run TestAudit21 -v ./es/admission/`. One checks the helper's fold against `encoding/json` over every rune and its tag check against `isValidTag`. The other walks the DTO guards' types for custom JSON or text methods |
| probes21.py.txt, probes21-uid1500-gid1600.log | Probes Q0 to Q5 on both heads (Q6 was added afterwards; its run is in the next file) |
| probes21-with-fix-uid1500-gid1600.log | Q0 to Q6 on `0aba38e`, `c99a1b4` and the proposal |
| probes21-trial-merge-uid1500-gid1600.log | Q0, Q1, Q2, Q3 and Q6 on the trial merge with the proposal |
| presence-exact-proposal.diff | The A21-1 fix (`patch -p1` on `c99a1b4`, test-only, 3 files) |
| fix21-apply.py.txt, fix21.sh.txt, run-fix21.sh.txt, presence-exact-proposal-uid1500-gid1600.log | How the proposal was made and checked: gofmt, vet (three targets), and es/admission in full, which matches `c99a1b4` test for test |
| mutants21.py.txt, mutants21-fix-uid1500-gid1600.log | 5 mutants of the proposal and a control. K01 to K04 are caught. K05 survives the suite, as expected; probe Q3 catches it |
| merge21.sh.txt, run-merge21.sh.txt, trial-merge-provenance.txt, trial-merge-pr28-2c8bf35-with-proposal-uid1500-gid1600.log | The trial merge of `2c8bf35` with the proposal: the merge-tree results with and without the proposal, the presence sites in `2c8bf35`, the resolution, and build, vet, gofmt and es/admission in full on the merged tree |
| trial-merge-results-vs-writer.txt | My es/admission results on the trial merge with the proposal, compared test for test with the writer's `pr12-trial/trial28p-admission.results.tsv` (random SIGKILL rounds compared by round number) |
| rprobes21.sh.txt, dto26b-writer.py.txt, writer-rprobes-c99a1b4-and-proposal-uid1500-gid1600.log | The writer's real-tree probes R0 to R7 on `c99a1b4` and on the proposal |
| ci-status.txt | CI runs on `0aba38e` and `c99a1b4`, read through the GitHub API |

## Sensitive material

The probes and fixtures are synthetic. No key, certificate body, token or config file is copied here. Commit-message trailers and author names are left out.
