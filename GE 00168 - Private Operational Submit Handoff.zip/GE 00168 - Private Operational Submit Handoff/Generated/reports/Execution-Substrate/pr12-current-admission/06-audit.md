# INDEPENDENT AUDIT REPORT

Workstream `pr12-current-admission`, stage 06: fresh audit of the repair of Execution Substrate draft PR #13.
Written 2026-11-22 (UTC) by a fresh audit thread. Read-only: nothing was edited, pushed, commented or merged.

**Final verdict: BLOCK**

## 1. In plain words

1. **The production code of the repair holds.** It implements the approved design. I found no path, by reading or by my own 150 mutants, on which a first-effect write commits for a process whose authority is stale, withdrawn, superseded or unconfirmed. The race detector reports no data race in either changed package. No test went from pass to fail against the blocked tip.
2. **Every earlier finding is fixed, except one.** Each fix that changes behaviour has a regression test. Section 7.1 says for each one whether I confirmed it with a mutant of my own or by reading. The exception is RT-1, the red team's finding about the test guard.
3. **RT-1 is not closed, and that is why I block.** The guard fix catches every shape the red team listed. One mirrored shape still passes: converting a *pointer* to a protected value into a pointer to a same-shape struct and writing through it. I rebuilt the red team's own end-to-end mutant in that form. With it, production code clears the revocation lists of the installed authority, and the build, `go vet`, the guard tests and the whole `es/admission` package (1,811 results) stay green. A second mutant clears the "withdrawn" and "superseded" latches the same way, with the same result. The contract does not list this shape as a limit. It says the opposite.
4. **This is a gap in the tests and in the contract text, not in shipped behaviour.** Nothing in production uses the shape. The risk is forward: a later change could weaken the authority while the tests that are described as preventing that stay green. That is the same impact the red team rated medium, shown by the same kind of demonstration, so I rate it medium and blocking (finding A2-1).
5. **The blocking repair is small.** One added clause in the guard, a few regression cases, and corrected sentences in the owner document. Section 9 lists it.
6. **Seven low findings (A2-2 to A2-8)** belong in the same repair. None blocks on its own. They are a second, smaller guard gap, three statements about locks that the code does not match, an unscoped outcome row, two tests that are weaker than they read, three checks in the new store write that no test observes, and the answer to a cancelled call, which is not always "cancelled". One pre-existing low item (P-1) is cheap to close in the same pass.

What I did not do: red-teaming, macOS, the Linux box (non-goals of the brief). Twelve tests cannot run in this container: nine Remote Alpha operator-script tests of the root package and the three old-binary refusal tests of the store package. They fail the same way at the blocked tip and at the repaired tip.

## 2. Audit target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Pull request | draft PR #13 (a fix PR into the PR #12 branch) |
| Topic branch | `claude/project-thread-sqldt7` |
| Audited commit | `b6d2f7787ec8254134cb48fcae0da72bac0fd02c` |
| Tree | `b1d14b017665eb996a82568f229472b6996523f4` |
| Base | `8058561edc08356c46680c204586b3c7796c0ff3` |
| Previously blocked tip | `e544e0fbe4220dfdd2c2068e3267dcfa454a0cf9` |
| Repair commits | `1fa8d72` (production, documents, tests), then `ca902a6`, `1826cef`, `af23316`, `b6d2f77` (test files only; verified by me with `git diff --stat` per commit) |
| Recipe | `governed_execution_audit_patch_manifest_v2.py`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified before every run) |
| Manifest, base-relative | `8659b099098575e19b9bbcade2a9f63d513a0a389b732294a22a313c64dd3d74`, 26 changed paths, +9,957 / -212 |
| Manifest, repair only (against `e544e0f`) | `2b6c6ee326b702b911066aa9573eb67b2ed7d69ce69e01fb12d964dcbd96ef63`, 25 changed paths, +7,583 / -906 |
| Implementation report | `05-repair.md`, SHA-256 `d3891db8fdafb46fa45f24ed8cdaab714142b0bdcaceb7da1051d89603b18994` (verified) |
| Approved design | `04-design-proper-admission.md` |

## 3. Audit posture

- Read-only. The provenance clone `/home/user/Execution-Substrate` was never modified. Every test, mutant and probe ran in scratch copies under `/home/ci`, as an unprivileged user, with `GOPROXY=off` and `GOTOOLCHAIN=local` (Go 1.26.5, linux/amd64).
- Parent plus three read-only subagents (test adequacy, guard, documents). They ran nothing and changed nothing. Their findings are listed in section 6.5 with what I adopted, verified or rejected.
- No push, no PR, no comment, no merge, no access to any live service, David's Mac or the Linux box.

## 4. Provenance reproduction

| Step | Result |
| --- | --- |
| Recipe bytes | SHA-256 matches the pinned value. Checked before the opening runs and again before the closing runs. |
| Remote tip | `git ls-remote` showed the branch at `b6d2f77…` at the start. At the end (2026-11-22T12:53:59Z) it was still at `b6d2f77…`. |
| Base-relative manifest, run twice | Byte-identical. SHA-256 `8659b099…3d74`, 26 paths. Equals the writer's value. |
| Repair-only manifest, run twice | Byte-identical. SHA-256 `2b6c6ee3…ef63`, 25 paths. Equals the writer's value. |
| Closing manifests | Run twice each after the last test, mutant and probe had finished. Byte-identical with each other and with the opening manifests: `8659b099…3d74` and `2b6c6ee3…ef63`. The clone was clean before and after (tracked, untracked and ignored files), at `b6d2f77`, with its branch and upstream restored. Output: `06-audit-evidence/manifests/closing-run.txt`. |
| Mode bits | No mode-bit difference was tolerated or needed. |

No provenance mismatch.

## 5. Coverage

**Read in full by me:** the two new production files (`es/admission/reliable_submit_operational_admission.go`, 503 lines; `es/admission/internal/reliablesubmit/operational_admission.go`, 319 lines); the changed parts of the other eight production files (ten production files in all, +1,194 / -81 against the base); the red-team test file's complete difference against PR #15's `5ca4079` (16 hunks, +150 / -23; my diff has the same changed lines as the writer's attachment); the guard code that the repair changed (`wholeValueReferences`, the classifier steps, the commissioning gate, the import inventory, the table-writer inventory); the owner document's sections on the durable fact, the token cuts, freshness, outcomes, guard and limits; `05-repair.md` sections 1 to 11; the design sections 5 to 8 and 12.

**Read by subagents and spot-checked by me:** the seven changed documents and `docs_contract_test.go`; the three large test files.

**Schema and migration:** the amended migration 5 text, the table, its three triggers and the two claim-trigger clauses (`sqlite_operational_handoff_schema.go:277-328, 461-463`); 16 schema mutants with the digest pin moved out of the way.

**Artifacts classified before opening:** `05-repair-mutant-evidence.tar.gz` (SHA-256 `d881d896…`). Listed first without extraction: plain text, Python and shell files only, no links, no absolute or parent paths. Extracted into its own empty directory, execute bits removed, read with `python3 -I`. Nothing from it was executed. I used it only to compare the writer's survivor list with mine.

**Not inspected:** files outside the 26 changed paths, except where a changed line calls into them (`egs/model/trustmodel.go`, `policy.go`, the PB1 format code). `trunk_dev` beyond confirming it carries schemas 1 to 4 only. Anything on David's Mac or the Linux box.

## 6. Findings

### 6.1 Summary

| ID | Severity | Kind | One line |
| --- | --- | --- | --- |
| A2-1 | medium, **blocking** | patch defect, guard tests and contract | A write through a pointer conversion away from a protected type passes the guard and the whole package. RT-1 still reproduces. |
| A2-2 | low | patch defect, guard tests | The commissioning gate does not see a call made through an interface. A second gate still catches a complete wiring. |
| A2-3 | low | patch defect, documents against code | Three statements about locks do not match the code. |
| A2-4 | low | patch defect, documents and tests | The "Denied" row is not limited to retained claims. A fresh delivery that the current rules refuse reports Unavailable, and no test pins that reason. |
| A2-5 | low | patch defect, tests | The value of the shared evidence cap (256 KiB) is pinned by no test any more. |
| A2-6 | low | patch defect, tests | The published-shape test accepts any error from three of four openers, and its control covers two. |
| A2-7 | low | patch defect, tests | Three checks of the store's admission write, the answer to an unknown COMMIT among them, have no test. |
| A2-8 | low | patch defect in part, documents against code and tests | A cancelled call answers Unavailable while ES waits for EGS and Integrity in one narrow window, not Canceled. The check that keeps the other answers Canceled has no test. |
| P-1 | low | pre-existing | One clause of the store fence (the returned match must be for this original) has no test, before or after the repair. |
| O-1 to O-13 | observation | mixed | Section 6.4 |

### 6.2 Patch defects

```text
AUDIT FINDING
ID / Type / Severity: A2-1 / test and contract gap in the typed guard (RT-1 not closed) / medium
Current contract or strategic target:
  .docs/execution_lifecycle/reliable_submit_operational_handoff.md:534-551: "A protected field
  can also be written without being spelled. For every protected field the inventory therefore
  also lists each whole-value occurrence of its owning struct type as its own access kind: ...
  a conversion to the owning type or to a pointer to or container of it (whole-convert) ...".
  Lines 553-560 name the limits that remain: "values reached through an alias or pointer that
  was itself obtained at an inventoried site; the bodies of called functions and methods ...;
  reflection; unsafe; and cgo."
  Red-team report 03, RT-1, required correction: fix the guard, or name the shapes as exclusions.
  Repair report 05, section 4.8: "Guard fix, taking the red team's first option in full".
Path and line: es/admission/workstream_c_guardrails_test.go:3939-3944 (wholeValueReferences).
  A conversion is recorded as "whole-convert" only when the RESULT type is the owner or a pointer
  or container of it. The operand type is used only for an identity check. A conversion whose
  operand is a pointer to the owner and whose result is a pointer to another struct of the same
  shape is recorded nowhere. The owner is matched by identity of its struct type (:3832), so the
  fields written through the result belong to another type and no protected field is spelled.
Evidence (all run by me on the exact tip bytes, in scratch copies):
  1. Synthetic packages against the tip's own validators (06-audit-evidence/guard-probe-synthetic.txt):
     "(*twin)(s).value = 1", the anonymous form, the form kept in a variable, and the whole
     overwrite "*(*twin)(s) = twin{}" each give zero references and are accepted by both the
     field-access inventory and the object inventory. Controls are refused: the spelled write, the
     red team's value conversion, a conversion TO the owner pointer, a second literal.
  2. Real package, mutant GM1 (guard-probe-real.txt). It is the red team's mutant
     (03-red-team-poc/mutant-anonymous-struct-conversion.diff) with one change: the installed view
     is converted as a pointer, "(*struct{...})(snapshot)", and the revocation lists are cleared
     through it. Result: go build ./... exit 0; go vet reports only the old result_auth_test.go:395
     line; the nine guard tests pass (250 results, 0 failures); the whole es/admission package
     passes (1,811 results, 0 failures).
  3. Real package, mutant GM2. The receiver "s" is converted to a pointer to an anonymous mirror
     of Service, and operationalWithdrawn, operationalSuperseded and operationalConfirmed are
     written through it. Same result: build, vet, guard tests and whole package all green.
  4. Control: the same rewrite spelled through the field names fails
     TestExecutionSubstrateSynchronizedMutableStateReferenceInventoryIsExact.
  5. The writer's own mutant list (05-repair.md 11.8) counts the red team's end-to-end mutant E1
     as killed by the guard. GM1 is E1 with a pointer conversion and survives everything.
Impact: none on shipped behaviour. No production code uses the shape: the non-test files of the
  two packages contain no pointer conversion at all (searched by me). The risk is forward: a
  later change, by a person or an agent, can rewrite the installed admission content or clear the
  stop latches while the tests described as maintaining those properties stay green, and nothing
  in the inventories changes, so no reviewer is prompted to look. This is the impact statement of
  RT-1, word for word, and the demonstration is the same kind.
Required correction (one of):
  a. Fix the guard: also record a conversion whose OPERAND is a pointer to the owner (or to a
     defined type over it) when the result is not. Go permits that conversion only between
     pointers to same-shape structs, so the rule is narrow. Add self-test cases (named twin,
     anonymous twin, named pointer type, alias kept in a variable, whole overwrite through the
     converted pointer, and a negative control), add the two end-to-end forms to the maintained
     escape tests, and state the rule in both directions at owner document 538-540.
  b. Or name the shape as a limit at owner document 553-560 and pin the exclusion in a test. I
     recommend (a): unlike the named limits, this shape leaves no trace in any inventory.
  In both cases correct the sentence at 534-535, which today reads as complete coverage.
Uncertainty: a reader could argue that GM1 falls under "an alias or pointer obtained at an
  inventoried site", because the view pointer comes from a method whose field read is inventoried.
  GM2 cannot be read that way: the receiver is not obtained at any inventoried site. I searched
  for further shapes of the same kind (same function, no trace, not a named limit) and found none
  besides A2-2. That is a search, not a proof.
Patch defect or pre-existing issue: patch defect in the guard and the contract text of this
  repair. Production code is not affected.
```

```text
AUDIT FINDING
ID / Type / Severity: A2-2 / test gap in the commissioning gate / low
Current contract or strategic target: design section 8: the trigger for production commissioning
  is the "first non-test reference to commission, advance, withdraw"; owner document guard
  section: "zero non-test references" to the three Service methods and the two handoff entries.
Path and line: es/admission/reliable_submit_guardrails_test.go:1313-1319 and 1462-1473. The gate
  counts references that resolve to the method object of Service. A call through an interface
  resolves to the interface's method and is not counted.
Evidence (run by me): probe P1 (guard-probe-real-2.txt) adds, inside operatePrivateHandoff, a
  local interface value holding the Service and calls commissionOperationalAdmission,
  advanceOperationalAdmission and withdrawOperationalEffects through it. Build exit 0, vet
  nothing new, guard tests pass, whole es/admission package passes (1,811 results). Control: the
  same call by name fails the gate and prints all five prerequisites.
Impact: the prerequisite list (CP-ROLLBACK, CP-EPOCH, CP-POLICY-CUSTODY, CP-NATIVE, CP-RELEASE)
  is not printed for such a caller. Limited by a second gate: a working wiring also needs a
  domain, and newOperationalDomain is a function, so any reference to it still fails the same test
  (:1474-1479). I therefore rate this low.
Required correction: count selections of the gated method names through interface and
  type-parameter values in the package, or forbid an interface or constraint that declares one of
  those names, with a positive control. Or name dynamic dispatch as a limit of the gate.
Uncertainty: none on the evidence.
Patch defect or pre-existing issue: patch defect (the gate is new in this repair).
```

```text
AUDIT FINDING
ID / Type / Severity: A2-3 / documents against code, lock statements / low
Current contract or strategic target: AGENTS.md section 9: documents, tests and code must
  describe the same current reality. Design 5.5: "Confirm runs outside every lock and every
  transaction", called at "the two pre-checks".
Path and line / Evidence (read by me):
  1. Owner document :457 "Confirmation runs outside every lock and every transaction."; :578-579
     "the confirmation takes no lock while it fetches"; persistence document :551-552; code comment
     es/admission/reliable_submit_operational_admission.go:277. In the code, the two pre-check
     calls run inside the callback of WithOperationalOriginal, which holds OperationalCustody.mu
     in read mode across the callback (internal/reliablesubmit/operational_handoff.go:711-712,
     769; es/admission/reliable_submit_operational_handoff.go:194, 307-308). Only the fresh
     delivery call (:213) holds no lock. True as written: no SQLite transaction, no Service.mu,
     no owner mutex.
  2. Owner document :577-578 "Commission, advance and withdrawal take the SQLite writer without
     Service.mu and never custody, stage or owner locks". In the code all three run in
     operationalAdmissionWrite, which takes OperationalCustody.mu in read mode
     (internal/reliablesubmit/operational_admission.go:143-144).
  3. Admission model document :996, the lock inventory row for OperationalCustody.mu, does not
     list operationalAdmissionWrite as a reader or ConfigureOperationalReleaseProofForProof as a
     writer (operational_admission.go:311). The typed guard inventory was updated; the row was not.
Impact: liveness only, and bounded. OperationalCustody.Close waits for an EGS request in flight
  (bounded by the EGS client timeout, service.go:330). While a Close waits, new read locks queue
  behind it. Tests call withdrawal from inside a borrow, which takes the read lock twice on one
  goroutine; that is safe only while no Close is waiting. There is no production caller today.
  The fence is not affected. The design placed the confirmation at these points, so the code
  conforms to the design's placement; the sentence is what is wrong.
Required correction: scope the sentences to "outside every writer turn, Service.mu and the owner
  mutex; at the two pre-checks the custody read lock of the borrow is held"; say that the three
  operations take the custody handle's lock in read mode and whether they may be called from
  inside a borrow; add the two functions to the lock inventory row.
Uncertainty: none on the code. The deadlock scenario is reasoning about sync.RWMutex, not a run.
Patch defect or pre-existing issue: patch defect (sentences written or kept by this repair).
```

```text
AUDIT FINDING
ID / Type / Severity: A2-4 / outcome mapping, documents against code, and an unpinned reason / low
Current contract or strategic target: owner document :590 "Signer not allowed or revoked,
  artifact revoked, built-in policy denies | OperationalDenied"; PLANS.md:33-34; design 5.6, whose
  stated purpose is that a caller can tell "denied" from "try again later".
Path and line: es/admission/reliable_submit_operational_handoff.go:220-223. A fresh delivery that
  ordinary resolution refuses returns OperationalUnavailable. Denied is produced only for a
  retained original (reliable_submit_operational_admission.go:444-503).
Evidence: read by me at the tip, and the same lines at the base (8058561, :206-209), so the
  behaviour is older than the repair. TestPR12RetainedAdmissionCuts "fresh ordinary policy denial"
  and "fresh ordinary revocation denial" (reliable_submit_operational_admission_test.go:250-272)
  assert the result kind, zero claims and zero POSTs, not the reason.
  TestOperationalAdmissionOutcomeMapping seeds a stored claim for every cause.
Impact: on a first delivery the caller cannot tell "the rules refuse this" from "authority not
  available". Both are value-free; nothing is disclosed and nothing is written.
Required correction: either limit the row and the PLANS sentence to retained originals and state
  the fresh-delivery reason, or report Denied there too. Pin whichever is chosen.
Uncertainty: which of the two the owner wants. The design table does not say.
Patch defect or pre-existing issue: the unscoped text is a patch defect; the behaviour is
  pre-existing.
```

```text
AUDIT FINDING
ID / Type / Severity: A2-5 / test gap, the value of the evidence cap is no longer pinned / low
Current contract or strategic target: owner document :304 "at most 256 KiB within the existing
  1 MiB original; one exported store constant"; prior audit O-6 asked for one shared constant
  and noted that both copies had over-cap test vectors.
Path and line: es/admission/internal/reliablesubmit/replay_custody_structure.go:457
  (OperationalEvidenceLimit = 256 * 1024); store test
  es/admission/internal/reliablesubmit/operational_handoff_test.go:197 and :211, where the
  at-cap and over-cap vectors are now built from the constant itself.
Evidence (run by me): mutants S-CAP1 (constant raised by one byte) and S-CAP2 (constant
  doubled) survive the whole store package and the admission behavioural
  subset, and the whole es/admission package.
  Mutant S-CS3 (the constant doubled at the custody check only) is
  killed by behaviour, so the tests pin that both layers use the constant and
  that the boundary is exact. They do not pin the number. At the blocked tip the store's
  over-cap vector was the literal 256*1024+1 (operational_handoff_test.go:189 at e544e0f),
  so raising the store's cap failed a test there.
  The admission test that still carries the literal (reliable_submit_operational_format_test.go
  :501) puts 'x' bytes in place of signed evidence, which is refused for other reasons too.
Impact: none on behaviour. A later edit of the one constant changes the bound of retained
  evidence in both layers with every test green. The document phrase "256 KiB" is pinned by the
  docs test, the code value is not.
Required correction: pin the value once. The existing table of limits in
  es/admission/resource_limits_test.go is the natural place, or one store vector with a literal
  length (262,144 bytes accepted, 262,145 refused).
Uncertainty: none.
Patch defect or pre-existing issue: patch defect (the literal vector was replaced by this repair).
```

```text
AUDIT FINDING
ID / Type / Severity: A2-6 / test weaker than its stated claim / low
Current contract or strategic target: 05-repair.md 3.3 and 11.5: "A database built from the
  migration-5 text published at 8058561 is refused by every opener, byte for byte unchanged";
  the test's own comment: "the same construction with the amended text is the current schema,
  and every opener accepts it."
Path and line: es/admission/internal/reliablesubmit/operational_admission_test.go:1414-1425
  (refusals) and :1433-1452 (control).
Evidence (read by me): the migrating opener must return the "unsupported" error. The fixture
  custody, progress custody and operational custody openers pass with any error. The control
  opens the amended shape with the migrating opener and the operational custody only. So for
  the fixture and progress custody openers the test does not show that the refusal is caused by
  the shape: an opener that rejected this hand-built fixture for another reason would pass too.
  My own probe on a database built by the real opener of e544e0f shows the behaviour is right:
  three openers answer "unsupported format", the operational custody answers "temporarily
  unavailable", the file is byte-identical (old-shape-probe.txt).
Impact: none on behaviour. A later change that broke one of these openers for every database
  would leave this test green.
Required correction: assert the specific refusal of each opener, and open the control fixture
  with all four.
Uncertainty: none.
Patch defect or pre-existing issue: patch defect (the test is new in this repair).
```

```text
AUDIT FINDING
ID / Type / Severity: A2-7 / test gap, three checks of the store's admission write / low
Current contract or strategic target: design 5.3 and owner document :383-385: "Each is one
  BEGIN IMMEDIATE transaction and is idempotent by content, so an unknown COMMIT outcome returns
  an error, the caller stays closed and calls again." Owner document :412-414: withdrawal
  "reports success only when the durable withdrawal is confirmed; a failed or unknown write
  still leaves this process closed."
Path and line: es/admission/internal/reliablesubmit/operational_admission.go, function
  operationalAdmissionWrite, the one transaction behind commission, advance and withdrawal:
  :170 (the store is verified as current inside the transaction), :177-180 (the written time
  never goes below the stored time), :193-196 (a failed COMMIT answers "commit unknown").
Evidence (run by me): three mutants, each removing one check, survive the whole store package
  and the admission behavioural subset, and the whole es/admission package.
  1. S-WR2 answers a failed COMMIT with success. The handoff writers have a fault seam for the
     COMMIT answer (operational_handoff.go:953-959), and so has the claim store
     (sqlite_store.go:33, :39). The admission write calls commit directly (:193), so no test
     can make its COMMIT fail. What the tests cover is the call after an unknown outcome
     (operational_admission_test.go:326, the same call again) and a withdrawal under an ended
     context, which is refused before BEGIN.
  2. S-WR3 removes the time clamp. No test puts the wall clock behind the stored time. The
     trigger that refuses a time going backwards is pinned (my X-TIME is killed), so without
     the clamp the write would be refused, not wrong: an advance or a withdrawal would stop
     working until the clock caught up.
  3. S-WR4 removes the store verification. No test changes the database under an open custody
     handle and then calls one of the three operations.
  A fourth mutant, S-WR1r (the re-read of the written row is not compared), also survives. I do
  not count it: each of the three operations returns exactly the row it wrote (:223, :264,
  :297-298), so that comparison cannot fail today.
Impact: none on behaviour. The code is correct as read, and nothing in production calls the
  three operations. The gap is forward: a later edit of this function can report a commission,
  an advance or, worst, a withdrawal as done when the row was not written, with every test
  green. For commission and advance the cuts would still fence the process, because every cut
  compares the token with the row. A withdrawal has no such second line: its caller is told
  the domain is stopped.
Required correction: give the admission write the same COMMIT fault seam the other writers
  have, and add store tests: (1) for each of the three operations, a COMMIT whose answer is
  lost returns the commit-unknown error, once with the row really written and once without,
  and the same call again converges; (2) a row whose stored time is ahead of the clock (seeded
  by raw SQL) is advanced and withdrawn, and the stored time does not go back; (3) a database
  that no longer verifies as current refuses all three operations with no write. Optional: one
  direct test of the write function with a step that returns another row than it wrote.
Uncertainty: none on the evidence. Each mutant ran once.
Patch defect or pre-existing issue: patch defect (the function is new in this repair).
```

```text
AUDIT FINDING
ID / Type / Severity: A2-8 / the answer to a cancelled call is not always Canceled, and one
  check that keeps it Canceled has no test / low
Current contract or strategic target: owner document :594 "Cancellation | OperationalCanceled".
  Lines :592-593 give OperationalUnavailable and OperationalIntegrity their own causes, and
  :596-599 let a refusal by the authority take precedence over a cancellation. None of the
  three cases below is a refusal by the authority.
Path and line:
  1. es/admission/reliable_submit_operational_handoff.go:307-313. The pre-check answers
     Unavailable when the admission hint cannot be read, and the hint refuses an ended context
     (internal/reliablesubmit/operational_admission.go:127).
  2. es/admission/reliable_submit_operational_handoff.go:384-387. When the intent binding
     fails, the call answers Integrity, and the binding fails on an ended context
     (internal/reliablesubmit/operational_handoff.go:1284, replay_custody_structure.go:619).
  3. es/admission/reliable_submit_operational_admission.go:494-496. After the policy evaluation
     has allowed, the re-judgment answers Canceled when the context has ended.
Evidence (run by me in a scratch copy, on the exact tip, through the hooks the tests use):
  1. Probe 3 (cancel-during-confirmation-probe.txt) ends the request context while the
     synthetic EGS answers the confirmation. In all three starting states that confirm, the call
     answers Unavailable. This is the longest window of an invocation in practice: the time
     ES waits for EGS.
  2. Probe 2 (cancel-at-sample-probe.txt) ends the context at the k-th freshness sample, for
     every sample of four starting states. The context ends during the call in 106 samples.
     102 answer Canceled. 4 answer Integrity: the last two samples of the pre-check before the
     intent write, on a retry after the assign write and in a call that has just applied the
     assign write. In production this window is the time between two adjacent statements.
  3. Mutant A-Q8 removes the check of point 3 and survives the admission behavioural
     tests, and the whole es/admission package.
     Probe 1 (cancel-during-evaluation-probe.txt) ends the context during the k-th
     evaluation, on the tip and under the mutant, 40 samples each. The claim row after
     the call is the same in all 40. The answer differs in 3: twice the mutant answers
     Integrity where the tip answers Canceled, once only the reported operation differs.
  In the seven samples that answer Unavailable or Integrity the claim row does not change
  after the cancellation, nothing is staged or sent, and no run or receipt is returned.
Impact: none on the durable state or on any effect. A caller that gives up while ES waits
  for EGS is told "unavailable", and in one narrow window "integrity", which the contract
  reserves for contradictory evidence and a wrong realm. Both are value-free.
Required correction: decide the rule and make code, table and tests agree. Either answer
  Canceled whenever the context has ended at these two points (the helper
  operationalFailureAt at :61-66 does this for the writer results), or state both windows in
  the outcome table. Add a test that ends the context from the EGS hook, from the evaluation
  hook and from the clock seam at each first-effect cut and asserts the reason, no further
  write, no run and no receipt.
Uncertainty: each probe ran once. The probes cover the confirmation, every evaluation up to
  the tenth and every freshness sample of four starting states, not every statement boundary.
  Further windows of the same kind may exist.
Patch defect or pre-existing issue: mixed. Point 1 and the outcome table are new in this
  repair. The lines of point 2 are the same at the base (8058561, :325-327). The check of
  point 3 came with the first version of PR #13 (:322 at e544e0f).
```

### 6.3 Pre-existing issues

None of these was introduced by the repair, and none decides the verdict.

```text
AUDIT FINDING
ID / Type / Severity: P-1 / unpinned check in the store fence / low
Current contract or strategic target: owner document, "Writers, locks and outcomes": each writer
  "authenticates the exact current row, original, keys, revision and retained material, compares
  the admission token with the row, then checks complete current admission on that same
  original."
Path and line: es/admission/internal/reliablesubmit/operational_handoff.go:1306. qualifiesOriginal
  requires a.matchesOriginal(match): the match the callback returns must be for the original this
  access holds (claim, plan binding, witness, digest).
Evidence (run by me): my mutant S-Q3 removes that clause. It survives the whole store package
  and the admission behavioural subset at the
  tip, and the whole es/admission package. The same edit at the blocked tip e544e0f
  survives the whole store package (675 results, only the three environment failures) and
  the whole es/admission package (1,385 results, 0 failures):
  match-clause-mutant-at-blocked-tip.txt. So no test, before or after the repair, hands a
  first-effect cut a callback that answers for another original.
Impact: none today. The only production callback is the Service's own closure, which builds its
  match from the original the borrow has just verified (the borrow checks the same match at
  :754). The clause protects against a future caller that passes a wrong closure; the prior
  audit's O-9 noted that the callback type is not sealed.
Required correction: none for this pull request by classification. It is one small store test
  (at each cut, a callback that returns a valid match for a different original must be refused
  with no write), in a function this repair rewrote. I recommend adding it in the same tranche.
Uncertainty: none on the evidence.
Patch defect or pre-existing issue: pre-existing. The clause and the missing test are both older
  than the repair.
```

| ID | Pre-existing item | Evidence |
| --- | --- | --- |
| P-2 | `go vet` reports a copied lock at `es/admission/result_auth_test.go:395:15`. | Same line at `e544e0f`; file not in the changed set. |
| P-3 | The store package's tests do not compile on Linux without a one-file overlay (`Stat_t.Mode` width). PR #14 carries the fix. | `store-test-linux-overlay.patch`; the prior audit's O-8. |
| P-4 | Twelve tests fail in this container at both tips (section 8.1). | `full-suite-compare.tsv` |
| P-5 | `gofmt -l` over the whole tree lists six files, the same six at the base and at the tip (`ags/sign/signer.go`, `ars/index/index.go`, `egs/sign/signer.go`, `es/runtimehelper/main.go`, `es/runtimehelper/privilege_linux.go`, `internal/observability/observability.go`). None is in the changed set. | Run by me at both commits. |

### 6.4 Observations

None of these blocks. They are recorded so the next reader does not rediscover them.

| ID | Kind | Observation |
| --- | --- | --- |
| O-1 | patch, design order | Withdrawal sets the local latch first and then makes the durable write (`es/admission/reliable_submit_operational_admission.go:257-270`). Design 5.3 says the write comes first, "then set the local latch". The code's order is the safer one: a failed write leaves the process stopped and the call reports "not confirmed". The owner document describes the code. The writer's deviation list (11.4) does not mention it. |
| O-2 | patch, by design | A refusal between staging and the stamp leaves the charged stage in place, and the claim cannot stage again ("no stage reattachment", owner document :613-615, :621-622). The document says this for a *denial*. Inference: the same holds when the cause is a passed confirmation deadline or a fence, because the stage and the no-reattachment rule do not depend on the cause. No confirmation happens between staging and the stamp (three points only, :463-468), and the confirmation time is the instant *before* the EGS request (:460-461), so a slow EGS answer plus slow staging can use up the 30 seconds. The result is fail closed: the caller needs a new submit key. `TestOperationalAdmissionDenialAfterStagingKeepsResidue` pins revision, stage and zero POSTs, not the later retry. One sentence in the owner document would make the scope exact. |
| O-3 | patch, by design | An advance accepts any content that differs from the current content, including the content of an earlier generation (`internal/reliablesubmit/operational_admission.go:252`). The row keeps no history. So A, then B, then A again is three valid generations. Who may advance, and whether going back is allowed, is the open prerequisite `CP-POLICY-CUSTODY`; the generation counter still fences every process that holds an older token. Nothing can call advance in production today. |
| O-4 | patch | The table's `CHECK` accepts an all-zero admission digest; the Go layer refuses it before the write (`sqlite_operational_handoff_schema.go:282`, `operational_admission.go:26, 84-86`). Fail closed. The writer lists it (11.4 item 13). |
| O-5 | patch, test comment | Stale comment in the red team's file (`reliable_submit_operational_admission_redteam_test.go:289-291`). See 7.7. |
| O-6 | pre-existing loader, new exposure | The typed inventories load the packages for three targets with default build tags. A production file behind a custom build tag is therefore not loaded, and a spelled write of a latch in such a file passes the guard tests and the whole package (my probe P2, `guard-probe-real-2.txt`). The same file without the tag is refused. No build script, workflow or document in the repository passes `-tags` (searched by me), so such a file is not compiled into any shipped binary today. The import inventory does read every file whatever its constraints. A cheap closure: a test that fails when a non-test file of the two packages carries a build constraint outside the known operating-system and architecture set. |
| O-7 | patch | The whole-value inventory covers the two packages it loads. `*a.service = admission.Service{}` written in `es/app` is not listed anywhere and passes the guard tests and `es/app` (probe P3). The result is a Service without a view, which admits nothing: fail closed. Naming the package scope in the owner document would be exact. |
| O-8 | patch | The table-writer inventory (`TestOperationalAdmissionTableWriters`) reads SQL statement literals. A statement assembled at run time is not seen. The test's own comment and 11.4 item 14 say so; the owner document's list of limits does not. The triggers, not this inventory, are the barrier. |
| O-9 | patch | Field inventories exist for `operationalAdmission`, `operationalWithdrawn`, `operationalSuperseded`, `operationalConfirmed` and `trustModel`. The Service fields `egsClient`, `trustModelVerifier`, `provenanceVerifier` and `admissionPolicyEvaluator` have none, although the confirmation and the content digest read them. A later write to one of them changes what "confirmed" means without changing an inventory. Today each is written only during construction and `Initialize` (read by me). |
| O-10 | patch, docs | `PLANS.md:24-27` can be read as if every cut had a post-COMMIT re-read. Establish and pre-stage have none, by design (establish releases nothing; pre-stage is followed by the stamp turn). The owner document is exact. |
| O-11 | patch, docs | `.docs/execution_lifecycle/implementation.md:1088` says "older than 30 seconds". The code refuses at exactly 30 seconds (`>=`), and the owner document says "less than 30 seconds" (:472). |
| O-12 | hygiene | Six commit messages in the range carry a co-author trailer that names a model and a session link (five name one model, one names another). No changed file names a model or an authoring tool; the only matches in the added lines are the product's own `codexCredential` fields. If the eventual merge should carry no model name, as was decided for the Maintenance Agent pull request, it needs a squash with a clean message. Not a correctness matter. |
| O-13 | patch, by design | Establish is the one first-effect write whose confirmation deadline and local latches are sampled just before its turn, not inside it (`reliable_submit_operational_handoff.go:224-230`). Between that sample and the COMMIT lie a pooled read, the reservation, the publication of the sealed original and the wait for the writer (`internal/reliablesubmit/operational_handoff.go`, `EstablishOperational`). The turn itself compares the token with the row, so a withdrawal or an advance is always seen; a deadline that passes or a supersession that is latched inside that window is not, and one claim row at revision 1 can still be written. No run is assigned, nothing is staged or sent, and the next cut judges again. This is the design's table 5.4 and the owner document's table (:426-427) says "hints, not the authority". The short forms "within 30 seconds before any first-effect cut" (`PLANS.md:32`) and design guarantee 3 are exact for the five later cuts and approximate for establish. |

### 6.5 Subagent findings: adopted, verified, downgraded or rejected

Subagent reports are model output. Nothing below was adopted without my own reading or run.

| Subagent finding | Its rating | My disposition |
| --- | --- | --- |
| Guard GA-1: pointer conversion away from the owner | medium | **Adopted as A2-1** after my own synthetic and end-to-end runs. |
| Guard GA-2: interface dispatch of gated methods | low | **Adopted as A2-2** after my own runs. |
| Guard GA-3: a file behind a custom build tag is not loaded | medium, or low | **Downgraded to observation O-6.** Verified by my run. The loader and its three targets predate this repair, no build script in the repository passes `-tags`, and the import inventory does read every file. |
| Guard GA-4: whole-value writes from another package | low | **Downgraded to observation O-7.** Verified by my run. A zero or copied Service has no usable view (the view is bound to its owner), so the result is fail closed. |
| Guard GA-5: table-writer inventory can be defeated in text | low | **Downgraded to observation O-8.** Read, not run. The triggers are the barrier, and the test's comment says so. |
| Guard GA-6: owner document over-claims | low | **Folded into A2-1 and A2-2** (required corrections). |
| Guard GA-7: missing controls for some gates and shapes | low | **Partly adopted** in the required corrections of A2-1 and A2-2. Not verified one by one. |
| Guard GA-8: `egsClient`, `trustModelVerifier`, `provenanceVerifier`, `admissionPolicyEvaluator` are in no field inventory | observation | **Kept as observation O-9.** Verified by search of the inventories. |
| Guard GA-9, GA-10 | observation | **Not adopted.** Not verified by me; preserved here as the subagent's minority observations (key granularity of the inventories; the import inventory covers two directories only). |
| Documents F-1, F-2, F-3: lock statements | low | **Adopted as A2-3** after my own reading of each line. |
| Documents F-4: Denied row not limited to retained claims | low | **Adopted as A2-4** after my own reading; I added the test gap. |
| Documents F-5: `PLANS.md:24-27` reads as if establish and pre-stage had a post-COMMIT re-read | low | **Downgraded to observation O-10.** The sentence mirrors the design's table and can be read either way; the owner document is exact. |
| Documents F-6: docs tests pin anchors, not contradictions | low | **Not adopted as a finding.** True, and it is why A2-3 and A2-4 were not caught; noted in A2-3. |
| Documents F-7 to F-15 | observation | **F-10** is O-4, **F-13** is O-8. **F-12** (`implementation.md:1088` says "older than 30 seconds", the code refuses at exactly 30) is O-11. The rest are preserved as the subagent's observations; I did not verify them. |
| Documents F-16: the three owner decisions D-1 to D-3 rest on one relayed approval | observation | **Rejected.** The coordinator's audit brief states that David approved the design with exactly these three points. |
| Tests TA-1: the over-cap vector now derives from the constant | low | **Adopted as A2-5** (low) after my mutants S-CAP1 and S-CAP2 survived. |
| Tests TA-3: published-shape test accepts any error for three openers | low | **Adopted as A2-6** (low); my probe shows the behaviour is right. |
| Tests TA-2, TA-5 to TA-14 | observation | Each names a test that is weaker than its title. I used them to choose mutants (TA-5: A-MAP4; TA-6: A-ES2; TA-7: S-E1, S-E1b; TA-10: A-RD1). Where the mutant is killed, the property is pinned somewhere and I raise nothing. TA-9 and TA-13 (assertions that cannot fail, one of them pre-existing) are preserved as observations, not verified by me. |
| Tests TA-4: hash of the published migration text | to verify | **Verified** by me: `c100749d…d294`. |

## 7. What the brief asked me to check

### 7.1 Every prior finding, with its regression test

"Pinned" means: I named a mutant that removes the check, and a behavioural test failed under it. Mutant ids refer to the table in `06-audit-evidence/mutants-results.tsv`. "Read" means I read the fix and its test and ran no mutant.

**Prior audit (02-audit.md)**

| Finding | Fix at the tip | Regression test | My check | Status |
| --- | --- | --- | --- | --- |
| AF-1 (medium): run-assignment cut, establish gate and two in-writer checks unpinned | Every cut now compares the token in its writer turn and re-judges the claim | `TestOperationalAdmissionRunAssignmentCutAndEstablishGate`, `TestOperationalAdmissionDenialInsideEachWriter`, `TestOperationalAdmissionTokenAtEveryCut` | Mutants S-A1, S-A2, S-A3, S-A4, S-A5, S-P1, S-E1, S-E1b, S-E2, S-E12, A-ES1, A-ES2, A-ES12: all killed by behaviour | **Fixed, pinned** |
| AF-5 (medium): new v1 compatibility edge without reason or removal condition | v1 is deleted. No production source names the literal (searched by me). | `TestOperationalV1Removed`, store `TestOperationalHandoffV2CustodyStructure` | Mutant S-CS1 (custody accepts the v1 literal): killed by behaviour. A-RD1 (reader accepts any literal) survives as a duplicate layer, see 7.3 | **Fixed, pinned** |
| AF-2 (low): commissioning properties unpinned | Content copy and digest (`reliable_submit_operational_admission.go:142-198`) | `TestOperationalAdmissionCommissioning` | Mutants A-PE1, A-CO1, A-CO2, A-CO3, A-CO4, A-CP1, A-CP2, A-CU3, A-CU4, A-CU6: all killed by behaviour | **Fixed, pinned** |
| AF-3 (low): classifier claims unpinned; three write forms read as reads | Conversion, channel send and `append` are write-through; an unknown step is unclassified | Guard self-tests | Guard mutants G-S7a, G-S7b, G-CV: killed | **Fixed, pinned.** The wider guard question is A2-1. |
| AF-4 (low): owner document promoted schema 5 to "Current invariant" | Status table restored (owner document :5-10) | Docs test phrase pins | Read | **Fixed** |
| AF-6 (low): cancellation against refusal | Order kept and stated (:597-599) | `TestOperationalAdmissionRefusalPrecedesCancellation` | Read: both subtests assert the refusal reason under a cancelled context, and a third is the control. I ran no mutant that swaps the order | **Fixed** as asked. A cancellation alone still does not answer Canceled at two points the old finding did not cover: A2-8 |
| AF-7 (low): result reports only the last writer | Sentence corrected (:600-604) | `TestOperationalAdmissionResultReportsLastAttemptedWriter` | Read | **Fixed** |
| AF-8 (low): "policy change needs a new epoch" contradiction; stranding | Trust, verifier and policy no longer bind the epoch; a later generation re-judges | `TestOperationalAdmissionGenerationsOnOneDomain`, `TestPR12RetryAfterPolicyChange` | Mutants A-Q1, A-Q2, A-Q3, A-Q7, A-Q9: all killed by behaviour | **Fixed, pinned** |
| AF-9 (low): stamped retry returns the run under a denying authority | Rule stated (:604-609): an entry that attempts no cut returns stored facts to the original caller | `TestOperationalAdmissionEntriesWithoutACutReturnStoredFacts` | Read | **Fixed** (by stating the rule; same as RT-3) |
| AF-10 (low): unreachable 403 branch; marshal on the ordinary path | Branch removed; an unmarshallable record leaves the carrier empty (`service.go:470-487`) | Empty-carrier refusal in `TestOperationalV1Removed` | Read; mutants A-EN1, A-EN2: all killed by behaviour | **Fixed, pinned** |
| AF-11 (low): assertions that cannot fail | Replaced by a comparison with an independently resolved plan and material | `TestOperationalAdmissionCaptureIsSameResolution` (:1341-1399) | Read | **Fixed** |
| AF-12 (low): v1 fallback of the encoder | v1 deleted; the encoder refuses an empty record | `TestOperationalV1Removed/an_empty_evidence_record_cannot_be_composed` | Mutants A-EN2, S-CS2: all killed by behaviour | **Fixed, pinned** |
| O-4: `boundaries.md` section before the reading guide | Moved to section 8.1 with labels (:801-829) | none needed | Read | **Fixed** |
| O-5: "denial does not poison the claim" unscoped | Scoped (:617-622) | `TestOperationalAdmissionDenialAfterStagingKeepsResidue` | Read. See observation O-2 for the remaining scope | **Fixed** |
| O-6: evidence cap written twice | One exported constant (`replay_custody_structure.go:457`) | Cap vectors in both layers | Mutants S-CAP1, S-CAP2, S-CS3: killed by behaviour, except S-CAP1 (survives, see 7.3), S-CAP2 (survives, see 7.3) | **Fixed.** Both layers use the one constant (S-CS3 killed). Its value is no longer pinned: finding A2-5. |

**Red team (03-red-team.md)**

| Finding | Fix at the tip | Regression test | My check | Status |
| --- | --- | --- | --- | --- |
| RT-1 (medium): the guard accepts changes that do not spell the field | Conversion step, whole-value inventory, construction count, import inventory | `TestRedTeamPR13GuardAccessInventoryEscapes` (unchanged, now passes) and about 100 self-test cases | Guard mutants killed; my probes | **Every listed shape is fixed and pinned. The finding's subject still reproduces through one shape the red team did not list: A2-1 (blocking).** |
| RT-10 (medium): three production checks without a behavioural test | Tests adopted from PR #15 and extended | `TestRedTeamPR13HoldsNoNewClaimAfterWithdrawal`, `TestRedTeamPR13HoldsDenialMatrixAcrossCrashPoints`, `TestOperationalAdmissionViewIsBoundToTheDomainRealm` | Mutants A-ES1, A-ES2, A-ES12 (establish samples), A-CU3, A-CU4 (installation, epoch), S-A3 (assign writer): all killed by behaviour | **Fixed, pinned** |
| RT-2 (low): verifier rotation reported as Integrity | Rotated verifier reports Denied; a realm mismatch stays Integrity, and the contract says so (:591, :593) | `TestOperationalAdmissionOutcomeMapping` | Mutants A-MAP1 to A-MAP6: all killed by behaviour | **Fixed, pinned** |
| RT-3 (low): recovery returns the run under a denying authority | Rule stated (same as AF-9) | as AF-9 | Read | **Fixed** by contract |
| RT-4 (low): withdrawal is a sampled flag | Withdrawal is a durable row state checked in every writer turn and by the claim triggers; the one remaining sender window is stated (:443-446) | `TestOperationalAdmissionChangeAtEachProofHook`, `TestOperationalAdmissionClaimGuardsByRawSQL`, `TestOperationalAdmissionFencesAnotherProcess` | Mutants S-EN1, X-INSANY, X-UPDANY, A-WD1 to A-WD4, A-CU1, S-W1 to S-W3: killed by behaviour, except S-W2 (survives, see 7.3) | **Fixed, pinned.** The stated residual is by design. |
| RT-5 (observation): denial after staging strands the claim | Stated (:621-622) | `TestOperationalAdmissionDenialAfterStagingKeepsResidue` | Read | **Stated** |
| RT-6 (observation): a policy change was a new epoch | Replaced by generations on one domain | as AF-8 | as AF-8 | **Resolved by design** |
| RT-7 (observation): qualifier work in the writer is bounded | Unchanged. The new confirmation never runs in a writer turn | `TestOperationalAdmissionFreshness` (the synthetic EGS takes the writer lock while it answers) | Read | **Holds** |
| RT-8 (observation): padded seal values | Unchanged, outside this repair | none | Not re-examined | **Unchanged** |
| RT-9 (scope caveat): what "current" means | Now includes a confirmation with EGS within 30 seconds. ARS and zone or profile configuration are still not re-read at a cut, and the contract says so | `TestOperationalAdmissionFreshness`, `TestOperationalAdmissionDeadlineAtEverySample` | Mutants A-CF1, A-CF2r, A-CT1 to A-CT3, A-CT5, A-SS1, A-SS2r, A-FR1 to A-FR8, A-CU5r: killed by behaviour, except A-FR4 (survives, see 7.3), A-FR6 (survives, see 7.3) | **Narrowed as designed** |

### 7.2 Conformance to the approved design

Design `04-design-proper-admission.md`, sections 5 to 8 and the three owner decisions of section 12.

| Design item | At the tip | Conforms | My evidence |
| --- | --- | --- | --- |
| D-1, 5.2: one admission row in schema 5 by amending migration 5; no delete; insert only as generation 1, enabled; update only as withdraw or as advance to generation plus one with another digest; installation and epoch never change | `sqlite_operational_handoff_schema.go:277-328` | Yes | 16 schema mutants with the digest pin moved out of the way (X-DEL, X-INS2, X-IDI, X-IDE, X-TIME, X-REEN, X-SAMEDIG, X-SKIP, X-ADVW, X-ZERO and the six claim-clause mutants): all killed by behaviour |
| 5.2: two claim-trigger clauses; kind 8 (accept) not affected | `:461-463` and the insert guard | Yes | X-INS, X-UPD, X-INSANY, X-UPDANY, X-UPD8, X-UPDK: all killed by behaviour |
| 5.3: commission, advance, withdraw, each one `BEGIN IMMEDIATE` transaction, idempotent by content, unknown COMMIT fails closed | `internal/reliablesubmit/operational_admission.go:138-301` | Yes, by reading, and pinned for the rules of each operation. Three checks of the shared write function, the unknown-COMMIT answer among them, have no test: finding A2-7 (low) | S-C1 to S-C4, S-AD1, S-AD2, S-AD2p, S-AD3, S-AD4, S-W1, S-W1a, S-W1b, S-W3, S-LK1: all killed by behaviour. S-WR2, S-WR3 and S-WR4 survive (A2-7). S-AD2w, S-W2 and S-WR1r survive as duplicates (7.3) |
| 5.3: one view per Service; `Initialize` cannot replace trust after commissioning; a withdrawn domain is re-enabled only by new content | `reliable_submit_operational_admission.go:200-231`; `service.go` | Yes | A-IN1r, A-IN2, A-IN3r, A-IN3br, A-IN3c, A-IN12r, A-INIT1, A-INIT2, A-INIT12, S-C2, X-REEN: all killed by behaviour |
| 5.3: withdraw writes the row, "then set the local latch" | The latch is set first (`:257-270`) | **Differs, safer.** Observation O-1 | Read; A-WD1 to A-WD3: all killed by behaviour |
| 5.4: establish turn compares the token with the row; the pre-establish check is a hint | `operational_handoff.go` establish turn and pooled hint | Yes | S-E1, S-E1b, S-E2, S-E12: all killed by behaviour |
| 5.4: assign, intent, pre-stage, stamp and marker turns compare the token, then judge the retained evidence | `qualifiesOriginal` (:1301-1307) and its three call sites | Yes | S-A1 to S-A5, S-P1, S-Q1, S-Q2, S-FQ, A-F1: all killed by behaviour |
| 5.4: post-COMMIT release re-reads the row | `operationalReleaseQualified` (:1530-1548) | Yes | S-R1, S-R2: all killed by behaviour |
| 5.4: final sender entry checks the local view only | `reliable_submit_operational_handoff.go:654-657` | Yes | A-FS1, A-FS2r, A-FS3: killed by behaviour, except A-FS2r (survives, see 7.3) |
| 5.5: confirmation with EGS before the first sample of a fresh delivery and before the two pre-checks, at most once per invocation, never for recovery or receipt reads | `:166-172`, `:213`, `:307-308` | Yes | A-CF1, A-CF2r, A-PC1, A-PC2: all killed by behaviour |
| 5.5: equal content records the time; different content latches supersession; a failure changes nothing | `reliable_submit_operational_admission.go:278-311` | Yes, and stricter: the recorded time is the instant before the request, not "now" | A-SS1, A-SS2r, A-CT1, A-CT2, A-CT3, A-CT5: all killed by behaviour |
| 5.5: every use requires not withdrawn, not superseded, under 30 seconds on both clocks; compiled constant | `:317-353`; `operationalAdmissionConfirmationLimit = 30 * time.Second` | Yes | A-CU1, A-CU2, A-CU5r, A-FR1, A-FR1b, A-FR2, A-FR3, A-FR5, A-FR7, A-FR8: all killed by behaviour |
| 5.5: "Confirm runs outside every lock and every transaction" | Outside every transaction, `Service.mu` and owner mutex. At the two pre-checks the custody read lock of the borrow is held | **Sentence not met at two of three points.** The design placed the call there itself. Finding A2-3 (low) | Read |
| 5.6: outcomes | `qualifyOperationalRetained` (:444-503) | Yes for retained originals. A fresh delivery that the rules refuse reports Unavailable: finding A2-4 (low). A cancelled call does not always answer Canceled: finding A2-8 (low) | A-MAP1 to A-MAP6, A-RF1: all killed by behaviour |
| 5.6, 6: a denial is not terminal; a later generation that allows the claim completes it with one POST | Generations on one domain | Yes | `TestOperationalAdmissionGenerationsOnOneDomain` passes; A-Q1 to A-Q3: all killed by behaviour |
| 5.7: writer, then a brief `Service.mu` read; the three operations hold no `Service.mu` across the store write | `:206-218`, `:261-269` | Yes | Read; race detector clean |
| 5.8 guarantees 1 to 5 | as rows above | Yes | as rows above; `TestOperationalAdmissionFencesAnotherProcess` (two real processes) passes |
| D-3, 7: delete `operational_local_v1` | No production source names it; custody grammar, reader, encoder and handoff carry no v1 branch | Yes | S-CS1, S-CS2, A-EN2: all killed by behaviour |
| 8: tripwires: zero production references to commission, advance, withdraw; prerequisite list printed; exactly three table writers; no statement updates installation or epoch; clock seam can only add time | `reliable_submit_guardrails_test.go:1313-1319, 1456-1530`; `TestOperationalAdmissionTableWriters`; `:321-326` | Yes for calls by name. A call through an interface is not seen: finding A2-2 (low) | Probes P1; G-GATE killed; A-FR2: killed by behaviour |
| D-2, 12: freshness in this repair with a 30 second limit | as above | Yes | as above |
| 13: ordinary Submit reads trust only at startup | Unchanged and stated (owner document :484) | Yes (out of scope by design) | Read |

Conformance in one line: the production code implements the approved design. The two differences I found are in the safe direction (withdrawal order, confirmation time). The places where the repair falls short are in the guard, in three document statements and in a few tests, not in the store or the admission logic.

### 7.3 The writer's section 11.8: six surviving mutants and the equivalence claims

I did not reuse the writer's mutants. I wrote each of the six again from the code, with its neighbour and the pair, and ran them at the tip. "Both stages" means the behavioural run and then the whole `es/admission` package with every inventory test. For a store mutant the first stage also runs the whole store package.

| Writer's survivor | My mutant | Alone | The neighbour alone | Both together | My reading |
| --- | --- | --- | --- | --- | --- |
| `GO-advance-where` | S-AD2w | Survives both stages | S-AD2 killed (3 tests). X-SKIP, the trigger rule, is killed with the pin moved | S-AD2p killed (3 tests) | Agreed. The same transaction has just compared the generation in Go (`operational_admission.go:252`), and the trigger demands generation plus one. |
| `T1b-callback-returns-stored-token` | A-T1b | Survives behaviour. In the whole package only a source inventory notices the edit (`TestExecutionSubstrateSynchronizedMutableStateReferenceInventoryIsExact`) | A-F1 killed (37 tests) | A-T1ab killed (38 tests) | Agreed. The callback has refused `view.token != stored` before it answers (`reliable_submit_operational_handoff.go:284-288`). |
| `F2b-never-confirmed-accepted` | A-FR6 | Survives both stages | The deadline clauses: A-FR5 killed (74 tests); A-FR7 killed (5 tests) | A-CU5r, which ignores the whole freshness test: killed (26 tests) | Agreed. The elapsed time since a zero time saturates at the largest duration, so the deadline clause refuses (`:327-330`). |
| `F2g-limit-inclusive` | A-FR9 | Survives both stages | The added-time clause: A-FR5 killed (74 tests) | Both clauses inclusive: A-FR7 killed (5 tests) | Agreed. At exactly 30 seconds the added-time clause compares zero with zero and refuses. |
| `C5` | A-C5 | Survives behaviour. In the whole package only a source inventory notices the edit (`TestExecutionSubstrateSynchronizedMutableStateReferenceInventoryIsExact`) | A-C5b is its neighbour and survives alone | A-C5ab killed (1 test, `TestOperationalAdmissionCommissioning/copied,_oversized_and_unsupported_Services_gain_nothing/invalid_trust`) | Agreed. An invalid trust model is refused by the validity check or by the canonical encoding, whichever is left. |
| `C5b` | A-C5b | Survives both stages | A-C5 is its neighbour and survives alone | The same pair, A-C5ab | Agreed. |

**Result for 11.8.** All six survive the behavioural tests in my runs as well, and every pair is killed. The equivalence claims hold, and I agree that none of the six is a missing test. Two remarks. My forms of two of them (A-T1b, A-C5) remove a read of a protected field, so the source inventory notices the edit in the whole package; no behavioural test does. And one of the pair kills rests on a single test (A-C5ab, the `invalid_trust` case).

**My further survivors.** My list is wider than the writer's in places, so more of mine survive the behavioural tests: 20 besides the six. The writer's closing sentence in 11.8, that an independent auditor may still find a check that nothing observes, is confirmed.

Thirteen of them are duplicates of a neighbouring check, or checks that cannot fail today. None is a finding.

| My mutant | What it changes | Result | Why no test can see it |
| --- | --- | --- | --- |
| S-M1 | The admitted match is built from an invalid token | Survives both stages | `qualifiesOriginal` accepts a match only when its token equals a valid stored token (`operational_handoff.go:1301-1307`). The two halves of that comparison are pinned: S-Q1 killed (9 tests), S-Q2 killed (1 test, `TestOperationalAdmissionTokenAtEveryCut/Prestage`). |
| S-W2 | Withdraw accepts an invalid token | Survives both stages | Only the store package can build a nonzero token (unexported fields). The zero token names installation zero, which no row can hold (table `CHECK`; X-ZERO killed), so the realm comparison of the same step refuses it: S-W1 killed (2 tests), S-W1a killed (2 tests), S-W1b killed (1 test, `TestOperationalAdmissionLifecycle/Withdraw`). |
| S-WR1r | The re-read of the written row is not compared | Survives both stages | A self-check that cannot fail today: each of the three operations returns exactly the row it wrote (`operational_admission.go:223, 264, 297-298`). See A2-7, last paragraph of the evidence. |
| S-N2 | `Names` ignores the installation | Survives both stages | `Names` has two callers (`reliable_submit_operational_admission.go:215, 304`). At the first the store has just compared installation and epoch itself (S-C3 killed (1 test, `TestOperationalAdmissionLifecycle/Commission`); S-C4 killed (1 test, `TestOperationalAdmissionLifecycle/Commission`); S-AD3 killed (1 test, `TestOperationalAdmissionLifecycle/Advance`)). At the second a view compares its own token with its own realm. Only the digest can differ there, and that part is pinned: S-N1 killed (6 tests). |
| S-N3 | `Names` ignores the epoch | Survives both stages | As S-N2. |
| A-PC3 | The pre-check passes on when the hint read fails | Survives both stages | The callback then receives the zero token. A view's token is never zero, so the callback refuses with the same reason, Unavailable (`reliable_submit_operational_handoff.go:284-288`). |
| A-CT4 | Confirmation does not check that the view is still the installed one | Survives behaviour. In the whole package only a source inventory notices the edit (`TestExecutionSubstrateSynchronizedMutableStateReferenceInventoryIsExact`) | A Service installs a view at most once and never replaces it (A-IN1r killed (3 tests); A-IN3r killed (4 tests); A-IN12r killed (4 tests)), so the pointer cannot differ. |
| A-FS2r | The final sender entry does not compare the current view with the owner's | Survives both stages | The same one-view rule: the current view of a Service is always the pointer the owner sampled. The sample itself is pinned: A-FS1 killed (8 tests). |
| A-FR4 | The deadline clause `elapsed >= limit` is removed | Survives both stages | When the elapsed time is at or over the limit, `limit - elapsed` is zero or negative, and the added time is never negative (`:321-326`), so the second clause refuses. That clause is pinned: A-FR5 killed (74 tests). |
| A-DG6 | The digest leaves out the verifier's algorithm | Survives both stages | The content copy accepts only `ed25519` (`reliable_submit_operational_admission.go:153`), so the hashed frame is a constant today. |
| A-DG7 | The digest leaves out the configured policy's id and entry count | Survives both stages | The policy set has one fixed shape (`copyOperationalPolicySet`, `:55-82`): the configured policy is always the second and last and has at least one entry. Its id is a constant, and the framed entries that follow fix their own count. No two accepted contents differ only in the omitted bytes. |
| A-RD1 | The reader accepts any provenance literal | Survives both stages | The reader re-encodes what it read and compares the bytes with the stored original (`reliable_submit_operational_format.go:197-198`). The encoder writes only the v2 literal (`:116`). The custody grammar refuses the v1 literal as well: S-CS1 killed (8 tests). |
| A-RD2 | The reader does not match the evidence against the original | Survives both stages | The re-encoding goes through the encoder, which makes the same match: A-EN1 killed (9 tests). The pair: A-RDEN killed (9 tests). |

Seven are checks that a test could observe and none does. Each is covered by a finding.

| My mutant | What it changes | Result | Finding |
| --- | --- | --- | --- |
| S-CAP1 | The shared evidence cap is one byte larger | Survives both stages | A2-5 |
| S-CAP2 | The shared evidence cap is doubled | Survives both stages | A2-5 |
| S-WR2 | A failed COMMIT of the admission write answers success | Survives both stages | A2-7 |
| S-WR3 | The time clamp of the admission write is removed | Survives both stages | A2-7 |
| S-WR4 | The admission write does not verify the store as current | Survives both stages | A2-7 |
| A-Q8 | The re-judgment ignores a cancellation that arrives during the evaluation | Survives both stages | A2-8 |
| S-Q3 | The fence does not require the match to be for this original | Survives both stages | P-1 (pre-existing) |

A check that is only a duplicate today can become the only check after a later edit. For the fence I therefore also ran the pairs across the two layers: S-FQ (the callback's comparison and the store's comparison both removed) is killed by 47 tests, S-E12 (both establish checks) by 9, A-ES12 (both establish samples) by 8, A-Q56 (both final resamples) by 27.

### 7.4 The guard fix: syntactic inventory and named limits

What the fix does, read by me in `es/admission/workstream_c_guardrails_test.go` and checked with seven mutants of the guard itself (table below):

- A conversion is now a transparent step of an access chain (`typedLocationStep`, :4246-4250), so `(*alias)(s.value).n = 1` is a write-through.
- A type-assertion step and an unknown step are classified (:4244-4245, :4166-4168). These were the prior audit's S7a and S7b.
- Whole values of an owning struct are listed by `wholeValueReferences` (:3816-3996): literals, assignment and range targets, conversions *to* the owner or to a pointer or container of it, declarations, `new`, `make`, `copy`, `clear`, `append`, and any other by-value use.
- The construction inventory counts the same forms, so a zero-value declaration and a same-shape conversion are refused like a second literal.
- An import inventory for `reflect`, `unsafe` and `C` reads every non-test file of the two packages, whatever its build constraints (:3078 onward).

What I ran against it:

| Probe | Where | Result |
| --- | --- | --- |
| Red team's eleven escape cases | `TestRedTeamPR13GuardAccessInventoryEscapes`, unchanged byte for byte from PR #15 | Passes at the tip (it failed at `e544e0f` by design). |
| Spelled write, red team's value conversion, conversion to the owner pointer, second literal, pointer conversion into the owner | synthetic packages, tip validators | All refused. |
| Pointer conversion **away** from the owner: named twin, anonymous twin, alias kept in a variable, whole overwrite | synthetic packages | All accepted with zero references. **Finding A2-1.** |
| GM1 and GM2 (end to end, real package) | scratch copy | Build, vet, guard tests and the whole package pass. **Finding A2-1.** |
| Interface call of the three commissioning entries | synthetic and real package | Accepted. **Finding A2-2.** |
| A spelled latch write in a file behind a custom build tag | real package | Guard tests and whole package pass; without the tag the same file is refused. Observation O-6. |
| `*a.service = admission.Service{}` from `es/app` | real package | Guard tests and `es/app` pass. Fail closed by construction. Observation O-7. |

Seven mutants of the guard's own code, each run against the guard tests in a scratch copy (`06-audit-evidence/guard-mutants.txt`). A kill here means the guard's self-tests notice when the guard is weakened.

| Mutant | What it weakens | Result | Failing leaf tests |
| --- | --- | --- | --- |
| G-S7a | A type-assertion step ends the access chain (prior audit S7a) | killed | 2 |
| G-S7b | An unknown step is classified as a read (prior audit S7b) | killed | 1 |
| G-CV | A conversion is no longer a transparent step (RT-1 shape 3) | killed | 8 |
| G-WC | A conversion to the owner is not recorded (RT-1 shapes 4 and 5) | killed | 6 |
| G-WA | An assignment target is not recorded (RT-1 shape 1) | killed | 13 |
| G-WR | A plain copy of the owner is not recorded | killed | 1 |
| G-GATE | The commissioning gate accepts any production reference | killed | 12 |

These are kills by the guard under test, not by behaviour. They show that each part of the fix is pinned. They cannot show that the list of shapes is complete, and A2-1 is the proof that it is not.

Named limits. The owner document names five (:553-560): aliases or pointers obtained at an inventoried site, bodies of called functions and methods, reflection, `unsafe`, cgo. Each of these leaves a trace at the place where the alias or the import is introduced, which is what makes them acceptable as limits. The shape of A2-1 leaves none, and the interface call of A2-2, the build-tag limit, the cross-package scope of the whole-value inventory and the literal-only scope of the table-writer inventory are not named in the owner document. The last one is named in the test's own comment (`operational_admission_test.go:1133-1136`) and in `05-repair.md` 11.4 item 14.

Conclusion for this item: the fix is real and each part of it is pinned by the guard's own tests. It is not complete, and the contract text claims more than the tests deliver.

### 7.5 Admission digest contents

Read at `es/admission/reliable_submit_operational_admission.go:111-138`. The digest is SHA-256 over, in this order: the label `ESOHADM1`; the canonical bytes of the normalized trust model (allowed signers, revoked signers, revoked artifacts); the verifier's algorithm, key id and public key; the number of selected policies; and for each policy its id, its entry count and each entry's id and literal. Every variable-length part is length-framed. An unknown policy type or an empty policy set gives no digest, so such a Service cannot commission (:113-114, :133-134).

It is taken over the values the view holds (:186-195), so what is hashed is what is enforced. The view's lists are fresh copies (`Normalized()` and an explicit key copy), not shared with the Service's own trust model.

What it does not cover, and where that is handled:

- The compiled behaviour of a built-in policy and compiled limits. Two releases with the same configuration present the same digest. The code comment says so (:106-110) and the commissioning gate names it as prerequisite `CP-RELEASE`.
- Order. The digest depends on the configured order of policies and entries. Two processes with the same configuration produce the same order. Inference: a reordered but equivalent configuration would count as new content and require an advance. That is safe.

My mutants: one per digest input (A-DG1 to A-DG7: killed by behaviour, except A-DG6 (survives, see 7.3), A-DG7 (survives, see 7.3)).

The two that survive remove bytes that are constant today. The verifier's algorithm: the content copy accepts only `ed25519` (:153). The configured policy's id and entry count: the policy set has one fixed shape (:55-82), so the id is a constant and the framed entries fix their own count. No two contents that a Service can commission differ only there. If a second algorithm or another policy is ever accepted, these frames start to matter, and no test would notice their absence. A direct test of the digest function with two inputs that differ only in such a frame would pin them now; I list it as optional in section 9 and raise no finding.

### 7.6 Deviations listed in 11.4

`05-repair.md` 11.4 lists 18 items. My reading of each:

| Item | Subject | My check | Result |
| --- | --- | --- | --- |
| 1 | Store operations have one production reference each, not zero | Read the store-member inventory (`reliable_submit_guardrails_test.go:1327-1338`) | Accurate. The three Service methods have zero. Consistent with design section 8. |
| 2 | The gate prints its prerequisites | Probe P1-control | Accurate. |
| 3 | More call-site inventories than planned | Read :1480-1530 | Accurate, stricter than planned. |
| 4 | Guard fix beyond the plan's list | Read, probes, guard mutants | Accurate for what is listed. The closing sentence on named limits is incomplete: **A2-1**, A2-2. |
| 5 | Closure accesses are a kind of their own | Read the self-test (:3029-3045) and the real inventories | Accurate. The only protected-field accesses listed inside a function literal are the two token reads of the callback (`workstream_c_guardrails_test.go:2677`). Not a weakening: an unlisted one still fails. |
| 6 | Object inventories carry whole-value entries | Spot-checked the store entries (:2558-2583) | Accurate as far as checked. I did not check every new entry against its source line. |
| 7 | Import inventory covers cgo | Read :3078-3125 | Accurate. |
| 8 | The callback receives the stored token and compares it first | Read `reliable_submit_operational_handoff.go:283-288`; mutants A-F1, S-Q1, A-T1b, A-T1ab, S-FQ | Accurate. See 7.3. |
| 9 | Pre-check reads the row once outside a turn | Read :307-316 and `AdmissionHint`; mutants A-PC1 to A-PC3, S-N1 to S-N3 | Accurate. It grants nothing. |
| 10 | Empty-record guard moved to the encoder | Read; mutants A-EN1, A-EN2 | Accurate. |
| 11 | Layered checks kept | My own re-derived mutants | Accurate. See 7.3. I found more duplicate layers of the same kind; they are listed there. |
| 12 | A withdrawn domain is re-enabled only by new content | Read the store operations; mutants S-C2, S-AD1, X-REEN | Accurate, and it is the design. |
| 13 | The table accepts an all-zero digest; Go refuses it | Read `sqlite_operational_handoff_schema.go:282` and `operational_admission.go:26, 84-86` | Accurate. Fail closed. Observation O-4. |
| 14 | The table-writer inventory reads statement literals | Read `operational_admission_test.go:1128-1250` | Accurate. The limit is in the code comment but not in the owner document. Observation O-8. |
| 15 | Tests that reach inside | Read the cases named | Accurate. `unsafe` appears in a test file only; the import inventory covers non-test files. |
| 16 | Store file count 36 to 38 in the docs test | Not checked line by line; the test passes | No concern. |
| 17 | Tests added after the first push | `git diff --stat` per commit | Accurate. The four later commits change test files only. |
| 18 | The exact sample count of 48 | Read; mutants that drop one sample | Accurate. See the mutant table. |

Not listed by the writer, found by me:

- **Withdrawal order.** Design 5.3 says the durable write comes first, "then set the local latch". The code sets the latch first and then writes (`reliable_submit_operational_admission.go:257-270`). This is the safer order, and the owner document describes it. Observation O-1.
- **Custody read lock at two confirmation points and in the three operations.** Finding A2-3.

### 7.7 The red team's file (11.6), every changed line

- The file at PR #15's `5ca4079` hashes to `10e705ab…ca52`, as the writer states.
- My own diff of that file against the tip has 16 hunks, 150 lines added and 23 removed. Its changed lines are identical to the writer's attachment `05-repair-redteam-test-changes.diff` (compared mechanically). Kept as `06-audit-evidence/redteam-file-5ca4079-to-b6d2f77.diff`.
- No hunk touches `TestRedTeamPR13GuardAccessInventoryEscapes`, `TestRedTeamPR13HoldsSealedOriginalTamperRefused` or the two fuzz targets. All 11 test and fuzz names are kept.
- I read all 16 hunks against the writer's table. Each row describes its hunk correctly. I found no weakened assertion.
- The two inverted preconditions ("another epoch", "another installation", and "matching authority" in the cross-realm test) are correct under the new model: the store now refuses to commission a Service for a realm its row does not name, and the tests assert that refusal. The red team's original attacker, a current view that names another realm, is kept by three added arms that rewrite a confirmed view in memory or commission on another database. That is stronger than before.
- The concurrency test now runs 28 iterations. In the first 14 the denying Service is refused by the fence, not by its own judgment; the last 14 reverse the order. The writer says so. Both halves keep the original assertions.
- One stale comment, observation O-5: in `TestRedTeamPR13HoldsNoNewClaimAfterWithdrawal` the arm "between the two authority samples" withdraws through the Service, which is now a durable withdrawal. The store's own check would refuse that establish too, so this arm no longer "pins the later one on its own" as the comment says (:289-291). The second sample is pinned on its own elsewhere, by `establish gate/deadline passes between the two samples`, where the row stays enabled (my mutant A-ES2 removes that sample's checks and is killed by exactly this subtest and one more).

### 7.8 The assumption that no old-shape schema-5 database exists

The repair amends migration 5 instead of adding a migration 6, and assumes no database with the published schema-5 shape exists. I checked what happens if one does.

- The migration-5 text at `8058561` and at `e544e0f` hashes to `c100749d…d294`, which equals the value pinned in `TestOperationalAdmissionPublishedSchema5ShapeRefused`. The amended text hashes differently, and the schema digest moves from `e1239b29…09ed` to `7d545c73…ae27`.
- I built a database with the real opener of `e544e0f` and opened it with all four openers of the repaired tip. All four refuse it: three with "unsupported format", the operational custody with "temporarily unavailable". The database file is byte-identical afterwards and no journal or WAL file appears. The reverse direction (old code, new shape) is refused the same way. Control: the tip opens its own shape. Output: `06-audit-evidence/old-shape-probe.txt`.
- No production code calls any store opener at `8058561`, `e544e0f` or `b6d2f77` (typed inventory, zero references to `OpenProvisionedOperationalCustody`; read by me). `trunk_dev` carries schemas 1 to 4 only.

- The other old binary. The maintained test that a schema-4 binary refuses schema 5 needs a probe binary this container does not have (section 8). So I built my own check: the three openers of the schema-4 tree (`trunk_dev`, `ae326b0`) each refuse a database created by the repaired tip with "unsupported format", and the file is byte-identical afterwards with no journal or WAL. Controls: the schema-4 tree opens its own shape, and the repaired tip migrates that schema-4 database forward to version 5. Output: `06-audit-evidence/schema4-opener-probe.txt`. This is my probe on an empty database, not the maintained test with its populated fixture.

So an old-shape database, if one exists, is refused unchanged. Nothing is silently reinterpreted. **Unknown:** whether such a file exists on David's Mac or on the Linux box; I did not look there (non-goal). Inference: only a test run or a manual experiment could have made one, and tests use temporary directories.

One loose test, low (A2-6): the maintained test asserts a specific error for the migrating opener only. For the other three openers it accepts any error, and its positive control opens the amended shape with two of the four openers. My probe shows the behaviour itself is right.

### 7.9 Commissioning: no production caller, and its guard

- **No production caller.** `commissionOperationalAdmission`, `advanceOperationalAdmission`, `withdrawOperationalEffects`, the two private handoff entries, `newOperationalDomain`, `newOperationalLoopbackProvider`, `OpenProvisionedOperationalCustody` and the release proof hook have zero non-test references; each of the three store operations has exactly one, from the Service method of the same purpose (`reliable_submit_guardrails_test.go:1456-1530`). The test passes at the tip in all three build targets it loads (darwin/arm64, linux/amd64, linux/arm64).
- **The gate works for a call by name.** Probe P1-control: a call to `commissionOperationalAdmission` added to the private handoff path fails `TestOperationalHandoffNoPublicStartupOrdinaryOrFixtureCaller` and the message names all five prerequisites.
- **The gate does not see a call through an interface** (A2-2, low). A complete wiring still needs a domain, and the constructor gate catches that.
- **The prerequisite list cannot drift silently.** `docs_contract_test.go` compares the list in the guard file with owner document section 8 and with a third copy, in order. Read, not mutated by me.
- **Guard mutant G-GATE** (the gate accepts any reference): killed by 12 leaf tests, the direct, closure, method-value and method-expression controls of all three entries.
- **What commissioning lacks is stated, not hidden.** The owner document and `PLANS.md` say that installed commissioning, the custody of the right to commission, advance and withdraw, an epoch change and rollback protection for the trust publication are open seams. I agree with that reading of the code: nothing in production can create, replace or stop an admission row today.

## 8. Validation assessment

### 8.1 What I ran, on which bytes

Every run used a git clone of the audited commit, owned by an unprivileged user, on Linux amd64 with Go 1.26.5, `GOTOOLCHAIN=local`, `GOPROXY=off`, `GOFLAGS=-mod=readonly`. The store package's test file `replay_custody_file_test.go` does not compile on Linux at the base (the known `Stat_t.Mode` width problem that PR #14 fixes). Runs that include the store package therefore use the committed bytes plus that one test-file overlay (`store-test-linux-overlay.patch`, SHA-256 `1173ed06…9ad4`, the same patch hash the writer reports). Runs of `es/admission` alone use the exact bytes.

| Check | Command | Result at `b6d2f77` |
| --- | --- | --- |
| Build | `go build ./...` | Exit 0 |
| Vet | `go vet ./es/admission/ ./es/admission/internal/reliablesubmit/` | One line, `es/admission/result_auth_test.go:395:15` (a copied lock). File not touched by the repair; same line at `e544e0f`. |
| Format | `gofmt -l` on the 19 changed Go files | Clean |
| Whitespace | `git diff --check 8058561 b6d2f77` | Clean |
| Dependencies | `git diff` on `go.mod`, `go.sum` | Unchanged |
| Full suite | `go test -count=1 -timeout 90m -json ./...` | 6,204 results: 6,121 pass, 42 fail, 41 skip. `es/admission`: 1,810 pass, 0 fail, 1 skip. Store: 727 pass, 3 fail, 2 skip. |
| Same at the blocked tip `e544e0f` | same command | 5,699 results: 5,616 pass, 42 fail, 41 skip. |
| Comparison by test name | `full-suite-compare.tsv` | The same 42 names fail at both tips. **No name changed result.** 13 names removed (all passed before; v1 tests, renamed subtests, two document cases), 518 added (all pass). |
| Race detector, store | `go test -race -count=1 -timeout 60m -json ./es/admission/internal/reliablesubmit/` | 727 pass, 3 fail (the three environment failures), 2 skip. No data race reported. |
| Race detector, admission | `go test -race -count=1 -timeout 60m -json ./es/admission/` | 1,810 pass, 0 fail, 1 skip. Exit 0. No data race reported. |
| Guard probes | section 7.4 | Two escapes found (A2-1, A2-2), each with a control |
| Guard mutants | section 7.4 | 7 of 7 killed |
| Old-shape and schema-4 probes | section 7.8 | Refused unchanged in both directions |
| My mutants | section 8.2 | 150 mutants of production code: 124 killed by behaviour, 26 survive (the writer's six, 13 duplicates, 7 real gaps: A2-5, A2-7, A2-8, P-1). 6 of 6 controls pass. |

**The 42 failing names** are environment failures, identical at both tips. They are 12 top-level tests: nine `TestRemoteAlpha…` operator-script tests of the root package (39 results with their subtests; Inference from their messages and from the writer's description: they need macOS paths, `sudo` or directories this container does not allow) and the 3 old-binary refusal tests of the store package, which need probe binaries built from older trees. I did not diagnose each one and did not make any of them pass. The 41 skips are the same at both tips: 38 in `es/app`, 2 helper tests in the store package, 1 in `es/admission`.

**The writer's counts against mine.** Totals agree exactly: 6,204 results at the tip and 5,699 at the blocked tip, 518 added, 13 removed, and the per-package counts of the two changed packages (1,810 / 0 / 1 and 727 / 3 / 2). The writer reports 166 failing results under 16 top-level tests at the tip, I have 42 under 12. Inference: the difference is environment only. The writer ran in a copy without `.git` and under another account, so more of the operator-script tests fail there, and `TestTrackedGeneratedArtifactHygiene`, which needs `.git`, passes in my clone. The writer's report names its failures by class, not one by one, so I compared classes, not names: all of mine fall in the two classes the writer names. The writer also saw 15 names go from fail to pass between its baseline run and its final run; in my two runs no name changed.

### 8.2 My mutants

A mutant is one small change to production code that removes or weakens one check. It is killed when a test fails because of it. I wrote my own list from the code, not from the writer's list, and ran each against the exact tip.

- **First stage, behaviour only.** Admission-layer mutants run `-run '^Test(PR12|Operational|RedTeamPR13)'` with the four source-inventory tests skipped, so a kill cannot come from an inventory noticing the edit. Store-layer mutants also run the whole store package. Schema mutants first get the schema digest pin recomputed, so a kill cannot come from the pin.
- **Second stage, for survivors only.** The whole `es/admission` package with every inventory and guard test, to see whether anything at all notices. For store-layer mutants the whole store package already ran in the first stage.
- **Controls.** Six runs with no change, spread over the streams and over time, to detect load-dependent failures.

| Layer | Mutants | Killed by behaviour | Survive behaviour, noticed only by an inventory test | Survive everything |
| --- | --- | --- | --- | --- |
| Store operations, cuts and custody grammar | 46 | 34 | 0 | 12 |
| Schema text (digest pin moved first) | 16 | 16 | 0 | 0 |
| Admission | 88 | 74 | 3 | 11 |
| **Total** | **150** | **124** | **3** | **23** |

- **Controls.** All 6 unchanged runs pass.
- **Survivors.** 26 mutants survive the behavioural stage: the writer's six, 13 duplicates of mine and 7 real gaps. Section 7.3 lists each one with the neighbour and the pair. The gaps are findings A2-5, A2-7 and A2-8 and the pre-existing item P-1.
- **Thin kills.** 38 of the 124 kills rest on a single failing test. The result table gives the count and the first failing test for every mutant.
- **Definitions that did not compile.** 9 of my first definitions left a variable unused and did not build (S-WR1, A-CF2, A-SS2, A-CU5, A-IN1, A-IN3, A-IN3b, A-IN12, A-FS2). I rewrote each so that it compiles (the ids ending in `r`) and ran it. The failed forms stay in the result table as `BUILD-FAIL` rows and are not counted above.
- **One interrupted stream.** My background runner stopped one stream of the first stage at its 30-minute limit, in the middle of a mutant. I restored that scratch copy, checked that its difference from the tip was again only the one-file overlay, and ran the unfinished mutants again in another stream. No verdict comes from a partial run.
- **Guard mutants** are separate (section 7.4): 7 of 7 killed.

**What the mutant runs do not show.** They show that each listed check is observed by a behavioural test. They do not show that my list of checks is complete, and each mutant ran once. Kills that fail many tests are robust against one flaky test; the kills with a single failing test are marked in the result table.

### 8.3 What did not run

- macOS, the Linux box, any live service, a real EGS or agent (non-goals).
- The three old-binary refusal tests and the nine Remote Alpha root tests with their subtests (environment). For the schema-4 refusal I ran my own probe instead (7.8).
- CI. No workflow exists on this branch until PR #14 merges.
- Fuzzing beyond the seed corpus.
- Red-team work (non-goal; planned for the combined PR #12).
- A second run of the full suite or of the race detector.

### 8.4 Evidence files (`06-audit-evidence/`)

| File | Content |
| --- | --- |
| `manifests/` | Opening and closing manifests, two runs each, for both comparisons |
| `full-suite-compare.tsv` | Test-by-test comparison of the two tips |
| `race-summary.txt` | Race detector counts and the data-race search |
| `store-test-linux-overlay.patch` | The one test-file overlay |
| `redteam-file-5ca4079-to-b6d2f77.diff` | My diff of the red team's file |
| `guard-probe-synthetic.txt`, `guard-probe-real.txt`, `guard-probe-real-2.txt` | Guard probes and controls |
| `guard-probe-sources/` | The probe sources and scripts (as text) |
| `guard-mutants.txt` | The seven guard mutants |
| `old-shape-probe.txt`, `schema4-opener-probe.txt` | Schema probes |
| `match-clause-mutant-at-blocked-tip.txt` | The P-1 mutant at the blocked tip |
| `cancel-during-confirmation-probe.txt`, `cancel-at-sample-probe.txt`, `cancel-during-evaluation-probe.txt` | The three A2-8 probes |
| `mutants-specs.py.txt`, `mutants-runner.py.txt` | My mutant definitions and runner |
| `mutants-results.tsv` | One row per mutant: both stages, verdict, first failing test |
| `scripts/` | Environment, suite, race and helper scripts (as text) |

## 9. Required corrections (repair scope for the writer thread)

One repair tranche, by the writer thread, on the same branch. Production code needs no change for R1 to R6. R7 adds one test seam to the store, as the other writers already have. R8 is a small change of a reported reason at two points, or two sentences.

**Blocking**

- **R1 (A2-1).** In `wholeValueReferences`, also record a conversion whose *operand* is a pointer to the owning type (or to a defined type over it) when the result is not. Go allows this conversion only between pointers to structs of the same shape, so the rule is narrow. Give it the existing `whole-convert` kind or a kind of its own. Add self-test cases to the guard: named twin, anonymous twin, a named pointer type as the target, the converted pointer kept in a variable, a whole overwrite through the converted pointer, and a negative control (a pointer conversion between two unrelated same-shape types). Add the two end-to-end forms of this report (the view's revocation lists; the three Service latches) to the maintained escape tests, so that each fails the guard. State the rule in both directions in the owner document (:538-540) and re-read the sentence at :534-535 against what the tests deliver. Then update every real inventory that the new rule touches; I expect none: the non-test files of the two packages contain no pointer conversion at all (my search for `(*T)(` and `(*struct`: zero matches).
  The alternative, naming the shape as a limit and pinning the exclusion, is permitted by RT-1's wording. I do not recommend it: this shape leaves no trace in any inventory, unlike the five limits named today.

**Low, same tranche**

- **R2 (A2-2).** Make the commissioning gate see dynamic dispatch: count selections of the gated method names through interface and type-parameter values in the package, or refuse an interface or constraint that declares one of those names. Add a positive control. Or name dynamic dispatch as a limit of the gate in the owner document, beside the statement that the constructor gate is the backstop.
- **R3 (A2-3).** Correct the lock statements: owner document :457 and :577-579, persistence document :551-552, the code comment at `reliable_submit_operational_admission.go:277`, and the lock inventory row at admission model document :996. Say whether the three operations may be called from inside a borrow.
- **R4 (A2-4).** Limit the "Denied" row and the `PLANS.md` sentence to retained originals and state the reason a fresh delivery reports, or report Denied there too. Pin the chosen reason in `TestPR12RetainedAdmissionCuts`.
- **R5 (A2-5).** Pin the value of the evidence cap once: a row in the limits table of `es/admission/resource_limits_test.go`, or one store vector with a literal length.
- **R6 (A2-6).** In `TestOperationalAdmissionPublishedSchema5ShapeRefused`, assert the specific refusal for each of the four openers and open the amended shape with all four in the control.
- **R7 (A2-7).** Give the store's admission write the COMMIT fault seam the other writers have, and add three store tests: an unknown COMMIT answer for each of the three operations (row written, and row not written), a stored time ahead of the clock, and a database that no longer verifies as current.
- **R8 (A2-8).** Decide what a cancelled call answers and make code, outcome table and tests agree: answer Canceled when the context has ended at the pre-check's hint read (`reliable_submit_operational_handoff.go:309-313`) and at the intent-binding failures (`:380-387`), or state both windows in the table. Add a test that ends the context from the EGS hook, the evaluation hook and the clock seam at each first-effect cut.

**Pre-existing, recommended for the same pass**

- **R9 (P-1).** One store test: at each first-effect cut, a callback that returns a valid match for a different original is refused with no write.

**Optional, cheap, and worth doing in the same pass**

- O-2: one sentence that any refusal after staging, not only a denial, leaves the claim needing a new submit key.
- O-5: correct the stale comment in the red team's file. This is a change to that file and belongs in the 11.6 table of the next report.
- O-6: a test that fails when a non-test file of the two packages carries a build constraint outside the known set.
- O-7, O-8: name the package scope of the whole-value inventory and the literal-only scope of the table-writer inventory in the owner document's list of limits.
- O-10, O-11: the two wording fixes.
- 7.5: a direct test of the digest function for the two frames that are constant today (the verifier's algorithm; the configured policy's id and entry count).

**After the repair:** new provenance for the new tip, a replacement implementation report, then a fresh audit thread. The red-team pass on the combined PR #12 comes after an accepted audit, as planned.

## 10. Sensitive-material handling

No secret, credential, key, token, environment file or production state was read, printed or copied. The tests use keys generated inside their fixtures and temporary SQLite files that the tests create and delete. My probe databases were built by test code in a scratch directory and hold fixture data only. The writer's evidence archive was classified before it was opened, extracted in its own empty directory and never executed. The evidence files of this report contain source paths, hashes, test names, test output and scripts. No personal contact detail appears in this report or its evidence.

## 11. Remaining uncertainty and stop conditions

**Unknown, and what would settle it**

- Whether an old-shape schema-5 database exists on David's Mac or on the Linux box. I did not look (non-goal). If one exists it is refused unchanged (7.8). A file search on those machines would settle it.
- Whether the three old-binary refusal tests and the nine Remote Alpha root tests pass on this tip. They cannot run in this container and fail the same way at the blocked tip. The Mac run and CI settle it. One of them is `TestOperationalHandoffSchema4BinaryRefusesSchema5`. My own probe (7.8) shows the schema-4 openers refusing the amended shape unchanged, on an empty database; the maintained test with its populated fixture still has to run.
- macOS behaviour of the changed code. Not run (non-goal). The typed guard does load the darwin/arm64 target, so the inventories cover the darwin file set.
- Whether any shape beyond A2-1 and A2-2 escapes the guard inside one function. I searched and found none. That is a search, not a proof. The red-team pass on the combined PR #12 is the planned place to push further.

**Not verified by me, stated so**

- Each new inventory entry against its source line (I spot-checked the store entries and the closure entries).
- The docs test's file count change (11.4 item 16) and the phrase pins, beyond the test passing.
- The subagent observations marked "not verified" in 6.5.
- Flakiness beyond what my runs show: the full suite ran once per tip, the race detector once, each mutant once (six unchanged controls at different times all passed). The writer reports one scheduling-dependent kill, fixed in `b6d2f77`; its replacement subtest passed in every run of mine, and my own deferred-transaction mutant S-LK1 is killed by three tests, that subtest among them.

**Stop conditions for the next step**

- Do not merge PR #13 into the PR #12 branch on this report. The verdict is BLOCK.
- This audit binds only the bytes of `b6d2f77`. Any changed byte needs new provenance and a fresh audit.
- No stop condition was hit during the audit: no provenance mismatch, no secret material, no need to widen scope.

## 12. Confidence

- **Provenance: high.** Both manifests were reproduced twice at the start and twice at the end, byte-identical each time and equal to the writer's values. The remote tip did not move.
- **Validation: medium to high.** Everything in section 8 ran on the exact bytes with my own commands. The limits: Linux only; the full suite and the race detector ran once per tip; each mutant ran once; twelve tests cannot run in this container; the store package's tests need a one-file overlay to compile on Linux.
- **Implementation: high for the store and the admission logic, medium for the guard.** The fence, the triggers, the freshness rule and the outcome mapping were read in full and are pinned by behaviour under my mutants, with the exceptions named in A2-5, A2-7 and A2-8. For the guard I show two escapes. My search for more found none, and a search is not a proof.
- **The verdict: high.** A2-1 is reproduced end to end, twice, with controls.

## 13. Effect status

Repair: not performed. Commit: none. Push: none. Pull request, comment, review: none. Merge: none. The provenance clone is unchanged and at `b6d2f77`. Scratch copies and outputs exist only inside this thread's container.

## 14. Report delivery

This file: `/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/06-audit.md`. Its SHA-256 is given in the thread reply that attaches it. Evidence: `06-audit-evidence/` in the same folder (section 8 lists the files).

## 15. Final verdict

**BLOCK.** One medium finding (A2-1). The production change itself is accepted as audited; the block is on the guard and its contract text. After the repair: new provenance, a replacement implementation report, then a fresh audit thread. This audit does not bind changed bytes.

STATUS: READY
