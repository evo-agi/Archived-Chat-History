# 24-audit-pr26-repair3 evidence (ES PR #26, `06ec54b` to `a88467f`)

Written by the independent audit thread "Audit Execution-Substrate PRs" on 2026-11-23, from 18:28Z onwards. Every file here was made in the audit's cloud container or fetched read-only. `SHA256SUMS.txt` lists every file.
My local folder, tree and script names carry the tag `26d`. The writer's own evidence happens to use the label `26d` for its round as well (`pr12-trial/trial26d-…`); the two are unrelated.
Nothing in this folder is authority. It is evidence for `../24-audit-pr26-repair3.md`.

## Setup

- **Clone and recipe.**
  - The repository clone is `/opt/audit/es`.
  - Manifests use the v2 recipe `/opt/audit/v2.py` (SHA-256 `c08597e2…a3ca`), checked before each run.
  - Each run checks out the topic branch at the tip, resets it to the base, and pins the upstream to `origin/trunk_dev`.
- **Test trees.** All are `git archive` exports in `/home/ci`:
  - `es26d` and `pr26d`: head `a88467f`.
  - `b26d`: previous head `06ec54b`. `pr23h` (audit 23) is also `06ec54b`, and `pr21h` is `c99a1b4`.
  - `fix26c` (audit 23): `06ec54b` + `key-path-unambiguous-proposal.diff`.
  - `/home/ci2` holds copies of `es26d` and `b26d` for the second identity.
  - `m26d`: the trial merge of PR #12's head `2c8bf35` with `a88467f`, resolved in a temporary worktree (never committed or pushed; the worktree was removed). See `trial-merge-provenance.txt`.
- **Identities.** Runs used `env -i` and Go 1.26.5 with `GOTOOLCHAIN=local`, as user `ci` (1500:1600, with sudo) and user `ci2` (1700:1700, without sudo).
- **Probes and mutants.** Each one ran in a fresh copy of a pristine tree.
- **No downloaded binary was executed.** `dto26b-writer.py.txt` is the writer's probe script from `02-repair-evidence/`, copied verbatim and read in full before it ran.

## Files

| File | What |
| --- | --- |
| ls-remote-open.txt, ls-remote-close.txt | Remote refs at the start (18:29Z) and at the end (18:52Z). Both times the branch was at `a88467f` and `trunk_dev` at `036d507` |
| manifest-v2-open-…-run1/2.json (+ .out.txt), manifest-v2-close-…-run1/2.json (+ .out.txt) | `a88467f` against `036d507`: `54afb586…19ff` all four times. The JSON is byte-identical across runs and to the writer's `manifests/a88467f-vs-036d507-trunk-1.json` and `-2.json` |
| delta-06ec54b-a88467f.diff | `git diff 06ec54b a88467f`, byte-identical to the writer's |
| equivalence-proposal-vs-a88467f.diff | My audit 23 proposal commit (`06ec54b` + `key-path-unambiguous-proposal.diff`, local) compared with `a88467f`: only the `zzJSONOwnString` case differs |
| writer-evidence-check.txt | The writer's report and tar hashes, its `SHA256SUMS` check (78 of 78 OK), and the manifest, delta and proposal comparisons |
| unit26d.sh.txt, unit-admission-a88467f-vs-06ec54b-uid1500-gid1600.log, -uid1700-gid1700.log | gofmt, vet (three targets) and es/admission in full at both heads, for both identities, with a diff of the results |
| probes26d.py.txt, probes26d-a88467f-and-trial-merge-uid1500-gid1600.log | Audit 23's probes T0 to T7 plus the new T8 (a named string type with its own `MarshalJSON`) on `a88467f` and on the trial merge |
| probes26d-T8-earlier-trees-uid1500-gid1600.log | T8 on `c99a1b4`, `06ec54b` and audit 23's proposal tree |
| probes21.py.txt, probes21-a88467f-uid1500-gid1600.log | Audit 22's probes Q0 to Q6 on `a88467f` |
| probes20.py.txt, probes20-a88467f-uid1500-gid1600.log | Audit 20's probes P00 to P30 on `a88467f` (tree label `a88`): all 31 as predicted |
| mutants20.py.txt, mutants20-a88467f-uid1500-gid1600.log | Audit 20's 22 mutants on `a88467f`: all caught |
| mutants26d.py.txt, mutants26d-a88467f-uid1500-gid1600.log | Codec mutants P00 to P03 on `a88467f`: all caught |
| mutants26d-P03-on-audit23-proposal-uid1500-gid1600.log | P03 on audit 23's proposal tree: survives, so the writer's string case is needed |
| mutants26d-with-probe-T8-uid1500-gid1600.log | P00 and P03 with probe T8 applied, judged by the DTO guard: refused without the mutant, let through under P03 |
| mutants26d-fix.py.txt, mutants26d-fix-a88467f-uid1500-gid1600.log | The mutants of audit 23's diff, X00 to X04, on `a88467f`: all caught |
| rprobes26d.sh.txt, dto26b-writer.py.txt, writer-rprobes-a88467f-uid1500-gid1600.log | The writer's real-tree probes R0 to R7 on `a88467f` |
| resolve26d.py.txt, merge26d.sh.txt, trial-merge-provenance.txt, trial-merge-2c8bf35-a88467f-uid1500-gid1600.log | The trial merge: merge-tree result, the resolution of the two known blocks, the resolved tree (`052d1024…`, the writer's tree too), and build, vet, gofmt and es/admission in full on it |
| trialcmp26d.py.txt, trial-merge-results-vs-writer.txt | My es/admission results on the trial merge compared test for test with the writer's `pr12-trial/trial26d-admission.results.tsv` (random SIGKILL rounds compared by round number) |
| run-26d.sh.txt | The driver for the runs above |
| ci-status.txt | CI runs on `06ec54b` and `a88467f`, read through the GitHub API |

## Sensitive material

The probes and fixtures are synthetic. No key, certificate body, token or config file is copied here. Commit-message trailers and author names are left out.
