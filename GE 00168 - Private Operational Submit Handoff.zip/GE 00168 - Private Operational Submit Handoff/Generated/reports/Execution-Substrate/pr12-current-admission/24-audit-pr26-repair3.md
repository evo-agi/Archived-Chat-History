# INDEPENDENT AUDIT REPORT: PR #26, repair of audit 23's findings (`06ec54b` to `a88467f`)

This is a narrow, read-only re-audit. The writer handed it over at 18:28Z. Audit thread: "Audit Execution-Substrate PRs", the same auditor as `20-audit-pr26.md`, `22-audit-pr26-repair.md` and `23-audit-pr26-repair2.md`. Date: 2026-11-23, 18:28Z to 19:09Z (UTC). I wrote the diff this commit applies, so for those lines this audit checks that they landed unchanged and still work; the one case the writer added is judged on its own. There is no red-team, because the PR changes test files only. My local file names carry the tag `26d`.

Verdict: **ACCEPT, with no findings.** A23-1 and A23-2 are closed. Nothing new is open in this PR.

## 1. In plain words

1. **The bytes are the ones the writer reported.**
   - My manifest of `a88467f` against `trunk_dev` `036d507` matched the writer's byte for byte at the start and at the end (`54afb586…19ff`, 4 files).
   - `a88467f` is a fast-forward from `06ec54b`. It changes one test file, +72/−11, and my delta is byte-identical to the writer's.
2. **It is my audit 23 diff, unchanged, plus one test case.**
   - Compared with my local commit of `06ec54b` plus `key-path-unambiguous-proposal.diff`, the only difference is 9 lines: a named string type `zzJSONOwnString` with its own `MarshalJSON`, and one codec case that expects it to be refused.
   - The writer's copy of my diff is byte-identical to the one I published.
3. **The extra case is right, and it is needed.**
   - It closes a gap my diff left: mutant P03, which checks for a custom codec only on composite kinds (pointer, struct, slice, array, map), survives the suite with my diff alone and is caught on `a88467f`. The writer found it first (their N27).
   - My new probe T8 puts a named string type with its own `MarshalJSON` into `PrepareRequest`. On `c99a1b4` the guards let it through; on `06ec54b`, on my diff alone and on `a88467f` the DTO guard refuses it, because the codec check already looks at every kind. With P03 applied to `a88467f`, the DTO guard lets T8 through, and only the new string case fails. So that case is what keeps the check whole.
4. **A23-1 and A23-2 are closed.** On `a88467f` and on its trial merge with PR #12, my probes T1 and T2 (a key that names a nested path) are refused, and T6 and T7 (a named map and a named `[]byte` with their own `MarshalJSON`) are refused. Mutants P01 and P02 are caught, and so are the four mutants of the diff, X01 to X04.
5. **Behaviour is unchanged.** es/admission in full, two identities: `a88467f` adds 3 new results, the three named-type codec cases, all passing. No shared result changes. gofmt is clean, and vet is clean for linux/amd64, linux/arm64 and darwin/arm64. Audit 20's 31 probes, audit 22's probes, the writer's R0 to R7 and audit 20's 22 mutants give the same results as on `06ec54b`.
6. **With PR #12.** Merged with PR #12's head `2c8bf35`, the same two known conflict blocks appear, and resolving them by the plan gives the same tree as the writer's (`052d1024…`). It builds and passes es/admission in full: 2,537 pass. Test for test, it matches the writer's trial merge, apart from five tests that skip only in the writer's environment.
7. **CI.** GitHub's "build, vet and test" run 45238013540 on `a88467f` passed (18:24Z to 18:59Z).

## 2. Audit target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Pull request | #26, draft, branch `claude/project-thread-ne9cwa` into `trunk_dev` |
| Commit | `a88467fafad9b033f637f7eddfc8de1033ab3d68`, tree `45b41a40bac412b67fcf7258836bb81a10edabde`, parent `06ec54b` (fast-forward) |
| Previous head (audit 23) | `06ec54b81a0b2afe9512f061bb1fff28e22040c3` |
| Base | `trunk_dev` `036d50724b499b020c5149c55ad902cfcb1482c0`, unchanged |
| Change | `es/admission/workstream_a_guardrails_test.go`, +72/−11 against `06ec54b`, test code only (`delta-06ec54b-a88467f.diff`, byte-identical to the writer's) |
| Recipe | `governed-execution.audit-patch-manifest.v2`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked before every run |
| Trunk-relative manifest | `54afb5869bc8f2413248bf818f66df1e8ca296623a03b4a4c97cd5540c8f19ff`, 4 files, textual diff `b0bd54fa6955e1a716c85e94fb53a07907ad2ee83df64166d2ecabafa2b5c706`, upstream `origin/trunk_dev` |
| Writer report | `reports/Execution-Substrate/workstream-a-allow-rule/04-repair.md`, SHA-256 `eac70facf6e390546ff166f7cd312d94a1b4d68a3d4371e9f26e2617215b1b7e`. Evidence `04-repair-evidence/`: its `SHA256SUMS` has 78 entries, all OK, and its two manifests are byte-identical to mine (`writer-evidence-check.txt`) |
| Background | `23-audit-pr26-repair2.md` (SHA-256 `22e7b3e5…675a`): A23-1, A23-2, O23-1, O23-2 |

## 3. Posture and setup

- Read-only on GitHub: no push, comment, review, merge or branch change. The trial merge was resolved in a temporary worktree of my clone, written as a tree object only, never committed or pushed, and the worktree was removed (section 6).
- Clone `/opt/audit/es`. Test trees are `git archive` exports of the exact commits.
- Runs used Go 1.26.5 with `GOTOOLCHAIN=local` and an emptied environment, as two identities: `ci` (uid 1500, gid 1600, with sudo) and `ci2` (uid 1700, gid 1700, without sudo). Probes, mutants and the trial merge ran as `ci`, after the full runs.
- Every probe and mutant ran in a fresh copy of a pristine export. I ran the writer's probe script `dto26b.py` (verbatim, SHA-256 `25b2f7dd…8906`) again, on `a88467f`. No downloaded binary was executed.

## 4. Provenance

| Run | Time | `trunk_dev` | Result |
| --- | --- | --- | --- |
| Opening, two runs | 18:29Z | `036d507` | `54afb586…19ff` both times, identical to each other and to the writer's `manifests/a88467f-vs-036d507-trunk-1.json` and `-2.json` |
| Closing, two runs | 18:52Z | `036d507` | `54afb586…19ff` both times, byte-identical to the opening runs |

The ref check before each pair is explicit, and it passed. The branch and `trunk_dev` were at the expected commits (`ls-remote-open.txt`, `ls-remote-close.txt`). Afterwards the clone was at `a88467f` with a clean status.

## 5. What I verified

### 5.1 The diff

- `git diff` of my audit 23 proposal commit (`189340e`, local, never pushed) against `a88467f` shows only `zzJSONOwnString` and its codec case (`equivalence-proposal-vs-a88467f.diff`). The writer's `a88467f-vs-06ec54b-plus-proposal.diff` has the same changed lines.
- The new case follows the two cases my diff added: a struct with one field of the named type, and the expected refusal `["admission.zzJSONOwnString"]`. The type's `MarshalJSON` writes an object, so a string type with its own codec can carry keys the field walk cannot see. Refusing it is right.

### 5.2 Tests

`unit26d.sh` runs gofmt, vet for three targets and es/admission in full at `a88467f` and `06ec54b`, as both identities (`unit-admission-a88467f-vs-06ec54b-uid1500-gid1600.log`, `-uid1700-gid1700.log`).

| Identity | `06ec54b` | `a88467f` | Difference |
| --- | --- | --- | --- |
| `ci` (sudo) | 1,170 pass, 7 skip | 1,173 pass, 7 skip | +3 new, all pass: the codec cases for a named map, a named `[]byte` and a named string type. 0 changed, none gone |
| `ci2` (no sudo) | 1,159 pass, 11 skip, 7 fail | 1,162 pass, 11 skip, 7 fail | the same +3. The 7 failures are the same at both heads, all from execution-root privilege |

gofmt is clean, and vet is clean for linux/amd64, linux/arm64 and darwin/arm64, at both heads. The writer's counts (1,165 to 1,168 passing, 12 skips) differ from mine only in how many tests skip; the totals agree, 1,177 to 1,180. The three refused key cases of my diff run as a loop inside the existing paths test, so they add no results of their own.

### 5.3 Probes

All probes built, and every result matched my prediction.

- **Audit 23's probes, as `probes26d.py`** (a copy that adds the trees `a88467f` and `m26d` and the probe T8), on `a88467f` and on the trial merge (`probes26d-a88467f-and-trial-merge-uid1500-gid1600.log`, unexpected=0):

  | Probe | Change | `a88467f` | trial merge |
  | --- | --- | --- | --- |
  | T0 | none | all pass | all pass |
  | T1 | a top-level field tagged `"governed_execution.contract"` stands in for `contract` | producer **refused** | producer **refused** |
  | T2 | a field tagged `"runtime_profiles[].name"` stands in for the element's `name` | producer **refused** | producer **refused** |
  | T3 | `PrepareRequest` gets `json.RawMessage` `extra` | pass (O23-1) | pass (O23-1) |
  | T4 | `PrepareRequest` gets `any` `extra` | pass (O23-1) | pass (O23-1) |
  | T5 | `PrepareRequest` gets a `time.Time` field | refused (fails closed, as before) | refused |
  | T6 | a named map type with its own `MarshalJSON` | refused | refused |
  | T7 | a named `[]byte` type with its own `MarshalJSON` | refused | refused |
  | T8 | a named string type with its own `MarshalJSON`, which writes `"zzname":{"publication":true}` | refused | refused |

- **T8 on the earlier trees** (`probes26d-T8-earlier-trees-uid1500-gid1600.log`, unexpected=0): it passes on `c99a1b4`, and it is refused on `06ec54b` and on `06ec54b` with my diff. So the code refused named string types before this commit; only the test was missing.
- **Audit 22's `probes21.py`** on `a88467f` (`probes21-a88467f-uid1500-gid1600.log`, unexpected=0): Q1, Q2, Q3, Q5 and Q6 are refused, and Q0 and Q4 pass, as on `06ec54b`.
- **Audit 20's `probes20.py`** on `a88467f`: all 31 as predicted (`probes20-a88467f-uid1500-gid1600.log`).
- **The writer's R0 to R7** on `a88467f`: R0 passes, and R1 to R7 are refused by the DTO guard (`writer-rprobes-a88467f-uid1500-gid1600.log`).

### 5.4 Mutants

- **Audit 20's `mutants20.py`** on `a88467f`: the control passes, and all 22 are caught (`mutants20-a88467f-uid1500-gid1600.log`).
- **`mutants26d.py`** (audit 23's codec mutants plus P03). Each runs the Workstream A and B, producer and C2 to C5 guard tests:

  | Mutant | Change | my diff alone (`06ec54b` + diff) | `a88467f` |
  | --- | --- | --- | --- |
  | P00 | none (control) | passes | passes |
  | P01 | the codec check looks only at pointers and structs | caught (audit 23) | caught |
  | P02 | every `[]byte` type is exempt, not only `json.RawMessage` | caught (audit 23) | caught |
  | P03 | the codec check looks only at composite kinds (pointer, struct, slice, array, map) | **survives** | caught |

  (`mutants26d-a88467f-uid1500-gid1600.log`, `mutants26d-P03-on-audit23-proposal-uid1500-gid1600.log`; P01 and P02 on my diff alone are in audit 23's `mutants26c-on-proposal-uid1500-gid1600.log`.) The writer's mutant N27 is the same change as P03, and their report says the same.
- **With probe T8 applied** (`mutants26d-with-probe-T8-uid1500-gid1600.log`): on `a88467f` the DTO guard refuses T8. Under P03 the DTO guard lets T8 through, and only `TestWorkstreamAJSONFieldNamesRefuseOwnCodecs` fails, through the new string case. My first run of this check labelled the result by "any test fails", which the string case alone triggers under P03; I relabelled it to judge the DTO guard itself and ran it again. The log holds the second run.
- **The mutants of my diff, X00 to X04**, on `a88467f` (`mutants26d-fix-a88467f-uid1500-gid1600.log`): the control passes, and all four are caught by `TestWorkstreamAJSONKeyPathsAreWhatEncodingJSONWrites`.
- **The writer's 42 mutants:** their log shows all caught. I did not run them again.

## 6. With PR #12

PR #12's branch head is `2c8bf35`, the tree audited in `21-audit-pr28.md`.

- I merged `a88467f` into `2c8bf35` in a temporary worktree of my clone. The same two conflict blocks appear in `workstream_a_guardrails_test.go`, and `resolve26d.py` resolves exactly those two as the plan says (it stops on anything else): keep PR #12's `source:` line and add this PR's `node:` and `syntax:` lines. `workstream_c_guardrails_test.go` merges cleanly.
- The resolved tree is `052d102465743ce673a34f3805100b29f2d142c5`, the same tree as the writer's trial merge `356317c`. It differs from audit 23's trial merge only by the string case (`trial-merge-provenance.txt`). No `fieldNames[…]` read is left in `es/admission`; only `es/config` keeps its own, unrelated helper (O23-4).
- On that tree (`trial-merge-2c8bf35-a88467f-uid1500-gid1600.log`): gofmt is clean, `go build ./...` is ok, and vet of es/admission is clean for the three targets. es/admission in full: exit 0, 2,537 pass, 8 skip.
- Test for test against the writer's `pr12-trial/trial26d-admission.results.tsv` (`trial-merge-results-vs-writer.txt`; random SIGKILL rounds compared by round number): no test is only in one set. Five tests that the writer's run skipped pass here; they are execution-root checks that skip without passwordless sudo (Inference: the writer's environment lacks it). Nothing else differs.
- My probes T0 to T8 on the merged tree give the same results as on `a88467f` (section 5.3).

## 7. Findings

None.

Observations O23-1 and O23-2 stay as audit 23 described them. I advised no action, and the writer gives reasons in `04-repair.md` section 3.3 that I agree with: the guards judge a DTO's own field names, `map[string]string` fields such as `Env` already carry arbitrary keys as data, and a new `any` or `json.RawMessage` field in a public DTO would be a visible, reviewed design change. O23-4 (`es/config`'s own helper) is outside this PR and with the coordinator.

## 8. CI

| Head | Run | Result |
| --- | --- | --- |
| `06ec54b` | 45226582061 | completed 17:48Z, success |
| `a88467f` | 45238013540 | completed 18:59Z, success |

(`ci-status.txt`)

## 9. Sensitive material

The probes and fixtures are synthetic. No key, certificate body, token or config file is copied into the evidence. Commit-message trailers and author names are left out.

Before publishing, I scanned this report and every evidence file for private-key and certificate headers, Vault, GitHub, Anthropic and AWS token shapes, JWTs, phone-number shapes, personal names and model names, with a positive control that matched as expected. There were no hits. A second scan for commit trailers and author names found nothing.
