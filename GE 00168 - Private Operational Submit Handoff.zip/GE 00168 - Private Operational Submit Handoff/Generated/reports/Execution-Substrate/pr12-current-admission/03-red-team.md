# Red-team report: Execution-Substrate PR #13, current-admission re-check

Stage 03 of workstream `pr12-current-admission`. Written by the red-team thread, which is separate from the writer (stage 01) and from the correctness audit. I did not read the audit report or coordinate with the audit.

One disclosure on independence. At about 04:45 UTC, after this report was first written to the shared folder, I updated the shared project memory index and saw one line there that summarizes the audit: verdict BLOCK, with tests said to leave the run-assignment cut and the establish gate unpinned. Everything in this report except mutation run 3 predates that. Run 3 (section 6) was added afterwards, to check each writer on its own.

Date of the work: 2026-11-22, about 03:07 to 05:00 UTC.

## 1. Verdict

**HOLDS WITH CAVEATS.**

In plain words:

- **The fix itself held.** I could not get ES to stage files, write the stamp, write the dispatch marker or send the job to Nomad after the current authority said no. I tried this at every crash point, under concurrency, with tampered and forged records, with reused keys and with planted files. Section 5 lists every attack and its result.
- **Finding RT-1 holds (medium).** The test guard that is supposed to stop a later change from quietly weakening the fix can be evaded. I proved it end to end: in a scratch copy I changed production code so that the installed admission snapshot loses its revocation lists, and the build, `go vet`, the whole `es/admission` suite and the root contract tests all still passed. This is a gap in the tests, not a defect in the shipped code. It is the same class as the two guard gaps that were already treated as defects in this workstream (the parenthesized write, and the range, address and write-through gaps).
- **Finding RT-10 holds (medium).** Three production checks had no behavioural test. I could remove each one and the writer's whole suite still passed. The shipped code is correct. Draft PR #15 adds tests that close all three gaps.
- **Eight caveats (RT-2 to RT-9).** They are low or informational. Most are documented or older PR #12 behaviour that the patch does not make worse. They are listed so nobody is surprised later.

My recommendation: do not treat PR #13 as finished until RT-1 is either fixed in the guard or written into the contract as a named exclusion, and take the RT-10 tests. Nothing here calls for changing the production re-check.

## 2. Target identity

| Item | Value | Source |
| --- | --- | --- |
| Repository | `evo-agi/Execution-Substrate` | brief |
| PR under test | draft PR #13 | brief |
| Topic branch | `claude/project-thread-sqldt7` | brief, re-fetched by me just before opening PR #15 and still at the commit below |
| Commit | `e544e0fbe4220dfdd2c2068e3267dcfa454a0cf9` | brief, checked by me |
| Tree | `7be20ba8a71f0f55490aaac2eb8aed5601386830` | reproduced by me |
| Base | `8058561edc08356c46680c204586b3c7796c0ff3` (PR #12 branch `codex/reliable-submit-operational-handoff-v1`) | checked by me |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` | verified by me before use |
| Canonical manifest SHA-256 | `21d19775bbe7c2d9aef0752d7a9f5b315734b7bf6f8f313197357dfc71cd7907` (4,334 bytes, 19 paths) | reproduced by me |
| Writer report | `/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/01-implementation.md` | read by me |

Provenance reproduction (repo-validated by me): fresh clone, recipe hash checked, pushed tip equals the reported commit, base is an ancestor of the tip, base ref still at the base SHA, upstream pinned to the base ref as the writer report instructs, recipe run twice, outputs byte-identical, and the manifest hash equals the writer's. So the attacks below ran against the bytes the writer reported.

## 3. Posture and effects

- I changed nothing in PR #13 and pushed nothing to its branch.
- I pushed two commits to my own branch `claude/project-thread-uijb9o`: `ef83f335559518e76f9b77dca2adba9e80ecf4fa` and `5ca407965a202c076e62d88ae79daa30ae97838b` (head, tree `56bc93d5aad552973490ea50a3290a030fbe998d`). Together they add one test file and no production change.
- I opened draft PR #15 from that branch to the PR #13 branch: https://github.com/evo-agi/Execution-Substrate/pull/15. It is red on purpose (section 8).
- Production mutants existed only in scratch worktrees inside this thread's container. None was committed or pushed. The worktrees are removed.
- No merge, no force-push, no contact with any live service. The disposable Linux box was not used. No subagents were used.
- Everything ran in a Linux cloud container, `go1.26.5 linux/amd64`, 4 CPUs.

## 4. What the patch claims (current contract)

Repo-validated at `e544e0f`:

- Every unmarked first-effect cut re-verifies the retained signed evidence and evaluates the commissioned Service trust model and built-in policy: `es/admission/reliable_submit_operational_admission.go:268` (`qualifyOperationalRetained`), called before and inside each writer and at release from `es/admission/reliable_submit_operational_handoff.go:263` (`advanceOperational`), with a final identity and withdrawal sample at `reliable_submit_operational_handoff.go:624-627`, just before the POST at line 631.
- Contract text: `.docs/execution_lifecycle/reliable_submit_operational_handoff.md:346-380`. Key sentences: a denied or unavailable authority "withholds run/receipt"; "A withdrawal observed before a cut stops its next action; a previous committed write or already-entered I/O cannot be retracted"; a retry after a policy change "is refused at its first remaining cut ... without advancing or disclosing the claim; a later retry under an allowing authority still completes, so a denial does not poison the claim".
- Guard claim: same file, lines 317-344. "The maintained guarantee is exact syntactic occurrence, function site and access kind, not a general proof of aliases or runtime safety." "Called functions and methods are not analyzed beyond Go's implicit address-of."

## 5. Attacks and results

All results in this table were produced by me in the container. "Final bytes" means commit `5ca4079`, which is `e544e0f` plus my one test file.

| # | Attack | What I did | Result |
| --- | --- | --- | --- |
| A1 | Retry after a crash, across a policy change | 6 crash points (assign rolled back, assign committed with the reply lost, intent rolled back, intent committed, stamp committed, marker committed) by 10 authority states (no authority, never commissioned, withdrawn, signer removed, empty allowed list, verifier key rotated under the same key id, verifier key id rotated, other epoch, other installation, artifact revoked), each through handoff and through recovery: 120 calls | No stage, stamp, marker, receipt or POST was ever gained. For claims not yet stamped, the handoff also withheld the run. Afterwards a retry under the original allowing authority completed exactly once for the four not-yet-staged crash points. Stamped and marked claims never dispatched again. |
| A2 | Realm confusion | Domain rebuilt for a later epoch or another installation, against a claim at intent and an accepted claim, with a matching authority, the original authority and no authority | Refused with reason Integrity, nothing changed, and the original realm still worked afterwards. |
| A3 | Idempotency-key reuse and caller substitution | Same submit key with a different invocation, and the retained delivery presented by another SPIFFE identity, under a denying and an allowing authority, handoff and recovery | Key reuse returned Conflict with no run. The other caller returned Unauthorized with no run. Nothing changed. |
| A4 | Race between authority change and handoff | An allowing and a denying Service on one claim at the same time, with a withdrawal fired asynchronously from each proof hook in turn. 14 iterations in the committed test, 28 in the experiment. Also under `-race`. | The denying Service never performed a gated write. Never more than one POST. No data race reported. See RT-4 for what a withdrawal does not promise. |
| A5 | Path and symlink tricks on staged files | Planted at the assigned run's stage name before the retry: a symlink to a directory, a dangling symlink, a directory holding a symlinked payload, a regular file | No retry followed, adopted or wrote through the planted object, and no file appeared outside the staging root. |
| A6 | Tampered retained original | 48 single-bit flips written in place into the sealed original object, 16 of them aimed at the trailing evidence leaf | Every one refused with no run and no effect. Restoring the exact bytes let the retry complete. |
| A7 | Forged or stale admission record | The qualifier was handed changed evidence directly: 6,000 random mutations, semantic edits such as an added `CAP_SYS_ADMIN`, a validly signed record for a sibling artifact, a padded seal key id, duplicate and unknown members | A changed record qualified only when its signed canonical claims were byte-identical to the original's. 0 counterexamples. See RT-8. |
| A8 | Fuzzing the parsers | `FuzzRedTeamPR13DecodeOperationalEvidence`: 1,060,231 executions in 151 s. `FuzzRedTeamPR13ParsePrivateReplayDelivery`: 786,486 executions in 151 s. | No crash, no failed property. |
| A9 | Custody grammar for the new evidence leaf | 20,000 generated leaves, the 256 KiB boundary, 5,000 variant labels, 200,000 wire mutations. Run earlier in this session in scratch only, see section 9. | No panic. 262,144 bytes accepted, 262,145 refused. |
| A10 | Would the tests notice a removed check? | 23 production mutants, each run against the writer's own suite and against my tests | Three checks are not pinned by any behavioural test in the writer's suite: **RT-10 holds.** My tests pin all three. See section 6. |
| A11 | The test guard itself | Synthetic packages against the guard validators, then a real production mutant against the whole suite, with a control | **RT-1 holds.** |
| A12 | Cost inside the database writer | A payload that decodes to 15 MiB from about 15.5 KB of gzip, and a count of policy evaluations | About 4 to 6 ms per extraction and 11 policy evaluations per handoff. Bounded. See RT-7. |
| A13 | New claim after the authority is gone | A fresh delivery handed to a withdrawn Service, with the withdrawal before the handoff and between the two authority samples around Establish | No claim row, no sealed original, no run. A control fixture built the same way was accepted. |

## 6. Mutation runs (A10)

Each mutant removes one check from production code in a scratch worktree at `e544e0f`. "Writer's suite" is `go test -count=1 ./es/admission/` without my file. "Red-team tests" is `go test -count=1 -run 'TestRedTeamPR13Holds' ./es/admission/` with my file, as of `ef83f33` for runs 1 and 2 and as of `5ca4079` for run 3. "Caught" means at least one test failed. The labels are the ones in `mutation-run.txt` in the PoC folder. There is no M4.

**Run 1. Checks inside the qualifier** (`es/admission/reliable_submit_operational_admission.go`):

| Label | Check removed | Writer's suite | Red-team tests |
| --- | --- | --- | --- |
| M1 | Everything after the snapshot lookup: evidence decode, match to the original, signature, trust model, policy | caught by 5 tests | caught |
| M2 | The withdrawal flag | caught by 2 behavioural tests and the access inventory | caught |
| M3 | The epoch comparison | caught by 1 behavioural test and the access inventory | caught |
| M3b | The installation comparison | caught by the access inventory only, no behavioural test | caught |
| M3c | The installation comparison, disabled with its field read kept in place | **not caught** | caught |
| M5 | The exact canonical re-encode comparison in the evidence decoder | caught by 1 test | caught |
| M6 | Signature verification | caught by 1 test | caught |
| M7 | Trust model enforcement | caught by 2 tests | caught |
| M8 | The evidence-to-original match | caught by 1 test | caught |

**Run 2. Where the check is called** (`es/admission/reliable_submit_operational_handoff.go` and `es/admission/internal/reliablesubmit/operational_handoff.go`):

| Label | Call removed | Writer's suite | Red-team tests |
| --- | --- | --- | --- |
| C1 | Qualification before the Assign writer | not caught | not caught |
| C2 | Qualification before the later writers | not caught | not caught |
| C12 | C1 and C2 together | not caught | not caught |
| C3 | Qualification inside the Assign, Intent, Stamp and Marker writers | caught by `TestOperationalAdmissionWithdrawalCuts` | not caught |
| C4 | Qualification inside the pre-stage check | caught by the same test | not caught |
| C5 | Qualification at post-COMMIT release | caught by the same test | not caught |
| C345 | C3, C4 and C5 together | caught by the same test | not caught |
| C6 | The final sample before the POST | caught by the same test and the access inventory | not caught |
| C7 | The authority sample taken when the sender owner is built | not caught | not caught |
| C8 | Both authority samples around Establish | **not caught** | not caught at `ef83f33`. Caught by the test added in `5ca4079`. |

**Run 3. One writer at a time.** Runs 1 and 2 remove one layer everywhere. Run 3 removes every layer in front of one writer: both qualifications before the writers, and the qualification inside the writer for that one operation only. The release check after the COMMIT stays.

| Label | Writer left unguarded | Writer's suite | Red-team tests |
| --- | --- | --- | --- |
| PAssign | Run assignment (revision 1 to 2) | **not caught** | caught by `TestRedTeamPR13HoldsDenialMatrixAcrossCrashPoints` |
| PIntent | Intent (revision 2 to 3) | caught by `TestPR12RetryAfterPolicyChange` | caught by the same red-team test |
| PStamp | Stamp | caught by `TestOperationalAdmissionWithdrawalCuts` | not caught |
| PMark | First marker | caught by `TestOperationalAdmissionWithdrawalCuts` | not caught |

How to read this:

- The in-writer and release layers (C3 to C6) are pinned, by one test: `TestOperationalAdmissionWithdrawalCuts`. My tests are black-box and cannot see one layer removed while the other layers still refuse, which is why they miss C3 to C6, PStamp and PMark.
- C1, C2, C12 and C7 survive everything. **Inference:** on their own they are redundant layers. With them removed, the in-writer check or the final sample still refuses, and no test, including my denial matrix, saw any change. What would confirm it: the writer stating that these calls are an early exit only.
- PAssign, C8 and M3c are real gaps in the writer's suite. They are finding RT-10.

## 7. Findings

Format follows the operating protocol's finding format. Severity scale: critical, high, medium, low, observation.

### RT-1. The typed access guard accepts protected-field changes that do not spell the field

- **Type / severity:** test and doc gap in the guard. **Medium.**
- **Origin:** patch defect in the guard, not in production code. `typedReferenceAccessKind`, `typedStorageEffect`, `typedLocationStep` and `validateTypedFieldAccessInventory` are new in PR #13. `validateOperationalAuthorityConstruction` already existed at the base, and PR #13 newly relies on it for `operationalAdmissionSnapshot`.
- **Contract:** `.docs/execution_lifecycle/reliable_submit_operational_handoff.md:317-344`. The contract promises "exact syntactic occurrence, function site and access kind" and names called functions, methods and aliases as the things it does not analyse. The shapes below are none of those. They are direct writes in the same function.
- **Evidence (repo-validated by me at `e544e0f`):**
  1. Whole-value assignment. `*s = Service{}`, `*s = Service{true, 0}`, `*s = Service{other: 1}` and `*s = fresh` change every protected field of the struct and contain no reference to any field, so the per-field inventory sees nothing.
  2. Positional literal. `&Service{true, 0}` sets the protected field with no key, so it is not counted as an initializer.
  3. A type conversion inside the access chain. `(*alias)(s.value).n = 1`, `([]int)(s.value)[0] = 1`, `delete(map[string]int(s.value), "k")` and `clear([]int(s.value))` are classified `read`. Cause: `typedLocationStep` (`es/admission/workstream_c_guardrails_test.go:3514`) has no case for a conversion call and falls to its default arm at line 3554, so `typedReferenceAccessKind` (`:3423`) returns `read` at line 3459.
  4. Construction. `validateOperationalAuthorityConstruction` (`es/admission/reliable_submit_guardrails_test.go:1543`) counts only composite literals and `new(T)`. `var forged operationalAdmissionSnapshot; return &forged` and `operationalAdmissionSnapshot(struct{ owner int }{2})` both make a snapshot outside the one approved site and are accepted.
  5. End to end. Production mutant `mutant-anonymous-struct-conversion.diff`: inside `qualifyOperationalRetained`, copy `*snapshot` into an anonymous struct of the same shape, set `RevokedSigners` and `RevokedArtifacts` to nil, and write it back with `*snapshot = operationalAdmissionSnapshot(shadow)`. With this mutant in: `go build ./...` ok, `go vet ./es/admission/` reports nothing new, `go test -count=1 ./es/admission/` ok, root `go test -count=1 -run 'TestOperationalSubmitHandoffCurrentAdmissionV2' .` ok. The "immutable" installed snapshot is rewritten and no test notices. I ran the build, vet and suite steps twice, the second time through `reproduce-guard-mutant.sh`.
  6. Control. The same rewrite spelled through the field names (`mutant-named-field-control.diff`) is rejected by `TestExecutionSubstrateSynchronizedMutableStateReferenceInventoryIsExact` with `operationalAdmissionSnapshot.trust field access inventory changed ... write-through:2`. So the guard works for the spelled form and misses the unspelled one.
  7. A named shadow struct type (`mutant-named-shadow-struct.diff`) is caught, but by a different test, `TestExecutionSubstrateProductionHasNoA3LeaseRegistryOrPoisonDesign`, because the new type adds a field to the synchronization-field inventory. The anonymous form avoids that.
  8. `go vet` copylocks does not close the gap. Earlier in this session I checked that it flags only `*s = fresh` and `*s = *t` on a struct that contains a lock. It does not flag composite-literal resets, and `operationalAdmissionSnapshot` contains no lock.
- **Impact:** no effect on shipped behaviour today. The risk is forward: a later change, by a person or an agent, can weaken the installed authority while the tests that are described as maintaining that property stay green. The contract currently reads as if that cannot happen.
- **Required correction (one of):**
  - Fix the guard. Treat a conversion call as a transparent step in `typedLocationStep`. Count positional and partial composite literals of an owning type as initializers of its protected fields. Add a type-based inventory for whole values: any assignment whose target has an owning struct type, any conversion to it, and any zero-value declaration of it.
  - Or name these shapes in the contract as exclusions, next to "Called functions and methods are not analyzed", and change the cases in `TestRedTeamPR13GuardAccessInventoryEscapes` to pin the exclusion.
- **Regression test:** `TestRedTeamPR13GuardAccessInventoryEscapes` in PR #15, 11 subtests, fails at `e544e0f` by design.
- **Uncertainty:** the list of shapes is what I found, not a proof that there are no others. Reflection, `unsafe` and generics were not explored. Two more shapes also read as `read` (a write through a temporary slice that holds the pointer, and a write through the result of a function literal call), but I left them out of the regression test because they are aliasing and a called function, which the contract already excludes.

### RT-10. Three production checks have no behavioural test

Numbered 10 because it was found last, in the mutation runs. It is listed second because it holds.

- **Type / severity:** test gap. **Medium**, because the patch's central claim is that every first-effect cut re-checks admission, and the first cut can be removed with a green suite. The fix is small: the tests already exist in PR #15 and pass.
- **Origin:** patch. The checks and their tests are both in PR #13. The production code is correct.
- **Evidence (repo-validated by me at `e544e0f`):**
  1. Mutant C8 removes both authority samples around Establish (`reliable_submit_operational_handoff.go:205` and `:215`). The writer's whole `es/admission` suite still passes. With the mutant in, a withdrawn Service that is handed a fresh delivery writes a claim row at revision 1 (claims 0 to 1). Without the mutant it writes nothing (claims 0 to 0).
  2. Mutant M3c disables the installation comparison in `currentOperationalAdmission` and keeps the field read. The writer's whole `es/admission` suite still passes. With the mutant in, a Service commissioned for another installation gets a retained claim accepted and POSTed. Removing the comparison outright (M3b) is noticed only by the syntactic access inventory.
  3. Mutant PAssign leaves the run-assignment writer unguarded. The writer's whole `es/admission` suite still passes. With the mutant in, a Service with no authority performs the run assignment on a retained claim (revision 1 to 2, write disposition 13). The release check still withholds the run from the caller, so the write is durable but silent.
- **Impact:** none today. A later change could drop any of the three checks with a green suite. Without the Establish samples, a withdrawn Service would still write a sealed original and occupy the caller's submit key. Without the assignment guard, a denied retry would still advance the claim. In both cases the later cuts would still refuse a stage or POST. Without the installation comparison there is no later cut: the job is sent.
- **Required correction:** take the tests from PR #15. `TestRedTeamPR13HoldsNoNewClaimAfterWithdrawal` fails under C8 and under removal of the later sample alone. In `TestRedTeamPR13HoldsDenialMatrixAcrossCrashPoints`, the "authority commissioned for another installation" case fails under M3b and M3c, and the "assign rolled back" crash point fails under PAssign.
- **Inference:** removing only the later Establish sample also passes the writer's suite. I did not run that mutant against the whole suite. It follows from C8, which removes more and passes.

### RT-2. Verifier rotation and realm mismatch are reported as Integrity, not Unavailable

- **Type / severity:** contract clarity, report-only. **Low.**
- **Origin:** verifier rotation: patch (the qualifier is new). Realm mismatch: pre-existing, because the realm with its epoch is sealed into the original by code that dates from `8058561` (`es/admission/reliable_submit_operational_format.go:64-65`).
- **Evidence:** a Service whose verifier key was rotated, under the same or a new key id, returns kind Unavailable with reason Integrity (8) and no run. A domain for another epoch or installation does the same.
- **Impact:** no effect is gained. An operator or caller sees "integrity", which suggests damaged data, when the cause is a changed authority. The contract line "An unavailable or denied current authority ... returns value-free `OperationalUnavailable`" reads the other way.
- **Unknown:** whether any future caller will treat Integrity as permanent and Unavailable as retryable. There is no production caller to check.
- **Required correction:** decide the intended reason for a rotated verifier and say it in the contract. No code change is required for safety.

### RT-3. Recovery, and any stamped claim, return the run under a denying or absent authority

- **Type / severity:** contract drift between one sentence and the behaviour. **Low.**
- **Origin:** the code path is pre-existing. `reliable_submit_operational_handoff.go:340` (`if !advance || stamp != [32]byte{} { return out }`) is unchanged from `8058561`. The sentence that over-reads is in the PR #13 contract text.
- **Evidence:** at a committed intent, a handoff under a denying authority returns Unavailable with no run. Recovery on the same claim returns Pending with the run id, under a denying authority and under a Service with no authority at all. A stamped but unmarked claim returns Pending with the run id on handoff too. Historical v1 originals are withheld on both paths (`:285`, `:337`), so v2 and v1 differ here.
- **Impact:** no write and no sender is gained. The run id goes only to the authenticated original caller with the original key, since another caller is refused (A3). In the reply-lost crash points that caller has not seen the run id before, so "without ... disclosing the claim" is not true for the recovery entry.
- **Required correction:** either withhold the run on these paths for v2 as for v1, or narrow the sentence to the handoff entry before the stamp.

### RT-4. A withdrawal is a sampled flag, not a barrier

- **Type / severity:** design caveat. **Low.**
- **Origin:** patch design. Partly documented: "No Service lock spans transport", and "already-entered I/O cannot be retracted".
- **Evidence:** deterministic demonstration `TestRTExpWithdrawBeforeAnyTransportByte` (in the PoC folder). `withdrawOperationalEffects()` returned true while 0 POSTs had been sent. The POST was then sent and accepted, and the claim reached revision 6. The window is between the final sample at `reliable_submit_operational_handoff.go:624` and the transport write.
- **Impact:** a caller of withdraw cannot conclude "no further effect" from its return. One in-flight handoff per claim can still POST. This matters for the documented epoch change, which says to withdraw old processes first.
- **Required correction:** one contract sentence that withdrawal returning is not a drain, or a drain step before an epoch is declared closed. I found no stated promise that the current behaviour breaks.

### RT-5. A denial between staging and the stamp strands the claim for good

- **Type / severity:** observation.
- **Origin:** the consequence is pre-existing PR #12 design (no stage reattachment). The patch adds one more way to reach it.
- **Evidence:** `TestRTExpStampCutWithdrawalPoisons`. A withdrawal observed at the stamp cut left revision 3 with one stage entry. Two later retries under an allowing authority returned Pending with reason Occupied (6) and nothing advanced.
- **Impact:** "a denial does not poison the claim" is true for the cuts before staging, which is what the sentence is attached to. It is not true after staging. The contract does say that denial after staging "may leave inert charged residue".
- **Required correction:** none for safety. Consider saying plainly that such a claim needs a new submit key.

### RT-6. The in-model policy change is a new epoch, and a new epoch cannot read old claims

- **Type / severity:** observation on scope and test naming.
- **Origin:** pre-existing PR #12 behaviour.
- **Evidence:** the contract says trust, verifier or policy replacement "requires a new qualified epoch" (line 313) and lists unapproved policy changes as a violated premise (lines 54-56). Originals bind the epoch, so a domain for the new epoch refuses old claims and old accepted receipts with Integrity (`TestRTExpEpochRollover`, A2). The writer's `TestPR12RetryAfterPolicyChange` tests change policy inside one epoch, which is the out-of-model case.
- **Inference:** the realistic trigger the re-check protects against is a restart that picks up a changed trust policy, for example a new EGS revocation, without an epoch bump. The re-check does cover that (A1). What would confirm it: a decision from David on whether a revocation is meant to force a new epoch.
- **Impact:** none on safety. Reading old receipts after an epoch change needs a domain for the old epoch, which the contract says.

### RT-7. Qualifier work inside the SQLite writer is bounded

- **Type / severity:** observation.
- **Evidence:** `TestRTExpQualifyCostBomb`. A payload of about 15.5 KB of gzip that decodes to 15 MiB took about 4 to 6 ms per extraction over three runs. One accepted handoff ran 11 policy evaluations. I found no input that makes the in-writer work unbounded.

### RT-8. Retained evidence is malleable in value, not in meaning

- **Type / severity:** observation.
- **Origin:** pre-existing evidence contract (`internal/contracts/evidence/v1`), which compares trimmed seal fields and signs whitespace-normalized claims.
- **Evidence:** records with a padded `seal.algorithm`, `seal.signature`, `seal.content_digest` or `intent_digest` still qualify (A7). Their signed canonical claims are identical.
- **Impact:** none found. The record sits inside the sealed original, and any change to the sealed bytes is refused first (A6). The contract's "noncanonical spellings" covers JSON syntax, not padded values.

### RT-9. What "current admission" means here

- **Type / severity:** scope caveat. **Inference from code**, not a defect.
- The re-check uses the trust model, verifier and built-in policy that the Service was commissioned with, applied to the evidence retained at establish time. It does not ask ARS or EGS again, so an artifact removed or re-issued in ARS after establish, or a changed workload-zone or runtime-profile configuration, is not noticed at a cut. The contract says no resolver or ARS/EGS read runs in the callback. A new EGS revocation is noticed only by a Service commissioned after it.

## 8. Regression tests delivered

Draft PR #15, head `5ca4079`, file `es/admission/reliable_submit_operational_admission_redteam_test.go` (759 lines, SHA-256 `10e705ab457455c1dcf8405b208b5b1ffed339ed27aede7f3b86779b48ccca52`).

- Pass at `e544e0f`: `TestRedTeamPR13HoldsDenialMatrixAcrossCrashPoints`, `TestRedTeamPR13HoldsNoNewClaimAfterWithdrawal`, `TestRedTeamPR13HoldsCrossRealmIsolation`, `TestRedTeamPR13HoldsSubmitKeyReuseAndCallerSubstitution`, `TestRedTeamPR13HoldsConcurrentDenyingAuthorityNeverWrites`, `TestRedTeamPR13HoldsPlantedStageNameOnRetry`, `TestRedTeamPR13HoldsSealedOriginalTamperRefused`, `TestRedTeamPR13HoldsChangedEvidenceNeverQualifies`, `FuzzRedTeamPR13DecodeOperationalEvidence`, `FuzzRedTeamPR13ParsePrivateReplayDelivery`.
- Fails at `e544e0f` by design: `TestRedTeamPR13GuardAccessInventoryEscapes` (RT-1).

RT-1 got a failing regression test because it is a defect that needs a decision. RT-10 got passing tests because the production behaviour is right and only the test was missing. RT-2 to RT-9 are kept as report-only experiments in the PoC folder, since turning a design caveat into a failing test would assert a behaviour nobody has decided.

## 9. Validation: what I ran

On the final bytes (`5ca4079`), by me:

| Command | Result |
| --- | --- |
| `go test -count=1 -json ./es/admission/` | 1,420 pass, 12 fail, 3 skip. Existing tests: 1,382 pass, 0 fail, 3 skip, which equals the writer's reported result. Red-team tests: 38 pass, 12 fail. All 12 failures are `TestRedTeamPR13GuardAccessInventoryEscapes` and its 11 subtests. |
| `go test -race -count=1 -run 'TestRedTeamPR13Holds\|FuzzRedTeamPR13' ./es/admission/` | ok, 67.8 s |
| `gofmt -l es/admission/` | clean |
| `go vet ./es/admission/` | one finding, pre-existing and not in my file: `es/admission/result_auth_test.go:395` copies a lock value (file last changed in PR #8) |
| `go test -count=1 -v -run 'TestRTExp' ./es/admission/` with the PoC experiments copied in | ok, log in the PoC folder |
| `reproduce-tests.sh` and `reproduce-guard-mutant.sh` | both ran to the expected result, exit 0 |
| Provenance recipe v2, twice, fresh clone | manifest reproduced (section 2) |

Run on earlier bytes and not repeated:

- Mutation runs 1 and 2 used production code at `e544e0f` and my test file as of `ef83f33`. The only later change to my file is the added test for the Establish samples, which I checked separately against C8 and its two halves. Run 3 used the final file.
- The two fuzz targets with `-fuzztime 150s` each. Logs kept.
- The custody leaf grammar test (A9). The test package `es/admission/internal/reliablesubmit` does not compile on Linux at `e544e0f`. That is already known and is fixed on the CI branch (draft PR #14). I ran A9 in scratch with that branch's `replay_custody_file_test.go` laid over the tree, so A9 is evidence about the production custody code, on a tree that is not exactly `e544e0f`.

## 10. Coverage the environment could not provide

- **No production commissioning caller exists.** Every Service in these tests is a proof Service built by test helpers. Nothing here shows how a real ES process would commission, withdraw or change epoch.
- No Docker, Nomad, systemd, SPIRE or Vault. The provider was the in-process test provider. Real transport timing, real TLS and a real Nomad register were not exercised.
- No macOS run. The disposable Linux box was not used, because the handoff is not wired into any running service, so the box would have added nothing the container did not give.
- Crash and restart were simulated with the repository's commit-fault hooks and a reopened domain, not by killing a process.
- I did not run the repository root package as a whole, or packages outside `es/admission`. The root v2 contract tests were run once against the RT-1 mutant.
- Fuzzing was time-boxed. **Guess:** the evidence decoder fuzzer mostly exercised refusal paths, because its seeds did not include a complete valid signed record. A7 covers the valid-record neighbourhood instead. A longer fuzz run seeded with a valid record would confirm or refute the guess.
- The mutation runs cover the qualifier and its call sites. They do not cover the custody package's own checks or the built-in policy evaluators.
- Reflection, `unsafe` and generics as ways around the guard were not explored (RT-1 uncertainty).

## 11. Sensitive material

No secrets, keys, tokens, environment files, SQLite state from a real host, or TLS, SPIFFE or Vault material were read or written. All keys in the tests are generated by the test fixtures at run time. The PoC logs contain only synthetic run ids from those fixtures.

## 12. Confidence

- **Provenance: high.** Manifest reproduced from the pushed commit.
- **Validation: high for `es/admission` on Linux, none for other platforms and packages.** I re-ran the writer's `es/admission` result and got the same counts.
- **That the production re-check holds: moderate to high within the model tested.** Every attack I could build failed, and the mutation runs show that the writer's tests together with the PR #15 tests notice a removed check in the qualifier and at every cut. The limit is section 10: no real commissioning caller, no real provider, simulated crashes.
- **That RT-1 and RT-10 are real: high.** Each was reproduced with a production mutant, and RT-1 with a control.

## 13. How to reproduce

Two scripts are in the PoC folder. Each works in a throwaway copy of the repository, changes nothing in your checkout, commits and pushes nothing, and cleans up after itself. Both were tested by me in the Linux container only. They need `git`, Go and network access.

```bash
bash reproduce-tests.sh /path/to/Execution-Substrate          # about 2 minutes
bash reproduce-guard-mutant.sh /path/to/Execution-Substrate   # about 5 minutes
```

`reproduce-tests.sh` runs the PR #15 tests and the report-only experiments. `reproduce-guard-mutant.sh` applies the RT-1 mutant, shows the suite passing with it, then shows the control being rejected.

PoC folder: `/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/03-red-team-poc/`

| File | What it is |
| --- | --- |
| `reproduce-tests.sh`, `reproduce-guard-mutant.sh` | the two scripts above |
| `mutant-anonymous-struct-conversion.diff` | RT-1 production mutant that passes everything |
| `mutant-named-field-control.diff` | RT-1 control that the guard rejects |
| `mutant-named-shadow-struct.diff` | named-type variant that is caught by a different test |
| `experiments_test.go.txt`, `experiments.log` | report-only experiments for RT-2 to RT-7 and their output on the final bytes |
| `custody_v2_leaf_mutation_test.go.txt` | A9 test source |
| `fuzz-decode-tail.log`, `fuzz-parse-tail.log` | last lines of the two fuzz runs |
| `mutation-run.txt` | raw result lines of the mutation runs in section 6 |

## 14. Effect status

- Pushed: `claude/project-thread-uijb9o` at `5ca4079` (my branch only).
- Opened: draft PR #15 to `claude/project-thread-sqldt7`. Not merged. Not marked ready.
- Not done: any change to PR #13, any repair, any merge, any deployment, any live-service contact.

## 15. Report delivery

Path: `/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/03-red-team.md`. Its SHA-256 is given in the delivering thread reply.

**Final verdict: HOLDS WITH CAVEATS.**
