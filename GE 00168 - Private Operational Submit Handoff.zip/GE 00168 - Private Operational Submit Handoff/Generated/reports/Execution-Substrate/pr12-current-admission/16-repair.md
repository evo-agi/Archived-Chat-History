# CORRECTION AFTER THE SIXTH AUDIT OF PR #12 + #13: line directives no longer move a site of any guard (A6-1, A6-2)

Status of this file: **IMPLEMENTATION REPORT, NOT AUDITED.** It covers two commits after `8e1f539`. `15-audit.md` is the audit that asked for them (BLOCK on A6-1), and `14-repair.md` stays the report of everything up to `8e1f539`.

Written by the PR #13 writer thread (the Opus continuation) on 2026-11-23 (UTC). Readers: the coordinator, David, and the auditor of `15-audit.md`, who does the narrow re-audit of this delta.

---

## 1. In plain words

The sixth audit found that the new raw pointer rule could be fooled with one comment. Go has a `//line` comment (and an inline `/*line*/` form) that tells tools "the code below belongs to another file and line". The rule asked Go's position table where each raw pointer value was, and that table follows such comments. So a file without the `unsafe` import could put `//line <a sibling file that imports unsafe>:1` above a raw pointer road, and the rule counted the road as part of the sibling and accepted it. The auditor measured this on the macOS build of `es/admission` and the Linux build of `es/runtimehelper`.

What I changed, all in guard tests and documents:

1. **Every guard reads real positions now (R1).** One helper, `guardPosition`, reads a position without applying line directives, and every guard of the module reads positions through it: the raw pointer rule and the 18 other calls in three guard files that read a position (section 4.1).
2. **A test enforces that.** It reads every test file of the module and refuses a call that reads a position the adjusted way (`Position`, `File.Line`, `PositionFor` with anything but `false`, also as method values and method expressions). The only exemption is the one small function that compares the adjusted and the real position on purpose, and a test shows the exemption is needed and that a read planted anywhere else is refused.
3. **Production files may hold no line directive at all.** A test reads every non-test Go file of the repository, whatever build target compiles it, and refuses a `//line` or `/*line` comment, and also any position that a directive moved, whatever its spelling. None exists today, and none is needed: no production file is generated from another source.
4. **The auditor's three subtests (R2)**, for both siblings: a road beside a file that imports `unsafe` (the darwin build of `es/admission` beside `execution_roots_darwin.go`, the Linux build of `es/runtimehelper` beside `privilege_linux.go`) with no directive, with a `//line` and a `/*line` directive naming the sibling, and with a `//line` directive naming no file of the package. Each is refused, and each directive subtest checks that the directive really moved the adjusted positions. A further subtest makes sure a site in no file of the package is refused, not dropped (it kills the auditor's surviving mutant B4).
5. **A directive moves no site of any inventory.** A new test type-checks every production package of the three build targets again with a `/*line` directive in every file and shows that the raw pointer sites and all 227,655 typed references are the same as without it.
6. **The documents (R3)** now say that the rule judges the file that holds each value by its real position, that the guards read positions that way, that production files hold no directive, and (O6-1) that the rule reads the static types of the source. Each phrase is pinned with a missing and a wrong-statement case.

While doing R1 I found **one more guard that a directive could fool**, and measured it: Workstream A's source-term guard picks the source line for its allow rule by the adjusted line. At `8e1f539`, a forbidden `PolicyDecision` identifier in `policy.go` passes that guard when a `//line policy.go:56` comment above it points at the allowed line `type AdmissionPolicyDecision struct {`, and fails without the comment. It is pre-existing (the guard is older than PR #12), and it is closed by the same change. By reading, the binding producer guard of PR #12 had the same weakness (a helper below `//line <allowed file>:1` would have counted as defined in an allowed file); not probed, closed the same way. Fixing it touches one more test file, so **the path ceiling of PR #12 plus its repairs goes from 52 to 53 files**, with an owner reconciliation paragraph that names the file, pinned like the earlier ones.

Nothing changes behaviour, stored formats or public contracts. No production file changed.

## 2. Identity

| Field | Value |
| --- | --- |
| Objective | Correct A6-1 and A6-2 of `15-audit.md` (R1 to R3), with the optional O6-1 subtests and sentence |
| Repository | `evo-agi/Execution-Substrate` |
| Base ref and SHA | `codex/reliable-submit-operational-handoff-v1` at `8058561edc08356c46680c204586b3c7796c0ff3` (the PR #12 branch) |
| Previous tip | `8e1f539613b85511b537e52b376aad88ab4af643` (audited in `15-audit.md`: BLOCK on A6-1); last accepted tip `bff8dda37dbf5484afb3b264d4eca38cf6abf118` |
| Topic branch | `claude/project-thread-sqldt7` (draft PR #13) |
| Topic commit SHA | `d314590dad6f6e132a20c62e9fff671311e286fe` |
| Tree SHA | `d9ec2b9ddca1fcdbaadf706d74a0e32ac8463b95` |
| Commits after `8e1f539` | `ce8760b` Read real positions in every guard and refuse line directives; `d314590` Say that the raw pointer rule judges the file that holds each value |
| Scope | 33 paths against the base (32 before), 53 against the trunk merge base `ae326b0` (52 before); the new path is `es/admission/workstream_a_guardrails_test.go` |
| `trunk_dev` | `df46164` (PR #24) throughout; fetched again before the trial merge and before the manifests |
| Toolchain | Go 1.26.5 (`GOTOOLCHAIN=local`), linux/amd64 container, runs as an unprivileged user `ci` with an emptied environment |
| Recipe | `governed_execution_audit_patch_manifest_v2.py`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified before every run |

## 3. The audit's corrections and where each is

| Audit item | What it asked | Where it is now |
| --- | --- | --- |
| **R1** (A6-1) | Attribute each raw pointer site to the file that holds it: unadjusted position or the token's file | `guardPosition(fset, pos)` = `fset.PositionFor(pos, false)` in `operationalGuardRawPointerSites`, and in every other place a guard reads a position (section 4.1) |
| **R2 (a)** (A6-2, mutant A1) | A road in a package with a sibling file that imports `unsafe` | Subtests `refused: es/admission beside execution_roots_darwin.go, no directive` (darwin/arm64 view, road R14-2) and `refused: es/runtimehelper beside privilege_linux.go, no directive` (linux/amd64 view, road R14-1). Each first checks, from the parsed files of that view, that the sibling really imports `unsafe` |
| **R2 (b)** | The same road below a `//line` directive naming the sibling | `... a //line directive naming the sibling` and `... a /*line directive naming the sibling`, both packages. Each also checks that the directive did move the adjusted positions of the file (so the subtest is about the directive, not an ignored comment) and that the production directive check refuses the file |
| **R2 (c)** (mutant B4) | A `//line` directive naming a file that does not exist | `... a //line directive naming no file of the package`, both packages. With real positions B4's branch is never reached by a directive, so a further subtest, `a site in no file of the package is refused`, takes the file out of the package's list and requires the refusal "is in no file of"; it kills B4 |
| **R2, recommended** | Refuse `//line` and `/*line` in every production file | `TestOperationalGuardProductionFilesHoldNoLineDirective` (section 4.2) |
| **R3** | Keep the owner document true, add the phrase, pin it with a wrong-statement case | Section 4.4 |
| **O6-1, optional** | G1 and G3 as subtests, one sentence on static types | Subtests `a raw pointer held through an inferred type parameter is not a raw type of the source` (G1: the rule passes it, and the subtest fails if the rule starts reading instances, so the documents must follow) and `an inferred type parameter does not convert to a pointer` (G3: the type checker refuses it with "cannot convert"); the sentence is in the owner document |
| Coordinator: "a test that //line directives can't redirect any other guard check" | — | `TestOperationalGuardReadsUnadjustedPositions` (every position read of every test file) and `TestOperationalGuardLineDirectivesMoveNoInventorySite` (whole inventories under a directive), section 4.3; plus the measured Workstream A case, section 6.1 |

## 4. What changed

| File | Added | Removed | Commit |
| --- | --- | --- | --- |
| `es/admission/workstream_c_guardrails_test.go` | 584 | 10 | `ce8760b` |
| `es/admission/reliable_submit_guardrails_test.go` | 2 | 2 | `ce8760b` |
| `es/admission/workstream_a_guardrails_test.go` (new path for this PR) | 4 | 4 | `ce8760b` |
| `.docs/execution_lifecycle/reliable_submit_operational_handoff.md` | 19 | 3 | `d314590` |
| `PLANS.md` | 23 | 3 | `d314590` |
| `docs_contract_test.go` | 32 | 4 | `d314590` |

### 4.1 Real positions everywhere (R1)

`guardPosition` is the only way a guard reads a position. At `8e1f539` the three guard files read positions the adjusted way in 19 calls; all 19 now go through `guardPosition`. What each did with the position, and so what a directive could have done:

| Where (at `8e1f539`) | What the position decides | Could a directive redirect it? |
| --- | --- | --- |
| `workstream_c_guardrails_test.go:4526`, raw pointer rule | The file whose `unsafe` import is checked | Yes: A6-1, measured by the auditor |
| `workstream_a_guardrails_test.go:419,422,440,443`, source-term guard | The source line that the allow rule reads | **Yes, measured here** (section 6.1): pre-existing |
| `reliable_submit_guardrails_test.go:221`, binding producer guard | Whether a called helper is defined in an allowed file | Yes, by reading (a helper below `//line <allowed file>:1` would count as allowed); not probed |
| `workstream_c_guardrails_test.go:6767,7067,7330`, typed references | File, line and column of each reference: keys of the exact inventories (for example `site@file:line:col` at :6334, and :6921, :7202) and one file comparison (:3201) | Yes, by reading: keys would move with the directive; the inventory test of section 4.3 shows they no longer do |
| `workstream_c_guardrails_test.go:8391`, `trancheB1SemanticOccurrence` | Line and column in an occurrence key (the site name comes from the real file name) | Keys would move; same as above |
| `workstream_c_guardrails_test.go:1583,6273,8743` | Text of error messages; the type-error file name | Messages only |
| `workstream_c_guardrails_test.go:1557` (2), `:3989` (2), `reliable_submit_guardrails_test.go:2022` (2) | `.Offset` only, to cut source text | No: a directive never changes an offset. Changed for one rule without exceptions |

### 4.2 No line directive in production files

`TestOperationalGuardProductionFilesHoldNoLineDirective` reads every non-test Go file of the repository (the same listing as the import inventory: every directory except `.git`, every build tag) and refuses:

- a comment that starts with `//line ` or `/*line ` (or the same with a tab), in any column. This is stricter than the go command, which honours `//line` only at the start of a line and only with a position; a comment that merely looks like a directive is refused too.
- any node whose adjusted position differs from its real one, whatever comment moved it. This second check holds a form the name check would miss.

Subtests: ten refused forms (at the start of a line, without a file name, naming the file itself, inside a function, after code, `/*line` inline and at the start of a line, `/*line` without a position, a tab, the last line of a file), five accepted controls (`// line of text`, `//lines`, a directive inside a string and a raw string, `//go:build` and `//go:noinline`), and `a moved position is refused by itself`, which runs the check with the name check switched off: honoured directives are still refused, and a comment that only looks like a directive (after code, or `/*line` without a position) is not, so each check is needed (mutants N4, N5, N7).

### 4.3 No guard can read an adjusted position

`TestOperationalGuardReadsUnadjustedPositions` parses every `_test.go` file of the module (146 today) and refuses, by syntax:

- any selector named `Position`, called or taken as a value or method expression (`token.FileSet.Position` and `token.File.Position` apply directives); the type name `token.Position` is allowed;
- any call of a selector named `Line` (`token.File.Line` applies directives);
- any selector named `PositionFor` other than a call with two arguments whose second is the identifier `false`.

The one exemption is the body of `operationalGuardMovedPosition`, the function that compares the adjusted and the real position on purpose. Subtests: twelve refused forms, five accepted ones, `the exemption is needed` (the guard file is refused without it), and `refused: a read planted in ...` for the guard file outside the exempted function and two other test files. The check is syntactic; a method value of `File.Line` looks like the field `Line` of a `token.Position` and is not refused (section 5).

`TestOperationalGuardLineDirectivesMoveNoInventorySite` type-checks every production package of the three build targets (126 package views) a second time, with ` /*line zz_elsewhere.go:9000:1*/` after the package name of every file, on the same line, so every later adjusted position names another file and line while real lines and columns stay. It requires that the directive moved positions in every file with declarations, and that the raw pointer sites and the typed references to every object (227,655) are identical with and without it.

### 4.4 Documents (R3)

- Owner document, the paragraph of the raw pointer rule (after "does not import `unsafe` fails it."): the rule judges the file that holds each such value by the value's real position, not by the file and line that a `//line` or `/*line` directive names; every guard reads positions that way and a test refuses the calls that read an adjusted position in the test files; another test refuses such a directive in every non-test Go file of the repository; the rule reads the static types of the source, and a type parameter that inference sets to `unsafe.Pointer` cannot become a typed pointer without a constraint that spells the type, which the rule sees (O6-1).
- Owner document, section 9 (path map): a reconciliation paragraph for the one new path, `A/workstream_a_guardrails_test.go`, raising the aggregate HEAD ceiling from 52 to 53 files. The previous paragraph now says "was 52 files".
- `PLANS.md`: a new entry "PR #12 durable admission: line directives after the sixth audit (2026-11-23)"; the previous entry's "is 52 files" became "became 52 files".
- `docs_contract_test.go`: seven owner phrases and five plan phrases pinned; seven missing-phrase cases and seven wrong-statement cases (placed by a directive, adjusted reads allowed, directives allowed, instances read, a type parameter converts, the ceiling not raised to 53, the new path unnamed).

The sentences the auditor quoted (owner `:618-619`, `:812-818`, `PLANS.md:19-20`) are unchanged and true with the correction.

## 5. Limits that remain (stated, not hidden)

1. **The position-read check is syntactic.** A method value of `token.File.Line` cannot be told from the field `Line` of a `token.Position` without types, so it is not refused. The production directive check is the backstop: with no directive in any production file, an adjusted read returns the real position anyway. Both are machine checks.
2. **The production directive check covers the module's own files.** Dependencies may hold directives (generated code often does); their positions never enter a guard, which reads only production files of this module. Inference, from what the loaders read.
3. **O6-1 stays as the auditor measured it:** a raw pointer can be held in a file without the import through an inferred type parameter (G1, G2) but not converted (G3, G4). The documents now say the rule reads static types; a subtest fails if the rule starts reading instances, so the documents and the subtest move together.
4. **No CI run, no macOS run** of this delta. The darwin view is type-checked from Linux, as the guard always does.

## 6. Validation

All runs are on Linux (linux/amd64 container), Go 1.26.5, as the unprivileged user `ci` with an emptied environment (`scripts/cirun.sh.txt`), on fresh clones of the commits. The store package needs the uncommitted Linux overlay of one test file to compile on this branch, as in every earlier report (`trunk_dev` already holds the fix); it was applied to the test clones of `8e1f539` and the new head, never to the manifest clone. The mutants, the auditor's probes, the full suite, vet, build, race and the first trial merge ran on `0939bf6`, an earlier local version of the second commit (parent `ce8760b`, never pushed). I then amended that commit to add the path ceiling of section 4.4, which changed only the owner document, `PLANS.md` and `docs_contract_test.go`; every other file of the final head is byte-identical to `0939bf6`. The root package, the docs pins against the old documents, vet of the root package and a second trial merge ran again on the final head, and so did the Workstream A probe. Logs are in `16-repair-evidence/runs/` and `16-repair-evidence/probes/`.

### 6.1 Failing first, passing after

| What | At `8e1f539` (old) | At the new head |
| --- | --- | --- |
| The auditor's probes (`zz_line_darwin.go` in `es/admission`, `zz_line_linux.go` in `es/runtimehelper`, checksums equal to `15-audit-evidence/SHA256SUMS`) | The four guard tests pass, 169 results: the guard is blind (`probe-guard-old.log`) | The raw pointer rule refuses `zz_line_darwin.go` in darwin/arm64 and `zz_line_linux.go` in linux/amd64 and linux/arm64; the production directive check refuses both directives and both moved positions; the other five guard tests pass (`probe-guard-new.log`) |
| The same files without their `//line` lines (control) | Refused (auditor's `a6-guard-control.log`) | The raw pointer rule refuses the same files in the same views; the directive check passes (`probe-guard-control.log`) |
| Build with the probes, three targets | Clean (auditor) | Clean: the probes compile, so the refusals come from the guard (`probe-build-*.log`) |
| **Workstream A source-term guard** with `//line policy.go:56` above `var zzProbePolicyDecision = 1` appended to `es/admission/policy.go` (line 56 is `type AdmissionPolicyDecision struct {`) | **Passes**: the allow rule read the line the directive named (`wsaold-dir.log`). Without the directive it fails with `policy.go:330 must not contain "PolicyDecision"` (`wsaold-ctl.log`) | Fails with `policy.go:331 must not contain "PolicyDecision"`, the real line; the directive check refuses the file too (`wsanew-dir.log`) |
| The old rule's behaviour as mutants of the new guard | — | N1 (`guardPosition` reads adjusted positions) and N2 (only the raw pointer rule reads adjusted positions, as at `8e1f539`): the six sibling subtests with a directive fail, and so do the inventory test and the position-read test (section 6.2) |
| The new docs pins against the documents of `8e1f539` | 16 subtests and their 2 parent tests fail (`runs/docs-red-head.log`) | Pass |

### 6.2 Mutation

16 mutants (`mutants/mutants16.py.txt`, log `mutants/mutants16.log`), each run against every `TestOperationalGuard*` test and the RT2-1 test (328 results, all passing, without a mutant: `mutants/baseline-unmutated.json`): **16 of 16 caught.**

| Mutant | Failing results |
| --- | --- |
| N1 `guardPosition` reads adjusted positions | 11: the six directive subtests, the inventory test, the directive check's position subtest, the position-read test (its own body is now a refused read), and parents |
| N2 the raw pointer rule reads adjusted positions (the rule at `8e1f539`) | 9: the six directive subtests, the inventory test, the position-read test, and the parent |
| A1 (auditor) the `unsafe` import checked per package | 9: all eight sibling subtests (with and without a directive) and their parent test |
| B4 (auditor) a site in no file of the package dropped | 2: `a site in no file of the package is refused` |
| N3 no comment is named a directive | 4 |
| N4 the production check ignores comments named a directive | 5 |
| N5 the production check ignores moved positions | 2: `a moved position is refused by itself` |
| N6 no position is ever found moved | 10 |
| N7 `/*line` comments not named directives | 2: `/*line with no position` |
| N8 the position-read check replaces the whole guard file | 2: the planted read in the guard file |
| N9 the position-read check accepts `Position` | 9 |
| N10 `PositionFor` accepted with any second argument | 6 |
| N11 `Position` skipped on any receiver named by an identifier | 7 |
| N12 the position-read check reads only `es/admission` | 1 (fewer than 100 test files read) |
| N13 the inventory test inserts no directive | 1 |
| N14 the exemption empties every function of the guard file | 2: the planted read in the guard file |

A first run of an earlier version (`mutants/mutants16-first-run.log`) had three survivors, each fixed by a test before the final run: N7 (every refused `/*line` case was also a moved position, so the name check for `/*line` was untested; the case `/*line with no position` added), N8 (the exemption could replace the whole guard file; planted reads added, and the exemption moved into `validateGuardPositionReadsOfModule`), and N9, which was a wrong mutant in that run (it kept one error instead of none); the corrected N9 is caught. N14 was added with the planted reads.

### 6.3 Full suite, old against new

`go test -count=1 -json ./...` once at `8e1f539` and once at `0939bf6` (`runs/base-full.*`, `runs/new-full.*`, comparison `runs/compare-8e1f539-vs-0939bf6.txt`):

| | Results | Pass | Fail | Skip |
| --- | --- | --- | --- | --- |
| `8e1f539` | 7,018 | 6,846 | 131 | 41 |
| `0939bf6` | 7,079 | 6,907 | 131 | 41 |

- **No test that exists in both runs changed its result.** The 131 failures are the same set at both commits: 30 top-level tests with their subtests. 29 are the known environment failures of every earlier report (26 in the root package, the three probe-binary store tests). The 30th is new to this container since `14-repair.md`: `es/app` `TestLinuxSetupGoToolchainInstallerHermeticPreflightAndCleanup` and 13 subtests fail at both commits here (the operator script's fake harness stops after `uname`), while they passed in the run of `14-repair.md` at the same commit `8e1f539`. The test file is untouched by PR #12 and #13. Inference, not diagnosed: something in this container changed between the two runs.
- 85 new names, all pass: 61 new guard subtests and docs pins, and 24 rounds of the adopted SIGKILL test, whose names carry a random delay (the 24 gone names are the same test's rounds of the old run).
- **The final head**: its root package ran again after the path-ceiling change of the documents (`runs/head-root.summary.txt`): 2,328 pass, 114 fail, the same 26 known top-level tests as at `8e1f539`; all new docs pins pass. Every other file of the final head is byte-identical to `0939bf6` (`runs/run16.log` lists the three changed paths), so the other packages' results stand.

### 6.4 Build, vet, race, trial merge

- `go build ./...` with `CGO_ENABLED=0` for darwin/arm64, linux/amd64 and linux/arm64: clean at both commits, and with the auditor's probes in place.
- `go vet ./...` for the same three targets: one finding at both commits, the same as in every earlier report: `es/admission/result_auth_test.go:395:15: assignment copies lock value`. The file is untouched by this PR; `trunk_dev` fixed it in PR #14. `go vet .` of the final head's root package (whose test file changed last) for the three targets: clean.
- `gofmt -l es/admission docs_contract_test.go`: clean at `0939bf6` and at the final head. (Two files of `es/runtimehelper` are unformatted at both commits and untouched.)
- Race detector (`CGO_ENABLED=1 go test -race`): the adopted tests and the four new or changed guard tests in `es/admission` pass in 159 s, and `es/admission/internal/admissionstate` passes; no data race reported.
- **Trial merges** of `trunk_dev` `df46164` (fetched again just before) into `0939bf6` and into the final head, in scratch clones, never pushed. Both conflict in one file, `docs_contract_test.go`, the adjacency conflict that `bff8dda`, `51d6d5f` and `8e1f539` have too (PR #12's block of operational handoff tests and PR #19's `TestARSStorageCheckDocsContract` were appended after the same function). Resolved by keeping both blocks with one blank line between them; the combined diff of the final head's merge adds only that blank line (`runs/trialhead-resolution-cc.diff`). `workstream_a_guardrails_test.go` and every other file merged without conflict. On the merge of `0939bf6`:
  - `go build ./...`, `go vet ./...` and `GOOS=darwin GOARCH=arm64 go vet ./...` (the CI's three steps): clean.
  - `es/admission`: 2,462 pass, 13 skip, 0 fail. The new guard tests pass on `trunk_dev`'s code as well, so `trunk_dev` brings no line directive into a production file and no adjusted position read into a test file. The 13 skips are the same as in `14-repair.md`: eleven tests and one subtest of `trunk_dev` that skip themselves here (stress tests the CI list names, and tests that need `bindfs` or a supplementary group), and `TestOperationalHandoffChildProcess`, which `13-ci-list-two-lines.patch` lists.
  - The root package: 2,328 pass, 113 fail, 25 of the known top-level tests; `es/admission/internal/...`: 819 pass, 3 fail (the probe-binary store tests), 2 skip; `es/runtimehelper`: 81 pass.
  - On the merge of the final head, the root package again: 2,332 pass, 113 fail, the same 25 known top-level tests, and all 208 results of the operational handoff docs tests and PR #19's docs test pass (`runs/trialhead-root.summary.txt`).
- No new test skips itself on any host, so the CI list still needs only the two lines of `13-ci-list-two-lines.patch`.

## 7. Provenance manifests

Taken after the push by `scripts/prov16.sh.txt` (the script of `14-repair.md` with the previous tip set to `8e1f539`), on a clean working tree at the final head. The recipe's SHA-256 was checked before every run. Each manifest was written twice into a fresh mode-0700 directory outside the repository, and the two files are byte-identical. For each, `git add -A` with the index reset to its base staged exactly the manifest's paths, and `git write-tree` gave the tree of the commit, `d9ec2b9ddca1fcdbaadf706d74a0e32ac8463b95`, every time. Afterwards: head `d314590`, status empty, upstream `origin/claude/project-thread-sqldt7` restored. The remote branch is at `d314590dad6f6e132a20c62e9fff671311e286fe`. `trunk_dev` was fetched just before: `df461642d2f7c9481873ca74b7eaaba368feb12f`.

| Manifest | Base (index reset to) | Upstream pinned to | Files | Manifest SHA-256 | Textual diff SHA-256 |
| --- | --- | --- | --- | --- | --- |
| Base-relative | `8058561` | `origin/codex/reliable-submit-operational-handoff-v1` | 33 | `0e65b61e4a0ecc6752f2b1c79cfbc340d231012f14727ab7831cf2d1c0eb1096` | `b41a7716737dd8c7d262de58bae614b206901876fc7bb27ec98229bfec933b0e` |
| Delta against the previous tip | `8e1f539` | `origin/claude/project-thread-sqldt7` | 6 | `015d2c6fc1681d4c4fab6628043a4b11e40a2bb2b4891a530821bbd2f8507a4a` | `023d6496f5857b62a09dbbde5617ba0959d82f88bf1ca076417e67d9cef9ccfd` |
| Delta against the last accepted tip | `bff8dda` | `origin/claude/project-thread-sqldt7` | 11 | `86dc961d9eea69ce5a7e6af232db4bdb04ab341e3087ef9fc9b6d18b262ac43b` | `85d5aad1f127822014c4bf8997c0b777dd6b7d82c9ebc2152d26723d51955c5b` |
| Trunk-relative | merge base `ae326b0` of the tip and `trunk_dev` (`df46164`) | `origin/trunk_dev` | 53 | `ab665c1892440d15ac36932146c03f975eac8c3dcf57a67298243256694593d9` | `14d20102286cf14c791953851f2f9b5cb26349a5cae6eab79d7dc782a359bf51` |

## 8. What the narrow re-audit should check

1. That every guard reads real positions (section 4.1), that the position-read test would refuse a new adjusted read (section 4.3), and whether a way to read an adjusted position exists that neither the syntax check nor the production directive check holds.
2. That the production directive check reads every file the build views can compile (it uses the import inventory's listing), and that no form of directive that the go command or `go/parser` honours passes both its checks.
3. That the auditor's three subtests are the ones asked for (R2 a to c), in both packages, and that the probes of `15-audit-evidence/probes/` are refused (section 6.1).
4. The Workstream A finding (section 6.1) and the reading of the binding producer guard (section 4.1): whether the classification of each of the 19 reads is right.
5. The owner document's new sentences, the reconciliation paragraph for the 53rd path, and their pins.
6. The merge gate must name the new head `d314590dad6f6e132a20c62e9fff671311e286fe` and tree `d9ec2b9ddca1fcdbaadf706d74a0e32ac8463b95`.
7. When PR #12 takes `trunk_dev`: the adjacency conflict in `docs_contract_test.go` (keep both blocks) and the two lines of `13-ci-list-two-lines.patch`, unchanged.

## 9. Open points for the Fable red-team (not in this batch)

Unchanged from `14-repair.md` section 10, plus A6-1 as a target: R14-1 to R14-5; whether any road hands out a raw pointer that the rule misses; A-30 (in-place change of `*s.trustModel`), MU6 (the second identity check of the staging root), double crash and crash during a WAL checkpoint, longer fuzzing and a fuzz target over the durable record codec.

## 10. Effects

- Pushed: `claude/project-thread-sqldt7`, fast-forward `8e1f539..d314590`. No other branch, no force-push, no merge, no tag. Before the push the two local commits were rewritten locally (to fold in test additions and the path ceiling); nothing that was ever pushed was rewritten.
- PR #13's description was updated for the new head (attribution lines kept). It stays a draft.
- Nothing ran outside this container: no CI on this branch, no Mac, no test box, no live service.
- Probe files and mutants stayed out of the repository; copies are in the evidence folder as `.txt`.
- No secret, key, environment file or SQLite state from a real system was read or written. The leak scan of the evidence found only the fixture string `hvs.abcdefghijklmnopqrstuvwxyz` inside test names in the result lists, as the auditor noted in `15-audit.md`.
- Evidence: `16-repair-evidence/` (`probes/`, `mutants/`, `runs/`, `scripts/`, `manifests/`, `SHA256SUMS`) and `16-repair-evidence.tar.gz`.
