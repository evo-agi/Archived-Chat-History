# PR #12 repair round, A30-1 fix (draft PR #40 at `75d0f5c`): re-check 32

Written 2026-11-23 from 23:25Z onwards by the independent audit thread "Audit Execution-Substrate PRs", after the coordinator asked for a diff-only check. Read-only: nothing was pushed, commented, reviewed or merged. Evidence is in `32-recheck-evidence/` next to this file. My local names carry the tag `40b`.

Subject: the writer's `31-repair.md`, which answers A30-1 of `30-audit.md`.

## Verdict

**ACCEPT: A30-1 is fixed, and production code is unchanged.**

- **Only test code changed.**
  - `414a5e5`, whose parent is the audited `fd399a1`, changes one file: `es/admission/reliable_submit_operational_job_bound_test.go`, +39/−22.
  - `75d0f5c` is exactly git's merge of `414a5e5` and `trunk_dev` `0aa4a2b`. Its diff over `414a5e5` is byte-identical to #33's diff.
  - From `fd399a1` to the head, the only paths that change are that test file and #33's two `es/config` test files. No non-test file and no document changes.
- **The manifests verify.**
  - Trunk-relative: `7cbd8a16…6868`, 66 files, base `0aa4a2b`.
  - PR-relative: `9e6b7ec3…12ba`, 82 files, base `4416699`.

  Each was taken twice, byte-identical, and matches the writer's values. Against audit 30's manifests:
  - in the trunk-relative manifest, only the job-bound test's entry changed;
  - the PR-relative manifest adds only #33's two files.
- **Vet and format are clean.** `go vet ./...` passes, the changed test is gofmt-clean, and the `es/config` tests pass (`unit40b.log`).
- **The test is stable.** The fixed test passed 800 of 800 runs: 80 under each of ten `TMPDIR` settings, from unset (`/tmp`, as in CI) to 24 characters. In the same container, at the same time, the old test of `fd399a1` failed 5 of 30 runs under `/tmp` and 12 of 30 under a 13-character path, with `html` and `control` one apart each time. So the environment still triggers the old flakiness, and the new test no longer has it. This matches the writer's 0 of 550.
- **The fix keeps what the test is for.** The bounds of `a`, `<` and `\x01` are now bisected on one shared fixture, where the job differs only in the argument. So exact equality of the `<` and control bounds is sound there, and it still catches the canonical measure (F6). Under `/tmp`, F6 was caught in 3 of 3 runs, and F1, F2 and F5 were caught too.
- **N-1 is still forced.** PR #31's head moved to `b150657` during this check. I trial-merged it into `75d0f5c`, with the `PLANS.md` conflict resolved as a union. Its guard still fails, naming the same three private requests.
- **CI:** run 45288282539 of `build, vet and test` on `75d0f5c` succeeded (check run 138090176147, 23:23Z to 23:57Z). It ran the fixed test under `/tmp`.

## In plain words

The flaky test now measures all three bounds on one test setup, so the random folder names can no longer push two of them one apart. I ran it hundreds of times at different temporary-path lengths. It never failed, while the old version failed in the same container. Nothing outside that one test file changed, apart from the trunk merge, which is exactly #33.

## Target

| Item | Value |
| --- | --- |
| PR | evo-agi/Execution-Substrate #40 (draft) into `codex/reliable-submit-operational-handoff-v1` (PR #12 at `44166998`) |
| Head | `75d0f5c1c858365bf1f68e7e3887405665f0e29f`, tree `321b195d22b563f1007d52c41a903393fdcfdb3f` |
| Previous audit target | `fd399a1` (`30-audit.md`) |
| `trunk_dev` | `0aa4a2b5d8e93a10f65b3bb724b286ee79a0aa7e` (#33), the merge base |
| Recipe | v2, source SHA-256 `c08597e2…a1a3ca`, verified before every run |
| Trunk-relative manifest | `7cbd8a1669c8a31940543a1fe70ba43897b376ca8340331d03adeaab0ac56868`, 66 files, textual diff `42a26fd8…c1e1`, upstream `origin/trunk_dev` |
| PR-relative manifest | `9e6b7ec30d529a2efac32453844ba8b4ce1126305821f28a137c728ce53d12ba`, 82 files, textual diff `c439b13d…bc5`, upstream `origin/codex/reliable-submit-operational-handoff-v1` |
| Toolchain | Go 1.26.5, `GOTOOLCHAIN=local`, `env -i`, user `ci` (1500:1600) |

`trunk_dev` moved to `725c97a` (#41, two `internal/contracts/runtimeconfig/v1` test files) during this check. PR #40 changes nothing in that package, and `git merge-tree` merges `75d0f5c` and `725c97a` with no conflict (`provenance-40b.txt`).

The evidence files:
- refs at the start and the end: `ls-remote-open.txt`, `ls-remote-close.txt`;
- provenance: `provenance-40b.txt`;
- the tree check of the ci copy: `tree-check.txt`, with 528 entries and 0 differences.

## The change

The bisection moved into `operationalLargestArgvThatFits`, unchanged. The parent test now:
1. makes one fixture;
2. bisects all three characters on it;
3. requires `html == control` and `html*5 <= plain`.

Each subtest still makes its own fixture, bisects its own bound, completes the request at that bound and refuses one character more with no claim, grant, POST or revision. The refusal now uses `low+1` instead of `high`. When the bisection ends, `high` is always `low+1`, so this is the same request.

On one fixture, the `<` and `\x01` requests give jobs that differ only in the argument, and `encoding/json` writes both characters as six-byte escapes. So their jobs have the same length for every count. That is why exact equality is sound now, and the writer was right to prefer it over a tolerance: F6 counts `<` differently, and a tolerance of one would weaken the comparison that catches it.

## Stability (`repeat40b.log`)

The test binaries ran alone as `ci`:
- `75d0f5c`: 80 runs under each of ten `TMPDIR` settings, from unset (`/tmp`, as in CI) to 24 characters;
- `fd399a1`: 30 runs each under `/tmp` and a 13-character path, as a positive control.

| Binary | `TMPDIR` | Length | Runs | Failures |
| --- | --- | --- | --- | --- |
| `75d0f5c` | unset (`/tmp`) | 4 | 80 | 0 |
| `75d0f5c` | `/tmp/a` | 6 | 80 | 0 |
| `75d0f5c` | `/tmp/ab12` | 9 | 80 | 0 |
| `75d0f5c` | `/tmp/ab123` | 10 | 80 | 0 |
| `75d0f5c` | `/tmp/m40b-x` | 11 | 80 | 0 |
| `75d0f5c` | `/tmp/ab12345` | 12 | 80 | 0 |
| `75d0f5c` | `/tmp/ab123456` | 13 | 80 | 0 |
| `75d0f5c` | `/tmp/ab1234567` | 14 | 80 | 0 |
| `75d0f5c` | `/tmp/ab123456789` | 16 | 80 | 0 |
| `75d0f5c` | `/tmp/ab1234567890abcdefg` | 24 | 80 | 0 |
| **`75d0f5c`, all** | | | **800** | **0** |
| `fd399a1` (control) | unset (`/tmp`) | 4 | 30 | 5 |
| `fd399a1` (control) | `/tmp/ab123456` | 13 | 30 | 12 |

Each control failure shows `html` and `control` one apart, either way round. For example, `map[control:10368 html:10367 plain:62207]` under `/tmp` and `map[control:10364 html:10365 plain:62191]` at length 13.

## Mutants under `/tmp` (`mut40b.log`)

On a fresh copy of the head, with `TMPDIR` unset, I ran the writer's round 29 RUN set (`mutants40a.py`, the writer's list run as `ci`). I ran the baseline twice, F1, F2 and F5 once, and F6 three times, because only the job-bound comparison catches it.

| Run | Result | Failing tests |
| --- | --- | --- |
| Baseline, twice | 71 of 71 pass, both times | none |
| F1: the handoff does not ask whether the request fits | caught | the job-bound test, `TestOperationalRequestsTooLargeForAJobLeaveTheDomainOpen`, `TestRedTeamPR12HeadRequestTooLargeForAJobTakesNoClaim` |
| F2: every request fits | caught | the same three |
| F5: a shorter locator shape | caught | the job-bound test, `TestOperationalLocatorShapeHasTheLengthsOfEveryAssignedRun` |
| F6: Job0 measured in canonical form | caught, 3 of 3 runs | the job-bound test only |

This matches the writer's section 4.2. Audit 30 had to run these mutants under an 11-character `TMPDIR`. They now give the same verdicts under `/tmp`.

## What I did not cover

- I did not rerun the whole module. Only one test file changed beyond #33's `es/config` tests. Audit 30's whole-module comparison stands for the rest, the writer's `go test ./...` at the head found no changed result, and CI runs the whole module.
- I did not repeat the red-team's check of RT28-1 and RT28-2. It runs at `fd399a1`, and this repair changes no production code.

## Sensitive material

The probes are synthetic. No key, certificate body, token, env file or config file is copied into the evidence. Commit-message trailers and author names are left out. The report and evidence were scanned with the thread's pattern list and a positive control before delivery.
