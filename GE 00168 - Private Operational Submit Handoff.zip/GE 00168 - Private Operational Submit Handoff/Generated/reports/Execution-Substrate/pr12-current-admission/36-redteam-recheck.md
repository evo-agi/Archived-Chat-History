# Red-team re-check of ES PR #12 (round 36) — Nomad token handling

Target: Execution-Substrate draft PR #47 (PR 12's reliable-submit line, round 35),
head `f7bb1d67a1ef1d2882a2f04e2d8aa62e8457cb04`, tree `8408ab09…` (verified by
fetch). `trunk_dev` was `6dbeaeb` (PR #38) and is an ancestor of the head.

Scope (coordinator's brief): the new attack surface this round adds — the
operational provider now sends ES's Nomad token (N-1), the CP-NOMAD-ACL
prerequisite, and the take-up of PR #31 (Nomad lock) and PR #38 (caller
identity). Focus on token handling and leakage (redirects, logs, wrong host) and
on the integration seams with #31. Guard-evasion itself is the auditor's. Local
lab only (cloud container, Go 1.26.5), read-only, nothing pushed. Evidence:
`36-redteam-recheck-evidence/`. Writer's repair report for this round:
`35-repair.md`.

## Outcome in one line

No finding. The token path is leakage-clean by construction: ES's Nomad token is
header-only, validated to the exact canonical SecretID (no injection), sent over
a transport that follows no redirect and dials only the loopback-pinned,
SPKI-pinned Nomad, and never reaches a log, error, ack or URL. The #31 token
guard now covers the operational provider, and the #38 caller-identity take-up is
a clean trunk merge. The provider still has no production caller (commissioning
gate). The token surface is clean.

## What changed this round

- **N-1** (`0db37f1`, "Send ES's Nomad token on the operational provider's
  requests"): the only production change in scope. `operationalProvider` gains a
  `token` field; `newOperationalLoopbackProvider` takes and validates it;
  `prepareExchange` sets it on every request; a new `prepareRegister` wraps
  `POST /v1/jobs`; `handoff.consume` calls `prepareRegister`. Diff:
  `logs/n1-token-send.diff` (provider + handoff only).
- **CP-NOMAD-ACL** (`f3a2d19`, "State the provider's Nomad token, gate its ACL
  wiring"): docs/PLANS/contract test only — states the token and gates the ACL
  wiring behind the commissioning prerequisite. No production `.go` change.
- **#31 take-up** (`0842983`, Nomad lock) and **#38 take-up** (`6dbeaeb`, caller
  identity): trunk PRs merged into PR 12's line.
- Blob SHA-256 of the token-path files at the head: `head/pr-file-sha256.txt`.

## Token handling and leakage — clean

Read of `es/admission/reliable_submit_operational_provider.go`,
`reliable_submit_operational_handoff.go` and `nomad_access.go`:

- **Canonical-only token (no header injection).** The provider refuses to build
  unless `parseNomadTokenFileContent(token)` returns a value equal to `token`
  itself. `parseNomadTokenFileContent` accepts exactly a lower-case 8-4-4-4-12
  UUID (optionally one trailing `\n`, which it strips), so the stored `p.token`
  is exactly the 36-char SecretID — no CR, LF, space or control byte can survive,
  so nothing can be smuggled into the header line.
  `TestOperationalProviderNeedsANomadToken` confirms empty, trailing-LF,
  upper-case, short, non-UUID, surrounding-space and "management" tokens are all
  refused.
- **Header only, never the URL.** `prepareExchange` does
  `req.Header.Set(nomadTokenHeader /* X-Nomad-Token */, p.token)`; the URL query
  is only `region=…&namespace=…`.
  `TestEveryOperationalNomadRequestCarriesTheTokenAndTheOperationalNamespace`
  asserts each of the three requests (`POST /v1/jobs`, `GET /v1/job/<name>`,
  `GET /v1/job/<name>/evaluations`) carries exactly one token header with ES's
  token and that the token appears in neither the path nor the query.
- **No redirect, so no cross-host leak.** Requests are run with
  `prepared.transport.RoundTrip(prepared.request)` — a bare `RoundTripper`, not
  `http.Client.Do` — so no redirect is ever followed and the token is never
  re-sent to a 3xx target. This closes the classic leak where Go's client
  re-sends a custom header such as `X-Nomad-Token` across a redirect to another
  host (Go only strips `Authorization`/`Cookie`, not custom headers).
  `TestNomadClientNeverFollowsARedirectOrUsesAProxy` and
  `TestDependencyClientsDoNotFollowRedirects` pass.
- **Wrong host is impossible.** The transport's `DialContext` refuses unless
  `addr == u.Host` and then dials `p.target`, which `newOperationalLoopbackProvider`
  requires to be loopback on the realm port; `TLSClientConfig.VerifyConnection`
  requires the peer's SPKI SHA-256 to equal `realm.spki`. So the token reaches
  only the cryptographically pinned, loopback Nomad.
- **No leak into logs, errors or acks.** The only use of `p.token` in the whole
  provider is the one `Header.Set`. On a transport error, `exchange` maps the
  error to an opaque `OperationalReason` enum (`operationalExchangeFailure`),
  never surfacing the error text (and the URL it might contain has no token); a
  non-200 returns only the status code. There is no log, summary, `String()` or
  serialization of the token. Startup refuses before provisioning anything when
  the token file is absent or unsafe, and
  `TestNomadTokenIsAStartupPrerequisiteBeforeAnyRootIsProvisioned` asserts the
  refusal error contains neither the token path nor the token value.

Runtime confirmation (`logs/token-guard-tests-root.txt`, 18/18): the three
provider requests each carry the token once in the header with
`region=global&namespace=<operational>`; a wrong token registers nothing
(`TestOperationalProviderRefusesARequestWithoutTheToken` — the fake ACL-Nomad
refuses it); the provider cannot be built without a canonical token.

## #31 (Nomad lock) integration seam — holds

PR #31's static guard now covers both Nomad client types, including the operational
provider:

- `nomadTokenRequestBuilders` lists `operationalProvider` and
  `nomadTokenHeaderSetters` maps it to `prepareExchange`.
- `TestEveryNomadRequestPathGoesThroughTheTokenBuilder` requires every Nomad API
  path literal to be the path argument of a token-setting builder called on the
  receiver. `prepareRegister`'s `"/v1/jobs"` and the GET paths are all arguments
  of `p.prepareExchange(...)`, so they are approved; a Nomad path added anywhere
  else would fail the guard.
- `TestNomadTokenRequestBuildersSetTheToken` requires `prepareExchange` to set
  `nomadTokenHeader` from the receiver's own `token`, and flags any builder that
  deletes the header.
- `TestNomadRequestGuardCatchesEachBypass` and
  `TestNomadTokenBuilderCheckCatchesALostToken` exercise the bypass/lost-token
  cases, including the provider. All pass.

So a future Nomad request for the provider cannot be added without routing
through `prepareExchange`, which sets the token — the seam is enforced, not just
documented. `handoff.consume` was switched to `prepareRegister` accordingly.

## #38 (caller identity) take-up — clean

`6dbeaeb` is a straight trunk merge of PR #38, already red-teamed at the trunk
(`es-pr38-red-team-16`, no exploitable finding). Its logic tests pass here:
`internal/callerallowlist` (incl. `FuzzPrefixRule`) and `internal/callerauth`
(ParseSPIFFEID, CallerFromConnectionState, reference-parser/validator agreement)
— 22/22 (`logs/caller-identity-38-root.txt`). No regression from the take-up.

## Not yet reachable from production

The operational provider still has no production caller: it is commissioned only
by the private, unwired handoff (`commissionOperationalAdmission` is private with
no production caller), and `f3a2d19` keeps the ACL wiring behind the
commissioning prerequisite. So N-1 prepares the token path for a future
commissioned operational submit; it is not reachable on the current admission
path.

## Opens nothing new

- The token-handling surface is green: 18/18 token/guard/provider/redirect tests
  and 42 operational tests pass as root (`logs/`). The secret-shape scan of the
  three token-path production files is all-zero (`logs/secret-scan.txt`): the
  token is only ever a variable, never a literal.
- The full suite ("build, vet and test") is **green in CI at the exact head**
  `f7bb1d6` (run 45324371962, 2026-11-24 04:09–04:45Z).

## Coverage this pass could not provide (environment artifacts, not defects)

Five tests fail in this cloud container only; details and proof in
`logs/environment-artifacts.txt`. None is a code defect:

- Three (`…StartupPrerequisite…`, `…EveryOperationalNomadRequest…`,
  `…ProviderRefusesARequestWithoutTheToken`) fail because the sandbox's
  `/opt/ci` (uid 1500) temp ancestry does not satisfy the production custody
  parent-safety checks (`result_auth.go`, the private-replay custody). They
  **pass as root under a root-owned TMPDIR** (`token-guard-tests-root.txt`) and
  in CI; the service still fails closed in the sandbox, just at a different
  custody check.
- Two guard-analysis tests (`…NoPublicStartupOrdinaryOrFixtureCaller`, the
  callerauth typed guard) spawn an inner cross-platform `go list`/`go build`
  that is blocked offline (`GOPROXY=off`) and by VCS stamping (`exit status
  128`, the documented #38 scratch-clone artifact). These are out of scope
  (the auditor owns the guards) and are green in CI.

The live Nomad box check for N-1 (a real ACL-enabled Nomad accepting ES's token)
remains a box-run step and needs David's go.

## Pointers

PR 12 chain: `31-redteam-recheck.md` (prior), `35-repair.md` (this round's
repair). Related finding records: [[es-pr12-repair-recheck-31]],
[[es-nomad-acl-lock]], [[es-pr38-red-team-16]]. Finding record for this pass:
[[es-pr12-redteam-recheck-36]].
