# INDEPENDENT AUDIT REPORT: A7-1 fix of PR #13 (narrow re-audit of `d314590..e060449`) and check of the `trunk_dev` merge plan

Fresh, read-only, narrow re-audit by the auditor of `15-audit.md` and `17-audit.md`. Audit thread: "Audit PR 13 post-red-team repair". Date: 2026-11-23, 14:47Z to 15:50Z (UTC). Model: Opus. I am not the writer of the audited bytes.

Verdict: **ACCEPT** `e060449` (section 12). A7-1 is closed and O7-4 is done. The merge plan has **one error that must be fixed before it runs (M19-1)**: it counts 55 paths, but the merged head has 56, because the CI list file is a path too. My own `17-audit.md` made the same miss.

## 1. In plain words

1. **The bytes are the ones the writer reported.** I rebuilt the writer's manifests from the pushed branch at the start and at the end. All nine files I compared are identical byte for byte to the writer's, both times.
2. **A7-1 is closed.** The new subtest plants a line directive in ten production files in a scratch tree:
   - in `testdata`, `_name` and `.name` directories (nested ones too), a `vendor` directory and a nested module;
   - in a cgo file and in a file with a build tag that no target builds.
   All ten are refused, each by name and line. A test file, a file under `.git` and a `go.mod` are not read. The mutant that survived last time (C3, the check skips `testdata`) now fails the guard. So do my two new mutants (the listing skips `vendor`; only the first refusal is reported). My four planted files in the real repository are refused, as at `d314590`.
3. **O7-4 is done.** All four refusal messages now say to use `PositionFor(pos, false)` outside package `admission`.
4. **Behaviour is unchanged.**
   - Whole `es/admission` gives 2,450 pass and 1 skip. That is identical to `d314590` except for the one new subtest, which passes.
   - Builds are clean for three targets. `gofmt` is clean, and the race detector is clean on the guard tests.
   - Vet shows the known `result_auth_test.go:395` finding and the old Linux compile gap of one store test file (O8-2). Both are gone on every merged tree.
5. **The merge plan, first version (for `trunk_dev` `200fd60`).** Steps 1 and 2 give exactly the writer's trees, and every result is as expected. But step 3, the two CI list lines, adds a path the plan does not count. That gives 55, not 54.
6. **`trunk_dev` moved during this audit.** PR #22 landed at 14:53Z as `792f17c`, with the same tree as the audited `8ce6b73`. The writer revised the plan at 15:10Z: the follow-up patch now also changes PR #22's two position reads, and it counts 55 paths.
7. **The revised plan works, except for the count.**
   - I ran it on `e060449` with `792f17c`. The conflicts are the same two blocks, and both patches apply. The tree after step 2 is exactly the writer's (`b0394068…`).
   - Build, vet and darwin vet are clean. The CI gate's self-test passes, and so does its check of the list against the merged module.
   - PR #12's position-read guard passes. Without the read change, it refuses exactly PR #22's lines 108 and 153.
   - Against my run of the plan on `200fd60`, the only changed results are PR #22's 18 new ones and the renamed docs pins, and all of them pass. PR #22's own tests give the same results on the merged tree as on `trunk_dev` itself.
   - **But the merged head has 56 trunk-relative paths, not 55.** The 56th is `.github/ci/environment-only-tests.txt`.
8. **M19-1 (medium, merge plan; it does not block `e060449`).**
   - The owner document says any further file needs its own owner reconciliation. The patch's paragraph says "exactly two more paths … 55 files". The plan entry says "adds one test file, changes another and changes documents". Neither names the CI list.
   - The CI lines cannot go to `trunk_dev` on their own: there the gate's list check fails ("listed test is not defined").
   - So the reconciliation must name three paths and say 56, and the pins must follow.
9. **`trunk_dev` moved again: PR #25 landed at 15:26Z (`036d507`).** I ran the revised plan once more against it. It gives the same two blocks, both patches apply, and the results are identical entry by entry to the run at `792f17c`. It still gives 56 paths. The writer's third version of the plan (15:33Z) says PR #25 changes nothing; that is right, but it still counts 55.
10. **The PR #26 case of the plan holds.** I took the case where draft PR #26 (`bcfb6da`) lands first and resolved its two blocks as step 1 says. The result: gofmt and vet clean, whole `es/admission` 2,480 pass and 13 skip (the 2,463 plus PR #26's 17 new results, all pass), and still 56 paths. PR #26 changes only a file that PR #12 already counts.

## 2. Audit target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Pull request | #13, draft, head branch `claude/project-thread-sqldt7`, base branch `codex/reliable-submit-operational-handoff-v1` (PR #12's head) |
| Base commit | `8058561edc08356c46680c204586b3c7796c0ff3`, remote base branch unchanged at the end (`git ls-remote`, 15:15Z) |
| Previous tip | `d314590dad6f6e132a20c62e9fff671311e286fe` (`17-audit.md`, ACCEPT with low A7-1) |
| Audited commit | `e060449c5166e35a3de444cbc9d16f739854fe45`, tree `24ab1e9b671a0f775f964d2310638f23fe02b336`, one commit after `d314590`, one file (`es/admission/workstream_c_guardrails_test.go`, +76/−7); remote head unchanged at the end |
| Recipe | `governed-execution.audit-patch-manifest.v2`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked before every run |
| Base-relative manifest | `1594c9b0d674c9ee39d4fefd94f2516c13f860bcd582d1b121502de89c797385`, 33 paths, textual diff `576ac201715e129daa222a16ea9b704a883a577dfeb7444221d4a857f4eb1a1a` |
| Delta against `d314590` | `4467fecf5a42ff4796e0730c1a1f3afe95b79470e06a23f9749c8ac9f4e80c0d`, 1 path, textual diff `844630423a80201923882aa723754f582ca3697e5b41eb25c9e57eff3997e178` |
| Delta against `8e1f539` (mine) | `7f8fccf9c8e0634376ba49ca280966f4260674bc1bcf3a012dde1ce0aaffa707`, 6 paths, textual diff `6cc08ded6895b66abe8c7f0e77c305cba1bf03df6cb2a1cad68183240013afa7` |
| Trunk-relative | `f5432c1bf85ff03134c3c4af0921efb1e3ea26b1618a45bea699c6f52e819136`, 53 paths, upstream `origin/trunk_dev`, base the merge base `ae326b0ddc30ec6b35883ee32945c622405b68b6` |
| Writer report | `18-repair.md`, SHA-256 `829c37daa3e1991d960b5d114b183fe50b3c7f84f9d67edee0d7d346b577ee2f` (revised 15:08Z; I first read the 14:43Z version `9c2ab83e…c493`). Evidence `18-repair-evidence/`, `SHA256SUMS` `67834847…3447`, 101 entries, all OK at 15:20Z |
| Merge plan | `18-trunk-dev-merge-plan.md` `825da0db500aa44d9b00d1ea58cf949ad8ba94f446aca6cd21d043986a885d93` (third version, 15:33Z, after PR #25; second `fd77c8d8…3522`, 15:10Z; first `f97624b0…d04c`); `18-trunk-dev-merge-gate.patch` `12cba9f294096429f999577b6e6e64803a212864c63528c098a292ba52883523` (for `792f17c`); `18-trunk-dev-merge-gate-200fd60.patch` `c4ea82e2b2ae23e958eb0f1a9628799523994144759f5b439c391899771b3aab` (first version); `13-ci-list-two-lines.patch` `cded683036e43bd9a9182b5fbaffe3ed92c0dec28f9a628d634cdcd7f0c71298` |
| `trunk_dev` | `200fd6097b43981ffae86e69500d1ab41b49a94c` at the start; `792f17c7c56ca4a9c00d34aeb59524d898aeb58c` (PR #22, 14:53Z, tree `02ab404b…` = tree of `8ce6b73`); `036d50724b499b020c5149c55ad902cfcb1482c0` (PR #25, 15:26Z) at the end (`git ls-remote`, 15:33Z). The merge base with the tip stayed `ae326b0` |
| Draft PR #26 | `bcfb6dad5546661d0587489f7214f783c030af19` when tested; `0aba38e28e9f529fad44b810a00c8d35446552d4` at the end, which only merges `036d507` (its own file is byte-identical) |

## 3. Audit posture

- Read-only. One thread, no subagents, no repository edits, no GitHub comments. The working copy `/home/user/Execution-Substrate` was only fetched into.
- Manifests were taken in the separate clone `/opt/audit/prov-repo`. Everything else ran in throwaway clones under `/opt/ci/work/`, as the unprivileged user `ci` with an emptied environment. Settings: Go 1.26.5, `GOTOOLCHAIN=local`, `CGO_ENABLED=0` except the race run, linux/amd64, no Docker daemon.
- This time no clone has the Linux overlay of `replay_custody_file_test.go`. The audit of `e060449` ran only `es/admission`, which does not need it, and the trial merges do not need it either, because `trunk_dev` holds the fix.
- Test runs start through `sigdfl.py`, which resets HUP, INT, QUIT and TERM to their default handling. SIGPIPE and SIGXFSZ stay ignored, as in the earlier reports.
- This container has no `ssh`, `uuidgen` or `bindfs`. That is why the root package fails more Remote Alpha tests here than in the writer's runs, so root results are only compared between my own runs. Mutants never ran beside a suite I compared.
- Trial merges were committed in local scratch clones and never pushed.

## 4. Provenance reproduction

`prov19.sh` (evidence `scripts/`) is `prov17.sh` with the new tip. Before each of its eight recipe runs, it checks the recipe hash, a clean tree, HEAD at the remote tip, and the base and both earlier tips as ancestors. It uses the writer's upstreams:

- base: `origin/codex/reliable-submit-operational-handoff-v1`;
- deltas: `origin/claude/project-thread-sqldt7`;
- trunk: `origin/trunk_dev`, reset to the merge base.

Each manifest runs twice. After each pair, HEAD and the upstream are restored.

| Run | Time | Result |
| --- | --- | --- |
| Opening | 14:48Z (`trunk_dev` `200fd60`) | `base-1/2.json`, `delta-prev-1/2.json`, `trunk-1/2.json` and the three staged path lists byte-identical to `18-repair-evidence/manifests/`; each pair identical; staged tree `24ab1e9b…` = tip tree; tree clean, HEAD and upstream restored |
| Closing | 15:05Z (`trunk_dev` `792f17c`) | The same nine files byte-identical to the writer's again. The merge base did not move, so the trunk manifest is unchanged although `trunk_dev` moved |
| Second closing | 15:46Z (`trunk_dev` `036d507`) | The same nine files byte-identical to the writer's again |

The path lists equal those of `d314590` (33 base, 53 trunk). The delta against `d314590` is the one guard file.

## 5. Coverage

- I read every line of the delta, `git diff d314590 e060449` (`runs/delta-d314590-e060449.diff`):
  - the helper `operationalGuardLineDirectivesOfTree`;
  - the rewritten top of `TestOperationalGuardProductionFilesHoldNoLineDirective`;
  - its new subtest;
  - the four messages of `validateGuardPositionReads`.
- Read for context: `repositoryProductionListings` (unchanged; walks every directory but `.git`, reads every `*.go` that is not `*_test.go`), `validateOperationalNoLineDirective`, `operationalGuardMovedPosition`.
- On the plan side, I read all of `18-repair.md` and both versions of the plan and of the gate patch. I also read the 101-entry evidence list.

## 6. Findings

### 6.1 Summary

| ID | Severity | Type | Summary |
| --- | --- | --- | --- |
| M19-1 | medium; merge plan, not PR #13's bytes | wrong path count | Applying the plan gives 56 trunk-relative paths, but the gate patch's owner paragraph, plan entry and pins say 55 (54 in the first version). The extra path is `.github/ci/environment-only-tests.txt` (step 3), and no reconciliation names it. |

No finding against `e060449`. A7-1 is closed (section 7) and O7-4 is done (section 8).

### 6.2 M19-1

ID / Type / Severity: M19-1 / wrong path count in an unpushed plan / medium. It must be fixed before the plan runs. It does not block `e060449`.

**Claim.** The owner document (section 9) says that each path beyond the ceiling needs its own owner reconciliation ("Any further file again requires separate owner reconciliation"). Earlier audits measured that ceiling as the trunk-relative path count (`12-audit.md` section 4, `17-audit.md` section 7.4). The revised gate patch says:

- "It adds exactly two more paths, both test files: … With them the aggregate HEAD ceiling for PR #12 plus its repairs is 55 files";
- in `PLANS.md`: "These are two more test files, so the path ceiling … is 55 files" and "This entry adds one test file, changes another and changes documents";
- plan step 6: "the trunk-relative manifest has 55 paths".

**Measured** on `e060449` with `trunk_dev` `792f17c` (`trial-merge-792f17c/tm19d.log` and the path lists):

| After | Trunk-relative paths | New path |
| --- | --- | --- |
| Step 1, the merge | 53 | none |
| Step 2, the gate patch (tree `b0394068…`, = writer's) | 55 | the startup file, PR #22's test file |
| Step 3, `13-ci-list-two-lines.patch` | **56** | `.github/ci/environment-only-tests.txt` |

The first version of the plan has the same gap: 54 claimed, 55 measured after step 3 (`trial-merge-200fd60/tm19.log`). My `17-audit.md` (section 15, item 3) said the ceiling "becomes 54" and missed it too (section 10).

**Why the lines must ride with PR #12.** I applied the CI list patch to `trunk_dev` `792f17c` alone and ran the gate's own list check (`check_list` of `go_test_gate.py`, via `scripts/listcheck.py`). It fails with "listed test is not defined in package …/reliablesubmit: TestOperationalHandoffSchema4BinaryRefusesSchema5" (`trial-merge-792f17c/td792-listcheck-with-patch.log`). On the merged tree it passes (`tm19d-listcheck.log`).

**Fix (smallest).** In the follow-up commit, or a second one before the push:

- make the owner paragraph name three paths: the two test files and `.github/ci/environment-only-tests.txt` (two lines for tests of the handoff that fail or skip themselves on the runner by design);
- make the paragraph say "is 56 files";
- make the `PLANS.md` entry say the same and that the entry also changes the CI's environment-only list;
- change the pins and their missing and wrong-statement cases to match, and plan step 6 to 56.

Folding the two CI lines into the follow-up commit would keep the reconciliation and the path in one commit. That is an option, not a requirement.

An alternative for PR #22's file only: change the two reads on `trunk_dev` itself, in a tests-only PR, before PR #12 takes `trunk_dev`. Then PR #12 would add two paths and land at 55. This is inference: the change passes PR #22's tests on the merged tree (section 9.3), and nothing on `trunk_dev` depends on PR #12. It costs one more PR, so I recommend the reconciliation above.

### 6.3 Observations (not findings)

- **O8-1.** The new message text "use guardPosition, or PositionFor(pos, false) outside package admission" reads like a rule. The check also accepts `PositionFor(pos, false)` inside package `admission`, so the message gives a preference, not a rule. It does no harm.
- **O8-2.** At `e060449` on its own, `go vet` for linux reports, besides the known `result_auth_test.go:395` finding, that the `reliablesubmit` test package does not compile on Linux (`Stat_t.Mode` width). This is pre-existing: the file is unchanged since `8058561`. Earlier reports ran with the Linux overlay. `trunk_dev`'s PR #14 fixes it. On every merged tree, `go vet` is fully clean, because `trunk_dev` also changed `result_auth_test.go`.

## 7. A7-1 closed

The new helper `operationalGuardLineDirectivesOfTree(t, root)` lists the tree with the shared `repositoryProductionListings`, runs the directive check on it, and returns how many files it read. The repository test now calls it on the repository root.

The new subtest "every directory the go command can compile from is read" calls it on a `t.TempDir()` tree:

- **Planted, must be read and refused (10):** `top.go`, `pkg/kept.go`, `pkg/testdata/fixture/td.go`, `pkg/_under/under.go`, `pkg/.dot/dot.go`, `pkg/testdata/_deep/.deeper/d.go`, `pkg/vendor/dep/dep.go`, `pkg/nested/inner.go` (next to a nested `go.mod`), `pkg/zz_cgo.go` (imports `C`), `pkg/zz_tagged.go` (`//go:build zzcustom`).
- **Must not be read (3):** `pkg/kept_test.go`, `.git/planted/planted.go`, `pkg/nested/go.mod`.
- **Checks:** exactly 10 files read; each planted file refused at its own `name:line:1`; no unread name in the error.

That holds the reach that A7-1 asked for (`testdata`, `_`, `.`), plus `vendor`, nested modules, cgo and build-tagged files. Reading `vendor`, nested modules and `_`/`.` files is more than the go command would compile in some setups, which is the safe side.

**Mutants** (`scripts/mutate19.py`, `scripts/m19.sh`; run on the two directive and position tests, 40 results; `runs/mut-*.log`):

| Mutant | What it does | Result |
| --- | --- | --- |
| base | none | 40 pass |
| C3 (17-audit, verbatim) | drops every source under `/testdata/` before the check | **caught**: the new subtest and its parent fail |
| E1 (new) | the shared listing skips directories named `vendor` | **caught**, same two |
| E4 (new) | the directive check reports only its first refusal | **caught**, same two |

In `17-audit.md`, C3 survived the whole package. The writer reports 13 of 13 mutants caught (C3 and D1 to D12). I repeated C3 and added E1 and E4.

**Repository probe** (`runs/cover.log`, files in `probes/`). The four files of my 17-audit probe were planted again at `e060449`: `es/app/testdata/zzline/zz.go`, `es/admission/_zzline/zz.go`, `es/.zzline/zz.go` and the cgo file `es/admission/zz_cgo.go`. All four are refused, each twice: by name, and as a moved position.

## 8. O7-4

All four refusals of `validateGuardPositionReads` (`Position`, `Line`, `PositionFor` with the wrong argument count, `PositionFor` without `false`) now end "use guardPosition, or PositionFor(pos, false) outside package admission". This matters because `guardPosition` lives in package `admission`, and PR #22's root test file cannot call it. Its fix (section 9.3) is exactly the form the message names.

## 9. Merge plan check

### 9.1 First version, for `trunk_dev` `200fd60` (`scripts/tm19.sh`, `trial-merge-200fd60/`)

| Step | Result |
| --- | --- |
| 1. Merge, strict resolver: the count block takes ours with the counted 39, the adjacency block keeps both, and any other block stops the run | Exactly the two blocks in `docs_contract_test.go`. Tree `2bab09a1…` = writer's |
| 2. `18-trunk-dev-merge-gate-200fd60.patch` | Applies; tree `a59019e7…` = writer's; 54 paths |
| 3. `13-ci-list-two-lines.patch` | Applies; **55 paths** |
| Build, vet, vet darwin, CI gate self-test | Clean, clean, clean, OK |
| Tests (`.`, `es/admission/...`, `internal/testtmpdir/...`) | Against my 17-audit trial merge of `d314590` (no patch), exactly 7 entries differ, all now passing: <br>• the 4 new docs pins; <br>• the A7-1 subtest; <br>• `TestEveryTestPackageResolvesTheTemporaryDirectory`, from fail to pass (2 entries). <br>`es/admission` 2,463 pass, 13 skip; `admissionstate` 70; `reliablesubmit` 749 pass, 2 skip, 3 fail (the three probe-binary tests the CI list names); `testtmpdir` 27 |

### 9.2 `trunk_dev` `792f17c`, the first plan plus my own step 4 (`scripts/tm19c.sh`, `trial-merge-792f17c/tm19c*`)

I ran this before the writer revised the plan.

- Step 1 gives the same two blocks (tree `e47d8f62…`). Both patches apply.
- PR #12's position-read guard fails on exactly `remote_alpha_es_service_tls_status_local_boundary_test.go:108` and `:153`.
- I changed the two reads to `PositionFor(…, false)` (`tm19c-step4.diff`, 2 lines). The guard then passes, and there are 56 paths.
- All results equal the 200fd60 run, except PR #22's 18 new results, all pass.
- PR #22's selection (`^TestRemoteAlphaESServiceTLSStatus`) gives 812 pass and 25 fail. That is identical, entry by entry, to the same selection run on `trunk_dev` `792f17c` itself. The 25 failing results belong to three older tests of `remote_alpha_es_service_tls_status_test.go` (two of them fail at `staged_leaf_check_reached`). They fail the same way on `trunk_dev` itself, and they also failed in my runs before PR #22. So they come from this container, not from the merge; I did not establish the cause.

### 9.3 Revised plan, for `trunk_dev` `792f17c` (`scripts/tm19d.sh`, `trial-merge-792f17c/tm19d*`)

| Step | Result |
| --- | --- |
| 1. Merge with the same resolver | Same two blocks; tree `e47d8f62…` |
| 2. `18-trunk-dev-merge-gate.patch` | Applies; tree **`b0394068…` = writer's**; 55 paths |
| 3. `13-ci-list-two-lines.patch` | Applies; tree `b96df219…`; **56 paths** (M19-1) |
| Code against my step-4 tree of 9.2 | Differs only in the owner document, `PLANS.md` and `docs_contract_test.go`; PR #22's file is byte-identical to my change |
| Position-read guard, build, vet, vet darwin, gate self-test, CI list check | Pass, clean, clean, clean, OK, OK |
| Tests | Against 9.2, exactly 6 entries differ, all docs-pin subtests that were renamed or added (`CeilingNotRaisedForTrunkDev`, `MissingTrunkDevCeiling`, `MissingTrunkDevPositionReadsPath`, `TrunkDevPositionReadsPathUnnamed` now; the two `…TrunkDevStartup…` ceiling cases of the first version gone), all pass |

**Other statements of the revised plan that I checked:**

- "PR #22 changed neither file" of the conflicts: true; the only conflicting file is `docs_contract_test.go`.
- "At `792f17c`, only PR #22's two reads trip a guard": true; with them changed, whole `es/admission` and `internal/testtmpdir` pass.
- "Every PR #12 test passes": true for `es/admission/...` (the three probe-binary store tests aside, which the CI list names).

### 9.4 Draft PR #26 landing first (`scripts/tm19e.sh`, `trial-merge-792f17c/tm19e*`)

I merged `bcfb6da` (`refs/pull/26/head`, based on `792f17c`) into the step-3 head of 9.3.

- It conflicts only in `es/admission/workstream_a_guardrails_test.go`, in two blocks of identical shape.
- I resolved them as plan step 1 says, with a strict script: ours keeps its `source:` line through `guardPosition`, and theirs adds `node:` and `syntax:`. Tree `c4c3d52c…`.
- No `Position(` read is left in the file.
- gofmt clean; vet of `es/admission` clean; whole `es/admission` 2,480 pass and 13 skip. Against 9.3, exactly the 17 results of PR #26's new test `TestWorkstreamAPublicationAllowRuleJudgesTheCodeNotTheLine` are new, and all pass.
- 56 paths against `bcfb6da`: PR #26 adds none.

### 9.5 `trunk_dev` `036d507`, PR #25 landed during the audit (`scripts/tm19f.sh`, `trial-merge-036d507/`)

PR #25 changes `docs_contract_test.go`, `.github/workflows/go.yml`, a new test file in `es/app` and scripts. The revised plan, run unchanged against it:

- Step 1 gives the same two blocks (tree `8c61971c…`).
- Step 2 gives tree `53d13232…` with 55 paths. Step 3 gives tree `8da40b4d…` with **56 paths**.
- The position-read guard passes. It also reads PR #25's new test file.
- Build, vet, vet darwin, the gate self-test and the CI list check are clean.
- The tests (`.`, `es/admission/...`, `internal/testtmpdir/...`) are identical, entry by entry, to section 9.3 (`runs/compare.txt`).

The plan's third version (15:33Z) says the same: "PR #25 changes nothing in this plan". That is true, except that its count is still 55. Its patch is unchanged (`12cba9f2…`).

PR #26's new head `0aba38e` only merges `036d507`, and its guard file is byte-identical to `bcfb6da`'s. So section 9.4 carries over (inference from identical bytes; not rerun).

### 9.6 Order and other steps

Plan section 2 runs: PR #13 into PR #12, then this merge on a branch of the writer's thread, then an audit of the merge, and David's go before fast-forwarding PR #12's branch. That matches the merge policy as recorded (writes to PR #12's branch need David's go). Step 5 (full suite with the CI's list on the runner) is still needed: this container is not the runner.

## 10. Corrections

- **`17-audit.md` section 15, item 3, and section 1, item 9** say the startup file is "a 54th path". The trial merge there did not apply the CI list patch, and I did not count it. With the CI list, the count was 55 at `200fd60`. It is 56 at `792f17c` with PR #22's file. M19-1 is the same miss, in the writer's plan.

## 11. Evidence files

`19-audit-evidence/` (`SHA256SUMS` lists every file):

- `scripts/`: `prov19.sh`, `mutate19.py`, `m19.sh`, `val19.sh`, `tm19.sh`, `tm19c.sh`, `tm19d.sh`, `tm19e.sh`, `tm19f.sh`, `listcheck.py`, `compare19.py`, `sync.sh`, `cirun.sh`, `sigdfl.py`, `summ.py`.
- `manifests/open/`, `manifests/close/`, `manifests/close2/`: my manifests, stdout, staged lists and trees.
- `probes/`: the two directive probe files.
- `runs/`:
  - the delta diff;
  - build, vet and gofmt logs for three targets;
  - the `es/admission` summary and TSV;
  - race and repository-probe logs;
  - mutant logs and JSON;
  - `compare.txt`, every comparison named in this report.
- `trial-merge-200fd60/`, `trial-merge-792f17c/`, `trial-merge-036d507/`: the logs, path lists, diffs, guard logs, list checks, test summaries and TSVs of sections 9.1 to 9.5.

## 12. Final verdict

**ACCEPT** `e060449` (tree `24ab1e9b…`) as the A7-1 fix of PR #13. A7-1 is closed, O7-4 is done, and behaviour is unchanged on the exact bytes. There is no finding against PR #13.

For PR #12's merge with `trunk_dev`, the revised plan's steps, patches and trees are right at `792f17c` and at `036d507`, with one fix needed first:

- **M19-1:** the reconciliation, plan entry, pins and step 6 must count 56 paths and name `.github/ci/environment-only-tests.txt`.

What PR #12's merge with `trunk_dev` (`036d507`) needs, as measured here:

1. Two `docs_contract_test.go` blocks: the count block takes ours with 39 (not keep both); the adjacency block keeps both.
2. The follow-up patch (startup file, PR #22's two reads, documents and pins), corrected for M19-1.
3. The two CI list lines.
4. If PR #26 lands first: its two `workstream_a_guardrails_test.go` blocks, ours `source:` plus theirs `node:`/`syntax:`.
5. Re-check all of it against `trunk_dev` at merge time. Then a narrow audit of the merge commit and the follow-up, and the runner's CI.
