# Red-team re-check of the PR #12 repair round: draft PR #40 at `fd399a1`

Status of this file: **RED-TEAM RE-CHECK.** Written by the red-team thread "Red-team PR 12 reliable submit" on 2026-11-23 between 22:58 and 23:55 UTC. Readers: the coordinator, David, the PR #12 writer and the audit thread.

It follows `28-redteam.md` (my findings RT28-1 and RT28-2), `29-repair.md` (the writer's repair) and `30-audit.md` (the audit of the repair). The brief: try to break the two repairs, look for new problems the repairs introduced, leave the guard-evasion angle aside, read-only, no box. The brief names the head `fd399a1`. While I worked the branch moved to `75d0f5c`, which changes three test files and no product file (the writer's `31-repair.md`, which I read at the end and did not audit); what I ran again there is in section 2.

This thread pushed nothing, opened nothing, commented nowhere and merged nothing.

Words used below. "Source: run" means I measured it in this container and the log is in the evidence folder. "Source: reading" means I read it in code or in a document and did not run it. "Inference" and "Unknown" are marked as such. Unicode characters are written as U+XXXX in this file, never as the characters themselves.

---

## 1. Verdict

**BOTH REPAIRS HOLD AGAINST WHAT THEY WERE WRITTEN TO STOP. TWO LOW FINDINGS REMAIN, both older than the repair: RC31-1 (Nomad still rewrites two kinds of admitted strings) and RC31-2 (a request Nomad always refuses still spends a claim).**

In plain words:

1. **RT28-1's repair holds for template evaluation.** I found no way to get `${`, `%{` or a NUL byte into a Nomad job. Every road to a job goes through the one rule; escaped spellings in the request text are decoded before the rule runs; no later step of ES can create an opener; the strings ES places in the job without checking are constants or the operator's own configuration. The rule does not echo caller text and leaves nothing behind on either path.
2. **RT28-2's repair holds for size.** In 120 random requests at the bound and up to three bytes either side of it, with mixed characters in one argument, three arguments, one hundred arguments and an environment value, the check before the claim agreed every time with the projection after it: 70 completed with one POST, 50 were refused as malformed with nothing stored. The writer's two open questions have a clear answer from Nomad's source: Nomad's answer is never longer than the form ES measures, and the two mutants the writer could not kill are equivalent (section 7).
3. **RC31-1, low, contract drift and a latent security risk. Older than PR #12.** The repair's new contract sentence says the workload "receives exactly the strings ES admitted". That is not yet true for the two request fields that go into the task's driver configuration, the arguments and the mount targets. Nomad's client drops a byte order mark (U+FEFF) at the start of such a string and rewrites the string to Unicode Normalization Form C. So an argument with an invisible mark in front runs without it, a Greek question mark (U+037E) runs as `;`, and two mount targets that ES sees as different paths can be one path for the container. Verified from the source of Nomad, HCL and cty at the versions Nomad v2.1.1 pins, not against a running Nomad.
4. **RC31-2, low, bug. Not caused by the repair.** ES accepts `resources.memory_mb` from 1. Nomad v2.1.1 refuses to register a task with less than 10. On the private path such a request takes a claim, is staged, gets its marker and its one POST, and the claim then stays "ambiguous" for good. It is a second road to the kind of spent claim the size check was written to prevent. Verified from Nomad's source; ES's side is measured.
5. **Nothing the two repairs added opens a new road.** What they add is restriction: a caller can no longer pass a literal `${` or `%{` to a workload at all (section 6, O31-2). That is a product choice, stated in the contract, and I think it is the right one for now.

Recommendation. Both findings are small and each comes with a failing test (section 9). Under the project rule that low items are fixed in the PR, they belong in PR #40 before it is fast-forwarded into PR #12: two more conditions next to the new rule for the two driver-configuration fields, and a lower bound of 10 for the memory. Whether a non-normalized argument is refused or normalized before it is bound is the writer's choice; I would refuse, for the reason the writer gave for `${`: ES then never changes a caller's string and never lets Nomad change it either.

## 2. Target identity

| Field | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Re-check target | Draft PR #40, branch `claude/project-thread-ne9cwa-pr12-trunk-dev`, at `fd399a12b5fc8319d403de471bb3ce42446f350c`, tree `dc6e1b6ea6ea34c4fb22020e06f27957a12a3754` |
| Head bytes | Source: run. Fetched `refs/pull/40/head` at 23:02 UTC; commit and tree are the ones `29-repair.md` names. A tree id fixes every byte, so I did not run the manifest recipe again. |
| My earlier tests | Source: run. The five test files of `28-redteam-*.patch` are in the head byte for byte (five equal SHA-256 values, `head/adopted-tests.txt`). |
| The head moved during the pass | Source: run. `ls-remote` gave `fd399a1` for PR #40 at 23:19 UTC and `75d0f5c1c858365bf1f68e7e3887405665f0e29f` (tree `321b195d22b563f1007d52c41a903393fdcfdb3f`) at 23:38 UTC and at 23:52 UTC (`head/ls-remote-close.txt`). The two new commits are `414a5e5` (the repair of A30-1, one test file: `es/admission/reliable_submit_operational_job_bound_test.go`) and the merge of `trunk_dev` `0aa4a2b` (two test files under `es/config`). `git diff fd399a1 75d0f5c` names those three test files and no other file, so every product byte this report judges is the same at both heads (`head/new-head.txt`). PR #12 stayed at `4416699`. |
| What I ran at the new head | Source: run. The finding tests (18 of 18 fail), the writer's and my adopted tests (pass), mutant RM40-1 against the corrected bound test (caught, 3 of 3), and the full `es/admission` suite with the finding file (section 8). Everything else in this report was run at `fd399a1`. |
| `trunk_dev` | `725c97a9663df060e49270fce3bc8c904a88986e` at 23:34 UTC and at the close. It moved twice since the repair merged `400ff7f`: to `0aa4a2b` (PR #33, two test files under `es/config`; the new head has it) and to `725c97a` (PR #41, two test files under `internal/contracts/runtimeconfig/v1`; the new head does not have it). Source: run: trial merges of `fd399a1` and of `75d0f5c` with `725c97a` have no conflict (`head/trunk-dev.txt`, `head/new-head.txt`). I did not test a tree that holds `725c97a`. |
| Environment | Cloud container, linux/amd64, 4 CPUs, Go 1.26.5 (`GOTOOLCHAIN=local`), unprivileged user `ci` (uid 1500), emptied environment, umask 022, `TMPDIR=/opt/ci/tmp`. Scratch clones under `/opt/ci/work/`. |

Posture. Read-only toward every repository: two fetches of PR #40's head, two of `trunk_dev`, and `ls-remote`. All probes, the two mutants and the candidate correction exist only in scratch clones and in the evidence folder. No live service, no third party, no box. I read sixteen more public source files of Nomad, HCL, cty, go-msgpack and `x/text` (`reference-sources.txt`); I ran none of that code.

## 3. Findings at a glance

| ID | Severity | Type | Origin | One line |
| --- | --- | --- | --- | --- |
| RC31-1 | low | contract drift; security risk (latent); bug for file-name arguments | pre-existing on `trunk_dev`; the repair's new contract sentence contradicts it | Nomad drops a leading byte order mark and applies NFC to the arguments and mount targets, so they can still differ from what ES admitted. |
| RC31-2 | low | bug (availability) | PR #12 for the claim; `trunk_dev` for the ordinary path | `memory_mb` 1 to 9 is admitted and Nomad always refuses it; on the private path the claim is spent for good. |
| O31-1 to O31-7 | observation | see section 6 | | No action required by this report. |

RT28-1 and RT28-2 as I reported them are closed. Not mine and not re-tested: A30-1 (the flaky new test, `30-audit.md`), G28-1 and G28-2 (the guard).

## 4. RT28-1's repair: what I tried and what held

The repair (commit `3ddbd2e`): `nomadPassesAsWritten` (`es/admission/service.go:840`) refuses a string that contains `${`, `%{` or NUL. `validateInvocationAgainstManifest` applies it to `output_id` (`:853`), each argument (`:857`), each environment key and value (`:866`); `normalizeRuntimeMountTargetPath` applies it to each mount target (`es/admission/mounts.go:111`).

| # | Attack | Result | Source |
| --- | --- | --- | --- |
| S1 | Another road to a job that skips the rule | None. `buildNomadJobSpec` has two callers, `Submit` (`submit.go:90`) and the provider's `project` (`reliable_submit_operational_provider.go:378`). Both get their plan from `resolveExecutionForSubmit`, which reaches the rule through `prepareAdmission`, `prepareArtifact` and `service.go:628`. Establishment has one caller (`reliable_submit_operational_handoff.go:249`), after `composeOperationalOriginal`, which resolves the same way. `Prepare` refuses the same strings. | reading; run for `Prepare` (`logs/zz-all-3.log`) |
| S2 | Escaped spellings in the private request text: the escapes for `$`, `%`, `{` and NUL in eight combinations, including an escaped doubled `$` | All eight refused with no claim, no reservation, no stage entry and no POST. The rule runs on decoded strings. | run, `TestZZRC31EscapedOpenersPrivatePath` |
| S3 | Invalid UTF-8, an overlong encoding of `$`, unpaired surrogates | The private parser refuses all five as malformed (reason 15) with nothing stored. A valid surrogate pair is accepted and sent as the one character it encodes. | run, `TestZZRC31InvalidUTF8PrivatePath` |
| S4 | A later ES step that creates an opener from checked strings | None found. Arguments are copied (`executionpackage.go:78`; twelve fixed arguments in front, eleven constants and the timeout as a number). Mount targets must already be clean, so `path.Clean` changes nothing, and `strings.TrimSpace` only removes from the ends. Each string is its own JSON string in the job; nothing joins an argument ending in `$` with one starting with `{`. | reading |
| S5 | A string in the job that the rule does not see | Every other string is a constant, a hex name ES makes, a digest whose format is checked (`service.go:818-823`), or operator configuration: image, runtime profile environment, Vault values, staging and SPIRE paths, datacenter, region. Annotations never reach the job; they select between two constant profile names (`runtimeprofile.go:33-48`). The audit said the same of the operator strings; see O31-3. | reading; the writer's marker test passes |
| S6 | The other places where Nomad interpolates | Environment and meta values go through `ReplaceEnv`, which only matches `${name}` (`helper/args/args.go`); environment keys are not interpolated at all (`client/taskenv/env.go:655-657`). So the rule covers them, and is stricter than needed there (O31-2). | reading |
| S7 | The refusal as an oracle or a side effect | The messages are constants that name the field, never the value. On the ordinary path: 400 `invalid_request`, no POST. On the private path: no claim, no reservation, no stage entry, no POST, also on a second delivery and on recovery. | run, `TestZZRC31RefusalClassesPrivatePath`, the writer's tests |
| S8 | Weaker versions of the rule (do the tests hold it) | Mutant RM40-2 exempts the last argument from the rule: 7 subtests of the writer's and 5 of my adopted finding test fail. The writer's own eight mutants are in `29-repair.md`. | run, `logs/RM40-2.log` |
| S9 | A string that changes on Nomad's side without containing an opener | **Found: RC31-1** (section 5.1). | reading for Nomad, run for ES |

## 5. Findings

### 5.1 RC31-1: Nomad still rewrites two kinds of admitted driver strings

**Severity low. Type: contract drift; security risk that is latent today; bug for arguments that are file names. Older than PR #12 and than the repair.**

What the repair claims. `.docs/execution_lifecycle/contracts.md:493` (new in `3ddbd2e`): ES refuses the three sequences "so the workload receives exactly the strings ES admitted". The comment on `nomadPassesAsWritten` says it "reports whether Nomad hands s to the workload exactly as written".

What Nomad does with a string of a task's driver configuration. Source: reading, at the versions Nomad v2.1.1's `go.mod` pins.

1. `client/allocrunner/taskrunner/task_runner.go:943` passes the task's `Config` to `hclutils.ParseHclInterface`, which writes it as JSON and decodes it with HCL (`helper/pluginutils/hclutils/util.go:28-63`).
2. HCL parses every string value as a template: `hcl/v2 v2.20.2-nomad-1`, `json/structure.go:384-410` calls `hclsyntax.ParseTemplate`.
3. The template scanner starts with `stripData := stripUTF8BOM(data)` (`hclsyntax/scan_tokens.rl:21`; `hclsyntax/token.go:325-337`): **a UTF-8 byte order mark at the start of the string is removed.**
4. Every literal part becomes `cty.StringVal(tok.Val)` (`hclsyntax/parser_template.go:91-95`) and the result is again `cty.StringVal(buf.String())` (`hclsyntax/expression_template.go:110`). `go-cty v1.19.0`, `cty/value_init.go:91-110`: strings "are NFC-normalized on entry into the world of cty values", through `cty/ctystrings/normalize.go` (`norm.NFC.String`). **The string is rewritten to Normalization Form C.**
5. The decoded value is what the driver receives (`task_runner.go:950`, `EncodeDriverConfig`).

Of the request strings, the arguments (`Config.args`) and the mount targets (`Config.mounts[].target`) are driver configuration. Environment values, environment keys and `output_id` are not: they do not pass through HCL or cty.

What ES does. Source: run (`logs/zz-all-3.log`, `logs/finding-head.log`).

| Written by the caller | Admitted, bound, shown to the policy and sent as | The workload receives (reading) |
| --- | --- | --- |
| U+FEFF followed by `--flag` | the same seven characters | `--flag` |
| `cafe` followed by U+0301 | the same | `caf` followed by U+00E9 |
| U+212A (KELVIN SIGN) | the same | `K` |
| U+037E (GREEK QUESTION MARK) | the same | `;` |
| U+1FEF (GREEK VARIA) | the same | a grave accent |
| `a`, U+0302, U+0323 | the same | U+1EAD |
| mount targets `/execution/mounts/caf` + U+00E9 and `/execution/mounts/cafe` + U+0301 | two different paths: no 409 `mount_conflict`, both in the job | one path, twice |
| the same pair with `/inner` under the second | accepted | one mount inside the other |

All eleven probe arguments passed `nomadPassesAsWritten`, were accepted on the ordinary path and on the private path (accepted, revision 6, one POST), and are in `Config.args` byte for byte as written. The control, the same mount target twice in one form, is refused with "mount target paths must not overlap".

Why it matters.

- **The argv that runs is still not always the argv that was admitted.** That was the sentence of RT28-1, and of its three harms one is still there in a narrower form: a caller "can spell an argument so that a literal comparison of the argv never sees it". With a byte order mark in front, *any* argument differs from the one an exact or prefix comparison looks for, the mark is invisible in most displays, and the workload receives the argument without it. With normalization, `;`, a grave accent and `K` can be written as other characters. The admission policy interface hands policies the argv as written (`es/admission/policy.go:44`, `:222`, input class `invocation_argv`).
- **Why low and not medium.** Nothing is evaluated and nothing from the node flows into the arguments, which was the larger part of RT28-1. No policy in the tree reads the text of an argument today (Source: reading: the only readers of `InvocationArgv` copy it), so there is no decision to get around yet. It becomes medium the day a policy or a reviewer decides on the text of an argument.
- **A correctness bug without any attacker.** A file name in decomposed form, which is what macOS tools often produce, names a file in the payload. The workload receives the composed form and does not find the file on a Linux file system.
- **A run that ES accepted and that cannot start.** Two binds at one target. Inference: Docker refuses a container with duplicate mount points; I did not verify what the driver does with it.

What I did not find. NFC cannot create an opener: template parsing happens on the bytes before normalization, and no code point normalizes to something that holds `$`, `%`, `{` or NUL, and none normalizes to nothing (Source: run over every code point with Python's Unicode 15.1.0 data, `logs/nfc-ascii.txt`. Nomad's `x/text` carries its own tables; what an assigned character normalizes to is fixed by Unicode's stability policy, and code points assigned after 15.1.0 are not covered by this run). The same run shows how small the set is: exactly three ASCII characters can be written as another character that NFC turns into them, `;` (U+037E), `K` (U+212A) and the grave accent (U+1FEF). Removing a leading mark cannot create one either, because the string after the mark is checked as part of the whole. A lone carriage return is the one more control character I looked at: the scanner has no rule for it and falls back to "the rest is literal" (`scan_tokens.rl`, the block after `write exec`), so the bytes should pass unchanged. Inference; it is on the list for the box (section 10).

Correction, for the writer to choose. The two driver-configuration fields need two more conditions next to the new rule: no U+FEFF at the start, and the string is in NFC (`golang.org/x/text/unicode/norm`, `norm.NFC.IsNormalString`; the module is already in `go.mod` line 23 as an indirect dependency at v0.17.0). The contract sentence and the comment then become true. The alternative is that ES normalizes the two fields itself before it binds them; then ES changes the caller's string, which the repair chose not to do for `${`. A candidate that refuses is in the evidence (`candidates/candidate-fix-RC31.diff`, 13 lines); with it the 14 subtests of this finding pass. It is there to prove the tests, not as proposed code.

One thing the correction has to get right so that it stays true: **the answer to "is this string in NFC" depends on the Unicode version of the tables.** ES's `x/text` v0.17.0 with Go 1.26.5 uses Unicode 15.0.0 (Source: run and reading: build tag `go1.21`, `Version = "15.0.0"`). Nomad v2.1.1 names `x/text` v0.43.0, which uses 15.0.0 when built with a Go before 1.27 and 17.0.0 from Go 1.27 on (Source: reading, the two table files' build tags). Nomad's `go.mod` says `go 1.26.8`, so today both sides most likely agree. Inference; which Go built the Nomad binary on the box is Unknown here, and `go version` on the binary answers it. A later Nomad built with Go 1.27 will know code points that ES's tables do not, and could rewrite a string ES found normal. The rule that does not depend on the other side's version: refuse a string that is not in NFC by ES's tables **or that holds a code point ES's own Unicode version has not assigned.** Unicode's normalization stability policy then guarantees that every later version leaves the string alone. With that second condition no reminder to re-check on a Nomad upgrade is needed.

Tests: `TestRedTeamRecheck31NomadDoesNotRewriteAdmittedArguments` (12 subtests, both paths) and `TestRedTeamRecheck31MountTargetsStayDistinctForNomad` (2 subtests). All 14 fail at `fd399a1` and pass with the candidate.

### 5.2 RC31-2: memory below Nomad's minimum is admitted, and on the private path it spends a claim

**Severity low. Type: bug (availability). In PR #12 for the claim; on `trunk_dev` for the ordinary path. Not caused by the repair.**

The repair's reason for the size check, in the code (`reliable_submit_operational_handoff.go:237-239`): a request whose job could not be sent "would hold its claim slot and its reservation for good, so it is refused here, before anything is stored". There is one more kind of request with that fate that ES can recognize just as early.

- ES accepts `resources.memory_mb` from 1 on both paths: `service.go:812-814` ("must be greater than 0") and `reliable_submit_replay_intent.go:151` (`privateRequiredUint(object, "memory_mb", 1, 2147483647)`). Source: reading.
- Nomad v2.1.1 refuses a task with less than 10: `nomad/structs/structs.go:2401-2407` (`MinResources`: `CPU: 1`, `MemoryMB: 10`) and `:2598-2608` (`MeetsMinResources`: "minimum MemoryMB value is 10; got N"), called from `Resources.Validate` (`:2431`) and that from `Task.Validate`. Source: reading. The CPU minimum is 1, which ES already requires. I found no other check in `Task.Validate` that a request value can fail.
- With `memory_mb` 1, 5 or 9 the private path accepts the request, stores the claim, stages, sets the marker and sends one POST with `"MemoryMB": 5` (Source: run, `TestZZRC31SmallMemoryReachesTheJob`; the suite's Nomad accepts anything).
- When the registration is answered with a status other than 200, the claim stays at revision 5: result "ambiguous", reason `OperationalHTTPRefusal`, one POST, the stage on disk. Four more deliveries and a recovery change nothing and send nothing (Source: run, `TestZZRC31RefusedRegistrationStays`, with a receiver mode that exists only in my scratch clone and answers 500 with Nomad's message).

So on the private path the caller's claim is spent on a run that cannot exist, and the caller hears "ambiguous" forever instead of a refusal. The owner document says that the model does not guarantee a registration's acceptance (lines 1555-1556) and that the proof domain has four claims in total (line 1561), so this is not a break of a stated contract. It is the same waste the size check removes, for a value ES can check with one comparison. On the ordinary path the same request is staged and answered with 503 "execution submission failed" (`submit.go:99-106`) where 400 would be right. Source: reading.

Correction: a lower bound of 10 for `memory_mb` at request validation, with the Nomad version it comes from next to it. The candidate in the evidence does that in one condition; with it the four subtests of `TestRedTeamRecheck31MemoryBelowNomadMinimumIsRefusedFirst` pass. All four fail at `fd399a1`.

The Nomad side of this finding is source reading. The check on the box is one registration (section 10).

## 6. Observations (no finding)

- **O31-1. The two refusals of this round answer differently on the private path.** A string Nomad would rewrite answers `OperationalUnavailable` (reason 1), because every refusal of ordinary resolution does. A job that is too large answers `OperationalMalformed` (reason 15). Both are permanent properties of the request. A caller that retries on "unavailable" retries the first forever. The owner document already names the gate that must settle this, `CP-PUBLIC-MAPPING` (line 1616), and project memory lists it as an open product question. Source: run (`TestZZRC31RefusalClassesPrivatePath`).
- **O31-2. The rule is stricter than Nomad needs in three places, and it is a restriction on callers.** `%{` means nothing to Nomad in environment values and in `output_id`; environment keys are never interpolated. And a caller can no longer pass a literal `${` or `%{` to a workload in an argument at all, for example `curl -w '%{http_code}'` or a shell line with `${HOME}`. For arguments an escape exists (`$${`), for environment values none does, so one uniform refusal is the simple rule that is certainly right. I would keep it. If a workload ever needs such an argument, escaping in the job builder is the way, with the escaped form in the job and the written form in the binding.
- **O31-3. Operator strings go through the same Nomad machinery unchecked.** The audit noted that the image, the profile environment, the Vault values and the host paths are not checked. Two more facts for whoever writes the operator documentation: a staging root that is not in NFC would be normalized in the bind sources and in the command path, and `${` in a profile environment value would be replaced. These are the operator's own strings; no caller can set them.
- **O31-4. Nomad rewrites environment keys with five prefixes.** Keys that start with `NOMAD_ADDR_`, `NOMAD_IP_`, `NOMAD_PORT_`, `NOMAD_HOST_PORT_` or `NOMAD_META_` are cleaned to letters, digits and underscores (`client/taskenv/env.go:676-687`). ES does not reserve `NOMAD_` (`service.go:86-89`), so an artifact whose evidence declares such a key and a caller who sets it get a different key in the workload. It needs the publisher's signed declaration, so I list it and nothing more. Source: reading.
- **O31-5. The stricter mount rule is also applied when stored records are read and when a resolved plan is bound** (`reliable_submit_replay_hydration.go:298`, `reliable_submit_binding.go:364`). A stored record whose mount target holds an opener would now read as unavailable. Inference: no such record exists in a store David owns, because the private path takes no mounts (`validateOperationalPlan`) and the public keyed path is refused structurally. If RC31-1 is corrected in the same function, the same holds for the new conditions.
- **O31-6. No store predates the two rules.** A claim established before the repair with an opener or an oversize job would not be caught by the new checks, which run at first delivery only. Inference: PR #12 was never merged or deployed, so there is none.
- **O31-7. `trunk_dev` moved twice during the audit and this pass**, to `0aa4a2b` (PR #33) and to `725c97a` (PR #41), test files only both times. PR #40's new head holds the first. The trial merge with the second is clean. The branch must hold `725c97a` before the fast-forward because ES requires up-to-date branches.

## 7. RT28-2's repair: what I tried, and the writer's three questions

The repair (commit `39e6eb7`): `operationalProvider.fits` (`reliable_submit_operational_provider.go:443-452`) runs the real `project` and the real `request` with a stage, a job name and a correlation value of the lengths every run has; the handoff asks it at `reliable_submit_operational_handoff.go:240`, after composing the original and before `EstablishOperational` (`:249`).

| # | Attack | Result | Source |
| --- | --- | --- | --- |
| B1 | Requests at the bound that the check and the projection judge differently | None in 120 trials (seeded). For each trial I measured the largest plain value that fits on that fixture, then built a random mix of 22 kinds of characters (plain, `<`, `>`, `&`, control bytes, quote, backslash, the five short escapes, U+2028, U+2029, DEL, two-, three- and four-byte characters, lone `$`, `%`, `{`) whose `encoding/json` length is the bound plus a delta from -3 to +3, as one argument, three arguments, one hundred arguments or an environment value. `fits` said yes exactly when delta was at most 0, all 120 times. 70 completed with one POST and a second delivery read the same receipt; 50 were refused as `OperationalMalformed` with the same store state before and after: no claim, no reservation, no stage entry, no POST. | run, `TestZZRC31BoundDifferential`, `logs/zz-all-3.log` |
| B2 | Something in the job after the assignment that is longer than what `fits` measured | Nothing. The run name enters the job as `run_id` (twice), `EXEC_RUN_ID`, the stage paths and the identity paths; the job name as `ID` and `Name`; the correlation value in `Meta`. All three are hex of fixed length (`OperationalLocatorShape`, and 64 hex digits). `fits` and the projection at `:373-374` use the same `original.resolved` in the same call. | reading; B1 |
| B3 | A projection failure other than size that `fits` misses | None: `fits` is not a size formula, it runs `project` and `request` themselves, so the node count, the depth, the string bound and the template rendering are all asked before the claim. | reading |
| B4 | An effect of the check itself | None. `fits` writes nothing and sends nothing. A refused request leaves the store, the stage directory and the receiver untouched, also when delivered again and on recovery. | run |
| B5 | A check that measures a little short | Mutant RM40-1 shortens the two names in `fits` by one byte: the writer's bound test fails in 3 of 3 subtests with exactly the old end state (claim at revision 2, reason 8). | run, `logs/RM40-1.log` |
| B6 | Another deterministic refusal after the claim | **Found: RC31-2** (section 5.2). I found no other one: staging depends on the payload, which resolution already bounded, and on the host. | reading; run |

The three questions of `29-repair.md`, section 9.

1. **Does any other request string reach the job, and can one be evaluated without `${` or `%{`?** No other request string reaches the job (S5). None can be *evaluated* without an opener (S2, S4, S6). Two kinds are *rewritten* without one: RC31-1. **Is refusing right for `output_id`?** Yes. It reaches the task's meta, where Nomad replaces `${name}` and has no escape form; and the request's value must equal the evidence's (`service.go:617`), so an output id with an opener is an artifact nobody can run, which is the honest answer.
2. **Can the job or the body after the assignment be larger than what `fits` measured?** No (B1, B2).
3. **Is Nomad's answer ever longer than the form ES measures, and was keeping the `encoding/json` measure right?** It is never longer, and it was right. Source: reading. Nomad's HTTP API writes answers with `structs.JsonHandleWithExtensions` (`command/agent/http.go:862`), which sets `HTMLCharsAsIs: true` (`nomad/structs/handlers.go:18-20`). The string writer of `go-msgpack v2.1.5` (`codec/json.go:516-582`) then writes `<`, `>`, `&` as one byte where `encoding/json` writes six; quote, backslash and the five short escapes as two bytes, as `encoding/json` does; other control bytes, U+2028 and U+2029 as six bytes, as `encoding/json` does; everything else as it is. So per string Nomad's form is at most as long. The answer is then at most the expanded template (at most 65,536 bytes) plus the job's strings (at most 65,536 in the measured form) plus the eight fields ES removes, well under the 262,144-byte bound of the read.
   **The two surviving mutants F3 and F4 are equivalent.** The canonical POST body is the job in a form that is never longer than the measured one, plus a wrapper of about 60 bytes and the correlation entry of about 90. A job within 65,536 bytes therefore gives a body far below 131,072, with any correlation value. The body check in `fits` can never be the one that refuses. It is harmless, and it keeps `fits` true to its sentence.

## 8. What I ran

| Run | Command or test | Result | Log |
| --- | --- | --- | --- |
| Adopted and new tests at the head | my two finding tests of pass 28, the writer's seven new tests in `es/admission`, the contract test in the root package | all pass (66 `PASS` lines) | `logs/head-targeted.log` |
| String probes | seven `TestZZRC31*` tests | all pass; as described in sections 4 and 5.1 | `logs/zz-all-3.log` |
| Size differential, small memory, refused registration | three `TestZZRC31*` tests | all pass; 120 of 120 consistent; as described in 5.2 | `logs/zz-all-3.log` |
| Finding tests at the head | `-run TestRedTeamRecheck31` | 18 of 18 subtests fail | `logs/finding-head.log` |
| Finding tests with the candidate | the same | 18 of 18 pass | `logs/finding-candidate.log` |
| Mutants | RM40-1, RM40-2 against the repair's tests and my adopted ones | both caught | `logs/RM40-1.log`, `logs/RM40-2.log` |
| Full `./es/admission/...` at clean `fd399a1` | `go test -count=1 -json` | 3720 pass, 15 skip, 3 fail: the three environment-limited tests named below | `logs/base-admission-all.json.gz` |
| Full `./es/admission/...` at `fd399a1` plus the finding file | the same | 3720 pass, 15 skip, 24 fail: the same three, and my three tests with their 18 subtests. No test has a different result in the two runs. | `logs/final-admission-all.json.gz`, `logs/suite-compare.txt` |
| Root package, clean `fd399a1` and with the file | `go test -count=1 -json .` | 2465 pass, 38 fail in both: the same eight tests with the same 30 subtests, named below | `logs/base-root.json.gz`, `logs/final-root.json.gz` |
| `go vet ./es/admission/...`, `gofmt -l es/admission` with the file | | both empty, exit 0 | `logs/final-vet.txt`, `logs/final-gofmt.txt` |
| At the new head `75d0f5c`: the targeted tests, the finding tests, mutant RM40-1 | as in the rows above | targeted: all pass (18 top-level tests, among them the corrected bound test); finding tests: 18 of 18 fail; RM40-1: caught, 3 of 3 subtests of the bound test fail | `logs/newhead-targeted.log`, `logs/newhead-finding.log`, `logs/newhead-RM40-1.log` |
| Full `./es/admission/...` at `75d0f5c` plus the finding file, with `go vet` and `gofmt -l` | the same commands | 3720 pass, 15 skip, 24 fail: the same three and my 21 entries. No test has a different result than at clean `fd399a1`. `go vet` and `gofmt -l` empty. | `logs/newhead-admission-all.json.gz`, `logs/newhead-vet.txt`, `logs/newhead-gofmt.txt` |

The failures that are not mine are limits of this container. They are the same at the clean head and with the file (Source: run, `logs/suite-compare.txt`).

- In `es/admission`, three tests ask for a probe of an older ES build, which the environment has to supply and this container does not have: `TestOperationalHandoffSchema4BinaryRefusesSchema5` ("authenticated schema-4 opener is required"), `TestSQLiteV3OldBinaryRefusesWithoutMutation` ("old PB1 production-source probe is required") and `TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation` ("authenticated schema-3 production-source probe is required"). The same three failed at PR #12's head in pass 28.
- In the root package, eight tests of the remote-alpha operator scripts. Three stop at a lookup of the local user `ds`, which this container does not have (`TestRemoteAlphaP0tGrammarDiagnosticBootstrapLifecycleComposition`, `...PriorReaderCloseSuppression`, `...V2VersionedBootstrap`). Two stop at the path `/private/tmp`, which does not exist here (`TestRemoteAlphaESServiceTLSStatusRootLoadedStageCustody`, `TestRemoteAlphaOperatorRecoverySessionESTLSStatusRemoteWrapperTrap`). Three do not name their cause in the output (`TestRemoteAlphaESServiceTLSStatusFailureWitnessBootstrapOwnedTerminal`, `TestRemoteAlphaESServiceTLSStatusStageFIFOSubstitution`, `TestRemoteAlphaOperatorRecoverySessionESTLSStatusStageFIFORefusal`). Inference: the same two lacks, since they exercise the same stage directory. I did not look further: my file is in package `admission` and cannot change a result of the root package, and the two runs agree test for test.
- 44 subtests of three kill-timing tests carry a random delay in their names, so their names differ from run to run. All pass in every run.

Earlier runs, kept for the record and not relied on: `logs/earlier/`. The first size test predicted the environment-value case with a hand count that was off by a few bytes (six false alarms in 60 trials, every one a request that fit and completed); I replaced the hand count by a measurement on the fixture. The first string test did not escape what it meant to escape in the request text, and had no byte order mark case.

## 9. Tests delivered

`31-redteam-recheck-finding-tests.patch`, next to this report: one new file, `es/admission/nomad_request_strings_redteam31_finding_test.go` (SHA-256 `d97689b9d327c95c0308460b3c75bfc156c350a1ec8a1a5acdbb66fcdefec1cf`), three tests, 18 subtests, all failing at `fd399a1` and at `75d0f5c`. The patch applies to both.

| Test | Finding | Subtests |
| --- | --- | --- |
| `TestRedTeamRecheck31NomadDoesNotRewriteAdmittedArguments` | RC31-1 | 12: six strings on the ordinary and on the private path. Passes when the request is refused before any effect, or the job carries the form the workload receives. |
| `TestRedTeamRecheck31MountTargetsStayDistinctForNomad` | RC31-1 | 2: the same path and a nested path after normalization. Passes when the pair is refused and nothing is sent. |
| `TestRedTeamRecheck31MemoryBelowNomadMinimumIsRefusedFirst` | RC31-2 | 4: `memory_mb` 1 and 9 on both paths. Passes when the private path stores no claim and the ordinary path answers 400 and sends nothing. |

The file uses the writer's helpers `nomadStringsFixture` and `nomadStringsSubmit` and mine from pass 28. It imports nothing new. Its non-ASCII characters are written as Go escapes. It is one more path under `es/admission`, so the writer's path reconciliation has to name it, as it did for the earlier ones. With the file in place the rest of the package behaves as at the clean head (section 8).

## 10. Coverage this environment could not provide, and what I did not do

- **No running Nomad.** Everything this report says about what Nomad does is read from the source at v2.1.1 and at the versions of HCL, cty and go-msgpack that its `go.mod` pins. That includes both findings. A session like this one may not download and run the binary, and I did not run the HCL or cty packages as a substitute.
- **The checks for the Linux box**, which need David's go. One job with the Docker driver that prints the bytes of its arguments, with these five: U+FEFF followed by `--flag`; `e` followed by U+0301; U+212A; `a`, carriage return, `b`; and, to close the open check of pass 28, `${attr.kernel.name}` sent to Nomad directly, since ES now refuses it. Then one registration with `MemoryMB` 5, to read Nomad's answer and its status code. And `go version` on the box's Nomad binary, which says which Go built it and so which Unicode tables it carries (section 5.1).
- **Docker with two binds at one target.** Inference only.
- **The guard** (G28-1, G28-2) is left aside as the brief says. **A30-1** is the audit's and is being repaired separately; my size test does not depend on the length of the temporary path because it measures the bound on each fixture.
- **A tree that holds `trunk_dev` `725c97a`** was not tested, only trial-merged. The new head `75d0f5c` holds `0aa4a2b`; at that head I ran the `es/admission` suite and not the other packages, so the two `es/config` test files that came with the merge are not covered by me.
- **The repair of A30-1** (`414a5e5`) is the audit's to judge. I saw its test pass in the targeted run and in the full run at the new head, both with `TMPDIR=/opt/ci/tmp`; I did not repeat the audit's 30 runs under `/tmp`.
- I did not repeat the long runs of pass 28 (fence races, process kills, fuzzing). The repair does not touch the code they exercise, and the adopted tests run in the full suite above with their default round counts.

## 11. Sensitive material

The evidence folder holds logs of the suite, my scratch tests, two mutants and one candidate diff. I scanned it with the same pattern scan as in pass 28 (`scripts/scan.py`): the 66 files of the folder, the patch and this report. No private key, no GitHub, Anthropic, OpenAI or AWS key shape, no JWT, no e-mail address and no phone number. 54 hits of the Vault-token shape, all in the three root-package logs: a placeholder made of the letters a to z after the prefix, in the names of subtests of two repository tests that check that such a string is refused as a target. Not a token. One certificate-header hit and four model-name hits are the scan script's own patterns. A second pass for LAN addresses, home-directory paths of a person and session links found none (the counts are in the folder's README).

## 12. Confidence

- High that no opener and no NUL reaches a Nomad job: one rule, one road, measured on both paths, and held by tests that two independent sets of mutants do not get past.
- High that the size check and the projection agree: they are the same code with names of the same length, and 120 random cases at the bound agree.
- High for the ES side of both findings (measured). Medium-high for the Nomad side: the code paths are short and I cite each step, but I have not seen them run.

## 13. How to reproduce

1. `git fetch origin refs/pull/40/head` and check out `fd399a12b5fc8319d403de471bb3ce42446f350c` (tree `dc6e1b6ea6ea34c4fb22020e06f27957a12a3754`).
2. `git apply 31-redteam-recheck-finding-tests.patch`, then `go test -count=1 -run TestRedTeamRecheck31 ./es/admission/`: 18 subtests fail. The patch applies in the same way to `75d0f5c1c858365bf1f68e7e3887405665f0e29f`, with the same result.
3. For the probes: copy `scratch/zz_rc31_strings_test.go` and `scratch/zz_rc31_bound_test.go` into `es/admission/` (drop the `.txt`), apply `scratch/receiver-refuse500.diff` for the refused-registration test, and run `go test -count=1 -v -run TestZZRC31 ./es/admission/`.
4. For the proof of the tests: apply `candidates/candidate-fix-RC31.diff` and run step 2 again: 18 pass.

## 14. Effect status

Read-only pass. Nothing committed, pushed, commented or merged. No live system touched. Files written: this report, one patch and one evidence folder under `/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/`.
