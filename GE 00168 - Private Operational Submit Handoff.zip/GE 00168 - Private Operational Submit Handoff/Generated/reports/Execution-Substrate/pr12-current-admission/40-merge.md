# MERGE REPORT: PR #12 (private operational submit handoff) into trunk_dev

Writer: the PR #13 thread. Date: 2026-11-24, 06:56Z.

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| PR | #12 (https://github.com/evo-agi/Execution-Substrate/pull/12), "Add private operational submit handoff", head branch `codex/reliable-submit-operational-handoff-v1` |
| Accepted head | `7324b62968ee4c93b5d8e4fe71532c7d7c51f383`, tree `ca8f4ca71672959dd25c9573c2452309c75b0fcf`, 70 paths against `trunk_dev` (`trunk_dev`-relative manifest `1a56860c8bf8f406ef347fa74b7abd6ebff085b534647f047ec49bdcbfe6bd3e`) |
| Checks | Combined check `36-combined-check.md` (ACCEPT at `f7bb1d6`); final red-team re-check `36-redteam-recheck.md` (no finding at `f7bb1d6`); diff-only check of the final sync `38-final-sync-check.md` (ACCEPT at `7324b62`, no findings). Earlier rounds: `12-audit.md` to `33-recheck.md` |
| Branch | Fast-forwarded to `7324b62` at 06:17:02Z (`39-pr12-fast-forward-7324b62.md`) |
| CI | PR #12's run 45339314263 of `build, vet and test`, success on `7324b62` (06:17Z to 06:53:44Z); PR #47's run 45333412400 also green on the same commit |
| Gate (06:54:42Z) | `git ls-remote` just before: PR #12's head `7324b62`, `trunk_dev` `5d6ad51`, an ancestor of the head; GitHub mergeable state clean; the one review thread (Codex, current admission) resolved and outdated; no draft |
| Authority | Product merges need a fresh audit, a red-team where required and the merge gate (project merge policy; David's product reviews were done). The coordinator asked for this merge at 05:08Z and 05:23Z, with every other merge into `trunk_dev` held until it |
| Effect | Squash merge with expected head `7324b62`: `trunk_dev` is `a60c216f5f6f19794f7848555d255b065e19e0d7`, tree `ca8f4ca71672959dd25c9573c2452309c75b0fcf`, equal to the accepted head's tree; parent `5d6ad51`. GitHub deleted the head branch. The merge tool accepted it without asking for David's word |
| Unauthorized effects | None. PR #12's description was not edited; it still describes the branch as of 2026-11-23 |

## What changes for users of `trunk_dev`

- New refusals with `400 invalid_request` on the ordinary submit path: `${`, `%{` or a NUL byte in an argument, environment value, output id or mount target; a leading byte order mark, a string not in Normalization Form C, or a code point unassigned in the tables' Unicode version, in an argument or mount target; `resources.memory_mb` below 10. The execution lifecycle contracts state them.
- The private operational handoff is present but unwired. A maintained gate fails on its first production caller and names seven commissioning prerequisites.

## Remaining

- `box-live-checks.md`: Parts A and C in the coordinator's box order; Part B now that PR #12 is in `trunk_dev`, once ES built from it runs on the box.
- PR #12's description is stale. Updating it needs David's own word.
