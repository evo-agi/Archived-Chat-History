# Draft: section to add at the top of PR #12's description

Not applied: editing PR #12's description needs David's go. The existing description stays below this section, unchanged, under the heading "Original description".

## Current state (2026-11-23)

The original description further down describes the first source commit, `8058561`, only. Its identity, path counts and validation figures do not describe the current head.

- **Head.** `2c8bf35f30877bc3749b1799be686bf108a1cf8d`, tree `df3ff9dd042462534cb2eaece56295b78a6f018d`. It differs from `trunk_dev` `036d507` in 56 paths.
- **CI.** Run 45219219689 passed on this head.

### How the branch got here

1. **`8058561`:** the private operational-submit handoff source slice described below.
2. **PR #13** (fix for this PR) was merged into this branch as `6288b63` on 2026-11-23, after independent audits and David's approval.
   - Current admission is now re-checked for retained operational handoffs. Every first-effect cut re-reads the current operational admission (`qualify` and `currentOperationalAdmission` in `es/admission/reliable_submit_operational_handoff.go`). This answers the Codex review thread on that file.
   - Guard hardening: line directives, raw-memory imports and position reads.
   - The red-team's regression tests were adopted.
   - The final audit accepted `e060449`.
3. **A red-team** of the combined change found that it HOLDS WITH CAVEATS. Its finding RT2-1, and two more raw-memory roads, were closed in PR #13.
4. **PR #28** merged `trunk_dev` `036d507` into this branch: merge `f36911c`, plus follow-up `2c8bf35`. The follow-up added the test startup file, real position reads and two CI list lines. The audit accepted it with no findings, and the branch was fast-forwarded to `2c8bf35` at 16:40Z.

The reports are in the project folder, under `reports/Execution-Substrate/pr12-current-admission/`: `12-audit.md` to `21-audit-pr28.md`, plus `13-red-team.md`.

### What remains before this merges into `trunk_dev`

1. **PR #26.** This test-only guard fix is in its last re-audit. Once it lands on `trunk_dev`, this branch takes `trunk_dev` again. Two small known blocks in `es/admission/workstream_a_guardrails_test.go` will conflict: keep this branch's `source:` line and add PR #26's `node:` and `syntax:` lines. This was tested on a trial merge with PR #26's head `06ec54b`: es/admission gave 2,529 pass and 0 fail.
2. **PR #29** (artifact byte verification). Whichever of #29 and #12 lands second re-runs `TestFetchVerifiedARSBlobIsTheOnlyARSBlobReadInES`.
3. **A second red-team** of the combined change, planned for around 2026-11-27. Its starting inventory is section 6 of `13-red-team.md`.
4. **A fresh merge gate** on the final head, then the merge into `trunk_dev`.

