# REPAIR AFTER THE RED-TEAM OF PR #12 + #13: RT2-1 closed, two more raw-memory roads found and closed, the red-team's tests adopted

Status of this file: **IMPLEMENTATION REPORT, NOT AUDITED.** It covers four commits after `51d6d5f`. `13-red-team.md` is the red-team that asked for them, and `11-repair.md` plus `13-repair.md` stay the reports of everything up to `51d6d5f`.

Written by the PR #13 writer thread (the Opus continuation) on 2026-11-23 (UTC). Readers: the coordinator, David, the narrow audit that judges this delta, and the later Fable red-team.

---

## 1. In plain words

The red-team of the combined PR #12 at `bff8dda` found that the behaviour holds and left one low finding, **RT2-1**: a production file can import `modernc.org/libc`, which the SQLite driver brings into the build, and clear the stop latches of the admission state with its `Xmemset`, with no `reflect`, `unsafe` or `C` import. The guard did not see it.

While closing RT2-1 I found **two more roads of the same class**, and measured both. Each reopened a withdrawn Service, which then sent a job, at the previous tip `51d6d5f`, and the whole guard passed with the probe files in place:

- **Road 1, a reviewed dependency:** `golang.org/x/sys/unix.MmapPtr` returns an `unsafe.Pointer`. Such a value converts to a pointer of any type in any file, with no `unsafe` import. With `MAP_32BIT` the mapping lies below the Go heap, and an index into a large array type from it reaches the state.
- **Road 2, the standard library alone:** `json.Unmarshal` returns a `*json.UnmarshalTypeError`, whose `Type` field is a `reflect.Type`. Its `.Method(0).Func.UnsafePointer()` hands out a code pointer, and the same index reaches the state. The file imports neither `reflect` nor `unsafe`.

The old writer had also reported a second road for RT2-1, `protoimpl.Pointer` (a type whose underlying type is `unsafe.Pointer`). I measured it the same way; it works too.

An allowlist of dependency packages alone could not hold road 1 (the package is on the list) or road 2 (no dependency at all). So, with the coordinator's agreement (10:35Z), the guard now has **three rules** where it had one:

1. **The import inventory** counts `plugin` as well as `reflect`, `unsafe` and `C`, and **every dependency package that is not on a reviewed list**. That closes RT2-1, its protoimpl variant, and any new dependency.
2. **The reviewed list** has 11 packages, each pinned to the **module and version** whose exported API I reviewed (section 5). A new dependency import, a further package of a listed module, a new version, and a `replace` each fail a test until the list is changed. The pin is the machine trigger for re-reviewing a dependency.
3. **A new raw pointer rule** reads the type of every expression and every declared or used name in every production package, for all three build targets, and refuses a value whose type has the underlying type `unsafe.Pointer` (or a function or tuple type carrying one) in a file that does not import `unsafe`. That closes roads 1 and 2 and every road like them that hands out such a value, from any package. A file that does import `unsafe` is held by the import inventory and its hash, as before.

Raw system calls get **no inventory**, as the brief said. The owner document now names them as part of the operating-system limit (A5-1). It no longer claims that the import names every file that can write past the typed inventories: it says so for every road known here, and that a source inventory cannot show that no other road exists.

The **red-team's tests are adopted** as permanent tests: its 11 behaviour tests, its SIGKILL test, its RT2-1 guard test (with protoimpl added), and its three tests of documented limits, renamed `TestOperationalLimit*`. These are four new test files, so the path ceiling in the owner document goes from 48 to 52 files, with the reconciliation paragraph and its pins. **O5-1** is done: the comment in `state.go` says only an untyped nil owner gets the closed handle, and the guard's hash pin of that file follows.

Nothing changes behaviour, stored formats or public contracts. One production file changed: a comment in `state.go`.

**What I did not do:** the red-team's other follow-ups (A-30 in-place `*s.trustModel`, MU6 root-swap window, double crash, longer fuzzing) are not in this batch; they are listed in section 10 for the Fable red-team. Nothing was merged. Only `claude/project-thread-sqldt7` was pushed.

## 2. Identity

| Field | Value |
| --- | --- |
| Objective | Close RT2-1 with a general rule; close the two further roads found while doing so; name raw syscalls in the OS limit; O5-1; adopt the red-team's tests |
| Repository | `evo-agi/Execution-Substrate` |
| Base ref and SHA | `codex/reliable-submit-operational-handoff-v1` at `8058561edc08356c46680c204586b3c7796c0ff3` (the PR #12 branch) |
| Previous tip | `51d6d5fcb5d7e59e70fd53e1cd2801044a03e23a` (documents-only change after the fifth audit); last audited tip `bff8dda37dbf5484afb3b264d4eca38cf6abf118` |
| Topic branch | `claude/project-thread-sqldt7` (draft PR #13) |
| Topic commit SHA | `8e1f539613b85511b537e52b376aad88ab4af643` |
| Tree SHA | `5dd0af054e351315789d375dec15b29d6eaac01c` |
| Commits after `51d6d5f` | `2849293` Say in the admission state file which owner gets the closed handle; `582ae7d` Hold dependency packages to a reviewed list and raw pointers to the unsafe import; `98fa8f5` Adopt the red-team's behaviour, crash and limit tests as permanent tests; `8e1f539` Name the reviewed list, the raw pointer rule and raw system calls in the documents |
| Scope | 32 paths against the base (28 before), 52 against the trunk merge base `ae326b0` (48 before); the four new paths are the adopted test files |
| `trunk_dev` | `bc9fe36` when validation started; `ea86a96` (PR #19 merged at 11:34Z) at the end. The tip merges `bc9fe36` without conflict; `ea86a96` gives one adjacency conflict in `docs_contract_test.go` that `51d6d5f` has as well (section 7.4) |
| Toolchain | Go 1.26.5 (`GOTOOLCHAIN=local`), linux/amd64 container, runs as an unprivileged user `ci` with an emptied environment |
| Recipe | `governed_execution_audit_patch_manifest_v2.py`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified before every run |

## 3. New findings (targets for the narrow audit and the Fable red-team)

| ID | What | Measured how | Effect at `51d6d5f` | Held now by |
| --- | --- | --- | --- | --- |
| **R14-1** (road 1) | `golang.org/x/sys/unix.MmapPtr` returns `unsafe.Pointer`. With `MAP_32BIT` (linux/amd64) the mapping is below the heap; `(*[1<<47]byte)(base)[address-base]` writes the latches | Probe file importing only `golang.org/x/sys/unix`, plus a probe test (`14-repair-evidence/probes/`) | A withdrawn Service (local latch set, durable write failed) was reopened and sent a job: `kind=5 operation=8 write=11 run=true receipt=true`. `go vet` clean. Whole `es/admission` suite with the probes: all pass, so the guard was blind | Raw pointer rule (refused in every view that compiles the file); 4 overlay roads in the rule's test (direct, pointer discarded, as a function value, through a generic function) |
| **R14-2** (road 2) | Standard library only: `json.Unmarshal` gives `*json.UnmarshalTypeError`; its `.Type` is a `reflect.Type`; `.Method(0).Func.UnsafePointer()` is a code pointer below the heap | Probe file importing `encoding/json`, `errors`, `fmt`, `strconv`, `strings`, `time` | Same as R14-1 | Raw pointer rule; 4 overlay roads (direct, passed on at once, through an interface value and a type assertion, in a field of a generic type) |
| **R14-3** (RT2-1 variant, reported by the old writer) | `google.golang.org/protobuf/runtime/protoimpl.Pointer` has underlying type `unsafe.Pointer`; `protoimpl.Pointer(address)` converts an integer to a pointer | Probe file importing only protoimpl | Same as R14-1 | Import inventory (protoimpl is not on the reviewed list) and the raw pointer rule; RT2-1 test extended |
| **R14-4** (correction of the red-team's A-26 reading) | A-26 read that `x/sys/unix` "reaches memory only through system calls", that protobuf's reflective code reads only tagged fields, and listed `encoding/json` among the packages it read without finding a road. R14-1, R14-3 and R14-2 show a road through the language in each | As above | — | — |
| **R14-5** (found by the API scan, not probed) | `modernc.org/sqlite` exposes `Page.Buf()` and `Page.Extra()` returning `unsafe.Pointer`, and reaches `reflect.Type` through `database/sql.ColumnType.ScanType` | `14-repair-evidence/scan/` | Not run | Raw pointer rule; the `Page.Buf` road is an overlay subtest |

How the probes find the address without `unsafe`: `fmt.Sprintf("%+v", s)` prints the pointer inside the state handle. The probes work on linux/amd64; road 2 needs code mapped below the heap, which I measured only there.

## 4. What changed

| File | Added | Removed | Commit |
| --- | --- | --- | --- |
| `es/admission/internal/admissionstate/state.go` | 3 | 2 | `2849293` (comment only) |
| `es/admission/workstream_c_guardrails_test.go` | 645 | 15 | `2849293` (hash pin), `582ae7d` |
| `es/admission/reliable_submit_operational_admission_redteam2_guard_test.go` (new) | 78 | 0 | `582ae7d` |
| `es/admission/reliable_submit_operational_admission_redteam2_test.go` (new) | 590 | 0 | `98fa8f5` |
| `es/admission/reliable_submit_operational_admission_redteam2_crash_test.go` (new) | 120 | 0 | `98fa8f5` |
| `es/admission/reliable_submit_operational_admission_limits_test.go` (new) | 160 | 0 | `98fa8f5` |
| `.docs/execution_lifecycle/reliable_submit_operational_handoff.md` | 66 | 13 | `8e1f539` |
| `PLANS.md` | 33 | 0 | `8e1f539` |
| `docs_contract_test.go` | 47 | 1 | `8e1f539` |

### 4.1 The import inventory (`582ae7d`)

`operationalGuardInventoriedImport(path)` decides what the inventory counts: `reflect`, `unsafe`, `C` and `plugin` always; a dotless path (the standard library and the module itself, by the go command's own rule) never; any other path unless it is a key of `operationalGuardReviewedDependencyPackages`. The test was renamed `TestOperationalGuardImportInventoryIsExact` (the exact inventory is unchanged: the two `unsafe` files). New mutation cases, each of which must change the inventory: `plugin`; `modernc.org/libc` plain, renamed and blank; protoimpl; a further package of a reviewed module (`modernc.org/sqlite/lib`); a dependency nobody reviewed. New controls that must not: a reviewed dependency (`x/sys/unix`), a package of the module, and `syscall`, `os`, `encoding/json`.

### 4.2 The reviewed list (`582ae7d`)

`operationalGuardReviewedDependencyPackages` maps each of the 11 dependency packages that production files import to `module@version`:

| Package(s) | Pin |
| --- | --- |
| `github.com/go-jose/go-jose/v4`, `.../jwt` | `github.com/go-jose/go-jose/v4@v4.0.4` |
| `github.com/spiffe/go-spiffe/v2/proto/spiffe/workload`, `.../spiffeid`, `.../svid/jwtsvid`, `.../workloadapi` | `github.com/spiffe/go-spiffe/v2@v2.4.0` |
| `golang.org/x/sys/unix` | `golang.org/x/sys@v0.46.0` |
| `google.golang.org/grpc`, `.../codes`, `.../status` | `google.golang.org/grpc@v1.67.1` |
| `modernc.org/sqlite` | `modernc.org/sqlite@v1.54.0` |

`TestOperationalGuardReviewedDependencyPackagesAreExact`: the dependency imports of all production source files equal the list's keys (both directions); `go list` metadata for darwin/arm64, linux/amd64 and linux/arm64 shows every listed package, from a module that is not replaced and whose `path@version` equals the pin; a dotless import is standard or from the main module; a dotted import is not reported standard. Mutation subtests, each checked against its own reason text: a new version, a replaced module, the package from another module, a package taken off the list, a dotless path from a module, a dotted path reported standard, a listed package not reported, a package without a module, and a new dependency import in a source file.

### 4.3 The raw pointer rule (`582ae7d`)

`operationalGuardRawPointerType(t)` is true when `t.Underlying()` is `unsafe.Pointer`, or when `t` is a tuple or signature with such a parameter or result (recursively). `operationalGuardRawPointerSites(pkg)` reads `info.Types` (every expression), `info.Defs` and `info.Uses` (every declared and used name) and returns sorted `line:col type` per file. `validateOperationalRawPointerFiles` refuses every file with a site that does not import `unsafe`, in a stable order, all files at once.

`TestOperationalGuardRawPointerValuesNeedTheUnsafeImport`:

- The real repository passes in all three views, and a floor requires sites in both files that import `unsafe` (`execution_roots_darwin.go`, `privilege_linux.go`), so the rule is shown to read something.
- Ten roads, each written into `es/admission/service.go` as an overlay in the linux/amd64 view: `MmapPtr`; `MmapPtr` with the pointer discarded; `MmapPtr` as a function value; road 2; road 2 passed on at once; a raw pointer through a generic function; through an interface value and a type assertion to an inferred type parameter; from an interface method (`modernc.org/sqlite.Page.Buf`); in a field of a generic type; `protoimpl.Pointer`. Each must be refused, and each has a control: the same file with `import _ "unsafe"` added passes the rule and is held by the import inventory.
- "expressions and names are both read" pins the exact sites of one road: the call expression (from `Types`), the declared name (`Defs`) and the selector (`Uses`).
- "an integer address does not convert to a pointer": the type checker refuses `(*T)(uintptr)`.
- "integer addresses from reflect.Value.Pointer and UnsafeAddr" (the coordinator's check): `uintptr` results are not refused, by design. An integer cannot become a pointer without a value of raw pointer type, which the rule refuses. Handing the integer to a system call is the OS road (section 6).

### 4.4 The adopted tests (`98fa8f5`, and the RT2-1 test in `582ae7d`)

Taken from `13-red-team-evidence/tests/` and `characterization/` after checking their SHA-256 against the red-team's `SHA256SUMS`. The diffs against the originals are in `14-repair-evidence/adopted-tests/`:

- `..._redteam2_test.go`: the 11 behaviour tests (A-1 to A-12 and A-14), unchanged except the header, which now credits the red-team. The claim-progress raw-write subtest of A-9 is kept as delivered; the red-team noted its writes also fail CHECK constraints, and the writer's `TestOperationalAdmissionClaimGuardsByRawSQL` covers that clause with well-formed writes.
- `..._redteam2_crash_test.go`: `TestRedTeamPR12CombinedSIGKILLAtRandomInstants` (A-13), unchanged except the credit. 24 rounds (6 with `-short`), random kill instants, seed logged; it asserts invariants, not a particular outcome.
- `..._redteam2_guard_test.go`: the RT2-1 test, with credit and `google.golang.org/protobuf/runtime/protoimpl` added to its roads (5 imports × 9 forms = 45 subtests).
- `..._limits_test.go`: the three characterization tests L1 to L3, renamed `TestOperationalLimitStartupOnlyTrustOnTheOrdinaryPath`, `TestOperationalLimitRollbackReplayConfirmsOldTrust`, `TestOperationalLimitNewReleaseJoinsAndDoesNotFence`, helpers renamed, and their failure text changed from "GAP CLOSED?" to "LIMIT CHANGED (update the owner document §8 and this test):". The header says why they exist: a limit cannot close or widen without the documents.

### 4.5 The documents (`8e1f539`)

Owner document, section on the admission state package, after the A5-1 paragraph:

- "The other ways to that memory are system calls ..." names a raw system call through `syscall` or `golang.org/x/sys/unix`, a write to `/proc/self/mem` through `os`, `ptrace`, `process_vm_writev`, a mapping or shared memory segment placed over memory in use, and a process started for the purpose, all as part of the OS limit. It says which of these was measured (only `/proc/self/mem`, by the fifth audit) and that the import inventory does not list the files that import `syscall` or `x/sys/unix`, because on Linux `os` alone reaches the same memory.
- "Two kinds of road do go through the language without a `reflect`, `unsafe` or `C` import, and the guard holds both ..." explains the raw pointer value (it converts in every file; the import is needed only to spell the type), names `MmapPtr` and the `encoding/json` route, the libc functions, and the two rules.

Owner document, list of limits: the import inventory now covers "reflection; `unsafe`; cgo; code loaded at run time; and dependencies that export raw memory access", describes the reviewed list and the raw pointer rule, and replaces "The import names which files can write storage past the typed inventories" with "... by every road through the language known here, a data race aside; a source inventory cannot show that no other road exists." Raw system calls are named part of the limit.

Path allowance (section 9): a new reconciliation paragraph names the four adopted test files; "ceiling ... is 48 files" becomes "was 48 files", and the new ceiling is 52.

`docs_contract_test.go`: 13 new phrases in the owner rule, 13 Missing cases and 12 wrong-statement cases (for example "no other road\nexists", "is 48 files", "are held by\nthe import inventory"), the ceiling and the four paths in the plan assertions, and 6 phrases of the new `PLANS.md` entry. The long `//go:linkname` line was rewrapped (not pinned).

## 5. The dependency API review behind the pins

Tool: a scratch program (`14-repair-evidence/scan/main.go.txt`, never committed) reads `go list -deps -export -json` export data (linux/amd64, `CGO_ENABLED=0`) and walks every type reachable from a package's exported API: exported package-level objects, exported methods of every reachable named type (pointer receivers included), exported and embedded fields, interface methods, and parameters and results. It reports reachable types with underlying `unsafe.Pointer`, functions with `uintptr` or raw pointer parameters or results, and reachable `reflect`, `unsafe` or `plugin` types. `scripts/run-scan.sh.txt` reproduces both outputs byte for byte.

| Package (module) | Exported names | Result |
| --- | --- | --- |
| go-jose v4, jwt | 85, 27 | nothing |
| spiffe workload, spiffeid, jwtsvid, workloadapi | 25, 29, 5, 42 | nothing |
| grpc, codes, status | 183, 18, 11 | nothing |
| `modernc.org/sqlite` | 53 | `Page.Buf`/`Page.Extra` return `unsafe.Pointer`; `reflect.Type`/`reflect.Value` reachable through `database/sql` (R14-5) |
| `golang.org/x/sys/unix` | 10,772 | `MmapPtr`, `MremapPtr` return `unsafe.Pointer` (R14-1); `Syscall*`, `RawSyscall*` take and return `uintptr` (OS road) |

The standard-library packages that production files import (51) were scanned the same way (`scan-std.txt`): `encoding/json`, `database/sql` and `database/sql/driver` reach `reflect.Value.UnsafePointer`; `sync/atomic` has raw pointer functions; `syscall` is the OS road. All values of raw pointer type that these hand out are held by the raw pointer rule, whatever the package, so the rule does not depend on this review being complete. The review decides only which dependency packages may be imported without entering the import inventory.

## 6. Limits that remain (stated, not hidden)

1. **The OS road (A5-1).** Raw system calls, `/proc/self/mem`, `ptrace`, `process_vm_writev`, and mapping memory in use. Named, no inventory, as the brief asked. An integer address from `reflect.Value.Pointer` or `fmt` handed to a system call belongs here.
2. **A data race** that breaks Go's memory safety: by reasoning (the auditor's), not measured.
3. **Unknown roads.** The documents now say a source inventory cannot show that no other road exists.
4. **Reflection without the import.** `reflect.Value` is reachable without importing `reflect` (R14-2, R14-5). By reasoning, not tested: such a value cannot set an unexported field (the read-only flag), and the only raw-pointer exits (`UnsafePointer`, `SetPointer`'s parameter) are values the rule refuses.
5. **The API review ran on linux/amd64 export data only.** The rule itself runs on all three targets.
6. **The two reading loops overlap.** Mutation M10 (expressions not read) and M11 (names not read) are each caught only by the exact-site subtest; every road subtest is caught by either loop alone. Both are kept, and the exact-site test makes each of them necessary.
7. **Environment.** No GitHub CI run and no macOS run of this delta. `bindfs`, `uuidgen` and `setfacl` are missing in this container (`apt-get` hung, so I did not install them). The missing `bindfs` explains ten skips on the trial merge. Inference, not checked test by test: `remote_alpha_operator_test.go` uses `uuidgen` and `setfacl`, so some of the known root-package failures likely come from their absence.

## 7. Validation

All runs are on Linux (linux/amd64 container), Go 1.26.5, as the unprivileged user `ci` with an emptied environment (`scripts/cirun.sh.txt`), on fresh clones of the commits (or of the working tree, for the run marked "new tree"). The store package needs the uncommitted Linux overlay of one test file to compile at `51d6d5f` and later on this branch (as in every earlier report; `trunk_dev` already holds the same fix through PR #14). Logs are in `14-repair-evidence/runs/`.

### 7.1 Failing first, passing after

| What | At `51d6d5f` (old) | At `8e1f539` (new) |
| --- | --- | --- |
| RT2-1 guard test (red-team's, with protoimpl) | fails: 45 of 45 subtests | passes |
| Probes R14-1, R14-2, R14-3 (effect) | each reopens a withdrawn Service, which sends a job (`v14-probe-effect-old.log`) | — |
| Whole `es/admission` with the three probe files added | 2,211 pass, 1 skip, 0 fail: the guard sees nothing (2,207 + the probe test and its 3 subtests) | — |
| Guard tests with the three probe files added | — | 3 guard tests fail: the import inventory (protoimpl), the reviewed list (protoimpl), the raw pointer rule (every probe file, in every view that compiles it) (`v14-probe-guard-new.log`) |
| Docs pins with the documents of `51d6d5f` and the final docs test | 25 subtests and 2 parent tests fail (`v14b-docs-red.log`) | pass |

### 7.2 Mutation of the new rules

13 mutants of the guard rules (`mutants/mutants14.py.txt`, log `mutants/mutants14.log`), each run against the new guard tests: **13 of 13 caught**. M1 dependency packages never inventoried; M2 plugin not inventoried; M3 raw pointer rule accepts every file; M4 tuples not read; M5 function types not read; M6 version not compared; M7 replacement not refused; M8 dotless paths not compared with the go command; M9 a stale entry on the list; M10 expressions not read; M11 declared and used names not read; M12 a package outside the list counted as reviewed; M13 a reviewed package without a module accepted. M10, M11 and M12 survived a first run; each got a test before the final run (the exact-site subtest for M10 and M11, reason checks on the list mutations for M12), and M13 was added with the module-less case. After the final run, the refusal message was changed to list every refused file in a stable order instead of the first one found in map order; M3 still applies to the changed function unchanged.

### 7.3 Full suite, old against new

`go test -count=1 -json ./...` once at `51d6d5f` and once on the new tree (`v14-base-full.json`, `v14-new-full.json`, comparison `v14-compare.txt`):

| | Results | Pass | Fail | Skip |
| --- | --- | --- | --- | --- |
| `51d6d5f` | 6,802 | 6,644 | 117 | 41 |
| new tree | 7,016 | 6,858 | 117 | 41 |

- **No test that exists in both runs changed its result.** The 117 failures are the same set: 29 top-level tests with their subtests, all known environment failures: 26 in the root package (operator-script, TLS-status and P0t diagnostic tests; none in a file this PR touches, and I did not diagnose them again) and the three store tests that need a probe binary built from an older tree (`v14-base-full.summary.txt`).
- 44 names are gone: `TestOperationalGuardReflectUnsafeImportInventoryIsExact` and its 43 subtests, renamed. Each has a successor of the same name under `TestOperationalGuardImportInventoryIsExact` that passes.
- 258 new names, all pass: the new guard tests and mutation cases, the adopted tests, and the new docs pins.

The new tree of that run was taken before two last edits: the path ceiling paragraph and its pins (documents and `docs_contract_test.go`), and the stable listing of refused files. Following the project's rule, only the two packages whose files changed ran again, on a clone of the committed tip `8e1f539`: `es/admission` 2,398 pass, 1 skip, 0 fail (same names and results as the run above, except the SIGKILL subtests, whose names carry their random delay); the root package 2,314 pass, 114 fail, the same 114 as before plus the two new ceiling cases, which pass.

### 7.4 Build, vet, race, trial merge

- `go build ./...` with `CGO_ENABLED=0` for darwin/arm64, linux/amd64 and linux/arm64: clean at both commits.
- `go vet ./...` for the same three targets: one finding at both commits, byte-identical output: `es/admission/result_auth_test.go:395:15: assignment copies lock value to restarted`. The file is untouched by PR #12 and #13; `trunk_dev` fixed it in PR #14 (`f9537a8`), and vet is clean on the trial merge.
- Race detector (`CGO_ENABLED=1 go test -race`): the adopted tests (`-run 'TestRedTeamPR12Combined|TestOperationalLimit'`) in `es/admission` pass in 82 s, and `es/admission/internal/admissionstate` passes; no data race reported.
- `gofmt -l` on every changed Go file: clean. Six unformatted files elsewhere in the repository are unchanged by this PR.
- **Trial merge** of `trunk_dev` (`bc9fe36`) into `8e1f539` in a scratch clone: no conflict (three files auto-merged, among them `workstream_c_guardrails_test.go`). Never pushed. `trunk_dev` already holds the Linux fix of the store test file, so the overlay was not applied there. On the merged tree:
  - `go build ./...`, `go vet ./...` and `GOOS=darwin GOARCH=arm64 go vet ./...` (the CI's three steps): clean.
  - `es/admission`: 2,411 pass, 13 skip, 0 fail. All 343 results of the new guard tests, the adopted tests and `TestOperationalGuardLoadsEveryProductionFile` pass, so the code that `trunk_dev` brings since the merge base adds no dependency import and no raw pointer value. The 13 skips are 12 tests of `trunk_dev` that skip themselves here (two stress tests that the CI list already names as skipping themselves, and ten that need `bindfs` or a supplementary group, which the runner provides and this container does not), and `TestOperationalHandoffChildProcess`, the helper that `13-ci-list-two-lines.patch` lists.
  - The root package: 2,317 pass, 113 fail; the failures are a subset of the 26 known top-level tests (25 of them), and all 193 results of the operational handoff docs tests pass.
  - `es/admission/internal/...`: 819 pass, 3 fail, 2 skip, the same as at `51d6d5f`; the 3 are the probe-binary store tests.
  - No new test of this repair skips itself on a host, so the CI list needs no line beyond the two of `13-ci-list-two-lines.patch`.
- **Second trial merge**, after PR #19 landed on `trunk_dev` at 11:34Z during this run (`ea86a96`). It conflicts in one file, `docs_contract_test.go`: PR #12's block of operational handoff tests and PR #19's new `TestARSStorageCheckDocsContract` were both appended after the same function. **The same conflict appears when `ea86a96` is merged into `51d6d5f`,** so it comes from PR #19 meeting PR #12, not from this repair. I resolved it in the scratch clone by keeping both blocks verbatim with one blank line between them (`runs/v14c-trial2-conflict-resolution.diff`: the combined diff adds only that blank line). On that merge: build and both vet steps clean; `es/admission` 2,411 pass, 13 skip (the same 13), 0 fail; the root package 2,318 pass, 113 fail, the same 25 known top-level tests, with PR #19's `TestARSStorageCheckDocsContract` and all 193 operational handoff docs results passing; `es/app` (the package of PR #19's new tests) 453 pass, 84 skip, 0 fail.

## 8. Provenance manifests

Taken after the push, by `scripts/prov14.sh.txt` (the script of `13-repair.md` extended to four manifests), on a clean working tree at `8e1f539`. The recipe's SHA-256 was checked before every run. Each manifest was written twice into a fresh mode-0700 directory outside the repository, and the two files are byte-identical. For each, `git add -A` with the index reset to its base staged exactly the manifest's paths, and `git write-tree` gave the tree of the commit, `5dd0af054e351315789d375dec15b29d6eaac01c`, every time. Afterwards: head `8e1f539`, status empty, upstream `origin/claude/project-thread-sqldt7` restored. The remote branch is at `8e1f539613b85511b537e52b376aad88ab4af643`.

| Manifest | Base (index reset to) | Upstream pinned to | Files | Manifest SHA-256 | Textual diff SHA-256 |
| --- | --- | --- | --- | --- | --- |
| Base-relative | `8058561` | `origin/codex/reliable-submit-operational-handoff-v1` | 32 | `b2a8d5a2a1d3164062a170d7154d51d6568df2a29a7df6c2e63573d277c916a0` | `d1a893e28a7d32ae20a20ac6983e9e9935986800e95cc7623383af38818a6369` |
| Delta against the previous tip | `51d6d5f` | `origin/claude/project-thread-sqldt7` | 9 | `290c05ac745bc92409ae9f73ca3addd07e1405e789fc55ade5265c6308cb6db8` | `963adaf06fc980c4e0bf87598ac7191343f48334ab046cb5fa51fa089c6dd8bc` |
| Delta against the audited tip | `bff8dda` | `origin/claude/project-thread-sqldt7` | 9 | `f761abed937dc1b09726878874cac5210892143d5a42608ef5b817c559955377` | `fda830eb0a55c84eced09088acac12af8c6617807e6fc153e7e5685fda6c19f5` |
| Trunk-relative | merge base `ae326b0` of the tip and `trunk_dev` (`bc9fe36`) | `origin/trunk_dev` | 52 | `67b0932f59089fb7fd3ab0cf13eb0d68afff67393273bba4697a85a17d5e410d` | `8ac39a4343618f30fe2145b83af41e42148e65d76ca63cedcba2060ca2186716` |

The two deltas list the same nine paths: `bff8dda..51d6d5f` changed three of them, which this repair changes again.

`trunk_dev` moved to `ea86a96` (PR #19) while the run was going on, after a fetch at the start. I fetched again and took all four manifests a second time (`manifests/prov14b-output.txt`): every manifest and staged tree is byte-identical, because the merge base of the tip and `trunk_dev` is still `ae326b0`.

## 9. What the narrow audit should check

1. That the three rules hold what section 3 says, and that the overlay roads and controls are the right ones. In particular whether a raw pointer can reach a file of the module without ever being the type of an expression or name in that file.
2. That each pin of the reviewed list is the version in `go.sum`, and that the review in section 5 is enough to put each package on the list.
3. That the owner document's new wording matches the rules, and that the ceiling of 52 is right.
4. That the adopted tests are the red-team's, with only the changes listed in section 4.4.
5. The merge gate must name the new head and tree.
6. When PR #12 takes `trunk_dev`: the adjacency conflict in `docs_contract_test.go` (section 7.4, keep both blocks) and the two lines of `13-ci-list-two-lines.patch`.

## 10. Open points for the Fable red-team (not in this batch)

- R14-1 to R14-5 above, and whether any road hands out a raw pointer that the rule misses.
- The red-team's own follow-ups: A-30 (in-place change of `*s.trustModel`), MU6 (the second identity check of the staging root, needs a racing swapper), double crash and crash during a WAL checkpoint, longer fuzzing and a fuzz target over the durable record codec.

## 11. Effects

- Pushed: `claude/project-thread-sqldt7`, fast-forward `51d6d5f..8e1f539`. No other branch, no force-push, no merge, no tag.
- PR #13's description was updated for the new head (attribution lines kept). It stays a draft.
- Nothing ran outside this container: no CI on this branch, no Mac, no test box, no live service.
- Probe files, the scanner and the mutants stayed out of the repository; copies are in the evidence folder as `.txt`.
- No secret, key, environment file or SQLite state from a real system was read or written.
