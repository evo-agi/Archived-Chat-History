# 28a-guard-coverage evidence (ES PR #12 at `4416699`, tree `052d1024`)

Written by the independent audit thread "Audit Execution-Substrate PRs" on 2026-11-23, from 20:03Z onwards. Every file here was made in the audit's cloud container or fetched read-only. `SHA256SUMS.txt` lists every file. My local names carry the tag `28a`.
Nothing in this folder is authority. It is evidence for `../28a-guard-coverage.md`.

## Setup

- **Tree.** `/home/ci/m26d`, byte-identical to `git archive 4416699` (`tree-check.txt`). Every probe and the fix ran on a fresh copy of it (`cp -a`), never on the clone.
- **Identity.** Go 1.26.5 with `GOTOOLCHAIN=local` under `env -i`, as user `ci` (1500:1600).
- **Guard tests.** `go test ./es/admission -run '^(TestOperationalGuard|TestRedTeamPR12CombinedRawMemory|TestOperationalAdmissionStatePackage)'`: the ten tests of the raw-memory guard.
- **The test library.** `libzz28a.so` is built by `dyn28a.sh` from six lines of C written for this audit. Its initialiser writes one line to stderr and does nothing else. No downloaded binary was run.
- **The fix.** `guard-directive-allowlist-proposal.diff` applies with `git apply` to `4416699`. It was made by `apply28a.py` (which reads `newcode28a.go.txt`, saved locally as `/opt/audit/fix28a/newcode.go.txt`) followed by `apply28a-part2.py`. Nothing was committed or pushed.

## Files

| File | What |
| --- | --- |
| ls-remote-open.txt, ls-remote-close.txt | Remote refs at the start and at the end: PR #12's branch, `refs/pull/12/head` and `refs/pull/32/head` at `4416699`; trunk_dev at `76c030f` |
| tree-check.txt | The reviewed copy against `git archive 4416699`; trunk_dev since `8ba1edb` against the guard file and owner doc; `//go:` directives in non-test Go files at both heads |
| dyn28a.sh.txt, dyn28a.log | Small module: the directive in a file with no import makes `CGO_ENABLED=0` builds for linux/amd64 and arm64 dynamic; the library's initialiser runs before `main`; without the library the binary does not start; control without the directive is static |
| dirs28a.sh.txt, dirs28a.log | Directive forms: block comment (no effect), inside a function (works), after code (refused), absolute path (works), variable binding (builds), two-field form and `cgo_ldflag` (refused), `linkname` with and without `unsafe`, `//go:debug` in package main |
| probes28a.sh.txt, probes28a-A.log, guard-tests-probeA-uid1500-gid1600.log | Real tree plus the directive file: vet clean, `cmd/es` dynamic for both Linux targets, all ten guard tests pass |
| probes28a-B.log, guard-tests-probeB-uid1500-gid1600.log | Real tree plus dot imports of `unsafe` and `reflect`, escaped and raw-string paths, a generated file and a `//go:build cgo` file: the inventory test names the first five, the file-set test the last |
| guard-directive-allowlist-proposal.diff, apply28a.py.txt, apply28a-part2.py.txt, newcode28a.go.txt | The proposed fix and regression cases, and the scripts that made it |
| test28a.sh.txt, test28a-uid1500-gid1600.log, guard-tests-fix-plus-probeA-uid1500-gid1600.log | gofmt, vet for three targets, the new test, the guard tests, the docs contract tests, and the fix tree with probe A's file |
| mutants28a.py.txt, mutants28a-uid1500-gid1600.log | Mutants K1 to K6 of the directive check, on the final fix tree |
| mutants28a-inv.py.txt, mutants28a-inv-uid1500-gid1600.log | Inventory mutants J1 to J3, on the final fix tree and on the tree without the new cases |
| full28a.sh.txt, full28a-uid1500-gid1600.log | es/admission in full on the final fix tree, compared test for test with the audit 24 run on `052d1024` |

## Sensitive material

The probes are synthetic. No key, certificate body, token or config file is copied here. Commit-message trailers and author names are left out.
