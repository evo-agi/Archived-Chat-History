# PROVENANCE CHECK: PR #32, `trunk_dev` `8ba1edb` merged into PR #12 as `4416699`

A narrow, read-only provenance check, asked for by the coordinator at 19:22Z. Audit thread: "Audit Execution-Substrate PRs", the auditor of PR #26 (audits 20 to 24). Date: 2026-11-23, 19:22Z to 19:59Z (UTC). I am not the writer of the merge. My local file names carry the tag `26e`.

Verdict: **ACCEPT.** The merge commit is exactly what it claims to be, and PR #12's branch can fast-forward to it.

## 1. In plain words

- **Parents and tree.** `44166998d4ef0d7b86152f3f66265b906f7d612a` has parents `2c8bf35` (PR #12's head, first parent) and `8ba1edb` (`trunk_dev`), and tree `052d102465743ce673a34f3805100b29f2d142c5`. `2c8bf35` is its ancestor, so PR #12's branch can fast-forward to it.
- **Same tree as audit 24's trial.** I merged `8ba1edb` into `2c8bf35` myself, in a temporary worktree, and resolved the two conflict blocks with a script that stops on anything else. My tree is `052d1024`, the same tree as `4416699` and as my audit 24 trial merge of `a88467f` into `2c8bf35`.
- **Why that holds.** `8ba1edb` is PR #26's squash merge onto `036d507`, and its tree is `45b41a40`, exactly the tree of `a88467f`, which audit 24 accepted. The merge base is `036d507` both times. So the three inputs of the merge are the same.
- **Only the two known blocks differ from a plain merge.** `git show --remerge-diff 4416699` compares the commit with git's own automatic merge. It shows only the two conflict blocks in `workstream_a_guardrails_test.go`, each resolved by deleting the markers and PR #26's old `source:` line. So each block keeps PR #12's `source:` line and adds PR #26's `node:` and `syntax:` lines. Nothing else in the commit differs from what git merges by itself.
- **Manifests.** Both of the writer's v2 manifests reproduce byte for byte: PR-relative `4ab0ddab…cbc`, 4 files, and trunk-relative `86ff064d…7b0`, 56 files.
- **Tests.** The tree is byte-identical to the one I tested in audit 24: build, vet and gofmt clean, and es/admission in full 2,537 pass, 8 skip, 0 fail. I did not run it again; a tree id fixes every byte.
- **CI.** GitHub's "build, vet and test" run 45248038866 on `4416699` passed (19:21Z to 19:53Z). The refs had not moved at 19:58Z.

## 2. Target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Pull request | #32, draft, branch `claude/project-thread-ne9cwa-pr12-trunk-dev` into `codex/reliable-submit-operational-handoff-v1` (PR #12's branch) |
| Merge commit | `44166998d4ef0d7b86152f3f66265b906f7d612a`, tree `052d102465743ce673a34f3805100b29f2d142c5` |
| Parents | `2c8bf35f30877bc3749b1799be686bf108a1cf8d` (PR #12 head, audited in `21-audit-pr28.md`), `8ba1edb8af52214ec1bfbb5b93e5a4dc4e51b1ce` (`trunk_dev`, PR #26) |
| Merge base | `036d50724b499b020c5149c55ad902cfcb1482c0` (the only one) |
| Writer report | `25-pr12-trunk-dev-8ba1edb.md`, SHA-256 `0e90a7f6f66849019e9353d472fc65aa4fe54ee8b2782bebfdfd5c495901348a`. Evidence `25-pr12-trunk-dev-8ba1edb-evidence/`: its `SHA256SUMS` has 25 entries, all OK |
| Recipe | v2, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked before the runs |

## 3. What I checked

1. **Refs.** An explicit check before the manifest runs: PR #32's branch and `refs/pull/32/head` at `4416699`, PR #12's branch at `2c8bf35`, `trunk_dev` at `8ba1edb` (`ls-remote-open.txt`, `ls-remote-close.txt`).
2. **Commit object.** The `tree` and both `parent` lines read from the commit itself, first parent `2c8bf35`.
3. **`8ba1edb`.** One parent, `036d507`; tree `45b41a40bac412b67fcf7258836bb81a10edabde`, equal to `a88467f`'s tree (`paths-and-trees.txt`).
4. **Independent merge** (`plain-merge-output.txt`, `workstream_a_guardrails_test.go.conflicted.txt`, `resolve26e.py.txt`). `git merge --no-commit 8ba1edb` on `2c8bf35` in a temporary worktree conflicts only in `workstream_a_guardrails_test.go`, with exactly two blocks; `workstream_c_guardrails_test.go` merges cleanly. `resolve26e.py` resolves only those two known blocks. `git write-tree` gives `052d1024`. The worktree was removed afterwards, and nothing was committed or pushed.
5. **Commit vs automatic merge** (`remerge-diff-4416699.txt`, `merge-tree-conflicted-vs-4416699.diff`). Two hunks, both in the conflict blocks, both only deletions.
6. **Paths** (`paths-and-trees.txt`). Against `2c8bf35` the merge changes only the four PR #26 test files, the same four `trunk_dev` changed since `036d507`. Against `8ba1edb`, its 56 paths are the same 56 as PR #28's `036d507..2c8bf35`.
7. **Manifests** (`manifest-v2-…`). Each written twice, byte-identical to each other and to the writer's `manifests/44166998-base-1.json` and `44166998-trunk-1.json`. After the runs, the clone was back at `4416699` with a clean status.

## 4. CI

| Head | Run | Result |
| --- | --- | --- |
| `2c8bf35` (PR #12) | 45219219689 | success, 17:12Z (writer-reported, as in audit 23) |
| `4416699` (PR #32) | 45248038866 | completed 19:53Z, success |

(`ci-status.txt`)

## 5. Findings

None.

## 6. Not covered

This is a provenance check only. PR #12's own red-team and merge gate into `trunk_dev` are still ahead, as the writer says. Nothing ran on macOS.

## 7. Sensitive material

No key, certificate body, token or config file is copied into the evidence. Commit-message trailers and author names are left out.

Before publishing, I scanned this report and every evidence file for private-key and certificate headers, Vault, GitHub, Anthropic and AWS token shapes, JWTs, phone-number shapes, personal names and model names, with a positive control that matched as expected. There were no hits. A second scan for commit trailers and author names found nothing.
