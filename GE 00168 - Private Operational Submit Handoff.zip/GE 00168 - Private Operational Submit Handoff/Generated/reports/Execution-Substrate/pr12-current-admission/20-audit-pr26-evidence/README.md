# 20-audit-pr26 evidence (ES PR #26, `bcfb6da`, head `0aba38e`)

Written by the independent audit thread "Audit Execution-Substrate PRs", 2026-11-23, 15:12Z to 15:40Z.
Every file here was produced in the audit's cloud container or fetched read-only. `SHA256SUMS.txt` lists all files.
Nothing in this folder is authority; it is evidence for `../20-audit-pr26.md`.

## Setup

- **Clone and recipe.** Repository clone `/opt/audit/es`. Manifests use the v2 recipe `/opt/audit/v2.py` (sha256 `c08597e2…a3ca`), checked before each run. Each run checks out the topic branch at the tip, resets it to the base, and pins the upstream to `origin/trunk_dev`.
- **Test trees.** These are `git archive` exports in `/home/ci`:
  - `pr20h` (head `bcfb6da`) and `pr20b` (base `792f17c`);
  - `es20` and `base20` (the same two commits, used for the full runs), plus copies under `/home/ci2` for the second identity;
  - `fix20` (`bcfb6da` + `object-level-allow-proposal.diff`);
  - `dto20` (`bcfb6da` + `dto-embedded-proposal.diff`);
  - `mt20` (merge-tree of `036d507` and `bcfb6da`, which is the tree of `0aba38e`);
  - `m20` (the PR #13 trial merge).
- **Identities.** Runs used `env -i` and Go 1.26.5 with `GOTOOLCHAIN=local`, as user `ci` (1500:1600, with sudo) and user `ci2` (1700:1700, without sudo).
- **Probes and mutants.** Each one ran in a fresh copy of a pristine tree.
- **Local commits.** The trial-merge commits (`trial20-build.sh.txt`) were made in a temporary index, author "audit", and never pushed.
- No downloaded binary was executed.

## Files

| File | What |
| --- | --- |
| ls-remote-open.txt, ls-remote-close.txt | Remote refs at the start (15:12Z: branch `bcfb6da`, trunk_dev `792f17c`) and at the end (15:32Z: branch `0aba38e`, trunk_dev `036d507`) |
| manifest-v2-open-bcfb6da-vs-792f17c-run1/2.json (+ .out.txt) | Opening manifests, `49ff0a0d…0c15` both times, byte-identical to the writer's `manifests/trunk-1.json` |
| manifest-v2-close-0aba38e-vs-036d507-run1/2.json (+ .out.txt) | Closing manifests of the new head, `3c7c3e1a…9c25` both times, byte-identical to the writer's `regate-036d507/manifests/trunk-1.json` and `-2.json` |
| head-provenance-0aba38e.txt | `0aba38e`'s parents and tree, the `merge-tree` result, the diff against `036d507`, the blob of the changed file in both commits, and the files PR #25 changed |
| delta-792f17c-bcfb6da.diff | `git diff 792f17c bcfb6da` |
| writer-evidence-check.txt | sha256 of the writer's report (both versions seen), its `SHA256SUMS` check, and manifest comparisons |
| zz_audit20_count_test.go.txt, allowed-occurrences-bcfb6da.log | A probe test that runs the new rule and the old rule (copied verbatim) over every occurrence: 21 occurrences, 21 allowed by both |
| term-lines-bcfb6da-vs-pr13-e060449.txt | The lines holding any guarded word in the guard's files at `bcfb6da` and at PR #13's tip `e060449`: the same set |
| unit20.sh.txt, run-unit20.sh.txt, unit-admission-bcfb6da-vs-792f17c-uid1500-gid1600.log, -uid1700-gid1700.log | gofmt, vet (three targets) and es/admission in full at head and base, for both identities, with a diff of results |
| probes20.py.txt, probes20-uid1500-gid1600.log | Probes P00 to P30 on head and base, all 62 results as predicted |
| probes20-fix-uid1500-gid1600.log | The same probes on the proposal: P03 to P07 now refused, the rest unchanged |
| mutants20.py.txt, mutants20-head-uid1500-gid1600.log | 21 mutants on `bcfb6da`: 17 caught; M16, M17, M18 and M21 survive |
| mutants20-fix-uid1500-gid1600.log | 22 mutants on the proposal (M07 to M21 and F01 to F07): all caught |
| object-level-allow-proposal.diff | The fix for A20-1 and A20-2 (`patch -p1`, test-only) |
| fix20.sh.txt, object-level-allow-proposal-uid1500-gid1600.log | The proposal's gofmt, vet (three targets), the Workstream A tests, the count probe (still 21), and es/admission in full (1,133 pass, 7 skip, only the 12 new subtests differ) |
| trial20-build.sh.txt, trial-merge-pr13-e060449-build.log, merge20.sh.txt, trial-merge-pr13-e060449-with-proposal-uid1500-gid1600.log | The trial merge of PR #13's tip with `bcfb6da` + the proposal: the same two conflict blocks as without it, resolved per the writer's plan; vet and the Workstream A tests pass |
| trunkmove20.sh.txt, merge-onto-036d507-uid1500-gid1600.log | gofmt, vet (three targets) and the Workstream A tests on the merge of `036d507` and `bcfb6da` (= `0aba38e`'s tree) |
| dto-embedded-proposal.diff, dto20.sh.txt, dto20full.sh.txt, dto-embedded-proposal-uid1500-gid1600.log | O20-1: the one-line DTO guard change; without the probe everything passes, with P29 the DTO guard refuses; es/admission in full has the same results as the head |

## Sensitive material

The probes and fixtures are synthetic. No key, certificate body, token or config file is copied here.
A pattern scan for private-key headers, certificates, Vault, JWT, GitHub, Anthropic and AWS token shapes, personal names, mail and phone shapes, and model names found nothing.
