# GUARD COVERAGE: PR #12's raw-memory guard at `4416699` (tree `052d1024`)

A read-only completeness review of the repository's own static check, asked for by the coordinator at 20:03Z. Audit thread: "Audit Execution-Substrate PRs". Date: 2026-11-23, 20:03Z to 20:45Z (UTC). I did not write the guard. My local file names carry the tag `28a`.

Verdict: **one road the guard misses (G28-1, Medium), with a tested fix. Every other construct on the list is caught or is one of the guard's named limits.** Three of the caught forms have no regression test; the fix adds them.

## 1. In plain words

- **What the guard is.** Four checks in `es/admission/workstream_c_guardrails_test.go`: an import inventory (any `reflect`, `unsafe`, `C` or `plugin` import, and any dependency package not on a reviewed list, puts its file on a list held by SHA-256); a reviewed dependency list held against the go command; a raw pointer rule (a value whose underlying type is `unsafe.Pointer` may appear only in a file that imports `unsafe`); and a refusal of `//line` directives plus a file-set check that every production file is one the typed checks read.
- **The miss (G28-1).** One comment line in any production file, with no import at all, makes the deployed binary load a shared library when it starts:
  `//go:cgo_import_dynamic _ _ "libname.so"`
  The compiler accepts this form outside cgo files. With `CGO_ENABLED=0`, which is how the deploy scripts build `cmd/es`, the binary stops being static: it gets a program interpreter and a `NEEDED` entry for the library, and the library's initialisers run native code inside the ES process before `main`. That code can write any memory. I measured it on the real tree: `052d1024` plus a three-line file in `es/app` builds `cmd/es` for linux/amd64 and linux/arm64 with the library entry, and all ten guard tests pass. In a small module, a harmless library I wrote ran its initialiser in the process; without the library on the loader path the binary does not start at all.
- **Why it matters.** The owner doc says the import names "the files that can write storage past the typed inventories by every road through the language known here", and lists code loaded at run time among the roads the import inventory holds. This road goes through the language (a directive in Go source) and needs neither `plugin` nor `C`. It also turns a static binary into one that reads `LD_LIBRARY_PATH` (measured: that is how my test found the library), which a static binary ignores.
- **The fix.** An exact list of the `//go:` directives that production files may hold, by verb. Today it is `//go:build` alone; trunk_dev at `76c030f` (PR #27 merged) holds no other either. The test reads the same files as the `//line` check (every non-test Go file in every directory except `.git`), refuses any other verb, and also fails when a listed verb is no longer used. Tested diff: `guard-directive-allowlist-proposal.diff`.
- **Caught, but untested.** A dot import (`import . "unsafe"`), an import path spelled with an escape (`"\x75nsafe"`) or as a raw string, and a generated file (`// Code generated ... DO NOT EDIT.`) are all caught today, which I measured. No test names them, and three inventory mutants that break exactly these forms pass every existing test. The same diff adds six cases to the existing mutation table; with them all three mutants fail.
- **Tests of the fix.** gofmt, vet for the three targets, the ten guard tests plus the new one, and the four docs contract tests that read the owner doc all pass. With the probe file added, only the new test fails, naming `es/app/zz_dynamic.go:3:1`. 9 of 9 mutants of the fix are caught. es/admission in full passes: 2,596 pass, 8 skip, 0 fail, and no existing test changed its result.

## 2. Target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| PR #12 branch | `codex/reliable-submit-operational-handoff-v1` at `44166998d4ef0d7b86152f3f66265b906f7d612a` (open and close ref checks), tree `052d102465743ce673a34f3805100b29f2d142c5` |
| Copy reviewed | `/home/ci/m26d`, byte-identical to `git archive 4416699` (`tree-check.txt`) |
| Guard | `es/admission/workstream_c_guardrails_test.go`, lines 4078 to 7040 for the parts below |
| Owner doc | `.docs/execution_lifecycle/reliable_submit_operational_handoff.md`, lines 573 to 625 and 792 to 857 |
| Production builds | `CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build ./cmd/es` (`scripts/internal/remote_alpha_deploy_es_binaries.sh:1106`) |
| Toolchain | Go 1.26.5, `GOTOOLCHAIN=local`, as unprivileged user `ci` |

Line numbers below are in `workstream_c_guardrails_test.go` at `4416699` unless a file is named.

## 3. Construct by construct

| # | Construct | Guard sees it? | Where | Evidence | Regression test |
| --- | --- | --- | --- | --- | --- |
| 1 | `//line` and `/*line` directives (earlier R14-1, R14-2, A6-1) | Yes, twice | Name check `operationalGuardLineDirective` (5043) on every non-test Go file (`TestOperationalGuardProductionFilesHoldNoLineDirective`, 5130); moved-position check (5092); every guard reads unadjusted positions through `guardPosition` (4570), enforced by 5369; 5258 shows no site moves even with a directive | Existing tests: 10 refused forms, 5 not refused, planted files in testdata, `_`, `.`, vendor, nested module, cgo and tagged files | Enough as is |
| 2 | Import aliases (named, blank) | Yes | The inventory reads the unquoted path, never the name (`operationalGuardImportInventory`, 4171 to 4190) | Existing mutations: renamed and blank `unsafe`, renamed and blank `modernc.org/libc` | Enough as is |
| 3 | Dot imports | Yes | Same path rule | Probe B: `import . "unsafe"` and `import . "reflect"` fail the inventory test | **Missing; added** (dot `unsafe`, `reflect`, `modernc.org/libc`) |
| 4 | Import path with an escape or in a raw string | Yes | `strconv.Unquote` (4179); the go command accepts both and builds | Probe B | **Missing; added** |
| 5 | Build tags and files the targets exclude (custom tag, other OS or architecture, `cgo`, `ignore`, release tags) | Yes | File-set check refuses any non-test Go file compiled for none of the three targets (5685); the loader runs with `CGO_ENABLED=0` (7033), as the deploy builds do | Probe B: a `//go:build cgo` file is refused; existing cases for a custom tag and a windows file in 8 directories (5887) | Enough as is |
| 6 | testdata, `_`, `.` and vendor directories | Yes | The walk skips only `.git` (4092); vendor files are also refused as compiled for no target, since the loader forces `-mod=readonly` | Existing "every directory but .git is listed" | Enough as is |
| 7 | Symbolic links | Yes | The walk does not enter a linked directory, but a package compiled through one is type-checked and refused as "type-checked but its directory was not listed" (5733). A linked file is read through the link by both sides | Existing subtest at 6222 | Enough as is |
| 8 | Generated code | Yes | No exemption anywhere in the guard (no `ast.IsGenerated` or "Code generated" test) | Probe B: a generated file importing `unsafe` fails the inventory | **Missing; added** |
| 9 | cgo | Yes | `import "C"` is inventoried (4156); under `CGO_ENABLED=0` a cgo file is also compiled for no target; C, C++, Objective-C, Fortran, header, SWIG, assembly and `.syso` files are refused by extension, case-insensitively (5690), which is the go command's whole list | Existing cases for `.s`, `.S`, `.c`, `.syso` | Enough as is |
| 10 | Compiler directives `//go:` | **No (G28-1)** | No check reads `//go:` comments; 5043 matches only `line` | Probes A and dirs28a, §4 | **Fix proposed** |
| 11 | `//go:linkname` | Yes, through the compiler | The compiler refuses it in a file that does not import `unsafe` (measured); a blank `unsafe` import is inventoried | dirs28a | The new list refuses it as well |
| 12 | Reflection | Yes, or a named limit | `reflect` inventoried under any name. Reflection reached without the import (the exported `reflect.Type` in `json.UnmarshalTypeError`) leaves raw memory only through `Value.UnsafePointer`, whose result the raw pointer rule sees; `Value.Pointer` and `UnsafeAddr` give a `uintptr`, which needs `unsafe` or a system call to become a pointer. Reflection inside library bodies (`json.Unmarshal`, `errors.As`, `sort.Slice`) is a named limit (doc 833 to 836) | Existing generic probes in 4682 to 5032 | Enough as is |
| 13 | `unsafe` and raw pointer values | Yes | Inventoried under any name; raw values without the import fail the rule (4578 to 4680), including tuples and function types, every expression, declared and used name, and type expressions inside constraints. A slice of raw pointers is not flagged itself, but reading an element is an expression of raw type (`zzHold`, 5015) | Existing | Enough as is |
| 14 | Unreviewed dependency packages | Yes | Exact list in both directions, versions, no `replace` (4128, 4392, 4435) | Existing | Enough as is |
| 15 | `go.mod` directives, `go.work`, `GOWORK`, nested modules | Yes | 5707 to 5743, 6828 | Existing | Enough as is |

Named limits, not findings: system calls and `/proc/self/mem` (doc 597 to 610), data races, `-modfile`, `-overlay` and `GOFLAGS`, and a toolchain or module cache whose content is not the published one (doc 849 to 853). Inference: `syscall.Madvise` and `unix.Madvise` on a slice over the Go heap would zero whole pages without any integer address; that is a system call and so inside the named limit. Reads are outside the guard's pattern, which is about writes: `runtime/debug.WriteHeapDump` and `fmt` printing unexported fields read memory, nothing more.

## 4. Finding G28-1 (Medium): a compiler directive loads native code with no import

**Road.** `//go:cgo_import_dynamic _ _ "libname.so"` in any production Go file. The compiler refuses the other `//go:cgo_*` directives outside cgo-generated files, but permits this four-field form anywhere (measured: the two-field form and `//go:cgo_ldflag` are refused with "only allowed in cgo-generated code"). The linker then adds the library to the executable even when nothing uses a symbol from it.

**Measured** (`probes28a-A.log`, `dyn28a.log`, `dirs28a.log`):

- Real tree, `052d1024` plus `es/app/zz_dynamic.go` (package clause and the directive, nothing else). `go vet` is clean. `CGO_ENABLED=0 go build ./cmd/es` for linux/amd64 and linux/arm64 gives `NEEDED libzz28a.so` and an interpreter (`/lib64/ld-linux-x86-64.so.2`, `/lib/ld-linux-aarch64.so.1`). The same build without the file has no dynamic section. All ten guard tests pass.
- Small module, linux/amd64: with my own library on `LD_LIBRARY_PATH`, its initialiser printed its line before `main` ran. Without it, the binary exits 127 before `main`. The static control binary runs either way.
- Placement: the directive works indented inside a function body and with an absolute library path. It is refused after code on the same line, and a `/*go:...*/` block comment does nothing.

**Why the guard misses it.** None of its checks reads `//go:` comments; the only directive check matches `line` (5043). The import inventory and the raw pointer rule see nothing, because the file has no import and no expression.

**Severity.** Medium. Production code is inside the trust boundary (doc 590 to 595), so this is not an attack from outside. But the guard exists to make every such road fail a test, so that a reviewer sees it, and the doc says the import names every road through the language it knows. This one is a single comment line, changes the deployed binary from static to dynamic, and opens it to the dynamic loader's environment variables. It is the same class as the earlier RT2-1 road: no inventoried import.

**Fix** (`guard-directive-allowlist-proposal.diff`, SHA-256 in `SHA256SUMS.txt`, applies with `git apply` to `4416699`):

- `operationalGuardReviewedCompilerDirectives = {"build"}`, an exact list of verbs, in the same style as the exact `go.mod` directive kinds and the reviewed dependency list.
- `operationalGuardCompilerDirectiveSites` reads every comment of every non-test Go file below the root (`repositoryProductionListings`, the same files the `//line` check reads) and records each comment that starts with `//go:`, in any column, at its real position.
- `TestOperationalGuardProductionFilesHoldOnlyReviewedCompilerDirectives` refuses any verb not listed and any listed verb that no file holds. Subtests: 14 refused forms (the dynamic import in three spellings, inside a function, after code, `cgo_ldflag`, `linkname`, `debug`, `embed`, `generate`, `noinline`, a tab after the verb, an empty verb, a last line without newline), 6 forms not refused (a build constraint, prose naming a directive, `//gofmt`, a directive in a string and a raw string, a block comment), and a planted tree with testdata, `_`, `.`, vendor and tagged files, where test files and `.git` are not read.
- One paragraph in the owner doc after the `//go:linkname` sentence.

A stricter list than a ban on `cgo_import_dynamic` alone is deliberate: it also holds `//go:debug`, which sets the binary's GODEBUG defaults (measured: `DefaultGODEBUG=panicnil=1`) while the guard already refuses the `godebug` line of `go.mod`, and any directive a future toolchain adds. Adding a verb later is a one-word reviewed change.

## 5. Regression cases for forms the guard already catches

The diff adds six entries to the mutation table of `TestOperationalGuardImportInventoryIsExact` (after 4256); each runs in the six directories the table already uses: dot `unsafe`, dot `reflect`, dot `modernc.org/libc`, `unsafe` with an escaped path, `unsafe` in a raw string, `unsafe` in a generated file.

| Inventory mutant | Without the new cases | With them |
| --- | --- | --- |
| J1 skip dot imports | passes every test | 18 subtests fail |
| J2 compare the literal without unquoting it | passes every test | 12 subtests fail |
| J3 skip files with a generated header | passes every test | 6 subtests fail |

(`mutants28a-inv.log`)

## 6. Tests of the fix

| Check | Result |
| --- | --- |
| gofmt `es/admission` | clean |
| go vet `es/admission`, linux/amd64, linux/arm64, darwin/arm64 | clean |
| New test, verbose | pass, 22 subtests |
| Guard tests (10 existing + new) | all pass |
| Docs contract tests reading the owner doc (4) | all pass |
| Fix tree plus probe A's file | only the new test fails: `es/app/zz_dynamic.go:3:1 holds the compiler directive //go:cgo_import_dynamic, which is not on the reviewed list` |
| Mutants of the directive check, K1 to K6 | 6 of 6 caught: no refusal; `cgo_import_dynamic` listed (caught by the exactness check); refuse only `cgo_` verbs; column 1 only; no unused check; top-level comments only |
| es/admission in full on the fix tree vs. `052d1024` (audit 24 run) | exit 0: 2,596 pass, 8 skip, 0 fail (baseline 2,537 pass, 8 skip). No test changed result. 59 tests are new: the new test with its 22 subtests, and 36 inventory subtests (6 cases in 6 directories). The other 24 differences are the random SIGKILL rounds, whose names carry a random delay |

(`test28a.log`, `mutants28a.log`, `full28a.log`)

## 7. Findings

| ID | Severity | Summary | Status |
| --- | --- | --- | --- |
| G28-1 | Medium | `//go:cgo_import_dynamic _ _ "lib"` in a production file with no import makes the `CGO_ENABLED=0` binary load a shared library at start; the guard does not see it | Tested fix in the diff |
| G28-2 | Low | Dot imports, escaped and raw-string import paths, and generated files are caught but not tested; three inventory mutants survive | Tested cases in the diff |

## 8. Not covered

Nothing ran on macOS; darwin/arm64 was vetted and type-checked only. I did not measure what the four-field form does when it binds a Go variable to a library symbol, only that it builds. I did not review the standard library or the reviewed dependencies for raw access to memory; the guard names that as outside its reading. The review is of `4416699`; trunk_dev has since moved to `76c030f` (PR #27), which touches neither the guard file nor the owner doc and holds no `//go:` directive other than `//go:build` in production files.

## 9. Sensitive material

No key, certificate body, token or config file is copied into the evidence. The test library is a few lines of C I wrote, kept inside `dyn28a.sh.txt`; no downloaded binary was run. Commit-message trailers and author names are left out.

Before publishing, I scanned this report and every evidence file for private-key and certificate headers, Vault, GitHub, Anthropic and AWS token shapes, JWTs, phone-number shapes, personal names and model names, with a positive control that matched as expected. There were no hits. A second scan for commit trailers and author names found nothing.
