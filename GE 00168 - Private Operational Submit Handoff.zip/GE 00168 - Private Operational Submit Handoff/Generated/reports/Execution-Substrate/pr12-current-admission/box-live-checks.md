# PR #12: live Nomad checks for the Linux test box

Status of this file: **THE CURRENT LIST, NOT RUN.** It gathers every check of PR #12's repairs that needs a running Nomad. David gave the go on 2026-11-24 at 04:23Z, as part of the bundled box runs. The checks run through Remote Control on his Mac, one box run at a time, in the order of section 6. Later rounds add to this file instead of writing a new list.

Written by the PR #13 writer thread on 2026-11-24. Sources: `29-repair.md` section 8 (RT28-1), `31-redteam-recheck.md` sections 5 and 10 (RC31-1, RC31-2), `32-repair.md`, `35-repair.md` (Part C).

---

## 1. Why these checks exist

What ES does about Nomad's string handling and memory floor is built on reading Nomad's source at v2.1.1 and the HCL, cty and `x/text` versions it pins. Nobody has watched a running Nomad do it. These checks confirm each fact on the box's own Nomad. If one comes out differently from the expected result, the matching ES rule may be wrong, so the result goes back to the PR #12 writer thread before PR #12 merges.

## 2. Setup

- The box's Nomad (v2.1.1, as CI pins), with its usual credentials, which stay on the box. Once the Nomad lock is deployed, that is the management token the Nomad ACL tool keeps on the box, used in the `default` namespace and never printed.
- **Part A goes straight to Nomad, not through ES**, because ES now refuses most of these inputs. Submit the job as JSON through the HTTP API (`PUT /v1/jobs`, or `nomad job run -json`). Do not use an HCL jobspec file: the CLI would then parse the strings with HCL itself, and the check would measure the CLI, not the client.
- One batch job with the Docker driver. Its task prints the bytes of each argument, one line each, for example command `/bin/sh` with arguments `-c`, `for a; do printf '%s' "$a" | od -An -tx1; done`, `sh`, and then the inputs below. Read the result from the allocation's log.
- Stop and purge each test job afterwards (`nomad job stop -purge`).

## 3. Part A: Nomad on its own

| # | Input | Expected | From |
| --- | --- | --- | --- |
| A1 | argument `${attr.kernel.name}` | prints `linux`, not the text | RT28-1 (also closes pass 28's open check) |
| A2 | argument `$${x}` | prints `${x}` | RT28-1 |
| A3 | argument holding the control byte `\x01` | arrives as written | RT28-1 |
| A4 | environment value `${NOMAD_TASK_DIR}` | prints the task directory | RT28-1 |
| A5 | `Meta.output_id` set to `${NOMAD_ALLOC_ID}`, read back as `NOMAD_META_output_id` | prints the allocation id | RT28-1 |
| A6 | argument U+FEFF followed by `--flag` (bytes `ef bb bf 2d 2d 66 6c 61 67`) | prints `--flag` without the mark (`2d 2d 66 6c 61 67`) | RC31-1 |
| A7 | argument `e` followed by U+0301 (bytes `65 cc 81`) | prints U+00E9 (`c3 a9`) | RC31-1 |
| A8 | argument U+212A, the Kelvin sign (bytes `e2 84 aa`) | prints `K` (`4b`) | RC31-1 |
| A9 | argument `a`, carriage return, `b` (bytes `61 0d 62`) | arrives as written. Inference: the HCL scanner has no rule for a lone carriage return | RC31-1 |
| A10 | two read-only Docker mounts whose targets differ only in normal form, `/execution/mounts/caf` + U+00E9 and `/execution/mounts/cafe` + U+0301 | Inference: Nomad turns both into one path, and Docker refuses the duplicate target or one bind hides the other. Record which | RC31-1 |
| A11 | one registration with `Resources.MemoryMB` 5 | refused. Record the status code and the error text | RC31-2 |
| A12 | `go version <path of the nomad binary>` on the box | names the Go that built it. Before Go 1.27, Nomad's `x/text` v0.43.0 uses the Unicode 15.0.0 tables, as ES does; from Go 1.27 on it uses 17.0.0. ES's rule holds either way; this records which one the box runs | RC31-1 |

## 4. Part B: the same inputs through ES

- The strings of A1, A2, A4, A5, A6, A7, A8 and A10 in a request are refused with `400 invalid_request`, and nothing reaches Nomad.
- A request holding only the control byte of A3, or the carriage return of A9, is admitted and runs with it.
- `memory_mb` 9 is refused with `400 invalid_request`. `memory_mb` 10 is admitted and runs.

## 5. Size

Guess: 20 to 30 minutes on the box for Parts A and C, and 10 more for Part B. Nothing in it changes ES, its stored state or the box's configuration. The test jobs are purged afterwards.

## 6. Part C: Nomad's access control and the private provider (round 35)

Round 35 made PR #12's private provider send ES's Nomad token, and its tests use a fake Nomad that answers `403 Permission denied` to a request without the right token. These checks record what the box's real Nomad answers instead. The provider is unwired, and ES's token has no grant in the operational namespace until `CP-NOMAD-ACL` is done, so every request below should be refused.

- Run them on the box itself, against Nomad's local address, after the Nomad lock is deployed there (ACLs on, ES's token set up by the Nomad ACL tool).
- Read ES's token from the file that `nomad.token_file` in `/etc/execution-substrate/es.json` names, straight into the header, for example `-H "X-Nomad-Token: $(sudo cat <file>)"`. Never print, log or copy the token, and keep `set -x` off.

| # | Request | Expected | Why |
| --- | --- | --- | --- |
| C1 | `nomad namespace list` with the management token, and whether `es-operational-v1` exists | recorded | the answers below can depend on it |
| C2 | `GET /v1/job/es-live-check?region=global&namespace=es-operational-v1` with ES's token | `403` with `Permission denied`. Record the status and body | the fake's answer to a token with no grant |
| C3 | the same request with no `X-Nomad-Token` header | `403` with `Permission denied` | the fake's answer to no token |
| C4 | `POST /v1/jobs?region=global&namespace=es-operational-v1` of a minimal batch job with ES's token | `403`; afterwards `nomad job status -namespace es-operational-v1` shows no job | registration is refused, so what a 403 means for the claim must be chosen before wiring (`CP-NOMAD-ACL`) |
| C5 | `GET /v1/job/es-live-check?region=global&namespace=es-submit-v1` with ES's token | `404` (no such job), not `403` | control: the same token is accepted where it has a grant |

If C4 registers a job, stop and purge it at once and send the result to the PR #12 writer thread: the lock would then not cover the operational namespace.

## 7. Order

State on 2026-11-24 07:10Z: the coordinator gave the box for Part A at 07:03Z, but every Remote Control environment on David's Mac was offline, so nothing ran and the box was handed back untouched. The run is ready as `box-part-a/es_part_a.py` (standard-library Python, run on the box under `nohup`; it submits one batch job per check, reads its output, purges it, and prints `DONE`). The box runs Nomad 2.0.0, not the 2.1.1 the expectations were read from, so the results will be recorded against 2.0.0. Parts B and C wait for the planned ES upgrade and Nomad lock run: the box's ES predates `nomad.token_file`.

1. Parts A and C after the Nomad lock's own box run has finished (PR #31 and its setup fixes, PR #48). Part A does not need ES; Part C needs the lock.
2. Part B after PR #12 has merged into `trunk_dev` and ES built from it runs on the box, since the box's ES does not have PR #12's rules before then.
3. If the connection to the Mac or the box drops (David's Wi-Fi was disrupted on 2026-11-24), stop cleanly: purge any test job already registered, leave the box as it was, record the last finished check here, and retry later.

