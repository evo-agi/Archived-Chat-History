# INDEPENDENT AUDIT REPORT

Workstream `pr12-current-admission`, stage 08: fresh audit of the second repair of Execution Substrate draft PR #13.
Written 2026-11-22 (UTC) by a fresh audit thread. Read-only: nothing was edited, pushed, commented or merged.

**Final verdict: BLOCK**

## 1. In plain words

1. **The production code of the repair holds.** It is 47 added lines in four files. I read all of it with its callers, ran 36 mutants of my own against it, and found no defect. The race detector reports no data race in either changed package. No test went from pass to fail against the previously blocked tip, and the 154 new test results all pass.
2. **Every finding of the prior audit is fixed, and each fix has a test.** For most of them I confirmed it by breaking the fix in a scratch copy and watching a test fail, or by re-running the probe that used to pass. Two fixes and the wording items I confirmed by reading (section 7.1). One half of one rule has no test yet (finding A3-2, low). The two end-to-end escapes that blocked the last audit (GM1, GM2) are now caught, and so are the interface call (P1) and the file behind a build tag (P2).
3. **One more route past the RT-1 guard exists, and that is why I block (finding A3-1, medium).** The guard now lists a generic function only where it is *used* with a protected type, and it reads those uses only inside the package that declares the type. So a generic function added to `es/admission` and called from another package (for example `es/app`) is listed nowhere. I built exactly that in a scratch copy: three small generic functions in `es/admission`, one call of each from `es/app`. The build, `go vet`, the guard tests and the whole suite (6,360 results) stay as green as before. Two probe tests then show what it can do: a job whose artifact EGS has revoked is accepted and posted, once with EGS unreachable and once with EGS reachable and confirming.
4. **This is a gap in the tests and in the contract text, not in shipped behaviour.** Nothing in production uses the shape, and the private handoff still has no production caller. The risk is forward: a later change could weaken the authority while the tests that are described as preventing it stay green. That is the same impact, shown by the same kind of demonstration, that the red team (RT-1) and the prior audit (A2-1) rated medium and blocking, so I rate it the same.
5. **The blocking repair is small.** One added rule in the guard (list a generic whose constraint names a protected type, at its own declaration), a handful of self-test cases, and two corrected sentences in the owner document. No production code changes. Section 9 lists it.
6. **Four low findings** belong in the same repair. None blocks on its own (section 6.1).
7. **The writer's two judgment calls are sound.** Neither is a compromise of the approved design, and neither changes a public contract today. One of them (what a refused first delivery tells its caller) leaves a product question for the integration into the real submit path. Nothing is needed from David now; finding A3-3 asks that the commissioning gate name that question, so it cannot be forgotten.
8. **The two surviving mutants the writer explains only by reading:** I rebuilt both, they survive the whole package for me too, and I agree with the explanation after reading the code (section 7.7).

What I did not do: red-teaming, macOS, the Linux box (non-goals of the brief). Twelve tests cannot run in this container: nine Remote Alpha operator-script tests of the root package and the three old-binary refusal tests of the store package. They fail the same way at `b6d2f77` and at `c41e177`.

## 2. Audit target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Pull request | draft PR #13 (a fix PR into the PR #12 branch `codex/reliable-submit-operational-handoff-v1`) |
| Topic branch | `claude/project-thread-sqldt7` |
| Audited commit | `c41e177f0d264318de3d799d8b28e7f494b18c74` (one commit on top of the previously blocked tip) |
| Tree | `f8868837ed8f363d47d80f0a94622f0163efb2ff` |
| Base | `8058561edc08356c46680c204586b3c7796c0ff3` |
| Previously blocked tip | `b6d2f7787ec8254134cb48fcae0da72bac0fd02c` (audit `06-audit.md`) |
| Recipe | `governed_execution_audit_patch_manifest_v2.py`, recipe ID `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified before the opening runs and before the closing runs) |
| Manifest, base-relative (`8058561..c41e177`) | `f198dedd7913a187eff6a2048fb315ae7961073dfef7831fc45b682133bc1cb5`, 26 changed paths, +11,805 / -302 |
| Manifest, repair only (`b6d2f77..c41e177`) | `468b34852d4a175cf04edcaead7dde4815c7a00d2c6adfe77855189e95d7057a`, 16 changed paths, +1,892 / -134 |
| Implementation report | `07-repair.md`, SHA-256 `e971eb82ea1f1e10d3154a8b0d21e68d3c2e530c07f226e9ea921fa2ec78dcdb` (verified) |
| Prior audit | `06-audit.md`, SHA-256 `dd9735b4dffab6071bce0e46d7f3ab16f6f8384c2d22fdecbe631773c9447e4b` (verified) |
| Approved design | `04-design-proper-admission.md`, SHA-256 `7ffda583d94909dfb3601068ea07289cf44cec40a8946a8b11a7e7793103398c` |

The repair commit changes 16 files and adds no path. Production code: +47 / -6 lines in four files (`es/admission/reliable_submit_operational_handoff.go` +33/-4, `es/admission/reliable_submit_operational_admission.go` +3/-1, a comment only, `es/admission/internal/reliablesubmit/operational_admission.go` +7/-1, `es/admission/internal/reliablesubmit/operational_handoff.go` +4/-0). The rest is test code (seven files) and five documents. `go.mod` and `go.sum` are unchanged. These counts are mine (`git diff --numstat`) and equal the writer's.

## 3. Audit posture

- Read-only. The provenance clone `/home/user/Execution-Substrate` was never modified. Every test, mutant and probe ran in scratch copies under `/home/ci` (`tip`, `prev`, `probe`, `mut`), as the unprivileged user `ci`, with `GOPROXY=off`, `GOFLAGS=-mod=readonly`, `GOTOOLCHAIN=local` and umask 022 (Go 1.26.5, linux/amd64, 4 cores).
- One auditor. No subagent was used (the brief asked to limit helpers).
- Mutation status: 47 mutants and 12 probes on the real packages were applied to scratch copies only and reverted after each run; the runner refuses to continue when a scratch copy is not back to its starting state. Nothing was committed anywhere.
- Side effects: none outside this container and the shared report folder. No push, no comment, no pull request change, no merge. GitHub was read through `git fetch` and `git ls-remote` only.
- The writer's evidence archive was read as data. None of its scripts was executed.

## 4. Provenance reproduction

1. Recipe bytes checked against the pinned SHA-256 before use: match.
2. `git ls-remote` showed `refs/heads/claude/project-thread-sqldt7` at `c41e177f…` at the start and again at the end of the audit. `8058561` is an ancestor of `b6d2f77`, and `b6d2f77` is the single parent of `c41e177`.
3. Base-relative manifest: branch checked out under its own name at the tip, `git reset --mixed 8058561…`, upstream pinned to `origin/codex/reliable-submit-operational-handoff-v1`, recipe run twice. Both runs gave `f198dedd…1cb5` (26 files), byte-equal to each other, to the writer's manifest file and to the JSON printed in `07-repair.md`.
4. Repair-only manifest: `git reset --mixed b6d2f77…`, upstream pinned to `origin/claude/project-thread-sqldt7`, recipe run twice. Both runs gave `468b3485…057a` (16 files), byte-equal in the same three ways.
5. **Tolerated mode-bit difference, recorded.** My first attempt used a checkout made under umask 077. Both manifests then differed from the writer's in every entry's mode only (`0600` instead of `0644`; hashes `e38bf2fd…` and `df62561d…`). Paths, sizes, kinds and content hashes were equal. That is the tolerated non-executable mode-bit case of the provenance guide (§5.3, step 3). I re-created the working tree under umask 022 and took the manifests again; those are the values above and the ones I use.
6. Closing: after the last run I verified the recipe hash again, confirmed the clone was clean (`git status --porcelain --ignored` empty) and at the tip, and re-ran both manifests twice. All four files are byte-equal to the opening ones. The clone was reset to the tip afterwards.

Opening and closing manifests are in `08-audit-evidence/manifests/`.

## 5. Coverage

| Area | What I inspected |
| --- | --- |
| Governing documents | The operating protocol and the provenance guide (whole). `04-design-proper-admission.md` sections 5.4 to 5.8, 6 and 14. `06-audit.md` findings, observations and required corrections. `07-repair.md` (whole). The owner document `.docs/execution_lifecycle/reliable_submit_operational_handoff.md`: every changed hunk, the guard rules and limits (:556-602), the outcome table and cancellation paragraph (:634-690), §8 commissioning (:1300-1312). The other four changed documents: every changed hunk. |
| Production source | All four changed production files, the changed functions in full with their callers and callees: `advanceOperational`, `reconcileOperational`, `withholdAt`, `operationalFailureAt`, `currentOperationalAdmission`, `qualifyOperationalRetained` (admission); `operationalAdmissionWrite`, `AdmissionHint`, `WithOperationalOriginal`, `operationalTurn`, the four binding functions, `canBind`, `matchesOriginal`, `qualifiesOriginal`, `validOperationalStagePreimage` (store); `measureOperationalStage` and `operationalStageEntry` (`staging_custody.go`, unchanged, read for the survivor argument). |
| Guard (test code) | `wholeValueReferences`, `dynamicMethodReferences`, `validateGuardedProductionFileSet`, the overlay loader, `mergedProductionReferences`, the commissioning gate and its prerequisite list, and the new self-test tables, in `workstream_c_guardrails_test.go` and `reliable_submit_guardrails_test.go`. |
| Tests | Every changed hunk of the seven changed test files. The red team's file changed in one comment (O-5 of the prior audit). |
| Validation evidence | My own runs (section 8). The writer's numbers were compared with mine; the writer's evidence scripts were not executed. |
| Schemas, migrations, scripts, configuration | Not changed by this commit (verified from the path list). Not re-inspected. |
| Not inspected | The 10 base-relative paths that this commit does not touch were audited at `b6d2f77` by the prior audit and are byte-identical here (the repair-only manifest has 16 paths); I did not re-audit them. Unchanged production files outside the call paths named above. macOS behaviour and red-teaming (non-goals of the brief). |

## 6. Findings

### 6.1 Summary

| ID | Severity | Type | In one line |
| --- | --- | --- | --- |
| A3-1 | **medium, blocking** | patch defect, test guard (residual of RT-1 and A2-1) | A generic function whose constraint names a protected type converts its operand without being listed; when its use is in another package, nothing lists it. Shown end to end: a revoked artifact is admitted and the whole suite stays unchanged. |
| A3-2 | low | patch defect, test adequacy | The rule that a denial wins over an ended context is right in the code and held by no test (mutant M16 survives the whole package). |
| A3-3 | low | patch defect, documents and gate | The answer of a refused first delivery is deferred to "the public mapping, a later gate", and the machine gate does not name it. |
| A3-4 | low | patch defect, documents | The documents do not say where a cancelled call still returns the stored run, and the outcome table says "No" for every case. |
| A3-5 | low | patch defect, guard self-test | No guard self-test has an instantiation in which only one of several type arguments names the owner (mutants G04 and G11 survive). |

No pre-existing issue is raised by this audit. Observations are in section 6.4.

### 6.2 Patch defects

```text
AUDIT FINDING
ID / Type / Severity: A3-1 / test guard (typed inventories), residual of RT-1 and A2-1 / medium, blocking
Current contract or strategic target: RT-1 (03-red-team.md): the typed guard lists every production
  write of a protected field that does not spell it, or the exclusion is named. Owner document
  .docs/execution_lifecycle/reliable_submit_operational_handoff.md :556-582 (a conversion is listed in
  both directions; an instantiation whose type argument is, contains or points to the owning type is
  listed) and :584-602 (limits by name, among them "the bodies of called functions and methods ...,
  where a generic one is listed only at an instantiation that names an owning type" and "Their scope
  is these two packages: a whole-value write of an exported owning type from another package ... is
  not listed, and yields a Service without a view, which admits nothing").
Path and line: es/admission/workstream_c_guardrails_test.go
  :4338-4349  reinterprets: an operand whose type is a type parameter neither "holds" nor "contains"
              the owner (:4296-4335 look at the underlying type, which for a type parameter is its
              constraint interface), so its conversion to a same-shape struct pointer is not recorded;
  :4380-4387  the instantiation that would name the owner is recorded only where it is written in the
              package being inventoried;
  :4009-4014  mergedProductionReferences: each owning type is inventoried in the package that
              declares it, and in no other.
Evidence: all at c41e177 in a scratch copy, sources and complete outputs in 08-audit-evidence/probes/.
  E1V (guard-probe-real-2.txt, guard-probe-real-3.txt). Added to es/admission, in one new file: three
    exported generic functions, ZZAuditReopen[S interface{ *Service }], ZZAuditView[S interface{
    *Service }] and ZZAuditClearView[V interface{ *operationalAdmissionSnapshot }]. Each converts its
    type-parameter operand to a pointer to an anonymous same-shape struct; none spells a field of
    Service or of the view. Added to es/app/app.go: one call of each, behind a condition that is never
    true. Result: gofmt lists neither file; go build ./... exit 0; go vet ./es/admission/ ./es/app/
    reports nothing that it does not report on the unchanged tip; the guard tests pass (339 results,
    0 failing); the whole suite has 6,360 results and the same 42 failing names as the unchanged tip
    (the two extra results are my two probe tests, which only log). No repository test notices.
    What the functions can do, from the two probe tests:
    (a) Latches. EGS publishes a revocation of the artifact of the delivery. The Service latches
        supersession and refuses twice (Unavailable; 0 claims, 0 POSTs). EGS then cannot be reached.
        After ZZAuditReopen the same delivery is accepted: run and receipt returned, revision 6,
        1 POST. The latch that is documented to last for the life of the process, and the 30-second
        confirmation limit, are both gone.
    (b) View. A retained claim at revision 1. A restarted Service is commissioned with content that
        revokes the claim's artifact; its EGS serves and confirms that content. It refuses twice
        (Denied). After ZZAuditClearView(ZZAuditView(service)) the claim completes: accepted,
        revision 6, 1 POST. EGS was reachable and equal throughout: nothing latches again.
  E1 (guard-probe-real.txt): the first form, latch write only. Same detection result (6,359 results;
    the 42 known failures plus my own probe test, whose assertion was wrong for that scenario). It
    also shows the limit of (a): with EGS reachable and still serving the different trust, the next
    call's confirmation latches again and the call is refused.
  E1-CONTROL: the same function instantiated inside es/admission fails the guard (whole-instantiate).
  E1-DECLARED: the function alone, instantiated nowhere, passes the guard tests.
  E3 (guard-probe-real-2.txt): the same between the two guarded packages. A generic function in the
    store package clears the busy latch of an OperationalAccess; it is instantiated from
    es/admission. Guard tests pass; whole es/admission 1,926 results, 0 failing; whole store package
    754 results, the 3 known failures. E3-CONTROL (instantiated in the store package) is caught.
  Synthetic (guard-probe-synthetic.txt): seven generic bodies with a type-parameter operand and no
    instantiation in the package (G1 to G5, G8, G10) record no occurrence.
Impact: forward-looking, as for RT-1 and A2-1. A later change can add such a function and a caller in
  another package; admission then ignores a revocation while every test described as preventing that
  stays green. Nothing in production uses the shape today. The two packages hold one generic
  declaration (replayPresence[T any], es/admission/reliable_submit_replay_intent.go:25), and it names
  no owning type. The private handoff has no production caller.
  Why this is not covered by the named limits: the document names both halves (generic bodies are
  listed at instantiations; the scope is the two packages) but states the consequence of the scope
  limit as fail closed. For this route it is not. The prior audit's test for accepting a named limit
  (06-audit.md, R1) was that the form leaves a trace in some inventory. This one leaves none: the
  body sits in a file the guard reads, and the guard reads past it.
Required correction: R1 in section 9. In short: list the generic at its declaration. A type parameter
  whose constraint has a term that is, holds, contains or points to an owning type (directly, through
  a named constraint or in a union) is an occurrence of that type in the declaring package, whatever
  instantiates it. Today that inventory is empty. Add self-tests and the end-to-end forms; correct
  the two sentences of the owner document.
Uncertainty: I searched for relatives by reasoning and with 52 synthetic cases and 12 probes on the
  real packages (section 7.2); this is not a proof that no other form exists. The red-team pass on
  the combined PR #12 is the place to push further. The effect probes use the test fixtures of the
  package; I did not run them against a deployed service.
Patch defect or pre-existing issue: patch defect. The instantiation rule, its self-tests and the two
  sentences are new in this commit. The per-package scope itself is older (O-7 of 06-audit.md, where
  only the whole-value write was considered).
```

```text
AUDIT FINDING
ID / Type / Severity: A3-2 / test adequacy (a denial under an ended context) / low
Current contract or strategic target: owner document :662-666: a pre-check or cut that has read the
  row reports "a denial that its evaluation returned as `OperationalDenied`, also when the context
  has ended meanwhile. A cancellation that arrives during an evaluation that allows is reported as
  the cancellation". Outcome table :643: Canceled only when "the admission returned no refusal of
  its own in this call". 07-repair.md section 4.6 states the A2-8 rule the same way: a completed
  denial answers Denied, also when the context has ended meanwhile.
Path and line: es/admission/reliable_submit_operational_admission.go:493-498 (the refusal is returned
  before the context is looked at). es/admission/reliable_submit_operational_admission_test.go:3172
  ("during the evaluation"): its hook reports an error when an evaluation refuses, so the test
  exercises only the second sentence (an evaluation that allows).
Evidence: mutant M16 adds a look at the context before the refusal, so that an ended context answers
  Canceled although the evaluation refused. It survives the tests that pin the cancellation rule and
  the whole es/admission package (1,926 results, 0 failing). The code at the tip is correct by
  reading.
Impact: none on what is admitted. With the order reversed the run is still withheld; only the reason
  changes from Denied to Canceled. But the first half of the rule that the judgment call A2-8 rests
  on ("the admission's own judgment wins") is held by reading only for a denial, and a later edit can
  reverse it without a failing test.
Required correction: R2 in section 9: one test.
Uncertainty: the two earlier refusals of the same function (signature :464, trust model :468) are in
  the same position. I mutated only the policy refusal.
Patch defect or pre-existing issue: patch defect (the sentence and the test are new in this commit).
```

```text
AUDIT FINDING
ID / Type / Severity: A3-3 / deferred decision without a machine trigger (documents and gate) / low
Current contract or strategic target: project rule: no "accept now, revisit later"; an edge that
  stays open needs a machine-enforced trigger. Owner document :646-649: "what a first delivery tells
  its caller belongs to the public mapping, a later gate". Design 5.6: "The public mapping stays a
  later gate".
Path and line: owner document §8 :1300-1312 (five prerequisites: CP-ROLLBACK, CP-EPOCH,
  CP-POLICY-CUSTODY, CP-NATIVE, CP-RELEASE); es/admission/reliable_submit_guardrails_test.go:1304
  (operationalCommissioningPrerequisites, the same five), :1711 (their count); PLANS.md:24-25.
Evidence: read by me at the tip. The gate fails on the first production reference to the handoff or
  to commissioning and prints the five identifiers. None of them is the public mapping of the
  handoff's reasons. The fresh-delivery answer itself is pinned (mutant M17 is caught), so it cannot
  change silently; what is not held is the promise to decide it before a caller exists.
Impact: when the handoff is wired into the real submit path, nothing asks what a refused first
  delivery tells its caller. If the private reason were simply forwarded, a caller would be told
  "unavailable" (try again) for a request the rules keep refusing, where ordinary Submit says
  signer_revoked or artifact_revoked today.
Required correction: R3 in section 9: a sixth prerequisite in the table and in the list.
Uncertainty: none about the facts. Whether David wants "denied" or "unavailable" there is his to
  decide at integration; this finding does not ask for that decision now.
Patch defect or pre-existing issue: patch defect (the sentence that defers it is new in this commit).
```

```text
AUDIT FINDING
ID / Type / Severity: A3-4 / documents against code (where a cancelled call returns the run) / low
Current contract or strategic target: owner document :643 "The context of the call has ended and the
  admission returned no refusal of its own in this call | OperationalCanceled | No" (column "Run
  disclosed"), :645 "Every row is value-free and withholds run and receipt at the refused cut", and
  :667-669 "... because it withholds the run and a cancellation alone does not".
Path and line: es/admission/reliable_submit_operational_handoff.go
  :553-562  reconciliation entry: a cancelled call answers Canceled and keeps the stored run;
  :574-583  observation binding (new in this commit): Canceled, run kept;
  :371-379  verification of an accepted receipt (new in this commit): Canceled through
            operationalFailureAt, so no run is returned, although the receipt and marker are durable.
Evidence: read by me; pinned by TestOperationalAdmissionCancelledCallAnswersCanceled ("before a
  completed observation is bound", "before an accepted receipt is verified"). Mutant M10 (the
  observation binding withholds the run) and M08, M15 (receipt) are caught, so both behaviours are
  deliberate and held.
Impact: a reader of the table expects no run in any cancelled answer; a reader of the paragraph
  expects the run in every cancelled answer after a marker. The code does one at reconciliation and
  the other at an accepted-receipt replay. No effect on what is admitted.
Required correction: R4 in section 9: say it in one or two sentences and in the table cell.
Uncertainty: I did not judge which behaviour is better at the receipt replay; a cancelled caller is
  not waiting for the answer. I ask for the text to match the code, not for a behaviour change.
Patch defect or pre-existing issue: patch defect (the row and two of the three points are new).
```

```text
AUDIT FINDING
ID / Type / Severity: A3-5 / guard self-test adequacy (instantiations with several type arguments) / low
Current contract or strategic target: owner document :574-575: an "instantiation of a generic
  function or type whose type argument is, contains or points to the owning type is listed".
Path and line: es/admission/workstream_c_guardrails_test.go:4380-4387 (the loop over the type
  arguments); self-test table :3100-3107 (eight instantiation cases) and :3153 (the negative
  control).
Evidence: mutants G04 (only the first type argument is read) and G11 (only the last) survive the
  eleven guard tests and the whole es/admission package (1,926 results, 0 failing, each). Seven of
  the eight cases have one type argument; the eighth (first[L ~[]E, E any] used with []Service)
  names the owner in both.
Impact: none today: the loop at the tip reads every type argument. A later edit that stops doing so
  would go unnoticed, and a generic with two type parameters would then be listed or not by the
  position of the owner.
Required correction: R5 in section 9: two self-test cases.
Uncertainty: none.
Patch defect or pre-existing issue: patch defect (the rule and its self-tests are new in this commit).
```

### 6.3 Pre-existing issues

None raised. P-1 of the prior audit is closed (section 7.1).

### 6.4 Observations

None of these blocks or needs a repair.

| ID | Kind | Observation |
| --- | --- | --- |
| O3-1 | patch, test seam | The new seam `admissionCommit` (`internal/reliablesubmit/operational_handoff.go:390-393`) is held by a comment ("no function sets it"). Like the three older seam fields (`fault`, `prestageProof`, `releaseProof`) it has no field inventory, so a production assignment inside the store package would fail no test. The older seams are set through `Configure…ForProof` functions whose callers are inventoried; this one has no setter at all, and the store's own tests assign the field. One inventory row (two reads in `operationalAdmissionWrite`, no write) would make the comment a test. Optional. |
| O3-2 | patch, documents test | `operationalCustodyLockHolders` (`docs_contract_test.go:14057-…`) finds `<receiver>.mu.Lock()` and `.RLock()` inside methods of `*OperationalCustody`. A helper function that takes the lock for a custody passed as an argument would not appear in its list. None exists today: the typed lock inventory lists every reference to the field (`workstream_c_guardrails_test.go:2508-2522`), and the seven sites that take the lock are methods. |
| O3-3 | defence in depth, confirmed | With EGS reachable and serving different trust, clearing the two Service latches does not re-admit: the confirmation that runs at each effect-capable call latches again (probe E1). Clearing the withdrawn latch alone does not re-admit either once the withdrawal's own write has committed, by reading: the withdrawal is also a row state (`operational_admission.go:55-60`), and every cut compares the token with the enabled row. A3-1's effect needs EGS unreachable, or the write to the view. |
| O3-4 | probe detail | A whole-value copy of a store type in `es/admission` (probe E2) passes the guard tests. `go vet` reports that copy ("assignment copies lock value"), but `go vet` is not part of the test suite on this branch. The copy is refused at use by the store's self-pointer checks. |
| O3-5 | outside this PR | On the unchanged tip, `gofmt -l es/` lists `es/runtimehelper/main.go` and `es/runtimehelper/privilege_linux.go`, and `go vet ./es/admission/` reports a lock copy in `es/admission/result_auth_test.go:395`. None of the three files is among the 26 paths of this PR. The 11 Go files this commit changes are gofmt-clean. |
| O3-6 | hygiene, carried over | The repair commit's message carries the harness's co-author trailer, which names a model (O-12 of the prior audit). A merge that should carry no model name needs a squash with a clean message. Not a correctness matter. |

## 7. What the brief asked me to check

### 7.1 Every finding of the prior audit, with its test

"Confirmed" means I broke the fix in a scratch copy and a test failed (mutant IDs in section 8.3), or I ran the probe that used to pass and it now fails.

| 06 finding | Fix at `c41e177` | Test that holds it | How I confirmed |
| --- | --- | --- | --- |
| **A2-1** (medium): the guard misses a pointer conversion away from a protected type | `wholeValueReferences` lists a conversion in both directions (`reinterprets`, `workstream_c_guardrails_test.go:4338-4349`) and an instantiation whose type argument is, contains or points to the owner (`:4380-4387`) | Self-test table (`:3080-3107`), the overlay probes in `TestExecutionSubstrateSynchronizedMutableStateReferenceInventoryIsExact` and `TestOperationalHandoffOpaqueAuthorityBoundaries` | The prior audit's two end-to-end mutants GM1 and GM2 now fail the guard tests. Guard mutants G01, G02, G03, G05 and G06 are caught by the self-test table or the overlay probes; G04 and G11 survive (finding A3-5). 52 synthetic cases of my own. **One relative still passes: finding A3-1.** |
| **A2-2** (low): a call through an interface passes the commissioning gate | `dynamicMethodReferences` (`:4159-4203`) counts interface and constraint methods of the same identity and their selections; the gate refuses them | `TestTypedMethodReferenceInventoryCountsDynamicDispatch` (11 results), the overlay probe "gated entries reached through an interface in the real packages" | Probe P1 now fails the guard tests. Guard mutants G07 and G08 are caught by the overlay probe. 11 synthetic dispatch cases (embedded pointer, method value, method expression, alias of an interface, embedded constraint and others): nine are refused by the gate, one is not expressible in Go, and one (a defined type over the Service) does not have the gated method. |
| **A2-3** (low): three lock statements did not match the code | Sentences corrected in the owner document, the persistence document, the admission model document and one code comment | `operationalAdmissionLockRule` and the lock-holder rows in `docs_contract_test.go` (`:14041-14055`, 17 mutation cases in `TestOperationalSubmitHandoffCurrentAdmissionV2RejectsUnsafeMutants`) | Read against the code: `operationalAdmissionWrite` holds the custody lock in read mode (`operational_admission.go:145-146`); the confirmation holds neither `Service.mu` nor the owner mutex while it fetches (`reliable_submit_operational_admission.go:284-297`) and runs inside the borrow at the two pre-checks. The statements are now true. |
| **A2-4** (low): the Denied row was not limited to retained claims | Row limited to retained originals; a row for the refused first delivery (Unavailable, nothing stored) | `TestPR12RetainedAdmissionCuts`, two fresh-delivery cases now assert the reason (`:253-280`); `operationalAdmissionOutcomeRule` pins the rows | Mutant M17 (a refused first delivery answers Denied) is caught by "fresh ordinary policy denial". Judgment in section 7.4. |
| **A2-5** (low): the value of the evidence cap was not pinned | Literal lengths 262,144 (accepted) and 262,145 (refused) | `TestOperationalHandoffV2CustodyStructure` (`operational_handoff_test.go:199, 213`) | Mutants S12 (one byte larger) and S13 (one byte smaller) are caught by it. |
| **A2-6** (low): the published-shape test was loose | Each of the four openers asserts its specific refusal; the control opens the amended shape with all four | `TestOperationalAdmissionPublishedSchema5ShapeRefused` (`operational_admission_test.go:1418-1555`) | By reading. No mutant: the subject is the stored schema text. |
| **A2-7** (low): three checks of the store's admission write had no test | Test-only COMMIT seam `admissionCommit` (`operational_handoff.go:390-393`, read at `operational_admission.go:195-198`); no function sets it | `TestOperationalAdmissionCommitAnswerLost` (7), `…WriteRequiresCurrentStore` (4), `…StoredTimeAheadOfTheClock` (1), `…WriteReadsBackBeforeCommit` (1), `…WriteLooksAtTheContextBeforeCommit` (4), `TestOperationalHandoffCutLooksAtTheContextBeforeCommit` (5) | Of mutants S01 to S11, nine are caught, each by the test written for its check. S07 and S10 survive and change no behaviour (section 8.3). The seam is nil in production: the field has no assignment in non-test code (searched), and it can only replace the COMMIT with a function supplied by test code of the same package. |
| **A2-8** (low): a cancelled call did not always answer Canceled | Six points (table in section 7.5) | `TestOperationalAdmissionCancelledCallAnswersCanceled` (23 results) | Mutants M01 to M11, M14 and M15 are caught. M12 and M13 survive (section 7.7). M16 survives: the half of the rule that says a denial wins has no test (finding A3-2). Judgment in section 7.5. |
| **P-1** (pre-existing): the `matchesOriginal` clause had no test | No production change | `TestOperationalAdmissionTokenAtEveryCut` with `operationalForeignMatches` (`operational_admission_test.go:133-…, 1073`) | Mutants S14 to S18 (the clause itself and each of its four comparisons) are caught by it. |
| O-2, O-5, O-7, O-8, O-10, O-11, O-13 | Wording | Document rules | By reading the changed hunks. O-7's sentence is imprecise (finding A3-1, document part). |
| O-6: a production file behind a custom build tag | File-set check | `TestOperationalGuardLoadsEveryProductionFile` (10 results) | Probe P2 now fails it. Guard mutants G09 and G10 are caught by it. |
| O-9: four Service fields without an inventory | Inventories for `egsClient`, `trustModelVerifier`, `provenanceVerifier`, `admissionPolicyEvaluator` | The synchronized-state inventory test | By reading the added rows; the test passes at the tip. |
| O-1, O-3, O-4, O-12 | No change, with a stated reason (07-repair.md section 5) | n/a | Reasons read; I agree. O-12 (commit trailers name a model) stays a step for the merge. |

### 7.2 The guard: prior escapes, close relatives and my own new escapes

Probes on the real packages, each in a scratch copy at `c41e177`, each followed by gofmt, `go build ./...`, `go vet` and the eleven guard tests (the nine of the prior audit plus the two new ones). "Passes" means the guard tests stay green.

| Probe | What it adds | Result at `b6d2f77` (06-audit.md) | Result at `c41e177` (mine) |
| --- | --- | --- | --- |
| Baseline | nothing | n/a | guard tests pass (339 results) |
| GM1 | the installed view rewritten through a pointer conversion | not caught (A2-1) | **caught** (2 guard tests fail) |
| GM2 | the Service latches cleared through a pointer conversion of the receiver | not caught (A2-1) | **caught** |
| P1 | commissioning, advance and withdrawal called through an interface | not caught (A2-2) | **caught** |
| P2 | a spelled latch write in a file behind a custom build tag | not caught (O-6) | **caught** (`TestOperationalGuardLoadsEveryProductionFile`) |
| P3 | `*a.service = admission.Service{}` in `es/app` | not caught (O-7) | not caught: the named limit; fail closed (section 7.6) |
| E1-CONTROL | a generic latch write in `es/admission`, instantiated in `es/admission` | n/a | caught at the instantiation |
| E1-DECLARED | the same generic, instantiated nowhere | n/a | passes |
| **E1, E1V** | the same generic (E1V: three of them), instantiated from `es/app` | n/a | **passes; whole suite unchanged; a revoked artifact is admitted (A3-1)** |
| E2 | a store owning type declared, overwritten and copied in `es/admission` | n/a | passes; fail closed by the store's self-pointer checks (O3-4) |
| E3-CONTROL | a generic latch write in the store package, instantiated there | n/a | caught |
| **E3** | the same generic, instantiated from `es/admission` | n/a | **passes; both packages unchanged (A3-1)** |

Synthetic cases against the tip's own inventory and gate functions (`guard-probe-synthetic.txt`, 52 cases, test file `zz_audit8_guard_probe_test.go`, never committed):

- **Controls (3):** a spelled write and the A2-1 conversion are listed; a write to an unrelated twin is not.
- **Listed, as they should be (26):** conversions through an alias, a generic alias, a named double pointer, a slice-to-array pointer, an array pointer, a deferred call, a parenthesized operand, a channel element, a map element, a function result, a type-switch binding, a method expression on the twin, an embedded pointer; generic bodies that convert a *concrete* operand (approximate constraint, named pointer constraint, holder constraint, container constraint); a whole overwrite and a field write through a dereferenced type parameter; every instantiation written in the package: with a pointer to the owner, a holder, a slice of pointers, a standard-library generic, `atomic.Pointer` of the owner, a generic method value and an inferred generic constructor.
- **Not expressible in Go (5):** a field and a method selected on a type parameter with a core type, a double-pointer conversion, a conversion between structs that hold different pointer types, a conversion of a holder to an anonymous holder of an anonymous twin.
- **Not listed, harmless (2):** an instantiation with `**Service` (it can only move pointers; any step to the value has a concrete operand and is listed), and a defined type over the Service (it does not have the gated method).
- **Not listed, the gap (7):** generic bodies whose converted operand is a type parameter, with no instantiation in the package (G1 to G5, G8, G10). This is A3-1.
- **Dispatch past the commissioning gate (9, besides one case in each of the two groups above):** a direct call, a local interface, an embedded pointer, an embedded pointer stored in another interface, a method expression, a method value in a struct field, a generic wrapper, an interface that embeds the constraint, and an alias of an interface are all refused by the gate.

Why I believe the gap is exactly A3-1 and not wider (reasoning, not proof): inside one package, a generic body can only run for a protected type through a concrete instantiation, and Go lets a type parameter be converted to a same-shape struct pointer only when every type in its constraint's type set is such a pointer. So either the instantiation is written in the package (listed), or it is in another package (not read). From another package nothing else selective is possible without `unsafe`: unexported fields cannot be named, and a mirror struct cannot be declared there, because unexported field names of two packages are different names.

### 7.3 The guard's own mutants

Eleven mutants of the guard code (section 8.3): nine are caught by the guard tests (the self-test tables or the overlay probes). Two survive, and they are one gap (finding A3-5): G04 reads only the first type argument of an instantiation and G11 only the last, and no self-test has an instantiation in which one type argument names the owner and another does not.

### 7.4 The writer's judgment call on A2-4 (what a refused first delivery answers)

**What the writer chose.** `OperationalDenied` is the answer of the re-judgment of a retained original only. A first delivery that ordinary resolution refuses, whatever the cause, answers `OperationalUnavailable`, and nothing is stored. The outcome table, `PLANS.md` and two pinned test cases say so (`TestPR12RetainedAdmissionCuts`, "fresh ordinary policy denial" and "fresh ordinary revocation denial", `reliable_submit_operational_admission_test.go:253-280`; my mutant M17 changes the answer to Denied and is caught by them).

**Against the approved design.** Design 5.6 adds `OperationalDenied` with a four-row table and gives the reason: "with stranding reduced to 'claims the current rules deny', the caller must be able to tell 'denied' from 'try again later'". Stranding is about a stored claim. A refused first delivery stores no claim, so nothing is stranded and the table's subject, the re-judgment at a cut, does not arise. The design then says "The public mapping stays a later gate". The prior audit offered both corrections as acceptable (R4: limit the row to retained originals and state the fresh-delivery reason, "or report Denied there too"). The behaviour is the base's (`8058561`, same lines, verified by the prior audit), so the repair changed text and tests, not the answer.

**My judgment.**

- It is **consistent with the approved design** as written, and it is the option that changes no behaviour.
- It is **not a public-contract change**. The handoff has no production caller (the commissioning gate fails on the first one, section 7.6), the result type is private to `es/admission`, and the owner document still says that no public HTTP status, DTO field or producer declaration is selected (:1296-1298).
- It is **not a compromise today**, but it **leaves one product question open, and only prose holds it open**. On a first delivery the private result does not tell "the rules refuse this" from "authority is not available right now". Ordinary Submit already tells callers the difference (`signer_revoked`, `artifact_revoked`). If the future public mapping simply forwarded the private reason, a caller of reliable submit would be told "try again later" for a request that the rules will keep refusing. The owner document assigns the answer to "the public mapping, a later gate" (:646-649). That gate exists as a sentence. The machine gate that fires when the handoff gets its first production caller prints five prerequisites (`CP-ROLLBACK`, `CP-EPOCH`, `CP-POLICY-CUSTODY`, `CP-NATIVE`, `CP-RELEASE`), and the public mapping is not one of them. Under the project rule that an open edge needs a machine-enforced trigger, this is finding **A3-3 (low)**: add the public mapping as a sixth named prerequisite. That is a few lines, and it changes no behaviour.
- **For David:** nothing to decide now. The decision (does a refused first delivery tell its caller "denied" or "unavailable") belongs to the design of the integration into the real submit path, which is the next step after PR #12. With A3-3 fixed, the gate itself will ask for it.

### 7.5 The writer's judgment call on A2-8 (what a cancelled call answers)

**What the writer chose.** A judgment that the admission returned in this call wins. Otherwise a step that fails because the context of the call has ended answers `OperationalCanceled`. The prior audit named two points (the pre-check's read of the row and the intent binding). The writer applied the same rule at four more: the binding of the staged tree, the binding of the marker, the verification of an accepted receipt, and the binding of a completed observation.

| Point | Code at the tip | Answer when the context has ended | Run in the result |
| --- | --- | --- | --- |
| Pre-check's read of the admission row | `reliable_submit_operational_handoff.go:320-330` | Canceled (was Unavailable) | withheld |
| Intent binding | `:404-407` | Canceled (was Integrity) | withheld |
| Stage binding | `:461-466` | Canceled (was Integrity) | withheld |
| Marker binding | `:484-487` | Canceled (was Integrity) | withheld |
| Verification of an accepted receipt | `:371-379` | Canceled (was Integrity) | not returned |
| Binding of a completed observation | `:574-583` | Canceled (was Integrity) | **kept** (the marker is durable) |

**Against the approved design.** The design does not decide this. It lists it as an open risk (section 14, item 4: whether confirming at the two pre-checks "changes any existing result mapping when EGS is slow and the context is cancelled"). The owner contract already had the governing rule before this repair: when one call is both cancelled and refused by the authority, the authority refusal is reported, "because it withholds the run and a cancellation alone does not". The writer's rule is that sentence applied everywhere.

**What I checked.**

- *No durable effect hides behind the new answer.* Under an ended context the store refuses every read, binding and writer turn of the borrow (`life.live()` is tied to the same context; `canBind` at `operational_handoff.go:1287-1294`; each writer turn looks at the context immediately before its COMMIT, `:957`, and the admission write at `operational_admission.go:191`). So "Canceled" at these points is never the answer to a call that wrote something in that step. My mutants S05 and S11 remove the two looks before COMMIT and are caught (by `TestOperationalAdmissionWriteLooksAtTheContextBeforeCommit` and `TestOperationalHandoffCutLooksAtTheContextBeforeCommit`).
- *A real integrity failure is delayed, not lost.* If a binding would also fail under a live context (a tampered stage, a wrong receipt) and the context has ended, the call answers Canceled. The caller's retry, with a live context, answers Integrity. Nothing is accepted in between.
- *The admission's own judgment still wins.* A denial that the evaluation returned is reported as Denied also when the context ended meanwhile (`reliable_submit_operational_admission.go:493-498`). That order is right in the code, but no test holds it: my mutant M16 puts a look at the context before the refusal and survives the whole package (finding A3-2, low).
- *Each point is pinned.* `TestOperationalAdmissionCancelledCallAnswersCanceled` (23 results). My mutants M01 to M11, M14 and M15 change one point each, in both directions where a live-context failure is reachable; all thirteen are caught.

**My judgment.** Consistent with the owner contract's existing rule and with the prior audit's option (a) of R8. More truthful than before: "Integrity" claimed evidence of tampering where the cause was the caller's own cancellation. **Not a compromise and not a public-contract change**: the reasons are value-free and private, and no production caller exists. Nothing here needs David.

One thing the documents do not say (finding **A3-4, low, documents**): where a cancelled call still returns the stored run. A cancelled reconciliation keeps it (entry, observation binding, sender entry), a cancelled accepted-receipt replay does not, and the outcome table's cancellation row says "Run disclosed: No" without that distinction.

### 7.6 The package-scope limit (probe P3): acceptable, and machine-held?

The owner document names the limit (:596-599): the inventories' "scope is these two packages: a whole-value write of an exported owning type from another package, such as `*service = admission.Service{}`, is not listed, and yields a Service without a view, which admits nothing."

- **The named example is as stated.** I re-ran P3: the overwrite written in `es/app` passes the guard tests and the `es/app` package (439 results, none failing). The result is fail closed, by two checks in `currentOperationalAdmission` (`reliable_submit_operational_admission.go:347-348`): a Service without a view stops, and a view installed for another Service stops (a whole-value copy of a commissioned Service). Both are behaviour, and tests hold them: my mutant A01 removes the owner comparison and is caught (in the whole-package run, by `TestOperationalAdmissionCommissioning`, case "view is a private copy bound to owner, installation and epoch", and by the field inventory, which counts one read fewer); the nil view cannot be removed without a nil dereference.
- **Machine-held?** The fail-closed consequence is. The limit itself is not: nothing fails when another package writes such a value, and nothing in the repository tells a reader of `es/app` that the inventories do not read it.
- **The stated consequence does not cover every route through the limit.** Finding **A3-1**: a generic function in `es/admission` whose instantiation is in another package writes the latches selectively, and nothing lists it. For that route "admits nothing" is false. With A3-1 fixed at the generic body, what remains of the package-scope limit is whole-value writes and copies only, for which the fail-closed statement holds, and I consider the limit acceptable as a named limit then.
- **One precision** (part of A3-1's document correction): the scope is narrower than "these two packages". Each owning type is inventoried in the package that declares it (`mergedProductionReferences`, `workstream_c_guardrails_test.go:4009-4014`). A store type handled in `es/admission` is not listed either (probe E2). For those types the store's own self-pointer checks refuse a copied or zeroed value (`a.self != a`, `c.self != c`), so this too is fail closed.

### 7.7 The two survivors the writer explains by reading (07-repair.md section 6, item 8)

The mutants make the intent binding (`R2-INTENT-ALWAYS`) and the stage binding (`R2-STAGE-ALWAYS`) answer Canceled also under a live context. The writer's claim: neither binding can fail under a live context, so no test can tell the mutant from the code.

I rebuilt both (my M12 and M13) and ran them against the whole `es/admission` package: both survive (1,926 results, 0 failing, each). By reading, I agree with the claim:

- **Intent binding** (`operational_handoff.go:1146-1153`) fails when `canBind(p, 2)` fails or the locator is zero. `canBind` (`:1287-1294`) fails for an ended borrow, a busy access, or a projection that is not the access's current one at revision 2. Inside the borrow's callback with a live context the borrow is live, the access is used by one goroutine, and `p` is the projection the store just returned. The locator is a SHA-256 output.
- **Stage binding** (`:1169-1179`) fails for the same `canBind` reasons at revision 3, for a zero project or locator, for an intent that is not the intent of this locator, or for a preimage that `validOperationalStagePreimage` refuses. The intent comparison has already been made, with an answer of its own, at `reliable_submit_operational_handoff.go:384-386`. The preimage is the one `measureOperationalStage` returned without error two statements earlier (`:457-461`), and a failed measurement has its own Integrity answer there. I compared the two functions rule by rule (entry order and count, modes, device, owner, link counts, the 262,144-byte and 1,048,576-byte limits): the measurement enforces everything the validation checks.

So a live-context failure at these two points needs a defect elsewhere. The unmutated code would then answer Integrity, which is the intended answer; what is missing is only a test that could notice if that answer were lost. A seam to force it would be test-only code in production for an unreachable branch, and I do not ask for one. The marker binding and the receipt verification, where a live-context failure *is* reachable (a changed stage, a wrong receipt), are pinned: my M14 and M15 are caught (by the two control cases: a staged tree that drifted before the marker, and an accepted receipt that does not verify).

Uncertainty: this is an argument from reading plus two surviving mutants, not a proof.

## 8. Validation assessment

### 8.1 What I ran, on which bytes

Everything ran on the exact bytes of `c41e177` (and of `b6d2f77` for the comparison), cloned from the provenance clone, plus one test-file overlay that the store package needs on Linux (`store-test-linux-overlay.patch`, SHA-256 `1173ed062000267f4365ff40b0a7530da9e08d9e7a7a9a922992869143e19ad4`, byte-identical to the one the prior audit and the writer used; it changes how one test builds a `Stat_t` mode and touches no production file). User `ci`, Go 1.26.5 linux/amd64, `GOPROXY=off`, umask 022.

| Run | Command | Result |
| --- | --- | --- |
| Full suite at `c41e177` | `go test -count=1 -timeout 90m -json ./...` | 6,358 results: 6,275 pass, 42 fail, 41 skip. 19 packages pass, 2 fail, 20 have no tests. `es/admission` 1,925 pass, 1 skip. Store 749 pass, 3 fail, 2 skip. Root 2,272 pass, 39 fail. |
| Full suite at `b6d2f77` | same | 6,204 results: 6,121 pass, 42 fail, 41 skip. |
| Comparison | `full-suite-compare.tsv` | 0 names changed result. 0 names removed. 154 names added (115 admission, 22 store, 17 root), all pass; 10 new top-level tests. The 42 failing names are identical. |
| The 42 failures | read | 12 top-level tests: nine `TestRemoteAlpha…` operator-script tests of the root package, and the three old-binary refusal tests of the store package, which need an authenticated older source tree that a scratch clone does not have (`TestOperationalHandoffSchema4BinaryRefusesSchema5`, `TestSQLiteV3OldBinaryRefusesWithoutMutation`, `TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation`). Environment, the same at both commits and in the prior audit. |
| Race detector, store | `go test -race -count=1 -timeout 120m -json ./es/admission/internal/reliablesubmit/` | 754 results: 749 pass, the same 3 failures, 2 skip. No data-race report. 425 s. |
| Race detector, admission | `go test -race -count=1 -timeout 120m -json ./es/admission/` | 1,926 results: 1,925 pass, 1 skip. No data-race report. 1,340 s. |
| Static checks | `git diff --check b6d2f77 c41e177`; `gofmt -l` on the 11 changed Go files; `go build ./...`; `go.mod`, `go.sum` | Clean; clean; exit 0; unchanged. `go vet ./es/admission/ ./es/app/` reports one lock copy in a test file outside this PR (O3-5) and nothing in a changed file. |
| Guard probes | section 7.2 | 12 probes on the real packages, 52 synthetic cases |
| Mutants | section 8.3 | 47 |

The writer's totals agree with mine where the environment allows: 6,358 results, the per-package counts of the two changed packages, 154 new results, nothing from pass to fail. The writer reports 166 failing results in its environment; I have 42. That difference is the environment (the same set as at `b6d2f77` on each side), not this commit.

### 8.2 What the comparison does and does not show

It shows that the repair breaks no existing test and that its new tests pass. It does not show that the new tests are sufficient; the mutants do that.

### 8.3 My mutants

Each mutant is one edit in a scratch copy, run first against the tests that pin the changed behaviour (with `-failfast`), and, if it survives, against the whole package without `-failfast`. Specifications and results: `08-audit-evidence/mutants/`.

| Group | Count | Caught | Survive the whole package |
| --- | --- | --- | --- |
| `es/admission` production: the six cancellation points, in both directions; the first-delivery answer; the owner comparison of the view | 18 | 15 | 3: M12, M13, M16 |
| Store production: the COMMIT seam, the five checks of the admission write, the cut's look at the context, the evidence cap in both directions, each clause of the original match | 18 | 16 | 2: S07, S10 (both equivalent) |
| Guard code: both directions of the conversion rule, the type-parameter rule, the instantiation rule, dynamic dispatch, the file-set check | 11 | 9 | 2: G04, G11 |

Survivors:

| Mutant | What it changes | Whole-package run | Reading |
| --- | --- | --- | --- |
| M12, M13 | The intent binding and the stage binding answer Canceled also under a live context (the writer's two survivors) | `es/admission`: 1,926 results, 0 failing, each | No live-context failure is reachable at these two points (section 7.7). Not a finding. |
| M16 | An ended context wins over a denial that the evaluation returned | `es/admission`: 1,926 results, 0 failing | The order in the code is right and no test holds it. **Finding A3-2.** |
| S07 | The admission write ignores an error of its read-back | Store: 754 results, no failure besides the three environment failures | Equivalent. Every error path of `selectOperationalAdmission` returns the zero row (`operational_admission.go:70-86`), and each of the three rows a step writes is a present row (`:229, :270, :304`), so the comparison `written != want` at `:191` refuses the same calls. |
| S10 | `AdmissionHint` does not look at the context itself | Store: 754 results, no failure besides the three environment failures | Equivalent. `life.live()` in the same condition looks at the borrow's context, and `pooledOperationalAdmission` looks at the call's context first (`:104`). |
| G04, G11 | The instantiation rule reads only the first, or only the last, type argument | `es/admission`: 1,926 results, 0 failing, each | No self-test separates the positions. **Finding A3-5.** |

Counts: 40 of 47 caught, 7 survive. Of the survivors, two are the writer's own (explained by reading), two are equivalent, and three are the two low findings above. `select.tsv` holds the first five mutants (a broader first-stage selection that I replaced because it was slow), `narrow.tsv` the other 42, and `whole.tsv` the whole-package runs of the eight first-stage survivors (A01 survives the first stage only because the tests selected there do not exercise the owner comparison; the whole package catches it).

### 8.4 What did not run

- macOS, red-teaming, the Linux test box: non-goals of the brief.
- The twelve environment-dependent tests above (they ran and failed for the stated reason at both commits).
- The writer's evidence scripts (read as data only).
- `go vet ./...` and the race detector over the whole module: I ran both only for the two changed packages (and `es/app` for vet).
- No test of mine exercises the handoff through a network listener or a deployed service; it has no production caller.

### 8.5 Evidence files (`08-audit-evidence/`)

| File | Content |
| --- | --- |
| `manifests/opening-*.json`, `manifests/closing-*.json` | The four canonical manifests (two ranges, opening and closing) |
| `suite-summary.txt`, `full-suite-compare.tsv`, `runs.log.txt` | Full suite at both commits, the per-test comparison, exit codes and durations |
| `race-summary.txt` | Race detector results for both packages |
| `probes/guard-probe-synthetic.txt`, `probes/zz_audit8_guard_probe_test.go.txt` | The 52 synthetic cases and their source |
| `probes/guard-probe-real.txt`, `-real-2.txt`, `-real-3.txt`, `probes/run_real.py.txt` | The 12 probes on the real packages, with the sources of every added line, and the effect tests' log lines |
| `mutants/mutants-specs.py.txt`, `mutants/mutants-runner.py.txt`, `mutants/*.tsv` | The 47 mutants, the runner, and one row per run |
| `scripts/*.txt`, `store-test-linux-overlay.patch` | How the environment was built and how each run was started |

## 9. Required corrections (repair scope for the writer thread)

One repair tranche, by the writer thread, on the same branch. No production code needs to change.

**Blocking**

- **R1 (A3-1).** Make the guard list a generic at its declaration. In `wholeValueReferences`, treat a type parameter as naming the owner when a term of its constraint's type set is, holds, contains or points to the owning type: a direct term (`*T`, `~*T`, `T`), a term of a union, or the same through a named or embedded constraint interface. Record the declaration of such a type parameter, with a kind of its own, in the declaring package. With that, the generic body is listed wherever it is instantiated, and the inventory is empty today (the two packages hold one generic declaration, `replayPresence[T any]`). An equivalent alternative: record a conversion whose operand's type is such a type parameter. Add to the guard's self-tests the seven forms that record nothing today (a generic function converting to a named twin, to an anonymous mirror, with a write through it, with a whole overwrite through it, with both sides type parameters, a generic type with a converting method, and a chain of two generics) and one negative control (a constraint over an unrelated twin). Add the end-to-end forms to the maintained overlay probes: a generic that clears the Service latches, one that reaches and rewrites the view, and one for a store owning type, each with no instantiation in its package.
  Then correct two sentences of the owner document: the limit "a generic one is listed only at an instantiation" (:586-587), and the scope sentence (:596-599), which should say that each owning type is read in the package that declares it, that another package (the other guarded package included) can then only write or copy a whole value, and what that yields for the Service and for the store's types.
  I do not recommend naming the route as a limit instead: unlike every limit named today, it is not fail closed, and it leaves no trace in any inventory.

**Low, same tranche**

- **R2 (A3-2).** One test beside `TestOperationalAdmissionCancelledCallAnswersCanceled`: a retained claim that the current rules deny, with the context ended from the `evaluated` hook of the refusing evaluation, once at a pre-check and once at a cut. The answer is `OperationalDenied`, with run and receipt withheld. Check that a look at the context placed before the refusal (my M16) then fails.
- **R3 (A3-3).** Add a sixth prerequisite to the commissioning gate, in the owner document's table (§8) and in `operationalCommissioningPrerequisites` with its count: the public mapping of the handoff's reasons, which includes the decision what a refused first delivery tells its caller (Denied or Unavailable). Suggested identifier: `CP-PUBLIC-MAPPING`. Point the sentence at :646-649 and `PLANS.md:24-25` to it.
- **R4 (A3-4).** Say in the owner document where a cancelled call still returns the stored run: it does at the reconciliation entry, at the binding of a completed observation and at the final sender entry; it does not at the verification of an accepted receipt. Correct the "Run disclosed" cell of the cancellation row (:643) and the sentence at :645 to match, together with the document rule that pins the row. Text only. If the writer prefers to return the run at the receipt replay as well, that is a behaviour change: it then needs its own test and a line in the report.
- **R5 (A3-5).** Two self-test cases for the instantiation rule: a generic with two type parameters where only the first type argument names the owner, and one where only the second does (for example `func pair[A, B any](a *A, b *B)` used with `(*Service, *int)` and with `(*int, *Service)`). Check that reading only the first or only the last type argument (my G04, G11) then fails.

**Optional, cheap**

- O3-1: one inventory row for `OperationalCustody.admissionCommit` (two reads, no write).

**After the repair:** new provenance for the new tip, a replacement implementation report, then a fresh audit. The brief of that audit can point at the delta: the guard file, the owner document and the commissioning prerequisite. Production code is unchanged by R1 to R5. The red-team pass on the combined PR #12 comes after an accepted audit, as planned.

## 10. Sensitive-material handling

No secret, key, token, credential, personal contact detail or host address was read, written or copied. The evidence holds test names, counts, source lines of my own probes and manifest metadata (repository-relative paths, modes, sizes, SHA-256 values). The commit author's e-mail address is not reproduced. No model identifier appears in this report or its evidence.

## 11. Remaining uncertainty and stop conditions

- **The guard is a search over source forms, not a proof.** A3-1 is the route I found; my argument in section 7.2 that it is the only one of its kind is reasoning.
- **The two survivors of section 7.7** are explained by reading. If the explanation were wrong, the unmutated code would still give the intended answer.
- **The effect probes of A3-1** use the package's own fixtures (a test EGS, a test provider). They show that the checks are bypassed in the code as written; they are not a test of a deployed system.
- **Unchecked, carried over from the writer:** the assumption that no persistent old-shape schema-5 database exists on the Mac or the Linux box. This commit does not change the schema.
- **Stop conditions met:** none. Provenance reproduced at opening and closing; the report was delivered.

## 12. Confidence

| | Level | Why |
| --- | --- | --- |
| Provenance | 0.99 | Both manifests reproduced twice at the start and twice at the end, byte-equal to the writer's; remote tip unchanged at the end. |
| Validation | 0.9 | Full suite at both commits, race detector on both changed packages, 47 mutants, 64 probes, all run by me on the exact bytes. Twelve tests cannot run here. Linux only. |
| Implementation | 0.9 for the production code of this commit; 0.75 for the guard as a whole | The production change is small and each of its points is pinned by a test, in both directions where a failure under a live context is reachable; one precedence rule is held by reading only (A3-2). The guard has been found incomplete three times now (RT-1, A2-1, A3-1), each time one step further out. |

## 13. Effect status

Repair, commit, push, pull-request change, comment and merge: **not performed**. The provenance clone is unchanged (closing manifests equal the opening ones). Scratch copies exist only in this thread's container.

## 14. Report delivery

`/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/08-audit.md`, with evidence in `08-audit-evidence/` beside it. The SHA-256 of this file is given in the thread reply that attaches it (a file cannot contain its own hash).

## 15. Final verdict

**BLOCK**

STATUS: READY
