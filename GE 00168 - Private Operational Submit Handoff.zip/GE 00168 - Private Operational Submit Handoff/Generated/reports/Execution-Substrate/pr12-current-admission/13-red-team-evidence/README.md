# Evidence for 13-red-team.md

Red-team of Execution-Substrate PR #12 with its fix PR #13, at bff8dda37dbf5484afb3b264d4eca38cf6abf118.
Everything here is scratch material from an isolated container. Nothing in it was committed anywhere.

- `tests/`: regression-test candidates (rename `.go.txt` to `.go`, place in `es/admission/`).
  - `..._redteam2_test.go.txt`: 11 behaviour tests, pass at bff8dda and under -race.
  - `..._redteam2_crash_test.go.txt`: SIGKILL-at-random-instants test.
  - `..._redteam2_guard_test.go.txt`: RT2-1 guard test; fails at bff8dda until the import inventory is extended.
- `characterization/`: report-only tests of documented limits (L1 to L3). Not for adoption.
- `probes/`: hostile production files used to test the guard (p4 egs swap, p5 second state file, p6 method expressions, the libc probe and its effect tests) and the fuzz-seed writer. Never commit.
- `scripts/`: container setup, clone sync, unprivileged runner, manifest reproduction, mutant runners, fuzz and evidence sequences.
- `results/`: logs and summaries named in the report (suite summaries, mutants, fuzz, SIGKILL runs, libc effect, guard test at tip and with the candidate fix, vet, darwin build, vendoring probe).
- `manifests/`: opening and closing provenance manifests (base-relative and trunk-relative), equal.
- `SHA256SUMS`: checksums of every file in this folder except itself.
