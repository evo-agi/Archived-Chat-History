# FOURTH REPAIR OF PR #13: the guard reads every compiled package, and the admission state moves into its own package

Status of this file: **IMPLEMENTATION REPORT, NOT AUDITED.** It is the replacement implementation report for draft PR #13 after the audit of `faacf16` (`10-audit.md`, verdict BLOCK). It describes the bytes of `bff8dda37dbf5484afb3b264d4eca38cf6abf118`. A fresh audit thread must judge it. The red-team pass on the combined PR #12 comes after an accepted audit.

Written by the PR #13 writer thread on 2026-11-23 (UTC). Readers: the coordinator, David, and the fresh audit thread.

The approved design (`04-design-proper-admission.md`) and the frozen plan (`05-repair.md`, sections 0 to 10) still describe what the pull request builds. This report covers what changed after `faacf16`. **Unlike the three repairs before it, this one changes production code,** because the coordinator decided on section 4.4 of the last report: do the type-level design now, in this pull request.

---

## 1. In plain words

The audit accepted the production code a fourth time and blocked on the guard a fourth time. The guard read only the packages that the pattern `./...` matches. The go command compiles a package from a `testdata`, a dot or an underscore directory as soon as another package imports it, and none of the guard's lists read such a package.

This repair has two parts.

**Part one closes the audit's findings in the guard** (commit `3f65592`, test code and documents only). The guard now reads what the go command compiles from this repository, whatever the directory is called. It refuses the three ways to make the go command compile from a place it does not read: a `replace` line (or any other new directive) in `go.mod`, a workspace file in the repository or above it, and a second `go.mod` below the root. Every file that imports `reflect`, `unsafe` or `C` is held by the SHA-256 of its bytes, so a change inside such a file is a reviewed change.

**Part two is the coordinator's decision, which David agreed to: the protected state moved into a small package of its own** (commit `1182b9f`). The installed view, the two latches and the confirmation time were five fields of `Service`, in a package of 40 production files, kept apart from the other 38 files by a source guard. They are now fields of one unexported struct in the new package `es/admission/internal/admissionstate`. That package is one production file of 388 lines. `Service` holds a handle whose only field is an unexported pointer.

David asked: "So it's a proper fix?" **Yes, for the class of escape that three of the four reviews found.** A value conversion (red team), a pointer conversion (second audit) and a generic used from another package (third audit) all needed the same three things: to name a protected field, to write a struct type of the same shape, or to copy or overwrite a whole value. Outside the 388-line package none of these compiles any more, in any Go version, without anyone re-deriving why. A test compiles each form against the real packages and requires the compiler's refusal.

**It is not the whole protection, and the report says where the border is.**

- Reflection and `unsafe` do not respect package borders. The red-team test still rewrites an installed view through reflection, with no `unsafe` import. So the module-wide pin on the `reflect`, `unsafe` and `C` imports stays essential, as the coordinator asked. This is also why part one was needed under either design.
- The package has a few exported functions, and `es/admission` may call them. No call can clear a latch, move the confirmation time back or install a second view. A wrong call could still install, withdraw or confirm at a place no review put it. The guard holds every call site of every exported function by an exact list.
- `es/admission` can assign the whole handle. A handle saved earlier restores nothing, because it names the same state. A new handle is like a restarted process: it admits nothing until the store issues a token for its content, and it must ask EGS before its first use. The guard lists the one place that assigns the handle.

**Which parts of the guard the design makes redundant** (section 4.6). Outside the new package, the whole-value, same-shape and type-parameter rules can no longer be broken for the two state structs, because the compiler refuses first. Inside it, the field and lock inventories repeat what a hash of the one file already fixes. I kept both, as defence in depth and because they read every other owning type too. Everything else is still needed.

**No behaviour changed, and no public contract changed.** `NewService` has the same signature, every moved rule has the same checks, and the admission digest is byte-identical: five digests computed by the old function at `faacf16` are pinned as golden values in the new package. The package split forced no change to a public contract, so the stop condition of the brief did not apply.

**Three things the auditor should know first** (section 7 has the full list):

1. **The first commit of this repair was pushed with one failing test.** At `3f65592` the test `TestExecutionSubstrateProductionHasNoA3LeaseRegistryOrPoisonDesign` fails: the loader now returns the packages that ES imports, and that test counted their locks as ES locks. I had run the guard tests and the admission tests before that push, and not the test in question. The second commit fixes it and pins the fix. No commit on the branch between `faacf16` and `1182b9f` should be taken as a green state.
2. **The frozen path scope is wider by two files:** `state.go` and `state_test.go` of the new package. The pull request is 28 paths against its base (26 before), and 48 against the trunk merge base (46 before). The owner document states the new ceiling.
3. **The audit's R3 is not implemented as written.** It asked for a seventh gate row that records the open decision. The decision is no longer open, so there is no row. `PLANS.md` says so.

**The evidence in short.** Everything was measured on the bytes of `bff8dda`, after the push. The full suite has 6,786 results: the 166 failures known from `faacf16`, and two results of one test with a known timing fault in a file this pull request does not touch, which passes 20 of 20 runs alone. The race detector reports nothing on the two packages whose production code changed. Of 232 behaviour mutants, 172 are killed by a behaviour test, 4 no longer compile, 52 are caught by guard tests only and 4 survive, one of them new (`I1`, a check that is now made twice). Of the 161 guard mutants that still have their lines, 158 are caught. Of twelve probes, the audit's six that passed at `faacf16` among them, eleven fail a guard test and one has no result in my environment. The store's 54 mutants did not run again, because no file of that package changed.

Nothing was merged. No branch other than `claude/project-thread-sqldt7` was pushed.

## 2. Identity

| Field | Value |
| --- | --- |
| Objective | Repair findings A4-1 to A4-3 of `10-audit.md` on draft PR #13 (section 9: R1 to R3), the optional O4-1 and O4-2, and carry out the coordinator's decision on section 4.4: move the protected admission state into its own package in this pull request |
| Repository | `evo-agi/Execution-Substrate` |
| Base ref and SHA | `codex/reliable-submit-operational-handoff-v1` at `8058561edc08356c46680c204586b3c7796c0ff3` (the PR #12 branch) |
| Audited tip this repair starts from | `faacf16b9d5cd5ddc28b79da5c6c30f2bca6c124` |
| Topic branch | `claude/project-thread-sqldt7` (draft PR #13) |
| Topic commit SHA | `bff8dda37dbf5484afb3b264d4eca38cf6abf118` |
| Tree SHA | `38269372c5bc21f291e1b73e93cf48d78180649d` |
| Commits after `faacf16` | `3f65592` Read every package the build compiles from the repository; pin unsafe files by content<br>`1182b9f` Move the admission state into its own package<br>`4c1414b` Hold the surface of the admission state package; close mutant gaps<br>`12fd6f0` Test the trust-model owner check for a copy with its own admission state<br>`fd74e97` Test the refusal of a view whose content builds no policy set; close two guard self-test gaps<br>`6826aae` Require an inventory for every holder of admission state; run the state inventories through the gate<br>`bff8dda` Test that the stricter seam cannot allow what the built-in policy set refuses |
| Final working-tree status | clean (`git status --porcelain` empty after the last commit and after the push) |
| Recipe | `governed_execution_audit_patch_manifest_v2.py`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified before every run |

## 3. Reconnaissance

- I read `10-audit.md` in full and its evidence folder as data. I did not execute the auditor's scripts or probes. Where I re-ran a probe of an audit, my runner read only string constants of the probe file with a syntax-tree parser and applied them to a scratch copy (section 10.4).
- Before moving anything I read every use of the five protected `Service` fields and of the snapshot struct at `faacf16`. They were used in two production files (`reliable_submit_operational_admission.go` and `reliable_submit_operational_handoff.go`) and in `service.go` (the declaration and `Initialize`). That is the whole set of places the split had to change.
- Facts that shaped the design:
  - Go's `internal` rule already limits who can import a package below `es/admission/internal/`: `es/admission` and the packages below it. Today that is `es/admission` alone.
  - A struct with an unexported field cannot be converted to a same-shape struct of another package, because the field name of another package is a different name. This is the language rule that the three escapes ran into; I confirmed each form with the compiler rather than from memory (section 4.4).
  - Reflection can make an unexported field of another package settable without importing `unsafe`: `reflect.NewAt(field.Type(), field.Addr().UnsafePointer())`. I confirmed this by keeping the red-team test's forged view working through exactly that road.
  - The store's token type has a method `Names(installation, epoch, digest)`. It lets the new package check, without any I/O, that a view is installed only with a token the store issued for exactly that realm and content.
  - The built-in admission policies are types of `es/admission`. The new package cannot import them (that would be an import cycle), so the content of a view crosses the border as plain data and is mapped back for every evaluation (section 4.2).
- For the guard repair I measured the tree before writing any list: no `go.work` file, no `go.mod` below the root, no `replace` line; the only directive kinds in `go.mod` are `go`, `module` and `require`; two production files import `unsafe`, none imports `reflect` or `C`; no production Go file lies in a `testdata`, dot or underscore directory.

## 4. The admission state package

### 4.1 Before and after

**At `faacf16`** the state was five fields of `Service` under `Service.mu`: `operationalAdmission` (a pointer to an `operationalAdmissionSnapshot`), `operationalWithdrawn`, `operationalSuperseded`, `operationalConfirmed`, plus the test seam `operationalProof`. The snapshot struct lived in `es/admission` too. Any of the 40 production files of the package could name these fields. The guard listed every access.

**Now** the package `execution-substrate/es/admission/internal/admissionstate` owns them. It is one production file, `state.go`, 388 lines. It imports `crypto/sha256`, `encoding/binary`, `slices`, `sync`, `time`, the EGS trust model type and the store package for its token type. It has no `reflect`, no `unsafe`, no cgo and no I/O.

```
type State struct{ s *state }     // the handle a Service holds
type View  struct{ v *view }      // the handle of one installed view

type state struct {               // unexported, never leaves the package
    mu         sync.RWMutex
    owner      any                // the *Service the state was made for
    view       *view
    withdrawn  bool               // latch
    superseded bool               // latch
    confirmed  time.Time          // only moves forward
}
type view struct {                // unexported, immutable after Install
    installation [32]byte
    epoch        uint64
    token        reliablesubmit.OperationalAdmissionToken
    content      Content          // trust lists, verifier, policies as plain data
    proof        any              // test seam, nil in production
    skew         func() time.Duration   // test seam, nil in production
}
```

`Service` keeps one field, `operational admissionstate.State`, which `NewService` sets once. The seam field `operationalProof` stays on `Service`, as before.

### 4.2 What the package exports

| Member | What it does | Production callers (exact list in the guard) |
| --- | --- | --- |
| `New(owner)` | Makes the state of one owner. A nil owner gets the zero handle. | `NewService`, once |
| `State.Commissioned()` | Was a view installed or the state withdrawn. The one question that asks no owner. | `Service.Initialize`, twice |
| `State.Installable(owner)` | No view yet and neither latch set. | `Service.installOperationalAdmission`, once |
| `State.Install(owner, installation, epoch, token, content, proof, skew)` | Installs the one view. Refuses unless the token names exactly this installation, this epoch and the digest of this content. Copies the content. | `Service.installOperationalAdmission`, once |
| `State.Withdraw(owner, installation, epoch)` | Sets the withdrawal latch and returns the token to withdraw in the store. | `Service.withdrawOperationalEffects`, once |
| `State.Confirmable(owner)` | The installed view while a confirmation can still change something. | `Service.confirmOperationalAdmission`, once |
| `State.Confirm(owner, view, trust, started)` | Compares served trust with the view through the digest. Equal: records `started` unless a later time is recorded. Different: latches supersession. | `Service.confirmOperationalAdmission`, once |
| `State.Current(owner, installation, epoch)` | The view only while it may be used: this realm, no latch, last confirmation inside the limit. | `Service.currentOperationalAdmission`, once |
| `State.Inspect(owner)` | A copy of the status, for tests. | none |
| `View.Installed()` | Does the handle name a view. For tests. | none |
| `View.Token()` | The token of the view. | `Service.operatePrivateHandoff` once, `Service.advanceOperational` twice |
| `View.Trust()`, `View.Verifier()`, `View.Policies()` | Copies of the content. | `Service.qualifyOperationalRetained`, once each |
| `View.Proof()` | The seam value given to `Install`, unread. | `operationalProofOf`, once |
| `Digest(content)` | The admission digest. | `Service.operationalAdmissionContent` once; inside the package at install and at confirmation |
| `ConfirmationLimit` | 30 seconds. | constant |
| `Content`, `Verifier`, `Policy`, `PolicyEntry`, `Status` | Plain data types. | |

Every method of the state except `Commissioned` takes the owner and answers only the `Service` the state was made for, compared by identity. A copy of a `Service`, another `Service` holding the same handle and the zero handle are answered "no" by every method.

**Why the content is plain data.** The built-in policy types belong to `es/admission`, which imports the new package, so the new package cannot name them. `es/admission` maps its selected policy set to `[]Policy` (the identifier of each policy and every configured entry, in order) and builds the set back from the view for every evaluation. Two consequences are improvements rather than costs: the digest is computed over exactly the bytes the view holds, and what is evaluated is rebuilt from what the digest names. A policy the mapping does not know is refused in both directions.

### 4.3 Locks

The state has its own read-write lock. `Service.mu` no longer covers the latches and the confirmation time.

- Installing a view takes `Service.mu` and then the state lock. This is the only place both are held, and the order is fixed. `Service.mu` is held so that a trust load cannot run between the comparison of the trust model and the install, as before.
- Withdraw, confirm and the question for the current view take only the state lock. They took `Service.mu` before.
- `Initialize` asks `Commissioned()` twice, the second time under `Service.mu`, as before. The answer cannot change between that question and the write that follows: a view is installed only under `Service.mu`, and withdrawal changes the answer only for a state that already has a view.
- While the package holds its lock it calls no function a caller supplied. The clock and the test seam `skew` are read after the lock is released, as the old code did.
- No lock of either kind spans a store call or a network call. That is unchanged.

### 4.4 What no longer compiles outside the package

A new subtest, "what does not compile outside the admission state package", adds each form below in memory to a real file of `es/admission` and type-checks it against the real packages, for all three build targets. The type checker must refuse it. Seven controls beside them must compile (a method call, a handle copied, the zero handle, two handles compared, a struct holding a handle, content made by a caller, and nothing added).

- A field of the state or of a view through either handle: the pointer itself, a latch, the confirmation time, the content of a view (5 forms).
- The name of either struct type: in a variable, in a literal, in a type-parameter constraint (4 forms).
- A handle literal that sets its pointer, keyed or positional, for both handles (4 forms).
- A struct type of the handle's shape written in `es/admission`, converted from a pointer to the handle; a defined type of the handle; an embedded handle (5 forms). These are the forms of the red team, the second audit and the third audit, applied to the handle.
- A copy of the state's value, and an overwrite through a generic function (2 forms).
- The package's unexported functions: the owner check, the deadline arithmetic, the copy of the trust lists (3 forms).

A form counts as refused only if every error lies in the added lines and one of them carries the expected message. So a probe that fails to compile for an unrelated reason does not pass as a refusal. That rule is a function with its own self-test of two accepted and eight rejected cases.

### 4.5 What stays possible, and what holds it

**Reflection.** `reflect` can reach an unexported field of another package and make it settable without `unsafe`. The red-team helper `redTeamRewrittenViewService` does exactly this to keep attacking with a view whose realm fields were rewritten in memory, and the attack still needs it: the package's own `Install` refuses such a view. So the border does not hold against a production file that imports `reflect` or `unsafe`. The import inventory holds that: none of the 120 production Go files of the repository imports `reflect` or `C`, two import `unsafe` (`es/admission/execution_roots_darwin.go` and `es/runtimehelper/privilege_linux.go`), and each of those two is pinned by the hash of its bytes (section 5.2).

**A call of an exported function.** What a call can do is limited by the package: no method clears a latch, moves the confirmation time back, replaces a view or changes a view's content. What a wrong call could still do: install a view at a new place (it would still need a store token for exactly that content and realm), withdraw, or record a confirmation that asked nobody, for example `Confirm(s, view, view.Trust(), time.Now())`. That last one would keep a view alive without EGS. The guard holds it with an exact call-site list for every exported function and method (section 4.2, right column), a closed list of everything the package exports, and a cross-check that every exported function and method has exactly one such list.

**An assignment of the whole handle** `Service.operational`. Only `es/admission` can write the field. A handle saved earlier and put back names the same state, so it restores nothing: latches and confirmation time are as they are now. A new handle from `New`, or the zero handle, is a state without a view. It has forgotten the local latches, as a restarted process has. It admits nothing until a view is installed with a token the store issued for its content, and the first use must confirm with EGS. A token kept from before could be used to install on a new handle; that needs a call of `New` and a call of `Install`, and both have exact call-site lists. The reference inventory lists the one assignment of the field, in `NewService`.

**A handle kept somewhere else.** A view handle that is stored outlives the check `Current` made when it handed the view out. So the guard does not leave it to the lists which fields are watched. It reads from the types which fields must have an inventory: every field of the two structs `state` and `view`, and every field of a struct in any other package whose type holds one of the two handle types, directly or behind a pointer, a container, a function type, a struct without a name, a named type, an alias, a type argument or the package's own `Status`. Today that is `Service.operational` and `handoffOwner.admission`, the view a handoff holds while it runs. A new field of that kind fails until it has an inventory, and a package variable that holds a handle is refused. The rule came late in this repair: two guard mutants that removed list entries survived until it existed (section 7, item 15). Its limit is a field of an interface type, which can hold anything; that is the alias limit of section 14.

### 4.6 Which guard rules the design makes redundant

The coordinator asked me to say which parts become provably redundant. For the two structs `state` and `view`:

| Guard rule | Outside the package | Inside the package |
| --- | --- | --- |
| Whole-value rules (copy, overwrite, restore, conversion) | **Redundant.** No expression outside has the type, so the compiler refuses first (section 4.4). | Needed in principle. Covered together with the next row. |
| Same-shape struct ("mirror") rule | **Redundant.** A mirror written elsewhere has a field named by another package and never converts. | Same. |
| Type-parameter rules | **Redundant.** A constraint cannot name the type. | Same. |
| Field and lock inventories | Nothing to list: no outside access compiles. | **Repeat the hash.** The one file is pinned by its SHA-256, so every access in it is already a reviewed fact. |

I kept all of them. They are the same code that reads every other owning type (`Service`, the handoff owner, the store's types), so removing them for two types would mean adding exceptions to the guard, not removing code. And inside the package they turn "the hash changed" into "this access changed", which is what a reviewer wants to see.

**Not redundant, and why:**

- the import inventory for `reflect`, `unsafe` and `C`, module-wide (section 4.5);
- the file-set and tree checks and the loader that reads every compiled package (part one of this repair);
- the call-site lists, the closed export list, the inventory of the handle field and the rule that every field that holds a handle has an inventory (section 4.5);
- the hash pin of `state.go`, with the rule that the package has exactly one production file and no directory below it;
- every rule for the other owning types.

### 4.7 Why behaviour is unchanged

I moved the checks one by one and compared each with the old code at `faacf16`.

- **Install.** Old: under `Service.mu`, refuse when a view exists or a latch is set or the trust model changed since it was sampled, then store the snapshot. New: under `Service.mu`, refuse when the trust model changed, then `Install`, which refuses when a view exists or a latch is set, and additionally refuses a token that does not name the realm and the digest of the content. The caller checked `token.Names` before the move and still does, so the new check inside the package refuses nothing the old code accepted.
- **Withdraw, confirm, current.** The same comparisons in the same order. The deadline arithmetic (`fresh`) is the old function `operationalConfirmationFresh` line for line; it takes the seam function instead of the hooks struct.
- **The digest.** `Digest` frames the same fields in the same order. `TestDigestGoldenVectors` holds five cases with the digests the old function produced at `faacf16` (I computed them with a temporary test on that commit before the move), and a test in `es/admission` computes two of them through the new mapping from a policy set.
- **Qualification of a retained original.** The same steps. The policy set is now rebuilt from the view's content. If that fails the answer is `OperationalUnavailable`. That branch is new, and it fails closed. No `Service` can reach it: the one call of `Install` passes the content that `operationalAdmissionContent` maps from the selected set, and the round trip of that mapping is tested. The package itself takes any content that has a digest and a store token naming it, and it does not know the policy identifiers. So the branch is tested with views installed by hand, with a control (section 7, item 14).

Two differences that are not behaviour:

- **More copying.** `View.Trust()`, `View.Verifier()` and `View.Policies()` return deep copies, and the qualification callback calls each once per evaluation. Before, it read the snapshot's fields in place. The content is bounded (the trust model by 256 KiB at commissioning), and there is no production caller yet. I did not measure it.
- **A stricter test seam.** The proof hooks gained `stricter`, a policy evaluated after the view's built-in set. Two tests used to overwrite the policy set of the snapshot in place, to simulate a refusal and an input class the set cannot evaluate. They cannot reach the view any more. The seam appends to the built-in set, which stops at the first refusal, so it can refuse more and cannot allow what the built-in set refuses. A test holds both halves (section 7, item 9). It is nil in production: the guard lists no production write of any hook field, and exactly the two reads of `stricter` in `Service.qualifyOperationalRetained`.

`Inspect` and `View.Installed` exist for tests. The guard lists zero production references to each.

### 4.8 The public contract

Unchanged. `NewService(cfg)` has the same signature and returns the same type. `Service` gained and lost only unexported fields. The new package is below `internal/`. No exported identifier of `es/admission` changed, and no document of a public surface changed. The brief's stop condition did not apply.

## 5. What was done, finding by finding

### 5.1 R1, finding A4-1 (medium, blocking): packages the guard did not read

Commit `3f65592`. All five items of the audit's R1.

1. **The loader.** `selectCompiledRepositoryPackages` keeps every package of the dependency closure (`go list -deps`) that is not in the standard library and whose directory lies inside the repository, whatever `DepOnly` says and whatever its import path is. It fails the test when a closure package is compiled from a directory that is neither in the Go root, nor in the module cache, nor in the repository. A package below the module cache directory counts as a dependency even when that directory lies inside the repository; the content of the module cache and of the toolchain is a named limit of the guard, as before.
2. **The walk.** `repositoryProductionListings` reads every directory of the repository except `.git`. The exclusions of `testdata`, dot and underscore directories are gone.
3. **Ways to compile from elsewhere.** Three exact tests: the directive kinds of `go.mod` are exactly `go`, `module` and `require` (so a `replace` line, an `exclude`, a `toolchain` line or a `godebug` line fails until listed); no `go.work` or `go.work.sum` in the repository, and `go env GOWORK` reports none above it; no `go.mod` below the root.
4. **Self-tests.** Synthetic cases for each rule, and probe modules written to disk and loaded with the real go command: a package in a `testdata`, an underscore and a dot directory, with and without `reflect` and `unsafe`; a nested module behind a `replace` line; a package directory that is a symbolic link; a workspace file above the repository. The self-test that pinned the gap is replaced.
5. **Text.** The comment in the guard and the three sentences of the owner document and of `PLANS.md` that the audit named now describe what the guard does.

**A consequence I missed in that commit.** The loader now returns the in-repository packages that ES imports (for example `ars/index`). `TestExecutionSubstrateProductionHasNoA3LeaseRegistryOrPoisonDesign` treats every package of the view as ES production code and so found a lock of `ars/index` in the ES synchronization inventory. The test fails at `3f65592`. Commit `1182b9f` gives that test a directory scope (`es` and `cmd/es`), with the new helper `packagesCompiledBelow` and its self-test `TestPackagesCompiledBelowReadsADirectoryScope`. The admission guards keep reading the whole closure. A scope that reads too little passes silently, so the test also fails unless `cmd/es` and `es/admission` are among the packages it read (`requirePackagesRead`, added in `fd74e97` after a mutant that dropped `cmd/es` from the scope survived).

### 5.2 R2, finding A4-2 (low): what a file with `unsafe` does

Commit `3f65592`. The import inventory holds every file that imports `reflect`, `unsafe` or `C` by the SHA-256 of its bytes (`operationalGuardImportPins`). A change of one byte in either of the two listed files fails `TestOperationalGuardReflectUnsafeImportInventoryIsExact` until the pin is updated, and so does a `go:linkname` line added there. The owner document's limit sentence says the listed files are held this way.

### 5.3 R3, finding A4-3 (low): the open design decision

**Not implemented as written, because the decision is made.** The audit asked for a seventh commissioning prerequisite, `CP-STATE-BOUNDARY`, that records the question whether the state moves behind a package border. The coordinator decided to move it now (relay of 21:45 UTC), and David agreed (his message relayed at 22:02 UTC). So there is no open question to gate. The commissioning gate keeps six rows. `PLANS.md` records, in the entry for the admission state package, that the seventh row was not added and why.

### 5.4 O4-1 (optional): a deadline during the observation of the job

Commit `3f65592`. I took both options. The owner document's cancellation paragraph and the outcome row now say that a deadline passing while the provider is asked about the job answers `OperationalTimeout` with the stored run, and that a cancellation there answers `OperationalCanceled` with the stored run. Both are tested (subtest "during the observation of the job" of `TestOperationalAdmissionCancelledCallAnswersCanceled`), and two mutants are in the behaviour set and killed: one reports the deadline as a cancellation, one answers it with `OperationalIO` (section 10.1, which also names a third mutant of mine that turned out to be equivalent).

### 5.5 O4-2 (optional): the stray comment

Commit `3f65592`. The comment is back on its test. In `1182b9f` that test moved to the new package as `TestDigestFramesItsConstantParts`, with its comment.

### 5.6 O4-3 and O4-4

O4-3 (166 environment failures in a copy without `.git`, 42 in a git clone) needs no change; section 11 states the environment set of this run. O4-4 (a source guard makes a bypass visible, it does not stop a change that edits the inventory with the code) is true of every rule in section 4.5 and 4.6 too, and is the reason the required check on the target branch matters. The package border is the one control in this pull request that it does not apply to.

## 6. Files touched

Sixteen paths against the audited tip `faacf16` (`git diff --numstat faacf16 bff8dda`). Two are new.

| File | Added | Removed | What changed |
| --- | --- | --- | --- |
| `.docs/execution_lifecycle/es_execution_admission_model.md` | 20 | 14 | Where the view and the latches live, the lock table (the lock of the state, the pointer of the handle), the count of synchronization fields |
| `.docs/execution_lifecycle/reliable_submit_operational_handoff.md` | 186 | 29 | The owner document: the section on the admission state package, what the guard reads, its limits, the path allowance, the outcome of a deadline during the observation (O4-1), the rule for holders of a handle |
| `.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md` | 7 | 4 | Three lock-order sentences name the lock of the admission state |
| `PLANS.md` | 84 | 0 | Two entries: the guard repair, and the admission state package with the reason for no seventh gate row |
| `docs_contract_test.go` | 119 | 13 | Pins and mutation cases for every new statement of the documents |
| `es/admission/internal/admissionstate/state.go` | 388 | 0 | **New, production.** The admission state package |
| `es/admission/internal/admissionstate/state_test.go` | 835 | 0 | **New.** Its tests |
| `es/admission/reliable_submit_guardrails_test.go` | 339 | 6 | Call-site lists, the closed surface, the construction inventory, probes on the real packages |
| `es/admission/reliable_submit_operational_admission.go` | 148 | 157 | **Production.** The state code moved out; the mapping between the policy set and plain content moved in |
| `es/admission/reliable_submit_operational_admission_redteam_test.go` | 47 | 18 | The forged view is made through reflection |
| `es/admission/reliable_submit_operational_admission_test.go` | 911 | 205 | Tests read the state through accessors; the new tests of section 8.1 |
| `es/admission/reliable_submit_operational_format_test.go` | 4 | 4 | Two reads go through accessors |
| `es/admission/reliable_submit_operational_handoff.go` | 5 | 4 | **Production.** The type of a view, and `Token()` in place of a field read |
| `es/admission/reliable_submit_operational_handoff_test.go` | 5 | 0 | Two fixtures that build a `Service` by hand give it a state |
| `es/admission/service.go` | 20 | 18 | **Production.** The fields, `NewService`, `Initialize` |
| `es/admission/workstream_c_guardrails_test.go` | 1,361 | 130 | The loader that reads every compiled package, the tree and `go.mod` checks, the import pins, the pin of the state package, the forms that must not compile, the directory scope, the rule for holders |

Total: 4,479 lines added, 602 removed, in 16 files.

**Production files: four.** `state.go` is new. `service.go` (the fields, `NewService`, `Initialize`), `reliable_submit_operational_admission.go` (the state code moved out; the mapping to and from plain content moved in) and `reliable_submit_operational_handoff.go` (nine lines: the type of a view, and `Token()` instead of a field read). The store package `es/admission/internal/reliablesubmit` is untouched: `git diff faacf16 bff8dda -- es/admission/internal/reliablesubmit` is empty.

**Scope.** Against the PR base `8058561` the pull request now has 28 paths (26 before). Against the trunk merge base `ae326b0` the combined PR #12 has 48 (46 before). The two new paths are `es/admission/internal/admissionstate/state.go` and `state_test.go`. The owner document's path allowance names both and states the new ceiling of 48, and the docs contract test pins that sentence.

## 7. Deviations, and what the auditor should know

1. **The first commit was pushed with a failing test** (section 5.1, last paragraph). `3f65592` fails `TestExecutionSubstrateProductionHasNoA3LeaseRegistryOrPoisonDesign`. I had run the guard tests of the brief and the admission tests on its bytes, and no full suite. I found it when I ran all of `es/admission` before the second commit. Fixed and pinned in `1182b9f`.
2. **The frozen path scope is wider by two files** (section 6).
3. **R3 is replaced, not implemented** (section 5.3).
4. **This repair changes production code.** The three before it did not. The audit's sentence "no production code needs to change" was true for its repair scope; the coordinator's decision added the split.
5. **Seven commits, each pushed as a checkpoint.** The session's environment requires uncommitted work to be committed and pushed when a turn ends, and a cloud container can be reclaimed. `3f65592` is part one. `1182b9f` is the split with its documents. `4c1414b` adds guard rules for the new package and the tests that mutants asked for (item 9). `12fd6f0`, `fd74e97`, `6826aae` and `bff8dda` each add tests that later mutants asked for (items 9, 14 and 15); `6826aae` also adds one sentence to the owner document. None of the five commits after `1182b9f` changes a production file. The final validation of section 9 and every mutant result of section 10 ran on the last commit.
6. **The red-team test keeps its forged view, through reflection.** `redTeamRewrittenViewService` used to write the snapshot's fields directly. It now makes them settable with `reflect.NewAt`. I kept the attack instead of deleting it, because it is the proof that the package border does not hold against reflection, and because the tests behind it still pin what the store and the qualifier do with a view that names another realm. Every test name of the red team's file is kept.
7. **A new test seam, `stricter`, and two members that exist for tests** (`Inspect`, `View.Installed`) (section 4.7). The guard pins that production does not use them.
8. **Tests moved with the code.** `TestOperationalAdmissionConfirmationDeadlineArithmetic` and `TestOperationalAdmissionDigestFramesItsConstantParts` are gone from `es/admission`; their successors are `TestConfirmationDeadlineArithmetic` and `TestDigestFramesItsConstantParts` in the new package. Every case is kept under its name except one: "hooks without a skew" gave the old function a hooks struct without a skew function, and the new package takes the function itself. The wrapper that turns hooks without a skew into zero is in `Service.installOperationalAdmission`, where every fixture with hooks and no skew runs through it. Section 9 compares the suites by name.
9. **Tests were added because mutants survived.** The first behaviour run on the split left these without a behaviour test that catches them, and I added a test for each before the final run:
   - `NewService` gives the state another owner, or no state: nothing tested the one assignment in `NewService`, because every fixture builds its `Service` by hand. New: `TestOperationalAdmissionNewServiceOwnsItsState`.
   - The owner check accepts a nil owner: new subtest "a state without an owner serves nobody".
   - `Install` ignores the latches: new subtest "a latched state without a view takes none". No method produces that state, so the test sets a latch through reflection and has a control.
   - The copy of the verifier key and the copy of the configured entries before the install: both were killed at `faacf16` by tests of the snapshot. The state now copies again at install, which hid the loss of either earlier copy. New subtest "each step before the install hands on a copy".
   - The check that a Service loaded and verified its own trust model: at `faacf16` a copied Service was refused by that check alone. The state now refuses a copy first, because the copy does not own the state, which hid the loss of the older check. New case in `TestOperationalAdmissionCommissioning`: a copy that was given a state of its own (`12fd6f0`).
   - The fail-closed branch of item 14 (`fd74e97`).
   - The test seam `stricter` put in place of the built-in policy set instead of behind it. Section 4.7 says the seam can refuse more and cannot allow what the set refuses, and no test held the second half. I overlooked this survivor of the first run until I built the lists for the final run. New subtest "the stricter seam cannot allow what the built-in set refuses", with three controls (`bff8dda`).
   - Six guard mutants survived their first run, and each got a self-test: a comment line in `go.mod` read as a directive (a case in the directive self-test, before `4c1414b`); `cmd/es` dropped from the scope of the ES inventory (`requirePackagesRead`, `fd74e97`); an error without a file name judged a refusal (a case in the refusal self-test, `fd74e97`); and three in `6826aae`, which item 15 describes.
10. **Some guard rules are now redundant for two types and stay** (section 4.6).
11. **The guard test of the gate is slower.** `TestOperationalHandoffNoPublicStartupOrdinaryOrFixtureCaller` adds one probe per exported member of the new package to the real packages and type-checks each. In the full suite it took 103 seconds, where it took 28 at `faacf16`; both runs were alone on the same machine.
12. **The store's mutants were not run again** (section 10.5 says why).
13. **Two unformatted files that this pull request does not touch.** `gofmt -l es/` lists `es/runtimehelper/main.go` and `es/runtimehelper/privilege_linux.go`. Both are byte-identical to the base and are not among the 28 paths. I did not format them: `privilege_linux.go` is one of the two files now pinned by content, and neither is in scope.
14. **A new fail-closed branch, and a wrong sentence of mine about it.** In `Service.qualifyOperationalRetained`, a view whose content builds no policy set answers `OperationalUnavailable` (section 4.7). My first draft of this report said the branch cannot be reached, and the first mutant run left its two mutants alive. One of them evaluated an empty policy set in place of the refusal, which admits. The sentence was wrong about the package: `Digest` takes any policy identifier, so `Install` would take such content with a store token that names it. What is true is that no `Service` installs it. The new subtest "a view whose content builds no set answers Unavailable" installs three such views by hand, with real store tokens and a control, and both mutants are killed now.
15. **A guard rule added in `6826aae`: every holder of admission state has an inventory.** Three guard mutants of mine survived the run with every guard test, and none was a mutant of a checking function. Each removed a piece of what the guard reads on the real tree:
   - The inventories of the state package were taken out of the commissioning gate's validation. Nothing failed, because the probes called those inventories directly. Now one added call and one control go through the whole validation as well.
   - The access inventory of the handle `Service.operational` was deleted, and the inventories of the fields inside the state package were skipped. Nothing failed, because every self-test of that guard walks the same lists: an entry that is gone takes its self-test with it. The same was true at `faacf16` for the five protected fields, and no audit or mutant had asked the question.
   
   A second list of required names would only move the problem. So the new rule reads the requirement from the types (section 4.5, last paragraph): `admissionStateHolders` lists the fields of the two state structs and every field elsewhere whose type holds a handle, and each must have an inventory. Its self-test adds sixteen kinds of holder, two package variables, a new field in each state struct and five controls to the real packages in memory. The owner document states the rule in one sentence, and the docs contract test pins it. All three mutants are caught now, and the rule has 21 mutants of its own (section 10.3).
16. **One test of the full suite failed that passed at `faacf16`** (sections 9 and 11): `TestRemoteAlphaESServiceTLSStatusCombinedGroupSignalFailureLiveDescendant`, subtest `term`. It is the timing fault of a fixture in a file this pull request does not touch, repaired on `trunk_dev` by PR #21, which this branch does not hold. Alone it passes 20 of 20 runs. I did not run the full suite again to get a run without it.
17. **My own runners needed three corrections during the final pass,** and none changed a committed byte.
   - The test selection of the behaviour mutant runner leaves out five guard tests, so a second run could not tell a survivor from a mutant that one of those five catches. A third stage with every test of the package decides it now (section 10.1). Two of the six mutants it ran are caught there.
   - One mutant stream was stopped by the two-hour limit of a background job after 50 of its 62 mutants. I ran the other 12 in a continuation and did not start the stream again (section 10.1).
   - The probe runner had a wrong label for H1D, and its N3 never reached the guard because the audit ran with `GOFLAGS=-mod=readonly`. I corrected the label, added N3R and ran every probe again (section 10.4).

## 8. Tests

### 8.1 Added

**The new package, `es/admission/internal/admissionstate/state_test.go`** (an internal test file, 11 top-level tests):

- `TestDigestGoldenVectors`, `TestDigestCoversEveryField`, `TestDigestFramesItsConstantParts`: the digest is the one of `faacf16`, every field of the content changes it, and its constant parts are framed.
- `TestConfirmationDeadlineArithmetic`: the moved table of the deadline, with both clocks and the seam.
- `TestHandlesExposeNothing`, `TestContentFieldSetIsCovered`: each handle is one unexported pointer; a new field of the content fails until the digest and the copies cover it.
- `TestContentIsCopied`: deep copies in and out, absent and empty lists kept apart.
- `TestNoViewAnswersNothing`, `TestZeroAndForeignHandlesAreClosed`: the zero handles, another owner, a copy of the owner, no owner, a state without an owner.
- `TestStateLatchesAndRealm`: one view, the realm, both latches, the confirmation time that only moves forward, the seam read outside the lock, a state that lost its view.
- `TestStateConcurrentUse`: readers and writers under the race detector.

**`es/admission`:**

- `TestOperationalAdmissionState`: `Install` and `Confirm` with real store tokens, which the new package cannot make for itself. Subtests: "a view that its token names is installed once", "what the token does not name is refused" (nine cases and "another owner and no owner"), "a latched state without a view takes none", "the installed content is the state's own copy", "confirmation, deadline and latches", "a handle put back restores nothing".
- `TestOperationalAdmissionPolicyContent`: the mapping between the policy set and plain content, in both directions. Subtests: "the mapping covers every field of the built-in policies", "round trip", "the digest through the mapping is the digest before the move", "a set that cannot be named has no content", "content that no set produces builds no set", "each step before the install hands on a copy", "a view whose content builds no set answers Unavailable" (three views installed by hand with real store tokens, and a control), "the stricter seam cannot allow what the built-in set refuses".
- `TestOperationalAdmissionNewServiceOwnsItsState`.
- In `TestOperationalAdmissionCommissioning`: the case "copied Service with content and an admission state of its own".
- In `TestOperationalAdmissionCancelledCallAnswersCanceled`: "during the observation of the job", with "cancelled" and "deadline passed" (O4-1).

**The guard:**

- `TestOperationalAdmissionStatePackageIsOneReviewedFile`: the hash pin, with twelve changes that must fail (a byte added, changed or removed, a second file, a platform file, an assembly file, a directory below, the file renamed or gone) and four controls.
- `TestOperationalAdmissionStateSurfaceIsAClosedList`: twelve additions that must change the surface, four unexported additions that must not, six ways the call-site lists can fail to cover it.
- `TestPackagesCompiledBelowReadsADirectoryScope`, which also tests `requirePackagesRead`: the scope must have read the packages it names.
- In `TestExecutionSubstrateSynchronizedMutableStateReferenceInventoryIsExact`: "what does not compile outside the admission state package" and "how a form that must not compile is judged" (section 4.4), and "what holds admission state has an inventory" (section 7, item 15).
- In `TestOperationalHandoffNoPublicStartupOrdinaryOrFixtureCaller`: "calls of the admission state package added in the real packages". For each exported function and method a call is added to `es/admission` and must fail its inventory; the test also requires that every member was probed. Inside the package, a second literal of the state or of a view, a view made with `new` and a declared view must each fail the construction inventory. One added call must also fail the whole validation of the gate, and one control must pass it.
- In the two module-wide tests of part one: the subtests of section 5.1, item 4.

**`docs_contract_test.go`:** pins for every new statement of the owner document, `PLANS.md`, the admission model and the persistence document; a count over the diff finds 30 added cases that delete a pinned statement (one of them replaces `MissingSnapshotConstructionOwner`) and 29 added cases that state the opposite of a pinned sentence, two of which are earlier cases anchored to the new text (examples: "the package may import reflect", "a saved handle restores the latches it held", "a replace line is allowed").

### 8.2 Changed

- **Tests of `es/admission` that read the state** now go through `Inspect` and the view's accessors instead of the fields. Tests that built a `Service` by hand give it a state with `admissionstate.New`. No assertion was weakened; where a test compared a field, it compares the same value from the accessor.
- **Two tests that overwrote the policy of the snapshot** use the `stricter` seam (section 4.7).
- **The red-team helper** (section 7, item 6).
- **The reference inventories of the guard:** the synchronization inventory has 55 fields (eight locks, four atomics, 43 references). Three entries left with the old fields and two came: the lock of the state and the pointer of the handle.
- **`docs_contract_test.go`:** the counts above, the construction sentence, the lock sentences and the path allowance are pinned in their new wording, and the replaced sentences are refused.

### 8.3 Removed with a successor

The two tests named in section 7, item 8, with the one case that has no successor of its name, and the renamed subtests in the table of section 9. No test was skipped or disabled.

## 9. Validation

Everything below ran on Linux (amd64, Go 1.26.5, the toolchain `go.mod` pins) in the writer's cloud container, as an unprivileged user, on copies of the committed tree without `.git`. The machine has four processors.

| What | Exact command | Bytes | Result |
| --- | --- | --- | --- |
| Format | `gofmt -l` on the twelve changed Go files (ten paths and the directory of the new package) | copy of commit `bff8dda` (tree `38269372c5bc21f291e1b73e93cf48d78180649d`) | no output |
| Whitespace | `git diff --check faacf16 bff8dda` | the commits | no output, exit 0 |
| Build | `go build ./...` | same copy | exit 0 |
| Vet | `go vet ./es/admission/ ./es/admission/internal/admissionstate/ ./es/admission/internal/reliablesubmit/ .` | same copy | one report, `es/admission/result_auth_test.go:395:15` (copied lock): the same line at every audited tip, in a file this pull request does not change. Nothing in the new package. |
| Full suite | `go test -count=1 -timeout 90m -json ./...`, alone on the machine | same copy | 6,786 results: 6,577 pass, 168 fail, 41 skip. Packages: 20 pass, 2 fail, 20 without tests. `go test` exit 1, as at `faacf16`. The failures are the 166 known ones and two results of one test with a known timing fault (below). 269 s. |
| Race detector | `go test -race -count=1 -timeout 120m -json ./es/admission/ ./es/admission/internal/admissionstate/`, alone on the machine | a second copy of the same tree | `es/admission`: 2,207 pass, 0 fail, 1 skip, 1589 s. The new package: 70 pass, 0 fail, 1 s. No data race reported. Exit 0. |

All of it ran after the last commit and after the push. The script recorded the commit and `git status --porcelain` before the first run and after the last one: the commit is `bff8dda37dbf5484afb3b264d4eca38cf6abf118` both times and the status is empty both times (`final-pass/head.txt`, `head-after.txt`, `status-before.txt`, `status-after.txt`).

**The full suite against `faacf16`, by package and test name** (`11-repair-evidence/full-suite-compare.tsv`). The run at `faacf16` is the one of the last report, on the same machine.

| | `faacf16` | `bff8dda` |
| --- | --- | --- |
| Results | 6,527 | 6,786 |
| Pass | 6,320 | 6,577 |
| Fail | 166 | 168 |
| Skip | 41 | 41 |
| `es/admission` | 2,074 pass, 1 skip | 2,207 pass, 1 skip |
| The new package | no such package | 70 pass |
| Store package | 749 pass, 3 fail, 2 skip | 749 pass, 3 fail, 2 skip |
| Root package | 2,168 pass, 163 fail | 2,222 pass, 165 fail |

- **One test went from pass to fail,** with its one subtest: `TestRemoteAlphaESServiceTLSStatusCombinedGroupSignalFailureLiveDescendant` and `TestRemoteAlphaESServiceTLSStatusCombinedGroupSignalFailureLiveDescendant/term`, in the root package. No other test that exists at both commits changed its result. It is the timing fault of the TLS status fixture that PR #21 repaired on `trunk_dev` (commit `110d377`), which this branch does not hold: the fixture leaves an orphan process for the container's init process to reap, and the test's bound can pass first. The file, `remote_alpha_es_service_tls_status_test.go`, is byte-identical to the base and is not among the 28 paths. I re-ran this one test alone on the same copy, twenty times: 20 runs pass and 0 fail (`final-pass/flake-rerun.txt`). The project's rule is to re-run what failed and not the whole suite, so the full suite ran once.
- 285 names are new (158 in `es/admission`, 70 in the new package, 57 in the root package) and all pass. 17 of them are top-level tests: the 11 of the new package and 6 in `es/admission` (section 8.1).
- 26 names are gone (25 in `es/admission`, 1 in the root package). Each has a successor that passes; the table below lists them.
- The other 166 failures are the same 166 names as at `faacf16`: 16 top-level tests with their subtests. None is in a file this pull request touches. Thirteen are in the root package (twelve Remote Alpha operator-script tests, and `TestTrackedGeneratedArtifactHygiene`, which needs `.git`). Three are in the store package and need a probe binary built from an older source tree. The audit lists the same environment failures (its O4-3).
- The 41 skips are the same 41 names: 38 in `es/app`, 2 in `es/admission/internal/reliablesubmit`, 1 in `es/admission`.

**The names that are gone, and their successors.**

| Name at `faacf16` | Successor now |
| --- | --- |
| `TestOperationalSubmitHandoffCurrentAdmissionV2RejectsUnsafeMutants/MissingSnapshotConstructionOwner` | `TestOperationalSubmitHandoffCurrentAdmissionV2RejectsUnsafeMutants/MissingStateConstructionOwner`, `TestOperationalSubmitHandoffCurrentAdmissionV2RejectsUnsafeMutants/MissingViewConstructionOwner` |
| `TestOperationalAdmissionConfirmationDeadlineArithmetic` and its 17 subtests of the same names | `TestConfirmationDeadlineArithmetic` in the new package, with the same 17 subtest names |
| `TestOperationalAdmissionConfirmationDeadlineArithmetic/hooks_without_a_skew` | No subtest of this name. The case gave the old function a hooks struct without a skew function. The new package takes the function itself, and the wrapper that turns hooks without a skew into zero is in `Service.installOperationalAdmission`, where every fixture with hooks and no skew runs through it. `TestConfirmationDeadlineArithmetic/a_view_that_was_never_confirmed_does_not_ask_the_proof_seam` is new |
| `TestOperationalAdmissionDigestFramesItsConstantParts` and its 2 subtests of the same names | `TestDigestFramesItsConstantParts` in the new package, with the same 2 subtest names |
| `TestOperationalGuardLoadsEveryProductionFile/directories_the_go_command_does_not_build_from` | `TestOperationalGuardLoadsEveryProductionFile/packages_compiled_from_directories_that_no_pattern_matches`, `TestOperationalGuardLoadsEveryProductionFile/every_directory_but_.git_is_listed`. The old subtest pinned the gap of finding A4-1; the two new ones pin its repair |
| `TestOperationalHandoffOpaqueAuthorityBoundaries/snapshot-construction/&operationalAdmissionSnapshot{}`, `TestOperationalHandoffOpaqueAuthorityBoundaries/snapshot-construction/new(operationalAdmissionSnapshot)` | `TestOperationalHandoffOpaqueAuthorityBoundaries/snapshot-construction/&view{}`, `TestOperationalHandoffOpaqueAuthorityBoundaries/snapshot-construction/new(view)` |

**Runs while repairing.** Before each push I ran, on a scratch copy, the tests that the change touches. Before each of the last three pushes that was the whole of `es/admission` on the bytes of the commit, with the root package before `6826aae` (which changes the docs contract test) and the new package before `fd74e97` and `bff8dda`. Those runs are superseded by the full suite above and are not listed one by one. The one push that went out with a failing test is section 7, item 1.

## 10. Mutants and probes

Every result in this section was measured on the bytes of `bff8dda`, after the push, by scripts that copy the committed tree (`scripts/fin4-m.sh.txt`; each stream records the commit it copied in `final-pass/mutants-head.*.txt`). The tables are built from the run outputs by `scripts/build4.py.txt`, which fails on a missing result, on a doubled one, and on a mutant that is not killed and has no written reason.

### 10.1 Behaviour mutants: 232

**Where the 232 come from.** The earlier repairs left 211 mutants in four specs: 133 of the first repair for `es/admission`, 40 for the store, 33 of the second repair and 5 of the third. 54 of the 211 change a file of the store package and did not run again (section 10.5). The other 157 are all in the set, under their old ids, and 75 are new:

- **59 earlier mutants change lines that this repair moved or rewrote.** Part R of the new spec (`specs/split-mutants-spec.py.txt`) restates each one at its new place, with the same weakening.
- **66 earlier mutants have anchors that match the committed bytes unchanged:** 45 of the first repair's spec, 17 of the second repair's, 4 of the third's. One of them, `C4-content-key-length-unchecked`, has a corrected replacement text. As written it removed the last use of an import in its file, which no longer compiles since the digest moved out of that file; the corrected text disables the same comparison (`specs/adm-mutants-spec.fourth-repair.py.txt`).
- **32 earlier mutants weaken a rule of the guard of the first repair.** They change a guard test file, so only guard tests can catch them, now as before.
- **75 new mutants,** part N of the new spec: the package border and its owner check, `Install` and what the token must name, the latches, the confirmation and its two clocks, the copies in and out, the mapping between the policy set and plain content, the seams, the new fail-closed branch, `NewService`, and the two outcomes of O4-1.

**How a mutant is judged.** The runner (`scripts/mutants-runner.py.txt`) applies one mutant to a scratch copy and runs the behaviour selection of `es/admission` (`-run 'Operational|PR12|RedTeam'`); a mutant of `state.go` also runs every test of the new package. It counts the leaf tests that fail with the mutant and pass without it, and it keeps the failures of the guard tests apart. The verdicts:

- **Killed by a behaviour test:** at least one test that is not a guard test fails.
- **Does not compile:** the compiler refuses the mutated production code.
- **Caught by guard tests only:** no behaviour test of the selection fails, and a source inventory or the hash pin does.
- **Survives:** no test of the package fails.

Every mutant outside the 32 ran in up to three stages, and a later stage ran only for the mutants that the stage before left alive:

1. The selection with the guard tests left out (`final-pass/beh_*.out`). This halves the time of a mutant that a behaviour test kills.
2. The selection with its guard tests (`final-pass/second_*.out`).
3. Every test of the package, `-run .` (`final-pass/third_whole_package.out`, from `scripts/whole_package.py.txt`).

**Stage 3 was added during the final pass, and it corrects a weakness of my own runner.** The selection picks tests by name, and five guard tests have names it does not match, the synchronization inventory among them. So stage 2 cannot tell a survivor from a mutant that one of those five catches. I saw it when `N-E2h`, which assigns the zero handle in a new production method and which I expected the reference inventory of the handle field to refuse, came out of stage 2 alive. Stage 3 ran the six mutants that stage 2 left alive. Two are caught by the synchronization inventory: `N-E2h`, as expected, and `C5`, which removes one of the references that the inventory of `Service.trustModel` counts. Four survive: `I1`, `N-O41-deadline-reported-io`, `R2-INTENT-ALWAYS` and `R2-STAGE-ALWAYS`. The earlier reports called a mutant a survivor after the selection alone; for the mutants in this set that is now measured against the whole package.

The 32 guard-rule mutants ran with the guard tests their spec names, except the slowest one (`final-pass/guardrules_light.out`). All 32 were caught there, so none needed a second run with it.

| Group | Mutants | Killed by a behaviour test | Does not compile | Caught by guard tests only | Survives |
| --- | --- | --- | --- | --- | --- |
| New in this repair | 75 | 65 | 0 | 9 | 1 |
| Earlier, text moved (same id, new anchor) | 59 | 53 | 4 | 2 | 0 |
| Earlier, anchor unchanged | 66 | 54 | 0 | 9 | 3 |
| Earlier, weakens a guard rule | 32 | 0 | 0 | 32 | 0 |
| **All** | **232** | **172** | **4** | **52** | **4** |

**Against the audited tip,** for the 157 earlier mutants. "At `faacf16`" is the result the last report gave.

| At `faacf16` | Now | Mutants |
| --- | --- | --- |
| killed by a behaviour test | does not compile | 1 |
| killed by a behaviour test | killed by a behaviour test | 105 |
| killed by a behaviour test | survives | 1 |
| caught by guard tests only | does not compile | 3 |
| caught by guard tests only | caught by guard tests only | 40 |
| survives | caught by guard tests only | 3 |
| survives | killed by a behaviour test | 2 |
| survives | survives | 2 |

Ten of the 157 have another result than at `faacf16`:

- **Four no longer compile** (`T1ab`, `E1`, `E2`, `E9`). Each needs code that the package border refuses. Three of them were caught by guard tests only at `faacf16`, among them the red team's conversion; here the compiler does what the guard did.
- **Two earlier survivors are killed** (`F2b-never-confirmed-accepted`, `C5b-digest-ignores-canonical-error`). Each disables one of two checks that refuse the same fault, so no test of `es/admission` could see it. The tests of the new package call the function with the one check directly (`TestConfirmationDeadlineArithmetic`, `TestDigestGoldenVectors`, `TestStateLatchesAndRealm`).
- **Three earlier survivors are caught by guard tests only** (`F2g` by the hash pin of `state.go`, `T1b` and `C5` by an inventory that counts calls or references). No behaviour test sees them, now as before; the table below says so for each.
- **One mutant that was killed survives:** `I1`, because the check it removes is now made twice (section 4.7).

The other 147 have the result they had: 105 killed by a behaviour test, 40 caught by guard tests only, and the two survivors `R2-INTENT-ALWAYS` and `R2-STAGE-ALWAYS`.

**Every mutant that no behaviour test kills, and why.** The 32 guard-rule mutants are left out of this table: no behaviour test can catch a change of the guard, and all 32 are caught by guard tests.

| Mutant | Result now | At `faacf16` | Why |
| --- | --- | --- | --- |
| `T1b-callback-returns-stored-token` | caught by guard tests only | survives | No behaviour test fails, for the reason given at `faacf16`: it is one of two checks that refuse the same fault, and the callback has already refused when the two tokens differ (`05-repair.md` section 11.8). What fails now is the call-site list of `View.Token`, which counts two calls in `Service.advanceOperational`; the mutant removes one. That is a count of calls and not a judgement of behaviour, so I still read this mutant as one that the behaviour tests do not see. |
| `T1ab-fence-removed` | does not compile | killed by a behaviour test | The mutant needs code that the package border refuses: to pass the token comparison it sets a view by hand, and `admissionstate.View{v: nil}` does not compile outside the package. At `faacf16` the same weakening compiled and a test killed it. |
| `F2g-limit-inclusive` | caught by guard tests only | survives | Equivalent, as at `faacf16`: at exactly 30 seconds the added-time clause refuses (`05-repair.md` section 11.8). No behaviour test fails. The hash pin of `state.go` fails, as it does for any edit of that file. |
| `E1-redteam-anonymous-struct-conversion` | does not compile | caught by guard tests only | The mutant needs code that the package border refuses: the red team's conversion to a same-shape struct, applied to the view handle. At `faacf16` it compiled and only the guard caught it. |
| `E2-production-zeroes-the-view` | does not compile | caught by guard tests only | The mutant needs code that the package border refuses: it overwrites the state through the handle's pointer. At `faacf16` the same overwrite compiled and only the guard caught it. |
| `E9-production-writes-token-through-pointer` | does not compile | caught by guard tests only | The mutant needs code that the package border refuses: it takes the address of the view's token field. At `faacf16` it compiled and only the guard caught it. |
| `N-E2h-production-swaps-in-the-zero-handle` | caught by guard tests only | new | It assigns the zero handle to `Service.operational` in a new method. The reference inventory of the handle field lists the one assignment, in `NewService`. The guard test that holds this inventory is outside the test selection of the second run, so this mutant was decided by its third run, with every test of the package. |
| `N-E2n-production-swaps-in-a-new-state` | caught by guard tests only | new | It assigns a new state to `Service.operational` in a new method: a second call of `New` and a second assignment of the handle. Both lists refuse it. |
| `N-E12-production-inspects` | caught by guard tests only | new | It adds a production call of an exported member of the new package. Only the call-site lists can refuse that, by design (section 4.5): `Inspect`, which has no production caller. |
| `N-E13-production-confirms-without-asking` | caught by guard tests only | new | It adds a production call of an exported member of the new package. Only the call-site lists can refuse that, by design (section 4.5): `Confirm` with the view's own trust, which would keep a view alive without EGS. |
| `N-E14-production-installs-with-a-kept-token` | caught by guard tests only | new | It adds a production call of an exported member of the new package. Only the call-site lists can refuse that, by design (section 4.5): `Install` at a second place. |
| `N-E15-production-withdraws-locally` | caught by guard tests only | new | It adds a production call of an exported member of the new package. Only the call-site lists can refuse that, by design (section 4.5): `Withdraw` at a second place. |
| `N-E16-production-reads-the-proof-value` | caught by guard tests only | new | It adds a production call of an exported member of the new package. Only the call-site lists can refuse that, by design (section 4.5): `View.Proof` at a second place. |
| `N-INSTALL-zero-installation-accepted` | caught by guard tests only | new | Equivalent: the next check requires `token.Names(installation, epoch, digest)`, and a token is valid only with a nonzero installation. The pair with the token check removed is killed (`N-INSTALL-token-unchecked-in-both-places`). No behaviour test fails. The hash pin of `state.go` fails, as it does for any edit of that file. |
| `N-INSTALL-zero-epoch-accepted` | caught by guard tests only | new | Equivalent for the same reason: a valid token has a nonzero epoch. No behaviour test fails. The hash pin of `state.go` fails, as it does for any edit of that file. |
| `N-O41-deadline-reported-io` | survives | new | Equivalent, and my mistake in writing it. The mutant removes `errors.Is(err, context.DeadlineExceeded)` from a case whose other half is `errors.As(err, &timeout) && timeout.Timeout()` with a `net.Error`. `context.DeadlineExceeded` is a `net.Error` whose `Timeout()` is true, so the answer stays `OperationalTimeout`. The provider file is unchanged since `faacf16`. The mutant that does answer an I/O failure, `N-O41-deadline-answers-io`, is killed. |
| `C5-content-trust-validity-unchecked` | caught by guard tests only | survives | No behaviour test fails, for the reason given at `faacf16`: it is one of two checks that refuse the same fault, and the digest refuses a trust model without a canonical encoding. What fails is the reference inventory of `Service.trustModel`, which counts the references in each function; the mutant removes one. That is a count and not a judgement of behaviour, and it showed only in the third run: the guard test that holds it is outside the test selection. The last report called this mutant a survivor after the selection alone; I did not measure whether the same inventory caught it at `faacf16`. Its neighbour `C5b` survived at `faacf16` too and is killed now, by the direct tests of `Digest` in the new package. |
| `I1-install-token-not-checked` | survives | killed by a behaviour test | **New survivor, and I say why.** The check in `Service.installOperationalAdmission` that the store's token names the realm and the digest is now doubled: `Install` makes the same comparison inside the package (section 4.7). With the caller's check removed, `Install` refuses the same token and the caller returns the same error. The check inside the package is killed on its own (`N-INSTALL-token-unchecked`), and so is the pair. I kept the caller's check: it refuses before the Service lock is taken. |
| `E3-production-commissions` | caught by guard tests only | caught by guard tests only | It adds production code that behaves like the code beside it until it is used. The guard's inventories are what refuses it, as at `faacf16`. |
| `E4-production-advances` | caught by guard tests only | caught by guard tests only | It adds production code that behaves like the code beside it until it is used. The guard's inventories are what refuses it, as at `faacf16`. |
| `E5-production-configures-clock-seam` | caught by guard tests only | caught by guard tests only | It adds production code that behaves like the code beside it until it is used. The guard's inventories are what refuses it, as at `faacf16`. |
| `E6-production-confirms-twice` | caught by guard tests only | caught by guard tests only | It adds production code that behaves like the code beside it until it is used. The guard's inventories are what refuses it, as at `faacf16`. |
| `E7-production-imports-reflect` | caught by guard tests only | caught by guard tests only | It adds production code that behaves like the code beside it until it is used. The guard's inventories are what refuses it, as at `faacf16`. |
| `E8-production-copies-the-service` | caught by guard tests only | caught by guard tests only | It adds production code that behaves like the code beside it until it is used. The guard's inventories are what refuses it, as at `faacf16`. |
| `E10-production-second-trust-fetch` | caught by guard tests only | caught by guard tests only | It adds production code that behaves like the code beside it until it is used. The guard's inventories are what refuses it, as at `faacf16`. |
| `E11-production-calls-store-advance` | caught by guard tests only | caught by guard tests only | It adds production code that behaves like the code beside it until it is used. The guard's inventories are what refuses it, as at `faacf16`. |
| `R2-INTENT-ALWAYS` | survives | survives | As at `faacf16`: no state the handoff can reach has a failed intent binding under a live context (`07-repair.md` section 9.1, judged in `08-audit.md`). |
| `R2-STAGE-ALWAYS` | survives | survives | As at `faacf16`: the same for the stage binding. |

In numbers, outside the 32: 4 do not compile, 20 are caught by guard tests only, 4 survive. Of the 20, eight add forbidden production code that the guard has always been the control for (`E3` to `E8`, `E10`, `E11`), seven add a call or an assignment that only the call-site and reference lists can refuse (`N-E2h`, `N-E2n`, `N-E12` to `N-E16`), three are equivalent mutants inside `state.go` that the hash pin catches like any edit (`F2g`, `N-INSTALL-zero-installation-accepted`, `N-INSTALL-zero-epoch-accepted`), and two fail an exact count (`T1b`, `C5`). Of the four survivors, one is an equivalent mutant of mine, two are the survivors the last two audits judged, and **one is new: `I1`.** I ask the auditor to judge it.

**The first pass, and what it changed.** Before the final pass, every mutant of the set except five (`N-E12` to `N-E16`, which I wrote last) had run at least once on earlier bytes of the working tree (`first-pass/mut_*.out`). I report three things about it:

- **Three first-pass streams were cut off.** A background job in this environment ends after two hours, and `mut_split_a.out`, `mut_split_b.out` and `mut_old_c.out` each stopped there, the last line cut in the middle. I continued each list for the ids without a result (`mut_fix_*.out`). No number in this report rests on the first pass: the final pass ran all 232 again, in shorter jobs. **One job of the final pass reached the limit too.** `final-pass/beh_split_a.out` ends after 50 of its 62 mutants, and there is no `M2_DONE` marker. The other 12 ran in a follow-up job that reads which ids have no result line (`scripts/fin4-c.sh.txt`, `final-pass/beh_split_a_cont1.out`). Every mutant has exactly one result of each stage it ran in; the builder fails on a doubled id.
- **The first pass found the survivors that section 7, item 9 lists,** and each got a test before the final pass. Nine mutants that were alive after their first run are killed by a behaviour test now: `S5b`, `S5c`, `S20`, `N-NEWSERVICE-foreign-owner`, `N-HELD-nil-owner-unchecked`, `N-INSTALL-latches-unchecked`, the two `N-QUALIFY-` mutants and `N-SEAM-stricter-replaces-the-built-in-set`. Four mutants did not compile as I first wrote them and were corrected (`N-INSTALL-token-unchecked`, `N-INSTALL-token-unchecked-in-both-places`, `N-CONFIRM-not-recorded`, `C4`); all four are killed. In the behaviour stage no mutant has a worse result in the final pass than in its first run.
- **One mutant of mine was wrong.** `N-O41-deadline-reported-io` is equivalent (its row in the table above says why). The mutant I had meant is `N-O41-deadline-answers-io`, which makes the deadline answer `OperationalIO`; it is in the set and is killed.

### 10.2 Guard mutants: 169

Each weakens the guard's own code in a scratch copy and runs the guard tests. A mutant counts as caught only when a guard test fails. The guard selection is the twelve guard and inventory tests of `es/admission` (`specs/guard-mutants-runner.py.txt` names them); without a mutant it passes with 592 results, and with 589 when the slowest test is left out. The specs are in `specs/`: 18 mutants of the second repair, 56 of the third, 34 for part one of this repair (`G4-`) and 61 for the state package (`G5-`).

| Rules of | Mutants | Caught | Caught (run with every guard test) | Caught: the test binary stops | Not caught | Its lines are gone |
| --- | --- | --- | --- | --- | --- | --- |
| Second repair | 18 | 18 | 0 | 0 | 0 | 0 |
| Third repair | 56 | 47 | 0 | 1 | 0 | 8 |
| Part one of this repair | 34 | 34 | 0 | 0 | 0 | 0 |
| The state package | 61 | 48 | 9 | 1 | 3 | 0 |
| **All** | **169** | **147** | **9** | **2** | **3** | **8** |

**How they ran.** 149 mutants ran against the selection without its slowest test, `TestOperationalHandoffNoPublicStartupOrdinaryOrFixtureCaller` (`final-pass/guard_fast_*.tsv`). Twelve ran with every guard test (`final-pass/guard_full_*.tsv`): nine that the first pass showed alive without the slowest test and caught with it, and the three below.

**The first pass.** The first runs of the guard mutants (`first-pass/`, on earlier bytes) left six alive with every guard test: `G4-MOD-COMMENT`, `G5-SCOPE-ES-ONLY`, `G5-REFUSAL-FILE`, `G5-STATE-NOT-RUN`, `G5-HANDLE-NO-INVENTORY` and `G5-STATE-FIELDS-UNREAD`. Each led to a self-test or a rule (section 7, items 9 and 15) and is caught now. Three mutants did not compile as I first wrote them and were corrected: `G5-PIN-SUBDIR`, `G5-SCOPE-ALL`, and `G5-REFUSAL-FILE`, which survived once it compiled and is one of the six. The three mutants that are not caught now were not caught in the first pass either.

**Eight mutants of the third repair have no lines left to change.** Part one rewrote the walk and the tree checks they weakened, and each has a successor among the `G4-` and `G5-` mutants that weakens the same rule in the new code:

| Mutant of the third repair | Successor |
| --- | --- |
| `G3-WALK-VENDOR`, `G3-WALK-TESTDATA`, `G3-WALK-DOT`, `G3-WALK-UNDERSCORE`, `G3-WALK-ROOT` | `G4-WALK-VENDOR`, `G4-WALK-TESTDATA`, `G4-WALK-DOT`, `G4-WALK-UNDERSCORE`, `G4-WALK-ROOT` |
| `G3-FILESET-ROOT` | `G4-TREE-ROOTDIR` |
| `G3-FILESET-DIRECTORY` | `G4-TREE-MISSINGDIR` |
| `G3-FILESET-TWO` | `G5-TREE-TWO` |

`final-pass/anchors.txt` counts, for every guard mutant, how often the text it replaces occurs in the committed bytes: exactly once for 161, and not once for these eight.

**Two mutants stop the test binary.** `G3-REACH-SEEN-OFF` and `G5-HELD-SEEN-OFF` remove the mark that ends a walk through a type that refers to itself. The walk then runs until the stack is full, the test binary stops and `go test` fails. I count that as caught and show it apart in the table.

**Three mutants are not caught, and I do not think a test can catch them.** I list them because the count must be honest, and because the auditor may disagree:

| Mutant | What it changes | Why no test fails |
| --- | --- | --- |
| `G5-PROBE-UNJUDGED` | In the self-test of the forms that must not compile, the answer of the compiler is not judged | It changes the last assertion of a test, not a rule that the test checks. A test of that assertion would have a last assertion of its own. What judges a refusal (`compileRefusal`) is a function, and its mutants are caught (`G5-REFUSAL-` in section 10.3). |
| `G5-SCOPE-NO-CMD` | The directory scope of the ES synchronization inventory is no longer required to have read `cmd/es` | The same: `requirePackagesRead` is the check that the scope read what it names, and the mutant changes its argument at the one call. The function has a self-test, and the mutant that drops `cmd/es` from the scope itself is caught (`G5-SCOPE-ES-ONLY`). |
| `G5-PIN-NOT-RUN` | The first comparison of the real `state.go` with its pin is removed | Equivalent: the four controls of the same test compare the real file with the real pin again, and they fail on a changed file as the removed line did (`G5-PIN-STALE` and `G5-PIN-HASH` are caught). |

The first two belong to one class: the final assertion of a test, or the data it is called with at its one call site on the real tree. Section 7, item 15 is about the neighbouring class, where a piece of what the guard reads on the real tree can be taken out, and the holder rule closed the cases I found. I searched for more of both classes by writing these mutants; I do not claim the search is complete.

### 10.3 The mutants of this repair's guard rules, one by one

The last column is the number of leaf tests that fail.

**Part one, 34 mutants (`G4-`):** the loader, the walk, the three ways to compile from elsewhere, the directive list of `go.mod`, the import pins.

| Mutant | What it weakens in the guard | Result | Tests that fail |
| --- | --- | --- | --- |
| G4-SEL-DEPONLY | selection: a dependency-only package is not read (the rule audited at faacf16) | caught | 6 |
| G4-SEL-OUTSIDE | selection: a package compiled from outside is passed over, not refused | caught | 4 |
| G4-SEL-NODIR | selection: a package without a directory is passed over | caught | 1 |
| G4-SEL-CACHE-ORDER | selection: the repository is asked before the module cache | caught | 1 |
| G4-SEL-PREFIX | selection: inside means a string prefix | caught | 2 |
| G4-SEL-PARENT | selection: the directory above counts as inside | caught | 2 |
| G4-SEL-IMPORTPATH | selection: only an import path of the root module is read | caught | 2 |
| G4-WALK-ALL3 | walk: testdata, dot and underscore directories are skipped again (the audit's W1) | caught | 6 |
| G4-WALK-TESTDATA | walk: testdata directories are skipped | caught | 5 |
| G4-WALK-DOT | walk: dot directories are skipped | caught | 4 |
| G4-WALK-UNDER | walk: underscore directories are skipped | caught | 5 |
| G4-WALK-VENDOR | walk: vendor directories are skipped | caught | 1 |
| G4-WALK-ROOT | walk: a checkout whose own directory is called .git is skipped whole | caught | 1 |
| G4-WALK-GIT | walk: .git is read | caught | 1 |
| G4-TREE-WORK | tree: a workspace file is accepted | caught | 3 |
| G4-TREE-WORK-ROOT | tree: a workspace file is refused at the root only | caught | 1 |
| G4-TREE-WORKSUM | tree: go.work.sum is accepted | caught | 1 |
| G4-TREE-NESTED | tree: a nested module is accepted | caught | 3 |
| G4-TREE-NESTED-TESTDATA | tree: a nested module is accepted in a testdata directory | caught | 2 |
| G4-TREE-MISSINGDIR | tree: a type-checked file in an unlisted directory is accepted | caught | 2 |
| G4-TREE-ROOTDIR | tree: the repository root is not checked | caught | 6 |
| G4-MOD-COMMENT | go.mod: a comment is read as a directive | caught | 2 |
| G4-MOD-INDENT | go.mod: an indented directive is not read | caught | 1 |
| G4-MOD-PAREN | go.mod: a block opened without a space is one unknown word | caught | 1 |
| G4-MOD-BLOCKEND | go.mod: a block never ends | caught | 1 |
| G4-MOD-FIRSTONLY | go.mod: only the kinds before the first block are read | caught | 1 |
| G4-MOD-REPLACE | go.mod: a replace directive is not a kind | caught | 6 |
| G4-WORK-ANY | workspace: any workspace is accepted | caught | 1 |
| G4-WORK-CALL | workspace: the loader does not ask | caught | 1 |
| G4-WORK-OFF | workspace: a switched-off workspace is refused | caught | 1 |
| G4-PIN-NOHASH | pin: the content is not hashed | caught | 1 |
| G4-PIN-IMPORTS | pin: only the import list is hashed | caught | 1 |
| G4-PIN-NAME | pin: the file name is hashed, not the content | caught | 1 |
| G4-PIN-C | pin: a cgo import is not listed | caught | 5 |

**The state package, 61 mutants (`G5-`):** the closed surface, the call-site lists, the construction inventory, the forms that must not compile, the hash pin, the directory scope, and the 21 of the holder rule (`G5-HELD-`).

| Mutant | What it weakens in the guard | Result | Tests that fail |
| --- | --- | --- | --- |
| G5-SURF-UNCOMPARED | surface: the exported names are not compared with the list | caught | 1 |
| G5-SURF-NO-METHODS | surface: methods are not listed | caught | 1 |
| G5-SURF-VALUE-METHODS | surface: only methods with a value receiver are listed | caught | 1 |
| G5-SURF-NO-FIELDS | surface: exported fields of an exported struct are not listed | caught | 1 |
| G5-SURF-NO-EMBEDDED | surface: embedded fields are not listed | caught | 1 |
| G5-SURF-NO-VARS | surface: exported variables are not listed | caught | 1 |
| G5-SURF-NO-CONSTS | surface: exported constants are not listed | caught | 1 |
| G5-SURF-NO-FUNCS | surface: exported functions are not listed | caught | 1 |
| G5-SURF-NONSTRUCT | surface: an exported type that is not a struct is listed like an empty struct | caught | 1 |
| G5-COVER-UNCHECKED | coverage: functions and methods are not compared with the inventories | caught | 1 |
| G5-COVER-METHODS | coverage: only functions need an inventory | caught | 1 |
| G5-MEMBERS-NO-INSTALL | call sites: the inventory of State.Install is removed | caught (run with every guard test) | 1 |
| G5-MEMBERS-NO-INSPECT | call sites: the inventory of State.Inspect is removed | caught (run with every guard test) | 1 |
| G5-MEMBERS-NO-NEW | call sites: the inventory of New is removed | caught (run with every guard test) | 1 |
| G5-MEMBERS-UNVALIDATED | call sites: a changed inventory of a state member is not an error | caught (run with every guard test) | 1 |
| G5-MEMBERS-CLOSURES | call sites: a call of Installable inside a function literal is accepted | caught (run with every guard test) | 1 |
| G5-MEMBERS-INSPECT-ANYWHERE | call sites: Inspect may be called once from the confirmation | caught (run with every guard test) | 1 |
| G5-STATE-NOT-RUN | the inventories of the state package are not part of the gate | caught (run with every guard test) | 1 |
| G5-CONSTRUCT-UNCHECKED | construction: a second state or view literal in the package is accepted | caught (run with every guard test) | 1 |
| G5-CONSTRUCT-VIEW-UNLISTED | construction: only the state literal is held, a view may be made anywhere | caught (run with every guard test) | 1 |
| G5-REFUSAL-MESSAGE | compile probes: any error counts as the expected refusal | caught | 1 |
| G5-REFUSAL-LINE | compile probes: an error in the host text counts | caught | 1 |
| G5-REFUSAL-FILE | compile probes: an error in another file counts | caught | 1 |
| G5-REFUSAL-COMPILES | compile probes: a form that compiles is judged refused | caught | 1 |
| G5-PROBE-UNJUDGED | compile probes: the result of a probe is not judged | **not caught** |  |
| G5-PIN-HASH | pin: the hash of the file is not compared | caught | 3 |
| G5-PIN-SECOND-FILE | pin: a second production file is accepted | caught | 5 |
| G5-PIN-TEST-NAME | pin: a file whose name only contains _test.go is taken for a test | caught | 1 |
| G5-PIN-SUBDIR | pin: a directory below the package is accepted | caught | 1 |
| G5-PIN-NOT-RUN | pin: the real package is not checked against the pin | **not caught** |  |
| G5-PIN-STALE | pin: the constant is the hash of other bytes | caught | 1 |
| G5-SCOPE-ALL | scope: every loaded package is in the scope | caught | 2 |
| G5-SCOPE-PREFIX | scope: a directory whose name begins like the scope is inside | caught | 1 |
| G5-SCOPE-ES-ONLY | scope: the packages of cmd/es are not read | caught | 1 |
| G5-HANDLE-NO-INVENTORY | the handle Service.operational has no access inventory | caught | 1 |
| G5-STATE-FIELDS-UNREAD | the access inventories inside the state package are not read | caught | 1 |
| G5-TREE-TWO | tree: only the admission package and the packages below it are checked (the scope audited at c41e177) | caught | 37 |
| G5-SCOPE-READ-NEVER-FAILS | scope: a required package that was not read is accepted | caught | 1 |
| G5-SCOPE-READ-ANY | scope: one required package that was read is enough | caught | 1 |
| G5-SCOPE-NO-CMD | scope: the main package of the ES binary is not required | **not caught** |  |
| G5-HELD-UNCHECKED | holders: a field without an inventory is accepted | caught | 1 |
| G5-HELD-VARIABLES | holders: a package variable that holds a handle is accepted | caught | 1 |
| G5-HELD-VIEW-FREE | holders: only the state handle counts, a view may be held anywhere | caught | 1 |
| G5-HELD-STATE-FREE | holders: only the view handle counts, a state may be held anywhere | caught | 1 |
| G5-HELD-VIEW-STRUCT | holders: the fields of the view struct need no inventory | caught | 1 |
| G5-HELD-STATE-STRUCT | holders: the fields of the state struct need no inventory | caught | 1 |
| G5-HELD-OTHER-PACKAGES | holders: the fields of other packages that hold a handle are not listed | caught | 1 |
| G5-HELD-POINTER | holders: a pointer to a handle is not seen | caught | 1 |
| G5-HELD-SLICE | holders: a slice of handles is not seen | caught | 1 |
| G5-HELD-ARRAY | holders: an array of handles is not seen | caught | 1 |
| G5-HELD-CHAN | holders: a channel of handles is not seen | caught | 1 |
| G5-HELD-MAP-KEY | holders: a map keyed by handles is not seen | caught | 1 |
| G5-HELD-MAP-VALUE | holders: a map to handles is not seen | caught | 1 |
| G5-HELD-STRUCT | holders: a struct without a name is not looked into | caught | 1 |
| G5-HELD-FUNC-PARAMS | holders: a function type that takes a handle is not seen | caught | 1 |
| G5-HELD-FUNC-RESULTS | holders: a function type that returns a handle is not seen | caught | 1 |
| G5-HELD-TYPE-ARGUMENT | holders: a handle as a type argument is not seen | caught | 1 |
| G5-HELD-NAMED | holders: a named type that is not a struct is not looked into | caught | 1 |
| G5-HELD-STATUS | holders: a named struct of the state package is not looked into | caught | 1 |
| G5-HELD-ALIAS | holders: an alias of a handle type is not resolved | caught | 1 |
| G5-HELD-SEEN-OFF | holders: a named type that names itself is followed without end | caught: the test binary stops |  |

### 10.4 The probes of the audit, again

The audit ran 26 probes on the real packages at `faacf16`. Six passed the guard there: H1A, H1B and H1C (a package in a `testdata`, an underscore and a dot directory that imports `reflect` and `unsafe`), H1D (whole values of `Service` in such a package), H2A (the same as a nested module behind a `replace` line) and U1 (an offset write through `unsafe` in a file that already imports it). I ran those six and the audit's four controls (H1E, N1, N2, N3) against the committed bytes, and two of my own (U2 and N3R).

My runner (`scripts/r4-probes-runner.py.txt`) reads the Go source of each probe out of the auditor's two files as data, with a syntax-tree parser that takes string constants only; it executes nothing of those files. Their SHA-256 are `73f0079986ec852b9c3b42a163c286bb01ab679b874cc58a7fd61538b0ba8a49` (`probe_hidden_bodies.py.txt`) and `39982a4669c581f0e1e2cd12ce523945236670e517a3e7adf960e0f7e1719ed5` (`probe_rerun.py.txt`). The edits that place a probe are restated in my runner from reading the auditor's scripts. Each probe is applied to a scratch copy, the tree is built for Linux and for darwin/arm64, and the guard tests run without the slowest one.

| Probe | What it adds | Result | Guard tests that fail |
| --- | --- | --- | --- |
| BASE | no change | passes |  |
| H1A | a package in es/app/testdata/zzaudit that imports reflect and unsafe and reaches into the Service by field name; one call from es/app | caught | TestOperationalGuardReflectUnsafeImportInventoryIsExact |
| H1B | a package in es/app/_zzaudit that imports reflect and unsafe and reaches into the Service by field name; one call from es/app | caught | TestOperationalGuardReflectUnsafeImportInventoryIsExact |
| H1C | a package in es/app/.zzaudit that imports reflect and unsafe and reaches into the Service by field name; one call from es/app | caught | TestOperationalGuardReflectUnsafeImportInventoryIsExact |
| H1D | whole values of admission.Service, a generic instantiated with it and a type parameter constrained to it, in es/app/testdata/zzwhole | caught | TestExecutionSubstrateSynchronizedMutableStateReferenceInventoryIsExact |
| H1E | control: save and restore of admission.Service written in es/app itself | caught | TestExecutionSubstrateSynchronizedMutableStateReferenceInventoryIsExact |
| N1 | control: the whole-value package of H1D in an ordinary directory (es/zzwhole) | caught | TestExecutionSubstrateSynchronizedMutableStateReferenceInventoryIsExact |
| N2 | reflect and unsafe in a file of es/app behind the build constraint cgo (the guard loads with CGO_ENABLED=0) | caught | TestOperationalGuardLoadsEveryProductionFile, TestOperationalGuardReflectUnsafeImportInventoryIsExact |
| N3 | a Go file under a vendor directory | no-result |  |
| N3R | the same Go file under a vendor directory, with GOFLAGS=-mod=readonly as in the audit's runs | caught | TestOperationalGuardLoadsEveryProductionFile |
| U1 | an offset write into the Service through unsafe in es/admission/execution_roots_darwin.go, which already imports it; one call from the handoff | caught | TestOperationalGuardReflectUnsafeImportInventoryIsExact |
| U2 | one comment line added to es/runtimehelper/privilege_linux.go, the other file that imports unsafe | caught | TestOperationalGuardReflectUnsafeImportInventoryIsExact |
| H2A | the reflect and unsafe package of H1 as a nested module in es/app/testdata/zzmod, reached through a replace line in go.mod | caught | TestOperationalGuardLoadsEveryProductionFile, TestOperationalGuardReflectUnsafeImportInventoryIsExact |

**Results: eleven of the twelve probes fail a guard test, and one has no result in my environment.** The unchanged tree passes (589 results, none fails).

- **H1A, H1B and H1C passed every guard test at `faacf16` (finding A4-1) and fail now.** The guard reads the package whatever its directory is called, and the file that imports `reflect` and `unsafe` is not in the import inventory (`TestOperationalGuardReflectUnsafeImportInventoryIsExact`).
- **H1D passed at `faacf16` and fails now.** The whole values of `Service` in a `testdata` directory are read, and the whole-value inventory lists them as unexpected (`TestExecutionSubstrateSynchronizedMutableStateReferenceInventoryIsExact`).
- **H2A passed at `faacf16` and fails two tests now.** The file-set check refuses the second `go.mod` ("es/app/testdata/zzmod/go.mod declares a nested module, which no pattern of this module matches"), and the import inventory reads the nested module's file.
- **U1 passed at `faacf16` (finding A4-2) and fails now.** The file that already imports `unsafe` is held by the SHA-256 of its bytes, and the added write changes them.
- **U2 is my own:** one comment line in the other file that imports `unsafe` fails the same pin. It shows that the pin is on the bytes and not on the import list.
- **The controls H1E, N1 and N2 fail as they did at `faacf16`.**
- **N3 has no result here, and N3R is caught.** In my environment the go command refuses the tree before any test runs ("inconsistent vendoring"), because a `vendor` directory exists that does not match `go.mod`. The audit ran its probes with `GOFLAGS=-mod=readonly` (its `scripts/asci.py.txt`), which makes the go command ignore the vendor directory. N3R is the same probe with that setting: the file-set check fails ("vendor/audit.example/zz/zz.go is built for none of the guarded targets"), as at `faacf16`.

A probe run has fewer than 589 results because a failing test does not reach its later subtests. The file `final-pass/r4-probes.first-run.txt` is my first run of the probes on the same bytes. It had a wrong label for H1D (it said the probe had failed a test at `faacf16` already; the audit's final form of H1D passed there) and no N3R. I corrected the runner and ran every probe again; the verdicts of the eleven probes that both runs hold are the same.

**The audit's other 16 probes did not run again:** its 12 re-runs of earlier probes, and EM1, AL1, MV1 and GC1. All were caught at `faacf16`. Inference, not measured probe by probe: the ones that reach a protected field of `Service` no longer compile, because those fields are gone. Section 4.4 compiles the same kinds of form against the new package and requires the compiler's refusal.

The auditor's effect tests did not run either: they show what a probe does once it passes the guard, they name fields that no longer exist, and the question here is whether a guard test fails.

### 10.5 What did not run again: the 54 mutants of the store

The store package `es/admission/internal/reliablesubmit` has 54 mutants in the earlier specs (the 40 of the store spec and 14 of the second repair's spec that change a store file). `git diff faacf16 bff8dda -- es/admission/internal/reliablesubmit` is empty, and so is the diff of the store's own tests. Every one of the 54 had its result at `faacf16` from tests of the store package alone, and those tests and the code they run are byte for byte what they were. The full suite of section 9 shows that the store's tests give the same results without a mutant. This is an argument and not a measurement, as in the last report for the mutants it carried over; the auditor may want to run them.

## 11. Failed or skipped validation

**Failed, and why it does not block.**

- Full suite: 168 failing results (section 9). 166 are the same 166 names as at `faacf16`: twelve Remote Alpha operator-script tests, one test that needs a `.git` directory in the tested copy, and three store tests that need a probe binary built from an older source tree, each with its subtests. The audit measured the same set in a copy without `.git` and 42 in a git clone (its O4-3); this run is of the first kind.
- The other two failing results are one test and its one subtest, `TestRemoteAlphaESServiceTLSStatusCombinedGroupSignalFailureLiveDescendant`, which passed at `faacf16`. It is the timing fault of the TLS status fixture that PR #21 repaired on `trunk_dev`; this branch does not hold that repair, and the file is byte-identical to the base. In the full suite its subtest `term` took 2.14 s and reported "leader_reaped failed" and "returned failed" (`final-pass/flake-in-full-suite.txt`). Alone on the same copy it passes 20 of 20 runs. It does not block because no file of this pull request is involved, and it will stay a possible failure of this branch until PR #12 picks up `trunk_dev`. I did not run the full suite a second time to get a run without it.
- `go vet`: one report in `es/admission/result_auth_test.go`, a file this pull request does not change.
- `gofmt -l es/` lists two files of `es/runtimehelper` that this pull request does not touch (section 7, item 13).
- The race detector run has no failure.
- Commit `3f65592` fails one test (section 7, item 1). It is an intermediate commit; the tip does not.

**Mutants that are not killed.** Section 10.1 lists every behaviour mutant that no behaviour test kills, with its reason, and section 10.2 the three guard mutants that are not caught. In numbers: of the 232 behaviour mutants, 172 are killed by a behaviour test, 4 do not compile, 52 are caught by guard tests only (the 32 that weaken a guard rule and 20 others) and 4 survive. Of the 161 guard mutants that still have their lines, 158 are caught and 3 are not.

**Skipped or not run.**

- macOS: nothing was run on a Mac. The guard loads the darwin/arm64 target on Linux, so its inventories cover the darwin file set, and the compile probes of section 4.4 are checked under every target the guard loads.
- GitHub CI: none ran. The head of the pull request has no check run and the branch has no workflow run (asked through the GitHub API after the last push). Neither the base branch nor this branch holds a workflow file; the CI workflow came to `trunk_dev` with PR #14, and PR #12's branch has not picked it up.
- The 54 store mutants did not run again (section 10.5).
- The auditor's effect tests did not run (section 10.4).
- The race detector ran on `es/admission` and the new package, the two packages whose production code this repair changes. It did not run on the store package, which is unchanged since `faacf16`, nor on the root package, whose one changed file is the docs contract test.
- 41 tests skip themselves in the full suite, the same 41 as at `faacf16`: 38 in `es/app` that need Docker, Nomad or Vault, and 3 helper-process tests that only run as a child of another test.
- The full suite and the race detector ran once, on the last commit. The six commits before it were validated by the narrower runs of section 9, last paragraph.
- The store package's tests compile on Linux only with the one-file overlay (`11-repair-evidence/store-test-linux-overlay.patch`, the audit's P-3). The overlay is applied to every scratch copy and is not part of any commit.
- The cost of the per-evaluation copies was not measured (section 4.7).

## 12. Dependencies, hygiene, widening, cross-repo impact

- **Dependencies:** none changed. `go.mod` and `go.sum` are untouched. The new package imports only the standard library and two packages of this repository.
- **Artifact hygiene:** no generated file, binary, database or log is in any commit. The staged set equals the manifest's path list (section 13).
- **Sensitive material:** none read, printed or copied. Tests use keys generated in their fixtures and temporary SQLite files. The evidence folder holds source paths, hashes, test names, test output and scripts. No personal contact detail appears in this report or its evidence.
- **Authority, security or protocol widening:** none. No new caller of any gated entry, no new exported symbol of `es/admission`, no schema change, no change to the wire or to a public API. The new package is below `internal/` and can be imported only from `es/admission` and below. The new exported members are listed in section 4.2, and each has an exact call-site list. `Install` is stricter than the code it replaces (it checks the token itself).
- **Model identifiers:** none in a commit body, in code comments or in the pull request text. The commits carry the required co-author trailer.
- **Cross-repo impact:** none. Only `evo-agi/Execution-Substrate` was touched.
- **PR #14 and PR #12:** not touched. When PR #12 picks up `trunk_dev`, the list line for `TestOperationalHandoffSchema4BinaryRefusesSchema5` still has to be added there, as noted before. This repair adds no test that fails on Linux.

## 13. Provenance

| Item | Value |
| --- | --- |
| Recipe | `governed-execution.audit-patch-manifest.v2` |
| Recipe source SHA-256 | `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked before every run. The recipe file was not edited. |
| Base-relative manifest | SHA-256 `4ccb1a24c05c0baec014b3f295975bb60ae7bae00437752b12f3865767bd1616`, 28 files. Head `8058561edc08356c46680c204586b3c7796c0ff3`, upstream pinned to `origin/codex/reliable-submit-operational-handoff-v1`. |
| Base-relative textual diff | SHA-256 `1de154107b2f7c82e048c5dbf92ef942a2f543111eab96022b45ab09918d2b8b` |
| Repair-only manifest, against the audited tip `faacf16` | SHA-256 `f036029d5399627a95b963b59b910aec1db4e8828a055062b205fe1abbe41f6b`, 16 files. Head `faacf16b9d5cd5ddc28b79da5c6c30f2bca6c124`, upstream `origin/claude/project-thread-sqldt7`. |
| Repair-only textual diff | SHA-256 `3420d32f13517941796562b519e1ad6a815da52c54d556ecc79c96a4abf34b37` |
| Taken twice | Each manifest was written twice into a fresh mode-0700 directory outside the repository, and the two files are byte-identical. |
| Staged-set check | With the index reset to the base, `git add -A` staged exactly the 28 paths of the base-relative manifest; with the index reset to `faacf16`, exactly the 16 paths of the repair-only manifest. `git write-tree` gave `38269372c5bc21f291e1b73e93cf48d78180649d` both times, the tree of the commit. |
| Clean status | `git status --porcelain` was empty before the manifests were taken and after. The local branch equals `origin/claude/project-thread-sqldt7` at `bff8dda37dbf5484afb3b264d4eca38cf6abf118`. |

How the manifests were taken (operating protocol 5.5), by `scripts/prov4.sh.txt`: check that the working tree is clean at the tip, record the tip, `git reset --mixed` to the base, pin the upstream, run the recipe twice, stage and record the staged set and its tree, the same against the audited tip, then `git reset --mixed` back to the tip and restore the upstream. The working tree is never changed by this. The manifests were taken once, after the push and after the final validation, on the commit that this report describes.

The 28 base-relative paths are the 26 of `faacf16` and the two files of the new package. All seven commits were fast-forward pushes of `claude/project-thread-sqldt7`; nothing was forced, and no other branch was pushed.

Complete canonical manifest, base-relative. The block is the file's exact content (one line and a final newline, 6,291 bytes):

```json
{"branch":"claude/project-thread-sqldt7","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/es_execution_admission_model.md","sha256":"f47a909b8ffcf6502ce614cb4f6ef0e1f70c05f0108ff652dd3cd9e6d0e88904","size":101711},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/implementation.md","sha256":"24a09851c0c9e3c59228a87bfba849d4d349bb435c7b2510fd4ea9830bf3cf29","size":91503},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_operational_handoff.md","sha256":"0e1089d3a50d160d277f95a7bb0cccabf1c78cef513402a5fc857ff0fc908a14","size":119984},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md","sha256":"351ce44cb09d916669eec7d02ec171340d3d52f473cb81140ce76bf2f5bb69e0","size":166995},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md","sha256":"17d6ea3808063559ec9ae63d0c764d6db4c7a9d3bb0f2fe401d1f698daaff208","size":105872},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/system_overview/boundaries.md","sha256":"13ae36c014ffe3407f75a52a464d3988ed4880d00ea9e3a69e4da9626aeb97a8","size":73385},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"a8f3a9760296e4d82bd9c433b1694a7881ac62dfac0b0e3d6d600d0644163227","size":324895},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"fb8c85dbc8165d0d1c1ded6860dd30cbe4fb8819ba2d010be02527c7e1cafb65","size":861955},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/admissionstate/state.go","sha256":"e18a153eb0115085fec9a80b049ddbd44cd2aa59a8410792951c3c392368dc8f","size":12803},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/admissionstate/state_test.go","sha256":"ad9ef898a983d29f697066c2f2c1ed00fc141b0cd853bf7cf270e1a53876f5d8","size":36549},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/operational_admission.go","sha256":"713d629f0e24b65028096390ad04a0985fd4475d44a98937cc04333148d1c3de","size":13288},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/reliablesubmit/operational_admission_test.go","sha256":"6e3f33ee5234fbb35cfde4c4313c59dadb3330198544d9a492b1d70918a80bb5","size":78663},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/operational_handoff.go","sha256":"e38ecdcbe199a7423f93348d5ffe6206b32e414f1b75a8a6dbcc0c976fad9bb3","size":63434},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/operational_handoff_test.go","sha256":"0f666893e5f3164c54839eb9bc90d969f895623c7a4a187c779ac1f652538b8f","size":54589},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/replay_custody_structure.go","sha256":"4adcd21ae2396edddd4c552c9fdd5c53b5d61ab56c718573b0985089e5f16ed7","size":19440},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_operational_handoff_schema.go","sha256":"0414016c73ee268a4a14de340cf57fab132ac7d27737a3df8a606cfe8480e74f","size":38102},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_replay_shape.go","sha256":"710668283d3d8075a43c445bda729f35798fa30ccaf88c6aabaffb5a8afb85e7","size":2878},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_guardrails_test.go","sha256":"bb5833dddb699a25e16bd9dbd49ebe073beeadd19a1b9c5c0e859f9053e4403e","size":111486},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/reliable_submit_operational_admission.go","sha256":"dc1ae7c579cf143cbba334438fb31a167604e0e85dfbf499a411ec807579b3be","size":20272},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/reliable_submit_operational_admission_redteam_test.go","sha256":"97790abce938db98a4535b187d6191e7bbc1f99729404937560837d29a948ffd","size":42569},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/reliable_submit_operational_admission_test.go","sha256":"b32e37191882722c1cccb87b35fb8eda96c2e93dcec64b4f3a0f4e063552a5af","size":201484},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_format.go","sha256":"7a0a2128c9412917a400a05eeae6d3650417584042b87e25f333ec108aa1d2dd","size":10157},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_format_test.go","sha256":"5c3f6fe623b0404e07f116845574f43fa33fa8ba4a33aa9864404db753db3ce7","size":31614},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_handoff.go","sha256":"914d50ce55bdf4c47df4957f8ba2a0f0abfbb8c90f265fd5cb8796ff9a5f69cd","size":27467},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_handoff_test.go","sha256":"5447b5e1bce100c4c78f6c67917fec7e8786d709f29a59c912bf474d99b17257","size":62149},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/resolved_execution_plan.go","sha256":"449dedaaf284bb3798f897b93c42ef282dcebe2c553e7318ffaf7a72e75c7ef0","size":28834},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/service.go","sha256":"6ea048764305478689a8b31bcc5f2b4f2d01ff3acd641a37c0fd485ba5d92877","size":36264},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/workstream_c_guardrails_test.go","sha256":"c37eeb2a47957718a05b4fbebd0c979c3685d31d09f80e8c7de57a9c332cb257","size":509573}],"head":"8058561edc08356c46680c204586b3c7796c0ff3","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"1de154107b2f7c82e048c5dbf92ef942a2f543111eab96022b45ab09918d2b8b","upstream":"origin/codex/reliable-submit-operational-handoff-v1"}
```

Complete canonical manifest, repair-only against `faacf16` (3,669 bytes):

```json
{"branch":"claude/project-thread-sqldt7","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/es_execution_admission_model.md","sha256":"f47a909b8ffcf6502ce614cb4f6ef0e1f70c05f0108ff652dd3cd9e6d0e88904","size":101711},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_operational_handoff.md","sha256":"0e1089d3a50d160d277f95a7bb0cccabf1c78cef513402a5fc857ff0fc908a14","size":119984},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md","sha256":"351ce44cb09d916669eec7d02ec171340d3d52f473cb81140ce76bf2f5bb69e0","size":166995},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"a8f3a9760296e4d82bd9c433b1694a7881ac62dfac0b0e3d6d600d0644163227","size":324895},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"docs_contract_test.go","sha256":"fb8c85dbc8165d0d1c1ded6860dd30cbe4fb8819ba2d010be02527c7e1cafb65","size":861955},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/admissionstate/state.go","sha256":"e18a153eb0115085fec9a80b049ddbd44cd2aa59a8410792951c3c392368dc8f","size":12803},{"file_type":"regular","kind":"untracked","mode":"0644","path":"es/admission/internal/admissionstate/state_test.go","sha256":"ad9ef898a983d29f697066c2f2c1ed00fc141b0cd853bf7cf270e1a53876f5d8","size":36549},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_guardrails_test.go","sha256":"bb5833dddb699a25e16bd9dbd49ebe073beeadd19a1b9c5c0e859f9053e4403e","size":111486},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_admission.go","sha256":"dc1ae7c579cf143cbba334438fb31a167604e0e85dfbf499a411ec807579b3be","size":20272},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_admission_redteam_test.go","sha256":"97790abce938db98a4535b187d6191e7bbc1f99729404937560837d29a948ffd","size":42569},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_admission_test.go","sha256":"b32e37191882722c1cccb87b35fb8eda96c2e93dcec64b4f3a0f4e063552a5af","size":201484},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_format_test.go","sha256":"5c3f6fe623b0404e07f116845574f43fa33fa8ba4a33aa9864404db753db3ce7","size":31614},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_handoff.go","sha256":"914d50ce55bdf4c47df4957f8ba2a0f0abfbb8c90f265fd5cb8796ff9a5f69cd","size":27467},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/reliable_submit_operational_handoff_test.go","sha256":"5447b5e1bce100c4c78f6c67917fec7e8786d709f29a59c912bf474d99b17257","size":62149},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/service.go","sha256":"6ea048764305478689a8b31bcc5f2b4f2d01ff3acd641a37c0fd485ba5d92877","size":36264},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/workstream_c_guardrails_test.go","sha256":"c37eeb2a47957718a05b4fbebd0c979c3685d31d09f80e8c7de57a9c332cb257","size":509573}],"head":"faacf16b9d5cd5ddc28b79da5c6c30f2bca6c124","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"3420d32f13517941796562b519e1ad6a815da52c54d556ecc79c96a4abf34b37","upstream":"origin/claude/project-thread-sqldt7"}
```

## 14. Assumptions, unresolved seams, uninspected areas

**Limits of the package border** (section 4.5): reflection and `unsafe` in a production file; a wrong call of an exported member; an assignment of the handle. Each is held by a source inventory, and a source inventory makes a change visible to review. It does not stop a commit that edits the inventory together with the code (the audit's O4-4).

**Named limits of the guard, as the owner document lists them.** Unchanged from the last report, with two additions from part one:

- An alias or pointer obtained at an inventoried site and used elsewhere. The holder rule of section 4.5 narrows this for the two handle types and does not close it: it reads the declared type of a field, so a view that a listed call hands out and that is then stored in a field of an interface type is not seen.
- The bodies of called functions and methods.
- Reflection inside a called library function on a pointer or container passed as an interface value. Such code can move or overwrite a whole `Service` value. Since the split that can only close the admission state: a handle that is put back names the same state, the zero handle is closed, and the handle of another Service answers only that Service.
- The three build targets.
- SQL statements assembled at run time.
- Code outside the repository: the standard library, the module cache and the toolchain are not read.
- New: build inputs that live outside the tree. The flags `-modfile` and `-overlay` and the environment of the build are not seen by a test in the repository. The guard refuses workspace mode as the go command reports it in the guard's own environment.
- New: the hash pins fix bytes, not meaning. A pinned file can be changed with its pin in one commit.

**Assumptions.**

- The owner given to `New` is a pointer. `New` takes `any` and compares with `==`; a non-pointer owner would be compared by value. The only production caller passes `*Service`, and the call-site list holds that.
- No generated or vendored Go code is meant to live in the module, and no production Go file is meant to live in a `testdata`, dot or underscore directory. Each is read like any other code now; none exists.
- Linux only. Nothing was run on macOS. The guard loads the darwin/arm64 target on Linux.

**Open question for the integration step.** Unchanged: whether a refused first delivery tells its caller "denied" or "unavailable" (`CP-PUBLIC-MAPPING`).

**Not done, and why.**

- No measurement of the cost of the per-evaluation copies (section 4.7).
- No mutants against the code of the docs contract test. Its rules are covered by their own mutation cases, which change the document text and require the rule to fail.
- No test for the three guard mutants that are not caught (section 10.2). I think none can be written for two of them, and the third is equivalent.
- The store's 54 mutants were not run again (section 10.5).
- The auditor's effect tests were not run. They name fields that no longer exist and would not compile; the question for this report is whether the guard tests fail on a probe.

**Uninspected.** Nothing outside the 28 changed paths was read for this repair, except `es/app/app.go` and `go.mod` (to place probes), the two files that import `unsafe`, the module's directory listing, the store's token type, and the audit's evidence folder (as data).

## 15. Confidence

- **Provenance: high.** The manifests were taken twice on the pushed commit, byte-identical; the staged sets equal the manifests' path lists, and the staged trees equal the tree of the commit; the remote branch is at the commit.
- **Validation: high on Linux, not established on macOS.** The full suite, the race detector on both packages with changed production code, 232 behaviour mutants, 161 guard mutants and the audit's probes all ran on the committed bytes, after the push. Of the 232, 228 are caught (172 by a behaviour test, 4 by the compiler, 52 by guard tests only) and 4 survive, each with its reason. Of the 161 guard mutants, 158 are caught. Of the 12 probes, 11 are caught and one has no result in my environment. The full suite has one changed result, a test with a known timing fault in a file this pull request does not touch (section 9); it passes 20 of 20 runs alone. The store's 54 mutants are carried over by argument (section 10.5).
- **No behaviour change: high.** The digest is pinned by five golden values computed with the old function. Every earlier behaviour mutant of `es/admission` runs against the moved code: of the 107 that a behaviour test killed at `faacf16`, 105 are killed again, one no longer compiles and one survives because its check is now made twice (`I1`). No test of the changed packages that exists at both commits changed its result; the one changed result of the suite is the timing test of the root package named above. What I cannot measure is behaviour that no test and no mutant asks about; the one new branch and the doubled token check are named in sections 4.7 and 7.
- **The package border: high for what it claims.** The forms that the three escapes needed are compiled against the real packages under every build target and must be refused by the compiler with the expected message; that is a property of the language and not of my reading of it. The border claims nothing about reflection, `unsafe`, a wrong call of an exported member, or a stored handle (section 4.5).
- **The guard: medium to high.** Four audits found a gap in it, each one step further out, and this repair's own mutants found three more places where a piece of what the guard reads could be removed without a failing test (section 7, item 15). I closed what I found and I do not claim there is nothing left. The difference to the last report is that the state no longer depends on the guard alone: for a bypass that names a field, mirrors a type or copies a value, the compiler refuses first.

## 16. Report delivery

This file: `/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/11-repair.md`. Its SHA-256 is in the thread reply that attaches it. Evidence: `11-repair-evidence/` in the same folder, also as `11-repair-evidence.tar.gz`:

- `README.md`: what every file is, and how to read a result line.
- `final-pass/`: every run on the committed bytes. The three stages of the behaviour mutants (`beh_*.out`, `second_*.out`, `third_whole_package.out`), the 32 guard-rule mutants (`guardrules_light.out`), the guard mutants (`guard_fast_*.tsv`, `guard_full_*.tsv`, `anchors.txt`), the probes (`r4-probes.txt`, and the superseded first run `r4-probes.first-run.txt`), the twenty runs of the one timing test (`flake-rerun.txt`), the outputs of the build, the vet run and the format check, the exit codes, the commit and status before and after, and two tables with one line per mutant (`behaviour-mutants.tsv`, `guard-mutants.tsv`). `summary.json` is what the tables of this report were built from.
- `first-pass/`: the runs on earlier bytes that showed which mutants survived first.
- `full-suite-compare.tsv`: every test result of the full suite at `faacf16` and at `bff8dda`, by package and name. `race-summary.txt`: the race detector run.
- `manifests/`: the two canonical manifests, the recipe's output for each, and the staged path lists.
- `changed-files-faacf16-to-bff8dda.numstat.txt`, `commits-faacf16-to-bff8dda.txt`.
- `golden-digests-at-faacf16.txt`, `golden-digests-temporary-test.go.txt`: the five digests computed with the old function, and the temporary test that printed them (never committed).
- `store-test-linux-overlay.patch`: the one-file overlay the store tests need to compile on Linux.
- `specs/`: every mutant as text, the id lists the runs were started with, and the notes of section 10.1.
- `scripts/`: the runners and the scripts that built this report, as text files. They name scratch paths of the writer's container.

The full JSON output of the test runs is not in the folder; the comparison table and the summaries are.

## 17. Effect status

`TOPIC_BRANCH_PUSHED` (`claude/project-thread-sqldt7` at `bff8dda37dbf5484afb3b264d4eca38cf6abf118`) | `DRAFT_PR_OPENED` https://github.com/evo-agi/Execution-Substrate/pull/13 (existing draft, description updated) | `MERGE_NOT_PERFORMED` | `INDEPENDENT_AUDIT_NOT_PERFORMED`

No push to any other branch. No force-push. No comment or review posted. PR #12, PR #14 and the closed PR #15 were not touched.

STATUS: READY
