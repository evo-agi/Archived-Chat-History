# Evidence for `31-redteam-recheck.md`

Red-team re-check of the PR #12 repair round: Execution-Substrate draft PR #40 at `fd399a12b5fc8319d403de471bb3ce42446f350c`, and at `75d0f5c1c858365bf1f68e7e3887405665f0e29f` where noted, 2026-11-23. Everything here was produced in a cloud container by the unprivileged user `ci` with Go 1.26.5. Nothing here was committed or pushed anywhere. `SHA256SUMS` covers every file of this folder except itself.

The patch for the writer is next to the report, not in this folder: `31-redteam-recheck-finding-tests.patch`.

## head/

| File | What it shows |
| --- | --- |
| `adopted-tests.txt` | The five test files of the pass-28 patches are in `fd399a1` byte for byte. |
| `ls-remote-2319Z.txt`, `ls-remote-close.txt` | PR #40, PR #12 and `trunk_dev` on GitHub at 23:19 UTC and at the end of the pass. |
| `new-head.txt` | PR #40 moved to `75d0f5c` during the pass: two commits, three test files, no product file. The patch applies there. |
| `trunk-dev.txt` | `trunk_dev` went from `400ff7f` to `0aa4a2b` and to `725c97a`; test files only; trial merges are clean. |

## tests/

The new test file as text (`.go.txt`), identical to what the patch adds.

## candidates/

`candidate-fix-RC31.diff`: thirteen added lines that exist only to show that the 18 subtests pass once both defects are gone. Not proposed code.

## mutants/

`RM40-1.diff` (the size check measures one byte short) and `RM40-2.diff` (the string rule skips the last argument).

## logs/

| File | Run |
| --- | --- |
| `head-targeted.log`, `.exit` | My two pass-28 finding tests, the writer's seven new tests and the root contract test at `fd399a1`: all pass |
| `zz-all-3.log` | The ten scratch tests of `scratch/` at `fd399a1` |
| `finding-head.log` | The delivered finding tests at `fd399a1`: 18 of 18 subtests fail |
| `finding-candidate.log` | The same with the candidate: 18 of 18 pass |
| `RM40-1.log`, `RM40-2.log`, `.exit` | The two mutants at `fd399a1` |
| `base-admission-all.json.gz`, `base-root.json.gz`, `.exit` | Clean `fd399a1`: `go test -count=1 -json ./es/admission/...` and `go test -count=1 -json .` |
| `final-admission-all.json.gz`, `final-root.json.gz`, `.exit`, `final-vet.*`, `final-gofmt.*` | `fd399a1` plus the finding file as delivered, same commands, with `go vet` and `gofmt -l` (both empty) |
| `newhead-targeted.log`, `newhead-finding.log`, `newhead-RM40-1.log`, `.exit` | At `75d0f5c`: the targeted tests pass, the finding tests fail 18 of 18, mutant RM40-1 is caught by the corrected bound test |
| `newhead-admission-all.json.gz`, `.exit`, `newhead-vet.*`, `newhead-gofmt.*` | `75d0f5c` plus the finding file: the full `es/admission` suite, `go vet`, `gofmt -l` |
| `suite-compare.txt` | The failing tests of each full run side by side |
| `nfc-ascii.txt` | Which code points Normalization Form C turns into ASCII (three), and that none yields `$`, `%`, `{` or NUL |
| `earlier/` | Earlier runs kept for the record and not relied on: the first two versions of each scratch test, and the full suite with the first version of the finding file (`rc40f-*`) |

## scratch/

The two scratch test files behind `zz-all-3.log`, as text, and `receiver-refuse500.diff`, the receiver mode that answers a registration with status 500 and exists only in the scratch clone.

## scripts/

The helper scripts as text. `cirun.sh` runs a command as the unprivileged user with an emptied environment; `sync.sh` makes a scratch clone at a commit and checks its tree; `summ.py` counts results of a `go test -json` file; `full40.sh`, `final40.sh` and `newhead40.sh` are the batch runs; `compare40.py` made `logs/suite-compare.txt`; `nfc_ascii.py` made `logs/nfc-ascii.txt`; `scan.py` is the secret-shape scan of section 11 of the report.

## reference-sources.txt

The public source files of Nomad, HCL, cty, go-msgpack and x/text that the report cites, each with its URL, SHA-256 and the lines cited. They are not copied here. None of that code was run.

## Scan of this folder

`scripts/scan.py` over the 66 files of this folder (before `SHA256SUMS` was written), the patch and the report: no private key, GitHub, Anthropic, OpenAI or AWS key shape, no JWT, no e-mail address, no phone number. 54 hits of the Vault-token shape, 18 in each of `logs/base-root.json.gz`, `logs/final-root.json.gz` and `logs/earlier/rc40f-root.json.gz`: a placeholder made of the letters a to z after the prefix, in the names of subtests of two repository tests of the root package. One certificate-header hit and four model-name hits are the patterns in `scripts/scan.py.txt` itself.

A second pass over the folder counted: LAN addresses of the form 192.168.x.y, 0; paths under `/Users/`, 0; session links, 0.
