# INDEPENDENT AUDIT REPORT: fourth repair of PR #13 (the guard reads every compiled package; the admission state has its own package)

Fresh, read-only audit. Audit thread: "Audit PR 13 package split". Date: 2026-11-23. I am not the writer of the audited bytes.

Verdict: **ACCEPT** (section 15). One low finding with a correction that is carried to the next required change of PR #12's branch (A5-1), and observations. Nothing blocks.

## 1. In plain words

1. **The bytes are the ones the writer reported.** I rebuilt both of the writer's manifests from the pushed branch and they are identical byte for byte, at the start and at the end of this audit.
2. **The split does what it was built for.** The admission state (the installed view, the two latches that stop admission, and the time of the last confirmation) now lives in one small package. Outside that package the forms that earlier audits used to reopen admission no longer compile. I wrote 11 further forms of my own and gave them to the real compiler for Linux and for macOS: all 11 are refused, and 3 controls compile. The writer's 23 forms run in the suite and pass.
3. **Behaviour is unchanged.** I read the four changed production files line by line against the old code and found no change of behaviour. The digest that names admission content gives the same bytes as before: I ran the old function at `faacf16` on the five inputs that the new package pins, and got the five pinned values.
4. **What the compiler does not hold, the guard holds, as far as I could measure.** A call of the state package at a new place, a fresh state for the same Service, and a view kept in a new struct each compile, and each fails a guard test (section 7.1).
5. **One road is held by neither, and the documents do not name it (finding A5-1, low, not blocking).** A program can write its own memory through the operating system. A production function that does so cleared the withdrawal latch in my probe, and the withdrawn Service admitted again. It needs no `reflect`, `unsafe` or cgo import, and with it in place the whole suite gives the same results as without it, apart from one known timing test that it cannot touch. This is not new with this repair, it was possible at every earlier tip, and no source guard can hold it in general. What is missing is one sentence in the list of limits. I ask for it before PR #12's merge gate, not before this pull request moves on.
6. **The other points of the brief.** The doubled token check (survivor I1) is harmless defence in depth. The three guard mutants that no test catches are what the writer says they are. All failing tests are environment failures that were known before. Commit `3f65592` fails one test when it stands alone, as the writer reported. The scope is 28 paths. No CI ran on this branch and nothing ran on a Mac.
7. **For the merge gate** (section 7.7): squash, so that the one red commit never stands alone; two lines for the CI list when PR #12 picks up `trunk_dev` (one of them was not recorded before); the first CI run and a Mac run are still to come.

## 2. Audit target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Pull request | #13, open, draft, head branch `claude/project-thread-sqldt7`, base branch `codex/reliable-submit-operational-handoff-v1` (the head branch of PR #12). GitHub reports head `bff8dda`, base `8058561`, 28 changed files, 15 commits, mergeable state "clean", and no check run (read at the end of the audit) |
| Base commit (PR #12's head) | `8058561edc08356c46680c204586b3c7796c0ff3` |
| Last audited tip (third repair) | `faacf16b9d5cd5ddc28b79da5c6c30f2bca6c124` |
| Audited commit | `bff8dda37dbf5484afb3b264d4eca38cf6abf118` (2026-11-23T01:53:46Z), seven commits after `faacf16`, 15 after the base |
| Tree | `38269372c5bc21f291e1b73e93cf48d78180649d` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source `/mnt/project-files/claude-conversion/tools/governed_execution_audit_patch_manifest_v2.py`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (checked before every run) |
| Base-relative manifest | SHA-256 `4ccb1a24c05c0baec014b3f295975bb60ae7bae00437752b12f3865767bd1616`, 6,291 bytes, 28 paths, textual diff `1de154107b2f7c82e048c5dbf92ef942a2f543111eab96022b45ab09918d2b8b` |
| Repair-only manifest (against `faacf16`) | SHA-256 `f036029d5399627a95b963b59b910aec1db4e8828a055062b205fe1abbe41f6b`, 3,669 bytes, 16 paths, textual diff `3420d32f13517941796562b519e1ad6a815da52c54d556ecc79c96a4abf34b37` |
| Size of the repair | 16 files, 4,479 lines added, 602 removed. Production code: 4 files, all in commit `1182b9f` |
| Writer report | `/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/11-repair.md`, SHA-256 `78bf92c87b913df204679001ba2d0634ecf5466db1dd2f36dff025d250bc9568` (matches the brief) |
| Writer evidence | `11-repair-evidence.tar.gz`, SHA-256 `f6902fdd37216776e439f66f973c3e2529aa44cb5cf61387af6a506aa07b49f8`, 154 files |
| Remote state at the end of the audit | head branch `bff8dda`, base branch `8058561`, `trunk_dev` `bc9fe3619823245faf550db4bf1bc3e782fbd5a5` (`git ls-remote`) |

What this audit read in full is the delta `faacf16..bff8dda`. The eight earlier commits of PR #13 (`8058561..faacf16`) were judged by the earlier audits (`04` to `10`); I did not read their diffs again. The whole of the 28 paths is covered by the provenance check and by the full suite on the tip.

## 3. Audit posture

- Read-only. One thread, no subagents.
- The working copy `/home/user/Execution-Substrate` was never edited. Every build, test and probe ran in throwaway clones under `/opt/ci/work/` (`tip`, `merge`, `p`), as the unprivileged user `ci` with an emptied environment, Go 1.26.5, linux/amd64, 4 CPUs.
- Mutants and probe files existed only in those clones. Nothing was committed there. The trial merge of `trunk_dev` in the clone `merge` was never committed: the clone holds `MERGE_HEAD` and a staged tree.
- Nothing was pushed, no comment was posted, no pull request was opened or changed, nothing was merged. The development branch assigned to this thread does not exist on the remote.
- The brief says "no red-team work here". I kept to that with one exception that I name: to answer what is held by neither the compiler nor the guard, I wrote one hostile production function in two forms (section 6.2, A5-1). It is two files and three runs.

## 4. Provenance reproduction

Commands: `/opt/audit/scripts/prov.sh` (evidence `scripts/prov.sh.txt`). For each manifest it checks the recipe's hash, resets `HEAD` to the manifest's base with `--mixed`, pins the upstream, runs the recipe twice with `python3 -I`, compares the two outputs with `cmp`, and afterwards restores `HEAD`, the upstream and a clean status. Checkout under `umask 022`.

| Manifest | `HEAD` at | Upstream | Result |
| --- | --- | --- | --- |
| Base-relative | `8058561` | `origin/codex/reliable-submit-operational-handoff-v1` | `4ccb1a24…1616`, 28 paths. Two runs identical. Equal to the writer's. |
| Repair-only | `faacf16` | `origin/claude/project-thread-sqldt7` | `f036029d…1f6b`, 16 paths. Two runs identical. Equal to the writer's. |
| Trunk-relative (mine, extra) | `ae326b0` (merge base with `trunk_dev`) | `origin/trunk_dev` | `2f770674b0095a814852b3a76499c77766228f897ccb7482f64e0477212cc788`, 10,578 bytes, 48 paths. Two runs identical. |

- **Upstream pin.** The brief says to re-pin the upstream to `origin/trunk_dev`. The manifest records its upstream, and the writer's two manifests record the two upstreams above. A byte-identical reproduction needs the same pin, so I used the writer's for the two reproductions and added the third manifest with `origin/trunk_dev`. Its 48 paths equal the ceiling the owner document names for PR #12 with its repairs.
- **Opening and closing.** Opening manifests at 05:48Z, closing at the end of the work (container clock). All three closing manifests are byte-identical to the opening ones (`cmp`). The working copy was clean at `bff8dda` with its upstream restored both times.
- **Mode bits.** No difference to tolerate.
- **Ancestry.** `8058561` and `faacf16` are ancestors of `bff8dda`. The pushed tip equals the reported tip at the start and at the end.

## 5. Coverage

| Area | What I covered |
| --- | --- |
| Governing documents | The operating protocol and the provenance guide (whole). The writer report `11-repair.md` (whole). The prior audit `10-audit.md` (findings, required corrections, remaining bypass shapes). The design `04-design-proper-admission.md` (searched, not re-read in full). |
| Production source | `es/admission/internal/admissionstate/state.go` (whole, 388 lines). The diffs of `service.go`, `reliable_submit_operational_admission.go` and `reliable_submit_operational_handoff.go` (whole), each against the code it replaces. `es/admission/policy.go` and the store's `operational_admission.go` (the parts the mapping and the token rest on). |
| Tests and guard | The diffs of both guard files (2,197 diff lines, read). `state_test.go` (first 135 lines and the list of tests). The diffs of the admission, red-team, format and handoff tests, with every removed line checked for a successor. |
| Documents of the repository | The repair's changes to the owner document `.docs/execution_lifecycle/reliable_submit_operational_handoff.md` and its sections on the package and on the limits (:500-800), the two smaller documents, both `PLANS.md` entries, and the diff of `docs_contract_test.go`. |
| Validation evidence of the writer | Read through the report. Spot-checked by my own runs (section 8), not by reading the 154 evidence files. |
| Schemas, migrations | None changed by this repair. The store package is unchanged since `faacf16` (`git diff --stat faacf16..bff8dda -- es/admission/internal/reliablesubmit/` is empty). |
| Scripts, CI configuration | None in this pull request. I read `trunk_dev`'s `.github/ci/environment-only-tests.txt` and the rules in `go_test_gate.py` for section 7.7. |
| Not inspected | The eight earlier commits of PR #13 (see section 2). The writer's mutant runs, except the five I repeated. The store's 54 mutants. Anything on macOS or on the GitHub runner. The cost of the per-evaluation copies. Lines 136 to 835 of `state_test.go` beyond its test list. |

## 6. Findings

### 6.1 Summary

| ID | Severity | Type | In one line |
| --- | --- | --- | --- |
| A5-1 | low, not blocking | documents; a road that neither the compiler nor the guard holds is not named. The road is pre-existing | A write to the process's own memory through the operating system reopens a withdrawn admission state. No pinned import is needed, and the whole suite gives the same results with the hostile function in place. The owner document's list of limits does not name it. |

No finding of severity medium or higher. No patch defect in production code. Observations are in section 6.4.

### 6.2 The finding

```text
AUDIT FINDING
ID / Type / Severity: A5-1 / documents: residual road not named in the limits / low, not blocking

Current contract or strategic target:
  Owner document, "Admission state package" and "Typed inventories and guard limits":
  what the compiler refuses outside the package, what "remains possible" there, and
  the "limits that remain, by name". Design goal of the split: no code outside the
  package can change the admission state except through calls that the guard lists.

Path and line:
  .docs/execution_lifecycle/reliable_submit_operational_handoff.md
    :557-558  "Two things remain possible outside the package, and the guard below
               holds both by exact inventories."            (added by this repair)
    :571-574  "The package boundary does not hold against reflection or `unsafe`.
               ... Those roads stay with the import inventory below." (added)
    :742-747  "Limits that remain, by name: ... reflection; `unsafe`; and cgo."
    :753-755  "The import names which files can write storage past the typed
               inventories ..."                              (added)
    :783-785  "The maintained guarantee is exact syntactic occurrence, function site
               and access kind, not a general proof of aliases or runtime safety."
  PLANS.md:31-38 repeats the first two statements.

Evidence (all measured at bff8dda, linux/amd64):
  1. A production function zzAuditReopen(s *Service) in package admission. It formats
     the Service with fmt, reads the address of the state out of the text, opens
     /proc/self/mem and writes two zero bytes at the offset of the two latches. It
     imports fmt, strconv, strings and os (first form) or syscall (second form). It
     names no protected field, no handle field, nothing of the state package.
     Sources: probes-src/os/ and probes-src/os2/.
  2. Effect (probes/os-effect.txt, probes/os2-effect.txt): a fixture Service is
     confirmed and then withdrawn. Before the call: withdrawn=true, the view is not
     current. After the call: withdrawn=false, currentOperationalAdmission answers
     true. Both forms.
  3. Guard, first form (os.OpenFile): every test of es/admission. One test fails,
     TestAdmissionProductionHasOneResolverAndOneMaterializationPath, because
     es/admission has an exact list of os.OpenFile references for its file-creation
     rules. That list exists for another purpose and happens to see this call.
  4. Guard, second form (syscall.Open, syscall.Pwrite): the whole suite of the
     repository with only the production file added, on the same clone as the
     baseline run. 6,786 results. The only difference to the baseline is the known
     timing test of the TLS status fixture and its subtest "term" (section 7.4),
     which this file cannot touch. es/admission: 2,207 pass, 1 skip, 0 fail, as
     without the file. go vet reports nothing new. The file also builds for
     darwin/arm64 (where /proc does not exist, so it would only fail at run time).
     Tables: probes/os2-full.results.tsv, lists/tip-vs-probe-run.diff.

Impact:
  None on shipped behaviour: the handoff has no production caller, and nobody writes
  such a function by accident. The impact is on what a reader concludes from the
  documents. Read as a complete list, they say that outside the package only calls,
  the handle assignment, reflection, unsafe and cgo remain, and that each has an
  inventory. One more road remains and has none. A later design step could rely on
  the border for something it cannot give, for example for code of lower trust in
  the same process.

Required correction:
  C1 in section 9: name the limit in the owner document, pinned by the docs contract
  test like its neighbours. No guard rule is asked for (see Uncertainty).
  Not required before PR #13 moves on. Required before PR #12's merge gate.

Uncertainty:
  - No source inventory can hold this road in general: the path can be put together
    at run time, and the operating system offers other ways (process_vm_writev, a raw
    mmap over the page, ptrace from a child). Inference, not measured: the same holds
    for a data race that breaks Go's memory safety and for code loaded at run time.
    An operating-system control would be the place to hold it; I did not examine one.
  - Whether a sentence is "untrue" or "incomplete" is a matter of reading. I read the
    list as incomplete and no sentence as false, because the closing sentence at
    :783-785 excludes runtime safety in general.
  - Not run on macOS or linux/arm64. The offsets in the probe are those of linux/amd64.

Patch defect or pre-existing issue:
  The road is pre-existing. Inference from the old code, not run at an earlier tip:
  the same write would have cleared Service.operationalWithdrawn there. The repair
  neither opens nor widens it. Three of the
  sentences that read as complete were added by this repair.
```

**Why it does not block.** (1) Nothing the bytes do is wrong, and no machine control that could exist is missing. (2) No statement is shown false; a list is incomplete. (3) The road is older than the repair. (4) PR #12's branch needs another change anyway before it can merge (section 7.7), and that change gets its own audit, so the sentence has a fixed place to land. If the coordinator reads the project rule against "accept now, revisit later" as covering a missing sentence too, the alternative is a documents-only repair on this branch before the red-team pass. That is a process choice. The bytes are sound either way.

### 6.3 Pre-existing issues

None raised beyond the road of A5-1. Two known items that this pull request does not touch showed in my runs, as in the writer's: the `go vet` report at `es/admission/result_auth_test.go:395:15` (copied lock; gone on the trial merge, where `trunk_dev`'s version of the file applies), and the store tests that compile on Linux only with the one-file overlay (fixed on `trunk_dev` by PR #14).

### 6.4 Observations

| ID | Observation |
| --- | --- |
| O5-1 | `state.go:153-160`. The comment says "A nil owner gets the closed zero handle". `New` tests `owner == nil`, which is true only for an interface without a value. `New((*Service)(nil))` makes a real state owned by a nil pointer. No effect: the one production call passes a fresh pointer, and a method on a nil `*Service` dereferences it before it reaches the state. By reading, not run. |
| O5-2 | `state.go:162-167`. `held` compares two interface values with `!=`. An owner of a type that cannot be compared would panic at run time. The one construction site passes `*Service`, and the guard lists that site. The writer names the assumption. By reading. |
| O5-3 | The owner document says the forms that must not compile are held "by compiling each form" (:538-540). The self-test type-checks them with the standard library's type checker (`go/types`), not with the compiler. The two follow the same language rules; my 14 forms went through the compiler itself and agree. Wording only. |
| O5-4 | With the token check inside `Install` removed, the tests of the state package still pass (70 of 70). Six subtests of `TestOperationalAdmissionState` in `es/admission` fail, and so does the hash pin. So the rule is tested where a real token exists; only the store can make one. Not a gap. |
| O5-5 | `11-repair.md:375` says of the known failures "None is in a file this pull request touches". `TestOperationalHandoffSchema4BinaryRefusesSchema5` is in `es/admission/internal/reliablesubmit/operational_handoff_test.go`, one of the 28 paths. The test itself came with PR #12 and is not changed by PR #13, and this repair does not touch the file. The conclusion stands; the sentence is imprecise. |
| O5-6 | The timing test `TestRemoteAlphaESServiceTLSStatusCombinedGroupSignalFailureLiveDescendant` (subtest `term`) passed in my first full run of the tip and failed in my second, with the two messages the writer quotes. One of two for me, one of one for the writer. It is fixed on `trunk_dev` (`110d377`). |
| O5-7 | `Install` computes the digest again under `Service.mu`, and every evaluation rebuilds the policy set from copies of the view. Both are deliberate and safe. The writer did not measure the cost and neither did I. It is a point for the step that gives the handoff a production caller, not for this one. |
| O5-8 | As in the last audit (its O4-4): the guard is tests in the same repository. It makes a bypass a visible, reviewed change. A change that edits an inventory together with the code is held by review and by the required check on the target branch. |

## 7. What the brief asked me to judge

### 7.1 Does the type-level split close the class, and what remains guard-held?

**It closes the class.** The earlier findings (RT-1, A2-1, A3-1, A4-1) were each a form of Go source that changed the protected state and that the guard did not see, one step further out each time. For the state itself that question no longer goes to the guard. The fields, the two struct types and their values cannot be named, converted, copied or overwritten outside one file of 388 lines, and that file is pinned by its hash (`e18a153eb0115085fec9a80b049ddbd44cd2aa59a8410792951c3c392368dc8f`, confirmed).

| Road | Held by | How I know |
| --- | --- | --- |
| A field of the state or of a view; the two struct types by name; a handle literal with a pointer; a same-shape "mirror" type; a copy, overwrite or restore of the whole state | The compiler | 11 forms of my own, `go build` for linux/amd64 and darwin/arm64, all refused; 3 controls compile (`probes/compile-*.txt`). They add to the writer's 23: a structural constraint on a type parameter, a conversion through a generic result, an embedded handle's unexported method, a mirror with a blank field, arrays and slices of handles converted, an interface with the unexported method, a `Status` literal with a chosen view, a dereference through a type parameter. |
| A store token made outside the store | The compiler | Two of the 11: a mirror conversion and a literal with fields. |
| A call of an exported member at a new place | The guard only: exact call-site lists, closed export list | Measured: a new function that calls `Commissioned` fails two guard tests (`g1`). |
| A new state for the same Service, which like a restart has forgotten the latches | The guard only: the one listed assignment of `Service.operational`, the one listed call of `New` | Measured: fails the same two guard tests (`g2`). A generic function that overwrites the handle with the zero handle fails the field inventory (`c3`). |
| A handle kept somewhere else | The guard only: every field whose type holds a handle needs an inventory | Measured: a new struct with a view field fails ("has no inventory", `g3`). By reading: the rule goes by the field's type, so a handle put into an interface-typed field is not seen by it. That falls under the first named limit (a value obtained at a listed site), and using such a handle later still needs a call that the call-site lists refuse at a new place. |
| `reflect`, `unsafe`, cgo, `go:linkname`, assembly, object files | The guard only: import inventory with content hashes, file-set check, module-wide | By reading. Not probed again; the last audit probed them, and the writer's mutants `G4-` and `G5-` cover the new rules. |
| The arguments and bodies of the listed calls, for example a confirmation that asked nobody | Review and behaviour tests | Named limit. |
| A build with other inputs than the repository (`-modfile`, `-overlay`, another toolchain) | Nothing in the repository | Named limit. |
| A write to the process's own memory through the operating system | Nothing | A5-1, measured. |

The redundancy table of the writer's section 4.6 is right: for the two struct types the whole-value, mirror and type-parameter rules are implied by the compiler outside the package, and the field inventories inside the package repeat the hash. Keeping them is sound; they are the same code that reads the other owning types.

**Behaviour.** Install, withdraw, confirm, the currency check and `Initialize` do what they did. The lock order is `Service.mu`, then the state's lock, never the reverse, and the state calls no caller's function under its lock. The clock is read after the lock is released in the old code and in the new. A copy of a Service is now refused earlier (it does not own the state), which is stricter. The round trip between the built-in policy set and plain content is exact for the two built-in policies, and a content the mapping does not know answers `OperationalUnavailable`. The test seam `stricter` is evaluated after the built-in set and can only refuse.

### 7.2 Survivor I1 (the token check at install is made twice)

Harmless, and I would keep it.

| Mutant | Run | Result |
| --- | --- | --- |
| Caller's check removed (I1) | every test of `es/admission` and of the state package | 2,277 pass, 1 skip, 0 fail. Survives. |
| Check inside `Install` removed, caller's kept | operational, PR12 and red-team tests, and the state package | 7 failing leaf tests: six subtests of `TestOperationalAdmissionState/what the token does not name is refused` and the hash pin. |
| Both removed | the same | 8 failing leaf tests: the seven above and `TestOperationalAdmissionCommissioning/.../the store returns a token for other content`. |

Both checks compare the same token with the digest of the same content, so removing the outer one changes no result. The inner one is the rule of the package and is tested. The outer one refuses before the Service lock is taken.

### 7.3 The three guard mutants that no test catches

I agree with the writer on all three.

- `G5-PIN-NOT-RUN` is equivalent. Measured: with the mutant alone the pin test passes, and with one byte added to `state.go` it fails in the test's own controls ("state.go changed").
- `G5-PROBE-UNJUDGED` and `G5-SCOPE-NO-CMD` change the last assertion of a test, or the argument of a check at its one call on the real tree. A test of that assertion would have a last assertion of its own. I read both places: the judgement is there (`workstream_c_guardrails_test.go:3293`, with seven controls that must compile), and my compiler probes confirm its result independently.

### 7.4 Full-suite failures

On the exact bytes, in a git clone, alone on the machine, 385 s: `go build ./...` exit 0; `gofmt -l` on the changed Go files prints nothing; `go test -count=1 ./...`: 6,786 results, 6,703 pass, 42 fail, 41 skip.

- All 42 failing results are within the writer's 166 names. The writer ran a copy without `.git` (168 failures); a clone gives 42, as the last audit found. None is new.
- They are 12 top-level tests: nine Remote Alpha operator-script tests of the root package and three store tests that need a probe binary through the environment (`lists/tip-failing-top-level.tsv`).
- `es/admission`: 2,207 pass, 1 skip. The state package: 70 pass.
- The TLS status timing test passed in this run and failed in my second full run (O5-6). Its file is byte-identical to the base.
- The 41 skips are the writer's 41.

### 7.5 Commit `3f65592` alone fails a test

Confirmed: at `3f65592` the build passes and `TestExecutionSubstrateProductionHasNoA3LeaseRegistryOrPoisonDesign` fails; at `1182b9f` it passes. Only `1182b9f` changes production files; the five commits after it change tests and documents only (checked per commit). This is history hygiene, not a defect of the tip. The repository merges by squash, and PR #13 should too, so that the red commit never stands alone on a branch that others build from.

### 7.6 Scope, CI, macOS

- **Scope.** 28 paths against the base (11 production Go files, 10 test files, 6 documents and `PLANS.md`), 16 of them in this repair, two new. No path outside `es/admission`, the documents and the docs contract test. 48 paths against `trunk_dev`'s merge base, which is the ceiling the owner document names.
- **CI.** None ran, and none can on this branch: the base branch holds no workflow file. The first CI run of this code will be PR #12's after it picks up `trunk_dev`.
- **macOS.** Nothing ran on a Mac. I cross-built the tip for darwin/arm64 (`go build ./...` exit 0, `go vet` with the same single known report) and the compile probes were refused for that target too. Unknown: how the guard's directory walk and path checks behave on a Mac, where `/var` is a symbolic link. The guard fails closed by design, so a difference would show as a red test, not as a silent pass. That is an inference until it is run.

### 7.7 What the merge gate will need

Measured on a trial merge of `trunk_dev` `bc9fe36` into `bff8dda` (clone only, never committed): the merge is textually clean (7 files merged automatically), tree `eec14cb271a8986fd6e04a6910ee99ffc0b7c3d7`, `go build ./...` and `go vet ./...` exit 0, suite 6,823 results with 6,729 pass, 41 fail, 53 skip, `es/admission` 2,220 pass and 13 skip, the guards pass, and no test that passes at the tip fails on the merge.

1. PR #13's head must still be `bff8dda` (tree `38269372…`).
2. David's go for a product-code change. Whether a merge into PR #12's branch counts as one of his three product reviews, or only PR #12's own merge into `trunk_dev` does, is the coordinator's reading.
3. Squash-merge into PR #12's branch. The base branch still stands at PR #13's merge base, so the squash must give exactly the tree `38269372…`; check it after the merge.
4. The red-team pass on the combined PR #12, with the road of A5-1 handed over as a known target, so that it is not found a second time at full cost.
5. C1 (the sentence for A5-1) on PR #12's branch before its merge gate.
6. PR #12 picks up `trunk_dev`. That makes new bytes: new manifests and an audit of the delta (provenance guide 5.4 and 5.5).
7. **Two lines in `.github/ci/environment-only-tests.txt`** with that step. The gate fails without them:
   - an entry: `execution-substrate/es/admission/internal/reliablesubmit TestOperationalHandoffSchema4BinaryRefusesSchema5` (it fails without the environment variable `ES_REPLAY_SCHEMA4_PROBE`; already on the coordinator's list);
   - `skips-itself execution-substrate/es/admission TestOperationalHandoffChildProcess` (it skips itself unless another test starts it; the gate fails on a test that skips itself and is not listed). I did not find this one recorded before.
   Both follow from the tests' own code. What else the runner shows is unknown until CI runs: this container is not the runner.
8. The required check "build, vet and test" green on an up-to-date branch.
9. A Mac run, compared with `trunk_dev`'s own Mac result, because `es/admission` is already red on macOS without this change.
10. After the merge: the merged bytes equal the audited ones.

## 8. Validation assessment

### 8.1 What I ran, on which bytes

| Run | Bytes | Result |
| --- | --- | --- |
| Provenance, opening and closing | `bff8dda` | Section 4 |
| Build, vet, gofmt, full suite | clone of `bff8dda` with the store-test overlay | Section 7.4. `go vet` of the writer's four packages: the one known report |
| Trial merge of `trunk_dev` `bc9fe36`: build, vet, full suite | merged tree `eec14cb…` | Section 7.7 |
| Compile probes: 11 forms and 3 controls, two targets | `bff8dda` plus one file each | All as expected |
| Cross-build and vet for darwin/arm64 | `bff8dda` | Build exit 0; vet: the one known report |
| Guard-held forms `g1`, `g2`, `g3`, each against every test of `es/admission`; control `c3` against ten guard tests | `bff8dda` plus one file each | Each caught (section 7.1) |
| Process-memory probe: effect (two forms), `es/admission` (first form), whole suite (second form) | `bff8dda` plus one or two files | A5-1 |
| I1 and its two neighbours | `bff8dda` with one or two lines changed | Section 7.2 |
| `G5-PIN-NOT-RUN`, alone and with a changed `state.go` | `bff8dda` with the mutant | Section 7.3 |
| Commits `3f65592` and `1182b9f`, the one test | those commits | Section 7.5 |
| Golden digests with the old function | `faacf16` plus one test file | Five of five equal to `state_test.go:15-20` |
| Race detector: the state package (70 results) and the operational, PR12 and red-team tests of `es/admission` (400 results, 817 s) | `bff8dda` | All pass, no data race reported |

### 8.2 What I did not run

- The writer's 232 behaviour mutants and 169 guard mutants, except the five above. I rely on the writer's report for the rest.
- The race detector on all of `es/admission`. The writer reports a clean full run (1,589 s). Mine covers the tests that use the state.
- Anything on macOS, on linux/arm64 or on the GitHub runner.
- The store's 54 mutants (the store is unchanged since `faacf16`).
- `go vet ./...` on the tip for the whole module (I ran the writer's four packages; the whole module on the trial merge is clean).

### 8.3 Limits of what I ran

- One container, 4 CPUs. Its clock ran slower than real time between commands (inference from uptime), so the times in the logs are the container's.
- My first probe batch stopped at the intermediate commits because of an error in my own reset order, and two mutants of mine did not compile as first written. I corrected both and ran them again (`probes2.log`). No committed byte was involved.
- The overlay left an untracked `.orig` file in the clone `tip`. It is not a Go file and was present in the baseline run and in the comparison run alike.

### 8.4 Evidence files

`/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/12-audit-evidence/` with a `SHA256SUMS`: `manifests/` (opening and closing), `scripts/` (every script as `.txt`), `probes-src/` (every probe source as `.txt`), `full/` and `merge/` (logs and result tables), `probes/` (logs, per-run summaries, result tables, the failure text of each catching test), `race/`, `lists/` (failing and skipping tests against `trunk_dev`'s list). The raw `go test -json` streams are not delivered: they are large, and I did not screen every log line in them.

## 9. Corrections

**Blocking: none.**

**Carried, to land on PR #12's branch before its merge gate**

- **C1 (A5-1).** Name the limit in the owner document, next to the sentence on reflection and `unsafe` (:571-574) and in the list of limits (:742-760), and hold the phrase in `docs_contract_test.go` like its neighbours. Suggested content, wording is the writer's: the package border and the inventories read Go source; they do not hold against code that writes the memory of its own process without the language, through the operating system, through a data race or through code loaded at run time; no import names such code and no inventory reads it; every production file of the module and every dependency is therefore inside the trust boundary of the admission state. Adjust the `PLANS.md` entry if it is to stay a complete list.

**Optional, cheap, with the same change**

- O5-1: say "an untyped nil owner" in the comment, or test the pointer.
- O5-3: say "type-checking" where the document says "compiling", or keep the word and add that the standard library's type checker is used.

No production code needs to change.

## 10. Sensitive-material handling

I read no security directory, environment file, database of a live system, key or credential. The tests use generated fixture keys. The delivered evidence holds scripts, probe sources, logs of my own runs and tables of test names; I searched it for key material, passwords, tokens, e-mail addresses and phone numbers and found only test names that contain such words. No personal data is in the report.

## 11. Remaining uncertainty and stop conditions

- A source guard cannot be proven complete. Four earlier reviews each found a form it missed. This audit found none among forms written in Go, in the time it had, and the question no longer decides the safety of the state's own fields. It still decides the call sites and the handle.
- A5-1 shows that the border is a border of the language, not of the process. Anything that later relies on it against code of lower trust in the same process must not.
- The runner's and the Mac's results are unknown.
- Stop conditions for the next step: PR #13's head is no longer `bff8dda`; the squash gives another tree than `38269372…`; a CI or Mac run shows a failure outside the lists and outside `trunk_dev`'s own baseline.

## 12. Confidence

- **Provenance: high.** Both writer manifests reproduced twice, byte for byte; opening equals closing; remote tip unchanged.
- **Validation: medium to high.** High for linux/amd64 in this container: full suite, trial merge, probes and a race run on the exact bytes. Lower overall, because no CI and no Mac run exists and I repeated only five of the writer's mutants.
- **Implementation: high for the production change** (read whole, behaviour compared, digest bytes equal, mutants around the one new survivor). **Medium to high for the guard**: what I threw at it was caught, and its completeness remains reasoning.

## 13. Effect status

No repair, no commit, no push, no pull request, no comment, no merge. The repository copy is clean at `bff8dda`. Only files under `/opt/audit/`, `/opt/ci/work/` and the report folder were created.

## 14. Report delivery

- Report: `/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/12-audit.md`. Its SHA-256 is given in the thread reply that delivers it, because a file cannot hold its own hash.
- Evidence: `/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/12-audit-evidence/`.

## 15. Final verdict

**ACCEPT**

STATUS: READY
