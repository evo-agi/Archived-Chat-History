# 23-audit-pr26-repair2 evidence (ES PR #26, `c99a1b4` to `06ec54b`)

Written by the independent audit thread "Audit Execution-Substrate PRs" on 2026-11-23, from 17:29Z onwards. Every file here was made in the audit's cloud container or fetched read-only. `SHA256SUMS.txt` lists every file.
My local folder, tree and script names carry the tag `26c` (and `23` for the unit runs and probe tests), so that they do not reuse names from older audits.
Nothing in this folder is authority. It is evidence for `../23-audit-pr26-repair2.md`.

## Setup

- **Clone and recipe.**
  - The repository clone is `/opt/audit/es`.
  - Manifests use the v2 recipe `/opt/audit/v2.py` (SHA-256 `c08597e2…a3ca`), checked before each run.
  - Each run checks out the topic branch at the tip, resets it to the base, and pins the upstream to `origin/trunk_dev`.
- **Test trees.** All are `git archive` exports in `/home/ci`:
  - `pr23h` and `es23`: head `06ec54b`.
  - `b23` and `pr21h`: previous head `c99a1b4`.
  - `/home/ci2` holds copies of `es23` and `b23` for the second identity.
  - `fix26c`: `06ec54b` + `key-path-unambiguous-proposal.diff`.
  - `m26c`: the trial merge of PR #12's head `2c8bf35` (PR #28's head) with `fix26c`'s commit. The two known conflict blocks are resolved by the PR #12 merge plan (see `trial-merge-provenance.txt`).
- **Identities.** Runs used `env -i` and Go 1.26.5 with `GOTOOLCHAIN=local`, as user `ci` (1500:1600, with sudo) and user `ci2` (1700:1700, without sudo).
- **Probes and mutants.** Each one ran in a fresh copy of a pristine tree.
- **Local commits.** The proposal commit used for the trial merge was made in a temporary index, author "audit", and never pushed.
- **No downloaded binary was executed.** `dto26b-writer.py.txt` is the writer's probe script from `02-repair-evidence/`, copied verbatim and read in full before it ran.

## Files

| File | What |
| --- | --- |
| ls-remote-open.txt, ls-remote-close.txt | Remote refs at the start (17:29Z) and at the end (17:55Z). Both times the branch was at `06ec54b` and `trunk_dev` at `036d507` |
| manifest-v2-open-…-run1/2.json (+ .out.txt), manifest-v2-close-…-run1/2.json (+ .out.txt) | `06ec54b` against `036d507`: `98c25abf…b55f` all four times. The JSON is byte-identical across runs and to the writer's `manifests/06ec54b-vs-036d507-trunk-1.json` and `-2.json` |
| delta-c99a1b4-06ec54b.diff | `git diff c99a1b4 06ec54b`, byte-identical to the writer's |
| writer-evidence-check.txt | The writer's report hash (before and after its CI-line edit), its `SHA256SUMS` check (70 of 70 OK), and the manifest and delta comparisons |
| unit23.sh.txt, run-unit23.sh.txt, unit-admission-06ec54b-vs-c99a1b4-uid1500-gid1600.log, -uid1700-gid1700.log | gofmt, vet (three targets) and es/admission in full at both heads, for both identities, with a diff of the results |
| zz_audit23_paths_test.go.txt, paths26c.sh.txt, written-key-paths-06ec54b-uid1500-gid1600.log | Every key path `encoding/json` writes for the four envelopes the presence checks name |
| coverage26c.py.txt, presence-coverage-06ec54b.txt | The 104 pins compared with every written place of a key the old checks required: equal |
| pincheck26c.sh.txt, oldcheck26c.sh.txt, pincheck26c.py.txt, pin-log-06ec54b-uid1500-gid1600.log, old-required-keys-c99a1b4-uid1500-gid1600.log, pin-check-06ec54b.txt | Checks that the coverage script's transcribed lists match the source: the (root, path) pairs the four checks pass on `06ec54b`, and the keys the four old checks required on `c99a1b4`, each logged by one added `t.Logf` in a fresh copy |
| zz_audit23_passthrough_test.go.txt, passthrough26c.sh.txt, passthrough-fields-06ec54b-uid1500-gid1600.log | 25 types reachable from the public DTOs, walked for `any`, interface or `json.RawMessage` fields: none (O23-1) |
| probes21.py.txt, probes21-06ec54b-uid1500-gid1600.log, probes21-fix-uid1500-gid1600.log | Audit 22's probes Q0 to Q6 on `06ec54b` and on the proposal |
| probes20.py.txt, probes20-06ec54b-uid1500-gid1600.log | Audit 20's probes P00 to P30 on `06ec54b` (tree label `06e`): all 31 as predicted |
| mutants20.py.txt, mutants20-06ec54b-uid1500-gid1600.log | Audit 20's 22 mutants on `06ec54b`: all caught |
| rprobes26c.sh.txt, dto26b-writer.py.txt, writer-rprobes-06ec54b-uid1500-gid1600.log | The writer's real-tree probes R0 to R7 on `06ec54b` |
| probes26c.py.txt, probes26c_defs.py.txt, probes26c-uid1500-gid1600.log, probes26c-T3-T4-rerun-uid1500-gid1600.log | New probes T0 to T7 on `c99a1b4` and `06ec54b`. T3 and T4 did not build in the first log because of a quoting error in my probe test; the rerun has them |
| probes26c-fix-and-trial-merge-uid1500-gid1600.log | T0 to T7 on the proposal and on the trial merge with the proposal |
| mutants26c.py.txt, mutants26c-uid1500-gid1600.log, mutants26c-with-probe-T6-uid1500-gid1600.log, -T7-… | Mutants P00 to P02 on `06ec54b` (P01 and P02 survive the suite: A23-2), and P01 with probe T6 and P02 with probe T7 applied, which show the code itself refuses them |
| mutants26c-on-proposal-uid1500-gid1600.log | P00 to P02 on the proposal |
| key-path-unambiguous-proposal.diff | The fix for A23-1 and A23-2 (`patch -p1` on `06ec54b`, test-only, one file) |
| fix26c-apply.py.txt, fix26c.sh.txt, run-fix26c.sh.txt, key-path-unambiguous-proposal-uid1500-gid1600.log | How the proposal was made and checked: gofmt, vet (three targets), and es/admission in full compared with `06ec54b` test for test |
| mutants26c-fix.py.txt, mutants26c-fix-uid1500-gid1600.log | Mutants X00 to X04 of the proposal |
| merge26c.sh.txt, trial-merge-provenance.txt, trial-merge-2c8bf35-with-proposal-uid1500-gid1600.log | The trial merge of `2c8bf35` with the proposal: the merge-tree results with and without the proposal, the resolution, and build, vet, gofmt and es/admission in full on the merged tree |
| trialcmp26c.py.txt, trial-merge-results-vs-writer.txt | My es/admission results on the trial merge with the proposal, compared test for test with the writer's `pr12-trial/trial26c-admission.results.tsv` (random SIGKILL rounds compared by round number) |
| run-26c.sh.txt | The driver for the runs on `06ec54b` |
| ci-status.txt | CI run 45226582061 on `06ec54b`, read through the GitHub API |

## Sensitive material

The probes and fixtures are synthetic. No key, certificate body, token or config file is copied here. Commit-message trailers and author names are left out.
