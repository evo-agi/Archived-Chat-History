# INDEPENDENT AUDIT REPORT: repair of PR #13 after the red-team of the combined PR #12 (narrow audit of `bff8dda..8e1f539`)

Fresh, read-only audit. Audit thread: "Audit PR 13 post-red-team repair". Date: 2026-11-23 (UTC). Model: Opus (Fable exhausted). I am not the writer of the audited bytes.

Verdict: **BLOCK** (section 16), on one medium finding in the new raw pointer rule (A6-1). Everything else the brief asked me to verify holds. The correction is small: one line in the guard plus three subtests and one sentence (section 10).

## 1. In plain words

1. **The bytes are the ones the writer reported.** I rebuilt all four of the writer's manifests from the pushed branch. They are identical byte for byte, at the start and at the end of this audit.
2. **RT2-1 is closed.** The red-team's guard test fails 45 of 45 at the previous tip `51d6d5f` and passes at `8e1f539`. The reviewed list of dependency packages is pinned to the same versions as `go.mod` and `go.sum`, `plugin` is in the import inventory, and the red-team's test is kept as a permanent test.
3. **The two new roads are closed in the way the writer says.** With the writer's three probe files, a withdrawn Service reopened and sent a job at `51d6d5f`, and every guard test still passed. At `8e1f539` the new raw pointer rule refuses all three files in every build view that compiles them.
4. **But the new rule can be fooled with one comment (A6-1, medium, blocking).** Go has a `//line` comment that tells tools "the code below belongs to another file". The rule believes it. A file without the `unsafe` import can write `//line <name of a sibling file that imports unsafe>:1` above a raw pointer road, and the rule then counts the road as part of that sibling file and accepts it. I measured this with two probe files: every guard test, the whole `es/admission` package and `es/runtimehelper` pass with them in place. Without the comment the same code is refused. Today this reaches the admission package only in its macOS build (the sibling is `execution_roots_darwin.go`), and in Linux builds only the runtime helper package, a separate program. It does not reach the Linux build of the admission process unless someone also adds a new file that imports `unsafe`, which the inventory would show. Two new sentences of the owner document are untrue as written because of it. A one-line change in the guard (read the file's own position, not the one the comment names) refuses both probes in every view; I tried it in a scratch copy.
5. **The test of the rule never checks that it judges per file (A6-2, low).** A mutant that accepts a road when any file of the same package imports `unsafe` passes every guard test. That is the same gap seen from the test side; the correction of A6-1 closes it.
6. **What else I tried did not get through.** Generic code can hold and move a raw pointer without any expression of a raw pointer type, but it cannot turn it into a typed pointer without spelling a raw constraint, which the rule sees; neither the standard library nor any reviewed dependency exports such a constraint. Reflection reached without the `reflect` import cannot call methods or set values with anything taken from an unexported field, and it has no conversion from or to `unsafe.Pointer`.
7. **Behaviour is unchanged.** The full suite at `51d6d5f` and at `8e1f539`, run by me on the exact bytes: none of the 6,758 shared results changed; the 260 new results all pass. Build is clean for the three targets, vet shows only the one known finding, and the race detector is clean.
8. **The merge conflict with `trunk_dev` is real and older than this repair.** It appears in `docs_contract_test.go` at `8e1f539`, at `51d6d5f` and at the last audited tip `bff8dda`. Keeping both blocks gives exactly the writer's resolution. `trunk_dev` moved again during this audit (PR #24, `df46164`); the conflict is the same and the resolution still passes the docs tests.

## 2. Audit target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Pull request | #13, draft, head branch `claude/project-thread-sqldt7`, base branch `codex/reliable-submit-operational-handoff-v1` (PR #12's head) |
| Base commit | `8058561edc08356c46680c204586b3c7796c0ff3` (remote base branch unchanged at the end, `git ls-remote`) |
| Previous tip | `51d6d5fcb5d7e59e70fd53e1cd2801044a03e23a`; last audited tip `bff8dda37dbf5484afb3b264d4eca38cf6abf118` (`12-audit.md`, ACCEPT) |
| Audited commit | `8e1f539613b85511b537e52b376aad88ab4af643`, tree `5dd0af054e351315789d375dec15b29d6eaac01c` (four commits after `51d6d5f`: `2849293`, `582ae7d`, `98fa8f5`, `8e1f539`) |
| Recipe | `governed-execution.audit-patch-manifest.v2`, `/mnt/project-files/claude-conversion/tools/governed_execution_audit_patch_manifest_v2.py`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (checked before every run) |
| Base-relative manifest | `b2a8d5a2a1d3164062a170d7154d51d6568df2a29a7df6c2e63573d277c916a0`, 32 paths, textual diff `d1a893e28a7d32ae20a20ac6983e9e9935986800e95cc7623383af38818a6369` |
| Delta against `51d6d5f` | `290c05ac745bc92409ae9f73ca3addd07e1405e789fc55ade5265c6308cb6db8`, 9 paths, textual diff `963adaf06fc980c4e0bf87598ac7191343f48334ab046cb5fa51fa089c6dd8bc` |
| Delta against `bff8dda` | `f761abed937dc1b09726878874cac5210892143d5a42608ef5b817c559955377`, 9 paths, textual diff `fda830eb0a55c84eced09088acac12af8c6617807e6fc153e7e5685fda6c19f5` |
| Trunk-relative | `67b0932f59089fb7fd3ab0cf13eb0d68afff67393273bba4697a85a17d5e410d`, 52 paths, upstream `origin/trunk_dev`, base the merge base `ae326b0ddc30ec6b35883ee32945c622405b68b6` |
| Writer report | `14-repair.md`, SHA-256 `d0e8c7a828c4fc27b4cb4f2f7f2dcff192c1d6a282b726d74c0f8ead4e045963`; evidence `14-repair-evidence/` (its `SHA256SUMS`, 94 entries, all OK) and `14-repair-evidence.tar.gz` `6fe8205ac9941644e4d60d1aebcda0ef536e4d9568ef50493ab1ede3a7dc73ab` |
| Prior reports read | `12-audit.md` (`7bfb9135…d331c`), `13-red-team.md` (`0d6793a5…dafd60`) |
| `trunk_dev` | `ea86a963eba7588eaa57d31454beba8362f722a5` at the start; `df461642d2f7c9481873ca74b7eaaba368feb12f` (PR #24, CI configuration and documents) at the end. The merge base with the tip stayed `ae326b0` |

## 3. Audit posture

- Read-only. One thread, no subagents, no repository edits. The working copy `/home/user/Execution-Substrate` was only fetched into.
- Manifests were taken in a separate clone `/opt/audit/prov-repo` (checkout under `umask 022`); every build, test, probe and mutant ran in throwaway clones under `/opt/ci/work/`, as an unprivileged user `ci` (uid 1500, gid 1600) with an emptied environment, Go 1.26.5 (`GOTOOLCHAIN=local`), linux/amd64, 4 CPUs. The store package needs the Linux overlay of `replay_custody_file_test.go` (`11-repair-evidence/store-test-linux-overlay.patch`, SHA-256 `1173ed06…19ad4`) to compile on this branch, as in every earlier report; it was applied to the test clones only, never to the manifest clone.
- Probe files and mutants existed only in those clones. Two trial merges were committed in a local scratch clone (`/opt/audit/tm`) and never pushed.
- Nothing was pushed, no comment was posted, no pull request was opened or changed, nothing was merged.

## 4. Provenance reproduction

Script `scripts/prov15.sh.txt` (the writer's `prov14.sh` adapted to a separate clone): it checks the recipe's hash, checks that the pushed tip equals `8e1f539` and that `8058561`, `51d6d5f` and `bff8dda` are its ancestors, then for each manifest resets `HEAD` with `--mixed`, pins the upstream, runs the recipe twice with `python3 -I`, compares the two outputs with `cmp`, stages the tree and writes it, and finally restores `HEAD`, the upstream and a clean status.

| Manifest | Upstream pinned to | Result |
| --- | --- | --- |
| Base-relative | `origin/codex/reliable-submit-operational-handoff-v1` | 32 paths, `b2a8d5a2…16a0`; both runs identical; equal to the writer's file (`cmp`) |
| Delta against `51d6d5f` | `origin/claude/project-thread-sqldt7` | 9 paths, `290c05ac…6db8`; identical; equal to the writer's |
| Delta against `bff8dda` | `origin/claude/project-thread-sqldt7` | 9 paths, `f761abed…5377`; identical; equal to the writer's |
| Trunk-relative | `origin/trunk_dev` | 52 paths, `67b0932f…410d`; identical; equal to the writer's |

- Each staged set equals the manifest's paths and each staged tree is `5dd0af05…ac01c`, the tree of the commit.
- **Opening and closing.** Opening at 11:57Z, closing at 12:37Z (container clock). All four closing manifests are byte-identical to the opening ones. `trunk_dev` had moved to `df46164` by then; the merge base and so the trunk-relative manifest did not change.
- **Upstream pin.** The brief says to pin the upstream to `origin/trunk_dev`. A manifest records its upstream, so a byte-identical reproduction needs the writer's pin. I used the writer's pins; the trunk-relative manifest is the one pinned to `origin/trunk_dev`.
- **Mode bits.** No difference to tolerate.

## 5. Coverage

| Area | What I covered |
| --- | --- |
| Governing documents | Operating protocol sections 12 to 16, provenance guide sections 5, 8 and 9. Writer report `14-repair.md` (whole). Prior audit `12-audit.md` (whole). Red-team `13-red-team.md` (its evidence: tests and checksums). ES `AGENTS.md` and `PLANS.md`: the new `PLANS.md` entry only. |
| Production source | The one production change, a comment in `es/admission/internal/admissionstate/state.go` (O5-1), against the code. The two production files that import `unsafe` (`es/admission/execution_roots_darwin.go`, `es/runtimehelper/privilege_linux.go`), for what they do with `unsafe.Pointer`. Which binaries import `es/runtimehelper` (only `cmd/es-runtime-support`). |
| Guard | The whole diff of `es/admission/workstream_c_guardrails_test.go` (737 diff lines) and the loader it uses (`loadTypedProductionPackagesAt`, `loadTypedProductionMetadataAt`, `typeCheckCollecting`, `productionGoListEnvironment`, `TestOperationalGuardLoadsEveryProductionFile`). |
| Adopted tests | Each of the four files diffed against the red-team's delivered file (section 7.6). |
| Documents | The diffs of the owner document, `PLANS.md` and `docs_contract_test.go`; the owner document's section headings and its §8 limits table. |
| Dependencies | `go.mod`, `go.sum` and `go list -m all` against the reviewed list; the writer's API scan output (read, not re-run); a search of the standard library and the five reviewed modules for constraints or exported types with `unsafe.Pointer` in them. |
| Toolchain source | `go/scanner` (how `//line` is resolved), `reflect` (`Value.Call`, `Value.Convert`), `text/template` (how it passes `reflect.Value` arguments). |
| Not inspected | The 13 commits before `51d6d5f` (judged by audits `04` to `12`). The writer's 13 guard mutants beyond the three I repeated. The red-team's behaviour tests line by line (I checked them by diff and by running them). Anything on macOS, linux/arm64 hardware or the GitHub runner. |

## 6. Findings

### 6.1 Summary

| ID | Severity | Type | In one line |
| --- | --- | --- | --- |
| A6-1 | **medium, blocking** | security risk / guard gap; patch defect of this repair; documents untrue as written | The raw pointer rule attributes each site by the position a `//line` comment names. A file without the `unsafe` import passes the rule if it names a sibling file that imports `unsafe`. Measured: whole guard and whole `es/admission` unchanged with two probe files. |
| A6-2 | low | test gap | No test of the rule has a road in a package that also has a file importing `unsafe`, so a mutant that checks the import per package instead of per file survives all guard tests. |

No production defect. Observations are in section 6.4.

### 6.2 A6-1

```text
AUDIT FINDING
ID / Type / Severity: A6-1 / security risk: guard gap in the new raw pointer rule;
  documents untrue as written / medium, blocking

Current contract or strategic target:
  Owner document .docs/execution_lifecycle/reliable_submit_operational_handoff.md
    :618-619 "So a raw pointer value may appear only in a file that imports
              `unsafe`, which the import inventory holds by its hash."
    :812-818 "The raw pointer rule reads every expression and every declared or
              used name of every production package for the same three targets,
              and a value whose type has the underlying type `unsafe.Pointer` in a
              file that does not import `unsafe` fails it. With that rule the
              import names the files that can write storage past the typed
              inventories by every road through the language known here ..."
  PLANS.md:19-20 "A new raw pointer rule refuses such a value in a file that does
              not import `unsafe`."
  All three sentences are pinned by docs_contract_test.go.

Path and line:
  es/admission/workstream_c_guardrails_test.go
    :4526  position := pkg.fset.Position(pos)
           FileSet.Position applies //line directives (it is PositionFor(pos,
           true)); the file name it returns is the one a directive names.
    :4527-4530 the site is then filed under that name.
    :4575-4580 validateOperationalRawPointerFiles asks whether THAT file imports
           unsafe.
  go/scanner (Go 1.26.5, scanner.go updateLineInfo): a relative file name in a
  //line directive is joined to the directory of the file being parsed, and the
  loader parses with absolute paths (typeCheckCollecting), so
  "//line privilege_linux.go:1" names the real sibling on every machine.

Evidence (linux/amd64 container; darwin view type-checked from linux, as the
guard does):
  1. Two probe files, never committed (probes/zz_line_*.go.txt):
     - es/runtimehelper/zz_line_linux.go (//go:build linux): road R14-1
       (golang.org/x/sys/unix.MmapPtr, a [1<<47]byte window), preceded by
       "//line privilege_linux.go:1". Imports only golang.org/x/sys/unix.
     - es/admission/zz_line_darwin.go (//go:build darwin): the writer's road-2
       function against Service (encoding/json UnmarshalTypeError ->
       reflect.Type -> Method(0).Func.UnsafePointer(), then clearing the two
       latches), preceded by "//line execution_roots_darwin.go:1". Imports only
       encoding/json, errors, fmt, strconv, strings, time.
  2. go build ./... for darwin/arm64, linux/amd64, linux/arm64: exit 0. go vet of
     both packages for the three targets: nothing beyond the known
     result_auth_test.go:395 report.
  3. Guard, five tests (raw pointer rule, import inventory, reviewed list, loads
     every production file, RT2-1): 277 results, all pass
     (probes/a6-guard-line-v.log).
  4. Whole es/admission, admissionstate, reliablesubmit and runtimehelper with the
     probes: es/admission 2,398 pass, 1 skip, 0 fail (the same as the tip
     without probes); runtimehelper 81 pass; the only failures are the three known
     probe-binary store tests (probes/a6-whole-suite.summary.txt).
  5. Control: the same two files with only the //line lines removed. The raw
     pointer rule fails in all three views: darwin/arm64 for zz_line_darwin.go,
     linux/amd64 and linux/arm64 for zz_line_linux.go
     (probes/a6-guard-control.log).
  6. Correction sketch (probes/a6-fix-sketch.diff): position :=
     pkg.fset.PositionFor(pos, false). With it, the rule refuses both probes,
     with the //line lines in place, in every view that compiles them
     (probes/a6-fix-sketch.log). Not pushed; the writer owns the correction.

Impact:
  - The rule was the deliverable of this repair: it is what holds R14-1 and R14-2.
    In every package that has a file importing unsafe, the class is open again for
    any other file of that package, and the whole guard is blind to it, as it was
    at 51d6d5f.
  - Today that is es/admission in its darwin/arm64 build (the sibling is
    execution_roots_darwin.go) and es/runtimehelper in both Linux builds (sibling
    privilege_linux.go; the package is linked only into cmd/es-runtime-support,
    a separate program from the admission process).
  - Not reached today: the Linux build of the admission process. es/admission has
    no Linux file that imports unsafe, so a //line directive there names a file
    the rule cannot find and the site is refused ("in no file"). A hostile change
    would have to add such a file, which the import inventory and its hash show.
  - The effect on macOS is Inference, not run: road 2 needs code mapped below the
    heap, which the writer measured only on linux/amd64. The guard's blindness on
    darwin is measured.
  - The handoff has no production caller yet, so nothing shipped is affected.
  - The three sentences quoted above are untrue as written.

Required correction: R1 to R3 in section 10.

Uncertainty:
  - Other position-based keys of the older typed inventories also use adjusted
    positions (for example the line and column in trancheB1SemanticOccurrence,
    :8391). Their site names come from the real file name, so I judged them not
    affected, by reading; I did not probe them.
  - No //line or /*line directive exists in any Go file of the repository today
    (searched), so refusing them in production files costs nothing now.

Patch defect or pre-existing issue:
  Patch defect: the rule and the sentences are new in 582ae7d and 8e1f539.
```

**Why medium and blocking, not low.** The earlier guard gaps that left the whole guard blind to a measured road (A3-1, A4-1) were medium and blocking; a darwin-only change inside an existing `unsafe` file (A4-2) was low. A6-1 sits between them: it reopens exactly the class this repair was built to close, in one of the three views the rule claims, in the package it protects, and the documents now promise more than the rule does. It is not high because the Linux build of the admission process is not reached without a visible new `unsafe` file, and nothing has a production caller. If the coordinator weighs the darwin-only reach in `es/admission` as lower, the alternative is to carry it to PR #12's merge gate like C1 last time. I recommend fixing it in PR #13 now, before the Fable red-team: the correction is one line and three subtests, the project rule is against "accept now, revisit later", and a red-team that starts from a rule with a known hole would spend its time finding it again.

### 6.3 A6-2

```text
AUDIT FINDING
ID / Type / Severity: A6-2 / test gap / low
Path and line: es/admission/workstream_c_guardrails_test.go:4599-4800
  (TestOperationalGuardRawPointerValuesNeedTheUnsafeImport). Every road subtest
  writes into es/admission/service.go in the linux/amd64 view, where no file of
  the package imports unsafe.
Evidence: mutant A1 (mutants/A1-per-package-unsafe.diff) makes
  validateOperationalRawPointerFiles accept a site when ANY file of the package
  imports unsafe. The five guard tests pass: 277 results (mutants/A1.log).
  Mutant B4 (a site whose position names no file of the package is dropped instead
  of refused) also survives (mutants/B4.log); it matters only with a //line
  directive.
Impact: the per-file rule that the documents describe is not pinned by a test.
  It is the test-side view of A6-1.
Required correction: R2 in section 10.
Patch defect or pre-existing issue: patch defect (new test).
```

### 6.4 Observations

| ID | Observation |
| --- | --- |
| O6-1 | **Generics hold raw pointers without any raw type in the file.** A constraint with a method `UnsafePointer() P` lets Go 1.21 inference set `P` to `unsafe.Pointer` from a `reflect.Value` argument; the instance is recorded only in `Info.Instances`, which the rule does not read. Measured with the guard's own functions (`probes/zz_audit_generic_test.go.txt`, `probes/generic.log`): holding such values in a `[]P` (G1) and passing one to `reflect.Value.SetPointer` through another constraint method (G2) both pass the rule. Turning one into a typed pointer does not compile: a conversion from `P` constrained by `any` (G3) and from the inferred `[]unsafe.Pointer` to `*[1]*bool` (G4) are both refused by the type checker. A conversion needs a constraint whose type set holds `unsafe.Pointer`; spelling one is an expression of raw pointer type, which the rule sees, and neither the standard library outside `internal`, `runtime` and `cmd`, nor the five reviewed modules, exports such a constraint or a named type or alias with that underlying type (searched). So no road, but the documents' "a value whose type has the underlying type `unsafe.Pointer`" is a statement about the static types of the source, not about instances. Optional: say so, and keep G1 and G3 as two more subtests. |
| O6-2 | **Reflection without the import.** I checked the writer's limit 4 against the Go 1.26.5 source. `Value.Call` checks the function value (`mustBeExported`) and, in `call`, every argument (`mustBeExported` in the argument loop), so a handle or receiver taken from an unexported field cannot be passed; `Value.Set` needs an assignable value. `Value.Convert` (`convertOp`) has no case for `unsafe.Pointer` in either direction. `text/template` does pass a `reflect.Value` of its data to a function whose parameter is `reflect.Value`, and such a function can be spelled without the import through a type parameter, but what it receives is subject to the same flags. By reading and by the generic probe; I did not build a reflective probe against the state handle. |
| O6-3 | `14-repair.md` §7.4 says the `docs_contract_test.go` conflict with `ea86a96` appears at `51d6d5f`. It appears at `bff8dda` too, the last audited tip. Keeping both blocks (ours first, one blank line) gives blob `cdb2b1b`, the same as the writer's resolution. |
| O6-4 | The API scan (`14-repair-evidence/scan/`) found nothing for gRPC although gRPC's API reaches protobuf reflection types; I read the output and did not re-run the scanner. The raw pointer rule does not depend on the scan; the reviewed list does, for which packages need no import inventory. The pins are a machine trigger for a new review. |
| O6-5 | Leak scan of my evidence: the only hit is the placeholder `hvs.abcdefghijklmnopqrst` inside two test names in the result lists. It is a fixture string in a test name, not a credential. |
| O6-6 | My full-suite failure counts differ from the writer's (239 against 117 in the root package and store tests) because this container lacks more of what the root package's operator-script tests need (no `ssh`, `uuidgen`, `setfacl`, `bindfs`; locale `C.UTF-8`). Within my runs the failing set is identical at both commits, and none is in a file this pull request touches except the known store test `TestOperationalHandoffSchema4BinaryRefusesSchema5`, which came with PR #12 and is not changed here. |

## 7. What the brief asked me to judge

### 7.1 RT2-1 (reviewed dependency list, `plugin`, permanent test)

| Check | Result |
| --- | --- |
| Each pin equals `go.mod` and `go.sum` | Yes for all five modules (`go-jose/v4 v4.0.4`, `go-spiffe/v2 v2.4.0`, `x/sys v0.46.0`, `grpc v1.67.1`, `sqlite v1.54.0`); `go list -m all` agrees; `go.mod` and `go.sum` are unchanged by PR #13; `trunk_dev`'s `go.mod` has the same versions |
| `plugin` inventoried | Yes (`operationalGuardInventoriedImport`), with a mutation case |
| A dependency outside the list is inventoried | Yes: `modernc.org/libc` (plain, renamed, blank), protoimpl, `modernc.org/sqlite/lib`, an unknown module; controls for a reviewed package, a module package and the standard library |
| Version, replacement, other module, dotless and dotted paths | Each a subtest checked against its reason text; my mutant B3 (version not compared) is caught |
| Red-team test permanent | `reliable_submit_operational_admission_redteam2_guard_test.go`, 5 imports × 9 forms. With it copied onto `51d6d5f`: 45 of 45 subtests fail (`probes/rt21-old.log`); at `8e1f539`: all pass |

### 7.2 R14-1 and R14-2 (and the protoimpl variant)

Reproduced with the writer's probe files (checksums match their `SHA256SUMS`):

| Commit | What | Result |
| --- | --- | --- |
| `51d6d5f` + probes | The writer's effect test | All three roads reopen a withdrawn Service, which sends: `kind=5 operation=8 write=11 run=true receipt=true` (`probes/r14-effect-old.log`) |
| `51d6d5f` + probes | Guard tests | Pass (`probes/r14-guard-old.log`): the guard was blind |
| `8e1f539` + probes | Guard tests | The raw pointer rule refuses `zz_probe_rawptr_json.go` and `zz_probe_rawptr_protoimpl.go` in all three views and `zz_probe_rawptr_mmap_linux_amd64.go` in linux/amd64; the import inventory and the reviewed list refuse protoimpl (`probes/r14-guard-new.log`) |

The rule's own test is new, so "fails before" means the guard passed the roads at `51d6d5f`, shown above. Its ten overlay roads each have the `import _ "unsafe"` control. The rule holds R14-1 and R14-2 as long as no `//line` directive is used (A6-1).

### 7.3 Further bypasses of the typed rule

| Idea | Result |
| --- | --- |
| `//line` directive naming a sibling file that imports `unsafe` | **Gets through** (A6-1) |
| `//line` directive naming a file that does not exist | Refused ("is in no file"), at the tip; survives mutant B4 |
| Generic type parameters (inferred from a method, held in a slice, passed on) | Held, not converted (O6-1) |
| Interfaces and type assertions, method values, generic fields | Covered by the writer's overlay roads; the method value `zzunix.MmapPtr` is refused by its signature |
| `reflect.Value.Pointer` and `UnsafeAddr` (`uintptr`) | No conversion from an integer to a pointer without a raw type (the writer's subtest; the type checker refuses `(*T)(uintptr)`); handing the integer to a system call is the named OS limit |
| Conversions without cgo: containers of raw pointers (`[]unsafe.Pointer`), array-pointer conversion | Not convertible to a typed pointer (G4) |
| Other packages exposing `reflect.Type` | `encoding/json`, `database/sql` (and so `modernc.org/sqlite`) reach `reflect.Value`; the only raw exits (`UnsafePointer`, `SetPointer`'s parameter) are raw types the rule sees (O6-2) |
| Exported raw-core constraints or raw aliases in the standard library or the reviewed modules | None found by search |
| Files the rule does not read | Every production file must be loaded by one of the three views (`TestOperationalGuardLoadsEveryProductionFile`), and the views use `CGO_ENABLED=0`; a file behind `cgo`, another platform or a custom tag fails that test. Unchanged by this repair |
| `//go:linkname` | Accepted by the compiler only in a file that imports `unsafe` (unchanged reasoning of the documents; not probed again) |

### 7.4 O5-1

Done as described. `state.go:152-155` now says that an untyped nil owner, an interface without a value, gets the closed handle, and that a typed nil pointer gets a real state; that matches `if owner == nil` at :157. The hash pin moved to `sha256:e07fa2a0b98684fd11fe291d9e8d12ffdb61002e6fcdb83032fc9f30bc625a48`, which is the manifest's hash of the file.

### 7.5 Path ceiling 48 to 52

Justified. The trunk-relative manifest has 52 paths; the four new ones are exactly the four adopted test files that the new reconciliation paragraph names. The base-relative count went from 28 to 32 for the same four. The old sentence now says "was 48 files" and the docs test pins both, with a wrong-statement case for "is 48 files".

### 7.6 Adopted red-team tests

Each file differs from the red-team's delivered file (`13-red-team-evidence/`, checksums OK) only as `14-repair.md` §4.4 says: the credit lines in the headers of the behaviour, crash and guard tests; protoimpl added to the guard test's roads with its paragraph; and in the limits test the header, the renamed tests and helpers, and "GAP CLOSED?" replaced by "LIMIT CHANGED (update the owner document §8 and this test):". The owner document's §8 does hold `CP-ROLLBACK` and `CP-RELEASE`. All the adopted tests pass at the tip and under the race detector.

### 7.7 Mutants

| Mutant | What | Result |
| --- | --- | --- |
| B1 (writer's M3) | The raw pointer rule accepts every file | Caught: 11 failing results |
| B2 (writer's M10) | Expressions are not read | Caught by the exact-site subtest only, as the writer says |
| B3 (writer's M6) | The version of a reviewed module is not compared | Caught |
| A1 (mine) | The import is checked per package, not per file | **Survives** (A6-2) |
| B4 (mine) | A site in an unknown file is dropped instead of refused | Survives; matters only with `//line` (A6-1) |

I did not re-run the writer's other ten mutants.

### 7.8 The merge with `trunk_dev`

| Trial merge into | Result |
| --- | --- |
| `bc9fe36` into `8e1f539` | Clean (as the writer reports) |
| `ea86a96` into `8e1f539`, `51d6d5f`, `bff8dda` | The same one conflict in each: `docs_contract_test.go`, PR #12's block of operational handoff tests and PR #19's `TestARSStorageCheckDocsContract` appended after the same function |
| `ea86a96` resolved by keeping both blocks | Blob `cdb2b1b`, the writer's. Tree `1194b731…0046`. `go build ./...`, `go vet ./...`, `GOOS=darwin GOARCH=arm64 go vet ./...`: exit 0. Root package and `es/admission/...`: no result that passes at the tip fails here (one known failure of the tip passes, fixed on `trunk_dev`); `es/admission` 2,411 pass, 13 skip, 0 fail; all 194 operational handoff and ARS docs results pass |
| `df46164` (PR #24) into `8e1f539` | The same one conflict. Resolved the same way: `go vet .` exit 0, and the operational, ARS and Go-baseline docs tests pass. `13-ci-list-two-lines.patch` still applies to `df46164`'s list, at an offset of 7 lines |

The 13 skips in `es/admission` on the merge are the writer's 13, including `TestOperationalHandoffChildProcess`, which needs the second line of the CI list patch.

## 8. Validation assessment

### 8.1 What I ran, on which bytes

| Run | Bytes | Result |
| --- | --- | --- |
| Provenance, opening and closing, four manifests | `8e1f539` | Section 4 |
| Full suite, `go test -count=1 -json ./...` | clone of `8e1f539` and of `51d6d5f` (with the store overlay) | 7,018 and 6,802 results; 6,758 shared, 0 changed; 44 gone (the renamed inventory test and its subtests); 260 new, all pass; failing set identical (239). Tip: 6,738 pass, 239 fail, 41 skip; `es/admission` 2,398 pass, 1 skip |
| `go build ./...`, `go vet ./...` for darwin/arm64, linux/amd64, linux/arm64 | `8e1f539` | Build exit 0; vet: only `es/admission/result_auth_test.go:395:15` (copied lock), pre-existing, fixed on `trunk_dev` |
| `gofmt -l` on the changed Go files | `8e1f539` | Clean |
| Race detector, `CGO_ENABLED=1 go test -race -run 'TestRedTeamPR12Combined\|TestOperationalLimit' ./es/admission` and `./es/admission/internal/admissionstate` | `8e1f539` | 112 passing results in 84 s, no data race; state package passes |
| A6-1 probes: build, vet, guard, whole packages, control, correction sketch | `8e1f539` + two files | Section 6.2 |
| Generic probes G1 to G4 | `8e1f539` + one test file | O6-1 |
| R14 reproduction and RT2-1 test at the old tip | `51d6d5f` / `8e1f539` + writer probes | Sections 7.1, 7.2 |
| Mutants A1, B1 to B4 against the five guard tests | `8e1f539` with one change each | Section 7.7 |
| Trial merges and their tests | sections 7.8 | |

### 8.2 What I did not run

- Anything on macOS, on linux/arm64 hardware or on the GitHub runner. The darwin view was type-checked from Linux, as the guard does; the effect of A6-1 on macOS is an inference.
- The writer's API scan (read only), the writer's other ten guard mutants, and the race detector on all of `es/admission` (the adopted tests and the state package only).
- `es/app` on the trial merge (the writer reports 453 pass, 84 skip); the merge does not touch its files apart from the documents test.
- A reflective probe against the admission state handle (O6-2 is by reading).

### 8.3 Limits of what I ran

- One container, 4 CPUs, the same missing tools as the writer's (no `ssh`, `uuidgen`, `setfacl`, `bindfs`). Root-package failures are environment failures, the same set at both commits.
- The SIGKILL test's subtest names carry random delays, so the count of "new" results differs slightly between runs (the writer counted 258, I count 260).

## 9. Evidence files

`/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/15-audit-evidence/`, with `SHA256SUMS`:

- `manifests/opening/`, `manifests/closing/`: the four manifests, the recipe's stdout, staged sets and trees.
- `probes/`: the A6-1 probe sources (`zz_line_*.go.txt`), the generic probe test, their logs, the control and the correction sketch; the R14 and RT2-1 reproduction logs.
- `mutants/`: the diffs and logs of A1 and B1 to B4, and the script that applies them.
- `runs/`: full-suite summaries and result lists of both commits and their comparison, build, vet and race logs, trial-merge logs, the resolution diff and the merge test summaries.
- `scripts/`: every script I ran, as `.txt`.

Raw `go test -json` streams are not delivered (large); the result lists (`*.results.tsv`) hold every test name and outcome.

## 10. Corrections

**Blocking (A6-1, A6-2), for the writer on PR #13:**

- **R1.** Attribute each site of the raw pointer rule to the file that holds it: read the unadjusted position (`pkg.fset.PositionFor(pos, false)`) or the file of the token (`pkg.fset.File(pos).Name()`). My sketch of the first form refuses both probes in every view.
- **R2.** Add subtests that need the per-file check: (a) a road in a package that has a sibling file importing `unsafe` (the darwin view of `es/admission`, or the linux view of `es/runtimehelper`), which kills mutant A1; (b) the same road preceded by a `//line` directive naming that sibling; (c) a `//line` directive naming a file that does not exist, which keeps B4 visible. Recommended as well: refuse `//line` and `/*line` directives in every production file, by a test that reads the sources. None exists today, and the older inventories also key some entries by adjusted line and column.
- **R3.** Keep the owner document's sentences at :618-619 and :812-818 true: with R1 and R2 they are; add one phrase that the rule judges the file that holds each site and (if adopted) that production files hold no line directive, pinned in `docs_contract_test.go` like its neighbours, with a wrong-statement case.

Then new manifests, a replacement report, and a fresh narrow audit of the delta.

**Optional, cheap, with the same change:** O6-1 as two more subtests (G1 passes the rule by design, G3 does not compile) and one sentence that the rule reads the static types of the source.

**Carried, unchanged, for PR #12's merge gate:** the two lines of `13-ci-list-two-lines.patch` (they still apply to `trunk_dev` `df46164`) and the `docs_contract_test.go` conflict resolved by keeping both blocks (section 7.8).

No production code needs to change.

## 11. Sensitive-material handling

I read no security directory, environment file, database of a live system, key or credential. Tests use generated fixture keys. The evidence holds scripts, probe sources, logs and lists of test names; I searched it for key material, tokens, passwords, e-mail addresses and private addresses; the only hit is a placeholder in two test names (O6-5). No personal data is in the report.

## 12. Remaining uncertainty and stop conditions

- A source guard cannot be shown complete; the documents now say so. This audit found one more road through the guard's own reading of positions, not through the language.
- The macOS effect of A6-1 and everything about the runner remain unknown until run.
- Stop conditions for the next step: PR #13's head is no longer `8e1f539` (it will be, after R1 to R3); the next tip changes production code; a later `trunk_dev` brings a production file that imports a new dependency or `unsafe`.

## 13. Confidence

- **Provenance: high.** Four manifests reproduced byte for byte, opening equals closing, remote tip unchanged.
- **Validation: medium to high.** High for linux/amd64 in this container on the exact bytes (full suite at both commits, trial merges, probes, race); lower overall without CI and macOS.
- **Implementation: high** that nothing changed behaviour and that RT2-1, R14-1 and R14-2 are held as reported; **medium** for the raw pointer rule until A6-1 is corrected.

## 14. Effect status

No repair, no commit to any remote, no push, no pull request, no comment, no merge. The repository copy is clean at its original checkout; the manifest clone is clean at `8e1f539` with its upstream restored. Only files under `/opt/audit/`, `/opt/ci/work/`, `/root/prov-a15*` and the report folder were created.

## 15. Merge-gate data (for when an accepted tip exists)

1. PR #13's head must equal the accepted tip; today it is `8e1f539` (tree `5dd0af05…ac01c`), which this report does not accept.
2. Squash into PR #12's branch, so that the tree after the merge equals the accepted tree.
3. David's go for product code, as before (the coordinator's reading whether this counts toward his three reviews).
4. The Fable red-team of the combined PR #12 after the reset, with R14-1 to R14-5, A6-1 and the red-team's open items (A-30, MU6, double crash, longer fuzzing).
5. PR #12 picks up `trunk_dev`: keep both blocks in `docs_contract_test.go`; add the two lines of `13-ci-list-two-lines.patch`; new manifests and an audit of that delta.
6. The required check green on an up-to-date branch; a Mac run compared with `trunk_dev`'s own Mac result.

## 16. Final verdict

**BLOCK**

STATUS: READY
