# REPAIR REPORT: A7-1 of the narrow re-audit, PR #13

Writer of PR #13. Date: 2026-11-23. Answers `17-audit.md` (SHA-256 `413792a813e7c912072050e1a709e8e64e971dca82cbedf72abdbdcea3d846f3`), which accepted `d314590` with one low finding, A7-1, and asked, with the coordinator, that it be fixed in this PR. I wrote both the code and its tests.

## 1. In plain words

- **A7-1 is fixed by a test.** The check that refuses line directives in production files already read `testdata`, underscore and dot directories, but no test needed it to. Now the check goes through one function that lists a tree and checks it, and a new subtest plants a directive in each kind of directory the go command can compile from and requires each to be refused. The auditor's surviving mutant C3, applied verbatim, now fails the test, and so do twelve more mutants of the same kind (section 4).
- **O7-4 is fixed too.** The position-read check's message now also names `PositionFor(pos, false)`, which test files outside package `admission` (for example PR #22's root test file) must use.
- **One commit, one file, test code only.** `e060449c5166e35a3de444cbc9d16f739854fe45` changes only `es/admission/workstream_c_guardrails_test.go`. No production code, document, stored format or public contract changes, and the path scope is unchanged: 33 paths against the base, 53 against `trunk_dev`.
- **Not fixed here: O7-1.** Workstream A's allow rule for `PolicyDecision` reads the text of the source line, comments included. It is older than PR #12, outside its change, and the auditor listed it as separate. It belongs in its own small change from `trunk_dev`.
- **The merge with `trunk_dev`** is prepared separately and not pushed: `18-trunk-dev-merge-plan.md` with `18-trunk-dev-merge-gate.patch`.

## 2. Target

| Item | Value |
| --- | --- |
| Branch | `claude/project-thread-sqldt7` (draft PR #13), base `codex/reliable-submit-operational-handoff-v1` at `8058561edc08356c46680c204586b3c7796c0ff3` |
| Accepted tip | `d314590dad6f6e132a20c62e9fff671311e286fe` (`17-audit.md`, ACCEPT) |
| New tip | `e060449c5166e35a3de444cbc9d16f739854fe45`, tree `24ab1e9b671a0f775f964d2310638f23fe02b336`, one commit after `d314590` |
| `trunk_dev` | `200fd6097b43981ffae86e69500d1ab41b49a94c` (PR #23); merge base unchanged at `ae326b0` |

## 3. The change

`es/admission/workstream_c_guardrails_test.go`, +76/−7:

- **`operationalGuardLineDirectivesOfTree(t, root)`** lists every non-test Go file below `root` with `repositoryProductionListings` (every directory but `.git`) and refuses a line directive in any of them. It returns how many files it read. `TestOperationalGuardProductionFilesHoldNoLineDirective` now calls it for the repository, so the repository check and its test share one path from listing to refusal.
- **Subtest `every directory the go command can compile from is read`.** In a scratch tree it plants a `//line` directive in ten production files: one at the root, one in a package, one in each of `testdata/`, `_under/`, `.dot/`, a nested `testdata/_deep/.deeper/`, `vendor/`, a nested module, a cgo file and a file with a build tag that no guarded target builds. It requires exactly those ten files to be read and each directive to be refused at its line. It plants the same directive in a test file and in a file below `.git` and requires that neither is read.
- **O7-4.** The four messages of the position-read check end with "use guardPosition, or PositionFor(pos, false) outside package admission".

The existing subtest `every directory but .git is listed` already holds `repositoryProductionListings` itself for the import inventory; the new subtest holds the directive check's use of it.

## 4. Validation

Linux (linux/amd64 container), Go 1.26.5, user `ci`, emptied environment, fresh clones. Logs: `18-repair-evidence/`.

### 4.1 Mutants

13 mutants (`mutants/mutants18.py.txt`, log `mutants/m18.log`), each in a fresh copy of the new tip, run against `TestOperationalGuardProductionFilesHoldNoLineDirective` and `TestOperationalGuardReadsUnadjustedPositions` (41 results on the unmutated tip, all pass). **13 of 13 caught.**

| Mutant | Change | Caught by |
| --- | --- | --- |
| C3 | The auditor's mutant, verbatim: sources under `/testdata/` are dropped before the check | the new subtest |
| D1 | sources under a directory whose name begins with `_` dropped | the new subtest |
| D2 | sources under a directory whose name begins with `.` dropped | the new subtest |
| D3 | sources under `vendor/` dropped | the new subtest |
| D4 | cgo files dropped | the new subtest |
| D5 | files with a build constraint dropped | the new subtest |
| D6 | files more than one directory deep dropped | the repository check itself ("no production source was read") |
| D7 | the tree check validates nothing | the new subtest |
| D8 | the shared listing skips `testdata` directories | the new subtest |
| D9 | the shared listing skips every directory whose name begins with a dot | the new subtest |
| D10 | the shared listing skips nested modules | the new subtest |
| D11 | the shared listing reads test files as production sources | the new subtest (the planted test file was read) |
| D12 | only files directly below the root read | the repository check itself |

The first run of D8 to D10 did not apply (their anchor occurs twice in the file); the script was corrected to name the listing's own lines, and the second run caught all three (`m18.log`, both runs).

### 4.2 Package suite, build, vet, race

- `es/admission`, whole package, at the new tip: **2,450 pass, 1 skip, 0 fail** (`runs/admission.results.tsv`). Against the run at `0939bf6` of `16-repair.md` (code identical to `d314590`): 2,426 shared results, **0 changed**; 1 new result, the new subtest, passes; the other 24 names on each side are the random-instant rounds of the adopted SIGKILL test.
- `go build ./...` with `CGO_ENABLED=0` for linux/amd64, linux/arm64 and darwin/arm64: clean.
- `go vet ./...` for the same targets: the one known finding, `es/admission/result_auth_test.go:395:15` (untouched; fixed on `trunk_dev` by PR #14).
- `gofmt -l es/admission docs_contract_test.go`: clean.
- Race detector (`CGO_ENABLED=1 go test -race`) on the two changed tests: pass, no data race.

### 4.3 Trial merge with `trunk_dev` `200fd60`

The new tip merged with `trunk_dev` `200fd60` in a scratch clone, never pushed (`trunk-dev-merge/merge.log`): the same one conflicting file, `docs_contract_test.go`, resolved exactly as in the tested resolution of `d314590` (the file is unchanged between the two tips); the merged tree differs from that of `d314590`'s merge only in `workstream_c_guardrails_test.go`. Then the merge-gate patch for `200fd60` applied cleanly (now kept as `18-trunk-dev-merge-gate-200fd60.patch`; after PR #22 landed, `18-trunk-dev-merge-gate.patch` is the version for `792f17c`, tested with this tip in `18-trunk-dev-merge-plan.md`).

- `go build ./...`, `go vet ./...`, `GOOS=darwin GOARCH=arm64 go vet ./...`: clean.
- `internal/testtmpdir`: 27 pass (the startup-file guard included).
- `es/admission/...`: `es/admission` 2,463 pass, 13 skip, 0 fail; `admissionstate` 70 pass; `reliablesubmit` 749 pass, 2 skip, 3 fail, the three known probe-binary tests that `13-ci-list-two-lines.patch` and the existing CI list name.
- `13-ci-list-two-lines.patch` still applies. The trunk-relative path list of the merged head has 54 paths.

The root package and the documents of this merge are byte-identical to the tested merge of `d314590` (section 4 of `18-trunk-dev-merge-plan.md`), so its root results stand.

## 5. Provenance manifests

Taken after the push by `scripts/prov18.sh.txt` (the script of `16-repair.md` with the previous tip set to `d314590`), on a clean working tree at the new tip, recipe `governed-execution.audit-patch-manifest.v2` (SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked before every run). Each manifest written twice, byte-identical; for each, the staged paths equal the manifest's and `git write-tree` gives the tip's tree. Afterwards: head at the tip, status empty, upstream restored. `trunk_dev` fetched just before: `200fd6097b43981ffae86e69500d1ab41b49a94c`. Files: `manifests/`.

| Manifest | Base | Upstream pinned to | Files | Manifest SHA-256 | Textual diff SHA-256 |
| --- | --- | --- | --- | --- | --- |
| Base-relative | `8058561` | `origin/codex/reliable-submit-operational-handoff-v1` | 33 | `1594c9b0d674c9ee39d4fefd94f2516c13f860bcd582d1b121502de89c797385` | `576ac201715e129daa222a16ea9b704a883a577dfeb7444221d4a857f4eb1a1a` |
| Delta against the accepted tip | `d314590` | `origin/claude/project-thread-sqldt7` | 1 | `4467fecf5a42ff4796e0730c1a1f3afe95b79470e06a23f9749c8ac9f4e80c0d` | `844630423a80201923882aa723754f582ca3697e5b41eb25c9e57eff3997e178` |
| Trunk-relative | merge base `ae326b0` | `origin/trunk_dev` (`200fd60`) | 53 | `f5432c1bf85ff03134c3c4af0921efb1e3ea26b1618a45bea699c6f52e819136` | `acaee8b22060541a060b13406f1d62b61b1508216fbafba362c5c9b174b10f88` |

The path lists are those of `d314590`: the one changed file was already in scope.

## 6. What the narrow re-audit should check

1. That the subtest's planted tree covers every kind of directory the go command can compile a package from, and that the repository check and the subtest share the function that lists and checks (no filtering path outside it).
2. That C3, applied verbatim, and the other mutants of section 4 are caught.
3. That the O7-4 wording is right.
4. That the change is one test file and the manifests are as stated.

## 7. Not claimed

- No CI runs on this branch, and nothing ran on macOS.
- The full suite was not run again: the change is one test file of `es/admission`, which compiles into no other package; that package was run whole.
- O7-1 is not fixed here (section 1).
- Before PR #13 merges into PR #12: the narrow re-audit of this commit, then David's review (PR #13 is product code), then David's go.

## 8. Effects

- Pushed: `claude/project-thread-sqldt7`, fast-forward `d314590..e060449`. No other branch, no force-push, no merge, no tag.
- PR #13's description updated for the new tip (attribution lines kept). It stays a draft.
- Not pushed: the trial merges with `trunk_dev` (scratch clones only) and the merge-gate patch, which is a file in the project folder.
- Nothing ran outside this container: no CI, no Mac, no test box, no live service.
- No secret, key, environment file or SQLite state from a real system was read or written. A scan of the evidence found only the fixture strings `hvs.abcdefghijklmnopqrstuvwxyz` and `sk-abcdefghijklmnopqrstuvwxyz` inside test names, as in `17-audit.md`.
- Evidence: `18-repair-evidence/` (`mutants/`, `runs/`, `trunk-dev-merge/`, `manifests/`, `scripts/`, `SHA256SUMS`) and `18-repair-evidence.tar.gz`.
