# INDEPENDENT AUDIT REPORT: PR #26, repair of audit 22's findings (`c99a1b4` to `06ec54b`)

This is a narrow, read-only re-audit. The writer handed it over at 17:29Z, after the coordinator asked for A22-1 and O22-1 to be fixed in this PR with no tracked follow-up. Audit thread: "Audit Execution-Substrate PRs", the same auditor as `20-audit-pr26.md` and `22-audit-pr26-repair.md`. Date: 2026-11-23, 17:29Z to 18:02Z (UTC). I am not the writer of the audited bytes. There is no red-team, because the PR changes test files only. My local file names carry the tag `26c`.

Verdict: **ACCEPT**, with two low findings, A23-1 and A23-2, which I recommend fixing in this PR before it merges. This commit introduced A23-1. A23-2 is a gap in the new tests. One test-only diff fixes both, and I tested it (section 8).

## 1. In plain words

1. **The bytes are the ones the writer reported.**
   - My manifest of `06ec54b` against `trunk_dev` `036d507` matched the writer's byte for byte at the start and at the end (`98c25abf…b55f`, 4 files).
   - `06ec54b` is a fast-forward from `c99a1b4`. It changes four test files, +605/−83, and my delta is byte-identical to the writer's.
2. **A22-1, O22-1 and O22-2 are closed, and the writer's design is better than my proposal.**
   - The writer did not apply my `presence-exact-proposal.diff`. I agree with the reasons in section 3.6 of their report:
     - in my diff, a presence check written the wrong way still compiled;
     - a flat set cannot see name clashes or keys that move to another object.
   - **Forbidden keys:** the key set is now a struct whose only method is `accepts`, which folds case. `fieldNames[x]` no longer compiles.
   - **Required keys:** they are now judged by what `json.Marshal` really writes for a fully filled value, written both through a pointer and by value, path by path.
   - My probes Q1 and Q2 (a key changes case or loses its tag) are refused, and so are Q5 (a type's own `UnmarshalJSON`) and Q6 (a name clash drops the key). Q3 and the writer's R1 to R7 stay refused.
   - The 104 pinned paths are exactly every place where ES writes a key that the old checks required, in the envelopes those checks name. I recomputed this myself, and the two sets are equal.
3. **A23-1 (low, new in this commit): a key whose name holds a dot or brackets can stand in for a nested key.**
   - A path joins keys with `.` and marks array elements with `[]`. But a JSON key may itself contain `.`, `[`, `]` or `*`, and `encoding/json` accepts such tag names.
   - So I renamed `governed_execution.contract` to `governed_execution.kontrakt` and added a top-level field tagged `"governed_execution.contract"`. Every guard passes on `06ec54b`, although the wire no longer has `contract` inside `governed_execution` (T1).
   - The same works for `runtime_profiles[].name` (T2).
   - On `c99a1b4` both changes fail.
   - No key in today's DTOs holds one of these characters. It takes a deliberately odd tag, so this is low. But it is a looseness that this commit added.
4. **A23-2 (low, test gap): the codec refusal is right, but its tests would not notice two ways of breaking it.**
   - The code refuses a named map type or a named `[]byte` type that has its own `MarshalJSON`; my probes T6 and T7 are refused.
   - But two mutants survive the whole guard suite:
     - checking only pointers and structs;
     - exempting every `[]byte` type instead of only `json.RawMessage`.
   - The new codec test has no case for a named non-struct type.
5. **One fix for both.** `key-path-unambiguous-proposal.diff` is test-only, one file, +63/−11:
   - The filler puts its map entry under the empty key, which no struct field can have, and the paths show that entry as `*`.
   - Any written key that holds `.`, `[`, `]` or `*` fails the test with a message that names it.
   - It adds three refused cases for such keys, and two codec cases: a named map type and a named `[]byte` type.
   - Results: on `06ec54b` with the diff, gofmt and vet are clean, and es/admission in full passes with exactly two new results, the two codec cases. T1, T2, T6 and T7 are refused, P01 and P02 are caught, and all four mutants of the diff itself are caught. Merged with PR #12's head `2c8bf35`, it builds and passes es/admission in full. Test for test, it matches the writer's own trial merge, apart from the two new cases and five tests that skip only in the writer's environment.
6. **Two older observations.**
   - **O23-1:** a public DTO field of type `any` or `json.RawMessage` would let any key through, `"publication"` included (T3, T4). Today there is none in the 25 types the guards reach, so refusing them would cost nothing.
   - **O23-2:** `fieldNames.keys[x]` still compiles inside the package. A deliberate reach into the field could still read the set by hand.
7. **Behaviour is unchanged.**
   - es/admission in full, two identities: `06ec54b` adds 24 new results (17 for the paths test, 7 for the codec test), all passing. No shared result changes.
   - The identity without sudo has the same 7 execution-root privilege failures at both heads.
   - gofmt is clean, and vet is clean for linux/amd64, linux/arm64 and darwin/arm64.
   - Audit 20's 31 probes and 22 mutants give the same results as on `c99a1b4`.
8. **CI.** GitHub's "build, vet and test" run 45226582061 on `06ec54b` passed (17:20Z to 17:48Z).

## 2. Audit target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Pull request | #26, draft, branch `claude/project-thread-ne9cwa` into `trunk_dev` |
| Commit | `06ec54b81a0b2afe9512f061bb1fff28e22040c3`, tree `111e028a26297eed12a3f44251701f76f6ea205d`, parent `c99a1b4` (fast-forward) |
| Previous head (audit 22) | `c99a1b46d4d8df2a63f97a13b5e437e3957f1ea9` |
| Base | `trunk_dev` `036d50724b499b020c5149c55ad902cfcb1482c0`, unchanged |
| Change | `producercontract_test.go`, `workstream_a_guardrails_test.go`, `workstream_b_guardrails_test.go`, `workstream_c_guardrails_test.go` in `es/admission`, +605/−83 against `c99a1b4`, test code only (`delta-c99a1b4-06ec54b.diff`, byte-identical to the writer's) |
| Recipe | `governed-execution.audit-patch-manifest.v2`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked before every run |
| Trunk-relative manifest | `98c25abf39ac818fa88def0744f33cdd86d131c57a86f535d088af1c2b32b55f`, 4 files, textual diff `89c6c9b971b505293fad4733db9515784b452144410473c7633dc9e790df46f3`, upstream `origin/trunk_dev` |
| Writer report | `reports/Execution-Substrate/workstream-a-allow-rule/03-repair.md`, delivered with SHA-256 `22a8e44ea3410a5da91101f9c8672c598e04983594c248d14fcfaef32bed996e`. At 17:49Z the writer changed only its section 7 CI line to record run 45226582061's success; it is now `2486c11171b2aaf3dabc6b003c301dc37f0f11874c43d5745b363a3aa0aa4203`. Evidence `03-repair-evidence/`: its `SHA256SUMS` has 70 entries, all OK, and its two manifests are byte-identical to mine (`writer-evidence-check.txt`) |
| Background | `22-audit-pr26-repair.md` (SHA-256 `94d0ce57…a5a0`): A22-1, O22-1, O22-2 |

## 3. Posture and setup

- Read-only on GitHub: no push, comment, review, merge or branch change. One local commit for the trial merge (`06ec54b` plus the proposal) stayed in my clone and was never pushed (section 8.3).
- Clone `/opt/audit/es`. Test trees are `git archive` exports of the exact commits.
- Runs used Go 1.26.5 with `GOTOOLCHAIN=local` and an emptied environment, as two identities: `ci` (uid 1500, gid 1600, with sudo) and `ci2` (uid 1700, gid 1700, without sudo). Probes, mutants and the proposal ran as `ci`.
- Every probe and mutant ran in a fresh copy of a pristine export. The full runs that I compare ran without probes or mutants beside them, apart from a few sub-second probe tests during the `ci2` run and during the trial-merge run. Neither run's results differ from what the comparison predicts.
- I ran the writer's probe script `dto26b.py` (verbatim, SHA-256 `25b2f7dd…8906`) again, on `06ec54b`. No downloaded binary was executed.
- A housekeeping note: at the start I reused a local folder name from an older audit and overwrote one local file of its evidence. I restored it from the published copy and checked it against that evidence's `SHA256SUMS` (all OK). The published evidence was never touched.

## 4. Provenance

| Run | Time | `trunk_dev` | Result |
| --- | --- | --- | --- |
| Opening, two runs | 17:30Z | `036d507` | `98c25abf…b55f` both times, identical to each other and to the writer's `manifests/06ec54b-vs-036d507-trunk-1.json` and `-2.json` |
| Closing, two runs | 17:55Z | `036d507` | `98c25abf…b55f` both times, byte-identical to the opening runs |

The ref check before each pair is explicit, and it passed. The branch and `trunk_dev` were at the expected commits (`ls-remote-open.txt`, `ls-remote-close.txt`). Afterwards the clone was at `06ec54b` with a clean status.

## 5. What changed, and what I verified

### 5.1 Forbidden keys: `accepts`

- `collectJSONFieldNames` returns `workstreamAJSONDecodableKeys`, a struct around the key map with one method, `accepts`. It folds the name it is asked about and looks it up.
- The walk is round 2's walk, which audit 22 verified against Go 1.26.5. It now also calls `t.Fatalf` when it reaches a type with its own `MarshalJSON` or `UnmarshalJSON`. It looks at the type itself, at its pointer, through pointers, slices, arrays and map values, and through promotion from embedded types. `json.RawMessage` is the one exception.
- All seven forbidden checks now read `fieldNames.accepts(forbidden)`.
- Text methods are not refused, and that is right. `encoding/json` writes a string for a type with `MarshalText`, and it will not decode an object into a type with `UnmarshalText` (I checked `decode.go`'s `object`). So text methods can only take keys away.
- `time.Time` has its own `MarshalJSON`, so a future public `time.Time` field would be refused. My probe T5 shows that this fails closed, with a message that names the type. The writer lists this.

### 5.2 Required keys: `assertJSONKeyPathsWritten`

- **Filling.** Every exported field gets something to write, so `omitempty` fields are written too. Each struct type is filled once per branch, so a type that holds itself ends. These stay empty: interfaces, maps whose keys are not strings, and an embedded pointer to an unexported struct type. Nothing beneath them can be required. That limits what can be pinned, but it never makes a pin pass falsely.
- **Writing.** The value is written through a pointer and by value, and a path counts only if it is written both ways. This is the conservative choice for a presence check. A key that only one form writes, through a pointer-receiver method, does not count.
- **Comparing.** Paths are compared exactly. That covers case, a lost tag, name clashes (both fields dropped at one depth; the shallower or tagged field wins) and moved keys. A23-1 is the one gap I found.
- **Coverage** (`written-key-paths-06ec54b-uid1500-gid1600.log`, `presence-coverage-06ec54b.txt`, `pin-check-06ec54b.txt`). A probe test logged every path `encoding/json` writes for `SubmitResult`, `ExecutionStatusResult`, `ExecutionCancelResult` and `ProducerContractDeclaration`. A script then compared the pins with every place where a key of the old lists is written, in each check's envelopes. The script's lists are not taken on trust: a copy of `06ec54b` with one `t.Logf` in `assertJSONKeyPathsWritten` logged the 104 (root, path) pairs the four checks really pass, and a copy of `c99a1b4` with a `t.Logf` before each old `!ok` read logged the keys the old checks required (24, 4, 8 and 14). Both match the script's lists exactly.

  | Check | Pins | Written places of old keys | Old keys without a pin |
  | --- | --- | --- | --- |
  | producer | 53 | 53, the same | none |
  | C3 | 10 | 10, the same | none |
  | C4 | 22 | 22, the same | none |
  | C5 | 33 | 33, the same | none |
  | all, without repeats | 104 | 104, equal | |

  No key that any of the four envelopes writes holds `.`, `[`, `]` or `*` today.

### 5.3 Probes

All probes built, and every result matched my prediction unless noted.

- **Audit 22's `probes21.py`** on `06ec54b` (`probes21-06ec54b-uid1500-gid1600.log`, unexpected=0 against the expectations for this head):
  - Q1, Q2, Q3, Q5 and Q6 are refused;
  - Q0 and Q4 pass.
  
  Q5 also fails the writer's codec test, because that test uses `PrepareRequest`. The writer reported the same.
- **Audit 20's `probes20.py`** on `06ec54b`: all 31 as predicted (`probes20-06ec54b-uid1500-gid1600.log`).
- **The writer's R0 to R7** on `06ec54b`: R0 passes, and R1 to R7 are refused by the DTO guard (`writer-rprobes-06ec54b-uid1500-gid1600.log`).
- **New probes `probes26c.py`.** Each one edits `types.go` in a fresh copy of `c99a1b4` and of `06ec54b`, adds a probe test that logs what `encoding/json` does, and runs the Workstream A, producer and C3 to C5 guards (`probes26c-uid1500-gid1600.log`; T3 and T4 in `probes26c-T3-T4-rerun-uid1500-gid1600.log`, after I fixed a quoting error in my first probe test for them):

| Probe | Change | What `encoding/json` does | `c99a1b4` | `06ec54b` |
| --- | --- | --- | --- | --- |
| T0 | none | | all pass | all pass |
| T1 | `contract` tagged `kontrakt`; a top-level field tagged `"governed_execution.contract"` | writes `"governed_execution.contract"` at the top and `kontrakt` inside | producer **refused** | **pass** (A23-1) |
| T2 | the profile's `name` tagged `label`; a field tagged `"runtime_profiles[].name"` on its parent | writes `label` in each element | producer **refused** | **pass** (A23-1) |
| T3 | `PrepareRequest` gets `json.RawMessage` `extra` | decodes `{"extra":{"publication":{"probe":true}}}` without error and writes it back unchanged | pass | pass (O23-1) |
| T4 | `PrepareRequest` gets `any` `extra` | decodes `{"extra":{"publication":{"probe":true}}}` without error and writes it back unchanged | pass | pass (O23-1) |
| T5 | `PrepareRequest` gets a `time.Time` field | | pass | refused (`time.Time` has its own codec; fails closed) |
| T6 | `PrepareRequest` gets a named map type with its own `MarshalJSON` | writes `"labels":{"publication":true}` | **pass** | refused |
| T7 | `PrepareRequest` gets a named `[]byte` type with its own `MarshalJSON` | writes `"blob":{"publication":true}` | **pass** | refused |

### 5.4 Mutants

- **Audit 20's `mutants20.py`** on `06ec54b`: the control passes, and all 22 are caught (`mutants20-06ec54b-uid1500-gid1600.log`).
- **The writer's 41 mutants** (J01 to J15, N01 to N26): their log shows the control passing and all 41 caught. I did not re-run them. Their N list covers path matching, filling, the comparison, `accepts`' fold, the codec refusal (off, RawMessage refused, pointer receivers unseen, `UnmarshalJSON` unseen, no `Fatalf`, elements unchecked), the pointer/value intersection, and the end of recursion.
- **My `mutants26c.py`** on `06ec54b`. Each mutant runs the Workstream A and B, producer and C2 to C5 guard tests (`mutants26c-uid1500-gid1600.log`):

  | Mutant | Change | Result on `06ec54b` |
  | --- | --- | --- |
  | P00 | none (control) | passes |
  | P01 | the codec check looks only at pointers and structs | **survives** (A23-2) |
  | P02 | every `[]byte` type is exempt, not only `json.RawMessage` | **survives** (A23-2) |

  With probe T6 applied, the guards let it through under P01 but refuse it on `06ec54b`. The same holds for P02 with T7 (`mutants26c-with-probe-T6-…`, `-T7-…`). So the code is right, and only the tests miss these mutants.

## 6. Findings

| ID | Severity | Type | Summary |
| --- | --- | --- | --- |
| A23-1 | low | looseness in a guard, new in `06ec54b` | A key path cannot tell a nested key from a key whose name holds `.`, `[`, `]` or `*`. So a required nested key can move, and a top-level field tagged with its path takes its place unnoticed (T1, T2). On `c99a1b4` both are refused. |
| A23-2 | low | test gap | The codec refusal is right on the real tree (T6, T7), but mutants P01 and P02 survive the suite. The codec test has no case for a named map, slice or `[]byte` type with its own `MarshalJSON`. |

**A23-1 in detail.**
- `workstreamAJSONObjectKeyPaths` joins keys with `.`, appends `[]` for arrays, and the filler names its map entry `*`.
- `encoding/json`'s `isValidTag` allows `.`, `[`, `]` and `*` in a tag name. A key written by a type's own code may hold anything, though those types are refused in the DTO guards.
- So one path string can name two places. The presence check, whose whole purpose is the exact place, then accepts a key in the wrong place.
- It needs a deliberately odd tag, and no current key has one. So it is low, but it is the one road back to O22-1's "moved key" that I found.

**A23-2 in detail.** `workstreamAJSONCustomCodec` runs at every level of the walk before the walk dereferences, so a named map or `[]byte` type with its own codec is refused. That is correct. But nothing in the tests holds that, so a later edit that narrows the check would pass every test. This is the same class as A20-2.

### 6.1 Observations

| ID | Observation |
| --- | --- |
| O23-1 | Older than this commit. A public DTO field of type `any`, `map[string]any` or `json.RawMessage` carries any JSON through, keys included, and the DTO guards cannot see inside it (T3, T4). The writer exempts `json.RawMessage` as data, which is reasonable for a field that is meant to carry data. A probe test walked 25 types reachable from the public DTOs (`PrepareRequest`, the three envelopes, `LifecycleProjection`, `ExecutionOutcomeEvidence`, `ExecutionAuthorityHandoff`, the producer declaration, `ExecutionLogsResult` and `ExecutionResultBundle`) and found no such field (`passthrough-fields-06ec54b-uid1500-gid1600.log`). So a refusal like O22-2's would cost nothing today, and adding such a field would then need an explicit, reviewed exception. |
| O23-2 | `collectJSONFieldNames`' result has an unexported field `keys`, and the writer's own test reads it. Inside the package, `fieldNames.keys[x]` still compiles, so a presence check could still be written against the flat set on purpose. `fieldNames[x]`, the easy mistake, no longer compiles, which is the main point. |
| O23-3 | The writer's counts (1,141 to 1,165 passing, 12 skips) differ from mine (1,146 to 1,170 passing, 7 skips, as `ci`) only in how many tests skip in each environment. The totals agree: 1,153 to 1,177 results. |
| O23-4 | Seen by the writer, outside this PR: `es/config`'s `collectConfigStructFieldNames` uses the old `_, ok` reads on Go field names. The writer has passed it to the coordinator. I did not audit it. |

## 7. Behaviour and tests

`unit23.sh` runs gofmt, vet for three targets and es/admission in full at `06ec54b` and `c99a1b4`, as both identities (`unit-admission-06ec54b-vs-c99a1b4-uid1500-gid1600.log`, `-uid1700-gid1700.log`).

| Identity | `c99a1b4` | `06ec54b` | Difference |
| --- | --- | --- | --- |
| `ci` (sudo) | 1,146 pass, 7 skip | 1,170 pass, 7 skip | +24 new, all pass: 17 for `TestWorkstreamAJSONKeyPathsAreWhatEncodingJSONWrites` and its 16 cases, 7 for `TestWorkstreamAJSONFieldNamesRefuseOwnCodecs` and its 6 cases. 0 changed, none gone |
| `ci2` (no sudo) | 1,135 pass, 11 skip, 7 fail | 1,159 pass, 11 skip, 7 fail | the same +24. The 7 failures are the same at both heads, all from execution-root privilege |

gofmt is clean, and vet is clean for linux/amd64, linux/arm64 and darwin/arm64, at both heads.

## 8. The proposal

`key-path-unambiguous-proposal.diff` (SHA-256 `7a1111851ec5ab750d2ad29b00ffc97a464118c65a6447e89f870c89d4096d8c`) applies with `patch -p1` to `06ec54b`. It is test-only, one file (`workstream_a_guardrails_test.go`), +63/−11:

- **Map entries:** `workstreamAFillJSONValue` puts a map's one entry under the empty key. No struct field can have it, because an empty tag name falls back to the Go name. `workstreamAJSONObjectKeyPaths` names that key `*`, so every existing path, such as `labels.*`, stays as it was.
- **Ambiguous keys:** any other written key that holds `.`, `[`, `]` or `*` is collected instead of becoming a path. `workstreamAJSONWrittenKeyPaths` then fails with `encoding/json writes keys [...] for T, which a key path cannot name unambiguously`.
- **Tests:** three refused cases in the paths test: a top-level `"governed_execution.contract"`, a `"runtime_profiles[].name"` and a `"*"`. Two codec cases: a named map type and a named `[]byte` type, each with its own `MarshalJSON`.

### 8.1 Results on `06ec54b` with the proposal

- **Full run** (`key-path-unambiguous-proposal-uid1500-gid1600.log`):
  - The diff applies, and the log records its SHA-256, which matches the one above.
  - gofmt is clean, and vet is clean for linux/amd64, linux/arm64 and darwin/arm64.
  - es/admission in full: exit 0, 1,172 pass, 7 skip.
  - Compared with `06ec54b` test for test, there are two new results, the two codec cases, and both pass. Nothing else changes. The three refused key cases run as a loop inside the existing paths test, not as subtests, so they add no results of their own.
- **My probes T0 to T7** (`probes26c-fix-and-trial-merge-uid1500-gid1600.log`, unexpected=0):
  - T0 passes;
  - T1 and T2 are refused by the producer check (A23-1 closed);
  - T3 and T4 still pass (O23-1, unchanged by the diff);
  - T5, T6 and T7 are refused.
- **Audit 22's probes** (`probes21-fix-uid1500-gid1600.log`, unexpected=0): Q1, Q2, Q3, Q5 and Q6 are refused, and Q0 and Q4 pass, as on `06ec54b`.
- **My mutants P00 to P02 on the diff** (`mutants26c-on-proposal-uid1500-gid1600.log`): the control passes, and P01 and P02 are now caught by `TestWorkstreamAJSONFieldNamesRefuseOwnCodecs` (A23-2 closed).

### 8.2 Mutants of the proposal

`mutants26c-fix.py` runs the Workstream A and B, producer and C2 to C5 guard tests for each mutant of the diff (`mutants26c-fix-uid1500-gid1600.log`):

| Mutant | Change | Result |
| --- | --- | --- |
| X00 | none (control) | passes |
| X01 | ambiguous keys are not refused | caught |
| X02 | the map entry goes back under the key `*` | caught |
| X03 | the empty key is not named `*` | caught |
| X04 | only `.` counts as a separator | caught |

All four are caught by `TestWorkstreamAJSONKeyPathsAreWhatEncodingJSONWrites`.

### 8.3 With PR #12

PR #12's branch head is `2c8bf35`, the tree audited in `21-audit-pr28.md`.

- `git merge-tree` of `2c8bf35` with `06ec54b`, and with `06ec54b` plus the proposal (a local commit, never pushed), gives the same two conflict blocks in `workstream_a_guardrails_test.go`. These are the blocks the writer's plan resolves. `workstream_c_guardrails_test.go` merges cleanly. The two merged trees differ only by the proposal's own lines (`trial-merge-provenance.txt`).
- In the merged tree, no `fieldNames[…]` read is left in `es/admission`. Only `es/config` keeps its own, unrelated helper (O23-4).
- I resolved the two blocks as the plan says (`trial-merge-2c8bf35-with-proposal-uid1500-gid1600.log`):
  - gofmt is clean, `go build ./...` is ok, and vet of es/admission is clean for the three targets.
  - es/admission in full: exit 0, 2,536 pass, 8 skip.
  - I compared this test for test with the writer's `pr12-trial/trial26c-admission.results.tsv`, which is `2c8bf35` merged with `06ec54b` without my diff (`trial-merge-results-vs-writer.txt`; the random SIGKILL rounds are compared by round number, because their names carry a random delay). Only the two new codec cases are extra. Five tests that the writer's run skipped pass here. They are execution-root checks that skip without passwordless sudo (Inference: the writer's environment lacks it, as in O23-3). Nothing else differs.
  - My probes T0 to T7 on the merged tree give the same results as on `06ec54b` with the diff.

## 9. CI

| Head | Run | Result |
| --- | --- | --- |
| `c99a1b4` | 45212809103 | completed 16:43Z, success |
| `06ec54b` | 45226582061 | completed 17:48Z, success |

(`ci-status.txt`)

## 10. Sensitive material

The probes and fixtures are synthetic. No key, certificate body, token or config file is copied into the evidence. Commit-message trailers and author names are left out.

Before publishing, I scanned this report and every evidence file for private-key and certificate headers, Vault, GitHub, Anthropic and AWS token shapes, JWTs, phone-number shapes, personal names and model names, with a positive control that matched as expected. There were no hits. A second scan for commit trailers and author names found nothing.
