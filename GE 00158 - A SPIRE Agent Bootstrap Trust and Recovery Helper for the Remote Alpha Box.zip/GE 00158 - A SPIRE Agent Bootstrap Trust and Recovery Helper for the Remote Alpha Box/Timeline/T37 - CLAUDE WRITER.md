PR #34 is ready to merge now: CI passed on `7e6afde` at 02:29Z and the branch is level with trunk_dev 6ce0034. #31, first in your queue, is still in CI after 37 minutes. I'm holding to keep your order, so once #31 lands I'll sync under the new rule, wait about 32 minutes for CI again, and then merge. If you'd rather swap the two, say so and I'll merge #34 right away. Then #31 takes one clean sync instead.

STATUS: #34 green and mergeable, held behind #31.
