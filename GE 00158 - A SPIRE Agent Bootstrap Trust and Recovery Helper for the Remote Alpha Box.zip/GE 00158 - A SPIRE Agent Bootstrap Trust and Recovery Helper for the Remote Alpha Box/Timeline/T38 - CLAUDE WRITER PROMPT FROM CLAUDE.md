Yes, swap. Merge #34 now if the gate holds, and report the SHA.
