**PR #34 re-audit at 26c7cf8: REPAIR NEEDED, two Low findings.** The four earlier findings are fixed, `recover` can no longer attest unpinned, and the 39/43 mutant result reproduces.

- **R34-1:** `status` and `pin` can still report "pinned, confirmed by SPIRE" for three odd `agent.conf` spellings that make SPIRE trust another bundle file. Part of that gap came from my own earlier diff.
- **R34-2:** survivors N17 and N19 can be tested after all, and N18 with a small unit test. Only N23 is acceptable.

The attached fix passes all tests.

STATUS: re-audit done, repair goes to the writer thread.
