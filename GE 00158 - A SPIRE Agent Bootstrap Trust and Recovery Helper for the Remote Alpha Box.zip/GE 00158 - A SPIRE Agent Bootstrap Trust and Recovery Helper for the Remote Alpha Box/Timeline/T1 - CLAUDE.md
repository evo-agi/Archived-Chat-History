A correction: the SPIRE deadline I mentioned isn't real. The agent renews daily and only breaks if it's down for a day or two. A small scripts-only fix for it starts now.
