PR #34 is repaired and ready for the narrow re-audit and red-team. All four audit findings are fixed in the PR. trunk_dev 76c030f is merged in (a clean automatic merge).

- **New head:** `26c7cf8012741b2a8e94cdd690061cd959899ce7` (tree `e4dd6306…`), base trunk_dev `76c030f`.
- **Manifest v2:** `e1bc6de6b43ca8986119ec0f41edd902e45b47837c811781f76846e025b58a51`, covering the same 5 files. Tool hash verified, two identical runs, committed files match.
- **A34-1 (Medium):** the attesting run now passes `-trustBundle`, so SPIRE refuses to start if it still reads `insecure_bootstrap`. Two tests pin the order: one checks every attesting run, and one checks that pinning after attesting fails. I also made status, pin and recover ask SPIRE before calling a file pinned, running `validate` both plain and with `-trustBundle`. The `-trustBundle` run alone would have accepted a heredoc that hides the bundle path; the first mutation round found that gap.
- **A34-2 to A34-4:** all fixed with tests. That covers the report crash, stop signals and OS errors (cleanup and rollback now hold signals, and the attesting agent can't be orphaned), and the auditor's missing tests. I also folded in O34-5, O34-6 and O34-7.
- **Checks:** 39 of 43 deliberately broken versions of the code fail the tests. The 4 that pass need a signal inside a window a few instructions wide, or a box account the fixture can't create. The full root package run as an unprivileged user shows no new failures or skips against 76c030f, and GitHub CI is green.

Nothing ran on the box.

STATUS: REPAIRED at 26c7cf8 · audit 02 findings fixed · CI green · waiting on narrow re-audit and red-team, then the gate and the box run
