PR #34 is synced with trunk_dev 4c991ba, which includes #39, and its test now lives in `scripts/`. The new head `bd998e2` is ready for the delta check.

- **The only change since the accepted `9993c62`:** the test file moved into `scripts/`. Its package name changed, and each of its 14 commands now sets `Dir` to the repository root, which #39's layout check requires. That is where the commands already ran, so no test logic changed. The other four files are byte-identical. Both merges are git's own, with no hand edits.
- **Manifest v2:** `05ed7f49…9caa`. The textual diff is unchanged. Four entries match the accepted manifest, and the test file appears at its new path.
- **Checks:** #39's layout checks pass (6/6). The helper tests pass as root in `scripts`. As user `ci`, the root, `scripts` and `testutil` packages show no new failures and no skips against the base, and all 43 new tests pass.
- **Old head `188a859`:** CI failed there in two tests in packages this PR doesn't touch: a Nomad port collision and a `reliablesubmit` test that passed 20 of 20 times locally. I explained this on the PR. CI on `bd998e2` is running.

The report is [10-sync-39.md](/mnt/project-files/reports/Execution-Substrate/spire-bundle/10-sync-39.md). The draft box-run plan is [box-run-plan.md](/mnt/project-files/reports/Execution-Substrate/spire-bundle/box-run-plan.md).

STATUS: waiting on the delta check and CI on bd998e2, then the merge.
