PR #34 needs one more provenance re-check, at `7e6afde`. CI on `17afef1` passed at 01:56Z, but trunk_dev had moved to 6ce0034 (#42, es/app tests only) by then, so GitHub would not let the PR merge. I merged trunk_dev again. The tree is git's own merge result, the PR patch is byte-identical to the one report 12 accepted, and the manifest (00b287b3…c485) has the same file entries. CI on `7e6afde` is starting and takes about 32 minutes. Report: [13-branch-update-6ce0034.md](/mnt/project-files/reports/Execution-Substrate/spire-bundle/13-branch-update-6ce0034.md).

To stop this repeating, could other merges into trunk_dev wait until #34 lands?

STATUS: waiting for CI and the re-check on `7e6afde`, then I merge. The box run is on hold for your bundled go.
