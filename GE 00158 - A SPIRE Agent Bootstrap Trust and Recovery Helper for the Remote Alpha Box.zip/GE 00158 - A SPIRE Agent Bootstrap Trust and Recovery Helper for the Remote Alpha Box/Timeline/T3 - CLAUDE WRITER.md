Draft [PR #34](https://github.com/evo-agi/Execution-Substrate/pull/34) for INF-14 is ready for an independent audit. The implementation report is attached: [01-implementation.md](/mnt/project-files/reports/Execution-Substrate/spire-bundle/01-implementation.md), sha256 `d5ee56a1…4122`.

**What it does:** one scripts-only helper for the box's SPIRE agent.
- `status` is read-only.
- `pin` stops the agent trusting whatever server answers, without registering it again.
- `recover` brings back an agent whose certificate expired. It pins first and uses a single-use token that never appears on a command line, in a log or in output.

**Tests:** they run against real SPIRE 1.14.4. A pinned agent refuses a fake server, and the box's current setting joins it. All 10 of my deliberate code breakages were caught. The whole root package, run as an unprivileged user, has no new failures compared with trunk_dev.

**Audit target:** base trunk_dev `8ba1edb`, head `0927911` (two commits, the second only fixes a test comment), manifest v2 `2632287f…d790`, 5 files.

**Where it differs from Addendum B:**
- The token goes in through a 0600 file (`-joinTokenFile`) instead of a temporary copy of the config.
- The token lives 120 s instead of 300 s.
- The runbook entry waits for the box run.

Nothing ran on the box. GitHub CI is still running, and I'm watching it. A failure would mean a repair commit and a new manifest.

STATUS: READY
