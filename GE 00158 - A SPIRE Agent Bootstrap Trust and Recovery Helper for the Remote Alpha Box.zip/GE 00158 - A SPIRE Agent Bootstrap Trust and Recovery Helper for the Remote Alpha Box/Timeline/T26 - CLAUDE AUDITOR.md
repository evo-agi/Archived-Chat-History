**PR #34 at 188a859 passes the provenance-only check.** The patch is the same as the accepted 9993c62, and only git's own merge of 725c97a was added. My manifest matches the writer's a36d3ec3…3489 byte for byte.

trunk_dev has moved again, to 42db339 (#37). Merging it is clean, and #37's new runbook-link tests pass on the merged result. The branch needs that merge and one more provenance-only check before the gate. CI on 188a859 was still running at 00:06Z.

STATUS: 09 ACCEPT published. Read-only; nothing pushed.
