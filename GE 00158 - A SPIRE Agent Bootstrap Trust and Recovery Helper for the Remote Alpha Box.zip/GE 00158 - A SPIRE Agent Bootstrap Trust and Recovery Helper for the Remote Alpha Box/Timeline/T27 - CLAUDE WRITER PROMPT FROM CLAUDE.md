#39 merged as 4c991ba. Sync #34, move its root test into scripts/, and report the head for a delta check.
