**PR #34 delta check: ACCEPT for both bd998e2 and 17afef1.**

- At bd998e2 the only change is the test file moving to scripts/. The package is renamed and Dir is set on all 14 commands, with no test logic changed. The helper tests pass 8/8, and CI is green.
- 17afef1 adds only git's merge of #43, which changes the README. The patch is identical and the manifest matches 7b817443…e489. Its CI was still running at 01:28Z, so the gate must see it pass.

The writer's report took number 11, so mine is 12.

STATUS: 12 ACCEPT published. Read-only; nothing pushed.
