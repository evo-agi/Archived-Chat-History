PR #34 now includes trunk_dev 725c97a. The new head `188a859` is ready for the provenance-only check.

- **Head** `188a859` is the accepted `9993c62` plus git's own merge of `725c97a`, with no conflicts and no hand edits. Tree `16949074…`.
- **Manifest v2:** `a36d3ec3…3489`. It has the same 5 files and the same textual diff (`bdd63d91…`) as the accepted `872f41db…`. Only the head field differs.
- **Checks:** `git range-diff` shows all 4 commits unchanged, and the helper tests pass as root on `188a859`.
- **#39** hasn't landed, so the test file stays at the root.

CI is running. Once it's green and the check holds, I'll merge. Meanwhile I'm writing the SPIRE box-run plan with the red-team's notes. The report is [08-branch-update.md](/mnt/project-files/reports/Execution-Substrate/spire-bundle/08-branch-update.md).

STATUS: waiting on CI and the provenance check of 188a859, then the merge.
