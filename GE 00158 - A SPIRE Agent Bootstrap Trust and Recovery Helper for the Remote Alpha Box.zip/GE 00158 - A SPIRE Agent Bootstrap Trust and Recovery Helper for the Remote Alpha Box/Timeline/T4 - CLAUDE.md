The SPIRE agent recovery helper ([PR 34](https://github.com/evo-agi/Execution-Substrate/pull/34)) is ready, so I'm starting its audit.
