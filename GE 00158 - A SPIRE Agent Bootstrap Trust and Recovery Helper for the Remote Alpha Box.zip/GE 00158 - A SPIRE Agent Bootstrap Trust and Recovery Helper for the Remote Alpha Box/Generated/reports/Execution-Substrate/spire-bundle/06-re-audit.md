# Narrow re-audit of the second SPIRE agent helper repair (INF-14, PR #34)

**Verdict: ACCEPT. Both re-audit 04 findings are fixed.**
- **R34-1:** the scan now refuses quoted keys anywhere and any non-ASCII character. None of the spellings that fooled `status` and `pin` gets through.
- **R34-2:** N17, N18 and N19 are now caught by tests. That includes the writer's own N19 test, which is sound.
- **Survivors:** four remain (N17c, N17d, N23, plus N17e, which I added). Each sits in a window of a few system calls inside the helper that no test can hold open from outside, and I accept all four.
- **Provenance, tests and CI:** the manifest reproduces, the helper tests pass as root and as an unprivileged user, and CI is green.
- **My error in 04:** report 04's diff was missing the N19 test, as the writer found. That report now carries a correction.

```text
NARROW RE-AUDIT REPORT
Repository:        evo-agi/Execution-Substrate
Audit target:      base trunk_dev 400ff7faa0f124b10dbb607fbad009e346bac4df
                   topic claude/project-thread-wg7jh5 at 9993c62e9faf6e6ecb87f4ce326a93d352a117ec
                   tree 24951907803a3002778619aad2a9374237f593f6
                   = 26c7cf8 (re-audited in 04) + merge 690db9a of 400ff7f + repair commit 9993c62
                   recipe governed-execution.audit-patch-manifest.v2, source sha256
                   c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (verified)
                   manifest_sha256 872f41db4343d16060a03220d120aee1a808686e26e62a9205478a066d303890, 5 paths
Writer report:     reports/Execution-Substrate/spire-bundle/05-repair.md, sha256 bffb19c1…14cc
Scope:             R34-1, R34-2 and the surviving mutants (from 04-re-audit.md)
Audit posture:     read-only on the repo; no subagents; nothing pushed; no PR comment; nothing run on the
                   Linux box. Tests, mutants and probes ran on copies outside the audit clone.
Provenance:        REPRODUCED. Two v2 runs into a fresh 0700 directory, byte-identical, and byte-equal to
                   05-evidence/manifest-v2-9993c62.json. Closing run equal to the opening one (section 7).
Final verdict:     ACCEPT
```

## 0. In plain words

The writer took my fix unchanged and completed it.

- **The `agent.conf` scan:** the helper now refuses any file written in the odd ways that could make SPIRE trust a different bundle file than the one `status` names. I re-ran my probes on the new code, and every such spelling is now refused.
- **Signal handling:** the tests now cover a stop signal during recover's cleanup, a second stop signal during pin's rollback, and the group-membership rule. I re-ran those three breakages (and the scan breakages) against the PR's own bytes, and the tests catch each one.

Four deliberate breakages still pass the tests. Each removes a safety hold around a step that lasts a few microseconds to milliseconds: rewriting one file, two renames, deleting a scratch directory, or starting a process. Holding any of these open would need a hook inside the helper. The code is short and reads correctly, so I accept them.

One correction to my own work: the fix diff in report 04 did not contain the N19 test, although the report said it did. I made the diff before adding that test and never regenerated it. The test results in 04 were real, but the file was incomplete. The writer noticed and wrote the test from my description. Their version is close to mine and slightly stricter. I added a correction note to the top of 04, and I put the missing hunk in this report's evidence.

## 1. Provenance reproduction

```bash
cd /opt/audit/es3   # the audit clone from re-audit 04
git fetch -q origin "+refs/heads/trunk_dev:refs/remotes/origin/trunk_dev" \
  "+refs/heads/claude/project-thread-wg7jh5:refs/remotes/origin/claude/project-thread-wg7jh5"
git rev-parse origin/claude/project-thread-wg7jh5          # 9993c62e…  (tip-ok)
git merge-base --is-ancestor 400ff7fa… 9993c62e…            # ancestor-ok
git merge-base --is-ancestor 26c7cf80… 9993c62e…            # the re-audited head is inside
git checkout -q -f -B claude/project-thread-wg7jh5 9993c62e…; test -z "$(git status --porcelain)"
git rev-parse HEAD^{tree}                                    # 24951907…
git rev-parse 690db9a^{tree}; git merge-tree --write-tree 26c7cf80… 400ff7fa…   # both 0467d411…, = my trial merge in 04
git diff --name-only 400ff7fa… 9993c62e…                     # the same 5 paths
git reset -q --mixed 400ff7fa…; git branch -q --set-upstream-to=origin/trunk_dev
python3 -I "$V2" /opt/audit/manifest5/1.json; python3 -I "$V2" /opt/audit/manifest5/2.json   # 0700 directory, umask 022
cmp 1.json 2.json; cmp 1.json …/05-evidence/manifest-v2-9993c62.json                         # identical
```

Result: `manifest_sha256 872f41db…3890`, `textual_diff_sha256 bdd63d91…2e12`, 5 files. The merge commit `690db9a` is git's own merge, with no hand edits. Copies: `06-re-audit-evidence/manifest/open-{1,2}.json`.

## 2. What changed since 26c7cf8, against my tested files

I rebuilt my tested files from re-audit 04: its diff applied to `26c7cf8`, plus the N19 step exactly as I ran it (`06-re-audit-evidence/compare/n19-step-edit.py.txt`). The result is byte-equal to the hashes that 04 records: `.py` `6c425fec…df17`, test file `d709ae38…36dc`.

- **`scripts/internal/remote_alpha_spire_agent.py`:** my file plus a docstring in `spire_confirms_pinned`. The docstring now names the conditions under which "SPIRE reads the line the scan saw" holds: no quoted key, heredoc or non-ASCII character, and keys counted without regard to case. That claim is now true (section 3).
- **`remote_alpha_spire_agent_test.go`:** my file, except for the N19 step (`compare/test-mine-vs-9993c62.diff`).
  - The writer's fake systemctl uses one `hold-restart` marker for any unit, and logs held restarts by unit name.
  - The writer's step adds two checks. The message must contain "rolled back: stopped by SIGTERM" and must not contain "rollback failed". The agent ID must also be unchanged.
  - It refreshes the agent and `es.service` PIDs before the next step. My version did not; that was harmless only because the next step does not compare those PIDs.

  Every difference makes the test stricter, so I take the writer's version.
- **Docs:** the list of refused shapes now says "a quoted key anywhere, a non-ASCII character", as 04 asked.

## 3. Scope check

| Item | Result | Evidence |
|---|---|---|
| R34-1: three spellings fooled `status` and `pin` | **Fixed.** On `9993c62` the scan refuses all of them: two with "a quoted key" and the long-s ones with "a non-ASCII character", including the long-s `insecure_bootstrap`. The honest pinned file still classifies as pinned. | `probes/hcl-path-aliasing-9993c62.out`, `probes/hcl-unicode-fold-9993c62.out` (the 04 probe scripts, unchanged) |
| R34-1 completeness | **Inference: closed.** With quoted keys and non-ASCII refused, the only other spelling of a key is a change of ASCII letter case, and the existing case-insensitive count catches that. A file in HCL's JSON form cannot contain the `agent {` line the scan requires, and is refused for that reason. Values are compared byte for byte, so an escaped value is refused. | code |
| R34-2: tests for N17, N18 and N19 | **Fixed.** I re-ran each mutant on the PR's own bytes, and each is killed by the intended step (section 4). | `mutants/results-06-on-9993c62.txt` |
| O-R1 from 04 (root-package runs not tied to commits) | **Fixed.** The `.env.txt` files now record run-directory trees `24951907…` = `9993c62^{tree}` and `c6415fd4…` = `400ff7f^{tree}`, both checked here. I recomputed the comparison: head 2065 pass / 244 fail / 0 skip, base 2022 / 244 / 0. 0 tests fail only on head, and all 43 new tests and subtests are the helper's and pass. | `root-package/recompute-writer-json.txt` |

## 4. Mutants

I ran the writer's definitions for every mutant in scope (`05-evidence/mutations/mutations.py.txt`). I also added one of my own, N17e. The writer has mutants for four of the helper's five signal holds; N17e removes the fifth, around the tmpfiles sandbox removal. Each ran on a fresh copy of the exact `9993c62` bytes.

| Mutant | Change | Result |
|---|---|---|
| R1 | quoted keys refused only at the start of a line again | killed (`ConfigAnalysis`: "state pinned, want unrecognized") |
| R2 | non-ASCII allowed again | killed (`ConfigAnalysis`) |
| N13 | quoted keys allowed (re-anchored to the new rule) | killed (`ConfigAnalysis`) |
| N18 | `group_members` lists only `gr_mem` | killed ("members of root [] leave out root, whose primary group it is") |
| N17 | `signals_deferred` is a no-op | killed ("a SIGTERM during cleanup cut it short: scratch entries left") |
| N17b | no hold in `attest_once`'s cleanup only | killed (same) |
| N19 | the handler keeps handling further signals | killed by the writer's step ("two SIGTERMs during pin's restart and its rollback did not end in a finished rollback") |
| N17c | no hold in `restore_config` only | survives (writer predicted) |
| N17d | no hold in `rollback_data_dir` only | survives (writer predicted) |
| N17e (mine) | no hold around the tmpfiles sandbox removal only | survives |
| N23 | no hold around `Popen` | survives (accepted in 04) |

7 killed, 4 survived, exactly as predicted (`mutants/results-06-on-9993c62.txt`). This agrees with the writer's 45/48: every mutant in both runs got the same result in each.

**The survivors (my judgment):**
- **N17c, the hold in `restore_config`:** the window is one `atomic_write` and a read-back of `agent.conf`.
- **N17d, the hold in `rollback_data_dir`:** the window is two `rename` calls.
- **N17e, the hold around the tmpfiles sandbox removal:** the window is an `rmtree` of a small scratch tree.
- **N23, no hold around `Popen`:** the window runs from the fork until `Popen` returns, inside the parent.

None of these waits on another process, so no shim or fake systemctl can hold the window open. A test would need a hook inside the helper, which the rule of testing the real script argues against.

What the holds do: each only defers a first stop signal that lands inside that short window after an ordinary failure. A later signal is already ignored, because N19's switch is now tested. Each hold is a two-line `with` that reads correctly. **Accept all four.**

## 5. Validation

| Command | Bytes | Result |
|---|---|---|
| `go test -count=1 -v -run '^TestRemoteAlphaSPIREAgent' .` as root, `env -i`, Go 1.26.5, SPIRE tarball pinned | 9993c62 | 8/8 PASS (`tests/helper-tests-root-9993c62.log`) |
| the same as an unprivileged user (uid 1500, no sudo) | 9993c62 | 8/8 PASS (`tests/helper-tests-ci-uid1500-9993c62.log`) |
| GitHub Actions "build, vet and test", run 45283590343, job 138074040852 | 9993c62 | success, 22:51:26Z to 23:20:49Z |
| root package comparison | writer's JSON, trees verified | 0 failing only on head (section 3) |
| trial merge onto current trunk_dev `725c97a` (#33 and #41, after `400ff7f`) | merge tree `16949074…` | clean. No path is changed on both sides: #33 and #41 touch only `es/config` and `runtimeconfig/v1` tests (`trial-merge-725c97a.txt`) |

Not run: anything on the box; macOS; the 37 writer mutants outside this scope. Those were killed in 04, and the repair only added tests and a docstring.

## 6. Before merge

- **Base update:** ES requires an up-to-date branch, so the merge gate must first bring in `725c97a` (or whatever trunk_dev is by then). That merge is clean and shares no path. After it, a provenance-only re-check of the new head is enough (provenance doc section 5.4).
- **PR #39:** still an open draft. Whichever of #34 and #39 lands second must move `remote_alpha_spire_agent_test.go` into `scripts/`. That needs the narrow re-check described in re-audit 04 section 6.
- **Red-team:** still recommended as a narrow pass before merge, as in audits 02 and 04. It is the coordinator's call under the scope rule, since this is a scripts-only PR.

## 7. Closing provenance

At 23:32Z, after all tests, mutants and probes, and after removing the scratch trees:

```text
git ls-remote origin: claude/project-thread-wg7jh5 = 9993c62e…  (unchanged)
                      trunk_dev = 725c97a9…  (moved by #33 and #41; section 5)
audit clone:          HEAD 400ff7fa…, upstream name origin/trunk_dev, branch claude/project-thread-wg7jh5
recipe sha256         c08597e2…a3ca (unchanged)
python3 -I v2 /opt/audit/manifest6-close/1.json   (fresh 0700 directory, umask 022)
manifest_sha256       872f41db4343d16060a03220d120aee1a808686e26e62a9205478a066d303890
textual_diff_sha256   bdd63d91404cfa9964d2368d43f0993dff68cd549af96b400e3c057600272e12, 5 files
cmp close-1.json open-1.json: byte-identical
```

Copy: `06-re-audit-evidence/manifest/close-1.json`.

## 8. Correction to re-audit 04

`04-re-audit-evidence/proposed-fix/proposed-fix.diff` (sha256 `30476407…a3d3`) lacks the N19 step. Applied to `26c7cf8`, it gives test file `2acec82f…`, not the tested `d709ae38…`. The cause: I added the step to my test tree after I had generated the diff, and I did not regenerate it before publishing. Two things in 04 still hold: the test logs and mutant results, which came from the full tested tree; and the description of the step, from which the writer rebuilt it.

I have now done three things:
- added a correction note at the top of `04-re-audit.md`;
- put the missing hunk in `06-re-audit-evidence/compare/missing-n19-hunk-from-04.diff`, from which `d709ae38…` rebuilds exactly;
- saved a lesson to project memory: regenerate the diff after the last edit, and check its result against the tested shas when publishing.

## 9. Effect status

Audit only. This thread made no repair commit, push, PR comment, merge or box action. The one change outside this report is the correction note added to `04-re-audit.md`. Evidence is under `06-re-audit-evidence/` (`SHA256SUMS.txt`). Scratch trees were removed before the closing manifest.
